/******************************************************************************
 ** FILE NAME  : StrBCDConv.h 
 ** AUTHOR     : Sadiq S. 
 ** DEFINITION : This includes BCD and Str conversion related declaration
 ** Change Log : Created on 23/4/2008
 ** REMARKS    :
 *******************************************************************************/

#ifndef STRBCDCONV_H
#define STRBCDCONV_H

#include "UniTypes.h"
//#include "Logger.h"
bool     ValidateIpv4(char *p_ipadd);
bool    checkValidBCDDigit(u8 c);
int     numToBCD(u8 *m_numStr, u8 *m_bcdStr, u8 m_numStrLength);
int     BCDToWholeNum(u8 m_bcdStr, u8 *m_numStr);
int     WholeNumToBCD( u8 m_numStr, u8 *m_bcdStr);
int     BCDToNum(u8 *m_bcdStr, u8 *m_numStr, u16 m_bcdStrLength);
void    BCDToString(u8 *str, u8 *bcd, int i);
void    BCDToString(u8 *str, u8 *bcd, s32 i, bool oddEven);
void    StringToBCD(u8 *dest,u8 *src, int length);
bool    ConvertInto8Bit(unsigned char *source, unsigned char *dest, int len);
unsigned int parseHex(const char * str);
void convertIPV4toHex(char * apIPv4Addr,unsigned char *apAddrInHex);

#endif /* STRBCDCONV_H */
