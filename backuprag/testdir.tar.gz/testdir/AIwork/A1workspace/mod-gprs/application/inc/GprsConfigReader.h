#ifndef _GPRS_CONFIG_READER_H
#define __GPRS_CONFIG_READER_H
#include <ConfigReader.h>
class GprsConfigReader: public ConfigReader
{
   public :
      GprsConfigReader();
      ~GprsConfigReader();
      int m_GGSNSSN;
      int m_SGSNSSN;
      int m_HLRSSN;
      int m_retrycount;
      int m_noteMStimer;
      int m_retryTimer;
      bool readData();
      void printConfigData(char *p_output);
};

extern GprsConfigReader *g_GprsConfigReaderObj;
extern bool resetStruct(int p_version, int p_pdu, void *p_struct);
#endif
