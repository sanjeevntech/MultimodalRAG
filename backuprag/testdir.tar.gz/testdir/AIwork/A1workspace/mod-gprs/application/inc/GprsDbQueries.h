#ifndef __NPC_DB_QUERIES_H
#define __NPC_DB_QUERIES_H
#include<vector>
using namespace std;


#include <DbQueryMsg.h>
//#include <CtxtNoteMsPresentGprs.h>

class SendRoutingInfoData : public DbQueryMsg 
{
   public:
      SendRoutingInfoData();
      ~SendRoutingInfoData();
      bool  executeQuery(void*);
      int   m_TypeOfQuery;
      int m_ErrorCode;
      char m_InIMSI[20];
      char m_InGGSNAddress[30];
      char m_InGGSNNumber[20];
      char m_OutSGSNAddress[30];
      char m_OutSGSNNumber[20];
      int m_MNRG;
      unsigned int m_MNRR_SGSN;
      int m_nwid;
      char m_ActiveIMSI[20];
      char m_OutHLRAddress[20];
};
class FailureReportData : public DbQueryMsg 
{
   public:
      FailureReportData();
      ~FailureReportData();
      bool  executeQuery(void*);
      int   m_TypeOfQuery;
      int m_ErrorCode;
      char m_InIMSI[20];
      char m_InGGSNAddress[30];
      char m_InGGSNNumber[20];
      char m_ActiveIMSI[20];
      char m_OutHLRAddress[20];

};
typedef struct t_GGSNAddress
{
   char m_OutGGSNNumber[20];
   char m_OutGGSNAddress[30];
   char m_OutHLRAddress[20];
}GGSNAddresslist;
class NoteMsPresentGPRSData : public DbQueryMsg 
{
   public:
      int m_Count;
      GGSNAddresslist m_ggsnaddlist[10];
      NoteMsPresentGPRSData();
      ~NoteMsPresentGPRSData();
      bool  executeQuery(void*);
      int   m_TypeOfQuery;
      int m_deleteFlag;
      int m_MNRG;
      int m_dlgId;
      int m_ErrorCode;
      int m_Norows;
      char m_InIMSI[20];
      char m_OutSGSNNumber[20];
      char m_OutSGSNAddress[30];
      char m_InGGSNNumber[20];
};
#endif
