#ifndef __CONTEXT_SIMULATOR
#define __CONTEXT_SIMULATOR

#include <ContextBase.h>
#include <Msg.h>
#include <StrBCDConv.h>


class CSimulator : public ContextBase
{
   private:
      bool flag;
      int  m_isdCount;
      void * m_MsgStrctBuffer;
      int m_ATIdlgId;
      int m_PSIdlgId;


   public:
      CSimulator();
      ~CSimulator();

      bool processMessage(Msg *p_MsgPtr,bool& p_DeleteFlag);
      bool startProcessing();
      bool sendRoutingInfoGprs();
	  bool sendFailureReport();
  };



#endif
