#ifndef __SIBASIC_SERVICEGROUP
#define __SIBASIC_SERVICEGROUP
{
   typedef enum

   {
      BEARERSERVICE_TYPE =1,
      TELESERVICE_TYPE = 2
   }SI_BSType;

   //bstype -- teleservicetype and bearerservicetype
   //
   ////bsggroupcode -- teleservice 
   //
   //--all_teleservice,speech,fax,sms,all_data_servicesync,all
   //
   //_data_asyn,all_teleservice_except_sms(chk this)
   //
   ////bsggroupcode -- bearerservice -- 
   //
   //all_bearerservice,data_sync,data_async,PAD(CHK THIS)
   typedef enum
   {
      BSG_SPEECH               = 0x10,
      BSG_SMS                = 0x20,
      BSG_FAX                 = 0x60,
      BSG_ALL_DATA_CIR_ASYNCH   = 0x50,//bearer
      BSG_ALL_ASYNCH_SERVICE = 0x60,//bearer
      BSG_ALL_DATA_CIR_SYNCH    = 0x58,//bearer
      BSG_ALL_SYNCH_SERVICE    = 0x68,//bearer
      BSG_ALL_DATA_TS           = 0x70,//covers TS_ALL_FAX and TS_ALL_SMS 
      BSGS_ALL_TELE_EXCEPT_SMS  = 0x80,//covers TS_ALL_SPEECH, TS_ALL_FAX
      BSG_VOICE_GROUP       = 0x90,
      BSG_ALL_TS            = 0x00,
      BSG_ALL_BS          = 0x00 //bearer
   }SI_BSGCode;
   typedef enum

   {
      TS_ALL                   = 0x00,
      TS_ALL_SPEECH            = 0x10,
      TS_TELEPHONY             = 0x11,
      TS_EMERGENCY             = 0x12,
      TS_ALL_SMS               = 0x20,
      TS_SMS_MT                = 0x21,
      TS_SMS_MO                = 0x22,
      TS_ALL_FAX               = 0x60,
      TS_FAX3_AND_ALTER_SPEECH = 0x61,
      TS_AUTO_FAX3             = 0x62,
      TS_FAX4                  = 0x63,
      TS_ALL_DATA_TS           = 0x70, //covers TS_ALL_FAX  and TS_ALL_SMS
      TS_ALL_EXEPT_SMS         = 0x80, //covers  TS_ALL_SPEECH, TS_ALL_FAX
      TS_ALL_VOICE_GROUP       = 0x90,
      TS_VOICE_GROUP           = 0x91,
      TS_VOICE_BROADCAST       = 0x92,
      TS_ALL_PLMN_SPECIFIC     = 0xD0

   } SI_TSCode;
   typedef enum
   {
      BS_ALL                   = 0x00,
      BS_ALL_DATA_CDA          = 0x10,
      BS_DATA_CDA_300          = 0x11,
      BS_DATA_CDA_1200         = 0x12,
      BS_DATA_CDA_1200_75      = 0x13,
      BS_DATA_CDA_2400         = 0x14,
      BS_DATA_CDA_4800         = 0x15,
      BS_DATA_CDA_9600         = 0x16,
      BS_GENERAL_DATA_CDA      = 0x17,
      BS_ALL_DATA_CDS          = 0x18,
      BS_DATA_CDS_1200         = 0x1A,
      BS_DATA_CDS_2400         = 0x1C,
      BS_DATA_CDS_4800         = 0x1D,
      BS_DATA_CDS_9600         = 0x1E,
      BS_GENERAL_DATA_CDS      = 0x1F,
      BS_ALL_PAD_ACCESS_CA     = 0x20,
      BS_PAD_ACCESS_CA_300     = 0x21,
      BS_PAD_ACCESS_CA_1200    = 0x22,
      BS_PAD_ACCESS_CA_1200_75 = 0x23,
      BS_PAD_ACCESS_CA_2400    = 0x24,
      BS_PAD_ACCESS_CA_4800    = 0x25,
      BS_PAD_ACCESS_CA_9600    = 0x26,
      BS_GENERAL_PAD_ACCESS_CA = 0x27,
      BS_ALL_DATA_PDS          = 0x28,
      BS_DATA_PDS_2400         = 0x2C,
      BS_DATA_PDS_4800         = 0x2D,
      BS_DATA_PDS_9600         = 0x2E,
      BS_GENERAL_DATA_PDS      = 0x2F,
      BS_ALL_ALT_SPEECH_CDA    = 0x30,
      BS_ALL_ALT_SPEECH_CDS    = 0x38,
      BS_ALL_SPEECH_FB_CDA     = 0x40,
      BS_ALL_SPEECH_FB_CDS     = 0x48,
      BS_ALL_DATA_CIRCUIT_ASYN = 0x50,//covers BS_ALL_DATA_CDA,BS_ALL_ALT_SPEECH_CDA,BS_ALL_SPEECH_FB_CD
      BS_ALL_ASYN              = 0x60,//coversBS_ALL_DATA_CDA,BS_ALL_ALT_SPEECH_CDA,BS_ALL_SPEECH_FB_CD A,BS_ALL_PAD_ACCESS_CA
      BS_ALL_DATA_CIRCUIT_SYN  = 0x58,//covers BS_ALL_DATA_CDS,BS_ALL_ALT_SPEECH_CDS,BS_ALL_SPEECH_FB_CDS
      BS_ALL_SYN               = 0x68,//covers BS_ALL_DATA_CDS,BS_ALL_ALT_SPEECH_CDS,BS_ALL_SPEECH_FB_CDS,BS_ALL_DATA_PDS
      BS_ALL_PLMN_SPECIFIC     = 0xD0
   }SI_ BSCode;

   typedef enum
   {
      SS_ALL          = 0x00,
      SS_ALL_LINE       = 0x10,
      SS_CLIP           = 0x11,
      SS_CLIR           = 0x12,
      SS_COLP           = 0x13,
      SS_COLR           = 0x14,
      SS_MCI            = 0x15,
      SS_ALL_NAME       = 0x18,
      SS_CNAP           = 0x19,
      SS_ALL_CF         = 0x20,
      SS_CFU            = 0x21,
      SS_ALL_CCF        = 0x28,
      SS_CFB            = 0x29,
      SS_CFNRY       = 0x2A,
      SS_CFNRC       = 0x2B,
      SS_CD          = 0x24,
      SS_ALL_CALL_OFFR  = 0x30,
      SS_ECT            = 0x31,
      SS_MAH            = 0x32,
      SS_ALL_CALL_COMPL = 0x40,
      SS_CW          = 0x41,
      SS_HOLD           = 0x42,
      SS_CCBSA       = 0x43,
      SS_CCBSB       = 0x44,
      SS_ALL_MPTY       = 0x50,
      SS_MPTY           = 0x51,
      SS_ALL_COMTY_INT  = 0x60,
      SS_CUG            = 0x61,
      SS_ALL_CHARGE     = 0x70,
      SS_AOCI           = 0x71,
      SS_AOCC           = 0x72,
      SS_ALL_ADD_INFO_TR   = 0x80,
      SS_UUS1           = 0x81,
      SS_UUS2           = 0x82,
      SS_UUS3           = 0x83,
      SS_ALL_BAR        = 0x90,
      SS_BAR_OG_CALLS      = 0x91,
      SS_BAOC           = 0x92,
      SS_BOIC           = 0x93,
      SS_BOICEXHC       = 0x94,
      S_BAR_IC_CALLS    = 0x99,
      SS_BAIC           = 0x9A,
      SS_BICROAM        = 0x9B,
      SS_ALL_CALL_PRI      = 0xA0,
      SS_EMLPP       = 0xA1,
      SS_MC          = 0x45,
      SS_FM          = 214,
      SS_ALL_LCS_PRIVACY_EX   = 0xB0, //MAP3
      SS_UNIVERSAL         = 0xB1, 
      //MAP3-allow location by any LCS client
      SS_CALL_SESS_RELATED = 0xB2, //MAP3
      SS_CALL_SESS_UNRELATED  = 0xB3, //MAP3
      SS_PLMN_OPERATOR     = 0xB4, //MAP3
      SS_SERVICE_TYPE      = 0xB5, //added 
      //MAP3-allow location by LCS clients of a designated 
      //LCS service type
      S_ALL_MOLR        = 0xC0, //MAP3
      SS_BASIC_SELF_LOCATION  = 0xC1, //MAP3
      SS_AUTO_SELF_LOCATION   = 0xC2, //MAP3
      SS_TRANSFER_TO_3RD_PTY  = 0xC3   //MAP3
   }SI_SSCode;
