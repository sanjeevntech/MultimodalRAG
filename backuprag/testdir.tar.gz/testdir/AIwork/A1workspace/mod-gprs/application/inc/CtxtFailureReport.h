#ifndef __CONTEXT_FAILURE_REPORT
#define __CONTEXT_FAILURE_REPORT

#include <ContextBase.h>
#include <Msg.h>
#include <Utilities.h>
#include "MapMessages.h"
#include "GprsDbQueries.h"



class CtxtFailureReport : public ContextBase
{
   private:

      FailureReportData *m_ptrfailreport;
      EMapVersion m_MapVesion;
      MapSpecificIndication *m_MsgSpecificMsgInd;


   public:
      CtxtFailureReport();
      ~CtxtFailureReport();
      int m_FRdlgId;
      bool sendErrorResponse(EMapErrorCode p_ErrorCode);
      bool processMessage(Msg *p_MsgPtr,bool& p_DeleteFlag);
      bool handleFailtureReport(Msg *p_MsgPtr);
      bool handleDBResponse(Msg *p_MsgPtr,bool& p_DeleteFlag);
      bool sendFailureReportResp();

};
#endif
