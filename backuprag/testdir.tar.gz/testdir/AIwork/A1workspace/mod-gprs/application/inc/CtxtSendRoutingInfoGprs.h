#ifndef __CONTEXT_SEND_ROUTING_INFO_GPRS
#define __CONTEXT_SEND_ROUTING_INFO_GPRS

#include <ContextBase.h>
#include <Msg.h>
#include <Utilities.h>
#include <MapMessages.h>
#include <GprsDbQueries.h>

class CtxtSendRoutingInfoGprs : public ContextBase
{
   private:
      MapSpecificIndication * m_MsgSpecificMsgInd;
      int m_SRIdlgId;
      bool m_ErrorInd;
      EMapVersion m_MapVesion;
      SendRoutingInfoData *mp_routingInfoData;


   public:
      CtxtSendRoutingInfoGprs();
      ~CtxtSendRoutingInfoGprs();

      bool processMessage(Msg *p_MsgPtr,bool& p_DeleteFlag);
      bool handleDBResponse(Msg *p_MsgPtr);
      bool handleRoutingInfo(Msg *p_MsgPtr);
      bool sendRountingInfoResp();
      bool sendErrorResponse(EMapErrorCode p_ErrorCode,EMapVersion p_MapVer);
      //void convertIPV4toHex(char * apIPv4Addr,unsigned char *apAddrInHex);
};



#endif
