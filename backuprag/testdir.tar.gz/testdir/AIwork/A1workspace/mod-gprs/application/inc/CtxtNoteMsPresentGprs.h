#ifndef __CONTEXT_NOTE_PRESENT_GPRS
#define __CONTEXT_NOTE_PRESENT_GPRS

#include <ContextBase.h>
#include <Msg.h>
#include <Utilities.h>
#include <GprsDbQueries.h>
#include "MapMessages.h"
#include "GprsDbQueries.h"

#include <map>
using namespace std;

typedef struct t_GgsnAddress
{
   int retCount;
   GGSNAddresslist ggsnAddress;
   unsigned char m_ggsnaddress[4];
}GgsnAddress;
class CtxtNoteMsPresentGprs : public ContextBase
{
   private:
      //NoteMsPresentGPRSData *m_ptrMsPresent;
      EMapVersion m_MapVesion;     
      unsigned char m_sgsnaddress[4];
      char m_imsi[20];
      int m_refcount;

   public:
      map<int,GgsnAddress> mapGgsnAddress; 
      bool startProcessing(InterModuleData *p_imd,bool& p_DeleteFlag);
      CtxtNoteMsPresentGprs();
      ~CtxtNoteMsPresentGprs();
      bool processMessage(Msg *p_MsgPtr,bool& p_DeleteFlag);
      bool sendRetryReq(NoteMsPresentGPRSData *p_msPresent,int p_userId,bool &p_deleteFlag);
      int m_MSPrntdlgId;
      bool sendErrorResponse(EMapErrorCode p_ErrorCode);
      bool handleDBResponse(Msg *p_MsgPtr,bool& p_DeleteFlag,int p_userId);
      bool sendMSPresentReq(NoteMsPresentGPRSData *p_msPresent,bool& p_DeleteFlag);
      bool checkmnrgFlag(int p_userId,bool &p_deleteflag);
      bool fillNoteMSPresentGPRS(int p_dlgId,unsigned char* p_SGSNAddress,char *p_GGSNNumber,unsigned char *p_GGSNAddress,char *p_hlrAddress);


};
#endif
