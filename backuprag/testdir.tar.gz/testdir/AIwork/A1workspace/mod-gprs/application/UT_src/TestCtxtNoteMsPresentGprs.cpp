#define private public
#include<iostream>
#include"gtest.h"
#include <CtxtNoteMsPresentGprs.h>
#include <stdio.h>
#include <MapMessages.h>
#include <ServiceCoordinator.h>
#include <Logger.h>
#include <OMAP3.h>
#include <IMAP3.h>
#include <DbActiveObject.h>
#include "Utilities.h"
#include <string.h>
#include <DataUnion.h>
#include <CtxtSendRoutingInfoGprs.h>
#include <GprsConfigReader.h>
#include <map>
#include <HlrTdrFiller.h>
#include <ContextBase.h>
#include <Msg.h>
#include <Utilities.h>
#include <GprsDbQueries.h>
#include <map>

class UT_CtxtNoteMsPresentGprs: public testing::Test , public CtxtNoteMsPresentGprs
{public:
UT_CtxtNoteMsPresentGprs()
{
}
~UT_CtxtNoteMsPresentGprs()
{
}
};

class UT_InterModuleData 
{public:
UT_InterModuleData()
{
}
~UT_InterModuleData()
{
}
};

class UT_NoteMsPresentGPRSData
{public:
UT_NoteMsPresentGPRSData()
{
}
~UT_NoteMsPresentGPRSData()
{
}
};

class UT_GprsConfigReader
{public:
UT_GprsConfigReader()
{
}
~UT_GprsConfigReader()
{
}
};

class UT_Msg
{public:
UT_Msg()
{
}
~UT_Msg()
{
}
};

class UT_MapCommonMsg
{public:
UT_MapCommonMsg()
{
}
~UT_MapCommonMsg()
{
}
};


/*TEST_F(UT_CtxtNoteMsPresentGprs,startProcessing_Func) {
InterModuleData p_imd;
NoteMsPresentGPRSData obj;
m_MSPrntdlgId=1;
strcpy(p_imd.m_Parameters,"aaaa");
strcpy(obj.m_InIMSI,"bbb");
bool p_DeleteFlag=false;
EXPECT_FALSE(startProcessing(&p_imd,p_DeleteFlag));
EXPECT_EQ(obj.m_UserDlgId,0);
EXPECT_EQ(obj.m_TypeOfQuery,0);
}*/

TEST_F(UT_CtxtNoteMsPresentGprs,checkmnrgFlag_Func) {
t_GgsnAddress a;
a.retCount=1;
strcpy(a.m_ggsnaddress,"aaaa");
t_GgsnAddress b;
b.retCount=2;
strcpy(b.m_ggsnaddress,"bbbb");
map<int,GgsnAddress> obj;
obj.insert(pair<int,GgsnAddress>(1,a));
obj.insert(pair<int,GgsnAddress>(1,b));
m_refcount=0;
NoteMsPresentGPRSData obj1;
strcpy(m_imsi,"aaaaa");
bool p_deleteflag=false;
EXPECT_TRUE(checkmnrgFlag(1,p_deleteflag));
EXPECT_EQ(obj1.m_TypeOfQuery,0);
EXPECT_EQ(obj1.m_dlgId,0);
EXPECT_EQ(p_deleteflag,true);
}

TEST_F(UT_CtxtNoteMsPresentGprs,sendMSPresentReq_Func) {
NoteMsPresentGPRSData p_msPresent;
p_msPresent.m_Norows=1;
strcpy(p_msPresent.m_OutSGSNAddress,"266.1266.266.289");
bool p_deleteflag=false;
EXPECT_FALSE(sendMSPresentReq(&p_msPresent,p_deleteflag));
EXPECT_EQ(p_deleteflag,false);
EXPECT_EQ(p_msPresent.m_Norows,1);
}

TEST_F(UT_CtxtNoteMsPresentGprs,sendMSPresentReq_Two_Func) {
NoteMsPresentGPRSData p_msPresent;
p_msPresent.m_Norows=1;
strcpy(p_msPresent.m_OutSGSNAddress,"125.12.0.1");
//p_msPresent.m_ggsnaddlist[10]="11111";
GGSNAddresslist a;
strcpy(a.m_OutGGSNNumber,"aaaa");
strcpy(a.m_OutGGSNAddress,"bbbbb");
strcpy(a.m_OutHLRAddress,"cccc");
bool p_deleteflag=false;
g_GprsConfigReaderObj=new GprsConfigReader;
g_GprsConfigReaderObj->m_retrycount=1;
EXPECT_FALSE(sendMSPresentReq(&p_msPresent,p_deleteflag));
EXPECT_EQ(p_deleteflag,false);
EXPECT_EQ(p_msPresent.m_Norows,1);
EXPECT_EQ(g_GprsConfigReaderObj->m_retrycount,1);
}

TEST_F(UT_CtxtNoteMsPresentGprs,processMessage_MAP_CMN_OPEN_IND_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MapCommonMsgType=202;
bool p_DeleteFlag=false;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtNoteMsPresentGprs,processMessage_MAP_CMN_OPEN_CNF_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MapCommonMsgType=204;
bool p_DeleteFlag=false;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtNoteMsPresentGprs,processMessage_MAP_CMN_DELIMITER_IND_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MapCommonMsgType=208;
bool p_DeleteFlag=false;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtNoteMsPresentGprs,processMessage_MAP_CMN_CLOSE_IND_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MapCommonMsgType=206;
bool p_DeleteFlag=false;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtNoteMsPresentGprs,processMessage_MAP_CMN_U_ABORT_IND_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MapCommonMsgType=210;
bool p_DeleteFlag=false;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
NoteMsPresentGPRSData *ptr=new NoteMsPresentGPRSData;
EXPECT_EQ(ptr->m_TypeOfQuery,0);
EXPECT_EQ(ptr->m_dlgId,0);
delete ptr;
}

TEST_F(UT_CtxtNoteMsPresentGprs,processMessage_MAP_CMN_P_ABORT_IND_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MapCommonMsgType=212;
bool p_DeleteFlag=false;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
NoteMsPresentGPRSData *ptr=new NoteMsPresentGPRSData;
EXPECT_EQ(ptr->m_TypeOfQuery,0);
EXPECT_EQ(ptr->m_dlgId,0);
delete ptr;
}

TEST_F(UT_CtxtNoteMsPresentGprs,processMessage_MAP_CMN_NOTICE_IND_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MapCommonMsgType=213;
bool p_DeleteFlag=false;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
NoteMsPresentGPRSData *ptr=new NoteMsPresentGPRSData;
EXPECT_EQ(ptr->m_TypeOfQuery,0);
EXPECT_EQ(ptr->m_dlgId,0);
delete ptr;
}

TEST_F(UT_CtxtNoteMsPresentGprs,processMessage_default_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MapCommonMsgType=0;
bool p_DeleteFlag=false;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtNoteMsPresentGprs,sendErrorResponse_MAP_ERROR_unknownSubscriber_Func) {
EXPECT_TRUE(sendErrorResponse(1));
TdrData obj;
EXPECT_TRUE(obj.m_CDR != NULL);
}

TEST_F( UT_CtxtNoteMsPresentGprs,sendErrorResponse_MAP_ERROR_unexpectedData_Func) {
EXPECT_TRUE(sendErrorResponse(36));
TdrData obj;
EXPECT_TRUE(obj.m_CDR != NULL);
}

TEST_F(UT_CtxtNoteMsPresentGprs,sendErrorResponse_MAP_ERROR_dataMissing_Func) {
EXPECT_TRUE(sendErrorResponse(35));
TdrData obj;
EXPECT_TRUE(obj.m_CDR != NULL);
}

TEST_F(UT_CtxtNoteMsPresentGprs,sendErrorResponse_MAP_ERROR_systemFailure_Func) {
EXPECT_TRUE(sendErrorResponse(34));
TdrData obj;
EXPECT_TRUE(obj.m_CDR != NULL);
}

TEST_F(UT_CtxtNoteMsPresentGprs,sendErrorResponse_MAP_ERROR_default_Func) {
EXPECT_TRUE(sendErrorResponse(0));
TdrData obj;
EXPECT_TRUE(obj.m_CDR != NULL);
}

TEST_F(UT_CtxtNoteMsPresentGprs ,processMessage_MAP_SPEC_EVENT_IND_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=2;
bool p_DeleteFlag=false;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtNoteMsPresentGprs,processMessage_MAP_SPEC_EVENT_RESULT_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=3;
bool p_DeleteFlag=false;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtNoteMsPresentGprs,processMessage_MAP_SPEC_EVENT_CONFIRMATION_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=4;
bool p_DeleteFlag=false;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtNoteMsPresentGprs,processMessage_MAP_SPEC_EVENT_USER_ERROR_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=5;
p_MsgPtr.m_UserDlgId=1;
bool p_DeleteFlag=false;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtNoteMsPresentGprs,processMessage_MAP_SPEC_EVENT_PROV_ERROR_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=6;
p_MsgPtr.m_UserDlgId=1;
bool p_DeleteFlag=false;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

#undef private
