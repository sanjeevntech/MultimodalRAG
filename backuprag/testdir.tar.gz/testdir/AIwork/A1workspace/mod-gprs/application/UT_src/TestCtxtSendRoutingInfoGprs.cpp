#define private public
#include <iostream>
#include "gtest.h"
#include <ContextBase.h>
#include <Msg.h>
#include <CtxtSendRoutingInfoGprs.h>
#include <stdio.h>
#include <MapMessages.h>
#include <ServiceCoordinator.h>
#include <Logger.h>
#include <IMAP3.h>
#include <OMAP3.h>
#include <GprsDbQueries.h>
#include <DbActiveObject.h>
#include <ConfigReader.h>
#include <string.h>
#include <DataUnion.h>
#include "Utilities.h"
#include <GprsConfigReader.h>
#include <HlrTdrFiller.h>
class UT_CtxtSendRoutingInfoGprs : public testing::Test , public CtxtSendRoutingInfoGprs
{public:
UT_CtxtSendRoutingInfoGprs()
{
}
~UT_CtxtSendRoutingInfoGprs()
{
}
};


class UT_TdrData
{public:
UT_TdrData()
{
}
~UT_TdrData()
{
}
};


class UT_MapMsg
{public:
UT_MapMsg()
{
}
~UT_MapMsg()
{
}
};

class UT_MapCommonMsg
{public:
UT_MapCommonMsg()
{
}
~UT_MapCommonMsg()
{
}
};

class UT_MapSpecificMsg
{public:
UT_MapSpecificMsg()
{
}
~UT_MapSpecificMsg()
{
}
};


TEST_F(UT_CtxtSendRoutingInfoGprs,sendErrorResponse_MAP_ERROR_unknownSubscriber_Func) {
EXPECT_TRUE(sendErrorResponse(1,1));
TdrData obj;
EXPECT_TRUE(obj.m_CDR != NULL);
}
TEST_F(UT_CtxtSendRoutingInfoGprs,sendErrorResponse_MAP_ERROR_unexpectedData_Func) {
EXPECT_TRUE(sendErrorResponse(36,2));
TdrData obj;
EXPECT_TRUE(obj.m_CDR != NULL);
}

TEST_F(UT_CtxtSendRoutingInfoGprs,sendErrorResponse_MAP_ERROR_dataMissing_Func) {
EXPECT_TRUE(sendErrorResponse(35,3));
TdrData obj;
EXPECT_TRUE(obj.m_CDR != NULL);
}

TEST_F(UT_CtxtSendRoutingInfoGprs,sendErrorResponse_MAP_ERROR_CallBarred_Func) {
EXPECT_TRUE(sendErrorResponse(34,1));
TdrData obj;
EXPECT_TRUE(obj.m_CDR != NULL);
}

TEST_F(UT_CtxtSendRoutingInfoGprs,sendErrorResponse_MAP_ERROR_AbsentSubscriber_Func) {
EXPECT_TRUE(sendErrorResponse(31,1));
TdrData obj;
EXPECT_TRUE(obj.m_CDR != NULL);
}


//-----------------------------------------------------------------------------

TEST_F(UT_CtxtSendRoutingInfoGprs,processMessage_MAP_CMN_OPEN_IND_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=202;
bool p_DeleteFlag=false;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtSendRoutingInfoGprs,processMessage_MAP_CMN_DELIMITER_IND_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=208;
bool p_DeleteFlag=false;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtSendRoutingInfoGprs,processMessage_MAP_CMN_CLOSE_IND_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=206;
bool p_DeleteFlag=false;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtSendRoutingInfoGprs,processMessage_MAP_CMN_U_ABORT_IND_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=210;
bool p_DeleteFlag=false;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtSendRoutingInfoGprs,processMessage_MAP_CMN_P_ABORT_IND_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=212;
bool p_DeleteFlag=false;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtSendRoutingInfoGprs,processMessage_MAP_CMN_NOTICE_IND_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=213;
bool p_DeleteFlag=false;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtSendRoutingInfoGprs,processMessage_MapCommonMsg_default_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=214;
bool p_DeleteFlag=false;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtSendRoutingInfoGprs,processMessage_MAP_SPEC_EVENT_IND_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=2;
p_MsgPtr.m_OpCode=2;
p_MsgPtr.m_allocatedFlag=false;
bool p_DeleteFlag=false;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtSendRoutingInfoGprs,processMessage_MAP_SPEC_EVENT_RESULT_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=3;
bool p_DeleteFlag=false;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtSendRoutingInfoGprs ,processMessage_MAP_SPEC_EVENT_CONFIRMATION_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=4;
p_MsgPtr.m_OpCode=2;
bool p_DeleteFlag=false;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtSendRoutingInfoGprs,processMessage_MAP_SPEC_EVENT_USER_ERROR_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=5;
bool p_DeleteFlag=false;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtSendRoutingInfoGprs,processMessage_MAP_SPEC_EVENT_PROV_ERROR_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=6;
bool p_DeleteFlag=false;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtSendRoutingInfoGprs,processMessage_MAP_MSG_TYPE_SPEC_default_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=0;
bool p_DeleteFlag=false;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}


TEST_F(UT_CtxtSendRoutingInfoGprs,processMessage_MAP_MSG_TYPE_default_Func) {
MapMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=0;
bool p_DeleteFlag=false;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtSendRoutingInfoGprs,processMessage_MSG_TYPE_DB_Func) {
Msg p_MsgPtr;
p_MsgPtr.m_MsgType=2;
bool p_DeleteFlag=false;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}


TEST_F(UT_CtxtSendRoutingInfoGprs,processMessage_MSG_TYPE_Default_Func) {
Msg p_MsgPtr;
p_MsgPtr.m_MsgType=0;
bool p_DeleteFlag=false;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}



//-------------------------------------------------------------------------


/*
TEST_F(UT_CtxtSendRoutingInfoGprs ,sendRountingInfoResp_Func) {
mp_routingInfoData->m_InGGSNAddress=true;
mp_routingInfoData->m_OutSGSNAddress=0;
mp_routingInfoData->m_OutSGSNAddress=false;
EXPECT_FALSE(sendRountingInfoResp());
}
*/

TEST_F(UT_CtxtSendRoutingInfoGprs,handleRoutingInfo_Func) {
Msg p_MsgPtr;
CtxtSendRoutingInfoGprs::m_MapVesion=3;
EXPECT_TRUE(handleRoutingInfo(&p_MsgPtr));
}

TEST_F(UT_CtxtSendRoutingInfoGprs,handleRoutingInfo_Default_Func) {
Msg p_MsgPtr;
CtxtSendRoutingInfoGprs::m_MapVesion=0;
EXPECT_TRUE(handleRoutingInfo(&p_MsgPtr));
}

//-------------------------------------------------------------------------


TEST_F(UT_CtxtSendRoutingInfoGprs,handleDBResponse_Func) {
Msg p_MsgPtr;
mp_routingInfoData->m_DbQueryRes=1;
mp_routingInfoData->m_ErrorCode=1;
EXPECT_FALSE(handleDBResponse(&p_MsgPtr));
}

TEST_F(UT_CtxtSendRoutingInfoGprs,handleDBResponse_Two_Func) {
Msg p_MsgPtr;
mp_routingInfoData->m_DbQueryRes=1;
mp_routingInfoData->m_ErrorCode=2;
EXPECT_FALSE(handleDBResponse(&p_MsgPtr));
}

TEST_F(UT_CtxtSendRoutingInfoGprs,handleDBResponse_else_Func) {
Msg p_MsgPtr;
mp_routingInfoData->m_DbQueryRes=0;
strcpy(mp_routingInfoData->m_OutHLRAddress,"aaaaaaaaaaaaaaaaaa");
EXPECT_FALSE(handleDBResponse(&p_MsgPtr));
}




#undef private
