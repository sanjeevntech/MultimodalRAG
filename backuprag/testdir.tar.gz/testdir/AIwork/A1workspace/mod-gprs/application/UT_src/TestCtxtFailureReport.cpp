#define private public
#include<iostream>
#include"gtest.h"
#include <ContextBase.h>
#include <Msg.h>
#include <Utilities.h>
#include "MapMessages.h"
#include "GprsDbQueries.h"
#include "CtxtFailureReport.h"
#include <stdio.h>
#include <MapMessages.h>
#include <ServiceCoordinator.h>
#include <Logger.h>
#include <IMAP3.h>
#include <OMAP3.h>
#include <GprsDbQueries.h>
#include <DbActiveObject.h>
#include <ConfigReader.h>
#include <CtxtSendRoutingInfoGprs.h>
#include <DataUnion.h>
#include "Utilities.h"
#include "CtxtNoteMsPresentGprs.h"
#include <GprsConfigReader.h>
#include <HlrTdrFiller.h>
#include<TdrData.h>

class UT_CtxtFailureReport: public testing::Test , public CtxtFailureReport
{public:
UT_CtxtFailureReport()
{
}
~UT_CtxtFailureReport()
{
}
};

class UT_TdrData
{public:
UT_TdrData()
{
}
~UT_TdrData()
{
}
};

class UT_MapMsg
{public:
UT_MapMsg()
{
}
~UT_MapMsg()
{
}
};

class UT_MapCommonMsg
{public:
UT_MapCommonMsg()
{
}
~UT_MapCommonMsg()
{
}
};

class UT_MapSpecificMsg
{public:
UT_MapSpecificMsg()
{
}
~UT_MapSpecificMsg()
{
}
};


TEST_F(UT_CtxtFailureReport,sendErrorResponse_MAP_ERROR_unknownSubscriber_Func) {
	EXPECT_TRUE(sendErrorResponse(1));
	TdrData obj;
	EXPECT_TRUE(obj.m_CDR != NULL);
//printf("%s\n",obj.m_CDR);
}

TEST_F(UT_CtxtFailureReport,sendErrorResponse_MAP_ERROR_unexpectedData_Func) {
        EXPECT_TRUE(sendErrorResponse(36));
        TdrData obj;
        EXPECT_TRUE(obj.m_CDR != NULL);
}

TEST_F(UT_CtxtFailureReport,sendErrorResponse_MAP_ERROR_dataMissing_Func) {
        EXPECT_TRUE(sendErrorResponse(35));
        TdrData obj;
        EXPECT_TRUE(obj.m_CDR != NULL);
}

TEST_F(UT_CtxtFailureReport,processMessage_MAP_CMN_OPEN_IND_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=202;
bool p_DeleteFlag=false;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtFailureReport,processMessage_MAP_CMN_DELIMITER_IND_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=208;
bool p_DeleteFlag=false;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtFailureReport,processMessage_MAP_CMN_CLOSE_IND_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=206;
bool p_DeleteFlag=false;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtFailureReport,processMessage_MAP_CMN_U_ABORT_IND_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=210;
bool p_DeleteFlag=false;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtFailureReport,processMessage_MAP_CMN_P_ABORT_IND_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=212;
bool p_DeleteFlag=false;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtFailureReport,processMessage_MAP_CMN_NOTICE_IND_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=213;
bool p_DeleteFlag=false;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtFailureReport,processMessage_MapCommonMsg_default_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=214;
bool p_DeleteFlag=false;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtFailureReport,processMessage_MAP_SPEC_EVENT_RESULT_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=3;
bool p_DeleteFlag=false;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtFailureReport,processMessage_MAP_SPEC_EVENT_CONFIRMATION_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=4;
p_MsgPtr.m_OpCode=1;
bool p_DeleteFlag=false;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtFailureReport,processMessage_MAP_SPEC_EVENT_USER_ERROR_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=5;
bool p_DeleteFlag=false;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtFailureReport,processMessage_MAP_MSG_TYPE_COMMON_default_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=0;
bool p_DeleteFlag=false;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtFailureReport,processMessage_MSG_TYPE_DB_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=2;
bool p_DeleteFlag=false;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}


TEST_F(UT_CtxtFailureReport,sendFailureReportResp_Func) {
EXPECT_TRUE(sendFailureReportResp());
}

TEST_F(UT_CtxtFailureReport,handleDBResponse_Func) {
Msg p_MsgPtr;
m_ptrfailreport->m_DbQueryRes=1;
m_ptrfailreport->m_ErrorCode=1;
bool p_DeleteFlag=false;
EXPECT_FALSE(handleDBResponse(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtFailureReport,handleDBResponse_Two_Func) {
Msg p_MsgPtr;
m_ptrfailreport->m_DbQueryRes=1;
m_ptrfailreport->m_ErrorCode=2;
bool p_DeleteFlag=false;
EXPECT_FALSE(handleDBResponse(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtFailureReport,handleDBResponse_else_Func) {
Msg p_MsgPtr;
m_ptrfailreport->m_DbQueryRes=0;
strcpy(m_ptrfailreport->m_OutHLRAddress,"aaaaaaaaaaaaaaaaaa");
bool p_DeleteFlag=false;
EXPECT_FALSE(handleDBResponse(&p_MsgPtr,p_DeleteFlag));
}


/*TEST_F(UT_CtxtFailureReport,processMessage_MAP_OP_CODE_failureReport_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=2;
p_MsgPtr.m_OpCode=25;
p_MsgPtr.m_allocatedFlag=true;
bool p_DeleteFlag=false;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}
*/


#undef private
