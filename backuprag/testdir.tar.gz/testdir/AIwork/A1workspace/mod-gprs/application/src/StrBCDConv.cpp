/*****************************************************************************
 ** FILE NAME      : StrBCDConv.cpp
 ** AUTHOR         : 
 ** DEFINITION     : Implements the class for converting BCD encoded string
 **                :  to numeric string and vice-versa
 **                : 
 ** change Log     :
 ** REMARKS        :
 ****************************************************************************/
#include  "errno.h"
#include "StrBCDConv.h"
unsigned int parseHex(const char * str) 
{ 
   unsigned int val = 0; 
   char c; 

   while(c = *str++) 
   { 
      val <<= 4; 

      if (c >= '0' && c <= '9') 
      { 
         val += c & 0x0F; 
         continue; 
      } 

      c &= 0xDF; 
      if (c >= 'A' && c <= 'F') 
      { 
         val += (c & 0x07) + 9; 
         continue; 
      } 

      errno = EINVAL; 
      return 0; 
   } 

   return val; 
}
bool  ValidateIpv4(char *p_ipadd)
{
   unsigned b1, b2, b3, b4;
   unsigned char c;
   if (sscanf(p_ipadd, "%3u.%3u.%3u.%3u%c", &b1, &b2, &b3, &b4, &c) != 4)
      return false;
   if ((b1 | b2 | b3 | b4) > 255) return  false;

   if (strspn(p_ipadd, "0123456789.") < strlen(p_ipadd)) return 0;
   return true;

}
void convertIPV4toHex(char * apIPv4Addr,unsigned char *apAddrInHex)
{
   char *pch=NULL;
   pch=strtok(apIPv4Addr,".");
   apAddrInHex[0]=atoi(pch);

   pch= strtok (NULL, ".");
   apAddrInHex[1]=atoi(pch);

   pch= strtok (NULL, ".");
   apAddrInHex[2]=atoi(pch);

   apAddrInHex[3]=atoi((pch+strlen(pch)+1));
}


/*****************************************************************************
 ** FUNCTION NAME  : checkValidBCDDigit
 **
 ** DEFINITON      : Checks whether a character is a valid BCD digit
 **
 ** ARGUMENTS      : c(in) -> The character to be checked for validity
 **
 ** RETURN         : true if valid BCD digit
 **                  false otherwise
 **
 ** REMARKS        :
 *****************************************************************************/
bool checkValidBCDDigit(u8 c)
{
   try
   {
      //if (((c >= 0) && (c <= 9)) || ((c == 0xF)))
      if (((c <= 9)) || ((c == 0xF)))
      {
         return true;
      }
   }
   catch(...)
   {
      //g_LoggerObj.log(LOG_LEVEL_CRITICAL, "%s<Ln: %d> Exception occured.", __FUNCTION__, __LINE__);
   }
   return false;
}

/*****************************************************************************
 ** FUNCTION NAME  : BCDToNum
 **
 ** DEFINITON      : Converts BCD encoded string to numeric string
 **                : It will convert 4 bits as a single numeric string
 **                : for ex. 10010011 will be 3 and 9 as 2 separte digits.   
 ** ARGUMENTS      : none
 **
 ** RETURN         : false in case of some error
 **                  true if successfully decoded
 **
 ** REMARKS        : This function also sets the length of the encoded string
 *****************************************************************************/
int BCDToNum(u8 *m_bcdStr, u8 *m_numStr, u16 m_bcdStrLength)
{
   u16 m_numStrLength = 0;
   try
   {
      u8 c;
      //if ((m_bcdStrLength > MAX_BCD_STR_LEN) || (!m_bcdStrLength))
      //if (!m_bcdStrLength)		
      if (m_bcdStrLength <= 0)		
      {
         //g_LoggerObj.log(LOG_LEVEL_WARNING, "%s<Ln: %d> Invalid BCD string length %d", __FUNCTION__, __LINE__, m_bcdStrLength);
         return -1;
      }

      for (int i = 0; i<m_bcdStrLength; i++)
      {
         c = m_bcdStr[i] & 0x0F;
         if (!checkValidBCDDigit(c))
         {
            //g_LoggerObj.log(LOG_LEVEL_WARNING, "%s<Ln: %d> Invalid input BCD string", __FUNCTION__, __LINE__);
            return -1;
         }
         m_numStr[i*2] = c + '0';

         c = (m_bcdStr[i] & 0xF0) >> 4;
         if (!checkValidBCDDigit(c))
         {
            //g_LoggerObj.log(LOG_LEVEL_WARNING, "%s<Ln: %d> Invalid input BCD string", __FUNCTION__, __LINE__);
            return -1;
         }
         m_numStr[i*2 + 1] = c + '0';
      }

      m_numStrLength = 2*m_bcdStrLength;

      // check whether last BCD octet contains filler
      if ((m_bcdStr[m_bcdStrLength-1] & 0xF0) == 0xF0)
      {
         m_numStrLength--;
      }
      // null terminate the string
      m_numStr[m_numStrLength] = 0;
   }
   catch(...)
   {
      //g_LoggerObj.log(LOG_LEVEL_CRITICAL, "%s<Ln: %d> Exception occured.", __FUNCTION__, __LINE__);
      return -1;
   }
   return m_numStrLength;
}

/*****************************************************************************
 ** FUNCTION NAME  : BCDToWholeNum
 **
 ** DEFINITON      : Converts BCD encoded string to numeric string
 **                : It will convert 4 bits as a single numeric string and and makes a decimal 
 **                : single digit by adding these 2 digits  
 **                : for ex. 10010011 will be first converts as 9 and 3 and makes a single 
 **                : whole decimal number like 93.   nd input will be 8 bits at a time
 ** ARGUMENTS      : none
 **
 ** RETURN         : false in case of some error
 **                  true if successfully decoded
 **
 ** REMARKS        : This function also sets the length of the encoded string
 *****************************************************************************/
int BCDToWholeNum(u8 m_bcdStr, u8 *m_numStr)
{
   //u16 m_numStrLength=0;
   try
   {
      u8 c;

      c = m_bcdStr & 0x0F;
      if (!checkValidBCDDigit(c))
      {
         //g_LoggerObj.log(LOG_LEVEL_WARNING, "%s<Ln: %d> Invalid input BCD string", __FUNCTION__, __LINE__);
         return -1;
      }
      *m_numStr = c;

      c = (m_bcdStr & 0xF0) >> 4;
      if (!checkValidBCDDigit(c))
      {
         //g_LoggerObj.log(LOG_LEVEL_WARNING, "%s<Ln: %d> Invalid input BCD string", __FUNCTION__, __LINE__);
         return -1;
      }
      c*=10; //Add 10th Position ex if 9 it will be 90 (decimal)
      *m_numStr+=c;	

   }
   catch(...)
   {
      //g_LoggerObj.log(LOG_LEVEL_WARNING, "%s<Ln: %d> Exception occured.", __FUNCTION__, __LINE__);
      return -1;
   }
   return 0;
}

/*****************************************************************************
 ** FUNCTION NAME  : numToBCD
 **
 ** DEFINITON      : Converts numeric string to BCD encoded string
 **                : It will take 2 digits(0 to 9) and makes 1 8 bit BCD
 **                : Ex: i/p 3,9(two digits-hex) makes 10010011
 ** ARGUMENTS      : none
 **
 ** RETURN         : false in case of some error
 **                  true if successfully decoded
 **
 ** REMARKS        : This function also sets the length of the encoded string
 *****************************************************************************/
int numToBCD(u8 *m_numStr, u8 *m_bcdStr, u8 m_numStrLength)
{
   try
   {
      u16 m_bcdStrLength=0;
      if (!m_numStrLength)
      {
         //g_LoggerObj.log(LOG_LEVEL_WARNING, "%s<Ln: %d> Invalid Numeric string length %d", __FUNCTION__, __LINE__, m_numStrLength);
         return false;
      }

      for (int i=0; i<m_numStrLength/2; i++)
      {
         if (!checkValidBCDDigit(m_numStr[i*2] - '0'))
         {
            // g_LoggerObj.log(LOG_LEVEL_WARNING, "%s<Ln: %d> Invalid input Numeric string", __FUNCTION__, __LINE__);
            return false;
         }

         m_bcdStr[i] = m_numStr[i*2] & 0x0F;

         if (!checkValidBCDDigit(m_numStr[i*2+1] - '0'))
         {
            //g_LoggerObj.log(LOG_LEVEL_WARNING, "%s<Ln: %d> Invalid input Numeric string", __FUNCTION__, __LINE__);
            return false;
         }

         m_bcdStr[i] |= (m_numStr[i*2+1] & 0x0F) << 4;
      }

      m_bcdStrLength = m_numStrLength/2;
      // Check whether filler is required
      if (m_numStrLength % 2)
      {
         m_bcdStr[m_bcdStrLength] = m_numStr[m_numStrLength - 1] & 0x0F;
         m_bcdStr[m_bcdStrLength] |= 0xF0;
         m_bcdStrLength++;
      }
      // null terminate the string
      m_bcdStr[m_bcdStrLength] = 0;
   }
   catch(...)
   {
      //g_LoggerObj.log(LOG_LEVEL_CRITICAL, "%s<Ln: %d> Exception occured.", __FUNCTION__, __LINE__);
      return false;
   }
   return true;
}

/*****************************************************************************
 ** FUNCTION NAME  : numToBCD
 **
 ** DEFINITON      : Converts numeric string to BCD encoded string
 **                : It will take 1(00 to 99 decimal) digit and makes 1 8 bit BCD
 **                : ex: i/p 93(decimal hex 5D- 01011101) makes 10010011
 ** ARGUMENTS      : none
 **
 ** RETURN         : false in case of some error
 **                  true if successfully decoded
 **
 ** REMARKS        : This function also sets the length of the encoded string
 *****************************************************************************/
int WholeNumToBCD(u8 m_numStr, u8 *m_bcdStr)
{
   try
   {
      u8 c;
      c=m_numStr%10;
      if (!checkValidBCDDigit(c))
      {
         //g_LoggerObj.log(LOG_LEVEL_WARNING, "%s<Ln: %d> Invalid input Numeric string", __FUNCTION__, __LINE__);
         return false;
      }

      *m_bcdStr = c & 0x0F;

      m_numStr/=10;
      c=m_numStr%10;
      if (!checkValidBCDDigit(c))
      {
         //g_LoggerObj.log(LOG_LEVEL_WARNING, "%s<Ln: %d> Invalid input Numeric string", __FUNCTION__, __LINE__);
         return false;
      }

      *m_bcdStr |= (c & 0x0F) << 4;

   }
   catch(...)
   {
      //g_LoggerObj.log(LOG_LEVEL_CRITICAL, "%s<Ln: %d> Exception occured.", __FUNCTION__, __LINE__);
      return false;
   }
   return true;
}

/**************************************************************
 * Name             :  bcdtostring
 * Input Parameters :  char *str,char *bcd,int lengthofBCD
 * Return Type      :  none
 * Purpose          :  To change into string from BCD
 * **************************************************************/
void BCDToString(u8 *str, u8 *bcd, int bcdLen)
{
   for(int count=0, j=0; count<bcdLen; count++, j+=2)
   {
      str[j] = ((bcd[count])&(0x0F)) + '0';
      str[j+1] = ((bcd[count]&0xF0)>>4) + '0';

      //if(  (count == (bcdLen-1)) && ( ((bcd[count]&0xF0) == 0xF0) || ((bcd[count]&0xC0) == 0xC0) || ((bcd[count]&0xFC) == 0xFC) ) )
      if(((count == (bcdLen-1)) && (bcd[count]&0xF0) == 0xF0))
         str[j+1] = '\0';
      else if(count == (bcdLen-1))
         str[j+2] = '\0';
   }
}

/**************************************************************
 * Name             :  StringToBCD
 * Input Parameters :  char *bcd,char *str,int lenOfString
 * Return Type      :  none
 * Purpose          :  To change into string from BCD
 * **************************************************************/
#if 0
void StringToBCD(u8 *dest,u8 *src, int length)
{
   int i, j;
   for(i = 0, j = 0; j < length; i++)
   {
      dest[i]= src[j]-'0';

      if((length == (j+1)) && length%2)
         dest[i] |= 0xF0;
      else
         dest[i] |= ((src[j+1]-'0')<<4);
      j += 2;
   }
}
#else
void StringToBCD(u8 * dest,u8 * src, s32 length)
{
   s8 temp;

   for(int i=0;i<length;i++)
   {
      switch(src[i])
      {
         case '#':
            temp=0x0C;
            break;
         case '*':
            temp=0x0B;
            break;
         case 0:
            temp=0x0E;
            break;
         case 'A':
         case 'B':
         case 'C':
         case 'D':
         case 'E':
         case 'F':
            temp=src[i]-55;
            break;
         default:
            temp=src[i]-'0';
            break;
      }
      if(i%2==0)
         dest[i/2]=temp;
      else
         dest[i/2]|=(temp<<4);
   }
   if(length%2)
      dest[length/2]= dest[length/2] & 0x0F;
}
#endif

/**************************************************************
Name             :  BCDToString
Input Parameters :  U8 *str, U8 *bcd, S32 i
Return Type      :  none
Purpose          :  To change into string from BCD
 **************************************************************/
void BCDToString(u8 *str, u8 *bcd, s32 i, bool oddEven)
{
   int count, j;
   for(count=0,j=0;count<i;count++,j=j+2)
   {
      str[j] = ((bcd[count])&(0x0F)) + '0';
      str[j+1] = ((bcd[count]&0xF0)>>4) + '0';

      if(((count == (i-1)) && (bcd[count]&0xF0) == 0xF0))
         str[j+1] = '\0';
      else if(count == (i-1))
         str[j+2] = '\0';
   }
   i *= 2;
   if(oddEven)
      i--;
   str[i] = '\0';

   for(count = 0; count < j; count++)
   {
      if((0x39 < str[count]) || (0x30 > str[count]))
         str[count] = '\0';
   }
   //printf("Inside bcdToString: count : %d str : %s\n", count, str);
}

#if 0
/**************************************************************
Name             :  StringToBCD
Input Parameters :  U8 *dest, U8 *src, S32 length
Return Type      :  none
Purpose          :  To change into string from BCD
 **************************************************************/
void StringToBCD(u8 *dest, u8 *src, s32 length)
{
   int i, j;
   //printf("STRING: %s Length: %d\n", src, length);

   for(i = 0, j = 0; j < length; i++)
   {
      dest[i]= src[j]-'0';
      //printf("dest[%d]: %x\n", i, dest[i]);

      if((length == (j+1)) && length%2)
         dest[i] |= 0xF0;
      else
         dest[i] |= ((src[j+1]-'0')<<4);
      j += 2;
   }
}
#endif



/**************************************************************
Name             :  ConvertInto8Bit
Input Parameters :  
Return Type      :  
Purpose          :  
 **************************************************************/
bool ConvertInto8Bit(unsigned char *source, unsigned char *dest, int len)
{
   int temp = 0;
   int count = 0;
   for(int i= 0, j=0; i < len+1 ; i++, j++)
   {
      if((i % 8) == 0)
      {
         count = 0;
         if(j > 1)
         {
            dest[j] = source[i-1] & 0x7f;
            len -=8;
            if(len)
            {
               source = source+7;
               i = 0;
            }
         }
         else
         {
            dest[j] = (source[i] << (count+1));
            dest[j] = dest[j] >> (count+1);
         }
      }
      else
      {
         dest[j] = source[i] << (count+1);
         dest[j] = ((dest[j] >> (count+1))) << (i%7);
         temp  = (source[i-1] >> (8-count));
         dest[j] |= temp;
      }
      count++;
   }
   return true;
}
