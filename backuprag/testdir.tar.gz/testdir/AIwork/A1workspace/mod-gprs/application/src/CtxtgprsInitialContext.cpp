#include <CtxtSendRoutingInfoGprs.h>
#include <ModuleBase.h>
#include <stdio.h>
#include <MapMessages.h>
#include <Logger.h>
#include <CtxtFailureReport.h>
#include <CtxtNoteMsPresentGprs.h>
#include <GprsConfigReader.h>
#include <DiameterMessages.h>
#include <DiameterConstants.h>

#include <ExtendedServiceCoordinator.h>

extern "C" {
   ModuleBase *getModuleObj();
}


class GprsModule : public ModuleBase
{
   public:
      bool initModule();
      ContextBase *getCtxtObj(EMapOpCode, MapSpecificMsg*);
      ContextBase *getCtxtObj(EDiameterCommandCode, DiameterMsg* );
      ContextBase *getCtxtObj(EMapOpCode, SccpMsg*);
      char *getVersion();
      ConfigReader *getConfigReaderObj();
      ConfigReader **retrieveConfigReaderPtr();
};

GprsModule g_GprsModule;

ModuleBase *getModuleObj()
{
   return &g_GprsModule;
}

char * GprsModule::getVersion()
{
   RETURN_VERSION (APP_VERSION);//2.0.16.0_Rev2 2.0.15.0//base is "2.0.0.0" //1.0.8.0 Rev2
}
bool GprsModule::initModule()
{
   m_modName="GPR";
   LLOG(0,0,"GPR APPVER-v:%s ci:%s cd:%s comp:%s %s", APP_VERSION, COMMIT_ID, COMMIT_DATE,__DATE__,__TIME__);

#if 0 
   if (false == g_GprsConfigReaderObj->m_derivedObjectInitializedFlag)
   {
      printf("\nERROR: GPRS specific configuration file reading is mandatory");
      return false;
   }
#endif

   return true;
}
ContextBase *GprsModule::getCtxtObj(EDiameterCommandCode p_ccCode, DiameterMsg *p_msg)
{
   ELOG(0,0,"Diameter Message not supported");
      return NULL;
}
ContextBase *GprsModule::getCtxtObj(EMapOpCode p_opcode, MapSpecificMsg *p_msg)
{
   switch(p_opcode)
   {
      case MAP_OP_CODE_sendRoutingInfoForGprs:
         {
            LLOG(0,0,"Newing CtxtSendRoutingInfoGprs");
            return new CtxtSendRoutingInfoGprs();
         }
         break;
      case MAP_OP_CODE_failureReport:
         {
            LLOG(0,0,"Newing CtxtFailureReport");
            return new CtxtFailureReport();
         }
         break;
      case MAP_OP_CODE_noteMsPresentForGprs:
         {
            LLOG(0,0,"Newing CtxtNoteMsPresentGprs");
            return new CtxtNoteMsPresentGprs();
         }
         break;
      default: 
         ELOG(0,0,"Newing Defualt Could not Create");
         return NULL;
   }
}

ContextBase *GprsModule::getCtxtObj(EMapOpCode p_OpCode, SccpMsg* p_msg)
{
   ELOG(0,0,"SCCP message not supported");
   return NULL;
}

ConfigReader *GprsModule::getConfigReaderObj()
{
   LLOG(0,0,"Returning g_GprsConfigReaderObj");
   //return (g_GprsConfigReaderObj = new GprsConfigReader);
   return new GprsConfigReader;
}
ConfigReader **GprsModule::retrieveConfigReaderPtr()
{
   LLOG(0,0,"ConfigReader **SiModule::retrieveConfigReaderPtr() called");
   return (ConfigReader **)&g_GprsConfigReaderObj;
}
bool resetStruct(int p_version, int p_pdu, void *p_struct)
{
   return false;
}
