#include "CtxtFailureReport.h"
#include <stdio.h>
#include <MapMessages.h>
#include <ServiceCoordinator.h>
#include <Logger.h>
#include <IMAP3.h>
#include <OMAP3.h>
#include <GprsDbQueries.h>
#include <DbActiveObject.h>
#include <ConfigReader.h>
#include <CtxtSendRoutingInfoGprs.h>
#include <DataUnion.h>
#include "Utilities.h"
#include "CtxtNoteMsPresentGprs.h"
#include <GprsConfigReader.h>
#include <HlrTdrFiller.h>


CtxtFailureReport::CtxtFailureReport()
{
   DLOG(0,0,"CtxtFailureReport::CtxtFailureReport()");
   m_MapVesion=MAP_V_UNKNOWN;
   m_MsgSpecificMsgInd=NULL;
   m_FRdlgId=0;
   m_ptrfailreport = new FailureReportData();
}

CtxtFailureReport::~CtxtFailureReport()
{
   DLOG(0,0,"CtxtFailureReport::~CtxtFailureReport()");
   if(m_ptrfailreport)
   {
      delete m_ptrfailreport;
      m_ptrfailreport=NULL;
   }
   if(m_MsgSpecificMsgInd)
   {
      delete m_MsgSpecificMsgInd;
      m_MsgSpecificMsgInd=NULL;
   }


}
bool CtxtFailureReport::sendErrorResponse(EMapErrorCode p_ErrorCode)
{
   m_tdr.setInteger(TDR_INDEX_ERR_CODE,(ETdrErrorCode)p_ErrorCode);
   LLOG(0,0,"Sending error  Response towards GGSN");
   int l_UserDlgId=m_FRdlgId;
   switch(p_ErrorCode)
   {
      case MAP_ERROR_unknownSubscriber:
         {
            OMAP3_UnknownSubscriberParam l_UnknowSub;
            memset(&l_UnknowSub,'\0',sizeof(OMAP3_UnknownSubscriberParam));
            l_UnknowSub.bit_mask |= OMAP3_unknownSubscriberDiagnostic_present;
            l_UnknowSub.unknownSubscriberDiagnostic=OMAP3_gprsSubscriptionUnknown;
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_unknownSubscriber, MAP_V3, (void*)&l_UnknowSub);
            g_sc.sendMsg(this, &l_userError);
            ELOG(0,0,"Sending User Error with MAP_ERROR_unknownSubscriber dlgId %d",l_UserDlgId);
         }
         break;
      case MAP_ERROR_unexpectedData:
         { 
            OMAP3_UnexpectedDataParam l_UnexpectedData;
            memset(&l_UnexpectedData,'\0',sizeof(OMAP3_UnexpectedDataParam));
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_unexpectedData, MAP_V3, &l_UnexpectedData);
            g_sc.sendMsg(this, &l_userError);
            ELOG(0,0,"Sending User Error with MAP_ERROR_unexpectedData dlgId %d",l_UserDlgId);
         }
         break;
      case MAP_ERROR_dataMissing:
         {
            OMAP3_DataMissingParam l_DataMissing;
            memset(&l_DataMissing,'\0',sizeof(OMAP3_DataMissingParam));
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_dataMissing, MAP_V3, &l_DataMissing);
            g_sc.sendMsg(this, &l_userError);
            ELOG(0,0,"Sending User Error with MAP_ERROR_dataMissing dlgId %d",l_UserDlgId);
         }
         break;
      case MAP_ERROR_systemFailure:
         {
            OMAP3_SystemFailureParam l_systemFail;
            memset(&l_systemFail,'\0',sizeof(OMAP3_SystemFailureParam));
            l_systemFail.choice = OMAP3_networkResource_chosen;
            l_systemFail.u.networkResource=OMAP3_NetworkResource_vlr;
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_systemFailure, MAP_V3, &l_systemFail);
            g_sc.sendMsg(this, &l_userError);
            ELOG(0,0,"Sending User Error with MAP_ERROR_systemFailure dlgId %d ",l_UserDlgId);
         }
         break;
      default :
         printf("Error code could not handle :%d]\n",p_ErrorCode);
         CLOG(0,0,"It is default Error code could not handle dlgId %d ",l_UserDlgId);

   }

   DLOG(0,0,"Closing the Dialogue");
   MapCloseReq l_closeReq(l_UserDlgId);
   g_sc.sendMsg(this, &l_closeReq);

   return true;
}

/*void CtxtFailureReport::convertIPV4toHex(char * apIPv4Addr,unsigned char *apAddrInHex)
  {
  char *pch=NULL;

  pch=strtok(apIPv4Addr,".");
  apAddrInHex[0]=atoi(pch);

  pch= strtok (NULL, ".");
  apAddrInHex[1]=atoi(pch);

  pch= strtok (NULL, ".");
  apAddrInHex[2]=atoi(pch);

  apAddrInHex[3]=atoi((pch+strlen(pch)+1));

  }*/

bool CtxtFailureReport::sendFailureReportResp()
{
   LLOG(0,0,"Sending sendFailureReportResp Success towards GGSN Address %s DlgId %d",m_ptrfailreport->m_InGGSNAddress,m_FRdlgId);
   int l_UserDlgId=m_FRdlgId;
   DECLARE(OMAP3_FailureReportRes,l_SRIResp,3,"OMAP3_FailureReportRes",resetStruct);
   int l_len = strlen(m_ptrfailreport->m_InGGSNAddress);
   //printf("strlen(m_ptrfailreport->m_InGGSNAddress) %d \n",l_len);
   //if(strlen(m_ptrfailreport->m_InGGSNAddress) > 0)
   if(true == ValidateIpv4(m_ptrfailreport->m_InGGSNAddress))
   {
      LLOG(0,0,"Failure Report  Response towards GGSN Address %s DlgId %d",m_ptrfailreport->m_InGGSNAddress,m_FRdlgId);
      l_SRIResp->bit_mask |= OMAP3_FailureReportRes_ggsn_Address_present;
      l_SRIResp->ggsn_Address.length=5;
      l_SRIResp->ggsn_Address.value[0]=0x04;
      convertIPV4toHex(m_ptrfailreport->m_InGGSNAddress,&l_SRIResp->ggsn_Address.value[1]);
   }

   MapSpecificResult l_result(l_UserDlgId,MAP_OP_CODE_failureReport,MAP_V3);
   l_result.m_structBuffer = (void*)l_SRIResp;
   g_sc.sendMsg(this, &l_result);
   DLOG(0,0,"Closing the Dialogue");
   MapCloseReq l_closeReq(l_UserDlgId);
   g_sc.sendMsg(this, &l_closeReq);
   //Test
   //g_sc.initiateIndependentContext(this, MAP_OP_CODE_noteMsPresentForGprs, m_ptrfailreport->m_InIMSI);

   return true;
}
bool CtxtFailureReport::handleFailtureReport(Msg *p_MsgPtr)
{
   DLOG(0,0,"HandleFailtureReport Started executed");
   m_MapVesion=((MapSpecificMsg*)p_MsgPtr)->m_Version;
   switch (m_MapVesion)
   {
      case 1:
         break;
      case 2:
         break;
      case 3:
         {
            IMAP3_FailureReportArg *l_temp = (IMAP3_FailureReportArg*)(((MapSpecificMsg*)p_MsgPtr)->m_structBuffer);

            // int l_UserDlgId = p_MsgPtr->m_UserDlgId;
            int l_UserDlgId = m_FRdlgId;

            BCDToString((u8*)m_ptrfailreport->m_InIMSI, l_temp->imsi.value,l_temp->imsi.length);
            LLOG(0,0,"FailureReport Received on IMSI %s On DlgId %d",m_ptrfailreport->m_InIMSI,m_FRdlgId);
            setTraceImsi(m_ptrfailreport->m_InIMSI);// Set IMSI for Tracing 
            m_tdr.setChar(TDR_INDEX_REQUEST_TYPE,'I');
            m_tdr.setString(TDR_INDEX_REQUEST_IMSI,m_ptrfailreport->m_InIMSI);
            if(strlen(m_ptrfailreport->m_InIMSI) < 15 )//Data Missing
            {
               ELOG(0,0,"FailureReport Received on IMSI %s On DlgId %d less than 15",m_ptrfailreport->m_InIMSI,m_FRdlgId);
               sendErrorResponse(MAP_ERROR_unexpectedData);
               return false ;
            }
            m_ptrfailreport->m_UserDlgId = l_UserDlgId;
            if(l_temp->bit_mask & IMAP3_FailureReportArg_ggsn_Address_present)
            {
               char l_ggsn[15];
               memset(l_ggsn,'\0',sizeof(l_ggsn));
               if( 0x04 == l_temp->ggsn_Address.value[0])
               {
                  sprintf(l_ggsn,"%d.%d.%d.%d",l_temp->ggsn_Address.value[1],l_temp->ggsn_Address.value[2],l_temp->ggsn_Address.value[3],l_temp->ggsn_Address.value[4]);
                  strcpy(m_ptrfailreport->m_InGGSNAddress,l_ggsn);
                  LLOG(0,0,"Failure Report Received on GGSN Address %s DlgId %d ",m_ptrfailreport->m_InGGSNAddress,m_FRdlgId);
               }
               if(strlen(m_ptrfailreport->m_InGGSNAddress) <= 0) // Data Missing
               {
                  LLOG(0,0,"Sending User Error on dlgId GGSN Address is Zero%d",m_FRdlgId);
                  sendErrorResponse(MAP_ERROR_dataMissing);
                  return false;
               }
               m_tdr.setString(TDR_INDEX_GGSN_IP_ADDRESS,m_ptrfailreport->m_InGGSNAddress);
            }
            BCDToString((u8*)m_ptrfailreport->m_InGGSNNumber, l_temp->ggsn_Number.value+1,l_temp->ggsn_Number.length-1);
            LLOG(0,0,"Failure Report Received on GGSN Number %s DlgId %d",m_ptrfailreport->m_InGGSNNumber,m_FRdlgId);
            if(strlen(m_ptrfailreport->m_InGGSNNumber) <= 0)// Data Missing
            {
               DLOG(0,0,"Sending MAP_ERROR_dataMissing GGSN Number is Zero len");
               sendErrorResponse(MAP_ERROR_dataMissing);
               return false ;
            }
            m_tdr.setString(TDR_INDEX_GGSN_ADDRESS,m_ptrfailreport->m_InGGSNNumber);
            //printf("mp_routingInfoData->m_InGGSNNumber%s\n",m_ptrfailreport->m_InGGSNNumber);
            m_ptrfailreport->m_cb = this;
            g_act.execute(m_ptrfailreport);
         }
         break;
      default:
         printf("MAP version is the Unknown ...........\n");
   }

   return true;

}

bool CtxtFailureReport::processMessage(Msg *p_MsgPtr,bool& p_DeleteFlag)
{
   DLOG(0,0,"Start of CtxtFailureReport::processMsg function");
   MapSpecificMsg *l_specMsg = NULL;
   int l_dlgId=0;
   int l_UserDlgId=0;

   switch (p_MsgPtr->m_MsgType)
   {
      case MSG_TYPE_MAP:
         switch (((MapMsg*)p_MsgPtr)->m_MapMsgType)
         {
            case MAP_MSG_TYPE_COMMON:
               switch (((MapCommonMsg*)p_MsgPtr)->m_MapCommonMsgType)
               {
                  case MAP_CMN_OPEN_IND:
                     DLOG(0,0,"MAP_CMN_OPEN_IND received");
                     break;

                  case MAP_CMN_DELIMITER_IND:
                     DLOG(0,0,"MAP_CMN_DELIMITER_IND received");
                     break;

                  case MAP_CMN_CLOSE_IND:
                     DLOG(0,0,"MAP_CMN_CLOSE_IND received");
                     //printf("\nGot a Close. Call flow success.\n");
                     return true;
                     break;

                  case MAP_CMN_U_ABORT_IND:
                     ELOG(0,0,"MAP_CMN_U_ABORT_IND received");
                     sendErrorResponse(MAP_ERROR_systemFailure);
                     break;

                  case MAP_CMN_P_ABORT_IND:
                     ELOG(0,0,"MAP_CMN_P_ABORT_IND received");
                     sendErrorResponse(MAP_ERROR_systemFailure);
                     break;

                  case MAP_CMN_NOTICE_IND:
                     {
                        ELOG(0,0,"MAP_CMN_NOTICE_IND received");
                        DLOG(0,0,"Closing the Dialogue");
                        sendErrorResponse(MAP_ERROR_systemFailure);
                     }
                     break;

                  default:
                     CLOG(0,0,"Unknown Msg received [%d]", ((MapCommonMsg*)p_MsgPtr)->m_MapCommonMsgType);
                     break;
               }
               break;

            case MAP_MSG_TYPE_SPECIFIC:
               l_specMsg = (MapSpecificMsg*)p_MsgPtr;
               l_UserDlgId = l_specMsg->m_UserDlgId;
               DLOG(0,0,"MAP_MSG_TYPE_SPECIFIC received dlgId[%d] UserDlgId[%d]",
                     l_dlgId, l_UserDlgId);

               switch (((MapSpecificMsg*)p_MsgPtr)->m_MapSpecificEventType)
               {
                  case MAP_SPEC_EVENT_INDICATION:
                     {
                        DLOG(0,0,"MAP_SPEC_EVENT_INDICATION received");
                        l_UserDlgId = p_MsgPtr->m_UserDlgId;

                        switch (((MapSpecificMsg*)p_MsgPtr)->m_OpCode)
                        {
                           case MAP_OP_CODE_failureReport :
                              {
                                 LLOG(0,0,"Received Failure Report ");
                                 m_MsgSpecificMsgInd=(MapSpecificIndication*)p_MsgPtr;
                                 if (false == ((MapSpecificMsg*)p_MsgPtr)->m_allocatedFlag)
                                 {
                                    CLOG(0,0,"GPRS module Received on FR DlgId with NuLL buffer%d ",l_UserDlgId);
                                    sendErrorResponse(MAP_ERROR_unexpectedData);
                                    return false;
                                 }

                                 p_DeleteFlag=false;
                                 m_FRdlgId=l_UserDlgId;
                                 handleFailtureReport(p_MsgPtr);
                              }
                              break;

                           default:
                              DLOG(0,0,"Received Unknown Specific Message");
                              break;

                        }


                        //return true;
                     }

                     break;

                  case MAP_SPEC_EVENT_RESULT:
                     {
                        DLOG(0,0,"MAP_SPEC_EVENT_RESULT received");
                     }
                     break;

                  case MAP_SPEC_EVENT_CONFIRMATION:
                     {
                        DLOG(0,0,"MAP_SPEC_EVENT_CONFIRMATION received");
                        switch (((MapSpecificMsg*)p_MsgPtr)->m_OpCode)
                        {
                           break;
                           default:
                           break;

                        }
                     }
                     break;

                  case MAP_SPEC_EVENT_USER_ERROR:
                     {
                        ELOG(0,0,"MAP_SPEC_EVENT_USER_ERROR received");
                     }
                     break;

                  case MAP_SPEC_EVENT_PROV_ERROR:
                     {
                        ELOG(0,0,"MAP_SPEC_EVENT_PROV_ERROR received");
                        DLOG(0,0,"Closing the Dialogue");
                        sendErrorResponse(MAP_ERROR_systemFailure);
                        /*MapCloseReq l_closeReq(((MapSpecificMsg*)p_MsgPtr)->m_UserDlgId);
                          g_sc.sendMsg(this, &l_closeReq);*/
                     }
                     break;
                  default:
                     ELOG(0,0,"ERROR!! Default received");
                     break;
               }

               break;

            default:
               break;
         }
         break;

      case MSG_TYPE_DB:
         {
            DLOG(0,0,"DB message received");

            handleDBResponse(p_MsgPtr,p_DeleteFlag);
            p_DeleteFlag=false;
            break;
            default:
            DLOG(0,0,"Unknown message received");
            break;
         }

   }
   return true;
}


bool CtxtFailureReport::handleDBResponse(Msg *p_MsgPtr,bool& p_DeleteFlag)
{
   //printf("Application got DB response \n");

   if(m_ptrfailreport->m_DbQueryRes != DB_QUERY_RES_SUCCESS)
   {
      ELOG(0,0,"HandleDBResponse Database return Error code %d",m_ptrfailreport->m_ErrorCode);
      switch(m_ptrfailreport->m_ErrorCode)
      {
         case 1:
            {
               ELOG(0,0,"HandleDBResponse Failure Report with Unknown Subscriber in DlgId %d", m_FRdlgId);
               sendErrorResponse(MAP_ERROR_unknownSubscriber);
               return false;
            }
         case 2:
            {
               ELOG(0,0,"HandleDBResponse Failure Report with Stsyem Failure in DlgId %d", m_FRdlgId);
               sendErrorResponse(MAP_ERROR_systemFailure);
               return false;
            }
         default:
            {
               printf("Application Could not handle the error code %d\n",m_ptrfailreport->m_ErrorCode);
               CLOG(0,0,"handleDBResponse with error code %d in DlgId %d",m_ptrfailreport->m_ErrorCode, m_FRdlgId);
               return false;
            }
      }
   }
   else
   {
      if(strlen(m_ptrfailreport->m_OutHLRAddress) <= 0)
      {
         ELOG(0,0,"HandleDBResponse Failure Report with Stsyem Failure in DlgId %d", m_FRdlgId);
         sendErrorResponse(MAP_ERROR_systemFailure);
         return false;
      }
      LLOG(0,0,"Failure Report response with originating HLR address %s",m_ptrfailreport->m_OutHLRAddress);

      sendMapOpenResponse(m_FRdlgId,m_ptrfailreport->m_OutHLRAddress,g_GprsConfigReaderObj->m_HLRSSN);// Release 
      m_tdr.setString(TDR_INDEX_LOCAL_ADDRESS,m_ptrfailreport->m_OutHLRAddress);
      LLOG(0,0,"Database return Success Error Code %d",m_ptrfailreport->m_ErrorCode);
      sendFailureReportResp();
   }
   return true;
}
