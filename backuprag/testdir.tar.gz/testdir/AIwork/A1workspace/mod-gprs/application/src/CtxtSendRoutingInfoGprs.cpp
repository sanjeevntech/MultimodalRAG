#include <CtxtSendRoutingInfoGprs.h>
#include <stdio.h>
#include <MapMessages.h>
#include <ServiceCoordinator.h>
#include <Logger.h>
#include <IMAP3.h>
#include <OMAP3.h>
#include <GprsDbQueries.h>
#include <DbActiveObject.h>
#include <ConfigReader.h>
#include <string.h>
#include <DataUnion.h>
#include "Utilities.h"
#include <GprsConfigReader.h>
#include <HlrTdrFiller.h>
//extern  GprsConfigReader g_GprsConfigReaderObj;

CtxtSendRoutingInfoGprs::CtxtSendRoutingInfoGprs():m_SRIdlgId(0)
{
   DLOG(0,0,"CtxtSendRoutingInfoGprs::CtxtSendRoutingInfoGprs()");
   m_ErrorInd=false;
   m_MapVesion=MAP_V_UNKNOWN;

   m_MsgSpecificMsgInd=NULL;
   mp_routingInfoData = new SendRoutingInfoData(); 
}

CtxtSendRoutingInfoGprs::~CtxtSendRoutingInfoGprs()
{
   DLOG(0,0,"CtxtSendRoutingInfoGprs::~CtxtSendRoutingInfoGprs()");
   if(mp_routingInfoData)
   {
      delete mp_routingInfoData;
      mp_routingInfoData=NULL;
   }
   if(m_MsgSpecificMsgInd)
   {
      delete m_MsgSpecificMsgInd;
      m_MsgSpecificMsgInd=NULL;
   }

}
bool CtxtSendRoutingInfoGprs::sendErrorResponse(EMapErrorCode p_ErrorCode,EMapVersion p_MapVer)
{
   m_tdr.setInteger(TDR_INDEX_ERR_CODE,(ETdrErrorCode)p_ErrorCode);
   LLOG(0,0,"Insite the Send Error Response");
   int l_UserDlgId=m_SRIdlgId;
   switch(p_ErrorCode)
   {
      case MAP_ERROR_unknownSubscriber:
         {
            OMAP3_UnknownSubscriberParam l_UnknowSub;
            memset(&l_UnknowSub,'\0',sizeof(OMAP3_UnknownSubscriberParam));
            l_UnknowSub.bit_mask |= OMAP3_unknownSubscriberDiagnostic_present;
            l_UnknowSub.unknownSubscriberDiagnostic=OMAP3_gprsSubscriptionUnknown;
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_unknownSubscriber, MAP_V3, (void*)&l_UnknowSub);
            g_sc.sendMsg(this, &l_userError);
            ELOG(0,0,"Sending User Error with MAP_ERROR_unknownSubscriber");
         }
         break;
      case MAP_ERROR_absentSubscriber:
         {
            OMAP3_AbsentSubscriberParam l_AbsentSub;
            memset(&l_AbsentSub,'\0',sizeof(OMAP3_AbsentSubscriberParam));
            l_AbsentSub.bit_mask |= OMAP3_absentSubscriberReason_present;
            l_AbsentSub.absentSubscriberReason=OMAP3_AbsentSubscriberReason_restrictedArea;
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_absentSubscriber, MAP_V3, &l_AbsentSub);
            g_sc.sendMsg(this, &l_userError);
            ELOG(0,0,"Sending User Error with MAP_ERROR_absentSubscriber");

         }
         break;
      case MAP_ERROR_systemFailure:
         {
            OMAP3_SystemFailureParam l_systemFail;
            memset(&l_systemFail,'\0',sizeof(OMAP3_SystemFailureParam));
            l_systemFail.choice = OMAP3_networkResource_chosen;
            l_systemFail.u.networkResource=OMAP3_NetworkResource_vlr;
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_systemFailure, MAP_V3, &l_systemFail);
            g_sc.sendMsg(this, &l_userError);
            ELOG(0,0,"Sending User Error with MAP_ERROR_systemFailure");

         }	
         break;
      case MAP_ERROR_callBarred:
         {
            OMAP3_CallBarredParam l_CallBarred;
            memset(&l_CallBarred,'\0',sizeof(OMAP3_CallBarredParam));
            l_CallBarred.choice=OMAP3_callBarringCause_chosen;
            l_CallBarred.u.callBarringCause=OMAP3_operatorBarring;
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_callBarred, MAP_V3, &l_CallBarred);
            g_sc.sendMsg(this, &l_userError);
            ELOG(0,0,"Sending User Error with MAP_ERROR_callBarred");
         }
         break;
      case MAP_ERROR_dataMissing:
         {
            OMAP3_DataMissingParam l_DataMissing;
            memset(&l_DataMissing,'\0',sizeof(OMAP3_DataMissingParam));
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_dataMissing, MAP_V3, &l_DataMissing);
            g_sc.sendMsg(this, &l_userError);
            ELOG(0,0,"Sending User Error with MAP_ERROR_dataMissing");
         }
         break;
      case MAP_ERROR_unexpectedData:
         {
            OMAP3_UnexpectedDataParam l_UnexpectedData;
            memset(&l_UnexpectedData,'\0',sizeof(OMAP3_UnexpectedDataParam));
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_unexpectedData, MAP_V3, &l_UnexpectedData);
            g_sc.sendMsg(this, &l_userError);
            ELOG(0,0,"Sending User Error with MAP_ERROR_unexpectedData");
         }
         break;
      default :
         printf("Error code could not handle :%d]\n",p_ErrorCode);
         CLOG(0,0,"Sending User Error Code could not handle");

   }

   DLOG(0,0,"Closing the Dialogue");
   MapCloseReq l_closeReq(l_UserDlgId);
   g_sc.sendMsg(this, &l_closeReq);

   return true;
}

bool CtxtSendRoutingInfoGprs::processMessage(Msg *p_MsgPtr,bool& p_DeleteFlag)
{
   LLOG(0,0,"Start of CtxtSendRoutingInfoGprs::processMsg function");
   MapSpecificMsg *l_specMsg = NULL;
   int l_dlgId=0;;
   int l_UserDlgId;

   switch (p_MsgPtr->m_MsgType)
   {
      case MSG_TYPE_MAP:
         switch (((MapMsg*)p_MsgPtr)->m_MapMsgType)
         {
            case MAP_MSG_TYPE_COMMON:
               switch (((MapCommonMsg*)p_MsgPtr)->m_MapCommonMsgType)
               {
                  case MAP_CMN_OPEN_IND:
                     DLOG(0,0,"MAP_CMN_OPEN_IND received");
                     break;

                  case MAP_CMN_DELIMITER_IND:
                     DLOG(0,0,"MAP_CMN_DELIMITER_IND received");
                     break;

                  case MAP_CMN_CLOSE_IND:
                     LLOG(0,0,"MAP_CMN_CLOSE_IND received");
                     printf("\nGot a Close. Call flow success.\n");
                     return true;
                     break;

                  case MAP_CMN_U_ABORT_IND:
                     {
                        ELOG(0,0,"MAP_CMN_U_ABORT_IND received");
                        sendErrorResponse(MAP_ERROR_systemFailure,m_MapVesion);
                     }
                     break;

                  case MAP_CMN_P_ABORT_IND:
                     {
                        ELOG(0,0,"MAP_CMN_P_ABORT_IND received");
                        sendErrorResponse(MAP_ERROR_systemFailure,m_MapVesion);
                     }
                     break;

                  case MAP_CMN_NOTICE_IND:
                     {
                        ELOG(0,0,"MAP_CMN_NOTICE_IND received");
                        sendErrorResponse(MAP_ERROR_systemFailure,m_MapVesion);
                     }
                     break;

                  default:
                     CLOG(0,0,"Unknown Msg received [%d]", ((MapCommonMsg*)p_MsgPtr)->m_MapCommonMsgType);
                     break;
               }
               break;

            case MAP_MSG_TYPE_SPECIFIC:
               l_specMsg = (MapSpecificMsg*)p_MsgPtr;
               l_UserDlgId = l_specMsg->m_UserDlgId;
               DLOG(0,0,"MAP_MSG_TYPE_SPECIFIC received dlgId[%d] UserDlgId[%d]",
                     l_dlgId, l_UserDlgId);

               switch (((MapSpecificMsg*)p_MsgPtr)->m_MapSpecificEventType)
               {
                  case MAP_SPEC_EVENT_INDICATION:
                     {
                        DLOG(0,0,"MAP_SPEC_EVENT_INDICATION received");
                        l_UserDlgId = p_MsgPtr->m_UserDlgId;

                        switch (((MapSpecificMsg*)p_MsgPtr)->m_OpCode)
                        {
                           case MAP_OP_CODE_sendRoutingInfoForGprs:
                              {
                                 LLOG(0,0,"Received Send Routing Info for GPRS SRI");
                                 m_MsgSpecificMsgInd=(MapSpecificIndication*)p_MsgPtr;
                                 if (false == ((MapSpecificMsg*)p_MsgPtr)->m_allocatedFlag)
                                 {
                                    CLOG(0,0,"GPRS module Received on SRI DlgId with NuLL buffer%d ",l_UserDlgId);
                                    sendErrorResponse(MAP_ERROR_systemFailure,m_MapVesion);
                                    return false;
                                 }
                                 p_DeleteFlag=false;
                                 m_SRIdlgId=l_UserDlgId;
                                 handleRoutingInfo(p_MsgPtr);
                              }
                              break;

                           default:
                              ELOG(0,0,"Received Unknown Specific Message");
                              break;

                        }


                        //return true;
                     }

                     break;

                  case MAP_SPEC_EVENT_RESULT:
                     {
                        DLOG(0,0,"MAP_SPEC_EVENT_RESULT received");
                     }
                     break;

                  case MAP_SPEC_EVENT_CONFIRMATION:
                     {
                        LLOG(0,0,"MAP_SPEC_EVENT_CONFIRMATION received");
                        switch (((MapSpecificMsg*)p_MsgPtr)->m_OpCode)
                        {

                           break;
                           default:
                           ELOG(0,0,"ERROR!! Default received");
                           break;

                        }
                     }
                     break;

                  case MAP_SPEC_EVENT_USER_ERROR:
                     {
                        ELOG(0,0,"MAP_SPEC_EVENT_USER_ERROR received");

                     }
                     break;

                  case MAP_SPEC_EVENT_PROV_ERROR:
                     {
                        ELOG(0,0,"MAP_SPEC_EVENT_PROV_ERROR received");
                        sendErrorResponse(MAP_ERROR_systemFailure,m_MapVesion);
                        /*MapCloseReq l_closeReq(((MapSpecificMsg*)p_MsgPtr)->m_UserDlgId);
                          g_sc.sendMsg(this, &l_closeReq);*/
                     }
                     break;
                  default:
                     ELOG(0,0,"ERROR!! Default received");
                     break;

               }


               break;

            default:
               break;
         }
         break;

      case MSG_TYPE_DB:
         DLOG(0,0,"DB message received");
         p_DeleteFlag=false;
         handleDBResponse(p_MsgPtr);
         break;

      default:
         DLOG(0,0,"Unknown message received");
         break;

   }
   return true;
}
bool CtxtSendRoutingInfoGprs::handleRoutingInfo(Msg *p_MsgPtr)
{
   DLOG(0,0,"CtxtSendRoutingInfoGprs::handleRoutingInfo insite message received");
   m_MapVesion=((MapSpecificMsg*)p_MsgPtr)->m_Version;
   switch (m_MapVesion)
   {
      case 3:
         {
            //OMAP3_SendRoutingInfoForGprsArg  *l_temp=safe_reinterpret_cast<OMAP3_SendRoutingInfoForGprsArg*>(l_specMsg);
            IMAP3_SendRoutingInfoForGprsArg *l_temp = (IMAP3_SendRoutingInfoForGprsArg*)(((MapSpecificMsg*)p_MsgPtr)->m_structBuffer);

            int l_UserDlgId = p_MsgPtr->m_UserDlgId;

            //m_MsgStrctBuffer=l_temp;
            //m_SRIdlgId=l_UserDlgId;
            BCDToString((u8*)mp_routingInfoData->m_InIMSI, l_temp->imsi.value,l_temp->imsi.length); 
            DLOG(0,0,"HandleRoutingInfo Received IMSI in SRI %s\n",mp_routingInfoData->m_InIMSI );
            //printf(")mp_routingInfoData->m_InIMSI %s",mp_routingInfoData->m_InIMSI);
            setTraceImsi(mp_routingInfoData->m_InIMSI);// Set IMSI for Tracing 
            m_tdr.setChar(TDR_INDEX_REQUEST_TYPE,'I');
            m_tdr.setString(TDR_INDEX_REQUEST_IMSI,mp_routingInfoData->m_InIMSI);
            if(strlen(mp_routingInfoData->m_InIMSI) < 15) //Data Missing
            {
               LLOG(0,0,"SendingMAP_ERROR_unexpectedDataived User Error IMSI length%d",strlen(mp_routingInfoData->m_InIMSI));
               sendErrorResponse(MAP_ERROR_unexpectedData,m_MapVesion);
               return false ;
            }
            mp_routingInfoData->m_UserDlgId = l_UserDlgId;
            if(l_temp->bit_mask & OMAP3_SendRoutingInfoForGprsArg_ggsn_Address_present)
            {
               char l_ggsn[15];
               memset(l_ggsn,'\0',sizeof(l_ggsn));
               if(0x04 == l_temp->ggsn_Address.value[0])
               {

                  sprintf(l_ggsn,"%d.%d.%d.%d",l_temp->ggsn_Address.value[1],l_temp->ggsn_Address.value[2],l_temp->ggsn_Address.value[3],l_temp->ggsn_Address.value[4]);
                  strcpy(mp_routingInfoData->m_InGGSNAddress,l_ggsn);
                  DLOG(0,0,"Received GGSN Address in SRI %s\n",mp_routingInfoData->m_InGGSNAddress);
               }
               if (strlen(mp_routingInfoData->m_InGGSNAddress) <= 0)  // Data Missing  
               {
                  LLOG(0,0,"SendingMAP_ERROR_unexpectedDataived User Error GGSN Address Zero");
                  sendErrorResponse(MAP_ERROR_unexpectedData,m_MapVesion);
                  return false;
               }
               m_tdr.setString(TDR_INDEX_GGSN_IP_ADDRESS,mp_routingInfoData->m_InGGSNAddress);
            }
            BCDToString((u8*)mp_routingInfoData->m_InGGSNNumber, l_temp->ggsn_Number.value+1,l_temp->ggsn_Number.length-1); 
            DLOG(0,0,"Received GGSN Number in SRI %s\n",mp_routingInfoData->m_InGGSNNumber);
            if(strlen(mp_routingInfoData->m_InGGSNNumber) <= 0)// Data Missing
            {
               LLOG(0,0,"SendingMAP_ERROR_unexpectedDataived User Error GGSN Number Zero");
               sendErrorResponse(MAP_ERROR_unexpectedData,m_MapVesion);
               return false ;
            }
            m_tdr.setString(TDR_INDEX_GGSN_ADDRESS,mp_routingInfoData->m_InGGSNNumber);
            //printf("mp_routingInfoData->m_InGGSNNumber%s\n",mp_routingInfoData->m_InGGSNNumber);
            LLOG(0,0,"Sending data to DB IMSI %s, GGSN number %s, GGSN address %s ",mp_routingInfoData->m_InIMSI,mp_routingInfoData->m_InGGSNNumber,mp_routingInfoData->m_InGGSNAddress);

            mp_routingInfoData->m_cb = this;
            g_act.execute(mp_routingInfoData);

         }
         break;
      default:
         printf("MAP version is the Unknown ...........\n");
   }
   return true;

}

/*void CtxtSendRoutingInfoGprs::convertIPV4toHex(char * apIPv4Addr,unsigned char *apAddrInHex)
  {
  char *pch=NULL;

  pch=strtok(apIPv4Addr,".");
  apAddrInHex[0]=atoi(pch);

  pch= strtok (NULL, ".");
  apAddrInHex[1]=atoi(pch);

  pch= strtok (NULL, ".");
  apAddrInHex[2]=atoi(pch);

  apAddrInHex[3]=atoi((pch+strlen(pch)+1));

  }*/


bool CtxtSendRoutingInfoGprs::sendRountingInfoResp()
{
   LLOG(0,0,"SendRountingInfoResp Success Resp On DlgId %d SGSN Address %s",m_SRIdlgId,mp_routingInfoData->m_OutSGSNAddress);
   int l_UserDlgId=m_SRIdlgId;
   DECLARE(OMAP3_SendRoutingInfoForGprsRes,l_SRIResp,3,"OMAP3_SendRoutingInfoForGprsRes",resetStruct);
   //memset(&l_SRIResp, '\0', sizeof(OMAP3_SendRoutingInfoForGprsRes));

   //if(strlen(mp_routingInfoData->m_InGGSNAddress) > 0)
   if(true == ValidateIpv4(mp_routingInfoData->m_InGGSNAddress))
   {
      l_SRIResp->bit_mask |= OMAP3_SendRoutingInfoForGprsRes_ggsn_Address_present;
      l_SRIResp->ggsn_Address.length=5;
      l_SRIResp->ggsn_Address.value[0]=0x04;
      convertIPV4toHex(mp_routingInfoData->m_InGGSNAddress,&l_SRIResp->ggsn_Address.value[1]);
   }

   // if(strlen(mp_routingInfoData->m_OutSGSNAddress) > 0)
   if(0 == strlen(mp_routingInfoData->m_OutSGSNAddress))
   {
      ELOG(0,0,"Sending absentSubscriber on DlgId %d SGSN Address is Zero",m_SRIdlgId);
      sendErrorResponse(MAP_ERROR_absentSubscriber,m_MapVesion);
      return false;
   }
   if(true == ValidateIpv4(mp_routingInfoData->m_OutSGSNAddress))
   {
      m_tdr.setString(TDR_INDEX_SGSN_IP_ADDRESS,mp_routingInfoData->m_OutSGSNAddress);
      DLOG(0,0,"CtxtSendRoutingInfoGprs::sendRountingInfoResp On DlgId %d SGSN Address %s",m_SRIdlgId,mp_routingInfoData->m_OutSGSNAddress);
      l_SRIResp->sgsn_Address.length=5;
      l_SRIResp->sgsn_Address.value[0]=0x04;
      convertIPV4toHex(mp_routingInfoData->m_OutSGSNAddress,&l_SRIResp->sgsn_Address.value[1]);
   }
   else
   {
      WLOG(0,0,"Sending UnexpectedData on DlgId %d SGSN Address is Zero",m_SRIdlgId);
      sendErrorResponse(MAP_ERROR_unexpectedData,m_MapVesion);
      return false;
   }
   if(1 == mp_routingInfoData->m_MNRG)
   {
      m_tdr.setInteger(TDR_INDEX_SI_SGSN_NOTREACHABLE_REASON,mp_routingInfoData->m_MNRR_SGSN);
      LLOG(0,0,"Filling MNRR:%d in SRI Response ::sendRountingInfoResp On DlgId %d",m_SRIdlgId,mp_routingInfoData->m_MNRR_SGSN);
      l_SRIResp->bit_mask |= OMAP3_mobileNotReachableReason_present;
      l_SRIResp->mobileNotReachableReason=mp_routingInfoData->m_MNRR_SGSN;

   }
   MapSpecificResult l_result(l_UserDlgId,MAP_OP_CODE_sendRoutingInfoForGprs,MAP_V3);
   l_result.m_structBuffer = (void*)l_SRIResp;
   g_sc.sendMsg(this, &l_result);
   DLOG(0,0,"Closing the Dialogue");
   MapCloseReq l_closeReq(l_UserDlgId);
   g_sc.sendMsg(this, &l_closeReq);

   return true;
}
bool CtxtSendRoutingInfoGprs::handleDBResponse(Msg *p_MsgPtr)
{
m_tdr.setInteger(TDR_INDEX_MM_NETWORK_ID, mp_routingInfoData->m_nwid);
   if(mp_routingInfoData->m_DbQueryRes != DB_QUERY_RES_SUCCESS)
   {
      switch(mp_routingInfoData->m_ErrorCode)
      {
         case 1:
            {
               ELOG(0,0,"HandleDBResponse with Error code %d",mp_routingInfoData->m_ErrorCode);
               sendErrorResponse(MAP_ERROR_unknownSubscriber,m_MapVesion);
               return false;
            }
            break;
         case 2:
            {
               ELOG(0,0,"HandleDBResponse with Error code %d",mp_routingInfoData->m_ErrorCode);
               sendErrorResponse(MAP_ERROR_absentSubscriber,m_MapVesion);
               return true;
            }
            break;
         case 3:
            {
               ELOG(0,0,"HandleDBResponse with Error code %d",mp_routingInfoData->m_ErrorCode);
               sendErrorResponse(MAP_ERROR_systemFailure,m_MapVesion);
               return true;
               break;
            }
            break;
         case 4:
            {
               ELOG(0,0,"HandleDBResponse with Error code %d",mp_routingInfoData->m_ErrorCode);
               sendErrorResponse(MAP_ERROR_callBarred,m_MapVesion);
               return true;
            }
            break;

         default:
            {
               CLOG(0,0,"HandleDBResponse with default case %d",mp_routingInfoData->m_ErrorCode);
               printf("Application Could not handle the error Code %d\n",mp_routingInfoData->m_ErrorCode);
               return false;
            }

      }
   }
   else if ((1 == mp_routingInfoData->m_MNRG ) && ( 5 == mp_routingInfoData->m_MNRR_SGSN))// Send Absent Subscriber
   {
      ELOG(0,0,"Sending Absent Subscriber in SRI response with with DlgId%d",m_SRIdlgId);
      sendErrorResponse(MAP_ERROR_absentSubscriber,m_MapVesion);
      return false;

   }
   else// Getting Response from the DB Sucesss
   {
      if(strlen( mp_routingInfoData->m_OutHLRAddress) <= 0)
      {
         ELOG(0,0,"Sending System Failure HLR Address is not present");
         sendErrorResponse(MAP_ERROR_systemFailure,m_MapVesion);
         return false;
      }
      LLOG(0,0,"SRI for GPRS response DlgId %d  Hlr address %s",m_SRIdlgId,mp_routingInfoData->m_OutHLRAddress);
      sendMapOpenResponse(m_SRIdlgId,mp_routingInfoData->m_OutHLRAddress,g_GprsConfigReaderObj->m_HLRSSN);// Release 
      m_tdr.setString(TDR_INDEX_LOCAL_ADDRESS,mp_routingInfoData->m_OutHLRAddress);
      sendRountingInfoResp();
      LLOG(0,0,"Sending sendRountingInfoResp()SRI response with DlgId%d",m_SRIdlgId);

   }
   return true;
}
