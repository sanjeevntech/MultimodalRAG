#include <GprsConfigReader.h>
#include <Logger.h>
#include <stdlib.h>

GprsConfigReader *g_GprsConfigReaderObj=NULL;


GprsConfigReader::GprsConfigReader():m_GGSNSSN(0),m_SGSNSSN(0),m_HLRSSN(0)
{
   m_retrycount=0;
   m_noteMStimer=0;
   m_retryTimer=0;
}
GprsConfigReader::~GprsConfigReader()
{
}
bool GprsConfigReader::readData()
{
   //string l_npcInfo = readValue(m_DataString, "GPRS");
   string l_npcInfo = m_DataString;

   if( false == readInteger(l_npcInfo, "GGSN_SSN", m_GGSNSSN, 7, 255))
      return false;

   if( false == readInteger(l_npcInfo, "SGSN_SSN", m_SGSNSSN, 7, 255))
      return false;

   if( false == readInteger(l_npcInfo, "HLR_SSN", m_HLRSSN, 6, 255))
      return false;

   if( false == readInteger(l_npcInfo, "RETRY_COUNT", m_retrycount, 1, 10))
      return false;

   /*string l_rtrytimer = readValue(l_npcInfo, "RETRY_INTERVAL");
     g_GprsConfigReaderObj.m_retryTimer=atoi(l_rtrytimer.c_str());
     if((10 > g_GprsConfigReaderObj.m_retryTimer ) || (30 <g_GprsConfigReaderObj.m_retryTimer))
     {
     printf("Invalid RETRY TIMER, RETRY TIMER should be more than zero \n");
     return false;
     }
     string l_noteMS = readValue(l_npcInfo, "NoteMSTimer");
     g_GprsConfigReaderObj.m_noteMStimer=atoi(l_noteMS.c_str());
     if((10 > g_GprsConfigReaderObj.m_noteMStimer ) || (30 <g_GprsConfigReaderObj.m_noteMStimer))
     {
     printf("Invalid NOTE MS GPRS TIMER, NOTE MS GPRS TIMER should be more than zero \n");
     return false;
     }*/

   m_derivedObjectInitializedFlag=true;
   return true;
}
void GprsConfigReader::printConfigData(char *p_output)
{
   LLOG(0,1,"PrintConfigData called.");

   sprintf(p_output, "%s:%d\t%s:%d\t%s:%d\t%s:%d",
         "GGSN SSN",  g_GprsConfigReaderObj->m_GGSNSSN,
         "SGSN SSN",  g_GprsConfigReaderObj->m_SGSNSSN,
         "HLR SSN",  g_GprsConfigReaderObj->m_HLRSSN,
         "Retry Count",  g_GprsConfigReaderObj->m_retrycount
         );
}

