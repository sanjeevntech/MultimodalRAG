
/* Result Sets Interface */
#ifndef SQL_CRSR
#  define SQL_CRSR
  struct sql_cursor
  {
    unsigned int curocn;
    void *ptr1;
    void *ptr2;
    unsigned int magic;
  };
  typedef struct sql_cursor sql_cursor;
  typedef struct sql_cursor SQL_CURSOR;
#endif /* SQL_CRSR */

/* Thread Safety */
typedef void * sql_context;
typedef void * SQL_CONTEXT;

/* Object support */
struct sqltvn
{
  unsigned char *tvnvsn; 
  unsigned short tvnvsnl; 
  unsigned char *tvnnm;
  unsigned short tvnnml; 
  unsigned char *tvnsnm;
  unsigned short tvnsnml;
};
typedef struct sqltvn sqltvn;

struct sqladts
{
  unsigned int adtvsn; 
  unsigned short adtmode; 
  unsigned short adtnum;  
  sqltvn adttvn[1];       
};
typedef struct sqladts sqladts;

static struct sqladts sqladt = {
  1,1,0,
};

/* Binding to PL/SQL Records */
struct sqltdss
{
  unsigned int tdsvsn; 
  unsigned short tdsnum; 
  unsigned char *tdsval[1]; 
};
typedef struct sqltdss sqltdss;
static struct sqltdss sqltds =
{
  1,
  0,
};

/* File name & Package Name */
struct sqlcxp
{
  unsigned short fillen;
           char  filnam[15];
};
static const struct sqlcxp sqlfpn =
{
    14,
    "SiDbQueries.pc"
};


static unsigned int sqlctx = 1267619;


static struct sqlexd {
   unsigned long  sqlvsn;
   unsigned int   arrsiz;
   unsigned int   iters;
   unsigned int   offset;
   unsigned short selerr;
   unsigned short sqlety;
   unsigned int   occurs;
      const short *cud;
   unsigned char  *sqlest;
      const char  *stmt;
   sqladts *sqladtp;
   sqltdss *sqltdsp;
   unsigned char  **sqphsv;
   unsigned long  *sqphsl;
            int   *sqphss;
            short **sqpind;
            int   *sqpins;
   unsigned long  *sqparm;
   unsigned long  **sqparc;
   unsigned short  *sqpadto;
   unsigned short  *sqptdso;
   unsigned int   sqlcmax;
   unsigned int   sqlcmin;
   unsigned int   sqlcincr;
   unsigned int   sqlctimeout;
   unsigned int   sqlcnowait;
            int   sqfoff;
   unsigned int   sqcmod;
   unsigned int   sqfmod;
   unsigned char  *sqhstv[1];
   unsigned long  sqhstl[1];
            int   sqhsts[1];
            short *sqindv[1];
            int   sqinds[1];
   unsigned long  sqharm[1];
   unsigned long  *sqharc[1];
   unsigned short  sqadto[1];
   unsigned short  sqtdso[1];
} sqlstm = {12,1};

// Prototypes
extern "C" {
  void sqlcxt (void **, unsigned int *,
               struct sqlexd *, const struct sqlcxp *);
  void sqlcx2t(void **, unsigned int *,
               struct sqlexd *, const struct sqlcxp *);
  void sqlbuft(void **, char *);
  void sqlgs2t(void **, char *);
  void sqlorat(void **, unsigned int *, void *);
}

// Forms Interface
static const int IAPSUCC = 0;
static const int IAPFAIL = 1403;
static const int IAPFTL  = 535;
extern "C" { void sqliem(char *, int *); }

typedef struct { unsigned short len; unsigned char arr[1]; } VARCHAR;
typedef struct { unsigned short len; unsigned char arr[1]; } varchar;

/* cud (compilation unit data) array */
static const short sqlcud0[] =
{12,4130,1,0,0,
5,0,0,1,77,0,4,29,0,0,1,0,0,1,0,2,3,0,0,
};


#include <SiDbQueries.h>
#include <stdio.h>
#include <strings.h>
#include <sqlca.h>
#include <sqlda.h>

 
#define SQLCA_STORAGE_CLASS extern
#define ORACA_STORAGE_CLASS extern

extern struct oraca oraca;
extern struct sqlda sqlda;

/* EXEC SQL INCLUDE "/opt/product/rgopal/work/ng_framework_0.2/framework/inc/SCPConnectionObject.h";   
 */ 
/*
 * =====================================================================================
 * 
 *        Filename:  SCPConnectionObject.h
 * 
 *     Description:  
 * 
 *         Version:  3.0.1.0
 *         Created:  05/24/2006 11:45:15 AM IST
 *        Revision:  2
 *        Compiler:  g++
 * 
 *          Author:  Anjanr  (Unknown)
 *         History:        
 * 
 * 
 * 
 * =====================================================================================
 */

#include <sqlda.h>

// Begin-Unix-Specific 
// Modified on 27-May-2003 for porting to Unix 
#ifndef ORA_PROC
#include <string>
#endif 

#ifndef ORA_PROC
#include "Logger.h"
#endif 
#include <string>
#include "Logger.h"
#include "ConfigReader.h"
// End-Unix-Specific 

#define CONNECTION_ATTEMPTS 5
#define MEMBER_STATE_GOOD	0
#define MEMBER_STATE_BAD	1


extern struct oraca oraca;


// Begin-Unix-Specific 
// Commented on 02-Jun-2003 for porting to Unix 
#ifndef SQLCA
#define SQLCA 1
struct   sqlca
         {
         /* ub1 */ char    sqlcaid[8];
         /* b4  */ int     sqlabc;
         /* b4  */ int     sqlcode;
         struct
           {
           /* ub2 */ unsigned short sqlerrml;
           /* ub1 */ char           sqlerrmc[70];
           } sqlerrm;
         /* ub1 */ char    sqlerrp[8];
         /* b4  */ int     sqlerrd[6];
         /* ub1 */ char    sqlwarn[8];
         /* ub1 */ char    sqlext[8];
         };
#endif

#include <sqlca.h>
// End-Unix-Specific 

extern struct sqlca sqlca;
extern struct oraca oraca;

class ConnectionObject
{

private:
	// This variable indicates the state of the runtime context
	int	iState ;				
	/* EXEC SQL BEGIN DECLARE SECTION; */ 
		
		/* varchar	iCntStr[200]; */ 
struct { unsigned short len; unsigned char arr[200]; } iCntStr;

	/* EXEC SQL END DECLARE SECTION; */ 

	Logger* iLogger ;
public:

	/* EXEC SQL BEGIN DECLARE SECTION; */ 

   		sql_context iCtx;
	/* EXEC SQL END DECLARE SECTION; */ 

 
 	// Default Context Object
	ConnectionObject(string mCntStr,Logger* mLogger) ;

	// Create an instance of the Rating Context	
	static ConnectionObject* CreateContext(string m_ConnString,Logger* mLogger);

	// Destroys an instance of Rating Context
	static void DestroyContext(ConnectionObject* mPObj,string mStr);

	int checkConnectionStatus(int) ;

	virtual ~ConnectionObject();
};


bool GetSubsData::executeQuery(void *p_conn)
{
    printf("\nRetrieveSubsData::executeQuery start...");

    /* EXEC SQL BEGIN DECLARE SECTION; */ 

    int l_noOfEntries;
    /* EXEC SQL END DECLARE SECTION; */ 


    ConnectionObject* l_RunTimeContext = (ConnectionObject*)p_conn;
    /* EXEC SQL CONTEXT USE :(l_RunTimeContext->iCtx); */ 

    /* EXEC SQL WHENEVER SQLERROR GOTO SQL_ERROR_OCCURED; */ 

    /* EXEC SQL WHENEVER NOT FOUND GOTO DATA_NOT_FOUND; */ 


    /* EXEC SQL SELECT count(1) 
             INTO  :l_noOfEntries 
             FROM  RRBS_SUBSCRIBER_PROFILE 
             WHERE RESERVE_AMOUNT > 0; */ 

{
    struct sqlexd sqlstm;
    sqlstm.sqlvsn = 12;
    sqlstm.arrsiz = 1;
    sqlstm.sqladtp = &sqladt;
    sqlstm.sqltdsp = &sqltds;
    sqlstm.stmt = "select count(1) into :b0  from RRBS_SUBSCRIBER_PROFILE wh\
ere RESERVE_AMOUNT>0";
    sqlstm.iters = (unsigned int  )1;
    sqlstm.offset = (unsigned int  )5;
    sqlstm.selerr = (unsigned short)1;
    sqlstm.cud = sqlcud0;
    sqlstm.sqlest = (unsigned char  *)&sqlca;
    sqlstm.sqlety = (unsigned short)256;
    sqlstm.occurs = (unsigned int  )0;
    sqlstm.sqhstv[0] = (unsigned char  *)&l_noOfEntries;
    sqlstm.sqhstl[0] = (unsigned long )sizeof(int);
    sqlstm.sqhsts[0] = (         int  )0;
    sqlstm.sqindv[0] = (         short *)0;
    sqlstm.sqinds[0] = (         int  )0;
    sqlstm.sqharm[0] = (unsigned long )0;
    sqlstm.sqadto[0] = (unsigned short )0;
    sqlstm.sqtdso[0] = (unsigned short )0;
    sqlstm.sqphsv = sqlstm.sqhstv;
    sqlstm.sqphsl = sqlstm.sqhstl;
    sqlstm.sqphss = sqlstm.sqhsts;
    sqlstm.sqpind = sqlstm.sqindv;
    sqlstm.sqpins = sqlstm.sqinds;
    sqlstm.sqparm = sqlstm.sqharm;
    sqlstm.sqparc = sqlstm.sqharc;
    sqlstm.sqpadto = sqlstm.sqadto;
    sqlstm.sqptdso = sqlstm.sqtdso;
    sqlcxt(&((l_RunTimeContext->iCtx)), &sqlctx, &sqlstm, &sqlfpn);
    if (sqlca.sqlcode == 1403) goto DATA_NOT_FOUND;
    if (sqlca.sqlcode < 0) goto SQL_ERROR_OCCURED;
}



    printf("\nCount [%d]", l_noOfEntries);

	m_DbQueryRes = DB_QUERY_RES_SUCCESS;	
    return true;

SQL_ERROR_OCCURED:
	m_DbQueryRes = DB_QUERY_RES_CODE_EXCEPTION;	
    printf("\nRetrieveSubsData::executeQuery: SQL Error Occurred");
	return false;

DATA_NOT_FOUND:
	m_DbQueryRes = DB_QUERY_RES_ROWS_NOT_FOUND;	

    printf("\nRetrieveSubsData::executeQuery: Data Not Found");
       
    return false;
}

