/*****************************************************************************
 ** FILE NAME      : MsgList.cpp
 ** AUTHOR         : 
 ****************************************************************************/


#include <iostream>

#include "ConfigReader.h"
#include "MsgList.h"
//#include "Logger.h"

MsgList* MsgList::m_pUniqueIdList = NULL;

/*****************************************************************************
 ** FUNCTION NAME : MsgList::MsgList() 
 ** DEFINITION    : Constructor
 ** ARGUMENTS     : NULL
 ** RETURNS       : NULL
 ** REMARKS       :
 ****************************************************************************/
MsgList::MsgList()
{
   m_IsInitialized = false;
}

/*****************************************************************************
 ** FUNCTION NAME : initMsgList
 ** DEFINITION    : It initializes the Message Pool
 ** ARGUMENTS     : maxNoOfMsgs
 ** RETURNS       : NULL
 ** REMARKS       : It creates the Mutex.
 *****************************************************************************/
void MsgList::initMsgList()
{

   ENTER_FUNC
      try
      {
         m_CallContextList = new CallContext[g_ConfigData.m_MaxMsg + 1];
         if(NULL == m_CallContextList)
         {
            //g_LoggerObj.log(LOG_LEVEL_CRITICAL, "%s<Ln: %d> Failed to allocate memory.", __FUNCTION__, __LINE__);
            EXIT_FUNC
               return;
         }
         g_LoggerObj.log(LOG_LEVEL_DEBUG, "%s<Ln: %d> Allocated memory.", __FUNCTION__, __LINE__);
         m_IsInitialized = true;
      }
   catch(...)
   {
      //g_LoggerObj.log(LOG_LEVEL_CRITICAL, "%s<Ln: %d> Exception occured.", __FUNCTION__, __LINE__);
   }
   EXIT_FUNC
}

/*****************************************************************************
 ** FUNCTION NAME     : MsgList::getInstance()
 ** DEFINITION        : This function implements SINGLETON class and ensures
 **                   : that only one instance of NsUniqueIdList in the app.
 ** ARGUMENTS         :
 ** RETURNS           : Pointer of MsgList 
 ** REMARKS           : 
 *****************************************************************************/
MsgList*  MsgList::getInstance()
{
   try
   {
      if(m_pUniqueIdList == NULL)
      {
         m_pUniqueIdList = new MsgList();
      }
   }
   catch(...)
   {
     // g_LoggerObj.log(LOG_LEVEL_CRITICAL, "%s<Ln: %d> Exception occured.", __FUNCTION__, __LINE__);
   }
   return m_pUniqueIdList;
}

CallContext *MsgList::getCallDetails(u16 UId)
{
   if(false == m_IsInitialized)
   {
      //g_LoggerObj.log(LOG_LEVEL_CRITICAL, " %s<Ln: %d> Not initialized.", __FUNCTION__, __LINE__);
      return NULL;
   }

   if((g_ConfigData.m_MaxMsg < UId) || (1 > UId))
   {
      //g_LoggerObj.log(LOG_LEVEL_CRITICAL, "%s<Ln: %d> Invalid ID %d.",  __FUNCTION__, __LINE__, UId);
      return NULL;
   }
   return &m_CallContextList[UId];
}

{
   //g_LoggerObj.log(LOG_LEVEL_DEBUG, "%s<Ln: %d> [dlgId:%d] Reseting all call details ",__FUNCTION__, __LINE__,UId);
   memset(&m_CallContextList[UId], 0, sizeof(CallContext));
   memset(m_CallContextList[UId].dtmpInputs,'\0',sizeof(m_CallContextList[UId].dtmpInputs));
}
