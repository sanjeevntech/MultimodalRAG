#include <CtxtNoteMsPresentGprs.h>
#include <stdio.h>
#include <MapMessages.h>
#include <ServiceCoordinator.h>
#include <Logger.h>
#include <OMAP3.h>
#include <IMAP3.h>
#include <GprsDbQueries.h>
#include <DbActiveObject.h>
#include "Utilities.h"
#include <string.h>
#include <DataUnion.h>
#include <CtxtSendRoutingInfoGprs.h>
#include <GprsConfigReader.h>
#include <map>
#include <HlrTdrFiller.h>
using namespace std;
class CtxtNoteMsPresentGprs;
extern map<int,GgsnAddress> mapGgsnAddress;
bool CtxtNoteMsPresentGprs::startProcessing(InterModuleData *p_imd,bool& p_DeleteFlag)
{
   TLOG(0,0,"StartProcessing() Received DlgId %d %s" ,m_MSPrntdlgId,(NULL == p_imd->m_Parameters)?"":p_imd->m_Parameters);

   if(NULL == p_imd->m_Parameters)
   {
      CLOG(0,0,"p_imd->m_Parameters NULL returning");
      return false;
   }

   NoteMsPresentGPRSData *l_ptrMsPresent;
   l_ptrMsPresent=new NoteMsPresentGPRSData();
   l_ptrMsPresent->m_UserDlgId = m_MSPrntdlgId;
   memcpy(l_ptrMsPresent->m_InIMSI,(const char*)p_imd->m_Parameters,strlen((const char*)p_imd->m_Parameters));
   memcpy(m_imsi,l_ptrMsPresent->m_InIMSI,strlen(l_ptrMsPresent->m_InIMSI));
   setTraceImsi(m_imsi);//Set IMSI fo tracing 
   if(strlen(m_imsi) < 15 )
   {
      LLOG(0,0,"Received IMSI Length is less than 15 char" );
      return false;

   }


   TLOG(0,0,"StartProcessing() IMSI %s" ,(NULL == p_imd->m_Parameters)?"":p_imd->m_Parameters);

   l_ptrMsPresent->m_cb = this;
   l_ptrMsPresent->m_TypeOfQuery=1;
   g_act.execute(l_ptrMsPresent);
   return true;

}
bool CtxtNoteMsPresentGprs::checkmnrgFlag(int p_userId,bool &p_deleteflag)
{
   LLOG(0,0,"CheckmnrgFlag on DlgId %d ",p_userId);
   map<int,GgsnAddress>::iterator itr;
   itr=mapGgsnAddress.find(p_userId);
   if(itr != mapGgsnAddress.end())
   {
      NoteMsPresentGPRSData *l_ptrMsPresent;
      l_ptrMsPresent= new  NoteMsPresentGPRSData();
      memcpy(l_ptrMsPresent->m_InIMSI,m_imsi,strlen(m_imsi));
      l_ptrMsPresent->m_TypeOfQuery=2;
      l_ptrMsPresent->m_dlgId=p_userId;
      l_ptrMsPresent->m_cb = this;
      g_act.execute(l_ptrMsPresent);
   }
   if(0 == m_refcount)
      p_deleteflag=true;
   else
      p_deleteflag=false;
   return true;
}

CtxtNoteMsPresentGprs::CtxtNoteMsPresentGprs():m_MSPrntdlgId(0)
{
   DLOG(0,0,"CtxtNoteMsPresentGprs::CtxtNoteMsPresentGprs");
   m_MapVesion=MAP_V_UNKNOWN;
   mapGgsnAddress.clear();
   memset(m_sgsnaddress,'\0',4);
   memset(m_imsi,'\0',20);
   m_refcount=0;
}

CtxtNoteMsPresentGprs::~CtxtNoteMsPresentGprs()
{
   DLOG(0,0,"CtxtNoteMsPresentGprs::~CtxtNoteMsPresentGprs");
}

bool CtxtNoteMsPresentGprs::sendErrorResponse(EMapErrorCode p_ErrorCode)
{
   m_tdr.setInteger(TDR_INDEX_ERR_CODE,(ETdrErrorCode)p_ErrorCode);
   ELOG(0,0,"Sending error Response");
   int l_UserDlgId=m_MSPrntdlgId;
   switch(p_ErrorCode)
   {
      case MAP_ERROR_unknownSubscriber:
         {
            OMAP3_UnknownSubscriberParam l_UnknowSub;
            l_UnknowSub.bit_mask |= OMAP3_unknownSubscriberDiagnostic_present;
            l_UnknowSub.unknownSubscriberDiagnostic=OMAP3_gprsSubscriptionUnknown;
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_unknownSubscriber, MAP_V3, (void*)&l_UnknowSub);
            g_sc.sendMsg(this, &l_userError);
            ELOG(0,0,"Sending User Error with MAP_ERROR_unknownSubscriber DlgId %d",l_UserDlgId);
         }

      case MAP_ERROR_unexpectedData:
         { 
            OMAP3_UnexpectedDataParam l_UnexpectedData;
            memset(&l_UnexpectedData,'\0',sizeof(OMAP3_UnexpectedDataParam));
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_unexpectedData, MAP_V3, &l_UnexpectedData);
            g_sc.sendMsg(this, &l_userError);
            ELOG(0,0,"Sending User Error with MAP_ERROR_unexpectedData DlgId %d",l_UserDlgId);
         }
         break;

      case MAP_ERROR_dataMissing:
         {
            OMAP3_DataMissingParam l_DataMissing;
            memset(&l_DataMissing,'\0',sizeof(OMAP3_DataMissingParam));
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_orNotAllowed, MAP_V3, &l_DataMissing);
            g_sc.sendMsg(this, &l_userError);
            ELOG(0,0,"Sending User Error with MAP_ERROR_dataMissing DlgId %d",l_UserDlgId);
         }
         break;
      case MAP_ERROR_systemFailure:
         {
            OMAP3_SystemFailureParam l_systemFail;
            memset(&l_systemFail,'\0',sizeof(OMAP3_SystemFailureParam));
            l_systemFail.choice = OMAP3_networkResource_chosen;
            l_systemFail.u.networkResource=OMAP3_NetworkResource_vlr;
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_systemFailure, MAP_V3, &l_systemFail);
            g_sc.sendMsg(this, &l_userError);
            ELOG(0,0,"Sending User Error with MAP_ERROR_systemFailure DlgId %d",l_UserDlgId);

         }	
         break;



      default :
         printf("Error code could not handle :%d]\n",p_ErrorCode);
         CLOG(0,0,"Getting default Case in dlgId %d",l_UserDlgId);

   }

   DLOG(0,0,"Closing the Dialogue");
   MapCloseReq l_closeReq(l_UserDlgId);
   g_sc.sendMsg(this, &l_closeReq);

   return true;
}
bool CtxtNoteMsPresentGprs::handleDBResponse(Msg *p_MsgPtr,bool& p_DeleteFlag,int p_userId)
{
   NoteMsPresentGPRSData *l_msPresentGPRSData;
   DbQueryMsg *l_dbmesg;
   l_dbmesg=(DbQueryMsg*)p_MsgPtr;
   l_msPresentGPRSData=(NoteMsPresentGPRSData*)l_dbmesg;
   p_userId=l_msPresentGPRSData->m_dlgId;

   LLOG(0,0,"  CtxtNoteMsPresentGprs::handleDBResponse DB Error Code %d",l_msPresentGPRSData->m_ErrorCode);

   if(l_msPresentGPRSData->m_DbQueryRes != DB_QUERY_RES_SUCCESS)
   {
      switch(l_msPresentGPRSData->m_ErrorCode)
      {
         case 1:
            {
               ELOG(0,0,"Return Database Error Code 1");
               return false;
            }
         case 2:
            {
               ELOG(0,0,"Return Database Error Code 2");
               return false;
            }
         default:
            {
               printf("Application Could not handle the error code %d\n",l_msPresentGPRSData->m_ErrorCode);
               ELOG(0,0,"Application Could not handle the error code %d\n",l_msPresentGPRSData->m_ErrorCode);
               return false;
            }
      }
   }
   else if (l_msPresentGPRSData->m_TypeOfQuery == 1)
   {
      LLOG(0,0,"HandleDBResponse sendMSPresentReq");
      sendMSPresentReq(l_msPresentGPRSData,p_DeleteFlag);
   }
   else 
   {
      LLOG(0,0,"HandleDBResponse Started Retry Logic ");
      sendRetryReq(l_msPresentGPRSData,p_userId,p_DeleteFlag);
   }


   return true;
}

bool CtxtNoteMsPresentGprs::fillNoteMSPresentGPRS(int p_dlgId,unsigned char* p_SGSNAddress,char *p_GGSNNumber,unsigned char *p_GGSNAddress,char *p_hlrAddress)
{
   LLOG(0,0,"FillNoteMSPresentGPRS On DlgId %d HLR Adrress%s GGSN Number%s",p_dlgId,p_hlrAddress,p_GGSNNumber);
   MapOpenReq l_mapOpenReq(p_dlgId, MAP_V3);

   m_tdr.setString(TDR_INDEX_LOCAL_ADDRESS,p_hlrAddress);
   m_tdr.setString(TDR_INDEX_GGSN_ADDRESS,p_GGSNNumber);
   configureSccpAddress(&l_mapOpenReq.m_OrigAddr,0,0,g_GprsConfigReaderObj->m_HLRSSN,p_hlrAddress); //Release 
   configureSccpAddress(&l_mapOpenReq.m_DestAddr,0,0,g_GprsConfigReaderObj->m_GGSNSSN,p_GGSNNumber); //Release 
   //l_mapOpenReq.m_DestAddr  = g_ConfigData->i_NgConfigData.m_remoteAddress1; // Testing 
   l_mapOpenReq.m_ApplCntxt = MAP_AC_CODE_gprsNotify;
   g_sc.sendMsg(this, &l_mapOpenReq);

   DECLARE(OMAP3_NoteMsPresentForGprsArg,l_MSPrntReq,3,"OMAP3_NoteMsPresentForGprsArg",resetStruct);
   LLOG(0,0,"FillNoteMSPresentGPRS On DlgId %d",p_dlgId);
   char l_ggsn[15];
   memset(l_ggsn,'\0',sizeof(l_ggsn));
   sprintf(l_ggsn,"%d.%d.%d.%d",p_GGSNAddress[0],p_GGSNAddress[1],p_GGSNAddress[2],p_GGSNAddress[3]);
   m_tdr.setString(TDR_INDEX_GGSN_IP_ADDRESS,l_ggsn);
   l_MSPrntReq->bit_mask |= OMAP3_NoteMsPresentForGprsArg_ggsn_Address_present;
   l_MSPrntReq->ggsn_Address.length=5;
   l_MSPrntReq->ggsn_Address.value[0]=0x04;
   memcpy(&l_MSPrntReq->ggsn_Address.value[1],p_GGSNAddress,4);
   char l_sgsn[15];
   memset(l_sgsn,'\0',sizeof(l_sgsn));
   sprintf(l_sgsn,"%d.%d.%d.%d",p_SGSNAddress[0],p_SGSNAddress[1],p_SGSNAddress[2],p_SGSNAddress[3]);
   m_tdr.setString(TDR_INDEX_SGSN_IP_ADDRESS,l_sgsn);
   l_MSPrntReq->sgsn_Address.length=5;
   l_MSPrntReq->sgsn_Address.value[0]=0x04;
   memcpy(&l_MSPrntReq->sgsn_Address.value[1], p_SGSNAddress,4);
   int l_len =strlen(m_imsi);
   int l_rem=l_len%2;
   if(l_rem==0)
   {
      l_MSPrntReq->imsi.length=l_len/2;
   }
   else
   {
      l_MSPrntReq->imsi.length=l_len/2+1;
   }
   //StringToBCD( l_MSPrntReq->imsi.value, (u8*)m_imsi, l_len);
   numToBCD((u8*)m_imsi,l_MSPrntReq->imsi.value,l_len);
   m_tdr.setChar(TDR_INDEX_REQUEST_TYPE,'I');
   m_tdr.setString(TDR_INDEX_REQUEST_IMSI,m_imsi);


   LLOG(0,0,"Sending Note MS Present for GPRS MapSpecificRequest ...");
   MapSpecificRequest l_request(p_dlgId, MAP_OP_CODE_noteMsPresentForGprs, MAP_V3);
   l_request.m_structBuffer = (void*)l_MSPrntReq;
   g_sc.sendMsg(this, &l_request);

   DLOG(0,0,"Sending Note MS Present for GPRS  MapDelimiterReq Req ...");
   MapDelimiterReq l_del(p_dlgId);
   g_sc.sendMsg(this, &l_del);
   return true;

}
bool CtxtNoteMsPresentGprs::sendRetryReq(NoteMsPresentGPRSData *p_msPresent,int p_userId,bool &p_deleteFlag)
{
   DLOG(0,0,"SendRetryReq Started User Id %d",p_userId);
   int l_UserDlgId=p_userId;
   map<int,GgsnAddress>::iterator itr;
   itr=mapGgsnAddress.find(l_UserDlgId);
   --m_refcount;
   if((itr != mapGgsnAddress.end())&& (0 == p_msPresent->m_MNRG))
   {
      GgsnAddress l_ggsnAddress;
      memset(&l_ggsnAddress,'\0',sizeof(GgsnAddress));
      memcpy(&l_ggsnAddress,&itr->second,sizeof(GgsnAddress));
      LLOG(0,0,"Retry Count from Configure %d",l_ggsnAddress.retCount);
      --l_ggsnAddress.retCount;
      int l_newId=g_sc.getNewDialogue();
      if(l_newId <= 0)
      {
         CLOG(0,0,"For NOte MS Present Couldnot Allocated  DlgId:%d",l_newId);
         return false;
      }
      LLOG(0,0,"Allocated DlgId %d for Note Ms Present for GPRS ",l_newId);
      ++m_refcount;
      fillNoteMSPresentGPRS(l_newId,m_sgsnaddress,l_ggsnAddress.ggsnAddress.m_OutGGSNNumber,l_ggsnAddress.m_ggsnaddress,l_ggsnAddress.ggsnAddress.m_OutHLRAddress);
      mapGgsnAddress.erase(itr);
      p_deleteFlag=false;
      if( 0 != l_ggsnAddress.retCount)
      {
         DLOG(0,0,"Insert Into mapGgsnAddress Map Based on DlgId %d and Retry Count is more thean zero",l_newId);
         mapGgsnAddress[l_newId]=l_ggsnAddress;
      }
      else// Delete from the HLR_SUBS_PWD
      {
         NoteMsPresentGPRSData *l_ptrMsPresent;
         l_ptrMsPresent = new  NoteMsPresentGPRSData();
         memcpy(l_ptrMsPresent->m_InIMSI,m_imsi,strlen(m_imsi));
         l_ptrMsPresent->m_TypeOfQuery=2;
         DLOG(0,0,"Deleting Entry from HLR_SUBS_PWD on DlgId %d",l_UserDlgId);
         l_ptrMsPresent->m_dlgId=l_UserDlgId;
         memcpy(l_ptrMsPresent->m_InGGSNNumber,l_ggsnAddress.ggsnAddress.m_OutGGSNNumber,strlen(l_ggsnAddress.ggsnAddress.m_OutGGSNNumber));
         LLOG(0,0,"Deleting Entry from HLR_SUBS_PWD based IMSI %s GGSN Number %s ",l_ptrMsPresent->m_InIMSI,l_ptrMsPresent->m_InGGSNNumber); 
         l_ptrMsPresent->m_deleteFlag=1;
         l_ptrMsPresent->m_cb = this;
         g_act.execute(l_ptrMsPresent);
      }

   }
   p_deleteFlag=true;
   //if(0 == m_refcount)
   return true;
}
bool CtxtNoteMsPresentGprs::sendMSPresentReq(NoteMsPresentGPRSData *p_msPresent,bool& p_DeleteFlag)
{
   LLOG(0,0,"No of Rows %d returns from HLR_SUBS_PWD and SGSN Address %s",p_msPresent->m_Norows,p_msPresent->m_OutSGSNAddress);
   if(p_msPresent->m_Norows)
   {
      if(true == ValidateIpv4(p_msPresent->m_OutSGSNAddress))
      {
         convertIPV4toHex(p_msPresent->m_OutSGSNAddress,&m_sgsnaddress[0]);
      }
      else 
      {
         ELOG(0,0,"Invalid SGSN Address from DB");
         return false;
      }
      for(int cnt=0; cnt < p_msPresent->m_Norows; cnt++)
      {
         GgsnAddress l_ggsnAddress;
         memset(&l_ggsnAddress,'\0',sizeof(GgsnAddress));
         l_ggsnAddress.retCount=g_GprsConfigReaderObj->m_retrycount;
         LLOG(0,0,"Retry Count %d and RefCount %d",l_ggsnAddress.retCount,m_refcount);
         if(true == ValidateIpv4(p_msPresent->m_ggsnaddlist[cnt].m_OutGGSNAddress))
         {
            convertIPV4toHex(p_msPresent->m_ggsnaddlist[cnt].m_OutGGSNAddress,&l_ggsnAddress.m_ggsnaddress[0]);
         }
         else
         {
            ELOG(0,0,"Invalid GGSN Address from DB");
            return false;
         }
         memcpy(&l_ggsnAddress.ggsnAddress,&p_msPresent->m_ggsnaddlist[cnt],sizeof(GGSNAddresslist));
         m_MSPrntdlgId=g_sc.getNewDialogue();
         if(m_MSPrntdlgId <= 0)
         {
            CLOG(0,0,"For NOte MS Present Couldnot Allocated  DlgId:%d",m_MSPrntdlgId);
            return false;
         }
         p_msPresent->m_dlgId=m_MSPrntdlgId;
         ++m_refcount;
         DLOG(0,0,"Allocated DlgId%d and RefCount %d",m_MSPrntdlgId,m_refcount);
         mapGgsnAddress[m_MSPrntdlgId]=l_ggsnAddress;
         LLOG(0,0,"Sending Count %d Filling Note Ms Presnt for GPRS on DlgId %d" ,cnt, m_MSPrntdlgId); 
         fillNoteMSPresentGPRS(m_MSPrntdlgId,m_sgsnaddress,p_msPresent->m_ggsnaddlist[cnt].m_OutGGSNNumber,l_ggsnAddress.m_ggsnaddress,p_msPresent->m_ggsnaddlist[cnt].m_OutHLRAddress);
      }
   }
   else
   {
      ELOG(0,0,"In Database not presentSGSN Address");
      return false;

   }
   //p_DeleteFlag=true;
   DLOG(0,0,"Sending Note Ms Presnt end");

}

bool CtxtNoteMsPresentGprs::processMessage(Msg *p_MsgPtr,bool& p_DeleteFlag)
{
   DLOG(0,0,"Start of CtxtNoteMsPresentGprs::processMsg function");
   MapSpecificMsg *l_specMsg = NULL;
   MapCommonMsg* l_commMsg =NULL;
   int l_dlgId=0;
   int l_UserDlgId=0;

   switch (p_MsgPtr->m_MsgType)
   {
      l_UserDlgId=p_MsgPtr->m_UserDlgId;
      case MSG_TYPE_MAP:
      switch (((MapMsg*)p_MsgPtr)->m_MapMsgType)
      {
         case MAP_MSG_TYPE_COMMON:
            l_commMsg = (MapCommonMsg*)p_MsgPtr;
            l_UserDlgId=l_commMsg->m_UserDlgId;
            switch (((MapCommonMsg*)p_MsgPtr)->m_MapCommonMsgType)
            {
               case MAP_CMN_OPEN_IND:
                  DLOG(0,0,"MAP_CMN_OPEN_IND received");
                  break;
               case MAP_CMN_OPEN_CNF:
                  WLOG(0,0,"MAP_CMN_OPEN_CNF received with version % d",l_commMsg->m_Version);
                  break;
               case MAP_CMN_DELIMITER_IND:
                  DLOG(0,0,"MAP_CMN_DELIMITER_IND received");
                  break;

               case MAP_CMN_CLOSE_IND:
                  DLOG(0,0,"MAP_CMN_CLOSE_IND received");
                  //printf("\nGot a Close. Call flow success.\n");
                  return true;
                  break;

               case MAP_CMN_U_ABORT_IND:
                  {
                     ELOG(0,0,"MAP_CMN_U_ABORT_IND received DlgId %d",l_UserDlgId);
                     checkmnrgFlag(l_UserDlgId,p_DeleteFlag);
                     m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_U_ABORT_RCVD);
                  }

                  break;

               case MAP_CMN_P_ABORT_IND:
                  {
                     ELOG(0,0,"MAP_CMN_P_ABORT_IND received DlgId %d",l_UserDlgId);
                     checkmnrgFlag(l_UserDlgId,p_DeleteFlag);
                     m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_P_ABORT_RCVD);
                  }

                  break;

               case MAP_CMN_NOTICE_IND:
                  {
                     ELOG(0,0,"MAP_CMN_NOTICE_IND received DlgId %d",l_UserDlgId);
                     checkmnrgFlag(l_UserDlgId,p_DeleteFlag);
                     m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_NOTICE_RCVD);
                     MapCloseReq l_closeReq(((MapSpecificMsg*)p_MsgPtr)->m_UserDlgId);
                     l_closeReq.m_CloseType = MAP_CLOSE_TYPE_PRE_ARRANGED_END;
                     g_sc.sendMsg(this, &l_closeReq);
                  }
                  break;

               default:
                  CLOG(0,0,"Unknown Msg received [%d]", ((MapCommonMsg*)p_MsgPtr)->m_MapCommonMsgType);
                  break;
            }
            break;

         case MAP_MSG_TYPE_SPECIFIC:
            l_specMsg = (MapSpecificMsg*)p_MsgPtr;
            l_UserDlgId = l_specMsg->m_UserDlgId;
            DLOG(0,0,"MAP_MSG_TYPE_SPECIFIC received dlgId[%d] UserDlgId[%d]",
                  l_dlgId, l_UserDlgId);

            switch (((MapSpecificMsg*)p_MsgPtr)->m_MapSpecificEventType)
            {
               case MAP_SPEC_EVENT_INDICATION:
                  {
                     DLOG(0,0,"MAP_SPEC_EVENT_INDICATION received");
                     l_UserDlgId = p_MsgPtr->m_UserDlgId;

                     switch (((MapSpecificMsg*)p_MsgPtr)->m_OpCode)
                     {
                        case MAP_OP_CODE_noteMsPresentForGprs:
                           {
                              DLOG(0,0,"Received MAP_OP_CODE_noteMsPresentForGprs  ");

                           }
                           break;

                        default:
                           DLOG(0,0,"Received Unknown Specific Message");
                           break;

                     }


                     //return true;
                  }
                  break;

               case MAP_SPEC_EVENT_RESULT:
                  {
                     DLOG(0,0,"MAP_SPEC_EVENT_RESULT received");
                  }
                  break;

               case MAP_SPEC_EVENT_CONFIRMATION:
                  {
                     switch (((MapSpecificMsg*)p_MsgPtr)->m_OpCode)
                     {
                        case MAP_OP_CODE_noteMsPresentForGprs:
                           {
                              --m_refcount;
                              LLOG(0,0,"Received MAP_OP_CODE_noteMsPresentForGprs  Confirmation Indication DlgId %d",l_UserDlgId);
                              map<int,GgsnAddress>::iterator itr;
                              itr=mapGgsnAddress.find(l_UserDlgId);
                              if(itr != mapGgsnAddress.end())
                              {
                                 GgsnAddress l_ggsnAddress;
                                 memset(&l_ggsnAddress,'\0',sizeof(GgsnAddress));
                                 memcpy(&l_ggsnAddress,&itr->second,sizeof(GgsnAddress));
                                 mapGgsnAddress.erase(itr);
                                 NoteMsPresentGPRSData *l_msPresentdata;
                                 l_msPresentdata = new  NoteMsPresentGPRSData();
                                 l_msPresentdata->m_TypeOfQuery=2;
                                 l_msPresentdata->m_dlgId=l_UserDlgId;
                                 memcpy(l_msPresentdata->m_InIMSI,m_imsi,strlen(m_imsi));
                                 memcpy(l_msPresentdata->m_InGGSNNumber,l_ggsnAddress.ggsnAddress.m_OutGGSNNumber,strlen(l_ggsnAddress.ggsnAddress.m_OutGGSNNumber));
                                 LLOG(0,0,"Deleting entry from HLR_SUB_PWD on IMSI%s GGSN Number %d",l_msPresentdata->m_InIMSI,l_msPresentdata->m_InGGSNNumber);
                                 l_msPresentdata->m_deleteFlag=1;
                                 l_msPresentdata->m_cb = this;
                                 g_act.execute(l_msPresentdata);
                              }
                              if(0 == m_refcount)
                                 p_DeleteFlag=true;
                              else
                                 p_DeleteFlag=false;

                              /*if (false == ((MapSpecificMsg*)p_MsgPtr)->m_allocatedFlag)
                                {
                                sendErrorResponse(MAP_ERROR_unexpectedData);
                                CLOG(0,0,"Note For MS Present Recevied NULL Buffer on DlgId%d ",m_MSPrntdlgId);
                                return false;
                                }*/

                           }
                           break;
                        default:
                           DLOG(0,0,"Received Unknown Specific Message");
                           break;

                     }
                  }
                  break;

               case MAP_SPEC_EVENT_USER_ERROR:
                  {
                     ELOG(0,0,"MAP_SPEC_EVENT_USER_ERROR received DlgId %d",l_UserDlgId);
                     checkmnrgFlag(l_UserDlgId,p_DeleteFlag);
                     MapCloseReq l_closeReq(((MapSpecificMsg*)p_MsgPtr)->m_UserDlgId);
                     g_sc.sendMsg(this, &l_closeReq);
                     /*map<int,GgsnAddress>::iterator itr;
                       itr=mapGgsnAddress.find(l_UserDlgId);
                       if(itr != mapGgsnAddress.end())
                       {
                       m_ptrMsPresent = new  NoteMsPresentGPRSData();
                       memcpy(m_ptrMsPresent->m_InIMSI,m_imsi,strlen(m_imsi));
                       m_ptrMsPresent->m_TypeOfQuery=2;
                       m_ptrMsPresent->m_dlgId=l_UserDlgId;
                       m_ptrMsPresent->m_cb = this;
                       g_act.execute(m_ptrMsPresent);
                       }
                       if(0 == m_refcount)
                       p_DeleteFlag=true;
                       else
                       p_DeleteFlag=false;*/

                  }
                  break;

               case MAP_SPEC_EVENT_PROV_ERROR:
                  {
                     ELOG(0,0,"MAP_SPEC_EVENT_PROV_ERROR received DlgId %d",l_UserDlgId);
                     checkmnrgFlag(l_UserDlgId,p_DeleteFlag);

                     MapCloseReq l_closeReq(((MapSpecificMsg*)p_MsgPtr)->m_UserDlgId);

                     g_sc.sendMsg(this, &l_closeReq);
                  }
                  break;
               default:
                  ELOG(0,0,"ERROR!! Default received");
                  break;
            }
            break;
         default:
            break;


      }

      break;

      case MSG_TYPE_DB:
      DLOG(0,0,"DB message received User Id %d",l_UserDlgId);
      if(true == handleDBResponse(p_MsgPtr,p_DeleteFlag,l_UserDlgId))
         //p_DeleteFlag=false;

         break;


      default:
      DLOG(0,0,"Unknown message received");
      break;

   }
   printf("Return true \n");
   return true;
}


