#!/bin/bash
cd $APP_ROOT

echo "Start preparing HLR TEST release bundle"

#setting env varible for release
BUILD_TYPE=PROD
export BUILD_TYPE

. run.sh

#setting env varible for ST release
export GCOV_FLAGS=""
export GOOGLE_TEST=""
export APP_VERSION=`git describe --tags`
export COMMIT_ID=`git rev-parse HEAD`
export COMMIT_DATE=


echo $LD_LIBRARY_PATH
###########################
### START OF USER_SPACE ###
###########################

rm -rf $APP_ROOT/build/
mkdir $APP_ROOT/build/
$MAKE_PATH/make -f MakefileTST clean
$MAKE_PATH/make -f MakefileTST procdirs
$MAKE_PATH/make -f MakefileTST all -j 16
$MAKE_PATH/make -f MakefileTST copy
$MAKE_PATH/make -f MakefileTST tar

$MAKE_PATH/make -f MakefileTST rtpsclean
$MAKE_PATH/make -f MakefileTST rtpsprocdirs
$MAKE_PATH/make -f MakefileTST rtpsall
$MAKE_PATH/make -f MakefileTST rtpscopy
$MAKE_PATH/make -f MakefileTST rtpstar

#########################
### END OF USER_SPACE ###
#########################

echo
echo -e "Preparing TEST release bundle done"
echo
echo
