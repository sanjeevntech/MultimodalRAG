#!/bin/bash

rm -rf  $CI_REPORT_DIR/generated/

mkdir $CI_REPORT_DIR/generated

echo -e "\nGenerating UT report\n"
xsltproc $CI_REPORT_DIR/UnitTestCase_Report.xsl $CI_REPORT_DIR/$UT_OUTPUT_FILE_NAME > $CI_REPORT_DIR/generated/$UT_REPORT_FILE_NAME
echo -e "\nGenerating UT report done\n"

echo -e "\nGenerating Code Coverage report\n"
$LCOV_PATH/bin/genhtml $CI_REPORT_DIR/$CRR_OUTPUT_FILE_NAME --output-directory $CI_REPORT_DIR/generated/$CRR_OUTPUT_DIR --title "$APP_NAME Code Coverage Test"  --show-details --legend
echo -e "\nGenerating Code Coverage report done\n"


echo -e "\nGenerating CPPcheck report\n"
xsltproc $CI_REPORT_DIR/CppCheck_Report.xsl $CI_REPORT_DIR/$CPPCHECK_OUTPUT_FILE_NAME > $CI_REPORT_DIR/generated/$CPP_CHECK_REPORT_FILENAME

echo -e "\nGenerating CPPcheck report done \n"

