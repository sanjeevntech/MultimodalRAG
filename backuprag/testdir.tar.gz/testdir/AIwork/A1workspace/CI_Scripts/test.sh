#!/bin/bash
cd $BIN_DIR
echo $BIN_DIR
echo we are in $BIN_DIR

ldd $BIN_DIR/$UT_BIN_NAME

GUTIL_DEBUG_LOGS=yes
export GUTIL_DEBUG_LOGS=Yes
SHM=100

echo $BIN_DIR
echo $UT_BIN_NAME
echo $BIN_ARG
$BIN_DIR/$UT_BIN_NAME $BIN_ARG 
