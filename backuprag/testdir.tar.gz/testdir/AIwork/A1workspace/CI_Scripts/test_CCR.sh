#!/bin/bash

$LCOV_PATH/bin/lcov --gcov-tool $GCOV_PATH/bin/gcov $APP_OBJ_DIRS --capture --output-file $CI_REPORT_DIR/$CRR_OUTPUT_FILE_NAME

$LCOV_PATH/bin/lcov --remove $CI_REPORT_DIR/$CRR_OUTPUT_FILE_NAME $CRR_REMOVE_CONTENT -o $CI_REPORT_DIR/$CRR_OUTPUT_FILE_NAME

