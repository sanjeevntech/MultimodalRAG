#!/bin/bash
cd $APP_ROOT

echo "Start preparing HLR release bundle"

#setting env varible for release
BUILD_TYPE=PROD
export BUILD_TYPE

. run.sh

#setting env varible for ST release
export GCOV_FLAGS=""
export GOOGLE_TEST=""
export APP_VERSION=`git describe --tags`
export COMMIT_ID=`git rev-parse HEAD`
export COMMIT_DATE=


echo $LD_LIBRARY_PATH
###########################
### START OF USER_SPACE ###
###########################

rm -rf $APP_ROOT/build/
mkdir $APP_ROOT/build/
$MAKE_PATH/make clean
$MAKE_PATH/make procdirs
$MAKE_PATH/make all -j 16 
$MAKE_PATH/make copy
$MAKE_PATH/make tar

#$MAKE_PATH/make rtpsclean
#$MAKE_PATH/make rtpsprocdirs
#$MAKE_PATH/make rtpsall -j 4
#$MAKE_PATH/make rtpscopy
#$MAKE_PATH/make rtpstar

#########################
### END OF USER_SPACE ###
#########################

echo
echo -e "Preparing release bundle done"
echo
echo
