#!/bin/bash

######################################################
#################### CI starts #######################
######################################################

cd $APP_ROOT

echo -e "\nCompilation started for Devops release \n"

#setting env varible for release
BUILD_TYPE=CI
export BUILD_TYPE
pwd
. run.sh
pwd
if [ -z $GTEST_INSTALL ]; 
then 
	echo "GTEST_INSTALL is unset"; 
	exit	
else 
	echo "GTEST_INSTALL is set to '$GTEST_INSTALL'"; 
fi

#setting env varible for devops release
export GCOV_FLAGS='-fprofile-arcs -ftest-coverage'
export GOOGLE_TEST='-DGOOGLE_TEST'
export APP_VERSION=`git describe --tags`
export COMMIT_ID=`git rev-parse HEAD`
export COMMIT_DATE=

HLR_CI=$APP_ROOT/
export HLR_CI
RTPS_CI=$APP_ROOT/RTPS/
export RTPS_CI

MULTI_BUNDLE_BUILD_PATH=$HLR_CI:$RTPS_CI

#changing directory start 

#make for UT bin 
#rm -rf $APP_ROOT/build/
#mkdir $APP_ROOT/build/

$MAKE_PATH/make -f MakefileD clean
$MAKE_PATH/make -f MakefileD procdirs
$MAKE_PATH/make -f MakefileD -j 8 all
$MAKE_PATH/make -f MakefileD copy
#$MAKE_PATH/make -f MakefileD copyextra

$MAKE_PATH/make -f MakefileDevOps rtpsclean
$MAKE_PATH/make -f MakefileDevOps rtpsprocdirs
$MAKE_PATH/make -f MakefileDevOps rtpsall
$MAKE_PATH/make -f MakefileDevOps rtpscopy
$MAKE_PATH/make -f MakefileDevOps rtpstar

echo -e "\n DevOps compilation done \n"
