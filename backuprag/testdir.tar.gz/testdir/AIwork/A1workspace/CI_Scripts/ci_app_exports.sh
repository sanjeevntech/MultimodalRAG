#!/bin/sh

#Application name - configure
APP_NAME=HLR
export APP_NAME

##################################################################
################### Dependent for UT EXEC ########################
##################################################################

#application bin path - configure
releasepath=hlr_oss_install_"$SYSTEM_OS"_"$SYSTEM_HARDWARE"
BIN_DIR=$APP_ROOT/$releasepath/
ls -lrt $BIN_DIR > /dev/null
export BIN_DIR

#binary name - configure
UT_BIN_NAME=start_hss.sh
export UT_BIN_NAME

#LD_LIBRARY_PATH=$ORACLE_HOME/lib/:$GEN_UTIL_HOME/lib/:$ARGTABLE_PATH/lib/
#export LD_LIBRARY_PATH

#echo $LD_LIBRARY_PATH

#Arguments passed to binary for execution - configure
BIN_ARG="1"
export BIN_ARG


##################################################################
############## Dependent for Code Review Report ##################
##################################################################

#point to application obj directories - configure
#APP_OBJ_DIRS="-d $APP_ROOT/map-ng/application/objs/"
APP_OBJ_DIRS="-d $APP_ROOT/map-ng/application/objs/ -d $APP_ROOT/mod-mm/application/objs/ -d $APP_ROOT/mod-lte-mm/application/objs/ -d $APP_ROOT/mod-oam/application/objs/ -d $APP_ROOT/mod-si/application/objs/ -d $APP_ROOT/mod-subs-profiles/application/objs/ -d $APP_ROOT/mod-auc/application/objs/ -d $APP_ROOT/mod-ssm/application/objs/ -d $APP_ROOT/mod-cm/application/objs/ -d $APP_ROOT/mod-smsm/application/objs/ -d $APP_ROOT/mod-lte-mm2/application/objs/ -d $APP_ROOT/mod-lte-si/application/objs/ -d $APP_ROOT/mod-lte-sm/application/objs/ -d $APP_ROOT/mod-gprs/application/objs/ -d $APP_ROOT/IOLIB_SunOS/diameter-constants/objs/ -d $APP_ROOT/IOLIB_SunOS/map-constants/objs/ -d $APP_ROOT/rtps/server/objs/ -d $APP_ROOT/rtps/interfaces/objs/"
export APP_OBJ_DIRS 

#point to application directories what to exclude from code coverage - configure
# EXAMPLE: CRR_REMOVE_CONTENT="'$APP_ROOT_DIR/server/src/ut-src/*' '$APP_ROOT_DIR/interfaces/src/ut-src/*'"
CRR_REMOVE_CONTENT="'$APP_ROOT/map-ng/application/ut-src/*' '/usr/include/*' '*Dependency/*'" 
#CRR_REMOVE_CONTENT="'$APP_ROOT/map-ng/application/ut-src/' '/usr/include/c++/4.8.2'" 
export CRR_REMOVE_CONTENT

##################################################################
################### Dependent for CPPCHECK #######################
##################################################################

#Application include directory paths specify with eg: "-I INC_DIR1 -I INC_DIR2 -I INC_DIR3"  - configure
#APP_INC_DIRS="-I $APP_ROOT/map-ng/application/inc/"
APP_INC_DIRS="-I $APP_ROOT/mod-mm/application/inc/"
export APP_INC_DIRS

#Application src directory paths - configure
#APP_SRC_DIRS="$APP_ROOT/map-ng/application/src/*.cpp"
APP_SRC_DIRS="$APP_ROOT/mod-mm/application/src/*.cpp" 
export APP_SRC_DIRS

##################################################################
########################### DONE!!!  #############################
##################################################################

