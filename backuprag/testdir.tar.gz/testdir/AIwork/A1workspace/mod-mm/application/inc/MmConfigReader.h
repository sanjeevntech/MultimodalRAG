#ifndef __MM_CONFIG_READER_H
#define __MM_CONFIG_READER_H

#include <ConfigReader.h>
#include <SubsProfileData.h>
#include <HlrTdrFiller.h>
#include <vector>

typedef unsigned char   u8;

class MmConfigReader: public ConfigReader
{

   public:
      //u8 m_hlrAddr[16];
      int m_cancelTimer;
      int m_superCharge;
      int m_traceReqd;
      int m_isdRetry;
      int m_isdTimer;
      u8 m_nai[1];
      u8 m_npi[1];

      int m_IsdLen;
      int m_Version;
      int m_CL_Version;
      int m_CL_Invoke_Timer;
      int m_ISD_Invoke_Timer;

      int m_Cancel_Location_Timer;
      int m_Cancel_Location_Retry;
      int m_Congestion_CL_Retry_Attempts;

      //Added for CAMEL filtering of UPD
      bool m_Home_CAP_Filtering;
      bool m_Roam_CAP_Filtering;

      char m_home_cap_version[5];
      bool m_home_camel_one;
      bool m_home_camel_two;
      bool m_home_camel_three;
      bool m_home_camel_four;

      char m_roam_cap_version[5];
      bool m_roam_camel_one;
      bool m_roam_camel_two;
      bool m_roam_camel_three;
      bool m_roam_camel_four;
      
      bool m_Multi_Imsi_Reqd;
      int m_Multi_Imsi_ErrCode;
      bool m_SendCl;
      bool m_SendAscGprs;

      int m_MinFreeMsisdnThreshold;
      int m_MsisdnAllocErrCode;

      bool m_SendLCS_Details;
      bool m_GT_Transtlation_Reqd;

      int m_Dealloc_Msisdn_On_Fail;

      //Added in 1.0.11.0
      int m_send_cl_on_isd_failure;
      vector<string> m_cl_reason;

      int m_scpSSN;

      MmConfigReader();
      ~MmConfigReader();
       void printConfigData(char *p_output);
      bool readData();
};


extern MmConfigReader *g_MmConfigReaderObj;
extern bool DeclareFunc(int p_version, int p_pdu, void *p_struct);
#endif
