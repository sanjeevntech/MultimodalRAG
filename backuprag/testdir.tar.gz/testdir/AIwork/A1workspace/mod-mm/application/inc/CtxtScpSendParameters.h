#ifndef _CTXT_SEND_PARAM_H
#define _CTXT_SEND_PARAM_H


#include <ContextBase.h>
#include <MapMessages.h>
#include <MapConstants.h>
#include <Msg.h>
#include <MmDbQueries.h>
#include <MmConfigReader.h>
#include <IMAP1.h>
#include <OMAP1.h>
#include <CommonDefines.h>

class CtxtScpSendParameters : public ContextBase
{ 
   private:

      char m_imsi[15 + 1];
      char m_SCPAddress[20 + 1];
      u32 m_InitDlgId;
      EMapVersion m_MapVer;	
      EMapErrorCode m_ErrCode; 

      SendParamData *mp_sp;

   public:

      CtxtScpSendParameters();

      bool checkSendParameters(IMAP1_SendParametersArg *aSendParametersReq);
      bool handleError();
      bool handleDbQuery();
      bool sendSendParametersResp();
      bool processMessage(Msg *aMsgPtr,bool& aDeleteFlag);
      bool handleSendParameters(Msg *aMsgPtr, u32 aDlgId, EMapVersion aMapVer);

      virtual ~CtxtScpSendParameters();
};

#endif //_CTXT_SEND_PARAM_H
