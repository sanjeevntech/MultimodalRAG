#ifndef __CONTEXT_SEND_PARAMETERS_H
#define __CONTEXT_SEND_PARAMETERS_H

#include <ContextBase.h>
#include <MapMessages.h>
#include <MapConstants.h>
#include <Msg.h>
#include <MmDbQueries.h>
#include <IMAP1.h>
#include <OMAP1.h>
#include <ISDData.h>

#include <CommonDefines.h>

typedef unsigned char   u8;

class CtxtSendParameters : public ContextBase
{

   ISDData m_isd;


   enum error
   {
      SystemFailure = 1,
      UnknownSubscriber,
      DataMissing,
      UnexpectedData
   };

   enum m_callState
   {
      m_rsd,//Retrieve subscriber data
      m_psd,//Process subscriber data
      m_fid,//Fill ISD data
      m_sid,//Send ISD data
      m_usd //Update Subscriber data
   };

   enum CFWD
   {
      CFWD_UNCON = 0,
      CFWD_BUSY,
      CFWD_NOTREACH,
      CFWD_NOREPLY,
      CALL_DEF,
      DEF
   };

   enum CB
   {
      CB_BOAC = 0,
      CB_BOIC,
      CB_BOIHC,
      CB_BAIC,
      CB_BICR,
      DEFA
   };
   //int val;
   CFWD CFWD_STATE;
   CB CB_STATE;

   struct dbisd1
   {
      u8 msisdn[21];//msisdn
      int nwAccMode;
      int category;//category
      int subStatus;//subscriberStatus
      bool bearer;//bearerServiceList
      char bearerData[53];
      char teleData[33];
      bool provisionedSS;//provisionedSS
   }dbisd1;


   struct GsmProfile
   {
      u8 l_ActMsisdn[MAXISDNADDRLEN+1];
      u8 l_Actimsi[IMSILEN+1];
      u8 l_lmsino[LMSILEN+1];
      u8 l_vlrno[MAXISDNADDRLEN+1];
      u8 l_Mscno[MAXISDNADDRLEN+1];
      int l_mscRest;
      int l_ssInd;
      int l_msPur_gsm;
      int l_roamrestduf;
      int l_msgWait;
      int l_mnrr;
      int l_mnrf;
      int l_mcef;
      u8 l_ActHLRAddr[MAXISDNADDRLEN+1];
      int l_ActPnwId;
   }GsmProfile;

   struct GenProfile
   {
      int l_nwAccMode;
      int l_catgory;
      int l_subsRest;
      int l_accRest;
      int l_subsStatus;
      int l_lmu;
      int l_ist;
      char l_bearer[MAX_BEARER_COUNT+1];
      char l_tele[MAX_TELE_COUNT+1];
      int l_ocsiPid;
      int l_tcsiPid;
      int l_ugcsiPid;
      int l_sscsiPid;
      int l_tifcsiPid;
      int l_dcsiPid;
      int l_moscsiPid;
      int l_mtscsiPid;
      int l_gcsiPid;
      int l_mgcsiPid;
      int l_pdpPid;
   }GenProfile;

   u8 m_imsi[16];
   bool m_SendParamPresent;
   u8 m_VlrAddr[21];
   m_callState m_state;


   public: 
   CtxtSendParameters();
   virtual ~CtxtSendParameters();

   unsigned int index;
   unsigned int SsIndex;
   enum m_callState l_state;
   bool flag;
   int m_PrevSS;
   int m_SdLen;

   u8 m_AccId[MAX_ACCOUNTID_LEN+1];
   int m_nwId;
   u8 m_hlrAddr[MAXISDNADDRLEN+1];
   unsigned short m_GenOdb;
   unsigned short m_PlmnOdb;
   bool m_secondChunk;
   bool m_SecondBS;
   int pLen,len;


   bool processMessage(Msg *p_MsgPtr,bool &p_DeleteFlag);
   int  processDBData(int l_UserDlgId,RetrieveRSDData *l_rsd);  
   bool CheckParametersV1(int l_UserDlgId,IMAP1_SendParametersArg* l_temp);
   void RetErrorV1(int l_UserDlgId,int ErrorCode);
   void CloseReq(int l_UserDlgId);
   void ContinueReq(int l_UserDlgId);
   void RetrieveData(int l_UserDlgId);
   bool SendParamResp(int l_UserDlgId);
   bool FillSubsData(int l_UserDlgId,OMAP1_SendParametersRes *l_sp);
   bool sendRESULTNOTLAST(int DlgId,MapSpecificResult l_result,OMAP1_SendParametersRes *m_sp);
   bool sendRESULTLAST(int DlgId,MapSpecificResult l_result,OMAP1_SendParametersRes *m_sp);
   //Supplementary services
   int formFwdSS1(int DlgId,OMAP1_SS_InfoList &l_isd, int p_isdLen);
   int formCbSS1(int DlgId,OMAP1_SS_InfoList &l_isd, int p_isdLen);
   int formSsSS1(int DlgId,OMAP1_SS_InfoList &l_isd, int p_isdLen);

};
#endif
