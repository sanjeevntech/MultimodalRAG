#ifndef __CONTEXT_UPDATE_LOCATION_H
#define __CONTEXT_UPDATE_LOCATION_H

#include <ContextBase.h>
#include <MapMessages.h>
#include <MapConstants.h>
#include <Msg.h>
#include <MmDbQueries.h>
#include <MmConfigReader.h>
#include <IMAP1.h>
#include <OMAP1.h>
#include <IMAP2.h>
#include <OMAP2.h>
#include <IMAP3.h>
#include <OMAP3.h>
#include <CommonDefines.h>
#include <ISDData.h>

#define UPDV3_SUCCESS         1000
#define CAP_VALIDATION_FAILED 1001
#define CAP_PROFILE_NOT_FOUND 1002
#define SEND_ATM              1003

extern int g_EmergencyFlag;
typedef unsigned char   u8;
class CtxtUpdateLocation : public ContextBase
{
   private:

      int numOfParams;//Maintained as a index to set the  Current param position
      int csiParam;//for current csi param position
      int MoreData;//Flag to check more data to send in ISD
      ISDData m_isd;

      bool m_MoreDataToSend;
      int m_TraceErrorCode;
      bool m_TrapReqd;

      //MmConfigReader ConfigData;

      struct Details
      {
         u8 imsi[IMSILEN+1];
         u8 vlr[MAXISDNADDRLEN+1];
         u8 msc[MAXISDNADDRLEN+1];
         u8 lmsi[LMSILEN+1];
         char VlrCap_camel[5];
         short VlrCap_Phase;
         bool VlrCap_Camel1;
         bool VlrCap_Camel2;
         bool VlrCap_Camel3;
         bool VlrCap_Camel4;
         bool soLSA;
         int istSupportIndicator;
         bool SuperCharge;
         /*int SendISD;
           u8 dataAge[12];*/
         bool LongFTN;
         bool lcsCS1;
         bool lcsCS2;
         bool lcsCS3;
         bool lcsCS4;
         bool c4_oCSI;
         bool c4_dCSI;
         bool c4_vtCSI;
         bool c4_tCSI;
         bool c4_mtsCSI;
         bool c4_mgCSI;
         bool c4_psiCSI;
         bool utran;
         bool geran;
         bool lgIDSupp;
         bool informPreviousNetworkEntity;
         bool cs_LCS_NotSupportedByUE;
         u8 gmlc_Address[35];
         bool AddCapability;
         u8 imeisv[40];
         bool skipISDUpdate;
         int l_mtrf_support_ind;
         //s8 UpdLocResValue[7];
         u8 l_hlrno[MAXISDNADDRLEN+1];
      }l_updv3;

      unsigned char m_ExtnCntrData[200];
      struct CallDetails
      {
         u8 imsi[IMSILEN+1];
         u8 vlr[MAXISDNADDRLEN+1];
         u8 msc[MAXISDNADDRLEN+1];
         u8 lmsi[LMSILEN+1];
      }l_updv1,l_updv2;

      //Start For Restore data

      u8 m_SccpGt[MAXISDNADDRLEN+1];
      int m_imsOcsiProfId; //6.4.11.0

      //End For Restore data

      char m_SubsData[25][33];
      struct GsmProfile
      {
         u8 l_ActMsisdn[MAXISDNADDRLEN+1];
         u8 l_Actimsi[IMSILEN+1];
         u8 l_lmsino[LMSILEN+1];
         u8 l_vlrno[MAXISDNADDRLEN+1];
         u8 l_Mscno[MAXISDNADDRLEN+1];
         int l_mscRest;
         int l_ssInd;
         int l_msPur_gsm;
         int l_roamrestduf;
         int l_msgWait;
         int l_mnrr;
         int l_mnrf;
         int l_mcef;
         u8 l_ActHLRAddr[MAXISDNADDRLEN+1];
         int l_ActPnwId;
         int l_TraceFlag;
         unsigned char l_OmcId[MAXISDNADDRLEN+1];
         unsigned char l_TraceRef[5];
         unsigned char l_TraceType[5];
         int l_TraceStatus;
         unsigned char l_imeisv[40];
         u8 l_sgsnNum[MAXISDNADDRLEN+1];  //Added in 1.0.14.0
      }GsmProfile;

      struct GenProfile
      {
         int l_nwAccMode;
         int l_catgory;
         int l_subsRest;
         int l_accRest;
         int l_subsStatus;
         int l_lmu;
         int l_ist;
         char l_bearer[MAX_BEARER_COUNT+1];
         char l_tele[MAX_TELE_COUNT+1];
         int l_ocsiPid;
         int l_vtcsiPid;
         int l_ugcsiPid;
         int l_sscsiPid;
         int l_tifcsiPid;
         int l_dcsiPid;
         int l_moscsiPid;
         int l_mtscsiPid;
         int l_gcsiPid;
         int l_mgcsiPid;
         int l_pdpPid;
      }GenProfile;

      enum m_callState
      {
         m_rsd,//Retrieve subscriber data
         m_psd,//Process subscriber data
         m_atm,//sent Activte trace mode
         m_atmerr,//Received error for ATM
         m_fid,//Fill ISD data
         m_sid,//Send ISD data
         m_isderr,//received error for ISD
         m_usds, //Update Subscriber data on success
         m_usdf  //Update Subscriber data on failure
      };

      enum error
      {
         SystemFailure = 1,
         UnknownSubscriber,
         DataMissing,
         UnexpectedData,
         RoamingNotAllowed_plmn,
         RoamingNotAllowed_odb
      };


      bool flag;
      int m_UlInvokeId;
      int l_Version;
      int l_OpCode;
      enum m_callState l_state;
      enum error EMapErrorCode;

      //params for counting ISD
      unsigned int index;
      unsigned int VcsiIndex;
      unsigned int ScsiIndex;
      unsigned int SsIndex;

      bool m_SendATM;

      //params of DB query
      u8 l_AccId[MAX_ACCOUNTID_LEN+1];
      int l_nwId;
      int l_pnwId;
      int l_AlocType;
      u8 l_actMsisdn[MAXISDNADDRLEN+1];
      u8 l_priMsisdn[MAXISDNADDRLEN+1];
      u8 l_priImsi[IMSILEN+1];
      int l_roamInd;
      int l_mwd;
      u8 l_AlertMsisdn[MAXISDNADDRLEN+1];
      u8 l_hlrAddr[MAXISDNADDRLEN+1];
      unsigned int l_GenOdb;
      unsigned int l_PlmnOdb;
      bool m_ProvErrRcvd;
      char m_activeImsi[IMSILEN+1]; // added 6160

      //Added in 1.0.8.0
      int m_FirstUlFlag;
      int m_MsisdnAllocStatus;
      char m_UploadedMsisdn[21];
      char m_GSM_Seq_id[21];
      char m_VLR_Restricted_Bear_Codes[53];
      char m_VLR_Restricted_Tele_Codes[33];
      int  m_Cap_Failure_Action;
      char m_Cap_Action[5][30+1];
      //End Added in 1.0.8.0
      //
      bool m_fIsd;
      char m_TransId[21];
      unsigned char m_Orig_Imei[40];

   public:


      CtxtUpdateLocation();
      virtual ~CtxtUpdateLocation();
      //~CtxtUpdateLocation();

      bool processMessage(Msg *p_MsgPtr,bool &p_DeleteFlag);
      bool startProcessing(InterModuleData *p_imd,bool &p_DeleteFlag);
      //void OpenInd(MapOpenInd *l_test);
      bool CheckParametersV1(int l_UserDlgId,IMAP1_UpdateLocationArg* l_temp);
      bool CheckParametersV2(int l_UserDlgId,IMAP2_UpdateLocationArg *l_temp);
      bool CheckParametersV3(int l_UserDlgId,IMAP3_UpdateLocationArg *l_temp);
      int  processDBData(int l_UserDlgId,RetrieveSubsVLRData *l_rsd);
      int  UpdLocV3(int l_UserDlgId);
      bool UpdLocV2(int l_UserDlgId);
      bool UpdLocV1(int l_UserDlgId);
      void UpdLocV3Cont(int l_UserDlgId);
      void UpdLocV2Cont(int l_UserDlgId);
      void UpdLocV1Cont(int l_UserDlgId);
      void UpdLocV3_Cont(int l_UserDlgId);
      void UpdLocV2_Cont(int l_UserDlgId);
      void UpdLocV1_Cont(int l_UserDlgId);
      void CancelLocV1(u8 *imsi,u8 *hlrno,u8 *vlrno);
      void CancelLocV2(u8 *imsi,u8 *hlrno,u8 *vlrno);
      void CancelLocV3(u8 *imsi,u8 *hlrno,u8 *vlrno);

      void RetrieveData(int l_UserDlgId,u8 *imsi,u8 *vlr);
      void UpdateGsmData(int l_UserDlgId);
      void UpdateUpdFailData(int l_UserDlgId);

      //void updLocResV1(int l_UserDlgId,u8* hlrAddr);
      void updLocResV1(int l_UserDlgId);
      void updLocResV2(int l_UserDlgId);
      void updLocResV3(int l_UserDlgId);
      void GetISDdata(int l_UserDlgId);
      void startISDV3(int l_UserDlgId);
      void startISDV2(int l_UserDlgId);
      void startISDV1(int l_UserDlgId);
      void sendCheckSS();
      void SendMsgV1(int DlgId,MapSpecificRequest *l_request,OMAP1_InsertSubscriberDataArg *l_isd,unsigned int &numOfParam,unsigned int &SsParam);
      void SendMsgV2(int DlgId,MapSpecificRequest *l_request,OMAP2_InsertSubscriberDataArg *l_isd,unsigned int &numOfParam,unsigned int &SsParam);
      void SendMsgV3(int DlgId,MapSpecificRequest *l_request,OMAP3_InsertSubscriberDataArg *l_isd,unsigned int &numOfParam,unsigned int &VcsiParam,unsigned int &ScsiParam,unsigned int &SsParam);

      void RetErrorV1(int l_UserDlgId,int ErrorCode);
      void RetErrorV2(int l_UserDlgId,int ErrorCode);
      void RetErrorV3(int l_UserDlgId,int ErrorCode);
      void CloseReq(int l_UserDlgId);
      void ContinueReq(int l_UserDlgId);    
      void HandleError(int l_UserDlgId);

      //Added for Restore data
      bool CheckParametersRSDV2(int l_UserDlgId,IMAP2_RestoreDataArg *l_rd);
      bool CheckParametersRSDV3(int l_UserDlgId,IMAP3_RestoreDataArg *l_rd);
      void RsdRespV3(int l_UserDlgId,int mnrf);
      void RsdRespV2(int l_UserDlgId,int mnrf);
      //End Restore data               
      //

      //
      //Added to merge Send Parametes with UL
      //
      //
      unsigned int m_sp_index;
      unsigned int m_sp_SsIndex;
      //enum m_callState l_state;
      bool m_sp_flag;
      int m_sp_PrevSS;
      int m_sp_SdLen;

      //u8 m_AccId[MAX_ACCOUNTID_LEN+1];
      //int m_nwId;
      //u8 m_hlrAddr[MAXISDNADDRLEN+1];
      //unsigned short m_GenOdb;
      //unsigned short m_PlmnOdb;
      bool m_sp_secondChunk;
      bool m_sp_SecondBS;
      int m_sp_pLen,m_sp_len;
      u8 m_sp_imsi[16];
      bool m_sp_SendParamPresent;

      bool sp_CheckSendParametersV1(int l_UserDlgId,IMAP1_SendParametersArg* l_temp);
      bool sp_SendParamResp(int l_UserDlgId);
      bool sp_FillSubsDataForSp(int l_UserDlgId,OMAP1_SendParametersRes *l_sp);
      bool sp_sendRESULTNOTLAST(int DlgId,MapSpecificResult l_result,OMAP1_SendParametersRes *m_sp);
      bool sp_sendRESULTLAST(int DlgId,MapSpecificResult l_result,OMAP1_SendParametersRes *m_sp);
      //Supplementary services
      int sp_formFwdSS1(int DlgId,OMAP1_SS_InfoList &l_isd, int p_isdLen);
      int sp_formCbSS1(int DlgId,OMAP1_SS_InfoList &l_isd, int p_isdLen);
      int sp_formSsSS1(int DlgId,OMAP1_SS_InfoList &l_isd, int p_isdLen);
      //
      //End Additions for Send Parameters
      //

      void sendCLforFupd();

      string m_DataString;

};


#endif


