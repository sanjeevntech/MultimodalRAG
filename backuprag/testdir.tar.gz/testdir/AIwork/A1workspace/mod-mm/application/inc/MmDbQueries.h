#ifndef __MM_DB_QUERIES_H
#define __MM_DB_QUERIES_H

#include <DbQueryMsg.h>
#include <CommonDefines.h>
typedef unsigned char   u8;

class OssTriggerDataGsm
{
   public:
      OssTriggerDataGsm();
      ~OssTriggerDataGsm();
      char  m_rowId[MAX_ROW_ID_LEN+1];
};

class RetrieveSubsVLRData : public DbQueryMsg
{
   public:
      u8  m_imsi[IMSILEN+1];
      u8  m_vlr[MAXISDNADDRLEN+1];
      int m_OpCode;
      //Additions in 1.0.8.0
      //
      //int m_Home_CAP_Validation_Reqd;
      //int m_Roam_CAP_Validation_Reqd;
      //u8  m_Supported_CAP_Home[5];
      //u8  m_Supported_CAP_Roam[5];
      int m_VLR_Supported_Max_CAP_Phase;
      int m_UPD_Version;
      int m_mtrf_support_ind;
      int m_full_isd_ind;
      u8  m_lmsi[5];
      u8  m_msc[MAXISDNADDRLEN+1];
      int m_CamPha;
      int m_Solsa;
      int m_IST;
      int m_SupChrg;
      int m_LongFTN;
      int m_SuppLCS;
      int m_OffCAM;
      u8 m_IMEISV[40];
      u8 m_Orig_Imei[40];
      u8 m_cs_v_gmlc_Address[34+1];
      int m_cs_LCS_SupportedByUE;
      //End Additions in 1.0.8.0
      //
      u8  m_AccId[MAX_ACCOUNTID_LEN+1];
      int m_nwid;
      int m_pnwid;
      int m_AlocType;
      u8  m_ActMsisdn[MAXISDNADDRLEN+1];
      u8  m_PriMsisdn[MAXISDNADDRLEN+1];
      u8  m_AlrtMsisdn[MAXISDNADDRLEN+1];
      u8  m_PriImsi[IMSILEN+1];
      int m_MWD;
      u8  m_AlertMsisdn[MAXISDNADDRLEN+1];
      int m_RoamIND;
      u8  m_HlrADDR[MAXISDNADDRLEN+1];
      u8  m_GenINFO[MAX_PROF_LEN+1];
      u8  m_GsmINFO[MAX_PROF_LEN+1];
      int m_ssCount;
      u8  m_SSDATA[MAX_SS_DATA][MAX_SS_DATALEN];
      int m_CFCount;
      u8  m_CFData[MAX_CFWD_DATA][MAX_CFWD_DATALEN];
      int m_CBCount;
      u8  m_CBData[MAX_CB_DATA][MAX_CB_DATALEN];
      int m_LiCount;
      u8  m_LiData[MAX_LI_DATA][MAX_LI_DATALEN];
      int m_CWCount;
      u8  m_CWData[MAX_CW_DATA][MAX_CW_DATALEN];
      u8  m_MCData[MAX_MC_DATALEN];
      u8  m_EmlppData[MAX_EMLPP_DATALEN];
      int m_partType;
      int m_AssumeCap1Support;
      u8  m_OldMsisdn[MAXISDNADDRLEN+1];
      int m_MsisdnAllcatedStatus;
      int m_RemainingMsisnd;
      int m_FirstUL;
      int m_gsmFul;
      int m_DynMsisdnMinFreeThreshold;              //Added in HLR 5.0.3.0
      char m_AltFlagCampaignId[10+1];                  //5054
      u8 m_AltImsi[IMSILEN+1];                     //5054
      char m_AreaCodeBasedAllocInfo[100+1];
      char m_TrapCode[50+1];
      char m_TrapDesc[500+1];
      int m_First_Roam_To_Home_Flag;
      char m_CC_Info[150+1];
      int m_EmergencyFlag;
      int m_ErrorCode;
      int m_PrevImsiPartType;
      //Added in 1.0.8.0
      u8  m_GSM_Seq_id[21]; 
      u8  m_rest_tele_code[33];
      u8  m_rest_bear_code[53];
      u8  m_TdrData[200+1];
      int m_Non_Camel_Action;
      //End Addition in 1.0.8.0
      // 1.0.13.2 Begin
      //int               m_ossTriggerDataCount;
      //OssTriggerDataGsm    m_ossTriggerDataArray[MAX_OSS_TRIGGER_DATA];
      //char                 m_ossTriggerDataVarchar[300];
      // 1.0.13.2 End
      u8  m_ErrorMsg[MAX_ERRORMSG_LEN];
      int m_localImsiSubscription;
      char m_roamCC[10 + 1];
      // 1.0.15.0 Begin
      u8  m_LocalMsisdn[MAXISDNADDRLEN+1];
      u8  m_LocalImsi[IMSILEN+1];
      int m_ImsiPreBurnt;
      int m_freeCount;
      int m_threshCount;
      char m_SimStructure[30 + 1];
      // 1.0.15.0 End
      int m_transFreeCount;
      int m_transThreshCount;

      u8 m_localRoamInfo[100 + 1];
      u8 m_tdrResrvData[100 + 1];

      int                  m_ossTriggerDataCount_OUT;
      u8                   m_ossTriggerData_OUT[10][5000 + 1];

      u8 m_TdrRestrData[300 + 1];
      u8 m_TdrProfData[100 + 1];
      char m_generalTDRdata[1000 + 1];

      char m_log_message[3000 + 1];
      char m_IsrImsi[IMSILEN+1];
      char m_qSpaErrMsg[100+1];

      int m_crossClType_OUT;

      char m_TemplateFtnInfo_OUT[50+1]; //6.2.0.0

      char m_AllocImsiApi_OUT[50+1]; //6.3.0.0
      char m_MnoProvisioningTdr_OUT[30+1]; //6.3.5.0
      char m_AllowRestoreData_OUT[20+1]; //6.4.0.0

      char m_StatsInfo_OUT[500+1]; //6.4.1.0
      int m_PrimaryIndicator_OUT;//6.4.2.0
      char m_DualImsiInfo_OUT[50+1]; //6.4.4.0
      int m_ul_mpg_indicator_OUT;   //6.4.4.1

      bool executeQuery(void*);
      RetrieveSubsVLRData();
      virtual ~RetrieveSubsVLRData();
};


class UpdateVLRData : public DbQueryMsg
{
   public:
      u8 m_AccId[MAX_ACCOUNTID_LEN+1];
      int m_nwid;
      u8 m_ActMsisdn[MAXISDNADDRLEN+1];
      u8 m_ActImsi[IMSILEN+1];
      int m_roamInd;
      u8 m_lmsi[MAXISDNADDRLEN+1];
      u8 m_vlr[MAXISDNADDRLEN+1];
      u8 m_msc[MAXISDNADDRLEN+1];
      int m_mscRest;
      int m_ssInd;
      int m_purge;
      int m_MNRR;
      int m_MNRF;
      int m_RRDUF;
      u8  m_hlr[MAXISDNADDRLEN+1];
      int m_MsisdnTyp;
      int m_pnwid;
      unsigned short m_CamPhases;
      int m_solsa;
      int m_ist;
      int m_SuprChrg;
      int m_LongFTN;
      unsigned short m_SuppLCS;
      unsigned short m_OffCSI;
      unsigned char m_Unsupp_Bearer[53];  
      unsigned char m_Unsupp_Tele[33]; 
      unsigned char m_Unsupp_SuppServ[201];   
      unsigned int m_Unsupp_GenOdb;   
      unsigned int  m_AtmErrorCode;
      unsigned char m_IMEISV[40];     
      int m_cs_LCS_SupportedByUE;
      unsigned char m_cs_v_gmlc_Address[34+1];
      //Modified in HLR 1.0.8.0, for Deallocation on MSISDN on First UL failure for Dynamic case
      int m_AllocStatus;
      int m_FirstUl;
      int m_DeallocMsisdn;
      u8  m_GSM_Seq_id[21]; //1.0.8.0 
      //End Modified in HLR 1.0.8.0
      int m_ErrorCode;
      u8 m_ErrorMsg[MAX_ERRORMSG_LEN];
      bool executeQuery(void*);
      UpdateVLRData();
      virtual ~UpdateVLRData();
};

class PurgeMS : public DbQueryMsg
{
   public:
      u8 m_imsi[IMSILEN+1];
      u8 m_number[MAXISDNADDRLEN+1];      
      int m_flag;
      u8 m_HlrAddr[MAXISDNADDRLEN+1];
      int m_ImsiPartType;
      int m_nwid;
      int m_ErrorCode;
      char m_ErrorMsg[MAX_ERRORMSG_LEN];
      bool executeQuery(void*);
      PurgeMS();
      virtual ~PurgeMS();
};
#if 0
class RetrieveRSDData : public DbQueryMsg
{
   public:
      u8 m_imsi[IMSILEN+1];
      u8 m_lmsi[LMSILEN];
      u8 m_vlrAddr[MAXISDNADDRLEN+1];      
      u8 m_AccId[MAX_ACCOUNTID_LEN+1];
      int m_nwid;
      int m_pnwid;
      u8 m_GenINFO[MAX_PROF_LEN+1];
      u8 m_GsmINFO[MAX_PROF_LEN+1];
      int m_ssCount;
      u8  m_SSDATA[MAX_SS_DATA][MAX_SS_DATALEN];
      int m_CFCount;
      u8  m_CFData[MAX_CFWD_DATA][MAX_CFWD_DATALEN];
      int m_CBCount;
      u8  m_CBData[MAX_CB_DATA][MAX_CB_DATALEN];
      int m_LiCount;
      u8  m_LiData[MAX_LI_DATA][MAX_LI_DATALEN];
      int m_CWCount;
      u8  m_CWData[MAX_CW_DATA][MAX_CW_DATALEN];
      u8  m_MCData[MAX_MC_DATALEN];
      u8  m_EmlppData[MAX_EMLPP_DATALEN];
      int m_partType;
      int m_AssumeCap1Support;
      int m_ErrorCode;
      u8 m_ErrorMsg[MAX_ERRORMSG_LEN];
      bool executeQuery(void*);
      RetrieveRSDData();
      virtual ~RetrieveRSDData();
};
#endif

class UpdateDBStatus : public DbQueryMsg
{
   public:
      UpdateDBStatus();
      virtual ~UpdateDBStatus();

      bool executeQuery(void*);

      // Inputs
      char  m_TransId[21];
      char m_Status;
      char m_ErrorCause[100+1];
      char m_IMSI[IMSILEN+1];;
      int  m_TYPE;
      int m_DontUpdateFail;
      //output
      int m_ErrorCode_OAM;
      u8 m_ErrorMsg_OAM[MAX_ERRORMSG_LEN];
};

class UpdSubsData : public DbQueryMsg
{
   public:
      UpdSubsData();
      virtual ~UpdSubsData();

      bool executeQuery(void*);

      char m_imsi[21];
      int m_type;
      int m_ClearingMethod;
      char m_Node[21];
      //output
      int m_ErrorCode_CL;
      u8 m_ErrorMsg_CL[MAX_ERRORMSG_LEN];
};

class IsCurrentNode : public DbQueryMsg
{
   public:
      IsCurrentNode();
      virtual ~IsCurrentNode();

      //In
      char m_imsi[21];
      char m_Node[21];
      int m_Nodetype;

      //Out
      int m_Result;
      int m_ErrorCode;
      char m_ErrorMsg[201];

      bool executeQuery(void*);
};

class UpdTransStatus : public DbQueryMsg
{
   public:
      UpdTransStatus();
      virtual ~UpdTransStatus();

      //In
      char m_allocMsisdn[21];

      //Out
      int m_ErrorCode;
      char m_ErrorMsg[201];

      bool executeQuery(void*);
};

class SendParamData : public DbQueryMsg
{
   public:
      SendParamData();
      virtual ~SendParamData();

      //In
      char m_imsi[15 + 1];
      char m_SCPAddress[20 + 1];

      //Out
      int m_networkId;
      int m_partnerNetworkId;
      int  m_CFCount;
      char m_CFData[MAX_CFWD_DATA][MAX_CFWD_DATALEN];
      char m_HlrAddr[20 + 1];
      char m_PrimaryMsisdn[20 + 1];
      char m_PrimaryImsi[15 + 1];
      char m_ActiveMsisdn[20 + 1];
      int m_ErrorCode;
      char m_ErrorMsg[201];

      bool executeQuery(void*);
};

#endif
