#ifndef __VLR_CAMEL_SUBSINFO_H
#define __VLR_CAMEL_SUBSINFO_H

#include <MapMessages.h>
#include <MapConstants.h>
#include <Msg.h>
#include <MmDbQueries.h>
#include <OMAP3.h>

typedef unsigned char   u8;   /* Exactly one byte (8 bits) */
typedef unsigned short u16;
typedef char            s8;

class VlrCamelSubsinfo
{
   public:

      struct vcsi
      {
         int roamInd;
         u16 nwId;
         u16 PnwId;
         int rcvd_camel_phase;
         int ocsi;
         int sscsi;
         int tifcsi;
         int dcsi;
         int vtcsi;
         int mcsi;
         int mosmscsi;
         int mtsmscsi;
      }vcsi;
      u16 l_OutScfAddrLen;
      VlrCamelSubsinfo();
      virtual ~VlrCamelSubsinfo();
      
#if 0
      bool ValidateAllCsi(int DlgId,int OcsiPid,int SscsiPid,int TifcsiPid,int DcsiPid,int MosmscsiPid,int MtsmscsiPid);
      void formOCsi(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd);
      void formTifCsi(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd);
      void formSsCsi(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd);
      void formObcsmTdp(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd);
      void formDCsi(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd);
      void formTCsi(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd);
      void formTbcsmTdp(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd);
      void formMosCsi(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd);
      void formMtsCsi(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd);
      void formMtsTdp(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd);
#endif

      bool ValidateAllCsi(int DlgId,int OcsiPid,int SscsiPid,int TifcsiPid,int DcsiPid,int MosmscsiPid,int VtcsiPid,int MtsmscsiPid);      
      void formOCsi(OMAP3_InsertSubscriberDataArg *l_isd);
      void formTifCsi(OMAP3_InsertSubscriberDataArg *l_isd);
      void formSsCsi(OMAP3_InsertSubscriberDataArg *l_isd);
      void formObcsmTdp(OMAP3_InsertSubscriberDataArg *l_isd);
      void formDCsi(OMAP3_InsertSubscriberDataArg *l_isd);
      void formVTCsi(OMAP3_InsertSubscriberDataArg *l_isd);
      void formVTbcsmTdp(OMAP3_InsertSubscriberDataArg *l_isd);
      void formMosCsi(OMAP3_InsertSubscriberDataArg *l_isd);
      void formMtsCsi(OMAP3_InsertSubscriberDataArg *l_isd);
      void formMtsTdp(OMAP3_InsertSubscriberDataArg *l_isd);
      s8* getPartnerGsmScfAddr(s8 * aGsmScfAddr,u16 &aOutScfAddrLen,u16 aNkId,u16 aPnkId);
};
#endif
