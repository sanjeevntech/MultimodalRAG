#ifndef __ISDDATA_H
#define __ISDDATA_H

#include <MapMessages.h>
#include <MapConstants.h>
#include <Msg.h>
#include <MmDbQueries.h>
#include <IMAP1.h>
#include <OMAP1.h>
#include <IMAP2.h>
#include <OMAP2.h>
#include <IMAP3.h>
#include <OMAP3.h>
#include <VlrCamelSubsinfo.h>
#include <ProvisionedSS.h>
#include <SgsnCamelSubsinfo.h>
#include <GprsSubscriptioninfo.h>
#include <BasicService.h>


typedef unsigned char u8;   /* Exactly one byte (8 bits) */


class ISDData
{
   public:
      int MsgOpCode;
      int PrevSS;
      int IsdLen;

      int len;
      int pLen;

      VlrCamelSubsinfo vlrcsi;      
      provisionedSS pss;            
      SgsnCamelSubsinfo Sgsncsi;    
      GprsSubscriptioninfo gprssi;  
      basicService bs;              

      bool m_SecondChunk;
      unsigned char m_Unsupp_Bearer[53];
      unsigned char m_Unsupp_Tele[33];
      unsigned char m_Unsupp_SS[201];
      unsigned int  m_Unsupp_ODB;
      bool m_IsdResp_With_Unsupp_Service_Rcvd;//Added in 1.0.8.0
      bool m_AllDataAdded;


      struct dbisd3
      {
         bool imsiReqd;
         u8 imsi[16];
         bool msisdnReqd;
         u8 msisdn[20];
         int category;
         int subStatus;
         bool bearer;//bearerServiceList
         char bearerData[53];
         char teleData[33];
         int provisionedSS;
         int ssInfoCount;
         bool odb_Data;
         bool odb_GenData;
         unsigned int odb_Genvalue;
         bool odb_HplmnData;
         unsigned int odb_HplmnValue;
         int rr_duf;//Nulltype roamingRestrictionDueToUnsupportedFeature
         int zC;//regionalSubscriptionData
         int zC_Count;
         u8 zC_Value[10];
         int VGCS;//vgcsSubscriptionData
         bool VLRCsi;//Flag to indicate presence vlrCamelSubscriptionInfo
         int CamelPhase;
         int gprsSubsData;//gprsSubscriptionData
         int lmu;
         int rrs_duf;//Nulltype        roamingRestrictedInSgsnDueToUnsupportedFeature
         bool nwmReqd;
         int nwAccMode;//networkAccessMode
         unsigned short istvalue;
         int mcSSInfo;
         bool sgsncsi;//Flag to indicate presence of sgsn_CAMEL_SubscriptionInfo
         u8  ChrgChar[2];
         int accrest;//accessRestrictionData
         u8 accrestvalue;
         bool LcsIndicatorPresent;
      }dbisd3;

      struct dbisd2
      {
         bool imsiReqd;
         u8 imsi[16];//imsi
         bool msisdnReqd;
         u8 msisdn[20];//msisdn
         int nwAccMode;
         int category;//category
         int subStatus;//subscriberStatus
         bool bearer;//bearerServiceList
         char bearerData[52+1];
         char teleData[32+1];
         int provisionedSS;//provisionedSS
         bool odb_Data;//odb_Data
         bool odb_GenData;
         unsigned int odb_Genvalue;
         bool odb_HplmnData;
         unsigned int odb_HplmnValue;
         int rr_duf;//Nulltype roamingRestrictionDueToUnsupportedFeature
         int zC;//regionalSubscriptionData
         int zC_Count;
         u8 zC_Value[10];
      }dbisd2;

      struct dbisd1
      {
         bool imsiReqd;
         u8 imsi[16];//imsi
         bool msisdnReqd;
         u8 msisdn[20];//msisdn
         int nwAccMode;
         int category;//category
         int subStatus;//subscriberStatus
         bool bearer;//bearerServiceList
         char bearerData[52+1];
         char teleData[32+1];
         bool provisionedSS;//provisionedSS
      }dbisd1;

      unsigned int m_MM_TDR_CSI_FLAGS;

      ISDData();
      virtual ~ISDData();

      bool FormISDReqV3(int l_UserDlgId,unsigned int &index,unsigned int &VcsiIndex,unsigned int &ScsiIndex,unsigned int &SsIndex,bool flag,struct dbisd3,int &opCode,OMAP3_InsertSubscriberDataArg *l_isd);
      bool FormISDReqV2(int l_UserDlgId,unsigned int &index,unsigned int &SsIndex,bool flag,struct dbisd2,int &opCode,OMAP2_InsertSubscriberDataArg *l_isd);//u8 *l_imsi,u8 *l_basicMsisdn,
      bool FormISDReqV1(int l_UserDlgId,unsigned int &index,unsigned int &SsIndex,bool flag,struct dbisd1,int &opCode,OMAP1_InsertSubscriberDataArg *l_isd);//u8 *l_imsi,u8 *l_basicMsisdn,



      int CheckLengthV1(OMAP1_InsertSubscriberDataArg *l_isd);
      int CheckLengthV2(OMAP2_InsertSubscriberDataArg *l_isd);
      int CheckLengthV3(OMAP3_InsertSubscriberDataArg *l_isd);
      bool ProcessIsdResV1(int l_UserDlgId,IMAP2_InsertSubscriberDataRes *ISD_Res,int &opCode);
      //bool ProcessIsdResV2(int l_UserDlgId,IMAP2_InsertSubscriberDataRes *ISD_Res,int &opCode);
      bool ProcessIsdResV2(int l_UserDlgId,IMAP2_InsertSubscriberDataRes *ISD_Res);
      bool ProcessIsdResV3(int l_UserDlgId,IMAP3_InsertSubscriberDataRes *ISD_Res);


};

#endif
