#ifndef __STAND_ALONE_ISD_H
#define __STAND_ALONE_ISD_H

#include <ContextBase.h>
#include <MapMessages.h>
#include <MapConstants.h>
#include <Msg.h>
#include <MmDbQueries.h>
#include <MmConfigReader.h>
#include <IMAP1.h>
#include <OMAP1.h>
#include <IMAP2.h>
#include <OMAP2.h>
#include <IMAP3.h>
#include <OMAP3.h>
#include <ISDData.h>


typedef unsigned char   u8;
typedef char            s8;
class StandaloneISD : public ContextBase
{
   private:

      ISDData m_isd;

      unsigned int l_Version;
      unsigned int index;
      unsigned int SsIndex;
      unsigned int VcsiIndex;
      unsigned int ScsiIndex;
      bool flag;
      bool m_ErrorRcvd;
      bool m_NoticeRcvd;
      bool m_OpenCnfRcvd;
      bool m_FirstFilled;
      
      string l_imsi;
      string l_lmsi;
      string l_NodeType;
      int m_ssn;
      string l_destAddress;
      string l_mscNumber;
      string l_origAddress;
      
      bool   l_somethingToSendPresent;
      bool   l_ssPresent;
      bool   l_VcsiPresent;
      bool   l_ScsiPresent;
      bool   l_pdpInfoPresent;
      string l_msisdn;
      string l_bearerService;
      string l_teleService;
      string l_ssList;
      string l_vcsi;
      string l_scsi;
      string l_ODB;
      string l_pdpDetails;
      bool m_ODBflag;
      bool odb_Data;
      bool odb_GenData;
      unsigned int odb_Genvalue;
      bool odb_HplmnData;
      unsigned int odb_HplmnValue;

      int m_Roaming_indicator;
      bool m_Odb_Rejected_in_ISD_Resp;

   public:
      StandaloneISD();
      virtual ~StandaloneISD();

      bool processMessage(Msg *p_MsgPtr,bool &p_DeleteFlag);
      bool startProcessing(InterModuleData *p_imd,bool &p_DeleteFlag);
      bool FormISDV3();
      //bool FillIsdV3(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd);
      bool FillIsdV3(OMAP3_InsertSubscriberDataArg *l_isd);
      bool FormISDV2();
      //bool FillIsdV2(int DlgId,OMAP2_InsertSubscriberDataArg *l_isd);
      bool FillIsdV2(OMAP2_InsertSubscriberDataArg *l_isd);
      bool FormISDV1();
      //void FillIsdV1(int DlgId,OMAP1_InsertSubscriberDataArg *l_isd);
      bool FillIsdV1(OMAP1_InsertSubscriberDataArg *l_isd);
      bool Validate4LFTN();
      int CheckLengthV3(OMAP3_InsertSubscriberDataArg *l_isd);
      int CheckLengthV2(OMAP2_InsertSubscriberDataArg *l_isd);
      int CheckLengthV1(OMAP1_InsertSubscriberDataArg *l_isd);
      void updateDb(char p_status, char *p_error);
      bool OpenCnf(MapOpenCnf *l_oCnf);


      int l_isdDlgId;
      char m_TransId[21];
      char m_Orginator[20];
      bool m_UpdateReqd;
      string m_DataString;

      bool m_updateDbCalledFlag; //Added in 1.0.11.0 to not repeat calling of updateDb func in a Close Ind followed by Spec Msg Ind

};
#endif
