#ifndef _CtxtSimRestoreData_h
#define _CtxtSimRestoreData_h
#include <ContextBase.h>
#include <Msg.h>
#include <MapConstants.h>

class CtxtSimRestoreData : public ContextBase
{
   private:

   public:
      CtxtSimRestoreData();
      bool processMessage(Msg *p_MsgPtr,bool& p_DeleteFlag);
      bool startProcessing();
      bool sendRestoreDataReq();
      virtual ~CtxtSimRestoreData();
};

#endif

