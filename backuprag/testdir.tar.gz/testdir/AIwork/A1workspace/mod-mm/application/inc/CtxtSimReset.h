#ifndef __CONTEXT_SIM_RESET_H
#define __CONTEXT_SIM_RESET_H

#include <ContextBase.h>
#include <Msg.h>
#include <MapConstants.h>
#include <string>
using namespace std;

class CtxtSimReset : public ContextBase
{
	public:
		CtxtSimReset();
		~CtxtSimReset();
		bool processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag);
};



#endif
