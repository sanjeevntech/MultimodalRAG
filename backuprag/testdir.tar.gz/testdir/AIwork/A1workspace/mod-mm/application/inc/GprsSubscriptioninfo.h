#ifndef __GPRS_SUBS_INFO_H
#define __GPRS_SUBS_INFO_H

#include <MapMessages.h>
#include <MapConstants.h>
#include <Msg.h>
#include <MmDbQueries.h>

typedef unsigned char   u8;   /* Exactly one byte (8 bits) */

class GprsSubscriptioninfo
{
   public:

      int PdpId;
      int m_NwId;
      int m_PNwId;
      int m_FormedTill;

      bool m_completeDataListIncluded;
      string m_contextList;
      string m_IPv4Addr;     //5054
      string m_IPv6Addr;     //5054
      int m_ApnOiOverrideIndicator; //6.3.5.0

      GprsSubscriptioninfo();
      virtual ~GprsSubscriptioninfo();
      int formgprssi(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd,int len);
      void convertIPV4toHex(char * apIPv4Addr,unsigned char *apAddrInHex);
      s8* getPartnerAPN(s8 *aAPN,u16 aNkId,u16 aPnkId);
};
#endif
