#ifndef __CONTEXT_CANCEL_LOCATION_H
#define __CONTEXT_CANCEL_LOCATION_H

#include <ContextBase.h>
#include <MapMessages.h>
#include <MapConstants.h>
#include <Msg.h>
#include <MmDbQueries.h>
#include <MmConfigReader.h>
#include <CommonDefines.h>
#include <IMAP1.h>
#include <OMAP1.h>
#include <IMAP2.h>
#include <OMAP2.h>
#include <IMAP3.h>
#include <OMAP3.h>

extern int g_EmergencyFlag;

typedef unsigned char   u8;
typedef char            s8;
typedef unsigned short  u16;
class CtxtCancelLocation : public ContextBase
{
   private:
      u8 imsi[IMSILEN + 1];
      u8 lmsi[LMSILEN + 1];
      u8 vlrno[MAXISDNADDRLEN + 1];
      u8 hlrno[MAXISDNADDRLEN + 1];
      u8 m_new_vlr_num[MAXISDNADDRLEN + 1];
      u8 m_new_msc_num[MAXISDNADDRLEN + 1];
      u8 m_new_lmsi[LMSILEN + 1];
      int cause;
      int m_ssn;
      int m_UpdateSubsDataTable;

      int m_Avoid_Capturing_fail;
      string m_InitiatedFor;
      int m_mtrf_support_ind;
      int m_mtrf_authorized_ind;

      int m_networkId;
   public:
      CtxtCancelLocation();
      virtual ~CtxtCancelLocation();

      bool processMessage(Msg *p_MsgPtr, bool &p_DeleteFlag);
      bool startProcessing(InterModuleData *p_imd,bool &p_DeleteFlag);
      bool SendCancelLocationV3();
      bool SendCancelLocationV2(); 
      bool SendCancelLocationV1();
      void CloseReq(int l_UserDlgId);
      void ContinueReq(int l_UserDlgId);
      void OpenCnf(MapOpenCnf *l_oCnf);
      void updateDb(char p_status, char *p_error);
      void UpdateSubsData(u8 *l_imsi);
      int m_timerId;
      int m_retryCount;

      char m_TransId[21];
      char m_Orginator[21];
      bool m_UpdateReqd;
      string m_DataString;
      int l_Version;
      //Added in 1.0.5.0
      void CheckIsCurrentNode();
      int  m_callState;
      //End 1.0.5.0

      //Added in 1.0.11.0
      int  m_SendPrn;
      char m_msc_no[21];
      //End 1.0.11.0
         
      // 1.0.16.0 Begin
      char m_CLreason[100];
      void UpdateTransStatusDB();
      char m_allocMsisdn[21];
      // 1.0.16.0 End

      bool m_crossCL; //2.0.21.0
      int m_Emergency_CL_Retry_Attempts;
};


extern void FormXMLRequest(char *XmlReq,int NodeType,u8 *imsi,u8 *lmsi,u8 *l_ActHLRAddr,u8 *l_vlrno,int updateSubsdata,int p_ImsiType,char *p_requestType,char *p_msc);
extern unsigned int map3tomap2odb(unsigned int GeneralOdb);
extern void dec2bin(unsigned int decimal, char *binary);
extern unsigned int HplmnOdb(unsigned int hplmn);
extern unsigned short itoChar(unsigned char *character, unsigned int deci);
extern bool fillAtmV1(int DlgID,unsigned char *TraceRef,unsigned char *TraceType,unsigned char *Omc_ID,OMAP1_ActivateTraceModeArg *l_atm);
extern bool fillAtmV2(int DlgID,unsigned char *TraceRef,unsigned char *TraceType,unsigned char *Omc_ID,OMAP2_ActivateTraceModeArg *l_atm);
extern bool fillAtmV3(int DlgID,unsigned char *TraceRef,unsigned char *TraceType,unsigned char *Omc_ID,OMAP3_ActivateTraceModeArg *l_atm);
//extern bool GetNetworkHlrAddr(u8* p_NetworkHlrAddr, u8 *p_OriginalHlrAddr);
#endif
