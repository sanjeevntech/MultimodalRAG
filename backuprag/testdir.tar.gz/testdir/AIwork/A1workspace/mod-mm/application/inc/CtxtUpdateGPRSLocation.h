#ifndef __CONTEXT_UPDATE_GPRS_LOCATION_H
#define __CONTEXT_UPDATE_GPRS_LOCATION_H

#include <ContextBase.h>
#include <MapMessages.h>
#include <MapConstants.h>
#include <Msg.h>
#include <MmSgsnDbQueries.h>
#include <ISDData.h>
#include <CommonDefines.h>
#include <IMAP3.h>
#include <OMAP3.h>

typedef unsigned char   u8;

#define UPGV3_SUCCESS         1000
#define CAP_VALIDATION_FAILED 1001
#define CAP_PROFILE_NOT_FOUND 1002
#define SEND_ATM              1003

extern int g_EmergencyFlag;
class CtxtUpdateGPRSLocation : public ContextBase
{
   private:


      enum m_callState
      {
         m_rsd,//Retrieve subscriber data
         m_psd,//Process subscriber data
         m_atm,//Sent ATM
         m_fid,//Fill ISD data
         m_sid,//Send ISD data
         m_usd, //Update Subscriber data
         m_usdf //Update Subscriber data on UPG Fail
      };

      struct GenProfile
      {
         int l_nwAccMode;
         int l_catgory;
         int l_subsRest;
         int l_accRest;
         int l_subsStatus;
         int l_lmu;
         int l_ist;
         char l_bearer[MAX_BEARER_COUNT];
         char l_tele[MAX_TELE_COUNT];
         int l_ocsiPid;
         int l_tcsiPid;
         int l_ugcsiPid;
         int l_sscsiPid;
         int l_tifcsiPid;
         int l_dcsiPid;
         int l_moscsiPid;
         int l_mtscsiPid;
         int l_gcsiPid;
         int l_mgcsiPid;
         int l_pdpPid;
      }GenProfile;

      struct GprsProfile
      {
         u8 l_ActMsisdn[MAXISDNADDRLEN+1];
         u8 l_Actimsi[IMSILEN+1];
         int l_roamInd;
         u8 l_sgsnno[MAXISDNADDRLEN+1];
         u8 l_sgsnAddr[MAXISDNADDRLEN+1];
         int l_sgsnRest;
         int l_msPur_gprs;
         int l_mnrg;
         int l_roamrestduf;
         int l_pdpId;
         u8 l_ActHLRAddr[MAXISDNADDRLEN+1];
         int l_ActPnwId;
         int l_TraceFlag;
         unsigned char l_OmcId[MAXISDNADDRLEN+1];
         unsigned char l_TraceRef[5];
         unsigned char l_TraceType[5];
         int l_TraceStatus;
         u8 l_lmsino[LMSILEN+1];
         u8 l_vlrNum[MAXISDNADDRLEN+1];
      }GprsProfile;

      enum error
      {
         SystemFailure = 1,
         UnknownSubscriber_imsiUnknown,
         DataMissing,
         UnexpectedData,
         RoamingNotAllowed_plmn,
         RoamingNotAllowed_odb,
         UnknownSubscriber_gprsUnknown
      };

      ISDData m_isd;

      bool flag;
      int l_Version;
      enum m_callState l_state;
      enum error EMapErrorCode;
      unsigned int index;
      unsigned int VcsiIndex;
      unsigned int ScsiIndex;
      unsigned int SsIndex;
      int m_InitiateNoteMsPresent;
      int m_TraceErrorCode;
      bool m_TrapReqd;
      bool m_SendCl;
      int m_mwd_flag;
      u8 m_AlertMsisdn[21];
      //Params of DB query
      u8 l_AccId[MAX_ACCOUNTID_LEN+1];
      int l_nwId;
      int l_pnwId;
      int l_AlocType;
      u8 l_actMsisdn[MAXISDNADDRLEN+1];
      u8 l_priMsisdn[MAXISDNADDRLEN+1];
      u8 l_priImsi[IMSILEN+1];
      int l_roamInd;
      u8 l_hlrAddr[MAXISDNADDRLEN+1];
      int l_OpCode;
      unsigned int l_GenOdb;
      unsigned int l_PlmnOdb;
      bool m_ProvErrRcvd;
      int m_ApnOiOverrideIndVal; //6.3.5.0


      struct Details
      {
         u8 imsi[IMSILEN+1];//imsi
         u8 SgsnNo[MAXISDNADDRLEN+1];//sgsn_Number
         u8 SgsnAddr[MAX_SGSN_ADDR_LEN+1];//sgsn_Address
         //sgsn_Capability
         char SgsnCap_Camel[5];
         bool SgsnCap_Camel1;//supportedCamelPhases
         bool SgsnCap_Camel2;
         bool SgsnCap_Camel3;
         bool SgsnCap_Camel4;
         int SgsnCap_Phase;
         bool gprsEncSupIndicator;//gprsEnhancementsSupportIndicator
         bool soLSA;//solsaSupportIndicator
         bool supercharge;//Super charger capability
         /*bool SendISD;
           bool dataAge[12];*/
         bool smsCBSInd;//smsCallBarringSupportIndicator
         bool lcsCS1;//supportedLCS_CapabilitySets
         bool lcsCS2;
         bool lcsCS3;
         bool lcsCS4;
         bool c4_oCSI;//offeredCamel4CSIs
         bool c4_dCSI;
         bool c4_vtCSI;
         bool c4_tCSI;
         bool c4_mtsmsCSI;
         bool c4_mgCSI;
         bool c4_psiCSI;
         bool utran;//supportedRAT_TypesIndicator
         bool geran;
         int lgIDSupp;
         bool ps_LCS_NotSupportedByUE;//ps_LCS_NotSupportedByUE
         u8 gmlc_Address[35];//v_gmlc_Address
         bool AddCapability;//add_info
         u8 imeisv[40];
         int skipISDUpdate;

      }l_upgv3;

      //Added in 1.0.8.0
      int m_FirstUlFlag;
      int m_MsisdnAllocStatus;
      char m_UploadedMsisdn[21];
      char m_GPRS_Seq_id[21];
      //End Added in 1.0.8.0
      char m_TransId[21];
      bool m_fIsd;
      unsigned char m_Orig_Imei[40];


   public:
      CtxtUpdateGPRSLocation();
      virtual ~CtxtUpdateGPRSLocation();
     
      bool processMessage(Msg *p_MsgPtr,bool &p_DeleteFlag);
      bool CheckParameters(int l_UserDlgId,IMAP3_UpdateGprsLocationArg *l_temp);
      int  processDBData(int l_UserDlgId,RetrieveSubsSGSNData *l_rsd);
      int  UpgLoc(int l_UserDlgId);
      void UpgLocCont(int l_UserDlgId);
      void UpgLoc_Cont(int l_UserDlgId);
      void CancelLoc(u8 *l_imsi,u8 *hlrno,u8 *SgsnNo);
      void RetrieveData(int l_UserDlgId,u8 *l_imsi,u8 *l_sgsn);
      void upgLocRes(int l_UserDlgId);
      void GetISDdata(int l_UserDlgId);
      void UpdateGprsData(int l_UserDlgId);
      void UpdateFailData(int l_UserDlgId);
      void startISDV3(int l_UserDlgId);
      void SendMsgV3(int DlgId,MapSpecificRequest *l_request,OMAP3_InsertSubscriberDataArg *l_isd,unsigned int &numOfParam,unsigned int &VcsiParam,unsigned int &ScsiParam,unsigned int &SsParam);
      void RetError(int l_UserDlgId,int ErrorCode);
      void CloseReq(int l_UserDlgId);
      void ContinueReq(int l_UserDlgId);
      bool startProcessing(InterModuleData *p_imd,bool &p_DeleteFlag);
      string m_DataString;
      void sendCLforFupd();
};
#endif
