#ifndef __LCCCOMMDEFINES_H__
#define __LCCCOMMDEFINES_H__

#include <math.h>
using namespace std;

//SP Related
#define MAX_ACCOUNTID_LEN    20
#define IMSILEN              15
#define LMSILEN              10 
#define MAXISDNADDRLEN       20
#define MINISDNADDRLEN        1
#define MAX_PROF_LEN        350
#define MAX_SS_DATA          45
#define MAX_SS_DATALEN       20
#define MAX_CFWD_DATA        30
#define MAX_CFWD_DATALEN    150
#define MAX_CB_DATA          30
#define MAX_CB_DATALEN       50
#define MAX_LI_DATA          30
#define MAX_LI_DATALEN       40
#define MAX_CW_DATA          20
#define MAX_CW_DATALEN       10
#define MAX_MC_DATALEN       25
#define MAX_EMLPP_DATALEN    25
#define MAX_ERRORMSG_LEN    300
#define MAX_SGSN_ADDR_LEN    35
#define MAX_BEARER_COUNT     53
#define MAX_TELE_COUNT       33

//Constants for ISD
#define VLR_SUPPORTED_ODB  0xFFFE0000 
#define SGSN_SUPPORTED_ODB 0xE381C000 //3816931328 
#define OG_CALLS_BARRED_WHEN_ROAMING 0x00002000 //byte 3, 3rd MSB ==> roamingOutsidePLMNOG_CallsBarred
#define ALL_OG_CALLS_BARRED 0x80000000
//Encoding Length for ISD related
#define ISDN_LEN           12
#define ISDN_SUBADDR_LEN   24
#define FWD_OPTN_LEN        4
#define NO_RPLY_TIMER_LEN   3
#define FTN_ADDR_LEN       18
#define BSIC_SRV_CODE_LEN   3
#define SS_STATUS_LEN       3
#define SS_CODE_LEN         3
#define DEF_CALL_LEN        3
#define SK_LEN              3
#define O_TDP_LEN           3
#define CAMEL_CAPAB_LEN     3
#define ODB_DATA_LEN        7
#define ODB_HDATA_LEN       5


//Added for 1.0.8.0
//CFB:-   [A7 1A A0 18 04 01 29 30 13 30 11 83 01 10 84 01 07 85 06 91 89 97 78 89 F7 86 01 04] taking 29 bytes(no timer too)
//CFNRY:- [A7 48 A0 1B 04 01 2A 30 16 30 14 83 01 10 84 01 07 85 06 91 89 97 78 89 F7 86 01 08 87 01 0F] taking 32 bytes (has timer), assuming 35 bytes
#define CFWD_STRUCT_LEN    40
#define CFWD_EXTRA_BS_FTN_LEN  30
//Line Ident:- [A3 09 04 01 11 84 01 05 81 01 00] CLIP and CLIR taking 11 bytes, assuming value as 15
#define LI_SS_STRUCT_LEN   15
//CB :-   [A1 0A 04 01 94 30 05 30 03 84 01 04] CB taking 12 bytes, assuming value as 15
#define CB_STRUCT_LEN      15
#define GEN_SS_STRUCT_LEN  15
//End Addition for 1.0.8.0



//Profile Related
#define OCSI_SERVICEKEY       2
#define SS_EVENT_COUNT        4
#define O_BCSMTDP_CRITERIA    2
#define T_BCSMTDP_CRITERIA    3


// SSN Numbers
#define HLR_SSN     6
#define VLR_SSN     7
#define MSC_SSN     8
#define SGSN_SSN    149

//Opcodes
#define UPDATE_LOCATION_MSG      2
#define CANCEL_LOCATION_MSG      3
#define INSERT_SUBSCRIBER_DATA   7
#define DELETE_SUBSCRIBER_DATA   8
#define UPDATE_GPRS_LOCATION    23
#define PURGE_MS_MSG            67

#define MAX_BCD_STR_LEN 10  /* Maximum length of address string */
#define MAX_NUM_STR_LEN 20  /* (2*MAX_BCD_STR_LEN) */


//TDR  CSI flags
#define MM_TDR_MG_CSI_PRESENT         0x00000200
#define MM_TDR_GPRS_CSI_PRESENT       0x00000100

#define MM_TDR_M_CSI_PRESENT          0x00000080
#define MM_TDR_MT_SMS_CSI_PRESENT     0x00000040
#define MM_TDR_MO_SMS_CSI_PRESENT     0x00000020
#define MM_TDR_VT_CSI_PRESENT         0x00000010
#define MM_TDR_D_CSI_PRESENT          0x00000008
#define MM_TDR_TIF_CSI_PRESENT        0x00000004
#define MM_TDR_SS_CSI_PRESENT         0x00000002
#define MM_TDR_O_CSI_PRESENT          0x00000001

// OAM CL
#define MAX_OSS_TRIGGER_DATA        5
#define MAX_ROW_ID_LEN              30

//4.0.2.0 IMEI encryption
#define ENCRYPTION 1
#define DECRYPTION 2
//unsigned char Encrypt_KEY[]="PLINTRON";


typedef enum
{
   MM_TRAP_SEQ_ID_ONE = 500,
   MM_TRAP_SEQ_ID_TWO,
   MM_TRAP_SEQ_ID_THREE,
   MM_TRAP_SEQ_ID_FOUR,
   MM_TRAP_SEQ_ID_FIVE,
   MM_TRAP_SEQ_ID_SIX,
   MM_TRAP_SEQ_ID_SEVEN,
   MM_TRAP_SEQ_ID_EIGHT,
   MM_TRAP_SEQ_ID_NINE,
   MM_TRAP_SEQ_ID_TEN,
   MM_TRAP_SEQ_ID_ELEVEN,
   MM_TRAP_SEQ_ID_TWELVE,
   MM_TRAP_SEQ_ID_THIRTEEN,
   MM_TRAP_SEQ_ID_FOURTEEN,
   MM_TRAP_SEQ_ID_FIFTEEN,
} EMMTrapSequenceId;
#endif /* __COMMDEFINES_H__ */



