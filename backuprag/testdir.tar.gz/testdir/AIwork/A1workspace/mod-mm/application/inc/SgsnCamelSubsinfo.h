#ifndef __SGSN_CAMEL_SUBS_INFO_H
#define __SGSN_CAMEL_SUBS_INFO_H

#include <MapMessages.h>
#include <MapConstants.h>
#include <Msg.h>
#include <MmDbQueries.h>
#include <OMAP3.h>

typedef unsigned char   u8;   /* Exactly one byte (8 bits) */
typedef unsigned short u16;
typedef char            s8;

class SgsnCamelSubsinfo
{
   public:

      struct scsi
      {
         int roamInd;
         u16 nwId;
         u16 PnwId;
         int RcvdCamelPhase;
         int gcsi;
         int mosmscsi;
         int mtsmscsi;
         int mgcsi;
      }scsi;

      u16 l_OutScfAddrLen;

      bool ValidateAllCsi(int l_DlgId,int PdpprofileId,int GprscsiPid,int MosmscsiPid,int MtsmscsiPid);
#if 0
      void formGprsCsi(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd);
      void formMtsmsCsi(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd);
      void formMtcritList(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd);
      void formMosmsCsi(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd);
      void formMgCsi(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd);
#endif      
      
      void formGprsCsi(OMAP3_InsertSubscriberDataArg *l_isd);
      void formMtsmsCsi(OMAP3_InsertSubscriberDataArg *l_isd);
      void formMtcritList(OMAP3_InsertSubscriberDataArg *l_isd);
      void formMosmsCsi(OMAP3_InsertSubscriberDataArg *l_isd);
      void formMgCsi(OMAP3_InsertSubscriberDataArg *l_isd);
      
      s8* getPartnerGsmScfAddr(s8 * aGsmScfAddr,u16 &aOutScfAddrLen,u16 aNkId,u16 aPnkId);

      SgsnCamelSubsinfo();
      virtual ~SgsnCamelSubsinfo();

};
#endif
