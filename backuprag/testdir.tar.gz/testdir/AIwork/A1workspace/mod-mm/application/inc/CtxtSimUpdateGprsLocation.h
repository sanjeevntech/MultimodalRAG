#ifndef __CONTEXT_SGSN_UPD_LOC_H
#define __CONTEXT_SGSN_UPD_LOC_H

#include <ContextBase.h>
#include <Msg.h>

class CtxtSimUpdateGprsLocation : public ContextBase
{
	private:
		bool sendV3UpdateLocation();
    
	public:
		CtxtSimUpdateGprsLocation();
		~CtxtSimUpdateGprsLocation();

		bool processMessage(Msg *p_MsgPtr,bool &p_DeleteFlag);
		bool startProcessing();
};

#endif
