#ifndef __BASIC_H
#define __BASIC_H

#include <MapMessages.h>
#include <MapConstants.h>
#include <Msg.h>
#include <IMAP1.h>
#include <OMAP1.h>
#include <IMAP2.h>
#include <OMAP2.h>
#include <IMAP3.h>
#include <OMAP3.h>

class basicService
{
   public:

      unsigned short tele[33];
      unsigned short bearer[53];

      basicService();
      virtual ~basicService();

      void formBearerV3C1(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd,char ProvisionedBearer[53]);
      void formBearerV3C2(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd,char ProvisionedBearer[53]);
      void formTeleV3(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd,char ProvisionedTele[33]);
      void formBearerV2C1(int DlgId,OMAP2_InsertSubscriberDataArg *l_isd,char ProvisionedBearer[53]);
      void formBearerV2C2(int DlgId,OMAP2_InsertSubscriberDataArg *l_isd,char ProvisionedBearer[53]);
      void formTeleV2(int DlgId,OMAP2_InsertSubscriberDataArg *l_isd,char ProvisionedTele[33]);
      void formBearerV1C1(int DlgId,OMAP1_BearerServiceList &l_bs,char ProvisionedBearer[53]);
      void formBearerV1C2(int DlgId,OMAP1_BearerServiceList &l_bs,char ProvisionedBearer[53]);
      void formTeleV1(int DlgId,OMAP1_TeleserviceList &l_ts,char ProvisionedTele[33]);

};

#endif
