#ifndef __CONTEXT_PURGEMS_H
#define __CONTEXT_PURGEMS_H

#include <ContextBase.h>
#include <MapMessages.h>
#include <MapConstants.h>
#include <Msg.h>
#include <MmDbQueries.h>
#include <IMAP1.h>
#include <OMAP1.h>
#include <IMAP2.h>
#include <OMAP2.h>
#include <IMAP3.h>
#include <OMAP3.h>
#include <CommonDefines.h>

typedef unsigned char   u8;

class CtxtPurgeMS : public ContextBase
{

   enum m_callState
   {
      m_rgsm,
      m_rgprs
   };

   enum error
   {
      SystemFailure = 1,
      UnknownSubscriber,
      DataMissing,
      UnexpectedData
   };

   private:

   u8 l_imsi[IMSILEN+1];
   u8 l_vlr[MAXISDNADDRLEN+1];
   u8 l_sgsn[MAXISDNADDRLEN+1];
   bool flag;
   bool m_freezeReqd;
   int m_UlInvokeId;
   int l_Version;
   enum m_callState l_msg;
   enum error EMapErrorCode;



   public:
   CtxtPurgeMS();
   virtual ~CtxtPurgeMS();

   bool processMessage(Msg *p_MsgPtr,bool &p_DeleteFlag);
   bool CheckParametersV2(int l_UserDlgId,IMAP2_PurgeMS_Arg *l_pms);
   bool CheckParametersV3(int l_UserDlgId,IMAP3_PurgeMS_Arg *l_pms);
   void PurgeGSM(int l_UserDlgId,u8 *imsi,u8 *l_number);
   void PurgeGPRS(int l_UserDlgId,u8 *imsi,u8 *l_number);
   void VLRResponseV2(int l_UserDlgId);
   void VLRResponseV3(int l_UserDlgId);
   void SgsnResponseV3(int l_UserDlgId);
   void RetErrorV2(int l_UserDlgId,int ErrorCode);
   void RetErrorV3(int l_UserDlgId,int ErrorCode);
   void CloseReq(int l_UserDlgId);
   void ContinueReq(int l_UserDlgId);
};


#endif
