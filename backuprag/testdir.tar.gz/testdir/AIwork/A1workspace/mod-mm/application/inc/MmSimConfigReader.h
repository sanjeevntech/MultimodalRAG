#ifndef __MM_SIM_CONFIG_READER_H
#define __MM_SIM_CONFIG_READER_H

#include <ConfigReader.h>
#include <SubsProfileData.h>
#include <HlrTdrFiller.h>
#include <vector>

typedef unsigned char   u8;

class MmSimConfigReader: public ConfigReader
{

   public:

      MmSimConfigReader();
      ~MmSimConfigReader();

 int l_version;
 int l_rversion;
 int l_pms;
 int l_pmsvlr;
 int l_pmssgsn;
 int l_Count;
 int l_camel;
 bool l_sendEnd;

 //unsigned int l_teleList[33];
 //unsigned int l_bearerList[53];

 bool l_SendISDResp;
 char l_UnsuppTele[33];
 char l_UnsuppBear[53];
 unsigned int l_GenODB;

 bool l_SendATMError;
 int l_UnsuppSsCode[100];
 int l_UnsuppSsCount;

       int l_Home_FLAG;
       unsigned long int l_Home_VLR;
       unsigned long int l_Roam_VLR;
       unsigned long int l_Local_VLR;
       unsigned long int l_pri_imsi_with_CSI;
       unsigned long int l_sec_imsi_with_CSI;
       unsigned long int l_loc_imsi_with_CSI;
       unsigned long int l_pri_imsi_no_CSI;
       unsigned long int l_sec_imsi_no_CSI;
       unsigned long int l_loc_imsi_no_CSI;
       bool l_SendGmlcAddr;
       bool l_SendLCSCapabilitySet;
       bool l_Send_LCSNotSupportIndicator;

       unsigned int l_timeout;

       unsigned int m_mtrf_support_ind;



      void printConfigData(char *p_output);
      bool readData();
};


extern MmSimConfigReader *g_MmSimConfigReaderObj;
extern bool DeclareFunc(int p_version, int p_pdu, void *p_struct);

extern int l_teleList[];
extern int l_bearerList[];
#endif
