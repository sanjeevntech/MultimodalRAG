#ifndef __CONTEXT_RESTORE_DATA_H
#define __CONTEXT_RESTORE_DATA_H

#include <ContextBase.h>
#include <MapMessages.h>
#include <MapConstants.h>
#include <Msg.h>
#include <MmDbQueries.h>
#include <IMAP1.h>
#include <OMAP1.h>
#include <IMAP2.h>
#include <OMAP2.h>
#include <IMAP3.h>
#include <OMAP3.h>
#include <ISDData.h>
#include <CommonDefines.h>

typedef unsigned char   u8;

class CtxtRestoreData : public ContextBase
{

   private:
      enum m_callState
      {
         m_rsd,//Retrieve subscriber data
         m_psd,//Process subscriber data
         m_atm,//Sent ATM
         m_fid,//Fill ISD data
         m_sid,//Send ISD data
         m_usd //Update Subscriber data
      };

      enum error
      {
         SystemFailure = 1,
         UnknownSubscriber,
         DataMissing,
         UnexpectedData
      };

      ISDData m_isd;

      u8 l_imsi[IMSILEN+1];
      u8 l_lmsi[LMSILEN+1];
      u8 m_VlrAddr[MAXISDNADDRLEN+1];
      bool m_ProvErrRcvd;
      struct l_vlrCap
      {
         char VlrCap_Camel[5];
         bool VlrCap_Camel1;
         bool VlrCap_Camel2;
         bool VlrCap_Camel3;
         bool VlrCap_Camel4;
         int VlrCap_Phase;
         bool soLSA;
         int istSupportIndicator;
         bool SuperCharge;
         int SendISD;
         //u8 dataAge[12];
         //int LongFTN;
         int lcsCS1;
         int lcsCS2;
         int lcsCS3;
         int lcsCS4;
         bool oCSI;
         bool dCSI;
         bool vtCSI;
         bool tCSI;
         bool mtsmsCSI;
         bool mgCSI;
         bool psiCSI;
         bool utran;
         bool geran;
         bool LongFTN;
         //int lgIDSupp;
      }l_vlrCap;


      struct GsmProfile
      {
         u8 l_ActMsisdn[MAXISDNADDRLEN+1];
         u8 l_Actimsi[IMSILEN+1];
         u8 l_lmsino[LMSILEN+1];
         u8 l_vlrno[MAXISDNADDRLEN+1];
         u8 l_Mscno[MAXISDNADDRLEN+1];
         int l_mscRest;
         int l_ssInd;
         int l_msPur_gsm;
         int l_roamrestduf;
         int l_msgWait;
         int l_mnrr;
         int l_mnrf;
         int l_mcef;
         u8 l_ActHLRAddr[MAXISDNADDRLEN+1];
         int l_ActPnwId;
         int l_TraceFlag;
         unsigned char l_OmcId[MAXISDNADDRLEN+1];
         unsigned char l_TraceRef[5];
         unsigned char l_TraceType[5];
         int l_TraceStatus;
      }GsmProfile;

      struct GenProfile
      {
         int l_nwAccMode;
         int l_catgory;
         int l_subsRest;
         int l_accRest;
         int l_subsStatus;
         int l_lmu;
         int l_ist;
         char l_bearer[MAX_BEARER_COUNT+1];
         char l_tele[MAX_TELE_COUNT+1];
         int l_ocsiPid;
         int l_tcsiPid;
         int l_ugcsiPid;
         int l_sscsiPid;
         int l_tifcsiPid;
         int l_dcsiPid;
         int l_moscsiPid;
         int l_mtscsiPid;
         int l_gcsiPid;
         int l_mgcsiPid;
         int l_pdpPid;
      }GenProfile;




   public:

      bool flag;
      int m_UlInvokeId;
      int l_Version;
      //int numOfParam;
      int l_OpCode;
      enum m_callState l_msg;
      enum error EMapErrorCode;
      //params for counting ISD
      unsigned int index;
      unsigned int VcsiIndex;
      unsigned int ScsiIndex;
      unsigned int SsIndex;
      /*unsigned int VcsiParam;
        unsigned int numOfParam;
        unsigned int ScsiParam;
        unsigned int SsParam;*/
      //params of DB query
      u8 l_AccId[MAX_ACCOUNTID_LEN+1];
      int l_nwId;
      /*int l_pnwId;
        int l_AlocType;
        u8 l_actMsisdn[20];
        u8 l_priMsisdn[20];
        u8 l_priImsi[16];
        int l_roamInd;
        int l_mwd;*/
      u8 l_hlrAddr[MAXISDNADDRLEN+1];
      unsigned int l_GenOdb;
      unsigned int l_PlmnOdb;

      CtxtRestoreData();
      virtual ~CtxtRestoreData();      

      bool processMessage(Msg *p_MsgPtr,bool &p_DeleteFlag);
      bool processDBData(int l_UserDlgId,RetrieveRSDData *l_rsd);     
      bool CheckParametersV2(int l_UserDlgId,IMAP2_RestoreDataArg *l_rd);
      bool CheckParametersV3(int l_UserDlgId,IMAP3_RestoreDataArg *l_rd);
      void RetrieveData(int l_UserDlgId,u8 *imsi,u8 *lmsi);
      void startISDV3(int l_UserDlgId);
      void startISDV2(int l_UserDlgId);     
      bool RsdV3(int l_UserDlgId);
      bool RsdV2(int l_UserDlgId);
      void ProcessGsmData(int l_UserDlgId);      
      void SendMsgV2(int DlgId,MapSpecificRequest l_request,OMAP2_InsertSubscriberDataArg *l_isd,unsigned int &numOfParam,unsigned int &SsParam);
      void SendMsgV3(int DlgId,MapSpecificRequest l_request,OMAP3_InsertSubscriberDataArg *l_isd,unsigned int &numOfParam,unsigned int &VcsiParam,unsigned int &ScsiParam,unsigned int &SsParam);
      void SendRespV2(int l_UserDlgId,int mnrf);
      void SendRespV3(int l_UserDlgId,int mnrf);
      void RespV2(int l_UserDlgId);
      void RespV3(int l_UserDlgId);
      void RetErrorV2(int l_UserDlgId,int ErrorCode);
      void RetErrorV3(int l_UserDlgId,int ErrorCode);
      void CloseReq(int l_UserDlgId);
      void ContinueReq(int l_UserDlgId);      
};


#endif
