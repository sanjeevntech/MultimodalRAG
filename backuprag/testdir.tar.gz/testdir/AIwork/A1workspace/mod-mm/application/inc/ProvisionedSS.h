#ifndef __PROVISIONED_SS_H
#define __PROVISIONED_SS_H

#include <MapMessages.h>
#include <MapConstants.h>
#include <Msg.h>
#include <MmDbQueries.h>
#include <CommonDefines.h>
#include <OMAP3.h>
#include <OMAP2.h>
#include <OMAP1.h>

typedef unsigned char   u8;   /* Exactly one byte (8 bits) */
typedef unsigned short u16;   /* Exactly two bytes(16 bits)*/

class provisionedSS
{
#define SS_EMLPP    0xA1
#define SS_MC       0x45
#define SS_CW       0x41

   public:

      int m_GenSsCount;

      enum CFWD
      {          
         CFWD_UNCON = 0,
         CFWD_BUSY,
         CFWD_NOTREACH,
         CFWD_NOREPLY,
         CALL_DEF,
         DEF
      };

      enum CB
      {
         CB_BOAC = 0,
         CB_BOIC,
         CB_BOIHC,
         CB_BAIC,
         CB_BICR,
         DEFA
      };

      //CFWD Data --> Cfu,Cfb,Cfnry,Cfnrc,Cd
      //Call fwd unconditional - SSCODE 33
      u16 cfuSsCode;
      u16 cfuSsCount;
      u16 cfuSsStatus[MAX_CFWD_DATA];
      u16 cfuBCode[MAX_CFWD_DATA];
      u16 cfuBType[MAX_CFWD_DATA];
      u8  cfuFTN[MAX_CFWD_DATA][21];
      u8  cfuFTS[MAX_CFWD_DATA][23];
      u16 cfuOPTN[MAX_CFWD_DATA];
      u16 cfuNRT[MAX_CFWD_DATA];
      u8  cfuLFTN[MAX_CFWD_DATA][40];
      //-- call deflection - SSCODE 36
      u16 cdSsCode;
      u16 cdSsCount;
      u16 cdSsStatus[MAX_CFWD_DATA];
      u16 cdBCode[MAX_CFWD_DATA];
      u16 cdBType[MAX_CFWD_DATA];
      u8  cdFTN[MAX_CFWD_DATA][20];
      u8  cdFTS[MAX_CFWD_DATA][22];
      u16 cdOPTN[MAX_CFWD_DATA];
      u16 cdNRT[MAX_CFWD_DATA];
      u8  cdLFTN[MAX_CFWD_DATA][20];
      //call forwarding on mobile subscriber busy - SSCODE 41
      u16 cfbSsCode;
      u16 cfbSsCount;
      u16 cfbSsStatus[MAX_CFWD_DATA];
      u16 cfbBCode[MAX_CFWD_DATA];
      u16 cfbBType[MAX_CFWD_DATA];
      u8  cfbFTN[MAX_CFWD_DATA][20];
      u8  cfbFTS[MAX_CFWD_DATA][22];
      u16 cfbOPTN[MAX_CFWD_DATA];
      u16 cfbNRT[MAX_CFWD_DATA];
      u8  cfbLFTN[MAX_CFWD_DATA][20];
      //call forwarding on no reply - SSCODE 42
      u16 cfnrySsCode;
      u16 cfnrySsCount;
      u16 cfnrySsStatus[MAX_CFWD_DATA];
      u16 cfnryBCode[MAX_CFWD_DATA];
      u16 cfnryBType[MAX_CFWD_DATA];
      u8  cfnryFTN[MAX_CFWD_DATA][20];
      u8  cfnryFTS[MAX_CFWD_DATA][22];
      u16 cfnryOPTN[MAX_CFWD_DATA];
      u16 cfnryNRT[MAX_CFWD_DATA];
      u8  cfnryLFTN[MAX_CFWD_DATA][20];
      //call forwarding on mobile subscriber not reachable - SSCODE 43
      u16 cfnrcSsCode;
      u16 cfnrcSsCount;
      u16 cfnrcSsStatus[MAX_CFWD_DATA];
      u16 cfnrcBCode[MAX_CFWD_DATA];
      u16 cfnrcBType[MAX_CFWD_DATA];
      u8  cfnrcFTN[MAX_CFWD_DATA][20];
      u8  cfnrcFTS[MAX_CFWD_DATA][22];
      u16 cfnrcOPTN[MAX_CFWD_DATA];
      u16 cfnrcNRT[MAX_CFWD_DATA];
      u8  cfnrcLFTN[MAX_CFWD_DATA][20];     



      //Call Barring - baoc,boic,boihc,baic,bicr
      //Barring of All Outgoing Call - SSCODE 146
      u16 boacSsCode;
      u16 boacCount;
      u16 boacSsStatus[MAX_CB_DATA];
      u16 boacBCode[MAX_CB_DATA];
      u16 boacBType[MAX_CB_DATA];
      u8  boacGsmscfAddr[MAXISDNADDRLEN];
      //barring of All Outgoing International calls - SSCODE 147
      u16 boicSsCode;
      u16 boicCount;
      u16 boicSsStatus[MAX_CB_DATA];
      u16 boicBCode[MAX_CB_DATA];
      u16 boicBType[MAX_CB_DATA];
      u8  boicGsmscfAddr[MAXISDNADDRLEN];
      //Barring of Internation outgoing calls except for HPLMN country - SSCODE 148
      u16 boihcSsCode;
      u16 boihcCount;
      u16 boihcSsStatus[MAX_CB_DATA];
      u16 boihcBCode[MAX_CB_DATA];
      u16 boihcBType[MAX_CB_DATA];
      u8  boihcGsmscfAddr[MAXISDNADDRLEN];
      //Barring of all Incoming calls - SSCODE 154
      u16 baicSsCode;
      u16 baicCount;
      u16 baicSsStatus[MAX_CB_DATA];
      u16 baicBCode[MAX_CB_DATA];
      u16 baicBType[MAX_CB_DATA];
      u8  baicGsmscfAddr[MAXISDNADDRLEN];
      //Barring of Incoming Calls while Roaming outside Home PLMN Country - SSCODE 155
      u16 bicrSsCode;
      u16 bicrCount;
      u16 bicrSsStatus[MAX_CB_DATA];
      u16 bicrBCode[MAX_CB_DATA];
      u16 bicrBType[MAX_CB_DATA];
      u8  bicrGsmscfAddr[MAXISDNADDRLEN];

      //SS Data, Call Waiting & Line Identification send as Ext_SS_Data
      int SsCount;
      u16 SsCode[MAX_SS_DATA];
      u16 SsStatus[MAX_SS_DATA];
      u16 SsBCode[MAX_SS_DATA];
      u16 SsBType[MAX_SS_DATA];
      u16 SsSubsRest[MAX_SS_DATA];
      u16 SsCLIOptn[MAX_SS_DATA];
      u16 SsOverRide[MAX_SS_DATA];

      //EMLPP
      u16 ESsCode;
      u16 ESsStatus;
      u16 EDefaultPriority;
      u16 EMaxPriority;

      //MC_SS_INFO
      u16 mcSsCode;
      u16 MCSsStatus;
      u16 NBR_SB;
      u16 NBR_USER;

      int val;
      CFWD CFWD_STATE;
      CB CB_STATE;

      //Added in 1.0.8.0
      bool m_AllOGCallsBarresPresent;
      // End of Addition
      provisionedSS();
      virtual ~provisionedSS();

#if 0
      //For V3 ISD Call FWD, Call Barring, SS_Data and EMLPP supported
      int formFwdSS3(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd, int p_isdLen);
      void formCfuSS3(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd);
      void formCdSS3(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd);
      void formCfbSS3(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd);
      void formCfnrySS3(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd);
      void formCfnrcSS3(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd);

      int formCbSS3(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd, int p_isdLen);
      void formboaSS3(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd);
      void formboicSS3(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd);
      void formboihcSS3(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd);
      void formbaicSS3(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd);
      void formbicrSS3(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd);

      int formSsSS3(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd, int p_isdLen);
      int  formGenSS3(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd,int isdDataLen);
      int formEmSS3(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd, int p_isdLen);
      void  formEmlSS3(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd);

      void formMcSS(int l_UserDlgId,OMAP3_InsertSubscriberDataArg *l_isd);

      //For V2 ISD Call FWD, Call Barring, SS_Data and EMLPP supported
      int formFwdSS2(int DlgId,OMAP2_InsertSubscriberDataArg *l_isd, int p_isdLen);
      void formCfuSS2(int DlgId,OMAP2_InsertSubscriberDataArg *l_isd);
      void formCdSS2(int DlgId,OMAP2_InsertSubscriberDataArg *l_isd);
      void formCfbSS2(int DlgId,OMAP2_InsertSubscriberDataArg *l_isd);
      void formCfnrySS2(int DlgId,OMAP2_InsertSubscriberDataArg *l_isd);
      void formCfnrcSS2(int DlgId,OMAP2_InsertSubscriberDataArg *l_isd);

      int formCbSS2(int DlgId,OMAP2_InsertSubscriberDataArg *l_isd, int p_isdLen);
      void formboaSS2(int DlgId,OMAP2_InsertSubscriberDataArg *l_isd);
      void formboicSS2(int DlgId,OMAP2_InsertSubscriberDataArg *l_isd);
      void formboihcSS2(int DlgId,OMAP2_InsertSubscriberDataArg *l_isd);
      void formbaicSS2(int DlgId,OMAP2_InsertSubscriberDataArg *l_isd);
      void formbicrSS2(int DlgId,OMAP2_InsertSubscriberDataArg *l_isd);

      int formSsSS2(int DlgId,OMAP2_InsertSubscriberDataArg *l_isd, int p_isdLen);
      void  formGenSS2(int DlgId,OMAP2_InsertSubscriberDataArg *l_isd);

      //For V1 ISD Call FWD, Call Barring and SS_Data supported
      int formFwdSS1(int DlgId,OMAP1_InsertSubscriberDataArg *l_isd, int p_isdLen);
      void formCfuSS1(int DlgId,OMAP1_SS_InfoList &l_isd);
      void formCdSS1(int DlgId,OMAP1_SS_InfoList &l_isd);
      void formCfbSS1(int DlgId,OMAP1_SS_InfoList &l_isd);
      void formCfnrySS1(int DlgId,OMAP1_SS_InfoList &l_isd);
      void formCfnrcSS1(int DlgId,OMAP1_SS_InfoList &l_isd);

      int formCbSS1(int DlgId,OMAP1_InsertSubscriberDataArg *l_isd, int p_isdLen);
      void formboaSS1(int DlgId,OMAP1_SS_InfoList &l_isd);
      void formboicSS1(int DlgId,OMAP1_SS_InfoList &l_isd);
      void formboihcSS1(int DlgId,OMAP1_SS_InfoList &l_isd);

      int formSsSS1(int DlgId,OMAP1_InsertSubscriberDataArg *l_isd, int p_isdLen);
      int  formGenSS1(int DlgId,OMAP1_SS_InfoList &l_isd);
#endif 


      //For V3 ISD Call FWD, Call Barring, SS_Data and EMLPP supported
      //int formFwdSS3(OMAP3_InsertSubscriberDataArg *l_isd,int &);
      int formFwdSS3(OMAP3_InsertSubscriberDataArg *l_isd);
      void formCfuSS3(OMAP3_InsertSubscriberDataArg *l_isd);
      void formCdSS3(OMAP3_InsertSubscriberDataArg *l_isd);
      void formCfbSS3(OMAP3_InsertSubscriberDataArg *l_isd);
      void formCfnrySS3(OMAP3_InsertSubscriberDataArg *l_isd);
      void formCfnrcSS3(OMAP3_InsertSubscriberDataArg *l_isd);

      //int formCbSS3(OMAP3_InsertSubscriberDataArg *l_isd,int &);
      int formCbSS3(OMAP3_InsertSubscriberDataArg *l_isd);
      void formboaSS3(OMAP3_InsertSubscriberDataArg *l_isd);
      void formboicSS3(OMAP3_InsertSubscriberDataArg *l_isd);
      void formboihcSS3(OMAP3_InsertSubscriberDataArg *l_isd);
      void formbaicSS3(OMAP3_InsertSubscriberDataArg *l_isd);
      void formbicrSS3(OMAP3_InsertSubscriberDataArg *l_isd);

      int formSsSS3(OMAP3_InsertSubscriberDataArg *l_isd);
      int  formGenSS3(OMAP3_InsertSubscriberDataArg *l_isd,int isdDataLen);
      int formEmSS3(OMAP3_InsertSubscriberDataArg *l_isd);
      void  formEmlSS3(OMAP3_InsertSubscriberDataArg *l_isd);

      void formMcSS(OMAP3_InsertSubscriberDataArg *l_isd);

      //For V2 ISD Call FWD, Call Barring, SS_Data and EMLPP supported
      int formFwdSS2(OMAP2_InsertSubscriberDataArg *l_isd);
      void formCfuSS2(OMAP2_InsertSubscriberDataArg *l_isd);
      void formCdSS2(OMAP2_InsertSubscriberDataArg *l_isd);
      void formCfbSS2(OMAP2_InsertSubscriberDataArg *l_isd);
      void formCfnrySS2(OMAP2_InsertSubscriberDataArg *l_isd);
      void formCfnrcSS2(OMAP2_InsertSubscriberDataArg *l_isd);

      int formCbSS2(OMAP2_InsertSubscriberDataArg *l_isd);
      void formboaSS2(OMAP2_InsertSubscriberDataArg *l_isd);
      void formboicSS2(OMAP2_InsertSubscriberDataArg *l_isd);
      void formboihcSS2(OMAP2_InsertSubscriberDataArg *l_isd);
      void formbaicSS2(OMAP2_InsertSubscriberDataArg *l_isd);
      void formbicrSS2(OMAP2_InsertSubscriberDataArg *l_isd);

      int formSsSS2(OMAP2_InsertSubscriberDataArg *l_isd);
      void  formGenSS2(OMAP2_InsertSubscriberDataArg *l_isd);

      //For V1 ISD Call FWD, Call Barring and SS_Data supported
      int formFwdSS1(OMAP1_InsertSubscriberDataArg *l_isd);
      void formCfuSS1(OMAP1_SS_InfoList &l_isd);
      void formCdSS1(OMAP1_SS_InfoList &l_isd);
      void formCfbSS1(OMAP1_SS_InfoList &l_isd);
      void formCfnrySS1(OMAP1_SS_InfoList &l_isd);
      void formCfnrcSS1(OMAP1_SS_InfoList &l_isd);

      int formCbSS1(OMAP1_InsertSubscriberDataArg *l_isd, int p_isdLen);
      void formboaSS1(OMAP1_SS_InfoList &l_isd);
      void formboicSS1(OMAP1_SS_InfoList &l_isd);
      void formboihcSS1(OMAP1_SS_InfoList &l_isd);

      int formSsSS1(OMAP1_InsertSubscriberDataArg *l_isd, int p_isdLen);
      int  formGenSS1(OMAP1_SS_InfoList &l_isd);      
};
#endif
