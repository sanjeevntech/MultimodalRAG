#ifndef __MM_SGSN_DB_QUERIES_H
#define __MM_SGSN_DB_QUERIES_H

#include <DbQueryMsg.h>
#include <DbActiveObject.h>
#include <CommonDefines.h>
typedef unsigned char   u8;

class OssTriggerDataGprs
{
   public:
      OssTriggerDataGprs();
      ~OssTriggerDataGprs();
      char  m_rowId[MAX_ROW_ID_LEN+1];
};

class RetrieveSubsSGSNData : public DbQueryMsg
{
   public:

      u8 m_imsi[IMSILEN+1];
      u8 m_sgsn[MAXISDNADDRLEN+1];
      int m_MultiImsiReqd;
      //Additions in 1.0.8.0
      //
      int m_SGSN_Supported_Max_CAP_Phase;
      u8 m_sgsnAddr[MAX_SGSN_ADDR_LEN+1];
      int m_CamPha;
      int m_Solsa;
      int m_SupChrg;
      int m_GprsEhnc;
      int m_SupLCS;
      int m_OffCAM;
      int m_SMSCB;
      u8 m_IMEISV[40];
      u8 m_ps_v_gmlc_Address[34+1];
      int m_ps_LCS_SupportedByUE;
      int m_full_isd_ind;
      u8 m_Orig_Imei[40]; 
      //End Additions in 1.0.8.0
      //
      u8 m_AccId[MAX_ACCOUNTID_LEN+1];
      int m_nwid;
      int m_pnwid;
      int m_AlocType;
      u8 m_ActMsisdn[MAXISDNADDRLEN+1];
      u8 m_PriMsisdn[MAXISDNADDRLEN+1];
      u8 m_PriImsi[IMSILEN+1];
      int m_RoamIND;
      u8 m_HlrADDR[MAXISDNADDRLEN+1];
      u8 m_GenINFO[MAX_PROF_LEN+1];
      u8 m_GprsINFO[MAX_PROF_LEN+1];
      int m_CBCount;
      u8  m_CBData[MAX_CB_DATA][MAX_CB_DATALEN+1];
      int m_partType;
      int m_pwd_flag;
      int m_mwd_flag;
      u8 m_alertMsisdn[MAXISDNADDRLEN+1];
      u8  m_OldMsisdn[MAXISDNADDRLEN+1];
      int m_MsisdnAllcatedStatus;
      int m_RemainingMsisnd;
      int m_FirstUL;
      u8  m_GPRS_Seq_id[21]; //1.0.8.0 
      u8 m_TdrData[200+1];
      // 1.0.13.2 Begin
      //int               m_ossTriggerDataCount;
      //OssTriggerDataGprs    m_ossTriggerDataArray[MAX_OSS_TRIGGER_DATA];
      //char                 m_ossTriggerDataVarchar[300];
      // 1.0.13.2 End
      char m_MmeHost[100+1];
      char m_MmeRealm[100+1];
      char m_HssHost[100+1];
      char m_HssRealm[100+1];
      int m_DynMsisdnMinFreeThreshold;              //Added in HLR 5.0.3.0
      char m_AreaCodeBasedAllocInfo[100+1];
      char m_TrapCode[50+1];
      char m_TrapDesc[500+1];
      int m_ErrorCode;
      u8 m_ErrorMsg[MAX_ERRORMSG_LEN+1];
      int m_localImsiSubscription;
      char m_roamCC[10 + 1];
      // 1.0.15.0 Begin
      u8  m_LocalMsisdn[MAXISDNADDRLEN+1];
      u8  m_LocalImsi[IMSILEN+1];
      int m_ImsiPreBurnt;
      int m_freeCount;
      int m_threshCount;
      char m_SimStructure[30 + 1];
      // 1.0.15.0 End
      int m_transFreeCount;
      int m_transThreshCount;

      u8 m_localRoamInfo[100 + 1];
      u8 m_tdrResrvData[100 + 1];

      int                  m_ossTriggerDataCount_OUT;
      u8                   m_ossTriggerData_OUT[10][5000 + 1];

      u8 m_TdrRestrData[300 + 1];
      u8 m_TdrProfData[100 + 1];
      char m_generalTDRdata[500 + 1];

      int m_crossClType_OUT;

      u8 m_AltImsi[IMSILEN+1];   //5054
      char m_IPAddress[100 + 1];
      int m_First_Roam_To_Home_Flag;
      char m_CC_Info[150+1];

      char m_TemplateFtnInfo_OUT[50+1]; //6.2.0.0
      int m_ApnOiOverrideInd_OUT;//6.3.5.0
      int m_PrimaryIndicator_OUT;//6.4.2.0
      char m_DualImsiInfo_OUT[50+1]; //6.4.4.0
      char m_MnoProvisioningTdr_OUT[30+1]; //6.4.4.1
      int m_ugl_mpg_indicator_OUT;  //6.4.4.1

      bool executeQuery(void*);
      RetrieveSubsSGSNData();
      virtual ~RetrieveSubsSGSNData();
};

class UpdateSGSNData : public DbQueryMsg
{
   public:
      u8 m_AccId[MAX_ACCOUNTID_LEN+1];
      int m_nwid;
      u8 m_ActMsisdn[MAXISDNADDRLEN+1];
      u8 m_ActImsi[IMSILEN+1];
      int m_roamInd;
      u8 m_sgsn[MAXISDNADDRLEN+1];
      u8 m_ActHlr[MAXISDNADDRLEN+1];
      u8 m_sgsnAddr[MAX_SGSN_ADDR_LEN+1];
      int m_sgsnRest;
      int m_purge;
      int m_MNRG;
      int m_RRDUF;
      int m_pnwid;
      int m_MsisdnTyp;
      int m_CamPha;
      int m_Solsa;
      int m_SupChrg;
      int m_GprsEhnc;
      int m_SupLCS;
      int m_OffCAM;
      int m_SMSCB;
      unsigned char m_Unsupp_Tele[33];
      unsigned char m_Unsupp_SuppServ[201];
      unsigned int  m_Unsupp_GenOdb;
      unsigned int  m_AtmErrorCode;
      unsigned char m_IMEISV[40];
      int m_RoamRest;
      int m_ps_LCS_SupportedByUE;
      unsigned char m_ps_v_gmlc_Address[34+1];
      //Modified in HLR 1.0.8.0 , for Deallocation on MSISDN on First UL failure for Dynamic case
      int m_AllocStatus;
      int m_FirstUl;
      int m_DeallocMsisdn;
      u8  m_GPRS_Seq_id[21]; //1.0.8.0 
      //End Modified in HLR 1.0.8.0
      int m_ErrorCode;
      u8 m_ErrorMsg[MAX_ERRORMSG_LEN+1];
      bool executeQuery(void*);
      UpdateSGSNData();
      virtual ~UpdateSGSNData();
};


#endif
