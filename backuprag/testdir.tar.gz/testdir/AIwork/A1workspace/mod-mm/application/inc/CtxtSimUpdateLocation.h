#ifndef __CONTEXT_VLR_UPD_LOC_H
#define __CONTEXT_VLR_UPD_LOC_H

#include <ContextBase.h>
#include <MapMessages.h>
#include <ServiceCoordinator.h>
#include <Logger.h>
#include <IMAP1.h>
#include <OMAP1.h>
#include <IMAP2.h>
#include <OMAP2.h>
#include <IMAP3.h>
#include <OMAP3.h>
#include <DataUnion.h>
#include <MmConfigReader.h>
#include <Utilities.h>
#include <Msg.h>

class CtxtSimUpdateLocation : public ContextBase
{
	private:
		bool sendV2UpdateLocation();
    
		bool sendV3UpdateLocation();
    
		bool sendV1UpdateLocationWithBeginSubscriber();


	public:
		CtxtSimUpdateLocation();
		~CtxtSimUpdateLocation();

		bool processMessage(Msg *p_MsgPtr,bool &p_DeleteFlag);
		bool startProcessing();
};

#endif
