#include <CtxtSimRestoreData.h>
#include <stdio.h>
#include <MapMessages.h>
#include <ServiceCoordinator.h>
#include <Logger.h>
#include <OMAP1.h>
#include <OMAP2.h>
#include <OMAP3.h>
#include <DbActiveObject.h>
#include <ConfigReader.h>
#include <DataUnion.h>
#include <Utilities.h>
#include <HlrTdrFiller.h>
#include <MmSimConfigReader.h>


extern bool DeclareFunc(int p_version, int p_pdu, void *p_struct);


CtxtSimRestoreData::CtxtSimRestoreData()
{
   DLOG(0,0,"CtxtSimRestoreData::CtxtSimRestoreData()");
}

CtxtSimRestoreData::~CtxtSimRestoreData()
{
   DLOG(0,0,"CtxtSimRestoreData::~CtxtSimRestoreData()");
}

bool CtxtSimRestoreData :: startProcessing()
{
      DLOG(0,0,"CtxtSimRestoreData:: startProcessing");
         sendRestoreDataReq();
            return true;
}

bool CtxtSimRestoreData :: sendRestoreDataReq()
{
      DLOG(0,0,"CtxtSimRestoreData:: sendRestoreDataReq");

      DECLARE(OMAP3_RestoreDataArg,l_tempRestoreData,3,"OMAP3_RestoreDataArg",DeclareFunc);
      int l_UserDlgId = g_sc.getNewDialogue();
      DLOG(l_UserDlgId,0,"###CtxtSimRestoreData### Start of CtxtSimRestoreData::sendRestoreDataReq function");

      DLOG(l_UserDlgId,0,"###CtxtSimRestoreData### Sending MapOpenReq ...");
      MapOpenReq l_mapOpenReq(l_UserDlgId, MAP_V3);
      l_mapOpenReq.m_ApplCntxt = MAP_AC_CODE_networkLocUp;
      l_mapOpenReq.m_DestAddr  = g_ConfigData->i_NgConfigData.m_remoteAddress1;
      g_sc.sendMsg(this, &l_mapOpenReq);

      DLOG(l_UserDlgId,0,"###CtxtSimRestoreData### CtxtSimRestoreData::sendRestoreDataReq Sending MapSpecificRequest ...");
      MapSpecificRequest l_request(l_UserDlgId, MAP_OP_CODE_restoreData, MAP_V3);

      //l_tempRestoreData->imsi.length = 8;
      //l_tempRestoreData->imsi.value =  0x91;
    
      unsigned long int imsi = 0;
      imsi = g_MmSimConfigReaderObj->l_pri_imsi_with_CSI;

      char l_imsi[15+1];
      memset(l_imsi,'\0',sizeof(l_imsi));
      snprintf(l_imsi,sizeof(l_imsi),"%ld",imsi);
      DLOG(0,0,"IMSI [%s]",l_imsi);
      l_tempRestoreData->imsi.length = StringToBCD(l_tempRestoreData->imsi.value ,(unsigned char *)l_imsi, strlen(l_imsi));

      l_tempRestoreData->bit_mask |= OMAP3_RestoreDataArg_vlr_Capability_present;

      l_tempRestoreData->vlr_Capability.bit_mask |= OMAP3_VLR_Capability_supportedCamelPhases_present;
      //l_tempRestoreData->vlr_Capability.supportedCamelPhases = 111;
      
   
      l_request.m_structBuffer = (void*)l_tempRestoreData;
      g_sc.sendMsg(this, &l_request);

      DLOG(0,0,"###CtxtSimRestoreData### Sending MapDelimiterReq Req ...");
      MapDelimiterReq l_del(l_UserDlgId);
      g_sc.sendMsg(this, &l_del);

      return true;

   
}


bool CtxtSimRestoreData::processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag)
{
   DLOG(0,0,"Start of CtxtSimRestoreData::processMsg function");
   MapSpecificMsg *l_specMsg = NULL;
   int l_dlgId;
   int l_UserDlgId;
   
   switch (p_MsgPtr->m_MsgType)
   {
      case MSG_TYPE_MAP:
         switch (((MapMsg*)p_MsgPtr)->m_MapMsgType)
         {
            case MAP_MSG_TYPE_COMMON:
               switch (((MapCommonMsg*)p_MsgPtr)->m_MapCommonMsgType)
               {
                  case MAP_CMN_OPEN_IND:
                     DLOG(0,0,"MAP_CMN_OPEN_IND received");
                     break;

                  case MAP_CMN_DELIMITER_IND:
                     DLOG(0,0,"MAP_CMN_DELIMITER_IND received");
                     break;

                  case MAP_CMN_CLOSE_IND:
                     DLOG(0,0,"MAP_CMN_CLOSE_IND received");

                     return true;
                     break;
                  
                  case MAP_CMN_OPEN_CNF:
                    { 
                        LLOG(0,0,"checking log");
                    }
                    break;
                  
                  case MAP_CMN_U_ABORT_IND:
                     DLOG(0,0," MAP_CMN_U_ABORT_IND received");
                     break;

                  case MAP_CMN_P_ABORT_IND:
                     DLOG(0,0,"MAP_CMN_P_ABORT_IND received");
                     break;

                  case MAP_CMN_NOTICE_IND:
                     {
                        DLOG(0,0,"MAP_CMN_NOTICE_IND received");
                        DLOG(0,0,"Closing the Dialogue");
                        MapCloseReq l_closeReq(((MapMsg*)p_MsgPtr)->m_UserDlgId);
                        g_sc.sendMsg(this, &l_closeReq);
                     }
                     break;

                  default:
                     DLOG(0,0,"Unknown Msg received [%d]", ((MapCommonMsg*)p_MsgPtr)->m_MapCommonMsgType);
                     break;
               }
               break;

            case MAP_MSG_TYPE_SPECIFIC:
               DLOG(0,0,"MAP_MSG_TYPE_SPECIFIC received");
               l_specMsg = (MapSpecificMsg*)p_MsgPtr;
               l_UserDlgId = l_specMsg->m_UserDlgId;
               DLOG(0,0,"MAP_MSG_TYPE_SPECIFIC received dlgId[%d] UserDlgId[%d]",
                     l_dlgId, l_UserDlgId);

               switch (((MapSpecificMsg*)p_MsgPtr)->m_MapSpecificEventType)
               {
                  case MAP_SPEC_EVENT_INDICATION:
                     {
                        DLOG(0,0,"MAP_SPEC_EVENT_INDICATION received");
                        l_UserDlgId = p_MsgPtr->m_UserDlgId;
                     
                        switch (((MapSpecificMsg*)p_MsgPtr)->m_OpCode)
                        {
                           case MAP_OP_CODE_restoreData:
                              {
                                 DLOG(l_UserDlgId,0,"###CtxtSimRestoreData### Received RestoreData");
                              }
                              break;
                           
                           case MAP_OP_CODE_insertSubscriberData:
                              {
                                 TLOG(0, 0, "MAP_OP_CODE_insertSubscriberData REQUEST received");

                                 if(g_MmSimConfigReaderObj->l_timeout > 0)
                                 {
                                    //sleep(g_MmSimConfigReaderObj->l_timeout);
                                 }
                                 char *l_tmp;
                                 l_tmp = getenv("SEND_ERROR_ON_ISD");
                                 if(strcmp(l_tmp,"YES") == 0)
                                 {

                                    printf("\nSEND_ERROR_ON_ISD is set, sending MAP_ERROR_unexpectedData \n");
                                    OMAP3_UnexpectedDataParam l_udp;
                                    memset(&l_udp,'\0',sizeof(l_udp));
                                    MapUserError l_userError(((MapSpecificMsg*) p_MsgPtr)->m_UserDlgId, MAP_ERROR_unexpectedData, MAP_V3, NULL);
                                    g_sc.sendMsg(this, &l_userError);
                                    MapDelimiterReq l_del(((MapSpecificMsg*) p_MsgPtr)->m_UserDlgId);
                                    g_sc.sendMsg(this, &l_del);
                                    return false;
                                 }


                                 l_tmp = getenv("DONT_SEND_ISD_RESP");
                                 if(strcmp(l_tmp,"YES") == 0)
                                 {
                                    printf("\nDONT_SEND_ISD_RESP is set, Not sending, L_CANCEL will come in 30 seconds\n");
                                    return false;
                                 }


                                 if(g_MmSimConfigReaderObj->l_version == 3)
                                 {
                                    MapSpecificResult l_result(((MapSpecificMsg*) p_MsgPtr)->m_UserDlgId, MAP_OP_CODE_insertSubscriberData, MAP_V3);


                                    DECLARE(OMAP3_InsertSubscriberDataRes,l_isdRes,3,"OMAP3_InsertSubscriberDataRes",DeclareFunc);

                                    l_isdRes->bit_mask = 0;
                                    if( g_MmSimConfigReaderObj->l_SendISDResp)
                                    {
                                       if(strcmp(g_MmSimConfigReaderObj->l_UnsuppTele,"00000000000000000000000000000000"))
                                          l_isdRes->bit_mask |= OMAP3_InsertSubscriberDataRes_teleserviceList_present;
                                       l_isdRes->teleserviceList.count = 0;
                                       for(int bear = 0;bear < 32;bear++)
                                       {
                                          if(g_MmSimConfigReaderObj->l_UnsuppTele[bear] == '1')
                                          {
                                             l_isdRes->teleserviceList.value[l_isdRes->teleserviceList.count].length = 1;
                                             l_isdRes->teleserviceList.value[l_isdRes->teleserviceList.count].value[0] = l_teleList[bear];
                                             l_isdRes->teleserviceList.count++;
                                          }
                                       }
                                       if(l_isdRes->teleserviceList.count>20)
                                          l_isdRes->teleserviceList.count = 20;


                                       if(strcmp(g_MmSimConfigReaderObj->l_UnsuppBear,"0000000000000000000000000000000000000000000000000000"))
                                          l_isdRes->bit_mask |= OMAP3_InsertSubscriberDataRes_bearerServiceList_present;
                                       l_isdRes->bearerServiceList.count = 0;
                                       for(int bear = 0;bear < 52;bear++)
                                       {
                                          if(g_MmSimConfigReaderObj->l_UnsuppBear[bear] == '1')
                                          {
                                             l_isdRes->bearerServiceList.value[l_isdRes->bearerServiceList.count].length = 1;
                                             l_isdRes->bearerServiceList.value[l_isdRes->bearerServiceList.count].value[0] = l_bearerList[bear];//0x21;
                                             l_isdRes->bearerServiceList.count++;
                                          }
                                       }
                                       if(l_isdRes->bearerServiceList.count > 45)
                                          l_isdRes->bearerServiceList.count = 45;

                                       if(g_MmSimConfigReaderObj->l_UnsuppSsCount)
                                          l_isdRes->bit_mask |= OMAP3_InsertSubscriberDataRes_ss_List_present;
                                       l_isdRes->ss_List.count = g_MmSimConfigReaderObj->l_UnsuppSsCount;
                                       for(int i=0;i<100;i++)
                                       {
                                          l_isdRes->ss_List.value[i].length = 1;
                                          l_isdRes->ss_List.value[i].value[0] = g_MmSimConfigReaderObj->l_UnsuppSsCode[i];
                                       }


                                       union Hdata
                                       {
                                          unsigned int l_Hodb;
                                          unsigned char l_testhOdb[4];
                                       };
                                       Hdata l_HomOdb;
                                       l_HomOdb.l_Hodb = g_MmSimConfigReaderObj->l_GenODB;
                                       if(g_MmSimConfigReaderObj->l_GenODB)
                                          l_isdRes->bit_mask |= OMAP3_odb_GeneralData_present;                  
                                       memcpy(l_isdRes->odb_GeneralData.value,l_HomOdb.l_testhOdb,4);                                                            
                                       l_isdRes->odb_GeneralData.length =  getNumberOfSignificantBitsForAnArray(l_isdRes->odb_GeneralData.value,4);                                    
                                    }
                                    if( g_MmSimConfigReaderObj->l_SendISDResp == 1)
                                       l_result.m_structBuffer = l_isdRes;
                                    else
                                       l_result.m_structBuffer = NULL;
                                    g_sc.sendMsg(this, &l_result);

                                    //printf("Received ISD Arg, Sending MapSpecificResult followed by MAP_Delimiter\n");
                                    DLOG(0, 0, "Sending Delimiter Req ...");
                                    MapDelimiterReq l_del(((MapSpecificMsg*) p_MsgPtr)->m_UserDlgId); 
                                    g_sc.sendMsg(this, &l_del); 
                                 }
                                 else if(g_MmSimConfigReaderObj->l_version == 2)
                                 {
                                    MapSpecificResult l_result(((MapSpecificMsg*) p_MsgPtr)->m_UserDlgId, MAP_OP_CODE_insertSubscriberData, MAP_V2);
                                    //OMAP2_InsertSubscriberDataRes *l_isdRes = (OMAP2_InsertSubscriberDataRes*) malloc(sizeof (OMAP2_InsertSubscriberDataRes));

                                    //memset(l_isdRes, '\0', sizeof (OMAP2_InsertSubscriberDataRes));
                                    DECLARE(OMAP2_InsertSubscriberDataRes,l_isdRes,2,"OMAP3_InsertSubscriberDataRes",DeclareFunc);


                                    if( g_MmSimConfigReaderObj->l_SendISDResp)
                                    {
                                       l_isdRes->bit_mask = OMAP2_InsertSubscriberDataRes_teleserviceList_present;
                                       l_isdRes->teleserviceList.count = 3;
                                       l_isdRes->teleserviceList.value[0].length = 1;
                                       l_isdRes->teleserviceList.value[0].value[0] = 0x21;
                                       l_isdRes->teleserviceList.value[1].length = 1;
                                       l_isdRes->teleserviceList.value[1].value[0] = 0x22;
                                       l_isdRes->teleserviceList.value[2].length = 1;
                                       l_isdRes->teleserviceList.value[2].value[0] = 0x23;

                                       l_isdRes->odb_GeneralData.length = 6;
                                       l_isdRes->odb_GeneralData.value[0] = OMAP2_allOG_CallsBarred|OMAP2_internationalOGCallsBarred|OMAP2_internationalOGCallsNotToHPLMN_CountryBarred|OMAP2_premiumRateInformationOGCallsBarred|OMAP2_premiumRateEntertainementOGCallsBarred|OMAP2_ss_AccessBarred;

                                       if(g_MmSimConfigReaderObj->l_GenODB)
                                          l_isdRes->bit_mask |= OMAP2_odb_GeneralData_present;                                   
                                    }

                                    l_result.m_structBuffer = l_isdRes;
                                    g_sc.sendMsg(this, &l_result);

                                    DLOG(0, 0, "Sending Delimiter Req ...");
                                    MapDelimiterReq l_del(((MapSpecificMsg*) p_MsgPtr)->m_UserDlgId);
                                    g_sc.sendMsg(this, &l_del);
                                 }
                                 else if(g_MmSimConfigReaderObj->l_version == 1)
                                 {
                                    MapSpecificResult l_result(((MapSpecificMsg*) p_MsgPtr)->m_UserDlgId, MAP_OP_CODE_insertSubscriberData, MAP_V2);

                                    //OMAP2_InsertSubscriberDataRes *l_isdRes = (OMAP2_InsertSubscriberDataRes*) malloc(sizeof (OMAP2_InsertSubscriberDataRes));
                                    g_sc.sendMsg(this, &l_result);

                                    DLOG(0, 0, "Sending Delimiter Req ...");
                                    MapDelimiterReq l_del(((MapSpecificMsg*) p_MsgPtr)->m_UserDlgId);
                                    g_sc.sendMsg(this, &l_del);
                                 }
                                 else
                                 {
                                    return false;
                                 }
                              }
                              break;
                            /*case MAP_OP_CODE_insertSubscriberData:
                              {
                                 DLOG(0,0,"Received InsertSubscriberData");

                                 OMAP3_InsertSubscriberDataArg *lp_isd=(OMAP3_InsertSubscriberDataArg*)(l_specMsg->m_structBuffer);
                                 OMAP3_InsertSubscriberDataRes l_ISDRes;
                                 memset(&l_ISDRes,'\0',sizeof(l_ISDRes));
                                 if(lp_isd->bit_mask & OMAP3_InsertSubscriberDataArg_teleserviceList_present)
                                 {
                                    l_ISDRes.bit_mask=OMAP3_InsertSubscriberDataRes_teleserviceList_present;
                                    l_ISDRes.teleserviceList.count=lp_isd->teleserviceList.count;
                                    for(int i=0;i<l_ISDRes.teleserviceList.count;++i)
                                    {
                                       l_ISDRes.teleserviceList.value[i].length=0x1;
                                       l_ISDRes.teleserviceList.value[i].value[0]=lp_isd->teleserviceList.value[i].value[0];

                                    }
                                 }
                                 DLOG(0,0,"Sending ISD Response");
                                 //MapSpecificResult l_Result(m_DialogId,MAP_OP_CODE_insertSubscriberData,MAP_V3);
                                 MapSpecificResult l_result(((MapSpecificMsg*) p_MsgPtr)->m_UserDlgId, MAP_OP_CODE_insertSubscriberData, MAP_V3);
                                 l_result.m_structBuffer=(void*)&l_ISDRes;
                                 g_sc.sendMsg(this,&l_result);
                                 //MapCloseReq l_CloseReq(m_DialogId);
                                 MapCloseReq l_closeReq(((MapSpecificMsg*) p_MsgPtr)->m_UserDlgId);
                                 g_sc.sendMsg(this,&l_closeReq);
                              }
                              break;*/
                        }

                     }

                    break; 
                 
                  case MAP_SPEC_EVENT_RESULT:
                     {
                        DLOG(0,0,"MAP_SPEC_EVENT_RESULT received");
                     }
                     break;

                  case MAP_SPEC_EVENT_CONFIRMATION:
                     {
                        DLOG(0,0,"MAP_SPEC_EVENT_CONFIRMATION received");
                     }
                     break;

                  case MAP_SPEC_EVENT_USER_ERROR:
                     
                        DLOG(0,0,"MAP_SPEC_EVENT_USER_ERROR received");
                        switch (((MapUserError*)p_MsgPtr)->m_ErrorCode)
                        {
                           case MAP_ERROR_systemFailure:
                              printf("\nGot a User Error : System Failure Param ");
                              break;
                           case MAP_ERROR_UNKNOWN:
                              printf("\nGot a User Error : Unknown ");
                              break;
                           default:
                              printf("\nGot a Different error");
                              break;
                        }
                        break;


                  case MAP_SPEC_EVENT_PROV_ERROR:
                     {
                        DLOG(0,0,"MAP_SPEC_EVENT_PROV_ERROR received");
                        DLOG(0,0,"Closing the Dialogue");
                        MapCloseReq l_closeReq(((MapSpecificMsg*)p_MsgPtr)->m_UserDlgId);
                        g_sc.sendMsg(this, &l_closeReq);
                     }
                     break;
                  default:
                     ELOG(0,0,"ERROR!! Default received");
                     break;

               }
               break;

            default:
               break;
         }
         break;

      case MSG_TYPE_DB:
         DLOG(0,0,"DB message received");
         break;

      default:
         DLOG(0,0,"Unknown message received");
         break;

   }
   return true;
}


