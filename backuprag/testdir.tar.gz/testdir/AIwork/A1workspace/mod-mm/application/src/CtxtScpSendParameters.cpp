
/**************************************************************************************************
  Function Name      : CtxtScpSendParameters
Author               :
InParams             : void 
OutParam /return val : void
Description          : Constructor
 ****************************************************************************************************/

#include <CommonDefines.h>
#include <stdio.h>
#include <ServiceCoordinator.h>
#include <Logger.h>
#include <DbQueryMsg.h>
#include <DbActiveObject.h>    
#include <MmConfigReader.h>
#include <DataUnion.h>
#include <Utilities.h>
#include <sys/time.h>
#include <AsnCodec.h>
#include <SnmpInterface.h>
#include <DiameterConstants.h>
#include <ExtendedServiceCoordinator.h>
#include <CtxtScpSendParameters.h>

extern int g_CMEntityAuthFailTrap;

CtxtScpSendParameters :: CtxtScpSendParameters()
{
   DLOG(0,0,"CtxtScpSendParameters :cons:");

   m_ErrCode = (EMapErrorCode)0;
   m_InitDlgId = 0;

   memset(m_imsi,'\0',sizeof(m_imsi));
   memset(m_SCPAddress,'\0',sizeof(m_SCPAddress));

   mp_sp = NULL;
}   



/**************************************************************************************************
  Function Name      : CtxtScpSendParameters
Author               :
InParams             : void 
OutParam /return val : void
Description          : Destructor
 ****************************************************************************************************/


CtxtScpSendParameters :: ~CtxtScpSendParameters()
{
   DLOG(0,0,"CtxtScpSendParameters :des:");
   if( NULL != mp_sp )
   {
      delete mp_sp;
      mp_sp = NULL;
   }
}

bool CtxtScpSendParameters :: handleSendParameters(Msg *aMsgPtr, u32 aDlgId, EMapVersion aMapVer)
{
   m_InitDlgId = aDlgId;
   m_MapVer = aMapVer;

   DLOG(0,0,"Initiating dialogueId-|%d| mapversion-|%d|",m_InitDlgId,m_MapVer);

   switch(m_MapVer)
   {
      case MAP_V1:
         {
            IMAP1_SendParametersArg *l_temp = (IMAP1_SendParametersArg*) (((MapSpecificMsg*) aMsgPtr)->m_structBuffer);
            if(false == checkSendParameters(l_temp))
            {
               ELOG(0,0,"checkSendParameters: failed sending maperror");
               return handleError(); 
            }
            handleDbQuery();
         }
         break;
      default:
         {
            ELOG(0,0,"invalid mapversion");
            m_ErrCode = MAP_ERROR_systemFailure;
            return handleError();
         }
   }
   return true;
}

bool CtxtScpSendParameters :: handleError()
{
   DLOG(0,0,"In HandleError");
   switch(m_ErrCode)
   {
      case MAP_ERROR_systemFailure:
         {
            CLOG(0,0,"sending mapusererror MAP_ERROR_systemFailure on dlgId |%d|",m_InitDlgId);
         }
         break;
      case MAP_ERROR_unexpectedData:
         {
            CLOG(0,0,"sending mapusererror MAP_ERROR_unexpectedData on dlgId |%d|",m_InitDlgId);
         }
         break;
      case MAP_ERROR_dataMissing:
         {
            CLOG(0,0,"sending mapusererror MAP_ERROR_dataMissing on dlgId |%d|",m_InitDlgId);
         }
         break;
      case MAP_ERROR_unknownSubscriber:
         {
            CLOG(0,0,"sending mapusererror MAP_ERROR_unknownSubscriber on dlgId |%d|",m_InitDlgId);
         }
         break;
      default:
         {
            CLOG(0,0,"Default Case of HandleError: sending mapusererror MAP_ERROR_systemFailure on dlgId |%d|",m_InitDlgId);
            m_ErrCode = MAP_ERROR_systemFailure;
         }
         break;
   }
   m_tdr.setInteger(TDR_INDEX_ERR_CODE,m_ErrCode); 
   MapUserError l_userError(m_InitDlgId, m_ErrCode, m_MapVer,NULL);
   g_sc.sendMsg(this, &l_userError);

   DLOG(0,0,"Closing the Dialogue |%d|",m_InitDlgId);
   MapCloseReq l_CloseReq(m_InitDlgId);
   g_sc.sendMsg(this,&l_CloseReq);
   return true;
}

bool CtxtScpSendParameters :: sendSendParametersResp()
{
   DECLARE(OMAP1_SendParametersRes,l_sp,1,"OMAP1_SendParametersRes",DeclareFunc);

   DLOG(0,0,"Sending SendParametersresponse");

   char l_tokens[40][202];
   TLOG(0,0,"CF Count[%d]",mp_sp->m_CFCount);
   l_sp->sentParameters.count = 1;
   l_sp->sentParameters.value[0].choice = OMAP1_susbcriberData_chosen;
   if(mp_sp->m_CFCount > 0 )
   {
      l_sp->sentParameters.value[0].u.susbcriberData.bit_mask |= OMAP1_SubscriberData_provisonedSS_present;
      l_sp->sentParameters.value[0].u.susbcriberData.provisonedSS.count = mp_sp->m_CFCount;
   }
   m_tdr.setInteger(TDR_INDEX_OAM_FREE_FORMAT_DATA,mp_sp->m_CFCount);
   for(int l_k = 0; l_k < mp_sp->m_CFCount; l_k++)
   {
      char l_cfwd[202];
      memset(l_cfwd,'\0',sizeof(l_cfwd));
      snprintf(l_cfwd,sizeof(l_cfwd),"|%s|",mp_sp->m_CFData[l_k]);
      memset(l_tokens,'\0',sizeof(l_tokens));
      tokenize(l_cfwd, (char*)l_tokens, 202);

      LLOG(0,0,"SSCode[%s] SSStatus[%s] BSCode[%s] BSType[%s] FTN[%s] SubAddr[%s] Options[%s] NRCTimer[%s] LongFtn[%s] DFTN[%s]",l_tokens[1],l_tokens[2],l_tokens[3],l_tokens[4],l_tokens[5],l_tokens[6],l_tokens[7],l_tokens[8],l_tokens[9],l_tokens[10]);
      OMAP1_SS_Information *l_ssInfo= &(l_sp->sentParameters.value[0].u.susbcriberData.provisonedSS.value[l_k]);
      l_ssInfo->choice =  OMAP1_forwardingInfo_chosen;
      l_ssInfo->u.forwardingInfo.bit_mask |= OMAP1_ForwardingInfo_ss_Code_present;
      l_ssInfo->u.forwardingInfo.ss_Code.length = 1;
      l_ssInfo->u.forwardingInfo.ss_Code.value[0] = atoi(l_tokens[1]);
      l_ssInfo->u.forwardingInfo.forwardingFeatureList.count = 1;
      if(2 == atoi(l_tokens[4])) //TELSERVICE
      {
         l_ssInfo->u.forwardingInfo.forwardingFeatureList.value[0].bit_mask |= OMAP1_ForwardingFeature_basicService_present;
         l_ssInfo->u.forwardingInfo.forwardingFeatureList.value[0].basicService.choice = OMAP1_teleservice_chosen;
         l_ssInfo->u.forwardingInfo.forwardingFeatureList.value[0].basicService.u.teleservice.length = 1;
         l_ssInfo->u.forwardingInfo.forwardingFeatureList.value[0].basicService.u.teleservice.value[0] = atoi(l_tokens[3]);
         TLOG(0,0,"SENDPARAMRES: TELESERVICE[%d]",atoi(l_tokens[3]));
      }
      else if(1 == atoi(l_tokens[4])) //BEARERSERVICE
      {
         l_ssInfo->u.forwardingInfo.forwardingFeatureList.value[0].bit_mask |= OMAP1_ForwardingFeature_basicService_present;
         l_ssInfo->u.forwardingInfo.forwardingFeatureList.value[0].basicService.choice = OMAP1_bearerService_chosen;
         l_ssInfo->u.forwardingInfo.forwardingFeatureList.value[0].basicService.u.bearerService.length = 1;
         l_ssInfo->u.forwardingInfo.forwardingFeatureList.value[0].basicService.u.bearerService.value[0] = atoi(l_tokens[3]);
         TLOG(0,0,"SENDPARAMRES: BEARERSERVICE[%d]",atoi(l_tokens[3]));
      }
      l_ssInfo->u.forwardingInfo.forwardingFeatureList.value[0].ss_Status.length = 1;
      l_ssInfo->u.forwardingInfo.forwardingFeatureList.value[0].ss_Status.value[0] = atoi(l_tokens[2]);
      TLOG(0,0,"SENDPARAMRES: SS-STATUS[%d]",atoi(l_tokens[2]));
      if(strlen(l_tokens[5]) > 1)  
      {
         l_ssInfo->u.forwardingInfo.forwardingFeatureList.value[0].bit_mask |= OMAP1_ForwardingFeature_forwardedToNumber_present;
         l_ssInfo->u.forwardingInfo.forwardingFeatureList.value[0].forwardedToNumber.length = StringToBCD(l_ssInfo->u.forwardingInfo.forwardingFeatureList.value[0].forwardedToNumber.value,(u8*)l_tokens[5],strlen(l_tokens[5]));
         TLOG(0,0,"SENDPARAMRES: FTN[%s]",l_tokens[5]);
      }
      else if(strlen(l_tokens[10]) > 1)
      {
         l_ssInfo->u.forwardingInfo.forwardingFeatureList.value[0].bit_mask |= OMAP1_ForwardingFeature_forwardedToNumber_present;
         l_ssInfo->u.forwardingInfo.forwardingFeatureList.value[0].forwardedToNumber.length = StringToBCD(l_ssInfo->u.forwardingInfo.forwardingFeatureList.value[0].forwardedToNumber.value,(u8*)l_tokens[10],strlen(l_tokens[10]));
         TLOG(0,0,"SENDPARAMRES: DEFAULT FTN[%s]",l_tokens[10]);
      }
      else
      {
         TLOG(0,0,"SENDPARAMRES: FTN or DFTN not present .. ignoring");
      }
      if(0 != atoi(l_tokens[7]))
      {
         l_ssInfo->u.forwardingInfo.forwardingFeatureList.value[0].bit_mask |= OMAP1_ForwardingFeature_forwardingOptions_present;
         l_ssInfo->u.forwardingInfo.forwardingFeatureList.value[0].forwardingOptions.length = 1;
         l_ssInfo->u.forwardingInfo.forwardingFeatureList.value[0].forwardingOptions.value[0] = atoi(l_tokens[7]);
         TLOG(0,0,"SENDPARAMRES: FORWARDINGOPTIONS[%d]",atoi(l_tokens[7]));
      }
      if(0 != atoi(l_tokens[8]))
      {
         l_ssInfo->u.forwardingInfo.forwardingFeatureList.value[0].bit_mask |= OMAP1_ForwardingFeature_noReplyConditionTime_present;
         l_ssInfo->u.forwardingInfo.forwardingFeatureList.value[0].noReplyConditionTime = atoi(l_tokens[8]);
         TLOG(0,0,"SENDPARAMRES: NOREPLYCONDITIONTIME[%d]",atoi(l_tokens[8]));
      }
   } 

   MapSpecificResult l_resultL(m_InitDlgId,MAP_OP_CODE_sendParameters,m_MapVer);
   l_resultL.m_structBuffer = (void*)l_sp;
   g_sc.sendMsg(this, &l_resultL);

   DLOG(0,0,"Closing the SendParametersRes dialogue");
   MapCloseReq l_closeReq(m_InitDlgId);
   g_sc.sendMsg(this, &l_closeReq);
   return true;
}

bool CtxtScpSendParameters :: checkSendParameters(IMAP1_SendParametersArg *aSendParametersReq)
{
   DLOG(0,0,"In checkSendParameters");

   if(IMAP1_SubscriberId_imsi_chosen != aSendParametersReq->subscriberId.choice)
   {
      WLOG(0,0,"Subscriber id is not IMSI");
      m_ErrCode = MAP_ERROR_systemFailure;
      return false;
   }
   BCDToString((u8*)m_imsi,(u8*)aSendParametersReq->subscriberId.u.imsi.value, aSendParametersReq->subscriberId.u.imsi.length);
   if(15 != strlen(m_imsi))
   {
      WLOG(0,0,"IMSI is not 15 digits");
      m_ErrCode = MAP_ERROR_dataMissing;
      return false;
   }
   setTraceImsi((char *)m_imsi);
   m_tdr.setChar(TDR_INDEX_REQUEST_TYPE,'I'); 
   m_tdr.setString(TDR_INDEX_REQUEST_IMSI,m_imsi);
   LLOG(0,0,"Trace enabled on Imsi[%s]",m_imsi);
   struct IMAP1_RequestParameters_ *l_rp = NULL;
   l_rp = aSendParametersReq->requestParameters;
   bool l_reqSubData = false;
   while(l_rp != NULL)
   {
      switch(l_rp->value)
      {
         case IMAP1_request_IMSI:
            {
               WLOG(0,0,"MAP1_request_IMSI present");
            }
            break;
         case IMAP1_request_AuthenticationSet:
            {
               WLOG(0,0,"MAP1_request_AuthenticationSet present");
            }
            break;
         case IMAP1_request_SubscriberData:
            {
               LLOG(0,0,"MAP1_request_SubscriberData present");
               l_reqSubData = true;
            }
            break;
         case IMAP1_request_CUG_Information:
            {
               WLOG(0,0,"MAP1_request_CUG_Information present");
            }
            break;
         case IMAP1_request_Ki:
            {
               WLOG(0,0,"MAP1_request_Ki present");
            }
            break;
         default:
            {
               CLOG(0,0,"unknown request parameter");
            }
            break;
      }
      l_rp = l_rp->next;
   }
   if(false == l_reqSubData)
   {
      LLOG(0,0,"Requested data is not SubscriberData");
      m_ErrCode = MAP_ERROR_systemFailure;
      return false;
   }
   DLOG(0,0,"Check parameters true for dlgId %d",m_InitDlgId);
   return true;
}

bool CtxtScpSendParameters :: handleDbQuery()
{
   SendParamData *l_sp = NULL;
   DLOG(0,0,"In handleDbQuery");
   l_sp = new SendParamData();
   if(l_sp != NULL)
   {
      strcpy(l_sp->m_imsi,(s8*)m_imsi);
      strcpy(l_sp->m_SCPAddress,(s8*)m_SCPAddress);
      LLOG(0,0,"DBIN-SP: IMSI-|%s| SCPADDRESS-|%s|",l_sp->m_imsi,l_sp->m_SCPAddress);
   }
   else
   {
      CLOG(0,0,"Newing SendParamData Failed");
   }
   TLOG(0,0,"Pushing data to DB");
   l_sp->m_cb = this;
   l_sp->m_DbQueryType = 1;
   g_act.execute(l_sp);
   return true; 
}

/////////////////////////////////////////////////////////////////////////////////////////
bool CtxtScpSendParameters :: processMessage(Msg *aMsgPtr,bool& aDeleteFlag)
{
   DLOG(0,0,"Start of ProcessMsg function");
   MapSpecificMsg *l_specMsg = NULL;
   u32 l_UserDlgId = 0;

   switch (aMsgPtr->m_MsgType)
   {
      case MSG_TYPE_MAP:
         switch (((MapMsg*)aMsgPtr)->m_MapMsgType)
         {
            case MAP_MSG_TYPE_COMMON:
               switch (((MapCommonMsg*)aMsgPtr)->m_MapCommonMsgType)
               {
                  case MAP_CMN_OPEN_IND:
                     {
                        DLOG(0,0,"MAP_CMN_OPEN_IND received OriginationGt |%s| DestinationGt |%s|",((MapOpenInd*)aMsgPtr)->m_OrigAddr.globalTitle.addressInformation,((MapOpenInd*)aMsgPtr)->m_DestAddr.globalTitle.addressInformation);
                        strcpy((char *)m_SCPAddress,((MapOpenInd*)aMsgPtr)->m_OrigAddr.globalTitle.addressInformation);
                        m_tdr.setString(TDR_INDEX_SI_GSM_SCF_ADDRESS,(char*)m_SCPAddress);
                        LLOG(0,0,"SCP Address[%s]",m_SCPAddress);
                     }
                     break;

                  case MAP_CMN_DELIMITER_IND:
                     DLOG(0,0,"MAP_CMN_DELIMITER_IND received");
                     break;

                  case MAP_CMN_CLOSE_IND:
                     DLOG(0,0,"MAP_CMN_CLOSE_IND received");
                     return true;
                     break;

                  case MAP_CMN_OPEN_CNF:
                     {
                        u32 l_abrtDlgId = ((MapMsg*)aMsgPtr)->m_UserDlgId;
                        EMapVersion l_MapVersion = ((MapOpenCnf*)aMsgPtr)->m_Version;
                        m_tdr.setInteger(TDR_INDEX_OPEN_CNF_VERSION,(int)l_MapVersion); 
                        CLOG(0,0,"MAP_CMN_OPEN_CNF Received on SendParameters DlgId |%d| just returning",l_abrtDlgId);
                        return true;
                     }
                     break;

                  case MAP_CMN_U_ABORT_IND:
                     {
                        u32 l_abrtDlgId = ((MapMsg*)aMsgPtr)->m_UserDlgId;
                        CLOG(0,0,"MAP_CMN_U_ABORT_IND Received on SendParameters DlgId |%d| just returning",l_abrtDlgId);
                        m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_U_ABORT_RCVD); 
                        return true;
                     }
                     break;

                  case MAP_CMN_P_ABORT_IND:
                     {
                        u32 l_abrtDlgId = ((MapMsg*)aMsgPtr)->m_UserDlgId;
                        CLOG(0,0,"MAP_CMN_P_ABORT_IND Received on SendParameters DlgId |%d| just returning",l_abrtDlgId);
                        m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_P_ABORT_RCVD); 
                        return true;
                     }
                     break;

                  case MAP_CMN_NOTICE_IND:
                     {
                     }
                     break;

                  default:
                     CLOG(0,0,"Unknown Msg received [%d]", ((MapCommonMsg*)aMsgPtr)->m_MapCommonMsgType);
                     break;
               }
               break;

            case MAP_MSG_TYPE_SPECIFIC:
               {
                  l_specMsg = (MapSpecificMsg*)aMsgPtr;
                  l_UserDlgId = l_specMsg->m_UserDlgId; 
                  EMapVersion l_MapVersion = ((MapMsg*)aMsgPtr)->m_Version;

                  switch (((MapSpecificMsg*)aMsgPtr)->m_MapSpecificEventType)
                  {
                     case MAP_SPEC_EVENT_INDICATION:
                        {
                           DLOG(0,0,"MAP_SPEC_EVENT_INDICATION received MapVersion-|%d| DlgId-|%d|",l_MapVersion,l_UserDlgId);
                           switch (((MapSpecificMsg*)aMsgPtr)->m_OpCode)
                           {
                              case MAP_OP_CODE_sendParameters:
                                 {
                                    DLOG(0,0,"Received SendParameters");

                                    if (false == ((MapSpecificMsg*)aMsgPtr)->m_allocatedFlag)
                                    {
                                       CLOG(0,0,"SendParameters Decode Failed - Sending User Error Unexpected Data");
                                       m_ErrCode = MAP_ERROR_unexpectedData;
                                       m_InitDlgId = l_UserDlgId;
                                       m_MapVer = l_MapVersion;
                                       return handleError();
                                    }
                                    else if(NULL == g_spdPtr)
                                    {
                                       CLOG(0,0,"g_spdPTR is NULL .. profile Loading Failed returning SystemFailure");
                                       printf("\n ##### PROFILE LOADING FAILED .. sending system failure #####\n");
                                       m_ErrCode = MAP_ERROR_systemFailure; 
                                       m_InitDlgId = l_UserDlgId;
                                       m_MapVer = l_MapVersion;
                                       return handleError(); 
                                    }
                                    handleSendParameters(aMsgPtr,l_UserDlgId,l_MapVersion);
                                 }
                                 break;

                              default:
                                 {
                                    CLOG(0,0,"Received Unknown Specific Message");
                                    MapUAbortReq l_req(l_UserDlgId);
                                    g_sc.sendMsg(this, &l_req);
                                 }
                                 break;
                           }
                        }
                        break;

                     case MAP_SPEC_EVENT_RESULT:
                        {
                           DLOG(0,0,"MAP_SPEC_EVENT_RESULT received");
                        }
                        break;

                     case MAP_SPEC_EVENT_CONFIRMATION:
                        {
                           DLOG(0,0,"MAP_SPEC_EVENT_CONFIRMATION received MapVersion-|%d| DlgId-|%d|",l_MapVersion,l_UserDlgId);
                        }
                        break;

                     case MAP_SPEC_EVENT_USER_ERROR:
                        {
                           DLOG(0,0,"MAP_SPEC_EVENT_USER_ERROR received");
                        }
                        break;

                     case MAP_SPEC_EVENT_PROV_ERROR:
                        {
                           DLOG(0,0,"MAP_SPEC_EVENT_PROV_ERROR received");
                        }
                        break;
                     default:
                        ELOG(0,0,"ERROR!! Default SPECIFIC MSG received");
                        break;
                  }
               }
               break;

            default:
               break;
         }
         break;

      case MSG_TYPE_DB:
         {
            if(1 ==  ((DbQueryMsg*)aMsgPtr)->m_DbQueryType)
            {
               aDeleteFlag = false;
               SendParamData *l_Msg = (SendParamData *)aMsgPtr;

               DLOG(0,0,"DBRES: m_EdbResult |%d|",l_Msg->m_ErrorCode);

               mp_sp = l_Msg;

               LLOG(0,0,"DBRES: SENDPARAM HLRAddress:[%s] PrimaryMsisdn[%s] PrimaryImsi[%s] ActiveMsisdn[%s] NetId[%d] PartNetId[%d]",mp_sp->m_HlrAddr,mp_sp->m_PrimaryMsisdn,mp_sp->m_PrimaryImsi,mp_sp->m_ActiveMsisdn,mp_sp->m_networkId,mp_sp->m_partnerNetworkId);
               if(strlen((s8*)mp_sp->m_HlrAddr) > 1) 
               {
                  sendMapOpenResponse(m_InitDlgId,(s8*)mp_sp->m_HlrAddr,g_ConfigData->i_NgConfigData.m_selfAddress.ssn);
                  m_tdr.setString(TDR_INDEX_LOCAL_ADDRESS,(s8*)mp_sp->m_HlrAddr); 
               }
               else
               {
                  WLOG(0,0,"DBRES: SendParameters GT not present in SubsData picking from NgConfig");
               }
               m_tdr.setString(TDR_INDEX_REQUEST_MSISDN,mp_sp->m_ActiveMsisdn);
               m_tdr.setString(TDR_INDEX_MM_PRIMARY_MSISDN,mp_sp->m_PrimaryMsisdn);
               m_tdr.setString(TDR_INDEX_MM_PRIMARY_IMSI,mp_sp->m_PrimaryImsi);
               m_tdr.setString(TDR_INDEX_RESRV4,"SCPSP");


               if(0 != l_Msg->m_ErrorCode)
               {
                  CLOG(0,0,"DB Failure .. Error Code Value|%d|  ErrorDesc|%s|",l_Msg->m_ErrorCode,l_Msg->m_ErrorMsg);
                  m_tdr.setInteger(TDR_INDEX_DB_ERR_CODE, (abs)(((DbQueryMsg*)aMsgPtr)->m_procErrorCode));
                  m_tdr.setString(TDR_INDEX_DB_ERR_DESC, ((DbQueryMsg*)aMsgPtr)->m_procErrorMessage);
                  if(3 == l_Msg->m_ErrorCode)
                  {
                     WLOG(0,0,"Client Validation failed .. sending Unexpected Data");
                     m_ErrCode = MAP_ERROR_unexpectedData;
                  }
                  else if(1 == l_Msg->m_ErrorCode)
                  {
                     WLOG(0,0,"Invalid Imsi .. sending Unknown subscriber");
                     m_ErrCode = MAP_ERROR_unknownSubscriber;
                  }
                  else
                  {
                     WLOG(0,0,"DB Exception sending System failure");
                     m_ErrCode = MAP_ERROR_systemFailure;
                  }
                  return handleError(); 
               }
               else 
               {
                  LLOG(0,0,"DBRES: NetworkId:|%d| PartnerNetworkId:|%d| HlrAddress|%s| CfwdInfoCount:|%d|",mp_sp->m_networkId,mp_sp->m_partnerNetworkId,mp_sp->m_HlrAddr,mp_sp->m_CFCount);

                  sendSendParametersResp();
               }
            }
            else
            {
               ELOG(0,0,"Unknown DB message");
            }
         }
         break;

      default:
         CLOG(0,0,"Unknown message received");
         break;
   }
   return true;
}
