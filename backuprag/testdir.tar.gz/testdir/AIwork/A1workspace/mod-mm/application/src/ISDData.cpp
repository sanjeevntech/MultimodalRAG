/*******************************************************************************
 * File        : ISDData.cpp
 * Author      : VenkatRaman
 * Description : To fill ISD params, called by UPD,UPG and RSD
 * Created on  : March 27, 2010, 5:34 PM IST
 *******************************************************************************/

#include <stdio.h>
#include <ServiceCoordinator.h>
#include <MapMessages.h>
#include <Logger.h>
#include <DbQueryMsg.h>
#include <DbActiveObject.h>
#include <AsnCodec.h>
#include <SubsProfileData.h>
#include <SubsProfilesManager.h>
#include <DataUnion.h>
#include <Utilities.h>

#include <ISDData.h>
#include <CtxtCancelLocation.h>
#include <ContextBase.h>

extern AsnCodec g_AsnCodecO3;
extern AsnCodec g_AsnCodecO2;
extern AsnCodec g_AsnCodecO1;



ISDData::ISDData()
{
   DLOG(0,0,"ISDData::ISDData()");
   MsgOpCode = 0;
   IsdLen = 0;
   memset(&dbisd3,'\0',sizeof(dbisd3));
   memset(&dbisd2,'\0',sizeof(dbisd2));
   memset(&dbisd1,'\0',sizeof(dbisd1));
   m_SecondChunk = false;
   memset(m_Unsupp_Bearer,'\0',sizeof(m_Unsupp_Bearer));
   memset(m_Unsupp_Bearer,'0',52);
   memset(m_Unsupp_Tele,'\0',sizeof(m_Unsupp_Tele));
   memset(m_Unsupp_Tele,'0',32);
   memset(m_Unsupp_SS,'\0',sizeof(m_Unsupp_SS));
   m_Unsupp_ODB = 0;
   m_IsdResp_With_Unsupp_Service_Rcvd = false;
   m_MM_TDR_CSI_FLAGS = 0; // Added in 1.0.8.0 to write CSI info in TDR
   m_AllDataAdded = false;
}

ISDData::~ISDData()
{
   DLOG(0,0,"ISDData::~ISDData()");
}



bool ISDData::FormISDReqV3(int l_UserDlgId,unsigned int &index,unsigned int &VcsiIndex,unsigned int &ScsiIndex,unsigned int &SsIndex,bool flag,struct dbisd3,int &opCode,OMAP3_InsertSubscriberDataArg *l_isd)
{
   MsgOpCode = opCode;
   DLOG(0,0,"Inside FormISDReqV3 for Dialog Id %d for the OpCode %d [Opcode -> 2 Update location request,Opcode -> 23 Update GPRS Location,Opcode -> 57 Restore Data]",l_UserDlgId,MsgOpCode);
   DLOG(0,0,"Request for ISD V3 with index %x SsIndex %x and CSI Index %x",index,SsIndex,VcsiIndex);
   pLen = 0;  len = 0;   

   IsdLen = g_MmConfigReaderObj->m_IsdLen;
   DLOG(0, 0, "Forming ISD request for Dialog Id %d,ISD data length configured is %d bytes",l_UserDlgId,IsdLen);
   l_isd->bit_mask = 0;
   switch(index)
   {
      case OMAP3_InsertSubscriberDataArg_imsi_present://80000000
         {
            //DLOG(0,0,"Adding IMSI");
            if(dbisd3.imsiReqd)
            {
               l_isd->bit_mask = OMAP3_InsertSubscriberDataArg_imsi_present;
               int len1 = strlen((char *)dbisd3.imsi);
               l_isd->imsi.length = (len1/2)+1;
               StringToBCD(l_isd->imsi.value,dbisd3.imsi,len1);
               len = l_isd->imsi.length;
               DLOG(0,0,"Added IMSI[%s]",(char*)dbisd3.imsi);
            }
         }

      case OMAP3_InsertSubscriberDataArg_msisdn_present://40000000
         {
            {
               //DLOG(0,0,"Adding MSISDN in ISD");
               l_isd->bit_mask |= OMAP3_InsertSubscriberDataArg_msisdn_present;
               u8 finalMsisdn[21];
               memset(finalMsisdn, '\0', sizeof(finalMsisdn));
               strncpy((char *)finalMsisdn,"19",2);
               DLOG(0,0,"Received MSISDN in ISD as %s",(char *)dbisd3.msisdn);
               strncat((char *)finalMsisdn,(char *)dbisd3.msisdn,strlen((char *)dbisd3.msisdn));               
               int len2 = strlen((char *)finalMsisdn);
               l_isd->msisdn.length = (len2+1)/2;
               StringToBCD(l_isd->msisdn.value,finalMsisdn,len2);
               len = l_isd->msisdn.length + 7; 
               DLOG(0,0,"Added MSISDN");
            }          
            //index = OMAP3_category_present;
         }

      case OMAP3_category_present://20000000
         {
            if(dbisd3.category)
            {
               l_isd->bit_mask |= OMAP3_category_present;
               l_isd->category.length = 1;
               l_isd->category.value[0]=dbisd3.category;
               DLOG(0,0,"Added CATEGORY");
            }

            //Adding network access mode
            l_isd->bit_mask |= OMAP3_networkAccessMode_present;
            l_isd->networkAccessMode = (OMAP3_NetworkAccessMode)dbisd3.nwAccMode;
            DLOG(0,0,"Added Network Access Mode");
            pLen = len;
            len += 6;

            //index = OMAP3_subscriberStatus_present;
         }

      case OMAP3_subscriberStatus_present: //10000000
         {
            l_isd->bit_mask |= OMAP3_subscriberStatus_present;
            l_isd->subscriberStatus = (OMAP3_SubscriberStatus)dbisd3.subStatus;
            DLOG(0,0,"Added SUBSCRIBER STATUS %d",dbisd3.subStatus);
            pLen = len;
            len += 3;
            //int asnLen = CheckLengthV3(l_isd);
            //DLOG(0,0,"Added tll Subscriber status , length of ISD string formed till now is %d get encoding length is %d",len,asnLen);
         }

      case OMAP3_InsertSubscriberDataArg_bearerServiceList_present: //08000000
         {
            if(dbisd3.bearer)
            {
               int l_PrevCount = 0;
               DLOG(0,0,"Bearer service data received from DB is %s",dbisd3.bearerData);
               if(false == m_SecondChunk)
               {
                  bs.formBearerV3C1(l_UserDlgId,l_isd,dbisd3.bearerData);
                  DLOG(0,0,"Count of Bearer Service after Adding is %d",l_isd->bearerServiceList.count);
                  pLen = len;
                  len = len + 3+ (l_isd->bearerServiceList.count*3);
                  l_PrevCount = l_isd->bearerServiceList.count;
                  /*if (len >=IsdLen)
                    {
                    LLOG(0,0,"Current length is %d sending till Subscriber Status",pLen);
                    index = OMAP3_InsertSubscriberDataArg_bearerServiceList_present;
                    l_isd->bit_mask &= (~OMAP3_InsertSubscriberDataArg_bearerServiceList_present);
                    flag = true;
                    m_SecondChunk = true;
                    return true;
                    break;
                    }*/
               }
               if(m_SecondChunk)
                  l_isd->bearerServiceList.count = 0;
               bs.formBearerV3C2(l_UserDlgId,l_isd,dbisd3.bearerData);
               DLOG(0,0,"Count of Bearer Service after Adding is %d",l_isd->bearerServiceList.count);
               pLen = len;
               len = len + 3+ (l_isd->bearerServiceList.count*3);
               if (len >=IsdLen)
               {
                  TLOG(0,0,"Current length is %d sending till Subscriber Status",pLen);
                  index = OMAP3_InsertSubscriberDataArg_bearerServiceList_present;
                  //l_isd->bit_mask &= (~OMAP3_InsertSubscriberDataArg_bearerServiceList_present);
                  l_isd->bearerServiceList.count = l_PrevCount;
                  flag = true;
                  m_SecondChunk = true;
                  return true;
                  break;
               }

               DLOG(0,0,"The Encoding length till here is %d BEARER SERVICE added %d",len,(len-pLen));
            }
            flag = false;
         }

      case OMAP3_InsertSubscriberDataArg_teleserviceList_present: //04000000
         {
            DLOG(0,0,"Tele Service data received from DB is %s",dbisd3.teleData);
            bs.formTeleV3(l_UserDlgId,l_isd,dbisd3.teleData);
            DLOG(0,0,"Count of Tele Service after Adding is %d",l_isd->teleserviceList.count);
            pLen = len;
            len = len + 3 + (l_isd->teleserviceList.count*3);
            if(len > IsdLen)
            {
               TLOG(0,0,"Current length is %d Bearer service list",pLen);
               index = OMAP3_InsertSubscriberDataArg_teleserviceList_present;
               l_isd->bit_mask &= (~OMAP3_InsertSubscriberDataArg_teleserviceList_present);
               flag = true;
               return true;
               break;
            }
            DLOG(0,0,"The Encoding length till here is %d TELE SERVICE added %d",len,(len-pLen));
            pLen = len;
            flag = false;
         }

      case OMAP3_provisionedSS_present: //02000000
         {
            DLOG(0,0,"Forming Supplementary service data");
            switch(SsIndex)
            {
               case OMAP3_Ext_SS_Info_forwardingInfo_chosen: //choice 1
                  {
                     l_isd->bit_mask |= OMAP3_provisionedSS_present;
                     l_isd->provisionedSS.count = 0;
                     //int rret = pss.formFwdSS3(l_UserDlgId,l_isd,g_MmConfigReaderObj->m_IsdLen);
                     //pLen = len = CheckLengthV3(l_isd);
                     TLOG(0,0,"Going to add FWD info,CFWD State is %d,Length of ISD till now formed is stored as %d",pss.CFWD_STATE,len);
                     //int rret = pss.formFwdSS3(l_isd,len); -- opti to be done
                     int rret = pss.formFwdSS3(l_isd);
                     if(l_isd->provisionedSS.count == 0)
                     {
                        l_isd->bit_mask &= (~OMAP3_provisionedSS_present);
                     }
                     len = CheckLengthV3(l_isd);
                     pLen = len;
                     DLOG(0,0,"Length of ISD till now formed is %d, returned value %d, SS Count added till is %d",len,rret,l_isd->provisionedSS.count);
                     if(1 == rret)
                     {
                        TLOG(0,0,"Current length is %d sending till Teleservice list",pLen);
                        index = OMAP3_provisionedSS_present;
                        l_isd->bit_mask &= (~OMAP3_provisionedSS_present);
                        SsIndex = OMAP3_Ext_SS_Info_forwardingInfo_chosen;
                        pss.val = 0;
                        DLOG(0,0,"Reset Count to %d,CFWD State is %d",pss.val,pss.CFWD_STATE);                        
                        flag = true;
                        return true;
                        break;
                     }
                     else if(2 == rret)
                     {
                        TLOG(0,0,"Current length is %d sending till SS data count %d",pLen,l_isd->provisionedSS.count);
                        //DLOG(0,0,"Length after adding CFWD is %d\n",len);
                        index = OMAP3_provisionedSS_present;
                        //l_isd->bit_mask &= (~OMAP3_provisionedSS_present);
                        SsIndex = OMAP3_Ext_SS_Info_forwardingInfo_chosen;
                        pss.val = 0;
                        DLOG(0,0,"Reset val to %d,CFWD State is %d",pss.val,pss.CFWD_STATE);
                        flag = true;
                        return true;
                        break;
                     }

                     else
                     {

                        DLOG(0,0,"After Call FWD unconditional Info.The Encoding length till here is %d PROVISIONEDSS added %d",len,(len-pLen));
                        index = OMAP3_provisionedSS_present;
                        flag = false;
                        SsIndex = OMAP3_Ext_SS_Info_callBarringInfo_chosen;
                        pLen = len;
                     }
                  }
                  //break;
               case OMAP3_Ext_SS_Info_callBarringInfo_chosen: //choice 2
                  {
                     l_isd->bit_mask |= OMAP3_provisionedSS_present;
                     DLOG(0,0,"going to add CB info,SS Count value is %d,CB State is %d len [%d]",pss.val,pss.CB_STATE,pLen);                     
                     //int reet = pss.formCbSS3(l_UserDlgId,l_isd,g_MmConfigReaderObj->m_IsdLen);
                     //int reet = pss.formCbSS3(l_isd,pLen); --> opti to be done
                     int reet = pss.formCbSS3(l_isd);
                     DLOG(0,0,"CB SS data returned %d",reet);
                     if(l_isd->provisionedSS.count == 0)
                     {
                        l_isd->bit_mask &= (~OMAP3_provisionedSS_present);
                     }
                     if(reet == 1)
                     {
                        DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                        index = OMAP3_provisionedSS_present;
                        DLOG(0,0,"Length after adding CB is %d",len);
                        l_isd->bit_mask &= (~OMAP3_provisionedSS_present);
                        SsIndex = OMAP3_Ext_SS_Info_callBarringInfo_chosen;
                        pss.val = 0;
                        DLOG(0,0,"Reset count to %d",pss.val);
                        flag = true;
                        return true;
                        break;
                     }
                     else if(reet == 2)
                     {
                        TLOG(0,0,"Sending ISD till SS Count %d",l_isd->provisionedSS.count);
                        index = OMAP3_provisionedSS_present;                            
                        SsIndex = OMAP3_Ext_SS_Info_callBarringInfo_chosen;
                        pss.val = 0;
                        DLOG(0,0,"Reset val to %d",pss.val);
                        flag = true;
                        return true;
                        break;
                     }
                     else// RETT WILL BE 0
                     {    
                        if(pss.val == 0)
                        {
                           l_isd->bit_mask &= (~OMAP3_provisionedSS_present);
                        }
                        flag = false;
                        SsIndex = OMAP3_Ext_SS_Info_ss_Data_chosen;                     
                        DLOG(0,0,"ISD filled till Call Barring, continuing with remaining, len is %d and pLen is %d",len,pLen);
                        pLen = len;
                     }                     
                     //if( (MsgOpCode == 23)||(111 == MsgOpCode) )
                     if(MsgOpCode == 23)
                     {
                        DLOG(0,0,"Breaking and not filling SS info as opcode is [%d]",MsgOpCode);
                        break;
                     }
                  }
                  //break;
               case OMAP3_Ext_SS_Info_ss_Data_chosen:
                  {
                     l_isd->bit_mask |= OMAP3_provisionedSS_present;
                     PrevSS = pss.val;
                     //len = CheckLengthV3(l_isd);
                     DLOG(0,0,"Going to form Ext_SS_Info Count here is %d,Length of ISD till now formed is %d",pss.val,len);                     
                     //int rett = pss.formSsSS3(l_UserDlgId,l_isd,len);
                     int rett = pss.formSsSS3(l_isd);
                     len = CheckLengthV3(l_isd);
                     pLen = len;
                     DLOG(0,0,"Retruned from General SS Count here is %d return value is %d, length of ISD data added %d",l_isd->provisionedSS.count,rett,len);
                     if(l_isd->provisionedSS.count == 0)
                     {
                        l_isd->bit_mask &= (~OMAP3_provisionedSS_present);
                     }                     
                     if(rett == 1)
                     {
                        TLOG(0,0,"Current length is %d sending till SS Count %d",pLen,l_isd->provisionedSS.count);
                        index = OMAP3_provisionedSS_present;
                        DLOG(0,0,"Length after adding SS is %d\n",len);
                        l_isd->bit_mask &= (~OMAP3_provisionedSS_present);
                        SsIndex = OMAP3_Ext_SS_Info_ss_Data_chosen;
                        index = OMAP3_provisionedSS_present;
                        pss.m_GenSsCount = 0;
                        pss.val = 0;
                        flag = true;
                        return true;
                        break;
                     }
                     else if(rett == 2)
                     {                          
                        if(len  > IsdLen)
                        {
                           l_isd->bit_mask &= (~OMAP3_provisionedSS_present);
                           SsIndex = OMAP3_Ext_SS_Info_ss_Data_chosen;
                           index = OMAP3_provisionedSS_present;
                           pss.m_GenSsCount = 0;
                           pss.val = 0;
                           TLOG(0,0,"Sending ISD till SS Count %d",l_isd->provisionedSS.count);
                           return true;
                        }                        
                        SsIndex = OMAP3_Ext_SS_Info_ss_Data_chosen;
                        index = OMAP3_provisionedSS_present;
                        pss.val = 0;
                        TLOG(0,0,"Sending ISD till SS Count %d",l_isd->provisionedSS.count);
                        flag = true;
                        return true;
                        break;
                     }
                     else
                     {                          
                        if(len >IsdLen)
                        {
                           l_isd->bit_mask &= (~OMAP3_provisionedSS_present);
                           SsIndex = OMAP3_Ext_SS_Info_ss_Data_chosen;
                           index = OMAP3_provisionedSS_present;
                           pss.m_GenSsCount = 0;
                           pss.val = 0;
                           TLOG(0,0,"Sending ISD till SS Count %d",l_isd->provisionedSS.count);
                           return true;
                        }
                        flag = false;
                        SsIndex = OMAP3_emlpp_Info_chosen;
                        pss.val = 0;
                        DLOG(0,0,"The Encoding length till here is %d PROVISIONEDSS added %d",len,(len-pLen));
                        pLen = len;
                     }
                  }
                  //break;

               case OMAP3_emlpp_Info_chosen:
                  {
                     l_isd->bit_mask |= OMAP3_provisionedSS_present;
                     DLOG(0,0,"Inside Emlpp for Count %d",pss.val);
                     int retu = 0;
                     //retu = pss.formEmSS3(l_UserDlgId,l_isd,g_MmConfigReaderObj->m_IsdLen);
                     retu = pss.formEmSS3(l_isd);
                     DLOG(0,0,"Finished adding Emlpp in Provisioned SS data,Value returned is %d, SS Count value is %d",retu,l_isd->provisionedSS.count);
                     if(l_isd->provisionedSS.count == 0)
                     {
                        l_isd->bit_mask &= (~OMAP3_provisionedSS_present);
                     }    
                     if(retu == 1)
                     {                          
                        TLOG(0,0,"Sending ISD till SS Count of %d",l_isd->provisionedSS.count);
                        index = OMAP3_provisionedSS_present;
                        l_isd->bit_mask &= (~OMAP3_provisionedSS_present);
                        SsIndex = OMAP3_emlpp_Info_chosen;
                        pss.val = 0;
                        DLOG(0,0,"Reset count to %d",pss.val);
                        flag = true;
                        return true;
                        break;
                     }
                     else if(retu == 2)
                     {
                        DLOG(0,0,"Sending ISD length %d",pLen);
                        index = OMAP3_provisionedSS_present;                        
                        SsIndex = OMAP3_emlpp_Info_chosen;
                        pss.val = 0;
                        DLOG(0,0,"Reset count to %d",pss.val);
                        flag = true;
                        return true;
                        break;
                     }
                     else
                     {
                        DLOG(0,0,"SS Count obtained here is %d",pss.val);                        
                        flag = false;
                        SsIndex = 0;//OMAP3_Ext_SS_Info_callBarringInfo_chosen;
                        DLOG(0,0,"The Encoding length till here is %d PROVISIONEDSS added %d",len,(len-pLen));
                        pLen = len;
                     }
                     if(l_isd->provisionedSS.count == 0)
                     {
                        l_isd->bit_mask &= (~OMAP3_provisionedSS_present);
                     }
                  }//break;
               default:
                  {
                     //DLOG(0,0,"Inside Default");
                     SsIndex = 0;
                     index = OMAP3_odb_Data_present;
                  }
                  //break;
            }
            if(flag)
               break;
            else
            {
               DLOG(0,0,"After Provisioned SS,continuing with remaing ISD");
               //g_AsnCodecO3.printPdu(OMAP3_InsertSubscriberDataArg_PDU,l_isd,1,0);
               index = OMAP3_odb_Data_present;
            }
            index = OMAP3_odb_Data_present;
         }
         //break;

      case OMAP3_odb_Data_present: //01000000
         {
            if(dbisd3.odb_Data)
            {
               if(dbisd3.odb_HplmnData)
               {
                  l_isd->bit_mask |= OMAP3_odb_Data_present;
                  l_isd->odb_Data.odb_GeneralData.length = 0;
                  l_isd->odb_Data.bit_mask = OMAP3_odb_HPLMN_Data_present;
                  union Hdata
                  {
                     unsigned int l_Hodb;
                     unsigned char l_testhOdb[4];
                  };
                  Hdata l_HomOdb;
                  l_HomOdb.l_Hodb = dbisd3.odb_HplmnValue;
#ifdef SunOS
                  l_isd->odb_Data.odb_HPLMN_Data.value[0] = l_HomOdb.l_testhOdb[0];
#else
                  l_isd->odb_Data.odb_HPLMN_Data.value[0] = l_HomOdb.l_testhOdb[3];
#endif
                  l_isd->odb_Data.odb_HPLMN_Data.length = 4;
                  TLOG(0,0,"Added ODB HPLMN specific Data %ld, adding length %d, value %02x",dbisd3.odb_HplmnValue,l_isd->odb_Data.odb_HPLMN_Data.length,l_isd->odb_Data.odb_HPLMN_Data.value[0]);               
               }
               if(dbisd3.odb_GenData)
               {
                  l_isd->bit_mask |= OMAP3_odb_Data_present;
                  union data
                  {
                     unsigned int l_Godb;
                     unsigned char l_testOdb[4];
                  };
                  data l_GenOdb;
                  l_GenOdb.l_Godb = dbisd3.odb_Genvalue;
#ifdef SunOS
                  memcpy(l_isd->odb_Data.odb_GeneralData.value,l_GenOdb.l_testOdb,4);
#else
                  l_isd->odb_Data.odb_GeneralData.value[0]=l_GenOdb.l_testOdb[3];
                  l_isd->odb_Data.odb_GeneralData.value[1]=l_GenOdb.l_testOdb[2];
                  l_isd->odb_Data.odb_GeneralData.value[2]=l_GenOdb.l_testOdb[1];
                  l_isd->odb_Data.odb_GeneralData.value[3]=l_GenOdb.l_testOdb[0];
#endif
                  int l_genlen = getNumberOfSignificantBitsForAnArray(l_isd->odb_Data.odb_GeneralData.value,4);
                  if(15 <= l_genlen ) 
                  {
                     l_isd->odb_Data.odb_GeneralData.length = l_genlen;
                  }
                  else
                  {
                     l_isd->odb_Data.odb_GeneralData.length = 15;
                  }
                  TLOG(0,0,"Adding ODB General Data %ld, adding length %d, value %02x%02x%02x%02x",dbisd3.odb_Genvalue,l_isd->odb_Data.odb_GeneralData.length,l_isd->odb_Data.odb_GeneralData.value[0],l_isd->odb_Data.odb_GeneralData.value[1],l_isd->odb_Data.odb_GeneralData.value[2],l_isd->odb_Data.odb_GeneralData.value[3]);
               }
               len = CheckLengthV3(l_isd);
               if (len  >=IsdLen)
               {
                  DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                  index = OMAP3_odb_Data_present;
                  l_isd->bit_mask &= (~OMAP3_odb_Data_present);
                  flag = true;
                  return true;
                  break;
               }
               DLOG(0,0,"The Encoding length till here is %d ODB_DATA added %d",len,(len-pLen));
               pLen = len;
            }
            DLOG(0,0,"Added odb data");
            index = OMAP3_InsertSubscriberDataArg_roamingRestrictionDueToUnsupportedFeature_present;
         }
         //break;

      case OMAP3_InsertSubscriberDataArg_roamingRestrictionDueToUnsupportedFeature_present: //00800000
         {
#if 0
            if(0)
            {
               LLOG(0,0,"SEND_ROAMREST_ISD %s",getenv("SEND_ROAMREST_ISD"));
               l_isd->bit_mask |= OMAP3_InsertSubscriberDataArg_roamingRestrictionDueToUnsupportedFeature_present;
               if ((len = CheckLengthV3(l_isd)) >=IsdLen)
               {
                  DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                  index = OMAP3_InsertSubscriberDataArg_roamingRestrictionDueToUnsupportedFeature_present;
                  l_isd->bit_mask &= (~OMAP3_InsertSubscriberDataArg_roamingRestrictionDueToUnsupportedFeature_present);
                  return true;
                  break;
               }
               LLOG(0,0,"The Encoding length till here is %d Roaming Restricted Due to Unsupported Feature added %d",len,(len-pLen));
               pLen = len;
            }
#endif
            index = OMAP3_regionalSubscriptionData_present;
         }
         //break;

      case OMAP3_regionalSubscriptionData_present: //00400000
         {
#if 0//Not supported
            if(0)//dbisd3.zC)
            {
               l_isd->bit_mask |= OMAP3_regionalSubscriptionData_present;
               //db_data->HLR_SUBS_RSZI_LIST.ZONE_CODE1
               l_isd->regionalSubscriptionData.count = 1;
               l_isd->regionalSubscriptionData.value[0].length = 1;
               l_isd->regionalSubscriptionData.value[0].value[0] = 0x37;
               //if ((len = CheckLengthV3(l_isd)) >=IsdLen)
               {
                  DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                  index = OMAP3_regionalSubscriptionData_present;
                  l_isd->bit_mask &= (~OMAP3_regionalSubscriptionData_present);
                  SendIsdV3(l_UserDlgId,l_request,l_isd,index,VcsiIndex,MsgOpCode);
                  break;
               }
               DLOG(0,0,"The Encoding length till here is %d REGIONAL SUBSCRIPTION DATA added %d",len,(len-pLen));
               pLen = len;
               index = OMAP3_vbsSubscriptionData_present;
            }
#endif
         }
         //break;

      case OMAP3_vbsSubscriptionData_present: //00200000
         {
#if 0
            if(0)//dbisd3.VBS)
            {
               l_isd->bit_mask |= OMAP3_vbsSubscriptionData_present;
               l_isd->vbsSubscriptionData.count = 1;
               l_isd->vbsSubscriptionData.value[0].groupid.length = 1;
               l_isd->vbsSubscriptionData.value[0].groupid.value[0] = 0x38;
               l_isd->vbsSubscriptionData.value[0].bit_mask = OMAP3_broadcastInitEntitlement_present;
               //if ((len = CheckLengthV3(l_isd)) >=IsdLen)
               {
                  DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                  index = OMAP3_vbsSubscriptionData_present;
                  l_isd->bit_mask &= (~OMAP3_vbsSubscriptionData_present);
                  SendIsdV3(l_UserDlgId,l_request,l_isd,index,MsgOpCode);
                  break;
               }
               DLOG(0,0,"The Encoding length till here is %d VBS SUBSCRIPTION DATA added %d",len,(len-pLen));
               pLen = len;
            }
#endif
            index = OMAP3_vgcsSubscriptionData_present;
         }
         //break;

      case OMAP3_vgcsSubscriptionData_present: //00100000
         {
#if 0
            if(0)//dbisd3.VGCS)
            {
               l_isd->bit_mask |= OMAP3_vgcsSubscriptionData_present;
               l_isd->vgcsSubscriptionData.count = 1;
               l_isd->vgcsSubscriptionData.value[0].groupId.length = 1;
               l_isd->vgcsSubscriptionData.value[0].groupId.value[0] = 0x39;
               l_isd->vgcsSubscriptionData.value[0].bit_mask = OMAP3_additionalSubscriptions_present;
               u8 vgcs[1];
               l_isd->vgcsSubscriptionData.value[0].additionalSubscriptions.value = vgcs;
               l_isd->vgcsSubscriptionData.value[0].additionalSubscriptions.length = 8;
               l_isd->vgcsSubscriptionData.value[0].additionalSubscriptions.value[0] = OMAP3_privilegedUplinkRequest;
               //if ((len = CheckLengthV3(l_isd)) >=IsdLen)
               {
                  DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                  index = OMAP3_vgcsSubscriptionData_present;
                  l_isd->bit_mask &= (~OMAP3_vgcsSubscriptionData_present);
                  SendIsdV3(l_UserDlgId,l_request,l_isd,index,MsgOpCode);
                  break;
               }
               DLOG(0,0,"The Encoding length till here is %d VGCS SUBSCRIPTION DATA added %d",len,(len-pLen));
               pLen = len;
            }
#endif
            index = OMAP3_vlrCamelSubscriptionInfo_present;
         }
         //break;

      case OMAP3_vlrCamelSubscriptionInfo_present://00080000
         {
            int LenBeforeCSI = CheckLengthV3(l_isd);
            DLOG(0,0,"Length before VLR CSI info is %d",LenBeforeCSI);
            if(dbisd3.VLRCsi)
            {
               DLOG(0,0,"Going to add VLR CSI for ISD, Camel phase supported VLR is %d",dbisd3.CamelPhase);
               l_isd->bit_mask |= OMAP3_vlrCamelSubscriptionInfo_present;
               l_isd->vlrCamelSubscriptionInfo.bit_mask = 0;
               DLOG(0,0,"Forming VLR Camel Subscription information for Dialog ID %d,Index value here is %x, VcsiIndex value is %x",l_UserDlgId,index,VcsiIndex);
               switch(VcsiIndex)
               {
                  case OMAP3_VlrCamelSubscriptionInfo_o_CSI_present://8000
                     {
                        DLOG(0,0,"Camel phase supported %d, OCSI profile id %d",dbisd3.CamelPhase,vlrcsi.vcsi.ocsi);
                        if((dbisd3.CamelPhase >= 1) && (vlrcsi.vcsi.ocsi))
                        {
                           DLOG(0,0,"Checking O_CSI");
                           //vlrcsi.formOCsi(l_UserDlgId,l_isd);
                           vlrcsi.formOCsi(l_isd);
                           //DLOG(0,0,"Returned to ISDData after adding OCSI");
                           if ((len = CheckLengthV3(l_isd)) >=IsdLen)
                           {
                              DLOG(0,0,"Length limit exceeded in OCSI,removing VLR CSI info");
                              index = OMAP3_vlrCamelSubscriptionInfo_present;
                              VcsiIndex = OMAP3_VlrCamelSubscriptionInfo_o_CSI_present;
                              l_isd->vlrCamelSubscriptionInfo.bit_mask &= (~OMAP3_VlrCamelSubscriptionInfo_o_CSI_present);
                              l_isd->bit_mask &= (~OMAP3_vlrCamelSubscriptionInfo_present);
                              flag = true;
                              return true;
                              break;
                           }
                           DLOG(0,0,"The Encoding length till OCSI info is %d VLR CAMEL SUBSCRIPTION INFO added %d",len,(len-pLen));
                           m_MM_TDR_CSI_FLAGS |= MM_TDR_O_CSI_PRESENT;
                           pLen = len;
                           flag = false;
                        }
                        index = OMAP3_vlrCamelSubscriptionInfo_present;
                        VcsiIndex = OMAP3_VlrCamelSubscriptionInfo_ss_CSI_present;
                     }
                     //break

                  case OMAP3_VlrCamelSubscriptionInfo_ss_CSI_present://2000
                     {
                        DLOG(0,0,"Camel phase supported %d, SS_CSI profile id %d",dbisd3.CamelPhase,vlrcsi.vcsi.sscsi);
                        if((dbisd3.CamelPhase >=2) && (vlrcsi.vcsi.sscsi))
                        {
                           DLOG(0,0,"Going to SS CSI for ISD");
                           //vlrcsi.formSsCsi(l_UserDlgId,l_isd);
                           vlrcsi.formSsCsi(l_isd);
                           DLOG(0,0,"Returned from SS CSI");
                           if ((len = CheckLengthV3(l_isd)) >=IsdLen)
                           {
                              DLOG(0,0,"Length limit exceeded in SSCSI,removing VLR CSI info");
                              index = OMAP3_vlrCamelSubscriptionInfo_present;
                              VcsiIndex = OMAP3_VlrCamelSubscriptionInfo_o_CSI_present;
                              l_isd->vlrCamelSubscriptionInfo.bit_mask &= (~OMAP3_VlrCamelSubscriptionInfo_ss_CSI_present);
                              l_isd->bit_mask &= (~OMAP3_vlrCamelSubscriptionInfo_present);
                              flag = true;
                              return true;
                              break;
                           }
                           DLOG(0,0,"The Encoding length till SSCSI info is %d VLR CAMEL SUBSCRIPTION INFO added %d",len,(len-pLen));
                           m_MM_TDR_CSI_FLAGS |= MM_TDR_SS_CSI_PRESENT;
                           pLen = len;
                           flag = false;
                        }
                        index = OMAP3_vlrCamelSubscriptionInfo_present;
                        VcsiIndex = OMAP3_VlrCamelSubscriptionInfo_tif_CSI_present;
                     }
                     //break;
#if 0
                  case OMAP3_VlrCamelSubscriptionInfo_tif_CSI_present://0800
                     {
                        DLOG(0,0,"Camel phase supported %d, TIF_CSI profile id %d",dbisd3.CamelPhase,vlrcsi.vcsi.tifcsi);
                        if((dbisd3.CamelPhase >= 2) && (vlrcsi.vcsi.tifcsi))
                        {
                           DLOG(0,0,"Checking TIF_CSI ");
                           //vlrcsi.formTifCsi(l_UserDlgId,l_isd);
                           vlrcsi.formTifCsi(l_isd);
                           //DLOG(0,0,"Returned from TIF CSI");
                           if ((len = CheckLengthV3(l_isd)) >=IsdLen)
                           {
                              DLOG(0,0,"Length limit exceeded in TIF CSI,removing VLR CSI info");
                              index = OMAP3_vlrCamelSubscriptionInfo_present;
                              VcsiIndex = OMAP3_VlrCamelSubscriptionInfo_o_CSI_present;
                              l_isd->vlrCamelSubscriptionInfo.bit_mask &= (~OMAP3_VlrCamelSubscriptionInfo_tif_CSI_present);
                              l_isd->bit_mask &= (~OMAP3_vlrCamelSubscriptionInfo_present);
                              flag = true;
                              return true;
                              break;
                           }
                           DLOG(0,0,"The Encoding length till TIFCSI info is %d VLR CAMEL SUBSCRIPTION INFO added %d",len,(len-pLen));
                           m_MM_TDR_CSI_FLAGS |= MM_TDR_TIF_CSI_PRESENT;
                           pLen = len;
                           flag = false;
                        }
                        index = OMAP3_vlrCamelSubscriptionInfo_present;
                        VcsiIndex = OMAP3_VlrCamelSubscriptionInfo_o_BcsmCamelTDP_CriteriaList_present;
                     }
                     //break;

#endif

                  case OMAP3_VlrCamelSubscriptionInfo_o_BcsmCamelTDP_CriteriaList_present://1000
                     {
                        DLOG(0,0,"Camel phase supported %d, O_CSI profile id %d",dbisd3.CamelPhase,vlrcsi.vcsi.ocsi);
                        if((dbisd3.CamelPhase >= 2) && (vlrcsi.vcsi.ocsi))
                        {
                           //vlrcsi.formObcsmTdp(l_UserDlgId,l_isd);
                           vlrcsi.formObcsmTdp(l_isd);
                           DLOG(0,0,"Returned to ISDData from O_BCSM_TDP Criteria List");
                           if ((len = CheckLengthV3(l_isd)) >=IsdLen)
                           {
                              TLOG(0,0,"Sending ISD till camel phase 1 data, ISD length %d",pLen);
                              index = OMAP3_vlrCamelSubscriptionInfo_present;
                              VcsiIndex = OMAP3_VlrCamelSubscriptionInfo_o_BcsmCamelTDP_CriteriaList_present;
                              l_isd->vlrCamelSubscriptionInfo.bit_mask &= (~OMAP3_VlrCamelSubscriptionInfo_o_BcsmCamelTDP_CriteriaList_present);
                              flag = true;
                              return true;
                              break;
                           }
                           DLOG(0,0,"The Encoding length till OBCSM TDP Criteria info is %d VLR CAMEL SUBSCRIPTION INFO added %d",len,(len-pLen));
                           m_MM_TDR_CSI_FLAGS |= MM_TDR_O_CSI_PRESENT;
                           pLen = len;
                           flag = false;
                        }
                        index = OMAP3_vlrCamelSubscriptionInfo_present;
                        VcsiIndex = OMAP3_VlrCamelSubscriptionInfo_m_CSI_present;
                     }
                     //break;

                  case OMAP3_VlrCamelSubscriptionInfo_m_CSI_present://400
                     {
#if 0//Not Supported
                        //vlrcsi.formMcsi(l_UserDlgId,l_isd);
                        vlrcsi.formMcsi(l_isd);
                        DLOG(0,0,"Returned to ISDData from MCSI");
                        //if ((len = CheckLengthV3(l_isd)) >=IsdLen)
                        {
                           DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                           index = OMAP3_vlrCamelSubscriptionInfo_present;
                           VcsiIndex = OMAP3_VlrCamelSubscriptionInfo_m_CSI_present;
                           l_isd->vlrCamelSubscriptionInfo.bit_mask &= (~OMAP3_VlrCamelSubscriptionInfo_m_CSI_present);
                           //l_isd->bit_mask &= (~OMAP3_vlrCamelSubscriptionInfo_present);
                           flag = true;
                           return true;
                           break;
                        }
                        DLOG(0,0,"The Encoding length till MCSI is %d VLR CAMEL SUBSCRIPTION INFO added %d",len,(len-pLen));
                        pLen = len;
                        flag = false;
                        m_MM_TDR_CSI_FLAGS |= MM_TDR_M_CSI_PRESENT;
#endif
                        index = OMAP3_vlrCamelSubscriptionInfo_present;
                        VcsiIndex = OMAP3_VlrCamelSubscriptionInfo_mo_sms_CSI_present;
                     }
                     //break;
                  case OMAP3_VlrCamelSubscriptionInfo_mo_sms_CSI_present://200
                     {
                        DLOG(0,0,"Camel phase supported %d, MO_SMS_CSI profile id %d",dbisd3.CamelPhase,vlrcsi.vcsi.mosmscsi);
                        if((dbisd3.CamelPhase >= 3) &&(vlrcsi.vcsi.mosmscsi))
                        {
                           //vlrcsi.formMosCsi(l_UserDlgId,l_isd);
                           vlrcsi.formMosCsi(l_isd);
                           DLOG(0,0,"Returned to ISDData from MO SMS CSI");
                           if ((len = CheckLengthV3(l_isd)) >=IsdLen)
                           {
                              DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                              index = OMAP3_vlrCamelSubscriptionInfo_present;
                              VcsiIndex = OMAP3_VlrCamelSubscriptionInfo_mo_sms_CSI_present;
                              l_isd->vlrCamelSubscriptionInfo.bit_mask &= (~OMAP3_VlrCamelSubscriptionInfo_mo_sms_CSI_present);
                              //l_isd->bit_mask &= (~OMAP3_vlrCamelSubscriptionInfo_present);
                              flag = true;
                              return true;
                              break;
                           }
                           DLOG(0,0,"The Encoding length till MOSMSCSI is %d VLR CAMEL SUBSCRIPTION INFO added %d",len,(len-pLen));
                           m_MM_TDR_CSI_FLAGS |= MM_TDR_MO_SMS_CSI_PRESENT;
                           pLen = len;
                           flag = false;
                        }
                        index = OMAP3_vlrCamelSubscriptionInfo_present;
                        VcsiIndex = OMAP3_VlrCamelSubscriptionInfo_vt_CSI_present;
                     }
                     //break;
                  case OMAP3_VlrCamelSubscriptionInfo_vt_CSI_present://100
                     {
#if 1 //Added in 1.0.1.0
                        DLOG(0,0,"dbisd3.CamelPhase [%d] vlrcsi.vcsi.vtcsi [%d]",dbisd3.CamelPhase,vlrcsi.vcsi.vtcsi);
                        if((dbisd3.CamelPhase >= 3) && (vlrcsi.vcsi.vtcsi != 0))
                        {
                           vlrcsi.formVTCsi(l_isd);
                           //DLOG(0,0,"Returned to ISDData from VTCSI");
                           if ((len = CheckLengthV3(l_isd)) >=IsdLen)
                           {
                              DLOG(0,0,"Current length is %d sending till previous length %d, Added VTCSI, Length exeeded",len,pLen);
                              index = OMAP3_vlrCamelSubscriptionInfo_present;
                              VcsiIndex = OMAP3_VlrCamelSubscriptionInfo_vt_CSI_present;
                              l_isd->vlrCamelSubscriptionInfo.bit_mask &= (~OMAP3_VlrCamelSubscriptionInfo_vt_CSI_present);
                              //l_isd->bit_mask &= (~OMAP3_vlrCamelSubscriptionInfo_present);
                              flag = true;
                              return true;
                              break;
                           }
                           DLOG(0,0,"The Encoding length till VTCSI info is %d VLR CAMEL SUBSCRIPTION INFO added %d",len,(len-pLen));
                           m_MM_TDR_CSI_FLAGS |= MM_TDR_VT_CSI_PRESENT;
                           pLen = len;
                           flag = false;
                        }
#endif
                        index = OMAP3_vlrCamelSubscriptionInfo_present;
                        VcsiIndex = OMAP3_VlrCamelSubscriptionInfo_t_BCSM_CAMEL_TDP_CriteriaList_present;
                     }
                     //break;
                  case OMAP3_VlrCamelSubscriptionInfo_t_BCSM_CAMEL_TDP_CriteriaList_present://80
                     {
#if 1//Added in 1.0.1.0 
                        if((dbisd3.CamelPhase >= 3) && (vlrcsi.vcsi.vtcsi))
                        {
                           vlrcsi.formVTbcsmTdp(l_isd);
                           len = CheckLengthV3(l_isd);
                           DLOG(0,0,"Returned to ISDData from TBCSM Criteria len [%d] ", len);
                           if (len >=IsdLen)
                           {
                              DLOG(0,0,"Current length is %d sending till previous length %d, nAdded VT_BCSM Criteria, Length exeeded",len,pLen);
                              index = OMAP3_vlrCamelSubscriptionInfo_present;
                              VcsiIndex = OMAP3_VlrCamelSubscriptionInfo_t_BCSM_CAMEL_TDP_CriteriaList_present;
                              l_isd->vlrCamelSubscriptionInfo.bit_mask &= (~OMAP3_VlrCamelSubscriptionInfo_t_BCSM_CAMEL_TDP_CriteriaList_present);
                              //l_isd->bit_mask &= (~OMAP3_vlrCamelSubscriptionInfo_present);
                              flag = true;
                              return true;
                              break;
                           }
                           DLOG(0,0,"The Encoding length till VTCSI BCSM info is %d VLR CAMEL SUBSCRIPTION INFO added %d",len,(len-pLen));
                           pLen = len;
                           flag = false;
                        }
#endif
                        index = OMAP3_vlrCamelSubscriptionInfo_present;
                        VcsiIndex = OMAP3_VlrCamelSubscriptionInfo_d_CSI_present;
                     }
                     //break;
                  case OMAP3_VlrCamelSubscriptionInfo_d_CSI_present://40
                     {
                        DLOG(0,0,"Camel phase supported %d, D_CSI profile id %d",dbisd3.CamelPhase,vlrcsi.vcsi.dcsi);
                        if((dbisd3.CamelPhase >= 3) && (vlrcsi.vcsi.dcsi))
                        {
                           //vlrcsi.formDCsi(l_UserDlgId,l_isd);
                           vlrcsi.formDCsi(l_isd);
                           DLOG(0,0,"Returned to ISDData from DCSI");
                           if ((len = CheckLengthV3(l_isd)) >=IsdLen)
                           {
                              DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                              index = OMAP3_vlrCamelSubscriptionInfo_present;
                              VcsiIndex = OMAP3_VlrCamelSubscriptionInfo_d_CSI_present;
                              l_isd->vlrCamelSubscriptionInfo.bit_mask &= (~OMAP3_VlrCamelSubscriptionInfo_d_CSI_present);
                              //l_isd->bit_mask &= (~OMAP3_vlrCamelSubscriptionInfo_present);
                              flag = true;
                              return true;
                              break;
                           }
                           DLOG(0,0,"The Encoding length till DCSI info is %d VLR CAMEL SUBSCRIPTION INFO added %d",len,(len-pLen));
                           pLen = len;
                           flag = false;
                           m_MM_TDR_CSI_FLAGS |= MM_TDR_D_CSI_PRESENT;
                        }
                        index = OMAP3_vlrCamelSubscriptionInfo_present;
                        VcsiIndex = OMAP3_VlrCamelSubscriptionInfo_mt_sms_CSI_present;
                     }
                     //break;
                  case OMAP3_VlrCamelSubscriptionInfo_mt_sms_CSI_present://20
                     {
#if 1 // Not required as of now
                        if((dbisd3.CamelPhase == 4) && (vlrcsi.vcsi.mtsmscsi != 0))
                        {
                           //vlrcsi.formMtsCsi(l_UserDlgId,l_isd);
                           vlrcsi.formMtsCsi(l_isd);
                           DLOG(0,0,"Returned to ISDData from MT SMS CSI");
                           if ((len = CheckLengthV3(l_isd)) >=IsdLen)
                           {
                              DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                              index = OMAP3_vlrCamelSubscriptionInfo_present;
                              VcsiIndex = OMAP3_VlrCamelSubscriptionInfo_mt_sms_CSI_present;
                              l_isd->vlrCamelSubscriptionInfo.bit_mask &= (~OMAP3_VlrCamelSubscriptionInfo_mt_sms_CSI_present);
                              //l_isd->bit_mask &= (~OMAP3_vlrCamelSubscriptionInfo_present);
                              flag = true;
                              return true;
                              break;
                           }
                           DLOG(0,0,"The Encoding length till MTSMSCSI is %d VLR CAMEL SUBSCRIPTION INFO added %d",len,(len-pLen));
                           pLen = len;
                           flag = false;
                           m_MM_TDR_CSI_FLAGS |= MM_TDR_MT_SMS_CSI_PRESENT;
                        }
#endif                        
                        index = OMAP3_VlrCamelSubscriptionInfo_mt_smsCAMELTDP_CriteriaList_present;
                        VcsiIndex = OMAP3_VlrCamelSubscriptionInfo_mt_smsCAMELTDP_CriteriaList_present;
                     }
                     //break;
                  case OMAP3_VlrCamelSubscriptionInfo_mt_smsCAMELTDP_CriteriaList_present://10
                     {
#if 1                     
                        if((dbisd3.CamelPhase == 4) && (vlrcsi.vcsi.mtsmscsi != 0))
                        {
                           //vlrcsi.formMtsTdp(l_UserDlgId,l_isd);
                           vlrcsi.formMtsTdp(l_isd);
                           DLOG(0,0,"Returned to ISDData from MTSMS TDP criteria list");
                           if ((len = CheckLengthV3(l_isd)) >=IsdLen)
                           {
                              DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                              index = OMAP3_vlrCamelSubscriptionInfo_present;
                              VcsiIndex = OMAP3_VlrCamelSubscriptionInfo_mt_smsCAMELTDP_CriteriaList_present;
                              l_isd->vlrCamelSubscriptionInfo.bit_mask &= (~OMAP3_VlrCamelSubscriptionInfo_mt_smsCAMELTDP_CriteriaList_present);
                              //l_isd->bit_mask &= (~OMAP3_vlrCamelSubscriptionInfo_present);
                              flag = true;
                              return true;
                              break;
                           }
                           DLOG(0,0,"The Encoding length till MOSMSCSI is %d VLR CAMEL SUBSCRIPTION INFO added %d",len,(len-pLen));
                           //pLen = len;
                           flag = false;
                        }
#endif                        
                        index = OMAP3_InsertSubscriberDataArg_extensionContainer_present;
                        VcsiIndex = 0;
                     }
                     //break;                 

                  default:
                     {
                        DLOG(0,0,"Inside default");                     
                     }  

               }//Switch case               
            }//dbisd3.VLRCSI
            if(flag)
               break;
            else
            {
               //DLOG(0,0,"Len after adding VLR CSI is %d\n",len);
               DLOG(0,0,"Len after adding VLR CSI is %d",len);
            }
            if((len - LenBeforeCSI) < 5)
               l_isd->bit_mask &= (~OMAP3_vlrCamelSubscriptionInfo_present);
            pLen = len;
            DLOG(0,0,"After VLR Camel subscription info,continuing with remaing ISD");
            //DLOG(0,0,"\nEnd of VLRCSI ==> Index value here %x VcsiIndex value here %x\n",index,VcsiIndex);
            index = OMAP3_InsertSubscriberDataArg_extensionContainer_present;
            VcsiIndex = 0;
         }
         //break;

      case OMAP3_InsertSubscriberDataArg_extensionContainer_present: //00040000
         {
            //DLOG(0,0,"\nExtn cont ==> Index value here %x VcsiIndex value here %x\n",index,VcsiIndex);
#if 0 //Not needed
            if(0)
            {
               l_isd->bit_mask |= OMAP3_InsertSubscriberDataArg_extensionContainer_present;
               //if ((len = CheckLengthV3(l_isd)) >=IsdLen)
               {
                  DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                  index = OMAP3_InsertSubscriberDataArg_extensionContainer_present;
                  l_isd->bit_mask &= (~OMAP3_InsertSubscriberDataArg_extensionContainer_present);
                  SendIsdV3(l_UserDlgId,l_request,l_isd,index,MsgOpCode);
                  break;
               }
               DLOG(0,0,"The Encoding length till here is %d EXTENSION CONTAINER added %d",len,(len-pLen));
               pLen = len;
            }
#endif
            index = OMAP3_InsertSubscriberDataArg_naea_PreferredCI_present;
         }
         //break;

      case OMAP3_InsertSubscriberDataArg_naea_PreferredCI_present: //00020000
         {
#if 0 //Not supported
            if(0)//dbisd3.naea)
            {
               l_isd->bit_mask |= OMAP3_InsertSubscriberDataArg_naea_PreferredCI_present;
               l_isd->naea_PreferredCI.naea_PreferredCIC.length = 1;
               l_isd->naea_PreferredCI.naea_PreferredCIC.value[0] = 0x41;
               //if ((len = CheckLengthV3(l_isd)) >=IsdLen)
               {
                  DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                  index = OMAP3_InsertSubscriberDataArg_naea_PreferredCI_present;
                  l_isd->bit_mask &= (~OMAP3_InsertSubscriberDataArg_extensionContainer_present);
                  SendIsdV3(l_UserDlgId,l_request,l_isd,index,MsgOpCode);
                  break;
               }
               DLOG(0,0,"The Encoding length till here is %d NAEA PREFERRED CI added %d",len,(len-pLen));
               pLen = len;
            }
#endif
            index = OMAP3_gprsSubscriptionData_present;
         }
         //break;

      case OMAP3_gprsSubscriptionData_present: //00010000
         {
            DLOG(0,0,"Value of gprs Subs Data id is %d",dbisd3.gprsSubsData);
            if(dbisd3.gprsSubsData)
            {
               len = CheckLengthV3(l_isd);
               int ChkRet = gprssi.formgprssi(l_UserDlgId,l_isd,len);
               TLOG(0,0,"Returned back from GPRS Subscription data,val %d",ChkRet);
               if ( ChkRet == 1)
               {
                  //DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                  TLOG(0,0,"No GPRS subscription data added  in this chunk");
                  index = OMAP3_gprsSubscriptionData_present;
                  l_isd->bit_mask &= (~OMAP3_gprsSubscriptionData_present);
                  gprssi.m_FormedTill = 0;
                  return true;
                  break;
               }
               else if(ChkRet == 2)
               {
                  TLOG(0,0,"GPRS subscription data added till count %d",gprssi.m_FormedTill);
                  index = OMAP3_gprsSubscriptionData_present;
                  return true;
                  break;
               }
               else
               {
                  TLOG(0,0,"All GprsSubscriptionData added");
               }
               DLOG(0,0,"The Encoding length till here is %d GPRS SUBSCRIPTION DATA added %d",len,(len-pLen));
               pLen = len;
            }
            index = OMAP3_roamingRestrictedInSgsnDueToUnsupportedFeature_present;
         }
         //break;

      case OMAP3_roamingRestrictedInSgsnDueToUnsupportedFeature_present: //00008000
         {
#if 0//Not planned when to send it
            if(dbisd3.rrs_duf)
            {
               l_isd->bit_mask |= OMAP3_roamingRestrictedInSgsnDueToUnsupportedFeature_present;//Nulltype for GPRS
               //l_isd->roamingRestrictedInSgsnDueToUnsupportedFeature;
               if ((len = CheckLengthV3(l_isd)) >=IsdLen)
               {
                  DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                  index = OMAP3_roamingRestrictedInSgsnDueToUnsupportedFeature_present;
                  l_isd->bit_mask &= (~OMAP3_roamingRestrictedInSgsnDueToUnsupportedFeature_present);
                  SendIsdV3(l_UserDlgId,l_request,l_isd,index,MsgOpCode);
                  break;
               }
               DLOG(0,0,"The Encoding length till here is %d RRSDUF added %d",len,(len-pLen));
               pLen = len;
            }
#endif
            index = OMAP3_networkAccessMode_present;
         }
         //break;

      case OMAP3_networkAccessMode_present: //00004000
         {
#if 0 //sent with category only
            if(0)//dbisd3.nwAccMode)
            {
               l_isd->bit_mask |= OMAP3_networkAccessMode_present;
               //db_Data->HLR_SUBS_GEN_PROFILE.NETWORK_ACCESS_MODE
               l_isd->networkAccessMode = (OMAP3_NetworkAccessMode)dbisd3.nwAccMode;
               // if ((len = CheckLengthV3(l_isd)) >=IsdLen)
               {
                  DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                  index = OMAP3_networkAccessMode_present;
                  l_isd->bit_mask &= (~OMAP3_networkAccessMode_present);
                  return true;
                  break;
               }
               DLOG(0,0,"The Encoding length till here is %d NETWORK ACCESS MODE added %d",len,(len-pLen));
               pLen = len;
            }
#endif
            index = OMAP3_lsaInformation_present;
         }
         //break;

      case OMAP3_lsaInformation_present: //00002000
         {
#if 0 //Not Supported
            if(0)//dbisd3.lsaInfo)
            {
               l_isd->bit_mask |= OMAP3_lsaInformation_present;
               l_isd->lsaInformation.bit_mask = OMAP3_LSAInformation_completeDataListIncluded_present;
               //l_isd->lsaInformation.bit_mask =
               if ((len = CheckLengthV3(l_isd)) >=IsdLen)
               {
                  DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                  index = OMAP3_lsaInformation_present;
                  l_isd->bit_mask &= (~OMAP3_lsaInformation_present);
                  SendIsdV3(l_UserDlgId,l_request,l_isd,index,MsgOpCode);
                  break;
               }
               DLOG(0,0,"The Encoding length till here is %d LSA INFORMATION added %d",len,(len-pLen));
               pLen = len;
            }
#endif
            index = OMAP3_lmu_Indicator_present;
         }
         //break;

      case OMAP3_lmu_Indicator_present: //00001000
         {
            if(dbisd3.lmu)
            {
               l_isd->bit_mask |= OMAP3_lmu_Indicator_present;//Nulltype
               len = CheckLengthV3(l_isd);
               if (len  >=IsdLen)
               {
                  DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                  index = OMAP3_lmu_Indicator_present;
                  l_isd->bit_mask &= (~OMAP3_lmu_Indicator_present);
                  return true;
                  break;
               }
               DLOG(0,0,"The Encoding length till here is %d LMU INDICATOR added %d",len,(len-pLen));
               pLen = len;
            }
            index = OMAP3_lcsInformation_present;
         }
         //break;

      case OMAP3_lcsInformation_present: //00000800
         {
#if 0 //Added in 1.0.3.0 Donno how it will work
            if((g_MmConfigReaderObj->m_SendLCS_Details == true) && (dbisd3.LcsIndicatorPresent == true))
            {
               DLOG(0,0,"Adding LcsInformation");
               l_isd->bit_mask |= OMAP3_lcsInformation_present;
               l_isd->lcsInformation.bit_mask = OMAP3_lcs_PrivacyExceptionList_present; 
               l_isd->lcsInformation.lcs_PrivacyExceptionList.count = 1;
               l_isd->lcsInformation.lcs_PrivacyExceptionList.value[0].ss_Code = OMAP3_universal;
               l_isd->lcsInformation.lcs_PrivacyExceptionList.value[0].ss_Status.length = 1;
               l_isd->lcsInformation.lcs_PrivacyExceptionList.value[0].ss_Status.value[0] = 7;
               LLOG(0,0,"Added LCS Privacy Exception List SS_CODE [%d] Status [%d]",
                     l_isd->lcsInformation.lcs_PrivacyExceptionList.value[0].ss_Code,
                     l_isd->lcsInformation.lcs_PrivacyExceptionList.value[0].ss_Status);
               if ((len = CheckLengthV3(l_isd)) >=IsdLen)
               {
                  TLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                  index = OMAP3_lcsInformation_present;
                  l_isd->bit_mask &= (~OMAP3_lcsInformation_present);
                  return true;
                  break;
               }
               DLOG(0,0,"The Encoding length till here is %d LCS INFORMATION added %d",len,(len-pLen));
               pLen = len;
            }
#endif
            index = OMAP3_InsertSubscriberDataArg_istAlertTimer_present;
         }
         //break;

      case OMAP3_InsertSubscriberDataArg_istAlertTimer_present: //00000400
         {
            if(dbisd3.istvalue)
            {
               DLOG(0,0,"IST Alert timer value is %d",dbisd3.istvalue);
               l_isd->bit_mask |= OMAP3_InsertSubscriberDataArg_istAlertTimer_present;
               l_isd->istAlertTimer = dbisd3.istvalue;
               if ((len = CheckLengthV3(l_isd)) >=IsdLen)
               {
                  DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                  index = OMAP3_InsertSubscriberDataArg_istAlertTimer_present;
                  l_isd->bit_mask &= (~OMAP3_InsertSubscriberDataArg_istAlertTimer_present);
                  return true;
                  break;
               }
               DLOG(0,0,"The Encoding length till here is %d IST ALERT TIMER added %d",len,(len-pLen));
               pLen = len;
            }
            index = OMAP3_superChargerSupportedInHLR_present;
         }
         //break;

      case OMAP3_superChargerSupportedInHLR_present: //00000200
         {
#if 0 //Not supported
            if(0)
            {
               l_isd->bit_mask |= OMAP3_superChargerSupportedInHLR_present;
               l_isd->superChargerSupportedInHLR.length = 1;
               l_isd->superChargerSupportedInHLR.value[0] = 0x44;
               if ((len = CheckLengthV3(l_isd)) >=IsdLen)
               {
                  DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                  index = OMAP3_superChargerSupportedInHLR_present;
                  l_isd->bit_mask &= (~OMAP3_superChargerSupportedInHLR_present);
                  SendIsdV3(l_UserDlgId,l_request,l_isd,index,MsgOpCode);
                  break;
               }
               DLOG(0,0,"The Encoding length till here is %d SUPER CHARGE SUPPORT IN HLR added %d",len,(len-pLen));
               pLen = len;
            }
#endif
            index = OMAP3_mc_SS_Info_present;
            //index = OMAP3_cs_AllocationRetentionPriority_present;
         }
         //break;

#if 1
      case OMAP3_mc_SS_Info_present: //00000100
         {
            DLOG(0,0,"Before MC_SS_info, MC_SS %d",pss.mcSsCode);
            if(pss.mcSsCode)
            {
               DLOG(0,0,"Forming MC SS info");
               //pss.formMcSS(l_UserDlgId,l_isd);
               pss.formMcSS(l_isd);
               if ((len = CheckLengthV3(l_isd)) >=IsdLen)
               {
                  DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                  index = OMAP3_mc_SS_Info_present;
                  l_isd->bit_mask &= (~OMAP3_mc_SS_Info_present);
                  return true;
                  break;
               }
               DLOG(0,0,"The Encoding length till here is %d SS INFO PRESENT added %d",len,(len-pLen));
               pLen = len;
            }
            index = OMAP3_cs_AllocationRetentionPriority_present;
         }
         //break;
#endif         

      case OMAP3_cs_AllocationRetentionPriority_present: //00000080
         {
#if 0 //Not supported
            if(0)
            {
               l_isd->bit_mask |= OMAP3_cs_AllocationRetentionPriority_present;
               l_isd->cs_AllocationRetentionPriority.length = 1;
               l_isd->cs_AllocationRetentionPriority.value[0] = 0x02;
               //if ((len = CheckLengthV3(l_isd)) >=IsdLen)
               {
                  DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                  index = OMAP3_cs_AllocationRetentionPriority_present;
                  l_isd->bit_mask &= (~OMAP3_cs_AllocationRetentionPriority_present);
                  SendIsdV3(l_UserDlgId,l_request,l_isd,index,MsgOpCode);
                  break;
               }
               DLOG(0,0,"The Encoding length till here is %d ALLOCATION RETENTION PRIOROTY added %d",len,(len-pLen));
               pLen = len;
            }
#endif
            index = OMAP3_sgsn_CAMEL_SubscriptionInfo_present;
         }
         //break;

      case OMAP3_sgsn_CAMEL_SubscriptionInfo_present: //00000040
         {
            int LenBeforeSCSI = 0;  flag = false;
            bool l_GprsCsiAdded = false;
            if(dbisd3.sgsncsi)
            {
               LenBeforeSCSI = CheckLengthV3(l_isd);
               DLOG(0,0,"Length before SGSN CSI info is %d",LenBeforeSCSI);
               l_isd->bit_mask |= OMAP3_sgsn_CAMEL_SubscriptionInfo_present;
               l_isd->sgsn_CAMEL_SubscriptionInfo.bit_mask = 0;
               DLOG(0,0,"Forming SGSN Camel Subscription information for Dialog ID %d,Index value here is %x, Sgsn_CsiIndex value is %x",l_UserDlgId,index,ScsiIndex);
               switch(ScsiIndex)
               {
                  case OMAP3_SGSN_CAMEL_SubscriptionInfo_gprs_CSI_present://0x80
                     {
                        if((dbisd3.CamelPhase >= 3) && (Sgsncsi.scsi.gcsi))
                        {
                           //Sgsncsi.formGprsCsi(l_UserDlgId,l_isd);
                           Sgsncsi.formGprsCsi(l_isd);
                           DLOG(0,0,"After SGSN CSI and returned to ISDData");
                           if ((len = CheckLengthV3(l_isd)) >=IsdLen)
                           {
                              DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                              index = OMAP3_sgsn_CAMEL_SubscriptionInfo_present;
                              ScsiIndex = OMAP3_SGSN_CAMEL_SubscriptionInfo_gprs_CSI_present;
                              l_isd->bit_mask &= (~OMAP3_sgsn_CAMEL_SubscriptionInfo_present);
                              flag = true;
                              return true;
                              break;
                           }
                           DLOG(0,0,"The Encoding length till here is %d SGSN CAMEL SUBSCRIPTION INFO added %d",len,(len-pLen));
                           if(Sgsncsi.scsi.gcsi)
                              l_GprsCsiAdded = true;
                           m_MM_TDR_CSI_FLAGS |= MM_TDR_GPRS_CSI_PRESENT;
                           pLen = len;
                        }
                        index = OMAP3_sgsn_CAMEL_SubscriptionInfo_present;
                        ScsiIndex = OMAP3_SGSN_CAMEL_SubscriptionInfo_mo_sms_CSI_present;
                     }
                     //break;
                  case OMAP3_SGSN_CAMEL_SubscriptionInfo_mo_sms_CSI_present://0x40
                     {
                        if((dbisd3.CamelPhase >= 3) && (Sgsncsi.scsi.mosmscsi != 0))
                        {
                           //Sgsncsi.formMosmsCsi(l_UserDlgId,l_isd);
                           Sgsncsi.formMosmsCsi(l_isd);
                           DLOG(0,0,"After MOSMSCSI and returned to ISDData");
                           if ((len = CheckLengthV3(l_isd)) >=IsdLen)
                           {
                              DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                              index = OMAP3_sgsn_CAMEL_SubscriptionInfo_present;
                              l_isd->sgsn_CAMEL_SubscriptionInfo.bit_mask &= (~OMAP3_SGSN_CAMEL_SubscriptionInfo_mo_sms_CSI_present);
                              ScsiIndex = OMAP3_SGSN_CAMEL_SubscriptionInfo_mo_sms_CSI_present;
                              if(l_GprsCsiAdded == false)
                                 l_isd->bit_mask &= (~OMAP3_sgsn_CAMEL_SubscriptionInfo_present);
                              flag = true;
                              return true;
                              break;
                           }
                           DLOG(0,0,"The Encoding length till here is %d SGSN CAMEL SUBSCRIPTION INFO added %d",len,(len-pLen));
                           m_MM_TDR_CSI_FLAGS |= MM_TDR_MO_SMS_CSI_PRESENT;
                           pLen = len;
                        }
                        index = OMAP3_sgsn_CAMEL_SubscriptionInfo_present;
                        ScsiIndex = OMAP3_SGSN_CAMEL_SubscriptionInfo_extensionContainer_present;
                     }
                     //break;
                  case OMAP3_SGSN_CAMEL_SubscriptionInfo_extensionContainer_present://0x20
                     {
                        index = OMAP3_sgsn_CAMEL_SubscriptionInfo_present;
                        ScsiIndex = OMAP3_SGSN_CAMEL_SubscriptionInfo_mt_sms_CSI_present;
                     }
                     //break;
                  case OMAP3_SGSN_CAMEL_SubscriptionInfo_mt_sms_CSI_present://0x10
                     {
                        if((dbisd3.CamelPhase == 4) && (Sgsncsi.scsi.mtsmscsi != 0))
                        {
                           //Sgsncsi.formMtsmsCsi(l_UserDlgId,l_isd);
                           Sgsncsi.formMtsmsCsi(l_isd);
                           DLOG(0,0,"After SGSN CSI and returned to ISDData");
                           if ((len = CheckLengthV3(l_isd)) >=IsdLen)
                           {
                              DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                              index = OMAP3_sgsn_CAMEL_SubscriptionInfo_present;
                              ScsiIndex = OMAP3_SGSN_CAMEL_SubscriptionInfo_mt_sms_CSI_present;
                              //l_isd->bit_mask &= (~OMAP3_sgsn_CAMEL_SubscriptionInfo_present);
                              l_isd->sgsn_CAMEL_SubscriptionInfo.bit_mask &= (~OMAP3_SGSN_CAMEL_SubscriptionInfo_mt_sms_CSI_present);
                              flag = true;
                              return true;
                              break;
                           }
                           DLOG(0,0,"The Encoding length till here is %d SGSN CAMEL SUBSCRIPTION INFO added %d",len,(len-pLen));
                           m_MM_TDR_CSI_FLAGS |= MM_TDR_MT_SMS_CSI_PRESENT;
                           pLen = len;
                        }
                        index = OMAP3_sgsn_CAMEL_SubscriptionInfo_present;
                        ScsiIndex = OMAP3_SGSN_CAMEL_SubscriptionInfo_mt_smsCAMELTDP_CriteriaList_present;
                     }
                     //break;
                  case OMAP3_SGSN_CAMEL_SubscriptionInfo_mt_smsCAMELTDP_CriteriaList_present://0x08
                     {
                        if((dbisd3.CamelPhase == 4) && (Sgsncsi.scsi.mtsmscsi != 0))
                        {
                           //Sgsncsi.formMtcritList(l_UserDlgId,l_isd);
                           Sgsncsi.formMtcritList(l_isd);
                           DLOG(0,0,"After MTSMS CRIT SGSN CSI and returned to ISDData");
                           if ((len = CheckLengthV3(l_isd)) >=IsdLen)
                           {
                              DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                              index = OMAP3_sgsn_CAMEL_SubscriptionInfo_present;
                              ScsiIndex = OMAP3_SGSN_CAMEL_SubscriptionInfo_mt_smsCAMELTDP_CriteriaList_present;
                              //l_isd->bit_mask &= (~OMAP3_sgsn_CAMEL_SubscriptionInfo_present);
                              l_isd->sgsn_CAMEL_SubscriptionInfo.bit_mask &= (~OMAP3_SGSN_CAMEL_SubscriptionInfo_mt_smsCAMELTDP_CriteriaList_present);
                              flag = true;
                              return true;
                              break;
                           }
                           DLOG(0,0,"The Encoding length till here is %d SGSN CAMEL SUBSCRIPTION INFO added %d",len,(len-pLen));
                           pLen = len;
                           m_MM_TDR_CSI_FLAGS |= MM_TDR_MT_SMS_CSI_PRESENT;
                        }
                        index = OMAP3_sgsn_CAMEL_SubscriptionInfo_present;
                        ScsiIndex = OMAP3_SGSN_CAMEL_SubscriptionInfo_mg_csi_present;
                     }
                     //break;
                  case OMAP3_SGSN_CAMEL_SubscriptionInfo_mg_csi_present://0x04
                     {
                        DLOG(0,0,"Finished adding SGSN CSI and returned to ISDData");
                        index = OMAP3_InsertSubscriberDataArg_chargingCharacteristics_present;
                        ScsiIndex = 0;
                     }
                  default:
                     {
                     }
               }              
            }
            if(flag)
               break;
            else
               if((len - LenBeforeSCSI) < 5)
                  l_isd->bit_mask &= (~OMAP3_sgsn_CAMEL_SubscriptionInfo_present);
            DLOG(0,0,"After SGSN Camel subscription info,continuing with remaing ISD");
            index = OMAP3_InsertSubscriberDataArg_chargingCharacteristics_present;
            ScsiIndex = 0;
         }
         //break;

      case OMAP3_InsertSubscriberDataArg_chargingCharacteristics_present: //00000020
         {
#if 1
            if((dbisd3.ChrgChar[0] != 0x00) || (dbisd3.ChrgChar[1] != 0x00))
            {
               l_isd->bit_mask |= OMAP3_InsertSubscriberDataArg_chargingCharacteristics_present;
               l_isd->chargingCharacteristics.length = 2;
               l_isd->chargingCharacteristics.value[0] = dbisd3.ChrgChar[0];
               l_isd->chargingCharacteristics.value[1] = dbisd3.ChrgChar[1];
               if ((len = CheckLengthV3(l_isd)) >=IsdLen)
               {
                  DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                  index = OMAP3_InsertSubscriberDataArg_chargingCharacteristics_present;
                  l_isd->bit_mask &= (~OMAP3_InsertSubscriberDataArg_chargingCharacteristics_present);
                  return true;
                  break;
               }
               DLOG(0,0,"The Encoding length till here is %d CHARGING CHARECTERISTICS added %d",len,(len-pLen));
               pLen = len;
            }
#endif
            index = OMAP3_accessRestrictionData_present;
         }
         //break;

      case OMAP3_accessRestrictionData_present: //00000010
         {
            if(dbisd3.accrest)
            {
               DLOG(0,0,"Adding Access restriction %d",dbisd3.accrest);
               l_isd->bit_mask |= OMAP3_accessRestrictionData_present;               
               l_isd->accessRestrictionData.value[0] = dbisd3.accrest;
               l_isd->accessRestrictionData.length = 2;//getNumberOfSignificantBitsForAByte(l_isd->accessRestrictionData.value[0]); 
               if ((len = CheckLengthV3(l_isd)) >=IsdLen)
               {
                  DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                  index = OMAP3_accessRestrictionData_present;
                  l_isd->bit_mask &= (~OMAP3_accessRestrictionData_present);
                  return true;
                  break;
               }
               DLOG(0,0,"The Encoding length till here is %d ACCESS RESTRICTION DATA added %d",len,(len-pLen));
               pLen = len;
            }
            index = OMAP3_ics_Indicator_present;
         }
         //break;

      case OMAP3_ics_Indicator_present: //00000008
         {
#if 0 //not supported
            if(0)
            {
               l_isd->bit_mask |= OMAP3_ics_Indicator_present;
               l_isd->ics_Indicator = true;
               if ((len = CheckLengthV3(l_isd)) >=IsdLen)
               {
                  DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                  index = OMAP3_ics_Indicator_present;
                  l_isd->bit_mask &= (~OMAP3_ics_Indicator_present);
                  SendIsdV3(l_UserDlgId,l_request,l_isd,index,MsgOpCode);
                  break;
               }
               DLOG(0,0,"The Encoding length till here is %d ICS INDICATOR added %d",len,(len-pLen));
               pLen = len;
            }
#endif
            index = OMAP3_eps_SubscriptionData_present;
         }
         //break;

      case OMAP3_eps_SubscriptionData_present: //00000004
         {
#if 0//not supported
            if(0)
            {
               l_isd->bit_mask |= OMAP3_eps_SubscriptionData_present;
               //l_isd->eps_SubscriptionData;
               if ((len = CheckLengthV3(l_isd)) >=IsdLen)
               {
                  DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                  index = OMAP3_eps_SubscriptionData_present;
                  l_isd->bit_mask &= (~OMAP3_eps_SubscriptionData_present);
                  SendIsdV3(l_UserDlgId,l_request,l_isd,index,MsgOpCode);
                  break;
               }
               DLOG(0,0,"The Encoding length till here is %d EPS SUBSCRIPTION DATA added %d",len,(len-pLen));
               pLen = len;
            }
#endif
            index = OMAP3_csg_SubscriptionDataList_present;
         }
         //break;

      case OMAP3_csg_SubscriptionDataList_present: //00000002
         {
            index = OMAP3_ue_ReachabilityRequestIndicator_present;
         }
         //break;

      case OMAP3_ue_ReachabilityRequestIndicator_present: //00000001
         {
            //Used only for IWF
            index = 00000000;
            TLOG(0,0,"All data for ISD added,sending the ISD");
            m_AllDataAdded = true;
            return true;
            break;
         }
         //break;
      default:
         {
         }
         //break;
   }
   //DLOG(0,0,"All data for ISD added,sending the ISD");
   //SendIsdV3(l_UserDlgId,l_request,l_isd,index,VcsiIndex,ScsiIndex,SsIndex,MsgOpCode);
   return true;
}

bool ISDData::FormISDReqV2(int l_UserDlgId,unsigned int &index,unsigned int &SsIndex,bool flag,struct dbisd2,int &opCode,OMAP2_InsertSubscriberDataArg *l_isd)
{
   MsgOpCode = opCode;
   DLOG(0,0,"Inside ISDReq for User DlgId %d with index value %x for Msg opcode %d", l_UserDlgId,index,MsgOpCode);   
   IsdLen = g_MmConfigReaderObj->m_IsdLen;
   DLOG(0,0,"ISD data length configured is %d bytes",IsdLen);
   l_isd->bit_mask = 0;
   //DLOG(0,0,"Going to switch on index");
   //int pLen,len;
   pLen = 0;
   len = 0;
   switch(index)
   {
      DLOG(0,0,"Inside switch index");      
      case OMAP2_InsertSubscriberDataArg_imsi_present://8000
      {
         DLOG(0,0,"Adding IMSI");
         if(dbisd2.imsiReqd)
         {
            l_isd->bit_mask = OMAP2_InsertSubscriberDataArg_imsi_present;
            len = strlen((char *)dbisd2.imsi);
            l_isd->imsi.length = (len+1)/2;
            StringToBCD(l_isd->imsi.value,dbisd2.imsi,len);
            len = l_isd->imsi.length;
            pLen = len;
            DLOG(0,0,"Length after adding IMSI is %d",pLen);
         }
         index = OMAP2_InsertSubscriberDataArg_msisdn_present;//4000;
      }

      case OMAP2_InsertSubscriberDataArg_msisdn_present: //4000
      {
         TLOG(0,0,"Adding MSISDN %s",dbisd2.msisdn);
         l_isd->bit_mask |= OMAP2_InsertSubscriberDataArg_msisdn_present;
         u8 finalMsisdn[20];
         memset(finalMsisdn,'\0',sizeof(finalMsisdn));
         strncpy((char *)finalMsisdn,"19",2);
         strcat((char *)finalMsisdn,(char *)dbisd2.msisdn);
         int len2 = strlen((char *)finalMsisdn);
         l_isd->msisdn.length = (len2+1)/2;
         StringToBCD(l_isd->msisdn.value,finalMsisdn,len2);
         len += l_isd->msisdn.length;
         DLOG(0,0,"The Encoding length till here is %d MSISDN added %d",len,(len-pLen));
         pLen = len;
         index = OMAP2_category_present;
      }

      case OMAP2_category_present: //2000
      {
         DLOG(0,0,"Adding Category");
         l_isd->bit_mask |= OMAP2_category_present;
         l_isd->category.length = 1;
         l_isd->category.value[0] = dbisd2.category;
         len += 5;
         DLOG(0,0,"The Encoding length till here is %d CATEGORY added %d",len,(len-pLen));
         pLen = len;
         index = OMAP2_subscriberStatus_present;
      }

      case OMAP2_subscriberStatus_present: //1000
      {
         DLOG(0,0,"Adding subscriber status");
         l_isd->bit_mask |= OMAP2_subscriberStatus_present;
         l_isd->subscriberStatus = (OMAP2_SubscriberStatus)dbisd2.subStatus;
         len += 4;
         DLOG(0,0,"The Encoding length till here is %d SUBSCRIBER STATUS added %d",len,(len-pLen));
         pLen = len;
         index = OMAP2_InsertSubscriberDataArg_bearerServiceList_present;
      }

      case OMAP2_InsertSubscriberDataArg_bearerServiceList_present: //0800
      {
         if(dbisd2.bearer)
         {
            DLOG(0,0,"Adding bearer data");
            int l_PrevCount = 0;
            if(false == m_SecondChunk)
            {
               bs.formBearerV2C1(l_UserDlgId,l_isd,dbisd2.bearerData);
               DLOG(0,0,"Count of Bearer Service after Adding is %d",l_isd->bearerServiceList.count);
               len += (l_isd->bearerServiceList.count * 3) + 5; 
               l_PrevCount = l_isd->bearerServiceList.count;
               /*if(len >=IsdLen)
                 {
                 DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                 index = OMAP2_InsertSubscriberDataArg_bearerServiceList_present;
                 l_isd->bit_mask &= (~OMAP2_InsertSubscriberDataArg_bearerServiceList_present);
                 return true;
                 break;
                 }*/
            }
            if(m_SecondChunk)
               l_isd->bearerServiceList.count = 0;
            bs.formBearerV2C2(l_UserDlgId,l_isd,dbisd2.bearerData);
            DLOG(0,0,"Count of Bearer Service after Adding is %d",l_isd->bearerServiceList.count);
            pLen = len;
            len = len + 3+ (l_isd->bearerServiceList.count*3);
            if (len >=IsdLen)
            {
               TLOG(0,0,"Current length is %d sending till Subscriber Status",pLen);
               index =OMAP2_InsertSubscriberDataArg_bearerServiceList_present; 
               //l_isd->bit_mask &= (~OMAP3_InsertSubscriberDataArg_bearerServiceList_present);
               l_isd->bearerServiceList.count = l_PrevCount;
               flag = true;
               m_SecondChunk = true;
               return true;
               break;
            }
            DLOG(0,0,"The Encoding length till here is %d BEARER SERVICE LIST added %d",len,(len-pLen));
            pLen = len;
         }
         index = OMAP2_InsertSubscriberDataArg_teleserviceList_present;
      }

      case OMAP2_InsertSubscriberDataArg_teleserviceList_present: //0400
      {
         if(1)//dbisd2.basicPid)
         {
            DLOG(0,0,"Adding tele data");
            bs.formTeleV2(l_UserDlgId,l_isd,dbisd2.teleData);
            DLOG(0,0,"Count of Tele Service after Adding is %d",l_isd->teleserviceList.count);
            len += (l_isd->teleserviceList.count * 3) +  5; 
            if (len >=IsdLen)
            {
               DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
               index = OMAP2_InsertSubscriberDataArg_teleserviceList_present;
               l_isd->bit_mask &= (~OMAP2_InsertSubscriberDataArg_teleserviceList_present);
               return true;
               break;
            }
            DLOG(0,0,"The Encoding length till here is %d TELE SERVICE LIST added %d",len,(len-pLen));
            pLen = len;
         }
         index = OMAP2_provisionedSS_present;
      }

      case OMAP2_provisionedSS_present: //0200
      {
         switch(SsIndex)
         {
            case OMAP2_Ext_SS_Info_forwardingInfo_chosen: //choice 1
               {
                  l_isd->bit_mask |= OMAP2_provisionedSS_present;
                  DLOG(0,0,"going to add Call FWD info");
                  // DLOG(0,0,"SS Count value is %d\n",pss.val);
                  DLOG(0,0,"CFWD State is %d",pss.CFWD_STATE);
                  //DLOG(0,0,"Going to call pss.formFwdSS3(l_UserDlgId,l_isd)\n");
                  len = CheckLengthV2(l_isd);
                  //int rret = pss.formFwdSS2(l_UserDlgId,l_isd,g_MmConfigReaderObj->m_IsdLen);
                  int rret = pss.formFwdSS2(l_isd);

                  if(1 == rret) //Restart from this SS info
                  {
                     DLOG(0,0,"Current length exceeded sending till previous length %d",pLen);
                     DLOG(0,0,"Length after adding CFWD is %d\n",len);
                     index = OMAP2_provisionedSS_present;
                     l_isd->bit_mask &= (~OMAP2_provisionedSS_present);
                     SsIndex = OMAP2_Ext_SS_Info_forwardingInfo_chosen;
                     pss.val = 0;
                     DLOG(0,0,"Reset count to %d",pss.val);
                     DLOG(0,0,"CFWD State is %d",pss.CFWD_STATE);
                     flag = true;
                     return true;
                     break;
                  }
                  else if(2 == rret) //Restart from Next SS Info
                  {
                     DLOG(0,0,"Current length exceeded sending till previous length %d",len);
                     DLOG(0,0,"Length after adding CFWD is %d\n",len);
                     index = OMAP2_provisionedSS_present;
                     //l_isd->bit_mask &= (~OMAP3_provisionedSS_present);
                     SsIndex = OMAP2_Ext_SS_Info_forwardingInfo_chosen;
                     pss.val = 0;
                     DLOG(0,0,"Reset val to %d",pss.val);
                     DLOG(0,0,"CFWD State is %d",pss.CFWD_STATE);
                     flag = true;
                     return true;
                     break;
                  }

                  else
                  {
                     if(pss.val == 0)
                     {
                        l_isd->bit_mask &= (~OMAP2_provisionedSS_present);
                     }
                     DLOG(0,0,"Added Call FWD Info\n");
                     index = OMAP2_provisionedSS_present;
                     flag = false;
                     SsIndex = OMAP2_Ext_SS_Info_callBarringInfo_chosen;
                     DLOG(0,0,"Length after adding CFWD is %d",len);
                     DLOG(0,0,"The Encoding length till here is %d PROVISIONEDSS added %d",len,(len-pLen));
                     pLen = len;
                  }
               }
               //break;
            case OMAP2_Ext_SS_Info_callBarringInfo_chosen: //choice 2
               {
                  l_isd->bit_mask |= OMAP2_provisionedSS_present;
                  DLOG(0,0,"going to add CB info");
                  DLOG(0,0,"SS Count value is %d",pss.val);
                  DLOG(0,0,"CB State is %d",pss.CB_STATE);
                  //int reet = pss.formCbSS2(l_UserDlgId,l_isd,g_MmConfigReaderObj->m_IsdLen);
                  int reet = pss.formCbSS2(l_isd);
                  len = g_AsnCodecO2.getEncodingLength(OMAP2_InsertSubscriberDataArg_PDU,l_isd);
                  DLOG(0,0,"Returned from CbSS3, return value is %d",reet);
                  if(2 == reet)
                  {
                     DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                     index = OMAP2_provisionedSS_present;
                     DLOG(0,0,"Length after adding CB is %d",len);
                     //l_isd->bit_mask &= (~OMAP3_provisionedSS_present);
                     SsIndex = OMAP2_Ext_SS_Info_callBarringInfo_chosen;
                     pss.val = 0;
                     DLOG(0,0,"Reset count to %d",pss.val);
                     flag = true;
                     return true;
                     break;
                  }


                  if(1 == reet)
                  {
                     DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                     index = OMAP2_provisionedSS_present;
                     l_isd->bit_mask &= (~OMAP2_provisionedSS_present);
                     SsIndex = OMAP2_Ext_SS_Info_callBarringInfo_chosen;
                     pss.val = 0;
                     DLOG(0,0,"Reset count to %d\n",pss.val);
                     flag = true;
                     return true;
                     break;
                  }
                  if(pss.val == 0)
                  {
                     l_isd->bit_mask &= (~OMAP2_provisionedSS_present);
                  }
                  flag = false;
                  SsIndex = OMAP2_Ext_SS_Info_ss_Data_chosen;
                  //len = g_AsnCodecO2.getEncodingLength(OMAP2_InsertSubscriberDataArg_PDU,l_isd);
                  DLOG(0,0,"Length after adding CB is %d",len);
                  DLOG(0,0,"The Encoding length till here is %d PROVISIONEDSS added %d",len,(len-pLen));
                  pLen = len;
               }
               //break;
            case OMAP2_Ext_SS_Info_ss_Data_chosen:
               {
                  l_isd->bit_mask |= OMAP2_provisionedSS_present;
                  DLOG(0,0,"Going to form Ext_SS_Info val here is %d",pss.val);
                  PrevSS = pss.val;
                  //int rett = pss.formSsSS2(l_UserDlgId,l_isd,g_MmConfigReaderObj->m_IsdLen);
                  int rett = pss.formSsSS2(l_isd);
                  len = g_AsnCodecO2.getEncodingLength(OMAP2_InsertSubscriberDataArg_PDU,l_isd);
                  DLOG(0,0," Count here is %d return value is %d",pss.val,rett);
                  DLOG(0,0,"Finished adding SS INFO Provisioned SS data and returned to ISDData");
                  if(rett == 1)
                  {
                     DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                     index = OMAP2_provisionedSS_present;
                     DLOG(0,0,"Length after adding SS is %d\n",len);
                     l_isd->bit_mask &= (~OMAP2_provisionedSS_present);
                     SsIndex = OMAP2_Ext_SS_Info_ss_Data_chosen;
                     index = OMAP2_provisionedSS_present;
                     flag = true;
                     return true;
                     break;
                  }
                  else if(rett == 2)
                  {
                     DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                     index = OMAP2_provisionedSS_present;
                     DLOG(0,0,"Length after adding SS Data is %d",len);
                     DLOG(0,0,"PrevSS = %d",PrevSS);
                     if(l_isd->provisionedSS.count == 0)
                        l_isd->bit_mask &= (~OMAP2_provisionedSS_present);
                     SsIndex = OMAP2_Ext_SS_Info_ss_Data_chosen;
                     index = OMAP2_provisionedSS_present;
                     pss.val = 0;
                     DLOG(0,0,"Reset count to %d",pss.val);
                     flag = true;
                     return true;
                     break;
                  }
                  else
                  {
                     if(pss.val == 0)
                     {
                        l_isd->bit_mask &= (~OMAP2_provisionedSS_present);
                     }
                     flag = false;
                     SsIndex = 0;//OMAP2_emlpp_Info_chosen;
                     DLOG(0,0,"Length after adding SS is %d\n",len);
                     DLOG(0,0,"The Encoding length till here is %d PROVISIONEDSS added %d",len,(len-pLen));
                     pLen = len;
                  }
               }
               //break;

            default://Must not come here
               {
                  DLOG(0,0,"Inside Default");
                  SsIndex = 0;
                  index = OMAP2_odb_Data_present;
               }
               //break;
         }
         if(flag)
            break;
         else
         {
            DLOG(0,0,"After Provisioned SS,continuing with remaing ISD");
            //g_AsnCodecO3.printPdu(OMAP3_InsertSubscriberDataArg_PDU,l_isd,1,0);
            index = OMAP2_odb_Data_present;
         }
         //index = OMAP2_odb_Data_present;
      }

      case OMAP2_odb_Data_present: //0100
      {
         if(dbisd2.odb_Data)
         {
            if(dbisd2.odb_HplmnData)
            {
               l_isd->bit_mask |= OMAP2_odb_Data_present;
               l_isd->odb_Data.odb_GeneralData.length = 0;
               l_isd->odb_Data.bit_mask = OMAP2_odb_HPLMN_Data_present;               
               l_isd->odb_Data.odb_HPLMN_Data.value[0] = dbisd2.odb_HplmnValue;
               l_isd->odb_Data.odb_HPLMN_Data.length = 4;
               TLOG(0,0,"Added ODB HPLMN Data %ld, adding length %d, value %02x",dbisd2.odb_HplmnValue,l_isd->odb_Data.odb_HPLMN_Data.length,l_isd->odb_Data.odb_HPLMN_Data.value[0]);               
            }
            if(dbisd2.odb_Data)
            {
               l_isd->bit_mask |= OMAP2_odb_Data_present;
               l_isd->odb_Data.odb_GeneralData.value[0]  = dbisd2.odb_Genvalue;
               l_isd->odb_Data.odb_GeneralData.length = 6;                  
               TLOG(0,0,"Added ODB Data %ld, adding length %d, value %02x",dbisd2.odb_Genvalue,l_isd->odb_Data.odb_GeneralData.length,l_isd->odb_Data.odb_GeneralData.value[0]);               
            }
            if ((len = CheckLengthV2(l_isd)) >=IsdLen)
            {
               DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
               index = OMAP2_odb_Data_present;
               l_isd->bit_mask &= (~OMAP2_odb_Data_present);
               return true;
               break;
            }
            DLOG(0,0,"The Encoding length till here is %d ODB DATA added %d",len,(len-pLen));
            pLen = len;
         }
         index = OMAP2_InsertSubscriberDataArg_roamingRestrictionDueToUnsupportedFeature_present;
      }

      case OMAP2_InsertSubscriberDataArg_roamingRestrictionDueToUnsupportedFeature_present: //0080
      {
#if 0
         if(dbisd2.rr_duf)
         {
            l_isd->bit_mask = OMAP2_InsertSubscriberDataArg_roamingRestrictionDueToUnsupportedFeature_present;
            /*if ((len = CheckLengthV2(l_isd)) >=IsdLen)
              {
              DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
              index = OMAP2_InsertSubscriberDataArg_roamingRestrictionDueToUnsupportedFeature_present;
              l_isd->bit_mask &= (~OMAP2_InsertSubscriberDataArg_roamingRestrictionDueToUnsupportedFeature_present);
              SendIsdV2(l_UserDlgId,l_request,l_isd,index,MsgOpCode);
              break;
              }*/
            DLOG(0,0,"The Encoding length till here is %d Roaming Restricted Due to unSupported Feature added %d",len,(len-pLen));
            pLen = len;
         }
#endif
         index = OMAP2_regionalSubscriptionData_present;
      }

      case OMAP2_regionalSubscriptionData_present: //0040
      {
         index = 00000000;
         TLOG(0,0,"All data for ISD added,sending the ISD");
         m_AllDataAdded = true;
         return true;
         break;
      }
      default:
      {

      }
      //break;
   }
   return true;
}

bool ISDData::FormISDReqV1(int l_UserDlgId,unsigned int &index,unsigned int &SsIndex,bool flag,struct dbisd1,int &opCode,OMAP1_InsertSubscriberDataArg *l_isd)
{
   MsgOpCode = opCode;
   DLOG(0,0,"Inside ISDReq for User DlgId %d with index value %x for Update Location Msg opcode %d", l_UserDlgId,index,MsgOpCode);// m_isdCount [%d]\n, m_isdCount);
   //DLOG(0,0,"\n\nForming ISD request message for Dialog ID %d\n",l_UserDlgId);
   DLOG(0, 0, "Forming ISD request for Dialog Id %d,index value is %d,SS index %d",l_UserDlgId,index,SsIndex);
   //MapSpecificRequest l_request(l_UserDlgId, MAP_OP_CODE_insertSubscriberData, MAP_V1);
   //DECLARE(OMAP1_InsertSubscriberDataArg,l_isd, 1);
   DLOG(0,0,"Called by message opcode %d",MsgOpCode);
   IsdLen = g_MmConfigReaderObj->m_IsdLen;
   DLOG(0,0,"ISD data length configured is %d bytes",IsdLen);
   l_isd->bit_mask = 0;
   //int pLen,len;
   pLen = 0;
   len = 0;
   switch(index)
   {
      DLOG(0,0,"Inside switch index");
      case OMAP1_InsertSubscriberDataArg_imsi_present://0x80
      {
         DLOG(0,0,"Adding IMSI");
         if(dbisd1.imsiReqd)
         {
            l_isd->bit_mask = OMAP1_InsertSubscriberDataArg_imsi_present;
            len = strlen((char *)dbisd1.imsi);
            l_isd->imsi.length = (len+1)/2;
            StringToBCD(l_isd->imsi.value,dbisd1.imsi,len);
            pLen = l_isd->imsi.length;
            DLOG(0,0,"Length after adding IMSI is %d",pLen);
         }
         DLOG(0,0,"The Encoding length till here is %d TELE SERVICE LIST added %d",len,(len-pLen));
         pLen = len;
         index = OMAP1_InsertSubscriberDataArg_msIsdn_present;
      }
      //break;
      case OMAP1_InsertSubscriberDataArg_msIsdn_present://0x40
      {
         DLOG(0,0,"Adding MSISDN %s",dbisd1.msisdn);
         l_isd->bit_mask |= OMAP1_InsertSubscriberDataArg_msIsdn_present;
         u8 finalMsisdn[20];
         memset(finalMsisdn,'\0',sizeof(finalMsisdn));
         strncat((char *)finalMsisdn,"1",1);//(char *)nai);
         strncat((char *)finalMsisdn,"9",1);//(char *)npi);
         strcat((char *)finalMsisdn,(char *)dbisd1.msisdn);
         int len2 = strlen((char *)finalMsisdn);
         l_isd->msIsdn.length = (len2+1)/2;
         StringToBCD(l_isd->msIsdn.value,finalMsisdn,len2);
         DLOG(0,0,"The Encoding length till here is %d MSISDN added %d",len,(len-pLen));
         len = l_isd->msIsdn.length + 10;
         pLen = len;
         index = OMAP1_InsertSubscriberDataArg_category_present;
      }
      //break;
      case OMAP1_InsertSubscriberDataArg_category_present:
      {
         DLOG(0,0,"Adding Category");
         l_isd->bit_mask |= OMAP1_InsertSubscriberDataArg_category_present;
         l_isd->category.length = 1;
         l_isd->category.value[0] = dbisd1.category;
         len += 5;
         DLOG(0,0,"The Encoding length till here is %d CATEGORY added %d",len,(len-pLen));
         pLen = len;
         index = OMAP1_InsertSubscriberDataArg_subscriberStatus_present;
      }
      //break;
      case OMAP1_InsertSubscriberDataArg_subscriberStatus_present:
      {
         DLOG(0,0,"Adding subscriber status");
         l_isd->bit_mask |= OMAP1_InsertSubscriberDataArg_subscriberStatus_present;
         l_isd->subscriberStatus = (OMAP1_SubscriberStatus)dbisd1.subStatus;
         len += 5;
         DLOG(0,0,"The Encoding length till here is %d SUBSCRIBER STATUS added %d",len,(len-pLen));
         pLen = len;
         index = OMAP1_InsertSubscriberDataArg_bearerServiceList_present;
      }
      //break;
      case OMAP1_InsertSubscriberDataArg_bearerServiceList_present:
      {
         if(dbisd1.bearer)
         {
            DLOG(0,0,"bearer service data");
            int l_PrevCount =0; 
            //DLOG(0,0,"bearer Set the bit mask\n");
            if(false == m_SecondChunk)
            {
               bs.formBearerV1C1(l_UserDlgId,l_isd->bearerServiceList,dbisd1.bearerData);
               DLOG(0,0,"Count of Bearer Service after Adding is %d",l_isd->bearerServiceList.count);
               l_PrevCount = l_isd->bearerServiceList.count;
               if(l_isd->bearerServiceList.count)
                  l_isd->bit_mask |=  OMAP1_InsertSubscriberDataArg_bearerServiceList_present;
               /*if ((len = CheckLengthV1(l_isd)) >=IsdLen)
                 {
                 DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                 index = OMAP1_InsertSubscriberDataArg_bearerServiceList_present;
                 l_isd->bit_mask &= (~OMAP1_InsertSubscriberDataArg_bearerServiceList_present);
                 return true;
                 break;
                 }*/
            }
            if(m_SecondChunk)
               l_isd->bearerServiceList.count = 0;
            bs.formBearerV1C2(l_UserDlgId,l_isd->bearerServiceList,dbisd1.bearerData);
            DLOG(0,0,"Count of Bearer Service after Adding is %d",l_isd->bearerServiceList.count);
            if(l_isd->bearerServiceList.count)
               l_isd->bit_mask |=  OMAP1_InsertSubscriberDataArg_bearerServiceList_present;
            pLen = len;
            len = len + 3+ (l_isd->bearerServiceList.count*3);
            if (len >=IsdLen)
            {
               TLOG(0,0,"Current length is %d sending till Subscriber Status",pLen);
               index = OMAP1_InsertSubscriberDataArg_bearerServiceList_present; 
               //l_isd->bit_mask &= (~OMAP3_InsertSubscriberDataArg_bearerServiceList_present);
               l_isd->bearerServiceList.count = l_PrevCount;
               flag = true;
               m_SecondChunk = true;
               return true;
               break;
            }
            DLOG(0,0,"The Encoding length till here is %d BEARER SERVICE LIST added %d",len,(len-pLen));
            pLen = len;
         }
         index = OMAP1_InsertSubscriberDataArg_teleserviceList_present;
      }
      //break;
      case OMAP1_InsertSubscriberDataArg_teleserviceList_present:
      {
         if(1)//dbisd1.basicPid)
         {
            DLOG(0,0,"Teleservice list [%s]",dbisd1.teleData);
            //DLOG(0,0,"Tele Set the bit mask\n");
            bs.formTeleV1(l_UserDlgId,l_isd->teleserviceList,dbisd1.teleData);
            DLOG(0,0,"Count of Tele Service after Adding is %d",l_isd->teleserviceList.count);
            if(l_isd->teleserviceList.count)
               l_isd->bit_mask |=   OMAP1_InsertSubscriberDataArg_teleserviceList_present;
            if ((len = CheckLengthV1(l_isd)) >=IsdLen)
            {
               DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
               index = OMAP1_InsertSubscriberDataArg_teleserviceList_present;
               l_isd->bit_mask &= (~OMAP1_InsertSubscriberDataArg_teleserviceList_present);
               return true;
               break;
            }
            DLOG(0,0,"The Encoding length till here is %d TELE SERVICE LIST added %d",len,(len-pLen));
            pLen = len;
         }
         index = OMAP1_InsertSubscriberDataArg_provisonedSS_present;

      }
      //break;
      case OMAP1_InsertSubscriberDataArg_provisonedSS_present:
      {
         switch(SsIndex)
         {
            case OMAP1_forwardingInfo_chosen: //choice 1
               {
                  l_isd->bit_mask |= OMAP1_InsertSubscriberDataArg_provisonedSS_present;
                  l_isd->provisonedSS.count = 0;
                  DLOG(0,0,"going to add CFWD FWD info, CFWD State is %d cnt [%d]",pss.CFWD_STATE,pss.val);
                  //int rret = pss.formFwdSS1(l_UserDlgId,l_isd,g_MmConfigReaderObj->m_IsdLen);
                  int rret = pss.formFwdSS1(l_isd);

                  if(1 == rret)
                  {
                     //DLOG(0,0,"Current length exceeded sending till previous length %d",pLen);
                     DLOG(0,0,"Length after adding CFWD is %d",len);
                     index = OMAP1_InsertSubscriberDataArg_provisonedSS_present;
                     l_isd->bit_mask &= (~OMAP1_InsertSubscriberDataArg_provisonedSS_present);
                     SsIndex = OMAP1_forwardingInfo_chosen;
                     pss.val = 0;
                     DLOG(0,0,"Reset val to %d",pss.val);
                     DLOG(0,0,"CFWD State is %d",pss.CFWD_STATE);
                     flag = true;
                     return true;
                     break;
                  }
                  else if(2 == rret)
                  {
                     //DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                     DLOG(0,0,"Length after adding CFWD is %d",len);
                     index = OMAP1_InsertSubscriberDataArg_provisonedSS_present;
                     //l_isd->bit_mask &= (~OMAP3_provisionedSS_present);
                     SsIndex = OMAP1_forwardingInfo_chosen;
                     pss.val = 0;
                     DLOG(0,0,"Reset count to %d",pss.val);
                     DLOG(0,0,"CFWD State is %d",pss.CFWD_STATE);
                     flag = true;
                     return true;
                     break;
                  }

                  else
                  {
                     if(pss.val == 0)
                     {
                        l_isd->bit_mask &= (~OMAP1_InsertSubscriberDataArg_provisonedSS_present);
                     }
                     DLOG(0,0,"Added Call FWD unconditional Info");
                     index = OMAP1_InsertSubscriberDataArg_provisonedSS_present;
                     flag = false;
                     SsIndex = OMAP1_callBarringInfo_chosen;
                     DLOG(0,0,"Length after adding CFWD is %d",len);
                     DLOG(0,0,"The Encoding length till here is %d PROVISIONEDSS added %d",len,(len-pLen));
                     pLen = len;
                  }
               }
               //break;
            case OMAP1_callBarringInfo_chosen: //choice 2
               {
                  l_isd->bit_mask |= OMAP1_InsertSubscriberDataArg_provisonedSS_present;
                  DLOG(0,0,"Going to add CB info, SS Count value is [%d] CB State is  [%d] ss cnt till added [%d]",pss.val,pss.CB_STATE,l_isd->provisonedSS.count);
                  int l_len1 = CheckLengthV1(l_isd);
                  //int reet = pss.formCbSS1(l_UserDlgId,l_isd,l_len1);
                  int reet = pss.formCbSS1(l_isd,g_MmConfigReaderObj->m_IsdLen);
                  //DLOG(0,0,"Returned from CbSS3\n");
                  if(2 == reet)
                  {
                     DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                     index = OMAP1_InsertSubscriberDataArg_provisonedSS_present;
                     //DLOG(0,0,"else 2 , Length after adding CB is %d\n",g_AsnCodecO1.getEncodingLength(OMAP2_InsertSubscriberDataArg_PDU,l_isd));
                     //l_isd->bit_mask &= (~OMAP3_provisionedSS_present);
                     SsIndex = OMAP1_callBarringInfo_chosen;
                     pss.val = 0;
                     DLOG(0,0,"Reset Count to %d",pss.val);
                     flag = true;
                     return true;
                     break;
                  }


                  if(1 == reet)
                  {
                     DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                     index = OMAP1_InsertSubscriberDataArg_provisonedSS_present;
                     l_isd->bit_mask &= (~OMAP1_InsertSubscriberDataArg_provisonedSS_present);
                     SsIndex = OMAP1_callBarringInfo_chosen;
                     pss.val = 0;
                     DLOG(0,0,"Reset count to %d",pss.val);
                     flag = true;
                     return true;
                     break;
                  }
                  if(pss.val == 0)
                  {
                     l_isd->bit_mask &= (~OMAP1_InsertSubscriberDataArg_provisonedSS_present);
                  }
                  flag = false;
                  SsIndex = OMAP1_ss_Data_chosen;
                  len = g_AsnCodecO1.getEncodingLength(OMAP1_InsertSubscriberDataArg_PDU,l_isd);
                  DLOG(0,0,"Length after adding CB is %d",len);
                  DLOG(0,0,"The Encoding length till here is %d PROVISIONEDSS added %d",len,(len-pLen));
                  pLen = len;
               }
               //break;
            case OMAP1_ss_Data_chosen:
               {
                  DLOG(0,0,"Going to form Ext_SS_Info count here is [%d] cnt [%d]",pss.val,l_isd->provisonedSS.count);
                  PrevSS = pss.val;
                  int l_len2 = CheckLengthV1(l_isd);
                  //int rett = pss.formSsSS1(l_UserDlgId,l_isd,l_len2);
                  l_isd->bit_mask |= OMAP1_InsertSubscriberDataArg_provisonedSS_present;
                  int rett = pss.formSsSS1(l_isd,l_len2);
                  DLOG(0,0,"After Other SS -> Val here is [%d] cnt [%d] rett is [%d]",pss.val,l_isd->provisonedSS.count,rett);
                  //DLOG(0,0,"Finished adding SS INFO Provisioned SS data and returned to ISDData");
                  if(l_isd->provisonedSS.count == 0)
                  {
                     DLOG(0,0,"count for provisioned ss 0, unsetting the bit mask");
                     l_isd->bit_mask &= (~OMAP1_InsertSubscriberDataArg_provisonedSS_present);
                  }
                  if(rett == 1)
                  {
                     DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                     index = OMAP1_InsertSubscriberDataArg_provisonedSS_present;
                     DLOG(0,0,"Length after adding SS DATA is %d",len);
                     l_isd->bit_mask &= (~OMAP1_InsertSubscriberDataArg_provisonedSS_present);
                     SsIndex = OMAP1_ss_Data_chosen;
                     index = OMAP1_InsertSubscriberDataArg_provisonedSS_present;
                     flag = true;
                     return true;
                     break;
                  }
                  else if(rett == 2)
                  {
                     DLOG(0,0,"Current length is %d sending till previous length %d PrevSS = %d",len,pLen,PrevSS);
                     index = OMAP1_InsertSubscriberDataArg_provisonedSS_present;
                     SsIndex = OMAP1_ss_Data_chosen;
                     index = OMAP1_InsertSubscriberDataArg_provisonedSS_present;
                     pss.val = 0;
                     DLOG(0,0,"Reset count to %d",pss.val);
                     flag = true;
                     return true;
                     break;
                  }
                  else
                  {

                     flag = false;
                     SsIndex = 0;
                     index = 0;
                     //DLOG(0,0,"Length after adding SS Data is %d",len);
                     //DLOG(0,0,"The Encoding length till here is %d PROVISIONEDSS added %d",len,(len-pLen));
                     pLen = len;
                     pss.val = 0;
                     DLOG(0,0,"Reset count to %d",pss.val);
                     flag = true;
                  }
               }
               //break;
            default://Must not come here
               {
                  DLOG(0,0,"Inside Default");
                  SsIndex = 0;
                  index = 00;
               }
               //break;
         }
         if(flag)
            break;
         else
         {
            DLOG(0,0,"After Provisioned SS,continuing with remaing ISD");
            index = 00;
         }
         index = 00;
         TLOG(0,0,"All data for ISD added,sending the ISD");
         m_AllDataAdded = true;
         return true;
         break;
      }
      //break;
      default:
      {
      }
      //break;
   }
   return true;
}

int ISDData::CheckLengthV3(OMAP3_InsertSubscriberDataArg *l_isd)//,int l_Version)
{     
   int enclen=0;
   //enclen = MAP3_getEncodingLength(MAP3_InsertSubscriberDataArg_PDU, l_isd);
   //enclen = asn.getEncodingLength(MAP3_InsertSubscriberDataArg_PDU, l_isd);
   enclen = g_AsnCodecO3.getEncodingLength(OMAP3_InsertSubscriberDataArg_PDU, l_isd);
   //DLOG(0,0,"The encoding length is %d",enclen);
   return enclen;
}

int ISDData::CheckLengthV2(OMAP2_InsertSubscriberDataArg *l_isd)//,int l_Version)
{
   int enclen=0;
   //DLOG(0,0,"Inside check length version 2");
   //enclen = OMAP2_getEncodingLength(OMAP2_InsertSubscriberDataArg_PDU, l_isd);
   enclen = g_AsnCodecO2.getEncodingLength(OMAP2_InsertSubscriberDataArg_PDU, l_isd);
   //DLOG(0,0,"The encoding length is %d",enclen);
   return enclen;
}
int ISDData::CheckLengthV1(OMAP1_InsertSubscriberDataArg *l_isd)//,int l_Version)
{
   int enclen=0;
   //DLOG(0,0,"Inside check length version 2");
   //enclen = OMAP2_getEncodingLength(OMAP2_InsertSubscriberDataArg_PDU, l_isd);
   enclen = g_AsnCodecO1.getEncodingLength(OMAP1_InsertSubscriberDataArg_PDU, l_isd);
   //DLOG(0,0,"The encoding length is %d",enclen);
   return enclen;
}

/*void ISDData::SendIsdV3(int DlgId,MapSpecificRequest l_request,OMAP3_InsertSubscriberDataArg *l_isd,unsigned int &numOfParam,unsigned int &VcsiParam,unsigned int &ScsiParam,unsigned int &SsParam,int MsgOpCode)
  {
  DLOG(0,0,"Opcode received here is %d",MsgOpCode);
#if 0
switch(MsgOpCode)
{
case 2:
{
DLOG(0,0,"Calling SendMsg in CtxtUpdateLocation");
DLOG(0,0,"The Index value till which the msg is formed is %x",numOfParam);
m_upd->SendMsgV3(DlgId,l_request,l_isd,numOfParam,VcsiParam,ScsiParam,SsParam);
}
break;
case 23:
{
DLOG(0,0,"Calling SendMsg in CtxtUpdateGprsLocation");
DLOG(0,0,"The Index value till which the msg is formed is %x",numOfParam);
upg.SendMsgV3(DlgId,l_request,l_isd,numOfParam,VcsiParam,ScsiParam,SsParam);
}
break;
case 57:
{
DLOG(0,0,"Calling SendMsg in CtxtRestoreSubscriberData");
DLOG(0,0,"The Index value till which the msg is formed is %x",numOfParam);
//rd.SendMsgV3(DlgId,l_request,l_isd,numOfParam);
rd.SendMsgV3(DlgId,l_request,l_isd,numOfParam,VcsiParam,ScsiParam,SsParam);
}
break;
default:
{
DLOG(0,0,"Unknown opcode, doing nothing");
}
break;
}
#endif
}*/

/*void ISDData::SendIsdV2(int DlgId,MapSpecificRequest l_request,OMAP2_InsertSubscriberDataArg *l_isd,unsigned int &numOfParam,unsigned int &SsParam,int MsgOpCode)
  {
  switch(MsgOpCode)
  {
  case 2:
  {
  DLOG(0,0,"Calling SendMsg in CtxtUpdateLocation");
  DLOG(0,0,"The Index value till which the msg is formed is %x",numOfParam);
  m_upd->SendMsgV2(DlgId,l_request,l_isd,numOfParam,SsParam);
  }
  break;
  case 57:
  {
  DLOG(0,0,"Calling SendMsg in CtxtUpdateLocation");
  DLOG(0,0,"The Index value till which the msg is formed is %x",numOfParam);
  rd.SendMsgV2(DlgId,l_request,l_isd,numOfParam,SsParam);
  }
  break;
  default:
  {
  DLOG(0,0,"Unknown Opcode,doing nothing");
  }
  break;

  }
  }*/

/*void ISDData::SendIsdV1(int DlgId,MapSpecificRequest l_request,OMAP1_InsertSubscriberDataArg *l_isd,unsigned int &numOfParam,unsigned int &SsParam,int MsgOpCode)
  {
#if 0
switch(MsgOpCode)
{
case 2:
{
DLOG(0,0,"Calling SendMsg in CtxtUpdateLocation");
DLOG(0,0,"The Index value till which the msg is formed is %x",numOfParam);
m_upd->SendMsgV1(DlgId,l_request,l_isd,numOfParam,SsParam);
//SendMsgV1(int DlgId,MapSpecificRequest l_request,OMAP1_InsertSubscriberDataArg *l_isd,unsigned int &numOfParam,unsigned int &SsParam)
}
break;
default:
{
DLOG(0,0,"Unknown Opcode,doing nothing");
}
break;

}
#endif
}*/

//bool ISDData::ProcessIsdResV2(int l_UserDlgId,IMAP2_InsertSubscriberDataRes *ISD_Res,int &opCode)
bool ISDData::ProcessIsdResV2(int l_UserDlgId,IMAP2_InsertSubscriberDataRes *ISD_Res)
{
   TLOG(0,0,"ISD Acknowledge received for Dialog ID %d bitmask %x",l_UserDlgId,ISD_Res->bit_mask);
   if(ISD_Res->bit_mask != 0)
   {
      DLOG(0,0,"ISD response not null");
      if (ISD_Res->bit_mask & IMAP2_InsertSubscriberDataRes_teleserviceList_present)
      {
         DLOG(0,0,"ISD Res Teleservice list not supported present") ;
         IMAP2_TeleserviceList_ *l_teleList;
         unsigned char l_Unsupp_tele[33];
         memset((char *)l_Unsupp_tele,'\0',sizeof(l_Unsupp_tele));
         memset((char *)l_Unsupp_tele,'0',32);
         l_teleList = ISD_Res->teleserviceList;
         while(l_teleList != NULL) 
         {
            TLOG(0,0,"Teleservice %d, not supported",l_teleList->value.value[0]);
            l_Unsupp_tele[g_spdPtr->m_TeleToDB[l_teleList->value.value[0]]] = '1';
            l_teleList =l_teleList->next;
         }
         LLOG(0,0,"Teleservice code unsuppoted %s",l_Unsupp_tele);
         strcpy((char *)m_Unsupp_Tele,(char *)l_Unsupp_tele);
         m_IsdResp_With_Unsupp_Service_Rcvd = true;
      }
      if(ISD_Res->bit_mask & IMAP2_InsertSubscriberDataRes_bearerServiceList_present)
      {
         DLOG(0,0,"ISD Res Bearer Service List not supported Present");
         IMAP2_BearerServiceList_ *l_bearerList;
         unsigned char l_Unsupp_bearer[53];
         memset((char *)l_Unsupp_bearer,'\0',sizeof(l_Unsupp_bearer));
         memset((char *)l_Unsupp_bearer,'0',52);
         l_bearerList = ISD_Res->bearerServiceList;
         while(l_bearerList != NULL) 
         {
            TLOG(0,0,"Bearerservice %d, not supported",l_bearerList->value.value[0]);
            l_Unsupp_bearer[g_spdPtr->m_BearerToDB[l_bearerList->value.value[0]]] = '1';
            l_bearerList =l_bearerList->next;
         }
         LLOG(0,0,"Bearerservice code unsuppoted %s",l_Unsupp_bearer);
         strcpy((char *)m_Unsupp_Bearer,(char *)l_Unsupp_bearer);
         m_IsdResp_With_Unsupp_Service_Rcvd = true;
      }
      if(ISD_Res->bit_mask & IMAP2_InsertSubscriberDataRes_ss_List_present)
      {
         TLOG(0,0,"ISD Res SS List not supported present");
         IMAP2_SS_List_ *l_ssList;
         unsigned char l_Unsupp_ss[201];
         memset((char *)l_Unsupp_ss,'\0',sizeof(l_Unsupp_ss));
         l_ssList = ISD_Res->ss_List;
         while(l_ssList != NULL) 
         {
            TLOG(0,0,"Supplementary service %d, not supported",l_ssList->value.value[0]);
            char l_tmp[5];
            snprintf(l_tmp,5,"%d",(char *)l_ssList->value.value[0]);
            strcat((char *)l_Unsupp_ss,l_tmp);
            strcat((char *)l_Unsupp_ss,",");
            l_ssList =l_ssList->next;
         }
         //strcpy((char *)m_Unsupp_SS,(char *)l_Unsupp_ss);
         strncpy((char *)m_Unsupp_SS,(char *)l_Unsupp_ss,(strlen((char *)l_Unsupp_ss) -1 ));
         m_IsdResp_With_Unsupp_Service_Rcvd = true;
         LLOG(0,0,"SS CODE unsupportd %s",m_Unsupp_SS);
      }
      if(ISD_Res->bit_mask & IMAP2_odb_GeneralData_present)
      {
         DLOG(0,0,"ISD Res odb General data not supported present");
         struct test
         {
            unsigned char  a:1,
                           b:1,
                           c:1,
                           d:1,
                           e:1,
                           f:1,
                           g:1,
                           h:1;
         };
         union ODBData 
         {
            test l_odbbit;
            unsigned int l_odbint;
            unsigned char l_Odbchar[4];
         };
         ODBData l_GenOdb;
         l_GenOdb.l_Odbchar[0] = ISD_Res->odb_GeneralData.value[0];
         l_GenOdb.l_Odbchar[1] = l_GenOdb.l_Odbchar[2] = l_GenOdb.l_Odbchar[3] = 0x00;
         DLOG(0,0,"ODB data value rejected in integer is %ld bit %d%d%d%d%d%d%d%d",l_GenOdb.l_odbint,l_GenOdb.l_odbbit.a,l_GenOdb.l_odbbit.b,l_GenOdb.l_odbbit.c,l_GenOdb.l_odbbit.d,l_GenOdb.l_odbbit.e,l_GenOdb.l_odbbit.f,l_GenOdb.l_odbbit.g,l_GenOdb.l_odbbit.h);
         WLOG(0,0,"odb_GeneralData received len %d, val : %02x in int %ld",ISD_Res->odb_GeneralData.length,ISD_Res->odb_GeneralData.value[0],l_GenOdb.l_odbint);//,ISD_Res->odb_GeneralData.value[1],ISD_Res->odb_GeneralData.value[2],ISD_Res->odb_GeneralData.value[3]);
         m_Unsupp_ODB = l_GenOdb.l_odbint;
         //
         //Added in 1.0.8.0
         //
         if(l_GenOdb.l_odbint > 0)// & ALL_OG_CALLS_BARRED)
            return false;
         //
         //Added in 1.0.8.0
         //
         m_IsdResp_With_Unsupp_Service_Rcvd = true;
      }
      if(ISD_Res->bit_mask & IMAP2_InsertSubscriberDataRes_regionalSubscriptionResponse_present)
      {
         LLOG(0,0,"ISD Res Regional subscription response present");
      }
      return true;
   }
   else
   {
      DLOG(0,0,"No data in ISD response,continuing");
      return true;
   }
}

//Called to check the ISD_Resp and send remaining/Modified ISD_Req
//bool ISDData::ProcessIsdResV3(int l_UserDlgId,IMAP3_InsertSubscriberDataRes *ISD_Res,int &opCode)
bool ISDData::ProcessIsdResV3(int l_UserDlgId,IMAP3_InsertSubscriberDataRes *ISD_Res)
{
   TLOG(0,0,"ISD Acknowledge received for Dialog id %d bit_mask received %x",l_UserDlgId,ISD_Res->bit_mask);
   if(ISD_Res->bit_mask != 0)
   {      
      if (ISD_Res->bit_mask & IMAP3_InsertSubscriberDataRes_teleserviceList_present)
      {
         DLOG(0,0,"Teleservice not supported indicator Present");
         IMAP3_TeleserviceList_ *l_teleList;
         l_teleList = ISD_Res->teleserviceList;
         unsigned char l_Unsupp_tele[33];
         memset((char *)l_Unsupp_tele,'\0',sizeof(l_Unsupp_tele));
         memset((char *)l_Unsupp_tele,'0',32);
         DLOG(0,0,"Teleservice code unsuppoted %s",l_Unsupp_tele);
         while(l_teleList != NULL) 
         {
            TLOG(0,0,"Teleservice %d, not supported",l_teleList->value.value[0]);
            l_Unsupp_tele[g_spdPtr->m_TeleToDB[l_teleList->value.value[0]]] = '1';
            l_teleList =l_teleList->next;
         }
         LLOG(0,0,"Teleservice code unsuppoted %s",l_Unsupp_tele);
         strcpy((char *)m_Unsupp_Tele,(char *)l_Unsupp_tele);
         m_IsdResp_With_Unsupp_Service_Rcvd = true;
      }
      if(ISD_Res->bit_mask & IMAP3_InsertSubscriberDataRes_bearerServiceList_present)
      {
         TLOG(0,0,"Bearer Service data not supported indicator Present");
         IMAP3_BearerServiceList_ *l_bearerList;
         unsigned char l_Unsupp_bearer[53];
         memset((char *)l_Unsupp_bearer,'\0',sizeof(l_Unsupp_bearer));
         memset((char *)l_Unsupp_bearer,'0',52);
         l_bearerList = ISD_Res->bearerServiceList;
         while(l_bearerList != NULL) 
         {
            TLOG(0,0,"Bearerservice %d, not supported",l_bearerList->value.value[0]);
            l_Unsupp_bearer[g_spdPtr->m_BearerToDB[l_bearerList->value.value[0]]] = '1';
            l_bearerList =l_bearerList->next;
         }
         LLOG(0,0,"Bearerservice code unsuppoted %s",l_Unsupp_bearer);
         strcpy((char *)m_Unsupp_Bearer,(char *)l_Unsupp_bearer);
         m_IsdResp_With_Unsupp_Service_Rcvd = true;
      }
      if(ISD_Res->bit_mask & IMAP3_InsertSubscriberDataRes_ss_List_present)
      {
         DLOG(0,0,"SS not supported indicator present");
         IMAP3_SS_List_ *l_ssList;
         unsigned char l_Unsupp_ss[201];
         memset((char *)l_Unsupp_ss,'\0',sizeof(l_Unsupp_ss));
         l_ssList = ISD_Res->ss_List;
         while(l_ssList != NULL) 
         {
            TLOG(0,0,"Supplementary service %d, not supported",l_ssList->value.value[0]);
            char l_tmp[5];
            snprintf(l_tmp,5,"%d",(char *)l_ssList->value.value[0]);
            strcat((char *)l_Unsupp_ss,l_tmp);
            strcat((char *)l_Unsupp_ss,",");
            l_ssList =l_ssList->next;
         }
         strncpy((char *)m_Unsupp_SS,(char *)l_Unsupp_ss,(strlen((char *)l_Unsupp_ss) -1 ));
         LLOG(0,0,"SS CODE unsupportd %s",m_Unsupp_SS);
         m_IsdResp_With_Unsupp_Service_Rcvd = true;
      }
      if(ISD_Res->bit_mask & IMAP3_odb_GeneralData_present)
      {
         TLOG(0,0,"ISD Res odb General data present");
         union ODBData 
         {
            unsigned int l_odbint;
            unsigned char l_Odbchar[4];
         };
         ODBData l_GenOdb;
         TLOG(0,0,"odb_GeneralData received len %d, val : %02x%02x%02x%02x",ISD_Res->odb_GeneralData.length,ISD_Res->odb_GeneralData.value[0],ISD_Res->odb_GeneralData.value[1],ISD_Res->odb_GeneralData.value[2],ISD_Res->odb_GeneralData.value[3]);
         l_GenOdb.l_Odbchar[0] = ISD_Res->odb_GeneralData.value[0];
         l_GenOdb.l_Odbchar[1] = ISD_Res->odb_GeneralData.value[1];
         l_GenOdb.l_Odbchar[2] = ISD_Res->odb_GeneralData.value[2];
         l_GenOdb.l_Odbchar[3] = ISD_Res->odb_GeneralData.value[3];
         WLOG(0,0,"ODB data value rejected in integer is %ld",l_GenOdb.l_odbint);
         //
         //Added in 1.0.8.0
         //
         m_Unsupp_ODB = l_GenOdb.l_odbint;
         if(l_GenOdb.l_odbint > 0)// & ALL_OG_CALLS_BARRED)
            return false;
         //
         //Added in 1.0.8.0
         //
         //m_Unsupp_ODB = l_GenOdb.l_odbint;
         m_IsdResp_With_Unsupp_Service_Rcvd = true;
      }
      if(ISD_Res->bit_mask & IMAP3_InsertSubscriberDataRes_regionalSubscriptionResponse_present)
      {
         LLOG(0,0,"Regional subscription data not supported present");
         int l_rSubRes;
         l_rSubRes = ISD_Res->regionalSubscriptionResponse;
      }
      bool l_IsdRes_Camel1 = false;
      bool l_IsdRes_Camel2 = false;
      bool l_IsdRes_Camel3 = false;
      bool l_IsdRes_Camel4 = false;
      if(ISD_Res->bit_mask & IMAP3_InsertSubscriberDataRes_supportedCamelPhases_present)
      {
         if(*ISD_Res->supportedCamelPhases.value & IMAP3_phase1)
         {
            l_IsdRes_Camel1 = true;
            TLOG(0,0,"CAMEL Phase 1 supported");
         }
         if(*ISD_Res->supportedCamelPhases.value & IMAP3_phase2)
         {
            l_IsdRes_Camel2 = true;
            TLOG(0,0,"CAMEL Phase 2 supported");
         }
         if(*ISD_Res->supportedCamelPhases.value & IMAP3_phase3)
         {
            l_IsdRes_Camel3 = true;
            TLOG(0,0,"CAMEL Phase 3 supported");
         }
         if(*ISD_Res->supportedCamelPhases.value & IMAP3_phase4)
         {
            l_IsdRes_Camel4 = true;
            TLOG(0,0,"CAMEL Phase 4 supported");
         }
         LLOG(0,0,"Camel phases Supported present, supported val [%d%d%d%d]",l_IsdRes_Camel1,l_IsdRes_Camel2,l_IsdRes_Camel3,l_IsdRes_Camel4);
      }
      if(ISD_Res->bit_mask & IMAP3_InsertSubscriberDataRes_offeredCamel4CSIs_present)
      {
         if(l_IsdRes_Camel4)
         {
            bool l_IsdRes_oCSI;
            l_IsdRes_oCSI = 0;
            bool l_IsdRes_dCSI;
            l_IsdRes_dCSI = 0;
            bool l_IsdRes_vtCSI;
            l_IsdRes_vtCSI = 0;
            bool l_IsdRes_tCSI;
            l_IsdRes_tCSI = 0;
            bool l_IsdRes_mtsmsCSI;
            l_IsdRes_mtsmsCSI = 0;
            bool l_IsdRes_mgCSI;
            l_IsdRes_mgCSI = 0;
            bool l_IsdRes_psiCSI;
            l_IsdRes_psiCSI = 0;

            //DLOG(0,0,"ISD Res Offered CAMEL 4 CSI present\n");
            DLOG(0,0,"ISD Res Offered CAMEL 4 CSI present");
            if(*ISD_Res->offeredCamel4CSIs.value & IMAP3_OfferedCamel4CSIs_o_csi)
            {
               //DLOG(0,0,"Offered Camel4 CSIs_o_csi present\n");
               l_IsdRes_oCSI = 1;
               DLOG(0,0,"O_CSI supported");
            }
            if(*ISD_Res->offeredCamel4CSIs.value & IMAP3_OfferedCamel4CSIs_d_csi)
            {
               //DLOG(0,0,"Offered Camel4 CSIs_d_csi present\n");
               l_IsdRes_dCSI = 1;
               DLOG(0,0,"D_CSI supported");
            }
            if(*ISD_Res->offeredCamel4CSIs.value & IMAP3_OfferedCamel4CSIs_vt_csi)
            {
               //DLOG(0,0,"Offered Camel4 CSIs_vt_csi present\n");
               l_IsdRes_vtCSI = 1;
               DLOG(0,0,"VT_CSI supported");
            }
            if(*ISD_Res->offeredCamel4CSIs.value & IMAP3_OfferedCamel4CSIs_t_csi)
            {
               //DLOG(0,0,"Offered Camel4 CSIs_t_csi present\n");
               l_IsdRes_tCSI = 1;
               DLOG(0,0,"T_CSI supported");
            }
            if(*ISD_Res->offeredCamel4CSIs.value & IMAP3_OfferedCamel4CSIs_mt_sms_csi)
            {
               //DLOG(0,0,"Offered Camel4 CSIs_mt_sms_csi present\n");
               l_IsdRes_mtsmsCSI = 1;
               DLOG(0,0,"MT_SMS_CSI supported");
            }
            if(*ISD_Res->offeredCamel4CSIs.value & IMAP3_OfferedCamel4CSIs_mg_csi)
            {
               //DLOG(0,0,"Offered Camel4 CSIs_mg_csi present\n");
               l_IsdRes_mgCSI = 1;
               DLOG(0,0,"MG_CSI supported");
            }
            if(*ISD_Res->offeredCamel4CSIs.value & IMAP3_psi_enhancements)
            {
               //DLOG(0,0,"Camel4 CSIs psi_enhancements present\n");
               l_IsdRes_psiCSI = 1;
               DLOG(0,0,"PSI_Enhancement supported");
            }
         }
         else
         {
            CLOG(0,0,"offeredCamel4CSIs present without presence of Camel Phase 4 support indicator");
         }
      }
#if 0
      {
         if (false == Ignore Unsupported service)//Have a seperate table to see this and replace
         {
            if (true == Replace service in VLR)
            {
               replace service;
               ISD_V3(CallDetails);
            }
            if (true == Unsupported sevice critical)
            {
               //roamingRestrictionDueToUnsupportedFeature = True;
               isd_req->bit_mask = MAP3_InsertSubscriberDataArg_roamingRestrictionDueToUnsupportedFeature_present;
               //MSCAreaRestricted = True;
               ISD_V3(DB_Data);
            }
            //HLR_Internal_Action // Wat to do for this ??
         }
      }
      if (true == MSCAreaRestricted)
      {
         MSCAreaRestricted = true;
      }
      if (count > 0)
         wait for ISD_Ack
      else
      {
         if (true == more data to send)
            ISD_V3(CallDetails);
         else
         {
            DLOG(0,0,"The ISD result is pass,sending Upd Location Response\n");
            updLocResV3(l_UserDlgID);
         }
      }
#endif
      //updLocResV3(l_UserDlgId);
      return true;
   }
   else
   {
      //DLOG(0,0,"\n\nNo data in ISD response,continuing\n");
      DLOG(0,0,"No data in ISD response,continuing");
      return true;
   }
}


