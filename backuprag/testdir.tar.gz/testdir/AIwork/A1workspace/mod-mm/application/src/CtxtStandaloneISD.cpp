/*******************************************************************************
 * File        : StandaloneISD.h
 * Author      : VenkatRaman
 * Description : To send ISD params whenever
 *               1. data shall be modified in both the HLR and the VLR
 *               2. data shall be modified in both the HLR and the SGSN
 * Created on  : July 1, 2010, 6:20 PM IST
 *******************************************************************************/

#include <StandaloneISD.h>
#include <stdio.h>
#include <ServiceCoordinator.h>
#include <Logger.h>
#include <DbQueryMsg.h>
#include <DbActiveObject.h>
#include <MmConfigReader.h>
#include <ConfigReader.h>
#include <Utilities.h>
#include <DataUnion.h>
#include <AsnCodec.h>
#include <SubsProfileData.h>
#include <SubsProfilesManager.h>
#include <CtxtCancelLocation.h>
#include <ISDData.h>
#include <MmDbQueries.h>

extern AsnCodec g_AsnCodecO3;
extern AsnCodec g_AsnCodecO2;
extern AsnCodec g_AsnCodecO1;
extern int getPartnerPdpProfId(unsigned int p_PdpProfId, int p_NkId, int p_PartnerNkId);

StandaloneISD::StandaloneISD()
{
   DLOG(0,0,"StandaloneISD::StandaloneISD Cons");   
   m_ssn = 7;
   memset(m_TransId,'\0',sizeof(m_TransId));
   memset(m_Orginator,'\0',sizeof(m_Orginator));
   m_ErrorRcvd = false;
   m_NoticeRcvd = false;
   m_OpenCnfRcvd = false;
   l_Version = index = SsIndex = VcsiIndex = ScsiIndex = 0;
   flag = false;
   l_somethingToSendPresent = l_ssPresent = l_VcsiPresent = l_ScsiPresent = odb_Data = odb_GenData = odb_HplmnData = l_pdpInfoPresent = false;
   odb_Genvalue = odb_HplmnValue = 0;
   l_isdDlgId = 0;
   memset(m_TransId,'\0',sizeof(m_TransId));
   memset(m_Orginator,'\0',sizeof(m_Orginator));
   m_UpdateReqd = false;
   m_FirstFilled = false;
   odb_Data = odb_GenData = odb_Genvalue = odb_HplmnData = odb_HplmnValue = m_Roaming_indicator = 0;
   m_Odb_Rejected_in_ISD_Resp = false;
   m_updateDbCalledFlag = false;
   m_ODBflag = false;
}

StandaloneISD::~StandaloneISD()
{
   DLOG(0, 0, "StandaloneISD::~StandaloneISD Des");
}

bool StandaloneISD::processMessage(Msg *p_MsgPtr,bool &p_DeleteFlag)
{
   DLOG(0, 0, "Start of StandaloneISD::processMsg function Delete flag %d",p_DeleteFlag);
   MapSpecificMsg *l_specMsg = NULL;
   int l_dlgId = 0;
   int l_UserDlgId = 0;

   //EMapOpCode l_OpCode;

   switch (p_MsgPtr->m_MsgType)
   {
      case MSG_TYPE_MAP:
         switch (((MapMsg*) p_MsgPtr)->m_MapMsgType)
         {
            case MAP_MSG_TYPE_COMMON:
               switch (((MapCommonMsg*) p_MsgPtr)->m_MapCommonMsgType)
               {
                  case MAP_CMN_OPEN_IND:
                     {
                        DLOG(0, 0, "MAP_CMN_OPEN_IND received");                        
                     }
                     break;

                  case MAP_CMN_OPEN_CNF:
                     {
                        DLOG(0,0,"MAP Open confirmation Received");
                        MapOpenCnf *l_oCnf = (MapOpenCnf*) p_MsgPtr;
                        if(false == OpenCnf(l_oCnf))
                           return false;
                     }
                     break;

                  case MAP_CMN_DELIMITER_IND:
                     {
                        LLOG(0, 0, "MAP_CMN_DELIMITER_IND received Dialog id %d",((MapMsg*)p_MsgPtr)->m_UserDlgId);
                        if(((MapMsg*)p_MsgPtr)->m_UserDlgId != l_isdDlgId)
                        {
                           WLOG(0,0,"Delimiter Rcvd for not for Current Dlg %d",l_isdDlgId);
                           //return;
                        }
                        else if(m_ErrorRcvd)
                        {
                           DLOG(0,0,"Delimiter rcvd on Call status is ErrorRcvd,sending close");
                           MapCloseReq l_closeReq(((MapMsg*)p_MsgPtr)->m_UserDlgId);
                           g_sc.sendMsg(this, &l_closeReq);
                        }
                        else if(m_NoticeRcvd)
                        {
                           DLOG(0,0,"Call status is Notice Rcvd,returning");
                        }
                        else if(m_OpenCnfRcvd)
                        {
                           WLOG(0,0,"Delimiter for OpenCnf");
                        }
                        else if(m_Odb_Rejected_in_ISD_Resp)
                        {
                           WLOG(0,0,"Rejected ODB service rcvd in ISD resp, sending Pre-Arraged END");
                           MapCloseReq l_closeReq(((MapMsg*)p_MsgPtr)->m_UserDlgId);
                           l_closeReq.m_CloseType = MAP_CLOSE_TYPE_PRE_ARRANGED_END;
                           g_sc.sendMsg(this, &l_closeReq);
                           return true;
                        }
                        else
                        {
                           switch(l_Version)
                           {
                              case 3:
                                 {
                                    LLOG(0,0,"The value returned by ISDData are  ISD Index is %x, VLR CSI Index is %x, SGSN CSI Index is %x, SS Index is %x", index, VcsiIndex, ScsiIndex, SsIndex);
                                    if(index == 0)
                                    {
                                       TLOG(0, 0, "No more ISD to send, Sending Close");
                                       MapCloseReq l_closeReq(((MapMsg*)p_MsgPtr)->m_UserDlgId);
                                       g_sc.sendMsg(this, &l_closeReq);
                                       if(true == m_UpdateReqd)
                                       {
                                          updateDb('S', "");
                                       }
                                       else
                                       {
                                          return true;
                                       }
                                    }
                                    else
                                    {
                                       DLOG(0, 0, "Index value is %x continuing sending remaining ISD", index);
                                       flag = false;
                                       MapSpecificRequest l_request(l_isdDlgId, MAP_OP_CODE_insertSubscriberData, MAP_V3);
                                       DECLARE(OMAP3_InsertSubscriberDataArg,l_isd,3,"OMAP3_InsertSubscriberDataArg",DeclareFunc);

                                       l_isd->bit_mask = 0;
                                       //FillIsdV3(l_isdDlgId,l_isd);
                                       FillIsdV3(l_isd);
                                       if(CheckLengthV3(l_isd) < 5)
                                       {
                                          ELOG(0,0,"Unable to form ISD msg, Check the received data");
                                          m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_UNABLE_TO_INITIATE);
                                          return false;
                                       }
                                       l_request.m_structBuffer = (void*) l_isd;
                                       l_request.m_TimerValue = g_MmConfigReaderObj->m_ISD_Invoke_Timer;
                                       g_sc.sendMsg(this, &l_request);
                                       DLOG(0, 0, "Sending MapDelimiterReq Req");
                                       MapDelimiterReq l_del(l_isdDlgId);
                                       g_sc.sendMsg(this, &l_del);
                                    }
                                 }
                                 break;
                              case 2:
                                 {
                                    LLOG(0,0,"Index value is %x,SS Data Index %x",index,SsIndex);
                                    if(index == 0)
                                    {
                                       LLOG(0, 0, "Processing ISD response success,no more ISD to send, Sending Close");
                                       MapCloseReq l_closeReq(((MapMsg*)p_MsgPtr)->m_UserDlgId);
                                       g_sc.sendMsg(this, &l_closeReq);
                                       if(true == m_UpdateReqd)
                                       {
                                          updateDb('S', "");
                                       }
                                       else
                                       {
                                          return true;
                                       }
                                    }
                                    else
                                    {
                                       DLOG(0,0,"Index value is %x SS_inded %x continuing sending remaining ISD",index,SsIndex);
                                       MapSpecificRequest l_request(l_isdDlgId, MAP_OP_CODE_insertSubscriberData, MAP_V2);
                                       DECLARE(OMAP2_InsertSubscriberDataArg,l_isd,2,"OMAP2_InsertSubscriberDataArg",DeclareFunc);
                                       l_isd->bit_mask = 0;
                                       //FillIsdV2(l_isdDlgId, l_isd);
                                       FillIsdV2(l_isd);
                                       if(CheckLengthV2(l_isd) < 5)
                                       {
                                          ELOG(0,0,"Unable to form ISD msg, Check the received data");
                                          m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_UNABLE_TO_INITIATE);
                                          return false;
                                       }
                                       DLOG(0,0,"After forming isd v2, Index value is %x SS_inded %x",index,SsIndex);
                                       l_request.m_structBuffer = (void*) l_isd;
                                       l_request.m_TimerValue = g_MmConfigReaderObj->m_ISD_Invoke_Timer;
                                       g_sc.sendMsg(this, &l_request);
                                       DLOG(0, 0, "Sending MapDelimiterReq Req");
                                       MapDelimiterReq l_del(l_isdDlgId);
                                       g_sc.sendMsg(this, &l_del);
                                    }
                                 }
                                 break;
                              case 1:
                                 {
                                    LLOG(0,0,"ISD Index is %x SS Index is %x",index,SsIndex);
                                    if(index == 0)
                                    {
                                       DLOG(0,0,"Processing ISD response success,no more ISD to send");
                                       //m_tdr.setBool(TDR_MSGSTATUS_INDEX,true);
                                       MapCloseReq l_closeReq(((MapMsg*)p_MsgPtr)->m_UserDlgId);
                                       g_sc.sendMsg(this, &l_closeReq);
                                       if(true == m_UpdateReqd)
                                       {
                                          updateDb('S', "");
                                       }
                                       else
                                       {
                                          return true;
                                       }
                                    }
                                    else
                                    {
                                       DLOG(0,0,"Index value is %x SS Index %x continuing sending remaining ISD",index,SsIndex);
                                       flag = false;
                                       MapSpecificRequest l_request(l_isdDlgId, MAP_OP_CODE_insertSubscriberData, MAP_V1);
                                       //DECLARE(OMAP1_InsertSubscriberDataArg, l_isd, 1);
                                       DECLARE(OMAP1_InsertSubscriberDataArg,l_isd,1,"OMAP1_InsertSubscriberDataArg",DeclareFunc);
                                       l_isd->bit_mask = 0;
                                       //FillIsdV1(l_isdDlgId, l_isd);
                                       FillIsdV1(l_isd);
                                       if(CheckLengthV1(l_isd) < 5)
                                       {
                                          ELOG(0,0,"Unable to form ISD msg, Check the received data");
                                          m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_UNABLE_TO_INITIATE);
                                          return false;
                                       }
                                       DLOG(0,0,"After ISD V1, index %x, SS Index %x",index,SsIndex);
                                       l_request.m_structBuffer = (void*) l_isd;
                                       l_request.m_TimerValue = g_MmConfigReaderObj->m_ISD_Invoke_Timer;
                                       g_sc.sendMsg(this, &l_request);
                                       DLOG(0, 0, "Sending MapDelimiterReq Req");
                                       MapDelimiterReq l_del(l_isdDlgId);
                                       g_sc.sendMsg(this, &l_del);
                                    }
                                 }
                                 break;
                              default:
                                 {
                                 }                      
                                 break;
                           }
                        }
                     }
                     break;

                  case MAP_CMN_CLOSE_IND:
                     {
                        LLOG(0,0,"MAP_CMN_CLOSE_IND received, The value returned by ISDData are  ISD Index is %x, VLR CSI Index is %x, SGSN CSI Index is %x, SS Index is %x", index, VcsiIndex, ScsiIndex, SsIndex);
                        if(true == m_UpdateReqd)
                        {
                           updateDb('S', "");
                        }
                        return true;
                     }
                     break;

                  case MAP_CMN_U_ABORT_IND:
                     {
                        WLOG(0, 0, "MAP_CMN_U_ABORT_IND received");
                        m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_U_ABORT_RCVD);
                        if(true == m_UpdateReqd)
                        {
                           updateDb('F', "Received U-Abort");
                        }
                     }
                     break;

                  case MAP_CMN_P_ABORT_IND:
                     {
                        WLOG(0, 0, "MAP_CMN_P_ABORT_IND received");
                        m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_P_ABORT_RCVD);
                        if(true == m_UpdateReqd)
                        {
                           updateDb('F', "Received P-Abort");
                        }
                     }
                     break;

                  case MAP_CMN_NOTICE_IND:
                     {
                        WLOG(0, 0, "MAP_CMN_NOTICE_IND received,Sending Close");
                        m_NoticeRcvd = true;
                        MapCloseReq l_closeReq(((MapMsg*)p_MsgPtr)->m_UserDlgId);
                        l_closeReq.m_CloseType = MAP_CLOSE_TYPE_PRE_ARRANGED_END;
                        m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_NOTICE_RCVD);
                        g_sc.sendMsg(this, &l_closeReq);
                        DLOG(0,0,"Checking Update status %d",m_UpdateReqd);
                        if(true == m_UpdateReqd)
                        {
                           updateDb('F', "Received Notice");
                        }
                     }
                     break;

                  default:
                     {
                        CLOG(0, 0, "Unknown Msg received [%d]", ((MapCommonMsg*) p_MsgPtr)->m_MapCommonMsgType);
                     }
                     break;
               }
               break;

            case MAP_MSG_TYPE_SPECIFIC:
               {
                  DLOG(0, 0, "MAP_MSG_TYPE_SPECIFIC received");
                  l_specMsg = (MapSpecificMsg*) p_MsgPtr;
                  l_UserDlgId = l_specMsg->m_UserDlgId;
                  DLOG(0, 0, "MAP_MSG_TYPE_SPECIFIC received dlgId[%d] UserDlgId[%d]",l_dlgId, l_UserDlgId);

                  switch (((MapSpecificMsg*) p_MsgPtr)->m_MapSpecificEventType)
                  {
                     case MAP_SPEC_EVENT_INDICATION:
                        {
                           DLOG(0, 0, "MAP_SPEC_EVENT_INDICATION received");
                           switch (((MapSpecificMsg*) p_MsgPtr)->m_OpCode)
                           {
                              default:
                                 DLOG(0, 0, "Received Unknown Specific Message");
                                 break;
                           }
                           return true;
                        }
                        break;

                     case MAP_SPEC_EVENT_RESULT:
                        {
                           DLOG(0, 0, "MAP_SPEC_EVENT_RESULT received");
                        }
                        break;

                     case MAP_SPEC_EVENT_CONFIRMATION:
                        {
                           DLOG(0, 0, "MAP_SPEC_EVENT_CONFIRMATION received");
                           switch (((MapSpecificMsg*) p_MsgPtr)->m_OpCode)
                           {
                              case MAP_OP_CODE_insertSubscriberData://OpCode = 7
                                 {
                                    //DLOG(0,0,"Insert Subscriber Response verions %d Received",((MapSpecificMsg*)p_MsgPtr)->m_Version);
                                    DLOG(0,0,"Received ISD response of Version %d received for ISD request Version %d sent",((MapSpecificMsg* )p_MsgPtr)->m_Version,l_Version);
                                    switch(l_Version)
                                    {
                                       case 3:
                                          {
                                             if(((MapSpecificMsg*) p_MsgPtr)->m_allocatedFlag)
                                             {
                                                IMAP3_InsertSubscriberDataRes *ISD_Res = (IMAP3_InsertSubscriberDataRes*) (((MapSpecificMsg*) p_MsgPtr)->m_structBuffer);
                                                DLOG(0,0,"The value returned by ISDData are \n ISD Index is %x\n VLR CSI Index is %x\n SGSN CSI Index is %x\n SS Index is %x\n",index,VcsiIndex,ScsiIndex,SsIndex);


                                                if( 
                                                      (ISD_Res->bit_mask & IMAP3_InsertSubscriberDataRes_teleserviceList_present) || 
                                                      (ISD_Res->bit_mask & IMAP3_InsertSubscriberDataRes_bearerServiceList_present) || 
                                                      (ISD_Res->bit_mask & IMAP3_InsertSubscriberDataRes_ss_List_present) ||
                                                      (ISD_Res->bit_mask & IMAP3_odb_GeneralData_present) ||
                                                      (ISD_Res->bit_mask & IMAP3_InsertSubscriberDataRes_regionalSubscriptionResponse_present) 
                                                  )
                                                {
                                                   if(false == m_isd.ProcessIsdResV3(l_UserDlgId,ISD_Res))
                                                   {
                                                      m_tdr.setString(TDR_INDEX_RESRV3,"ODB_REJECTED_IN_ISD_RESP");
                                                      m_tdr.setString(TDR_INDEX_OAM_FREE_FORMAT_DATA,"Converted_To_CL");
                                                      m_Odb_Rejected_in_ISD_Resp = true;
                                                      if(true == m_UpdateReqd)
                                                      {
                                                         updateDb('F', "ODB Rejected");
                                                      }
                                                      return false;
                                                   }                                             
                                                }
                                                else
                                                {
                                                   if(ISD_Res->bit_mask & IMAP3_InsertSubscriberDataRes_supportedCamelPhases_present)
                                                   {
                                                      LLOG(0,0,"ISD Response supportedCamelPhases present");
                                                   }
                                                   if(ISD_Res->bit_mask & IMAP3_InsertSubscriberDataRes_extensionContainer_present)
                                                   {
                                                      LLOG(0,0,"ISD Response extensionContatiner present");
                                                   }
                                                   if(ISD_Res->bit_mask & IMAP3_InsertSubscriberDataRes_offeredCamel4CSIs_present)
                                                   {
                                                      LLOG(0,0,"ISD Response offeredCamel4Csis present");
                                                   }
                                                   return false;
                                                }
                                             }
                                          }
                                          break;
                                       case 2:
                                          {
                                             if(((MapSpecificMsg*)p_MsgPtr)->m_allocatedFlag)
                                             {
                                                IMAP2_InsertSubscriberDataRes *ISD_Res = (IMAP2_InsertSubscriberDataRes*) (((MapSpecificMsg*) p_MsgPtr)->m_structBuffer);
                                                DLOG(0,0,"Index value is %x SS_Index %x Checking on ISD response",index,SsIndex);
                                                if(false == m_isd.ProcessIsdResV2(l_UserDlgId,ISD_Res))
                                                {
                                                   m_tdr.setString(TDR_INDEX_RESRV3,"ODB_REJECTED_IN_ISD_RESP");
                                                   m_tdr.setString(TDR_INDEX_OAM_FREE_FORMAT_DATA,"Converted_To_CL");
                                                   m_Odb_Rejected_in_ISD_Resp = true;
                                                   if(true == m_UpdateReqd)
                                                   {
                                                      updateDb('F', "ODB Rejected");
                                                   }
                                                   return false;
                                                }
                                             }

                                          }
                                          break;
                                       case 1:
                                          {
                                             DLOG(0,0,"ISD Res rcvd");
                                          }
                                          break;
                                       default:
                                          {
                                             DLOG(0,0,"ISD Acknowledge with unknown version of msg received");
                                             return false;
                                          }
                                          break;
                                          break;
                                    }
                                 }
                                 break;

                              default:
                                 DLOG(0,0,"Unrecognised MAP_SPEC_EVENT_CONFIRMATION received");
                                 break;
                           }
                        }
                        break;


                     case MAP_SPEC_EVENT_USER_ERROR:
                        {
                           unsigned short l_errCode = ((MapUserError*)p_MsgPtr)->m_ErrorCode;
                           WLOG(0, 0, "MAP_SPEC_EVENT_USER_ERROR received, Error code %d",l_errCode);
                           m_tdr.setInteger(TDR_INDEX_ERR_CODE,l_errCode);
                           m_ErrorRcvd = true;
                           if(true == m_UpdateReqd)
                           {
                              updateDb('F', "Received USER ERROR");
                           }
                        }
                        break;

                     case MAP_SPEC_EVENT_PROV_ERROR:
                        {
                           DLOG(0, 0, "MAP_SPEC_EVENT_PROV_ERROR received");
                           DLOG(0,0,"Closing the Dialogue");
                           m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_PROVIDER_ERROR_RCVD);
                           m_ErrorRcvd = true;
                           if(true == m_UpdateReqd)
                           {
                              updateDb('F', "Provider Error");
                           }
                        }
                        break;
                     default:
                        WLOG(0, 0, "ERROR!! Default received");
                        break;
                  }
               }
               break;

            default:
               CLOG(0,0,"Unknown MAP msg");
         }
         break;

      case MSG_TYPE_DB:
         {
            DLOG(0, 0, "DB message received");
            UpdateDBStatus *l_UDS = (UpdateDBStatus *)p_MsgPtr;
            if(l_UDS->m_ErrorCode_OAM != 0)
            {
               m_tdr.setInteger(TDR_INDEX_DB_ERR_CODE,l_UDS->m_ErrorCode_OAM); 
               m_tdr.setString(TDR_INDEX_DB_ERR_DESC,(char *)l_UDS->m_ErrorMsg_OAM);
            }
            if(l_UDS->m_DbQueryRes == DB_QUERY_RES_SUCCESS)
            {
               LLOG(0,0,"Update record successfully");
            }
            else
            {
               WLOG(0,0,"Error updating record into DB");
            }
         }
         break;

      default:
         CLOG(0, 0, "Unknown message received");
         break;
   }
   return true;
}

bool StandaloneISD::startProcessing(InterModuleData *p_imd,bool &p_DeleteFlag)
{
   DLOG(0,0,"Received indication to Start ISD, Delete flag %d",p_DeleteFlag);
   m_UpdateReqd = false;
   bool l_checkForCl = false;
   memset(m_Orginator,'\0',sizeof(m_Orginator));
   strcpy(m_Orginator,p_imd->m_OriginatorModule);  
   LLOG(1,0,"Msg Recv from [%s] Msg Rcvd [%s]", p_imd->m_OriginatorModule, (NULL == p_imd->m_Parameters)?"":p_imd->m_Parameters);

   if(NULL == p_imd->m_Parameters)
   {
      CLOG(0,0,"p_imd->m_Parameters NULL returning");
      return false;
   }

   if(strncmp(m_Orginator,"OAM",3) == 0)
   {
      DLOG(0,0,"Orginator module is OAM, getting transaction ID");
      char *l_check = NULL;
      l_check = strchr(p_imd->m_Parameters, ':');
      l_checkForCl = true;
      if(l_check == NULL)
      {
         WLOG(0,0,"Transaction ID not present");
         //m_DataString.assign(&p_imd->m_Parameters[0]);
         m_DataString.assign(p_imd->m_Parameters);
         m_UpdateReqd = false;
      }
      else
      {
         char l_transIdChar[20];
         memset(l_transIdChar, '\0', 20);
         strncpy(l_transIdChar, p_imd->m_Parameters, 20);
         strncpy(m_TransId,p_imd->m_Parameters,strlen(p_imd->m_Parameters)-strlen(l_check));
         LLOG(0,0,"Transaction ID :%s received from OAM", m_TransId);
         m_UpdateReqd = true; 
         //m_DataString.assign(&p_imd->m_Parameters[strlen(p_imd->m_Parameters)-strlen(l_check)]);
         //m_DataString.assign(p_imd->m_Parameters[strlen(p_imd->m_Parameters)-strlen(l_check)]);
         m_DataString.assign(&p_imd->m_Parameters[strlen(p_imd->m_Parameters)-strlen(l_check)]);
         //m_DataString.assign(p_imd->m_Parameters[strlen(p_imd->m_Parameters)-strlen(l_check)]);
         DLOG(0,0,"m_DataString 1 [%s]",(char*)m_DataString.c_str());
         m_tdr.setString(TDR_INDEX_OAM_TRANSACTION_ID, m_TransId);
      }
   }

   else if(strncmp(m_Orginator,"SSM",3) == 0)
   {
      DLOG(0,0,"Orginator module is SSM");
      //m_DataString.assign(&p_imd->m_Parameters[0]);
      m_DataString.assign(p_imd->m_Parameters);
      m_UpdateReqd = false;
      l_checkForCl = false;
   }
   else
   {
      WLOG(0,0,"Unrecognizable Orinator module %s, returning false",m_Orginator);
      m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_UNABLE_TO_INITIATE);
      return false;
   }
   //DecodeReq();

   l_imsi = ConfigReader::readValue(m_DataString, "IMSI");
   if(0 == l_imsi.length())
   {
      WLOG(0,0,"Unknown IMSI");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_UNABLE_TO_INITIATE);
      return false;
   }

   DLOG(0,0,"IMSI [%s]", l_imsi.c_str());   
   m_tdr.setChar(TDR_INDEX_REQUEST_TYPE,'I'); // 1-msisdn 2-imsi 3-both
   m_tdr.setString(TDR_INDEX_REQUEST_IMSI,(s8*)l_imsi.c_str());
   setTraceImsi((char *)l_imsi.c_str());


   l_lmsi = ConfigReader::readValue(m_DataString, "LMSI");
   if(0 == l_lmsi.length())
   {
      TLOG(0,0,"LMSI not present");
   }
   else
   {
      TLOG(0,0,"LMSI is %s",l_lmsi.c_str());
   }

   l_NodeType = ConfigReader::readValue(m_DataString, "TYPE");
   if(0 == l_NodeType.length())
   {
      WLOG(0,0,"Unknown Type");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_UNABLE_TO_INITIATE);
      return false;
   }
   DLOG(0,0,"Destination node type %s",l_NodeType.c_str());



   if(l_NodeType.compare("GSM") == 0)
   {
      m_ssn = 7;
   }
   else if(l_NodeType.compare("GPRS") == 0)
   {
      m_ssn =  149;
      if(g_MmConfigReaderObj->m_Version < 3)
      {
         CLOG(0,0,"Configured ISD version %d, and received msg type GPRS",g_MmConfigReaderObj->m_Version);
         //return false;
      }
   }
   else
   {
      CLOG(0,0,"Unrecognized Node Type %s",l_NodeType.c_str());
      m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_UNABLE_TO_INITIATE);
      return false;
   }

   m_tdr.setRemoteAddrSsn(m_ssn);

   //
   //Added in 1.0.8.0 for sending ALL_OG_CALLS_BARRED when OG_CALLS_BARRED_WHEN_ROAMING set and subsriber is in roaming
   //
   string l_RoamInd = ConfigReader::readValue(m_DataString, "ROAMING_INDICATOR");
   if(0 == l_RoamInd.length())
   {
      WLOG(0,0," ROAMING_INDICATOR not received, assuming home");
      m_Roaming_indicator = 0;
   }
   else
   {
      m_Roaming_indicator = atoi(l_RoamInd.c_str());
      TLOG(0,0," ROAMING_INDICATOR [%d]",m_Roaming_indicator);
   }
   //
   //End Added in 1.0.8.0
   //

   l_destAddress = ConfigReader::readValue(m_DataString, "DEST_ADDRESS");
   if(1 > l_destAddress.length())
   {
      WLOG(0,0,"Unknown DEST_ADDRESS");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_UNABLE_TO_INITIATE);
      return false;
   }
   //m_tdr.setCallingAddr((s8*)l_destAddress.c_str());
   m_tdr.setRemoteAddr((s8 *)l_destAddress.c_str());


   l_origAddress = ConfigReader::readValue(m_DataString, "ORIG_ADDRESS");
   if(1 > l_origAddress.length())
   {
      WLOG(0,0,"Unknown ORIG_ADDRESS");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_UNABLE_TO_INITIATE);
      return false;
   }
   m_tdr.setString(TDR_INDEX_LOCAL_ADDRESS,(s8 *)l_origAddress.c_str()); 
   l_somethingToSendPresent = false;
   l_ssPresent = false;
   l_VcsiPresent = false;
   l_ScsiPresent = false;

   // 
   // Uncommented in 1.0.11.0 - for MSISDN change notification
   //
   l_msisdn = ConfigReader::readValue(m_DataString, "MSISDN");
   if(l_msisdn.length() > 0)
   {
      LLOG(0,0,"MSISDN is [%s]",l_msisdn.c_str());
      l_somethingToSendPresent = true;
      l_checkForCl = false;
   }

   l_mscNumber = ConfigReader::readValue(m_DataString, "MSC_NUMBER");
   if(l_mscNumber.length() > 0)
   {
      LLOG(0,0,"MSC_NUMBER is [%s]",l_mscNumber.c_str());
   }

   // 1.0.11.0

   //
   string l_network_id = ConfigReader::readValue(m_DataString,"NETWORK_ID");
   if(l_network_id.length() > 0)
   {
      TLOG(0,0,"NetworkId[%s] present in xml",l_network_id.c_str());
      m_tdr.setString(TDR_INDEX_MM_NETWORK_ID,(char *)l_network_id.c_str());
   }

   l_bearerService = ConfigReader::readValue(m_DataString, "BEARER_SERVICE_LIST");
   if(l_bearerService.length() > 0)
   {
      DLOG(0,0,"Bearer Service Codes [%s]", l_bearerService.c_str());
      l_somethingToSendPresent = true;
      l_checkForCl = true;
   }

   l_teleService = ConfigReader::readValue(m_DataString, "TELE_SERVICE_LIST");
   if(l_teleService.length() > 0)
   {
      DLOG(0,0,"Tele Service Codes [%s]", l_teleService.c_str());
      l_somethingToSendPresent = true;
      l_checkForCl = true;
   }
   bool l_SendClForCsi = false;
   l_vcsi = ConfigReader::readValue(m_DataString, "VLR_CSI");
   if((l_vcsi.length() > 0)&& (g_MmConfigReaderObj->m_Version == 3))
   {
      DLOG(0,0,"VLR_CSI: [%s]",l_vcsi.c_str());
      l_somethingToSendPresent = true;
      l_VcsiPresent = true;
      l_checkForCl = true;
      l_SendClForCsi = true;
   }
   else
   {
      TLOG(0,0,"Configured ISD version is %d or Length of data received is %d, not reading the VLR CSI info received in the XML request",g_MmConfigReaderObj->m_Version,l_vcsi.length());
      l_VcsiPresent = false;
   }


   l_scsi = ConfigReader::readValue(m_DataString, "SGSN_CSI");
   if((l_scsi.length() > 0)&& (g_MmConfigReaderObj->m_Version == 3))
   {
      DLOG(0,0,"SGSN_CSI [%s]",l_scsi.c_str());
      l_somethingToSendPresent = true;
      l_ScsiPresent = true;
      l_checkForCl = true;
      l_SendClForCsi = true;
   }
   else
   {
      l_ScsiPresent = false;
   }

   l_ODB = ConfigReader::readValue(m_DataString,"ODB");
   if(l_ODB.length() > 0)
   {
      DLOG(0,0,"ODB Data [%s] len [%d]",l_ODB.c_str(),l_ODB.length());
      l_somethingToSendPresent = true;
      l_checkForCl = false;
   }

   string l_ODBflag = ConfigReader::readValue(l_ODB,"GEN_DATA");
   if(l_ODBflag.length() > 0)
   {
      TLOG(0,0,"ODB LENGTH PRESENT");
      m_ODBflag = true;
   }

   l_ssList = ConfigReader::readValue(m_DataString, "SS_LIST");
   if(l_ssList.length() > 0)
   {
      DLOG(0,0,"SS DATA [%s]", l_ssList.c_str());
      l_somethingToSendPresent = true;
      l_ssPresent = true;
      l_checkForCl = false;
   }
   else
   {
      l_ssPresent = false;
   }

   // m_DataString += "<PDP_INFO><NW_ID>21</NW_ID><PART_NW_ID>441</PART_NW_ID><PDP_PROF_ID>341</PDP_PROF_ID></PDP_INFO>";
   l_pdpDetails = ConfigReader::readValue(m_DataString, "PDP_INFO");
   if(l_pdpDetails.length() > 0)
   {
      DLOG(0,0," PDP DATA [%s]", l_pdpDetails.c_str());
      DLOG(0,0,"PDP Details[%s]",(char*)l_pdpDetails.c_str());
      string l_val1 = ConfigReader::readValue(l_pdpDetails,"NW_ID");
      int l_NwId = atoi(l_val1.c_str());
      if(l_val1.length() > 0)
      {
         m_isd.gprssi.m_NwId = atoi(l_val1.c_str());
         DLOG(0,0,"PDP_INFO NW Id %d",m_isd.gprssi.m_NwId);
      }
      else
      {
         LLOG(0,0,"No NW id present in PDP_INFO");
      }
      l_val1.clear();
      l_val1 = ConfigReader::readValue(l_pdpDetails,"PART_NW_ID");
      int l_PartNwId = atoi(l_val1.c_str());
      if(l_val1.length() > 0)
      {
         m_isd.gprssi.m_PNwId = atoi(l_val1.c_str());
         DLOG(0,0,"PDP_INFO Partner NW Id %d",m_isd.gprssi.m_PNwId);
      }
      else
      {
         LLOG(0,0,"No Partner NW id present in PDP_INFO");
      }
      l_val1.clear();
//5055
      l_val1 = ConfigReader::readValue(l_pdpDetails,"PDP_PROF_ID");
      int l_PdpProfId = atoi(l_val1.c_str());
      if(l_val1.length() > 0)
      {
         m_isd.gprssi.PdpId = atoi(l_val1.c_str());
         DLOG(0,0,"PDP_INFO profile id %d",atoi(l_val1.c_str()));
         l_somethingToSendPresent = true;
//5055
         if(0 == l_PartNwId)
         {
            TLOG(0,0,"Partner NetworkId is 0, not checking for a mapped Pdp Profile");
         }
         else
         {
            TLOG(0,0,"Partner Network Id is not 0, checking for mapped partnerPDPProfId");
            int l_PartnerPdpProfId = getPartnerPdpProfId(l_PdpProfId,l_NwId,l_PartNwId);
            if(0 != l_PartnerPdpProfId)
            {
               LLOG(0,0,"Partner PDP Profile found[%d]", l_PartnerPdpProfId);
               m_isd.gprssi.PdpId = l_PartnerPdpProfId;
            }
            else
            {
               WLOG(0,0,"Partner PDP not found, using [%d]",m_isd.gprssi.PdpId);
            }
         }
//5055         
         l_val1.clear();
         l_val1 = ConfigReader::readValue(l_pdpDetails,"CONTEXT_LIST");
         if(l_val1.length() > 0)
         {
            DLOG(0,0,"CONTEXT_LIST %s",l_val1.c_str());
            m_isd.gprssi.m_contextList = l_val1;
         }
         else
         {
            LLOG(0,0,"No CONTEXT LIST present in PDP_INFO");
         }

         l_val1.clear();
         l_val1 = ConfigReader::readValue(l_pdpDetails,"PDP_FLAG");
         if(l_val1.length() > 0)
         {
            DLOG(0,0,"FLAG %s",l_val1.c_str());
            if(('I' == l_val1.c_str()[0]) || ('M' == l_val1.c_str()[0]))
            {
               m_isd.gprssi.m_completeDataListIncluded = false;
            }
         }
         else
         {
            LLOG(0,0,"No FLAG present in PDP_INFO");
         }
      }
      else
      {
         LLOG(0,0,"No PDP Profile id present in PDP_INFO");
      }
      l_checkForCl = false;
   }
//5055
   string l_val = ConfigReader::readValue(m_DataString,"IPV4_ADDR");
   if(l_val.length() > 0)
   {
      m_isd.gprssi.m_IPv4Addr = l_val;
      DLOG(0,0,"IPV4_ADDR[%s] from ISD XML",m_isd.gprssi.m_IPv4Addr.c_str());
   }
   else
   {
      LLOG(0,0,"No IPV4_ADDR present in ISD XML");
   }
//5050
   if(l_somethingToSendPresent == false)
   {
      if(true == m_UpdateReqd)
      {
         updateDb('F', "No meaningful data present");
      }
      m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_UNABLE_TO_INITIATE);
      return false;
   }
   if(l_checkForCl)
   {
      LLOG(0,0,"Checking Send_CL Flag [%d] Send CL instead of CSI [%d]",g_MmConfigReaderObj->m_SendCl,l_SendClForCsi);
      if((g_MmConfigReaderObj->m_SendCl) || (l_SendClForCsi))
      {
         char XmlReq[501];
         memset(XmlReq,'\0',sizeof(XmlReq));
         u8 lmsi[9];
         memset(lmsi,'\0',sizeof(lmsi));
         if(l_lmsi.length() > 0)
            strcpy((char *)lmsi,(char *)l_lmsi.c_str());
         if(m_UpdateReqd)
            snprintf(XmlReq,sizeof(XmlReq),"%s:",m_TransId);
         LLOG(0, 0, "Initiating cancel location to previous VLR %s with HLR address %s for IMSI %s and LMSI %s",l_destAddress.c_str(),l_origAddress.c_str(), l_imsi.c_str(), lmsi);
         if(m_ssn == 7)
         {
            FormXMLRequest(XmlReq,1, (u8 *)l_imsi.c_str(), lmsi,(u8 *) l_origAddress.c_str(),(u8 *) l_destAddress.c_str(),1,0,"ISD_CONVERTED_TO_CL", (s8*)l_mscNumber.c_str());
         }
         else
         {
            FormXMLRequest(XmlReq,2, (u8 *)l_imsi.c_str(), lmsi,(u8 *) l_origAddress.c_str(),(u8 *) l_destAddress.c_str(),1,0,"ISD_CONVERTED_TO_CL", (s8*)l_mscNumber.c_str());
         }
         DLOG(0, 0, "Sending XmlReq %s to CtxtCancelLocation", XmlReq);
         g_sc.initiateIndependentContext(this, MAP_OP_CODE_cancelLocation, (char *) XmlReq, INITIATION_TYPE_IMMEDIATE);
         /*   if(true == m_UpdateReqd)
              {
              updateDb('S', "ISD Withdrawn to CL");
              }*/
         m_tdr.setString(TDR_INDEX_OAM_FREE_FORMAT_DATA,"Converted_To_CL");
         return false;
      }
   }

   if(true == l_somethingToSendPresent)
   {
      DLOG(0,0,"Parsing ISD XML Request");
      //CFWD
      m_isd.pss.cfuSsCount = 0;       m_isd.pss.cfuSsCode = 0;
      m_isd.pss.cdSsCount = 0;        m_isd.pss.cdSsCode = 0;
      m_isd.pss.cfbSsCount = 0;       m_isd.pss.cfbSsCode = 0;
      m_isd.pss.cfnrySsCount = 0;     m_isd.pss.cfnrySsCode = 0;
      m_isd.pss.cfnrcSsCount = 0;     m_isd.pss.cfnrcSsCode = 0;
      //CB
      m_isd.pss.boacCount = 0;      m_isd.pss.boacSsCode = 0;
      m_isd.pss.boicCount = 0;      m_isd.pss.boicSsCode = 0;
      m_isd.pss.boihcCount = 0;     m_isd.pss.boihcSsCode = 0;
      m_isd.pss.baicCount = 0;      m_isd.pss.baicSsCode = 0;
      m_isd.pss.bicrCount = 0;      m_isd.pss.bicrSsCode = 0;
      //SS DATA
      m_isd.pss.m_GenSsCount = 0;
      m_isd.pss.SsCount = 0;
      //EMLPP
      m_isd.pss.ESsCode = 0;
      m_isd.pss.EDefaultPriority = 0;m_isd.pss.EDefaultPriority = 0; m_isd.pss.EMaxPriority = 0;
      //MC_SS_Info
      m_isd.pss.mcSsCode = 0;
      m_isd.pss.MCSsStatus = 0; m_isd.pss.NBR_SB = 0; m_isd.pss.NBR_USER  = 0;
      if(true == l_ssPresent)
      {
         DLOG(0,0,"SS Related info present");
         //
         //Added in 1.0.8.0
         //
         unsigned int l_inf_gen_odb = atol(ConfigReader::readValue(l_ssList, "INF_GEN_ODB").c_str());
         DLOG(0,0,"ODB Info in SS list: GenODB [%ld]",l_inf_gen_odb);
         if((l_inf_gen_odb & ALL_OG_CALLS_BARRED) || ((m_Roaming_indicator > 0) && (l_inf_gen_odb & OG_CALLS_BARRED_WHEN_ROAMING)))
         {
            DLOG(0,0,"Setting All OG calls barred present flag");
            m_isd.pss.m_AllOGCallsBarresPresent = true;
         }
         //
         // End Added in 1.0.8.0
         //

         char l_val[10];
         memset(l_val, '\0', 10);
         for(int i = 1; i <= 20; i++)
         {
            sprintf(l_val, "VAL_%02d", i);
            DLOG(0,0,"Inside SS Data for tag %s",l_val);
            string l_valueChar = ConfigReader::readValue(l_ssList, l_val);
            char l_SStype[6];
            memset(l_SStype, '\0', sizeof(l_SStype));
            string l_type = ConfigReader::readValue(l_valueChar, "SS_TYPE");
            if(l_type.length() > 0)
            {
               strcpy(l_SStype,l_type.c_str());
               DLOG(0,0,"SS Type is %s",l_SStype);
               //CFWD

               if(l_SStype[0] == '1')
               {
                  char l_CFWD[150];
                  memset(l_CFWD, '\0', 150);
                  string l_ssData = ConfigReader::readValue(l_valueChar, "SS_DATA");
                  strncpy(l_CFWD, "|", 1);
                  strncat(l_CFWD, l_ssData.c_str(), strlen(l_ssData.c_str()));
                  strncat(l_CFWD, "|", 1);
                  //DLOG(0,0,"String received is %s\n", l_CFWD);
                  char str5[10][21];
                  memset(str5, '\0', 210);
                  {
                     char *ptr1, *ptr2;
                     ptr1 = ptr2 = l_CFWD;
                     ptr2++;
                     int a = 1;
                     while(*ptr2 != '\0')
                     {
                        if('|' == *ptr2)
                        {
                           //DLOG(0,0,"Found |\n");
                           if(ptr2 - ptr1 == 1)
                           {
                              strcpy(str5[a], "|0");
                              //DLOG(0,0,"str[%d]:%s\n",i,str5[i]);
                           }
                           else
                           {
                              //strncpy(str,ptr1,ptr2-ptr1);
                              strncpy(str5[a], ptr1, ptr2 - ptr1);
                              str5[a][ptr2 - ptr1] = '\0';
                              //DLOG(0,0,"str5[%d]:%s\n",i,str5[i]+1);
                           }
                           ptr1 = ptr2;
                           a++;
                        }

                        ptr2++;
                     }
                  }
                  //CFWD Unconditional DATA
                  if(atoi(str5[1] + 1) == 33)
                  {
                     m_isd.pss.cfuSsCode = 33;
                     m_isd.pss.cfuSsStatus[m_isd.pss.cfuSsCount] = atoi(str5[2] + 1);
                     m_isd.pss.cfuBCode[m_isd.pss.cfuSsCount] = atoi(str5[3] + 1);
                     m_isd.pss.cfuBType[m_isd.pss.cfuSsCount] = atoi(str5[4] + 1);
                     strncpy((char *) m_isd.pss.cfuFTN[m_isd.pss.cfuSsCount], str5[5] + 1, strlen(str5[5]));
                     strncpy((char *) m_isd.pss.cfuFTS[m_isd.pss.cfuSsCount], str5[6] + 1, strlen(str5[6]));
                     m_isd.pss.cfuOPTN[m_isd.pss.cfuSsCount] = atoi(str5[7] + 1);
                     m_isd.pss.cfuNRT[m_isd.pss.cfuSsCount] = atoi(str5[8] + 1);
                     strncpy((char *) m_isd.pss.cfuLFTN[m_isd.pss.cfuSsCount], str5[9] + 1, strlen(str5[9]));
                     //DLOG(0,0,"All Unconditional forwarding SS Count = %d\n",m_isd.pss.cfuSsCount);
                     DLOG(0, 0, "Call FWD Unconditional :- SSCODE[%d] = %d, SS_Status[%d] = %d, Basic Service Code[%d] = %d,Basic Service Type[%d] = %d, Fwd_To_Number[%d] = %s,Fwd_To_SubAddr[%d] = %s, Fwd_Optn[%d] = %d, No_Reply_Time[%d] = %d, Long_FTN[%d] = %s",
                           m_isd.pss.cfuSsCount, m_isd.pss.cfuSsCode, m_isd.pss.cfuSsCount, m_isd.pss.cfuSsStatus[m_isd.pss.cfuSsCount], m_isd.pss.cfuSsCount, m_isd.pss.cfuBCode[m_isd.pss.cfuSsCount], m_isd.pss.cfuSsCount, m_isd.pss.cfuBType[m_isd.pss.cfuSsCount], m_isd.pss.cfuSsCount, m_isd.pss.cfuFTN[m_isd.pss.cfuSsCount], m_isd.pss.cfuSsCount, m_isd.pss.cfuFTS[m_isd.pss.cfuSsCount], m_isd.pss.cfuSsCount, m_isd.pss.cfuOPTN[m_isd.pss.cfuSsCount], m_isd.pss.cfuSsCount, m_isd.pss.cfuNRT[m_isd.pss.cfuSsCount], m_isd.pss.cfuSsCount, m_isd.pss.cfuLFTN[m_isd.pss.cfuSsCount]);
                     m_isd.pss.cfuSsCount += 1;
                     DLOG(0, 0, "SS COUNT %d",m_isd.pss.cfuSsCount);
                  }
                  //Call Deflection
                  if(atoi(str5[1] + 1) == 36)
                  {
                     m_isd.pss.cdSsCode = 36;
                     m_isd.pss.cdSsStatus[m_isd.pss.cdSsCount] = atoi(str5[2] + 1);
                     m_isd.pss.cdBCode[m_isd.pss.cdSsCount] = atoi(str5[3] + 1);
                     m_isd.pss.cdBType[m_isd.pss.cdSsCount] = atoi(str5[4] + 1);
                     strncpy((char *) m_isd.pss.cdFTN[m_isd.pss.cdSsCount], str5[5] + 1, strlen(str5[5]));
                     strncpy((char *) m_isd.pss.cdFTS[m_isd.pss.cdSsCount], str5[6] + 1, strlen(str5[6]));
                     m_isd.pss.cdOPTN[m_isd.pss.cdSsCount] = atoi(str5[7] + 1);
                     m_isd.pss.cdNRT[m_isd.pss.cdSsCount] = atoi(str5[8] + 1);
                     strncpy((char *) m_isd.pss.cdLFTN[m_isd.pss.cdSsCount], str5[9] + 1, strlen(str5[9]));
                     //DLOG(0,0,"Call Deflection Count = %d\n",m_isd.pss.cdSsCount);
                     DLOG(0, 0, "Call Deflection :- SSCODE[%d] = %d, SS_Status[%d] = %d, Basic Service Code[%d] = %d,Basic Service Type[%d] = %d, Fwd_To_Number[%d] = %s,Fwd_To_SubAddr[%d] = %s Fwd_Optn[%d] = %d, No_Reply_Time[%d] = %d, Long_FTN[%d] = %s",
                           m_isd.pss.cdSsCount, m_isd.pss.cdSsCode, m_isd.pss.cdSsCount, m_isd.pss.cdSsStatus[m_isd.pss.cdSsCount], m_isd.pss.cdSsCount, m_isd.pss.cdBCode[m_isd.pss.cdSsCount], m_isd.pss.cdSsCount, m_isd.pss.cdBType[m_isd.pss.cdSsCount], m_isd.pss.cdSsCount, m_isd.pss.cdFTN[m_isd.pss.cdSsCount], m_isd.pss.cdSsCount, m_isd.pss.cdFTS[m_isd.pss.cdSsCount], m_isd.pss.cdSsCount, m_isd.pss.cdOPTN[m_isd.pss.cdSsCount], m_isd.pss.cdSsCount, m_isd.pss.cdNRT[m_isd.pss.cdSsCount], m_isd.pss.cdSsCount, m_isd.pss.cdLFTN[m_isd.pss.cdSsCount]);
                     m_isd.pss.cdSsCount += 1;
                  }
                  //call forwarding on mobile subscriber busy
                  if(atoi(str5[1] + 1) == 41)
                  {
                     m_isd.pss.cfbSsCode = 41;
                     m_isd.pss.cfbSsStatus[m_isd.pss.cfbSsCount] = atoi(str5[2] + 1);
                     m_isd.pss.cfbBCode[m_isd.pss.cfbSsCount] = atoi(str5[3] + 1);
                     m_isd.pss.cfbBType[m_isd.pss.cfbSsCount] = atoi(str5[4] + 1);
                     strncpy((char *) m_isd.pss.cfbFTN[m_isd.pss.cfbSsCount], str5[5] + 1, strlen(str5[5]));
                     strncpy((char *) m_isd.pss.cfbFTS[m_isd.pss.cfbSsCount], str5[6] + 1, strlen(str5[6]));
                     m_isd.pss.cfbOPTN[m_isd.pss.cfbSsCount] = atoi(str5[7] + 1);
                     m_isd.pss.cfbNRT[m_isd.pss.cfbSsCount] = atoi(str5[8] + 1);
                     strncpy((char *) m_isd.pss.cfbLFTN[m_isd.pss.cfbSsCount], str5[9] + 1, strlen(str5[9]));
                     //DLOG(0,0,"Call Fwd on Busy count = %d\n",m_isd.pss.cfbSsCount);
                     DLOG(0, 0, "Call FWD Busy :- SSCODE[%d] = %d, SS_Status[%d] = %d, Basic Service Code[%d] = %d,Basic Service Type[%d] = %d, Fwd_To_Number[%d] = %s,Fwd_To_SubAddr[%d] = %s Fwd_Optn[%d] = %d, No_Reply_Time[%d] = %d, Long_FTN[%d] = %s",
                           m_isd.pss.cfbSsCount, m_isd.pss.cfbSsCode, m_isd.pss.cfbSsCount, m_isd.pss.cfbSsStatus[m_isd.pss.cfbSsCount], m_isd.pss.cfbSsCount, m_isd.pss.cfbBCode[m_isd.pss.cfbSsCount], m_isd.pss.cfbSsCount, m_isd.pss.cfbBType[m_isd.pss.cfbSsCount], m_isd.pss.cfbSsCount, m_isd.pss.cfbFTN[m_isd.pss.cfbSsCount], m_isd.pss.cfbSsCount, m_isd.pss.cfbFTS[m_isd.pss.cfbSsCount], m_isd.pss.cfbSsCount, m_isd.pss.cfbOPTN[m_isd.pss.cfbSsCount], m_isd.pss.cfbSsCount, m_isd.pss.cfbNRT[m_isd.pss.cfbSsCount], m_isd.pss.cfbSsCount, m_isd.pss.cfbLFTN[m_isd.pss.cfbSsCount]);
                     m_isd.pss.cfbSsCount += 1;
                  }
                  //call forwarding on no reply
                  if(atoi(str5[1] + 1) == 42)
                  {
                     m_isd.pss.cfnrySsCode = 42;
                     m_isd.pss.cfnrySsStatus[m_isd.pss.cfnrySsCount] = atoi(str5[2] + 1);
                     m_isd.pss.cfnryBCode[m_isd.pss.cfnrySsCount] = atoi(str5[3] + 1);
                     m_isd.pss.cfnryBType[m_isd.pss.cfnrySsCount] = atoi(str5[4] + 1);
                     strncpy((char *) m_isd.pss.cfnryFTN[m_isd.pss.cfnrySsCount], str5[5] + 1, strlen(str5[5]));
                     strncpy((char *) m_isd.pss.cfnryFTS[m_isd.pss.cfnrySsCount], str5[6] + 1, strlen(str5[6]));
                     m_isd.pss.cfnryOPTN[m_isd.pss.cfnrySsCount] = atoi(str5[7] + 1);
                     m_isd.pss.cfnryNRT[m_isd.pss.cfnrySsCount] = atoi(str5[8] + 1);
                     strncpy((char *) m_isd.pss.cfnryLFTN[m_isd.pss.cfnrySsCount], str5[9] + 1, strlen(str5[9]));
                     if((m_isd.pss.cfnrySsStatus[m_isd.pss.cfnrySsCount] > 4) && ((m_isd.pss.cfnryNRT[m_isd.pss.cfnrySsCount] == 0)))
                     {
                        ELOG(0,0,"Error: CFNRY is not given with No reply timer");
                        m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_UNABLE_TO_INITIATE);
                        return false;
                     }
                     //DLOG(0,0,"Call Fwd on no Reply Count = %d\n",m_isd.pss.cfnrySsCount);
                     DLOG(0, 0, "Call FWD No Reply :- SSCODE[%d] = %d, SS_Status[%d] = %d, Basic Service Code[%d] = %d,Basic Service Type[%d] = %d, Fwd_To_Number[%d] = %s,Fwd_To_SubAddr[%d] = %s Fwd_Optn[%d] = %d, No_Reply_Time[%d] = %d, Long_FTN[%d] = %s",
                           m_isd.pss.cfnrySsCount, m_isd.pss.cfnrySsCode, m_isd.pss.cfnrySsCount, m_isd.pss.cfnrySsStatus[m_isd.pss.cfnrySsCount], m_isd.pss.cfnrySsCount, m_isd.pss.cfnryBCode[m_isd.pss.cfnrySsCount], m_isd.pss.cfnrySsCount, m_isd.pss.cfnryBType[m_isd.pss.cfnrySsCount], m_isd.pss.cfnrySsCount, m_isd.pss.cfnryFTN[m_isd.pss.cfnrySsCount], m_isd.pss.cfnrySsCount, m_isd.pss.cfnryFTS[m_isd.pss.cfnrySsCount], m_isd.pss.cfnrySsCount, m_isd.pss.cfnryOPTN[m_isd.pss.cfnrySsCount], m_isd.pss.cfnrySsCount, m_isd.pss.cfnryNRT[m_isd.pss.cfnrySsCount], m_isd.pss.cfnrySsCount, m_isd.pss.cfnryLFTN[m_isd.pss.cfnrySsCount]);
                     m_isd.pss.cfnrySsCount += 1;
                  }
                  //call forwarding on mobile subscriber not reachable
                  if(atoi(str5[1] + 1) == 43)
                  {
                     m_isd.pss.cfnrcSsCode = 43;
                     m_isd.pss.cfnrcSsStatus[m_isd.pss.cfnrcSsCount] = atoi(str5[2] + 1);
                     m_isd.pss.cfnrcBCode[m_isd.pss.cfnrcSsCount] = atoi(str5[3] + 1);
                     m_isd.pss.cfnrcBType[m_isd.pss.cfnrcSsCount] = atoi(str5[4] + 1);
                     strncpy((char *) m_isd.pss.cfnrcFTN[m_isd.pss.cfnrcSsCount], str5[5] + 1, strlen(str5[5]));
                     strncpy((char *) m_isd.pss.cfnrcFTS[m_isd.pss.cfnrcSsCount], str5[6] + 1, strlen(str5[6]));
                     m_isd.pss.cfnrcOPTN[m_isd.pss.cfnrcSsCount] = atoi(str5[7] + 1);
                     m_isd.pss.cfnrcNRT[m_isd.pss.cfnrcSsCount] = atoi(str5[8] + 1);
                     strncpy((char *) m_isd.pss.cfnrcLFTN[m_isd.pss.cfnrcSsCount], str5[9] + 1, strlen(str5[9]));
                     //DLOG(0,0,"Call FWD on not rechable Count = %d\n",m_isd.pss.cfnrcSsCount);
                     DLOG(0, 0, "Call FWD NRC :- SSCODE[%d] = %d, SS_Status[%d] = %d, Basic Service Code[%d] = %d,Basic Service Type[%d] = %d, Fwd_To_Number[%d] = %s,Fwd_To_SubAddr[%d] = %s Fwd_Optn[%d] = %d, No_Reply_Time[%d] = %d, Long_FTN[%d] = %s",
                           m_isd.pss.cfnrcSsCount, m_isd.pss.cfnrcSsCode, m_isd.pss.cfnrcSsCount, m_isd.pss.cfnrcSsStatus[m_isd.pss.cfnrcSsCount], m_isd.pss.cfnrcSsCount, m_isd.pss.cfnrcBCode[m_isd.pss.cfnrcSsCount], m_isd.pss.cfnrcSsCount, m_isd.pss.cfnrcBType[m_isd.pss.cfnrcSsCount], m_isd.pss.cfnrcSsCount, m_isd.pss.cfnrcFTN[m_isd.pss.cfnrcSsCount], m_isd.pss.cfnrcSsCount, m_isd.pss.cfnrcFTS[m_isd.pss.cfnrcSsCount], m_isd.pss.cfnrcSsCount, m_isd.pss.cfnrcOPTN[m_isd.pss.cfnrcSsCount], m_isd.pss.cfnrcSsCount, m_isd.pss.cfnrcNRT[m_isd.pss.cfnrcSsCount], m_isd.pss.cfnrcSsCount, m_isd.pss.cfnrcLFTN[m_isd.pss.cfnrcSsCount]);
                     m_isd.pss.cfnrcSsCount += 1;
                  }

               }//SS Type CFWD              
               //CB             
               if(l_SStype[1] == '1')
               {
                  char CB[50];
                  memset(CB, '\0', 50);
                  string l_ssData = ConfigReader::readValue(l_valueChar, "SS_DATA");
                  strncpy(CB, "|", 1);
                  strncat(CB, l_ssData.c_str(), strlen(l_ssData.c_str()));
                  strncat(CB, "|", 1);
                  //DLOG(0,0,"String received is %s\n", CB);
                  char str13[10][20];
                  memset(str13, '\0', 200);
                  {
                     char *ptr1, *ptr2;
                     ptr1 = ptr2 = CB;
                     ptr2++;
                     int b = 1;
                     while(*ptr2 != '\0')
                     {
                        if('|' == *ptr2)
                        {
                           //DLOG(0,0,"Found |\n");
                           if(ptr2 - ptr1 == 1)
                           {
                              strcpy(str13[b], "|0");
                              //DLOG(0,0,"str[%d]:%s\n",i,str13[i]);
                           }
                           else
                           {
                              //strncpy(str,ptr1,ptr2-ptr1);
                              strncpy(str13[b], ptr1, ptr2 - ptr1);
                              str13[b][ptr2 - ptr1] = '\0';
                              //DLOG(0,0,"str13[%d]:%s\n",i,str13[i]+1);
                           }
                           ptr1 = ptr2;
                           b++;
                        }

                        ptr2++;
                     }
                  }
                  //Barring of All Outgoing Call
                  if(atoi(str13[1] + 1) == 146)
                  {
                     m_isd.pss.boacSsCode = 146;
                     m_isd.pss.boacSsStatus[m_isd.pss.boacCount] = atoi(str13[2] + 1);
                     m_isd.pss.boacBCode[m_isd.pss.boacCount] = atoi(str13[3] + 1);
                     m_isd.pss.boacBType[m_isd.pss.boacCount] = atoi(str13[4] + 1);
                     DLOG(0, 0, "Call Barring :- SSCODE[%d] = %d, SS_Status[%d] = %d, Basic Service Code[%d] = %d,Basic Service Type[%d] = %d",
                           m_isd.pss.boacCount, m_isd.pss.boacSsCode, m_isd.pss.boacCount, m_isd.pss.boacSsStatus[m_isd.pss.boacCount], m_isd.pss.boacCount, m_isd.pss.boacBCode[m_isd.pss.boacCount], m_isd.pss.boacCount, m_isd.pss.boacBType[m_isd.pss.boacCount]);
                     m_isd.pss.boacCount += 1;
                  }
                  //barring of All Outgoing International calls
                  if(atoi(str13[1] + 1) == 147)
                  {
                     m_isd.pss.boicSsCode = 147;
                     m_isd.pss.boicSsStatus[m_isd.pss.boicCount] = atoi(str13[2] + 1);
                     m_isd.pss.boicBCode[m_isd.pss.boicCount] = atoi(str13[3] + 1);
                     m_isd.pss.boicBType[m_isd.pss.boicCount] = atoi(str13[4] + 1);
                     DLOG(0, 0, "Call Barring :- SSCODE[%d] = %d, SS_Status[%d] = %d, Basic Service Code[%d] = %d,Basic Service Type[%d] = %d",
                           m_isd.pss.boicCount, m_isd.pss.boicSsCode, m_isd.pss.boicCount, m_isd.pss.boicSsStatus[m_isd.pss.boicCount], m_isd.pss.boicCount, m_isd.pss.boicBCode[m_isd.pss.boicCount], m_isd.pss.boicCount, m_isd.pss.boicBType[m_isd.pss.boicCount]);
                     m_isd.pss.boicCount += 1;
                  }
                  //Barring of Internation outgoing calls except for HPLMN country
                  if(atoi(str13[1] + 1) == 148)
                  {
                     m_isd.pss.boihcSsCode = 148;
                     m_isd.pss.boihcSsStatus[m_isd.pss.boihcCount] = atoi(str13[2] + 1);
                     m_isd.pss.boihcBCode[m_isd.pss.boihcCount] = atoi(str13[3] + 1);
                     m_isd.pss.boihcBType[m_isd.pss.boihcCount] = atoi(str13[4] + 1);
                     DLOG(0, 0, "Call Barring :- SSCODE[%d] = %d, SS_Status[%d] = %d, Basic Service Code[%d] = %d,Basic Service Type[%d] = %d",
                           m_isd.pss.boihcCount, m_isd.pss.boihcSsCode, m_isd.pss.boihcCount, m_isd.pss.boihcSsStatus[m_isd.pss.boihcCount], m_isd.pss.boihcCount, m_isd.pss.boihcBCode[m_isd.pss.boihcCount], m_isd.pss.boihcCount, m_isd.pss.boihcBType[m_isd.pss.boihcCount]);
                     m_isd.pss.boihcCount += 1;
                  }
                  //Barring of all Incoming calls
                  if(atoi(str13[1] + 1) == 154)
                  {
                     m_isd.pss.baicSsCode = 154;
                     m_isd.pss.baicSsStatus[m_isd.pss.baicCount] = atoi(str13[2] + 1);
                     m_isd.pss.baicBCode[m_isd.pss.baicCount] = atoi(str13[3] + 1);
                     m_isd.pss.baicBType[m_isd.pss.baicCount] = atoi(str13[4] + 1);
                     DLOG(0, 0, "Call Barring :- SSCODE[%d] = %d, SS_Status[%d] = %d, Basic Service Code[%d] = %d,Basic Service Type[%d] = %d",
                           m_isd.pss.baicCount, m_isd.pss.baicSsCode, m_isd.pss.baicCount, m_isd.pss.baicSsStatus[m_isd.pss.baicCount], m_isd.pss.baicCount, m_isd.pss.baicBCode[m_isd.pss.baicCount], m_isd.pss.baicCount, m_isd.pss.baicBType[m_isd.pss.baicCount]);
                     m_isd.pss.baicCount += 1;
                  }
                  //Barring of Incoming Calls while Roaming outside Home PLMN Country
                  if(atoi(str13[1] + 1) == 155)
                  {
                     m_isd.pss.bicrSsCode = 155;
                     m_isd.pss.bicrSsStatus[m_isd.pss.bicrCount] = atoi(str13[2] + 1);
                     m_isd.pss.bicrBCode[m_isd.pss.bicrCount] = atoi(str13[3] + 1);
                     m_isd.pss.bicrBType[m_isd.pss.bicrCount] = atoi(str13[4] + 1);
                     DLOG(0, 0, "Call Barring :- SSCODE[%d] = %d, SS_Status[%d] = %d, Basic Service Code[%d] = %d,Basic Service Type[%d] = %d",
                           m_isd.pss.bicrCount, m_isd.pss.bicrSsCode, m_isd.pss.bicrCount, m_isd.pss.bicrSsStatus[m_isd.pss.bicrCount], m_isd.pss.bicrCount, m_isd.pss.bicrBCode[m_isd.pss.bicrCount], m_isd.pss.bicrCount, m_isd.pss.bicrBType[m_isd.pss.bicrCount]);
                     m_isd.pss.bicrCount += 1;
                  }

               }//SS Type CB
               //SS Data
               if(l_SStype[2] == '1')
               {
                  char SS[50];
                  memset(SS, '\0', 50);
                  string l_ssData = ConfigReader::readValue(l_valueChar, "SS_DATA");
                  strncat(SS, "|", 1);
                  strncat(SS, l_ssData.c_str(), strlen(l_ssData.c_str()));
                  strncat(SS, "|", 1);
                  //DLOG(0,0,"String to test in CWD %s\n",LID[li]);
                  char str4[10][30];
                  memset(str4, '\0', 300);
                  {
                     char *ptr1, *ptr2;
                     ptr1 = ptr2 = SS;
                     ptr2++;
                     int c = 1;
                     while(*ptr2 != '\0')
                     {
                        if('|' == *ptr2)
                        {
                           //DLOG(0,0,"Found |\n");
                           if(ptr2 - ptr1 == 1)
                           {
                              strcpy(str4[c], "|0");
                              //DLOG(0,0,"str[%d]:%s\n",i,str4[i]);
                           }
                           else
                           {
                              //strncpy(str,ptr1,ptr2-ptr1);
                              strncpy(str4[c], ptr1, ptr2 - ptr1);
                              str4[c][ptr2 - ptr1] = '\0';
                              //DLOG(0,0,"str4[%d]:%s\n",i,str4[i]+1);
                           }
                           ptr1 = ptr2;
                           c++;
                        }
                        ptr2++;
                     }
                  }
                  //DLOG(0,0,"STR 1 %d and STR 2 %d\n",atoi(str4[1]+1),atoi(str4[2]+1));
                  if(atoi(str4[1] + 1) == 17)
                  {
                     m_isd.pss.SsCode[m_isd.pss.SsCount] = atoi(str4[1] + 1);
                     m_isd.pss.SsStatus[m_isd.pss.SsCount] = atoi(str4[2] + 1);
                     m_isd.pss.SsBCode[m_isd.pss.SsCount] = atoi(str4[3] + 1);
                     m_isd.pss.SsBType[m_isd.pss.SsCount] = atoi(str4[4] + 1);
                     m_isd.pss.SsSubsRest[m_isd.pss.SsCount] = 2;//atoi(str4[5] + 1);
                     m_isd.pss.SsCLIOptn[m_isd.pss.SsCount] = 0;//atoi(str4[6] + 1);
                     if(atoi(str4[7] + 1))
                     {
                        m_isd.pss.SsOverRide[m_isd.pss.SsCount] = atoi(str4[7] + 1);
                     }
                     else
                     {
                        m_isd.pss.SsOverRide[m_isd.pss.SsCount] = 0;
                     }
                     DLOG(0, 0, "SS DATA CLIP :- SSCODE[%d] = %d , SS_Status[%d] = %d SS_BCode[%d] = %d SS_BTYPE[%d] = %d Subscription restrction[%d] = %d CLI_Option[%d] = %d OVERRide_Category[%d] = %d", m_isd.pss.SsCount, m_isd.pss.SsCode[m_isd.pss.SsCount], m_isd.pss.SsCount, m_isd.pss.SsStatus[m_isd.pss.SsCount], m_isd.pss.SsCount, m_isd.pss.SsBCode[m_isd.pss.SsCount], m_isd.pss.SsCount, m_isd.pss.SsBType[m_isd.pss.SsCount], m_isd.pss.SsCount, m_isd.pss.SsSubsRest[m_isd.pss.SsCount], m_isd.pss.SsCount, m_isd.pss.SsCLIOptn[m_isd.pss.SsCount], m_isd.pss.SsCount, m_isd.pss.SsOverRide[m_isd.pss.SsCount]);
                     m_isd.pss.SsCount += 1;
                  }
                  else if(atoi(str4[1] + 1) == 18)
                  {
                     m_isd.pss.SsCode[m_isd.pss.SsCount] = atoi(str4[1] + 1);
                     m_isd.pss.SsStatus[m_isd.pss.SsCount] = atoi(str4[2] + 1);
                     m_isd.pss.SsBCode[m_isd.pss.SsCount] = atoi(str4[3] + 1);
                     m_isd.pss.SsBType[m_isd.pss.SsCount] = atoi(str4[4] + 1);
                     m_isd.pss.SsSubsRest[m_isd.pss.SsCount] = 1;//atoi(str4[5] + 1);
                     if( atoi(str4[6] + 1))
                     {
                        m_isd.pss.SsCLIOptn[m_isd.pss.SsCount] = atoi(str4[6] + 1);
                     }
                     else
                     {
                        m_isd.pss.SsCLIOptn[m_isd.pss.SsCount] = 0;
                     }
                     m_isd.pss.SsOverRide[m_isd.pss.SsCount] = 0;
                     DLOG(0, 0, "SS DATA CLIR :- SSCODE[%d] = %d , SS_Status[%d] = %d SS_BCode[%d] = %d SS_BTYPE[%d] = %d Subscription restrction[%d] = %d CLI_Option[%d] = %d OVERRide_Category[%d] = %d", m_isd.pss.SsCount, m_isd.pss.SsCode[m_isd.pss.SsCount], m_isd.pss.SsCount, m_isd.pss.SsStatus[m_isd.pss.SsCount], m_isd.pss.SsCount, m_isd.pss.SsBCode[m_isd.pss.SsCount], m_isd.pss.SsCount, m_isd.pss.SsBType[m_isd.pss.SsCount], m_isd.pss.SsCount, m_isd.pss.SsSubsRest[m_isd.pss.SsCount], m_isd.pss.SsCount, m_isd.pss.SsCLIOptn[m_isd.pss.SsCount], m_isd.pss.SsCount, m_isd.pss.SsOverRide[m_isd.pss.SsCount]);
                     m_isd.pss.SsCount += 1;
                  }
                  else if(atoi(str4[1] + 1) == 19)
                  {
                     m_isd.pss.SsCode[m_isd.pss.SsCount] = atoi(str4[1] + 1);
                     m_isd.pss.SsStatus[m_isd.pss.SsCount] = atoi(str4[2] + 1);
                     m_isd.pss.SsBCode[m_isd.pss.SsCount] = atoi(str4[3] + 1);
                     m_isd.pss.SsBType[m_isd.pss.SsCount] = atoi(str4[4] + 1);
                     m_isd.pss.SsSubsRest[m_isd.pss.SsCount] = 2;//atoi(str4[5] + 1);
                     m_isd.pss.SsCLIOptn[m_isd.pss.SsCount] = 0;//atoi(str4[6] + 1);
                     if(atoi(str4[7] + 1))
                     {
                        m_isd.pss.SsOverRide[m_isd.pss.SsCount] = atoi(str4[7] + 1);
                     }
                     else
                     {
                        m_isd.pss.SsOverRide[m_isd.pss.SsCount] = 0;
                     }
                     DLOG(0, 0, "SS DATA COLP :- SSCODE[%d] = %d , SS_Status[%d] = %d SS_BCode[%d] = %d SS_BTYPE[%d] = %d Subscription restrction[%d] = %d CLI_Option[%d] = %d OVERRide_Category[%d] = %d", m_isd.pss.SsCount, m_isd.pss.SsCode[m_isd.pss.SsCount], m_isd.pss.SsCount, m_isd.pss.SsStatus[m_isd.pss.SsCount], m_isd.pss.SsCount, m_isd.pss.SsBCode[m_isd.pss.SsCount], m_isd.pss.SsCount, m_isd.pss.SsBType[m_isd.pss.SsCount], m_isd.pss.SsCount, m_isd.pss.SsSubsRest[m_isd.pss.SsCount], m_isd.pss.SsCount, m_isd.pss.SsCLIOptn[m_isd.pss.SsCount], m_isd.pss.SsCount, m_isd.pss.SsOverRide[m_isd.pss.SsCount]);
                     m_isd.pss.SsCount += 1;
                  }
                  else if(atoi(str4[1] + 1) == 20)
                  {
                     m_isd.pss.SsCode[m_isd.pss.SsCount] = atoi(str4[1] + 1);
                     m_isd.pss.SsStatus[m_isd.pss.SsCount] = atoi(str4[2] + 1);
                     m_isd.pss.SsBCode[m_isd.pss.SsCount] = atoi(str4[3] + 1);
                     m_isd.pss.SsBType[m_isd.pss.SsCount] = atoi(str4[4] + 1);
                     m_isd.pss.SsSubsRest[m_isd.pss.SsCount] = 0;//atoi(str4[5] + 1);
                     m_isd.pss.SsCLIOptn[m_isd.pss.SsCount] = 0;//atoi(str4[6] + 1);
                     m_isd.pss.SsOverRide[m_isd.pss.SsCount] = 0;//atoi(str4[7] + 1);
                     DLOG(0, 0, "SS DATA COLR :- SSCODE[%d] = %d , SS_Status[%d] = %d SS_BCode[%d] = %d SS_BTYPE[%d] = %d Subscription restrction[%d] = %d CLI_Option[%d] = %d OVERRide_Category[%d] = %d", m_isd.pss.SsCount, m_isd.pss.SsCode[m_isd.pss.SsCount], m_isd.pss.SsCount, m_isd.pss.SsStatus[m_isd.pss.SsCount], m_isd.pss.SsCount, m_isd.pss.SsBCode[m_isd.pss.SsCount], m_isd.pss.SsCount, m_isd.pss.SsBType[m_isd.pss.SsCount], m_isd.pss.SsCount, m_isd.pss.SsSubsRest[m_isd.pss.SsCount], m_isd.pss.SsCount, m_isd.pss.SsCLIOptn[m_isd.pss.SsCount], m_isd.pss.SsCount, m_isd.pss.SsOverRide[m_isd.pss.SsCount]);
                     m_isd.pss.SsCount += 1;
                  }
                  else
                  {
                     m_isd.pss.SsCode[m_isd.pss.SsCount] = atoi(str4[1] + 1);
                     m_isd.pss.SsStatus[m_isd.pss.SsCount] = atoi(str4[2] + 1);
                     m_isd.pss.SsBCode[m_isd.pss.SsCount] = atoi(str4[3] + 1);
                     m_isd.pss.SsBType[m_isd.pss.SsCount] = atoi(str4[4] + 1);
                     m_isd.pss.SsSubsRest[m_isd.pss.SsCount] = 0;//atoi(str4[5] + 1);
                     m_isd.pss.SsCLIOptn[m_isd.pss.SsCount] = 0;//atoi(str4[6] + 1);
                     m_isd.pss.SsOverRide[m_isd.pss.SsCount] = 0;//atoi(str4[7] + 1);
                     DLOG(0, 0, "SS DATA :- SSCODE[%d] = %d , SS_Status[%d] = %d SS_BCode[%d] = %d SS_BTYPE[%d] = %d Subscription restrction[%d] = %d CLI_Option[%d] = %d OVERRide_Category[%d] = %d", m_isd.pss.SsCount, m_isd.pss.SsCode[m_isd.pss.SsCount], m_isd.pss.SsCount, m_isd.pss.SsStatus[m_isd.pss.SsCount], m_isd.pss.SsCount, m_isd.pss.SsBCode[m_isd.pss.SsCount], m_isd.pss.SsCount, m_isd.pss.SsBType[m_isd.pss.SsCount], m_isd.pss.SsCount, m_isd.pss.SsSubsRest[m_isd.pss.SsCount], m_isd.pss.SsCount, m_isd.pss.SsCLIOptn[m_isd.pss.SsCount], m_isd.pss.SsCount, m_isd.pss.SsOverRide[m_isd.pss.SsCount]);
                     m_isd.pss.SsCount += 1;
                  }

               }//SS TYPE SS
               //EMLPP
               if(l_SStype[3] == '1')
               {
                  char EMLPP[50];
                  memset(EMLPP, '\0', sizeof(EMLPP));
                  string l_emlpp = ConfigReader::readValue(l_valueChar, "SS_DATA");
                  strncpy(EMLPP, "|", 1);
                  strncat(EMLPP,l_emlpp.c_str(), strlen(l_emlpp.c_str()));
                  strncat(EMLPP, "|", 1);
                  //DLOG(0,0,"String to test %s\n",EMLPP);
                  char str7[5][20];
                  memset(str7, '\0', 100);
                  {
                     char *ptr1, *ptr2;
                     ptr1 = ptr2 = EMLPP;
                     ptr2++;
                     int d = 1;
                     while(*ptr2 != '\0')
                     {
                        if('|' == *ptr2)
                        {
                           if(ptr2 - ptr1 == 1)
                           {
                              strncpy(str7[d], "|0", 2);
                              //DLOG(0,0,"str[%d]:%s\n",i,str7[i]);
                           }
                           else
                           {
                              //strncpy(str,ptr1,ptr2-ptr1);
                              strncpy(str7[d], ptr1, ptr2 - ptr1);
                              str7[d][ptr2 - ptr1] = '\0';
                              //DLOG(0,0,"str7[%d]:%s\n",i,str7[i]+1);
                           }
                           ptr1 = ptr2;
                           d++;
                        }
                        ptr2++;
                     }
                  }
                  m_isd.pss.ESsCode = 161;
                  m_isd.pss.ESsStatus = atoi(str7[1] + 1);
                  m_isd.pss.EDefaultPriority = atoi(str7[2] + 1);
                  m_isd.pss.EMaxPriority = atoi(str7[3] + 1);
                  DLOG(0,0,"EMLPP :- SSCODE = %d , SS_Status = %d Default Priority = %d Max Entitiled priority = %d",m_isd.pss.ESsCode,m_isd.pss.ESsStatus,m_isd.pss.EDefaultPriority,m_isd.pss.EMaxPriority);
               }//SS TYPE EMLPP Info
               if(l_SStype[4] == '1')
               {
                  char McSs[50];
                  memset(McSs, '\0', sizeof(McSs));
                  string l_McSS = ConfigReader::readValue(l_valueChar, "SS_DATA");
                  strncat(McSs, "|", 1);
                  strncat(McSs,l_McSS.c_str(), strlen(l_McSS.c_str()));
                  strncat(McSs, "|", 1);
                  //DLOG(0,0,"String to test %s\n",McSs);
                  char str8[5][20];
                  memset(str8, '\0', 100);
                  {
                     char *ptr1, *ptr2;
                     ptr1 = ptr2 = McSs;
                     ptr2++;
                     int e = 1;
                     while(*ptr2 != '\0')
                     {
                        if('|' == *ptr2)
                        {
                           if(ptr2 - ptr1 == 1)
                           {
                              strncpy(str8[e], "|0", 2);
                              //DLOG(0,0,"str[%d]:%s\n",i,str1[i]);
                           }
                           else
                           {
                              //strncpy(str,ptr1,ptr2-ptr1);
                              strncpy(str8[e], ptr1, ptr2 - ptr1);
                              str8[e][ptr2 - ptr1] = '\0';
                              //DLOG(0,0,"str1[%d]:%s\n",i,str1[i]+1);
                           }
                           ptr1 = ptr2;
                           e++;
                        }
                        ptr2++;
                     }
                  }
                  m_isd.pss.mcSsCode = 69;
                  m_isd.pss.MCSsStatus = atoi(str8[2] + 1);
                  m_isd.pss.NBR_SB = atoi(str8[3] + 1);
                  m_isd.pss.NBR_USER = atoi(str8[4] + 1);
                  DLOG(0, 0, "MC_SS_INFO :- SSCODE = %d , SS_Status = %d NBR_SB = %d NBR_USER = %d", m_isd.pss.mcSsCode, m_isd.pss.MCSsStatus, m_isd.pss.NBR_SB, m_isd.pss.NBR_USER);
               }//SS TYPE MC SS Info
            }
            else
            {
               DLOG(0,0,"%s not present,breaking",l_val);
               break;
            }
         }//for loop
         DLOG(0, 0, "Call forwarding Unconditional SS Count = %d", m_isd.pss.cfuSsCount);
         DLOG(0, 0, "Call Deflection Count = %d", m_isd.pss.cdSsCount);
         DLOG(0, 0, "Call Fwd on Busy count = %d", m_isd.pss.cfbSsCount);
         DLOG(0, 0, "Call Fwd on no Reply Count = %d", m_isd.pss.cfnrySsCount);
         DLOG(0, 0, "Call FWD on not rechable Count = %d", m_isd.pss.cfnrcSsCount);
         DLOG(0, 0, "Call barring for all Out going call = %d", m_isd.pss.boacCount);
         DLOG(0, 0, "Call barring for international outgoing call = %d", m_isd.pss.boicCount);
         DLOG(0, 0, "Call barring for internation outgoing calls except for HPLMN country = %d", m_isd.pss.boihcCount);
         DLOG(0, 0, "Call barring for all incoming call = %d", m_isd.pss.baicCount);
         DLOG(0, 0, "Call barring for Incoming Calls while Roaming outside Home PLMN Country = %d", m_isd.pss.bicrCount);
         DLOG(0,0,"SS Data count = %d",m_isd.pss.SsCount);

      //////////////////  MEXICO BEGIN 6100 ///////////////////////
         map<int, HlrNetworks* > :: iterator l_HlrNetworksDetailsIter;
         int l_nwId = atoi(l_network_id.c_str());
         l_HlrNetworksDetailsIter = g_spdPtr->m_HlrNetworks.find(l_nwId);
         if(l_HlrNetworksDetailsIter != g_spdPtr->m_HlrNetworks.end())
         {
            TLOG(0,0,"NetworkId[%d] present in HlrNetworks Map, checking for DisableFwdInfoInIsdSri Value",l_nwId);
            if(1 ==(l_HlrNetworksDetailsIter->second)->m_DisableFwdInfoInIsdSri)
            {
               LLOG(0,0,"DisableFwdInfoInIsdSri|%d| is Enabled, Unsetting the FWD info",(l_HlrNetworksDetailsIter->second)->m_DisableFwdInfoInIsdSri);
               m_isd.pss.cfuSsCount = 0;       m_isd.pss.cfuSsCode = 0;
               m_isd.pss.cdSsCount = 0;        m_isd.pss.cdSsCode = 0;
               m_isd.pss.cfbSsCount = 0;       m_isd.pss.cfbSsCode = 0;
               m_isd.pss.cfnrySsCount = 0;     m_isd.pss.cfnrySsCode = 0;
               m_isd.pss.cfnrcSsCount = 0;     m_isd.pss.cfnrcSsCode = 0;
            }
            else
            {
               LLOG(0,0,"DisableFwdInfoInIsdSri|%d| is Disabled, Sending the FWD info in ISD",(l_HlrNetworksDetailsIter->second)->m_DisableFwdInfoInIsdSri);
            }
         }
         else
         {
            TLOG(0,0,"NetworkId[%d]not present in HlrNetworks Map, Not checking DisableFwdInfoInIsdSri Value, Sending FWD info in ISD",l_nwId);
         }
      //////////////////  MEXICO END 6100 ///////////////////////
      }
      else
      {
         DLOG(0,0,"No Supplementary service data present");
         l_ssPresent = false;
      }//l_SSPresent
      if(true == l_VcsiPresent)
      {
         m_isd.vlrcsi.vcsi.nwId = 0;
         m_isd.vlrcsi.vcsi.PnwId = 0;
         m_isd.vlrcsi.vcsi.ocsi = 0;
         m_isd.vlrcsi.vcsi.sscsi = 0;
         m_isd.vlrcsi.vcsi.tifcsi = 0;
         m_isd.vlrcsi.vcsi.dcsi = 0;
         m_isd.vlrcsi.vcsi.vtcsi = 0;
         m_isd.vlrcsi.vcsi.mosmscsi = 0;
         m_isd.vlrcsi.vcsi.mtsmscsi = 0;
         string l_val = ConfigReader::readValue(l_vcsi,"NW_ID");
         if(l_val.length() > 0)
         {
            m_isd.vlrcsi.vcsi.nwId = atoi(l_val.c_str());
            DLOG(0,0,"VLR CSI NW Id %d",m_isd.vlrcsi.vcsi.nwId);
         }
         else
         {
            WLOG(0,0,"No NW id present in VLRCSI");
            m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_UNABLE_TO_INITIATE);
            return false;
         }
         l_val = ConfigReader::readValue(l_vcsi,"PART_NW_ID");
         if(l_val.length() > 0)
         {
            m_isd.vlrcsi.vcsi.PnwId = atoi(l_val.c_str());
            DLOG(0,0,"VLR CSI Partner NW Id %d",m_isd.vlrcsi.vcsi.PnwId);
         }
         else
         {
            WLOG(0,0,"No Partner NW id present in VLRCSI");
            m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_UNABLE_TO_INITIATE);
            return false;
         }
         l_val = ConfigReader::readValue(l_vcsi,"CAMEL_PHASE");
         if(l_val.length() > 0)
         {
            int l_cap = atoi(l_val.c_str());
            if(l_cap & 0x01)
            {
               m_isd.vlrcsi.vcsi.rcvd_camel_phase = 1;//atoi(l_val.c_str());
            }
            if(l_cap & 0x02)
            {
               m_isd.vlrcsi.vcsi.rcvd_camel_phase = 2;//atoi(l_val.c_str());
            }
            if(l_cap & 0x04)
            {
               m_isd.vlrcsi.vcsi.rcvd_camel_phase = 3;//atoi(l_val.c_str());
            }
            if(l_cap & 0x08)
            {
               m_isd.vlrcsi.vcsi.rcvd_camel_phase = 4;//atoi(l_val.c_str());
            }
            /*else
              {
              WLOG(0,0,"Unrecognized camel phase %d",l_cap);
              return false;
              }*/

            LLOG(0,0,"Received camel phase of destination %d",m_isd.vlrcsi.vcsi.rcvd_camel_phase);
         }
         else
         {
            WLOG(0,0,"VLR supported camel phase not present");
            m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_UNABLE_TO_INITIATE);
            return false;
         }
         l_val = ConfigReader::readValue(l_vcsi,"O_CSI");
         if(l_val.length() > 0)
         {
            m_isd.vlrcsi.vcsi.ocsi = atoi(l_val.c_str());
            DLOG(0,0,"VLR CSI OCSI Profile Id %d",m_isd.vlrcsi.vcsi.ocsi);
         }
         l_val = ConfigReader::readValue(l_vcsi,"SS_CSI");
         if(l_val.length() > 0)
         {
            m_isd.vlrcsi.vcsi.sscsi = atoi(l_val.c_str());
            DLOG(0,0,"VLR CSI SS CSI Profile Id %d",m_isd.vlrcsi.vcsi.sscsi);
         }
         l_val = ConfigReader::readValue(l_vcsi,"TIF_CSI");
         if(l_val.length() > 0)
         {
            m_isd.vlrcsi.vcsi.tifcsi = atoi(l_val.c_str());
            DLOG(0,0,"VLR CSI TIF CSI Profile Id %d",m_isd.vlrcsi.vcsi.tifcsi);
         }
         l_val = ConfigReader::readValue(l_vcsi,"D_CSI");
         if(l_val.length() > 0)
         {
            m_isd.vlrcsi.vcsi.dcsi = atoi(l_val.c_str());
            DLOG(0,0,"VLR CSI DCSI Profile Id %d",m_isd.vlrcsi.vcsi.dcsi);
         }
         l_val = ConfigReader::readValue(l_vcsi,"MOSMS_CSI");
         if(l_val.length() > 0)
         {
            m_isd.vlrcsi.vcsi.mosmscsi = atoi(l_val.c_str());
            DLOG(0,0,"VLR CSI MOSMS CSI Profile Id %d",m_isd.vlrcsi.vcsi.mosmscsi);
         }
         l_val = ConfigReader::readValue(l_vcsi,"MTSMS_CSI");
         if(l_val.length() > 0)
         {
            m_isd.vlrcsi.vcsi.mtsmscsi = atoi(l_val.c_str());
            DLOG(0,0,"VLR CSI MTSMS CSI Profile Id %d",m_isd.vlrcsi.vcsi.mtsmscsi);
         }
         if((m_isd.vlrcsi.vcsi.ocsi == 0) && (m_isd.vlrcsi.vcsi.sscsi == 0) && (m_isd.vlrcsi.vcsi.tifcsi == 0) && (m_isd.vlrcsi.vcsi.dcsi== 0) && (m_isd.vlrcsi.vcsi.mosmscsi == 0))
         {
            WLOG(0,0,"No csi profile id present");
            //return false;
            //l_VcsiPresent == false;
         }

      }
      else
      {
         DLOG(0,0,"No VLR CSI data present");
         l_VcsiPresent = false;
      }//l_VcsiPresent
      if(true == l_ScsiPresent)
      {
         string l_val1 = ConfigReader::readValue(l_scsi,"NW_ID");
         if(l_val1.length() > 0)
         {
            m_isd.Sgsncsi.scsi.nwId = atoi(l_val1.c_str());
            DLOG(0,0,"SGSN CSI NW Id %d",m_isd.Sgsncsi.scsi.nwId);
         }
         else
         {
            WLOG(0,0,"No NW id present in SGSNCSI");
            m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_UNABLE_TO_INITIATE);
            return false;
         }
         l_val1 = ConfigReader::readValue(l_scsi,"PART_NW_ID");
         if(l_val1.length() > 0)
         {
            m_isd.Sgsncsi.scsi.nwId = atoi(l_val1.c_str());
            DLOG(0,0,"SGSN CSI Partner NW Id %d",m_isd.Sgsncsi.scsi.nwId);
         }
         else
         {
            WLOG(0,0,"No Partner NW id present in SGSNCSI");
            m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_UNABLE_TO_INITIATE);
            return false;
         }
         l_val1 = ConfigReader::readValue(l_scsi,"CAMEL_PHASE");
         if(l_val1.length() > 0)
         {
            //m_isd.Sgsncsi.scsi.nwId = atoi(l_val1.c_str());
            DLOG(0,0,"SGSN Camel Phase %d",atoi(l_val1.c_str()));//m_isd.Sgsncsi.scsi.nwId);
         }
         else
         {
            WLOG(0,0,"No Camel phase id present in SGSNCSI");
            m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_UNABLE_TO_INITIATE);
            return false;
         }
      }
      else
      {
         DLOG(0,0,"No SGSN CSI data present");
         l_ScsiPresent = false;
      }//l_ScsiPresent

   }//l_somethingToSendPresent
   else
   {
      WLOG(0,0,"No data present to send in standalone ISD");
      return false;
   }
   if(m_ssn == 149)
   {
      LLOG(0,0,"Received ISD message for SGSN, Initiating ISD Version 3");
      l_Version = 3;
      if(false == FormISDV3())
         return false;
   }
   else
   {
      if(g_MmConfigReaderObj->m_Version == 3)
      {
         TLOG(0,0,"Received ISD message for GSM,Initiating ISD version 3");
         l_Version = 3;
         if(false == FormISDV3())
            return false;
      }
      else if(g_MmConfigReaderObj->m_Version == 2)
      {
         TLOG(0,0,"Received ISD message for GSM,Initiating ISD version 2");
         l_Version = 2;
         if(false == FormISDV2())
            return false;
      }
      else if(g_MmConfigReaderObj->m_Version == 1)
      {
         TLOG(0,0,"Received ISD message for GSM,Initiating ISD version 1");
         l_Version = 1;
         if(false == FormISDV1())
            return false;
      }
      else
      {
         WLOG(0,0,"Unrecognizable version %d",g_MmConfigReaderObj->m_Version);
         return false;
      }
   }
   return true;
}

bool StandaloneISD::OpenCnf(MapOpenCnf *l_oCnf)
{
   DLOG(0, 0, "Received Open Confirmation Refuse Reason is %d", l_oCnf->m_RefuseReasonParam);
   //m_OpenCnfRcvd = true;
   m_FirstFilled = false;
   if(l_oCnf->m_RefuseReasonParam ==  REFUSE_REASON_APPL_CNTXT_NOT_SUPPORTED)
   {
      m_tdr.setInteger(TDR_INDEX_OPEN_CNF_VERSION,l_oCnf->m_Version);
      LLOG(0, 0, "Received Open Cnf with Supported verion as %d", l_oCnf->m_Version);
      if((l_oCnf->m_Version == 2) && (l_oCnf->m_Version < g_MmConfigReaderObj->m_Version))
      {
         if(m_ssn == 149)
         {
            WLOG(0,0,"OpenCnf with V2 supported for Standalone ISD to SGSN");
            m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_UNABLE_TO_INITIATE);
            //if(true == m_UpdateReqd)
            //{
            //   updateDb('F', "Illegal Map version requested");
            //}
            return false;
         }
         DLOG(0,0,"Initiating ISD version 2");
         l_Version = l_oCnf->m_Version;
         if(false == FormISDV2())
            return false;
      }
      else if((l_oCnf->m_Version == 1) && (l_oCnf->m_Version < g_MmConfigReaderObj->m_Version))
      {
         if(m_ssn == 149)
         {
            WLOG(0,0,"OpenCnf with V1 supported for Standalone ISD to SGSN");
            m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_UNABLE_TO_INITIATE);
            //if(true == m_UpdateReqd)
            //{
            //   updateDb('F', "Illegal Map version requested");
            //}
            return false;
         }
         DLOG(0,0,"Initiating ISD version 1");
         l_Version = l_oCnf->m_Version;
         if(false == FormISDV1())
            return false;
      }
      else
         WLOG(0, 0, "Unrecognizable version received");
   }
   else
   {
      WLOG(0,0,"OpenCnf reason is not APPL_CNTXT_NOT_SUPPORTED, returning");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_NOTICE_RCVD);
      if(true == m_UpdateReqd)
      {
         updateDb('F', "Notice Rcvd");
      }
      return false;
   }
   return true;
}


void StandaloneISD::updateDb(char p_status, char *p_error)
{
   //
   //Added in 1.0.11.0
   //
   if(true == m_updateDbCalledFlag)
   {
      LLOG(0,1,"m_updateDbCalledFlag is already true. So not updating again");
      return;
   }

   m_updateDbCalledFlag = true; //A successive close ind shall not call update db again
   if( ((p_status == 'F') && (g_MmConfigReaderObj->m_send_cl_on_isd_failure == 1)) )
   {
      //send CL only for following errors
      // "Received U-Abort"
      // "Received P-Abort"
      // "Received Notice"
      // "Received USER ERROR"
      // "Provider Error"
      // "No meaningful data present"
      // "Illegal Map version requested"
      // "Notice Rcvd"
      // "Unable to form ISD"
      // "ODB Rejected"

      char l_reason[50];
      if(true == m_ODBflag)
      {
         snprintf(l_reason, sizeof(l_reason), "ISD_ODB_FAILED");
      }
      else if(l_msisdn.length() > 0)
      {
         snprintf(l_reason, sizeof(l_reason), "ISD_MSISDN_FAILED");
      }
      else if(l_ssList.length() > 0)
      {
         snprintf(l_reason, sizeof(l_reason), "ISD_SS_FAILED");
      }
      else
      {
         snprintf(l_reason, sizeof(l_reason), "ISD_OTHER_FAILED");
      }
      char XmlReq[501];
      memset(XmlReq,'\0',sizeof(XmlReq));
      u8 lmsi[9];
      memset(lmsi,'\0',sizeof(lmsi));
      if(l_lmsi.length() > 0)
         strcpy((char *)lmsi,(char *)l_lmsi.c_str());
      LLOG(0, 0, "Received ERROR on ISD Resp,Initiating cancel location to VLR [%s] with HLR address [%s] for IMSI [%s] and LMSI [%s]",l_destAddress.c_str(),l_origAddress.c_str(), l_imsi.c_str(), lmsi);
      if(m_ssn == 7)
      {
         FormXMLRequest(XmlReq,1, (u8 *)l_imsi.c_str(), lmsi,(u8 *) l_origAddress.c_str(),(u8 *) l_destAddress.c_str(),1,0,
               l_reason, (s8*)l_mscNumber.c_str());
      }
      else
      {
         FormXMLRequest(XmlReq,2, (u8 *)l_imsi.c_str(), lmsi,(u8 *) l_origAddress.c_str(),(u8 *) l_destAddress.c_str(),1,0,
               l_reason, (s8*)l_mscNumber.c_str());
      }
      DLOG(0, 0, "Sending XmlReq %s to CtxtCancelLocation", XmlReq);
      g_sc.initiateIndependentContext(this, MAP_OP_CODE_cancelLocation, (char *) XmlReq, INITIATION_TYPE_IMMEDIATE);
   }
   //End Added in 1.0.11.0
   //

   LLOG(0,0,"Updating OAM transaction ID %s with status %c",m_TransId,p_status);
   UpdateDBStatus *l_UDB = new UpdateDBStatus;
   l_UDB->m_cb = this;
   l_UDB->m_Status = p_status;
   strcpy(l_UDB->m_TransId,m_TransId);
   strcpy(l_UDB->m_ErrorCause, p_error);
   strcpy((char*)l_UDB->m_IMSI,(char*)l_imsi.c_str());
   if(m_ssn == 7)
   {
      l_UDB->m_TYPE = 0;
   }
   else
   {
      l_UDB->m_TYPE = 1;
   }
   g_act.execute(l_UDB);
}

bool StandaloneISD::FormISDV3()
{
   l_isdDlgId = 0;
   m_tdr.setMapVersion(3);
   DECLARE(OMAP3_InsertSubscriberDataArg,l_isd,3,"OMAP3_InsertSubscriberDataArg",DeclareFunc);
   l_isd->bit_mask = 0;
   index = OMAP3_InsertSubscriberDataArg_imsi_present;
   VcsiIndex = OMAP3_VlrCamelSubscriptionInfo_o_CSI_present;;
   m_isd.pss.CFWD_STATE = (provisionedSS::CFWD)0;
   m_isd.pss.CB_STATE = (provisionedSS::CB)0;
   m_isd.dbisd3.VLRCsi = true;
   m_isd.pss.val = 0;
   m_isd.dbisd3.sgsncsi = false;
   m_isd.dbisd3.gprsSubsData = 0;
   m_isd.pss.m_GenSsCount = 0;
   flag = false;
   SsIndex = OMAP3_Ext_SS_Info_forwardingInfo_chosen;
   ScsiIndex = 0;
   DLOG(0,0,"Starting ISD V3 with index %x SsIndex %x and VLR CSI Index %x",index,SsIndex,VcsiIndex);
   //if(true == FillIsdV3(l_isdDlgId,l_isd))
   if(true == FillIsdV3(l_isd))
   {
      int l_len = CheckLengthV3(l_isd);
      DLOG(0,0,"Length of ISD data formed %d",l_len);
      if(l_len < 15)
      {
         ELOG(0,0,"Unable to form ISD msg, Check the received data");
         m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_UNABLE_TO_INITIATE);
         if(true == m_UpdateReqd)
         {
            updateDb('F', "Unable to form ISD");
         }
         return false;
      }
      l_isdDlgId = g_sc.getNewDialogue();
      if(l_isdDlgId < 1)
      {
         CLOG(0,0,"Dialog id less than 1");
         return false;
      }
      DLOG(0, 0, "Sending MapSpecificRequest ISD v3...");
      MapSpecificRequest l_request(l_isdDlgId, MAP_OP_CODE_insertSubscriberData, MAP_V3);

      LLOG(0, 0, "Sending standalone ISD Map Open Req with MAP msg version 3");
      MapOpenReq l_mapOpenReq(l_isdDlgId, MAP_V3);
      l_mapOpenReq.m_ApplCntxt = MAP_AC_CODE_subscriberDataMngt;
      DLOG(0, 0, "Configuring SCCP address for Destination number %s,Orgination number %s", l_destAddress.c_str(), l_origAddress.c_str());
      unsigned char l_origAddr[21];unsigned char l_destAddr[21];
      memset(l_origAddr,'\0',sizeof(l_origAddr)); memset(l_destAddr,'\0',sizeof(l_destAddr));
      strcpy((char *)l_origAddr,l_origAddress.c_str()); 
      strcpy((char *)l_destAddr,l_destAddress.c_str());
      configureSccpAddress(&l_mapOpenReq.m_OrigAddr, L_ROUTE_ON_GT, 0, g_ConfigData->i_NgConfigData.m_LocalSSN, (char *)l_origAddr);
      configureSccpAddress(&l_mapOpenReq.m_DestAddr, L_ROUTE_ON_GT, 0,m_ssn, (char*) l_destAddr);
      g_sc.sendMsg(this, &l_mapOpenReq);

      DLOG(0,0,"After ISD v3 index %x SsIndex %x and VLR CSI Index %x",index,SsIndex,VcsiIndex);
      l_request.m_structBuffer = (void*) l_isd;
      l_request.m_TimerValue = g_MmConfigReaderObj->m_ISD_Invoke_Timer;
      g_sc.sendMsg(this, &l_request);

      DLOG(0, 0, "Sending MapDelimiterReq Req");
      MapDelimiterReq l_del(l_isdDlgId);
      g_sc.sendMsg(this, &l_del);
   }
   else
   {
      CLOG(0,0,"Unable to form ISD msg, Check the received data");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_UNABLE_TO_INITIATE);
      if(true == m_UpdateReqd)
      {
         updateDb('F', "Unable to form ISD");
      }
      return false;
   }
   return true;
}

bool StandaloneISD::FormISDV2()
{
   l_isdDlgId = 0;
#if 1
   if (false == Validate4LFTN())
      return false;
#endif   

   m_tdr.setMapVersion(2);
   //m_tdr.setCallingAddr((s8 *)l_destAddr);
   //DECLARE(OMAP2_InsertSubscriberDataArg, l_isd, 2);
   DECLARE(OMAP2_InsertSubscriberDataArg,l_isd,2,"OMAP2_InsertSubscriberDataArg",DeclareFunc);
   l_isd->bit_mask = 0;
   index = OMAP2_InsertSubscriberDataArg_imsi_present;;
   m_isd.pss.CFWD_STATE = (provisionedSS::CFWD)0;
   m_isd.pss.CB_STATE = (provisionedSS::CB)0;
   m_isd.pss.val = 0;
   flag = false;
   SsIndex = OMAP2_SS_Info_forwardingInfo_chosen;
   DLOG(0,0,"Calling FillIsdV2 Index value %x, SS Index value %x",index,SsIndex);
   //if(true == FillIsdV2(l_isdDlgId, l_isd))
   if(true == FillIsdV2(l_isd))
   {
      if(CheckLengthV2(l_isd) < 15)
      {
         ELOG(0,0,"Unable to form ISD msg, Check the received data");
         m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_UNABLE_TO_INITIATE);
         if(true == m_UpdateReqd)
         {
            updateDb('F', "Unable to form ISD");
         }
         return false;
      }
      l_isdDlgId = g_sc.getNewDialogue();
      if(l_isdDlgId < 1)
      {
         CLOG(0,0,"Dialog id less than 1");
         return false;
      }
      DLOG(0, 0, "Sending MapSpecificRequest ISD v2...");
      MapSpecificRequest l_request(l_isdDlgId, MAP_OP_CODE_insertSubscriberData, MAP_V2);
      LLOG(0, 0, "Sending standalone ISD Map Open Req with MAP msg version 2");
      MapOpenReq l_mapOpenReq(l_isdDlgId, MAP_V2);
      l_mapOpenReq.m_ApplCntxt = MAP_AC_CODE_subscriberDataMngt;
      DLOG(0, 0, "Configuring SCCP address for Destination number %s,Orgination number %s", l_destAddress.c_str(), l_origAddress.c_str());
      unsigned char l_origAddr[21];unsigned char l_destAddr[21];
      memset(l_origAddr,'\0',sizeof(l_origAddr)); memset(l_destAddr,'\0',sizeof(l_destAddr));
      strcpy((char *)l_origAddr,l_origAddress.c_str());
      strcpy((char *)l_destAddr,l_destAddress.c_str());
      configureSccpAddress(&l_mapOpenReq.m_OrigAddr, L_ROUTE_ON_GT, 0, g_ConfigData->i_NgConfigData.m_LocalSSN, (char*) l_origAddr);
      configureSccpAddress(&l_mapOpenReq.m_DestAddr, L_ROUTE_ON_GT, 0, m_ssn, (char*) l_destAddr);

      g_sc.sendMsg(this, &l_mapOpenReq);
      DLOG(0,0,"After forming isd v2, Index value is %x SS_inded %x",index,SsIndex);
      l_request.m_structBuffer = (void*) l_isd;
      l_request.m_TimerValue = g_MmConfigReaderObj->m_ISD_Invoke_Timer;
      g_sc.sendMsg(this, &l_request);

      DLOG(0, 0, "Sending MapDelimiterReq Req");
      MapDelimiterReq l_del(l_isdDlgId);
      g_sc.sendMsg(this, &l_del);
   }
   else
   {
      CLOG(0,0,"Unable to form ISD msg, Check the received data");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_UNABLE_TO_INITIATE);
      if(true == m_UpdateReqd)
      {
         updateDb('F', "Unable to form ISD");
      }
      return false;
   }

   return true;
}

bool StandaloneISD::Validate4LFTN()
{
   DLOG(0,0,"Value of cfuSsCount = %d,cdSsCount = %d,cfbSsCount = %d,cfnrySsCount = %d,cfnrcSsCount = %d",m_isd.pss.cfuSsCount,m_isd.pss.cdSsCount,m_isd.pss.cfbSsCount,m_isd.pss.cfnrySsCount,m_isd.pss.cfnrcSsCount);
   if(m_isd.pss.cfbSsCount)
   {
      for(int cf = 0;cf < m_isd.pss.cfbSsCount;cf++)
      {                                                                                                              
         if((strlen((char *)m_isd.pss.cfbLFTN[cf]) > 0) && (strlen((char *)m_isd.pss.cfbFTN[cf]) < 1))
            return false;
      }
   }
   if(m_isd.pss.cfnrySsCount)                                                                                        
   {
      for(int cf = 0;cf < m_isd.pss.cfnrySsCount;cf++)
      {
         if((strlen((char *)m_isd.pss.cfnryLFTN[cf]) > 0) && (strlen((char *)m_isd.pss.cfnryFTN[cf]) < 1))
            return false;
      }
   }
   if(m_isd.pss.cfnrcSsCount)
   {
      for(int cf = 0;cf < m_isd.pss.cfnrcSsCount;cf++)
      {
         if((strlen((char *)m_isd.pss.cfnrcLFTN[cf]) > 0) && (strlen((char *)m_isd.pss.cfnrcFTN[cf]) < 1))
            return false;
      }
   }
   if(m_isd.pss.cdSsCount)
   {
      for(int cf = 0;cf < m_isd.pss.cdSsCount;cf++)
      {
         if((strlen((char *)m_isd.pss.cdLFTN[cf]) > 0) && (strlen((char *)m_isd.pss.cdFTN[cf]) < 1))
            return false;
      }
   }
   DLOG(0,0,"Validate FTN success, returning true");
   return true;
}

bool StandaloneISD::FormISDV1()
{
   l_isdDlgId = 0;
#if 1
   if(false == Validate4LFTN())
      return false;
#endif   
   m_tdr.setMapVersion(1);

   DECLARE(OMAP1_InsertSubscriberDataArg,l_isd,1,"OMAP1_InsertSubscriberDataArg",DeclareFunc);
   l_isd->bit_mask = 0;
   index = OMAP1_InsertSubscriberDataArg_imsi_present;;
   m_isd.pss.CFWD_STATE = (provisionedSS::CFWD)0;
   m_isd.pss.CB_STATE = (provisionedSS::CB)0;
   m_isd.pss.val = 0;
   flag = false;
   SsIndex = OMAP1_forwardingInfo_chosen;
   DLOG(0,0,"Calling FillIsdV1 index value %x, SS Index value %x",index,SsIndex);
   //FillIsdV1(l_isdDlgId, l_isd);
   FillIsdV1(l_isd);
   if(CheckLengthV1(l_isd) < 15)
   {
      ELOG(0,0,"Unable to form ISD msg, Check the received data");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_UNABLE_TO_INITIATE);
      if(true == m_UpdateReqd)
      {
         updateDb('F', "Unable to form ISD");
      }
      return false;
   }
   l_isdDlgId = g_sc.getNewDialogue();
   if(l_isdDlgId < 1)
   {
      CLOG(0,0,"Dialog id less than 1");
      return false;
   }
   DLOG(0, 0, "Sending MapSpecificRequest ISD v1...");
   MapSpecificRequest l_request(l_isdDlgId, MAP_OP_CODE_insertSubscriberData, MAP_V1);

   LLOG(0, 0, "Sending standalone ISD Map Open Req with MAP msg version 1");
   MapOpenReq l_mapOpenReq(l_isdDlgId, MAP_V1);
   l_mapOpenReq.m_ApplCntxt = MAP_AC_CODE_subscriberDataMngt;
   DLOG(0, 0, "Configuring SCCP address for Destination number %s,Orgination number %s", l_destAddress.c_str(), l_origAddress.c_str());
   unsigned char l_origAddr[21];unsigned char l_destAddr[21];
   memset(l_origAddr,'\0',sizeof(l_origAddr)); memset(l_destAddr,'\0',sizeof(l_destAddr));
   strcpy((char *)l_origAddr,l_origAddress.c_str());
   strcpy((char *)l_destAddr, l_destAddress.c_str());
   configureSccpAddress(&l_mapOpenReq.m_OrigAddr, L_ROUTE_ON_GT, 0, g_ConfigData->i_NgConfigData.m_LocalSSN, (char*) l_origAddr);
   configureSccpAddress(&l_mapOpenReq.m_DestAddr, L_ROUTE_ON_GT, 0, m_ssn, (char*) l_destAddr);

   g_sc.sendMsg(this, &l_mapOpenReq);
   DLOG(0,0,"After ISD V1 index value %x, SS Index value %x",index,SsIndex);
   l_request.m_structBuffer = (void*) l_isd;
   l_request.m_TimerValue = g_MmConfigReaderObj->m_ISD_Invoke_Timer;
   g_sc.sendMsg(this, &l_request);

   DLOG(0, 0, "Sending MapDelimiterReq Req");
   MapDelimiterReq l_del(l_isdDlgId);
   g_sc.sendMsg(this, &l_del);
   return true;
}

//bool StandaloneISD::FillIsdV3(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd)
bool StandaloneISD::FillIsdV3(OMAP3_InsertSubscriberDataArg *l_isd)
{
   //DLOG(0,0,"Inside Fill ISD for Dialog ID %d",DlgId);
   int pLen,len;
   pLen = 0;
   len = 0;
   char l_value[10];
   memset(l_value, '\0', 10);
   DLOG(0,0,"ISD data length configured is %d bytes",g_MmConfigReaderObj->m_IsdLen);
   switch(index)
   {
      case OMAP3_InsertSubscriberDataArg_imsi_present://80000000
         {
            l_isd->bit_mask = OMAP3_InsertSubscriberDataArg_imsi_present;
            len = l_imsi.length();
            l_isd->imsi.length = (len+1)/2;
            u8 imsi[16];
            memset(imsi,'\0',sizeof(imsi));
            strcpy((char *)imsi,l_imsi.c_str());
            StringToBCD(l_isd->imsi.value,imsi, len);
            len = len + 10;
            pLen = len;
            TLOG(0, 0, "Added IMSI %s, length %d",l_imsi.c_str(),l_imsi.length());
         }

      case OMAP3_InsertSubscriberDataArg_msisdn_present://40000000
         {
            if(l_msisdn.length())
            {
               l_isd->bit_mask |= OMAP3_InsertSubscriberDataArg_msisdn_present;
               u8 finalMsisdn[21];
               memset(finalMsisdn, '\0', sizeof(finalMsisdn));
               strncpy((char *)finalMsisdn,"19",2);
               LLOG(0,0,"Received MSISDN %s",l_msisdn.c_str());
               strncat((char *)finalMsisdn,l_msisdn.c_str(),l_msisdn.length());
               int len2 = strlen((char *)finalMsisdn);
               l_isd->msisdn.length = (len2+1)/2;
               StringToBCD(l_isd->msisdn.value,finalMsisdn,len2);
               len += 3+l_isd->msisdn.length;
            }

         }

      case OMAP3_gprsSubscriptionData_present: //00010000
         {
            if(m_isd.gprssi.PdpId)
            {
               len = CheckLengthV3(l_isd);
               int ChkRet = m_isd.gprssi.formgprssi(l_isdDlgId,l_isd,len);
               TLOG(0,0,"Returned back from GPRS Subscription data,val %d",ChkRet);
               if ( ChkRet == 1)
               {
                  //DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                  TLOG(0,0,"No GPRS subscription data added  in this chunk");
                  index = OMAP3_gprsSubscriptionData_present;
                  l_isd->bit_mask &= (~OMAP3_gprsSubscriptionData_present);
                  m_isd.gprssi.m_FormedTill = 0;
                  return true;
               }
               else if(ChkRet == 2)
               {
                  TLOG(0,0,"GPRS subscription data added till count %d",m_isd.gprssi.m_FormedTill);
                  index = OMAP3_gprsSubscriptionData_present;
                  return true;
               }
               else
               {
                  TLOG(0,0,"All GprsSubscriptionData added");
               }
               DLOG(0,0,"The Encoding length till here is %d GPRS SUBSCRIPTION DATA added %d",len,(len-pLen));
               pLen = len;
            }
         }

      case OMAP3_InsertSubscriberDataArg_bearerServiceList_present: //08000000
         {
            int l_OldCount = 0;
            if(l_bearerService.length() > 0)
            {
               l_isd->bearerServiceList.count = 0;
               if(m_FirstFilled == false)
               {
                  DLOG(0, 0, "Inside Bearer service list C1");
                  for(int i = 1; i <= 27; i++)
                  {
                     sprintf(l_value, "VAL_%02d", i);
                     string l_valueChar = ConfigReader::readValue(l_bearerService, l_value);
                     if(l_valueChar.length() > 0)
                     {
                        DLOG(0,0,"Bearer Service Code [%s]", l_valueChar.c_str());
                        l_isd->bearerServiceList.value[l_isd->bearerServiceList.count].length = 1;
                        l_isd->bearerServiceList.value[l_isd->bearerServiceList.count].value[0] = atoi(l_valueChar.c_str());
                        l_isd->bearerServiceList.count += 1;
                     }                  
                  }
                  if(l_isd->bearerServiceList.count != 0)
                     l_isd->bit_mask |= OMAP3_InsertSubscriberDataArg_bearerServiceList_present;
                  len = CheckLengthV3(l_isd);
                  if(len >= g_MmConfigReaderObj->m_IsdLen)
                  {
                     DLOG(0, 0, "Current length is %d sending till previous length %d", len, pLen);
                     index = OMAP3_InsertSubscriberDataArg_bearerServiceList_present;
                     l_isd->bit_mask &= (~OMAP3_InsertSubscriberDataArg_bearerServiceList_present);
                     m_FirstFilled = false;
                     flag = true;
                     break;
                  }
                  m_FirstFilled = true;
                  l_OldCount = l_isd->bearerServiceList.count;
               }
               if(m_FirstFilled == true)
               {
                  DLOG(0, 0, "Inside Bearer service list C2");
                  for(int i = 28; i <= 42; i++)
                  {
                     sprintf(l_value, "VAL_%02d", i);
                     string l_valueChar = ConfigReader::readValue(l_bearerService, l_value);
                     if(l_valueChar.length() > 0)
                     {
                        l_isd->bit_mask |= OMAP3_InsertSubscriberDataArg_bearerServiceList_present;
                        DLOG(0,0,"Bearer Service Code [%s]", l_valueChar.c_str());
                        l_isd->bearerServiceList.value[l_isd->bearerServiceList.count].length = 1;
                        l_isd->bearerServiceList.value[l_isd->bearerServiceList.count].value[0] = atoi(l_valueChar.c_str());
                        l_isd->bearerServiceList.count += 1;
                     }
                  }
                  if(l_isd->bearerServiceList.count != 0)
                     l_isd->bit_mask |= OMAP3_InsertSubscriberDataArg_bearerServiceList_present;
                  len = CheckLengthV3(l_isd);
                  if(len >= g_MmConfigReaderObj->m_IsdLen)
                  {
                     DLOG(0, 0, "Current length is %d sending till previous length %d", len, pLen);
                     index = OMAP3_InsertSubscriberDataArg_bearerServiceList_present;
                     m_FirstFilled = true;
                     l_isd->bearerServiceList.count = l_OldCount;
                     if(l_isd->bearerServiceList.count == 0)
                        l_isd->bit_mask &= (~OMAP3_InsertSubscriberDataArg_bearerServiceList_present);
                     flag = true;
                     break;
                  }
               }
               DLOG(0, 0, "The Encoding length till here is %d BEARER SERVICE added %d", len, (len - pLen));
               pLen = len;
               flag = false;
               index = OMAP3_InsertSubscriberDataArg_teleserviceList_present;
            }
            pLen = len;
         }
      case OMAP3_InsertSubscriberDataArg_teleserviceList_present: //04000000
         {
            if(l_teleService.length() > 0)
            {
               DLOG(0,0,"Inside Teleservice list");
               l_isd->teleserviceList.count = 0;
               for(int i = 1; i <= 20; i++)
               {
                  sprintf(l_value, "VAL_%02d", i);
                  string l_valueChar = ConfigReader::readValue(l_teleService, l_value);
                  if(0 < l_valueChar.length())
                  {
                     l_isd->bit_mask |= OMAP3_InsertSubscriberDataArg_teleserviceList_present;
                     DLOG(0,0,"Tele Service Code [%s]", l_valueChar.c_str());
                     l_isd->teleserviceList.value[l_isd->teleserviceList.count].length = 1;
                     l_isd->teleserviceList.value[l_isd->teleserviceList.count].value[0] = atoi(l_valueChar.c_str());
                     l_isd->teleserviceList.count += 1;
                  }
               }
               len = len + 5 + (l_isd->teleserviceList.count * 3); 
               if(len  > g_MmConfigReaderObj->m_IsdLen)
               {
                  DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                  index = OMAP3_InsertSubscriberDataArg_teleserviceList_present;
                  l_isd->bit_mask &= (~OMAP3_InsertSubscriberDataArg_teleserviceList_present);
                  flag = true;
                  break;
               }
               DLOG(0,0,"The Encoding length till here is %d TELE SERVICE added %d",len,(len-pLen));
               pLen = len;
               flag = false;
               index = OMAP3_provisionedSS_present;
            }
            pLen = len;
         }
      case OMAP3_provisionedSS_present: //02000000
         {
            DLOG(0,0,"Inside Provisioned SS");
            if(l_ssPresent)
            {
               switch(SsIndex)
               {
                  case OMAP3_Ext_SS_Info_forwardingInfo_chosen: //choice 1
                     {
                        l_isd->bit_mask |= OMAP3_provisionedSS_present;
                        l_isd->provisionedSS.count = 0;
                        DLOG(0,0,"Going to add FWD info, CFWD State is %d",m_isd.pss.CFWD_STATE);
                        //int rret = m_isd.pss.formFwdSS3(DlgId,l_isd,g_MmConfigReaderObj->m_IsdLen);
                        int rret = m_isd.pss.formFwdSS3(l_isd);
                        if(l_isd->provisionedSS.count == 0)
                           l_isd->bit_mask &= (~OMAP3_provisionedSS_present);
                        if(1 == rret)
                        {
                           DLOG(0,0,"Sending ISD till Teleservice previous length %d",len,pLen);
                           index = OMAP3_provisionedSS_present;
                           l_isd->bit_mask &= (~OMAP3_provisionedSS_present);
                           SsIndex = OMAP3_Ext_SS_Info_forwardingInfo_chosen;
                           m_isd.pss.val = 0;
                           DLOG(0,0,"Reset Count to %d, CFWD State is %d",m_isd.pss.val,m_isd.pss.CFWD_STATE);
                           flag = true;
                           break;
                        }
                        else if(2 == rret)
                        {
                           DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                           index = OMAP3_provisionedSS_present;
                           SsIndex = OMAP3_Ext_SS_Info_forwardingInfo_chosen;
                           m_isd.pss.val = 0;
                           DLOG(0,0,"Reset val to %d, CFWD State is %d",m_isd.pss.val,m_isd.pss.CFWD_STATE);
                           flag = true;
                           break;
                        }

                        else
                        {
                           DLOG(0,0,"After Call FWD unconditional Info");
                           index = OMAP3_provisionedSS_present;
                           flag = false;
                           SsIndex = OMAP3_Ext_SS_Info_callBarringInfo_chosen;
                           DLOG(0,0,"The Encoding length till here is %d PROVISIONEDSS added %d",len,(len-pLen));
                           pLen = len;
                        }
                     }
                     //break;
                  case OMAP3_Ext_SS_Info_callBarringInfo_chosen: //choice 2
                     {
                        l_isd->bit_mask |= OMAP3_provisionedSS_present;
                        DLOG(0,0,"going to add CB info, SS Count value is %d, CB State is %d",m_isd.pss.val,m_isd.pss.CB_STATE);
                        //int reet = m_isd.pss.formCbSS3(DlgId,l_isd,g_MmConfigReaderObj->m_IsdLen);
                        int reet = m_isd.pss.formCbSS3(l_isd);
                        if(l_isd->provisionedSS.count == 0)
                        {
                           l_isd->bit_mask &= (~OMAP3_provisionedSS_present);
                        }
                        if(2 == reet)
                        {
                           DLOG(0,0,"On addition of Call barring data length limit exeeded,sending till previous");
                           index = OMAP3_provisionedSS_present;
                           SsIndex = OMAP3_Ext_SS_Info_callBarringInfo_chosen;
                           m_isd.pss.val = 0;
                           DLOG(0,0,"Reset val to %d",m_isd.pss.val);
                           flag = true;
                           break;
                        }
                        if(1 == reet)
                        {
                           DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                           index = OMAP3_provisionedSS_present;
                           DLOG(0,0,"Length after adding CB is %d",len);
                           l_isd->bit_mask &= (~OMAP3_provisionedSS_present);
                           SsIndex = OMAP3_Ext_SS_Info_callBarringInfo_chosen;
                           m_isd.pss.val = 0;
                           DLOG(0,0,"Reset count to %d",m_isd.pss.val);
                           flag = true;
                           break;
                        }
                        flag = false;
                        SsIndex = OMAP3_Ext_SS_Info_ss_Data_chosen;
                        DLOG(0,0,"Length after adding CB is %d",len);
                        DLOG(0,0,"The Encoding length till here is %d PROVISIONEDSS added %d",len,(len-pLen));
                        pLen = len;
                     }
                     //break;
                  case OMAP3_Ext_SS_Info_ss_Data_chosen:
                     {
                        l_isd->bit_mask |= OMAP3_provisionedSS_present;
                        DLOG(0,0,"Going to form Ext_SS_Info Count here is %d",m_isd.pss.val);
                        int PrevSS = m_isd.pss.val;
                        //int rett = m_isd.pss.formSsSS3(DlgId,l_isd,g_MmConfigReaderObj->m_IsdLen);
                        int rett = m_isd.pss.formSsSS3(l_isd);
                        len = g_AsnCodecO3.getEncodingLength(OMAP3_InsertSubscriberDataArg_PDU,l_isd);
                        DLOG(0,0,"Retruned from General SS Count here is %d return value is %d",m_isd.pss.val,rett);
                        if(rett == 1)
                        {
                           DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                           index = OMAP3_provisionedSS_present;
                           DLOG(0,0,"Length after adding SS is %d\n",len);
                           l_isd->bit_mask &= (~OMAP3_provisionedSS_present);
                           SsIndex = OMAP3_Ext_SS_Info_ss_Data_chosen;
                           index = OMAP3_provisionedSS_present;
                           flag = true;
                           //SendIsdV3(l_UserDlgId,l_request,l_isd,index,VcsiIndex,ScsiIndex,SsIndex,MsgOpCode);
                           break;
                        }
                        else if(rett == 2)
                        {
                           DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                           DLOG(0,0,"Length after adding SS is %d\n",len);
                           DLOG(0,0,"Count = %d\n",PrevSS);
                           //if(PrevSS == 0)
                           // l_isd->bit_mask &= (~OMAP3_provisionedSS_present);
                           SsIndex = OMAP3_Ext_SS_Info_ss_Data_chosen;
                           index = OMAP3_provisionedSS_present;
                           m_isd.pss.val = 0;
                           DLOG(0,0,"Reset val to %d",m_isd.pss.val);
                           flag = true;
                           //SendIsdV3(l_UserDlgId,l_request,l_isd,index,VcsiIndex,ScsiIndex,SsIndex,MsgOpCode);
                           break;
                        }
                        else
                        {
                           if(m_isd.pss.val == 0)
                           {
                              l_isd->bit_mask &= (~OMAP3_provisionedSS_present);
                           }
                           flag = false;
                           SsIndex = OMAP3_emlpp_Info_chosen;
                           DLOG(0,0,"The Encoding length till here is %d PROVISIONEDSS added %d",len,(len-pLen));
                           pLen = len;
                        }
                     }
                     //break;

                  case OMAP3_emlpp_Info_chosen:
                     {
                        l_isd->bit_mask |= OMAP3_provisionedSS_present;
                        DLOG(0,0,"Inside Emlpp for Count %d",m_isd.pss.val);
                        int retu = 0;
                        //retu = m_isd.pss.formEmSS3(DlgId,l_isd,g_MmConfigReaderObj->m_IsdLen);
                        retu = m_isd.pss.formEmSS3(l_isd);
                        DLOG(0,0,"Return value is  %d",retu);
                        DLOG(0,0,"Finished adding Emlpp in Provisioned SS data and returned to ISDData");
                        if(retu == 1)
                        {
                           DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                           index = OMAP3_provisionedSS_present;
                           l_isd->bit_mask &= (~OMAP3_provisionedSS_present);
                           SsIndex = OMAP3_emlpp_Info_chosen;
                           m_isd.pss.val = 0;
                           DLOG(0,0,"Reset count to %d\n",m_isd.pss.val);
                           flag = true;
                           //SendIsdV3(l_UserDlgId,l_request,l_isd,index,VcsiIndex,ScsiIndex,SsIndex,MsgOpCode);
                           break;
                        }
                        else if(retu == 2)
                        {
                           DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                           index = OMAP3_provisionedSS_present;
                           //l_isd->bit_mask &= (~OMAP3_provisionedSS_present);
                           SsIndex = OMAP3_emlpp_Info_chosen;
                           m_isd.pss.val = 0;
                           DLOG(0,0,"Reset count to %d\n",m_isd.pss.val);
                           flag = true;
                           //SendIsdV3(l_UserDlgId,l_request,l_isd,index,VcsiIndex,ScsiIndex,SsIndex,MsgOpCode);
                           break;
                        }
                        else
                        {
                           DLOG(0,0,"SS Count obtained here is %d\n",m_isd.pss.val);
                           if(m_isd.pss.val == 0)
                           {
                              l_isd->bit_mask &= (~OMAP3_provisionedSS_present);
                           }
                           flag = false;
                           SsIndex = 0;//OMAP3_Ext_SS_Info_callBarringInfo_chosen;
                           DLOG(0,0,"The Encoding length till here is %d PROVISIONEDSS added %d",len,(len-pLen));
                           pLen = len;
                        }
                     }//break;
                  default://Must not come here
                     {
                        //DLOG(0,0,"Inside Default\n");
                        SsIndex = 0;
                        index = OMAP3_odb_Data_present;
                     }
                     //break;
               }
            }
            if(flag)
               break;
            else
            {
               DLOG(0,0,"After Provisioned SS,continuing with remaing ISD");
               //g_AsnCodecO3.printPdu(OMAP3_InsertSubscriberDataArg_PDU,l_isd,1,0);
               index = OMAP3_odb_Data_present;
            }
            index = OMAP3_odb_Data_present;
         }
#if 1
      case OMAP3_odb_Data_present: //01000000
         {
            if(l_ODB.length())
            {
               unsigned int l_ConvertedODB = 0;
               DLOG(0,0,"Checking ODB data");
               l_isd->odb_Data.odb_GeneralData.length = 0;
               string l_valu = ConfigReader::readValue(l_ODB,"HPLMN_DATA");

               DLOG(0,0,"HPLMN Data len %d, val %ld ",l_valu.length(),atoi(l_valu.c_str()));
               if(l_valu.length() > 0)
               {
                  if(atoi(l_valu.c_str()))
                  {
                     l_isd->bit_mask |= OMAP3_subscriberStatus_present;
                     l_isd->subscriberStatus = OMAP3_SubscriberStatus_operatorDeterminedBarring; 
                     union Hdata
                     {
                        unsigned int l_Hodb;
                        unsigned char l_testHOdb[4];
                     };
                     Hdata l_HomOdb;
                     //memset(l_HomOdb,'\0',sizeof(Hdata));
                     l_HomOdb.l_Hodb =  HplmnOdb(atoi(l_valu.c_str()));
                     l_isd->odb_Data.odb_HPLMN_Data.value[0] = l_HomOdb.l_testHOdb[0];
                     l_isd->bit_mask |= OMAP3_odb_Data_present;
                     l_isd->odb_Data.bit_mask = OMAP3_odb_HPLMN_Data_present;
                     l_isd->odb_Data.odb_HPLMN_Data.length = 4;
                     LLOG(0,0,"Added ODB HPLMN specific Data %s len %d value %02x",l_valu.c_str(),l_isd->odb_Data.odb_HPLMN_Data.length,l_isd->odb_Data.odb_HPLMN_Data.value[0]);
                  }
                  else
                  {
                     l_isd->bit_mask |= OMAP3_subscriberStatus_present;
                     l_isd->subscriberStatus = OMAP3_serviceGranted;
                     LLOG(0,0,"No HPLMN ODB data present, Set subscriber status to service granted");
                  }
               }
               string l_val = ConfigReader::readValue(l_ODB,"GEN_DATA");

               unsigned int l_GenOdb_DB = atol(l_val.c_str());
               if(m_ssn == 7)
               {
                  //
                  //Added in 1.0.8.0 for sending ALL_OG_CALLS_BARRED when OG_CALLS_BARRED_WHEN_ROAMING set and subsriber is in roaming
                  //
                  if((l_GenOdb_DB & OG_CALLS_BARRED_WHEN_ROAMING) && (0 != m_Roaming_indicator))
                  {
                     LLOG(0,0,"Subscriber is in Roaming and OG_CALLS_BARRED_WHEN_ROAMING set, overriding with  ALL_OG_CALLS_BARRED");
                     l_GenOdb_DB |= ALL_OG_CALLS_BARRED;
                  }
                  //
                  //End Added in 1.0.8.0
                  //
                  l_ConvertedODB = l_GenOdb_DB & VLR_SUPPORTED_ODB;
               }
               else
               {
                  l_ConvertedODB = l_GenOdb_DB & SGSN_SUPPORTED_ODB;
               }
               LLOG(0,0,"General ODB len %d, val %ld ConvSupported Val %ld",l_val.length(),atol(l_val.c_str()),l_ConvertedODB);
               if(l_val.length() > 0)
               {

                  TLOG(0,0,"ODB LENGTH PRESENT");
                  m_ODBflag = true;
                  if(l_ConvertedODB)
                  {
                     l_isd->bit_mask |= OMAP3_subscriberStatus_present;
                     l_isd->subscriberStatus = OMAP3_SubscriberStatus_operatorDeterminedBarring;
                     union data
                     {
                        unsigned int l_Godb;
                        unsigned char l_testOdb[4];
                     };
                     data l_GenOdb;
                     l_GenOdb.l_Godb = l_ConvertedODB;

#ifdef SunOS
                     memcpy(l_isd->odb_Data.odb_GeneralData.value,l_GenOdb.l_testOdb,4);
#else
                     l_isd->odb_Data.odb_GeneralData.value[0]=l_GenOdb.l_testOdb[3];
                     l_isd->odb_Data.odb_GeneralData.value[1]=l_GenOdb.l_testOdb[2];
                     l_isd->odb_Data.odb_GeneralData.value[2]=l_GenOdb.l_testOdb[1];
                     l_isd->odb_Data.odb_GeneralData.value[3]=l_GenOdb.l_testOdb[0];
#endif
                     l_isd->bit_mask |= OMAP3_odb_Data_present;
                     int l_Genlen = getNumberOfSignificantBitsForAnArray(l_isd->odb_Data.odb_GeneralData.value,4);
                     if(l_Genlen >= 15)
                     {
                        l_isd->odb_Data.odb_GeneralData.length =  l_Genlen;
                     }
                     else
                     {
                        l_isd->odb_Data.odb_GeneralData.length = 15;
                     }
                     LLOG(0,0,"Added ODB General Data %s length %d, value %02x%02x%02x%02x",l_val.c_str(),l_isd->odb_Data.odb_GeneralData.length,l_isd->odb_Data.odb_GeneralData.value[0],l_isd->odb_Data.odb_GeneralData.value[1],l_isd->odb_Data.odb_GeneralData.value[2],l_isd->odb_Data.odb_GeneralData.value[3]);
                  }
                  else
                  {
                     if(atoi(l_valu.c_str()) == 0)
                     {
                        l_isd->bit_mask |= OMAP3_subscriberStatus_present;
                        l_isd->subscriberStatus = OMAP3_serviceGranted;
                        LLOG(0,0,"No General ODB data present, Set subscriber status to service granted");
                        l_isd->bit_mask &= (~OMAP3_odb_Data_present);
                     }
                  }
               }
               if ((len = CheckLengthV3(l_isd)) >= g_MmConfigReaderObj->m_IsdLen)
               {
                  DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                  index = OMAP3_odb_Data_present;
                  l_isd->bit_mask &= (~OMAP3_odb_Data_present);
                  flag = true;
                  //SendIsdV3(l_UserDlgId,l_request,l_isd,index,VcsiIndex,ScsiIndex,SsIndex,MsgOpCode);
                  break;
               }
               DLOG(0,0,"The Encoding length till here is %d ODB_DATA added %d",len,(len-pLen));
               pLen = len;
            }
            DLOG(0,0,"After odb data");
            index = OMAP3_InsertSubscriberDataArg_roamingRestrictionDueToUnsupportedFeature_present;
         }
         //break;
      case OMAP3_vlrCamelSubscriptionInfo_present://00080000
         {
            int LenBeforeCSI = CheckLengthV3(l_isd);
            //m_isd.vlrcsi.vcsi.rcvd_camel_phase = 0;
            DLOG(0,0,"Length before VLR CSI info is %d",LenBeforeCSI);
            if(l_VcsiPresent)
            {
               DLOG(0,0,"To add VLR CSI for ISD");
               l_isd->bit_mask |= OMAP3_vlrCamelSubscriptionInfo_present;
               l_isd->vlrCamelSubscriptionInfo.bit_mask = 0;
               DLOG(0,0,"Forming VLR Camel Subscription information Index value here is %x, VcsiIndex value is %x",index,VcsiIndex);
               switch(VcsiIndex)
               {
                  case OMAP3_VlrCamelSubscriptionInfo_o_CSI_present://8000
                     {
                        if((m_isd.vlrcsi.vcsi.ocsi != 0)&& (m_isd.vlrcsi.vcsi.rcvd_camel_phase >= 1))
                        {
                           //m_isd.vlrcsi.formOCsi(DlgId,l_isd);
                           m_isd.vlrcsi.formOCsi(l_isd);
                           DLOG(0,0,"Returned to ISDData from OCSI");
                           if ((len = CheckLengthV3(l_isd)) >= g_MmConfigReaderObj->m_IsdLen)
                           {
                              DLOG(0,0,"Length limit exceeded in OCSI,removing VLR CSI info");
                              index = OMAP3_vlrCamelSubscriptionInfo_present;
                              VcsiIndex = OMAP3_VlrCamelSubscriptionInfo_o_CSI_present;
                              l_isd->vlrCamelSubscriptionInfo.bit_mask &= (~OMAP3_VlrCamelSubscriptionInfo_o_CSI_present);
                              l_isd->bit_mask &= (~OMAP3_vlrCamelSubscriptionInfo_present);
                              flag = true;
                              //SendIsdV3(DlgId,l_request,l_isd,index,VcsiIndex,ScsiIndex,SsIndex,MsgOpCode);
                              break;
                           }
                           DLOG(0,0,"The Encoding length till OCSI info is %d VLR CAMEL SUBSCRIPTION INFO added %d",len,(len-pLen));
                           pLen = len;
                           flag = false;
                        }
                        index = OMAP3_vlrCamelSubscriptionInfo_present;
                        VcsiIndex = OMAP3_VlrCamelSubscriptionInfo_ss_CSI_present;
                     }
                     //break

                  case OMAP3_VlrCamelSubscriptionInfo_ss_CSI_present://2000
                     {
                        if((m_isd.vlrcsi.vcsi.sscsi != 0) && (m_isd.vlrcsi.vcsi.rcvd_camel_phase >= 2))
                        {
                           //m_isd.vlrcsi.formSsCsi(DlgId,l_isd);
                           m_isd.vlrcsi.formSsCsi(l_isd);
                           DLOG(0,0,"Returned from SS CSI");
                           if ((len = CheckLengthV3(l_isd)) >= g_MmConfigReaderObj->m_IsdLen)
                           {
                              DLOG(0,0,"Length limit exceeded in SSCSI,removing VLR CSI info");
                              index = OMAP3_vlrCamelSubscriptionInfo_present;
                              VcsiIndex = OMAP3_VlrCamelSubscriptionInfo_o_CSI_present;
                              l_isd->vlrCamelSubscriptionInfo.bit_mask &= (~OMAP3_VlrCamelSubscriptionInfo_ss_CSI_present);
                              l_isd->bit_mask &= (~OMAP3_vlrCamelSubscriptionInfo_present);
                              flag = true;
                              //SendIsdV3(DlgId,l_request,l_isd,index,VcsiIndex,ScsiIndex,SsIndex,MsgOpCode);
                              break;
                           }
                           DLOG(0,0,"The Encoding length till SSCSI info is %d VLR CAMEL SUBSCRIPTION INFO added %d",len,(len-pLen));
                           pLen = len;
                           flag = false;
                        }
                        index = OMAP3_vlrCamelSubscriptionInfo_present;
                        VcsiIndex = OMAP3_VlrCamelSubscriptionInfo_tif_CSI_present;
                     }
                     //break;
                  case OMAP3_VlrCamelSubscriptionInfo_tif_CSI_present://0800
                     {
                        if((m_isd.vlrcsi.vcsi.tifcsi != 0) && (m_isd.vlrcsi.vcsi.rcvd_camel_phase >= 2))
                        {
                           //m_isd.vlrcsi.formTifCsi(DlgId,l_isd);
                           m_isd.vlrcsi.formTifCsi(l_isd);
                           DLOG(0,0,"Returned from TIF CSI");
                           if ((len = CheckLengthV3(l_isd)) >= g_MmConfigReaderObj->m_IsdLen)
                           {
                              DLOG(0,0,"Length limit exceeded in TIF CSI,removing VLR CSI info");
                              index = OMAP3_vlrCamelSubscriptionInfo_present;
                              VcsiIndex = OMAP3_VlrCamelSubscriptionInfo_o_CSI_present;
                              l_isd->vlrCamelSubscriptionInfo.bit_mask &= (~OMAP3_VlrCamelSubscriptionInfo_tif_CSI_present);
                              l_isd->bit_mask &= (~OMAP3_vlrCamelSubscriptionInfo_present);
                              flag = true;
                              //SendIsdV3(DlgId,l_request,l_isd,index,VcsiIndex,ScsiIndex,SsIndex,MsgOpCode);
                              break;
                           }
                           DLOG(0,0,"The Encoding length till TIFCSI info is %d VLR CAMEL SUBSCRIPTION INFO added %d",len,(len-pLen));
                           pLen = len;
                           flag = false;
                        }
                        index = OMAP3_vlrCamelSubscriptionInfo_present;
                        VcsiIndex = OMAP3_VlrCamelSubscriptionInfo_o_BcsmCamelTDP_CriteriaList_present;
                     }
                     //break;


                  case OMAP3_VlrCamelSubscriptionInfo_o_BcsmCamelTDP_CriteriaList_present://1000
                     {
                        if((m_isd.vlrcsi.vcsi.ocsi != 0) && (m_isd.vlrcsi.vcsi.rcvd_camel_phase >= 2))
                        {
                           //m_isd.vlrcsi.formObcsmTdp(DlgId,l_isd);
                           m_isd.vlrcsi.formObcsmTdp(l_isd);
                           DLOG(0,0,"Returned to ISDData from O_BCSM_TDP Criteria List");
                           if ((len = CheckLengthV3(l_isd)) >= g_MmConfigReaderObj->m_IsdLen)
                           {
                              DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                              index = OMAP3_vlrCamelSubscriptionInfo_present;
                              VcsiIndex = OMAP3_VlrCamelSubscriptionInfo_o_BcsmCamelTDP_CriteriaList_present;
                              l_isd->vlrCamelSubscriptionInfo.bit_mask &= (~OMAP3_VlrCamelSubscriptionInfo_o_BcsmCamelTDP_CriteriaList_present);
                              //l_isd->bit_mask &= (~OMAP3_vlrCamelSubscriptionInfo_present);
                              flag = true;
                              //SendIsdV3(DlgId,l_request,l_isd,index,VcsiIndex,ScsiIndex,SsIndex,MsgOpCode);
                              break;
                           }
                           DLOG(0,0,"The Encoding length till OBCSM TDP Criteria info is %d VLR CAMEL SUBSCRIPTION INFO added %d",len,(len-pLen));
                           pLen = len;
                           flag = false;
                        }
                        index = OMAP3_vlrCamelSubscriptionInfo_present;
                        VcsiIndex = OMAP3_VlrCamelSubscriptionInfo_m_CSI_present;
                     }
                     //break;

                  case OMAP3_VlrCamelSubscriptionInfo_m_CSI_present://400
                     {
                        index = OMAP3_vlrCamelSubscriptionInfo_present;
                        VcsiIndex = OMAP3_VlrCamelSubscriptionInfo_mo_sms_CSI_present;
                     }
                     //break;
                  case OMAP3_VlrCamelSubscriptionInfo_mo_sms_CSI_present://200
                     {
                        if((m_isd.vlrcsi.vcsi.mosmscsi != 0) && (m_isd.vlrcsi.vcsi.rcvd_camel_phase >= 3))
                        {
                           //m_isd.vlrcsi.formMosCsi(DlgId,l_isd);
                           m_isd.vlrcsi.formMosCsi(l_isd);
                           DLOG(0,0,"Returned to ISDData from MO SMS CSI");
                           if ((len = CheckLengthV3(l_isd)) >= g_MmConfigReaderObj->m_IsdLen)
                           {
                              DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                              index = OMAP3_vlrCamelSubscriptionInfo_present;
                              VcsiIndex = OMAP3_VlrCamelSubscriptionInfo_mo_sms_CSI_present;
                              l_isd->vlrCamelSubscriptionInfo.bit_mask &= (~OMAP3_VlrCamelSubscriptionInfo_mo_sms_CSI_present);
                              //l_isd->bit_mask &= (~OMAP3_vlrCamelSubscriptionInfo_present);
                              flag = true;
                              //SendIsdV3(DlgId,l_request,l_isd,index,VcsiIndex,ScsiIndex,SsIndex,MsgOpCode);
                              break;
                           }
                           DLOG(0,0,"The Encoding length till MOSMSCSI is %d VLR CAMEL SUBSCRIPTION INFO added %d",len,(len-pLen));
                           pLen = len;
                           flag = false;
                        }
                        index = OMAP3_vlrCamelSubscriptionInfo_present;
                        VcsiIndex = OMAP3_VlrCamelSubscriptionInfo_vt_CSI_present;
                     }
                     //break;
                  case OMAP3_VlrCamelSubscriptionInfo_vt_CSI_present://100
                     {
                        index = OMAP3_vlrCamelSubscriptionInfo_present;
                        VcsiIndex = OMAP3_VlrCamelSubscriptionInfo_t_BCSM_CAMEL_TDP_CriteriaList_present;
                     }
                     //break;
                  case OMAP3_VlrCamelSubscriptionInfo_t_BCSM_CAMEL_TDP_CriteriaList_present://80
                     {
                        index = OMAP3_vlrCamelSubscriptionInfo_present;
                        VcsiIndex = OMAP3_VlrCamelSubscriptionInfo_d_CSI_present;
                     }
                     //break;
                  case OMAP3_VlrCamelSubscriptionInfo_d_CSI_present://40
                     {
                        if((m_isd.vlrcsi.vcsi.dcsi != 0) && (m_isd.vlrcsi.vcsi.rcvd_camel_phase >= 3))
                        {
                           //m_isd.vlrcsi.formDCsi(DlgId,l_isd);
                           m_isd.vlrcsi.formDCsi(l_isd);
                           DLOG(0,0,"Returned to ISDData from DCSI");
                           if ((len = CheckLengthV3(l_isd)) >= g_MmConfigReaderObj->m_IsdLen)
                           {
                              DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                              index = OMAP3_vlrCamelSubscriptionInfo_present;
                              VcsiIndex = OMAP3_VlrCamelSubscriptionInfo_d_CSI_present;
                              l_isd->vlrCamelSubscriptionInfo.bit_mask &= (~OMAP3_VlrCamelSubscriptionInfo_d_CSI_present);
                              //l_isd->bit_mask &= (~OMAP3_vlrCamelSubscriptionInfo_present);
                              flag = true;
                              //SendIsdV3(DlgId,l_request,l_isd,index,VcsiIndex,ScsiIndex,SsIndex,MsgOpCode);
                              break;
                           }
                           DLOG(0,0,"The Encoding length till DCSI info is %d VLR CAMEL SUBSCRIPTION INFO added %d",len,(len-pLen));
                           pLen = len;
                           flag = false;
                        }
                        index = OMAP3_vlrCamelSubscriptionInfo_present;
                        VcsiIndex = OMAP3_VlrCamelSubscriptionInfo_mt_sms_CSI_present;
                     }
                     //break;
                  case OMAP3_VlrCamelSubscriptionInfo_mt_sms_CSI_present://20
                     {
                        if((m_isd.vlrcsi.vcsi.mtsmscsi != 0) && (m_isd.vlrcsi.vcsi.rcvd_camel_phase == 4))
                        {
                           //m_isd.vlrcsi.formMtsCsi(DlgId,l_isd);
                           m_isd.vlrcsi.formMtsCsi(l_isd);
                           DLOG(0,0,"Returned to ISDData from MT SMS CSI");
                           if ((len = CheckLengthV3(l_isd)) >= g_MmConfigReaderObj->m_IsdLen)
                           {
                              DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                              index = OMAP3_vlrCamelSubscriptionInfo_present;
                              VcsiIndex = OMAP3_VlrCamelSubscriptionInfo_mt_sms_CSI_present;
                              l_isd->vlrCamelSubscriptionInfo.bit_mask &= (~OMAP3_VlrCamelSubscriptionInfo_mt_sms_CSI_present);
                              //l_isd->bit_mask &= (~OMAP3_vlrCamelSubscriptionInfo_present);
                              flag = true;
                              //SendIsdV3(DlgId,l_request,l_isd,index,VcsiIndex,ScsiIndex,SsIndex,MsgOpCode);
                              break;
                           }
                           DLOG(0,0,"The Encoding length till MTSMSCSI is %d VLR CAMEL SUBSCRIPTION INFO added %d",len,(len-pLen));
                           pLen = len;
                           flag = false;
                        }
                        index = OMAP3_VlrCamelSubscriptionInfo_mt_smsCAMELTDP_CriteriaList_present;
                        VcsiIndex = OMAP3_VlrCamelSubscriptionInfo_mt_smsCAMELTDP_CriteriaList_present;
                     }
                     //break;
                  case OMAP3_VlrCamelSubscriptionInfo_mt_smsCAMELTDP_CriteriaList_present://10
                     {
                        if((m_isd.vlrcsi.vcsi.mtsmscsi != 0) && (m_isd.vlrcsi.vcsi.rcvd_camel_phase == 4))
                        {
                           //m_isd.vlrcsi.formMtsTdp(DlgId,l_isd);
                           m_isd.vlrcsi.formMtsTdp(l_isd);
                           DLOG(0,0,"Returned to ISDData from MTSMS TDP criteria list");
                           if ((len = CheckLengthV3(l_isd)) >= g_MmConfigReaderObj->m_IsdLen)
                           {
                              DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                              index = OMAP3_vlrCamelSubscriptionInfo_present;
                              VcsiIndex = OMAP3_VlrCamelSubscriptionInfo_mt_smsCAMELTDP_CriteriaList_present;
                              l_isd->vlrCamelSubscriptionInfo.bit_mask &= (~OMAP3_VlrCamelSubscriptionInfo_mt_smsCAMELTDP_CriteriaList_present);
                              //l_isd->bit_mask &= (~OMAP3_vlrCamelSubscriptionInfo_present);
                              flag = true;
                              //SendIsdV3(DlgId,l_request,l_isd,index,VcsiIndex,ScsiIndex,SsIndex,MsgOpCode);
                              break;
                           }
                           DLOG(0,0,"The Encoding length till MOSMSCSI is %d VLR CAMEL SUBSCRIPTION INFO added %d",len,(len-pLen));
                           //pLen = len;
                           flag = false;
                        }
                        index = OMAP3_InsertSubscriberDataArg_extensionContainer_present;
                        VcsiIndex = 0;
                     }
                     //break;
                  default:
                     {
                     }                     
               }//Switch case
            }//dbisd3.VLRCSI
            if(flag)
               break;
            else
            {
               DLOG(0,0,"Len after adding VLR CSI is %d",len);
            }
            if((len - LenBeforeCSI) < 4)
               l_isd->bit_mask &= (~OMAP3_vlrCamelSubscriptionInfo_present);
            pLen = len;
            DLOG(0,0,"After VLR Camel subscription info,continuing with remaing ISD");
            //DLOG(0,0,"\nEnd of VLRCSI ==> Index value here %x VcsiIndex value here %x\n",index,VcsiIndex);
            index = OMAP3_InsertSubscriberDataArg_extensionContainer_present;
            VcsiIndex = 0;
         }
         //break;
      case OMAP3_mc_SS_Info_present: //00000100
         {
            DLOG(0,0,"Before MC_SS_info");
            if(l_ssPresent)
            {
               //l_isd->bit_mask |= OMAP3_mc_SS_Info_present;
               //m_isd.pss.formMcSS(DlgId,l_isd);
               m_isd.pss.formMcSS(l_isd);
               if ((len = CheckLengthV3(l_isd)) >= g_MmConfigReaderObj->m_IsdLen)
               {
                  DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                  index = OMAP3_mc_SS_Info_present;
                  l_isd->bit_mask &= (~OMAP3_mc_SS_Info_present);
                  //SendIsdV3(DlgId,l_request,l_isd,index,VcsiIndex,ScsiIndex,SsIndex,MsgOpCode);
                  break;
               }
               DLOG(0,0,"The Encoding length till here is %d SS INFO PRESENT added %d",len,(len-pLen));
               pLen = len;
            }
            index = OMAP3_cs_AllocationRetentionPriority_present;
         }
         //break;
      case OMAP3_sgsn_CAMEL_SubscriptionInfo_present: //00000040
         {
            //DLOG(0,0,"Before SGSN Camel Subscription info\n");
            int LenBeforeSCSI = 0;
            flag = false;
            if(l_ScsiPresent)
            {
               LenBeforeSCSI = CheckLengthV3(l_isd);
               DLOG(0,0,"Length before SGSN CSI info is %d",LenBeforeSCSI);
               l_isd->bit_mask |= OMAP3_sgsn_CAMEL_SubscriptionInfo_present;
               l_isd->sgsn_CAMEL_SubscriptionInfo.bit_mask = 0;
               DLOG(0,0,"Forming SGSN Camel Subscription information,Index value here is %x, VcsiIndex value is %x",index,ScsiIndex);
               //g_AsnCodecO3.printPdu(OMAP3_InsertSubscriberDataArg_PDU,l_isd,1,0);
               switch(ScsiIndex)
               {
                  case OMAP3_SGSN_CAMEL_SubscriptionInfo_gprs_CSI_present://0x80
                     {
                        if(m_isd.Sgsncsi.scsi.gcsi)
                        {
                           //m_isd.Sgsncsi.formGprsCsi(DlgId,l_isd);
                           m_isd.Sgsncsi.formGprsCsi(l_isd);
                           DLOG(0,0,"Finished adding SGSN CSI and returned to ISDData");
                           if ((len = CheckLengthV3(l_isd)) >=g_MmConfigReaderObj->m_IsdLen)
                           {
                              DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                              index = OMAP3_sgsn_CAMEL_SubscriptionInfo_present;
                              ScsiIndex = OMAP3_SGSN_CAMEL_SubscriptionInfo_gprs_CSI_present;
                              l_isd->bit_mask &= (~OMAP3_sgsn_CAMEL_SubscriptionInfo_present);
                              flag = true;
                              //SendIsdV3(DlgId,l_request,l_isd,index,VcsiIndex,ScsiIndex,SsIndex,MsgOpCode);
                              break;
                           }
                           DLOG(0,0,"The Encoding length till here is %d SGSN CAMEL SUBSCRIPTION INFO added %d",len,(len-pLen));
                           pLen = len;
                        }
                        index = OMAP3_sgsn_CAMEL_SubscriptionInfo_present;
                        ScsiIndex = OMAP3_SGSN_CAMEL_SubscriptionInfo_mo_sms_CSI_present;
                     }
                     //break;
                  case OMAP3_SGSN_CAMEL_SubscriptionInfo_mo_sms_CSI_present://0x40
                     {
                        if(m_isd.Sgsncsi.scsi.mosmscsi)
                        {
                           //m_isd.Sgsncsi.formMosmsCsi(DlgId,l_isd);
                           m_isd.Sgsncsi.formMosmsCsi(l_isd);
                           DLOG(0,0,"Finished adding SGSN CSI and returned to ISDData");
                           if ((len = CheckLengthV3(l_isd)) >=g_MmConfigReaderObj->m_IsdLen)
                           {
                              DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                              index = OMAP3_sgsn_CAMEL_SubscriptionInfo_present;
                              ScsiIndex = OMAP3_SGSN_CAMEL_SubscriptionInfo_extensionContainer_present;
                              //l_isd->bit_mask &= (~OMAP3_sgsn_CAMEL_SubscriptionInfo_present);
                              l_isd->sgsn_CAMEL_SubscriptionInfo.bit_mask &= (~OMAP3_SGSN_CAMEL_SubscriptionInfo_mo_sms_CSI_present);
                              flag = true;
                              //SendIsdV3(DlgId,l_request,l_isd,index,VcsiIndex,ScsiIndex,SsIndex,MsgOpCode);
                              break;
                           }
                           DLOG(0,0,"The Encoding length till here is %d SGSN CAMEL SUBSCRIPTION INFO added %d",len,(len-pLen));
                           pLen = len;
                        }
                        index = OMAP3_sgsn_CAMEL_SubscriptionInfo_present;
                        ScsiIndex = OMAP3_SGSN_CAMEL_SubscriptionInfo_extensionContainer_present;
                     }
                     //break;
                  case OMAP3_SGSN_CAMEL_SubscriptionInfo_extensionContainer_present://0x20
                     {
                        index = OMAP3_sgsn_CAMEL_SubscriptionInfo_present;
                        ScsiIndex = OMAP3_SGSN_CAMEL_SubscriptionInfo_mt_sms_CSI_present;
                     }
                     //break;
                  case OMAP3_SGSN_CAMEL_SubscriptionInfo_mt_sms_CSI_present://0x10
                     {
                        if(m_isd.Sgsncsi.scsi.mtsmscsi)
                        {
                           //m_isd.Sgsncsi.formMtsmsCsi(DlgId,l_isd);
                           m_isd.Sgsncsi.formMtsmsCsi(l_isd);
                           DLOG(0,0,"Finished adding SGSN CSI and returned to ISDData");
                           if ((len = CheckLengthV3(l_isd)) >= g_MmConfigReaderObj->m_IsdLen)
                           {
                              DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                              index = OMAP3_sgsn_CAMEL_SubscriptionInfo_present;
                              ScsiIndex = OMAP3_SGSN_CAMEL_SubscriptionInfo_mt_sms_CSI_present;
                              //l_isd->bit_mask &= (~OMAP3_sgsn_CAMEL_SubscriptionInfo_present);
                              l_isd->sgsn_CAMEL_SubscriptionInfo.bit_mask &= (~OMAP3_SGSN_CAMEL_SubscriptionInfo_mt_sms_CSI_present);
                              flag = true;
                              //SendIsdV3(DlgId,l_request,l_isd,index,VcsiIndex,ScsiIndex,SsIndex,MsgOpCode);
                              break;
                           }
                           DLOG(0,0,"The Encoding length till here is %d SGSN CAMEL SUBSCRIPTION INFO added %d",len,(len-pLen));
                           pLen = len;
                        }
                        index = OMAP3_sgsn_CAMEL_SubscriptionInfo_present;
                        ScsiIndex = OMAP3_SGSN_CAMEL_SubscriptionInfo_mt_smsCAMELTDP_CriteriaList_present;
                     }
                     //break;
                  case OMAP3_SGSN_CAMEL_SubscriptionInfo_mt_smsCAMELTDP_CriteriaList_present://0x08
                     {
                        if(m_isd.Sgsncsi.scsi.mtsmscsi)
                        {
                           //m_isd.Sgsncsi.formMtcritList(DlgId,l_isd);
                           m_isd.Sgsncsi.formMtcritList(l_isd);
                           DLOG(0,0,"Finished adding SGSN CSI and returned to ISDData");
                           if ((len = CheckLengthV3(l_isd)) >= g_MmConfigReaderObj->m_IsdLen)
                           {
                              DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                              index = OMAP3_sgsn_CAMEL_SubscriptionInfo_present;
                              ScsiIndex = OMAP3_SGSN_CAMEL_SubscriptionInfo_mt_smsCAMELTDP_CriteriaList_present;
                              //l_isd->bit_mask &= (~OMAP3_sgsn_CAMEL_SubscriptionInfo_present);
                              l_isd->sgsn_CAMEL_SubscriptionInfo.bit_mask &= (~OMAP3_SGSN_CAMEL_SubscriptionInfo_mt_smsCAMELTDP_CriteriaList_present);
                              flag = true;
                              //SendIsdV3(DlgId,l_request,l_isd,index,VcsiIndex,ScsiIndex,SsIndex,MsgOpCode);
                              break;
                           }
                           DLOG(0,0,"The Encoding length till here is %d SGSN CAMEL SUBSCRIPTION INFO added %d",len,(len-pLen));
                           pLen = len;
                        }
                        index = OMAP3_sgsn_CAMEL_SubscriptionInfo_present;
                        ScsiIndex = OMAP3_SGSN_CAMEL_SubscriptionInfo_mg_csi_present;
                     }
                     //break;
                  case OMAP3_SGSN_CAMEL_SubscriptionInfo_mg_csi_present://0x04
                     {                      
                        DLOG(0,0,"Finished adding SGSN CSI and returned to ISDData");
                        index = OMAP3_InsertSubscriberDataArg_chargingCharacteristics_present;
                        ScsiIndex = 0;
                     }
                     //break;
                  default:
                     {
                     }
               }
            }
            if(flag)
               break;
            else
               if((len - LenBeforeSCSI) < 5)
                  l_isd->bit_mask &= (~OMAP3_sgsn_CAMEL_SubscriptionInfo_present);
            DLOG(0,0,"After SGSN Camel subscription info,continuing with remaing ISD");
            index = OMAP3_InsertSubscriberDataArg_chargingCharacteristics_present;
            ScsiIndex = 0;
         }
         //break;
      case OMAP3_ue_ReachabilityRequestIndicator_present: //00000001
         {
            index = 00000000;
            DLOG(0,0,"All data for ISD added,sending the ISD");
            //SendIsdV3(DlgId,l_request,l_isd,index,VcsiIndex,ScsiIndex,SsIndex,MsgOpCode);
            break;
         }
      default:
         {
         }
#endif
   }
   return true;
}

//bool StandaloneISD::FillIsdV2(int DlgId,OMAP2_InsertSubscriberDataArg *l_isd)
bool StandaloneISD::FillIsdV2(OMAP2_InsertSubscriberDataArg *l_isd)
{
   //DLOG(0,0,"Inside Fill ISD for Dialog ID %d",DlgId);
   int pLen,len;
   pLen = 0;
   len = 0;
   //g_MmConfigReaderObj->m_IsdLen = g_MmConfigReaderObj->m_IsdLen;
   DLOG(0,0,"ISD data length configured is %d bytes",g_MmConfigReaderObj->m_IsdLen);
   switch(index)
   {
      DLOG(0,0,"Inside switch index");
      case OMAP2_InsertSubscriberDataArg_imsi_present://8000
      {
         DLOG(0,0,"Adding IMSI");
         l_isd->bit_mask = OMAP2_InsertSubscriberDataArg_imsi_present;
         len = l_imsi.length();
         l_isd->imsi.length = (len+1)/2;
         u8 imsi[16];
         memset(imsi,'\0',sizeof(imsi));
         strcpy((char *)imsi,l_imsi.c_str());
         StringToBCD(l_isd->imsi.value,imsi, len);
         DLOG(0, 0, "Added IMSI %s",l_imsi.c_str());
         len = l_isd->imsi.length + 10;
         DLOG(0,0,"Length after adding IMSI is %d",len);         
         index = OMAP2_InsertSubscriberDataArg_msisdn_present;//4000;
         pLen = len;
      }
      case OMAP2_InsertSubscriberDataArg_msisdn_present: //4000
      {
         if(l_msisdn.length())
         {
            DLOG(0,0,"Adding MSISDN %s",l_msisdn.c_str());
            l_isd->bit_mask |= OMAP2_InsertSubscriberDataArg_msisdn_present;
            u8 finalMsisdn[20];
            memset(finalMsisdn,'\0',sizeof(finalMsisdn));
            strncpy((char *)finalMsisdn,"19",2);
            strncat((char *)finalMsisdn,l_msisdn.c_str(),l_msisdn.length());
            int len2 = strlen((char *)finalMsisdn);
            l_isd->msisdn.length = (len2+1)/2;
            StringToBCD(l_isd->msisdn.value,finalMsisdn,len2);
            len += (3+ l_isd->msisdn.length);
            DLOG(0,0,"The Encoding length till here is %d MSISDN added %d",len,(len-pLen));
            pLen = len;
            index = OMAP2_category_present;
         }
      }

      char l_value[10];
      memset(l_value, '\0', 10);

      case OMAP2_InsertSubscriberDataArg_bearerServiceList_present: //0800
      {
         int l_OldCount = 0;
         if(l_bearerService.length() > 0)
         {
            l_isd->bearerServiceList.count = 0;
            if(!m_FirstFilled)
            {
               DLOG(0, 0, "Inside Bearer service list C1");
               for(int i = 1; i <= 27; i++)
               {
                  sprintf(l_value, "VAL_%02d", i);
                  string l_valueChar = ConfigReader::readValue(l_bearerService, l_value);
                  if(l_valueChar.length() > 0)
                  {
                     DLOG(0,0,"Bearer Service Code [%s]", l_valueChar.c_str());
                     l_isd->bearerServiceList.value[l_isd->bearerServiceList.count].length = 1;
                     l_isd->bearerServiceList.value[l_isd->bearerServiceList.count].value[0] = atoi(l_valueChar.c_str());
                     l_isd->bearerServiceList.count += 1;
                  }                  
               }
               if(l_isd->bearerServiceList.count != 0)
                  l_isd->bit_mask |= OMAP2_InsertSubscriberDataArg_bearerServiceList_present;
               len = len + 5 + (l_isd->bearerServiceList.count * 3);
               len = CheckLengthV2(l_isd);
               if(len >= g_MmConfigReaderObj->m_IsdLen)
               {
                  DLOG(0, 0, "Current length is %d sending till previous length %d", len, pLen);
                  index = OMAP2_InsertSubscriberDataArg_bearerServiceList_present;
                  l_isd->bit_mask &= (~OMAP2_InsertSubscriberDataArg_bearerServiceList_present);
                  m_FirstFilled = false;
                  flag = true;
                  break;
               }
               m_FirstFilled = true;
               l_OldCount = l_isd->bearerServiceList.count;
            }
            if(m_FirstFilled == true) 
            {
               DLOG(0, 0, "Inside Bearer service list C2");
               for(int i = 28; i <= 42; i++)
               {
                  sprintf(l_value, "VAL_%02d", i);
                  string l_valueChar = ConfigReader::readValue(l_bearerService, l_value);
                  if(l_valueChar.length() > 0)
                  {
                     l_isd->bit_mask |= OMAP2_InsertSubscriberDataArg_bearerServiceList_present;
                     DLOG(0,0,"Bearer Service Code [%s]", l_valueChar.c_str());
                     l_isd->bearerServiceList.value[l_isd->bearerServiceList.count].length = 1;
                     l_isd->bearerServiceList.value[l_isd->bearerServiceList.count].value[0] = atoi(l_valueChar.c_str());
                     l_isd->bearerServiceList.count += 1;
                  }
               }
               if(l_isd->bearerServiceList.count != 0)
                  l_isd->bit_mask |= OMAP2_InsertSubscriberDataArg_bearerServiceList_present;
               len = len + 5 + (l_isd->bearerServiceList.count * 3);
               len = CheckLengthV2(l_isd);
               if(len >= g_MmConfigReaderObj->m_IsdLen)
               {
                  DLOG(0, 0, "Current length is %d sending till previous length %d", len, pLen);
                  index = OMAP2_InsertSubscriberDataArg_bearerServiceList_present;
                  m_FirstFilled = true;
                  flag = true;
                  l_isd->bearerServiceList.count = l_OldCount;
                  if(l_isd->bearerServiceList.count == 0)
                     l_isd->bit_mask &= (~OMAP2_InsertSubscriberDataArg_bearerServiceList_present);
                  break;
               }
            }
            DLOG(0, 0, "The Encoding length till here is %d BEARER SERVICE added %d", len, (len - pLen));
            pLen = len;
            flag = false;
            index = OMAP2_InsertSubscriberDataArg_teleserviceList_present;
         }
         pLen = len;
         index = OMAP2_InsertSubscriberDataArg_teleserviceList_present;
      }

      case OMAP2_InsertSubscriberDataArg_teleserviceList_present: //0400
      {
         if(l_teleService.length() > 0)
         {
            DLOG(0,0,"Inside Teleservice list");
            l_isd->teleserviceList.count = 0;
            for(int i = 1; i <= 20; i++)
            {
               sprintf(l_value, "VAL_%02d", i);
               string l_valueChar = ConfigReader::readValue(l_teleService, l_value);
               DLOG(0,0,"Read value %s, data %s",l_value,l_valueChar.c_str());
               if(0 < l_valueChar.length())
               {
                  l_isd->bit_mask |= OMAP2_InsertSubscriberDataArg_teleserviceList_present;
                  l_isd->teleserviceList.value[l_isd->teleserviceList.count].length = 1;
                  l_isd->teleserviceList.value[l_isd->teleserviceList.count].value[0] = atoi(l_valueChar.c_str());
                  l_isd->teleserviceList.count += 1;
               }
            }
            len = len + 5 + (l_isd->teleserviceList.count * 3);
            if (len >= g_MmConfigReaderObj->m_IsdLen)
            {
               DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
               index = OMAP2_InsertSubscriberDataArg_teleserviceList_present;
               l_isd->bit_mask &= (~OMAP2_InsertSubscriberDataArg_teleserviceList_present);
               //SendIsdV2(l_UserDlgId,l_request,l_isd,index,SsIndex,MsgOpCode);
               break;
            }
            DLOG(0,0,"The Encoding length till here is %d TELE SERVICE LIST added %d",len,(len-pLen));
            pLen = len;
         }
         index = OMAP2_provisionedSS_present;
      }

      case OMAP2_provisionedSS_present: //0200
      {
         if(l_ssPresent)
         {
            switch(SsIndex)
            {
               case OMAP2_Ext_SS_Info_forwardingInfo_chosen: //choice 1
                  {
                     l_isd->bit_mask |= OMAP2_provisionedSS_present;
                     DLOG(0,0,"going to add Call FWD info");
                     // DLOG(0,0,"SS Count value is %d\n",m_isd.pss.val);
                     DLOG(0,0,"CFWD State is %d",m_isd.pss.CFWD_STATE);
                     len = CheckLengthV2(l_isd);
                     //int rret = m_isd.pss.formFwdSS2(DlgId,l_isd,g_MmConfigReaderObj->m_IsdLen);
                     int rret = m_isd.pss.formFwdSS2(l_isd);

                     if(1 == rret)
                     {
                        DLOG(0,0,"Current length exceeded sending till previous length %d",pLen);
                        DLOG(0,0,"Length after adding CFWD is %d\n",len);
                        index = OMAP2_provisionedSS_present;
                        l_isd->bit_mask &= (~OMAP2_provisionedSS_present);
                        SsIndex = OMAP2_Ext_SS_Info_forwardingInfo_chosen;
                        m_isd.pss.val = 0;
                        DLOG(0,0,"Reset count to %d",m_isd.pss.val);
                        DLOG(0,0,"CFWD State is %d",m_isd.pss.CFWD_STATE);
                        flag = true;
                        //SendIsdV2(l_UserDlgId,l_request,l_isd,index,SsIndex,MsgOpCode);
                        break;
                     }
                     else if(2 == rret)
                     {
                        DLOG(0,0,"Current length exceeded sending till previous length %d",len);
                        DLOG(0,0,"Length after adding CFWD is %d\n",len);
                        index = OMAP2_provisionedSS_present;
                        //l_isd->bit_mask &= (~OMAP2_provisionedSS_present);
                        SsIndex = OMAP2_Ext_SS_Info_forwardingInfo_chosen;
                        m_isd.pss.val = 0;
                        DLOG(0,0,"Reset val to %d",m_isd.pss.val);
                        DLOG(0,0,"CFWD State is %d",m_isd.pss.CFWD_STATE);
                        flag = true;
                        //SendIsdV2(l_UserDlgId,l_request,l_isd,index,SsIndex,MsgOpCode);
                        break;
                     }

                     else
                     {
                        if(m_isd.pss.val == 0)
                        {
                           l_isd->bit_mask &= (~OMAP2_provisionedSS_present);
                        }
                        DLOG(0,0,"Added Call FWD Info\n");
                        index = OMAP2_provisionedSS_present;
                        flag = false;
                        SsIndex = OMAP2_Ext_SS_Info_callBarringInfo_chosen;
                        DLOG(0,0,"Length after adding CFWD is %d",len);
                        DLOG(0,0,"The Encoding length till here is %d PROVISIONEDSS added %d",len,(len-pLen));
                        pLen = len;
                     }
                  }
                  //break;
               case OMAP2_Ext_SS_Info_callBarringInfo_chosen: //choice 2
                  {
                     l_isd->bit_mask |= OMAP2_provisionedSS_present;
                     DLOG(0,0,"going to add CB info,SS Count value is %d, CB State is %d",m_isd.pss.val,m_isd.pss.CB_STATE);
                     //int reet = m_isd.pss.formCbSS2(DlgId,l_isd,g_MmConfigReaderObj->m_IsdLen);
                     int reet = m_isd.pss.formCbSS2(l_isd);
                     len = g_AsnCodecO2.getEncodingLength(OMAP2_InsertSubscriberDataArg_PDU,l_isd);
                     DLOG(0,0,"Returned from CbSS3, return value is %d",reet);
                     if(2 == reet)
                     {
                        DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                        index = OMAP2_provisionedSS_present;
                        DLOG(0,0,"Length after adding CB is %d",len);
                        //l_isd->bit_mask &= (~OMAP3_provisionedSS_present);
                        SsIndex = OMAP2_Ext_SS_Info_callBarringInfo_chosen;
                        m_isd.pss.val = 0;
                        DLOG(0,0,"Reset count to %d",m_isd.pss.val);
                        flag = true;
                        //SendIsdV2(l_UserDlgId,l_request,l_isd,index,SsIndex,MsgOpCode);
                        break;
                     }


                     if(1 == reet)
                     {
                        DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                        index = OMAP2_provisionedSS_present;
                        l_isd->bit_mask &= (~OMAP2_provisionedSS_present);
                        SsIndex = OMAP2_Ext_SS_Info_callBarringInfo_chosen;
                        m_isd.pss.val = 0;
                        DLOG(0,0,"Reset count to %d\n",m_isd.pss.val);
                        flag = true;
                        //SendIsdV2(l_UserDlgId,l_request,l_isd,index,SsIndex,MsgOpCode);
                        break;
                     }
                     if(m_isd.pss.val == 0)
                     {
                        l_isd->bit_mask &= (~OMAP2_provisionedSS_present);
                     }
                     flag = false;
                     SsIndex = OMAP2_Ext_SS_Info_ss_Data_chosen;
                     //len = g_AsnCodecO2.getEncodingLength(OMAP2_InsertSubscriberDataArg_PDU,l_isd);
                     DLOG(0,0,"Length after adding CB is %d",len);
                     DLOG(0,0,"The Encoding length till here is %d PROVISIONEDSS added %d",len,(len-pLen));
                     pLen = len;
                  }
                  //break;
               case OMAP2_Ext_SS_Info_ss_Data_chosen:
                  {
                     l_isd->bit_mask |= OMAP2_provisionedSS_present;
                     DLOG(0,0,"Going to form Ext_SS_Info val here is %d",m_isd.pss.val);
                     int PrevSS = m_isd.pss.val;
                     //int rett = m_isd.pss.formSsSS2(DlgId,l_isd,g_MmConfigReaderObj->m_IsdLen);
                     int rett = m_isd.pss.formSsSS2(l_isd);
                     len = g_AsnCodecO2.getEncodingLength(OMAP2_InsertSubscriberDataArg_PDU,l_isd);
                     DLOG(0,0," Count here is %d return value is %d",m_isd.pss.val,rett);
                     DLOG(0,0,"Finished adding SS INFO Provisioned SS data and returned to ISDData");
                     if(rett == 1)
                     {
                        DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                        index = OMAP2_provisionedSS_present;
                        DLOG(0,0,"Length after adding SS is %d\n",len);
                        l_isd->bit_mask &= (~OMAP2_provisionedSS_present);
                        SsIndex = OMAP2_Ext_SS_Info_ss_Data_chosen;
                        index = OMAP2_provisionedSS_present;
                        flag = true;
                        //SendIsdV2(l_UserDlgId,l_request,l_isd,index,SsIndex,MsgOpCode);
                        break;
                     }
                     else if(rett == 2)
                     {
                        DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                        index = OMAP2_provisionedSS_present;
                        DLOG(0,0,"Length after adding SS Data is %d",len);
                        DLOG(0,0,"PrevSS = %d",PrevSS);
                        // if(PrevSS == 0)
                        //   l_isd->bit_mask &= (~OMAP3_provisionedSS_present);
                        SsIndex = OMAP2_Ext_SS_Info_ss_Data_chosen;
                        index = OMAP2_provisionedSS_present;
                        m_isd.pss.val = 0;
                        DLOG(0,0,"Reset count to %d",m_isd.pss.val);
                        flag = true;
                        //SendIsdV2(l_UserDlgId,l_request,l_isd,index,SsIndex,MsgOpCode);
                        break;
                     }
                     else
                     {
                        if(m_isd.pss.val == 0)
                        {
                           l_isd->bit_mask &= (~OMAP2_provisionedSS_present);
                        }
                        flag = false;
                        SsIndex = 0;//OMAP2_emlpp_Info_chosen;
                        DLOG(0,0,"Length after adding SS is %d\n",len);
                        DLOG(0,0,"The Encoding length till here is %d PROVISIONEDSS added %d",len,(len-pLen));
                        pLen = len;
                     }
                  }
                  //break;

               default://Must not come here
                  {
                     //DLOG(0,0,"Inside Default\n");
                     SsIndex = 0;
                     index = OMAP2_odb_Data_present;
                  }
                  //break;

            }
         }
         if(flag)
            break;
         else
         {
            DLOG(0,0,"After Provisioned SS,continuing with remaing ISD");
            //g_AsnCodecO3.printPdu(OMAP3_InsertSubscriberDataArg_PDU,l_isd,1,0);
            index = OMAP2_odb_Data_present;
         }
         //index = OMAP2_odb_Data_present;
      }

      case OMAP2_odb_Data_present: //0100
      {
         unsigned int l_ConvertedODB = 0;
         if(1)//odb_Data)
         {
            DLOG(0,0,"Checking ODB");            
            unsigned int l_hlodb = 0;
            l_isd->odb_Data.odb_GeneralData.length = 0;
            string l_val2 = ConfigReader::readValue(l_ODB,"HPLMN_DATA");
            if(l_val2.length() > 0)
            {
               if(atoi(l_val2.c_str()))
               {
                  unsigned int l_hodb = atoi(l_val2.c_str());
                  unsigned int l_map2HODB = HplmnOdb(l_hodb);
                  l_hlodb =  map3tomap2odb(l_map2HODB);
                  if(l_hlodb > 0)
                  {
                     l_isd->bit_mask |= OMAP2_subscriberStatus_present;
                     l_isd->subscriberStatus = OMAP2_SubscriberStatus_operatorDeterminedBarring;
                     l_isd->bit_mask |= OMAP2_odb_Data_present;
                     l_isd->odb_Data.bit_mask = OMAP2_odb_HPLMN_Data_present;
                     l_isd->odb_Data.odb_HPLMN_Data.value[0]  = l_hlodb;
                     l_isd->odb_Data.odb_HPLMN_Data.length = 4;
                     LLOG(0,0,"ODB HPLMN data Value read %ld, v2 data %d, length %d, value %02x",l_hodb,l_hlodb,l_isd->odb_Data.odb_HPLMN_Data.length,l_isd->odb_Data.odb_HPLMN_Data.value[0]);
                  }
                  else
                  {
                     WLOG(0,0,"Value of ODB data for MAP V2 is %d value read %ld, not adding it",l_hlodb,l_hodb);
                     return false;
                  }
               }
               else
               {
                  l_isd->bit_mask |= OMAP2_subscriberStatus_present;
                  l_isd->subscriberStatus = OMAP2_serviceGranted;
               }
            }
            string l_val1 = ConfigReader::readValue(l_ODB,"GEN_DATA");
            string l_val = ConfigReader::readValue(l_ODB,"GEN_DATA");
            unsigned int l_GenOdb_DB = atol(l_val.c_str());
            if(m_ssn == 7)
            {
               //
               //Added in 1.0.8.0 for sending ALL_OG_CALLS_BARRED when OG_CALLS_BARRED_WHEN_ROAMING set and subsriber is in roaming
               //
               if((l_GenOdb_DB & OG_CALLS_BARRED_WHEN_ROAMING) && (0 != m_Roaming_indicator))
               {
                  LLOG(0,0,"Subscriber is in Roaming and OG_CALLS_BARRED_WHEN_ROAMING set, overriding with  ALL_OG_CALLS_BARRED");
                  l_GenOdb_DB |= ALL_OG_CALLS_BARRED;
               }
               //
               //End Added in 1.0.8.0
               //
               l_ConvertedODB = l_GenOdb_DB & VLR_SUPPORTED_ODB;
            }
            //else
            //{
            //   l_ConvertedODB = atol(l_val.c_str()) & SGSN_SUPPORTED_ODB;
            //}
            if(l_val1.length() > 0)
            {
               TLOG(0,0,"ODB LENGTH PRESENT");
               m_ODBflag = true;
               if(atoi(l_val1.c_str()))
               {
                  unsigned int l_godb =  l_ConvertedODB;
                  unsigned int l_odb =  map3tomap2odb(l_godb); 
                  if(l_odb > 0)
                  {
                     l_isd->bit_mask |= OMAP2_subscriberStatus_present;
                     l_isd->subscriberStatus = OMAP2_SubscriberStatus_operatorDeterminedBarring;
                     l_isd->odb_Data.odb_GeneralData.value[0]  = l_odb;
                     l_isd->odb_Data.odb_GeneralData.length = 6;
                     l_isd->bit_mask |= OMAP2_odb_Data_present;
                     LLOG(0,0,"ODB General data value read %ld, V2 data %d, length %d, value %02x",l_godb,l_odb,l_isd->odb_Data.odb_GeneralData.length,l_isd->odb_Data.odb_GeneralData.value[0]);
                  }
                  else
                  {
                     WLOG(0,0,"Value of ODB data for MAP V2 is %d, Value read %ldnot adding it",l_odb,l_godb);
                     return false;
                  }
               }
               else
               {
                  if(l_hlodb == 0)
                  {
                     l_isd->bit_mask |= OMAP2_subscriberStatus_present;
                     l_isd->subscriberStatus = OMAP2_serviceGranted;
                  }
               }
            }
            if ((len = CheckLengthV2(l_isd)) >= g_MmConfigReaderObj->m_IsdLen)
            {
               DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
               index = OMAP2_odb_Data_present;
               l_isd->bit_mask &= (~OMAP2_odb_Data_present);
               //SendIsdV2(l_UserDlgId,l_request,l_isd,index,SsIndex,MsgOpCode);
               break;
            }
            DLOG(0,0,"The Encoding length till here is %d ODB DATA added %d",len,(len-pLen));
            pLen = len;
         }
         index = OMAP2_InsertSubscriberDataArg_roamingRestrictionDueToUnsupportedFeature_present;
      }

      case OMAP2_InsertSubscriberDataArg_roamingRestrictionDueToUnsupportedFeature_present: //0080
      {
         index = OMAP2_regionalSubscriptionData_present;
      }

      case OMAP2_regionalSubscriptionData_present: //0040
      {
         index = 00000000;
         //SendIsdV2(l_UserDlgId,l_request,l_isd,index,SsIndex,MsgOpCode);
         break;
      }
      default:
      break;
   }
   return true;
}


//void StandaloneISD::FillIsdV1(int DlgId,OMAP1_InsertSubscriberDataArg *l_isd)
bool StandaloneISD::FillIsdV1(OMAP1_InsertSubscriberDataArg *l_isd)
{
   DLOG(0,0,"Inside Fill ISD V1");
   int pLen,len;
   pLen = 0;
   len = 0;
   //g_MmConfigReaderObj->m_IsdLen = g_MmConfigReaderObj->m_IsdLen;
   DLOG(0,0,"ISD data length configured is %d bytes",g_MmConfigReaderObj->m_IsdLen);
   switch(index)
   {
      DLOG(0,0,"Inside switch index");
      case OMAP1_InsertSubscriberDataArg_imsi_present://0x80
      {
         DLOG(0,0,"Adding IMSI");
         l_isd->bit_mask |= OMAP1_InsertSubscriberDataArg_imsi_present;
         len = l_imsi.length();
         l_isd->imsi.length = (len+1)/2;
         u8 imsi[16];
         memset(imsi,'\0',sizeof(imsi));
         strcpy((char *)imsi,l_imsi.c_str());
         StringToBCD(l_isd->imsi.value,imsi,len);
         l_isd->imsi.value[l_isd->imsi.length - 1] |= 0xF0;
         len = l_isd->imsi.length + 10;
         DLOG(0,0,"Length after adding IMSI is %d",len);
         DLOG(0,0,"The Encoding length till here is %d TELE SERVICE LIST added %d",len,(len-pLen));
         pLen = len;
         index = OMAP1_InsertSubscriberDataArg_msIsdn_present;
      }
      //break;
      case OMAP1_InsertSubscriberDataArg_msIsdn_present://0x40
      {
         if(l_msisdn.length())
         {
            DLOG(0,0,"Adding MSISDN %s",l_msisdn.c_str());
            l_isd->bit_mask |= OMAP1_InsertSubscriberDataArg_msIsdn_present;
            u8 finalMsisdn[20];
            memset(finalMsisdn,'\0',sizeof(finalMsisdn));
            strncat((char *)finalMsisdn,"19",2);
            strncat((char *)finalMsisdn,l_msisdn.c_str(),l_msisdn.length());
            int len2 = strlen((char *)finalMsisdn);
            l_isd->msIsdn.length = (len2+1)/2;
            StringToBCD(l_isd->msIsdn.value,finalMsisdn,len2);
            len += (4 + l_isd->msIsdn.length );
            DLOG(0,0,"The Encoding length till here is %d MSISDN added %d",len,(len-pLen));
            pLen = len;
            index = OMAP1_InsertSubscriberDataArg_subscriberStatus_present;
         }
      }
      case OMAP1_InsertSubscriberDataArg_subscriberStatus_present:
      {
         string l_val1 = ConfigReader::readValue(l_ODB,"GEN_DATA");
         if(l_val1.length() > 0)
         {
            TLOG(0,0,"ODB LENGTH PRESENT");
            m_ODBflag = true;
            if(atoi(l_val1.c_str()))
            {
               LLOG(0,0,"Adding subscriber status for ODB");
               l_isd->bit_mask |= OMAP1_InsertSubscriberDataArg_subscriberStatus_present;
               l_isd->subscriberStatus = (OMAP1_SubscriberStatus)1;
               len +=5;
            }
            else
            {
               LLOG(0,0,"Adding subscriber status Service granted");
               l_isd->bit_mask |= OMAP1_InsertSubscriberDataArg_subscriberStatus_present;
               l_isd->subscriberStatus = (OMAP1_SubscriberStatus)0;
               len +=5;
            }
         }
         pLen = len;
      }
      //break;
      char l_value[10];
      memset(l_value, '\0', 10);
      case OMAP1_InsertSubscriberDataArg_bearerServiceList_present:
      {
         if(l_bearerService.length() > 0)
         {
            l_isd->bearerServiceList.count = 0;
            if(m_FirstFilled == false)
            {
               DLOG(0, 0, "Inside Bearer service list C1");
               for(int i = 1; i <= 27; i++)
               {
                  sprintf(l_value, "VAL_%02d", i);
                  string l_valueChar = ConfigReader::readValue(l_bearerService, l_value);
                  DLOG(0,0,"Read value %s, data %s",l_value,l_valueChar.c_str());
                  if(0 < l_valueChar.length())
                  {
                     l_isd->bearerServiceList.value[l_isd->bearerServiceList.count].length = 1;
                     l_isd->bearerServiceList.value[l_isd->bearerServiceList.count].value[0] = atoi(l_valueChar.c_str());
                     l_isd->bearerServiceList.count += 1;

                  }
               }
               if(l_isd->bearerServiceList.count >0)
                  l_isd->bit_mask |= OMAP1_InsertSubscriberDataArg_bearerServiceList_present;
               len = len + 5 + (l_isd->bearerServiceList.count * 3);
               if (len >= g_MmConfigReaderObj->m_IsdLen)
               {
                  DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                  index = OMAP1_InsertSubscriberDataArg_bearerServiceList_present;
                  l_isd->bit_mask &= (~OMAP1_InsertSubscriberDataArg_bearerServiceList_present);
                  m_FirstFilled = false;
                  //SendIsdV1(l_UserDlgId,l_request,l_isd,index,SsIndex,MsgOpCode);
                  break;
               }
               DLOG(0,0,"The Encoding length till here is %d BEARER SERVICE LIST added %d",len,(len-pLen));
               m_FirstFilled = true;
            }
            if(m_FirstFilled == true) 
            {
               DLOG(0, 0, "Inside Bearer service list C2");
               for(int i = 28; i <= 42; i++)
               {
                  sprintf(l_value, "VAL_%02d", i);
                  string l_valueChar = ConfigReader::readValue(l_bearerService, l_value);
                  DLOG(0,0,"Read value %s, data %s",l_value,l_valueChar.c_str());
                  if(0 < l_valueChar.length())
                  {
                     l_isd->bearerServiceList.value[l_isd->bearerServiceList.count].length = 1;
                     l_isd->bearerServiceList.value[l_isd->bearerServiceList.count].value[0] = atoi(l_valueChar.c_str());
                     m_FirstFilled = false;
                     l_isd->bearerServiceList.count += 1;

                  }
               }
               if(l_isd->bearerServiceList.count >0)
                  l_isd->bit_mask |= OMAP1_InsertSubscriberDataArg_bearerServiceList_present;
               len = len + 5 + (l_isd->bearerServiceList.count * 3);
               if (len >= g_MmConfigReaderObj->m_IsdLen)
               {
                  DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                  index = OMAP1_InsertSubscriberDataArg_bearerServiceList_present;
                  //l_isd->bit_mask &= (~OMAP1_InsertSubscriberDataArg_bearerServiceList_present);
                  m_FirstFilled = true;
                  break;
               }
               DLOG(0,0,"The Encoding length till here is %d BEARER SERVICE LIST added %d",len,(len-pLen));
            }
         }
         pLen = len;
         index = OMAP1_InsertSubscriberDataArg_teleserviceList_present;
      }
      //break;
      case OMAP1_InsertSubscriberDataArg_teleserviceList_present:
      {
         if(l_teleService.length() > 0)

         {
            DLOG(0,0,"Inside Teleservice list");
            l_isd->teleserviceList.count = 0;
            for(int i = 1; i <= 20; i++)
            {
               sprintf(l_value, "VAL_%02d", i);
               string l_valueChar = ConfigReader::readValue(l_teleService, l_value);
               DLOG(0,0,"Read value %s, data %s",l_value,l_valueChar.c_str());
               if(0 < l_valueChar.length())
               {
                  l_isd->bit_mask |= OMAP1_InsertSubscriberDataArg_teleserviceList_present;
                  l_isd->teleserviceList.value[l_isd->teleserviceList.count].length = 1;
                  l_isd->teleserviceList.value[l_isd->teleserviceList.count].value[0] = atoi(l_valueChar.c_str());
                  l_isd->teleserviceList.count += 1;
               }
            }
            len = len + 5 + (l_isd->teleserviceList.count * 3);
            if (len >= g_MmConfigReaderObj->m_IsdLen)
            {
               DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
               index = OMAP1_InsertSubscriberDataArg_teleserviceList_present;
               l_isd->bit_mask &= (~OMAP1_InsertSubscriberDataArg_teleserviceList_present);
               //SendIsdV1(l_UserDlgId,l_request,l_isd,index,SsIndex,MsgOpCode);
               break;
            }
            DLOG(0,0,"The Encoding length till here is %d BEARER SERVICE LIST added %d",len,(len-pLen));
            pLen = len;
         }
         index = OMAP1_InsertSubscriberDataArg_provisonedSS_present;

      }
      //break;
      case OMAP1_InsertSubscriberDataArg_provisonedSS_present:
      {
         if(l_ssPresent)
         {
            switch(SsIndex)
            {
               case OMAP1_forwardingInfo_chosen: //choice 1
                  {
                     l_isd->bit_mask |= OMAP1_InsertSubscriberDataArg_provisonedSS_present;
                     DLOG(0,0,"going to add CFWD FWD info,CFWD State is %d",m_isd.pss.CFWD_STATE);
                     //int rret = m_isd.pss.formFwdSS1(DlgId,l_isd,g_MmConfigReaderObj->m_IsdLen);
                     int rret = m_isd.pss.formFwdSS1(l_isd);
                     if(m_isd.pss.val == 0)
                     {
                        l_isd->bit_mask &= (~OMAP1_InsertSubscriberDataArg_provisonedSS_present);
                     }
                     if(1 == rret)
                     {
                        DLOG(0,0,"Current length exceeded sending till previous length %d",pLen);
                        DLOG(0,0,"Length after adding CFWD is %d",len);
                        index = OMAP1_InsertSubscriberDataArg_provisonedSS_present;
                        l_isd->bit_mask &= (~OMAP1_InsertSubscriberDataArg_provisonedSS_present);
                        SsIndex = OMAP1_forwardingInfo_chosen;
                        m_isd.pss.val = 0;
                        DLOG(0,0,"Reset val to %d",m_isd.pss.val);
                        DLOG(0,0,"CFWD State is %d",m_isd.pss.CFWD_STATE);
                        flag = true;
                        //SendIsdV1(l_UserDlgId,l_request,l_isd,index,SsIndex,MsgOpCode);
                        break;
                     }
                     else if(2 == rret)
                     {
                        DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                        DLOG(0,0,"Length after adding CFWD is %d",len);
                        index = OMAP1_InsertSubscriberDataArg_provisonedSS_present;
                        //l_isd->bit_mask &= (~OMAP3_provisionedSS_present);
                        SsIndex = OMAP1_forwardingInfo_chosen;
                        m_isd.pss.val = 0;
                        DLOG(0,0,"Reset count to %d",m_isd.pss.val);
                        DLOG(0,0,"CFWD State is %d",m_isd.pss.CFWD_STATE);
                        flag = true;
                        //SendIsdV1(l_UserDlgId,l_request,l_isd,index,SsIndex,MsgOpCode);
                        break;
                     }

                     else
                     {
                        if(m_isd.pss.val == 0)
                        {
                           l_isd->bit_mask &= (~OMAP1_InsertSubscriberDataArg_provisonedSS_present);
                        }
                        DLOG(0,0,"Added Call FWD unconditional Info");
                        index = OMAP1_InsertSubscriberDataArg_provisonedSS_present;
                        flag = false;
                        SsIndex = OMAP1_callBarringInfo_chosen;
                        DLOG(0,0,"Length after adding CFWD is %d",len);
                        DLOG(0,0,"The Encoding length till here is %d PROVISIONEDSS added %d",len,(len-pLen));
                        pLen = len;
                     }
                  }
                  //break;
               case OMAP1_callBarringInfo_chosen: //choice 2
                  {
                     l_isd->bit_mask |= OMAP1_InsertSubscriberDataArg_provisonedSS_present;
                     DLOG(0,0,"going to add CB info SS Count value is %d,CB State is %d",m_isd.pss.val,m_isd.pss.CB_STATE);
                     //int reet = m_isd.pss.formCbSS1(DlgId,l_isd,g_MmConfigReaderObj->m_IsdLen);
                     int l_len1 = CheckLengthV1(l_isd);
                     int reet = m_isd.pss.formCbSS1(l_isd,l_len1);
                     //DLOG(0,0,"Returned from CbSS3\n");
                     if(2 == reet)
                     {
                        DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                        index = OMAP1_InsertSubscriberDataArg_provisonedSS_present;
                        //DLOG(0,0,"else 2 , Length after adding CB is %d\n",g_AsnCodecO1.getEncodingLength(OMAP2_InsertSubscriberDataArg_PDU,l_isd));
                        //l_isd->bit_mask &= (~OMAP3_provisionedSS_present);
                        SsIndex = OMAP1_callBarringInfo_chosen;
                        m_isd.pss.val = 0;
                        DLOG(0,0,"Reset Count to %d",m_isd.pss.val);
                        flag = true;
                        //SendIsdV1(l_UserDlgId,l_request,l_isd,index,SsIndex,MsgOpCode);
                        break;
                     }


                     if(1 == reet)
                     {
                        DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                        index = OMAP1_InsertSubscriberDataArg_provisonedSS_present;
                        l_isd->bit_mask &= (~OMAP1_InsertSubscriberDataArg_provisonedSS_present);
                        SsIndex = OMAP1_callBarringInfo_chosen;
                        m_isd.pss.val = 0;
                        DLOG(0,0,"Reset count to %d",m_isd.pss.val);
                        flag = true;
                        //SendIsdV1(l_UserDlgId,l_request,l_isd,index,SsIndex,MsgOpCode);
                        break;
                     }

                     flag = false;
                     SsIndex = OMAP1_ss_Data_chosen;
                     len = g_AsnCodecO1.getEncodingLength(OMAP1_InsertSubscriberDataArg_PDU,l_isd);
                     DLOG(0,0,"Length after adding CB is %d\n",len);
                     DLOG(0,0,"The Encoding length till here is %d PROVISIONEDSS added %d",len,(len-pLen));
                     pLen = len;
                  }
                  //break;
               case OMAP1_ss_Data_chosen:
                  {
                     l_isd->bit_mask |= OMAP1_InsertSubscriberDataArg_provisonedSS_present;
                     DLOG(0,0,"Going to form Ext_SS_Info count here is %d",m_isd.pss.val);
                     int PrevSS = m_isd.pss.val;
                     //int rett = m_isd.pss.formSsSS1(DlgId,l_isd,g_MmConfigReaderObj->m_IsdLen);
                     int l_len2 = CheckLengthV1(l_isd);
                     int rett = m_isd.pss.formSsSS1(l_isd,l_len2);
                     DLOG(0,0,"SS -> Count here is %d return val is %d\n",m_isd.pss.val,rett);
                     DLOG(0,0,"Finished adding SS INFO Provisioned SS data and returned to ISDData");
                     if(rett == 1)
                     {
                        DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                        index = OMAP1_InsertSubscriberDataArg_provisonedSS_present;
                        DLOG(0,0,"Length after adding SS DATA is %d",len);
                        l_isd->bit_mask &= (~OMAP1_InsertSubscriberDataArg_provisonedSS_present);
                        SsIndex = OMAP1_ss_Data_chosen;
                        index = OMAP1_InsertSubscriberDataArg_provisonedSS_present;
                        flag = true;
                        //SendIsdV1(l_UserDlgId,l_request,l_isd,index,SsIndex,MsgOpCode);
                        break;
                     }
                     else if(rett == 2)
                     {
                        DLOG(0,0,"Current length is %d sending till previous length %d",len,pLen);
                        index = OMAP1_InsertSubscriberDataArg_provisonedSS_present;
                        DLOG(0,0,"Length after adding SS DATA is %d",len);
                        DLOG(0,0,"PrevSS = %d\n",PrevSS);
                        // if(PrevSS == 0)
                        //   l_isd->bit_mask &= (~OMAP3_provisionedSS_present);
                        SsIndex = OMAP1_ss_Data_chosen;
                        index = OMAP1_ss_Data_chosen;
                        m_isd.pss.val = 0;
                        DLOG(0,0,"Reset count to %d\n",m_isd.pss.val);
                        flag = true;
                        //SendIsdV1(l_UserDlgId,l_request,l_isd,index,SsIndex,MsgOpCode);
                        break;
                     }
                     else
                     {
                        if(m_isd.pss.val == 0)
                        {
                           l_isd->bit_mask &= (~OMAP1_InsertSubscriberDataArg_provisonedSS_present);
                        }
                        flag = false;
                        SsIndex = 0;
                        DLOG(0,0,"Length after adding SS Data is %d",len);
                        DLOG(0,0,"The Encoding length till here is %d PROVISIONEDSS added %d",len,(len-pLen));
                        pLen = len;
                     }
                  }
                  //break;
               default://Must not come here
                  {
                     SsIndex = 0;
                     index = 00;
                  }
                  //break;
            }
         }
         if(flag)
            break;
         else
         {
            index = 00;
         }
         index = 00;
         break;
      }
      //break;
      default:
      break;

   }
   return true;
}

int StandaloneISD::CheckLengthV3(OMAP3_InsertSubscriberDataArg *l_isd)
{
   int enclen=0;
   enclen = g_AsnCodecO3.getEncodingLength(OMAP3_InsertSubscriberDataArg_PDU, l_isd);
   return enclen;
}

int StandaloneISD::CheckLengthV2(OMAP2_InsertSubscriberDataArg *l_isd)
{
   int enclen=0;
   enclen = g_AsnCodecO2.getEncodingLength(OMAP2_InsertSubscriberDataArg_PDU, l_isd);
   return enclen;
}

int StandaloneISD::CheckLengthV1(OMAP1_InsertSubscriberDataArg *l_isd)
{
   int enclen=0;
   enclen = g_AsnCodecO1.getEncodingLength(OMAP1_InsertSubscriberDataArg_PDU, l_isd);
   return enclen;
}
