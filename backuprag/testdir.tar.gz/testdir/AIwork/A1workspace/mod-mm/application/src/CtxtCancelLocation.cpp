/************************************************************************************************************
 * File        : CancelLocation.cpp
 * Author      : VenkatRaman
 * Description : To Send Cancel Location whenever
 *               1. Modification affects the roaming permission for the subscriber and the subscriber record shall be removed from the VLR data base
 *               2. Withdrawal of non-GPRS Subscription caused by a change of Network Access Mode
 *               3. Modification affects the roaming permission for the subscriber and the subscriber record shall be removed from the SGSN data base
 *               4. Withdrawal of GPRS Subscription caused by a change of Network Access Mode
 *               5. Authentication algorithm or authentication key of the subscriber is modified
 * Created on  : July 1, 2010, 8:36 PM IST
 ************************************************************************************************************/

#include <CtxtCancelLocation.h>
#include <stdio.h>
#include <ServiceCoordinator.h>
#include <Logger.h>
#include <DbQueryMsg.h>
#include <DbActiveObject.h>
#include <MmConfigReader.h>
#include <MmDbQueries.h>
#include <DataUnion.h>
#include <Utilities.h>
#include <TimerManager.h>


CtxtCancelLocation::CtxtCancelLocation()
{
   DLOG(0,0,"CtxtCancelLocation::CtxtCancelLocation()");
   m_timerId = 0;
   m_retryCount = 5;
   memset(m_TransId,'\0',sizeof(m_TransId));
   memset(m_Orginator,'\0',sizeof(m_Orginator));
   m_ssn = 7;
   m_UpdateSubsDataTable = 0;

   m_SendPrn = 0;
   memset(m_msc_no,'\0',sizeof(m_msc_no));
   memset(m_CLreason,'\0',sizeof(m_CLreason));
   memset(m_allocMsisdn,'\0',sizeof(m_allocMsisdn));

   m_mtrf_support_ind = 0;
   m_mtrf_authorized_ind = 0;
   memset(m_new_vlr_num,'\0',sizeof(m_new_vlr_num));
   memset(m_new_msc_num,'\0',sizeof(m_new_msc_num));
   memset(m_new_lmsi,'\0',sizeof(m_new_lmsi));

   m_networkId = 0;
   m_crossCL = false;
   m_Emergency_CL_Retry_Attempts = 0;
}

CtxtCancelLocation::~CtxtCancelLocation()
{
   DLOG(0,0,"CtxtCancelLocation::~CtxtCancelLocation()");
}



bool CtxtCancelLocation::processMessage(Msg *p_MsgPtr,bool &p_DeleteFlag)
{
   DLOG(0, 0, "Start of CtxtCancelLocation::processMsg function Delete flag %d",p_DeleteFlag);
   MapSpecificMsg *l_specMsg = NULL;
   int l_dlgId = 0;
   int l_UserDlgId = 0;

   if( 1 == g_EmergencyFlag )
   {
    m_Emergency_CL_Retry_Attempts = g_MmConfigReaderObj->m_Congestion_CL_Retry_Attempts;
   }
   else
   {
    m_Emergency_CL_Retry_Attempts = g_MmConfigReaderObj->m_Cancel_Location_Retry;
   }
   
   LLOG(0,0,"m_Emergency_CL_Retry_Attempts [%d]",m_Emergency_CL_Retry_Attempts);

   switch (p_MsgPtr->m_MsgType)
   {
      case MSG_TYPE_MAP:
         switch (((MapMsg*) p_MsgPtr)->m_MapMsgType)
         {
            case MAP_MSG_TYPE_COMMON:
               switch (((MapCommonMsg*) p_MsgPtr)->m_MapCommonMsgType)
               {
                  case MAP_CMN_OPEN_IND:
                     {
                        DLOG(0, 0, "MAP_CMN_OPEN_IND received");
                        //MapOpenInd *l_test = (MapOpenInd*) p_MsgPtr;
                        //OpenInd(l_test);
                     }
                     break;

                  case MAP_CMN_OPEN_CNF:
                     {
                        DLOG(0,0,"MAP Open confirmation Received");
                        MapOpenCnf *l_oCnf = (MapOpenCnf*) p_MsgPtr;
                        OpenCnf(l_oCnf);
                     }
                     break;

                  case MAP_CMN_DELIMITER_IND:
                     {
                        DLOG(0, 0, "MAP_CMN_DELIMITER_IND received");
                     }
                     break;

                  case MAP_CMN_CLOSE_IND:
                     {
                        DLOG(0, 0, "MAP_CMN_CLOSE_IND received, returning true");
                        return true;
                     }
                     break;

                  case MAP_CMN_U_ABORT_IND:
                     {
                        WLOG(0, 0, "MAP_CMN_U_ABORT_IND received");
                        //g_tdrFiller->setBool(&this->m_tdr,TDR_MSGSTATUS_INDEX,false);
                        m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_U_ABORT_RCVD);
                        if(true == m_UpdateReqd)
                        {
                           LLOG(0,0,"Calling updateDb for Failure, Reason : Received U-Abort");
                           m_callState = 1;
                           updateDb('F', "Received U-Abort");
                        }
                     }
                     break;

                  case MAP_CMN_P_ABORT_IND:
                     {
                        WLOG(0, 0, "MAP_CMN_P_ABORT_IND received");
                        //g_tdrFiller->setBool(&this->m_tdr,TDR_MSGSTATUS_INDEX,false);
                        m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_P_ABORT_RCVD);
                        if(true == m_UpdateReqd)
                        {
                           LLOG(0,0,"Calling updateDb for Failure, Reason : Received P-Abort");
                           m_callState = 1;
                           updateDb('F', "Received P-Abort");
                        }
                     }
                     break;

                  case MAP_CMN_NOTICE_IND:
                     {
                        LLOG(0, 0, "MAP_CMN_NOTICE_IND received, Sending Close");
                        MapCloseReq l_closeReq(((MapMsg*)p_MsgPtr)->m_UserDlgId);
                        l_closeReq.m_CloseType = MAP_CLOSE_TYPE_PRE_ARRANGED_END;
                        g_sc.sendMsg(this, &l_closeReq); 

                        if((m_Emergency_CL_Retry_Attempts > 0) && (m_retryCount < m_Emergency_CL_Retry_Attempts))
                        {
                           m_timerId = g_tm.startTimer(this, g_MmConfigReaderObj->m_Cancel_Location_Timer);
                           if (m_timerId < 1)
                           {
                              ELOG(0,1,"Unable to set the timer value");
                           }
                           else
                           {
                              LLOG(0,0,"Cancel Location retry timer to %d seconds, TimerId %d", g_MmConfigReaderObj->m_Cancel_Location_Timer,m_timerId);
                           }
                        }
                        else
                        {
                           LLOG(0,0,"Configured Retry attempts %d, Retry attempts made %d, not setting retry timer",m_Emergency_CL_Retry_Attempts,m_retryCount);
                           //g_tdrFiller->setBool(&this->m_tdr,TDR_MSGSTATUS_INDEX,false);
                           m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_NOTICE_RCVD);
                           DLOG(0,0,"Checking Update DB status %d",m_UpdateReqd);
                           if(m_UpdateReqd)
                           {
                              LLOG(0,0,"Calling updateDb for Failure, Reason : Received Notice");
                              m_callState = 1;
                              updateDb('F', "Received Notice");
                           }
                        }
                     }
                     break;

                  default:
                     {
                        CLOG(0, 0, "Unknown Msg received [%d]", ((MapCommonMsg*) p_MsgPtr)->m_MapCommonMsgType);
                     }
                     break;
               }
               break;

            case MAP_MSG_TYPE_SPECIFIC:
               {
                  DLOG(0, 0, "MAP_MSG_TYPE_SPECIFIC received");
                  l_specMsg = (MapSpecificMsg*) p_MsgPtr;
                  l_UserDlgId = l_specMsg->m_UserDlgId;
                  DLOG(0, 0, "MAP_MSG_TYPE_SPECIFIC received dlgId[%d] UserDlgId[%d]",l_dlgId, l_UserDlgId);

                  switch (((MapSpecificMsg*) p_MsgPtr)->m_MapSpecificEventType)
                  {
                     case MAP_SPEC_EVENT_INDICATION:
                        {
                           DLOG(0, 0, "MAP_SPEC_EVENT_INDICATION received");
                           switch (((MapSpecificMsg*) p_MsgPtr)->m_OpCode)
                           {
                              default:
                                 DLOG(0, 0, "Received Unknown Specific Message");
                                 break;
                           }
                           return true;
                        }
                        break;

                     case MAP_SPEC_EVENT_RESULT:
                        {
                           DLOG(0, 0, "MAP_SPEC_EVENT_RESULT received");
                        }
                        break;

                     case MAP_SPEC_EVENT_CONFIRMATION:
                        {
                           DLOG(0, 0, "MAP_SPEC_EVENT_CONFIRMATION received");
                           switch (((MapSpecificMsg*) p_MsgPtr)->m_OpCode)
                           {
                              case MAP_OP_CODE_cancelLocation://Can_Loc_Res opcode=3
                                 {
                                    LLOG(0,0,"Cancel Location Acknowledge reveived");
                                    if(true == m_crossCL)
                                    {
                                       if(149 == m_ssn)
                                       {
                                          moduleLevelLogStats("CrossCLTowardsSGSN", MODULE_STATS_EVENT_STATUS_SUCCESS);
                                       }
                                       else
                                       {
                                          moduleLevelLogStats("CrossCLTowardsVLR", MODULE_STATS_EVENT_STATUS_SUCCESS);
                                       }
                                    }

                                    // 1.0.16.0 Begin
                                    if((NULL != strstr(m_CLreason,"TEMP_MSISDN_REMOVE")) && (7 == m_ssn))
                                    {
                                       UpdateTransStatusDB();
                                    }
                                    // 1.0.16.0 End

                                    if(true == m_UpdateReqd)
                                    {
                                       LLOG(0,0,"Calling updateDb with status Success");
                                       m_callState = 1;
                                       updateDb('S', "");
                                    }
                                    //
                                    // Added in 1.0.11.0
                                    //
                                    if((m_ssn == 7) && (m_SendPrn == 1))
                                    {
                                       TLOG(0,0,"Initiating PRN");
                                       char l_PrnXmlReq[500];
                                       //<PRN><IMSI>877775549310013</IMSI><MSC_NUMBER>447581234</MSC_NUMBER><HLR_NUMBER>4475311111</HLR_NUMBER></PRN>
                                       snprintf(l_PrnXmlReq,sizeof(l_PrnXmlReq),"<PRN><IMSI>%s</IMSI><MSC_NUMBER>%s</MSC_NUMBER><HLR_NUMBER>%s</HLR_NUMBER><NETWORK_ID>%d</NETWORK_ID></PRN>",imsi,m_msc_no,hlrno,m_networkId);
                                       LLOG(0,0,"Initiating XML request [%s] for PRN",l_PrnXmlReq);
                                       g_sc.initiateIndependentContext(this, MAP_OP_CODE_provideRoamingNumber, (char *) l_PrnXmlReq, INITIATION_TYPE_IMMEDIATE);
                                    }
                                    else
                                    {
                                       TLOG(0,0,"Not initiating PRN");
                                    }
                                    //
                                    // End Added in 1.0.11.0
                                    //
                                    return true;
                                 }
                                 break;
                              default:
                                 {
                                    DLOG(0,0,"Unknown Opcode received");
                                 }
                                 break;
                           }
                        }
                        break;

                     case MAP_SPEC_EVENT_USER_ERROR:
                        {
                           unsigned short l_errCode = ((MapUserError*)p_MsgPtr)->m_ErrorCode;
                           WLOG(0, 0, "MAP_SPEC_EVENT_USER_ERROR %d received",l_errCode);                              

                           // 1.0.16.0 Begin
                           if( (l_errCode != MAP_ERROR_resourceLimitation) &&
                                 (l_errCode != MAP_ERROR_unexpectedData) &&
                                 (l_errCode != MAP_ERROR_dataMissing) &&
                                 (l_errCode != MAP_ERROR_systemFailure))
                           {
                              LLOG(0,0,"Releasing TEMP MSISDN for CL err code: %d", l_errCode);
                              if((NULL != strstr(m_CLreason,"TEMP_MSISDN_REMOVE")) && (7 == m_ssn))
                              {
                                 UpdateTransStatusDB();
                              }
                           }
                           // 1.0.16.0 End

                           //g_tdrFiller->setBool(&this->m_tdr,TDR_MSGSTATUS_INDEX,false);
                           if((l_errCode == 1) && (m_Emergency_CL_Retry_Attempts > 0) && (m_retryCount < m_Emergency_CL_Retry_Attempts))
                           {
                              m_timerId = g_tm.startTimer(this, g_MmConfigReaderObj->m_Cancel_Location_Timer);
                              if (m_timerId < 1)
                              {
                                 ELOG(0,1,"Unable to set the timer value");
                              }
                              else
                              {
                                 LLOG(0,0,"Cancel Location retry timer to %d seconds, TimerId %d", g_MmConfigReaderObj->m_Cancel_Location_Timer,m_timerId);
                              }
                           }
                           else
                           {
                              LLOG(0,0,"Received error is not system failure or Configured Retry attempts %d, Retry attempts made %d, not setting retry timer, Checking Update DB status %d",m_Emergency_CL_Retry_Attempts,m_retryCount,m_UpdateReqd);
                              m_tdr.setInteger(TDR_INDEX_ERR_CODE,l_errCode);
                              if(m_UpdateReqd)
                              {
                                 m_callState = 1;
                                 updateDb('F', "Received USER ERROR");
                              }
                           }
                        }
                        break;

                     case MAP_SPEC_EVENT_PROV_ERROR:
                        {
                           WLOG(0, 0, "MAP_SPEC_EVENT_PROV_ERROR received, Checking Update DB status %d",m_UpdateReqd);
                           m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_PROVIDER_ERROR_RCVD);
                           if(true == m_UpdateReqd)
                           {
                              LLOG(0,0,"Calling updateDb for Failure, Reason : Received Provided Error");
                              m_callState = 1;
                              updateDb('F', "Received Provider Error");
                           }
                        }
                        break;
                     default:
                        WLOG(0, 0, "ERROR!! Default received");
                        break;
                  }
               }
               break;

            default:
               break;
         }
         break;

      case MSG_TYPE_DB:
         {
            DLOG(0, 0, "DB message received");

            DbQueryMsg *l_dqm = (DbQueryMsg*)p_MsgPtr;
            switch(l_dqm->m_DbQueryType)
            {
               case 1:
                  {
                     if(m_UpdateSubsDataTable)
                     {
                        UpdSubsData *l_US = (UpdSubsData *)p_MsgPtr;
                        if(l_US->m_ErrorCode_CL != 0)
                        {
                           m_tdr.setInteger(TDR_INDEX_DB_ERR_CODE,l_US->m_ErrorCode_CL); 
                           m_tdr.setString(TDR_INDEX_DB_ERR_DESC,(char *)l_US->m_ErrorMsg_CL);
                        }
                        if(l_US->m_DbQueryRes == DB_QUERY_RES_SUCCESS)
                        {
                           LLOG(0,0,"Update SUBS_DATA record successfully");
                        }
                        else
                        {
                           //WLOG(0,0,"Error updating SUBS_DATA [%s]",l_US->m_ErrorMsg_CL);
                           WLOG(0,0,"Error updating SUBS_DATA");
                        }
                     }
                  }
                  break;
               case 2:
                  {
                     //if(m_callState > 0)
                     {
                        DLOG(0,0,"Result of Update OAM Data");
                        UpdateDBStatus *l_UDS = (UpdateDBStatus *)p_MsgPtr;
                        if(l_UDS->m_ErrorCode_OAM != 0)
                        {
                           m_tdr.setInteger(TDR_INDEX_DB_ERR_CODE,l_UDS->m_ErrorCode_OAM); 
                           m_tdr.setString(TDR_INDEX_DB_ERR_DESC,(char *)l_UDS->m_ErrorMsg_OAM);
                        }
                        if(l_UDS->m_DbQueryRes == DB_QUERY_RES_SUCCESS)
                        {
                           LLOG(0,0,"Update record successfully");
                        }
                        else
                        {
                           WLOG(0,0,"Error updating record into DB");
                        }
                     }
                  }
                  break;
               case 3:
                  {
                     //if(m_callState  <= 0)
                     {
                        DLOG(0,0,"Result of IsCurrentNode");
                        IsCurrentNode *l_CN = (IsCurrentNode *)p_MsgPtr;
                        if(l_CN->m_DbQueryRes == DB_QUERY_RES_SUCCESS)
                        {
                           LLOG(0,0,"IsCurrentNode execution success, Result [%d]",l_CN->m_Result);
                           if(l_CN->m_Result == 0)
                           {
                              LLOG(0,0,"IMSI [%s] is Not in Node [%s] Type [%d], Calling Retry for CancelLocation",
                                    l_CN->m_imsi,l_CN->m_Node,l_CN->m_Nodetype);
                              if(l_Version == 3)
                              {
                                 SendCancelLocationV3();
                              }
                              else if(l_Version == 2)
                              {
                                 SendCancelLocationV2();
                              }
                              else if(l_Version == 1)
                              {
                                 SendCancelLocationV1();
                              }
                              else
                              {
                                 WLOG(0,0,"Unknown version of CL [%d]",l_Version);
                                 return false;
                              }

                           }
                           else
                           {
                              LLOG(0,0,"IMSI [%s] is in Node [%s] Type [%d],Not Retryint for CancelLocation",
                                    l_CN->m_imsi,l_CN->m_Node,l_CN->m_Nodetype);
                              return false;
                           }
                        }
                     }
                  }
                  break;
               case 4: // 1.0.16.0
                  {
                     DLOG(0,0,"Result of Update Transient Status");
                     UpdTransStatus *l_updTransStatus = (UpdTransStatus *)p_MsgPtr;
                     if(l_updTransStatus->m_ErrorCode != 0)
                     {
                        m_tdr.setInteger(TDR_INDEX_DB_ERR_CODE,l_updTransStatus->m_ErrorCode); 
                        m_tdr.setString(TDR_INDEX_DB_ERR_DESC,(char *)l_updTransStatus->m_ErrorMsg);
                     }
                     if(l_updTransStatus->m_DbQueryRes == DB_QUERY_RES_SUCCESS)
                     {
                        LLOG(0,0,"Update Transient Status successfully");
                        m_tdr.setString(TDR_INDEX_RESRV3, "Trans:Freed");
                     }
                     else
                     {
                        WLOG(0,0,"Error updating Transient Status");
                        m_tdr.setString(TDR_INDEX_RESRV3, "Trans:Error");
                     }
                  }
                  break;
               default:
                  {
                     ELOG(0,0,"Unknown query type received[%d]",l_dqm->m_DbQueryType);
                     break;
                  }
            }
         }
         break;

      case MSG_TYPE_TIMEOUT:
         {
            LLOG(0,0,"Timeout message received, Checking for CL_Version %d  and Retry count %d",l_Version,m_retryCount);
            if(l_Version == 3)
            {                 
               l_Version = 3;
               m_retryCount += 1;
               if(m_retryCount <=m_Emergency_CL_Retry_Attempts)
               {
                  LLOG(0,0,"Initiating Cancel location V3, incrementing Retry count to %d",m_retryCount);   
                  m_callState = 0;
                  CheckIsCurrentNode();
                  //SendCancelLocationV3();
               }
               else
               {
                  WLOG(0,0,"Max retry count limit exceeded, not sending Cancel location again");
                  return false;
               }
            }
            else if(l_Version == 2)
            {
               l_Version =2; 
               m_retryCount += 1;
               if(m_retryCount <=m_Emergency_CL_Retry_Attempts)
               {
                  LLOG(0,0,"Initiating Cancel location V2, incrementing Retry count to %d",m_retryCount);   
                  m_callState = 0;
                  CheckIsCurrentNode();
                  //SendCancelLocationV2();
               }
               else
               {
                  WLOG(0,0,"Max retry count limit exceeded, not sending Cancel location again");
                  return false;
               }
            }
            else if(l_Version == 1)
            {
               l_Version = 1;
               m_retryCount += 1;
               if(m_retryCount <=m_Emergency_CL_Retry_Attempts)
               {
                  LLOG(0,0,"Initiating Cancel location V1, incrementing Retry count to %d",m_retryCount);   
                  m_callState = 0;
                  CheckIsCurrentNode();
                  //SendCancelLocationV1();
               }
               else
               {
                  WLOG(0,0,"Max retry count limit exceeded, not sending Cancel location again");
                  return false;
               }
            }
            else
            {
               WLOG(0,0,"Unrecognizable version %d",g_MmConfigReaderObj->m_CL_Version);
               return false;
            }
            //MapCloseReq l_closeReq(getInitialRespondingDlgId());
            //g_sc.sendMsg(this, &l_closeReq);
         }
         break;
      default:
         ELOG(0, 0, "Unknown message received");
         break;
   }
   return true;
}


bool CtxtCancelLocation::startProcessing(InterModuleData *p_imd,bool &p_DeleteFlag)
{
   DLOG(0, 0, "Start of CtxtCancelLocation::startProcessing function, Delete flag %d",p_DeleteFlag);
   if( 1 == g_EmergencyFlag )
   {
    m_Emergency_CL_Retry_Attempts = g_MmConfigReaderObj->m_Congestion_CL_Retry_Attempts;
   }
   else
   {
    m_Emergency_CL_Retry_Attempts = g_MmConfigReaderObj->m_Cancel_Location_Retry;
   }
   
   LLOG(0,0,"g_EmergencyFlag [%d] m_Emergency_CL_Retry_Attempts [%d]",g_EmergencyFlag, m_Emergency_CL_Retry_Attempts);

   m_UpdateReqd = false;
   memset(m_Orginator,'\0',sizeof(m_Orginator));
   LLOG(0,0,"InterModule data for Cancel location Received from [%s] Xml Request  [%s], version for initiating message is configured to %d", p_imd->m_OriginatorModule,(NULL == p_imd->m_Parameters)?"":p_imd->m_Parameters,g_MmConfigReaderObj->m_CL_Version);
   
   if(NULL == p_imd->m_Parameters)
   {
      CLOG(0,0,"p_imd->m_Parameters NULL returning");
      return false;
   }

   strcpy(m_Orginator,p_imd->m_OriginatorModule);

   /* if(strncmp(m_Orginator,"OAM",3) == 0)
      {
      TLOG(0,0,"Orginator module is OAM ");
      }
      else if((strncmp(m_Orginator,"MMM",3) == 0))
      {
      TLOG(0,0,"Orginator module is Mobility Manager ");
      }
      else
      {
      WLOG(0,0,"Unrecognizable Orinator module %s, returning false",m_Orginator);
      m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_UNABLE_TO_INITIATE);
      return false;
      }*/
   char *l_check = NULL;
   l_check = strchr(p_imd->m_Parameters, ':');
   if(l_check == NULL)
   {
      TLOG(0,0,"Transaction ID not present");
      //return false;
      m_UpdateReqd = false;
      //m_DataString.assign(&p_imd->m_Parameters[0]);
      m_DataString.assign(p_imd->m_Parameters);
   }
   else
   {
      strncpy(m_TransId,p_imd->m_Parameters, strlen(p_imd->m_Parameters)-strlen(l_check));
      LLOG(0,0,"Transaction ID :%s received from OAM", m_TransId);
      m_UpdateReqd = true;

      m_DataString.assign(&p_imd->m_Parameters[strlen(p_imd->m_Parameters)-strlen(l_check)]);
      m_tdr.setString(TDR_INDEX_OAM_TRANSACTION_ID, m_TransId);
   }

   memset(imsi,'\0',sizeof(imsi));
   string l_imsi = ConfigReader::readValue(m_DataString, "IMSI");
   if(1 > l_imsi.length())
   {
      CLOG(0,0,"Unknown IMSI");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_UNABLE_TO_INITIATE);
      if(m_UpdateReqd)
      {
         m_callState = 1;
         updateDb('F', "Invalid IMSI");
      }
      return false;
   }
   //strncpy((char *)imsi,(char *)l_imsi.c_str(),strlen((char *)l_imsi.c_str()));
   strncpy((char *)imsi,l_imsi.c_str(),l_imsi.length());
   DLOG(0,0,"IMSI: %s", imsi);
   m_tdr.setChar(TDR_INDEX_REQUEST_TYPE,'I'); 
   m_tdr.setString(TDR_INDEX_REQUEST_IMSI,(char*)imsi);
   setTraceImsi((char *)imsi);

   string l_NodeType = ConfigReader::readValue(m_DataString,"TYPE");
   if(1 > l_NodeType.length())
   {
      CLOG(0,0,"Unknown Node type");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_UNABLE_TO_INITIATE);
      if(m_UpdateReqd)
      {
         m_callState = 1;
         updateDb('F', "Unknown Node Type");
      }
      return false;
   }
   DLOG(0,0,"Destination Node Type %s",l_NodeType.c_str());
   if((l_NodeType.compare("GSM")) == 0)
   { 
      m_ssn = 7;
      m_tdr.setInteger(TDR_INDEX_REQUEST_DOMAIN,1);
   }
   else if((l_NodeType.compare("GPRS")) == 0)
   {
      m_ssn = 149;
      m_tdr.setInteger(TDR_INDEX_REQUEST_DOMAIN,2);
      if(g_MmConfigReaderObj->m_CL_Version < 3)
      {
         WLOG(0,0,"Configured version %d,though sending version 3 cancel location",g_MmConfigReaderObj->m_CL_Version);
      }
   }
   else
   {
      CLOG(0,0,"Unknown Destination node type %s",l_NodeType.c_str());
      m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_UNABLE_TO_INITIATE);
      if(m_UpdateReqd)
      {
         m_callState = 1;
         updateDb('F', "Unknown Node Type");
      }
      return false;
   }

   memset(lmsi,'\0',sizeof(lmsi));
   string l_lmsi = ConfigReader::readValue(m_DataString, "LMSI");
   DLOG(0,0,"LMSI %s, len %d",l_lmsi.c_str(),l_lmsi.length());
   if(1 > l_lmsi.length())
   {
      DLOG(0,0,"LMSI not present, assuming default 00000000");
      strncpy((char *)lmsi,"00000000",8);      
   }
   else
   {   
      //strncpy((char *)lmsi,(char *)l_lmsi.c_str(),strlen((char *)l_lmsi.c_str()));
      strncpy((char *)lmsi,l_lmsi.c_str(),l_lmsi.length());
   }
   if(m_ssn == 149)
   {
      DLOG(0,0,"CancelLocation for SGSN, Removing LMSI if any");
      strncpy((char *)lmsi,"00000000",8);      
   }
   DLOG(0,0,"LMSI: %s", lmsi);

   memset(vlrno,'\0',sizeof(vlrno));
   string l_vlr = ConfigReader::readValue(m_DataString, "DEST_ADDRESS");
   if(1 > l_vlr.length())
   {
      WLOG(0,0,"Unknown destination number");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_UNABLE_TO_INITIATE);
      if(m_UpdateReqd)
      {
         m_callState = 1;
         updateDb('F', "Unknown destination number");
      }
      return false;
   }
   //strncpy((char *)vlrno,(char *)l_vlr.c_str(),strlen((char *)l_vlr.c_str()));
   strncpy((char *)vlrno,l_vlr.c_str(),l_vlr.length());
   DLOG(0,0,"VLR Numbner: %s",vlrno);

   memset(hlrno,'\0',sizeof(hlrno));
   string l_hlr = ConfigReader::readValue(m_DataString, "ORIG_ADDRESS");
   if(1 > l_hlr.length())
   {
      WLOG(0,0,"Unknown Orgination number");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_UNABLE_TO_INITIATE);
      if(m_UpdateReqd)
      {
         m_callState = 1;
         updateDb('F', "Unknown orgination number");
      }
      return false;
   }
   //strncpy((char *)hlrno,(char *)l_hlr.c_str(),strlen((char *)l_hlr.c_str()));
   strncpy((char *)hlrno,l_hlr.c_str(),l_hlr.length());
   DLOG(0,0,"HLR Number: %s", hlrno);

   string l_cause = ConfigReader::readValue(m_DataString, "CL_TYPE");
   if(0 == l_cause.length())
   {
      WLOG(0,0,"Unknown Cancellation Type");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_UNABLE_TO_INITIATE);
      if(m_UpdateReqd)
      {
         m_callState = 1;
         updateDb('F', "Unknown Cancellation Type");
      }
      return false;
   }
   cause = atoi(l_cause.c_str());
   DLOG(0,0,"Cancel Location Type: %d", cause);

   string l_updFlag = ConfigReader::readValue(m_DataString, "CLR_SUBS_DATA");
   if(0 == l_updFlag.length())
   {
      LLOG(0,0,"Unknown UpdateStatus,initiated through OAM");
      m_UpdateSubsDataTable =0; 
   }
   else
   {
      m_UpdateSubsDataTable = atoi(l_updFlag.c_str());
   }
   string l_PartType = ConfigReader::readValue(m_DataString, "IMSI_TYPE");
   int l_ImsiPartType = 0;
   if(l_PartType.length() > 0)
   {
      l_ImsiPartType = atoi(l_PartType.c_str());
      DLOG(0,0,"IMSI Partner Network Type is [%d]",l_ImsiPartType);
   }
   else
   {
      l_ImsiPartType = 0;
   }
   if(l_ImsiPartType > 0)
   {
      m_tdr.setInteger(TDR_INDEX_PARTNER_TYPE,l_ImsiPartType); 
   }


   m_Avoid_Capturing_fail = atoi((char*)(ConfigReader::readValue(m_DataString,"AVOID_CAPTURING_FAILED_TRANS")).c_str());
   DLOG(0,0,"Avoid Capturing Fail Transaction [%d]",m_Avoid_Capturing_fail);

   //Added in 1.0.11.0 for sending PRN in case of ISD failure which was initiated for change MSISDN FRR 1256

   string l_reqType = ConfigReader::readValue(m_DataString,"REQUEST_TYPE");
   TLOG(0,0,"RequestType: %s", (char*)l_reqType.c_str());
   if(l_reqType.length() > 0)
   {
      m_tdr.setString(TDR_INDEX_RESRV1, (char*)l_reqType.c_str());
      for(int k = 0; k < g_MmConfigReaderObj->m_cl_reason.size(); k++)
      {
         TLOG(0,0,"RequestType: %s", (char*)g_MmConfigReaderObj->m_cl_reason[k].c_str());
         if(l_reqType == g_MmConfigReaderObj->m_cl_reason[k])
         {
            m_SendPrn = 1;
            LLOG(0,0,"Send PRN flag set for CL Reason [%s]",l_reqType.c_str());
            break;
         }
      }
      // 1.0.16.0 Begin
      snprintf(m_CLreason,sizeof(m_CLreason),"%s",l_reqType.c_str());
      if(strstr(m_CLreason, "MME"))
      {
         m_crossCL=true;
      }
      string l_alloc_msisdn = ConfigReader::readValue(m_DataString,"ALLOC_MSISDN");
      if((7 == m_ssn) && (l_alloc_msisdn.length() > 0))
      {
         snprintf(m_allocMsisdn,sizeof(m_allocMsisdn),"%s",l_alloc_msisdn.c_str());
         TLOG(0,0,"AllocMsisdn [%s] present in xml",m_allocMsisdn);
         m_tdr.setString(TDR_INDEX_RESRV2, m_allocMsisdn);
         m_tdr.setString(TDR_INDEX_RESRV3, "Trans:NotFreed");
      }
      else
      {
         LLOG(0,0,"AllocMsisdn Not present in xml");
      }
      // 1.0.16.0 End
   }

   if(1 == m_SendPrn)
   {
      string l_msc_number = ConfigReader::readValue(m_DataString,"MSC_NUMBER");
      if(l_msc_number.length() > 0)
      {
         snprintf(m_msc_no,sizeof(m_msc_no),"%s",l_msc_number.c_str());
         TLOG(0,0,"MscNumber [%s] present in xml",m_msc_no);
      }
      else
      {
         LLOG(0,0,"MscNumber Not present in xml");
         m_SendPrn = 0;
      }
   }
   // End Added in 1.0.11.0 
   //
   string l_network_id = ConfigReader::readValue(m_DataString,"NETWORK_ID");
   if(l_network_id.length() > 0)
   {
      TLOG(0,0,"NetworkId[%s] present in xml",l_network_id.c_str());
      m_tdr.setString(TDR_INDEX_MM_NETWORK_ID,(char *)l_network_id.c_str());
      m_networkId = atoi((char *)l_network_id.c_str());
   }
   //
   string l_mtrf_support_ind = ConfigReader::readValue(m_DataString,"MTRF_SUPPORTED");
   if(l_mtrf_support_ind.length() > 0)
   {
      if(1 == atoi((char*)l_mtrf_support_ind.c_str()) )
      {
         m_mtrf_support_ind = 1;
         string l_mtrf_authorized = ConfigReader::readValue(m_DataString,"MTRF_AUTHORIZED");
         if(l_mtrf_authorized.length() > 0 )
         {
            if(1 == atoi((char*)l_mtrf_authorized.c_str()) )
            {
               LLOG(0,0,"MTRF supported and authorized");
               m_mtrf_authorized_ind = 1;
               m_tdr.setString(TDR_INDEX_OAM_FREE_FORMAT_DATA,"1|1");
            }
            else
            {
               LLOG(0,0,"MTRF supported and not authorized");
               m_mtrf_authorized_ind = 0;
               m_tdr.setString(TDR_INDEX_OAM_FREE_FORMAT_DATA,"1|0");
            }
         }
         else
         {
            LLOG(0,0,"MTRF authorized tag not presetn");
         }

         string l_new_msc_number = ConfigReader::readValue(m_DataString,"NEW_MSC_NUMBER");
         if(l_new_msc_number.length() > 0)
         {
            snprintf((char*)m_new_msc_num,sizeof(m_new_msc_num),"%s",l_new_msc_number.c_str());
            TLOG(0,0,"New MscNumber[%s] present in xml",m_new_msc_num);
         }
         else
         {
            LLOG(0,0,"New MscNumber not present in xml");
         }

         string l_new_vlr_number = ConfigReader::readValue(m_DataString,"NEW_VLR_NUMBER");
         if(l_new_vlr_number.length() > 0)
         {
            snprintf((char*)m_new_vlr_num,sizeof(m_new_vlr_num),"%s",l_new_vlr_number.c_str());
            TLOG(0,0,"New VlrNumber[%s] present in xml",m_new_vlr_num);
         }
         else
         {
            LLOG(0,0,"New VlrNumber not present in xml");
         }

         string l_new_lmsi = ConfigReader::readValue(m_DataString, "NEW_LMSI");
         DLOG(0,0,"NEW_LMSI %s, len %d",(u8*)l_new_lmsi.c_str(),l_new_lmsi.length());
         if(1 > l_new_lmsi.length())
         {
            DLOG(0,0,"NEW_LMSI not present, assuming default 00000000");
            strncpy((char *)m_new_lmsi,"00000000",8);      
         }
         else
         {   
            //strncpy((char *)lmsi,(char *)l_new_lmsi.c_str(),strlen((char *)l_new_lmsi.c_str()));
            strncpy((char *)m_new_lmsi,l_new_lmsi.c_str(),l_new_lmsi.length());
         }
      }
      else
      {
         m_mtrf_support_ind = 0;
         LLOG(0,0,"MTRF support indicator[%d] not set to 1",atoi((char*)l_mtrf_support_ind.c_str()));
         m_tdr.setString(TDR_INDEX_OAM_FREE_FORMAT_DATA,"0");
      }
   }
   else
   {
      LLOG(0,0,"MTRF_SUPPORTED tag not present");
   }

   if(true == m_crossCL)
   {
      if(149 == m_ssn)
      {
         moduleLevelLogStats("CrossCLTowardsSGSN", MODULE_STATS_EVENT_STATUS_TOTAL);
      }
      else
      {
         moduleLevelLogStats("CrossCLTowardsVLR", MODULE_STATS_EVENT_STATUS_TOTAL);
      }
   }

   if(m_UpdateSubsDataTable)
   {
      LLOG(0,0,"Update SubsData set");
      UpdateSubsData(imsi);
   }
   LLOG(0,0,"IMSI : %s, LMSI : %s, DESTINATION Number : %s, ORGINATION Number : %s, Cancel Location Type : %d m_UpdateSubsDataTable %d Capturing Fail Transaction [%s] Operation [%s] SendPRN [%d]",imsi,lmsi,vlrno,hlrno,cause,m_UpdateSubsDataTable,(m_Avoid_Capturing_fail==1?"Avoid":"Capture"),l_reqType.c_str(),m_SendPrn);
   m_tdr.setString(TDR_INDEX_LOCAL_ADDRESS,(char *)hlrno);
   //if((strncmp(m_Orginator,"MMMUPG",6) == 0)|| (m_ssn == 149))
   if(m_ssn == 149)
   {
      LLOG(0,0,"Cancel location initiated by UPG,Initiating Cancel location V3");
      l_Version = 3;
      m_retryCount = 0;
      SendCancelLocationV3();
   }
   //else if((strncmp(m_Orginator,"OAM",3) == 0) && (m_ssn == 149))
   else if(m_ssn == 149)
   {
      LLOG(0,0,"Cancel location initiated by OAM for Type:GPRS,Initiating Cancel location V3");
      l_Version = 3;
      m_retryCount = 0;
      SendCancelLocationV3();
   }
   else
   {
      TLOG(0,0,"Cancel location initiated by UPD, checking for the Configured CL version");
      if(g_MmConfigReaderObj->m_CL_Version == 3)
      {
         DLOG(0,0,"Initiating Cancel location V3");
         l_Version = 3;
         m_retryCount = 0;
         SendCancelLocationV3();
      }
      else if(g_MmConfigReaderObj->m_CL_Version == 2)
      {
         DLOG(0,0,"Initiating Cancel location V2");
         l_Version = 2;
         m_retryCount = 0;
         SendCancelLocationV2();
      }
      else if(g_MmConfigReaderObj->m_CL_Version == 1)
      {
         DLOG(0,0,"Initiating Cancel location V1");
         l_Version = 1;
         m_retryCount = 0;
         SendCancelLocationV1();
      }
      else
      {
         WLOG(0,0,"Unrecognizable version %d",g_MmConfigReaderObj->m_CL_Version);
         return false;
      }
   }
   return true;
}

void CtxtCancelLocation::OpenCnf(MapOpenCnf *l_oCnf)
{
   LLOG(0, 0, "Received Open Confirmation Refuse Reason is %d", l_oCnf->m_RefuseReasonParam);
   if(l_oCnf->m_RefuseReasonParam ==  REFUSE_REASON_APPL_CNTXT_NOT_SUPPORTED)
   {
      LLOG(0, 0, "Received Open Cnf with Supported verion as %d", l_oCnf->m_Version);
      m_tdr.setInteger(TDR_INDEX_OPEN_CNF_VERSION,l_oCnf->m_Version);
      if((l_oCnf->m_Version == 2) && (l_oCnf->m_Version < g_MmConfigReaderObj->m_CL_Version))
      {
         DLOG(0,0,"Initiating cancel location version 2");
         l_Version = l_oCnf->m_Version;
         SendCancelLocationV2();
      }
      else if((l_oCnf->m_Version == 1)&& (l_oCnf->m_Version < g_MmConfigReaderObj->m_CL_Version))
      {
         DLOG(0,0,"Initiating cancel location version 1");
         l_Version = l_oCnf->m_Version;
         SendCancelLocationV1();
      }
      else
         WLOG(0, 0, "Unrecognizable version received");
   }
   else
   {
      WLOG(0,0,"OpenCnf reason is not APPL_CNTXT_NOT_SUPPORTED, returning");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_NOTICE_RCVD);
      if(true == m_UpdateReqd)
      {
         m_callState = 1;
         updateDb('F', "Notice Rcvd");
      }
   }
}

void CtxtCancelLocation::updateDb(char p_status, char *p_error)
{
#if 0
   LLOG(0,0,"Updating OAM transaction ID %s with status %c, m_UpdateSubsDataTable %d",m_TransId,p_status,m_UpdateSubsDataTable);
   UpdateDBStatus *l_UDB = new UpdateDBStatus;
   l_UDB->m_cb = this;
   l_UDB->m_Status = p_status;
   strcpy(l_UDB->m_TransId,m_TransId);
   strcpy(l_UDB->m_ErrorCause, p_error);
   strcpy((char*)l_UDB->m_IMSI,(char*)imsi);
   if(m_ssn == 7)
   {
      l_UDB->m_TYPE = 0;
   }
   else
   {
      l_UDB->m_TYPE = 1;
   }
   if(m_Avoid_Capturing_fail == 1)
   {
      l_UDB->m_DontUpdateFail = 1; 
   }
   l_UDB->m_DbQueryType=2;
   g_act.execute(l_UDB);
#endif
}

void CtxtCancelLocation::UpdateSubsData(u8* l_imsi)
{
   DLOG(0,0,"update subsdata for imsi %s",l_imsi);
   UpdSubsData *l_USD = new UpdSubsData;
   l_USD->m_cb = this;
   strcpy((char *)l_USD->m_imsi,(char *)l_imsi);
   if(m_ssn == 7)
      l_USD->m_type = 0;
   else
      l_USD->m_type = 1;
   l_USD->m_ClearingMethod = m_UpdateSubsDataTable;
   strcpy((char*)l_USD->m_Node, (char*)vlrno);
   l_USD->m_DbQueryType=1;
   LLOG(0,0,"UpdateSubsDataTable for IMSI %s, Type %d, ClearingMethod %d, Node %s",l_USD->m_imsi,l_USD->m_type, l_USD->m_ClearingMethod, vlrno);
   g_act.execute(l_USD);
}

// Added in 1.0.5.0
void CtxtCancelLocation::CheckIsCurrentNode()
{
   DLOG(0,0,"Checking subsdata for imsi %s",imsi);
   IsCurrentNode *l_ICN = new IsCurrentNode;
   l_ICN->m_cb = this;
   strcpy((char *)l_ICN->m_imsi,(char *)imsi);
   strcpy((char*) l_ICN->m_Node,(char *)vlrno);
   if(m_ssn == 7)
      l_ICN->m_Nodetype = 0;
   else
      l_ICN->m_Nodetype = 1;
   LLOG(0,0,"IsCurrentNode for IMSI [%s] Type [%d] Node [%s]",l_ICN->m_imsi,l_ICN->m_Nodetype,l_ICN->m_Node);
   l_ICN->m_DbQueryType = 3;
   g_act.execute(l_ICN);
}

//1.0.16.0 Begin
void CtxtCancelLocation :: UpdateTransStatusDB()
{
   DLOG(0,0,"UpdateTransStatusDB for imsi %s",imsi);
   UpdTransStatus *l_transStat = new UpdTransStatus;
   l_transStat->m_cb = this;
   strcpy((char *)l_transStat->m_allocMsisdn,(char *)m_allocMsisdn);
   LLOG(0,0,"UpdateTransStatusDB AllocMsisdn[%s] ",l_transStat->m_allocMsisdn);
   l_transStat->m_DbQueryType = 4;
   g_act.execute(l_transStat);
}
//1.0.16.0 End

bool CtxtCancelLocation::SendCancelLocationV3()//u8 *imsi,u8 *lmsi,u8 *vlrno,u8 *hlrno,int cause)
{
   int l_CancelLocDlgId = g_sc.getNewDialogue();
   if(l_CancelLocDlgId < 1)
   {
      CLOG(0,0,"Cancel location dialog id %d is less then 0",l_CancelLocDlgId);
      return false;
   }
   DLOG(0,0,"Cancel Location on dialog ID %d",l_CancelLocDlgId);

   DLOG(0, 0, "Sending MapOpenReq for Cancel Location");
   MapOpenReq l_mapOpenReq(l_CancelLocDlgId, MAP_V3);
   l_mapOpenReq.m_ApplCntxt = MAP_AC_CODE_locationCancel;
   DLOG(0,0,"Configuring SCCP address in Cancel Location for Destination number %s and HLR Number %s",(char *)vlrno,(char *)hlrno);
   configureSccpAddress(&l_mapOpenReq.m_OrigAddr,L_ROUTE_ON_GT,1002,g_ConfigData->i_NgConfigData.m_selfAddress.ssn,(char *)hlrno);
   if(true == configureSccpAddress(&l_mapOpenReq.m_DestAddr,L_ROUTE_ON_GT,1002,m_ssn,(char *)vlrno))
      g_sc.sendMsg(this, &l_mapOpenReq);

   m_tdr.setMapVersion(3);
   //m_tdr.setCallingAddr((s8 *)vlrno);
   m_tdr.setRemoteAddr((s8 *)vlrno);
   m_tdr.setRemoteAddrSsn(m_ssn);

   LLOG(0,0,"Sending CancelLocation Request with DlgID %d IMSI %s and LMSI %s",l_CancelLocDlgId,imsi,lmsi);
   MapSpecificRequest l_request(l_CancelLocDlgId, MAP_OP_CODE_cancelLocation, MAP_V3);

   DECLARE(OMAP3_CancelLocationArg,l_cancelLoc,3,"OMAP3_CancelLocationArg",DeclareFunc);
   l_cancelLoc->bit_mask = 0;
   int l = strlen((char *)imsi);
   //int l1 = strlen((char *)lmsi);
   if((strncmp((char *)lmsi,"00000000",8)==0) || (strcmp((char *)lmsi,"0")==0))
   {
      l_cancelLoc->identity.choice = OMAP3_Identity_imsi_chosen;       
      l_cancelLoc->identity.u.imsi.length = (l+1)/2;
      StringToBCD(l_cancelLoc->identity.u.imsi.value,imsi,l);      
   }
   else
   {
      l_cancelLoc->identity.choice = OMAP3_imsi_WithLMSI_chosen;
      l_cancelLoc->identity.u.imsi_WithLMSI.imsi.length = (l+1)/2;
      StringToBCD(l_cancelLoc->identity.u.imsi_WithLMSI.imsi.value,imsi,l);
      l_cancelLoc->identity.u.imsi_WithLMSI.lmsi.length = 4;
      atohx((char *)l_cancelLoc->identity.u.imsi_WithLMSI.lmsi.value,(char *)lmsi);      
      m_tdr.setHex(TDR_INDEX_LMSI,(char *)l_cancelLoc->identity.u.imsi_WithLMSI.lmsi.value,4);
   }

   l_cancelLoc->bit_mask  |= OMAP3_cancellationType_present;
   l_cancelLoc->cancellationType = (OMAP3_CancellationType)cause;

   if(1 == m_mtrf_support_ind)
   {
      if(1 == m_mtrf_authorized_ind)
      {
         l_cancelLoc->bit_mask |= OMAP3_mtrf_SupportedAndAuthorized_present; 
      }
      else
      {
         l_cancelLoc->bit_mask |= OMAP3_mtrf_SupportedAndNotAuthorized_present; 
      }

      if(strlen((s8*)m_new_msc_num) > 0)
      {
         l_cancelLoc->bit_mask |= OMAP3_newMSC_Number_present;
         l_cancelLoc->newMSC_Number.value[0] = 0x91; 
         l_cancelLoc->newMSC_Number.length = StringToBCD(&l_cancelLoc->newMSC_Number.value[1],(u8*)m_new_msc_num,strlen((s8*)m_new_msc_num));
         l_cancelLoc->newMSC_Number.length++;
      }

      if(strlen((s8*)m_new_vlr_num) > 0)
      {
         l_cancelLoc->bit_mask |= OMAP3_newVLR_Number_present;
         l_cancelLoc->newVLR_Number.value[0] = 0x91; 
         l_cancelLoc->newVLR_Number.length = StringToBCD(&l_cancelLoc->newVLR_Number.value[1],(u8*)m_new_vlr_num,strlen((s8*)m_new_vlr_num));
         l_cancelLoc->newVLR_Number.length++;
      }

      if(strlen((s8*)m_new_lmsi) > 0)
      {
         l_cancelLoc->bit_mask |= OMAP3_new_lmsi_present;
         l_cancelLoc->new_lmsi.length = 4;
         atohx((char *)l_cancelLoc->new_lmsi.value,(char *)m_new_lmsi);      
      }
   }

   l_request.m_structBuffer = (void*) l_cancelLoc;
   l_request.m_TimerValue = g_MmConfigReaderObj->m_CL_Invoke_Timer;
   g_sc.sendMsg(this, &l_request);

   ContinueReq(l_CancelLocDlgId);
   DLOG(0,0,"Cancel Location request followed by delimiter sent, Configured Retry attempts %d, Number of Attempts made%d",m_Emergency_CL_Retry_Attempts,m_retryCount);  
   return true;
}

bool CtxtCancelLocation::SendCancelLocationV2()//u8 *imsi,u8 *lmsi,u8 *vlrno,u8 *hlrno )
{
   int l_CancelLocDlgId = g_sc.getNewDialogue();
   if(l_CancelLocDlgId < 1)
   {
      CLOG(0,0,"Cancel location dialog id %d is less then 0",l_CancelLocDlgId);
      return false;
   }
   DLOG(0,0,"Cancel Location on dialog ID %d",l_CancelLocDlgId);
   DLOG(0, 0, "Sending CancelLocation Map Open Req");
   MapOpenReq l_mapOpenReq(l_CancelLocDlgId, MAP_V2);
   l_mapOpenReq.m_ApplCntxt = MAP_AC_CODE_locationCancel;
   DLOG(0,0,"Configuring SCCP address in Cancel Location for Destination number %s and HLR Number %s",(char *)vlrno,(char *)hlrno);
   configureSccpAddress(&l_mapOpenReq.m_OrigAddr,L_ROUTE_ON_GT,1002,g_ConfigData->i_NgConfigData.m_selfAddress.ssn,(char *)hlrno);
   if(true == configureSccpAddress(&l_mapOpenReq.m_DestAddr,L_ROUTE_ON_GT,0,m_ssn,(char *)vlrno))
      g_sc.sendMsg(this, &l_mapOpenReq);

   m_tdr.setMapVersion(2);
   //m_tdr.setCallingAddr((s8 *)vlrno);
   m_tdr.setRemoteAddr((s8 *)vlrno);
   m_tdr.setRemoteAddrSsn(m_ssn);
   LLOG(0, 0, "Sending CancelLoc Request,IMSI %s and LMSI %s",imsi,lmsi);
   MapSpecificRequest l_request(l_CancelLocDlgId, MAP_OP_CODE_cancelLocation,MAP_V2);
   DECLARE(OMAP2_CancelLocationArg,l_cancelLoc,2,"OMAP2_CancelLocationArg",DeclareFunc);

   int l = strlen((char *)imsi);
   if((strncmp((char *)lmsi,"00000000",8)==0) || (strcmp((char *)lmsi,"0")==0))
   {
      l_cancelLoc->choice = OMAP2_CancelLocationArg_imsi_chosen;
      l_cancelLoc->u.imsi.length = (l+1)/2;
      StringToBCD(l_cancelLoc->u.imsi.value,imsi,l);      
   }
   else
   {
      l_cancelLoc->choice = OMAP2_CancelLocationArg_imsi_WithLMSI_chosen;
      l_cancelLoc->u.imsi_WithLMSI.imsi.length = (l+1)/2;
      StringToBCD(l_cancelLoc->u.imsi_WithLMSI.imsi.value,imsi,l);
      l_cancelLoc->u.imsi_WithLMSI.lmsi.length = 4;
      //memcpy(l_cancelLoc->u.imsi_WithLMSI.lmsi.value,lmsi,4);
      atohx((char *)l_cancelLoc->u.imsi_WithLMSI.lmsi.value,(char *)lmsi);
      m_tdr.setHex(TDR_INDEX_LMSI,(char *)l_cancelLoc->u.imsi_WithLMSI.lmsi.value,4);
   }

   l_request.m_structBuffer = (void*) l_cancelLoc;
   l_request.m_TimerValue = g_MmConfigReaderObj->m_CL_Invoke_Timer;
   g_sc.sendMsg(this, &l_request);

   DLOG(0, 0, "Sending Delimiter Req ...");
   MapDelimiterReq l_del(l_CancelLocDlgId);
   g_sc.sendMsg(this, &l_del);
   DLOG(0,0,"Cancel Location request followed by delimiter sent, Configured Retry attempts %d, Number of Attempts %d",m_Emergency_CL_Retry_Attempts,m_retryCount);  
   return true;
}

bool CtxtCancelLocation::SendCancelLocationV1()//u8 *imsi,u8 *lmsi,u8 *vlrno,u8 *hlrno )
{
   int l_CancelLocDlgId = g_sc.getNewDialogue();
   if(l_CancelLocDlgId < 1)
   {
      CLOG(0,0,"Cancel location dialog id %d is less then 0",l_CancelLocDlgId);
      return false;
   }
   DLOG(0, 0, "Sending CancelLocation Map Open Req");
   MapOpenReq l_mapOpenReq(l_CancelLocDlgId, MAP_V1);
   l_mapOpenReq.m_ApplCntxt = MAP_AC_CODE_locationCancel;
   DLOG(0,0,"Configuring SCCP address in Cancel Location for Destination number %s and HLR Number %s",(char *)vlrno,(char *)hlrno);
   configureSccpAddress(&l_mapOpenReq.m_OrigAddr,L_ROUTE_ON_GT,1002,g_ConfigData->i_NgConfigData.m_selfAddress.ssn,(char *)hlrno);
   if(true == configureSccpAddress(&l_mapOpenReq.m_DestAddr,L_ROUTE_ON_GT,1002,m_ssn,(char *)vlrno))
      g_sc.sendMsg(this, &l_mapOpenReq);

   m_tdr.setMapVersion(1);
   //m_tdr.setCallingAddr((s8 *)vlrno);
   m_tdr.setRemoteAddr((s8 *)vlrno);
   m_tdr.setRemoteAddrSsn(m_ssn);
   LLOG(0, 0, "Sending CancelLocation Request,IMSI %s and LMSI %s",imsi,lmsi);
   MapSpecificRequest l_request(l_CancelLocDlgId, MAP_OP_CODE_cancelLocation,MAP_V1);

   DECLARE(OMAP1_CancelLocationArg,l_cancelLoc,1,"OMAP1_CancelLocationArg",DeclareFunc);

   int l = strlen((char *)imsi);
   if((strncmp((char *)lmsi,"00000000",8)==0) || (strcmp((char *)lmsi,"0")==0))
   {
      l_cancelLoc->choice = OMAP1_CancelLocationArg_imsi_chosen;
      l_cancelLoc->u.imsi.length = (l+1)/2;
      StringToBCD(l_cancelLoc->u.imsi.value,imsi,l);
   }
   else
   {
      l_cancelLoc->choice = OMAP1_imsi_WithLMSI_chosen;
      l_cancelLoc->u.imsi_WithLMSI.imsi.length = (l+1)/2;
      StringToBCD(l_cancelLoc->u.imsi_WithLMSI.imsi.value,imsi,l);
      l_cancelLoc->u.imsi_WithLMSI.lmsi.length = 4;
      atohx((char *)l_cancelLoc->u.imsi_WithLMSI.lmsi.value,(char *)lmsi);
      m_tdr.setHex(TDR_INDEX_LMSI,(char *)l_cancelLoc->u.imsi_WithLMSI.lmsi.value,4);
   }

   l_request.m_structBuffer = (void*) l_cancelLoc;
   l_request.m_TimerValue = g_MmConfigReaderObj->m_CL_Invoke_Timer;
   g_sc.sendMsg(this, &l_request);

   DLOG(0, 0, "Sending Delimiter Req ...");
   MapDelimiterReq l_del(l_CancelLocDlgId);
   g_sc.sendMsg(this, &l_del);
   DLOG(0,0,"Cancel Location request followed by delimiter sent, Configured Retry attempts %d, Number of Attempts %d",m_Emergency_CL_Retry_Attempts,m_retryCount);  
   return true;
}

void CtxtCancelLocation::CloseReq(int l_UserDlgId)
{
   DLOG(0, 0, "Closing the Dialogue");
   MapCloseReq l_closeReq(l_UserDlgId);
   g_sc.sendMsg(this, &l_closeReq);
}

void CtxtCancelLocation::ContinueReq(int l_UserDlgId)
{
   DLOG(0, 0, "Sending Delimiter Req ...");
   MapDelimiterReq l_del(l_UserDlgId);
   g_sc.sendMsg(this, &l_del);
}

void FormXMLRequest(char *XmlReq,int NodeType,u8 *imsi,u8 *lmsi,u8 *l_ActHLRAddr,u8 *l_vlrno,int updateSubsdata,int p_ImsiType, char *p_requestType, char *p_msc)
{
   //memset(XmlReq,'\0',sizeof(XmlReq));
   strcat(XmlReq,"<CANCEL_LOC><IMSI>");
   strcat(XmlReq,(char *)imsi);
   if(NodeType == 1)
   {
      strcat(XmlReq,"</IMSI><TYPE>GSM</TYPE><LMSI>");
   }
   else if(NodeType == 2)
   {
      strcat(XmlReq,"</IMSI><TYPE>GPRS</TYPE><LMSI>");
   }
   else
   {
      CLOG(0,0,"Invalid Node type %d received",NodeType);
      return;
   }
   strcat(XmlReq,(char *)lmsi);
   strcat(XmlReq,"</LMSI><DEST_ADDRESS>");
   strcat(XmlReq,(char *)l_vlrno);
   strcat(XmlReq,"</DEST_ADDRESS><ORIG_ADDRESS>");
   strcat(XmlReq,(char *)l_ActHLRAddr);
   strcat(XmlReq,"</ORIG_ADDRESS><CL_TYPE>0</CL_TYPE><CLR_SUBS_DATA>");
   char l_UpdateFlag[2];
   snprintf(l_UpdateFlag,2,"%d",updateSubsdata);
   strcat(XmlReq,(char *)l_UpdateFlag);
   strcat(XmlReq,"</CLR_SUBS_DATA><IMSI_TYPE>");
   char l_ImsiType[2];
   snprintf(l_ImsiType,2,"%d",p_ImsiType);
   strcat(XmlReq,(char *)l_ImsiType);
   strcat(XmlReq,"</IMSI_TYPE>");

   char l_requestType[100+1];
   snprintf(l_requestType, sizeof(l_requestType), "<REQUEST_TYPE>%s</REQUEST_TYPE><MSC_NUMBER>%s</MSC_NUMBER>", p_requestType, p_msc);
   strcat(XmlReq,l_requestType);
   strcat(XmlReq,"</CANCEL_LOC>");

   if(strlen(XmlReq) > 499)
      XmlReq[500] = '\0';
}



unsigned int map3tomap2odb(unsigned int GeneralOdb)
{
   char out[32];
   memset(out,'0',32);
   dec2bin(GeneralOdb,out);
   unsigned int odbint = 0;
   char odb[8];
   memset(odb,'0',8);
   //int m;
   //printf("odbv3 is %s\n",out);
   for(int v=1;v<7;v++)
   {
      //printf("odbv3[%d] = %c\t",v-1,out[v]);
      if(out[v] == '1')
      {
         odb[v-1] = '1';
         int expo = 7-v+1;
         odbint += pow(2,expo);
         //printf("odbv3[%d]is 1, new data to int %d\n",v-1,odbint);
      }
      else
      {
         //printf("odbv3[%d] is not 1\n",v-1);
      }
   }
   DLOG(0,0,"ODBV3 data is int is %ld, str is %s, ODBV2 val str is %s int is %ld",GeneralOdb,out,odb,odbint);
   return odbint;
}

#if 0
unsigned short itoChar(unsigned char *character, unsigned int deci)
{
   //DLOG(0,0,"Received ODB in int as %ld",deci);
   unsigned short length = 0;
   char out[33];
   memset(out,'0',33);
   dec2bin(deci,out);
   //DLOG(0,0,"ODB in bit form %s",out);
   //strncpy((char *)character,out,32);
   //DLOG(0,0,"Copied data %s",character);
   for(int l = 32;l > 0;l--)
   {
      if(out[l] == '1')
      {                      
         length = l;
         break;
      }
   }
   unsigned int l_inte = 0;
   for(int a = 1; a < 9;a++)
   {
      if(out[a] == '1')
      {
         int exp = 7-a+1;
         l_inte += pow(2,exp); 
      }
   }
   character[0] = l_inte;
   l_inte = 0;
   for(int a = 9,j = 1; a < 17;a++,j++)
   {
      if(out[a] == '1')
      {
         int exp = 7-j+1;
         l_inte += pow(2,exp); 
      }
   }
   character[1] = l_inte;
   l_inte = 0;
   for(int a = 17,j = 1; a < 25;a++,j++)
   {
      if(out[a] == '1')
      {
         int exp = 7-j+1;
         l_inte += pow(2,exp); 
      }
   }
   character[2] = l_inte;
   l_inte = 0;
   for(int a = 25,j =1; a < 33;a++,j++)
   {
      if(out[a] == '1')
      {
         int exp = 7-j+1;
         l_inte += pow(2,exp); 
      }
   }
   character[3] = l_inte;

   //DLOG(0,0,"bit string %s Significant Length is %d data %02x%02x%02x%02x",out,length,character[0],character[1],character[2],character[3]);
   return length;
}
#endif

void dec2bin(unsigned int decimal, char *binary)
{
   int  k = 0, n = 0;
   int  neg_flag = 0;
   int  remain;
   //   unsigned int  old_decimal;  // for test
   char temp[80];

   /*if (decimal < 0)
     {
     decimal = -decimal;
     neg_flag = 1;
     }*/
   //do
   for(int v=0;v<32;v++)
   {
      //    old_decimal = decimal;   // for test
      remain    = decimal % 2;
      // whittle down the decimal number
      decimal   = decimal / 2;
      // this is a test to show the action
      //printf("%d/2 = %d  remainder = %d\n", old_decimal, decimal, remain);
      // converts digit 0 or 1 to character '0' or '1'
      temp[k++] = remain + '0';

   } //while (decimal > 0);

   if (neg_flag)
      temp[k++] = '-';       // add - sign
   else
      temp[k++] = ' ';       // space

   // reverse the spelling
   while (k >= 0)
      binary[n++] = temp[--k];

   binary[n-1] = 0;         // end with NULL
}

unsigned int HplmnOdb(unsigned int hplmn)
{
   //printf("Received hplmn ODB is %d",hplmn);
   unsigned  int l_HplmnOdb = 0;
   switch(hplmn)
   {
      case 1:
         l_HplmnOdb = 0x10000000;
         break;
      case 2:
         l_HplmnOdb = 0x20000000;
         break;
      case 3:
         l_HplmnOdb =  0x20000000;
         l_HplmnOdb |= 0x10000000;
         break;
      case 4:
         l_HplmnOdb = 0x40000000;
         break;
      case 5:
         l_HplmnOdb =  0x40000000;
         l_HplmnOdb |= 0x10000000;
         break;
      case 6:
         l_HplmnOdb =  0x40000000;
         l_HplmnOdb |= 0x20000000;
         break;
      case 7:
         l_HplmnOdb =  0x40000000;      
         l_HplmnOdb |= 0x20000000;
         l_HplmnOdb |= 0x10000000;
         break;
      case 8:
         l_HplmnOdb =  0x80000000;      
         break;
      case 9:
         l_HplmnOdb =  0x80000000;
         l_HplmnOdb |= 0x20000000;
         break;
      case 10:
         l_HplmnOdb =  0x80000000;
         l_HplmnOdb |= 0x20000000; 
         break;
      case 11:
         l_HplmnOdb =  0x80000000;
         l_HplmnOdb |= 0x20000000;
         l_HplmnOdb |= 0x10000000;
         break;
      case 12:
         l_HplmnOdb =  0x80000000;
         l_HplmnOdb |= 0x40000000;
         break;
      case 13:
         l_HplmnOdb =  0x80000000;
         l_HplmnOdb |= 0x40000000;
         l_HplmnOdb |= 0x10000000;
         break;
      case 14:
         l_HplmnOdb =  0x80000000;
         l_HplmnOdb |= 0x40000000;
         l_HplmnOdb |= 0x20000000;
         break;
      case 15:
         l_HplmnOdb =  0x80000000;
         l_HplmnOdb |= 0x40000000;
         l_HplmnOdb |= 0x20000000;
         l_HplmnOdb |= 0x10000000;
         break; 
      default:
         break;    
   }
   DLOG(0,0,"ODB HPLMN data got %ld, Returning ODB HPLMN data %ld",hplmn,l_HplmnOdb)
      return  l_HplmnOdb;
}

bool fillAtmV3(int DlgID,unsigned char *TraceRef,unsigned char *TraceType,unsigned char *Omc_ID,OMAP3_ActivateTraceModeArg *l_atm)
{
   LLOG(0,0,"Filling Activate Trace Mode for Dialog id %d with TraceRef %s,TraceType %s,OMC_ID %s",DlgID,TraceRef,TraceType,Omc_ID);
   l_atm->traceReference.length = 2;
   atohx((char *)l_atm->traceReference.value,(char *)TraceRef);
   unsigned char l_traceType[2];
   memset(l_traceType,'\0',sizeof(l_traceType));
   atohx((char *)l_traceType,(char *)TraceType);
   l_atm->traceType = l_traceType[0];
   l_atm->bit_mask = 0;
   l_atm->bit_mask |= OMAP3_omc_Id_present;
   char l_OmcID[21];
   memset(l_OmcID,'\0',sizeof(l_OmcID));
   strncpy(l_OmcID,"19",2);
   strcat(l_OmcID,(char *)Omc_ID);
   l_atm->omc_Id.length = (strlen((char *)l_OmcID)+1)/2;
   StringToBCD(l_atm->omc_Id.value,(u8 *)l_OmcID,strlen((char *)l_OmcID));
   return true;
}

bool fillAtmV2(int DlgID,unsigned char *TraceRef,unsigned char *TraceType,unsigned char *Omc_ID,OMAP2_ActivateTraceModeArg *l_atm)
{
   LLOG(0,0,"Filling Activate Trace Mode for Dialog id %d with TraceRef %s,TraceType %s,OMC_ID %s",DlgID,TraceRef,TraceType,Omc_ID);
   l_atm->traceReference.length = 2;
   atohx((char *)l_atm->traceReference.value,(char *)TraceRef);
   unsigned char l_traceType[2];
   memset(l_traceType,'\0',sizeof(l_traceType));
   atohx((char *)l_traceType,(char *)TraceType);
   l_atm->traceType = l_traceType[0];
   l_atm->bit_mask |= OMAP2_omc_Id_present;

   char l_OmcID[21];
   memset(l_OmcID,'\0',sizeof(l_OmcID));
   strncpy(l_OmcID,"19",2);
   strcat(l_OmcID,(char *)Omc_ID);
   l_atm->omc_Id.length = (strlen((char *)l_OmcID)+1)/2;
   StringToBCD(l_atm->omc_Id.value,(u8 *)l_OmcID,strlen((char *)l_OmcID));
   return true;
}

bool fillAtmV1(int DlgID,unsigned char *TraceRef,unsigned char *TraceType,unsigned char *Omc_ID,OMAP1_ActivateTraceModeArg *l_atm)
{
   LLOG(0,0,"Filling Activate Trace Mode for Dialog id %d with TraceRef %s,TraceType %s,OMC_ID %s",DlgID,TraceRef,TraceType,Omc_ID);
   l_atm->traceReference.length = 2;
   atohx((char *)l_atm->traceReference.value,(char *)TraceRef);
   unsigned char l_traceType[2];
   memset(l_traceType,'\0',sizeof(l_traceType));
   atohx((char *)l_traceType,(char *)TraceType);
   l_atm->traceType = l_traceType[0];
   l_atm->bit_mask |= OMAP1_ActivateTraceModeArg_omcId_present;
   char l_OmcID[21];
   memset(l_OmcID,'\0',sizeof(l_OmcID));
   strncpy(l_OmcID,"19",2);
   strcat(l_OmcID,(char *)Omc_ID);
   l_atm->omcId.length = (strlen((char *)l_OmcID)+1)/2;
   StringToBCD(l_atm->omcId.value,(u8 *)l_OmcID,strlen((char *)l_OmcID));
   return true;
}

#if 0
bool GetNetworkHlrAddr(u8* p_NetworkHlrAddr, u8 *p_OriginalHlrAddr)
{
   char l_OrigGT[21];
   snprintf(l_OrigGT,20,"%s",p_OriginalHlrAddr);
   map<char*, char*>::iterator l_it;
   l_it = g_OtherConfigData->m_GtTranslationMap.find(l_OrigGT);
#if 0 // As given by rgopal
   if (l_it != g_OtherConfigData->m_GtTranslationMap.end())// matches the list of GTS
   {
      LLOG(0,1,"Found gt in the map. translating");
      strcpy((char *)p_NetworkHlrAddr, l_it->second);
   }
   else
   {
      LLOG(0,1,"Didn't found gt in the map. not translating");
      strcpy((char *)p_NetworkHlrAddr,(char *) p_OriginalHlrAddr);
   }
#endif
   for(l_it = g_OtherConfigData->m_GtTranslationMap.begin();l_it != g_OtherConfigData->m_GtTranslationMap.end();)
   {
      DLOG(0,0,"In map GT [%s] OrigGT [%s]",l_it->first,l_OrigGT);
      int l_res = strcmp(l_it->first,l_OrigGT);
      if(l_res == 0)
      {
         LLOG(0,0,"Found gt in the map. translating to [%s]",l_it->second);
         strcpy((char *)p_NetworkHlrAddr, l_it->second);
         return true;
      }
      else if(l_it == g_OtherConfigData->m_GtTranslationMap.end())
      {
         LLOG(0,0,"Didn't found gt in the map. not translating");
         strcpy((char *)p_NetworkHlrAddr,(char *) p_OriginalHlrAddr);
         return false;
      }
      else
      {
         l_it++;
      }
   }
   return true;
}
#endif

