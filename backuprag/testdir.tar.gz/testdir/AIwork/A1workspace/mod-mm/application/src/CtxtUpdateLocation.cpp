/*******************************************************************************
 * File        : CtxtUpdateLocation.cpp
 * Author      : VenkatRaman
 * Description : To Process Update Location request from a VLR
 * Created on  : Feb 22, 2010, 10:36 AM IST
 *******************************************************************************/

#include <CtxtUpdateLocation.h>
#include <CtxtCancelLocation.h>
#include <CommonDefines.h>
#include <stdio.h>
#include <ServiceCoordinator.h>
#include <Logger.h>
#include <DbQueryMsg.h>
#include <DbActiveObject.h>    
#include <MmConfigReader.h>
#include <ISDData.h>
#include <DataUnion.h>
#include <Utilities.h>
#include <sys/time.h>
#include <AsnCodec.h>
#include <SnmpInterface.h>
#include <DiameterConstants.h>
#include <ExtendedServiceCoordinator.h>
#include <CommonData.h>
#include <GutilDAFInterface.h>

extern int g_UpdateLocationGsmTrap;
extern int g_FreeMsisdnRemainingTrap;
extern int g_TransientMsisdnUnavailableTrap;
extern int g_TransientMsisdnThresholdTrap;
extern int g_LocalMsisdnUnavailableTrap;
extern int g_LocalMsisdnThresholdTrap;
extern int g_DynamicAllocFailTrap;


extern AsnCodec g_AsnCodecO3;
extern AsnCodec g_AsnCodecO2;
extern AsnCodec g_AsnCodecO1;

time_t g_LastTimerExecuted=0;
time_t g_CurrTimeExecuted=time(NULL);

GenericUtilitiesFrameworkInterface *g_daf = NULL;

CtxtUpdateLocation::CtxtUpdateLocation()
{
   DLOG(0,0,"CtxtUpdateLocation::CtxtUpdateLocation() Cons");
   flag = false;
   memset(&GsmProfile, '\0', sizeof(GsmProfile));
   memset(&GenProfile,'\0',sizeof(GenProfile));
   memset(&l_updv3,'\0',sizeof(l_updv3));
   memset(&l_updv2,'\0',sizeof(l_updv2));
   memset(&l_updv1,'\0',sizeof(l_updv1));
   memset(m_SubsData, '\0', sizeof(m_SubsData));
   memset(m_ExtnCntrData,'\0',sizeof(m_ExtnCntrData));
   l_Version = 0;
   m_MoreDataToSend = false;
   index = l_OpCode =  m_TraceErrorCode = 0;
   numOfParams = csiParam = MoreData = 0;
   m_TrapReqd = m_SendATM = m_ProvErrRcvd = m_MoreDataToSend =false;
   memset(&GsmProfile,'\0',sizeof(GsmProfile));
   memset(&GenProfile,'\0',sizeof(GenProfile));
   memset(m_SccpGt,'\0',sizeof(m_SccpGt));
   memset(l_AccId,'\0',sizeof(l_AccId));
   memset(l_actMsisdn,'\0',sizeof(l_actMsisdn));
   memset(l_priMsisdn,'\0',sizeof(l_priMsisdn));
   memset(l_priImsi,'\0',sizeof(l_priImsi));
   memset(l_AlertMsisdn,'\0',sizeof(l_AlertMsisdn));
   memset(m_activeImsi,'\0',sizeof(m_activeImsi));
   m_SendATM = false;
   index = VcsiIndex = ScsiIndex = SsIndex = 0;
   m_FirstUlFlag = 0;
   m_MsisdnAllocStatus = 5;
   memset(m_UploadedMsisdn,'\0',sizeof(m_UploadedMsisdn));
   memset(m_GSM_Seq_id,'\0',sizeof(m_GSM_Seq_id));
   memset(m_VLR_Restricted_Bear_Codes,'\0',sizeof(m_VLR_Restricted_Bear_Codes));
   memset(m_VLR_Restricted_Tele_Codes,'\0',sizeof(m_VLR_Restricted_Tele_Codes));
   m_tdr.setString(TDR_INDEX_ERR_CODE,"0");
   memset(m_Cap_Action,'\0',sizeof(m_Cap_Action));
   snprintf(m_Cap_Action[0],sizeof(m_Cap_Action[0]),"FAIL_UPDATE_LOCATION");
   snprintf(m_Cap_Action[1],sizeof(m_Cap_Action[1]),"CONT_UL_WIHTOUT_CAMEL");
   snprintf(m_Cap_Action[2],sizeof(m_Cap_Action[2]),"DONT_SEND_CAMEL");


   m_sp_index = 0;
   m_sp_SsIndex = 0;
   m_sp_flag = false;
   m_sp_PrevSS = 0;
   m_sp_SdLen = 0;

   m_sp_secondChunk = false;
   m_sp_SecondBS = false;
   m_sp_pLen = 0;
   m_sp_len = 0;
   memset(m_sp_imsi,'\0',sizeof(m_sp_imsi));
   m_sp_SendParamPresent = false;

   m_fIsd = false;
   memset(m_TransId,'\0',sizeof(m_TransId));
   l_GenOdb = 0;
   l_PlmnOdb = 0;
   memset(m_Orig_Imei,'\0',sizeof(m_Orig_Imei));
   m_imsOcsiProfId = 0;

}

CtxtUpdateLocation::~CtxtUpdateLocation()
{
   DLOG(0, 0, "CtxtUpdateLocation::~CtxtUpdateLocation() Des");
}

bool CtxtUpdateLocation::processMessage(Msg *p_MsgPtr,bool &p_DeleteFlag)
{
   DLOG(0, 0, "Start of CtxtUpdateLocation::processMsg function Delete flag %d",p_DeleteFlag);

   if(1 == g_IMEI_EncrFlag)
   {
      TLOG(0,0,"Config reader IMEI encryption flag is set to 1");
      m_tdr.setInteger(TDR_INDEX_SMSM_GPRS_SM_DEL_OUTCOME,1);
   }
   MapSpecificMsg *l_specMsg = NULL;
   int l_dlgId = 0;
   int l_UserDlgId = 0;

   switch (p_MsgPtr->m_MsgType)
   {
      case MSG_TYPE_MAP:
         switch (((MapMsg*) p_MsgPtr)->m_MapMsgType)
         {
            case MAP_MSG_TYPE_COMMON:
               switch (((MapCommonMsg*) p_MsgPtr)->m_MapCommonMsgType)
               {
                  case MAP_CMN_OPEN_IND:
                     {
                        TLOG(0,0,"MAP_CMN_OPEN_IND received remote ssn: %d gt: %s",
                              ((MapOpenInd*)p_MsgPtr)->m_OrigAddr.ssn,
                              ((MapOpenInd*)p_MsgPtr)->m_OrigAddr.globalTitle.addressInformation);
                        strcpy((char *)m_SccpGt,((MapOpenInd*)p_MsgPtr)->m_OrigAddr.globalTitle.addressInformation);
                        m_tdr.setString(TDR_INDEX_VLR_ADDRESS,(char*)m_SccpGt);
                        m_tdr.setString(TDR_INDEX_MSC_ADDRESS,(char*)m_SccpGt);
                     }
                     break;

                  case MAP_CMN_DELIMITER_IND:
                     {
                        TLOG(0, 0, "MAP_DELIMITER_IND received");
                        if(m_ProvErrRcvd)
                        {
                           WLOG(0,0,"Provider error followed by Delimiter Rcvd, sending End");
                           CloseReq(((MapMsg*)p_MsgPtr)->m_UserDlgId);
                        }

                     }
                     break;

                  case MAP_CMN_CLOSE_IND:
                     {
                        TLOG(0, 0, "MAP_CLOSE_IND received");
                        return true;
                     }
                     break;

                  case MAP_CMN_U_ABORT_IND:
                     {
                        WLOG(0, 0, "MAP_U_ABORT_IND received");
                        m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_U_ABORT_RCVD);
                        if(l_state == m_atm)
                        {
                           m_TraceErrorCode = 101;
                        }
                        m_TrapReqd = true;
                        if(l_state != m_usds && l_state != m_usdf)
                        {
                           WLOG(0,0,"Abort received before sending UPD response,Call state here is %d,updating UPD fail data",l_state);
                           m_TrapReqd = true;
                           UpdateUpdFailData(((MapMsg*)p_MsgPtr)->m_UserDlgId);
                        }
                     }
                     break;

                  case MAP_CMN_P_ABORT_IND:
                     {
                        WLOG(0,0,"MAP_P_ABORT_IND received");
                        m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_P_ABORT_RCVD);
                        if(l_state == m_atm)
                        {
                           m_TraceErrorCode = 102;
                        }
                        m_TrapReqd = true;
                        if(l_state != m_usds && l_state != m_usdf)
                        {
                           WLOG(0,0,"Abort received before sending UPD response,Call state here is %d,updating UPD fail data",l_state);
                           m_TrapReqd = true;
                           UpdateUpdFailData(((MapMsg*)p_MsgPtr)->m_UserDlgId);
                        }
                     }
                     break;

                  case MAP_CMN_NOTICE_IND:
                     {
                        WLOG(0, 0, "MAP_NOTICE_IND received , Sending Close with Pre-arranged end");
                        MapCloseReq l_closeReq(((MapMsg*)p_MsgPtr)->m_UserDlgId);
                        l_closeReq.m_CloseType = MAP_CLOSE_TYPE_PRE_ARRANGED_END;
                        g_sc.sendMsg(this, &l_closeReq);
                        m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_NOTICE_RCVD);
                        if(l_state == m_atm)
                        {
                           m_TraceErrorCode = 103;
                        }
                        m_TrapReqd = true;

                        if(l_state != m_usds || l_state != m_usdf)
                        {
                           WLOG(0,0,"Notice Ind received before sending UPD response,Call state here is %d,updating UPD fail data",l_state);
                           m_TrapReqd = true;
                           UpdateUpdFailData(((MapMsg*)p_MsgPtr)->m_UserDlgId);
                        }
                     }
                     break;

                  default:
                     {
                        CLOG(0, 0, "Unknown Msg received [%d]", ((MapCommonMsg*) p_MsgPtr)->m_MapCommonMsgType);
                     }
                     break;
               }
               break;

            case MAP_MSG_TYPE_SPECIFIC:
               {
                  DLOG(0, 0, "MAP_MSG_TYPE_SPECIFIC received");
                  l_specMsg = (MapSpecificMsg*) p_MsgPtr;
                  l_UserDlgId = l_specMsg->m_UserDlgId;
                  TLOG(0, 0, "MAP_MSG_TYPE_SPECIFIC received dlgId[%d] UserDlgId[%d]",l_dlgId, l_UserDlgId);

                  switch (((MapSpecificMsg*) p_MsgPtr)->m_MapSpecificEventType)
                  {
                     case MAP_SPEC_EVENT_INDICATION:
                        {
                           DLOG(0, 0, "MAP_SPEC_EVENT_INDICATION : Received Update Location Request, Opcode %d, Version : %d",((MapSpecificMsg*) p_MsgPtr)->m_OpCode,((MapSpecificMsg*)p_MsgPtr)->m_Version);
                           l_OpCode = (int)(((MapSpecificMsg*) p_MsgPtr)->m_OpCode);

                           switch (((MapSpecificMsg*) p_MsgPtr)->m_OpCode)
                           {
                              case MAP_OP_CODE_updateLocation://OpCode = 2
                                 {
                                    l_Version = ((MapSpecificMsg*)p_MsgPtr)->m_Version;
                                    DLOG(0,0,"UL Map msg verions %d",l_Version);
                                    switch(l_Version)
                                    {                                       
                                       case 3:
                                          {
                                             if (false == ((MapSpecificMsg*)p_MsgPtr)->m_allocatedFlag)
                                             {
                                                RetErrorV3(l_UserDlgId,UnexpectedData);
                                             }
                                             else
                                             {                                                
                                                IMAP3_UpdateLocationArg *l_temp = (IMAP3_UpdateLocationArg*) (((MapSpecificMsg*) p_MsgPtr)->m_structBuffer);
                                                strcpy((char*)m_ExtnCntrData,((MapSpecificMsg*)p_MsgPtr)->m_extensionContainerBuffer);
                                                DLOG(0,0,"extension Container Buffer [%s] lcl [%s]",((MapSpecificMsg*)p_MsgPtr)->m_extensionContainerBuffer,m_ExtnCntrData);
                                                if(NULL == g_spdPtr)
                                                {
                                                   ELOG(0,0,"g_spdPTR is NULL .. profile Loading Failed returning SystemFailure");
                                                   RetErrorV3(l_UserDlgId,SystemFailure);
                                                   return false;
                                                }
                                                DLOG(0,0,"Reveived Version 3 Update Location request Message,Calling CheckParameters function");
                                                if(true == CheckParametersV3(l_UserDlgId,l_temp))
                                                {
                                                   TLOG(0,0,"Parameters are correct calling procedure to retreive data for received UPD");
                                                   l_state= m_rsd;
                                                   RetrieveData(l_UserDlgId,l_updv3.imsi,l_updv3.vlr+2);
                                                }
                                                else
                                                {
                                                   WLOG(0,0,"Parameter mismatch, returning error and closing the transaction");
                                                   RetErrorV3(l_UserDlgId,UnexpectedData);                                                   
                                                }
                                             }
                                          }
                                          break;
                                       case 2:
                                          {
                                             if (false == ((MapSpecificMsg*)p_MsgPtr)->m_allocatedFlag)
                                             {
                                                RetErrorV2(l_UserDlgId,UnexpectedData);
                                             }
                                             else
                                             {
                                                IMAP2_UpdateLocationArg *l_temp = (IMAP2_UpdateLocationArg*) (((MapSpecificMsg*) p_MsgPtr)->m_structBuffer);
                                                if(NULL == g_spdPtr)
                                                {
                                                   ELOG(0,0,"g_spdPTR is NULL .. profile Loading Failed returning SystemFailure");
                                                   RetErrorV2(l_UserDlgId,SystemFailure);
                                                   return false;
                                                }
                                                DLOG(0,0,"Reveived Version 2 Update Location request Message,Calling CheckParameters function\n");
                                                if(true == CheckParametersV2(l_UserDlgId,l_temp))
                                                {
                                                   TLOG(0,0,"Parameters are correct calling procedure to retreive data for received UPD");
                                                   l_state= m_rsd;
                                                   RetrieveData(l_UserDlgId,l_updv2.imsi,l_updv2.vlr+2);
                                                }
                                                else
                                                {
                                                   WLOG(0,0,"Parameters does not match, returning error and closing the transaction");
                                                   RetErrorV2(l_UserDlgId,UnexpectedData);
                                                }
                                             }
                                          }
                                          break;
                                       case 1:
                                          {
                                             if (false == ((MapSpecificMsg*)p_MsgPtr)->m_allocatedFlag)
                                             {
                                                RetErrorV1(l_UserDlgId,UnexpectedData);
                                             }
                                             else
                                             {
                                                IMAP1_UpdateLocationArg *l_temp = (IMAP1_UpdateLocationArg*) (((MapSpecificMsg*) p_MsgPtr)->m_structBuffer);
                                                if(NULL == g_spdPtr)
                                                {
                                                   ELOG(0,0,"g_spdPTR is NULL .. profile Loading Failed returning SystemFailure");
                                                   RetErrorV1(l_UserDlgId,SystemFailure);
                                                   return false;
                                                }
                                                DLOG(0,0,"Reveived Version 1 Update Location Message,Calling CheckParameters function");
                                                if(true == CheckParametersV1(l_UserDlgId,l_temp))
                                                {
                                                   TLOG(0,0,"Parameters are correct calling procedure to retreive data for received UPD");
                                                   l_state= m_rsd;
                                                   DLOG(0,0,"Calling Retrieve data with IMSI %s and VLR %s",l_updv1.imsi,l_updv1.vlr+2);
                                                   RetrieveData(l_UserDlgId,l_updv1.imsi,l_updv1.vlr+2);
                                                }
                                                else
                                                {
                                                   WLOG(0,0,"Parameters does not match, returning error and closing the transaction");
                                                   RetErrorV1(l_UserDlgId,UnexpectedData);                                                   
                                                }
                                             }
                                          }
                                          break;
                                       default:
                                          {
                                             ELOG(0,0,"Unrecognizable version of UpdateLocation Request received");
                                             return false;
                                          }
                                    }
                                 }
                                 break;

                              case MAP_OP_CODE_restoreData ://OpCode = 57 (39 in Hexa)
                                 {
                                    DLOG(0, 0, "Restore Data request Received");
                                    switch(((MapSpecificMsg*)p_MsgPtr)->m_Version)
                                    {
                                       case 2:
                                          {
                                             if (false == ((MapSpecificMsg*)p_MsgPtr)->m_allocatedFlag)
                                             {
                                                RetErrorV2(l_UserDlgId,UnexpectedData);
                                             }
                                             else
                                             {
                                                IMAP2_RestoreDataArg *l_rd = (IMAP2_RestoreDataArg*) (((MapSpecificMsg*) p_MsgPtr)->m_structBuffer);
                                                if(NULL == g_spdPtr)
                                                {
                                                   ELOG(0,0,"g_spdPTR is NULL .. profile Loading Failed returning SystemFailure");
                                                   RetErrorV2(l_UserDlgId,SystemFailure);
                                                   return false;
                                                }
                                                DLOG(0,0,"Reveived Restore Data version 2 message");
                                                l_Version = 2;
                                                if(true == CheckParametersRSDV2(l_UserDlgId,l_rd))
                                                {
                                                   DLOG(0,0,"Check parameters success, calling DB query to retrieve Subscriber profile");
                                                   l_state = m_rsd;
                                                   RetrieveData(l_UserDlgId,l_updv2.imsi,l_updv2.vlr);
                                                }
                                                else
                                                {
                                                   DLOG(0,0,"Check parameters fail, sending error and closing");
                                                   RetErrorV2(l_UserDlgId,UnexpectedData);
                                                }
                                             }
                                          }
                                          break;
                                       case 3:
                                          {
                                             if (false == ((MapSpecificMsg*)p_MsgPtr)->m_allocatedFlag)
                                             {
                                                RetErrorV3(l_UserDlgId,UnexpectedData);
                                             }
                                             else
                                             {
                                                IMAP3_RestoreDataArg *l_rd = (IMAP3_RestoreDataArg*) (((MapSpecificMsg*) p_MsgPtr)->m_structBuffer);
                                                if(NULL == g_spdPtr)
                                                {
                                                   ELOG(0,0,"g_spdPTR is NULL .. profile Loading Failed returning SystemFailure");
                                                   RetErrorV3(l_UserDlgId,SystemFailure);
                                                   return false;
                                                }
                                                DLOG(0,0,"Reveived Restore Data version 3 Message");
                                                l_Version = 3;
                                                if(true == CheckParametersRSDV3(l_UserDlgId,l_rd))
                                                {
                                                   DLOG(0,0,"Check parameters success, calling DB query to retrieve Subscriber profile");
                                                   l_state = m_rsd;
                                                   RetrieveData(l_UserDlgId,l_updv3.imsi,l_updv3.vlr);
                                                }
                                                else
                                                {
                                                   DLOG(0,0,"Check parameters fail, sending error and closing");
                                                   RetErrorV3(l_UserDlgId,UnexpectedData);
                                                }
                                             }
                                          }
                                          break;

                                       default:
                                          DLOG(0,0,"Unrecognizable version Restore Data received");
                                          break;
                                    }
                                 }
                                 break;

                              case MAP_OP_CODE_sendParameters: //9
                                 {
                                    TLOG(0,0,"Send Parameters request received");
                                    if (false == ((MapSpecificMsg*)p_MsgPtr)->m_allocatedFlag)
                                    {
                                       RetErrorV1(l_UserDlgId,UnexpectedData);
                                    }
                                    else
                                    {
                                       IMAP1_SendParametersArg *l_temp = (IMAP1_SendParametersArg*) (((MapSpecificMsg*) p_MsgPtr)->m_structBuffer);
                                       if(true == sp_CheckSendParametersV1(l_UserDlgId,l_temp))
                                       {
                                          LLOG(0,0,"Parameters are correct calling procedure to retreive data for received UPD");
                                          l_state= m_rsd;
                                          l_OpCode = MAP_OP_CODE_sendParameters;
                                          l_Version = 1;
                                          RetrieveData(l_UserDlgId,m_sp_imsi,m_SccpGt);
                                       }
                                       else
                                       {
                                          WLOG(0,0,"Parameters does not match, returning error and closing the transaction");
                                          RetErrorV1(l_UserDlgId,UnexpectedData);
                                       }
                                    }
                                 }
                                 break;

                              default:
                                 DLOG(0, 0, "Received Unknown Specific Message");
                                 break;
                           }
                           return true;
                        }
                        break;

                     case MAP_SPEC_EVENT_RESULT:
                        {
                           DLOG(0, 0, "MAP_SPEC_EVENT_RESULT received");
                        }
                        break;

                     case MAP_SPEC_EVENT_CONFIRMATION:
                        {
                           DLOG(0, 0, "MAP_SPEC_EVENT_CONFIRMATION received");
                           switch (((MapSpecificMsg*) p_MsgPtr)->m_OpCode)
                           {
                              case MAP_OP_CODE_activateTraceMode:
                                 {
                                    LLOG(0,0,"%d-TS:Received activate trace mode Resp",l_UserDlgId);
                                    switch(l_Version)
                                    {
                                       case 3:
                                          {
                                             UpdLocV3Cont(l_UserDlgId);
                                          }
                                          break;
                                       case 2:
                                          {
                                             UpdLocV2Cont(l_UserDlgId);
                                          }
                                          break;
                                       case 1:
                                          {
                                             UpdLocV1Cont(l_UserDlgId);
                                          }
                                          break;
                                       default :
                                          {
                                             ELOG(0,0,"Unknown Msg Version %d",l_Version);
                                             return false;
                                          }
                                    }
                                 }
                                 break;
                              case MAP_OP_CODE_insertSubscriberData://OpCode = 7
                                 {
                                    TLOG(0,0,"ISD Response Received ");
                                    switch(l_Version)
                                    {
                                       case 3:
                                          {
                                             LLOG(0,0,"The value returned by ISDData are ISD Index is %x, VLR CSI Index is %x, SGSN CSI Index is %x, SS Index is %x",index,VcsiIndex,ScsiIndex,SsIndex);
                                             if (true == ((MapSpecificMsg*)p_MsgPtr)->m_allocatedFlag)
                                             {
                                                IMAP3_InsertSubscriberDataRes *ISD_Res = (IMAP3_InsertSubscriberDataRes*) (((MapSpecificMsg*) p_MsgPtr)->m_structBuffer);
                                                if(true == m_isd.ProcessIsdResV3(l_UserDlgId,ISD_Res))
                                                {
                                                   DLOG(0,0,"Process ISD resp success");
                                                }
                                                else
                                                {
                                                   WLOG(0,0,"Process ISD resp fail, sending Roaming Not Allowed");
                                                   if(m_isd.m_Unsupp_ODB > 0)
                                                   {
                                                      LLOG(0,0,"ODB rejected value in ISD response logging in TDR [%d]",m_isd.m_Unsupp_ODB);
                                                      m_tdr.setInteger(TDR_INDEX_NOR_CONTEXT_ID,m_isd.m_Unsupp_ODB);
                                                   }
                                                   if(false == m_fIsd)
                                                   {
                                                      RetErrorV3(l_UserDlgId,RoamingNotAllowed_plmn);
                                                   }
                                                   m_tdr.setString(TDR_INDEX_RESRV3,"ODB_REJECTED_IN_ISD_RESP");
                                                   m_TrapReqd = false;
                                                   UpdateUpdFailData(l_UserDlgId);
                                                   return false;
                                                }
                                             }
                                             if(index == 0)
                                             {
                                                TLOG(0,0,"Processing ISD response success,no more ISD to send,calling Upd Loc Resp");
                                                UpdLocV3_Cont(l_UserDlgId);
                                             }
                                             else
                                             {
                                                TLOG(0,0,"Index value is %x continuing sending remaining ISD",index); 
                                                flag = false;
                                                MapSpecificRequest l_request(l_UserDlgId, MAP_OP_CODE_insertSubscriberData, MAP_V3);
                                                DECLARE(OMAP3_InsertSubscriberDataArg,l_isd,3,"OMAP3_InsertSubscriberDataArg",DeclareFunc);
                                                //DLOG(0,0,"Time for memset ISD V3 "); 
                                                if (true == m_isd.FormISDReqV3(l_UserDlgId,index,VcsiIndex,ScsiIndex,SsIndex,flag,m_isd.dbisd3,l_OpCode,l_isd))
                                                {
                                                   if(5 > g_AsnCodecO3.getEncodingLength(OMAP3_InsertSubscriberDataArg_PDU,l_isd))
                                                   {
                                                      if(m_isd.m_AllDataAdded == true)
                                                      {
                                                         LLOG(0,0,"no more ISD to send,calling Upd Loc Resp");
                                                         UpdLocV3_Cont(l_UserDlgId);
                                                         return true;
                                                      }
                                                      CLOG(0,0,"Formed ISD data of length less than 5 bytes, Sending System Failure");
                                                      WLOG(0,0,"Error: [%s]", g_AsnCodecO3.getErrMsg());
                                                      if(false == m_fIsd)
                                                      {
                                                         RetErrorV3(l_UserDlgId,SystemFailure);
                                                      }
                                                      m_TrapReqd = false;
                                                      UpdateUpdFailData(l_UserDlgId);
                                                   }
                                                   else
                                                   {
                                                      m_tdr.setInteger(TDR_INDEX_RESRV2,m_isd.m_MM_TDR_CSI_FLAGS);
                                                      SendMsgV3(l_UserDlgId,&l_request,l_isd,index,VcsiIndex,ScsiIndex,SsIndex);
                                                   }
                                                }
                                             }
                                          }
                                          break;
                                       case 2:
                                          {
                                             LLOG(0,0,"Index value here is %x,SS Data Index %x",index,SsIndex);
                                             if (true == ((MapSpecificMsg*)p_MsgPtr)->m_allocatedFlag)
                                             {
                                                IMAP2_InsertSubscriberDataRes *ISD_Res = (IMAP2_InsertSubscriberDataRes*) (((MapSpecificMsg*) p_MsgPtr)->m_structBuffer);
                                                if(true == m_isd.ProcessIsdResV2(l_UserDlgId,ISD_Res))
                                                {
                                                   DLOG(0,0,"Process ISD resp success");
                                                }
                                                else
                                                {
                                                   if(m_isd.m_Unsupp_ODB > 0)
                                                   {
                                                      LLOG(0,0,"ODB rejected value in ISD response logging in TDR [%d]",m_isd.m_Unsupp_ODB);
                                                      m_tdr.setInteger(TDR_INDEX_NOR_CONTEXT_ID,m_isd.m_Unsupp_ODB);
                                                   }
                                                   WLOG(0,0,"Process ISD resp fail, sending Roaming Not Allowed");
                                                   RetErrorV2(l_UserDlgId,RoamingNotAllowed_plmn);
                                                   m_tdr.setString(TDR_INDEX_RESRV3,"ODB_REJECTED_IN_ISD_RESP");
                                                   m_TrapReqd = false;
                                                   UpdateUpdFailData(l_UserDlgId);
                                                   return false;
                                                }
                                             }
                                             if(index == 0)
                                             {
                                                TLOG(0,0,"Processing ISD response success,no more ISD to send,calling Upd Loc Resp");
                                                UpdLocV2_Cont(l_UserDlgId);
                                             }
                                             else
                                             {
                                                TLOG(0,0,"Index value is %x continuing sending remaining ISD",index);
                                                //struct timeval tim;
                                                MapSpecificRequest l_request(l_UserDlgId, MAP_OP_CODE_insertSubscriberData, MAP_V2); 
                                                DECLARE(OMAP2_InsertSubscriberDataArg,l_isd,2,"OMAP2_InsertSubscriberDataArg",DeclareFunc);
                                                //DLOG(0,0,"Time for memset ISD V2  ");                                  

                                                if (true == m_isd.FormISDReqV2(l_UserDlgId,index,SsIndex,flag,m_isd.dbisd2,l_OpCode,l_isd))
                                                {
                                                   if(5 > g_AsnCodecO2.getEncodingLength(OMAP2_InsertSubscriberDataArg_PDU,l_isd))
                                                   {
                                                      if(m_isd.m_AllDataAdded == true)
                                                      {
                                                         LLOG(0,0,"no more ISD to send,calling Upd Loc Resp");
                                                         UpdLocV3_Cont(l_UserDlgId);
                                                         return true;
                                                      }
                                                      WLOG(0,0,"Formed ISD data of length less than 5 bytes, Neglecting it and continuing with remaining ISD");
                                                      RetErrorV2(l_UserDlgId,SystemFailure);
                                                      m_TrapReqd = false;
                                                      UpdateUpdFailData(l_UserDlgId);
                                                   }
                                                   else
                                                   {
                                                      SendMsgV2(l_UserDlgId,&l_request,l_isd,index,SsIndex);
                                                   }                                                   
                                                }
                                             }
                                          }
                                          break;
                                       case 1:
                                          {
                                             LLOG(0,0,"Index value here is %x,SS Index is %x",index,SsIndex);
                                             if(index == 0)
                                             {
                                                TLOG(0,0,"Processing ISD response success,no more ISD to send,calling Upd Loc Resp");
                                                UpdLocV1_Cont(l_UserDlgId);
                                             }
                                             else
                                             {
                                                TLOG(0,0,"Index value is %x continuing sending remaining ISD",index);                                                   
                                                flag = false;

                                                MapSpecificRequest l_request(l_UserDlgId, MAP_OP_CODE_insertSubscriberData, MAP_V1);
                                                DECLARE(OMAP1_InsertSubscriberDataArg,l_isd,1,"OMAP1_InsertSubscriberDataArg",DeclareFunc);
                                                //DLOG(0,0,"Time for memset ISD V1 ");

                                                m_isd.FormISDReqV1(l_UserDlgId,index,SsIndex,flag,m_isd.dbisd1,l_OpCode,l_isd);
                                                if(5 > g_AsnCodecO1.getEncodingLength(OMAP1_InsertSubscriberDataArg_PDU,l_isd))
                                                {
                                                   if(m_isd.m_AllDataAdded == true)
                                                   {
                                                      LLOG(0,0,"no more ISD to send,calling Upd Loc Resp");
                                                      UpdLocV3_Cont(l_UserDlgId);
                                                      return true;
                                                   }
                                                   WLOG(0,0,"Formed ISD data of length less than 5 bytes, Neglecting it and continuing with remaining ISD");
                                                   RetErrorV1(l_UserDlgId,SystemFailure);
                                                   m_TrapReqd = false;
                                                   UpdateUpdFailData(l_UserDlgId);
                                                }
                                                else
                                                {
                                                   SendMsgV1(l_UserDlgId,&l_request,l_isd,index,SsIndex);
                                                }                                                      
                                             }
                                          }
                                          break;
                                       default:
                                          {
                                             CLOG(0,0,"ISD Acknowledge with unknown version of msg received in Update Location");                                             
                                          }
                                          break;
                                    }
                                 }
                                 break;                                
                              default:
                                 DLOG(0,0,"Unrecognised MAP_SPEC_EVENT_CONFIRMATION received");
                                 break;
                           }
                        }
                        break;

                     case MAP_SPEC_EVENT_USER_ERROR:
                        {
                           unsigned short l_errCode = ((MapUserError*)p_MsgPtr)->m_ErrorCode;
                           WLOG(0, 0, "MAP_SPEC_EVENT_USER_ERROR received, Error code %d ",l_errCode);
                           m_tdr.setInteger(TDR_INDEX_ERR_CODE,l_errCode);
                           CloseReq(l_UserDlgId);
                           if(l_state == m_atm)
                           {
                              m_TraceErrorCode = l_errCode;
                           }
                           m_TrapReqd = true;
                           l_state = m_usdf;
                           UpdateUpdFailData(l_UserDlgId);
                        }
                        break;

                     case MAP_SPEC_EVENT_PROV_ERROR:
                        {
                           WLOG(0, 0, "MAP_SPEC_EVENT_PROV_ERROR received");
                           m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_PROVIDER_ERROR_RCVD);
                           if(l_state == m_atm)
                           {
                              m_TraceErrorCode = 104;
                           }
                           m_TrapReqd = true;
                           m_ProvErrRcvd = true;
                           l_state = m_usdf;
                           m_TrapReqd = true;
                           UpdateUpdFailData(l_UserDlgId);
                        }
                        break;
                     default:
                        CLOG(0, 0, "ERROR!! Default received");
                        break;
                  }
               }
               break;

            default:
               break;
         }
         break;

      case MSG_TYPE_DB:
         {
            DLOG(0,0,"DB message received on the call state %d",(m_callState)l_state);
            switch(l_state)
            {
               case m_rsd:
                  {
                     DLOG(0,0,"Received DB response on Retrieve subscriber Profile Data");
                     RetrieveSubsVLRData *l_rsd = (RetrieveSubsVLRData*) p_MsgPtr;
                     l_UserDlgId = l_rsd->m_UserDlgId;
                     TLOG(0,0,"DB message received for Retrieve subscriber Profile Data, call state [%d] ErrorCode [%d] ",(m_callState)l_state,l_rsd->m_ErrorCode);
                     DLOG(0,0,"MAP_MSG_TYPE_DB received with DlgId %d",l_UserDlgId);
                     memset(l_hlrAddr,'\0',sizeof(l_hlrAddr));
                     strncpy((char *)l_hlrAddr,(char *)l_rsd->m_HlrADDR,strlen((char *)l_rsd->m_HlrADDR));
                     char l_tmp[200+1];
                     snprintf(l_tmp,sizeof(l_tmp),"%s|%d",l_rsd->m_TdrData,l_rsd->m_Non_Camel_Action);//m_Cap_Action[l_rsd->m_Non_Camel_Action]);
                     m_tdr.setString(TDR_INDEX_RESRV1,(char *)l_tmp);
                     m_Cap_Failure_Action = l_rsd->m_Non_Camel_Action;
                     LLOG(0,0,"DBRES: VLR Prefix|VLR Template [%s] .. Non Camel Vlr Action [%d] [%s]",l_rsd->m_TdrData,m_Cap_Failure_Action,m_Cap_Action[m_Cap_Failure_Action]);
                     g_EmergencyFlag = g_spdPtr->m_MsisdnPrefReplaceStruct.m_CongestionEmergencyFlag;
                     LLOG(0,0,"DBRES: EmergencyFlag[%d]",g_EmergencyFlag);
                     m_tdr.setInteger(TDR_INDEX_NOR_VISITED_NET_ID,g_EmergencyFlag);

                     LLOG(0,0,"DBRES: Template FTN Info [%s]",l_rsd->m_TemplateFtnInfo_OUT);
                     m_tdr.setString(TDR_INDEX_AUC_NUM_VECTORS_SENT,l_rsd->m_TemplateFtnInfo_OUT);
                     
                     /************************************************************************************************************/
                     LLOG(0,0,"DBRES:  Allocate Imsi API [%s]",l_rsd->m_AllocImsiApi_OUT);
                     m_tdr.setString(TDR_INDEX_RESRV4,l_rsd->m_AllocImsiApi_OUT);

                     LLOG(0,0,"DBRES:  Allow Restore Data [%s]",l_rsd->m_AllowRestoreData_OUT);
                     m_tdr.setString(TDR_INDEX_SI_REQ_INFO,l_rsd->m_AllowRestoreData_OUT);

                     if((strlen(l_rsd->m_AllowRestoreData_OUT) > 3) && (('1' == l_rsd->m_AllowRestoreData_OUT[0]) && ('1' == l_rsd->m_AllowRestoreData_OUT[2])))
                     {
                        char l_tempData1[200+1];
                        memset(l_tempData1,'\0',sizeof(l_tempData1));
                        snprintf(l_tempData1, sizeof(l_tempData1), "|%s|", l_rsd->m_AllowRestoreData_OUT);
                        char tempBuff5[5][20];
                        memset(tempBuff5,'\0',sizeof(tempBuff5));
                        tokenize2(l_tempData1,(char*)tempBuff5,20,'|');
                        TLOG(0,1,"tokenized data: [%s] [%s] [%s] [%s] [%s]", tempBuff5[0], tempBuff5[1], tempBuff5[2], tempBuff5[3], tempBuff5[4]);

                        m_imsOcsiProfId = atoi(tempBuff5[3]);
                        TLOG(0,0,"IMS OCSI Profile ID [%d]",m_imsOcsiProfId);

                     }
                     else
                     {
                        TLOG(0,0,"IMS OCSI Profile ID not picked for Restore Data");
                     }

                     char l_tempData[200+1];
                     memset(l_tempData,'\0',sizeof(l_tempData));
                     snprintf(l_tempData, sizeof(l_tempData), "|%s|", l_rsd->m_AllocImsiApi_OUT);
                     char tempBuff1[5][20];
                     memset(tempBuff1,'\0',sizeof(tempBuff1));
                     tokenize2(l_tempData,(char*)tempBuff1,20,'|');
                     TLOG(0,1,"tokenized data: [%s] [%s] [%s] [%s] [%s]", tempBuff1[0], tempBuff1[1], tempBuff1[2], tempBuff1[3], tempBuff1[4]);
                     if(0 == strcmp("1",tempBuff1[1]))
                     {
                        DLOG(0,0,"Stats written ... Interested for Allocating AlternateImsi");
                        //moduleLevelLogStats("InterestedForAllocImsiAPICall", MODULE_STATS_EVENT_STATUS_TOTAL);
                        map<string,int>::iterator l_itr = g_globalMap.find("InterestedForAllocImsiAPICall");
                        if(l_itr != g_globalMap.end())
                        {
                           HLRStatisticsInitializer::logStatistics(l_itr->second);
                        }
                     }
                     else if(0 == strcmp("2",tempBuff1[1]))
                     {
                        DLOG(0,0,"Stats written ... InterestedForRoamingCampaignDph");
                        map<string,int>::iterator l_itr = g_globalMap.find("InterestedForRoamingCampaignDph");
                        if(l_itr != g_globalMap.end())
                        {
                           HLRStatisticsInitializer::logStatistics(l_itr->second);
                        }
                     }
                     /********************************************************************************************/
           //6.4.1.0 Start
		     LLOG(0,0,"DBRES: GSM Statistics Info[%s]",l_rsd->m_StatsInfo_OUT);
           if(strlen(l_rsd->m_StatsInfo_OUT) > 5)
           {
              m_tdr.setString(TDR_INDEX_NOR_ALERT_REASON,l_rsd->m_StatsInfo_OUT);//140

              vector<string> l_statsInfo;
              char* l_token = strtok(l_rsd->m_StatsInfo_OUT,"-");
              while(l_token != NULL)
              {
                 l_statsInfo.push_back(string(l_token));
                 l_token = strtok(NULL, "-");
              }
              vector<string>::iterator l_itr;
              for(l_itr = l_statsInfo.begin(); l_itr != l_statsInfo.end(); l_itr++)
              {
                 DLOG(0,0,"Trying to Log Statistics[%s]",(char*)(*l_itr).c_str());
                 if(((CommonData*)g_prov)->m_statsData.find(*l_itr) != ((CommonData*)g_prov)->m_statsData.end())
                 {
                    map<string,int>::iterator l_mapitr = g_globalMap.find((*l_itr).c_str());
                    if(l_mapitr != g_globalMap.end())
                    {
                       DLOG(0,0,"Logging Statistics[%s]",(char*)(l_mapitr->first).c_str());
                       HLRStatisticsInitializer::logStatistics(l_mapitr->second);
                    }

                 }
              }
           }
           //6.4.1.0 End

           /********************************************************/
           LLOG(0,0,"DBRES: MNO Provisioning Parameters[%s]",l_rsd->m_MnoProvisioningTdr_OUT);
           m_tdr.setString(TDR_INDEX_HLR_RESRV10,l_rsd->m_MnoProvisioningTdr_OUT);//106

           m_tdr.setInteger(TDR_INDEX_NOR_MIP6AI_HA_DEST_REALM,l_rsd->m_ul_mpg_indicator_OUT); //136 

		     char l_tempData2[200+1];
		     memset(l_tempData2,'\0',sizeof(l_tempData2));
		     snprintf(l_tempData2, sizeof(l_tempData2), "|%s|", l_rsd->m_MnoProvisioningTdr_OUT);
		     char tempBuff2[5][20];
		     memset(tempBuff2,'\0',sizeof(tempBuff2));
		     tokenize2(l_tempData2,(char*)tempBuff2,20,'|');
		     TLOG(0,1,"tokenized data: [%s] [%s] [%s] [%s] [%s]", tempBuff2[0], tempBuff2[1], tempBuff2[2], tempBuff2[3], tempBuff2[4]);
		     /*if((1 == atoi((char *)tempBuff2[1])) && (0 == atoi((char *)tempBuff2[3])))
		     {
			     LLOG(0,0,"Stats written ... Interested for MNO Provisioning");
			     map<string,int>::iterator l_itr = g_globalMap.find("InterestedForMnoProvisioning");
			     if(l_itr != g_globalMap.end())
			     {
				     HLRStatisticsInitializer::logStatistics(l_itr->second);
			     }
		     }*/

		     if( (0 < strlen((char*)tempBuff2[4])) && (1 == atoi(tempBuff2[1])) && (0 == atoi(tempBuff2[3])) )
		     {
              LLOG(0,0,"MnoProvisioning Interested to be sent to MPG");
              m_tdr.setString(TDR_INDEX_ULR_RAT_TYPE,"1");//122

              char l_tempData3[200+1];
              memset(l_tempData3,'\0',sizeof(l_tempData3));
              snprintf(l_tempData3, sizeof(l_tempData3), "|%s|", l_rsd->m_TdrProfData);
              char tempBuff3[5][20];
              memset(tempBuff3,'\0',sizeof(tempBuff3));
              tokenize2(l_tempData3,(char*)tempBuff3,20,'|');
              TLOG(0,1,"tokenized data: [%s] [%s] [%s] [%s] [%s]", tempBuff3[0], tempBuff3[1], tempBuff3[2], tempBuff3[3], tempBuff3[4]);
              m_tdr.setString(TDR_INDEX_ICC_ID,tempBuff3[4]);//103
           }
           else
           {
			     m_tdr.setString(TDR_INDEX_ULR_RAT_TYPE,"0");//122
		     }
		     /********************************************************/

		     //////////////////////////////////////////////////////////////////////////////////
		     LLOG(0,0,"DBRES: Count of OSS Triggers: [%d] .. TdrRestrData[%s]", l_rsd->m_ossTriggerDataCount_OUT, l_rsd->m_TdrRestrData);
                     LLOG(0,0,"DBRES: Cancel Location RowId Flag[%d]",l_rsd->m_crossClType_OUT);
                     m_tdr.setString(TDR_INDEX_HLR_RESRV1,(char *)l_rsd->m_TdrRestrData);
                     m_tdr.setInteger(TDR_INDEX_HLR_RESRV3,l_rsd->m_crossClType_OUT); // HLR 2.0.18.0_R1 
                     char l_currentOssData[5000 + 1];
                     char l_tokensOssData[10][5000 + 1];
                     for (int l_i=0; l_i<l_rsd->m_ossTriggerDataCount_OUT; l_i++)
                     {
                        memset(l_tokensOssData,'\0',sizeof(l_tokensOssData));
                        memset(l_currentOssData,'\0',sizeof(l_currentOssData));
                        sprintf(l_currentOssData,"|%s|",l_rsd->m_ossTriggerData_OUT[l_i]);
                        tokenize(l_currentOssData, (char*)l_tokensOssData, 5001);
                        TLOG(0,0,"RowId[%s] TransId[%s] Opcode[%d] TransXmlLen[%d]", l_tokensOssData[1],l_tokensOssData[2],atoi(l_tokensOssData[3]),strlen(l_tokensOssData[4]));
                        TLOG(0,0,"Current Data [%s]",l_currentOssData);

                        LLOG(0,0,"Cancel Location CROSS CL sending flag[%d]",l_rsd->m_crossClType_OUT);
                        if(1 == l_rsd->m_crossClType_OUT)
                        {
                           if(DIAM_COMM_CODE_S6A_S6D_CLR_CLA == atoi(l_tokensOssData[3]))
                           {
                              LLOG(0,0,"Initiating DIAM CL: RowId[%s] TransId[%s]",l_tokensOssData[1],l_tokensOssData[2]);
                              g_esc.initiateIndependentContext(this, DIAM_COMM_CODE_S6A_S6D_CLR_CLA, l_tokensOssData[4], INITIATION_TYPE_IMMEDIATE);
                           }
                           else if(MAP_OP_CODE_cancelLocation == atoi(l_tokensOssData[3]))
                           {
                              LLOG(0,0,"Initiating MAP CL: RowId[%s] TransId[%s]",l_tokensOssData[1],l_tokensOssData[2]);
                              g_sc.initiateIndependentContext(this, MAP_OP_CODE_cancelLocation, l_tokensOssData[4], INITIATION_TYPE_IMMEDIATE);
                           }
                        }
                        else
                        {
                           EMsgType l_msgType;
                           if(true == whetherToProcess(atoi(l_tokensOssData[3]),&l_msgType))
                           {
                              if(MSG_TYPE_DIAMETER == l_msgType)
                              {
                                 LLOG(0,0,"Initiating DIAM CL: RowId[%s] TransId[%s]",l_tokensOssData[1],l_tokensOssData[2]);
                                 g_esc.initiateIndependentContext(this, DIAM_COMM_CODE_S6A_S6D_CLR_CLA, l_tokensOssData[4], INITIATION_TYPE_IMMEDIATE);
                              }
                              else if(MSG_TYPE_MAP == l_msgType)
                              {
                                 LLOG(0,0,"Initiating MAP CL: RowId[%s] TransId[%s]",l_tokensOssData[1],l_tokensOssData[2]);
                                 g_sc.initiateIndependentContext(this, MAP_OP_CODE_cancelLocation, l_tokensOssData[4], INITIATION_TYPE_IMMEDIATE);
                              }
                           }
                           else
                           {
                              LLOG(0,0,"Not processing CL: RowId[%s] TransId[%s]",l_tokensOssData[1],l_tokensOssData[2]);
                              if(0 == l_i)
                                 m_tdr.setString(TDR_INDEX_ULR_ROWID_ONE,l_tokensOssData[1]);
                              else if(1 == l_i)
                                 m_tdr.setString(TDR_INDEX_ULR_ROWID_TWO,l_tokensOssData[1]);
                              else if(2 == l_i)
                                 m_tdr.setString(TDR_INDEX_ULR_ROWID_THREE,l_tokensOssData[1]);
                              else if(3 == l_i)
                                 m_tdr.setString(TDR_INDEX_ULR_ROWID_FOUR,l_tokensOssData[1]);
                           }
                        }
                     }
                     //////////////////////////////////////////////////////////////////////////////////

                     LLOG(0,0,"DBRES: General TDR Data[%s]", l_rsd->m_generalTDRdata);
                     LLOG(0,0,"DBRES: QSPA Error Messagee[%s]", l_rsd->m_qSpaErrMsg);
                     LLOG(1,1,"DBRES: DB LOG MESSAGE[%s]", l_rsd->m_log_message);
                     char l_tokensGenTdr[13][100 + 1];
                     memset(l_tokensGenTdr,'\0',sizeof(l_tokensGenTdr));
                     tokenize(l_rsd->m_generalTDRdata, (char*)l_tokensGenTdr, 101);
                     TLOG(1,1,"Tokenized General TDR Data 1[%s] 2[%s] 3[%s] 4[%s] 5[%s] 6[%s] 7[%s] 8[%s] 9[%s] 10[%s] 11[%s] 12[%s]",(char *)l_tokensGenTdr[1],(char *)l_tokensGenTdr[2],(char *)l_tokensGenTdr[3],(char *)l_tokensGenTdr[4],(char *)l_tokensGenTdr[5],(char *)l_tokensGenTdr[6],(char *)l_tokensGenTdr[7],(char *)l_tokensGenTdr[8],(char *)l_tokensGenTdr[9],(char *)l_tokensGenTdr[10],(char *)l_tokensGenTdr[11],(char *)l_tokensGenTdr[12]);
                     m_tdr.setString(TDR_INDEX_CURRENT_ROAMING_ZONE,(char *)l_tokensGenTdr[1]);  //143
                     m_tdr.setString(TDR_INDEX_CURRENT_ROAMING_AGE,(char *)l_tokensGenTdr[2]);   //144
                     m_tdr.setString(TDR_INDEX_PREVIOUS_ROAMING_ZONE,(char *)l_tokensGenTdr[3]); //145
                     m_tdr.setString(TDR_INDEX_PREVIOUS_ROAMING_AGE,(char *)l_tokensGenTdr[4]);  //146
                     m_tdr.setString(TDR_INDEX_RESRV_POS147,(char *)l_tokensGenTdr[5]); 
                     m_tdr.setString(TDR_INDEX_RESRV_POS148,(char *)l_tokensGenTdr[6]); 
                     m_tdr.setString(TDR_INDEX_RESRV_POS149,(char *)l_tokensGenTdr[7]); 
                     m_tdr.setString(TDR_INDEX_RESRV_POS150,(char *)l_tokensGenTdr[8]); 
                     m_tdr.setString(TDR_INDEX_RESRV_POS151,(char *)l_tokensGenTdr[9]); 
                     m_tdr.setString(TDR_INDEX_RESRV_POS152,(char *)l_tokensGenTdr[10]); 
                     m_tdr.setString(TDR_INDEX_RESRV_POS153,(char *)l_tokensGenTdr[11]); 
                     m_tdr.setString(TDR_INDEX_RESRV_POS154,(char *)l_tokensGenTdr[12]); 

                     m_tdr.setString(TDR_INDEX_HLR_RESRV5,(char *)l_rsd->m_IsrImsi); //4040 ISR imsi 
                     m_tdr.setString(TDR_INDEX_HLR_RESRV9,l_rsd->m_qSpaErrMsg); //4040 qspaErrMsg


                     m_tdr.setInteger(TDR_INDEX_MM_LOCAL_NUM_ALLOCATION_STATUS,l_rsd->m_localImsiSubscription); 
                     m_tdr.setString(TDR_INDEX_RESRV3,(char *)l_rsd->m_roamCC); 
                     m_tdr.setInteger(TDR_INDEX_PARTNER_TYPE,l_rsd->m_partType); 
                     m_tdr.setString(TDR_INDEX_RESRV7,(char *)l_rsd->m_localRoamInfo);
                     m_tdr.setString(TDR_INDEX_RESRV8,(char *)l_rsd->m_tdrResrvData);
                     m_tdr.setString(TDR_INDEX_HLR_RESRV2,(char *)l_rsd->m_TdrProfData);
                     m_tdr.setString(TDR_INDEX_NOR_MIP6AI_HA_FAMILY2,(char *)l_rsd->m_DualImsiInfo_OUT);  //6.4.4.0
                     TLOG(0,0,"freeCount[%d] thresholdCount[%d]",l_rsd->m_freeCount,l_rsd->m_threshCount);
                     DLOG(0,0,"Dual Imsi Info [%s] Alt/DualImsi flag [%c] Dual Imsi Indicator [%c]",l_rsd->m_DualImsiInfo_OUT,l_rsd->m_DualImsiInfo_OUT[0],l_rsd->m_DualImsiInfo_OUT[2]);

                     if((atoi((char*)l_rsd->m_tdrResrvData) == 1) && (l_rsd->m_partType == 3))
                     {
                        LLOG(0,0,"Stats written ... Subscriber latched with Alternate IMSI first time");
                        map<string,int>::iterator l_itr = g_globalMap.find("FirstAlternateIMSILatched");
                        if(l_itr != g_globalMap.end())
                        {
                           HLRStatisticsInitializer::logStatistics(l_itr->second);
                        }
                     }
                     
                     if((atoi((char*)l_rsd->m_tdrResrvData) == 1) && (l_rsd->m_partType == 2) && ('2' == l_rsd->m_DualImsiInfo_OUT[0]) && ('1' == l_rsd->m_DualImsiInfo_OUT[2]))
                     {
                        LLOG(0,0,"Stats written ... Subscriber latched with Dual IMSI first time");
                        map<string,int>::iterator l_itr = g_globalMap.find("FirstDualIMSILatched");
                        if(l_itr != g_globalMap.end())
                        {
                           HLRStatisticsInitializer::logStatistics(l_itr->second);
                        }
                     }
                     
                     char l_tempData4[200+1];
                     memset(l_tempData4,'\0',sizeof(l_tempData4));
                     snprintf(l_tempData4, sizeof(l_tempData4), "|%s|", l_rsd->m_DualImsiInfo_OUT);
                     char tempBuff4[5][20];
                     memset(tempBuff4,'\0',sizeof(tempBuff4));
                     tokenize2(l_tempData4,(char*)tempBuff4,20,'|');
                     TLOG(0,1,"tokenized data: [%s] [%s] [%s] [%s] [%s]", tempBuff4[0], tempBuff4[1], tempBuff4[2], tempBuff4[3], tempBuff4[4]);

		     char l_tempDataRoamOta1[200+1];
		     memset(l_tempDataRoamOta1,'\0',sizeof(l_tempDataRoamOta1));
		     snprintf(l_tempDataRoamOta1, sizeof(l_tempDataRoamOta1), "|%s|", l_rsd->m_AltFlagCampaignId);
		     char tempBuffRoamOta1[5][20];
		     memset(tempBuffRoamOta1,'\0',sizeof(tempBuffRoamOta1));
		     tokenize2(l_tempDataRoamOta1,(char*)tempBuffRoamOta1,20,'|');
		     TLOG(0,1,"tokenized data: [%s] [%s] [%s] [%s] [%s]", tempBuffRoamOta1[0], tempBuffRoamOta1[1], tempBuffRoamOta1[2], tempBuffRoamOta1[3], tempBuffRoamOta1[4]);

                     if((2 == atoi(tempBuff4[1])) && (1 == atoi(tempBuffRoamOta1[1])))
                     {
                        TrafficParams l_traf_in,l_traf_out;
                        l_traf_in.m_maxTPS = atoi(tempBuff4[3]); 
			DLOG(0,0,"DUAL IMSI OTA DPH configured in networks is [%d]", atoi(tempBuff4[3]));
			string l_service;
			l_service = "DIDPH";
                        string l_tdrString = "TPS|";
			bool l_dualImsiOTA = false;
			int l_SecondsToBeWaited = 0;

			if(0 != atoi(tempBuff4[3]))
			{
		           if(false == g_daf->getTrafficParameters(l_service, l_traf_in, l_traf_out))
			   {
			      DLOG(0,0,"getTrafficParameters returns false, making g_tp_out as NG MAX TPS ");
			      l_traf_out.m_maxTPS = atoi(tempBuff4[3]);
			   }
			   else
			   {
			      DLOG(0,0,"getTrafficParameters returns true for SS7, DAF TPS is %d",l_traf_out.m_maxTPS);
			   }
			   l_SecondsToBeWaited = 3600/l_traf_out.m_maxTPS;
			}

			g_CurrTimeExecuted=time(NULL);
			DLOG(0,0,"Seconds To Be Waited to get interested for DUAL IMSI OTA[%d] CurrTime[%d] LastSentTime[%d]",l_SecondsToBeWaited, g_CurrTimeExecuted,g_LastTimerExecuted); 
			if(0 != l_SecondsToBeWaited)
		        {
		           if(g_CurrTimeExecuted >= g_LastTimerExecuted + l_SecondsToBeWaited)
			   {
			      g_LastTimerExecuted = g_CurrTimeExecuted;
			      l_dualImsiOTA = true;
			   }
			   else
			   {
			      LLOG(0,0,"Not Interested for DUAL IMSI OTA Trigger DPH control time not exceeded");		
                              l_tdrString += 'F';
			      m_tdr.setString(TDR_INDEX_GGSN_ADDRESS,(char*)l_tdrString.c_str());
			   }
			}
			else
		        {
	                   LLOG(0,0,"DPH not Configured for Dual IMSI OTA ....");
			   l_tdrString += "NC";
			   m_tdr.setString(TDR_INDEX_GGSN_ADDRESS,(char*)l_tdrString.c_str());
			}
			if(false == l_dualImsiOTA)
			{
		           memset(l_rsd->m_AltFlagCampaignId,'\0',sizeof(l_rsd->m_AltFlagCampaignId));
			}
		     }
                     else
                     {
                        DLOG(0,0,"Not Interested for DUAL IMSI OTA DPH Trigger.");
                     }

		     char l_tempDataRoamOta[200+1];
		     memset(l_tempDataRoamOta,'\0',sizeof(l_tempDataRoamOta));
		     snprintf(l_tempDataRoamOta, sizeof(l_tempDataRoamOta), "|%s|", l_rsd->m_AltFlagCampaignId);
		     char tempBuffRoamOta[5][20];
		     memset(tempBuffRoamOta,'\0',sizeof(tempBuffRoamOta));
		     tokenize2(l_tempDataRoamOta,(char*)tempBuffRoamOta,20,'|');
		     TLOG(0,1,"tokenized data: [%s] [%s] [%s] [%s] [%s]", tempBuffRoamOta[0], tempBuffRoamOta[1], tempBuffRoamOta[2], tempBuffRoamOta[3], tempBuffRoamOta[4]);
		     if(2 == atoi((char *)tempBuffRoamOta[1]))
		     {
                        LLOG(0,0,"Stats written ... InterestedForRoamingCampaignOtaTrigger");
			map<string,int>::iterator l_itr = g_globalMap.find("InterestedForRoamingCampaignOtaTrigger");
			if(l_itr != g_globalMap.end())
			{
                           HLRStatisticsInitializer::logStatistics(l_itr->second);
			}
		     }
		     
		     m_tdr.setInteger(TDR_INDEX_SSM_NBR_USR,l_rsd->m_First_Roam_To_Home_Flag);
		     LLOG(0,0,"DBRES: First_Roam_To_Home_Flag [%d]",l_rsd->m_First_Roam_To_Home_Flag);
		     m_tdr.setInteger(TDR_INDEX_AUC_RESYNC_INFO,l_rsd->m_PrimaryIndicator_OUT);
		     LLOG(0,0,"DBRES: Primary Indicator [%d]",l_rsd->m_PrimaryIndicator_OUT);
		     m_tdr.setString(TDR_INDEX_SSM_DEF_PRIORITY,(char *)l_rsd->m_CC_Info); 
		     m_tdr.setString(TDR_INDEX_ALTFLAG_CAMPID,(char *)l_rsd->m_AltFlagCampaignId);
		     m_tdr.setString(TDR_INDEX_ALT_PRIMARYIMSI,(char *)l_rsd->m_AltImsi);
		     LLOG(0,0,"ALT_PRIM_IMSI [%s] ALT_PIMSI_FLAG_CAMP_ID[%s] AreaCode Based Alocation Info[%s] TrapCode[%s] TrapDesc[%s]", l_rsd->m_AltImsi, l_rsd->m_AltFlagCampaignId,l_rsd->m_AreaCodeBasedAllocInfo,l_rsd->m_TrapCode,l_rsd->m_TrapDesc);
		     if((strlen((char*)l_rsd->m_AltFlagCampaignId) > 0) && (strlen((char*)l_rsd->m_AltImsi) > 0))
		     {
                        char l_tempData[200+1];
			memset(l_tempData,'\0',sizeof(l_tempData));
			snprintf(l_tempData, sizeof(l_tempData), "|%s|", l_rsd->m_AltFlagCampaignId);
			char tempBuff1[5][20];
			memset(tempBuff1,'\0',sizeof(tempBuff1));
			tokenize2(l_tempData,(char*)tempBuff1,20,'|');
			TLOG(0,1,"tokenized data: [%s] [%s] [%s]", tempBuff1[0], tempBuff1[1], tempBuff1[2]);
			if(strlen(tempBuff1[2]) > 1)
			{
                           if(0 != atoi(tempBuff1[2]))
			   {
                              DLOG(0,0,"Stats written ... Interested for Alternate Imsi / Dual Imsi OTA trigger");
			      //moduleLevelLogStats("InterestedForAltImsiTrigger", MODULE_STATS_EVENT_STATUS_TOTAL);
			      map<string,int>::iterator l_itr = g_globalMap.find("InterestedForAltOrDualImsiTrigger");
			      if(l_itr != g_globalMap.end())
			      {
                                 HLRStatisticsInitializer::logStatistics(l_itr->second);
			      }
			   }
			}
		     }

                     m_tdr.setString(TDR_INDEX_NEW_RESERVED_SEVEN,(char *)l_rsd->m_AreaCodeBasedAllocInfo);

                     if( strlen(l_rsd->m_qSpaErrMsg) > 1 )
                     {
                        if((0 != strcmp(l_rsd->m_qSpaErrMsg,"TRIG_DISABLED_NWK"))) 
                        {
                           if(NULL != strstr(l_rsd->m_qSpaErrMsg,"TRIG_TO_SEND"))
                           {
                              TLOG(0,0,"QSPA trigger to be sent success .. logging statistics");
                              map<string,int>::iterator l_itr = g_globalMap.find("TotalULsTriggerSentToSPA");
                              if(l_itr != g_globalMap.end())
                              {
                                 HLRStatisticsInitializer::logStatistics(l_itr->second);
                              }
                           }

                           TLOG(0,0,"QSPA logic triggered .. logging statistics");
                           map<string,int>::iterator l_itr = g_globalMap.find("TotalULsTriggerLogicExecuted");
                           if(l_itr != g_globalMap.end())
                           {
                              HLRStatisticsInitializer::logStatistics(l_itr->second);
                           }
                        }
                     }

                     char l_tempDesc[200+1];
                     snprintf(l_tempDesc, sizeof(l_tempDesc), "CC:%s NetID: %d", (char *)l_rsd->m_roamCC, l_rsd->m_nwid);
                     if(2 == l_rsd->m_localImsiSubscription)
                     {
                        LLOG(0,0,"DBRES: Unable to allocate Local Msisdn");
                        g_si.sendSnmpTrap(g_LocalMsisdnUnavailableTrap, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL, l_tempDesc);
                     }
                     else if(l_rsd->m_freeCount < l_rsd->m_threshCount)
                     {
                        LLOG(0,0,"DBRES: Threshold reached for Local Msisdn .. freeCount[%d] threshCount[%d]",l_rsd->m_freeCount,l_rsd->m_threshCount);
                        g_si.sendSnmpTrap(g_LocalMsisdnThresholdTrap, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL, l_tempDesc);
                     }

                     strncpy((char *)l_priMsisdn,(char *)l_rsd->m_PriMsisdn,strlen((char *)l_rsd->m_PriMsisdn));
                     m_tdr.setString(TDR_INDEX_MM_PRIMARY_MSISDN,(char *)l_priMsisdn);  
                     strncpy((char *)l_priImsi,(char *)l_rsd->m_PriImsi,strlen((char*)l_rsd->m_PriImsi));
                     m_tdr.setString(TDR_INDEX_MM_PRIMARY_IMSI,(char *)l_priImsi); 

                     m_tdr.setString(TDR_INDEX_MM_LOCAL_IMSI,(char *)l_rsd->m_LocalImsi); 
                     m_tdr.setString(TDR_INDEX_MM_LOCAL_MSISDN,(char *)l_rsd->m_LocalMsisdn); 
                     m_tdr.setInteger(TDR_INDEX_MM_IMSI_BURNT_TYPE,l_rsd->m_ImsiPreBurnt); 
                     m_tdr.setString(TDR_INDEX_RESRV6,(char *)l_rsd->m_SimStructure); 

                     if(l_rsd->m_ErrorCode != 0)
                     {
                        m_tdr.setInteger(TDR_INDEX_DB_ERR_CODE,l_rsd->m_ErrorCode); 
                        m_tdr.setString(TDR_INDEX_DB_ERR_DESC,(char *)l_rsd->m_ErrorMsg);
                     }
                     if(l_rsd->m_FirstUL == 1)
                     {
                        m_tdr.setInteger(TDR_INDEX_MM_FIRST_UL,l_rsd->m_FirstUL); 
                        m_FirstUlFlag = 1; // Added in 1.0.8.0
                     }
                     m_tdr.setInteger(TDR_INDEX_HLR_RESRV4,l_rsd->m_gsmFul); // Added HLR 2.0.19.0_R1 for ussd
                     
                     DLOG(0,0,"outside the check of m_gsmFul");
                     if(1 == l_rsd->m_gsmFul)
                     {
                        LLOG(0,0,"GSM First Update Location Set");

                        map<int, HlrNetworks* > :: iterator l_HlrNetworksDetailsIter;
                        l_HlrNetworksDetailsIter = g_spdPtr->m_HlrNetworks.find(l_rsd->m_nwid);

                        if(l_HlrNetworksDetailsIter != g_spdPtr->m_HlrNetworks.end())
                        {
                           if(1 == (l_HlrNetworksDetailsIter->second)->m_NotifyCellId)
                           {
                              LLOG(0,0,"GSM First Update Location Set .. Initiating PSI to Notify Cell ID");
                              char l_NotifyCellIdXml[1000];
                              snprintf(l_NotifyCellIdXml,sizeof(l_NotifyCellIdXml),"<REQUEST_TYPE>MMUPD_NOTIFY_CELLID</REQUEST_TYPE><RESPONSE><ACTIVE_HLR_ADDRESS>%s</ACTIVE_HLR_ADDRESS><ACTIVE_IMSI>%s</ACTIVE_IMSI><ACTIVE_MSISDN>%s</ACTIVE_MSISDN><VLR>%s</VLR><NETWORK_ID>%d</NETWORK_ID><TDR_PROF_DATA>%s</TDR_PROF_DATA><NOTIFY_CELLID_FLAG>%d</NOTIFY_CELLID_FLAG><PRIMARY_IMSI>%s</PRIMARY_IMSI><PRIMARY_MSISDN>%s</PRIMARY_MSISDN></RESPONSE>",(char *)l_rsd->m_HlrADDR,(char *)m_activeImsi,(char *)l_actMsisdn,(char *)l_rsd->m_vlr,l_rsd->m_nwid,(char *)l_rsd->m_TdrProfData,1,(char *)l_priImsi,(char *)l_priMsisdn);
                              DLOG(0,0,"UL l_NotifyCellIdXml: %s",l_NotifyCellIdXml);
                              //m_tdr.setString(TDR_INDEX_OAM_REQUEST_TYPE, "MMUPD_NOTIFY_CELLID");
                              g_sc.initiateIndependentContext(this,(EMapOpCode)70,(char *)l_NotifyCellIdXml, INITIATION_TYPE_IMMEDIATE);
                           }
                        }
                        else
                        {
                           LLOG(0,0,"Network id not found in map");
                        }
                     }

                     m_tdr.setInteger(TDR_INDEX_MM_NETWORK_ID,l_rsd->m_nwid); 
                     m_tdr.setInteger(TDR_INDEX_MM_PARTNER_NW_ID,l_rsd->m_pnwid); 
                     DLOG(0,0,"MSISDN Alloc Stat [%d] Old_Msisdn [%s] Remaining Msisdn [%d]",l_rsd->m_MsisdnAllcatedStatus,l_rsd->m_OldMsisdn,l_rsd->m_RemainingMsisnd);

                     // 1.0.13.2 Begin
                     if( l_rsd->m_MsisdnAllcatedStatus >= 10 )
                     {
                        m_tdr.setInteger(TDR_INDEX_RESRV5,l_rsd->m_MsisdnAllcatedStatus); 
                        LLOG(0,0,"DBRES: Transient MSISDN allocation status [%d]",l_rsd->m_MsisdnAllcatedStatus);

                        if( (14 == l_rsd->m_MsisdnAllcatedStatus ) || (11 == l_rsd->m_MsisdnAllcatedStatus ) )
                        {
                           LLOG(0,0,"Unable to allocate Trasient Msisdn");
                           g_si.sendSnmpTrap(g_TransientMsisdnUnavailableTrap, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL);
                        }
                        // 1.0.16.0 Begin
                        else if(l_rsd->m_transFreeCount < l_rsd->m_transThreshCount)
                        {
                           LLOG(0,0,"Threshold reached for Transient Msisdn .. freeCount[%d] threshCount[%d]",l_rsd->m_transFreeCount, l_rsd->m_transThreshCount);
                           g_si.sendSnmpTrap(g_TransientMsisdnThresholdTrap, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL);
                        }
                        // 1.0.16.0 End
                     }
                     // 1.0.13.2 End

                     if((l_rsd->m_ErrorCode == 0) || (l_rsd->m_ErrorCode == 12) || (l_rsd->m_ErrorCode == 13))
                     {
                        if((l_rsd->m_MsisdnAllcatedStatus == 0) || (l_rsd->m_MsisdnAllcatedStatus == 1))
                        {
                           if(l_rsd->m_MsisdnAllcatedStatus == 0)
                           {
                              LLOG(0,0,"Dynamic MSISDN allocation successful");
                              m_tdr.setString(TDR_INDEX_MM_MSISDN_ALLOC_STATUS,"A");
                              moduleLevelLogStats("PrimMSISDNAllocatedinUL");
                              m_MsisdnAllocStatus = 1; // Added in 1.0.8.0
                           }
                           if(l_rsd->m_MsisdnAllcatedStatus == 1)
                           {
                              CLOG(0,0,"Dynamic MSISDN allocation Failed");
                              m_tdr.setString(TDR_INDEX_MM_MSISDN_ALLOC_STATUS,"N");
                           }
                           m_tdr.setString(TDR_INDEX_OAM_FREE_FORMAT_DATA,(char *)l_rsd->m_OldMsisdn); 
                           snprintf(m_UploadedMsisdn,sizeof(m_UploadedMsisdn),"%s",(char *)l_rsd->m_OldMsisdn);
                           DLOG(0,0,"Configured Network Threshold [%d]",l_rsd->m_DynMsisdnMinFreeThreshold);
                           if(l_rsd->m_RemainingMsisnd < l_rsd->m_DynMsisdnMinFreeThreshold)
                           {
                              CLOG(0,0,"Remaining FREE MSISDN count in pool [%d] is less than configured network threshold [%d]",l_rsd->m_RemainingMsisnd,l_rsd->m_DynMsisdnMinFreeThreshold);
                              g_si.sendSnmpTrap(g_FreeMsisdnRemainingTrap, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL);
                           }
                        }
                     }
                     else if(2 == l_rsd->m_ErrorCode)
                     {
                        if(NULL == strstr((char*)(l_rsd->m_ErrorMsg),"GET_"))
                        {
                           CLOG(0,0,"Dynamic Allocation Failed");
                           g_si.sendSnmpTrap(g_DynamicAllocFailTrap, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL);
                        }
                     }
                     if(strlen((char *)l_hlrAddr) > 1)
                     {
                        sendMapOpenResponse(l_UserDlgId,(char *)l_hlrAddr,g_ConfigData->i_NgConfigData.m_selfAddress.ssn);
                     }

                     char tempBuff[5][100];
                     char l_AreaCodeBuf[100+1];
                     memset(tempBuff,'\0',sizeof(tempBuff));
                     memset(l_AreaCodeBuf,'\0',sizeof(l_AreaCodeBuf));
                     snprintf(l_AreaCodeBuf,sizeof(l_AreaCodeBuf),"|%s|",l_rsd->m_AreaCodeBasedAllocInfo);
                     DLOG(0,0,"AreaCodeBuf[%s] before tokenizing",l_AreaCodeBuf);
                     tokenize2(l_AreaCodeBuf,(char*)tempBuff,100,'|');
                     TLOG(0,0,"tokenised data: [%s] [%s] [%s] [%s] [%s]", tempBuff[1], tempBuff[2], tempBuff[3], tempBuff[4], tempBuff[5]);

                     if(strlen(l_rsd->m_TrapCode) > 0)
                     {
                        TLOG(0,0,"Trap Code is [%s]", l_rsd->m_TrapCode);
                        if(NULL != g_prov)
                        {
                           int l_trapInt = ((CommonData*)g_prov)->getTrapInt(l_rsd->m_TrapCode);
                           DLOG(0,0,"TRAP ID[%d]",l_trapInt);
                           if(l_trapInt >= 0)
                           {
                              if(strlen(l_rsd->m_TrapDesc)> 0)
                              {
                                 char l_tempDesc1[200+1];
                                 snprintf(l_tempDesc1, sizeof(l_tempDesc1), "AreaShortCode:%s BusinessGroupID:%s", tempBuff[2],tempBuff[5]);
                                 g_si.sendSnmpTrap(l_trapInt, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL, l_tempDesc1);
                              }
                              else
                              {
                                 g_si.sendSnmpTrap(l_trapInt, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL);
                              }
                           }
                           else
                           {
                              ELOG(0,0,"Unable to get the integer for the trap [%s]", l_rsd->m_TrapCode);
                           }
                        }
                        else
                        {
                           WLOG(0,0,"g_prov is null. not sending trap");
                        }
                     }

                     if((1 == m_MsisdnAllocStatus) && (0 == strcmp("2", tempBuff[1])))
                     {
                        DLOG(0,0,"checking for logging AreaCode Based stats");
                        char l_TmpAreaShortCode[100+1];
                        memset(l_TmpAreaShortCode,'\0',sizeof(l_TmpAreaShortCode));
                        snprintf(l_TmpAreaShortCode,sizeof(l_TmpAreaShortCode),"TotalMsisdnAllocationsInAreaCode:%s",tempBuff[2]);
                        TLOG(0,0,"AreaCode[%s] Based MSISDN Allocated .. logging statistics",tempBuff[2]);
                        map<string,int>::iterator l_itr = g_globalMap.find(l_TmpAreaShortCode);
                        if(l_itr != g_globalMap.end())
                        {
                           HLRStatisticsInitializer::logStatistics(l_itr->second);
                        }
                        else
                        {
                           TLOG(0,0,"%s not found in global map, not calling statistics",l_TmpAreaShortCode);
                        }
                     }
                     else
                     {
                        TLOG(0,0,"Msisdn Alloc Status[%d] and AreaCode Flag Value[%s] not checking for statistics",m_MsisdnAllocStatus,tempBuff[1]);
                     }

                     //
                     // Added in 1.0.8.0
                     strcpy((char*)m_GSM_Seq_id,(char *)l_rsd->m_GSM_Seq_id);
                     LLOG(0,0,"DBRES: GSM Update location Sequence ID [%s] .. FUL-IND[%d]",m_GSM_Seq_id,m_FirstUlFlag);
                     m_tdr.setString(TDR_INDEX_OAM_TRANSACTION_ID,(char *)m_GSM_Seq_id);
                     //
                     //
                     LLOG(0,0,"##### SUBS_DATA pipes[%s] ####",(char *) l_rsd->m_GsmINFO);
                     char GsmPro[300];
                     memset(GsmPro, '\0', sizeof(GsmPro));
                     strncpy(GsmPro, "|", 1);
                     strncat(GsmPro, (char *) l_rsd->m_GsmINFO, strlen((char *) l_rsd->m_GsmINFO));
                     strncat(GsmPro, "|", 1);
                     //DLOG(0,0,"The string tested is %s\n",GsmPro);
                     tokenize(GsmPro, (char*)m_SubsData, 33);

                     strncpy((char *) GsmProfile.l_ActMsisdn, m_SubsData[1], strlen(m_SubsData[1]));
                     strncpy((char *) GsmProfile.l_Actimsi, m_SubsData[2], strlen(m_SubsData[2]));
                     strncpy((char *) GsmProfile.l_lmsino, m_SubsData[3], strlen(m_SubsData[3]));
                     strncpy((char *) GsmProfile.l_vlrno, m_SubsData[4], strlen(m_SubsData[4]));
                     strncpy((char *) GsmProfile.l_Mscno, m_SubsData[5], strlen(m_SubsData[5]));
                     GsmProfile.l_mscRest = atoi(m_SubsData[6]);
                     GsmProfile.l_ssInd = atoi(m_SubsData[7]);
                     GsmProfile.l_msPur_gsm = atoi(m_SubsData[8]);
                     GsmProfile.l_mnrr = atoi(m_SubsData[9]);
                     GsmProfile.l_mnrf = atoi(m_SubsData[10]);
                     GsmProfile.l_mcef = atoi(m_SubsData[11]);
                     GsmProfile.l_roamrestduf = atoi(m_SubsData[12]);
                     strncpy((char *) GsmProfile.l_ActHLRAddr, m_SubsData[13],strlen(m_SubsData[13]));
                     GsmProfile.l_ActPnwId = atoi(m_SubsData[14]);
                     GsmProfile.l_TraceFlag = atoi(m_SubsData[15]);
                     strncpy((char*)GsmProfile.l_TraceRef,m_SubsData[16],strlen(m_SubsData[16]));
                     strncpy((char *)GsmProfile.l_TraceType,m_SubsData[17],strlen(m_SubsData[17]));
                     strncpy((char *)GsmProfile.l_OmcId,m_SubsData[18],strlen(m_SubsData[18]));
                     GsmProfile.l_TraceStatus = atoi(m_SubsData[19]);
                     strncpy((char*)GsmProfile.l_imeisv,m_SubsData[20],strlen(m_SubsData[20]));
                     strncpy((char *) GsmProfile.l_sgsnNum, m_SubsData[21], strlen(m_SubsData[21])); //added in 1.0.14.0
                     // Added in 1.0.5.1
                     if((strcmp((char*)GsmProfile.l_imeisv,"0") != 0)) //&& (strcmp((char*)GsmProfile.l_imeisv,(char*)l_updv3.imeisv) != 0))
                     {
                        LLOG(0,0,"DBRES: Previous Imei [%s] and Current Imei [%s] ",GsmProfile.l_imeisv,l_updv3.imeisv);
                        //LLOG(0,0,"DBRES: Previous Imei [%s] and",GsmProfile.l_imeisv);
                        //LLOG_HEX(0,0,"DBRES: Current Imei ",(char*)l_updv3.imeisv,16);
                        // 4.0.2.0 say migration script going on and still previous imei is not encrypted

                        if( (1 == g_IMEI_EncrFlag) && (strlen((char*)(GsmProfile.l_imeisv)) < 18) ) 
                        {
                           LLOG(0,0,"IMEI enc flag enabled but DB previous Imei not in encrypted format.. so encrypting");
                           char l_tempIMEI[200];
                           memset(l_tempIMEI,'\0',sizeof(l_tempIMEI));
                           bool res = Copy_encryptedIMEI((char*)GsmProfile.l_imeisv,l_tempIMEI);
                           unsigned char l_rawImei[200];
                           memset(l_rawImei,'\0',sizeof(l_rawImei));
                           hexToStringWithoutSpace(l_rawImei, 200, (unsigned char*)l_tempIMEI, 16);
                           m_tdr.setString(TDR_INDEX_MM_PREVIOUS_IMEI,(char*)l_rawImei);
                           if(res == true)
                           {
                              memset((char*)GsmProfile.l_imeisv,'\0',strlen((char*)GsmProfile.l_imeisv));
                              strncpy((char*)GsmProfile.l_imeisv,(char*)l_rawImei,strlen((char*)l_rawImei));
                           }
                           else
                           {
                              CLOG(0,0,"Encryption of Imei Failed !!!!");
                           }
                        }
                        else
                        {
                           m_tdr.setString(TDR_INDEX_MM_PREVIOUS_IMEI,(char*)GsmProfile.l_imeisv);
                        }
                     }
#if 1//Send CL to old VLR
                     int l_check = 0;
                     if((l_OpCode == 57) || (l_OpCode == 9) ||  ((l_rsd->m_DbQueryRes != DB_QUERY_RES_SUCCESS) && ((l_rsd->m_ErrorCode == -200)||(l_rsd->m_ErrorCode == 2) || (l_rsd->m_ErrorCode == 1))))
                     {
                        DLOG(0,0,"Return code val [%d], Opcode [%d]",l_rsd->m_ErrorCode,l_OpCode);
                        if((strncmp((char *)GsmProfile.l_vlrno,"0",1)==0))
                        {
                           DLOG(0,0,"Existing VLR Addr is null");
                           m_SendATM = true;
                        }
                     }
                     else
                     {
                        if((strncmp((char *)GsmProfile.l_vlrno,"0",1)==0))
                        {
                           DLOG(0,0,"Existing VLR Addr is null");
                           m_SendATM = true;
                        }
                        else
                        {
                           m_tdr.setString(TDR_INDEX_MM_PREVIOUS_NODE,(s8*)GsmProfile.l_vlrno);
                           if(l_Version == 3)
                           {
                              l_check = strcmp((char *)GsmProfile.l_vlrno,(char *)l_updv3.vlr+2);
                              DLOG(0,0,"Rcvd VLR addr [%s] VLR addr in DB [%s] is Different [%d]",l_updv3.vlr+2,GsmProfile.l_vlrno,l_check);
                           }
                           else if(l_Version == 2)
                           {
                              l_check = strcmp((char *)GsmProfile.l_vlrno,(char *)l_updv2.vlr+2);
                              DLOG(0,0,"Rcvd VLR addr [%s] VLR addr in DB [%s] is Different [%d]",l_updv2.vlr+2,GsmProfile.l_vlrno,l_check);
                           }
                           else if(l_Version == 1)
                           {
                              l_check = strcmp((char *)GsmProfile.l_vlrno,(char *)l_updv1.vlr+2);
                              DLOG(0,0,"Rcvd VLR addr [%s] VLR addr in DB [%s] is Different [%d]",l_updv1.vlr+2,GsmProfile.l_vlrno,l_check);
                           }
                           else
                           {
                              CLOG(0,0,"Unknown version");
                              return false;
                           }
                        }
                     }

#endif                           
                     if(l_rsd->m_DbQueryRes == DB_QUERY_RES_SUCCESS)
                     {
                        memset(l_AccId,'\0',sizeof(l_AccId));
                        if(l_rsd->m_FirstUL == 1)
                           m_tdr.setInteger(TDR_INDEX_MM_FIRST_UL,l_rsd->m_FirstUL); 
                        m_tdr.setInteger(TDR_INDEX_MM_NETWORK_ID,l_rsd->m_nwid); 
                        m_tdr.setInteger(TDR_INDEX_MM_PARTNER_NW_ID,l_rsd->m_pnwid); 
                        if((l_rsd->m_MsisdnAllcatedStatus == 0) || (l_rsd->m_MsisdnAllcatedStatus == 1))
                        {
                           m_tdr.setString(TDR_INDEX_OAM_FREE_FORMAT_DATA,(char *)l_rsd->m_OldMsisdn); 
                        }
                        strncpy((char *)l_AccId,(char *)l_rsd->m_AccId,strlen((char *)l_rsd->m_AccId));
                        m_tdr.setString(TDR_INDEX_ACCOUNT_ID, (char *)l_rsd->m_AccId);
                        l_nwId = l_rsd->m_nwid;
                        int l_ProcessDbResp = 0; 
                        l_ProcessDbResp = processDBData(l_UserDlgId,l_rsd);
                        DLOG(0,0,"ProcessDB data returned %d",l_ProcessDbResp);
                        if(2 == l_ProcessDbResp && (false == m_fIsd))
                        {
                           WLOG(0,0,"Process db data returned false, returning Roaming not allowed");
                           switch(l_Version)
                           {
                              case 3:
                                 {
                                    if(l_OpCode == 2)
                                    {
                                       RetErrorV3(l_UserDlgId,RoamingNotAllowed_plmn);
                                    }
                                    else if(l_OpCode == 57)
                                    {
                                       RetErrorV3(l_UserDlgId,DataMissing);
                                    }
                                    else
                                    {
                                       return false;
                                    }
                                    m_TrapReqd = false;
                                    UpdateUpdFailData(l_UserDlgId);
                                 }
                                 break;
                              case 2:
                                 {
                                    if(l_OpCode == 2)
                                    {
                                       RetErrorV2(l_UserDlgId,RoamingNotAllowed_plmn);
                                    }
                                    else if(l_OpCode == 57)
                                    {
                                       RetErrorV3(l_UserDlgId,DataMissing);
                                    }
                                    else
                                    {
                                       return false;
                                    }                                    
                                    m_TrapReqd = false;
                                    UpdateUpdFailData(l_UserDlgId);
                                 }
                                 break;
                              case 1:
                                 {
                                    RetErrorV1(l_UserDlgId,RoamingNotAllowed_plmn);                                
                                    m_TrapReqd = false;
                                    UpdateUpdFailData(l_UserDlgId);
                                 }
                                 break; 
                              default:
                                 CLOG(0,0,"Unknown l_Version %d",l_Version);
                                 break;
                           }
                           return false;
                        }
                        else if(1 == l_ProcessDbResp && (false == m_fIsd))
                        {
                           WLOG(0,0,"Process db data returned false, returning SystemFailure");
                           switch(l_Version)
                           {
                              case 3:
                                 {
                                    RetErrorV3(l_UserDlgId,SystemFailure);
                                    m_TrapReqd = false;
                                    UpdateUpdFailData(l_UserDlgId);
                                 }
                                 break;
                              case 2:
                                 {
                                    RetErrorV2(l_UserDlgId,SystemFailure);                                    
                                    m_TrapReqd = false;
                                    UpdateUpdFailData(l_UserDlgId);
                                 }
                                 break;
                              case 1:
                                 {
                                    RetErrorV1(l_UserDlgId,SystemFailure);                                
                                    m_TrapReqd = false;
                                    UpdateUpdFailData(l_UserDlgId);
                                 }
                                 break; 
                              default:
                                 CLOG(0,0,"Unknown l_Version %d",l_Version);
                                 break;
                           }
                           return false;
                        }
                        else
                        {
                           DLOG(0,0,"Process DB data success");
                        }
                        m_tdr.setString(TDR_INDEX_LOCAL_ADDRESS,(char *)l_hlrAddr);
                        switch(l_Version)
                        {
                           case 3:
                              {
                                 int l_UpdV3Ret = UpdLocV3(l_UserDlgId);
                                 switch(l_UpdV3Ret)
                                 {
                                    case SEND_ATM:
                                       {
                                          if(true == m_fIsd)
                                             break;
                                          l_state = m_atm;
                                          MapSpecificRequest l_request(l_UserDlgId, MAP_OP_CODE_activateTraceMode, MAP_V3);
                                          DECLARE(OMAP3_ActivateTraceModeArg,l_atm,3,"OMAP3_ActivateTraceModeArg",DeclareFunc);
                                          fillAtmV3(l_UserDlgId,GsmProfile.l_TraceRef,GsmProfile.l_TraceType,GsmProfile.l_OmcId,l_atm);
                                          l_request.m_structBuffer = (void*) l_atm;
                                          g_sc.sendMsg(this, &l_request); //
                                          ContinueReq(l_UserDlgId);
                                          LLOG(0,0,"Sending ATM followed by cont, callstate here %d",(m_callState)l_state);   
                                       }
                                       break;
                                    case CAP_VALIDATION_FAILED:
                                       {
                                          m_tdr.setString(TDR_INDEX_RESRV2,"CAP Validation Failed");
                                          if(false == m_fIsd)
                                          {
                                             RetErrorV3(l_UserDlgId,RoamingNotAllowed_plmn);
                                          }
                                          UpdateUpdFailData(l_UserDlgId);
                                       }
                                       break;
                                    case UPDV3_SUCCESS:
                                       {
                                          TLOG(0,0,"UpdLocV3 success");
                                       }
                                       break;
                                    case CAP_PROFILE_NOT_FOUND:
                                       {
                                          m_tdr.setString(TDR_INDEX_RESRV2,"CAP_PROFILE_NOT_LOADED");
                                       }
                                    default:
                                       {
                                          if(false == m_fIsd)
                                          {
                                             RetErrorV3(l_UserDlgId,SystemFailure);
                                          }
                                          UpdateUpdFailData(l_UserDlgId);
                                       }
                                       break;
                                 }
                              }
                              break;

                           case 2:
                              {
                                 if(false == UpdLocV2(l_UserDlgId))
                                 {
                                    //RetErrorV2(l_UserDlgId,UnknownSubscriber);
                                    MapSpecificRequest l_request(l_UserDlgId, MAP_OP_CODE_activateTraceMode, MAP_V2);
                                    DECLARE(OMAP2_ActivateTraceModeArg,l_atm,2,"OMAP2_ActivateTraceModeArg",DeclareFunc);
                                    l_state = m_atm;
                                    fillAtmV2(l_UserDlgId,GsmProfile.l_TraceRef,GsmProfile.l_TraceType,GsmProfile.l_OmcId,l_atm);
                                    l_request.m_structBuffer = (void*) l_atm;
                                    g_sc.sendMsg(this, &l_request); //
                                    ContinueReq(l_UserDlgId);
                                 }
                              }
                              break;
                           case 1:
                              {
                                 if(l_OpCode == MAP_OP_CODE_sendParameters)
                                 {
                                    sp_SendParamResp(l_UserDlgId);
                                    TLOG(0,0,"Send Parameters response sent, returning");
                                    return true;
                                 }
                                 else
                                 {
                                    if(false == UpdLocV1(l_UserDlgId))
                                    {
                                       //RetErrorV1(l_UserDlgId,UnknownSubscriber);
                                       MapSpecificRequest l_request(l_UserDlgId, MAP_OP_CODE_activateTraceMode, MAP_V1);
                                       DECLARE(OMAP1_ActivateTraceModeArg,l_atm,1,"OMAP1_ActivateTraceModeArg",DeclareFunc);
                                       l_state = m_atm;
                                       fillAtmV1(l_UserDlgId,GsmProfile.l_TraceRef,GsmProfile.l_TraceType,GsmProfile.l_OmcId,l_atm);
                                       l_request.m_structBuffer = (void*) l_atm;
                                       g_sc.sendMsg(this, &l_request); //
                                       ContinueReq(l_UserDlgId);
                                    }

                                 }
                              }
                              break;

                           default:
                              DLOG(0,0,"Unknown DB version msg");
                              break;
                        }
                     }
                     else
                     {
                        WLOG(0,0,"DB response for Retrieve subscriber data Not success,sending error, Received Error Code from DB [%d],Error message [%s]",l_rsd->m_ErrorCode,l_rsd->m_ErrorMsg); 
                        if(true == m_fIsd)
                        {
                           LLOG(0,0,"DB Error for forced UPD .. ignoring");
                           break;
                        }
                        if(l_rsd->m_ErrorCode == 1)
                        {
                           LLOG(0,0,"Returning Unknown Subscriber");
                           switch(l_Version)
                           {
                              case 3:
                                 {
                                    RetErrorV3(l_UserDlgId,UnknownSubscriber);
                                 }
                                 break;
                              case 2:
                                 {
                                    RetErrorV2(l_UserDlgId,UnknownSubscriber);
                                 }
                                 break;
                              case 1:
                                 RetErrorV1(l_UserDlgId,UnknownSubscriber);
                                 break;
                              default:
                                 ELOG(0,0,"Unknown MAP version msg");
                                 break;
                           }
                        }
                        else if(l_rsd->m_ErrorCode == 8)
                        {  
                           if((l_OpCode == 57) || (l_OpCode == 9))
                           {
                              LLOG(0,0,"Returning Unknown Subscriber");
                              switch(l_Version)
                              {
                                 case 3:
                                    {
                                       RetErrorV3(l_UserDlgId,UnknownSubscriber);
                                    }
                                    break;
                                 case 2:
                                    {
                                       RetErrorV2(l_UserDlgId,UnknownSubscriber);
                                    }
                                    break;
                                 case 1:
                                    RetErrorV1(l_UserDlgId,UnknownSubscriber);
                                    break;
                                 default:
                                    ELOG(0,0,"Unknown MAP version msg");
                                    break;
                              }
                           }
                           else
                           {
                              WLOG(0,0,"Error Msg received %s",l_rsd->m_ErrorMsg);
                              {
                                 switch(l_Version)
                                 {
                                    case 3:
                                       {
                                          RetErrorV3(l_UserDlgId,RoamingNotAllowed_plmn);
                                       }
                                       break;
                                    case 2:
                                       {
                                          RetErrorV2(l_UserDlgId,RoamingNotAllowed_plmn);                                    
                                       }
                                       break;
                                    case 1:
                                       {
                                          RetErrorV1(l_UserDlgId,RoamingNotAllowed_plmn);                                
                                       }
                                       break;
                                    default:
                                       CLOG(0,0,"Unknown l_Version %d",l_Version);
                                       break;
                                 }
                              }
                           }
                        }
                        else if(l_rsd->m_ErrorCode == 9)
                        {
                           if((l_OpCode == 57) || (l_OpCode == 9))
                           {
                              LLOG(0,0,"Returning Unknown Subscriber");
                              switch(l_Version)
                              {
                                 case 3:
                                    {
                                       RetErrorV3(l_UserDlgId,UnknownSubscriber);
                                    }
                                    break;
                                 case 2:
                                    {
                                       RetErrorV2(l_UserDlgId,UnknownSubscriber);
                                    }
                                    break;
                                 case 1:
                                    RetErrorV1(l_UserDlgId,UnknownSubscriber);
                                    break;
                                 default:
                                    ELOG(0,0,"Unknown MAP version msg");
                                    break;
                              }
                           }
                           else
                           {
                              switch(l_Version)
                              {
                                 case 3:
                                    {
                                       RetErrorV3(l_UserDlgId,RoamingNotAllowed_odb);
                                    }
                                    break;
                                 case 2:
                                    {
                                       RetErrorV2(l_UserDlgId,RoamingNotAllowed_odb);
                                    }
                                    break;
                                 case 1:
                                    RetErrorV1(l_UserDlgId,RoamingNotAllowed_odb);
                                    break;
                                 default:
                                    CLOG(0,0,"Unknown l_Version %d",l_Version);
                                    break;
                              }
                           }
                        }
                        else if((l_rsd->m_ErrorCode == 10) || (l_rsd->m_ErrorCode == 11) || (l_rsd->m_ErrorCode == 12)  || (l_rsd->m_ErrorCode == 41) || (l_rsd->m_ErrorCode == 42) || (l_rsd->m_ErrorCode == 43) || (l_rsd->m_ErrorCode == 44) )
                        {
                           int l_ErrCode = 0;
                           if((l_rsd->m_ErrorCode == 10) || (l_rsd->m_ErrorCode == 11))
                           {
                              l_ErrCode = g_MmConfigReaderObj->m_Multi_Imsi_ErrCode; 
                           }
                           else if(l_rsd->m_ErrorCode == 12)
                           {
                              //m_tdr.setString(TDR_INDEX_MM_MSISDN_ALLOC_STATUS,"N");
                              l_ErrCode = g_MmConfigReaderObj->m_MsisdnAllocErrCode; 
                           }
                           else if(41 == l_rsd->m_ErrorCode)
                           {
                              LLOG(0,0,"VLR Address/IMSI Blacklist configured to send PreArrangedEnd");
                              MapCloseReq l_closeReq(l_UserDlgId);
                              l_closeReq.m_CloseType = MAP_CLOSE_TYPE_PRE_ARRANGED_END;
                              g_sc.sendMsg(this, &l_closeReq);
                              return true;
                           }
                           else if(42 == l_rsd->m_ErrorCode)
                           {
                              LLOG(0,0,"VLR Address/IMSI Blacklist configured to send RoamingNotAllowed-PLMN");
                              l_ErrCode = 8;
                           }
                           else if(43 == l_rsd->m_ErrorCode)
                           {
                              LLOG(0,0,"VLR Address/IMSI Blacklist configured to send RoamingNotAllowed-ODB");
                              l_ErrCode = 9;
                           }
                           else if(44 == l_rsd->m_ErrorCode)
                           {
                              LLOG(0,0,"VLR Address/IMSI Blacklist configured to send UnknownSubscriber");
                              l_ErrCode = 1;
                           }
                           LLOG(0,0,"Received Error Code [%d] Sending the configured Error code [%d]",l_rsd->m_ErrorCode,l_ErrCode);
                           switch(l_Version)
                           {
                              case 3:
                                 {
                                    switch(l_ErrCode)
                                    {

                                       case 1:
                                          RetErrorV3(l_UserDlgId,UnknownSubscriber);
                                          break;

                                       case 8:
                                          RetErrorV3(l_UserDlgId,RoamingNotAllowed_plmn);
                                          break;

                                       case 9:
                                          RetErrorV3(l_UserDlgId,RoamingNotAllowed_odb);
                                          break;

                                       case 34:
                                          RetErrorV3(l_UserDlgId,SystemFailure);
                                          break;

                                       case 36:
                                          RetErrorV3(l_UserDlgId,UnexpectedData);
                                          break;

                                       default:
                                          {
                                             WLOG(0,0,"Unknown error code %d read in config, sending Roaming not allowed HPLMN",l_ErrCode);
                                             RetErrorV3(l_UserDlgId,RoamingNotAllowed_plmn);
                                          }
                                          break;
                                    }
                                 }
                                 break;
                              case 2:
                                 {
                                    switch(l_ErrCode)
                                    {

                                       case 1:
                                          RetErrorV2(l_UserDlgId,UnknownSubscriber);
                                          break;

                                       case 8:
                                          RetErrorV2(l_UserDlgId,RoamingNotAllowed_plmn);
                                          break;

                                       case 9:
                                          RetErrorV2(l_UserDlgId,RoamingNotAllowed_odb);
                                          break;

                                       case 34:
                                          RetErrorV2(l_UserDlgId,SystemFailure);
                                          break;

                                       case 36:
                                          RetErrorV2(l_UserDlgId,UnexpectedData);
                                          break;


                                       default:
                                          {
                                             WLOG(0,0,"Unknown error code %d read in config, sending Roaming not allowed HPLMN",l_ErrCode);
                                             RetErrorV2(l_UserDlgId,RoamingNotAllowed_plmn);
                                          }
                                          break;
                                    }
                                 }
                                 break;
                              case 1:
                                 {
                                    switch(l_ErrCode)
                                    {

                                       case 1:
                                          RetErrorV1(l_UserDlgId,UnknownSubscriber);
                                          break;

                                       case 8:
                                          RetErrorV1(l_UserDlgId,RoamingNotAllowed_plmn);
                                          break;

                                       case 9:
                                          RetErrorV1(l_UserDlgId,RoamingNotAllowed_odb);
                                          break;

                                       case 34:
                                          RetErrorV1(l_UserDlgId,SystemFailure);
                                          break;

                                       case 36:
                                          RetErrorV1(l_UserDlgId,UnexpectedData);
                                          break;

                                       default:
                                          {
                                             WLOG(0,0,"Unknown error code %d read in config, sending Roaming not allowed HPLMN",l_ErrCode);
                                             RetErrorV1(l_UserDlgId,RoamingNotAllowed_plmn);
                                          }
                                          break;
                                    }
                                 }
                                 break;
                              default:
                                 ELOG(0,0,"Unrecognizable version %d",l_Version);
                                 break;
                           }
                        }
                        else //((l_rsd->m_ErrorCode == -200)||(l_rsd->m_ErrorCode == 2))
                        {
                           CLOG(0,0,"Unexpected DB Error code received");
                           switch(l_Version)
                           {
                              case 3:
                                 {
                                    RetErrorV3(l_UserDlgId,SystemFailure);
                                 }
                                 break;
                              case 2:
                                 {
                                    RetErrorV2(l_UserDlgId,SystemFailure);
                                 }
                                 break;
                              case 1:
                                 RetErrorV1(l_UserDlgId,SystemFailure);
                                 break;
                              default:
                                 ELOG(0,0,"Unknown MAP version msg");
                                 break;
                           }
                        }
                     }
                  }
                  break;              
               case m_usds:
                  {                       
                     UpdateVLRData *l_usd = (UpdateVLRData*) p_MsgPtr;
                     l_UserDlgId = l_usd->m_UserDlgId;
                     TLOG(0,0,"DB message after updating Subsciber Data received on the call state %d",(m_callState)l_state);                     
                     if(l_usd->m_ErrorCode != 0)
                     {
                        m_tdr.setInteger(TDR_INDEX_DB_ERR_CODE,l_usd->m_ErrorCode); 
                        m_tdr.setString(TDR_INDEX_DB_ERR_DESC,(char *)l_usd->m_ErrorMsg);
                     }
                     if(l_usd->m_DbQueryRes == DB_QUERY_RES_SUCCESS)
                     {
                        LLOG(0,0,"Successful updatation of UPD data in DB");
                     }
                     else
                     {
                        ELOG(0,0,"%d-Error while Updating GSM related info into DB Error Code %d, ErrorMsg: %s",l_UserDlgId,l_usd->m_ErrorCode,l_usd->m_ErrorMsg);                        
                     }
                  }
                  break;
               case m_usdf:
                  {
                     UpdateVLRData *l_usd = (UpdateVLRData*) p_MsgPtr;
                     l_UserDlgId = l_usd->m_UserDlgId;
                     if(l_usd->m_ErrorCode != 0)
                     {
                        m_tdr.setInteger(TDR_INDEX_DB_ERR_CODE,l_usd->m_ErrorCode); 
                        m_tdr.setString(TDR_INDEX_DB_ERR_DESC,(char *)l_usd->m_ErrorMsg);
                     }
                     TLOG(0,0,"DB message after updating Subsciber Data received on the call state %d",(m_callState)l_state);
                     if(l_usd->m_DbQueryRes == DB_QUERY_RES_SUCCESS)
                     {
                        LLOG(0,0,"Successful updatation of UPD data in DB,Ending of this CtxtUpdateLocation");
                     }
                     else
                     {
                        ELOG(0,0,"%d-Error while Updating GSM related info into DB Error Code %d, ErrorMsg: %s",l_UserDlgId,l_usd->m_ErrorCode,l_usd->m_ErrorMsg);                        
                     }
                  }
                  break;
               default:
                  {
                     CLOG(0,0,"Did not expect a DB data at this Call state");                     
                  }
                  break;
            }
         }
         break;

      default:
         CLOG(0, 0, "Unknown message received");
         break;
   }
   return true;
}

bool CtxtUpdateLocation::CheckParametersV1(int l_UserDlgId,IMAP1_UpdateLocationArg* l_temp)
{
   DLOG(0,0,"Check parameters for Dialog Id %d",l_UserDlgId);
   memset(&l_updv1,'\0',sizeof(CallDetails));
   BCDToString(l_updv1.imsi,l_temp->imsi.value,l_temp->imsi.length);
   if(strlen((char *)l_updv1.imsi) != IMSILEN)
      return false;
   setTraceImsi((char *)l_updv1.imsi);
   m_tdr.setChar(TDR_INDEX_REQUEST_TYPE,'I'); // 1-msisdn 2-imsi 3-both
   m_tdr.setString(TDR_INDEX_REQUEST_IMSI,(char*)l_updv1.imsi);

   snprintf(m_activeImsi,sizeof(m_activeImsi),"%s",(char *)l_updv1.imsi);

   TLOG(0,0,"Trace enabled on imsi %s",(char *)l_updv1.imsi);
   //if(l_temp->locationInfo.choice & IMAP1_LocationInfo_roamingNumber_chosen)
   if(l_temp->locationInfo.choice & IMAP1_mscNumber_chosen)
      BCDToString(l_updv1.msc,l_temp->locationInfo.u.mscNumber.value,l_temp->locationInfo.u.mscNumber.length);
   if((strlen((char*)l_updv1.msc) < MINISDNADDRLEN) && (strlen((char*)l_updv1.msc) > MAXISDNADDRLEN))
      return false;

   BCDToString(l_updv1.vlr,l_temp->vlrNumber.value,l_temp->vlrNumber.length);
   if((strlen((char*)l_updv1.vlr) < MINISDNADDRLEN) && (strlen((char*)l_updv1.msc) > MAXISDNADDRLEN))
      return false;

   LLOG(0,0,"IMSI %s MSC_Number %s VLR_Number: %s",l_updv1.imsi,l_updv1.msc+2,l_updv1.vlr+2);
   m_tdr.setString(TDR_INDEX_MSC_ADDRESS,(char*)l_updv1.msc+2);
   m_tdr.setString(TDR_INDEX_VLR_ADDRESS,(char*)l_updv1.vlr+2);

   if(l_temp->bit_mask & IMAP1_UpdateLocationArg_lmsi_present)
   {
      memcpy(l_updv1.lmsi,l_temp->lmsi.value,l_temp->lmsi.length);
      LLOG(0,0,"LMSI %02x%02x%02x%02x",l_updv1.lmsi[0],l_updv1.lmsi[1],l_updv1.lmsi[2],l_updv1.lmsi[3]);
      m_tdr.setHex(TDR_INDEX_LMSI,(char *)l_updv1.lmsi,l_temp->lmsi.length);
   }
   DLOG(0,0,"Check parameters true for dlgId %d",l_UserDlgId);
   return true;
}

bool CtxtUpdateLocation::CheckParametersV2(int l_UserDlgId, IMAP2_UpdateLocationArg *l_temp)
{
   DLOG(0,0,"Checking the received parameters");
   memset(&l_updv2,'\0',sizeof(CallDetails));

   BCDToString(l_updv2.imsi,l_temp->imsi.value,l_temp->imsi.length);
   if(strlen((char *)l_updv2.imsi) != IMSILEN)
      return false;
   setTraceImsi((char *)l_updv2.imsi);
   m_tdr.setChar(TDR_INDEX_REQUEST_TYPE,'I'); // 1-msisdn 2-imsi 3-both
   m_tdr.setString(TDR_INDEX_REQUEST_IMSI,(char*)l_updv2.imsi);
   TLOG(0,0,"Trace enabled on imsi %s",(char *)l_updv2.imsi);

   snprintf(m_activeImsi,sizeof(m_activeImsi),"%s",(char *)l_updv2.imsi);

   BCDToString(l_updv2.msc,l_temp->msc_Number.value,l_temp->msc_Number.length);
   if((MINISDNADDRLEN > strlen((char*)l_updv2.msc)) && (MAXISDNADDRLEN < strlen((char*)l_updv2.msc)))
      return false;

   BCDToString(l_updv2.vlr,l_temp->vlr_Number.value,l_temp->vlr_Number.length);
   if((MINISDNADDRLEN > strlen((char*)l_updv2.vlr)) && (MAXISDNADDRLEN < strlen((char*)l_updv2.msc)))
      return false;

   LLOG(0,0,"IMSI %s MSC_Number %s VLR_Number: %s",l_updv2.imsi,l_updv2.msc+2,l_updv2.vlr+2);
   m_tdr.setString(TDR_INDEX_MSC_ADDRESS,(char*)l_updv2.msc+2);
   m_tdr.setString(TDR_INDEX_VLR_ADDRESS,(char*)l_updv2.vlr+2);

   if(l_temp->bit_mask & IMAP2_UpdateLocationArg_lmsi_present)
   {
      memcpy(l_updv2.lmsi,l_temp->lmsi.value,l_temp->lmsi.length);
      DLOG(0,0,"LMSI %02x%02x%02x%02x",l_updv2.lmsi[0],l_updv2.lmsi[1],l_updv2.lmsi[2],l_updv2.lmsi[3]);
      m_tdr.setHex(TDR_INDEX_LMSI,(char *)l_updv2.lmsi,l_temp->lmsi.length);
   }
   DLOG(0,0,"Check parameters true for dlgId %d",l_UserDlgId);
   return true;
}

bool CtxtUpdateLocation::CheckParametersV3(int l_UserDlgId, IMAP3_UpdateLocationArg *l_temp)
{
   DLOG(0,0,"Inside CheckParameters for UPD request version 3");
   memset(&l_updv3,'\0',sizeof(Details));
   BCDToString(l_updv3.imsi,l_temp->imsi.value,l_temp->imsi.length);
   if(strlen((char *)l_updv3.imsi) != IMSILEN)
      return false;
   setTraceImsi((char *)l_updv3.imsi);
   m_tdr.setChar(TDR_INDEX_REQUEST_TYPE,'I'); // 1-msisdn 2-imsi 3-both
   m_tdr.setString(TDR_INDEX_REQUEST_IMSI,(char*)l_updv3.imsi);
   TLOG(0,0,"Trace enabled on imsi %s",(char *)l_updv3.imsi);
   snprintf(m_activeImsi,sizeof(m_activeImsi),"%s",(char *)l_updv3.imsi);

   BCDToString(l_updv3.msc,l_temp->msc_Number.value,l_temp->msc_Number.length);

   if((MAXISDNADDRLEN < strlen((char*)l_updv3.msc)) || (MINISDNADDRLEN > strlen((char*)l_updv3.msc)))
      return false;

   BCDToString(l_updv3.vlr,l_temp->vlr_Number.value,l_temp->vlr_Number.length);
   if((MAXISDNADDRLEN < strlen((char*)l_updv3.vlr)) || (MINISDNADDRLEN > strlen((char*)l_updv3.vlr)))
      return false;

   LLOG(0,0,"IMSI %s MSC_Number %s VLR_Number: %s",l_updv3.imsi,l_updv3.msc+2,l_updv3.vlr+2);
   m_tdr.setString(TDR_INDEX_MSC_ADDRESS,(char*)l_updv3.msc+2);
   m_tdr.setString(TDR_INDEX_VLR_ADDRESS,(char*)l_updv3.vlr+2);
#if 1//All optional parameters inside this
   if(l_temp->bit_mask & IMAP3_UpdateLocationArg_lmsi_present)
   {
      memcpy(l_updv3.lmsi,l_temp->lmsi.value,l_temp->lmsi.length);
      DLOG(0,0,"LMSI %02x%02x%02x%02x",l_updv3.lmsi[0],l_updv3.lmsi[1],l_updv3.lmsi[2],l_updv3.lmsi[3]);
      m_tdr.setHex(TDR_INDEX_LMSI,(char *)l_updv3.lmsi,l_temp->lmsi.length);
   }
   memset(l_updv3.VlrCap_camel,'\0',5);
   l_updv3.VlrCap_Camel1 = false;
   l_updv3.VlrCap_Camel2 = false;
   l_updv3.VlrCap_Camel3 = false;
   l_updv3.VlrCap_Camel4 = false;
   l_updv3.VlrCap_Phase = 0;

   if(l_temp->bit_mask & IMAP3_UpdateLocationArg_vlr_Capability_present)
   {
#if 1      
      if(l_temp->vlr_Capability.bit_mask & IMAP3_VLR_Capability_supportedCamelPhases_present)
      {
         DLOG(0,0,"Camel supported");
         if(*l_temp->vlr_Capability.supportedCamelPhases.value & IMAP3_phase1)
         {
            DLOG(0,0,"CAMEL Phase 1 supported");
            l_updv3.VlrCap_Camel1 = true;
            l_updv3.VlrCap_camel[0] = '1';
            l_updv3.VlrCap_Phase = 1;
         }
         else
         {
            l_updv3.VlrCap_camel[0] = '0';
         }
         if(*l_temp->vlr_Capability.supportedCamelPhases.value & IMAP3_phase2)
         {
            DLOG(0,0,"CAMEL Phase 2 supported");
            l_updv3.VlrCap_Camel2 = true;
            l_updv3.VlrCap_camel[1] = '1';
            l_updv3.VlrCap_Phase = 2;
         }
         else
         {
            l_updv3.VlrCap_camel[1] = '0';
         }
         if(*l_temp->vlr_Capability.supportedCamelPhases.value & IMAP3_phase3)
         {
            DLOG(0,0,"CAMEL Phase 3 supported");
            l_updv3.VlrCap_Camel3 = true;
            l_updv3.VlrCap_camel[2] = '1';
            l_updv3.VlrCap_Phase = 3;
         }
         else
         {
            l_updv3.VlrCap_camel[2] = '0';
         }
         if(*l_temp->vlr_Capability.supportedCamelPhases.value & IMAP3_phase4)
         {
            DLOG(0,0,"CAMEL Phase 4 supported");
            l_updv3.VlrCap_Camel4 = true;
            l_updv3.VlrCap_camel[3] = '1';
            l_updv3.VlrCap_Phase = 4;
         }
         else
         {
            l_updv3.VlrCap_camel[3] = '0';
         }         
      }
      else
      {
         LLOG(0,0,"CAMEL Support indicator not present");
      }
      DLOG(0,0,"Max camel phase supported %d,VLR camel phases reveiced %s",l_updv3.VlrCap_Phase,l_updv3.VlrCap_camel);

#endif
      if(l_temp->vlr_Capability.bit_mask & IMAP3_VLR_Capability_solsaSupportIndicator_present)
      {
         DLOG(0,0,"soLSA support present");
         l_updv3.soLSA = true;
      }
      l_updv3.istSupportIndicator = 5;
      if(l_temp->vlr_Capability.bit_mask & IMAP3_VLR_Capability_istSupportIndicator_present)
      {
         DLOG(0,0,"IST support indicator present");
         if(l_temp->vlr_Capability.istSupportIndicator == IMAP3_basicISTSupported)
         {
            l_updv3.istSupportIndicator = 0;
            DLOG(0,0,"Basic IST service supported l_istSupportIndicator = %c",l_updv3.istSupportIndicator);
         }
         if(l_temp->vlr_Capability.istSupportIndicator == IMAP3_istCommandSupported)
         {
            l_updv3.istSupportIndicator = 1;
            DLOG(0,0,"IST command supported l_istSupportIndicator = %d",l_updv3.istSupportIndicator);
         }
      }
      if(l_temp->vlr_Capability.bit_mask & IMAP3_VLR_Capability_superChargerSupportedInServingNetworkEntity_present)
      {
         DLOG(0,0,"SuperCharge supported in serving network entity is present");
         l_updv3.SuperCharge = true;
      }
      if(l_temp->vlr_Capability.bit_mask & IMAP3_VLR_Capability_longFTN_Supported_present)
      {
         l_updv3.LongFTN = true;
         DLOG(0,0,"Long FTN support present value is %d",l_updv3.LongFTN);
      }
      if(l_temp->vlr_Capability.bit_mask & IMAP3_VLR_Capability_supportedLCS_CapabilitySets_present)
      {
         l_updv3.lcsCS1 = false;
         l_updv3.lcsCS2 = false;
         l_updv3.lcsCS3 = false;
         l_updv3.lcsCS4 = false;

         TLOG(0,0,"LCS Support indicator present");
         if(*l_temp->vlr_Capability.supportedLCS_CapabilitySets.value & IMAP3_lcsCapabilitySet1)
         {
            TLOG(0,0,"LCS CS 1 supported");
            l_updv3.lcsCS1 = true;
         }
         if(*l_temp->vlr_Capability.supportedLCS_CapabilitySets.value & IMAP3_lcsCapabilitySet2)
         {
            l_updv3.lcsCS2 = true;
            TLOG(0,0,"LCS CS 2 supported");
         }
         if(*l_temp->vlr_Capability.supportedLCS_CapabilitySets.value & IMAP3_lcsCapabilitySet3)
         {
            l_updv3.lcsCS3 = true;
            TLOG(0,0,"LCS CS 3 supported");
         }
         if(*l_temp->vlr_Capability.supportedLCS_CapabilitySets.value & IMAP3_lcsCapabilitySet4)
         {
            l_updv3.lcsCS4 = true;
            TLOG(0,0,"LCS CS 4 supported");
         }
         m_isd.dbisd3.LcsIndicatorPresent = true;
         if((l_updv3.lcsCS1 == false) && (l_updv3.lcsCS2 == false) && (l_updv3.lcsCS3 == false) &&(l_updv3.lcsCS4 == false))
         {
            LLOG(0,0,"LCS Support indicator present but no CapabilitySets present, LCS not supported");
            m_isd.dbisd3.LcsIndicatorPresent = false;
         }
      }
#if 1 //TODO --> Camel4CSI
      if(l_temp->vlr_Capability.bit_mask & IMAP3_VLR_Capability_offeredCamel4CSIs_present)
      {
         DLOG(0,0,"Offered CAMEL 4 CSI Support indicator present");
         if(*l_temp->vlr_Capability.offeredCamel4CSIs.value & IMAP3_OfferedCamel4CSIs_o_csi)
         {
            DLOG(0,0,"Offered Camel4 CSIs_o_csi present");
            l_updv3.c4_oCSI = true;
         }
         if(*l_temp->vlr_Capability.offeredCamel4CSIs.value & IMAP3_OfferedCamel4CSIs_d_csi)
         {
            DLOG(0,0,"Offered Camel4 CSIs_d_csi present");
            l_updv3.c4_dCSI = true;
         }
         if(*l_temp->vlr_Capability.offeredCamel4CSIs.value & IMAP3_OfferedCamel4CSIs_vt_csi)
         {
            DLOG(0,0,"Offered Camel4 CSIs_vt_csi present");
            l_updv3.c4_vtCSI = true;
         }
         if(*l_temp->vlr_Capability.offeredCamel4CSIs.value & IMAP3_OfferedCamel4CSIs_t_csi)
         {
            DLOG(0,0,"Offered Camel4 CSIs_t_csi present");
            l_updv3.c4_tCSI = true;
         }
         if(*l_temp->vlr_Capability.offeredCamel4CSIs.value & IMAP3_OfferedCamel4CSIs_mt_sms_csi)
         {
            DLOG(0,0,"Offered Camel4 CSIs_mt_sms_csi present");
            l_updv3.c4_mtsCSI = true;
         }
         if(*l_temp->vlr_Capability.offeredCamel4CSIs.value & IMAP3_OfferedCamel4CSIs_mg_csi)
         {
            DLOG(0,0,"Offered Camel4 CSIs_mg_csi present");
            l_updv3.c4_mgCSI = true;
         }
         if(*l_temp->vlr_Capability.offeredCamel4CSIs.value & IMAP3_psi_enhancements)
         {
            DLOG(0,0,"Camel4 CSIs psi_enhancements present");
            l_updv3.c4_psiCSI = true;
         }
      }
#endif
#if 1//TODO --> Supported RAT type
      if(l_temp->vlr_Capability.bit_mask & IMAP3_VLR_Capability_supportedRAT_TypesIndicator_present)
      {
         DLOG(0,0,"RAT type support present");

         if(*l_temp->vlr_Capability.supportedRAT_TypesIndicator.value & IMAP3_utran_1)
         {
            DLOG(0,0,"UTRAN supported");
            l_updv3.utran = true;
         }
         if(*l_temp->vlr_Capability.supportedRAT_TypesIndicator.value & IMAP3_geran_1)
         {
            DLOG(0,0,"GERAN Supported");
            l_updv3.geran = true;
         }
      }
#endif
      if(l_temp->vlr_Capability.bit_mask & IMAP3_longGroupID_Supported_present)
      {
         DLOG(0,0,"Long group ID support present");
         l_updv3.lgIDSupp = true;
      }

      if(l_temp->vlr_Capability.bit_mask & IMAP3_mtRoamingForwardingSupported_present)
      {
         DLOG(0,0,"Roaming forwarding supported");
         l_updv3.l_mtrf_support_ind = 1;
      }
   }
   LLOG(0,0,"Camel Phase supported is %s, MAX VLR Camel phase supported is %d",l_updv3.VlrCap_camel,l_updv3.VlrCap_Phase);
   if(l_temp->bit_mask & IMAP3_UpdateLocationArg_informPreviousNetworkEntity_present)
   {
      DLOG(0,0,"Inform previous network entity present");
      l_updv3.informPreviousNetworkEntity = true;
   }
   if(l_temp->bit_mask & IMAP3_cs_LCS_NotSupportedByUE_present)
   {
      LLOG(0,0,"LCS not supported by UE");
      l_updv3.cs_LCS_NotSupportedByUE = true;
   }
   if(l_temp->bit_mask & IMAP3_UpdateLocationArg_v_gmlc_Address_present)
   {
      DLOG(0,0,"v_gmlc_Address received, len [%d] Type [%d]",l_temp->v_gmlc_Address.length,l_temp->v_gmlc_Address.value[0]);
      if(l_temp->v_gmlc_Address.value[0] != 0x04)
      {
         WLOG(0,0,"GMLC Address is not of type IPV4");
         return false;
      }
      char l_gmlcAddr[25];
      snprintf(l_gmlcAddr,24,"%d.%d.%d.%d",l_temp->v_gmlc_Address.value[1],l_temp->v_gmlc_Address.value[2],l_temp->v_gmlc_Address.value[3],l_temp->v_gmlc_Address.value[4]);
      strcpy((char *)l_updv3.gmlc_Address,l_gmlcAddr);
      LLOG(0,0,"gmlc address is %s",l_updv3.gmlc_Address);
   }
   if(l_temp->bit_mask & IMAP3_UpdateLocationArg_add_info_present)
   {
      TLOG(0,0,"add_info present in UPD req, serving network entity has ADD");
      l_updv3.AddCapability = true;
      BCDToString(l_updv3.imeisv,l_temp->add_info.imeisv.value,l_temp->add_info.imeisv.length);
      //LLOG(0,0,"imeisv is %s",l_updv3.imeisv);
      snprintf((char*)m_Orig_Imei,sizeof(m_Orig_Imei),"%s",l_updv3.imeisv);
      DLOG(0,0,"Orig_Imei is [%s]",m_Orig_Imei);
      // 4.0.2.0
      if(1 == g_IMEI_EncrFlag)
      {
         char l_tempIMEI[200];
         memset(l_tempIMEI,'\0',sizeof(l_tempIMEI));
         bool res = Copy_encryptedIMEI((char*)l_updv3.imeisv,l_tempIMEI);
         unsigned char l_rawImei[200];
         memset(l_rawImei,'\0',sizeof(l_rawImei));
         hexToStringWithoutSpace(l_rawImei, 200, (unsigned char*)l_tempIMEI, 16);
         m_tdr.setString(TDR_INDEX_IMEI,(char*)l_rawImei);
         if(res == true)
         {
            memset((char*)l_updv3.imeisv,'\0',strlen((char*)l_updv3.imeisv));
            strncpy((char*)l_updv3.imeisv,(char*)l_rawImei,strlen((char*)l_rawImei));
         }
         else
         {
            CLOG(0,0,"Encryption of Imei Failed !!!!");
         }
      }
      else
         m_tdr.setString(TDR_INDEX_IMEI,(char*)l_updv3.imeisv);

      if(l_temp->add_info.bit_mask & IMAP3_skipSubscriberDataUpdate_present)
      {
         l_updv3.skipISDUpdate = true;
         DLOG(0,0,"UpdateLocationArg->add_info.skipISDUpdate present value is %d , no need to send ISD",l_updv3.skipISDUpdate);
      }
   }
   if(l_temp->bit_mask & IMAP3_UpdateLocationArg_extensionContainer_present)
   {
      DLOG(0,0,"Extension Container set in Bit_Mask");
      if(strlen((char*)m_ExtnCntrData) > 1)
      {
         TLOG(0,0,"Decoded ExtensionContainer data [%s]",m_ExtnCntrData);
         string l_ExtrData = "";
         l_ExtrData.append((char*)m_ExtnCntrData);
         string l_ExtType = MmConfigReader::readValue(l_ExtrData,"IMEI");
         if(l_ExtType.length() == 16)
         {
            DLOG(0,0,"Parsed Data [%s]",l_ExtType.c_str());
            unsigned char l_ExtData[25];
            memset(l_ExtData,'\0',sizeof(l_ExtData));
            atohx((char *)l_ExtData,(char *)l_ExtType.c_str());
            //TLOG_HEX(0,0,"IMEI in BCD Format ",(char*)l_ExtData,strlen((char*)l_ExtData));
            BCDToString(l_updv3.imeisv,l_ExtData,8);
            snprintf((char*)m_Orig_Imei,sizeof(m_Orig_Imei),"%s",l_updv3.imeisv);
            DLOG(0,0,"Extension Container: m_Orig_Imei is [%s]",m_Orig_Imei);
            //LLOG(0,0,"IMEISV from Extension Container is [%s]",l_updv3.imeisv);

            //4.0.2.0
            if(1 == g_IMEI_EncrFlag)
            {
               char l_tempIMEI[200];
               memset(l_tempIMEI,'\0',sizeof(l_tempIMEI));
               bool res = Copy_encryptedIMEI((char*)l_updv3.imeisv,l_tempIMEI);
               unsigned char l_rawImei[200];
               memset(l_rawImei,'\0',sizeof(l_rawImei));
               hexToStringWithoutSpace(l_rawImei, 200, (unsigned char *)l_tempIMEI, 16);
               m_tdr.setString(TDR_INDEX_IMEI,(char*)l_rawImei);
               if(res == true)
               {
                  memset((char*)l_updv3.imeisv,'\0',strlen((char*)l_updv3.imeisv));
                  strncpy((char*)l_updv3.imeisv,(char*)l_rawImei,strlen((char*)l_rawImei));
               }
               else
               {
                  CLOG(0,0,"Encryption of Imei Failed !!!!");
               }
            }
            else
               m_tdr.setString(TDR_INDEX_IMEI,(char*)l_updv3.imeisv);

         }
         else
         {
            LLOG(0,0,"Extension Container Data present, but does not contain IMEI , Ignoring it");
         }
      }
      else
      {
         TLOG(0,0,"Extension Container Data present, but not decoded, Ignoring it");
      }
   }
#endif
   DLOG(0,0,"Check parameters() true for dlgId %d",l_UserDlgId);
   return true;   
}

#if 1
bool CtxtUpdateLocation::CheckParametersRSDV2(int l_UserDlgId,IMAP2_RestoreDataArg *l_rd)
{
   DLOG(0,0,"Inside Check parameters for Dialog Id %d",l_UserDlgId);
   BCDToString(l_updv2.imsi,l_rd->imsi.value,l_rd->imsi.length);
   if(strlen((char *)l_updv2.imsi) != IMSILEN)
      return false;
   setTraceImsi((char *)l_updv2.imsi);
   TLOG(0,0,"Trace enabled on imsi %s",(char *)l_updv2.imsi);
   m_tdr.setChar(TDR_INDEX_REQUEST_TYPE,'I'); // 1-msisdn 2-imsi 3-both
   m_tdr.setString(TDR_INDEX_REQUEST_IMSI,(char*)l_updv2.imsi);
   strcpy((char *)l_updv2.msc,(char *)m_SccpGt);
   if((MAXISDNADDRLEN < strlen((char*)l_updv2.msc)) || (MINISDNADDRLEN > strlen((char*)l_updv2.msc)))
      return false;

   strcpy((char *)l_updv2.vlr,(char *)m_SccpGt);
   if((MAXISDNADDRLEN < strlen((char*)l_updv2.vlr)) || (MINISDNADDRLEN > strlen((char*)l_updv2.vlr)))
      return false;

   if(l_rd->bit_mask & IMAP2_RestoreDataArg_lmsi_present)
   {
      memcpy(l_updv2.lmsi,l_rd->lmsi.value,l_rd->lmsi.length);
      DLOG(0,0,"LMSI %02x%02x%02x%02x",l_updv2.lmsi[0],l_updv2.lmsi[1],l_updv2.lmsi[2],l_updv2.lmsi[3]);
      m_tdr.setHex(TDR_INDEX_LMSI,(char *)l_updv2.lmsi,l_rd->lmsi.length);
   }
   DLOG(0,0,"Check parameters true for dlgId %d",l_UserDlgId);
   return true;
}

bool CtxtUpdateLocation::CheckParametersRSDV3(int l_UserDlgId,IMAP3_RestoreDataArg *l_rd)
{     
   DLOG(0,0,"Inside Check parameters for Dialog ID %d",l_UserDlgId);
   BCDToString(l_updv3.imsi,l_rd->imsi.value,l_rd->imsi.length);
   if(strlen((char *)l_updv3.imsi) != IMSILEN)
      return false;
   setTraceImsi((char *)l_updv3.imsi);
   LLOG(0,0,"Trace enabled on imsi %s",(char *)l_updv3.imsi);
   m_tdr.setChar(TDR_INDEX_REQUEST_TYPE,'I'); // 1-msisdn 2-imsi 3-both
   m_tdr.setString(TDR_INDEX_REQUEST_IMSI,(char*)l_updv3.imsi);
   strcpy((char *)l_updv3.msc,(char *)m_SccpGt);
   if((MAXISDNADDRLEN < strlen((char*)l_updv3.msc)) || (MINISDNADDRLEN > strlen((char*)l_updv3.msc)))
      return false;

   strcpy((char *)l_updv3.vlr,(char *)m_SccpGt);
   if((MAXISDNADDRLEN < strlen((char*)l_updv3.vlr)) || (MINISDNADDRLEN > strlen((char*)l_updv3.vlr)))
      return false;

   if(l_rd->bit_mask & IMAP3_RestoreDataArg_lmsi_present)
   {
      //BCDToString(l_lmsi,l_rd->lmsi.value,l_rd->lmsi.length);
      memcpy(l_updv3.lmsi,l_rd->lmsi.value,l_rd->lmsi.length);
      TLOG(0,0,"LMSI value received %02x%02x%02x%02x",l_updv3.lmsi[0],l_updv3.lmsi[1],l_updv3.lmsi[2],l_updv3.lmsi[3]);
      m_tdr.setHex(TDR_INDEX_LMSI,(char *)l_updv3.lmsi,l_rd->lmsi.length);
   }
   memset(l_updv3.VlrCap_camel,'\0',5);
   l_updv3.VlrCap_Camel1 = false;
   l_updv3.VlrCap_Camel2 = false;
   l_updv3.VlrCap_Camel3 = false;
   l_updv3.VlrCap_Camel4 = false;
   l_updv3.VlrCap_Phase = 0;
   if(l_rd->bit_mask & IMAP3_RestoreDataArg_vlr_Capability_present)
   {

      if(l_rd->vlr_Capability.bit_mask & IMAP3_VLR_Capability_supportedCamelPhases_present)
      {
         DLOG(0,0,"Camel supported");
         if(*l_rd->vlr_Capability.supportedCamelPhases.value & IMAP3_phase1)
         {
            DLOG(0,0,"CAMEL Phase 1 supported");
            l_updv3.VlrCap_Camel1 = true;
            l_updv3.VlrCap_camel[0] = '1';
            l_updv3.VlrCap_Phase = 1;
         }
         else
         {
            l_updv3.VlrCap_camel[0] = '0';
         }
         if(*l_rd->vlr_Capability.supportedCamelPhases.value & IMAP3_phase2)
         {
            DLOG(0,0,"CAMEL Phase 2 supported");
            l_updv3.VlrCap_Camel2 = true;
            l_updv3.VlrCap_camel[1] = '1';
            l_updv3.VlrCap_Phase = 2;
         }
         else
         {
            l_updv3.VlrCap_camel[1] = '0';
         }
         if(*l_rd->vlr_Capability.supportedCamelPhases.value & IMAP3_phase3)
         {
            DLOG(0,0,"CAMEL Phase 3 supported");
            l_updv3.VlrCap_Camel3 = true;
            l_updv3.VlrCap_camel[2] = '1';
            l_updv3.VlrCap_Phase = 3;
         }
         else
         {
            l_updv3.VlrCap_camel[2] = '0';
         }
         if(*l_rd->vlr_Capability.supportedCamelPhases.value & IMAP3_phase4)
         {
            DLOG(0,0,"CAMEL Phase 4 supported");
            l_updv3.VlrCap_Camel4 = true;
            l_updv3.VlrCap_camel[3] = '1';
            l_updv3.VlrCap_Phase = 4;
         }
         else
         {
            l_updv3.VlrCap_camel[3] = '0';
         }
         DLOG(0,0,"Formed Camel data string is %s",l_updv3.VlrCap_camel);
      }
      else
      {
         LLOG(0,0,"CAMEL phase support indicator not present in VLR Capability");
      }
      DLOG(0,0,"Max camel phase supported %d,VLR camel phases reveiced %s",l_updv3.VlrCap_Phase,l_updv3.VlrCap_camel);
      if(l_rd->vlr_Capability.bit_mask & IMAP3_VLR_Capability_solsaSupportIndicator_present)
      {
         DLOG(0,0,"soLSA support present");
         l_updv3.soLSA = true;
      }
      l_updv3.istSupportIndicator = 5;
      if(l_rd->vlr_Capability.bit_mask & IMAP3_VLR_Capability_istSupportIndicator_present)
      {
         DLOG(0,0,"IST support indicator present");
         if(l_rd->vlr_Capability.istSupportIndicator == IMAP3_basicISTSupported)
         {
            l_updv3.istSupportIndicator = 0;
            DLOG(0,0,"Basic IST service supported l_istSupportIndicator = %d",l_updv3.istSupportIndicator);
         }
         if(l_rd->vlr_Capability.istSupportIndicator == IMAP3_istCommandSupported)
         {
            l_updv3.istSupportIndicator = 1;
            DLOG(0,0,"IST command supported l_istSupportIndicator = %d",l_updv3.istSupportIndicator);
         }
      }
      if(l_rd->vlr_Capability.bit_mask & IMAP3_VLR_Capability_superChargerSupportedInServingNetworkEntity_present)
      {
         DLOG(0,0,"SuperCharge supported in serving network entity is present");
         l_updv3.SuperCharge = true;        
      }
      if(l_rd->vlr_Capability.bit_mask & IMAP3_VLR_Capability_longFTN_Supported_present)
      {
         l_updv3.LongFTN = true;//l_rd->vlr_Capability.longFTN_Supported.value;
         DLOG(0,0,"Long FTN support present value is %d",l_updv3.LongFTN);
      }
      if(l_rd->vlr_Capability.bit_mask & IMAP3_VLR_Capability_supportedLCS_CapabilitySets_present)
      {
         //DLOG(0,0,"LCS support present with value %x\n",l_rd->vlr_Capability.supportedLCS_CapabilitySets.value[sizeof(l_rd->vlr_Capability.supportedLCS_CapabilitySets.length)]);
         if(*l_rd->vlr_Capability.supportedLCS_CapabilitySets.value & IMAP3_lcsCapabilitySet1)
         {
            DLOG(0,0,"LCS CS 1 supported");
            l_updv3.lcsCS1 = 1;
         }
         if(*l_rd->vlr_Capability.supportedLCS_CapabilitySets.value & IMAP3_lcsCapabilitySet2)
         {
            l_updv3.lcsCS2 = 1;
            DLOG(0,0,"LCS CS 2 supported");
         }
         if(*l_rd->vlr_Capability.supportedLCS_CapabilitySets.value & IMAP3_lcsCapabilitySet3)
         {
            l_updv3.lcsCS3 = 1;
            DLOG(0,0,"LCS CS 3 supported");
         }
         if(*l_rd->vlr_Capability.supportedLCS_CapabilitySets.value & IMAP3_lcsCapabilitySet4)
         {
            l_updv3.lcsCS4 = 1;
            DLOG(0,0,"LCS CS 4 supported");
         }
      }
      if(l_rd->vlr_Capability.bit_mask & IMAP3_VLR_Capability_offeredCamel4CSIs_present)
      {
         DLOG(0,0,"CAMEL 4 CSI present");
         if(*l_rd->vlr_Capability.offeredCamel4CSIs.value & IMAP3_OfferedCamel4CSIs_o_csi)
         {
            DLOG(0,0,"Offered Camel4 CSIs_o_csi present");
            l_updv3.c4_oCSI = true;
         }
         if(*l_rd->vlr_Capability.offeredCamel4CSIs.value & IMAP3_OfferedCamel4CSIs_d_csi)
         {
            DLOG(0,0,"Offered Camel4 CSIs_d_csi present");
            l_updv3.c4_dCSI = true;
         }
         if(*l_rd->vlr_Capability.offeredCamel4CSIs.value & IMAP3_OfferedCamel4CSIs_vt_csi)
         {
            DLOG(0,0,"Offered Camel4 CSIs_vt_csi present");
            l_updv3.c4_vtCSI = true;
         }
         if(*l_rd->vlr_Capability.offeredCamel4CSIs.value & IMAP3_OfferedCamel4CSIs_t_csi)
         {
            DLOG(0,0,"Offered Camel4 CSIs_t_csi present");
            l_updv3.c4_tCSI = true;
         }
         if(*l_rd->vlr_Capability.offeredCamel4CSIs.value & IMAP3_OfferedCamel4CSIs_mt_sms_csi)
         {
            DLOG(0,0,"Offered Camel4 CSIs_mt_sms_csi present");
            l_updv3.c4_mtsCSI = true;
         }
         if(*l_rd->vlr_Capability.offeredCamel4CSIs.value & IMAP3_OfferedCamel4CSIs_mg_csi)
         {
            DLOG(0,0,"Offered Camel4 CSIs_mg_csi present");
            l_updv3.c4_mgCSI = true;
         }
         if(*l_rd->vlr_Capability.offeredCamel4CSIs.value & IMAP3_psi_enhancements)
         {
            DLOG(0,0,"Camel4 CSIs psi_enhancements present");
            l_updv3.c4_psiCSI = true;
         }
      }
      if(l_rd->vlr_Capability.bit_mask & IMAP3_VLR_Capability_supportedRAT_TypesIndicator_present)
      {
         DLOG(0,0,"RAT type support present");
         if(*l_rd->vlr_Capability.supportedRAT_TypesIndicator.value & IMAP3_utran_1)
         {
            DLOG(0,0,"UTRAN supported");
            l_updv3.utran = true;;
         }
         if(*l_rd->vlr_Capability.supportedRAT_TypesIndicator.value & IMAP3_geran_1)
         {
            DLOG(0,0,"GERAN Supported");
            l_updv3.geran = true;
         }
      }
      if(l_rd->vlr_Capability.bit_mask & IMAP3_longGroupID_Supported_present)
      {
         DLOG(0,0,"Long group ID support present");
         l_updv3.lgIDSupp = true;
      }
   }
   else
   {
      LLOG(0,0,"VLR capability and camel phase support indicator not present");
   }
   LLOG(0,0,"Camel Phase supported is %s, MAX VLR Camel phase supported is %d",l_updv3.VlrCap_camel,l_updv3.VlrCap_Phase);
   return true;
}
#endif

int CtxtUpdateLocation::processDBData(int l_UserDlgId,RetrieveSubsVLRData *l_rsd)
{
   DLOG(0,0,"Processing DB data for the Dialog id %d",l_UserDlgId);
   l_state = m_psd;
   strncpy((char *)l_AccId,(char *)l_rsd->m_AccId,strlen((char *)l_rsd->m_AccId));
   l_nwId = l_rsd->m_nwid;
   l_pnwId = l_rsd->m_pnwid;
   l_AlocType = l_rsd->m_AlocType;
   strncpy((char *)l_actMsisdn,(char *)l_rsd->m_ActMsisdn,strlen((char*)l_rsd->m_ActMsisdn));

   l_roamInd = l_rsd->m_RoamIND;

   l_mwd = l_rsd->m_MWD;
   
   if(true == m_fIsd)
   {
      map<int, HlrNetworks* > :: iterator l_HlrNetworksDetailsIter;
      l_HlrNetworksDetailsIter = g_spdPtr->m_HlrNetworks.find(l_nwId);
      if(l_HlrNetworksDetailsIter == g_spdPtr->m_HlrNetworks.end())
      {
         LLOG(0,0,"Network ID not found in networks map[%d]",l_nwId);
      }
      else
      {
         DLOG(0,0,"Network ID found in networks map[%d]",l_nwId);
         LLOG(0,0,"Change Template Gsm Action in Networks page is ... [%d]",((l_HlrNetworksDetailsIter->second)->m_ChangeTempGsmAction));
         m_tdr.setInteger(TDR_INDEX_SSM_USSD_SERV_CODE,((l_HlrNetworksDetailsIter->second)->m_ChangeTempGsmAction));
      }
   }
   
   if(l_mwd)
   {
      strncpy((char *)l_AlertMsisdn,(char *)l_rsd->m_AlertMsisdn,strlen((char *)l_rsd->m_AlertMsisdn));
      DLOG(0,0,"Message waiting set, Alert MSISDN is %s",l_AlertMsisdn);
   }   
   m_tdr.setInteger(TDR_INDEX_CM_SRI_TCSI_STATUS,l_roamInd);
   LLOG(0,0,"DBRES: AccountID[%s] NetworkId[%d] MsisdnAllocationType[%d] ActiveMSISDN[%s] PrimaryMSISDN[%s] PrimaryIMSI[%s] RoamingIndicator[%d] HLRAddress[%s] PartnerType[%d]",l_AccId,l_nwId,l_AlocType,l_actMsisdn,l_priMsisdn,l_priImsi,l_roamInd,l_hlrAddr,l_rsd->m_partType);

   // HLR 1.0.16.0 Begin
   char l_allocTypeBuf[50];
   memset(l_allocTypeBuf,'\0',sizeof(l_allocTypeBuf));

   char l_partnerTypeBuf[30];
   memset(l_partnerTypeBuf,'\0',sizeof(l_partnerTypeBuf));

   if(0 == l_AlocType)
   {
      strcpy(l_allocTypeBuf,"Home Msisdn");
   }
   else if(1 == l_AlocType)
   {
      strcpy(l_allocTypeBuf,"Dummy Msisdn");
   }
   else if(2 == l_AlocType)
   {
      strcpy(l_allocTypeBuf,"CBOS Allocated Msisdn");
   }
   else if(3 == l_AlocType)
   {
      strcpy(l_allocTypeBuf,"LERG Allocated Msisdn");
   }
   else if(4 == l_AlocType)
   {
      strcpy(l_allocTypeBuf,"Home Real Msisdn");
   }
   else if(5 == l_AlocType)
   {
      strcpy(l_allocTypeBuf,"Temporary Dummy Msisdn");
   }

   if(0 == (l_rsd->m_partType))
   {
      strcpy(l_partnerTypeBuf,"Home");
   }
   else if(1 == (l_rsd->m_partType))
   {
      strcpy(l_partnerTypeBuf,"Internal");
   }
   else if(2 == (l_rsd->m_partType))
   {
      strcpy(l_partnerTypeBuf,"External");
   }

   LLOG(0,0,"DBRES: Subscriber Msisdn Allocation Type [%s] and Partner Type [%s]",l_allocTypeBuf,l_partnerTypeBuf);
   // HLR 1.0.16.0 End

   //DLOG(0,0,"Starting Gen profile\n");
   char GenPro[300];
   memset(GenPro,'\0',sizeof(GenPro));
   //char *tmp1;
   strncat(GenPro,"|",1);
   strncat(GenPro,(char *)l_rsd->m_GenINFO,strlen((char *)l_rsd->m_GenINFO));
   strncat(GenPro,"|",1);
   //DLOG(0,0,"The string tested is %s",GenPro);
   char str[25][53];
   memset(str,'\0',sizeof(str));
   tokenize(GenPro, (char*)str, 53);
   GenProfile.l_nwAccMode = atoi(str[1]);

   // 2.0.0.0 Begin
   int l_Converted_Nam = 0;
   bool l_Nam_Applicable = true;
   if( (0 == GenProfile.l_nwAccMode) || (7 == GenProfile.l_nwAccMode) )
   {
      GenProfile.l_nwAccMode = 0;
   }
   else if( (1 ==  GenProfile.l_nwAccMode) || (5 == GenProfile.l_nwAccMode) )
   {
      GenProfile.l_nwAccMode = 1;
   }
   else if( (2 ==  GenProfile.l_nwAccMode) || (6 == GenProfile.l_nwAccMode) )
   {
      GenProfile.l_nwAccMode = 2;
   }
   else
   {
      ELOG(0,0,"DBRES: Invalid NAM value[%d] .. setting default 0",GenProfile.l_nwAccMode);
      GenProfile.l_nwAccMode = 0;
   }
   // 2.0.0.0 End

   GenProfile.l_catgory = atoi(str[2]);
   GenProfile.l_subsRest = atoi(str[3]);
   GenProfile.l_accRest = atoi(str[4]);
   GenProfile.l_lmu = atoi(str[5]);
   GenProfile.l_ist = atoi(str[6]);
   if(m_imsOcsiProfId > 0)
   {
      GenProfile.l_ocsiPid = m_imsOcsiProfId;
   }
   else
   {
      GenProfile.l_ocsiPid = atoi(str[7]);
   }
   GenProfile.l_vtcsiPid = atoi(str[8]);
   GenProfile.l_ugcsiPid = atoi(str[9]);
   GenProfile.l_sscsiPid = atoi(str[10]);
   GenProfile.l_tifcsiPid = atoi(str[11]);
   GenProfile.l_dcsiPid = atoi(str[12]);
   GenProfile.l_moscsiPid = atoi(str[13]);
   GenProfile.l_mtscsiPid = atoi(str[14]);
   GenProfile.l_gcsiPid = atoi(str[15]);
   GenProfile.l_mgcsiPid = atoi(str[16]);
   GenProfile.l_pdpPid = atoi(str[17]);
   GenProfile.l_subsStatus = atoi(str[18]);      
   strncpy(GenProfile.l_bearer,str[19],52);
   strncpy(GenProfile.l_tele,str[20],strlen(str[20]));

   m_tdr.setInteger(TDR_INDEX_MM_NAM,GenProfile.l_nwAccMode);


   if(l_roamInd)
   {
      TLOG(0,0,"Roaming indicator set, removing PLMN specific bearer and tele sercice list");
      for(int ltele = 16;ltele < 32;ltele++)
      {
         GenProfile.l_tele[ltele] = '0';
      }
      for(int lbear = 36;lbear < 52;lbear++)
      {
         GenProfile.l_bearer[lbear] = '0';
      }
   }
   if(false == m_isd.vlrcsi.ValidateAllCsi(l_UserDlgId,GenProfile.l_ocsiPid,GenProfile.l_sscsiPid,GenProfile.l_tifcsiPid,GenProfile.l_dcsiPid,GenProfile.l_moscsiPid,GenProfile.l_vtcsiPid,GenProfile.l_mtscsiPid))
   {
      m_tdr.setString(TDR_INDEX_RESRV2,"CAP_PROFILE_NOT_LOADED");
      if(false == m_fIsd)
      {
         CLOG(0,0,"Validate CSI returned false. Sending System Failure");
         return 1;
      }
      else
      {
         CLOG(0,0,"Validate CSI returned false for FUPD .. ignoring");
      }
   }
   unsigned int l_GenOdb_DB = 0;

   ////// ADDED in 1.0.8.0 ////////
   l_GenOdb_DB = atoi(m_SubsData[22]);
   if(l_GenOdb_DB > 0)
      GenProfile.l_subsStatus = 1;
   ////// ENDED ADDED in 1.0.8.0  /////

   if(GenProfile.l_subsStatus == 1)
   {
      l_GenOdb_DB = atoi(m_SubsData[22]);
      //
      //Added in 1.0.8.0 for sending ALL_OG_CALLS_BARRED when OG_CALLS_BARRED_WHEN_ROAMING set and subsriber is in roaming
      //
      DLOG(0,0,"l_GenOdb_DB [%ld] OG_CALLS_BARRED_WHEN_ROAMING [%ld] l_roamInd [%ld]",
            l_GenOdb_DB,OG_CALLS_BARRED_WHEN_ROAMING,l_roamInd);
      if((l_GenOdb_DB & OG_CALLS_BARRED_WHEN_ROAMING) && (0 != l_roamInd))
      {
         LLOG(0,0,"Subscriber is in Roaming and OG_CALLS_BARRED_WHEN_ROAMING set, overriding with  ALL_OG_CALLS_BARRED");
         l_GenOdb_DB |= ALL_OG_CALLS_BARRED;
      }
      //
      //End Added in 1.0.8.0
      //
      l_GenOdb = l_GenOdb_DB & VLR_SUPPORTED_ODB;


      LLOG(0,0,"DBRES: General ODB data[%ld].. After conv to VLR specific[%ld]",l_GenOdb_DB,l_GenOdb);
      if(l_roamInd == 0)
      {
         unsigned int l_WrongHplmn = atoi(m_SubsData[23]);
         l_PlmnOdb = HplmnOdb(l_WrongHplmn);             
      }
      else
      {
         l_PlmnOdb = 0;
      }
      if((l_GenOdb == 0) && (l_PlmnOdb == 0))
      {
         GenProfile.l_subsStatus = 0;
         LLOG(0,0,"DBRES: General ODB data[%ld].. HPLMN Specific ODB Data[%ld] .. changing Subscriber Status to[%d]",
               l_GenOdb,l_PlmnOdb,GenProfile.l_subsStatus);
      }
   }
   else
   {           
      l_GenOdb = 0;         
      l_PlmnOdb = 0;
   }
   //
   //  Added in 1.0.8.0
   //
   if(l_GenOdb & ALL_OG_CALLS_BARRED)
   {
      DLOG(0,0,"Setting All OG calls barred present flag");
      m_isd.pss.m_AllOGCallsBarresPresent = true;
   }
   //
   // End Added in 1.0.8.0
   //


   DLOG(0,0," Generel ODB data %ld and HPLMN Specific ODB Data %ld",l_GenOdb,l_PlmnOdb);
   if(l_roamInd)
   {
      TLOG(0,0,"Subscriber is not in HPLMN area,ignoring traceflag");
   }
#if 1
   LLOG(0,0,"DBRES: SUBSCRIBER ACCOUNT AND PROFILE INFO : NAM[%d] Category[%d] SubscriptionRestriction[%d] AccessRestriction[%d] SubscriberStatus[%d] LMU[%d] IST[%d] BearerServiceList[%s] TeleServiceList[%s] OCSIProfileID[%d] VTCSIProfileId[%d] UGCSIProfileId[%d] SSCSIProfileID[%d] TIFCSIProfileID[%d]  DCSIProfileId[%d] MOSmsCsiProfileId[%d] MTSmsCsiProfileId[%d] GprsCsiProfileId[%d] MGCsiProfileId[%d]",
         GenProfile.l_nwAccMode,GenProfile.l_catgory,GenProfile.l_subsRest,GenProfile.l_accRest,GenProfile.l_subsStatus,GenProfile.l_lmu,GenProfile.l_ist,GenProfile.l_bearer,GenProfile.l_tele,GenProfile.l_ocsiPid,GenProfile.l_vtcsiPid,GenProfile.l_ugcsiPid,GenProfile.l_sscsiPid,GenProfile.l_tifcsiPid,GenProfile.l_dcsiPid,GenProfile.l_moscsiPid,GenProfile.l_mtscsiPid,GenProfile.l_gcsiPid,GenProfile.l_mgcsiPid);
   LLOG(0,0,"DBRES: EXISTING GSM PROFILE INFO: ActiveMsisdn[%s] ActiveIMSI[%s] LMSI[%s] VlrNumber[%s] MscNumber[%s] MSCAreaRestricted[%d] CheckSSIndicator[%d] MSPurgeNonGPRS[%d] MNRR[%d] MNRF[%d] MCEF[%d] RoamRestrdDueToUnsuppFeature[%d] ActiveHlrAddress[%s] ActivePartnerNkID[%d] TraceReqd[%d] TraceReference[%s] TraceType[%s] OMC_ID[%s] Trace_Status[%d] ExistingIMEISV[%s]",
         GsmProfile.l_ActMsisdn,GsmProfile.l_Actimsi,GsmProfile.l_lmsino,GsmProfile.l_vlrno,GsmProfile.l_Mscno,GsmProfile.l_mscRest,GsmProfile.l_ssInd,GsmProfile.l_msPur_gsm,GsmProfile.l_mnrr,GsmProfile.l_mnrf,GsmProfile.l_mcef,GsmProfile.l_roamrestduf,GsmProfile.l_ActHLRAddr,GsmProfile.l_ActPnwId,GsmProfile.l_TraceFlag,GsmProfile.l_TraceRef,GsmProfile.l_TraceType,GsmProfile.l_OmcId,GsmProfile.l_TraceStatus,GsmProfile.l_imeisv);
#endif   
   if(l_updv3.VlrCap_Phase == 0)
   {
      if(l_rsd->m_AssumeCap1Support)
      {
         LLOG(0,0,"DBRES: Assume CAMEL Phase 1 support indicator present .. Incoming UPD vlr cap phase 0");
         l_updv3.VlrCap_Camel1 = true;
         l_updv3.VlrCap_Phase = 1;
         l_updv3.VlrCap_camel[0] = '1';
         l_updv3.VlrCap_camel[1] = '0';l_updv3.VlrCap_camel[2] = '0';l_updv3.VlrCap_camel[3] = '0';
      }
      else
      {
         LLOG(0,0,"DBRES: Assume CAMEL Phase 1 support indicator not present .. Incoming UPD vlr cap phase 0");
      }
   }

   setTraceMsisdn((char *)l_actMsisdn);
   m_tdr.setString(TDR_INDEX_REQUEST_MSISDN,(char*)l_actMsisdn);
   TLOG(0,0,"Trace enabled on MSISDN %s",(char *)l_actMsisdn);


   //EMLPP Info
   {
      m_isd.pss.ESsCode = 0;
      m_isd.pss.EDefaultPriority = 0;m_isd.pss.EDefaultPriority = 0; m_isd.pss.EMaxPriority = 0;
      //DLOG(0,0,"EMLPP Data  : %s\n",l_rsd->m_EmlppData);
      char EMLPP[50];
      memset(EMLPP,'\0',sizeof(EMLPP));
      strncat(EMLPP,"|",1);
      strncat(EMLPP,(char *)l_rsd->m_EmlppData,strlen((char *)l_rsd->m_EmlppData));
      strncat(EMLPP,"|",1);
      //DLOG(0,0,"String to test %s\n",EMLPP);
      char str7[5][20];
      memset(str7,'\0',sizeof(str7));
      tokenize(EMLPP,(char*)str7, 20);
      m_isd.pss.ESsCode = 161;
      m_isd.pss.ESsStatus = atoi(str7[1]);
      m_isd.pss.EDefaultPriority = atoi(str7[2]);
      m_isd.pss.EMaxPriority = atoi(str7[3]);
      if(m_isd.pss.ESsStatus)
      {
         DLOG(0,0,"EMLPP :- SSCODE = %d , SS_Status = %d Default Priority = %d Max Entitiled priority = %d",m_isd.pss.ESsCode,m_isd.pss.ESsStatus,m_isd.pss.EDefaultPriority,m_isd.pss.EMaxPriority);
      }
      else
      {
         DLOG(0,0,"No EMLPP data available");
      }
   }

   //MC_SS Info
   {
      m_isd.pss.mcSsCode = 0;
      m_isd.pss.MCSsStatus = 0; m_isd.pss.NBR_SB = 0; m_isd.pss.NBR_USER  = 0;
      //DLOG(0,0,"MC SS Data  : %s\n",l_rsd->m_MCData);
      char McSs[50];
      memset(McSs,'\0',sizeof(McSs));
      strncat(McSs,"|",1);
      strncat(McSs,(char *)l_rsd->m_MCData,strlen((char *)l_rsd->m_MCData));
      strncat(McSs,"|",1);
      //DLOG(0,0,"String to test %s\n",McSs);
      char str8[5][20];
      memset(str8,'\0',sizeof(str8));
      tokenize(McSs, (char*)str8, 20);
      m_isd.pss.mcSsCode = 69;
      m_isd.pss.MCSsStatus = atoi(str8[1]);
      m_isd.pss.NBR_SB = atoi(str8[2]);
      m_isd.pss.NBR_USER = atoi(str8[3]);
      if((m_isd.pss.MCSsStatus == 6) || (m_isd.pss.MCSsStatus == 7) || (m_isd.pss.MCSsStatus == 4))
      {
         DLOG(0,0,"MC_SS_INFO :- SSCODE = %d , SS_Status = %d NBR_SB = %d NBR_USER = %d",m_isd.pss.mcSsCode,m_isd.pss.MCSsStatus,m_isd.pss.NBR_SB,m_isd.pss.NBR_USER);
      }
      else
      {    
         m_isd.pss.mcSsCode = 0;
         DLOG(0,0,"No MC SS INFO present");
      }
   }


#if 1   //GEN SS DATA Inside this
   {
      m_isd.pss.SsCount = 0;
      //LineIdentification DATA
      for(int li = 0;li<l_rsd->m_LiCount;li++)
      {
         //DLOG(0,0,"Line Identification Data[%d]             : %s\n",li,l_rsd->m_LiData[li]);
         char LID[50];
         memset(LID,'\0',sizeof(LID));
         strncat(LID,"|",1);
         strncat(LID,(char *)l_rsd->m_LiData[li],strlen((char *)l_rsd->m_LiData[li]));
         strncat(LID,"|",1);
         //DLOG(0,0,"String to test in CWD %s\n",LID[li]);
         char str4[30][30];
         memset(str4,'\0',sizeof(str4));
         tokenize(LID, (char*)str4, 30);
         //DLOG(0,0,"STR 1 %d and STR 2 %d\n",atoi(str4[1]),atoi(str4[2]));
         if(atoi(str4[1]) == 17)
         {
            m_isd.pss.SsCode[m_isd.pss.SsCount] = 17;//atoi(str4[1]);
            m_isd.pss.SsStatus[m_isd.pss.SsCount] = atoi(str4[2]);
            m_isd.pss.SsBCode[m_isd.pss.SsCount] = 0;//atoi(str4[3]+1);
            m_isd.pss.SsBType[m_isd.pss.SsCount] = 0;//atoi(str4[4]+1);
            m_isd.pss.SsSubsRest[m_isd.pss.SsCount] = 2;//atoi(str4[5]+1);
            m_isd.pss.SsCLIOptn[m_isd.pss.SsCount] = 0;//atoi(str4[6]+1);
            if(atoi(str4[7]))
            {
               m_isd.pss.SsOverRide[m_isd.pss.SsCount] = atoi(str4[7]);
            }
            else
            {
               m_isd.pss.SsOverRide[m_isd.pss.SsCount] = 0;
            }
            DLOG(0,0,"Line Identification CLIP :- SSCODE[%d] = %d , SS_Status[%d] = %d SS_BCode[%d] = %d SS_BTYPE[%d] = %d Subscription restrction[%d] = %d CLI_Option[%d] = %d OVERRide_Category[%d] = %d",m_isd.pss.SsCount,m_isd.pss.SsCode[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsStatus[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsBCode[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsBType[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsSubsRest[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsCLIOptn[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsOverRide[m_isd.pss.SsCount]);
            m_isd.pss.SsCount += 1;
         }
         if(atoi(str4[1]) == 18)
         {
            m_isd.pss.SsCode[m_isd.pss.SsCount] = 18;//atoi(str4[1]);
            m_isd.pss.SsStatus[m_isd.pss.SsCount] = atoi(str4[2]);
            m_isd.pss.SsBCode[m_isd.pss.SsCount] = 0;//atoi(str4[3]+1);
            m_isd.pss.SsBType[m_isd.pss.SsCount] = 0;//atoi(str4[4]+1);
            m_isd.pss.SsSubsRest[m_isd.pss.SsCount] = 1;//atoi(str4[5]+1);
            if(atoi(str4[6]))
            {
               m_isd.pss.SsCLIOptn[m_isd.pss.SsCount] = atoi(str4[6]);
            }
            else
            {
               m_isd.pss.SsCLIOptn[m_isd.pss.SsCount] = 0;
            }
            m_isd.pss.SsOverRide[m_isd.pss.SsCount] = 0;//atoi(str4[7]+1);
            DLOG(0,0,"Line Identification CLIR :- SSCODE[%d] = %d , SS_Status[%d] = %d SS_BCode[%d] = %d SS_BTYPE[%d] = %d Subscription restrction[%d] = %d CLI_Option[%d] = %d OVERRide_Category[%d] = %d",m_isd.pss.SsCount,m_isd.pss.SsCode[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsStatus[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsBCode[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsBType[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsSubsRest[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsCLIOptn[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsOverRide[m_isd.pss.SsCount]);
            m_isd.pss.SsCount += 1;
         }
         if(atoi(str4[1]) == 19)
         {
            m_isd.pss.SsCode[m_isd.pss.SsCount] = 19;//atoi(str4[1]);
            m_isd.pss.SsStatus[m_isd.pss.SsCount] = atoi(str4[2]);
            m_isd.pss.SsBCode[m_isd.pss.SsCount] = 0;//atoi(str4[3]);
            m_isd.pss.SsBType[m_isd.pss.SsCount] = 0;//atoi(str4[4]);
            m_isd.pss.SsSubsRest[m_isd.pss.SsCount] = 2;//atoi(str4[5]);
            m_isd.pss.SsCLIOptn[m_isd.pss.SsCount] = 0;//atoi(str4[6]);
            if(atoi(str4[7]))
            {
               m_isd.pss.SsOverRide[m_isd.pss.SsCount] = atoi(str4[7]);
            }
            else
            {
               m_isd.pss.SsOverRide[m_isd.pss.SsCount] = 0;
            }
            DLOG(0,0,"Line Identification COLP :- SSCODE[%d] = %d , SS_Status[%d] = %d SS_BCode[%d] = %d SS_BTYPE[%d] = %d Subscription restrction[%d] = %d CLI_Option[%d] = %d OVERRide_Category[%d] = %d",m_isd.pss.SsCount,m_isd.pss.SsCode[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsStatus[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsBCode[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsBType[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsSubsRest[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsCLIOptn[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsOverRide[m_isd.pss.SsCount]);
            m_isd.pss.SsCount += 1;
         }
         if(atoi(str4[1]) == 20)
         {
            m_isd.pss.SsCode[m_isd.pss.SsCount] = 20;//atoi(str4[1]);
            m_isd.pss.SsStatus[m_isd.pss.SsCount] = atoi(str4[2]);
            m_isd.pss.SsBCode[m_isd.pss.SsCount] = 0;//atoi(str4[3]);
            m_isd.pss.SsBType[m_isd.pss.SsCount] = 0;//atoi(str4[4]);
            m_isd.pss.SsSubsRest[m_isd.pss.SsCount] = 0;//atoi(str4[5]);
            m_isd.pss.SsCLIOptn[m_isd.pss.SsCount] = 0;//atoi(str4[6]);
            m_isd.pss.SsOverRide[m_isd.pss.SsCount] = 0;//atoi(str4[7]);
            DLOG(0,0,"Line Identification COLR :- SSCODE[%d] = %d , SS_Status[%d] = %d SS_BCode[%d] = %d SS_BTYPE[%d] = %d Subscription restrction[%d] = %d CLI_Option[%d] = %d OVERRide_Category[%d] = %d",m_isd.pss.SsCount,m_isd.pss.SsCode[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsStatus[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsBCode[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsBType[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsSubsRest[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsCLIOptn[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsOverRide[m_isd.pss.SsCount]);
            m_isd.pss.SsCount += 1;
         }
      }

      //Call Waiting DATA
      for(int cw = 0;cw<l_rsd->m_CWCount;cw++)
      {
         DLOG(0,0,"Call Waiting Data[%d]             : %s",cw,l_rsd->m_CWData[cw]);
         char CWD[75];
         memset(CWD,'\0',sizeof(CWD));
         strncat(CWD,"|",1);
         strncat(CWD,(char *)l_rsd->m_CWData[cw],strlen((char *)l_rsd->m_CWData[cw]));
         strncat(CWD,"|",1);
         //DLOG(0,0,"String to test in CWD %s\n",CWD[cw]);
         char str3[30][35];
         memset(str3,'\0',sizeof(str3));
         tokenize(CWD, (char*)str3, 35);
         //DLOG(0,0,"STR 1 %d and STR 2 %d\n",atoi(str3[1]),atoi(str3[2]));
         DLOG(0,0,"SS Count in CW is %d",m_isd.pss.SsCount);
         m_isd.pss.SsCode[m_isd.pss.SsCount] = 65;
         m_isd.pss.SsStatus[m_isd.pss.SsCount] = atoi(str3[1]);
         m_isd.pss.SsBCode[m_isd.pss.SsCount] = atoi(str3[2]);
         m_isd.pss.SsBType[m_isd.pss.SsCount] = atoi(str3[3]);
         m_isd.pss.SsSubsRest[m_isd.pss.SsCount] = 0;
         m_isd.pss.SsCLIOptn[m_isd.pss.SsCount] = 0;
         m_isd.pss.SsOverRide[m_isd.pss.SsCount] = 0;
         DLOG(0,0,"Call Waiting :- SSCODE[%d] = %d , SS_Status[%d] = %d SS_BCode[%d] = %d SS_BTYPE[%d] = %d",m_isd.pss.SsCount,m_isd.pss.SsCode[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsStatus[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsBCode[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsBType[m_isd.pss.SsCount]);
         m_isd.pss.SsCount += 1;
      }

      //SUBS_SS_INFO
      DLOG(0,0,"SS Data count received is %d",l_rsd->m_ssCount);
      for(int ss = 0;ss<l_rsd->m_ssCount;ss++)
      {
         //DLOG(0,0,"\nSS Data[%d]             : %s\n",ss,l_rsd->m_SSDATA[ss]);
         char SSD[30];
         memset(SSD,'\0',sizeof(SSD));
         strncat(SSD,"|",1);
         strncat(SSD,(char *)l_rsd->m_SSDATA[ss],strlen((char *)l_rsd->m_SSDATA[ss]));
         strncat(SSD,"|",1);
         //DLOG(0,0,"String to test[%d]] %s\n",ss,SSD);
         char str1[30][35];
         memset(str1,'\0',sizeof(str1));
         tokenize(SSD, (char*)str1, 35);
         //DLOG(0,0,"STR 1 %d and STR 2 %d\n",atoi(str1[1]),atoi(str1[2]));
         m_isd.pss.SsCode[m_isd.pss.SsCount] = atoi(str1[1]);
         m_isd.pss.SsStatus[m_isd.pss.SsCount] = atoi(str1[2]);
         m_isd.pss.SsBCode[m_isd.pss.SsCount] = 0;
         m_isd.pss.SsBType[m_isd.pss.SsCount] = 0;
         m_isd.pss.SsSubsRest[m_isd.pss.SsCount] = 0;
         m_isd.pss.SsCLIOptn[m_isd.pss.SsCount] = 0;
         m_isd.pss.SsOverRide[m_isd.pss.SsCount] = 0;
         DLOG(0,0,"SUBS_SS_DATA :- SSCODE[%d] = %d , SS_Status[%d] = %d",ss,m_isd.pss.SsCode[ss],ss,m_isd.pss.SsStatus[ss]);
         m_isd.pss.SsCount += 1;
      }

   }
#endif


#if 1 // Call Forward SS inside this
   {
      //Initializing All CFWD related arrays sizes
      m_isd.pss.cfuSsCount = 0;   m_isd.pss.cfuSsCode = 0;
      m_isd.pss.cdSsCount = 0;    m_isd.pss.cdSsCode = 0;
      m_isd.pss.cfbSsCount = 0;   m_isd.pss.cfbSsCode = 0;
      m_isd.pss.cfnrySsCount = 0; m_isd.pss.cfnrySsCode = 0;
      m_isd.pss.cfnrcSsCount = 0; m_isd.pss.cfnrcSsCode = 0;

      //Call FWD DATA
      char str5[40][202];
      for(int all = 0;all<l_rsd->m_CFCount;all++)
      {
         //DLOG(0,0,"\n\n\nCall Fwd Data[%d]             : %s\n",all,l_rsd->m_CFData[all]);
         char CFD[202];
         memset(CFD,'\0',sizeof(CFD));
         strncat(CFD,"|",1);
         strncat(CFD,(char *)l_rsd->m_CFData[all],strlen((char *)l_rsd->m_CFData[all]));
         strncat(CFD,"|",1);
         memset(str5,'\0',sizeof(str5));
         //DLOG(0,0,"String to test %s\n",CFD[all]);         
         tokenize(CFD, (char*)str5, 202);
         //CFWD Unconditional DATA
         if(atoi(str5[1]) == 33)
         {
            m_isd.pss.cfuSsCode = 33;
            m_isd.pss.cfuSsStatus[m_isd.pss.cfuSsCount] = atoi(str5[2]);
            m_isd.pss.cfuBCode[m_isd.pss.cfuSsCount] = atoi(str5[3]);
            m_isd.pss.cfuBType[m_isd.pss.cfuSsCount] = atoi(str5[4]);
            strncpy((char *)m_isd.pss.cfuFTN[m_isd.pss.cfuSsCount],str5[5],strlen(str5[5]));
            strncpy((char *)m_isd.pss.cfuFTS[m_isd.pss.cfuSsCount],str5[6],strlen(str5[6]));
            m_isd.pss.cfuOPTN[m_isd.pss.cfuSsCount] = atoi(str5[7]);
            m_isd.pss.cfuNRT[m_isd.pss.cfuSsCount] = atoi(str5[8]);
            strncpy((char *)m_isd.pss.cfuLFTN[m_isd.pss.cfuSsCount],str5[9],strlen(str5[9]));
            if((m_isd.pss.cfuSsStatus[m_isd.pss.cfuSsCount] > 4)&&(strcmp((char *)m_isd.pss.cfuFTN[m_isd.pss.cfuSsCount],"0") == 0))
            {
               strncpy((char *)m_isd.pss.cfuFTN[m_isd.pss.cfuSsCount],str5[10],strlen(str5[10]));
               DLOG(0,0,"CFU FTN number not present, Getting Default FTN %s",m_isd.pss.cfuFTN[m_isd.pss.cfuSsCount]);              
            }            
            //DLOG(0,0,"All Unconditional forwarding SS Count = %d\n",m_isd.pss.cfuSsCount);
            DLOG(0,0,"Call FWD Unconditional :- SSCODE[%d] = %d, SS_Status[%d] = %d, Basic Service Code[%d] = %d,Basic Service Type[%d] = %d, Fwd_To_Number[%d] = %s,Fwd_To_SubAddr[%d] = %s Fwd_Optn[%d] = %d, No_Reply_Time[%d] = %d, Long_FTN[%d] = %s",
                  m_isd.pss.cfuSsCount,m_isd.pss.cfuSsCode,m_isd.pss.cfuSsCount,m_isd.pss.cfuSsStatus[m_isd.pss.cfuSsCount],m_isd.pss.cfuSsCount,m_isd.pss.cfuBCode[m_isd.pss.cfuSsCount],m_isd.pss.cfuSsCount,m_isd.pss.cfuBType[m_isd.pss.cfuSsCount],m_isd.pss.cfuSsCount,m_isd.pss.cfuFTN[m_isd.pss.cfuSsCount],m_isd.pss.cfuSsCount,m_isd.pss.cfuFTS[m_isd.pss.cfuSsCount],m_isd.pss.cfuSsCount,m_isd.pss.cfuOPTN[m_isd.pss.cfuSsCount],m_isd.pss.cfuSsCount,m_isd.pss.cfuNRT[m_isd.pss.cfuSsCount],m_isd.pss.cfuSsCount,m_isd.pss.cfuLFTN[m_isd.pss.cfuSsCount]);
            m_isd.pss.cfuSsCount += 1;
         }
         //Call Deflection
         if(atoi(str5[1]) == 36)
         {
            m_isd.pss.cdSsCode = 36;
            m_isd.pss.cdSsStatus[m_isd.pss.cdSsCount] = atoi(str5[2]);
            m_isd.pss.cdBCode[m_isd.pss.cdSsCount] = atoi(str5[3]);
            m_isd.pss.cdBType[m_isd.pss.cdSsCount] = atoi(str5[4]);
            strncpy((char *)m_isd.pss.cdFTN[m_isd.pss.cdSsCount],str5[5],strlen(str5[5]));
            strncpy((char *)m_isd.pss.cdFTS[m_isd.pss.cdSsCount],str5[6],strlen(str5[6]));
            m_isd.pss.cdOPTN[m_isd.pss.cdSsCount] = atoi(str5[7]);
            m_isd.pss.cdNRT[m_isd.pss.cdSsCount] = atoi(str5[8]);
            strncpy((char *)m_isd.pss.cdLFTN[m_isd.pss.cdSsCount],str5[9],strlen(str5[9]));
            if((m_isd.pss.cdSsStatus[m_isd.pss.cdSsCount] > 4)&&(strcmp((char *)m_isd.pss.cdFTN[m_isd.pss.cdSsCount],"0") == 0))
            {
               strncpy((char *)m_isd.pss.cdFTN[m_isd.pss.cdSsCount],str5[10],strlen(str5[10]));
               DLOG(0,0,"CD FTN number not present, Getting Default FTN %s",m_isd.pss.cdFTN[m_isd.pss.cdSsCount]);              
            }
            //DLOG(0,0,"Call Deflection Count = %d\n",m_isd.pss.cdSsCount);
            DLOG(0,0,"Call Deflection :- SSCODE[%d] = %d, SS_Status[%d] = %d, Basic Service Code[%d] = %d,Basic Service Type[%d] = %d, Fwd_To_Number[%d] = %s,Fwd_To_SubAddr[%d] = %s Fwd_Optn[%d] = %d, No_Reply_Time[%d] = %d, Long_FTN[%d] = %s",
                  m_isd.pss.cdSsCount,m_isd.pss.cdSsCode,m_isd.pss.cdSsCount,m_isd.pss.cdSsStatus[m_isd.pss.cdSsCount],m_isd.pss.cdSsCount,m_isd.pss.cdBCode[m_isd.pss.cdSsCount],m_isd.pss.cdSsCount,m_isd.pss.cdBType[m_isd.pss.cdSsCount],m_isd.pss.cdSsCount,m_isd.pss.cdFTN[m_isd.pss.cdSsCount],m_isd.pss.cdSsCount,m_isd.pss.cdFTS[m_isd.pss.cdSsCount],m_isd.pss.cdSsCount,m_isd.pss.cdOPTN[m_isd.pss.cdSsCount],m_isd.pss.cdSsCount,m_isd.pss.cdNRT[m_isd.pss.cdSsCount],m_isd.pss.cdSsCount,m_isd.pss.cdLFTN[m_isd.pss.cdSsCount]);
            m_isd.pss.cdSsCount += 1;
         }         
         //call forwarding on mobile subscriber busy
         if(atoi(str5[1]) == 41)
         {
            m_isd.pss.cfbSsCode = 41;
            m_isd.pss.cfbSsStatus[m_isd.pss.cfbSsCount] = atoi(str5[2]);
            m_isd.pss.cfbBCode[m_isd.pss.cfbSsCount] = atoi(str5[3]);
            m_isd.pss.cfbBType[m_isd.pss.cfbSsCount] = atoi(str5[4]);
            strncpy((char *)m_isd.pss.cfbFTN[m_isd.pss.cfbSsCount],str5[5],strlen(str5[5]));
            strncpy((char *)m_isd.pss.cfbFTS[m_isd.pss.cfbSsCount],str5[6],strlen(str5[6]));
            m_isd.pss.cfbOPTN[m_isd.pss.cfbSsCount] = atoi(str5[7]);
            m_isd.pss.cfbNRT[m_isd.pss.cfbSsCount] = atoi(str5[8]);
            strncpy((char *)m_isd.pss.cfbLFTN[m_isd.pss.cfbSsCount],str5[9],strlen(str5[9]));
            if((m_isd.pss.cfbSsStatus[m_isd.pss.cfbSsCount] > 4)&&(strcmp((char *)m_isd.pss.cfbFTN[m_isd.pss.cfbSsCount],"0") == 0))
            {
               strncpy((char *)m_isd.pss.cfbFTN[m_isd.pss.cfbSsCount],str5[10],strlen(str5[10]));
               DLOG(0,0,"CFB FTN number not present, Getting Default FTN %s",m_isd.pss.cfbFTN[m_isd.pss.cfbSsCount]);              
            }
            //DLOG(0,0,"Call Fwd on Busy count = %d\n",m_isd.pss.cfbSsCount);
            DLOG(0,0,"Call FWD Busy :- SSCODE[%d] = %d, SS_Status[%d] = %d, Basic Service Code[%d] = %d,Basic Service Type[%d] = %d, Fwd_To_Number[%d] = %s,Fwd_To_SubAddr[%d] = %s Fwd_Optn[%d] = %d, No_Reply_Time[%d] = %d, Long_FTN[%d] = %s",
                  m_isd.pss.cfbSsCount,m_isd.pss.cfbSsCode,m_isd.pss.cfbSsCount,m_isd.pss.cfbSsStatus[m_isd.pss.cfbSsCount],m_isd.pss.cfbSsCount,m_isd.pss.cfbBCode[m_isd.pss.cfbSsCount],m_isd.pss.cfbSsCount,m_isd.pss.cfbBType[m_isd.pss.cfbSsCount],m_isd.pss.cfbSsCount,m_isd.pss.cfbFTN[m_isd.pss.cfbSsCount],m_isd.pss.cfbSsCount,m_isd.pss.cfbFTS[m_isd.pss.cfbSsCount],m_isd.pss.cfbSsCount,m_isd.pss.cfbOPTN[m_isd.pss.cfbSsCount],m_isd.pss.cfbSsCount,m_isd.pss.cfbNRT[m_isd.pss.cfbSsCount],m_isd.pss.cfbSsCount,m_isd.pss.cfbLFTN[m_isd.pss.cfbSsCount]);
            m_isd.pss.cfbSsCount += 1;
         }
         //call forwarding on no reply
         if(atoi(str5[1]) == 42)
         {
            m_isd.pss.cfnrySsCode = 42;
            m_isd.pss.cfnrySsStatus[m_isd.pss.cfnrySsCount] = atoi(str5[2]);
            m_isd.pss.cfnryBCode[m_isd.pss.cfnrySsCount] = atoi(str5[3]);
            m_isd.pss.cfnryBType[m_isd.pss.cfnrySsCount] = atoi(str5[4]);
            strncpy((char *)m_isd.pss.cfnryFTN[m_isd.pss.cfnrySsCount],str5[5],strlen(str5[5]));
            strncpy((char *)m_isd.pss.cfnryFTS[m_isd.pss.cfnrySsCount],str5[6],strlen(str5[6]));
            m_isd.pss.cfnryOPTN[m_isd.pss.cfnrySsCount] = atoi(str5[7]);
            m_isd.pss.cfnryNRT[m_isd.pss.cfnrySsCount] = atoi(str5[8]);
            strncpy((char *)m_isd.pss.cfnryLFTN[m_isd.pss.cfnrySsCount],str5[9],strlen(str5[9]));
            if((m_isd.pss.cfnrySsStatus[m_isd.pss.cfnrySsCount] > 4)&&(strcmp((char *)m_isd.pss.cfnryFTN[m_isd.pss.cfnrySsCount],"0") == 0))
            {
               strncpy((char *)m_isd.pss.cfnryFTN[m_isd.pss.cfnrySsCount],str5[10],strlen(str5[10]));
               DLOG(0,0,"CFNRY FTN number not present, Getting Default FTN %s",m_isd.pss.cfnryFTN[m_isd.pss.cfnrySsCount]);              
            }
            //DLOG(0,0,"Call Fwd on no Reply Count = %d\n",m_isd.pss.cfnrySsCount);
            DLOG(0,0,"Call FWD No Reply :- SSCODE[%d] = %d, SS_Status[%d] = %d, Basic Service Code[%d] = %d,Basic Service Type[%d] = %d, Fwd_To_Number[%d] = %s,Fwd_To_SubAddr[%d] = %s Fwd_Optn[%d] = %d, No_Reply_Time[%d] = %d, Long_FTN[%d] = %s",
                  m_isd.pss.cfnrySsCount,m_isd.pss.cfnrySsCode,m_isd.pss.cfnrySsCount,m_isd.pss.cfnrySsStatus[m_isd.pss.cfnrySsCount],m_isd.pss.cfnrySsCount,m_isd.pss.cfnryBCode[m_isd.pss.cfnrySsCount],m_isd.pss.cfnrySsCount,m_isd.pss.cfnryBType[m_isd.pss.cfnrySsCount],m_isd.pss.cfnrySsCount,m_isd.pss.cfnryFTN[m_isd.pss.cfnrySsCount],m_isd.pss.cfnrySsCount,m_isd.pss.cfnryFTS[m_isd.pss.cfnrySsCount],m_isd.pss.cfnrySsCount,m_isd.pss.cfnryOPTN[m_isd.pss.cfnrySsCount],m_isd.pss.cfnrySsCount,m_isd.pss.cfnryNRT[m_isd.pss.cfnrySsCount],m_isd.pss.cfnrySsCount,m_isd.pss.cfnryLFTN[m_isd.pss.cfnrySsCount]);
            m_isd.pss.cfnrySsCount += 1;
         }
         //call forwarding on mobile subscriber not reachable
         if(atoi(str5[1]) == 43)
         {
            m_isd.pss.cfnrcSsCode = 43;
            m_isd.pss.cfnrcSsStatus[m_isd.pss.cfnrcSsCount] = atoi(str5[2]);
            m_isd.pss.cfnrcBCode[m_isd.pss.cfnrcSsCount] = atoi(str5[3]);
            m_isd.pss.cfnrcBType[m_isd.pss.cfnrcSsCount] = atoi(str5[4]);
            strncpy((char *)m_isd.pss.cfnrcFTN[m_isd.pss.cfnrcSsCount],str5[5],strlen(str5[5]));
            strncpy((char *)m_isd.pss.cfnrcFTS[m_isd.pss.cfnrcSsCount],str5[6],strlen(str5[6]));
            m_isd.pss.cfnrcOPTN[m_isd.pss.cfnrcSsCount] = atoi(str5[7]);
            m_isd.pss.cfnrcNRT[m_isd.pss.cfnrcSsCount] = atoi(str5[8]);
            strncpy((char *)m_isd.pss.cfnrcLFTN[m_isd.pss.cfnrcSsCount],str5[9],strlen(str5[9]));
            if((m_isd.pss.cfnrcSsStatus[m_isd.pss.cfnrcSsCount]> 4)&&(strcmp((char *)m_isd.pss.cfnrcFTN[m_isd.pss.cfnrcSsCount],"0") == 0))
            {
               strncpy((char *)m_isd.pss.cfnrcFTN[m_isd.pss.cfnrcSsCount],str5[10],strlen(str5[10]));
               DLOG(0,0,"CFNRC FTN number not present, Getting Default FTN %s",m_isd.pss.cfnrcFTN[m_isd.pss.cfnrcSsCount]);              
            }
            //DLOG(0,0,"Call FWD on not rechable Count = %d\n",m_isd.pss.cfnrcSsCount);
            DLOG(0,0,"Call FWD NRC :- SSCODE[%d] = %d, SS_Status[%d] = %d, Basic Service Code[%d] = %d,Basic Service Type[%d] = %d, Fwd_To_Number[%d] = %s,Fwd_To_SubAddr[%d] = %s Fwd_Optn[%d] = %d, No_Reply_Time[%d] = %d, Long_FTN[%d] = %s",
                  m_isd.pss.cfnrcSsCount,m_isd.pss.cfnrcSsCode,m_isd.pss.cfnrcSsCount,m_isd.pss.cfnrcSsStatus[m_isd.pss.cfnrcSsCount],m_isd.pss.cfnrcSsCount,m_isd.pss.cfnrcBCode[m_isd.pss.cfnrcSsCount],m_isd.pss.cfnrcSsCount,m_isd.pss.cfnrcBType[m_isd.pss.cfnrcSsCount],m_isd.pss.cfnrcSsCount,m_isd.pss.cfnrcFTN[m_isd.pss.cfnrcSsCount],m_isd.pss.cfnrcSsCount,m_isd.pss.cfnrcFTS[m_isd.pss.cfnrcSsCount],m_isd.pss.cfnrcSsCount,m_isd.pss.cfnrcOPTN[m_isd.pss.cfnrcSsCount],m_isd.pss.cfnrcSsCount,m_isd.pss.cfnrcNRT[m_isd.pss.cfnrcSsCount],m_isd.pss.cfnrcSsCount,m_isd.pss.cfnrcLFTN[m_isd.pss.cfnrcSsCount]);
            m_isd.pss.cfnrcSsCount += 1;
         }
      }
      //DLOG(0,0,"All Call Fowarding data Count = %d\n",m_isd.pss.allSsCount);
      DLOG(0,0,"Call Fwd Unconditional SS Count = %d",m_isd.pss.cfuSsCount);
      DLOG(0,0,"Call Deflection Count = %d",m_isd.pss.cdSsCount);
      //DLOG(0,0,"All Conditional fWD count = %d\n",m_isd.pss.acfSsCount);
      DLOG(0,0,"Call Fwd on Busy count = %d",m_isd.pss.cfbSsCount);
      DLOG(0,0,"Call Fwd on no Reply Count = %d",m_isd.pss.cfnrySsCount);
      DLOG(0,0,"Call FWD on not rechable Count = %d",m_isd.pss.cfnrcSsCount);


      /////////////////////////// MEXICO CHANGES BEGIN 6100///////////////
      map<int, HlrNetworks* > :: iterator l_HlrNetworksDetailsIter;
      l_HlrNetworksDetailsIter = g_spdPtr->m_HlrNetworks.find(l_nwId);
      if(l_HlrNetworksDetailsIter != g_spdPtr->m_HlrNetworks.end())
      {
         TLOG(0,0,"NetworkId[%d] present in HlrNetworks Map, checking for DisableFwdInfoInIsdSri Value",l_nwId);
         if(1 ==(l_HlrNetworksDetailsIter->second)->m_DisableFwdInfoInIsdSri)
         {
            LLOG(0,0,"DisableFwdInfoInIsdSri|%d| is Enabled, Unsetting the FWD info",(l_HlrNetworksDetailsIter->second)->m_DisableFwdInfoInIsdSri);
            m_isd.pss.cfuSsCount = 0;   m_isd.pss.cfuSsCode = 0;
            m_isd.pss.cdSsCount = 0;    m_isd.pss.cdSsCode = 0;
            m_isd.pss.cfbSsCount = 0;   m_isd.pss.cfbSsCode = 0;
            m_isd.pss.cfnrySsCount = 0; m_isd.pss.cfnrySsCode = 0;
            m_isd.pss.cfnrcSsCount = 0; m_isd.pss.cfnrcSsCode = 0;
         }
         else
         {
            LLOG(0,0,"DisableFwdInfoInIsdSri|%d| is Disabled, Sending the FWD info in ISD",(l_HlrNetworksDetailsIter->second)->m_DisableFwdInfoInIsdSri);
         }
      }
      else
      {
         TLOG(0,0,"NetworkId[%d]not present in HlrNetworks Map, Not checking DisableFwdInfoInIsdSri Value, Sending FWD info in ISD",l_nwId);
      }
      /////////////////////////// MEXICO CHANGES END ///////////////
   }
#endif


#if 1//Call Barring SS DATA
   {
      //Initializing all Counts      
      m_isd.pss.boacCount = 0;  m_isd.pss.boacSsCode = 0;
      m_isd.pss.boicCount = 0;  m_isd.pss.boicSsCode = 0;
      m_isd.pss.boihcCount = 0; m_isd.pss.boihcSsCode = 0;
      m_isd.pss.baicCount = 0;  m_isd.pss.baicSsCode = 0;
      m_isd.pss.bicrCount = 0;  m_isd.pss.bicrSsCode = 0;
      char str13[100][100];
      for(int acb = 0;acb<l_rsd->m_CBCount;acb++)
      {
         //DLOG(0,0,"\n\n\nAll Call Barring Data[%d]             : %s\n",acb,l_rsd->m_CBData[acb]);
         memset(str13,'\0',sizeof(str13));
         char ACB[100];
         memset(ACB,'\0',sizeof(ACB));
         strncat(ACB,"|",1);
         strncat(ACB,(char *)l_rsd->m_CBData[acb],strlen((char *)l_rsd->m_CBData[acb]));
         strncat(ACB,"|",1);
         //DLOG(0,0,"String to test %s\n",ACB[acb]);
         tokenize(ACB, (char*)str13, 100);
         //Barring of All Outgoing Call
         if(atoi(str13[1]) == 146)
         {
            m_isd.pss.boacSsCode = 146;            
            m_isd.pss.boacSsStatus[m_isd.pss.boacCount] = atoi(str13[2]);
            m_isd.pss.boacBCode[m_isd.pss.boacCount] = atoi(str13[3]);
            m_isd.pss.boacBType[m_isd.pss.boacCount] = atoi(str13[4]);
            DLOG(0,0,"Call Barring (Barring of All Outgoing Calls):- SSCODE[%d] = %d, SS_Status[%d] = %d, Basic Service Code[%d] = %d,Basic Service Type[%d] = %d",
                  m_isd.pss.boacCount,m_isd.pss.boacSsCode,m_isd.pss.boacCount,m_isd.pss.boacSsStatus[m_isd.pss.boacCount],m_isd.pss.boacCount,m_isd.pss.boacBCode[m_isd.pss.boacCount],m_isd.pss.boacCount,m_isd.pss.boacBType[m_isd.pss.boacCount]);
            m_isd.pss.boacCount += 1;
         }
         //barring of All Outgoing International calls
         if(atoi(str13[1]) == 147)
         {
            m_isd.pss.boicSsCode = 147;            
            m_isd.pss.boicSsStatus[m_isd.pss.boicCount] = atoi(str13[2]);
            m_isd.pss.boicBCode[m_isd.pss.boicCount] = atoi(str13[3]);
            m_isd.pss.boicBType[m_isd.pss.boicCount] = atoi(str13[4]);
            DLOG(0,0,"Call Barring (Barring of Outgoing Int. Calls) :- SSCODE[%d] = %d, SS_Status[%d] = %d, Basic Service Code[%d] = %d,Basic Service Type[%d] = %d",
                  m_isd.pss.boicCount,m_isd.pss.boicSsCode,m_isd.pss.boicCount,m_isd.pss.boicSsStatus[m_isd.pss.boicCount],m_isd.pss.boicCount,m_isd.pss.boicBCode[m_isd.pss.boicCount],m_isd.pss.boicCount,m_isd.pss.boicBType[m_isd.pss.boicCount]);
            m_isd.pss.boicCount += 1;
         }
         //Barring of Internation outgoing calls except for HPLMN country
         if(atoi(str13[1]) == 148)
         {
            m_isd.pss.boihcSsCode = 148;            
            m_isd.pss.boihcSsStatus[m_isd.pss.boihcCount] = atoi(str13[2]);
            m_isd.pss.boihcBCode[m_isd.pss.boihcCount] = atoi(str13[3]);
            m_isd.pss.boihcBType[m_isd.pss.boihcCount] = atoi(str13[4]);
            DLOG(0,0,"Call Barring (boic except home PLMN Country) :- SSCODE[%d] = %d, SS_Status[%d] = %d, Basic Service Code[%d] = %d,Basic Service Type[%d] = %d",
                  m_isd.pss.boihcCount,m_isd.pss.boihcSsCode,m_isd.pss.boihcCount,m_isd.pss.boihcSsStatus[m_isd.pss.boihcCount],m_isd.pss.boihcCount,m_isd.pss.boihcBCode[m_isd.pss.boihcCount],m_isd.pss.boihcCount,m_isd.pss.boihcBType[m_isd.pss.boihcCount]);
            m_isd.pss.boihcCount += 1;
         }        
         m_isd.pss.baicSsCode = 0;   m_isd.pss.baicCount = 0;
         m_isd.pss.bicrSsCode = 0;   m_isd.pss.bicrCount = 0;

      }
      //DLOG(0,0,"ALL Call Barring count = %d\n",m_isd.pss.allBcount);
      //DLOG(0,0,"Call Barring for Out going call = %d\n",m_isd.pss.bocCount);
      DLOG(0,0,"Call barring for all Out going call = %d",m_isd.pss.boacCount);
      DLOG(0,0,"Call barring for international outgoing call = %d",m_isd.pss.boicCount);
      DLOG(0,0,"Call barring for internation outgoing calls except for HPLMN country = %d",m_isd.pss.boihcCount);
      //DLOG(0,0,"Call barring for incoming calls = %d\n",m_isd.pss.bicCount);
   }
#endif

   // Added in 1.0.8.0 to get restricted basic service code 
   //
   strcpy((char*)m_VLR_Restricted_Bear_Codes,(char *)l_rsd->m_rest_bear_code);
   strcpy((char*)m_VLR_Restricted_Tele_Codes,(char *)l_rsd->m_rest_tele_code);
   //
   //
   return 0;
}

int CtxtUpdateLocation::UpdLocV3(int l_UserDlgId)
{
   DLOG(0,0,"Inside UpdLoc for Dialog ID %d",l_UserDlgId);
   TLOG(0,0,"Subscriber Known MSISDN is %s",(char *)l_actMsisdn);
   m_isd.dbisd3.imsiReqd = false;
   if(true == m_fIsd) 
   {
      TLOG(0,0,"FullISD set so sending IMSI in ISDdata"); // Added in HLR 2.0.23.0 for IMSI in ISD
      m_isd.dbisd3.imsiReqd = true;
      strncpy((char *)m_isd.dbisd3.imsi,(char *)GsmProfile.l_Actimsi,strlen((char *)GsmProfile.l_Actimsi));
   }
   strncpy((char *)m_isd.dbisd3.msisdn,(char *)l_actMsisdn,strlen((char *)l_actMsisdn));
   m_isd.dbisd3.msisdnReqd = true;
   //l_state = m_rgsm;
   //set subscriber tracing active in VLR as False
   {
      m_isd.dbisd3.category = GenProfile.l_catgory;
      m_isd.dbisd3.nwAccMode = GenProfile.l_nwAccMode;
      m_isd.dbisd3.accrest = GenProfile.l_accRest;
      m_isd.dbisd3.subStatus = GenProfile.l_subsStatus;
      m_isd.dbisd3.lmu = GenProfile.l_lmu; 
      m_isd.dbisd3.istvalue = 0;
      if((GenProfile.l_ist > 0) && (l_updv3.istSupportIndicator == 0))
      {
         if(GenProfile.l_ist < 15 || GenProfile.l_ist > 255)
         {
            WLOG(0,0,"IST Alert timer value is not in allowed range of 15 to 255, not sending it in ISD");
            m_isd.dbisd3.istvalue = 0;
         }
         else
         {
            m_isd.dbisd3.istvalue = GenProfile.l_ist;
         }
      }

      strncpy(m_isd.dbisd3.bearerData,GenProfile.l_bearer,52);
      m_isd.dbisd3.bearer = true;
      strncpy(m_isd.dbisd3.teleData,GenProfile.l_tele,32);
      if(GenProfile.l_subsStatus == 1)
      {
         m_isd.dbisd3.odb_Genvalue = 0;
         m_isd.dbisd3.odb_HplmnValue = 0;
         m_isd.dbisd3.odb_GenData = false;
         m_isd.dbisd3.odb_HplmnData = false;
         m_isd.dbisd3.odb_Data = false;
         if(l_GenOdb)
         {
            m_isd.dbisd3.odb_Data = true;
            m_isd.dbisd3.odb_GenData = true;
            m_isd.dbisd3.odb_Genvalue = l_GenOdb;
         }
         if(l_PlmnOdb)
         {
            m_isd.dbisd3.odb_Data = true;
            m_isd.dbisd3.odb_HplmnData = true;
            m_isd.dbisd3.odb_HplmnValue = l_PlmnOdb;
         }
      }
      else
      {
         m_isd.dbisd3.odb_Data = false;
         m_isd.dbisd3.odb_GenData = false;
         m_isd.dbisd3.odb_HplmnData = false;
         m_isd.dbisd3.odb_Genvalue = 0;
         m_isd.dbisd3.odb_HplmnValue = 0;
      }
      m_isd.vlrcsi.vcsi.nwId = l_nwId;
      m_isd.vlrcsi.vcsi.PnwId = l_pnwId;
#if 1
      //Initializing CSI profile ID's
      m_isd.vlrcsi.vcsi.ocsi = 0;
      m_isd.vlrcsi.vcsi.sscsi = 0;
      m_isd.vlrcsi.vcsi.tifcsi = 0;
      m_isd.vlrcsi.vcsi.dcsi = 0;
      m_isd.vlrcsi.vcsi.vtcsi = 0;
      m_isd.vlrcsi.vcsi.mosmscsi = 0;
      m_isd.vlrcsi.vcsi.mtsmscsi = 0;
      if(l_updv3.VlrCap_Camel4)
      {
         m_isd.dbisd3.CamelPhase = 4;
         m_isd.vlrcsi.vcsi.rcvd_camel_phase = 4;
         /////////
         ////////
         m_isd.vlrcsi.vcsi.ocsi = 0;
         if(GenProfile.l_ocsiPid > 0)
         {
            map<u16,OCSI*>::iterator l_ocsiItr;
            if((l_ocsiItr = g_spdPtr->m_OCSIMap.find(GenProfile.l_ocsiPid))!= g_spdPtr->m_OCSIMap.end())
            {
               OCSI *l_Ocsi = l_ocsiItr->second;
               if((l_updv3.c4_oCSI) || (l_Ocsi->m_camelCapability <= 3))
               {
                  m_isd.vlrcsi.vcsi.ocsi = GenProfile.l_ocsiPid;
               }
               else
               {
                  WLOG(0,0,"Configured OCSI CCH [%d] and OfferedCamel4CSI OCSI not supported for CAP phase [%d] CAP_ACTION [%s]",
                        l_Ocsi->m_camelCapability,l_updv3.VlrCap_Phase,m_Cap_Action[m_Cap_Failure_Action]);
                  if(m_Cap_Failure_Action == 0)
                  {
                     return CAP_VALIDATION_FAILED;
                  }
               }
            }
            else
            {
               ELOG(0,0,"OCSI profile id [%d] not found in map",GenProfile.l_ocsiPid);
               return CAP_PROFILE_NOT_FOUND;
            }
         }
         /////////
         ////////
         m_isd.vlrcsi.vcsi.sscsi = GenProfile.l_sscsiPid;
         /////////
         ////////
         if(GenProfile.l_vtcsiPid > 0)
         {
            map<u16,VTCSI*>::iterator l_vt_csiItr;
            if((l_vt_csiItr = g_spdPtr->m_VTCSIMap.find(GenProfile.l_vtcsiPid))!= g_spdPtr->m_VTCSIMap.end())
            {
               VTCSI *l_VTcsi = l_vt_csiItr->second;
               if((l_updv3.c4_vtCSI) || (l_VTcsi->m_camelCapability == 3))
               {
                  m_isd.vlrcsi.vcsi.vtcsi = GenProfile.l_vtcsiPid;
               }
               else
               {
                  WLOG(0,0,"Configured VTCSI CCH [%d] and OfferedCamel4CSI VT_CSI not supported for CAP phase [%d] CAP_ACTION [%s]",
                        l_VTcsi->m_camelCapability,l_updv3.VlrCap_Phase,m_Cap_Action[m_Cap_Failure_Action]);
                  if(m_Cap_Failure_Action == 0)
                  {
                     return CAP_VALIDATION_FAILED;
                  }
               }
            }
            else
            {
               ELOG(0,0,"VT_CSI profile id [%d] not found in map",GenProfile.l_vtcsiPid);
               return CAP_PROFILE_NOT_FOUND;
            }
         }
         /////////
         ////////
         m_isd.vlrcsi.vcsi.tifcsi = GenProfile.l_tifcsiPid;
         /////////
         //////////
         m_isd.vlrcsi.vcsi.dcsi = 0;
         if(GenProfile.l_dcsiPid > 0)
         {
            map<u16,DCSI*>::iterator l_dcsiItr;
            l_dcsiItr = g_spdPtr->m_DCSIMap.find(GenProfile.l_dcsiPid);
            if(l_dcsiItr != g_spdPtr->m_DCSIMap.end())
            {
               DCSI *l_dcsi = l_dcsiItr->second;
               if((l_updv3.c4_dCSI) || (l_dcsi->m_camelCapability == 3))
               {
                  m_isd.vlrcsi.vcsi.dcsi = GenProfile.l_dcsiPid;
               }
               else
               {
                  WLOG(0,0,"Configured DCSI CCH [%d] and OfferedCamel4CSI DCSI not supported for CAP phase [%d]  CAP_ACTION [%s]",
                        l_dcsi->m_camelCapability,l_updv3.VlrCap_Phase,m_Cap_Action[m_Cap_Failure_Action]);
                  if(m_Cap_Failure_Action == 0)
                  {
                     return CAP_VALIDATION_FAILED;
                  }
               }
            }
            else
            {
               CLOG(0,0,"DCSI profileID |%d| not found in map.. ",GenProfile.l_dcsiPid);
               return CAP_PROFILE_NOT_FOUND;
            }
         }
         /////////
         /////////
         m_isd.vlrcsi.vcsi.mosmscsi = GenProfile.l_moscsiPid;
         /////////
         ////////
         if(GenProfile.l_mtscsiPid != 0)
         {
            if(l_updv3.c4_mtsCSI)
            {
               m_isd.vlrcsi.vcsi.mtsmscsi = GenProfile.l_mtscsiPid;
            }
            else
            {
               WLOG(0,0,"OFFEREDCAP4CSI MT_SMS_CSI support indicator not present  CAP_ACTION [%s]",m_Cap_Action[m_Cap_Failure_Action]);
               if(m_Cap_Failure_Action == 0)
               {
                  return CAP_VALIDATION_FAILED;
               }
            }
         }
         /////////
         ////////
         DLOG(0,0,"Camel phase Supported version is 4, OCSI profile id %d, SS CSI profile id %d, TIF CSI profile id %d, DCSI profile id %d, MOSMS CSI profile id %d",m_isd.vlrcsi.vcsi.ocsi,m_isd.vlrcsi.vcsi.sscsi,m_isd.vlrcsi.vcsi.tifcsi,m_isd.vlrcsi.vcsi.dcsi,m_isd.vlrcsi.vcsi.mosmscsi);
      }
      else if(l_updv3.VlrCap_Camel3 && !(l_updv3.VlrCap_Camel4))
      {
         m_isd.dbisd3.CamelPhase = 3;
         m_isd.vlrcsi.vcsi.rcvd_camel_phase = 3;
         m_isd.vlrcsi.vcsi.ocsi = GenProfile.l_ocsiPid;
         m_isd.vlrcsi.vcsi.sscsi = GenProfile.l_sscsiPid;
         m_isd.vlrcsi.vcsi.tifcsi = GenProfile.l_tifcsiPid;
         m_isd.vlrcsi.vcsi.dcsi = GenProfile.l_dcsiPid;
         m_isd.vlrcsi.vcsi.vtcsi = GenProfile.l_vtcsiPid;
         m_isd.vlrcsi.vcsi.mosmscsi = GenProfile.l_moscsiPid;
         m_isd.vlrcsi.vcsi.mtsmscsi = 0;
         if(GenProfile.l_mtscsiPid != 0)
         {
            WLOG(0,0,"MT_SMS_CSI [%d] present in subscriber profile, but rcvd max CAP phase is 3 CAP_ACTION [%s]",GenProfile.l_mtscsiPid,m_Cap_Action[m_Cap_Failure_Action]);
            if(m_Cap_Failure_Action == 0)
            {
               return CAP_VALIDATION_FAILED;
            }
         }
         DLOG(0,0,"Camel phase Supported version is 3, OCSI profile id %d, SS CSI profile id %d, TIF CSI profile id %d, DCSI profile id %d, MOSMS CSI profile id %d, MTSMS CSI profile id %d",GenProfile.l_ocsiPid,GenProfile.l_sscsiPid,GenProfile.l_tifcsiPid,GenProfile.l_dcsiPid,GenProfile.l_moscsiPid,GenProfile.l_mtscsiPid);
      }
      else if(l_updv3.VlrCap_Camel2 && !(l_updv3.VlrCap_Camel3) && !(l_updv3.VlrCap_Camel4))
      {
         DLOG(0,0,"Camel phase Supported version is 2, OCSI profile id %d, SS CSI profile id %d and TIF CSI profile id %d",GenProfile.l_ocsiPid,GenProfile.l_sscsiPid,GenProfile.l_tifcsiPid);
         m_isd.dbisd3.CamelPhase = 2;
         m_isd.vlrcsi.vcsi.rcvd_camel_phase = 2;
         m_isd.vlrcsi.vcsi.ocsi = GenProfile.l_ocsiPid;
         m_isd.vlrcsi.vcsi.sscsi = GenProfile.l_sscsiPid;
         m_isd.vlrcsi.vcsi.tifcsi = GenProfile.l_tifcsiPid;
         if((GenProfile.l_mtscsiPid != 0) || (GenProfile.l_vtcsiPid != 0) || (GenProfile.l_dcsiPid != 0) || (GenProfile.l_moscsiPid  != 0))
         {
            WLOG(0,0,"CSI for higher CAP version [MT_SMS %d MOSMS %d VTCSI %d DCSI %d]present in subscriber profile, but rcvd max CAP phase is 2 CAP_ACTION [%s]",
                  GenProfile.l_mtscsiPid,GenProfile.l_moscsiPid,GenProfile.l_vtcsiPid,GenProfile.l_dcsiPid,m_Cap_Action[m_Cap_Failure_Action]);
            if(m_Cap_Failure_Action == 0)
            {
               return CAP_VALIDATION_FAILED;
            }
         }
         m_isd.vlrcsi.vcsi.dcsi = 0;
         m_isd.vlrcsi.vcsi.vtcsi = 0;
         m_isd.vlrcsi.vcsi.mosmscsi = 0;
         m_isd.vlrcsi.vcsi.mtsmscsi = 0;
      }
      else if(l_updv3.VlrCap_Camel1 && !(l_updv3.VlrCap_Camel2) && !(l_updv3.VlrCap_Camel3) && !(l_updv3.VlrCap_Camel4))
      {
         m_isd.dbisd3.CamelPhase = 1;
         m_isd.vlrcsi.vcsi.rcvd_camel_phase = 1;
         DLOG(0,0,"Camel phase Supported version is 1, OCSI profile id %d",GenProfile.l_ocsiPid);
         m_isd.vlrcsi.vcsi.ocsi = GenProfile.l_ocsiPid;
         if((GenProfile.l_sscsiPid != 0) || (GenProfile.l_tifcsiPid != 0) || (GenProfile.l_mtscsiPid != 0) || (GenProfile.l_vtcsiPid != 0) || (GenProfile.l_dcsiPid != 0) || (GenProfile.l_moscsiPid  != 0))
         {
            WLOG(0,0,"CSI for higher CAP version [MT_SMS %d MOSMS %d VTCSI %d DCSI %d SSCSI %d TIFCSI %d] present in subscriber profile, but rcvd max CAP phase is 1 CAP_ACTION [%s]"
                  , GenProfile.l_mtscsiPid,GenProfile.l_moscsiPid,GenProfile.l_vtcsiPid,GenProfile.l_dcsiPid,GenProfile.l_sscsiPid,GenProfile.l_tifcsiPid,m_Cap_Action[m_Cap_Failure_Action]);
            if(m_Cap_Failure_Action == 0)
            {
               return CAP_VALIDATION_FAILED;
            }
         }
         m_isd.vlrcsi.vcsi.sscsi = 0;
         m_isd.vlrcsi.vcsi.tifcsi = 0;
         m_isd.vlrcsi.vcsi.dcsi = 0;
         m_isd.vlrcsi.vcsi.vtcsi = 0;
         m_isd.vlrcsi.vcsi.mosmscsi = 0;
         m_isd.vlrcsi.vcsi.mtsmscsi = 0;
      }
      else
      {
         m_isd.dbisd3.CamelPhase = 1;
         m_isd.vlrcsi.vcsi.rcvd_camel_phase = 1;
         DLOG(0,0,"No camel phase supported obtained, Assuming as Camel phase 1 OCSI profile id is %d",GenProfile.l_ocsiPid);
         m_isd.vlrcsi.vcsi.ocsi = GenProfile.l_ocsiPid;
         m_isd.vlrcsi.vcsi.sscsi = 0;
         m_isd.vlrcsi.vcsi.tifcsi = 0;
         m_isd.vlrcsi.vcsi.dcsi = 0;
         m_isd.vlrcsi.vcsi.vtcsi = 0;
         m_isd.vlrcsi.vcsi.mosmscsi = 0;
         m_isd.vlrcsi.vcsi.mtsmscsi = 0;
      }
#endif      
   }

   TLOG(0,0,"GsmProfile.l_TraceFlag %d, GsmProfile.l_TraceStatus %d, Send_ATM %d",GsmProfile.l_TraceFlag,GsmProfile.l_TraceStatus,m_SendATM);
   //   if((l_roamInd == 0)&& (GsmProfile.l_TraceFlag == 1) && ((GsmProfile.l_TraceStatus != 0)||(m_SendATM)) ) commented in 2.0.0.0 Rev1
   if((l_roamInd == 0)&& (GsmProfile.l_TraceFlag == 1))
   {
      return SEND_ATM;
   }
   else
   {
      UpdLocV3Cont(l_UserDlgId);
      return UPDV3_SUCCESS;
   }
}

bool CtxtUpdateLocation::UpdLocV2(int l_UserDlgId)//,RetrieveSubsVLRData *l_rsd)
{
   DLOG(0,0,"Subscriber Known Assigning MSISDN is %s",(char *)l_actMsisdn);
   strcpy((char *)m_isd.dbisd2.imsi,(char *)l_updv2.imsi);
   m_isd.dbisd2.imsiReqd = false;
   memset(m_isd.dbisd2.msisdn,'\0',sizeof(m_isd.dbisd2.msisdn));
   strncpy((char *)m_isd.dbisd2.msisdn,(char *)l_actMsisdn,strlen((char *)l_actMsisdn));
   m_isd.dbisd2.msisdnReqd = true;
   //l_state = m_rgen;
   {
      m_isd.dbisd2.category = GenProfile.l_catgory;
      m_isd.dbisd2.nwAccMode = GenProfile.l_nwAccMode;
      {
         strncpy(m_isd.dbisd2.bearerData,GenProfile.l_bearer,52);
         m_isd.dbisd2.bearer = true;
         strncpy(m_isd.dbisd2.teleData,GenProfile.l_tele,32);
      }
      if(GenProfile.l_subsStatus == 1)
      {
         m_isd.dbisd2.odb_Genvalue = 0;
         m_isd.dbisd2.odb_HplmnValue = 0;
         m_isd.dbisd2.odb_Data = false;
         m_isd.dbisd2.odb_GenData = false;
         m_isd.dbisd2.odb_HplmnData = false;
         if(l_GenOdb)
         {
            m_isd.dbisd2.odb_Data = true;
            m_isd.dbisd2.odb_GenData = true;
            unsigned int l_map2ODB = map3tomap2odb(l_GenOdb); 
            m_isd.dbisd2.odb_Genvalue = l_map2ODB;         
         }
         if(l_PlmnOdb)
         {
            m_isd.dbisd2.odb_Data = true;
            m_isd.dbisd2.odb_HplmnData = true;
            unsigned int l_map2HODB = map3tomap2odb(l_PlmnOdb); 
            m_isd.dbisd2.odb_HplmnValue = l_map2HODB;
         }
         if((m_isd.dbisd2.odb_Genvalue == 0) && ( m_isd.dbisd2.odb_HplmnValue == 0))
         {
            m_isd.dbisd2.odb_Data = false;
            m_isd.dbisd2.odb_GenData = false;
            m_isd.dbisd2.odb_HplmnData = false;
            m_isd.dbisd2.odb_Genvalue = 0;
            m_isd.dbisd2.odb_HplmnValue = 0;
            WLOG(0,0,"No meaningful ODB data for map version 2 present");
            GenProfile.l_subsStatus = 0;
         }
         LLOG(0,0,"ODB value to add is %ld, HPLMN ODB value is %ld Subscriber Status %d",m_isd.dbisd2.odb_Genvalue,m_isd.dbisd2.odb_HplmnValue,GenProfile.l_subsStatus);
      }
      else
      {
         m_isd.dbisd2.odb_Data = false;
         m_isd.dbisd2.odb_GenData = false;
         m_isd.dbisd2.odb_HplmnData = false;
         m_isd.dbisd2.odb_Genvalue = 0;
         m_isd.dbisd2.odb_HplmnValue = 0;
      }
      m_isd.dbisd2.subStatus = GenProfile.l_subsStatus;
   }
   if((l_roamInd == 0)&& (GsmProfile.l_TraceFlag == 1) && ((GsmProfile.l_TraceStatus != 0)||(m_SendATM)))
   {
      return false;
   }
   else
   {
      UpdLocV2Cont(l_UserDlgId);
      return true;
   }
}

bool CtxtUpdateLocation::UpdLocV1(int l_UserDlgId)
{
   DLOG(0,0,"Subscriber Known MSISDN is %s",(char *)l_actMsisdn);
   strcpy((char *)m_isd.dbisd1.imsi,(char *)l_updv1.imsi);
   m_isd.dbisd1.imsiReqd = false;
   memset(m_isd.dbisd1.msisdn,'\0',sizeof(m_isd.dbisd1.msisdn));
   strncpy((char *)m_isd.dbisd1.msisdn,(char *)l_actMsisdn,strlen((char *)l_actMsisdn));
   m_isd.dbisd1.msisdnReqd = true;
   //l_state = m_rgen;
   m_isd.dbisd1.category = GenProfile.l_catgory;
   m_isd.dbisd1.nwAccMode = GenProfile.l_nwAccMode;
   m_isd.dbisd1.subStatus = GenProfile.l_subsStatus;

   strncpy(m_isd.dbisd1.bearerData,GenProfile.l_bearer,52);
   m_isd.dbisd1.bearer = true;


   strncpy(m_isd.dbisd1.teleData,GenProfile.l_tele,32);


   if((l_roamInd == 0)&& (GsmProfile.l_TraceFlag == 1) && ((GsmProfile.l_TraceStatus != 0)||(m_SendATM)))
   {
      return false;
   }
   else
   {
      UpdLocV1Cont(l_UserDlgId);
      return true;
   }
}

//Called on receiving ActivateTraceMode_resp
void CtxtUpdateLocation::UpdLocV3Cont(int l_UserDlgId)
{   
   DLOG(0,0,"Calling FormISDReq");
   l_state = m_fid;
   startISDV3(l_UserDlgId);      
}

void CtxtUpdateLocation::UpdLocV2Cont(int l_UserDlgId)
{
   DLOG(0,0,"Inside UpdLoc Continue for version 2");
   DLOG(0,0,"Calling FormISDReq");
   l_state = m_fid;
   startISDV2(l_UserDlgId);
}

void CtxtUpdateLocation::UpdLocV1Cont(int l_UserDlgId)
{
   DLOG(0,0,"Inside UpdLoc Continue for version 1");
   DLOG(0,0,"Calling FormISDReq");
   l_state = m_fid;
   startISDV1(l_UserDlgId);
}

void CtxtUpdateLocation::startISDV3(int l_UserDlgId)
{
   l_state = m_fid;
   index = OMAP3_InsertSubscriberDataArg_imsi_present;//0x80000000 initialized to first param
   VcsiIndex = OMAP3_VlrCamelSubscriptionInfo_o_CSI_present;//0x8000 initialized to OCSI
   ScsiIndex = 0;
   m_MoreDataToSend = true;
   SsIndex = OMAP3_Ext_SS_Info_forwardingInfo_chosen;
   m_isd.pss.CFWD_STATE = (provisionedSS::CFWD)0;
   m_isd.pss.CB_STATE = (provisionedSS::CB)0;
   m_isd.pss.val = 0;
   m_isd.dbisd3.VLRCsi = true;
   m_isd.dbisd3.sgsncsi = false;
   m_isd.dbisd3.gprsSubsData = 0;
   m_isd.pss.m_GenSsCount = 0;
   DLOG(0,0,"Starting ISD V3 with index %x SsIndex %x and CSI Index %x",index,SsIndex,VcsiIndex);
   DLOG(0,0,"Calling FormISDReqV3 from OpCode %d for Dialog Id %d call state is %d",l_OpCode,l_UserDlgId,(m_callState)l_state);

   MapSpecificRequest l_request(l_UserDlgId, MAP_OP_CODE_insertSubscriberData, MAP_V3);
   DECLARE(OMAP3_InsertSubscriberDataArg,l_isd,3,"OMAP3_InsertSubscriberDataArg",DeclareFunc);
   m_isd.FormISDReqV3(l_UserDlgId,index,VcsiIndex,ScsiIndex,SsIndex,flag,m_isd.dbisd3,l_OpCode,l_isd);
   DLOG(0,0,"Index here is %x",index);
   if(10 > g_AsnCodecO3.getEncodingLength(OMAP3_InsertSubscriberDataArg_PDU,l_isd))
   {
      ELOG(0,0,"Unable to form ISD, returning System Failure");
      if(false == m_fIsd)
      {
         RetErrorV3(l_UserDlgId,SystemFailure);        
      }
      UpdateUpdFailData(l_UserDlgId);
   }
   else
   {
      m_tdr.setInteger(TDR_INDEX_RESRV2,m_isd.m_MM_TDR_CSI_FLAGS);
      SendMsgV3(l_UserDlgId,&l_request,l_isd,index,VcsiIndex,ScsiIndex,SsIndex);
   }
}

void CtxtUpdateLocation::startISDV2(int l_UserDlgId)
{
   l_state = m_fid;
   DLOG(0,0,"Calling FormISDReqV2 for Dialog Id %d",l_UserDlgId);
   index = OMAP2_InsertSubscriberDataArg_imsi_present;//0x8000 initialized to first param
   SsIndex = OMAP2_SS_Info_forwardingInfo_chosen;
   m_isd.pss.CFWD_STATE = (provisionedSS::CFWD)0;
   m_isd.pss.CB_STATE = (provisionedSS::CB)0;
   m_isd.pss.val = 0;
   m_MoreDataToSend = true;

   MapSpecificRequest l_request(l_UserDlgId, MAP_OP_CODE_insertSubscriberData, MAP_V2); 
   DECLARE(OMAP2_InsertSubscriberDataArg,l_isd,2,"OMAP2_InsertSubscriberDataArg",DeclareFunc);                                     
   m_isd.FormISDReqV2(l_UserDlgId,index,SsIndex,flag,m_isd.dbisd2,l_OpCode,l_isd);//l_updv2.imsi,l_basicMsisdn,
   if(10 > g_AsnCodecO2.getEncodingLength(OMAP2_InsertSubscriberDataArg_PDU,l_isd))
   {
      ELOG(0,0,"Unable to form ISD, returning System Failure");
      RetErrorV2(l_UserDlgId,SystemFailure);        
      UpdateUpdFailData(l_UserDlgId);
   }
   else
   {
      SendMsgV2(l_UserDlgId,&l_request,l_isd,index,SsIndex);
   }
}

void CtxtUpdateLocation::startISDV1(int l_UserDlgId)
{
   l_state = m_fid;
   DLOG(0,0,"Calling FormISDReqV1 for Dialog Id %d",l_UserDlgId);
   index = OMAP1_InsertSubscriberDataArg_imsi_present;//0x8000 initialized to first param
   SsIndex = OMAP1_forwardingInfo_chosen;
   m_isd.pss.CFWD_STATE = (provisionedSS::CFWD)0;
   m_isd.pss.CB_STATE = (provisionedSS::CB)0;
   m_isd.pss.val = 0;
   m_MoreDataToSend = true;

   MapSpecificRequest l_request(l_UserDlgId, MAP_OP_CODE_insertSubscriberData, MAP_V1);
   DECLARE(OMAP1_InsertSubscriberDataArg,l_isd,1,"OMAP1_InsertSubscriberDataArg",DeclareFunc);

   m_isd.FormISDReqV1(l_UserDlgId,index,SsIndex,flag,m_isd.dbisd1,l_OpCode,l_isd);//l_updv2.imsi,l_basicMsisdn,
   if(10 > g_AsnCodecO1.getEncodingLength(OMAP1_InsertSubscriberDataArg_PDU,l_isd))
   {
      ELOG(0,0,"Unable to form ISD, returning System Failure");
      RetErrorV1(l_UserDlgId,SystemFailure);        
      UpdateUpdFailData(l_UserDlgId);
   }
   else
   {
      SendMsgV1(l_UserDlgId,&l_request,l_isd,index,SsIndex);
   }
}

void CtxtUpdateLocation::SendMsgV3(int DlgId,MapSpecificRequest *l_request,OMAP3_InsertSubscriberDataArg *l_isd,unsigned int &numOfParam,unsigned int &VcsiParam,unsigned int &ScsiParam,unsigned int &SsParam)
{
   LLOG(0,0,"Sending ISD for Dialog id %d",DlgId);
   index = numOfParam;
   VcsiIndex = VcsiParam;
   ScsiIndex = ScsiParam;
   ScsiIndex = 0;
   SsIndex = SsParam;
   DLOG(0,0,"The value returned by ISDData are ISD Index %x, VLR CSI Index is %x SGSN CSI Index is %x and SS INDEX is %x",index,VcsiIndex,ScsiIndex,SsIndex);
   l_request->m_structBuffer = (void*) l_isd;
   g_sc.sendMsg(this, l_request);
   ContinueReq(DlgId);
   l_state = m_sid;
   DLOG(0, 0, "Sending Delimiter Req after the ISD,callState here is %d",(m_callState)l_state);
}

void CtxtUpdateLocation::SendMsgV2(int DlgId,MapSpecificRequest *l_request,OMAP2_InsertSubscriberDataArg *l_isd,unsigned int &numOfParam,unsigned int &SsParam)
{
   l_state = m_sid;
   LLOG(0,0,"Sending ISD for Dialog id %d ",DlgId);
   index = numOfParam;
   SsIndex = SsParam;
   DLOG(0,0,"The index value returned by ISDData is %x, SS_Index %x",index,SsIndex);
   l_request->m_structBuffer = (void*) l_isd;
   g_sc.sendMsg(this, l_request);
   DLOG(0, 0, "Sending Delimiter Req after the ISD");
   ContinueReq(DlgId);
}

void CtxtUpdateLocation::SendMsgV1(int DlgId,MapSpecificRequest *l_request,OMAP1_InsertSubscriberDataArg *l_isd,unsigned int &numOfParam,unsigned int &SsParam)
{
   l_state = m_sid;
   LLOG(0,0,"Sending ISD for Dialog id %d",DlgId);
   index = numOfParam;
   VcsiIndex = 0;//VcsiParam;
   ScsiIndex = 0;
   SsIndex = SsParam;
   //DLOG(0,0,"The value returned by ISDData are \n ISD Index is %x\n VLR CSI Index is %x\n SGSN CSI Index is %x\n SS Index is %x\n",index,VcsiIndex,ScsiIndex,SsIndex);
   DLOG(0,0,"The value returned by ISDData are ISD Index %x, VLR CSI Index is %x SGSN CSI Index is %x and SS INDEX is %x",index,VcsiIndex,ScsiIndex,SsIndex);
   l_request->m_structBuffer = (void*) l_isd;
   g_sc.sendMsg(this, l_request);
   DLOG(0, 0, "Sending Delimiter Req after the ISD");
   ContinueReq(DlgId);   
}

void CtxtUpdateLocation::UpdLocV3_Cont(int l_UserDlgId)//,struct GsmProfile)
{
   DLOG(0,0,"Finished ISD,continuing with remaining UPD");
   if((l_mwd == 1) && ((l_OpCode == 2) || ((l_OpCode == 57) && (strncmp((char *)GsmProfile.l_vlrno,"0",1)!=0))))
   {
      LLOG(0,0,"Message waiting set, Initiating Alert SC context for AlertMSISDN %s GprsFlag 0",l_AlertMsisdn);
      char l_AscXml[100];
      snprintf(l_AscXml, sizeof(l_AscXml), "<ALERT_SC><MSISDN>%s</MSISDN><GPRS>0</GPRS><NETWORK_ID>%d</NETWORK_ID></ALERT_SC>",(char *)l_AlertMsisdn,l_nwId);
      g_sc.initiateIndependentContext(this,MAP_OP_CODE_alertServiceCentre,(char *)l_AscXml, INITIATION_TYPE_TARDILY);
   }
   if (1 == GsmProfile.l_ssInd)
   {
      //DLOG(0,0,"SS_INDICATOR set in HLR_SUBS_DATA, sending ForwardCheckSSIndication\n");
      DLOG(0,0,"Check SS Indicator is set in DB, sending Forward check ss Indication");
      sendCheckSS();      
   }
   else
   {
      DLOG(0,0,"Check SS Indicator is not set in DB");
   }
   DLOG(0,0,"OPCODE VALUE [%d]",l_OpCode);
   if(l_OpCode == 2 || l_OpCode == 110)
   {
      updLocResV3(l_UserDlgId);
   }
   if(l_OpCode == 57)
   {
      RsdRespV3(l_UserDlgId,GsmProfile.l_mnrf);
   }
}

void CtxtUpdateLocation::UpdLocV2_Cont(int l_UserDlgId)//,struct GsmProfile)
{
   DLOG(0,0,"Finished ISD,continuing with remaining UPD");
   if((l_mwd == 1) && ((l_OpCode == 2) || ((l_OpCode == 57) && (strncmp((char *)GsmProfile.l_vlrno,"0",1)!=0))))
   {
      LLOG(0,0,"Message waiting set, Initiating Alert SC context for Alert MSISDN %s",l_AlertMsisdn);
      char l_AscXml[100];
      snprintf(l_AscXml, sizeof(l_AscXml), "<ALERT_SC><MSISDN>%s</MSISDN><GPRS>0</GPRS><NETWORK_ID>%d</NETWORK_ID></ALERT_SC>",(char *)l_AlertMsisdn,l_nwId);
      g_sc.initiateIndependentContext(this,MAP_OP_CODE_alertServiceCentre,(char *)l_AscXml, INITIATION_TYPE_TARDILY);
   }
   if (1 == GsmProfile.l_ssInd)
   {
      sendCheckSS();
      DLOG(0,0,"Check SS Indicator is set in DB, sending Forward check ss Indication");
   }
   if(l_OpCode == 2)
   {
      updLocResV2(l_UserDlgId);
   }
   if(l_OpCode == 57)
   {
      RsdRespV2(l_UserDlgId,GsmProfile.l_mnrf);
   }
}

void CtxtUpdateLocation::UpdLocV1_Cont(int l_UserDlgId)//,struct GsmProfile)
{
   DLOG(0,0,"Finished ISD,continuing with remaining UPD");
   if(l_mwd == 1)
   {
      LLOG(0,0,"Message waiting set, Initiating Alert SC context for Alert MSISDN %s",l_AlertMsisdn);
      char l_AscXml[100];
      snprintf(l_AscXml, sizeof(l_AscXml), "<ALERT_SC><MSISDN>%s</MSISDN><GPRS>0</GPRS><NETWORK_ID>%d</NETWORK_ID></ALERT_SC>",(char *)l_AlertMsisdn,l_nwId);
      g_sc.initiateIndependentContext(this,MAP_OP_CODE_alertServiceCentre,(char *)l_AscXml, INITIATION_TYPE_TARDILY);
   }
   if (1 == GsmProfile.l_ssInd)
   {
      sendCheckSS();
      DLOG(0,0,"Check SS Indicator is set in DB, sending Forward check ss Indication");
   }
   DLOG(0,0,"Passing the HLR address %s to updlocres",l_hlrAddr);
   //updLocResV1(l_UserDlgId,l_hlrAddr);
   updLocResV1(l_UserDlgId);
}



#if 1
void CtxtUpdateLocation::RetrieveData(int l_UserDlgId,u8 *imsi,u8 *vlr)
{   
   TLOG(0,0,"%d-TS:Retriving profile data for IMSI [%s] from VLR [%s] Multi_Imsi Reqd [%d] for Opcode %d",
         l_UserDlgId,(char *)imsi,(char *)vlr,g_MmConfigReaderObj->m_Multi_Imsi_Reqd,l_OpCode);                           
   RetrieveSubsVLRData *l_rsd = new RetrieveSubsVLRData();
   //UpdSubsData *l_rsd = new UpdSubsData();
   l_rsd->m_UserDlgId = l_UserDlgId;
   strcpy((char *)l_rsd->m_imsi,(char *)imsi);
   strcpy((char *)l_rsd->m_vlr,(char *)vlr);


   l_rsd->m_OpCode = ((l_OpCode == MAP_OP_CODE_sendParameters)?57:l_OpCode);
   l_rsd->m_UPD_Version = l_Version;
   l_rsd->m_VLR_Supported_Max_CAP_Phase = 0;
   if(l_Version == 3)
   {
      memcpy((char *)l_rsd->m_lmsi,(char *)l_updv3.lmsi,4);
      if(l_OpCode == 2)
      {
         strncpy((char *)l_rsd->m_msc,(char *)l_updv3.msc+2,strlen((char *)l_updv3.msc+2));
      }
      else if( (l_OpCode == 57) || (l_OpCode == 110) )
      {
         strncpy((char *)l_rsd->m_msc,(char *)l_updv3.msc,strlen((char *)l_updv3.msc));
      }

      if(strlen((char*)l_updv3.imeisv) > 2)
      {
         strncpy((char *)l_rsd->m_IMEISV,(char *)l_updv3.imeisv,strlen((char *)l_updv3.imeisv));
      }


      l_rsd->m_CamPha = 0;
      if(l_updv3.VlrCap_Camel4)
      {
         l_rsd->m_CamPha |= 0x08;
      }
      if(l_updv3.VlrCap_Camel3)
      {
         l_rsd->m_CamPha |= 0x04;
      }
      if(l_updv3.VlrCap_Camel2)
      {
         l_rsd->m_CamPha |= 0x02;
      }
      if(l_updv3.VlrCap_Camel1)
      {
         l_rsd->m_CamPha |= 0x01;
      }
      l_rsd->m_VLR_Supported_Max_CAP_Phase = l_updv3.VlrCap_Phase; 

      l_rsd->m_Solsa =  0;
      if(l_updv3.soLSA)
         l_rsd->m_Solsa = 1;
      l_rsd->m_IST = 0;
      l_rsd->m_IST = l_updv3.istSupportIndicator;
      l_rsd->m_SupChrg = 0;
      if(l_updv3.SuperCharge)
         l_rsd->m_SupChrg = 1;
      l_rsd->m_LongFTN = 0;
      if(l_updv3.LongFTN)
         l_rsd->m_LongFTN = 1;
      l_rsd->m_SuppLCS = 0;
      if(l_updv3.lcsCS4)
         l_rsd->m_SuppLCS |= 0x08;
      if(l_updv3.lcsCS3)
         l_rsd->m_SuppLCS |= 0x04;
      if(l_updv3.lcsCS2)
         l_rsd->m_SuppLCS |= 0x02;
      if(l_updv3.lcsCS1)
         l_rsd->m_SuppLCS |= 0x01;

      if(l_rsd->m_SuppLCS != 0)
      {
         l_rsd->m_cs_LCS_SupportedByUE = 1;
      }

      l_rsd->m_OffCAM = 0;
      if(l_updv3.c4_oCSI)
         l_rsd->m_OffCAM |= 0x01;
      if(l_updv3.c4_dCSI)
         l_rsd->m_OffCAM |= 0x02;
      if(l_updv3.c4_vtCSI)
         l_rsd->m_OffCAM |= 0x04;
      if(l_updv3.c4_tCSI)
         l_rsd->m_OffCAM |= 0x08;
      if(l_updv3.c4_mtsCSI)
         l_rsd->m_OffCAM |= 0x16;
      if(l_updv3.c4_mgCSI)
         l_rsd->m_OffCAM |= 0x32;
      if(strlen((char *)l_updv3.gmlc_Address) > 1)
      {
         strcpy((char *)l_rsd->m_cs_v_gmlc_Address,(char *)l_updv3.gmlc_Address);
      }
      if(true == l_updv3.cs_LCS_NotSupportedByUE)
      {
         l_rsd->m_cs_LCS_SupportedByUE = 0;
      }
      l_rsd->m_mtrf_support_ind = l_updv3.l_mtrf_support_ind;
   }
   if(l_Version == 2)
   {
      memset(l_rsd->m_lmsi,'\0',sizeof(l_rsd->m_lmsi));
      memcpy((char *)l_rsd->m_lmsi,(char *)l_updv2.lmsi,4);
      memset(l_rsd->m_msc,'\0',sizeof(l_rsd->m_msc));
      if(l_OpCode == 2)
      {
         strncpy((char *)l_rsd->m_msc,(char *)l_updv2.msc+2,strlen((char *)l_updv2.msc+2));
      }
      if(l_OpCode == 57)
      {
         strncpy((char *)l_rsd->m_msc,(char *)l_updv2.msc,strlen((char *)l_updv2.msc));
      }
      l_rsd->m_CamPha = 0;
      l_rsd->m_Solsa = 0;
      l_rsd->m_LongFTN = 0;
      l_rsd->m_SuppLCS = 0;
      l_rsd->m_IST = 0;
      l_rsd->m_SupChrg = 0;
      l_rsd->m_OffCAM = 0;
   }
   if(l_Version == 1)
   {
      if(l_OpCode == MAP_OP_CODE_sendParameters)
      {
         strncpy((char *)l_rsd->m_msc,(char *)vlr,strlen((char *)vlr));
         memset(l_rsd->m_lmsi,'\0',sizeof(l_rsd->m_lmsi));
      }
      else
      {
         strncpy((char *)l_rsd->m_msc,(char *)l_updv1.msc+2,strlen((char *)l_updv1.msc+2));
         memcpy((char *)l_rsd->m_lmsi,(char *)l_updv1.lmsi,4);
      }
      l_rsd->m_CamPha = 0;
      l_rsd->m_Solsa = 0;
      l_rsd->m_LongFTN = 0;
      l_rsd->m_SuppLCS = 0;
      l_rsd->m_IST = 0;
      l_rsd->m_SupChrg = 0;
      l_rsd->m_OffCAM = 0;
   }
   if(true == m_fIsd)
   {
      DLOG(0,0,"UPD initiated from startprocessing so setting m_full_isd_ind with value 1");
      LLOG(0,0,"Setting Full ISD DB indicator to 1");
      l_rsd->m_full_isd_ind = 1;

      /*map<int, HlrNetworks* > :: iterator l_HlrNetworksDetailsIter;
      l_HlrNetworksDetailsIter = g_spdPtr->m_HlrNetworks.find(l_nwId);
      if(l_HlrNetworksDetailsIter == g_spdPtr->m_HlrNetworks.end())
      {
         LLOG(0,0,"Network ID not found in networks map[%d]",l_nwId);
      }
      else
      {
         DLOG(0,0,"Network ID found in networks map[%d]",l_nwId);
         LLOG(0,0,"Change Template Gsm Action in Networks page is ... [%d]",((l_HlrNetworksDetailsIter->second)->m_ChangeTempGsmAction));
         m_tdr.setInteger(TDR_INDEX_SSM_USSD_SERV_CODE,((l_HlrNetworksDetailsIter->second)->m_ChangeTempGsmAction));
      }*/
   }

   //6.1.10.0 --> start
   snprintf((char*)l_rsd->m_Orig_Imei,sizeof(l_rsd->m_Orig_Imei),"%s",m_Orig_Imei);
   DLOG(0,0,"#### l_rsd->m_Orig_Imei [%s] ####",l_rsd->m_Orig_Imei);
   //6.1.10.0 -->end
   l_rsd->m_cb = this;
   g_act.execute(l_rsd);
}

void CtxtUpdateLocation::UpdateGsmData(int l_UserDlgId)
{
   if(true == m_fIsd)
   {
      LLOG(0,0,"Full ISD indicator set NOT updating subs data for ISD unsupported failures");
      return;
   }
   DLOG(0,0,"Calling the procedure to update GSM data");
   LLOG(0,0,"Updating data for Dialog id %d, Account id %s ",l_UserDlgId,l_AccId);
   l_state = m_usds;      
   UpdateVLRData *l_usd = new UpdateVLRData();
   l_usd->m_UserDlgId = l_UserDlgId;
   memset(l_usd->m_AccId,'\0',sizeof(l_usd->m_AccId));
   strncpy((char *)l_usd->m_AccId,(char *)l_AccId,strlen((char *)l_AccId));
   l_usd->m_nwid = l_nwId;
   l_usd->m_pnwid = l_pnwId;
   l_usd->m_MsisdnTyp = l_AlocType;
   memset(l_usd->m_ActMsisdn,'\0',sizeof(l_usd->m_ActMsisdn));
   strncpy((char *)l_usd->m_ActMsisdn,(char *)l_actMsisdn,strlen((char *)l_actMsisdn));
   memset(l_usd->m_hlr,'\0',sizeof(l_usd->m_hlr));
   strncpy((char *)l_usd->m_hlr,(char *)l_hlrAddr,strlen((char *)l_hlrAddr));
   memset(l_usd->m_IMEISV,'\0',sizeof(l_usd->m_IMEISV));
   DLOG(0,0,"Opcode %d Version is %d",l_OpCode,l_Version);
   if(l_Version == 3)
   {
      strncpy((char *)l_usd->m_ActImsi,(char *)l_updv3.imsi,strlen((char *)l_updv3.imsi));
      memcpy((char *)l_usd->m_lmsi,(char *)l_updv3.lmsi,4);
      if(l_OpCode == 2)
      {
         strncpy((char *)l_usd->m_vlr,(char *)l_updv3.vlr+2,strlen((char *)l_updv3.vlr+2));
         strncpy((char *)l_usd->m_msc,(char *)l_updv3.msc+2,strlen((char *)l_updv3.msc+2));
      }
      if((l_OpCode == 57)  || (l_OpCode == 110)) // 107 added in HLR 2.0.23.0
      {
         strncpy((char *)l_usd->m_vlr,(char *)l_updv3.vlr,strlen((char *)l_updv3.vlr));
         strncpy((char *)l_usd->m_msc,(char *)l_updv3.msc,strlen((char *)l_updv3.msc));
      }
      //Changed in 1.0.5.0
      if(strlen((char*)l_updv3.imeisv) < 2)
      {
         if(strcmp((char*)GsmProfile.l_imeisv,"0")!= 0)
            strcpy((char *)l_usd->m_IMEISV,(char*)GsmProfile.l_imeisv);
      }
      else
      {
         strncpy((char *)l_usd->m_IMEISV,(char *)l_updv3.imeisv,strlen((char *)l_updv3.imeisv));
      }
      //End changes in 1.0.5.0
      l_usd->m_CamPhases = 0;
      if(l_updv3.VlrCap_Camel4)
         l_usd->m_CamPhases |= 0x08;
      if(l_updv3.VlrCap_Camel3)
         l_usd->m_CamPhases |= 0x04;
      if(l_updv3.VlrCap_Camel2)
         l_usd->m_CamPhases |= 0x02;
      if(l_updv3.VlrCap_Camel1)
         l_usd->m_CamPhases |= 0x01;
      l_usd->m_solsa =  0;
      if(l_updv3.soLSA)
         l_usd->m_solsa = 1;
      l_usd->m_ist = 0;
      l_usd->m_ist = l_updv3.istSupportIndicator;
      l_usd->m_SuprChrg = 0;
      if(l_updv3.SuperCharge)
         l_usd->m_SuprChrg = 1;
      l_usd->m_LongFTN = 0;
      if(l_updv3.LongFTN)
         l_usd->m_LongFTN = 1;
      l_usd->m_SuppLCS = 0;
      if(l_updv3.lcsCS4)
         l_usd->m_SuppLCS |= 0x08;
      if(l_updv3.lcsCS3)
         l_usd->m_SuppLCS |= 0x04;
      if(l_updv3.lcsCS2)
         l_usd->m_SuppLCS |= 0x02;
      if(l_updv3.lcsCS1)
         l_usd->m_SuppLCS |= 0x01;

      if(l_usd->m_SuppLCS != 0)
      {
         l_usd->m_cs_LCS_SupportedByUE = 1;
      }

      l_usd->m_OffCSI = 0;
      if(l_updv3.c4_oCSI)
         l_usd->m_OffCSI |= 0x01;
      if(l_updv3.c4_dCSI)
         l_usd->m_OffCSI |= 0x02;
      if(l_updv3.c4_vtCSI)
         l_usd->m_OffCSI |= 0x04;
      if(l_updv3.c4_tCSI)
         l_usd->m_OffCSI |= 0x08;
      if(l_updv3.c4_mtsCSI)
         l_usd->m_OffCSI |= 0x16;
      if(l_updv3.c4_mgCSI)
         l_usd->m_OffCSI |= 0x32;
      if(strlen((char *)l_updv3.gmlc_Address) > 1)
      {
         strcpy((char *)l_usd->m_cs_v_gmlc_Address,(char *)l_updv3.gmlc_Address);
      }
      if(true == l_updv3.cs_LCS_NotSupportedByUE)
      {
         l_usd->m_cs_LCS_SupportedByUE = 0;
      }

   }
   if(l_Version == 2)
   {
      memset(l_usd->m_ActImsi,'\0',sizeof(l_usd->m_ActImsi));
      strncpy((char *)l_usd->m_ActImsi,(char *)l_updv2.imsi,strlen((char *)l_updv2.imsi));
      memset(l_usd->m_lmsi,'\0',sizeof(l_usd->m_lmsi));
      memcpy((char *)l_usd->m_lmsi,(char *)l_updv2.lmsi,4);
      memset(l_usd->m_vlr,'\0',sizeof(l_usd->m_vlr));
      memset(l_usd->m_msc,'\0',sizeof(l_usd->m_msc));
      if(l_OpCode == 2)
      {
         strncpy((char *)l_usd->m_vlr,(char *)l_updv2.vlr+2,strlen((char *)l_updv2.vlr+2));
         strncpy((char *)l_usd->m_msc,(char *)l_updv2.msc+2,strlen((char *)l_updv2.msc+2));
      }
      if(l_OpCode == 57)
      {
         strncpy((char *)l_usd->m_vlr,(char *)l_updv2.vlr,strlen((char *)l_updv2.vlr));
         strncpy((char *)l_usd->m_msc,(char *)l_updv2.msc,strlen((char *)l_updv2.msc));
      }
      l_usd->m_CamPhases = 0;
      l_usd->m_solsa = 0;
      l_usd->m_OffCSI = 0;
      l_usd->m_LongFTN = 0;
      l_usd->m_SuppLCS = 0;
      l_usd->m_ist = 0;
      l_usd->m_SuprChrg = 0;
   }
   if(l_Version == 1)
   {
      memset(l_usd->m_ActImsi,'\0',sizeof(l_usd->m_ActImsi));
      strncpy((char *)l_usd->m_ActImsi,(char *)l_updv1.imsi,strlen((char *)l_updv1.imsi));
      memset(l_usd->m_lmsi,'\0',sizeof(l_usd->m_lmsi));
      memcpy((char *)l_usd->m_lmsi,(char *)l_updv1.lmsi,4);
      memset(l_usd->m_vlr,'\0',sizeof(l_usd->m_vlr));
      strncpy((char *)l_usd->m_vlr,(char *)l_updv1.vlr+2,strlen((char *)l_updv1.vlr+2));
      memset(l_usd->m_msc,'\0',sizeof(l_usd->m_msc));
      strncpy((char *)l_usd->m_msc,(char *)l_updv1.msc+2,strlen((char *)l_updv1.msc+2));
      l_usd->m_CamPhases = 0;
      l_usd->m_solsa = 0;
      l_usd->m_OffCSI = 0;
      l_usd->m_LongFTN = 0;
      l_usd->m_SuppLCS = 0;
      l_usd->m_ist = 0;
      l_usd->m_SuprChrg = 0;
   }
   memset(l_usd->m_Unsupp_Bearer,'0',52);
   //
   //Modified in 1.0.8.0 to update unsupported bearer and tele along with restricted bearer and tele
   //
   //strcpy((char *)l_usd->m_Unsupp_Bearer,(char *)m_isd.m_Unsupp_Bearer);
   int l_i = 0;
   for(l_i = 0;l_i < 52;l_i++)
   {
      if(('1' == m_isd.m_Unsupp_Bearer[l_i] ) || ('1' == m_VLR_Restricted_Bear_Codes[l_i] ))
         l_usd->m_Unsupp_Bearer[l_i] = '1';
   }
   memset(l_usd->m_Unsupp_Tele,'0',32);
   //strcpy((char *)l_usd->m_Unsupp_Tele,(char *)m_isd.m_Unsupp_Tele);
   for(l_i = 0;l_i < 32;l_i++)
   {
      if(('1' == m_isd.m_Unsupp_Tele[l_i]) || ('1' == m_VLR_Restricted_Tele_Codes[l_i]))
         l_usd->m_Unsupp_Tele[l_i] = '1';
   }
   //
   //End Modification
   //
   memset(l_usd->m_Unsupp_SuppServ,'\0',sizeof(l_usd->m_Unsupp_SuppServ));
   strcpy((char *)l_usd->m_Unsupp_SuppServ,(char *)m_isd.m_Unsupp_SS);
   l_usd->m_Unsupp_GenOdb = m_isd.m_Unsupp_ODB;
   if(l_roamInd == 0)
   {
      if(GsmProfile.l_TraceFlag)
      {
         l_usd->m_AtmErrorCode = 0;
      }
      else
      {
         l_usd->m_AtmErrorCode = 999;
      }
   }
   else
   {
      l_usd->m_AtmErrorCode = GsmProfile.l_TraceStatus;
   }
   l_usd->m_roamInd = l_roamInd;
   l_usd->m_mscRest = 0;
   l_usd->m_ssInd = 0;
   l_usd->m_purge = 0;
   l_usd->m_MNRR = 0;
   l_usd->m_MNRF = 0;
   strcpy((char*)l_usd->m_GSM_Seq_id,(char*)m_GSM_Seq_id);
   if((l_OpCode == 57) && ((strcmp((char *)GsmProfile.l_vlrno,"0")) != 0))
      l_usd->m_MNRF = GsmProfile.l_mnrf;
   l_usd->m_RRDUF = 0;
   TLOG(0,0,"Updating Account Id is %s, Network ID is %d in HLR_SUBS_DATA with, Active Msisdn is %s, Active Imsi is %s, Active HLR address is %s, vlr number is %s, msc number is %s, LMSI %02x%02x%02x%02x,IMEISV %s SEQ_ID %s",
         l_AccId,l_usd->m_nwid,l_usd->m_ActMsisdn,l_usd->m_ActImsi,l_usd->m_hlr,l_usd->m_vlr,l_usd->m_msc,l_usd->m_lmsi[0],l_usd->m_lmsi[1],l_usd->m_lmsi[2],l_usd->m_lmsi[3],l_usd->m_IMEISV,l_usd->m_GSM_Seq_id);
   TLOG(0,0,"MSC Area Restricted %d,Chk SS Indicator %d, Purge_Status %d, MNRR %d,MNRF %d, RRDUF %d, Roam Ind %d, Msisdn Type %d,Partner Network ID is %d, Unsupp_Bearer_Code %s, Unsupp_Tele_Code %s,Unsupp_SS_Code %s,Unsupp_ODB %ld, ATM_Err_Code %d LCS_SupportedBy_UE %d, V_GMLC_Addr %s"
         ,l_usd->m_mscRest,l_usd->m_ssInd,l_usd->m_purge,l_usd->m_MNRR,l_usd->m_MNRF,l_usd->m_RRDUF,l_usd->m_roamInd,l_usd->m_MsisdnTyp,l_usd->m_pnwid,l_usd->m_Unsupp_Bearer,l_usd->m_Unsupp_Tele,l_usd->m_Unsupp_SuppServ,l_usd->m_Unsupp_GenOdb,l_usd->m_AtmErrorCode,l_usd->m_cs_LCS_SupportedByUE,l_usd->m_cs_v_gmlc_Address);
   TLOG(0,0,"Camel Phase support %d, Solsa %d, IST %d, Super Chrg %d, LongFTN  support %d,Supported LCS %d, Offer CAMEL 4 CSI %d",l_usd->m_CamPhases,l_usd->m_solsa,l_usd->m_ist,l_usd->m_SuprChrg,l_usd->m_LongFTN,l_usd->m_SuppLCS,l_usd->m_OffCSI);

   l_usd->m_cb = this;
   g_act.execute(l_usd);
}

void CtxtUpdateLocation::UpdateUpdFailData(int l_UserDlgId)
{
   if(true == m_fIsd)
   {
      LLOG(0,0,"Full ISD indicator set NOT updating failure case subs data... sending CL");
      sendCLforFupd();
      return;
   }
   DLOG(0,0,"Calling the procedure to update GSM data");
   if(m_TrapReqd)
   {
      g_si.sendSnmpTrap(g_UpdateLocationGsmTrap, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL);
   }
   WLOG(0,0,"Calling the procedure on Update Location Failure for Dialog Id %d, Account ID %s ",l_UserDlgId,l_AccId);
   l_state = m_usdf;
   UpdateVLRData *l_usd = new UpdateVLRData();
   l_usd->m_UserDlgId = l_UserDlgId;
   memset(l_usd->m_AccId,'\0',sizeof(l_usd->m_AccId));
   strncpy((char *)l_usd->m_AccId,(char *)l_AccId,strlen((char *)l_AccId));
   l_usd->m_nwid = l_nwId;
   l_usd->m_pnwid = 0;
   l_usd->m_MsisdnTyp = 0;
   memset(l_usd->m_ActMsisdn,'\0',sizeof(l_usd->m_ActMsisdn));
   memset(l_usd->m_ActImsi,'\0',sizeof(l_usd->m_ActImsi));
   if(l_Version == 3)
   {
      strncpy((char *)l_usd->m_ActImsi,(char *)l_updv3.imsi,strlen((char *)l_updv3.imsi));
   }
   if(l_Version == 2)
   {
      strncpy((char *)l_usd->m_ActImsi,(char *)l_updv2.imsi,strlen((char *)l_updv2.imsi));
   }
   if(l_Version == 1)
   {
      strncpy((char *)l_usd->m_ActImsi,(char *)l_updv1.imsi,strlen((char *)l_updv1.imsi));
   }
   memset(l_usd->m_IMEISV,'\0',sizeof(l_usd->m_IMEISV));
   strcpy((char*)l_usd->m_IMEISV,(char*)GsmProfile.l_imeisv); // Added in 1.0.8.0 to update back old IMEI on Failure


   //Modified in HLR 1.0.8.0, for Deallocation on MSISDN on First UL failure for Dynamic case and Update for Fetched data only
   strncpy((char *)l_usd->m_ActMsisdn,(char *)l_actMsisdn,strlen((char *)l_actMsisdn));
   l_usd->m_FirstUl = m_FirstUlFlag;
   l_usd->m_AllocStatus = m_MsisdnAllocStatus;
   l_usd->m_DeallocMsisdn = g_MmConfigReaderObj->m_Dealloc_Msisdn_On_Fail;
   if((m_FirstUlFlag == 1) && (m_MsisdnAllocStatus == 1) && (g_MmConfigReaderObj->m_Dealloc_Msisdn_On_Fail == 1))
   {
      m_tdr.setString(TDR_INDEX_MM_FIRST_UL," "); 
      m_tdr.setString(TDR_INDEX_MM_MSISDN_ALLOC_STATUS,"D");
      m_tdr.setString(TDR_INDEX_REQUEST_MSISDN," ");
      m_tdr.setString(TDR_INDEX_MM_PRIMARY_MSISDN," ");
      char tmp[200];
      snprintf(tmp,sizeof(tmp),"First UL Failed,Deallocating MSISDN %s restoring Uploaded MSISDN %s",l_actMsisdn,m_UploadedMsisdn);
      m_tdr.setString(TDR_INDEX_OAM_FREE_FORMAT_DATA,tmp);
      WLOG(0,0,"First UL Failed,Deallocating MSISDN [%s] and Restoring with Uploaded MSISDN [%s]",l_actMsisdn,m_UploadedMsisdn); 
   }
   strcpy((char*)l_usd->m_GSM_Seq_id,(char*)m_GSM_Seq_id);
   //End Modified in HLR 1.0.8.0


   memset(l_usd->m_hlr,'\0',sizeof(l_usd->m_hlr));
   strncpy((char *)l_usd->m_hlr,(char *)l_hlrAddr,strlen((char *)l_hlrAddr));
   memset(l_usd->m_lmsi,'\0',sizeof(l_usd->m_lmsi));
   memset(l_usd->m_vlr,'\0',sizeof(l_usd->m_vlr));
   memset(l_usd->m_msc,'\0',sizeof(l_usd->m_msc));
   memset(l_usd->m_Unsupp_Tele,'\0',sizeof(l_usd->m_Unsupp_Tele));
   memset(l_usd->m_Unsupp_Tele,'0',32);
   memset(l_usd->m_Unsupp_SuppServ,'\0',sizeof(l_usd->m_Unsupp_SuppServ));
   l_usd->m_Unsupp_GenOdb = 0;//m_isd.m_Unsupp_ODB;
   if(GsmProfile.l_TraceFlag)
   {
      l_usd->m_AtmErrorCode = m_TraceErrorCode;
   }
   else
   {
      l_usd->m_AtmErrorCode = 999;
   }
   l_usd->m_roamInd = 0;
   l_usd->m_mscRest = 0; //changed in 1.0.7.0 to set "Not Restricted" always
   l_usd->m_ssInd = 0;
   l_usd->m_purge = 0;
   l_usd->m_MNRR = 0;
   l_usd->m_MNRF = 1;
   l_usd->m_RRDUF = 0;
   l_usd->m_CamPhases = 0;
   l_usd->m_solsa = 0;
   l_usd->m_OffCSI = 0;
   l_usd->m_LongFTN = 0;
   l_usd->m_SuppLCS = 0;
   l_usd->m_ist = 0;
   l_usd->m_SuprChrg = 0;

   TLOG(0,0,"Updating Account Id is %s, Network ID is %d in HLR_SUBS_DATA with, Active Msisdn is %s, Active Imsi is %s, Active HLR address is %s, vlr number is %s, msc number is %s, LMSI %s Trace Error %d SEQ_ID %s",
         l_AccId,l_usd->m_nwid,l_usd->m_ActMsisdn,l_usd->m_ActImsi,l_usd->m_hlr,l_usd->m_vlr,l_usd->m_msc,l_usd->m_lmsi,l_usd->m_AtmErrorCode,l_usd->m_GSM_Seq_id);
   TLOG(0,0,"MSC Area Restricted %d,Chk SS Indicator %d, Purge_Status %d, MNRR %d,MNRF %d, RRDUF %d, Roam Ind %d, Msisdn Type %d,Partner Network ID is %d",l_usd->m_mscRest,l_usd->m_ssInd,l_usd->m_purge,l_usd->m_MNRR,l_usd->m_MNRF,l_usd->m_RRDUF,l_usd->m_roamInd,l_usd->m_MsisdnTyp,l_usd->m_pnwid);
   TLOG(0,0,"Camel Phase support %d, Solsa %d, IST %d, Super Chrg %d, LongFTN  support %d,Supported LCS %d, Offer CAMEL 4 CSI %d",l_usd->m_CamPhases,l_usd->m_solsa,l_usd->m_ist,l_usd->m_SuprChrg,l_usd->m_LongFTN,l_usd->m_SuppLCS,l_usd->m_OffCSI);

   l_usd->m_cb = this;
   g_act.execute(l_usd);
   /*if(true == m_fIsd)
   {
      LLOG(0,0,"for FullISD Update default subs data called");
      sendCLforFupd();
   }*/
}
#endif

#if 1 // UpdateLocationResponse
void CtxtUpdateLocation::updLocResV1(int l_UserDlgId)
{
   MapSpecificResult l_result(l_UserDlgId, MAP_OP_CODE_updateLocation, MAP_V1);
   DECLARE(OMAP1_UpdateLocationRes,l_res,1,"OMAP1_UpdateLocationRes",DeclareFunc);
   u8 l_NwHlrAddr[21];
   memset(l_NwHlrAddr,'\0',sizeof(l_NwHlrAddr));
   if(g_MmConfigReaderObj->m_GT_Transtlation_Reqd==1)
   {
      DLOG(0,0,"GT_Transtlation_Reqd Enabled");
      GetNetworkHlrAddr(l_NwHlrAddr,l_hlrAddr);
   }
   else
   {
      DLOG(0,0,"GT_Transtlation_Reqd not Enabled");
      strcpy((char *)l_NwHlrAddr,(char *)l_hlrAddr);
   }
   u8 hlrnum[21];
   memset(hlrnum,'\0',sizeof(hlrnum));
   strncpy((char *)hlrnum,"19",2);
   strncat((char *)hlrnum,(char *)l_NwHlrAddr,strlen((char *)l_NwHlrAddr));
   int len1 = strlen((char *)hlrnum);
   l_res->length = (len1+1)/2;
   StringToBCD(l_res->value,hlrnum,len1);   
   LLOG(0, 0, "Sending UpdateLocation Response for Dlg id %d  HLR Addr %s",l_UserDlgId,l_NwHlrAddr);
   l_result.m_structBuffer = (void*) l_res;

   g_sc.sendMsg(this, &l_result);
   CloseReq(l_UserDlgId);
   m_tdr.setString(TDR_INDEX_ERR_CODE,"");
   if(m_isd.m_IsdResp_With_Unsupp_Service_Rcvd)
   {
      TLOG(0,0,"ISD response rcvd with Unsupported datas,Callin Update Query");
      UpdateGsmData(l_UserDlgId);
   }
}

void CtxtUpdateLocation::updLocResV2(int l_UserDlgId)
{
   MapSpecificResult l_result(l_UserDlgId, MAP_OP_CODE_updateLocation, MAP_V2);
   DECLARE(OMAP2_UpdateLocationRes,l_res,2,"OMAP2_UpdateLocationRes",DeclareFunc);
   l_res->choice = OMAP2_extensibleUpdateLocationRes_chosen;

   u8 l_NwHlrAddr[21];
   memset(l_NwHlrAddr,'\0',sizeof(l_NwHlrAddr));
   if(g_MmConfigReaderObj->m_GT_Transtlation_Reqd==1)
   {
      DLOG(0,0,"GT_Transtlation_Reqd Enabled");
      GetNetworkHlrAddr(l_NwHlrAddr,l_hlrAddr);
   }
   else
   {
      DLOG(0,0,"GT_Transtlation_Reqd not Enabled");
      strcpy((char *)l_NwHlrAddr,(char *)l_hlrAddr);
   }
   u8 hlrnum[21];
   memset(hlrnum,'\0',sizeof(hlrnum));
   strncpy((char *)hlrnum,"19",2);
   strncat((char *)hlrnum,(char *)l_NwHlrAddr,strlen((char *)l_NwHlrAddr));

   LLOG(0, 0, "Sending UpdateLocation Response for Dlg id %d  HLR Addr %s",l_UserDlgId,l_NwHlrAddr);
   int len1 = strlen((char *)hlrnum);
   StringToBCD(l_res->u.extensibleUpdateLocationRes.hlr_Number.value,hlrnum,len1);
   l_res->u.extensibleUpdateLocationRes.hlr_Number.length = (len1+1)/2;
   l_result.m_structBuffer = (void*) l_res;
   g_sc.sendMsg(this, &l_result);
   CloseReq(l_UserDlgId);   
   m_tdr.setString(TDR_INDEX_ERR_CODE,"");
   if(m_isd.m_IsdResp_With_Unsupp_Service_Rcvd)
   {
      TLOG(0,0,"ISD response rcvd with Unsupported datas,Callin Update Query");
      UpdateGsmData(l_UserDlgId);
   }
}

void CtxtUpdateLocation::updLocResV3(int l_UserDlgId)
{
   if(false == m_fIsd)
   {
      MapSpecificResult l_result(l_UserDlgId, MAP_OP_CODE_updateLocation, MAP_V3);
      DECLARE(OMAP3_UpdateLocationRes,l_res,3,"OMAP3_UpdateLocationRes",DeclareFunc);
      u8 l_NwHlrAddr[21];
      memset(l_NwHlrAddr,'\0',sizeof(l_NwHlrAddr));
      if(g_MmConfigReaderObj->m_GT_Transtlation_Reqd==1)
      {
         DLOG(0,0,"GT_Transtlation_Reqd Enabled");
         GetNetworkHlrAddr(l_NwHlrAddr,l_hlrAddr);
      }
      else
      {
         DLOG(0,0,"GT_Transtlation_Reqd not Enabled");
         strcpy((char *)l_NwHlrAddr,(char *)l_hlrAddr);
      }
      u8 hlrnum[21];
      memset(hlrnum,'\0',sizeof(hlrnum));
      strncpy((char *)hlrnum,"19",2);
      strncat((char *)hlrnum,(char *)l_NwHlrAddr,strlen((char *)l_NwHlrAddr));
      LLOG(0, 0, "Sending UpdateLocation Response for Dlg id %d HLR Addr %s",l_UserDlgId,l_NwHlrAddr);
      int len = strlen((char *)hlrnum);
      l_res->hlr_Number.length = (len+1)/2;

      StringToBCD(l_res->hlr_Number.value,hlrnum,len);
      l_result.m_structBuffer = (void*) l_res;
      g_sc.sendMsg(this, &l_result);

      CloseReq(l_UserDlgId);   
   }
   else
   {
      LLOG(0,0,"Closing full ISD");
      m_tdr.setString(TDR_INDEX_ERR_CODE,"");
      MapCloseReq l_closeReq(l_UserDlgId);
      g_sc.sendMsg(this, &l_closeReq);
      return;
   }
   m_tdr.setString(TDR_INDEX_ERR_CODE,"");
   if(m_isd.m_IsdResp_With_Unsupp_Service_Rcvd)
   {
      TLOG(0,0,"ISD response rcvd with Unsupported datas,Callin Update Query");
      UpdateGsmData(l_UserDlgId);
   }
}
#endif

#if 1 //RestoreDataResp
void CtxtUpdateLocation::RsdRespV3(int l_UserDlgId,int mnrf)
{
   DLOG(0,0,"Sending Restore data response for Dialog Id %d",l_UserDlgId);
   MapSpecificResult l_result(l_UserDlgId, MAP_OP_CODE_restoreData, MAP_V3);
   DECLARE(OMAP3_RestoreDataRes,l_res,3,"OMAP3_RestoreDataRes",DeclareFunc);
   l_res->bit_mask = 0;

   u8 l_NwHlrAddr[21];
   memset(l_NwHlrAddr,'\0',sizeof(l_NwHlrAddr));
   if(g_MmConfigReaderObj->m_GT_Transtlation_Reqd==1)
   {
      DLOG(0,0,"GT_Transtlation_Reqd Enabled");
      GetNetworkHlrAddr(l_NwHlrAddr,l_hlrAddr);
   }
   else
   {
      DLOG(0,0,"GT_Transtlation_Reqd not Enabled");
      strcpy((char *)l_NwHlrAddr,(char *)l_hlrAddr);
   }
   u8 hlrnum[21];
   memset(hlrnum,'\0',sizeof(hlrnum));
   strncpy((char *)hlrnum,"19",2);
   strncat((char *)hlrnum,(char *)l_NwHlrAddr,strlen((char *)l_NwHlrAddr));



   LLOG(0,0,"HLR Address in Restore Data Response is %s",l_NwHlrAddr);

   int len = strlen((char *)hlrnum);
   l_res->hlr_Number.length = (len+1)/2;
   StringToBCD(l_res->hlr_Number.value,hlrnum,len);
   if((mnrf) && ((strncmp((char *)GsmProfile.l_vlrno,"0",1)) != 0) )
   {
      l_res->bit_mask |= OMAP3_msNotReachable_present;
   }
   l_result.m_structBuffer = (void*) l_res;
   g_sc.sendMsg(this, &l_result);

   CloseReq(l_UserDlgId);
   m_tdr.setString(TDR_INDEX_ERR_CODE,"");
   if(m_isd.m_IsdResp_With_Unsupp_Service_Rcvd)
   {
      TLOG(0,0,"ISD response rcvd with Unsupported datas,Callin Update Query");
      UpdateGsmData(l_UserDlgId);
   }
}

void CtxtUpdateLocation::RsdRespV2(int l_UserDlgId,int mnrf)
{
   DLOG(0,0,"Sending Restore data response for Dialog Id %d",l_UserDlgId);
   MapSpecificResult l_result(l_UserDlgId, MAP_OP_CODE_restoreData, MAP_V2);
   DECLARE(OMAP2_RestoreDataRes,l_res,2,"OMAP2_RestoreDataRes",DeclareFunc);
   l_res->bit_mask = 0;

   u8 l_NwHlrAddr[21];
   memset(l_NwHlrAddr,'\0',sizeof(l_NwHlrAddr));
   if(g_MmConfigReaderObj->m_GT_Transtlation_Reqd==1)
   {
      DLOG(0,0,"GT_Transtlation_Reqd Enabled");
      GetNetworkHlrAddr(l_NwHlrAddr,l_hlrAddr);
   }
   else
   {
      DLOG(0,0,"GT_Transtlation_Reqd not Enabled");
      strcpy((char *)l_NwHlrAddr,(char *)l_hlrAddr);
   }
   DLOG(0,0,"GT_Translation_Required Not Enabled");
   u8 hlrnum[21];
   memset(hlrnum,'\0',sizeof(hlrnum));
   strncpy((char *)hlrnum,"19",2);
   strncat((char *)hlrnum,(char *)l_NwHlrAddr,strlen((char *)l_NwHlrAddr));

   int len = strlen((char *)hlrnum);
   l_res->hlr_Number.length = (len+1)/2;
   StringToBCD(l_res->hlr_Number.value,hlrnum,len);
   LLOG(0,0,"HLR Address in Restore Data Response is %s",l_NwHlrAddr);
   if((mnrf) && ((strncmp((char *)GsmProfile.l_vlrno,"0",1)) != 0) )
   {
      l_res->bit_mask |= OMAP2_msNotReachable_present;
   }
   l_result.m_structBuffer = (void*) l_res;
   g_sc.sendMsg(this, &l_result);
   CloseReq(l_UserDlgId);
   m_tdr.setString(TDR_INDEX_ERR_CODE,"");
   if(m_isd.m_IsdResp_With_Unsupp_Service_Rcvd)
   {
      TLOG(0,0,"ISD response rcvd with Unsupported datas,Callin Update Query");
      UpdateGsmData(l_UserDlgId);
   }
}
#endif

void CtxtUpdateLocation::HandleError(int l_UserDlgId)
{
   DLOG(0,0,"Inside Handle Error");
   if(l_Version == 3)
   {
      DLOG(0,0,"Handling Error for Dialog ID [%d], msg processed was version 3,closing all transaction for it",l_UserDlgId);
      //RetErrorV3(l_UserDlgId,1)
      CloseReq(l_UserDlgId);
   }
   else if(l_Version == 2)
   {
      DLOG(0,0,"Handling Error for Dialog ID [%d], msg processed was version 2,closing all transaction for it",l_UserDlgId);
      CloseReq(l_UserDlgId);
   }
   else
   {
      DLOG(0,0,"Handling Error for Dialog ID [%d], msg processed was version 1,closing all transaction for it",l_UserDlgId);
      CloseReq(l_UserDlgId);
   }
}

void CtxtUpdateLocation::sendCheckSS()
{
   //DLOG(0,0,"\n\nSending Check SS Indication\n--------------------------------\n");
   int l_SSDlgId = g_sc.getNewDialogue();
   LLOG(0,0,"Sending Open req for Check SS indication");
   MapOpenReq l_mapOpenReq(l_SSDlgId,(EMapVersion)l_Version); //MAP ver as received in UPD Req
   l_mapOpenReq.m_ApplCntxt = MAP_AC_CODE_networkLocUp;
   //TODO Add  HLR adderess
   configureSccpAddress(&l_mapOpenReq.m_OrigAddr,L_ROUTE_ON_GT,1002,g_ConfigData->i_NgConfigData.m_selfAddress.ssn,(char*)l_hlrAddr);
   if(l_Version == 3)
      configureSccpAddress(&l_mapOpenReq.m_DestAddr,L_ROUTE_ON_GT,1002,8,(char *)l_updv3.vlr+2);
   if(l_Version == 2)
      configureSccpAddress(&l_mapOpenReq.m_DestAddr,L_ROUTE_ON_GT,1002,8,(char *)l_updv2.vlr+2);
   if(l_Version == 1)
      configureSccpAddress(&l_mapOpenReq.m_DestAddr,L_ROUTE_ON_GT,1002,8,(char *)l_updv1.vlr+2);
   g_sc.sendMsg(this, &l_mapOpenReq);

   LLOG(0,0,"Sending Check SS Indication for Dialog id %d",l_SSDlgId);
   MapSpecificRequest l_request(l_SSDlgId, MAP_OP_CODE_forwardCheckSSIndication,(EMapVersion)l_Version);
   g_sc.sendMsg(this, &l_request);
   ContinueReq(l_SSDlgId);
   DLOG(0,0,"Forward check SS indication sent on Dlg ID %d",l_SSDlgId);
}

#if 1//Return Error
void CtxtUpdateLocation::RetErrorV1(int l_UserDlgId,int ErrorCode)
{
   DLOG(0,0,"Returning Error %d",ErrorCode);
   //m_tdr.setBool(&this->m_tdr,TDR_MSGSTATUS_INDEX,false);
   switch(ErrorCode)
   {
      case 1://SystemFailure
         {
            WLOG(0,0,"Sending System Failure");
            OMAP1_SystemFailure l_sfp;
            memset(&l_sfp,'\0',sizeof(l_sfp));
            l_sfp.choice = OMAP1_localValue_chosen;
            l_sfp.u.localValue = 1;
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_systemFailure, MAP_V1, NULL);
            g_sc.sendMsg(this, &l_userError);
            CloseReq(l_UserDlgId);
            m_tdr.setInteger(TDR_INDEX_ERR_CODE,34);
            //ContinueReq(l_UserDlgId);
         }
         break;
      case 2://UnknownSubscriber
         {
            WLOG(0,0,"Unknown subscriber Sending error Unknown Subscriber - IMSI unknown");
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_unknownSubscriber, MAP_V1, NULL);
            g_sc.sendMsg(this, &l_userError);
            CloseReq(l_UserDlgId);
            m_tdr.setInteger(TDR_INDEX_ERR_CODE,1);
            //ContinueReq(l_UserDlgId);
         }
         break;
      case 3://DataMissing
         {
            WLOG(0,0,"Sending Data missing error");
            OMAP1_DataMissing l_dmp;
            memset(&l_dmp,'\0', sizeof(l_dmp));
            l_dmp.choice = OMAP1_localValue_chosen;
            l_dmp.u.localValue = 1;
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_dataMissing, MAP_V1, NULL);
            g_sc.sendMsg(this, &l_userError);
            CloseReq(l_UserDlgId);
            m_tdr.setInteger(TDR_INDEX_ERR_CODE,35);
            //ContinueReq(l_UserDlgId);
         }
         break;
      case 4://UnexpectedData
         {
            WLOG(0,0,"Sending Unexpected data received");
            OMAP1_UnexpectedDataValue l_udp;
            memset(&l_udp,'\0',sizeof(l_udp));
            l_udp.choice = OMAP1_localValue_chosen;
            l_udp.u.localValue = 1;
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_unexpectedData, MAP_V1, NULL);
            g_sc.sendMsg(this, &l_userError);
            CloseReq(l_UserDlgId);
            m_tdr.setInteger(TDR_INDEX_ERR_CODE,36);
            //ContinueReq(l_UserDlgId);
         }
         break;
      case 5://RoamingNotAllowed_plmn
         {
            WLOG(0,0,"Sending Roaming not allowed - Reason plmnroaming not allowed");
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_roamingNotAllowed, MAP_V1, NULL);
            g_sc.sendMsg(this, &l_userError);
            m_tdr.setInteger(TDR_INDEX_ERR_CODE,8);
            CloseReq(l_UserDlgId);            
         }
         break;
      case 6://RoamingNotAllowed_plmn
         {
            WLOG(0,0,"Sending Roaming not allowed - reason ODB");
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_roamingNotAllowed, MAP_V1, NULL);
            g_sc.sendMsg(this, &l_userError);
            m_tdr.setInteger(TDR_INDEX_ERR_CODE,8);
            CloseReq(l_UserDlgId);
         }
         break;
      default:
         CLOG(0,0,"Error while processing Return code %d",ErrorCode);
         break;
   }
}

void CtxtUpdateLocation::RetErrorV2(int l_UserDlgId,int ErrorCode)
{
   DLOG(0,0,"Returning Error %d",ErrorCode);
   //m_tdr.setBool(&this->m_tdr,TDR_MSGSTATUS_INDEX,false);
   switch(ErrorCode)
   {
      case 1://SystemFailure
         {
            WLOG(0,0,"Sending System Failure");
            OMAP2_SystemFailureParam l_sfp;
            memset(&l_sfp,'\0',sizeof(l_sfp));
            l_sfp.choice = OMAP2_networkResource_chosen;
            l_sfp.u.networkResource = OMAP2_hlr;
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_systemFailure, MAP_V2, &l_sfp);
            g_sc.sendMsg(this, &l_userError);
            CloseReq(l_UserDlgId);
            m_tdr.setInteger(TDR_INDEX_ERR_CODE,34);
            //ContinueReq(l_UserDlgId);
         }
         break;
      case 2://UnknownSubscriber
         {
            WLOG(0,0,"Unknown subscriber Sending error Unknown Subscriber - IMSI unknown");
            OMAP2_UnknownSubscriberParam l_usp;
            memset(&l_usp,'\0',sizeof(l_usp));
            l_usp.bit_mask = OMAP2_unknownSubscriberDiagnostic_present;
            l_usp.unknownSubscriberDiagnostic = OMAP2_imsiUnknown;
            //MapUserError l_userError(l_UserDlgId, MAP_ERROR_unknownSubscriber, MAP_V2, &l_usp);
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_unknownSubscriber, MAP_V2, NULL);
            g_sc.sendMsg(this, &l_userError);
            CloseReq(l_UserDlgId);
            m_tdr.setInteger(TDR_INDEX_ERR_CODE,1);
            //ContinueReq(l_UserDlgId);
         }
         break;
      case 3://DataMissing
         {
            WLOG(0,0,"Sending Data missing on Dialog ID %d",l_UserDlgId);
            OMAP2_DataMissingParam l_dmp;
            memset(&l_dmp,'\0', sizeof(l_dmp));
            //l_dmp.choice
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_dataMissing, MAP_V2, NULL);
            g_sc.sendMsg(this, &l_userError);
            CloseReq(l_UserDlgId);
            m_tdr.setInteger(TDR_INDEX_ERR_CODE,35);
            //ContinueReq(l_UserDlgId);
         }
         break;
      case 4://UnexpectedData
         {
            WLOG(0,0,"Sending Unexpected data");
            OMAP2_UnexpectedDataParam l_udp;
            memset(&l_udp,'\0',sizeof(l_udp));
            //l_udp.choice
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_unexpectedData, MAP_V2, NULL);
            g_sc.sendMsg(this, &l_userError);
            CloseReq(l_UserDlgId);
            m_tdr.setInteger(TDR_INDEX_ERR_CODE,36);
            //ContinueReq(l_UserDlgId);
         }
         break;
      case 5://RoamingNotAllowed_plmn
         {
            WLOG(0,0,"Sending Roaming not allowed - Reason plmnroaming not allowed");
            OMAP2_RoamingNotAllowedParam l_rna;
            memset(&l_rna,'\0',sizeof(l_rna));
            l_rna.roamingNotAllowedCause = OMAP2_plmnRoamingNotAllowed;
            //l_udp.choice
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_roamingNotAllowed, MAP_V2, &l_rna);
            g_sc.sendMsg(this, &l_userError);
            CloseReq(l_UserDlgId);
            m_tdr.setInteger(TDR_INDEX_ERR_CODE,8);
            //ContinueReq(l_UserDlgId);
         }
         break;
      case 6://RoamingNotAllowed_odb
         {
            WLOG(0,0,"Sending Roaming not allowed - reason ODB");
            OMAP2_RoamingNotAllowedParam l_rna;
            memset(&l_rna,'\0',sizeof(l_rna));
            l_rna.roamingNotAllowedCause = OMAP2_RoamingNotAllowedCause_operatorDeterminedBarring;
            //l_udp.choice
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_roamingNotAllowed, MAP_V2, &l_rna);
            g_sc.sendMsg(this, &l_userError);
            CloseReq(l_UserDlgId);
            m_tdr.setInteger(TDR_INDEX_ERR_CODE,8);
            //ContinueReq(l_UserDlgId);
         }
         break;
      default:
         CLOG(0,0,"Error while processing Return code %d",ErrorCode);
         break;
   }
}

void CtxtUpdateLocation::RetErrorV3(int l_UserDlgId,int ErrorCode)
{ 
   DLOG(0,0,"Returning Error %d",ErrorCode);
   //m_tdr.setBool(&this->m_tdr,TDR_MSGSTATUS_INDEX,false);
   switch(ErrorCode)
   {
      case 1://SystemFailure
         {
            WLOG(0,0,"Sending System Failure");
            OMAP3_SystemFailureParam l_sfp;
            memset(&l_sfp,'\0',sizeof(l_sfp));
            l_sfp.choice = OMAP3_extensibleSystemFailureParam_chosen; 
            l_sfp.u.extensibleSystemFailureParam.bit_mask = OMAP3_networkResource_present;
            l_sfp.u.extensibleSystemFailureParam.networkResource = OMAP3_hlr;
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_systemFailure, MAP_V3, &l_sfp);
            //MapUserError l_userError(l_UserDlgId, MAP_ERROR_systemFailure, MAP_V3, NULL);
            g_sc.sendMsg(this, &l_userError);
            CloseReq(l_UserDlgId);            
            m_tdr.setInteger(TDR_INDEX_ERR_CODE,34);
         }
         break;
      case 2://UnknownSubscriber
         {
            WLOG(0,0,"Sending error Unknown Subscriber - IMSI unknown");
            OMAP3_UnknownSubscriberParam l_usp;
            memset(&l_usp,'\0',sizeof(l_usp));
            l_usp.bit_mask = OMAP3_unknownSubscriberDiagnostic_present;
            l_usp.unknownSubscriberDiagnostic = OMAP3_imsiUnknown;
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_unknownSubscriber, MAP_V3, &l_usp);
            g_sc.sendMsg(this, &l_userError);
            CloseReq(l_UserDlgId);
            m_tdr.setInteger(TDR_INDEX_ERR_CODE,1);
            //ContinueReq(l_UserDlgId);
         }
         break;
      case 3://DataMissing
         {            
            WLOG(0,0,"Sending Data missing on Dialog ID %d",l_UserDlgId);
            OMAP3_DataMissingParam l_dmp;
            memset(&l_dmp,'\0', sizeof(l_dmp));
            //l_dmp.choice
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_dataMissing, MAP_V3, NULL);
            g_sc.sendMsg(this, &l_userError);
            CloseReq(l_UserDlgId);
            m_tdr.setInteger(TDR_INDEX_ERR_CODE,35);
            //ContinueReq(l_UserDlgId);
         }
         break;
      case 4://UnexpectedData
         {
            WLOG(0,0,"Sending Unexpected data");
            OMAP3_UnexpectedDataParam l_udp;
            memset(&l_udp,'\0',sizeof(l_udp));
            //l_udp.choice
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_unexpectedData, MAP_V3, NULL);
            g_sc.sendMsg(this, &l_userError);
            CloseReq(l_UserDlgId);
            m_tdr.setInteger(TDR_INDEX_ERR_CODE,36);
            //ContinueReq(l_UserDlgId);
         }
         break;
      case 5://RoamingNotAllowed_plmn
         {
            WLOG(0,0,"Sending Roaming not allowed - Reason plmnroaming not allowed");
            OMAP3_RoamingNotAllowedParam l_rna;
            memset(&l_rna,'\0',sizeof(l_rna));
            l_rna.roamingNotAllowedCause = OMAP3_plmnRoamingNotAllowed;
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_roamingNotAllowed, MAP_V3, &l_rna);
            g_sc.sendMsg(this, &l_userError);
            m_tdr.setInteger(TDR_INDEX_ERR_CODE,8);
            CloseReq(l_UserDlgId);            
         }
         break;
      case 6://RoamingNotAllowed_odb
         {
            WLOG(0,0,"Sending Roaming not allowed - reason ODB");
            OMAP3_RoamingNotAllowedParam l_rna;
            memset(&l_rna,'\0',sizeof(l_rna));
            l_rna.roamingNotAllowedCause = OMAP3_RoamingNotAllowedCause_operatorDeterminedBarring;
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_roamingNotAllowed, MAP_V3, &l_rna);
            g_sc.sendMsg(this, &l_userError);
            CloseReq(l_UserDlgId);           
            m_tdr.setInteger(TDR_INDEX_ERR_CODE,8);
         }
         break;
      default:
         CLOG(0,0,"Error found while processing Return code %d",ErrorCode);
         break;
   }
}
#endif

void CtxtUpdateLocation::CloseReq(int l_UserDlgId)
{
   TLOG(0, 0, "Sending MAP_Close");
   MapCloseReq l_closeReq(l_UserDlgId);
   g_sc.sendMsg(this, &l_closeReq);
}

void CtxtUpdateLocation::ContinueReq(int l_UserDlgId)
{
   TLOG(0, 0, "Sending Delimiter");
   MapDelimiterReq l_del(l_UserDlgId);
   g_sc.sendMsg(this, &l_del);
}


bool CtxtUpdateLocation::startProcessing(InterModuleData *p_imd,bool &p_DeleteFlag)
{
   DLOG(0, 0, "Start of CtxtUpdateLocation::startProcessing function, Delete flag %d",p_DeleteFlag);
   LLOG(0,0,"InterModule data for Update Location Received from [%s] Xml Request [%s]", p_imd->m_OriginatorModule,(NULL == p_imd->m_Parameters)?"":p_imd->m_Parameters);

   if(NULL == p_imd->m_Parameters)
   {
      CLOG(0,0,"p_imd->m_Parameters NULL returning");
      return false;
   }

   m_fIsd = true;
   memset(&l_updv3,'\0',sizeof(l_updv3));

   char *l_check = NULL;
   l_check = strchr(p_imd->m_Parameters, ':');
   if(l_check == NULL)
   {
      TLOG(0,0,"Transaction ID not present");
      //return false;
      //m_DataString.assign(&p_imd->m_Parameters[0]);
      m_DataString.assign(p_imd->m_Parameters);
   }
   else
   {
      strncpy(m_TransId,p_imd->m_Parameters, strlen(p_imd->m_Parameters)-strlen(l_check));
      LLOG(0,0,"Transaction ID :%s received from OAM", m_TransId);

      //m_DataString.assign(&p_imd->m_Parameters[strlen(p_imd->m_Parameters)-strlen(l_check)]);
      m_DataString.assign(&p_imd->m_Parameters[strlen(p_imd->m_Parameters)-strlen(l_check)]);
      m_tdr.setString(TDR_INDEX_OAM_TRANSACTION_ID, m_TransId);
   }

   //m_tdr.setOpCode(110);
   //m_tdr.setContextId("MMMISD");
   m_tdr.setOriginatingModule("GSMISD");
   string l_imsi = ConfigReader::readValue(m_DataString, "IMSI");
   if(1 > l_imsi.length())
   {
      CLOG(0,0,"Unknown IMSI");
      return false;
   }
   m_tdr.setChar(TDR_INDEX_REQUEST_TYPE,'I'); 
   m_tdr.setString(TDR_INDEX_REQUEST_IMSI,(char*)l_imsi.c_str());

   string l_vlrno = ConfigReader::readValue(m_DataString, "VLR_NUM");
   if(1 > l_vlrno.length())
   {
      CLOG(0,0,"Unknown VLR");
      return false;
   }
   m_tdr.setString(TDR_INDEX_VLR_ADDRESS,(char*)l_vlrno.c_str());

   string l_mscno = ConfigReader::readValue(m_DataString, "MSC_NUM");
   if(1 > l_mscno.length())
   {
      CLOG(0,0,"Unknown MSC");
      return false;
   }
   m_tdr.setString(TDR_INDEX_MSC_ADDRESS,(char*)l_mscno.c_str());

   string l_hlrno = ConfigReader::readValue(m_DataString, "ORIG_ADDRESS");
   if(1 > l_hlrno.length())
   {
      CLOG(0,0,"Unknown HLR address");
      return false;
   }

   string l_lmsi = ConfigReader::readValue(m_DataString, "LMSI");
   DLOG(0,0,"LMSI %s, len %d",l_lmsi.c_str(),l_lmsi.length());
   if(1 > l_lmsi.length())
   {
      TLOG(0,0,"LMSI not present");
   }
   else
   {
      memcpy(l_updv3.lmsi,l_lmsi.c_str(),l_lmsi.length());
      m_tdr.setHex(TDR_INDEX_LMSI,(char *)l_updv3.lmsi,l_lmsi.length());
   }

   snprintf((char*)l_updv3.imsi,sizeof(l_updv3.imsi),"%s",(char*)l_imsi.c_str());
   snprintf((char*)l_updv3.vlr,sizeof(l_updv3.vlr),"%s",(char*)l_vlrno.c_str());
   snprintf((char*)l_updv3.msc,sizeof(l_updv3.msc),"%s",(char*)l_mscno.c_str());
   snprintf((char*)l_updv3.l_hlrno,sizeof(l_updv3.l_hlrno),"%s",(char*)l_hlrno.c_str());

   //assuming vlr supports camel phase 1,2 and 3
   memset(l_updv3.VlrCap_camel,'\0',5);
   l_updv3.VlrCap_Camel1 = false;
   l_updv3.VlrCap_Camel2 = false;
   l_updv3.VlrCap_Camel3 = false;
   l_updv3.VlrCap_Camel4 = false;
   l_updv3.VlrCap_Phase = 0;

   l_updv3.VlrCap_Camel1 = true;
   l_updv3.VlrCap_camel[0] = '1';

   l_updv3.VlrCap_Camel2 = true;
   l_updv3.VlrCap_camel[1] = '1';

   l_updv3.VlrCap_Camel3 = true;
   l_updv3.VlrCap_camel[2] = '1';

   l_updv3.VlrCap_Phase = 3;

   l_state= m_rsd;
   int l_isdDlgId = g_sc.getNewDialogue();
   if(l_isdDlgId < 1)
   {
      CLOG(0,0,"ISD location dialog id %d is less then 0",l_isdDlgId);
      return false;
   }
   DLOG(0,0,"ISD on dialog ID %d",l_isdDlgId);

   DLOG(0, 0, "Sending MapOpenReq for ISD");
   MapOpenReq l_mapOpenReq(l_isdDlgId, MAP_V3);
   l_mapOpenReq.m_ApplCntxt = MAP_AC_CODE_subscriberDataMngt;
   DLOG(0,0,"Configuring SCCP address in ISD for Destination number %s and HLR Number %s",(char *)l_vlrno.c_str(),(char *)l_hlrno.c_str());
   configureSccpAddress(&l_mapOpenReq.m_OrigAddr,L_ROUTE_ON_GT,1002,6,(char *)l_hlrno.c_str());
   if(true == configureSccpAddress(&l_mapOpenReq.m_DestAddr,L_ROUTE_ON_GT,1002,7,(char *)l_vlrno.c_str()))
      g_sc.sendMsg(this, &l_mapOpenReq);

   l_OpCode = 2;
   l_Version = 3;

   m_tdr.setMapVersion(3);
   m_tdr.setRemoteAddr((s8 *)l_vlrno.c_str());
   m_tdr.setRemoteAddrSsn(7);
   RetrieveData(l_isdDlgId,(u8*)(char*)l_imsi.c_str(),(u8*)(char*)l_vlrno.c_str());
   m_tdr.setString(TDR_INDEX_AUC_NUM_VECTORS_REQUESTED,"FULL_ISD_GSM");

   return true;
}

void CtxtUpdateLocation :: sendCLforFupd()
{
   char XmlReq[501];
   memset(XmlReq,'\0',sizeof(XmlReq));
   FormXMLRequest(XmlReq,1, (u8 *)l_updv3.imsi, l_updv3.lmsi,(u8 *) l_updv3.l_hlrno,(u8 *) l_updv3.vlr,1,0,"FISD_GSM", (s8*)l_updv3.msc);
   g_sc.initiateIndependentContext(this, MAP_OP_CODE_cancelLocation, (char *) XmlReq, INITIATION_TYPE_IMMEDIATE);
}
