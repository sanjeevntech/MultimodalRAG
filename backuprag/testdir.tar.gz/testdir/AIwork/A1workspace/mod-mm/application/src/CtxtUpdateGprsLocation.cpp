/*******************************************************************************
 * File        : GprsUpdateLocation.cpp
 * Author      : VenkatRaman
 * Description : To Process Update Location request from a SGSN
 * Created on  : April 19, 2010, 9:46 AM IST
 *******************************************************************************/

#include <CtxtUpdateGPRSLocation.h>
#include <CtxtCancelLocation.h>
#include <CommonDefines.h>
#include <stdio.h>
#include <ServiceCoordinator.h>
#include <Logger.h>
#include <DbActiveObject.h>
#include <MmSgsnDbQueries.h>
#include <ISDData.h>
#include <MmConfigReader.h>
#include <SgsnCamelSubsinfo.h>
#include <GprsSubscriptioninfo.h>
#include <DataUnion.h>
#include <Utilities.h>
#include <AsnCodec.h>
#include <SubsProfileData.h>
#include <SnmpInterface.h>
#include <DiameterConstants.h>
#include <ExtendedServiceCoordinator.h>
#include <CommonData.h>

extern AsnCodec g_AsnCodecO3;
extern int g_UpdateLocationGprsTrap;
extern int g_FreeMsisdnRemainingTrap;
extern int g_TransientMsisdnUnavailableTrap;
extern int g_TransientMsisdnThresholdTrap;
extern int g_LocalMsisdnUnavailableTrap;
extern int g_LocalMsisdnThresholdTrap;
extern int g_DynamicAllocFailTrap;



CtxtUpdateGPRSLocation::CtxtUpdateGPRSLocation()
{
   DLOG(0, 0, "CtxtUpdateGPRSLocation::CtxtUpdateGPRSLocation()");
   l_OpCode = 0;
   index = 0;
   l_Version = 0;
   m_InitiateNoteMsPresent = 0;
   m_TraceErrorCode = 0;
   m_TrapReqd = false;
   m_SendCl = false;
   m_ProvErrRcvd = false;
   memset(l_AccId,'\0',sizeof(l_AccId));
   memset(l_actMsisdn,'\0',sizeof(l_actMsisdn));
   memset(l_priMsisdn,'\0',sizeof(l_priMsisdn));
   memset(l_priImsi,'\0',sizeof(l_priImsi));
   memset(l_hlrAddr,'\0',sizeof(l_hlrAddr));
   l_nwId = l_pnwId = l_AlocType = l_roamInd = l_OpCode = l_GenOdb = l_PlmnOdb = 0;
   index = VcsiIndex =ScsiIndex = SsIndex = 0;
   m_mwd_flag = 0;
   memset(m_AlertMsisdn,'\0',sizeof(m_AlertMsisdn));
   memset(&GenProfile,'\0',sizeof(GenProfile));
   memset(&GprsProfile,'\0',sizeof(GprsProfile));
   memset(&l_upgv3,'\0',sizeof(l_upgv3));
   m_FirstUlFlag = 0;
   m_MsisdnAllocStatus = -1;
   m_fIsd = false;
   memset(m_UploadedMsisdn,'\0',sizeof(m_UploadedMsisdn));
   memset(m_GPRS_Seq_id,'\0',sizeof(m_GPRS_Seq_id));
   m_tdr.setString(TDR_INDEX_ERR_CODE,"0");
   memset(m_Orig_Imei,'\0',sizeof(m_Orig_Imei));
   m_ApnOiOverrideIndVal = 0;
}

CtxtUpdateGPRSLocation::~CtxtUpdateGPRSLocation()
{
   DLOG(0, 0, "CtxtUpdateGPRSLocation::~CtxtUpdateGPRSLocation()");
}

int getPartnerPdpProfId(unsigned int p_PdpProfId, int p_NkId, int p_PartnerNkId)
{
   char l_tempArr[100 + 1];
   memset(l_tempArr,'\0',sizeof(l_tempArr));
   DLOG(0,0,"Nw Id %d PartNwId %d PdpId %d",p_NkId, p_PartnerNkId, p_PdpProfId);
   p_NkId +=100;
   snprintf(l_tempArr,sizeof(l_tempArr),"%d%04d%d",p_NkId,p_PartnerNkId,p_PdpProfId);
   DLOG(0,0,"Map Size [%d] tempArr in getPartnerPdpProfId [%s]",(int )g_spdPtr->m_RPPdpProfMap.size(),l_tempArr);

   map<string , int> :: iterator RPPdpPartProfIter;
   RPPdpPartProfIter = g_spdPtr->m_RPPdpProfMap.find(l_tempArr);
   if(RPPdpPartProfIter != g_spdPtr->m_RPPdpProfMap.end())
   {
      TLOG(0,0,"PARTNER PDP PROFILE MATCH FOUND [%d]",RPPdpPartProfIter->second);
      return RPPdpPartProfIter->second;
   }
   TLOG(0,0,"PARTNER PDP PROFILE MATCH NOT FOUND,returning 0");
   return 0;
}

bool CtxtUpdateGPRSLocation::processMessage(Msg *p_MsgPtr,bool &p_DeleteFlag)
{
   DLOG(0, 0, "Start of CtxtUpdateGPRSLocation::processMsg function Delete Flag is %d",p_DeleteFlag);
   if(1 == g_IMEI_EncrFlag)
   {
      TLOG(0,0,"Config reader IMEI encryption flag is set to 1");
      m_tdr.setInteger(TDR_INDEX_SMSM_GPRS_SM_DEL_OUTCOME,1);
   }
   MapSpecificMsg *l_specMsg = NULL;
   int l_dlgId = 0;
   int l_UserDlgId = 0;

   switch (p_MsgPtr->m_MsgType)
   {
      case MSG_TYPE_MAP:
         switch (((MapMsg*) p_MsgPtr)->m_MapMsgType)
         {
            case MAP_MSG_TYPE_COMMON:
               switch (((MapCommonMsg*) p_MsgPtr)->m_MapCommonMsgType)
               {
                  case MAP_CMN_OPEN_IND:
                     {
                        DLOG(0, 0, "MAP_CMN_OPEN_IND received");
                        //MapOpenInd *l_test = (MapOpenInd*) p_MsgPtr;
                        //OpenInd(l_test);
                     }
                     break;

                  case MAP_CMN_DELIMITER_IND:
                     {
                        DLOG(0, 0, "MAP_CMN_DELIMITER_IND received");
                        if(m_ProvErrRcvd)
                        {
                           WLOG(0,0,"Provider error followed by Delimiter rcvd, sending End");
                           CloseReq(((MapMsg*)p_MsgPtr)->m_UserDlgId);
                        }
                     }
                     break;

                  case MAP_CMN_CLOSE_IND:
                     {
                        DLOG(0, 0, "MAP_CMN_CLOSE_IND received");                        
                        return true;
                     }
                     break;

                  case MAP_CMN_U_ABORT_IND:
                     DLOG(0, 0, "MAP_CMN_U_ABORT_IND received");
                     if(l_state == m_atm)
                     {
                        m_TraceErrorCode = 101;
                     }
                     m_TrapReqd = true;
                     if(l_state != m_usdf)
                     {
                        WLOG(0,0," MAP_U_Abort received for Dlg Id %d before sending UPD response,Call state here is %d,updating UPG fail data",((MapMsg*)p_MsgPtr)->m_UserDlgId,l_state);
                        UpdateFailData(((MapMsg*)p_MsgPtr)->m_UserDlgId);
                        m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_U_ABORT_RCVD);
                     }
                     break;

                  case MAP_CMN_P_ABORT_IND:
                     DLOG(0, 0, "MAP_CMN_P_ABORT_IND received");
                     if(l_state == m_atm)
                     {
                        m_TraceErrorCode = 102;
                     }
                     m_TrapReqd = true;
                     if(l_state != m_usdf)
                     {
                        WLOG(0,0,"P_APORT received for Dlg Id %d before sending UPD response,Call state here is %d,updating UPG fail data",((MapMsg*)p_MsgPtr)->m_UserDlgId,l_state);
                        UpdateFailData(((MapMsg*)p_MsgPtr)->m_UserDlgId);
                        m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_P_ABORT_RCVD);
                     }
                     break;

                  case MAP_CMN_NOTICE_IND:
                     {
                        /*struct timeval tim;
                          gettimeofday(&tim);
                          struct tm *l_timeStruct=NULL;
                          time_t l_tim =time(NULL);
                          l_timeStruct = localtime(&l_tim);
                          char tim1[100];
                          memset(tim1,'\0',100);
                          sprintf(tim1, "%.6f",l_timeStruct->tm_sec+(tim.tv_usec/1000000.0));*/
                        WLOG(0, 0, "%d-TS:MAP_NOTICE_IND received, Sending Close with Pre-arranged end",((MapMsg*)p_MsgPtr)->m_UserDlgId);
                        MapCloseReq l_closeReq(((MapMsg*)p_MsgPtr)->m_UserDlgId);
                        l_closeReq.m_CloseType = MAP_CLOSE_TYPE_PRE_ARRANGED_END;
                        g_sc.sendMsg(this, &l_closeReq);
                        m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_NOTICE_RCVD);
                        if(l_state == m_atm)
                        {
                           m_TraceErrorCode = 103;
                        }
                        m_TrapReqd = true;
                        if(l_state != m_usdf)
                        {
                           DLOG(0,0,"Notice Ind received for Dlg Id %d before sending UPD response,Call state here is %d,updating UPG fail data",((MapMsg*)p_MsgPtr)->m_UserDlgId,l_state);
                           UpdateFailData(((MapMsg*)p_MsgPtr)->m_UserDlgId);
                        }
                     }
                     break;

                  default:
                     DLOG(0, 0, "Unknown Msg received [%d]", ((MapCommonMsg*) p_MsgPtr)->m_MapCommonMsgType);
                     break;
               }
               break;

            case MAP_MSG_TYPE_SPECIFIC:
               {
                  DLOG(0, 0, "MAP_MSG_TYPE_SPECIFIC received");
                  l_specMsg = (MapSpecificMsg*) p_MsgPtr;
                  l_UserDlgId = l_specMsg->m_UserDlgId;
                  DLOG(0, 0, "MAP_MSG_TYPE_SPECIFIC received dlgId[%d] UserDlgId[%d]",l_dlgId, l_UserDlgId);

                  switch (((MapSpecificMsg*) p_MsgPtr)->m_MapSpecificEventType)
                  {
                     case MAP_SPEC_EVENT_INDICATION:
                        {
                           DLOG(0, 0, "MAP_SPEC_EVENT_INDICATION received");
                           l_OpCode = (int)((MapSpecificMsg*) p_MsgPtr)->m_OpCode;
                           /*struct timeval tim;
                             gettimeofday(&tim);
                             struct tm *l_timeStruct=NULL;
                             time_t l_tim =time(NULL);
                             l_timeStruct = localtime(&l_tim);
                             char tim1[100];
                             memset(tim1,'\0',100);
                             sprintf(tim1, "%.6f",l_timeStruct->tm_sec+(tim.tv_usec/1000000.0));*/
                           DLOG(0, 0, "%d-TS:Received Update GPRS Location opcode %d",l_UserDlgId,l_OpCode);

                           switch (((MapSpecificMsg*) p_MsgPtr)->m_OpCode)
                           {
                              case MAP_OP_CODE_updateGprsLocation://OpCode = 23
                                 {
                                    DLOG(0,0,"Update GPRS location received for dlgId[%d] UserDlgId[%d]",l_dlgId, l_UserDlgId);
                                    if(((MapSpecificMsg*)p_MsgPtr)->m_Version == 3)
                                    {
                                       if (false == ((MapSpecificMsg*)p_MsgPtr)->m_allocatedFlag)
                                       {
                                          CLOG(0,0,"Received Update GPRS Location request with NULL params, returning Unexpected Data");
                                          RetError(l_UserDlgId,UnexpectedData);
                                       }
                                       else
                                       {
                                          IMAP3_UpdateGprsLocationArg *l_temp = (IMAP3_UpdateGprsLocationArg*) (((MapSpecificMsg*) p_MsgPtr)->m_structBuffer);
                                          if(NULL == g_spdPtr)
                                          {
                                             ELOG(0,0,"g_spdPTR is NULL .. profile Loading Failed returning SystemFailure");
                                             RetError(l_UserDlgId,SystemFailure);
                                             return false;
                                          }
                                          if(true == CheckParameters(l_UserDlgId,l_temp))
                                          {                                               
                                             DLOG(0,0,"Parameters are correct calling procedure to retreive data for received UPG");
                                             l_state= m_rsd;                                             
                                             RetrieveData(l_UserDlgId,l_upgv3.imsi,l_upgv3.SgsnNo+2);
                                          }
                                          else
                                          {                                               
                                             WLOG(0,0,"Check Parameters not success, returning Unexpected data error");
                                             RetError(l_UserDlgId,UnexpectedData);
                                          }
                                       }
                                    }
                                 }
                                 break;

                              default:
                                 DLOG(0, 0, "Received Unknown Specific Message");
                                 break;
                           }
                           return true;
                        }
                        break;

                     case MAP_SPEC_EVENT_RESULT:
                        {
                           DLOG(0, 0, "MAP_SPEC_EVENT_RESULT received");
                        }
                        break;

                     case MAP_SPEC_EVENT_CONFIRMATION:
                        {
                           DLOG(0, 0, "MAP_SPEC_EVENT_CONFIRMATION received");
                           l_UserDlgId = p_MsgPtr->m_UserDlgId;
                           switch (((MapSpecificMsg*) p_MsgPtr)->m_OpCode)
                           {
                              case MAP_OP_CODE_activateTraceMode:
                                 {
                                    if(l_state == m_atm)
                                    {
                                       LLOG(0,0,"%d-TS:Received activate trace mode Resp",l_UserDlgId);
                                       UpgLocCont(l_UserDlgId);
                                    }
                                    else
                                    {
                                       CLOG(0,0,"ATM Resp received in unknown call state");
                                       return false;
                                    }
                                 }
                                 break;
                              case MAP_OP_CODE_insertSubscriberData:
                                 {
                                    DLOG(0,0,"Received ISD response of Version %d received for ISD request Version %d sent",((MapSpecificMsg* )p_MsgPtr)->m_Version,l_Version);
                                    switch(((MapSpecificMsg* )p_MsgPtr)->m_Version)
                                    {
                                       case 3:
                                          {
                                             LLOG(0,0,"The value returned by ISDData are Index %x, VLR CSI Index is %x, SGSN CSI Index is %x, SS Index is %x",index,VcsiIndex,ScsiIndex,SsIndex);
                                             if (true == ((MapSpecificMsg*)p_MsgPtr)->m_allocatedFlag)
                                             {
                                                IMAP3_InsertSubscriberDataRes *ISD_Res = (IMAP3_InsertSubscriberDataRes*) (((MapSpecificMsg*) p_MsgPtr)->m_structBuffer);
                                                TLOG(0,0,"Checking on ISD response");
                                                if(true == m_isd.ProcessIsdResV3(l_UserDlgId,ISD_Res))
                                                {
                                                   TLOG(0,0,"Processing ISD response success");
                                                }
                                                else
                                                {
                                                   WLOG(0,0,"Process ISD resp fail, sending Roaming Not Allowed");
                                                   if(false == m_fIsd)
                                                   {
                                                      RetError(l_UserDlgId,RoamingNotAllowed_plmn);
                                                   }
                                                   m_tdr.setString(TDR_INDEX_RESRV3,"ODB_REJECTED_IN_ISD_RESP");
                                                   m_TrapReqd = false;
                                                   UpdateFailData(l_UserDlgId);
                                                   return false;
                                                }
                                             }
                                             if(index == 0)
                                             {
                                                LLOG(0,0,"No more ISD to send,calling Upd GPRS Loc Resp");
                                                upgLocRes(l_UserDlgId);
                                                return true;
                                             }
                                             else
                                             {
                                                LLOG(0,0,"Index value is %x continuing sending remaining ISD",index);
                                                flag = false;
                                                MapSpecificRequest l_request(l_UserDlgId, MAP_OP_CODE_insertSubscriberData, MAP_V3);
                                                DECLARE(OMAP3_InsertSubscriberDataArg,l_isd,3,"OMAP3_InsertSubscriberDataArg",DeclareFunc);
                                                if(true == m_isd.FormISDReqV3(l_UserDlgId,index,VcsiIndex,ScsiIndex,SsIndex,flag,m_isd.dbisd3,l_OpCode,l_isd))
                                                {
                                                   if(5 > g_AsnCodecO3.getEncodingLength(OMAP3_InsertSubscriberDataArg_PDU,l_isd))
                                                   {
                                                      WLOG(0,0,"Formed ISD data of length less than 5 bytes,Sending System failure");
                                                      if(false == m_fIsd)
                                                      {
                                                         RetError(l_UserDlgId,SystemFailure);
                                                      }
                                                      m_TrapReqd = false;
                                                      UpdateFailData(l_UserDlgId);
                                                   }
                                                   else
                                                   { 
                                                      SendMsgV3(l_UserDlgId,&l_request,l_isd,index,VcsiIndex,ScsiIndex,SsIndex);
                                                   }
                                                }     
                                             }
                                          }
                                          break;
                                       default:
                                          {
                                             WLOG(0,0,"ISD Acknowledge with unknown version of msg received in Update GPRS Location");
                                             RetError(l_UserDlgId,UnexpectedData);//MAP_ERROR_UNKNOWN_VERSION);
                                          }
                                          break;
                                    }
                                 }
                                 break;

                              default:
                                 CLOG(0,0,"Unknown Event specific confirmation received");
                                 break;
                           }
                        }
                        break;

                     case MAP_SPEC_EVENT_USER_ERROR:
                        {
                           unsigned short l_errCode = ((MapUserError*)p_MsgPtr)->m_ErrorCode;
                           WLOG(0, 0, "MAP_SPEC_EVENT_USER_ERROR %d received",l_errCode);
                           m_tdr.setInteger(TDR_INDEX_ERR_CODE,l_errCode);
                           CloseReq(((MapMsg*)p_MsgPtr)->m_UserDlgId);
                           if(l_state == m_atm)
                           {
                              m_TraceErrorCode = l_errCode;
                           }
                           m_TrapReqd = true;
                           l_state = m_usdf;
                           UpdateFailData(((MapMsg*)p_MsgPtr)->m_UserDlgId);
                        }
                        break;

                     case MAP_SPEC_EVENT_PROV_ERROR:
                        {
                           WLOG(0, 0, "MAP_SPEC_EVENT_PROV_ERROR received");
                           //CloseReq(((MapMsg*)p_MsgPtr)->m_UserDlgId);
                           if(l_state == m_atm)
                           {
                              m_TraceErrorCode = 104;
                           }
                           m_TrapReqd = true;
                           m_ProvErrRcvd = true;
                           l_state = m_usdf;
                           UpdateFailData(((MapMsg*)p_MsgPtr)->m_UserDlgId);
                           m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_PROVIDER_ERROR_RCVD);
                        }
                        break;
                     default:
                        CLOG(0, 0, "ERROR!! Default received");
                        break;
                  }
               }
               break;

            default:
               break;
         }
         break;

      case MSG_TYPE_DB:
         {
            DLOG(0, 0, "DB message received,call state is %d",(m_callState)l_state);
            switch(l_state)
            {
               case m_rsd:
                  {
                     RetrieveSubsSGSNData *l_rsd = (RetrieveSubsSGSNData*) p_MsgPtr;
                     TLOG(0,0,"Received DB response on Retrieve subscriber Profile Data");
                     l_UserDlgId = l_rsd->m_UserDlgId;
                     DLOG(0,0,"MAP_MSG_TYPE_DB received with DlgId %d",l_UserDlgId);

                     m_tdr.setInteger(TDR_INDEX_MM_LOCAL_NUM_ALLOCATION_STATUS,l_rsd->m_localImsiSubscription); 
                     m_tdr.setString(TDR_INDEX_RESRV3,(char *)l_rsd->m_roamCC); 
                     m_tdr.setInteger(TDR_INDEX_PARTNER_TYPE,l_rsd->m_partType); 
                     m_tdr.setString(TDR_INDEX_RESRV7,(char *)l_rsd->m_localRoamInfo);
                     m_tdr.setString(TDR_INDEX_RESRV8,(char *)l_rsd->m_tdrResrvData);
                     m_tdr.setString(TDR_INDEX_HLR_RESRV2,(char *)l_rsd->m_TdrProfData);
                     m_tdr.setString(TDR_INDEX_NOR_MIP6AI_HA_FAMILY2,(char *)l_rsd->m_DualImsiInfo_OUT);  //6.4.4.0
                     TLOG(0,0,"freeCount[%d] thresholdCount[%d]",l_rsd->m_freeCount,l_rsd->m_threshCount);
                     DLOG(0,0,"Dual Imsi Info [%s] Alt/DualImsi flag [%c] Dual Imsi Indicator [%c]",l_rsd->m_DualImsiInfo_OUT,l_rsd->m_DualImsiInfo_OUT[0],l_rsd->m_DualImsiInfo_OUT[2]);

		     if((atoi((char*)l_rsd->m_tdrResrvData) == 1) && (l_rsd->m_partType == 3))
		     {
			     LLOG(0,0,"Stats written ... Subscriber latched with Alternate IMSI first time");
			     map<string,int>::iterator l_itr = g_globalMap.find("FirstAlternateIMSILatched");
			     if(l_itr != g_globalMap.end())
			     {
				     HLRStatisticsInitializer::logStatistics(l_itr->second);
			     }
		     }

                     
                     if((atoi((char*)l_rsd->m_tdrResrvData) == 1) && (l_rsd->m_partType == 2) && ('2' == l_rsd->m_DualImsiInfo_OUT[0]) && ('1' == l_rsd->m_DualImsiInfo_OUT[2]))
                     {
                        LLOG(0,0,"Stats written ... Subscriber latched with Dual IMSI first time");
                        map<string,int>::iterator l_itr = g_globalMap.find("FirstDualIMSILatched");
                        if(l_itr != g_globalMap.end())
                        {
                           HLRStatisticsInitializer::logStatistics(l_itr->second);
                        }
                     }
                     
		     g_EmergencyFlag = g_spdPtr->m_MsisdnPrefReplaceStruct.m_CongestionEmergencyFlag;
		     LLOG(0,0,"DBRES: EmergencyFlag[%d]",g_EmergencyFlag);
		     m_tdr.setInteger(TDR_INDEX_NOR_VISITED_NET_ID,g_EmergencyFlag);

		     LLOG(0,0,"DBRES: Template FTN Info [%s]",l_rsd->m_TemplateFtnInfo_OUT);
		     m_tdr.setString(TDR_INDEX_AUC_NUM_VECTORS_SENT,l_rsd->m_TemplateFtnInfo_OUT);

		     //////////////////////////////////////////////////////////////////////////////////
		     LLOG(0,0,"DBRES: Count of OSS Triggers: [%d] .. TdrRestrData[%s]", l_rsd->m_ossTriggerDataCount_OUT, l_rsd->m_TdrRestrData);
		     LLOG(0,0,"DBRES: Cancel Location RowId Flag[%d]",l_rsd->m_crossClType_OUT);
                     m_tdr.setString(TDR_INDEX_HLR_RESRV1,(char *)l_rsd->m_TdrRestrData);
                     m_tdr.setInteger(TDR_INDEX_HLR_RESRV3,l_rsd->m_crossClType_OUT); // HLR 2.0.18.0_R1 
                     char l_currentOssData[5000 + 1];
                     char l_tokensOssData[10][5000 + 1];
                     for (int l_i=0; l_i<l_rsd->m_ossTriggerDataCount_OUT; l_i++)
                     {
                        memset(l_tokensOssData,'\0',sizeof(l_tokensOssData));
                        memset(l_currentOssData,'\0',sizeof(l_currentOssData));
                        sprintf(l_currentOssData,"|%s|",l_rsd->m_ossTriggerData_OUT[l_i]);
                        DLOG(0,0,"BEFORE TOKENIZE CURRENTOSSDATA[%s]",l_currentOssData);
                        tokenize(l_currentOssData, (char*)l_tokensOssData, 5001);
                        DLOG(0,0,"AFTER TOKENIZE");
                        TLOG(0,0,"RowId[%s] TransId[%s] Opcode[%d] TransXmlLen[%d]", l_tokensOssData[1],l_tokensOssData[2],atoi(l_tokensOssData[3]),strlen(l_tokensOssData[4]));
                        TLOG(0,0,"Current Data [%s]",l_currentOssData);

                        LLOG(0,0,"Cancel location CROSS CL sending flag[%d]",l_rsd->m_crossClType_OUT);
                        if(1 == l_rsd->m_crossClType_OUT)
                        {
                           if(DIAM_COMM_CODE_S6A_S6D_CLR_CLA == atoi(l_tokensOssData[3]))
                           {
                              LLOG(0,0,"Initiating DIAM CL: RowId[%s] TransId[%s]",l_tokensOssData[1],l_tokensOssData[2]);
                              g_esc.initiateIndependentContext(this, DIAM_COMM_CODE_S6A_S6D_CLR_CLA, l_tokensOssData[4], INITIATION_TYPE_IMMEDIATE);
                           }
                           else if(MAP_OP_CODE_cancelLocation == atoi(l_tokensOssData[3]))
                           {
                              LLOG(0,0,"Initiating MAP CL: RowId[%s] TransId[%s]",l_tokensOssData[1],l_tokensOssData[2]);
                              g_sc.initiateIndependentContext(this, MAP_OP_CODE_cancelLocation, l_tokensOssData[4], INITIATION_TYPE_IMMEDIATE);
                           }
                        }
                        else
                        {
                           EMsgType l_msgType;
                           if(true == whetherToProcess(atoi(l_tokensOssData[3]),&l_msgType))
                           {
                              if(MSG_TYPE_DIAMETER == l_msgType)
                              {
                                 LLOG(0,0,"Initiating DIAM CL: RowId[%s] TransId[%s]",l_tokensOssData[1],l_tokensOssData[2]);
                                 g_esc.initiateIndependentContext(this, DIAM_COMM_CODE_S6A_S6D_CLR_CLA, l_tokensOssData[4], INITIATION_TYPE_IMMEDIATE);
                              }
                              else if(MSG_TYPE_MAP == l_msgType)
                              {
                                 LLOG(0,0,"Initiating MAP CL: RowId[%s] TransId[%s]",l_tokensOssData[1],l_tokensOssData[2]);
                                 g_sc.initiateIndependentContext(this, MAP_OP_CODE_cancelLocation, l_tokensOssData[4], INITIATION_TYPE_IMMEDIATE);
                              }
                           }
                           else
                           {
                              LLOG(0,0,"Not processing CL: RowId[%s] TransId[%s]",l_tokensOssData[1],l_tokensOssData[2]);
                              if(0 == l_i)
                                 m_tdr.setString(TDR_INDEX_ULR_ROWID_ONE,l_tokensOssData[1]);
                              else if(1 == l_i)
                                 m_tdr.setString(TDR_INDEX_ULR_ROWID_TWO,l_tokensOssData[1]);
                              else if(2 == l_i)
                                 m_tdr.setString(TDR_INDEX_ULR_ROWID_THREE,l_tokensOssData[1]);
                              else if(3 == l_i)
                                 m_tdr.setString(TDR_INDEX_ULR_ROWID_FOUR,l_tokensOssData[1]);
                           }
                        }
                     }
                     //////////////////////////////////////////////////////////////////////////////////

                //6.4.4.1

		     LLOG(0,0,"DBRES: MNO Provisioning Parameters[%s]",l_rsd->m_MnoProvisioningTdr_OUT);
		     m_tdr.setString(TDR_INDEX_HLR_RESRV10,l_rsd->m_MnoProvisioningTdr_OUT);//106
                     
                     m_tdr.setInteger(TDR_INDEX_NOR_MIP6AI_HA_DEST_REALM,l_rsd->m_ugl_mpg_indicator_OUT); //136

		     char l_tempData2[200+1];
		     memset(l_tempData2,'\0',sizeof(l_tempData2));
		     snprintf(l_tempData2, sizeof(l_tempData2), "|%s|", l_rsd->m_MnoProvisioningTdr_OUT);
		     char tempBuff2[5][20];
		     memset(tempBuff2,'\0',sizeof(tempBuff2));
		     tokenize2(l_tempData2,(char*)tempBuff2,20,'|');
		     TLOG(0,1,"tokenized data: [%s] [%s] [%s] [%s] [%s]", tempBuff2[0], tempBuff2[1], tempBuff2[2], tempBuff2[3], tempBuff2[4]);

		     if( (0 < strlen((char*)tempBuff2[4])) && (1 == atoi(tempBuff2[1])) && (0 == atoi(tempBuff2[3])) )
		     {
			     LLOG(0,0,"MnoProvisioning Interested to be sent to MPG");
			     m_tdr.setString(TDR_INDEX_ULR_RAT_TYPE,"1");//122

			     char l_tempData3[200+1];
			     memset(l_tempData3,'\0',sizeof(l_tempData3));
			     snprintf(l_tempData3, sizeof(l_tempData3), "|%s|", l_rsd->m_TdrProfData);
			     char tempBuff3[5][20];
			     memset(tempBuff3,'\0',sizeof(tempBuff3));
			     tokenize2(l_tempData3,(char*)tempBuff3,20,'|');
			     TLOG(0,1,"tokenized data: [%s] [%s] [%s] [%s] [%s]", tempBuff3[0], tempBuff3[1], tempBuff3[2], tempBuff3[3], tempBuff3[4]);
			     m_tdr.setString(TDR_INDEX_ICC_ID,tempBuff3[4]);//103
		     }
		     else
		     {
			     m_tdr.setString(TDR_INDEX_ULR_RAT_TYPE,"0");//122
		     }

 
               //6.4.4.1



                     LLOG(0,0,"DBRES: General TDR Data[%s]", l_rsd->m_generalTDRdata);
                     char l_tokensGenTdr[13][100 + 1];
                     memset(l_tokensGenTdr,'\0',sizeof(l_tokensGenTdr));
                     tokenize(l_rsd->m_generalTDRdata, (char*)l_tokensGenTdr, 101);
                     TLOG(1,1,"Tokenized General TDR Data 1[%s] 2[%s] 3[%s] 4[%s] 5[%s] 6[%s] 7[%s] 8[%s] 9[%s] 10[%s] 11[%s] 12[%s]",(char *)l_tokensGenTdr[1],(char *)l_tokensGenTdr[2],(char *)l_tokensGenTdr[3],(char *)l_tokensGenTdr[4],(char *)l_tokensGenTdr[5],(char *)l_tokensGenTdr[6],(char *)l_tokensGenTdr[7],(char *)l_tokensGenTdr[8],(char *)l_tokensGenTdr[9],(char *)l_tokensGenTdr[10],(char *)l_tokensGenTdr[11],(char *)l_tokensGenTdr[12]);
                     m_tdr.setString(TDR_INDEX_CURRENT_ROAMING_ZONE,(char *)l_tokensGenTdr[1]);  //143
                     m_tdr.setString(TDR_INDEX_CURRENT_ROAMING_AGE,(char *)l_tokensGenTdr[2]);   //144
                     m_tdr.setString(TDR_INDEX_PREVIOUS_ROAMING_ZONE,(char *)l_tokensGenTdr[3]); //145
                     m_tdr.setString(TDR_INDEX_PREVIOUS_ROAMING_AGE,(char *)l_tokensGenTdr[4]);  //146
                     m_tdr.setString(TDR_INDEX_RESRV_POS147,(char *)l_tokensGenTdr[5]); 
                     m_tdr.setString(TDR_INDEX_RESRV_POS148,(char *)l_tokensGenTdr[6]); 
                     m_tdr.setString(TDR_INDEX_RESRV_POS149,(char *)l_tokensGenTdr[7]); 
                     m_tdr.setString(TDR_INDEX_RESRV_POS150,(char *)l_tokensGenTdr[8]); 
                     m_tdr.setString(TDR_INDEX_RESRV_POS151,(char *)l_tokensGenTdr[9]); 
                     m_tdr.setString(TDR_INDEX_RESRV_POS152,(char *)l_tokensGenTdr[10]); 
                     m_tdr.setString(TDR_INDEX_RESRV_POS153,(char *)l_tokensGenTdr[11]); 
                     m_tdr.setString(TDR_INDEX_RESRV_POS154,(char *)l_tokensGenTdr[12]); 

                     m_tdr.setInteger(TDR_INDEX_SSM_NBR_USR,l_rsd->m_First_Roam_To_Home_Flag);
                     LLOG(0,0,"DBRES: First_Roam_To_Home_Flag [%d]",l_rsd->m_First_Roam_To_Home_Flag);
                     m_tdr.setInteger(TDR_INDEX_AUC_RESYNC_INFO,l_rsd->m_PrimaryIndicator_OUT);
                     LLOG(0,0,"DBRES: Primary Indicator [%d]",l_rsd->m_PrimaryIndicator_OUT);
                     m_tdr.setString(TDR_INDEX_SSM_DEF_PRIORITY,(char *)l_rsd->m_CC_Info);
                     m_tdr.setString(TDR_INDEX_ALT_PRIMARYIMSI,(char *)l_rsd->m_AltImsi);      //5054
                     m_tdr.setString(TDR_INDEX_ALT_PRIMARYIMSI2,(char *)l_rsd->m_IPAddress);      //5054
                     LLOG(0,0,"ALT_PRIM_IMSI [%s] STATIC_IP_ADDRESS [%s] AreaCode Based Alocation Info[%s] TrapCode[%s] TrapDesc[%s]", (char *)l_rsd->m_AltImsi, (char *)l_rsd->m_IPAddress,l_rsd->m_AreaCodeBasedAllocInfo,l_rsd->m_TrapCode,l_rsd->m_TrapDesc);
                     m_tdr.setString(TDR_INDEX_NEW_RESERVED_SEVEN,(char *)l_rsd->m_AreaCodeBasedAllocInfo);

                     char l_tempIpv4Addr[100 + 1];
                     char tempBuff[3][100];
                     memset(l_tempIpv4Addr,'\0',sizeof(l_tempIpv4Addr));
                     memset(tempBuff,'\0',sizeof(tempBuff));
                     snprintf(l_tempIpv4Addr,sizeof(l_tempIpv4Addr),"|%s|",(char *)l_rsd->m_IPAddress);
                     DLOG(0,0,"Static IP Address before tokenising [%s]", l_tempIpv4Addr);
                     tokenize2(l_tempIpv4Addr,(char*)tempBuff,100,'|');
                     TLOG(0,0,"tokenised data: [%s] [%s] [%s]", tempBuff[1], tempBuff[2], tempBuff[3]);
                     m_isd.gprssi.m_IPv4Addr = tempBuff[1];
                     m_isd.gprssi.m_IPv6Addr = tempBuff[2];
                     DLOG(0,0,"After tokenising Static IPV4 Address [%s] IPV6 Address[%s]",m_isd.gprssi.m_IPv4Addr.c_str(), m_isd.gprssi.m_IPv6Addr.c_str());

                     char l_tempDesc[200+1];
                     snprintf(l_tempDesc, sizeof(l_tempDesc), "CC:%s NetID: %d", (char *)l_rsd->m_roamCC, l_rsd->m_nwid);
                     if(2 == l_rsd->m_localImsiSubscription)
                     {
                        LLOG(0,0,"DBRES: Unable to allocate Local Msisdn");
                        g_si.sendSnmpTrap(g_LocalMsisdnUnavailableTrap, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL, l_tempDesc);
                     }
                     else if(l_rsd->m_freeCount < l_rsd->m_threshCount)
                     {
                        LLOG(0,0,"DBRES: Threshold reached for Local Msisdn .. freeCount[%d] threshCount[%d]",l_rsd->m_freeCount,l_rsd->m_threshCount);
                        g_si.sendSnmpTrap(g_LocalMsisdnThresholdTrap, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL, l_tempDesc);
                     }
                     strncpy((char *)l_priMsisdn,(char *)l_rsd->m_PriMsisdn,strlen((char *)l_rsd->m_PriMsisdn));
                     m_tdr.setString(TDR_INDEX_MM_PRIMARY_MSISDN,(char *)l_priMsisdn);
                     strncpy((char *)l_priImsi,(char *)l_rsd->m_PriImsi,strlen((char*)l_rsd->m_PriImsi));
                     m_tdr.setString(TDR_INDEX_MM_PRIMARY_IMSI,(char *)l_priImsi);

                     m_tdr.setString(TDR_INDEX_MM_LOCAL_IMSI,(char *)l_rsd->m_LocalImsi); 
                     m_tdr.setString(TDR_INDEX_MM_LOCAL_MSISDN,(char *)l_rsd->m_LocalMsisdn); 
                     m_tdr.setInteger(TDR_INDEX_MM_IMSI_BURNT_TYPE,l_rsd->m_ImsiPreBurnt); 
                     m_tdr.setString(TDR_INDEX_RESRV6,(char *)l_rsd->m_SimStructure); 

                     m_tdr.setString(TDR_INDEX_REMOTE_HOST,l_rsd->m_MmeHost);
                     m_tdr.setString(TDR_INDEX_REMOTE_REALM,l_rsd->m_MmeRealm);

                     if(l_rsd->m_ErrorCode != 0)
                     {
                        m_tdr.setInteger(TDR_INDEX_DB_ERR_CODE,l_rsd->m_ErrorCode); 
                        m_tdr.setString(TDR_INDEX_DB_ERR_DESC,(char *)l_rsd->m_ErrorMsg);
                     }
                     //Added in 1.0.4.5
                     memset(l_hlrAddr,'\0',sizeof(l_hlrAddr));
                     strncpy((char *)l_hlrAddr,(char *)l_rsd->m_HlrADDR,strlen((char *)l_rsd->m_HlrADDR));
                     DLOG(0,0,"Sending MAP Open resp with hlr gt  [%s]",l_hlrAddr);
                     if(strlen((char *)l_hlrAddr) > 1)
                     {
                        sendMapOpenResponse(l_UserDlgId,(char *)l_hlrAddr,g_ConfigData->i_NgConfigData.m_selfAddress.ssn);
                     }

                     //
                     // Added in 1.0.8.0
                     strcpy((char*)m_GPRS_Seq_id,(char *)l_rsd->m_GPRS_Seq_id);
                     m_tdr.setString(TDR_INDEX_OAM_TRANSACTION_ID,(char *)m_GPRS_Seq_id);
                     m_tdr.setString(TDR_INDEX_RESRV1,(char *)l_rsd->m_TdrData);
                     //    
                     //End 1.0.8.0
                     //     
                     if(l_rsd->m_FirstUL == 1)
                     {
                        m_tdr.setInteger(TDR_INDEX_MM_FIRST_UL,l_rsd->m_FirstUL); 
                        m_FirstUlFlag = 1;
                     }
                     m_tdr.setInteger(TDR_INDEX_MM_NETWORK_ID,l_rsd->m_nwid); 
                     m_tdr.setInteger(TDR_INDEX_MM_PARTNER_NW_ID,l_rsd->m_pnwid); 
                     LLOG(0,0,"DBRES: GPRS Update location Sequence ID [%s] .. FUGL-IND[%d] .. SGSN Prefix|SGSN Template [%s]",m_GPRS_Seq_id,m_FirstUlFlag,l_rsd->m_TdrData);

                     // 1.0.13.2 Begin
                     if( l_rsd->m_MsisdnAllcatedStatus >= 10 )
                     {
                        m_tdr.setInteger(TDR_INDEX_RESRV5,l_rsd->m_MsisdnAllcatedStatus); 
                        LLOG(0,0,"DBRES: Transient MSISDN allocation status [%d]",l_rsd->m_MsisdnAllcatedStatus);

                        if( (14 == l_rsd->m_MsisdnAllcatedStatus ) || (11 == l_rsd->m_MsisdnAllcatedStatus ) )
                        {
                           LLOG(0,0,"Unable to allocate Trasient msisdn");
                           g_si.sendSnmpTrap(g_TransientMsisdnUnavailableTrap, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL);
                        }
                        // 1.0.16.0 Begin
                        else if(l_rsd->m_transFreeCount < l_rsd->m_transThreshCount)
                        {
                           LLOG(0,0,"Threshold reached for Transient msisdn .. freeCount[%d] threshCount[%d]",l_rsd->m_transFreeCount,l_rsd->m_transThreshCount);
                           g_si.sendSnmpTrap(g_TransientMsisdnThresholdTrap, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL);
                        }
                        // 1.0.16.0 End
                     }
                     // 1.0.13.2 End

                     if((l_rsd->m_ErrorCode == 0) || (l_rsd->m_ErrorCode == 12) || (l_rsd->m_ErrorCode == 13))
                     {
                        if((l_rsd->m_MsisdnAllcatedStatus == 0) || (l_rsd->m_MsisdnAllcatedStatus == 1))
                        {
                           if(l_rsd->m_MsisdnAllcatedStatus == 0)
                           {
                              LLOG(0,0,"Dynamic MSISDN allocation Success");
                              m_tdr.setString(TDR_INDEX_MM_MSISDN_ALLOC_STATUS,"A");
                              moduleLevelLogStats("PrimMSISDNAllocatedinUGL");
                              m_MsisdnAllocStatus = 1;
                           }
                           if(l_rsd->m_MsisdnAllcatedStatus == 1)
                           {
                              CLOG(0,0,"Dynamic MSISDN allocation Failed");
                              m_tdr.setString(TDR_INDEX_MM_MSISDN_ALLOC_STATUS,"N");
                           }
                           m_tdr.setString(TDR_INDEX_OAM_FREE_FORMAT_DATA,(char *)l_rsd->m_OldMsisdn); 
                           snprintf(m_UploadedMsisdn,sizeof(m_UploadedMsisdn),"%s",(char *)l_rsd->m_OldMsisdn);
                           DLOG(0,0,"Configured Network Threshold [%d]",l_rsd->m_DynMsisdnMinFreeThreshold);
                           if(l_rsd->m_RemainingMsisnd < l_rsd->m_DynMsisdnMinFreeThreshold)
                           {
                              CLOG(0,0,"Remaining FREE MSISDN count in pool [%d] is less than configured network threshold [%d]",l_rsd->m_RemainingMsisnd,l_rsd->m_DynMsisdnMinFreeThreshold);
                              g_si.sendSnmpTrap(g_FreeMsisdnRemainingTrap, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL);
                           }
                        }
                     }
                     else if(2 == l_rsd->m_ErrorCode)
                     {
                        if(NULL == strstr((char*)(l_rsd->m_ErrorMsg),"GET_"))
                        {
                           CLOG(0,0,"Dynamic Allocation Failed");
                           g_si.sendSnmpTrap(g_DynamicAllocFailTrap, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL);
                        }
                     }

                     char tmpBuff[5][100];
                     char l_AreaCodeBuf[100+1];
                     memset(tmpBuff,'\0',sizeof(tmpBuff));
                     memset(l_AreaCodeBuf,'\0',sizeof(l_AreaCodeBuf));
                     snprintf(l_AreaCodeBuf,sizeof(l_AreaCodeBuf),"|%s|",l_rsd->m_AreaCodeBasedAllocInfo);
                     DLOG(0,0,"AreaCodeBuf[%s] before tokenizing",l_AreaCodeBuf);
                     tokenize2(l_AreaCodeBuf,(char*)tmpBuff,100,'|');
                     TLOG(0,0,"tokenised data: [%s] [%s] [%s] [%s] [%s]", tmpBuff[1], tmpBuff[2], tmpBuff[3], tmpBuff[4], tmpBuff[5]);

                     if(strlen(l_rsd->m_TrapCode) > 0)
                     {
                        TLOG(0,0,"Trap Code is [%s]", l_rsd->m_TrapCode);
                        if(NULL != g_prov)
                        {
                           int l_trapInt = ((CommonData*)g_prov)->getTrapInt(l_rsd->m_TrapCode);
                           if(l_trapInt >= 0)
                           {
                              if(strlen(l_rsd->m_TrapDesc)> 0)
                              {
                                 char l_tempDesc1[200+1];
                                 snprintf(l_tempDesc1, sizeof(l_tempDesc1), "AreaShortCode:%s BusinessGroupID:%s", tmpBuff[2],tmpBuff[5]);
                                 g_si.sendSnmpTrap(l_trapInt, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL, l_tempDesc1);
                              }
                              else
                              {
                                 g_si.sendSnmpTrap(l_trapInt, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL);
                              }
                           }
                           else
                           {
                              ELOG(0,0,"Unable to get the integer for the trap [%s]", l_rsd->m_TrapCode);
                           }
                        }
                        else
                        {
                           WLOG(0,0,"g_prov is null. not sending trap");
                        }
                     }

                     if((1 == m_MsisdnAllocStatus) && (0 == strcmp("2", tmpBuff[1])))
                     {
                        DLOG(0,0,"checking for logging AreaCode Based stats");
                        char l_TmpAreaShortCode[100+1];
                        memset(l_TmpAreaShortCode,'\0',sizeof(l_TmpAreaShortCode));
                        snprintf(l_TmpAreaShortCode,sizeof(l_TmpAreaShortCode),"TotalMsisdnAllocationsInAreaCode:%s",tmpBuff[2]);
                        TLOG(0,0,"AreaCode[%s] Based MSISDN Allocated .. logging statistics",tmpBuff[2]);
                        map<string,int>::iterator l_itr = g_globalMap.find(l_TmpAreaShortCode);
                        if(l_itr != g_globalMap.end())
                        {
                           HLRStatisticsInitializer::logStatistics(l_itr->second);
                        }
                        else
                        {
                            TLOG(0,0,"%s not found in global map, not calling statistics",l_TmpAreaShortCode);
                        }
                     }
                     else
                     {
                        TLOG(0,0,"Msisdn Alloc Status[%d] and AreaCode Flag Value[%s] not checking for statistics",m_MsisdnAllocStatus,tmpBuff[1]);
                     }

#if 0
                     if(strlen(l_rsd->m_rowIdGsm) > 5)
                     {
                        TLOG(0,0,"Pushing the gsm row id [%s] into queue", l_rsd->m_rowIdGsm);
                        g_sc.initiateIndependentContext(this, MAP_OP_CODE_dummy_1, (char*)l_rsd->m_rowIdGsm, INITIATION_TYPE_TARDILY);
                        m_tdr.setString(TDR_INDEX_ULR_ROWID_GSM, l_rsd->m_rowIdGsm);
                     }
                     if(strlen(l_rsd->m_rowIdGprs) > 5)
                     {
                        TLOG(0,0,"Pushing the Gprs row id [%s] into queue", l_rsd->m_rowIdGprs);
                        g_sc.initiateIndependentContext(this, MAP_OP_CODE_dummy_1, (char*)l_rsd->m_rowIdGprs, INITIATION_TYPE_TARDILY);
                        m_tdr.setString(TDR_INDEX_ULR_ROWID_GPRS, l_rsd->m_rowIdGprs);
                     }

                     if(1 == g_MmConfigReaderObj->m_crossCancelLoc)
                     {
                        if(strlen(l_rsd->m_rowIdMme) > 5)
                        {
                           TLOG(0,0,"Pushing the MME row id [%s] into queue", l_rsd->m_rowIdMme);
                           g_sc.initiateIndependentContext(this, MAP_OP_CODE_dummy_1, (char*)l_rsd->m_rowIdMme, INITIATION_TYPE_TARDILY);
                           m_tdr.setString(TDR_INDEX_ULR_ROWID_MME, l_rsd->m_rowIdMme);
                           m_tdr.setString(TDR_INDEX_ULR_CROSS_CL, "ToMmeEnabled");
                        }
                     }
                     else if( strlen(l_rsd->m_rowIdMme) > 5)
                     {
                        m_tdr.setString(TDR_INDEX_ULR_ROWID_MME, l_rsd->m_rowIdMme);
                        m_tdr.setString(TDR_INDEX_ULR_CROSS_CL, "ToMmeDisabled");
                     }
#endif


                     if(l_rsd->m_DbQueryRes == DB_QUERY_RES_SUCCESS)
                     {
#if 0
                        LLOG(0,0,"RetrieveSubsSGSNData successfull. Count of oss triggers: %d", l_rsd->m_ossTriggerDataCount);

                        for (int l_i=0; l_i<l_rsd->m_ossTriggerDataCount; l_i++)
                        {
                           TLOG(0,0,"Pushing the row id [%s] into queue", l_rsd->m_ossTriggerDataArray[l_i].m_rowId);
                           g_sc.initiateIndependentContext(this, MAP_OP_CODE_dummy_1, (char*)l_rsd->m_ossTriggerDataArray[l_i].m_rowId, INITIATION_TYPE_TARDILY);
                        }
#endif



                        int l_processDbResp= processDBData(l_UserDlgId,l_rsd);
                        if(2 == l_processDbResp && (false == m_fIsd))
                        {
                           RetError(l_UserDlgId,RoamingNotAllowed_plmn);
                           m_TrapReqd = false;
                           UpdateFailData(l_UserDlgId);
                           return false;
                        }
                        else if(1== l_processDbResp && (false == m_fIsd))
                        {
                           RetError(l_UserDlgId,SystemFailure);
                           m_TrapReqd = false;
                           UpdateFailData(l_UserDlgId);
                           return false;
                        }
                        sendMapOpenResponse(l_UserDlgId,(char *)l_hlrAddr,g_ConfigData->i_NgConfigData.m_selfAddress.ssn);
                        m_tdr.setString(TDR_INDEX_LOCAL_ADDRESS,(char *)l_hlrAddr);
                        int l_UpgRet= UpgLoc(l_UserDlgId);
                        switch (l_UpgRet)
                        {
                           case SEND_ATM:
                              {
                                 if(true == m_fIsd)
                                    break;
                                 // RetError(l_UserDlgId,UnknownSubscriber_imsiUnknown);
                                 l_state = m_atm;
                                 MapSpecificRequest l_request(l_UserDlgId, MAP_OP_CODE_activateTraceMode, MAP_V3);
                                 DECLARE(OMAP3_ActivateTraceModeArg,l_atm,3,"OMAP3_ActivateTraceModeArg",DeclareFunc);
                                 fillAtmV3(l_UserDlgId,GprsProfile.l_TraceRef,GprsProfile.l_TraceType,GprsProfile.l_OmcId,l_atm);
                                 l_request.m_structBuffer = (void*) l_atm;
                                 g_sc.sendMsg(this, &l_request); //
                                 ContinueReq(l_UserDlgId);
                                 LLOG(0,0,"Sending ATM followed by cont, callstate here %d",(m_callState)l_state);
                              }
                              break;
                           case CAP_VALIDATION_FAILED:
                              {
                                 if(false == m_fIsd)
                                 {
                                    RetError(l_UserDlgId,RoamingNotAllowed_plmn);
                                 }
                                 m_tdr.setString(TDR_INDEX_OAM_FREE_FORMAT_DATA,"CAP Validation Failed");
                                 UpdateFailData(l_UserDlgId);
                              }
                              break;
                           case UPGV3_SUCCESS:
                              {
                                 TLOG(0,0,"Upg success");
                              }
                              break;
                           case CAP_PROFILE_NOT_FOUND:
                           default:
                              {
                                 if(false == m_fIsd)
                                 {
                                    RetError(l_UserDlgId,SystemFailure);
                                 }
                                 UpdateFailData(l_UserDlgId);
                              }
                              break;
                        }
                     }
                     else
                     {
                        if(true == m_fIsd)
                        {
                           LLOG(0,0,"DB Error for forced UPG .. ignoring");
                           break;
                        }
                        {
                           char GprsPro[300];
                           memset(GprsPro, '\0', 300);
                           //char *tmp2;
                           strncpy(GprsPro, "|", 1);
                           strncat(GprsPro, (char *) l_rsd->m_GprsINFO, strlen((char *) l_rsd->m_GprsINFO));
                           strncat(GprsPro, "|", 1);
                           //DLOG(0,0,"The string tested is %s\n",GprsPro);
                           char str2[20][20];
                           memset(str2, '\0', 400);
                           {
                              char *ptr1, *ptr2;
                              ptr1 = ptr2 = GprsPro;
                              ptr2++;
                              int i = 1;
                              while(*ptr2 != '\0')
                              {
                                 if('|' == *ptr2)
                                 {
                                    //DLOG(0,0,"Found |\n");
                                    if(ptr2 - ptr1 == 1)
                                    {
                                       strcpy(str2[i], "|0");
                                       //DLOG(0,0,"str[%d]:%s\n",i,str[i]);
                                    }
                                    else
                                    {
                                       //strncpy(str,ptr1,ptr2-ptr1);
                                       strncpy(str2[i], ptr1, ptr2 - ptr1);
                                       str2[i][ptr2 - ptr1] = '\0';
                                       //DLOG(0,0,"str[%d]:%s\n",i,str[i]+1);
                                    }
                                    ptr1 = ptr2;
                                    i++;
                                 }

                                 ptr2++;
                              }
                              strncpy((char *) GprsProfile.l_ActMsisdn, str2[1] + 1, strlen(str2[1]));
                              strncpy((char *) GprsProfile.l_Actimsi, str2[2] + 1, strlen(str2[2]));
                              GprsProfile.l_roamInd = atoi(str2[3] + 1);
                              strncpy((char *) GprsProfile.l_sgsnno, str2[4] + 1, strlen(str2[4]));
                              strncpy((char *) GprsProfile.l_sgsnAddr, str2[5] + 1, strlen(str2[5]));
                              GprsProfile.l_sgsnRest = atoi(str2[6] + 1);
                              GprsProfile.l_msPur_gprs = atoi(str2[7] + 1);
                              GprsProfile.l_mnrg = atoi(str2[8] + 1);
                              GprsProfile.l_roamrestduf = atoi(str2[9] + 1);
                              //GprsProfile.l_pdpId = atoi(str2[10] + 1);
                              strncpy((char *) GprsProfile.l_ActHLRAddr, str2[10] + 1, strlen(str2[10]));
                              GprsProfile.l_ActPnwId = atoi(str2[11] + 1);
                              strncpy((char *) GprsProfile.l_lmsino, str2[17] + 1, strlen(str2[17])); //added in 1.0.14.0
                              strncpy((char *) GprsProfile.l_vlrNum, str2[18] + 1, strlen(str2[18])); //added in 1.0.14.0
                           }
#if 0
                           int l_check = 0;
                           if(l_Version == 3)
                           {
                              l_check = strcmp((char *)GprsProfile.l_sgsnno,(char *)l_upgv3.SgsnNo+2);
                           }
                           //added in 1.0.14.0 Rev1
                           if(0 == l_check)
                           {
                              if(GprsProfile.l_ActPnwId != l_rsd->m_pnwid)
                              {
                                 LLOG(0,0,"Same SGSN But different pwids %d %d", GprsProfile.l_ActPnwId, l_rsd->m_pnwid);
                                 l_check=1;
                              }
                           }
                           //end of addition
                           if(strncmp((char *) GprsProfile.l_sgsnno,"0",1) == 0)
                           {
                              DLOG(0,0,"Existing SGSN Number is null");
                              m_SendCl = true;
                           }
                           char XmlReq[501];
                           unsigned char lmsi[9];
                           if((l_check) && (strncmp((char *) GprsProfile.l_sgsnno,"0",1) != 0) && (strncmp((char *) GprsProfile.l_ActHLRAddr,"0",1)!= 0))
                           {
                              memset(XmlReq, '\0', sizeof(XmlReq));
                              memset(lmsi, '\0', sizeof(lmsi));
                              strcpy((char *) lmsi, "00000000");
                              m_tdr.setString(TDR_INDEX_MM_PREVIOUS_NODE,(s8*)GprsProfile.l_sgsnno);
                              LLOG(0, 0, "Initiating cancel location to previous SGSN Number %s with HLR address %s for IMSI %s", GprsProfile.l_sgsnno, GprsProfile.l_ActHLRAddr, GprsProfile.l_Actimsi);
                              m_SendCl = true;
                              FormXMLRequest(XmlReq,2, GprsProfile.l_Actimsi,lmsi, GprsProfile.l_ActHLRAddr, GprsProfile.l_sgsnno,0,0,"UPDATE_GPRS_LOC","");
                              DLOG(0, 0, "Sending XmlReq %s to CtxtCancelLocation. OldPnwId:%d, CurrPnwId:%d", XmlReq, GprsProfile.l_ActPnwId,
                                    l_rsd->m_pnwid);
                              g_sc.initiateIndependentContext(this, MAP_OP_CODE_cancelLocation, (char *) XmlReq, INITIATION_TYPE_IMMEDIATE);

                           }
                           if( (GprsProfile.l_ActPnwId != l_rsd->m_pnwid) && 
                                 (strlen((char*)GprsProfile.l_vlrNum) > 5)
                             )
                           {
                              memset(XmlReq, '\0', sizeof(XmlReq));
                              memset(lmsi, '\0', sizeof(lmsi));
                              if((strcmp((char *) GprsProfile.l_lmsino, "0") != 0) && (strcmp((char *) GprsProfile.l_lmsino, "00000000") != 0))
                              {
                                 strcpy((char *) lmsi, (char *) GprsProfile.l_lmsino);
                              }
                              else
                              {
                                 strcpy((char *) lmsi, "00000000");
                              }
                              LLOG(0, 0, "UPDATE_GPRS_LOC_IMSI_CHANGE Initiating cancel location to previous VLR Number %s with HLR address %s for IMSI %s", GprsProfile.l_vlrNum, GprsProfile.l_ActHLRAddr, GprsProfile.l_Actimsi);
                              FormXMLRequest(XmlReq,1, GprsProfile.l_Actimsi,lmsi, GprsProfile.l_ActHLRAddr, GprsProfile.l_vlrNum,2,0,"UPDATE_GPRS_LOC_IMSI_CHANGE","");
                              DLOG(0, 0, "Sending XmlReq %s to CtxtCancelLocation", XmlReq);
                              g_sc.initiateIndependentContext(this, MAP_OP_CODE_cancelLocation, (char *) XmlReq, INITIATION_TYPE_IMMEDIATE);
                           }
#endif
                        }
                        WLOG(0,0,"Received Error Code from DB %d,Error message %s",l_rsd->m_ErrorCode,l_rsd->m_ErrorMsg);
                        if(l_rsd->m_ErrorCode == 8)
                        {
                           LLOG(0,0,"sending Roaming Not Allowed");
                           RetError(l_UserDlgId,RoamingNotAllowed_plmn);
                        }
                        else if((l_rsd->m_ErrorCode == 10) || (l_rsd->m_ErrorCode == 11) || (l_rsd->m_ErrorCode == 12)  || (l_rsd->m_ErrorCode == 41) || (l_rsd->m_ErrorCode == 42) || (l_rsd->m_ErrorCode == 43) || (l_rsd->m_ErrorCode == 44) )
                        {
                           int l_ErrCode =0; 
                           if((l_rsd->m_ErrorCode == 10) || (l_rsd->m_ErrorCode == 11))
                           {
                              l_ErrCode = g_MmConfigReaderObj->m_Multi_Imsi_ErrCode;
                           }
                           else if(l_rsd->m_ErrorCode == 12)
                           {
                              m_tdr.setString(TDR_INDEX_MM_MSISDN_ALLOC_STATUS,"N");
                              l_ErrCode = g_MmConfigReaderObj->m_MsisdnAllocErrCode;
                           }
                           else if(41 == l_rsd->m_ErrorCode)
                           {
                              LLOG(0,0,"SGSN Address/IMSI Blacklist configured to send PreArrangedEnd");
                              MapCloseReq l_closeReq(l_UserDlgId);
                              l_closeReq.m_CloseType = MAP_CLOSE_TYPE_PRE_ARRANGED_END;
                              g_sc.sendMsg(this, &l_closeReq);
                              return true;
                           }
                           else if(42 == l_rsd->m_ErrorCode)
                           {
                              LLOG(0,0,"SGSN Address/IMSI Blacklist configured to send RoamingNotAllowed-PLMN");
                              l_ErrCode = 8;
                           }
                           else if(43 == l_rsd->m_ErrorCode)
                           {
                              LLOG(0,0,"SGSN Address/IMSI Blacklist configured to send RoamingNotAllowed-ODB");
                              l_ErrCode = 9;
                           }
                           else if(44 == l_rsd->m_ErrorCode)
                           {
                              LLOG(0,0,"SGSN Address/IMSI Blacklist configured to send UnknownSubscriber");
                              l_ErrCode = 1;
                           }
                           LLOG(0,0,"Sending error code [%d]",l_ErrCode);
                           switch(l_ErrCode)
                           {

                              case 1:
                                 RetError(l_UserDlgId,UnknownSubscriber_imsiUnknown);
                                 break;

                              case 8:
                                 RetError(l_UserDlgId,RoamingNotAllowed_plmn);
                                 break;

                              case 9:
                                 RetError(l_UserDlgId,RoamingNotAllowed_odb);
                                 break;

                              case 34:
                                 RetError(l_UserDlgId,SystemFailure);
                                 break;

                              case 36:
                                 RetError(l_UserDlgId,UnexpectedData);
                                 break;

                              default:
                                 {
                                    WLOG(0,0,"Unknown error code %d read in config, sending Roaming not allowed HPLMN",l_ErrCode);                                 
                                    RetError(l_UserDlgId,RoamingNotAllowed_plmn);
                                 }
                                 break;
                           }
                        }
                        else if(l_rsd->m_ErrorCode == 9)
                        {
                           DLOG(0,0,"sending Roaming Not Allowed");
                           RetError(l_UserDlgId,RoamingNotAllowed_odb);
                        }
                        else if(l_rsd->m_ErrorCode == 1)
                        {
                           DLOG(0,0,"sending Unknown Subscriber - IMSI unknown");
                           RetError(l_UserDlgId,UnknownSubscriber_imsiUnknown);
                        }
                        else if(l_rsd->m_ErrorCode == 3)
                        {
                           DLOG(0,0,"sending Unknown Subscriber - GPRS Subscription unknown");
                           RetError(l_UserDlgId,UnknownSubscriber_gprsUnknown);
                           //DLOG(0,0,"Sending Roaming Not Allowed Error");
                           //RetError(l_UserDlgId,RoamingNotAllowed_plmn);
                        }
                        else //if(l_rsd->m_ErrorCode == 1 || l_rsd->m_ErrorCode == 2)
                        {
                           CLOG(0,0,"sending system failure");
                           RetError(l_UserDlgId,SystemFailure);
                        }
                     }

#if 0
                     /// HSS CHANGE BEGIN ////
                     if(1 == g_MmConfigReaderObj->m_crossCancelLoc)
                     {
                        char l_CancelLocXml[500];
                        memset(l_CancelLocXml,'\0',sizeof(l_CancelLocXml));
                        if( (strlen(l_rsd->m_MmeHost) > 1) && (strlen(l_rsd->m_HssHost) > 1) )
                        {
                           sprintf(l_CancelLocXml, "<CANCEL_LOC><IMSI>%s</IMSI><NODE_TYPE>%s</NODE_TYPE><ORIGIN_HOST>%s</ORIGIN_HOST><ORIGIN_REALM>%s</ORIGIN_REALM><DESTINATION_HOST>%s</DESTINATION_HOST><DESTINATION_REALM>%s</DESTINATION_REALM><UPDATE_SUBS_DATA>%d</UPDATE_SUBS_DATA><CL_TYPE>%d</CL_TYPE><IMSI_TYPE>%d</IMSI_TYPE><REQUEST_TYPE>%s</REQUEST_TYPE></CANCEL_LOC>", 
                                 GprsProfile.l_Actimsi, "MME", l_rsd->m_HssHost, l_rsd->m_HssRealm, l_rsd->m_MmeHost, l_rsd->m_MmeRealm, 1, 0, l_rsd->m_partType, "CROSS_CL_UPG");
                           LLOG(0,0,"Sending CROSS CL");
                           g_esc.initiateIndependentContext(this, DIAM_COMM_CODE_S6A_S6D_CLR_CLA, l_CancelLocXml, INITIATION_TYPE_IMMEDIATE);
                        }
                     }
                     //  HSS CHANGE END   ////
#endif //Commented in HLR 2.0.0.0
                  }
                  break;              
               case m_usd:
                  {
                     DLOG(0,0,"Got a Response from DB after updating Subsciber Data");
                     UpdateSGSNData *l_usd = (UpdateSGSNData*) p_MsgPtr;
                     l_UserDlgId = l_usd->m_UserDlgId;
                     DLOG(0,0,"MAP_MSG_TYPE_DB received with DlgId %d",l_UserDlgId);
                     if(l_usd->m_ErrorCode != 0)
                     {
                        m_tdr.setInteger(TDR_INDEX_DB_ERR_CODE,l_usd->m_ErrorCode); 
                        m_tdr.setString(TDR_INDEX_DB_ERR_DESC,(char *)l_usd->m_ErrorMsg);
                     }
                     if(l_usd->m_DbQueryRes == DB_QUERY_RES_SUCCESS)
                     {
                        LLOG(0,0,"Successful updatation of UPG data in DB,Ending of this CtxtUpdateGPRSLocation");
                        /*
                           if(m_InitiateNoteMsPresent)
                           {
                           LLOG(0,0,"Initiating Note MS present for GPRS for IMSI %s",l_upgv3.imsi);
                           g_sc.initiateIndependentContext(this, MAP_OP_CODE_noteMsPresentForGprs,(char *)l_upgv3.imsi, INITIATION_TYPE_TARDILY);
                           }
                           */
                     }
                     else
                     {
                        CLOG(0,0,"Error while updating UPG data in DB");
                     }
                  }
                  break;                  
               case m_usdf:
                  {
                     DLOG(0,0,"Got a Response from DB after updating Subsciber Data");
                     UpdateSGSNData *l_usd = (UpdateSGSNData*) p_MsgPtr;
                     l_UserDlgId = l_usd->m_UserDlgId;
                     DLOG(0,0,"MAP_MSG_TYPE_DB received with DlgId %d",l_UserDlgId);
                     if(l_usd->m_ErrorCode != 0 )
                     {
                        m_tdr.setInteger(TDR_INDEX_DB_ERR_CODE,l_usd->m_ErrorCode); 
                        m_tdr.setString(TDR_INDEX_DB_ERR_DESC,(char *)l_usd->m_ErrorMsg);
                     }
                     if(l_usd->m_DbQueryRes == DB_QUERY_RES_SUCCESS)
                     {
                        LLOG(0,0,"Successful updatation of UPG data in DB on failure");
                        return true;
                     }
                     else
                     {
                        CLOG(0,0,"Error while updating UPG data in DB");
                     }
                  }
                  break;                  
               default:
                  {
                     ELOG(0,0,"Did not expect a DB data at this Call state");
                  }
                  break;
            }
         }
         break;

      default:
         DLOG(0, 0, "Unknown message received");
         break;
   }
   return true;
}

int CtxtUpdateGPRSLocation::processDBData(int l_UserDlgId,RetrieveSubsSGSNData *l_rsd)
{
   DLOG(0,0,"Inside process DB data for Dialog id %d",l_UserDlgId);
   strncpy((char *)l_AccId,(char *)l_rsd->m_AccId,strlen((char *)l_rsd->m_AccId));   
   m_tdr.setString(TDR_INDEX_ACCOUNT_ID, (char *)l_rsd->m_AccId);
   l_nwId = l_rsd->m_nwid;   
   l_pnwId = l_rsd->m_pnwid;
   m_ApnOiOverrideIndVal = l_rsd->m_ApnOiOverrideInd_OUT;
   m_tdr.setInteger(TDR_INDEX_SSM_BS_TYPE, m_ApnOiOverrideIndVal); // 37th index
   l_AlocType = l_rsd->m_AlocType;
   strncpy((char *)l_actMsisdn,(char *)l_rsd->m_ActMsisdn,strlen((char*)l_rsd->m_ActMsisdn));
   //1.0.12.0
   /*   strncpy((char *)l_priMsisdn,(char *)l_rsd->m_PriMsisdn,strlen((char *)l_rsd->m_PriMsisdn));
        m_tdr.setString(TDR_INDEX_MM_PRIMARY_MSISDN,(char *)l_priMsisdn);
        strncpy((char *)l_priImsi,(char *)l_rsd->m_PriImsi,strlen((char*)l_rsd->m_PriImsi));
        m_tdr.setString(TDR_INDEX_MM_PRIMARY_IMSI,(char *)l_priImsi);*/
   l_roamInd = l_rsd->m_RoamIND;
   strncpy((char *)l_hlrAddr,(char *)l_rsd->m_HlrADDR,strlen((char *)l_rsd->m_HlrADDR));
   m_mwd_flag = l_rsd->m_mwd_flag;

   if(true == m_fIsd)
   {
      map<int, HlrNetworks* > :: iterator l_HlrNetworksDetailsIter;
      l_HlrNetworksDetailsIter = g_spdPtr->m_HlrNetworks.find(l_nwId);
      if(l_HlrNetworksDetailsIter == g_spdPtr->m_HlrNetworks.end())
      {
         LLOG(0,0,"Network ID not found in networks map[%d]",l_nwId);
      }
      else
      {
         DLOG(0,0,"Network ID found in networks map[%d]",l_nwId);
         LLOG(0,0,"Change Template Sgsn Action in Networks page is ... [%d]",((l_HlrNetworksDetailsIter->second)->m_ChangeTempSgsnAction));
         m_tdr.setInteger(TDR_INDEX_SSM_USSD_SERV_CODE,((l_HlrNetworksDetailsIter->second)->m_ChangeTempSgsnAction));
      }
   }

   if(m_mwd_flag)
   {
      strncpy((char *)m_AlertMsisdn,(char *)l_rsd->m_alertMsisdn,strlen((char *)l_rsd->m_alertMsisdn));
   }

   LLOG(0,0,"DBRES: AccountID[%s] NetworkId[%d] PartnerNkId[%d] MsisdnAllocationType[%d] ActiveMSISDN[%s] PrimaryMSISDN[%s] PrimaryIMSI[%s] RoamingIndicator[%d] HLRAddress[%s] MWD_Flag[%d] Alert_Msisdn[%s] PartnerType[%d] ApiOiOverrideIndicator[%d]"
         ,l_AccId,l_nwId,l_pnwId,l_AlocType,l_actMsisdn,l_priMsisdn,l_priImsi,l_roamInd,l_hlrAddr,m_mwd_flag,m_AlertMsisdn,l_rsd->m_partType,m_ApnOiOverrideIndVal);

   // HLR 1.0.16.0 Begin
   char l_allocTypeBuf[50];
   memset(l_allocTypeBuf,'\0',sizeof(l_allocTypeBuf));

   char l_partnerTypeBuf[30];
   memset(l_partnerTypeBuf,'\0',sizeof(l_partnerTypeBuf));

   if(0 == l_AlocType)
   {
      strcpy(l_allocTypeBuf,"Home Msisdn");
   }
   else if(1 == l_AlocType)
   {
      strcpy(l_allocTypeBuf,"Dummy Msisdn");
   }
   else if(2 == l_AlocType)
   {
      strcpy(l_allocTypeBuf,"CBOS Allocated Msisdn");
   }
   else if(3 == l_AlocType)
   {
      strcpy(l_allocTypeBuf,"LERG Allocated Msisdn");
   }
   else if(4 == l_AlocType)
   {
      strcpy(l_allocTypeBuf,"Home Real Msisdn");
   }
   else if(5 == l_AlocType)
   {
      strcpy(l_allocTypeBuf,"Temporary Dummy Msisdn");
   }

   if(0 == (l_rsd->m_partType))
   {
      strcpy(l_partnerTypeBuf,"Home");
   }
   else if(1 == (l_rsd->m_partType))
   {
      strcpy(l_partnerTypeBuf,"Internal");
   }
   else if(2 == (l_rsd->m_partType))
   {
      strcpy(l_partnerTypeBuf,"External");
   }

   LLOG(0,0,"DBRES: Subscriber Msisdn Allocation Type [%s] and Partner Type [%s]",l_allocTypeBuf,l_partnerTypeBuf);
   // HLR 1.0.16.0 End
   //
   //Added in 1.0.8.0 to write Roaming indicator in TDR, using CM_TCSI_STATUS field as of now...
   //
   m_tdr.setInteger(TDR_INDEX_CM_SRI_TCSI_STATUS,l_roamInd);
   //
   //

   //Added in 1.0.6.0
   bool l_GprsSmsSupported = false;
   //1.0.6.0


   char GenPro[300];
   //char *tmp1;
   memset(GenPro,'\0',sizeof(GenPro));
   strncpy(GenPro,"|",1);
   strncat(GenPro,(char *)l_rsd->m_GenINFO,strlen((char *)l_rsd->m_GenINFO));
   strncat(GenPro,"|",1);
   //tmp1 = strtok(GenPro,"|");
   //DLOG(0,0,"The string tested is %s\n",GenPro);
   char str[21][53];
   memset(str,'\0',sizeof(str));
   {      
      char *ptr1, *ptr2;
      ptr1=ptr2=GenPro;
      ptr2++;
      int i=1;
      while(*ptr2 != '\0')
      {
         if('|' == *ptr2)
         {
            //DLOG(0,0,"Found |\n");
            if(ptr2-ptr1 == 1)
            {
               strncpy(str[i],"|0",2);
               //DLOG(0,0,"str[%d]:%s\n",i,str[i]);
            }
            else
            {
               //strncpy(str,ptr1,ptr2-ptr1);
               strncpy(str[i],ptr1,ptr2-ptr1);
               str[i][ptr2-ptr1]='\0';
               //DLOG(0,0,"str[%d]:%s\n",i,str[i]+1);
            }
            ptr1=ptr2;
            i++;
         }

         ptr2++;
      }
      GenProfile.l_nwAccMode = atoi(str[1]+1);
      // 2.0.0.0 Begin
      int l_Converted_Nam = 0;
      bool l_Nam_Applicable = true;
      if( (0 == GenProfile.l_nwAccMode) || (7 == GenProfile.l_nwAccMode) )
      {
         GenProfile.l_nwAccMode = 0;
      }
      else if( (1 ==  GenProfile.l_nwAccMode) || (5 == GenProfile.l_nwAccMode) )
      {
         GenProfile.l_nwAccMode = 1;
      }
      else if( (2 ==  GenProfile.l_nwAccMode) || (6 == GenProfile.l_nwAccMode) )
      {
         GenProfile.l_nwAccMode = 2;
      }
      else
      {
         ELOG(0,0,"DBRES: Invalid NAM value[%d] .. setting default 0",GenProfile.l_nwAccMode);
         GenProfile.l_nwAccMode = 0;
      }
      // 2.0.0.0 End

      GenProfile.l_catgory = atoi(str[2]+1);
      GenProfile.l_subsRest = atoi(str[3]+1);
      GenProfile.l_accRest = atoi(str[4]+1);
      GenProfile.l_lmu = atoi(str[5]+1);
      GenProfile.l_ist = atoi(str[6]+1);
      GenProfile.l_ocsiPid = atoi(str[7]+1);
      GenProfile.l_tcsiPid = atoi(str[8]+1);
      GenProfile.l_ugcsiPid = atoi(str[9]+1);
      GenProfile.l_sscsiPid = atoi(str[10]+1);
      GenProfile.l_tifcsiPid = atoi(str[11]+1);
      GenProfile.l_dcsiPid = atoi(str[12]+1);
      GenProfile.l_moscsiPid = atoi(str[13]+1);
      GenProfile.l_mtscsiPid = atoi(str[14]+1);
      GenProfile.l_gcsiPid = atoi(str[15]+1);
      GenProfile.l_mgcsiPid = atoi(str[16]+1);
      GenProfile.l_pdpPid = atoi(str[17]+1);
      GenProfile.l_subsStatus = atoi(str[18]+1);
      strncpy(GenProfile.l_bearer,str[19]+1,strlen(str[19]));
      strncpy(GenProfile.l_tele,str[20]+1,strlen(str[20]));
      m_tdr.setInteger(TDR_INDEX_MM_NAM,GenProfile.l_nwAccMode);
      TLOG(0,0,"Received PDP profile id %d,Teleservice list %s",GenProfile.l_pdpPid,GenProfile.l_tele);

      if(GenProfile.l_pdpPid == 0)
      {
         CLOG(0,0,"PDP profile not configured, sending SYSTEM FAILURE");
         return 1;
      }
      if(false == m_isd.Sgsncsi.ValidateAllCsi(l_UserDlgId,GenProfile.l_pdpPid,GenProfile.l_gcsiPid,GenProfile.l_moscsiPid,GenProfile.l_mtscsiPid))
      {
         CLOG(0,0,"Validate all csi false, returning 1");
         return 1;
      }



      map<u16,PDP*>::iterator l_pdpItr;
      l_pdpItr = g_spdPtr->m_PDPMap.find(GenProfile.l_pdpPid);
      PDP *l_pdp = l_pdpItr->second;
      DLOG(0,0,"VALUE OF PDPPROFILEID[%d] GPRSSMSSUPPORTED[%d]",GenProfile.l_pdpPid,l_pdp->m_GprsSmsSupported);
      DLOG(0,0,"m_pdpContextCount[%d] m_ChargingChar[%s] ", l_pdp->m_pdpContextCount,(char*)l_pdp->m_ChargingChar);
      if(1 == (l_pdp->m_GprsSmsSupported))
      {
         l_GprsSmsSupported = true;
         TLOG(0,0,"GPRS SMS Support indicator set,Removing Telephony related teleservice data");
         for(int j=0;j<4;j++)
         {
            GenProfile.l_tele[j] = '0';
         }
         TLOG(0,0,"Teleservice list %s after modification",GenProfile.l_tele);
      }
      else
      {
         l_GprsSmsSupported = false;
         TLOG(0,0,"GPRS SMS Support indicator not set,Removing Telephony and SMS related teleservice data");
         for(int j=0;j<7;j++)
         {
            GenProfile.l_tele[j] = '0';
         }
         TLOG(0,0,"Teleservice list %s after modification",GenProfile.l_tele);
      }
      memset(m_isd.dbisd3.ChrgChar,'\0',sizeof(m_isd.dbisd3.ChrgChar));
      m_isd.dbisd3.ChrgChar[0] = l_pdp->m_ChargingChar[0];
      m_isd.dbisd3.ChrgChar[1] = l_pdp->m_ChargingChar[1];
      TLOG(0,0,"Charging charecteristics received %02x%02x",m_isd.dbisd3.ChrgChar[0],m_isd.dbisd3.ChrgChar[1]);
      if(l_roamInd)
      {
         TLOG(0,0,"Roaming indicator set, removing PLMN specific bearer and tele sercice list");
         for(int ltele = 16;ltele < 32;ltele++)
         {
            GenProfile.l_tele[ltele] = '0';
         }
         for(int lbear = 36;lbear < 52;lbear++)
         {
            GenProfile.l_bearer[lbear] = '0';
         }
      }
   }

   char GprsPro[300];
   memset(GprsPro,'\0',300);
   //char *tmp2;
   strncpy(GprsPro,"|",1);
   strncat(GprsPro,(char *)l_rsd->m_GprsINFO,strlen((char *)l_rsd->m_GprsINFO));
   strncat(GprsPro,"|",1);
   //DLOG(0,0,"The string tested is %s\n",GprsPro);
   char str2[25][22];
   memset(str2,'\0',sizeof(str2));
   {      
      char *ptr1, *ptr2;
      ptr1=ptr2=GprsPro;
      ptr2++;
      int i=1;
      while(*ptr2 != '\0')
      {
         if('|' == *ptr2)
         {
            //DLOG(0,0,"Found |\n");
            if(ptr2-ptr1 == 1)
            {
               strcpy(str2[i],"|0");
               //DLOG(0,0,"str[%d]:%s\n",i,str[i]);
            }
            else
            {
               //strncpy(str,ptr1,ptr2-ptr1);
               strncpy(str2[i],ptr1,ptr2-ptr1);
               str2[i][ptr2-ptr1]='\0';
               //DLOG(0,0,"str[%d]:%s\n",i,str[i]+1);
            }
            ptr1=ptr2;
            i++;
         }

         ptr2++;
      }
      strncpy((char *)GprsProfile.l_ActMsisdn,str2[1]+1,strlen(str2[1]));
      strncpy((char *)GprsProfile.l_Actimsi,str2[2]+1,strlen(str2[2]));
      GprsProfile.l_roamInd = atoi(str2[3]+1);
      strncpy((char *)GprsProfile.l_sgsnno,str2[4]+1,strlen(str2[4]));
      strncpy((char *)GprsProfile.l_sgsnAddr,str2[5]+1,strlen(str2[5]));
      GprsProfile.l_sgsnRest = atoi(str2[6]+1);
      GprsProfile.l_msPur_gprs = atoi(str2[7]+1);
      GprsProfile.l_mnrg = atoi(str2[8]+1);
      GprsProfile.l_roamrestduf = atoi(str2[9]+1);
      strncpy((char *)GprsProfile.l_ActHLRAddr,str2[10]+1,strlen(str2[10]));
      GprsProfile.l_ActPnwId = atoi(str2[11]+1);
      GprsProfile.l_TraceFlag = atoi(str2[12]+1);
      strncpy((char *)GprsProfile.l_TraceRef,str2[13]+1,strlen(str2[13]+1));
      strncpy((char *)GprsProfile.l_TraceType,str2[14]+1,strlen(str2[14]+1));
      strncpy((char *)GprsProfile.l_OmcId,str2[15]+1,strlen(str2[15]+1));
      GprsProfile.l_TraceStatus = atoi(str2[16]+1);
      strncpy((char *)GprsProfile.l_lmsino,str2[17]+1,strlen(str2[17]));
      strncpy((char *)GprsProfile.l_vlrNum,str2[18]+1,strlen(str2[18]));

      if(GenProfile.l_subsStatus == 1)
      {
         unsigned int l_GenOdb_DB = 0;
         l_GenOdb_DB = atoi(str2[19]+1);
         l_GenOdb = l_GenOdb_DB & SGSN_SUPPORTED_ODB;
         TLOG(0,0,"General ODB data from DB is %ld, After conv %ld",l_GenOdb_DB,l_GenOdb);
         if(l_roamInd == 0)
         {
            unsigned int l_WrongHplmn = atoi(str2[20]+1);
            l_PlmnOdb = HplmnOdb(l_WrongHplmn);             
         }
         else
         {
            l_PlmnOdb = 0;
         }
         if((l_GenOdb == 0) && (l_PlmnOdb == 0))
         {
            GenProfile.l_subsStatus = 0;
            TLOG(0,0,"GenODB data is %ld and HPLMN Specific ODB data %ld,setting Subs_Status %d",l_GenOdb,l_PlmnOdb,GenProfile.l_subsStatus);
         }
      }
      else
      {
         l_GenOdb = 0;
         l_PlmnOdb = 0;         
      }
   }
   if(l_roamInd)
   {
      TLOG(0,0,"Subscriber is not in HPLMN area, ignoring traceflag");
      GprsProfile.l_TraceFlag = 0;
   }
#if 0
   //added in 1.0.14.0 Rev1
   int l_check = 0;
   if(l_Version == 3)
   {
      l_check = strcmp((char *)GprsProfile.l_sgsnno,(char *)l_upgv3.SgsnNo+2);
   }
   if(0 == l_check)
   {
      if(GprsProfile.l_ActPnwId != l_rsd->m_pnwid)
      {
         LLOG(0,0,"Same SGSN But different pwids %d %d", GprsProfile.l_ActPnwId, l_rsd->m_pnwid);
         if(strlen((char*)GprsProfile.l_vlrNum) > 5)
         {
            l_check=1;
         }
      }
   }
   //end of addition
#endif

#if 0
   if(strncmp((char *)GprsProfile.l_sgsnno,"0",1)==0)
   {
      DLOG(0,0,"Existing SGSN Number is null");
      m_SendCl = true;
   }


   char XmlReq[501];
   unsigned char lmsi[9];
   if( (strncmp((char *)GprsProfile.l_sgsnno,"0",1)!=0) && 
         ( (strcmp((char *)GprsProfile.l_sgsnno,(char *)l_upgv3.SgsnNo+2)!=0)  || 
           (GprsProfile.l_ActPnwId != l_rsd->m_pnwid)) )
   {
      DLOG(0,0,"Received SGSN Number %s is different from that of in DB %s",l_upgv3.SgsnNo+2,GprsProfile.l_sgsnno);
      memset(XmlReq,'\0',sizeof(XmlReq));
      memset(lmsi,'\0',sizeof(lmsi));
      strcpy((char *)lmsi,"00000000");
      m_tdr.setString(TDR_INDEX_MM_PREVIOUS_NODE,(s8*)GprsProfile.l_sgsnno);
      FormXMLRequest(XmlReq,2, GprsProfile.l_Actimsi,lmsi, GprsProfile.l_ActHLRAddr, GprsProfile.l_sgsnno,0,0,"UPDATE_GPRS_LOC","");
      m_SendCl = true;

      LLOG(0,0,"Sending XmlReq %s to CtxtCancelLocation",XmlReq);
      g_sc.initiateIndependentContext(this,MAP_OP_CODE_cancelLocation,(char *)XmlReq, INITIATION_TYPE_IMMEDIATE);
   }

   if(   (GprsProfile.l_ActPnwId != l_rsd->m_pnwid) && (strlen((char*)GprsProfile.l_vlrNum) > 5) )
   {
      memset(XmlReq, '\0', sizeof(XmlReq));
      memset(lmsi,'\0',sizeof(lmsi));
      if((strcmp((char *) GprsProfile.l_lmsino, "0") != 0) && (strcmp((char *) GprsProfile.l_lmsino, "00000000") != 0))
      {
         strcpy((char *) lmsi, (char *) GprsProfile.l_lmsino);
      }
      else
      {
         strcpy((char *) lmsi, "00000000");
      }
      LLOG(0, 0, "UPDATE_GPRS_LOC_IMSI_CHANGE Initiating cancel location to previous VLR Number %s with HLR address %s for IMSI %s", GprsProfile.l_vlrNum, GprsProfile.l_ActHLRAddr, GprsProfile.l_Actimsi);
      FormXMLRequest(XmlReq,1, GprsProfile.l_Actimsi,lmsi, GprsProfile.l_ActHLRAddr, GprsProfile.l_vlrNum,2,0,"UPDATE_GPRS_LOC_IMSI_CHANGE","");
      DLOG(0, 0, "Sending XmlReq %s to CtxtCancelLocation", XmlReq);
      g_sc.initiateIndependentContext(this, MAP_OP_CODE_cancelLocation, (char *) XmlReq, INITIATION_TYPE_IMMEDIATE);
   }

#endif //Commented in HLR 2.0.0.0

#if 0 // Removed in 1.0.8.0 for moving these validations to DB query
   if((GenProfile.l_gcsiPid || GenProfile.l_moscsiPid || GenProfile.l_mtscsiPid ))
   {
      if(l_upgv3.SgsnCap_Phase < 3)
      {
         CLOG(0,0,"Max SGSN camel phase received %d, should be minimum 3",l_upgv3.SgsnCap_Phase);
         return 2;
      }
      if(l_roamInd == 0)
      {
         if(g_MmConfigReaderObj->m_Home_CAP_Filtering)
         {         
            DLOG(0,0,"Checking the Camel capability of HOME_CAMEL_PHASE %s with received CAMEL_PHASE %s MAX camel phase supported %d",g_MmConfigReaderObj->m_home_cap_version,l_upgv3.SgsnCap_Camel,l_upgv3.SgsnCap_Phase);
            if(g_MmConfigReaderObj->m_home_cap_version[l_upgv3.SgsnCap_Phase -1] == '1')
            {
               LLOG(0,0,"Received Camel phase components %s and Configured Camel phases %s Max camel phase %d are same, Continuing",l_upgv3.SgsnCap_Camel,g_MmConfigReaderObj->m_home_cap_version,l_upgv3.SgsnCap_Phase);              
            }
            else
            {
               LLOG(0,0,"Received Camel phase components %s and Configured Camel phases %s Max camel phase supported %d are different, returning false ",l_upgv3.SgsnCap_Camel,g_MmConfigReaderObj->m_home_cap_version,l_upgv3.SgsnCap_Phase);
               return 2; 
            }
         }
         else
         {
            LLOG(0,0,"Subscriber is in Home and HOME Camel filtering flag configured is %d, Not Checking it",g_MmConfigReaderObj->m_Home_CAP_Filtering);
         }            
      }
      else
      {
         if(g_MmConfigReaderObj->m_Roam_CAP_Filtering)
         {
            DLOG(0,0,"Checking the Camel capability of ROAM_CAMEL_PHASE %s with received CAMEL_PHASE %s Max camel phase supported %d",g_MmConfigReaderObj->m_roam_cap_version,l_upgv3.SgsnCap_Camel,l_upgv3.SgsnCap_Phase);
            if(g_MmConfigReaderObj->m_roam_cap_version[l_upgv3.SgsnCap_Phase - 1] == '1')
            {
               LLOG(0,0,"Received Camel phase components %s and Configured Camel phases %s Max camel phase %d are same, Continuing",l_upgv3.SgsnCap_Camel,g_MmConfigReaderObj->m_roam_cap_version,l_upgv3.SgsnCap_Phase);              
            }
            else
            {
               LLOG(0,0,"Received Camel phase components %s and Configured Camel phases %s Max camel phase %d are different, returning false",l_upgv3.SgsnCap_Camel,g_MmConfigReaderObj->m_roam_cap_version,l_upgv3.SgsnCap_Phase);
               return 2; 
            }
         }
         else
         {
            LLOG(0,0,"Subscriber is in Roaming and Roam Camel filtering flag configured is %d, Not Checking it",g_MmConfigReaderObj->m_Roam_CAP_Filtering);
         }            
      }                   
   }
   else
   {
      TLOG(0,0,"No CSI configured, not checking the camel phase and the CSI");
   }
#endif   
   setTraceMsisdn((char *)l_actMsisdn);
   m_tdr.setString(TDR_INDEX_REQUEST_MSISDN,(char*)l_actMsisdn);
   LLOG(0,0,"Trace enabled on MSISDN %s",(char *)l_actMsisdn);

   //All CB SS Data inside this,Initializing all Counts
   m_isd.pss.boacCount = 0;  m_isd.pss.boacSsCode = 0;
   m_isd.pss.boicCount = 0;  m_isd.pss.boicSsCode = 0;
   m_isd.pss.boihcCount = 0; m_isd.pss.boihcSsCode = 0;
   m_isd.pss.baicCount = 0;  m_isd.pss.baicSsCode = 0;
   m_isd.pss.bicrCount = 0;  m_isd.pss.bicrSsCode = 0;
#if 1
   for(int acb = 0;acb<l_rsd->m_CBCount;acb++)
   {
      DLOG(0,0,"All Call Barring Data[%d]             : %s",acb,l_rsd->m_CBData[acb]);
      char ACB[100][100];
      memset(ACB[acb],'\0',100);
      strncat(ACB[acb],"|",1);
      strncat(ACB[acb],(char *)l_rsd->m_CBData[acb],strlen((char *)l_rsd->m_CBData[acb]));
      strncat(ACB[acb],"|",1);
      DLOG(0,0,"CB String : %s",ACB[acb]);
      char str13[100][100];
      memset(str13,'\0',sizeof(str13));
      {
         char *ptr1, *ptr2;
         ptr1=ptr2=ACB[acb];
         ptr2++;
         int i=1;
         while(*ptr2 != '\0')
         {
            if('|' == *ptr2)
            {
               //DLOG(0,0,"Found |\n");
               if(ptr2-ptr1 == 1)
               {
                  strcpy(str13[i],"|0");
                  //DLOG(0,0,"str[%d]:%s\n",i,str1[i]);
               }
               else
               {
                  //strncpy(str,ptr1,ptr2-ptr1);
                  strncpy(str13[i],ptr1,ptr2-ptr1);
                  str13[i][ptr2-ptr1]='\0';
                  //DLOG(0,0,"str1[%d]:%s\n",i,str1[i]+1);
               }
               ptr1=ptr2;
               i++;
            }

            ptr2++;
         }
      }       
      //Barring of All Outgoing Call
      if(atoi(str13[1]+1) == 146)
      {
         if((l_GprsSmsSupported == false) && ((atoi(str13[3]+1) == 32) || (atoi(str13[3]+1) == 33) || (atoi(str13[3]+1) == 34)))
         {
            continue;
         }
         m_isd.pss.boacSsCode = 146;            
         m_isd.pss.boacSsStatus[m_isd.pss.boacCount] = atoi(str13[2]+1);
         m_isd.pss.boacBCode[m_isd.pss.boacCount] = atoi(str13[3]+1);
         m_isd.pss.boacBType[m_isd.pss.boacCount] = atoi(str13[4]+1);
         DLOG(0,0,"SSCODE[%d] = %d, SS_Status[%d] = %d, Basic Service Code[%d] = %d,Basic Service Type[%d] = %d",
               m_isd.pss.boacCount,m_isd.pss.boacSsCode,m_isd.pss.boacCount,m_isd.pss.boacSsStatus[m_isd.pss.boacCount],m_isd.pss.boacCount,m_isd.pss.boacBCode[m_isd.pss.boacCount],m_isd.pss.boacCount,m_isd.pss.boacBType[m_isd.pss.boacCount]);
         m_isd.pss.boacCount += 1;
      }
      //barring of All Outgoing International calls
      if(atoi(str13[1]+1) == 147)
      {
         if((l_GprsSmsSupported == false) && ((atoi(str13[3]+1) == 32) || (atoi(str13[3]+1) == 33) || (atoi(str13[3]+1) == 34)))
         {
            continue;
         }
         m_isd.pss.boicSsCode = 147;            
         m_isd.pss.boicSsStatus[m_isd.pss.boicCount] = atoi(str13[2]+1);
         m_isd.pss.boicBCode[m_isd.pss.boicCount] = atoi(str13[3]+1);
         m_isd.pss.boicBType[m_isd.pss.boicCount] = atoi(str13[4]+1);
         DLOG(0,0,"SSCODE[%d] = %d, SS_Status[%d] = %d, Basic Service Code[%d] = %d,Basic Service Type[%d] = %d",
               m_isd.pss.boicCount,m_isd.pss.boicSsCode,m_isd.pss.boicCount,m_isd.pss.boicSsStatus[m_isd.pss.boicCount],m_isd.pss.boicCount,m_isd.pss.boicBCode[m_isd.pss.boicCount],m_isd.pss.boicCount,m_isd.pss.boicBType[m_isd.pss.boicCount]);
         m_isd.pss.boicCount += 1;
      }
      //Barring of Internation outgoing calls except for HPLMN country
      if(atoi(str13[1]+1) == 148)
      {
         if((l_GprsSmsSupported == false) && ((atoi(str13[3]+1) == 32) || (atoi(str13[3]+1) == 33) || (atoi(str13[3]+1) == 34)))
         {
            continue;
         }
         m_isd.pss.boihcSsCode = 148;            
         m_isd.pss.boihcSsStatus[m_isd.pss.boihcCount] = atoi(str13[2]+1);
         m_isd.pss.boihcBCode[m_isd.pss.boihcCount] = atoi(str13[3]+1);
         m_isd.pss.boihcBType[m_isd.pss.boihcCount] = atoi(str13[4]+1);
         DLOG(0,0,"SSCODE[%d] = %d, SS_Status[%d] = %d, Basic Service Code[%d] = %d,Basic Service Type[%d] = %d",
               m_isd.pss.boihcCount,m_isd.pss.boihcSsCode,m_isd.pss.boihcCount,m_isd.pss.boihcSsStatus[m_isd.pss.boihcCount],m_isd.pss.boihcCount,m_isd.pss.boihcBCode[m_isd.pss.boihcCount],m_isd.pss.boihcCount,m_isd.pss.boihcBType[m_isd.pss.boihcCount]);
         m_isd.pss.boihcCount += 1;
      }       
   }
   DLOG(0,0,"Call barring for all Out going call = %d",m_isd.pss.boacCount);
   DLOG(0,0,"Call barring for international outgoing call = %d",m_isd.pss.boicCount);
   DLOG(0,0,"Call barring for internation outgoing calls except for HPLMN country = %d",m_isd.pss.boihcCount);
#endif   
   m_InitiateNoteMsPresent = l_rsd->m_pwd_flag;
   TLOG(0,0,"m_pwd_flag = %d",m_InitiateNoteMsPresent);
   return 0;
}


bool CtxtUpdateGPRSLocation::CheckParameters(int l_UserDlgId, IMAP3_UpdateGprsLocationArg *l_temp)//yet to do
{
   memset(&l_upgv3,'\0',sizeof(Details));
   BCDToString(l_upgv3.imsi,l_temp->imsi.value,l_temp->imsi.length);
   if(strlen((char *)l_upgv3.imsi) != IMSILEN)
      return false;
   setTraceImsi((char *)l_upgv3.imsi);
   m_tdr.setChar(TDR_INDEX_REQUEST_TYPE,'I'); // 1-msisdn 2-imsi 3-both
   m_tdr.setString(TDR_INDEX_REQUEST_IMSI,(char*)l_upgv3.imsi);
   TLOG(0,0,"Trace enabled on imsi %s",(char *)l_upgv3.imsi);

   BCDToString(l_upgv3.SgsnNo,l_temp->sgsn_Number.value,l_temp->sgsn_Number.length);
   if(MINISDNADDRLEN > strlen((char*)l_upgv3.SgsnNo+2))//|| strlen((char*)l_upgv3.SgsnNo+2) > MAXISDNADDRLEN)
      return false;

   m_tdr.setString(TDR_INDEX_SGSN_ADDRESS,(char*)l_upgv3.SgsnNo+2);
   //BCDToString(l_upgv3.SgsnAddr,l_temp->sgsn_Address.value,l_temp->sgsn_Address.length);
   char l_sgsn[20];
   memset(l_sgsn,'\0',sizeof(l_sgsn));
   if(0x04 == l_temp->sgsn_Address.value[0])
   {
      sprintf(l_sgsn,"%d.%d.%d.%d",l_temp->sgsn_Address.value[1],l_temp->sgsn_Address.value[2],l_temp->sgsn_Address.value[3],l_temp->sgsn_Address.value[4]);
      strcpy((char *)l_upgv3.SgsnAddr,l_sgsn);
   }
   else
   {
      CLOG(0,0,"SGSN address IP version is not IPv4, sending error");
      return false;
   }
   if(1 > strlen((char*)l_upgv3.SgsnAddr))
   {
      WLOG(0,0,"SGSN Address length less than 1");
      return false;
   }   
   if(strcmp((char*)l_upgv3.SgsnAddr,"0.0.0.0") == 0)
   {
      CLOG(0,0,"SGSN Address is %s, sending error",(char*)l_upgv3.SgsnAddr);
      return false;
   }


   LLOG(0,0,"IMSI %s Sgsn_Number: %s Sgsn_Address %s",l_upgv3.imsi,l_upgv3.SgsnNo+2,l_upgv3.SgsnAddr);
   m_tdr.setString(TDR_INDEX_SGSN_IP_ADDRESS,(char*)l_upgv3.SgsnAddr);
#if 1//All optional parameters inside this
   l_upgv3.SgsnCap_Camel1 = false;l_upgv3.SgsnCap_Camel2 = false;l_upgv3.SgsnCap_Camel3 = false;l_upgv3.SgsnCap_Camel4 = false;
   l_upgv3.SgsnCap_Phase = 0; 
   memset(l_upgv3.SgsnCap_Camel,'\0',sizeof(l_upgv3.SgsnCap_Camel));
   strncpy(l_upgv3.SgsnCap_Camel,"0000",4);
   if(l_temp->bit_mask & IMAP3_sgsn_Capability_present)
   {
      if(l_temp->sgsn_Capability.bit_mask & IMAP3_SGSN_Capability_supportedCamelPhases_present)
      {
         DLOG(0,0,"Camel phase support indicator present");
         l_upgv3.SgsnCap_Camel1 = false;l_upgv3.SgsnCap_Camel2 = false;l_upgv3.SgsnCap_Camel3 = false;l_upgv3.SgsnCap_Camel4 = false;
         memset(l_upgv3.SgsnCap_Camel,'\0',5);
         if(*l_temp->sgsn_Capability.supportedCamelPhases.value & IMAP3_phase1)
         {
            DLOG(0,0,"CAMEL Phase 1 supported");
            l_upgv3.SgsnCap_Camel1 = true;
            l_upgv3.SgsnCap_Camel[0] = '1';
            l_upgv3.SgsnCap_Phase = 1;
         }
         else
         {
            l_upgv3.SgsnCap_Camel[0] = '0';
         }
         if(*l_temp->sgsn_Capability.supportedCamelPhases.value & IMAP3_phase2)
         {
            DLOG(0,0,"CAMEL Phase 2 supported");
            l_upgv3.SgsnCap_Camel2 = true;
            l_upgv3.SgsnCap_Camel[1] = '1';
            l_upgv3.SgsnCap_Phase = 2;
         }
         else
         {
            l_upgv3.SgsnCap_Camel[1] = '0';
         }
         if(*l_temp->sgsn_Capability.supportedCamelPhases.value & IMAP3_phase3)
         {
            DLOG(0,0,"CAMEL Phase 3 supported");
            l_upgv3.SgsnCap_Camel3 = true;
            l_upgv3.SgsnCap_Camel[2] = '1';
            l_upgv3.SgsnCap_Phase = 3;
         }
         else
         {
            l_upgv3.SgsnCap_Camel[2] = '0';
         }
         if(*l_temp->sgsn_Capability.supportedCamelPhases.value & IMAP3_phase4)
         {
            DLOG(0,0,"CAMEL Phase 4 supported");
            l_upgv3.SgsnCap_Camel4 = true;
            l_upgv3.SgsnCap_Camel[3] = '1';
            l_upgv3.SgsnCap_Phase = 4;
         }
         else
         {
            l_upgv3.SgsnCap_Camel[3] = '0';
         }
         LLOG(0,0,"Formed Camel data string is %s Max camel phase supported %d",l_upgv3.SgsnCap_Camel,l_upgv3.SgsnCap_Phase);
         if(l_upgv3.SgsnCap_Phase < 3)
         {
            CLOG(0,0,"The SGSN can only support CAMEL phase 3 or greater");
            return false;
         }
      }
      /*else
        {
        DLOG(0,0,"CAMEL phase support indicator not present in SGSN Capability,assuming default as phase 1");
        l_upgv3.SgsnCap_Camel1 = true;
        l_upgv3.SgsnCap_Camel[0] = '1';
        l_upgv3.SgsnCap_Camel[1] = '0';l_upgv3.SgsnCap_Camel[2] = '0';l_upgv3.SgsnCap_Camel[3] = '0';
        l_upgv3.SgsnCap_Phase = 1;
        }*/
      if(l_temp->sgsn_Capability.bit_mask & IMAP3_SGSN_Capability_solsaSupportIndicator_present)
      {
         DLOG(0,0,"soLSA support present");
         l_upgv3.soLSA = true;         
      }
      if(l_temp->sgsn_Capability.bit_mask & IMAP3_gprsEnhancementsSupportIndicator_present)
      {
         TLOG(0,0,"GPRS EnhancementsSupportIndicator present");
         l_upgv3.gprsEncSupIndicator = 1;
      }
      if(l_temp->sgsn_Capability.bit_mask & IMAP3_SGSN_Capability_superChargerSupportedInServingNetworkEntity_present)
      {
         DLOG(0,0,"Super charger supported in serving network entity is present");
         l_upgv3.supercharge = true;         
      }
      if(l_temp->sgsn_Capability.bit_mask & IMAP3_SGSN_Capability_supportedLCS_CapabilitySets_present)
      {
         l_upgv3.lcsCS1 = false; l_upgv3.lcsCS2 = false; l_upgv3.lcsCS3 = false; l_upgv3.lcsCS4 = false;
         if(*l_temp->sgsn_Capability.supportedLCS_CapabilitySets.value & IMAP3_lcsCapabilitySet1)
         {
            TLOG(0,0,"LCS CS 1 supported");
            l_upgv3.lcsCS1 = true;
         }
         if(*l_temp->sgsn_Capability.supportedLCS_CapabilitySets.value & IMAP3_lcsCapabilitySet2)
         {
            l_upgv3.lcsCS2 = true;
            TLOG(0,0,"LCS CS 2 supported");
         }
         if(*l_temp->sgsn_Capability.supportedLCS_CapabilitySets.value & IMAP3_lcsCapabilitySet3)
         {
            l_upgv3.lcsCS3 = true;
            TLOG(0,0,"LCS CS 3 supported");
         }
         if(*l_temp->sgsn_Capability.supportedLCS_CapabilitySets.value & IMAP3_lcsCapabilitySet4)
         {
            l_upgv3.lcsCS4 = true;
            TLOG(0,0,"LCS CS 4 supported");
         }
         m_isd.dbisd3.LcsIndicatorPresent = true;
         LLOG(0,0,"LCS support indicator present, phase supported [%d%d%d%d]",l_upgv3.lcsCS1,l_upgv3.lcsCS2,l_upgv3.lcsCS3,l_upgv3.lcsCS4);
         if((l_upgv3.lcsCS1 == false) && (l_upgv3.lcsCS2 == false) && (l_upgv3.lcsCS3 == false) &&(l_upgv3.lcsCS4 == false))
         {
            LLOG(0,0,"LCS Support indicator present but no CapabilitySets present, LCS not supported");
            m_isd.dbisd3.LcsIndicatorPresent = false;
         }
      }
      if(l_temp->sgsn_Capability.bit_mask & IMAP3_SGSN_Capability_offeredCamel4CSIs_present)
      {
         DLOG(0,0,"CAMEL 4 CSI present");
         l_upgv3.c4_oCSI = false;l_upgv3.c4_dCSI = false;l_upgv3.c4_vtCSI = false;l_upgv3.c4_tCSI = false;
         l_upgv3.c4_mtsmsCSI = false; l_upgv3.c4_mgCSI = false;l_upgv3.c4_psiCSI = false;
         if(*l_temp->sgsn_Capability.offeredCamel4CSIs.value & IMAP3_OfferedCamel4CSIs_o_csi)
         {
            DLOG(0,0,"Offered Camel4 CSIs_o_csi present");
            l_upgv3.c4_oCSI = true;
         }
         if(*l_temp->sgsn_Capability.offeredCamel4CSIs.value & IMAP3_OfferedCamel4CSIs_d_csi)
         {
            DLOG(0,0,"Offered Camel4 CSIs_d_csi present");
            l_upgv3.c4_dCSI = true;
         }
         if(*l_temp->sgsn_Capability.offeredCamel4CSIs.value & IMAP3_OfferedCamel4CSIs_vt_csi)
         {
            DLOG(0,0,"Offered Camel4 CSIs_vt_csi present");
            l_upgv3.c4_vtCSI = true;
         }
         if(*l_temp->sgsn_Capability.offeredCamel4CSIs.value & IMAP3_OfferedCamel4CSIs_t_csi)
         {
            DLOG(0,0,"Offered Camel4 CSIs_t_csi present");
            l_upgv3.c4_tCSI = true;
         }
         if(*l_temp->sgsn_Capability.offeredCamel4CSIs.value & IMAP3_OfferedCamel4CSIs_mt_sms_csi)
         {

            DLOG(0,0,"Offered Camel4 CSIs_mt_sms_csi present");
            l_upgv3.c4_mtsmsCSI = true;
         }
         if(*l_temp->sgsn_Capability.offeredCamel4CSIs.value & IMAP3_OfferedCamel4CSIs_mg_csi)
         {

            DLOG(0,0,"Offered Camel4 CSIs_mg_csi present");
            l_upgv3.c4_mgCSI = true;
         }
         if(*l_temp->sgsn_Capability.offeredCamel4CSIs.value & IMAP3_psi_enhancements)
         {

            DLOG(0,0,"Camel4 CSIs psi_enhancements present");
            l_upgv3.c4_psiCSI = true;
         }
      }
      if(l_temp->sgsn_Capability.bit_mask & IMAP3_smsCallBarringSupportIndicator_present)
      {
         DLOG(0,0,"smsCallBarringSupportIndicator present");
         l_upgv3.smsCBSInd = true;
      }
      if(l_temp->sgsn_Capability.bit_mask & IMAP3_SGSN_Capability_supportedRAT_TypesIndicator_present)
      {
         DLOG(0,0,"RAT type support present");
         if(*l_temp->sgsn_Capability.supportedRAT_TypesIndicator.value & IMAP3_utran_1)
         {
            DLOG(0,0,"UTRAN supported");
            l_upgv3.utran = true;
         }
         if(*l_temp->sgsn_Capability.supportedRAT_TypesIndicator.value & IMAP3_geran_1)
         {
            DLOG(0,0,"GERAN Supported");
            l_upgv3.geran = true;
         }
      }

   }
   /*else
     {
     DLOG(0,0,"SGSN capabilities and CAMEL phase support indicator not present");
     DLOG(0,0,"SGSN capabilities and CAMEL phase support indicator not present in SGSN Capability,assuming default as phase 1");
     l_upgv3.SgsnCap_Camel1 = true;
     l_upgv3.SgsnCap_Camel[0] = '1';
     l_upgv3.SgsnCap_Camel[1] = '0';l_upgv3.SgsnCap_Camel[2] = '0';l_upgv3.SgsnCap_Camel[3] = '0';
     l_upgv3.SgsnCap_Phase = 1;
     }*/
   LLOG(0,0,"Camel Phase supported is %s, MAX SGSN Camel phase supported is %d",l_upgv3.SgsnCap_Camel,l_upgv3.SgsnCap_Phase);

   if(l_temp->bit_mask & IMAP3_UpdateGprsLocationArg_informPreviousNetworkEntity_present)
   {
      DLOG(0,0,"Inform previous network entity present");
      //l_upgv3.informPreviousNetworkEntity = 1;
   }
   if(l_temp->bit_mask & IMAP3_ps_LCS_NotSupportedByUE_present)
   {
      WLOG(0,0,"LCS not supported by UE");
      l_upgv3.ps_LCS_NotSupportedByUE = true;
   }
   if(l_temp->bit_mask & IMAP3_UpdateGprsLocationArg_v_gmlc_Address_present)
   {
      TLOG(0,0,"Gmlc_Address present len [%d] Type [%d]",l_temp->v_gmlc_Address.length,l_temp->v_gmlc_Address.value[0]);
      if(l_temp->v_gmlc_Address.value[0] != 0x04)
      {
         WLOG(0,0,"GMLC_Addr is not of type IPV4");
         return false;
      }
      char l_GmlcAddr[25];
      snprintf(l_GmlcAddr,24,"%d.%d.%d.%d",l_temp->v_gmlc_Address.value[1],l_temp->v_gmlc_Address.value[2],l_temp->v_gmlc_Address.value[3],l_temp->v_gmlc_Address.value[4]);
      strcpy((char *)l_upgv3.gmlc_Address,l_GmlcAddr);
      LLOG(0,0,"gmlc address is %s",(char *)l_upgv3.gmlc_Address);
   }
   if(l_temp->bit_mask & IMAP3_UpdateGprsLocationArg_add_info_present)
   {
      TLOG(0,0,"add_info present");
      BCDToString(l_upgv3.imeisv,l_temp->add_info.imeisv.value,l_temp->add_info.imeisv.length);
      snprintf((char*)m_Orig_Imei,sizeof(m_Orig_Imei),"%s",l_upgv3.imeisv);
      DLOG(0,0,"Orig_Imei is [%s]",m_Orig_Imei);
      // 4.0.2.0
      if(1 == g_IMEI_EncrFlag)
      {
         char l_tempIMEI[200];
         memset(l_tempIMEI,'\0',sizeof(l_tempIMEI));
         bool res = Copy_encryptedIMEI((char*)l_upgv3.imeisv,l_tempIMEI);
         unsigned char l_rawImei[200];
         memset(l_rawImei,'\0',sizeof(l_rawImei));
         hexToStringWithoutSpace(l_rawImei, 200, (unsigned char*)l_tempIMEI, 16);
         m_tdr.setString(TDR_INDEX_IMEI,(char*)l_rawImei);
         if(res == true)
         {
            memset((char*)l_upgv3.imeisv,'\0',strlen((char*)l_upgv3.imeisv));
            strncpy((char*)l_upgv3.imeisv,(char*)l_rawImei,strlen((char*)l_rawImei));
         }
         else
         {
            CLOG(0,0,"Encryption of Imei Failed !!!!");
         }
      }
      else
         m_tdr.setString(TDR_INDEX_IMEI,(char*)l_upgv3.imeisv);
   }
#endif 
   DLOG(0,0,"Check parameters() true for dlgId %d",l_UserDlgId);
   return true;
}

int CtxtUpdateGPRSLocation::UpgLoc(int l_UserDlgId)//,RetrieveSubsData *l_rsd)
{
   DLOG(0,0,"Inside UpdLocV3 for Dialog ID %d",l_UserDlgId);   
   DLOG(0,0,"Subscriber Known Assigning MSISDN is %s",(char *)l_actMsisdn);
   m_isd.dbisd3.imsiReqd = false;
   strcpy((char *)m_isd.dbisd3.imsi,(char *)l_upgv3.imsi);
   memset(m_isd.dbisd3.msisdn,'\0',sizeof(m_isd.dbisd3.msisdn));
   strncpy((char *)m_isd.dbisd3.msisdn,(char *)l_actMsisdn,strlen((char *)l_actMsisdn));
   //strncpy((char *)m_isd.dbisd3.msisdn,(char *)l_priMsisdn,strlen((char *)l_priMsisdn));
   m_isd.dbisd3.msisdnReqd = true;
   if(true == m_fIsd)
   {
      TLOG(0,0,"FullISD set so sending IMSI in ISDdata"); // Added in HLR 2.0.23.0 for IMSI in ISD
      m_isd.dbisd3.imsiReqd = true;
      strncpy((char *)m_isd.dbisd3.imsi,(char *)GprsProfile.l_Actimsi,strlen((char *)GprsProfile.l_Actimsi));
   }
   DLOG(0,0,"GENERAL PROFILE INFO : Network Access Mode:%d Category:%d Subscription Restriction:%d Access Restriction:%d Subscriber Status:%d LMU :%d IST :%d Bearer Service list:%s Tele Service list:%s OCSI Profile ID:%d TCSI Profile Id:%d UGCSI Profile Id:%d SSCSI Profile ID:%d TIFCSI Profile ID:%d  DCSI Profile Id:%d MO SMS CSI profile Id:%d MT SMS CSI Profile Id:%d GPRS CSI profile Id:%d MG CSI Profile Id:%d, PDP Profile ID:%d",
         GenProfile.l_nwAccMode,GenProfile.l_catgory,GenProfile.l_subsRest,GenProfile.l_accRest,GenProfile.l_subsStatus,GenProfile.l_lmu,GenProfile.l_ist,GenProfile.l_bearer,GenProfile.l_tele,GenProfile.l_ocsiPid,GenProfile.l_tcsiPid,GenProfile.l_ugcsiPid,GenProfile.l_sscsiPid,GenProfile.l_tifcsiPid,GenProfile.l_dcsiPid,GenProfile.l_moscsiPid,GenProfile.l_mtscsiPid,GenProfile.l_gcsiPid,GenProfile.l_mgcsiPid,GenProfile.l_pdpPid);

   {
      m_isd.dbisd3.category = 0;//GenProfile.l_catgory;
      m_isd.dbisd3.nwAccMode = GenProfile.l_nwAccMode;
      m_isd.dbisd3.accrest = GenProfile.l_accRest;
      m_isd.dbisd3.subStatus = GenProfile.l_subsStatus;
      m_isd.dbisd3.lmu = 0;
      m_isd.dbisd3.bearer = false;
      strncpy(m_isd.dbisd3.teleData,GenProfile.l_tele,33);
      m_isd.dbisd3.istvalue = 0;
      if(0)//GenProfile.l_ist != 0)
      {
         if(GenProfile.l_ist < 15 || GenProfile.l_ist > 255)
         {
            WLOG(0,0,"IST Alert timer value is not in allowed range of 15 to 255, not sending it in ISD");
            m_isd.dbisd3.istvalue = 0;
         }
         else
         {
            m_isd.dbisd3.istvalue = GenProfile.l_ist;
         }
      }
      if(GenProfile.l_subsStatus == 1)
      {
         m_isd.dbisd3.odb_Genvalue = 0;
         m_isd.dbisd3.odb_HplmnValue = 0;
         m_isd.dbisd3.odb_GenData = false;
         m_isd.dbisd3.odb_HplmnData = false;
         m_isd.dbisd3.odb_Data = false;
         if(l_GenOdb)
         {
            m_isd.dbisd3.odb_Data = true;
            m_isd.dbisd3.odb_GenData = true;
            m_isd.dbisd3.odb_Genvalue = l_GenOdb;
         }
         if(l_PlmnOdb)
         {
            m_isd.dbisd3.odb_Data = true;
            m_isd.dbisd3.odb_HplmnData = true;
            m_isd.dbisd3.odb_HplmnValue = l_PlmnOdb;
         }
         LLOG(0,0,"ODB value to add is %ld, HPLMN ODB value is %ld",m_isd.dbisd3.odb_Genvalue,m_isd.dbisd3.odb_HplmnValue);
      }
      else
      {
         m_isd.dbisd3.odb_Data = false;
         m_isd.dbisd3.odb_GenData = false;
         m_isd.dbisd3.odb_HplmnData = false;
         m_isd.dbisd3.odb_Genvalue = 0;
         m_isd.dbisd3.odb_HplmnValue = 0;
      }
      m_isd.dbisd3.provisionedSS = true;
      m_isd.dbisd3.VLRCsi = false;
      m_isd.dbisd3.sgsncsi = true;
      m_isd.dbisd3.gprsSubsData = GenProfile.l_pdpPid;
      //Setting all other SS data to 0
      m_isd.pss.mcSsCode = 0;  m_isd.pss.MCSsStatus = 0;
      m_isd.pss.ESsCode = 0;   m_isd.pss.EDefaultPriority = 0;
      m_isd.pss.SsCount = 0;
      //End setting SS data

//5054
      if(l_pnwId == 0)
      {
         TLOG(0,0,"Partner NetworkId is 0, not checking for a mapped Pdp Profile");
      }
      else
      {
         TLOG(0,0,"Partner Network Id is not 0, checking for mapped partnerPDPProfId");
         int l_PartnerPdpProfId = getPartnerPdpProfId(GenProfile.l_pdpPid,l_nwId,l_pnwId);
         if(0 != l_PartnerPdpProfId)
         {
            LLOG(0,0,"Partner PDP Profile found[%d]", l_PartnerPdpProfId);
            GenProfile.l_pdpPid = l_PartnerPdpProfId;
         }
         else
         {
            WLOG(0,0,"Partner PDP not found, using [%d]",GenProfile.l_pdpPid);
         }
      }
      m_isd.gprssi.PdpId = GenProfile.l_pdpPid;
      m_isd.gprssi.m_NwId = l_nwId;
      m_isd.gprssi.m_PNwId = l_pnwId;
      m_isd.Sgsncsi.scsi.gcsi = 0;
      m_isd.Sgsncsi.scsi.mosmscsi = 0;
      m_isd.Sgsncsi.scsi.mtsmscsi = 0;
      m_isd.Sgsncsi.scsi.mgcsi = 0;
      m_isd.dbisd3.CamelPhase = 0;
      m_isd.gprssi.m_ApnOiOverrideIndicator = m_ApnOiOverrideIndVal;
      if(l_upgv3.SgsnCap_Camel4)
      {
         m_isd.Sgsncsi.scsi.gcsi = GenProfile.l_gcsiPid;
         m_isd.Sgsncsi.scsi.mosmscsi = GenProfile.l_moscsiPid;
         if((l_upgv3.c4_mtsmsCSI == false) && (GenProfile.l_mtscsiPid != 0))
         {
            WLOG(0,0,"MT_SMS_CSI [%d] configured, but received Offered Camel4CSI -> support indication not set ",GenProfile.l_mtscsiPid,GenProfile.l_mgcsiPid);
            return CAP_VALIDATION_FAILED;
         }
         else
         {
            m_isd.Sgsncsi.scsi.mtsmscsi = GenProfile.l_mtscsiPid;
         }
         m_isd.Sgsncsi.scsi.mgcsi = GenProfile.l_mgcsiPid;
         m_isd.dbisd3.CamelPhase = 4;
      }
      else if((l_upgv3.SgsnCap_Camel3)&&(~l_upgv3.SgsnCap_Camel4))
      {
         m_isd.dbisd3.CamelPhase = 3;
         m_isd.Sgsncsi.scsi.gcsi = GenProfile.l_gcsiPid;
         m_isd.Sgsncsi.scsi.mosmscsi = GenProfile.l_moscsiPid;
         if((GenProfile.l_mtscsiPid > 0) || (GenProfile.l_mgcsiPid > 0))
         {
            WLOG(0,0,"MT_SMS_CSI [%d] MG_CSI [%d] configured, but received is CAP 3 only",GenProfile.l_mtscsiPid,GenProfile.l_mgcsiPid);
            return CAP_VALIDATION_FAILED;
         }
         m_isd.Sgsncsi.scsi.mtsmscsi = 0;
         m_isd.Sgsncsi.scsi.mgcsi = 0;
      }
      else
      {
         if( (0 != GenProfile.l_gcsiPid) || ( 0 != GenProfile.l_moscsiPid) || ( 0 != GenProfile.l_mtscsiPid) || ( 0 != GenProfile.l_mgcsiPid))
         {
            WLOG(0,0,"GPRS_CSI [%d] MO_SMS_CSI [%d] MT_SMS_CSI [%d] MG_CSI [%d] configured, but received no CAP 3 or CAP 4",GenProfile.l_gcsiPid,GenProfile.l_moscsiPid,GenProfile.l_mtscsiPid,GenProfile.l_mgcsiPid);
            return CAP_VALIDATION_FAILED;
         }
         m_isd.Sgsncsi.scsi.gcsi = 0;
         m_isd.Sgsncsi.scsi.mosmscsi = 0;
         m_isd.Sgsncsi.scsi.mtsmscsi = 0;
         m_isd.Sgsncsi.scsi.mgcsi = 0;
      }
      m_isd.Sgsncsi.scsi.nwId = l_nwId;
      m_isd.Sgsncsi.scsi.PnwId = l_pnwId;
      m_isd.Sgsncsi.scsi.RcvdCamelPhase = m_isd.dbisd3.CamelPhase;

   }
   LLOG(0,0,"EXISTING GPRS PROFILE INFO: ActiveMsisdn[%s] ActiveIMSI[%s] SGSNNumber[%s] SGSNAreaRestricted[%d] MSPurgeGPRS[%d] MNRG[%d] RoamRestrDueToUnsuppFeature[%d] PDP ActiveHLRAddress[%s] ActivePartnerNkId[%d] TraceReqd[%d] TraceReference[%s] TraceType[%s] OMC_ID[%s] TraceStatus[%d]",
         GprsProfile.l_ActMsisdn,GprsProfile.l_Actimsi,GprsProfile.l_sgsnno,GprsProfile.l_sgsnRest,GprsProfile.l_msPur_gprs,GprsProfile.l_mnrg,GprsProfile.l_roamrestduf,GprsProfile.l_ActHLRAddr,GprsProfile.l_ActPnwId,GprsProfile.l_TraceFlag,GprsProfile.l_TraceRef,GprsProfile.l_TraceType,GprsProfile.l_OmcId,GprsProfile.l_TraceStatus);
   //m_isd.gprssi.CtxtId = GprsProfile.l_pdpId;

   //if((GprsProfile.l_TraceFlag == 1) && ((GprsProfile.l_TraceStatus != 0)|| (m_SendCl))) commented in 2.0.0.0 Rev1
   if(GprsProfile.l_TraceFlag == 1)
   {
      return SEND_ATM;
   }
   else
   {
      UpgLocCont(l_UserDlgId);
      return UPGV3_SUCCESS;
   }
}


void CtxtUpdateGPRSLocation::UpgLocCont(int l_UserDlgId)//,u8 *l_basicMsisdn,RetrieveSubsGprsProfile *l_rgprs)
{
   DLOG(0,0,"Inside UpgLocCont....");
   l_state = m_fid;
   startISDV3(l_UserDlgId);
}

void CtxtUpdateGPRSLocation::startISDV3(int l_UserDlgId)
{
   l_state = m_fid;
   index = OMAP3_InsertSubscriberDataArg_imsi_present;//0x80000000 initialized to first param
   VcsiIndex = 0;
   ScsiIndex = OMAP3_SGSN_CAMEL_SubscriptionInfo_gprs_CSI_present;//0x80 init to first param
   flag = false;
   m_isd.dbisd3.sgsncsi = true;
   m_isd.dbisd3.VLRCsi = false;
   m_isd.dbisd3.gprsSubsData = true;
   SsIndex = OMAP3_Ext_SS_Info_callBarringInfo_chosen;
   m_isd.pss.val = 0;
   m_isd.pss.m_GenSsCount = 0;
   m_isd.pss.CB_STATE = (provisionedSS::CB)0;
   m_isd.pss.CFWD_STATE = (provisionedSS::CFWD)0;
   m_isd.gprssi.m_FormedTill =0;
   DLOG(0,0,"Starting ISD V3 with index %x SsIndex %x and CSI Index %x",index,SsIndex,VcsiIndex);
   DLOG(0,0,"Calling FormISDReqV3 from OpCode %d for Dialog Id %d call state is %d",l_OpCode,l_UserDlgId,(m_callState)l_state);

   MapSpecificRequest l_request(l_UserDlgId, MAP_OP_CODE_insertSubscriberData, MAP_V3);
   DECLARE(OMAP3_InsertSubscriberDataArg,l_isd,3,"OMAP3_InsertSubscriberDataArg",DeclareFunc);

   m_isd.FormISDReqV3(l_UserDlgId,index,VcsiIndex,ScsiIndex,SsIndex,flag,m_isd.dbisd3,l_OpCode,l_isd);
   if(20 > g_AsnCodecO3.getEncodingLength(OMAP3_InsertSubscriberDataArg_PDU,l_isd))
   {
      ELOG(0,0,"Unable to form ISD, returning System Failure");
      if(false == m_fIsd)
      {
         RetError(l_UserDlgId,SystemFailure);       
      }
   }
   else
   {
      SendMsgV3(l_UserDlgId,&l_request,l_isd,index,VcsiIndex,ScsiIndex,SsIndex);
   }
}

void CtxtUpdateGPRSLocation::SendMsgV3(int DlgId,MapSpecificRequest *l_request,OMAP3_InsertSubscriberDataArg *l_isd,unsigned int &numOfParam,unsigned int &VcsiParam,unsigned int &ScsiParam,unsigned int &SsParam)
{
   LLOG(0,0,"%d-TS:Sending ISD for Dialog id %d ",DlgId,DlgId);
   index = numOfParam;
   VcsiIndex = VcsiParam;
   ScsiIndex = ScsiParam;
   SsIndex = SsParam;
   DLOG(0,0,"The value returned by ISDData are ISD Index %x, VLR CSI Index is %x SGSN CSI Index is %x and SS INDEX is %x",index,VcsiIndex,ScsiIndex,SsIndex);
   l_request->m_structBuffer = (void*) l_isd;
   g_sc.sendMsg(this, l_request);
   ContinueReq(DlgId);
   m_tdr.setInteger(TDR_INDEX_RESRV2,m_isd.m_MM_TDR_CSI_FLAGS);
   DLOG(0, 0, "Sending Delimiter Req after the ISD,callState here is %d",(m_callState)l_state);   
}

#if 1//For retrieving DB Data
void CtxtUpdateGPRSLocation::RetrieveData(int l_UserDlgId,u8 *l_imsi,u8 *l_sgsn)
{
   LLOG(0,0,"Calling Retrieve data for IMSI[%s] SGSNNumber[%s] Multi_IMSI Reqd[%d] through HLR_PKG_MOB_MANAGEMENT.GET_SGSN_INFO",l_imsi,l_sgsn,g_MmConfigReaderObj->m_Multi_Imsi_Reqd);
   RetrieveSubsSGSNData *l_rsd = new RetrieveSubsSGSNData();
   l_rsd->m_UserDlgId = l_UserDlgId;
   strcpy((char *)l_rsd->m_imsi,(char *)l_imsi);
   strcpy((char *)l_rsd->m_sgsn,(char *)l_sgsn);

   if(strlen((char*)l_upgv3.imeisv) > 2) // Added in hlr 2.0.21.0_r2
   {
      strncpy((char *)l_rsd->m_IMEISV,(char *)l_upgv3.imeisv,strlen((char *)l_upgv3.imeisv));
   }

   //Added in 1.0.8.0
   //
   l_rsd->m_SGSN_Supported_Max_CAP_Phase = l_upgv3.SgsnCap_Phase;
   strncpy((char *)l_rsd->m_sgsnAddr,(char *)l_upgv3.SgsnAddr,strlen((char *)l_upgv3.SgsnAddr));
   if(l_upgv3.SgsnCap_Camel1)
      l_rsd->m_CamPha |= 0x01;
   if(l_upgv3.SgsnCap_Camel2)
      l_rsd->m_CamPha |= 0x02;
   if(l_upgv3.SgsnCap_Camel3)
      l_rsd->m_CamPha |= 0x04;
   if(l_upgv3.SgsnCap_Camel4)
      l_rsd->m_CamPha |= 0x08;


   l_rsd->m_Solsa = 0;
   if(l_upgv3.soLSA)
      l_rsd->m_Solsa = 1;


   l_rsd->m_SupLCS = 0;
   if(l_upgv3.lcsCS1)
      l_rsd->m_SupLCS |= 0x01;
   if(l_upgv3.lcsCS2)
      l_rsd->m_SupLCS |= 0x02;
   if(l_upgv3.lcsCS3)
      l_rsd->m_SupLCS |= 0x04;
   if(l_upgv3.lcsCS4)
      l_rsd->m_SupLCS |= 0x08;

   if(l_rsd->m_SupLCS != 0)
   {
      l_rsd->m_ps_LCS_SupportedByUE = 1;
   }
   if(true == l_upgv3.ps_LCS_NotSupportedByUE)
   {
      l_rsd->m_ps_LCS_SupportedByUE = 0;
   }

   if(strlen((char *)l_upgv3.gmlc_Address) > 1)
   {
      strcpy((char *)l_rsd->m_ps_v_gmlc_Address,(char *)l_upgv3.gmlc_Address);
   }


   l_rsd->m_OffCAM = 0;
   if(l_upgv3.c4_oCSI)
      l_rsd->m_OffCAM |= 0x01;
   if(l_upgv3.c4_dCSI)
      l_rsd->m_OffCAM |= 0x02;
   if(l_upgv3.c4_vtCSI)
      l_rsd->m_OffCAM |= 0x04;
   if(l_upgv3.c4_tCSI)
      l_rsd->m_OffCAM |= 0x08;
   if(l_upgv3.c4_mtsmsCSI)
      l_rsd->m_OffCAM |= 0x16;
   if(l_upgv3.c4_mgCSI)
      l_rsd->m_OffCAM |= 0x32;
   if(l_upgv3.c4_psiCSI)
      l_rsd->m_OffCAM |= 0;


   l_rsd->m_SMSCB = 0;
   if(l_upgv3.smsCBSInd)
      l_rsd->m_SMSCB = 1;
   //End Added in 1.0.8.0
   //
   //
   if(true == m_fIsd)
   {
      DLOG(0,0,"UPG initiated from startprocessing so setting m_full_isd_ind with value 1");
      LLOG(0,0,"Setting Full ISD DB indicator to 1");
      l_rsd->m_full_isd_ind = 1;

      
      /*map<int, HlrNetworks* > :: iterator l_HlrNetworksDetailsIter;
      l_HlrNetworksDetailsIter = g_spdPtr->m_HlrNetworks.find(l_nwId);
      if(l_HlrNetworksDetailsIter == g_spdPtr->m_HlrNetworks.end())
      {
         LLOG(0,0,"Network ID not found in networks map[%d]",l_nwId);
      }
      else
      {
         DLOG(0,0,"Network ID found in networks map[%d]",l_nwId);
         LLOG(0,0,"Change Template Sgsn Action in Networks page is ... [%d]",((l_HlrNetworksDetailsIter->second)->m_ChangeTempSgsnAction));
         m_tdr.setInteger(TDR_INDEX_SSM_USSD_SERV_CODE,((l_HlrNetworksDetailsIter->second)->m_ChangeTempSgsnAction));
      }*/
   }
   //6.1.10.0 --> start
   snprintf((char*)l_rsd->m_Orig_Imei,sizeof(l_rsd->m_Orig_Imei),"%s",m_Orig_Imei);
   DLOG(0,0,"#### l_rsd->m_Orig_Imei [%s] ####",l_rsd->m_Orig_Imei);
   //6.1.10.0 -->end

   l_rsd->m_cb = this;
   g_act.execute(l_rsd);
}

void CtxtUpdateGPRSLocation::UpdateGprsData(int l_UserDlgId)
{
   if(true == m_fIsd)
   {
      LLOG(0,0,"Full ISD indicator set NOT updating subs data for ISD unsupported failures");
      return;
   }
   LLOG(0,0,"Calling the procedure to update GPRS data for Dialog Id %d",l_UserDlgId);
   l_state = m_usd;
   UpdateSGSNData *l_usd = new UpdateSGSNData();
   l_usd->m_UserDlgId = l_UserDlgId;
   memset(l_usd->m_AccId,'\0',sizeof(l_usd->m_AccId));
   strncpy((char *)l_usd->m_AccId,(char *)l_AccId,strlen((char *)l_AccId));
   l_usd->m_nwid = l_nwId;
   memset(l_usd->m_ActMsisdn,'\0',sizeof(l_usd->m_ActMsisdn));
   strncpy((char *)l_usd->m_ActMsisdn,(char *)l_actMsisdn,strlen((char *)l_actMsisdn));
   l_usd->m_pnwid = l_pnwId;
   l_usd->m_MsisdnTyp = l_AlocType;
   memset(l_usd->m_ActImsi,'\0',sizeof(l_usd->m_ActImsi));
   strncpy((char *)l_usd->m_ActImsi,(char *)l_upgv3.imsi,strlen((char *)l_upgv3.imsi));
   l_usd->m_roamInd = l_roamInd;
   memset(l_usd->m_sgsn,'\0',sizeof(l_usd->m_sgsn));
   strncpy((char *)l_usd->m_sgsn,(char *)l_upgv3.SgsnNo+2,strlen((char *)l_upgv3.SgsnNo+2));
   memset(l_usd->m_sgsnAddr,'\0',sizeof(l_usd->m_sgsnAddr));
   strncpy((char *)l_usd->m_sgsnAddr,(char *)l_upgv3.SgsnAddr,strlen((char *)l_upgv3.SgsnAddr));
   memset(l_usd->m_ActHlr,'\0',sizeof(l_usd->m_ActHlr));
   strncpy((char *)l_usd->m_ActHlr,(char *)l_hlrAddr,strlen((char *)l_hlrAddr));
   memset(l_usd->m_IMEISV,'\0',sizeof(l_usd->m_IMEISV));
   strncpy((char *)l_usd->m_IMEISV,(char *)l_upgv3.imeisv,strlen((char *)l_upgv3.imeisv));
   memset(l_usd->m_Unsupp_Tele,'\0',sizeof(l_usd->m_Unsupp_Tele));
   strcpy((char *)l_usd->m_Unsupp_Tele,(char *)m_isd.m_Unsupp_Tele);
   memset(l_usd->m_Unsupp_SuppServ,'\0',sizeof(l_usd->m_Unsupp_SuppServ));
   strcpy((char *)l_usd->m_Unsupp_SuppServ,(char *)m_isd.m_Unsupp_SS);
   l_usd->m_Unsupp_GenOdb = m_isd.m_Unsupp_ODB;
   if(GprsProfile.l_TraceFlag)
   {
      l_usd->m_AtmErrorCode = 0;
   }
   else
   {
      l_usd->m_AtmErrorCode = 999;
   }
   /*
      if(g_MmConfigReaderObj->m_SendAscGprs)
      {
      LLOG(0,0,"Send Asc for Gprs enabled, checking sent Teleservice %s and rcvd Rejected Teleservice %s MWD Flag %d",
      m_isd.dbisd3.teleData,m_isd.m_Unsupp_Tele,m_mwd_flag);
      if((m_isd.m_Unsupp_Tele[6] == '0') && (m_isd.dbisd3.teleData[6] == '1') && (m_mwd_flag == 1))
      {
      LLOG(0,0,"Initiating independent context for Alert_SC for Alert_Msisdn %s",m_AlertMsisdn);
      char l_AscXml[100];
      snprintf(l_AscXml, sizeof(l_AscXml), "<ALERT_SC><MSISDN>%s</MSISDN><GPRS>1</GPRS></ALERT_SC>",(char *)m_AlertMsisdn);
      g_sc.initiateIndependentContext(this,MAP_OP_CODE_alertServiceCentre,(char *)l_AscXml, INITIATION_TYPE_TARDILY);
      }
      }
      */
   l_usd->m_sgsnRest = 0;
   l_usd->m_purge = 0;
   l_usd->m_MNRG = 0;
   l_usd->m_RRDUF = 0;
   l_usd->m_CamPha = 0;
   if(l_upgv3.SgsnCap_Camel1)
      l_usd->m_CamPha |= 0x01;
   if(l_upgv3.SgsnCap_Camel2)
      l_usd->m_CamPha |= 0x02;
   if(l_upgv3.SgsnCap_Camel3)
      l_usd->m_CamPha |= 0x04;
   if(l_upgv3.SgsnCap_Camel4)
      l_usd->m_CamPha |= 0x08;
   l_usd->m_Solsa = 0;
   if(l_upgv3.soLSA)
      l_usd->m_Solsa = 1;
   l_usd->m_SupChrg = 0;
   l_usd->m_GprsEhnc = 0;
   l_usd->m_SupLCS = 0;
   if(l_upgv3.lcsCS1)
      l_usd->m_SupLCS |= 0x01;
   if(l_upgv3.lcsCS2)
      l_usd->m_SupLCS |= 0x02;
   if(l_upgv3.lcsCS3)
      l_usd->m_SupLCS |= 0x04;
   if(l_upgv3.lcsCS4)
      l_usd->m_SupLCS |= 0x08;

   if(l_usd->m_SupLCS != 0)
   {
      l_usd->m_ps_LCS_SupportedByUE = 1;
   }
   if(true == l_upgv3.ps_LCS_NotSupportedByUE)
   {
      l_usd->m_ps_LCS_SupportedByUE = 0;
   }

   if(strlen((char *)l_upgv3.gmlc_Address) > 1)
   {
      strcpy((char *)l_usd->m_ps_v_gmlc_Address,(char *)l_upgv3.gmlc_Address);
   }
   l_usd->m_OffCAM = 0;
   if(l_upgv3.c4_oCSI)
      l_usd->m_OffCAM |= 0x01;
   if(l_upgv3.c4_dCSI)
      l_usd->m_OffCAM |= 0x02;
   if(l_upgv3.c4_vtCSI)
      l_usd->m_OffCAM |= 0x04;
   if(l_upgv3.c4_tCSI)
      l_usd->m_OffCAM |= 0x08;
   if(l_upgv3.c4_mtsmsCSI)
      l_usd->m_OffCAM |= 0x16;
   if(l_upgv3.c4_mgCSI)
      l_usd->m_OffCAM |= 0x32;
   if(l_upgv3.c4_psiCSI)
      l_usd->m_OffCAM |= 0;
   l_usd->m_SMSCB = 0;
   if(l_upgv3.smsCBSInd)
      l_usd->m_SMSCB = 1;
   l_usd->m_RoamRest = 0;
   strcpy((char*)l_usd->m_GPRS_Seq_id,(char*)m_GPRS_Seq_id);
   DLOG(0,0,"Updating Data for Account id %s, Network id %d with Active IMSI %s,Active MSISDN %s,Partner NwId %d,Msisdn Type %d,SGSN Number %s,SGSN Address %s,Active HLR Address %s, SGSN Area Restricted %d,Purge status %d,MNRG %d,Roaming restricted %d,Supported camel phases %d,SOLSA %d,GPRS Enhancement Support indicator %d,Supported LCS Capability Set %d,Offered CAMEL4CSI %d,SMS Call barring support indicator %d,Unsupp_Tele_Code %s,Unsupp_SS_Code %s,Unsupp_ODB %ld, ATM_Err_Code %d, LCS_SupportedBy_UE %d, GMLC_Addr %s SEQ_ID %s",
         l_usd->m_AccId,l_usd->m_nwid,l_usd->m_ActImsi,l_usd->m_ActMsisdn,l_usd->m_pnwid,l_usd->m_MsisdnTyp,l_usd->m_sgsn,l_usd->m_sgsnAddr,l_usd->m_ActHlr,l_usd->m_sgsnRest,l_usd->m_purge,l_usd->m_MNRG,l_usd->m_RRDUF,l_usd->m_CamPha,l_upgv3.soLSA,l_usd->m_GprsEhnc,l_usd->m_SupLCS,l_usd->m_OffCAM,l_usd->m_SMSCB,l_usd->m_Unsupp_Tele,l_usd->m_Unsupp_SuppServ,l_usd->m_Unsupp_GenOdb,l_usd->m_AtmErrorCode,l_usd->m_ps_LCS_SupportedByUE,l_usd->m_ps_v_gmlc_Address,l_usd->m_GPRS_Seq_id);
   l_usd->m_cb = this;
   g_act.execute(l_usd);
}

void CtxtUpdateGPRSLocation::UpdateFailData(int l_UserDlgId)
{
   if(true == m_fIsd)
   {
      LLOG(0,0,"Full ISD indicator set NOT updating failure case subs data .. sending CL");
      sendCLforFupd();
      return;
   }
   LLOG(0,0,"Calling the procedure to update GPRS data for Upg Fail,Dialog Id %d",l_UserDlgId);
   if(m_TrapReqd)
   {
      g_si.sendSnmpTrap(g_UpdateLocationGprsTrap, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL);
   }
   l_state = m_usdf;
   UpdateSGSNData *l_usd = new UpdateSGSNData();
   l_usd->m_UserDlgId = l_UserDlgId;
   memset(l_usd->m_AccId,'\0',sizeof(l_usd->m_AccId));
   strncpy((char *)l_usd->m_AccId,(char *)l_AccId,strlen((char *)l_AccId));
   l_usd->m_nwid = l_nwId;
   memset(l_usd->m_ActImsi,'\0',sizeof(l_usd->m_ActImsi));
   strncpy((char *)l_usd->m_ActImsi,(char *)l_upgv3.imsi,strlen((char *)l_upgv3.imsi));   
   memset(l_usd->m_ActMsisdn,'\0',sizeof(l_usd->m_ActMsisdn));
   strncpy((char *)l_usd->m_ActMsisdn,(char *)l_actMsisdn,strlen((char *)l_actMsisdn));
   l_usd->m_pnwid = 0;
   l_usd->m_MsisdnTyp = 0;
   l_usd->m_roamInd = 0;
   memset(l_usd->m_sgsn,'\0',sizeof(l_usd->m_sgsn));
   //strncpy((char *)l_usd->m_sgsn,"0",1);
   memset(l_usd->m_sgsnAddr,'\0',sizeof(l_usd->m_sgsnAddr));
   //strncpy((char *)l_usd->m_sgsnAddr,"0",1);
   memset(l_usd->m_ActHlr,'\0',sizeof(l_usd->m_ActHlr));
   strncpy((char *)l_usd->m_ActHlr,(char *)l_hlrAddr,strlen((char *)l_hlrAddr));
   memset(l_usd->m_Unsupp_Tele,'\0',sizeof(l_usd->m_Unsupp_Tele));
   memset(l_usd->m_Unsupp_Tele,'0',32);
   memset(l_usd->m_Unsupp_SuppServ,'\0',sizeof(l_usd->m_Unsupp_SuppServ));
   l_usd->m_Unsupp_GenOdb = 0;
   if(GprsProfile.l_TraceFlag)
   {
      l_usd->m_AtmErrorCode = m_TraceErrorCode;
   }
   else
   {
      l_usd->m_AtmErrorCode = 999;
   }
   l_usd->m_sgsnRest = 0; //changed in 1.0.7.0 to set "Not Restricted" always
   l_usd->m_purge = 0;
   l_usd->m_MNRG = 1;
   l_usd->m_RRDUF = 0;
   l_usd->m_CamPha = 0;   
   l_usd->m_Solsa = 0;   
   l_usd->m_SupChrg = 0;  
   l_usd->m_GprsEhnc = 0;
   l_usd->m_SupLCS = 0;   
   l_usd->m_OffCAM = 0;   
   l_usd->m_SMSCB = 0;
   l_usd->m_RoamRest = 1;

   //Modified in HLR 1.0.8.0 , for Deallocation on MSISDN on First UL failure for Dynamic case and Updating only retrieved data
   strncpy((char *)l_usd->m_ActMsisdn,(char *)l_actMsisdn,strlen((char *)l_actMsisdn));
   l_usd->m_FirstUl = m_FirstUlFlag;
   l_usd->m_AllocStatus = m_MsisdnAllocStatus;
   l_usd->m_DeallocMsisdn = g_MmConfigReaderObj->m_Dealloc_Msisdn_On_Fail;
   if((m_FirstUlFlag == 1) && (m_MsisdnAllocStatus == 1) && (g_MmConfigReaderObj->m_Dealloc_Msisdn_On_Fail == 1))
   {
      m_tdr.setString(TDR_INDEX_MM_FIRST_UL," ");
      m_tdr.setString(TDR_INDEX_MM_MSISDN_ALLOC_STATUS,"D");
      m_tdr.setString(TDR_INDEX_REQUEST_MSISDN," ");
      m_tdr.setString(TDR_INDEX_MM_PRIMARY_MSISDN," ");
      char tmp[200];
      snprintf(tmp,sizeof(tmp),"First UL Failed Deallocating MSISDN %s",l_actMsisdn);
      m_tdr.setString(TDR_INDEX_OAM_FREE_FORMAT_DATA,tmp);
      WLOG(0,0,"First UL Failed,Deallocating MSISDN [%s] and Restoring with Uploaded MSISDN [%s]",l_actMsisdn,m_UploadedMsisdn);
   }
   strcpy((char*)l_usd->m_GPRS_Seq_id,(char*)m_GPRS_Seq_id);
   //End Modified in HLR 1.0.8.0


   LLOG(0,0,"Updating Data for Account id %s, Network id %d with Active IMSI %s,Active MSISDN %s,Partner NwId %d,Msisdn Type %d,SGSN Number %s,SGSN Address %s,Active HLR Address %s, SGSN Area Restricted %d,Purge status %d,MNRG %d,Roaming restricted %d,Supported camel phases %d,SOLSA %d,GPRS Enhancement Support indicator %d,Supported LCS %d,Offered CAMEL4CSI %d,SMS Call barring support indicator %d,Unsupp_Tele_Code %s,Unsupp_SS_Code %s,Unsupp_ODB %ld, ATM_Err_Code %d SEQ_ID %s",
         l_usd->m_AccId,l_usd->m_nwid,l_usd->m_ActImsi,l_usd->m_ActMsisdn,l_usd->m_pnwid,l_usd->m_MsisdnTyp,l_usd->m_sgsn,l_usd->m_sgsnAddr,l_usd->m_ActHlr,l_usd->m_sgsnRest,l_usd->m_purge,l_usd->m_MNRG,l_usd->m_RRDUF,l_usd->m_CamPha,l_upgv3.soLSA,l_usd->m_GprsEhnc,l_usd->m_SupLCS,l_usd->m_OffCAM,l_usd->m_SMSCB,l_usd->m_Unsupp_Tele,l_usd->m_Unsupp_SuppServ,l_usd->m_Unsupp_GenOdb,l_usd->m_AtmErrorCode,l_usd->m_GPRS_Seq_id);
   l_usd->m_cb = this;
   g_act.execute(l_usd);
   /*
   if(true == m_fIsd)
   {
      LLOG(0,0,"for FullISD Update default subs data called");
      sendCLforFupd();
   }*/
}
#endif


void CtxtUpdateGPRSLocation::upgLocRes(int l_UserDlgId)
{
   if(false == m_fIsd)
   {
   MapSpecificResult l_result(l_UserDlgId, MAP_OP_CODE_updateGprsLocation, MAP_V3);
   DECLARE(OMAP3_UpdateGprsLocationRes,l_res,3,"OMAP3_UpdateGprsLocationRes",DeclareFunc);
   u8 l_NwHlrAddr[21];
   memset(l_NwHlrAddr,'\0',sizeof(l_NwHlrAddr));
   if(g_MmConfigReaderObj->m_GT_Transtlation_Reqd==1)
   {
      DLOG(0,0,"GT_Transtlation_Reqd Enabled");
      GetNetworkHlrAddr(l_NwHlrAddr,l_hlrAddr);
   }
   else
   {
      DLOG(0,0,"GT_Transtlation_Reqd not Enabled");
      strcpy((char *)l_NwHlrAddr,(char *)l_hlrAddr);
   }
   u8 hlrnum[21];
   memset(hlrnum,'\0',sizeof(hlrnum));
   strncpy((char *)hlrnum,"19",2);
   strncat((char *)hlrnum,(char *)l_NwHlrAddr,strlen((char *)l_NwHlrAddr));
   int len = strlen((char *)hlrnum);
   l_res->hlr_Number.length = (len+1)/2;
   StringToBCD(l_res->hlr_Number.value,hlrnum,len);
   l_result.m_structBuffer = l_res;
   g_sc.sendMsg(this, &l_result);

   LLOG(0, 0, "Sending Update GPRS Location Response, HLR Number %s",l_NwHlrAddr);
   CloseReq(l_UserDlgId);
   }
   else
   {
      LLOG(0,0,"Closing full ISD");
      m_tdr.setString(TDR_INDEX_ERR_CODE,"");
      MapCloseReq l_closeReq(l_UserDlgId);
      g_sc.sendMsg(this, &l_closeReq);
      return;
   }
   m_tdr.setString(TDR_INDEX_ERR_CODE,"");
   if(m_isd.m_IsdResp_With_Unsupp_Service_Rcvd)
   {
      UpdateGprsData(l_UserDlgId);   
   }

   if(m_InitiateNoteMsPresent)
   {
      LLOG(0,0,"Initiating Note MS present for GPRS for IMSI %s",l_upgv3.imsi);
      g_sc.initiateIndependentContext(this, MAP_OP_CODE_noteMsPresentForGprs,(char *)l_upgv3.imsi, INITIATION_TYPE_TARDILY);
   }
   if(g_MmConfigReaderObj->m_SendAscGprs)
   {
      LLOG(0,0,"Send Asc for Gprs enabled, checking sent Teleservice %s and rcvd Rejected Teleservice %s MWD Flag %d",
            m_isd.dbisd3.teleData,m_isd.m_Unsupp_Tele,m_mwd_flag);
      if((m_isd.m_Unsupp_Tele[6] == '0') && (m_isd.dbisd3.teleData[6] == '1') && (m_mwd_flag == 1))
      {
         LLOG(0,0,"Initiating independent context for Alert_SC for Alert_Msisdn %s",m_AlertMsisdn);
         char l_AscXml[100];
         snprintf(l_AscXml, sizeof(l_AscXml), "<ALERT_SC><MSISDN>%s</MSISDN><GPRS>1</GPRS><NETWORK_ID>%d</NETWORK_ID></ALERT_SC>",(char *)m_AlertMsisdn,l_nwId);
         g_sc.initiateIndependentContext(this,MAP_OP_CODE_alertServiceCentre,(char *)l_AscXml, INITIATION_TYPE_TARDILY);
      }
   }
}

void CtxtUpdateGPRSLocation::RetError(int l_UserDlgId,int ErrorCode)
{
   DLOG(0,0,"Returning Error for Error code %d",ErrorCode);
   //m_tdr.setBool(TDR_MSGSTATUS_INDEX,false);
   switch(ErrorCode)
   {
      case 1://SystemFailure
         {
            WLOG(0,0,"Sending System Failure");
            OMAP3_SystemFailureParam l_sfp;
            memset(&l_sfp,'\0',sizeof(l_sfp));
            l_sfp.choice = OMAP3_extensibleSystemFailureParam_chosen;
            l_sfp.u.extensibleSystemFailureParam.bit_mask = OMAP3_networkResource_present;
            l_sfp.u.extensibleSystemFailureParam.networkResource = OMAP3_hlr;
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_systemFailure, MAP_V3, &l_sfp);
            g_sc.sendMsg(this, &l_userError);
            CloseReq(l_UserDlgId);
            m_tdr.setInteger(TDR_INDEX_ERR_CODE,34);
            //ContinueReq(l_UserDlgId);
         }
         break;
      case 2://UnknownSubscriber
         {
            WLOG(0,0,"Unknown subscriber Sending error Unknown Subscriber - IMSI unknown");
            OMAP3_UnknownSubscriberParam l_usp;
            memset(&l_usp,'\0',sizeof(l_usp));
            l_usp.bit_mask = OMAP3_unknownSubscriberDiagnostic_present;
            l_usp.unknownSubscriberDiagnostic = OMAP3_imsiUnknown;
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_unknownSubscriber, MAP_V3, &l_usp);
            g_sc.sendMsg(this, &l_userError);
            CloseReq(l_UserDlgId);
            m_tdr.setInteger(TDR_INDEX_ERR_CODE,1);
         }
         break;
      case 3://DataMissing
         {
            WLOG(0,0,"Sending Data missing");
            OMAP3_DataMissingParam l_dmp;
            memset(&l_dmp,'\0', sizeof(l_dmp));
            //l_dmp.choice
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_dataMissing, MAP_V3, NULL);
            g_sc.sendMsg(this, &l_userError);
            CloseReq(l_UserDlgId);
            m_tdr.setInteger(TDR_INDEX_ERR_CODE,35);
            //ContinueReq(l_UserDlgId);
         }
         break;
      case 4://UnexpectedData
         {
            WLOG(0,0,"Sending Unexpected data error");
            OMAP3_UnexpectedDataParam l_udp;
            memset(&l_udp,'\0',sizeof(l_udp));
            //l_udp.choice
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_unexpectedData, MAP_V3, NULL);
            g_sc.sendMsg(this, &l_userError);
            CloseReq(l_UserDlgId);
            m_tdr.setInteger(TDR_INDEX_ERR_CODE,36);
            //ContinueReq(l_UserDlgId);
         }
         break;
      case 5://RoamingNotAllowed_plmn
         {
            WLOG(0,0,"Sending Roaming not allowed - Reason plmnroaming not allowed");
            OMAP3_RoamingNotAllowedParam l_rna;
            memset(&l_rna,'\0',sizeof(l_rna));
            l_rna.roamingNotAllowedCause = OMAP3_plmnRoamingNotAllowed;
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_roamingNotAllowed, MAP_V3, &l_rna);
            g_sc.sendMsg(this, &l_userError);
            CloseReq(l_UserDlgId);
            m_tdr.setInteger(TDR_INDEX_ERR_CODE,8);

         }
         break;
      case 6://RoamingNotAllowed_odb
         {
            WLOG(0,0,"Sending Roaming not allowed - reason ODB");
            OMAP3_RoamingNotAllowedParam l_rna;
            memset(&l_rna,'\0',sizeof(l_rna));
            l_rna.roamingNotAllowedCause = OMAP3_RoamingNotAllowedCause_operatorDeterminedBarring;
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_roamingNotAllowed, MAP_V3, &l_rna);
            g_sc.sendMsg(this, &l_userError);
            CloseReq(l_UserDlgId);
            m_tdr.setInteger(TDR_INDEX_ERR_CODE,8);
         }
         break;
      case 7://UnknownSubscriber - GPRS Subscription unknowd
         {
            WLOG(0,0,"Unknown subscriber for GPRS, Sending error Unknown Subscriber - GPRS Subscription unknown");
            OMAP3_UnknownSubscriberParam l_usp;
            memset(&l_usp,'\0',sizeof(l_usp));
            l_usp.bit_mask = OMAP3_unknownSubscriberDiagnostic_present;
            l_usp.unknownSubscriberDiagnostic = OMAP3_gprsSubscriptionUnknown;
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_unknownSubscriber, MAP_V3, &l_usp);
            g_sc.sendMsg(this, &l_userError);
            CloseReq(l_UserDlgId);
            m_tdr.setInteger(TDR_INDEX_ERR_CODE,1);
         }
         break;
      default:
         WLOG(0,0,"Error found while processing Return code");
         break;
   }
}

void CtxtUpdateGPRSLocation::CloseReq(int l_UserDlgId)
{
   DLOG(0, 0, "Closing the Dialogue");
   MapCloseReq l_closeReq(l_UserDlgId);
   g_sc.sendMsg(this, &l_closeReq);
}

void CtxtUpdateGPRSLocation::ContinueReq(int l_UserDlgId)
{
   DLOG(0, 0, "Sending Delimiter Req ...");
   MapDelimiterReq l_del(l_UserDlgId);
   g_sc.sendMsg(this, &l_del);
}

bool CtxtUpdateGPRSLocation::startProcessing(InterModuleData *p_imd,bool &p_DeleteFlag)
{
   DLOG(0, 0, "Start of CtxtUpdateGPRSLocation::startProcessing function, Delete flag %d",p_DeleteFlag);
   LLOG(0,0,"InterModule data for Update GPRS Location Received from [%s] Xml Request [%s]", p_imd->m_OriginatorModule,(NULL == p_imd->m_Parameters)?"":p_imd->m_Parameters);

   if(NULL == p_imd->m_Parameters)
   {
      CLOG(0,0,"p_imd->m_Parameters NULL returning");
      return false;
   }

   m_fIsd = true;
   memset(&l_upgv3,'\0',sizeof(l_upgv3));

   char *l_check = NULL;
   l_check = strchr(p_imd->m_Parameters, ':');
   if(l_check == NULL)
   {
      TLOG(0,0,"Transaction ID not present");
      //return false;
      //m_DataString.assign(&p_imd->m_Parameters[0]);
      m_DataString.assign(p_imd->m_Parameters);
   }
   else
   {
      strncpy(m_TransId,p_imd->m_Parameters, strlen(p_imd->m_Parameters)-strlen(l_check));
      LLOG(0,0,"Transaction ID :%s received from OAM", m_TransId);

      //m_DataString.assign(&p_imd->m_Parameters[strlen(p_imd->m_Parameters)-strlen(l_check)]);
      m_DataString.assign(&p_imd->m_Parameters[strlen(p_imd->m_Parameters)-strlen(l_check)]);
      m_tdr.setString(TDR_INDEX_OAM_TRANSACTION_ID, m_TransId);
   }

   //m_tdr.setOpCode(111);
   //m_tdr.setContextId("MMMISD");
   m_tdr.setOriginatingModule("GPRSISD");
   string l_imsi = ConfigReader::readValue(m_DataString, "IMSI");
   if(1 > l_imsi.length())
   {
      CLOG(0,0,"Unknown IMSI");
      return false;
   }
   m_tdr.setChar(TDR_INDEX_REQUEST_TYPE,'I'); 
   m_tdr.setString(TDR_INDEX_REQUEST_IMSI,(char*)l_imsi.c_str());

   string l_sgsnno = ConfigReader::readValue(m_DataString, "SGSN_NUM");
   if(1 > l_sgsnno.length())
   {
      CLOG(0,0,"Unknown SGSN");
      return false;
   }
   m_tdr.setString(TDR_INDEX_SGSN_ADDRESS,(char*)l_sgsnno.c_str());

   string l_sgsnadd = ConfigReader::readValue(m_DataString, "SGSN_ADDRESS");
   if(1 > l_sgsnadd.length())
   {
      CLOG(0,0,"Unknown SGSN ADDRESS");
      return false;
   }
   m_tdr.setString(TDR_INDEX_SGSN_IP_ADDRESS,(char*)l_sgsnadd.c_str());

   string l_hlrno = ConfigReader::readValue(m_DataString, "ORIG_ADDRESS");
   if(1 > l_hlrno.length())
   {
      CLOG(0,0,"Unknown HLR address");
      return false;
   }

   /*string l_lmsi = ConfigReader::readValue(m_DataString, "LMSI");
   DLOG(0,0,"LMSI %s, len %d",l_lmsi.c_str(),l_lmsi.length());
   if(1 > l_lmsi.length())
   {
      TLOG(0,0,"LMSI not present");
   }
   else
   {
      memcpy(l_upgv3.lmsi,l_lmsi.c_str(),l_lmsi.length());
      m_tdr.setHex(TDR_INDEX_LMSI,(char *)l_upgv3.lmsi,l_lmsi.length());
   }*/

   snprintf((char*)l_upgv3.imsi,sizeof(l_upgv3.imsi),"%s",(char*)l_imsi.c_str());
   snprintf((char*)l_upgv3.SgsnNo,sizeof(l_upgv3.SgsnNo),"%s",(char*)l_sgsnno.c_str());
   snprintf((char*)l_upgv3.SgsnAddr,sizeof(l_upgv3.SgsnAddr),"%s",(char*)l_sgsnadd.c_str());
   //snprintf((char*)l_upgv3.l_hlrno,sizeof(l_upgv3.l_hlrno),"%s",(char*)l_hlrno.c_str());

   //assuming vlr supports camel phase 1,2 and 3
   memset(l_upgv3.SgsnCap_Camel,'\0',5);
   l_upgv3.SgsnCap_Camel1 = false;
   l_upgv3.SgsnCap_Camel2 = false;
   l_upgv3.SgsnCap_Camel3 = false;
   l_upgv3.SgsnCap_Camel4 = false;
   l_upgv3.SgsnCap_Phase = 0;

   l_upgv3.SgsnCap_Camel1 = true;
   l_upgv3.SgsnCap_Camel[0] = '1';

   l_upgv3.SgsnCap_Camel2 = true;
   l_upgv3.SgsnCap_Camel[1] = '1';

   l_upgv3.SgsnCap_Camel3 = true;
   l_upgv3.SgsnCap_Camel[2] = '1';

   l_upgv3.SgsnCap_Phase = 3;

   l_state= m_rsd;
   int l_isdDlgId = g_sc.getNewDialogue();
   if(l_isdDlgId < 1)
   {
      CLOG(0,0,"ISD location dialog id %d is less then 0",l_isdDlgId);
      return false;
   }
   DLOG(0,0,"ISD on dialog ID %d",l_isdDlgId);

   DLOG(0, 0, "Sending MapOpenReq for ISD");
   MapOpenReq l_mapOpenReq(l_isdDlgId, MAP_V3);
   l_mapOpenReq.m_ApplCntxt = MAP_AC_CODE_subscriberDataMngt;
   DLOG(0,0,"Configuring SCCP address in ISD for Destination number %s and HLR Number %s",(char *)l_sgsnno.c_str(),(char *)l_hlrno.c_str());
   configureSccpAddress(&l_mapOpenReq.m_OrigAddr,L_ROUTE_ON_GT,1002,6,(char *)l_hlrno.c_str());
   if(true == configureSccpAddress(&l_mapOpenReq.m_DestAddr,L_ROUTE_ON_GT,1002,149,(char *)l_sgsnno.c_str()))
      g_sc.sendMsg(this, &l_mapOpenReq);

   l_Version = 3;
   l_OpCode = 23;

   m_tdr.setMapVersion(3);
   m_tdr.setRemoteAddr((s8 *)l_sgsnno.c_str());
   m_tdr.setRemoteAddrSsn(149);
   RetrieveData(l_isdDlgId,(u8*)(char*)l_imsi.c_str(),(u8*)(char*)l_sgsnno.c_str());
   m_tdr.setString(TDR_INDEX_AUC_NUM_VECTORS_REQUESTED,"FULL_ISD_GPRS");
   
   return true;
}


void CtxtUpdateGPRSLocation ::sendCLforFupd()
{
   char XmlReq[501];
   memset(XmlReq,'\0',sizeof(XmlReq));
   FormXMLRequest(XmlReq,2, (u8 *)l_upgv3.imsi, (u8*)"",(u8 *) l_hlrAddr,(u8 *) l_upgv3.SgsnNo,1,0,"FISD_GPRS", (s8*)l_upgv3.SgsnNo);
   g_sc.initiateIndependentContext(this, MAP_OP_CODE_cancelLocation, (char *) XmlReq, INITIATION_TYPE_IMMEDIATE);
}

