#include <CtxtSimUpdateGprsLocation.h>
#include <stdio.h>
#include <MapMessages.h>
#include <ServiceCoordinator.h>
#include <Logger.h>
#include <IMAP3.h>
#include <OMAP3.h>
#include <DbActiveObject.h>
#include <Utilities.h>
#include <DataUnion.h>
#include <MmSimConfigReader.h>

CtxtSimUpdateGprsLocation::CtxtSimUpdateGprsLocation() {

}

CtxtSimUpdateGprsLocation::~CtxtSimUpdateGprsLocation() {

}

bool CtxtSimUpdateGprsLocation::sendV3UpdateLocation() 
{
   OMAP3_UpdateGprsLocationArg *l_temp = (OMAP3_UpdateGprsLocationArg*) malloc(sizeof (OMAP3_UpdateGprsLocationArg));
   memset(l_temp, '\0', sizeof (OMAP3_UpdateGprsLocationArg));
   l_temp->bit_mask = 0;
   l_temp->imsi.length = 8;

   //100007525310000 to 100007525319999

   unsigned long int l_imsi = 0;
   if(g_MmSimConfigReaderObj->l_Home_FLAG == 0)
      l_imsi = g_MmSimConfigReaderObj->l_pri_imsi_with_CSI;
   else if(g_MmSimConfigReaderObj->l_Home_FLAG == 1)
      l_imsi = g_MmSimConfigReaderObj->l_sec_imsi_with_CSI;
   else if(g_MmSimConfigReaderObj->l_Home_FLAG == 2)
      l_imsi = g_MmSimConfigReaderObj->l_loc_imsi_with_CSI;
   else
      return false;     
   for(int a = 1; a <= g_MmSimConfigReaderObj->l_Count; a++)
   {    

      //l_imsi;
      //l_imsi = 110000000000000;
      unsigned char imsi[16];
      memset(imsi,'\0',sizeof(imsi));
      sprintf((char *)imsi,"%ld",l_imsi);      
      TLOG(0,0,"Filling IMSI %ld in string %s",l_imsi,imsi);
      StringToBCD(l_temp->imsi.value,imsi,15);
      l_temp->imsi.value[7] |= 0xf0;
      l_imsi++;


      int l_UserDlgId = g_sc.getNewDialogue();

      DLOG(0, 0, "Sending MapOpenReq for Dialog id %d",l_UserDlgId);
      MapOpenReq l_mapOpenReq(l_UserDlgId, MAP_V3);
      l_mapOpenReq.m_OpenInfo.bit_mask = MAP_DP_OpenInfo_destinationReference_present |
         MAP_DP_OpenInfo_originationReference_present;
      l_mapOpenReq.m_OpenInfo.destinationReference.length = 2;
      l_mapOpenReq.m_OpenInfo.destinationReference.value[0] = 0x11;
      l_mapOpenReq.m_OpenInfo.destinationReference.value[1] = 0x22;

      l_mapOpenReq.m_OpenInfo.originationReference.length = 3;
      l_mapOpenReq.m_OpenInfo.originationReference.value[0] = 0x33;
      l_mapOpenReq.m_OpenInfo.originationReference.value[1] = 0x22;
      l_mapOpenReq.m_OpenInfo.originationReference.value[2] = 0x11;

      l_mapOpenReq.m_ApplCntxt = MAP_AC_CODE_gprsLocationUpdate;
      l_mapOpenReq.m_DestAddr = g_ConfigData->i_NgConfigData.m_remoteAddress1;

      g_sc.sendMsg(this, &l_mapOpenReq);

      DLOG(0, 0, "Sending MapSpecificRequest ...");
      MapSpecificRequest l_request(l_UserDlgId,MAP_OP_CODE_updateGprsLocation, MAP_V3);

      unsigned long int l_isgsnNum = 0;
      if(g_MmSimConfigReaderObj->l_Home_FLAG == 0)
         l_isgsnNum =  g_MmSimConfigReaderObj->l_Home_VLR;
      else if(g_MmSimConfigReaderObj->l_Home_FLAG == 1)
         l_isgsnNum = g_MmSimConfigReaderObj->l_Roam_VLR;
      else if(g_MmSimConfigReaderObj->l_Home_FLAG == 2)
         l_isgsnNum = g_MmSimConfigReaderObj->l_Local_VLR;
      else
         return false;
      unsigned char l_csgsnNum[20];
      memset(l_csgsnNum,'\0',sizeof(l_csgsnNum));  
      sprintf((char *)l_csgsnNum,"%ld",l_isgsnNum);   
      l_temp->sgsn_Number.length = (strlen((char *)l_csgsnNum) + 1)/2;
      StringToBCD(l_temp->sgsn_Number.value,l_csgsnNum,strlen((char *)l_csgsnNum)); 
      l_temp->sgsn_Address.length = 5; //192.137.88.255
      l_temp->sgsn_Address.value[0] = 0x04;
      l_temp->sgsn_Address.value[1] = 0xC0;
      l_temp->sgsn_Address.value[2] = 0x89;
      l_temp->sgsn_Address.value[3] = 0x58;
      l_temp->sgsn_Address.value[4] = 0xFF;
      l_temp->bit_mask = OMAP3_sgsn_Capability_present;
      l_temp->sgsn_Capability.bit_mask = 0;
      l_temp->sgsn_Capability.bit_mask |= OMAP3_gprsEnhancementsSupportIndicator_present;

      char* l_tmp = getenv("MAX_CAP_PHASE_SUPPORTED");
      l_temp->sgsn_Capability.supportedCamelPhases.length  = 4;
      if((l_tmp != NULL) and (strcmp(l_tmp,"4") == 0))
      {
         l_temp->sgsn_Capability.bit_mask |= OMAP3_SGSN_Capability_supportedCamelPhases_present;
         l_temp->sgsn_Capability.supportedCamelPhases.value[0]  = OMAP3_phase3|OMAP3_phase4;    
      }
      else if((l_tmp != NULL) and (strcmp(l_tmp,"3") == 0))
      {
         l_temp->sgsn_Capability.bit_mask |= OMAP3_SGSN_Capability_supportedCamelPhases_present;
         l_temp->sgsn_Capability.supportedCamelPhases.value[0]  = OMAP3_phase3;    
      }
      else if((l_tmp != NULL) and (strcmp(l_tmp,"2") == 0))
      {
         l_temp->sgsn_Capability.bit_mask |= OMAP3_SGSN_Capability_supportedCamelPhases_present;
         l_temp->sgsn_Capability.supportedCamelPhases.value[0]  = OMAP3_phase2;    
      }
      else if((l_tmp != NULL) and (strcmp(l_tmp,"1") == 0))
      {
         l_temp->sgsn_Capability.bit_mask |= OMAP3_SGSN_Capability_supportedCamelPhases_present;
         l_temp->sgsn_Capability.supportedCamelPhases.value[0]  = OMAP3_phase1;    
      }
      else //if((l_tmp != NULL) and (strcmp(l_tmp,"3") == 0))
      {
         //l_temp->sgsn_Capability.bit_mask |= OMAP3_SGSN_Capability_supportedCamelPhases_present;
         //l_temp->sgsn_Capability.supportedCamelPhases.value[0]  = OMAP3_phase3;    
      }
      l_tmp = getenv("OFFERED_CAP_CSI");
      if(((l_tmp != NULL)) and (l_temp->sgsn_Capability.supportedCamelPhases.value[0] & OMAP3_phase4))
      {
         l_temp->sgsn_Capability.bit_mask |= OMAP3_SGSN_Capability_offeredCamel4CSIs_present;
         l_temp->sgsn_Capability.offeredCamel4CSIs.length = 6;
         l_temp->sgsn_Capability.offeredCamel4CSIs.value[0] = 0; 

         if(l_tmp[0] == '1')
            l_temp->sgsn_Capability.offeredCamel4CSIs.value[0] |= OMAP3_OfferedCamel4CSIs_o_csi;
         if(l_tmp[1] == '1')
            l_temp->sgsn_Capability.offeredCamel4CSIs.value[0] |= OMAP3_OfferedCamel4CSIs_d_csi;
         if(l_tmp[2] == '1')
            l_temp->sgsn_Capability.offeredCamel4CSIs.value[0] |= OMAP3_OfferedCamel4CSIs_vt_csi;
         if(l_tmp[3] == '1')
            l_temp->sgsn_Capability.offeredCamel4CSIs.value[0] |= OMAP3_OfferedCamel4CSIs_t_csi;
         if(l_tmp[4] == '1')
            l_temp->sgsn_Capability.offeredCamel4CSIs.value[0] |= OMAP3_OfferedCamel4CSIs_mt_sms_csi;
         if(l_tmp[5] == '1')
            l_temp->sgsn_Capability.offeredCamel4CSIs.value[0] |= OMAP3_OfferedCamel4CSIs_mg_csi;
      }

      l_temp->bit_mask |= OMAP3_UpdateGprsLocationArg_add_info_present;
      unsigned char l_imei[21];
      snprintf((char *)l_imei,20,"3213213213213216");
      l_temp->add_info.imeisv.length = (strlen((char *)l_imei)+1)/2;
      StringToBCD(l_temp->add_info.imeisv.value,l_imei,strlen((char *)l_imei));
      l_request.m_structBuffer = (void*) l_temp;


      if(g_MmSimConfigReaderObj->l_SendGmlcAddr)
      {
         l_temp->bit_mask |= OMAP3_UpdateGprsLocationArg_v_gmlc_Address_present;
         l_temp->v_gmlc_Address.length = 5;
         l_temp->v_gmlc_Address.value[0] = 0x04;
         l_temp->v_gmlc_Address.value[1] = 0xA5;
         l_temp->v_gmlc_Address.value[2] = 0x55;
         l_temp->v_gmlc_Address.value[3] = 0x9C;
         l_temp->v_gmlc_Address.value[4] = 0x15;
      }

      if(g_MmSimConfigReaderObj->l_SendLCSCapabilitySet)
      {
         l_temp->sgsn_Capability.bit_mask |= OMAP3_SGSN_Capability_supportedLCS_CapabilitySets_present;
         l_temp->sgsn_Capability.supportedLCS_CapabilitySets.length = 4;
         l_temp->sgsn_Capability.supportedLCS_CapabilitySets.value[0] = OMAP3_lcsCapabilitySet1 | OMAP3_lcsCapabilitySet2;

      }

      /*unsigned char l_imei[20];
      memset(l_imei,'\0',sizeof(l_imei));
      l_tmp = getenv("IMEISV");
      if(l_tmp != NULL)
      {
         // printf("\n\n\n IMEISV Present \n\n\n");
         l_temp->bit_mask |= OMAP3_UpdateGprsLocationArg_add_info_present;
         snprintf((char *)l_imei,sizeof(l_imei),"%s",l_tmp);
         l_temp->add_info.imeisv.length = (strlen((char *)l_imei)+1)/2;
         StringToBCD(l_temp->add_info.imeisv.value,l_imei,strlen((char *)l_imei));
      }*/


      g_sc.sendMsg(this, &l_request);

      DLOG(0, 0, "Sending MapDelimiterReq Req ...");
      MapDelimiterReq l_del(l_UserDlgId);
      g_sc.sendMsg(this, &l_del);
   }
   return true;
}

bool CtxtSimUpdateGprsLocation::startProcessing() {
   TLOG(0, 0, "Start of CtxtSimUpdateGprsLocation::startProcessing function");

   sendV3UpdateLocation();
   return true;
}

bool CtxtSimUpdateGprsLocation::processMessage(Msg *p_MsgPtr, bool &p_DeleteFlag) {
   DLOG(0, 0, "Start of CtxtSimUpdateGprsLocation::processMessage function delete flag %d",p_DeleteFlag);

   int l_UserDlgId = 0;

   switch (p_MsgPtr->m_MsgType) {
      case MSG_TYPE_MAP:
         switch (((MapMsg*) p_MsgPtr)->m_MapMsgType) {
            case MAP_MSG_TYPE_COMMON:
               switch (((MapCommonMsg*) p_MsgPtr)->m_MapCommonMsgType) {
                  case MAP_CMN_OPEN_IND:
                     DLOG(0, 0, "MAP_CMN_OPEN_IND received");
                     break;

                  case MAP_CMN_OPEN_CNF:
                     DLOG(0, 0, "MAP_CMN_OPEN_CNF received");
                     printf("\nThe other entity's version is %d", ((MapOpenCnf*) p_MsgPtr)->m_Version);
                     //sendV2UpdateLocation();
                     break;

                  case MAP_CMN_DELIMITER_IND:
                     {
                        DLOG(0, 0, "MAP_CMN_DELIMITER_IND received");
                        l_UserDlgId = p_MsgPtr->m_UserDlgId;

                        /*DLOG(0,0,"Closing the Dialogue");
                          MapCloseReq l_closeReq(l_UserDlgId);
                          g_sc.sendMsg(this, &l_closeReq);*/
                     }
                     break;

                  case MAP_CMN_CLOSE_IND:
                     DLOG(0, 0, "MAP_CMN_CLOSE_IND received");
                     return true;
                     break;

                  case MAP_CMN_U_ABORT_IND:
                     DLOG(0, 0, "MAP_CMN_U_ABORT_IND received");
                     break;

                  case MAP_CMN_P_ABORT_IND:
                     DLOG(0, 0, "MAP_CMN_P_ABORT_IND received");
                     break;

                  case MAP_CMN_NOTICE_IND:
                     {
                        DLOG(0, 0, "MAP_CMN_NOTICE_IND received");
                        MapCloseReq l_closeReq(((MapMsg*)p_MsgPtr)->m_UserDlgId);
                        l_closeReq.m_CloseType = MAP_CLOSE_TYPE_PRE_ARRANGED_END;
                        g_sc.sendMsg(this, &l_closeReq);
                     }
                     break;

                  default:
                     DLOG(0, 0, "Unknown Msg received");
                     break;
               }
               break;

            case MAP_MSG_TYPE_SPECIFIC:
               DLOG(0, 0, "MAP_MSG_TYPE_SPECIFIC received");
               switch (((MapSpecificMsg*) p_MsgPtr)->m_MapSpecificEventType) {
                  case MAP_SPEC_EVENT_REQUEST:
                     DLOG(0, 0, "MAP_SPEC_EVENT_REQUEST received");
                     break;

                  case MAP_SPEC_EVENT_INDICATION:
                     {
                        DLOG(0, 0, "MAP_SPEC_EVENT_INDICATION received");
                        switch (((MapSpecificMsg*) p_MsgPtr)->m_OpCode) {
                           case MAP_OP_CODE_activateTraceMode:
                              {
#if 1
                                 TLOG(0,0,"Received activate trace mode");
                                 MapSpecificResult l_result(((MapSpecificMsg*) p_MsgPtr)->m_UserDlgId, MAP_OP_CODE_activateTraceMode, MAP_V3);
                                 g_sc.sendMsg(this, &l_result);
#else
                                 OMAP3_FacilityNotSupParam l_fns;
                                 memset(&l_fns,'\0',sizeof(l_fns));
                                 MapUserError l_userError(((MapSpecificMsg*) p_MsgPtr)->m_UserDlgId, MAP_ERROR_facilityNotSup, MAP_V3, NULL);
                                 g_sc.sendMsg(this, &l_userError);
#endif                                     


                                 MapDelimiterReq l_del(((MapSpecificMsg*) p_MsgPtr)->m_UserDlgId);
                                 g_sc.sendMsg(this, &l_del);

                              }
                              break;
                           case MAP_OP_CODE_insertSubscriberData:
                              {
                                 TLOG(0, 0, "MAP_OP_CODE_insertSubscriberData REQ received");

                                 char *l_tmp;
                                 l_tmp = getenv("SEND_ERROR_ON_ISD");
                                 if(strcmp(l_tmp,"YES") == 0)
                                 {

                                    printf("\nSEND_ERROR_ON_ISD is set, sending MAP_ERROR_unexpectedData \n");

                                    OMAP3_UnexpectedDataParam l_udp;
                                    memset(&l_udp,'\0',sizeof(l_udp));
                                    MapUserError l_userError(((MapSpecificMsg*) p_MsgPtr)->m_UserDlgId, MAP_ERROR_unexpectedData, MAP_V3, NULL);
                                    g_sc.sendMsg(this, &l_userError);
                                    MapDelimiterReq l_del(((MapSpecificMsg*) p_MsgPtr)->m_UserDlgId);
                                    g_sc.sendMsg(this, &l_del);
                                    return false;
                                 }


                                 l_tmp = getenv("DONT_SEND_ISD_RESP");
                                 if(strcmp(l_tmp,"YES") == 0)
                                 {
                                    printf("\nDONT_SEND_ISD_RESP is set, Not sending, L_CANCEL will come in 30 seconds\n");
                                    return false;
                                 }

                                 MapSpecificResult l_result(((MapSpecificMsg*) p_MsgPtr)->m_UserDlgId, MAP_OP_CODE_insertSubscriberData, MAP_V3);


                                 //OMAP3_InsertSubscriberDataRes *l_isdRes = (OMAP3_InsertSubscriberDataRes*) malloc(sizeof (OMAP3_InsertSubscriberDataRes));
                                 //memset(l_isdRes, '\0', sizeof (OMAP3_InsertSubscriberDataRes));
                                 DECLARE(OMAP3_InsertSubscriberDataRes,l_isdRes,3,"OMAP3_InsertSubscriberDataRes",DeclareFunc);

                                 l_isdRes->bit_mask = 0;
                                 if( g_MmSimConfigReaderObj->l_SendISDResp)
                                 {
                                    if(strcmp(g_MmSimConfigReaderObj->l_UnsuppTele,"00000000000000000000000000000000"))
                                       l_isdRes->bit_mask |= OMAP3_InsertSubscriberDataRes_teleserviceList_present;
                                    l_isdRes->teleserviceList.count = 0;
                                    for(int bear = 0;bear < 32;bear++)
                                    {
                                       if(g_MmSimConfigReaderObj->l_UnsuppTele[bear] == '1')
                                       {
                                          l_isdRes->teleserviceList.value[l_isdRes->teleserviceList.count].length = 1;
                                          l_isdRes->teleserviceList.value[l_isdRes->teleserviceList.count].value[0] = l_teleList[bear];
                                          l_isdRes->teleserviceList.count++;
                                       }
                                    }
                                    if(l_isdRes->teleserviceList.count>20)
                                       l_isdRes->teleserviceList.count = 20;


                                    if(strcmp(g_MmSimConfigReaderObj->l_UnsuppBear,"0000000000000000000000000000000000000000000000000000"))
                                       l_isdRes->bit_mask |= OMAP3_InsertSubscriberDataRes_bearerServiceList_present;
                                    l_isdRes->bearerServiceList.count = 0;
                                    for(int bear = 0;bear < 52;bear++)
                                    {
                                       if(g_MmSimConfigReaderObj->l_UnsuppBear[bear] == '1')
                                       {
                                          l_isdRes->bearerServiceList.value[l_isdRes->bearerServiceList.count].length = 1;
                                          l_isdRes->bearerServiceList.value[l_isdRes->bearerServiceList.count].value[0] = l_bearerList[bear];//0x21;
                                          l_isdRes->bearerServiceList.count++;
                                       }
                                    }
                                    if(l_isdRes->bearerServiceList.count > 45)
                                       l_isdRes->bearerServiceList.count = 45;

                                    if(g_MmSimConfigReaderObj->l_UnsuppSsCount)
                                       l_isdRes->bit_mask |= OMAP3_InsertSubscriberDataRes_ss_List_present;
                                    l_isdRes->ss_List.count = g_MmSimConfigReaderObj->l_UnsuppSsCount;
                                    for(int i=0;i<100;i++)
                                    {
                                       l_isdRes->ss_List.value[i].length = 1;
                                       l_isdRes->ss_List.value[i].value[0] = g_MmSimConfigReaderObj->l_UnsuppSsCode[i];
                                    }


                                    union Hdata
                                    {
                                       unsigned int l_Hodb;
                                       unsigned char l_testhOdb[4];
                                    };
                                    Hdata l_HomOdb;
                                    l_HomOdb.l_Hodb = g_MmSimConfigReaderObj->l_GenODB;
                                    if(g_MmSimConfigReaderObj->l_GenODB)
                                       l_isdRes->bit_mask |= OMAP3_odb_GeneralData_present;                  
                                    memcpy(l_isdRes->odb_GeneralData.value,l_HomOdb.l_testhOdb,4);                                                            
                                    l_isdRes->odb_GeneralData.length =  getNumberOfSignificantBitsForAnArray(l_isdRes->odb_GeneralData.value,4);                                    
                                 }
                                 l_result.m_structBuffer = l_isdRes;
                                 g_sc.sendMsg(this, &l_result);

                                 printf("Received ISD Arg, Sending MapSpecificResult followed by MAP_Delimiter\n");
                                 TLOG(0, 0, "Sending Delimiter Req ...");
                                 MapDelimiterReq l_del(((MapSpecificMsg*) p_MsgPtr)->m_UserDlgId);
                                 g_sc.sendMsg(this, &l_del);
                              }
                              break;
                           default:
                              ELOG(0, 0, "Unknown REQUEST received");
                              break;

                        }
                     }
                     break;

                  case MAP_SPEC_EVENT_RESULT:
                     DLOG(0, 0, "MAP_SPEC_EVENT_RESULT received");
                     break;
                  case MAP_SPEC_EVENT_CONFIRMATION:
                     TLOG(0, 0, "Update GPRS location response received");
                     /* IMAP2_UpdateLocationRes *l_res = (IMAP2_UpdateLocationRes*) (((MapSpecificMsg*) p_MsgPtr)->m_structBuffer);
                        printf("\nUpdate GPRS location response received\n");
                        if (l_res != NULL) {
                        printf("\nHLR Number [%d] [", l_res->u.hlr_Number.length);
                        for (int i = 0; i < l_res->u.hlr_Number.length; i++) {
                        printf(" %02x", l_res->u.hlr_Number.value[i]);
                        }
                        printf(" ]\n");
                        }*/


                     break;
                  case MAP_SPEC_EVENT_USER_ERROR:
                     DLOG(0, 0, "MAP_SPEC_EVENT_USER_ERROR received");
                     switch (((MapUserError*) p_MsgPtr)->m_ErrorCode) {
                        case MAP_ERROR_systemFailure:
                           printf("\nGot a User Error : System Failure Param ");
                           break;
                        default:
                           printf("\nGot a User Error : %d ",((MapUserError*) p_MsgPtr)->m_ErrorCode);
                           break;
                     }
                     break;

                  case MAP_SPEC_EVENT_PROV_ERROR:
                     {
                        DLOG(0, 0, "MAP_SPEC_EVENT_PROV_ERROR received");
                        DLOG(0, 0, "Closing the Dialogue");
                        MapCloseReq l_closeReq(((MapSpecificMsg*) p_MsgPtr)->m_UserDlgId);
                        g_sc.sendMsg(this, &l_closeReq);
                     }
                     break;

                  default:
                     ELOG(0, 0, "ERROR!!! Default received");
                     break;

               }
               break;

            default:
               break;
         }
         break;

      case MSG_TYPE_DB:
         DLOG(0,0,"DB message received");
         break;

      case MSG_TYPE_TIMEOUT:
         break;

      default:
         DLOG(0, 0, "Unknown message received");
         break;

   }
   return true;
}
