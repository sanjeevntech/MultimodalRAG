#include <CtxtSimUpdateLocation.h>
#include <stdio.h>
#include <MmSimConfigReader.h>

CtxtSimUpdateLocation::CtxtSimUpdateLocation() 
{

}

CtxtSimUpdateLocation::~CtxtSimUpdateLocation() 
{

}

bool CtxtSimUpdateLocation::sendV3UpdateLocation() 
{
   DLOG(0,0,"MAP 3 UPD");
   OMAP3_UpdateLocationArg *l_temp = (OMAP3_UpdateLocationArg*) malloc(sizeof (OMAP3_UpdateLocationArg));
   memset(l_temp, '\0', sizeof (OMAP3_UpdateLocationArg));
   l_temp->bit_mask = 0;
   l_temp->imsi.length = 8;   

   unsigned long int l_imsi = 0;
   if(g_MmSimConfigReaderObj->l_Home_FLAG == 0)
   {
      l_imsi = g_MmSimConfigReaderObj->l_pri_imsi_with_CSI;
   }
   else if(g_MmSimConfigReaderObj->l_Home_FLAG == 1)
   {
      l_imsi = g_MmSimConfigReaderObj->l_sec_imsi_with_CSI;
   }   
   else if(g_MmSimConfigReaderObj->l_Home_FLAG == 2)
   {
      l_imsi = g_MmSimConfigReaderObj->l_loc_imsi_with_CSI;
   }   
   else
      return false;    
   DLOG(0,0,"Here"); 
   for(int a = 1; a <= g_MmSimConfigReaderObj->l_Count; a++)
   {    
      DLOG(0,0,"Here");
      unsigned char imsi[16];
      memset(imsi,'\0',sizeof(imsi));
      sprintf((char *)imsi,"%ld",l_imsi);      
      TLOG(0,0,"Filling IMSI %ld in string %s",l_imsi,imsi);
      StringToBCD(l_temp->imsi.value,imsi,15);
      l_temp->imsi.value[7] |= 0xf0;
      l_imsi++;



      int l_UserDlgId = g_sc.getNewDialogue();

      DLOG(0, 0, "Sending MapOpenReq ...");
      MapOpenReq l_mapOpenReq(l_UserDlgId, MAP_V3);
      l_mapOpenReq.m_OpenInfo.bit_mask = MAP_DP_OpenInfo_destinationReference_present |  MAP_DP_OpenInfo_originationReference_present;
      l_mapOpenReq.m_OpenInfo.destinationReference.length = 2;
      l_mapOpenReq.m_OpenInfo.destinationReference.value[0] = 0x11;
      l_mapOpenReq.m_OpenInfo.destinationReference.value[1] = 0x22;

      l_mapOpenReq.m_OpenInfo.originationReference.length = 3;
      l_mapOpenReq.m_OpenInfo.originationReference.value[0] = 0x33;
      l_mapOpenReq.m_OpenInfo.originationReference.value[1] = 0x22;
      l_mapOpenReq.m_OpenInfo.originationReference.value[2] = 0x11;

      l_mapOpenReq.m_ApplCntxt = MAP_AC_CODE_networkLocUp;
      l_mapOpenReq.m_DestAddr = g_ConfigData->i_NgConfigData.m_remoteAddress1;


      //TLOG(0, 0, "Sending Update Location request ...");
      MapSpecificRequest l_request(l_UserDlgId, MAP_OP_CODE_updateLocation, MAP_V3);
      unsigned long int l_ivlrAddr = 0;
      if(g_MmSimConfigReaderObj->l_Home_FLAG == 0)
         l_ivlrAddr =  g_MmSimConfigReaderObj->l_Home_VLR;
      else if(g_MmSimConfigReaderObj->l_Home_FLAG == 1)
         l_ivlrAddr = g_MmSimConfigReaderObj->l_Roam_VLR;
      else if(g_MmSimConfigReaderObj->l_Home_FLAG == 2)  
         l_ivlrAddr = g_MmSimConfigReaderObj->l_Local_VLR;

      unsigned char l_cvlrAddr[21];
      memset(l_cvlrAddr,'\0',sizeof(l_cvlrAddr));  
      sprintf((char *)l_cvlrAddr,"%ld",l_ivlrAddr);     

      configureSccpAddress(&l_mapOpenReq.m_OrigAddr,L_ROUTE_ON_GT,1002,g_ConfigData->i_NgConfigData.m_selfAddress.ssn,(char *)l_cvlrAddr+2);
      g_sc.sendMsg(this, &l_mapOpenReq);
      DLOG(0,0,"Map opem sent");


      l_temp->msc_Number.length = (strlen((char *)l_cvlrAddr) + 1)/2;
      StringToBCD(l_temp->msc_Number.value,l_cvlrAddr,strlen((char *)l_cvlrAddr));  
      l_temp->vlr_Number.length = (strlen((char *)l_cvlrAddr) + 1)/2;
      StringToBCD(l_temp->vlr_Number.value,l_cvlrAddr,strlen((char *)l_cvlrAddr)); 

      DLOG(0,0,"Here");
      l_temp->bit_mask =  OMAP3_UpdateLocationArg_lmsi_present;
      l_temp->bit_mask = 0;
      l_temp->lmsi.length = 4;
      l_temp->lmsi.value[0] = 0x00;
      l_temp->lmsi.value[1] = 0x00;
      l_temp->lmsi.value[2] = 0x02;
      l_temp->lmsi.value[3] = 0x00;

      l_temp->bit_mask |= OMAP3_UpdateLocationArg_vlr_Capability_present;
      l_temp->vlr_Capability.bit_mask = 0;
 
      char* l_tmp = getenv("SEND_NO_CAMEL");
      if((l_tmp != NULL) and (strcmp(l_tmp,"NO") == 0))
      {
         l_temp->vlr_Capability.bit_mask |= OMAP3_VLR_Capability_supportedCamelPhases_present;
      }
      l_temp->vlr_Capability.supportedCamelPhases.length  = 4;
      l_temp->vlr_Capability.supportedCamelPhases.value[0]  = 0;
      l_tmp = getenv("MAX_CAP_PHASE_SUPPORTED");
      if((l_tmp != NULL) and (strcmp(l_tmp,"4") == 0))
      {
         l_temp->vlr_Capability.supportedCamelPhases.value[0] |= OMAP3_phase4 | OMAP3_phase3 | OMAP3_phase2 | OMAP3_phase1;
      }
      else if((l_tmp != NULL) and (strcmp(l_tmp,"3") == 0))
      {
         l_temp->vlr_Capability.supportedCamelPhases.value[0] |= OMAP3_phase3 | OMAP3_phase2 | OMAP3_phase1;
      }
      else if((l_tmp != NULL) and (strcmp(l_tmp,"2") == 0))
      {
         l_temp->vlr_Capability.supportedCamelPhases.value[0] |=  OMAP3_phase2 | OMAP3_phase1;
      }
      else if((l_tmp != NULL) and (strcmp(l_tmp,"1") == 0))
      {
         l_temp->vlr_Capability.supportedCamelPhases.value[0] |= OMAP3_phase1;
      }
      //l_temp->vlr_Capability.offeredCamel4CSIs = 0;
      l_tmp = getenv("OFFERED_CAP_CSI");
      if(((l_tmp != NULL)) and (l_temp->vlr_Capability.supportedCamelPhases.value[0] & OMAP3_phase4))
      {
         l_temp->vlr_Capability.bit_mask |= OMAP3_VLR_Capability_offeredCamel4CSIs_present;
         l_temp->vlr_Capability.offeredCamel4CSIs.length = 6;
         l_temp->vlr_Capability.offeredCamel4CSIs.value[0] = 0; 

         if(l_tmp[0] == '1')
            l_temp->vlr_Capability.offeredCamel4CSIs.value[0] |= OMAP3_OfferedCamel4CSIs_o_csi;
         if(l_tmp[1] == '1')
            l_temp->vlr_Capability.offeredCamel4CSIs.value[0] |= OMAP3_OfferedCamel4CSIs_d_csi;
         if(l_tmp[2] == '1')
            l_temp->vlr_Capability.offeredCamel4CSIs.value[0] |= OMAP3_OfferedCamel4CSIs_vt_csi;
         if(l_tmp[3] == '1')
            l_temp->vlr_Capability.offeredCamel4CSIs.value[0] |= OMAP3_OfferedCamel4CSIs_t_csi;
         if(l_tmp[4] == '1')
            l_temp->vlr_Capability.offeredCamel4CSIs.value[0] |= OMAP3_OfferedCamel4CSIs_mt_sms_csi;
         if(l_tmp[5] == '1')
            l_temp->vlr_Capability.offeredCamel4CSIs.value[0] |= OMAP3_OfferedCamel4CSIs_mg_csi;
      }
      if(g_MmSimConfigReaderObj->l_Home_FLAG == 0)
         l_temp->vlr_Capability.bit_mask |= OMAP3_VLR_Capability_istSupportIndicator_present;
      l_temp->vlr_Capability.istSupportIndicator= OMAP3_istCommandSupported;//OMAP3_basicISTSupported;//

      unsigned char l_imei[20];
      memset(l_imei,'\0',sizeof(l_imei));
      l_tmp = getenv("IMEISV");
      if(l_tmp != NULL)
      {
        // printf("\n\n\n IMEISV Present \n\n\n");
         l_temp->bit_mask |= OMAP3_UpdateLocationArg_add_info_present;
         snprintf((char *)l_imei,sizeof(l_imei),"%s",l_tmp);
      }
      l_temp->add_info.imeisv.length = (strlen((char *)l_imei)+1)/2;
      StringToBCD(l_temp->add_info.imeisv.value,l_imei,strlen((char *)l_imei));

      if(g_MmSimConfigReaderObj->m_mtrf_support_ind == 1)
         l_temp->vlr_Capability.bit_mask |= OMAP3_mtRoamingForwardingSupported_present;

      if(g_MmSimConfigReaderObj->l_Send_LCSNotSupportIndicator)
      {
         DLOG(0,0,"Setting LCS Not supported Indicator");
         l_temp->bit_mask |= OMAP3_cs_LCS_NotSupportedByUE_present;
      }

      if(g_MmSimConfigReaderObj->l_SendGmlcAddr)
      {
         l_temp->bit_mask |= OMAP3_UpdateLocationArg_v_gmlc_Address_present;
         l_temp->v_gmlc_Address.length = 5;
         l_temp->v_gmlc_Address.value[0] = 0x04;
         l_temp->v_gmlc_Address.value[1] = 0xA5;
         l_temp->v_gmlc_Address.value[2] = 0x55;
         l_temp->v_gmlc_Address.value[3] = 0x9C;
         l_temp->v_gmlc_Address.value[4] = 0x15;
      }

      if(g_MmSimConfigReaderObj->l_SendLCSCapabilitySet)
      {
         l_temp->vlr_Capability.bit_mask |= OMAP3_VLR_Capability_supportedLCS_CapabilitySets_present;
         l_temp->vlr_Capability.supportedLCS_CapabilitySets.length = 4;
         l_temp->vlr_Capability.supportedLCS_CapabilitySets.value[0] = OMAP3_lcsCapabilitySet1 | OMAP3_lcsCapabilitySet2;

      }
      /*l_temp->bit_mask |= OMAP3_UpdateLocationArg_extensionContainer_present;
      l_temp->extensionContainer.bit_mask = OMAP3_ExtensionContainer_privateExtensionList_present;
      l_temp->extensionContainer.privateExtensionList.count = 1;
      OMAP3__ObjectID_ l_extId1;
      OMAP3__ObjectID_ l_extId2;
      OMAP3__ObjectID_ l_extId3;
      OMAP3__ObjectID_ l_extId4;
      OMAP3__ObjectID_ l_extId5;
      OMAP3__ObjectID_ l_extId6;
      OMAP3__ObjectID_ l_extId7;
      OMAP3__ObjectID_ l_extId8;
      OMAP3__ObjectID_ l_extId9;*/
#if 0   

      l_extId1.value=0x2A;
      l_extId2.value=0x86;
      l_extId3.value=0x3A;
      l_extId4.value=0x00;
      l_extId5.value=0x89;
      l_extId6.value=0x61;
      l_extId7.value=0x3A;
      l_extId8.value=0x01;
      l_extId9.value=0x00;

      l_extId1.next = &l_extId2;
      l_extId2.next = &l_extId3;
      l_extId3.next = &l_extId4;
      l_extId4.next = &l_extId5;
      l_extId5.next = &l_extId6;
      l_extId6.next = &l_extId7;
      l_extId7.next = &l_extId8;
      l_extId8.next = &l_extId9;
      l_extId9.next = NULL;
#endif   

#if 0   
      l_extId1.value=1;
      l_extId2.value=2;
      l_extId3.value=826;
      l_extId4.value=0x00;
      l_extId5.value=1249;
      l_extId6.value=58;
      l_extId7.value=1;
      l_extId8.value=0x00;

      l_extId1.next = &l_extId2;
      l_extId2.next = &l_extId3;
      l_extId3.next = &l_extId4;
      l_extId4.next = &l_extId5;
      l_extId5.next = &l_extId6;
      l_extId6.next = &l_extId7;
      l_extId7.next = &l_extId8;
      l_extId8.next = NULL;
#endif   
#if 0
      OssEncodedOID l_EncodedOID;
      OssBuf        l_OssAsnBuf;
      int l_res = 0;
      l_res = ossEncodedOidToAsnVal(m_AsnWorld_1,l_EncodedOID,l_OssAsnBuf);
      if(l_res == 0)
      {
         TLOG(0,0,"ossAsnValToEncodedOid success");
      }
      else
      {
         TLOG(0,0,"ossAsnValToEncodedOid fail");
      }
#endif 
#if 0   
      l_extId1.value=0x2A;
      l_extId2.value=0x86;
      l_extId1.next = &l_extId2;
      l_extId2.next = NULL; 
#endif   
      /*l_temp->extensionContainer.privateExtensionList.value[0].extId = &l_extId1;
      l_temp->extensionContainer.privateExtensionList.value[0].bit_mask = OMAP3_extType_present;
      l_temp->extensionContainer.privateExtensionList.value[0].extType.length = 17;
      char l_extType[] = {0xA7,0x0F,0x30,0x0D,0x81,0x01,0x0F,0x83,0x08,0x53,0x28,0x34,0x30,0x41,0x12,0x40,0x07};
      l_temp->extensionContainer.privateExtensionList.value[0].extType.encoded = l_extType;*/
      DLOG(0,0,"Calling Send MSG");
      l_request.m_structBuffer = (void*) l_temp;

      g_sc.sendMsg(this, &l_request);

      //printf("\n Sending Update location Req %d\n",l_UserDlgId);
      DLOG(0,0,"Sending Delimiter");
      MapDelimiterReq l_del(l_UserDlgId);
      g_sc.sendMsg(this, &l_del);
      TLOG(0, 0, "Sending Update Location request %d...IMSI is %02x%02x%02x%02x%02x%02x%02x%02x",a,l_temp->imsi.value[0],l_temp->imsi.value[1],l_temp->imsi.value[2],l_temp->imsi.value[3],l_temp->imsi.value[4],l_temp->imsi.value[5],l_temp->imsi.value[6],l_temp->imsi.value[7]);
   }


   return true;
}

bool CtxtSimUpdateLocation::sendV2UpdateLocation() 
{


   OMAP2_UpdateLocationArg *l_temp = (OMAP2_UpdateLocationArg*) malloc(sizeof (OMAP2_UpdateLocationArg));
   memset(l_temp, '\0', sizeof (OMAP2_UpdateLocationArg));

   l_temp->bit_mask = 0;
   l_temp->imsi.length = 8;

   //100007525310000 to 100007525319999
#if 0
   unsigned long int l_imsi = 0;
   if(g_MmSimConfigReaderObj->l_Home_FLAG == 0)
      l_imsi = g_MmSimConfigReaderObj->l_pri_imsi_no_CSI;
   else if(g_MmSimConfigReaderObj->l_Home_FLAG == 1)
      l_imsi = g_MmSimConfigReaderObj->l_sec_imsi_no_CSI;
   else if(g_MmSimConfigReaderObj->l_Home_FLAG == 2)
      l_imsi = g_MmSimConfigReaderObj->l_loc_imsi_no_CSI;
   else
      return false; 
#endif   
   unsigned long int l_imsi = 0;
   if(g_MmSimConfigReaderObj->l_Home_FLAG == 0)
   {
      l_imsi = g_MmSimConfigReaderObj->l_pri_imsi_with_CSI;
   }
   else if(g_MmSimConfigReaderObj->l_Home_FLAG == 1)
   {
      l_imsi = g_MmSimConfigReaderObj->l_sec_imsi_with_CSI;
   }   
   else if(g_MmSimConfigReaderObj->l_Home_FLAG == 2)
   {
      l_imsi = g_MmSimConfigReaderObj->l_loc_imsi_with_CSI;
   }   
   else
      return false;    

   for(int a = 1; a <= g_MmSimConfigReaderObj->l_Count; a++)
   {    
      unsigned char imsi[16];
      memset(imsi,'\0',sizeof(imsi));
      sprintf((char *)imsi,"%ld",l_imsi);        
      TLOG(0,0,"Filling IMSI %ld in string %s",l_imsi,imsi);
      StringToBCD(l_temp->imsi.value,imsi,15);
      l_temp->imsi.value[7] |= 0xf0;
      l_imsi++;

      int l_UserDlgId = g_sc.getNewDialogue();
      DLOG(0, 0, "Sending MapOpenReq ...");
      MapOpenReq l_mapOpenReq(l_UserDlgId, MAP_V2);
      l_mapOpenReq.m_OpenInfo.bit_mask = MAP_DP_OpenInfo_destinationReference_present |  MAP_DP_OpenInfo_originationReference_present;
      l_mapOpenReq.m_OpenInfo.destinationReference.length = 2;
      l_mapOpenReq.m_OpenInfo.destinationReference.value[0] = 0x11;
      l_mapOpenReq.m_OpenInfo.destinationReference.value[1] = 0x22;

      l_mapOpenReq.m_OpenInfo.originationReference.length = 3;
      l_mapOpenReq.m_OpenInfo.originationReference.value[0] = 0x33;
      l_mapOpenReq.m_OpenInfo.originationReference.value[1] = 0x22;
      l_mapOpenReq.m_OpenInfo.originationReference.value[2] = 0x11;

      l_mapOpenReq.m_ApplCntxt = MAP_AC_CODE_networkLocUp;
      l_mapOpenReq.m_DestAddr = g_ConfigData->i_NgConfigData.m_remoteAddress1;

      g_sc.sendMsg(this, &l_mapOpenReq);
      DLOG(0,0,"Map opem sent");

      //TLOG(0, 0, "Sending Update Location request ...");
      MapSpecificRequest l_request(l_UserDlgId, MAP_OP_CODE_updateLocation, MAP_V2);
      unsigned long int l_ivlrAddr = 0;
      if(g_MmSimConfigReaderObj->l_Home_FLAG == 0)
         l_ivlrAddr =  g_MmSimConfigReaderObj->l_Home_VLR;
      else if(g_MmSimConfigReaderObj->l_Home_FLAG == 1)
         l_ivlrAddr = g_MmSimConfigReaderObj->l_Roam_VLR;
      else if(g_MmSimConfigReaderObj->l_Home_FLAG == 2)
         l_ivlrAddr = g_MmSimConfigReaderObj->l_Local_VLR;
      else
         return false;
      unsigned char l_cvlrAddr[20];
      memset(l_cvlrAddr,'\0',sizeof(l_cvlrAddr));  
      sprintf((char *)l_cvlrAddr,"%ld",l_ivlrAddr);     

      l_temp->msc_Number.length = (strlen((char *)l_cvlrAddr) + 1)/2;
      StringToBCD(l_temp->msc_Number.value,l_cvlrAddr,strlen((char *)l_cvlrAddr));  
      l_temp->vlr_Number.length = (strlen((char *)l_cvlrAddr) + 1)/2;
      StringToBCD(l_temp->vlr_Number.value,l_cvlrAddr,strlen((char *)l_cvlrAddr)); 


      l_temp->bit_mask = 0;
      l_temp->bit_mask =  OMAP2_UpdateLocationArg_lmsi_present;
      l_temp->lmsi.length = 4;
      l_temp->lmsi.value[0] = 0x00;
      l_temp->lmsi.value[1] = 0x00;
      l_temp->lmsi.value[2] = 0x8D;
      l_temp->lmsi.value[3] = 0x42;


      DLOG(0,0,"Calling Send MSG");
      l_request.m_structBuffer = (void*) l_temp;

      g_sc.sendMsg(this, &l_request);

      //printf("\n Sending Update location Req %d\n",l_UserDlgId);
      DLOG(0,0,"Sending Delimiter");
      MapDelimiterReq l_del(l_UserDlgId);
      g_sc.sendMsg(this, &l_del);
      TLOG(0, 0, "Sending Update Location request %ld...IMSI is %02x%02x%02x%02x%02x%02x%02x%02x",a,l_temp->imsi.value[0],l_temp->imsi.value[1],l_temp->imsi.value[2],l_temp->imsi.value[3],l_temp->imsi.value[4],l_temp->imsi.value[5],l_temp->imsi.value[6],l_temp->imsi.value[7]);
   }
   return true;
}

bool CtxtSimUpdateLocation::sendV1UpdateLocationWithBeginSubscriber() 
{

   OMAP1_UpdateLocationArg *l_temp = (OMAP1_UpdateLocationArg*) malloc(sizeof (OMAP1_UpdateLocationArg));
   memset(l_temp, '\0', sizeof (OMAP1_UpdateLocationArg));
   l_temp->locationInfo.choice = OMAP1_mscNumber_chosen;
   l_temp->locationInfo.u.mscNumber.length = 1;
   l_temp->locationInfo.u.mscNumber.value[0] = 1;

   l_temp->bit_mask = 0;
   l_temp->imsi.length = 8;
#if 0
   unsigned long int l_imsi = 0;
   if(g_MmSimConfigReaderObj->l_Home_FLAG == 0)
      l_imsi = g_MmSimConfigReaderObj->l_pri_imsi_no_CSI;
   else if(g_MmSimConfigReaderObj->l_Home_FLAG == 1)
      l_imsi = g_MmSimConfigReaderObj->l_sec_imsi_no_CSI;
   else if(g_MmSimConfigReaderObj->l_Home_FLAG == 2)
      l_imsi = g_MmSimConfigReaderObj->l_loc_imsi_no_CSI;
   else
      return false;
#endif   
   unsigned long int l_imsi = 0;
   if(g_MmSimConfigReaderObj->l_Home_FLAG == 0)
   {
      l_imsi = g_MmSimConfigReaderObj->l_pri_imsi_with_CSI;
   }
   else if(g_MmSimConfigReaderObj->l_Home_FLAG == 1)
   {
      l_imsi = g_MmSimConfigReaderObj->l_sec_imsi_with_CSI;
   }   
   else if(g_MmSimConfigReaderObj->l_Home_FLAG == 2)
   {
      l_imsi = g_MmSimConfigReaderObj->l_loc_imsi_with_CSI;
   }   
   else
      return false;    
   for(int a = 1; a <= g_MmSimConfigReaderObj->l_Count; a++)
   {    
      unsigned char imsi[16];
      memset(imsi,'\0',sizeof(imsi));
      sprintf((char *)imsi,"%ld",l_imsi);        
      TLOG(0,0,"Filling IMSI %ld in string %s",l_imsi,imsi);
      StringToBCD(l_temp->imsi.value,imsi,15);
      l_temp->imsi.value[7] |= 0xf0;
      l_imsi++;

      int l_UserDlgId = g_sc.getNewDialogue();

      DLOG(0, 0, "Sending MapOpenReq ...");
      MapOpenReq l_mapOpenReq(l_UserDlgId, MAP_V1);
      l_mapOpenReq.m_ApplCntxt = MAP_AC_CODE_networkLocUp;
      l_mapOpenReq.m_DestAddr = g_ConfigData->i_NgConfigData.m_remoteAddress1;
      //l_mapOpenReq.m_DestAddr = g_ConfigData.i_NgConfigData.m_remoteAddress1;
      g_sc.sendMsg(this, &l_mapOpenReq);

      DLOG(0, 0, "Sending UL MapSpecificRequest ...");
      MapSpecificRequest l_request(l_UserDlgId, MAP_OP_CODE_updateLocation, MAP_V1);

      unsigned long int l_ivlrAddr = 0;
      if(g_MmSimConfigReaderObj->l_Home_FLAG == 0)
         l_ivlrAddr =  g_MmSimConfigReaderObj->l_Home_VLR;
      else if(g_MmSimConfigReaderObj->l_Home_FLAG == 1)
         l_ivlrAddr = g_MmSimConfigReaderObj->l_Roam_VLR;
      else if(g_MmSimConfigReaderObj->l_Home_FLAG == 2)
         l_ivlrAddr = g_MmSimConfigReaderObj->l_Local_VLR;
      else
         return false;
      unsigned char l_cvlrAddr[20];
      memset(l_cvlrAddr,'\0',sizeof(l_cvlrAddr));  
      sprintf((char *)l_cvlrAddr,"%ld",l_ivlrAddr);     

      l_temp->locationInfo.choice = OMAP1_mscNumber_chosen;
      l_temp->locationInfo.u.mscNumber.length = (strlen((char *)l_cvlrAddr) + 1)/2;
      StringToBCD(l_temp->locationInfo.u.mscNumber.value,l_cvlrAddr,strlen((char *)l_cvlrAddr));  
      l_temp->vlrNumber.length = (strlen((char *)l_cvlrAddr) + 1)/2;
      StringToBCD(l_temp->vlrNumber.value,l_cvlrAddr,strlen((char *)l_cvlrAddr)); 

      l_request.m_structBuffer = (void*) l_temp;
      g_sc.sendMsg(this, &l_request);
      DLOG(0, 0, "Sending MapDelimiterReq Req ...");
      MapDelimiterReq l_del(l_UserDlgId);
      g_sc.sendMsg(this, &l_del);
      TLOG(0, 0, "Sending Update Location request %ld...IMSI is %ld",l_imsi);
   }
   return true;
}

bool CtxtSimUpdateLocation::startProcessing() 
{
   DLOG(0, 0, "Start of CtxtSimUpdateLocation::startProcessing function");
   DLOG(0,0,"The version on UPD set is %d",g_MmSimConfigReaderObj->l_version);

   if(g_MmSimConfigReaderObj->l_version == 2)
   {
      sendV2UpdateLocation();
   }
   else if(g_MmSimConfigReaderObj->l_version == 1)
   {
      sendV1UpdateLocationWithBeginSubscriber();
   }
   else if(g_MmSimConfigReaderObj->l_version == 3)
   {
      sendV3UpdateLocation();
   }
   else
   {
      printf("\nWhat the hell u hav configured\n");
   }
   return true;
}

bool CtxtSimUpdateLocation::processMessage(Msg *p_MsgPtr, bool &p_DeleteFlag) 
{
   DLOG(0, 0, "Start of CtxtSimUpdateLocation::processMessage function Delete flag %d",p_DeleteFlag);

   //MapSpecificMsg *l_specMsg = NULL;

   int l_UserDlgId = 0;

   switch (p_MsgPtr->m_MsgType) {
      case MSG_TYPE_MAP:
         switch (((MapMsg*) p_MsgPtr)->m_MapMsgType) {
            case MAP_MSG_TYPE_COMMON:
               switch (((MapCommonMsg*) p_MsgPtr)->m_MapCommonMsgType) {
                  case MAP_CMN_OPEN_IND:
                     DLOG(0, 0, "MAP_CMN_OPEN_IND received");
                     break;

                  case MAP_CMN_OPEN_CNF:
                     DLOG(0, 0, "MAP_CMN_OPEN_CNF received");
                     //printf("\nThe other entity's version is %d", ((MapOpenCnf*) p_MsgPtr)->m_Version);
                     sendV2UpdateLocation();
                     break;

                  case MAP_CMN_DELIMITER_IND:
                     {
                        DLOG(0, 0, "MAP_CMN_DELIMITER_IND received");
                        l_UserDlgId = p_MsgPtr->m_UserDlgId;

                        /*DLOG(0,0,"Closing the Dialogue");
                          MapCloseReq l_closeReq(l_UserDlgId);
                          g_sc.sendMsg(this, &l_closeReq);*/
                     }
                     break;

                  case MAP_CMN_CLOSE_IND:
                     DLOG(0, 0, "MAP_CMN_CLOSE_IND received");
                     return true;
                     break;

                  case MAP_CMN_U_ABORT_IND:
                     DLOG(0, 0, "MAP_CMN_U_ABORT_IND received");
                     break;

                  case MAP_CMN_P_ABORT_IND:
                     DLOG(0, 0, "MAP_CMN_P_ABORT_IND received");
                     break;

                  case MAP_CMN_NOTICE_IND:
                     {
                        DLOG(0, 0, "MAP_CMN_NOTICE_IND received");
                        MapCloseReq l_closeReq(((MapMsg*)p_MsgPtr)->m_UserDlgId);
                        l_closeReq.m_CloseType = MAP_CLOSE_TYPE_PRE_ARRANGED_END;
                        g_sc.sendMsg(this, &l_closeReq);
                     }
                     break;

                  default:
                     DLOG(0, 0, "Unknown Msg received");
                     break;
               }
               break;

            case MAP_MSG_TYPE_SPECIFIC:
               DLOG(0, 0, "MAP_MSG_TYPE_SPECIFIC received");
               switch (((MapSpecificMsg*) p_MsgPtr)->m_MapSpecificEventType) {
                  case MAP_SPEC_EVENT_REQUEST:
                     DLOG(0, 0, "MAP_SPEC_EVENT_REQUEST received");
                     break;

                  case MAP_SPEC_EVENT_INDICATION:
                     {
                        DLOG(0, 0, "MAP_SPEC_EVENT_INDICATION received");
                        switch (((MapSpecificMsg*) p_MsgPtr)->m_OpCode) {
                           case MAP_OP_CODE_activateTraceMode:
                              {
                                 if(g_MmSimConfigReaderObj->l_SendATMError == 0)
                                 {
                                    TLOG(0,0,"Received activate trace mode");
                                    MapSpecificResult l_result(((MapSpecificMsg*) p_MsgPtr)->m_UserDlgId, MAP_OP_CODE_activateTraceMode, MAP_V3);
                                    g_sc.sendMsg(this, &l_result);
                                 }
                                 else                            
                                 {   
                                    OMAP3_FacilityNotSupParam l_fns;
                                    memset(&l_fns,'\0',sizeof(l_fns));
                                    MapUserError l_userError(((MapSpecificMsg*) p_MsgPtr)->m_UserDlgId, MAP_ERROR_facilityNotSup, MAP_V3, NULL);
                                    g_sc.sendMsg(this, &l_userError);
                                 } 

                                 MapDelimiterReq l_del(((MapSpecificMsg*) p_MsgPtr)->m_UserDlgId);
                                 g_sc.sendMsg(this, &l_del);


                              }
                              break;
                           case MAP_OP_CODE_insertSubscriberData:
                              {
                                 TLOG(0, 0, "MAP_OP_CODE_insertSubscriberData REQUEST received");

                                 if(g_MmSimConfigReaderObj->l_timeout > 0)
                                 {
                                    //sleep(g_MmSimConfigReaderObj->l_timeout);
                                 }
                                 char *l_tmp;
                                 l_tmp = getenv("SEND_ERROR_ON_ISD");
                                 if(strcmp(l_tmp,"YES") == 0)
                                 {

                                    printf("\nSEND_ERROR_ON_ISD is set, sending MAP_ERROR_unexpectedData \n");
                                    OMAP3_UnexpectedDataParam l_udp;
                                    memset(&l_udp,'\0',sizeof(l_udp));
                                    MapUserError l_userError(((MapSpecificMsg*) p_MsgPtr)->m_UserDlgId, MAP_ERROR_unexpectedData, MAP_V3, NULL);
                                    g_sc.sendMsg(this, &l_userError);
                                    MapDelimiterReq l_del(((MapSpecificMsg*) p_MsgPtr)->m_UserDlgId);
                                    g_sc.sendMsg(this, &l_del);
                                    return false;
                                 }


                                 l_tmp = getenv("DONT_SEND_ISD_RESP");
                                 if(strcmp(l_tmp,"YES") == 0)
                                 {
                                    printf("\nDONT_SEND_ISD_RESP is set, Not sending, L_CANCEL will come in 30 seconds\n");
                                    return false;
                                 }


#if 0
                                 /*TLOG(0,0,"Forming Provider error");
                                   MapProviderErrorMsg l_prov;//(((MapSpecificMsg*) p_MsgPtr)->m_UserDlgId);
                                   l_prov.m_UserDlgId     = ((MapSpecificMsg*) p_MsgPtr)->m_UserDlgId;
                                   l_prov.m_UserDlgId = 0;
                                   l_prov.m_MapProvErrorCode = MAP_PROV_ERROR_MISTYPED_PARAMETER;
                                   g_sc.sendMsg(this, &l_prov);
                                   TLOG(0,0,"SEnding Continue");
                                   MapDelimiterReq l_del(((MapSpecificMsg*) p_MsgPtr)->m_UserDlgId);
                                   g_sc.sendMsg(this, &l_del);
                                   return false;*/

#endif
#if 0
                                 sleep(1);
                                 sleep(1);
                                 sleep(1);
                                 sleep(1);
                                 sleep(1);
                                 sleep(1);
                                 sleep(1);
                                 sleep(1);
                                 sleep(1);
                                 sleep(1);
                                 sleep(1);
                                 sleep(1);
                                 sleep(1);
                                 sleep(1);
                                 sleep(1);
                                 sleep(1);
                                 sleep(1);
                                 sleep(1);
                                 sleep(1);
                                 sleep(1);
                                 sleep(1);
#endif      
                                 if(g_MmSimConfigReaderObj->l_version == 3)
                                 {
                                    MapSpecificResult l_result(((MapSpecificMsg*) p_MsgPtr)->m_UserDlgId, MAP_OP_CODE_insertSubscriberData, MAP_V3);


                                    DECLARE(OMAP3_InsertSubscriberDataRes,l_isdRes,3,"OMAP3_InsertSubscriberDataRes",DeclareFunc);

                                    l_isdRes->bit_mask = 0;
                                    if( g_MmSimConfigReaderObj->l_SendISDResp)
                                    {
                                       if(strcmp(g_MmSimConfigReaderObj->l_UnsuppTele,"00000000000000000000000000000000"))
                                          l_isdRes->bit_mask |= OMAP3_InsertSubscriberDataRes_teleserviceList_present;
                                       l_isdRes->teleserviceList.count = 0;
                                       for(int bear = 0;bear < 32;bear++)
                                       {
                                          if(g_MmSimConfigReaderObj->l_UnsuppTele[bear] == '1')
                                          {
                                             l_isdRes->teleserviceList.value[l_isdRes->teleserviceList.count].length = 1;
                                             l_isdRes->teleserviceList.value[l_isdRes->teleserviceList.count].value[0] = l_teleList[bear];
                                             l_isdRes->teleserviceList.count++;
                                          }
                                       }
                                       if(l_isdRes->teleserviceList.count>20)
                                          l_isdRes->teleserviceList.count = 20;


                                       if(strcmp(g_MmSimConfigReaderObj->l_UnsuppBear,"0000000000000000000000000000000000000000000000000000"))
                                          l_isdRes->bit_mask |= OMAP3_InsertSubscriberDataRes_bearerServiceList_present;
                                       l_isdRes->bearerServiceList.count = 0;
                                       for(int bear = 0;bear < 52;bear++)
                                       {
                                          if(g_MmSimConfigReaderObj->l_UnsuppBear[bear] == '1')
                                          {
                                             l_isdRes->bearerServiceList.value[l_isdRes->bearerServiceList.count].length = 1;
                                             l_isdRes->bearerServiceList.value[l_isdRes->bearerServiceList.count].value[0] = l_bearerList[bear];//0x21;
                                             l_isdRes->bearerServiceList.count++;
                                          }
                                       }
                                       if(l_isdRes->bearerServiceList.count > 45)
                                          l_isdRes->bearerServiceList.count = 45;

                                       if(g_MmSimConfigReaderObj->l_UnsuppSsCount)
                                          l_isdRes->bit_mask |= OMAP3_InsertSubscriberDataRes_ss_List_present;
                                       l_isdRes->ss_List.count = g_MmSimConfigReaderObj->l_UnsuppSsCount;
                                       for(int i=0;i<100;i++)
                                       {
                                          l_isdRes->ss_List.value[i].length = 1;
                                          l_isdRes->ss_List.value[i].value[0] = g_MmSimConfigReaderObj->l_UnsuppSsCode[i];
                                       }


                                       union Hdata
                                       {
                                          unsigned int l_Hodb;
                                          unsigned char l_testhOdb[4];
                                       };
                                       Hdata l_HomOdb;
                                       l_HomOdb.l_Hodb = g_MmSimConfigReaderObj->l_GenODB;
                                       if(g_MmSimConfigReaderObj->l_GenODB)
                                          l_isdRes->bit_mask |= OMAP3_odb_GeneralData_present;                  
                                       memcpy(l_isdRes->odb_GeneralData.value,l_HomOdb.l_testhOdb,4);                                                            
                                       l_isdRes->odb_GeneralData.length =  getNumberOfSignificantBitsForAnArray(l_isdRes->odb_GeneralData.value,4);                                    
                                    }
                                    if( g_MmSimConfigReaderObj->l_SendISDResp == 1)
                                       l_result.m_structBuffer = l_isdRes;
                                    else
                                       l_result.m_structBuffer = NULL;
                                    g_sc.sendMsg(this, &l_result);

                                    //printf("Received ISD Arg, Sending MapSpecificResult followed by MAP_Delimiter\n");
                                    DLOG(0, 0, "Sending Delimiter Req ...");
                                    MapDelimiterReq l_del(((MapSpecificMsg*) p_MsgPtr)->m_UserDlgId); 
                                    g_sc.sendMsg(this, &l_del); 
                                 }
                                 else if(g_MmSimConfigReaderObj->l_version == 2)
                                 {
                                    MapSpecificResult l_result(((MapSpecificMsg*) p_MsgPtr)->m_UserDlgId, MAP_OP_CODE_insertSubscriberData, MAP_V2);
                                    //OMAP2_InsertSubscriberDataRes *l_isdRes = (OMAP2_InsertSubscriberDataRes*) malloc(sizeof (OMAP2_InsertSubscriberDataRes));

                                    //memset(l_isdRes, '\0', sizeof (OMAP2_InsertSubscriberDataRes));
                                    DECLARE(OMAP2_InsertSubscriberDataRes,l_isdRes,2,"OMAP3_InsertSubscriberDataRes",DeclareFunc);


                                    if( g_MmSimConfigReaderObj->l_SendISDResp)
                                    {
                                       l_isdRes->bit_mask = OMAP2_InsertSubscriberDataRes_teleserviceList_present;
                                       l_isdRes->teleserviceList.count = 3;
                                       l_isdRes->teleserviceList.value[0].length = 1;
                                       l_isdRes->teleserviceList.value[0].value[0] = 0x21;
                                       l_isdRes->teleserviceList.value[1].length = 1;
                                       l_isdRes->teleserviceList.value[1].value[0] = 0x22;
                                       l_isdRes->teleserviceList.value[2].length = 1;
                                       l_isdRes->teleserviceList.value[2].value[0] = 0x23;

                                       l_isdRes->odb_GeneralData.length = 6;
                                       l_isdRes->odb_GeneralData.value[0] = OMAP2_allOG_CallsBarred|OMAP2_internationalOGCallsBarred|OMAP2_internationalOGCallsNotToHPLMN_CountryBarred|OMAP2_premiumRateInformationOGCallsBarred|OMAP2_premiumRateEntertainementOGCallsBarred|OMAP2_ss_AccessBarred;

                                       if(g_MmSimConfigReaderObj->l_GenODB)
                                          l_isdRes->bit_mask |= OMAP2_odb_GeneralData_present;                                   
                                    }

                                    l_result.m_structBuffer = l_isdRes;
                                    g_sc.sendMsg(this, &l_result);

                                    DLOG(0, 0, "Sending Delimiter Req ...");
                                    MapDelimiterReq l_del(((MapSpecificMsg*) p_MsgPtr)->m_UserDlgId);
                                    g_sc.sendMsg(this, &l_del);
                                 }
                                 else if(g_MmSimConfigReaderObj->l_version == 1)
                                 {
                                    MapSpecificResult l_result(((MapSpecificMsg*) p_MsgPtr)->m_UserDlgId, MAP_OP_CODE_insertSubscriberData, MAP_V2);

                                    //OMAP2_InsertSubscriberDataRes *l_isdRes = (OMAP2_InsertSubscriberDataRes*) malloc(sizeof (OMAP2_InsertSubscriberDataRes));
                                    g_sc.sendMsg(this, &l_result);

                                    DLOG(0, 0, "Sending Delimiter Req ...");
                                    MapDelimiterReq l_del(((MapSpecificMsg*) p_MsgPtr)->m_UserDlgId);
                                    g_sc.sendMsg(this, &l_del);
                                 }
                                 else
                                 {
                                    return false;
                                 }
                              }
                              break;
                           default:
                              ELOG(0, 0, "Unknown REQUEST received");
                              break;

                        }
                     }
                     break;

                  case MAP_SPEC_EVENT_RESULT:
                     DLOG(0, 0, "MAP_SPEC_EVENT_RESULT received");
                     break;
                  case MAP_SPEC_EVENT_CONFIRMATION:
                     DLOG(0, 0, "MAP_SPEC_EVENT_CONFIRMATION received");
                     TLOG(0,0,"Received Update Location response");                     
#if 0
                     IMAP2_UpdateLocationRes *l_res = (IMAP2_UpdateLocationRes*) (((MapSpecificMsg*) p_MsgPtr)->m_structBuffer);
                     if (l_res != NULL) {
                        printf("\nHLR Number [%d] [", l_res->u.hlr_Number.length);
                        for (int i = 0; i < l_res->u.hlr_Number.length; i++) {
                           printf(" %02x", l_res->u.hlr_Number.value[i]);
                        }
                        printf(" ]\n");
                     }
#endif                     


                     break;
                  case MAP_SPEC_EVENT_USER_ERROR:
                     DLOG(0, 0, "MAP_SPEC_EVENT_USER_ERROR received, code[%d]",((MapUserError*) p_MsgPtr)->m_ErrorCode);
                     switch (((MapUserError*) p_MsgPtr)->m_ErrorCode) 
                     {
                        case MAP_ERROR_systemFailure:
                           ELOG(0,0,"\nGot a User Error : System Failure Param for dialog id %d",((MapSpecificMsg*) p_MsgPtr)->m_UserDlgId);
                           break;
                        default:
                           CLOG(0,0,"\nGot error code %d for dialog id %d",((MapUserError*) p_MsgPtr)->m_ErrorCode,((MapSpecificMsg*) p_MsgPtr)->m_UserDlgId);
                           break;
                     }
                     break;

                  case MAP_SPEC_EVENT_PROV_ERROR:
                     {
                        DLOG(0, 0, "MAP_SPEC_EVENT_PROV_ERROR received");
                        DLOG(0, 0, "Closing the Dialogue");
                        MapCloseReq l_closeReq(((MapSpecificMsg*) p_MsgPtr)->m_UserDlgId);
                        g_sc.sendMsg(this, &l_closeReq);
                     }
                     break;

                  default:
                     ELOG(0, 0, "ERROR!!! Default received");
                     break;

               }
               break;

            default:
               break;
         }
         break;

      case MSG_TYPE_DB:
         DLOG(0, 0, "DB message received");
         break;

      default:
         DLOG(0, 0, "Unknown message received");
         break;

   }
   return true;
}
