#include <CtxtSimReset.h>
#include <stdio.h>
#include <MapMessages.h>
#include <ServiceCoordinator.h>
#include <Logger.h>
#include <OMAP1.h>
#include <OMAP2.h>
#include <OMAP3.h>
#include <DbActiveObject.h>
#include <ConfigReader.h>
#include <DataUnion.h>
#include <Utilities.h>
#include <HlrTdrFiller.h>

extern bool resetStruct(int p_version, int p_pdu, void *p_struct);


CtxtSimReset::CtxtSimReset()
{
   DLOG(0,0,"CtxtSimReset::CtxtSimReset()");
}

CtxtSimReset::~CtxtSimReset()
{
   DLOG(0,0,"CtxtSimReset::~CtxtSimReset()");
}


bool CtxtSimReset::processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag)
{
   DLOG(0,0,"Start of CtxtSimReset::processMsg function");
   MapSpecificMsg *l_specMsg = NULL;
   int l_dlgId;
   int l_UserDlgId;
   
   switch (p_MsgPtr->m_MsgType)
   {
      case MSG_TYPE_MAP:
         switch (((MapMsg*)p_MsgPtr)->m_MapMsgType)
         {
            case MAP_MSG_TYPE_COMMON:
               switch (((MapCommonMsg*)p_MsgPtr)->m_MapCommonMsgType)
               {
                  case MAP_CMN_OPEN_IND:
                     DLOG(0,0,"MAP_CMN_OPEN_IND received");
                     break;

                  case MAP_CMN_DELIMITER_IND:
                     DLOG(0,0,"MAP_CMN_DELIMITER_IND received");
                     break;

                  case MAP_CMN_CLOSE_IND:
                     DLOG(0,0,"MAP_CMN_CLOSE_IND received");

                     return true;
                     break;
                  
                  case MAP_CMN_OPEN_CNF:
                    { 
                        LLOG(0,0,"checking log");
                    }
                    break;
                  
                  case MAP_CMN_U_ABORT_IND:
                     DLOG(0,0," MAP_CMN_U_ABORT_IND received");
                     break;

                  case MAP_CMN_P_ABORT_IND:
                     DLOG(0,0,"MAP_CMN_P_ABORT_IND received");
                     break;

                  case MAP_CMN_NOTICE_IND:
                     {
                        DLOG(0,0,"MAP_CMN_NOTICE_IND received");
                        DLOG(0,0,"Closing the Dialogue");
                        MapCloseReq l_closeReq(((MapMsg*)p_MsgPtr)->m_UserDlgId);
                        g_sc.sendMsg(this, &l_closeReq);
                     }
                     break;

                  default:
                     DLOG(0,0,"Unknown Msg received [%d]", ((MapCommonMsg*)p_MsgPtr)->m_MapCommonMsgType);
                     break;
               }
               break;

            case MAP_MSG_TYPE_SPECIFIC:
               DLOG(0,0,"MAP_MSG_TYPE_SPECIFIC received");
               l_specMsg = (MapSpecificMsg*)p_MsgPtr;
               l_UserDlgId = l_specMsg->m_UserDlgId;
               DLOG(0,0,"MAP_MSG_TYPE_SPECIFIC received dlgId[%d] UserDlgId[%d]",
                     l_dlgId, l_UserDlgId);

               switch (((MapSpecificMsg*)p_MsgPtr)->m_MapSpecificEventType)
               {
                  case MAP_SPEC_EVENT_INDICATION:
                     {
                        DLOG(0,0,"MAP_SPEC_EVENT_INDICATION received");
                        l_UserDlgId = p_MsgPtr->m_UserDlgId;
                     }

                     break;

                  case MAP_SPEC_EVENT_RESULT:
                     {
                        DLOG(0,0,"MAP_SPEC_EVENT_RESULT received");
                     }
                     break;

                  case MAP_SPEC_EVENT_CONFIRMATION:
                     {
                        DLOG(0,0,"MAP_SPEC_EVENT_CONFIRMATION received");
                     }
                     break;

                  case MAP_SPEC_EVENT_USER_ERROR:
                     {
                        DLOG(0,0,"MAP_SPEC_EVENT_USER_ERROR received");
                     }
                     break;

                  case MAP_SPEC_EVENT_PROV_ERROR:
                     {
                        DLOG(0,0,"MAP_SPEC_EVENT_PROV_ERROR received");
                        DLOG(0,0,"Closing the Dialogue");
                        MapCloseReq l_closeReq(((MapSpecificMsg*)p_MsgPtr)->m_UserDlgId);
                        g_sc.sendMsg(this, &l_closeReq);
                     }
                     break;
                  default:
                     ELOG(0,0,"ERROR!! Default received");
                     break;

               }
               break;

            default:
               break;
         }
         break;

      case MSG_TYPE_DB:
         DLOG(0,0,"DB message received");
         break;

      default:
         DLOG(0,0,"Unknown message received");
         break;

   }
   return true;
}


