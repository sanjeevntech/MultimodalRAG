/*******************************************************************************
 * File        : CtxtSendParameters.cpp
 * Author      : VenkatRaman
 * Description : To handle SendParameter request
 * Created on  : August 29, 2010, 3:04 PM IST
 *******************************************************************************/

#include <stdio.h>
#include <ServiceCoordinator.h>
#include <MapMessages.h>
#include <Logger.h>
#include <DbQueryMsg.h>
#include <DbActiveObject.h>
#include <SubsProfileData.h>
#include <SubsProfilesManager.h>
#include <DataUnion.h>
#include <Utilities.h>
#include <MmConfigReader.h>
#include <CtxtUpdateLocation.h>

bool CtxtUpdateLocation::sp_CheckSendParametersV1(int l_UserDlgId,IMAP1_SendParametersArg* l_temp)
{
   DLOG(0,0,"Check parameters for Dialog Id %d",l_UserDlgId);
   memset(m_sp_imsi,'\0',sizeof(m_sp_imsi));
   if(l_temp->subscriberId.choice != OMAP1_SubscriberId_imsi_chosen)
   {
      WLOG(0,0,"Subscriber id is not IMSI");
      return false;
   }
   BCDToString(m_sp_imsi,l_temp->subscriberId.u.imsi.value, l_temp->subscriberId.u.imsi.length);
   if(strlen((char *)m_sp_imsi) != IMSILEN)
   {
      WLOG(0,0,"Strlen of imsi is not 15");
      return false;
   }
   setTraceImsi((char *)m_sp_imsi);
   m_tdr.setChar(TDR_INDEX_REQUEST_TYPE,'I'); // 1-msisdn 2-imsi 3-both
   m_tdr.setString(TDR_INDEX_REQUEST_IMSI,(char*)m_sp_imsi);
   LLOG(0,0,"Trace enabled on imsi %s",(char *)m_sp_imsi);
   m_sp_SendParamPresent = false;
   struct IMAP1_RequestParameters_ *l_rp = NULL;
   l_rp = l_temp->requestParameters;
   while(l_rp != NULL)
   {
      switch(l_rp->value)
      {
         case IMAP1_request_IMSI:
            {
               WLOG(0,0,"MAP1_request_IMSI present");
            }
            break;
         case IMAP1_request_AuthenticationSet:
            {
               WLOG(0,0,"MAP1_request_AuthenticationSet present");
            }
            break;
         case IMAP1_request_SubscriberData:
            {
               LLOG(0,0,"MAP1_request_SubscriberData present");
               m_sp_SendParamPresent = true;
            }
            break;
         case IMAP1_request_CUG_Information:
            {
               WLOG(0,0,"MAP1_request_CUG_Information present");
            }
            break;
         case IMAP1_request_Ki:
            {
               WLOG(0,0,"MAP1_request_Ki present");
            }
            break;
         default:
            {
               CLOG(0,0,"unknown request parameter");
            }
            break;
      }
      l_rp = l_rp->next;
   }
   if(m_sp_SendParamPresent == false)
      return false;
   DLOG(0,0,"Check parameters true for dlgId %d",l_UserDlgId); 
   return true;    
}

bool CtxtUpdateLocation::sp_SendParamResp(int l_UserDlgId)
{
   LLOG(0,0,"Forming Send parameter response for Dialog Id %d",l_UserDlgId);
//   DLOG(0,0,"SUBSCRIBER ACCOUNT AND PROFILE INFO : Network Access Mode:%d Category:%d Subscription Restriction:%d Access Restriction:%d Subscriber Status:%d LMU :%d IST :%d Bearer Service list:%s Tele Service list:%s OCSI Profile ID:%d TCSI Profile Id:%d UGCSI Profile Id:%d SSCSI Profile ID:%d TIFCSI Profile ID:%d  DCSI Profile Id:%d MO SMS CSI profile Id:%d MT SMS CSI Profile Id:%d GPRS CSI profile Id:%d MG CSI Profile Id:%d",
 //        GenProfile.l_nwAccMode,GenProfile.l_catgory,GenProfile.l_subsRest,GenProfile.l_accRest,GenProfile.l_subsStatus,GenProfile.l_lmu,GenProfile.l_ist,GenProfile.l_bearer,GenProfile.l_tele,GenProfile.l_ocsiPid,GenProfile.l_tcsiPid,GenProfile.l_ugcsiPid,GenProfile.l_sscsiPid,GenProfile.l_tifcsiPid,GenProfile.l_dcsiPid,GenProfile.l_moscsiPid,GenProfile.l_mtscsiPid,GenProfile.l_gcsiPid,GenProfile.l_mgcsiPid);
   DLOG(0,0,"Subscriber Known MSISDN is [%s] [%s]",(char *)l_actMsisdn,GsmProfile.l_ActMsisdn);
   //strcpy((char *)m_isd.dbisd1.msisdn,(char *)GsmProfile.l_ActMsisdn);
   strncpy((char *)m_isd.dbisd1.msisdn,(char *)l_actMsisdn,strlen((char *)l_actMsisdn));
   strcpy(m_isd.dbisd1.bearerData,GenProfile.l_bearer);
   strcpy(m_isd.dbisd1.teleData,GenProfile.l_tele);
   m_isd.dbisd1.subStatus = GenProfile.l_subsStatus;
   m_isd.dbisd1.nwAccMode = GenProfile.l_nwAccMode;
   m_isd.dbisd1.category = GenProfile.l_catgory;
   MapSpecificResult l_result(l_UserDlgId, MAP_OP_CODE_sendParameters, MAP_V1);
   //DECLARE(OMAP1_SendParametersRes,l_sp, 1);
   DECLARE(OMAP1_SendParametersRes,l_sp,1,"OMAP1_SendParametersRes",DeclareFunc);
   index = OMAP1_SubscriberData_msIsdn_present;
   SsIndex = OMAP1_forwardingInfo_chosen;
   flag = false;   
   m_isd.pss.CFWD_STATE = (provisionedSS::CFWD)0;
   m_isd.pss.CB_STATE = (provisionedSS::CB)0;
   m_isd.pss.val = 0;
   m_isd.dbisd3.VLRCsi = false;
   m_isd.dbisd3.sgsncsi = false;
   m_isd.dbisd3.gprsSubsData = 0;
   m_isd.pss.m_GenSsCount = 0;
   //FillSubsData(l_UserDlgId,l_sp->sentParameters.value[0].u.susbcriberData);  
   while(false == sp_FillSubsDataForSp(l_UserDlgId,l_sp))
   {
      m_sp_len = 0;
      sp_sendRESULTNOTLAST(l_UserDlgId,l_result,l_sp);      
      m_sp_secondChunk = true;
      //DECLARE(OMAP1_SendParametersRes,l_sp,1,"OMAP1_SendParametersRes",DeclareFunc);
   }
   //else
   //{
   //DECLARE(OMAP1_SendParametersRes,l_sp,1,"OMAP1_SendParametersRes",DeclareFunc);
   sp_sendRESULTLAST(l_UserDlgId,l_result,l_sp);
   //}
   return true;   
}


bool CtxtUpdateLocation::sp_FillSubsDataForSp(int l_UserDlgId,OMAP1_SendParametersRes *l_sp)
{
   l_sp->sentParameters.count = 1;
   l_sp->sentParameters.value[0].choice = OMAP1_susbcriberData_chosen;
   l_sp->sentParameters.value[0].u.susbcriberData.bit_mask = 0;

   m_sp_pLen = 0;
   m_sp_len = 6;
   switch(index)
   {
      case OMAP1_SubscriberData_msIsdn_present://0x80
         {
            DLOG(0,0,"Adding MSISDN %s",m_isd.dbisd1.msisdn);
            l_sp->sentParameters.value[0].u.susbcriberData.bit_mask |= OMAP1_SubscriberData_msIsdn_present;
            u8 finalMsisdn[20];
            memset(finalMsisdn,'\0',sizeof(finalMsisdn));
            strncpy((char *)finalMsisdn,"19",2);
            strcat((char *)finalMsisdn,(char *)m_isd.dbisd1.msisdn);
            int len2 = strlen((char *)finalMsisdn);
            l_sp->sentParameters.value[0].u.susbcriberData.msIsdn.length = (len2+1)/2;
            StringToBCD(l_sp->sentParameters.value[0].u.susbcriberData.msIsdn.value,finalMsisdn,len2);
            m_sp_len += len2;
            DLOG(0,0,"The Encoding length till here is %d MSISDN added %d",m_sp_len,(m_sp_len-m_sp_pLen));
            m_sp_pLen = m_sp_len;
            index = OMAP1_SubscriberData_category_present;
            //m_SdLen += m_sp_len;
         }
         //break;
      case OMAP1_SubscriberData_category_present://0x40
         {
            DLOG(0,0,"Adding Category");
            l_sp->sentParameters.value[0].u.susbcriberData.bit_mask |= OMAP1_SubscriberData_category_present;
            l_sp->sentParameters.value[0].u.susbcriberData.category.length = 1;
            l_sp->sentParameters.value[0].u.susbcriberData.category.value[0] = m_isd.dbisd1.category;
            m_sp_len += 3;
            m_sp_pLen = m_sp_len;
            index = OMAP1_SubscriberData_subscriberStatus_present;
         }
         //break;
      case OMAP1_SubscriberData_subscriberStatus_present://0x20
         {
            DLOG(0,0,"Adding subscriber status");
            l_sp->sentParameters.value[0].u.susbcriberData.bit_mask |= OMAP1_SubscriberData_subscriberStatus_present;
            l_sp->sentParameters.value[0].u.susbcriberData.subscriberStatus = (OMAP1_SubscriberStatus)m_isd.dbisd1.subStatus;
            m_sp_len += 3;
            DLOG(0,0,"The Encoding length till here is %d SUBSCRIBER STATUS added %d",m_sp_len,(m_sp_len-m_sp_pLen));
            m_sp_pLen = m_sp_len;
            index = OMAP1_SubscriberData_bearerServiceList_present;
         }
         //break;
      case OMAP1_SubscriberData_bearerServiceList_present:
         {
            if(1)//m_isd.dbisd1.bearer)
            {
               DLOG(0,0,"Adding bearer service data %s",m_isd.dbisd1.bearerData);
               int l_PrevCount = 0;
               if(false == m_sp_SecondBS)
               {
                  m_isd.bs.formBearerV1C1(l_UserDlgId,l_sp->sentParameters.value[0].u.susbcriberData.bearerServiceList,m_isd.dbisd1.bearerData);
                  DLOG(0,0,"Count of Bearer Service afteir Adding is %d",l_sp->sentParameters.value[0].u.susbcriberData.bearerServiceList.count);
                  if(l_sp->sentParameters.value[0].u.susbcriberData.bearerServiceList.count)
                  {
                     l_sp->sentParameters.value[0].u.susbcriberData.bit_mask |= OMAP1_SubscriberData_bearerServiceList_present;
                     m_sp_len += 10 + (l_sp->sentParameters.value[0].u.susbcriberData.bearerServiceList.count * 3);
                  }
                  l_PrevCount = l_sp->sentParameters.value[0].u.susbcriberData.bearerServiceList.count;
               }
               if(m_sp_SecondBS)
                  l_sp->sentParameters.value[0].u.susbcriberData.bearerServiceList.count = 0;
               m_isd.bs.formBearerV1C2(l_UserDlgId,l_sp->sentParameters.value[0].u.susbcriberData.bearerServiceList,m_isd.dbisd1.bearerData);
               DLOG(0,0,"Count of Bearer Service afteir Adding is %d",l_sp->sentParameters.value[0].u.susbcriberData.bearerServiceList.count);
               if(l_sp->sentParameters.value[0].u.susbcriberData.bearerServiceList.count)
               {
                  l_sp->sentParameters.value[0].u.susbcriberData.bit_mask |= OMAP1_SubscriberData_bearerServiceList_present;
                  m_sp_len += 10 + (l_sp->sentParameters.value[0].u.susbcriberData.bearerServiceList.count * 3);
               }

               if (m_sp_len >= g_MmConfigReaderObj->m_IsdLen)
               {
                  DLOG(0,0,"Current length is %d sending till previous length %d",m_sp_len,m_sp_pLen);
                  index = OMAP1_SubscriberData_bearerServiceList_present;
                  //l_sp->sentParameters.value[0].u.susbcriberData.bit_mask &= (~OMAP1_SubscriberData_bearerServiceList_present);
                  l_sp->sentParameters.value[0].u.susbcriberData.bearerServiceList.count = l_PrevCount;
                  m_sp_SecondBS = true;
                  return false;
                  break;
               }
               DLOG(0,0,"The Encoding length till here is %d BEARER SERVICE LIST added %d",m_sp_len,(m_sp_len-m_sp_pLen));
               m_sp_pLen = m_sp_len;
            }
            index = OMAP1_SubscriberData_teleserviceList_present;
         }
         //break;
      case OMAP1_SubscriberData_teleserviceList_present://0x08
         {
            DLOG(0,0,"Teleservice list %s",m_isd.dbisd1.teleData);
            m_isd.bs.formTeleV1(l_UserDlgId,l_sp->sentParameters.value[0].u.susbcriberData.teleserviceList,m_isd.dbisd1.teleData);
            DLOG(0,0,"Count of Tele Service after Adding is %d",l_sp->sentParameters.value[0].u.susbcriberData.teleserviceList.count);
            if(l_sp->sentParameters.value[0].u.susbcriberData.teleserviceList.count)
            {
               l_sp->sentParameters.value[0].u.susbcriberData.bit_mask |=   OMAP1_SubscriberData_teleserviceList_present;
               m_sp_len += 5 + (l_sp->sentParameters.value[0].u.susbcriberData.teleserviceList.count * 3);
            }
            if (m_sp_len  >=  g_MmConfigReaderObj->m_IsdLen)
            {
               DLOG(0,0,"Current length is %d sending till previous length %d",m_sp_len,m_sp_pLen);
               index = OMAP1_SubscriberData_teleserviceList_present;
               l_sp->sentParameters.value[0].u.susbcriberData.bit_mask &= (~OMAP1_SubscriberData_teleserviceList_present);
               return false;
               break;
            }
            DLOG(0,0,"The Encoding length till here is %d TELE SERVICE LIST added %d",m_sp_len,(m_sp_len-m_sp_pLen));
            m_sp_pLen = m_sp_len;
            index = OMAP1_SubscriberData_provisonedSS_present;

         }
         //break;
      case OMAP1_SubscriberData_provisonedSS_present:
         {
            switch(SsIndex)
            {
               case OMAP1_forwardingInfo_chosen: //choice 1
                  {
                     if(m_sp_secondChunk)
                     {
                        l_sp->sentParameters.value[0].u.susbcriberData.provisonedSS.count = 0;
                        m_sp_secondChunk = false;
                     }
                     l_sp->sentParameters.value[0].u.susbcriberData.bit_mask |= OMAP1_SubscriberData_provisonedSS_present;
                     l_sp->sentParameters.value[0].u.susbcriberData.provisonedSS.count = 0;
                     m_isd.pss.val = 0;
                     DLOG(0,0,"going to add CFWD FWD info, CFWD State is %d,ISD length formed so far %d",m_isd.pss.CFWD_STATE,m_sp_len);
                     int rret = sp_formFwdSS1(l_UserDlgId,l_sp->sentParameters.value[0].u.susbcriberData.provisonedSS,m_sp_len);
                     DLOG(0,0,"SS Count %d, rret %d",l_sp->sentParameters.value[0].u.susbcriberData.provisonedSS.count,rret);
                     if(l_sp->sentParameters.value[0].u.susbcriberData.provisonedSS.count == 0)
                     {
                        l_sp->sentParameters.value[0].u.susbcriberData.bit_mask &= (~OMAP1_SubscriberData_provisonedSS_present);
                        m_isd.pss.val = 0;
                     }
                     m_sp_len += 5 + (l_sp->sentParameters.value[0].u.susbcriberData.provisonedSS.count * 30);

                     if(1 == rret)
                     {
                        DLOG(0,0,"Current length exceeded sending till previous length %d",m_sp_pLen);
                        index = OMAP1_SubscriberData_provisonedSS_present;
                        l_sp->sentParameters.value[0].u.susbcriberData.bit_mask &= (~OMAP1_SubscriberData_provisonedSS_present);
                        SsIndex = OMAP1_forwardingInfo_chosen;
                        m_isd.pss.val = 0;
                        DLOG(0,0,"Reset val to %d, CFWD State is %d",m_isd.pss.val,m_isd.pss.CFWD_STATE);
                        flag = true;
                        return false;
                        break;
                     }
                     else if(2 == rret)
                     {
                        DLOG(0,0,"Current length is %d sending till previous length %d",m_sp_len,m_sp_pLen);
                        DLOG(0,0,"Length after adding CFWD is %d",m_sp_len);
                        index = OMAP1_SubscriberData_provisonedSS_present;
                        SsIndex = OMAP1_forwardingInfo_chosen;
                        m_isd.pss.val = 0;
                        DLOG(0,0,"Reset count to %d",m_isd.pss.val);
                        DLOG(0,0,"CFWD State is %d",m_isd.pss.CFWD_STATE);
                        flag = true;
                        return false;
                        break;
                     }

                     else
                     {
                        DLOG(0,0,"After Call FWD unconditional Info,Length after adding CFWD is %d",m_sp_len);
                        index = OMAP1_SubscriberData_provisonedSS_present;
                        flag = false;
                        SsIndex = OMAP1_callBarringInfo_chosen;
                        DLOG(0,0,"The Encoding length till here is %d PROVISIONEDSS added %d",m_sp_len,(m_sp_len-m_sp_pLen));
                        m_sp_pLen = m_sp_len;
                     }
                  }
                  //break;
               case OMAP1_callBarringInfo_chosen: //choice 2
                  {
                     if(m_sp_secondChunk)
                     {
                        l_sp->sentParameters.value[0].u.susbcriberData.provisonedSS.count = 0;
                        m_sp_secondChunk = false;
                     }
                     l_sp->sentParameters.value[0].u.susbcriberData.bit_mask |= OMAP1_SubscriberData_provisonedSS_present;
                     int l_CFWDCount = l_sp->sentParameters.value[0].u.susbcriberData.provisonedSS.count;
                     DLOG(0,0,"going to add CB info SS Count value is %d CB State is %d SD m_sp_len formed till now %d",l_sp->sentParameters.value[0].u.susbcriberData.provisonedSS.count,m_isd.pss.CB_STATE,m_sp_len);
                     int reet = sp_formCbSS1(l_UserDlgId,l_sp->sentParameters.value[0].u.susbcriberData.provisonedSS,m_sp_len);
                     DLOG(0,0,"After CB count here %d reet is %d",l_sp->sentParameters.value[0].u.susbcriberData.provisonedSS.count,reet);
                     if(l_sp->sentParameters.value[0].u.susbcriberData.provisonedSS.count == 0)
                     {
                        l_sp->sentParameters.value[0].u.susbcriberData.bit_mask &= (~OMAP1_SubscriberData_provisonedSS_present);
                        m_isd.pss.val = 0;
                     }
                     if(l_sp->sentParameters.value[0].u.susbcriberData.provisonedSS.count - l_CFWDCount)
                        m_sp_len += 5 + ((l_sp->sentParameters.value[0].u.susbcriberData.provisonedSS.count - l_CFWDCount) * 18);
                     if(2 == reet)
                     {
                        DLOG(0,0,"Current length is %d sending till previous length %d",m_sp_len,m_sp_pLen);
                        index = OMAP1_SubscriberData_provisonedSS_present;
                        //l_isd->bit_mask &= (~OMAP3_provisionedSS_present);
                        SsIndex = OMAP1_callBarringInfo_chosen;
                        m_isd.pss.val = 0;
                        DLOG(0,0,"Reset Count to %d",m_isd.pss.val);
                        flag = true;
                        return false;
                        break;
                     }


                     if(1 == reet)
                     {
                        DLOG(0,0,"Current length is %d sending till previous length %d",m_sp_len,m_sp_pLen);
                        index = OMAP1_SubscriberData_provisonedSS_present;
                        l_sp->sentParameters.value[0].u.susbcriberData.bit_mask &= (~OMAP1_SubscriberData_provisonedSS_present);
                        SsIndex = OMAP1_callBarringInfo_chosen;
                        m_isd.pss.val = 0;
                        DLOG(0,0,"Reset count to %d",m_isd.pss.val);
                        flag = true;
                        return false;
                        break;
                     }
                     flag = false;
                     SsIndex = OMAP1_ss_Data_chosen;
                     //m_sp_len = g_AsnCodecO1.getEncodingLength(OMAP1_InsertSubscriberDataArg_PDU,l_isd);
                     DLOG(0,0,"The Encoding length till here is %d PROVISIONEDSS added %d",m_sp_len,(m_sp_len-m_sp_pLen));
                     m_sp_pLen = m_sp_len;
                  }
                  //break;
               case OMAP1_ss_Data_chosen:
                  {
                     if(m_sp_secondChunk)
                     {
                        l_sp->sentParameters.value[0].u.susbcriberData.provisonedSS.count = 0;
                        m_sp_secondChunk = false;
                     }
                     l_sp->sentParameters.value[0].u.susbcriberData.bit_mask |= OMAP1_SubscriberData_provisonedSS_present;
                     DLOG(0,0,"Going to form Ext_SS_Info count here is %d",l_sp->sentParameters.value[0].u.susbcriberData.provisonedSS.count);
                     m_sp_PrevSS = l_sp->sentParameters.value[0].u.susbcriberData.provisonedSS.count;
                     int rett = sp_formSsSS1(l_UserDlgId,l_sp->sentParameters.value[0].u.susbcriberData.provisonedSS,m_sp_len);
                     if(l_sp->sentParameters.value[0].u.susbcriberData.provisonedSS.count == 0)
                     {
                        l_sp->sentParameters.value[0].u.susbcriberData.bit_mask &= (~OMAP1_SubscriberData_provisonedSS_present);
                     }
                     DLOG(0,0,"SS -> Val here is %d ISD count fill till %d rett is %d",m_isd.pss.val,l_sp->sentParameters.value[0].u.susbcriberData.provisonedSS.count,rett);
                     if(rett == 1)
                     {
                        DLOG(0,0,"Current length is %d sending till previous length %d",m_sp_len,m_sp_pLen);
                        index = OMAP1_SubscriberData_provisonedSS_present;
                        DLOG(0,0,"Length after adding SS DATA is %d",m_sp_len);
                        l_sp->sentParameters.value[0].u.susbcriberData.bit_mask &= (~OMAP1_SubscriberData_provisonedSS_present);
                        SsIndex = OMAP1_ss_Data_chosen;
                        flag = true;
                        return false;
                        break;
                     }
                     else if(rett == 2)
                     {
                        //DLOG(0,0,"Current length is %d sending till previous length %d",m_sp_len,m_sp_pLen);
                        index = OMAP1_SubscriberData_provisonedSS_present;
                        DLOG(0,0,"Length after adding SS DATA is %d SS Data count %d",m_sp_len,l_sp->sentParameters.value[0].u.susbcriberData.provisonedSS.count);
                        //DLOG(0,0,"PrevSS = %d",m_PrevSS);
                        // if(PrevSS == 0)
                        //   l_isd->bit_mask &= (~OMAP3_provisionedSS_present);
                        SsIndex = OMAP1_ss_Data_chosen;
                        index = OMAP1_ss_Data_chosen;
                        m_isd.pss.val = 0;
                        DLOG(0,0,"Reset count to %d",m_isd.pss.val);
                        flag = true;
                        return false;
                        break;
                     }
                     else
                     {
                        flag = false;
                        SsIndex = 0;
                        DLOG(0,0,"The Encoding length till here is %d PROVISIONEDSS added %d",m_sp_len,(m_sp_len-m_sp_pLen));
                        m_sp_pLen = m_sp_len;
                     }
                  }
                  //break;
               default://Must not come here
                  {
                     DLOG(0,0,"Inside Default");
                     SsIndex = 0;
                     index = 00;
                  }
                  //break;
            }
            if(flag)
               break;
            else
            {
               DLOG(0,0,"After Provisioned SS,Added all Subscriber Data");
               index = 0;
            }
            index = 0;
            return true;
            break;
         }
         //break;

      default:
         {
         }
         //break;
   }
   return true;
}

bool CtxtUpdateLocation :: sp_sendRESULTNOTLAST(int DlgId,MapSpecificResult l_result,OMAP1_SendParametersRes *m_sp)
{
   l_result.m_structBuffer = (void*)m_sp;
   l_result.m_LastFlag = false; // TC_RESULT_NL
   g_sc.sendMsg(this, &l_result);
   DLOG(0,0,"Continuing the sendParameters Dialogue");
   MapDelimiterReq l_delReq(DlgId);
   g_sc.sendMsg(this, &l_delReq);
   return true;
}

bool CtxtUpdateLocation :: sp_sendRESULTLAST(int DlgId,MapSpecificResult l_result,OMAP1_SendParametersRes *m_sp)
{
   l_result.m_structBuffer = (void*)m_sp;
   g_sc.sendMsg(this, &l_result);
   DLOG(0,0,"Closing sendParameters Dialog");
   MapCloseReq l_closeReq(DlgId);
   g_sc.sendMsg(this, &l_closeReq);
   m_tdr.setString(TDR_INDEX_ERR_CODE,"");
   return true;
}


int CtxtUpdateLocation::sp_formFwdSS1(int DlgId,OMAP1_SS_InfoList &l_isd, int p_isdLen)
{
   DLOG(0,0,"Inside formFwdSS for Dialog Id %d, SS Count is %d",DlgId,m_isd.pss.val);
   DLOG(0,0,"Value of cfuSsCount = %d,cdSsCount = %d,cfbSsCount = %d,cfnrySsCount = %d,cfnrcSsCount = %d",
         m_isd.pss.cfuSsCount,m_isd.pss.cdSsCount,m_isd.pss.cfbSsCount,m_isd.pss.cfnrySsCount,m_isd.pss.cfnrcSsCount);
   int l_len = p_isdLen;   
   switch(m_isd.pss.CFWD_STATE)
   {
      case provisionedSS::CFWD_UNCON:
         {
            if(m_isd.pss.cfuSsCode)
            {                 
               l_isd.count = m_isd.pss.val+1;
               DLOG(0,0,"SS Count after adding CFU = %d",m_isd.pss.val+1);
               //m_isd.pss.formCfuSS1(DlgId,l_isd);
               m_isd.pss.formCfuSS1(l_isd);
               int len1 = l_len;
               //len1 = g_AsnCodecO1.getEncodingLength(OMAP1_SendParametersRes_PDU, l_isd);
               len1 += 15 + (m_isd.pss.cfuSsCount * 15);
               DLOG(0,0,"CFU current length is %d",len1);
               if(len1 > g_MmConfigReaderObj->m_IsdLen)
               {
                  DLOG(0,0,"Length limit exceeded on adding CFU CFWD info");
                  l_isd.count -= 1;
                  m_isd.pss.CFWD_STATE = provisionedSS::CFWD_UNCON;
                  if(m_isd.pss.val == 0)
                     return 1;
                  else
                     return 2;
                  break;
               }
               else
               {
                  DLOG(0,0,"CFU Added,moving to CFB");
                  m_isd.pss.CFWD_STATE = provisionedSS::CFWD_BUSY;
                  l_len = len1;
                  m_isd.pss.val += 1;
               }
            }
         }
         //break;
      case provisionedSS::CFWD_BUSY:
         {
            if(m_isd.pss.cfbSsCode)
            {
               DLOG(0,0,"SS Count after adding CFB = %d",m_isd.pss.val+1);
               l_isd.count = m_isd.pss.val+1;
               //m_isd.pss.formCfbSS1(DlgId,l_isd);
               m_isd.pss.formCfbSS1(l_isd);
               int len2 = l_len;
               len2 += 15 + (m_isd.pss.cfbSsCount * 20);
               //g_AsnCodecO1.getEncodingLength(OMAP1_InsertSubscriberDataArg_PDU, l_isd);
               DLOG(0,0,"Len after CFB is %d",len2);
               if(len2 > g_MmConfigReaderObj->m_IsdLen)
               {
                  DLOG(0,0,"Length limit exceeded on adding CFB CFWD info");
                  l_isd.count -= 1;
                  m_isd.pss.CFWD_STATE = provisionedSS::CFWD_BUSY;
                  if(m_isd.pss.val == 0)
                     return 1;
                  else
                     return 2;
                  break;
               }
               else
               {
                  DLOG(0,0,"CFB added, moving to CFNRC");
                  m_isd.pss.CFWD_STATE = provisionedSS::CFWD_NOTREACH;
                  l_len = len2;
                  m_isd.pss.val += 1;
               }
            }
         }
         //break;
      case provisionedSS::CFWD_NOTREACH:
         {
            if(m_isd.pss.cfnrcSsCode)
            {
               DLOG(0,0,"SS Count after adding CFNRC = %d",m_isd.pss.val+1);
               l_isd.count = m_isd.pss.val+1;
               //m_isd.pss.formCfnrcSS1(DlgId,l_isd);
               m_isd.pss.formCfnrcSS1(l_isd);
               int len3 = l_len;
               len3 += 15 + (m_isd.pss.cfnrcSsCount * 20);
               //g_AsnCodecO1.getEncodingLength(OMAP1_InsertSubscriberDataArg_PDU, l_isd)
               if(len3 > g_MmConfigReaderObj->m_IsdLen)
               {
                  DLOG(0,0,"Length limit exceeded on adding CFNRC CFWD info");
                  l_isd.count -= 1;
                  m_isd.pss.CFWD_STATE = provisionedSS::CFWD_NOTREACH;
                  if(m_isd.pss.val == 0)
                     return 1;
                  else
                     return 2;
                  break;
               }
               else
               {
                  DLOG(0,0,"CFNRC added, moving to CFNRY");
                  m_isd.pss.CFWD_STATE = provisionedSS::CFWD_NOREPLY;
                  l_len = len3;
                  m_isd.pss.val += 1;
               }
            }
         }
         //break;
      case provisionedSS::CFWD_NOREPLY:
         {
            if(m_isd.pss.cfnrySsCode)
            {
               DLOG(0,0,"SS Count after adding CFNRY = %d",m_isd.pss.val+1);
               l_isd.count = m_isd.pss.val+1;
               //m_isd.pss.formCfnrySS1(DlgId,l_isd);
               m_isd.pss.formCfnrySS1(l_isd);
               int len4 = l_len;
               len4 += 15 + (m_isd.pss.cfnrySsCount * 20);
               //g_AsnCodecO1.getEncodingLength(OMAP1_InsertSubscriberDataArg_PDU, l_isd)
               if(len4 > g_MmConfigReaderObj->m_IsdLen)
               {
                  DLOG(0,0,"Length limit exceeded on adding CFNRY CFWD info");
                  l_isd.count -= 1;
                  m_isd.pss.CFWD_STATE = provisionedSS::CFWD_NOREPLY;
                  if(m_isd.pss.val == 0)
                     return 1;
                  else
                     return 2;
                  break;
               }
               else
               {
                  DLOG(0,0,"CFNRY added, moving to CD");
                  m_isd.pss.CFWD_STATE = provisionedSS::CALL_DEF;
                  l_len = len4;
                  m_isd.pss.val += 1;
               }
            }
         }
         //break;
      case provisionedSS::CALL_DEF:
         {
            if(m_isd.pss.cdSsCode)
            {
               DLOG(0,0,"SS Count after adding CD = %d",m_isd.pss.val+1);
               l_isd.count = m_isd.pss.val+1;
               //m_isd.pss.formCdSS1(DlgId,l_isd);
               m_isd.pss.formCdSS1(l_isd);
               //g_AsnCodecO1.getEncodingLength(OMAP1_InsertSubscriberDataArg_PDU,l_isd)
               int len5 = l_len;
               len5 += 15 + (m_isd.pss.cdSsCount * 20);
               if(len5 > g_MmConfigReaderObj->m_IsdLen)
               {
                  DLOG(0,0,"Length limit exceeded on adding CD CFWD info");
                  l_isd.count -= 1;
                  m_isd.pss.CFWD_STATE = provisionedSS::CALL_DEF;
                  if(m_isd.pss.val == 0)
                     return 1;
                  else
                     return 2;
                  break;
               }
               else
               {
                  DLOG(0,0,"CD Added, all CFWD SS DATA Added");
                  m_isd.pss.CFWD_STATE = provisionedSS::DEF;
                  l_len = len5;
                  m_isd.pss.val += 1;
               }
            }
         }
         //break;
      default:
      case provisionedSS::DEF:
         return 0;
         //break;
   }
   return 0;
}

int CtxtUpdateLocation::sp_formCbSS1(int DlgId,OMAP1_SS_InfoList &l_isd, int p_isdLen)
{
   int l_len = p_isdLen;
   DLOG(0,0,"Inside Call Barring for Dialog Id %d,SS Count here is %d,boacCount = %d , boicCount = %d, boihcCount = %d ISD Length formed till now %d ",DlgId,m_isd.pss.val,m_isd.pss.boacCount,m_isd.pss.boicCount,m_isd.pss.boihcCount,l_len);
   switch(m_isd.pss.CB_STATE)
   {
      case provisionedSS::CB_BOAC:
         {
            if(m_isd.pss.boacSsCode)
            {
               DLOG(0,0,"SS Count after adding BOAC = %d",m_isd.pss.val+1);
               l_isd.count = m_isd.pss.val+1;
               //m_isd.pss.formboaSS1(DlgId,l_isd);
               m_isd.pss.formboaSS1(l_isd);
               int len6 = l_len;
               len6 += 7 + 3 + 3 + (m_isd.pss.boacCount * 10);
               DLOG(0,0,"BOAC count is %d ISD len %d",l_isd.value[l_isd.count - 1].u.callBarringInfo.callBarringFeatureList.count,len6);
               if(len6 >= g_MmConfigReaderObj->m_IsdLen)
               {
                  DLOG(0,0,"Length limit exceeded on adding BOAC CB info");
                  l_isd.count -= 1;
                  m_isd.pss.CB_STATE = provisionedSS::CB_BOAC;
                  if(m_isd.pss.val == 0)
                     return 1;
                  else
                     return 2;
                  break;
               }
               else
               {
                  DLOG(0,0,"Added BOAC CB info, moving to BOIC");
                  m_isd.pss.CB_STATE = provisionedSS::CB_BOIC;
                  m_isd.pss.val += 1;
                  l_len = len6;
               }
            }
         }
         //break;
      case provisionedSS::CB_BOIC:
         {
            if(m_isd.pss.boicSsCode)
            {
               DLOG(0,0,"SS Count after adding BOIC = %d",m_isd.pss.val+1);
               l_isd.count = m_isd.pss.val+1;
               //m_isd.pss.formboicSS1(DlgId,l_isd);
               m_isd.pss.formboicSS1(l_isd);
               int len7 = l_len;
               len7 += 13 + (m_isd.pss.boicCount * 10);
               DLOG(0,0,"BOAC count is %d ISD len %d",l_isd.value[l_isd.count - 1].u.callBarringInfo.callBarringFeatureList.count,len7);
               if(len7 >= g_MmConfigReaderObj->m_IsdLen)
               {
                  DLOG(0,0,"Length limit exceeded on adding BOIC CB info");
                  l_isd.count -= 1;
                  m_isd.pss.CB_STATE = provisionedSS::CB_BOIC;
                  if(m_isd.pss.val == 0)
                     return 1;
                  else
                     return 2;
                  break;
               }
               else
               {
                  DLOG(0,0,"Added BOIC CB info, moving to BOIHC");
                  m_isd.pss.CB_STATE = provisionedSS::CB_BOIHC;
                  m_isd.pss.val += 1;
                  l_len = len7;
               }
            }
         }
         //break;
      case provisionedSS::CB_BOIHC:
         {
            if(m_isd.pss.boihcSsCode)
            {
               DLOG(0,0,"SS Count after adding BOIHC = %d",m_isd.pss.val+1);
               l_isd.count = m_isd.pss.val+1;
               //m_isd.pss.formboihcSS1(DlgId,l_isd);
               m_isd.pss.formboihcSS1(l_isd);
               int len8 = l_len;
               len8 += 13+ (m_isd.pss.boihcCount * 10);
               //g_AsnCodecO1.getEncodingLength(OMAP1_InsertSubscriberDataArg_PDU,l_isd)
               DLOG(0,0,"BOAC count is %d ISD len %d",l_isd.value[l_isd.count - 1].u.callBarringInfo.callBarringFeatureList.count,len8);
               if(len8 > g_MmConfigReaderObj->m_IsdLen)
               {
                  DLOG(0,0,"Length limit exceeded on adding BOIHC CB info");
                  l_isd.count -= 1;
                  m_isd.pss.CB_STATE = provisionedSS::CB_BOIHC;
                  if(m_isd.pss.val == 0)
                     return 1;
                  else
                     return 2;
                  break;
               }
               else
               {
                  DLOG(0,0,"Added BOIHC CB info, moving to BAIC");
                  m_isd.pss.CB_STATE = provisionedSS::DEFA;
                  m_isd.pss.val += 1;
               }
            }
         }
         //break;
      case provisionedSS::DEFA:
      default:
         return 0;
         break;
   }
   return 0;
}

int CtxtUpdateLocation::sp_formSsSS1(int DlgId,OMAP1_SS_InfoList &l_isd, int p_isdLen)
{
   int prevVal = l_isd.count;
   m_isd.pss.val = l_isd.count;
   DLOG(0,0,"Inside formSsSS1, DlgId: [%d] SS Count here is [%d],storing it as prevVal [%d], ISD length formed till now [%d]",DlgId,m_isd.pss.val,prevVal,p_isdLen);
   //int l_count = m_isd.pss.formGenSS1(DlgId,l_isd);
   int l_count = m_isd.pss.formGenSS1(l_isd);
   DLOG(0,0,"SS Count after adding SS DATA is  %d",l_count);
   int len2 = p_isdLen + 10 + (l_count * 6);
   //g_AsnCodecO1.getEncodingLength(OMAP1_InsertSubscriberDataArg_PDU,l_isd);
   if(len2 >= g_MmConfigReaderObj->m_IsdLen)
   {
      DLOG(0,0,"Length limit exeeded to %d while adding GEN_SS, Removing till prevVal %d",len2,prevVal);
      if(prevVal != l_isd.count)
      {
      l_isd.count = prevVal;
      return 2;      
      }
      else
      {
         return 0;
      }
   }
   else
   {
      DLOG(0,0,"Length limit not exeeded after adding SS data");
      //m_SdLen = len2;
      return 0;
   }
}




