/*******************************************************************************************
 * File        : SgsnCamelSubsinfo.cpp
 * Author      : VenkatRaman
 * Description : To retrieve and add SGSN Camel Subscription Infromation from DB to ISD arg
 * Created on April 30, 2010, 10:00 AM IST
 *******************************************************************************************/

#include <stdio.h>
#include <SgsnCamelSubsinfo.h>
#include <ISDData.h>
#include <Logger.h>
#include <MmConfigReader.h>
#include <DbQueryMsg.h>
#include <DbActiveObject.h>
#include <CommonDefines.h>
#include <SubsProfileData.h>
#include <SubsProfilesManager.h>
#include <Utilities.h>



SgsnCamelSubsinfo::SgsnCamelSubsinfo()
{
   DLOG(0,0,"SgsnCamelSubsinfo Cons");
   memset(&scsi,'\0',sizeof(scsi));
   l_OutScfAddrLen = 0;
}

SgsnCamelSubsinfo::~SgsnCamelSubsinfo()
{
   DLOG(0,0,"SgsnCamelSubsinfo Des");
}

bool SgsnCamelSubsinfo::ValidateAllCsi(int DlgId,int PdpprofileId,int GprscsiPid,int MosmscsiPid,int MtsmscsiPid)
{
   LLOG(0,0,"Validating All CSI for dialogId %d, for PDP Profile ID %d,GPRSCSI Pid %d, MOSMSCSI Pid %d,MTSMSCSI Pid %d",DlgId,PdpprofileId,GprscsiPid,MosmscsiPid,MtsmscsiPid);
   if(PdpprofileId)
   {
      map<u16,PDP*>::iterator l_pdpItr;
      l_pdpItr = g_spdPtr->m_PDPMap.find(PdpprofileId);
      if(l_pdpItr == g_spdPtr->m_PDPMap.end())
      {
         CLOG(0,0,"PDP profileID |%d| not found in map.. ",PdpprofileId);
         return false;
      }
      else
      {
         PDP *lpPdp = l_pdpItr->second;
         if(lpPdp == NULL)
         {
            ELOG(0,0,"Null values in PDP MAP for profileID |%d| ..",PdpprofileId);
            return false;
         }
      }
   }
   if(GprscsiPid)
   {
      DLOG(0,0,"Checking GPRS CSI profile");
      map<u16,GPRSCSI*>::iterator l_gcsiItr;
      l_gcsiItr = g_spdPtr->m_GPRSCSIMap.find(GprscsiPid);
      if(l_gcsiItr == g_spdPtr->m_GPRSCSIMap.end())
      {
         CLOG(0,0,"GPRS_CSI profileID |%d| not found in map.. ",GprscsiPid);
         return false;
      }
      else
      {
         GPRSCSI *lpGcsi = l_gcsiItr->second;
         if(lpGcsi == NULL)
         {
            ELOG(0,0,"Null values in GPRSCSI MAP for profileID |%d| ..",GprscsiPid);
            return false;
         }
      }
   }
   if(MosmscsiPid)
   {
      DLOG(0,0,"Checking MOSMS CSI profile");
      map<u16,MOSMSCSI*>::iterator l_mosmscsiItr;
      l_mosmscsiItr = g_spdPtr->m_MOSMSCSIMap.find(MosmscsiPid);
      if(l_mosmscsiItr == g_spdPtr->m_MOSMSCSIMap.end())
      {
         CLOG(0,0,"MOSMS_CSI profileID |%d| not found in map.. ",MosmscsiPid);
         return false;
      }
      else
      {
         MOSMSCSI *lpMosmscsi = l_mosmscsiItr->second;
         if(lpMosmscsi == NULL)
         {
            ELOG(0,0,"Null values in MOSMSCSI MAP for profileID |%d| ..",MosmscsiPid);
            return false;
         }
      }
   }
   if(MtsmscsiPid)
   {
      DLOG(0,0,"Checking MTSMS CSI profile");
      map<u16,MTSMSCSI*>::iterator l_mtsmscsiItr;
      l_mtsmscsiItr = g_spdPtr->m_MTSMSCSIMap.find(MtsmscsiPid);
      if(l_mtsmscsiItr == g_spdPtr->m_MTSMSCSIMap.end())
      {
         CLOG(0,0,"MTSMS_CSI profileID |%d| not found in map.. ",MtsmscsiPid);
         return false;
      }
      else
      {
         MTSMSCSI *lpMtsmscsi = l_mtsmscsiItr->second;
         if(lpMtsmscsi == NULL)
         {
            ELOG(0,0,"Null values in MTSMSCSI MAP for profileID |%d| ..",MtsmscsiPid);
            return false;
         }
      }
   }
   return true;
}

//void SgsnCamelSubsinfo::formGprsCsi(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd)
void SgsnCamelSubsinfo::formGprsCsi(OMAP3_InsertSubscriberDataArg *l_isd)
{
   DLOG(0,0,"Received GPRS CSI profile ID as %d",scsi.gcsi);
   if(scsi.gcsi)
   {
      DLOG(0,0,"Adding GPRS CSI in SGSN Camel Subscription information");        
      int gpid = scsi.gcsi;
      bool l_GcsiPresent = false;
      map<u16,GPRSCSI*>::iterator l_gcsiItr;
      l_gcsiItr = g_spdPtr->m_GPRSCSIMap.find(gpid);
      l_GcsiPresent = true;
      if(l_GcsiPresent)
      {
         GPRSCSI *l_gcsi = l_gcsiItr->second;
         if((l_gcsi->m_csiState == 1) && (l_gcsi->m_camelCapability >=3) )
         {
            l_isd->sgsn_CAMEL_SubscriptionInfo.bit_mask |= OMAP3_SGSN_CAMEL_SubscriptionInfo_gprs_CSI_present;

            l_isd->sgsn_CAMEL_SubscriptionInfo.gprs_CSI.bit_mask = 0;//Max no. of service Keys for 1,2,11,12 and 14
            l_isd->sgsn_CAMEL_SubscriptionInfo.gprs_CSI.bit_mask |= OMAP3_gprs_CamelTDPDataList_present;
            l_isd->sgsn_CAMEL_SubscriptionInfo.gprs_CSI.gprs_CamelTDPDataList.count = 0;
            int gcsk = 0;
            for(int gg = 0;gg < 5;gg++)
            {
               u32 l_NetworkServiceKey = g_spdPtr->getNetworkServiceKey(scsi.nwId,l_gcsi->m_serviceKey[gg]);
               if(l_gcsi->m_serviceKey[gg])
               {
                  DLOG(0,0,"GPRS Service Key %d present",l_gcsi->m_serviceKey[gg]);
                  //GPRSServiceKey *p_gServiceKey = g_spdPtr->m_GPRSServiceKeyMap[l_gcsi->m_serviceKey[gg]];
                  GPRSServiceKey *p_gServiceKey = g_spdPtr->getGprsServiceKeyPtr(scsi.nwId,l_gcsi->m_serviceKey[gg]);
                  LLOG(0,0,"GPRS Service key TDP %d",p_gServiceKey->m_bcsmTDP);
                  l_isd->sgsn_CAMEL_SubscriptionInfo.gprs_CSI.bit_mask |= OMAP3_gprs_CamelTDPDataList_present;
                  l_isd->sgsn_CAMEL_SubscriptionInfo.gprs_CSI.gprs_CamelTDPDataList.count++;
                  l_isd->sgsn_CAMEL_SubscriptionInfo.gprs_CSI.gprs_CamelTDPDataList.value[gcsk].gprs_TriggerDetectionPoint = (OMAP3_GPRS_TriggerDetectionPoint)p_gServiceKey->m_bcsmTDP;
                  if(l_NetworkServiceKey == l_gcsi->m_serviceKey[gg])
                  {
                     LLOG(0,0,"GPRS_CSI: Sending ServiceKey |%d|",l_gcsi->m_serviceKey[gg]);
                     l_isd->sgsn_CAMEL_SubscriptionInfo.gprs_CSI.gprs_CamelTDPDataList.value[gcsk].serviceKey = (OMAP3_ServiceKey)l_gcsi->m_serviceKey[gg];
                  }
                  else
                  {
                     LLOG(0,0,"GPRS_CSI: Sending Network Specific ServiceKey |%d|",l_NetworkServiceKey);
                     l_isd->sgsn_CAMEL_SubscriptionInfo.gprs_CSI.gprs_CamelTDPDataList.value[gcsk].serviceKey = (OMAP3_ServiceKey)l_NetworkServiceKey;
                  }
                  u8 gsmscf1[20];
                  memset(gsmscf1, '\0',sizeof(gsmscf1));
                  strncat((char *)gsmscf1,"19",2);
                  if(scsi.PnwId)
                  {
                     if(NULL != getPartnerGsmScfAddr(p_gServiceKey->m_gsmScfAddr,l_OutScfAddrLen,scsi.nwId,scsi.PnwId))
                     {
                        u8 *Pgsmscf = (u8 *)getPartnerGsmScfAddr(p_gServiceKey->m_gsmScfAddr,l_OutScfAddrLen,scsi.nwId,scsi.PnwId);
                        strncat((char *)gsmscf1,(char *)Pgsmscf,strlen((char *)Pgsmscf));
                     }
                     else
                     {
                        strncat((char *)gsmscf1,(char *)p_gServiceKey->m_gsmScfAddr,strlen((char *)p_gServiceKey->m_gsmScfAddr));
                     }
                  }
                  else
                  {
                     strncat((char *)gsmscf1,(char *)p_gServiceKey->m_gsmScfAddr,strlen((char *)p_gServiceKey->m_gsmScfAddr));
                  }
                  LLOG(0,0,"Adding GSMSCF address %s",gsmscf1);
                  int len1 = strlen((char *)gsmscf1);
                  l_isd->sgsn_CAMEL_SubscriptionInfo.gprs_CSI.gprs_CamelTDPDataList.value[gcsk].gsmSCF_Address.length = (len1+1)/2;
                  StringToBCD(l_isd->sgsn_CAMEL_SubscriptionInfo.gprs_CSI.gprs_CamelTDPDataList.value[gcsk].gsmSCF_Address.value,gsmscf1,len1);
                  l_isd->sgsn_CAMEL_SubscriptionInfo.gprs_CSI.gprs_CamelTDPDataList.value[gcsk].defaultSessionHandling = (OMAP3_DefaultGPRS_Handling) p_gServiceKey->m_defGprsHandle;                    
               }
               gcsk++;
               DLOG(0,0,"Filled GPRS Service key count [%d]",gcsk);
            }
            LLOG(0,0,"GPRS_CSI CCH [%d] Rcvd CCH [%d]",l_gcsi->m_camelCapability,scsi.RcvdCamelPhase);
            if(l_gcsi->m_camelCapability)
            {
               l_isd->sgsn_CAMEL_SubscriptionInfo.gprs_CSI.bit_mask |= OMAP3_GPRS_CSI_camelCapabilityHandling_present;
               if(l_gcsi->m_camelCapability <= scsi.RcvdCamelPhase)
               {
                  l_isd->sgsn_CAMEL_SubscriptionInfo.gprs_CSI.camelCapabilityHandling = (OMAP3_CamelCapabilityHandling) l_gcsi->m_camelCapability;
               }
               else
               {
                  l_isd->sgsn_CAMEL_SubscriptionInfo.gprs_CSI.camelCapabilityHandling = (OMAP3_CamelCapabilityHandling)scsi.RcvdCamelPhase;
               }
            }
         }
      }
      else
      {
         ELOG(0,0,"GPRS CSI profile ID [%d] is NULL",gpid);            
      }
   }
   LLOG(0,0,"After GPRS CSI for SGSN Camel Subscription info");
   //return *l_isd;
}



//void SgsnCamelSubsinfo::formMosmsCsi(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd)
void SgsnCamelSubsinfo::formMosmsCsi(OMAP3_InsertSubscriberDataArg *l_isd)
{
   DLOG(0,0,"Received MO SMS CSI id %d",scsi.mosmscsi);
   if(scsi.mosmscsi)
   {
      LLOG(0,0,"Adding MO SMS CSI in SGSN Camel Subscription information");
      int mospid = scsi.mosmscsi;
      bool l_MosmscsiPresent = false;
      map<u16,MOSMSCSI*>::iterator l_mosmscsiItr;
      l_mosmscsiItr = g_spdPtr->m_MOSMSCSIMap.find(mospid);
         l_MosmscsiPresent = true;
      if(l_MosmscsiPresent)
      {                 
         MOSMSCSI *l_moscsi = l_mosmscsiItr->second; 
         DLOG(0,0,"CSI state of MOSMS CSI %d",l_moscsi->m_csiState);
         if(l_moscsi->m_csiState)
         {
            l_isd->sgsn_CAMEL_SubscriptionInfo.bit_mask |= OMAP3_SGSN_CAMEL_SubscriptionInfo_mo_sms_CSI_present;
            l_isd->sgsn_CAMEL_SubscriptionInfo.mo_sms_CSI.bit_mask = 0;

            SMSServiceKey *p_sServiceKey = g_spdPtr->getSmsServiceKeyPtr(scsi.nwId,l_moscsi->m_serviceKey);
            u32 l_NetworkServiceKey = g_spdPtr->getNetworkServiceKey(scsi.nwId,l_moscsi->m_serviceKey);

            l_isd->sgsn_CAMEL_SubscriptionInfo.mo_sms_CSI.bit_mask = OMAP3_sms_CAMEL_TDP_DataList_present;
            l_isd->sgsn_CAMEL_SubscriptionInfo.mo_sms_CSI.sms_CAMEL_TDP_DataList.count = 1;
            l_isd->sgsn_CAMEL_SubscriptionInfo.mo_sms_CSI.sms_CAMEL_TDP_DataList.value[0].sms_TriggerDetectionPoint = (OMAP3_SMS_TriggerDetectionPoint)p_sServiceKey->m_bcsmTDP;
            DLOG(0,0,"TDP %d",p_sServiceKey->m_bcsmTDP);
            if(l_NetworkServiceKey == l_moscsi->m_serviceKey)
            {
               LLOG(0,0,"MO_SMS_CSI Sending ServiceKey [%d]",l_moscsi->m_serviceKey);
               l_isd->sgsn_CAMEL_SubscriptionInfo.mo_sms_CSI.sms_CAMEL_TDP_DataList.value[0].serviceKey = l_moscsi->m_serviceKey;
            }
            else
            {
               LLOG(0,0,"MO_SMS_CSI Sending Network Specific ServiceKey [%d]",l_NetworkServiceKey);
               l_isd->sgsn_CAMEL_SubscriptionInfo.mo_sms_CSI.sms_CAMEL_TDP_DataList.value[0].serviceKey = l_NetworkServiceKey;
            }

            u8 gsmscf2[20];
            memset(gsmscf2, '\0',sizeof(gsmscf2));
            strncat((char *)gsmscf2,"19",2);
            if(scsi.PnwId)
            {
               if(NULL != getPartnerGsmScfAddr(p_sServiceKey->m_gsmScfAddr,l_OutScfAddrLen,scsi.nwId,scsi.PnwId))
               {
                  u8 *Pgsmscf = (u8 *)getPartnerGsmScfAddr(p_sServiceKey->m_gsmScfAddr,l_OutScfAddrLen,scsi.nwId,scsi.PnwId);
                  strncat((char *)gsmscf2,(char *)Pgsmscf,strlen((char *)Pgsmscf));
               }
               else
               {
                  strncat((char *)gsmscf2,(char *)p_sServiceKey->m_gsmScfAddr,strlen((char *)p_sServiceKey->m_gsmScfAddr));
               }
            }
            else
            {
               strncat((char *)gsmscf2,(char *)p_sServiceKey->m_gsmScfAddr,strlen((char *)p_sServiceKey->m_gsmScfAddr));
            }
            DLOG(0,0,"MOSMS CSI GsmScf addr %s",gsmscf2);
            int len2 = strlen((char *)gsmscf2);
            l_isd->sgsn_CAMEL_SubscriptionInfo.mo_sms_CSI.sms_CAMEL_TDP_DataList.value[0].gsmSCF_Address.length = (len2+1)/2;
            StringToBCD(l_isd->sgsn_CAMEL_SubscriptionInfo.mo_sms_CSI.sms_CAMEL_TDP_DataList.value[0].gsmSCF_Address.value,gsmscf2,len2);            
            l_isd->sgsn_CAMEL_SubscriptionInfo.mo_sms_CSI.sms_CAMEL_TDP_DataList.value[0].defaultSMS_Handling = (OMAP3_DefaultSMS_Handling)p_sServiceKey->m_defSmsHandle;
            if(l_moscsi->m_camelCapability)
            {
               l_isd->sgsn_CAMEL_SubscriptionInfo.mo_sms_CSI.bit_mask |= OMAP3_SMS_CSI_camelCapabilityHandling_present;
               l_isd->sgsn_CAMEL_SubscriptionInfo.mo_sms_CSI.camelCapabilityHandling = (OMAP3_CamelCapabilityHandling)l_moscsi->m_camelCapability;
            }
         }
      }
      else
      {
         ELOG(0,0,"g_spdPtr->g_MOSMSCSIMap[%d] is NULL",mospid);          
      }
   }

   DLOG(0,0,"After MO SMS CSI for SGSN Camel Subscription info");
   //return *l_isd;
}

//void SgsnCamelSubsinfo::formMtsmsCsi(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd)
void SgsnCamelSubsinfo::formMtsmsCsi(OMAP3_InsertSubscriberDataArg *l_isd)
{
   DLOG(0,0,"Received MT SMS CSI id %d",scsi.mtsmscsi);
   if(scsi.mtsmscsi)
   {
      DLOG(0,0,"Adding MT SMS CSI in SGSN Camel Subscription information");        
      int mtspid = scsi.mtsmscsi;
      bool l_MtsmscsiPresent = false;
      map<u16,MTSMSCSI*>::iterator l_MtsmscsiItr;
      l_MtsmscsiItr = g_spdPtr->m_MTSMSCSIMap.find(mtspid);
      if(l_MtsmscsiItr == g_spdPtr->m_MTSMSCSIMap.end())
      {
         CLOG(0,0,"MTSMS_CSI profileID |%d| not found in map.. ",mtspid);
         l_MtsmscsiPresent = false;
      }
      else
      {
         l_MtsmscsiPresent = true;
      }
      if(l_MtsmscsiPresent)
      {
         MTSMSCSI *l_mtscsi = l_MtsmscsiItr->second; 
         if(l_mtscsi->m_csiState)
         {
            l_isd->sgsn_CAMEL_SubscriptionInfo.bit_mask |= OMAP3_SGSN_CAMEL_SubscriptionInfo_mt_sms_CSI_present;
            l_isd->sgsn_CAMEL_SubscriptionInfo.mt_sms_CSI.bit_mask = 0;
            //SMSServiceKey *p_sServiceKey = g_spdPtr->m_SMSServiceKeyMap[l_mtscsi->m_serviceKey];
            SMSServiceKey *p_sServiceKey = g_spdPtr->getSmsServiceKeyPtr(scsi.nwId,l_mtscsi->m_serviceKey);
            u32 l_NetworkServiceKey = g_spdPtr->getNetworkServiceKey(scsi.nwId,l_mtscsi->m_serviceKey);
            if(l_mtscsi->m_serviceKey)
            {
               l_isd->sgsn_CAMEL_SubscriptionInfo.mt_sms_CSI.bit_mask = OMAP3_sms_CAMEL_TDP_DataList_present;
               l_isd->sgsn_CAMEL_SubscriptionInfo.mt_sms_CSI.sms_CAMEL_TDP_DataList.count = 1;
               l_isd->sgsn_CAMEL_SubscriptionInfo.mt_sms_CSI.sms_CAMEL_TDP_DataList.value[0].sms_TriggerDetectionPoint = (OMAP3_SMS_TriggerDetectionPoint)(p_sServiceKey->m_bcsmTDP);
               if(l_NetworkServiceKey == l_mtscsi->m_serviceKey)
               {
                  LLOG(0,0,"MT_SMS_CSI Sending ServiceKey [%d]",l_mtscsi->m_serviceKey);
                  l_isd->sgsn_CAMEL_SubscriptionInfo.mt_sms_CSI.sms_CAMEL_TDP_DataList.value[0].serviceKey = l_mtscsi->m_serviceKey;
               }
               else
               {
                  LLOG(0,0,"MT_SMS_CSI Sending Network Sepcific ServiceKey [%d]",l_NetworkServiceKey);
                  l_isd->sgsn_CAMEL_SubscriptionInfo.mt_sms_CSI.sms_CAMEL_TDP_DataList.value[0].serviceKey = l_NetworkServiceKey; 
               }

               u8 gsmscf3[21];
               memset(gsmscf3, '\0',sizeof(gsmscf3));
               strncat((char *)gsmscf3,"1",1);
               strncat((char *)gsmscf3,"9",1);
               if(scsi.PnwId)
               {
                  if(NULL != getPartnerGsmScfAddr(p_sServiceKey->m_gsmScfAddr,l_OutScfAddrLen,scsi.nwId,scsi.PnwId))
                  {
                     u8 *Pgsmscf = (u8 *)getPartnerGsmScfAddr(p_sServiceKey->m_gsmScfAddr,l_OutScfAddrLen,scsi.nwId,scsi.PnwId);
                     strncat((char *)gsmscf3,(char *)Pgsmscf,strlen((char *)Pgsmscf));
                  }
                  else
                  {
                     strncat((char *)gsmscf3,(char *)p_sServiceKey->m_gsmScfAddr,strlen((char *)p_sServiceKey->m_gsmScfAddr));
                  }
               }
               else
               {
                  strncat((char *)gsmscf3,(char *)p_sServiceKey->m_gsmScfAddr,strlen((char *)p_sServiceKey->m_gsmScfAddr));
               }
               int len3 = strlen((char *)gsmscf3);
               l_isd->sgsn_CAMEL_SubscriptionInfo.mt_sms_CSI.sms_CAMEL_TDP_DataList.value[0].gsmSCF_Address.length = (len3+1)/2;
               StringToBCD(l_isd->sgsn_CAMEL_SubscriptionInfo.mt_sms_CSI.sms_CAMEL_TDP_DataList.value[0].gsmSCF_Address.value,gsmscf3,len3);
               if(len3%2)
                  l_isd->sgsn_CAMEL_SubscriptionInfo.mt_sms_CSI.sms_CAMEL_TDP_DataList.value[0].gsmSCF_Address.value[((len3+1)/2) - 1] |= 0xF0;
               l_isd->sgsn_CAMEL_SubscriptionInfo.mt_sms_CSI.sms_CAMEL_TDP_DataList.value[0].defaultSMS_Handling = (OMAP3_DefaultSMS_Handling)p_sServiceKey->m_defSmsHandle;
               DLOG(0,0,"Added SK for MTSMS CSI time\n");
            }
            if(l_mtscsi->m_camelCapability)
            {
               l_isd->sgsn_CAMEL_SubscriptionInfo.mt_sms_CSI.bit_mask |= OMAP3_SMS_CSI_camelCapabilityHandling_present;
               l_isd->sgsn_CAMEL_SubscriptionInfo.mt_sms_CSI.camelCapabilityHandling = (OMAP3_CamelCapabilityHandling)l_mtscsi->m_camelCapability;
            }          
         }
      }
      else
      {
         ELOG(0,0,"g_spdPtr->g_MTSMSCSIMap[%d]",mtspid);            
      }
   }
   DLOG(0,0,"After MT SMS CSI for SGSN Camel Subscription info");
   //return *l_isd;
}

//void SgsnCamelSubsinfo::formMtcritList(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd)
void SgsnCamelSubsinfo::formMtcritList(OMAP3_InsertSubscriberDataArg *l_isd)
{       
   DLOG(0,0,"Received MT SMS CSI id %d",scsi.mtsmscsi);
   if(scsi.mtsmscsi)
   {
      DLOG(0,0,"Adding MT SMS TDP Criteria in SGSN Camel Subscription information");        
      int mtspid = scsi.mtsmscsi;
      bool l_MtsmscsiPresent = false;
      map<u16,MTSMSCSI*>::iterator l_MtsmscsiItr;
      l_MtsmscsiItr = g_spdPtr->m_MTSMSCSIMap.find(mtspid);
      if(l_MtsmscsiItr == g_spdPtr->m_MTSMSCSIMap.end())
      {
         CLOG(0,0,"MTSMS_CSI profileID |%d| not found in map.. ",mtspid);
         l_MtsmscsiPresent = false;
      }
      else
      {
         l_MtsmscsiPresent = true;
      }
      if(l_MtsmscsiPresent)
      {
         MTSMSCSI *l_mtscsi =  l_MtsmscsiItr->second;
         if(l_mtscsi->m_csiState)
         {
            l_isd->sgsn_CAMEL_SubscriptionInfo.bit_mask |= OMAP3_SGSN_CAMEL_SubscriptionInfo_mt_smsCAMELTDP_CriteriaList_present;
            l_isd->sgsn_CAMEL_SubscriptionInfo.mt_smsCAMELTDP_CriteriaList.count = 1;
            //SMSServiceKey *p_sServiceKey = g_spdPtr->m_SMSServiceKeyMap[l_mtscsi->m_serviceKey];
            SMSServiceKey *p_sServiceKey = g_spdPtr->getSmsServiceKeyPtr(scsi.nwId,l_mtscsi->m_serviceKey);
            l_isd->sgsn_CAMEL_SubscriptionInfo.mt_smsCAMELTDP_CriteriaList.value[0].sms_TriggerDetectionPoint = (OMAP3_SMS_TriggerDetectionPoint)(p_sServiceKey->m_bcsmTDP);
            l_isd->sgsn_CAMEL_SubscriptionInfo.mt_smsCAMELTDP_CriteriaList.value[0].bit_mask = OMAP3_tpdu_TypeCriterion_present;
            l_isd->sgsn_CAMEL_SubscriptionInfo.mt_smsCAMELTDP_CriteriaList.value[0].tpdu_TypeCriterion.count = 1;
            l_isd->sgsn_CAMEL_SubscriptionInfo.mt_smsCAMELTDP_CriteriaList.value[0].tpdu_TypeCriterion.value[0] = (OMAP3_MT_SMS_TPDU_Type) p_sServiceKey->m_TPDU_TypeCrit;
         }
      }
      else
      {
         ELOG(0,0,"g_spdPtr->g_MTSMSCSIMap[%d] is NULL",mtspid);            
      }
   }
   DLOG(0,0,"After MT SMS TDP Criteria list for SGSN Camel Subscription info,returning back");
   //return *l_isd;
}

#if 0
void SgsnCamelSubsinfo::formMgCsi(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd)
{    
   /*DLOG(0,0,"Received MGCSI state as %d",scsi.gcsi);
     if(scsi.mgcsi)
     {
     DLOG(0,0,"Adding MT SMS TDP Criteria in SGSN Camel Subscription information for Dialog ID %d",DlgId);        
     int mgpid = scsi.mgcsi;
     if(NULL != g_spdPtr->g_MGCSIMap[mgpid])
     {
     MGCSI *l_mgcsi = g_spdPtr->g_MGCSIMap[mgpid];
     if(l_mgcsi->m_csiState)
     {
     l_isd->sgsn_CAMEL_SubscriptionInfo.bit_mask |= OMAP3_SGSN_CAMEL_SubscriptionInfo_mg_csi_present;
     l_isd->sgsn_CAMEL_SubscriptionInfo.mg_csi.bit_mask = 0;
     l_isd->sgsn_CAMEL_SubscriptionInfo.mg_csi.mobilityTriggers.count = 1;
     l_isd->sgsn_CAMEL_SubscriptionInfo.mg_csi.mobilityTriggers.value[0].length = 1;
     l_isd->sgsn_CAMEL_SubscriptionInfo.mg_csi.mobilityTriggers.value[0].value[0] = 0x91;
     l_isd->sgsn_CAMEL_SubscriptionInfo.mg_csi.serviceKey = l_mgcsi->mgcsisk;

     u8 gsmscf4[20];
     memset(gsmscf4, '\0',sizeof(gsmscf4));
     strncat((char *)gsmscf4,"1",1);
     strncat((char *)gsmscf4,"9",1);
     if(scsi.PnwId)
     {
     if(NULL != getPartnerGsmScfAddr(l_mgcsi->m_gsmScfAddr,l_OutScfAddrLen,scsi.nwId,scsi.PnwId))
     {
     u8 *Pgsmscf = (u8 *)getPartnerGsmScfAddr(l_mgcsi->m_gsmScfAddr,l_OutScfAddrLen,scsi.nwId,scsi.PnwId);
     strncat((char *)gsmscf4,(char *)Pgsmscf,strlen((char *)Pgsmscf));
     }
     else
     {
     strcat((char *)gsmscf4,(char *)l_mgcsi->m_gsmscfAddr,strlen((char *)l_mgcsi->m_gsmscfAddr));
     }
     }
     else
     {
     strcat((char *)gsmscf4,(char *)l_mgcsi->m_gsmscfAddr,strlen((char *)l_mgcsi->m_gsmscfAddr));
     }
     int len4 = strlen((char *)gsmscf4);
     l_isd->sgsn_CAMEL_SubscriptionInfo.mg_csi.gsmSCF_Address.length = len4+1/2;
     StringToBCD(l_isd->sgsn_CAMEL_SubscriptionInfo.mg_csi.gsmSCF_Address.value,gsmscf4,len4);
   //l_isd->sgsn_CAMEL_SubscriptionInfo.mg_csi.bit_mask = OMAP3_MG_CSI_extensionContainer_present;
   //l_isd->sgsn_CAMEL_SubscriptionInfo.mg_csi.bit_mask = OMAP3_MG_CSI_notificationToCSE_present;
   //l_isd->sgsn_CAMEL_SubscriptionInfo.mg_csi.bit_mask = OMAP3_MG_CSI_csi_Active_present;
   }
   }
   else
   {
   ELOG(0,0,"g_spdPtr->g_MGCSIMap[%d] is NULL",mgpid);            
   }
   }
   DLOG(0,0,"Finished adding MGCSI for SGSN Camel Subscription info");*/    
}
#endif

s8* SgsnCamelSubsinfo::getPartnerGsmScfAddr(s8 * aGsmScfAddr,u16 &aOutScfAddrLen,u16 aNkId,u16 aPnkId)
{
   char l_tempArr[100];
   memset(l_tempArr,'\0',sizeof(l_tempArr));
   DLOG(0,0,"Nw id is %d",aNkId);
   aNkId += 100;
   //aNkId = 101;
   sprintf(l_tempArr,"%d%04d%s",aNkId,aPnkId,aGsmScfAddr);

   DLOG(0,0," tempArr in getPartnerGsmScfAddr %s",l_tempArr);

   long double key = strtold(l_tempArr,NULL);
   map<long double,s8*> :: iterator rpiter = g_spdPtr->m_RPMap.find(key);
   if(rpiter != g_spdPtr->m_RPMap.end())
   {
      LLOG(0,0,"PARTNER GSMSCFADDR MATCH FOUND ");
      aOutScfAddrLen = strlen(rpiter->second);
      return rpiter->second;
   }
   else
   {
      WLOG(0,0," PARTNER GSMSCF ADDRESS NOT FOUND returning NULL");
      return NULL;
   }
}




/* else
   {
   DLOG(0,0,"No data to add for SGSN Camel Subscription Info, returning back");
   return *l_isd;
   }*/


