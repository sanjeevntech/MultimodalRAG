/*******************************************************************************
 * File        : provisionedSS.cpp
 * Author      : VenkatRaman
 * Description : To add SS info list from DB to ISD arg
 * Created on April 22, 2010, 3:00 PM IST
 *******************************************************************************/

#include <stdio.h>
#include <ProvisionedSS.h>
#include <Logger.h>
#include <MmConfigReader.h>
#include <AsnCodec.h>
#include <Utilities.h>
#include <CommonDefines.h>

extern AsnCodec g_AsnCodecO3;
extern AsnCodec g_AsnCodecO2;
extern AsnCodec g_AsnCodecO1;


provisionedSS::provisionedSS()
{
   DLOG(0,0,"provisionedSS Cons");
   m_GenSsCount = 0;
   cfuSsCode = cfuSsCount =0;
   cdSsCode = cdSsCount = 0;
   cfbSsCode = cfbSsCount = 0;
   cfnrySsCode = cfnrySsCount =0;
   cfnrcSsCode = cfnrcSsCount = 0;
   boacSsCode = boacCount = 0;
   boicSsCode = boicCount = 0;
   boihcSsCode = boihcCount = 0;
   SsCount = 0;
   ESsCode  = ESsStatus = EDefaultPriority = EMaxPriority = 0;
   mcSsCode = MCSsStatus = NBR_SB = NBR_USER = 0;
   val = 0;
   CFWD_STATE = (provisionedSS::CFWD)0;
   CB_STATE = (provisionedSS::CB)0;
   for(int i = 0; i < MAX_CFWD_DATA; i++)
   {
      cfuSsStatus[i] = cfuBCode[i] = cfuBType[i] = cfuOPTN[i] = cfuNRT[i] = 0;
      memset(cfuFTN[i],'\0',sizeof(cfuFTN[i]));
      memset(cfuFTS[i],'\0',sizeof(cfuFTS[i]));
      memset(cfuLFTN[i],'\0',sizeof(cfuLFTN[i]));
      cfnrcSsStatus[i] = cfnrcBCode[i] = cfnrcBType[i] = cfnrcOPTN[i] = cfnrcNRT[i] = 0;
      memset(cfnrcFTN[i],'\0',sizeof(cfnrcFTN[i]));
      memset(cfnrcFTS[i],'\0',sizeof(cfnrcFTS[i]));
      memset(cfnrcLFTN[i],'\0',sizeof(cfnrcLFTN[i]));
      cfnrySsStatus[i] = cfnryBCode[i] = cfnryBType[i] = cfnryOPTN[i] = cfnryNRT[i] = 0;
      memset(cfnryFTN[i],'\0',sizeof(cfnryFTN[i]));
      memset(cfnryFTS[i],'\0',sizeof(cfnryFTS[i]));
      memset(cfnryLFTN[i],'\0',sizeof(cfnryLFTN[i]));
      cfbSsStatus[i] = cfbBCode[i] = cfbBType[i] = cfbOPTN[i] = cfbNRT[i] = 0;
      memset(cfbFTN[i],'\0',sizeof(cfbFTN[i]));
      memset(cfbFTS[i],'\0',sizeof(cfbFTS[i]));
      memset(cfbLFTN[i],'\0',sizeof(cfbLFTN[i]));
      cdSsStatus[i] = cdBCode[i] = cdBType[i] = cdOPTN[i] = cdNRT[i] = 0;
      memset(cdFTN[i],'\0',sizeof(cdFTN[i]));
      memset(cdFTS[i],'\0',sizeof(cdFTS[i]));
      memset(cdLFTN[i],'\0',sizeof(cdLFTN[i]));

   }

   m_AllOGCallsBarresPresent = false;
}

provisionedSS::~provisionedSS()
{
   DLOG(0,0,"provisionedSS Des");
}


//Start MAP3
//int provisionedSS::formFwdSS3(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd, int p_isdLen)
int provisionedSS::formFwdSS3(OMAP3_InsertSubscriberDataArg *l_isd)
{
   int p_isdLen = g_MmConfigReaderObj->m_IsdLen;
   DLOG(0,0,"Call forwarding SS, Count filled till is %d, cfuSsCount = %d,cdSsCount = %d,cfbSsCount = %d,cfnrySsCount = %d,cfnrcSsCount = %d",l_isd->provisionedSS.count,cfuSsCount,cdSsCount,cfbSsCount,cfnrySsCount,cfnrcSsCount);
   //int retVal=-1;
   switch(CFWD_STATE)
   {
      case CFWD_UNCON:
         {
            if(cfuSsCode)
            {
               DLOG(0,0,"CFU SS count = %d",val+1);
               l_isd->provisionedSS.count = val+1;
               //formCfuSS3(DlgId,l_isd);
               formCfuSS3(l_isd);
               int len1 = g_AsnCodecO3.getEncodingLength(OMAP3_InsertSubscriberDataArg_PDU, l_isd);
               DLOG(0,0,"CFU get encoding length is %d",len1);
               if(len1 > p_isdLen)
               {
                  DLOG(0,0,"Length limit exeeded on adding CFU");
                  l_isd->provisionedSS.count -= 1;
                  CFWD_STATE = CFWD_UNCON;
                  if(val == 0)
                     return 1;
                  else
                     return 2;
                  break;
               }
               else
               {
                  DLOG(0,0,"CFU Added,moving to CFB");
                  CFWD_STATE = CFWD_BUSY;
                  val += 1;
               }
            }
         }
         //break;
      case CFWD_BUSY:
         {
            if(cfbSsCode)
            {
               DLOG(0,0,"CFB SS count = %d",val+1);
               l_isd->provisionedSS.count = val+1;
               //formCfbSS3(DlgId,l_isd);
               formCfbSS3(l_isd);
               //fillFwdSS3(DlgId,l_isd,cfbSsCode,cfbSsStatus,cfbSsCount, cfbBCode, cfbBType, cfbFTN, cfbFTS, cfbOPTN, cfbLFTN);
               int len2 = g_AsnCodecO3.getEncodingLength(OMAP3_InsertSubscriberDataArg_PDU, l_isd);
               DLOG(0,0,"Len after CFB is %d",len2);
               if(len2 > p_isdLen)
               {
                  DLOG(0,0,"Length limit exeeded on adding CFB");
                  l_isd->provisionedSS.count -= 1;
                  CFWD_STATE = CFWD_BUSY;
                  if(val == 0)
                     return 1;
                  else
                     return 2;
                  break;
               }
               else
               {
                  DLOG(0,0,"CFB added, moving to CFNRC");
                  CFWD_STATE = CFWD_NOTREACH;
                  val += 1;
               }
            }
         }
         //break;
      case CFWD_NOTREACH:
         {
            if(cfnrcSsCode)
            {
               DLOG(0,0,"CFNRC SS count = %d",val+1);
               l_isd->provisionedSS.count = val+1;
               //formCfnrcSS3(DlgId,l_isd);
               formCfnrcSS3(l_isd);
               //fillFwdSS3(DlgId,l_isd,cfnrcSsCode,cfnrcSsStatus,cfnrcSsCount, cfnrcBCode, cfnrcBType, cfnrcFTN, cfnrcFTS, cfnrcOPTN, cfnrcLFTN);
               if(g_AsnCodecO3.getEncodingLength(OMAP3_InsertSubscriberDataArg_PDU, l_isd) > p_isdLen)
               {
                  DLOG(0,0,"Length limit exeeded on adding CFNRC ");
                  l_isd->provisionedSS.count -= 1;
                  CFWD_STATE = CFWD_NOTREACH;
                  if(val == 0)
                     return 1;
                  else
                     return 2;
                  break;
               }
               else
               {
                  DLOG(0,0,"CFNRC added, moving to CFNRY");
                  CFWD_STATE = CFWD_NOREPLY;
                  val += 1;
               }
            }
         }
         //break;
      case CFWD_NOREPLY:
         {
            if(cfnrySsCode)
            {
               DLOG(0,0,"CFNRY SS count value is %d",val+1);
               l_isd->provisionedSS.count = val+1;
               //formCfnrySS3(DlgId,l_isd);
               formCfnrySS3(l_isd);
               //fillFwdSS3(DlgId,l_isd,cfnrySsCode,cfnrySsStatus,cfnrySsCount, cfnryBCode, cfnryBType, cfnryFTN, cfnryFTS, cfnryOPTN, cfnryLFTN);
               if(g_AsnCodecO3.getEncodingLength(OMAP3_InsertSubscriberDataArg_PDU, l_isd) > p_isdLen)
               {
                  DLOG(0,0,"length limit exeeded an adding CFNRY ");
                  l_isd->provisionedSS.count -= 1;
                  CFWD_STATE = CFWD_NOREPLY;
                  if(val == 0)
                     return 1;
                  else
                     return 2;
                  break;
               }
               else
               {
                  DLOG(0,0,"CFNRY added, moving to CD");
                  CFWD_STATE = CALL_DEF;
                  val += 1;
               }
            }
         }
         //break;
      case CALL_DEF:
         {
            if(cdSsCode)
            {
               DLOG(0,0,"CD SS count value is %d",val+1);
               l_isd->provisionedSS.count = val+1;
               //formCdSS3(DlgId,l_isd);
               formCdSS3(l_isd);
               //fillFwdSS3(DlgId,l_isd,cdSsCode,cdSsStatus,cdSsCount, cdBCode, cdBType, cdFTN, cdFTS, cdOPTN, cdLFTN);
               if(g_AsnCodecO3.getEncodingLength(OMAP3_InsertSubscriberDataArg_PDU,l_isd) > p_isdLen)
               {
                  DLOG(0,0,"CD length limit exeeded");
                  l_isd->provisionedSS.count -= 1;
                  CFWD_STATE = CALL_DEF;
                  if(val == 0)
                     return 1;
                  else
                     return 2;
                  break;
               }
               else
               {
                  DLOG(0,0,"CD Added,End of CFWD SS");
                  CFWD_STATE = DEF;
                  val += 1;
               }
            }
         }
         //break;
      default:
      case DEF:
         return 0;
         //break;
   }
   return 0;
   DLOG(0,0,"SS Count added is %d",l_isd->provisionedSS.count);
}

//int provisionedSS::formCbSS3(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd, int p_isdLen)
int provisionedSS::formCbSS3(OMAP3_InsertSubscriberDataArg *l_isd)
{
   DLOG(0,0,"Inside Call Barring SS, boacCount = %d , boicCount = %d, boihcCount = %d ",boacCount,boicCount,boihcCount);
   int p_isdLen = g_MmConfigReaderObj->m_IsdLen;
   switch(CB_STATE)
   {
      case CB_BOAC:
         {
            if(boacSsCode)
            {
               DLOG(0,0,"SS count value is %d",val);
               l_isd->provisionedSS.count = val+1;
               //formboaSS3(DlgId,l_isd);
               formboaSS3(l_isd);
               if(g_AsnCodecO3.getEncodingLength(OMAP3_InsertSubscriberDataArg_PDU,l_isd)>p_isdLen)
               {
                  DLOG(0,0,"BOAC length limit exeeded");
                  l_isd->provisionedSS.count -= 1;
                  CB_STATE = CB_BOAC;
                  if(val == 0)
                     return 1;
                  else
                     return 2;
                  break;
               }
               else
               {
                  DLOG(0,0,"BOAC added, moving to BOIC");
                  CB_STATE = CB_BOIC;
                  val += 1;
               }
            }
         }
         //break;
      case CB_BOIC:
         {
            if(boicSsCode)
            {
               DLOG(0,0,"count value is %d",val);
               l_isd->provisionedSS.count = val+1;
               //formboicSS3(DlgId,l_isd);
               formboicSS3(l_isd);
               if(g_AsnCodecO3.getEncodingLength(OMAP3_InsertSubscriberDataArg_PDU,l_isd)>p_isdLen)
               {
                  DLOG(0,0,"BOIC length limit exeeded");
                  l_isd->provisionedSS.count -= 1;
                  CB_STATE = CB_BOIC;
                  if(val == 0)
                     return 1;
                  else
                     return 2;
                  break;
               }
               else
               {
                  DLOG(0,0,"BOIC added, moving to BOIHC");
                  CB_STATE = CB_BOIHC;
                  val += 1;
               }
            }
         }
         //break;
      case CB_BOIHC:
         {
            if(boihcSsCode)
            {
               DLOG(0,0,"count value is %d",val);
               l_isd->provisionedSS.count = val+1;
               //formboihcSS3(DlgId,l_isd);
               formboihcSS3(l_isd);
               if(g_AsnCodecO3.getEncodingLength(OMAP3_InsertSubscriberDataArg_PDU,l_isd)>p_isdLen)
               {
                  DLOG(0,0,"BOIHC length limit exeeded");
                  l_isd->provisionedSS.count -= 1;
                  CB_STATE = CB_BOIHC;
                  if(val == 0)
                     return 1;
                  else
                     return 2;
                  break;
               }
               else
               {
                  DLOG(0,0,"BOIHC added, moving to BAIC");
                  CB_STATE = CB_BAIC;
                  val += 1;
               }
            }
         }
         //break;
      case DEFA:
      default:
         return 0;
         break;
   }
   return 0;
}

//int provisionedSS::formSsSS3(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd, int p_isdLen)
int provisionedSS::formSsSS3(OMAP3_InsertSubscriberDataArg *l_isd)
{
   int prevVal = val;
   DLOG(0,0,"Inside formSsSS3 ,Count here is %d,storing it as prevVal = %d",val,prevVal);

   LLOG(0,0,"Calling Gen ss func SS count till which filled is %d, Total SS data count from DB",m_GenSsCount,SsCount);
   int len3 = 0;   
   len3 = g_AsnCodecO3.getEncodingLength(OMAP3_InsertSubscriberDataArg_PDU,l_isd);   
   DLOG(0,0,"Going to call formGenSS3, isd length formed %d",len3);
   if(SsCount != 0)
   { 
      //m_GenSsCount = formGenSS3(DlgId,l_isd,len3);   
      m_GenSsCount = formGenSS3(l_isd,len3);
   }
   len3 = g_AsnCodecO3.getEncodingLength(OMAP3_InsertSubscriberDataArg_PDU,l_isd);
   DLOG(0,0,"Count after formGenSS3 is  %d isd length formed %d, GenSsCount returned %d",l_isd->provisionedSS.count,len3,m_GenSsCount);


   if(m_GenSsCount < SsCount)
   {
      DLOG(0,0,"Some more Gen SS data remaining, Returning 2");
      return 2;
   }
   else
   {
      DLOG(0,0,"Length not exeeded after adding General SS data, returning 0");
      return 0;
   }
}

//int provisionedSS::formGenSS3(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd,int isdDataLen)
int provisionedSS::formGenSS3(OMAP3_InsertSubscriberDataArg *l_isd,int isdDataLen)
{
   DLOG(0,0,"Inside formGenSS3, Gen SS Count is %d ISD data length received is %d",m_GenSsCount,isdDataLen);
   isdDataLen += 10;
   int ss;
   for(ss = m_GenSsCount;ss<SsCount;ss++)
   {      
      DLOG(0,0,"ISD date length till which filled is %d",isdDataLen);
      if(isdDataLen > g_MmConfigReaderObj->m_IsdLen)
      {
         DLOG(0,0,"Length Limit configured exceeded, Returning Current SS count Value %d",(ss > 0)?ss-1:0);
         if(ss > 0)
         {
            l_isd->provisionedSS.count--;
            return ss-1; 
         }
         else
         {
            return 0;
         }
      }
      l_isd->provisionedSS.count = val+1;
      DLOG(0,0,"Filling SS Data for SS_Data count %d, SS Code: %d, SS Status: %d, Subscription Restriction: %d, CLI Option: %d, Override Cat: %d, Basic Service Type: %d, Basic Service Code: %d ",l_isd->provisionedSS.count,SsCode[ss],SsStatus[ss],SsSubsRest[ss],SsCLIOptn[ss],SsOverRide[ss],SsBType[ss],SsBCode[ss]);

      l_isd->provisionedSS.value[val].choice = OMAP3_Ext_SS_Info_ss_Data_chosen;
      l_isd->provisionedSS.value[val].u.ss_Data.ss_Code.length = 1;
      l_isd->provisionedSS.value[val].u.ss_Data.ss_Code.value[0] = SsCode[ss];
      l_isd->provisionedSS.value[val].u.ss_Data.ss_Status.length = 1;
      l_isd->provisionedSS.value[val].u.ss_Data.ss_Status.value[0] = SsStatus[ss];
      isdDataLen += 8;
      l_isd->provisionedSS.value[val].u.ss_Data.bit_mask = 0;
      if(SsSubsRest[ss]!=0)
      {
         l_isd->provisionedSS.value[val].u.ss_Data.bit_mask |= OMAP3_Ext_SS_Data_ss_SubscriptionOption_present;
         if(SsSubsRest[ss] == 1)
         {
            l_isd->provisionedSS.value[val].u.ss_Data.ss_SubscriptionOption.choice = OMAP3_cliRestrictionOption_chosen;
            l_isd->provisionedSS.value[val].u.ss_Data.ss_SubscriptionOption.u.cliRestrictionOption = (OMAP3_CliRestrictionOption)SsCLIOptn[ss];
         }
         if(SsSubsRest[ss] == 2)
         {
            l_isd->provisionedSS.value[val].u.ss_Data.ss_SubscriptionOption.choice = OMAP3_overrideCategory_chosen;
            l_isd->provisionedSS.value[val].u.ss_Data.ss_SubscriptionOption.u.overrideCategory = (OMAP3_OverrideCategory)SsOverRide[ss];
         }
         isdDataLen += 6;
      }
      if(SsBCode[ss])
      {
         l_isd->provisionedSS.value[val].u.ss_Data.bit_mask |= OMAP3_Ext_SS_Data_basicServiceGroupList_present;
         l_isd->provisionedSS.value[val].u.ss_Data.basicServiceGroupList.count = 1;
         if(SsBType[ss] == 2)
         {
            l_isd->provisionedSS.value[val].u.ss_Data.basicServiceGroupList.value[0].choice = OMAP3_Ext_BasicServiceCode_ext_Teleservice_chosen;
            l_isd->provisionedSS.value[val].u.ss_Data.basicServiceGroupList.value[0].u.ext_Teleservice.length = 1;
            l_isd->provisionedSS.value[val].u.ss_Data.basicServiceGroupList.value[0].u.ext_Teleservice.value[0] = SsBCode[ss];
         }
         if(SsBType[ss] == 1)
         {
            l_isd->provisionedSS.value[val].u.ss_Data.basicServiceGroupList.value[0].choice = OMAP3_Ext_BasicServiceCode_ext_BearerService_chosen;
            l_isd->provisionedSS.value[val].u.ss_Data.basicServiceGroupList.value[0].u.ext_BearerService.length = 1;
            l_isd->provisionedSS.value[val].u.ss_Data.basicServiceGroupList.value[0].u.ext_BearerService.value[0] = SsBCode[ss];
         }
         isdDataLen += 5;
      }
      val = val+1;
      DLOG(0,0,"After SS[%d],SS Count here is %d ISD data length is %d",ss,val,isdDataLen);
   }
   DLOG(0,0,"Added all Generel SS data");
   return ss;
}

//int provisionedSS::formEmSS3(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd, int p_isdLen)
int provisionedSS::formEmSS3(OMAP3_InsertSubscriberDataArg *l_isd)
{
   DLOG(0,0,"Inside formEmSS3,val here is %d",val);
   int p_isdLen = g_MmConfigReaderObj->m_IsdLen;
   //formEmlSS3(DlgId,l_isd);
   formEmlSS3(l_isd);
   
   if(g_AsnCodecO3.getEncodingLength(OMAP3_InsertSubscriberDataArg_PDU,l_isd) > p_isdLen)
   {
      DLOG(0,0,"Length limit exceeded on adding EMLPP  data")
         l_isd->provisionedSS.count -= 1;
      if(val == 0)
         return 1;
      else
         return 2;
      //break;
   }
   else
   {
      return 0;
   }
}

//void provisionedSS::formMcSS(int l_UserDlgId,OMAP3_InsertSubscriberDataArg *l_isd)
void provisionedSS::formMcSS(OMAP3_InsertSubscriberDataArg *l_isd)
{
   if(MCSsStatus > 3)
   {
      DLOG(0,0,"Adding MC_SS_INFO NBR_SB : %d, NBR_User : %d",NBR_SB,NBR_USER);
      l_isd->bit_mask |= OMAP3_mc_SS_Info_present;
      l_isd->mc_SS_Info.ss_Code.length = 1;
      l_isd->mc_SS_Info.ss_Code.value[0] = 69;//mcSsCode;
      l_isd->mc_SS_Info.ss_Status.length = 1;
      l_isd->mc_SS_Info.ss_Status.value[0] = MCSsStatus;
      l_isd->mc_SS_Info.nbrSB = (OMAP3_MaxMC_Bearers)NBR_SB;
      l_isd->mc_SS_Info.nbrUser = (OMAP3_MC_Bearers)NBR_USER;
   }
   else
   {
      DLOG(0,0,"No MC_SS_INFO Available");
   }
}

//void provisionedSS::formCfuSS3(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd)
void provisionedSS::formCfuSS3(OMAP3_InsertSubscriberDataArg *l_isd)
{
   DLOG(0,0,"Inside CFU, val = %d count already set is %d",val,l_isd->provisionedSS.count);
   DLOG(0,0,"cfuSsCode %d, cfuSsCount %d ",cfuSsCode,cfuSsCount);
   //l_isd->provisionedSS.count = val+1;
   l_isd->provisionedSS.value[val].choice = OMAP3_Ext_SS_Info_forwardingInfo_chosen;
   l_isd->provisionedSS.value[val].u.forwardingInfo.ss_Code.length = 1;
   l_isd->provisionedSS.value[val].u.forwardingInfo.ss_Code.value[0] = cfuSsCode;
   l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.count = cfuSsCount;
   for(int cfu = 0;cfu < cfuSsCount;cfu++)
   {
      DLOG(0,0,"SsStatus[%d] : %d, cfuBCode[%d] : %d, cfuBType[%d]: %d",cfu,cfuSsStatus[cfu],cfu,cfuBCode[cfu],cfu,cfuBType[cfu]);
      l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfu].ss_Status.length = 1;
      int l_SsStatus = cfuSsStatus[cfu];
      if((m_AllOGCallsBarresPresent == true) && (cfuSsStatus[cfu] == 7))
      {
            l_SsStatus = 15;
      }
      l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfu].ss_Status.value[0] = l_SsStatus;
      if(cfuBType[cfu])
      {
         l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfu].bit_mask |= OMAP3_Ext_ForwFeature_basicService_present;
         if(cfuBType[cfu] == 1)
         {
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfu].basicService.choice = OMAP3_Ext_BasicServiceCode_ext_BearerService_chosen;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfu].basicService.u.ext_BearerService.length = 1;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfu].basicService.u.ext_BearerService.value[0] = cfuBCode[cfu];
         }
         else
         {
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfu].basicService.choice = OMAP3_Ext_BasicServiceCode_ext_Teleservice_chosen;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfu].basicService.u.ext_Teleservice.length = 1;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfu].basicService.u.ext_Teleservice.value[0] = cfuBCode[cfu];
         }
      }
   }
   //val += 1;
   DLOG(0,0,"Added CFWD Unconditional Count is %d",val);   
}

//void provisionedSS::formCfbSS3(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd)
void provisionedSS::formCfbSS3(OMAP3_InsertSubscriberDataArg *l_isd)
{
   DLOG(0,0,"Inside CFB val here is %d count here is %d",val,l_isd->provisionedSS.count);
   DLOG(0,0,"cfbSsCode: %d, cfbSsCount: %d",cfbSsCode,cfbSsCount);
   l_isd->provisionedSS.value[val].choice = OMAP3_Ext_SS_Info_forwardingInfo_chosen;
   l_isd->provisionedSS.value[val].u.forwardingInfo.ss_Code.length = 1;
   l_isd->provisionedSS.value[val].u.forwardingInfo.ss_Code.value[0] = cfbSsCode;
   l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.count = cfbSsCount;
   for(int cfb = 0;cfb < cfbSsCount;cfb++)
   {
      DLOG(0,0,"cfbBCode[%d]: %d, cfbBType[%d]: %d, cfbSsStatus[%d]: %d, cfbFTN[%d]: %s,cfbFTS[%d]: %s,cfbOPTN[%d]: %d, cfbLFTN[%d]: %s",cfb,cfbBCode[cfb],cfb,cfbBType[cfb],cfb,cfbSsStatus[cfb],cfb,cfbFTN[cfb],cfb,cfbFTS[cfb],cfb,cfbOPTN[cfb],cfb,cfbLFTN[cfb]);
      l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].ss_Status.length = 1;
      int l_SsStatus = cfbSsStatus[cfb];
      if((m_AllOGCallsBarresPresent == true) && (cfbSsStatus[cfb] == 7))
      {
         l_SsStatus = 15;
      }
      l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].ss_Status.value[0] = l_SsStatus;
      if(cfbBType[cfb])
      {
         l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].bit_mask |= OMAP3_Ext_ForwFeature_basicService_present;
         if(cfbBType[cfb] == 1)
         {
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].basicService.choice = OMAP3_Ext_BasicServiceCode_ext_BearerService_chosen;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].basicService.u.ext_BearerService.length = 1;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].basicService.u.ext_BearerService.value[0] = cfbBCode[cfb];
         }
         else
         {
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].basicService.choice = OMAP3_Ext_BasicServiceCode_ext_Teleservice_chosen;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].basicService.u.ext_Teleservice.length = 1;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].basicService.u.ext_Teleservice.value[0] = cfbBCode[cfb];
         }
      }
      if(cfbSsStatus[cfb] > 4)
      {
         TLOG(0,0,"Forward To Number[%d]: %s, Forward To Subaddress[%d]: %s, Forwarding Option[%d]: %d, Long FTN[%d]: %s",cfb,cfbFTN[cfb],cfb,cfbFTS[cfb],cfb,cfbOPTN[cfb],cfb,cfbLFTN[cfb]);
         if(strcmp((char*)cfbFTN[cfb],"0")!=0)
         {           
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].bit_mask |= OMAP3_Ext_ForwFeature_forwardedToNumber_present;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].forwardedToNumber.length = (strlen((char*)cfbFTN[cfb])+1)/2;
            StringToBCD(l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].forwardedToNumber.value,cfbFTN[cfb],strlen((char*)cfbFTN[cfb]));
         }
         if(strcmp((char *)cfbFTS[cfb],"0")!=0)
         {
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].bit_mask |= OMAP3_Ext_ForwFeature_forwardedToSubaddress_present;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].forwardedToSubaddress.length = (strlen((char *)cfbFTS[cfb])+1)/2;
            StringToBCD(l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].forwardedToSubaddress.value,cfbFTS[cfb],strlen((char *)cfbFTS[cfb]));
         }
         if(cfbOPTN[cfb]!=0)
         {              
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].bit_mask |= OMAP3_Ext_ForwFeature_forwardingOptions_present;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].forwardingOptions.length = 1;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].forwardingOptions.value[0] = cfbOPTN[cfb];
         }
         if(strcmp((char *)cfbLFTN[cfb],"0")!=0)
         {
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].bit_mask |= OMAP3_Ext_ForwFeature_longForwardedToNumber_present;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].longForwardedToNumber.length = (strlen((char *)cfbLFTN[cfb])+1)/2;
            StringToBCD(l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].longForwardedToNumber.value,cfbLFTN[cfb],strlen((char *)cfbLFTN[cfb]));
         }
      }
      else
      {
         DLOG(0,0,"SS_Status for the SS_CODE 41(CFB) and basic service code %d is not Registered or Active,not sending FTN,FTS and FWD optn",cfbBCode[cfb]);
      }
   }
   //    val += 1;
   DLOG(0,0,"Added CFWD Busy");   
}

//void provisionedSS::formCfnrySS3(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd)
void provisionedSS::formCfnrySS3(OMAP3_InsertSubscriberDataArg *l_isd)
{
   DLOG(0,0,"Inside CFNRY, val here is %d count here is %d",val,l_isd->provisionedSS.count);
   DLOG(0,0,"cfnrySsCode %d, cfnrySsCount %d",cfnrySsCode,cfnrySsCount);
   l_isd->provisionedSS.value[val].choice = OMAP3_Ext_SS_Info_forwardingInfo_chosen;
   l_isd->provisionedSS.value[val].u.forwardingInfo.ss_Code.length = 1;
   l_isd->provisionedSS.value[val].u.forwardingInfo.ss_Code.value[0] = cfnrySsCode;
   l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.count = cfnrySsCount;
   for(int cfnry = 0;cfnry < cfnrySsCount;cfnry++)
   {
      DLOG(0,0,"cfnryBCode[%d]: %d, cfnryBType[%d]: %d, cfnryFTN[%d]: %s, cfnryFTS[%d]: %s, cfnryOPTN[%d]: %d, cfnryLFTN[%d]: %s",cfnry,cfnryBCode[cfnry],cfnry,cfnryBType[cfnry],cfnry,cfnryFTN[cfnry],cfnry,cfnryFTS[cfnry],cfnry,cfnryOPTN[cfnry],cfnry,cfnryLFTN[cfnry]);
      l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].ss_Status.length = 1;
      int l_SsStatus = cfnrySsStatus[cfnry];
      if((m_AllOGCallsBarresPresent == true) && (cfnrySsStatus[cfnry] == 7))
      {
         l_SsStatus = 15;
      }
      l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].ss_Status.value[0] = l_SsStatus;
      if(cfnryBType[cfnry])
      {
         l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].bit_mask |= OMAP3_Ext_ForwFeature_basicService_present;
         if(cfnryBType[cfnry] == 1)
         {
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].basicService.choice = OMAP3_Ext_BasicServiceCode_ext_BearerService_chosen;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].basicService.u.ext_BearerService.length = 1;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].basicService.u.ext_BearerService.value[0] = cfnryBCode[cfnry];
         }
         else
         {
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].basicService.choice = OMAP3_Ext_BasicServiceCode_ext_Teleservice_chosen;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].basicService.u.ext_Teleservice.length = 1;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].basicService.u.ext_Teleservice.value[0] = cfnryBCode[cfnry];
         }
      }
      if(cfnrySsStatus[cfnry] > 4)
      {
         TLOG(0,0,"SS Status[%d]: %d, Forward To Number[%d]: %s, Forward To Subaddress[%d]: %s, Forwarding Option[%d]: %d, No Reply Timer[%d]: %d, Long FTN[%d]: %s",cfnry,cfnrySsStatus[cfnry],cfnry,cfnryFTN[cfnry],cfnry,cfnryFTS[cfnry],cfnry,cfnryOPTN[cfnry],cfnry,cfnryNRT[cfnry],cfnry,cfnryLFTN[cfnry]);
         if(strcmp((char*)cfnryFTN[cfnry],"0")!=0)
         {
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].bit_mask |= OMAP3_Ext_ForwFeature_forwardedToNumber_present;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].forwardedToNumber.length = (strlen((char*)cfnryFTN[cfnry])+1)/2;
            StringToBCD(l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].forwardedToNumber.value,cfnryFTN[cfnry],strlen((char*)cfnryFTN[cfnry]));
         }
         if(strcmp((char *)cfnryFTS[cfnry],"0")!=0)
         {
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].bit_mask |= OMAP3_Ext_ForwFeature_forwardedToSubaddress_present;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].forwardedToSubaddress.length = (strlen((char *)cfnryFTS[cfnry])+1)/2;
            StringToBCD(l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].forwardedToSubaddress.value,cfnryFTS[cfnry],strlen((char *)cfnryFTS[cfnry]));
         }
         if(cfnryOPTN[cfnry] != 0)
         {
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].bit_mask |= OMAP3_Ext_ForwFeature_forwardingOptions_present;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].forwardingOptions.length = 1;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].forwardingOptions.value[0] = cfnryOPTN[cfnry];
         }
         if(cfnryNRT[cfnry] != 0)
         {
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].bit_mask |= OMAP3_Ext_ForwFeature_noReplyConditionTime_present;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].noReplyConditionTime = cfnryNRT[cfnry];
         }
         if(strcmp((char *)cfnryLFTN[cfnry],"0")!=0)
         {
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].bit_mask |= OMAP3_Ext_ForwFeature_longForwardedToNumber_present;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].longForwardedToNumber.length = (strlen((char *)cfnryLFTN[cfnry])+1)/2;
            StringToBCD(l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].longForwardedToNumber.value,cfnryLFTN[cfnry],strlen((char *)cfnryLFTN[cfnry]));
         }
      }
      else
      {
         DLOG(0,0,"SS_Status for the SS_CODE 42(cfnry)) and basic service code %d is not Registered or Active,not sending FTN,FTS and FWD optn",cfnryBCode[cfnry]);
      }
   }
   //val += 1;
   DLOG(0,0,"Added CFWD no reply, SS Count id %d",val);
}

//void provisionedSS::formCfnrcSS3(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd)
void provisionedSS::formCfnrcSS3(OMAP3_InsertSubscriberDataArg *l_isd)
{
   DLOG(0,0,"Inside CFNRC, val here is %d count here is %d",val,l_isd->provisionedSS.count);
   DLOG(0,0,"cfnrcSsCode: %d, cfnrcSsCount: %d",cfnrcSsCode,cfnrcSsCount);
   l_isd->provisionedSS.value[val].choice = OMAP3_Ext_SS_Info_forwardingInfo_chosen;
   l_isd->provisionedSS.value[val].u.forwardingInfo.ss_Code.length = 1;
   l_isd->provisionedSS.value[val].u.forwardingInfo.ss_Code.value[0] = cfnrcSsCode;
   l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.count = cfnrcSsCount;
   for(int cfnrc = 0;cfnrc < cfnrcSsCount;cfnrc++)
   {
      DLOG(0,0,"cfnrcBCode[%d]: %d, cfnrcBType[%d]: %d, cfnrcSsStatus[%d]: %d, cfnrcFTN[%d] : %s, cfnrcFTS[%d] : %s, cfnrcLFTN[%d]: %s",cfnrc,cfnrcBCode[cfnrc],cfnrc,cfnrcBType[cfnrc],cfnrc,cfnrcSsStatus[cfnrc],cfnrc,cfnrcFTN[cfnrc],cfnrc,cfnrcFTS[cfnrc],cfnrc,cfnrcLFTN[cfnrc]);
      l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].ss_Status.length = 1;
      int l_SsStatus = cfnrcSsStatus[cfnrc];
      if((m_AllOGCallsBarresPresent == true) && (cfnrcSsStatus[cfnrc] == 7))
      {
            l_SsStatus = 15;
      }
      l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].ss_Status.value[0] = l_SsStatus;
      if(cfnrcBType[cfnrc])
      {
         l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].bit_mask |= OMAP3_Ext_ForwFeature_basicService_present;
         if(cfnrcBType[cfnrc] == 1)
         {
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].basicService.choice = OMAP3_Ext_BasicServiceCode_ext_BearerService_chosen;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].basicService.u.ext_BearerService.length = 1;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].basicService.u.ext_BearerService.value[0] = cfnrcBCode[cfnrc];
         }
         else
         {
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].basicService.choice = OMAP3_Ext_BasicServiceCode_ext_Teleservice_chosen;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].basicService.u.ext_Teleservice.length = 1;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].basicService.u.ext_Teleservice.value[0] = cfnrcBCode[cfnrc];
         }
      }
      if(cfnrcSsStatus[cfnrc] > 4)
      {
         TLOG(0,0,"Forward To Number[%d]: %s, Forward To Subaddress[%d]: %s, Forwarding Option[%d]: %d, Long FTN[%d]: %s",cfnrc,cfnrcFTN[cfnrc],cfnrc,cfnrcFTS[cfnrc],cfnrc,cfnrcOPTN[cfnrc],cfnrc,cfnrcLFTN[cfnrc]);
         if(strcmp((char*)cfnrcFTN[cfnrc],"0")!=0)
         {
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].bit_mask |= OMAP3_Ext_ForwFeature_forwardedToNumber_present;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].forwardedToNumber.length = (strlen((char*)cfnrcFTN[cfnrc])+1)/2;
            StringToBCD(l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].forwardedToNumber.value,cfnrcFTN[cfnrc],strlen((char*)cfnrcFTN[cfnrc]));
         }         
         if(strcmp((char *)cfnrcFTS[cfnrc],"0")!=0)
         {
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].bit_mask |= OMAP3_Ext_ForwFeature_forwardedToSubaddress_present;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].forwardedToSubaddress.length = (strlen((char *)cfnrcFTS[cfnrc])+1)/2;
            StringToBCD(l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].forwardedToSubaddress.value,cfnrcFTS[cfnrc],strlen((char *)cfnrcFTS[cfnrc]));
         }
         if(1)//It is 0 only,cannot check it,cfnrcOPTN[cfnrc]!= 0)
         {
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].bit_mask |= OMAP3_Ext_ForwFeature_forwardingOptions_present;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].forwardingOptions.length = 1;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].forwardingOptions.value[0] = cfnrcOPTN[cfnrc];
         }
         if(strncmp((char *)cfnrcLFTN[cfnrc],"0",1)!=0)
         {
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].bit_mask |= OMAP3_Ext_ForwFeature_longForwardedToNumber_present;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].longForwardedToNumber.length = (strlen((char *)cfnrcLFTN[cfnrc])+1)/2;
            StringToBCD(l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].longForwardedToNumber.value,cfnrcLFTN[cfnrc],strlen((char *)cfnrcLFTN[cfnrc]));
         }
      }
      else
      {
         DLOG(0,0,"SS_Status for the SS_CODE 43(CFNRC) and basic service code %d is not Registered or Active,not sending FTN,FTS and FWD optn",cfnrcBCode[cfnrc]);
      }
   }
   //   val += 1;
   DLOG(0,0,"Added Call Fwd on not rechable, SS Count is %d",val);
}


//void provisionedSS::formCdSS3(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd)
void provisionedSS::formCdSS3(OMAP3_InsertSubscriberDataArg *l_isd)
{
   DLOG(0,0,"Forming CD, val here is %d count here is %d",val,l_isd->provisionedSS.count);
   DLOG(0,0,"cdSsCode: %d, cdSsCount: %d",cdSsCode,cdSsCount);
   l_isd->provisionedSS.value[val].choice = OMAP3_Ext_SS_Info_forwardingInfo_chosen;
   l_isd->provisionedSS.value[val].u.forwardingInfo.ss_Code.length = 1;
   l_isd->provisionedSS.value[val].u.forwardingInfo.ss_Code.value[0] = cdSsCode;
   l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.count = cdSsCount;
   for(int cd = 0;cd < cdSsCount;cd++)
   {
      DLOG(0,0,"cdBCode[%d]: %d, cdBType[%d]: %d, cdSsStatus[%d]: %d, cdFTN[%d]: %s, cdFTS[%d]: %s, cdOPTN[%d]: %d,cdLFTN[%d]: %s",cd,cdBCode[cd],cd,cdBType[cd],cd,cdSsStatus[cd],cd,cdFTN[cd],cd,cdFTS[cd],cd,cdOPTN[cd],cd,cdLFTN[cd]);
      l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cd].ss_Status.length = 1;
      int l_SsStatus = cdSsStatus[cd];
      if((m_AllOGCallsBarresPresent == true) && (cdSsStatus[cd] == 7))
      {
            l_SsStatus = 15;
      }
      l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cd].ss_Status.value[0] = l_SsStatus;
      if(cdBType[cd])
      {
         l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cd].bit_mask |= OMAP3_Ext_ForwFeature_basicService_present;
         if(cdBType[cd] == 1)
         {
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cd].basicService.choice = OMAP3_Ext_BasicServiceCode_ext_BearerService_chosen;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cd].basicService.u.ext_BearerService.length = 1;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cd].basicService.u.ext_BearerService.value[0] = cdBCode[cd];
         }
         else
         {
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cd].basicService.choice = OMAP3_Ext_BasicServiceCode_ext_Teleservice_chosen;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cd].basicService.u.ext_Teleservice.length = 1;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cd].basicService.u.ext_Teleservice.value[0] = cdBCode[cd];
         }
      }
      if(cdSsStatus[cd] > 4)
      {
         DLOG(0,0,"Forward To Number[%d]: %s, Forward To Subaddress[%d]: %s, Forwarding Option[%d]: %d, Long FTN[%d]: %s",cd,cdFTN[cd],cd,cdFTS[cd],cd,cdOPTN[cd],cd,cdLFTN[cd]);
         if(strncmp((char*)cdFTN[cd],"0",1)!=0)
         {
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cd].bit_mask |= OMAP3_Ext_ForwFeature_forwardedToNumber_present;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cd].forwardedToNumber.length = (strlen((char*)cdFTN[cd])+1)/2;
            StringToBCD(l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cd].forwardedToNumber.value,cdFTN[cd],strlen((char*)cdFTN[cd]));
         }
         if(strncmp((char *)cdFTS[cd],"0",1)!=0)
         {
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cd].bit_mask |= OMAP3_Ext_ForwFeature_forwardedToSubaddress_present;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cd].forwardedToSubaddress.length = (strlen((char *)cdFTS[cd])+1)/2;
            StringToBCD(l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cd].forwardedToSubaddress.value,cdFTS[cd],strlen((char *)cdFTS[cd]));
         }
         if(cdOPTN[cd]!=0)
         {
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cd].bit_mask |= OMAP3_Ext_ForwFeature_forwardingOptions_present;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cd].forwardingOptions.length = 1;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cd].forwardingOptions.value[0] = cdOPTN[cd];
         }
         if(strncmp((char *)cdLFTN[cd],"0",1)!=0)
         {
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cd].bit_mask |= OMAP3_Ext_ForwFeature_longForwardedToNumber_present;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cd].longForwardedToNumber.length = (strlen((char *)cdLFTN[cd])+1)/2;
            StringToBCD(l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cd].longForwardedToNumber.value,cdLFTN[cd],strlen((char *)cdLFTN[cd]));
         }
      }
      else
      {
         DLOG(0,0,"SS_Status for the SS_CODE 36 and basic service code %d is not Registered or Active,not sending FTN,FTS and FWD optn",cdBCode[cd]);
      }
   }
   //val += 1;
   DLOG(0,0,"Added CFWD Call Deflection ,SS Count is %d",val);
} 

//void provisionedSS::formboaSS3(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd)
void provisionedSS::formboaSS3(OMAP3_InsertSubscriberDataArg *l_isd)
{
   DLOG(0,0,"Forming BOAC,SS DATA count = %d",l_isd->provisionedSS.count);
   l_isd->provisionedSS.value[val].choice = OMAP3_Ext_SS_Info_callBarringInfo_chosen;
   l_isd->provisionedSS.value[val].u.callBarringInfo.ss_Code.length = 1;
   l_isd->provisionedSS.value[val].u.callBarringInfo.ss_Code.value[0] = boacSsCode;
   l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.count = boacCount;
   for(int boac = 0;boac<boacCount;boac++)
   {
      DLOG(0,0,"Basic Service Code[%d]: %d, Basic Service Type[%d]: %d, SS-Status[%d]: %d",boac,boacBCode[boac],boac,boacBType[boac],boac,boacSsStatus[boac]);
      l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boac].ss_Status.length = 1;
      l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boac].ss_Status.value[0] = boacSsStatus[boac];
      if(boacBType[boac])
      {
         l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boac].bit_mask |= OMAP3_Ext_CallBarringFeature_basicService_present;
         if(boacBType[boac] == 1)
         {
            l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boac].basicService.choice = OMAP3_Ext_BasicServiceCode_ext_BearerService_chosen;
            l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boac].basicService.u.ext_BearerService.length = 1;
            l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boac].basicService.u.ext_BearerService.value[0] = boacBCode[boac];
         }
         else
         {
            l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boac].basicService.choice = OMAP3_Ext_BasicServiceCode_ext_Teleservice_chosen;
            l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boac].basicService.u.ext_Teleservice.length = 1;
            l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boac].basicService.u.ext_Teleservice.value[0] = boacBCode[boac];
         }
      }
   }
   DLOG(0,0,"Finished adding Barring of all OutGoing Call");   
}

//void provisionedSS::formboicSS3(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd)
void provisionedSS::formboicSS3(OMAP3_InsertSubscriberDataArg *l_isd)
{
   DLOG(0,0,"Forming BOIC,SS DATA count = %d",l_isd->provisionedSS.count);
   l_isd->provisionedSS.value[val].choice = OMAP3_Ext_SS_Info_callBarringInfo_chosen;
   l_isd->provisionedSS.value[val].u.callBarringInfo.ss_Code.length = 1;
   l_isd->provisionedSS.value[val].u.callBarringInfo.ss_Code.value[0] = boicSsCode;
   l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.count = boicCount;
   for(int boic = 0;boic<boicCount;boic++)
   {
      DLOG(0,0,"Basic Service Code[%d]: %d, Basic Service Type[%d]: %d, SS-Status[%d]: %d",boic,boicBCode[boic],boic,boicBType[boic],boic,boicSsStatus[boic]);
      l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boic].ss_Status.length = 1;
      l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boic].ss_Status.value[0] = boicSsStatus[boic];
      if(boicBType[boic])
      {
         l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boic].bit_mask |= OMAP3_Ext_CallBarringFeature_basicService_present;
         if(boicBType[boic] == 1)
         {
            l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boic].basicService.choice = OMAP3_Ext_BasicServiceCode_ext_BearerService_chosen;
            l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boic].basicService.u.ext_BearerService.length = 1;
            l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boic].basicService.u.ext_BearerService.value[0] = boicBCode[boic];
         }
         else
         {
            l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boic].basicService.choice = OMAP3_Ext_BasicServiceCode_ext_Teleservice_chosen;
            l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boic].basicService.u.ext_Teleservice.length = 1;
            l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boic].basicService.u.ext_Teleservice.value[0] = boicBCode[boic];
         }
      }
   }
   DLOG(0,0,"Finished adding Barring of OutGoing International Call");   
}

//void provisionedSS::formboihcSS3(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd)
void provisionedSS::formboihcSS3(OMAP3_InsertSubscriberDataArg *l_isd)
{
   DLOG(0,0,"inside form boihc count  here %d",l_isd->provisionedSS.count);
   l_isd->provisionedSS.value[val].choice = OMAP3_Ext_SS_Info_callBarringInfo_chosen;
   l_isd->provisionedSS.value[val].u.callBarringInfo.ss_Code.length = 1;
   l_isd->provisionedSS.value[val].u.callBarringInfo.ss_Code.value[0] = boihcSsCode;
   l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.count = boihcCount;
   for(int boihc = 0;boihc<boihcCount;boihc++)
   {
      DLOG(0,0,"Basic Service Code[%d]: %d, Basic Service Type[%d]: %d, SS-Status[%d]: %d",boihc,boihcBCode[boihc],boihc,boihcBType[boihc],boihc,boihcSsStatus[boihc]);
      l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boihc].ss_Status.length = 1;
      l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boihc].ss_Status.value[0] = boihcSsStatus[boihc];
      if(boihcBType[boihc])
      {
         l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boihc].bit_mask |= OMAP3_Ext_CallBarringFeature_basicService_present;
         if(boihcBType[boihc] == 1)
         {
            l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boihc].basicService.choice = OMAP3_Ext_BasicServiceCode_ext_BearerService_chosen;
            l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boihc].basicService.u.ext_BearerService.length = 1;
            l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boihc].basicService.u.ext_BearerService.value[0] = boihcBCode[boihc];
         }
         else
         {
            l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boihc].basicService.choice = OMAP3_Ext_BasicServiceCode_ext_Teleservice_chosen;
            l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boihc].basicService.u.ext_Teleservice.length = 1;
            l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boihc].basicService.u.ext_Teleservice.value[0] = boihcBCode[boihc];
         }
      }
   }
   DLOG(0,0,"Finished adding Barring of OutGoing International Call");  
}

//void provisionedSS::formEmlSS3(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd)
void provisionedSS::formEmlSS3(OMAP3_InsertSubscriberDataArg *l_isd)
{
   if(ESsStatus  >= 4)
   {      
      l_isd->provisionedSS.count += 1;
      DLOG(0,0,"Count of SS data received here is %d, EMLPP MAX Entitiled priority %d and Default Priority %d",l_isd->provisionedSS.count,EMaxPriority,EDefaultPriority);
      l_isd->provisionedSS.value[val].choice = OMAP3_emlpp_Info_chosen;
      l_isd->provisionedSS.value[val].u.emlpp_Info.maximumentitledPriority = EMaxPriority;
      l_isd->provisionedSS.value[val].u.emlpp_Info.defaultPriority = EDefaultPriority;
      DLOG(0,0,"Added Emlpp info");
      val +=1;
   }
   else
   {
      DLOG(0,0,"No EMLPP data available");
   }
}
//END MAP3


//START MAP2
//int provisionedSS::formFwdSS2(int DlgId,OMAP2_InsertSubscriberDataArg *l_isd, int p_isdLen)
int provisionedSS::formFwdSS2(OMAP2_InsertSubscriberDataArg *l_isd)
{
   DLOG(0,0,"Inside formFwdSS, SS Count here is %d, Value of cfuSsCount = %d,cdSsCount = %d,cfbSsCount = %d,cfnrySsCount = %d,cfnrcSsCount = %d",val,cfuSsCount,cdSsCount,cfbSsCount,cfnrySsCount,cfnrcSsCount);
   int p_isdLen = g_MmConfigReaderObj->m_IsdLen;
   switch(CFWD_STATE)
   {
      case CFWD_UNCON:
         {
            if(cfuSsCode)
            {
               DLOG(0,0,"SS Count after adding CFU = %d",val+1);
               l_isd->provisionedSS.count = val+1;
               //formCfuSS2(DlgId,l_isd);
               formCfuSS2(l_isd);
               int len1 = g_AsnCodecO2.getEncodingLength(OMAP2_InsertSubscriberDataArg_PDU, l_isd);
               DLOG(0,0,"CFU current length is %d",len1);
               if(len1 > p_isdLen)
               {
                  DLOG(0,0,"Length limit exceeded on adding CFU CFWD info");
                  l_isd->provisionedSS.count -= 1;
                  CFWD_STATE = CFWD_UNCON;
                  if(val == 0)
                     return 1;
                  else
                     return 2;
                  break;
               }
               else
               {
                  DLOG(0,0,"CFU Added, moving to CFB");
                  CFWD_STATE = CFWD_BUSY;
                  val += 1;
               }
            }
         }
         //break;
      case CFWD_BUSY:
         {
            if(cfbSsCode)
            {
               DLOG(0,0,"SS Count after adding CFB = %d",val+1);
               l_isd->provisionedSS.count = val+1;
               //formCfbSS2(DlgId,l_isd);
               formCfbSS2(l_isd);
               int len2 = g_AsnCodecO2.getEncodingLength(OMAP2_InsertSubscriberDataArg_PDU, l_isd);
               DLOG(0,0,"Length after CFB is %d",len2);
               if(len2 > p_isdLen)
               {
                  DLOG(0,0,"Length limit exceeded on adding CFB CFWD info");
                  l_isd->provisionedSS.count -= 1;
                  CFWD_STATE = CFWD_BUSY;
                  if(val == 0)
                     return 1;
                  else
                     return 2;
                  break;
               }
               else
               {
                  DLOG(0,0,"CFB Added, moving to CFNRC");
                  CFWD_STATE = CFWD_NOTREACH;
                  val += 1;
               }
            }
         }
         //break;
      case CFWD_NOTREACH:
         {
            if(cfnrcSsCode)
            {
               DLOG(0,0,"SS Count after adding CFNRC = %d",val+1);
               l_isd->provisionedSS.count = val+1;
               //formCfnrcSS2(DlgId,l_isd);
               formCfnrcSS2(l_isd);
               if(g_AsnCodecO2.getEncodingLength(OMAP2_InsertSubscriberDataArg_PDU, l_isd) > p_isdLen)
               {
                  DLOG(0,0,"Length limit exceeded on adding CFNRC CFWD info");
                  l_isd->provisionedSS.count -= 1;
                  CFWD_STATE = CFWD_NOTREACH;
                  if(val == 0)
                     return 1;
                  else
                     return 2;
                  break;
               }
               else
               {
                  DLOG(0,0,"CFNRC Added, moving to CFNRY");
                  CFWD_STATE = CFWD_NOREPLY;
                  val += 1;
               }
            }
         }
         //break;
      case CFWD_NOREPLY:
         {
            if(cfnrySsCode)
            {
               DLOG(0,0,"SS Count after adding CFNRY = %d",val+1);
               l_isd->provisionedSS.count = val+1;
               //formCfnrySS2(DlgId,l_isd);
               formCfnrySS2(l_isd);
               if(g_AsnCodecO2.getEncodingLength(OMAP2_InsertSubscriberDataArg_PDU, l_isd) > p_isdLen)
               {
                  DLOG(0,0,"Length limit exceeded on adding CFNRY CFWD info");
                  l_isd->provisionedSS.count -= 1;
                  CFWD_STATE = CFWD_NOREPLY;
                  if(val == 0)
                     return 1;
                  else
                     return 2;
                  break;
               }
               else
               {
                  DLOG(0,0,"CFNRY Added, moving to CD");
                  CFWD_STATE = CALL_DEF;
                  val += 1;
               }
            }
         }
         //break;
      case CALL_DEF:
         {
            if(cdSsCode)
            {
               DLOG(0,0,"SS Count after adding CD = %d",val+1);
               l_isd->provisionedSS.count = val+1;
               //formCdSS2(DlgId,l_isd);
               formCdSS2(l_isd);
               if(g_AsnCodecO2.getEncodingLength(OMAP2_InsertSubscriberDataArg_PDU,l_isd) > p_isdLen)
               {
                  DLOG(0,0,"Length limit exceeded on adding CD CFWD info");
                  l_isd->provisionedSS.count -= 1;
                  CFWD_STATE = CALL_DEF;
                  if(val == 0)
                     return 1;
                  else
                     return 2;
                  break;
               }
               else
               {
                  DLOG(0,0,"CD Added, all CFWD SS DATA Added");
                  CFWD_STATE = DEF;
                  val += 1;
               }
            }
         }
         //break;
      default:
      case DEF:
         return 0;
         //break;
   }
   return 0;
}

//int provisionedSS::formCbSS2(int DlgId,OMAP2_InsertSubscriberDataArg *l_isd, int p_isdLen)
int provisionedSS::formCbSS2(OMAP2_InsertSubscriberDataArg *l_isd)
{
   DLOG(0,0,"Inside Call Barring, SS Count here is %d, boacCount = %d , boicCount = %d, boihcCount = %d baicCount = %d bicrCount = %d",val,boacCount,boicCount,boihcCount,baicCount,bicrCount);
   int p_isdLen = g_MmConfigReaderObj->m_IsdLen;
   switch(CB_STATE)
   {
      case CB_BOAC:
         {
            if(boacSsCode)
            {
               DLOG(0,0,"SS Count after adding BOAC = %d",val+1);
               l_isd->provisionedSS.count = val+1;
               //formboaSS2(DlgId,l_isd);
               formboaSS2(l_isd);
               if(g_AsnCodecO2.getEncodingLength(OMAP2_InsertSubscriberDataArg_PDU,l_isd)>p_isdLen)
               {
                  DLOG(0,0,"Length limit exceeded on adding BOAC CB info");
                  l_isd->provisionedSS.count -= 1;
                  CB_STATE = CB_BOAC;
                  if(val == 0)
                     return 1;
                  else
                     return 2;
                  break;
               }
               else
               {
                  DLOG(0,0,"Added BOAC moving to BOIC");
                  CB_STATE = CB_BOIC;
                  val += 1;
               }
            }
         }
         //break;
      case CB_BOIC:
         {
            if(boicSsCode)
            {
               DLOG(0,0,"SS Count after adding BOIC = %d",val+1);
               l_isd->provisionedSS.count = val+1;
               //formboicSS2(DlgId,l_isd);
               formboicSS2(l_isd);
               if(g_AsnCodecO2.getEncodingLength(OMAP2_InsertSubscriberDataArg_PDU,l_isd)>p_isdLen)
               {
                  DLOG(0,0,"Length limit exceeded on adding BOIC CB info");
                  l_isd->provisionedSS.count -= 1;
                  CB_STATE = CB_BOIC;
                  if(val == 0)
                     return 1;
                  else
                     return 2;
                  break;
               }
               else
               {
                  DLOG(0,0,"Added BOIC moving to BOIHC");
                  CB_STATE = CB_BOIHC;
                  val += 1;
               }
            }
         }
         //break;
      case CB_BOIHC:
         {
            if(boihcSsCode)
            {
               DLOG(0,0,"SS Count after adding BOIHC = %d",val+1);
               l_isd->provisionedSS.count = val+1;
               //formboihcSS2(DlgId,l_isd);
               formboihcSS2(l_isd);
               if(g_AsnCodecO2.getEncodingLength(OMAP2_InsertSubscriberDataArg_PDU,l_isd)>p_isdLen)
               {
                  DLOG(0,0,"Length limit exceeded on adding BOIHC CB info");
                  l_isd->provisionedSS.count -= 1;
                  CB_STATE = CB_BOIHC;
                  if(val == 0)
                     return 1;
                  else
                     return 2;
                  break;
               }
               else
               {
                  DLOG(0,0,"Added BOIHC moving to BAIC");
                  CB_STATE = CB_BAIC;
                  val += 1;
               }
            }
         }
         //break;
      case DEFA:
      default:
         return 0;
         break;
   }
   return 0;
}

//int provisionedSS::formSsSS2(int DlgId,OMAP2_InsertSubscriberDataArg *l_isd, int p_isdLen)
int provisionedSS::formSsSS2(OMAP2_InsertSubscriberDataArg *l_isd)
{
   int prevVal = val;
   int p_isdLen = g_MmConfigReaderObj->m_IsdLen;
   DLOG(0,0,"Inside formSsSS2,SS Count here is %d,storing it as prevVal = %d",val,prevVal);
   //formGenSS2(DlgId,l_isd);
   formGenSS2(l_isd);
   DLOG(0,0,"SS Count after adding SS DATA is  %d",val);
   int len2 = g_AsnCodecO2.getEncodingLength(OMAP2_InsertSubscriberDataArg_PDU,l_isd);
   if(len2 >p_isdLen)
   {
      DLOG(0,0,"Length limit exeeded to %d while adding SS_Data,removing that alone",len2);
      DLOG(0,0,"Filled SS Count till %d,removing till prevVal %d",val,prevVal);
      l_isd->provisionedSS.count = prevVal;
      return 2;
   }
   else
   {
      DLOG(0,0,"Length not exeeded after adding SS data");
      return 0;
   }
}

//void provisionedSS::formCfuSS2(int DlgId,OMAP2_InsertSubscriberDataArg *l_isd)
void provisionedSS::formCfuSS2(OMAP2_InsertSubscriberDataArg *l_isd)
{
   DLOG(0,0,"Filling CFU CFWD info,SS count here is %d,SS Code %d, CFU SS Count %d ",val,cfuSsCode,cfuSsCount);   
   l_isd->provisionedSS.value[val].choice = OMAP2_Ext_SS_Info_forwardingInfo_chosen;
   l_isd->provisionedSS.value[val].u.forwardingInfo.bit_mask |= OMAP2_ForwardingInfo_ss_Code_present;
   l_isd->provisionedSS.value[val].u.forwardingInfo.ss_Code.length = 1;
   l_isd->provisionedSS.value[val].u.forwardingInfo.ss_Code.value[0] = cfuSsCode;
   l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.count = cfuSsCount;
   for(int cfu = 0;cfu < cfuSsCount;cfu++)
   {
      DLOG(0,0,"SS-Status[%d] : %d, Bearer service Code[%d] : %d, Bearer service Type[%d]: %d",cfu,cfuSsStatus[cfu],cfu,cfuBCode[cfu],cfu,cfuBType[cfu]);
      l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfu].bit_mask |= OMAP2_ForwardingFeature_ss_Status_present;
      l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfu].ss_Status.length = 1;
      int l_SsStatus = cfuSsStatus[cfu];
      if((m_AllOGCallsBarresPresent == true) && (cfuSsStatus[cfu] == 7))
      {
            l_SsStatus = 15;
      }
      l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfu].ss_Status.value[0] = l_SsStatus;
      if(cfuBType[cfu])
      {
         l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfu].bit_mask |= OMAP2_ForwardingFeature_basicService_present;
         if(cfuBType[cfu] == 1)
         {
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfu].basicService.choice = OMAP2_bearerService_chosen;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfu].basicService.u.bearerService.length = 1;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfu].basicService.u.bearerService.value[0] = cfuBCode[cfu];
         }
         else
         {
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfu].basicService.choice = OMAP2_teleservice_chosen;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfu].basicService.u.teleservice.length = 1;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfu].basicService.u.teleservice.value[0] = cfuBCode[cfu];
         }
      }
   }
   DLOG(0,0,"Added CFWD Unconditional SS Count is %d",val);
}

//void provisionedSS::formCfbSS2(int DlgId,OMAP2_InsertSubscriberDataArg *l_isd)
void provisionedSS::formCfbSS2(OMAP2_InsertSubscriberDataArg *l_isd)
{
   DLOG(0,0,"Filling CFB CFWD info,SS count here is %d,SS Code: %d, cfb Count: %d",val,cfbSsCode,cfbSsCount);   
   l_isd->provisionedSS.value[val].choice = OMAP2_Ext_SS_Info_forwardingInfo_chosen;
   l_isd->provisionedSS.value[val].u.forwardingInfo.bit_mask |= OMAP2_ForwardingInfo_ss_Code_present;
   l_isd->provisionedSS.value[val].u.forwardingInfo.ss_Code.length = 1;
   l_isd->provisionedSS.value[val].u.forwardingInfo.ss_Code.value[0] = cfbSsCode;
   l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.count = cfbSsCount;
   for(int cfb = 0;cfb < cfbSsCount;cfb++)
   {
      DLOG(0,0,"Bearer Service Code[%d]: %d, Basic Service Type[%d]: %d, SS-Status[%d]: %d, Fwd To Number[%d]: %s,Fwd To SubAddr[%d]: %s,Fwd Option[%d]: %d, Long FTN[%d]: %s",cfb,cfbBCode[cfb],cfb,cfbBType[cfb],cfb,cfbSsStatus[cfb],cfb,cfbFTN[cfb],cfb,cfbFTS[cfb],cfb,cfbOPTN[cfb],cfb,cfbLFTN[cfb]);
      l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].bit_mask = 0;
      l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].bit_mask |= OMAP2_ForwardingFeature_ss_Status_present;
      l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].ss_Status.length = 1;
      int l_SsStatus = cfbSsStatus[cfb];
      if((m_AllOGCallsBarresPresent == true) && (cfbSsStatus[cfb] == 7))
      {
            l_SsStatus = 15;
      }
      l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].ss_Status.value[0] = l_SsStatus;
      if(cfbBType[cfb])
      {
         l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].bit_mask |= OMAP2_ForwardingFeature_basicService_present;
         if(cfbBType[cfb] == 1)
         {
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].basicService.choice = OMAP2_bearerService_chosen;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].basicService.u.bearerService.length = 1;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].basicService.u.bearerService.value[0] = cfbBCode[cfb];
         }
         else
         {
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].basicService.choice = OMAP2_teleservice_chosen;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].basicService.u.teleservice.length = 1;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].basicService.u.teleservice.value[0] = cfbBCode[cfb];
         }
      }
      if(cfbSsStatus[cfb] > 4)
      {
         if(strcmp((char*)cfbFTN[cfb],"0")!= 0)
         {                
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].bit_mask |= OMAP2_ForwardingFeature_forwardedToNumber_present;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].forwardedToNumber.length = (strlen((char*)cfbFTN[cfb])+1)/2;
            StringToBCD(l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].forwardedToNumber.value,cfbFTN[cfb],strlen((char*)cfbFTN[cfb]));
         }
         if(strcmp((char *)cfbFTS[cfb],"0")!=0)
         {              
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].bit_mask |= OMAP2_ForwardingFeature_forwardedToSubaddress_present;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].forwardedToSubaddress.length = (strlen((char *)cfbFTS[cfb])+1)/2;
            StringToBCD(l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].forwardedToSubaddress.value,cfbFTS[cfb],strlen((char *)cfbFTS[cfb]));
         }
         if(cfbOPTN[cfb] != 0)
         {
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].bit_mask |= OMAP2_ForwardingFeature_forwardingOptions_present;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].forwardingOptions.length = 1;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].forwardingOptions.value[0] = cfbOPTN[cfb];
         }
      }
      else
      {
         DLOG(0,0,"SS_Status for the SS_CODE 41(CFB) and basic service code %d is not Registered or Active,not sending FTN,FTS and FWD optn",cfbBCode[cfb]);
      }
   }
   DLOG(0,0,"Added CFWD Busy");
}

//void provisionedSS::formCfnrySS2(int DlgId,OMAP2_InsertSubscriberDataArg *l_isd)
void provisionedSS::formCfnrySS2(OMAP2_InsertSubscriberDataArg *l_isd)
{
   DLOG(0,0,"Filling CFNRY CFWD info,SS count here is %d,SS-Code %d, Cfnry Count %d",val,cfnrySsCode,cfnrySsCount);    
   l_isd->provisionedSS.value[val].choice = OMAP2_Ext_SS_Info_forwardingInfo_chosen;
   l_isd->provisionedSS.value[val].u.forwardingInfo.bit_mask |= OMAP2_ForwardingInfo_ss_Code_present;
   l_isd->provisionedSS.value[val].u.forwardingInfo.ss_Code.length = 1;
   l_isd->provisionedSS.value[val].u.forwardingInfo.ss_Code.value[0] = cfnrySsCode;
   l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.count = cfnrySsCount;
   for(int cfnry = 0;cfnry < cfnrySsCount;cfnry++)
   {
      DLOG(0,0,"Basic service Code[%d]: %d, Basic service Type[%d]: %d, Fwd To Number[%d]: %s, Fwd To SubAddr[%d]: %s, Fwd Option[%d]: %d, Long FTN[%d]: %s",cfnry,cfnryBCode[cfnry],cfnry,cfnryBType[cfnry],cfnry,cfnryFTN[cfnry],cfnry,cfnryFTS[cfnry],cfnry,cfnryOPTN[cfnry],cfnry,cfnryLFTN[cfnry]);
      l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].bit_mask = 0;
      l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].bit_mask |= OMAP2_ForwardingFeature_ss_Status_present;
      l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].ss_Status.length = 1;
      int l_SsStatus = cfnrySsStatus[cfnry];
      if((m_AllOGCallsBarresPresent == true) && (cfnrySsStatus[cfnry] == 7))
      {
         l_SsStatus = 15;
      }
      l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].ss_Status.value[0] = l_SsStatus;
      if(cfnryBType[cfnry])
      {
         l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].bit_mask |= OMAP2_ForwardingFeature_basicService_present;
         if(cfnryBType[cfnry] == 1)
         {
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].basicService.choice = OMAP2_bearerService_chosen;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].basicService.u.bearerService.length = 1;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].basicService.u.bearerService.value[0] = cfnryBCode[cfnry];
         }
         else
         {
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].basicService.choice = OMAP2_teleservice_chosen;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].basicService.u.teleservice.length = 1;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].basicService.u.teleservice.value[0] = cfnryBCode[cfnry];
         }
      }
      if(cfnrySsStatus[cfnry] > 4)
      {
         if(strcmp((char*)cfnryFTN[cfnry],"0")!=0)
         {
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].bit_mask |= OMAP2_ForwardingFeature_forwardedToNumber_present;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].forwardedToNumber.length = (strlen((char*)cfnryFTN[cfnry])+1)/2;
            StringToBCD(l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].forwardedToNumber.value,cfnryFTN[cfnry],strlen((char*)cfnryFTN[cfnry]));
         }
         if(strcmp((char *)cfnryFTS[cfnry],"0")!=0)
         {
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].bit_mask |= OMAP2_ForwardingFeature_forwardedToSubaddress_present;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].forwardedToSubaddress.length = (strlen((char *)cfnryFTS[cfnry])+1)/2;
            StringToBCD(l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].forwardedToSubaddress.value,cfnryFTS[cfnry],strlen((char *)cfnryFTS[cfnry]));
         }
         if(cfnryOPTN[cfnry] != 0)
         {
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].bit_mask |= OMAP2_ForwardingFeature_forwardingOptions_present;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].forwardingOptions.length = 1;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].forwardingOptions.value[0] = cfnryOPTN[cfnry];
         }
         l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].bit_mask |= OMAP2_ForwardingFeature_noReplyConditionTime_present;
         l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].noReplyConditionTime = cfnryNRT[cfnry];
      }
      else
      {
         DLOG(0,0,"SS_Status for the SS_CODE 42(CFNRY) and basic service code %d is not Registered or Active,not sending FTN,FTS and FWD optn",cfnryBCode[cfnry]);
      }
   }
   DLOG(0,0,"Added CFWD no reply");
}

//void provisionedSS::formCfnrcSS2(int DlgId,OMAP2_InsertSubscriberDataArg *l_isd)
void provisionedSS::formCfnrcSS2(OMAP2_InsertSubscriberDataArg *l_isd)
{
   DLOG(0,0,"Filling CFNRC CFWD info,SS count here is %d,cfnrcSsCode: %d, cfnrcSsCount: %d",val,cfnrcSsCode,cfnrcSsCount);    
   l_isd->provisionedSS.value[val].choice = OMAP2_Ext_SS_Info_forwardingInfo_chosen;
   l_isd->provisionedSS.value[val].u.forwardingInfo.bit_mask |= OMAP2_ForwardingInfo_ss_Code_present;
   l_isd->provisionedSS.value[val].u.forwardingInfo.ss_Code.length = 1;
   l_isd->provisionedSS.value[val].u.forwardingInfo.ss_Code.value[0] = cfnrcSsCode;
   l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.count = cfnrcSsCount;
   for(int cfnrc = 0;cfnrc < cfnrcSsCount;cfnrc++)
   {
      DLOG(0,0,"Basic service Code[%d]: %d, Basic service Type[%d]: %d, SS-Status[%d]: %d, Fwd To Number[%d] : %s, Fwd To SubAddr[%d] : %s, Long FTN[%d]: %s",cfnrc,cfnrcBCode[cfnrc],cfnrc,cfnrcBType[cfnrc],cfnrc,cfnrcSsStatus[cfnrc],cfnrc,cfnrcFTN[cfnrc],cfnrc,cfnrcFTS[cfnrc],cfnrc,cfnrcLFTN[cfnrc]);
      l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].bit_mask = 0;
      l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].bit_mask |= OMAP2_ForwardingFeature_ss_Status_present;
      l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].ss_Status.length = 1;
      int l_SsStatus = cfnrcSsStatus[cfnrc];
      if((m_AllOGCallsBarresPresent == true) && (cfnrcSsStatus[cfnrc] == 7))
      {
            l_SsStatus = 15;
      }
      l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].ss_Status.value[0] = l_SsStatus;
      if(cfnrcBType[cfnrc])
      {
         l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].bit_mask |= OMAP2_ForwardingFeature_basicService_present;
         if(cfnrcBType[cfnrc] == 1)
         {
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].basicService.choice = OMAP2_bearerService_chosen;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].basicService.u.bearerService.length = 1;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].basicService.u.bearerService.value[0] = cfnrcBCode[cfnrc];
         }
         else
         {
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].basicService.choice = OMAP2_teleservice_chosen;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].basicService.u.teleservice.length = 1;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].basicService.u.teleservice.value[0] = cfnrcBCode[cfnrc];
         }
      }
      if(( cfnrcSsStatus[cfnrc] == 6) || ( cfnrcSsStatus[cfnrc] == 7))
      {
         if(strcmp((char*)cfnrcFTN[cfnrc],"0")!=0)
         {
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].bit_mask |= OMAP2_ForwardingFeature_forwardedToNumber_present;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].forwardedToNumber.length = (strlen((char*)cfnrcFTN[cfnrc])+1)/2;
            StringToBCD(l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].forwardedToNumber.value,cfnrcFTN[cfnrc],strlen((char*)cfnrcFTN[cfnrc]));
         }
         if(strcmp((char *)cfnrcFTS[cfnrc],"0")!=0)
         {
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].bit_mask |= OMAP2_ForwardingFeature_forwardedToSubaddress_present;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].forwardedToSubaddress.length = (strlen((char *)cfnrcFTS[cfnrc])+1)/2;
            StringToBCD(l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].forwardedToSubaddress.value,cfnrcFTS[cfnrc],strlen((char *)cfnrcFTS[cfnrc]));
         }
         if(cfnrcOPTN[cfnrc] !=0)
         {
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].bit_mask |= OMAP2_ForwardingFeature_forwardingOptions_present;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].forwardingOptions.length = 1;
            l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].forwardingOptions.value[0] = cfnrcOPTN[cfnrc];
         }
      }
      else
      {
         DLOG(0,0,"SS_Status for the SS_CODE 43(CFNRC) and basic service code %d is not Registered or Active,not sending FTN,FTS and FWD optn",cfnrcBCode[cfnrc]);
      }
   }
   DLOG(0,0,"Added Call Fwd on not rechable");
}

//void provisionedSS::formCdSS2(int DlgId,OMAP2_InsertSubscriberDataArg *l_isd)
void provisionedSS::formCdSS2(OMAP2_InsertSubscriberDataArg *l_isd)
{
   DLOG(0,0,"Filling CD CFWD info,SS count here is %d,cdSsCode: %d, cdSsCount: %d",val,cdSsCode,cdSsCount);   
   l_isd->provisionedSS.value[val].choice = OMAP2_Ext_SS_Info_forwardingInfo_chosen;
   l_isd->provisionedSS.value[val].u.forwardingInfo.bit_mask |= OMAP2_ForwardingInfo_ss_Code_present;
   l_isd->provisionedSS.value[0].u.forwardingInfo.ss_Code.length = 1;
   l_isd->provisionedSS.value[0].u.forwardingInfo.ss_Code.value[0] = cdSsCode;
   l_isd->provisionedSS.value[0].u.forwardingInfo.forwardingFeatureList.count = cdSsCount;
   for(int cd = 0;cd < cdSsCount;cd++)
   {
      DLOG(0,0,"Basic Service Code[%d]: %d, Basic service Type[%d]: %d, SS-Status[%d]: %d, Fwd To Number[%d]: %s, Fwd To SubAddr[%d]: %s, Fwd Option[%d]: %d,Long FTN[%d]: %s",cd,cdBCode[cd],cd,cdBType[cd],cd,cdSsStatus[cd],cd,cdFTN[cd],cd,cdFTS[cd],cd,cdOPTN[cd],cd,cdLFTN[cd]);
      l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cd].bit_mask = 0;
      l_isd->provisionedSS.value[val].u.forwardingInfo.forwardingFeatureList.value[cd].bit_mask |= OMAP2_ForwardingFeature_ss_Status_present;
      l_isd->provisionedSS.value[0].u.forwardingInfo.forwardingFeatureList.value[cd].ss_Status.length = 1;
      int l_SsStatus = cdSsStatus[cd];
      if((m_AllOGCallsBarresPresent == true) && (cdSsStatus[cd] == 7))
      {
            l_SsStatus = 15;
      }
      l_isd->provisionedSS.value[0].u.forwardingInfo.forwardingFeatureList.value[cd].ss_Status.value[0] = l_SsStatus;
      if(cdBType[cd])
      {
         l_isd->provisionedSS.value[0].u.forwardingInfo.forwardingFeatureList.value[cd].bit_mask |= OMAP2_ForwardingFeature_basicService_present;
         if(cdBType[cd] == 1)
         {
            l_isd->provisionedSS.value[0].u.forwardingInfo.forwardingFeatureList.value[cd].basicService.choice = OMAP2_bearerService_chosen;
            l_isd->provisionedSS.value[0].u.forwardingInfo.forwardingFeatureList.value[cd].basicService.u.bearerService.length = 1;
            l_isd->provisionedSS.value[0].u.forwardingInfo.forwardingFeatureList.value[cd].basicService.u.bearerService.value[0] = cdBCode[cd];
         }
         else
         {
            l_isd->provisionedSS.value[0].u.forwardingInfo.forwardingFeatureList.value[cd].basicService.choice = OMAP2_teleservice_chosen;
            l_isd->provisionedSS.value[0].u.forwardingInfo.forwardingFeatureList.value[cd].basicService.u.teleservice.length = 1;
            l_isd->provisionedSS.value[0].u.forwardingInfo.forwardingFeatureList.value[cd].basicService.u.teleservice.value[0] = cdBCode[cd];
         }
      }
      if((cdSsStatus[cd] == 6)||(cdSsStatus[cd]==7))
      {
         if(strcmp((char*)cdFTN[cd],"0")!=0)
         {
            l_isd->provisionedSS.value[0].u.forwardingInfo.forwardingFeatureList.value[cd].bit_mask |= OMAP2_ForwardingFeature_forwardedToNumber_present;
            l_isd->provisionedSS.value[0].u.forwardingInfo.forwardingFeatureList.value[cd].forwardedToNumber.length = (strlen((char*)cdFTN[cd])+1)/2;
            StringToBCD(l_isd->provisionedSS.value[0].u.forwardingInfo.forwardingFeatureList.value[cd].forwardedToNumber.value,cdFTN[cd],strlen((char*)cdFTN[cd]));
         }
         if(strcmp((char *)cdFTS[cd],"0")!=0)
         {
            l_isd->provisionedSS.value[0].u.forwardingInfo.forwardingFeatureList.value[cd].bit_mask |= OMAP2_ForwardingFeature_forwardedToSubaddress_present;
            l_isd->provisionedSS.value[0].u.forwardingInfo.forwardingFeatureList.value[cd].forwardedToSubaddress.length = (strlen((char *)cdFTS[cd])+1)/2;
            StringToBCD(l_isd->provisionedSS.value[0].u.forwardingInfo.forwardingFeatureList.value[cd].forwardedToSubaddress.value,cdFTS[cd],strlen((char *)cdFTS[cd]));
         }
         if(1)//cdOPTN[cd]!=0)
         {
            l_isd->provisionedSS.value[0].u.forwardingInfo.forwardingFeatureList.value[cd].bit_mask |= OMAP2_ForwardingFeature_forwardingOptions_present;
            l_isd->provisionedSS.value[0].u.forwardingInfo.forwardingFeatureList.value[cd].forwardingOptions.length = 1;
            l_isd->provisionedSS.value[0].u.forwardingInfo.forwardingFeatureList.value[cd].forwardingOptions.value[0] = cdOPTN[cd];
         }
      }
      else
      {
         DLOG(0,0,"SS_Status for the SS_CODE 36(Call Deflection) and basic service code %d is not Registered or Active,not sending FTN,FTS and FWD optn",cdBCode[cd]);
      }
   }
   DLOG(0,0,"Added CFWD Call Deflection");
}

//void provisionedSS::formboaSS2(int DlgId,OMAP2_InsertSubscriberDataArg *l_isd)
void provisionedSS::formboaSS2(OMAP2_InsertSubscriberDataArg *l_isd)
{
   DLOG(0,0,"Forming BOAC,SS DATA count = %d, BOAC count : %d",l_isd->provisionedSS.count,boacCount);
   l_isd->provisionedSS.value[val].choice = OMAP2_Ext_SS_Info_callBarringInfo_chosen;
   l_isd->provisionedSS.value[val].u.callBarringInfo.bit_mask |= OMAP2_CallBarringInfo_ss_Code_present;
   l_isd->provisionedSS.value[val].u.callBarringInfo.ss_Code.length = 1;
   l_isd->provisionedSS.value[val].u.callBarringInfo.ss_Code.value[0] = boacSsCode;
   l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.count = boacCount;
   for(int boac = 0;boac<boacCount;boac++)
   {
      DLOG(0,0,"Basic Service Code[%d]: %d, Basic Service Type[%d]: %d, SS-Status[%d]: %d",boac,boacBCode[boac],boac,boacBType[boac],boac,boacSsStatus[boac]);
      l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boac].bit_mask |= OMAP2_CallBarringFeature_ss_Status_present;
      l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boac].ss_Status.length = 1;
      l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boac].ss_Status.value[0] = boacSsStatus[boac];
      if(boacBType[boac])
      {
         l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boac].bit_mask |= OMAP2_Ext_CallBarringFeature_basicService_present;
         if(boacBType[boac] == 1)
         {
            l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boac].basicService.choice = OMAP2_ext_BearerService_chosen;
            l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boac].basicService.u.bearerService.length = 1;
            l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boac].basicService.u.bearerService.value[0] = boacBCode[boac];
         }
         else
         {
            l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boac].basicService.choice = OMAP2_ext_Teleservice_chosen;
            l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boac].basicService.u.teleservice.length = 1;
            l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boac].basicService.u.teleservice.value[0] = boacBCode[boac];
         }
      }
   }
   DLOG(0,0,"Added Barring of all OutGoing Call");
}

//void provisionedSS::formboicSS2(int DlgId,OMAP2_InsertSubscriberDataArg *l_isd)
void provisionedSS::formboicSS2(OMAP2_InsertSubscriberDataArg *l_isd)
{
   DLOG(0,0,"Forming BOIC,SS DATA count = %d, BOIC count : %d",l_isd->provisionedSS.count,boicCount);
   l_isd->provisionedSS.value[val].choice = OMAP2_Ext_SS_Info_callBarringInfo_chosen;
   l_isd->provisionedSS.value[val].u.callBarringInfo.bit_mask |= OMAP2_CallBarringInfo_ss_Code_present;
   l_isd->provisionedSS.value[val].u.callBarringInfo.ss_Code.length = 1;
   l_isd->provisionedSS.value[val].u.callBarringInfo.ss_Code.value[0] = boicSsCode;
   l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.count = boicCount;
   for(int boic = 0;boic<boicCount;boic++)
   {
      DLOG(0,0,"Basic Service Code[%d]: %d, Basic Service Type[%d]: %d, SS-Status[%d]: %d",boic,boicBCode[boic],boic,boicBType[boic],boic,boicSsStatus[boic]);
      l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boic].bit_mask |= OMAP2_CallBarringFeature_ss_Status_present;
      l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boic].ss_Status.length = 1;
      l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boic].ss_Status.value[0] = boicSsStatus[boic];
      if(boicBType[boic])
      {
         l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boic].bit_mask |= OMAP2_Ext_CallBarringFeature_basicService_present;
         if(boicBType[boic] == 1)
         {
            l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boic].basicService.choice = OMAP2_ext_BearerService_chosen;
            l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boic].basicService.u.bearerService.length = 1;
            l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boic].basicService.u.bearerService.value[0] = boicBCode[boic];
         }
         else
         {
            l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boic].basicService.choice = OMAP2_ext_Teleservice_chosen;
            l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boic].basicService.u.teleservice.length = 1;
            l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boic].basicService.u.teleservice.value[0] = boicBCode[boic];
         }
      }
   }
   DLOG(0,0,"Added Barring of OutGoing International Call");
}

//void provisionedSS::formboihcSS2(int DlgId,OMAP2_InsertSubscriberDataArg *l_isd)
void provisionedSS::formboihcSS2(OMAP2_InsertSubscriberDataArg *l_isd)
{
   DLOG(0,0,"Forming BOIHC,SS DATA count = %d, BOIHC Count : %d",l_isd->provisionedSS.count,boihcCount);
   l_isd->provisionedSS.value[val].choice = OMAP2_Ext_SS_Info_callBarringInfo_chosen;
   l_isd->provisionedSS.value[val].u.callBarringInfo.bit_mask |= OMAP2_CallBarringInfo_ss_Code_present;
   l_isd->provisionedSS.value[val].u.callBarringInfo.ss_Code.length = 1;
   l_isd->provisionedSS.value[val].u.callBarringInfo.ss_Code.value[0] = boihcSsCode;
   l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.count = boihcCount;
   for(int boihc = 0;boihc<boihcCount;boihc++)
   {
      DLOG(0,0,"Basic Service Code[%d]: %d, Basic Service Type[%d]: %d, SS-Status[%d]: %d",boihc,boihcBCode[boihc],boihc,boihcBType[boihc],boihc,boihcSsStatus[boihc]);
      l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boihc].bit_mask |= OMAP2_CallBarringFeature_ss_Status_present;
      l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boihc].ss_Status.length = 1;
      l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boihc].ss_Status.value[0] = boihcSsStatus[boihc];
      if(boihcBType[boihc])
      {
         l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boihc].bit_mask |= OMAP2_Ext_CallBarringFeature_basicService_present;
         if(boihcBType[boihc] == 1)
         {
            l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boihc].basicService.choice = OMAP2_ext_BearerService_chosen;
            l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boihc].basicService.u.bearerService.length = 1;
            l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boihc].basicService.u.bearerService.value[0] = boihcBCode[boihc];
         }
         else
         {
            l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boihc].basicService.choice = OMAP2_ext_Teleservice_chosen;
            l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boihc].basicService.u.teleservice.length = 1;
            l_isd->provisionedSS.value[val].u.callBarringInfo.callBarringFeatureList.value[boihc].basicService.u.teleservice.value[0] = boihcBCode[boihc];
         }
      }
   }
   DLOG(0,0,"Finished adding Barring of OutGoing International Call Except HPLMN");
}

//void provisionedSS::formGenSS2(int DlgId,OMAP2_InsertSubscriberDataArg *l_isd)
void provisionedSS::formGenSS2(OMAP2_InsertSubscriberDataArg *l_isd)
{
   DLOG(0,0,"Inside formGenSS2, Gen SS Count is %d ",m_GenSsCount);
   for(int ss = 0;ss<SsCount;ss++)
   {
      DLOG(0,0,"Filling SS Data for SS_Data count %d, SS Code: %d, SS Status: %d, Subscription Restriction: %d, CLI Option: %d, Override Cat: %d, Basic Service Type: %d, Basic Service Code: %d ",l_isd->provisionedSS.count,SsCode[ss],SsStatus[ss],SsSubsRest[ss],SsCLIOptn[ss],SsOverRide[ss],SsBType[ss],SsBCode[ss]);
      l_isd->provisionedSS.count = val+1;
      l_isd->provisionedSS.value[val].choice = OMAP2_SS_Info_ss_Data_chosen;
      l_isd->provisionedSS.value[val].u.ss_Data.bit_mask = 0;
      l_isd->provisionedSS.value[val].u.ss_Data.bit_mask |= OMAP2_SS_Data_ss_Code_present;
      l_isd->provisionedSS.value[val].u.ss_Data.ss_Code.length = 1;
      l_isd->provisionedSS.value[val].u.ss_Data.ss_Code.value[0] = SsCode[ss];
      l_isd->provisionedSS.value[val].u.ss_Data.bit_mask |= OMAP2_SS_Data_ss_Status_present;
      l_isd->provisionedSS.value[val].u.ss_Data.ss_Status.length = 1;
      l_isd->provisionedSS.value[val].u.ss_Data.ss_Status.value[0] = SsStatus[ss];           
      if(SsSubsRest[ss]!=0)
      {
         l_isd->provisionedSS.value[val].u.ss_Data.bit_mask |= OMAP2_SS_Data_ss_SubscriptionOption_present;
         if(SsSubsRest[ss] == 1)
         {
            l_isd->provisionedSS.value[val].u.ss_Data.ss_SubscriptionOption.choice = OMAP2_cliRestrictionOption_chosen;
            l_isd->provisionedSS.value[val].u.ss_Data.ss_SubscriptionOption.u.cliRestrictionOption = (OMAP2_CliRestrictionOption)SsCLIOptn[ss];
         }
         if(SsSubsRest[ss] == 2)
         {
            l_isd->provisionedSS.value[val].u.ss_Data.ss_SubscriptionOption.choice = OMAP2_overrideCategory_chosen;
            l_isd->provisionedSS.value[val].u.ss_Data.ss_SubscriptionOption.u.overrideCategory = (OMAP2_OverrideCategory)SsOverRide[ss];
         }
      }
      if(SsBType[ss])
      {
         l_isd->provisionedSS.value[val].u.ss_Data.bit_mask |= OMAP2_SS_Data_basicServiceGroupList_present;
         l_isd->provisionedSS.value[val].u.ss_Data.basicServiceGroupList.count = 1;
         if(SsBType[ss] == 2)
         {
            l_isd->provisionedSS.value[val].u.ss_Data.basicServiceGroupList.value[0].choice = OMAP2_teleservice_chosen;
            l_isd->provisionedSS.value[val].u.ss_Data.basicServiceGroupList.value[0].u.teleservice.length = 1;
            l_isd->provisionedSS.value[val].u.ss_Data.basicServiceGroupList.value[0].u.teleservice.value[0] = SsBCode[ss];
         }
         if(SsBType[ss] == 1)
         {
            l_isd->provisionedSS.value[val].u.ss_Data.basicServiceGroupList.value[0].choice = OMAP2_bearerService_chosen;
            l_isd->provisionedSS.value[val].u.ss_Data.basicServiceGroupList.value[0].u.bearerService.length = 1;
            l_isd->provisionedSS.value[val].u.ss_Data.basicServiceGroupList.value[0].u.bearerService.value[0] = SsBCode[ss];
         }
      }
      val = val+1;
      DLOG(0,0,"After GenSS[%d],SS Count here is %d ",ss,val);
   }
   DLOG(0,0,"Added Generel SS data");
}
//END MAP2


//START MAP1
//int provisionedSS::formFwdSS1(int DlgId,OMAP1_InsertSubscriberDataArg *l_isd, int p_isdLen)
int provisionedSS::formFwdSS1(OMAP1_InsertSubscriberDataArg *l_isd)
{
   DLOG(0,0,"Inside formFwdSS, SS Count is %d, Value of cfuSsCount = %d,cdSsCount = %d,cfbSsCount = %d,cfnrySsCount = %d,cfnrcSsCount = %d",val,cfuSsCount,cdSsCount,cfbSsCount,cfnrySsCount,cfnrcSsCount);
   int p_isdLen = g_MmConfigReaderObj->m_IsdLen;
   switch(CFWD_STATE)
   {
      case CFWD_UNCON:
         {
            if(cfuSsCode)
            {
               DLOG(0,0,"SS Count after adding CFU = %d",val+1);
               l_isd->provisonedSS.count = val+1;
               //formCfuSS1(DlgId,l_isd->provisonedSS);
               formCfuSS1(l_isd->provisonedSS);
               int len1 = 0;
               len1 = g_AsnCodecO1.getEncodingLength(OMAP1_InsertSubscriberDataArg_PDU, l_isd);
               DLOG(0,0,"CFU current length is %d",len1);
               if(len1 > p_isdLen)
               {
                  DLOG(0,0,"Length limit exceeded on adding CFU CFWD info");
                  l_isd->provisonedSS.count -= 1;
                  CFWD_STATE = CFWD_UNCON;
                  if(val == 0)
                     return 1;
                  else
                     return 2;
                  break;
               }
               else
               {
                  DLOG(0,0,"CFU Added,moving to CFB");
                  CFWD_STATE = CFWD_BUSY;
                  val += 1;
               }
            }
         }
         //break;
      case CFWD_BUSY:
         {
            if(cfbSsCode)
            {
               DLOG(0,0,"SS Count after adding CFB = %d",val+1);
               l_isd->provisonedSS.count = val+1;
               //formCfbSS1(DlgId,l_isd->provisonedSS);
               formCfbSS1(l_isd->provisonedSS);
               int len1 = 0;
               len1 = g_AsnCodecO1.getEncodingLength(OMAP1_InsertSubscriberDataArg_PDU, l_isd);
               DLOG(0,0,"Len after CFB is %d",len1);
               if(len1 > p_isdLen)
               {
                  DLOG(0,0,"Length limit exceeded on adding CFB CFWD info");
                  l_isd->provisonedSS.count -= 1;
                  CFWD_STATE = CFWD_BUSY;
                  if(val == 0)
                     return 1;
                  else
                     return 2;
                  break;
               }
               else
               {
                  DLOG(0,0,"CFB added, moving to CFNRC");
                  CFWD_STATE = CFWD_NOTREACH;
                  val += 1;
               }
            }
         }
         //break;
      case CFWD_NOTREACH:
         {
            if(cfnrcSsCode)
            {
               DLOG(0,0,"SS Count after adding CFNRC = %d",val+1);
               l_isd->provisonedSS.count = val+1;
               //formCfnrcSS1(DlgId,l_isd->provisonedSS);
               formCfnrcSS1(l_isd->provisonedSS);
               int len = 0;
               len = g_AsnCodecO1.getEncodingLength(OMAP1_InsertSubscriberDataArg_PDU, l_isd);
               if(len > p_isdLen)
               {
                  DLOG(0,0,"Length limit exceeded on adding CFNRC CFWD info");
                  l_isd->provisonedSS.count -= 1;
                  CFWD_STATE = CFWD_NOTREACH;
                  if(val == 0)
                     return 1;
                  else
                     return 2;
                  break;
               }
               else
               {
                  DLOG(0,0,"CFNRC added, moving to CFNRY");
                  CFWD_STATE = CFWD_NOREPLY;
                  val += 1;
               }
            }
         }
         //break;
      case CFWD_NOREPLY:
         {
            if(cfnrySsCode)
            {
               DLOG(0,0,"SS Count after adding CFNRY = %d",val+1);
               l_isd->provisonedSS.count = val+1;
               //formCfnrySS1(DlgId,l_isd->provisonedSS);
               formCfnrySS1(l_isd->provisonedSS);
               int len = g_AsnCodecO1.getEncodingLength(OMAP1_InsertSubscriberDataArg_PDU, l_isd);
               if(len > p_isdLen)
               {
                  DLOG(0,0,"Length limit exceeded on adding CFNRY CFWD info");
                  l_isd->provisonedSS.count -= 1;
                  CFWD_STATE = CFWD_NOREPLY;
                  if(val == 0)
                     return 1;
                  else
                     return 2;
                  break;
               }
               else
               {
                  DLOG(0,0,"CFNRY added, moving to CD");
                  CFWD_STATE = CALL_DEF;
                  val += 1;
               }
            }
         }
         //break;
      case CALL_DEF:
         {
            if(cdSsCode)
            {
               DLOG(0,0,"SS Count after adding CD = %d",val+1);
               l_isd->provisonedSS.count = val+1;
               //formCdSS1(DlgId,l_isd->provisonedSS);               
               formCdSS1(l_isd->provisonedSS);
               int len = g_AsnCodecO1.getEncodingLength(OMAP1_InsertSubscriberDataArg_PDU,l_isd);
               if(len > p_isdLen)
               {
                  DLOG(0,0,"Length limit exceeded on adding CD CFWD info");
                  l_isd->provisonedSS.count -= 1;
                  CFWD_STATE = CALL_DEF;
                  if(val == 0)
                     return 1;
                  else
                     return 2;
                  break;
               }
               else
               {
                  DLOG(0,0,"CD Added, all CFWD SS DATA Added");
                  CFWD_STATE = DEF;
                  val += 1;
               }
            }
         }
         //break;
      default:
      case DEF:
         return 0;
         //break;
   }
   return 0;
}

//int provisionedSS::formCbSS1(int DlgId,OMAP1_InsertSubscriberDataArg *l_isd, int p_isdLen)
int provisionedSS::formCbSS1(OMAP1_InsertSubscriberDataArg *l_isd, int p_isdLen)
{
   int l_len = p_isdLen;
   DLOG(0,0,"Inside Call Barring,SS Count here is %d,boacCount = %d , boicCount = %d, boihcCount = %d ISD Length formed till now %d ",val,boacCount,boicCount,boihcCount,l_len);
   switch(CB_STATE)
   {
      case CB_BOAC:
         {
            if(boacSsCode)
            {
               DLOG(0,0,"SS Count after adding BOAC = %d",val+1);
               l_isd->provisonedSS.count = val+1;
               //formboaSS1(DlgId,l_isd->provisonedSS);
               formboaSS1(l_isd->provisonedSS);


               //int len = l_len;
               //len += 7 + 3 + 3 + (l_isd->provisonedSS.value[l_isd->provisonedSS.count - 1].u.callBarringInfo.callBarringFeatureList.count * 9);


			   int len = g_AsnCodecO1.getEncodingLength(OMAP1_InsertSubscriberDataArg_PDU,l_isd);
               DLOG(0,0,"BOAC count is %d ISD len %d",l_isd->provisonedSS.value[l_isd->provisonedSS.count - 1].u.callBarringInfo.callBarringFeatureList.count,len);
               if(len >= g_MmConfigReaderObj->m_IsdLen)
               {
                  DLOG(0,0,"Length limit exceeded on adding BOAC CB info");
                  l_isd->provisonedSS.count -= 1;
                  CB_STATE = CB_BOAC;
                  if(val == 0)
                     return 1;
                  else
                     return 2;
                  break;
               }
               else
               {
                  DLOG(0,0,"Added BOAC CB info, moving to BOIC");
                  CB_STATE = CB_BOIC;
                  val += 1;
                  l_len = len;
               }
            }
         }
         //break;
      case CB_BOIC:
         {
            if(boicSsCode)
            {
               DLOG(0,0,"SS Count after adding BOIC = %d",val+1);
               l_isd->provisonedSS.count = val+1;
               //formboicSS1(DlgId,l_isd->provisonedSS);
               formboicSS1(l_isd->provisonedSS);


               //int len = l_len;
               //len += 7 + 3 + 3 + (l_isd->provisonedSS.value[l_isd->provisonedSS.count - 1].u.callBarringInfo.callBarringFeatureList.count * 9);


			   int len = g_AsnCodecO1.getEncodingLength(OMAP1_InsertSubscriberDataArg_PDU,l_isd);
               DLOG(0,0,"BOAC count is %d ISD len %d",l_isd->provisonedSS.value[l_isd->provisonedSS.count - 1].u.callBarringInfo.callBarringFeatureList.count,len);
               if(len >= g_MmConfigReaderObj->m_IsdLen)
               {
                  DLOG(0,0,"Length limit exceeded on adding BOIC CB info");
                  l_isd->provisonedSS.count -= 1;
                  CB_STATE = CB_BOIC;
                  if(val == 0)
                     return 1;
                  else
                     return 2;
                  break;
               }
               else
               {
                  DLOG(0,0,"Added BOIC CB info, moving to BOIHC");
                  CB_STATE = CB_BOIHC;
                  val += 1;
                  l_len = len;
               }
            }
         }
         //break;
      case CB_BOIHC:
         {
            if(boihcSsCode)
            {
               DLOG(0,0,"SS Count after adding BOIHC = %d",val+1);
               l_isd->provisonedSS.count = val+1;
               //formboihcSS1(DlgId,l_isd->provisonedSS);
               formboihcSS1(l_isd->provisonedSS);
               int len = g_AsnCodecO1.getEncodingLength(OMAP1_InsertSubscriberDataArg_PDU,l_isd);
			   DLOG(0,0,"SS len after adding BOIHC = %d",len);
               if(len >p_isdLen)
               {
                  DLOG(0,0,"Length limit exceeded on adding BOIHC CB info");
                  l_isd->provisonedSS.count -= 1;
                  CB_STATE = CB_BOIHC;
                  if(val == 0)
                     return 1;
                  else
                     return 2;  
                  break;
               }  
               else
               {
                  DLOG(0,0,"Added BOIHC CB info, moving to BAIC");
                  CB_STATE = CB_BAIC;
                  val += 1;
               }
            }
         }
         //break;
      case DEFA:
      default:
         return 0;
         break;
   }
   return 0;
}

//int provisionedSS::formSsSS1(int DlgId,OMAP1_InsertSubscriberDataArg *l_isd, int p_isdLen)
int provisionedSS::formSsSS1(OMAP1_InsertSubscriberDataArg *l_isd,int p_isdLen)
{
   int prevVal = l_isd->provisonedSS.count;
   DLOG(0,0,"Inside formSsSS1,SS Count here is %d,storing it as prevVal = %d, ISD length formed till now %d",val,prevVal,p_isdLen);
   //int l_count = formGenSS1(DlgId,l_isd->provisonedSS);
   int l_count = formGenSS1(l_isd->provisonedSS);
   DLOG(0,0,"SS Count after adding SS DATA is  %d",l_count);
   //int len2 = p_isdLen + 10 + (l_count * 6);
   int len2 = g_AsnCodecO1.getEncodingLength(OMAP1_InsertSubscriberDataArg_PDU,l_isd);
   if(len2 >= g_MmConfigReaderObj->m_IsdLen)
   {
      DLOG(0,0,"Length limit exeeded to %d while adding SS_Data,removing that alone",len2);
      DLOG(0,0,"Filled SS Count till %d,removing till prevVal %d",val,prevVal);
      l_isd->provisonedSS.count = prevVal;
      //if(val == 0)
      //    return 1;
      //else
      return 2;
      //break;
   }
   else
   {
      DLOG(0,0,"Length limit not exeeded after adding SS data");
      return 0;
   }
}

//void provisionedSS::formCfuSS1(int DlgId,OMAP1_SS_InfoList &l_isd)
void provisionedSS::formCfuSS1(OMAP1_SS_InfoList &l_isd)
{
   DLOG(0,0,"Filling CFU info, SS Count here is %d,SS-Code %d, cfu Count %d ",l_isd.count,cfuSsCode,cfuSsCount);
   l_isd.value[val].choice = OMAP1_forwardingInfo_chosen;
   l_isd.value[val].u.forwardingInfo.bit_mask = OMAP1_ForwardingInfo_ss_Code_present;
   l_isd.value[val].u.forwardingInfo.ss_Code.length = 1;
   l_isd.value[val].u.forwardingInfo.ss_Code.value[0] = cfuSsCode;
   l_isd.value[val].u.forwardingInfo.forwardingFeatureList.count = cfuSsCount;
   for(int cfu = 0;cfu < cfuSsCount;cfu++)
   {
      DLOG(0,0,"Basic service Code[%d] : %d, Basic service Type[%d]: %d",cfu,cfuBCode[cfu],cfu,cfuBType[cfu]);
      l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfu].ss_Status.length = 1;
      int l_SsStatus = cfuSsStatus[cfu];
      if((m_AllOGCallsBarresPresent == true) && (cfuSsStatus[cfu] == 7))
      {
            l_SsStatus = 15;
      }
      l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfu].ss_Status.value[0] = l_SsStatus;
      if(cfuBType[cfu])
      {         
         l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfu].bit_mask |= OMAP1_ForwardingFeature_basicService_present;
         if(cfuBType[cfu] == 1)
         {
            l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfu].basicService.choice = OMAP1_bearerService_chosen;
            l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfu].basicService.u.bearerService.length = 1;
            l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfu].basicService.u.bearerService.value[0] = cfuBCode[cfu];
         }
         else
         {
            l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfu].basicService.choice = OMAP1_teleservice_chosen;
            l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfu].basicService.u.teleservice.length = 1;
            l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfu].basicService.u.teleservice.value[0] = cfuBCode[cfu];
         }
      }        
   }
   DLOG(0,0,"Added CFWD Unconditional");
}

//void provisionedSS::formCdSS1(int DlgId,OMAP1_SS_InfoList &l_isd)
void provisionedSS::formCdSS1(OMAP1_SS_InfoList &l_isd)
{
   DLOG(0,0,"Filling  CD CFWD info, SS Count here is %d,SS-Code: %d, CD Data Count: %d",l_isd.count,cdSsCode,cdSsCount);
   l_isd.value[val].choice = OMAP1_forwardingInfo_chosen;
   l_isd.value[val].u.forwardingInfo.bit_mask = OMAP1_ForwardingInfo_ss_Code_present;
   l_isd.value[val].u.forwardingInfo.ss_Code.length = 1;
   l_isd.value[val].u.forwardingInfo.ss_Code.value[0] = cdSsCode;
   l_isd.value[val].u.forwardingInfo.forwardingFeatureList.count = cdSsCount;
   for(int cd = 0;cd < cdSsCount;cd++)
   {
      DLOG(0,0,"cdBCode[%d]: %d, cdBType[%d]: %d, cdSsStatus[%d]: %d, cdFTN[%d]: %s, cdFTS[%d]: %s, cdOPTN[%d]: %d,cdLFTN[%d]: %s",cd,cdBCode[cd],cd,cdBType[cd],cd,cdSsStatus[cd],cd,cdFTN[cd],cd,cdFTS[cd],cd,cdOPTN[cd],cd,cdLFTN[cd]);
      l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cd].ss_Status.length = 1;
      int l_SsStatus = cdSsStatus[cd];
      if((m_AllOGCallsBarresPresent == true) && (cdSsStatus[cd] == 7))
      {
            l_SsStatus = 15;
      }
      l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cd].ss_Status.value[0] = l_SsStatus;
      if(cdBType[cd])
      {
         l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cd].bit_mask |= OMAP1_ForwardingFeature_basicService_present;
         if(cdBType[cd] == 1)
         {
            l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cd].basicService.choice = OMAP1_bearerService_chosen;
            l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cd].basicService.u.bearerService.length = 1;
            l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cd].basicService.u.bearerService.value[0] = cdBCode[cd];
         }
         else
         {
            l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cd].basicService.choice = OMAP1_teleservice_chosen;
            l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cd].basicService.u.teleservice.length = 1;
            l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cd].basicService.u.teleservice.value[0] = cdBCode[cd];
         }
      }
      if((cdSsStatus[cd] == 6) || (cdSsStatus[cd] == 7))
      {
         if(strncmp((char*)cdFTN[cd],"0",1)!=0)
         {
            l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cd].bit_mask |= OMAP1_ForwardingFeature_forwardedToNumber_present;
            l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cd].forwardedToNumber.length = (strlen((char*)cdFTN[cd])+1)/2;
            StringToBCD(l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cd].forwardedToNumber.value,cdFTN[cd],strlen((char*)cdFTN[cd]));
         }
         if(1)//cdOPTN[cd] != 0)
         {
            l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cd].bit_mask |= OMAP1_ForwardingFeature_forwardingOptions_present;
            l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cd].forwardingOptions.length = 1;
            l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cd].forwardingOptions.value[0] = cdOPTN[cd];
         }
      }
      else
      {
         DLOG(0,0,"Call Deflection status is not active or registered");
      }
   }
   DLOG(0,0,"Added CFWD Call Deflection");
}

//void provisionedSS::formCfbSS1(int DlgId,OMAP1_SS_InfoList &l_isd)
void provisionedSS::formCfbSS1(OMAP1_SS_InfoList &l_isd)
{
   DLOG(0,0,"Filling CFB CFWD, SS Count here is %d, cfbSsCode: %d, cfbSsCount: %d",val,cfbSsCode,cfbSsCount);
   l_isd.value[val].choice = OMAP1_forwardingInfo_chosen;
   l_isd.value[val].u.forwardingInfo.bit_mask = OMAP1_ForwardingInfo_ss_Code_present;
   l_isd.value[val].u.forwardingInfo.ss_Code.length = 1;
   l_isd.value[val].u.forwardingInfo.ss_Code.value[0] = cfbSsCode;
   l_isd.value[val].u.forwardingInfo.forwardingFeatureList.count = cfbSsCount;
   for(int cfb = 0;cfb < cfbSsCount;cfb++)
   {
      DLOG(0,0,"cfbBCode[%d]: %d, cfbBType[%d]: %d, cfbSsStatus[%d]: %d, cfbFTN[%d]: %s,cfbFTS[%d]: %s,cfbOPTN[%d]: %d, cfbLFTN[%d]: %s",cfb,cfbBCode[cfb],cfb,cfbBType[cfb],cfb,cfbSsStatus[cfb],cfb,cfbFTN[cfb],cfb,cfbFTS[cfb],cfb,cfbOPTN[cfb],cfb,cfbLFTN[cfb]);
      l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].ss_Status.length = 1;
      int l_SsStatus = cfbSsStatus[cfb];
      if((m_AllOGCallsBarresPresent == true) && (cfbSsStatus[cfb] == 7))
      {
         l_SsStatus = 15;
      }
      l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].ss_Status.value[0] = l_SsStatus;
      if(cfbBType[cfb])
      {
         l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].bit_mask |= OMAP1_ForwardingFeature_basicService_present;
         if(cfbBType[cfb] == 1)
         {
            l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].basicService.choice = OMAP1_bearerService_chosen;
            l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].basicService.u.bearerService.length = 1;
            l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].basicService.u.bearerService.value[0] = cfbBCode[cfb];
         }
         else
         {
            l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].basicService.choice = OMAP1_teleservice_chosen;
            l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].basicService.u.teleservice.length = 1;
            l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].basicService.u.teleservice.value[0] = cfbBCode[cfb];
         }
      }
      if((cfbSsStatus[cfb] == 6) || (cfbSsStatus[cfb] == 7))
      {
         if(strncmp((char*)cfbFTN[cfb],"0",1)!=0)
         {
            l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].bit_mask |= OMAP1_ForwardingFeature_forwardedToNumber_present;
            l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].forwardedToNumber.length = (strlen((char*)cfbFTN[cfb])+1)/2;
            StringToBCD(l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].forwardedToNumber.value,cfbFTN[cfb],strlen((char*)cfbFTN[cfb]));
         }
         if(cfbOPTN[cfb] != 0)
         {
            l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].bit_mask |= OMAP1_ForwardingFeature_forwardingOptions_present;
            l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].forwardingOptions.length = 1;
            l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfb].forwardingOptions.value[0] = cfbOPTN[cfb];
         }
      }
      else
      {
         DLOG(0,0,"CFB ss status is not active or registered");
      }
   }
   DLOG(0,0,"Added CFWD Busy");
}

//void provisionedSS::formCfnrySS1(int DlgId,OMAP1_SS_InfoList &l_isd)
void provisionedSS::formCfnrySS1(OMAP1_SS_InfoList &l_isd)
{
   DLOG(0,0,"Filling CFNRY CFWD, SS Count here is %d, cfnrySsCode %d, cfnrySsCount %d",val,cfnrySsCode,cfnrySsCount);
   l_isd.value[val].choice = OMAP1_forwardingInfo_chosen;
   l_isd.value[val].u.forwardingInfo.bit_mask = OMAP1_ForwardingInfo_ss_Code_present;
   l_isd.value[val].u.forwardingInfo.ss_Code.length = 1;
   l_isd.value[val].u.forwardingInfo.ss_Code.value[0] = cfnrySsCode;
   l_isd.value[val].u.forwardingInfo.forwardingFeatureList.count = cfnrySsCount;
   for(int cfnry = 0;cfnry < cfnrySsCount;cfnry++)
   {
      DLOG(0,0,"cfnryBCode[%d]: %d, cfnryBType[%d]: %d, cfnryFTN[%d]: %s, cfnryFTS[%d]: %s, cfnryOPTN[%d]: %d, cfnryLFTN[%d]: %s",cfnry,cfnryBCode[cfnry],cfnry,cfnryBType[cfnry],cfnry,cfnryFTN[cfnry],cfnry,cfnryFTS[cfnry],cfnry,cfnryOPTN[cfnry],cfnry,cfnryLFTN[cfnry]);
      l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].ss_Status.length = 1;
      int l_SsStatus = cfnrySsStatus[cfnry];
      if((m_AllOGCallsBarresPresent == true) && (cfnrySsStatus[cfnry] == 7))
      {
            l_SsStatus = 15;
      }
      l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].ss_Status.value[0] = l_SsStatus;
      if(cfnryBType[cfnry])
      {
         l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].bit_mask |= OMAP1_ForwardingFeature_basicService_present;
         if(cfnryBType[cfnry] == 1)
         {
            l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].basicService.choice = OMAP1_bearerService_chosen;
            l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].basicService.u.bearerService.length = 1;
            l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].basicService.u.bearerService.value[0] = cfnryBCode[cfnry];
         }
         else
         {
            l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].basicService.choice = OMAP1_teleservice_chosen;
            l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].basicService.u.teleservice.length = 1;
            l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].basicService.u.teleservice.value[0] = cfnryBCode[cfnry];
         }
      }
      if((cfnrySsStatus[cfnry] == 6) || (cfnrySsStatus[cfnry] ==7) )
      {
         if(strncmp((char*)cfnryFTN[cfnry],"0",1)!= 0)
         {
            l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].bit_mask |= OMAP1_ForwardingFeature_forwardedToNumber_present;
            l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].forwardedToNumber.length = (strlen((char*)cfnryFTN[cfnry])+1)/2;
            StringToBCD(l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].forwardedToNumber.value,cfnryFTN[cfnry],strlen((char*)cfnryFTN[cfnry]));
         }
         if(cfnryOPTN[cfnry] != 0)
         {
            l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].bit_mask |= OMAP1_ForwardingFeature_forwardingOptions_present;
            l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].forwardingOptions.length = 1;
            l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].forwardingOptions.value[0] = cfnryOPTN[cfnry];
         }
         l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].bit_mask |= OMAP1_ForwardingFeature_noReplyConditionTime_present;
         l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnry].noReplyConditionTime = cfnryNRT[cfnry];
      }
      else
      {
         DLOG(0,0,"CFNRY ss status not active or registered");
      }
   }
   DLOG(0,0,"Added CFWD no reply");
}

//void provisionedSS::formCfnrcSS1(int DlgId,OMAP1_SS_InfoList &l_isd)
void provisionedSS::formCfnrcSS1(OMAP1_SS_InfoList &l_isd)
{
   DLOG(0,0,"Filling CFNRC CFWD info, SS Count here is %d, cfnrcSsCode: %d, cfnrcSsCount: %d",val,cfnrcSsCode,cfnrcSsCount);
   l_isd.value[val].choice = OMAP1_forwardingInfo_chosen;
   l_isd.value[val].u.forwardingInfo.bit_mask = OMAP1_ForwardingInfo_ss_Code_present;
   l_isd.value[val].u.forwardingInfo.ss_Code.length = 1;
   l_isd.value[val].u.forwardingInfo.ss_Code.value[0] = cfnrcSsCode;
   l_isd.value[val].u.forwardingInfo.forwardingFeatureList.count = cfnrcSsCount;
   for(int cfnrc = 0;cfnrc < cfnrcSsCount;cfnrc++)
   {
      DLOG(0,0,"cfnrcBCode[%d]: %d, cfnrcBType[%d]: %d, cfnrcSsStatus[%d]: %d, cfnrcFTN[%d] : %s, cfnrcFTS[%d] : %s, cfnrcLFTN[%d]: %s",cfnrc,cfnrcBCode[cfnrc],cfnrc,cfnrcBType[cfnrc],cfnrc,cfnrcSsStatus[cfnrc],cfnrc,cfnrcFTN[cfnrc],cfnrc,cfnrcFTS[cfnrc],cfnrc,cfnrcLFTN[cfnrc]);
      l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].ss_Status.length = 1;
      int l_SsStatus = cfnrcSsStatus[cfnrc];
      if((m_AllOGCallsBarresPresent == true) && (cfnrcSsStatus[cfnrc] == 7))
      {
            l_SsStatus = 15;
      }
      l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].ss_Status.value[0] = l_SsStatus;
      if(cfnrcBType[cfnrc])
      {
         l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].bit_mask |= OMAP1_ForwardingFeature_basicService_present;
         if(cfnrcBType[cfnrc] == 1)
         {
            l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].basicService.choice = OMAP1_bearerService_chosen;
            l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].basicService.u.bearerService.length = 1;
            l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].basicService.u.bearerService.value[0] = cfnrcBCode[cfnrc];
         }
         else
         {
            l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].basicService.choice = OMAP1_teleservice_chosen;
            l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].basicService.u.teleservice.length = 1;
            l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].basicService.u.teleservice.value[0] = cfnrcBCode[cfnrc];
         }
      }
      if(( cfnrcSsStatus[cfnrc] == 6) || ( cfnrcSsStatus[cfnrc] == 7))
      {
         if(strncmp((char*)cfnrcFTN[cfnrc],"0",1)!= 0)
         {
            l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].bit_mask |= OMAP1_ForwardingFeature_forwardedToNumber_present;
            l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].forwardedToNumber.length = (strlen((char*)cfnrcFTN[cfnrc])+1)/2;
            StringToBCD(l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].forwardedToNumber.value,cfnrcFTN[cfnrc],strlen((char*)cfnrcFTN[cfnrc]));
         }
         if(cfnrcOPTN[cfnrc] != 0)
         {
            l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].bit_mask |= OMAP1_ForwardingFeature_forwardingOptions_present;
            l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].forwardingOptions.length = 1;
            l_isd.value[val].u.forwardingInfo.forwardingFeatureList.value[cfnrc].forwardingOptions.value[0] = cfnrcOPTN[cfnrc];
         }
      }
      else
      {
         DLOG(0,0,"CFNRC SS status is not active or registered");
      }
   }
   DLOG(0,0,"Added Call Fwd on not rechable");
}

//void provisionedSS::formboaSS1(int DlgId,OMAP1_SS_InfoList &l_isd)
void provisionedSS::formboaSS1(OMAP1_SS_InfoList &l_isd)
{
   DLOG(0,0,"Forming BOAC,SS DATA count = %d, VAL %d, BOAC Count : %d",l_isd.count,val,boacCount);
   l_isd.value[val].choice = OMAP1_callBarringInfo_chosen;
   l_isd.value[val].u.callBarringInfo.ss_Code.length = 1;
   l_isd.value[val].u.callBarringInfo.ss_Code.value[0] = boacSsCode;
   l_isd.value[val].u.callBarringInfo.callBarringFeatureList.count = boacCount;
   for(int boac = 0;boac<boacCount;boac++)
   {
      DLOG(0,0,"Basic Service Code[%d]: %d, Basic Service Type[%d]: %d, SS-Status[%d]: %d",boac,boacBCode[boac],boac,boacBType[boac],boac,boacSsStatus[boac]);
      l_isd.value[val].u.callBarringInfo.callBarringFeatureList.value[boac].ss_Status.length = 1;
      l_isd.value[val].u.callBarringInfo.callBarringFeatureList.value[boac].ss_Status.value[0] = boacSsStatus[boac];
      if(boacBType[boac])
      {
         l_isd.value[val].u.callBarringInfo.callBarringFeatureList.value[boac].bit_mask |= OMAP1_basicServiceCode_present;
         if(boacBType[boac] == 1)
         {
            l_isd.value[val].u.callBarringInfo.callBarringFeatureList.value[boac].basicServiceCode.choice = OMAP1_bearerService_chosen;
            l_isd.value[val].u.callBarringInfo.callBarringFeatureList.value[boac].basicServiceCode.u.bearerService.length = 1;
            l_isd.value[val].u.callBarringInfo.callBarringFeatureList.value[boac].basicServiceCode.u.bearerService.value[0] = boacBCode[boac];
         }
         else
         {
            l_isd.value[val].u.callBarringInfo.callBarringFeatureList.value[boac].basicServiceCode.choice = OMAP1_teleservice_chosen;
            l_isd.value[val].u.callBarringInfo.callBarringFeatureList.value[boac].basicServiceCode.u.teleservice.length = 1;
            l_isd.value[val].u.callBarringInfo.callBarringFeatureList.value[boac].basicServiceCode.u.teleservice.value[0] = boacBCode[boac];
         }
      }
   }
   DLOG(0,0,"Finished adding Barring of all OutGoing Call");
}

//void provisionedSS::formboicSS1(int DlgId,OMAP1_SS_InfoList &l_isd)
void provisionedSS::formboicSS1(OMAP1_SS_InfoList &l_isd)
{
   DLOG(0,0,"Forming BOIC,SS DATA count = %d, val %d,BOIC Count : %d",l_isd.count,val,boicCount);
   l_isd.value[val].choice = OMAP1_callBarringInfo_chosen;
   l_isd.value[val].u.callBarringInfo.ss_Code.length = 1;
   l_isd.value[val].u.callBarringInfo.ss_Code.value[0] = boicSsCode;
   l_isd.value[val].u.callBarringInfo.callBarringFeatureList.count = boicCount;
   for(int boic = 0;boic<boicCount;boic++)
   {
      DLOG(0,0,"Basic Service Code[%d]: %d, Basic Service Type[%d]: %d, SS-Status[%d]: %d",boic,boicBCode[boic],boic,boicBType[boic],boic,boicSsStatus[boic]);
      l_isd.value[val].u.callBarringInfo.callBarringFeatureList.value[boic].ss_Status.length = 1;
      l_isd.value[val].u.callBarringInfo.callBarringFeatureList.value[boic].ss_Status.value[0] = boicSsStatus[boic];
      if(boicBType[boic])
      {
         l_isd.value[val].u.callBarringInfo.callBarringFeatureList.value[boic].bit_mask |= OMAP1_basicServiceCode_present;
         if(boicBType[boic] == 1)
         {
            l_isd.value[val].u.callBarringInfo.callBarringFeatureList.value[boic].basicServiceCode.choice = OMAP1_bearerService_chosen;
            l_isd.value[val].u.callBarringInfo.callBarringFeatureList.value[boic].basicServiceCode.u.bearerService.length = 1;
            l_isd.value[val].u.callBarringInfo.callBarringFeatureList.value[boic].basicServiceCode.u.bearerService.value[0] = boicBCode[boic];
         }
         else
         {
            l_isd.value[val].u.callBarringInfo.callBarringFeatureList.value[boic].basicServiceCode.choice = OMAP1_teleservice_chosen;
            l_isd.value[val].u.callBarringInfo.callBarringFeatureList.value[boic].basicServiceCode.u.teleservice.length = 1;
            l_isd.value[val].u.callBarringInfo.callBarringFeatureList.value[boic].basicServiceCode.u.teleservice.value[0] = boicBCode[boic];
         }
      }
   }
   DLOG(0,0,"Finished adding Barring of OutGoing International Call");
}

//void provisionedSS::formboihcSS1(int DlgId,OMAP1_SS_InfoList &l_isd)
void provisionedSS::formboihcSS1(OMAP1_SS_InfoList &l_isd)
{
   DLOG(0,0,"Forming BOIHC,SS DATA count = %d, VAL %d, BOIHC Count : %d",l_isd.count,val,boihcCount);
   l_isd.value[val].choice = OMAP1_callBarringInfo_chosen;
   l_isd.value[val].u.callBarringInfo.ss_Code.length = 1;
   l_isd.value[val].u.callBarringInfo.ss_Code.value[0] = boihcSsCode;
   l_isd.value[val].u.callBarringInfo.callBarringFeatureList.count = boihcCount;
   for(int boihc = 0;boihc<boihcCount;boihc++)
   {
      DLOG(0,0,"Basic Service Code[%d]: %d, Basic Service Type[%d]: %d, SS-Status[%d]: %d",boihc,boihcBCode[boihc],boihc,boihcBType[boihc],boihc,boihcSsStatus[boihc]);
      l_isd.value[val].u.callBarringInfo.callBarringFeatureList.value[boihc].ss_Status.length = 1;
      l_isd.value[val].u.callBarringInfo.callBarringFeatureList.value[boihc].ss_Status.value[0] = boihcSsStatus[boihc];
      if(boihcBType[boihc])
      {
         l_isd.value[val].u.callBarringInfo.callBarringFeatureList.value[boihc].bit_mask |= OMAP1_basicServiceCode_present;
         if(boihcBType[boihc] == 1)
         {
            l_isd.value[val].u.callBarringInfo.callBarringFeatureList.value[boihc].basicServiceCode.choice = OMAP1_bearerService_chosen;
            l_isd.value[val].u.callBarringInfo.callBarringFeatureList.value[boihc].basicServiceCode.u.bearerService.length = 1;
            l_isd.value[val].u.callBarringInfo.callBarringFeatureList.value[boihc].basicServiceCode.u.bearerService.value[0] = boihcBCode[boihc];
         }
         else
         {
            l_isd.value[val].u.callBarringInfo.callBarringFeatureList.value[boihc].basicServiceCode.choice = OMAP1_teleservice_chosen;
            l_isd.value[val].u.callBarringInfo.callBarringFeatureList.value[boihc].basicServiceCode.u.teleservice.length = 1;
            l_isd.value[val].u.callBarringInfo.callBarringFeatureList.value[boihc].basicServiceCode.u.teleservice.value[0] = boihcBCode[boihc];
         }
      }
   }
   DLOG(0,0,"Finished adding Barring of OutGoing International Call");
}

//int  provisionedSS::formGenSS1(int DlgId,OMAP1_SS_InfoList &l_isd)
int  provisionedSS::formGenSS1(OMAP1_SS_InfoList &l_isd)
{
   DLOG(0,0,"Inside Gen SS, GEN_SS DATA Count = %d",SsCount);
   for(int ss = 0;ss<SsCount;ss++)
   {
      DLOG(0,0,"SS DATA Count = %d, SS Code : %d, SS Status : %d",l_isd.count,SsCode[ss],SsStatus[ss]);
      l_isd.value[val].choice = OMAP1_ss_Data_chosen;
      l_isd.value[val].u.ss_Data.ss_Code.length = 1;
      l_isd.value[val].u.ss_Data.ss_Code.value[0] = SsCode[ss];
      l_isd.value[val].u.ss_Data.bit_mask = OMAP1_SS_Data_ss_Status_present;
      l_isd.value[val].u.ss_Data.ss_Status.length = 1;
      l_isd.value[l_isd.count].u.ss_Data.ss_Status.value[0] = SsStatus[ss];      
      l_isd.count = val+1;
      val++;// = val+1;
      DLOG(0,0,"Added GEN_SS[%d],Count here is %d",ss,l_isd.count);
   }
   DLOG(0,0,"Added Generel SS data");
   return l_isd.count;
}
//END MAP1
