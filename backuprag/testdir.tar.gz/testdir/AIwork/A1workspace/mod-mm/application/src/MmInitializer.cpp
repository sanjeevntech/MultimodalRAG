#include <MapMessages.h>
#include <ContextBase.h>
#include <ModuleBase.h>
#include <MmConfigReader.h>
#include <Logger.h>
#include <CtxtUpdateLocation.h>
#include <CtxtSimUpdateLocation.h>
#include <CtxtPurgeMS.h>
#include <CtxtUpdateGPRSLocation.h>
#include <CtxtSimUpdateGprsLocation.h>
#include <CtxtSimRestoreData.h>
#include <CtxtCancelLocation.h>
#include <CtxtScpSendParameters.h>
#include <StandaloneISD.h>
#include <SnmpInterface.h>
#include <MmSimConfigReader.h>
#include <CtxtSimReset.h>

int g_UpdateLocationGsmTrap=-1;
int g_UpdateLocationGprsTrap=-1;
int g_FreeMsisdnRemainingTrap=-1;
int g_TransientMsisdnUnavailableTrap = -1;
int g_LocalMsisdnUnavailableTrap = -1;
int g_LocalMsisdnThresholdTrap = -1;
int g_TransientMsisdnThresholdTrap = -1;
int g_DynamicAllocFailTrap = -1;

extern bool g_loadFlag;

extern "C" {
   ModuleBase *getModuleObj();
}

class MmModule : public ModuleBase
{
   public:
      MmModule(){}
      bool initModule();
      ContextBase *getCtxtObj(EMapOpCode, MapSpecificMsg*);
      ContextBase *getCtxtObj(EDiameterCommandCode, DiameterMsg*);
      ContextBase *getCtxtObj(EMapOpCode, SccpMsg*);
      char *getVersion();
      ConfigReader *getConfigReaderObj();
      ConfigReader **retrieveConfigReaderPtr();
};

MmModule g_MmModule;

ModuleBase *getModuleObj()
{
   return &g_MmModule;
}

char *MmModule::getVersion()
{
   RETURN_VERSION (APP_VERSION);//2.0.23.0_Rev1 2.0.23.0 //2.0.21.0_Rev2 //2.0.21.0 
}

bool MmModule::initModule()
{
   if(true == g_loadFlag)
   {
     m_modName="UPS";
   }
   else
   {
   m_modName="MM";
   LLOG(0,0,"MM  APPVER-v:%s ci:%s cd:%s comp:%s %s", APP_VERSION, COMMIT_ID, COMMIT_DATE,__DATE__,__TIME__);
   moduleLevelAddHeader("CrossCLTowardsVLR", MODULE_STATS_TYPE_TOTAL_SUCCESS);
   moduleLevelAddHeader("CrossCLTowardsSGSN", MODULE_STATS_TYPE_TOTAL_SUCCESS);
   moduleLevelAddHeader("PrimMSISDNAllocatedinUL", MODULE_STATS_TYPE_NORMAL);
   moduleLevelAddHeader("PrimMSISDNAllocatedinUGL", MODULE_STATS_TYPE_NORMAL);
   //moduleLevelAddHeader("InterestedForAllocImsiAPICall", MODULE_STATS_TYPE_NORMAL);
   //moduleLevelAddHeader("InterestedForAltImsiTrigger", MODULE_STATS_TYPE_TOTAL_SUCCESS);
#if 0
   if (NULL == g_MmConfigReaderObj)
   {
      printf("\n\n Error: MmConfigReaderObj is Null\n");
      return false;
   }
   if (false == g_MmConfigReaderObj->m_derivedObjectInitializedFlag)
   {
      printf("\n\nERROR: MM specific configuration file reading is mandatory\n");
      return false;
   }
#endif
   g_UpdateLocationGsmTrap          = g_si.registerSnmpTrap("GSM_UPD_LOC",         "GSM Update Location", MM_TRAP_SEQ_ID_ONE);
   g_UpdateLocationGprsTrap         = g_si.registerSnmpTrap("GPRS_UPD_LOC",        "GPRS Update Location", MM_TRAP_SEQ_ID_TWO);
   g_FreeMsisdnRemainingTrap        = g_si.registerSnmpTrap("MIN_DYNAMIC_MSISDN",  "Remaining Free MSISDN", MM_TRAP_SEQ_ID_THREE);
   g_TransientMsisdnUnavailableTrap = g_si.registerSnmpTrap("TRANS_MSISDN_UNAVAIL","Transient MSISDN Unavailable", MM_TRAP_SEQ_ID_FOUR);
   g_LocalMsisdnUnavailableTrap     = g_si.registerSnmpTrap("LOCAL_MSISDN_UNAVAIL","Local MSISDN Unavailable", MM_TRAP_SEQ_ID_FIVE);
   g_LocalMsisdnThresholdTrap       = g_si.registerSnmpTrap("LOCAL_MSISDN_THRESH", "Local MSISDN Threshold reached", MM_TRAP_SEQ_ID_SIX);
   g_TransientMsisdnThresholdTrap   = g_si.registerSnmpTrap("TRANS_MSISDN_THRESH", "Transient MSISDN Threshold reached", MM_TRAP_SEQ_ID_SEVEN);
   g_DynamicAllocFailTrap           = g_si.registerSnmpTrap("DYNAMIC_ALLOC_FAIL", "Dynamic Msisdn Alloc Fail", MM_TRAP_SEQ_ID_EIGHT);
  }
   return true;
}


ContextBase *MmModule::getCtxtObj(EMapOpCode p_OpCode, MapSpecificMsg *p_msg)
{
   EMapOpCode l_OpCode;
   if(p_msg != NULL)
   {
      l_OpCode = p_msg->m_OpCode;
      DLOG(0,0,"getCtxtObj opcode:%d",l_OpCode);
   }
   else
   {
      DLOG(0,0,"getCtxtObj opcode:%d",l_OpCode);
      l_OpCode = p_OpCode;
      if(103 == l_OpCode)
      {
          DLOG(0,0,"getCtxtObj changed to 3 - cancelLocation");
          l_OpCode=(EMapOpCode)3; //For Cancel Location 
      }
   }
   DLOG(0,0,"Rcvd OpCode [%d] ",l_OpCode);
   switch (l_OpCode)
   {
      case MAP_OP_CODE_updateLocation://OpCode = 2
         {
         if(false == g_loadFlag)
         {
            TLOG(0,0,"Newing CtxtUpdateLocation");
            return new CtxtUpdateLocation;
         }
         else
         {
            TLOG(0,0,"Newing Simulator CtxtSimUpdateLocation");
            return new CtxtSimUpdateLocation;
         }
         }
         break;

      case MAP_OP_CODE_reset:
         {
         if(false == g_loadFlag)
         {
            WLOG(0,0,"Not supported");
            return NULL;
         }
         else
         {
            TLOG(0,0,"Newing Simulator CtxtSimReset");
            return new CtxtSimReset;
         }
         }
         break;

      case MAP_OP_CODE_sendParameters://OpCode = 9
         {
            DLOG(0,0,"Rcvd MAP_OP_CODE_sendParameters");
            if (false == p_msg->m_allocatedFlag)
            {
               CLOG(0,0,"m_allocatedFlag is false for SPR");
               return NULL;
            }
            else
            {
               bool l_intendedForMmFlag=false;
               IMAP1_SendParametersArg *l_temp = (IMAP1_SendParametersArg*)(p_msg->m_structBuffer);
               struct IMAP1_RequestParameters_ *l_rp = NULL;
               l_rp = l_temp->requestParameters;
               while (l_rp != NULL)
               {
                  if (IMAP1_request_SubscriberData == l_rp->value)
                  {
                     TLOG(0,0,"OMAP1_request_SubscriberData found in the list");
                     l_intendedForMmFlag=true;
                     break;
                  }
                  l_rp = l_rp->next;
               }

               if (true == l_intendedForMmFlag)
               {
                  LLOG(0,0,"Newing an object for Send Parameters SSN:%d", g_currentOpenIndPtr->m_OrigAddr.ssn);
                  //if(146 == g_currentOpenIndPtr->m_OrigAddr.ssn)
                  if(g_MmConfigReaderObj->m_scpSSN == g_currentOpenIndPtr->m_OrigAddr.ssn)
                  {
                     DLOG(0,0,"Returning CtxtScpSendParameters");
                     return new CtxtScpSendParameters;
                  }
                  else
                  {
                     DLOG(0,0,"Returning CtxtUpdateLocation");
                     return new CtxtUpdateLocation;
                  }
                  //return NULL;
               }
               else
               {
                  CLOG(0,0,"Not Intended for MM");
                  return NULL;
               }
            }
         }
         break;

      case MAP_OP_CODE_updateGprsLocation://OpCode = 23
         {
		 if(false == g_loadFlag)
		 {
			 TLOG(0,0,"Newing CtxtUpdateGprsLocation");
			 return new CtxtUpdateGPRSLocation;
		 }
                 else
                 {
			 TLOG(0,0,"Newing Simulator CtxtUpdateGprsLocation");
			 return new CtxtSimUpdateGprsLocation;
                 }
	 }
	 break;


      case MAP_OP_CODE_restoreData://OpCode = 57

    {
       if(false == g_loadFlag)
       {
          TLOG(0,0,"Newing CtxtUpdateLocation");
          //return new CtxtRestoreData;
          return new CtxtUpdateLocation;
       }
       else
       {
          TLOG(0,0,"Newing Simulator CtxtSimRestoreData");
          return new CtxtSimRestoreData;
       }
	 }
    
	 break;

      case MAP_OP_CODE_purgeMS: //Opcode = 67
	 {
		 TLOG(0,0,"Newing CtxtPurgeMS");
		 return new CtxtPurgeMS;
	 }
	 break;

      case MAP_OP_CODE_cancelLocation: //Opcode = 3
	 {
		 TLOG(0,0,"Newing Cancel Location");
		 return new CtxtCancelLocation;
	 }
	 break;

      case MAP_OP_CODE_insertSubscriberData: //Opcode = 7
	 {
		 TLOG(0,0,"Newing StandaloneISD");
		 return new StandaloneISD;
	 }
	 break;

   /*   case 107:
	 {
		 TLOG(0,0,"Newing CtxtUpdateLocation for ISD");
		 return new CtxtUpdateLocation;
	 }
	 break;

      case 108:
    {
       TLOG(0,0,"Newing CtxtUpdateGPRSLocation for ISD");
       return new CtxtUpdateGPRSLocation;
    }
    break;*/

      default:
	 ELOG(0,0,"\ngetCtxtObj Unknown OpCode [%d] for MMM\n",l_OpCode);
	 return NULL;
	 break;
   }
}

ContextBase *MmModule::getCtxtObj(EDiameterCommandCode p_OpCode, DiameterMsg* p_msg)
{
	ELOG(0,0,"Diameter Message not supported");
	return NULL;
}

ContextBase *MmModule::getCtxtObj(EMapOpCode p_OpCode, SccpMsg* p_msg)
{
   ELOG(0,0,"SCCP message not supported");
   return NULL;
}

ConfigReader *MmModule::getConfigReaderObj()
{
	if(true == g_loadFlag)
	{
		LLOG(0,0,"Returning g_MmSimConfigReaderObj");
		return (g_MmSimConfigReaderObj = new MmSimConfigReader);
	}
   LLOG(0,0,"Returning g_MmConfigReaderObj");
   //return (g_MmConfigReaderObj = new MmConfigReader);
   return new MmConfigReader;
}

ConfigReader **MmModule::retrieveConfigReaderPtr()
{
   if(true == g_loadFlag)
   {
      LLOG(0,0,"ConfigReader Sim **MmModule::retrieveConfigReaderPtr() called");
      return (ConfigReader **)&g_MmSimConfigReaderObj;
   }
   LLOG(0,0,"ConfigReader **MmModule::retrieveConfigReaderPtr() called");
   return (ConfigReader **)&g_MmConfigReaderObj;
}

bool DeclareFunc(int p_version, int p_pdu, void *p_struct)
{
   switch (p_version)
   {
      case 3:
         {   
            DLOG(0,0,"Received PDU number %d",p_pdu);
            switch(p_pdu)
            {  

               //DECLARE(OMAP3_InsertSubscriberDataArg,l_isd,3);
               case OMAP3_InsertSubscriberDataArg_PDU:
                  {
                     TLOG(0,0,"MEMSET values for ISD version 3");
                     OMAP3_InsertSubscriberDataArg *l_isd = (OMAP3_InsertSubscriberDataArg*) p_struct;
                     //For All bit mask
                     l_isd->bit_mask = 0;
                     l_isd->odb_Data.bit_mask = 0;
                     l_isd->vlrCamelSubscriptionInfo.bit_mask = 0;
                     l_isd->sgsn_CAMEL_SubscriptionInfo.bit_mask = 0;

                     //Can't help these
                     memset(&l_isd->provisionedSS,'\0',sizeof(OMAP3_Ext_SS_InfoList));
                     memset(&l_isd->vlrCamelSubscriptionInfo,'\0',sizeof(OMAP3_VlrCamelSubscriptionInfo));
                     memset(&l_isd->sgsn_CAMEL_SubscriptionInfo,'\0',sizeof(OMAP3_SGSN_CAMEL_SubscriptionInfo));
                     memset(&l_isd->gprsSubscriptionData,'\0',sizeof(OMAP3_GPRSSubscriptionData));


                     //All Lengths
                     l_isd->msisdn.length = 0;
                     l_isd->category.length = 0;
                     l_isd->subscriberStatus = (OMAP3_SubscriberStatus)0;
                     l_isd->networkAccessMode = (OMAP3_NetworkAccessMode)0;
                     l_isd->istAlertTimer = 0;
                     //Counts
                     l_isd->bearerServiceList.count = 0;
                     l_isd->teleserviceList.count = 0;
                     l_isd->provisionedSS.count = 0;
                     l_isd->vlrCamelSubscriptionInfo.bit_mask = 0;
                     l_isd->odb_Data.odb_GeneralData.length = 0;
                     l_isd->vlrCamelSubscriptionInfo.o_CSI.o_BcsmCamelTDPDataList.count = 0;
                     l_isd->vlrCamelSubscriptionInfo.ss_CSI.ss_CamelData.ss_EventList.count = 0;


                     DLOG(0,0,"Memset for ISD version 3");
                     return true; 
                  }
                  break;

               default:
                  {
                     DLOG(0,0,"In the default case");
                     return false;
                  }
                  break;
            }
         }
      case 2:
         {   
            switch(p_pdu)
            {  
               //DECLARE(OMAP2_InsertSubscriberDataArg,l_isd,2);
               /*case OMAP2_InsertSubscriberDataArg_PDU:
                 {
                 OMAP3_InsertSubscriberDataArg *l_isd = (OMAP3_InsertSubscriberDataArg*) p_struct;
                 LLOG(0,0,"Memset for ISD version 2");
                 return true; 
                 }
                 break;*/
               default:
                  {
                     DLOG(0,0,"In the default case");
                     return false;
                  }
                  break;
            }
         }
      case 1:
         {   
            switch(p_pdu)
            {  
               //DECLARE(OMAP1_InsertSubscriberDataArg,l_isd,1);
               /*case OMAP1_InsertSubscriberDataArg:
                 {
                 OMAP1_InsertSubscriberDataArg *l_isd = (OMAP1_InsertSubscriberDataArg*) p_struct;
                 LLOG(0,0,"Memset for ISD version 1");
                 return true; 
                 }
                 break;*/
               default:
                  {
                     DLOG(0,0,"In the default case");
                     return false;
                  }
                  break;
            }
         }
      default :
         {        
            CLOG(0,0,"Unknown version");
            return false;
         }                      
   }                 
}





