/*******************************************************************************************
 * File        : CtxtPurgeMS.cpp
 * Author      : VenkatRaman
 * Description : To handle Purge MS request 
 * Created on April 22, 2010, 6:00 PM IST
 *******************************************************************************************/

#include <CtxtPurgeMS.h>
#include <stdio.h>
#include <MapMessages.h>
#include <ServiceCoordinator.h>
#include <Logger.h>
#include <IMAP1.h>
#include <OMAP1.h>
#include <IMAP2.h>
#include <OMAP2.h>
#include <IMAP3.h>
#include <OMAP3.h>
#include <DataUnion.h>
#include <DbActiveObject.h>
#include <Utilities.h>
#include <CommonDefines.h>
#include <MmConfigReader.h>
#include <sys/time.h>

CtxtPurgeMS::CtxtPurgeMS()
{
   DLOG(0, 0, "CtxtPurgeMS::CtxtPurgeMS()");
   flag = false;
   m_freezeReqd = false;   
   l_Version = 0;
   m_UlInvokeId = 0;
}

CtxtPurgeMS::~CtxtPurgeMS()
{
   DLOG(0, 0, "CtxtPurgeMS::~CtxtPurgeMS()");
}

bool CtxtPurgeMS::processMessage(Msg *p_MsgPtr,bool &p_DeleteFlag)
{
   DLOG(0, 0, "Start of CtxtPurgeMS::processMsg function Delete flag is %d",p_DeleteFlag);
   MapSpecificMsg *l_specMsg = NULL;
   int l_dlgId = 0;
   int l_UserDlgId;
   //EMapOpCode l_OpCode;


   switch (p_MsgPtr->m_MsgType)
   {
      case MSG_TYPE_MAP:
         switch (((MapMsg*) p_MsgPtr)->m_MapMsgType)
         {
            case MAP_MSG_TYPE_COMMON:
               switch (((MapCommonMsg*) p_MsgPtr)->m_MapCommonMsgType)
               {
                  case MAP_CMN_OPEN_IND:
                     {
                        DLOG(0, 0, "MAP_CMN_OPEN_IND received");
                        //MapOpenInd *l_test = (MapOpenInd*) p_MsgPtr;
                        //OpenInd(l_test);
                     }
                     break;

                  case MAP_CMN_DELIMITER_IND:
                     DLOG(0, 0, "MAP_CMN_DELIMITER_IND received");
                     break;

                  case MAP_CMN_CLOSE_IND:
                     {
                        LLOG(0, 0, "MAP_CMN_CLOSE_IND received");                        
                        return true;
                     }
                     break;

                  case MAP_CMN_U_ABORT_IND:
                     WLOG(0, 0, "MAP_CMN_U_ABORT_IND received");
                     m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_U_ABORT_RCVD);
                     break;

                  case MAP_CMN_P_ABORT_IND:
                     WLOG(0, 0, "MAP_CMN_P_ABORT_IND received");
                     m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_P_ABORT_RCVD);
                     break;

                  case MAP_CMN_NOTICE_IND:
                     {
                        struct timeval tim;
                     #ifdef Linux
                        gettimeofday(&tim, NULL);
                     #else
                        gettimeofday(&tim);
                     #endif
                        struct tm *l_timeStruct=NULL;
                        //char *l_dateString=NULL;
                        time_t l_tim =time(NULL);
                        l_timeStruct = localtime(&l_tim);
                        char tim1[100];
                        memset(tim1,'\0',100);
                        sprintf(tim1, "%.6f",l_timeStruct->tm_sec+(tim.tv_usec/1000000.0));
                        LLOG(0, 0, "%d-TS:MAP_NOTICE_IND received at Time %s",((MapMsg*)p_MsgPtr)->m_UserDlgId,tim1);

                        MapCloseReq l_closeReq(((MapMsg*)p_MsgPtr)->m_UserDlgId);
                        l_closeReq.m_CloseType = MAP_CLOSE_TYPE_PRE_ARRANGED_END;
                        g_sc.sendMsg(this, &l_closeReq);
                        m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_NOTICE_RCVD);
                     }
                     break;

                  default:
                     DLOG(0, 0, "Unknown Msg received [%d]", ((MapCommonMsg*) p_MsgPtr)->m_MapCommonMsgType);
                     break;
               }
               break;

            case MAP_MSG_TYPE_SPECIFIC:
               {
                  DLOG(0, 0, "MAP_MSG_TYPE_SPECIFIC received");
                  l_specMsg = (MapSpecificMsg*) p_MsgPtr;
                  l_UserDlgId = l_specMsg->m_UserDlgId;
                  DLOG(0, 0, "MAP_MSG_TYPE_SPECIFIC received dlgId[%d] UserDlgId[%d]",l_dlgId, l_UserDlgId);
                  switch (((MapSpecificMsg*) p_MsgPtr)->m_MapSpecificEventType)
                  {
                     case MAP_SPEC_EVENT_INDICATION:
                        {
                           l_UserDlgId = p_MsgPtr->m_UserDlgId;
                           l_Version = ((MapSpecificMsg*)p_MsgPtr)->m_Version;
                           TLOG(0, 0, "MAP_SPEC_EVENT_INDICATION received for dlgId[%d] UserDlgId[%d], OpCode [%d], Version[%d]",l_dlgId, l_UserDlgId,(int)((MapSpecificMsg*) p_MsgPtr)->m_OpCode,l_Version);                           
                           switch (((MapSpecificMsg*) p_MsgPtr)->m_OpCode)
                           {
                              case MAP_OP_CODE_purgeMS ://OpCode = 67 (43 in Hexa)
                                 {
                                    DLOG(0, 0, "Received Purge MS request");
                                    /*struct timeval tim;
                                    gettimeofday(&tim);
                                    struct tm *l_timeStruct=NULL;
                                    //char *l_dateString=NULL;
                                    time_t l_tim =time(NULL);
                                    l_timeStruct = localtime(&l_tim);
                                    char tim1[100];
                                    memset(tim1,'\0',100);
                                    sprintf(tim1, "%.6f",l_timeStruct->tm_sec+(tim.tv_usec/1000000.0));*/
                                    LLOG(0, 0, "%d-TS:Received Purge MS Request, Opcode %d, Version : %d ",l_UserDlgId,((MapSpecificMsg*) p_MsgPtr)->m_OpCode,((MapSpecificMsg*)p_MsgPtr)->m_Version);

                                    switch(l_Version)
                                    {
                                       case 2:
                                          {
                                             if (false == ((MapSpecificMsg*)p_MsgPtr)->m_allocatedFlag)
                                             {
                                                RetErrorV2(l_UserDlgId,UnexpectedData);
                                             }
                                             else
                                             {
                                                IMAP2_PurgeMS_Arg *l_pms = (IMAP2_PurgeMS_Arg*) (((MapSpecificMsg*) p_MsgPtr)->m_structBuffer);
                                                DLOG(0,0,"Reveived Purge MS version 2 message");
                                                if(true == CheckParametersV2(l_UserDlgId,l_pms))
                                                {
                                                   DLOG(0,0,"Check parameters success, calling DB query to retrieve Subscriber profile");
                                                   l_msg = m_rgsm;
                                                   PurgeGSM(l_UserDlgId,l_imsi,l_vlr);
                                                }
                                                else
                                                {
                                                   DLOG(0,0,"Check parameters fail, sending error and closing");
                                                   RetErrorV2(l_UserDlgId,UnexpectedData);
                                                }
                                             }
                                          }
                                          break;
                                       case 3:
                                          {
                                             if (false == ((MapSpecificMsg*)p_MsgPtr)->m_allocatedFlag)
                                             {
                                                RetErrorV3(l_UserDlgId,UnexpectedData);
                                             }
                                             else
                                             {
                                                IMAP3_PurgeMS_Arg *l_pms = (IMAP3_PurgeMS_Arg*) (((MapSpecificMsg*) p_MsgPtr)->m_structBuffer);
                                                DLOG(0,0,"Reveived Purge MS version 3 Message");
                                                if(false == CheckParametersV3(l_UserDlgId,l_pms))
                                                   return false;
                                             }
                                          }
                                          break;
                                       default:
                                          ELOG(0,0,"Unknown version Purge MS received");
                                          break;
                                    }
                                 }
                                 break;

                              default:
                                 CLOG(0, 0, "Received Unknown Specific Message");
                                 break;
                           }
                           return true;
                        }
                        break;

                     case MAP_SPEC_EVENT_RESULT:
                        {
                           DLOG(0, 0, "MAP_SPEC_EVENT_RESULT received");
                        }
                        break;

                     case MAP_SPEC_EVENT_CONFIRMATION:
                        {
                           DLOG(0, 0, "MAP_SPEC_EVENT_CONFIRMATION received");
                           switch (((MapSpecificMsg*) p_MsgPtr)->m_OpCode)
                           {
                              default:
                                 break;
                           }
                        }
                        break;

                     case MAP_SPEC_EVENT_USER_ERROR:
                        {
                           unsigned short l_errCode = ((MapUserError*)p_MsgPtr)->m_ErrorCode;
                           WLOG(0, 0, "MAP_SPEC_EVENT_USER_ERROR %d received",l_errCode);
                           m_tdr.setInteger(TDR_INDEX_ERR_CODE,l_errCode);
                           CloseReq(l_UserDlgId);
                        }
                        break;

                     case MAP_SPEC_EVENT_PROV_ERROR:
                        {
                           WLOG(0, 0, "MAP_SPEC_EVENT_PROV_ERROR received");
                           m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_PROVIDER_ERROR_RCVD);
                           //CloseReq(l_UserDlgId);
                        }
                        break;
                     default:
                        CLOG(0, 0, "ERROR!! Default received");
                        break;
                  }
               }
               break;

            default:
               break;
         }
         break;

      case MSG_TYPE_DB:
         {
            DLOG(0, 0, "DB message received");
            /*struct timeval tim;
            gettimeofday(&tim);
            //double t1=tim.tv_sec+(tim.tv_usec/1000000.0);
            struct tm *l_timeStruct=NULL;
            //char *l_dateString=NULL;
            time_t l_tim =time(NULL);
            l_timeStruct = localtime(&l_tim);
            char tim1[100];
            memset(tim1,'\0',100);
            sprintf(tim1, "%.6lf",l_timeStruct->tm_sec+(tim.tv_usec/1000000.0));*/
            switch(l_msg)
            {
               case m_rgsm:
                  {
                     PurgeMS *l_rgsm = (PurgeMS *) p_MsgPtr;
                     l_UserDlgId = l_rgsm->m_UserDlgId;
                     m_tdr.setInteger(TDR_INDEX_MM_NETWORK_ID,l_rgsm->m_nwid); 
                     TLOG(0,0,"%d-TS:DB msg received for PURGE_VLR req",l_UserDlgId);
                     if(l_rgsm->m_ErrorCode != 0)
                     {
                        m_tdr.setInteger(TDR_INDEX_DB_ERR_CODE,l_rgsm->m_ErrorCode); 
                        m_tdr.setString(TDR_INDEX_DB_ERR_DESC,(char *)l_rgsm->m_ErrorMsg);
                     }
                     if(l_rgsm->m_DbQueryRes == DB_QUERY_RES_SUCCESS)
                     {
                        if(l_rgsm->m_ErrorCode == 0)     
                        {
                           if(l_rgsm->m_ImsiPartType != 0)
                           {
                              m_tdr.setInteger(TDR_INDEX_PARTNER_TYPE,l_rgsm->m_ImsiPartType); 
                              m_tdr.setInteger(TDR_INDEX_REQUEST_DOMAIN,1);
                           }
                           if(strlen((char *)l_rgsm->m_HlrAddr) > 1)
                              sendMapOpenResponse(l_UserDlgId,(char *)l_rgsm->m_HlrAddr,g_ConfigData->i_NgConfigData.m_selfAddress.ssn);
                           m_freezeReqd = true;
                        }
                        if(l_rgsm->m_ErrorCode == 3)
                        {
                           if(strlen((char *)l_rgsm->m_HlrAddr) > 1)
                              sendMapOpenResponse(l_UserDlgId,(char *)l_rgsm->m_HlrAddr,g_ConfigData->i_NgConfigData.m_selfAddress.ssn);
                           m_freezeReqd = false;
                        }
                        LLOG(0,0,"DB response successful, Sending response");
                        if(l_Version == 3)
                           VLRResponseV3(l_UserDlgId);
                        else
                           VLRResponseV2(l_UserDlgId);
                     }
                     else
                     {
                        WLOG(0,0,"DB resopnse for Retrieve GSM profile data Not success,sending Unknown subscriber and closeing");
                        if(l_Version == 3)
                           RetErrorV3(l_UserDlgId,UnknownSubscriber);
                        else
                           RetErrorV2(l_UserDlgId,UnknownSubscriber);
                     }                     
                  }
                  break;
               case m_rgprs:
                  {
                     PurgeMS *l_rgprs = (PurgeMS *) p_MsgPtr;
                     l_UserDlgId = l_rgprs->m_UserDlgId;
                     TLOG(0,0,"%d-TS:DB msg received for PURGE_SGSN req ",l_UserDlgId);
                     m_tdr.setInteger(TDR_INDEX_MM_NETWORK_ID,l_rgprs->m_nwid); 
                     if(l_rgprs->m_ErrorCode != 0)
                     {
                        m_tdr.setInteger(TDR_INDEX_DB_ERR_CODE,l_rgprs->m_ErrorCode); 
                        m_tdr.setString(TDR_INDEX_DB_ERR_DESC,(char *)l_rgprs->m_ErrorMsg);
                     }
                     if(l_rgprs->m_DbQueryRes == DB_QUERY_RES_SUCCESS)
                     {
                        if(l_rgprs->m_ErrorCode == 0)     
                        {
                           if(l_rgprs->m_ImsiPartType != 0)
                           {
                              m_tdr.setInteger(TDR_INDEX_PARTNER_TYPE,l_rgprs->m_ImsiPartType); 
                              m_tdr.setInteger(TDR_INDEX_REQUEST_DOMAIN,2);
                           }
                           if(strlen((char *)l_rgprs->m_HlrAddr) > 1)
                              sendMapOpenResponse(l_UserDlgId,(char *)l_rgprs->m_HlrAddr,g_ConfigData->i_NgConfigData.m_selfAddress.ssn);
                           m_freezeReqd = true;
                        }
                        if(l_rgprs->m_ErrorCode == 3)
                        {
                           if(strlen((char *)l_rgprs->m_HlrAddr) > 1)
                              sendMapOpenResponse(l_UserDlgId,(char *)l_rgprs->m_HlrAddr,g_ConfigData->i_NgConfigData.m_selfAddress.ssn);
                           m_freezeReqd = false;
                        }
                        LLOG(0,0,"DB response is success for SGSN purge,Sending Success response");
                        SgsnResponseV3(l_UserDlgId);
                     }
                     else
                     {
                        WLOG(0,0,"DB resopnse for Retrieve GPRS profile data Not success,sending Unknown subscriber and closeing");
                        RetErrorV3(l_UserDlgId,UnknownSubscriber);
                     }
                  }
                  break;
               default:
                  {                       
                     ELOG(0,0,"Unknown DB data received");
                  }
                  break;
            }
         }
         break;

      default:
         ELOG(0, 0, "Unknown message received");
         break;

   }
   return true;
}

bool CtxtPurgeMS::CheckParametersV2(int l_UserDlgId,IMAP2_PurgeMS_Arg *l_pms)
{
   DLOG(0,0,"Inside Check Parameters Version 2 for the purge MS received on DlgId %d",l_UserDlgId);
   memset(l_imsi,'\0',sizeof(l_imsi));
   BCDToString(l_imsi,l_pms->imsi.value,l_pms->imsi.length);
   if(strlen((char *)l_imsi) !=  IMSILEN)
      return false;
   setTraceImsi((char *)l_imsi);
   m_tdr.setChar(TDR_INDEX_REQUEST_TYPE,'I'); // 1-msisdn 2-imsi 3-both
   m_tdr.setString(TDR_INDEX_REQUEST_IMSI,(char*)l_imsi);
   TLOG(0,0,"Trace enabled on imsi %s",(char *)l_imsi);
   memset(l_vlr,'\0',sizeof(l_vlr));
   BCDToString(l_vlr,l_pms->vlr_Number.value,l_pms->vlr_Number.length);
   if(MAXISDNADDRLEN < strlen((char *)l_vlr))
      return false;
   LLOG(0,0,"Purge MS received for IMSI %s from VLR number %s",(char *)l_imsi,(char *)l_vlr+2);
   m_tdr.setString(TDR_INDEX_VLR_ADDRESS,(char*)l_vlr+2);
   return true;
}

bool CtxtPurgeMS::CheckParametersV3(int l_UserDlgId,IMAP3_PurgeMS_Arg *l_pms)
{
   DLOG(0,0,"Inside Check Parameters Version 3");
   memset(l_imsi,'\0',sizeof(l_imsi));
   BCDToString(l_imsi,l_pms->imsi.value,l_pms->imsi.length);
   if(strlen((char *)l_imsi) != IMSILEN)
   {
      WLOG(0,0,"IMSI is not of proper length, returning error and closing");
      RetErrorV3(l_UserDlgId,UnexpectedData);
      return false;
   }
   setTraceImsi((char *)l_imsi);
   m_tdr.setChar(TDR_INDEX_REQUEST_TYPE,'I'); // 1-msisdn 2-imsi 3-both
   m_tdr.setString(TDR_INDEX_REQUEST_IMSI,(char*)l_imsi);
   TLOG(0,0,"Trace enabled on imsi %s",(char *)l_imsi);   
   memset((char *)l_vlr,'\0',sizeof((char *)l_vlr));
   memset((char *)l_sgsn,'\0',sizeof((char *)l_sgsn));
   if(l_pms->bit_mask & IMAP3_PurgeMS_Arg_vlr_Number_present)
   {
      BCDToString(l_vlr,l_pms->vlr_Number.value,l_pms->vlr_Number.length);
      DLOG(0,0,"VLR number is %s",(char *)l_vlr+2);
      if(MAXISDNADDRLEN < strlen((char *)l_vlr))
      {
         DLOG(0,0,"VLR number is not of proper length, returning error and closing");
         RetErrorV3(l_UserDlgId,UnexpectedData);
         return false;
      }
      flag = false;
      LLOG(0,0,"Purge MS received for IMSI %s from VLR number %s",(char *)l_imsi,(char *)l_vlr+2);
      m_tdr.setString(TDR_INDEX_VLR_ADDRESS,(char*)l_vlr+2);
   }
   if(l_pms->bit_mask & IMAP3_PurgeMS_Arg_sgsn_Number_present)
   {
      BCDToString(l_sgsn,l_pms->sgsn_Number.value,l_pms->sgsn_Number.length);
      DLOG(0,0,"SGSN Number is %s",(char *)l_sgsn+2);
      if(MAXISDNADDRLEN < strlen((char *)l_sgsn))
      {
         DLOG(0,0,"SGSN number is not of proper length, returning error and closing");
         RetErrorV3(l_UserDlgId,UnexpectedData);
         return false;
      }
      flag = true;
      LLOG(0,0,"Purge MS received for IMSI %s from SGSN number %s",(char *)l_imsi,(char *)l_sgsn+2);
      m_tdr.setString(TDR_INDEX_SGSN_ADDRESS,(char*)l_sgsn+2);
   }
   if((strlen((char *)l_sgsn) < 1) && (strlen((char *)l_vlr) < 1))
   {
      WLOG(0,0,"Incorrect IMSI or VLR number and SGSN number both not present in Purge MS request, unknown sender closing by sending error");
      RetErrorV3(l_UserDlgId,DataMissing);
      return false;
   }
   if(flag)
   {
      DLOG(0,0,"Purge MS request from SGSN calling RetrieveGprsProfile");
      l_msg = m_rgprs;
      PurgeGPRS(l_UserDlgId,l_imsi,l_sgsn);
   }
   else
   {
      DLOG(0,0,"Purge MS request from VLR calling RetrieveGprsProfile");
      l_msg = m_rgsm;
      PurgeGSM(l_UserDlgId,l_imsi,l_vlr);
   }
   return true;
}


void CtxtPurgeMS::PurgeGSM(int l_UserDlgId,u8 *imsi,u8 *l_number)
{
   LLOG(0,0,"Executing the Purge MS query for Dialog Id %d with IMSI %s and VLR number %s",l_UserDlgId,imsi,l_number+2);
   PurgeMS *l_rgsm = new PurgeMS();
   l_rgsm->m_UserDlgId = l_UserDlgId;
   strcpy((char *)l_rgsm->m_imsi,(char *)imsi);
   strcpy((char *)l_rgsm->m_number,(char *)l_number+2);
   l_rgsm->m_ErrorCode = 0;
   l_rgsm->m_flag = 0;
   l_rgsm->m_cb = this;
   g_act.execute(l_rgsm);
}

void CtxtPurgeMS::PurgeGPRS(int l_UserDlgId,u8 *imsi,u8 *l_number)
{
   LLOG(0,0,"Executing the Purge MS query for Dialog Id %d with IMSI %s and SGSN number %s",l_UserDlgId,imsi,l_number+2);
   PurgeMS *l_rgprs = new PurgeMS();
   l_rgprs->m_UserDlgId = l_UserDlgId;
   strcpy((char *)l_rgprs->m_imsi,(char *)imsi);
   strcpy((char *)l_rgprs->m_number,(char *)l_number+2);
   l_rgprs->m_ErrorCode = 0;
   l_rgprs->m_flag = 1;
   l_rgprs->m_cb = this;
   g_act.execute(l_rgprs);
}

void CtxtPurgeMS::VLRResponseV2(int l_UserDlgId)
{
   /*struct timeval tim;
   gettimeofday(&tim);
   struct tm *l_timeStruct=NULL;
   //char *l_dateString=NULL;
   time_t l_tim =time(NULL);
   l_timeStruct = localtime(&l_tim);
   char tim1[100];
   memset(tim1,'\0',100);
   sprintf(tim1, "%.6f",l_timeStruct->tm_sec+(tim.tv_usec/1000000.0));*/
   LLOG(0,0,"%d-TS:Sending Purge MS Response",l_UserDlgId);
   MapSpecificResult l_result(l_UserDlgId, MAP_OP_CODE_purgeMS, MAP_V2);
   DECLARE(OMAP2_PurgeMS_Res,l_pmr,2,"OMAP2_PurgeMS_Res",DeclareFunc);
   l_pmr->bit_mask = 0;
   if(m_freezeReqd)
      l_pmr->bit_mask = OMAP2_freezeTMSI_present;
   l_result.m_structBuffer = l_pmr;
   g_sc.sendMsg(this, &l_result);
   DLOG(0,0,"Sending Close Req after Purge MS response");
   CloseReq(l_UserDlgId);
}

void CtxtPurgeMS::VLRResponseV3(int l_UserDlgId)
{
   /*struct timeval tim;
   gettimeofday(&tim);
   struct tm *l_timeStruct=NULL;
   //char *l_dateString=NULL;
   time_t l_tim =time(NULL);
   l_timeStruct = localtime(&l_tim);
   char tim1[100];
   memset(tim1,'\0',100);
   sprintf(tim1, "%.6f",l_timeStruct->tm_sec+(tim.tv_usec/1000000.0));*/
   LLOG(0,0,"%d-TS:Sending Purge MS Response",l_UserDlgId);
   MapSpecificResult l_result(l_UserDlgId, MAP_OP_CODE_purgeMS, MAP_V3);
   //DECLARE(OMAP3_PurgeMS_Res,l_pmr,3);
   DECLARE(OMAP3_PurgeMS_Res,l_pmr,3,"OMAP3_PurgeMS_Res",DeclareFunc);
   l_pmr->bit_mask = 0;
   if(m_freezeReqd)
      l_pmr->bit_mask = OMAP3_freezeTMSI_present;
   l_result.m_structBuffer = (void *)l_pmr;
   g_sc.sendMsg(this, &l_result);
   CloseReq(l_UserDlgId);
   DLOG(0,0,"Sending Close Req after Purge MS response");
   //m_tdr.setBool(TDR_MSGSTATUS_INDEX,true);
}

void CtxtPurgeMS::SgsnResponseV3(int l_UserDlgId)
{
/*   struct timeval tim;
   gettimeofday(&tim);
   struct tm *l_timeStruct=NULL;
   //char *l_dateString=NULL;
   time_t l_tim =time(NULL);
   l_timeStruct = localtime(&l_tim);
   char tim1[100];
   memset(tim1,'\0',100);
   sprintf(tim1, "%.6f",l_timeStruct->tm_sec+(tim.tv_usec/1000000.0));*/
   LLOG(0,0,"%d-TS:Sending Purge MS Response",l_UserDlgId);
   MapSpecificResult l_result(l_UserDlgId, MAP_OP_CODE_purgeMS, MAP_V3);
   //DECLARE(OMAP3_PurgeMS_Res,l_pmr,3);
   DECLARE(OMAP3_PurgeMS_Res,l_pmr,3,"OMAP3_PurgeMS_Res",DeclareFunc);
   l_pmr->bit_mask = 0;    
   if(m_freezeReqd)
      l_pmr->bit_mask = OMAP3_freezeP_TMSI_present;
   l_result.m_structBuffer = l_pmr;
   g_sc.sendMsg(this, &l_result);
   DLOG(0,0,"Sending Close Req after Purge MS response");
   CloseReq(l_UserDlgId);
   //m_tdr.setBool(TDR_MSGSTATUS_INDEX,true);
}

void CtxtPurgeMS::RetErrorV2(int l_UserDlgId,int ErrorCode)
{
   DLOG(0,0,"Returning Error %d",ErrorCode);
   //m_tdr.setBool(TDR_MSGSTATUS_INDEX,false);
   switch(ErrorCode)
   {
      case 1://SystemFailure
         {
            LLOG(0,0,"Sending System Failure");
            OMAP2_SystemFailureParam l_sfp;
            memset(&l_sfp,'\0',sizeof(l_sfp));
            l_sfp.choice = OMAP2_networkResource_chosen;
            l_sfp.u.networkResource = OMAP2_hlr;
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_systemFailure, MAP_V2, &l_sfp);
            g_sc.sendMsg(this, &l_userError);
            CloseReq(l_UserDlgId);
            m_tdr.setInteger(TDR_INDEX_ERR_CODE,34);
         }
         break;
      case 2://UnknownSubscriber
         {
            LLOG(0,0,"Unknown subscriber Sending error Unknown Subscriber - IMSI unknown");
            OMAP2_UnknownSubscriberParam l_usp;
            memset(&l_usp,'\0',sizeof(l_usp));
            l_usp.bit_mask = OMAP2_unknownSubscriberDiagnostic_present;
            l_usp.unknownSubscriberDiagnostic = OMAP2_imsiUnknown;
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_unknownSubscriber, MAP_V2, NULL);
            g_sc.sendMsg(this, &l_userError);
            CloseReq(l_UserDlgId);
            m_tdr.setInteger(TDR_INDEX_ERR_CODE,1);
         }
         break;
      case 3://DataMissing
         {
            LLOG(0,0,"Sending Data missing error");
            OMAP2_DataMissingParam l_dmp;
            memset(&l_dmp,'\0', sizeof(l_dmp));
            //l_dmp.choice
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_dataMissing, MAP_V2, NULL);
            g_sc.sendMsg(this, &l_userError);
            CloseReq(l_UserDlgId);
            m_tdr.setInteger(TDR_INDEX_ERR_CODE,35);
         }
         break;
      case 4://UnexpectedData
         {
            LLOG(0,0,"Sending Unexpected data ");
            OMAP2_UnexpectedDataParam l_udp;
            memset(&l_udp,'\0',sizeof(l_udp));
            //l_udp.choice
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_unexpectedData, MAP_V2, NULL);
            g_sc.sendMsg(this, &l_userError);
            CloseReq(l_UserDlgId);
            m_tdr.setInteger(TDR_INDEX_ERR_CODE,36);
         }
         break;
      default:
         CLOG(0,0,"Error found while processing data");
         break;
   }
}

void CtxtPurgeMS::RetErrorV3(int l_UserDlgId,int ErrorCode)
{
   DLOG(0,0,"Returning Error %d",ErrorCode);
   //m_tdr.setBool(TDR_MSGSTATUS_INDEX,false);
   switch(ErrorCode)
   {
      case 1://SystemFailure
         {
            LLOG(0,0,"Sending System Failure ");            
            OMAP3_SystemFailureParam l_sfp;
            memset(&l_sfp,'\0',sizeof(l_sfp));
            l_sfp.choice = OMAP3_extensibleSystemFailureParam_chosen;
            l_sfp.u.extensibleSystemFailureParam.bit_mask = OMAP3_networkResource_present;
            l_sfp.u.extensibleSystemFailureParam.networkResource = OMAP3_hlr;
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_systemFailure, MAP_V3, &l_sfp);
            g_sc.sendMsg(this, &l_userError);
            CloseReq(l_UserDlgId);
            m_tdr.setInteger(TDR_INDEX_ERR_CODE,34);

         }
         break;
      case 2://UnknownSubscriber
         {              
            LLOG(0,0,"Unknown subscriber Sending error Unknown Subscriber - IMSI unknown");
            OMAP3_UnknownSubscriberParam l_usp;
            memset(&l_usp,'\0',sizeof(l_usp));
            l_usp.bit_mask = OMAP3_unknownSubscriberDiagnostic_present;
            l_usp.unknownSubscriberDiagnostic = OMAP3_imsiUnknown;
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_unknownSubscriber, MAP_V3, &l_usp);
            g_sc.sendMsg(this, &l_userError);
            CloseReq(l_UserDlgId);
            m_tdr.setInteger(TDR_INDEX_ERR_CODE,1);
         }
         break;
      case 3://DataMissing
         {
            LLOG(0,0,"Sending Data missing error");
            OMAP3_DataMissingParam l_dmp;
            memset(&l_dmp,'\0', sizeof(l_dmp));
            //l_dmp.choice
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_dataMissing, MAP_V3, NULL);
            g_sc.sendMsg(this, &l_userError);
            CloseReq(l_UserDlgId);
            m_tdr.setInteger(TDR_INDEX_ERR_CODE,35);
         }
         break;
      case 4://UnexpectedData
         {
            LLOG(0,0,"Sending Unexpected data");
            OMAP3_UnexpectedDataParam l_udp;
            memset(&l_udp,'\0',sizeof(l_udp));
            //l_udp.choice
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_unexpectedData, MAP_V3, NULL);
            g_sc.sendMsg(this, &l_userError);
            CloseReq(l_UserDlgId);            
            m_tdr.setInteger(TDR_INDEX_ERR_CODE,36);
         }
         break;
      default:
         ELOG(0,0,"Error found while processing data");
         break;
   }
}

void CtxtPurgeMS::CloseReq(int l_UserDlgId)
{
   DLOG(0, 0, "Sending Close");
   MapCloseReq l_closeReq(l_UserDlgId);
   g_sc.sendMsg(this, &l_closeReq);
}

void CtxtPurgeMS::ContinueReq(int l_UserDlgId)
{
   DLOG(0, 0, "Sending Delimiter Req ...");
   MapDelimiterReq l_del(l_UserDlgId);
   g_sc.sendMsg(this, &l_del);
}
