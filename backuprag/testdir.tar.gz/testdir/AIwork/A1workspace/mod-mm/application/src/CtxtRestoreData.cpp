#include <CtxtRestoreData.h>
#include <stdio.h>
#include <MapMessages.h>
#include <ServiceCoordinator.h>
#include <Logger.h>
#include <DbQueryMsg.h>
#include <DbActiveObject.h>
#include <MmConfigReader.h>
#include <ISDData.h>
#include <DataUnion.h>
#include <Utilities.h>
#include <CommonDefines.h>
#include <CtxtCancelLocation.h>
#include <AsnCodec.h>

extern AsnCodec g_AsnCodecO3;
extern AsnCodec g_AsnCodecO2;

CtxtRestoreData::CtxtRestoreData()
{
   TLOG(0,0,"CtxtRestoreData::CtxtRestoreData()");
   flag = false;
   l_Version = 0;
   l_OpCode = 0;
   memset(m_VlrAddr,'\0',sizeof(m_VlrAddr));
   m_ProvErrRcvd = false;
   memset(l_imsi,'\0',sizeof(l_imsi));
   memset(l_lmsi,'\0',sizeof(l_lmsi));
   memset(m_VlrAddr,'\0',sizeof(m_VlrAddr));
}

CtxtRestoreData::~CtxtRestoreData()
{
   TLOG(0, 0, "CtxtRestoreData::~CtxtRestoreData()");
}

bool CtxtRestoreData::processMessage(Msg *p_MsgPtr,bool &p_DeleteFlag)
{
   DLOG(0, 0, "Start of CtxtRestoreData::processMsg function, Delete flag %s",p_DeleteFlag?"true":"false");   
   MapSpecificMsg *l_specMsg = NULL;
   int l_dlgId = 0;
   int l_UserDlgId = 0;

   switch (p_MsgPtr->m_MsgType)
   {
      case MSG_TYPE_MAP:
         switch (((MapMsg*) p_MsgPtr)->m_MapMsgType)
         {
            case MAP_MSG_TYPE_COMMON:
               switch (((MapCommonMsg*) p_MsgPtr)->m_MapCommonMsgType)
               {
                  case MAP_CMN_OPEN_IND:
                     {                          
                        DLOG(0, 0, "MAP_CMN_OPEN_IND received");
                        //MapOpenInd *l_test = (MapOpenInd*) p_MsgPtr;
                        //OpenInd(l_test);
                        TLOG(0,0,"MAP_CMN_OPEN_IND received remote ssn: %d gt: %s",
                              ((MapOpenInd*)p_MsgPtr)->m_OrigAddr.ssn,
                              ((MapOpenInd*)p_MsgPtr)->m_OrigAddr.globalTitle.addressInformation);
                        strcpy((char *)m_VlrAddr,((MapOpenInd*)p_MsgPtr)->m_OrigAddr.globalTitle.addressInformation);
                     }
                     break;

                  case MAP_CMN_DELIMITER_IND:
                     DLOG(0, 0, "MAP_CMN_DELIMITER_IND received");
                     break;

                  case MAP_CMN_CLOSE_IND:
                     {
                        TLOG(0, 0, "MAP_CMN_CLOSE_IND received");                        
                        return true;
                     }
                     break;

                  case MAP_CMN_U_ABORT_IND:
                     TLOG(0, 0, "MAP_CMN_U_ABORT_IND received");
                     m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_U_ABORT_RCVD);
                     break;

                  case MAP_CMN_P_ABORT_IND:
                     TLOG(0, 0, "MAP_CMN_P_ABORT_IND received");
                     m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_P_ABORT_RCVD);
                     break;

                  case MAP_CMN_NOTICE_IND:
                     {
                        TLOG(0, 0, "MAP_CMN_NOTICE_IND received, Sending Close");
                        MapCloseReq l_closeReq(((MapMsg*)p_MsgPtr)->m_UserDlgId);
                        l_closeReq.m_CloseType = MAP_CLOSE_TYPE_PRE_ARRANGED_END;
                        m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_NOTICE_RCVD);
                        g_sc.sendMsg(this, &l_closeReq);
                     }
                     break;

                  default:
                     CLOG(0, 0, "Unknown Msg received [%d]", ((MapCommonMsg*) p_MsgPtr)->m_MapCommonMsgType);
                     break;
               }
               break;

            case MAP_MSG_TYPE_SPECIFIC:
               {
                  DLOG(0, 0, "MAP_MSG_TYPE_SPECIFIC received");
                  l_specMsg = (MapSpecificMsg*) p_MsgPtr;
                  l_UserDlgId = l_specMsg->m_UserDlgId;
                  DLOG(0, 0, "MAP_MSG_TYPE_SPECIFIC received dlgId[%d] UserDlgId[%d]",l_dlgId, l_UserDlgId);

                  switch (((MapSpecificMsg*) p_MsgPtr)->m_MapSpecificEventType)
                  {
                     case MAP_SPEC_EVENT_INDICATION:
                        {
                           DLOG(0, 0, "MAP_SPEC_EVENT_INDICATION received");
                           l_UserDlgId = p_MsgPtr->m_UserDlgId;
                           l_Version = ((MapSpecificMsg*)p_MsgPtr)->m_Version;
                           l_OpCode = (int)((MapSpecificMsg*) p_MsgPtr)->m_OpCode;
                           TLOG(0,0,"Received OpCode %d, Received message of version %d for dlgId[%d] UserDlgId[%d]",l_OpCode,l_Version,l_dlgId, l_UserDlgId);

                           switch (((MapSpecificMsg*) p_MsgPtr)->m_OpCode)
                           {
                              case MAP_OP_CODE_restoreData ://OpCode = 57 (39 in Hexa)
                                 {
                                    DLOG(0, 0, "Restore Data request Received");
                                    switch(((MapSpecificMsg*)p_MsgPtr)->m_Version)
                                    {
                                       case 2:
                                          {
                                             if (false == ((MapSpecificMsg*)p_MsgPtr)->m_allocatedFlag)
                                             {
                                                RetErrorV2(l_UserDlgId,UnexpectedData);
                                             }
                                             else
                                             {
                                                IMAP2_RestoreDataArg *l_rd = (IMAP2_RestoreDataArg*) (((MapSpecificMsg*) p_MsgPtr)->m_structBuffer);
                                                DLOG(0,0,"Reveived Restore Data version 2 message");
                                                l_Version = 2;
                                                if(true == CheckParametersV2(l_UserDlgId,l_rd))
                                                {
                                                   DLOG(0,0,"Check parameters success, calling DB query to retrieve Subscriber profile");
                                                   l_msg = m_rsd;
                                                   RetrieveData(l_UserDlgId,l_imsi,l_lmsi);
                                                }
                                                else
                                                {
                                                   DLOG(0,0,"Check parameters fail, sending error and closing");
                                                   RetErrorV2(l_UserDlgId,UnexpectedData);
                                                }
                                             }
                                          }
                                          break;
                                       case 3:
                                          {
                                             if (false == ((MapSpecificMsg*)p_MsgPtr)->m_allocatedFlag)
                                             {
                                                RetErrorV3(l_UserDlgId,UnexpectedData);
                                             }
                                             else
                                             {
                                                IMAP3_RestoreDataArg *l_rd = (IMAP3_RestoreDataArg*) (((MapSpecificMsg*) p_MsgPtr)->m_structBuffer);
                                                DLOG(0,0,"Reveived Restore Data version 3 Message");
                                                l_Version = 3;
                                                if(true == CheckParametersV3(l_UserDlgId,l_rd))
                                                {
                                                   DLOG(0,0,"Check parameters success, calling DB query to retrieve Subscriber profile");
                                                   l_msg = m_rsd;
                                                   RetrieveData(l_UserDlgId,l_imsi,l_lmsi);
                                                }
                                                else
                                                {
                                                   DLOG(0,0,"Check parameters fail, sending error and closing");
                                                   RetErrorV3(l_UserDlgId,UnexpectedData);
                                                }
                                             }
                                          }
                                          break;
                                       default:
                                          DLOG(0,0,"Unrecognizable version Restore Data received");
                                          break;
                                    }
                                 }
                                 break;

                              default:
                                 DLOG(0, 0, "Received Unknown Specific Message");
                                 break;
                           }
                           return true;
                        }
                        break;

                     case MAP_SPEC_EVENT_RESULT:
                        {
                           DLOG(0, 0, "MAP_SPEC_EVENT_RESULT received");
                        }
                        break;

                     case MAP_SPEC_EVENT_CONFIRMATION:
                        {
                           DLOG(0, 0, "MAP_SPEC_EVENT_CONFIRMATION received");
                           switch (((MapSpecificMsg*) p_MsgPtr)->m_OpCode)
                           {
                              case MAP_OP_CODE_activateTraceMode:
                                 {
                                    TLOG(0,0,"%d-TS:Received activate trace mode Resp",l_UserDlgId);
                                    switch(l_Version)
                                    {
                                       case 3:
                                          {
                                             startISDV3(l_UserDlgId); 
                                          }
                                          break;
                                       case 2:
                                          {
                                             startISDV2(l_UserDlgId);
                                          }
                                          break;
                                       default :
                                          {
                                             ELOG(0,0,"Unknown Msg Version %d",l_Version);
                                             return false;
                                          }
                                    }
                                 }
                                 break;
                              case MAP_OP_CODE_insertSubscriberData://OpCode = 7
                                 {
                                    TLOG(0,0,"Received ISD response of Version %d, index %d",((MapSpecificMsg* )p_MsgPtr)->m_Version,index);
                                    switch(l_Version)
                                    {
                                       case 3:
                                          {
                                             if(true == ((MapSpecificMsg*)p_MsgPtr)->m_allocatedFlag)
                                             {
                                                IMAP3_InsertSubscriberDataRes *ISD_Res = (IMAP3_InsertSubscriberDataRes*) (((MapSpecificMsg*) p_MsgPtr)->m_structBuffer);
                                                if(true == m_isd.ProcessIsdResV3(l_UserDlgId,ISD_Res))
                                                {
                                                   DLOG(0,0,"Processed ISD response");
                                                }
                                             }
                                             if(index == 0)
                                             {
                                                DLOG(0,0,"Index value is %d, sending rsd resp",(int)index);
                                                SendRespV3(l_UserDlgId,GsmProfile.l_mnrf);
                                             }
                                             else
                                             {
                                                DLOG(0,0,"Index value is %x continuing remaining ISD",index);

                                                MapSpecificRequest l_request(l_UserDlgId, MAP_OP_CODE_insertSubscriberData, MAP_V3); 
                                                DECLARE(OMAP3_InsertSubscriberDataArg,l_isd,3,"OMAP3_InsertSubscriberDataArg",DeclareFunc);                                     
                                                m_isd.FormISDReqV3(l_UserDlgId,index,VcsiIndex,ScsiIndex,SsIndex,flag,m_isd.dbisd3,l_OpCode,l_isd);
                                                if(5 > g_AsnCodecO3.getEncodingLength(OMAP3_InsertSubscriberDataArg_PDU,l_isd))
                                                {
                                                   WLOG(0,0,"Formed ISD data of length less than 5 bytes, Neglecting it and continuing with remaining ISD");
                                                   RetErrorV3(l_UserDlgId,SystemFailure);
                                                }
                                                else
                                                {
                                                   SendMsgV3(l_UserDlgId,l_request,l_isd,index,VcsiIndex,ScsiIndex,SsIndex);
                                                }
                                             }
                                          }
                                          break;
                                       case 2:
                                          {
                                             if(true == ((MapSpecificMsg*)p_MsgPtr)->m_allocatedFlag)
                                             {
                                                IMAP2_InsertSubscriberDataRes *ISD_Res = (IMAP2_InsertSubscriberDataRes*) (((MapSpecificMsg*) p_MsgPtr)->m_structBuffer);
                                                if(true == m_isd.ProcessIsdResV2(l_UserDlgId,ISD_Res))
                                                {
                                                   DLOG(0,0,"Processing ISD response success");
                                                }
                                             }
                                             if(index == 0)
                                             {
                                                DLOG(0,0,"Index value is %d, sending rsd response",(int)index);
                                                SendRespV2(l_UserDlgId,GsmProfile.l_mnrf);
                                             }
                                             else
                                             {
                                                DLOG(0,0,"Index value is %x continuing sending remaining ISD",index);
                                                MapSpecificRequest l_request(l_UserDlgId, MAP_OP_CODE_insertSubscriberData, MAP_V2); 
                                                DECLARE(OMAP2_InsertSubscriberDataArg,l_isd,2,"OMAP3_InsertSubscriberDataArg",DeclareFunc);                                     
                                                m_isd.FormISDReqV2(l_UserDlgId,index,SsIndex,flag,m_isd.dbisd2,l_OpCode,l_isd);
                                                SendMsgV2(l_UserDlgId,l_request,l_isd,index,SsIndex);
                                             }
                                          }
                                          break;
                                       default:
                                          {
                                             DLOG(0,0,"ISD Acknowledge with unknown version of msg received");
                                             RetErrorV3(l_UserDlgId,UnexpectedData);
                                          }
                                          break;
                                    }
                                 }
                                 break;

                              default:
                                 DLOG(0,0,"Unrecognised MAP_SPEC_EVENT_CONFIRMATION received");
                                 break;
                           }
                        }
                        break;

                     case MAP_SPEC_EVENT_USER_ERROR:
                        {
                           unsigned short l_errCode = ((MapUserError*)p_MsgPtr)->m_ErrorCode;
                           TLOG(0, 0, "MAP_SPEC_EVENT_USER_ERROR received, Error code %d",l_errCode);
                           //m_tdr.setBool(TDR_MSGSTATUS_INDEX,false);
                           if(l_msg == m_atm)
                           {
                              TLOG(0,0,"Received error for ATM"); 
                           }
                           m_tdr.setInteger(TDR_INDEX_ERR_CODE,l_errCode);
                           CloseReq(l_UserDlgId);
                        }
                        break;

                     case MAP_SPEC_EVENT_PROV_ERROR:
                        {
                           TLOG(0, 0, "MAP_SPEC_EVENT_PROV_ERROR received");
                           m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_PROVIDER_ERROR_RCVD);
                           m_ProvErrRcvd = true;
                           //CloseReq(l_UserDlgId);
                        }
                        break;
                     default:
                        WLOG(0, 0, "ERROR!! Default received");
                        break;
                  }
               }
               break;

            default:
               break;
         }
         break;

      case MSG_TYPE_DB:
         {
            TLOG(0,0,"DB message received on the call state %d",(m_callState)l_msg);
            switch(l_msg)
            {
               case m_rsd:
                  {
                     RetrieveRSDData *l_rsd = (RetrieveRSDData*) p_MsgPtr;
                     DLOG(0,0,"Received DB response on Retrieve subscriber Profile Data");
                     l_UserDlgId = l_rsd->m_UserDlgId;
                     TLOG(0,0,"Received DB response on Retrieve subscriber Profile Data for DlgId %d",l_UserDlgId);
                     m_tdr.setInteger(TDR_INDEX_MM_NETWORK_ID,l_rsd->m_nwid); 
                     if(l_rsd->m_DbQueryRes == DB_QUERY_RES_SUCCESS)
                     {
                        int l_ProcessDbResp = processDBData(l_UserDlgId,l_rsd);
                        if(2 == l_ProcessDbResp)
                        {
                           TLOG(0,0,"Process db data returned false, returning Roaming not allowed");
                           switch(l_Version)
                           {
                              case 3:
                                 {
                                    RetErrorV3(l_UserDlgId,DataMissing);
                                    return false;
                                 }
                                 break;
                              case 2:
                                 {
                                    RetErrorV2(l_UserDlgId,DataMissing);                                    
                                    return false;
                                 }
                                 break;
                              default:
                                 {
                                    WLOG(0,0,"Unrecognized version of Restore subscriber data msg");
                                 }
                                 break;
                           }
                           return false;
                        }
                        else if(1 == l_ProcessDbResp)
                        {
                           TLOG(0,0,"Process db data returned false, returning Roaming not allowed");
                           switch(l_Version)
                           {
                              case 3:
                                 {
                                    RetErrorV3(l_UserDlgId,SystemFailure);
                                    return false;
                                 }
                                 break;
                              case 2:
                                 {
                                    RetErrorV2(l_UserDlgId,SystemFailure);                                    
                                    return false;
                                 }
                                 break;
                              default:
                                 {
                                    WLOG(0,0,"Unrecognized version of Restore subscriber data msg");
                                 }
                                 break;
                           }
                           return false;
                        }
                        else
                        {
                           TLOG(0,0,"Setting MAP Open response HLR address %s",GsmProfile.l_ActHLRAddr);
                           sendMapOpenResponse(l_UserDlgId,(char *)GsmProfile.l_ActHLRAddr,g_ConfigData->i_NgConfigData.m_selfAddress.ssn);
                           m_tdr.setString(TDR_INDEX_LOCAL_ADDRESS,(char *)GsmProfile.l_ActHLRAddr);
                           switch(l_Version)
                           {
                              case 3:
                                 {
                                    if(false == RsdV3(l_UserDlgId))
                                    {
                                       DLOG(0,0,"ActivateTrace flag set");
                                       l_msg = m_atm;
                                       MapSpecificRequest l_request(l_UserDlgId, MAP_OP_CODE_activateTraceMode, MAP_V3);
                                       DECLARE(OMAP3_ActivateTraceModeArg,l_atm,3,"OMAP3_ActivateTraceModeArg",DeclareFunc);
                                       fillAtmV3(l_UserDlgId,GsmProfile.l_TraceRef,GsmProfile.l_TraceType,GsmProfile.l_OmcId,l_atm);
                                       l_request.m_structBuffer = (void*) l_atm;
                                       g_sc.sendMsg(this, &l_request); //
                                       ContinueReq(l_UserDlgId);
                                       TLOG(0,0,"Sending ATM followed by cont, callstate here %d",(m_callState)l_msg);
                                    }
                                 }
                                 break;

                              case 2:
                                 {
                                    if(false == RsdV2(l_UserDlgId))
                                    {
                                       DLOG(0,0,"ActivateTrace flag set");
                                       l_msg = m_atm;
                                       MapSpecificRequest l_request(l_UserDlgId, MAP_OP_CODE_activateTraceMode, MAP_V2);
                                       DECLARE(OMAP2_ActivateTraceModeArg,l_atm,2,"OMAP2_ActivateTraceModeArg",DeclareFunc);
                                       fillAtmV2(l_UserDlgId,GsmProfile.l_TraceRef,GsmProfile.l_TraceType,GsmProfile.l_OmcId,l_atm);
                                       l_request.m_structBuffer = (void*) l_atm;
                                       g_sc.sendMsg(this, &l_request); //
                                       ContinueReq(l_UserDlgId);
                                    }
                                 }
                                 break;

                              default:
                                 WLOG(0,0,"Unknown RSD version msg");
                                 break;

                           }
                        }
                     }
                     else
                     {                        
                        WLOG(0,0,"DB resopnse for Retrieve subscriber data Not success,sending Unknown subscriber and closeing");
                        switch(l_Version)
                        {
                           case 3:
                              {
                                 RetErrorV3(l_UserDlgId,UnknownSubscriber);
                              }
                              break;
                           case 2:
                              {
                                 RetErrorV2(l_UserDlgId,UnknownSubscriber);
                              }
                              break;
                           default:
                              DLOG(0,0,"Unknown DB version msg");
                              break;
                        }
                     }

                  }
                  break;
               default:
                  {                       
                     CLOG(0,0,"DB data received at unexpected state");
                     return false;
                  }
                  break;
            }
         }
         break;

      default:
         DLOG(0, 0, "Unknown message received");
         break;

   }
   return true;
}

bool CtxtRestoreData::processDBData(int l_UserDlgId,RetrieveRSDData *l_rsd)
{
   DLOG(0,0,"Processing DB data for the Dialog id %d",l_UserDlgId);   
   l_msg = m_psd;
   memset(l_AccId,'\0',sizeof(l_AccId));
   strcpy((char *)l_AccId,(char *)l_rsd->m_AccId);//,strlen((char *)l_rsd->m_AccId));   
   l_nwId = l_rsd->m_nwid;   
   TLOG(0,0," Account ID: %s, Network Id %d",l_AccId,l_nwId);



   char GenPro[300];
   memset(GenPro,'\0',sizeof(GenPro));
   strncat(GenPro,"|",1);
   strncat(GenPro,(char *)l_rsd->m_GenINFO,strlen((char *)l_rsd->m_GenINFO));
   strncat(GenPro,"|",1);
   //DLOG(0,0,"The string tested is %s\n",GenPro);
   {
      char str[20][53];
      memset(str,'\0',1060);
      char *ptr1, *ptr2;
      ptr1=ptr2=GenPro;
      ptr2++;
      int i=1;
      while(*ptr2 != '\0')
      {
         if('|' == *ptr2)
         {
            //DLOG(0,0,"Found |\n");
            if(ptr2-ptr1 == 1)
            {
               strncpy(str[i],"|0",2);
               //DLOG(0,0,"str[%d]:%s\n",i,str[i]);
            }
            else
            {
               //strncpy(str,ptr1,ptr2-ptr1);
               strncpy(str[i],ptr1,ptr2-ptr1);
               str[i][ptr2-ptr1]='\0';
               //DLOG(0,0,"str[%d]:%s\n",i,str[i]+1);
            }
            ptr1=ptr2;
            i++;
         }

         ptr2++;
      }
      GenProfile.l_nwAccMode = atoi(str[1]+1);
      GenProfile.l_catgory = atoi(str[2]+1);
      GenProfile.l_subsRest = atoi(str[3]+1);
      GenProfile.l_accRest = atoi(str[4]+1);
      GenProfile.l_lmu = atoi(str[5]+1);
      GenProfile.l_ist = atoi(str[6]+1);
      GenProfile.l_ocsiPid = atoi(str[7]+1);
      GenProfile.l_tcsiPid = atoi(str[8]+1);
      GenProfile.l_ugcsiPid = atoi(str[9]+1);
      GenProfile.l_sscsiPid = atoi(str[10]+1);
      GenProfile.l_tifcsiPid = atoi(str[11]+1);
      GenProfile.l_dcsiPid = atoi(str[12]+1);
      GenProfile.l_moscsiPid = atoi(str[13]+1);
      GenProfile.l_mtscsiPid = atoi(str[14]+1);
      GenProfile.l_gcsiPid = atoi(str[15]+1);
      GenProfile.l_mgcsiPid = atoi(str[16]+1);
      GenProfile.l_pdpPid = atoi(str[17]+1);
      GenProfile.l_subsStatus = atoi(str[18]+1);
      strncpy(GenProfile.l_bearer,str[19]+1,52);
      strncpy(GenProfile.l_tele,str[20]+1,32);
   }
   if(false == m_isd.vlrcsi.ValidateAllCsi(l_UserDlgId,GenProfile.l_ocsiPid,GenProfile.l_sscsiPid,GenProfile.l_tifcsiPid,GenProfile.l_dcsiPid,GenProfile.l_moscsiPid,GenProfile.l_mtscsiPid))
   {
      CLOG(0,0,"Validate CSI returned false. Sending System Failure");
      return 1;
   }

   char GsmPro[300];
   memset(GsmPro,'\0',sizeof(GsmPro));
   //DLOG(0,0,"The string tested is %s\n",l_rsd->m_GsmINFO);
   strncpy(GsmPro,"|",1);
   strncat(GsmPro,(char *)l_rsd->m_GsmINFO,strlen((char *)l_rsd->m_GsmINFO));
   strncat(GsmPro,"|",1);
   //DLOG(0,0,"The string tested is %s\n",GsmPro);
   char str1[25][22];
   memset(str1,'\0',sizeof(str1));
   {
      char *ptr1, *ptr2;
      ptr1=ptr2=GsmPro;
      ptr2++;
      int i=1;
      while(*ptr2 != '\0')
      {
         if('|' == *ptr2)
         {
            //DLOG(0,0,"Found |\n");
            if(ptr2-ptr1 == 1)
            {
               strncpy(str1[i],"|0",2);
               //DLOG(0,0,"str[%d]:%s\n",i,str[i]+1);
            }
            else
            {
               //strncpy(str,ptr1,ptr2-ptr1);
               strncpy(str1[i],ptr1,ptr2-ptr1);
               str1[i][ptr2-ptr1]='\0';
               //DLOG(0,0,"str[%d]:%s\n",i,str[i]+1);
            }
            ptr1=ptr2;
            i++;
         }

         ptr2++;
      }
      strncpy((char *)GsmProfile.l_ActMsisdn,str1[1]+1,strlen(str1[1]));
      strncpy((char *)GsmProfile.l_Actimsi,str1[2]+1,strlen(str1[2]));
      strncpy((char *)GsmProfile.l_lmsino,str1[3]+1,strlen(str1[3]));
      strncpy((char *)GsmProfile.l_vlrno,str1[4]+1,strlen(str1[4]));
      strncpy((char *)GsmProfile.l_Mscno,str1[5]+1,strlen(str1[5]));
      GsmProfile.l_mscRest = atoi(str1[6]+1);
      GsmProfile.l_ssInd = atoi(str1[7]+1);
      GsmProfile.l_msPur_gsm = atoi(str1[8]+1);
      GsmProfile.l_mnrr = atoi(str1[9]+1);
      GsmProfile.l_mnrf = atoi(str1[10]+1);
      GsmProfile.l_mcef = atoi(str1[11]+1);
      GsmProfile.l_roamrestduf = atoi(str1[12]+1);
      strncpy((char *)GsmProfile.l_ActHLRAddr,str1[13]+1,strlen(str1[13]));
      GsmProfile.l_ActPnwId = atoi(str1[14]+1);
      GsmProfile.l_TraceFlag = atoi(str1[15]+1);
      strncpy((char*)GsmProfile.l_TraceRef,str1[16]+1,strlen(str1[16]+1));
      strncpy((char *)GsmProfile.l_TraceType,str1[17]+1,strlen(str1[17]+1));
      strncpy((char *)GsmProfile.l_OmcId,str1[18]+1,strlen(str1[18]+1));
      GsmProfile.l_TraceStatus = atoi(str1[19]+1);
      if(GenProfile.l_subsStatus == 1)
      {
         unsigned int l_GenOdb_DB  = atoi(str1[20]+1);
         l_GenOdb = l_GenOdb_DB & VLR_SUPPORTED_ODB;
         TLOG(0,0,"General ODB data from DB is %ld, After conv to VLR specific %ld",l_GenOdb_DB,l_GenOdb);
         if(GsmProfile.l_ActPnwId)
         {
            l_PlmnOdb = 0;
         }
         else
         {
            unsigned int l_WrongHplmn = atoi(str1[21]+1);
            l_PlmnOdb = HplmnOdb(l_WrongHplmn);             
         }
         if((l_GenOdb == 0) && (l_PlmnOdb == 0))
         {
            GenProfile.l_subsStatus = 0;
            TLOG(0,0,"General ODB data %ld and HPLMN Specific ODB Data %ld, changing Subscriber Status to %d",
                  l_GenOdb,l_PlmnOdb,GenProfile.l_subsStatus);
         }
      }
      else
      {         
         l_GenOdb = 0;        
         l_PlmnOdb = 0;         
      }
      DLOG(0,0,"Subscriber status %d,Partner NW id %d,Gen ODB data %ld,HPLMN ODB Data %ld",GenProfile.l_subsStatus,GsmProfile.l_ActPnwId,l_GenOdb,l_PlmnOdb);
   }
   if(GsmProfile.l_ActPnwId)
   {
      TLOG(0,0,"Subscriber is not in HPLMN area, ignoring traceflag");
      GsmProfile.l_TraceFlag = 0;
      TLOG(0,0,"Subscriber is not in HPLMN area, removing PLMN specific bearer and teleservice list data");
      for(int ltele = 16;ltele < 32;ltele++)
      {
         GenProfile.l_tele[ltele] = '0';
      }
      for(int lbear = 36;lbear < 52;lbear++)
      {
         GenProfile.l_bearer[lbear] = '0';
      }
   }

   if(l_vlrCap.VlrCap_Phase == 0)
   {
      if(l_rsd->m_AssumeCap1Support)
      {
         TLOG(0,0,"Assume CAMEL phase 1 indicator present");
         l_vlrCap.VlrCap_Camel1 = true;
         l_vlrCap.VlrCap_Camel[0] = '1'; l_vlrCap.VlrCap_Camel[1] = '0';
         l_vlrCap.VlrCap_Camel[2] = '0';l_vlrCap.VlrCap_Camel[3] = '0';
         l_vlrCap.VlrCap_Phase = 1;
      }
      else
      {
         TLOG(0,0,"Assume CAMEL phase 1 indicator Not present");
      }
   }

   if((l_Version == 3) && (GenProfile.l_ocsiPid || GenProfile.l_sscsiPid || GenProfile.l_tifcsiPid || GenProfile.l_dcsiPid || GenProfile.l_moscsiPid || GenProfile.l_mtscsiPid ))
   {
      if(GsmProfile.l_ActPnwId == 0)
      {
         if(g_MmConfigReaderObj->m_Home_CAP_Filtering)
         {         
            DLOG(0,0,"Checking the Camel capability of HOME_CAMEL_PHASE %s with received CAMEL_PHASE %s, Max Camel phase in VLR %d",g_MmConfigReaderObj->m_home_cap_version,l_vlrCap.VlrCap_Camel,l_vlrCap.VlrCap_Phase);
            if(g_MmConfigReaderObj->m_home_cap_version[l_vlrCap.VlrCap_Phase-1] == '1')
            {
               TLOG(0,0,"Received Camel phase components %s and Configured Camel phases %s , Max Camel phase in VLE %d,are same, Continuing",l_vlrCap.VlrCap_Camel,g_MmConfigReaderObj->m_home_cap_version,l_vlrCap.VlrCap_Phase);              
            }
            else
            {
               TLOG(0,0,"Received Camel phase components %s and Configured Camel phases %s , MAX Camel phase in VLR %d are different, returning false",l_vlrCap.VlrCap_Camel,g_MmConfigReaderObj->m_home_cap_version,l_vlrCap.VlrCap_Phase);
               return 2; 
            }
         }
         else
         {
            TLOG(0,0,"Subscriber is in Home and HOME Camel filtering flag configured is %d, Not Checking it",g_MmConfigReaderObj->m_Home_CAP_Filtering);
         }            
      }
      else
      {
         if(g_MmConfigReaderObj->m_Roam_CAP_Filtering)
         {
            DLOG(0,0,"Checking the Camel capability of ROAM_CAMEL_PHASE %s with received CAMEL_PHASE %s, Max Camel phase in VLR %d",g_MmConfigReaderObj->m_roam_cap_version,l_vlrCap.VlrCap_Camel,l_vlrCap.VlrCap_Phase);
            if(g_MmConfigReaderObj->m_roam_cap_version[l_vlrCap.VlrCap_Phase-1] == '1')
            {
               TLOG(0,0,"Received Camel phase components %s and Configured Camel phases %s, Max Camel phase in VLR %d are same, Continuing",l_vlrCap.VlrCap_Camel,g_MmConfigReaderObj->m_home_cap_version,l_vlrCap.VlrCap_Phase);              
            }
            else
            {
               TLOG(0,0,"Received Camel phase components %s and Configured Camel phases %s, Max Camel phase in VLR %d are different, returning false",l_vlrCap.VlrCap_Camel,g_MmConfigReaderObj->m_home_cap_version,l_vlrCap.VlrCap_Phase);
               return 2; 
            }
         }
         else
         {
            TLOG(0,0,"Subscriber is in Roam and Roam Camel filtering flag configured is %d, Not Checking it",g_MmConfigReaderObj->m_Roam_CAP_Filtering);
         }            
      }                   
   } 
   else
   {
      TLOG(0,0,"Received RSD version is %d checking if CSI configured",l_Version);
      if ((GenProfile.l_ocsiPid || GenProfile.l_sscsiPid || GenProfile.l_tifcsiPid || GenProfile.l_dcsiPid || GenProfile.l_moscsiPid || GenProfile.l_mtscsiPid ))
      {
         WLOG(0,0,"CSI configured but received version is not 3");
         return 2;
      }
   } 

   setTraceMsisdn((char *)GsmProfile.l_ActMsisdn);
   m_tdr.setString(TDR_INDEX_REQUEST_MSISDN,(char*)GsmProfile.l_ActMsisdn);
   TLOG(0,0,"Trace enabled on MSISDN %s",(char *)GsmProfile.l_ActMsisdn);
   DLOG(0,0," Generel ODB data %ld, HPLMN Specific ODB Data %ld",l_GenOdb,l_PlmnOdb);

   //EMLPP Info
   {
      m_isd.pss.ESsCode = 0;
      m_isd.pss.EDefaultPriority = 0;m_isd.pss.EDefaultPriority = 0; m_isd.pss.EMaxPriority = 0;
      //DLOG(0,0,"EMLPP Data  : %s\n",l_rsd->m_EmlppData);
      char EMLPP[50];
      memset(EMLPP,'\0',sizeof(EMLPP));
      strncat(EMLPP,"|",1);
      strncat(EMLPP,(char *)l_rsd->m_EmlppData,strlen((char *)l_rsd->m_EmlppData));
      strncat(EMLPP,"|",1);
      //DLOG(0,0,"String to test %s\n",EMLPP);
      char str7[5][20];
      memset(str7,'\0',100);
      {
         char *ptr1, *ptr2;
         ptr1=ptr2=EMLPP;
         ptr2++;
         int i=1;
         while(*ptr2 != '\0')
         {
            if('|' == *ptr2)
            {
               if(ptr2-ptr1 == 1)
               {
                  strncpy(str7[i],"|0",2);
                  //DLOG(0,0,"str[%d]:%s\n",i,str7[i]);
               }
               else
               {
                  //strncpy(str,ptr1,ptr2-ptr1);
                  strncpy(str7[i],ptr1,ptr2-ptr1);
                  str7[i][ptr2-ptr1]='\0';
                  //DLOG(0,0,"str7[%d]:%s\n",i,str7[i]+1);
               }
               ptr1=ptr2;
               i++;
            }
            ptr2++;
         }
      }
      m_isd.pss.ESsCode = 161;
      m_isd.pss.ESsStatus = atoi(str7[1]+1);
      m_isd.pss.EDefaultPriority = atoi(str7[2]+1);
      m_isd.pss.EMaxPriority = atoi(str7[3]+1);
      if(m_isd.pss.ESsStatus)
      {
         DLOG(0,0,"EMLPP :- SSCODE = %d , SS_Status = %d Default Priority = %d Max Entitiled priority = %d",m_isd.pss.ESsCode,m_isd.pss.ESsStatus,m_isd.pss.EDefaultPriority,m_isd.pss.EMaxPriority);
      }
      else
      {
         DLOG(0,0,"No EMLPP data available");
      }
   }

   //MC_SS Info
   {
      m_isd.pss.mcSsCode = 0;
      m_isd.pss.MCSsStatus = 0; m_isd.pss.NBR_SB = 0; m_isd.pss.NBR_USER  = 0;
      //DLOG(0,0,"MC SS Data  : %s\n",l_rsd->m_MCData);
      char McSs[50];
      memset(McSs,'\0',sizeof(McSs));
      strncat(McSs,"|",1);
      strncat(McSs,(char *)l_rsd->m_MCData,strlen((char *)l_rsd->m_MCData));
      strncat(McSs,"|",1);
      //DLOG(0,0,"String to test %s\n",McSs);
      char str8[5][20];
      memset(str8,'\0',100);
      {
         char *ptr1, *ptr2;
         ptr1=ptr2=McSs;
         ptr2++;
         int i=1;
         while(*ptr2 != '\0')
         {
            if('|' == *ptr2)
            {
               if(ptr2-ptr1 == 1)
               {
                  strncpy(str8[i],"|0",2);
                  //DLOG(0,0,"str[%d]:%s\n",i,str8[i]);
               }
               else
               {
                  //strncpy(str,ptr1,ptr2-ptr1);
                  strncpy(str8[i],ptr1,ptr2-ptr1);
                  str8[i][ptr2-ptr1]='\0';
                  //DLOG(0,0,"str8[%d]:%s\n",i,str8[i]+1);
               }
               ptr1=ptr2;
               i++;
            }
            ptr2++;
         }
      }
      m_isd.pss.mcSsCode = 69;
      m_isd.pss.MCSsStatus = atoi(str8[1]+1);
      m_isd.pss.NBR_SB = atoi(str8[2]+1);
      m_isd.pss.NBR_USER = atoi(str8[3]+1);
      if(m_isd.pss.MCSsStatus)
      {
         DLOG(0,0,"MC_SS_INFO :- SSCODE = %d , SS_Status = %d NBR_SB = %d NBR_USER = %d",m_isd.pss.mcSsCode,m_isd.pss.MCSsStatus,m_isd.pss.NBR_SB,m_isd.pss.NBR_USER);
      }
      else
      {
         DLOG(0,0,"No MC SS INFO present");
      }
   }


#if 1   //GEN SS DATA Inside this
   {
      m_isd.pss.SsCount = 0;
      //Line Identification DATA
      //DLOG(0,0,"\n\nGen SS Count before %d\n",m_isd.pss.SsCount);
      //m_isd.pss.SsCount += l_rsd->m_LiCount;
      //DLOG(0,0,"Gen SS Count after %d\n",m_isd.pss.SsCount);
      for(int li = 0;li<l_rsd->m_LiCount;li++)
      {
         //DLOG(0,0,"Line Identification Data[%d]             : %s\n",li,l_rsd->m_LiData[li]);
         char LID[30][30];
         memset(LID[li],'\0',30);
         strncat(LID[li],"|",1);
         strncat(LID[li],(char *)l_rsd->m_LiData[li],strlen((char *)l_rsd->m_LiData[li]));
         strncat(LID[li],"|",1);
         //DLOG(0,0,"String to test in CWD %s\n",LID[li]);
         char str4[30][30];
         memset(str4,'\0',900);
         {
            char *ptr1, *ptr2;
            ptr1=ptr2=LID[li];
            ptr2++;
            int i=1;
            while(*ptr2 != '\0')
            {
               if('|' == *ptr2)
               {
                  //DLOG(0,0,"Found |\n");
                  if(ptr2-ptr1 == 1)
                  {
                     strcpy(str4[i],"|0");
                     //DLOG(0,0,"str[%d]:%s\n",i,str4[i]);
                  }
                  else
                  {
                     //strncpy(str,ptr1,ptr2-ptr1);
                     strncpy(str4[i],ptr1,ptr2-ptr1);
                     str4[i][ptr2-ptr1]='\0';
                     //DLOG(0,0,"str4[%d]:%s\n",i,str4[i]+1);
                  }
                  ptr1=ptr2;
                  i++;
               }
               ptr2++;
            }
         }
         //DLOG(0,0,"STR 1 %d and STR 2 %d\n",atoi(str4[1]+1),atoi(str4[2]+1));
         if(atoi(str4[1]+1) == 17)
         {
            m_isd.pss.SsCode[m_isd.pss.SsCount] = atoi(str4[1]+1);
            m_isd.pss.SsStatus[m_isd.pss.SsCount] = atoi(str4[2]+1);
            m_isd.pss.SsBCode[m_isd.pss.SsCount] = atoi(str4[3]+1);
            m_isd.pss.SsBType[m_isd.pss.SsCount] = atoi(str4[4]+1);
            m_isd.pss.SsSubsRest[m_isd.pss.SsCount] = 2;//atoi(str4[5]+1);
            m_isd.pss.SsCLIOptn[m_isd.pss.SsCount] = 0;//atoi(str4[6]+1);
            if(atoi(str4[7]+1))
            {
               m_isd.pss.SsOverRide[m_isd.pss.SsCount] = atoi(str4[7]+1);
            }
            else
            {
               m_isd.pss.SsOverRide[m_isd.pss.SsCount] = 0;
            }
            DLOG(0,0,"Line Identification CLIP :- SSCODE[%d] = %d , SS_Status[%d] = %d SS_BCode[%d] = %d SS_BTYPE[%d] = %d Subscription restrction[%d] = %d CLI_Option[%d] = %d OVERRide_Category[%d] = %d",m_isd.pss.SsCount,m_isd.pss.SsCode[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsStatus[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsBCode[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsBType[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsSubsRest[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsCLIOptn[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsOverRide[m_isd.pss.SsCount]);
            m_isd.pss.SsCount += 1;
         }
         if(atoi(str4[1]+1) == 18)
         {
            m_isd.pss.SsCode[m_isd.pss.SsCount] = atoi(str4[1]+1);
            m_isd.pss.SsStatus[m_isd.pss.SsCount] = atoi(str4[2]+1);
            m_isd.pss.SsBCode[m_isd.pss.SsCount] = atoi(str4[3]+1);
            m_isd.pss.SsBType[m_isd.pss.SsCount] = atoi(str4[4]+1);
            m_isd.pss.SsSubsRest[m_isd.pss.SsCount] = 1;//atoi(str4[5]+1);
            if( atoi(str4[6]+1))
            {
               m_isd.pss.SsCLIOptn[m_isd.pss.SsCount] = atoi(str4[6]+1);
            }
            else
            {
               m_isd.pss.SsCLIOptn[m_isd.pss.SsCount] = 0;
            }
            m_isd.pss.SsOverRide[m_isd.pss.SsCount] = 0;//atoi(str4[7]+1);

            DLOG(0,0,"Line Identification CLIR :- SSCODE[%d] = %d , SS_Status[%d] = %d SS_BCode[%d] = %d SS_BTYPE[%d] = %d Subscription restrction[%d] = %d CLI_Option[%d] = %d OVERRide_Category[%d] = %d",m_isd.pss.SsCount,m_isd.pss.SsCode[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsStatus[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsBCode[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsBType[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsSubsRest[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsCLIOptn[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsOverRide[m_isd.pss.SsCount]);
            m_isd.pss.SsCount += 1;
         }
         if(atoi(str4[1]+1) == 19)
         {
            m_isd.pss.SsCode[m_isd.pss.SsCount] = atoi(str4[1]+1);
            m_isd.pss.SsStatus[m_isd.pss.SsCount] = atoi(str4[2]+1);
            m_isd.pss.SsBCode[m_isd.pss.SsCount] = atoi(str4[3]+1);
            m_isd.pss.SsBType[m_isd.pss.SsCount] = atoi(str4[4]+1);
            m_isd.pss.SsSubsRest[m_isd.pss.SsCount] = 2;//atoi(str4[5]+1);
            m_isd.pss.SsCLIOptn[m_isd.pss.SsCount] = 0;//atoi(str4[6]+1);
            if(atoi(str4[7]+1))
            {
               m_isd.pss.SsOverRide[m_isd.pss.SsCount] = atoi(str4[7]+1);
            }
            else
            {
               m_isd.pss.SsOverRide[m_isd.pss.SsCount] = 0;
            }

            DLOG(0,0,"Line Identification CLIP :- SSCODE[%d] = %d , SS_Status[%d] = %d SS_BCode[%d] = %d SS_BTYPE[%d] = %d Subscription restrction[%d] = %d CLI_Option[%d] = %d OVERRide_Category[%d] = %d",m_isd.pss.SsCount,m_isd.pss.SsCode[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsStatus[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsBCode[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsBType[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsSubsRest[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsCLIOptn[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsOverRide[m_isd.pss.SsCount]);
            m_isd.pss.SsCount += 1;
         }
         if(atoi(str4[1]+1) == 20)
         {
            m_isd.pss.SsCode[m_isd.pss.SsCount] = atoi(str4[1]+1);
            m_isd.pss.SsStatus[m_isd.pss.SsCount] = atoi(str4[2]+1);
            m_isd.pss.SsBCode[m_isd.pss.SsCount] = atoi(str4[3]+1);
            m_isd.pss.SsBType[m_isd.pss.SsCount] = atoi(str4[4]+1);
            m_isd.pss.SsSubsRest[m_isd.pss.SsCount] = 0;//atoi(str4[5]+1);
            m_isd.pss.SsCLIOptn[m_isd.pss.SsCount] = 0;//atoi(str4[6]+1);
            m_isd.pss.SsOverRide[m_isd.pss.SsCount] = 0;//atoi(str4[7]+1);
            DLOG(0,0,"Line Identification CLIP :- SSCODE[%d] = %d , SS_Status[%d] = %d SS_BCode[%d] = %d SS_BTYPE[%d] = %d Subscription restrction[%d] = %d CLI_Option[%d] = %d OVERRide_Category[%d] = %d",m_isd.pss.SsCount,m_isd.pss.SsCode[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsStatus[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsBCode[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsBType[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsSubsRest[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsCLIOptn[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsOverRide[m_isd.pss.SsCount]);
            m_isd.pss.SsCount += 1;
         }

      }

      //Call Waiting DATA
      //DLOG(0,0,"\n\nGen SS Count before %d\n",m_isd.pss.SsCount);
      //m_isd.pss.SsCount += l_rsd->m_CWCount;
      //DLOG(0,0,"Gen SS Count after %d\n",m_isd.pss.SsCount);
      for(int cw = 0;cw<l_rsd->m_CWCount;cw++)
      {
         DLOG(0,0,"Call Waiting Data[%d]             : %s\n",cw,l_rsd->m_CWData[cw]);
         char CWD[70][15];
         memset(CWD[cw],'\0',15);
         strncat(CWD[cw],"|",1);
         strncat(CWD[cw],(char *)l_rsd->m_CWData[cw],strlen((char *)l_rsd->m_CWData[cw]));
         strncat(CWD[cw],"|",1);
         //DLOG(0,0,"String to test in CWD %s\n",CWD[cw]);
         char str3[70][15];
         memset(str3,'\0',1050);
         {
            char *ptr1, *ptr2;
            ptr1=ptr2=CWD[cw];
            ptr2++;
            int i=1;
            while(*ptr2 != '\0')
            {
               if('|' == *ptr2)
               {
                  //DLOG(0,0,"Found |\n");
                  if(ptr2-ptr1 == 1)
                  {
                     strcpy(str3[i],"|0");
                     //DLOG(0,0,"str[%d]:%s\n",i,str3[i]);
                  }
                  else
                  {
                     //strncpy(str,ptr1,ptr2-ptr1);
                     strncpy(str3[i],ptr1,ptr2-ptr1);
                     str3[i][ptr2-ptr1]='\0';
                     //DLOG(0,0,"str3[%d]:%s\n",i,str3[i]+1);
                  }
                  ptr1=ptr2;
                  i++;
               }
               ptr2++;
            }
         }
         //DLOG(0,0,"STR 1 %d and STR 2 %d\n",atoi(str3[1]+1),atoi(str3[2]+1));
         DLOG(0,0,"SS Count in CW is %d\n",m_isd.pss.SsCount);
         m_isd.pss.SsCode[m_isd.pss.SsCount] = 65;
         m_isd.pss.SsStatus[m_isd.pss.SsCount] = atoi(str3[1]+1);
         m_isd.pss.SsBCode[m_isd.pss.SsCount] = atoi(str3[2]+1);
         m_isd.pss.SsBType[m_isd.pss.SsCount] = atoi(str3[3]+1);
         m_isd.pss.SsSubsRest[m_isd.pss.SsCount] = 0;
         m_isd.pss.SsCLIOptn[m_isd.pss.SsCount] = 0;
         m_isd.pss.SsOverRide[m_isd.pss.SsCount] = 0;
         DLOG(0,0,"Call Waiting :- SSCODE[%d] = %d , SS_Status[%d] = %d SS_BCode[%d] = %d SS_BTYPE[%d] = %d",m_isd.pss.SsCount,m_isd.pss.SsCode[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsStatus[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsBCode[m_isd.pss.SsCount],m_isd.pss.SsCount,m_isd.pss.SsBType[m_isd.pss.SsCount]);
         m_isd.pss.SsCount += 1;
      }
      //Gen SS Data
      DLOG(0,0,"SS Data count received is %d",l_rsd->m_ssCount);
      for(int ss = 0;ss<l_rsd->m_ssCount;ss++)
      {
         //DLOG(0,0,"\nSS Data[%d]             : %s\n",ss,l_rsd->m_SSDATA[ss]);
         char SSD[20][20];
         memset(SSD[ss],'\0',20);
         strncat(SSD[ss],"|",1);
         strncat(SSD[ss],(char *)l_rsd->m_SSDATA[ss],strlen((char *)l_rsd->m_SSDATA[ss]));
         strncat(SSD[ss],"|",1);
         //DLOG(0,0,"String to test %s\n",SSD[ss]);
         char str2[10][22];
         memset(str2,'\0',220);
         {
            char *ptr1, *ptr2;
            ptr1=ptr2=SSD[ss];
            ptr2++;
            int i=1;
            while(*ptr2 != '\0')
            {
               if('|' == *ptr2)
               {
                  //DLOG(0,0,"Found |\n");
                  if(ptr2-ptr1 == 1)
                  {
                     strncpy(str2[i],"|0",2);
                     //DLOG(0,0,"str[%d]:%s\n",i,str2[i]);
                  }
                  else
                  {
                     //strncpy(str,ptr1,ptr2-ptr1);
                     strncpy(str2[i],ptr1,ptr2-ptr1);
                     str2[i][ptr2-ptr1]='\0';
                     //DLOG(0,0,"str2[%d]:%s\n",i,str2[i]+1);
                  }
                  ptr1=ptr2;
                  i++;
               }

               ptr2++;
            }
         }
         //DLOG(0,0,"STR 1 %d and STR 2 %d\n",atoi(str2[1]+1),atoi(str2[2]+1));
         m_isd.pss.SsCode[m_isd.pss.SsCount] = atoi(str2[1]+1);
         m_isd.pss.SsStatus[m_isd.pss.SsCount] = atoi(str2[2]+1);
         m_isd.pss.SsBCode[m_isd.pss.SsCount] = 0;
         m_isd.pss.SsBType[m_isd.pss.SsCount] = 0;
         m_isd.pss.SsSubsRest[m_isd.pss.SsCount] = 0;
         m_isd.pss.SsCLIOptn[m_isd.pss.SsCount] = 0;
         m_isd.pss.SsOverRide[m_isd.pss.SsCount] = 0;
         DLOG(0,0,"SUBS_SS_DATA :- SSCODE[%d] = %d , SS_Status[%d] = %d",ss,m_isd.pss.SsCode[ss],ss,m_isd.pss.SsStatus[ss]);
         m_isd.pss.SsCount += 1;
      }
   }
#endif


#if 1 // Call Forward SS inside this
   {
      //Initializing All CFWD related arrays sizes
      m_isd.pss.cfuSsCount = 0;   m_isd.pss.cfuSsCode = 0;
      m_isd.pss.cdSsCount = 0;    m_isd.pss.cdSsCode = 0;
      m_isd.pss.cfbSsCount = 0;   m_isd.pss.cfbSsCode = 0;
      m_isd.pss.cfnrySsCount = 0; m_isd.pss.cfnrySsCode = 0;
      m_isd.pss.cfnrcSsCount = 0; m_isd.pss.cfnrcSsCode = 0;

      //Call FWD DATA
      for(int all = 0;all<l_rsd->m_CFCount;all++)
      {
         //DLOG(0,0,"\n\n\nCall Fwd Data[%d]             : %s\n",all,l_rsd->m_CFData[all]);
         char CFD[500][150];
         memset(CFD[all],'\0',150);
         strncat(CFD[all],"|",1);
         strncat(CFD[all],(char *)l_rsd->m_CFData[all],strlen((char *)l_rsd->m_CFData[all]));
         strncat(CFD[all],"|",1);
         //DLOG(0,0,"String to test %s\n",CFD[all]);
         char str5[500][152];
         memset(str5,'\0',76000);
         {
            char *ptr1, *ptr2;
            ptr1=ptr2=CFD[all];
            ptr2++;
            int i=1;
            while(*ptr2 != '\0')
            {
               if('|' == *ptr2)
               {
                  //DLOG(0,0,"Found |\n");
                  if(ptr2-ptr1 == 1)
                  {
                     strcpy(str5[i],"|0");
                     //DLOG(0,0,"str[%d]:%s\n",i,str5[i]);
                  }
                  else
                  {
                     //strncpy(str,ptr1,ptr2-ptr1);
                     strncpy(str5[i],ptr1,ptr2-ptr1);
                     str5[i][ptr2-ptr1]='\0';
                     //DLOG(0,0,"str5[%d]:%s\n",i,str5[i]+1);
                  }
                  ptr1=ptr2;
                  i++;
               }

               ptr2++;
            }
         }
         //CFWD Unconditional DATA
         if(atoi(str5[1]+1) == 33)
         {
            m_isd.pss.cfuSsCode = 33;
            m_isd.pss.cfuSsStatus[m_isd.pss.cfuSsCount] = atoi(str5[2]+1);
            m_isd.pss.cfuBCode[m_isd.pss.cfuSsCount] = atoi(str5[3]+1);
            m_isd.pss.cfuBType[m_isd.pss.cfuSsCount] = atoi(str5[4]+1);
            strncpy((char *)m_isd.pss.cfuFTN[m_isd.pss.cfuSsCount],str5[5]+1,strlen(str5[5]));
            strncpy((char *)m_isd.pss.cfuFTS[m_isd.pss.cfuSsCount],str5[6]+1,strlen(str5[6]));
            m_isd.pss.cfuOPTN[m_isd.pss.cfuSsCount] = atoi(str5[7]+1);
            m_isd.pss.cfuNRT[m_isd.pss.cfuSsCount] = atoi(str5[8]+1);
            strncpy((char *)m_isd.pss.cfuLFTN[m_isd.pss.cfuSsCount],str5[9]+1,strlen(str5[9]));
            if((m_isd.pss.cfuSsStatus[m_isd.pss.cfuSsCount] > 4)&&(strcmp((char *)m_isd.pss.cfuFTN[m_isd.pss.cfuSsCount],"0") == 0))
            {
               strncpy((char *)m_isd.pss.cfuFTN[m_isd.pss.cfuSsCount],str5[10]+1,strlen(str5[10]));
               DLOG(0,0,"CFU FTN number not present, Getting Default FTN %s",m_isd.pss.cfuFTN[m_isd.pss.cfuSsCount]);              
            }
            //DLOG(0,0,"All Unconditional forwarding SS Count = %d\n",m_isd.pss.cfuSsCount);
            DLOG(0,0,"Call FWD Unconditional :- SSCODE[%d] = %d, SS_Status[%d] = %d, Basic Service Code[%d] = %d,Basic Service Type[%d] = %d, Fwd_To_Number[%d] = %s,Fwd_To_SubAddr[%d] = %s Fwd_Optn[%d] = %d, No_Reply_Time[%d] = %d, Long_FTN[%d] = %s",
                  m_isd.pss.cfuSsCount,m_isd.pss.cfuSsCode,m_isd.pss.cfuSsCount,m_isd.pss.cfuSsStatus[m_isd.pss.cfuSsCount],m_isd.pss.cfuSsCount,m_isd.pss.cfuBCode[m_isd.pss.cfuSsCount],m_isd.pss.cfuSsCount,m_isd.pss.cfuBType[m_isd.pss.cfuSsCount],m_isd.pss.cfuSsCount,m_isd.pss.cfuFTN[m_isd.pss.cfuSsCount],m_isd.pss.cfuSsCount,m_isd.pss.cfuFTS[m_isd.pss.cfuSsCount],m_isd.pss.cfuSsCount,m_isd.pss.cfuOPTN[m_isd.pss.cfuSsCount],m_isd.pss.cfuSsCount,m_isd.pss.cfuNRT[m_isd.pss.cfuSsCount],m_isd.pss.cfuSsCount,m_isd.pss.cfuLFTN[m_isd.pss.cfuSsCount]);
            m_isd.pss.cfuSsCount += 1;
         }
         //Call Deflection
         if(atoi(str5[1]+1) == 36)
         {
            m_isd.pss.cdSsCode = 36;
            m_isd.pss.cdSsStatus[m_isd.pss.cdSsCount] = atoi(str5[2]+1);
            m_isd.pss.cdBCode[m_isd.pss.cdSsCount] = atoi(str5[3]+1);
            m_isd.pss.cdBType[m_isd.pss.cdSsCount] = atoi(str5[4]+1);
            strncpy((char *)m_isd.pss.cdFTN[m_isd.pss.cdSsCount],str5[5]+1,strlen(str5[5]));
            strncpy((char *)m_isd.pss.cdFTS[m_isd.pss.cdSsCount],str5[6]+1,strlen(str5[6]));
            m_isd.pss.cdOPTN[m_isd.pss.cdSsCount] = atoi(str5[7]+1);
            m_isd.pss.cdNRT[m_isd.pss.cdSsCount] = atoi(str5[8]+1);
            strncpy((char *)m_isd.pss.cdLFTN[m_isd.pss.cdSsCount],str5[9]+1,strlen(str5[9]));
            if((m_isd.pss.cdSsStatus[m_isd.pss.cdSsCount] > 4)&&(strcmp((char *)m_isd.pss.cdFTN[m_isd.pss.cdSsCount],"0") == 0))
            {
               strncpy((char *)m_isd.pss.cdFTN[m_isd.pss.cdSsCount],str5[10]+1,strlen(str5[10]));
               DLOG(0,0,"CD FTN number not present, Getting Default FTN %s",m_isd.pss.cdFTN[m_isd.pss.cdSsCount]);              
            }
            //DLOG(0,0,"Call Deflection Count = %d\n",m_isd.pss.cdSsCount);
            DLOG(0,0,"Call Deflection :- SSCODE[%d] = %d, SS_Status[%d] = %d, Basic Service Code[%d] = %d,Basic Service Type[%d] = %d, Fwd_To_Number[%d] = %s,Fwd_To_SubAddr[%d] = %s Fwd_Optn[%d] = %d, No_Reply_Time[%d] = %d, Long_FTN[%d] = %s",
                  m_isd.pss.cdSsCount,m_isd.pss.cdSsCode,m_isd.pss.cdSsCount,m_isd.pss.cdSsStatus[m_isd.pss.cdSsCount],m_isd.pss.cdSsCount,m_isd.pss.cdBCode[m_isd.pss.cdSsCount],m_isd.pss.cdSsCount,m_isd.pss.cdBType[m_isd.pss.cdSsCount],m_isd.pss.cdSsCount,m_isd.pss.cdFTN[m_isd.pss.cdSsCount],m_isd.pss.cdSsCount,m_isd.pss.cdFTS[m_isd.pss.cdSsCount],m_isd.pss.cdSsCount,m_isd.pss.cdOPTN[m_isd.pss.cdSsCount],m_isd.pss.cdSsCount,m_isd.pss.cdNRT[m_isd.pss.cdSsCount],m_isd.pss.cdSsCount,m_isd.pss.cdLFTN[m_isd.pss.cdSsCount]);
            m_isd.pss.cdSsCount += 1;
         }
         //call forwarding on mobile subscriber busy
         if(atoi(str5[1]+1) == 41)
         {
            m_isd.pss.cfbSsCode = 41;
            m_isd.pss.cfbSsStatus[m_isd.pss.cfbSsCount] = atoi(str5[2]+1);
            m_isd.pss.cfbBCode[m_isd.pss.cfbSsCount] = atoi(str5[3]+1);
            m_isd.pss.cfbBType[m_isd.pss.cfbSsCount] = atoi(str5[4]+1);
            strncpy((char *)m_isd.pss.cfbFTN[m_isd.pss.cfbSsCount],str5[5]+1,strlen(str5[5]));
            strncpy((char *)m_isd.pss.cfbFTS[m_isd.pss.cfbSsCount],str5[6]+1,strlen(str5[6]));
            m_isd.pss.cfbOPTN[m_isd.pss.cfbSsCount] = atoi(str5[7]+1);
            m_isd.pss.cfbNRT[m_isd.pss.cfbSsCount] = atoi(str5[8]+1);
            strncpy((char *)m_isd.pss.cfbLFTN[m_isd.pss.cfbSsCount],str5[9]+1,strlen(str5[9]));
            if((m_isd.pss.cfbSsStatus[m_isd.pss.cfbSsCount] > 4)&&(strcmp((char *)m_isd.pss.cfbFTN[m_isd.pss.cfbSsCount],"0") == 0))
            {
               strncpy((char *)m_isd.pss.cfbFTN[m_isd.pss.cfbSsCount],str5[10]+1,strlen(str5[10]));
               DLOG(0,0,"CFB FTN number not present, Getting Default FTN %s",m_isd.pss.cfbFTN[m_isd.pss.cfbSsCount]);              
            }
            //DLOG(0,0,"Call Fwd on Busy count = %d\n",m_isd.pss.cfbSsCount);
            DLOG(0,0,"Call FWD Busy :- SSCODE[%d] = %d, SS_Status[%d] = %d, Basic Service Code[%d] = %d,Basic Service Type[%d] = %d, Fwd_To_Number[%d] = %s,Fwd_To_SubAddr[%d] = %s Fwd_Optn[%d] = %d, No_Reply_Time[%d] = %d, Long_FTN[%d] = %s",
                  m_isd.pss.cfbSsCount,m_isd.pss.cfbSsCode,m_isd.pss.cfbSsCount,m_isd.pss.cfbSsStatus[m_isd.pss.cfbSsCount],m_isd.pss.cfbSsCount,m_isd.pss.cfbBCode[m_isd.pss.cfbSsCount],m_isd.pss.cfbSsCount,m_isd.pss.cfbBType[m_isd.pss.cfbSsCount],m_isd.pss.cfbSsCount,m_isd.pss.cfbFTN[m_isd.pss.cfbSsCount],m_isd.pss.cfbSsCount,m_isd.pss.cfbFTS[m_isd.pss.cfbSsCount],m_isd.pss.cfbSsCount,m_isd.pss.cfbOPTN[m_isd.pss.cfbSsCount],m_isd.pss.cfbSsCount,m_isd.pss.cfbNRT[m_isd.pss.cfbSsCount],m_isd.pss.cfbSsCount,m_isd.pss.cfbLFTN[m_isd.pss.cfbSsCount]);
            m_isd.pss.cfbSsCount += 1;
         }
         //call forwarding on no reply
         if(atoi(str5[1]+1) == 42)
         {
            m_isd.pss.cfnrySsCode = 42;
            m_isd.pss.cfnrySsStatus[m_isd.pss.cfnrySsCount] = atoi(str5[2]+1);
            m_isd.pss.cfnryBCode[m_isd.pss.cfnrySsCount] = atoi(str5[3]+1);
            m_isd.pss.cfnryBType[m_isd.pss.cfnrySsCount] = atoi(str5[4]+1);
            strncpy((char *)m_isd.pss.cfnryFTN[m_isd.pss.cfnrySsCount],str5[5]+1,strlen(str5[5]));
            strncpy((char *)m_isd.pss.cfnryFTS[m_isd.pss.cfnrySsCount],str5[6]+1,strlen(str5[6]));
            m_isd.pss.cfnryOPTN[m_isd.pss.cfnrySsCount] = atoi(str5[7]+1);
            m_isd.pss.cfnryNRT[m_isd.pss.cfnrySsCount] = atoi(str5[8]+1);
            strncpy((char *)m_isd.pss.cfnryLFTN[m_isd.pss.cfnrySsCount],str5[9]+1,strlen(str5[9]));
            if((m_isd.pss.cfnrySsStatus[m_isd.pss.cfnrySsCount] > 4)&&(strcmp((char *)m_isd.pss.cfnryFTN[m_isd.pss.cfnrySsCount],"0") == 0))
            {
               strncpy((char *)m_isd.pss.cfnryFTN[m_isd.pss.cfnrySsCount],str5[10]+1,strlen(str5[10]));
               DLOG(0,0,"CFNRY FTN number not present, Getting Default FTN %s",m_isd.pss.cfnryFTN[m_isd.pss.cfnrySsCount]);              
            }
            //DLOG(0,0,"Call Fwd on no Reply Count = %d\n",m_isd.pss.cfnrySsCount);
            DLOG(0,0,"Call FWD No Reply :- SSCODE[%d] = %d, SS_Status[%d] = %d, Basic Service Code[%d] = %d,Basic Service Type[%d] = %d, Fwd_To_Number[%d] = %s,Fwd_To_SubAddr[%d] = %s Fwd_Optn[%d] = %d, No_Reply_Time[%d] = %d, Long_FTN[%d] = %s",
                  m_isd.pss.cfnrySsCount,m_isd.pss.cfnrySsCode,m_isd.pss.cfnrySsCount,m_isd.pss.cfnrySsStatus[m_isd.pss.cfnrySsCount],m_isd.pss.cfnrySsCount,m_isd.pss.cfnryBCode[m_isd.pss.cfnrySsCount],m_isd.pss.cfnrySsCount,m_isd.pss.cfnryBType[m_isd.pss.cfnrySsCount],m_isd.pss.cfnrySsCount,m_isd.pss.cfnryFTN[m_isd.pss.cfnrySsCount],m_isd.pss.cfnrySsCount,m_isd.pss.cfnryFTS[m_isd.pss.cfnrySsCount],m_isd.pss.cfnrySsCount,m_isd.pss.cfnryOPTN[m_isd.pss.cfnrySsCount],m_isd.pss.cfnrySsCount,m_isd.pss.cfnryNRT[m_isd.pss.cfnrySsCount],m_isd.pss.cfnrySsCount,m_isd.pss.cfnryLFTN[m_isd.pss.cfnrySsCount]);
            m_isd.pss.cfnrySsCount += 1;
         }
         //call forwarding on mobile subscriber not reachable
         if(atoi(str5[1]+1) == 43)
         {
            m_isd.pss.cfnrcSsCode = 43;
            m_isd.pss.cfnrcSsStatus[m_isd.pss.cfnrcSsCount] = atoi(str5[2]+1);
            m_isd.pss.cfnrcBCode[m_isd.pss.cfnrcSsCount] = atoi(str5[3]+1);
            m_isd.pss.cfnrcBType[m_isd.pss.cfnrcSsCount] = atoi(str5[4]+1);
            strncpy((char *)m_isd.pss.cfnrcFTN[m_isd.pss.cfnrcSsCount],str5[5]+1,strlen(str5[5]));
            strncpy((char *)m_isd.pss.cfnrcFTS[m_isd.pss.cfnrcSsCount],str5[6]+1,strlen(str5[6]));
            m_isd.pss.cfnrcOPTN[m_isd.pss.cfnrcSsCount] = atoi(str5[7]+1);
            m_isd.pss.cfnrcNRT[m_isd.pss.cfnrcSsCount] = atoi(str5[8]+1);
            strncpy((char *)m_isd.pss.cfnrcLFTN[m_isd.pss.cfnrcSsCount],str5[9]+1,strlen(str5[9]));
            if((m_isd.pss.cfnrcSsStatus[m_isd.pss.cfnrcSsCount]> 4)&&(strcmp((char *)m_isd.pss.cfnrcFTN[m_isd.pss.cfnrcSsCount],"0") == 0))
            {
               strncpy((char *)m_isd.pss.cfnrcFTN[m_isd.pss.cfnrcSsCount],str5[10]+1,strlen(str5[10]));
               DLOG(0,0,"CFNRC FTN number not present, Getting Default FTN %s",m_isd.pss.cfnrcFTN[m_isd.pss.cfnrcSsCount]);              
            }
            //DLOG(0,0,"Call FWD on not rechable Count = %d",m_isd.pss.cfnrcSsCount);
            DLOG(0,0,"Call FWD NRC :- SSCODE[%d] = %d, SS_Status[%d] = %d, Basic Service Code[%d] = %d,Basic Service Type[%d] = %d, Fwd_To_Number[%d] = %s,Fwd_To_SubAddr[%d] = %s Fwd_Optn[%d] = %d, No_Reply_Time[%d] = %d, Long_FTN[%d] = %s",
                  m_isd.pss.cfnrcSsCount,m_isd.pss.cfnrcSsCode,m_isd.pss.cfnrcSsCount,m_isd.pss.cfnrcSsStatus[m_isd.pss.cfnrcSsCount],m_isd.pss.cfnrcSsCount,m_isd.pss.cfnrcBCode[m_isd.pss.cfnrcSsCount],m_isd.pss.cfnrcSsCount,m_isd.pss.cfnrcBType[m_isd.pss.cfnrcSsCount],m_isd.pss.cfnrcSsCount,m_isd.pss.cfnrcFTN[m_isd.pss.cfnrcSsCount],m_isd.pss.cfnrcSsCount,m_isd.pss.cfnrcFTS[m_isd.pss.cfnrcSsCount],m_isd.pss.cfnrcSsCount,m_isd.pss.cfnrcOPTN[m_isd.pss.cfnrcSsCount],m_isd.pss.cfnrcSsCount,m_isd.pss.cfnrcNRT[m_isd.pss.cfnrcSsCount],m_isd.pss.cfnrcSsCount,m_isd.pss.cfnrcLFTN[m_isd.pss.cfnrcSsCount]);
            m_isd.pss.cfnrcSsCount += 1;
         }
      }
      DLOG(0,0,"All Unconditional forwarding SS Count = %d",m_isd.pss.cfuSsCount);
      DLOG(0,0,"Call Deflection Count = %d",m_isd.pss.cdSsCount);
      DLOG(0,0,"Call Fwd on Busy count = %d",m_isd.pss.cfbSsCount);
      DLOG(0,0,"Call Fwd on no Reply Count = %d",m_isd.pss.cfnrySsCount);
      DLOG(0,0,"Call FWD on not rechable Count = %d",m_isd.pss.cfnrcSsCount);
   }
#endif


#if 1//Call Barring SS DATA
   {
      //Initializing all Counts
      m_isd.pss.boacCount = 0;  m_isd.pss.boacSsCode = 0;
      m_isd.pss.boicCount = 0;  m_isd.pss.boicSsCode = 0;
      m_isd.pss.boihcCount = 0; m_isd.pss.boihcSsCode = 0;
      m_isd.pss.baicCount = 0;  m_isd.pss.baicSsCode = 0;
      m_isd.pss.bicrCount = 0;  m_isd.pss.bicrSsCode = 0;
      for(int acb = 0;acb<l_rsd->m_CBCount;acb++)
      {
         //DLOG(0,0,"\n\n\nAll Call Barring Data[%d]             : %s\n",acb,l_rsd->m_CBData[acb]);
         char ACB[500][50];
         memset(ACB[acb],'\0',50);
         strncat(ACB[acb],"|",1);
         strncat(ACB[acb],(char *)l_rsd->m_CBData[acb],strlen((char *)l_rsd->m_CBData[acb]));
         strncat(ACB[acb],"|",1);
         //DLOG(0,0,"String to test %s\n",ACB[acb]);
         char str13[500][50];
         memset(str13,'\0',25000);
         {
            char *ptr1, *ptr2;
            ptr1=ptr2=ACB[acb];
            ptr2++;
            int i=1;
            while(*ptr2 != '\0')
            {
               if('|' == *ptr2)
               {
                  //DLOG(0,0,"Found |\n");
                  if(ptr2-ptr1 == 1)
                  {
                     strcpy(str13[i],"|0");
                     //DLOG(0,0,"str[%d]:%s\n",i,str1[i]);
                  }
                  else
                  {
                     //strncpy(str,ptr1,ptr2-ptr1);
                     strncpy(str13[i],ptr1,ptr2-ptr1);
                     str13[i][ptr2-ptr1]='\0';
                     //DLOG(0,0,"str1[%d]:%s\n",i,str1[i]+1);
                  }
                  ptr1=ptr2;
                  i++;
               }

               ptr2++;
            }
         }
         //Barring of All Outgoing Call
         if(atoi(str13[1]+1) == 146)
         {
            m_isd.pss.boacSsCode = 146;
            m_isd.pss.boacSsStatus[m_isd.pss.boacCount] = atoi(str13[2]+1);
            m_isd.pss.boacBCode[m_isd.pss.boacCount] = atoi(str13[3]+1);
            m_isd.pss.boacBType[m_isd.pss.boacCount] = atoi(str13[4]+1);
            DLOG(0,0,"Call Barring :- SSCODE[%d] = %d, SS_Status[%d] = %d, Basic Service Code[%d] = %d,Basic Service Type[%d] = %d",
                  m_isd.pss.boacCount,m_isd.pss.boacSsCode,m_isd.pss.boacCount,m_isd.pss.boacSsStatus[m_isd.pss.boacCount],m_isd.pss.boacCount,m_isd.pss.boacBCode[m_isd.pss.boacCount],m_isd.pss.boacCount,m_isd.pss.boacBType[m_isd.pss.boacCount]);
            m_isd.pss.boacCount += 1;
         }
         //barring of All Outgoing International calls
         if(atoi(str13[1]+1) == 147)
         {
            m_isd.pss.boicSsCode = 147;
            m_isd.pss.boicSsStatus[m_isd.pss.boicCount] = atoi(str13[2]+1);
            m_isd.pss.boicBCode[m_isd.pss.boicCount] = atoi(str13[3]+1);
            m_isd.pss.boicBType[m_isd.pss.boicCount] = atoi(str13[4]+1);
            DLOG(0,0,"Call Barring :- SSCODE[%d] = %d, SS_Status[%d] = %d, Basic Service Code[%d] = %d,Basic Service Type[%d] = %d",
                  m_isd.pss.boicCount,m_isd.pss.boicSsCode,m_isd.pss.boicCount,m_isd.pss.boicSsStatus[m_isd.pss.boicCount],m_isd.pss.boicCount,m_isd.pss.boicBCode[m_isd.pss.boicCount],m_isd.pss.boicCount,m_isd.pss.boicBType[m_isd.pss.boicCount]);
            m_isd.pss.boicCount += 1;
         }
         //Barring of Internation outgoing calls except for HPLMN country
         if(atoi(str13[1]+1) == 148)
         {
            m_isd.pss.boihcSsCode = 148;
            m_isd.pss.boihcSsStatus[m_isd.pss.boihcCount] = atoi(str13[2]+1);
            m_isd.pss.boihcBCode[m_isd.pss.boihcCount] = atoi(str13[3]+1);
            m_isd.pss.boihcBType[m_isd.pss.boihcCount] = atoi(str13[4]+1);
            DLOG(0,0,"Call Barring :- SSCODE[%d] = %d, SS_Status[%d] = %d, Basic Service Code[%d] = %d,Basic Service Type[%d] = %d",
                  m_isd.pss.boihcCount,m_isd.pss.boihcSsCode,m_isd.pss.boihcCount,m_isd.pss.boihcSsStatus[m_isd.pss.boihcCount],m_isd.pss.boihcCount,m_isd.pss.boihcBCode[m_isd.pss.boihcCount],m_isd.pss.boihcCount,m_isd.pss.boihcBType[m_isd.pss.boihcCount]);
            m_isd.pss.boihcCount += 1;
         }
         //Barring of all Incoming calls
         if(atoi(str13[1]+1) == 154)
         {
            m_isd.pss.baicSsCode = 154;
            m_isd.pss.baicSsStatus[m_isd.pss.baicCount] = atoi(str13[2]+1);
            m_isd.pss.baicBCode[m_isd.pss.baicCount] = atoi(str13[3]+1);
            m_isd.pss.baicBType[m_isd.pss.baicCount] = atoi(str13[4]+1);
            DLOG(0,0,"Call Barring :- SSCODE[%d] = %d, SS_Status[%d] = %d, Basic Service Code[%d] = %d,Basic Service Type[%d] = %d",
                  m_isd.pss.baicCount,m_isd.pss.baicSsCode,m_isd.pss.baicCount,m_isd.pss.baicSsStatus[m_isd.pss.baicCount],m_isd.pss.baicCount,m_isd.pss.baicBCode[m_isd.pss.baicCount],m_isd.pss.baicCount,m_isd.pss.baicBType[m_isd.pss.baicCount]);
            m_isd.pss.baicCount += 1;
         }
         //Barring of Incoming Calls while Roaming outside Home PLMN Country
         if(atoi(str13[1]+1) == 155)
         {
            m_isd.pss.bicrSsCode = 155;
            m_isd.pss.bicrSsStatus[m_isd.pss.bicrCount] = atoi(str13[2]+1);
            m_isd.pss.bicrBCode[m_isd.pss.bicrCount] = atoi(str13[3]+1);
            m_isd.pss.bicrBType[m_isd.pss.bicrCount] = atoi(str13[4]+1);
            DLOG(0,0,"Call Barring :- SSCODE[%d] = %d, SS_Status[%d] = %d, Basic Service Code[%d] = %d,Basic Service Type[%d] = %d",
                  m_isd.pss.bicrCount,m_isd.pss.bicrSsCode,m_isd.pss.bicrCount,m_isd.pss.bicrSsStatus[m_isd.pss.bicrCount],m_isd.pss.bicrCount,m_isd.pss.bicrBCode[m_isd.pss.bicrCount],m_isd.pss.bicrCount,m_isd.pss.bicrBType[m_isd.pss.bicrCount]);
            m_isd.pss.bicrCount += 1;
         }

      }
      DLOG(0,0,"Call barring for all Out going call = %d",m_isd.pss.boacCount);
      DLOG(0,0,"Call barring for international outgoing call = %d",m_isd.pss.boicCount);
      DLOG(0,0,"Call barring for internation outgoing calls except for HPLMN country = %d",m_isd.pss.boihcCount);
      DLOG(0,0,"Call barring for all incoming call = %d",m_isd.pss.baicCount);
      DLOG(0,0,"Call barring for Incoming Calls while Roaming outside Home PLMN Country = %d",m_isd.pss.bicrCount);
   }
#endif
   return 0;
}


/*void CtxtRestoreData::OpenInd(MapOpenInd *l_test)
  {
  DLOG(0,0,"\n\nInside void CtxtRestoreData::OpenInd(MapOpenInd *l_test)\n\n");
  if (l_test->m_OpenInfo.bit_mask | MAP_DP_OpenInfo_destinationReference_present)
  {
  DLOG(0, 0, "Dest Ref length [%d] value [%02x %02x]",l_test->m_OpenInfo.destinationReference.length,
  l_test->m_OpenInfo.destinationReference.value[0],l_test->m_OpenInfo.destinationReference.value[1]);
  DLOG(0,0,"Dest Ref length [%d] value [%02x %02x]\n\n",l_test->m_OpenInfo.destinationReference.length,
  l_test->m_OpenInfo.destinationReference.value[0],l_test->m_OpenInfo.destinationReference.value[1]);
  }

  if (l_test->m_OpenInfo.bit_mask | MAP_DP_OpenInfo_originationReference_present)
  {
  DLOG(0, 0, "Orig Ref length [%d] value [%02x %02x]",l_test->m_OpenInfo.originationReference.length,
  l_test->m_OpenInfo.originationReference.value[0],l_test->m_OpenInfo.originationReference.value[1]);
  DLOG(0,0,"Orig Ref length [%d] value [%02x %02x]\n\n",l_test->m_OpenInfo.originationReference.length,
  l_test->m_OpenInfo.originationReference.value[0],l_test->m_OpenInfo.originationReference.value[1]);
  }
  }*/

bool CtxtRestoreData::CheckParametersV2(int l_UserDlgId,IMAP2_RestoreDataArg *l_rd)
{
   DLOG(0,0,"Inside Check parameters for Dialog Id %d",l_UserDlgId);
   memset(l_imsi,'\0',sizeof(l_imsi));
   BCDToString(l_imsi,l_rd->imsi.value,l_rd->imsi.length);
   if(strlen((char *)l_imsi) != IMSILEN)
      return false;
   setTraceImsi((char *)l_imsi);
   TLOG(0,0,"Trace enabled on imsi %s",(char *)l_imsi);
   m_tdr.setChar(TDR_INDEX_REQUEST_TYPE,'I'); // 1-msisdn 2-imsi 3-both
   m_tdr.setString(TDR_INDEX_REQUEST_IMSI,(char*)l_imsi);
   memset(l_lmsi,'\0',sizeof(l_lmsi));
   if(l_rd->bit_mask & IMAP2_RestoreDataArg_lmsi_present)
   {
      memset(l_lmsi,'\0',sizeof(l_lmsi));
      //BCDToString(l_lmsi,l_rd->lmsi.value,l_rd->lmsi.length);
      memcpy(l_lmsi,l_rd->lmsi.value,l_rd->lmsi.length);
      DLOG(0,0,"LMSI value received %02x%02x%02x%02x",l_lmsi[0],l_lmsi[1],l_lmsi[2],l_lmsi[3]);      
      m_tdr.setHex(TDR_INDEX_LMSI,(char *)l_lmsi,l_rd->lmsi.length);
   }
   return true;

}

bool CtxtRestoreData::CheckParametersV3(int l_UserDlgId,IMAP3_RestoreDataArg *l_rd)
{     
   DLOG(0,0,"Inside Check parameters for Dialog ID %d",l_UserDlgId);
   memset(l_imsi,'\0',sizeof(l_imsi));
   BCDToString(l_imsi,l_rd->imsi.value,l_rd->imsi.length);
   if(strlen((char *)l_imsi) != IMSILEN)
      return false;
   setTraceImsi((char *)l_imsi);
   TLOG(0,0,"Trace enabled on imsi %s",(char *)l_imsi);
   m_tdr.setChar(TDR_INDEX_REQUEST_TYPE,'I'); // 1-msisdn 2-imsi 3-both
   m_tdr.setString(TDR_INDEX_REQUEST_IMSI,(char*)l_imsi);
   memset(l_lmsi,'\0',sizeof(l_lmsi));
   if(l_rd->bit_mask & IMAP3_RestoreDataArg_lmsi_present)
   {
      memset(l_lmsi,'\0',sizeof(l_lmsi));
      //BCDToString(l_lmsi,l_rd->lmsi.value,l_rd->lmsi.length);
      memcpy(l_lmsi,l_rd->lmsi.value,l_rd->lmsi.length);
      TLOG(0,0,"LMSI value received %02x%02x%02x%02x",l_lmsi[0],l_lmsi[1],l_lmsi[2],l_lmsi[3]);
      m_tdr.setHex(TDR_INDEX_LMSI,(char *)l_lmsi,l_rd->lmsi.length);
   }
   memset(&l_vlrCap,'\0',sizeof(l_vlrCap));
   l_vlrCap.VlrCap_Camel1 = false;   l_vlrCap.VlrCap_Camel2 = false;
   l_vlrCap.VlrCap_Camel3 = false;   l_vlrCap.VlrCap_Camel4 = false;
   memset(l_vlrCap.VlrCap_Camel,'\0',5);
   l_vlrCap.VlrCap_Phase = 0;
   if(l_rd->bit_mask | IMAP3_RestoreDataArg_vlr_Capability_present)
   {

      if(l_rd->vlr_Capability.bit_mask & IMAP3_VLR_Capability_supportedCamelPhases_present)
      {
         DLOG(0,0,"Camel supported");
         if(*l_rd->vlr_Capability.supportedCamelPhases.value & IMAP3_phase1)
         {
            DLOG(0,0,"CAMEL Phase 1 supported");
            l_vlrCap.VlrCap_Camel1 = true;
            l_vlrCap.VlrCap_Camel[0] = '1';
            l_vlrCap.VlrCap_Phase = 1;
         }
         else
         {
            l_vlrCap.VlrCap_Camel[0] = '0';
         }
         if(*l_rd->vlr_Capability.supportedCamelPhases.value & IMAP3_phase2)
         {
            DLOG(0,0,"CAMEL Phase 2 supported");
            l_vlrCap.VlrCap_Camel2 = true;
            l_vlrCap.VlrCap_Camel[1] = '1';
            l_vlrCap.VlrCap_Phase = 2;
         }
         else
         {
            l_vlrCap.VlrCap_Camel[1] = '0';
         }
         if(*l_rd->vlr_Capability.supportedCamelPhases.value & IMAP3_phase3)
         {
            DLOG(0,0,"CAMEL Phase 3 supported");
            l_vlrCap.VlrCap_Camel3 = true;
            l_vlrCap.VlrCap_Camel[2] = '1';
            l_vlrCap.VlrCap_Phase = 3;
         }
         else
         {
            l_vlrCap.VlrCap_Camel[2] = '0';
         }
         if(*l_rd->vlr_Capability.supportedCamelPhases.value & IMAP3_phase4)
         {
            DLOG(0,0,"CAMEL Phase 4 supported");
            l_vlrCap.VlrCap_Camel4 = true;
            l_vlrCap.VlrCap_Camel[3] = '1';
            l_vlrCap.VlrCap_Phase = 4;
         }
         else
         {
            l_vlrCap.VlrCap_Camel[3] = '0';
         }
         DLOG(0,0,"Formed Camel data string is %s",l_vlrCap.VlrCap_Camel);
      }
      else
      {
         TLOG(0,0,"CAMEL phase support indicator not present in VLR Capability");
#if 0
         l_vlrCap.VlrCap_Camel1 = true;
         l_vlrCap.VlrCap_Camel[0] = '1'; l_vlrCap.VlrCap_Camel[1] = '0';
         l_vlrCap.VlrCap_Camel[2] = '0';l_vlrCap.VlrCap_Camel[3] = '0';
         l_vlrCap.VlrCap_Phase = 1;
#endif         
      }
      if(l_rd->vlr_Capability.bit_mask & IMAP3_VLR_Capability_solsaSupportIndicator_present)
      {
         DLOG(0,0,"soLSA support present");
         l_vlrCap.soLSA = true;
      }
      l_vlrCap.istSupportIndicator = 5;
      if(l_rd->vlr_Capability.bit_mask & IMAP3_VLR_Capability_istSupportIndicator_present)
      {
         DLOG(0,0,"IST support indicator present");
         if(l_rd->vlr_Capability.istSupportIndicator == IMAP3_basicISTSupported)
         {
            l_vlrCap.istSupportIndicator = 0;
            DLOG(0,0,"Basic IST service supported l_istSupportIndicator = %d",l_vlrCap.istSupportIndicator);
         }
         if(l_rd->vlr_Capability.istSupportIndicator == IMAP3_istCommandSupported)
         {
            l_vlrCap.istSupportIndicator = 1;
            DLOG(0,0,"IST command supported l_istSupportIndicator = %d",l_vlrCap.istSupportIndicator);
         }
      }
      if(l_rd->vlr_Capability.bit_mask & IMAP3_VLR_Capability_superChargerSupportedInServingNetworkEntity_present)
      {
         DLOG(0,0,"SuperCharge supported in serving network entity is present");
         l_vlrCap.SuperCharge = true;        
      }
      if(l_rd->vlr_Capability.bit_mask & IMAP3_VLR_Capability_longFTN_Supported_present)
      {
         l_vlrCap.LongFTN = true;//l_rd->vlr_Capability.longFTN_Supported.value;
         DLOG(0,0,"Long FTN support present value is %d",l_vlrCap.LongFTN);
      }
      if(l_rd->vlr_Capability.bit_mask & IMAP3_VLR_Capability_supportedLCS_CapabilitySets_present)
      {
         //DLOG(0,0,"LCS support present with value %x\n",l_rd->vlr_Capability.supportedLCS_CapabilitySets.value[sizeof(l_rd->vlr_Capability.supportedLCS_CapabilitySets.length)]);
         if(*l_rd->vlr_Capability.supportedLCS_CapabilitySets.value & IMAP3_lcsCapabilitySet1)
         {
            DLOG(0,0,"LCS CS 1 supported");
            l_vlrCap.lcsCS1 = 1;
         }
         if(*l_rd->vlr_Capability.supportedLCS_CapabilitySets.value & IMAP3_lcsCapabilitySet2)
         {
            l_vlrCap.lcsCS2 = 1;
            DLOG(0,0,"LCS CS 2 supported");
         }
         if(*l_rd->vlr_Capability.supportedLCS_CapabilitySets.value & IMAP3_lcsCapabilitySet3)
         {
            l_vlrCap.lcsCS3 = 1;
            DLOG(0,0,"LCS CS 3 supported");
         }
         if(*l_rd->vlr_Capability.supportedLCS_CapabilitySets.value & IMAP3_lcsCapabilitySet4)
         {
            l_vlrCap.lcsCS4 = 1;
            DLOG(0,0,"LCS CS 4 supported");
         }
      }
      if(l_rd->vlr_Capability.bit_mask & IMAP3_VLR_Capability_offeredCamel4CSIs_present)
      {
         DLOG(0,0,"CAMEL 4 CSI present");
         if(*l_rd->vlr_Capability.offeredCamel4CSIs.value & IMAP3_OfferedCamel4CSIs_o_csi)
         {
            DLOG(0,0,"Offered Camel4 CSIs_o_csi present");
            l_vlrCap.oCSI = true;
         }
         if(*l_rd->vlr_Capability.offeredCamel4CSIs.value & IMAP3_OfferedCamel4CSIs_d_csi)
         {
            DLOG(0,0,"Offered Camel4 CSIs_d_csi present");
            l_vlrCap.dCSI = true;
         }
         if(*l_rd->vlr_Capability.offeredCamel4CSIs.value & IMAP3_OfferedCamel4CSIs_vt_csi)
         {
            DLOG(0,0,"Offered Camel4 CSIs_vt_csi present");
            l_vlrCap.vtCSI = true;
         }
         if(*l_rd->vlr_Capability.offeredCamel4CSIs.value & IMAP3_OfferedCamel4CSIs_t_csi)
         {
            DLOG(0,0,"Offered Camel4 CSIs_t_csi present");
            l_vlrCap.tCSI = true;
         }
         if(*l_rd->vlr_Capability.offeredCamel4CSIs.value & IMAP3_OfferedCamel4CSIs_mt_sms_csi)
         {
            DLOG(0,0,"Offered Camel4 CSIs_mt_sms_csi present");
            l_vlrCap.mtsmsCSI = true;
         }
         if(*l_rd->vlr_Capability.offeredCamel4CSIs.value & IMAP3_OfferedCamel4CSIs_mg_csi)
         {
            DLOG(0,0,"Offered Camel4 CSIs_mg_csi present");
            l_vlrCap.mgCSI = true;
         }
         if(*l_rd->vlr_Capability.offeredCamel4CSIs.value & IMAP3_psi_enhancements)
         {
            DLOG(0,0,"Camel4 CSIs psi_enhancements present");
            l_vlrCap.psiCSI = true;
         }
      }
      if(l_rd->vlr_Capability.bit_mask & IMAP3_VLR_Capability_supportedRAT_TypesIndicator_present)
      {
         DLOG(0,0,"RAT type support present");
         if(*l_rd->vlr_Capability.supportedRAT_TypesIndicator.value & IMAP3_utran_1)
         {
            DLOG(0,0,"UTRAN supported");
            l_vlrCap.utran = true;;
         }
         if(*l_rd->vlr_Capability.supportedRAT_TypesIndicator.value & IMAP3_geran_1)
         {
            DLOG(0,0,"GERAN Supported");
            l_vlrCap.geran = true;
         }
      }
      if(l_rd->vlr_Capability.bit_mask & IMAP3_longGroupID_Supported_present)
      {
         DLOG(0,0,"Long group ID support present");
         //l_vlrCap.lgIDSupp = 1;//l_rd->vlr_Capability.longGroupID_Supported.value;
      }
   }
   else
   {
      TLOG(0,0,"VLR capability and camel phase support indicator not present");
#if 0      
      l_vlrCap.VlrCap_Camel1 = true;
      l_vlrCap.VlrCap_Camel[0] = '1'; l_vlrCap.VlrCap_Camel[1] = '0';
      l_vlrCap.VlrCap_Camel[2] = '0';l_vlrCap.VlrCap_Camel[3] = '0';
      l_vlrCap.VlrCap_Phase = 1;
#endif      
   }
   TLOG(0,0,"Camel Phase supported is %s, MAX VLR Camel phase supported is %d",l_vlrCap.VlrCap_Camel,l_vlrCap.VlrCap_Phase);
   return true;
}

#if 0
void CtxtRestoreData::RetrieveData(int l_UserDlgId,u8 *imsi,u8 *lmsi)
{
   TLOG(0,0,"Retriving profile data for IMSI %s from VLR Addr %s and Updating the LMSI %02x%02x%02x%02x",(char *)imsi,m_VlrAddr,lmsi[0],lmsi[1],lmsi[2],lmsi[3]);
   RetrieveRSDData *l_rd = new RetrieveRSDData();
   l_rd->m_UserDlgId = l_UserDlgId;
   strcpy((char *)l_rd->m_imsi,(char *)imsi);
   memset((char *)l_rd->m_lmsi,'\0',sizeof((char *)l_rd->m_lmsi));
   memcpy((char *)l_rd->m_lmsi,(char *)lmsi,4);
   strcpy((char *)l_rd->m_vlrAddr,(char *)m_VlrAddr);
   l_rd->m_cb = this;
   g_act.execute(l_rd);
}
#endif

#if 1 //New DB Procedures inside this
void CtxtRestoreData::RetrieveData(int l_UserDlgId,u8 *imsi,u8 *lmsi)
{
   TLOG(0,0,"Retriving data for IMSI %s from VLR Addr %s ",(char *)imsi,m_VlrAddr);
   RetrieveSubsVLRData *l_rd = new RetrieveSubsVLRData();
   l_rd->m_UserDlgId = l_UserDlgId;
   strcpy((char *)l_rd->m_imsi,(char *)imsi);
   strcpy((char *)l_rd->m_vlr,(char *)m_VlrAddr);
   l_rd->m_MultiImsiReqd = g_MmConfigReaderObj->m_Multi_Imsi_Reqd;
   l_rd->m_LocalMsisdnReqd = g_MmConfigReaderObj->m_Local_Msisdn_Reqd;
   l_rd->m_OpCode = 57;
   l_rd->m_cb = this;
   g_act.execute(l_rd);
}

void CtxtRestoreData::UpdateGsmData(int l_UserDlgId)
{
   DLOG(0,0,"Calling the procedure to update GSM data");
   l_state = m_usds;      
   UpdateVLRData *l_usd = new UpdateVLRData();
   l_usd->m_UserDlgId = l_UserDlgId;
   strncpy((char *)l_usd->m_AccId,(char *)l_AccId,strlen((char *)l_AccId));
   l_usd->m_nwid = l_nwId;
   l_usd->m_pnwid = l_pnwId;
   l_usd->m_MsisdnTyp = l_AlocType;
   strncpy((char *)l_usd->m_ActMsisdn,(char *)l_actMsisdn,strlen((char *)l_actMsisdn));
   strncpy((char *)l_usd->m_hlr,(char *)l_hlrAddr,strlen((char *)l_hlrAddr));
   DLOG(0,0,"rsd Version is %d",l_Version);
   strncpy((char *)l_usd->m_ActImsi,(char *)l_imsi,strlen((char *)l_imsi));
   memcpy((char *)l_usd->m_lmsi,(char *)l_lmsi,4);
   strncpy((char *)l_usd->m_vlr,(char *)m_VlrAddr,strlen((char *)m_VlrAddr));
   strncpy((char *)l_usd->m_msc,(char *)m_VlrAddr,strlen((char *)m_VlrAddr));
   if(l_Version == 3)
   {
      l_usd->m_CamPhases = 0;
      if(l_vlrCap.VlrCap_Camel4)
         l_usd->m_CamPhases |= 0x08;
      if(l_vlrCap.VlrCap_Camel3)
         l_usd->m_CamPhases |= 0x04;
      if(l_vlrCap.VlrCap_Camel2)
         l_usd->m_CamPhases |= 0x02;
      if(l_vlrCap.VlrCap_Camel1)
         l_usd->m_CamPhases |= 0x01;
      l_usd->m_solsa =  0;
      if(l_vlrCap.soLSA)
         l_usd->m_solsa = 1;
      l_usd->m_ist = 0;
      l_usd->m_ist = l_updv3.istSupportIndicator;
      l_usd->m_SuprChrg = 0;
      if(l_vlrCap.SuperCharge)
         l_usd->m_SuprChrg = 1;
      l_usd->m_LongFTN = 0;
      if(l_vlrCap.LongFTN)
         l_usd->m_LongFTN = 1;
      l_usd->m_SuppLCS = 0;
      if(l_vlrCap.lcsCS4)
         l_usd->m_SuppLCS |= 0x08;
      if(l_vlrCap.lcsCS3)
         l_usd->m_SuppLCS |= 0x04;
      if(l_vlrCap.lcsCS2)
         l_usd->m_SuppLCS |= 0x02;
      if(l_vlrCap.lcsCS1)
         l_usd->m_SuppLCS |= 0x01;
      l_usd->m_OffCSI = 0;
      if(l_vlrCap.oCSI)
         l_usd->m_OffCSI |= 0x01;
      if(l_vlrCap.dCSI)
         l_usd->m_OffCSI |= 0x02;
      if(l_vlrCap.vtCSI)
         l_usd->m_OffCSI |= 0x04;
      if(l_vlrCap.tCSI)
         l_usd->m_OffCSI |= 0x08;
      if(l_vlrCap.mtsCSI)
         l_usd->m_OffCSI |= 0x16;
      if(l_vlrCap.mgCSI)
         l_usd->m_OffCSI |= 0x32;
   }
   if(l_Version == 2)
   {
      l_usd->m_CamPhases = 0;
      l_usd->m_solsa = 0;
      l_usd->m_OffCSI = 0;
      l_usd->m_LongFTN = 0;
      l_usd->m_SuppLCS = 0;
      l_usd->m_ist = 0;
      l_usd->m_SuprChrg = 0;
   }
   memset(l_usd->m_Unsupp_Bearer,'\0',sizeof(l_usd->m_Unsupp_Bearer));
   strcpy((char *)l_usd->m_Unsupp_Bearer,(char *)m_isd.m_Unsupp_Bearer);
   memset(l_usd->m_Unsupp_Tele,'\0',sizeof(l_usd->m_Unsupp_Tele));
   strcpy((char *)l_usd->m_Unsupp_Tele,(char *)m_isd.m_Unsupp_Tele);
   memset(l_usd->m_Unsupp_SuppServ,'\0',sizeof(l_usd->m_Unsupp_SuppServ));
   strcpy((char *)l_usd->m_Unsupp_SuppServ,(char *)m_isd.m_Unsupp_SS);
   l_usd->m_Unsupp_GenOdb = m_isd.m_Unsupp_ODB;
   if(GsmProfile.l_TraceFlag)
   {
      l_usd->m_AtmErrorCode = 0;
   }
   else
   {
      l_usd->m_AtmErrorCode = 999;
   }
   l_usd->m_roamInd = l_roamInd;
   l_usd->m_mscRest = 0;
   l_usd->m_ssInd = 0;
   l_usd->m_purge = 0;
   l_usd->m_MNRR = GsmProfile.l_mnrr;
   l_usd->m_MNRF = GsmProfile.l_mnrf;
   l_usd->m_RRDUF = GsmProfile.l_roamrestduf;
   l_usd->m_CamPhases = 0;
   l_usd->m_solsa = 0;
   l_usd->m_OffCSI = 0;
   l_usd->m_LongFTN = 0;
   l_usd->m_SuppLCS = 0;
   l_usd->m_ist = 0;
   l_usd->m_SuprChrg = 0;

   TLOG(0,0,"Updating Account Id is %s, Network ID is %d in HLR_SUBS_DATA with, Active Msisdn is %s, Active Imsi is %s, Active HLR address is %s, vlr number is %s, msc number is %s, LMSI %s",l_AccId,l_usd->m_nwid,l_usd->m_ActMsisdn,l_usd->m_ActImsi,l_usd->m_hlr,l_usd->m_vlr,l_usd->m_msc,l_usd->m_lmsi);
   TLOG(0,0,"MSC Area Restricted %d,Chk SS Indicator %d, Purge_Status %d, MNRR %d,MNRF %d, RRDUF %d, Roam Ind %d, Msisdn Type %d,Partner Network ID is %d",l_usd->m_mscRest,l_usd->m_ssInd,l_usd->m_purge,l_usd->m_MNRR,l_usd->m_MNRF,l_usd->m_RRDUF,l_usd->m_roamInd,l_usd->m_MsisdnTyp,l_usd->m_pnwid);
   TLOG(0,0,"Camel Phase support %d, Solsa %d, IST %d, Super Chrg %d, LongFTN  support %d,Supported LCS %d, Offer CAMEL 4 CSI %d",l_usd->m_CamPhases,l_usd->m_solsa,l_usd->m_ist,l_usd->m_SuprChrg,l_usd->m_LongFTN,l_usd->m_SuppLCS,l_usd->m_OffCSI);

   l_usd->m_cb = this;
   g_act.execute(l_usd);
}
#endif

bool CtxtRestoreData::RsdV3(int l_UserDlgId)
{     
   DLOG(0,0,"Inside Restoredata for Dialog ID %d",l_UserDlgId);
   DLOG(0,0,"Subscriber Known");
   //DLOG(0,0,"Subscriber Known Assigning MSISDN is %s",(char *)l_actMsisdn);
   strcpy((char *)m_isd.dbisd3.imsi,(char *)l_imsi);
   m_isd.dbisd3.imsiReqd = false;
   memset(m_isd.dbisd3.msisdn,'\0',sizeof(m_isd.dbisd3.msisdn));
   strncpy((char *)m_isd.dbisd3.msisdn,(char *)GsmProfile.l_ActMsisdn,strlen((char *)GsmProfile.l_ActMsisdn));
   m_isd.dbisd3.msisdnReqd = true;
   l_msg = m_psd;
   //OLD Process GSM Data
   DLOG(0,0,"GENERAL PROFILE INFO : Network Access Mode:%d Category:%d Subscription Restriction:%d Access Restriction:%d Subscriber Status:%d LMU :%d IST :%d Bearer Service list:%s, Tele Service list:%s OCSI Profile ID:%d TCSI Profile Id:%d UGCSI Profile Id:%d SSCSI Profile ID:%d TIFCSI Profile ID:%d  DCSI Profile Id:%d, MO SMS CSI profile Id:%d MT SMS CSI Profile Id:%d GPRS CSI profile Id:%d MG CSI Profile Id:%d",
         GenProfile.l_nwAccMode,GenProfile.l_catgory,GenProfile.l_subsRest,GenProfile.l_accRest,GenProfile.l_subsStatus,GenProfile.l_lmu,GenProfile.l_ist,GenProfile.l_bearer,GenProfile.l_tele,GenProfile.l_ocsiPid,GenProfile.l_tcsiPid,GenProfile.l_ugcsiPid,GenProfile.l_sscsiPid,GenProfile.l_tifcsiPid,GenProfile.l_dcsiPid,GenProfile.l_moscsiPid,GenProfile.l_mtscsiPid,GenProfile.l_gcsiPid,GenProfile.l_mgcsiPid);


   m_isd.dbisd3.category = GenProfile.l_catgory;
   m_isd.dbisd3.nwAccMode = GenProfile.l_nwAccMode;
   m_isd.dbisd3.subStatus = GenProfile.l_subsStatus;
   m_isd.dbisd3.lmu = GenProfile.l_lmu;
   m_isd.dbisd3.accrest = GenProfile.l_accRest;
   m_isd.dbisd3.istvalue = 0;
   strncpy(m_isd.dbisd3.bearerData,GenProfile.l_bearer,53);
   m_isd.dbisd3.bearer = true;
   strncpy(m_isd.dbisd3.teleData,GenProfile.l_tele,33);
   if((GenProfile.l_ist > 0) && (l_vlrCap.istSupportIndicator == 0))
   {
      if(GenProfile.l_ist < 15 || GenProfile.l_ist > 255)
      {
         WLOG(0,0,"IST Alert timer value is not in allowed range of 15 to 255, not sending it in ISD");
         m_isd.dbisd3.istvalue = 0;
      }
      else
      {
         m_isd.dbisd3.istvalue = GenProfile.l_ist;
      }
   }
   if(GenProfile.l_subsStatus == 1)
   {
      m_isd.dbisd3.odb_Genvalue = 0;
      m_isd.dbisd3.odb_HplmnValue = 0;
      m_isd.dbisd3.odb_GenData = false;
      m_isd.dbisd3.odb_HplmnData = false;
      m_isd.dbisd3.odb_Data = false;
      if(l_GenOdb)
      {
         m_isd.dbisd3.odb_Data = true;
         m_isd.dbisd3.odb_GenData = true;
         m_isd.dbisd3.odb_Genvalue = l_GenOdb;
      }
      if(l_PlmnOdb)
      {
         m_isd.dbisd3.odb_Data = true;
         m_isd.dbisd3.odb_HplmnData = true;
         m_isd.dbisd3.odb_HplmnValue = l_PlmnOdb;
      }
      TLOG(0,0,"ODB General Data %ld, ODB HPLMN Data %ld",m_isd.dbisd3.odb_Genvalue,m_isd.dbisd3.odb_HplmnValue);
   }
   else
   {
      m_isd.dbisd3.odb_Data = false;
      m_isd.dbisd3.odb_GenData = false;
      m_isd.dbisd3.odb_HplmnData = false;
      m_isd.dbisd3.odb_Genvalue = 0;
      m_isd.dbisd3.odb_HplmnValue = 0;
   }

#if 1
   //m_isd.vlrcsi.vcsi.nwId = l_nwId;
   m_isd.vlrcsi.vcsi.nwId = l_nwId;
   m_isd.vlrcsi.vcsi.PnwId = GsmProfile.l_ActPnwId;

   m_isd.dbisd3.CamelPhase = 0;
   m_isd.vlrcsi.vcsi.ocsi = 0;
   m_isd.vlrcsi.vcsi.sscsi = 0;
   m_isd.vlrcsi.vcsi.tifcsi = 0;
   m_isd.vlrcsi.vcsi.dcsi = 0;
   m_isd.vlrcsi.vcsi.tcsi = 0;
   m_isd.vlrcsi.vcsi.mosmscsi = 0;
   m_isd.vlrcsi.vcsi.mtsmscsi = 0;
   if(l_vlrCap.VlrCap_Camel4)
   {
      DLOG(0,0,"Camel phase Supported version is 4, OCSI profile id %d, SS CSI profile id %d, TIF CSI profile id %d, DCSI profile id %d, MOSMS CSI profile id %d, MTSMS CSI profile id %d"
            ,GenProfile.l_ocsiPid,GenProfile.l_sscsiPid,GenProfile.l_tifcsiPid,GenProfile.l_dcsiPid,GenProfile.l_moscsiPid,GenProfile.l_mtscsiPid);
      m_isd.dbisd3.CamelPhase = 4;
      m_isd.vlrcsi.vcsi.rcvd_camel_phase = 4;
      m_isd.vlrcsi.vcsi.ocsi = GenProfile.l_ocsiPid;
      m_isd.vlrcsi.vcsi.sscsi = GenProfile.l_sscsiPid;
      m_isd.vlrcsi.vcsi.tifcsi = GenProfile.l_tifcsiPid;
      m_isd.vlrcsi.vcsi.dcsi = GenProfile.l_dcsiPid;
      m_isd.vlrcsi.vcsi.tcsi = GenProfile.l_tcsiPid;
      m_isd.vlrcsi.vcsi.mosmscsi = GenProfile.l_moscsiPid;
      m_isd.vlrcsi.vcsi.mtsmscsi = GenProfile.l_mtscsiPid;
   }
   else if(l_vlrCap.VlrCap_Camel3 && !(l_vlrCap.VlrCap_Camel4))
   {
      DLOG(0,0,"Camel phase Supported version is 3, OCSI profile id %d, SS CSI profile id %d, TIF CSI profile id %d, DCSI profile id %d, MOSMS CSI profile id %d"
            ,GenProfile.l_ocsiPid,GenProfile.l_sscsiPid,GenProfile.l_tifcsiPid,GenProfile.l_dcsiPid,GenProfile.l_moscsiPid);
      m_isd.dbisd3.CamelPhase = 3;
      m_isd.vlrcsi.vcsi.rcvd_camel_phase = 3;
      m_isd.vlrcsi.vcsi.ocsi = GenProfile.l_ocsiPid;
      m_isd.vlrcsi.vcsi.sscsi = GenProfile.l_sscsiPid;
      m_isd.vlrcsi.vcsi.tifcsi = GenProfile.l_tifcsiPid;
      m_isd.vlrcsi.vcsi.dcsi = GenProfile.l_dcsiPid;
      m_isd.vlrcsi.vcsi.tcsi = GenProfile.l_tcsiPid;
      m_isd.vlrcsi.vcsi.mosmscsi = GenProfile.l_moscsiPid;
      m_isd.vlrcsi.vcsi.mtsmscsi = 0;
   }
   else if(l_vlrCap.VlrCap_Camel2 && !(l_vlrCap.VlrCap_Camel3) && !(l_vlrCap.VlrCap_Camel4))
   {
      DLOG(0,0,"Camel phase Supported version is 2, OCSI profile id %d, SS CSI profile id %d and TIF CSI profile id %d",GenProfile.l_ocsiPid,GenProfile.l_sscsiPid,GenProfile.l_tifcsiPid);
      m_isd.dbisd3.CamelPhase = 2;
      m_isd.vlrcsi.vcsi.rcvd_camel_phase = 2;
      m_isd.vlrcsi.vcsi.ocsi = GenProfile.l_ocsiPid;
      m_isd.vlrcsi.vcsi.sscsi = GenProfile.l_sscsiPid;
      m_isd.vlrcsi.vcsi.tifcsi = GenProfile.l_tifcsiPid;
      m_isd.vlrcsi.vcsi.dcsi = 0;
      m_isd.vlrcsi.vcsi.tcsi = 0;
      m_isd.vlrcsi.vcsi.mosmscsi = 0;
      m_isd.vlrcsi.vcsi.mtsmscsi = 0;
   }
   else if(l_vlrCap.VlrCap_Camel1 && !(l_vlrCap.VlrCap_Camel2) && !(l_vlrCap.VlrCap_Camel3) && !(l_vlrCap.VlrCap_Camel4))
   {
      m_isd.dbisd3.CamelPhase = 1;
      m_isd.vlrcsi.vcsi.rcvd_camel_phase = 1;
      DLOG(0,0,"Camel phase Supported version is 1, OCSI profile id %d",GenProfile.l_ocsiPid);
      m_isd.vlrcsi.vcsi.ocsi = GenProfile.l_ocsiPid;
      m_isd.vlrcsi.vcsi.sscsi = 0;
      m_isd.vlrcsi.vcsi.tifcsi = 0;
      m_isd.vlrcsi.vcsi.dcsi = 0;
      m_isd.vlrcsi.vcsi.tcsi = 0;
      m_isd.vlrcsi.vcsi.mosmscsi = 0;
      m_isd.vlrcsi.vcsi.mtsmscsi = 0;
   }
   else
   {
      m_isd.dbisd3.CamelPhase = 1;
      m_isd.vlrcsi.vcsi.rcvd_camel_phase = 1;
      DLOG(0,0,"No camel phase supported obtained, Assuming as Camel phase 1 OCSI profile id is %d",GenProfile.l_ocsiPid);
      m_isd.vlrcsi.vcsi.ocsi = GenProfile.l_ocsiPid;
      m_isd.vlrcsi.vcsi.sscsi = 0;
      m_isd.vlrcsi.vcsi.tifcsi = 0;
      m_isd.vlrcsi.vcsi.dcsi = 0;
      m_isd.vlrcsi.vcsi.tcsi = 0;
      m_isd.vlrcsi.vcsi.mosmscsi = 0;
      m_isd.vlrcsi.vcsi.mtsmscsi = 0;
   }
#endif


   TLOG(0,0,"EXISTING GSM PROFILE INFO: Active MSISDN :%s Active IMSI :%s LMSI :%s VLR Number :%s MSC Number :%s MSC Area Restricted :%d Check SS Indicator :%d MS Purge Non GPRS %d MNRR :%d MNRF :%d MCEF :%d Roaming Restricted due to unsupported feature :%d Active HLR Address :%s Active Partner NW Id :%d Trace Reqd :%d,TraceReference :%s,TraceType :%s,OMC_ID :%s, Trace Status :%d",
         GsmProfile.l_ActMsisdn,GsmProfile.l_Actimsi,GsmProfile.l_lmsino,GsmProfile.l_vlrno,GsmProfile.l_Mscno,GsmProfile.l_mscRest,GsmProfile.l_ssInd,GsmProfile.l_msPur_gsm,GsmProfile.l_mnrr,GsmProfile.l_mnrf,GsmProfile.l_mcef,GsmProfile.l_roamrestduf,GsmProfile.l_ActHLRAddr,GsmProfile.l_ActPnwId,GsmProfile.l_TraceFlag,GsmProfile.l_TraceRef,GsmProfile.l_TraceType,GsmProfile.l_OmcId,GsmProfile.l_TraceStatus);
   if((GsmProfile.l_TraceFlag == 1) && (GsmProfile.l_TraceStatus != 0))
   {
      return false;
   }
   else
   {
      //Starting ISD
      startISDV3(l_UserDlgId);
      return true;
   }
}

bool CtxtRestoreData::RsdV2(int l_UserDlgId)
{     
   DLOG(0,0,"Inside Restoredata for Dialog ID %d",l_UserDlgId);
   DLOG(0,0,"Subscriber Known\n");
   //DLOG(0,0,"Subscriber Known Assigning MSISDN is %s",(char *)l_actMsisdn);
   strcpy((char *)m_isd.dbisd2.imsi,(char *)l_imsi);
   m_isd.dbisd2.imsiReqd = false;
   memset(m_isd.dbisd2.msisdn,'\0',sizeof(m_isd.dbisd2.msisdn));
   strncpy((char *)m_isd.dbisd2.msisdn,(char *)GsmProfile.l_ActMsisdn,strlen((char *)GsmProfile.l_ActMsisdn));
   m_isd.dbisd2.msisdnReqd = true;
   l_msg = m_psd;
   //OLD Process GSM Data
   DLOG(0,0,"GENERAL PROFILE INFO : Network Access Mode:%d Category:%d Subscription Restriction:%d Access Restriction:%d Subscriber Status:%d LMU :%d IST :%d Bearer Service list:%s"
         " Tele Service list:%s OCSI Profile ID:%d TCSI Profile Id:%d UGCSI Profile Id:%d SSCSI Profile ID:%d TIFCSI Profile ID:%d  DCSI Profile Id:%d"
         "MO SMS CSI profile Id:%d MT SMS CSI Profile Id:%d GPRS CSI profile Id:%d MG CSI Profile Id:%d",
         GenProfile.l_nwAccMode,GenProfile.l_catgory,GenProfile.l_subsRest,GenProfile.l_accRest,GenProfile.l_subsStatus,GenProfile.l_lmu,GenProfile.l_ist,
         GenProfile.l_bearer,GenProfile.l_tele,GenProfile.l_ocsiPid,GenProfile.l_tcsiPid,GenProfile.l_ugcsiPid,GenProfile.l_sscsiPid,GenProfile.l_tifcsiPid,GenProfile.l_dcsiPid,
         GenProfile.l_moscsiPid,GenProfile.l_mtscsiPid,GenProfile.l_gcsiPid,GenProfile.l_mgcsiPid);


   m_isd.dbisd2.category = GenProfile.l_catgory;
   m_isd.dbisd2.nwAccMode = GenProfile.l_nwAccMode;
   m_isd.dbisd2.subStatus = GenProfile.l_subsStatus;
   {
      strncpy(m_isd.dbisd2.bearerData,GenProfile.l_bearer,52);
      m_isd.dbisd2.bearer = true;
      strncpy(m_isd.dbisd2.teleData,GenProfile.l_tele,32);
   }

   if(GenProfile.l_subsStatus == 1)
   {
      m_isd.dbisd2.odb_Genvalue = 0;
      m_isd.dbisd2.odb_HplmnValue = 0;
      m_isd.dbisd2.odb_Data = false;
      m_isd.dbisd2.odb_GenData = false;
      m_isd.dbisd2.odb_HplmnData = false;
      if(l_GenOdb)
      {
         m_isd.dbisd2.odb_Data = true;
         m_isd.dbisd2.odb_GenData = true;
         unsigned int l_map2ODB = map3tomap2odb(l_GenOdb); 
         m_isd.dbisd2.odb_Genvalue = l_map2ODB;         
      }
      if(l_PlmnOdb)
      {
         m_isd.dbisd2.odb_Data = true;
         m_isd.dbisd2.odb_HplmnData = true;
         unsigned int l_map2HODB = map3tomap2odb(l_PlmnOdb); 
         m_isd.dbisd2.odb_HplmnValue = l_map2HODB;
      }
      if((m_isd.dbisd2.odb_Genvalue == 0) && (m_isd.dbisd2.odb_HplmnValue == 0))
      {
         WLOG(0,0,"No meaningful ODB data for map version 2 present");
         m_isd.dbisd2.odb_Data = false;
         m_isd.dbisd2.odb_GenData = false;
         m_isd.dbisd2.odb_HplmnData = false;
         m_isd.dbisd2.odb_Genvalue = 0;
         m_isd.dbisd2.odb_HplmnValue = 0;
      }
      TLOG(0,0,"ODB value to add is %ld, HPLMN ODB value is %ld",m_isd.dbisd2.odb_Genvalue,m_isd.dbisd2.odb_HplmnValue);
   }
   else
   {
      m_isd.dbisd2.odb_Data = false;
      m_isd.dbisd2.odb_GenData = false;
      m_isd.dbisd2.odb_HplmnData = false;
      m_isd.dbisd2.odb_Genvalue = 0;
      m_isd.dbisd2.odb_HplmnValue = 0;
   }
   TLOG(0,0,"EXISTING GSM PROFILE INFO: Active MSISDN :%s Active IMSI :%s LMSI :%s VLR Number :%s MSC Number :%s MSC Area Restricted :%d Check SS Indicator :%d MS Purge Non GPRS %d MNRR :%d MNRF :%d MCEF :%d Roaming Restricted due to unsupported feature :%d Active HLR Address :%s Active Partner NW Id :%d Trace Reqd :%d,TraceReference :%s,TraceType :%s,OMC_ID :%s, Trace Status :%d",
         GsmProfile.l_ActMsisdn,GsmProfile.l_Actimsi,GsmProfile.l_lmsino,GsmProfile.l_vlrno,GsmProfile.l_Mscno,GsmProfile.l_mscRest,GsmProfile.l_ssInd,GsmProfile.l_msPur_gsm,GsmProfile.l_mnrr,GsmProfile.l_mnrf,GsmProfile.l_mcef,GsmProfile.l_roamrestduf,GsmProfile.l_ActHLRAddr,GsmProfile.l_ActPnwId,GsmProfile.l_TraceFlag,GsmProfile.l_TraceRef,GsmProfile.l_TraceType,GsmProfile.l_OmcId,GsmProfile.l_TraceStatus);
   if((GsmProfile.l_TraceFlag == 1) && (GsmProfile.l_TraceStatus != 0))
   {
      return false;
   }
   else
   {
      //Starting ISD
      startISDV2(l_UserDlgId);
      return true;
   }
}

void CtxtRestoreData::startISDV3(int l_UserDlgId)
{
   index = OMAP3_InsertSubscriberDataArg_imsi_present;//0x80000000 initialized to first param
   VcsiIndex = OMAP3_VlrCamelSubscriptionInfo_o_CSI_present;//0x8000 initialized to OCSI
   ScsiIndex = 0;
   SsIndex = OMAP3_Ext_SS_Info_forwardingInfo_chosen;
   m_isd.pss.CFWD_STATE = (provisionedSS::CFWD)0;
   m_isd.pss.CB_STATE = (provisionedSS::CB)0;
   m_isd.pss.val = 0;
   m_isd.dbisd3.VLRCsi = true;
   m_isd.dbisd3.sgsncsi = false;
   m_isd.dbisd3.gprsSubsData = 0;
   m_isd.pss.m_GenSsCount = 0;
   DLOG(0,0,"Starting ISD V3 with index %x and CSI Index %x\n",index,VcsiIndex);
   DLOG(0,0,"Calling FormISDReqV3 for OpCode %d Dialog Id %d",l_OpCode,l_UserDlgId);

   flag = true;
   m_isd.dbisd3.VLRCsi = true;
   m_isd.dbisd3.sgsncsi = false;
   //m_isd.FormISDReqV3(l_UserDlgId,index,VcsiIndex,flag,m_isd.dbisd3,l_OpCode);

   MapSpecificRequest l_request(l_UserDlgId, MAP_OP_CODE_insertSubscriberData, MAP_V3); 
   DECLARE(OMAP3_InsertSubscriberDataArg,l_isd,3,"OMAP3_InsertSubscriberDataArg",DeclareFunc);                                     

   m_isd.FormISDReqV3(l_UserDlgId,index,VcsiIndex,ScsiIndex,SsIndex,flag,m_isd.dbisd3,l_OpCode,l_isd);
   SendMsgV3(l_UserDlgId,l_request,l_isd,index,VcsiIndex,ScsiIndex,SsIndex);
}

void CtxtRestoreData::startISDV2(int l_UserDlgId)
{
   index = OMAP2_InsertSubscriberDataArg_imsi_present;//0x80000000 initialized to first param
   SsIndex = OMAP2_SS_Info_forwardingInfo_chosen;
   DLOG(0,0,"Calling FormISDReqV2 for Dialog Id %d\n",l_UserDlgId);
   m_isd.pss.CFWD_STATE = (provisionedSS::CFWD)0;
   m_isd.pss.CB_STATE = (provisionedSS::CB)0;
   m_isd.pss.val = 0;
   flag = true;
   MapSpecificRequest l_request(l_UserDlgId, MAP_OP_CODE_insertSubscriberData, MAP_V2); 
   DECLARE(OMAP2_InsertSubscriberDataArg,l_isd,2,"OMAP2_InsertSubscriberDataArg",DeclareFunc);                                     

   m_isd.FormISDReqV2(l_UserDlgId,index,SsIndex,flag,m_isd.dbisd2,l_OpCode,l_isd);
   SendMsgV2(l_UserDlgId,l_request,l_isd,index,SsIndex);

}

#if 0
bool CtxtRestoreData::CtrlTracingHLRV3(int l_UserDlgId,u8 *l_imsi)
{

   DLOG(0,0,"The value of g_MmConfigReaderObj->m_traceReqd is %d",g_MmConfigReaderObj->m_traceReqd);
   if (g_MmConfigReaderObj->m_traceReqd)
   {
      DLOG(0,0,"Subscriber Tracing active in HLR and Subscriber is in HPLMN");
      DLOG(0,0,"Sending Activate Trace mode arg");
      MapSpecificRequest l_request(l_UserDlgId, MAP_OP_CODE_activateTraceMode, MAP_V3);
      MAP3_ActivateTraceModeArg *l_atm = (MAP3_ActivateTraceModeArg *) malloc(sizeof (MAP3_ActivateTraceModeArg));
      l_atm->traceReference.length = 1;
      l_atm->traceReference.value[0] = 1;
      l_atm->traceType = 7;
      l_atm->bit_mask = MAP3_ActivateTraceModeArg_imsi_present;
      int ll = strlen((char *)l_imsi);
      l_atm->imsi.length = (ll+1)/2;
      StringToBCD(l_atm->imsi.value,l_imsi,ll);

      l_request.m_structBuffer = l_atm;
      g_sc.sendMsg(this, &l_request);
      DLOG(0,0,"Sending Continue Req after Activate Trace Mode Req");
      ContinueReq(l_UserDlgId);
      return true;
   }
   else
   {
      DLOG(0,0,"Subscriber tracing in HLR is false");// or Subscriber is not in HPLMN");
   }
   return false;

}
#endif


void CtxtRestoreData::SendMsgV2(int DlgId,MapSpecificRequest l_request,OMAP2_InsertSubscriberDataArg *l_isd,unsigned int &numOfParam,unsigned int &SsParam)
{
   DLOG(0,0,"Inside Send Msg for ISD");
   index = numOfParam;
   SsIndex = SsParam;
   DLOG(0,0,"The index value returned by ISDData is %x, SS_Index %x",index,SsIndex);
   l_request.m_structBuffer = (void*) l_isd;
   g_sc.sendMsg(this, &l_request);
   DLOG(0, 0, "Sending Delimiter Req after the ISD");
   ContinueReq(DlgId);
}

void CtxtRestoreData::SendMsgV3(int DlgId,MapSpecificRequest l_request,OMAP3_InsertSubscriberDataArg *l_isd,unsigned int &numOfParam,unsigned int &VcsiParam,unsigned int &ScsiParam,unsigned int &SsParam)
{     
   TLOG(0,0,"Sending ISD");
   index = numOfParam;
   VcsiIndex = VcsiParam;
   ScsiIndex = ScsiParam;
   ScsiIndex = 0;
   SsIndex = SsParam;
   DLOG(0,0,"The value returned by ISDData are ISD Index %x, VLR CSI Index is %x SGSN CSI Index is %x and SS INDEX is %x",index,VcsiIndex,ScsiIndex,SsIndex);   
   l_request.m_structBuffer = (void*) l_isd;
   g_sc.sendMsg(this, &l_request);
   DLOG(0, 0, "Sending Delimiter Req after the ISD");
   ContinueReq(DlgId);
}

void CtxtRestoreData::SendRespV3(int l_UserDlgId,int mnrf)
{
   DLOG(0,0,"Sending Restore data response for Dialog Id %d",l_UserDlgId);
   MapSpecificResult l_result(l_UserDlgId, MAP_OP_CODE_restoreData, MAP_V3);
   //DECLARE(OMAP3_RestoreDataRes,l_res,3);
   DECLARE(OMAP3_RestoreDataRes,l_res,3,"OMAP3_RestoreDataRes",DeclareFunc);
   l_res->bit_mask = 0;
   u8 hlrnum[21];
   memset(hlrnum,'\0',sizeof(hlrnum));
   strncpy((char *)hlrnum,"19",2);
   DLOG(0,0,"HLR Address in Restore Data Response is %s",GsmProfile.l_ActHLRAddr);
   strncat((char *)hlrnum,(char *)GsmProfile.l_ActHLRAddr,strlen((char *)GsmProfile.l_ActHLRAddr));
   int len = strlen((char *)hlrnum);
   l_res->hlr_Number.length = (len+1)/2;
   StringToBCD(l_res->hlr_Number.value,hlrnum,len);
   if(mnrf)
   {
      l_res->bit_mask |= OMAP3_msNotReachable_present;
   }
   l_result.m_structBuffer = (void*) l_res;
   g_sc.sendMsg(this, &l_result);

   CloseReq(l_UserDlgId);   
   //m_tdr.setErrCode(0);
   //m_tdr.setBool(TDR_MSGSTATUS_INDEX,true);
   TLOG(0,0,"RestoreData response followed by map close request sent");
   UpdateGsmData(l_UserDlgId);
}

void CtxtRestoreData::SendRespV2(int l_UserDlgId,int mnrf)
{
   DLOG(0,0,"Sending Restore data response for Dialog Id %d",l_UserDlgId);
   MapSpecificResult l_result(l_UserDlgId, MAP_OP_CODE_restoreData, MAP_V2);
   //OMAP2_RestoreDataRes *l_res = (OMAP2_RestoreDataRes*) malloc(sizeof (OMAP2_RestoreDataRes));
   //memset(l_res, '\0', sizeof (OMAP2_RestoreDataRes));
   //DECLARE(OMAP2_RestoreDataRes,l_res, 2);
   DECLARE(OMAP2_RestoreDataRes,l_res,2,"OMAP2_RestoreDataRes",DeclareFunc);
   l_res->bit_mask = 0;
   u8 hlrnum[20];
   memset(hlrnum,'\0',sizeof(hlrnum));
   strncat((char *)hlrnum,"1",1);
   strncat((char *)hlrnum,"9",1);
   DLOG(0,0,"HLR Address in Restore Data Response is %s",GsmProfile.l_ActHLRAddr);
   strncat((char *)hlrnum,(char *)GsmProfile.l_ActHLRAddr,strlen((char *)GsmProfile.l_ActHLRAddr));
   int len = strlen((char *)hlrnum);
   l_res->hlr_Number.length = (len+1)/2;
   StringToBCD(l_res->hlr_Number.value,hlrnum,len);
   if(len%2)
      l_res->hlr_Number.value[l_res->hlr_Number.length] |= 0x0F;
   if(mnrf)
   {
      l_res->bit_mask |= OMAP2_msNotReachable_present;
   }
   l_result.m_structBuffer = (void*) l_res;
   g_sc.sendMsg(this, &l_result);
   CloseReq(l_UserDlgId);   
   //m_tdr.setErrCode(0);
   //m_tdr.setBool(TDR_MSGSTATUS_INDEX,true);
   TLOG(0,0,"RestoreData response followed by map close request sent");
   UpdateGsmData(l_UserDlgId);
}

void CtxtRestoreData::RetErrorV2(int l_UserDlgId,int ErrorCode)
{
   DLOG(0,0,"Sending Error for error code %d",ErrorCode);
   //m_tdr.setBool(TDR_MSGSTATUS_INDEX,false);
   switch(ErrorCode)
   {
      case 1://SystemFailure
         {
            TLOG(0,0,"Sending System Failure");
            OMAP2_SystemFailureParam l_sfp;
            memset(&l_sfp,'\0',sizeof(l_sfp));
            l_sfp.choice = OMAP2_networkResource_chosen;
            l_sfp.u.networkResource = OMAP2_hlr;
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_systemFailure, MAP_V2, &l_sfp);
            g_sc.sendMsg(this, &l_userError);
            CloseReq(l_UserDlgId);
            m_tdr.setInteger(TDR_INDEX_ERR_CODE,34);
            //ContinueReq(l_UserDlgId);
         }
         break;
      case 2://UnknownSubscriber
         {              
            TLOG(0,0,"Unknown subscriber Sending error Unknown Subscriber - IMSI unknown");
            OMAP2_UnknownSubscriberParam l_usp;
            memset(&l_usp,'\0',sizeof(l_usp));
            l_usp.bit_mask = OMAP2_unknownSubscriberDiagnostic_present;
            l_usp.unknownSubscriberDiagnostic = OMAP2_imsiUnknown;
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_unknownSubscriber, MAP_V2, NULL);
            g_sc.sendMsg(this, &l_userError);
            CloseReq(l_UserDlgId);
            m_tdr.setInteger(TDR_INDEX_ERR_CODE,1);
            //ContinueReq(l_UserDlgId);
         }
         break;
      case 3://DataMissing
         {
            TLOG(0,0,"Sending Data missing");
            OMAP2_DataMissingParam l_dmp;
            memset(&l_dmp,'\0', sizeof(l_dmp));
            //l_dmp.choice
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_dataMissing, MAP_V2, NULL);
            g_sc.sendMsg(this, &l_userError);
            CloseReq(l_UserDlgId);
            m_tdr.setInteger(TDR_INDEX_ERR_CODE,35);
            //ContinueReq(l_UserDlgId);
         }
         break;
      case 4://UnexpectedData
         {
            TLOG(0,0,"Sending Unexpected data");
            OMAP2_UnexpectedDataParam l_udp;
            memset(&l_udp,'\0',sizeof(l_udp));
            //l_udp.choice
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_unexpectedData, MAP_V2, NULL);
            g_sc.sendMsg(this, &l_userError);
            CloseReq(l_UserDlgId);
            m_tdr.setInteger(TDR_INDEX_ERR_CODE,36);
            //ContinueReq(l_UserDlgId);
         }
         break;
      default:
         CLOG(0,0,"Error found while processing data");
         break;
   }
}

void CtxtRestoreData::RetErrorV3(int l_UserDlgId,int ErrorCode)
{
   DLOG(0,0,"Sending Error for error code %d",ErrorCode);
   //m_tdr.setBool(TDR_MSGSTATUS_INDEX,false);
   switch(ErrorCode)
   {
      case 1://SystemFailure
         {
            TLOG(0,0,"Sending System Failure occured");
            //MAP3_UnknownSubscriberParam l_usp;
            OMAP3_SystemFailureParam l_sfp;
            memset(&l_sfp,'\0',sizeof(l_sfp));
            l_sfp.choice = OMAP3_extensibleSystemFailureParam_chosen;
            l_sfp.u.extensibleSystemFailureParam.bit_mask = OMAP3_networkResource_present;
            l_sfp.u.extensibleSystemFailureParam.networkResource = OMAP3_hlr;
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_systemFailure, MAP_V3, &l_sfp);
            g_sc.sendMsg(this, &l_userError);
            CloseReq(l_UserDlgId);
            m_tdr.setInteger(TDR_INDEX_ERR_CODE,34);
            //ContinueReq(l_UserDlgId);
         }
         break;
      case 2://UnknownSubscriber
         {              
            TLOG(0,0,"Unknown subscriber Sending error Unknown Subscriber - IMSI unknown");
            OMAP3_UnknownSubscriberParam l_usp;
            memset(&l_usp,'\0',sizeof(l_usp));
            l_usp.bit_mask = OMAP3_unknownSubscriberDiagnostic_present;
            l_usp.unknownSubscriberDiagnostic = OMAP3_imsiUnknown;
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_unknownSubscriber, MAP_V3, &l_usp);
            g_sc.sendMsg(this, &l_userError);
            CloseReq(l_UserDlgId);
            m_tdr.setInteger(TDR_INDEX_ERR_CODE,1);
            //ContinueReq(l_UserDlgId);
         }
         break;
      case 3://DataMissing
         {
            TLOG(0,0,"Sending Data missing error");
            OMAP3_DataMissingParam l_dmp;
            memset(&l_dmp,'\0', sizeof(l_dmp));
            //l_dmp.choice
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_dataMissing, MAP_V3, NULL);
            g_sc.sendMsg(this, &l_userError);
            CloseReq(l_UserDlgId);
            m_tdr.setInteger(TDR_INDEX_ERR_CODE,35);
            //ContinueReq(l_UserDlgId);
         }
         break;
      case 4://UnexpectedData
         {
            TLOG(0,0,"Sending Unexpected data ");
            OMAP3_UnexpectedDataParam l_udp;
            memset(&l_udp,'\0',sizeof(l_udp));
            //l_udp.choice
            MapUserError l_userError(l_UserDlgId, MAP_ERROR_unexpectedData, MAP_V3, NULL);
            g_sc.sendMsg(this, &l_userError);
            CloseReq(l_UserDlgId);
            m_tdr.setInteger(TDR_INDEX_ERR_CODE,36);
            //ContinueReq(l_UserDlgId);
         }
         break;
      default:
         CLOG(0,0,"Error found while processing data");
         break;
   }
}

void CtxtRestoreData::CloseReq(int l_UserDlgId)
{
   DLOG(0, 0, "Closing the Dialogue");
   MapCloseReq l_closeReq(l_UserDlgId);
   g_sc.sendMsg(this, &l_closeReq);
}

void CtxtRestoreData::ContinueReq(int l_UserDlgId)
{
   DLOG(0, 0, "Sending Delimiter Req ...");
   MapDelimiterReq l_del(l_UserDlgId);
   g_sc.sendMsg(this, &l_del);
}
