/*******************************************************************************************
 * File        : VlrCamelSubsinfo.cpp
 * Author      : VenkatRaman
 * Description : To retrieve and add VLR Camel Subscription Infromation from DB to ISD arg
 * Created on April 22, 2010, 6:00 PM IST
 *******************************************************************************************/

#include <stdio.h>
#include <VlrCamelSubsinfo.h>
#include <Logger.h>
#include <MmConfigReader.h>
#include <DbQueryMsg.h>
#include <DbActiveObject.h>
#include <CtxtUpdateLocation.h>
#include <CommonDefines.h>
#include <SubsProfileData.h>
#include <SubsProfilesManager.h>
#include <AsnCodec.h>
#include <Utilities.h>


extern AsnCodec g_AsnCodecO3;

VlrCamelSubsinfo::VlrCamelSubsinfo()
{
   DLOG(0,0,"VlrCamelSubsinfo() cons");
   memset(&vcsi,'\0',sizeof(vcsi));
}

VlrCamelSubsinfo::~VlrCamelSubsinfo()
{
   DLOG(0,0,"VlrCamelSubsinfo() des");
}

bool VlrCamelSubsinfo::ValidateAllCsi(int DlgId,int OcsiPid,int SscsiPid,int TifcsiPid,int DcsiPid,int MosmscsiPid,int VtcsiPid,int MtsmscsiPid)
{
   LLOG(0,0,"Validating CSI for DlgId %d, for profiles OCSI %d,SSCSI %d,TIFCSI %d,DCSI %d,MOSMSCSI %d,VTCSI %d,MTSMSCSI %d",DlgId,OcsiPid,SscsiPid,TifcsiPid,DcsiPid,MosmscsiPid,VtcsiPid,MtsmscsiPid);
   if(OcsiPid)
   {
      DLOG(0,0,"Validating OCSI profile id %d",OcsiPid);
      map<u16,OCSI*>::iterator l_ocsiItr;
      l_ocsiItr = g_spdPtr->m_OCSIMap.find(OcsiPid);
      if(l_ocsiItr == g_spdPtr->m_OCSIMap.end())
      {
         CLOG(0,0,"OCSI profileID |%d| not found in map.. ",OcsiPid);
         return false;
      }
      else
      {
         OCSI *lpOcsi = l_ocsiItr->second;
         if(lpOcsi == NULL)
         {
            ELOG(0,0,"Null values in OcsiMap for profileID |%d| .. ",OcsiPid);
            return false;
         }
      }
   }
   if(SscsiPid)
   {
      DLOG(0,0,"Validating SsCSI profile id %d",SscsiPid);
      map<u16,SSCSI*>::iterator l_SscsiItr;
      l_SscsiItr = g_spdPtr->m_SSCSIMap.find(SscsiPid);
      if(l_SscsiItr == g_spdPtr->m_SSCSIMap.end())
      {
         CLOG(0,0,"SSCSI profileID |%d| not found in map.. ",SscsiPid);
         return false;
      }
      else
      {
         SSCSI *lpSscsi = l_SscsiItr->second;
         if(lpSscsi == NULL)
         {
            ELOG(0,0,"Null values in SScsiMap for profileID |%d| .. ",SscsiPid);
            return false;
         }
      }
   }
   if(TifcsiPid)
   {
      DLOG(0,0,"Validating TIFCSI profile id %d",TifcsiPid);
      map<u16,TIFCSI*>::iterator l_TifcsiItr;
      l_TifcsiItr = g_spdPtr->m_TIFCSIMap.find(TifcsiPid);
      if(l_TifcsiItr == g_spdPtr->m_TIFCSIMap.end())
      {
         CLOG(0,0,"TIFCSI profileID |%d| not found in map.. ",TifcsiPid);
         return false;
      }
      else
      {
         TIFCSI *lpTifcsi = l_TifcsiItr->second;
         if(lpTifcsi == NULL)
         {
            ELOG(0,0,"Null values in TifcsiMap for profileID |%d| .. ",TifcsiPid);
            return false;
         }
      }
   }
   if(DcsiPid)
   {
      DLOG(0,0,"Validating DCSI profileid %d",DcsiPid);
      map<u16,DCSI*>::iterator l_DcsiItr;
      l_DcsiItr = g_spdPtr->m_DCSIMap.find(DcsiPid);
      if(l_DcsiItr == g_spdPtr->m_DCSIMap.end())
      {
         CLOG(0,0,"DCSI profileID |%d| not found in map.. ",DcsiPid);
         return false;
      }
      else
      {
         DCSI *lpDcsi = l_DcsiItr->second;
         if(lpDcsi == NULL)
         {
            ELOG(0,0,"Null values in DcsiMap for profileID |%d| .. ",DcsiPid);
            return false;
         }
      }
   }
   if(MosmscsiPid)
   {
      DLOG(0,0,"Validating MosmsCSI profileid %d",MosmscsiPid);
      map<u16,MOSMSCSI*>::iterator l_MosmscsiItr;
      l_MosmscsiItr = g_spdPtr->m_MOSMSCSIMap.find(MosmscsiPid);
      if(l_MosmscsiItr == g_spdPtr->m_MOSMSCSIMap.end())
      {
         CLOG(0,0,"MOSMS_CSI profileID |%d| not found in map.. ",MosmscsiPid);
         return false;
      }
      else
      {
         MOSMSCSI *lpMosmscsi = l_MosmscsiItr->second;
         if(lpMosmscsi == NULL)
         {
            ELOG(0,0,"Null values in MosmscsiMap for profileID |%d| .. ",MosmscsiPid);
            return false;
         }
      }
   }
   if(VtcsiPid)
   {
      DLOG(0,0,"Validating VTCSI profileid %d",VtcsiPid);
      map<u16,VTCSI*>::iterator l_VtcsiItr;
      l_VtcsiItr = g_spdPtr->m_VTCSIMap.find(VtcsiPid);
      if(l_VtcsiItr == g_spdPtr->m_VTCSIMap.end())
      {
         CLOG(0,0,"VT_CSI profileID |%d| not found in map.. ",VtcsiPid);
         return false;
      }
      else
      {
         VTCSI *lpVtcsi = l_VtcsiItr->second;
         if(lpVtcsi == NULL)
         {
            ELOG(0,0,"Null values in VtcsiMap for profileID |%d| .. ",MtsmscsiPid);
            return false;
         }
      }
   }
   if(MtsmscsiPid)
   {
      DLOG(0,0,"Validating MTSMSCSI profileid %d",MtsmscsiPid);
      map<u16,MTSMSCSI*>::iterator l_MtsmscsiItr;
      l_MtsmscsiItr = g_spdPtr->m_MTSMSCSIMap.find(MtsmscsiPid);
      if(l_MtsmscsiItr == g_spdPtr->m_MTSMSCSIMap.end())
      {
         CLOG(0,0,"MTSMS_CSI profileID |%d| not found in map.. ",MtsmscsiPid);
         return false;
      }
      else
      {
         MTSMSCSI *lpMtsmscsi = l_MtsmscsiItr->second;
         if(lpMtsmscsi == NULL)
         {
            ELOG(0,0,"Null values in MtsmscsiMap for profileID |%d| .. ",MtsmscsiPid);
            return false;
         }
      }
   }
   return true;
}

//void VlrCamelSubsinfo::formOCsi(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd)
void VlrCamelSubsinfo::formOCsi(OMAP3_InsertSubscriberDataArg *l_isd)
{
   DLOG(0,0,"OCSI Profile id is %d",vcsi.ocsi);
   if(vcsi.ocsi != 0)
   {
      DLOG(0,0,"Adding OCSI in VLR Camel Subscription information");
      int opid = vcsi.ocsi;
      bool l_OcsiPresent = false;
      map<u16,OCSI*>::iterator l_ocsiItr;
      l_ocsiItr = g_spdPtr->m_OCSIMap.find(opid);
      l_OcsiPresent = 1;
      if(l_OcsiPresent)
      {
         OCSI *l_Ocsi = l_ocsiItr->second;
         if(l_Ocsi->m_csiState == 1)
         {
            LLOG(0,0,"Adding OCSI data of Profile ID %d,Csi state %d, Camel phase support received in UPD %d, Camel Capability of OCSI %d",opid,l_Ocsi->m_csiState,vcsi.rcvd_camel_phase,l_Ocsi->m_camelCapability);
            l_isd->vlrCamelSubscriptionInfo.bit_mask |= OMAP3_VlrCamelSubscriptionInfo_o_CSI_present;
            int OCSICount = 0;
            //Adding CALL_ServiceKey            
            for(int oc=0;oc<OCSI_SERVICEKEY;oc++)
            {
               u32 l_serviceKey = l_Ocsi->m_serviceKey[oc];  
               DLOG(0,0,"Service key is %ld",l_serviceKey);                            

               if(l_serviceKey != 0)
               {
                  OCSICount++;
                  ServiceKey *p_ServiceKey = g_spdPtr->getCallServiceKeyPtr(vcsi.nwId,l_serviceKey);
                  u32 l_NetworkServiceKey = g_spdPtr->getNetworkServiceKey(vcsi.nwId,l_serviceKey);
                  if(NULL == p_ServiceKey)
                  {
                     CLOG(0,0,"p_ServiceKey pointer null");
                     return;
                  }

                  LLOG(0,0,"OCSI ServiceKey[%d] :-  TDP : %d, Default Call Handling : %d, Received Camel phase %d",oc,p_ServiceKey->m_bcsmTDP,p_ServiceKey->m_defCallHandle,vcsi.rcvd_camel_phase);
                  if(((vcsi.rcvd_camel_phase == 1) || (l_Ocsi->m_camelCapability == 1)) && (p_ServiceKey->m_bcsmTDP == 4))                  
                  {
                     WLOG(0,0,"OCSI Profile %d with camel capability %d is having Service key with TDP %d for received camel phase %d",opid,l_Ocsi->m_camelCapability,p_ServiceKey->m_bcsmTDP,vcsi.rcvd_camel_phase);
                     continue;
                  }
                  else
                  {
                     l_isd->vlrCamelSubscriptionInfo.o_CSI.o_BcsmCamelTDPDataList.count = OCSICount;// Max of 2
                     l_isd->vlrCamelSubscriptionInfo.o_CSI.o_BcsmCamelTDPDataList.value[OCSICount-1].o_BcsmTriggerDetectionPoint = (OMAP3_O_BcsmTriggerDetectionPoint)p_ServiceKey->m_bcsmTDP;
                     if(l_serviceKey == l_NetworkServiceKey)
                     {
                        TLOG(0,0,"Ocsi-SK: Sending ServiceKey |%d|",l_serviceKey);
                        l_isd->vlrCamelSubscriptionInfo.o_CSI.o_BcsmCamelTDPDataList.value[OCSICount-1].serviceKey = l_serviceKey;
                     }
                     else
                     {
                        TLOG(0,0,"Ocsi-SK: Sending Network Specific ServiceKey |%d|",l_NetworkServiceKey);
                        l_isd->vlrCamelSubscriptionInfo.o_CSI.o_BcsmCamelTDPDataList.value[OCSICount-1].serviceKey = l_NetworkServiceKey;
                     }
                     l_isd->vlrCamelSubscriptionInfo.o_CSI.o_BcsmCamelTDPDataList.value[OCSICount-1].defaultCallHandling = (OMAP3_DefaultCallHandling)p_ServiceKey->m_defCallHandle;
                     u8 gsmscf[21];
                     memset(gsmscf,'\0',sizeof(gsmscf));
                     strncat((char *)gsmscf,"19",2);
                     if(vcsi.PnwId)
                     {
                        u8 *Pgsmscf = (u8 *)getPartnerGsmScfAddr(p_ServiceKey->m_gsmScfAddr,l_OutScfAddrLen,vcsi.nwId,vcsi.PnwId);
                        if(NULL != Pgsmscf) 
                        {
                           strncat((char *)gsmscf,(char *)Pgsmscf,strlen((char *)Pgsmscf));
                           DLOG(0,0,"Partner GSMSCF Addr found [%s]",gsmscf);                  
                        }
                        else
                        {
                           strncat((char *)gsmscf,(char *)p_ServiceKey->m_gsmScfAddr,strlen((char *)p_ServiceKey->m_gsmScfAddr));
                           WLOG(0,0,"Partner GSMSCF Addr value is NULL, using [%s]",gsmscf);                  
                        }
                     }
                     else
                     {
                        strncat((char *)gsmscf,(char *)p_ServiceKey->m_gsmScfAddr,strlen((char *)p_ServiceKey->m_gsmScfAddr));
                        DLOG(0,0,"GSMSCF Addr value is [%s]",gsmscf);                  
                     }
                     //LLOG(0,0,"GSMSCF Addr value is [%s]",gsmscf);                  
                     LLOG(0,0,"NwId: [%d], Partner NwID: [%d], GsmScfAddr: [%s]",vcsi.nwId,vcsi.PnwId,gsmscf);
                     int len = strlen((char *)gsmscf);
                     l_isd->vlrCamelSubscriptionInfo.o_CSI.o_BcsmCamelTDPDataList.value[OCSICount-1].gsmSCF_Address.length = (len+1)/2;                
                     StringToBCD(l_isd->vlrCamelSubscriptionInfo.o_CSI.o_BcsmCamelTDPDataList.value[OCSICount-1].gsmSCF_Address.value,gsmscf,len);

                  }
               }
               DLOG(0,0,"Added OCSI count on sk %d",OCSICount);
            }
            LLOG(0,0,"Received Camel Capability %d, OCSI camel Capability %d",vcsi.rcvd_camel_phase,l_Ocsi->m_camelCapability);
            if((l_Ocsi->m_camelCapability > 1))
            {
               if(vcsi.rcvd_camel_phase)
               {
                  if(vcsi.rcvd_camel_phase < l_Ocsi->m_camelCapability)
                  {
                     if(vcsi.rcvd_camel_phase != 1)
                     {
                        l_isd->vlrCamelSubscriptionInfo.o_CSI.bit_mask |= OMAP3_O_CSI_camelCapabilityHandling_present;
                        l_isd->vlrCamelSubscriptionInfo.o_CSI.camelCapabilityHandling = (OMAP3_CamelCapabilityHandling)vcsi.rcvd_camel_phase;
                        LLOG(0,0,"Camel Capability handling %d",vcsi.rcvd_camel_phase);
                     }
                  }
                  else
                  {
                     l_isd->vlrCamelSubscriptionInfo.o_CSI.bit_mask |= OMAP3_O_CSI_camelCapabilityHandling_present;
                     l_isd->vlrCamelSubscriptionInfo.o_CSI.camelCapabilityHandling = (OMAP3_CamelCapabilityHandling)l_Ocsi->m_camelCapability;
                     LLOG(0,0,"Camel Capability handling %d",l_Ocsi->m_camelCapability);
                  }
               }
               else
               {
                  l_isd->vlrCamelSubscriptionInfo.o_CSI.bit_mask |= OMAP3_O_CSI_camelCapabilityHandling_present;
                  l_isd->vlrCamelSubscriptionInfo.o_CSI.camelCapabilityHandling = (OMAP3_CamelCapabilityHandling)l_Ocsi->m_camelCapability;
                  LLOG(0,0,"Camel Capability handling %d",l_Ocsi->m_camelCapability);
               }
            }
            DLOG(0,0,"Added OCSI");
         }
         else
         {
            CLOG(0,0,"CSI stace is inactive, not adding it");
         }
      }
      else
      {
         CLOG(0,0,"No profile present for OCSI Profile Id %d",opid);         
      }
   }   
}

//void VlrCamelSubsinfo::formSsCsi(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd)
void VlrCamelSubsinfo::formSsCsi(OMAP3_InsertSubscriberDataArg *l_isd)
{
   DLOG(0,0,"SSCSI Profile ID = %d",vcsi.sscsi);
   if(vcsi.sscsi != 0)
   {
      int sspid = vcsi.sscsi;
      bool l_SscsiPresent = false;
      map<u16,SSCSI*>::iterator l_SscsiItr;
      l_SscsiItr = g_spdPtr->m_SSCSIMap.find(sspid);
      if(l_SscsiItr == g_spdPtr->m_SSCSIMap.end())
      {
         CLOG(0,0,"SSCSI profileId |%d| not found in map",sspid);
         l_SscsiPresent = false;
      }
      else
      {
         l_SscsiPresent = true;
      }
      if(l_SscsiPresent)
      {
         SSCSI *l_Sscsi = l_SscsiItr->second;
         DLOG(0,0,"SS Csi state %d",l_Sscsi->m_csiState);
         if(l_Sscsi->m_csiState)
         {
            LLOG(0,0,"Adding SSCSI in VLR Camel Subscription information Profile id %d",vcsi.sscsi);
            l_isd->vlrCamelSubscriptionInfo.bit_mask |= OMAP3_VlrCamelSubscriptionInfo_ss_CSI_present;
            int l_ssEvntCnt = 0;
            //l_isd->vlrCamelSubscriptionInfo.ss_CSI.ss_CamelData.ss_EventList.count = l_ssEvntCnt;

            if(l_Sscsi->m_ssECT)
            {
               l_isd->vlrCamelSubscriptionInfo.ss_CSI.ss_CamelData.ss_EventList.value[l_ssEvntCnt].length = 1;
               l_isd->vlrCamelSubscriptionInfo.ss_CSI.ss_CamelData.ss_EventList.value[l_ssEvntCnt].value[0] = 49;
               DLOG(0,0,"Adding SS Event for ECT,SS code %d ",l_isd->vlrCamelSubscriptionInfo.ss_CSI.ss_CamelData.ss_EventList.value[l_ssEvntCnt].value[0]);
               l_ssEvntCnt++;            
            }

            if(l_Sscsi->m_ssCD)
            {
               l_isd->vlrCamelSubscriptionInfo.ss_CSI.ss_CamelData.ss_EventList.value[l_ssEvntCnt].length = 1;
               l_isd->vlrCamelSubscriptionInfo.ss_CSI.ss_CamelData.ss_EventList.value[l_ssEvntCnt].value[0] = 36;
               DLOG(0,0,"Adding SS Event for Call Deflection ,SS code %d ",l_isd->vlrCamelSubscriptionInfo.ss_CSI.ss_CamelData.ss_EventList.value[l_ssEvntCnt].value[0]);
               l_ssEvntCnt++;
            }

            if(l_Sscsi->m_ssMPTY)
            {
               l_isd->vlrCamelSubscriptionInfo.ss_CSI.ss_CamelData.ss_EventList.value[l_ssEvntCnt].length = 1;
               l_isd->vlrCamelSubscriptionInfo.ss_CSI.ss_CamelData.ss_EventList.value[l_ssEvntCnt].value[0] = 80;
               DLOG(0,0,"Adding SS Event for Multi party,SS code %d ",l_isd->vlrCamelSubscriptionInfo.ss_CSI.ss_CamelData.ss_EventList.value[l_ssEvntCnt].value[0]);
               l_ssEvntCnt++;
            }

            if(l_Sscsi->m_ssCCBS)
            {
               l_isd->vlrCamelSubscriptionInfo.ss_CSI.ss_CamelData.ss_EventList.value[l_ssEvntCnt].length = 1;
               l_isd->vlrCamelSubscriptionInfo.ss_CSI.ss_CamelData.ss_EventList.value[l_ssEvntCnt].value[0] = 67;
               DLOG(0,0,"Adding SS Event for CCBS ,SS code %d ",l_isd->vlrCamelSubscriptionInfo.ss_CSI.ss_CamelData.ss_EventList.value[l_ssEvntCnt].value[0]);
               l_ssEvntCnt++;
            }

            DLOG(0,0,"SS CSI Event count added is %d",l_ssEvntCnt);           
            l_isd->vlrCamelSubscriptionInfo.ss_CSI.ss_CamelData.ss_EventList.count = l_ssEvntCnt;

            u8 gsmscf1[21];
            memset(gsmscf1,'\0',sizeof(gsmscf1));
            strncpy((char *)gsmscf1,"19",2);
            if(vcsi.PnwId)
            {
               u8 *Pgsmscf = (u8 *)getPartnerGsmScfAddr(l_Sscsi->m_gsmScfAddr,l_OutScfAddrLen,vcsi.nwId,vcsi.PnwId);
               if(NULL != Pgsmscf) 
               { 
                  strncat((char *)gsmscf1,(char *)Pgsmscf,strlen((char *)Pgsmscf));        
               }             
               else
                  strncat((char *)gsmscf1,(char *)l_Sscsi->m_gsmScfAddr,strlen((char *)l_Sscsi->m_gsmScfAddr));
            }
            else
            {
               strncat((char *)gsmscf1,(char *)l_Sscsi->m_gsmScfAddr,strlen((char *)l_Sscsi->m_gsmScfAddr));
            }
            LLOG(0,0,"GSMSCF Addr for SS_CSI is %s",gsmscf1);
            int len1 = strlen((char *)gsmscf1);
            l_isd->vlrCamelSubscriptionInfo.ss_CSI.ss_CamelData.gsmSCF_Address.length = (len1+1)/2;                  
            StringToBCD(l_isd->vlrCamelSubscriptionInfo.ss_CSI.ss_CamelData.gsmSCF_Address.value,gsmscf1,len1);            
         }
         else
         {
            WLOG(0,0,"SS CSI state is inactive, not adding it");
         }
      }
      else
      {
         CLOG(0,0,"No profile loaded for SSCSI Profile Id %d",sspid);         
      }         
   }
}

//void VlrCamelSubsinfo::formTifCsi(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd)
void VlrCamelSubsinfo::formTifCsi(OMAP3_InsertSubscriberDataArg *l_isd)
{
   if(vcsi.tifcsi != 0)
   {
      DLOG(0,0,"TIFCSI Profile ID = %d",vcsi.tifcsi);
      bool l_TifcsiPresent = false;
      map<u16,TIFCSI*>::iterator l_TifcsiItr;
      l_TifcsiItr = g_spdPtr->m_TIFCSIMap.find(vcsi.tifcsi);
      if(l_TifcsiItr == g_spdPtr->m_TIFCSIMap.end())
      {
         CLOG(0,0,"TIFCSI profileID |%d| not found in map.. ",vcsi.tifcsi);
         l_TifcsiPresent = false;
      }
      else
      {
         l_TifcsiPresent = true;
      }
      if(l_TifcsiPresent)
      {
         TIFCSI *l_Tifcsi = l_TifcsiItr->second;
         if(l_Tifcsi->m_flag)
         {
            LLOG(0,0,"Adding TIFCSI in VLR Camel Subscription information");
            l_isd->vlrCamelSubscriptionInfo.bit_mask |= OMAP3_VlrCamelSubscriptionInfo_tif_CSI_present;
         }
         else
         {
            WLOG(0,0,"TIF_CSI profile is Inactive");
         }
      }
      else
      {
         CLOG(0,0,"No profile present for the TIFCSI profile ID %d",vcsi.tifcsi);
      }        
   }    
   //return *l_isd;
}

//void VlrCamelSubsinfo::formObcsmTdp(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd)
void VlrCamelSubsinfo::formObcsmTdp(OMAP3_InsertSubscriberDataArg *l_isd)
{
   LLOG(0,0,"O BCSM TDP Criteria,OCSI Profile ID = %d",vcsi.ocsi);
   if(vcsi.ocsi != 0) 
   {                                                                    
      bool dnc,bsc,ctc,cvc;// = false;
      int ObcsmPid = vcsi.ocsi;
      bool l_OcsiPresent = false;
      map<u16,OCSI*>::iterator l_ocsiItr;
      l_ocsiItr = g_spdPtr->m_OCSIMap.find(ObcsmPid);
      if(l_ocsiItr == g_spdPtr->m_OCSIMap.end())
      {
         CLOG(0,0,"OCSI profileID |%d| not found in map.. ",ObcsmPid);
         l_OcsiPresent = false;
      }
      else
      {
         l_OcsiPresent = true;
      }
      if(l_OcsiPresent)
      {
         OCSI *l_Ocsi = l_ocsiItr->second;
         if((l_Ocsi->m_camelCapability != 1) && (l_Ocsi->m_csiState == 1))
         {
            DLOG(0,0,"Adding Obcsm TDP Criteria in VLR Camel Subscription information ");
            unsigned int sk;
            //Only two service key with BCSM_TDP's as 2 and 4 when camel phase > 1
            int ObcsmCount = 0;
            for(int ob = 0;ob < O_BCSMTDP_CRITERIA;ob++)
            {              
               sk = l_Ocsi->m_serviceKey[ob];
               TLOG(0,0,"OBCSMTDP[%d] Service key is [%ld]",ob,sk);
               if(sk != 0)
               {
                  ServiceKey *p_ServiceKey = g_spdPtr->getCallServiceKeyPtr(vcsi.nwId,sk);
                  if(p_ServiceKey == NULL)
                  {
                     CLOG(0,0,"p_ServiceKey pointer null");
                     return;
                  }
                  LLOG(0,0,"OBCSM TDP: Criteria value is %d",p_ServiceKey->m_criteriaVal);
                  if(p_ServiceKey->m_criteriaVal)
                  {
                     ObcsmCount++;
                     l_isd->vlrCamelSubscriptionInfo.o_BcsmCamelTDP_CriteriaList.count = ObcsmCount;
                     l_isd->vlrCamelSubscriptionInfo.bit_mask |= OMAP3_VlrCamelSubscriptionInfo_o_BcsmCamelTDP_CriteriaList_present;
                     l_isd->vlrCamelSubscriptionInfo.o_BcsmCamelTDP_CriteriaList.value[ObcsmCount-1].o_BcsmTriggerDetectionPoint = (OMAP3_O_BcsmTriggerDetectionPoint)p_ServiceKey->m_bcsmTDP;
                     dnc = false; bsc = false; ctc = false; cvc = false;
                     switch(p_ServiceKey->m_criteriaVal)
                     {
                        case 1:
                           dnc = true;
                           bsc = false;
                           ctc = false;
                           cvc = false;
                           DLOG(0,0,"OBCSM TDP: numCriteria present");

                           break;
                        case 2:
                           dnc = false;
                           bsc = true;
                           ctc = false;
                           cvc = false;
                           DLOG(0,0,"OBCSM TDP: bsCriteria present");
                           break;
                        case 3:
                           dnc = true;
                           bsc = true;
                           ctc = false;
                           cvc = false;
                           DLOG(0,0,"OBCSM TDP: numCriteria and bsCriteria present");
                           break;
                        case 4:
                           dnc = false;
                           bsc = false;
                           ctc = true;
                           cvc = false;
                           DLOG(0,0,"OBCSM TDP: callTypeCriteria present");
                           break;
                        case 5:
                           dnc = true;
                           bsc = false;
                           ctc = true;
                           cvc = false;
                           DLOG(0,0,"OBCSM TDP: numCriteria and callTypeCriteria present");
                           break;
                        case 6:
                           dnc = false;
                           bsc = true;
                           ctc = true;
                           cvc = false;
                           DLOG(0,0,"OBCSM TDP: bsCriteria and callTypeCriteria present");
                           break;
                        case 7:
                           dnc = true;
                           bsc = true;
                           ctc = true;
                           cvc = false;
                           DLOG(0,0,"OBCSM TDP: numCriteria, bsCriteria and callTypeCriteriaeria present");
                           break;
                        case 8:
                           dnc = false;
                           bsc = false;
                           ctc = false;
                           cvc = true;
                           DLOG(0,0,"OBCSM TDP: causeValCriteria present");
                           break;
                        default:
                           dnc = false;
                           bsc = false;
                           ctc = false;
                           cvc = false;
                           DLOG(0,0,"OBCSM TDP: No criteria present");
                           break;
                     }

                     if(dnc)
                     {
                        u16 l_matchType = (int)p_ServiceKey->m_destCriteria.m_matchType;
                        DLOG(0,0,"Destination number criteria matchType is %d",l_matchType);
                        if((l_matchType == 0) || (l_matchType == 1))
                        {
                           DLOG(0,0,"Adding Destination number criteria");
                           l_isd->vlrCamelSubscriptionInfo.o_BcsmCamelTDP_CriteriaList.value[ObcsmCount-1].bit_mask |= OMAP3_destinationNumberCriteria_present;
                           l_isd->vlrCamelSubscriptionInfo.o_BcsmCamelTDP_CriteriaList.value[ObcsmCount-1].destinationNumberCriteria.matchType = (OMAP3_MatchType)l_matchType;
                        }
                        int l_destNumLenListCount = p_ServiceKey->m_destCriteria.m_destNumCritLenListCount;
                        LLOG(0,0,"Destination number length list count is %d, Destination Number Length 1 %c, Destination Number Length 2 %c, Destination Number Length 3 %c",l_destNumLenListCount,p_ServiceKey->m_destCriteria.m_destNumLenList[0],p_ServiceKey->m_destCriteria.m_destNumLenList[1],p_ServiceKey->m_destCriteria.m_destNumLenList[2]);
                        if(l_destNumLenListCount)
                        {
                           l_isd->vlrCamelSubscriptionInfo.o_BcsmCamelTDP_CriteriaList.value[ObcsmCount-1].destinationNumberCriteria.bit_mask |= OMAP3_destinationNumberLengthList_present;
                           for(int k=0; k < l_destNumLenListCount; k++)
                           {
                              l_isd->vlrCamelSubscriptionInfo.o_BcsmCamelTDP_CriteriaList.value[ObcsmCount-1].destinationNumberCriteria.destinationNumberLengthList.count = k+1;
                              l_isd->vlrCamelSubscriptionInfo.o_BcsmCamelTDP_CriteriaList.value[ObcsmCount-1].destinationNumberCriteria.destinationNumberLengthList.value[k] = p_ServiceKey->m_destCriteria.m_destNumLenList[k];
                           }

                        }
                        int l_destNumListCount =  p_ServiceKey->m_destCriteria.m_destNumCritListCount;
                        LLOG(0,0,"Destination Number count is %d, Destination Number 1 %s, Destination Number 2 %s, Destination Number 3 %s, Destination Number 4 %s, Destination Number 5 %s, Destination Number 6 %s, Destination Number 7 %s, Destination Number 8 %s, Destination Number 9 %s, Destination Number 10 %s ",
                              l_destNumListCount,p_ServiceKey->m_destCriteria.m_destNumList1,p_ServiceKey->m_destCriteria.m_destNumList2,p_ServiceKey->m_destCriteria.m_destNumList3,p_ServiceKey->m_destCriteria.m_destNumList4,p_ServiceKey->m_destCriteria.m_destNumList5,
                              p_ServiceKey->m_destCriteria.m_destNumList6,p_ServiceKey->m_destCriteria.m_destNumList7,p_ServiceKey->m_destCriteria.m_destNumList8,p_ServiceKey->m_destCriteria.m_destNumList9,p_ServiceKey->m_destCriteria.m_destNumList10);
                        if(l_destNumListCount)
                        {
                           l_isd->vlrCamelSubscriptionInfo.o_BcsmCamelTDP_CriteriaList.value[ObcsmCount-1].destinationNumberCriteria.bit_mask |= OMAP3_destinationNumberList_present;
                           l_isd->vlrCamelSubscriptionInfo.o_BcsmCamelTDP_CriteriaList.value[ObcsmCount-1].destinationNumberCriteria.destinationNumberList.count = l_destNumListCount;
                           for(int p=0; p<l_destNumListCount; p++)
                           {
                              switch(p)
                              {
                                 case 0:
                                    {

                                       u8 dest1[21]; memset(dest1,'\0',sizeof(dest1));
                                       strncpy((char *)dest1,"19",2);
                                       strncat((char *)dest1,(char *)p_ServiceKey->m_destCriteria.m_destNumList1,strlen((char *)p_ServiceKey->m_destCriteria.m_destNumList1));
                                       int leng1 = strlen((char *)dest1);
                                       l_isd->vlrCamelSubscriptionInfo.o_BcsmCamelTDP_CriteriaList.value[ObcsmCount-1].destinationNumberCriteria.destinationNumberList.value[p].length = (leng1+1)/2;
                                       StringToBCD(l_isd->vlrCamelSubscriptionInfo.o_BcsmCamelTDP_CriteriaList.value[ObcsmCount-1].destinationNumberCriteria.destinationNumberList.value[p].value,dest1,leng1);

                                    }
                                    break;
                                 case 1:
                                    {

                                       u8 dest2[21]; memset(dest2,'\0',sizeof(dest2));
                                       strncpy((char *)dest2,"19",2);
                                       strncat((char *)dest2,(char *)p_ServiceKey->m_destCriteria.m_destNumList2,strlen((char *)p_ServiceKey->m_destCriteria.m_destNumList2));
                                       int leng2 = strlen((char *)dest2);
                                       l_isd->vlrCamelSubscriptionInfo.o_BcsmCamelTDP_CriteriaList.value[ObcsmCount-1].destinationNumberCriteria.destinationNumberList.value[p].length = (leng2+1)/2;
                                       StringToBCD(l_isd->vlrCamelSubscriptionInfo.o_BcsmCamelTDP_CriteriaList.value[ObcsmCount-1].destinationNumberCriteria.destinationNumberList.value[p].value,dest2,leng2);                                 
                                    }
                                    break;
                                 case 2:
                                    {

                                       u8 dest3[21]; memset(dest3,'\0',sizeof(dest3));
                                       strncpy((char *)dest3,"19",2);
                                       strncat((char *)dest3,(char *)p_ServiceKey->m_destCriteria.m_destNumList3,strlen((char *)p_ServiceKey->m_destCriteria.m_destNumList3));
                                       int leng3 = strlen((char *)dest3);
                                       l_isd->vlrCamelSubscriptionInfo.o_BcsmCamelTDP_CriteriaList.value[ObcsmCount-1].destinationNumberCriteria.destinationNumberList.value[p].length = (leng3+1)/2;
                                       StringToBCD(l_isd->vlrCamelSubscriptionInfo.o_BcsmCamelTDP_CriteriaList.value[ObcsmCount-1].destinationNumberCriteria.destinationNumberList.value[p].value,dest3,leng3);
                                    }
                                    break;
                                 case 3:
                                    {

                                       u8 dest4[21]; memset(dest4,'\0',sizeof(dest4));
                                       strncpy((char *)dest4,"19",2);
                                       strncat((char *)dest4,(char *)p_ServiceKey->m_destCriteria.m_destNumList4,strlen((char *)p_ServiceKey->m_destCriteria.m_destNumList4));
                                       int leng4 = strlen((char *)dest4);
                                       l_isd->vlrCamelSubscriptionInfo.o_BcsmCamelTDP_CriteriaList.value[ObcsmCount-1].destinationNumberCriteria.destinationNumberList.value[p].length = (leng4+1)/2;
                                       StringToBCD(l_isd->vlrCamelSubscriptionInfo.o_BcsmCamelTDP_CriteriaList.value[ObcsmCount-1].destinationNumberCriteria.destinationNumberList.value[p].value,dest4,leng4);
                                    }
                                    break;
                                 case 4:
                                    {

                                       u8 dest5[21]; memset(dest5,'\0',sizeof(dest5));
                                       strncpy((char *)dest5,"19",2);
                                       strncat((char *)dest5,(char *)p_ServiceKey->m_destCriteria.m_destNumList5,strlen((char *)p_ServiceKey->m_destCriteria.m_destNumList5));
                                       int leng5 = strlen((char *)dest5);
                                       l_isd->vlrCamelSubscriptionInfo.o_BcsmCamelTDP_CriteriaList.value[ObcsmCount-1].destinationNumberCriteria.destinationNumberList.value[p].length = (leng5+1)/2;
                                       StringToBCD(l_isd->vlrCamelSubscriptionInfo.o_BcsmCamelTDP_CriteriaList.value[ObcsmCount-1].destinationNumberCriteria.destinationNumberList.value[p].value,dest5,leng5);
                                    }
                                    break;
                                 case 5:
                                    {                                 
                                       u8 dest6[21]; memset(dest6,'\0',sizeof(dest6));
                                       strncpy((char *)dest6,"19",2);
                                       strncat((char *)dest6,(char *)p_ServiceKey->m_destCriteria.m_destNumList6,strlen((char *)p_ServiceKey->m_destCriteria.m_destNumList6));
                                       int leng6 = strlen((char *)dest6);
                                       l_isd->vlrCamelSubscriptionInfo.o_BcsmCamelTDP_CriteriaList.value[ObcsmCount-1].destinationNumberCriteria.destinationNumberList.value[p].length = (leng6+1)/2;
                                       StringToBCD(l_isd->vlrCamelSubscriptionInfo.o_BcsmCamelTDP_CriteriaList.value[ObcsmCount-1].destinationNumberCriteria.destinationNumberList.value[p].value,dest6,leng6);
                                    }
                                    break;
                                 case 6:
                                    {                                 
                                       u8 dest7[21]; memset(dest7,'\0',sizeof(dest7));
                                       strncpy((char *)dest7,"19",2);
                                       strncat((char *)dest7,(char *)p_ServiceKey->m_destCriteria.m_destNumList7,strlen((char *)p_ServiceKey->m_destCriteria.m_destNumList7));
                                       int leng7 = strlen((char *)dest7);
                                       l_isd->vlrCamelSubscriptionInfo.o_BcsmCamelTDP_CriteriaList.value[ObcsmCount-1].destinationNumberCriteria.destinationNumberList.value[p].length = (leng7+1)/2;
                                       StringToBCD(l_isd->vlrCamelSubscriptionInfo.o_BcsmCamelTDP_CriteriaList.value[ObcsmCount-1].destinationNumberCriteria.destinationNumberList.value[p].value,dest7,leng7);
                                    }
                                    break;
                                 case 7:
                                    {                               
                                       u8 dest8[21]; memset(dest8,'\0',sizeof(dest8));
                                       strncpy((char *)dest8,"19",2);
                                       strncat((char *)dest8,(char *)p_ServiceKey->m_destCriteria.m_destNumList8,strlen((char *)p_ServiceKey->m_destCriteria.m_destNumList8));
                                       int leng8 = strlen((char *)dest8);                                 
                                       l_isd->vlrCamelSubscriptionInfo.o_BcsmCamelTDP_CriteriaList.value[ObcsmCount-1].destinationNumberCriteria.destinationNumberList.value[p].length = (leng8+1)/2;
                                       StringToBCD(l_isd->vlrCamelSubscriptionInfo.o_BcsmCamelTDP_CriteriaList.value[ObcsmCount-1].destinationNumberCriteria.destinationNumberList.value[p].value,dest8,leng8);                                 
                                    }
                                    break;
                                 case 8:
                                    {

                                       u8 dest9[21]; memset(dest9,'\0',sizeof(dest9));
                                       strncpy((char *)dest9,"19",2);
                                       strncat((char *)dest9,(char *)p_ServiceKey->m_destCriteria.m_destNumList9,strlen((char *)p_ServiceKey->m_destCriteria.m_destNumList9));
                                       int leng9 = strlen((char *)dest9);
                                       l_isd->vlrCamelSubscriptionInfo.o_BcsmCamelTDP_CriteriaList.value[ObcsmCount-1].destinationNumberCriteria.destinationNumberList.value[p].length = (leng9+1)/2;
                                       StringToBCD(l_isd->vlrCamelSubscriptionInfo.o_BcsmCamelTDP_CriteriaList.value[ObcsmCount-1].destinationNumberCriteria.destinationNumberList.value[p].value,dest9,leng9);
                                    }
                                    break;
                                 case 9:
                                    {

                                       u8 dest10[21]; memset(dest10,'\0',sizeof(dest10));
                                       strncpy((char *)dest10,"19",2);
                                       strncat((char *)dest10,(char *)p_ServiceKey->m_destCriteria.m_destNumList10,strlen((char *)p_ServiceKey->m_destCriteria.m_destNumList10));
                                       int leng10 = strlen((char *)dest10);                                 
                                       l_isd->vlrCamelSubscriptionInfo.o_BcsmCamelTDP_CriteriaList.value[ObcsmCount-1].destinationNumberCriteria.destinationNumberList.value[p].length = (leng10+1)/2;
                                       StringToBCD(l_isd->vlrCamelSubscriptionInfo.o_BcsmCamelTDP_CriteriaList.value[ObcsmCount-1].destinationNumberCriteria.destinationNumberList.value[p].value,dest10,leng10);                                 
                                    }
                                    break;
                                 default:
                                    {
                                       DLOG(0,0,"Inside default");
                                    }
                                    break;

                              }
                           }
                        }
                     }

                     if(bsc)
                     {
                        if(p_ServiceKey->m_bsCriteria.m_bsCount < 6)
                        {
                           DLOG(0,0,"Adding Basic Service criteria");
                           l_isd->vlrCamelSubscriptionInfo.o_BcsmCamelTDP_CriteriaList.value[ObcsmCount-1].bit_mask |= OMAP3_O_BcsmCamelTDP_Criteria_basicServiceCriteria_present;
                           //l_isd->vlrCamelSubscriptionInfo.o_BcsmCamelTDP_CriteriaList.value[ob].basicServiceCriteria.value[l].choice = 0;
                           LLOG(0,0,"Basic Service Criteria count %d, Basic service Code[1] - %d, Basic Service Type[1] - %d, Basic service Code[2] - %d, Basic Service Type[2] - %d, Basic service Code[3] - %d, Basic Service Type[3] - %d, Basic service Code[4] - %d, Basic Service Type[4] - %d, Basic service Code[5] - %d, Basic Service Type[5] - %d, ",
                                 p_ServiceKey->m_bsCriteria.m_bsCount,p_ServiceKey->m_bsCriteria.m_bsTypeCode[0].m_bscode,p_ServiceKey->m_bsCriteria.m_bsTypeCode[0].m_bsType,p_ServiceKey->m_bsCriteria.m_bsTypeCode[1].m_bscode,p_ServiceKey->m_bsCriteria.m_bsTypeCode[1].m_bsType,p_ServiceKey->m_bsCriteria.m_bsTypeCode[2].m_bscode,p_ServiceKey->m_bsCriteria.m_bsTypeCode[2].m_bsType,p_ServiceKey->m_bsCriteria.m_bsTypeCode[3].m_bscode,p_ServiceKey->m_bsCriteria.m_bsTypeCode[3].m_bsType,p_ServiceKey->m_bsCriteria.m_bsTypeCode[4].m_bscode,p_ServiceKey->m_bsCriteria.m_bsTypeCode[4].m_bsType);
                           l_isd->vlrCamelSubscriptionInfo.o_BcsmCamelTDP_CriteriaList.value[ObcsmCount-1].basicServiceCriteria.count = p_ServiceKey->m_bsCriteria.m_bsCount;
                           for(int bs = 0;bs <=p_ServiceKey->m_bsCriteria.m_bsCount;bs++)
                              //for(int bs=0; bs < 5; bs++)
                           {
                              unsigned short l=0;
                              if(p_ServiceKey->m_bsCriteria.m_bsTypeCode[bs].m_bsType == 1)
                              {
                                 l_isd->vlrCamelSubscriptionInfo.o_BcsmCamelTDP_CriteriaList.value[ObcsmCount-1].basicServiceCriteria.value[bs].choice |= OMAP3_Ext_BasicServiceCode_ext_BearerService_chosen;
                                 l_isd->vlrCamelSubscriptionInfo.o_BcsmCamelTDP_CriteriaList.value[ObcsmCount-1].basicServiceCriteria.value[bs].u.ext_BearerService.length = 1;//strlen((char *)p_ServiceKey->m_bsCriteria.m_bs[bs]);
                                 l_isd->vlrCamelSubscriptionInfo.o_BcsmCamelTDP_CriteriaList.value[ObcsmCount-1].basicServiceCriteria.value[bs].u.ext_BearerService.value[0] =  p_ServiceKey->m_bsCriteria.m_bsTypeCode[bs].m_bscode;
                                 l++;
                              }
                              if(p_ServiceKey->m_bsCriteria.m_bsTypeCode[bs].m_bsType == 2)
                              {
                                 l_isd->vlrCamelSubscriptionInfo.o_BcsmCamelTDP_CriteriaList.value[ObcsmCount-1].basicServiceCriteria.value[bs].choice |= OMAP3_Ext_BasicServiceCode_ext_Teleservice_chosen;
                                 l_isd->vlrCamelSubscriptionInfo.o_BcsmCamelTDP_CriteriaList.value[ObcsmCount-1].basicServiceCriteria.value[bs].u.ext_Teleservice.length = 1;
                                 l_isd->vlrCamelSubscriptionInfo.o_BcsmCamelTDP_CriteriaList.value[ObcsmCount-1].basicServiceCriteria.value[bs].u.ext_Teleservice.value[0] = p_ServiceKey->m_bsCriteria.m_bsTypeCode[bs].m_bscode;
                                 l++;
                              }
                           }
                        }
                        else
                        {
                           CLOG(0,0,"BASIC service criteria count received %d is greater than 5",p_ServiceKey->m_bsCriteria.m_bsCount)
                        }
                     }
                     if(ctc)
                     {
                        DLOG(0,0,"Adding Call type criteria value %d",p_ServiceKey->m_callTypeCriteria);
                        l_isd->vlrCamelSubscriptionInfo.o_BcsmCamelTDP_CriteriaList.value[ObcsmCount-1].bit_mask |= OMAP3_callTypeCriteria_present;
                        l_isd->vlrCamelSubscriptionInfo.o_BcsmCamelTDP_CriteriaList.value[ObcsmCount-1].callTypeCriteria = (OMAP3_CallTypeCriteria)p_ServiceKey->m_callTypeCriteria;
                     }
                     //Filling for Service Key 1 with BCSM_TDP = 4
                     if(cvc)
                     {
                        LLOG(0,0,"Adding Cause value criteria, Number of Cause value present %d, Cause_value[1] - %d, Cause_value[2] - %d, Cause_value[3] - %d, Cause_value[4] - %d, Cause_value[5] - %d",
                              p_ServiceKey->m_cvCriteria.m_cvCount,p_ServiceKey->m_cvCriteria.m_cv[0],p_ServiceKey->m_cvCriteria.m_cv[1],p_ServiceKey->m_cvCriteria.m_cv[2],p_ServiceKey->m_cvCriteria.m_cv[3],p_ServiceKey->m_cvCriteria.m_cv[4]);
                        l_isd->vlrCamelSubscriptionInfo.o_BcsmCamelTDP_CriteriaList.value[ObcsmCount-1].bit_mask |= OMAP3_o_CauseValueCriteria_present;
                        l_isd->vlrCamelSubscriptionInfo.o_BcsmCamelTDP_CriteriaList.value[ObcsmCount-1].o_CauseValueCriteria.count = p_ServiceKey->m_cvCriteria.m_cvCount;
                        for(int cv = 0;cv<=p_ServiceKey->m_cvCriteria.m_cvCount;cv++)
                        {
                           l_isd->vlrCamelSubscriptionInfo.o_BcsmCamelTDP_CriteriaList.value[ObcsmCount-1].o_CauseValueCriteria.value[cv].length = 1;
                           l_isd->vlrCamelSubscriptionInfo.o_BcsmCamelTDP_CriteriaList.value[ObcsmCount-1].o_CauseValueCriteria.value[cv].value[0] = p_ServiceKey->m_cvCriteria.m_cv[cv];
                        }
                     }
                  }
                  else
                  {
                     LLOG(0,0,"Criteria val is %d for Servicekey %d, not Adding it",p_ServiceKey->m_criteriaVal,sk);
                  }
               }
               DLOG(0,0,"After OBCSM TDP for Count %d",ob);
            }
            DLOG(0,0,"Added O_BCSM_TDP Criteria list in VLR camel subscription Info");
         }
         else
         {
            WLOG(0,0,"Camel capability of the CSI is %d, Camel capability %d, not adding criterias",l_Ocsi->m_camelCapability,l_Ocsi->m_csiState);
         }
      }
      else
      {
         CLOG(0,0,"No profile present for OCSI profile ID %d",vcsi.ocsi);         
      }      
   }
}


//void VlrCamelSubsinfo::formDCsi(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd)
void VlrCamelSubsinfo::formDCsi(OMAP3_InsertSubscriberDataArg *l_isd)
{
   DLOG(0,0,"DCSI Profile ID = %d",vcsi.dcsi);
   if(vcsi.dcsi != 0)
   {      
      bool l_DcsiPresent = false;
      map<u16,DCSI*>::iterator l_dcsiItr;
      l_dcsiItr = g_spdPtr->m_DCSIMap.find(vcsi.dcsi);
      if(l_dcsiItr == g_spdPtr->m_DCSIMap.end())
      {
         CLOG(0,0,"DCSI profileID |%d| not found in map.. ",vcsi.dcsi);
         l_DcsiPresent = false;
      }
      else
      {
         l_DcsiPresent = true;
      }
      if(l_DcsiPresent)
      {
         DCSI *l_dcsi = l_dcsiItr->second;
         if(l_dcsi->m_camelCapability > 2)
         {
            DLOG(0,0,"DCSI profile data :- CSI state %d",l_dcsi->m_csiState);
            if((l_dcsi->m_csiState))
            {
               l_isd->vlrCamelSubscriptionInfo.bit_mask |= OMAP3_VlrCamelSubscriptionInfo_d_CSI_present;
               if(l_dcsi->m_serviceKey3)
               {
                  ServiceKey *p_ServiceKey = g_spdPtr->getCallServiceKeyPtr(vcsi.nwId,l_dcsi->m_serviceKey3); 
                  u32 l_NetworkServiceKey = g_spdPtr->getNetworkServiceKey(vcsi.nwId,l_dcsi->m_serviceKey3);
                  if(NULL == p_ServiceKey)
                  {
                     CLOG(0,0,"p_ServiceKey in NULL");
                     return;
                  }

                  LLOG(0,0,"DCSI :- Service key %ld, Dialled Number %s, GSMSCF Address %s, Default call handling %d, Camel capability handling %d",l_dcsi->m_serviceKey3,p_ServiceKey->m_dialledNum,p_ServiceKey->m_gsmScfAddr,p_ServiceKey->m_defCallHandle,l_dcsi->m_camelCapability);
                  l_isd->vlrCamelSubscriptionInfo.d_CSI.bit_mask = OMAP3_dp_AnalysedInfoCriteriaList_present;
                  l_isd->vlrCamelSubscriptionInfo.d_CSI.dp_AnalysedInfoCriteriaList.count = 1;
                  u8 l_DledNum[21]; memset(l_DledNum,'\0',sizeof(l_DledNum));
                  strncpy((char *)l_DledNum,"19",2);
                  strncat((char *)l_DledNum,(char *)p_ServiceKey->m_dialledNum,strlen((char *)p_ServiceKey->m_dialledNum));
                  l_isd->vlrCamelSubscriptionInfo.d_CSI.dp_AnalysedInfoCriteriaList.value[0].dialledNumber.length = (strlen((char *)l_DledNum)+1)/2;
                  StringToBCD(l_isd->vlrCamelSubscriptionInfo.d_CSI.dp_AnalysedInfoCriteriaList.value[0].dialledNumber.value,l_DledNum,strlen((char *)l_DledNum));
                  if(l_dcsi->m_serviceKey3 == l_NetworkServiceKey)
                  {
                     LLOG(0,0,"Dcsi SK: Sending ServiceKey [%d]",l_dcsi->m_serviceKey3);
                     l_isd->vlrCamelSubscriptionInfo.d_CSI.dp_AnalysedInfoCriteriaList.value[0].serviceKey = l_dcsi->m_serviceKey3;
                  }
                  else
                  {
                     LLOG(0,0,"Dcsi SK: Sending Network specific ServiceKey [%d]",l_NetworkServiceKey);
                     l_isd->vlrCamelSubscriptionInfo.d_CSI.dp_AnalysedInfoCriteriaList.value[0].serviceKey = l_NetworkServiceKey;
                  }
                  u8 gsmscf2[20];
                  memset(gsmscf2,'\0',sizeof(gsmscf2));
                  strncpy((char *)gsmscf2,"19",2);
                  if(vcsi.PnwId)
                  {
                     u8 *Pgsmscf = (u8 *)getPartnerGsmScfAddr(p_ServiceKey->m_gsmScfAddr,l_OutScfAddrLen,vcsi.nwId,vcsi.PnwId);
                     if(NULL != Pgsmscf) 
                     {
                        strncat((char *)gsmscf2,(char *)Pgsmscf,strlen((char *)Pgsmscf));
                        LLOG(0,0,"Partner GSMSCF addr found [%d]",gsmscf2);
                     }                            
                     else
                     {
                        strncat((char *)gsmscf2,(char *)p_ServiceKey->m_gsmScfAddr,strlen((char *)p_ServiceKey->m_gsmScfAddr));
                        LLOG(0,0,"Partner GSMSCF addr not found [%d]",gsmscf2);
                     }
                  }
                  else
                  {
                     strncat((char *)gsmscf2,(char *)p_ServiceKey->m_gsmScfAddr,strlen((char *)p_ServiceKey->m_gsmScfAddr));
                  }
                  int len2 = strlen((char *)gsmscf2);
                  l_isd->vlrCamelSubscriptionInfo.d_CSI.dp_AnalysedInfoCriteriaList.value[0].gsmSCF_Address.length = (len2+1)/2;
                  StringToBCD(l_isd->vlrCamelSubscriptionInfo.d_CSI.dp_AnalysedInfoCriteriaList.value[0].gsmSCF_Address.value,gsmscf2,strlen((char*)gsmscf2));
                  LLOG(0,0,"Adding DCSI :- Dialled Number %s, GSMSCF Address %s, Default call handling %d, Camel capability handling %d",p_ServiceKey->m_dialledNum,gsmscf2,p_ServiceKey->m_defCallHandle,l_dcsi->m_camelCapability);
                  l_isd->vlrCamelSubscriptionInfo.d_CSI.dp_AnalysedInfoCriteriaList.value[0].defaultCallHandling = (OMAP3_DefaultCallHandling)p_ServiceKey->m_defCallHandle;
               }
               LLOG(0,0,"D_CSI CCH [%d] Rcvd CCH [%d]",l_dcsi->m_camelCapability,vcsi.rcvd_camel_phase);
               if(l_dcsi->m_camelCapability)
               {
                  l_isd->vlrCamelSubscriptionInfo.d_CSI.bit_mask |= OMAP3_D_CSI_camelCapabilityHandling_present;
                  if(l_dcsi->m_camelCapability <= vcsi.rcvd_camel_phase)
                  {
                     l_isd->vlrCamelSubscriptionInfo.d_CSI.camelCapabilityHandling = (OMAP3_CamelCapabilityHandling)l_dcsi->m_camelCapability;               
                  }
                  else
                  {
                     l_isd->vlrCamelSubscriptionInfo.d_CSI.camelCapabilityHandling = (OMAP3_CamelCapabilityHandling)vcsi.rcvd_camel_phase;
                  }
               }
            }
            else
            {
               WLOG(0,0,"DCSI Profile %d CSI state is inactive",vcsi.dcsi);
            }
         }
         else
         {
            CLOG(0,0,"Camel capability of DCSI is %d, it should be minimum 3",l_dcsi->m_camelCapability);   
         }
      }
      else
      {
         CLOG(0,0,"No profile present for the DCSI profile ID %d",vcsi.dcsi);         
      }      
   }
}

#if 1
void VlrCamelSubsinfo::formVTCsi(OMAP3_InsertSubscriberDataArg *l_isd)
{
   if(vcsi.vtcsi != 0)
   {
      DLOG(0,0,"Adding VTCSI from TCSI Profile ID: [%d]",vcsi.vtcsi);
      int tpid = vcsi.vtcsi;
      map<u16,VTCSI*>::iterator l_VtcsiItr;
      l_VtcsiItr = g_spdPtr->m_VTCSIMap.find(tpid);
      if(l_VtcsiItr == g_spdPtr->m_VTCSIMap.end())
      {
         CLOG(0,0,"VTCSI profileID |%d| not found in map.. ",tpid);
         return; // send system failure
      }
      else
      {
         VTCSI *l_VTcsi = l_VtcsiItr->second;
         LLOG(0,0,"csi state [%d] CCH [%d] Rcvd Cap phase [%d]",l_VTcsi->m_csiState,l_VTcsi->m_camelCapability,vcsi.rcvd_camel_phase);


         if(l_VTcsi->m_csiState == 1)
         {
            l_isd->vlrCamelSubscriptionInfo.vt_CSI.bit_mask = OMAP3_T_CSI_camelCapabilityHandling_present;
            LLOG(0,0,"VT_CSI CCH [%d] Rcvd CCH [%d]",l_VTcsi->m_camelCapability,vcsi.rcvd_camel_phase);
            if(vcsi.rcvd_camel_phase < l_VTcsi->m_camelCapability)
            {	
               l_isd->vlrCamelSubscriptionInfo.vt_CSI.camelCapabilityHandling = vcsi.rcvd_camel_phase;
            }
            else
            {
               l_isd->vlrCamelSubscriptionInfo.vt_CSI.camelCapabilityHandling = l_VTcsi->m_camelCapability;
            }
            int tbcsmCount = 0;
            for(int ts = 0;ts < 3;ts++)
            {
               u32 l_serviceKey = l_VTcsi->m_serviceKey[ts];
               DLOG(0,0,"Recevied Service key [%d]",l_serviceKey);
               if(l_serviceKey != 0)
               {
                  ServiceKey *p_ServiceKey = g_spdPtr->getCallServiceKeyPtr(vcsi.nwId,l_serviceKey);
                  u32 l_NetworkServiceKey = g_spdPtr->getNetworkServiceKey(vcsi.nwId,l_serviceKey);
                  LLOG(0,0,"TDP [%d] GSMSCF Addr [%s] NwId [%d] PartnerNwID [%d] Def Call Handle [%d]",
                        p_ServiceKey->m_bcsmTDP,p_ServiceKey->m_gsmScfAddr,vcsi.nwId,vcsi.PnwId,p_ServiceKey->m_defCallHandle);
                  l_isd->vlrCamelSubscriptionInfo.bit_mask |= OMAP3_VlrCamelSubscriptionInfo_vt_CSI_present;
                  tbcsmCount++;
                  l_isd->vlrCamelSubscriptionInfo.vt_CSI.t_BcsmCamelTDPDataList.count = tbcsmCount;
                  if(l_NetworkServiceKey == l_serviceKey)
                  {
                     TLOG(0,0,"VT_CSI SK: Sending ServiceKey [%d]",l_serviceKey);
                     l_isd->vlrCamelSubscriptionInfo.vt_CSI.t_BcsmCamelTDPDataList.value[tbcsmCount-1].serviceKey = l_serviceKey;
                  }
                  else
                  {
                     TLOG(0,0,"VT_CSI SK: Sending NetworkSpecific ServiceKey [%d]",l_NetworkServiceKey);
                     l_isd->vlrCamelSubscriptionInfo.vt_CSI.t_BcsmCamelTDPDataList.value[tbcsmCount-1].serviceKey = l_NetworkServiceKey;
                  }
                  l_isd->vlrCamelSubscriptionInfo.vt_CSI.t_BcsmCamelTDPDataList.value[tbcsmCount-1].t_BcsmTriggerDetectionPoint =(OMAP3_T_BcsmTriggerDetectionPoint)p_ServiceKey->m_bcsmTDP;
                  u8 gsmscf3[21];
                  memset(gsmscf3,'\0',sizeof(gsmscf3));
                  strncat((char *)gsmscf3,"19",2);
                  if(vcsi.PnwId)
                  {
                     u8 *Pgsmscf = (u8 *)getPartnerGsmScfAddr(p_ServiceKey->m_gsmScfAddr,l_OutScfAddrLen,vcsi.nwId,vcsi.PnwId);
                     if(NULL != Pgsmscf) 
                     {                     
                        strncat((char *)gsmscf3,(char *)Pgsmscf,strlen((char *)Pgsmscf));
                     }   
                     else
                     {
                        strncat((char *)gsmscf3,(char *)p_ServiceKey->m_gsmScfAddr,strlen((char *)p_ServiceKey->m_gsmScfAddr));
                     }
                  }
                  else
                  {
                     strncat((char *)gsmscf3,(char *)p_ServiceKey->m_gsmScfAddr,strlen((char *)p_ServiceKey->m_gsmScfAddr));
                  }
                  int len3 = strlen((char *)gsmscf3);
                  l_isd->vlrCamelSubscriptionInfo.vt_CSI.t_BcsmCamelTDPDataList.value[tbcsmCount-1].gsmSCF_Address.length = (len3+1)/2;
                  StringToBCD(l_isd->vlrCamelSubscriptionInfo.vt_CSI.t_BcsmCamelTDPDataList.value[tbcsmCount-1].gsmSCF_Address.value,gsmscf3,strlen((char *)gsmscf3));
                  l_isd->vlrCamelSubscriptionInfo.vt_CSI.t_BcsmCamelTDPDataList.value[tbcsmCount-1].defaultCallHandling =(OMAP3_DefaultCallHandling)p_ServiceKey->m_defCallHandle;
               }
               DLOG(0,0,"Added VTCSI count %d",tbcsmCount);
            }
         }
         else
         {
            WLOG(0,0,"CSI state is inactive");
         }
      }
   }
}


void VlrCamelSubsinfo::formVTbcsmTdp(OMAP3_InsertSubscriberDataArg *l_isd)
{
   if(vcsi.vtcsi)
   {
      DLOG(0,0,"Adding VTbcsm TDP Criteria in VLR Camel Subscription info, Profile ID [%d]",vcsi.vtcsi);
      bool dnc,bsc,ctc,cvc = false;
      map<u16,VTCSI*>::iterator l_VtcsiItr;
      l_VtcsiItr = g_spdPtr->m_VTCSIMap.find(vcsi.vtcsi);
      if(l_VtcsiItr == g_spdPtr->m_VTCSIMap.end())
      {
         CLOG(0,0,"VTCSI profileID |%d| not found in map.. ",vcsi.vtcsi);
         return; // send system failure
      }
      else
      {
         VTCSI *l_VTcsi = l_VtcsiItr->second;
         int sk = 0;
         int Tbcsm = 0;
         for(int tb = 0;tb < T_BCSMTDP_CRITERIA;tb++)
         {
            sk = l_VTcsi->m_serviceKey[tb];
            DLOG(0,0,"Adding VT BCSM TDP count[%d] Service Key [%d]",tb,sk);
            if(sk != 0)
            {
               ServiceKey *p_ServiceKey = g_spdPtr->getCallServiceKeyPtr(vcsi.nwId,sk);
               if(p_ServiceKey == NULL)
               {
                  CLOG(0,0,"p_ServiceKey pointer null");
                  return;
               }
               else
               {
                  DLOG(0,0,"TDP Criteria [%d] BCSM TDP [%d]",p_ServiceKey->m_criteriaVal,p_ServiceKey->m_bcsmTDP);
                  if(p_ServiceKey->m_criteriaVal != 0)
                  {
                     l_isd->vlrCamelSubscriptionInfo.bit_mask |= OMAP3_VlrCamelSubscriptionInfo_t_BCSM_CAMEL_TDP_CriteriaList_present;
                     l_isd->vlrCamelSubscriptionInfo.t_BCSM_CAMEL_TDP_CriteriaList.count = Tbcsm+1;
                     l_isd->vlrCamelSubscriptionInfo.t_BCSM_CAMEL_TDP_CriteriaList.value[Tbcsm].t_BCSM_TriggerDetectionPoint = (OMAP3_T_BcsmTriggerDetectionPoint)p_ServiceKey->m_bcsmTDP;
                     switch(p_ServiceKey->m_criteriaVal)
                     {
                        case 1:
                           {
                              dnc = true;
                              bsc = false;
                              ctc = false;
                              cvc = false;
                              DLOG(0,0,"TBCSM TDP: numCriteria present");
                           }
                           break;
                        case 2:
                           {
                              dnc = false;
                              bsc = true;
                              ctc = false;
                              cvc = false;
                              DLOG(0,0,"TBCSM TDP: bsCriteria present");
                           }
                           break;
                        case 3:
                           {
                              dnc = true;
                              bsc = true;
                              ctc = false;
                              cvc = false;
                              DLOG(0,0,"TBCSM TDP: numCriteria and bsCriteria present");
                           }
                           break;
                        case 4:
                           dnc = false;
                           bsc = false;
                           ctc = true;
                           cvc = false;
                           DLOG(0,0,"TBCSM TDP: callTypeCriteria present");
                           break;
                        case 5:
                           dnc = true;
                           bsc = false;
                           ctc = true;
                           cvc = false;
                           DLOG(0,0,"TBCSM TDP: numCriteria and callTypeCriteria present");
                           break;
                        case 6:
                           dnc = false;
                           bsc = true;
                           ctc = true;
                           cvc = false;
                           DLOG(0,0,"TBCSM TDP: bsCriteria and callTypeCriteria present");
                           break;
                        case 7:
                           dnc = true;
                           bsc = true;
                           ctc = true;
                           cvc = false;
                           DLOG(0,0,"TBCSM TDP: numCriteria, bsCriteria and callTypeCriteriaeria present");
                           break;
                        case 8:
                           dnc = false;
                           bsc = false;
                           ctc = false;
                           cvc = true;
                           DLOG(0,0,"TBCSM TDP: causeValCriteria present");
                           break;
                        default:
                           dnc = false;
                           bsc = false;
                           ctc = false;
                           cvc = false;
                           DLOG(0,0,"TBCSM TDP: No criteria present");
                           break;
                     }
                     if(bsc)
                     {
                        DLOG(0,0,"Basic Service Criteria count [%d], Basic service Code[1] - %d, Basic Service Type[1] - %d, Basic service Code[2] - %d, Basic Service Type[2] - %d, Basic service Code[3] - %d, Basic Service Type[3] - %d, Basic service Code[4] - %d, Basic Service Type[4] - %d, Basic service Code[5] - %d, Basic Service Type[5] - %d, ",
                              p_ServiceKey->m_bsCriteria.m_bsCount,p_ServiceKey->m_bsCriteria.m_bsTypeCode[0].m_bscode,p_ServiceKey->m_bsCriteria.m_bsTypeCode[0].m_bsType,p_ServiceKey->m_bsCriteria.m_bsTypeCode[1].m_bscode,p_ServiceKey->m_bsCriteria.m_bsTypeCode[1].m_bsType,p_ServiceKey->m_bsCriteria.m_bsTypeCode[2].m_bscode,p_ServiceKey->m_bsCriteria.m_bsTypeCode[2].m_bsType,p_ServiceKey->m_bsCriteria.m_bsTypeCode[3].m_bscode,p_ServiceKey->m_bsCriteria.m_bsTypeCode[3].m_bsType,p_ServiceKey->m_bsCriteria.m_bsTypeCode[4].m_bscode,p_ServiceKey->m_bsCriteria.m_bsTypeCode[4].m_bsType);
                        l_isd->vlrCamelSubscriptionInfo.t_BCSM_CAMEL_TDP_CriteriaList.value[Tbcsm].bit_mask |= OMAP3_T_BCSM_CAMEL_TDP_Criteria_basicServiceCriteria_present;
                        l_isd->vlrCamelSubscriptionInfo.t_BCSM_CAMEL_TDP_CriteriaList.value[Tbcsm].basicServiceCriteria.count = p_ServiceKey->m_bsCriteria.m_bsCount;
                        for(int bs = 0;bs <p_ServiceKey->m_bsCriteria.m_bsCount;bs++)
                        {
                           if(p_ServiceKey->m_bsCriteria.m_bsTypeCode[bs].m_bsType == 1)
                           {
                              l_isd->vlrCamelSubscriptionInfo.t_BCSM_CAMEL_TDP_CriteriaList.value[Tbcsm].basicServiceCriteria.value[bs].choice |= OMAP3_Ext_BasicServiceCode_ext_BearerService_chosen;
                              l_isd->vlrCamelSubscriptionInfo.t_BCSM_CAMEL_TDP_CriteriaList.value[Tbcsm].basicServiceCriteria.value[bs].u.ext_BearerService.length = 1;
                              l_isd->vlrCamelSubscriptionInfo.t_BCSM_CAMEL_TDP_CriteriaList.value[Tbcsm].basicServiceCriteria.value[bs].u.ext_BearerService.value[0] = p_ServiceKey->m_bsCriteria.m_bsTypeCode[bs].m_bscode;
                           }
                           if(p_ServiceKey->m_bsCriteria.m_bsTypeCode[bs].m_bsType == 2)
                           {
                              l_isd->vlrCamelSubscriptionInfo.t_BCSM_CAMEL_TDP_CriteriaList.value[Tbcsm].basicServiceCriteria.value[bs].choice |= OMAP3_Ext_BasicServiceCode_ext_Teleservice_chosen;
                              l_isd->vlrCamelSubscriptionInfo.t_BCSM_CAMEL_TDP_CriteriaList.value[Tbcsm].basicServiceCriteria.value[bs].u.ext_Teleservice.length = 1;
                              l_isd->vlrCamelSubscriptionInfo.t_BCSM_CAMEL_TDP_CriteriaList.value[Tbcsm].basicServiceCriteria.value[bs].u.ext_Teleservice.value[0] = p_ServiceKey->m_bsCriteria.m_bsTypeCode[bs].m_bscode;
                           }
                        }
                     }
                     if(cvc)
                     {
                        LLOG(0,0,"Adding Cause value criteria, Number of Cause value present %d, Cause_value[1] - %d, Cause_value[2] - %d, Cause_value[3] - %d, Cause_value[4] - %d, Cause_value[5] - %d",
                              p_ServiceKey->m_cvCriteria.m_cvCount,p_ServiceKey->m_cvCriteria.m_cv[0],p_ServiceKey->m_cvCriteria.m_cv[1],p_ServiceKey->m_cvCriteria.m_cv[2],p_ServiceKey->m_cvCriteria.m_cv[3],p_ServiceKey->m_cvCriteria.m_cv[4]);
                        l_isd->vlrCamelSubscriptionInfo.t_BCSM_CAMEL_TDP_CriteriaList.value[Tbcsm].bit_mask |= OMAP3_t_CauseValueCriteria_present;
                        l_isd->vlrCamelSubscriptionInfo.t_BCSM_CAMEL_TDP_CriteriaList.value[Tbcsm].t_CauseValueCriteria.count = p_ServiceKey->m_cvCriteria.m_cvCount;
                        for(int cv = 0;cv<=p_ServiceKey->m_cvCriteria.m_cvCount;cv++)
                        {
                           l_isd->vlrCamelSubscriptionInfo.t_BCSM_CAMEL_TDP_CriteriaList.value[Tbcsm].t_CauseValueCriteria.value[cv].length = 1;
                           l_isd->vlrCamelSubscriptionInfo.t_BCSM_CAMEL_TDP_CriteriaList.value[Tbcsm].t_CauseValueCriteria.value[cv].value[0] = p_ServiceKey->m_cvCriteria.m_cv[cv];
                        }
                     }
                     Tbcsm= Tbcsm+1;
                  }
               }
            }
            DLOG(0,0,"Added t bcsm criteria for [%d] ",l_isd->vlrCamelSubscriptionInfo.t_BCSM_CAMEL_TDP_CriteriaList.count);
         }
      }
      DLOG(0,0,"After VT BCSM Criteria list");
   }
}
#endif

//void VlrCamelSubsinfo::formMosCsi(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd)
void VlrCamelSubsinfo::formMosCsi(OMAP3_InsertSubscriberDataArg *l_isd)
{
   if(vcsi.mosmscsi != 0)
   {
      DLOG(0,0,"Adding MOSMSCSI in VLR Camel Subscription information,MOSMS CSI Profile ID %d",vcsi.mosmscsi);
      int mospid = vcsi.mosmscsi;
      bool l_MosmscsiPresent = false;
      map<u16,MOSMSCSI*>::iterator l_MosmscsiItr;
      l_MosmscsiItr = g_spdPtr->m_MOSMSCSIMap.find(mospid);
      if(l_MosmscsiItr == g_spdPtr->m_MOSMSCSIMap.end())
      {
         CLOG(0,0,"MOSMS_CSI profileID |%d| not found in map.. ",mospid);
         l_MosmscsiPresent = false;
      }
      else
      {
         l_MosmscsiPresent = true;
      }
      if(l_MosmscsiPresent)
      {
         MOSMSCSI *l_moscsi = l_MosmscsiItr->second; 
         if((l_moscsi->m_csiState) && (l_moscsi->m_camelCapability > 2))
         {
            //SMSServiceKey *p_sServiceKey = g_spdPtr->m_SMSServiceKeyMap[l_moscsi->m_serviceKey];
            SMSServiceKey *p_sServiceKey = g_spdPtr->getSmsServiceKeyPtr(vcsi.nwId,l_moscsi->m_serviceKey);
            u32 l_NetworkServiceKey = g_spdPtr->getNetworkServiceKey(vcsi.nwId,l_moscsi->m_serviceKey);
            LLOG(0,0,"Adding MO SMS CSI Service Key [%d], SMS TDP [%d], Camel Capability Handling [%d], Default SMS Handling [%d] Rcvd Camel Phase [%d]",l_moscsi->m_serviceKey,p_sServiceKey->m_bcsmTDP,l_moscsi->m_camelCapability,p_sServiceKey->m_defSmsHandle,vcsi.rcvd_camel_phase);
            l_isd->vlrCamelSubscriptionInfo.bit_mask |= OMAP3_VlrCamelSubscriptionInfo_mo_sms_CSI_present;
            l_isd->vlrCamelSubscriptionInfo.mo_sms_CSI.bit_mask = 0;            
            l_isd->vlrCamelSubscriptionInfo.mo_sms_CSI.bit_mask = OMAP3_sms_CAMEL_TDP_DataList_present;
            l_isd->vlrCamelSubscriptionInfo.mo_sms_CSI.sms_CAMEL_TDP_DataList.count = 1;
            l_isd->vlrCamelSubscriptionInfo.mo_sms_CSI.sms_CAMEL_TDP_DataList.value[0].sms_TriggerDetectionPoint = (OMAP3_SMS_TriggerDetectionPoint)p_sServiceKey->m_bcsmTDP;
            if(l_NetworkServiceKey == l_moscsi->m_serviceKey)
            {
               LLOG(0,0,"MO_SMS_CSI Sending ServiceKey [%d]",l_moscsi->m_serviceKey);
               l_isd->vlrCamelSubscriptionInfo.mo_sms_CSI.sms_CAMEL_TDP_DataList.value[0].serviceKey = l_moscsi->m_serviceKey;
            }
            else
            {
               LLOG(0,0,"MO_SMS_CSI Sending Network Specific ServiceKey [%d]",l_NetworkServiceKey);
               l_isd->vlrCamelSubscriptionInfo.mo_sms_CSI.sms_CAMEL_TDP_DataList.value[0].serviceKey = l_NetworkServiceKey;
            }
            l_isd->vlrCamelSubscriptionInfo.mo_sms_CSI.sms_CAMEL_TDP_DataList.value[0].defaultSMS_Handling = (OMAP3_DefaultSMS_Handling)p_sServiceKey->m_defSmsHandle;            
            l_isd->vlrCamelSubscriptionInfo.mo_sms_CSI.bit_mask |= OMAP3_SMS_CSI_camelCapabilityHandling_present;
            if(vcsi.rcvd_camel_phase < l_moscsi->m_camelCapability)
            {
               l_isd->vlrCamelSubscriptionInfo.mo_sms_CSI.camelCapabilityHandling = (OMAP3_CamelCapabilityHandling)vcsi.rcvd_camel_phase;
            }
            else
            {
               l_isd->vlrCamelSubscriptionInfo.mo_sms_CSI.camelCapabilityHandling = (OMAP3_CamelCapabilityHandling)l_moscsi->m_camelCapability;
            }
            u8 gsmscf2[20];
            memset(gsmscf2, '\0',sizeof(gsmscf2));
            strncpy((char *)gsmscf2,"19",2);            
            if(vcsi.PnwId)
            {            
               u8 *Pgsmscf = (u8 *)getPartnerGsmScfAddr(p_sServiceKey->m_gsmScfAddr,l_OutScfAddrLen,vcsi.nwId,vcsi.PnwId);
               if(NULL != Pgsmscf) 
               {
                  strncat((char *)gsmscf2,(char *)Pgsmscf,strlen((char *)Pgsmscf));
               }   
               else
                  strncat((char *)gsmscf2,(char *)p_sServiceKey->m_gsmScfAddr,strlen((char *)p_sServiceKey->m_gsmScfAddr));
            }
            else
            {
               strncat((char *)gsmscf2,(char *)p_sServiceKey->m_gsmScfAddr,strlen((char *)p_sServiceKey->m_gsmScfAddr));
            }
            DLOG(0,0,"MOSMS CSI GSMSCF Addr is %s",gsmscf2);            
            int len4 = strlen((char *)gsmscf2);
            l_isd->vlrCamelSubscriptionInfo.mo_sms_CSI.sms_CAMEL_TDP_DataList.value[0].gsmSCF_Address.length = (len4+1)/2;
            StringToBCD(l_isd->vlrCamelSubscriptionInfo.mo_sms_CSI.sms_CAMEL_TDP_DataList.value[0].gsmSCF_Address.value,gsmscf2,len4);



         }
         else
         {
            WLOG(0,0,"MO_SMS CSI state is %d and Camel Capability %d, Not adding it",l_moscsi->m_csiState,l_moscsi->m_camelCapability);
         }
      }
      else
      {
         ELOG(0,0,"No profile present for the MOSMS CSI Profile Id %d",mospid);         
      }      
   }   
}



//void VlrCamelSubsinfo::formMtsCsi(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd)
void VlrCamelSubsinfo::formMtsCsi(OMAP3_InsertSubscriberDataArg *l_isd)
{    
   if(vcsi.mtsmscsi != 0)
   {
      DLOG(0,0,"Adding MTSMSCSI in VLR Camel Subscription information, MTSMS CSI Profile ID is %d",vcsi.mtsmscsi);
      int mtspid = vcsi.mtsmscsi;
      bool l_MtsmscsiPresent = false;
      map<u16,MTSMSCSI*>::iterator l_MtsmscsiItr;
      l_MtsmscsiItr = g_spdPtr->m_MTSMSCSIMap.find(mtspid);
      if(l_MtsmscsiItr == g_spdPtr->m_MTSMSCSIMap.end())
      {
         CLOG(0,0,"MTSMS_CSI profileID |%d| not found in map.. ",mtspid);
         l_MtsmscsiPresent = false;
      }
      else
      {
         l_MtsmscsiPresent = true;
      }
      if(l_MtsmscsiPresent)
      {
         MTSMSCSI *l_mtscsi = l_MtsmscsiItr->second; 
         l_isd->vlrCamelSubscriptionInfo.bit_mask |= OMAP3_VlrCamelSubscriptionInfo_mt_sms_CSI_present;
         l_isd->vlrCamelSubscriptionInfo.mt_sms_CSI.bit_mask = 0;
         u32 l_NetworkServiceKey = g_spdPtr->getNetworkServiceKey(vcsi.nwId,l_mtscsi->m_serviceKey);
         if(l_mtscsi->m_csiState)
         {
            l_isd->vlrCamelSubscriptionInfo.mt_sms_CSI.bit_mask |= OMAP3_sms_CAMEL_TDP_DataList_present;
            l_isd->vlrCamelSubscriptionInfo.mt_sms_CSI.sms_CAMEL_TDP_DataList.count = 1;
            SMSServiceKey *p_sServiceKey = g_spdPtr->getSmsServiceKeyPtr(vcsi.nwId,l_mtscsi->m_serviceKey);
            l_isd->vlrCamelSubscriptionInfo.mt_sms_CSI.sms_CAMEL_TDP_DataList.value[0].sms_TriggerDetectionPoint = (OMAP3_SMS_TriggerDetectionPoint)(p_sServiceKey->m_bcsmTDP);
            if(l_NetworkServiceKey == l_mtscsi->m_serviceKey)
            {
               LLOG(0,0,"MT_SMS_CSI Sending ServiceKey [%d]",l_mtscsi->m_serviceKey);
               l_isd->vlrCamelSubscriptionInfo.mt_sms_CSI.sms_CAMEL_TDP_DataList.value[0].serviceKey = l_mtscsi->m_serviceKey;
            }
            else
            {
               LLOG(0,0,"MT_SMS_CSI Sending Network Sepcific ServiceKey [%d]",l_NetworkServiceKey);
               l_isd->vlrCamelSubscriptionInfo.mt_sms_CSI.sms_CAMEL_TDP_DataList.value[0].serviceKey = l_NetworkServiceKey; 
            }

            u8 gsmscf3[21];
            memset(gsmscf3, '\0',sizeof(gsmscf3));
            strncat((char *)gsmscf3,"19",2);
            strncat((char *)gsmscf3,(char *)p_sServiceKey->m_gsmScfAddr,strlen((char *)p_sServiceKey->m_gsmScfAddr));
            int len5 = strlen((char *)gsmscf3);
            l_isd->vlrCamelSubscriptionInfo.mt_sms_CSI.sms_CAMEL_TDP_DataList.value[0].gsmSCF_Address.length = (len5+1)/2;
            StringToBCD(l_isd->vlrCamelSubscriptionInfo.mt_sms_CSI.sms_CAMEL_TDP_DataList.value[0].gsmSCF_Address.value,gsmscf3,len5);
            l_isd->vlrCamelSubscriptionInfo.mt_sms_CSI.sms_CAMEL_TDP_DataList.value[0].defaultSMS_Handling = (OMAP3_DefaultSMS_Handling)p_sServiceKey->m_defSmsHandle;
            if(l_mtscsi->m_camelCapability)
            {
               l_isd->vlrCamelSubscriptionInfo.mt_sms_CSI.bit_mask |= OMAP3_SMS_CSI_camelCapabilityHandling_present;
               l_isd->vlrCamelSubscriptionInfo.mt_sms_CSI.camelCapabilityHandling = (OMAP3_CamelCapabilityHandling)4;//(HLR_MT_SMSCSI_PROFILE->CAMEL_CAPABILITY)
            }
            //l_isd->vlrCamelSubscriptionInfo.mt_sms_CSI.bit_mask = OMAP3_SMS_CSI_notificationToCSE_present;
            //if(HLR_MT_SMSCSI_PROFILE->CSI_STATE)
            //l_isd->vlrCamelSubscriptionInfo.mt_sms_CSI.bit_mask = OMAP3_SMS_CSI_csi_Active_present;
            DLOG(0,0,"Added MT SMS  list Dp [%d] TPDU_CRIT [%d]",p_sServiceKey->m_bcsmTDP,p_sServiceKey->m_TPDU_TypeCrit);
         }
      }
      else
      {
         ELOG(0,0,"No profile present for the MTSMS CSI Profile Id %d",mtspid);         
      }
      DLOG(0,0,"After MT SMS CSI");
   }
}

//void VlrCamelSubsinfo::formMtsTdp(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd)
void VlrCamelSubsinfo::formMtsTdp(OMAP3_InsertSubscriberDataArg *l_isd)
{   
   if(vcsi.mtsmscsi != 0)
   {
      DLOG(0,0,"Adding MT SMS TDP Criteria in VLR Camel Subscription information,MTSMS CSI Profile ID is %d",vcsi.mtsmscsi);
      int mtspid = vcsi.mtsmscsi;        
      bool l_MtsmscsiPresent = false;
      map<u16,MTSMSCSI*>::iterator l_MtsmscsiItr;
      l_MtsmscsiItr = g_spdPtr->m_MTSMSCSIMap.find(mtspid);
      if(l_MtsmscsiItr == g_spdPtr->m_MTSMSCSIMap.end())
      {
         CLOG(0,0,"MTSMS_CSI profileID |%d| not found in map.. ",mtspid);
         l_MtsmscsiPresent = false;
      }
      else
      {
         l_MtsmscsiPresent = true;
      }
      if(l_MtsmscsiPresent)
      {
         MTSMSCSI *l_mtscsi =  l_MtsmscsiItr->second;
         if(l_mtscsi->m_csiState)
         {
            l_isd->vlrCamelSubscriptionInfo.bit_mask |= OMAP3_VlrCamelSubscriptionInfo_mt_smsCAMELTDP_CriteriaList_present;
            l_isd->vlrCamelSubscriptionInfo.mt_smsCAMELTDP_CriteriaList.count = 1;
            //SMSServiceKey *p_sServiceKey = g_spdPtr->m_SMSServiceKeyMap[l_mtscsi->m_serviceKey];
            SMSServiceKey *p_sServiceKey = g_spdPtr->getSmsServiceKeyPtr(vcsi.nwId,l_mtscsi->m_serviceKey);
            l_isd->vlrCamelSubscriptionInfo.mt_smsCAMELTDP_CriteriaList.value[0].sms_TriggerDetectionPoint = (OMAP3_SMS_TriggerDetectionPoint)(p_sServiceKey->m_bcsmTDP);
            l_isd->vlrCamelSubscriptionInfo.mt_smsCAMELTDP_CriteriaList.value[0].bit_mask |= OMAP3_tpdu_TypeCriterion_present;
            l_isd->vlrCamelSubscriptionInfo.mt_smsCAMELTDP_CriteriaList.value[0].tpdu_TypeCriterion.count = 1;
            l_isd->vlrCamelSubscriptionInfo.mt_smsCAMELTDP_CriteriaList.value[0].tpdu_TypeCriterion.value[0] = (OMAP3_MT_SMS_TPDU_Type) p_sServiceKey->m_TPDU_TypeCrit;
            DLOG(0,0,"Added MT SMS Criteria list Dp [%d] TPDU_CRIT [%d]",p_sServiceKey->m_bcsmTDP,p_sServiceKey->m_TPDU_TypeCrit);
         }
         //return *l_isd;
      }
      else
      {
         ELOG(0,0,"No profile present for the MTSMS CSI Profile Id %d",mtspid);         
      }
      DLOG(0,0,"After MT SMS TDP Criteria");
   }   
}

s8* VlrCamelSubsinfo::getPartnerGsmScfAddr(s8 * aGsmScfAddr,u16 &aOutScfAddrLen,u16 aNkId,u16 aPnkId)
{
   char l_tempArr[100];
   memset(l_tempArr,'\0',sizeof(l_tempArr));
   DLOG(0,0,"Nw id is %d",aNkId);
   aNkId += 100;
   //aNkId = 101;
   sprintf(l_tempArr,"%d%04d%s",aNkId,aPnkId,aGsmScfAddr);

   LLOG(0,0," tempArr in getPartnerGsmScfAddr %s",l_tempArr);

   long double key = strtold(l_tempArr,NULL);
   map<long double,s8*> :: iterator rpiter = g_spdPtr->m_RPMap.find(key);
   if(rpiter != g_spdPtr->m_RPMap.end())
   {
      DLOG(0,0,"PARTNER GSMSCF ADDR MATCH FOUND ");
      aOutScfAddrLen = strlen(rpiter->second);
      return rpiter->second;
   }
   else
   {
      CLOG(0,0," PARTNER GSMSCF ADDRESS NOT FOUND returning NULL");
      return NULL;
   }
}


#if 0
OMAP3_InsertSubscriberDataArg VlrCamelSubsinfo::formMCSI(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd)
{
   SubsProfilesManager &obj = SubsProfilesManager::getInstance();
   if(1)//vcsi.Mcsi)
   {
      DLOG(0,0,"Adding MCSI in VLR Camel Subscription information for Dialog ID %d",DlgId);
      int mtspid = 22;
      MCSI *l_mcsi = obj.getProfilePtr()->g_MCSIMap[mtspid];
      if(l_mcsi->m_csiState)
      {
         l_isd->vlrCamelSubscriptionInfo.bit_mask |= OMAP3_VlrCamelSubscriptionInfo_m_CSI_present;
         l_isd->vlrCamelSubscriptionInfo.m_CSI.mobilityTriggers.count = 1;
         l_isd->vlrCamelSubscriptionInfo.m_CSI.mobilityTriggers.value[0].length = 1;
         l_isd->vlrCamelSubscriptionInfo.m_CSI.mobilityTriggers.value[0].value[0] = 0x01;
         l_isd->vlrCamelSubscriptionInfo.m_CSI.serviceKey = 0x05;
         l_isd->vlrCamelSubscriptionInfo.m_CSI.gsmSCF_Address.length = 1;
         l_isd->vlrCamelSubscriptionInfo.m_CSI.gsmSCF_Address.value[0] = 0x91;
         //l_isd->vlrCamelSubscriptionInfo.m_CSI.bit_mask = OMAP3_M_CSI_notificationToCSE_present;
         //l_isd->vlrCamelSubscriptionInfo.m_CSI.bit_mask = OMAP3_M_CSI_csi_Active_present;
      }
   }   
}
#endif


