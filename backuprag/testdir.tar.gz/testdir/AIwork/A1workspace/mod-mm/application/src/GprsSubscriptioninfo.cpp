/*******************************************************************************************
 * File        : GprsSubscriptioninfo.cpp
 * Author      : VenkatRaman
 * Description : To retrieve and add GPRS Subscription Infromation from DB to ISD arg
 * Created on April 29, 2010, 2:45 PM IST
 *******************************************************************************************/

#include <stdio.h>
#include<CtxtUpdateGPRSLocation.h>
#include <GprsSubscriptioninfo.h>
#include <ISDData.h>
#include <Logger.h>
#include <DbQueryMsg.h>
#include <DbActiveObject.h>
#include <MmConfigReader.h>
#include <CommonDefines.h>
#include <SubsProfileData.h>
#include <SubsProfilesManager.h>
#include <Utilities.h>

GprsSubscriptioninfo::GprsSubscriptioninfo()
{
   DLOG(0,0,"GprsSubscriptioninfo Cons");
   PdpId = 0;
   m_FormedTill = 0;
   m_NwId = 0;
   m_PNwId = 0;
   m_completeDataListIncluded = true;
   m_contextList="";
   m_ApnOiOverrideIndicator = 0;
}

GprsSubscriptioninfo::~GprsSubscriptioninfo()
{
   DLOG(0,0,"GprsSubscriptioninfo Des");
}

int EncodeApn(char * OriginalData,unsigned char * EncodedData)
{
   int EncodedTill = 0;
   int len = strlen((char *)OriginalData);
   int l_Count = 0;
   for(int i =0;i<=len;i++)
   {
      if((OriginalData[i] == '.')||(OriginalData[i] == '\0'))
      {
         EncodedData[EncodedTill] = l_Count;
         EncodedTill = i+1;
         l_Count = 0;
      }
      else
      {
         EncodedData[i+1] = OriginalData[i];
         l_Count++;
      }
   }
   return len+1;
}

int GprsSubscriptioninfo::formgprssi (int DlgId, OMAP3_InsertSubscriberDataArg *l_isd,int len)
{
   DLOG (0, 0, "Adding GPRS Subscription info for Dialog Id %d PDP profile id %d,ISD msg len formed so far %d", DlgId, PdpId,len);
   int pdppid = PdpId;
   bool l_pdpPresent = false;
   map<u16,PDP*>::iterator l_pdpItr;
   l_pdpItr = g_spdPtr->m_PDPMap.find(pdppid);
   if(l_pdpItr == g_spdPtr->m_PDPMap.end())
   {
      CLOG(0,0,"PDP Profile id %d not found in map",pdppid);
      l_pdpPresent = false;
   }
   else
   {
      l_pdpPresent = true;
   }

   if (l_pdpPresent)
   {
      int l_PdpCountThisChunk = 0;

      PDP *l_pdp = l_pdpItr->second;
      l_isd->bit_mask |= OMAP3_gprsSubscriptionData_present;
      l_isd->gprsSubscriptionData.bit_mask = 0;
      TLOG(0,0,"PDP Context set count %d for profile id %d PDP Context set added so far %d",l_pdp->m_pdpContextCount,pdppid,m_FormedTill);
      for(int c=m_FormedTill;c<l_pdp->m_pdpContextCount;c++)
      {
         LLOG(0,0,"PDP profile Values for Context id-|%d|: Access_Point_Name-|%s| Vplmn_Access_Allowed-|%d| PDP_Address-|%s|  Qos_Subscribed-|%02x%02x%02x| PDP_Type-|%02x%02x|  PDP_Charging_Characteristics-|%02x%02x| ApplicabilityFlag[%d] ApplicabilityRoamPartnerId[%d]",l_pdp->m_pdpContextListArr[c].m_ContextId,l_pdp->m_pdpContextListArr[c].m_apn,l_pdp->m_pdpContextListArr[c].m_vplmnAddsAlwd,l_pdp->m_pdpContextListArr[c].m_PDPAddr,l_pdp->m_pdpContextListArr[c].m_QosSusbcribed[0],l_pdp->m_pdpContextListArr[c].m_QosSusbcribed[1],l_pdp->m_pdpContextListArr[c].m_QosSusbcribed[2],l_pdp->m_pdpContextListArr[c].m_PDPType[0],l_pdp->m_pdpContextListArr[c].m_PDPType[1],l_pdp->m_pdpContextListArr[c].m_pdpChrgChar[0],l_pdp->m_pdpContextListArr[c].m_pdpChrgChar[1],l_pdp->m_pdpContextListArr[c].m_applicability_flag,l_pdp->m_pdpContextListArr[c].m_applicability_roam_parnter_id);

         if(1 == l_pdp->m_pdpContextListArr[c].m_applicability_flag)
         {
            if(0 == m_PNwId)
            {
               TLOG(0,0,"Subscriber in Home and Applicability flag of CtxdId[%d] is 1 so ignoring",l_pdp->m_pdpContextListArr[c].m_ContextId);
               continue;
            }
            else 
            {
               if(l_pdp->m_pdpContextListArr[c].m_applicability_roam_parnter_id != m_PNwId)
               {
                  LLOG(0,0,"Roam: CtxtId[%d] ApplicableRoamPartner[%d] not matching ActualRoamParnter[%d] so ignoring",l_pdp->m_pdpContextListArr[c].m_ContextId, l_pdp->m_pdpContextListArr[c].m_applicability_roam_parnter_id, m_PNwId);
                  continue;
               }
            }
         }

         if(m_FormedTill == 0)
         {
            if(true == m_completeDataListIncluded)
            {
               l_isd->gprsSubscriptionData.bit_mask |= OMAP3_GPRSSubscriptionData_completeDataListIncluded_present;
	       if(0 == m_ApnOiOverrideIndicator)
	       {
		       DLOG(0,0,"Overriding ApnOi in Gprs"); 
		       if((strlen(l_pdp->m_pdp_apn_oi_replacement)) > 1)
		       { 
			       //start of filling apn_oi_Replacement (in HLR 5.0.3.0)
			       l_isd->gprsSubscriptionData.apn_oi_Replacement.length = EncodeApn((char *)l_pdp->m_pdp_apn_oi_replacement, l_isd->gprsSubscriptionData.apn_oi_Replacement.value);

			       //l_isd->gprsSubscriptionData.apn_oi_Replacement.length = strlen(l_pdp->m_pdp_apn_oi_replacement);
			       //snprintf((char *)l_isd->gprsSubscriptionData.apn_oi_Replacement.value,strlen(l_pdp->m_pdp_apn_oi_replacement),"|%s|",(char *)l_pdp->m_pdp_apn_oi_replacement);
			       TLOG(0,0,"PDP Profile APN-OI-Replacement is [%s]",l_pdp->m_pdp_apn_oi_replacement);
			       //end of filling apn_oi_Replacement (in HLR 5.0.3.0)
			       l_isd->gprsSubscriptionData.bit_mask |= OMAP3_GPRSSubscriptionData_apn_oi_Replacement_present;
		       }
		       else
		       {
			       TLOG(0,0,"PDP Profile APN-OI-Replacement is length is less than one(NULL)");
		       } 
	       }
	       else
	       {
		       DLOG(0,0,"MnoProvisionFlag and MnoProvisioningStatus is 1 ... So not Overriding ApnOi");
	       }
            }
         }
         if(false == m_completeDataListIncluded)
         {
            char l_contextId[7 + 1];
            snprintf(l_contextId,sizeof(l_contextId),"|%d|",l_pdp->m_pdpContextListArr[c].m_ContextId);
            if(NULL == strstr((char*)m_contextList.c_str(),l_contextId))
            {
               TLOG(0,0,"Ctxt[%s] not found in CtxtList[%s]",l_contextId,(char*)m_contextList.c_str());
               continue;
            }
            else
            {
               TLOG(0,0,"Found Ctxt[%s] in CtxtList[%s]",l_contextId,(char*)m_contextList.c_str());
            }
         }


         l_isd->gprsSubscriptionData.gprsDataList.value[l_PdpCountThisChunk].pdp_ContextId = l_pdp->m_pdpContextListArr[c].m_ContextId;
         l_isd->gprsSubscriptionData.gprsDataList.value[l_PdpCountThisChunk].pdp_Type.length = 2;
         l_isd->gprsSubscriptionData.gprsDataList.value[l_PdpCountThisChunk].pdp_Type.value[0] = l_pdp->m_pdpContextListArr[c].m_PDPType[0];
         l_isd->gprsSubscriptionData.gprsDataList.value[l_PdpCountThisChunk].pdp_Type.value[1] = l_pdp->m_pdpContextListArr[c].m_PDPType[1];
#if 1
// 5054R1
         if( m_IPv4Addr.length() > 1)
         {
            TLOG(0,0,"Subscriber specific IPV4 present[%s], filling PDP Address as IPV4 Address",(char *)m_IPv4Addr.c_str());
            l_isd->gprsSubscriptionData.gprsDataList.value[l_PdpCountThisChunk].bit_mask = OMAP3_PDP_Context_pdp_Address_present;
            l_isd->gprsSubscriptionData.gprsDataList.value[l_PdpCountThisChunk].pdp_Address.length = 4;
            char IpAddr[20];
            memset(IpAddr,'\0',sizeof(IpAddr));
            strcpy(IpAddr,(char *)m_IPv4Addr.c_str());
            convertIPV4toHex(IpAddr,&l_isd->gprsSubscriptionData.gprsDataList.value[l_PdpCountThisChunk].pdp_Address.value[0]);
         }
         else
         {
            if(strcmp((char *)l_pdp->m_pdpContextListArr[c].m_PDPAddr,"0") != 0)
            {
               TLOG(0,0,"Subscriber specific IPV4 address not present, filling PDP Address from Profiles[%s]",(char *)l_pdp->m_pdpContextListArr[c].m_PDPAddr);
               l_isd->gprsSubscriptionData.gprsDataList.value[l_PdpCountThisChunk].bit_mask = OMAP3_PDP_Context_pdp_Address_present;
               l_isd->gprsSubscriptionData.gprsDataList.value[l_PdpCountThisChunk].pdp_Address.length = 4;
               char IpAddr[20];
               memset(IpAddr,'\0',sizeof(IpAddr));
               strcpy(IpAddr,(char *)l_pdp->m_pdpContextListArr[c].m_PDPAddr);
               convertIPV4toHex(IpAddr,&l_isd->gprsSubscriptionData.gprsDataList.value[l_PdpCountThisChunk].pdp_Address.value[0]);
            }
         }
#endif         
         l_isd->gprsSubscriptionData.gprsDataList.value[l_PdpCountThisChunk].qos_Subscribed.length = 3;//Can be 3 only;
         l_isd->gprsSubscriptionData.gprsDataList.value[l_PdpCountThisChunk].qos_Subscribed.value[0] = l_pdp->m_pdpContextListArr[c].m_QosSusbcribed[0];
         l_isd->gprsSubscriptionData.gprsDataList.value[l_PdpCountThisChunk].qos_Subscribed.value[1] = l_pdp->m_pdpContextListArr[c].m_QosSusbcribed[1];
         l_isd->gprsSubscriptionData.gprsDataList.value[l_PdpCountThisChunk].qos_Subscribed.value[2] = l_pdp->m_pdpContextListArr[c].m_QosSusbcribed[2];

         if (l_pdp->m_pdpContextListArr[c].m_vplmnAddsAlwd)
            l_isd->gprsSubscriptionData.gprsDataList.value[l_PdpCountThisChunk].bit_mask |= OMAP3_PDP_Context_vplmnAddressAllowed_present;

         unsigned char l_apnName[64];
         memset(l_apnName,'\0',sizeof(l_apnName));
         //04646174610A6C7963616D6F62696C6502636F02756B for data.lycamobile.co.uk
         LLOG(0,0,"NwId [%d] Partner NwId [%d] APN [%s]",m_NwId,m_PNwId,l_pdp->m_pdpContextListArr[c].m_apn);
         if(m_PNwId == 0)
         {
            strcpy((char *)l_apnName,(char *)l_pdp->m_pdpContextListArr[c].m_apn);
         }
         else
         {
            u8 *l_PAPN = (u8 *)getPartnerAPN(l_pdp->m_pdpContextListArr[c].m_apn,m_NwId,m_PNwId);
            if(NULL != l_PAPN) 
            {
               strcpy((char *)l_apnName,(char *)l_PAPN);
               LLOG(0,0,"Partner APN found [%s]",l_apnName);                  
            }
            else
            {
               strcpy((char *)l_apnName,(char *)l_pdp->m_pdpContextListArr[c].m_apn);
               WLOG(0,0,"Partner APN value is NULL, using [%s]",l_apnName);                  
            }
         }
         l_isd->gprsSubscriptionData.gprsDataList.value[l_PdpCountThisChunk].apn.length = EncodeApn((char *)l_apnName,l_isd->gprsSubscriptionData.gprsDataList.value[l_PdpCountThisChunk].apn.value);
#if 1
         if((l_pdp->m_pdpContextListArr[c].m_pdpChrgChar[0] != 0x00)||(l_pdp->m_pdpContextListArr[c].m_pdpChrgChar[1] != 0x00))
         {
            l_isd->gprsSubscriptionData.gprsDataList.value[l_PdpCountThisChunk].bit_mask |= OMAP3_pdp_ChargingCharacteristics_present;
            l_isd->gprsSubscriptionData.gprsDataList.value[l_PdpCountThisChunk].pdp_ChargingCharacteristics.length = 2;
            memcpy((char *)l_isd->gprsSubscriptionData.gprsDataList.value[l_PdpCountThisChunk].pdp_ChargingCharacteristics.value,l_pdp->m_pdpContextListArr[c].m_pdpChrgChar,2);
         }


#endif

#if 1         

         // Added in 1.0.5.0 Rev 1 for Ext_Qos support
         LLOG(0,0,"PDP profile Values for Context id-|%d|: Ext-Qos-length-|%d| Ext-Qos-Data-|%02x %02x %02x %02x %02x %02x %02x %02x %02x| Ext-Qos2-length-|%d| Ext-Qos2-Data-|%02x %02x %02x|",
               l_pdp->m_pdpContextListArr[c].m_ContextId,
               l_pdp->m_pdpContextListArr[c].m_ext_qos_length,
               l_pdp->m_pdpContextListArr[c].m_ext_qos_data[0],l_pdp->m_pdpContextListArr[c].m_ext_qos_data[1],l_pdp->m_pdpContextListArr[c].m_ext_qos_data[2],l_pdp->m_pdpContextListArr[c].m_ext_qos_data[3],l_pdp->m_pdpContextListArr[c].m_ext_qos_data[4],l_pdp->m_pdpContextListArr[c].m_ext_qos_data[5],l_pdp->m_pdpContextListArr[c].m_ext_qos_data[6],l_pdp->m_pdpContextListArr[c].m_ext_qos_data[7],l_pdp->m_pdpContextListArr[c].m_ext_qos_data[8],
               l_pdp->m_pdpContextListArr[c].m_ext_qos2_length,
               l_pdp->m_pdpContextListArr[c].m_ext_qos2_data[0],l_pdp->m_pdpContextListArr[c].m_ext_qos2_data[1],l_pdp->m_pdpContextListArr[c].m_ext_qos2_data[2]);

         if((l_pdp->m_pdpContextListArr[c].m_ext_qos_length > 0) && (l_pdp->m_pdpContextListArr[c].m_ext_qos_length <= 9))
         {
            l_isd->gprsSubscriptionData.gprsDataList.value[l_PdpCountThisChunk].bit_mask |= OMAP3_ext_QoS_Subscribed_present;
            l_isd->gprsSubscriptionData.gprsDataList.value[l_PdpCountThisChunk].ext_QoS_Subscribed.length = l_pdp->m_pdpContextListArr[c].m_ext_qos_length;
            memcpy(l_isd->gprsSubscriptionData.gprsDataList.value[l_PdpCountThisChunk].ext_QoS_Subscribed.value,l_pdp->m_pdpContextListArr[c].m_ext_qos_data,l_pdp->m_pdpContextListArr[c].m_ext_qos_length);
         }

         if(((l_pdp->m_pdpContextListArr[c].m_ext_qos2_length > 0) && (l_pdp->m_pdpContextListArr[c].m_ext_qos2_length <= 3))&& ((l_pdp->m_pdpContextListArr[c].m_ext_qos_length > 0) && (l_pdp->m_pdpContextListArr[c].m_ext_qos_length <= 9)))
         {
            l_isd->gprsSubscriptionData.gprsDataList.value[l_PdpCountThisChunk].bit_mask |= OMAP3_ext2_QoS_Subscribed_present;
            l_isd->gprsSubscriptionData.gprsDataList.value[l_PdpCountThisChunk].ext2_QoS_Subscribed.length = l_pdp->m_pdpContextListArr[c].m_ext_qos2_length;
            memcpy(l_isd->gprsSubscriptionData.gprsDataList.value[l_PdpCountThisChunk].ext2_QoS_Subscribed.value,l_pdp->m_pdpContextListArr[c].m_ext_qos2_data,l_pdp->m_pdpContextListArr[c].m_ext_qos2_length);
         }
         //End Additions of Ext_Qos 1.0.5.0 Rev1
#endif         

         l_PdpCountThisChunk++;
         m_FormedTill++;
         l_isd->gprsSubscriptionData.gprsDataList.count = l_PdpCountThisChunk;
         len += 60;
         TLOG(0,0,"Total length formed now %d Allowed ISD len %d",len,g_MmConfigReaderObj->m_IsdLen);
         if(len  > g_MmConfigReaderObj->m_IsdLen)
         {
            if(m_FormedTill <= l_pdp->m_pdpContextCount)
            {
               m_FormedTill = c;
               l_isd->gprsSubscriptionData.gprsDataList.count--;
               TLOG(0,0,"PDP Profile filled till count %d,Formed till count %d",l_isd->gprsSubscriptionData.gprsDataList.count,m_FormedTill);
               if(l_isd->gprsSubscriptionData.gprsDataList.count)
               {
                  return 2;
               }
               else
               {
                  return 1;
               }
            }
            else
            {
               m_FormedTill = c+1;
               TLOG(0,0,"PDP Profile filled till count %d,Formed till count %d",l_isd->gprsSubscriptionData.gprsDataList.count,m_FormedTill);
               return 3;
            }
         }
      }
      DLOG (0, 0, "Finished adding GPRS Subscription info for Dialog Id %d", DlgId);     

   }
   else
   {
      CLOG(0,0,"PDP Profile ID Id is NULL",PdpId);
      return 3;
   }
   return 3;
}

void GprsSubscriptioninfo::convertIPV4toHex(char * apIPv4Addr,unsigned char *apAddrInHex)
{
   char *pch=NULL;
   pch=strtok(apIPv4Addr,".");
   apAddrInHex[0]=atoi(pch);

   pch= strtok (NULL, ".");
   apAddrInHex[1]=atoi(pch);

   pch= strtok (NULL, ".");
   apAddrInHex[2]=atoi(pch);

   apAddrInHex[3]=atoi((pch+strlen(pch)+1));
}

s8* GprsSubscriptioninfo::getPartnerAPN(s8 *aAPN,u16 aNkId,u16 aPnkId)
{
   char l_tempArr[200];
   memset(l_tempArr,'\0',sizeof(l_tempArr));
   DLOG(0,0,"Nw id is %d",aNkId);
   aNkId += 100;
   sprintf(l_tempArr,"%d%04d%s",aNkId,aPnkId,aAPN);

   TLOG(0,0,"tempArr in getPartnerAPN [%s]",l_tempArr);

   //long double key = strtold(l_tempArr,NULL);

   map<s8*,s8*> :: iterator rpiter1;
   DLOG(0,0,"map size %d",(int )g_spdPtr->m_RPApnMap.size());
   for(rpiter1 = g_spdPtr->m_RPApnMap.begin();rpiter1 != g_spdPtr->m_RPApnMap.end();)
   {
      DLOG(0,0,"[%s] [%s]",rpiter1->first,l_tempArr);
      int l_res = strcmp(rpiter1->first,l_tempArr);
      if(l_res == 0)
      {
         TLOG(0,0,"PARTNER APN MATCH FOUND [%s]",rpiter1->second);
         return rpiter1->second;
      }
      else if(rpiter1 == g_spdPtr->m_RPApnMap.end())
      {
         CLOG(0,0," PARTNER APN NOT FOUND returning NULL");
         return NULL;
      }
      else
      {
         rpiter1++;
      }
   }
#if 0
   map<s8*,s8*> :: iterator rpiter;
   rpiter = g_spdPtr->m_RPApnMap.find(l_tempArr);
   if(rpiter != g_spdPtr->m_RPApnMap.end())
   {
      DLOG(0,0,"PARTNER APN MATCH FOUND ");
      //aOutApnLen = strlen(rpiter->second);
      return rpiter->second;
   }
   else
   {
      CLOG(0,0," PARTNER APN NOT FOUND returning NULL");
      return NULL;
   }
#endif   
   return NULL;
}

/*int GprsSubscriptioninfo::ValidateIpv4(char *ipadd)
  {
  unsigned b1, b2, b3, b4;
  unsigned char c;
  if (sscanf(ipadd, "%3u.%3u.%3u.%3u%c", &b1, &b2, &b3, &b4, &c) != 4)
  return 0;
  if ((b1 | b2 | b3 | b4) > 255) return  0;

  if (strspn(ipadd, "0123456789.") < strlen(ipadd)) return 0;
  return 1;

  }*/
