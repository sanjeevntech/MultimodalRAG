#include <MmSimConfigReader.h>
#include <Parser.h>
#include <SubsProfileData.h>

MmSimConfigReader *g_MmSimConfigReaderObj=NULL;

int l_teleList[]   = {0x00,0x10,0x11,0x12,0x20,0x21,0x22,0x60,0x61,0x62,0x63,0x70,0x80,0x90,0x91,0x92,0xD0,0xD1,0xD2,0xD3,0xD4,0xD5,0xD6,0xD7,0xD8,0xD9,0xDA,0xDB,0xDC,0xDD,0xDE,0xDF};
int l_bearerList[] = {0x00,0x10,0x11,0x12,0x13,0x14,0x15,0x16,0x17,0x18,0x1A,0x1C,0x1D,0x1E,0x1F,0x20,0x21,0x22,0x23,0x24,0x25,0x26,0x27,0x28,0x2C,0x2D,0x2E,0x2F,0x30,0x38,0x40,0x48,0x50,0x60,0x58,0x68,0xD0,0xD1,0xD2,0xD3,0xD4,0xD5,0xD6,0xD7,0xD8,0xD9,0xDA,0xDB,0xDC,0xDD,0xDE,0xDF};


MmSimConfigReader::MmSimConfigReader()
{
   LLOG(0,0,"MmSimConfigReader cons");
   l_version = 0;
   l_rversion = 0;
   l_pms = 0;
   l_pmsvlr = 0;
   l_pmssgsn = 0;
   l_Count = 0;
   l_camel = 0;
   l_sendEnd = 0;
   l_SendISDResp = 0;
   memset(l_UnsuppTele,'\0',sizeof(l_UnsuppTele));
   memset(l_UnsuppBear,'\0',sizeof(l_UnsuppBear));
   l_GenODB = 0;
   l_SendATMError = 0;
   for(int j = 0;j<101;j++)
      l_UnsuppSsCode[j] = 0;
   l_UnsuppSsCount = 0;


   l_Home_FLAG = 0;
   l_Home_VLR = 0;
   l_Roam_VLR = 0;
   l_Local_VLR = 0;
   l_pri_imsi_with_CSI = 0;
   l_sec_imsi_with_CSI = 0;
   l_loc_imsi_with_CSI = 0;
   l_pri_imsi_no_CSI = 0;
   l_sec_imsi_no_CSI = 0;
   l_loc_imsi_no_CSI = 0;
   l_SendGmlcAddr = false;
   l_SendLCSCapabilitySet = false;
   l_Send_LCSNotSupportIndicator = false;

   m_mtrf_support_ind = 0;
}

MmSimConfigReader::~MmSimConfigReader()
{
}

bool MmSimConfigReader::readData()
{
   printf("\nCalling MmConfigReader::readData()");
   string l_mm = readValue(m_DataString, "UPDSIM");


   string version = readValue(l_mm,"UPD_VERSION");
   l_version = atoi(version.c_str());
   printf("\n\nUPD version to be sent is %d",l_version);

   string count = readValue(l_mm,"UPD_LOAD_COUNT");
   l_Count = atoi(count.c_str());
   printf("\nUPD Msg Count %d",l_Count);

   string camel = readValue(l_mm,"CAMEL_SUPPORT");
   l_camel = atoi(camel.c_str());
   printf("\nCAMEL SUPPORT %d",l_camel);

   string Rversion = readValue(l_mm,"RSD_VERSION");
   l_rversion = atoi(Rversion.c_str());
   printf("\nRestore Data version to be sent is %d",l_rversion);

   string pms = readValue(l_mm,"PMS_VERSION");
   l_pms = atoi(pms.c_str());
   printf("\nPMS version to be sent is %d",l_pms);

   string pmsvlr = readValue(l_mm,"PMSV3_VLR");
   l_pmsvlr = atoi(pmsvlr.c_str());
   if(l_pmsvlr)
      printf("\nPMS version 3 msg from VLR Enabled");

   string pmssgsn = readValue(l_mm,"PMSV3_SGSN");
   l_pmssgsn = atoi(pmssgsn.c_str());
   if(l_pmssgsn)
      printf("\nPMS version 3 msg from SGSN Enabled");
   string homeFlag = readValue(l_mm,"ROAM_FLAG");
   l_Home_FLAG = atoi(homeFlag.c_str());
   printf("\n Roam flag %d\n",l_Home_FLAG);

   string homeVlr = readValue(l_mm,"HOME_VLR");
   l_Home_VLR = atol(homeVlr.c_str()); 

   string roamVlr = readValue(l_mm,"ROAM_VLR");
   l_Roam_VLR = atol(roamVlr.c_str());

   roamVlr = readValue(l_mm,"LOCAL_VLR");
   l_Local_VLR = atol(roamVlr.c_str());

   string priimsi = readValue(l_mm,"PRIMARY_IMSI_WITH_CSI");
   l_pri_imsi_with_CSI = atol(priimsi.c_str());
   printf("\nPrimary imsi series %ld",l_pri_imsi_with_CSI);

   string secimsi = readValue(l_mm,"SECONDARY_IMSI_WITH_CSI");
   l_sec_imsi_with_CSI = atol(secimsi.c_str());    
   printf("\nSecondary imsi series %ld",l_sec_imsi_with_CSI);

   secimsi = readValue(l_mm,"LOCAL_IMSI_WITH_CSI");
   l_loc_imsi_with_CSI = atol(secimsi.c_str());    
   printf("\nLocal imsi series %ld",l_loc_imsi_with_CSI);

   priimsi = readValue(l_mm,"PRIMARY_IMSI_NO_CSI");
   l_pri_imsi_no_CSI = atol(priimsi.c_str());
   printf("\nPrimary imsi series %ld",l_pri_imsi_no_CSI);

   secimsi = readValue(l_mm,"SECONDARY_IMSI_NO_CSI");
   l_sec_imsi_no_CSI = atol(secimsi.c_str());    
   printf("\nSecondary imsi series %ld",l_sec_imsi_no_CSI);

   secimsi = readValue(l_mm,"LOCAL_IMSI_NO_CSI");
   l_loc_imsi_no_CSI = atol(secimsi.c_str());    
   printf("\nLocal imsi series %ld",l_loc_imsi_no_CSI);

   secimsi = readValue(l_mm,"SEND_END");
   l_sendEnd = atoi(secimsi.c_str());    
   printf("\nSend End flag %d",l_sendEnd);

   secimsi = readValue(l_mm,"USPP_TELE");
   strncpy(l_UnsuppTele,(char *)secimsi.c_str(),32);           
   printf("\nUnsupported Teleservice %s",l_UnsuppTele);

   secimsi = readValue(l_mm,"USPP_BEAR");
   strncpy(l_UnsuppBear,(char *)secimsi.c_str(),52);    
   printf("\nUnsupported Bearerservice %s",l_UnsuppBear);

   secimsi = readValue(l_mm,"USPP_SS");
   char l_UnsuppSs[250];
   memset(l_UnsuppSs,'\0',sizeof(l_UnsuppSs)); 
   strncpy(l_UnsuppSs,(char *)secimsi.c_str(),200);
   if(strlen(l_UnsuppSs)>1)
   {
      strcat(l_UnsuppSs,",");    
      printf("\nUnsupported SuppService %s\n",l_UnsuppSs);

      char * pch;
      l_UnsuppSsCount = 0;
      int l_PrevPos = 0;
      pch=strchr(l_UnsuppSs,',');
      while (pch!=NULL)
      {
         char l_SsCode[5];
         memset(l_SsCode,'\0',sizeof(l_SsCode));
         //secimsi.assign((char *)l_SsCode,pch-l_UnsuppSs+1,((pch-l_UnsuppSs+1)-l_PrevPos));
         secimsi.copy((char *)l_SsCode,((pch-l_UnsuppSs) - l_PrevPos),l_PrevPos);
         printf("l_SsCode %s\t",l_SsCode);
         l_UnsuppSsCode[l_UnsuppSsCount] = atoi(l_SsCode);

         printf ("found at %d,l_UnsuppSsCode[%d] is %d \n",pch-l_UnsuppSs+1,l_UnsuppSsCount,l_UnsuppSsCode[l_UnsuppSsCount]);
         //printf ("found at %d \n",pch-l_UnsuppSs+1);
         l_UnsuppSsCount++;
         l_PrevPos = pch-l_UnsuppSs+1; 
         pch=strchr(pch+1,',');
      }
   }

   secimsi = readValue(l_mm,"SEND_ISD_RESP");
   l_SendISDResp = atoi(secimsi.c_str());    
   printf("\nISD Resp %d",l_SendISDResp);

   secimsi = readValue(l_mm,"ATM_ERR_RESP");
   l_SendATMError = atoi(secimsi.c_str());    
   printf("\nSend ATM Error Resp %d",l_SendATMError);

   secimsi = readValue(l_mm,"GEN_ODB");
   l_GenODB = atoi(secimsi.c_str());    
   printf("\nGenODB %ld\n",l_GenODB);

   secimsi = readValue(l_mm,"SEND_GMLC");
   l_SendGmlcAddr = atoi(secimsi.c_str());
   printf("\n SendGmlcAddr %d\n",l_SendGmlcAddr);

   secimsi = readValue(l_mm,"SEND_LCS_SET");
   l_SendLCSCapabilitySet = atoi(secimsi.c_str());
   printf("\n Send LCS capability Set [%d]\n",l_SendLCSCapabilitySet);

   secimsi = readValue(l_mm,"SEND_LCS_NS_UE");
   l_Send_LCSNotSupportIndicator = atoi(secimsi.c_str());
   printf("\n SEND LCS not supported bu UE [%d]\n",l_Send_LCSNotSupportIndicator);


   string l_isdTimeout = readValue(l_mm,"ISD_TIMEOUT");
   l_timeout = atoi(l_isdTimeout.c_str());
   printf("\n\nISD Timeout to be sent is %d",l_timeout);

   string l_mtrf = readValue(l_mm,"MTRF_SUPPORT_IND");
   m_mtrf_support_ind = atoi(l_mtrf.c_str());
   printf("\n\nMTRF support indicator %d",m_mtrf_support_ind);

   //0000000000000000000000000000000000000000000000000000          
   m_derivedObjectInitializedFlag=true;

   return true;
}

void MmSimConfigReader::printConfigData(char *p_output)
{
}

