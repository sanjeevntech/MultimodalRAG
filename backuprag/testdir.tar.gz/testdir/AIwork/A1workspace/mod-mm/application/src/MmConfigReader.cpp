#include <MmConfigReader.h>
#include <Logger.h>
#include <Parser.h>
#include <SubsProfileData.h>

extern int g_EmergencyFlag;

MmConfigReader *g_MmConfigReaderObj=NULL;

MmConfigReader::MmConfigReader()
{
   LLOG(0,0,"MmConfigReader cons");
   m_IsdLen = 0;
   m_Version = 0;
   m_CL_Version = 0;
   m_CL_Invoke_Timer = 0;
   m_ISD_Invoke_Timer = 0;
   m_Cancel_Location_Timer = 0;
   m_Cancel_Location_Retry = 0;
   m_Home_CAP_Filtering = true;
   memset(m_home_cap_version,'\0',5);
   m_home_camel_one = false;
   m_home_camel_two = false;
   m_home_camel_three = false;
   m_home_camel_four = false;
   m_Roam_CAP_Filtering = true;
   memset(m_roam_cap_version,'\0',5);
   m_roam_camel_one = false;
   m_roam_camel_two = false;
   m_roam_camel_three = false;
   m_roam_camel_four = false;
   m_Multi_Imsi_ErrCode = 0;
   m_SendCl = false;
   m_SendAscGprs = false;
   m_MinFreeMsisdnThreshold = 0;
   m_MsisdnAllocErrCode = 0;
   m_SendLCS_Details = false;
   m_GT_Transtlation_Reqd = false;
   m_Dealloc_Msisdn_On_Fail = 0;
   m_send_cl_on_isd_failure = 1;// Send
   m_scpSSN = 0;
}

MmConfigReader::~MmConfigReader()
{
   LLOG(0,0,"MmConfigReader des");
}

bool isValidString(char const* p_string)
{
   char const validChars[] = "_:ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
   return strspn(p_string, validChars) == strlen(p_string);
}

bool MmConfigReader::readData()
{
   LLOG(0,0,"MmConfigReader::readData()");
   //string l_mm = readValue(m_DataString, "MM");
   string l_mm = m_DataString;


   int tmp = 0;
   LLOG(0,0,"Deployment Type :%c", g_DeploymentType);
   if( false == readInteger(l_mm, "INITIATE_CL_VERSION", m_CL_Version, 1, 3))
      return false;
   LLOG(0,0,"INITIATE_CL_VERSIO value [%d]",m_CL_Version);

   if( false == readInteger(l_mm, "CL_INVOKE_TIMER", m_CL_Invoke_Timer, 15, 30))
      return false;
   LLOG(0,0,"CL_INVOKE_TIMER value [%d]",m_CL_Invoke_Timer);

   if( false == readInteger(l_mm, "CL_TIMEOUT_SECONDS", m_Cancel_Location_Timer, 300, 900))
      return false;
   LLOG(0,0,"CL_TIMEOUT_SECONDS value [%d]",m_Cancel_Location_Timer);

   if( false == readInteger(l_mm, "CL_RETRY_ATTEMPTS", m_Cancel_Location_Retry, 0, 2))
      return false;
   LLOG(0,0,"CL_RETRY_ATTEMPTS value [%d]",m_Cancel_Location_Retry);

   if( false == readInteger(l_mm, "CONGESTION_CL_RETRY_ATTEMPTS", m_Congestion_CL_Retry_Attempts, 0, 2))
      return false;
   LLOG(0,0,"CONGESTION_CL_RETRY_ATTEMPTS value [%d]",m_Congestion_CL_Retry_Attempts);

   if( false == readInteger(l_mm, "SEND_CL", tmp, 0, 1))
      return false;
   m_SendCl = tmp;
   LLOG(0,0,"SEND_CL value [%d]",m_SendCl);

   if( g_DeploymentType != 'S')
   {
      if( false == readInteger(l_mm, "ISD_DATA_LEN", m_IsdLen, 110, 155))
         return false;
      LLOG(0,0,"ISD_DATA_LEN value [%d]",m_IsdLen);

      if( false == readInteger(l_mm, "INITIATE_ISD_VERSION", m_Version, 1, 3))
         return false;
      LLOG(0,0,"INITIATE_ISD_VERSION value [%d]",m_Version);

      if( false == readInteger(l_mm, "ISD_INVOKE_TIMER", m_ISD_Invoke_Timer, 15, 30))
         return false;
      LLOG(0,0,"ISD_INVOKE_TIMER value [%d]",m_ISD_Invoke_Timer);
      /*
       * Commented in 1.0.8.0 to make CAMEL Validation mandatory
       int tmp = 0;
       if( false == readInteger(l_mm, "HOME_CAMEL_FILTERING_REQD", tmp, 0, 1))
       return false;
       m_Home_CAP_Filtering = tmp;
       */
      m_Home_CAP_Filtering = 1;
      LLOG(0,0,"HOME_CAMEL_FILTERING_REQD value [%d]",m_Home_CAP_Filtering);

      /*
       * tmp = 0;
       if( false == readInteger(l_mm, "ROAM_CAMEL_FILTERING_REQD", tmp, 0, 1))
       return false;
       m_Roam_CAP_Filtering = tmp;
       */
      m_Roam_CAP_Filtering = 1;
      LLOG(0,0,"ROAM_CAMEL_FILTERING_REQD value [%d]",m_Roam_CAP_Filtering);


      tmp = 0;
      if( false == readInteger(l_mm, "SEND_ASC_GPRS", tmp, 0, 1))
         return false;
      m_SendAscGprs = tmp;
      LLOG(0,0,"SEND_ASC_GPRS value [%d]",m_SendAscGprs);

      if (false == readString(l_mm, "HOME_CAMEL_PHASE", m_home_cap_version,4,4))
         return false;
      LLOG(0,0,"HOME_CAMEL_PHASE value [%s]",m_home_cap_version);

      if (false == readString(l_mm, "ROAM_CAMEL_PHASE", m_roam_cap_version,4,4))
         return false;
      LLOG(0,0,"ROAM_CAMEL_PHASE value [%s]",m_roam_cap_version);

      if( false == readInteger(l_mm, "MIN_FREE_MSISDN", m_MinFreeMsisdnThreshold, 0, 20000))
         //return false;
         LLOG(0,0,"MIN_FREE_MSISDN value [%d] - UNUSED",m_MinFreeMsisdnThreshold);

      int l_msisdnAllocErr = 0;
      if( false == readInteger(l_mm, "DYNAMIC_MSISDN_ERROR_CODE",l_msisdnAllocErr,1,36))
         return false;
      if((l_msisdnAllocErr == 1) || (l_msisdnAllocErr == 8) || (l_msisdnAllocErr == 9) ||
            (l_msisdnAllocErr == 34) || (l_msisdnAllocErr == 36))
      {
         m_MsisdnAllocErrCode = l_msisdnAllocErr;
         LLOG(0,0,"DYNAMIC_MSISDN_ERROR_CODE is %d",m_MsisdnAllocErrCode);      
      }
      else
      {
         ELOG(0,0,"\nDYNAMIC_MSISDN_ERROR_CODE is %d, should be 1(UnknownSubscriber), 8(Roaming not allowed - HPLMN roaming), 9(Roaming not allowed - ODB), 34(System Failure) or 36 (Unexpected Data Value)",l_msisdnAllocErr);
         return false;
      }

      int l_multiImsiErr = 0;
      if( false == readInteger(l_mm, "MULTI_IMSI_REJECT_CODE",l_multiImsiErr,1,36))
         return false;
      if((l_multiImsiErr == 1)||(l_multiImsiErr == 8)||(l_multiImsiErr == 9)||(l_multiImsiErr == 34)||(l_multiImsiErr == 36))
      {
         m_Multi_Imsi_ErrCode = l_multiImsiErr;
         LLOG(0,0,"MULTI_IMSI_REJECT_CODE is %d",m_Multi_Imsi_ErrCode);      
      }
      else
      {
         ELOG(0,0,"MULTI_IMSI_REJECT_CODE is %d, should be 1(UnknownSubscriber), 8(Roaming not allowed - HPLMN roaming), 9(Roaming not allowed - ODB), 34(System Failure) or 36 (Unexpected Data Value)",l_multiImsiErr);
         return false;
      }

#if 1 // Added in 1.0.3.0 for Sending LCS and GT trans Reqd in UPD Res

      //Modified in 1.0.6.0 for not sending LCS
      //int l_SendLcs = atoi(readValue(l_mm,"SEND_LCS").c_str());
      m_SendLCS_Details = 0;//l_SendLcs;
      //if(m_SendLCS_Details == 1)
      //{
      //   LLOG(0,0,"SEND_LCS flag set to %d",m_SendLCS_Details);
      //}


      int l_GT_Trans = 0;
      if( false == readInteger(l_mm, "GT_TRANS_REQD", l_GT_Trans, 0, 1))
         return false;
      LLOG(0,0,"GT_TRANS_REQD value [%d]",l_GT_Trans);
      if(l_GT_Trans == 1)
         m_GT_Transtlation_Reqd = true;
#endif

      for(int c= 0;c<4;c++)
      {
         if ( (m_home_cap_version[c] != '0') && (m_home_cap_version[c] != '1') )
         {
            printf("\nERROR: Unrecognizable HOME CAMEL VERSION value present in phase %d indicator\n",c);
            return false;
         }
         if ( (m_roam_cap_version[c] != '0') && (m_roam_cap_version[c] != '1') )
         {
            printf("\nERROR: Unrecognizable ROAM CAMEL VERSION value present in phase %d indicator\n",c);
            return false;
         }
      }
      //Roaming Camel phase
      if(m_roam_cap_version[0] == '1')
      {
         LLOG(0,0,"ROAM CAMEL phase 1 indicator is set");
         m_roam_camel_one = true;
      }
      else
      {
         LLOG(0,0,"ROAM CAMEL phase 1 indicator is not set");
         m_roam_camel_one = false;
      }
      if(m_roam_cap_version[1] == '1')
      {
         LLOG(0,0,"ROAM CAMEL phase 2 indicator is set");
         m_roam_camel_two = true;
      }
      else
      {
         LLOG(0,0,"ROAM CAMEL phase 2 indicator is not set");
         m_roam_camel_two = false;
      }
      if(m_roam_cap_version[2] == '1')
      {
         LLOG(0,0,"ROAM CAMEL phase 3 indicator is set");
         m_roam_camel_three = true;
      }
      else
      {
         LLOG(0,0,"ROAM CAMEL phase 3 indicator is not set");
         m_roam_camel_three = false;
      }
      if(m_roam_cap_version[3] == '1')
      {
         LLOG(0,0,"ROAM CAMEL phase 4 indicator is set");
         m_roam_camel_four = true;
      }
      else
      {
         LLOG(0,0,"ROAM CAMEL phase 4 indicator is not set");
         m_roam_camel_four = false;
      }

      //Home camel phase
      if(m_home_cap_version[0] == '1')
      {
         LLOG(0,0,"HOME CAMEL phase 1 indicator is set");
         m_home_camel_one = true;
      }
      else
      {
         LLOG(0,0,"HOME CAMEL phase 1 indicator is not set");
         m_home_camel_one = false;
      }
      if(m_home_cap_version[1] == '1')
      {
         LLOG(0,0,"HOME CAMEL phase 2 indicator is set");
         m_home_camel_two = true;
      }
      else
      {
         LLOG(0,0,"HOME CAMEL phase 2 indicator is not set");
         m_home_camel_two = false;
      }
      if(m_home_cap_version[2] == '1')
      {
         LLOG(0,0,"HOME CAMEL phase 3 indicator is set");
         m_home_camel_three = true;
      }
      else
      {
         LLOG(0,0,"HOME CAMEL phase 3 indicator is not set");
         m_home_camel_three = false;
      }
      if(m_home_cap_version[3] == '1')
      {
         LLOG(0,0,"HOME CAMEL phase 4 indicator is set");
         m_home_camel_four = true;
      }
      else
      {
         LLOG(0,0,"HOME CAMEL phase 4 indicator is not set");
         m_home_camel_four = false;
      } 

      if( false == readInteger(l_mm, "DEALLOC_MSISDN_ON_FAIL",m_Dealloc_Msisdn_On_Fail,0,1))
         return false;

      if( false == readInteger(l_mm, "SEND_CL_ON_ISD_FAILURE",m_send_cl_on_isd_failure,0,1))
         return false;

      string l_initiateprn = readValue(m_DataString,"INITIATE_PRN_AFTER_CL");

      if(l_initiateprn.size() > 0)
      {
         list<string>l_CodeList;
         l_CodeList = Parser::getAllValues(l_initiateprn,"REASON");
         list<string> :: iterator l_CodeIt;
         for(l_CodeIt = l_CodeList.begin();  l_CodeIt != l_CodeList.end(); l_CodeIt++)
         {

            int  l_Code;
            char l_codeChar[100 + 1];
            memset(l_codeChar,'\0',sizeof(l_codeChar));
            snprintf(l_codeChar,sizeof(l_codeChar),"%s",(char *)( * l_CodeIt).c_str());
            if(strlen(l_codeChar) < 1 )
               break;
            /*for(unsigned int k = 0; k < strlen(l_codeChar); k++) // commented in HLR 2.0.16.0_R2 why it was required earlier is strange?
              {
              l_codeChar[k] = toupper(l_codeChar[k]);
              }*/

            LLOG(0,0,"INITIATE_PRN_AFTER_CL: REASON [%s]",l_codeChar);
            m_cl_reason.push_back((string)l_codeChar);
         }
      }
      else
      {
         CLOG(0,0,"INITIATE_PRN_AFTER_CL CL_REASONS not found");
         snprintf(m_errorDesc, sizeof(m_errorDesc), "%s", "INITIATE_PRN_AFTER_CL CL_REASONS not found");
         return false;
      }


#if 0
      string l_initiateprn =  readValue(m_DataString, "INITIATE_PRN_AFTER_CL");
      if(l_initiateprn.size() > 0)
      {
         for(int l_reasonCount = 1; l_reasonCount <= 50; l_reasonCount++)
         {
            char l_buff[20];
            memset(l_buff,'\0',sizeof(l_buff));
            sprintf(l_buff,"CL_REASON_%02d",l_reasonCount);
            string l_reason = readValue(l_initiateprn, l_buff);
            if(l_reason.length() < 1)
               break;

            for(unsigned int k = 0; k < l_reason.length(); k++)
            {
               l_reason[k] = toupper(l_reason[k]);
            }
            /*if(false == isValidString((char*)l_reason.c_str()))
              {
              ELOG(0,0,"CL_REASON_%02d Value[%s] is not valid",l_reasonCount,(char*)l_reason.c_str());
              return false;
              }*/
            m_cl_reason.push_back(l_reason);
         }
      }
      else
      {
         TLOG(0,0,"INITIATE_PRN_AFTER_CL CL_REASONS not found");
         //      return false;
      }
#endif
      if( false == readInteger(l_mm, "SCP_SSN",m_scpSSN,1,255))
      {
         LLOG(0,0,"SCP_SSN should be between 1 and 255 except 7");
         return false;
      }
      if(7 == m_scpSSN)
      {
         LLOG(0,0,"SCP_SSN should not be 7");
         return false;
      }
   }

   m_derivedObjectInitializedFlag=true;
   return true;
}

void MmConfigReader::printConfigData(char *p_output)
{
   if( g_DeploymentType != 'S')
   {
      sprintf(p_output,"%s : %d %s\t\t%s : %d\t\t%s : %d\n\t%s : %d %s\t%s : %d %s\t\t%s : %d %s\n\t%s : %d\t\t%s : %s\t\t%s : %s\n\t%s : %s\t%s : %s\t\t%s\n\t%s : %s\t\t%s : %s\t%s : %s\n\t%s : %s\t\t%s : %s\n\t%s : %s\t%s : %s\n\t%s : %s\t%s : %d\n\t%s : %d\n\t%s : %d\t\t%s : %d\n", 
            "ISD_Chunking_Length",m_IsdLen,"Bytes",
            "StandAlone_ISD_Version",m_Version,
            "CancelLoc_Version",m_CL_Version,
            "CancelLoc_Invoke_Timer",m_CL_Invoke_Timer,"Seconds",
            "ISD_Invoke_Timer",m_ISD_Invoke_Timer,"Seconds",
            "CancelLoc_Retry_Timer",m_Cancel_Location_Timer,"Seconds",
            "CancelLoc_Retry_Count",m_Cancel_Location_Retry,
            "Home_CAMEL_Filtering",(m_Home_CAP_Filtering==1)?"Required":"Not Required",         
            "Allowed_CAP_Phase_Home",m_home_cap_version,
            "Roaming_CAMEL_Filtering",(m_Roam_CAP_Filtering==1)?"Required":"Not Required",
            "Allowed_CAP_Phase_Roam",m_roam_cap_version,
            "Multi_IMSI_Related: ",
            "MI_Validation",(1==1)?"Required":"Not Required",
            "MI_Error_Code",((m_Multi_Imsi_ErrCode==1)?"UnknownSubscriber":((m_Multi_Imsi_ErrCode==8)?"RoamingNotAllowed_HPLMN":((m_Multi_Imsi_ErrCode==9)?"RoamingNotAllowed_ODB":((m_Multi_Imsi_ErrCode==34)?"SystemFailure":"UnexpectedData")))),
            "SEND_CL_InsteadOf_ISD",(m_SendCl == 1)?"Enabled":"Disabled",
            "SEND_AlertSC_GPRS",(m_SendAscGprs == 1)?"Enabled":"Disabled",
            "DYN_MSISDN_ERROR_CODE",((m_MsisdnAllocErrCode==1)?"UnknownSubscriber":((m_MsisdnAllocErrCode==8)?"RoamingNotAllowed_HPLMN":((m_MsisdnAllocErrCode==9)?"RoamingNotAllowed_ODB":((m_MsisdnAllocErrCode==34)?"SystemFailure":"UnexpectedData")))),
            "GT_TRANS_FOR_UPD_REQD",(m_GT_Transtlation_Reqd==1)?"Required":"Not Required",
            "DEALLOC_MSISDN_ON_FAIL",((m_Dealloc_Msisdn_On_Fail ==0)?"Dont Deallocate":"Deallocate"),
            "SEND_CL_ON_SD_FAILURE",((m_send_cl_on_isd_failure ==0)?"DISABLED":"ENABLED"),
            "INIT_PRN_CL_REASON_COUNT",m_cl_reason.size(),
            "SCP_SSN",m_scpSSN,
            "CONGESTION_CL_RETRY_ATTEMPTS",m_Congestion_CL_Retry_Attempts,
            "Congestion_Emergency_Flag",g_EmergencyFlag
               );
   }
   else
   {
      sprintf(p_output,"%s: %d\t %s: %d %s\t %s: %d %s\t %s: %d\t  %s: %s\n%s : %d\t%s : %d\n", 
            "CancelLoc_Version",m_CL_Version,
            "CancelLoc_Invoke_Timer",m_CL_Invoke_Timer,"Seconds",
            "CancelLoc_Retry_Timer",m_Cancel_Location_Timer,"Seconds",
            "CancelLoc_Retry_Count",m_Cancel_Location_Retry,
            "SEND_CL_InsteadOf_ISD",(m_SendCl == 1)?"Enabled":"Disabled",
            "CONGESTION_CL_RETRY_ATTEMPTS",m_Congestion_CL_Retry_Attempts,
            "Congestion_Emergency_Flag",g_EmergencyFlag

            );
   }
}

