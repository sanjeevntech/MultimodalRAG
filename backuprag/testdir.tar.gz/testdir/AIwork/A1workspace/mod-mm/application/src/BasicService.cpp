/*******************************************************************************
 * File        : basicService.cpp
 * Author      : VenkatRaman
 * Description : To fill ISD params, called by UPD,UPG and RSD
 * Created on  : July 9, 2010, 11:34 AM IST
 *******************************************************************************/

#include <stdio.h>
#include <BasicService.h>
#include <MapMessages.h>
#include <ISDData.h>            
#include <SubsProfileData.h>
#include <ConfigReader.h>

basicService::basicService()
{
   DLOG(0,0,"basicService Cons");  
}

basicService::~basicService()
{
   DLOG(0,0,"basicService Des");         
}

void basicService::formBearerV3C1(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd,char ProvisionedBearer[53])
{
   DLOG(0,0,"Inside formBearerc1 for Dialog id %d",DlgId);
   l_isd->bearerServiceList.count = 0;//Maximum of 52 bearer service can be provisioned
   for(int b=0; b<32; b++)
   {
      if(ProvisionedBearer[b] == '1')
      {
         l_isd->bearerServiceList.value[l_isd->bearerServiceList.count].length = 1;         
         l_isd->bearerServiceList.value[l_isd->bearerServiceList.count].value[0] = g_spdPtr->m_DBtoBearer[b];
         l_isd->bearerServiceList.count += 1;
      }
   }
   if(l_isd->bearerServiceList.count != 0)
      l_isd->bit_mask |= OMAP3_InsertSubscriberDataArg_bearerServiceList_present;
}

void basicService::formBearerV3C2(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd,char ProvisionedBearer[53])
{
   DLOG(0,0,"Inside formBearerc2 for Dialog id %d Bearer service count filled %d",DlgId,l_isd->bearerServiceList.count);
   for(int b=36; b<52; b++)
   {
      if(ProvisionedBearer[b] == '1')
      {
         l_isd->bearerServiceList.value[l_isd->bearerServiceList.count].length = 1;
         l_isd->bearerServiceList.value[l_isd->bearerServiceList.count].value[0] = g_spdPtr->m_DBtoBearer[b];
         l_isd->bearerServiceList.count += 1;
      }
   }
   if(l_isd->bearerServiceList.count != 0)
      l_isd->bit_mask |= OMAP3_InsertSubscriberDataArg_bearerServiceList_present;
}

void basicService::formTeleV3(int DlgId,OMAP3_InsertSubscriberDataArg *l_isd,char ProvisionedTele[33])
{
   DLOG(0,0,"Inside formTele for Dialog id %d",DlgId);
   l_isd->teleserviceList.count = 0;   
   for(int t=0; t<11; t++)
   {
      if(ProvisionedTele[t] == '1')
      {
         l_isd->teleserviceList.value[l_isd->teleserviceList.count].length = 1;
         l_isd->teleserviceList.value[l_isd->teleserviceList.count].value[0] = g_spdPtr->m_DBtoTele[t];
         l_isd->teleserviceList.count += 1;         
      }
   }
   for(int t=13; t<32; t++)
   {
      if(ProvisionedTele[t] == '1')
      {
         l_isd->teleserviceList.value[l_isd->teleserviceList.count].length = 1;
         l_isd->teleserviceList.value[l_isd->teleserviceList.count].value[0] = g_spdPtr->m_DBtoTele[t];
         l_isd->teleserviceList.count += 1;
      }
   }
   if(l_isd->teleserviceList.count != 0)
      l_isd->bit_mask |= OMAP3_InsertSubscriberDataArg_teleserviceList_present;
   if(l_isd->teleserviceList.count > 20)
      l_isd->teleserviceList.count = 20;
}

void basicService::formBearerV2C1(int DlgId,OMAP2_InsertSubscriberDataArg *l_isd,char ProvisionedBearer[53])
{
   DLOG(0,0,"Inside formBearer for Dialog id %d",DlgId);
   l_isd->bearerServiceList.count = 0;//Maximum of 52 bearer service can be provisioned
   for(int b=0; b<32; b++)
   {
      if(ProvisionedBearer[b] == '1')
      {
         l_isd->bearerServiceList.value[l_isd->bearerServiceList.count].length = 1;
         l_isd->bearerServiceList.value[l_isd->bearerServiceList.count].value[0] = g_spdPtr->m_DBtoBearer[b];
         l_isd->bearerServiceList.count += 1;
      }
   }
   if(l_isd->bearerServiceList.count != 0)
      l_isd->bit_mask |= OMAP2_InsertSubscriberDataArg_bearerServiceList_present;
}

void basicService::formBearerV2C2(int DlgId,OMAP2_InsertSubscriberDataArg *l_isd,char ProvisionedBearer[53])
{
   DLOG(0,0,"Inside formBearerc2 for Dialog id %d Bearer service count filled %d",DlgId,l_isd->bearerServiceList.count);
   for(int b=36; b<52; b++)
   {  
      if(ProvisionedBearer[b] == '1')
      {
         l_isd->bearerServiceList.value[l_isd->bearerServiceList.count].length = 1;
         l_isd->bearerServiceList.value[l_isd->bearerServiceList.count].value[0] = g_spdPtr->m_DBtoBearer[b];
         l_isd->bearerServiceList.count += 1;
      }
   }
   if(l_isd->bearerServiceList.count != 0)
      l_isd->bit_mask |= OMAP2_InsertSubscriberDataArg_bearerServiceList_present;
}

void basicService::formTeleV2(int DlgId,OMAP2_InsertSubscriberDataArg *l_isd,char ProvisionedTele[33])
{
   DLOG(0,0,"Inside formTele for Dialog id %d",DlgId);
   l_isd->teleserviceList.count = 0;
   for(int t=0; t<11; t++)
   {
      if(ProvisionedTele[t] == '1')
      {
         l_isd->teleserviceList.value[l_isd->teleserviceList.count].length = 1;
         l_isd->teleserviceList.value[l_isd->teleserviceList.count].value[0] = g_spdPtr->m_DBtoTele[t];
         l_isd->teleserviceList.count += 1;

      }
   }
   for(int t=13; t<32; t++)
   {
      if(ProvisionedTele[t] == '1')
      {
         l_isd->teleserviceList.value[l_isd->teleserviceList.count].length = 1;
         l_isd->teleserviceList.value[l_isd->teleserviceList.count].value[0] = g_spdPtr->m_DBtoTele[t];
         l_isd->teleserviceList.count += 1;

      }
   }
   if(l_isd->teleserviceList.count != 0)
      l_isd->bit_mask |= OMAP2_InsertSubscriberDataArg_teleserviceList_present;
   if(l_isd->teleserviceList.count > 20)
      l_isd->teleserviceList.count = 20;
}

void basicService::formBearerV1C1(int DlgId,OMAP1_BearerServiceList &l_bs,char ProvisionedBearer[53])
{
   DLOG(0,0,"Inside formBearerc1 for Dialog id %d",DlgId);
   l_bs.count = 0;//Maximum of 52 bearer service can be provisioned
   for(int b=0; b<32; b++)
   {
      if(ProvisionedBearer[b] == '1')
      {
         l_bs.value[l_bs.count].length = 1;
         l_bs.value[l_bs.count].value[0] = g_spdPtr->m_DBtoBearer[b];
         l_bs.count += 1;
      }
   }
   DLOG(0,0,"Bearer count %d for Dialog id %d",l_bs.count,DlgId);
}

void basicService::formBearerV1C2(int DlgId,OMAP1_BearerServiceList &l_bs,char ProvisionedBearer[53])
{
   DLOG(0,0,"Inside formBearerc2 for Dialog id %d Bearer service count filled %d",DlgId,l_bs.count);
   for(int b=36; b<52; b++)
   {
      if(ProvisionedBearer[b] == '1')
      {
         l_bs.value[l_bs.count].length = 1;
         l_bs.value[l_bs.count].value[0] = g_spdPtr->m_DBtoBearer[b];
         l_bs.count += 1;
      }
   }
   DLOG(0,0,"Bearer count %d for Dialog id %d",l_bs.count,DlgId);
}

void basicService::formTeleV1(int DlgId,OMAP1_TeleserviceList &l_ts,char ProvisionedTele[33])
{
   DLOG(0,0,"Inside formTele for Dialog id %d",DlgId);
   l_ts.count = 0;
   for(int t=0; t<11; t++)
   {
      if(ProvisionedTele[t] == '1')
      {
         l_ts.value[l_ts.count].length = 1;
         l_ts.value[l_ts.count].value[0] = g_spdPtr->m_DBtoTele[t];
         l_ts.count += 1;
      }
   }
   for(int t=13; t<32; t++)
   {
      if(ProvisionedTele[t] == '1')
      {
         l_ts.value[l_ts.count].length = 1;
         l_ts.value[l_ts.count].value[0] = g_spdPtr->m_DBtoTele[t];
         l_ts.count += 1;
      }
   }
   if(l_ts.count > 20)
      l_ts.count = 20;
}

