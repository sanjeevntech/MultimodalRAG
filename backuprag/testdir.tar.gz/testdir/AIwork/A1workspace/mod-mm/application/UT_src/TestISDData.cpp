#define private public

#include"gtest.h"
#include<ISDData.h>
#include <ServiceCoordinator.h>
#include <MapMessages.h>
#include <Logger.h>
#include <DbQueryMsg.h>
#include <DbActiveObject.h>
#include <AsnCodec.h>
#include <SubsProfileData.h>
#include <SubsProfilesManager.h>
#include <DataUnion.h>
#include <Utilities.h>
#include <CtxtCancelLocation.h>
#include<OMAP2.h>
#include<IMAP2.h>
#include<OMAP3.h>
#include<IMAP3.h>
#include<iostream>
#include<GlobalData.h>
#include<SgsnCamelSubsinfo.h>
class UT_ISDData: public testing::Test , public ISDData, public MmConfigReader//, public CtxtRestoreData
{public:
UT_ISDData()
{
}
~UT_ISDData()
{
}
};

class UT_SubsProfileData: public testing::Test , public SubsProfileData
{public:
UT_SubsProfileData()
{
}
~UT_SubsProfileData()
{
}
};

class UT_GlobalData: public testing::Test , public GlobalData
{public:
UT_GlobalData()
{
}
~UT_GlobalData()
{
}
};


//extern MmConfigReader *g_MmConfigReaderObj;

/***********************************************************/

TEST_F(UT_ISDData,FormISDReqV3_Func) {
//dbisd3 obj;
g_MmConfigReaderObj=new MmConfigReader;
unsigned int index=0x80000000;
//dbisd3* ptr=new dbisd3;
//ptr->imsiReqd=true;
struct dbisd3 dbisd3;
ISDData::dbisd3.imsiReqd=true;
unsigned int VcsiIndex=1;
unsigned int ScsiIndex=1;
unsigned int SsIndex=1;
OMAP3_InsertSubscriberDataArg ab;
int opCode=1;
EXPECT_TRUE(FormISDReqV3(1,index,VcsiIndex,ScsiIndex,SsIndex,true,dbisd3,opCode,&ab));
//delete ptr;
//EXPECT_TRUE(FormISDReqV3(1,2147483648,1,1,true,dbisd3,1,ab));
}

TEST_F(UT_ISDData,FormISDReqV3_OMAP3_category_present_Func) {
g_MmConfigReaderObj=new MmConfigReader;
unsigned int index=0x20000000;
struct dbisd3 dbisd3;
ISDData::dbisd3.category=1;
unsigned int VcsiIndex=1;
unsigned int ScsiIndex=1;
unsigned int SsIndex=1;
OMAP3_InsertSubscriberDataArg ab;
int opCode=1;
m_SecondChunk=true;
EXPECT_TRUE(FormISDReqV3(1,index,VcsiIndex,ScsiIndex,SsIndex,true,dbisd3,opCode,&ab));
}

TEST_F(UT_ISDData,FormISDReqV3_OMAP3_provisionedSS_present_Func) {
g_MmConfigReaderObj=new MmConfigReader;
unsigned int index=0x02000000;
unsigned int VcsiIndex=1;
unsigned int ScsiIndex=1;
unsigned int SsIndex=1;
int opCode=1;
OMAP3_InsertSubscriberDataArg ab;
ab.provisionedSS.count=0;
struct dbisd3 dbisd3;
ISDData::dbisd3.imsiReqd=true;
EXPECT_TRUE(FormISDReqV3(1,index,VcsiIndex,ScsiIndex,SsIndex,true,dbisd3,opCode,&ab));}

TEST_F(UT_ISDData,FormISDReqV3_OMAP3_provisionedSS_present_rret_one_Func) {
g_MmConfigReaderObj=new MmConfigReader;
unsigned int index=0x02000000;
unsigned int VcsiIndex=1;
unsigned int ScsiIndex=1;
unsigned int SsIndex=1;
int opCode=1;
OMAP3_InsertSubscriberDataArg ab;
ab.provisionedSS.count=0;
struct dbisd3 dbisd3;
ISDData::dbisd3.imsiReqd=true;
OMAP1_InsertSubscriberDataArg a;
provisionedSS *ptr=new provisionedSS;
ptr->CFWD_STATE=0;
ptr->cfuSsCode=1;
ptr->val=0;
EXPECT_TRUE(FormISDReqV3(1,index,VcsiIndex,ScsiIndex,SsIndex,true,dbisd3,opCode,&ab));
delete ptr;
}

TEST_F(UT_ISDData,FormISDReqV3_OMAP3_provisionedSS_present_rret_two_Func) {
g_MmConfigReaderObj=new MmConfigReader;
unsigned int index=0x02000000;
unsigned int VcsiIndex=1;
unsigned int ScsiIndex=1;
unsigned int SsIndex=1;
int opCode=1;
OMAP3_InsertSubscriberDataArg ab;
ab.provisionedSS.count=0;
struct dbisd3 dbisd3;
ISDData::dbisd3.imsiReqd=true;
OMAP1_InsertSubscriberDataArg a;
provisionedSS *ptr=new provisionedSS;
ptr->CFWD_STATE=0;
ptr->cfuSsCode=1;
ptr->val=1;
EXPECT_TRUE(FormISDReqV3(1,index,VcsiIndex,ScsiIndex,SsIndex,true,dbisd3,opCode,&ab));
delete ptr;
}


TEST_F(UT_ISDData,FormISDReqV3_OMAP3_Ext_SS_Info_callBarringInfo_chosen__Func) {
g_MmConfigReaderObj=new MmConfigReader;
unsigned int index=0x02000000;
unsigned int VcsiIndex=1;
unsigned int ScsiIndex=1;
unsigned int SsIndex=2;
int opCode=1;
OMAP3_InsertSubscriberDataArg ab;
ab.provisionedSS.count=0;
struct dbisd3 dbisd3;
ISDData::dbisd3.imsiReqd=true;
EXPECT_TRUE(FormISDReqV3(1,index,VcsiIndex,ScsiIndex,SsIndex,true,dbisd3,opCode,&ab));
}

TEST_F(UT_ISDData,FormISDReqV3_OMAP3_Ext_SS_Info_ss_Data_chosen_Func) {
g_MmConfigReaderObj=new MmConfigReader;
unsigned int index=0x02000000;
unsigned int VcsiIndex=1;
unsigned int ScsiIndex=1;
unsigned int SsIndex=4;
int opCode=1;
OMAP3_InsertSubscriberDataArg ab;
ab.provisionedSS.count=0;
struct dbisd3 dbisd3;
ISDData::dbisd3.imsiReqd=true;
EXPECT_TRUE(FormISDReqV3(1,index,VcsiIndex,ScsiIndex,SsIndex,true,dbisd3,opCode,&ab));
}

TEST_F(UT_ISDData,FormISDReqV3_OMAP3_emlpp_Info_chosen_Func) {
g_MmConfigReaderObj=new MmConfigReader;
unsigned int index=0x02000000;
unsigned int VcsiIndex=1;
unsigned int ScsiIndex=1;
unsigned int SsIndex=5;
int opCode=1;
OMAP3_InsertSubscriberDataArg ab;
ab.provisionedSS.count=0;
struct dbisd3 dbisd3;
ISDData::dbisd3.imsiReqd=true;
EXPECT_TRUE(FormISDReqV3(1,index,VcsiIndex,ScsiIndex,SsIndex,true,dbisd3,opCode,&ab));
}

TEST_F(UT_ISDData,FormISDReqV3_OMAP3_emlpp_Info_chosen_retu_two_Func) {
g_MmConfigReaderObj=new MmConfigReader;
unsigned int index=0x02000000;
unsigned int VcsiIndex=1;
unsigned int ScsiIndex=1;
unsigned int SsIndex=5;
int opCode=1;
OMAP3_InsertSubscriberDataArg ab;
ab.provisionedSS.count=0;
struct dbisd3 dbisd3;
ISDData::dbisd3.imsiReqd=true;
//int *ptr=new int;
provisionedSS *ptr=new provisionedSS;
ptr->val=1;
int retu=2;
EXPECT_TRUE(FormISDReqV3(1,index,VcsiIndex,ScsiIndex,SsIndex,true,dbisd3,opCode,&ab));
delete ptr;
}

TEST_F(UT_ISDData,FormISDReqV3_OMAP3_odb_Data_present_Func) {
g_MmConfigReaderObj=new MmConfigReader;
unsigned int index=0x01000000;
unsigned int VcsiIndex=1;
unsigned int ScsiIndex=1;
unsigned int SsIndex=5;
int opCode=1;
OMAP3_InsertSubscriberDataArg ab;
ab.provisionedSS.count=0;
struct dbisd3 dbisd3;
ISDData::dbisd3.imsiReqd=true;
ISDData::dbisd3.odb_Data=true;
ISDData::dbisd3.odb_HplmnData=true;
ISDData::dbisd3.odb_GenData=true;
ISDData::IsdLen=0;
EXPECT_TRUE(FormISDReqV3(1,index,VcsiIndex,ScsiIndex,SsIndex,true,dbisd3,opCode,&ab));
}

TEST_F(UT_ISDData,FormISDReqV3_OMAP3_vlrCamelSubscriptionInfo_present_Func) {
g_MmConfigReaderObj=new MmConfigReader;
unsigned int index=0x00080000;
ISDData::dbisd3.VLRCsi=true;
unsigned int VcsiIndex=0x8000;
struct dbisd3 dbisd3;
ISDData::dbisd3.CamelPhase=0;
ISDData::vlrcsi.vcsi.ocsi=1;
ISDData::IsdLen=-1;
unsigned int ScsiIndex=1;
unsigned int SsIndex=5;
int opCode=1;
OMAP3_InsertSubscriberDataArg ab;
EXPECT_TRUE(FormISDReqV3(1,index,VcsiIndex,ScsiIndex,SsIndex,true,dbisd3,opCode,&ab));
}

/*
//seg fault
TEST_F(UT_ISDData,FormISDReqV3_OMAP3_vlrCamelSubscriptionInfo_present_639_Func) {
g_MmConfigReaderObj=new MmConfigReader;
unsigned int index=0x00080000;
ISDData::dbisd3.VLRCsi=true;
unsigned int VcsiIndex=0x8000;
struct dbisd3 dbisd3;
ISDData::dbisd3.CamelPhase=1;
ISDData::vlrcsi.vcsi.ocsi=1;
OMAP3_InsertSubscriberDataArg ab;
unsigned int ScsiIndex=1;
unsigned int SsIndex=5;
int opCode=1;
OCSI *ptr=new OCSI;
ptr->m_csiState=1;
EXPECT_TRUE(FormISDReqV3(1,index,VcsiIndex,ScsiIndex,SsIndex,true,dbisd3,opCode,&ab));
delete ptr;
}
*/


TEST_F(UT_ISDData,FormISDReqV3_OMAP3_VlrCamelSubscriptionInfo_ss_CSI_present_Func) {
g_MmConfigReaderObj=new MmConfigReader;
unsigned int index=0x00080000;
ISDData::dbisd3.VLRCsi=true;
unsigned int VcsiIndex=0x2000;
struct dbisd3 dbisd3;
ISDData::dbisd3.CamelPhase=0;
ISDData::vlrcsi.vcsi.ocsi=1;
ISDData::IsdLen=-1;
unsigned int ScsiIndex=1;
unsigned int SsIndex=5;
int opCode=1;
OMAP3_InsertSubscriberDataArg ab;
EXPECT_TRUE(FormISDReqV3(1,index,VcsiIndex,ScsiIndex,SsIndex,true,dbisd3,opCode,&ab));
}

/*
//seg fault
TEST_F(UT_ISDData,FormISDReqV3_OMAP3_VlrCamelSubscriptionInfo_ss_CSI_present_Two_Func) {
g_MmConfigReaderObj=new MmConfigReader;
unsigned int index=0x00080000;
ISDData::dbisd3.VLRCsi=true;
unsigned int VcsiIndex=0x2000;
struct dbisd3 dbisd3;
ISDData::dbisd3.CamelPhase=100;
ISDData::vlrcsi.vcsi.sscsi=1;
ISDData::IsdLen=-1;
unsigned int ScsiIndex=1;
unsigned int SsIndex=5;
int opCode=1;
OMAP3_InsertSubscriberDataArg ab;
EXPECT_TRUE(FormISDReqV3(1,index,VcsiIndex,ScsiIndex,SsIndex,true,dbisd3,opCode,&ab));
}
*/


TEST_F(UT_ISDData,FormISDReqV3_OMAP3_VlrCamelSubscriptionInfo_o_BcsmCamelTDP_CriteriaList_present_Func) {
g_MmConfigReaderObj=new MmConfigReader;
unsigned int index=0x00080000;
ISDData::dbisd3.VLRCsi=true;
unsigned int VcsiIndex=0x1000;
struct dbisd3 dbisd3;
ISDData::dbisd3.CamelPhase=0;
ISDData::vlrcsi.vcsi.ocsi=1;
ISDData::IsdLen=-1;
unsigned int ScsiIndex=1;
unsigned int SsIndex=5;
int opCode=1;
OMAP3_InsertSubscriberDataArg ab;
EXPECT_TRUE(FormISDReqV3(1,index,VcsiIndex,ScsiIndex,SsIndex,true,dbisd3,opCode,&ab));
}

TEST_F(UT_ISDData,FormISDReqV3_OMAP3_VlrCamelSubscriptionInfo_m_CSI_present_Func) {
g_MmConfigReaderObj=new MmConfigReader;
unsigned int index=0x00080000;
ISDData::dbisd3.VLRCsi=true;
unsigned int VcsiIndex=0x0400;
struct dbisd3 dbisd3;
ISDData::dbisd3.CamelPhase=0;
ISDData::vlrcsi.vcsi.ocsi=1;
ISDData::IsdLen=-1;
unsigned int ScsiIndex=1;
unsigned int SsIndex=5;
int opCode=1;
OMAP3_InsertSubscriberDataArg ab;
EXPECT_TRUE(FormISDReqV3(1,index,VcsiIndex,ScsiIndex,SsIndex,true,dbisd3,opCode,&ab));
}

TEST_F(UT_ISDData,FormISDReqV3_OMAP3_gprsSubscriptionData_present_Func) {
g_MmConfigReaderObj=new MmConfigReader;
unsigned int index=0x00010000;
struct dbisd3 dbisd3;
ISDData::dbisd3.gprsSubsData=0;
unsigned int VcsiIndex=0x0200;unsigned int ScsiIndex=1;unsigned int SsIndex=5;
int opCode=1;
OMAP3_InsertSubscriberDataArg ab;
//g_spdPtr=new SubsProfileData;
g_spd=new GlobalData;
EXPECT_TRUE(FormISDReqV3(1,index,VcsiIndex,ScsiIndex,SsIndex,true,dbisd3,opCode,&ab));
}
/*
//worked but giving seg fault from 26/05/2022 
TEST_F(UT_ISDData,FormISDReqV3_OMAP3_gprsSubscriptionData_present_Two_Func) {
g_MmConfigReaderObj=new MmConfigReader;
unsigned int index=0x00010000;
struct dbisd3 dbisd3;
ISDData::dbisd3.gprsSubsData=1;
unsigned int VcsiIndex=0x0200;
unsigned int ScsiIndex=1;
unsigned int SsIndex=5;
int opCode=1;
OMAP3_InsertSubscriberDataArg ab;
g_spd=new GlobalData;
EXPECT_TRUE(FormISDReqV3(1,index,VcsiIndex,ScsiIndex,SsIndex,true,dbisd3,opCode,&ab));
}
*/
TEST_F(UT_ISDData,FormISDReqV3_OMAP3_lmu_Indicator_present_Func) {
g_MmConfigReaderObj=new MmConfigReader;
unsigned int index=0x00001000;
struct dbisd3 dbisd3;
ISDData::dbisd3.lmu=1;
ISDData::IsdLen=-1;
unsigned int VcsiIndex=1;
unsigned int ScsiIndex=1;
unsigned int SsIndex=5;
int opCode=1;
OMAP3_InsertSubscriberDataArg ab;
EXPECT_TRUE(FormISDReqV3(1,index,VcsiIndex,ScsiIndex,SsIndex,true,dbisd3,opCode,&ab));
}

TEST_F(UT_ISDData,FormISDReqV3_OMAP3_InsertSubscriberDataArg_istAlertTimer_present_Func) {
g_MmConfigReaderObj=new MmConfigReader;
unsigned int index=0x00000400;
struct dbisd3 dbisd3;
ISDData::dbisd3.istvalue=1;
ISDData::IsdLen=-1;
unsigned int VcsiIndex=1;
unsigned int ScsiIndex=1;
unsigned int SsIndex=5;
int opCode=1;
OMAP3_InsertSubscriberDataArg ab;
EXPECT_TRUE(FormISDReqV3(1,index,VcsiIndex,ScsiIndex,SsIndex,true,dbisd3,opCode,&ab));
}

TEST_F(UT_ISDData,FormISDReqV3_OMAP3_sgsn_CAMEL_SubscriptionInfo_present_Func) {
g_MmConfigReaderObj=new MmConfigReader;
unsigned int index=0x00000040;
struct dbisd3 dbisd3;
ISDData::dbisd3.sgsncsi=true;
unsigned int VcsiIndex=1;
unsigned int ScsiIndex=0x80;
ISDData::dbisd3.CamelPhase=0;
ISDData::Sgsncsi.scsi.gcsi=0;
unsigned int SsIndex=5;
int opCode=1;
OMAP3_InsertSubscriberDataArg ab;
EXPECT_TRUE(FormISDReqV3(1,index,VcsiIndex,ScsiIndex,SsIndex,true,dbisd3,opCode,&ab));
}

TEST_F(UT_ISDData,FormISDReqV3_OMAP3_SGSN_CAMEL_SubscriptionInfo_mo_sms_CSI_present_Func) {
g_MmConfigReaderObj=new MmConfigReader;
unsigned int index=0x00000040;
struct dbisd3 dbisd3;
ISDData::dbisd3.sgsncsi=true;
unsigned int VcsiIndex=1;
unsigned int ScsiIndex=0x40;
ISDData::dbisd3.CamelPhase=0;
ISDData::Sgsncsi.scsi.mosmscsi=0;
unsigned int SsIndex=5;
int opCode=1;
OMAP3_InsertSubscriberDataArg ab;
EXPECT_TRUE(FormISDReqV3(1,index,VcsiIndex,ScsiIndex,SsIndex,true,dbisd3,opCode,&ab));
}

TEST_F(UT_ISDData,FormISDReqV3_OMAP3_SGSN_CAMEL_SubscriptionInfo_extensionContainer_present_Func) {
g_MmConfigReaderObj=new MmConfigReader;
unsigned int index=0x00000040;
struct dbisd3 dbisd3;
ISDData::dbisd3.sgsncsi=true;
unsigned int VcsiIndex=1;
unsigned int ScsiIndex=0x20;
ISDData::dbisd3.CamelPhase=0;
ISDData::Sgsncsi.scsi.mosmscsi=0;
unsigned int SsIndex=5;
int opCode=1;
OMAP3_InsertSubscriberDataArg ab;
EXPECT_TRUE(FormISDReqV3(1,index,VcsiIndex,ScsiIndex,SsIndex,true,dbisd3,opCode,&ab));
}

TEST_F(UT_ISDData,FormISDReqV3_OMAP3_InsertSubscriberDataArg_chargingCharacteristics_present_Func) {
g_MmConfigReaderObj=new MmConfigReader;
unsigned int index=0x00000020;
struct dbisd3 dbisd3;
ISDData::dbisd3.ChrgChar[0]=0x01;
ISDData::dbisd3.ChrgChar[1]=0x01;
ISDData::IsdLen=-1;
unsigned int VcsiIndex=1;
unsigned int ScsiIndex=0x20;
unsigned int SsIndex=5;
int opCode=1;
OMAP3_InsertSubscriberDataArg ab;
EXPECT_TRUE(FormISDReqV3(1,index,VcsiIndex,ScsiIndex,SsIndex,true,dbisd3,opCode,&ab));
}

TEST_F(UT_ISDData,FormISDReqV3_OMAP3_InsertSubscriberDataArg_chargingCharacteristics_present_Two_Func) {
g_MmConfigReaderObj=new MmConfigReader;
unsigned int index=0x00000020;
struct dbisd3 dbisd3;
ISDData::dbisd3.ChrgChar[0]=0x00;
ISDData::dbisd3.ChrgChar[1]=0x00;
ISDData::IsdLen=-1;
unsigned int VcsiIndex=1;
unsigned int ScsiIndex=0x20;
unsigned int SsIndex=5;
int opCode=1;
OMAP3_InsertSubscriberDataArg ab;
EXPECT_TRUE(FormISDReqV3(1,index,VcsiIndex,ScsiIndex,SsIndex,true,dbisd3,opCode,&ab));
}

TEST_F(UT_ISDData,FormISDReqV3_OMAP3_accessRestrictionData_present_Func) {
g_MmConfigReaderObj=new MmConfigReader;
unsigned int index=0x00000010;
struct dbisd3 dbisd3;
ISDData::dbisd3.accrest=1;
ISDData::IsdLen=-1;
unsigned int VcsiIndex=1;
unsigned int ScsiIndex=0x20;
unsigned int SsIndex=5;
int opCode=1;
OMAP3_InsertSubscriberDataArg ab;
EXPECT_TRUE(FormISDReqV3(1,index,VcsiIndex,ScsiIndex,SsIndex,true,dbisd3,opCode,&ab));
}

/********************************************************************/

TEST_F(UT_ISDData,FormISDReqV2_OMAP2_InsertSubscriberDataArg_imsi_present_Func) {
g_MmConfigReaderObj=new MmConfigReader;
unsigned int index=0x8000;
struct dbisd2 dbisd2;
ISDData::dbisd2.imsiReqd=true;
unsigned int SsIndex=5;
int opCode=1;
OMAP2_InsertSubscriberDataArg ab;
EXPECT_TRUE(FormISDReqV2(1,index,SsIndex,true,dbisd2,opCode,&ab));
}

TEST_F(UT_ISDData,FormISDReqV2_OMAP2_Ext_SS_Info_forwardingInfo_chosen_Func) {
g_MmConfigReaderObj=new MmConfigReader;
unsigned int index=0x0200;
struct dbisd2 dbisd2;
ISDData::dbisd2.imsiReqd=true;
unsigned int SsIndex=1;
ISDData::pss.val=0;
int opCode=1;
OMAP2_InsertSubscriberDataArg ab;
EXPECT_TRUE(FormISDReqV2(1,index,SsIndex,true,dbisd2,opCode,&ab));
}

TEST_F(UT_ISDData,FormISDReqV2_OMAP2_Ext_SS_Info_callBarringInfo_chosen_Func) {
g_MmConfigReaderObj=new MmConfigReader;
unsigned int index=0x0200;
struct dbisd2 dbisd2;
ISDData::dbisd2.imsiReqd=true;
unsigned int SsIndex=2;
ISDData::pss.val=0;
int opCode=1;
OMAP2_InsertSubscriberDataArg ab;
EXPECT_TRUE(FormISDReqV2(1,index,SsIndex,true,dbisd2,opCode,&ab));
}

TEST_F(UT_ISDData,FormISDReqV2_OMAP2_Ext_SS_Info_ss_Data_chosen_Func) {
g_MmConfigReaderObj=new MmConfigReader;
unsigned int index=0x0200;
struct dbisd2 dbisd2;
ISDData::dbisd2.imsiReqd=true;
unsigned int SsIndex=4;
ISDData::pss.val=0;
int opCode=1;
OMAP2_InsertSubscriberDataArg ab;
ISDData::pss.val=0;
EXPECT_TRUE(FormISDReqV2(1,index,SsIndex,true,dbisd2,opCode,&ab));
}

TEST_F(UT_ISDData,FormISDReqV2_OMAP2_provisionedSS_present_default_Func) {
g_MmConfigReaderObj=new MmConfigReader;
unsigned int index=0x0200;
struct dbisd2 dbisd2;
ISDData::dbisd2.imsiReqd=true;
unsigned int SsIndex=0;
ISDData::pss.val=0;
int opCode=1;
OMAP2_InsertSubscriberDataArg ab;
ISDData::pss.val=0;
EXPECT_TRUE(FormISDReqV2(1,index,SsIndex,true,dbisd2,opCode,&ab));
}

TEST_F(UT_ISDData,FormISDReqV2_OMAP2_odb_Data_present_Func) {
g_MmConfigReaderObj=new MmConfigReader;
unsigned int index=0x0100;
struct dbisd2 dbisd2;
ISDData::dbisd2.odb_Data=true;
ISDData::dbisd2.odb_HplmnData=true;
ISDData::IsdLen=-1;
unsigned int SsIndex=0;
ISDData::pss.val=0;
int opCode=1;
OMAP2_InsertSubscriberDataArg ab;
ISDData::pss.val=0;
EXPECT_TRUE(FormISDReqV2(1,index,SsIndex,true,dbisd2,opCode,&ab));
}

TEST_F(UT_ISDData,FormISDReqV2_OMAP2_regionalSubscriptionData_present_Func) {
g_MmConfigReaderObj=new MmConfigReader;
unsigned int index=0x0040;
struct dbisd2 dbisd2;
ISDData::IsdLen=-1;
unsigned int SsIndex=0;
int opCode=1;
OMAP2_InsertSubscriberDataArg ab;
EXPECT_TRUE(FormISDReqV2(1,index,SsIndex,true,dbisd2,opCode,&ab));
}

/*****************************************************************/

TEST_F(UT_ISDData,FormISDReqV1_Func) {
g_MmConfigReaderObj=new MmConfigReader;
unsigned int index=0x0100;
unsigned int SsIndex=0;
struct dbisd1 dbisd1;
ISDData::dbisd1.imsiReqd=true;
ISDData::dbisd1.imsi[16]="aaaaaaaaaaaaaaaaaaaaaa";
ISDData::len=2;
int opCode=1;
OMAP1_InsertSubscriberDataArg ab;
strcpy(ab.imsi.value,"aaaaaaaaaaaa");
ab.imsi.length=1;
EXPECT_TRUE(FormISDReqV1(1,index,SsIndex,true,dbisd1,opCode,&ab));
}

TEST_F(UT_ISDData,FormISDReqV1_OMAP1_InsertSubscriberDataArg_provisonedSS_present_Func) {
g_MmConfigReaderObj=new MmConfigReader;
unsigned int index=0x02;
struct dbisd1 dbisd1;
unsigned int SsIndex=1;
int opCode=1;
OMAP1_InsertSubscriberDataArg ab;
EXPECT_TRUE(FormISDReqV1(1,index,SsIndex,true,dbisd1,opCode,&ab));
}

TEST_F(UT_ISDData,FormISDReqV1_OMAP1_callBarringInfo_chosen_Func) {
g_MmConfigReaderObj=new MmConfigReader;
unsigned int index=0x02;
struct dbisd1 dbisd1;
unsigned int SsIndex=2;
int opCode=1;
OMAP1_InsertSubscriberDataArg ab;
EXPECT_TRUE(FormISDReqV1(1,index,SsIndex,true,dbisd1,opCode,&ab));
}

TEST_F(UT_ISDData,FormISDReqV1_OMAP1_ss_Data_chosen_Func) {
g_MmConfigReaderObj=new MmConfigReader;
unsigned int index=0x02;
struct dbisd1 dbisd1;
unsigned int SsIndex=4;
int opCode=1;
OMAP1_InsertSubscriberDataArg ab;
ab.provisonedSS.count=0;
EXPECT_TRUE(FormISDReqV1(1,index,SsIndex,true,dbisd1,opCode,&ab));
}

/********************************************************************/

TEST_F(UT_ISDData,ProcessIsdResV2_Func) {
IMAP2_InsertSubscriberDataRes ab;
ab.bit_mask=0x00;
EXPECT_TRUE(ProcessIsdResV2(1,&ab));
}

/*
//Already commented
TEST_F(UT_ISDData,ProcessIsdResV2_IMAP2_InsertSubscriberDataRes_teleserviceList_present_Func) {
IMAP2_InsertSubscriberDataRes *ptr=new IMAP2_InsertSubscriberDataRes;
ptr->bit_mask=0x80;
EXPECT_TRUE(ProcessIsdResV2(1,ptr));
delete ptr;
}*/

/**************************************************************/

TEST_F(UT_ISDData,ProcessIsdResV3_Func) {
IMAP3_InsertSubscriberDataRes ab;
ab.bit_mask=0x00;
EXPECT_TRUE(ProcessIsdResV3(1,&ab));
}


#undef private

