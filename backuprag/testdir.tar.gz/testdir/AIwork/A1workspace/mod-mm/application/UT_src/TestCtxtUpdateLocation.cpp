#define private public
#include<iostream>
#include"gtest.h"
#include <CtxtUpdateLocation.h>
#include <CtxtCancelLocation.h>
#include <CommonDefines.h>
#include <stdio.h>
#include <ServiceCoordinator.h>
#include <Logger.h>
#include <DbQueryMsg.h>
#include <DbActiveObject.h>
#include <MmConfigReader.h>
#include <ISDData.h>
#include <DataUnion.h>
#include <Utilities.h>
#include <sys/time.h>
#include <AsnCodec.h>
#include <SnmpInterface.h>
#include <DiameterConstants.h>
#include <ExtendedServiceCoordinator.h>
#include<MapConstants.h>
#include<SubsProfileData.h>
#include<IMAP1.h>
#include<MmDbQueries.h>
#include<IMAP2.h>
#include<IMAP3.h>
#include<ConfigReader.h>
#include<GlobalData.h>
#include<ProvisionedSS.h>
//#include<CtxtRestoreData.h>

class UT_CtxtUpdateLocation: public testing::Test , public CtxtUpdateLocation, public MmConfigReader, public provisionedSS//,public RetrieveSubsVLRData, public CtxtCancelLocation
{public:
UT_CtxtUpdateLocation()
{
}
~UT_CtxtUpdateLocation()
{
}
};

/*class UT_provisionedSS
{public:
UT_provisionedSS()
{
}
~UT_provisionedSS()
{
}
};*/

class UT_MapUserError
{public:
UT_MapUserError()
{
}
~UT_MapUserError()
{
}
};

class UT_RetrieveSubsVLRData
{public:
UT_RetrieveSubsVLRData()
{
}
~UT_RetrieveSubsVLRData()
{
}
};

class UT_CtxtCancelLocation
{public:
UT_CtxtCancelLocation()
{
}
~UT_CtxtCancelLocation()
{
}
};

class UT_UpdateVLRData
{public:
UT_UpdateVLRData()
{
}
~UT_UpdateVLRData()
{
}
};

class UT_SubsProfileData
{public:
UT_SubsProfileData()
{
}
~UT_SubsProfileData()
{
}
};

class UT_InterModuleData
{public:
UT_InterModuleData()
{
}
~UT_InterModuleData()
{
}
};

class UT_ISDData
{public:
UT_ISDData()
{
}
~UT_ISDData()
{
}
};

class UT_GlobalData
{public:
UT_GlobalData()
{
}
~UT_GlobalData()
{
}
};

/*class UT_CtxtRestoreData
{public:
UT_CtxtRestoreData()
{
}
~UT_CtxtRestoreData()
{
}
};*/

/***********************************************************************/

TEST_F(UT_CtxtUpdateLocation,processMessage_MAP_CMN_OPEN_IND_Func) {
g_IMEI_EncrFlag=1;
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=202;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MAP_CMN_DELIMITER_IND_Func) {
g_IMEI_EncrFlag=1;
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=208;
CtxtUpdateLocation::m_ProvErrRcvd=true;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MAP_CMN_CLOSE_IND_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=206;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MAP_CMN_U_ABORT_IND_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=210;
p_MsgPtr.m_UserDlgId=1;
bool p_DeleteFlag=true;
//m_Dealloc_Msisdn_On_Fail=1;
//MmConfigReader obj;
//obj.m_Dealloc_Msisdn_On_Fail=1;
//MmConfigReader *ptr=new MmConfigReader;
//ptr->m_Dealloc_Msisdn_On_Fail=1;
//g_MmConfigReaderObj->m_Dealloc_Msisdn_On_Fail=1;
g_MmConfigReaderObj=new MmConfigReader;
g_MmConfigReaderObj->m_Dealloc_Msisdn_On_Fail=1;
//printf("g_MmConfigReaderObj->m_Dealloc_Msisdn_On_Fail=%d",g_MmConfigReaderObj->m_Dealloc_Msisdn_On_Fail);
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
//delete ptr;
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MAP_CMN_U_ABORT_IND_Two_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=210;
p_MsgPtr.m_UserDlgId=1;
bool p_DeleteFlag=true;
g_MmConfigReaderObj=new MmConfigReader;
g_MmConfigReaderObj->m_Dealloc_Msisdn_On_Fail=1;
CtxtUpdateLocation::l_state=3;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MAP_CMN_P_ABORT_IND_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=212;
p_MsgPtr.m_UserDlgId=1;
bool p_DeleteFlag=true;
g_MmConfigReaderObj=new MmConfigReader;
g_MmConfigReaderObj->m_Dealloc_Msisdn_On_Fail=1;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MAP_CMN_P_ABORT_IND_Two_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=212;
p_MsgPtr.m_UserDlgId=1;
bool p_DeleteFlag=true;
g_MmConfigReaderObj=new MmConfigReader;
g_MmConfigReaderObj->m_Dealloc_Msisdn_On_Fail=1;
CtxtUpdateLocation::l_state=3;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}


TEST_F(UT_CtxtUpdateLocation,processMessage_MAP_CMN_NOTICE_IND_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=213;
p_MsgPtr.m_UserDlgId=1;
bool p_DeleteFlag=true;
g_MmConfigReaderObj=new MmConfigReader;
g_MmConfigReaderObj->m_Dealloc_Msisdn_On_Fail=1;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MAP_CMN_NOTICE_IND_Two_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=213;
p_MsgPtr.m_UserDlgId=1;
bool p_DeleteFlag=true;
g_MmConfigReaderObj=new MmConfigReader;
g_MmConfigReaderObj->m_Dealloc_Msisdn_On_Fail=1;
CtxtUpdateLocation::l_state=3;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MAP_MSG_TYPE_COMMON_default_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=200;
p_MsgPtr.m_UserDlgId=1;
bool p_DeleteFlag=true;
g_MmConfigReaderObj=new MmConfigReader;
g_MmConfigReaderObj->m_Dealloc_Msisdn_On_Fail=1;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MAP_SPEC_EVENT_INDICATION_case3_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=2;
p_MsgPtr.m_OpCode=2;
p_MsgPtr.m_Version=3;
p_MsgPtr.m_allocatedFlag=false;
int *ptr=new int;
*ptr=1;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
delete ptr;
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MAP_SPEC_EVENT_INDICATION_case3_else_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=2;
p_MsgPtr.m_OpCode=2;
p_MsgPtr.m_Version=3;
p_MsgPtr.m_allocatedFlag=true;
int *ptr=new int;
*ptr=1;
bool p_DeleteFlag=true;
EXPECT_FALSE(processMessage(&p_MsgPtr,p_DeleteFlag));
delete ptr;
}



TEST_F(UT_CtxtUpdateLocation,processMessage_MAP_SPEC_EVENT_INDICATION_case2_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=2;
p_MsgPtr.m_OpCode=2;
p_MsgPtr.m_Version=2;
p_MsgPtr.m_allocatedFlag=false;
int *ptr=new int;
*ptr=1;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
delete ptr;
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MAP_SPEC_EVENT_INDICATION_case2_else_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=2;
p_MsgPtr.m_OpCode=2;
p_MsgPtr.m_Version=2;
p_MsgPtr.m_allocatedFlag=true;
int *ptr=new int;
*ptr=1;
bool p_DeleteFlag=true;
EXPECT_FALSE(processMessage(&p_MsgPtr,p_DeleteFlag));
delete ptr;
}


TEST_F(UT_CtxtUpdateLocation,processMessage_MAP_SPEC_EVENT_INDICATION_case1_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=2;
p_MsgPtr.m_OpCode=2;
p_MsgPtr.m_Version=1;
p_MsgPtr.m_allocatedFlag=false;
int *ptr=new int;
*ptr=1;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
delete ptr;
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MAP_SPEC_EVENT_INDICATION_case1_else_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=2;
p_MsgPtr.m_OpCode=2;
p_MsgPtr.m_Version=1;
p_MsgPtr.m_allocatedFlag=true;
int *ptr=new int;
*ptr=1;
bool p_DeleteFlag=true;
EXPECT_FALSE(processMessage(&p_MsgPtr,p_DeleteFlag));
delete ptr;
}


TEST_F(UT_CtxtUpdateLocation,processMessage_MAP_SPEC_EVENT_INDICATION_default_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=2;
p_MsgPtr.m_OpCode=2;
p_MsgPtr.m_Version=1;
p_MsgPtr.m_allocatedFlag=false;
int *ptr=new int;
*ptr=1;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
delete ptr;
}
/*
//NOT WORKING
TEST_F(UT_CtxtUpdateLocation,processMessage_MAP_SPEC_EVENT_INDICATION_g_spdPtr_no_null_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=2;
p_MsgPtr.m_OpCode=2;
p_MsgPtr.m_Version=3;
p_MsgPtr.m_allocatedFlag=true;
int *ptr=new int;
*ptr=1;
g_spdPtr=1;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
delete ptr;
}
*/

TEST_F(UT_CtxtUpdateLocation,processMessage_MAP_OP_CODE_restoreData_case2_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=2;
p_MsgPtr.m_OpCode=57;
p_MsgPtr.m_Version=2;
p_MsgPtr.m_allocatedFlag=false;
int *ptr=new int;
*ptr=1;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));delete ptr;
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MAP_OP_CODE_restoreData_case2_else_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=2;
p_MsgPtr.m_OpCode=57;
p_MsgPtr.m_Version=2;
p_MsgPtr.m_allocatedFlag=true;
int *ptr=new int;
*ptr=1;
bool p_DeleteFlag=true;
EXPECT_FALSE(processMessage(&p_MsgPtr,p_DeleteFlag));delete ptr;
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MAP_OP_CODE_restoreData_case3_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=2;
p_MsgPtr.m_OpCode=57;
p_MsgPtr.m_Version=3;
p_MsgPtr.m_allocatedFlag=false;
int *ptr=new int;
*ptr=1;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
delete ptr;
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MAP_OP_CODE_restoreData_case3_else_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=2;
p_MsgPtr.m_OpCode=57;
p_MsgPtr.m_Version=3;
p_MsgPtr.m_allocatedFlag=true;
int *ptr=new int;
*ptr=1;
bool p_DeleteFlag=true;
EXPECT_FALSE(processMessage(&p_MsgPtr,p_DeleteFlag));delete ptr;
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MAP_OP_CODE_restoreData_default_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=2;
p_MsgPtr.m_OpCode=57;
p_MsgPtr.m_Version=0;
p_MsgPtr.m_allocatedFlag=false;
int *ptr=new int;
*ptr=1;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
delete ptr;
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MAP_OP_CODE_sendParameters_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=2;
p_MsgPtr.m_OpCode=9;
//p_MsgPtr.m_Version=0;
p_MsgPtr.m_allocatedFlag=false;
int *ptr=new int;
*ptr=1;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
delete ptr;
}


TEST_F(UT_CtxtUpdateLocation,processMessage_MAP_MSG_TYPE_SPECIFIC_default_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=0;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}


TEST_F(UT_CtxtUpdateLocation,processMessage_MAP_SPEC_EVENT_RESULT_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=3;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MAP_OP_CODE_activateTraceMode_case3_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=4;
p_MsgPtr.m_OpCode=50;
p_MsgPtr.m_Version=3;
bool p_DeleteFlag=true;
EXPECT_FALSE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MAP_OP_CODE_activateTraceMode_case2_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=4;
p_MsgPtr.m_OpCode=50;
p_MsgPtr.m_Version=2;
bool p_DeleteFlag=true;
EXPECT_FALSE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MAP_OP_CODE_activateTraceMode_case1_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=4;
p_MsgPtr.m_OpCode=50;
p_MsgPtr.m_Version=1;
bool p_DeleteFlag=true;
EXPECT_FALSE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MAP_OP_CODE_activateTraceMode_l_Version_Three_Func) {
MapSpecificMsg p_MsgPtr;
CtxtUpdateLocation::l_Version=3;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=4;
p_MsgPtr.m_OpCode=50;
p_MsgPtr.m_Version=1;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MAP_OP_CODE_activateTraceMode_l_Version_Two_Func) {
MapSpecificMsg p_MsgPtr;
CtxtUpdateLocation::l_Version=2;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=4;
p_MsgPtr.m_OpCode=50;
p_MsgPtr.m_Version=2;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MAP_OP_CODE_activateTraceMode_l_Version_One_Func) {
MapSpecificMsg p_MsgPtr;
CtxtUpdateLocation::l_Version=1;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=4;
p_MsgPtr.m_OpCode=50;
p_MsgPtr.m_Version=1;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}


TEST_F(UT_CtxtUpdateLocation,processMessage_MAP_OP_CODE_insertSubscriberData_default_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=4;
p_MsgPtr.m_OpCode=07;
l_Version=0;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}


TEST_F(UT_CtxtUpdateLocation,processMessage_MAP_SPEC_EVENT_USER_ERROR_Func) {
//MapUserError p_MsgPtr(1,0,1,NULL);
MapUserError p_MsgPtr(1, MAP_ERROR_callBarred, MAP_V3, NULL);
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=5;
p_MsgPtr.m_ErrorCode=1;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MAP_SPEC_EVENT_PROV_ERROR_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=6;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MSG_TYPE_DB_m_usds_Func) {
UpdateVLRData p_MsgPtr;
p_MsgPtr.m_MsgType=2;
CtxtCancelLocation *ptr=new CtxtCancelLocation;
ptr->m_callState=7;
p_MsgPtr.m_ErrorCode=1;
p_MsgPtr.m_ErrorMsg[300]="aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
p_MsgPtr.m_DbQueryRes=1;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
delete ptr;
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MSG_TYPE_DB_m_usds_else_Func) {
UpdateVLRData p_MsgPtr;
p_MsgPtr.m_MsgType=2;
CtxtCancelLocation *ptr=new CtxtCancelLocation;
ptr->m_callState=7;
p_MsgPtr.m_ErrorCode=1;
p_MsgPtr.m_ErrorMsg[300]="aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
p_MsgPtr.m_DbQueryRes=0;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
delete ptr;
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MSG_TYPE_DB_m_usdf_Func) {
UpdateVLRData p_MsgPtr;
p_MsgPtr.m_ErrorCode=1;
p_MsgPtr.m_ErrorMsg[300]="aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
p_MsgPtr.m_DbQueryRes=1;
CtxtCancelLocation *ptr=new CtxtCancelLocation;
ptr->m_callState=8;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
delete ptr;
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MSG_TYPE_DB_m_usdf_else_Func) {
UpdateVLRData p_MsgPtr;
p_MsgPtr.m_ErrorCode=1;
p_MsgPtr.m_ErrorMsg[300]="aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
p_MsgPtr.m_DbQueryRes=0;
CtxtCancelLocation *ptr=new CtxtCancelLocation;
ptr->m_callState=8;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
delete ptr;
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MSG_TYPE_DB_inside_default_Func) {
UpdateVLRData p_MsgPtr;
p_MsgPtr.m_ErrorCode=1;
p_MsgPtr.m_ErrorMsg[300]="aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
p_MsgPtr.m_DbQueryRes=0;
CtxtCancelLocation *ptr=new CtxtCancelLocation;
ptr->m_callState=10;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
delete ptr;
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MSG_TYPE_DB_m_usds_two_Func) {
UpdateVLRData p_MsgPtr;
p_MsgPtr.m_MsgType=2;
l_state=7;
p_MsgPtr.m_ErrorCode=1;
p_MsgPtr.m_ErrorMsg[300]="aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
p_MsgPtr.m_DbQueryRes=1;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MSG_TYPE_DB_m_usds_else_two_Func) {
UpdateVLRData p_MsgPtr;
p_MsgPtr.m_MsgType=2;
CtxtUpdateLocation::l_state=7;
p_MsgPtr.m_ErrorCode=1;
p_MsgPtr.m_ErrorMsg[300]="aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
p_MsgPtr.m_DbQueryRes=1;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}
#if 0
june 1
TEST_F(UT_CtxtUpdateLocation,processMessage_MSG_TYPE_DB_m_rsd_Func) {
RetrieveSubsVLRData p_MsgPtr;
p_MsgPtr.m_MsgType=2;
CtxtUpdateLocation::l_state=0;
p_MsgPtr.m_UserDlgId=1;
p_MsgPtr.m_ErrorCode=1;
p_MsgPtr.m_HlrADDR[20+1]="aaaaaaaaaaaaaaaaaaaa";
p_MsgPtr.m_TdrData[200+1]="qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq";
p_MsgPtr.m_Non_Camel_Action=1;
p_MsgPtr.m_ossTriggerDataCount_OUT=2;
p_MsgPtr.m_crossClType_OUT=1;
p_MsgPtr.m_qSpaErrMsg[100+1]="TRIG_DISABLED_NWK";
p_MsgPtr.m_localImsiSubscription=2;
p_MsgPtr.m_PriMsisdn[20+1]="qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq";
p_MsgPtr.m_PriImsi[15+1]="wwwwwwwwwwwwwwwwwww";
p_MsgPtr.m_FirstUL=1;
p_MsgPtr.m_gsmFul=1;
p_MsgPtr.m_MsisdnAllcatedStatus=14;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MSG_TYPE_DB_Two_Func) {
RetrieveSubsVLRData p_MsgPtr;
p_MsgPtr.m_MsgType=2;
CtxtUpdateLocation::l_state=0;
p_MsgPtr.m_ossTriggerDataCount_OUT=3;
p_MsgPtr.m_crossClType_OUT=2;
p_MsgPtr.m_qSpaErrMsg[100+1]="aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
p_MsgPtr.m_ErrorCode =0;
p_MsgPtr.m_MsisdnAllcatedStatus =0;
p_MsgPtr.m_RemainingMsisnd=0;
p_MsgPtr.m_DynMsisdnMinFreeThreshold=2;
p_MsgPtr.m_TrapCode[50+1]="aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
g_prov=new CommonDataBase;
p_MsgPtr.m_TrapDesc[500+1]="aaaaaaaaaaaaaaaaa";
CtxtUpdateLocation::l_OpCode=7;
p_MsgPtr.m_DbQueryRes=0;
p_MsgPtr.m_ErrorCode=5;
//CtxtCancelLocation::l_Version=3;
l_Version=3;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MSG_TYPE_DB_Three_Func) {
RetrieveSubsVLRData p_MsgPtr;
p_MsgPtr.m_MsgType=2;
CtxtUpdateLocation::l_state=0;
p_MsgPtr.m_ossTriggerDataCount_OUT=3;
p_MsgPtr.m_crossClType_OUT=2;
EMsgType l_msgType=7;
strcpy(p_MsgPtr.m_qSpaErrMsg,"TRIG_TO_SEND");
p_MsgPtr.m_freeCount=1;
p_MsgPtr.m_threshCount=5;
p_MsgPtr.m_MsisdnAllcatedStatus=10;
p_MsgPtr.m_transFreeCount=1;
p_MsgPtr.m_transThreshCount=10;
p_MsgPtr.m_ErrorCode=0;
p_MsgPtr.m_MsisdnAllcatedStatus=0;
bool p_DeleteFlag=true;
EXPECT_FALSE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MSG_TYPE_DB_Four_Func) {
RetrieveSubsVLRData p_MsgPtr;
p_MsgPtr.m_MsgType=2;
CtxtUpdateLocation::l_state=0;
p_MsgPtr.m_ossTriggerDataCount_OUT=3;
p_MsgPtr.m_crossClType_OUT=2;
EMsgType l_msgType=7;
strcpy(p_MsgPtr.m_qSpaErrMsg,"TRIG_TO_SEND");
p_MsgPtr.m_freeCount=1;
p_MsgPtr.m_threshCount=5;
//p_MsgPtr.m_MsisdnAllcatedStatus=10;
p_MsgPtr.m_transFreeCount=1;
p_MsgPtr.m_transThreshCount=10;
p_MsgPtr.m_ErrorCode=0;
p_MsgPtr.m_MsisdnAllcatedStatus=1;
bool p_DeleteFlag=true;
p_MsgPtr.m_RemainingMsisnd=0;
p_MsgPtr.m_DynMsisdnMinFreeThreshold=1;
p_MsgPtr.m_TrapCode[50+1]="aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
g_prov=new CommonDataBase;
CtxtUpdateLocation::m_MsisdnAllocStatus=1;
char tempBuff[1]="2";
l_Version=2;
p_MsgPtr.m_DbQueryRes=0;
CtxtUpdateLocation::l_OpCode=2;
//g_spd=new SubsProfileData;
//map<int, HlrNetworks *> l_HlrNetworks;
//HlrNetworks h1;
//h1.m_networkId=1;
//h1.m_hlrAddr[20+1]="aaaaaaaaa";
//h1.m_roamProfSel=1;
//h1.m_hssOrigHost[100+1]="aaaaaaaaaaaaaaaaaa";
//h1.m_hssOrigRealm[100+1]="aaaaaaaaaaaaaaaaaaaaaaaaaa";
//h1.m_hssCxOrigHost[100+1]="aaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
//h1.m_hssCxOrigRealm[100+1]="aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
//h1.m_DisableFwdInfoInIsdSri=1;
//l_HlrNetworks.insert(make_pair(1,&h1));
//g_spdPtr->m_HlrNetworks=l_HlrNetworks;
//g_spdPtr=new SubsProfileData;
//g_spdPtr->m_HlrNetworks;
//map<int, HlrNetworks *> m_HlrNetworks;
//HlrNetworks *h1=new HlrNetworks;
//h1->m_networkId=1;
//m_HlrNetworks.insert(make_pair(1,h1));
//g_spdPtr=m_HlrNetworks;
p_MsgPtr.m_nwid=1;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MSG_TYPE_DB_line_1358_Func) {
RetrieveSubsVLRData p_MsgPtr;
p_MsgPtr.m_MsgType=2;
p_MsgPtr.m_ErrorCode=1;
l_Version=3;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MSG_TYPE_DB_line_1361_Func) {
RetrieveSubsVLRData p_MsgPtr;
p_MsgPtr.m_MsgType=2;
p_MsgPtr.m_ErrorCode=1;
l_Version=2;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MSG_TYPE_DB_line_1366_Func) {
RetrieveSubsVLRData p_MsgPtr;
p_MsgPtr.m_MsgType=2;
p_MsgPtr.m_ErrorCode=1;
l_Version=1;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MSG_TYPE_DB_line_1376_Func) {
RetrieveSubsVLRData p_MsgPtr;
p_MsgPtr.m_MsgType=2;
p_MsgPtr.m_ErrorCode=8;
l_Version=3;
CtxtUpdateLocation::l_OpCode=57;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MSG_TYPE_DB_line_1388_Func) {
RetrieveSubsVLRData p_MsgPtr;
p_MsgPtr.m_MsgType=2;
p_MsgPtr.m_ErrorCode=8;
l_Version=2;
CtxtUpdateLocation::l_OpCode=57;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MSG_TYPE_DB_line_1392_Func) {
RetrieveSubsVLRData p_MsgPtr;
p_MsgPtr.m_MsgType=2;
p_MsgPtr.m_ErrorCode=8;
l_Version=1;
CtxtUpdateLocation::l_OpCode=57;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MSG_TYPE_DB_line_1394_Func) {
RetrieveSubsVLRData p_MsgPtr;
p_MsgPtr.m_MsgType=2;
p_MsgPtr.m_ErrorCode=8;
l_Version=0;
CtxtUpdateLocation::l_OpCode=57;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MSG_TYPE_DB_line_1407_Func) {
RetrieveSubsVLRData p_MsgPtr;
p_MsgPtr.m_MsgType=2;
p_MsgPtr.m_ErrorCode=8;
l_Version=3;
CtxtUpdateLocation::l_OpCode=1;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MSG_TYPE_DB_line_1412_Func) {
RetrieveSubsVLRData p_MsgPtr;
p_MsgPtr.m_MsgType=2;
p_MsgPtr.m_ErrorCode=8;
l_Version=2;
CtxtUpdateLocation::l_OpCode=1;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MSG_TYPE_DB_line_1417_Func) {
RetrieveSubsVLRData p_MsgPtr;
p_MsgPtr.m_MsgType=2;
p_MsgPtr.m_ErrorCode=8;
l_Version=1;
CtxtUpdateLocation::l_OpCode=1;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MSG_TYPE_DB_line_1421_Func) {
RetrieveSubsVLRData p_MsgPtr;
p_MsgPtr.m_MsgType=2;
p_MsgPtr.m_ErrorCode=8;
l_Version=0;
CtxtUpdateLocation::l_OpCode=1;
bool p_DeleteFlag=true;
EXPECT_FALSE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MSG_TYPE_DB_line_1436_Func) {
RetrieveSubsVLRData p_MsgPtr;
p_MsgPtr.m_MsgType=2;
p_MsgPtr.m_ErrorCode=9;
l_Version=3;
CtxtUpdateLocation::l_OpCode=57;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MSG_TYPE_DB_line_1441_Func) {
RetrieveSubsVLRData p_MsgPtr;
p_MsgPtr.m_MsgType=2;
p_MsgPtr.m_ErrorCode=9;
l_Version=2;
CtxtUpdateLocation::l_OpCode=57;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MSG_TYPE_DB_line_1445_Func) {
RetrieveSubsVLRData p_MsgPtr;
p_MsgPtr.m_MsgType=2;
p_MsgPtr.m_ErrorCode=9;
l_Version=1;
CtxtUpdateLocation::l_OpCode=57;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MSG_TYPE_DB_line_1448_Func) {
RetrieveSubsVLRData p_MsgPtr;
p_MsgPtr.m_MsgType=2;
p_MsgPtr.m_ErrorCode=9;
l_Version=0;
CtxtUpdateLocation::l_OpCode=57;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MSG_TYPE_DB_line_1458_Func) {
RetrieveSubsVLRData p_MsgPtr;
p_MsgPtr.m_MsgType=2;
p_MsgPtr.m_ErrorCode=9;
l_Version=3;
CtxtUpdateLocation::l_OpCode=1;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MSG_TYPE_DB_line_1463_Func) {
RetrieveSubsVLRData p_MsgPtr;
p_MsgPtr.m_MsgType=2;
p_MsgPtr.m_ErrorCode=9;
l_Version=2;
CtxtUpdateLocation::l_OpCode=1;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MSG_TYPE_DB_line_1467_Func) {
RetrieveSubsVLRData p_MsgPtr;
p_MsgPtr.m_MsgType=2;
p_MsgPtr.m_ErrorCode=9;
l_Version=1;
CtxtUpdateLocation::l_OpCode=1;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MSG_TYPE_DB_line_1470_Func) {
RetrieveSubsVLRData p_MsgPtr;
p_MsgPtr.m_MsgType=2;
p_MsgPtr.m_ErrorCode=9;
l_Version=0;
CtxtUpdateLocation::l_OpCode=1;
bool p_DeleteFlag=true;
EXPECT_FALSE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MSG_TYPE_DB_line_1480_Func) {
RetrieveSubsVLRData p_MsgPtr;
p_MsgPtr.m_MsgType=2;
p_MsgPtr.m_ErrorCode=10;
l_Version=0;
CtxtUpdateLocation::l_OpCode=1;
bool p_DeleteFlag=true;
g_MmConfigReaderObj->m_Multi_Imsi_ErrCode=1;
EXPECT_FALSE(processMessage(&p_MsgPtr,p_DeleteFlag));
}
/*
//NOT WORKING
TEST_F(UT_CtxtUpdateLocation,processMessage_MSG_TYPE_DB_line_1480_Two_Func) {
RetrieveSubsVLRData p_MsgPtr;
RetrieveSubsVLRData *ptr=new RetrieveSubsVLRData;
p_MsgPtr.m_MsgType=2;
ptr->m_ErrorCode=10;
l_Version=0;
CtxtUpdateLocation::l_OpCode=1;
bool p_DeleteFlag=true;
g_MmConfigReaderObj->m_Multi_Imsi_ErrCode=1;
EXPECT_FALSE(processMessage(&p_MsgPtr,p_DeleteFlag));
delete ptr;
}
*/

TEST_F(UT_CtxtUpdateLocation,processMessage_MSG_TYPE_DB_line_1482_Func) {
RetrieveSubsVLRData p_MsgPtr;
p_MsgPtr.m_MsgType=2;
p_MsgPtr.m_ErrorCode=12;
bool p_DeleteFlag=true;
g_MmConfigReaderObj->m_Multi_Imsi_ErrCode=1;
EXPECT_FALSE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MSG_TYPE_DB_line_1487_Func) {
RetrieveSubsVLRData p_MsgPtr;
p_MsgPtr.m_MsgType=2;
p_MsgPtr.m_ErrorCode=41;
bool p_DeleteFlag=true;
g_MmConfigReaderObj->m_Multi_Imsi_ErrCode=1;
EXPECT_FALSE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MSG_TYPE_DB_line_1495_Func) {
RetrieveSubsVLRData p_MsgPtr;
p_MsgPtr.m_MsgType=2;
p_MsgPtr.m_ErrorCode=42;
bool p_DeleteFlag=true;
g_MmConfigReaderObj->m_Multi_Imsi_ErrCode=1;
EXPECT_FALSE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MSG_TYPE_DB_line_1501_Func) {
RetrieveSubsVLRData p_MsgPtr;
p_MsgPtr.m_MsgType=2;
p_MsgPtr.m_ErrorCode=43;
bool p_DeleteFlag=true;
g_MmConfigReaderObj->m_Multi_Imsi_ErrCode=1;
EXPECT_FALSE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MSG_TYPE_DB_line_1507_Func) {
RetrieveSubsVLRData p_MsgPtr;
p_MsgPtr.m_MsgType=2;
p_MsgPtr.m_ErrorCode=44;
bool p_DeleteFlag=true;
g_MmConfigReaderObj->m_Multi_Imsi_ErrCode=1;
l_Version=3;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}
/*
//seg fault
TEST_F(UT_CtxtUpdateLocation,processMessage_MSG_TYPE_DB_line_1136_Func) {
RetrieveSubsVLRData p_MsgPtr;
p_MsgPtr.m_MsgType=2;
CtxtUpdateLocation::l_state=0;
bool p_DeleteFlag=true;
p_MsgPtr.m_DbQueryRes=1;
p_MsgPtr.m_MsisdnAllcatedStatus=0;
g_spd=new GlobalData;
//g_spdPtr=new GlobalData;
CtxtUpdateLocation::l_Version=3;
CtxtUpdateLocation::l_OpCode=2;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MSG_TYPE_DB_line_1298_Func) {
RetrieveSubsVLRData p_MsgPtr;
p_MsgPtr.m_MsgType=2;
CtxtUpdateLocation::l_state=0;
bool p_DeleteFlag=true;
p_MsgPtr.m_DbQueryRes=1;
p_MsgPtr.m_MsisdnAllcatedStatus=0;
g_spd=new GlobalData;
CtxtUpdateLocation::l_Version=2;
CtxtUpdateLocation::l_OpCode=2;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}
*/
/*
//seg fault
TEST_F(UT_CtxtUpdateLocation,processMessage_MSG_TYPE_DB_line_1312_Func) {
RetrieveSubsVLRData p_MsgPtr;
p_MsgPtr.m_MsgType=2;
CtxtUpdateLocation::l_state=0;
bool p_DeleteFlag=true;
p_MsgPtr.m_DbQueryRes=1;
p_MsgPtr.m_MsisdnAllcatedStatus=0;
g_spd=new GlobalData;
CtxtUpdateLocation::l_Version=1;
CtxtUpdateLocation::l_OpCode=10;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}*/


/*
//Already comennted
TEST_F(UT_CtxtUpdateLocation,processMessage_MSG_TYPE_DB_m_rsd_Two_Func) {
RetrieveSubsVLRData p_MsgPtr;
p_MsgPtr.m_MsgType=2;
CtxtUpdateLocation::l_state=0;
p_MsgPtr.m_UserDlgId=1;
p_MsgPtr.m_ErrorCode=0;
p_MsgPtr.m_HlrADDR[20+1]="aaaaaaaaaaaaaaaaaaaa";
p_MsgPtr.m_TdrData[200+1]="qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq";
p_MsgPtr.m_Non_Camel_Action=1;
p_MsgPtr.m_ossTriggerDataCount_OUT=3;
p_MsgPtr.m_crossClType_OUT=0;
EMsgType l_msgType=7;
p_MsgPtr.m_qSpaErrMsg[100+1]="TRIG_DISABLED_NWK";
p_MsgPtr.m_localImsiSubscription=3;
p_MsgPtr.m_freeCount=1;
p_MsgPtr.m_threshCount=2;
p_MsgPtr.m_PriMsisdn[20+1]="qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq";
p_MsgPtr.m_PriImsi[15+1]="wwwwwwwwwwwwwwwwwww";
p_MsgPtr.m_FirstUL=1;
p_MsgPtr.m_gsmFul=1;
p_MsgPtr.m_MsisdnAllcatedStatus=10;
p_MsgPtr.m_transFreeCount=1;
p_MsgPtr.m_transThreshCount=3;
l_Version=3;
p_MsgPtr.m_DbQueryRes=1;
CtxtUpdateLocation::m_fIsd=false;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MSG_TYPE_DB_m_rsd_Three_Func) {
RetrieveSubsVLRData p_MsgPtr;
e_MsgPtr.m_MsgType=2;
CtxtUpdateLocation::l_state=0;
p_MsgPtr.m_UserDlgId=2;
p_MsgPtr.m_ErrorCode=8;
p_MsgPtr.m_HlrADDR[20+1]="aaaaaaaaaaaaaaaaaaaa";
p_MsgPtr.m_TdrData[200+1]="qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq";
p_MsgPtr.m_Non_Camel_Action=1;
p_MsgPtr.m_ossTriggerDataCount_OUT=3;
p_MsgPtr.m_crossClType_OUT=0;
EMsgType l_msgType=7;
p_MsgPtr.m_qSpaErrMsg[100+1]="TRIG_DISABLED_NWK";
p_MsgPtr.m_localImsiSubscription=3;
p_MsgPtr.m_freeCount=1;
p_MsgPtr.m_threshCount=2;
p_MsgPtr.m_PriMsisdn[20+1]="qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq";
p_MsgPtr.m_PriImsi[15+1]="wwwwwwwwwwwwwwwwwww";
p_MsgPtr.m_FirstUL=1;
p_MsgPtr.m_gsmFul=1;
p_MsgPtr.m_MsisdnAllcatedStatus=0;
p_MsgPtr.m_transFreeCount=1;
p_MsgPtr.m_transThreshCount=3;
CtxtUpdateLocation::l_Version=3;
CtxtUpdateLocation::l_OpCode=57;
p_MsgPtr.m_DbQueryRes=1;
CtxtUpdateLocation::m_fIsd=false;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MSG_TYPE_DB_m_rsd_Four_Func) {
RetrieveSubsVLRData p_MsgPtr;
p_MsgPtr.m_MsgType=2;
CtxtUpdateLocation::l_state=0;
p_MsgPtr.m_UserDlgId=2;
p_MsgPtr.m_ErrorCode=9;
p_MsgPtr.m_HlrADDR[20+1]="aaaaaaaaaaaaaaaaaaaa";
p_MsgPtr.m_TdrData[200+1]="qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq";
p_MsgPtr.m_Non_Camel_Action=1;
p_MsgPtr.m_ossTriggerDataCount_OUT=3;
p_MsgPtr.m_crossClType_OUT=0;
EMsgType l_msgType=7;
p_MsgPtr.m_qSpaErrMsg[100+1]="TRIG_DISABLED_NWK";
p_MsgPtr.m_localImsiSubscription=3;
p_MsgPtr.m_freeCount=1;
p_MsgPtr.m_threshCount=2;
p_MsgPtr.m_PriMsisdn[20+1]="qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq";
p_MsgPtr.m_PriImsi[15+1]="wwwwwwwwwwwwwwwwwww";
p_MsgPtr.m_FirstUL=1;
p_MsgPtr.m_gsmFul=1;
p_MsgPtr.m_MsisdnAllcatedStatus=0;
p_MsgPtr.m_transFreeCount=1;
p_MsgPtr.m_transThreshCount=3;
CtxtUpdateLocation::l_Version=3;
CtxtUpdateLocation::l_OpCode=57;
p_MsgPtr.m_DbQueryRes=1;
CtxtUpdateLocation::m_fIsd=false;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MSG_TYPE_DB_m_rsd_Five_Func) {
RetrieveSubsVLRData p_MsgPtr;
p_MsgPtr.m_MsgType=2;
CtxtUpdateLocation::l_state=0;
p_MsgPtr.m_UserDlgId=2;
p_MsgPtr.m_ErrorCode=41;
p_MsgPtr.m_HlrADDR[20+1]="aaaaaaaaaaaaaaaaaaaa";
p_MsgPtr.m_TdrData[200+1]="qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq";
p_MsgPtr.m_Non_Camel_Action=1;
p_MsgPtr.m_ossTriggerDataCount_OUT=3;
p_MsgPtr.m_crossClType_OUT=0;
EMsgType l_msgType=7;
p_MsgPtr.m_qSpaErrMsg[100+1]="TRIG_DISABLED_NWK";
p_MsgPtr.m_localImsiSubscription=3;
p_MsgPtr.m_freeCount=1;
p_MsgPtr.m_threshCount=2;
p_MsgPtr.m_PriMsisdn[20+1]="qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq";
p_MsgPtr.m_PriImsi[15+1]="wwwwwwwwwwwwwwwwwww";
p_MsgPtr.m_FirstUL=1;
p_MsgPtr.m_gsmFul=1;
p_MsgPtr.m_MsisdnAllcatedStatus=0;
p_MsgPtr.m_transFreeCount=1;
p_MsgPtr.m_transThreshCount=3;
CtxtUpdateLocation::l_Version=3;
CtxtUpdateLocation::l_OpCode=57;
p_MsgPtr.m_DbQueryRes=1;
CtxtUpdateLocation::m_fIsd=false;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MSG_TYPE_DB_m_rsd_six_Func) {
RetrieveSubsVLRData p_MsgPtr;
p_MsgPtr.m_MsgType=2;
CtxtUpdateLocation::l_state=0;
p_MsgPtr.m_UserDlgId=2;
p_MsgPtr.m_ErrorCode=0;
p_MsgPtr.m_HlrADDR[20+1]="aaaaaaaaaaaaaaaaaaaa";
p_MsgPtr.m_TdrData[200+1]="qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq";
p_MsgPtr.m_Non_Camel_Action=1;
p_MsgPtr.m_ossTriggerDataCount_OUT=3;
p_MsgPtr.m_crossClType_OUT=0;
EMsgType l_msgType=7;
p_MsgPtr.m_qSpaErrMsg[100+1]="TRIG_DISABLED_NWK";
p_MsgPtr.m_localImsiSubscription=3;
p_MsgPtr.m_freeCount=1;
p_MsgPtr.m_threshCount=2;
p_MsgPtr.m_PriMsisdn[20+1]="qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq";
p_MsgPtr.m_PriImsi[15+1]="wwwwwwwwwwwwwwwwwww";
p_MsgPtr.m_FirstUL=1;
p_MsgPtr.m_gsmFul=1;
p_MsgPtr.m_MsisdnAllcatedStatus=0;
p_MsgPtr.m_transFreeCount=1;
p_MsgPtr.m_transThreshCount=3;
CtxtUpdateLocation::l_Version=3;
CtxtUpdateLocation::l_OpCode=57;
p_MsgPtr.m_DbQueryRes=1;
CtxtUpdateLocation::m_fIsd=false;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateLocation,processMessage_MSG_TYPE_DB_m_rsd_seven_Func) {
RetrieveSubsVLRData p_MsgPtr;
p_MsgPtr.m_MsgType=2;
CtxtUpdateLocation::l_state=0;
p_MsgPtr.m_UserDlgId=2;
p_MsgPtr.m_ErrorCode=0;
p_MsgPtr.m_HlrADDR[20+1]="aaaaaaaaaaaaaaaaaaaa";
p_MsgPtr.m_TdrData[200+1]="qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq";
p_MsgPtr.m_Non_Camel_Action=1;
p_MsgPtr.m_ossTriggerDataCount_OUT=3;
p_MsgPtr.m_crossClType_OUT=0;
EMsgType l_msgType=7;
p_MsgPtr.m_qSpaErrMsg[100+1]="TRIG_DISABLED_NWK";
p_MsgPtr.m_localImsiSubscription=3;
p_MsgPtr.m_freeCount=1;
p_MsgPtr.m_threshCount=2;
p_MsgPtr.m_PriMsisdn[20+1]="qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq";
p_MsgPtr.m_PriImsi[15+1]="wwwwwwwwwwwwwwwwwww";
p_MsgPtr.m_FirstUL=1;
p_MsgPtr.m_gsmFul=1;
p_MsgPtr.m_MsisdnAllcatedStatus=1;
p_MsgPtr.m_transFreeCount=1;
p_MsgPtr.m_transThreshCount=3;
CtxtUpdateLocation::l_Version=3;
CtxtUpdateLocation::l_OpCode=57;
p_MsgPtr.m_DbQueryRes=1;
CtxtUpdateLocation::m_fIsd=false;
p_MsgPtr.m_RemainingMsisnd=0;
p_MsgPtr.m_DynMsisdnMinFreeThreshold=4;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}
*/
#endif
/******************************************************************/

TEST_F(UT_CtxtUpdateLocation,CheckParametersV1_Func) {
IMAP1_UpdateLocationArg ab;
IMAP1_IMSI ba;
strcpy(ba.value,"aaaaaaaa");
ba.length=7;
EXPECT_FALSE(CheckParametersV1(1,&ab));
}
/*
june 1
TEST_F(UT_CtxtUpdateLocation,CheckParametersV1_Two_Func) {
IMAP1_UpdateLocationArg ab;
IMAP1_IMSI ba;
strcpy(ba.value,"aaaaaaaa");
ba.length=0;
strcpy(l_updv1.imsi,"aaaaaaaaaaaaaaa");
EXPECT_FALSE(CheckParametersV1(1,&ab));
}
*/
/************************************************************/

TEST_F(UT_CtxtUpdateLocation,UpdLocV1_Func) {
EXPECT_TRUE(UpdLocV1(1));
}

TEST_F(UT_CtxtUpdateLocation,UpdLocV2_Func) {
GenProfile.l_subsStatus=1;
CtxtUpdateLocation::l_GenOdb=1;
CtxtUpdateLocation::l_PlmnOdb=1;
ISDData *ptr=new ISDData;
ptr->dbisd2.odb_Genvalue=0;
ptr->dbisd2.odb_HplmnValue=0;
l_roamInd=1;
GsmProfile.l_TraceFlag=1;
GsmProfile.l_TraceStatus=1;
m_SendATM=true;
EXPECT_TRUE(UpdLocV2(1));
delete ptr;
}

TEST_F(UT_CtxtUpdateLocation,UpdLocV2_else_Func) {
CtxtUpdateLocation::GenProfile.l_subsStatus=0;
CtxtUpdateLocation::l_roamInd=0;
CtxtUpdateLocation::l_GenOdb=1;
CtxtUpdateLocation::l_PlmnOdb=1;
ISDData *ptr=new ISDData;
ptr->dbisd2.odb_Genvalue=0;
ptr->dbisd2.odb_HplmnValue=0;
l_roamInd=1;
CtxtUpdateLocation::GsmProfile.l_TraceFlag=1;
CtxtUpdateLocation::GsmProfile.l_TraceStatus=1;
CtxtUpdateLocation::m_SendATM=true;
EXPECT_TRUE(UpdLocV2(1));
delete ptr;
}

TEST_F(UT_CtxtUpdateLocation,UpdLocV3_Func) {
CtxtUpdateLocation::m_fIsd=true;
CtxtUpdateLocation::GenProfile.l_subsStatus=1;
CtxtUpdateLocation::l_GenOdb=1;
CtxtUpdateLocation::l_PlmnOdb=1;
CtxtUpdateLocation::GenProfile.l_ist=254;
CtxtUpdateLocation::l_updv3.istSupportIndicator=0;
CtxtUpdateLocation::l_updv3.VlrCap_Camel4=true;
CtxtUpdateLocation::GenProfile.l_ocsiPid=0;
CtxtUpdateLocation::GenProfile.l_vtcsiPid=0;
CtxtUpdateLocation::GenProfile.l_dcsiPid=0;
CtxtUpdateLocation::GenProfile.l_mtscsiPid=1;
CtxtUpdateLocation::l_updv3.c4_mtsCSI=false;
CtxtUpdateLocation::m_Cap_Failure_Action=0;
EXPECT_EQ(UpdLocV3(1),1001);
}

TEST_F(UT_CtxtUpdateLocation,UpdLocV3_Two_Func) {
CtxtUpdateLocation::m_fIsd=true;
CtxtUpdateLocation::GenProfile.l_subsStatus=1;
CtxtUpdateLocation::l_GenOdb=1;
CtxtUpdateLocation::l_PlmnOdb=1;
CtxtUpdateLocation::GenProfile.l_ist=300;
CtxtUpdateLocation::l_updv3.istSupportIndicator=0;
CtxtUpdateLocation::l_updv3.VlrCap_Camel4=true;
CtxtUpdateLocation::GenProfile.l_ocsiPid=0;
CtxtUpdateLocation::GenProfile.l_vtcsiPid=0;
CtxtUpdateLocation::GenProfile.l_dcsiPid=0;
CtxtUpdateLocation::GenProfile.l_mtscsiPid=1;
CtxtUpdateLocation::l_updv3.c4_mtsCSI=true;
CtxtUpdateLocation::m_Cap_Failure_Action=0;
EXPECT_NE(UpdLocV3(1),1);
}


/*
//Worked but giving seg fault now
TEST_F(UT_CtxtUpdateLocation,UpdLocV3_Three_Func) {
CtxtUpdateLocation::l_updv3.VlrCap_Camel4=true;
CtxtUpdateLocation::GenProfile.l_ocsiPid=1;
g_spd=new GlobalData;
l_updv3.c4_oCSI=true;
//GenProfile.l_ocsiPid=-100;
CtxtUpdateLocation::m_Cap_Failure_Action=0;
EXPECT_NE(UpdLocV3(1),100000);
}
*/

/*
//same as three
TEST_F(UT_CtxtUpdateLocation,UpdLocV3_Four_Func) {
CtxtUpdateLocation::l_updv3.VlrCap_Camel4=true;
CtxtUpdateLocation::GenProfile.l_vtcsiPid=1;
g_spd=new GlobalData;
l_updv3.c4_vtCSI=true;
CtxtUpdateLocation::m_Cap_Failure_Action=0;
EXPECT_NE(UpdLocV3(1),100000);
}
*/

/*
//gave seg fault in processDBdata 
TEST_F(UT_CtxtUpdateLocation,UpdLocV3_Five_Func) {
CtxtUpdateLocation::l_updv3.VlrCap_Camel4=true;
CtxtUpdateLocation::GenProfile.l_dcsiPid=1;
l_updv3.c4_dCSI=true;
g_spd=new GlobalData;
CtxtUpdateLocation::m_Cap_Failure_Action=0;
EXPECT_NE(UpdLocV3(1),100000);
}*/

TEST_F(UT_CtxtUpdateLocation,UpdLocV3_3257_Func) {
CtxtUpdateLocation::l_updv3.VlrCap_Camel4=false;
CtxtUpdateLocation::l_updv3.VlrCap_Camel3=true;
GenProfile.l_mtscsiPid=1;
CtxtUpdateLocation::m_Cap_Failure_Action=1;
EXPECT_NE(UpdLocV3(1),100000);
}

TEST_F(UT_CtxtUpdateLocation,UpdLocV3_3278_Func) {
CtxtUpdateLocation::l_updv3.VlrCap_Camel2=true;
CtxtUpdateLocation::l_updv3.VlrCap_Camel3=false;
CtxtUpdateLocation::l_updv3.VlrCap_Camel4=false;
GenProfile.l_mtscsiPid=1;
GenProfile.l_vtcsiPid=1;
GenProfile.l_dcsiPid=1;
GenProfile.l_moscsiPid=1;
CtxtUpdateLocation::m_Cap_Failure_Action =0;
EXPECT_NE(UpdLocV3(1),100000);
}

TEST_F(UT_CtxtUpdateLocation,UpdLocV3_3295_Func) {
CtxtUpdateLocation::l_updv3.VlrCap_Camel2=true;
CtxtUpdateLocation::l_updv3.VlrCap_Camel3=false;
CtxtUpdateLocation::l_updv3.VlrCap_Camel4=false;
GenProfile.l_mtscsiPid=0;
GenProfile.l_vtcsiPid=0;
GenProfile.l_dcsiPid=0;
GenProfile.l_moscsiPid=0;
CtxtUpdateLocation::m_Cap_Failure_Action =0;
EXPECT_NE(UpdLocV3(1),100000);
}

TEST_F(UT_CtxtUpdateLocation,UpdLocV3_3300_Func) {
CtxtUpdateLocation::l_updv3.VlrCap_Camel1=true;
CtxtUpdateLocation::l_updv3.VlrCap_Camel2=false;
CtxtUpdateLocation::l_updv3.VlrCap_Camel3=false;
CtxtUpdateLocation::l_updv3.VlrCap_Camel4=false;
GenProfile.l_sscsiPid=1;
GenProfile.l_tifcsiPid=1;
GenProfile.l_mtscsiPid=1;
GenProfile.l_vtcsiPid=1;
GenProfile.l_dcsiPid=1;
GenProfile.l_moscsiPid=1;
CtxtUpdateLocation::m_Cap_Failure_Action =0;
EXPECT_NE(UpdLocV3(1),100000);
}

TEST_F(UT_CtxtUpdateLocation,UpdLocV3_3315_Func) {
CtxtUpdateLocation::l_updv3.VlrCap_Camel1=true;
CtxtUpdateLocation::l_updv3.VlrCap_Camel2=false;
CtxtUpdateLocation::l_updv3.VlrCap_Camel3=false;
CtxtUpdateLocation::l_updv3.VlrCap_Camel4=false;
GenProfile.l_sscsiPid=0;
GenProfile.l_tifcsiPid=0;
GenProfile.l_mtscsiPid=0;
GenProfile.l_vtcsiPid=0;
GenProfile.l_dcsiPid=0;
GenProfile.l_moscsiPid=0;
EXPECT_NE(UpdLocV3(1),100000);
}

TEST_F(UT_CtxtUpdateLocation,UpdLocV3_3322_else_Func) {
CtxtUpdateLocation::l_updv3.VlrCap_Camel1=false;
CtxtUpdateLocation::l_updv3.VlrCap_Camel2=false;
CtxtUpdateLocation::l_updv3.VlrCap_Camel3=false;
CtxtUpdateLocation::l_updv3.VlrCap_Camel4=false;
GenProfile.l_sscsiPid=0;
GenProfile.l_tifcsiPid=0;
GenProfile.l_mtscsiPid=0;
GenProfile.l_vtcsiPid=0;
GenProfile.l_dcsiPid=0;
GenProfile.l_moscsiPid=0;
EXPECT_NE(UpdLocV3(1),100000);
}

/***************************************************************/

TEST_F(UT_CtxtUpdateLocation,UpdLocV3Cont_Func) {
EXPECT_NO_THROW(UpdLocV3Cont(1));
}

TEST_F(UT_CtxtUpdateLocation,UpdLocV2Cont_Func) {
EXPECT_NO_THROW(UpdLocV2Cont(1));
}

TEST_F(UT_CtxtUpdateLocation,UpdLocV1Cont_Func) {
EXPECT_NO_THROW(UpdLocV1Cont(1));
}

/************************************************************/

TEST_F(UT_CtxtUpdateLocation,startISDV2_Func) {
EXPECT_NO_THROW(startISDV2(1));
}

TEST_F(UT_CtxtUpdateLocation,startISDV1_Func) {
EXPECT_NO_THROW(startISDV1(1));
}

/************************************************************/

TEST_F(UT_CtxtUpdateLocation,UpdLocV3_Cont_Func) {
CtxtUpdateLocation::l_OpCode=107;
EXPECT_NO_THROW(UpdLocV3_Cont(1));
}

TEST_F(UT_CtxtUpdateLocation,UpdLocV3_Cont_Two_Func) {
CtxtUpdateLocation::l_mwd=1;
CtxtUpdateLocation::l_OpCode=2;
CtxtUpdateLocation::GsmProfile.l_ssInd=1;
EXPECT_NO_THROW(UpdLocV3_Cont(1));
}

TEST_F(UT_CtxtUpdateLocation,UpdLocV3_Cont_Three_Func) {
CtxtUpdateLocation::l_mwd=0;
CtxtUpdateLocation::l_OpCode=57;
EXPECT_NO_THROW(UpdLocV3_Cont(1));
}


TEST_F(UT_CtxtUpdateLocation,UpdLocV2_Cont_Func) {
CtxtUpdateLocation::l_OpCode=2;
EXPECT_NO_THROW(UpdLocV2_Cont(1));
}

TEST_F(UT_CtxtUpdateLocation,UpdLocV2_Cont_Two_Func) {
CtxtUpdateLocation::l_mwd=1;
CtxtUpdateLocation::l_OpCode=2;
CtxtUpdateLocation::GsmProfile.l_ssInd=1;
EXPECT_NO_THROW(UpdLocV2_Cont(1));
}

TEST_F(UT_CtxtUpdateLocation,UpdLocV2_Cont_Three_Func) {
CtxtUpdateLocation::l_mwd=1;
CtxtUpdateLocation::l_OpCode=57;
EXPECT_NO_THROW(UpdLocV2_Cont(1));
}

TEST_F(UT_CtxtUpdateLocation,UpdLocV1_Cont_Func) {
CtxtUpdateLocation::l_OpCode=2;
//RetrieveSubsVLRData *ptr=new RetrieveSubsVLRData;
RetrieveSubsVLRData obj;
obj.m_MWD=1;
EXPECT_NO_THROW(UpdLocV1_Cont(1));
//detele ptr;
}

TEST_F(UT_CtxtUpdateLocation,UpdLocV1_Cont_Two_Func) {
CtxtUpdateLocation::l_mwd=1;
CtxtUpdateLocation::GsmProfile.l_ssInd=1;
EXPECT_NO_THROW(UpdLocV1_Cont(1));
}

/***************************************************************/

TEST_F(UT_CtxtUpdateLocation,RetrieveData_Func) {
g_MmConfigReaderObj->m_Multi_Imsi_Reqd=true;
RetrieveSubsVLRData *ptr = new RetrieveSubsVLRData();
EXPECT_NO_THROW(RetrieveData(1,"aaaaaaaaaaaaaaaaaaaaaaaa","bbbbbbbbbbbbbbbbbbbb"));
delete ptr;
}

TEST_F(UT_CtxtUpdateLocation,RetrieveData_Two_Func) {
g_MmConfigReaderObj->m_Multi_Imsi_Reqd=true;
RetrieveSubsVLRData *ptr = new RetrieveSubsVLRData();
CtxtUpdateLocation::l_Version=3;
CtxtUpdateLocation::l_OpCode=2;
EXPECT_NO_THROW(RetrieveData(1,"aaaaaaaaaaaaaaaaaaaaaaaa","bbbbbbbbbbbbbbbbbbbb"));
delete ptr;
}

TEST_F(UT_CtxtUpdateLocation,RetrieveData_Two_Three_Func) {
g_MmConfigReaderObj->m_Multi_Imsi_Reqd=true;
RetrieveSubsVLRData *ptr = new RetrieveSubsVLRData();
CtxtUpdateLocation::l_Version=3;
CtxtUpdateLocation::l_OpCode=57;
EXPECT_NO_THROW(RetrieveData(1,"aaaaaaaaaaaaaaaaaaaaaaaa","bbbbbbbbbbbbbbbbbbbb"));
delete ptr;
}

TEST_F(UT_CtxtUpdateLocation,RetrieveData_Three_Func) {
g_MmConfigReaderObj->m_Multi_Imsi_Reqd=true;
RetrieveSubsVLRData *ptr = new RetrieveSubsVLRData();
CtxtUpdateLocation::l_Version=2;
CtxtUpdateLocation::l_OpCode=57;
EXPECT_NO_THROW(RetrieveData(1,"aaaaaaaaaaaaaaaaaaaaaaaa","bbbbbbbbbbbbbbbbbbbb"));
delete ptr;
}

TEST_F(UT_CtxtUpdateLocation,RetrieveData_Three_Two_Func) {
g_MmConfigReaderObj->m_Multi_Imsi_Reqd=true;
RetrieveSubsVLRData *ptr = new RetrieveSubsVLRData();
CtxtUpdateLocation::l_Version=2;
CtxtUpdateLocation::l_OpCode=2;
EXPECT_NO_THROW(RetrieveData(1,"aaaaaaaaaaaaaaaaaaaaaaaa","bbbbbbbbbbbbbbbbbbbb"));
delete ptr;
}

TEST_F(UT_CtxtUpdateLocation,RetrieveData_Four_Func) {
g_MmConfigReaderObj->m_Multi_Imsi_Reqd=true;
RetrieveSubsVLRData *ptr = new RetrieveSubsVLRData();
CtxtUpdateLocation::l_Version=1;
CtxtUpdateLocation::l_OpCode=9;
EXPECT_NO_THROW(RetrieveData(1,"aaaaaaaaaaaaaaaaaaaaaaaa","bbbbbbbbbbbbbbbbbbbb"));
delete ptr;
}

TEST_F(UT_CtxtUpdateLocation,RetrieveData_Four_else_Func) {
g_MmConfigReaderObj->m_Multi_Imsi_Reqd=true;
RetrieveSubsVLRData *ptr = new RetrieveSubsVLRData();
CtxtUpdateLocation::l_Version=1;
CtxtUpdateLocation::l_OpCode=1;
EXPECT_NO_THROW(RetrieveData(1,"aaaaaaaaaaaaaaaaaaaaaaaa","bbbbbbbbbbbbbbbbbbbb"));
delete ptr;
}

TEST_F(UT_CtxtUpdateLocation,RetrieveData_Five_else_Func) {
g_MmConfigReaderObj->m_Multi_Imsi_Reqd=true;
RetrieveSubsVLRData *ptr = new RetrieveSubsVLRData();
CtxtUpdateLocation::l_Version=3;
CtxtUpdateLocation::l_OpCode=1;
l_updv3.VlrCap_Camel4=true;
l_updv3.VlrCap_Camel3=true;
l_updv3.VlrCap_Camel2=true;
l_updv3.VlrCap_Camel1=true;
l_updv3.soLSA=true;
l_updv3.SuperCharge=true;
l_updv3.LongFTN=true;
l_updv3.lcsCS4=true;
l_updv3.lcsCS3=true;
l_updv3.lcsCS2=true;
l_updv3.lcsCS1=true;
ptr->m_SuppLCS=1;
l_updv3.c4_oCSI=true;
l_updv3.c4_dCSI=true;
l_updv3.c4_vtCSI=true;
l_updv3.c4_tCSI=true;
l_updv3.c4_mtsCSI=true;
l_updv3.c4_mgCSI=true;
strcpy(l_updv3.gmlc_Address,"aaaaaaaaaaaaaaaaaaaaaaa");
l_updv3.cs_LCS_NotSupportedByUE=true;
EXPECT_NO_THROW(RetrieveData(1,"aaaaaaaaaaaaaaaaaaaaaaaa","bbbbbbbbbbbbbbbbbbbb"));
delete ptr;
}

TEST_F(UT_CtxtUpdateLocation,UpdateGsmData_Func) {
CtxtUpdateLocation::l_Version=3;
MmConfigReader::m_Version=3;
CtxtUpdateLocation::l_OpCode=2;
RetrieveSubsVLRData *ptr=new RetrieveSubsVLRData;
ptr->m_OpCode=2;
EXPECT_NO_THROW(UpdateGsmData(1));
delete ptr;
}

TEST_F(UT_CtxtUpdateLocation,UpdateGsmData_Two_Func) {
UpdateVLRData *p= new UpdateVLRData;
l_updv3.VlrCap_Camel4=true;
l_updv3.VlrCap_Camel3=true;
l_updv3.VlrCap_Camel2=true;
l_updv3.VlrCap_Camel1=true;
l_updv3.soLSA=true;
l_updv3.SuperCharge=true;
l_updv3.LongFTN=true;
l_updv3.lcsCS4=true;
l_updv3.lcsCS3=true;
l_updv3.lcsCS2=true;
l_updv3.lcsCS1=true;
p->m_SuppLCS=1;
l_updv3.c4_oCSI=true;
l_updv3.c4_dCSI=true;
l_updv3.c4_vtCSI=true;
l_updv3.c4_tCSI=true;
l_updv3.c4_mtsCSI=true;
l_updv3.c4_mgCSI=true;
CtxtUpdateLocation::l_Version=3;
MmConfigReader::m_Version=3;
CtxtUpdateLocation::l_OpCode=57;
RetrieveSubsVLRData *ptr=new RetrieveSubsVLRData;
ptr->m_OpCode=57;
EXPECT_NO_THROW(UpdateGsmData(1));
delete ptr;
delete p;
}

TEST_F(UT_CtxtUpdateLocation,UpdateGsmData_l_Version_Two_Func) {
CtxtUpdateLocation::l_Version=2;
MmConfigReader::m_Version=2;
CtxtUpdateLocation::l_OpCode=2;
RetrieveSubsVLRData *ptr=new RetrieveSubsVLRData;
ptr->m_OpCode=2;
EXPECT_NO_THROW(UpdateGsmData(1));
delete ptr;
}

TEST_F(UT_CtxtUpdateLocation,UpdateGsmData_l_Version_Two_Two_Func) {
CtxtUpdateLocation::l_Version=2;
MmConfigReader::m_Version=2;
CtxtUpdateLocation::l_OpCode=57;
RetrieveSubsVLRData *ptr=new RetrieveSubsVLRData;
ptr->m_OpCode=57;
EXPECT_NO_THROW(UpdateGsmData(1));
delete ptr;
}

TEST_F(UT_CtxtUpdateLocation,UpdateGsmData_l_Version_One_Func) {
CtxtUpdateLocation::l_Version=1;
MmConfigReader::m_Version=1;
CtxtUpdateLocation::l_OpCode=57;
RetrieveSubsVLRData *ptr=new RetrieveSubsVLRData;
ptr->m_OpCode=57;
EXPECT_NO_THROW(UpdateGsmData(1));
delete ptr;
}


TEST_F(UT_CtxtUpdateLocation,UpdateUpdFailData_Func) {
CtxtUpdateLocation::m_TrapReqd=true;
UpdateVLRData *ptr= new UpdateVLRData();
ptr->m_UserDlgId=1;
CtxtUpdateLocation::l_Version=3;
MmConfigReader::m_Version=3;
CtxtUpdateLocation::m_FirstUlFlag=1;
CtxtUpdateLocation::m_MsisdnAllocStatus=1;
MmConfigReader::m_Dealloc_Msisdn_On_Fail=1;
g_MmConfigReaderObj->m_Dealloc_Msisdn_On_Fail=1;
CtxtUpdateLocation::m_fIsd=true;
EXPECT_NO_THROW(UpdateUpdFailData(1));
delete ptr;
}

TEST_F(UT_CtxtUpdateLocation,UpdateUpdFailData_Two_Func) {
CtxtUpdateLocation::m_TrapReqd=true;
UpdateVLRData *ptr= new UpdateVLRData();
ptr->m_UserDlgId=1;
CtxtUpdateLocation::l_Version=2;
MmConfigReader::m_Version=3;
CtxtUpdateLocation::m_FirstUlFlag=1;
CtxtUpdateLocation::m_MsisdnAllocStatus=1;
MmConfigReader::m_Dealloc_Msisdn_On_Fail=1;
g_MmConfigReaderObj->m_Dealloc_Msisdn_On_Fail=1;
CtxtUpdateLocation::m_fIsd=true;
EXPECT_NO_THROW(UpdateUpdFailData(1));
delete ptr;
}

TEST_F(UT_CtxtUpdateLocation,UpdateUpdFailData_One_Func) {
CtxtUpdateLocation::m_TrapReqd=true;
UpdateVLRData *ptr= new UpdateVLRData();
ptr->m_UserDlgId=1;
CtxtUpdateLocation::l_Version=1;
MmConfigReader::m_Version=3;
CtxtUpdateLocation::m_FirstUlFlag=1;
CtxtUpdateLocation::m_MsisdnAllocStatus=1;
MmConfigReader::m_Dealloc_Msisdn_On_Fail=1;
g_MmConfigReaderObj->m_Dealloc_Msisdn_On_Fail=1;
CtxtUpdateLocation::m_fIsd=true;
EXPECT_NO_THROW(UpdateUpdFailData(1));
delete ptr;
}

/****************************************************************/

TEST_F(UT_CtxtUpdateLocation,updLocResV1_Func) {
g_MmConfigReaderObj->m_GT_Transtlation_Reqd=1;
EXPECT_NO_THROW(updLocResV1(1));
}


TEST_F(UT_CtxtUpdateLocation,updLocResV2_Func) {
g_MmConfigReaderObj->m_GT_Transtlation_Reqd=1;
EXPECT_NO_THROW(updLocResV2(1));
}

TEST_F(UT_CtxtUpdateLocation,updLocResV2_Two_Func) {
g_MmConfigReaderObj->m_GT_Transtlation_Reqd=1;
ISDData *ptr=new ISDData;
ptr->m_IsdResp_With_Unsupp_Service_Rcvd=true;
EXPECT_NO_THROW(updLocResV2(1));
delete ptr;
}

TEST_F(UT_CtxtUpdateLocation,updLocResV3_Func) {
g_MmConfigReaderObj->m_GT_Transtlation_Reqd=1;
CtxtUpdateLocation::m_fIsd=false;
EXPECT_NO_THROW(updLocResV3(1));
}

TEST_F(UT_CtxtUpdateLocation,updLocResV3_else_Func) {
g_MmConfigReaderObj->m_GT_Transtlation_Reqd=1;
CtxtUpdateLocation::m_fIsd=true;
ISDData *ptr=new ISDData;
ptr->m_IsdResp_With_Unsupp_Service_Rcvd=true;
EXPECT_NO_THROW(updLocResV3(1));
delete ptr;
}


/************************************************************************/

TEST_F(UT_CtxtUpdateLocation,RsdRespV3_Func) {
g_MmConfigReaderObj->m_GT_Transtlation_Reqd=1;
EXPECT_NO_THROW(RsdRespV3(1,1));
}

TEST_F(UT_CtxtUpdateLocation,RsdRespV3_else_Func) {
g_MmConfigReaderObj->m_GT_Transtlation_Reqd=0;
ISDData *ptr=new ISDData;
ptr->m_IsdResp_With_Unsupp_Service_Rcvd=true;
EXPECT_NO_THROW(RsdRespV3(1,1));
delete ptr;
}

TEST_F(UT_CtxtUpdateLocation,RsdRespV2_Func) {
g_MmConfigReaderObj->m_GT_Transtlation_Reqd=1;
EXPECT_NO_THROW(RsdRespV2(1,1));
}

TEST_F(UT_CtxtUpdateLocation,RsdRespV2_else_Func) {
g_MmConfigReaderObj->m_GT_Transtlation_Reqd=0;
ISDData *ptr=new ISDData;
ptr->m_IsdResp_With_Unsupp_Service_Rcvd=true;
EXPECT_NO_THROW(RsdRespV2(1,1));
delete ptr;
}

/*************************************************************************/

TEST_F(UT_CtxtUpdateLocation,HandleError_Func) {
CtxtUpdateLocation::l_Version=3;
EXPECT_NO_THROW(HandleError(1));
}

TEST_F(UT_CtxtUpdateLocation,HandleError_Two_Func) {
CtxtUpdateLocation::l_Version=2;
EXPECT_NO_THROW(HandleError(1));
}

TEST_F(UT_CtxtUpdateLocation,HandleError_else_Func) {
CtxtUpdateLocation::l_Version=1;
EXPECT_NO_THROW(HandleError(1));
}

/***********************************************************************/
/*
//already commented
TEST_F(UT_CtxtUpdateLocation,processDBData_Func) {
RetrieveSubsVLRData obj;
obj.m_AlocType=1;
obj.m_partType=1;
EXPECT_FALSE(processDBData(1,&obj));
}

TEST_F(UT_CtxtUpdateLocation,processDBData_Two_Func) {
RetrieveSubsVLRData obj;
obj.m_AlocType=2;
obj.m_partType=2;
obj.m_RoamIND=1;
obj.m_AssumeCap1Support=1;
obj.m_LiCount=2;
obj.m_CWCount=2;
obj.m_ssCount=2;
obj.m_CFCount=2;
obj.m_CBCount=2;
EXPECT_FALSE(processDBData(1,&obj));
}

TEST_F(UT_CtxtUpdateLocation,processDBData_Three_Func) {
RetrieveSubsVLRData obj;
obj.m_AlocType=3;
obj.m_partType=2;
obj.m_RoamIND=1;
obj.m_AssumeCap1Support=1;
obj.m_LiCount=2;
obj.m_CWCount=2;
obj.m_ssCount=2;
obj.m_CFCount=2;
obj.m_CBCount=2;
EXPECT_FALSE(processDBData(1,&obj));
}

TEST_F(UT_CtxtUpdateLocation,processDBData_Four_Func) {
RetrieveSubsVLRData obj;
obj.m_AlocType=4;
obj.m_partType=2;
obj.m_RoamIND=1;
obj.m_AssumeCap1Support=1;
obj.m_LiCount=2;
obj.m_CWCount=2;
obj.m_ssCount=2;
obj.m_CFCount=2;
obj.m_CBCount=2;
EXPECT_FALSE(processDBData(1,&obj));
}

TEST_F(UT_CtxtUpdateLocation,processDBData_Five_Func) {
RetrieveSubsVLRData obj;
obj.m_AlocType=5;
obj.m_partType=2;
obj.m_RoamIND=1;
obj.m_AssumeCap1Support=1;
obj.m_LiCount=2;
obj.m_CWCount=2;
obj.m_ssCount=2;
obj.m_CFCount=2;
obj.m_CBCount=2;
EXPECT_FALSE(processDBData(1,&obj));
}
*/
/****************************************************/

TEST_F(UT_CtxtUpdateLocation,sendCheckSS_Func) {
CtxtUpdateLocation::l_Version=3;
EXPECT_NO_THROW(sendCheckSS());
}

TEST_F(UT_CtxtUpdateLocation,sendCheckSS_Two_Func) {
CtxtUpdateLocation::l_Version=2;
EXPECT_NO_THROW(sendCheckSS());
}

TEST_F(UT_CtxtUpdateLocation,sendCheckSS_one_Func) {
CtxtUpdateLocation::l_Version=1;
EXPECT_NO_THROW(sendCheckSS());
}

/**************************************************/

TEST_F(UT_CtxtUpdateLocation,RetErrorV1_Func) {
EXPECT_NO_THROW(RetErrorV1(1,2));
}

TEST_F(UT_CtxtUpdateLocation,RetErrorV1_Three_Func) {
EXPECT_NO_THROW(RetErrorV1(1,3));
}

TEST_F(UT_CtxtUpdateLocation,RetErrorV1_Five_Func) {
EXPECT_NO_THROW(RetErrorV1(1,5));
}

TEST_F(UT_CtxtUpdateLocation,RetErrorV1_Six_Func) {
EXPECT_NO_THROW(RetErrorV1(1,6));
}

TEST_F(UT_CtxtUpdateLocation,RetErrorV1_default_Func) {
EXPECT_NO_THROW(RetErrorV1(1,0));
}

/*********************************************************/

TEST_F(UT_CtxtUpdateLocation,RetErrorV2_Func) {
EXPECT_NO_THROW(RetErrorV2(1,2));
}

TEST_F(UT_CtxtUpdateLocation,RetErrorV2_Three_Func) {
EXPECT_NO_THROW(RetErrorV2(1,3));
}

TEST_F(UT_CtxtUpdateLocation,RetErrorV2_Five_Func) {
EXPECT_NO_THROW(RetErrorV2(1,5));
}

TEST_F(UT_CtxtUpdateLocation,RetErrorV2_Six_Func) {
EXPECT_NO_THROW(RetErrorV2(1,6));
}

TEST_F(UT_CtxtUpdateLocation,RetErrorV2_default_Func) {
EXPECT_NO_THROW(RetErrorV2(1,0));
}

/*************************************************************/

TEST_F(UT_CtxtUpdateLocation,RetErrorV3_Func) {
EXPECT_NO_THROW(RetErrorV3(1,2));
}

TEST_F(UT_CtxtUpdateLocation,RetErrorV3_Three_Func) {
EXPECT_NO_THROW(RetErrorV3(1,3));
}

TEST_F(UT_CtxtUpdateLocation,RetErrorV3_Five_Func) {
EXPECT_NO_THROW(RetErrorV3(1,5));
}

TEST_F(UT_CtxtUpdateLocation,RetErrorV3_Six_Func) {
EXPECT_NO_THROW(RetErrorV3(1,6));
}

TEST_F(UT_CtxtUpdateLocation,RetErrorV3_default_Func) {
EXPECT_NO_THROW(RetErrorV3(1,0));
}

/*************************************************************/

/*TEST_F(UT_CtxtUpdateLocation,startProcessing_Func) {
CtxtUpdateLocation::m_DataString="aa";
InterModuleData ab;
strcpy(ab.m_Parameters,"aaaaaaaaaaaaaaaaaaaaaa");
bool p_DeleteFlag=true;
EXPECT_FALSE(startProcessing(&ab,p_DeleteFlag));
}*/

/*TEST_F(UT_CtxtUpdateLocation,startProcessing_Two_Func) {
InterModuleData ab;
//char *l_check = NULL;
//char **ptr=(new(*l_check));
//char **ptr=&l_check;
**ptr="aaaaaa";
strcpy(ab.m_Parameters,":::::::");
CtxtUpdateLocation::m_DataString="VLR_NUM";
bool p_DeleteFlag=true;
EXPECT_FALSE(startProcessing(&ab,p_DeleteFlag));
}*/

/*TEST_F(UT_CtxtUpdateLocation,startProcessing_Three_Func) {
InterModuleData ab;
strcpy(ab.m_Parameters,":::::::");
CtxtUpdateLocation::m_DataString="IMSI";
bool p_DeleteFlag=true;
EXPECT_FALSE(startProcessing(&ab,p_DeleteFlag));
}*/

/*TEST_F(UT_CtxtUpdateLocation,startProcessing_Four_Func) {
InterModuleData ab;
strcpy(ab.m_Parameters,":::::::");
CtxtUpdateLocation::m_DataString="1111111111111111111111111111111111111111111";
bool p_DeleteFlag=true;
EXPECT_FALSE(startProcessing(&ab,p_DeleteFlag));
}*/

/******************************************************/
TEST_F(UT_CtxtUpdateLocation,CheckParametersRSDV2_Func) {
IMAP2_RestoreDataArg IMAP2_RestoreDataArg;
CtxtUpdateLocation::l_updv2.imsi[15+1]="IMSILEN";
strcpy(IMAP2_RestoreDataArg.imsi.value,"IMSILEN");
IMAP2_RestoreDataArg.imsi.length=8;
//strcpy(IMAP2_IMSI.value,"IMSILEN");
EXPECT_FALSE(CheckParametersRSDV2(1,&IMAP2_RestoreDataArg));
}

TEST_F(UT_CtxtUpdateLocation,CheckParametersRSDV3_Func) {
IMAP3_RestoreDataArg IMAP3_RestoreDataArg;
CtxtUpdateLocation::l_updv3.imsi[15+1]="IMSILEN";
strcpy(IMAP3_RestoreDataArg.imsi.value,"IMSILEN");
IMAP3_RestoreDataArg.imsi.length=8;
EXPECT_FALSE(CheckParametersRSDV3(1,&IMAP3_RestoreDataArg));
}

TEST_F(UT_CtxtUpdateLocation,CheckParametersV3_Func) {
IMAP3_UpdateLocationArg IMAP3_UpdateLocationArg;
CtxtUpdateLocation::l_updv3.imsi[15+1]="IMSILEN";
strcpy(IMAP3_UpdateLocationArg.imsi.value,"aaaaaaaaaaaaaa");
IMAP3_UpdateLocationArg.imsi.length=1;
EXPECT_FALSE(CheckParametersV3(1,&IMAP3_UpdateLocationArg));
}

TEST_F(UT_CtxtUpdateLocation,CheckParametersV2_Func) {
IMAP2_UpdateLocationArg IMAP2_UpdateLocationArg;
CtxtUpdateLocation::l_updv2.imsi[15+1]="IMSILEN";
strcpy(IMAP2_UpdateLocationArg.imsi.value,"aaaaaaaaaaaaa");
IMAP2_UpdateLocationArg.imsi.length=1;
EXPECT_FALSE(CheckParametersV2(1,&IMAP2_UpdateLocationArg));
}

/****************************************************************/
/*
//NEW seg
TEST_F(UT_CtxtUpdateLocation,processDBData_Func) {
RetrieveSubsVLRData l_rsd;
l_rsd.m_MWD=1;
l_rsd.m_AlocType=0;
l_rsd.m_partType=1;
CtxtUpdateLocation::GenProfile.l_nwAccMode=0;
CtxtUpdateLocation::l_roamInd=1;
CtxtUpdateLocation::GenProfile.l_ocsiPid=0;
CtxtUpdateLocation::GenProfile.l_sscsiPid=0;
CtxtUpdateLocation::GenProfile.l_tifcsiPid=0;
CtxtUpdateLocation::GenProfile.l_dcsiPid=0;
CtxtUpdateLocation::GenProfile.l_moscsiPid=0;
CtxtUpdateLocation::GenProfile.l_vtcsiPid=0;
CtxtUpdateLocation::GenProfile.l_mtscsiPid=0;
CtxtUpdateLocation::m_fIsd=false;
CtxtUpdateLocation::m_SubsData[25][33]="aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
CtxtUpdateLocation::GenProfile.l_subsStatus=1;
l_rsd.m_CWCount=1;
l_rsd.m_ssCount=1;
l_rsd.m_CFCount=1;
g_spd=new GlobalData;
//g_spd=new SubsProfileData;
//g_spdPtr=new SubsProfileData;
EXPECT_NE(processDBData(1,&l_rsd),100);
}
*/

#undef private

