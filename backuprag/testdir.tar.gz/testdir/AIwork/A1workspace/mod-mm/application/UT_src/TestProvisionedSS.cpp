#define private public

#include"gtest.h"
#include<ProvisionedSS.h>
#include <ProvisionedSS.h>
#include <Logger.h>
#include <MmConfigReader.h>
#include <AsnCodec.h>
#include <Utilities.h>
#include <CommonDefines.h>
#include<OMAP3.h>
class UT_provisionedSS: public testing::Test , public provisionedSS, public MmConfigReader
{public:
UT_provisionedSS()
{
}
~UT_provisionedSS()
{
}
};


TEST_F(UT_provisionedSS,formFwdSS3_CFWD_UNCON_Func) {
OMAP3_InsertSubscriberDataArg ab;
provisionedSS *ptr=new provisionedSS;
ptr->CFWD_STATE=0;
ptr->cfuSsCode=1;
ptr->val=0;
ab.bit_mask=4;
g_MmConfigReaderObj=new MmConfigReader;
g_MmConfigReaderObj->m_IsdLen=1;
EXPECT_NE(formFwdSS3(&ab),1);
delete ptr;
}

TEST_F(UT_provisionedSS,formFwdSS3_CFWD_UNCON_else_Func) {
OMAP3_InsertSubscriberDataArg ab;
provisionedSS::CFWD_STATE=0;
provisionedSS::cfuSsCode=1;
provisionedSS::val=1;
ab.bit_mask=4;
g_MmConfigReaderObj=new MmConfigReader;
g_MmConfigReaderObj->m_IsdLen=1;
EXPECT_NE(formFwdSS3(&ab),NULL);
}

TEST_F(UT_provisionedSS,formFwdSS3_CFWD_BUSY_Func) {
OMAP3_InsertSubscriberDataArg ab;
provisionedSS *ptr=new provisionedSS;
ptr->CFWD_STATE=1;
//ptr->cfbSsCode=1;
provisionedSS::cfbSsCode=1;
ptr->val=1;
ab.bit_mask=4;
g_MmConfigReaderObj=new MmConfigReader;
g_MmConfigReaderObj->m_IsdLen=1;
EXPECT_NE(formFwdSS3(&ab),0);
delete ptr;
}

TEST_F(UT_provisionedSS,formFwdSS3_CFWD_NOTREACH_Func) {
OMAP3_InsertSubscriberDataArg ab;
provisionedSS *ptr=new provisionedSS;
ptr->CFWD_STATE=2;
//ptr->cfnrcSsCode=2;
provisionedSS::cfnrcSsCode=1;
ptr->val=1;
ab.bit_mask=4;
g_MmConfigReaderObj=new MmConfigReader;
g_MmConfigReaderObj->m_IsdLen=1;
EXPECT_NE(formFwdSS3(&ab),0);
delete ptr;
}

TEST_F(UT_provisionedSS,formFwdSS3_CFWD_NOREPLY_Func) {
OMAP3_InsertSubscriberDataArg ab;
provisionedSS *ptr= new provisionedSS;
ptr->CFWD_STATE=3;
//ptr->cfnrySsCode=3;
provisionedSS::cfnrySsCode=1;
ptr->val=1;
ab.bit_mask=4;
g_MmConfigReaderObj=new MmConfigReader;
g_MmConfigReaderObj->m_IsdLen=1;
EXPECT_NE(formFwdSS3(&ab),0);
delete ptr;
}

TEST_F(UT_provisionedSS,formFwdSS3_CALL_DEF_Func) {
OMAP3_InsertSubscriberDataArg ab;
provisionedSS::CFWD_STATE=4;
provisionedSS::cdSsCode=4;
provisionedSS::val=1;
ab.bit_mask=4;
g_MmConfigReaderObj=new MmConfigReader;
g_MmConfigReaderObj->m_IsdLen=1;
EXPECT_NE(formFwdSS3(&ab),1);
}

TEST_F(UT_provisionedSS,formFwdSS3_CALL_DEF_Two_Func) {
OMAP3_InsertSubscriberDataArg ab;
provisionedSS *ptr=new provisionedSS;
ptr->CFWD_STATE=4;
provisionedSS::cdSsCode=1;
ptr->val=1;
ab.bit_mask=4;
g_MmConfigReaderObj=new MmConfigReader;
g_MmConfigReaderObj->m_IsdLen=1;
EXPECT_NE(formFwdSS3(&ab),0);
delete ptr;
}


TEST_F(UT_provisionedSS,formFwdSS3_DEF_Func) {
OMAP3_InsertSubscriberDataArg ab;
provisionedSS::CFWD_STATE=5;
provisionedSS::cfuSsCode=5;
provisionedSS::val=1;
ab.bit_mask=4;
g_MmConfigReaderObj=new MmConfigReader;
g_MmConfigReaderObj->m_IsdLen=1;
EXPECT_NE(formFwdSS3(&ab),15);
}

/***********************************************************/

TEST_F(UT_provisionedSS,formCbSS3_CB_BOAC_Func) {
OMAP3_InsertSubscriberDataArg ab;
provisionedSS *ptr=new provisionedSS;
ptr->CB_STATE=0;
//ptr->boacSsCode=1;
ptr->val=0;
provisionedSS::boacSsCode=1;
EXPECT_NE(formCbSS3(&ab),0);
delete ptr;
}

TEST_F(UT_provisionedSS,formCbSS3_CB_BOIC_Func) {
OMAP3_InsertSubscriberDataArg ab;
provisionedSS *ptr=new provisionedSS;
ptr->CB_STATE=1;
//ptr->boicSsCode=1;
provisionedSS::boicSsCode=1;
ptr->val=0;
EXPECT_NE(formCbSS3(&ab),0);
delete ptr;
}

TEST_F(UT_provisionedSS,formCbSS3_CB_BOIHC_Func) {
OMAP3_InsertSubscriberDataArg ab;
provisionedSS *ptr=new provisionedSS;
ptr->CB_STATE=2;
//ptr->boihcSsCode=1;
provisionedSS::boihcSsCode=1;
ptr->val=0;
EXPECT_NE(formCbSS3(&ab),0);
delete ptr;
}

TEST_F(UT_provisionedSS,formCbSS3_DEFA_Func) {
OMAP3_InsertSubscriberDataArg ab;
provisionedSS *ptr=new provisionedSS;
ptr->CB_STATE=5;
EXPECT_NE(formCbSS3(&ab),1);
delete ptr;
}



/***********************************************************/

TEST_F(UT_provisionedSS,formSsSS3_Func) {
OMAP3_InsertSubscriberDataArg ab;
provisionedSS::val=0;
ab.bit_mask=4;
provisionedSS::SsCount=0;
EXPECT_FALSE(formSsSS3(&ab));
}


/*****************************************************************/

TEST_F(UT_provisionedSS,formGenSS3_Func) {
OMAP3_InsertSubscriberDataArg ab;
provisionedSS *ptr=new provisionedSS;
ptr->m_GenSsCount=2;
ptr->SsCount=2;
g_MmConfigReaderObj=new MmConfigReader;
g_MmConfigReaderObj->m_IsdLen=1;
EXPECT_NE(formGenSS3(&ab,10),20);
delete ptr;
}

TEST_F(UT_provisionedSS,formGenSS3_TwoFunc) {
OMAP3_InsertSubscriberDataArg ab;
provisionedSS::m_GenSsCount=2;
provisionedSS::SsCount=2;
g_MmConfigReaderObj=new MmConfigReader;
g_MmConfigReaderObj->m_IsdLen=1;
EXPECT_NE(formGenSS3(&ab,1),400);
}

TEST_F(UT_provisionedSS,formGenSS3_Three_Func) {
OMAP3_InsertSubscriberDataArg ab;
provisionedSS::m_GenSsCount=2;
provisionedSS::SsCount=2;
g_MmConfigReaderObj=new MmConfigReader;
g_MmConfigReaderObj->m_IsdLen=10000;
SsSubsRest[45]="111111111111";
SsBCode[45]="111111111111111111";
SsBType[45]="222222222222222222222";
EXPECT_NE(formGenSS3(&ab,4),4000);
}


/**********************************************************/

TEST_F(UT_provisionedSS,formEmSS3_Func) {
OMAP3_InsertSubscriberDataArg ab;
g_MmConfigReaderObj=new MmConfigReader;
g_MmConfigReaderObj->m_IsdLen=10000;
EXPECT_NE(formEmSS3(&ab),1000000);
}

/****************************************************************/

TEST_F(UT_provisionedSS,formMcSS_Func) {
OMAP3_InsertSubscriberDataArg ab;
ab.bit_mask=4;
provisionedSS::MCSsStatus=4;
EXPECT_NO_THROW(formMcSS(&ab));
}

TEST_F(UT_provisionedSS,formMcSS_else_Func) {
OMAP3_InsertSubscriberDataArg ab;
ab.bit_mask=4;
provisionedSS::MCSsStatus=2;
EXPECT_NO_THROW(formMcSS(&ab));
}

/******************************************************************/

TEST_F(UT_provisionedSS,formCfuSS3_Func) {
OMAP3_InsertSubscriberDataArg ab;
ab.bit_mask=4;
provisionedSS::cfuSsCount=2;
provisionedSS::m_AllOGCallsBarresPresent=true;
provisionedSS::cfuSsStatus[30]="7777777777777777777";
EXPECT_NO_THROW(formCfuSS3(&ab));
}

TEST_F(UT_provisionedSS,formCfuSS3_if_Func) {
OMAP3_InsertSubscriberDataArg ab;
ab.bit_mask=4;
provisionedSS::cfuSsCount=2;
provisionedSS::m_AllOGCallsBarresPresent=true;
provisionedSS::cfuSsStatus[30]="1111111111";
EXPECT_NO_THROW(formCfuSS3(&ab));
}

TEST_F(UT_provisionedSS,formCfuSS3_if_Two_Func) {
OMAP3_InsertSubscriberDataArg ab;
ab.bit_mask=4;
provisionedSS::cfuSsCount=2;
m_AllOGCallsBarresPresent=true;provisionedSS::cfuSsStatus[30]="7777777777777777777777777777777777777777777777777";
provisionedSS:cfuBType[30]="111111111111111111111111111111111111111111111";
EXPECT_NO_THROW(formCfuSS3(&ab));
}


TEST_F(UT_provisionedSS,formCfuSS3_if_Three_Func) {
OMAP3_InsertSubscriberDataArg ab;
ab.bit_mask=4;
provisionedSS::cfuSsCount=2;
m_AllOGCallsBarresPresent=true;provisionedSS::cfuSsStatus[30]="7777777777777777777777777777777777777777777777777";
provisionedSS:cfuBType[30]="7777777777777777777777777777777777777777777777777777";
EXPECT_NO_THROW(formCfuSS3(&ab));
}

TEST_F(UT_provisionedSS,formCfuSS3_if_Four_Func) {
OMAP3_InsertSubscriberDataArg ab;
ab.bit_mask=4;
provisionedSS *ptr=new provisionedSS;
ptr->cfuSsCount=2;
ptr->m_AllOGCallsBarresPresent=true;
ptr->cfuSsStatus[30]="7777777777777777777777777777777777777777777777777";
ptr->cfuBType[30]="7777777777777777777777777777777777777777777777777777";
EXPECT_NO_THROW(formCfuSS3(&ab));
delete ptr;
}

TEST_F(UT_provisionedSS,formCfuSS3_if_Five_Func) {
OMAP3_InsertSubscriberDataArg ab;
ab.bit_mask=4;
provisionedSS mm;
mm.cfuSsCount=2;
//mm.m_AllOGCallsBarresPresent=true;
mm.cfuSsStatus[30]="7777777777777777777777777777777777777777777777777";
mm.cfuBType[30]="7777777777777777777777777777777777777777777777777777";
EXPECT_NO_THROW(formCfuSS3(&ab));
//delete ptr;
}


/*************************************************************/

TEST_F(UT_provisionedSS,formCfbSS3_Func) {
OMAP3_InsertSubscriberDataArg ab;
ab.bit_mask=4;
provisionedSS::cfbSsCount=2;
provisionedSS::cfbBType[30]="000000";
provisionedSS::m_AllOGCallsBarresPresent=true;
provisionedSS::cfbSsStatus[30]="77777777777";
provisionedSS::cfbFTN[30][20]="44444444";
provisionedSS::cfbFTS[30][22]="111111";
provisionedSS::cfbOPTN[30]="33333";
provisionedSS::cfbLFTN[30][20]="4445667";
EXPECT_NO_THROW(formCfbSS3(&ab));
}

TEST_F(UT_provisionedSS,formCfbSS3_Two_Func) {
OMAP3_InsertSubscriberDataArg ab;
ab.bit_mask=4;
provisionedSS::cfbSsCount=2;
provisionedSS::cfbBType[30]="11111111";
provisionedSS::m_AllOGCallsBarresPresent=true;
provisionedSS::cfbSsStatus[30]="0000000";
provisionedSS::cfbFTN[30][20]="44444444";
provisionedSS::cfbFTS[30][22]="111111";
provisionedSS::cfbOPTN[30]="33333";
provisionedSS::cfbLFTN[30][20]="4445667";
EXPECT_NO_THROW(formCfbSS3(&ab));
}

TEST_F(UT_provisionedSS,formCfbSS3_Three_Func) {
OMAP3_InsertSubscriberDataArg ab;
ab.bit_mask=4;
provisionedSS::cfbSsCount=10;
m_AllOGCallsBarresPresent=true;
provisionedSS::cfbSsStatus[30]="7777777777777777777777777777777777777777777777777777777777777777";
provisionedSS::cfbBType[30]="77777777777777777777777777777777777777777777777777777777";
provisionedSS::cfbFTN[30][20]="444444444444444444444444444444444444444444444444";
provisionedSS::cfbFTS[30][22]="111111111111111111111111111111111111111111111111";
provisionedSS::cfbOPTN[30]="333333333333333333333333333333333333333333333333333333";
provisionedSS::cfbLFTN[30][20]="4445667444444444444444444444444444444444444444444444";
EXPECT_NO_THROW(formCfbSS3(&ab));
}

TEST_F(UT_provisionedSS,formCfbSS3_Four_Func) {
OMAP3_InsertSubscriberDataArg ab;
ab.bit_mask=4;
provisionedSS::cfbSsCount=10;
m_AllOGCallsBarresPresent=true;
provisionedSS::cfbSsStatus[30]="7777777777777777777777777777777777777777777777777777777777777777";
provisionedSS::cfbBType[30]="111111111111111111111111111111111111111111111111111111111111111111111";
provisionedSS::cfbFTN[30][20]="444444444444444444444444444444444444444444444444";
provisionedSS::cfbFTS[30][22]="111111111111111111111111111111111111111111111111";
provisionedSS::cfbOPTN[30]="333333333333333333333333333333333333333333333333333333";
provisionedSS::cfbLFTN[30][20]="4445667444444444444444444444444444444444444444444444";
EXPECT_NO_THROW(formCfbSS3(&ab));
}

/*********************************************************/

TEST_F(UT_provisionedSS,formCfbSS2_Func) {
OMAP2_InsertSubscriberDataArg ab;
ab.bit_mask=4;
provisionedSS::cfnrySsCount=2;
provisionedSS::m_AllOGCallsBarresPresent=true;
provisionedSS::cfnrySsStatus[30]="7777777";
provisionedSS::cfnryBType[30]="11111111";
provisionedSS::cfnryFTN[30][20]="1111111";
provisionedSS::cfnryFTS[30][22]="22222222";
provisionedSS::cfnryOPTN[30]="999999";
EXPECT_NO_THROW(formCfbSS2(&ab));
}

TEST_F(UT_provisionedSS,formCfbSS2_Two_Func) {
OMAP2_InsertSubscriberDataArg ab;
ab.bit_mask=4;
provisionedSS::cfnrySsCount=2;
provisionedSS::m_AllOGCallsBarresPresent=true;
provisionedSS::cfnrySsStatus[30]="111111111";
provisionedSS::cfnryBType[30]="11111111";
provisionedSS::cfnryFTN[30][20]="1111111";
provisionedSS::cfnryFTS[30][22]="22222222";
provisionedSS::cfnryOPTN[30]="999999";
EXPECT_NO_THROW(formCfbSS2(&ab));
}

TEST_F(UT_provisionedSS,formCfbSS2_Three_Func) {
OMAP2_InsertSubscriberDataArg ab;
ab.bit_mask=4;
provisionedSS::cfbSsCount=10;
m_AllOGCallsBarresPresent=true;
provisionedSS::cfbSsStatus[30]="777777777777777777777777777777777";
provisionedSS::cfbBType[30]="1111111111111111111111111111111111111111";
provisionedSS::cfbFTN[30][20]="aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
provisionedSS::cfbFTS[30][22]="bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb";
provisionedSS::cfbOPTN[30]="rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr";
EXPECT_NO_THROW(formCfbSS2(&ab));
}

/*******************************************************************/

TEST_F(UT_provisionedSS,formCfnrySS3_Func) {
OMAP3_InsertSubscriberDataArg ab;
ab.bit_mask=4;
provisionedSS::cfnrySsCount=2;
m_AllOGCallsBarresPresent=true;
provisionedSS::cfnrySsStatus[30]="77777777777777777777777777777777777777";
provisionedSS::cfnryBType[30]="1111111111111111111111111111111111111111";
provisionedSS::cfnryFTN[30][20]="7777777777777777777777777777777777777";
provisionedSS::cfnryFTS[30][22]="77777777777777777777777777777777777777";
provisionedSS::cfnryOPTN[30]="77777777777777777777777777777777777777777";
provisionedSS::cfnryNRT[30]="777777777777777777777777777777777777777";
provisionedSS::cfnryLFTN[30][20]="777777777777777777777777777777";
EXPECT_NO_THROW(formCfnrySS3(&ab));
}

/*********************************************************************/

TEST_F(UT_provisionedSS,formCfnrcSS3_Func) {
OMAP3_InsertSubscriberDataArg ab;
ab.bit_mask=4;
provisionedSS::cfnrcSsCount=2;
provisionedSS::m_AllOGCallsBarresPresent=true;
provisionedSS::cfnrcSsStatus[30]="77777777777777777777777777777777777777";
provisionedSS::cfnrcBType[30]="1111111111111111111111111111111111111111";
provisionedSS::cfnrcFTN[30][20]="7777777777777777777777777777777777777";
provisionedSS::cfnrcFTS[30][22]="77777777777777777777777777777777777777";
provisionedSS::cfnrcLFTN[30][20]="77777777777777777777777777777777777777777";
EXPECT_NO_THROW(formCfnrcSS3(&ab));
}

/*****************************************************************/

TEST_F(UT_provisionedSS,formCdSS3_Func) {
OMAP3_InsertSubscriberDataArg ab;
ab.bit_mask=4;
provisionedSS::cdSsCount=2;
provisionedSS::m_AllOGCallsBarresPresent=true;
provisionedSS::cdSsStatus[30]="aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
provisionedSS::cdBType[30]="1111111111111111111111111111111111111";
provisionedSS::cdFTN[30][20]="aaaaaaaaaaaaa";
provisionedSS::cdFTS[30][22]="bbbbbbbbbbbbb";
provisionedSS::cdOPTN[30]="cccccccccccccccc";
provisionedSS::cdLFTN[30][20]="hhhhhhhhhhhhhhhh";
EXPECT_NO_THROW(formCdSS3(&ab));
}

/****************************************************************/

TEST_F(UT_provisionedSS,formboaSS3_Func) {
OMAP3_InsertSubscriberDataArg ab;
ab.bit_mask=4;
provisionedSS::boacCount=5;
provisionedSS::boacBType[30]="111111111111111111111111111111111111111";
EXPECT_NO_THROW(formboaSS3(&ab));
}

/***********************************************/

TEST_F(UT_provisionedSS,formboicSS3_Func) {
OMAP3_InsertSubscriberDataArg ab;
ab.bit_mask=4;
provisionedSS::boicCount=2;
provisionedSS::boicBType[30]="1111111111111111111111111111111111";
EXPECT_NO_THROW(formboicSS3(&ab));
}

/*******************************************************/

TEST_F(UT_provisionedSS,formboihcSS3_Func) {
OMAP3_InsertSubscriberDataArg ab;
ab.bit_mask=4;
provisionedSS::boihcCount=2;
provisionedSS::boihcBType[30]="11111111111111111111111111111111111111";
EXPECT_NO_THROW(formboihcSS3(&ab));
}

/**********************************************************/

TEST_F(UT_provisionedSS,formEmlSS3_Func) {
OMAP3_InsertSubscriberDataArg ab;
ab.bit_mask=4;
provisionedSS::ESsStatus=7;
EXPECT_NO_THROW(formEmlSS3(&ab));
}

TEST_F(UT_provisionedSS,formEmlSS3_Two_Func) {
OMAP3_InsertSubscriberDataArg ab;
ab.bit_mask=1;
provisionedSS::ESsStatus=7;
EXPECT_NO_THROW(formEmlSS3(&ab));
}

/***************************************************************/

TEST_F(UT_provisionedSS,formCfuSS2_Func) {
OMAP2_InsertSubscriberDataArg ab;
ab.bit_mask=4;
provisionedSS::cfuSsCount=10;
provisionedSS::m_AllOGCallsBarresPresent=true;
provisionedSS::cfuSsStatus[30]="777777777777777777777777";
provisionedSS::cfuBType[30]="111111111111111111111111111";
EXPECT_NO_THROW(formCfuSS2(&ab));
}

/**************************************************************/

TEST_F(UT_provisionedSS,formCfnrySS2_Func) {
OMAP2_InsertSubscriberDataArg ab;
ab.bit_mask=4;
provisionedSS::cfnrySsCount=10;
m_AllOGCallsBarresPresent=true;
provisionedSS::cfnrySsStatus[30]="7777777777777777777777777777777777777777";
provisionedSS::cfnryBType[30]="111111111111111111111111111111111111111111111111111";
provisionedSS::cfnryFTN[30][20]="aaaaaaaaaaaaaaaaaaaaaaa";
provisionedSS::cfnryFTS[30][22]="wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww";
provisionedSS::cfnryOPTN[30]="qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq";
EXPECT_NO_THROW(formCfnrySS2(&ab));
}

/*************************************************************/

TEST_F(UT_provisionedSS,formCfnrcSS2_Func) {
OMAP2_InsertSubscriberDataArg ab;
ab.bit_mask=4;
provisionedSS::cfnrcSsCount=10;
m_AllOGCallsBarresPresent=true;
provisionedSS::cfnrcSsStatus[30]="77777777777777777777777777777777777777777777";provisionedSS::cfnrcBType[30]="1111111111111111111111111111111111111111111111";
provisionedSS::cfnrcFTN[30][20]="2222222222222222222222222222222222";
provisionedSS::cfnrcFTS[30][22]="1111111111111111111111111111111111";
provisionedSS::cfnrcOPTN[30]="3333333333333333333333333333333333333";
EXPECT_NO_THROW(formCfnrcSS2(&ab));
}

/**************************************************************/

TEST_F(UT_provisionedSS,formCdSS2_Func) {
OMAP2_InsertSubscriberDataArg ab;
ab.bit_mask=4;
provisionedSS::cdSsCount=10;
m_AllOGCallsBarresPresent=true;
cdSsStatus[30]="77777777777777777777777777777777777777777777777777777";
cdBType[30]="11111111111111111111111111111111111111111111111111111111";
cdFTN[30][20]="2222222222222222222222222222222222222";
cdFTS[30][22]="333333333333333333333333333333333333333333";
EXPECT_NO_THROW(formCdSS2(&ab));
}

/*****************************************************************/

TEST_F(UT_provisionedSS,formboaSS2_Func) {
OMAP2_InsertSubscriberDataArg ab;
ab.bit_mask=4;
provisionedSS::boacCount=5;
boacBType[30]="111111111111111111111111111111111111111";
EXPECT_NO_THROW(formboaSS2(&ab));
}

/**************************************************************/

TEST_F(UT_provisionedSS,formboicSS2_Func) {
OMAP2_InsertSubscriberDataArg ab;
ab.bit_mask=4;
boicCount=5;
boicBType[30]="111111111111111111111111111111111111";
EXPECT_NO_THROW(formboicSS2(&ab));
}

/*********************************************************/

TEST_F(UT_provisionedSS,formboihcSS2_Func) {
OMAP2_InsertSubscriberDataArg ab;
ab.bit_mask=4;
boihcCount=10;
boihcBType[30]="1111111111111111111111111111111111111111111111111";
EXPECT_NO_THROW(formboihcSS2(&ab));
}

/***********************************************************/

TEST_F(UT_provisionedSS,formGenSS2_Func) {
OMAP2_InsertSubscriberDataArg ab;
ab.bit_mask=4;
SsCount=10;
SsSubsRest[30]="111111111111111111111111111111111111111";
SsBType[30]="1111111111111111111111111111111111111111";
EXPECT_NO_THROW(formGenSS2(&ab));
}

/*****************************************************************/

TEST_F(UT_provisionedSS,formCfuSS1_Func) {
OMAP1_SS_InfoList ab;
//ab.bit_mask=4;
cfuSsCount=4;
m_AllOGCallsBarresPresent=true;
cfuSsStatus[30]="77777777777777777777777777777777777777777777";
cfuBType[30]="1111111111111111111111111111111111111111111111";
EXPECT_NO_THROW(formCfuSS1(ab));
}

/*******************************************************************/

TEST_F(UT_provisionedSS,formCdSS1_Func) {
OMAP1_SS_InfoList ab;
cdSsCount=10;
m_AllOGCallsBarresPresent=true;
cdSsStatus[30]="7777777777777777777777777777777777777777777";
cdBType[30]="11111111111111111111111111111111111111111111";
EXPECT_NO_THROW(formCdSS1(ab));
}

/*************************************************************/

TEST_F(UT_provisionedSS,formCfbSS1_Func) {
OMAP1_SS_InfoList ab;
cfbSsCount=10;
m_AllOGCallsBarresPresent=true;
cfbSsStatus[30]="7777777777777777777777777777777777777777";
cfbBType[30]="111111111111111111111111111111111111111";
cfbFTN[30][20]="1111111111111111111111111111111111111";
cfbOPTN[30]="222222222222222222222222222222222222";
EXPECT_NO_THROW(formCfbSS1(ab));
}

/********************************************************/

TEST_F(UT_provisionedSS,formCfnrySS1_Func) {
OMAP1_SS_InfoList ab;
cfnrySsCount=10;
m_AllOGCallsBarresPresent=true;
cfnrySsStatus[30]="777777777777777777777777777777777777777777";
cfnryBType[30]="111111111111111111111111111111";
cfnryFTN[32][20]="111111111111111111111111111";
cfnryOPTN[30]="111111111111111111111111111111111";
EXPECT_NO_THROW(formCfnrySS1(ab));
}

/************************************************************/

TEST_F(UT_provisionedSS,formCfnrcSS1_Func) {
OMAP1_SS_InfoList ab;
cfnrcSsCount=10;
m_AllOGCallsBarresPresent=true;
cfnrcSsStatus[30]="77777777777777777777777777777777777777777777777";
cfnrcBType[30]="11111111111111111111111111111111";
cfnrcFTN[30][20]="777777777777777777777777777777777777";
cfnrcOPTN[30]="7777777777777777777777777777777777777777";
EXPECT_NO_THROW(formCfnrcSS1(ab));
}

/*************************************************************/

TEST_F(UT_provisionedSS,formboaSS1_Func) {
OMAP1_SS_InfoList ab;
boacCount=10;
boacBType[30]="111111111111111111111111111111111";
EXPECT_NO_THROW(formboaSS1(ab));
}

/*****************************************************************/

TEST_F(UT_provisionedSS,formboicSS1_Func) {
OMAP1_SS_InfoList ab;
boicCount=11;
boicBType[3]="11111111111111111111111111";
EXPECT_NO_THROW(formboicSS1(ab));
}

/*****************************************************************/

TEST_F(UT_provisionedSS,formboihcSS1_Func) {
OMAP1_SS_InfoList ab;
boihcCount=10;
boihcBType[30]="1111111111111111111111111111111";
EXPECT_NO_THROW(formboihcSS1(ab));
}

TEST_F(UT_provisionedSS,formboihcSS1_Two_Func) {
OMAP1_SS_InfoList  ab;
provisionedSS *ptr=new provisionedSS;
ptr->boihcCount=1;
ptr->boihcBType[30]="11111111111111111";
EXPECT_NO_THROW(formboihcSS1(ab));
delete ptr;
}


/********************************************************************/

TEST_F(UT_provisionedSS,formGenSS1_Func) {
OMAP1_SS_InfoList ab;
SsCount=10;
SsStatus[30]="1111111111111111111111111111111111111111111111111";
ab.count=1;
EXPECT_NE(formGenSS1(ab),NULL);
}

/*********************************************************************/

TEST_F(UT_provisionedSS,formFwdSS1_Func) {
OMAP1_InsertSubscriberDataArg  ab;
g_MmConfigReaderObj=new MmConfigReader;
g_MmConfigReaderObj->m_IsdLen=1;
provisionedSS::CFWD_STATE=0;
provisionedSS::cfuSsCode=1;
EXPECT_NE(formFwdSS1(&ab),400);
}

TEST_F(UT_provisionedSS,formFwdSS1_CFWD_BUSY_Func) {
OMAP1_InsertSubscriberDataArg  ab;
g_MmConfigReaderObj=new MmConfigReader;
g_MmConfigReaderObj->m_IsdLen=1;
provisionedSS::CFWD_STATE=1;
provisionedSS::cfbSsCode=1;
EXPECT_NE(formFwdSS1(&ab),400);
}

TEST_F(UT_provisionedSS,formFwdSS1_CFWD_BUSY_Func1) {
OMAP1_InsertSubscriberDataArg  ab;
g_MmConfigReaderObj=new MmConfigReader;
g_MmConfigReaderObj->m_IsdLen=1;
provisionedSS::CFWD_STATE=1;
provisionedSS::cfbSsCode=1;
EXPECT_NE(formFwdSS1(&ab),400);
}

TEST_F(UT_provisionedSS,formFwdSS1_CFWD_NOTREACH_Func) {
OMAP1_InsertSubscriberDataArg  ab;
g_MmConfigReaderObj=new MmConfigReader;
g_MmConfigReaderObj->m_IsdLen=1;
provisionedSS::CFWD_STATE=2;
provisionedSS::cfnrcSsCode=1;
EXPECT_NE(formFwdSS1(&ab),400);
}

TEST_F(UT_provisionedSS,formFwdSS1_CFWD_NOREPLY_Func) {
OMAP1_InsertSubscriberDataArg  ab;
g_MmConfigReaderObj=new MmConfigReader;
g_MmConfigReaderObj->m_IsdLen=1;
provisionedSS::CFWD_STATE=3;
provisionedSS::cfnrySsCode=1;
EXPECT_NE(formFwdSS1(&ab),400);
}

TEST_F(UT_provisionedSS,formFwdSS1_CALL_DEF_Func) {
OMAP1_InsertSubscriberDataArg  ab;
g_MmConfigReaderObj=new MmConfigReader;
g_MmConfigReaderObj->m_IsdLen=1;
provisionedSS::CFWD_STATE=4;
provisionedSS::cdSsCode=1;
EXPECT_NE(formFwdSS1(&ab),400);
}

TEST_F(UT_provisionedSS,formFwdSS1_DEF_Func) {
OMAP1_InsertSubscriberDataArg  ab;
g_MmConfigReaderObj=new MmConfigReader;
g_MmConfigReaderObj->m_IsdLen=1;
provisionedSS::CFWD_STATE=5;
EXPECT_EQ(formFwdSS1(&ab),0);
}

/*************************************************************/

TEST_F(UT_provisionedSS,formCbSS1_CB_BOAC_Func) {
OMAP1_InsertSubscriberDataArg  ab;
g_MmConfigReaderObj=new MmConfigReader;
g_MmConfigReaderObj->m_IsdLen=-1;
provisionedSS::CB_STATE=0;
provisionedSS::boacSsCode=1;
provisionedSS::val=0;
EXPECT_NE(formFwdSS1(&ab),400);
}

TEST_F(UT_provisionedSS,formCbSS1_CB_BOIC_Func) {
OMAP1_InsertSubscriberDataArg  ab;
g_MmConfigReaderObj=new MmConfigReader;
g_MmConfigReaderObj->m_IsdLen=-1;
provisionedSS::CB_STATE=1;
provisionedSS::boicSsCode=1;
provisionedSS::val=0;
EXPECT_NE(formFwdSS1(&ab),400);
}

#undef private


