#define private public
#include <iostream>
#include "gtest.h"
#include <CtxtUpdateGPRSLocation.h>
#include <CtxtCancelLocation.h>
#include <CommonDefines.h>
#include <stdio.h>
#include <ServiceCoordinator.h>
#include <Logger.h>
#include <DbActiveObject.h>
#include <MmSgsnDbQueries.h>
#include <ISDData.h>
#include <MmConfigReader.h>
#include <SgsnCamelSubsinfo.h>
#include <GprsSubscriptioninfo.h>
#include <DataUnion.h>
#include <Utilities.h>
#include <AsnCodec.h>
#include <SubsProfileData.h>
#include <SnmpInterface.h>
#include <DiameterConstants.h>
#include <ExtendedServiceCoordinator.h>
#include <CommonData.h>
#include <MapConstants.h>
#include <SubsProfileData.h>
#include <IMAP1.h>
#include <MmDbQueries.h>
#include <IMAP2.h>
#include <IMAP3.h>
#include <ConfigReader.h>
#include <GlobalData.h>
#include <ProvisionedSS.h>
class UT_CtxtUpdateGPRSLocation: public testing::Test , public CtxtUpdateGPRSLocation , public MmConfigReader , public provisionedSS
{public: 
UT_CtxtUpdateGPRSLocation()
{
}
~UT_CtxtUpdateGPRSLocation()
{
}
};

class UT_MapUserError
{public:
UT_MapUserError()
{
}
~UT_MapUserError()
{
}
};

class UT_RetrieveSubsSGSNData
{public:
UT_RetrieveSubsSGSNData()
{
}
~UT_RetrieveSubsSGSNData()
{
}
};

class UT_CtxtCancelLocation
{public:
UT_CtxtCancelLocation()
{
}
~UT_CtxtCancelLocation()
{
}
};

class UT_UpdateSGSNData
{public:
UT_UpdateSGSNData()
{
}
~UT_UpdateSGSNData()
{
}
};

class UT_SubsProfileData
{public:
UT_SubsProfileData()
{
}
~UT_SubsProfileData()
{
}
};

class UT_InterModuleData
{public:
UT_InterModuleData()
{
}
~UT_InterModuleData()
{
}
};

class UT_ISDData
{public:
UT_ISDData()
{
}
~UT_ISDData()
{
}
};

class UT_GlobalData
{public:
UT_GlobalData()
{
}
~UT_GlobalData()
{
}
};

TEST_F(UT_CtxtUpdateGPRSLocation,processMessage_MAP_CMN_OPEN_IND_Func) {
g_IMEI_EncrFlag=1;
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=202;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateGPRSLocation,processMessage_MAP_CMN_DELIMITER_IND_Func) {
g_IMEI_EncrFlag=1;
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=208;
CtxtUpdateGPRSLocation::m_ProvErrRcvd=true;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateGPRSLocation,processMessage_MAP_CMN_CLOSE_IND_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=206;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}


TEST_F(UT_CtxtUpdateGPRSLocation,processMessage_MAP_CMN_U_ABORT_IND_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=210;
p_MsgPtr.m_UserDlgId=1;
bool p_DeleteFlag=true;
g_MmConfigReaderObj=new MmConfigReader;
g_MmConfigReaderObj->m_Dealloc_Msisdn_On_Fail=1;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}


TEST_F(UT_CtxtUpdateGPRSLocation,processMessage_MAP_CMN_P_ABORT_IND_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=212;
p_MsgPtr.m_UserDlgId=1;
bool p_DeleteFlag=true;
g_MmConfigReaderObj=new MmConfigReader;
g_MmConfigReaderObj->m_Dealloc_Msisdn_On_Fail=1;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}


TEST_F(UT_CtxtUpdateGPRSLocation,processMessage_MAP_CMN_P_ABORT_IND_Two_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=212;
p_MsgPtr.m_UserDlgId=1;
bool p_DeleteFlag=true;
g_MmConfigReaderObj=new MmConfigReader;
g_MmConfigReaderObj->m_Dealloc_Msisdn_On_Fail=1;
CtxtUpdateGPRSLocation::l_state=3;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}


TEST_F(UT_CtxtUpdateGPRSLocation,processMessage_MAP_CMN_NOTICE_IND_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=213;
p_MsgPtr.m_UserDlgId=1;
bool p_DeleteFlag=true;
g_MmConfigReaderObj=new MmConfigReader;
g_MmConfigReaderObj->m_Dealloc_Msisdn_On_Fail=1;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateGPRSLocation,processMessage_MAP_CMN_NOTICE_IND_Two_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=213;
p_MsgPtr.m_UserDlgId=1;
bool p_DeleteFlag=true;
g_MmConfigReaderObj=new MmConfigReader;
g_MmConfigReaderObj->m_Dealloc_Msisdn_On_Fail=1;
CtxtUpdateGPRSLocation::l_state=3;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateGPRSLocation,processMessage_MAP_MSG_TYPE_COMMON_default_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=200;
p_MsgPtr.m_UserDlgId=1;
bool p_DeleteFlag=true;
g_MmConfigReaderObj=new MmConfigReader;
g_MmConfigReaderObj->m_Dealloc_Msisdn_On_Fail=1;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}


TEST_F(UT_CtxtUpdateGPRSLocation,processMessage_MAP_SPEC_EVENT_INDICATION_case3_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=2;
p_MsgPtr.m_OpCode=23;
p_MsgPtr.m_Version=3;
p_MsgPtr.m_allocatedFlag=false;
int *ptr=new int;
*ptr=1;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
delete ptr;
}

TEST_F(UT_CtxtUpdateGPRSLocation,processMessage_MAP_SPEC_EVENT_INDICATION_case3_else_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=2;
p_MsgPtr.m_OpCode=23;
p_MsgPtr.m_Version=3;
p_MsgPtr.m_allocatedFlag=true;
int *ptr=new int;
*ptr=1;
bool p_DeleteFlag=true;
EXPECT_FALSE(processMessage(&p_MsgPtr,p_DeleteFlag));
delete ptr;
}

TEST_F(UT_CtxtUpdateGPRSLocation,processMessage_MAP_SPEC_EVENT_INDICATION_default_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=2;
p_MsgPtr.m_OpCode=0;
p_MsgPtr.m_Version=3;
p_MsgPtr.m_allocatedFlag=false;
int *ptr=new int;
*ptr=1;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
delete ptr;
}

TEST_F(UT_CtxtUpdateGPRSLocation,processMessage_MAP_SPEC_EVENT_RESULT_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=3;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateGPRSLocation,processMessage_MAP_OP_CODE_activateTraceMode_case1_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=4;
p_MsgPtr.m_OpCode=50;
bool p_DeleteFlag=true;
EXPECT_FALSE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateGPRSLocation,processMessage_MAP_MSG_TYPE_SPECIFIC_default_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=0;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateGPRSLocation,processMessage_MAP_OP_CODE_insertSubscriberData_default_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=4;
p_MsgPtr.m_OpCode=07;
p_MsgPtr.m_Version=0;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}


//--------------------------------------------------------------------------------------------------------

/*
TEST_F(UT_CtxtUpdateGPRSLocation,processMessage_MAP_OP_CODE_insertSubscriberData_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=4;
p_MsgPtr.m_OpCode=07;
p_MsgPtr.m_Version=3;
p_MsgPtr.m_allocatedFlag=true;
p_MsgPtr.m_isd.ProcessIsdResV3=true;
bool p_DeleteFlag=true;
EXPECT_FALSE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateGPRSLocation,processMessage_MAP_OP_CODE_insertSubscriberData_else_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=4;
p_MsgPtr.m_OpCode=07;
p_MsgPtr.m_Version=3;
p_MsgPtr.m_allocatedFlag=true;
p_MsgPtr.m_isd.ProcessIsdResV3=false;
bool p_DeleteFlag=true;
EXPECT_FALSE(processMessage(&p_MsgPtr,p_DeleteFlag));
}
*/


//-------------------------------------------------------------------------------------------------------------


TEST_F(UT_CtxtUpdateGPRSLocation,processMessage_MAP_SPEC_EVENT_USER_ERROR_Func) {
MapUserError p_MsgPtr(1, MAP_ERROR_callBarred, MAP_V3, NULL);
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=5;
p_MsgPtr.m_ErrorCode=1;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateGPRSLocation,processMessage_MAP_SPEC_EVENT_PROV_ERROR_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=6;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtUpdateGPRSLocation,processMessage_MSG_TYPE_DB_m_usd_Func) {
UpdateSGSNData p_MsgPtr;
p_MsgPtr.m_MsgType=2;
p_MsgPtr.m_ErrorCode=1;
p_MsgPtr.m_ErrorMsg[300]="aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
p_MsgPtr.m_DbQueryRes=1;
CtxtCancelLocation *ptr=new CtxtCancelLocation;
ptr->m_callState=7;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
delete ptr;
}

TEST_F(UT_CtxtUpdateGPRSLocation,processMessage_MSG_TYPE_DB_m_usd_else_Func) {
UpdateSGSNData p_MsgPtr;
p_MsgPtr.m_MsgType=2;
p_MsgPtr.m_ErrorCode=1;
p_MsgPtr.m_ErrorMsg[300]="aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
p_MsgPtr.m_DbQueryRes=0;
CtxtCancelLocation *ptr=new CtxtCancelLocation;
ptr->m_callState=7;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
delete ptr;
}

TEST_F(UT_CtxtUpdateGPRSLocation,processMessage_MSG_TYPE_DB_m_usdf_Func) {
UpdateSGSNData p_MsgPtr;
p_MsgPtr.m_ErrorCode=1;
p_MsgPtr.m_ErrorMsg[300]="aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
p_MsgPtr.m_DbQueryRes=1;
CtxtCancelLocation *ptr=new CtxtCancelLocation;
ptr->m_callState=8;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
delete ptr;
}

TEST_F(UT_CtxtUpdateGPRSLocation,processMessage_MSG_TYPE_DB_m_usdf_else_Func) {
UpdateSGSNData p_MsgPtr;
p_MsgPtr.m_ErrorCode=1;
p_MsgPtr.m_ErrorMsg[300]="aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
p_MsgPtr.m_DbQueryRes=0;
CtxtCancelLocation *ptr=new CtxtCancelLocation;
ptr->m_callState=8;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
delete ptr;
}


//----------------------------------------------------------------------

/*
TEST_F(UT_CtxtUpdateGPRSLocation,CheckParameters_Func) {
IMAP3_UpdateGprsLocationArg IMAP3_UpdateGprsLocationArg;
CtxtUpdateGPRSLocation::l_upgv3.imsi[15+1]="IMSILEN";
strcpy(IMAP3_UpdateGprsLocationArg.imsi.value,"aaaaaaaaaaaaaa");
IMAP3_UpdateGprsLocationArg.imsi.length=1;
EXPECT_FALSE(CheckParameters(1,&IMAP3_UpdateGprsLocationArg));
}
*/

//----------------------------------------------------------------------

TEST_F(UT_CtxtUpdateGPRSLocation,UpdateGprsData_Func) {
CtxtUpdateGPRSLocation::l_Version=3;
MmConfigReader::m_Version=3;
RetrieveSubsSGSNData *ptr=new RetrieveSubsSGSNData;
EXPECT_NO_THROW(UpdateGprsData(1));
delete ptr;
}

TEST_F(UT_CtxtUpdateGPRSLocation,UpdateGprsData_Two_Func) {
UpdateSGSNData *p= new UpdateSGSNData;
l_upgv3.SgsnCap_Camel1=true;
l_upgv3.SgsnCap_Camel2=true;
l_upgv3.SgsnCap_Camel3=true;
l_upgv3.SgsnCap_Camel4=true;
l_upgv3.soLSA=true;
l_upgv3.lcsCS1=true;
l_upgv3.lcsCS2=true;
l_upgv3.lcsCS3=true;
l_upgv3.lcsCS4=true;
p->m_SupLCS=1;
l_upgv3.c4_oCSI=true;
l_upgv3.c4_dCSI=true;
l_upgv3.c4_vtCSI=true;
l_upgv3.c4_tCSI=true;
l_upgv3.c4_mtsmsCSI=true;
l_upgv3.c4_mgCSI=true;
l_upgv3.c4_psiCSI=true;
l_upgv3.smsCBSInd=true;
CtxtUpdateGPRSLocation::l_Version=3;
MmConfigReader::m_Version=3;
RetrieveSubsSGSNData *ptr=new RetrieveSubsSGSNData;
EXPECT_NO_THROW(UpdateGprsData(1));
delete ptr;
delete p;
}


TEST_F(UT_CtxtUpdateGPRSLocation,UpdateFailData_Func) {
CtxtUpdateGPRSLocation::m_TrapReqd=true;
UpdateSGSNData *ptr= new UpdateSGSNData();
ptr->m_UserDlgId=1;
MmConfigReader::m_Version=3;
CtxtUpdateGPRSLocation::m_FirstUlFlag=1;
CtxtUpdateGPRSLocation::m_MsisdnAllocStatus=1;
MmConfigReader::m_Dealloc_Msisdn_On_Fail=1;
g_MmConfigReaderObj->m_Dealloc_Msisdn_On_Fail=1;
EXPECT_NO_THROW(UpdateFailData(1));
delete ptr;
}


//---------------------------------------------------------------------------



TEST_F(UT_CtxtUpdateGPRSLocation,upgLocRes_Func) {
g_MmConfigReaderObj->m_GT_Transtlation_Reqd=1;
EXPECT_NO_THROW(upgLocRes(1));
}



TEST_F(UT_CtxtUpdateGPRSLocation,RetrieveData_Func) {
g_MmConfigReaderObj->m_Multi_Imsi_Reqd=true;
RetrieveSubsSGSNData *ptr = new RetrieveSubsSGSNData();
EXPECT_NO_THROW(RetrieveData(1,"aaaaaaaaaaaaaaaaaaaaaaaa","bbbbbbbbbbbbbbbbbbbb"));
delete ptr;
}


TEST_F(UT_CtxtUpdateGPRSLocation,UpgLoc_Func) {
CtxtUpdateGPRSLocation::GenProfile.l_subsStatus=1;
CtxtUpdateGPRSLocation::l_GenOdb=1;
CtxtUpdateGPRSLocation::l_PlmnOdb=1;
CtxtUpdateGPRSLocation::l_upgv3.SgsnCap_Camel4=true;
CtxtUpdateGPRSLocation::GenProfile.l_gcsiPid=0;
CtxtUpdateGPRSLocation::GenProfile.l_mgcsiPid=0;
CtxtUpdateGPRSLocation::GenProfile.l_mtscsiPid=1;
CtxtUpdateGPRSLocation::l_upgv3.c4_mtsmsCSI=false;
CtxtUpdateGPRSLocation::GprsProfile.l_TraceFlag=0;
EXPECT_NE(UpgLoc(1),1);
}

TEST_F(UT_CtxtUpdateGPRSLocation,UpgLocCont_Func) {
EXPECT_NO_THROW(UpgLocCont(1));
}


TEST_F(UT_CtxtUpdateGPRSLocation,startISDV3_Func) {
EXPECT_NO_THROW(startISDV3(1));
}


//--------------------------------------------------------------

TEST_F(UT_CtxtUpdateGPRSLocation,RetError1_Func) {
EXPECT_NO_THROW(RetError(1,1));
}

TEST_F(UT_CtxtUpdateGPRSLocation,RetError2_Func) {
EXPECT_NO_THROW(RetError(1,8));
}

TEST_F(UT_CtxtUpdateGPRSLocation,RetError3_Func) {
EXPECT_NO_THROW(RetError(1,9));
}

TEST_F(UT_CtxtUpdateGPRSLocation,RetError4_Func) {
EXPECT_NO_THROW(RetError(1,34));
}

TEST_F(UT_CtxtUpdateGPRSLocation,RetError5_Func) {
EXPECT_NO_THROW(RetError(1,36));
}

TEST_F(UT_CtxtUpdateGPRSLocation,RetError6_Func) {
EXPECT_NO_THROW(RetError(1,6));
}

TEST_F(UT_CtxtUpdateGPRSLocation,RetError7_Func) {
EXPECT_NO_THROW(RetError(1,7));
}

TEST_F(UT_CtxtUpdateGPRSLocation,RetError_Default_Func) {
EXPECT_NO_THROW(RetError(1,0));
}


TEST_F(UT_CtxtUpdateGPRSLocation,ContinueReq_Func) {
EXPECT_NO_THROW(ContinueReq(1));
}




#undef private
















































