#ifndef __HSSCOMMDEFINES_H__
#define __HSSCOMMDEFINES_H__

#include <math.h>
using namespace std;


#define F1_ODB_ALL_APN                                                  0x00000001
#define F1_ODB_HPLMN_APN                                                0x00000002
#define F1_ODB_VPLMN_APN                                                0x00000004
#define F1_ODB_ALL_OG                                                   0x00000008
#define F1_ODB_ALL_InternationalOG                                      0x00000010
#define F1_ODB_ALL_InternationalOG_NotToHPLMNCountry                    0x00000020
#define F1_ODB_ALL_InterzonalOG                                         0x00000040
#define F1_ODB_ALL_InterzonalOG_NotToHPLMNCountry                       0x00000080
#define F1_ODB_ALL_InterzonalOG_And_InternationalOG_NotToHPLMNCountry   0x00000100
#define F1_RegSub                                                       0x00000200
#define F1_Trace                                                        0x00000400
#define F1_LCS_ALL_PrivExcep                                            0x00000800
#define F1_LCS_Universal                                                0x00001000
#define F1_LCS_CALL_SessionRelated                                      0x00002000
#define F1_LCS_CALL_SessionUnrelated                                    0x00004000
#define F1_LCS_PLMNOperator                                             0x00008000
#define F1_LCS_ServiceType                                              0x00010000
#define F1_LCS_ALL_MOLRSS                                               0x00020000
#define F1_LCS_BasicSelfLocation                                        0x00040000
#define F1_LCS_AutonomousSelfLocation                                   0x00080000
#define F1_LCS_TransferToThirdParty                                     0x00100000
#define F1_SMMOPP                                                       0x00200000
#define F1_BarringOutgoingCalls                                         0x00400000
#define F1_BAOC                                                         0x00800000
#define F1_BOIC                                                         0x01000000
#define F1_BOICExHC                                                     0x02000000
#define F1_UEReachabilityNotification                                   0x04000000
#define F1_TADS_Data_Retrieval                                          0x08000000
#define F1_State_LocationInformationRetrieval                           0x10000000
#define F1_Partial_Purge                                                0x20000000
#define F1_Local_Time_Zone_Retrieval                                    0x40000000
#define F1_Additional_MSISDN                                            0x80000000


#define F2_SMS_in_MME                                                   0x00000001
#define F2_SMS_in_SGSN                                                  0x00000002
#define F2_DiaLCS_ALL_PrivExcep                                         0x00000004
#define F2_DiaLCS_Universal                                             0x00000008
#define F2_DiaLCS_CALL_SessionRelated                                   0x00000010
#define F2_DiaLCS_CALL_SessionUnrelated                                 0x00000020
#define F2_DiaLCS_PLMNOperator                                          0x00000040
#define F2_DiaLCS_ServiceType                                           0x00000080
#define F2_DiaLCS_ALL_MOLRSS                                            0x00000100
#define F2_DiaLCS_BasicSelfLocation                                     0x00000200
#define F2_DiaLCS_AutonomousSelfLocation                                0x00000400
#define F2_DiaLCS_TransferToThirdParty                                  0x00000800
#define F2_EXTENDED_FEATURES                                            0xFFFFF000

#define HSS_IMSI_LEN                             20
#define HSS_IMEISV_LEN                             16
#define HSS_STNSR_LEN                            20
#define HSS_MSISDN_LEN                           20 
#define HSS_VPLMNID_LEN                          3
#define HSS_MME_HOST_LEN                         100 
#define HSS_MME_REALM_LEN                        100 
#define HSS_3GPP2_MEID_LEN                       8
#define HSS_SGSN_NUMBER_LEN                      20
#define HSS_GMLC_ADDRESS_LEN                     34 
#define HSS_3GPPCHARGINGCHAR_LEN                 2
#define HSS_MME_NUMBER_MT_SMS_LEN                20 
#define HSS_IMEI_SOFTWARE_VERSION_LEN            2

#define HSS_ORIGIN_HOST_LEN                      100
#define HSS_ORIGIN_REALM_LEN                     100
#define HSS_MIP6AI_HA_ADDR_LEN                   39
#define HSS_SERVICE_SELECTION_LEN                200
#define HSS_VISITED_NETWORK_ID_LEN               100
#define HSS_MIP6AI_HA_DEST_HOST_LEN              100
#define HSS_MIP6AI_HA_DEST_REALM_LEN             100

#define HSS_ERRORMSG_LEN                         200

#endif /* __HSSCOMMDEFINES_H__ */



