#ifndef __CONTEXT_LTE_NOTIFY_H
#define __CONTEXT_LTE_NOTIFY_H

#include <ContextBase.h>
#include <Msg.h>
#include "Utilities.h"
#include <DiameterConstants.h>
#include <DiametriqInterface.h>
#include <S6a_r10AVP.h>
#include <LteMm2DbQueries.h>
#include <DiameterMessages.h>
using namespace diameter::base;

class CtxtLteNotifyRequest : public ContextBase
{
	private:
      int m_DlgId;
      char m_PgwLinkPrefix[101];
      int m_NORFlags, m_AlertReason;
      unsigned int m_SessionIndex;
      char m_SessionId[MAX_SESSION_ID_SIZE+1];
      NotifyDbData *m_dbreq;

	public:
		CtxtLteNotifyRequest();
		~CtxtLteNotifyRequest();

      bool handleNotify(Msg *p_MsgPtr);
      bool handleDBResponse(Msg *p_MsgPtr);
      bool sendNOA(NotifyDbData* p_db, EDiameterResultCode p_ResultCode, EDiameterExperimentalResultCode p_ErrCode=DIAM_EXP_RESULT_CODE_UNKNOWN);
      bool processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag);
};



#endif
