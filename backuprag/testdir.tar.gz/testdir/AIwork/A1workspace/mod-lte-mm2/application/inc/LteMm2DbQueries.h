#ifndef __NOTIFY_DB_QUERIES_H
#define __NOTIFY_DB_QUERIES_H

#include <DbQueryMsg.h>
#include <HlrTdrFiller.h>
#include <ConfigReader.h>
#include <SubsProfileData.h>
#include <LteMm2CommonDefines.h>
#include <list>
using namespace std;

class OssCurData
{
   public:
      OssCurData();
      char  m_rowId[30+1];
      char  m_transId[20+1];
      int   m_opCode;
      char  m_transXml[2000+1]; 
};

class NotifyDbData : public DbQueryMsg
{
   public:

      int  m_ApnFlag;
      int  m_Mip6Flag;
      int  m_HsImsFlag;
      int  m_MmeHsValue;
      int  m_UrrpMmeFlag;
      int  m_UeSrvccCapFlag;
      int  m_UeSrvccCapValue;
      int  m_Mip6AiHaFamily1;
      int  m_Mip6AiHaFamily2;

      unsigned int  m_ContextId;

      char m_Imsi[HSS_IMSI_LEN + 1];
      char m_Imei[HSS_IMEISV_LEN + 1];
      char m_MeId[HSS_3GPP2_MEID_LEN + 1];
      char m_MmeHost[HSS_MME_HOST_LEN + 1];
      char m_MmeRealm[HSS_MME_REALM_LEN + 1];
      char m_Mip6AiHaAddr1[HSS_MIP6AI_HA_ADDR_LEN + 1];
      char m_Mip6AiHaAddr2[HSS_MIP6AI_HA_ADDR_LEN + 1];
      char m_VisitedNwId[HSS_VISITED_NETWORK_ID_LEN + 1];
      char m_ServiceSelection[HSS_SERVICE_SELECTION_LEN + 1];
      char m_Mip6AiHaDestHost[HSS_MIP6AI_HA_DEST_HOST_LEN + 1];
      char m_Mip6AiHaDestRealm[HSS_MIP6AI_HA_DEST_REALM_LEN + 1];
      //OUT
      int m_ErrorCode;
      int m_S6aRelease;
      int m_activeLteProfId;
      int m_partnerNetId;
      int m_NOAError;
      int m_imsFlag;
      char m_HssOriginHost[HSS_ORIGIN_HOST_LEN + 1];
      char m_HssOriginRealm[HSS_ORIGIN_REALM_LEN + 1];
      unsigned int m_FeatureList1;
      unsigned int m_FeatureList2;
      
      int m_nwid;
      bool m_ImsApn;
       
      int m_XmlCurCount;
      OssCurData m_OssCurData;

      NotifyDbData();
      bool executeQuery(void*);
      bool postQuery();
};

class ClrDbData : public DbQueryMsg
{
   public:

      int  m_Type;
      int  m_UpdateFlag;
      char m_Imsi[HSS_IMSI_LEN + 1];
      //OUT
      int m_ErrorCode;
      
      ClrDbData();
      bool executeQuery(void*);
      bool postQuery();
};


#endif
