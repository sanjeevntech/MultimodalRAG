#ifndef __CONTEXT_LTE_CANCELLOCATIONREQUEST
#define __CONTEXT_LTE_CANCELLOCATIONREQUEST

#include <ContextBase.h>
#include <Msg.h>
#include "Utilities.h"
#include <DiameterConstants.h>
#include <DiametriqInterface.h>
#include <S6a_r10AVP.h>
#include <LteMm2DbQueries.h>

class CtxtLteCancelLocationRequest : public ContextBase
{
	private:
      string m_OriginHost, m_OriginRealm, m_DestHost, m_DestRealm, m_Imsi, m_NodeType, m_UpdSubsData, m_ReqType;
      int m_CancelType, m_RetryCount, m_ImsiPartType;
      bool m_crossCL;

	public:
		CtxtLteCancelLocationRequest();
		~CtxtLteCancelLocationRequest();

		bool startProcessing(InterModuleData*, bool&);

      bool handleCancelLocationAnswer(Msg *p_MsgPtr);
      bool checkForRetry();
      bool sendCancelLocation();
      bool handleTimeout();
		bool processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag);
};



#endif
