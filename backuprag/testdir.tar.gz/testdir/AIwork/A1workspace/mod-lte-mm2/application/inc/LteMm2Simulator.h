#ifndef __LTE_MM2_SIMULATOR_H
#define __LTE_MM2_SIMULATOR_H

#include <CtxtLteCancelLocationRequest.h>

using namespace diameter::s6a_r10;
using namespace diameter::base;

class NotifySimulator : public ContextBase
{
   public:
      NotifySimulator();
      ~NotifySimulator();

      bool startProcessing();
      bool processMessage(Msg *p_MsgPtr,bool &p_DeleteFlag);
};

class CancelLocationSimulator : public ContextBase
{
    public:
       CancelLocationSimulator();
       ~CancelLocationSimulator();

       bool processMessage(Msg *p_MsgPtr,bool &p_DeleteFlag);
};

#endif
