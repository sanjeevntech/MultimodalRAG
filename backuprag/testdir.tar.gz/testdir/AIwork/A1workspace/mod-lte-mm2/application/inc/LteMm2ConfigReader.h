#ifndef __LET_MM2_CONFIG_READER_H
#define __LET_MM2_CONFIG_READER_H

#include <ConfigReader.h>

class LteMm2ConfigReader: public ConfigReader
{
    private:

    public:
       int m_PdnDynamicDiscoveryFlag;
       int m_CancelLocationRetryCount;
       int m_CancelLocationRetryTimer;

        LteMm2ConfigReader();
        ~LteMm2ConfigReader();

		bool readData();
      void printConfigData(char*);
};


extern LteMm2ConfigReader *g_LteMm2ConfigReaderObj;
extern bool resetStruct(int p_version, int p_pdu, void *p_struct);

#endif
