#include <CtxtLteNotifyRequest.h>
#include <ExtendedServiceCoordinator.h>

#include <stdio.h>
#include <ServiceCoordinator.h>
#include <Logger.h>
#include <DbActiveObject.h>
#include <ConfigReader.h>
#include <LteMm2ConfigReader.h>
#include <DataUnion.h>
#include <Utilities.h>

#include <DiameterMessages.h>
#include <DiameterConstants.h>

//#include <s6a_defines.h>
//#include <s6a_stats.h>
#include <DiametriqInterface.h>
#include <Notify.h>
#include <CtxtLteNotifyRequest.h>

using namespace diameter::s6a_r10;
using namespace diameter::base;

CtxtLteNotifyRequest::CtxtLteNotifyRequest()
{
   m_DlgId = m_NORFlags = m_AlertReason = -1;
   m_SessionIndex = 0;
   memset(&m_PgwLinkPrefix, 0, sizeof(m_PgwLinkPrefix));
   memset(&m_SessionId, 0, sizeof(m_SessionId));
   m_dbreq = NULL;
   TLOG(0,0,"CtxtLteNotifyRequest::CtxtLteNotifyRequest()");
}

CtxtLteNotifyRequest::~CtxtLteNotifyRequest()
{
   TLOG(0,0,"CtxtLteNotifyRequest::~CtxtLteNotifyRequest()");
}

bool CtxtLteNotifyRequest::handleNotify(Msg *p_MsgPtr)
{
   s6a_r10::NotifyRequest l_Tmp(*(diameter::CommandImpl *)((DiameterMsg*)p_MsgPtr)->m_cmd);
   s6a_r10::NotifyRequest *l_NotifyReq = &l_Tmp;

   m_tdr.setString(TDR_INDEX_REMOTE_REALM, (char*)l_NotifyReq->getOriginRealm().value().c_str());
   if(true == l_NotifyReq->containsDestinationHost())
      m_tdr.setString(TDR_INDEX_LOCAL_HOST, (char*)l_NotifyReq->getDestinationHost().value().c_str());
   m_tdr.setString(TDR_INDEX_LOCAL_REALM, (char*)l_NotifyReq->getDestinationRealm().value().c_str());

   m_dbreq = new NotifyDbData();

   if(15 != l_NotifyReq->getUserName().value().size())
   {
      CLOG(0,0,"IMSI length [%d] is not 15. Rejecting", l_NotifyReq->getUserName().value().size());
      sendNOA(NULL, DIAM_RESULT_CODE_UNABLE_TO_COMPLY);
      return false;
   }
   strcpy(m_dbreq->m_Imsi, l_NotifyReq->getUserName().value().c_str());
   LLOG(0,0,"IMSI: %s", m_dbreq->m_Imsi);

   m_tdr.setChar(TDR_INDEX_REQUEST_TYPE, 'I');
   m_tdr.setString(TDR_INDEX_REQUEST_IMSI, m_dbreq->m_Imsi);

   strcpy(m_dbreq->m_MmeHost, l_NotifyReq->getOriginHost().value().c_str());
   LLOG(0,0,"OriginHost: %s", m_dbreq->m_MmeHost);
   strcpy(m_dbreq->m_MmeRealm, l_NotifyReq->getOriginRealm().value().c_str());
   LLOG(0,0,"OriginRealm: %s", m_dbreq->m_MmeRealm);

   if(true == l_NotifyReq->containsTerminalInformation())
   {
      if(true == l_NotifyReq->getTerminalInformation().containsIMEI())
      {
         strcpy(m_dbreq->m_Imei, l_NotifyReq->getTerminalInformation().getIMEI().value().c_str());
         LLOG(0,0,"IMEI : %s", m_dbreq->m_Imei);
         if(strlen(m_dbreq->m_Imei) > 14)
         {
            m_dbreq->m_Imei[14] = 0;
            LLOG(0,0,"IMEI Len [%d] After discarding 15th digit, new IMEI : [%s]", strlen(m_dbreq->m_Imei), m_dbreq->m_Imei);
         }
         m_tdr.setString(TDR_INDEX_IMEI, m_dbreq->m_Imei);
      }
      if(true == l_NotifyReq->getTerminalInformation().containsS6a3GPP2MEID())
      {
         if( HSS_3GPP2_MEID_LEN != l_NotifyReq->getTerminalInformation().getS6a3GPP2MEID().value().size() )
         {
            CLOG(0,0,"3GPP2MEID Length[%d] is not 8 octets. Rejecting.", l_NotifyReq->getTerminalInformation().getS6a3GPP2MEID().value().size());
            sendNOA(NULL, DIAM_RESULT_CODE_UNABLE_TO_COMPLY);
            return false;
         }
         memcpy(m_dbreq->m_MeId, l_NotifyReq->getTerminalInformation().getS6a3GPP2MEID().value().c_str(),
               HSS_3GPP2_MEID_LEN);
         LLOG_HEX(0,0,"ME Id : ", m_dbreq->m_MeId, HSS_3GPP2_MEID_LEN);
         m_tdr.setHex(TDR_INDEX_ULR_MEID, m_dbreq->m_MeId, HSS_3GPP2_MEID_LEN);
      }
      if(true == l_NotifyReq->getTerminalInformation().containsSoftwareVersion())
      {
         char l_Tmp[10+1];
         sprintf(l_Tmp, "%s", l_NotifyReq->getTerminalInformation().getSoftwareVersion().value().c_str());
         strncat(m_dbreq->m_Imei, l_Tmp, 2);
         LLOG(0,0,"Software Version : %s IMEISV: %s", l_Tmp, m_dbreq->m_Imei);
         m_tdr.setString(TDR_INDEX_ULR_SOFTWARE_VERSION, l_Tmp);
      }
   }

   if(true == l_NotifyReq->containsMIP6AgentInfo())
   {
      int l_NumHomeAgentAdd = l_NotifyReq->getMIP6AgentInfo().countMIPHomeAgentAddress();

      if(l_NumHomeAgentAdd > 2)
         LLOG(0,0,"Maximum 2 PGW addresses only allowed. Received [%d] addresses, Using only 2", l_NumHomeAgentAdd);
      
      if(l_NumHomeAgentAdd > 0)
      {
         m_dbreq->m_Mip6Flag = 1;

          Address l_Address = l_NotifyReq->getMIP6AgentInfo().getMIPHomeAgentAddress(0).value();
          m_dbreq->m_Mip6AiHaFamily1 = l_Address.family;
          LLOG(0,0,"PGW IP Family1: %d", m_dbreq->m_Mip6AiHaFamily1);
          m_tdr.setInteger(TDR_INDEX_NOR_MIP6AI_HA_FAMILY1, m_dbreq->m_Mip6AiHaFamily1);

          convertHextoIPV4(l_Address.value, m_dbreq->m_Mip6AiHaAddr1);
          LLOG(0,0,"PGW IP value1: %s", m_dbreq->m_Mip6AiHaAddr1);
         m_tdr.setString(TDR_INDEX_NOR_MIP6AI_HA_ADDR1, m_dbreq->m_Mip6AiHaAddr1);
      }

      if(l_NumHomeAgentAdd > 1)
      {
	 LLOG(0,0,"NOT Supporting IPV6");
         /*Address l_Address = l_NotifyReq->getMIP6AgentInfo().getMIPHomeAgentAddress(1).value();
         m_dbreq->m_Mip6AiHaFamily2 = l_Address.family;
         LLOG(0,0,"PGW IP Family2: %d", m_dbreq->m_Mip6AiHaFamily2);
         m_tdr.setInteger(TDR_INDEX_NOR_MIP6AI_HA_FAMILY2, m_dbreq->m_Mip6AiHaFamily2);

         convertHextoIPV4(l_Address.value, m_dbreq->m_Mip6AiHaAddr2);
         LLOG(0,0,"PGW IP value2: %s", m_dbreq->m_Mip6AiHaAddr2);
         m_tdr.setString(TDR_INDEX_NOR_MIP6AI_HA_ADDR2, m_dbreq->m_Mip6AiHaAddr2);*/
      }

      if(true == l_NotifyReq->getMIP6AgentInfo().containsMIPHomeAgentHost())
      {
         m_dbreq->m_Mip6Flag = 1;
         strcpy(m_dbreq->m_Mip6AiHaDestRealm, l_NotifyReq->getMIP6AgentInfo().getMIPHomeAgentHost().getDestinationRealm().value().c_str());
         LLOG(0,0,"PGW Realm: %s", m_dbreq->m_Mip6AiHaDestRealm);
         m_tdr.setString(TDR_INDEX_NOR_MIP6AI_HA_DEST_REALM, m_dbreq->m_Mip6AiHaDestRealm);

         strcpy(m_dbreq->m_Mip6AiHaDestHost, l_NotifyReq->getMIP6AgentInfo().getMIPHomeAgentHost().getDestinationHost().value().c_str());
         LLOG(0,0,"PGW Host: %s", m_dbreq->m_Mip6AiHaDestHost);
         m_tdr.setString(TDR_INDEX_NOR_MIP6AI_HA_DEST_HOST, m_dbreq->m_Mip6AiHaDestHost);
      }

      if(true == l_NotifyReq->getMIP6AgentInfo().containsMIP6HomeLinkPrefix())
      {
         strcpy(m_PgwLinkPrefix, l_NotifyReq->getMIP6AgentInfo().getMIP6HomeLinkPrefix().value().c_str());
         LLOG(0,0,"PGW LinkPrefix: %s", m_PgwLinkPrefix);
      }
   }

   if(true == l_NotifyReq->containsVisitedNetworkIdentifier())
   {
      strcpy(m_dbreq->m_VisitedNwId, l_NotifyReq->getVisitedNetworkIdentifier().value().c_str());
      LLOG(0,0,"VisitedNwId: %s", m_dbreq->m_VisitedNwId);
      m_tdr.setString(TDR_INDEX_NOR_VISITED_NET_ID, m_dbreq->m_VisitedNwId);
   }

   if(true == l_NotifyReq->containsUESRVCCCapability())
   {
      m_dbreq->m_UeSrvccCapFlag = 1;

      m_dbreq->m_UeSrvccCapValue = l_NotifyReq->getUESRVCCCapability().value();
      LLOG(0,0,"UeSrvcc: %d", m_dbreq->m_UeSrvccCapValue);
      m_tdr.setInteger(TDR_INDEX_ULR_UE_SRVCC_CAP, m_dbreq->m_UeSrvccCapValue);
   }

   if(true == l_NotifyReq->containsContextIdentifier())
   {
      m_dbreq->m_ContextId = l_NotifyReq->getContextIdentifier().value();
      LLOG(0,0,"ContextIdentifier: %d", m_dbreq->m_ContextId);
      m_tdr.setInteger(TDR_INDEX_NOR_CONTEXT_ID, m_dbreq->m_ContextId);
   }

   if(true == l_NotifyReq->containsServiceSelection())
   {
      m_dbreq->m_ApnFlag = 1;

      if(0 == strcasecmp(l_NotifyReq->getServiceSelection().value().c_str(),"ims"))
      {
         LLOG(0,0,"ServiceSelection is IMS APN");
         m_dbreq->m_ImsApn = true;
      }

      strcpy(m_dbreq->m_ServiceSelection, l_NotifyReq->getServiceSelection().value().c_str());
      LLOG(0,0,"APN: %s", m_dbreq->m_ServiceSelection);
      m_tdr.setString(TDR_INDEX_NOR_SERVICE_SELECTION, m_dbreq->m_ServiceSelection);
   }

   if(true == l_NotifyReq->containsNORFlags())
   {
      m_NORFlags = l_NotifyReq->getNORFlags().value();
      LLOG(0,0,"NORFlags: %d", m_NORFlags);
      m_tdr.setInteger(TDR_INDEX_REQUEST_FLAGS, m_NORFlags);

      if(m_NORFlags & 0x0001)
         LLOG(0,0,"Single-Registration-Indication");
      if(m_NORFlags & 0x0002)
         LLOG(0,0,"SGSN area restricted");
      if(m_NORFlags & 0x0004)
      {
         m_dbreq->m_UrrpMmeFlag = 1; // FOR REL 8 HSS
         LLOG(0,0,"Ready for SM from SGSN");
      }
      if(m_NORFlags & 0x0008)
      {
         m_dbreq->m_UrrpMmeFlag = 1;
         LLOG(0,0,"UE Reachable from MME");
      }
      if(m_NORFlags & 0x0010)
         LLOG(0,0,"Reserved bit");
      if(m_NORFlags & 0x0020)
         LLOG(0,0,"UE Reachable from SGSN");
      if(m_NORFlags & 0x0040)
      {
         m_dbreq->m_UrrpMmeFlag = 1;
         LLOG(0,0,"Ready for SM from MME");
      }
      if(m_NORFlags & 0x0080)
      {
         m_dbreq->m_HsImsFlag = 1;
         LLOG(0,0,"Homogeneous Support of IMS Voice Over PS Sessions");
      }
   }

   if(true == l_NotifyReq->containsAlertReason())
   {
      m_dbreq->m_UrrpMmeFlag = 1;

      m_AlertReason = l_NotifyReq->getAlertReason().value();
      LLOG(0,0,"AlertReason: %d", m_AlertReason);
      m_tdr.setInteger(TDR_INDEX_NOR_ALERT_REASON, m_AlertReason);

      if(AlertReason::UE_PRESENT == m_AlertReason)
         LLOG(0,0,"AlertReason: UE Present");
      if(AlertReason::UE_MEMORY_AVAILABLE == m_AlertReason)
         LLOG(0,0,"AlertReason: Memory Available");
   }


   int l_NumSuppFeat = l_NotifyReq->countSupportedFeatures();
   for(int i=0; i<l_NumSuppFeat; i++)
   {
      LLOG(0,0,"SupportedFeature%d: VendorId: %d", i+1, l_NotifyReq->getSupportedFeatures(i).getVendorId().value());
      LLOG(0,0,"SupportedFeature%d: FeatureListID: %d", i+1, l_NotifyReq->getSupportedFeatures(i).getFeatureListID().value());
      LLOG(0,0,"SupportedFeature%d: FeatureList: %d", i+1, l_NotifyReq->getSupportedFeatures(i).getFeatureList().value());

      if(1 == l_NotifyReq->getSupportedFeatures(i).getFeatureListID().value())
         m_tdr.setInteger(TDR_INDEX_REMOTE_SUPP_FEATURE_1, l_NotifyReq->getSupportedFeatures(i).getFeatureList().value());
      else if(2 == l_NotifyReq->getSupportedFeatures(i).getFeatureListID().value())
         m_tdr.setInteger(TDR_INDEX_REMOTE_SUPP_FEATURE_2, l_NotifyReq->getSupportedFeatures(i).getFeatureList().value());
      else
         m_tdr.setInteger(TDR_INDEX_REMOTE_EXT_SUPP_FEATURE, l_NotifyReq->getSupportedFeatures(i).getFeatureList().value());
   }

   if( 0 == g_LteMm2ConfigReaderObj->m_PdnDynamicDiscoveryFlag )
   {
      m_dbreq->m_ApnFlag = m_dbreq->m_Mip6Flag = 0;
   }

   m_dbreq->m_cb = this;
   g_act.execute(m_dbreq);

   return true;
}

bool CtxtLteNotifyRequest::handleDBResponse(Msg *p_MsgPtr)
{
   NotifyDbData *l_db = (NotifyDbData*)p_MsgPtr;
   m_tdr.setInteger(TDR_INDEX_MM_NETWORK_ID, l_db->m_nwid);

   switch(l_db->m_ErrorCode)
   {
      case 0:
         if((true == m_dbreq->m_ImsApn) && (1 != l_db->m_imsFlag))
         {
            switch(l_db->m_NOAError)
            {
               case 0:
                  WLOG(0,0,"Sending unable to comply as IMS is disabled and NOR Error Flag[%d]",l_db->m_NOAError);
                  sendNOA(l_db, DIAM_RESULT_CODE_UNABLE_TO_COMPLY);
                  break;

               case 1:
                  WLOG(0,0,"Sending unknown serving node as IMS is disabled and NOR Error Flag[%d]",l_db->m_NOAError);
                  sendNOA(l_db, DIAM_RESULT_CODE_UNKNOWN, DIAM_EXP_RESULT_CODE_ERROR_UNKOWN_SERVING_NODE);
                  break;

               case 2:
                  WLOG(0,0,"Sending user unknown as IMS is disabled and NOR Error Flag[%d]",l_db->m_NOAError);
                  sendNOA(l_db, DIAM_RESULT_CODE_UNKNOWN, DIAM_EXP_RESULT_CODE_ERROR_USER_UNKNOWN);
                  break;

               default:
                  WLOG(0,0,"NOR Error Flag[%d] greater than 2.. Sending success");
                  sendNOA(l_db, DIAM_RESULT_CODE_SUCCESS);
                  break;
            }
         }
         else
         {
            LLOG(0,0,"Sending Success IMS Flag[%d] RequestedAPN [%s]",l_db->m_imsFlag,m_dbreq->m_ServiceSelection);
            sendNOA(l_db, DIAM_RESULT_CODE_SUCCESS);
         }
         break;

      case 1:
         sendNOA(l_db, DIAM_RESULT_CODE_UNKNOWN, DIAM_EXP_RESULT_CODE_ERROR_USER_UNKNOWN);
         break;

      case 2:
         sendNOA(l_db, DIAM_RESULT_CODE_UNKNOWN, DIAM_EXP_RESULT_CODE_ERROR_UNKOWN_SERVING_NODE);
         break;

      case 3:
         sendNOA(l_db, DIAM_RESULT_CODE_UNABLE_TO_COMPLY);
         break;

      default:
         sendNOA(l_db, DIAM_RESULT_CODE_UNABLE_TO_COMPLY);
         break;
   }
   return true;
}

bool CtxtLteNotifyRequest::sendNOA(NotifyDbData *p_db, EDiameterResultCode p_ResultCode, EDiameterExperimentalResultCode p_ExpResCode)
{

   DiameterMsg l_answer(m_SessionId, DIAM_EVENT_ANSWER, DIAM_COMM_CODE_S6A_S6D_NOR_NOA);
   s6a_r10::NotifyAnswer l_NotifyRes;
   try
   {
      l_answer.m_cmd = &l_NotifyRes;

      if(DIAM_RESULT_CODE_UNKNOWN != p_ResultCode)
      {
         m_tdr.setInteger(TDR_INDEX_ERR_CODE, p_ResultCode);
         LLOG(0,0,"Sending Result Code %d", p_ResultCode);
         ResultCode l_ResultCode(p_ResultCode);
         l_NotifyRes.setResultCode(l_ResultCode);
      }
      else
      {
         m_tdr.setInteger(TDR_INDEX_ERR_CODE, p_ExpResCode);
         LLOG(0,0,"Sending Experimental Result Code %d", p_ExpResCode);
         ExperimentalResult l_ExperimentalResult;
         VendorId l_VendorId(10415);
         l_ExperimentalResult.setVendorId(l_VendorId);
         ExperimentalResultCode l_ExperimentalResultCode(p_ExpResCode);
         l_ExperimentalResult.setExperimentalResultCode(l_ExperimentalResultCode);
         l_NotifyRes.setExperimentalResult(l_ExperimentalResult);
      }

      l_NotifyRes.setSessionIndex(m_SessionIndex);
      SessionId l_SessionId(m_SessionId);
      l_NotifyRes.setSessionId(l_SessionId);
      AuthSessionState l_AuthSessionState(AuthSessionState::NO_STATE_MAINTAINED);
      l_NotifyRes.setAuthSessionState(l_AuthSessionState);

      VendorSpecificApplicationId l_VendorSpecificApplicationId;
      VendorId l_VendorId(10415);
      l_VendorSpecificApplicationId.addVendorId(l_VendorId);
      AuthApplicationId l_AuthApplicationId(DIAM_APP_ID_S6A_S6D);
      l_VendorSpecificApplicationId.setAuthApplicationId(l_AuthApplicationId);
      l_NotifyRes.setVendorSpecificApplicationId(l_VendorSpecificApplicationId);

      if(NULL != p_db)
      {
         OriginHost l_OriginHost(p_db->m_HssOriginHost);
         l_NotifyRes.setOriginHost(l_OriginHost);
         OriginRealm l_OriginRealm(p_db->m_HssOriginRealm);
         l_NotifyRes.setOriginRealm(l_OriginRealm);

         if((int)p_db->m_FeatureList1 > 0)
         {
            SupportedFeatures l_SupportedFeatures;
            VendorId l_VendorId(10415);
            l_SupportedFeatures.setVendorId(l_VendorId);
            FeatureListID l_FeatureListID(1);
            l_SupportedFeatures.setFeatureListID(l_FeatureListID);
            FeatureList l_FeatureList(p_db->m_FeatureList1);
            l_SupportedFeatures.setFeatureList(l_FeatureList);
            l_NotifyRes.addSupportedFeatures(l_SupportedFeatures);
            m_tdr.setInteger(TDR_INDEX_LOCAL_SUPP_FEATURE_1, p_db->m_FeatureList1);
         }

         if(((int)p_db->m_FeatureList2 > 0) && (p_db->m_S6aRelease >= 12))
         {
            SupportedFeatures l_SupportedFeatures;
            VendorId l_VendorId(10415);
            l_SupportedFeatures.setVendorId(l_VendorId);
            FeatureListID l_FeatureListID(2);
            l_SupportedFeatures.setFeatureListID(l_FeatureListID);
            FeatureList l_FeatureList(p_db->m_FeatureList2);
            l_SupportedFeatures.setFeatureList(l_FeatureList);
            l_NotifyRes.addSupportedFeatures(l_SupportedFeatures);
            m_tdr.setInteger(TDR_INDEX_LOCAL_SUPP_FEATURE_2, p_db->m_FeatureList2);
         }
         if((1 == p_db->m_XmlCurCount) && (NULL != p_db->m_OssCurData.m_transXml))
         {
             LLOG(1,1,"XmlCurCount[%d], calling InitiateIndependentcontext with XML[%s] to initate PPR",p_db->m_XmlCurCount,p_db->m_OssCurData.m_transXml);
             g_esc.initiateIndependentContext(this, DIAM_COMM_CODE_CX_DX_PPR_PPA, p_db->m_OssCurData.m_transXml, INITIATION_TYPE_IMMEDIATE);
         }
      }
      else
      {
         OriginHost l_OriginHost("");
         l_NotifyRes.setOriginHost(l_OriginHost);
         OriginRealm l_OriginRealm("");
         l_NotifyRes.setOriginRealm(l_OriginRealm);
      }

   }
   catch (NoSuchAttributeException e)
   {
      ELOG(0,1,"ERROR!! Exception NoSuchAttributeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
      sendNOA(NULL, DIAM_RESULT_CODE_UNABLE_TO_COMPLY);
      return false;
   }
   catch (WrongCommandTypeException e)
   {
      ELOG(0,1,"ERROR!! Exception WrongCommandTypeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
      sendNOA(NULL, DIAM_RESULT_CODE_UNABLE_TO_COMPLY);
      return false;
   }
   catch (UnknownTypeException e)
   {
      ELOG(0,1,"ERROR!! Exception UnknownTypeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
      sendNOA(NULL, DIAM_RESULT_CODE_UNABLE_TO_COMPLY);
      return false;
   }
   catch (CodecException e)
   {
      ELOG(0,1,"ERROR!! Exception CodecException Caught: %s ,Error Cause: %s ",e.name(), e.what());
      sendNOA(NULL, DIAM_RESULT_CODE_UNABLE_TO_COMPLY);
      return false;
   }
   catch (...)
   {
      printf("\nException occurred while filling NOA");
      CLOG(0,0,"Exception occurred while filling NOA");
      sendNOA(NULL, DIAM_RESULT_CODE_UNABLE_TO_COMPLY);
      return false;
   }

   g_esc.sendMsg(this, &l_answer);
   LLOG(0,0,"Successfully sent NOA");
   return true;
}

bool CtxtLteNotifyRequest::processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag)
{
   TLOG(0,0,"Start of CtxtLteNotifyRequest::processMsg function %d", p_DeleteFlag);
   MapSpecificMsg *l_specMsg = NULL;

   switch (p_MsgPtr->m_MsgType)
   {
      case MSG_TYPE_MAP:
         DLOG(0,0,"MAP message received"); 
         break;

      case MSG_TYPE_DIAMETER:
         {
            LLOG(0,0,"DIAMETER message received");
            DiameterMsg *l_dm = (DiameterMsg*)p_MsgPtr;
            switch(l_dm->m_det)
            {
               case DIAM_EVENT_REQUEST:
                  {
                     snprintf(m_SessionId, sizeof(m_SessionId), "%s", l_dm->m_sessionId);
                     m_SessionIndex = l_dm->m_sessionIndex;
                     if((NULL == l_dm->m_cmd) || (NULL == l_dm->m_allocatedFlag))
                     {
                        CLOG(0,0,"Message received is NULL.");
                        sendNOA(NULL, DIAM_RESULT_CODE_UNABLE_TO_COMPLY);
                        break;
                     }
                     if(false == handleNotify(p_MsgPtr))
                        delete m_dbreq;
                  }
                  break;

               case DIAM_EVENT_ANSWER:
                  LLOG(0,0," DIAM_EVENT_ANSWER received");
                  break;

               case DIAM_EVENT_ERROR:
                  LLOG(0,0," DIAM_EVENT_ERROR received");
                  break;

               case DIAM_EVENT_TIME_OUT:
                  LLOG(0,0," DIAM_EVENT_TIME_OUT received");
                  break;

               case DIAM_EVENT_AUTH_LIFE_TIME_OUT:
                  LLOG(0,0," DIAM_EVENT_AUTH_LIFE_TIME_OUT received");
                  break;

               case DIAM_EVENT_AUTH_GRACE_TIME_OUT:
                  LLOG(0,0," DIAM_EVENT_AUTH_GRACE_TIME_OUT received");
                  break;

               case DIAM_EVENT_CORRUPTED_MSG:
                  LLOG(0,0," DIAM_EVENT_CORRUPTED_MSG received");
                  break;

               case DIAM_EVENT_ACCT_INTERIM_TIME_OUT:
                  LLOG(0,0," DIAM_EVENT_ACCT_INTERIM_TIME_OUT received");
                  break;

               default:
                  LLOG(0,0,"Unknown DIAMETER event %d received", l_dm->m_det);
                  break;
            }
         }
         break;

      case MSG_TYPE_DB:
         LLOG(0,0,"DB message received ErrorCode:%d", ((NotifyDbData*)p_MsgPtr)->m_ErrorCode);
         //LLOG(0,0,"DB message received [ErrorCode:%d]",((RetrieveSriSMData*)p_MsgPtr)->m_ErrorCode);
         //printf("\n GOT DB RESPONSE");

         //handleDBResponse(((NotifyDbData*)p_MsgPtr)->m_ErrorCode);
         handleDBResponse(p_MsgPtr);

         break;

      default:
         LLOG(0,0,"Unknown message received");
         break;

   }
   return true;
}
