#include <CtxtLteCancelLocationRequest.h>
#include <ExtendedServiceCoordinator.h>

#include <stdio.h>
#include <ServiceCoordinator.h>
#include <Logger.h>
#include <DbActiveObject.h>
#include <ConfigReader.h>
#include <LteMm2ConfigReader.h>
#include <DataUnion.h>
#include <Utilities.h>
#include <TimerManager.h>

#include <DiameterMessages.h>
#include <DiameterConstants.h>

//#include <app.h>
#include <DiametriqInterface.h>
#include <CancelLocation.h>
#include <CtxtLteCancelLocationRequest.h>
#include <S6a_r10AVP.h>
#include <LteMm2Simulator.h>

using namespace diameter::s6a_r10;
using namespace diameter::base;

CtxtLteCancelLocationRequest::CtxtLteCancelLocationRequest()
{
   m_OriginHost = m_OriginRealm = m_DestHost = m_DestRealm = m_Imsi = m_NodeType = m_UpdSubsData = m_ReqType = "";
   m_CancelType = m_ImsiPartType = -1;
   m_RetryCount = 0; 
   m_crossCL = false;
   TLOG(0,0,"CtxtLteCancelLocationRequest::CtxtLteCancelLocationRequest()");
}

CtxtLteCancelLocationRequest::~CtxtLteCancelLocationRequest()
{
   TLOG(0,0,"CtxtLteCancelLocationRequest::~CtxtLteCancelLocationRequest()");
}

#if 1
bool CtxtLteCancelLocationRequest::startProcessing(InterModuleData *p_imd, bool& p_DeleteFlag)
{

   LLOG(0,0,"CtxtLteCancelLocationRequest called with param [%s] OrigModule is [%s]", (NULL == p_imd->m_Parameters)?"":p_imd->m_Parameters, p_imd->m_OriginatorModule);

   if(NULL == p_imd->m_Parameters)
   {
      CLOG(0,0,"p_imd->m_Parameters NULL returning");
      return false;
   }
   
   if (strstr(p_imd->m_Parameters, "<CANCEL_LOC>"))
   {
      string l_dataString;
      l_dataString.assign(p_imd->m_Parameters, strlen(p_imd->m_Parameters));

      m_DestHost = ConfigReader::readValue(l_dataString, "DESTINATION_HOST");
      if("" == m_DestHost)
      {
         CLOG(0,0,"CtxtLteCancelLocationRequest received without DESTINATION_HOST. Returning..");
         m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
         return false;
      }

      m_DestRealm = ConfigReader::readValue(l_dataString, "DESTINATION_REALM");
      if("" == m_DestRealm)
      {
         CLOG(0,0,"CtxtLteCancelLocationRequest received without DESTINATION_REALM. Returning..");
         m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
         return false;
      }
      m_tdr.setString(TDR_INDEX_REMOTE_REALM, (char*)m_DestRealm.c_str());

      m_OriginHost = ConfigReader::readValue(l_dataString, "ORIGIN_HOST");
      if("" == m_OriginHost)
      {
         CLOG(0,0,"CtxtLteCancelLocationRequest received without ORIGIN_HOST. Returning..");
         m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
         return false;
      }
      m_tdr.setString(TDR_INDEX_LOCAL_HOST, (char*)m_OriginHost.c_str());

      m_OriginRealm = ConfigReader::readValue(l_dataString, "ORIGIN_REALM");
      if("" == m_OriginRealm)
      {
         CLOG(0,0,"CtxtLteCancelLocationRequest received without ORIGIN_REALM. Returning..");
         m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
         return false;
      }
      m_tdr.setString(TDR_INDEX_LOCAL_REALM, (char*)m_OriginRealm.c_str());

      m_Imsi = ConfigReader::readValue(l_dataString, "IMSI");
      if("" == m_Imsi)
      {
         CLOG(0,0,"CtxtLteCancelLocationRequest received without IMSI. Returning..");
         m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
         return false;
      }
      m_tdr.setChar(TDR_INDEX_REQUEST_TYPE, 'I');
      m_tdr.setString(TDR_INDEX_REQUEST_IMSI, (char*)m_Imsi.c_str());

      string l_tmp = ConfigReader::readValue(l_dataString, "CL_TYPE");
      if("" == l_tmp)
      {
         CLOG(0,0,"CtxtLteCancelLocationRequest received without CL_TYPE. Returning..");
         m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
         return false;
      }
      m_CancelType = atoi(l_tmp.c_str());
      if((0 > m_CancelType) || (m_CancelType > 4))
      {
         CLOG(0,0,"CtxtLteCancelLocationRequest received without proper TYPE value. Returning..");
         m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
         return false;
      }
      m_tdr.setInteger(TDR_INDEX_CLR_CANCELLATION_TYPE, m_CancelType);

      m_NodeType = ConfigReader::readValue(l_dataString, "NODE_TYPE");
      if("" == m_NodeType)
      {
         CLOG(0,0,"CtxtLteCancelLocationRequest received without NODE_TYPE. Returning..");
         m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
         return false;
      }

      l_tmp = ConfigReader::readValue(l_dataString, "IMSI_TYPE");
      if("" == l_tmp)
      {
         CLOG(0,0,"CtxtLteCancelLocationRequest received without IMSI_TYPE. ");
      }
      else
      {
         m_ImsiPartType = atoi((char*)l_tmp.c_str());
         m_tdr.setInteger(TDR_INDEX_PARTNER_TYPE, m_ImsiPartType);
      }

      m_UpdSubsData = ConfigReader::readValue(l_dataString, "UPDATE_SUBS_DATA");
      if("" == m_UpdSubsData)
      {
         CLOG(0,0,"CtxtLteCancelLocationRequest received without UPDATE_SUBS_DATA. Returning..");
         m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
         return false;
      }

      if("0" != m_UpdSubsData)
      {
         LLOG(0,0,"Initiating DB query for clearing SUBS DATA");
         ClrDbData *l_db = new ClrDbData();
         strcpy(l_db->m_Imsi, m_Imsi.c_str());
         l_db->m_Type = 2; //0-GSM, 1-GPRS, 2-MME
         l_db->m_UpdateFlag = atoi(m_UpdSubsData.c_str());
         l_db->m_cb = this;
         g_act.execute(l_db);
      }

      m_ReqType = ConfigReader::readValue(l_dataString, "REQUEST_TYPE");
      if("" == m_ReqType)
      {
         CLOG(0,0,"CtxtLteCancelLocationRequest received without REQUEST_TYPE.");
      }
      else
      {
         m_tdr.setString(TDR_INDEX_RESRV1, (char*)m_ReqType.c_str());
      }

      if(strstr(m_ReqType.c_str(), "SGSN"))
      {
         m_crossCL=true;
      }
      if(true == m_crossCL)
      {
         moduleLevelLogStats("CrossCLTowardsMME", MODULE_STATS_EVENT_STATUS_TOTAL);
      }

      sendCancelLocation();
   }
   return true;
}


bool CtxtLteCancelLocationRequest::sendCancelLocation()
{
   unsigned int sIdx;
   string sessIdString;
   if(false == g_esc.allocateSession(DIAM_APP_ID_S6A_S6D, 
            sIdx, 
            sessIdString))
   {
      ELOG(0,1,"Unable to allocate a session");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }

   DiameterMsg l_test((char*)sessIdString.c_str(), DIAM_EVENT_REQUEST, DIAM_COMM_CODE_S6A_S6D_CLR_CLA);;
   s6a_r10::CancelLocationRequest l_CLReq;

   try
   {
      l_CLReq.setSessionId(base::SessionId(sessIdString));
      l_CLReq.setSessionIndex(sIdx);

      AuthSessionState l_authSessionState(AuthSessionState::NO_STATE_MAINTAINED);
      l_CLReq.setAuthSessionState(l_authSessionState);

      OriginHost l_originHost = base::OriginHost(m_OriginHost);
      l_CLReq.setOriginHost(l_originHost);

      OriginRealm l_originRealm(m_OriginRealm);
      l_CLReq.setOriginRealm(l_originRealm);

      DestinationRealm l_destinationRealm(m_DestRealm);
      l_CLReq.setDestinationRealm(l_destinationRealm);

      DestinationHost l_destinationHost(m_DestHost);
      l_CLReq.setDestinationHost(l_destinationHost);

      UserName l_UserName(m_Imsi);
      l_CLReq.setUserName(l_UserName);

      CancellationType l_CancellationType((CancellationType::Value)m_CancelType);
      l_CLReq.setCancellationType(l_CancellationType);

      l_test.m_cmd = &l_CLReq;
   }
   catch (NoSuchAttributeException e)
   {
      ELOG(0,1,"ERROR!! Exception NoSuchAttributeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }
   catch (WrongCommandTypeException e)
   {
      ELOG(0,1,"ERROR!! Exception WrongCommandTypeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }
   catch (UnknownTypeException e)
   {
      ELOG(0,1,"ERROR!! Exception UnknownTypeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }
   catch (CodecException e)
   {
      ELOG(0,1,"ERROR!! Exception CodecException Caught: %s ,Error Cause: %s ",e.name(), e.what());
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }
   catch (...)
   {
      printf("\nException occurred while filling CLR");
      CLOG(0,0,"Exception occurred while filling CLR");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }

   g_esc.sendMsg(this, &l_test);
   LLOG(0,0,"Cancel Location Request has been sent successfully ");
   return true;
}
#endif

bool CtxtLteCancelLocationRequest::handleCancelLocationAnswer(Msg *p_MsgPtr)
{
   //s6a_r10::CancelLocationAnswer *l_CLAns = (s6a_r10::CancelLocationAnswer*)((DiameterMsg *)p_MsgPtr)->m_cmd;
   s6a_r10::CancelLocationAnswer l_Tmp(*(diameter::CommandImpl *)((DiameterMsg*)p_MsgPtr)->m_cmd);
   s6a_r10::CancelLocationAnswer *l_CLAns = &l_Tmp;

   int l_ResultCode = 0;
   if(true == l_CLAns->containsResultCode())
   {
      l_ResultCode = l_CLAns->getResultCode().value();
      LLOG(0,0,"CancelLocationAnswer received with ResultCode %d", l_ResultCode);
   }

   if(true == l_CLAns->containsExperimentalResult())
   {
      l_ResultCode = l_CLAns->getExperimentalResult().getExperimentalResultCode().value(); 
      LLOG(0,0,"CancelLocationAnswer received with ExperimentalResultCode %d", l_ResultCode);
   }
   m_tdr.setInteger(TDR_INDEX_ERR_CODE, l_ResultCode);

   //if(l_ResultCode != 2001)
   if((l_ResultCode >= 2000) && (l_ResultCode < 3000))
   {
      LLOG(0,0,"Result code[%d] is in success range", l_ResultCode);
   }
   else
   {
      LLOG(0,0,"Result code[%d] is NOT in success range. Checking for Retry", l_ResultCode);
      checkForRetry();
   }
   return true;
}

bool CtxtLteCancelLocationRequest::checkForRetry()
{
   LLOG(0,0,"Current Attempt:%d Total Retry Attempts:%d", m_RetryCount, g_LteMm2ConfigReaderObj->m_CancelLocationRetryCount);

   if(m_RetryCount < g_LteMm2ConfigReaderObj->m_CancelLocationRetryCount)
   {
      if(g_LteMm2ConfigReaderObj->m_CancelLocationRetryTimer > 0)
      {
         LLOG(0,0,"Starting Timer for CLR Retry [Dest Host:%s, Dest Realm:%s]", m_DestHost.c_str(), m_DestRealm.c_str());
         g_tm.startTimer(this, g_LteMm2ConfigReaderObj->m_CancelLocationRetryTimer);
      }
   }
   return true;
}

bool CtxtLteCancelLocationRequest::handleTimeout()
{
   LLOG(0,0,"CtxtLteCancelLocationRequest::handleTimeout %d %d", m_RetryCount, g_LteMm2ConfigReaderObj->m_CancelLocationRetryCount);
   if(m_RetryCount < g_LteMm2ConfigReaderObj->m_CancelLocationRetryCount)
   {
      sendCancelLocation();
      m_RetryCount++;
   }
   return true;
}

bool CtxtLteCancelLocationRequest::processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag)
{
   TLOG(0,0,"Start of CtxtLteCancelLocationRequest::processMsg function %d", p_DeleteFlag);
   MapSpecificMsg *l_specMsg = NULL;

   switch (p_MsgPtr->m_MsgType)
   {
      case MSG_TYPE_MAP:
         DLOG(0,0,"MAP message received"); 
         break;

      case MSG_TYPE_DIAMETER:
         {
            LLOG(0,0,"DIAMETER message received");
            DiameterMsg *l_dm = (DiameterMsg*)p_MsgPtr;
            switch(l_dm->m_det)
            {
               case DIAM_EVENT_ANSWER:
                  {
                     if((NULL == l_dm->m_cmd) || (NULL == l_dm->m_allocatedFlag))
                     {
                        CLOG(0,0,"Message received is NULL.");
                        break;
                     }
                     LLOG(0,1,"DIAM_EVENT_ANSWER received");
                     handleCancelLocationAnswer(p_MsgPtr);
                     if(true == m_crossCL)
                     {
                        moduleLevelLogStats("CrossCLTowardsMME", MODULE_STATS_EVENT_STATUS_SUCCESS);
                     }
                  }
                  break;

               case DIAM_EVENT_TIME_OUT:
                  {
                     m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EVENT_TIME_OUT);
                     LLOG(0,1,"DIAM_EVENT_TIME_OUT received");
                     checkForRetry();
                  }
                  break;

               case DIAM_EVENT_ERROR:
                  {
                     m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EVENT_ERROR);
                     LLOG(0,1,"DIAM_EVENT_ERROR received ");
                     checkForRetry();
                  }
                  break;

               case DIAM_EVENT_AUTH_LIFE_TIME_OUT:
                  m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EVENT_AUTH_LIFE_TIME_OUT);
                  LLOG(0,1,"DIAM_EVENT_AUTH_LIFE_TIME_OUT received");
                  checkForRetry();
                  break;

               case DIAM_EVENT_AUTH_GRACE_TIME_OUT:
                  m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EVENT_AUTH_GRACE_TIME_OUT);
                  LLOG(0,1,"DIAM_EVENT_AUTH_GRACE_TIME_OUT received");
                  checkForRetry();
                  break;

               case DIAM_EVENT_CORRUPTED_MSG:
                  {
                     m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EVENT_CORRUPTED_MSG);
                     LLOG(0,1,"DIAM_EVENT_CORRUPTED_MSG received");
                     checkForRetry();
                  }
                  break;

               case DIAM_EVENT_ACCT_INTERIM_TIME_OUT:
                  m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EVENT_ACCT_INTERIM_TIME_OUT);
                  LLOG(0,1,"DIAM_EVENT_ACCT_INTERIM_TIME_OUT received");
                  checkForRetry();
                  break;

               case DIAM_EVENT_ERROR_SOMETHING_WEIRD:
                  LLOG(0,1,"DIAM_EVENT_ERROR_SOMETHING_WEIRD received");
                  checkForRetry();
                  break;

               default:
                  LLOG(0,1,"UNKNOWN DIAMETER received");
                  checkForRetry();
                  return false;
                  break;
            }
         }
         break;

      case MSG_TYPE_DB:
         LLOG(0,0,"DB message received ");
         //LLOG(0,0,"DB message received [ErrorCode:%d]",((RetrieveSriSMData*)p_MsgPtr)->m_ErrorCode);
         //printf("\n GOT DB RESPONSE");

         //handleDBResponse(p_MsgPtr);

         break;

      case MSG_TYPE_TIMEOUT:
         LLOG(0,0,"TIMEOUT message received [IMSI:%s]", m_Imsi.c_str());
         handleTimeout();
         break;


      default:
         LLOG(0,0,"Unknown message received");
         break;

   }
   return true;
}

