#include <LteMm2ConfigReader.h>
#include <Logger.h>

LteMm2ConfigReader *g_LteMm2ConfigReaderObj = NULL;



LteMm2ConfigReader::LteMm2ConfigReader()
{
   m_CancelLocationRetryCount = m_CancelLocationRetryTimer = m_PdnDynamicDiscoveryFlag = 0;
}

LteMm2ConfigReader::~LteMm2ConfigReader()
{
}


bool LteMm2ConfigReader::readData()
{
   //printf("\nCalling LteMm2ConfigReader::readData()");
   //string l_Smsm = readValue(m_DataString, "MM2");
   string l_Smsm = m_DataString;

   if(false == readInteger(l_Smsm, "PDN_DYNAMIC_DISCOVERY_FLAG", m_PdnDynamicDiscoveryFlag, 0, 1))
   {
      ELOG(0,0,"PDN_DYNAMIC_DISCOVERY_FLAG should be 0 or 1");
      return false;
   }

   if(false == readInteger(l_Smsm, "CLR_RETRY_COUNT", m_CancelLocationRetryCount, 0, 10))
   {
      ELOG(0,0,"CLR_RETRY_COUNT should be between 0 and 10");
      return false;
   }

   if(m_CancelLocationRetryCount > 0)
   {
      if(false == readInteger(l_Smsm, "CLR_RETRY_TIMER", m_CancelLocationRetryTimer, 0, 600))
      {
         ELOG(0,0,"CLR_RETRY_TIMER should be between 0 and 600");
         return false;
      }
      if(m_CancelLocationRetryTimer == 0)
      {
         LLOG(0,0,"CLR_RETRY_TIMER is 0, Immediate Retry will be done");
      }
   }

   return true;
}

void LteMm2ConfigReader::printConfigData(char *p_output)
{
   TLOG(0,1,"LteMm2ConfigReader::printConfigData called.");

   sprintf(p_output, "%s:%d\t%s:%d\t%s:%d", 
         "CancelLocationRetryCount", g_LteMm2ConfigReaderObj->m_CancelLocationRetryCount,
         "CancelLocationRetryTimer", g_LteMm2ConfigReaderObj->m_CancelLocationRetryTimer,
         "PdnDynamicDiscoveryFlag", g_LteMm2ConfigReaderObj->m_PdnDynamicDiscoveryFlag
         );
}
