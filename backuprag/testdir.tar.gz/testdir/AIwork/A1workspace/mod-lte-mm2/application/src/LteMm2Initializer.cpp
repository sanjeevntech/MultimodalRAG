#include <MapMessages.h>
#include <ContextBase.h>
#include <ModuleBase.h>
#include <LteMm2ConfigReader.h>
#include <Logger.h>
#include <LteMm2Simulator.h>

#include <CtxtLteNotifyRequest.h>
//#include <CtxtUpd.h>
//#include <CtxtLteCancelLocationRequest.h>

extern bool g_loadFlag;

extern "C" {
   ModuleBase *getModuleObj();
}


class LteMm2Module : public ModuleBase
{
    public:
       LteMm2Module(){};
      bool initModule();
      ContextBase *getCtxtObj(EMapOpCode, MapSpecificMsg*);
      ContextBase *getCtxtObj(EDiameterCommandCode, DiameterMsg*);
      ContextBase *getCtxtObj(EMapOpCode, SccpMsg*);
      char *getVersion();
      ConfigReader *getConfigReaderObj();
      ConfigReader **retrieveConfigReaderPtr();
};

LteMm2Module g_LteMm2Module;

ModuleBase *getModuleObj()
{
    return &g_LteMm2Module;
}

ContextBase *LteMm2Module::getCtxtObj(EDiameterCommandCode p_OpCode, DiameterMsg *p_msg)
{
   switch (p_OpCode)
   {
      case DIAM_COMM_CODE_S6A_S6D_NOR_NOA:
         {
            if(false == g_loadFlag)
            {
               TLOG(0,0,"Newing CtxtLteNotifyRequest");
               return new CtxtLteNotifyRequest;
            }
#if 1
            else
            {
               TLOG(0,0,"Newing NotifySimulator");
               return new NotifySimulator;
            }
#endif
         }
         break;

      case DIAM_COMM_CODE_S6A_S6D_CLR_CLA:
         {
            if(false == g_loadFlag)
            {
               TLOG(0,0,"Newing CtxtLteCancelLocationRequest");
               return new CtxtLteCancelLocationRequest;
            }
            else
            {
               TLOG(0,0,"Newing CancelLocationSimulator");
               return new CancelLocationSimulator;
            }
         }
         break;

        default:
            CLOG(0,0,"getCtxtObj Unknown OpCode [%d]",p_OpCode);
            printf("\ngetCtxtObj Unknown OpCode [%d]",p_OpCode);
            return NULL;
            break;
    }
}

ContextBase *LteMm2Module::getCtxtObj(EMapOpCode p_OpCode, MapSpecificMsg *p_msg)
{
#if 0
    switch (p_OpCode)
    {
        case MAP_OP_CODE_reportSMDeliveryStatus:
            TLOG(0,0,"Newing CtxtReportSM");
            return new CtxtReportSM;
            break;

        case MAP_OP_CODE_readyForSM:
        case MAP_OP_CODE_noteMsPresent:
            TLOG(0,0,"Newing CtxtReadyForSM");
            return new CtxtReadyForSM;
            break;

        case MAP_OP_CODE_alertServiceCentre:
        case MAP_OP_CODE_alertServiceCentre_v1:
            TLOG(0,0,"Newing CtxtAlertSc");
            return new CtxtAlertSc;
            break;

        case MAP_OP_CODE_sendRoutingInfoForSM:
            TLOG(0,0,"Newing CtxtSriSM");
            return new CtxtSriSM;
            break;

        default:
            CLOG(0,0,"getCtxtObj Unknown OpCode [%d]",p_OpCode);
            printf("\ngetCtxtObj Unknown OpCode [%d]",p_OpCode);
            if (false == p_msg->m_allocatedFlag)
            {
               CLOG(0,0,"m_allocatedFlag is false");
            }
            return NULL;
            break;
    }
#else
    return NULL;
#endif
}

ContextBase *LteMm2Module::getCtxtObj(EMapOpCode p_OpCode, SccpMsg* p_msg)
{
   ELOG(0,0,"SCCP message not supported");
   return NULL;
}

char* LteMm2Module::getVersion()
{
   RETURN_VERSION (APP_VERSION) // 2.0.21.0 2.0.16.0_Rev3 //2.0.16.0_Rev2 //2.0.15.0 
}

bool LteMm2Module::initModule()
{
   m_modName="LM2";
   LLOG(0,0,"LM2 APPVER-v:%s ci:%s cd:%s comp:%s %s", APP_VERSION, COMMIT_ID, COMMIT_DATE,__DATE__,__TIME__);
   moduleLevelAddHeader("CrossCLTowardsMME", MODULE_STATS_TYPE_TOTAL_SUCCESS);
#if 0
   if (NULL == g_LteMm2ConfigReaderObj)
   {
      return false;
   }
#endif
   //g_selfSimObj = new LteMm2Simulator;
   return true;
}

ConfigReader *LteMm2Module::getConfigReaderObj()
{
	LLOG(0,0,"Returning g_LteMm2ConfigReaderObj");
   //return (g_LteMm2ConfigReaderObj = new LteMm2ConfigReader);
   return new LteMm2ConfigReader;
}

ConfigReader **LteMm2Module::retrieveConfigReaderPtr()
{
   LLOG(0,0,"ConfigReader **LteMm2Module::retrieveConfigReaderPtr() called");
   return (ConfigReader **)&g_LteMm2ConfigReaderObj;
}


bool resetStruct(int p_version, int p_pdu, void *p_struct)
{
   if(p_struct == NULL)
   {
      ELOG(0,0, "resetStruct called for %d version, %d pdu with NULL structure", p_version, p_pdu);
   }
   return false;
}
