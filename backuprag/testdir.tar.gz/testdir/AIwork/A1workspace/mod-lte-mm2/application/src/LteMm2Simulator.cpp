#include <LteMm2Simulator.h>
#include <Logger.h>

#include <DiameterMessages.h>
#include <ExtendedServiceCoordinator.h>
#include <DiameterConstants.h>

#include <ExtendedServiceCoordinator.h>
//#include <s6a_defines.h>
#include <DiametriqInterface.h>
#include <Notify.h>
#include <CancelLocation.h>
#include <S6a_r10AVP.h>

using namespace diameter::base;
using namespace diameter::s6a_r10;


NotifySimulator::NotifySimulator()
{
}

NotifySimulator::~NotifySimulator()
{
}

bool NotifySimulator::startProcessing()
{
   LLOG(0,0,"selfSimulate: NOR");
   unsigned int sIdx;
   string sessIdString;
   if(false == g_esc.allocateSession(DIAM_APP_ID_S6A_S6D, 
            sIdx, 
            sessIdString))
   {
      ELOG(0,1,"Unable to allocate a session");
      return false;
   }

   cout<<"--- sessionIDint---"<<sIdx<<endl<<"--- sessionIDstring ---"<<sessIdString<<endl;

   DiameterMsg l_test((char*)sessIdString.c_str(), DIAM_EVENT_REQUEST, DIAM_COMM_CODE_S6A_S6D_NOR_NOA);

   //Prepare ULR Message
   s6a_r10::NotifyRequest *l_NotifyReq = new s6a_r10::NotifyRequest;
   l_NotifyReq->setSessionId(base::SessionId(sessIdString));
   l_NotifyReq->setSessionIndex(sIdx);


   AuthSessionState l_authSessionState(AuthSessionState::NO_STATE_MAINTAINED);
   l_NotifyReq->setAuthSessionState(l_authSessionState);

   OriginHost l_originHost = base::OriginHost(g_OtherConfigData->m_dcd.m_originHost);
   l_NotifyReq->setOriginHost(l_originHost);

   OriginRealm l_originRealm(g_OtherConfigData->m_dcd.m_originRealm);
   l_NotifyReq->setOriginRealm(l_originRealm);

   DestinationRealm l_destinationRealm(g_OtherConfigData->m_dcd.m_destinationRealm);
   l_NotifyReq->setDestinationRealm(l_destinationRealm);

   DestinationHost l_destinationHost(g_OtherConfigData->m_dcd.m_destinationHost);
   l_NotifyReq->setDestinationHost(l_destinationHost);

   UserName l_userName("222640010000009");
   l_NotifyReq->setUserName(l_userName);

   TerminalInformation l_TerminalInformation;
   IMEI l_IMEI("098765432112345");
   l_TerminalInformation.setIMEI(l_IMEI);
   S6a3GPP2MEID l_S6a3GPP2MEID("ABCD1034");
   l_TerminalInformation.setS6a3GPP2MEID(l_S6a3GPP2MEID);
   SoftwareVersion l_SoftwareVersion("1.2");
   l_TerminalInformation.setSoftwareVersion(l_SoftwareVersion);
   l_NotifyReq->setTerminalInformation(l_TerminalInformation);

   MIP6AgentInfo l_MIP6AgentInfo;
   /*Address l_Address(Address::IPV4, "192.168.151.1");
   MIPHomeAgentAddress l_MIPHomeAgentAddress(l_Address);
   l_MIP6AgentInfo.addMIPHomeAgentAddress(l_MIPHomeAgentAddress);*/
   MIPHomeAgentHost l_MIPHomeAgentHost;
   DestinationHost l_DestinationHost("testhost");
   l_MIPHomeAgentHost.setDestinationHost(l_DestinationHost);;
   DestinationRealm l_DestinationRealm("testrealm.com");
   l_MIPHomeAgentHost.setDestinationRealm(l_DestinationRealm);
   l_MIP6AgentInfo.setMIPHomeAgentHost(l_MIPHomeAgentHost);
   MIP6HomeLinkPrefix l_MIP6HomeLinkPrefix("link prefix");
   l_MIP6AgentInfo.setMIP6HomeLinkPrefix(l_MIP6HomeLinkPrefix);
   l_NotifyReq->setMIP6AgentInfo(l_MIP6AgentInfo);

   ContextIdentifier l_ContextIdentifier(21);
   l_NotifyReq->setContextIdentifier(l_ContextIdentifier);

   ServiceSelection l_ServiceSelection("ims");
   l_NotifyReq->setServiceSelection(l_ServiceSelection);

   NORFlags l_NORFlags(1);
   l_NotifyReq->setNORFlags(l_NORFlags);

   AlertReason l_AlertReason(AlertReason::UE_MEMORY_AVAILABLE);
   l_NotifyReq->setAlertReason(l_AlertReason);

   VendorSpecificApplicationId l_vendorSpecAppId1;
   VendorId l_vendorId(1234);
   l_vendorSpecAppId1.addVendorId(l_vendorId);
   l_NotifyReq->setVendorSpecificApplicationId(l_vendorSpecAppId1);

   SupportedFeatures l_suppFeatures;
   VendorId l_vendorIdSup(4321);
   l_suppFeatures.setVendorId(l_vendorIdSup);
   FeatureListID l_featureListId(1);
   l_suppFeatures.setFeatureListID(l_featureListId);
   FeatureList l_featurList(630);
   l_suppFeatures.setFeatureList(l_featurList);
   l_NotifyReq->addSupportedFeatures(l_suppFeatures);

   SupportedFeatures l_suppFeatures1;
   VendorId l_vendorIdSup1(4321);
   l_suppFeatures1.setVendorId(l_vendorIdSup1);
   FeatureListID l_featureListId1(2);
   l_suppFeatures1.setFeatureListID(l_featureListId1);
   FeatureList l_featurList1(8);
   l_suppFeatures1.setFeatureList(l_featurList1);
   l_NotifyReq->addSupportedFeatures(l_suppFeatures1);

   l_test.m_cmd = l_NotifyReq;
   l_test.m_allocatedFlag = true;

   g_esc.sendMsg(this, &l_test);

#if 0
   LLOG(0,0,"selfSimulate: ULR");
   int sIdx;
   string sessIdString;
   if(false == g_esc.allocateSession(DIAM_APP_ID_S6A_S6D, 
            sIdx, 
            sessIdString))
   {
      ELOG(0,1,"Unable to allocate a session");
      return false;
   }

   cout<<"--- sessionIDint---"<<sIdx<<endl<<"--- sessionIDstring ---"<<sessIdString<<endl;

   *p_msgPtr = new DiameterMsg(DIAM_EVENT_REQUEST, DIAM_COMM_CODE_S6A_S6D_ULR_ULA);;
   DiameterMsg *l_test = (DiameterMsg*)(*p_msgPtr);
   l_test->m_commandCode = DIAM_COMM_CODE_S6A_S6D_ULR_ULA;

   //Prepare ULR Message
   s6a::UpdateLocationRequest *l_UpdReq = new s6a::UpdateLocationRequest;
   l_UpdReq->setSessionId(base::SessionId(sessIdString));
   l_UpdReq->setSessionIndex(sIdx);


   AuthSessionState l_authSessionState(AuthSessionState::NO_STATE_MAINTAINED);
   l_UpdReq->setAuthSessionState(l_authSessionState);

   OriginHost l_originHost = base::OriginHost("origin.mme");
   l_UpdReq->setOriginHost(l_originHost);

   OriginRealm l_originRealm("OriginRealm");
   l_UpdReq->setOriginRealm(l_originRealm);

   DestinationRealm l_destinationRealm("DestinationRealm");
   l_UpdReq->setDestinationRealm(l_destinationRealm);

   DestinationHost l_destinationHost("DestinationHost");
   l_UpdReq->setDestinationHost(l_destinationHost);

   UserName l_userName("123456789012345");
   l_UpdReq->setUserName(l_userName);

   RATType l_RATType(RATType::UTRAN);
   l_UpdReq->setRATType(l_RATType);

   VisitedPLMNId l_VisitedPLMNId("40412");
   l_UpdReq->setVisitedPLMNId(l_VisitedPLMNId);

   TerminalInformation l_TerminalInformation;
   IMEI l_IMEI("09876543211234");
   l_TerminalInformation.setIMEI(l_IMEI);
   S6a3GPP2MEID l_S6a3GPP2MEID("MEID");
   l_TerminalInformation.setS6a3GPP2MEID(l_S6a3GPP2MEID);
   SoftwareVersion l_SoftwareVersion("1.2");
   l_TerminalInformation.setSoftwareVersion(l_SoftwareVersion);
   l_UpdReq->setTerminalInformation(l_TerminalInformation);

   ULRFlags l_ULRFlags(1);
   l_UpdReq->setULRFlags(l_ULRFlags);

   VendorSpecificApplicationId l_vendorSpecAppId1;
   VendorId l_vendorId(1234);
   l_vendorSpecAppId1.addVendorId(l_vendorId);
   l_UpdReq->setVendorSpecificApplicationId(l_vendorSpecAppId1);

   SupportedFeatures l_suppFeatures;
   VendorId l_vendorIdSup(4321);
   l_suppFeatures.setVendorId(l_vendorIdSup);
   FeatureListID l_featureListId(629);
   l_suppFeatures.setFeatureListID(l_featureListId);
   FeatureList l_featurList(630);
   l_suppFeatures.setFeatureList(l_featurList);
   l_UpdReq->addSupportedFeatures(l_suppFeatures);

   l_test->m_cmd = l_UpdReq;
   l_test->m_allocatedFlag = true;

#endif
   return true;
}

bool NotifySimulator::processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag)
{
   TLOG(0,0,"Start of CtxtNotify::processMsg function %d", p_DeleteFlag);
   MapSpecificMsg *l_specMsg = NULL;

   switch (p_MsgPtr->m_MsgType)
   {
      case MSG_TYPE_MAP:
         DLOG(0,0,"MAP message received"); 
         break;

      case MSG_TYPE_DIAMETER:
         {
            LLOG(0,0,"DIAMETER message received");
            DiameterMsg *l_dm = (DiameterMsg*)p_MsgPtr;
            if(NULL == l_dm->m_cmd)
            {
               CLOG(0,0,"Message received is NULL.");
               break;
            }
         }
         break;

      case MSG_TYPE_DB:
         LLOG(0,0,"DB message received ");

         break;

      default:
         LLOG(0,0,"Unknown message received");
         break;

   }
   return true;
}


CancelLocationSimulator::CancelLocationSimulator()
{
}

CancelLocationSimulator::~CancelLocationSimulator()
{
}

bool CancelLocationSimulator::processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag)
{
   TLOG(0,0,"Start of processMsg function %d", p_DeleteFlag);
   MapSpecificMsg *l_specMsg = NULL;

   switch (p_MsgPtr->m_MsgType)
   {
      case MSG_TYPE_MAP:
         DLOG(0,0,"MAP message received"); 
         break;

      case MSG_TYPE_DIAMETER:
         {
            LLOG(0,0,"DIAMETER message received");
            DiameterMsg *l_dm = (DiameterMsg*)p_MsgPtr;
            switch(l_dm->m_det)
            {
               case DIAM_EVENT_REQUEST:
                  {
                     if((NULL == l_dm->m_cmd) || (NULL == l_dm->m_allocatedFlag))
                     {
                        CLOG(0,0,"Message received is NULL.");
                        DiameterMsg l_answer(l_dm->m_sessionId, DIAM_EVENT_ANSWER, DIAM_COMM_CODE_S6A_S6D_CLR_CLA);
                        s6a_r10::CancelLocationAnswer l_ClrAns;
                        l_answer.m_cmd = &l_ClrAns;
                        ResultCode l_ResultCode(DIAM_RESULT_CODE_UNABLE_TO_COMPLY);
                        l_ClrAns.setResultCode(l_ResultCode);
                        l_ClrAns.setSessionIndex(l_dm->m_sessionIndex);
                        SessionId l_SessionId(l_dm->m_sessionId);
                        l_ClrAns.setSessionId(l_SessionId);
                        AuthSessionState l_AuthSessionState(AuthSessionState::NO_STATE_MAINTAINED);
                        l_ClrAns.setAuthSessionState(l_AuthSessionState);
                        g_esc.sendMsg(this, &l_answer);
                        break;
                     }

                     try
                     {
                        CLOG(0,0,"Sending Success.");
                        DiameterMsg l_answer(l_dm->m_sessionId, DIAM_EVENT_ANSWER, DIAM_COMM_CODE_S6A_S6D_CLR_CLA);
                        s6a_r10::CancelLocationAnswer l_ClrAns;
                        l_answer.m_cmd = &l_ClrAns;
                        ResultCode l_ResultCode(DIAM_RESULT_CODE_SUCCESS);
                        l_ClrAns.setResultCode(l_ResultCode);
                        l_ClrAns.setSessionIndex(l_dm->m_sessionIndex);
                        SessionId l_SessionId(l_dm->m_sessionId);
                        l_ClrAns.setSessionId(l_SessionId);
                        AuthSessionState l_AuthSessionState(AuthSessionState::NO_STATE_MAINTAINED);
                        l_ClrAns.setAuthSessionState(l_AuthSessionState);
                        OriginHost originHost("MyHost");
                        l_ClrAns.setOriginHost(originHost);
                        OriginRealm originRealm("MyRealm");
                        l_ClrAns.setOriginRealm(originRealm);
                        g_esc.sendMsg(this, &l_answer);
                     }
                     catch (NoSuchAttributeException e)
                     {
                        ELOG(0,1,"ERROR!! Exception NoSuchAttributeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
                     }
                     catch (WrongCommandTypeException e)
                     {
                        ELOG(0,1,"ERROR!! Exception WrongCommandTypeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
                     }
                     catch (UnknownTypeException e)
                     {
                        ELOG(0,1,"ERROR!! Exception UnknownTypeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
                     }
                     catch (CodecException e)
                     {
                        ELOG(0,1,"ERROR!! Exception CodecException Caught: %s ,Error Cause: %s ",e.name(), e.what());
                     }
                     catch (...)
                     {
                        printf("\nException occurred while filling CLR");
                        CLOG(0,0,"Exception occurred while filling CLR");
                     }


                  }
                  break;

               case DIAM_EVENT_ANSWER:
                  LLOG(0,0," DIAM_EVENT_ANSWER received");
                  break;

               case DIAM_EVENT_ERROR:
                  LLOG(0,0," DIAM_EVENT_ERROR received");
                  break;

               case DIAM_EVENT_TIME_OUT:
                  LLOG(0,0," DIAM_EVENT_TIME_OUT received");
                  break;

               case DIAM_EVENT_AUTH_LIFE_TIME_OUT:
                  LLOG(0,0," DIAM_EVENT_AUTH_LIFE_TIME_OUT received");
                  break;

               case DIAM_EVENT_AUTH_GRACE_TIME_OUT:
                  LLOG(0,0," DIAM_EVENT_AUTH_GRACE_TIME_OUT received");
                  break;

               case DIAM_EVENT_CORRUPTED_MSG:
                  LLOG(0,0," DIAM_EVENT_CORRUPTED_MSG received");
                  break;

               case DIAM_EVENT_ACCT_INTERIM_TIME_OUT:
                  LLOG(0,0," DIAM_EVENT_ACCT_INTERIM_TIME_OUT received");
                  break;

               default:
                  LLOG(0,0,"Unknown DIAMETER event %d received", l_dm->m_det);
                  break;
            }
         }
         break;

      case MSG_TYPE_DB:
         LLOG(0,0,"DB message received ");
         break;

      default:
         LLOG(0,0,"Unknown message received");
         break;

   }
   
   return true;
}
