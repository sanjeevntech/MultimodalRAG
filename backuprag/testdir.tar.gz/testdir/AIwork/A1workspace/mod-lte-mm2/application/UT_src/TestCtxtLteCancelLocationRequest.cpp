#define private public
#include<iostream>
#include"gtest.h"
#include<CtxtLteCancelLocationRequest.h>
#include<LteMm2ConfigReader.h>
#include<idc_api.h>
#include<Msg.h>
#include<ServiceCoordinator.h>

extern IDSCLApi *g_smplApi;

class UT_CtxtLteCancelLocationRequest: public testing::Test ,public CtxtLteCancelLocationRequest 
{public:
UT_CtxtLteCancelLocationRequest()
{
}
~UT_CtxtLteCancelLocationRequest()
{
}
};

class UT_LteMm2ConfigReader
{public:
UT_LteMm2ConfigReader()
{
}
~UT_LteMm2ConfigReader()
{
}
};

class UT_Msg
{public:
UT_Msg()
{
}
~UT_Msg()
{
}
};

class UT_InterModuleData
{public:
UT_InterModuleData()
{
}
~UT_InterModuleData()
{
}
};


TEST_F(UT_CtxtLteCancelLocationRequest,checkForRetry_Func) {
CtxtLteCancelLocationRequest::m_RetryCount=1;
g_LteMm2ConfigReaderObj=new LteMm2ConfigReader;
g_LteMm2ConfigReaderObj->m_CancelLocationRetryCount=10000000000000000000000;
EXPECT_TRUE(checkForRetry());
}

TEST_F(UT_CtxtLteCancelLocationRequest,handleTimeout_Func) {
g_LteMm2ConfigReaderObj=new LteMm2ConfigReader;
EXPECT_TRUE(handleTimeout());
}

/*
TEST_F(UT_CtxtLteCancelLocationRequest,sendCancelLocation_Func) {
g_smplApi = new IDSCLApi;
EXPECT_TRUE(sendCancelLocation());
}*/

TEST_F(UT_CtxtLteCancelLocationRequest,processMessage_MSG_TYPE_MAP_Func) {
Msg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtLteCancelLocationRequest,processMessage_MSG_TYPE_DIAMETER_Func) {
Msg p_MsgPtr;
p_MsgPtr.m_MsgType=7;
bool p_DeleteFlag=true;
EXPECT_FALSE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtLteCancelLocationRequest,processMessage_MSG_TYPE_DB_Func) {
Msg p_MsgPtr;
p_MsgPtr.m_MsgType=2;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

/*
TEST_F(UT_CtxtLteCancelLocationRequest,processMessage_MSG_TYPE_TIMEOUT_Func) {
Msg p_MsgPtr;
p_MsgPtr.m_MsgType=4;
bool p_DeleteFlag=true;
g_LteMm2ConfigReaderObj=new LteMm2ConfigReader;
g_LteMm2ConfigReaderObj->m_CancelLocationRetryCount=100000000000000000000;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}
*/

TEST_F(UT_CtxtLteCancelLocationRequest,processMessage_default_Func) {
Msg p_MsgPtr;
p_MsgPtr.m_MsgType=0;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

/*TEST_F(UT_CtxtLteCancelLocationRequest,startProcessing_Func) {
InterModuleData p_imd;
strcpy(p_imd.m_Parameters,"<CANCEL_LOC>");
bool p_DeleteFlag=true;
EXPECT_FALSE(startProcessing(&p_imd,p_DeleteFlag));
}

TEST_F(UT_CtxtLteCancelLocationRequest,startProcessing_Two_Func) {
InterModuleData p_imd;
strcpy(p_imd.m_Parameters,"cANCEL_LOc");
bool p_DeleteFlag=true;
EXPECT_TRUE(startProcessing(&p_imd,p_DeleteFlag));
}*/


/*
TEST_F(UT_CtxtLteCancelLocationRequest,handleCancelLocationAnswer_Func) {
g_smplApi = new IDSCLApi;
Msg p_MsgPtr;
EXPECT_TRUE(handleCancelLocationAnswer(&p_MsgPtr));
}
*/

#undef private
