#define private public
#include<iostream>
#include"gtest.h"
#include <CtxtLteNotifyRequest.h>
#include <ExtendedServiceCoordinator.h>

#include <stdio.h>
#include <ServiceCoordinator.h>
#include <Logger.h>
#include <DbActiveObject.h>
#include <ConfigReader.h>
#include <LteMm2ConfigReader.h>
#include <DataUnion.h>
#include <Utilities.h>

#include <DiameterMessages.h>
#include <DiameterConstants.h>
#include <DiametriqInterface.h>
#include <Notify.h>
#include <CtxtLteNotifyRequest.h>
#include<Msg.h>

using namespace diameter::s6a_r10;
using namespace diameter::base;

//extern Msg *p_MsgPtr;

class UT_CtxtLteNotifyRequest: public testing::Test ,public CtxtLteNotifyRequest
{public:
UT_CtxtLteNotifyRequest()
{
}
~UT_CtxtLteNotifyRequest()
{
}
};

class UT_Msg
{public:
UT_Msg()
{
}
~UT_Msg()
{
}
};

/*
TEST_F(UT_CtxtLteNotifyRequest,processMessage_MSG_TYPE_MAP_Func) {
Msg o_MsgPtr;
o_MsgPtr.m_MsgType=1;
bool p_DeleteFlag=false;
EXPECT_TRUE(processMessage(&o_MsgPtr,p_DeleteFlag));
EXPECT_TRUE(p_MsgPtr->m_MsgType==1);
}
*/



#undef private

