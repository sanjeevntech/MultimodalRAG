#define private public
#include<iostream>
#include"gtest.h"
#include<LteMm2DbQueries.h>
#include <DbQueryMsg.h>
#include <HlrTdrFiller.h>
#include <ConfigReader.h>
#include <SubsProfileData.h>
#include <LteMm2CommonDefines.h>
#include <list>

class UT_NotifyDbData: public testing::Test ,public NotifyDbData
{public:
UT_NotifyDbData()
{
}
~UT_NotifyDbData()
{
}
};

class UT_ClrDbData: public testing::Test ,public ClrDbData
{public:
UT_ClrDbData()
{
}
~UT_ClrDbData()
{
}
};

TEST_F(UT_NotifyDbData,executeQuery_Func) {
int p_conn[]={1,2,3,4,5,6,7,8,9,10};
EXPECT_TRUE(executeQuery(p_conn));
}

TEST_F(UT_ClrDbData,executeQuery_Func) {
int p_conn[]={1,2,3,4,5,6,7,8,9,10};
EXPECT_TRUE(executeQuery(p_conn));
}

#undef private


