#!/bin/bash
for file in $1/*; do
    echo $(basename "$file")
    cksum $file > $file.cksum
done
