#ifndef __OAM_SIM_CONFIG_READER_H
#define __OAM_SIM_CONFIG_READER_H

#include <ConfigReader.h>
  
   class OamSimConfigReader: public ConfigReader
   {
      private:
  
    public:
        OamSimConfigReader();
        ~OamSimConfigReader();
 
        bool readData();
        void printConfigData(char *p_output);
 
        char m_msisdn[20];
  };
  extern OamSimConfigReader *g_OamSimConfigReaderObj;
  extern bool resetStruct(int p_version, int p_pdu, void *p_struct);
  #endif //CM_SIM_CONFIG_READER_H

