#ifndef __CONTEXT_ACTIVATE_TRACE_MODE_H
#define __CONTEXT_ACTIVATE_TRACE_MODE_H

#include <ContextBase.h>
#include <Msg.h>
#include <OamDbQueries.h>
#include <ServiceCoordinator.h>


class CtxtActivateTraceMode : public ContextBase
{
   private:
      bool sendv1ActTraceMode();
      bool sendv2ActTraceMode();
      bool sendv3ActTraceMode();

   public:
      CtxtActivateTraceMode();
      ~CtxtActivateTraceMode();

      bool updateDb(char, char *, int p_errorCode);


      bool processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag);
      bool startProcessing(InterModuleData *p_imd, bool& p_DeleteFlag);

      char m_TransId[20+1];
      string m_DataString;
      int m_UserDlgId;

      char m_imsi[MAX_IMSI_LEN+1];
      char m_lmsi[8+1];
      char m_OrigAddr[20+1];
      char m_DestAddr[20+1];
      char m_type[10+1];
};



#endif
