#ifndef __CONTEXT_RESET_H
#define __CONTEXT_RESET_H

#include <ContextBase.h>
#include <Msg.h>
#include <OamDbQueries.h>
#include <MapConstants.h>
#include <string>
using namespace std;

#define SSN_VLR 7
#define SSN_SGSN 149

class CtxtReset : public ContextBase
{
	private:
      string m_type;
      string m_hlr_address;
      string m_dest_address;
      string m_imsi_prefix;
      bool sendReset(char *p_type, char *p_hlrAddress, char *p_vlrAddress, char *p_imsiPrefix, EMapVersion);
      bool updateDb(char p_status, char *p_error);
      char m_TransId[20+1];

	public:
		CtxtReset();
		~CtxtReset();

      int m_imsiCount;
      string m_imsi[50];
      bool m_close_flag;
		bool startProcessing(InterModuleData *p_imd, bool &flag);

		bool processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag);

};



#endif
