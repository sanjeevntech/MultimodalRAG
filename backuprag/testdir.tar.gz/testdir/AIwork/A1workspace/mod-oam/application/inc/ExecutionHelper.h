#ifndef __EXECUTION_HELPER_H
#define __EXECUTION_HELPER_H

#include <ContextBase.h>
#include <Msg.h>
#include <ServiceCoordinator.h>
#include <string>

enum EHelperExecutionState
{
   HELPER_EXECUTION_STATE_INITIAL = 0,
   HELPER_EXECUTION_STATE_RELAY,
   HELPER_EXECUTION_STATE_FINISHED
};

class ExecutionHelper
{
   public:
      ExecutionHelper();
      virtual ~ExecutionHelper();

      EHelperExecutionState m_hes;
      int                   m_errCode;
      string                m_errDesc;
      string                m_body;

      ContextBase *m_mainContext;
      virtual bool startProcessingByHelper(Msg *p_MsgPtr, bool &p_DeleteFlag)=0;
      virtual bool processMessageByHelper(Msg *p_MsgPtr, bool &p_DeleteFlag)=0;
      bool setReturnValues(EHelperExecutionState, int, string, string);
};

extern ExecutionHelper *getExecutionHelper(int p_opCode);

#endif
