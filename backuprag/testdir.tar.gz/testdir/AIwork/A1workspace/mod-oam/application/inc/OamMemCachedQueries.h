#ifndef __OAM_MEMC_QUERIES_H
#define __OAM_MEMC_QUERIES_H

class OamMemCachedQueries 
{
   public:
      OamMemCachedQueries();
      ~OamMemCachedQueries();
};


#endif
