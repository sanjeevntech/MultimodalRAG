#ifndef __OAM_CONFIG_READER_H
#define __OAM_CONFIG_READER_H

#include <ConfigReader.h>

class OamConfigReader: public ConfigReader
{
   private:

   public:
      OamConfigReader();
      ~OamConfigReader();

      bool readData();
      void printConfigData(char *p_output);

      int m_DSD_MAP_VERSION;
      int m_SUBSCRIBER_TRACING_VERSION;
      int m_VlrResetEnabled;
      int m_SgsnResetEnabled;
      int m_ResetMapVer;
      int m_psiTimer;
      int m_MemcachedDeleteFlag;
};

extern OamConfigReader *g_OamConfigReaderObj;

#endif
