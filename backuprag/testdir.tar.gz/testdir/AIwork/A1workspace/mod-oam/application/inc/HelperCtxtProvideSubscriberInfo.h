#ifndef __HELPER_CONTEXT_PROVIDE_SUBSCRIBER_INFO_H
#define __HELPER_CONTEXT_PROVIDE_SUBSCRIBER_INFO_H

#include <ExecutionHelper.h>
#include <OamDbQueries.h>
#include <Msg.h>
#include <string>

class HelperCtxtProvideSubscriberInfo : public ExecutionHelper
{
   public:
      HelperCtxtProvideSubscriberInfo();
      ~HelperCtxtProvideSubscriberInfo();

      GenericXmlApiData *m_gxad;

      bool startProcessingByHelper(Msg *p_MsgPtr, bool &p_DeleteFlag);
      bool processMessageByHelper(Msg *p_MsgPtr, bool &p_DeleteFlag);
      bool handleError();
};

#endif
