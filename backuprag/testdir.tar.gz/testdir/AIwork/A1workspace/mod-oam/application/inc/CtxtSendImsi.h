#ifndef __CONTEXT_SEND_IMSI_H
#define __CONTEXT_SEND_IMSI_H

#include <ContextBase.h>
#include <Msg.h>
#include <OamDbQueries.h>

class CtxtSendImsi : public ContextBase
{
	public:
		CtxtSendImsi();
		~CtxtSendImsi();

      char m_OrigAddress[20];

		bool processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag);

};

#endif

