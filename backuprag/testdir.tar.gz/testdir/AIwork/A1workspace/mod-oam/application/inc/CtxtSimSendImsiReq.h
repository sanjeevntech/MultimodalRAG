#ifndef _CtxtSimSenImsiReq_H_
#define _CtxtSimSendImsiReq_H_
#include <ContextBase.h>
#include <Msg.h>
#include <MapConstants.h>
//#include "GmlcConfig.h"


class CtxtSimSendImsiReq : public ContextBase
{ 
   private:

   public:
      CtxtSimSendImsiReq();
      bool processMessage(Msg *p_MsgPtr,bool& p_DeleteFlag);
      bool startProcessing();
      bool sendSendImsiReq();
      virtual ~CtxtSimSendImsiReq();
};

#endif 
