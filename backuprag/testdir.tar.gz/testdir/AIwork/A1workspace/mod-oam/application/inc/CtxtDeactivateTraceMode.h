#ifndef __CONTEXT_DE_ACTIVATE_TRACE_MODE_H
#define __CONTEXT_DE_ACTIVATE_TRACE_MODE_H

#include <ContextBase.h>
#include <Msg.h>
#include <OamDbQueries.h>
#include <ServiceCoordinator.h>


class CtxtDeactivateTraceMode : public ContextBase
{
   private:
      bool sendv1DeactTraceMode();
      bool sendv2DeactTraceMode();
      bool sendv3DeactTraceMode();

   public:
      CtxtDeactivateTraceMode();
      ~CtxtDeactivateTraceMode();

      bool updateDb(char, char *);


      bool processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag);
      bool startProcessing(InterModuleData *p_imd, bool& p_DeleteFlag);

      char m_TransId[20+1];
      string m_DataString;
      int m_UserDlgId;
};



#endif
