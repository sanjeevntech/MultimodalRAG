#ifndef __OAM_DB_QUERIES_H
#define __OAM_DB_QUERIES_H

#include <DbQueryMsg.h>
#include <GlobalData.h>
#include <list>

//#define MAX_TRANS_XML_STRING_SIZE   5000
#define MAX_TRANS_XML_STRING_SIZE1   32767
#define MAX_IMSI_LEN                15
#define MAX_MSISDN_LEN              20
#define MAX_PIN_LEN                 5
#define MAX_PUK_LEN                 10
#define MAX_KI_LEN                  32
#define MAX_ACC_LEN                 5
#define MAX_ADM_LEN                 20
#define MAX_SQN_LEN                 6
#define MAX_XML_BODY_LEN1            32767
#define MAX_LOG_MSG_LEN1             32767
//#define MAX_OSS_TRIGGER_DATA        5
#define MAX_OSS_TRIGGER_DATA        10
#define MAX_REQUEST_TYPE_LEN        50
#define MAX_ROW_ID_LEN              30
#define MAX_USER_ID_LEN             50
#define MAX_FREE_FORMAT_TDR_LEN     1000
#define MAX_TRANS_REF_LEN           20
#define MAX_IP_ADDR_LEN             20
#define MAX_NUM_OF_SUBSCRIBERS      20
#define MAX_ICC_ID_LEN              20
#define MAX_ACCOUNT_ID_LEN          20
#define MAX_IMEI_LEN                39

#define MAX_ALL_SUBS_IMSI           (MAX_NUM_OF_SUBSCRIBERS*MAX_IMSI_LEN)
#define MAX_ALL_SUBS_MSISDN         (MAX_NUM_OF_SUBSCRIBERS*MAX_MSISDN_LEN)
#define MAX_ALL_SUBS_TDR_DATA       (MAX_NUM_OF_SUBSCRIBERS*MAX_FREE_FORMAT_TDR_LEN)
#define MAX_ALL_SUBS_ICC_ID         (MAX_NUM_OF_SUBSCRIBERS*MAX_ICC_ID_LEN)
#define MAX_ALL_SUBS_ACCOUNT_ID     (MAX_NUM_OF_SUBSCRIBERS*MAX_ACCOUNT_ID_LEN)


class RetrieveOamBulkTrans : public DbQueryMsg 
{
   public:
      RetrieveOamBulkTrans();
      ~RetrieveOamBulkTrans();

      bool executeQuery(void*);

      // Outputs
      list<char *> m_outputList;
};



class RetrieveOamTransData : public DbQueryMsg 
{
   public:
      RetrieveOamTransData();
      ~RetrieveOamTransData();

      bool executeQuery(void*);

      // Inputs
      char m_RowId[MAX_ROW_ID_LEN+1]; 

      // Outputs
      char m_TransId[20+1];;
      int  m_TransType;
      //char m_TransXml[MAX_TRANS_XML_STRING_SIZE+1];
      char *m_TransXml;
};

class RetrieveSendImsiData  : public DbQueryMsg
{
   public:
      RetrieveSendImsiData();
      ~RetrieveSendImsiData();

      bool executeQuery(void*);

      // Inputs
      char m_msisdn[20]; 
      char m_OrigAddress[20];

      // Outputs
      char m_imsi[20];
      char m_hlrAddress[20];
      int  m_networkId;
};


class UpdateOamTransData : public DbQueryMsg 
{
   public:
      UpdateOamTransData();
      ~UpdateOamTransData();

      bool executeQuery(void*);

      // Inputs
      char m_TransId[20+1]; 
      char m_Status;
      char m_ErrorCause[100+1];


      int  m_actTracingFlag;
      char m_type[10+1];
      char m_imsi[MAX_IMSI_LEN+1];
      int  m_errorCodeToBeUpdated;
};


class OssTriggerData
{
   public:
      OssTriggerData();
      ~OssTriggerData();
      char  m_rowId[MAX_ROW_ID_LEN+1]; 
      char  m_transId[20+1]; 
      int   m_opCode;
      //char  m_transXml[4000+1]; 
      char *m_transXml;
};

class DeleteMemcQuery : public MemCachedQueryMsg 
{
   public: 
      DeleteMemcQuery();
      ~DeleteMemcQuery();

      virtual void executeMemcQuery();
      virtual void serializeMemc();
      virtual bool deSerializeMemc();

      char m_primaryImsi[15+1];
};

class SoftDeleteMemcQuery : public MemCachedQueryMsg 
{
   public: 
      SoftDeleteMemcQuery();
      ~SoftDeleteMemcQuery();

      virtual void executeMemcQuery();
      virtual void serializeMemc();
      virtual bool deSerializeMemc();

      char m_primaryImsi[15+1];
      bool m_dataMemC;
};

class GenericXmlApiData: public DbQueryMsg 
{
   public:
      GenericXmlApiData();
      ~GenericXmlApiData();

      bool executeQuery(void*);

      // Inputs
      char              m_user       [MAX_USER_ID_LEN+1];
      char              m_ip         [MAX_IP_ADDR_LEN+1];
      char              m_requestType[MAX_REQUEST_TYPE_LEN+1];
      //char              m_xmlBody    [MAX_XML_BODY_LEN+1]; 
      char              *m_xmlBody;
      char              m_transactionRef[MAX_TRANS_REF_LEN+1]; 
      char              m_bulkTransId [MAX_TRANS_REF_LEN +1];

      // Outputs
      //char              m_channelResponseXml [MAX_XML_BODY_LEN+1]; 
      char              *m_channelResponseXml;
      int               m_ossTriggerDataCount;
      OssTriggerData    m_ossTriggerDataArray[MAX_OSS_TRIGGER_DATA];
      int               m_subs_data_count;
      char              m_subs_identity_imsi [MAX_ALL_SUBS_IMSI+1];
      char              m_subs_identity_msisdn[MAX_ALL_SUBS_MSISDN+1];
      char              m_subs_identity_flag;
      char              m_freeFormatTdrData[MAX_ALL_SUBS_TDR_DATA+1];
      char              m_primary_imsi [MAX_ALL_SUBS_IMSI+1];
      char              m_primary_msisdn[MAX_ALL_SUBS_MSISDN+1];
      char              m_icc_id [MAX_ICC_ID_LEN+1];
      char              m_account_id[MAX_ACCOUNT_ID_LEN+1];
      char              m_imei[MAX_IMEI_LEN+1];
      int               m_ossContinueOpCode;
      int               m_ossHelperOpCode;
      //char              m_ossHelperXml[MAX_XML_BODY_LEN+1]; 
      char              *m_ossHelperXml;
      //char              m_logMsg     [MAX_LOG_MSG_LEN+1]; 
      char              *m_logMsg;
      //char              m_trapCode   [20+1];
      char              m_trapCode   [100+1];
      char              m_trapDesc   [500+1];
      int               m_network_id;
      char              m_AltImsi [MAX_ALL_SUBS_IMSI+1];    //5054
      char              m_AltNewImsi [MAX_ALL_SUBS_IMSI+1];    //5054
      bool		m_MmeMemcached;
      char              m_StatsInfo_OUT[500+1];//6.4.1.0

      bool 		m_logTDRs;
};


class InsertBulkTransId : public DbQueryMsg 
{
   public:
      InsertBulkTransId();
      ~InsertBulkTransId();

      bool executeQuery(void*);

      // Inputs
      char m_user       [MAX_USER_ID_LEN+1];
      char m_ip         [MAX_IP_ADDR_LEN+1];
      char m_requestType[MAX_REQUEST_TYPE_LEN+1];
      int  m_count;
      bool 		m_logTDRs;

      // Outputs
      char m_TransId[20+1]; 
};


class InsertOamTransData : public DbQueryMsg 
{
   public:
      InsertOamTransData();
      ~InsertOamTransData();

      bool executeQuery(void*);

      // Inputs
      //char m_xml[MAX_TRANS_XML_STRING_SIZE+1]; 
      char *m_xml;
      int  m_opCode;
      char m_transRef[30+1];

      // Outputs
      char m_rowid[MAX_ROW_ID_LEN+1];
      char m_transId[20+1];
};


class ReloadConfigValues : public DbQueryMsg 
{
   public:
      ReloadConfigValues();
      ~ReloadConfigValues();

      bool executeQuery(void*);

      // Inputs
      char m_tempTransId[50+1];

      // Outputs
      TagValuePair *m_tvp;
};

#endif

