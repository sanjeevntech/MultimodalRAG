#ifndef __CONTEXT_OAM_H
#define __CONTEXT_OAM_H

#include <ContextBase.h>
#include <ExecutionHelper.h>
#include <Msg.h>
#include <ServiceCoordinator.h>
#include <string>

class CtxtOam : public ContextBase
{
   private:
      InterModuleData *m_imd;
      string m_oam_transactions;
      string m_reqType;
      int m_logTdrs;

   public:
      CtxtOam();
      ~CtxtOam();

      bool m_responseToBeSent;
      ExecutionHelper *m_executionHelper;

      bool processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag);
      bool startProcessing(InterModuleData *p_data, bool& p_DeleteFlag);

      bool sendResponse(int p_sockFd, int p_DeviceType, string& p_OrigEntity, string& p_IpAddress, string& p_transId, string& p_reqType, int p_errorCode, char *p_errorDesc, char *p_ResponseBody);

      bool postProcessAfterHelper();
};

#endif
