#ifndef __CONTEXT_DSD_H
#define __CONTEXT_DSD_H

#include <ContextBase.h>
#include <Msg.h>
#include <OamDbQueries.h>
#include <ServiceCoordinator.h>


class CtxtOamDeleteSubscriberData : public ContextBase
{
   private:
      bool sendv1Dsd();
      bool sendv2Dsd();
      bool sendv3Dsd();

   public:
      CtxtOamDeleteSubscriberData();
      ~CtxtOamDeleteSubscriberData();

      bool updateDb(char, char *);


      bool processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag);
      bool startProcessing(InterModuleData *p_imd, bool& p_DeleteFlag);

      char m_TransId[20+1];
      string m_DataString;
      int m_UserDlgId;
};



#endif
