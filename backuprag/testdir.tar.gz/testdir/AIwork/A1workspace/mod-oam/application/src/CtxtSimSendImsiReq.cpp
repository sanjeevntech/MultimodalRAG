#include <stdio.h>
#include <MapMessages.h>
#include <ServiceCoordinator.h>
#include <Logger.h>
#include "ConfigReader.h"
#include "CtxtSimSendImsiReq.h"
//#include "HLRCMEnums.h"
//#include "HLRCMConstants.h"
#include <DbActiveObject.h>
#include <DataUnion.h>
#include <IMAP3.h>
#include <IMAP2.h>
#include <IMAP1.h>
#include <OMAP3.h>
#include <OMAP2.h>
#include <OMAP1.h>
#include <Utilities.h>
#include <OamSimConfigReader.h>
/**************************************************************************************************
  Function Name      : CtxtSimSendImsiReq
Author               :
InParams             : void 
OutParam /return val : void
Description          : Constructor
 ****************************************************************************************************/


CtxtSimSendImsiReq :: CtxtSimSendImsiReq()
{
}


/**************************************************************************************************
  Function Name      : CtxtSimSendImsiReq
Author               :
InParams             : void 
OutParam /return val : void
Description          : Destructor
 ****************************************************************************************************/


CtxtSimSendImsiReq :: ~CtxtSimSendImsiReq()
{

}

bool CtxtSimSendImsiReq::startProcessing()
{
   sendSendImsiReq();
   return true;
}

bool CtxtSimSendImsiReq ::sendSendImsiReq()
{
   DECLARE(OMAP3_SendIMSIArg,l_tempSendImsi,3,"OMAP3_SendIMSIArg",resetStruct);
   int l_UserDlgId = g_sc.getNewDialogue();
   DLOG(l_UserDlgId,0,"###CtxtSendImsiReq### Start of CtxtSimSendImsiReq::sendSRIReq function");
   //printf("\n CtxtGmlcSriForLcsReq::sendSRI ######### SRI Request #############\n");

   DLOG(l_UserDlgId,0,"###CtxtSendImsiReq### Sending MapOpenReq ...");
   MapOpenReq l_mapOpenReq(l_UserDlgId, MAP_V3);

   l_mapOpenReq.m_ApplCntxt = MAP_AC_CODE_imsiRetrieval;
   l_mapOpenReq.m_DestAddr  = g_ConfigData->i_NgConfigData.m_remoteAddress1;

   g_sc.sendMsg(this, &l_mapOpenReq);

   DLOG(l_UserDlgId,0,"###CtxtSendImsiReq### CtxtSimSendImsiReq::sendImsi Sending MapSpecificRequest ...");
   MapSpecificRequest l_request(l_UserDlgId, MAP_OP_CODE_sendIMSI, MAP_V3);

   DLOG(0,0,"TEST 2");
//   l_tempSendImsi =  strlen(g_OamSimConfigReaderObj->m_msisdn);
   StringToBCD((unsigned char*)l_tempSendImsi, (unsigned char*)g_OamSimConfigReaderObj->m_msisdn, strlen(g_OamSimConfigReaderObj->m_msisdn));
   LLOG(0,0,"TargetMSISDN Req Length is %d Req TargetMSISDN Value is %s",strlen((const char*)l_tempSendImsi),(const char*)l_tempSendImsi);

   l_request.m_structBuffer = (void*)l_tempSendImsi;

   g_sc.sendMsg(this, &l_request);

   DLOG(0,0,"###CtxtSendImsiReq### Sending MapDelimiterReq Req ...");
   MapDelimiterReq l_del(l_UserDlgId);
   g_sc.sendMsg(this, &l_del);

   return true;
}

bool CtxtSimSendImsiReq ::processMessage(Msg *p_MsgPtr,bool& p_DeleteFlag)
{
   DLOG(0,0,"###CtxtSendImsiReq### Start of CtxtSimSendImsiReq::processMsg function");
   MapSpecificMsg *l_specMsg = NULL;
   int l_UserDlgId;

   switch (p_MsgPtr->m_MsgType)
   {
      case MSG_TYPE_MAP:
         switch (((MapMsg*)p_MsgPtr)->m_MapMsgType)
         {
            case MAP_MSG_TYPE_COMMON:
               switch (((MapCommonMsg*)p_MsgPtr)->m_MapCommonMsgType)
               {
                  case MAP_CMN_OPEN_IND:
                     DLOG(0,0,"###CtxtSendImsiReq### MAP_CMN_OPEN_IND received");
                     break;

                  case MAP_CMN_DELIMITER_IND:
                     DLOG(0,0,"###CtxtSendImsiReq### MAP_CMN_DELIMITER_IND received");
                     break;

                  case MAP_CMN_CLOSE_IND:
                     DLOG(0,0,"###CtxtSendImsiReq### MAP_CMN_CLOSE_IND received");
                     return true;
                     break;

                  case MAP_CMN_U_ABORT_IND:
                     TLOG(0,0,"###CtxtSendImsiReq### MAP_CMN_U_ABORT_IND received");
                     break;

                  case MAP_CMN_P_ABORT_IND:
                     TLOG(0,0,"###CtxtSendImsiReq### MAP_CMN_P_ABORT_IND received");
                     break;

                  case MAP_CMN_NOTICE_IND:
                     {
                        TLOG(0,0,"###CtxtSendImsiReq### MAP_CMN_NOTICE_IND received");
                     }
                     break;

                  default:
                     TLOG(0,0,"###CtxtSendImsiReq### Unknown Msg received [%d]", ((MapCommonMsg*)p_MsgPtr)->m_MapCommonMsgType);
                     break;
               }
               break;

            case MAP_MSG_TYPE_SPECIFIC:
               DLOG(0,0,"###CtxtSendImsiReq### MAP_MSG_TYPE_SPECIFIC received");
               l_specMsg = (MapSpecificMsg*)p_MsgPtr;
               l_UserDlgId = l_specMsg->m_UserDlgId;
               TLOG(0,0,"CtxtSendImsiReq MAP_MSG_TYPE_SPECIFIC received UserDlgId[%d]",
                     l_UserDlgId);

               switch (((MapSpecificMsg*)p_MsgPtr)->m_MapSpecificEventType)
               {
                  case MAP_SPEC_EVENT_INDICATION:
                     {
                        DLOG(l_UserDlgId,0,"###CtxtSendImsiReq### MAP_SPEC_EVENT_INDICATION received");

                        switch (((MapSpecificMsg*)p_MsgPtr)->m_OpCode)
                        {
                           case MAP_OP_CODE_sendIMSI:
                              {
                                 DLOG(l_UserDlgId,0,"###CtxtSendImsiReq### Received SendImsi");
                              }
                              break;

                           default:
                              DLOG(l_UserDlgId,0,"###CtxtSendImsiReq### Received Unknown Specific Message");
                              break;

                        }

                     }

                     break;

                  case MAP_SPEC_EVENT_RESULT:
                     {
                        DLOG(l_UserDlgId,0,"###CtxtSendImsiReq### MAP_SPEC_EVENT_RESULT received");
                     }
                     break;

                  case MAP_SPEC_EVENT_CONFIRMATION:
                     {
                        DLOG(l_UserDlgId,0,"CtxtSendImsiReq MAP_SPEC_EVENT_CONFIRMATION received");
                        switch (((MapSpecificMsg*)p_MsgPtr)->m_OpCode)
                        {
                           case MAP_OP_CODE_sendRoutingInfo:
                              { 

                              }
                              break;

                           default:
                              break;

                        }
                     }
                     break;

                  case MAP_SPEC_EVENT_USER_ERROR:
                     {
                        TLOG(l_UserDlgId,0,"###CtxtSendImsiReq### MAP_SPEC_EVENT_USER_ERROR received");
                     }
                     break;

                  case MAP_SPEC_EVENT_PROV_ERROR:
                     {
                        TLOG(l_UserDlgId,0,"###CtxtSendImsiReq### MAP_SPEC_EVENT_PROV_ERROR received");
                        DLOG(l_UserDlgId,0,"###CtxtSendImsiReq### Closing the Dialogue");
                        MapCloseReq l_closeReq(((MapSpecificMsg*)p_MsgPtr)->m_UserDlgId);
                        g_sc.sendMsg(this, &l_closeReq);
                     }
                     break;
                  default:
                     ELOG(l_UserDlgId,0,"###CtxtSendImsiReq### ERROR!! Default received");
                     break;

               }


               break;

            default:
               break;
         }
         break;

      case MSG_TYPE_DB:
         {
         }
         break;

      default:
         DLOG(0,0,"###CtxtSendImsiReq### Unknown message received");
         break;

   }
   return true;

}






