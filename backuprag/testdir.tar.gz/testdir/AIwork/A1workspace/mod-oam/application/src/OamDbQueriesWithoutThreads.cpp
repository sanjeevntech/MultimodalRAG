
/* Result Sets Interface */
#ifndef SQL_CRSR
#  define SQL_CRSR
  struct sql_cursor
  {
    unsigned int curocn;
    void *ptr1;
    void *ptr2;
    unsigned int magic;
  };
  typedef struct sql_cursor sql_cursor;
  typedef struct sql_cursor SQL_CURSOR;
#endif /* SQL_CRSR */

/* Thread Safety */
typedef void * sql_context;
typedef void * SQL_CONTEXT;

/* Object support */
struct sqltvn
{
  unsigned char *tvnvsn; 
  unsigned short tvnvsnl; 
  unsigned char *tvnnm;
  unsigned short tvnnml; 
  unsigned char *tvnsnm;
  unsigned short tvnsnml;
};
typedef struct sqltvn sqltvn;

struct sqladts
{
  unsigned int adtvsn; 
  unsigned short adtmode; 
  unsigned short adtnum;  
  sqltvn adttvn[1];       
};
typedef struct sqladts sqladts;

static struct sqladts sqladt = {
  1,1,0,
};

/* Binding to PL/SQL Records */
struct sqltdss
{
  unsigned int tdsvsn; 
  unsigned short tdsnum; 
  unsigned char *tdsval[1]; 
};
typedef struct sqltdss sqltdss;
static struct sqltdss sqltds =
{
  1,
  0,
};

/* File name & Package Name */
struct sqlcxp
{
  unsigned short fillen;
           char  filnam[16];
};
static const struct sqlcxp sqlfpn =
{
    15,
    "OamDbQueries.pc"
};


static unsigned int sqlctx = 2430883;


static struct sqlexd {
   unsigned long  sqlvsn;
   unsigned int   arrsiz;
   unsigned int   iters;
   unsigned int   offset;
   unsigned short selerr;
   unsigned short sqlety;
   unsigned int   occurs;
      const short *cud;
   unsigned char  *sqlest;
      const char  *stmt;
   sqladts *sqladtp;
   sqltdss *sqltdsp;
   unsigned char  **sqphsv;
   unsigned long  *sqphsl;
            int   *sqphss;
            short **sqpind;
            int   *sqpins;
   unsigned long  *sqparm;
   unsigned long  **sqparc;
   unsigned short  *sqpadto;
   unsigned short  *sqptdso;
   unsigned int   sqlcmax;
   unsigned int   sqlcmin;
   unsigned int   sqlcincr;
   unsigned int   sqlctimeout;
   unsigned int   sqlcnowait;
            int   sqfoff;
   unsigned int   sqcmod;
   unsigned int   sqfmod;
   unsigned char  *sqhstv[13];
   unsigned long  sqhstl[13];
            int   sqhsts[13];
            short *sqindv[13];
            int   sqinds[13];
   unsigned long  sqharm[13];
   unsigned long  *sqharc[13];
   unsigned short  sqadto[13];
   unsigned short  sqtdso[13];
} sqlstm = {12,13};

// Prototypes
extern "C" {
  void sqlcxt (void **, unsigned int *,
               struct sqlexd *, const struct sqlcxp *);
  void sqlcx2t(void **, unsigned int *,
               struct sqlexd *, const struct sqlcxp *);
  void sqlbuft(void **, char *);
  void sqlgs2t(void **, char *);
  void sqlorat(void **, unsigned int *, void *);
}

// Forms Interface
static const int IAPSUCC = 0;
static const int IAPFAIL = 1403;
static const int IAPFTL  = 535;
extern "C" { void sqliem(char *, int *); }

 static const char *sq0009 = 
"select ROWID  from HLR_OAM_TRANSACTIONS where (TRANS_STATUS='P' and INSERTED\
_DATE<(sysdate-(1/24)))           ";

typedef struct { unsigned short len; unsigned char arr[1]; } VARCHAR;
typedef struct { unsigned short len; unsigned char arr[1]; } varchar;

/* cud (compilation unit data) array */
static const short sqlcud0[] =
{12,4130,1,0,0,
5,0,0,0,0,0,56,116,0,0,1,1,0,1,0,3,102,0,0,
24,0,0,1,437,0,6,117,0,0,13,13,0,1,0,1,9,0,0,1,9,0,0,1,9,0,0,1,9,0,0,2,3,0,0,2,
102,0,0,2,9,0,0,2,9,0,0,2,9,0,0,2,1,0,0,2,9,0,0,2,3,0,0,2,9,0,0,
91,0,0,0,0,0,13,150,0,0,2,1,0,1,0,1,102,0,0,2,9,0,0,
114,0,0,0,0,0,78,186,0,0,1,1,0,1,0,3,102,0,0,
133,0,0,2,154,0,6,240,0,0,5,5,0,1,0,1,9,0,0,2,9,0,0,2,9,0,0,2,3,0,0,2,9,0,0,
168,0,0,3,67,0,4,319,0,0,2,1,0,1,0,2,3,0,0,1,9,0,0,
191,0,0,4,71,0,4,326,0,0,2,1,0,1,0,2,1,0,0,1,9,0,0,
214,0,0,5,146,0,4,339,0,0,4,1,0,1,0,2,9,0,0,2,3,0,0,2,9,0,0,1,9,0,0,
245,0,0,6,102,0,5,360,0,0,2,2,0,1,0,1,9,0,0,1,9,0,0,
268,0,0,7,0,0,29,365,0,0,0,0,0,1,0,
283,0,0,8,111,0,4,424,0,0,1,0,0,1,0,2,3,0,0,
302,0,0,9,110,0,9,438,0,0,0,0,0,1,0,
317,0,0,9,0,0,13,442,0,0,1,0,0,1,0,2,9,0,0,
336,0,0,9,0,0,15,459,0,0,0,0,0,1,0,
351,0,0,10,126,0,5,554,0,0,4,4,0,1,0,1,1,0,0,1,9,0,0,1,9,0,0,1,9,0,0,
382,0,0,11,0,0,29,561,0,0,0,0,0,1,0,
397,0,0,12,69,0,4,567,0,0,2,1,0,1,0,2,9,0,0,1,9,0,0,
420,0,0,13,70,0,5,574,0,0,2,2,0,1,0,1,3,0,0,1,9,0,0,
443,0,0,14,71,0,5,580,0,0,2,2,0,1,0,1,3,0,0,1,9,0,0,
466,0,0,15,0,0,29,589,0,0,0,0,0,1,0,
};


#include <OamDbQueries.h>
#include <Logger.h>
#include <stdio.h>
#include <strings.h>
#include <sqlca.h>
#include <sqlda.h>
#include <Utilities.h>


/////////////////////////////////////////////////////////////////////////////////


OssTriggerData::OssTriggerData()
{
   memset(m_rowId, '\0', sizeof(m_rowId));
}

OssTriggerData::~OssTriggerData()
{
}

GenericXmlApiData::GenericXmlApiData()
{
   memset(m_requestType, '\0', sizeof(m_requestType));
   memset(m_xmlBody, '\0', sizeof(m_xmlBody));
   memset(m_channelResponseXml, '\0', sizeof(m_channelResponseXml));
   m_ossTriggerDataCount=0;
   memset(m_ossTriggerDataArray, '\0', sizeof(m_ossTriggerDataArray));
   memset(m_user, '\0', sizeof(m_user));
   memset(m_subs_identity_imsi, '\0', sizeof(m_subs_identity_imsi));
   memset(m_subs_identity_msisdn, '\0', sizeof(m_subs_identity_msisdn));
   m_subs_identity_flag = '\0';
   memset(m_transactionRef, '\0', sizeof(m_transactionRef));
   memset(m_freeFormatTdrData, '\0', sizeof(m_freeFormatTdrData));
}

GenericXmlApiData::~GenericXmlApiData()
{
}

bool GenericXmlApiData::executeQuery(void *p_conn)
{
   struct sqlca sqlca;
   LLOG(0,0,"GenericXmlApiData called");
   /* EXEC SQL BEGIN DECLARE SECTION; */ 

      // Inputs
      /* VARCHAR           l_xmlBodyInput       [MAX_XML_BODY_LEN+1]; */ 
struct { unsigned short len; unsigned char arr[4001]; } l_xmlBodyInput;
 
      /* VARCHAR           l_requestType        [MAX_REQUEST_TYPE_LEN+1]; */ 
struct { unsigned short len; unsigned char arr[51]; } l_requestType;

      /* VARCHAR           l_user               [MAX_USER_ID_LEN+1]; */ 
struct { unsigned short len; unsigned char arr[31]; } l_user;

      /* VARCHAR           l_transactionRef     [MAX_TRANS_REF_LEN+1]; */ 
struct { unsigned short len; unsigned char arr[21]; } l_transactionRef;


      // Outputs
      /* VARCHAR           l_channelResponseXml [MAX_XML_BODY_LEN+1]; */ 
struct { unsigned short len; unsigned char arr[4001]; } l_channelResponseXml;
 short l_channelResponseXml_ind;
      int               l_ossTriggerDataCount;                     short l_ossTriggerDataCount_ind;

      int               l_errCode;                                 short l_errCode_ind;
      /* VARCHAR           l_errMsg[200]; */ 
struct { unsigned short len; unsigned char arr[200]; } l_errMsg;
                             short l_errMsg_ind;

      /* VARCHAR           l_identityImsi[MAX_IMSI_LEN]; */ 
struct { unsigned short len; unsigned char arr[15]; } l_identityImsi;
              short l_identityImsi_ind;
      /* VARCHAR           l_identityMsisdn[MAX_MSISDN_LEN]; */ 
struct { unsigned short len; unsigned char arr[20]; } l_identityMsisdn;
          short l_identityMsisdn_ind;
      char              l_identityFlag;                            short l_identityFlag_ind;
      /* VARCHAR           l_freeFormatTdrData[MAX_FREE_FORMAT_TDR_LEN]; */ 
struct { unsigned short len; unsigned char arr[200]; } l_freeFormatTdrData;
short l_freeFormatTdrData_ind;

      // cursor variables
      sql_cursor        l_cur;                                     short l_cur_ind;
      /* VARCHAR           l_rowid[MAX_ROW_ID_LEN+1]; */ 
struct { unsigned short len; unsigned char arr[31]; } l_rowid;
 
   /* EXEC SQL END DECLARE SECTION; */ 



   //Indicator Variables initialization
   l_channelResponseXml_ind=0;
   l_ossTriggerDataCount_ind=0;
   l_errCode_ind=0;        
   l_errMsg_ind=0;             
   l_identityImsi_ind=0;      
   l_identityMsisdn_ind=0;     
   l_identityFlag_ind=0;       
   l_freeFormatTdrData_ind=0;
   l_cur_ind=0;

   //Inputs memsets
   bzero(&l_requestType, sizeof(l_requestType));
   strncpy((char*)l_requestType.arr, m_requestType, MAX_REQUEST_TYPE_LEN);
   l_requestType.len = strlen((char*)l_requestType.arr);

   bzero(&l_xmlBodyInput, sizeof(l_xmlBodyInput));
   strncpy((char*)l_xmlBodyInput.arr, m_xmlBody, MAX_XML_BODY_LEN);
   l_xmlBodyInput.len = strlen((char*)l_xmlBodyInput.arr);

   bzero(&l_user, sizeof(l_user));
   strncpy((char*)l_user.arr, m_user, MAX_USER_ID_LEN);
   l_user.len = strlen((char*)l_user.arr);

   bzero(&l_transactionRef, sizeof(l_transactionRef));
   strncpy((char*)l_transactionRef.arr, m_transactionRef, MAX_TRANS_REF_LEN);
   l_transactionRef.len = strlen((char*)l_transactionRef.arr);

   memset(&l_cur, '\0', sizeof(l_cur));


   //Outputs
   bzero(&l_channelResponseXml, sizeof(l_channelResponseXml));
   l_ossTriggerDataCount=0;
   l_errCode=-1;
   bzero(&l_errMsg, sizeof(l_errMsg));
   bzero(&l_identityImsi, sizeof(l_identityImsi));
   bzero(&l_identityMsisdn, sizeof(l_identityMsisdn));
   l_identityFlag='\0';
   bzero(&l_freeFormatTdrData, sizeof(l_freeFormatTdrData));

   LLOG(0,1,"GenericXmlApiData calling with Request Type [%s], XML input [%s], User [%s]", 
			(char*)l_requestType.arr, (char*)l_xmlBodyInput.arr, (char*)l_user.arr);

   /* EXEC SQL CONTEXT USE :p_conn; */ 


   /* EXEC SQL ALLOCATE :l_cur; */ 

{
   struct sqlexd sqlstm;
   sqlstm.sqlvsn = 12;
   sqlstm.arrsiz = 1;
   sqlstm.sqladtp = &sqladt;
   sqlstm.sqltdsp = &sqltds;
   sqlstm.stmt = "";
   sqlstm.iters = (unsigned int  )1;
   sqlstm.offset = (unsigned int  )5;
   sqlstm.cud = sqlcud0;
   sqlstm.sqlest = (unsigned char  *)&sqlca;
   sqlstm.sqlety = (unsigned short)256;
   sqlstm.occurs = (unsigned int  )0;
   sqlstm.sqhstv[0] = (unsigned char  *)&l_cur;
   sqlstm.sqhstl[0] = (unsigned long )sizeof(int);
   sqlstm.sqhsts[0] = (         int  )0;
   sqlstm.sqindv[0] = (         short *)0;
   sqlstm.sqinds[0] = (         int  )0;
   sqlstm.sqharm[0] = (unsigned long )0;
   sqlstm.sqadto[0] = (unsigned short )0;
   sqlstm.sqtdso[0] = (unsigned short )0;
   sqlstm.sqphsv = sqlstm.sqhstv;
   sqlstm.sqphsl = sqlstm.sqhstl;
   sqlstm.sqphss = sqlstm.sqhsts;
   sqlstm.sqpind = sqlstm.sqindv;
   sqlstm.sqpins = sqlstm.sqinds;
   sqlstm.sqparm = sqlstm.sqharm;
   sqlstm.sqparc = sqlstm.sqharc;
   sqlstm.sqpadto = sqlstm.sqadto;
   sqlstm.sqptdso = sqlstm.sqtdso;
   sqlcxt(&p_conn, &sqlctx, &sqlstm, &sqlfpn);
}


   /* EXEC SQL EXECUTE
      BEGIN
      hlr_pkg_xml_request.mboss_iface(
                        :l_requestType,
                        :l_xmlBodyInput,
                        :l_user,
                        :l_transactionRef,
                        :l_ossTriggerDataCount:l_ossTriggerDataCount_ind,
                        :l_cur,
                        :l_channelResponseXml:l_channelResponseXml_ind,
                        :l_identityImsi:l_identityImsi_ind,
                        :l_identityMsisdn:l_identityMsisdn_ind,
                        :l_identityFlag:l_identityFlag_ind,
                        :l_freeFormatTdrData:l_freeFormatTdrData_ind,
                        :l_errCode:l_errCode_ind,
                        :l_errMsg:l_errMsg_ind
                        );
   END;
   END-EXEC; */ 

{
   struct sqlexd sqlstm;
   sqlstm.sqlvsn = 12;
   sqlstm.arrsiz = 13;
   sqlstm.sqladtp = &sqladt;
   sqlstm.sqltdsp = &sqltds;
   sqlstm.stmt = "begin hlr_pkg_xml_request . mboss_iface ( :l_requestType ,\
 :l_xmlBodyInput , :l_user , :l_transactionRef , :l_ossTriggerDataCount:l_ossT\
riggerDataCount_ind , :l_cur , :l_channelResponseXml:l_channelResponseXml_ind \
, :l_identityImsi:l_identityImsi_ind , :l_identityMsisdn:l_identityMsisdn_ind \
, :l_identityFlag:l_identityFlag_ind , :l_freeFormatTdrData:l_freeFormatTdrDat\
a_ind , :l_errCode:l_errCode_ind , :l_errMsg:l_errMsg_ind ) ; END ;";
   sqlstm.iters = (unsigned int  )1;
   sqlstm.offset = (unsigned int  )24;
   sqlstm.cud = sqlcud0;
   sqlstm.sqlest = (unsigned char  *)&sqlca;
   sqlstm.sqlety = (unsigned short)256;
   sqlstm.occurs = (unsigned int  )0;
   sqlstm.sqhstv[0] = (unsigned char  *)&l_requestType;
   sqlstm.sqhstl[0] = (unsigned long )53;
   sqlstm.sqhsts[0] = (         int  )0;
   sqlstm.sqindv[0] = (         short *)0;
   sqlstm.sqinds[0] = (         int  )0;
   sqlstm.sqharm[0] = (unsigned long )0;
   sqlstm.sqadto[0] = (unsigned short )0;
   sqlstm.sqtdso[0] = (unsigned short )0;
   sqlstm.sqhstv[1] = (unsigned char  *)&l_xmlBodyInput;
   sqlstm.sqhstl[1] = (unsigned long )4003;
   sqlstm.sqhsts[1] = (         int  )0;
   sqlstm.sqindv[1] = (         short *)0;
   sqlstm.sqinds[1] = (         int  )0;
   sqlstm.sqharm[1] = (unsigned long )0;
   sqlstm.sqadto[1] = (unsigned short )0;
   sqlstm.sqtdso[1] = (unsigned short )0;
   sqlstm.sqhstv[2] = (unsigned char  *)&l_user;
   sqlstm.sqhstl[2] = (unsigned long )33;
   sqlstm.sqhsts[2] = (         int  )0;
   sqlstm.sqindv[2] = (         short *)0;
   sqlstm.sqinds[2] = (         int  )0;
   sqlstm.sqharm[2] = (unsigned long )0;
   sqlstm.sqadto[2] = (unsigned short )0;
   sqlstm.sqtdso[2] = (unsigned short )0;
   sqlstm.sqhstv[3] = (unsigned char  *)&l_transactionRef;
   sqlstm.sqhstl[3] = (unsigned long )23;
   sqlstm.sqhsts[3] = (         int  )0;
   sqlstm.sqindv[3] = (         short *)0;
   sqlstm.sqinds[3] = (         int  )0;
   sqlstm.sqharm[3] = (unsigned long )0;
   sqlstm.sqadto[3] = (unsigned short )0;
   sqlstm.sqtdso[3] = (unsigned short )0;
   sqlstm.sqhstv[4] = (unsigned char  *)&l_ossTriggerDataCount;
   sqlstm.sqhstl[4] = (unsigned long )sizeof(int);
   sqlstm.sqhsts[4] = (         int  )0;
   sqlstm.sqindv[4] = (         short *)&l_ossTriggerDataCount_ind;
   sqlstm.sqinds[4] = (         int  )0;
   sqlstm.sqharm[4] = (unsigned long )0;
   sqlstm.sqadto[4] = (unsigned short )0;
   sqlstm.sqtdso[4] = (unsigned short )0;
   sqlstm.sqhstv[5] = (unsigned char  *)&l_cur;
   sqlstm.sqhstl[5] = (unsigned long )sizeof(int);
   sqlstm.sqhsts[5] = (         int  )0;
   sqlstm.sqindv[5] = (         short *)0;
   sqlstm.sqinds[5] = (         int  )0;
   sqlstm.sqharm[5] = (unsigned long )0;
   sqlstm.sqadto[5] = (unsigned short )0;
   sqlstm.sqtdso[5] = (unsigned short )0;
   sqlstm.sqhstv[6] = (unsigned char  *)&l_channelResponseXml;
   sqlstm.sqhstl[6] = (unsigned long )4003;
   sqlstm.sqhsts[6] = (         int  )0;
   sqlstm.sqindv[6] = (         short *)&l_channelResponseXml_ind;
   sqlstm.sqinds[6] = (         int  )0;
   sqlstm.sqharm[6] = (unsigned long )0;
   sqlstm.sqadto[6] = (unsigned short )0;
   sqlstm.sqtdso[6] = (unsigned short )0;
   sqlstm.sqhstv[7] = (unsigned char  *)&l_identityImsi;
   sqlstm.sqhstl[7] = (unsigned long )17;
   sqlstm.sqhsts[7] = (         int  )0;
   sqlstm.sqindv[7] = (         short *)&l_identityImsi_ind;
   sqlstm.sqinds[7] = (         int  )0;
   sqlstm.sqharm[7] = (unsigned long )0;
   sqlstm.sqadto[7] = (unsigned short )0;
   sqlstm.sqtdso[7] = (unsigned short )0;
   sqlstm.sqhstv[8] = (unsigned char  *)&l_identityMsisdn;
   sqlstm.sqhstl[8] = (unsigned long )22;
   sqlstm.sqhsts[8] = (         int  )0;
   sqlstm.sqindv[8] = (         short *)&l_identityMsisdn_ind;
   sqlstm.sqinds[8] = (         int  )0;
   sqlstm.sqharm[8] = (unsigned long )0;
   sqlstm.sqadto[8] = (unsigned short )0;
   sqlstm.sqtdso[8] = (unsigned short )0;
   sqlstm.sqhstv[9] = (unsigned char  *)&l_identityFlag;
   sqlstm.sqhstl[9] = (unsigned long )1;
   sqlstm.sqhsts[9] = (         int  )0;
   sqlstm.sqindv[9] = (         short *)&l_identityFlag_ind;
   sqlstm.sqinds[9] = (         int  )0;
   sqlstm.sqharm[9] = (unsigned long )0;
   sqlstm.sqadto[9] = (unsigned short )0;
   sqlstm.sqtdso[9] = (unsigned short )0;
   sqlstm.sqhstv[10] = (unsigned char  *)&l_freeFormatTdrData;
   sqlstm.sqhstl[10] = (unsigned long )202;
   sqlstm.sqhsts[10] = (         int  )0;
   sqlstm.sqindv[10] = (         short *)&l_freeFormatTdrData_ind;
   sqlstm.sqinds[10] = (         int  )0;
   sqlstm.sqharm[10] = (unsigned long )0;
   sqlstm.sqadto[10] = (unsigned short )0;
   sqlstm.sqtdso[10] = (unsigned short )0;
   sqlstm.sqhstv[11] = (unsigned char  *)&l_errCode;
   sqlstm.sqhstl[11] = (unsigned long )sizeof(int);
   sqlstm.sqhsts[11] = (         int  )0;
   sqlstm.sqindv[11] = (         short *)&l_errCode_ind;
   sqlstm.sqinds[11] = (         int  )0;
   sqlstm.sqharm[11] = (unsigned long )0;
   sqlstm.sqadto[11] = (unsigned short )0;
   sqlstm.sqtdso[11] = (unsigned short )0;
   sqlstm.sqhstv[12] = (unsigned char  *)&l_errMsg;
   sqlstm.sqhstl[12] = (unsigned long )202;
   sqlstm.sqhsts[12] = (         int  )0;
   sqlstm.sqindv[12] = (         short *)&l_errMsg_ind;
   sqlstm.sqinds[12] = (         int  )0;
   sqlstm.sqharm[12] = (unsigned long )0;
   sqlstm.sqadto[12] = (unsigned short )0;
   sqlstm.sqtdso[12] = (unsigned short )0;
   sqlstm.sqphsv = sqlstm.sqhstv;
   sqlstm.sqphsl = sqlstm.sqhstl;
   sqlstm.sqphss = sqlstm.sqhsts;
   sqlstm.sqpind = sqlstm.sqindv;
   sqlstm.sqpins = sqlstm.sqinds;
   sqlstm.sqparm = sqlstm.sqharm;
   sqlstm.sqparc = sqlstm.sqharc;
   sqlstm.sqpadto = sqlstm.sqadto;
   sqlstm.sqptdso = sqlstm.sqtdso;
   sqlcxt(&p_conn, &sqlctx, &sqlstm, &sqlfpn);
}



   LLOG(0,0,"GenericXmlApiData new result code:%d msg:%s sqlca:%d", l_errCode, (char*)l_errMsg.arr, sqlca.sqlcode);

   LLOG(0,1,"GenericXmlApiData end with outputs Count:[%d], ChannelResponseXml: [%s], code:%d msg:%s Imsi[%s], Msisdn[%s], Flag[%c], TdrData[%s]", 
               l_ossTriggerDataCount, l_channelResponseXml.arr, l_errCode, (char*)l_errMsg.arr,
               (char*)l_identityImsi.arr, (char*)l_identityMsisdn.arr, l_identityFlag, (char*)l_freeFormatTdrData.arr);

   if(0 == l_errCode)
   {
      LLOG(0,1,"GenericXmlApiData successfull ");
      for(int l_index=0; l_index<l_ossTriggerDataCount; l_index++)
      {
         bzero(&l_rowid, sizeof(l_rowid));

         /* EXEC SQL FETCH :l_cur INTO :l_rowid; */ 

{
         struct sqlexd sqlstm;
         sqlstm.sqlvsn = 12;
         sqlstm.arrsiz = 13;
         sqlstm.sqladtp = &sqladt;
         sqlstm.sqltdsp = &sqltds;
         sqlstm.iters = (unsigned int  )1;
         sqlstm.offset = (unsigned int  )91;
         sqlstm.selerr = (unsigned short)1;
         sqlstm.cud = sqlcud0;
         sqlstm.sqlest = (unsigned char  *)&sqlca;
         sqlstm.sqlety = (unsigned short)256;
         sqlstm.occurs = (unsigned int  )0;
         sqlstm.sqfoff = (         int )0;
         sqlstm.sqfmod = (unsigned int )2;
         sqlstm.sqhstv[0] = (unsigned char  *)&l_cur;
         sqlstm.sqhstl[0] = (unsigned long )sizeof(int);
         sqlstm.sqhsts[0] = (         int  )0;
         sqlstm.sqindv[0] = (         short *)0;
         sqlstm.sqinds[0] = (         int  )0;
         sqlstm.sqharm[0] = (unsigned long )0;
         sqlstm.sqadto[0] = (unsigned short )0;
         sqlstm.sqtdso[0] = (unsigned short )0;
         sqlstm.sqhstv[1] = (unsigned char  *)&l_rowid;
         sqlstm.sqhstl[1] = (unsigned long )33;
         sqlstm.sqhsts[1] = (         int  )0;
         sqlstm.sqindv[1] = (         short *)0;
         sqlstm.sqinds[1] = (         int  )0;
         sqlstm.sqharm[1] = (unsigned long )0;
         sqlstm.sqadto[1] = (unsigned short )0;
         sqlstm.sqtdso[1] = (unsigned short )0;
         sqlstm.sqphsv = sqlstm.sqhstv;
         sqlstm.sqphsl = sqlstm.sqhstl;
         sqlstm.sqphss = sqlstm.sqhsts;
         sqlstm.sqpind = sqlstm.sqindv;
         sqlstm.sqpins = sqlstm.sqinds;
         sqlstm.sqparm = sqlstm.sqharm;
         sqlstm.sqparc = sqlstm.sqharc;
         sqlstm.sqpadto = sqlstm.sqadto;
         sqlstm.sqptdso = sqlstm.sqtdso;
         sqlcxt(&p_conn, &sqlctx, &sqlstm, &sqlfpn);
}



         if (0 == sqlca.sqlcode)
         {
            LLOG(0,0,"GenericXmlApiData l_rowid [%s]",(char*)l_rowid.arr);
            strcpy(m_ossTriggerDataArray[m_ossTriggerDataCount].m_rowId, (char*)l_rowid.arr);;
            m_ossTriggerDataCount++;
         }
         else
         {
            ELOG(0,1,"GenericXmlApiData sqlca code for index %d is %d", l_index, sqlca.sqlcode);
	         break;
         }

      }
      m_DbQueryRes = DB_QUERY_RES_SUCCESS;	

      strncpy(m_channelResponseXml, (char*)l_channelResponseXml.arr, l_channelResponseXml.len);
      strncpy(m_subs_identity_imsi, (char*)l_identityImsi.arr, l_identityImsi.len);
      strncpy(m_subs_identity_msisdn, (char*)l_identityMsisdn.arr, l_identityMsisdn.len);
      m_subs_identity_flag=l_identityFlag;
      strncpy(m_freeFormatTdrData, (char*)l_freeFormatTdrData.arr, l_freeFormatTdrData.len);
   }
   else
   {
      WLOG(0,0,"GenericXmlApiData failed");
      m_DbQueryRes = DB_QUERY_RES_CODE_EXCEPTION;
      strncpy(m_subs_identity_imsi, (char*)l_identityImsi.arr, l_identityImsi.len);
      strncpy(m_subs_identity_msisdn, (char*)l_identityMsisdn.arr, l_identityMsisdn.len);
      m_subs_identity_flag=l_identityFlag;
      strncpy(m_freeFormatTdrData, (char*)l_freeFormatTdrData.arr, l_freeFormatTdrData.len);
   }
   m_procErrorCode = l_errCode;
   m_sqlcode = sqlca.sqlcode;
   strcpy(m_procErrorMessage, (char*)l_errMsg.arr);

   /* EXEC SQL FREE :l_cur; */ 

{
   struct sqlexd sqlstm;
   sqlstm.sqlvsn = 12;
   sqlstm.arrsiz = 13;
   sqlstm.sqladtp = &sqladt;
   sqlstm.sqltdsp = &sqltds;
   sqlstm.stmt = "";
   sqlstm.iters = (unsigned int  )1;
   sqlstm.offset = (unsigned int  )114;
   sqlstm.cud = sqlcud0;
   sqlstm.sqlest = (unsigned char  *)&sqlca;
   sqlstm.sqlety = (unsigned short)256;
   sqlstm.occurs = (unsigned int  )0;
   sqlstm.sqhstv[0] = (unsigned char  *)&l_cur;
   sqlstm.sqhstl[0] = (unsigned long )sizeof(int);
   sqlstm.sqhsts[0] = (         int  )0;
   sqlstm.sqindv[0] = (         short *)0;
   sqlstm.sqinds[0] = (         int  )0;
   sqlstm.sqharm[0] = (unsigned long )0;
   sqlstm.sqadto[0] = (unsigned short )0;
   sqlstm.sqtdso[0] = (unsigned short )0;
   sqlstm.sqphsv = sqlstm.sqhstv;
   sqlstm.sqphsl = sqlstm.sqhstl;
   sqlstm.sqphss = sqlstm.sqhsts;
   sqlstm.sqpind = sqlstm.sqindv;
   sqlstm.sqpins = sqlstm.sqinds;
   sqlstm.sqparm = sqlstm.sqharm;
   sqlstm.sqparc = sqlstm.sqharc;
   sqlstm.sqpadto = sqlstm.sqadto;
   sqlstm.sqptdso = sqlstm.sqtdso;
   sqlcxt(&p_conn, &sqlctx, &sqlstm, &sqlfpn);
}



   return true;
}


/////////////////////////////////////////////////////////////////////////////////



RetrieveSendImsiData::RetrieveSendImsiData()
{
   memset(m_msisdn, '\0', 20);
   memset(m_imsi, '\0', 20);
   memset(m_hlrAddress, '\0', 20);
}

RetrieveSendImsiData::~RetrieveSendImsiData()
{
}


bool RetrieveSendImsiData::executeQuery(void *p_conn)
{
   struct sqlca sqlca;

   /* EXEC SQL BEGIN DECLARE SECTION; */ 

   //Outputs
   /* VARCHAR l_imsi[20]; */ 
struct { unsigned short len; unsigned char arr[20]; } l_imsi;

   /* VARCHAR l_hlrAdd[20]; */ 
struct { unsigned short len; unsigned char arr[20]; } l_hlrAdd;

   int l_errCode;
   /* VARCHAR l_errMsg[200]; */ 
struct { unsigned short len; unsigned char arr[200]; } l_errMsg;

   //Inputs
   /* VARCHAR l_msisdn[20]; */ 
struct { unsigned short len; unsigned char arr[20]; } l_msisdn;


   short  l_imsi_ind;
   short  l_hlrAdd_ind;
   short  l_errCode_ind;
   short  l_errMsg_ind;
   /* EXEC SQL END DECLARE SECTION; */ 


   //Inputs
   memset(&l_msisdn, '\0', sizeof(l_msisdn));
   l_msisdn.len = strlen((char*)m_msisdn);
   strncpy((char*)l_msisdn.arr, m_msisdn, strlen(m_msisdn));

   //Outputs
   memset(&l_imsi, '\0', sizeof(l_imsi));
   memset(&l_errMsg, '\0', sizeof(l_errMsg));
   l_errCode=-1;
   memset(&l_hlrAdd, '\0', sizeof(l_hlrAdd));

   /* EXEC SQL CONTEXT USE :p_conn; */ 


   /* EXEC SQL EXECUTE
      BEGIN
      HLR_PKG_OAM_MODULE.GETIMSI(:l_msisdn, 
                                 :l_imsi:l_imsi_ind, 
				 :l_hlrAdd:l_hlrAdd_ind, 
				 :l_errCode:l_errCode_ind, 
				 :l_errMsg:l_errMsg_ind);
   END;
   END-EXEC; */ 

{
   struct sqlexd sqlstm;
   sqlstm.sqlvsn = 12;
   sqlstm.arrsiz = 13;
   sqlstm.sqladtp = &sqladt;
   sqlstm.sqltdsp = &sqltds;
   sqlstm.stmt = "begin HLR_PKG_OAM_MODULE . GETIMSI ( :l_msisdn , :l_imsi:l\
_imsi_ind , :l_hlrAdd:l_hlrAdd_ind , :l_errCode:l_errCode_ind , :l_errMsg:l_er\
rMsg_ind ) ; END ;";
   sqlstm.iters = (unsigned int  )1;
   sqlstm.offset = (unsigned int  )133;
   sqlstm.cud = sqlcud0;
   sqlstm.sqlest = (unsigned char  *)&sqlca;
   sqlstm.sqlety = (unsigned short)256;
   sqlstm.occurs = (unsigned int  )0;
   sqlstm.sqhstv[0] = (unsigned char  *)&l_msisdn;
   sqlstm.sqhstl[0] = (unsigned long )22;
   sqlstm.sqhsts[0] = (         int  )0;
   sqlstm.sqindv[0] = (         short *)0;
   sqlstm.sqinds[0] = (         int  )0;
   sqlstm.sqharm[0] = (unsigned long )0;
   sqlstm.sqadto[0] = (unsigned short )0;
   sqlstm.sqtdso[0] = (unsigned short )0;
   sqlstm.sqhstv[1] = (unsigned char  *)&l_imsi;
   sqlstm.sqhstl[1] = (unsigned long )22;
   sqlstm.sqhsts[1] = (         int  )0;
   sqlstm.sqindv[1] = (         short *)&l_imsi_ind;
   sqlstm.sqinds[1] = (         int  )0;
   sqlstm.sqharm[1] = (unsigned long )0;
   sqlstm.sqadto[1] = (unsigned short )0;
   sqlstm.sqtdso[1] = (unsigned short )0;
   sqlstm.sqhstv[2] = (unsigned char  *)&l_hlrAdd;
   sqlstm.sqhstl[2] = (unsigned long )22;
   sqlstm.sqhsts[2] = (         int  )0;
   sqlstm.sqindv[2] = (         short *)&l_hlrAdd_ind;
   sqlstm.sqinds[2] = (         int  )0;
   sqlstm.sqharm[2] = (unsigned long )0;
   sqlstm.sqadto[2] = (unsigned short )0;
   sqlstm.sqtdso[2] = (unsigned short )0;
   sqlstm.sqhstv[3] = (unsigned char  *)&l_errCode;
   sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
   sqlstm.sqhsts[3] = (         int  )0;
   sqlstm.sqindv[3] = (         short *)&l_errCode_ind;
   sqlstm.sqinds[3] = (         int  )0;
   sqlstm.sqharm[3] = (unsigned long )0;
   sqlstm.sqadto[3] = (unsigned short )0;
   sqlstm.sqtdso[3] = (unsigned short )0;
   sqlstm.sqhstv[4] = (unsigned char  *)&l_errMsg;
   sqlstm.sqhstl[4] = (unsigned long )202;
   sqlstm.sqhsts[4] = (         int  )0;
   sqlstm.sqindv[4] = (         short *)&l_errMsg_ind;
   sqlstm.sqinds[4] = (         int  )0;
   sqlstm.sqharm[4] = (unsigned long )0;
   sqlstm.sqadto[4] = (unsigned short )0;
   sqlstm.sqtdso[4] = (unsigned short )0;
   sqlstm.sqphsv = sqlstm.sqhstv;
   sqlstm.sqphsl = sqlstm.sqhstl;
   sqlstm.sqphss = sqlstm.sqhsts;
   sqlstm.sqpind = sqlstm.sqindv;
   sqlstm.sqpins = sqlstm.sqinds;
   sqlstm.sqparm = sqlstm.sqharm;
   sqlstm.sqparc = sqlstm.sqharc;
   sqlstm.sqpadto = sqlstm.sqadto;
   sqlstm.sqptdso = sqlstm.sqtdso;
   sqlcxt(&p_conn, &sqlctx, &sqlstm, &sqlfpn);
}



   if (0 == l_errCode)
   {
      strcpy((char*)m_imsi, (char*)l_imsi.arr);
      strcpy((char*)m_hlrAddress, (char*)l_hlrAdd.arr);
      m_DbQueryRes = DB_QUERY_RES_SUCCESS;	
   }
   else if ((1 == l_errCode) || (2 == l_errCode))
   {
      LLOG(0,0,"Error Code is %d", l_errCode);
      m_DbQueryRes = DB_QUERY_RES_ROWS_NOT_FOUND;	
   }
   else
   {
      LLOG(0,0,"Error Code is other: %d", l_errCode);
      m_DbQueryRes = DB_QUERY_RES_CODE_EXCEPTION;	
   }
   m_sqlcode = sqlca.sqlcode;
   return true;
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////


RetrieveOamTransData::RetrieveOamTransData()
{
   memset(m_RowId, '\0', MAX_ROW_ID_LEN+1);

   memset(m_TransId, '\0', sizeof(m_TransId));
   memset(m_TransXml, '\0', sizeof(m_TransXml));

}

RetrieveOamTransData::~RetrieveOamTransData()
{

}

bool RetrieveOamTransData::executeQuery(void *p_conn)
{
   struct sqlca sqlca;
   /* EXEC SQL BEGIN DECLARE SECTION; */ 

   /* VARCHAR l_transId[20+1]; */ 
struct { unsigned short len; unsigned char arr[21]; } l_transId;

   int l_transType;
   int l_count;
   char l_status;
   /* VARCHAR l_transXml[4000+1]; */ 
struct { unsigned short len; unsigned char arr[4001]; } l_transXml;

   /* VARCHAR l_rowId    [MAX_ROW_ID_LEN+1] = {'\0'}; */ 
struct { unsigned short len; unsigned char arr[31]; } l_rowId
 = {'\0'};

   /* VARCHAR l_processedBy [10+1]; */ 
struct { unsigned short len; unsigned char arr[11]; } l_processedBy;

   /* EXEC SQL END DECLARE SECTION; */ 


   /* EXEC SQL CONTEXT USE :p_conn; */ 

   /* EXEC SQL WHENEVER SQLERROR GOTO SQL_ERROR_OCCURED; */ 

   //EXEC SQL WHENEVER NOT FOUND GOTO DATA_NOT_FOUND;

   memset(&l_transId, '\0', sizeof(l_transId));
   memset(&l_transXml, '\0', sizeof(l_transXml));

   memset(&l_rowId, '\0', sizeof(l_rowId));
   l_rowId.len = strlen(m_RowId);
   strncpy((char*)l_rowId.arr, m_RowId, 30);

   memset(&l_processedBy, '\0', sizeof(l_processedBy));
   l_processedBy.len = strlen(g_entityName);
   strncpy((char*)l_processedBy.arr, g_entityName, 10);

   LLOG(0,0,"RetrieveOamTransData::executeQuery Querying for ROWID [%s]...", (char*)l_rowId.arr);


   /* EXEC SQL SELECT COUNT(1)
           INTO    :l_count
           FROM    HLR_OAM_TRANSACTIONS
           WHERE   ROWID = :l_rowId; */ 

{
   struct sqlexd sqlstm;
   sqlstm.sqlvsn = 12;
   sqlstm.arrsiz = 13;
   sqlstm.sqladtp = &sqladt;
   sqlstm.sqltdsp = &sqltds;
   sqlstm.stmt = "select count(1) into :b0  from HLR_OAM_TRANSACTIONS where \
ROWID=:b1";
   sqlstm.iters = (unsigned int  )1;
   sqlstm.offset = (unsigned int  )168;
   sqlstm.selerr = (unsigned short)1;
   sqlstm.cud = sqlcud0;
   sqlstm.sqlest = (unsigned char  *)&sqlca;
   sqlstm.sqlety = (unsigned short)256;
   sqlstm.occurs = (unsigned int  )0;
   sqlstm.sqhstv[0] = (unsigned char  *)&l_count;
   sqlstm.sqhstl[0] = (unsigned long )sizeof(int);
   sqlstm.sqhsts[0] = (         int  )0;
   sqlstm.sqindv[0] = (         short *)0;
   sqlstm.sqinds[0] = (         int  )0;
   sqlstm.sqharm[0] = (unsigned long )0;
   sqlstm.sqadto[0] = (unsigned short )0;
   sqlstm.sqtdso[0] = (unsigned short )0;
   sqlstm.sqhstv[1] = (unsigned char  *)&l_rowId;
   sqlstm.sqhstl[1] = (unsigned long )33;
   sqlstm.sqhsts[1] = (         int  )0;
   sqlstm.sqindv[1] = (         short *)0;
   sqlstm.sqinds[1] = (         int  )0;
   sqlstm.sqharm[1] = (unsigned long )0;
   sqlstm.sqadto[1] = (unsigned short )0;
   sqlstm.sqtdso[1] = (unsigned short )0;
   sqlstm.sqphsv = sqlstm.sqhstv;
   sqlstm.sqphsl = sqlstm.sqhstl;
   sqlstm.sqphss = sqlstm.sqhsts;
   sqlstm.sqpind = sqlstm.sqindv;
   sqlstm.sqpins = sqlstm.sqinds;
   sqlstm.sqparm = sqlstm.sqharm;
   sqlstm.sqparc = sqlstm.sqharc;
   sqlstm.sqpadto = sqlstm.sqadto;
   sqlstm.sqptdso = sqlstm.sqtdso;
   sqlcxt(&p_conn, &sqlctx, &sqlstm, &sqlfpn);
   if (sqlca.sqlcode < 0) goto SQL_ERROR_OCCURED;
}



   if(l_count > 0)
   {
	   /* EXEC SQL SELECT TRANS_STATUS
		   INTO    :l_status
		   FROM    HLR_OAM_TRANSACTIONS
		   WHERE   ROWID = :l_rowId; */ 

{
    struct sqlexd sqlstm;
    sqlstm.sqlvsn = 12;
    sqlstm.arrsiz = 13;
    sqlstm.sqladtp = &sqladt;
    sqlstm.sqltdsp = &sqltds;
    sqlstm.stmt = "select TRANS_STATUS into :b0  from HLR_OAM_TRANSACTIONS w\
here ROWID=:b1";
    sqlstm.iters = (unsigned int  )1;
    sqlstm.offset = (unsigned int  )191;
    sqlstm.selerr = (unsigned short)1;
    sqlstm.cud = sqlcud0;
    sqlstm.sqlest = (unsigned char  *)&sqlca;
    sqlstm.sqlety = (unsigned short)256;
    sqlstm.occurs = (unsigned int  )0;
    sqlstm.sqhstv[0] = (unsigned char  *)&l_status;
    sqlstm.sqhstl[0] = (unsigned long )1;
    sqlstm.sqhsts[0] = (         int  )0;
    sqlstm.sqindv[0] = (         short *)0;
    sqlstm.sqinds[0] = (         int  )0;
    sqlstm.sqharm[0] = (unsigned long )0;
    sqlstm.sqadto[0] = (unsigned short )0;
    sqlstm.sqtdso[0] = (unsigned short )0;
    sqlstm.sqhstv[1] = (unsigned char  *)&l_rowId;
    sqlstm.sqhstl[1] = (unsigned long )33;
    sqlstm.sqhsts[1] = (         int  )0;
    sqlstm.sqindv[1] = (         short *)0;
    sqlstm.sqinds[1] = (         int  )0;
    sqlstm.sqharm[1] = (unsigned long )0;
    sqlstm.sqadto[1] = (unsigned short )0;
    sqlstm.sqtdso[1] = (unsigned short )0;
    sqlstm.sqphsv = sqlstm.sqhstv;
    sqlstm.sqphsl = sqlstm.sqhstl;
    sqlstm.sqphss = sqlstm.sqhsts;
    sqlstm.sqpind = sqlstm.sqindv;
    sqlstm.sqpins = sqlstm.sqinds;
    sqlstm.sqparm = sqlstm.sqharm;
    sqlstm.sqparc = sqlstm.sqharc;
    sqlstm.sqpadto = sqlstm.sqadto;
    sqlstm.sqptdso = sqlstm.sqtdso;
    sqlcxt(&p_conn, &sqlctx, &sqlstm, &sqlfpn);
    if (sqlca.sqlcode < 0) goto SQL_ERROR_OCCURED;
}



	   LLOG(0,0,"RetrieveOamTransData::executeQuery count for ROWID [%s] %d status [%c]...", (char*)l_rowId.arr, l_count, l_status);
   }
   else
   {
	   LLOG(0,0,"RetrieveOamTransData::executeQuery count for ROWID [%s] is 0", (char*)l_rowId.arr);
   }


   /* EXEC SQL SELECT NVL(TRANS_ID, ' '),
        NVL(TRANS_TYPE, 0),
        NVL(TRANS_XML, ' ')
           INTO    :l_transId,
                   :l_transType,
                   :l_transXml
           FROM    HLR_OAM_TRANSACTIONS
           WHERE   ROWID = :l_rowId
           AND TRANS_STATUS = 'P'; */ 

{
   struct sqlexd sqlstm;
   sqlstm.sqlvsn = 12;
   sqlstm.arrsiz = 13;
   sqlstm.sqladtp = &sqladt;
   sqlstm.sqltdsp = &sqltds;
   sqlstm.stmt = "select NVL(TRANS_ID,' ') ,NVL(TRANS_TYPE,0) ,NVL(TRANS_XML\
,' ') into :b0,:b1,:b2  from HLR_OAM_TRANSACTIONS where (ROWID=:b3 and TRANS_S\
TATUS='P')";
   sqlstm.iters = (unsigned int  )1;
   sqlstm.offset = (unsigned int  )214;
   sqlstm.selerr = (unsigned short)1;
   sqlstm.cud = sqlcud0;
   sqlstm.sqlest = (unsigned char  *)&sqlca;
   sqlstm.sqlety = (unsigned short)256;
   sqlstm.occurs = (unsigned int  )0;
   sqlstm.sqhstv[0] = (unsigned char  *)&l_transId;
   sqlstm.sqhstl[0] = (unsigned long )23;
   sqlstm.sqhsts[0] = (         int  )0;
   sqlstm.sqindv[0] = (         short *)0;
   sqlstm.sqinds[0] = (         int  )0;
   sqlstm.sqharm[0] = (unsigned long )0;
   sqlstm.sqadto[0] = (unsigned short )0;
   sqlstm.sqtdso[0] = (unsigned short )0;
   sqlstm.sqhstv[1] = (unsigned char  *)&l_transType;
   sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
   sqlstm.sqhsts[1] = (         int  )0;
   sqlstm.sqindv[1] = (         short *)0;
   sqlstm.sqinds[1] = (         int  )0;
   sqlstm.sqharm[1] = (unsigned long )0;
   sqlstm.sqadto[1] = (unsigned short )0;
   sqlstm.sqtdso[1] = (unsigned short )0;
   sqlstm.sqhstv[2] = (unsigned char  *)&l_transXml;
   sqlstm.sqhstl[2] = (unsigned long )4003;
   sqlstm.sqhsts[2] = (         int  )0;
   sqlstm.sqindv[2] = (         short *)0;
   sqlstm.sqinds[2] = (         int  )0;
   sqlstm.sqharm[2] = (unsigned long )0;
   sqlstm.sqadto[2] = (unsigned short )0;
   sqlstm.sqtdso[2] = (unsigned short )0;
   sqlstm.sqhstv[3] = (unsigned char  *)&l_rowId;
   sqlstm.sqhstl[3] = (unsigned long )33;
   sqlstm.sqhsts[3] = (         int  )0;
   sqlstm.sqindv[3] = (         short *)0;
   sqlstm.sqinds[3] = (         int  )0;
   sqlstm.sqharm[3] = (unsigned long )0;
   sqlstm.sqadto[3] = (unsigned short )0;
   sqlstm.sqtdso[3] = (unsigned short )0;
   sqlstm.sqphsv = sqlstm.sqhstv;
   sqlstm.sqphsl = sqlstm.sqhstl;
   sqlstm.sqphss = sqlstm.sqhsts;
   sqlstm.sqpind = sqlstm.sqindv;
   sqlstm.sqpins = sqlstm.sqinds;
   sqlstm.sqparm = sqlstm.sqharm;
   sqlstm.sqparc = sqlstm.sqharc;
   sqlstm.sqpadto = sqlstm.sqadto;
   sqlstm.sqptdso = sqlstm.sqtdso;
   sqlcxt(&p_conn, &sqlctx, &sqlstm, &sqlfpn);
   if (sqlca.sqlcode < 0) goto SQL_ERROR_OCCURED;
}



   LLOG(0,0,"RetrieveOamTransData::executeQuery for ROWID [%s] code:%d", (char*)l_rowId.arr, sqlca.sqlcode);

   if(0 == sqlca.sqlcode)
   {
	   m_DbQueryRes = DB_QUERY_RES_SUCCESS;	
	   LLOG(0,0,"RetrieveOamTransData:: ROWID [%s] Retrieved Data: TransID[%s], TransType[%d], TransXML[%s]", 
		(char*)l_rowId.arr,
		 (char*)l_transId.arr,
		 l_transType,
		 (char*)l_transXml.arr);

	   /* EXEC SQL UPDATE HLR_OAM_TRANSACTIONS
	      SET TRANS_STATUS = 'I',
		  PICKED_DATE = SYSDATE,
		  PROCESSED_BY = :l_processedBy
		     WHERE ROWID = :l_rowId; */ 

{
    struct sqlexd sqlstm;
    sqlstm.sqlvsn = 12;
    sqlstm.arrsiz = 13;
    sqlstm.sqladtp = &sqladt;
    sqlstm.sqltdsp = &sqltds;
    sqlstm.stmt = "update HLR_OAM_TRANSACTIONS  set TRANS_STATUS='I',PICKED_\
DATE=SYSDATE,PROCESSED_BY=:b0 where ROWID=:b1";
    sqlstm.iters = (unsigned int  )1;
    sqlstm.offset = (unsigned int  )245;
    sqlstm.cud = sqlcud0;
    sqlstm.sqlest = (unsigned char  *)&sqlca;
    sqlstm.sqlety = (unsigned short)256;
    sqlstm.occurs = (unsigned int  )0;
    sqlstm.sqhstv[0] = (unsigned char  *)&l_processedBy;
    sqlstm.sqhstl[0] = (unsigned long )13;
    sqlstm.sqhsts[0] = (         int  )0;
    sqlstm.sqindv[0] = (         short *)0;
    sqlstm.sqinds[0] = (         int  )0;
    sqlstm.sqharm[0] = (unsigned long )0;
    sqlstm.sqadto[0] = (unsigned short )0;
    sqlstm.sqtdso[0] = (unsigned short )0;
    sqlstm.sqhstv[1] = (unsigned char  *)&l_rowId;
    sqlstm.sqhstl[1] = (unsigned long )33;
    sqlstm.sqhsts[1] = (         int  )0;
    sqlstm.sqindv[1] = (         short *)0;
    sqlstm.sqinds[1] = (         int  )0;
    sqlstm.sqharm[1] = (unsigned long )0;
    sqlstm.sqadto[1] = (unsigned short )0;
    sqlstm.sqtdso[1] = (unsigned short )0;
    sqlstm.sqphsv = sqlstm.sqhstv;
    sqlstm.sqphsl = sqlstm.sqhstl;
    sqlstm.sqphss = sqlstm.sqhsts;
    sqlstm.sqpind = sqlstm.sqindv;
    sqlstm.sqpins = sqlstm.sqinds;
    sqlstm.sqparm = sqlstm.sqharm;
    sqlstm.sqparc = sqlstm.sqharc;
    sqlstm.sqpadto = sqlstm.sqadto;
    sqlstm.sqptdso = sqlstm.sqtdso;
    sqlcxt(&p_conn, &sqlctx, &sqlstm, &sqlfpn);
    if (sqlca.sqlcode < 0) goto SQL_ERROR_OCCURED;
}


	   /* EXEC SQL COMMIT; */ 

{
    struct sqlexd sqlstm;
    sqlstm.sqlvsn = 12;
    sqlstm.arrsiz = 13;
    sqlstm.sqladtp = &sqladt;
    sqlstm.sqltdsp = &sqltds;
    sqlstm.iters = (unsigned int  )1;
    sqlstm.offset = (unsigned int  )268;
    sqlstm.cud = sqlcud0;
    sqlstm.sqlest = (unsigned char  *)&sqlca;
    sqlstm.sqlety = (unsigned short)256;
    sqlstm.occurs = (unsigned int  )0;
    sqlcxt(&p_conn, &sqlctx, &sqlstm, &sqlfpn);
    if (sqlca.sqlcode < 0) goto SQL_ERROR_OCCURED;
}


	   LLOG(0,0,"RetrieveOamTransData ROWID [%s] Updated the transaction", (char*)l_rowId.arr);

	   strcpy(m_TransId,(char*)l_transId.arr);
	   m_TransType=l_transType;
	   strncpy(m_TransXml, (char*)l_transXml.arr, MAX_TRANS_XML_STRING_SIZE);
	   m_sqlcode = sqlca.sqlcode;
	   return true;

   }
   else
   {
      LLOG(0,0,"RetrieveOamTransData::executeQuery error code :%d", sqlca.sqlcode);
	   m_sqlcode = sqlca.sqlcode;
	   return false;
   }


SQL_ERROR_OCCURED:
   m_DbQueryRes = DB_QUERY_RES_CODE_EXCEPTION;	
   m_sqlcode = sqlca.sqlcode;
   CLOG(0,0,"RetrieveOamTransData::executeQuery: ROWID [%s] SQL Error Occurred: %d", (char*)l_rowId.arr, sqlca.sqlcode);
   return false;

DATA_NOT_FOUND:
   m_sqlcode = sqlca.sqlcode;
   m_DbQueryRes = DB_QUERY_RES_ROWS_NOT_FOUND;	
   CLOG(0,0,"RetrieveOamTransData::executeQuery: ROWID [%s] Data Not Found", (char*)l_rowId.arr);
   return false;
}



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

RetrieveOamBulkTrans::RetrieveOamBulkTrans()
{

}

RetrieveOamBulkTrans::~RetrieveOamBulkTrans()
{

}

bool RetrieveOamBulkTrans::executeQuery(void *p_conn)
{
   struct sqlca sqlca;

   /* EXEC SQL BEGIN DECLARE SECTION; */ 

   int l_count;
   /* VARCHAR l_rowId    [MAX_ROW_ID_LEN+1]; */ 
struct { unsigned short len; unsigned char arr[31]; } l_rowId;

   /* EXEC SQL END DECLARE SECTION; */ 


   /* EXEC SQL CONTEXT USE :p_conn; */ 

   /* EXEC SQL WHENEVER SQLERROR GOTO SQL_ERROR_OCCURED; */ 


   LLOG(0,0,"RetrieveOamBulkTrans::executeQuery start");

   /* EXEC SQL SELECT COUNT(1)
           INTO    :l_count
           FROM    HLR_OAM_TRANSACTIONS
           WHERE   TRANS_STATUS = 'P'
             AND   INSERTED_DATE < sysdate-1/24; */ 

{
   struct sqlexd sqlstm;
   sqlstm.sqlvsn = 12;
   sqlstm.arrsiz = 13;
   sqlstm.sqladtp = &sqladt;
   sqlstm.sqltdsp = &sqltds;
   sqlstm.stmt = "select count(1) into :b0  from HLR_OAM_TRANSACTIONS where \
(TRANS_STATUS='P' and INSERTED_DATE<(sysdate-(1/24)))";
   sqlstm.iters = (unsigned int  )1;
   sqlstm.offset = (unsigned int  )283;
   sqlstm.selerr = (unsigned short)1;
   sqlstm.cud = sqlcud0;
   sqlstm.sqlest = (unsigned char  *)&sqlca;
   sqlstm.sqlety = (unsigned short)256;
   sqlstm.occurs = (unsigned int  )0;
   sqlstm.sqhstv[0] = (unsigned char  *)&l_count;
   sqlstm.sqhstl[0] = (unsigned long )sizeof(int);
   sqlstm.sqhsts[0] = (         int  )0;
   sqlstm.sqindv[0] = (         short *)0;
   sqlstm.sqinds[0] = (         int  )0;
   sqlstm.sqharm[0] = (unsigned long )0;
   sqlstm.sqadto[0] = (unsigned short )0;
   sqlstm.sqtdso[0] = (unsigned short )0;
   sqlstm.sqphsv = sqlstm.sqhstv;
   sqlstm.sqphsl = sqlstm.sqhstl;
   sqlstm.sqphss = sqlstm.sqhsts;
   sqlstm.sqpind = sqlstm.sqindv;
   sqlstm.sqpins = sqlstm.sqinds;
   sqlstm.sqparm = sqlstm.sqharm;
   sqlstm.sqparc = sqlstm.sqharc;
   sqlstm.sqpadto = sqlstm.sqadto;
   sqlstm.sqptdso = sqlstm.sqtdso;
   sqlcxt(&p_conn, &sqlctx, &sqlstm, &sqlfpn);
   if (sqlca.sqlcode < 0) goto SQL_ERROR_OCCURED;
}



   /* EXEC SQL DECLARE data_cursor CURSOR FOR
      SELECT ROWID
        FROM HLR_OAM_TRANSACTIONS
       WHERE TRANS_STATUS = 'P'
         AND INSERTED_DATE < sysdate-1/24; */ 


   LLOG(0,0,"RetrieveOamBulkTrans::executeQuery count is %d", l_count);

   /* EXEC SQL OPEN data_cursor; */ 

{
   struct sqlexd sqlstm;
   sqlstm.sqlvsn = 12;
   sqlstm.arrsiz = 13;
   sqlstm.sqladtp = &sqladt;
   sqlstm.sqltdsp = &sqltds;
   sqlstm.stmt = sq0009;
   sqlstm.iters = (unsigned int  )1;
   sqlstm.offset = (unsigned int  )302;
   sqlstm.selerr = (unsigned short)1;
   sqlstm.cud = sqlcud0;
   sqlstm.sqlest = (unsigned char  *)&sqlca;
   sqlstm.sqlety = (unsigned short)256;
   sqlstm.occurs = (unsigned int  )0;
   sqlstm.sqcmod = (unsigned int )0;
   sqlcxt(&p_conn, &sqlctx, &sqlstm, &sqlfpn);
   if (sqlca.sqlcode < 0) goto SQL_ERROR_OCCURED;
}


   for(int l_index=0;l_index<l_count;l_index++)
   {
      memset(&l_rowId, '\0', sizeof(l_rowId));
      /* EXEC SQL FETCH data_cursor 
               INTO  :l_rowId; */ 

{
      struct sqlexd sqlstm;
      sqlstm.sqlvsn = 12;
      sqlstm.arrsiz = 13;
      sqlstm.sqladtp = &sqladt;
      sqlstm.sqltdsp = &sqltds;
      sqlstm.iters = (unsigned int  )1;
      sqlstm.offset = (unsigned int  )317;
      sqlstm.selerr = (unsigned short)1;
      sqlstm.cud = sqlcud0;
      sqlstm.sqlest = (unsigned char  *)&sqlca;
      sqlstm.sqlety = (unsigned short)256;
      sqlstm.occurs = (unsigned int  )0;
      sqlstm.sqfoff = (         int )0;
      sqlstm.sqfmod = (unsigned int )2;
      sqlstm.sqhstv[0] = (unsigned char  *)&l_rowId;
      sqlstm.sqhstl[0] = (unsigned long )33;
      sqlstm.sqhsts[0] = (         int  )0;
      sqlstm.sqindv[0] = (         short *)0;
      sqlstm.sqinds[0] = (         int  )0;
      sqlstm.sqharm[0] = (unsigned long )0;
      sqlstm.sqadto[0] = (unsigned short )0;
      sqlstm.sqtdso[0] = (unsigned short )0;
      sqlstm.sqphsv = sqlstm.sqhstv;
      sqlstm.sqphsl = sqlstm.sqhstl;
      sqlstm.sqphss = sqlstm.sqhsts;
      sqlstm.sqpind = sqlstm.sqindv;
      sqlstm.sqpins = sqlstm.sqinds;
      sqlstm.sqparm = sqlstm.sqharm;
      sqlstm.sqparc = sqlstm.sqharc;
      sqlstm.sqpadto = sqlstm.sqadto;
      sqlstm.sqptdso = sqlstm.sqtdso;
      sqlcxt(&p_conn, &sqlctx, &sqlstm, &sqlfpn);
      if (sqlca.sqlcode < 0) goto SQL_ERROR_OCCURED;
}



      if (sqlca.sqlcode != 0)
      {
         LLOG(0,1,"sqlcode is %d", sqlca.sqlcode);
         break;
      }
      else
      {
         char *l_currentRowId = new char[MAX_ROW_ID_LEN+1];
         memset(l_currentRowId, '\0', MAX_ROW_ID_LEN+1);
         strcpy(l_currentRowId, (char*)l_rowId.arr);

         m_outputList.push_back(l_currentRowId);
      }
   }
   /* EXEC SQL CLOSE data_cursor; */ 

{
   struct sqlexd sqlstm;
   sqlstm.sqlvsn = 12;
   sqlstm.arrsiz = 13;
   sqlstm.sqladtp = &sqladt;
   sqlstm.sqltdsp = &sqltds;
   sqlstm.iters = (unsigned int  )1;
   sqlstm.offset = (unsigned int  )336;
   sqlstm.cud = sqlcud0;
   sqlstm.sqlest = (unsigned char  *)&sqlca;
   sqlstm.sqlety = (unsigned short)256;
   sqlstm.occurs = (unsigned int  )0;
   sqlcxt(&p_conn, &sqlctx, &sqlstm, &sqlfpn);
   if (sqlca.sqlcode < 0) goto SQL_ERROR_OCCURED;
}



   if(0 == sqlca.sqlcode)
   {
	   m_DbQueryRes = DB_QUERY_RES_SUCCESS;	
	   LLOG(0,0,"RetrieveOamBulkTrans:: success");
	   m_sqlcode = sqlca.sqlcode;
	   return true;
   }
   else
   {
      m_DbQueryRes = DB_QUERY_RES_CODE_EXCEPTION;
      LLOG(0,0,"RetrieveOamBulkTrans::executeQuery error code :%d", sqlca.sqlcode);
	   m_sqlcode = sqlca.sqlcode;
	   return false;
   }


SQL_ERROR_OCCURED:
   m_DbQueryRes = DB_QUERY_RES_CODE_EXCEPTION;	
   m_sqlcode = sqlca.sqlcode;
   CLOG(0,0,"RetrieveOamBulkTrans::executeQuery: SQL Error Occurred: %d", sqlca.sqlcode);
   return false;

DATA_NOT_FOUND:
   m_sqlcode = sqlca.sqlcode;
   m_DbQueryRes = DB_QUERY_RES_ROWS_NOT_FOUND;	
   CLOG(0,0,"RetrieveOamBulkTrans::executeQuery: Data Not Found");
   return false;
}



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

UpdateOamTransData::UpdateOamTransData()
{
   memset(m_TransId, '\0', sizeof(m_TransId));
   memset(m_ErrorCause, '\0', 100+1);
   m_Status='P';

   m_actTracingFlag=0; // By default to 0. Enable only for Activate Tracing
   memset(m_type, '\0', sizeof(m_type));
   memset(m_imsi, '\0', sizeof(m_imsi));
   m_errorCodeToBeUpdated=-1;
}

UpdateOamTransData::~UpdateOamTransData()
{
}

bool UpdateOamTransData::executeQuery(void *p_conn)
{
   struct sqlca sqlca;
   /* EXEC SQL BEGIN DECLARE SECTION; */ 

   /* VARCHAR l_TransId[20+1]; */ 
struct { unsigned short len; unsigned char arr[21]; } l_TransId;

   /* VARCHAR l_ErrorCause   [100+1]; */ 
struct { unsigned short len; unsigned char arr[101]; } l_ErrorCause;

   char    l_Status;
   /* VARCHAR l_processedBy [10+1]; */ 
struct { unsigned short len; unsigned char arr[11]; } l_processedBy;


   /* VARCHAR l_imsi [MAX_IMSI_LEN+1]; */ 
struct { unsigned short len; unsigned char arr[16]; } l_imsi;

   int     l_mapErrorCode;
   /* VARCHAR l_accId[20+1]; */ 
struct { unsigned short len; unsigned char arr[21]; } l_accId;

   /* EXEC SQL END DECLARE SECTION; */ 


   /* EXEC SQL CONTEXT USE :p_conn; */ 

   /* EXEC SQL WHENEVER SQLERROR GOTO SQL_ERROR_OCCURED; */ 

   //EXEC SQL WHENEVER NOT FOUND GOTO DATA_NOT_FOUND;

   memset(&l_TransId, '\0', sizeof(l_TransId));
   strcpy((char*)l_TransId.arr, m_TransId);
   l_TransId.len = strlen(m_TransId);

   memset(&l_ErrorCause, '\0', sizeof(l_ErrorCause));
   l_ErrorCause.len = strlen(m_ErrorCause);
   strncpy((char*)l_ErrorCause.arr, m_ErrorCause, 100);

   memset(&l_processedBy, '\0', sizeof(l_processedBy));
   l_processedBy.len = strlen(g_entityName);
   strncpy((char*)l_processedBy.arr, g_entityName, 10);

   LLOG(0,0,"Error Cause [%s] [%d]", (char*)l_ErrorCause.arr, l_ErrorCause.len);

   memset(&l_imsi, '\0', sizeof(l_imsi));
   l_imsi.len = strlen(m_imsi);
   strncpy((char*)l_imsi.arr, m_imsi, MAX_IMSI_LEN);
   l_mapErrorCode=m_errorCodeToBeUpdated;

   memset(&l_accId, '\0', sizeof(l_accId));

   l_Status = m_Status;

   LLOG(0,0,"UpdateOamTransData::executeQuery Updating for TransId [%s]...", (char*)l_TransId.arr);


   /* EXEC SQL UPDATE HLR_OAM_TRANSACTIONS
      SET TRANS_STATUS = :l_Status,
          FAILURE_CAUSE  = :l_ErrorCause,
          PROCESSED_DATE = SYSDATE,
          PROCESSED_BY = :l_processedBy
             WHERE TRANS_ID = :l_TransId; */ 

{
   struct sqlexd sqlstm;
   sqlstm.sqlvsn = 12;
   sqlstm.arrsiz = 13;
   sqlstm.sqladtp = &sqladt;
   sqlstm.sqltdsp = &sqltds;
   sqlstm.stmt = "update HLR_OAM_TRANSACTIONS  set TRANS_STATUS=:b0,FAILURE_\
CAUSE=:b1,PROCESSED_DATE=SYSDATE,PROCESSED_BY=:b2 where TRANS_ID=:b3";
   sqlstm.iters = (unsigned int  )1;
   sqlstm.offset = (unsigned int  )351;
   sqlstm.cud = sqlcud0;
   sqlstm.sqlest = (unsigned char  *)&sqlca;
   sqlstm.sqlety = (unsigned short)256;
   sqlstm.occurs = (unsigned int  )0;
   sqlstm.sqhstv[0] = (unsigned char  *)&l_Status;
   sqlstm.sqhstl[0] = (unsigned long )1;
   sqlstm.sqhsts[0] = (         int  )0;
   sqlstm.sqindv[0] = (         short *)0;
   sqlstm.sqinds[0] = (         int  )0;
   sqlstm.sqharm[0] = (unsigned long )0;
   sqlstm.sqadto[0] = (unsigned short )0;
   sqlstm.sqtdso[0] = (unsigned short )0;
   sqlstm.sqhstv[1] = (unsigned char  *)&l_ErrorCause;
   sqlstm.sqhstl[1] = (unsigned long )103;
   sqlstm.sqhsts[1] = (         int  )0;
   sqlstm.sqindv[1] = (         short *)0;
   sqlstm.sqinds[1] = (         int  )0;
   sqlstm.sqharm[1] = (unsigned long )0;
   sqlstm.sqadto[1] = (unsigned short )0;
   sqlstm.sqtdso[1] = (unsigned short )0;
   sqlstm.sqhstv[2] = (unsigned char  *)&l_processedBy;
   sqlstm.sqhstl[2] = (unsigned long )13;
   sqlstm.sqhsts[2] = (         int  )0;
   sqlstm.sqindv[2] = (         short *)0;
   sqlstm.sqinds[2] = (         int  )0;
   sqlstm.sqharm[2] = (unsigned long )0;
   sqlstm.sqadto[2] = (unsigned short )0;
   sqlstm.sqtdso[2] = (unsigned short )0;
   sqlstm.sqhstv[3] = (unsigned char  *)&l_TransId;
   sqlstm.sqhstl[3] = (unsigned long )23;
   sqlstm.sqhsts[3] = (         int  )0;
   sqlstm.sqindv[3] = (         short *)0;
   sqlstm.sqinds[3] = (         int  )0;
   sqlstm.sqharm[3] = (unsigned long )0;
   sqlstm.sqadto[3] = (unsigned short )0;
   sqlstm.sqtdso[3] = (unsigned short )0;
   sqlstm.sqphsv = sqlstm.sqhstv;
   sqlstm.sqphsl = sqlstm.sqhstl;
   sqlstm.sqphss = sqlstm.sqhsts;
   sqlstm.sqpind = sqlstm.sqindv;
   sqlstm.sqpins = sqlstm.sqinds;
   sqlstm.sqparm = sqlstm.sqharm;
   sqlstm.sqparc = sqlstm.sqharc;
   sqlstm.sqpadto = sqlstm.sqadto;
   sqlstm.sqptdso = sqlstm.sqtdso;
   sqlcxt(&p_conn, &sqlctx, &sqlstm, &sqlfpn);
   if (sqlca.sqlcode < 0) goto SQL_ERROR_OCCURED;
}



   /* EXEC SQL COMMIT; */ 

{
   struct sqlexd sqlstm;
   sqlstm.sqlvsn = 12;
   sqlstm.arrsiz = 13;
   sqlstm.sqladtp = &sqladt;
   sqlstm.sqltdsp = &sqltds;
   sqlstm.iters = (unsigned int  )1;
   sqlstm.offset = (unsigned int  )382;
   sqlstm.cud = sqlcud0;
   sqlstm.sqlest = (unsigned char  *)&sqlca;
   sqlstm.sqlety = (unsigned short)256;
   sqlstm.occurs = (unsigned int  )0;
   sqlcxt(&p_conn, &sqlctx, &sqlstm, &sqlfpn);
   if (sqlca.sqlcode < 0) goto SQL_ERROR_OCCURED;
}



   if (1 == m_actTracingFlag) // This is only for Activate Tracing 
   {
      LLOG(0,0,"UpdateOamTransData:: IMSI:%s, mapcode: %d type: %s", (char*)l_imsi.arr, l_mapErrorCode, m_type);

      /* EXEC SQL SELECT ACCOUNT_ID 
                 INTO :l_accId
                 FROM HLR_SUBS_IMSI_ACCOUNT
               WHERE IMSI = :l_imsi; */ 

{
      struct sqlexd sqlstm;
      sqlstm.sqlvsn = 12;
      sqlstm.arrsiz = 13;
      sqlstm.sqladtp = &sqladt;
      sqlstm.sqltdsp = &sqltds;
      sqlstm.stmt = "select ACCOUNT_ID into :b0  from HLR_SUBS_IMSI_ACCOUNT \
where IMSI=:b1";
      sqlstm.iters = (unsigned int  )1;
      sqlstm.offset = (unsigned int  )397;
      sqlstm.selerr = (unsigned short)1;
      sqlstm.cud = sqlcud0;
      sqlstm.sqlest = (unsigned char  *)&sqlca;
      sqlstm.sqlety = (unsigned short)256;
      sqlstm.occurs = (unsigned int  )0;
      sqlstm.sqhstv[0] = (unsigned char  *)&l_accId;
      sqlstm.sqhstl[0] = (unsigned long )23;
      sqlstm.sqhsts[0] = (         int  )0;
      sqlstm.sqindv[0] = (         short *)0;
      sqlstm.sqinds[0] = (         int  )0;
      sqlstm.sqharm[0] = (unsigned long )0;
      sqlstm.sqadto[0] = (unsigned short )0;
      sqlstm.sqtdso[0] = (unsigned short )0;
      sqlstm.sqhstv[1] = (unsigned char  *)&l_imsi;
      sqlstm.sqhstl[1] = (unsigned long )18;
      sqlstm.sqhsts[1] = (         int  )0;
      sqlstm.sqindv[1] = (         short *)0;
      sqlstm.sqinds[1] = (         int  )0;
      sqlstm.sqharm[1] = (unsigned long )0;
      sqlstm.sqadto[1] = (unsigned short )0;
      sqlstm.sqtdso[1] = (unsigned short )0;
      sqlstm.sqphsv = sqlstm.sqhstv;
      sqlstm.sqphsl = sqlstm.sqhstl;
      sqlstm.sqphss = sqlstm.sqhsts;
      sqlstm.sqpind = sqlstm.sqindv;
      sqlstm.sqpins = sqlstm.sqinds;
      sqlstm.sqparm = sqlstm.sqharm;
      sqlstm.sqparc = sqlstm.sqharc;
      sqlstm.sqpadto = sqlstm.sqadto;
      sqlstm.sqptdso = sqlstm.sqtdso;
      sqlcxt(&p_conn, &sqlctx, &sqlstm, &sqlfpn);
      if (sqlca.sqlcode < 0) goto SQL_ERROR_OCCURED;
}



      if (0 == strcmp(m_type, "GSM"))
      {
         /* EXEC SQL UPDATE HLR_SUBS_DATA
                     SET TRACE_MAP_ERROR_VLR = :l_mapErrorCode
                   WHERE ACCOUNT_ID = :l_accId; */ 

{
         struct sqlexd sqlstm;
         sqlstm.sqlvsn = 12;
         sqlstm.arrsiz = 13;
         sqlstm.sqladtp = &sqladt;
         sqlstm.sqltdsp = &sqltds;
         sqlstm.stmt = "update HLR_SUBS_DATA  set TRACE_MAP_ERROR_VLR=:b0 wh\
ere ACCOUNT_ID=:b1";
         sqlstm.iters = (unsigned int  )1;
         sqlstm.offset = (unsigned int  )420;
         sqlstm.cud = sqlcud0;
         sqlstm.sqlest = (unsigned char  *)&sqlca;
         sqlstm.sqlety = (unsigned short)256;
         sqlstm.occurs = (unsigned int  )0;
         sqlstm.sqhstv[0] = (unsigned char  *)&l_mapErrorCode;
         sqlstm.sqhstl[0] = (unsigned long )sizeof(int);
         sqlstm.sqhsts[0] = (         int  )0;
         sqlstm.sqindv[0] = (         short *)0;
         sqlstm.sqinds[0] = (         int  )0;
         sqlstm.sqharm[0] = (unsigned long )0;
         sqlstm.sqadto[0] = (unsigned short )0;
         sqlstm.sqtdso[0] = (unsigned short )0;
         sqlstm.sqhstv[1] = (unsigned char  *)&l_accId;
         sqlstm.sqhstl[1] = (unsigned long )23;
         sqlstm.sqhsts[1] = (         int  )0;
         sqlstm.sqindv[1] = (         short *)0;
         sqlstm.sqinds[1] = (         int  )0;
         sqlstm.sqharm[1] = (unsigned long )0;
         sqlstm.sqadto[1] = (unsigned short )0;
         sqlstm.sqtdso[1] = (unsigned short )0;
         sqlstm.sqphsv = sqlstm.sqhstv;
         sqlstm.sqphsl = sqlstm.sqhstl;
         sqlstm.sqphss = sqlstm.sqhsts;
         sqlstm.sqpind = sqlstm.sqindv;
         sqlstm.sqpins = sqlstm.sqinds;
         sqlstm.sqparm = sqlstm.sqharm;
         sqlstm.sqparc = sqlstm.sqharc;
         sqlstm.sqpadto = sqlstm.sqadto;
         sqlstm.sqptdso = sqlstm.sqtdso;
         sqlcxt(&p_conn, &sqlctx, &sqlstm, &sqlfpn);
         if (sqlca.sqlcode < 0) goto SQL_ERROR_OCCURED;
}


      }
      else if (0 == strcmp(m_type, "GPRS"))
      {
         /* EXEC SQL UPDATE HLR_SUBS_DATA
                     SET TRACE_MAP_ERROR_SGSN = :l_mapErrorCode
                   WHERE ACCOUNT_ID = :l_accId; */ 

{
         struct sqlexd sqlstm;
         sqlstm.sqlvsn = 12;
         sqlstm.arrsiz = 13;
         sqlstm.sqladtp = &sqladt;
         sqlstm.sqltdsp = &sqltds;
         sqlstm.stmt = "update HLR_SUBS_DATA  set TRACE_MAP_ERROR_SGSN=:b0 w\
here ACCOUNT_ID=:b1";
         sqlstm.iters = (unsigned int  )1;
         sqlstm.offset = (unsigned int  )443;
         sqlstm.cud = sqlcud0;
         sqlstm.sqlest = (unsigned char  *)&sqlca;
         sqlstm.sqlety = (unsigned short)256;
         sqlstm.occurs = (unsigned int  )0;
         sqlstm.sqhstv[0] = (unsigned char  *)&l_mapErrorCode;
         sqlstm.sqhstl[0] = (unsigned long )sizeof(int);
         sqlstm.sqhsts[0] = (         int  )0;
         sqlstm.sqindv[0] = (         short *)0;
         sqlstm.sqinds[0] = (         int  )0;
         sqlstm.sqharm[0] = (unsigned long )0;
         sqlstm.sqadto[0] = (unsigned short )0;
         sqlstm.sqtdso[0] = (unsigned short )0;
         sqlstm.sqhstv[1] = (unsigned char  *)&l_accId;
         sqlstm.sqhstl[1] = (unsigned long )23;
         sqlstm.sqhsts[1] = (         int  )0;
         sqlstm.sqindv[1] = (         short *)0;
         sqlstm.sqinds[1] = (         int  )0;
         sqlstm.sqharm[1] = (unsigned long )0;
         sqlstm.sqadto[1] = (unsigned short )0;
         sqlstm.sqtdso[1] = (unsigned short )0;
         sqlstm.sqphsv = sqlstm.sqhstv;
         sqlstm.sqphsl = sqlstm.sqhstl;
         sqlstm.sqphss = sqlstm.sqhsts;
         sqlstm.sqpind = sqlstm.sqindv;
         sqlstm.sqpins = sqlstm.sqinds;
         sqlstm.sqparm = sqlstm.sqharm;
         sqlstm.sqparc = sqlstm.sqharc;
         sqlstm.sqpadto = sqlstm.sqadto;
         sqlstm.sqptdso = sqlstm.sqtdso;
         sqlcxt(&p_conn, &sqlctx, &sqlstm, &sqlfpn);
         if (sqlca.sqlcode < 0) goto SQL_ERROR_OCCURED;
}


      }
      else
      {
         ELOG(0,0,"Invalid Type");
      }
   }
   /* EXEC SQL COMMIT; */ 

{
   struct sqlexd sqlstm;
   sqlstm.sqlvsn = 12;
   sqlstm.arrsiz = 13;
   sqlstm.sqladtp = &sqladt;
   sqlstm.sqltdsp = &sqltds;
   sqlstm.iters = (unsigned int  )1;
   sqlstm.offset = (unsigned int  )466;
   sqlstm.cud = sqlcud0;
   sqlstm.sqlest = (unsigned char  *)&sqlca;
   sqlstm.sqlety = (unsigned short)256;
   sqlstm.occurs = (unsigned int  )0;
   sqlcxt(&p_conn, &sqlctx, &sqlstm, &sqlfpn);
   if (sqlca.sqlcode < 0) goto SQL_ERROR_OCCURED;
}



   LLOG(0,0,"UpdateOamTransData::executeQuery Updating Done");


   m_DbQueryRes = DB_QUERY_RES_SUCCESS;	
   m_sqlcode = sqlca.sqlcode;
   return true;

SQL_ERROR_OCCURED:
   m_DbQueryRes = DB_QUERY_RES_CODE_EXCEPTION;	
   ELOG(0,0,"UpdateOamTransData::executeQuery: SQL Error Occurred");
   m_sqlcode = sqlca.sqlcode;
   return false;

DATA_NOT_FOUND:
   m_DbQueryRes = DB_QUERY_RES_ROWS_NOT_FOUND;	
   m_sqlcode = sqlca.sqlcode;
   LLOG(0,0,"UpdateOamTransData::executeQuery: Data Not Found");
   return false;
}





