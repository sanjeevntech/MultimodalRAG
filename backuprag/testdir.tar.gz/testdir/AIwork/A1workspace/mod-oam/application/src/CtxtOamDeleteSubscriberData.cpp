#include <CtxtOamDeleteSubscriberData.h>
#include <stdio.h>
#include <MapMessages.h>
#include <ServiceCoordinator.h>
#include <Logger.h>
#include <OMAP1.h>
#include <OMAP2.h>
#include <OMAP3.h>
#include <OamDbQueries.h>
#include <DbActiveObject.h>
#include <ConfigReader.h>
#include <OamConfigReader.h>
#include <Utilities.h>
#include <DataUnion.h>
#include <HlrTdrFiller.h>
#include <SubsProfilesManager.h>

bool resetStruct(int p_version, int p_pdu, void *p_struct)
{
   return false;
}


CtxtOamDeleteSubscriberData::CtxtOamDeleteSubscriberData()
{
   DLOG(0,0,"CtxtOamDeleteSubscriberData::CtxtOamDeleteSubscriberData()");
   memset(m_TransId, '\0', sizeof(m_TransId));
   m_UserDlgId=0;
}

CtxtOamDeleteSubscriberData::~CtxtOamDeleteSubscriberData()
{
   DLOG(0,0,"CtxtOamDeleteSubscriberData::~CtxtOamDeleteSubscriberData()");
}


bool CtxtOamDeleteSubscriberData::sendv3Dsd()
{
   string l_imsi = ConfigReader::readValue(m_DataString, "IMSI");
   if (0 == l_imsi.length())
   {
      CLOG(0,0,"Unknown IMSI");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }

   LLOG(0,0,"IMSI [%s]", l_imsi.c_str());

   string l_type = ConfigReader::readValue(m_DataString, "TYPE");
   if (0 == l_type.length())
   {
      CLOG(0,0,"Unknown TYPE");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }

   if ( (l_type.compare("GSM") != 0) &&
         ((l_type.compare("GPRS") != 0)))
   {
      CLOG(0,1,"Invalid TYPE %s", (char*)l_type.c_str());
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }

   string l_destAddress;
   l_destAddress = ConfigReader::readValue(m_DataString, "DEST_ADDRESS");
   if(0 == l_destAddress.length())
   {
      CLOG(0,0,"Unknown DEST_ADDRESS");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }

   string l_origAddress;
   l_origAddress = ConfigReader::readValue(m_DataString, "ORIG_ADDRESS");
   if(0 == l_origAddress.length())
   {
      CLOG(0,0,"Unknown ORIG_ADDRESS");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }

   bool l_somethingToSendPresent = false;
   string l_bearerService = ConfigReader::readValue(m_DataString, "BEARER_SERVICE_LIST");
   if(l_bearerService.length() > 0)
   {
      LLOG(0,0,"Bearer Service Codes [%s]", l_bearerService.c_str());
      l_somethingToSendPresent=true;
   }

   string l_teleService = ConfigReader::readValue(m_DataString, "TELE_SERVICE_LIST");
   if(l_teleService.length() > 0)
   {
      LLOG(0,0,"Tele Service Codes [%s]", l_teleService.c_str());
      l_somethingToSendPresent=true;
   }

   string l_ssList = ConfigReader::readValue(m_DataString, "SS_LIST");
   if(l_ssList.length() > 0)
   {
      LLOG(0,0,"SS Codes [%s]", l_ssList.c_str());
      l_somethingToSendPresent=true;
   }

   string l_removeRoaming = ConfigReader::readValue(m_DataString, "REMOVE_ROAMING");
   if(l_removeRoaming.length() > 0)
   {
      LLOG(0,0,"Remove Roaming feature present");
      l_somethingToSendPresent=true;
   }

   string l_removeAllCsi = ConfigReader::readValue(m_DataString, "REMOVE_ALL_CSI");
   if(l_removeAllCsi.length() > 0)
   {
      LLOG(0,0,"Remove All CSI feature present");
      l_somethingToSendPresent=true;
   }

   string l_removeSpecificCsi = ConfigReader::readValue(m_DataString, "REMOVE_SPECIFIC_CSI");
   if(l_removeSpecificCsi.length() > 0)
   {
      LLOG(0,0,"Remove Specific CSI feature present");
      l_somethingToSendPresent=true;
   }

   string l_removeGprs = ConfigReader::readValue(m_DataString, "REMOVE_GPRS");
   if(l_removeGprs.length() > 0)
   {
      LLOG(0,0,"Remove GPRS Subscription feature present");
      l_somethingToSendPresent=true;
   }

   string l_contextList =  ConfigReader::readValue(m_DataString, "CONTEXT_LIST");
   if(l_contextList.length() > 0)
   {
      LLOG(0,0,"CONTEXT_LIST present");
      l_somethingToSendPresent=true;
   }

   if(false == l_somethingToSendPresent)
   {
      CLOG(0,0,"Nothing meaningful to send DSD v3");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }

   m_UserDlgId = g_sc.getNewDialogue();
   if(m_UserDlgId < 1)
   {
      ELOG(0,0,"Couldnt get a new dialogue");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }
   LLOG(0,0,"Sending MapOpenReq v3 ...");
   MapOpenReq l_mapOpenReq(m_UserDlgId, MAP_V3);
   l_mapOpenReq.m_ApplCntxt = MAP_AC_CODE_subscriberDataMngt;
   configureSccpAddress(&l_mapOpenReq.m_OrigAddr, L_ROUTE_ON_GT, 0, g_ConfigData->i_NgConfigData.m_LocalSSN, (char*)l_origAddress.c_str());
   m_tdr.setMapVersion(3);
   m_tdr.setString(TDR_INDEX_LOCAL_ADDRESS, (char*)l_origAddress.c_str());

   if(0 == l_type.compare("GSM"))
   {
      m_tdr.setRemoteAddrSsn(7);
      configureSccpAddress(&l_mapOpenReq.m_DestAddr, L_ROUTE_ON_GT, 0, 7, (char*)l_destAddress.c_str());
   }
   else
   {
      m_tdr.setRemoteAddrSsn(149);
      configureSccpAddress(&l_mapOpenReq.m_DestAddr, L_ROUTE_ON_GT, 0, 149, (char*)l_destAddress.c_str());
   }
   m_tdr.setRemoteAddr((char*)l_destAddress.c_str());

   g_sc.sendMsg(this, &l_mapOpenReq);

   DLOG(0,0,"Sending MapSpecificRequest v3...");
   MapSpecificRequest l_request(m_UserDlgId, MAP_OP_CODE_deleteSubscriberData, MAP_V3);

   DECLARE(OMAP3_DeleteSubscriberDataArg, l_dsd3, 3, "OMAP3_DeleteSubscriberDataArg", resetStruct);

   l_dsd3->imsi.length = (strlen((char*)l_imsi.c_str())+1)/2;

   numToBCD((u8*)l_imsi.c_str(), (u8*)(l_dsd3->imsi.value), strlen(l_imsi.c_str()));

   m_tdr.setChar(TDR_INDEX_REQUEST_TYPE,'I');
   m_tdr.setString(TDR_INDEX_REQUEST_IMSI,(char*)l_imsi.c_str());

   char l_value[10];
   memset(l_value, '\0', 10);

   // Send Bearer Service Codes
   for(int i=1; i<=50; i++)
   {
      sprintf(l_value, "VAL_%02d", i);
      string l_valueChar = ConfigReader::readValue(l_bearerService, l_value);
      if(0 < l_valueChar.length())
      {
         l_dsd3->bit_mask |= OMAP3_DeleteSubscriberDataArg_basicServiceList_present;
         l_dsd3->basicServiceList.value[l_dsd3->basicServiceList.count].choice = OMAP3_Ext_BasicServiceCode_ext_BearerService_chosen;
         l_dsd3->basicServiceList.value[l_dsd3->basicServiceList.count].u.ext_BearerService.length = 1;
         l_dsd3->basicServiceList.value[l_dsd3->basicServiceList.count].u.ext_BearerService.value[0]= atoi((char*)l_valueChar.c_str());
         l_dsd3->basicServiceList.count++;
      }
   }

   // Send Tele Service Codes
   for(int i=1; i<=30; i++)
   {
      sprintf(l_value, "VAL_%02d", i);
      string l_valueChar = ConfigReader::readValue(l_teleService, l_value);
      if(0 < l_valueChar.length())
      {
         l_dsd3->bit_mask |= OMAP3_DeleteSubscriberDataArg_basicServiceList_present;
         l_dsd3->basicServiceList.value[l_dsd3->basicServiceList.count].choice = OMAP3_Ext_BasicServiceCode_ext_Teleservice_chosen;
         l_dsd3->basicServiceList.value[l_dsd3->basicServiceList.count].u.ext_Teleservice.length = 1;
         l_dsd3->basicServiceList.value[l_dsd3->basicServiceList.count].u.ext_Teleservice.value[0]= atoi((char*)l_valueChar.c_str());
         l_dsd3->basicServiceList.count++;
      }
   }


   string l_NetworkId = ConfigReader::readValue(m_DataString, "NETWORK_ID");
   if(l_NetworkId.length() > 0)
   {
      LLOG(0,0,"Network Id [%s]", l_NetworkId.c_str());
   }

   bool l_toSendCFWDInfo = true;
   map<int, HlrNetworks* > :: iterator l_HlrNetworksDetailsIter;
   l_HlrNetworksDetailsIter = g_spdPtr->m_HlrNetworks.find(atoi(l_NetworkId.c_str()));
   if(l_HlrNetworksDetailsIter != g_spdPtr->m_HlrNetworks.end())
   {
      TLOG(0,0,"NetworkId[%d] present in HlrNetworks Map, checking for DisableFwdInfoInIsdSri Value",atoi(l_NetworkId.c_str()));
      if(1 ==(l_HlrNetworksDetailsIter->second)->m_DisableFwdInfoInIsdSri)
      {
         LLOG(0,0,"DisableFwdInfoInIsdSri|%d| is Enabled",(l_HlrNetworksDetailsIter->second)->m_DisableFwdInfoInIsdSri);
         l_toSendCFWDInfo = false;
      }
      else
      {
         LLOG(0,0,"DisableFwdInfoInIsdSri|%d| is Disabled, Sending DSD",(l_HlrNetworksDetailsIter->second)->m_DisableFwdInfoInIsdSri);
      }
   }
   else
   {
      TLOG(0,0,"NetworkId[%d]not present in HlrNetworks Map, Not checking DisableFwdInfoInIsdSri Value, Sending FWD info in DSD",atoi(l_NetworkId.c_str()));
   }

   // Send SS Service Codes
   for(int i=1; i<=10; i++)
   {
      sprintf(l_value, "VAL_%02d", i);
      string l_valueChar = ConfigReader::readValue(l_ssList, l_value);
      if(0 < l_valueChar.length())
      {
         if(false == l_toSendCFWDInfo)
         {
            LLOG(0,0,"ToSendCFWDInfo Flag is %d, checking for SS services",l_toSendCFWDInfo);
            if((33 == atoi(l_valueChar.c_str())) || (36 == atoi(l_valueChar.c_str())) || (41 == atoi(l_valueChar.c_str())) || (42 == atoi(l_valueChar.c_str())) || (43 == atoi(l_valueChar.c_str())))
            {
               TLOG(0,0,"ToSendCFWDInfo Flag is %d, not sending DSD",l_toSendCFWDInfo);
               return false;
            }
         }
         else
         {
            LLOG(0,0,"ToSendCFWDInfo Flag is %d, Sending DSD of SS List Value[%d]",l_toSendCFWDInfo,atoi((char*)l_valueChar.c_str()));
            l_dsd3->bit_mask |= OMAP3_DeleteSubscriberDataArg_ss_List_present;
            l_dsd3->ss_List.value[l_dsd3->ss_List.count].length = 1;
            l_dsd3->ss_List.value[l_dsd3->ss_List.count].value[0] = atoi((char*)l_valueChar.c_str());
            DLOG(0,0,"SS list here[%d]",l_dsd3->ss_List.value[l_dsd3->ss_List.count].value[0]);
            l_dsd3->ss_List.count++;
            DLOG(0,0,"SS list count[%d]",l_dsd3->ss_List.count);
         }
      }
   }

   if(l_removeRoaming.length() > 0)
   {
      DLOG(0,0,"OMAP3_DeleteSubscriberDataArg_roamingRestrictionDueToUnsupportedFeature_present");
      l_dsd3->bit_mask |= OMAP3_DeleteSubscriberDataArg_roamingRestrictionDueToUnsupportedFeature_present;
   }

   if(l_removeAllCsi.length() > 0)
   {
      l_dsd3->bit_mask |= OMAP3_camelSubscriptionInfoWithdraw_present;
   }

   if(l_removeSpecificCsi.length() > 0)
   {
      l_dsd3->specificCSI_Withdraw.length = 11;
      l_dsd3->bit_mask |= OMAP3_specificCSI_Withdraw_present;

      char l_csi[30];
      memset(l_csi, '\0', sizeof(l_csi));
      strcpy(l_csi, (char*)l_removeSpecificCsi.c_str());

      LLOG(0,0,"CSI %s", l_csi);

      if('1' == l_csi[0])
      {
         LLOG(0,0,"Adding O");
         l_dsd3->specificCSI_Withdraw.value[0] |= OMAP3_SpecificCSI_Withdraw_o_csi;
      }
      if('1' == l_csi[1])
      {
         LLOG(0,0,"Adding SS");
         l_dsd3->specificCSI_Withdraw.value[0] |= OMAP3_ss_csi;
      }
      if('1' == l_csi[2])
      {
         LLOG(0,0,"Adding TIF");
         l_dsd3->specificCSI_Withdraw.value[0] |= OMAP3_tif_csi;
      }
      if('1' == l_csi[3])
      {
         LLOG(0,0,"Adding D");
         l_dsd3->specificCSI_Withdraw.value[0] |= OMAP3_SpecificCSI_Withdraw_d_csi;
      }
      if('1' == l_csi[4])
      {
         LLOG(0,0,"Adding VT");
         l_dsd3->specificCSI_Withdraw.value[0] |= OMAP3_SpecificCSI_Withdraw_vt_csi;
      }
      if('1' == l_csi[5])
      {
         LLOG(0,0,"Adding MO SMS");
         l_dsd3->specificCSI_Withdraw.value[0] |= OMAP3_mo_sms_csi;
      }
      if('1' == l_csi[6])
      {
         LLOG(0,0,"Adding M");
         l_dsd3->specificCSI_Withdraw.value[0] |= OMAP3_m_csi;
      }
      if('1' == l_csi[9])
      {
         LLOG(0,0,"Adding MT SMS");
         l_dsd3->specificCSI_Withdraw.value[1] |= OMAP3_SpecificCSI_Withdraw_mt_sms_csi;
      }
      if('1' == l_csi[10])
      {
         LLOG(0,0,"Adding MG");
         l_dsd3->specificCSI_Withdraw.value[1] |= OMAP3_SpecificCSI_Withdraw_mg_csi;
      }
   }

   if(l_removeGprs.length() > 0)
   {
      l_dsd3->bit_mask |= OMAP3_gprsSubscriptionDataWithdraw_present;
      l_dsd3->gprsSubscriptionDataWithdraw.choice = OMAP3_allGPRSData_chosen;
   }

   if(l_contextList.length() > 0)
   {
      l_dsd3->bit_mask |= OMAP3_gprsSubscriptionDataWithdraw_present;
      l_dsd3->gprsSubscriptionDataWithdraw.choice = OMAP3_contextIdList_chosen;

      char l_buff[50][100];
      memset(l_buff,'\0',sizeof(l_buff));
      int l_len = tokenize2((char*)l_contextList.c_str(), (char*)l_buff, 100, '|');
      TLOG(0,1,"ContextListCount:[%d] tokenized data: [%s] [%s] [%s] [%s] [%s]", l_len-1, l_buff[0],l_buff[1],l_buff[2],l_buff[3],l_buff[4]);

      l_dsd3->gprsSubscriptionDataWithdraw.u.contextIdList.count = l_len - 1;
      for(int i=0; i<l_dsd3->gprsSubscriptionDataWithdraw.u.contextIdList.count; i++)
      {
         if(i == 50)
         {
            TLOG(0,0,"Not allowing more than 50 contexts");
            break;
         }
         l_dsd3->gprsSubscriptionDataWithdraw.u.contextIdList.value[i] = (OMAP3_ContextId)atoi((char*)l_buff[i+1]);
         TLOG(0,0,"Context Value[%d]",l_dsd3->gprsSubscriptionDataWithdraw.u.contextIdList.value[i])
      }
   }

   l_request.m_structBuffer = (void*)l_dsd3;
   g_sc.sendMsg(this, &l_request);

   TLOG(0,0,"Sending MapDelimiterReq Req ...");
   MapDelimiterReq l_del(m_UserDlgId);
   g_sc.sendMsg(this, &l_del);
   return true;
}

bool CtxtOamDeleteSubscriberData::sendv2Dsd()
{
   string l_imsi = ConfigReader::readValue(m_DataString, "IMSI");
   if (0 == l_imsi.length())
   {
      CLOG(0,0,"Unknown IMSI");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }

   string l_type = ConfigReader::readValue(m_DataString, "TYPE");
   if (0 == l_type.length())
   {
      CLOG(0,0,"Unknown TYPE");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }

   if ( l_type.compare("GSM") != 0)
   {
      CLOG(0,1,"Invalid TYPE %s", (char*)l_type.c_str());
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }

   string l_destAddress;
   l_destAddress = ConfigReader::readValue(m_DataString, "DEST_ADDRESS");
   if(0 == l_destAddress.length())
   {
      CLOG(0,0,"Unknown DEST_ADDRESS");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }

   string l_origAddress;
   l_origAddress = ConfigReader::readValue(m_DataString, "ORIG_ADDRESS");
   if(0 == l_origAddress.length())
   {
      CLOG(0,0,"Unknown ORIG_ADDRESS");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }


   bool l_somethingToSendPresent = false;

   string l_bearerService = ConfigReader::readValue(m_DataString, "BEARER_SERVICE_LIST");
   if(l_bearerService.length() > 0)
   {
      LLOG(0,0,"Bearer Service Codes [%s]", l_bearerService.c_str());
      l_somethingToSendPresent=true;
   }

   string l_teleService = ConfigReader::readValue(m_DataString, "TELE_SERVICE_LIST");
   if(l_teleService.length() > 0)
   {
      LLOG(0,0,"Tele Service Codes [%s]", l_teleService.c_str());
      l_somethingToSendPresent=true;
   }

   string l_ssList = ConfigReader::readValue(m_DataString, "SS_LIST");
   if(l_ssList.length() > 0)
   {
      LLOG(0,0,"SS Codes [%s]", l_ssList.c_str());
      l_somethingToSendPresent=true;
   }

   string l_removeRoaming = ConfigReader::readValue(m_DataString, "REMOVE_ROAMING");
   if(l_removeRoaming.length() > 0)
   {
      LLOG(0,0,"Remove Roaming feature present");
      l_somethingToSendPresent=true;
   }


   if(false == l_somethingToSendPresent)
   {
      CLOG(0,0,"Nothing meaningful to send DSD v2");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }

   m_UserDlgId = g_sc.getNewDialogue();
   if(m_UserDlgId < 1)
   {
      ELOG(0,0,"Couldn't get a new dialogue");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }
   TLOG(0,0,"Sending MapOpenReq v2 ...");
   MapOpenReq l_mapOpenReq(m_UserDlgId, MAP_V2);
   l_mapOpenReq.m_ApplCntxt = MAP_AC_CODE_subscriberDataMngt;
   m_tdr.setMapVersion(2);
   configureSccpAddress(&l_mapOpenReq.m_OrigAddr, L_ROUTE_ON_GT, 0, g_ConfigData->i_NgConfigData.m_LocalSSN, (char*)l_origAddress.c_str());
   m_tdr.setString(TDR_INDEX_LOCAL_ADDRESS, (char*)l_origAddress.c_str());
   configureSccpAddress(&l_mapOpenReq.m_DestAddr, L_ROUTE_ON_GT, 0, 7, (char*)l_destAddress.c_str());
   m_tdr.setRemoteAddrSsn(7);
   m_tdr.setRemoteAddr((char*)l_destAddress.c_str());

   g_sc.sendMsg(this, &l_mapOpenReq);

   TLOG(0,0,"Sending MapSpecificRequest v2...");
   MapSpecificRequest l_request(m_UserDlgId, MAP_OP_CODE_deleteSubscriberData, MAP_V2);

   DECLARE(OMAP2_DeleteSubscriberDataArg, l_dsd2, 2, "OMAP2_DeleteSubscriberDataArg", resetStruct);

   l_dsd2->imsi.length = (strlen((char*)l_imsi.c_str())+1)/2;
   numToBCD((u8*)l_imsi.c_str(), (u8*)(l_dsd2->imsi.value), strlen(l_imsi.c_str()));

   m_tdr.setChar(TDR_INDEX_REQUEST_TYPE,'I');
   m_tdr.setString(TDR_INDEX_REQUEST_IMSI,(char*)l_imsi.c_str());

   char l_value[10];
   memset(l_value, '\0', 10);

   // Send Bearer Service Codes
   for(int i=1; i<=50; i++)
   {
      sprintf(l_value, "VAL_%02d", i);
      string l_valueChar = ConfigReader::readValue(l_bearerService, l_value);
      if(0 < l_valueChar.length())
      {
         l_dsd2->bit_mask |= OMAP2_basicServiceList_present;
         printf("\nBearer Service Code [%s]", l_valueChar.c_str());
         l_dsd2->basicServiceList.value[l_dsd2->basicServiceList.count].choice = OMAP2_bearerService_chosen;
         l_dsd2->basicServiceList.value[l_dsd2->basicServiceList.count].u.bearerService.length = 1;
         l_dsd2->basicServiceList.value[l_dsd2->basicServiceList.count].u.bearerService.value[0]= atoi((char*)l_valueChar.c_str());
         l_dsd2->basicServiceList.count++;
      }
   }

   // Send Tele Service Codes
   for(int i=1; i<=30; i++)
   {
      sprintf(l_value, "VAL_%02d", i);
      string l_valueChar = ConfigReader::readValue(l_teleService, l_value);
      if(0 < l_valueChar.length())
      {
         l_dsd2->bit_mask |= OMAP2_basicServiceList_present;
         l_dsd2->basicServiceList.value[l_dsd2->basicServiceList.count].choice = OMAP2_teleservice_chosen;
         l_dsd2->basicServiceList.value[l_dsd2->basicServiceList.count].u.teleservice.length = 1;
         l_dsd2->basicServiceList.value[l_dsd2->basicServiceList.count].u.teleservice.value[0]= atoi((char*)l_valueChar.c_str());
         l_dsd2->basicServiceList.count++;
      }
   }

   
   string l_NetworkId = ConfigReader::readValue(m_DataString, "NETWORK_ID");
   if(l_NetworkId.length() > 0)
   {
      LLOG(0,0,"Network Id [%s]", l_NetworkId.c_str());
   }

   bool l_toSendCFWDInfo = true;
   map<int, HlrNetworks* > :: iterator l_HlrNetworksDetailsIter;
   l_HlrNetworksDetailsIter = g_spdPtr->m_HlrNetworks.find(atoi(l_NetworkId.c_str()));
   if(l_HlrNetworksDetailsIter != g_spdPtr->m_HlrNetworks.end())
   {
      TLOG(0,0,"NetworkId[%d] present in HlrNetworks Map, checking for DisableFwdInfoInIsdSri Value",atoi(l_NetworkId.c_str()));
      if(1 ==(l_HlrNetworksDetailsIter->second)->m_DisableFwdInfoInIsdSri)
      {
         LLOG(0,0,"DisableFwdInfoInIsdSri|%d| is Enabled",(l_HlrNetworksDetailsIter->second)->m_DisableFwdInfoInIsdSri);
         l_toSendCFWDInfo = false;
      }
      else
      {
         LLOG(0,0,"DisableFwdInfoInIsdSri|%d| is Disabled, Sending DSD",(l_HlrNetworksDetailsIter->second)->m_DisableFwdInfoInIsdSri);
      }
   }
   else
   {
      TLOG(0,0,"NetworkId[%d]not present in HlrNetworks Map, Not checking DisableFwdInfoInIsdSri Value, Sending FWD info in ISD",atoi(l_NetworkId.c_str()));
   }

   // Send SS Service Codes
   for(int i=1; i<=10; i++)
   {
      sprintf(l_value, "VAL_%02d", i);
      string l_valueChar = ConfigReader::readValue(l_ssList, l_value);
      if(0 < l_valueChar.length())
      {
         if(false == l_toSendCFWDInfo)
         {
            LLOG(0,0,"ToSendCFWDInfo Flag is %d, checking for SS services",l_toSendCFWDInfo);
            if((33 == atoi(l_valueChar.c_str())) || (36 == atoi(l_valueChar.c_str())) || (41 == atoi(l_valueChar.c_str())) || (42 == atoi(l_valueChar.c_str())) || (43 == atoi(l_valueChar.c_str())))
            {
               TLOG(0,0,"ToSendCFWDInfo Flag is %d, not sending DSD",l_toSendCFWDInfo);
               return false;
            }
         }
         else
         {
            LLOG(0,0,"ToSendCFWDInfo Flag is %d, Sending DSD",l_toSendCFWDInfo);
            l_dsd2->bit_mask |= OMAP2_DeleteSubscriberDataArg_ss_List_present;
            l_dsd2->ss_List.value[l_dsd2->ss_List.count].length = 1;
            l_dsd2->ss_List.value[l_dsd2->ss_List.count].value[0] = atoi((char*)l_valueChar.c_str());
            l_dsd2->ss_List.count++;
         }
      }
   }

   if(l_removeRoaming.length() > 0)
   {
      l_dsd2->bit_mask |= OMAP2_DeleteSubscriberDataArg_roamingRestrictionDueToUnsupportedFeature_present;
   }

   l_request.m_structBuffer = (void*)l_dsd2;
   g_sc.sendMsg(this, &l_request);

   TLOG(0,0,"Sending MapDelimiterReq Req ...");
   MapDelimiterReq l_del(m_UserDlgId);
   g_sc.sendMsg(this, &l_del);
   return true;
}


bool CtxtOamDeleteSubscriberData::sendv1Dsd()
{
   string l_imsi = ConfigReader::readValue(m_DataString, "IMSI");
   if (0 == l_imsi.length())
   {
      CLOG(0,0,"Unknown IMSI");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }

   string l_type = ConfigReader::readValue(m_DataString, "TYPE");
   if (0 == l_type.length())
   {
      CLOG(0,0,"Unknown TYPE");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }

   if ( l_type.compare("GSM") != 0)
   {
      CLOG(0,1,"Invalid TYPE %s", (char*)l_type.c_str());
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }

   string l_destAddress;
   l_destAddress = ConfigReader::readValue(m_DataString, "DEST_ADDRESS");
   if(0 == l_destAddress.length())
   {
      CLOG(0,0,"Unknown DEST_ADDRESS");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }

   string l_origAddress;
   l_origAddress = ConfigReader::readValue(m_DataString, "ORIG_ADDRESS");
   if(0 == l_origAddress.length())
   {
      CLOG(0,0,"Unknown ORIG_ADDRESS");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }

   bool l_somethingToSendPresent = false;

   string l_bearerService = ConfigReader::readValue(m_DataString, "BEARER_SERVICE_LIST");
   if(l_bearerService.length() > 0)
   {
      LLOG(0,0,"Bearer Service Codes [%s]", l_bearerService.c_str());
      l_somethingToSendPresent=true;
   }

   string l_teleService = ConfigReader::readValue(m_DataString, "TELE_SERVICE_LIST");
   if(l_teleService.length() > 0)
   {
      LLOG(0,0,"Tele Service Codes [%s]", l_teleService.c_str());
      l_somethingToSendPresent=true;
   }

   string l_ssList = ConfigReader::readValue(m_DataString, "SS_LIST");
   if(l_ssList.length() > 0)
   {
      LLOG(0,0,"SS Codes [%s]", l_ssList.c_str());
      l_somethingToSendPresent=true;
   }

   if(false == l_somethingToSendPresent)
   {
      CLOG(0,0,"Nothing meaningful to send DSD v1");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }


   m_UserDlgId = g_sc.getNewDialogue();
   if(m_UserDlgId < 1)
   {
      ELOG(0,0,"Couldn't allocate a dialogue");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }


   TLOG(0,0,"Sending MapOpenReq v1...");
   MapOpenReq l_mapOpenReq(m_UserDlgId, MAP_V1);
   l_mapOpenReq.m_ApplCntxt = MAP_AC_CODE_subscriberDataMngt;
   m_tdr.setMapVersion(1);

   configureSccpAddress(&l_mapOpenReq.m_OrigAddr, L_ROUTE_ON_GT, 0, g_ConfigData->i_NgConfigData.m_LocalSSN, (char*)l_origAddress.c_str());
   m_tdr.setString(TDR_INDEX_LOCAL_ADDRESS, (char*)l_origAddress.c_str());
   configureSccpAddress(&l_mapOpenReq.m_DestAddr, L_ROUTE_ON_GT, 0, 7, (char*)l_destAddress.c_str());
   m_tdr.setRemoteAddrSsn(7);
   m_tdr.setRemoteAddr((char*)l_destAddress.c_str());

   g_sc.sendMsg(this, &l_mapOpenReq);

   TLOG(0,0,"Sending MapSpecificRequest v1...");
   MapSpecificRequest l_request(m_UserDlgId, MAP_OP_CODE_deleteSubscriberData, MAP_V1);

   DECLARE(OMAP1_DeleteSubscriberDataArg, l_dsd1, 1, "OMAP1_DeleteSubscriberDataArg", resetStruct);

   l_dsd1->imsi.length = (strlen((char*)l_imsi.c_str())+1)/2;
   numToBCD((u8*)l_imsi.c_str(), (u8*)(l_dsd1->imsi.value), strlen(l_imsi.c_str()));

   m_tdr.setChar(TDR_INDEX_REQUEST_TYPE,'I');
   m_tdr.setString(TDR_INDEX_REQUEST_IMSI,(char*)l_imsi.c_str());

   char l_value[10];
   memset(l_value, '\0', 10);


   // Send Bearer Service Codes
   for(int i=1; i<=50; i++)
   {
      sprintf(l_value, "VAL_%02d", i);
      string l_valueChar = ConfigReader::readValue(l_bearerService, l_value);
      if(0 < l_valueChar.length())
      {
         l_dsd1->bit_mask |= OMAP1_DeleteSubscriberDataArg_basicService_present;
         l_dsd1->basicService.value[l_dsd1->basicService.count].choice = OMAP1_bearerService_chosen;
         l_dsd1->basicService.value[l_dsd1->basicService.count].u.bearerService.length = 1;
         l_dsd1->basicService.value[l_dsd1->basicService.count].u.bearerService.value[0]= atoi((char*)l_valueChar.c_str());
         l_dsd1->basicService.count++;
      }
   }

   // Send Tele Service Codes
   for(int i=1; i<=30; i++)
   {
      sprintf(l_value, "VAL_%02d", i);
      string l_valueChar = ConfigReader::readValue(l_teleService, l_value);
      if(0 < l_valueChar.length())
      {
         l_dsd1->bit_mask |= OMAP1_DeleteSubscriberDataArg_basicService_present;
         l_dsd1->basicService.value[l_dsd1->basicService.count].choice = OMAP1_teleservice_chosen;
         l_dsd1->basicService.value[l_dsd1->basicService.count].u.teleservice.length = 1;
         l_dsd1->basicService.value[l_dsd1->basicService.count].u.teleservice.value[0]= atoi((char*)l_valueChar.c_str());
         l_dsd1->basicService.count++;
      }
   }

   string l_NetworkId = ConfigReader::readValue(m_DataString, "NETWORK_ID");
   if(l_NetworkId.length() > 0)
   {
      LLOG(0,0,"Network Id [%s]", l_NetworkId.c_str());
   }

   bool l_toSendCFWDInfo = true;
   map<int, HlrNetworks* > :: iterator l_HlrNetworksDetailsIter;
   l_HlrNetworksDetailsIter = g_spdPtr->m_HlrNetworks.find(atoi(l_NetworkId.c_str()));
   if(l_HlrNetworksDetailsIter != g_spdPtr->m_HlrNetworks.end())
   {
      TLOG(0,0,"NetworkId[%d] present in HlrNetworks Map, checking for DisableFwdInfoInIsdSri Value",atoi(l_NetworkId.c_str()));
      if(1 ==(l_HlrNetworksDetailsIter->second)->m_DisableFwdInfoInIsdSri)
      {
         LLOG(0,0,"DisableFwdInfoInIsdSri|%d| is Enabled",(l_HlrNetworksDetailsIter->second)->m_DisableFwdInfoInIsdSri);
         l_toSendCFWDInfo = false;
      }
      else
      {
         LLOG(0,0,"DisableFwdInfoInIsdSri|%d| is Disabled, Sending DSD",(l_HlrNetworksDetailsIter->second)->m_DisableFwdInfoInIsdSri);
      }
   }
   else
   {
      TLOG(0,0,"NetworkId[%d]not present in HlrNetworks Map, Not checking DisableFwdInfoInIsdSri Value, Sending FWD info in DSD",atoi(l_NetworkId.c_str()));
   }

   // Send SS Service Codes
   for(int i=1; i<=10; i++)
   {
      sprintf(l_value, "VAL_%02d", i);
      string l_valueChar = ConfigReader::readValue(l_ssList, l_value);
      if(0 < l_valueChar.length())
      {
         if(false == l_toSendCFWDInfo)
         {
            LLOG(0,0,"ToSendCFWDInfo Flag is %d, checking for SS services",l_toSendCFWDInfo);
            if((33 == atoi(l_valueChar.c_str())) || (36 == atoi(l_valueChar.c_str())) || (41 == atoi(l_valueChar.c_str())) || (42 == atoi(l_valueChar.c_str())) || (    43 == atoi(l_valueChar.c_str())))
            {
               TLOG(0,0,"ToSendCFWDInfo Flag is %d, not sending DSD",l_toSendCFWDInfo);
               return false;
            }
         }
         else
         {
            LLOG(0,0,"ToSendCFWDInfo Flag is %d, Sending DSD of SS List Value[%d]",l_toSendCFWDInfo,atoi((char*)l_valueChar.c_str()));
            l_dsd1->bit_mask |= OMAP1_DeleteSubscriberDataArg_ss_Code_present;
            l_dsd1->ss_Code.value[l_dsd1->ss_Code.count].length = 1;
            l_dsd1->ss_Code.value[l_dsd1->ss_Code.count].value[0] = atoi((char*)l_valueChar.c_str());
            l_dsd1->ss_Code.count++;
         }
      }
   }
   l_request.m_structBuffer = (void*)l_dsd1;
   g_sc.sendMsg(this, &l_request);

   TLOG(0,0,"Sending MapDelimiterReq Req ...");
   MapDelimiterReq l_del(m_UserDlgId);
   g_sc.sendMsg(this, &l_del);
   return true;
}

bool CtxtOamDeleteSubscriberData::startProcessing(InterModuleData *p_imd, bool& p_DeleteFlag)
{
   DLOG(0,0,"CtxtOamDeleteSubscriberData::startProcessing data [%s] [%d]", (NULL == p_imd->m_Parameters)?"":p_imd->m_Parameters, p_DeleteFlag);

   if(NULL == p_imd->m_Parameters)
   {
      CLOG(0,0,"p_imd->m_Parameters NULL returning");
      return false;
   }

   char *l_check = NULL;
   l_check = strchr(p_imd->m_Parameters, ':');
   if(l_check == NULL)
   {
      CLOG(0,0,"Transaction ID not present");
      return false;
   }

   strncpy(m_TransId, p_imd->m_Parameters, strlen(p_imd->m_Parameters)-strlen(l_check)); 

   LLOG(0,0,"Transaction ID :%s", m_TransId);
   m_tdr.setString(TDR_INDEX_OAM_TRANSACTION_ID, m_TransId);

   m_DataString.assign(l_check+1);

   if(g_OamConfigReaderObj->m_DSD_MAP_VERSION == 2)
   {
      sendv2Dsd();
   }
   else if(g_OamConfigReaderObj->m_DSD_MAP_VERSION == 1)
   {
      sendv1Dsd();
   }
   else if(g_OamConfigReaderObj->m_DSD_MAP_VERSION == 3)
   {
      sendv3Dsd();
   }
   else
   {
      ELOG(0,1,"Not implemented");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
   }
   return true;
}


bool CtxtOamDeleteSubscriberData::updateDb(char p_status, char *p_error)
{
   UpdateOamTransData *l_uotd = new UpdateOamTransData;
   l_uotd->m_cb = this;
   l_uotd->m_Status = p_status;
   strcpy(l_uotd->m_TransId, m_TransId);
   strcpy(l_uotd->m_ErrorCause, p_error);
   g_act.execute(l_uotd);
   return true;
}

bool CtxtOamDeleteSubscriberData::processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag)
{
   DLOG(0,0,"Start of CtxtOamDeleteSubscriberData::processMsg function");
   MapSpecificMsg *l_specMsg = NULL;

   switch (p_MsgPtr->m_MsgType)
   {
      case MSG_TYPE_MAP:
         switch (((MapMsg*)p_MsgPtr)->m_MapMsgType)
         {
            case MAP_MSG_TYPE_COMMON:
               switch (((MapCommonMsg*)p_MsgPtr)->m_MapCommonMsgType)
               {
                  case MAP_CMN_OPEN_IND:
                     DLOG(0,0,"MAP_CMN_OPEN_IND received with DlgId [%d], Version [%d]", getInitialRespondingDlgId(),
                           getInitialRespondingVersion());
                     break;

                  case MAP_CMN_OPEN_CNF:
                     {
                        if(REFUSE_REASON_APPL_CNTXT_NOT_SUPPORTED == ((MapOpenCnf*)p_MsgPtr)->m_RefuseReasonParam)
                        {
                           LLOG(0,0,"MAP_CMN_OPEN_CNF received with Version [%d]", ((MapOpenCnf*)p_MsgPtr)->m_Version);
                           m_tdr.setInteger(TDR_INDEX_OPEN_CNF_VERSION,(int)(((MapOpenCnf*)p_MsgPtr)->m_Version));

                           if(MAP_V1 == ((MapOpenCnf*)p_MsgPtr)->m_Version)
                           {
                              sendv1Dsd();
                           }
                           else if(MAP_V2  == ((MapOpenCnf*)p_MsgPtr)->m_Version)
                           {
                              sendv2Dsd();
                           }
                        }
                        else
                        {
                           LLOG(0,0,"MAP_CMN_OPEN_CNF received with other reason [%d]", 
                                 ((MapOpenCnf*)p_MsgPtr)->m_RefuseReasonParam);
                           m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_NOTICE_RCVD); 
                           updateDb('F', "Received Notice");
                        }
                     }
                     break;

                  case MAP_CMN_DELIMITER_IND:
                     {
                        TLOG(0,0,"MAP_CMN_DELIMITER_IND received ");
                     }
                     break;

                  case MAP_CMN_CLOSE_IND:
                     {
                        DLOG(0,0,"MAP_CMN_CLOSE_IND received");
                     }

                     break;

                  case MAP_CMN_U_ABORT_IND:
                     {
                        WLOG(0,0,"MAP_CMN_U_ABORT_IND received");
                        m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_U_ABORT_RCVD); 
                        updateDb('F', "Received U-Abort");
                     }
                     break;

                  case MAP_CMN_P_ABORT_IND:
                     {
                        WLOG(0,0,"MAP_CMN_P_ABORT_IND received");
                        m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_P_ABORT_RCVD); 
                        updateDb('F', "Received P-Abort");
                     }
                     break;

                  case MAP_CMN_NOTICE_IND:
                     {
                        LLOG(0,0,"MAP_CMN_NOTICE_IND received");
                        m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_NOTICE_RCVD); 
                        MapCloseReq l_closeReq(m_UserDlgId);
                        l_closeReq.m_CloseType = MAP_CLOSE_TYPE_PRE_ARRANGED_END;
                        g_sc.sendMsg(this, &l_closeReq);

                        updateDb('F', "Received Notice");
                     }
                     break;

                  default:
                     ELOG(0,0,"Unknown Msg received [%d]", ((MapCommonMsg*)p_MsgPtr)->m_MapCommonMsgType);
                     break;
               }
               break;

            case MAP_MSG_TYPE_SPECIFIC:
               DLOG(0,0,"MAP_MSG_TYPE_SPECIFIC received [%d]", getInitialRespondingDlgId());
               l_specMsg = (MapSpecificMsg*)p_MsgPtr;

               switch (((MapSpecificMsg*)p_MsgPtr)->m_MapSpecificEventType)
               {
                  case MAP_SPEC_EVENT_CONFIRMATION:
                     {
                        DLOG(0,0,"MAP_SPEC_EVENT_CONFIRMATION received");
                        updateDb('S', "");
                     }
                     break;

                  case MAP_SPEC_EVENT_USER_ERROR:
                     {
                        DLOG(0,0,"MAP_SPEC_EVENT_USER_ERROR received");
                        m_tdr.setInteger(TDR_INDEX_ERR_CODE, ((MapUserError*)p_MsgPtr)->m_ErrorCode); 
                        updateDb('F', "Received USER ERROR");
                     }
                     break;

                  case MAP_SPEC_EVENT_PROV_ERROR:
                     {
                        DLOG(0,0,"MAP_SPEC_EVENT_PROV_ERROR received");
                        m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_PROVIDER_ERROR_RCVD); 
                        DLOG(0,0,"Closing the Dialogue");
                        updateDb('F', "Some Error");
                     }
                     break;
                  default:
                     m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_GENERAL_ERROR); 
                     ELOG(0,0,"ERROR!! Default received");
                     break;
               }
               break;

            default:
               break;
         }
         break;

      case MSG_TYPE_DB:
         DLOG(0,0,"DB message received");
         break;

      default:
         ELOG(0,0,"Unknown message received");
         break;

   }
   return true;
}

