#include <CtxtActivateTraceMode.h>
#include <stdio.h>
#include <MapMessages.h>
#include <ServiceCoordinator.h>
#include <Logger.h>
#include <OMAP1.h>
#include <OMAP2.h>
#include <OMAP3.h>
#include <OamDbQueries.h>
#include <DbActiveObject.h>
#include <ConfigReader.h>
#include <OamConfigReader.h>
#include <Utilities.h>
#include <DataUnion.h>
#include <HlrTdrFiller.h>
#include <HlrUtilities.h>


extern bool resetStruct(int p_version, int p_pdu, void *p_struct);


CtxtActivateTraceMode::CtxtActivateTraceMode()
{
   DLOG(0,0,"CtxtActivateTraceMode::CtxtActivateTraceMode()");
   memset(m_TransId, '\0', sizeof(m_TransId));
   m_UserDlgId=0;
   memset(m_imsi, '\0', sizeof(m_imsi));
   memset(m_type, '\0', sizeof(m_type));
   memset(m_lmsi, '\0', sizeof(m_lmsi));
   memset(m_OrigAddr, '\0', sizeof(m_OrigAddr));
   memset(m_DestAddr, '\0', sizeof(m_DestAddr));
}

CtxtActivateTraceMode::~CtxtActivateTraceMode()
{
   DLOG(0,0,"CtxtActivateTraceMode::~CtxtActivateTraceMode()");
}


bool CtxtActivateTraceMode::sendv3ActTraceMode()
{
   string l_imsi = ConfigReader::readValue(m_DataString, "IMSI");
   if (0 == l_imsi.length())
   {
      CLOG(0,0,"Unknown IMSI");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }

   strcpy(m_imsi, (char*)l_imsi.c_str());
   LLOG(0,0,"IMSI [%s]", m_imsi);

   string l_lmsi = ConfigReader::readValue(m_DataString, "LMSI");
   if (0 == l_lmsi.length())
   {
      LLOG(0,0,"Unknown LMSI. Ignoring");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      //return false;
   }

   strcpy(m_lmsi, (char*)l_lmsi.c_str());
   LLOG(0,0,"LMSI [%s]", m_lmsi);


   string l_type = ConfigReader::readValue(m_DataString, "TYPE");
   if (0 == l_type.length())
   {
      CLOG(0,0,"Unknown TYPE");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }

   if ( (l_type.compare("GSM") != 0) &&
         ((l_type.compare("GPRS") != 0)))
   {
      CLOG(0,1,"Invalid TYPE %s", (char*)l_type.c_str());
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }

   strcpy(m_type, (char*)l_type.c_str());

   string l_destAddress;
   l_destAddress = ConfigReader::readValue(m_DataString, "DEST_ADDRESS");
   if(0 == l_destAddress.length())
   {
      CLOG(0,0,"Unknown DEST_ADDRESS");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }
   strcpy(m_DestAddr, (char*)l_destAddress.c_str());

   string l_origAddress;
   l_origAddress = ConfigReader::readValue(m_DataString, "ORIG_ADDRESS");
   if(0 == l_origAddress.length())
   {
      CLOG(0,0,"Unknown ORIG_ADDRESS");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }
   strcpy(m_OrigAddr, (char*)l_origAddress.c_str());

   string l_traceType;
   l_traceType = ConfigReader::readValue(m_DataString, "TRACE_TYPE");
   if(0 == l_traceType.length())
   {
      CLOG(0,0,"Unknown TRACE_TYPE");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }

   string l_traceRef;
   l_traceRef = ConfigReader::readValue(m_DataString, "TRACE_REF");
   if(0 == l_traceRef.length())
   {
      CLOG(0,0,"Unknown TRACE_REF");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }

   string l_omcId;
   l_omcId = ConfigReader::readValue(m_DataString, "OMC_ID");
   if(0 == l_omcId.length())
   {
      CLOG(0,0,"Unknown OMC_ID");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }

   m_UserDlgId = g_sc.getNewDialogue();
   if(m_UserDlgId < 1)
   {
      ELOG(0,0,"Couldnt get a new dialogue");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }
   TLOG(0,0,"Sending MapOpenReq v3 ...");
   MapOpenReq l_mapOpenReq(m_UserDlgId, MAP_V3);
   l_mapOpenReq.m_ApplCntxt = MAP_AC_CODE_tracing;
   configureSccpAddress(&l_mapOpenReq.m_OrigAddr, L_ROUTE_ON_GT, 0, g_ConfigData->i_NgConfigData.m_LocalSSN, (char*)l_origAddress.c_str());
   m_tdr.setMapVersion(3);
   m_tdr.setString(TDR_INDEX_LOCAL_ADDRESS, (char*)l_origAddress.c_str());

   if(0 == l_type.compare("GSM"))
   {
      m_tdr.setRemoteAddrSsn(7);
      configureSccpAddress(&l_mapOpenReq.m_DestAddr, L_ROUTE_ON_GT, 0, 7, (char*)l_destAddress.c_str());
   }
   else
   {
      m_tdr.setRemoteAddrSsn(149);
      configureSccpAddress(&l_mapOpenReq.m_DestAddr, L_ROUTE_ON_GT, 0, 149, (char*)l_destAddress.c_str());
   }
   m_tdr.setRemoteAddr((char*)l_destAddress.c_str());

   g_sc.sendMsg(this, &l_mapOpenReq);

   DLOG(0,0,"Sending MapSpecificRequest v3...");
   MapSpecificRequest l_request(m_UserDlgId, MAP_OP_CODE_activateTraceMode, MAP_V3);

   DECLARE(OMAP3_ActivateTraceModeArg, l_atm3, 3, "OMAP3_ActivateTraceModeArg", resetStruct);

   l_atm3->imsi.length = (strlen((char*)l_imsi.c_str())+1)/2;
   numToBCD((u8*)l_imsi.c_str(), (u8*)(l_atm3->imsi.value), strlen(l_imsi.c_str()));
   l_atm3->bit_mask = OMAP3_ActivateTraceModeArg_imsi_present;

   l_atm3->traceReference.length = 2;
   atohx((char*)l_atm3->traceReference.value, (char*)l_traceRef.c_str());

   unsigned char l_traceTypeChar[2];
   memset(l_traceTypeChar, '\0', sizeof(l_traceTypeChar));
   atohx((char*)l_traceTypeChar, (char*)l_traceType.c_str());

   l_atm3->traceType = l_traceTypeChar[0];

   l_atm3->omc_Id.length = 1 + ((1+strlen((char*)l_omcId.c_str()))/2);
   StringToBCD((u8*)&l_atm3->omc_Id.value[1], (u8*)l_omcId.c_str(), strlen((char*)l_omcId.c_str()));
   l_atm3->omc_Id.value[0] = 0x91;
   l_atm3->bit_mask |= OMAP3_omc_Id_present;


   m_tdr.setChar(TDR_INDEX_REQUEST_TYPE,'I');
   m_tdr.setString(TDR_INDEX_REQUEST_IMSI,(char*)l_imsi.c_str());

   char l_value[10];
   memset(l_value, '\0', 10);

   l_request.m_structBuffer = (void*)l_atm3;
   g_sc.sendMsg(this, &l_request);

   TLOG(0,0,"Sending MapDelimiterReq Req ...");
   MapDelimiterReq l_del(m_UserDlgId);
   g_sc.sendMsg(this, &l_del);
   return true;
}

bool CtxtActivateTraceMode::sendv2ActTraceMode()
{
   string l_imsi = ConfigReader::readValue(m_DataString, "IMSI");
   if (0 == l_imsi.length())
   {
      CLOG(0,0,"Unknown IMSI");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }

   strcpy(m_imsi, (char*)l_imsi.c_str());
   LLOG(0,0,"IMSI [%s]", m_imsi);

   string l_lmsi = ConfigReader::readValue(m_DataString, "LMSI");
   if (0 == l_lmsi.length())
   {
      LLOG(0,0,"Unknown LMSI. Ignoring");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      //return false;
   }

   strcpy(m_lmsi, (char*)l_lmsi.c_str());
   LLOG(0,0,"LMSI [%s]", m_lmsi);

   string l_type = ConfigReader::readValue(m_DataString, "TYPE");
   if (0 == l_type.length())
   {
      CLOG(0,0,"Unknown TYPE");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }

   if ( (l_type.compare("GSM") != 0) &&
         ((l_type.compare("GPRS") != 0)))
   {
      CLOG(0,1,"Invalid TYPE %s", (char*)l_type.c_str());
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }

   strcpy(m_type, (char*)l_type.c_str());


   string l_destAddress;
   l_destAddress = ConfigReader::readValue(m_DataString, "DEST_ADDRESS");
   if(0 == l_destAddress.length())
   {
      CLOG(0,0,"Unknown DEST_ADDRESS");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }
   strcpy(m_DestAddr, (char*)l_destAddress.c_str());

   string l_origAddress;
   l_origAddress = ConfigReader::readValue(m_DataString, "ORIG_ADDRESS");
   if(0 == l_origAddress.length())
   {
      CLOG(0,0,"Unknown ORIG_ADDRESS");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }
   strcpy(m_OrigAddr, (char*)l_origAddress.c_str());

   string l_traceType;
   l_traceType = ConfigReader::readValue(m_DataString, "TRACE_TYPE");
   if(0 == l_traceType.length())
   {
      CLOG(0,0,"Unknown TRACE_TYPE");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }

   string l_traceRef;
   l_traceRef = ConfigReader::readValue(m_DataString, "TRACE_REF");
   if(0 == l_traceRef.length())
   {
      CLOG(0,0,"Unknown TRACE_REF");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }

   string l_omcId;
   l_omcId = ConfigReader::readValue(m_DataString, "OMC_ID");
   if(0 == l_omcId.length())
   {
      CLOG(0,0,"Unknown OMC_ID");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }

   m_UserDlgId = g_sc.getNewDialogue();
   if(m_UserDlgId < 1)
   {
      ELOG(0,0,"Couldnt get a new dialogue");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }
   TLOG(0,0,"Sending MapOpenReq v2 ...");
   MapOpenReq l_mapOpenReq(m_UserDlgId, MAP_V2);
   l_mapOpenReq.m_ApplCntxt = MAP_AC_CODE_tracing;
   configureSccpAddress(&l_mapOpenReq.m_OrigAddr, L_ROUTE_ON_GT, 0, g_ConfigData->i_NgConfigData.m_LocalSSN, (char*)l_origAddress.c_str());
   m_tdr.setMapVersion(2);
   m_tdr.setString(TDR_INDEX_LOCAL_ADDRESS, (char*)l_origAddress.c_str());

   if(0 == l_type.compare("GSM"))
   {
      m_tdr.setRemoteAddrSsn(7);
      configureSccpAddress(&l_mapOpenReq.m_DestAddr, L_ROUTE_ON_GT, 0, 7, (char*)l_destAddress.c_str());
   }
   else
   {
      m_tdr.setRemoteAddrSsn(149);
      configureSccpAddress(&l_mapOpenReq.m_DestAddr, L_ROUTE_ON_GT, 0, 149, (char*)l_destAddress.c_str());
   }
   m_tdr.setRemoteAddr((char*)l_destAddress.c_str());

   g_sc.sendMsg(this, &l_mapOpenReq);

   DLOG(0,0,"Sending MapSpecificRequest v2...");
   MapSpecificRequest l_request(m_UserDlgId, MAP_OP_CODE_activateTraceMode, MAP_V2);

   DECLARE(OMAP2_ActivateTraceModeArg, l_atm2, 2, "OMAP2_ActivateTraceModeArg", resetStruct);

   l_atm2->imsi.length = (strlen((char*)l_imsi.c_str())+1)/2;
   numToBCD((u8*)l_imsi.c_str(), (u8*)(l_atm2->imsi.value), strlen(l_imsi.c_str()));
   l_atm2->bit_mask = OMAP2_ActivateTraceModeArg_imsi_present;

   l_atm2->traceReference.length = 2;
   atohx((char*)l_atm2->traceReference.value, (char*)l_traceRef.c_str());


   unsigned char l_traceTypeChar[2];
   memset(l_traceTypeChar, '\0', sizeof(l_traceTypeChar));
   atohx((char*)l_traceTypeChar, (char*)l_traceType.c_str());

   l_atm2->traceType = l_traceTypeChar[0];

   l_atm2->omc_Id.length = 1 + ((1+strlen((char*)l_omcId.c_str()))/2);
   l_atm2->omc_Id.value[0] = 0x91;
   StringToBCD((u8*)&l_atm2->omc_Id.value[1], (u8*)l_omcId.c_str(), strlen((char*)l_omcId.c_str()));
   l_atm2->bit_mask |= OMAP2_omc_Id_present;


   m_tdr.setChar(TDR_INDEX_REQUEST_TYPE,'I');
   m_tdr.setString(TDR_INDEX_REQUEST_IMSI,(char*)l_imsi.c_str());

   char l_value[10];
   memset(l_value, '\0', 10);

   l_request.m_structBuffer = (void*)l_atm2;
   g_sc.sendMsg(this, &l_request);

   TLOG(0,0,"Sending MapDelimiterReq Req ...");
   MapDelimiterReq l_del(m_UserDlgId);
   g_sc.sendMsg(this, &l_del);
   return true;
}


bool CtxtActivateTraceMode::sendv1ActTraceMode()
{
   string l_imsi = ConfigReader::readValue(m_DataString, "IMSI");
   if (0 == l_imsi.length())
   {
      CLOG(0,0,"Unknown IMSI");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }

   strcpy(m_imsi, (char*)l_imsi.c_str());
   LLOG(0,0,"IMSI [%s]", m_imsi);

   string l_lmsi = ConfigReader::readValue(m_DataString, "LMSI");
   if (0 == l_lmsi.length())
   {
      LLOG(0,0,"Unknown LMSI. Ignoring");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      //return false;
   }

   strcpy(m_lmsi, (char*)l_lmsi.c_str());
   LLOG(0,0,"LMSI [%s]", m_lmsi);

   string l_type = ConfigReader::readValue(m_DataString, "TYPE");
   if (0 == l_type.length())
   {
      CLOG(0,0,"Unknown TYPE");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }

   if ( (l_type.compare("GSM") != 0) &&
         ((l_type.compare("GPRS") != 0)))
   {
      CLOG(0,1,"Invalid TYPE %s", (char*)l_type.c_str());
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }

   strcpy(m_type, (char*)l_type.c_str());


   string l_destAddress;
   l_destAddress = ConfigReader::readValue(m_DataString, "DEST_ADDRESS");
   if(0 == l_destAddress.length())
   {
      CLOG(0,0,"Unknown DEST_ADDRESS");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }
   strcpy(m_DestAddr, (char*)l_destAddress.c_str());

   string l_origAddress;
   l_origAddress = ConfigReader::readValue(m_DataString, "ORIG_ADDRESS");
   if(0 == l_origAddress.length())
   {
      CLOG(0,0,"Unknown ORIG_ADDRESS");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }
   strcpy(m_OrigAddr, (char*)l_origAddress.c_str());

   string l_traceType;
   l_traceType = ConfigReader::readValue(m_DataString, "TRACE_TYPE");
   if(0 == l_traceType.length())
   {
      CLOG(0,0,"Unknown TRACE_TYPE");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }

   string l_traceRef;
   l_traceRef = ConfigReader::readValue(m_DataString, "TRACE_REF");
   if(0 == l_traceRef.length())
   {
      CLOG(0,0,"Unknown TRACE_REF");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }

   string l_omcId;
   l_omcId = ConfigReader::readValue(m_DataString, "OMC_ID");
   if(0 == l_omcId.length())
   {
      CLOG(0,0,"Unknown OMC_ID");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }

   m_UserDlgId = g_sc.getNewDialogue();
   if(m_UserDlgId < 1)
   {
      ELOG(0,0,"Couldnt get a new dialogue");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }
   TLOG(0,0,"Sending MapOpenReq v3 ...");
   MapOpenReq l_mapOpenReq(m_UserDlgId, MAP_V1);
   l_mapOpenReq.m_ApplCntxt = MAP_AC_CODE_tracing;
   configureSccpAddress(&l_mapOpenReq.m_OrigAddr, L_ROUTE_ON_GT, 0, g_ConfigData->i_NgConfigData.m_LocalSSN, (char*)l_origAddress.c_str());
   m_tdr.setMapVersion(1);
   m_tdr.setString(TDR_INDEX_LOCAL_ADDRESS, (char*)l_origAddress.c_str());

   if(0 == l_type.compare("GSM"))
   {
      m_tdr.setRemoteAddrSsn(7);
      configureSccpAddress(&l_mapOpenReq.m_DestAddr, L_ROUTE_ON_GT, 0, 7, (char*)l_destAddress.c_str());
   }
   else
   {
      m_tdr.setRemoteAddrSsn(149);
      configureSccpAddress(&l_mapOpenReq.m_DestAddr, L_ROUTE_ON_GT, 0, 149, (char*)l_destAddress.c_str());
   }
   m_tdr.setRemoteAddr((char*)l_destAddress.c_str());

   g_sc.sendMsg(this, &l_mapOpenReq);

   DLOG(0,0,"Sending MapSpecificRequest v3...");
   MapSpecificRequest l_request(m_UserDlgId, MAP_OP_CODE_activateTraceMode, MAP_V1);

   DECLARE(OMAP1_ActivateTraceModeArg, l_atm1, 1, "OMAP1_ActivateTraceModeArg", resetStruct);

   l_atm1->imsi.length = (strlen((char*)l_imsi.c_str())+1)/2;
   numToBCD((u8*)l_imsi.c_str(), (u8*)(l_atm1->imsi.value), strlen(l_imsi.c_str()));
   l_atm1->bit_mask = OMAP1_ActivateTraceModeArg_imsi_present;

   l_atm1->traceReference.length = 2;
   atohx((char*)l_atm1->traceReference.value, (char*)l_traceRef.c_str());

   unsigned char l_traceTypeChar[2];
   memset(l_traceTypeChar, '\0', sizeof(l_traceTypeChar));
   atohx((char*)l_traceTypeChar, (char*)l_traceType.c_str());

   l_atm1->traceType = l_traceTypeChar[0];

   l_atm1->omcId.length = 1 + ((1+strlen((char*)l_omcId.c_str()))/2);
   l_atm1->omcId.value[0] = 0x91;
   StringToBCD((u8*)&l_atm1->omcId.value[1], (u8*)l_omcId.c_str(), strlen((char*)l_omcId.c_str()));
   l_atm1->bit_mask |= OMAP1_ActivateTraceModeArg_omcId_present;


   m_tdr.setChar(TDR_INDEX_REQUEST_TYPE,'I');
   m_tdr.setString(TDR_INDEX_REQUEST_IMSI,(char*)l_imsi.c_str());

   char l_value[10];
   memset(l_value, '\0', 10);

   l_request.m_structBuffer = (void*)l_atm1;
   g_sc.sendMsg(this, &l_request);

   TLOG(0,0,"Sending MapDelimiterReq Req ...");
   MapDelimiterReq l_del(m_UserDlgId);
   g_sc.sendMsg(this, &l_del);
   return true;
}

bool CtxtActivateTraceMode::startProcessing(InterModuleData *p_imd, bool& p_DeleteFlag)
{
   DLOG(0,0,"CtxtActivateTraceMode::startProcessing data [%s] [%d]", (NULL == p_imd->m_Parameters)?"":p_imd->m_Parameters, p_DeleteFlag);

   if(NULL == p_imd->m_Parameters)
   {
      CLOG(0,0,"p_imd->m_Parameters NULL returning");
      return false;
   }

   char *l_check = NULL;
   l_check = strchr(p_imd->m_Parameters, ':');
   if(l_check == NULL)
   {
      CLOG(0,0,"Transaction ID not present");
      return false;
   }

   strncpy(m_TransId, p_imd->m_Parameters, strlen(p_imd->m_Parameters)-strlen(l_check)); 

   LLOG(0,0,"Transaction ID :%s", m_TransId);
   m_tdr.setString(TDR_INDEX_OAM_TRANSACTION_ID, m_TransId);

   m_DataString.assign(l_check+1);

   if(g_OamConfigReaderObj->m_DSD_MAP_VERSION == 2)
   {
      sendv2ActTraceMode();
   }
   else if(g_OamConfigReaderObj->m_DSD_MAP_VERSION == 1)
   {
      sendv1ActTraceMode();
   }
   else if(g_OamConfigReaderObj->m_DSD_MAP_VERSION == 3)
   {
      sendv3ActTraceMode();
   }
   else
   {
      ELOG(0,1,"Not implemented");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
   }
   return true;
}


bool CtxtActivateTraceMode::updateDb(char p_status, char *p_error, int p_errorCode)
{
   UpdateOamTransData *l_uotd = new UpdateOamTransData;
   l_uotd->m_cb = this;
   l_uotd->m_Status = p_status;
   strcpy(l_uotd->m_TransId, m_TransId);
   strcpy(l_uotd->m_ErrorCause, p_error);

   l_uotd->m_actTracingFlag=1;
   LLOG(0,0,"m_actTracingFlag is set %d", l_uotd->m_actTracingFlag);
   strcpy(l_uotd->m_imsi, m_imsi);
   strcpy(l_uotd->m_type, m_type);
   l_uotd->m_errorCodeToBeUpdated = p_errorCode;

   //bool FormClXml(char *p_XmlReq,int p_NodeType,u8 *p_imsi,u8 *p_lmsi,u8 *p_ActHLRAddr,u8 *p_vlrno,int p_updateSubsdata);
   if (p_errorCode != 0)
   {
      char l_xmlReq[500];
      memset(l_xmlReq, '\0', sizeof(l_xmlReq));
      bool l_status = FormClXml(l_xmlReq, 
                                (strcmp(m_type, "GSM")==0)?1:2,
                                 (u8*)m_imsi,
                                 (u8*)m_lmsi,
                                 (u8*)m_OrigAddr,
                                 (u8*)m_DestAddr,
                                 1); // Update DB with Cancel location update
      WLOG(0,0,"ATM failed. So initiating CL for the subscriber");
      g_sc.initiateIndependentContext(this, MAP_OP_CODE_cancelLocation, (char *)l_xmlReq, INITIATION_TYPE_IMMEDIATE);

   }
   TLOG(0,0,"m_actTracingFlag is set %d", l_uotd->m_actTracingFlag);
   g_act.execute(l_uotd);
   return true;
}

bool CtxtActivateTraceMode::processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag)
{
   DLOG(0,0,"Start of CtxtActivateTraceMode::processMsg function");
   MapSpecificMsg *l_specMsg = NULL;

   switch (p_MsgPtr->m_MsgType)
   {
      case MSG_TYPE_MAP:
         switch (((MapMsg*)p_MsgPtr)->m_MapMsgType)
         {
            case MAP_MSG_TYPE_COMMON:
               switch (((MapCommonMsg*)p_MsgPtr)->m_MapCommonMsgType)
               {
                  case MAP_CMN_OPEN_IND:
                     DLOG(0,0,"MAP_CMN_OPEN_IND received with DlgId [%d], Version [%d]", getInitialRespondingDlgId(),
                           getInitialRespondingVersion());
                     break;

                  case MAP_CMN_OPEN_CNF:
                     {
                        if(REFUSE_REASON_APPL_CNTXT_NOT_SUPPORTED == ((MapOpenCnf*)p_MsgPtr)->m_RefuseReasonParam)
                        {
                           LLOG(0,0,"MAP_CMN_OPEN_CNF received with Version [%d]", ((MapOpenCnf*)p_MsgPtr)->m_Version);
                           m_tdr.setInteger(TDR_INDEX_OPEN_CNF_VERSION,(int)(((MapOpenCnf*)p_MsgPtr)->m_Version));

                           if(MAP_V1 == ((MapOpenCnf*)p_MsgPtr)->m_Version)
                           {
                              sendv1ActTraceMode();
                           }
                           else if(MAP_V2  == ((MapOpenCnf*)p_MsgPtr)->m_Version)
                           {
                              sendv2ActTraceMode();
                           }
                        }
                        else
                        {
                           LLOG(0,0,"MAP_CMN_OPEN_CNF received with other reason [%d]", 
                                 ((MapOpenCnf*)p_MsgPtr)->m_RefuseReasonParam);
                           m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_NOTICE_RCVD); 
                           updateDb('F', "Received Notice", TDR_ERROR_NOTICE_RCVD);
                        }
                     }
                     break;

                  case MAP_CMN_DELIMITER_IND:
                     {
                        TLOG(0,0,"MAP_CMN_DELIMITER_IND received ");
                     }
                     break;

                  case MAP_CMN_CLOSE_IND:
                     {
                        DLOG(0,0,"MAP_CMN_CLOSE_IND received");
                     }

                     break;

                  case MAP_CMN_U_ABORT_IND:
                     {
                        WLOG(0,0,"MAP_CMN_U_ABORT_IND received");
                        m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_U_ABORT_RCVD); 
                        updateDb('F', "Received U-Abort", TDR_ERROR_U_ABORT_RCVD);
                     }
                     break;

                  case MAP_CMN_P_ABORT_IND:
                     {
                        WLOG(0,0,"MAP_CMN_P_ABORT_IND received");
                        m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_P_ABORT_RCVD); 
                        updateDb('F', "Received P-Abort", TDR_ERROR_P_ABORT_RCVD);
                     }
                     break;

                  case MAP_CMN_NOTICE_IND:
                     {
                        LLOG(0,0,"MAP_CMN_NOTICE_IND received");
                        m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_NOTICE_RCVD); 
                        MapCloseReq l_closeReq(m_UserDlgId);
                        l_closeReq.m_CloseType = MAP_CLOSE_TYPE_PRE_ARRANGED_END;
                        g_sc.sendMsg(this, &l_closeReq);

                        updateDb('F', "Received Notice", TDR_ERROR_NOTICE_RCVD);
                     }
                     break;

                  default:
                     ELOG(0,0,"Unknown Msg received [%d]", ((MapCommonMsg*)p_MsgPtr)->m_MapCommonMsgType);
                     break;
               }
               break;

            case MAP_MSG_TYPE_SPECIFIC:
               DLOG(0,0,"MAP_MSG_TYPE_SPECIFIC received [%d]", getInitialRespondingDlgId());
               l_specMsg = (MapSpecificMsg*)p_MsgPtr;

               switch (((MapSpecificMsg*)p_MsgPtr)->m_MapSpecificEventType)
               {
                  case MAP_SPEC_EVENT_CONFIRMATION:
                     {
                        DLOG(0,0,"MAP_SPEC_EVENT_CONFIRMATION received");
                        updateDb('S', "", 0);
                     }
                     break;

                  case MAP_SPEC_EVENT_USER_ERROR:
                     {
                        DLOG(0,0,"MAP_SPEC_EVENT_USER_ERROR received");
                        m_tdr.setInteger(TDR_INDEX_ERR_CODE, ((MapUserError*)p_MsgPtr)->m_ErrorCode); 
                        updateDb('F', "Received USER ERROR", ((MapUserError*)p_MsgPtr)->m_ErrorCode);
                     }
                     break;

                  case MAP_SPEC_EVENT_PROV_ERROR:
                     {
                        DLOG(0,0,"MAP_SPEC_EVENT_PROV_ERROR received");
                        m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_PROVIDER_ERROR_RCVD); 
                        DLOG(0,0,"Closing the Dialogue");
                        updateDb('F', "Some Error", TDR_ERROR_PROVIDER_ERROR_RCVD);
                     }
                     break;
                  default:
                     m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_GENERAL_ERROR); 
                     ELOG(0,0,"ERROR!! Default received");
                     break;
               }
               break;

            default:
               break;
         }
         break;

      case MSG_TYPE_DB:
         DLOG(0,0,"DB message received");
         break;

      default:
         ELOG(0,0,"Unknown message received");
         break;

   }
   return true;
}

