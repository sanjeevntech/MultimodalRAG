#include <CtxtReset.h>
#include <stdio.h>
#include <MapMessages.h>
#include <ServiceCoordinator.h>
#include <Logger.h>
#include <OMAP1.h>
#include <OMAP2.h>
#include <OMAP3.h>
#include <DbActiveObject.h>
#include <ConfigReader.h>
#include <OamConfigReader.h>
#include <OamDbQueries.h>
#include <DataUnion.h>
#include <Utilities.h>
#include <HlrTdrFiller.h>

extern bool resetStruct(int p_version, int p_pdu, void *p_struct);


CtxtReset::CtxtReset()
{
   DLOG(0,0,"CtxtReset::CtxtReset()");
   memset(m_TransId, '\0', sizeof(m_TransId));
   m_imsiCount=0;
   m_close_flag = false;
}

CtxtReset::~CtxtReset()
{
   DLOG(0,0,"CtxtReset::~CtxtReset()");
}

bool CtxtReset::updateDb(char p_status, char *p_error)
{
   UpdateOamTransData *l_uotd = new UpdateOamTransData;
   l_uotd->m_cb = this;
   l_uotd->m_Status = p_status;
   strcpy(l_uotd->m_TransId, m_TransId);
   strcpy(l_uotd->m_ErrorCause, p_error);
   g_act.execute(l_uotd);
   return true;
}

bool CtxtReset::startProcessing(InterModuleData *p_imd, bool &p_DeleteFlag)
{
   EMapVersion l_version=MAP_V1;
   LLOG(0,1,"CtxtReset::startProcessing() called [%d]", p_DeleteFlag);
   if(p_imd->m_Parameters != NULL)
   {
       LLOG(0,1,"Parameters are [%s]", p_imd->m_Parameters);
   }
   else
   {
      CLOG(0,0,"p_imd->m_Parameters NULL returning");
      return false;
   }

   printf("\nCtxtReset::startProcessing [%s]", (NULL == p_imd->m_Parameters)?"":p_imd->m_Parameters);

   char *l_check = NULL;
   l_check = strchr(p_imd->m_Parameters, ':');
   if(l_check == NULL)
   {
         printf("\nTransaction ID not present");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
            return false;
   }

   strncpy(m_TransId, p_imd->m_Parameters, strlen(p_imd->m_Parameters)-strlen(l_check));

   printf("\nTransaction ID :%s", m_TransId);
   m_tdr.setString(TDR_INDEX_OAM_TRANSACTION_ID, m_TransId);


    string l_resetString = ConfigReader::readValue(p_imd->m_Parameters, "RESET");
    if (l_resetString.length() == 0)
    {
        LLOG(0,1,"Invalid RESET Request");
        m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
        return false;
    }

    string l_type = ConfigReader::readValue(l_resetString, "TYPE");
    if (l_type.length() == 0)
    {
        ELOG(0,1,"TYPE not present");
        m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
        return false;
    }

    if (0 == strcmp(l_type.c_str(), "VLR"))
    {
        if (0 == g_OamConfigReaderObj->m_VlrResetEnabled)
        {
            CLOG(0,1,"Ignoring since VLR Reset is disabled");
            m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
            return false;
        }
        l_version=(EMapVersion)g_OamConfigReaderObj->m_ResetMapVer;
    }
    else if (0 == strcmp(l_type.c_str(), "SGSN"))
    {
        if (0 == g_OamConfigReaderObj->m_SgsnResetEnabled)
        {
            CLOG(0,1,"Ignoring since SGSN Reset is disabled");
            m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
            return false;
        }
        l_version=MAP_V3;
    }
    else
    {
        ELOG(0,1,"TYPE %s is invalid", l_type.c_str());
        m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
        return false;
    }

    string l_hlr_address = ConfigReader::readValue(l_resetString, "ORIG_ADDR");
    if (l_hlr_address.length() <= 5)
    {
        ELOG(0,1,"HLR_ADDR size invalid");
        m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
        return false;
    }
    m_tdr.setString(TDR_INDEX_LOCAL_ADDRESS, (char*)l_hlr_address.c_str());

    string l_dest_address = ConfigReader::readValue(l_resetString, "DEST_ADDR");
    if (l_dest_address.length() <= 5)
    {
        ELOG(0,1,"DEST_ADDR size invalid");
        m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
        return false;
    }
    m_tdr.setRemoteAddr((char*)l_dest_address.c_str());
    m_tdr.setRemoteAddrSsn((0 == strcmp(l_type.c_str(), "VLR"))?SSN_VLR:SSN_SGSN);

    string l_imsi_prefix = ConfigReader::readValue(l_resetString, "IMSI_PREFIXES");
    char l_imsi_prefixes_char[1000+1];
    memset(l_imsi_prefixes_char, '\0', sizeof(l_imsi_prefixes_char));
    strcpy(l_imsi_prefixes_char, ":");
    if (l_imsi_prefix.length() > 4)
    {
        LLOG(0,1,"IMSI_PREFIXES present");
        char l_imsiChar[10];
        for (int l_i=1; ; l_i++)
        {
           memset(l_imsiChar, '\0', sizeof(l_imsiChar));
           sprintf(l_imsiChar, "VAL_%02d", l_i);

           m_imsi[l_i] = ConfigReader::readValue(l_imsi_prefix, l_imsiChar);
           if (m_imsi[l_i].size() > 0)
           {
              if (m_imsi[l_i].size() < 5)
              {
                 ELOG(0,0,"Invalid IMSI prefix. should be minimum 5 digits");
                 return false;
              }
              strcat(l_imsi_prefixes_char, (char*)(m_imsi[l_i].c_str()));
              strcat(l_imsi_prefixes_char, ":");
              m_imsiCount++;
           }
           else
           {
              LLOG(0,0,"Found %d IMSI Prefixes", m_imsiCount);
              break;
           }
        }
    }

    m_tdr.setInteger(TDR_INDEX_OAM_IMSI_PREFIXES, m_imsiCount);
    m_tdr.setString(TDR_INDEX_OAM_IMSI_PREFIXES, l_imsi_prefixes_char);

    LLOG(0,1,"Calling reset with TYPE:%s HLR_ADDR:%s VLR_ADDR:%s IMSI_PREFIX:%s", 
         l_type.c_str(), l_hlr_address.c_str(), l_dest_address.c_str(), l_imsi_prefix.c_str());

    sendReset((char*)l_type.c_str(), (char*)l_hlr_address.c_str(), 
              (char*)l_dest_address.c_str(), (char*)l_imsi_prefix.c_str(),  l_version);

   m_type = l_type;
   m_hlr_address = l_hlr_address;
   m_dest_address = l_dest_address;
   m_imsi_prefix = l_imsi_prefix; 

   return true;
}


bool CtxtReset::sendReset(char *p_type, char *p_hlrAddress, char *p_vlrAddress, char *p_imsiPrefix, EMapVersion p_version)
{
   int l_UserDlgId = g_sc.getNewDialogue();

   LLOG(0,0,"Sending MapOpenReq ... MapVer = %d ImsiPrefix:%s",p_version, p_imsiPrefix);

   MapOpenReq l_mapOpenReq(l_UserDlgId, p_version); //MAP ver as configured
   configureSccpAddress(&l_mapOpenReq.m_OrigAddr, L_ROUTE_ON_GT, 0, g_ConfigData->i_NgConfigData.m_LocalSSN, p_hlrAddress);
   configureSccpAddress(&l_mapOpenReq.m_DestAddr, L_ROUTE_ON_GT, 0, (0 == strcmp(p_type, "VLR"))?SSN_VLR:SSN_SGSN, p_vlrAddress);
   l_mapOpenReq.m_ApplCntxt = MAP_AC_CODE_reset;
   m_tdr.setMapVersion(p_version);
   g_sc.sendMsg(this, &l_mapOpenReq);

   DLOG(0,0,"Sending MapSpecificRequest ...");
   MapSpecificRequest l_request(l_UserDlgId, MAP_OP_CODE_reset, p_version); //MAP ver as configured

   if(MAP_V3 == p_version)
   {
      DECLARE(OMAP3_ResetArg, l_Map3Reset, 3, "OMAP3_ResetArg", resetStruct);
      l_Map3Reset->hlr_Number.length = 1 + (strlen(p_hlrAddress) + 1) / 2;
      l_Map3Reset->hlr_Number.value[0]=0x91;
      numToBCD((unsigned char *)p_hlrAddress, l_Map3Reset->hlr_Number.value + 1, strlen(p_hlrAddress));

      l_Map3Reset->hlr_List.count=0;
      for (int l_i=1; l_i<=m_imsiCount; l_i++)
      {
          l_Map3Reset->bit_mask = OMAP3_hlr_List_present;
          l_Map3Reset->hlr_List.count++;
          l_Map3Reset->hlr_List.value[l_i-1].length = (m_imsi[l_i].size() + 1) / 2;
          numToBCD((u8*)m_imsi[l_i].c_str(), l_Map3Reset->hlr_List.value[l_i-1].value, m_imsi[l_i].size());
      }

      l_request.m_structBuffer = (void*)l_Map3Reset;
   }
   else if(MAP_V2 == p_version)
   {
      DECLARE(OMAP2_ResetArg, l_Map2Reset, 2, "OMAP2_ResetArg", resetStruct);
      l_Map2Reset->hlr_Number.length = 1 + (strlen(p_hlrAddress) + 1) / 2;
      l_Map2Reset->hlr_Number.value[0]=0x91;
      numToBCD((unsigned char *) p_hlrAddress, l_Map2Reset->hlr_Number.value + 1, strlen(p_hlrAddress));

      l_Map2Reset->hlr_List.count=0;
      for (int l_i=1; l_i<=m_imsiCount; l_i++)
      {
          l_Map2Reset->bit_mask = OMAP2_hlr_List_present;
          l_Map2Reset->hlr_List.count++;
          l_Map2Reset->hlr_List.value[l_i-1].length = (m_imsi[l_i].size() + 1) / 2;
          LLOG(0,0,"length %d", l_Map2Reset->hlr_List.value[l_i-1].length);
          numToBCD((u8*)m_imsi[l_i].c_str(), l_Map2Reset->hlr_List.value[l_i-1].value, m_imsi[l_i].size());
      }

      l_request.m_structBuffer = (void*)l_Map2Reset;
   }     
   else if(MAP_V1 == p_version)
   {
      DECLARE(OMAP1_ResetArg, l_Map1Reset, 1, "OMAP1_ResetArg", resetStruct);
      l_Map1Reset->networkResource = OMAP1_hLR;

      l_Map1Reset->originatingEntityNumber.length = 1 + (strlen(p_hlrAddress) + 1) / 2;
      l_Map1Reset->originatingEntityNumber.value[0]=0x91;
      numToBCD((unsigned char *) p_hlrAddress, l_Map1Reset->originatingEntityNumber.value + 1, strlen(p_hlrAddress));

      for (int l_i=1; l_i<=m_imsiCount; l_i++)
      {
          l_Map1Reset->bit_mask = OMAP1_hlrId_present;
          l_Map1Reset->hlrId.count++;
          l_Map1Reset->hlrId.value[l_i-1].length = (m_imsi[l_i].size() + 1) / 2;
          numToBCD((u8*)m_imsi[l_i].c_str(), l_Map1Reset->hlrId.value[l_i-1].value, m_imsi[l_i].size());
      }
      l_request.m_structBuffer = (void*)l_Map1Reset;
   }
   else
   {
      DLOG(0,0,"Invalid Map Version");
   }
   g_sc.sendMsg(this, &l_request);

   DLOG(0,0,"Sending MapDelimiterReq Req ...");
   MapDelimiterReq l_del(l_UserDlgId);
   g_sc.sendMsg(this, &l_del);

#if 0
   DLOG(0,0,"Sending MapDelimiterReq Req ...");
   MapCloseReq l_closeReq(l_UserDlgId);
   l_closeReq.m_CloseType = MAP_CLOSE_TYPE_PRE_ARRANGED_END;
   g_sc.sendMsg(this, &l_closeReq);
   return true;
#endif
} 


bool CtxtReset::processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag)
{
   DLOG(0,0,"Start of CtxtReset::processMsg function");
   MapSpecificMsg *l_specMsg = NULL;
   int l_dlgId;
   int l_UserDlgId;
   
   switch (p_MsgPtr->m_MsgType)
   {
      case MSG_TYPE_MAP:
         switch (((MapMsg*)p_MsgPtr)->m_MapMsgType)
         {
            case MAP_MSG_TYPE_COMMON:
               switch (((MapCommonMsg*)p_MsgPtr)->m_MapCommonMsgType)
               {
                  case MAP_CMN_OPEN_IND:
                     DLOG(0,0,"MAP_CMN_OPEN_IND received");
                     break;

                  case MAP_CMN_DELIMITER_IND:
                     DLOG(0,0,"MAP_CMN_DELIMITER_IND received");
                     break;

                  case MAP_CMN_CLOSE_IND:
                     DLOG(0,0,"MAP_CMN_CLOSE_IND received");

                     return true;
                     break;
                  
                  case MAP_CMN_OPEN_CNF:
                    { 
                        LLOG(0,0,"checking log");
                        if(REFUSE_REASON_APPL_CNTXT_NOT_SUPPORTED == ((MapOpenCnf*)p_MsgPtr)->m_RefuseReasonParam)
                        {
			    if(false == m_close_flag)
                            {
                                EMapVersion l_version=((MapOpenCnf*)p_MsgPtr)->m_Version;
                                DLOG(0,0,"MAP_CMN_U_ABORT_IND received with Version [%d]",((MapOpenCnf*)p_MsgPtr)->m_Version);
                                m_tdr.setInteger(TDR_INDEX_OPEN_CNF_VERSION,(int)(((MapOpenCnf*)p_MsgPtr)->m_Version));
                                if(MAP_V1 == l_version)
                                {
                                   sendReset((char*)m_type.c_str(), (char*)m_hlr_address.c_str(),
                                       (char*)m_dest_address.c_str(), (char*)m_imsi_prefix.c_str(),  l_version);  
                                   m_close_flag=true;
                               }
                               else if(MAP_V2 == l_version)
                               {
                                    sendReset((char*)m_type.c_str(), (char*)m_hlr_address.c_str(),
                                       (char*)m_dest_address.c_str(), (char*)m_imsi_prefix.c_str(),  l_version);  
                                   m_close_flag=true;
                               }
                           }
                           else
                           {
                                CLOG(0,0,"Loop identified. Stopping the loop");
                                updateDb('F', "Loop Detected");
                           }
                        }
                       
                        else
                        {
                        LLOG(0,0,"MAP_CMN_U_ABORT_IND received with other reason [%d]",
                                 ((MapOpenCnf*)p_MsgPtr)->m_RefuseReasonParam);
                        m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_NOTICE_RCVD);
                        updateDb('F', "Received Notice");
                        }
                    }
                    break;
                  
                  case MAP_CMN_U_ABORT_IND:
                     DLOG(0,0," MAP_CMN_U_ABORT_IND received");
                     break;

                  case MAP_CMN_P_ABORT_IND:
                     DLOG(0,0,"MAP_CMN_P_ABORT_IND received");
                     break;

                  case MAP_CMN_NOTICE_IND:
                     {
                        DLOG(0,0,"MAP_CMN_NOTICE_IND received");
                        DLOG(0,0,"Closing the Dialogue");
                        MapCloseReq l_closeReq(((MapMsg*)p_MsgPtr)->m_UserDlgId);
                        l_closeReq.m_CloseType = MAP_CLOSE_TYPE_PRE_ARRANGED_END;
                        l_closeReq.m_PreArrangedReason = MAP_CLOSE_PRE_ARRANGED_REASON_SUCCESS;
                        g_sc.sendMsg(this, &l_closeReq);
                     }
                     break;

                  default:
                     DLOG(0,0,"Unknown Msg received [%d]", ((MapCommonMsg*)p_MsgPtr)->m_MapCommonMsgType);
                     break;
               }
               break;

            case MAP_MSG_TYPE_SPECIFIC:
               DLOG(0,0,"MAP_MSG_TYPE_SPECIFIC received");
               l_specMsg = (MapSpecificMsg*)p_MsgPtr;
               l_UserDlgId = l_specMsg->m_UserDlgId;
               DLOG(0,0,"MAP_MSG_TYPE_SPECIFIC received dlgId[%d] UserDlgId[%d]",
                     l_dlgId, l_UserDlgId);

               switch (((MapSpecificMsg*)p_MsgPtr)->m_MapSpecificEventType)
               {
                  case MAP_SPEC_EVENT_INDICATION:
                     {
                        DLOG(0,0,"MAP_SPEC_EVENT_INDICATION received");
                        l_UserDlgId = p_MsgPtr->m_UserDlgId;
                     }

                     break;

                  case MAP_SPEC_EVENT_RESULT:
                     {
                        DLOG(0,0,"MAP_SPEC_EVENT_RESULT received");
                     }
                     break;

                  case MAP_SPEC_EVENT_CONFIRMATION:
                     {
                        DLOG(0,0,"MAP_SPEC_EVENT_CONFIRMATION received");
                     }
                     break;

                  case MAP_SPEC_EVENT_USER_ERROR:
                     {
                        DLOG(0,0,"MAP_SPEC_EVENT_USER_ERROR received");
                     }
                     break;

                  case MAP_SPEC_EVENT_PROV_ERROR:
                     {
                        DLOG(0,0,"MAP_SPEC_EVENT_PROV_ERROR received");
                        DLOG(0,0,"Closing the Dialogue");
                        MapCloseReq l_closeReq(((MapSpecificMsg*)p_MsgPtr)->m_UserDlgId);
                        g_sc.sendMsg(this, &l_closeReq);
                        updateDb('S', "");
                     }
                     break;
                  default:
                     ELOG(0,0,"ERROR!! Default received");
                     break;

               }
               break;

            default:
               break;
         }
         break;

      case MSG_TYPE_DB:
         DLOG(0,0,"DB message received");
         break;

      default:
         DLOG(0,0,"Unknown message received");
         break;

   }
   return true;
}


