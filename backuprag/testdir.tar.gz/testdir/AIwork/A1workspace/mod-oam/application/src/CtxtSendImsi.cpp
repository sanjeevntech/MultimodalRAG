#include <CtxtSendImsi.h>
#include <stdio.h>
#include <MapMessages.h>
#include <ServiceCoordinator.h>
#include <Logger.h>
#include <IMAP2.h>
#include <IMAP3.h>
#include <OMAP2.h>
#include <OMAP3.h>
#include <OamDbQueries.h>
#include <DbActiveObject.h>
#include <Utilities.h>
#include <OamConfigReader.h>
#include <DataUnion.h>
#include <HlrTdrFiller.h>
#include <SubsProfileData.h>

extern bool resetStruct(int p_version, int p_pdu, void *p_struct);

CtxtSendImsi::CtxtSendImsi()
{
   TLOG(0,0,"CtxtSendImsi::CtxtSendImsi()");
   memset(m_OrigAddress, '\0', sizeof(m_OrigAddress));
}

CtxtSendImsi::~CtxtSendImsi()
{
   TLOG(0,0,"CtxtSendImsi::~CtxtSendImsi()");
}


bool CtxtSendImsi::processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag)
{
   DLOG(0,0,"Start of CtxtSendImsi::processMsg function");

   p_DeleteFlag=p_DeleteFlag; // This is just to keep the compiler happy

   MapSpecificMsg *l_specMsg = NULL;

   switch (p_MsgPtr->m_MsgType)
   {
      case MSG_TYPE_MAP:
         switch (((MapMsg*)p_MsgPtr)->m_MapMsgType)
         {
            case MAP_MSG_TYPE_COMMON:
               switch (((MapCommonMsg*)p_MsgPtr)->m_MapCommonMsgType)
               {
                  case MAP_CMN_OPEN_IND:
                     DLOG(0,0,"MAP_CMN_OPEN_IND received remote ssn: %d gt: %s", 
                           ((MapOpenInd*)p_MsgPtr)->m_OrigAddr.ssn,
                           ((MapOpenInd*)p_MsgPtr)->m_OrigAddr.globalTitle.addressInformation);
                     snprintf(m_OrigAddress, sizeof(m_OrigAddress), ((MapOpenInd*)p_MsgPtr)->m_OrigAddr.globalTitle.addressInformation);
                     break;

                  case MAP_CMN_DELIMITER_IND:
                     DLOG(0,0,"MAP_CMN_DELIMITER_IND received");
                     break;

                  case MAP_CMN_CLOSE_IND:
                     DLOG(0,0,"MAP_CMN_CLOSE_IND received");
                     //printf("\nGot a Close. Call flow success.\n");
                     return true;
                     break;

                  case MAP_CMN_U_ABORT_IND:
                     m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_U_ABORT_RCVD);
                     DLOG(0,0,"MAP_CMN_U_ABORT_IND received");
                     break;

                  case MAP_CMN_P_ABORT_IND:
                     m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_P_ABORT_RCVD);
                     DLOG(0,0,"MAP_CMN_P_ABORT_IND received");
                     break;

                  case MAP_CMN_NOTICE_IND:
                     {
                        DLOG(0,0,"MAP_CMN_NOTICE_IND received");
                        DLOG(0,0,"Closing the Dialogue");
                        m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_NOTICE_RCVD);
                        MapCloseReq l_closeReq(((MapMsg*)p_MsgPtr)->m_UserDlgId);
                        g_sc.sendMsg(this, &l_closeReq);
                     }
                     break;

                  default:
                     DLOG(0,0,"Unknown Msg received [%d]", ((MapCommonMsg*)p_MsgPtr)->m_MapCommonMsgType);
                     break;
               }
               break;

            case MAP_MSG_TYPE_SPECIFIC:
               DLOG(0,0,"MAP_MSG_TYPE_SPECIFIC received");
               l_specMsg = (MapSpecificMsg*)p_MsgPtr;

               switch (((MapSpecificMsg*)p_MsgPtr)->m_MapSpecificEventType)
               {
                  case MAP_SPEC_EVENT_INDICATION:
                     {
                        DLOG(0,0,"MAP_SPEC_EVENT_INDICATION received");

                        switch (((MapSpecificMsg*)p_MsgPtr)->m_OpCode)
                        {
                           case MAP_OP_CODE_sendIMSI:
                              {
                                 if(false == ((MapSpecificMsg*)p_MsgPtr)->m_allocatedFlag)
                                 {
                                    CLOG(0,0,"Data received is NULL ...");
                                    MapUserError l_userError(getInitialRespondingDlgId(), MAP_ERROR_unexpectedData, 
                                          getInitialRespondingVersion(), NULL);
                                    g_sc.sendMsg(this, &l_userError);
                                    MapCloseReq l_closeReq(getInitialRespondingDlgId());
                                    g_sc.sendMsg(this, &l_closeReq);
                                 }
                                 else
                                 {
                                    DLOG(0,1,"Decoding data");
                                    char l_msisdn[20];
                                    memset(l_msisdn, '\0', 20);
                                    bool l_international_format = true;
                                    MapSpecificIndication *l_msi = (MapSpecificIndication*)p_MsgPtr;

                                    switch(l_specMsg->m_Version)
                                    {
                                       case MAP_V1:
                                          {
                                             CLOG(0,1,"v1 SendIMSI is not supported");
                                             MapUAbortReq l_req(((MapMsg*)p_MsgPtr)->m_UserDlgId);
                                             g_sc.sendMsg(this, &l_req);
                                             return true;
                                          }

                                          break;
                                       case MAP_V2:
                                          {
                                             DLOG(0,1,"v2 SendIMSI");
                                             IMAP2_SendIMSIArg *l_temp = (IMAP2_SendIMSIArg *)(((MapSpecificMsg*)p_MsgPtr)->m_structBuffer);
                                             BCDToString((u8*)l_msisdn, (u8*)(&(l_temp->value[1])), l_temp->length-1);
                                             DLOG(0,0,"Dialing pattern [%x]",l_temp->value[0]);
                                             if(l_temp->value[0] != 0x91)
                                                  l_international_format = false;
                                          }
                                          break;
                                       case MAP_V3:
                                          {
                                             DLOG(0,1,"v3 SendIMSI");
                                             IMAP3_SendIMSIArg *l_temp = (IMAP3_SendIMSIArg *)(((MapSpecificMsg*)p_MsgPtr)->m_structBuffer);
                                             BCDToString((u8*)l_msisdn, (u8*)(&(l_temp->value[1])), l_temp->length-1);
                                             DLOG(0,0,"Dialing pattern [%x]",l_temp->value[0]);
                                             if(l_temp->value[0] != 0x91)
                                                  l_international_format = false;
                                          }
                                          break;
                                       default:
                                          return false;
                                          break;
                                    }

                                    LLOG(0,0,"Received SendIMSI for MSISDN: %s", l_msisdn);
                                    RetrieveSendImsiData *l_sid = new RetrieveSendImsiData();
//5.0.5.3
                                    if(l_international_format)
                                    { 
                                       TLOG(0,0,"Dialing pattern International");
                                       s8* l_tmpMsisdn = NULL;
                                       l_tmpMsisdn = g_spdPtr->getMsisdnValue((s8*)l_msisdn);
                                       strcpy((s8*)l_sid->m_msisdn,l_tmpMsisdn);
                                    }
                                    else
                                    {
                                       TLOG(0,0,"Dialing pattern Not International");
                                       strcpy((s8*)l_sid->m_msisdn,l_msisdn);
                                       DLOG(0,0,"MSISDN is %s", (s8*)l_sid->m_msisdn);
                                    }
//5.0.5.3
                                    m_tdr.setChar(TDR_INDEX_REQUEST_TYPE,'M');                        
                                    m_tdr.setString(TDR_INDEX_REQUEST_MSISDN,l_msisdn);    

                                    //RetrieveSendImsiData *l_sid = new RetrieveSendImsiData();
                                    l_sid->m_cb = this;
//                                    strcpy(l_sid->m_msisdn, l_msisdn);
                                    snprintf(l_sid->m_OrigAddress, sizeof(l_sid->m_OrigAddress), m_OrigAddress);
                                    g_act.execute(l_sid);
                                 }

                              }
                              break;

                           default:
                              {
                                 WLOG(0,0,"Received Unknown Specific Message");
                                 MapUAbortReq l_req(((MapMsg*)p_MsgPtr)->m_UserDlgId);
                                 g_sc.sendMsg(this, &l_req);
                              }
                              break;
                        }
                     }
                     break;

                  case MAP_SPEC_EVENT_RESULT:
                     {
                        WLOG(0,0,"MAP_SPEC_EVENT_RESULT received");
                     }
                     break;

                  case MAP_SPEC_EVENT_CONFIRMATION:
                     {
                        WLOG(0,0,"MAP_SPEC_EVENT_CONFIRMATION received");
                     }
                     break;

                  case MAP_SPEC_EVENT_USER_ERROR:
                     {
                        WLOG(0,0,"MAP_SPEC_EVENT_USER_ERROR received");
                     }
                     break;

                  case MAP_SPEC_EVENT_PROV_ERROR:
                     {
                        WLOG(0,0,"MAP_SPEC_EVENT_PROV_ERROR received");
                     }
                     break;

                  default:
                     ELOG(0,0,"ERROR!! Default received");
                     break;
               }
               break;

            default:
               break;
         }
         break;

      case MSG_TYPE_DB:
         {
            DLOG(0,0,"DB message received");

            RetrieveSendImsiData *l_sid = (RetrieveSendImsiData*)p_MsgPtr;

            TLOG(0,0,"NetworkId is |%d|", l_sid->m_networkId);
            m_tdr.setInteger(TDR_INDEX_MM_NETWORK_ID, l_sid->m_networkId);

            if (strlen(l_sid->m_hlrAddress) > 0)
            {
               sendMapOpenResponse(getInitialRespondingDlgId(), l_sid->m_hlrAddress, 6);
               m_tdr.setString(TDR_INDEX_LOCAL_ADDRESS,l_sid->m_hlrAddress);   
            }

            switch(l_sid->m_DbQueryRes)
            {
               case DB_QUERY_RES_SUCCESS:
                  {
                     m_tdr.setString(TDR_INDEX_REQUEST_IMSI, l_sid->m_imsi);    
                     LLOG(0,1,"Received IMSI : %s", l_sid->m_imsi);
                     if(MAP_V2 == getInitialRespondingVersion())
                     {
                        MapSpecificResult l_result(getInitialRespondingDlgId(), MAP_OP_CODE_sendIMSI, MAP_V2);
                        DECLARE(OMAP2_SendIMSIRes, l_temp, 2, "OMAP2_SendIMSIRes", resetStruct);
                        numToBCD((u8*)l_sid->m_imsi, (u8*)(l_temp->value), strlen((char*)l_sid->m_imsi));
                        l_temp->length = (1+strlen((char*)l_sid->m_imsi))/2;

                        l_result.m_structBuffer = (void*)l_temp;
                        g_sc.sendMsg(this, &l_result);
                     }
                     else
                     {
                        MapSpecificResult l_result(getInitialRespondingDlgId(), MAP_OP_CODE_sendIMSI, MAP_V3);
                        DECLARE(OMAP3_SendIMSIRes, l_temp, 3, "OMAP3_SendIMSIRes", resetStruct);
                        numToBCD((u8*)l_sid->m_imsi, (u8*)(l_temp->value), strlen((char*)l_sid->m_imsi));
                        l_temp->length = (1+strlen((char*)l_sid->m_imsi))/2;

                        l_result.m_structBuffer = (void*)l_temp;
                        g_sc.sendMsg(this, &l_result);
                     }


                  }

                  break;
               case DB_QUERY_RES_ROWS_NOT_FOUND:
                  {
                     m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_unknownSubscriber);
                     MapUserError l_userError(getInitialRespondingDlgId(), MAP_ERROR_unknownSubscriber, getInitialRespondingVersion(), NULL);
                     g_sc.sendMsg(this, &l_userError);
                  }
                  break;
               default:
                  {
                     m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_systemFailure);
                     MapUserError l_userError(getInitialRespondingDlgId(), MAP_ERROR_systemFailure, getInitialRespondingVersion(), NULL);
                     g_sc.sendMsg(this, &l_userError);
                  }
                  break;
            }
            MapCloseReq l_closeReq(getInitialRespondingDlgId());
            g_sc.sendMsg(this, &l_closeReq);

         }


         break;

      default:
         DLOG(0,0,"Unknown message received %d", p_MsgPtr->m_MsgType);
         break;

   }
   return true;
}

