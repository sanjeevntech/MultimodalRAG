#include <OamMemCachedQueries.h>
#include <OamDbQueries.h>
#include <MemCachedUtilities.h>
#include <Logger.h>
#include <ConfigReader.h>
#include <SubsProfileData.h>

OamMemCachedQueries::OamMemCachedQueries()
{
   DLOG(0,1,"OamMemCachedQueries :cons:");
}

OamMemCachedQueries::~OamMemCachedQueries()
{
   DLOG(0,1,"OamMemCachedQueries :des:");
}

//////////////////////////////////////////////////////

DeleteMemcQuery::DeleteMemcQuery()
{
   m_MsgType = MSG_TYPE_MEMCACHED;       
   memset(m_primaryImsi,'\0',sizeof(m_primaryImsi));
   DLOG(0,1,"DeleteMemcQuery :cons:");
}

DeleteMemcQuery::~DeleteMemcQuery()
{
   DLOG(0,1,"DeleteMemcQuery :des:");
}

void DeleteMemcQuery::executeMemcQuery()
{
   DeleteMemCached(m_memcActivePtr, m_MemcKey, m_MemcErrorCode, m_MemcErrorMessage);

   if(m_MemcErrorCode != 0)
   {
      m_MemcQueryRes = MEMC_QUERY_RES_FAILURE;
   }
   else
   {
      m_MemcQueryRes = MEMC_QUERY_RES_SUCCESS;
   }
}

void DeleteMemcQuery::serializeMemc()
{
   m_MemcKey = m_primaryImsi;
   snprintf(m_PriImsi4Distribution,sizeof(m_PriImsi4Distribution),"%s",m_primaryImsi);

   DLOG(0,0,"DeleteMemcQuery: serialize: Delete Keys starting with MEMC_KEY[%s]",m_MemcKey.c_str());
}

bool DeleteMemcQuery::deSerializeMemc()
{
   DLOG(0,0,"DeleteMemcQuery: deSerialize:");
   return true;
}

////////////////////////////////////////////////////////

SoftDeleteMemcQuery::SoftDeleteMemcQuery()
{
   m_MsgType = MSG_TYPE_MEMCACHED;       
   m_dataMemC = false;
   memset(m_primaryImsi,'\0',sizeof(m_primaryImsi));
   DLOG(0,1,"SoftDeleteMemcQuery :cons:");
}

SoftDeleteMemcQuery::~SoftDeleteMemcQuery()
{
   DLOG(0,1,"SoftDeleteMemcQuery :des:");
}

void SoftDeleteMemcQuery::executeMemcQuery()
{
   SoftDeleteMemCached(m_memcActivePtr, m_MemcKey, m_MemcValue, m_MemcErrorCode, m_MemcErrorMessage);

   if(m_MemcErrorCode != 0)
   {
      m_MemcQueryRes = MEMC_QUERY_RES_FAILURE;
   }
   else
   {
      m_MemcQueryRes = MEMC_QUERY_RES_SUCCESS;
   }
}

void SoftDeleteMemcQuery::serializeMemc()
{
   if(true == m_dataMemC)
   {
    char l_dataMemCKey[25];
    memset(l_dataMemCKey,'\0',sizeof(l_dataMemCKey));
    snprintf(l_dataMemCKey,sizeof(l_dataMemCKey),"%s_ULR",m_primaryImsi);
    m_MemcKey = l_dataMemCKey;
   }
   else
   {
    m_MemcKey = m_primaryImsi;
   }
   snprintf(m_PriImsi4Distribution,sizeof(m_PriImsi4Distribution),"%s",m_primaryImsi);
   m_MemcValue = "DELETED";
   DLOG(0,0,"SoftDeleteMemcQuery: serialize: Mark as Deleted starting with MEMC_KEY[%s] MEMC_VALUE[%s]",m_MemcKey.c_str(),m_MemcValue.c_str());
}

bool SoftDeleteMemcQuery::deSerializeMemc()
{
   DLOG(0,0,"SoftDeleteMemcQuery: deSerialize:");
   return true;
}
