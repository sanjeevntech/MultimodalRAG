#include <CtxtOam.h>
#include <stdio.h>
#include <MapMessages.h>
#include <ServiceCoordinator.h>
#include <Logger.h>
#include <OamDbQueries.h>
#include <DbActiveObject.h>
#include <ConfigReader.h>
#include <TcpSocketServer.h>
#include <ProvisioningMessages.h>
#include <HlrTdrFiller.h>
#include <SnmpInterface.h>
#include <CommonData.h>
#include <GlobalData.h>
#include <StatisticsInterface.h>
#include <string>
#include <ContextManager.h>
#include <ExecutionHelper.h>
#include <SubsProfileData.h>
#include <MemCachedActiveObject.h>
#include <OamConfigReader.h>

//#include <des.h>
using namespace std;



#define MAX_TRANSACTIONS   5000


extern long              g_SubscriberBase;
extern char              g_Action[];

extern MessageQueue *g_OamTransactionsList;

#define PROV_GEN_ERROR_INVALID_TRANSACTION_ID   101
#define PROV_GEN_ERROR_INVALID_REQUEST_TYPE     102
#define PROV_GEN_ERROR_INVALID_PARAMETER        103
#define PROV_GEN_ERROR_MAX_TRANSACTIONS         104
#define PROV_GEN_DEVICE_UNAUTHORISED            105
#define PROV_GEN_ERROR_QUEUE_EXCEEDED           106

string  g_ASYNC_REQUEST = "ASYNC_REQUEST";
extern char *g_extraTag;
extern int terminateStack();

bool encodeXmlToTagvalue(char *p_inputXml, string& p_outputShortForm);
bool decodeTagvalueToXml(char *p_inputShortForm, char *p_RootTag, string& p_outputXml);
void tokenize1(char *p_input, char *p_str, int p_size, char p_token, bool p_startToken, bool p_endToken, int p_maxTokens);
void strncpyWithoutSpace(char *p_dest, char *p_src, int p_srcMaxLength, int p_destMaxLength);
/*

   bool decrypt(unsigned char *p_nonEncrypted, unsigned char *p_Encrypted, unsigned char *p_key)
   {
   DES_key_schedule l_ks;

//Decrypt the first 8 bytes
DES_set_key((const_DES_cblock *)p_key, &l_ks);
DES_ecb_encrypt((const_DES_cblock*)p_Encrypted, (DES_cblock*)p_nonEncrypted, &l_ks, DES_DECRYPT);

return true;
}
*/


CtxtOam::CtxtOam()
{
   DLOG(0,0,"CtxtOam::CtxtOam() :cons:");
   m_imd=NULL;
   m_responseToBeSent=false;
   m_executionHelper=NULL;
   m_logTdrs = 0;
}

CtxtOam::~CtxtOam()
{
   if (NULL != m_imd)
   {
      delete(m_imd);
      m_imd=NULL;
      DLOG(0,0,"CtxtOam :des: m_imd");
   }
   if (NULL != m_executionHelper)
   {
      delete(m_executionHelper);
      m_executionHelper=NULL;
      DLOG(0,0,"CtxtOam :des: m_executionHelper");
   }
}


bool decodeTagvalueToXml(char *p_inputShortForm, char *p_RootTag, string& p_outputXml)
{
   if(p_inputShortForm == NULL)
      return false;

   if(p_RootTag == NULL)
   {
      cout << "Root tag in input argument is null" << endl; 
      return false;
   }


   char tempBuff[50][200];
   memset(tempBuff,'\0',sizeof(tempBuff));
   tokenize1(p_inputShortForm, (char*)tempBuff, 200, '|', false, false, 50);

   p_outputXml = "<";
   p_outputXml += p_RootTag;
   p_outputXml += ">";

   for(int i=0; i<30; i++)
   {
      char *l_delimiter = strstr(tempBuff[i], ":");
      if(l_delimiter != NULL)
      {
         string l_locStr(tempBuff[i]);
         string l_val(l_delimiter+1);

         string l_tag = l_locStr.substr(0, l_locStr.length() - strlen(l_delimiter));
         p_outputXml += "<" + l_tag + ">" + l_val + "</" + l_tag + ">"; 
      }
      else
      {
         break;
      }
   }

   p_outputXml += "</";
   p_outputXml += p_RootTag;
   p_outputXml += ">";

   return true;	
}




bool encodeXmlToTagvalue(char *p_inputXml, string& p_outputShortForm)
{
   if(p_inputXml == NULL)
      return false;

   bool startTag = false;
   int l_maxLoopCnt = strlen(p_inputXml);
   for(int i=0; i<l_maxLoopCnt; i++)
   {
      if(*p_inputXml == '<')
      {
         if(p_inputXml+1 == NULL)
         {
            cout << "invalid input xml" << endl;
            return false;
         }

         if(*(p_inputXml+1) == '/')
         {
            startTag = false;
         }
         else
         {
            startTag = true;
         }

         p_inputXml++;
      }
      else if(startTag == false)
      {
         if(*p_inputXml == '/')
         {
            p_outputShortForm += '|';
         }
         p_inputXml++;
      }
      else 
      {
         if(*p_inputXml == '>' && startTag == true)
         {
            if(*(p_inputXml-1) == '/')
            {
               p_outputShortForm += ":;";
            }
            else
               p_outputShortForm += ':';
            p_inputXml++;
            continue;
         }

         if(*p_inputXml == '/')
         {
            p_inputXml++;
            continue;
         }
         p_outputShortForm += *p_inputXml;
         p_inputXml++;
      }
   }
   return true;
}
void logStats(char *p_api, int p_type)
{
   char l_char[50+1];
   if(0 == p_type)
   {
      snprintf(l_char, sizeof(l_char), "%s:Total", p_api);
   }
   else
   {
      snprintf(l_char, sizeof(l_char), "%s:Success", p_api);
   }

   map<string,int>::iterator l_itr = g_globalMap.find(l_char);
   if(l_itr != g_globalMap.end())
   {
      DLOG(0,0,"Found API [%s] in map", l_char);
      HLRStatisticsInitializer::logStatistics(l_itr->second);
   }
   else
   {
      WLOG(0,0,"API [%s] not found in map", l_char);
   }

}

bool CtxtOam::sendResponse(int p_sockFd, int p_DeviceType, string& p_OrigEntityName, string &p_IpAddress, string& p_transId, string& p_reqType, int p_errorCode, char *p_errorDesc, char *p_ResponseBody)
{
   //Setting TDR Parameters
   m_tdr.setInteger(TDR_INDEX_OAM_ERROR_CODE, p_errorCode);
   m_tdr.setString(TDR_INDEX_OAM_ERROR_DESC, p_errorDesc);
   //End of Setting TDR Parameters

   TLOG(0,0,"sendResponse called");
   ProvisioningResMsg *l_provRespMsg = new ProvisioningResMsg;
   l_provRespMsg->m_sockFd = p_sockFd;
   l_provRespMsg->m_OrigEntityName = p_OrigEntityName;
   l_provRespMsg->m_IpAddress = p_IpAddress;
   l_provRespMsg->m_DeviceConnectionType = p_DeviceType;

   string& l_temp=l_provRespMsg->m_data;
   l_temp.assign("<RESPONSE>");
   l_temp.append("<HEADER>");
   l_temp.append("<TRANSACTION_ID>");
   l_temp.append(p_transId);
   l_temp.append("</TRANSACTION_ID>");
   l_temp.append("<REQUEST_TYPE>");
   l_temp.append(p_reqType);

   l_temp.append("</REQUEST_TYPE>");
   l_temp.append("<ERROR_CODE>");
   char l_errorCode[10];
   memset(l_errorCode, '\0', sizeof(l_errorCode));
   sprintf(l_errorCode, "%d", p_errorCode);
   l_temp.append(l_errorCode);
   l_temp.append("</ERROR_CODE>");
   l_temp.append("<ERROR_DESC>");
   l_temp.append(p_errorDesc);
   l_temp.append("</ERROR_DESC>");
   l_temp.append("</HEADER>");


   if(NULL != p_ResponseBody) //strlen(p_ResponseBody) > 0)
   {
      TLOG(0,0,"Body is present");
      l_temp.append("<BODY>");
      l_temp.append(p_ResponseBody);
      if(NULL != g_extraTag)
      {
         l_temp.append("<EXTRA_ADDED_TAG>TEST</EXTRA_ADDED_TAG>");
      }

      char l_buf[256];
      if(0 == strcmp(p_reqType.c_str(),"GET_NETWORK_ELEMENT_INFO"))
      {
         time_t rawtime = time(NULL);
         if (rawtime == -1) {
            DLOG(0,0,"The time() function failed");
         }
         struct tm *ptm = localtime(&rawtime);

         if (ptm == NULL) {
            DLOG(0,0,"The localtime() function failed");
            //return 1;
         }

         l_temp.append("<SYSTEM_DATE>");
         memset(l_buf, '\0', 256);
         sprintf(l_buf, "<DATE_TIME>%04d%02d%02d%02d%02d%02d</DATE_TIME>",
               ptm->tm_year+1900, ptm->tm_mon+1, ptm->tm_mday,
               ptm->tm_hour, ptm->tm_min, ptm->tm_sec);
         l_temp.append(l_buf);
         memset(l_buf, '\0', 256);
         strftime(l_buf, 256, "<TIME_ZONE_OFFSET>%z</TIME_ZONE_OFFSET>", ptm);
         l_temp.append(l_buf);
         memset(l_buf, '\0', 256);
         strftime(l_buf, 256, "<TIME_ZONE_NAME>%Z</TIME_ZONE_NAME>", ptm);
         l_temp.append(l_buf);
         memset(l_buf, '\0', 256);
         sprintf(l_buf,"<DST_INDICATOR>%d</DST_INDICATOR>",ptm->tm_isdst);
         l_temp.append(l_buf);
         l_temp.append("</SYSTEM_DATE>");
      }

      l_temp.append("</BODY>");
   }
   else
   {
      DLOG(0,0,"Appending empty BODY tag as data is NULL");
      l_temp.append("<BODY></BODY>");
   }

   l_temp.append("</RESPONSE>");


   return g_tcpSocketQueue->push(l_provRespMsg);
}

bool CtxtOam::startProcessing(InterModuleData *p_imd, bool& p_DeleteFlag)
{
   if(1 == g_IMEI_EncrFlag)
   {
      m_tdr.setInteger(TDR_INDEX_SMSM_GPRS_SM_DEL_OUTCOME,1);
      TLOG(0,0,"IMEI Encyrption Flag enabled");
   }

   m_imd = p_imd;
   p_DeleteFlag=false;

   LLOG(0,1,"CtxtOam::startProcessing() called");

   int l_ParametersLen;
   if(p_imd->m_Parameters != NULL)
   {
      l_ParametersLen = strlen(p_imd->m_Parameters);
      DLOG(0,0,"OAM: l_ParametersLen [%d]",l_ParametersLen);
   }
   //DLOG(0,0,"strlen m_parameters[%d]",strlen(p_imd->m_Parameters));
   //if (strlen(p_imd->m_Parameters)>0) //This is assumed to be the Transaction from the OCI (ROWID would be coming)
   if (l_ParametersLen > 0) //This is assumed to be the Transaction from the OCI (ROWID would be coming)
   {
      DLOG(0,0,"before strstr");
      if(strstr((char*)p_imd->m_Parameters, "<MSG_TYPE>MORPHED</MSG_TYPE>"))
      {
         LLOG(0,0,"Preparing the message in TDR so that RTPS informs the other node");

         int l_opCode=0;
         if( false == ConfigReader::readInteger((char*)p_imd->m_Parameters, "OP_CODE", l_opCode, 0, 1000))
         {
            ELOG(0,0,"Unable to read the Operation Code of the morphed message");
            return false;
         }
         char l_xml[l_ParametersLen+1];
         memset(l_xml,'\0',sizeof(l_xml));
         if (false == ConfigReader::readString((char*)p_imd->m_Parameters, "XML", l_xml,1,sizeof(l_xml)))
         {
            ELOG(0,0,"Unable to read the XML content of the morphed message");
            return false;
         }
         char l_msg_orig[10+1];
         if (false == ConfigReader::readString((char*)p_imd->m_Parameters, "MSG_ORIG", l_msg_orig,1,10))
         {
            ELOG(0,0,"Unable to read the MSG_ORIG content of the morphed message");
            return false;
         }

         char l_xml1[l_ParametersLen+1];
         memset(l_xml1,'\0',sizeof(l_xml1));
         if(309 != l_opCode && 305 != l_opCode && 319 != l_opCode && 64 != l_opCode)
         {
            if (false == ConfigReader::readString(l_xml, "CANCEL_LOC", l_xml1,1,sizeof(l_xml)))
            {
               ELOG(0,0,"Unable to read the CANCEL_LOC content of the morphed message");
               return false;
            }
         }

         if(309 == l_opCode)
         {
            if (false == ConfigReader::readString(l_xml, "SSM_PNR", l_xml1,1,sizeof(l_xml)))
            {
               ELOG(0,0,"Unable to read the SSM_PNR content of the morphed message");
               return false;
            }
         }
         
         if(305 == l_opCode)
         {
            if (false == ConfigReader::readString(l_xml, "PUSH_PROFILE_REQ", l_xml1,1,sizeof(l_xml)))
            {
               ELOG(0,0,"Unable to read the PUSH_PROFILE_REQ content of the morphed message");
               return false;
            }
         }

         if(319 == l_opCode)
         {
            if (false == ConfigReader::readString(l_xml, "IDR", l_xml1,1, sizeof(l_xml)))
            {
               ELOG(0,0,"Unable to read the IDR content of the morphed message");
               return false;
            }
         }


         if(64 == l_opCode)
         {
            if (false == ConfigReader::readString(l_xml, "ALERT_SC", l_xml1,1, sizeof(l_xml)))
            {
               ELOG(0,0,"Unable to read the ALERT_SC content of the morphed message");
               return false;
            }
            else
            {
               DLOG(0,0,"Reading the ALERT_SC content of the morphed message");
            }
         }

         string l_ApplicationId;
         if(false == ConfigReader::readString(l_xml, "APP_ID", l_ApplicationId, 0, 10))
         {
            LLOG(0,0,"APP_ID is not Present");
         }
         m_tdr.setString(TDR_INDEX_REMOTE_ERR_CODE, (s8*)l_ApplicationId.c_str());
         //bool encodeXmlToTagvalue(char *p_inputXml, string& p_outputShortForm)
         string l_convertedData;
         bool l_status = encodeXmlToTagvalue(l_xml1, l_convertedData);

         if(true == l_status)
         {
            moduleLevelLogStats("GeneratingCrossMessage");
            m_tdr.setString(TDR_INDEX_OAM_REQUEST_TYPE, "MORPHED");
            m_tdr.setInteger(TDR_INDEX_ULR_ROWID_ONE, l_opCode);
            if(l_convertedData.size() > 200)
            {
               TLOG(0,0,"Converteddata size[%d] greater than 200",l_convertedData.size());
               char l_buff[200];
               memset(l_buff,'\0',sizeof(l_buff));
               snprintf(l_buff,sizeof(l_buff),"%s",(char*)l_convertedData.c_str());
               m_tdr.setString(TDR_INDEX_ULR_ROWID_THREE, l_buff);
               memset(l_buff,'\0',sizeof(l_buff));
               snprintf(l_buff,sizeof(l_buff),"%s",(char*)l_convertedData.c_str()+199);
               m_tdr.setString(TDR_INDEX_ULR_ROWID_FOUR, l_buff);
               if(l_convertedData.size() > 398)
               {
                  memset(l_buff,'\0',sizeof(l_buff));
		  snprintf(l_buff,sizeof(l_buff),"%s",(char*)l_convertedData.c_str()+398);
		  m_tdr.setString(TDR_INDEX_NOR_MIP6AI_HA_FAMILY1, l_buff);
               }
            }
            else
            {
               m_tdr.setString(TDR_INDEX_ULR_ROWID_THREE, (char*)l_convertedData.c_str());
            }
            m_tdr.setString(TDR_INDEX_ULR_ROWID_TWO, l_msg_orig);
         }
         else
         {
            ELOG(0,0,"encodeXmlToTagvalue failed");
            return false;
         }
         return true;
      }
      else if (0 == strcmp("RELOAD", (char*)p_imd->m_Parameters))
      {
         LLOG(0,0,"Assuming Bulk Reload request from MMI Tool");
         RetrieveOamBulkTrans *l_robt = new RetrieveOamBulkTrans();
         l_robt->m_cb = this;
         l_robt->m_DbQueryType = 3;
         g_act.execute(l_robt);
      }
      else if (0 != strstr((char*)p_imd->m_Parameters, "BULK:"))
      {
         LLOG(0,0,"Assuming MBOS/SPA requests as part of a Bulk Transaction");

         string l_request_type  = ConfigReader::readValue((char*)p_imd->m_Parameters, "REQUEST_TYPE");
         if(l_request_type.size() < 1)
         {
            ELOG(0,1,"Invalid Request type in bulk");
            return false;
         }
         logStats((char*)l_request_type.c_str(), 0);

         string l_bulk_trans_id  = ConfigReader::readValue((char*)p_imd->m_Parameters, "BULK_TRANS_ID");
         if(l_bulk_trans_id.size() < 1)
         {
            ELOG(0,1,"Invalid Transaction in bulk");
            return false;
         }

         string l_entity_name  = ConfigReader::readValue((char*)p_imd->m_Parameters, "ENTITY_NAME");
         if(l_entity_name.size() < 1)
         {
            ELOG(0,1,"Invalid Entity Name in bulk");
            return false;
         }

         string l_xml  = ConfigReader::readValue((char*)p_imd->m_Parameters, "XML");
         if(l_xml.size() < 1)
         {
            ELOG(0,1,"Invalid XML in bulk");
            return false;
         }

         if (0 != strstr((char*)p_imd->m_Parameters, "LOG_TDRS"))
         {
            if(false == ConfigReader::readInteger((char*)p_imd->m_Parameters, "LOG_TDRS", m_logTdrs, 0, 1))
            {
               LLOG(0,0,"m_logTdrs = [%d] LOG_TDRS can be either 0 or 1", m_logTdrs);
            }
         }

         char *l_temp = NULL;
         l_temp = strchr((char*)l_request_type.c_str(), ':');
         if (NULL == l_temp)
         {
            CLOG(0,1,"Invalid Request type in the data");
            return false;
         }

         m_tdr.setString(TDR_INDEX_OAM_REQUEST_TYPE, l_temp+1);

         string l_xml_trans;
         l_xml_trans = l_xml + "<BULK_TRANS_ID>" + l_bulk_trans_id + "</BULK_TRANS_ID>";

         char l_PrimaryImsi[20+1];
         if (m_logTdrs == 1)
         {
            int l_Network_ID = 0;
            char l_Account_ID[20+1];
            char l_PrimaryMsisdn[20+1];
            char l_IccID[20+1];
            memset(l_Account_ID,'\0',sizeof(l_Account_ID));
            memset(l_PrimaryImsi,'\0',sizeof(l_PrimaryImsi));
            memset(l_PrimaryMsisdn,'\0',sizeof(l_PrimaryMsisdn));
            memset(l_IccID,'\0',sizeof(l_IccID));


            if (true == ConfigReader::readInteger(l_xml, "NETWORK_ID",l_Network_ID, 1, 100))
            {
               LLOG(0,0,"NETWORK_ID = [%d]",l_Network_ID);
               m_tdr.setInteger(TDR_INDEX_MM_NETWORK_ID,l_Network_ID);
            }
            if (true == ConfigReader::readString(l_xml,"ACCOUNT_ID",l_Account_ID, 1, sizeof(l_Account_ID)))
            {
               LLOG(0,0,"ACCOUNT_ID = [%s]",l_Account_ID);
               m_tdr.setString(TDR_INDEX_ACCOUNT_ID, l_Account_ID);
            }
            if (true == ConfigReader::readString(l_xml,"PRIMARY_IMSI",l_PrimaryImsi, 1, sizeof(l_PrimaryImsi)))
            {
               LLOG(0,0,"PRIMARY_IMSI = [%s]",l_PrimaryImsi);
               m_tdr.setString(TDR_INDEX_MM_PRIMARY_IMSI,l_PrimaryImsi);
            }
            if (true == ConfigReader::readString(l_xml,"PRIMARY_MSISDN",l_PrimaryMsisdn, 1, sizeof(l_PrimaryMsisdn)))
            {
               LLOG(0,0,"PRIMARY_MSISDN= [%s]",l_PrimaryMsisdn);
               m_tdr.setString(TDR_INDEX_MM_PRIMARY_MSISDN,l_PrimaryMsisdn);
            }
            if (true == ConfigReader::readString(l_xml,"ICC_ID",l_IccID, 1, sizeof(l_IccID)))
            {
               LLOG(0,0,"ICC_ID = [%s]",l_IccID);
               m_tdr.setString(TDR_INDEX_ICC_ID,l_IccID);
            }

            char l_FreeFormatTdr[100];
            memset(l_FreeFormatTdr,'\0',sizeof(l_FreeFormatTdr));
            if (true == ConfigReader::readString(l_xml,"FREE_FORMAT_TDR",l_FreeFormatTdr, 0, sizeof(l_FreeFormatTdr)))
            {
               LLOG(0,0,"FreeFormatTdr = [%s]",l_FreeFormatTdr);
               m_tdr.setString(TDR_INDEX_OAM_FREE_FORMAT_DATA,l_FreeFormatTdr);
            }
         }
         GenericXmlApiData *l_gxad = new GenericXmlApiData;
         strncpy(l_gxad->m_requestType, l_temp+1, MAX_REQUEST_TYPE_LEN);
         int l_Length = strlen((char*)l_xml.c_str());
         if(l_Length > 0)
         {
            l_gxad->m_xmlBody = new char[l_Length + 201];
            snprintf(l_gxad->m_xmlBody,l_Length + 201,"%s",(char*)l_xml.c_str());
         }
         sprintf(l_gxad->m_user, "%s", l_entity_name.c_str());
         strncpy(l_gxad->m_transactionRef, "TRANS", MAX_TRANS_REF_LEN);
         strncpy(l_gxad->m_bulkTransId, l_bulk_trans_id.c_str(), MAX_TRANS_REF_LEN);
         l_gxad->m_cb = this;
         l_gxad->m_DbQueryType = 2;
         l_gxad->m_logTDRs = m_logTdrs;
         if(1 == m_logTdrs)
         {
            snprintf(l_gxad->m_primary_imsi,sizeof(l_gxad->m_primary_imsi),"%s",l_PrimaryImsi);
         }
         g_act.execute(l_gxad);
      }
      else if (0 != strstr((char*)p_imd->m_Parameters, "<SCHEDULER>"))
      {
         LLOG(0,0,"Assuming Scheduler request received");
         char l_type[20+1];
         if (false == ConfigReader::readString((char*)p_imd->m_Parameters, "TYPE", l_type,1,sizeof(l_type)-1))
         {
            WLOG(0,0,"TYPE not present in SCHEDULER");
            return false;
         }

         char l_data[1000+1];
         if (false == ConfigReader::readString((char*)p_imd->m_Parameters, "DATA", l_data,1,sizeof(l_data)-1))
         {
            WLOG(0,0,"DATA not present in SCHEDULER_DATA");
            return false;
         }

         m_tdr.setString(TDR_INDEX_OAM_REQUEST_TYPE,    l_type);
         m_tdr.setString(TDR_INDEX_OAM_FREE_FORMAT_DATA,l_data);
         return false;

      }
      else
      {
         LLOG(0,0,"Assuming request from OCI with row id [%s]", (NULL == p_imd->m_Parameters)?"":p_imd->m_Parameters);
         RetrieveOamTransData *l_otd = new RetrieveOamTransData();
         l_otd->m_cb = this;
         strncpy(l_otd->m_RowId, (char*)p_imd->m_Parameters, MAX_ROW_ID_LEN);
         l_otd->m_DbQueryType = 1;
         g_act.execute(l_otd);
      }
   }
   else if(p_imd->m_msgPtr != NULL)
   {
      ProvisioningReqMsg *l_provReqMsg = (ProvisioningReqMsg*)p_imd->m_msgPtr;

      LLOG(0,0,"Should Initiate Provisioning API here [%s]", l_provReqMsg->m_data.c_str());

      m_tdr.setOriginatingModule((char*)l_provReqMsg->m_OrigEntityName.c_str());
      m_tdr.setString(TDR_INDEX_OAM_REQUEST_TYPE, "UNKNOWN");
      m_tdr.setRemoteAddr((char*)((ProvisioningMsg*)(m_imd->m_msgPtr))->m_IpAddress.c_str());

      string l_request = ConfigReader::readValue(l_provReqMsg->m_data, "ASYNC_REQUEST"); // This is for current SPA release
      if (l_request.size() < 1)
      {
         l_request = ConfigReader::readValue(l_provReqMsg->m_data, "REQUEST"); //This is for the GUI and MBOS interfaces
      }

      string l_transId;
      string l_reqType;

      string l_header  = ConfigReader::readValue(l_request, "HEADER");
      if(l_header.size() < 1)
      {
         ELOG(0,1,"Invalid XML. Check the HEADER starting and ending tags");
         sendResponse(l_provReqMsg->m_sockFd, l_provReqMsg->m_DeviceConnectionType, l_provReqMsg->m_OrigEntityName, l_provReqMsg->m_IpAddress, l_transId, l_reqType, PROV_GEN_ERROR_INVALID_PARAMETER, "Invalid XML. Check the HEADER starting and ending tags", NULL);
         return false;
      }

      string l_body    = ConfigReader::readValue(l_request, "BODY");
      if(l_body.size() < 1)
      {
         if(NULL == strstr(l_request.c_str(), "<REQUEST_TYPE>GET_MODULE_CONFIG_DATA</REQUEST_TYPE>"))
         {
            ELOG(0,1,"Invalid XML. Check the BODY starting and ending tags");
            sendResponse(l_provReqMsg->m_sockFd, l_provReqMsg->m_DeviceConnectionType, l_provReqMsg->m_OrigEntityName, l_provReqMsg->m_IpAddress, l_transId, l_reqType, PROV_GEN_ERROR_INVALID_PARAMETER, "Invalid XML. Check the BODY starting and ending tags", NULL);
            return false;
         }
      }

      string l_itg = ConfigReader::readValue(l_body, "MESSAGE_ORIGINATION");
      if(0 == strcmp((char*)l_itg.c_str(), "ITG"))
      {
         m_tdr.setString(TDR_INDEX_REQUEST_DOMAIN, "ITG");
      }
      else
      {
         m_tdr.setString(TDR_INDEX_REQUEST_DOMAIN, "LOCAL");
      }


      l_transId = ConfigReader::readValue(l_header, "TRANSACTION_ID");
      l_reqType = ConfigReader::readValue(l_header, "REQUEST_TYPE");

      if(false == ConfigReader::readString(l_header, "TRANSACTION_ID", l_transId, 1, 30))
      {
         if(NULL == strstr(l_request.c_str(), "<REQUEST_TYPE>GET_MODULE_CONFIG_DATA</REQUEST_TYPE>"))
         {
            ELOG(0,1,"Invalid TRANSACTION_ID. Should be between 1 and 30 digits");
            sendResponse(l_provReqMsg->m_sockFd, l_provReqMsg->m_DeviceConnectionType, l_provReqMsg->m_OrigEntityName, l_provReqMsg->m_IpAddress, l_transId, l_reqType, PROV_GEN_ERROR_INVALID_TRANSACTION_ID, "Invalid TRANSACTION_ID", NULL);
            return false;
         }
      }

      l_provReqMsg->m_transId = l_transId;
      m_tdr.setString(TDR_INDEX_OAM_TRANSACTION_ID, (char*)l_transId.c_str());

      if(false == ConfigReader::readString(l_header, "REQUEST_TYPE", l_reqType, 1, 40))
      {
         ELOG(0,1,"Invalid REQUEST_TYPE length");
         sendResponse(l_provReqMsg->m_sockFd, l_provReqMsg->m_DeviceConnectionType, l_provReqMsg->m_OrigEntityName, l_provReqMsg->m_IpAddress, l_transId, l_reqType, PROV_GEN_ERROR_INVALID_REQUEST_TYPE, "Invalid REQUEST_TYPE", NULL);
         return false;
      }

      if (0 != strstr(l_header.c_str(), "LOG_TDRS"))
      {
         if(false == ConfigReader::readInteger(l_header, "LOG_TDRS", m_logTdrs, 0, 1))
         {
            LLOG(0,0,"m_logTdrs = [%d] LOG_TDRS can be either 0 or 1", m_logTdrs);
         }
      }

      char l_PrimaryImsi[20+1];
      if ((m_logTdrs == 1 )&& (NULL == strstr(l_reqType.c_str(), "BULK:"))) // single mode
      { 
         int l_Network_ID = 0;
         char l_Account_ID[20+1];
         char l_PrimaryMsisdn[20+1];
         char l_IccID[20+1];
         memset(l_Account_ID,'\0',sizeof(l_Account_ID));
         memset(l_PrimaryImsi,'\0',sizeof(l_PrimaryImsi));
         memset(l_PrimaryMsisdn,'\0',sizeof(l_PrimaryMsisdn));
         memset(l_IccID,'\0',sizeof(l_IccID));

         if (true == ConfigReader::readInteger(l_body, "NETWORK_ID",l_Network_ID, 1, 100))
         {
            LLOG(0,0,"NETWORK_ID = [%d]",l_Network_ID);
            m_tdr.setInteger(TDR_INDEX_MM_NETWORK_ID,l_Network_ID);
         }
         if (true == ConfigReader::readString(l_body,"ACCOUNT_ID",l_Account_ID, 1, sizeof(l_Account_ID)))
         {
            LLOG(0,0,"ACCOUNT_ID = [%s]",l_Account_ID);
            m_tdr.setString(TDR_INDEX_ACCOUNT_ID, l_Account_ID);
         }
         if (true == ConfigReader::readString(l_body,"PRIMARY_IMSI",l_PrimaryImsi, 1, sizeof(l_PrimaryImsi)))
         {
            LLOG(0,0,"PRIMARY_IMSI = [%s]",l_PrimaryImsi);
            m_tdr.setString(TDR_INDEX_MM_PRIMARY_IMSI,l_PrimaryImsi);
         }
         if (true == ConfigReader::readString(l_body,"PRIMARY_MSISDN",l_PrimaryMsisdn, 1, sizeof(l_PrimaryMsisdn)))
         {
            LLOG(0,0,"PRIMARY_MSISDN= [%s]",l_PrimaryMsisdn);
            m_tdr.setString(TDR_INDEX_MM_PRIMARY_MSISDN,l_PrimaryMsisdn);
         }
         if (true == ConfigReader::readString(l_body,"ICC_ID",l_IccID, 1, sizeof(l_IccID)))
         {
            LLOG(0,0,"ICC_ID = [%s]",l_IccID);
            m_tdr.setString(TDR_INDEX_ICC_ID,l_IccID);
         }

         char l_FreeFormatTdr[100];
         memset(l_FreeFormatTdr,'\0',sizeof(l_FreeFormatTdr));
         if (true == ConfigReader::readString(l_body,"FREE_FORMAT_TDR",l_FreeFormatTdr, 0, sizeof(l_FreeFormatTdr)))
         {
            LLOG(0,0,"FreeFormatTdr = [%s]",l_FreeFormatTdr);
            m_tdr.setString(TDR_INDEX_OAM_FREE_FORMAT_DATA,l_FreeFormatTdr);
         }
      } 

      // HLR 2.0.24.0
      string l_origInfo;
      string l_origTxnId;
      string l_origEntity;
      if(true == ConfigReader::readString(l_header, "ORIGINATING_ENTITY_INFO", l_origInfo, 0, 200))
      {
         if(l_origInfo.size() > 0)
         {
            if(true == ConfigReader::readString(l_origInfo, "ORIG_TRANS_ID", l_origTxnId, 0, 100))
            {
               LLOG(0,0,"ORIG_TRANS_ID[%s] for RequestType[%s]",(char*)l_origTxnId.c_str(),(char*)l_reqType.c_str());
               m_tdr.setString(TDR_INDEX_RESRV_POS147, (char*)l_origTxnId.c_str());
            }
            else
            {
               TLOG(0,0,"ORIG_TRANS_ID not present for RequestType[%s]",(char*)l_reqType.c_str());
            }

            if(true == ConfigReader::readString(l_origInfo, "ORIG_ENTITY", l_origEntity, 0, 100))
            {
               LLOG(0,0,"ORIG_ENTITY[%s] for RequestType[%s]",(char*)l_origEntity.c_str(),(char*)l_reqType.c_str());
               m_tdr.setString(TDR_INDEX_RESRV_POS148, (char*)l_origEntity.c_str());
            }
            else
            {
               TLOG(0,0,"ORIG_ENTITY not present for RequestType[%s]",(char*)l_reqType.c_str());
            }
         }
         else
         {
            TLOG(0,0,"ORIGINATING_ENTITY_INFO size error [%d]",l_origInfo.size());
         }
      }
      else
      {
         TLOG(0,0,"ORIGINATING_ENTITY_INFO not present for RequestType[%s]",(char*)l_reqType.c_str());
      }
      ///////////////////


      m_tdr.setString(TDR_INDEX_OAM_REQUEST_TYPE, (char*)l_reqType.c_str());

      l_provReqMsg->m_transType = l_reqType;


      if (0 == strcmp(l_reqType.c_str(), "OAM"))
      {
         if((0 == strcmp("HLRBSS", l_provReqMsg->m_OrigEntityName.c_str())) ||
               (NULL  != strstr(l_provReqMsg->m_OrigEntityName.c_str(), "RTPS"))
           )
         {
            LLOG(0,0,"Assuming request from GUI");
            string l_oam_transactions;
            if(false == ConfigReader::readString(l_body, "OAM_TRANSACTIONS", l_oam_transactions, 1, 5000000))
            {
               ELOG(0,1,"Invalid OAM_TRANSACTIONS length");
               sendResponse(l_provReqMsg->m_sockFd, l_provReqMsg->m_DeviceConnectionType, l_provReqMsg->m_OrigEntityName, l_provReqMsg->m_IpAddress, l_transId, l_reqType, PROV_GEN_ERROR_INVALID_PARAMETER, "Invalid OAM_TRANSACTIONS length", NULL);
               return false;
            }
            logStats("OAM", 0);

            char *ptr1, *ptr2;
            ptr1=ptr2=NULL;
            ptr1 = ptr2 = (char*)l_oam_transactions.c_str();
            ptr2++;
            int l_totalRequests=0;
            while(*ptr2 != '\0')
            {
               if('|' == *ptr2)
               {
                  if(ptr2-ptr1 == 1)
                  {
                     TLOG(0,1,"Breaking from the loop");
                     break;
                  }
                  else
                  {
                     l_totalRequests++;
                     char l_rowidChar[30];
                     memset(l_rowidChar, '\0', 30);
                     strncpy(l_rowidChar,ptr1+1,ptr2-ptr1-1);
                     TLOG(0,1,"Got a row id to process [%s]", l_rowidChar);
                     g_sc.initiateIndependentContext(this, MAP_OP_CODE_dummy_1, l_rowidChar, INITIATION_TYPE_TARDILY);
                     ptr1=ptr2;
                  }
               }
               ptr2++;
            }
            m_tdr.setInteger(TDR_INDEX_OAM_FREE_FORMAT_DATA,l_totalRequests);


            sendResponse(l_provReqMsg->m_sockFd, l_provReqMsg->m_DeviceConnectionType, l_provReqMsg->m_OrigEntityName, l_provReqMsg->m_IpAddress, l_transId, l_reqType, 0, "Success", NULL);
            logStats("OAM", 1);
         }
         else
         {
            sendResponse(l_provReqMsg->m_sockFd, l_provReqMsg->m_DeviceConnectionType, l_provReqMsg->m_OrigEntityName, l_provReqMsg->m_IpAddress, l_transId, l_reqType, 105, "Device Unauthorized for this internal operation", NULL);
         }
      }
      else if (0 == strcmp(l_reqType.c_str(), "INITIATE_CONTEXT"))
      {
         LLOG(0,0,"Processing the message from for this instance usage");

         int l_opCode=0;
         if( false == ConfigReader::readInteger(l_body, "OP_CODE", l_opCode, 0, 1000))
         {
            ELOG(0,0,"Unable to read the Operation Code of the morphed message");
            return false;
         }
         char l_xml[2000];
         memset(l_xml,'\0',sizeof(l_xml));
         if (false == ConfigReader::readString(l_body, "XML", l_xml,1,sizeof(l_xml)))
         {
            ELOG(0,0,"Unable to read the XML content of the morphed message");
            return false;
         }
         char l_msg_orig[10+1];
         if (false == ConfigReader::readString(l_body, "MSG_ORIG", l_msg_orig,1,10))
         {
            ELOG(0,0,"Unable to read the MSG_ORIG content of the morphed message");
            return false;
         }

         LLOG(0,0,"Processing the message with OpCode:[%d]", l_opCode);
         m_tdr.setString(TDR_INDEX_OAM_REQUEST_TYPE, "RECEIVED_MORPHED");
         m_tdr.setInteger(TDR_INDEX_ULR_ROWID_ONE, l_opCode);
         m_tdr.setString(TDR_INDEX_ULR_ROWID_TWO, l_msg_orig);

         //bool decodeTagvalueToXml(char *p_inputShortForm, char *p_RootTag, string& p_outputXml)
         string l_convertedData;

         if(309 != l_opCode && 305 != l_opCode && 319 != l_opCode && 64 != l_opCode)
         {
            bool l_status = decodeTagvalueToXml(l_xml, "CANCEL_LOC", l_convertedData);
            if(true == l_status)
            {
               moduleLevelLogStats("ReceivedCL");
               g_sc.initiateIndependentContext(this, (EMapOpCode)(l_opCode), (char*)l_convertedData.c_str(), INITIATION_TYPE_IMMEDIATE);
            }
            else
            {
               ELOG(0,0,"decodeTagvalueToXml failed");
               return false;
            }
         }
         if(309 == l_opCode)
         {
            bool l_status1 = decodeTagvalueToXml(l_xml, "SSM_PNR", l_convertedData);
            if(true == l_status1)
            {
               moduleLevelLogStats("ReceivedPNR");
               g_sc.initiateIndependentContext(this, (EMapOpCode)(l_opCode), (char*)l_convertedData.c_str(), INITIATION_TYPE_IMMEDIATE);
            }
            else
            {
               ELOG(0,0,"decodeTagvalueToXml failed");
               return false;
            }
         }
         if(305 == l_opCode)
         {
            bool l_status2 = decodeTagvalueToXml(l_xml, "PUSH_PROFILE_REQ", l_convertedData);
            if(true == l_status2)
            {
               moduleLevelLogStats("ReceivedPPR");
               g_sc.initiateIndependentContext(this, (EMapOpCode)(l_opCode), (char*)l_convertedData.c_str(), INITIATION_TYPE_IMMEDIATE);
            }
            else
            {
               ELOG(0,0,"decodeTagvalueToXml failed");
               return false;
            }
         }
         if(319 == l_opCode)
         {
            bool l_status3 = decodeTagvalueToXml(l_xml, "IDR", l_convertedData);
            if(true == l_status3)
            {
               moduleLevelLogStats("ReceivedIDR");
               char l_transId[20+1];
               memset(l_transId, '\0',sizeof(l_transId));
               snprintf(l_transId,sizeof(l_transId),"%d",time(NULL));
               l_convertedData = string(l_transId) + ':' + l_convertedData;
               g_sc.initiateIndependentContext(this, (EMapOpCode)(l_opCode), (char*)l_convertedData.c_str(), INITIATION_TYPE_IMMEDIATE);
            }
            else
            {
               ELOG(0,0,"decodeTagvalueToXml failed");
               return false;
            }
         }
         if(64 == l_opCode)
         {
            bool l_status4 = decodeTagvalueToXml(l_xml, "ALERT_SC", l_convertedData);
            if(true == l_status4)
            {
               moduleLevelLogStats("ReceivedSARAlertSC");
               g_sc.initiateIndependentContext(this, (EMapOpCode)(l_opCode), (char*)l_convertedData.c_str(), INITIATION_TYPE_IMMEDIATE);
            }
            else
            {
               ELOG(0,0,"decodeTagvalueToXml failed");
               return false;
            }
         }
         sendResponse(l_provReqMsg->m_sockFd, l_provReqMsg->m_DeviceConnectionType, l_provReqMsg->m_OrigEntityName, l_provReqMsg->m_IpAddress, l_transId, l_reqType, 0, "Success", NULL);
         return true;
      }
      else if (NULL != strstr(l_reqType.c_str(), "BULK:"))
      {
         LLOG(0,0,"Assuming request from MBOS/SPA (Bulk Interface)");


         if (0 != strstr(l_header.c_str(), "LOG_TDRS"))
         {
            if(false == ConfigReader::readInteger(l_header, "LOG_TDRS", m_logTdrs, 0, 1))
            {
               LLOG(0,0,"m_logTdrs = [%d] LOG_TDRS can be either 0 or 1", m_logTdrs);
            }
         }
         
         string l_oam_transactions;
         if(false == ConfigReader::readString(l_body, "TRANSACTIONS", l_oam_transactions, 1, 5000000))
         {
            ELOG(0,1,"Invalid TRANSACTIONS length");
            sendResponse(l_provReqMsg->m_sockFd, l_provReqMsg->m_DeviceConnectionType, l_provReqMsg->m_OrigEntityName, l_provReqMsg->m_IpAddress, l_transId, l_reqType, PROV_GEN_ERROR_INVALID_PARAMETER, "Invalid TRANSACTIONS length", NULL);
            return false;
         }

         char l_original_req_type[100];
         memset(l_original_req_type, '\0', sizeof(l_original_req_type));
         char *l_temp = strchr(l_reqType.c_str(), ':');
         if (NULL == l_temp)
         {
            ELOG(0,1,"Invalid REQUEST_TYPE data");
            sendResponse(l_provReqMsg->m_sockFd, l_provReqMsg->m_DeviceConnectionType, l_provReqMsg->m_OrigEntityName, l_provReqMsg->m_IpAddress, l_transId, l_reqType, PROV_GEN_ERROR_INVALID_PARAMETER, "Invalid REQUEST_TYPE data", NULL);
            return false;
         }

         TLOG(0,0,"req [%s], temp [%s]", l_reqType.c_str(), l_temp);

         strncpy(l_original_req_type, l_temp+1, strlen(l_temp)-1);

         if (strlen(l_original_req_type) < 5)
         {
            ELOG(0,1,"Invalid ORIGINAL_REQUEST_TYPE data length: %s", l_original_req_type);
            sendResponse(l_provReqMsg->m_sockFd, l_provReqMsg->m_DeviceConnectionType, l_provReqMsg->m_OrigEntityName, l_provReqMsg->m_IpAddress, l_transId, l_reqType, PROV_GEN_ERROR_INVALID_PARAMETER, "Invalid ORIGINAL_REQUEST_TYPE data", NULL);
            return false;
         }

         int l_count_pipes=0;
         char *l_temp_char = (char*)l_oam_transactions.c_str();
         int l_temp_char_len = strlen(l_temp_char);
         for (int l_i=0; l_i<l_temp_char_len; l_i++)
         {
            if ('^' == l_temp_char[l_i])
            {
               l_count_pipes++;
            }
         }
         l_count_pipes--;  //removing the extra pipe


         if (l_count_pipes > MAX_TRANSACTIONS)
         {
            WLOG(0,1,"Cannot process more than %d transactions", MAX_TRANSACTIONS);
            sendResponse(l_provReqMsg->m_sockFd, l_provReqMsg->m_DeviceConnectionType, l_provReqMsg->m_OrigEntityName, l_provReqMsg->m_IpAddress, l_transId, l_reqType, PROV_GEN_ERROR_MAX_TRANSACTIONS, "Cannot process more than 5000 transactions", NULL);
            return false;
         }

         int l_currentTransQueue = g_OamTransactionsList->size();
         if( (l_count_pipes+l_currentTransQueue) > 2*MAX_TRANSACTIONS)
         {
            char l_response[200+1];
            snprintf(l_response, sizeof(l_response), "Pending Requests Queue size is %d. Requested to process %d requests in bulk. Queue will cross %d, hence rejecting", l_currentTransQueue, l_count_pipes, 2*MAX_TRANSACTIONS);
            WLOG(0,1,"%s", l_response);
            sendResponse(l_provReqMsg->m_sockFd, l_provReqMsg->m_DeviceConnectionType, l_provReqMsg->m_OrigEntityName, l_provReqMsg->m_IpAddress, l_transId, l_reqType, PROV_GEN_ERROR_QUEUE_EXCEEDED, l_response, NULL);
            return false;
         }

         m_oam_transactions = l_oam_transactions;
         m_reqType = l_reqType;


         InsertBulkTransId *l_ibt = new InsertBulkTransId;
         sprintf(l_ibt->m_TransId, "T%d", time(NULL));

         char l_ipAddress[15+1];
         memset(l_ipAddress, '\0', sizeof(l_ipAddress));
         char *l_char = NULL;
         l_char = strchr((char*)l_provReqMsg->m_IpAddress.c_str(), ':');
         if(NULL != l_char)
         {
            strncpy(l_ipAddress, (char*)l_provReqMsg->m_IpAddress.c_str(), strlen((char*)l_provReqMsg->m_IpAddress.c_str()) - strlen(l_char));
         }
         else
         {
            strcpy(l_ipAddress, (char*)l_provReqMsg->m_IpAddress.c_str());
         }

         snprintf(l_ibt->m_user, MAX_USER_ID_LEN+1, "%s:%s", l_ipAddress, (char*)l_provReqMsg->m_OrigEntityName.c_str());
         snprintf(l_ibt->m_ip, MAX_IP_ADDR_LEN+1, "%s", l_ipAddress);
         strncpy(l_ibt->m_requestType, l_original_req_type, MAX_REQUEST_TYPE_LEN);
         l_ibt->m_count = l_count_pipes;
         l_ibt->m_cb = this;
         l_ibt->m_logTDRs = m_logTdrs;
         l_ibt->m_DbQueryType = 4;
         g_act.execute(l_ibt);
      }
      else if (0 == strcmp(l_reqType.c_str(), "SHUTDOWN"))
      {
         CLOG(0,0,"SHUTDOWN command received...exiting the application");
         printf("\n\nReceived shutdown command from SMP. Closing the application.\n\n");
         CLOG(0,1,"Received shutdown command from SMP ");
         g_shutdown_received=true;
         g_si.sendSnmpTrap(g_GracefullShutdownTrap, TRAP_TYPE_NORMAL, TRAP_SEVERITY_MAJOR);
         g_ContextMangerObject.terminate();
         sleep(2);
         exitFunc(EXIT_APPLICATION_TYPE_SMP_RECEIVED_SHUTDOWN_COMMAND);
      }
      else
      {
         /*if ( (0 == strcmp((char*)l_reqType.c_str(), "SS_REGISTER")) ||
           (0 == strcmp((char*)l_reqType.c_str(), "SS_ERASE"))
           )
           {
           LLOG(0,1,"SS_REGISTER or SS_ERASE");
           ProvisioningReqMsg *l_newProvReqMsg = new ProvisioningReqMsg;
           l_newProvReqMsg->m_sockFd = l_provReqMsg->m_sockFd;
           l_newProvReqMsg->m_data.assign((char*)l_body.c_str(), strlen((char*)l_body.c_str()));
           l_newProvReqMsg->m_OrigEntityName = l_provReqMsg->m_OrigEntityName;
           l_newProvReqMsg->m_IpAddress = l_provReqMsg->m_IpAddress;
           l_newProvReqMsg->m_DeviceConnectionType = l_provReqMsg->m_DeviceConnectionType;
           LLOG(1,1,"Preparing message with entityname [%s] entitytype [%d]", l_newProvReqMsg->m_OrigEntityName.c_str(), 
           l_newProvReqMsg->m_DeviceConnectionType);

           if(0 == strcmp((char*)l_reqType.c_str(), "SS_REGISTER"))
           {
           g_sc.initiateIndependentContext(this, MAP_OP_CODE_registerSS, l_newProvReqMsg);
           }
           else if(0 == strcmp((char*)l_reqType.c_str(), "SS_ERASE"))
           {
           g_sc.initiateIndependentContext(this, MAP_OP_CODE_eraseSS, l_newProvReqMsg);
           }
           else
           {
           ELOG(0,1,"Unknown request type: %s", (char*)l_reqType.c_str());
           }
           }
           else*/
         {
            logStats((char*)l_reqType.c_str(), 0);
            GenericXmlApiData *l_gxad = new GenericXmlApiData;
            strncpy(l_gxad->m_requestType, (char*)l_reqType.c_str(), MAX_REQUEST_TYPE_LEN);

            if(0 == strcmp(l_gxad->m_requestType, "GET_MODULE_CONFIG_DATA"))
            {
               string l_text;
               char *l_ngDetails = NULL;
               l_ngDetails = g_cr->getConfigPrint(0);
               l_text = l_ngDetails;
               char *l_moduleDetails = NULL;
               g_cr->getModulesPrint(&l_moduleDetails);
               l_text += l_moduleDetails;
               delete[] l_ngDetails;
               delete[] l_moduleDetails;
               sendResponse(l_provReqMsg->m_sockFd, l_provReqMsg->m_DeviceConnectionType, l_provReqMsg->m_OrigEntityName, l_provReqMsg->m_IpAddress, l_transId, l_reqType, 0, "Success", (char*)l_text.c_str());
               return false;
            }
            if(0 == strcmp(l_gxad->m_requestType, "ADD_SUBSCRIBER"))
            {
               char l_arr[50];
               memset(l_arr, '\0', sizeof(l_arr));
#ifdef SunOS
               sprintf(l_arr, "<LIMIT>%d</LIMIT><ACTION>%s</ACTION>", g_SubscriberBase, g_Action);
#else
               if( 0 >= strlen(g_Action) )
                  sprintf(l_arr, "<LIMIT>%d</LIMIT><ACTION>N</ACTION>", g_SubscriberBase);
               else
                  sprintf(l_arr, "<LIMIT>%d</LIMIT><ACTION>%s</ACTION>", g_SubscriberBase, g_Action);

#endif
               l_body += l_arr;
               DLOG(0,0,"changed %s", (char*)l_body.c_str());
            }
            int l_Length = strlen((char*)l_body.c_str());
            if(l_Length > 0)
            {
               l_gxad->m_xmlBody = new char[l_Length + 201];
               snprintf(l_gxad->m_xmlBody,l_Length + 201,"%s",(char*)l_body.c_str());
            }
            char l_ipAddress[15+1];
            memset(l_ipAddress, '\0', sizeof(l_ipAddress));
            char *l_char = NULL;
            l_char = strchr((char*)l_provReqMsg->m_IpAddress.c_str(), ':');
            if(NULL != l_char)
            {
               DLOG(0,1,"here 1");
               strncpy(l_ipAddress, (char*)l_provReqMsg->m_IpAddress.c_str(), strlen((char*)l_provReqMsg->m_IpAddress.c_str()) - strlen(l_char));
            }
            else
            {
               DLOG(0,1,"here 2");
               strcpy(l_ipAddress, (char*)l_provReqMsg->m_IpAddress.c_str());
            }

            sprintf(l_gxad->m_user, "%s:%s", l_ipAddress, (char*)l_provReqMsg->m_OrigEntityName.c_str());
            sprintf(l_gxad->m_ip, "%s", l_ipAddress);
            strncpy(l_gxad->m_transactionRef, (char*)l_transId.c_str(), MAX_TRANS_REF_LEN);
            l_gxad->m_cb = this;
            l_gxad->m_DbQueryType = 2;
            l_gxad->m_logTDRs = m_logTdrs;
            if(1 == m_logTdrs)
            {
               snprintf(l_gxad->m_primary_imsi,sizeof(l_gxad->m_primary_imsi),"%s",l_PrimaryImsi);
            }
            g_act.execute(l_gxad);
            m_responseToBeSent=true;
         }
      }
   }
   else
   {
      ELOG(0,1,"Both char and msg datatypes are null. Ignoring InterModuleData");
      return false;
   }
   return true;
}

bool CtxtOam::postProcessAfterHelper()
{
   if(HELPER_EXECUTION_STATE_INITIAL == m_executionHelper->m_hes)
   {
      sendResponse(((ProvisioningMsg*)(m_imd->m_msgPtr))->m_sockFd, 
            ((ProvisioningMsg*)(m_imd->m_msgPtr))->m_DeviceConnectionType, 
            ((ProvisioningMsg*)(m_imd->m_msgPtr))->m_OrigEntityName, 
            ((ProvisioningMsg*)(m_imd->m_msgPtr))->m_IpAddress, 
            ((ProvisioningMsg*)(m_imd->m_msgPtr))->m_transId, 
            ((ProvisioningMsg*)(m_imd->m_msgPtr))->m_transType, 
            602, "Unable to execute", "");
      return true;
   }
   else if (HELPER_EXECUTION_STATE_RELAY == m_executionHelper->m_hes)
   {
      LLOG(0,0,"Helper is in relay mode");
      return true;
   }
   else if (HELPER_EXECUTION_STATE_FINISHED == m_executionHelper->m_hes)
   {
      //LLOG(0,0,"Helper said FINAL. Output is [%s]", l_executionOutput.c_str());
      sendResponse(((ProvisioningMsg*)(m_imd->m_msgPtr))->m_sockFd, 
            ((ProvisioningMsg*)(m_imd->m_msgPtr))->m_DeviceConnectionType, 
            ((ProvisioningMsg*)(m_imd->m_msgPtr))->m_OrigEntityName, 
            ((ProvisioningMsg*)(m_imd->m_msgPtr))->m_IpAddress, 
            ((ProvisioningMsg*)(m_imd->m_msgPtr))->m_transId, 
            ((ProvisioningMsg*)(m_imd->m_msgPtr))->m_transType, 
            m_executionHelper->m_errCode, 
            (char*)m_executionHelper->m_errDesc.c_str(),
            (char*)m_executionHelper->m_body.c_str());
      //delete(m_executionHelper);    commented for coredump issue
      //m_executionHelper=NULL;
      return true;
   }
}

bool CtxtOam::processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag)
{
   DLOG(0,0,"Start of CtxtOam::processMsg function with flag %d", p_DeleteFlag);

   if(1 == g_IMEI_EncrFlag)
   {
      m_tdr.setInteger(TDR_INDEX_SMSM_GPRS_SM_DEL_OUTCOME,1);
      TLOG(0,0,"IMEI Encyrption Flag enabled");
   }

   if(NULL != m_executionHelper)
   {
      bool l_status = m_executionHelper->processMessageByHelper(p_MsgPtr, p_DeleteFlag);
      return postProcessAfterHelper();
   }

   MapSpecificMsg *l_specMsg = NULL;

   switch (p_MsgPtr->m_MsgType)
   {
      case MSG_TYPE_MAP:
         {
            switch (((MapMsg*)p_MsgPtr)->m_MapMsgType)
            {
               case MAP_MSG_TYPE_COMMON:
                  switch (((MapCommonMsg*)p_MsgPtr)->m_MapCommonMsgType)
                  {
                     case MAP_CMN_OPEN_IND:
                        DLOG(0,0,"MAP_CMN_OPEN_IND received with DlgId [%d], Version [%d]", getInitialRespondingDlgId(),
                              getInitialRespondingVersion());
                        break;

                     case MAP_CMN_DELIMITER_IND:
                        DLOG(0,0,"MAP_CMN_DELIMITER_IND received [%d]", getInitialRespondingDlgId());
                        break;

                     case MAP_CMN_CLOSE_IND:
                        DLOG(0,0,"MAP_CMN_CLOSE_IND received");
                        //DLOG(0,1,"Got a Close. Call flow success.\n");
                        return true;
                        break;

                     case MAP_CMN_U_ABORT_IND:
                        DLOG(0,0,"MAP_CMN_U_ABORT_IND received");
                        break;

                     case MAP_CMN_P_ABORT_IND:
                        DLOG(0,0,"MAP_CMN_P_ABORT_IND received");
                        break;

                     case MAP_CMN_NOTICE_IND:
                        {
                           DLOG(0,0,"MAP_CMN_NOTICE_IND received");
                        }
                        break;

                     default:
                        DLOG(0,0,"Unknown Msg received [%d]", ((MapCommonMsg*)p_MsgPtr)->m_MapCommonMsgType);
                        break;
                  }
                  break;

               case MAP_MSG_TYPE_SPECIFIC:
                  DLOG(0,0,"MAP_MSG_TYPE_SPECIFIC received [%d]", getInitialRespondingDlgId());
                  l_specMsg = (MapSpecificMsg*)p_MsgPtr;

                  switch (((MapSpecificMsg*)p_MsgPtr)->m_MapSpecificEventType)
                  {
                     case MAP_SPEC_EVENT_INDICATION:
                        {
                           DLOG(0,0,"MAP_SPEC_EVENT_INDICATION received");
                        }

                        break;

                     case MAP_SPEC_EVENT_RESULT:
                        {
                           DLOG(0,0,"MAP_SPEC_EVENT_RESULT received");
                        }
                        break;

                     case MAP_SPEC_EVENT_CONFIRMATION:
                        {
                           DLOG(0,0,"MAP_SPEC_EVENT_CONFIRMATION received");
                        }
                        break;

                     case MAP_SPEC_EVENT_USER_ERROR:
                        {
                           DLOG(0,0,"MAP_SPEC_EVENT_USER_ERROR received");
                        }
                        break;

                     case MAP_SPEC_EVENT_PROV_ERROR:
                        {
                           DLOG(0,0,"MAP_SPEC_EVENT_PROV_ERROR received");
                           DLOG(0,0,"Closing the Dialogue");
                           MapCloseReq l_closeReq(((MapSpecificMsg*)p_MsgPtr)->m_UserDlgId);
                           g_sc.sendMsg(this, &l_closeReq);
                        }
                        break;
                     default:
                        ELOG(0,0,"ERROR!! Default received");
                        break;
                  }
                  break;

               default:
                  break;
            }
         }
         break;

      case MSG_TYPE_DB:
         {
            DLOG(0,0,"DB message received");
            switch (((DbQueryMsg*)p_MsgPtr)->m_DbQueryType)
            {
               case 1:
                  {
                     LLOG(0,0,"RetrieveOamTransData response received");

                     RetrieveOamTransData *l_otd = (RetrieveOamTransData *)p_MsgPtr;
                     //char l_tempChar[4000+1];
                     int l_length = 0;
                     if(NULL != l_otd->m_TransXml)
                     {
                        l_length = strlen(l_otd->m_TransXml) + 21; 
                     }
                     else
                     {
                        l_length = 21;
                     }
                     char l_tempChar[l_length+1];
                     memset(l_tempChar, '\0', sizeof(l_tempChar));
                     //sprintf(l_tempChar, "%s:%s", l_otd->m_TransId, l_otd->m_TransXml);
                     snprintf(l_tempChar, sizeof(l_tempChar), "%s:%s", l_otd->m_TransId, (l_otd->m_TransXml == NULL)?"":l_otd->m_TransXml);
                     //sprintf(l_tempChar, "%s", l_otd->m_TransXml);

                     bool l_processTheMessage=true;
                     EMsgType l_msgType=MSG_TYPE_UNKNOWN;
                     l_processTheMessage = whetherToProcess(l_otd->m_TransType, &l_msgType);

                     string l_ApplicationId;

                     if(false == ConfigReader::readString(l_otd->m_TransXml, "APP_ID", l_ApplicationId, 0, 10))
                     {
                        LLOG(0,0,"APP_ID is not Present");
                     }
                     m_tdr.setString(TDR_INDEX_REMOTE_ERR_CODE, (s8*)l_ApplicationId.c_str());
                     m_tdr.setString(TDR_INDEX_OAM_TRANSACTION_ID, l_otd->m_TransId);
                     if(true == l_processTheMessage)
                     {
                        m_tdr.setString(TDR_INDEX_OAM_REQUEST_TYPE, "trigger");
                     }
                     else
                     {
                        m_tdr.setString(TDR_INDEX_OAM_REQUEST_TYPE, "trigger-suppressed");
                     }
                     m_tdr.setInteger(TDR_INDEX_OAM_FREE_FORMAT_DATA, l_otd->m_TransType);
                     m_tdr.setString(TDR_INDEX_OAM_ERROR_DESC, l_otd->m_RowId);
                     //m_tdr.setOriginatingModule("");
                     if(DB_QUERY_RES_SUCCESS == l_otd->m_DbQueryRes)
                     {
                        if(true == l_processTheMessage)
                        {
                           g_sc.initiateIndependentContext(this, (EMapOpCode)(l_otd->m_TransType), l_tempChar, INITIATION_TYPE_IMMEDIATE);
                           GenericXmlApiData *l_gxad = (GenericXmlApiData *)p_MsgPtr;


                           if((1 == g_ConfigData->m_MemcEnableFlag) && ((2 == g_OamConfigReaderObj->m_MemcachedDeleteFlag) || (3 == g_OamConfigReaderObj->m_MemcachedDeleteFlag)))
                           {
                              if((l_otd->m_TransType == 317) || (l_otd->m_TransType == 319) || (l_otd->m_TransType == 316))
                              {
                                 LLOG(0,0,"MmeMemcached triggers to be stopped .. as GenerateXml has MME trigger");
                                 DLOG(0,0,"TransType [%d]",l_otd->m_TransType);

                                 char l_primary_imsi_memc[15+1];
                                 if(l_otd->m_TransType == 316)
                                 {
                                    if(false == ConfigReader::readString(l_otd->m_TransXml, "ULRIMSI", (char*)l_primary_imsi_memc, 0, 15))
                                    {
                                       ELOG(0,0,"PRIMARY_IMSI is not present in the xml for soft delete");
                                       return false;
                                    }
                                 }
                                 else
                                 {
                                    if(false == ConfigReader::readString(l_otd->m_TransXml, "PRIMARY_IMSI", (char*)l_primary_imsi_memc, 0, 15))
                                    {
                                       ELOG(0,0,"PRIMARY_IMSI is not present in the xml for soft delete");
                                       return false;
                                    }
                                 }

                                 SoftDeleteMemcQuery *l_delMemcQuery;
                                 if( strlen(l_primary_imsi_memc) > 1 )
                                 {
                                    DLOG(0,0,"primary_imsi [%s]",l_primary_imsi_memc);
                                    l_delMemcQuery = new SoftDeleteMemcQuery();
                                    snprintf(l_delMemcQuery->m_primaryImsi,sizeof(l_delMemcQuery->m_primaryImsi),"%s",l_primary_imsi_memc);

                                    DLOG(0,0,"ImsiPresence is true");
                                    l_delMemcQuery->m_Mcb = this;
                                    l_delMemcQuery->m_MemcQueryType = MEMC_QUERY_TYPE_DELETE;
                                    l_delMemcQuery->m_dataMemC = true;
                                    g_MemcActObj.execute(l_delMemcQuery);
                                 }  
                                 else
                                 {
                                    LLOG(0,0,"Unable to Soft Delete as Primary Imsi in the xml is NULL");
                                 }

                              }
                           }
                           else
                           {
                              LLOG(0,0,"Memcached Disabled NgConfigMemcValue[%d] OamMemcValue[%d]",g_ConfigData->m_MemcEnableFlag,g_OamConfigReaderObj->m_MemcachedDeleteFlag);
                           }
                        }
                        else
                        {
                           m_tdr.setInteger(TDR_INDEX_OAM_ERROR_CODE, 100);
                           DLOG(0,0,"RetrieveOamTransData failed");
                        }
                     }
                  }
                  break;

               case 2:
                  {
                     LLOG(0,1,"GenericXmlApiData response received");
                     GenericXmlApiData *l_gxad = (GenericXmlApiData *)p_MsgPtr;
                     bool l_getSubsInfo = false;
                     //4020 BEGIN
                     //if((1 == g_IMEI_EncrFlag) && (NULL == strstr(l_gxad->m_user,"TCBOS"))) // "Commented for HLR 5.0.3.0 PID 47726"
                        
                     //6.4.1.0 Start
                     LLOG(0,0,"DBRES: OAM Statistics Info[%s]",l_gxad->m_StatsInfo_OUT);
                     if(strlen(l_gxad->m_StatsInfo_OUT) > 5)
                     {
                        m_tdr.setString(TDR_INDEX_NOR_ALERT_REASON,l_gxad->m_StatsInfo_OUT);//140
                        vector<string> l_statsInfo;
                        char* l_token = strtok(l_gxad->m_StatsInfo_OUT,"-");
                        while(l_token != NULL)
                        {
                           l_statsInfo.push_back(string(l_token));
                           l_token = strtok(NULL, "-");
                        }
                        vector<string>::iterator l_itr;
                        for(l_itr = l_statsInfo.begin(); l_itr != l_statsInfo.end(); l_itr++)
                        {
                           DLOG(0,0,"Trying to Log Statistics[%s]",(char*)(*l_itr).c_str());
                           if(((CommonData*)g_prov)->m_statsData.find(*l_itr) != ((CommonData*)g_prov)->m_statsData.end())
                           {
                              map<string,int>::iterator l_mapitr = g_globalMap.find((*l_itr).c_str());
                              if(l_mapitr != g_globalMap.end())
                              {
                                 DLOG(0,0,"Logging Statistics[%s]",(char*)(l_mapitr->first).c_str());
                                 HLRStatisticsInitializer::logStatistics(l_mapitr->second);
                              }

                           }
                        }
                     }
                     //6.4.1.0 End
                     
                     if(NULL == strstr(l_gxad->m_user,"TCBOS"))
                     {
                        DLOG(0,0,"User is not TCBOS");

                        if( (0 == strcmp(l_gxad->m_requestType, "GET_SUBSCRIBER_INFO")) || 
                              (0 == strcmp(l_gxad->m_requestType, "GET_SUBSCRIBER_DATA")) ||
                              (0 == strcmp(l_gxad->m_requestType, "GET_LOCATION_INFO")) ||
                              (0 == strcmp(l_gxad->m_requestType, "GET_LOCATION_DATA")) )
                        {
                           l_getSubsInfo = true;
                           DLOG(0,0,"API is[%s]",l_gxad->m_requestType);
                           if(DB_QUERY_RES_SUCCESS == l_gxad->m_DbQueryRes)
                           {
                              char l_imei[40];
                              memset(l_imei,'\0',sizeof(l_imei));
                              if (false == ConfigReader::readString(l_gxad->m_channelResponseXml, "IMEISV", l_imei,0,40))
                              {
                                 TLOG(0,0,"Unable to read the IMEISV in genericxml response message");
                              }
                              else
                              {   
                                 if( strlen(l_imei) > 18 )
                                 {
                                    if( true == Copy_Decrypt_IMEI(l_imei))
                                    {
                                       string l_output = l_gxad->m_channelResponseXml;
                                       replaceValAtTag(l_gxad->m_channelResponseXml, "IMEISV", l_imei,(char*)l_output.c_str());                           
                                       snprintf(l_gxad->m_channelResponseXml,l_output.length()+1,"%s",(char*)l_output.c_str());
                                    }
                                 }
                                 memset(l_imei,'\0',sizeof(l_imei));
                              }
                              if (false == ConfigReader::readString(l_gxad->m_channelResponseXml, "IMEI", l_imei,0,40))
                              {
                                 TLOG(0,0,"Unable to read the IMEI in genericxml response message");
                              }
                              else
                              {   
                                 if( strlen(l_imei) > 18 )
                                 {
                                    if( true == Copy_Decrypt_IMEI(l_imei))
                                    {
                                       string l_output = l_gxad->m_channelResponseXml;
                                       replaceValAtTag(l_gxad->m_channelResponseXml, "IMEI", l_imei, (char*)l_output.c_str());                           
                                       snprintf(l_gxad->m_channelResponseXml,l_output.length()+1,"%s",(char*)l_output.c_str());
                                    }
                                 }
                              }
                           }
                        }
                        /*else if((0 == strcmp(l_gxad->m_requestType, "ALLOCATE_IMSI")) || (0 == strcmp(l_gxad->m_requestType, "RE_SEND_SINGLE_IMSI_OTA_TRIGGER")) || (0 == strcmp(l_gxad->m_requestType, "UPDATE_PROV_STATUS_MNO_UPD")))
                          {
                           DLOG(0,0,"API is[%s]",l_gxad->m_requestType);
                           char l_tempData[200+1];
                           memset(l_tempData,'\0',sizeof(l_tempData));
                           snprintf(l_tempData, sizeof(l_tempData), "%s|", l_gxad->m_freeFormatTdrData);
                           char tempBuff[10][20];
                           memset(tempBuff,'\0',sizeof(tempBuff));
                           tokenize1(l_tempData, (char*)tempBuff, 20, '|', false, false, 10);
                           TLOG(0,1,"tokenized data: [%s] [%s] [%s] [%s] [%s] [%s] [%s] [%s] [%s]", tempBuff[0], tempBuff[1], tempBuff[2], tempBuff[3], tempBuff[4], tempBuff[5], tempBuff[6], tempBuff[7], tempBuff[8]);
                           if(strlen(tempBuff[2]) > 0)
                           {
                              m_tdr.setString(TDR_INDEX_ALTFLAG_CAMPID,l_gxad->m_freeFormatTdrData);
                              m_tdr.setString(TDR_INDEX_ALT_PRIMARYIMSI,tempBuff[2]);
                              m_tdr.setString(TDR_INDEX_HLR_RESRV2,tempBuff[3]);
                              char l_temp[30];
                              memset(l_temp,'\0',sizeof(l_temp));
                              snprintf(l_temp,sizeof(l_temp),"%s|%s|%s|%s",tempBuff[5], tempBuff[6], tempBuff[7], tempBuff[2]);
                              m_tdr.setString(TDR_INDEX_HLR_RESRV10,l_temp);
                              if((1 == atoi(tempBuff[5])) && (0 == atoi(tempBuff[7])))
                              {
                                 m_tdr.setString(TDR_INDEX_ULR_RAT_TYPE,"1");//122
                                 if(0 == strcmp(l_gxad->m_requestType, "ALLOCATE_IMSI"))
                                 {
                                    LLOG(0,0,"OAM: Stats written ... Interested for MNO Provisioning");
                                    map<string,int>::iterator l_itr = g_globalMap.find("InterestedForMnoProvisioning");
                                    if(l_itr != g_globalMap.end())
                                    {
                                       HLRStatisticsInitializer::logStatistics(l_itr->second);
                                    }
                                 }
                              }
                           }
                        }*/
                     }
                     else if( (0 == strcmp(l_gxad->m_requestType, "GET_SUBSCRIBER_INFO")) || 
                           (0 == strcmp(l_gxad->m_requestType, "GET_SUBSCRIBER_DATA")) ||
                           (0 == strcmp(l_gxad->m_requestType, "GET_LOCATION_INFO")) ||
                           (0 == strcmp(l_gxad->m_requestType, "GET_LOCATION_DATA")) )
                     {
                        DLOG(0,0,"User is TCBOS and get subscriber info request model");
                        l_getSubsInfo = true;
                     }
                     // 4020 END
                     int l_BlackListFlag = 0;
                     if( (0 == strcmp(l_gxad->m_requestType, "BLACKLIST_IMEI")) ||
                           (0 == strcmp(l_gxad->m_requestType, "UNBLACKLIST_IMEI")) ||
                           (0 == strcmp(l_gxad->m_requestType, "GET_IMEI_BLACKLIST_DETAILS")) )
                     {
                        l_BlackListFlag = 1;
                     }
                     if(0 == l_BlackListFlag)
                     {
                        m_tdr.setChar(TDR_INDEX_REQUEST_TYPE,          l_gxad->m_subs_identity_flag);
                     }

                     if (l_gxad->m_logTDRs != 1)
                     {
                        m_tdr.setString(TDR_INDEX_REQUEST_IMSI,        l_gxad->m_subs_identity_imsi);
                        m_tdr.setString(TDR_INDEX_REQUEST_MSISDN,      l_gxad->m_subs_identity_msisdn);

                        if(0 != strcmp(l_gxad->m_requestType, "ALLOCATE_IMSI"))
                        {
                           m_tdr.setString(TDR_INDEX_OAM_FREE_FORMAT_DATA,l_gxad->m_freeFormatTdrData);
                        }
                        m_tdr.setString(TDR_INDEX_MM_PRIMARY_IMSI,     l_gxad->m_primary_imsi);
                        m_tdr.setString(TDR_INDEX_MM_PRIMARY_MSISDN,   l_gxad->m_primary_msisdn);
                        m_tdr.setString(TDR_INDEX_ACCOUNT_ID,          l_gxad->m_account_id);
                        m_tdr.setString(TDR_INDEX_ICC_ID,              l_gxad->m_icc_id);
                        m_tdr.setString(TDR_INDEX_IMEI,                l_gxad->m_imei);

                        if(0 != strcmp(l_gxad->m_requestType, "ALLOCATE_IMSI"))
                        {
                           m_tdr.setString(TDR_INDEX_ALT_PRIMARYIMSI,l_gxad->m_AltImsi);
                        }
                        m_tdr.setString(TDR_INDEX_ALT_PRIMARYIMSI2,l_gxad->m_AltNewImsi);
                        LLOG(0,0,"ALT_PRIM_IMSI[%s], ALT_PRIM_IMSI2[%s]",l_gxad->m_AltImsi, l_gxad->m_AltNewImsi);
                     }
                     if(DB_QUERY_RES_SUCCESS == l_gxad->m_DbQueryRes)
                     {
                        if(0 == strcmp(l_gxad->m_requestType, "MODIFY_SUBSCRIBER_DATA"))
                        {
                           string l_DestAlocType;
                           if (false == ConfigReader::readString(l_gxad->m_xmlBody, "DEST_ALLOC_TYPE",l_DestAlocType,1,1))
                           {
                              TLOG(0,0,"Invalid DEST_ALLOC_TYPE in MODIFY_SUBSCRIBER_DATA, not logging DEST_ALLOC_TYPE in TDR");
                           }
                           else
                           {
                              TLOG(0,0,"Logging DEST_ALLOC_TYPE[%s] in TDR",l_DestAlocType.c_str());
                              m_tdr.setString(TDR_INDEX_OAM_DEST_ALOC_TYPE,(char*)l_DestAlocType.c_str());
                           }
                        }
                        else if((0 == strcmp(l_gxad->m_requestType, "ALLOCATE_IMSI")) || (0 == strcmp(l_gxad->m_requestType, "ROAM_CAMP_IMSI_OTA_TRIGGER")) || (0 == strcmp(l_gxad->m_requestType, "UPDATE_MNO_STATUS_ACTIVATION")))
                        {
                           DLOG(0,0,"API is[%s]",l_gxad->m_requestType);
                           char l_tempData[200+1];
                           memset(l_tempData,'\0',sizeof(l_tempData));
                           snprintf(l_tempData, sizeof(l_tempData), "%s|", l_gxad->m_freeFormatTdrData);
                           char tempBuff[10][20];
                           memset(tempBuff,'\0',sizeof(tempBuff));
                           tokenize1(l_tempData, (char*)tempBuff, 20, '|', false, false, 10);
                           TLOG(0,1,"tokenized data: [%s] [%s] [%s] [%s] [%s] [%s] [%s] [%s] [%s]", tempBuff[0], tempBuff[1], tempBuff[2], tempBuff[3], tempBuff[4], tempBuff[5], tempBuff[6], tempBuff[7], tempBuff[8]);
                           if(strlen(tempBuff[2]) > 0)
                           {
                              if(strlen((char*)l_gxad->m_freeFormatTdrData) > 0)
                              {
                                 if(0 != atoi(tempBuff[2]))
                                 {
                                    DLOG(0,0,"Stats written ... Interested for Alternate Imsi / Dual Imsi OTA trigger");
                                    map<string,int>::iterator l_itr = g_globalMap.find("InterestedForAltOrDualImsiTrigger");
                                    if(l_itr != g_globalMap.end())
                                    {
                                       HLRStatisticsInitializer::logStatistics(l_itr->second);
                                    }
                                 }
                              }


                              m_tdr.setString(TDR_INDEX_ALTFLAG_CAMPID,l_gxad->m_freeFormatTdrData);
                              m_tdr.setString(TDR_INDEX_ALT_PRIMARYIMSI,tempBuff[2]);
                              m_tdr.setString(TDR_INDEX_HLR_RESRV2,tempBuff[3]);
                              char l_temp[30];
                              memset(l_temp,'\0',sizeof(l_temp));
                              snprintf(l_temp,sizeof(l_temp),"%s|%s|%s|%s",tempBuff[5], tempBuff[6], tempBuff[7], tempBuff[2]);
                              m_tdr.setString(TDR_INDEX_HLR_RESRV10,l_temp);
                              if((1 == atoi(tempBuff[5])) && (0 == atoi(tempBuff[7])))
                              {
                                 if(0 != strcmp(l_gxad->m_requestType, "ALLOCATE_IMSI"))
                                 {
                                    m_tdr.setString(TDR_INDEX_ULR_RAT_TYPE,"1");//122
                                 }
                              }
                           }
                           if(0 == strcmp(l_gxad->m_requestType, "UPDATE_MNO_STATUS_ACTIVATION"))
                           {
                              LLOG(0,0,"OAM: Stats written ... Interested for MNO Provisioning");
                              map<string,int>::iterator l_itr = g_globalMap.find("InterestedForMnoProvisioning");
                              if(l_itr != g_globalMap.end())
                              {
                                 HLRStatisticsInitializer::logStatistics(l_itr->second);
                              }
                           }
                           if(0 == strcmp(l_gxad->m_requestType, "ROAM_CAMP_IMSI_OTA_TRIGGER"))
                           {
                              DLOG(0,0,"Stats written ... Interested for Roaming Campaign OTA trigger");
                              map<string,int>::iterator l_itr = g_globalMap.find("InterestedForRoamingCampaignOtaTrigger");
                              if(l_itr != g_globalMap.end())
                              {
                                 HLRStatisticsInitializer::logStatistics(l_itr->second);
                              }
                           }
                        }
                     }

                     if(l_gxad->m_network_id > 0)
                     {
                        m_tdr.setInteger(TDR_INDEX_MM_NETWORK_ID,      l_gxad->m_network_id);
                     }
                     m_tdr.setRemoteAddrSsn(l_gxad->m_subs_data_count);

                     DLOG(1,0,"BEFORE STRLEN NULL PTR");

                     LLOG(1,0,"DBLOG: %s", (l_gxad->m_logMsg == NULL)?"":l_gxad->m_logMsg);

                     if(DB_QUERY_RES_SUCCESS == l_gxad->m_DbQueryRes)
                     {
                        LLOG(0,0,"GenericXmlApiData successfull. Count of oss triggers: %d", l_gxad->m_ossTriggerDataCount);
                        logStats(l_gxad->m_requestType, 1);

                        for (int l_i=0; l_i<l_gxad->m_ossTriggerDataCount; l_i++)
                        {
                           TLOG(0,0,"Pushing the row id [%s] into queue", l_gxad->m_ossTriggerDataArray[l_i].m_rowId);
                           g_sc.initiateIndependentContext(this, MAP_OP_CODE_dummy_1, (char*)l_gxad->m_ossTriggerDataArray[l_i].m_rowId, INITIATION_TYPE_TARDILY);
                        }
                     }
                     else
                     {
                        CLOG(0,0,"GenericXmlApiData failed");
                     }

                     LLOG(0,0,"m_ossHelperOpCode %d", l_gxad->m_ossHelperOpCode);
                     if( (l_gxad->m_ossHelperOpCode > 0) &&
                           true )
                        //      (DB_QUERY_RES_SUCCESS == l_gxad->m_DbQueryRes) )
                     {
                        LLOG(0,0,"Helper Opcode from DB. So initiating Helper Context for help..");
                        m_executionHelper = getExecutionHelper(l_gxad->m_ossHelperOpCode);
                        if(NULL == m_executionHelper)
                        {
                           sendResponse(((ProvisioningMsg*)(m_imd->m_msgPtr))->m_sockFd, 
                                 ((ProvisioningMsg*)(m_imd->m_msgPtr))->m_DeviceConnectionType, 
                                 ((ProvisioningMsg*)(m_imd->m_msgPtr))->m_OrigEntityName, 
                                 ((ProvisioningMsg*)(m_imd->m_msgPtr))->m_IpAddress, 
                                 ((ProvisioningMsg*)(m_imd->m_msgPtr))->m_transId, 
                                 ((ProvisioningMsg*)(m_imd->m_msgPtr))->m_transType, 
                                 601, "No operation found to execute", "");
                        }
                        else
                        {
                           DLOG(0,0,"Found the Helper Context for execution. Calling the respective processMsg");
                           m_executionHelper->m_mainContext=this;
                           bool l_execRetType = m_executionHelper->startProcessingByHelper(l_gxad, p_DeleteFlag);
                           return postProcessAfterHelper();
                        }
                     }

                     if (true == m_responseToBeSent)
                     {
                        ProvisioningReqMsg *l_provReqMsg= (ProvisioningReqMsg*)(m_imd->m_msgPtr);

                        //printf("\nTrans type: [%s]", (char*)(l_provReqMsg->m_transType.c_str()));
                        //printf("\nTrans data: [%s]", (char*)(l_provReqMsg->m_data.c_str()));

                        if ( (l_gxad->m_ossContinueOpCode > 0) &&
                              (DB_QUERY_RES_SUCCESS == l_gxad->m_DbQueryRes) )
                        {
                           TLOG(0,1,"continuing with op code %d", l_gxad->m_ossContinueOpCode);
                           ProvisioningReqMsg *l_newProvReqMsg = new ProvisioningReqMsg;
                           l_newProvReqMsg->m_sockFd = l_provReqMsg->m_sockFd;
                           l_newProvReqMsg->m_data.assign(l_provReqMsg->m_data);
                           l_newProvReqMsg->m_data.append("<RESPONSE>");
                           l_newProvReqMsg->m_data.append((NULL == l_gxad->m_channelResponseXml)?"":l_gxad->m_channelResponseXml);

                           map<int, HlrNetworks* > :: iterator l_HlrNetworksDetailsIter;
                           l_HlrNetworksDetailsIter = g_spdPtr->m_HlrNetworks.find(l_gxad->m_network_id);
                           if(l_HlrNetworksDetailsIter !=  g_spdPtr->m_HlrNetworks.end())
                           {
                              DLOG(0,0,"### m_NotifyCellId: %d ####",(l_HlrNetworksDetailsIter->second)->m_NotifyCellId);
                              if( (false == l_getSubsInfo) && (1 == (l_HlrNetworksDetailsIter->second)->m_NotifyCellId) )
                              {
                                 l_newProvReqMsg->m_data.append("<FREE_FORMAT_DATA>");
                                 l_newProvReqMsg->m_data.append(l_gxad->m_freeFormatTdrData);
                                 l_newProvReqMsg->m_data.append("</FREE_FORMAT_DATA>");

                                 int l_temp = l_gxad->m_network_id;
                                 char l_NetworkId[3];

                                 memset(l_NetworkId,'\0',sizeof(l_NetworkId));
                                 sprintf(l_NetworkId,"%d",l_temp);

                                 l_newProvReqMsg->m_data.append("<NETWORK_ID>");
                                 l_newProvReqMsg->m_data.append(l_NetworkId);
                                 l_newProvReqMsg->m_data.append("</NETWORK_ID>");
                                 l_newProvReqMsg->m_data.append("<NOTIFY_CELLID_FLAG>");
                                 l_newProvReqMsg->m_data.append("1");
                                 l_newProvReqMsg->m_data.append("</NOTIFY_CELLID_FLAG>");
                              }
                           }
                           else
                           {
                              CLOG(0,0,"HlrNetworks Map iterator found NULL for Notify Cell Id");
                           }

                           l_newProvReqMsg->m_data.append("</RESPONSE>");
                           l_newProvReqMsg->m_OrigEntityName = l_provReqMsg->m_OrigEntityName;
                           l_newProvReqMsg->m_IpAddress = l_provReqMsg->m_IpAddress;
                           l_newProvReqMsg->m_DeviceConnectionType = l_provReqMsg->m_DeviceConnectionType;
                           LLOG(1,1,"Continuing with op code %d. Preparing message with entityname [%s] entitytype [%d] [%s]", 
                                 l_gxad->m_ossContinueOpCode,
                                 l_newProvReqMsg->m_OrigEntityName.c_str(), 
                                 l_newProvReqMsg->m_DeviceConnectionType, (char*)l_newProvReqMsg->m_data.c_str());

                           if(false == l_getSubsInfo)
                           {
                              DLOG(0,0,"Sendresponse called socket closed for other than subscriber info response");
                              sendResponse(((ProvisioningMsg*)(m_imd->m_msgPtr))->m_sockFd,
                                    ((ProvisioningMsg*)(m_imd->m_msgPtr))->m_DeviceConnectionType,
                                    ((ProvisioningMsg*)(m_imd->m_msgPtr))->m_OrigEntityName,
                                    ((ProvisioningMsg*)(m_imd->m_msgPtr))->m_IpAddress,
                                    ((ProvisioningMsg*)(m_imd->m_msgPtr))->m_transId,
                                    ((ProvisioningMsg*)(m_imd->m_msgPtr))->m_transType,
                                    l_gxad->m_procErrorCode,
                                    l_gxad->m_procErrorMessage,
                                    NULL);
                           }
                           g_sc.initiateIndependentContext(this, (EMapOpCode)l_gxad->m_ossContinueOpCode, l_newProvReqMsg);
                        }
                        else
                        {
                           if (
                                 (0 == strcmp( (char*)((ProvisioningMsg*)(m_imd->m_msgPtr))->m_transType.c_str(), "GET_DETAILS"))  &&
                                 (0 == l_gxad->m_procErrorCode)
                              )
                           {
                              char l_oamTransChar[200+1];
                              int l_currentOamTransactions = g_OamTransactionsList->size();
                              if(l_currentOamTransactions > 4*MAX_TRANSACTIONS)
                              {
                                 snprintf(l_oamTransChar, sizeof(l_oamTransChar), 
                                       "<ALLOW_TRANSACTION>N</ALLOW_TRANSACTION><QUEUE_SIZE>%d</QUEUE_SIZE><MAX_QUEUE_SIZE>%d</MAX_QUEUE_SIZE>",
                                       l_currentOamTransactions, 4*MAX_TRANSACTIONS);
                              }
                              else
                              {
                                 snprintf(l_oamTransChar, sizeof(l_oamTransChar), 
                                       "<ALLOW_TRANSACTION>Y</ALLOW_TRANSACTION><QUEUE_SIZE>%d</QUEUE_SIZE><MAX_QUEUE_SIZE>%d</MAX_QUEUE_SIZE>",
                                       l_currentOamTransactions, 4*MAX_TRANSACTIONS);
                              }

                              char l_LimitChar[500+1];
                              memset(l_LimitChar, '\0', sizeof(l_LimitChar));
#ifdef SunOS
                              snprintf(l_LimitChar, sizeof(l_LimitChar), 
                                    "<LIMIT>%d</LIMIT><ACTION>%s</ACTION>%s", 
                                    g_SubscriberBase, g_Action, l_oamTransChar);
#else
                              if( 0 >= strlen(g_Action) )
                                 sprintf(l_LimitChar, "<LIMIT>%d</LIMIT><ACTION>N</ACTION>%s", g_SubscriberBase, l_oamTransChar);
                              else
                                 sprintf(l_LimitChar, "<LIMIT>%d</LIMIT><ACTION>%s</ACTION>%s", g_SubscriberBase, g_Action, l_oamTransChar);
#endif
                              strcat(l_gxad->m_channelResponseXml, l_LimitChar);
                           }
                           else if (
                                 (0 == strcmp( (char*)((ProvisioningMsg*)(m_imd->m_msgPtr))->m_transType.c_str(), "VALIDATE_INSTANCE_CONFIGURATION")) &&
                                 (0 == l_gxad->m_procErrorCode)
                                 )
                           {
                              ProvisioningReqMsg *l_provReqMsg = (ProvisioningReqMsg*)m_imd->m_msgPtr;
                              string l_temp_trans_id = ConfigReader::readValue(l_provReqMsg->m_data, "TEMP_TRANS_ID");
                              //TEMP_TRANS_ID
                              //MODULE
                              ReloadConfigValues *l_rcv = new ReloadConfigValues;
                              l_rcv->m_cb = this;
                              l_rcv->m_DbQueryType = 6;
                              snprintf(l_rcv->m_tempTransId, sizeof(l_rcv->m_tempTransId), "%s", (char*)l_temp_trans_id.c_str());
                              g_act.execute(l_rcv);
                              return true;

                           }

                           sendResponse(((ProvisioningMsg*)(m_imd->m_msgPtr))->m_sockFd, 
                                 ((ProvisioningMsg*)(m_imd->m_msgPtr))->m_DeviceConnectionType, 
                                 ((ProvisioningMsg*)(m_imd->m_msgPtr))->m_OrigEntityName, 
                                 ((ProvisioningMsg*)(m_imd->m_msgPtr))->m_IpAddress, 
                                 ((ProvisioningMsg*)(m_imd->m_msgPtr))->m_transId, 
                                 ((ProvisioningMsg*)(m_imd->m_msgPtr))->m_transType, 
                                 l_gxad->m_procErrorCode, 
                                 l_gxad->m_procErrorMessage, 
                                 (NULL == l_gxad->m_channelResponseXml)?NULL:l_gxad->m_channelResponseXml);
                        }
                     }
                     else
                     {
                        m_tdr.setInteger(TDR_INDEX_OAM_ERROR_CODE, l_gxad->m_procErrorCode);
                        m_tdr.setString(TDR_INDEX_OAM_ERROR_DESC, l_gxad->m_procErrorMessage);
                     }

                     if(strlen(l_gxad->m_trapCode) > 0)
                     {
                        TLOG(0,0,"Trap Code is [%s]", l_gxad->m_trapCode);
                        if(NULL != g_prov)
                        {
                           int l_trapInt = ((CommonData*)g_prov)->getTrapInt(l_gxad->m_trapCode);
                           if(l_trapInt >= 0)
                           {
                              if(strlen(l_gxad->m_trapDesc)> 0)
                              {
                                 g_si.sendSnmpTrap(l_trapInt, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL, l_gxad->m_trapDesc);
                              }
                              else
                              {
                                 g_si.sendSnmpTrap(l_trapInt, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL);
                              }
                           }
                           else
                           {
                              ELOG(0,0,"Unable to get the integer for the trap [%s]", l_gxad->m_trapCode);
                           }
                        }
                        else
                        {
                           WLOG(0,0,"g_prov is null. not sending trap");
                        }
                     }


                     if(DB_QUERY_RES_SUCCESS == l_gxad->m_DbQueryRes)
                     {
                        if((1 == g_ConfigData->m_MemcEnableFlag) && ((1 == g_OamConfigReaderObj->m_MemcachedDeleteFlag) || (3 == g_OamConfigReaderObj->m_MemcachedDeleteFlag))) 
                        {
                           if(
                                 ( (0 == strcmp(l_gxad->m_requestType, "REMOVE_SUBSCRIBER")) ||
                                   (0 == strcmp(l_gxad->m_requestType,"SCHEDULE_REMOVE_SUBSCRIBER")) ||
                                   (0 == strcmp(l_gxad->m_requestType, "CHANGE_AUC_TEMPLATE")) ||
                                   (0 == strcmp(l_gxad->m_requestType, "MODIFY_AUC_PARAMS")) ) 
                             )
                           {
                              LLOG(0,0,"Got RequestType[%s]: Marking as deleted from Memcached", l_gxad->m_requestType);
                              if(strlen(l_gxad->m_primary_imsi) > 1)
                              {
                                 SoftDeleteMemcQuery *l_delMemcQuery =  new SoftDeleteMemcQuery();
                                 snprintf(l_delMemcQuery->m_primaryImsi,sizeof(l_delMemcQuery->m_primaryImsi),"%s",l_gxad->m_primary_imsi);
                                 l_delMemcQuery->m_Mcb = this;
                                 l_delMemcQuery->m_MemcQueryType = MEMC_QUERY_TYPE_DELETE;
                                 g_MemcActObj.execute(l_delMemcQuery);
                              }
                              else
                              {
                                 LLOG(0,0,"Unable to Delete RequestType[%s] as Primary Imsi is NULL",l_gxad->m_requestType);
                              }                            
                           }
                           else if(
                                 (0 == strcmp(l_gxad->m_requestType, "CHANGE_SIM")) ||
                                 (0 == strcmp(l_gxad->m_requestType, "CHANGE_IMSI")) 
                                 )
                           {
                              LLOG(0,0,"Got RequestType[%s]: Marking as deleted from Memcached", l_gxad->m_requestType);
                              DLOG(0,0,"PrimaryImsi[%s]",l_gxad->m_subs_identity_imsi);
                              if(strlen(l_gxad->m_subs_identity_imsi) > 1)
                              {
                                 SoftDeleteMemcQuery *l_delMemcQuery =  new SoftDeleteMemcQuery();
                                 snprintf(l_delMemcQuery->m_primaryImsi,sizeof(l_delMemcQuery->m_primaryImsi),"%s",l_gxad->m_subs_identity_imsi);
                                 l_delMemcQuery->m_Mcb = this;
                                 l_delMemcQuery->m_MemcQueryType = MEMC_QUERY_TYPE_DELETE;
                                 g_MemcActObj.execute(l_delMemcQuery);
                              }
                              else
                              {
                                 LLOG(0,0,"Unable to Delete RequestType[%s] as Primary Imsi is NULL",l_gxad->m_requestType);
                              }                            
                           }


                           /*if(true == l_gxad->m_MmeMemcached)
                             {
                             SoftDeleteMemcQuery *l_delMemcQuery;
                             bool l_ImsiPresence = false;
                             if(
                             (0 != strcmp(l_gxad->m_requestType, "CHANGE_SIM")) ||
                             (0 != strcmp(l_gxad->m_requestType, "CHANGE_IMSI")) 
                             )
                             {
                             if(strlen(l_gxad->m_primary_imsi) > 1)
                             {
                             l_delMemcQuery = new SoftDeleteMemcQuery();
                             snprintf(l_delMemcQuery->m_primaryImsi,sizeof(l_delMemcQuery->m_primaryImsi),"%s",l_gxad->m_primary_imsi);
                             l_ImsiPresence = true;
                             }
                             }
                             else
                             {
                             if(strlen(l_gxad->m_subs_identity_imsi) > 1)
                             {
                             l_delMemcQuery = new SoftDeleteMemcQuery();
                             snprintf(l_delMemcQuery->m_primaryImsi,sizeof(l_delMemcQuery->m_primaryImsi),"%s",l_gxad->m_subs_identity_imsi);
                             l_ImsiPresence = true;
                             }
                             }
                             if(true == l_ImsiPresence)
                             { 
                             l_delMemcQuery->m_Mcb = this;
                             l_delMemcQuery->m_MemcQueryType = MEMC_QUERY_TYPE_DELETE;
                             l_delMemcQuery->m_dataMemC = true;
                             g_MemcActObj.execute(l_delMemcQuery);
                             }  
                             else
                             {
                             LLOG(0,0,"Unable to Delete RequestType[%s] as Primary Imsi is NULL",l_gxad->m_requestType);
                             }
                             }
                             */
                        }
                        else
                        {
                           LLOG(0,0,"Memcached Disabled NgConfigMemcValue[%d] OamMemcValue[%d]",g_ConfigData->m_MemcEnableFlag,g_OamConfigReaderObj->m_MemcachedDeleteFlag);
                        }
                     }

                     TLOG(0,1,"GenericXmlApiData after sendResponse done");
                  }
                  break;

               case 3:
                  {
                     LLOG(0,0,"RetrieveOamBulkTrans response received");
                     RetrieveOamBulkTrans *l_robt = (RetrieveOamBulkTrans *)p_MsgPtr;

                     if(DB_QUERY_RES_SUCCESS == l_robt->m_DbQueryRes)
                     {
                        LLOG(0,0,"RetrieveOamBulkTrans successfull. Count of bulk trans: %d", l_robt->m_outputList.size());

                        m_tdr.setString(TDR_INDEX_OAM_REQUEST_TYPE, "bulkReload");
                        m_tdr.setInteger(TDR_INDEX_OAM_FREE_FORMAT_DATA, l_robt->m_outputList.size());

                        list<char*>::iterator l_itr;

                        for (l_itr=l_robt->m_outputList.begin(); l_itr != l_robt->m_outputList.end(); l_itr++)
                        {
                           TLOG(0,0,"RetrieveOamBulkTrans Pushing the row id [%s] into queue", *l_itr);
                           g_sc.initiateIndependentContext(this, MAP_OP_CODE_dummy_1, *l_itr, INITIATION_TYPE_TARDILY);
                        }
                     }
                     else
                     {
                        CLOG(0,0,"RetrieveOamBulkTrans failed");
                     }
                  }
                  break;

               case 4:
                  {
                     LLOG(0,0,"InsertBulkTransId response received");
                     InsertBulkTransId *l_ibt = (InsertBulkTransId *)p_MsgPtr;

                     if(DB_QUERY_RES_SUCCESS == l_ibt->m_DbQueryRes)
                     {
                        char *ptr1, *ptr2;
                        ptr1=ptr2=NULL;
                        ptr1 = ptr2 = (char*)m_oam_transactions.c_str();
                        ptr2++;
                        int l_totalRequests=0;
                        while(*ptr2 != '\0')
                        {
                           if('^' == *ptr2)
                           {
                              if(ptr2-ptr1 == 1)
                              {
                                 TLOG(0,1,"Breaking from the loop");
                                 break;
                              }
                              else
                              {
                                 l_totalRequests++;
                                 char l_requestXml[700];
                                 memset(l_requestXml, '\0', sizeof(l_requestXml));
                                 strncpy(l_requestXml, ptr1+1, ptr2-ptr1-1);
                                 LLOG(0,1,"Got a MBOS/SPA request to process [%s]", l_requestXml);


                                 char l_totalData[1000];
                                 memset(l_totalData, '\0', sizeof(l_totalData));
                                 if(l_ibt->m_logTDRs!= 1) 
                                 {
                                    sprintf(l_totalData, "<REQUEST_TYPE>%s</REQUEST_TYPE><BULK_TRANS_ID>%s</BULK_TRANS_ID><XML>%s</XML><ENTITY_NAME>%s</ENTITY_NAME>",m_reqType.c_str(), l_ibt->m_TransId, l_requestXml, l_ibt->m_user); 
                                 }
                                 else
                                 {
                                    sprintf(l_totalData, "<REQUEST_TYPE>%s</REQUEST_TYPE><BULK_TRANS_ID>%s</BULK_TRANS_ID><XML>%s</XML><ENTITY_NAME>%s</ENTITY_NAME>,<LOG_TDRS>%d</LOG_TDRS>",m_reqType.c_str(), l_ibt->m_TransId, l_requestXml, l_ibt->m_user ,l_ibt->m_logTDRs);
                                 }
                                 g_sc.initiateIndependentContext(this, MAP_OP_CODE_dummy_1, l_totalData, INITIATION_TYPE_TARDILY);
                                 ptr1=ptr2;

                              }
                           }
                           ptr2++;
                        }
                        m_tdr.setInteger(TDR_INDEX_OAM_FREE_FORMAT_DATA,l_totalRequests);

                        char l_response[500];
                        memset(l_response, '\0', sizeof(l_response));
                        sprintf(l_response, "Bulk Transaction ID: %s", l_ibt->m_TransId);


                        sendResponse(((ProvisioningMsg*)(m_imd->m_msgPtr))->m_sockFd, 
                              ((ProvisioningMsg*)(m_imd->m_msgPtr))->m_DeviceConnectionType, 
                              ((ProvisioningMsg*)(m_imd->m_msgPtr))->m_OrigEntityName, 
                              ((ProvisioningMsg*)(m_imd->m_msgPtr))->m_IpAddress, 
                              ((ProvisioningMsg*)(m_imd->m_msgPtr))->m_transId, 
                              ((ProvisioningMsg*)(m_imd->m_msgPtr))->m_transType, 
                              0, "Success", l_response);
                     }
                     else
                     {
                        WLOG(0,0,"InsertBulkTransId failed");
                        sendResponse(((ProvisioningMsg*)(m_imd->m_msgPtr))->m_sockFd, 
                              ((ProvisioningMsg*)(m_imd->m_msgPtr))->m_DeviceConnectionType, 
                              ((ProvisioningMsg*)(m_imd->m_msgPtr))->m_OrigEntityName, 
                              ((ProvisioningMsg*)(m_imd->m_msgPtr))->m_IpAddress, 
                              ((ProvisioningMsg*)(m_imd->m_msgPtr))->m_transId, 
                              ((ProvisioningMsg*)(m_imd->m_msgPtr))->m_transType, 
                              l_ibt->m_procErrorCode, l_ibt->m_procErrorMessage, NULL);
                     }
                  }
                  break;

               case 6:
                  {
                     LLOG(0,0,"ReloadConfigValues response received");
                     ReloadConfigValues *l_rcv = (ReloadConfigValues *)p_MsgPtr;

                     int l_errCode=0;
                     char l_errDesc[1000+1];
                     memset(l_errDesc, '\0', sizeof(l_errDesc));
                     //snprintf(l_errDesc, sizeof(l_errDesc), "%s", "SUCCESS");
                     if(DB_QUERY_RES_SUCCESS == l_rcv->m_DbQueryRes)
                     {
                        ProvisioningReqMsg *l_provReqMsg = (ProvisioningReqMsg*)m_imd->m_msgPtr;
                        string l_module = ConfigReader::readValue(l_provReqMsg->m_data, "MODULE");
                        char l_tempErrDesc[1000];
                        memset(l_tempErrDesc, '\0', sizeof(l_tempErrDesc));
                        bool l_status = validateConfigurationData(l_rcv->m_tvp, 1, l_tempErrDesc, sizeof(l_tempErrDesc)-1, (char*)l_module.c_str());
                        if(false == l_status)
                        {
                           l_errCode=800;
                           if(0 == strlen(l_errDesc))
                           {
                              snprintf(l_errDesc, sizeof(l_errDesc), "Validate: Error in configuration loading [%s]", l_tempErrDesc);
                           }
                        }
                        else
                        {
                           snprintf(l_errDesc, sizeof(l_errDesc), "%s", "SUCCESS");
                        }
                     }
                     else
                     {
                        l_errCode = 802;
                        snprintf(l_errDesc, sizeof(l_errDesc), "%s", "Validate: Some Error in DB");
                     }

                     sendResponse(((ProvisioningMsg*)(m_imd->m_msgPtr))->m_sockFd, 
                           ((ProvisioningMsg*)(m_imd->m_msgPtr))->m_DeviceConnectionType, 
                           ((ProvisioningMsg*)(m_imd->m_msgPtr))->m_OrigEntityName, 
                           ((ProvisioningMsg*)(m_imd->m_msgPtr))->m_IpAddress, 
                           ((ProvisioningMsg*)(m_imd->m_msgPtr))->m_transId, 
                           ((ProvisioningMsg*)(m_imd->m_msgPtr))->m_transType, 
                           l_errCode, 
                           l_errDesc, 
                           NULL);
                  }
                  break;

               default:
                  {
                     ELOG(0,0,"Invalid DB Response Message Received");
                  }
                  break;
            }
         }
         break;

      case MSG_TYPE_MEMCACHED:
         {
            MemCachedQueryMsg* l_MemcQueryMsgPtr = ((MemCachedQueryMsg*)p_MsgPtr);
            DLOG(0,0,"SOFT DELETE_MEMCACHED_DATA Query Response");      
            if(MEMC_QUERY_RES_SUCCESS == l_MemcQueryMsgPtr->m_MemcQueryRes)
            {
               m_tdr.setString(TDR_INDEX_MEMC_SET,"MCD|S");
            }
            else if(MEMC_QUERY_RES_FAILURE == l_MemcQueryMsgPtr->m_MemcQueryRes)
            {
               char l_errBuff[50];
               snprintf(l_errBuff,sizeof(l_errBuff),"MCD|F|%d|%s",l_MemcQueryMsgPtr->m_MemcErrorCode,(char*)(l_MemcQueryMsgPtr->m_MemcErrorMessage).c_str());
               m_tdr.setString(TDR_INDEX_MEMC_SET,l_errBuff);
            }
         }
         break;
      default:
         {
            DLOG(0,0,"Unknown message received");
         }
         break;

   }
   return true;
}

void strncpyWithoutSpace(char *p_dest, char *p_src, int p_srcMaxLength, int p_destMaxLength)
{
   int l_i=0;
   int l_j=0;
   int l_nonSpace=false;

   while( (p_src[l_i] != '\0') && (l_i < p_srcMaxLength))
   {
      if(p_src[l_i] != ' ')
      {
         l_nonSpace=true;
      }
      if(true == l_nonSpace)
      {
         if(l_j == p_destMaxLength)
         {
            break;
         }
         p_dest[l_j++] = p_src[l_i];
      }
      ++l_i;
   }
   p_dest[l_j]='\0';
   while(' ' == p_dest[l_j-1])
   {
      p_dest[--l_j]='\0';
   }
   return;
}

void tokenize1(char *p_input, char *p_str, int p_size, char p_token, bool p_startToken, bool p_endToken, int p_maxTokens)
{
   char *l_ptr1, *l_ptr2;
   l_ptr1=l_ptr2=p_input;
   l_ptr2++;
   int l_i=0;
   int l_startPos = (p_startToken==true)?1:0;

   if(*l_ptr2 == '\0')
   {
      strncpy(p_str, l_ptr1, 1);
   }
   while(*l_ptr2 != '\0')
   {
      if(p_token == *l_ptr2)
      {
         if(l_i == 0)
         {
            int l_length=l_ptr2-l_ptr1;
#if 0
            if(l_length > (p_size-1))
            {
               l_length=p_size-1;
            }
            strncpy(p_str+(l_i*p_size),l_ptr1+l_startPos,l_length);
#else
            strncpyWithoutSpace(p_str+(l_i*p_size),l_ptr1+l_startPos,l_length, p_size-1);
#endif
         }
         else
         {
            int l_length=l_ptr2-l_ptr1-1;
#if 0
            if(l_length > (p_size-1))
            {
               l_length=p_size-1;
            }

            strncpy(p_str+(l_i*p_size),l_ptr1+1,l_length);
#else
            strncpyWithoutSpace(p_str+(l_i*p_size),l_ptr1+1,l_length, p_size-1);
#endif
         }

         l_ptr1=l_ptr2;
         l_i++;
      }
      l_ptr2++;

      if(!p_endToken)
      {
         if((*l_ptr2 == '\0'))
         {
            if(l_ptr2-l_ptr1 == 1)
            {
               //strncpy(p_str+(l_i*p_size),"0",1);
            }
            else
            {
               if(l_i == 0)
               {
                  int l_length=l_ptr2-l_ptr1;
#if 0
                  if(l_length > (p_size-1))
                  {
                     l_length=p_size-1;
                  }
                  strncpy(p_str+(l_i*p_size),l_ptr1+l_startPos,l_length);
#else
                  strncpyWithoutSpace(p_str+(l_i*p_size),l_ptr1+l_startPos,l_length, p_size-1);
#endif
               }
               else
               {
                  int l_length=l_ptr2-l_ptr1-1;
#if 0
                  if(l_length > (p_size-1))
                  {
                     l_length=p_size-1;
                  }
                  strncpy(p_str+(l_i*p_size),l_ptr1+1,l_length);
#else
                  strncpyWithoutSpace(p_str+(l_i*p_size),l_ptr1+1,l_length, p_size-1);
#endif
               }

               if(l_i == p_maxTokens-1)
               {
                  return;
               }
            }
         }
      }
   }
}



