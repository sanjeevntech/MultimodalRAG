#include <HelperCtxtProvideSubscriberInfo.h>
#include <stdio.h>
#include <MapMessages.h>
#include <ServiceCoordinator.h>
#include <Logger.h>
#include <OMAP3.h>
#include <IMAP3.h>
#include <OamDbQueries.h>
#include <DbActiveObject.h>
#include <ConfigReader.h>
#include <OamConfigReader.h>
#include <Utilities.h>
#include <DataUnion.h>
#include <HlrTdrFiller.h>
#include <HlrUtilities.h>
extern bool resetStruct(int p_version, int p_pdu, void *p_struct);

enum EHelperPSIErrorCodes
{
   HELPER_PSI_ERR_CODE_ERROR_IN_RETRIEVING_LOCATION_INFORMATION = 694,
   HELPER_PSI_ERR_CODE_1,
   HELPER_PSI_ERR_CODE_2
};


HelperCtxtProvideSubscriberInfo::HelperCtxtProvideSubscriberInfo()
{
   DLOG(0,0,"HelperCtxtProvideSubscriberInfo::HelperCtxtProvideSubscriberInfo()");
   m_gxad=NULL;
}

HelperCtxtProvideSubscriberInfo::~HelperCtxtProvideSubscriberInfo()
{
   DLOG(0,0,"HelperCtxtProvideSubscriberInfo::~HelperCtxtProvideSubscriberInfo()");
   if(NULL != m_gxad)
   {
      delete(m_gxad);
      m_gxad=NULL;
   }
}

bool HelperCtxtProvideSubscriberInfo::handleError()
{
   LLOG(0,0,"handleError called");
   return setReturnValues(HELPER_EXECUTION_STATE_FINISHED, HELPER_PSI_ERR_CODE_ERROR_IN_RETRIEVING_LOCATION_INFORMATION, "Error in retrieving location information", "");

}

bool HelperCtxtProvideSubscriberInfo::startProcessingByHelper(Msg *p_MsgPtr, bool &p_DeleteFlag)
{
   LLOG(0,0,"HelperCtxtProvideSubscriberInfo::startProcessingByHelper called");
   p_DeleteFlag=false;
   m_gxad = (GenericXmlApiData*)p_MsgPtr;

   //Initiate PSI
   //Read Parameters
   string l_origHlrAddr = ConfigReader::readValue(m_gxad->m_ossHelperXml, "ORIG_ADDRESS");;
   if(1 > l_origHlrAddr.length())
   {
      CLOG(0,0,"Unknown ORIG_ADDRESS");
      return handleError();
   }
   string l_destVlrAddr = ConfigReader::readValue(m_gxad->m_ossHelperXml, "DEST_ADDRESS");
   if(1 > l_destVlrAddr.length())
   {
      CLOG(0,0,"Unknown DEST_ADDRESS");
      return handleError();
   }
   string l_imsi =  ConfigReader::readValue(m_gxad->m_ossHelperXml, "IMSI");
   if(1 > l_imsi.length())
   {
      CLOG(0,0,"Unknown IMSI");
      return handleError();
   }
   string l_lmsi =  ConfigReader::readValue(m_gxad->m_ossHelperXml, "LMSI");

   DECLARE(OMAP3_ProvideSubscriberInfoArg,l_tempPsi,3,"OMAP3_ProvideSubscriberInfoArg",resetStruct);

   u32 l_LocalDlg = g_sc.getNewDialogue();

   if(l_LocalDlg <= 0)
   {
      ELOG(0,0,"GetNewDialouge failed for sendpsi");
      return handleError();
   }
   m_mainContext->m_UserDlgId=l_LocalDlg;

   MapOpenReq l_mapOpenReq(l_LocalDlg, MAP_V3);
   TLOG(0,0,"created psi dlgid-|%d| and sending psi",l_LocalDlg);

   configureSccpAddress(&l_mapOpenReq.m_OrigAddr,L_ROUTE_ON_GT,0,6,(s8*)l_origHlrAddr.c_str());
   configureSccpAddress(&l_mapOpenReq.m_DestAddr,L_ROUTE_ON_GT,0,7,(s8*)l_destVlrAddr.c_str());

   //m_tdr.setString(TDR_INDEX_VLR_ADDRESS,(s8*)mp_sriSubData->m_VlrNum); //TODO?

   l_mapOpenReq.m_ApplCntxt = MAP_AC_CODE_subscriberInfoEnquiry;
   g_sc.sendMsg(m_mainContext, &l_mapOpenReq);

   DLOG(0,0,"sending psi MapSpecificRequest");
   MapSpecificRequest l_request(l_LocalDlg, MAP_OP_CODE_provideSubscriberInfo, MAP_V3);


   // IMSI MANDATORY PARAM		
   l_tempPsi->imsi.length = StringToBCD(l_tempPsi->imsi.value,(u8*)l_imsi.c_str(),l_imsi.size());
   TLOG(0,0,"sendPsi: requesting subscriber state and location info :active imsi-|%s|",l_imsi.c_str());

   // CIRCUIT-SWITCH DOMAIN ... whats the trigger ??	
   l_tempPsi->requestedInfo.bit_mask |= OMAP3_requestedDomain_present; 
   l_tempPsi->requestedInfo.requestedDomain = OMAP3_cs_Domain;

   l_tempPsi->requestedInfo.bit_mask |= OMAP3_RequestedInfo_subscriberState_present; 
   l_tempPsi->requestedInfo.subscriberState = true;

   l_tempPsi->requestedInfo.bit_mask |= OMAP3_RequestedInfo_locationInformation_present; 
   l_tempPsi->requestedInfo.locationInformation = true; 

   if(l_lmsi.size() > 0)
   {
      TLOG_HEX(0,0,"sendPsi: lmsi", (char*)l_lmsi.c_str(),4);
      l_tempPsi->bit_mask |= OMAP3_ProvideSubscriberInfoArg_lmsi_present;
      l_tempPsi->lmsi.length = 4;
      atohx((char *)l_tempPsi->lmsi.value,(char *)l_lmsi.c_str());
   }

   l_request.m_structBuffer = (void*)l_tempPsi;
   l_request.m_TimerValue = g_OamConfigReaderObj->m_psiTimer;
   g_sc.sendMsg(m_mainContext, &l_request);

   DLOG(0,0,"sending PSI Delimiter Req - End of send psi");
   MapDelimiterReq l_del(l_LocalDlg);
   g_sc.sendMsg(m_mainContext, &l_del);

   //End of initiating PSI
   m_hes=HELPER_EXECUTION_STATE_RELAY;
   return true;
}

bool HelperCtxtProvideSubscriberInfo::processMessageByHelper(Msg *p_MsgPtr, bool &p_DeleteFlag)
{
   DLOG(0,0,"Start of HelperCtxtProvideSubscriberInfo::processMsg function");
   if(NULL == m_mainContext)
   {
      return setReturnValues(HELPER_EXECUTION_STATE_FINISHED, HELPER_PSI_ERR_CODE_ERROR_IN_RETRIEVING_LOCATION_INFORMATION, "Error in retrieving location information", "");
   }

   MapSpecificMsg *l_specMsg = NULL;

   switch (p_MsgPtr->m_MsgType)
   {
      case MSG_TYPE_MAP:
         switch (((MapMsg*)p_MsgPtr)->m_MapMsgType)
         {
            case MAP_MSG_TYPE_COMMON:
               switch (((MapCommonMsg*)p_MsgPtr)->m_MapCommonMsgType)
               {
                  case MAP_CMN_OPEN_IND:
                     CLOG(0,0,"MAP_CMN_OPEN_IND received ");
                     return handleError();
                     break;

                  case MAP_CMN_OPEN_CNF:
                     {
                        if(REFUSE_REASON_APPL_CNTXT_NOT_SUPPORTED == ((MapOpenCnf*)p_MsgPtr)->m_RefuseReasonParam)
                        {
                           LLOG(0,0,"MAP_CMN_OPEN_CNF received with Version [%d]", ((MapOpenCnf*)p_MsgPtr)->m_Version);
                           //m_mainContext->m_tdr.setInteger(TDR_INDEX_OPEN_CNF_VERSION,(int)(((MapOpenCnf*)p_MsgPtr)->m_Version));

                           if(MAP_V1 == ((MapOpenCnf*)p_MsgPtr)->m_Version)
                           {
                              //sendv1Psi(); ??
                           }
                           else if(MAP_V2  == ((MapOpenCnf*)p_MsgPtr)->m_Version)
                           {
                              //sendv2Psi();??
                           }
                        }
                        else
                        {
                           LLOG(0,0,"MAP_CMN_OPEN_CNF received with other reason [%d]", 
                                 ((MapOpenCnf*)p_MsgPtr)->m_RefuseReasonParam);
                           //m_mainContext->m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_NOTICE_RCVD); 
                        }
                        return handleError();
                     }
                     break;

                  case MAP_CMN_DELIMITER_IND:
                     {
                        LLOG(0,0,"MAP_CMN_DELIMITER_IND received ");
                     }
                     break;

                  case MAP_CMN_CLOSE_IND:
                     {
                        LLOG(0,0,"MAP_CMN_CLOSE_IND received");
                     }

                     break;

                  case MAP_CMN_U_ABORT_IND:
                     {
                        WLOG(0,0,"MAP_CMN_U_ABORT_IND received");
                        return handleError();
                        //m_mainContext->m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_U_ABORT_RCVD); 
                     }
                     break;

                  case MAP_CMN_P_ABORT_IND:
                     {
                        WLOG(0,0,"MAP_CMN_P_ABORT_IND received");
                        return handleError();
                        //m_mainContext->m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_P_ABORT_RCVD); 
                     }
                     break;

                  case MAP_CMN_NOTICE_IND:
                     {
                        WLOG(0,0,"MAP_CMN_NOTICE_IND received");
                        //m_mainContext->m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_NOTICE_RCVD); 
                        MapCloseReq l_closeReq(m_mainContext->m_UserDlgId);
                        l_closeReq.m_CloseType = MAP_CLOSE_TYPE_PRE_ARRANGED_END;
                        g_sc.sendMsg(m_mainContext, &l_closeReq);
                        return handleError();

                     }
                     break;

                  default:
                     ELOG(0,0,"Unknown Msg received [%d]", ((MapCommonMsg*)p_MsgPtr)->m_MapCommonMsgType);
                     break;
               }
               break;

            case MAP_MSG_TYPE_SPECIFIC:
               DLOG(0,0,"MAP_MSG_TYPE_SPECIFIC received");
               l_specMsg = (MapSpecificMsg*)p_MsgPtr;

               switch (((MapSpecificMsg*)p_MsgPtr)->m_MapSpecificEventType)
               {
                  case MAP_SPEC_EVENT_CONFIRMATION:
                     {
                        DLOG(0,0,"MAP_SPEC_EVENT_CONFIRMATION received");
                        switch (((MapSpecificMsg*)p_MsgPtr)->m_OpCode)
                        {
                           case MAP_OP_CODE_provideSubscriberInfo:
                              {
                                 if (false == ((MapSpecificMsg*)p_MsgPtr)->m_allocatedFlag)
                                 {
                                    CLOG(0,0,"PSI received is NULL");
                                    return handleError();
                                 }
                                 DLOG(0,0,"Decoding PSIres..."); 

                                 IMAP3_ProvideSubscriberInfoRes *l_psiRes = (IMAP3_ProvideSubscriberInfoRes*)(((MapSpecificMsg*)p_MsgPtr)->m_structBuffer);

                                 //////////////////////////////////////////////////////////////////////////////////////////////////////////////////


                                 if(l_psiRes->subscriberInfo.bit_mask & IMAP3_SubscriberInfo_subscriberState_present)
                                 {
                                    u16 sState = l_psiRes->subscriberInfo.subscriberState.choice;
                                    TLOG(0,0,"Subscriber state in PsiRes |%d|",sState); 
                                    switch(sState)
                                    {
                                       case 1: //MAP3_assumedIdle_chosen
                                          {
                                             LLOG(0,0,"Subscriber state AssumedIdle from PsiRes"); 
                                          }
                                          break;
                                       case 2: //MAP3_camelBusy_chosen
                                          {
                                             LLOG(0,0,"Subscriber state CamelBusy from PsiRes"); 
                                          }
                                          break;
                                       case 3: //MAP3_SubscriberState_netDetNotReachable_chosen
                                          {
                                             LLOG(0,0,"Subscriber state NetworkDeterminedNotReachable from PsiRes"); 
                                          }
                                          break;
                                       case 4: //MAP3_notProvidedFromVLR_chosen
                                          {
                                             LLOG(0,0,"Subscriber state not provided from Vlr from PsiRes"); 
                                          }
                                          break;
                                       default:
                                          {
                                             CLOG(0,0,"Default case of subscriber state");
                                          }
                                          break;
                                    }
                                 }

                                 char l_cgi[50+1];
                                 IMAP3_LocationInformation *l_IlocInfo = &l_psiRes->subscriberInfo.locationInformation;

                                 if(l_psiRes->subscriberInfo.bit_mask & IMAP3_SubscriberInfo_locationInformation_present)
                                 {
                                    if(l_IlocInfo->bit_mask &  IMAP3_LocationInformation_ageOfLocationInformation_present) 
                                    {
                                       DLOG(0,0,"LocInfo: AgeOfLocInformation from PsiRes[%d]",l_IlocInfo->ageOfLocationInformation); 
                                    }
                                    if(l_IlocInfo->bit_mask & IMAP3_LocationInformation_geographicalInformation_present)
                                    {
                                       DLOG(0,0,"LocInfo: GeographicalInformation from PsiRes: Len[%d] Value[%s]",l_IlocInfo->geographicalInformation.length,l_IlocInfo->geographicalInformation.value); 
                                    }

                                    if(l_IlocInfo->bit_mask & IMAP3_vlr_number_present)
                                    {
                                       DLOG(0,0,"LocInfo: VlrNumber from PsiRes: Len[%d] Value[%s]",l_IlocInfo->vlr_number.length,l_IlocInfo->vlr_number.value); 

                                    }
                                    if(l_IlocInfo->bit_mask & IMAP3_LocationInformation_msc_Number_present)
                                    {
                                       DLOG(0,0,"LocInfo: MscNumber from PsiRes: Len[%d] Value[%s]",l_IlocInfo->msc_Number.length,l_IlocInfo->msc_Number.value); 
                                    }
                                    if(l_IlocInfo->bit_mask & IMAP3_locationNumber_present)
                                    {
                                       DLOG(0,0,"LocInfo: LocationNumber from PsiRes Len[%d] Value[%s]",l_IlocInfo->locationNumber.length,l_IlocInfo->locationNumber.value); 
                                    }
                                    if(l_IlocInfo->bit_mask & IMAP3_LocationInformation_geodeticInformation_present)
                                    {
                                       DLOG(0,0,"LocInfo: GeodeticInformation from PsiRes Len[%d] Value[%s]",l_IlocInfo->geodeticInformation.length,l_IlocInfo->geodeticInformation.value); 
                                    }
                                    int l_cellId = 0;
                                    int l_areaCode = 0;
                                    if(l_IlocInfo->bit_mask & IMAP3_LocationInformation_cellGlobalIdOrServiceAreaIdOrLAI_present)
                                    {
                                       u16 globOrsrvcOrLaiID = l_IlocInfo->cellGlobalIdOrServiceAreaIdOrLAI.choice;  
                                       switch(globOrsrvcOrLaiID)
                                       {
                                          case 1: //IMAP3_cellGlobalIdOrServiceAreaIdFixedLength_chosen 
                                             {
                                                DLOG(0,0,"LocInfo: GlobalOrServiceID from PsiRes Len[%d] Value[%s]",l_IlocInfo->cellGlobalIdOrServiceAreaIdOrLAI.u.cellGlobalIdOrServiceAreaIdFixedLength.length,l_IlocInfo->cellGlobalIdOrServiceAreaIdOrLAI.u.cellGlobalIdOrServiceAreaIdFixedLength.value); 
                                                if(l_IlocInfo->cellGlobalIdOrServiceAreaIdOrLAI.u.cellGlobalIdOrServiceAreaIdFixedLength.length != 7)
                                                {
                                                   LLOG(0,0,"Cell-Id length not equal to 7, cannot decode");
                                                   return handleError();
                                                }
                                                else
                                                {
                                                   char l_mcc[4+1];
                                                   memset(&l_mcc, '\0', sizeof(l_mcc));
                                                   char l_mnc[4+1];
                                                   memset(&l_mnc, '\0', sizeof(l_mnc));
                                                   BCDToString((u8*)l_mcc, &l_IlocInfo->cellGlobalIdOrServiceAreaIdOrLAI.u.cellGlobalIdOrServiceAreaIdFixedLength.value[0], 2);
                                                   BCDToString((u8*)l_mnc, &l_IlocInfo->cellGlobalIdOrServiceAreaIdOrLAI.u.cellGlobalIdOrServiceAreaIdFixedLength.value[2], 1);
                                                   l_cellId = l_IlocInfo->cellGlobalIdOrServiceAreaIdOrLAI.u.cellGlobalIdOrServiceAreaIdFixedLength.value[5]*256 + l_IlocInfo->cellGlobalIdOrServiceAreaIdOrLAI.u.cellGlobalIdOrServiceAreaIdFixedLength.value[6];
                                                   l_areaCode = l_IlocInfo->cellGlobalIdOrServiceAreaIdOrLAI.u.cellGlobalIdOrServiceAreaIdFixedLength.value[3]*256 + l_IlocInfo->cellGlobalIdOrServiceAreaIdOrLAI.u.cellGlobalIdOrServiceAreaIdFixedLength.value[4];
                                                   snprintf(l_cgi, sizeof(l_cgi), "%s-%s-%05d-%05d", l_mcc, l_mnc, l_areaCode, l_cellId);

                                                   l_areaCode = l_areaCode%100; //last two digits of decimal areaCode

                                                   LLOG(0,0,"CellId[%d] AreaCode[%d] CGI[%s]",
                                                         l_cellId,l_areaCode,l_cgi);
                                                }
                                             }
                                             break;
                                          case 2: //IMAP3_laiFixedLength_chosen
                                             {
                                                DLOG(0,0,"LocInfo: LAI from PsiRes Len[%d] Value[%s]",l_IlocInfo->cellGlobalIdOrServiceAreaIdOrLAI.u.laiFixedLength.length,l_IlocInfo->cellGlobalIdOrServiceAreaIdOrLAI.u.laiFixedLength.value); 
                                             }
                                             break;
                                          default:
                                             {
                                                CLOG(0,0,"Default case of globalOrSrvcOrLaiId %d", globOrsrvcOrLaiID);
                                             }
                                             break;
                                       }
                                    }
                                    if(l_IlocInfo->bit_mask & IMAP3_selectedLSA_Id_present)
                                    {
                                       DLOG(0,0,"LocInfo: SelectedLsaid from PsiRes Len[%d] Value[%s]",l_IlocInfo->selectedLSA_Id.length,l_IlocInfo->selectedLSA_Id.value); 
                                    }
                                    if(l_IlocInfo->bit_mask & IMAP3_LocationInformation_currentLocationRetrieved_present)
                                    {
                                       DLOG(0,0,"LocInfo: CurrentLocRetreived from PsiRes"); 
                                    }
                                    if(l_IlocInfo->bit_mask & IMAP3_LocationInformation_sai_Present_present)
                                    {
                                       DLOG(0,0,"LocInfo: SaiPresent from PsiRes"); 
                                    }
                                 }
                                 if(l_psiRes->subscriberInfo.bit_mask & IMAP3_SubscriberInfo_imei_present)
                                 {
                                    DLOG(0,0,"LocInfo: Imei from PsiRes Len[%d] Value[%s]",l_psiRes->subscriberInfo.imei.length,l_psiRes->subscriberInfo.imei.value); 
                                 }


                                 /////////////////////////////////////////////////////////////////////////////////////////////////////////////////

                                 if(0 == strlen(l_cgi))
                                 {
                                    CLOG(0,0,"CGI is null");
                                    return handleError();
                                 }

                                 m_gxad->m_DbQueryType = 1;
                                 m_gxad->m_cb = m_mainContext;
                                 m_gxad->m_DbQueryRes = DB_QUERY_RES_UNKNOWN;
                                 m_gxad->m_sqlcode = 0;
                                 m_gxad->m_procErrorCode = 0;
                                 char l_additionalData[200+1];
                                 memset(l_additionalData,'\0',sizeof(l_additionalData));
                                 snprintf(l_additionalData,sizeof(l_additionalData),"<CELL_ID>%s</CELL_ID>",l_cgi);
                                 if(NULL != m_gxad->m_xmlBody)
                                 {
                                    int l_length = strlen(m_gxad->m_xmlBody)+strlen(l_additionalData);
                                    strlcat((char*)m_gxad->m_xmlBody, l_additionalData, l_length+1);
                                 }
                                 memset(m_gxad->m_procErrorMessage, '\0', sizeof(m_gxad->m_procErrorMessage));
                                 g_act.execute(m_gxad);
                                 m_hes=HELPER_EXECUTION_STATE_RELAY;
                              }
                              break;

                           default:
                              break;
                        }

                     }
                     break;

                  case MAP_SPEC_EVENT_USER_ERROR:
                     {
                        CLOG(0,0,"MAP_SPEC_EVENT_USER_ERROR received");
                        return handleError();
                        //m_mainContext->m_tdr.setInteger(TDR_INDEX_ERR_CODE, ((MapUserError*)p_MsgPtr)->m_ErrorCode); 
                     }
                     break;

                  case MAP_SPEC_EVENT_PROV_ERROR:
                     {
                        CLOG(0,0,"MAP_SPEC_EVENT_PROV_ERROR received");
                        return handleError();
                        //m_mainContext->m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_PROVIDER_ERROR_RCVD); 
                        DLOG(0,0,"Closing the Dialogue");
                     }
                     break;
                  default:
                     //m_mainContext->m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_GENERAL_ERROR); 
                     ELOG(0,0,"ERROR!! Default received");
                     return handleError();
                     break;
               }
               break;

            default:
               break;
         }
         break;

      case MSG_TYPE_DB:
         {
            GenericXmlApiData *l_gxad = (GenericXmlApiData*)p_MsgPtr;
            LLOG(0,0,"DB message received Count of oss triggers: %d", l_gxad->m_ossTriggerDataCount);
            p_DeleteFlag=false;
            m_mainContext->m_tdr.setString(TDR_INDEX_OAM_FREE_FORMAT_DATA,l_gxad->m_freeFormatTdrData);
            for (int l_i=0; l_i<l_gxad->m_ossTriggerDataCount; l_i++)
            {
               TLOG(0,0,"Pushing the row id [%s] into queue", l_gxad->m_ossTriggerDataArray[l_i].m_rowId);
               g_sc.initiateIndependentContext(m_mainContext, MAP_OP_CODE_dummy_1, (char*)l_gxad->m_ossTriggerDataArray[l_i].m_rowId, INITIATION_TYPE_TARDILY);
            }
            return setReturnValues(HELPER_EXECUTION_STATE_FINISHED, 
                  l_gxad->m_procErrorCode, 
                  l_gxad->m_procErrorMessage, 
                  l_gxad->m_channelResponseXml);
         }
         break;

      default:
         ELOG(0,0,"Unknown message received");
         return handleError();
         break;

   }
   return false;
}

