#include <MapMessages.h>
#include <ContextBase.h>
#include <ModuleBase.h>
#include <Logger.h>
#include <ModuleBase.h>
#include <OamConfigReader.h>
#include <CtxtOam.h>
#include <CtxtOamDeleteSubscriberData.h>
#include <CtxtActivateTraceMode.h>
#include <CtxtDeactivateTraceMode.h>
#include <CtxtSendImsi.h>
#include <CtxtReset.h>
#include <SubsProfileData.h>
#include "CtxtSimSendImsiReq.h"
#include <OamSimConfigReader.h>

extern int getTrapInt(char *p_trapCode);

extern bool g_loadFlag;
extern "C" {
   ModuleBase *getModuleObj();
}

class OamModule : public ModuleBase
{
    public:
      OamModule(){}
      bool initModule();
      ContextBase *getCtxtObj(EMapOpCode, MapSpecificMsg*);
      ContextBase *getCtxtObj(EDiameterCommandCode, DiameterMsg*);
      ContextBase *getCtxtObj(EMapOpCode, SccpMsg*);
      char *getVersion();
      ConfigReader *getConfigReaderObj();
      ConfigReader **retrieveConfigReaderPtr();
};

char *g_extraTag = NULL;

OamModule g_OamModule;

ModuleBase *getModuleObj()
{
    return &g_OamModule;
}

char *OamModule::getVersion()
{
   RETURN_VERSION(APP_VERSION);// 2.0.24.0 2.0.23.0 
}

bool OamModule::initModule()
{
   g_extraTag=getenv("ADD_EXTRA_TAG_IN_APIS");
   if(true == g_loadFlag)
   {
      m_modName = "OMS";
   }
   else
   {
      m_modName="OAM";
      LLOG(0,0,"OAM APPVER-v:%s ci:%s cd:%s comp:%s %s", APP_VERSION, COMMIT_ID, COMMIT_DATE,__DATE__,__TIME__);
   }

   moduleLevelAddHeader("GeneratingCrossMessage", MODULE_STATS_TYPE_NORMAL);
   moduleLevelAddHeader("ReceivedCL", MODULE_STATS_TYPE_NORMAL);
   moduleLevelAddHeader("ReceivedPNR", MODULE_STATS_TYPE_NORMAL);
   moduleLevelAddHeader("ReceivedPPR", MODULE_STATS_TYPE_NORMAL);
   moduleLevelAddHeader("ReceivedIDR", MODULE_STATS_TYPE_NORMAL);
   moduleLevelAddHeader("ReceivedSARAlertSC", MODULE_STATS_TYPE_NORMAL);
#if 0
   if (false == g_OamConfigReaderObj->m_derivedObjectInitializedFlag)
   {
       printf("\nERROR: OAM specific configuration file reading is mandatory");
       return false;
   }
#endif
   return true;
}

ContextBase *OamModule::getCtxtObj(EMapOpCode p_OpCode, MapSpecificMsg *p_msg)
{
   switch (p_OpCode)
   {
      case MAP_OP_CODE_dummy_1:
         DLOG(0,0,"Newing CtxtOam");
         try
         {
            return new CtxtOam;
         }
         catch(...)
         {
            CLOG(0,0,"New Failed to create an instance");
            throw("New Failed");
         }
         break;

      case MAP_OP_CODE_deleteSubscriberData:
         DLOG(0,0,"Newing CtxtVLROam");
         return new CtxtOamDeleteSubscriberData;
         break;

      case MAP_OP_CODE_sendIMSI:
         {
            if(false == g_loadFlag)
            {
               DLOG(0,0,"Newing CtxtSendImsi");
               return new CtxtSendImsi;
            }
            else
            {
               TLOG(0,0,"Newing CtxtSimSendImsiReq");
               return new CtxtSimSendImsiReq;
            }
         }
            break;
      case MAP_OP_CODE_reset:
         DLOG(0,0,"Newing CtxtReset");
         return new CtxtReset;
         break;

      case MAP_OP_CODE_activateTraceMode:
         DLOG(0,0,"Newing CtxtActivateTraceMode");
         return new CtxtActivateTraceMode;
         break;

      case MAP_OP_CODE_deactivateTraceMode:
         DLOG(0,0,"Newing CtxtDeactivateTraceMode");
         return new CtxtDeactivateTraceMode;
         break;

      default:
         DLOG(0,0,"getOamCtxtObj Unknown OpCode [%d]",p_OpCode);
         printf("\ngetOamCtxtObj Unknown OpCode [%d]",p_OpCode);
         return NULL;
         break;
   }
}

ContextBase *OamModule::getCtxtObj(EDiameterCommandCode p_ccCode, DiameterMsg *p_msg)
{
   return NULL;
}

ContextBase *OamModule::getCtxtObj(EMapOpCode p_OpCode, SccpMsg* p_msg)
{
   ELOG(0,0,"SCCP message not supported");
   return NULL;
}

ConfigReader *OamModule::getConfigReaderObj()
{
   if(true == g_loadFlag)
   {
      LLOG(0,0,"Returning g_OamSimConfigReaderObj");
      return (g_OamSimConfigReaderObj = new OamSimConfigReader); 
   }
   LLOG(0,0,"Returning g_OamConfigReaderObj");
   return new OamConfigReader;
}

ConfigReader **OamModule::retrieveConfigReaderPtr()
{
      if(true == g_loadFlag)
      {
         LLOG(0,0,"ConfigReader Sim **OamModule::retrieveConfigReaderPtr() called");
         return (ConfigReader **)&g_OamSimConfigReaderObj;
      }
   LLOG(0,0,"ConfigReader **OamModule::retrieveConfigReaderPtr() called");
   return (ConfigReader **)&g_OamConfigReaderObj;
}




