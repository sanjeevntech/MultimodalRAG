#include <OamConfigReader.h>
#include <Logger.h>
#include <SubsProfileData.h>

OamConfigReader *g_OamConfigReaderObj;


OamConfigReader::OamConfigReader()
{
   m_DSD_MAP_VERSION=0;
   m_SUBSCRIBER_TRACING_VERSION=0;
}

OamConfigReader::~OamConfigReader()
{
}


bool OamConfigReader::readData()
{
   //string l_oam = readValue(m_DataString, "OAM");
   string l_oam = m_DataString;

   if( false == readInteger(l_oam, "RESET_TO_VLR_FLAG", m_VlrResetEnabled, 0, 1))
      return false;

   if( false == readInteger(l_oam, "RESET_TO_SGSN_FLAG", m_SgsnResetEnabled, 0, 1))
      return false;

   if((1 == m_VlrResetEnabled) || (1 == m_SgsnResetEnabled))
   {
      if( false == readInteger(l_oam, "RESET_MAP_VERSION", m_ResetMapVer, 1, 3))
         return false;
   }

   if( false == readInteger(l_oam, "MEMCACHED_DELETE_FLAG", m_MemcachedDeleteFlag, 0, 3))
      return false;

   DLOG(0,0,"MemcachedDeleteFlag[%d]",m_MemcachedDeleteFlag);

   LLOG(0,0,"Deployment Type :%c", g_DeploymentType);
   if( g_DeploymentType != 'S')
   {
      if( false == readInteger(l_oam, "DSD_MAP_VERSION", m_DSD_MAP_VERSION, 1, 3))
         return false;

      if( false == readInteger(l_oam, "SUBSCRIBER_TRACING_VERSION", m_SUBSCRIBER_TRACING_VERSION, 1, 3))
         return false;

      if( false == readInteger(l_oam, "PSI_TIMER", m_psiTimer, 15, 30))
         return false;
   }

   m_derivedObjectInitializedFlag=true;

   return true;
}

void OamConfigReader::printConfigData(char *p_output)
{
   LLOG(0,1,"OamConfigReader::printConfigData called.");

   if( g_DeploymentType != 'S')
   {
      sprintf(p_output, "%s:%d\t%s:%d\t%s:%d\t%s:%d\t%s:%d\t%s:%d\t%s:%d", 
            "DsdMapVersion", g_OamConfigReaderObj->m_DSD_MAP_VERSION,
            "ResetVlrFlag",    g_OamConfigReaderObj->m_VlrResetEnabled,
            "ResetSgsnFlag", g_OamConfigReaderObj->m_SgsnResetEnabled,
            "ResetMapVersion", g_OamConfigReaderObj->m_ResetMapVer,
            "SubsTracingVersion", g_OamConfigReaderObj->m_SUBSCRIBER_TRACING_VERSION,
            "PsiTimer",g_OamConfigReaderObj->m_psiTimer,
            "MemCachedDeleteFlag",g_OamConfigReaderObj->m_MemcachedDeleteFlag
            );
   }
   else
   {
      sprintf(p_output, "%s:%d\t%s:%d\t%s:%d", 
            "ResetVlrFlag",    g_OamConfigReaderObj->m_VlrResetEnabled,
            "ResetSgsnFlag", g_OamConfigReaderObj->m_SgsnResetEnabled,
            "ResetMapVersion", g_OamConfigReaderObj->m_ResetMapVer
            );
   }
}

