#include <ExecutionHelper.h>
#include <stdio.h>
#include <MapMessages.h>
#include <HlrUtilities.h>
#include <HelperCtxtProvideSubscriberInfo.h>

ExecutionHelper::ExecutionHelper()
{
   DLOG(0,0,"ExecutionHelper::ExecutionHelper()");
   m_mainContext=NULL;
   m_hes=HELPER_EXECUTION_STATE_INITIAL;
   m_errCode=700;
   m_errDesc="Problem in execution";
}

ExecutionHelper::~ExecutionHelper()
{
   DLOG(0,0,"ExecutionHelper::~ExecutionHelper()");
}

ExecutionHelper *getExecutionHelper(int p_opCode)
{
   DLOG(0,0,"getExecutionHelper called with OpCode [%d]", p_opCode);
   switch(p_opCode)
   {
      case 71: //to initiate PSI and retrieve the Cell ID
         return new HelperCtxtProvideSubscriberInfo;
         break;

      default:
         ELOG(0,0,"ERROR!! OpCode [%d] has no help", p_opCode);
         return NULL;
         break;
   }
   ELOG(0,0,"Should not come here");
   return NULL;
}

bool ExecutionHelper::setReturnValues(EHelperExecutionState p_hes, int p_errCode, string p_errDesc, string p_body)
{
   m_hes=p_hes;
   m_errCode=p_errCode;
   m_errDesc=p_errDesc;
   m_body=p_body;
   return true;
}
