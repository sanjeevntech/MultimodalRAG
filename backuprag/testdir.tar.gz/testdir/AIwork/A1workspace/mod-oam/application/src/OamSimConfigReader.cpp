#include <OamSimConfigReader.h>
#include <Logger.h>
  
  OamSimConfigReader *g_OamSimConfigReaderObj = NULL;
  OamSimConfigReader::OamSimConfigReader()
  {
     memset(m_msisdn,'\0',sizeof(m_msisdn));
  }
 
  OamSimConfigReader::~OamSimConfigReader()
  {
  }
 
  bool OamSimConfigReader::readData()
  {
     string l_cm = readValue(m_DataString,"OAMSIM");
 
     string l_msisdn = readValue(l_cm,"MSISDN");
     strncpy(g_OamSimConfigReaderObj->m_msisdn,(char*)l_msisdn.c_str(),strlen((char*)l_msisdn.c_str()));
     printf("\n Value of Msisdn = [%s]\n",m_msisdn);
 
     return true;
  }
void OamSimConfigReader::printConfigData(char *p_output)
  {
     TLOG(0,1,"OamSimConfigReader::printConfigData called.");

     sprintf(p_output, "%s:%s\n",
           "Msisdn", g_OamSimConfigReaderObj->m_msisdn
           );
}
