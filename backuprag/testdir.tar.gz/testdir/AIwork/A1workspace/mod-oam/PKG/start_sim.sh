clear
. run.sh
rm -f ./log/*.log
rm -f core
SHM=100
$HLR_FRAMEWORK_ROOT/ng -config SimulatorNgConfig.xml -sim -simCount 0 -simOpCode 2
