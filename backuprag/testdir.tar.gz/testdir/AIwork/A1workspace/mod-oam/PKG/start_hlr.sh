clear
. run.sh
rm -f ./log/*.log
rm -f ./tdr/*.log
rm -f ./log/db/*.log
rm -f core
SHM=100
MAX_TCAP_RECV_MESSAGES_AT_A_TIME=100
$HLR_FRAMEWORK_ROOT/map-ng/PKG/mapNG -config NgConfig.xml
