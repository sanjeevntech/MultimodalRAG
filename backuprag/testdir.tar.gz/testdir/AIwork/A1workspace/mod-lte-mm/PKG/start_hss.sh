HLR_RELEASE_PATH=/74bkp/rgopal/work/HSS_GCC_2.0.0.1/release/
#HLR_RELEASE_PATH=/74bkp/rgopal/work/HLR_2.0.2.0/map-ng/application/objs/mapNG

ITS_DIAMETER_SERVER_HOME=/74bkp/rgopal/DIAMETRIQ_GCC/DSS-6.0.3-Sol-GCC-x86_64/
ISS7_CONFIG_DIR=/74bkp/rgopal/DIAMETRIQ_GCC/DSS-6.0.3-Sol-GCC-x86_64/config/
ITS_DIAMETER_HOME=/74bkp/rgopal/DIAMETRIQ_GCC/DSA-6.0.3-Sol-GCC-x86_64/
ITS_S6A_HOME=/74bkp/rgopal/DIAMETRIQ_GCC/S6A-R10-6.0.3-Sol-GCC-x86_64/

ORACLE_HOME=/ora10gclnt/product/10.2.0/client
export ORACLE_HOME
export ITS_DIAMETER_SERVER_HOME
export ITS_DIAMETER_HOME
export ITS_S6A_HOME

echo $ORACLE_HOME

LD_LIBRARY_PATH=.:$HLR_RELEASE_PATH/lib:/usr/local/ssl/lib/:/opt/ulcm/library:$ORACLE_HOME/lib:/74bkp/rgopal/work/GENERIC_UTIL_1.4.0.0/gen-util/lib/:/opt/product/mohan/HLR/license/generator/pkg/:/lib/64/:$ITS_DIAMETER_HOME/api/lib:$ITS_DIAMETER_HOME//api/c++/lib:$ITS_DIAMETER_HOME/dframe/lib:$ITS_DIAMETER_HOME/vendors/IntelliNet/lib:$ITS_DIAMETER_HOME/AcceleroCore/common/lib/:$ITS_DIAMETER_HOME/lib:$ITS_S6A_HOME/lib/
export LD_LIBRARY_PATH

echo $LD_LIBRARY_PATH
SHM=100

echo "starting hss"
ldd $HLR_RELEASE_PATH/bin/pHLR
#$HLR_RELEASE_PATH/bin/pHLR -index $1 -config NgConfig.xml #-simLoad -simOpCode 317 -simLoadDuration 1 -simLoadMsgsPerSec 1
#/74bkp/rgopal/work/HLR_2.0.2.0_Rev1/map-ng/application/objs/mapNG -index $1 -config NgConfig.xml #-simLoad -simOpCode 317 -simLoadDuration 1 -simLoadMsgsPerSec 1
/74bkp/rgopal/work/HLR_2.0.6.0/map-ng/application/objs/mapNG -index $1 -config NgConfig.xml #-simLoad -simOpCode 317 -simLoadDuration 1 -simLoadMsgsPerSec 1
echo "hss exited with $?"
