clear
export MS_MODULE_DATA=`cat ./config/LteMmSimConfigData.xml`
echo $MS_MODULE_DATA
releasepath=hlr_oss_install_"$SYSTEM_OS"_"$SYSTEM_HARDWARE"
export releasepath
LD_LIBRARY_PATH=$OSS_NOKALVA_HOME/lib:/opt/sfp/64bit/openssl-0.9.8m/lib/:$HLR_RELEASE_PATH/lib:$OMNI_HOME/streams/lib/:$OMNI_HOME/library:$ORACLE_HOME/lib:$GEN_UTIL_HOME/lib/:/opt/product/mohan/HLR/license/generator/pkg/:$DIAMETER_STACK_HOME/diameter_stack_install/lib:$APP_ROOT/$releasepath/lib/:$OSS_NOKALVA_HOME/lib/:/etc/:$OPEN_SSL_LIB/:/home/mohan/JIRA/DIASTACK/STACK/diameter_stack_install/lib/
echo $LD_LIBRARY_PATH
SHM=100
export SHM

echo "starting mme..."
ldd $APP_ROOT/$releasepath/bin/pHSS-HLR
$APP_ROOT/$releasepath/bin/pHSS-HLR -index $1 -config ./config/MmeNgConfig.xml -simLoad -simOpCode 316 -simLoadDuration 1 -simLoadMsgsPerSec 1
#$APP_ROOT/$releasepath/bin/pHSS-HLR -index $1 -config ./config/MmeNgConfig.xml -simLoad -simOpCode 8388622 -simLoadDuration 1 -simLoadMsgsPerSec 1
