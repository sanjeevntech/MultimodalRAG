#ifndef __HSS_MM_DB_QUERIES_H
#define __HSS_MM_DB_QUERIES_H

#include <DbQueryMsg.h>
#include <LteCommonDefines.h>
typedef unsigned char   u8;
#define MAX_OSS_TRIGGER_DATA        10
#define MAX_ROW_ID_LEN              30
#define MAX_NUM_OF_SUBSCRIBERS      20
#define MAX_ACCOUNT_ID_LEN          20
#define MAX_ALL_SUBS_ACCOUNT_ID     (MAX_NUM_OF_SUBSCRIBERS*MAX_ACCOUNT_ID_LEN)

class LteSubsDbData : public DbQueryMsg 
{
   public:
      LteSubsDbData();
      virtual ~LteSubsDbData();

      void executeMemcQuery();
      void serializeMemc();
      bool deSerializeMemc();
      bool validateMemcachedContinuity();
      //int  m_RoamPartnerId;

      //In  
      int m_RatType_IN;
      int m_UeSrvccCap_IN;
      int m_HssImsVoipSessions_IN;
      int m_NodeTypeInd_IN;
      int m_FullIdrInd_IN;
      u8 m_Orig_Imei[40]; 
      unsigned int m_UlrFlag_IN;
      unsigned int m_FeatureList1_IN;
      unsigned int m_FeatureList2_IN;

      char m_Imei_IN[HSS_IMEISV_LEN + 1];
      char m_UlrImsi_IN[HSS_IMSI_LEN + 1];
      char m_MmeHost_IN[HSS_HOST_LEN + 1];
      char m_MmeRealm_IN[HSS_REALM_LEN + 1];
      char m_SgsnNumber_IN[HSS_SGSN_NUMBER_LEN + 1];
      char m_GmlcAddress_IN[HSS_GMLC_ADDRESS_LEN + 1];
      char m_MmeNumberMtSms_IN[HSS_MME_NUMBER_MT_SMS_LEN + 1];
      char m_ExtSuppFeatureList_IN[HSS_EXT_SUPP_FEATURE_LEN + 1];
      char m_SoftwareVersion_IN[HSS_IMEI_SOFTWARE_VERSION_LEN + 1];

      unsigned char m_VplmnId_IN[HSS_VPLMNID_LEN + 1];
      unsigned char m_3gpp2Meid_IN[HSS_3GPP2_MEID_LEN + 1];
      char m_MccMnc_IN[6+1]; //6.4.0.0


      //Out
      int m_Nam_OUT;
      int m_Mwd_OUT;
      int m_FirstUL_OUT;
      int m_NetworkId_OUT;
      int m_RoamingInd_OUT;
      int m_S6aRelease_OUT;
      int m_PartnerNkId_OUT;
      int m_PartnerType_OUT;
      int m_PreBurntImsi_OUT;
      int m_AllocationType_OUT;
      int m_AllocationStatus_OUT;
      int m_SubscriberStatus_OUT;
      int m_LocalImsiSubscription_OUT;
      int m_DynMsisdnMinFreeThreshold_OUT;

      unsigned int m_Odb_OUT;
      unsigned int m_HplmnOdb_OUT;
      unsigned int m_MmeSeqNum_OUT;
      unsigned int m_FreeCount_OUT;
      unsigned int m_PdpProfId_OUT;
      unsigned int m_ThresholdCount_OUT;
      unsigned int m_LteConfigProfId_OUT;
      unsigned int m_MsisdnFreeCount_OUT;
      unsigned int m_AccessRestriction_OUT;
      unsigned int m_TempMsisdnFreeCount_OUT;
      unsigned int m_TempMsisdnThreshCount_OUT;

      char m_AccountId_OUT[20 + 1];
      char m_RoamCC_OUT[HSS_CC_LEN + 1];
      char m_Msisdn_OUT[HSS_MSISDN_LEN + 1];
      char m_LocalImsi_OUT[HSS_IMSI_LEN + 1];
      char m_OldMsisdn_OUT[HSS_MSISDN_LEN + 1];
      char m_PrimaryImsi_OUT[HSS_IMSI_LEN + 1];
      char m_AlertMsisdn_OUT[HSS_MSISDN_LEN + 1];
      char m_LocalMsisdn_OUT[HSS_MSISDN_LEN + 1];
      char m_rowIdGsm_OUT[HSS_MAX_ROW_ID_LEN + 1];
      char m_rowIdGprs_OUT[HSS_MAX_ROW_ID_LEN + 1];
      char m_rowIdMme_OUT[HSS_MAX_ROW_ID_LEN + 1];
      char m_OldMmeHost_OUT[HSS_HOST_LEN + 1];
      char m_PrimaryMsisdn_OUT[HSS_MSISDN_LEN + 1];
      char m_LogPrefix_OUT[HSS_LOG_PREFIX_LEN + 1];
      char m_OldMmeRealm_OUT[HSS_REALM_LEN + 1];
      char m_SgsnNumber_OUT[HSS_SGSN_NUMBER_LEN + 1];
      char m_SgsnAddress_OUT[HSS_SGSN_ADDRESS_LEN + 1];
      char m_SimStructure_OUT[HSS_SIM_STRUCTURE_LEN + 1];
      char m_HssOriginHost_OUT[HSS_HOST_LEN + 1];
      char m_HssOriginRealm_OUT[HSS_REALM_LEN + 1];
      char m_HlrAddress_OUT[HSS_MAX_HLRADDR_LEN + 1];
      char m_AreaCodeBasedAllocInfo_OUT[100 + 1];
      char m_TrapCode_OUT[50+1];
      char m_TrapDesc_OUT[500+1];

      int                  m_ossTriggerDataCount_OUT;
      u8                   m_ossTriggerData_OUT[10][5000 + 1];

      u8 m_LocalRoamInfo_OUT[100 + 1];
      u8 m_TdrResrvData_OUT[100 + 1];

      u8 m_TdrRestrData_OUT[100 + 1];
      u8 m_TdrProfData_OUT[100 + 1];
      char m_generalTDRdata_OUT[500 + 1];

      unsigned int m_dsrFlag_OUT;
      char m_dsrContexts_OUT[100 + 1];

      int m_crossClType_OUT;
      char m_AltImsi_OUT[HSS_IMSI_LEN + 1];    //5054
      char m_IPAddress_OUT[100+1];
      int m_ImsProfId_OUT;
      int m_ims_service_flag_OUT;
      char m_Memcached_Parameters_OUT [1000 + 1];
      int m_ErrorCode_OUT;
      char m_ErrorMsg_OUT[HSS_ERRORMSG_LEN + 1];
      unsigned long int m_seconds;
      int m_Congestion_Cross_CL;
      int m_First_Roam_To_Home_Flag;
      char m_CC_Info[150+1];
      int m_updateMemcAfterDb;

      bool m_memcGETstatus;
      char m_StnSr_OUT[200+1]; //6.2.0.0
      char m_TemplateFtnInfo_OUT[50+1]; //6.2.0.0
      char m_TacInfo_OUT[20+1];//6.3.2.0
      
      u8 m_PreviousImei_OUT[40]; //6.3.4.0
      int m_ApnOiOverrideInd_OUT; //6.3.5.0
      int m_PrimaryIndicator_OUT; //6.4.2.0
      char m_DualImsiInfo_OUT[50+1]; //6.4.4.0
      char m_MnoProvisioningTdr_OUT[30+1]; //6.4.4.1
      int m_ulr_mpg_indicator_OUT; //6.4.4.1

      char m_MccMncWhitelist_OUT[10+1];//6.4.0.0
      s8 m_SarIpv4Address_OUT[39 + 1];
      s8 m_SarIpv6Address_OUT[39 + 1];
      s8 m_SarPgwHost_OUT[200 + 1];
      s8 m_SarPgwRealm_OUT[200 + 1];
      int m_roamImsiBlacKInd_OUT;
      char m_voLteRoamingCap_OUT[30+1];
      char m_migrationHelperTdr_OUT[100+1];
      bool executeQuery(void*);

};

/* dil added for slh */
class Slh_db_data : public DbQueryMsg
{
   public:
      Slh_db_data();

      /* input variables */
      char d_LcsIMSI[HSS_IMSI_LEN + 1];
      char d_LcsMSISDN[HSS_MSISDN_LEN + 1];
      char d_GMLCnumber[SLH_GMLC_LEN + 1];
      int d_flag_type;

      /* output variables */
      char d_LcsIMSI_OUT[HSS_IMSI_LEN + 1];
      char d_LcsMSISDN_OUT[HSS_MSISDN_LEN + 1];
      unsigned char d_LcsLMSI[SLH_LMSI_LEN + 1];
      int d_Lmsi_len;

      /* serving node */
      char d_MmeName[SLH_MME_NAME_LEN + 1];
      char d_MmeHost[HSS_HOST_LEN + 1];
      char d_MmeRealm[HSS_REALM_LEN + 1];
      char d_MSCnumber[SLH_MSC_ADD_LEN + 1];
      char d_SGSNnumber[HSS_SGSN_NUMBER_LEN + 1];
      char d_GmlcAddress[HSS_GMLC_ADDRESS_LEN + 1];
      int d_SuppLcsCAPset;
      char d_HssOriginHost[HSS_HOST_LEN + 1];
      char d_HssOriginRealm[HSS_REALM_LEN + 1];
      int d_ErrorCode_OUT;
      char d_ErrorMsg_OUT[HSS_ERRORMSG_LEN + 1];

      /* additional inputs for proc */
      int d_part_net_id;
      int d_net_id;
      char d_Act_imsi[HSS_IMSI_LEN + 1];
      int d_part_type;
      char d_Act_msisdn[HSS_MSISDN_LEN + 1];
      char d_Vlr_number[SLH_MSC_ADD_LEN + 1];
      char d_HLR_address[SLH_HLR_ADD_LEN + 1];
      int d_ps_lcs;


      bool executeQuery(void*);

};


typedef struct 
{
      char  m_rowId[MAX_ROW_ID_LEN+1];
      char  m_transId[20+1];
      int   m_opCode;
      char  m_transXml[4000+1];
}OssTriggerData_ULR;

class CheckForCancelLocations: public DbQueryMsg
{
   public:
      char m_UlrImsi_IN[HSS_IMSI_LEN + 1];
      int m_NetworkId_OUT;
      char m_AccountId_OUT[20 + 1];

      CheckForCancelLocations();
      virtual ~CheckForCancelLocations();

      bool executeQuery(void*);

      //outputs
      int m_ossTriggerDataCount;
      OssTriggerData_ULR m_ossTriggerDataArray[MAX_OSS_TRIGGER_DATA];
};

#endif
