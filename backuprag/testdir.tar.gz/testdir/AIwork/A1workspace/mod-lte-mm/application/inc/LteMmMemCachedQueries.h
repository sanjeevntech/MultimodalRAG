#ifndef __LTE_MM_MEMC_QUERIES_H
#define __LTE_MM_MEMC_QUERIES_H

class LteMmMemCachedQueries
{
   public:
      LteMmMemCachedQueries();
      ~LteMmMemCachedQueries();
};

extern bool IsSubscriberOtherImsi(char* pImsi);

#endif

