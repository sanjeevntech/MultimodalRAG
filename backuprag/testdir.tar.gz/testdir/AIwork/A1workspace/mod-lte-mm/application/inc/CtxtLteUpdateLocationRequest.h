#ifndef __HSS_MM_ULR_ULA_H
#define __HSS_MM_ULR_ULA_H

#include <ContextBase.h>
#include <MapMessages.h>
#include <MapConstants.h>
#include <Msg.h>
#include <LteMmDbQueries.h>
#include <LteCommonDefines.h>
#include <UpdateLocation.h>
#include <S6a_r10AVP.h>
#include <DiameterMessages.h>

#include <SubsProfileData.h>
#include <DiametriqInterface.h>

#include <InsertSubscriberData.h>
//#include<CtxtLteInsertSubscriberDataRequest.h>
//#include<../../../mod-lte-si/application/inc/CtxtLteInsertSubscriberDataRequest.h>
#define VENDOR_FEATURE_ID    10415

#define F1_ODB_ALL_APN                                                  0x00000001
#define F1_ODB_HPLMN_APN                                                0x00000002
#define F1_ODB_VPLMN_APN                                                0x00000004
#define F1_ODB_ALL_OG                                                   0x00000008
#define F1_ODB_ALL_InternationalOG                                      0x00000010
#define F1_ODB_ALL_InternationalOG_NotToHPLMNCountry                    0x00000020
#define F1_ODB_ALL_InterzonalOG                                         0x00000040
#define F1_ODB_ALL_InterzonalOG_NotToHPLMNCountry                       0x00000080
#define F1_ODB_ALL_InterzonalOG_And_InternationalOG_NotToHPLMNCountry   0x00000100
#define F1_RegSub                                                       0x00000200
#define F1_Trace                                                        0x00000400
#define F1_LCS_ALL_PrivExcep                                            0x00000800
#define F1_LCS_Universal                                                0x00001000
#define F1_LCS_CALL_SessionRelated                                      0x00002000
#define F1_LCS_CALL_SessionUnrelated                                    0x00004000
#define F1_LCS_PLMNOperator                                             0x00008000
#define F1_LCS_ServiceType                                              0x00010000
#define F1_LCS_ALL_MOLRSS                                               0x00020000
#define F1_LCS_BasicSelfLocation                                        0x00040000
#define F1_LCS_AutonomousSelfLocation                                   0x00080000
#define F1_LCS_TransferToThirdParty                                     0x00100000
#define F1_SMMOPP                                                       0x00200000
#define F1_BarringOutgoingCalls                                         0x00400000
#define F1_BAOC                                                         0x00800000
#define F1_BOIC                                                         0x01000000
#define F1_BOICExHC                                                     0x02000000
#define F1_UEReachabilityNotification                                   0x04000000
#define F1_TADS_Data_Retrieval                                          0x08000000
#define F1_State_LocationInformationRetrieval                           0x10000000
#define F1_Partial_Purge                                                0x20000000
#define F1_Local_Time_Zone_Retrieval                                    0x40000000
#define F1_Additional_MSISDN                                            0x80000000

#define F2_SMS_in_MME                                                   0x00000001
#define F2_SMS_in_SGSN                                                  0x00000002
#define F2_DiaLCS_ALL_PrivExcep                                         0x00000004
#define F2_DiaLCS_Universal                                             0x00000008
#define F2_DiaLCS_CALL_SessionRelated                                   0x00000010
#define F2_DiaLCS_CALL_SessionUnrelated                                 0x00000020
#define F2_DiaLCS_PLMNOperator                                          0x00000040
#define F2_DiaLCS_ServiceType                                           0x00000080
#define F2_DiaLCS_ALL_MOLRSS                                            0x00000100
#define F2_DiaLCS_BasicSelfLocation                                     0x00000200
#define F2_DiaLCS_AutonomousSelfLocation                                0x00000400
#define F2_DiaLCS_TransferToThirdParty                                  0x00000800
#define F2_EXTENDED_FEATURES                                            0xFFFFF000

#define HSS_3GPPCHARGINGCHAR_LEN                 2

#define F2_NR_AS_SECONDARY_RAT                                          0x08000000
using namespace diameter::s6a_r10;
using namespace diameter::base;

extern int g_EmergencyFlag;

enum ENodeTypeIndicator
{
   NODETYPE_MME = 1,
   NODETYPE_SGSN = 2,
   NODETYPE_MMESGSN = 3,

   NODETYPE_UNKNOWN
};

enum EErrorDiagnostic
{
   ERROR_DIAGNOSTIC_NOT_REQUIRED = -1,
   ERROR_DIAGNOSTIC_GPRS_DATA_SUBSCRIBED = 0,
   ERROR_DIAGNOSTIC_NO_GPRS_DATA_SUBSCRIBED,
   ERROR_DIAGNOSTIC_ODB_ALL_APN,
   ERROR_DIAGNOSTIC_ODB_HPLMN_APN,
   ERROR_DIAGNOSTIC_ODB_VPLMN_APN
};

typedef struct VendorIdFeatureList
{
   unsigned int m_vendorId;
   unsigned int m_featureList;
   unsigned int m_featureListId;
};

typedef struct TerminalInfoCopy
{
   char m_Imei[HSS_IMEI_LEN + 1];
   char m_SoftwareVersion[HSS_IMEI_SOFTWARE_VERSION_LEN + 1];

   unsigned char m_3gpp2Meid[HSS_3GPP2_MEID_LEN + 1];
};

typedef struct SpecificApnDetails
{
   char m_VisitedNetworkId[HSS_VISITED_NETWORK_ID_LEN + 1];
   char m_MIP6HomeLinkPrefix[HSS_MIP6_HOME_LINK_PREFIX_LEN + 1];
   char m_AgentRealm[HSS_REALM_LEN + 1];
   char m_AgentHost[HSS_HOST_LEN + 1];
   char m_MipHomeAgentAddress2[HSS_MIP6AI_HA_ADDR_LEN + 1];
   int m_MipHomeAgentFamily2;
   char m_MipHomeAgentAddress1[HSS_MIP6AI_HA_ADDR_LEN + 1];
   int m_MipHomeAgentFamily1;
   char m_ServiceSelection[HSS_SERVICE_SELECTION_LEN + 1];
};

typedef struct ActiveApnDetails
{
   int m_ContextId;
   SpecificApnDetails m_baseApn;
   list<SpecificApnDetails> m_SpecificApnList;
};

class CtxtLteUpdateLocationRequest : public ContextBase
{
   private:

   public:
      CtxtLteUpdateLocationRequest();
      virtual ~CtxtLteUpdateLocationRequest();

      bool m_S6aS6dInd;
      bool m_Single_Reg_Ind;
      bool m_Initial_Attach_Ind;

      int m_RatType;
      int m_HsImsPs;
      int m_UeSrvccCap;
      int m_GmlcFamily;

      unsigned int m_UlrFlag;
      unsigned int m_featureList1;
      unsigned int m_featureList2;

      ENodeTypeIndicator m_nodeTypeInd;
      TerminalInfoCopy m_terminalInformation;

      char m_UlrImsi[HSS_IMSI_LEN + 1];
      char m_SgsnNumber[HSS_SGSN_NUMBER_LEN + 1];
      char m_GmlcAddress[HSS_GMLC_ADDRESS_LEN + 1];
      char m_MmeHost[HSS_HOST_LEN + 1];
      char m_MmeRealm[HSS_REALM_LEN + 1];
      
      unsigned char m_VplmnId[HSS_VPLMNID_LEN + 1];

      LteSubsDbData *mp_HssSubsData;
      Msg *m_MessagePtr;

      list<ActiveApnDetails> m_ActiveApnList;
      list<VendorIdFeatureList> m_vendorIdFeatureList;

      bool m_5gSupportFlag;
      bool m_hlr_5gSupportFlag;

      string m_IPv4Addr;   //5054
      string m_IPv6Addr;   //5054
      bool m_fIdr;
      string m_DataString;
      char m_TransId[21];
      bool m_odbDataSend;
      unsigned int m_modifyOdb;
      int m_IdrFlag;
      unsigned char m_Orig_Imei[40];
      
      bool sendULA();
      bool checkULR();
      void LogULRFlags();
      bool handleDbQuery();
      bool SendCancelLocation();
      bool handleDBResponse();
      void LogSupportedFeatures();
      bool processMessage(Msg *p_MsgPtr,bool &p_DeleteFlag);
      bool handleError(unsigned int aErrCode, EErrorDiagnostic aEd);
      //bool handleError(EDiameterExperimentalResultCode aErrCode, EErrorDiagnostic aEd);
      bool FillSubscriptionData(LteConfigProf* aLteConfigProf, SubscriptionData aSubscriptionData);
      bool FillLteConfigurationProfile(LteConfigProf* aLteConfigProf, APNConfigurationProfile aApnConfProf);
      bool startProcessing(InterModuleData *p_imd,bool &p_DeleteFlag);
      bool SendIdr();
      bool requireSendCancelLoc(InsertSubscriberDataAnswer *p_answer);
};


#endif
