#ifndef __HSS_MM_SIM_CONFIG_READER_H
#define __HSS_MM_SIM_CONFIG_READER_H

#include <ConfigReader.h>
#include <SubsProfileData.h>
#include <HlrTdrFiller.h>

using namespace std;

typedef unsigned char   u8;

class LteMmSimConfigReader: public ConfigReader
{

   public:
      int m_UlrFlags;
      int m_SuppFeature1;
      int m_SuppFeature2;
      char m_UlrImsi[15 + 1];
      char m_VplmnId[6 + 1];
      int m_RatType;
      char m_Meid[16 + 1];
      int m_ActiveApnRequired;
      char m_gmlc[20];
      LteMmSimConfigReader();
      ~LteMmSimConfigReader();
      void printConfigData(char *p_output);
      bool readData();
};


extern LteMmSimConfigReader *g_LteMmSimConfigReaderObj;
extern bool DeclareFunc(int p_version, int p_pdu, void *p_struct);
#endif
