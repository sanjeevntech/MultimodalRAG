#ifndef __HSS_SIM_MM_ULR_ULA_H
#define __HSS_SIM_MM_ULR_ULA_H

#include <ContextBase.h>
#include <MapMessages.h>
#include <MapConstants.h>
#include <Msg.h>
#include <LteMmDbQueries.h>
#include <LteCommonDefines.h>
#include <UpdateLocation.h>
#include <S6a_r10AVP.h>
#include <DiameterMessages.h>

#include <SubsProfileData.h>
#include <DiametriqInterface.h>


using namespace diameter::s6a_r10;
using namespace diameter::base;

class HssSimMmUpdateLocation : public ContextBase
{
   private:

   public:
      HssSimMmUpdateLocation();
      virtual ~HssSimMmUpdateLocation();

      bool startProcessing();
      bool processMessage(Msg *p_MsgPtr,bool &p_DeleteFlag);
};


#endif
