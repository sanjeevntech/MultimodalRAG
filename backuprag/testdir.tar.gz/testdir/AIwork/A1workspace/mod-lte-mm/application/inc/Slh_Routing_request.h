#ifndef _HSS_SRI_LCS_H
#define _HSS_SRI_LCS_H

#include <ContextBase.h>
#include <MapMessages.h>
#include <MapConstants.h>
#include <Msg.h>
#include <LteMmDbQueries.h>
#include <LteCommonDefines.h>
#include <UpdateLocation.h>
#include <S6a_r10AVP.h>
#include <DiameterMessages.h>

#include <SubsProfileData.h>
#include <DiametriqInterface.h>

/* diameter files for slh */
#include <LcsRoutingInfo.h>
#include <Slh_rel_10AVP.h>


class SLH_routing_info: public ContextBase
{
   private:

   public:
   SLH_routing_info();
   virtual ~SLH_routing_info();
   
   char m_LcsIMSI[HSS_IMSI_LEN + 1];
   char m_LcsMSISDN[HSS_MSISDN_LEN + 1];
   char m_GmlcNumber[SLH_GMLC_LEN + 1];

   char m_LcsLMSI[SLH_LMSI_LEN + 1];

   /* serving node grouped avp */
   char m_MmeName[HSS_REALM_LEN + 1];
   char m_MmeHost[HSS_HOST_LEN + 1];
   char m_MmeRealm[HSS_REALM_LEN + 1];
   char m_MSCnumber[SLH_MSC_ADD_LEN + 1];
   char m_SGSNnumber[HSS_SGSN_NUMBER_LEN + 1];
   char m_GmlcAddress[HSS_GMLC_ADDRESS_LEN + 1];
   char m_OrigHost[HSS_HOST_LEN + 1];
   char m_OrigRealm[HSS_REALM_LEN + 1];
   bool YES_IMSI;
 
   Msg *m_MessagePtr;
   Slh_db_data *m_slh_usrData;

   bool check_RIR();
   bool send_RIA();
   bool handleSlhDbQuery();
   bool handleError(unsigned int aErrCode);
   bool processMessage(Msg *p_MsgPtr,bool &p_DeleteFlag);
   bool handleSlhDBResponse();


};

/* MME name parse function */
void set_SlhMmename(char *mmehost, char *mmename, char *mmerealm,char* slh_MmeNname);

#endif
