#ifndef __HSS_SIM_MM_RIR_RIA_H
#define __HSS_SIM_MM_RIR_RIA_H

#include <ContextBase.h>
#include <MapMessages.h>
#include <MapConstants.h>
#include <Msg.h>
#include <LteMmDbQueries.h>
#include <LteCommonDefines.h>
//#include <UpdateLocation.h>
//#include <S6a_r10AVP.h>
#include <DiameterMessages.h>

#include <SubsProfileData.h>
#include <DiametriqInterface.h>

#include <LcsRoutingInfo.h>
#include <Slh_rel_10AVP.h>

//using namespace diameter::s6a_r10;
using namespace diameter::base;
using namespace diameter::slh_rel_10;

class RIRSimulator : public ContextBase
{
   private:

   public:
      RIRSimulator();
      virtual ~RIRSimulator();

      bool startProcessing();
      bool processMessage(Msg *p_MsgPtr,bool &p_DeleteFlag);
};


#endif
