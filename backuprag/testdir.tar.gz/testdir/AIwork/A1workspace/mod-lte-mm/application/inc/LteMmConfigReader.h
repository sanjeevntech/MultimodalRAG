#ifndef __HSS_MM_CONFIG_READER_H
#define __HSS_MM_CONFIG_READER_H

#include <ConfigReader.h>
#include <SubsProfileData.h>
#include <HlrTdrFiller.h>

using namespace std;

typedef unsigned char   u8;

class LteMmConfigReader: public ConfigReader
{

   public:
      int m_UlrRejectCode;
      int m_MinFreeMsisdnThreshold;
      int m_ActiveApnUpdateFlag;
      int m_ULRMemcachedFlag;
      int m_ULRMemcachedRecordTime;
      int m_ULRAccessRestriction;
      LteMmConfigReader();
      ~LteMmConfigReader();
      void printConfigData(char *p_output);
      bool readData();
};


extern LteMmConfigReader *g_LteMmConfigReaderObj;
extern bool DeclareFunc(int p_version, int p_pdu, void *p_struct);
#endif
