#define private public

#include"gtest.h"
#include <CtxtLteUpdateLocationRequest.h>
#include <stdio.h>
#include <MapMessages.h>
#include <ServiceCoordinator.h>
#include <ExtendedServiceCoordinator.h>
#include <Logger.h>
#include <DataUnion.h>
#include <DbActiveObject.h>
#include <Utilities.h>
#include <LteCommonDefines.h>
#include <LteMmConfigReader.h>
#include <Utilities.h>
#include <SnmpInterface.h>

#include <DiameterConstants.h>
#include <DiametriqInterface.h>
#include <CommonData.h>
#include<Msg.h>
#include<HssSubsProfileData.h>
//#include<S6dAVP.h>
#include<DiameterMessages.h>
#include<LteMmDbQueries.h>
#include <diameter/AVP.h>
#include<SubsProfileData.h>
#include "SubsProfileData.h"
#include "CommonData.h"
#include<DbQueryMsg.h>


extern int g_FreeMsisdnRemainingTrap;
extern int g_TransientMsisdnUnavailableTrap;
extern int g_TransientMsisdnThresholdTrap;
extern int g_LocalMsisdnUnavailableTrap;
extern int g_LocalMsisdnThresholdTrap;
extern int g_DynamicAllocFailTrap;
extern getPartnerLteProfId(unsigned int p_LteProfId, int p_NkId, int p_PartnerNkId);

using namespace diameter::s6a_r10;
using namespace diameter::base;
namespace diameter { namespace s6a_r10 {
class SubscriptionData;
} }

class UT_CtxtLteUpdateLocationRequest: public testing::Test , public CtxtLteUpdateLocationRequest
{public:
UT_CtxtLteUpdateLocationRequest()
{
}
~UT_CtxtLteUpdateLocationRequest()
{
}
};

class UT_Msg
{public:
UT_Msg()
{
}
~UT_Msg()
{
}
};

class UT_DbQueryMsg
{public:
UT_DbQueryMsg()
{
}
~UT_DbQueryMsg()
{
}
};


class UT_SubsProfileData
{public:
UT_SubsProfileData()
{
}
~UT_SubsProfileData()
{
}
};

class UT_LteSubsDbData
{public:
UT_LteSubsDbData()
{
}
~UT_LteSubsDbData()
{
}
};

class UT_APNConfigurationProfile 
{public:
UT_APNConfigurationProfile ()
{
}
~UT_APNConfigurationProfile ()
{
}
};

class UT_DiameterMsg
{public:
UT_DiameterMsg()
{
}
~UT_DiameterMsg()
{
}
};

/****************************************************************/
/*
//New comment
TEST(CtxtLteUpdateLocationRequest_cpp_getPartnerLteProfId_Func, Return_int) {
unsigned int p_LteProfId=1;
int p_NkId=1;
int p_PartnerNkId=1;
g_spd=new GlobalData;
EXPECT_NE(getPartnerLteProfId(p_LteProfId,p_NkId,p_PartnerNkId),1);
}
*/
/******************************************************/
TEST_F(UT_CtxtLteUpdateLocationRequest,LogULRFlags_Func) {
CtxtLteUpdateLocationRequest::m_UlrFlag=0x01;
EXPECT_NO_THROW(LogULRFlags());
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogULRFlags_Two_Func) {
CtxtLteUpdateLocationRequest *ptr=new CtxtLteUpdateLocationRequest;
ptr->m_UlrFlag=0x02;
EXPECT_NO_THROW(LogULRFlags());
delete ptr;
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogULRFlags_Three_Func) {
CtxtLteUpdateLocationRequest *ptr=new CtxtLteUpdateLocationRequest;
ptr->m_UlrFlag=0x04;
EXPECT_NO_THROW(LogULRFlags());
delete ptr;
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogULRFlags_Four_Func) {
CtxtLteUpdateLocationRequest *ptr=new CtxtLteUpdateLocationRequest;
ptr->m_UlrFlag=0x08;
EXPECT_NO_THROW(LogULRFlags());
delete ptr;
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogULRFlags_Five_Func) {
CtxtLteUpdateLocationRequest *ptr=new CtxtLteUpdateLocationRequest;
ptr->m_UlrFlag=0x10;
EXPECT_NO_THROW(LogULRFlags());
delete ptr;
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogULRFlags_else_Func) {
CtxtLteUpdateLocationRequest *ptr=new CtxtLteUpdateLocationRequest;
ptr->m_UlrFlag=0x11;
ptr->m_S6aS6dInd=true;
EXPECT_NO_THROW(LogULRFlags());
delete ptr;
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogULRFlags_0x20_Func) {
CtxtLteUpdateLocationRequest *ptr=new CtxtLteUpdateLocationRequest;
ptr->m_UlrFlag=0x20;
EXPECT_NO_THROW(LogULRFlags());
delete ptr;
}
/*
TEST_F(UT_CtxtLteUpdateLocationRequest,LogULRFlags_0x40_Func) {
CtxtLteUpdateLocationRequest *ptr=new CtxtLteUpdateLocationRequest;
ptr->m_UlrFlag=0x40;
EXPECT_NO_THROW(LogULRFlags());
delete ptr;
}
*/

/*
TEST_F(UT_CtxtLteUpdateLocationRequest,LogULRFlags_Two_Func) {
CtxtLteUpdateLocationRequest::m_UlrFlag=0x02;
EXPECT_NO_THROW(LogULRFlags());
}
*/
/*********************************************************/

TEST_F(UT_CtxtLteUpdateLocationRequest,LogSupportedFeatures_Func) {
EXPECT_NO_THROW(LogSupportedFeatures());
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogSupportedFeatures_F1_ODB_ALL_APN_Func) {
VendorIdFeatureList objVendorIdFeatureList;
objVendorIdFeatureList.m_vendorId=10415;
objVendorIdFeatureList.m_featureList=0x00000001;
objVendorIdFeatureList.m_featureListId=1;
m_RatType=1;
//list<VendorIdFeatureList>m_vendorIdFeatureList;
m_vendorIdFeatureList.push_back(objVendorIdFeatureList);
EXPECT_NO_THROW(LogSupportedFeatures());
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogSupportedFeatures_F1_ODB_ALL_APN_Two_Func) {
VendorIdFeatureList *objVendorIdFeatureList=new VendorIdFeatureList;
objVendorIdFeatureList->m_vendorId=10415;
objVendorIdFeatureList->m_featureList=0x00000001;
objVendorIdFeatureList->m_featureListId=1;
//list<VendorIdFeatureList>m_vendorIdFeatureList;
//m_vendorIdFeatureList.push_back(&objVendorIdFeatureList);
EXPECT_NO_THROW(LogSupportedFeatures());
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogSupportedFeatures_F1_ODB_HPLMN_AP_Func) {
VendorIdFeatureList objVendorIdFeatureList;
objVendorIdFeatureList.m_vendorId=10415;
objVendorIdFeatureList.m_featureList=0x00000002;
objVendorIdFeatureList.m_featureListId=1;
EXPECT_NO_THROW(LogSupportedFeatures());
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogSupportedFeatures_F1_ODB_HPLMN_APN_Func) {
VendorIdFeatureList objVendorIdFeatureList;
objVendorIdFeatureList.m_vendorId=10415;
objVendorIdFeatureList.m_featureList=0x00000002;
objVendorIdFeatureList.m_featureListId=1;
m_vendorIdFeatureList.push_back(objVendorIdFeatureList);
EXPECT_NO_THROW(LogSupportedFeatures());
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogSupportedFeatures_F1_ODB_VPLMN_APN_Func) {
VendorIdFeatureList objVendorIdFeatureList;
objVendorIdFeatureList.m_vendorId=10415;
objVendorIdFeatureList.m_featureList=0x00000004;
objVendorIdFeatureList.m_featureListId=1;
m_vendorIdFeatureList.push_back(objVendorIdFeatureList);
EXPECT_NO_THROW(LogSupportedFeatures());
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogSupportedFeatures_F1_ODB_ALL_OG_Func) {
VendorIdFeatureList objVendorIdFeatureList;
objVendorIdFeatureList.m_vendorId=10415;
objVendorIdFeatureList.m_featureList=0x00000008;
objVendorIdFeatureList.m_featureListId=1;
m_vendorIdFeatureList.push_back(objVendorIdFeatureList);
EXPECT_NO_THROW(LogSupportedFeatures());
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogSupportedFeatures_F1_ODB_ALL_InternationalOG_Func) {
VendorIdFeatureList objVendorIdFeatureList;
objVendorIdFeatureList.m_vendorId=10415;
objVendorIdFeatureList.m_featureList=0x00000010;
objVendorIdFeatureList.m_featureListId=1;
m_vendorIdFeatureList.push_back(objVendorIdFeatureList);
EXPECT_NO_THROW(LogSupportedFeatures());
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogSupportedFeatures_F1_ODB_ALL_InternationalOG_NotToHPLMNCountry_Func) {
VendorIdFeatureList objVendorIdFeatureList;
objVendorIdFeatureList.m_vendorId=10415;
objVendorIdFeatureList.m_featureList=0x00000020;
objVendorIdFeatureList.m_featureListId=1;
m_vendorIdFeatureList.push_back(objVendorIdFeatureList);
EXPECT_NO_THROW(LogSupportedFeatures());
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogSupportedFeatures_F1_ODB_ALL_InterzonalOG_Func) {
VendorIdFeatureList objVendorIdFeatureList;
objVendorIdFeatureList.m_vendorId=10415;
objVendorIdFeatureList.m_featureList=0x00000040;
objVendorIdFeatureList.m_featureListId=1;
m_vendorIdFeatureList.push_back(objVendorIdFeatureList);
EXPECT_NO_THROW(LogSupportedFeatures());
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogSupportedFeatures_F1_ODB_ALL_InterzonalOG_NotToHPLMNCountry_Func) {
VendorIdFeatureList objVendorIdFeatureList;
objVendorIdFeatureList.m_vendorId=10415;
objVendorIdFeatureList.m_featureList=0x00000080;
objVendorIdFeatureList.m_featureListId=1;
m_vendorIdFeatureList.push_back(objVendorIdFeatureList);
EXPECT_NO_THROW(LogSupportedFeatures());
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogSupportedFeatures_F1_ODB_ALL_InterzonalOG_And_InternationalOG_NotToHPLMNCountry_Func) {
VendorIdFeatureList objVendorIdFeatureList;
objVendorIdFeatureList.m_vendorId=10415;
objVendorIdFeatureList.m_featureList=0x00000100;
objVendorIdFeatureList.m_featureListId=1;
m_vendorIdFeatureList.push_back(objVendorIdFeatureList);
EXPECT_NO_THROW(LogSupportedFeatures());
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogSupportedFeatures_F1_RegSub_Func) {
VendorIdFeatureList objVendorIdFeatureList;
objVendorIdFeatureList.m_vendorId=10415;
objVendorIdFeatureList.m_featureList=0x00000200;
objVendorIdFeatureList.m_featureListId=1;
m_vendorIdFeatureList.push_back(objVendorIdFeatureList);
EXPECT_NO_THROW(LogSupportedFeatures());
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogSupportedFeatures_F1_Trace_Func) {
VendorIdFeatureList objVendorIdFeatureList;
objVendorIdFeatureList.m_vendorId=10415;
objVendorIdFeatureList.m_featureList=0x00000400;
objVendorIdFeatureList.m_featureListId=1;
m_vendorIdFeatureList.push_back(objVendorIdFeatureList);
EXPECT_NO_THROW(LogSupportedFeatures());
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogSupportedFeatures_F1_LCS_ALL_PrivExcep_Func) {
VendorIdFeatureList objVendorIdFeatureList;
objVendorIdFeatureList.m_vendorId=10415;
objVendorIdFeatureList.m_featureList=0x00000800;
objVendorIdFeatureList.m_featureListId=1;
m_vendorIdFeatureList.push_back(objVendorIdFeatureList);
EXPECT_NO_THROW(LogSupportedFeatures());
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogSupportedFeatures_F1_LCS_Universal_Func) {
VendorIdFeatureList objVendorIdFeatureList;
objVendorIdFeatureList.m_vendorId=10415;
objVendorIdFeatureList.m_featureList=0x00001000;
objVendorIdFeatureList.m_featureListId=1;
m_vendorIdFeatureList.push_back(objVendorIdFeatureList);
EXPECT_NO_THROW(LogSupportedFeatures());
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogSupportedFeatures_F1_LCS_CALL_SessionRelated_Func) {
VendorIdFeatureList objVendorIdFeatureList;
objVendorIdFeatureList.m_vendorId=10415;
objVendorIdFeatureList.m_featureList=0x00002000;
objVendorIdFeatureList.m_featureListId=1;
m_vendorIdFeatureList.push_back(objVendorIdFeatureList);
EXPECT_NO_THROW(LogSupportedFeatures());
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogSupportedFeatures_F1_LCS_CALL_SessionUnrelated_Func) {
VendorIdFeatureList objVendorIdFeatureList;
objVendorIdFeatureList.m_vendorId=10415;
objVendorIdFeatureList.m_featureList=0x00004000;
objVendorIdFeatureList.m_featureListId=1;
m_vendorIdFeatureList.push_back(objVendorIdFeatureList);
EXPECT_NO_THROW(LogSupportedFeatures());
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogSupportedFeatures_F1_LCS_PLMNOperator_Func) {
VendorIdFeatureList objVendorIdFeatureList;
objVendorIdFeatureList.m_vendorId=10415;
objVendorIdFeatureList.m_featureList=0x00008000;
objVendorIdFeatureList.m_featureListId=1;
m_vendorIdFeatureList.push_back(objVendorIdFeatureList);
EXPECT_NO_THROW(LogSupportedFeatures());
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogSupportedFeatures_F1_LCS_ServiceType_Func) {
VendorIdFeatureList objVendorIdFeatureList;
objVendorIdFeatureList.m_vendorId=10415;
objVendorIdFeatureList.m_featureList=0x00010000;
objVendorIdFeatureList.m_featureListId=1;
m_vendorIdFeatureList.push_back(objVendorIdFeatureList);
EXPECT_NO_THROW(LogSupportedFeatures());
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogSupportedFeatures_F1_LCS_ALL_MOLRSS_Func) {
VendorIdFeatureList objVendorIdFeatureList;
objVendorIdFeatureList.m_vendorId=10415;
objVendorIdFeatureList.m_featureList=0x00020000;
objVendorIdFeatureList.m_featureListId=1;
m_vendorIdFeatureList.push_back(objVendorIdFeatureList);
EXPECT_NO_THROW(LogSupportedFeatures());
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogSupportedFeatures_F1_LCS_BasicSelfLocation_Func) {
VendorIdFeatureList objVendorIdFeatureList;
objVendorIdFeatureList.m_vendorId=10415;
objVendorIdFeatureList.m_featureList=0x00040000;
objVendorIdFeatureList.m_featureListId=1;
m_vendorIdFeatureList.push_back(objVendorIdFeatureList);
EXPECT_NO_THROW(LogSupportedFeatures());
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogSupportedFeatures_F1_LCS_AutonomousSelfLocation_Func) {
VendorIdFeatureList objVendorIdFeatureList;
objVendorIdFeatureList.m_vendorId=10415;
objVendorIdFeatureList.m_featureList=0x00080000;
objVendorIdFeatureList.m_featureListId=1;
m_vendorIdFeatureList.push_back(objVendorIdFeatureList);
EXPECT_NO_THROW(LogSupportedFeatures());
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogSupportedFeatures_F1_LCS_TransferToThirdParty_Func) {
VendorIdFeatureList objVendorIdFeatureList;
objVendorIdFeatureList.m_vendorId=10415;
objVendorIdFeatureList.m_featureList=0x00100000;
objVendorIdFeatureList.m_featureListId=1;
m_vendorIdFeatureList.push_back(objVendorIdFeatureList);
EXPECT_NO_THROW(LogSupportedFeatures());
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogSupportedFeatures_F1_SMMOPP_Func) {
VendorIdFeatureList objVendorIdFeatureList;
objVendorIdFeatureList.m_vendorId=10415;
objVendorIdFeatureList.m_featureList=0x00200000;
objVendorIdFeatureList.m_featureListId=1;
m_vendorIdFeatureList.push_back(objVendorIdFeatureList);
EXPECT_NO_THROW(LogSupportedFeatures());
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogSupportedFeatures_F1_BarringOutgoingCalls_Func) {
VendorIdFeatureList objVendorIdFeatureList;
objVendorIdFeatureList.m_vendorId=10415;
objVendorIdFeatureList.m_featureList=0x00400000;
objVendorIdFeatureList.m_featureListId=1;
m_vendorIdFeatureList.push_back(objVendorIdFeatureList);
EXPECT_NO_THROW(LogSupportedFeatures());
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogSupportedFeatures_F1_BAOC_Func) {
VendorIdFeatureList objVendorIdFeatureList;
objVendorIdFeatureList.m_vendorId=10415;
objVendorIdFeatureList.m_featureList=0x00800000;
objVendorIdFeatureList.m_featureListId=1;
m_vendorIdFeatureList.push_back(objVendorIdFeatureList);
EXPECT_NO_THROW(LogSupportedFeatures());
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogSupportedFeatures_F1_BOIC_Func) {
VendorIdFeatureList objVendorIdFeatureList;
objVendorIdFeatureList.m_vendorId=10415;
objVendorIdFeatureList.m_featureList=0x01000000;
objVendorIdFeatureList.m_featureListId=1;
m_vendorIdFeatureList.push_back(objVendorIdFeatureList);
EXPECT_NO_THROW(LogSupportedFeatures());
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogSupportedFeatures_F1_BOICExHC_Func) {
VendorIdFeatureList objVendorIdFeatureList;
objVendorIdFeatureList.m_vendorId=10415;
objVendorIdFeatureList.m_featureList=0x02000000;
objVendorIdFeatureList.m_featureListId=1;
m_vendorIdFeatureList.push_back(objVendorIdFeatureList);
EXPECT_NO_THROW(LogSupportedFeatures());
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogSupportedFeatures_F1_UEReachabilityNotification_Func) {
VendorIdFeatureList objVendorIdFeatureList;
objVendorIdFeatureList.m_vendorId=10415;
objVendorIdFeatureList.m_featureList=0x04000000;
objVendorIdFeatureList.m_featureListId=1;
m_vendorIdFeatureList.push_back(objVendorIdFeatureList);
EXPECT_NO_THROW(LogSupportedFeatures());
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogSupportedFeatures_F1_TADS_Data_Retrieval_Func) {
VendorIdFeatureList objVendorIdFeatureList;
objVendorIdFeatureList.m_vendorId=10415;
objVendorIdFeatureList.m_featureList=0x08000000;
objVendorIdFeatureList.m_featureListId=1;
m_vendorIdFeatureList.push_back(objVendorIdFeatureList);
EXPECT_NO_THROW(LogSupportedFeatures());
}


TEST_F(UT_CtxtLteUpdateLocationRequest,LogSupportedFeatures_F1_State_LocationInformationRetrieval_Func) {
VendorIdFeatureList objVendorIdFeatureList;
objVendorIdFeatureList.m_vendorId=10415;
objVendorIdFeatureList.m_featureList=0x10000000;
objVendorIdFeatureList.m_featureListId=1;
m_vendorIdFeatureList.push_back(objVendorIdFeatureList);
EXPECT_NO_THROW(LogSupportedFeatures());
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogSupportedFeatures_F1_Partial_Purge_Func) {
VendorIdFeatureList objVendorIdFeatureList;
objVendorIdFeatureList.m_vendorId=10415;
objVendorIdFeatureList.m_featureList=0x20000000;
objVendorIdFeatureList.m_featureListId=1;
m_vendorIdFeatureList.push_back(objVendorIdFeatureList);
EXPECT_NO_THROW(LogSupportedFeatures());
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogSupportedFeatures_F1_Local_Time_Zone_Retrieval_Func) {
VendorIdFeatureList objVendorIdFeatureList;
objVendorIdFeatureList.m_vendorId=10415;
objVendorIdFeatureList.m_featureList=0x40000000;
objVendorIdFeatureList.m_featureListId=1;
m_vendorIdFeatureList.push_back(objVendorIdFeatureList);
EXPECT_NO_THROW(LogSupportedFeatures());
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogSupportedFeatures_F1_Additional_MSISDN_Func) {
VendorIdFeatureList objVendorIdFeatureList;
objVendorIdFeatureList.m_vendorId=10415;
objVendorIdFeatureList.m_featureList=0x80000000;
objVendorIdFeatureList.m_featureListId=1;
m_vendorIdFeatureList.push_back(objVendorIdFeatureList);
EXPECT_NO_THROW(LogSupportedFeatures());
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogSupportedFeatures_2__Func) {
VendorIdFeatureList objVendorIdFeatureList;
objVendorIdFeatureList.m_vendorId=10415;
objVendorIdFeatureList.m_featureList=0x00000001;
objVendorIdFeatureList.m_featureListId=2;
m_vendorIdFeatureList.push_back(objVendorIdFeatureList);
EXPECT_NO_THROW(LogSupportedFeatures());
objVendorIdFeatureList.m_featureList=0x00000002;
EXPECT_NO_THROW(LogSupportedFeatures());
objVendorIdFeatureList.m_featureList=0x00000004;
EXPECT_NO_THROW(LogSupportedFeatures());
objVendorIdFeatureList.m_featureList=0x00000008;
EXPECT_NO_THROW(LogSupportedFeatures());
objVendorIdFeatureList.m_featureList=0x00000010;
EXPECT_NO_THROW(LogSupportedFeatures());
objVendorIdFeatureList.m_featureList=0x00000020;
EXPECT_NO_THROW(LogSupportedFeatures());
objVendorIdFeatureList.m_featureList=0x00000040;
EXPECT_NO_THROW(LogSupportedFeatures());
objVendorIdFeatureList.m_featureList=0x00000080;
EXPECT_NO_THROW(LogSupportedFeatures());
objVendorIdFeatureList.m_featureList=0x00000100;
EXPECT_NO_THROW(LogSupportedFeatures());
objVendorIdFeatureList.m_featureList=0x00000200;
EXPECT_NO_THROW(LogSupportedFeatures());
objVendorIdFeatureList.m_featureList=0x00000400;
EXPECT_NO_THROW(LogSupportedFeatures());
objVendorIdFeatureList.m_featureList=0x00000800;
EXPECT_NO_THROW(LogSupportedFeatures());
objVendorIdFeatureList.m_featureList=0x00001000;
EXPECT_NO_THROW(LogSupportedFeatures());
objVendorIdFeatureList.m_featureList=0x00002000;
EXPECT_NO_THROW(LogSupportedFeatures());
objVendorIdFeatureList.m_featureList=0x00004000;
EXPECT_NO_THROW(LogSupportedFeatures());
objVendorIdFeatureList.m_featureList=0x00008000;
EXPECT_NO_THROW(LogSupportedFeatures());
objVendorIdFeatureList.m_featureList=0x00010000;
EXPECT_NO_THROW(LogSupportedFeatures());
objVendorIdFeatureList.m_featureList=0x00020000;
EXPECT_NO_THROW(LogSupportedFeatures());
objVendorIdFeatureList.m_featureList=0x00040000;
EXPECT_NO_THROW(LogSupportedFeatures());
objVendorIdFeatureList.m_featureList=0x00080000;
EXPECT_NO_THROW(LogSupportedFeatures());
objVendorIdFeatureList.m_featureList=0x00100000;
EXPECT_NO_THROW(LogSupportedFeatures());
objVendorIdFeatureList.m_featureList=0x00200000;
EXPECT_NO_THROW(LogSupportedFeatures());
objVendorIdFeatureList.m_featureList=0x00400000;
EXPECT_NO_THROW(LogSupportedFeatures());
objVendorIdFeatureList.m_featureList=0x00800000;
EXPECT_NO_THROW(LogSupportedFeatures());
objVendorIdFeatureList.m_featureList=0x01000000;
EXPECT_NO_THROW(LogSupportedFeatures());
objVendorIdFeatureList.m_featureList=0x02000000;
EXPECT_NO_THROW(LogSupportedFeatures());
objVendorIdFeatureList.m_featureList=0x04000000;
EXPECT_NO_THROW(LogSupportedFeatures());
objVendorIdFeatureList.m_featureList=0x08000000;
EXPECT_NO_THROW(LogSupportedFeatures());
objVendorIdFeatureList.m_featureList=0x10000000;
EXPECT_NO_THROW(LogSupportedFeatures());
objVendorIdFeatureList.m_featureList=0x20000000;
EXPECT_NO_THROW(LogSupportedFeatures());
objVendorIdFeatureList.m_featureList=0x40000000;
EXPECT_NO_THROW(LogSupportedFeatures());
objVendorIdFeatureList.m_featureList=0x80000000;
EXPECT_NO_THROW(LogSupportedFeatures());
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogSupportedFeatures_3__Func) {
VendorIdFeatureList objVendorIdFeatureList;
objVendorIdFeatureList.m_vendorId=10415;
objVendorIdFeatureList.m_featureList=0x00000001;
objVendorIdFeatureList.m_featureListId=3;
m_vendorIdFeatureList.push_back(objVendorIdFeatureList);
EXPECT_NO_THROW(LogSupportedFeatures());
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogSupportedFeatures_else_Func) {
VendorIdFeatureList objVendorIdFeatureList;
objVendorIdFeatureList.m_vendorId=1;
objVendorIdFeatureList.m_featureList=0x00000001;
objVendorIdFeatureList.m_featureListId=3;
m_vendorIdFeatureList.push_back(objVendorIdFeatureList);
EXPECT_NO_THROW(LogSupportedFeatures());
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogSupportedFeatures_2_Func) {
VendorIdFeatureList objVendorIdFeatureList;
objVendorIdFeatureList.m_vendorId=10415;
objVendorIdFeatureList.m_featureList=0x00000002;
objVendorIdFeatureList.m_featureListId=2;
m_vendorIdFeatureList.push_back(objVendorIdFeatureList);
EXPECT_NO_THROW(LogSupportedFeatures());
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogSupportedFeatures_2_F2_DiaLCS_ALL_PrivExcep_Func) {
VendorIdFeatureList objVendorIdFeatureList;
objVendorIdFeatureList.m_vendorId=10415;
objVendorIdFeatureList.m_featureList=0x00000004;
objVendorIdFeatureList.m_featureListId=2;
m_vendorIdFeatureList.push_back(objVendorIdFeatureList);
EXPECT_NO_THROW(LogSupportedFeatures());
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogSupportedFeatures_2_F2_DiaLCS_Universal_Func) {
VendorIdFeatureList objVendorIdFeatureList;
objVendorIdFeatureList.m_vendorId=10415;
objVendorIdFeatureList.m_featureList=0x00000008;
objVendorIdFeatureList.m_featureListId=2;
m_vendorIdFeatureList.push_back(objVendorIdFeatureList);
EXPECT_NO_THROW(LogSupportedFeatures());
}


TEST_F(UT_CtxtLteUpdateLocationRequest,LogSupportedFeatures_2_F2_DiaLCS_CALL_SessionRelated_Func) {
VendorIdFeatureList objVendorIdFeatureList;
objVendorIdFeatureList.m_vendorId=10415;
objVendorIdFeatureList.m_featureList=0x00000010;
objVendorIdFeatureList.m_featureListId=2;
m_vendorIdFeatureList.push_back(objVendorIdFeatureList);
EXPECT_NO_THROW(LogSupportedFeatures());
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogSupportedFeatures_2_F2_DiaLCS_CALL_SessionUnrelated_Func) {
VendorIdFeatureList objVendorIdFeatureList;
objVendorIdFeatureList.m_vendorId=10415;
objVendorIdFeatureList.m_featureList=0x00000020;
objVendorIdFeatureList.m_featureListId=2;
m_vendorIdFeatureList.push_back(objVendorIdFeatureList);
EXPECT_NO_THROW(LogSupportedFeatures());
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogSupportedFeatures_2_F2_DiaLCS_PLMNOperator_Func) {
VendorIdFeatureList objVendorIdFeatureList;
objVendorIdFeatureList.m_vendorId=10415;
objVendorIdFeatureList.m_featureList=0x00000040;
objVendorIdFeatureList.m_featureListId=2;
m_vendorIdFeatureList.push_back(objVendorIdFeatureList);
EXPECT_NO_THROW(LogSupportedFeatures());
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogSupportedFeatures_2_F2_DiaLCS_ServiceType_Func) {
VendorIdFeatureList objVendorIdFeatureList;
objVendorIdFeatureList.m_vendorId=10415;
objVendorIdFeatureList.m_featureList=0x00000080;
objVendorIdFeatureList.m_featureListId=2;
m_vendorIdFeatureList.push_back(objVendorIdFeatureList);
EXPECT_NO_THROW(LogSupportedFeatures());
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogSupportedFeatures_2_F2_DiaLCS_ALL_MOLRSS_Func) {
VendorIdFeatureList objVendorIdFeatureList;
objVendorIdFeatureList.m_vendorId=10415;
objVendorIdFeatureList.m_featureList=0x00000100;
objVendorIdFeatureList.m_featureListId=2;
m_vendorIdFeatureList.push_back(objVendorIdFeatureList);
EXPECT_NO_THROW(LogSupportedFeatures());
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogSupportedFeatures_2_F2_DiaLCS_BasicSelfLocation_Func) {
VendorIdFeatureList objVendorIdFeatureList;
objVendorIdFeatureList.m_vendorId=10415;
objVendorIdFeatureList.m_featureList=0x00000200;
objVendorIdFeatureList.m_featureListId=2;
m_vendorIdFeatureList.push_back(objVendorIdFeatureList);
EXPECT_NO_THROW(LogSupportedFeatures());
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogSupportedFeatures_2_F2_DiaLCS_AutonomousSelfLocation_Func) {
VendorIdFeatureList objVendorIdFeatureList;
objVendorIdFeatureList.m_vendorId=10415;
objVendorIdFeatureList.m_featureList=0x00000400;
objVendorIdFeatureList.m_featureListId=2;
m_vendorIdFeatureList.push_back(objVendorIdFeatureList);
EXPECT_NO_THROW(LogSupportedFeatures());
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogSupportedFeatures_2_F2_DiaLCS_TransferToThirdParty_Func) {
VendorIdFeatureList objVendorIdFeatureList;
objVendorIdFeatureList.m_vendorId=10415;
objVendorIdFeatureList.m_featureList=0x00000800;
objVendorIdFeatureList.m_featureListId=2;
m_vendorIdFeatureList.push_back(objVendorIdFeatureList);
EXPECT_NO_THROW(LogSupportedFeatures());
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogSupportedFeatures_2_F2_EXTENDED_FEATURES_Func) {
VendorIdFeatureList objVendorIdFeatureList;
objVendorIdFeatureList.m_vendorId=10415;
objVendorIdFeatureList.m_featureList=0xFFFFF000;
objVendorIdFeatureList.m_featureListId=2;
m_vendorIdFeatureList.push_back(objVendorIdFeatureList);
EXPECT_NO_THROW(LogSupportedFeatures());
}

TEST_F(UT_CtxtLteUpdateLocationRequest,LogSupportedFeatures_2_F2_NR_AS_SECONDARY_RAT_Func) {
VendorIdFeatureList objVendorIdFeatureList;
objVendorIdFeatureList.m_vendorId=10415;
objVendorIdFeatureList.m_featureList=0x08000000;
objVendorIdFeatureList.m_featureListId=2;
m_vendorIdFeatureList.push_back(objVendorIdFeatureList);
EXPECT_NO_THROW(LogSupportedFeatures());
}

/**************************************************/
/*
//Working
TEST_F(UT_CtxtLteUpdateLocationRequest,handleDbQuery_Func) {
EXPECT_TRUE(handleDbQuery());
}
*/


/************************************************************/

TEST_F(UT_CtxtLteUpdateLocationRequest,SendCancelLocation_Func) {
//LteSubsDbData *ptr=new LteSubsDbData;
mp_HssSubsData=new LteSubsDbData;
strcpy(CtxtLteUpdateLocationRequest::m_MmeHost,"aaaaaaa");
strcpy(mp_HssSubsData->m_OldMmeHost_OUT,"aaaaaaa");
EXPECT_TRUE(SendCancelLocation());
//delete ptr;
}

TEST_F(UT_CtxtLteUpdateLocationRequest,SendCancelLocation_Two_Func) {
mp_HssSubsData=new LteSubsDbData;
strcpy(CtxtLteUpdateLocationRequest::m_MmeHost,"bbbbbbbbb");
strcpy(mp_HssSubsData->m_OldMmeHost_OUT,"aaaaaaa");
strcpy(mp_HssSubsData->m_HssOriginHost_OUT,"cccccccc");
CtxtLteUpdateLocationRequest::m_Initial_Attach_Ind=true;
EXPECT_TRUE(SendCancelLocation());
}

TEST_F(UT_CtxtLteUpdateLocationRequest,SendCancelLocation_else_Func) {
mp_HssSubsData=new LteSubsDbData;
strcpy(CtxtLteUpdateLocationRequest::m_MmeHost,"bbbbbbbbb");
strcpy(mp_HssSubsData->m_OldMmeHost_OUT,"aaaaaaa");
strcpy(mp_HssSubsData->m_HssOriginHost_OUT,"cccccccc");
CtxtLteUpdateLocationRequest::m_Initial_Attach_Ind=false;
EXPECT_TRUE(SendCancelLocation());
}
/**************************************************/
/*
TEST_F(UT_CtxtLteUpdateLocationRequest,FillSubscriptionData_Func) {
LteConfigProf obj;
SubscriptionData ptr;
//((SubsProfileData*)g_spd)=new GlobalData;
mp_HssSubsData=new LteSubsDbData;
g_spd=new GlobalData;
EXPECT_TRUE(FillSubscriptionData(&obj,ptr));
}
*/

/*TEST_F(UT_CtxtLteUpdateLocationRequest,FillSubscriptionData_Func) {
SubscriptionData ptr;
SubsProfileData *pt=new SubsProfileData;
ImsProf st;
st.m_imsProfId=1;
pt->m_imsProfMap.insert({1,st});
LteConfigProf *obj=new LteConfigProf;
g_spd=new GlobalData;
//((SubsProfileData*)g_spd)
mp_HssSubsData=new LteSubsDbData;
mp_HssSubsData->m_ImsProfId_OUT=1;
EXPECT_FALSE(FillSubscriptionData(obj,ptr));
delete obj;
delete pt;
}
*/
/*
TEST_F(UT_CtxtLteUpdateLocationRequest,FillSubscriptionData_Func) {
SubscriptionData ptr;
SubsProfileData *pt=new SubsProfileData;
}
*/
/**************************************************/
TEST_F(UT_CtxtLteUpdateLocationRequest,processMessage_MSG_TYPE_MAP_Func) {
g_IMEI_EncrFlag=1;
Msg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtLteUpdateLocationRequest,processMessage_MSG_TYPE_DIAMETER_Func) {
g_IMEI_EncrFlag=1;
Msg p_MsgPtr;
p_MsgPtr.m_MsgType=7;
bool p_DeleteFlag=true;
EXPECT_FALSE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtLteUpdateLocationRequest,processMessage_MSG_TYPE_DB_Func) {
g_IMEI_EncrFlag=1;
LteSubsDbData p_MsgPtr;
p_MsgPtr.m_MsgType=2;
p_MsgPtr.m_DbQueryType=0;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtLteUpdateLocationRequest,processMessage_default_Func) {
g_IMEI_EncrFlag=1;
Msg p_MsgPtr;
p_MsgPtr.m_MsgType=0;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}
/******************************************************/
/* //test case failing
TEST_F(UT_CtxtLteUpdateLocationRequest,FillLteConfigurationProfile_Func) {
LteConfigProf obj;
APNConfigurationProfile aApnConfProf;
EXPECT_TRUE(FillLteConfigurationProfile(&obj,aApnConfProf));
}


TEST_F(UT_CtxtLteUpdateLocationRequest,FillLteConfigurationProfile_Two_Func) {
LteConfigProf obj;
APNConfigurationProfile aApnConfProf;
obj.m_apnProfDetails.m_DefaultCtxdID=1;
EXPECT_TRUE(FillLteConfigurationProfile(&obj,aApnConfProf));
}*/

/**************************************************/
/*
/Memcached commented
TEST_F(UT_CtxtLteUpdateLocationRequest,handleDbQuery_Func) {
EXPECT_TRUE(handleDbQuery());
}*/

/*
TEST_F(UT_CtxtLteUpdateLocationRequest,sendULA_Func) {
//DiameterMsg l_answer("aaaaaaaaaaaaaaaaaaaaaaaaaaaa",DIAM_EVENT_UNKNOWN);
m_MessagePtr=new Msg;
strcpy(((DiameterMsg*)m_MessagePtr)->m_sessionId,"host26.realm26;1628358902;498433;1:2");
//strcpy(l_answer.m_sessionId,"aaaaaaaaaaaaaa");
EXPECT_TRUE(sendULA());
}
*/

/**************************************************/

/*
TEST_F(UT_CtxtLteUpdateLocationRequest,handleDBResponse_Func) {
DiameterMsg ptr("aaaaaaaaaaaaaaaaaaaaaaaaaaaa",DIAM_EVENT_UNKNOWN);
strcpy(ptr.m_sessionId,"aaaaaaaaaaaaaaaaaaaaa");
mp_HssSubsData=new LteSubsDbData;
mp_HssSubsData->m_ossTriggerDataCount_OUT=1;
mp_HssSubsData->m_crossClType_OUT=1;
mp_HssSubsData->m_ErrorCode_OUT=0;
mp_HssSubsData->m_LocalImsiSubscription_OUT=2;
mp_HssSubsData->m_FirstUL_OUT=1;
mp_HssSubsData->m_AllocationStatus_OUT=11;
EXPECT_TRUE(handleDBResponse());
}
*/
/**************************************************/

/*TEST_F(UT_CtxtLteUpdateLocationRequest,checkULR_Func) {
DiameterMsg l_answer("aaaaaaaaaaaaaaaa", DIAM_EVENT_ANSWER, DIAM_COMM_CODE_CX_DX_LIR_LIA);
int a=1;
l_answer.m_cmd=&a;
EXPECT_TRUE(checkULR());
}*/


/*TEST_F(UT_CtxtLteUpdateLocationRequest,handleError_Func) {
DiameterMsg *ptr= new DiameterMsg;
//p_msg("host26.realm26;1628358902;498433;1:2",DIAM_EVENT_ANSWER,318);
strcpy(ptr->m_sessionId,"host26.realm26;1628358902");
EXPECT_TRUE(handleError(0x01,-1));
delete ptr;
}*/
/*TEST_F(UT_CtxtLteUpdateLocationRequest,processMessage_Func) {
g_IMEI_EncrFlag=1;
Msg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}*/
/*
TEST_F(UT_CtxtLteUpdateLocationRequest,handleError_Func) {
EXPECT_TRUE(handleError(1,0));
}
*/

/*TEST_F(UT_CtxtLteUpdateLocationRequest,FillLteConfigurationProfile_Func) {
LteConfigProf *ptr=new LteConfigProf;
ptr->m_apnProfDetails.m_DefaultCtxdID=-1;
APNConfigurationProfile obj;
EXPECT_FALSE(FillLteConfigurationProfile(&ptr,&obj));
}*/

/*
TEST_F(UT_CtxtLteUpdateLocationRequest,sendULA_Func) {
EXPECT_TRUE(sendULA());
}
*/

#undef private

