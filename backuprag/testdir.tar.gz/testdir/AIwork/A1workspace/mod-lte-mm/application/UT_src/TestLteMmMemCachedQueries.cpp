#define private public

#include"gtest.h"
#include<LteMmMemCachedQueries.h>
#include<LteMmDbQueries.h>
#include <MemCachedUtilities.h>
#include <Logger.h>
#include <ConfigReader.h>
#include <SubsProfileData.h>
#include<LteMmConfigReader.h>
#include<MemCachedQueryMsg.h>
#include<Msg.h>
//#include"../../../mod-auc/application/inc/AucDbQueries.h"
//#include<OamDbQueries.h>
#include"../../../mod-oam/application/inc/OamDbQueries.h"

class UT_LteMmMemCachedQueries: public testing::Test , public LteMmMemCachedQueries
{public:
   UT_LteMmMemCachedQueries()
   {
   }
   ~UT_LteMmMemCachedQueries()
   {
   }
};

class UT_LteSubsDbData: public testing::Test , public LteSubsDbData
{public:
   UT_LteSubsDbData()
   {
   }
   ~UT_LteSubsDbData()
   {
   }
};

class UT_Msg
{public:
   UT_Msg()
   {
   }
   ~UT_Msg()
   {
   }
};

class UT_MemCachedQueryMsg
{
 public:
 UT_MemCachedQueryMsg()
 {
 }
 ~UT_MemCachedQueryMsg()
 {
 }
};


/*TEST_F(UT_LteSubsDbData,executeMemcQuery_MEMC_QUERY_TYPE_GET_Func)
{
//DeleteMemcQuery *ptr = new DeleteMemcQuery;
m_MemcQueryType=0;
EXPECT_NE(executeMemcQuery(),0);
//delete ptr;
}
 
TEST_F(UT_LteSubsDbData,executeMemcQuery_MEMC_QUERY_TYPE_UPDATE_Func)
{
//DeleteMemcQuery *ptr = new DeleteMemcQuery;
m_MemcQueryType=1;
EXPECT_NE(executeMemcQuery(),0);
//delete ptr;
}*/
TEST_F(UT_LteSubsDbData,serializeMemc_MEMC_QUERY_TYPE_GET_Func)
{
m_MemcQueryType=0;
strcpy(m_UlrImsi_IN,"111112222233333");
EXPECT_NO_THROW(serializeMemc());
}

TEST_F(UT_LteSubsDbData,serializeMemc_MEMC_QUERY_TYPE_UPDATE_Func)
{
m_MemcQueryType=1;
strcpy(m_UlrImsi_IN,"111112222233333");
EXPECT_NO_THROW(serializeMemc());
}

TEST_F(UT_LteSubsDbData,serializeMemc_MEMC_QUERY_TYPE_UPDATE_Func1)
{
   m_MemcQueryType=1;
   strcpy(m_UlrImsi_IN,"111112222233334");
   EXPECT_NO_THROW(serializeMemc());
}


TEST_F(UT_LteSubsDbData,deSerializeMemc_MEMC_QUERY_TYPE_GET_Func)
{
m_MemcQueryType=0;
EXPECT_FALSE(deSerializeMemc());
}

TEST_F(UT_LteSubsDbData,deSerializeMemc_MEMC_QUERY_TYPE_GET_TAG_Func)
{
m_MemcQueryType=0;
m_MemcValue="<A>0</A>";
EXPECT_FALSE(deSerializeMemc());
m_MemcValue="<B>1</B>";
EXPECT_FALSE(deSerializeMemc());
m_MemcValue="<B>1</B><C>1</C><D>1</D><E>1</E><F>1</F><G>1</G><H>1</H><I>1</I><J>1</J><K>1</K><L>1</L><M>1</M><N>1</N><O>1</O><P>1</P><Q>1</Q><R>1</R><S>1</S><T>1</T><U>1</U><V>1</V><W>1</W><X>1</X><Y>1</Y>";
EXPECT_FALSE(deSerializeMemc());

}

#undef private
