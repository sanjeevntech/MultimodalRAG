#include <MapMessages.h>
#include <ContextBase.h>
#include <ModuleBase.h>
#include <LteMmConfigReader.h>
#include <LteMmSimConfigReader.h>
#include <Logger.h>
#include <SnmpInterface.h>

#include <CtxtLteUpdateLocationRequest.h>

#include <DiameterMessages.h>
#include <DiameterConstants.h>

#include <ExtendedServiceCoordinator.h>
#include <UpdateLocation.h>
#include <LteMmSimulator.h>
#include <S6a_r10AVP.h>
#include <SnmpInterface.h>
#include <Slh_Routing_request.h>
#include <SimulatorRIR.h>


int g_FreeMsisdnRemainingTrap=-1;
int g_TransientMsisdnUnavailableTrap = -1;
int g_LocalMsisdnUnavailableTrap = -1;
int g_LocalMsisdnThresholdTrap = -1;
int g_TransientMsisdnThresholdTrap = -1;
int g_DynamicAllocFailTrap = -1;

using namespace diameter::base;
using namespace diameter::s6a_r10;

extern bool g_loadFlag;

extern "C" {
   ModuleBase *getModuleObj();
}

class HssMmModule : public ModuleBase
{
   public:
      HssMmModule(){}
      bool initModule();
      ContextBase *getCtxtObj(EMapOpCode, MapSpecificMsg*);
      ContextBase *getCtxtObj(EDiameterCommandCode, DiameterMsg*);
      ContextBase *getCtxtObj(EMapOpCode, SccpMsg*);
      char *getVersion();
      ConfigReader *getConfigReaderObj();
      ConfigReader **retrieveConfigReaderPtr();
};

HssMmModule g_HssMmModule;

ModuleBase *getModuleObj()
{
   return &g_HssMmModule;
}

char *HssMmModule::getVersion()
{
   RETURN_VERSION (APP_VERSION);//2.0.23.0 2.0.21.0 2.0.18.0_Rev1 
}

bool HssMmModule::initModule()
{
   if(true == g_loadFlag)
   {
      m_modName="LTS";
   }
   else
   {
      m_modName="LMM";
      LLOG(0,0,"LMM APPVER-v:%s ci:%s cd:%s comp:%s %s", APP_VERSION, COMMIT_ID, COMMIT_DATE,__DATE__,__TIME__);
   }
   moduleLevelAddHeader("PrimMSISDNAllocatedinULR", MODULE_STATS_TYPE_NORMAL);
   if(false == g_loadFlag)
   {
#if 0
      if (NULL == g_LteMmConfigReaderObj)
      {
         printf("\n\n Error: HssMmConfigReaderObj is Null\n");
         return false;
      }
      if (false == g_LteMmConfigReaderObj->m_derivedObjectInitializedFlag)
      {
         printf("\n\nERROR: LMM specific configuration file reading is mandatory\n");
         return false;
      }
#endif
      //g_selfSimObj = new HssMmSimulator;
      g_FreeMsisdnRemainingTrap        = g_si.registerSnmpTrap("MIN_DYNAMIC_MSISDN",  "Remaining Free MSISDN", LTE_MM_TRAP_SEQ_ID_ONE);
      g_TransientMsisdnUnavailableTrap = g_si.registerSnmpTrap("TRANS_MSISDN_UNAVAIL","Transient MSISDN Unavailable", LTE_MM_TRAP_SEQ_ID_TWO);
      g_LocalMsisdnUnavailableTrap     = g_si.registerSnmpTrap("LOCAL_MSISDN_UNAVAIL","Local MSISDN Unavailable", LTE_MM_TRAP_SEQ_ID_THREE);
      g_LocalMsisdnThresholdTrap       = g_si.registerSnmpTrap("LOCAL_MSISDN_THRESH", "Local MSISDN Threshold reached", LTE_MM_TRAP_SEQ_ID_FOUR);
      g_TransientMsisdnThresholdTrap   = g_si.registerSnmpTrap("TRANS_MSISDN_THRESH", "Transient MSISDN Threshold reached", LTE_MM_TRAP_SEQ_ID_FIVE);
      g_DynamicAllocFailTrap           = g_si.registerSnmpTrap("DYNAMIC_ALLOC_FAIL", "Dynamic Msisdn Alloc Fail", LTE_MM_TRAP_SEQ_ID_SIX);
   }

   return true;
}


ContextBase *HssMmModule::getCtxtObj(EMapOpCode p_OpCode, MapSpecificMsg *p_msg)
{
   WLOG(0,0,"getCtxtObj does not support MAP messages");
   return NULL;
}

ContextBase *HssMmModule::getCtxtObj(EMapOpCode p_OpCode, SccpMsg *p_msg)
{
   WLOG(0,0,"getCtxtObj does not support SCCP messages");
   return NULL;
}

ContextBase *HssMmModule::getCtxtObj(EDiameterCommandCode p_ccCode, DiameterMsg *p_msg)
{
   switch (p_ccCode)
   {
      case DIAM_COMM_CODE_S6A_S6D_ULR_ULA:
         {
            if(false == g_loadFlag)
            {
               DLOG(0,0,"Rcvd DIAM_COMM_CODE_S6A_S6D_ULR_ULA Newing CtxtDiameterUpdateLocationRequest");
               return new CtxtLteUpdateLocationRequest;
            }
            else
            {
               DLOG(0,0,"Rcvd DIAM_COMM_CODE_S6A_S6D_ULR_ULA Newing CtxtSimulatorDiameterUpdateLocationRequest");
               return new HssSimMmUpdateLocation;
            }
         }
         break;

      case DIAM_COMM_CODE_SLH_RIR_RIA:
         {
            if(false == g_loadFlag)
            {
               DLOG(0,0,"Rcvd DIAM_COMM_CODE_SLH_RIR_RIA Newing SLH_routing_info");
               return new SLH_routing_info;
            }
            else
            {
               DLOG(0,0,"Rcvd DIAM_COMM_CODE_SLH_RIR_RIA Newing SLH_routing_infoSimulator");
               return new RIRSimulator;
            }
         }
         break;

      default:
         {
            DLOG(0,0,"getMmCtxtObj Unknown ccCode [%d]",p_ccCode);
            printf("\ngetMmCtxtObj Unknown ccCode [%d]",p_ccCode);
            return NULL;
         }
         break;
   }
}

ConfigReader *HssMmModule::getConfigReaderObj()
{
   if(true == g_loadFlag)
   {
      LLOG(0,0,"Returning g_HssMmSimConfigReaderObj");
      return (g_LteMmSimConfigReaderObj = new LteMmSimConfigReader);
   }
   LLOG(0,0,"Returning g_HssMmConfigReaderObj");
   //return (g_LteMmConfigReaderObj = new LteMmConfigReader);
   return new LteMmConfigReader;
}

ConfigReader **HssMmModule::retrieveConfigReaderPtr()
{
   if(true == g_loadFlag)
   {
      LLOG(0,0,"ConfigReader Sim **HssMmModule::retrieveConfigReaderPtr() called");
      return (ConfigReader **)&g_LteMmSimConfigReaderObj;
   }
   LLOG(0,0,"ConfigReader **HssMmModule::retrieveConfigReaderPtr() called");
   return (ConfigReader **)&g_LteMmConfigReaderObj;
}

bool DeclareFunc(int p_version, int p_pdu, void *p_struct)
{
   return false;
}





