#include <LteMmSimConfigReader.h>
#include <Logger.h>
LteMmSimConfigReader *g_LteMmSimConfigReaderObj=NULL;

LteMmSimConfigReader::LteMmSimConfigReader()
{
   LLOG(0,0,"LteMmSimConfigReader cons");
   m_UlrFlags = 0;
   m_SuppFeature1 = 0;
   m_SuppFeature2 = 0;
   memset(m_UlrImsi,'\0',sizeof(m_UlrImsi));
   memset(m_gmlc,'\0',sizeof(m_gmlc));
}

LteMmSimConfigReader::~LteMmSimConfigReader()
{
   LLOG(0,0,"LteMmSimConfigReader des");
}

bool LteMmSimConfigReader::readData()
{
   LLOG(0,0,"LteMmSimConfigReader::readData()");
   string l_mm = readValue(m_DataString, "ULR_RIR_SIM");

   if( false == readInteger(l_mm, "ULR_FLAGS", m_UlrFlags, 0, 2147483645))
      return false;
   LLOG(0,0,"ULR_FLAGS value [%u]",m_UlrFlags);

   if( false == readInteger(l_mm, "SUPP_FEATURE_1", m_SuppFeature1, 0, 2147483645))
      return false;
   LLOG(0,0,"SUPP_FEATURE_1 value [%u]",m_SuppFeature1);

   if( false == readInteger(l_mm, "SUPP_FEATURE_2", m_SuppFeature2, 0, 2147483645))
      return false;
   LLOG(0,0,"SUPP_FEATURE_1 value [%u]",m_SuppFeature2);

   if (false == readString(l_mm, "ULR_IMSI", m_UlrImsi,4,15))
      return false;
   LLOG(0,0,"ULR_IMSI value [%s]",m_UlrImsi);

   if (false == readString(l_mm, "VPLMN_ID", m_VplmnId,3,6))
      return false;
   LLOG(0,0,"VPLMNid value [%s]",m_VplmnId);

   if( false == readInteger(l_mm, "RAT_TYPE", m_RatType, 0, 2002))
      return false;
   LLOG(0,0,"RAT TYPE value [%d]",m_RatType);

   if (false == readString(l_mm, "MEID", m_Meid,1,16))
      return false;
   LLOG(0,0,"MEID value [%s]",m_Meid);

   if( false == readInteger(l_mm, "ACTIVE_APN_ENABLE", m_ActiveApnRequired, 0, 1))
      return false;
   LLOG(0,0,"ACTIVE_APN_ENABLE value [%d]",m_ActiveApnRequired);

   string l_gmlc = readValue(l_mm,"GMLC");
   strncpy(m_gmlc,(char*)l_gmlc.c_str(),strlen((char*)l_gmlc.c_str()));
   DLOG(0,0,"Value of Gmlc = [%s]",m_gmlc);

   m_derivedObjectInitializedFlag=true;
   return true;
}

void LteMmSimConfigReader::printConfigData(char *p_output)
{
}

