#include <CtxtLteUpdateLocationRequest.h>
#include <stdio.h>
#include <MapMessages.h>
#include <ServiceCoordinator.h>
#include <ExtendedServiceCoordinator.h>
#include <Logger.h>
#include <DataUnion.h>
#include <DbActiveObject.h>
#include <Utilities.h>
#include <LteCommonDefines.h>
#include <LteMmConfigReader.h>
#include <Utilities.h>
#include <SnmpInterface.h>

#include <DiameterConstants.h>
#include <DiametriqInterface.h>
#include <CommonData.h>

#include <diameter/Command.h>
#include <diameter/base/BaseAVP.h>
#include <GutilDAFInterface.h>

using namespace diameter::s6a_r10;

extern int g_FreeMsisdnRemainingTrap;
extern int g_TransientMsisdnUnavailableTrap;
extern int g_TransientMsisdnThresholdTrap;
extern int g_LocalMsisdnUnavailableTrap;
extern int g_LocalMsisdnThresholdTrap;
extern int g_DynamicAllocFailTrap;

time_t g_LastTimerExecuted=0;
time_t g_CurrTimeExecuted=time(NULL);

GenericUtilitiesFrameworkInterface *g_daf = NULL;

CtxtLteUpdateLocationRequest :: CtxtLteUpdateLocationRequest()
{
   DLOG(0, 0, "CtxtLteUpdateLocationRequest::CtxtLteUpdateLocationRequest()");

   m_UlrFlag = 0;
   m_RatType = -1;
   m_HsImsPs = -1;
   m_UeSrvccCap = -1;
   m_GmlcFamily = -1;
   m_featureList1 = 0;
   m_featureList2 = 0;
   m_S6aS6dInd = false;
   m_Single_Reg_Ind = false;
   m_Initial_Attach_Ind = false;
   m_nodeTypeInd = NODETYPE_UNKNOWN;
   memset(m_VplmnId,'\0',sizeof(m_VplmnId));
   memset(m_UlrImsi,'\0',sizeof(m_UlrImsi));
   memset(m_MmeHost,'\0',sizeof(m_MmeHost));
   memset(m_MmeRealm,'\0',sizeof(m_MmeRealm));
   memset(m_SgsnNumber,'\0',sizeof(m_SgsnNumber));
   memset(m_GmlcAddress,'\0',sizeof(m_GmlcAddress));
   memset(&m_terminalInformation,'\0',sizeof(m_terminalInformation));

   m_MessagePtr = NULL;
   mp_HssSubsData = NULL;

   m_5gSupportFlag = false;
   m_hlr_5gSupportFlag = false;
   memset(m_TransId,'\0',sizeof(m_TransId));
   m_fIdr = false;
   m_odbDataSend = false;
   m_modifyOdb = 0;
   m_IdrFlag = 0;
   memset(m_Orig_Imei,'\0',sizeof(m_Orig_Imei));
}

CtxtLteUpdateLocationRequest :: ~CtxtLteUpdateLocationRequest()
{
   DLOG(0, 0, "CtxtLteUpdateLocationRequest::~CtxtLteUpdateLocationRequest()");
   if(NULL != m_MessagePtr)
   {
      delete m_MessagePtr;
      m_MessagePtr = NULL;
   }
   if(NULL != mp_HssSubsData)
   {
      delete mp_HssSubsData;
      mp_HssSubsData = NULL;
   }
}

int getPartnerLteProfId(unsigned int p_LteProfId, int p_NkId, int p_PartnerNkId)
{
   char l_tempArr[100 + 1];
   memset(l_tempArr,'\0',sizeof(l_tempArr));
   DLOG(0,0,"Nw Id is %d PartNwId %d LteProfId %d",p_NkId,p_PartnerNkId,p_LteProfId);
   p_NkId +=100;
   snprintf(l_tempArr,sizeof(l_tempArr),"%d%04d%d",p_NkId,p_PartnerNkId,p_LteProfId);
   DLOG(0,0,"Map Size [%d] tempArr in getPartnerLteProfId [%s]",(int )g_spdPtr->m_RPLteProfMap.size(),l_tempArr);

   map<string , int> :: iterator RPLtePartProfIter;
   RPLtePartProfIter = g_spdPtr->m_RPLteProfMap.find(l_tempArr);
   if(RPLtePartProfIter != g_spdPtr->m_RPLteProfMap.end())
   {
      TLOG(0,0,"PARTNER LTE PROFILE MATCH FOUND [%d]",RPLtePartProfIter->second);
      return RPLtePartProfIter->second;
   }
   return 0;
}

bool CtxtLteUpdateLocationRequest :: handleError(unsigned int aErrCode, EErrorDiagnostic aEd)
{
   DLOG(0,0,"CtxtLteUpdateLocationRequest :: handleError");
   DiameterMsg l_answer(((DiameterMsg*)m_MessagePtr)->m_sessionId, DIAM_EVENT_ANSWER, DIAM_COMM_CODE_S6A_S6D_ULR_ULA);

   s6a_r10::UpdateLocationAnswer l_ula;
   try
   {
      l_ula.setSessionIndex(((DiameterMsg*)m_MessagePtr)->m_sessionIndex);

      SessionId l_sid(((DiameterMsg*)m_MessagePtr)->m_sessionId);
      l_ula.setSessionId(l_sid);

      AuthSessionState l_authSs(AuthSessionState::NO_STATE_MAINTAINED);
      l_ula.setAuthSessionState(l_authSs);

      if(NULL != mp_HssSubsData)
      {
         OriginHost l_origHost(mp_HssSubsData->m_HssOriginHost_OUT);
         OriginRealm l_origRealm(mp_HssSubsData->m_HssOriginRealm_OUT);
         l_ula.setOriginHost(l_origHost);
         l_ula.setOriginRealm(l_origRealm);
      }
      else
      {
         OriginHost l_origHost("");
         OriginRealm l_origRealm("");
         l_ula.setOriginHost(l_origHost);
         l_ula.setOriginRealm(l_origRealm);
         TLOG(0,0,"DBresponse pointer null");
      }

      if(aErrCode == DIAM_RESULT_CODE_UNABLE_TO_COMPLY)
      {
         CLOG(0,1,"ErrorResp: SessionIndex[%d] Session[%s] ResultCode DIAM_RESULT_CODE_UNABLE_TO_COMPLY",((DiameterMsg*)m_MessagePtr)->m_sessionIndex,(char*)((DiameterMsg*)m_MessagePtr)->m_sessionId);
         ResultCode l_rc(aErrCode);
         l_ula.setResultCode(l_rc);
      }
      else
      {
         LLOG(0,0,"ErrorResp: SessionIndex[%d] Session[%s] ExperimentalResultCode[%d]",((DiameterMsg*)m_MessagePtr)->m_sessionIndex,(char*)((DiameterMsg*)m_MessagePtr)->m_sessionId,aErrCode);

         ExperimentalResult l_experimentalResult;
         VendorId l_vendorId(10415);
         l_experimentalResult.setVendorId(l_vendorId);
         ExperimentalResultCode l_experimentalResultCode(aErrCode);
         l_experimentalResult.setExperimentalResultCode(l_experimentalResultCode);
         l_ula.setExperimentalResult(l_experimentalResult);


         if(ERROR_DIAGNOSTIC_NOT_REQUIRED != aEd) //TODO: this is not present in Rel-8
         {
            switch(aEd)
            {
               case ERROR_DIAGNOSTIC_GPRS_DATA_SUBSCRIBED:
                  {
                     LLOG(0,1,"Setting Error Diagnostic GPRS_DATA_SUBSCRIBED");
                     ErrorDiagnostic l_ed(ErrorDiagnostic::GPRS_DATA_SUBSCRIBED);
                     l_ula.setErrorDiagnostic(l_ed);
                  }
                  break;
               case ERROR_DIAGNOSTIC_NO_GPRS_DATA_SUBSCRIBED:
                  {
                     LLOG(0,1,"Setting Error Diagnostic NO_GPRS_DATA_SUBSCRIBED");
                     ErrorDiagnostic l_ed(ErrorDiagnostic::NO_GPRS_DATA_SUBSCRIBED);
                     l_ula.setErrorDiagnostic(l_ed);
                  }
                  break;
               case ERROR_DIAGNOSTIC_ODB_ALL_APN:
                  {
                     LLOG(0,1,"Setting Error Diagnostic ODB_ALL_APN");
                     ErrorDiagnostic l_ed(ErrorDiagnostic::ODB_ALL_APN);
                     l_ula.setErrorDiagnostic(l_ed);
                  }
                  break;
               case ERROR_DIAGNOSTIC_ODB_HPLMN_APN:
                  {
                     LLOG(0,1,"Setting Error Diagnostic ODB_HPLMN_APN");
                     ErrorDiagnostic l_ed(ErrorDiagnostic::ODB_HPLMN_APN);
                     l_ula.setErrorDiagnostic(l_ed);
                  }
                  break;
               case ERROR_DIAGNOSTIC_ODB_VPLMN_APN:
                  {
                     LLOG(0,1,"Setting Error Diagnostic ODB_VPLMN_APN");
                     ErrorDiagnostic l_ed(ErrorDiagnostic::ODB_VPLMN_APN);
                     l_ula.setErrorDiagnostic(l_ed);
                  }
                  break;
               default:
                  {
                     LLOG(0,0,"Invalid Error Diagnoistic info[%d]",aEd);
                  }
                  break;
            }
         }
      }

      l_answer.m_cmd = &l_ula;
   }
   catch (NoSuchAttributeException e)
   {
      ELOG(0,1,"ERROR!! Exception NoSuchAttributeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EXCEPTION_OCCURRED);
      return false;
   }
   catch (WrongCommandTypeException e)
   {
      ELOG(0,1,"ERROR!! Exception WrongCommandTypeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EXCEPTION_OCCURRED);
      return false;
   }
   catch (UnknownTypeException e)
   {
      ELOG(0,1,"ERROR!! Exception UnknownTypeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EXCEPTION_OCCURRED);
      return false;
   }
   catch (CodecException e)
   {
      ELOG(0,1,"ERROR!! Exception CodecException Caught: %s ,Error Cause: %s ",e.name(), e.what());
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EXCEPTION_OCCURRED);
      return false;
   }
   catch (...)
   {
      CLOG(0,0,"Exception occurred while Sending Error");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EXCEPTION_OCCURRED);
      return false;
   }

   g_esc.sendMsg(this, &l_answer);
   m_tdr.setInteger(TDR_INDEX_ERR_CODE, aErrCode);
   DLOG(0,0,"CtxtLteUpdateLocationRequest :: handleError going to return ...");
   return true;
}

void CtxtLteUpdateLocationRequest :: LogULRFlags()
{
   if(m_UlrFlag & 0x01) // bit 0 set send CL to SGSN
   {
      m_Single_Reg_Ind = true;
      LLOG(0,0,"Single Registration indication set .. to send CL to SGSN");
   }
   if(m_UlrFlag & 0x02) // bit 1 s6a/s6d indicator
   {
      TLOG(0,0,"s6a indicator set"); 
      m_S6aS6dInd = true;
   }
   if(m_UlrFlag & 0x04) // bit 2 Skip Subscriber Data 
   {
      LLOG(0,0,"Skip subscriber data set"); 
   }
   if(m_UlrFlag & 0x08) // bit 3 GPRS-Subscription-Data-Indicator
   {
      LLOG(0,0,"GPRS subscription indicator set"); 
   }
   if(m_UlrFlag & 0x10) // bit 4 Node-Type-Indicator
   {
      LLOG(0,0,"NodeType indicator set .. Combined MME SGSN"); 
      m_nodeTypeInd = NODETYPE_MMESGSN;
   }
   else
   {
      if(true == m_S6aS6dInd)
      {
         m_nodeTypeInd = NODETYPE_MME;
         LLOG(0,0,"s6a indicator set .. Only MME"); 
      }
      else
      {
         m_nodeTypeInd = NODETYPE_SGSN;
         LLOG(0,0,"s6a indicator not set .. Only SGSN"); 
      }
   }
   LLOG(0,0,"NodeTypeInd[%d] S6aS6dInd[%d]",m_nodeTypeInd,m_S6aS6dInd);
   if(m_UlrFlag & 0x20) // bit 5 Initial-Attach-Indicator
   {
      m_Initial_Attach_Ind = true;
      LLOG(0,0,"Initial Attach indicator set .. to send CL for registered MME/SGSN"); 
   }
   if(m_UlrFlag & 0x40) // bit 6 PS-LCS-Not-Supported-By-UE
   {
      LLOG(0,0,"PS LCS not supported by UE set"); 
   }
   if(m_UlrFlag & 0x80) // bit 7 SMS-Only-Indication 
   {
      LLOG(0,0,"SMS Only indication set"); 
   }
}

void CtxtLteUpdateLocationRequest :: LogSupportedFeatures()
{
   list<VendorIdFeatureList> :: iterator l_featureListIter;
   for(l_featureListIter = m_vendorIdFeatureList.begin(); l_featureListIter != m_vendorIdFeatureList.end(); l_featureListIter++)
   {
      VendorIdFeatureList l_vendorFeatureList = *l_featureListIter;
      LLOG(0,0,"VendorID[%u] FeatureListID[%u] FeatureList[%u]",l_vendorFeatureList.m_vendorId,l_vendorFeatureList.m_featureListId,l_vendorFeatureList.m_featureList);

      if(10415 == l_vendorFeatureList.m_vendorId)
      {
         if(1 == l_vendorFeatureList.m_featureListId)
         {
            m_tdr.setUnsignedInteger(TDR_INDEX_REMOTE_SUPP_FEATURE_1, l_vendorFeatureList.m_featureList);
            m_featureList1 = l_vendorFeatureList.m_featureList;
            LLOG(0,0,"Feature List ID :  1");
            if(l_vendorFeatureList.m_featureList & F1_ODB_ALL_APN)
            {
               LLOG(0,0,"Supported Feature-1: ODB-all-APN");
            }
            if(l_vendorFeatureList.m_featureList & F1_ODB_HPLMN_APN)
            {
               LLOG(0,0,"Supported Feature-1: ODB-HPLMN-APN");
            }
            if(l_vendorFeatureList.m_featureList & F1_ODB_VPLMN_APN)
            {
               LLOG(0,0,"Supported Feature-1: ODB-VPLMN-APN");
            }
            if(l_vendorFeatureList.m_featureList & F1_ODB_ALL_OG)
            {
               LLOG(0,0,"Supported Feature-1: ODB-all-OG");
            }
            if(l_vendorFeatureList.m_featureList & F1_ODB_ALL_InternationalOG)
            {
               LLOG(0,0,"Supported Feature-1: ODB-all- InternationalOG");
            }
            if(l_vendorFeatureList.m_featureList & F1_ODB_ALL_InternationalOG_NotToHPLMNCountry)
            {
               LLOG(0,0,"Supported Feature-1: ODB-all-InternationalOGNotToHPLMN-Country");
            }
            if(l_vendorFeatureList.m_featureList & F1_ODB_ALL_InterzonalOG)
            {
               LLOG(0,0,"Supported Feature-1: ODB-all-InterzonalOG");
            }
            if(l_vendorFeatureList.m_featureList & F1_ODB_ALL_InterzonalOG_NotToHPLMNCountry)
            {
               LLOG(0,0,"Supported Feature-1: ODB-all-InterzonalOGNotToHPLMN-Country");
            }
            if(l_vendorFeatureList.m_featureList & F1_ODB_ALL_InterzonalOG_And_InternationalOG_NotToHPLMNCountry)
            {
               LLOG(0,0,"Supported Feature-1: ODB-all-InterzonalOGAndInternationalOGNotToHPLMN-Country");
            }
            if(l_vendorFeatureList.m_featureList & F1_RegSub)
            {
               LLOG(0,0,"Supported Feature-1: RegSub");
            }
            if(l_vendorFeatureList.m_featureList & F1_Trace)
            {
               LLOG(0,0,"Supported Feature-1: Trace");
            }
            if(l_vendorFeatureList.m_featureList & F1_LCS_ALL_PrivExcep)
            {
               LLOG(0,0,"Supported Feature-1: LCS-all-PrivExcep");
            }
            if(l_vendorFeatureList.m_featureList & F1_LCS_Universal)
            {
               LLOG(0,0,"Supported Feature-1: LCS-Universal");
            }
            if(l_vendorFeatureList.m_featureList & F1_LCS_CALL_SessionRelated)
            {
               LLOG(0,0,"Supported Feature-1: LCS-CallSessionRelated");
            }
            if(l_vendorFeatureList.m_featureList & F1_LCS_CALL_SessionUnrelated)
            {
               LLOG(0,0,"Supported Feature-1: LCS-CallSessionUnrelated");
            }
            if(l_vendorFeatureList.m_featureList & F1_LCS_PLMNOperator)
            {
               LLOG(0,0,"Supported Feature-1: LCS-PLMNOperator");
            }
            if(l_vendorFeatureList.m_featureList & F1_LCS_ServiceType)
            {
               LLOG(0,0,"Supported Feature-1: LCS-ServiceType");
            }
            if(l_vendorFeatureList.m_featureList & F1_LCS_ALL_MOLRSS)
            {
               LLOG(0,0,"Supported Feature-1: LCS-all-MOLR-SS");
            }
            if(l_vendorFeatureList.m_featureList & F1_LCS_BasicSelfLocation)
            {
               LLOG(0,0,"Supported Feature-1: LCS- BasicSelfLocation");
            }
            if(l_vendorFeatureList.m_featureList & F1_LCS_AutonomousSelfLocation)
            {
               LLOG(0,0,"Supported Feature-1: LCS- AutonomousSelfLocation");
            }
            if(l_vendorFeatureList.m_featureList & F1_LCS_TransferToThirdParty)
            {
               LLOG(0,0,"Supported Feature-1: LCS- TransferToThirdParty");
            }
            if(l_vendorFeatureList.m_featureList & F1_SMMOPP)
            {
               LLOG(0,0,"Supported Feature-1: SM-MO-PP");
            }
            if(l_vendorFeatureList.m_featureList & F1_BarringOutgoingCalls)
            {
               LLOG(0,0,"Supported Feature-1: Barring-OutgoingCalls");
            }
            if(l_vendorFeatureList.m_featureList & F1_BAOC)
            {
               LLOG(0,0,"Supported Feature-1: BAOC");
            }
            if(l_vendorFeatureList.m_featureList & F1_BOIC)
            {
               LLOG(0,0,"Supported Feature-1: BOIC");
            }
            if(l_vendorFeatureList.m_featureList & F1_BOICExHC)
            {
               LLOG(0,0,"Supported Feature-1: BOICExHC");
            }
            if(l_vendorFeatureList.m_featureList & F1_UEReachabilityNotification)
            {
               LLOG(0,0,"Supported Feature-1: UE-Reachability-Notification");
            }
            if(l_vendorFeatureList.m_featureList & F1_TADS_Data_Retrieval)
            {
               LLOG(0,0,"Supported Feature-1: T-ADS Data Retrieval");
            }
            if(l_vendorFeatureList.m_featureList & F1_State_LocationInformationRetrieval)
            {
               LLOG(0,0,"Supported Feature-1: State/Location-Information-Retrieval");
            }
            if(l_vendorFeatureList.m_featureList & F1_Partial_Purge)
            {
               LLOG(0,0,"Supported Feature-1: Partial Purge");
            }
            if(l_vendorFeatureList.m_featureList & F1_Local_Time_Zone_Retrieval)
            {
               LLOG(0,0,"Supported Feature-1: Local Time Zone Retrieval");
            }
            if(l_vendorFeatureList.m_featureList & F1_Additional_MSISDN)
            {
               LLOG(0,0,"Supported Feature-1: Additional MSISDN");
            }
         }
         else if(2 == l_vendorFeatureList.m_featureListId)
         {
            m_tdr.setUnsignedInteger(TDR_INDEX_REMOTE_SUPP_FEATURE_2, l_vendorFeatureList.m_featureList);
            LLOG(0,0,"Feature List ID :  2");
            m_featureList2 = l_vendorFeatureList.m_featureList;
            if(l_vendorFeatureList.m_featureList & F2_SMS_in_MME)
            {
               LLOG(0,0,"Supported Feature-2: SMS in MME");
            }
            if(l_vendorFeatureList.m_featureList & F2_SMS_in_SGSN)
            {
               LLOG(0,0,"Supported Feature-2: SMS in SGSN");
            }
            if(l_vendorFeatureList.m_featureList & F2_DiaLCS_ALL_PrivExcep)
            {
               LLOG(0,0,"Supported Feature-2: Dia-LCS-all-PrivExcep");
            }
            if(l_vendorFeatureList.m_featureList & F2_DiaLCS_Universal)
            {
               LLOG(0,0,"Supported Feature-2: Dia-LCS-Universal");
            }
            if(l_vendorFeatureList.m_featureList & F2_DiaLCS_CALL_SessionRelated)
            {
               LLOG(0,0,"Supported Feature-2: Dia-LCS-CallSessionRelated");
            }
            if(l_vendorFeatureList.m_featureList & F2_DiaLCS_CALL_SessionUnrelated)
            {
               LLOG(0,0,"Supported Feature-2: Dia-LCS-CallSessionUnrelated");
            }
            if(l_vendorFeatureList.m_featureList & F2_DiaLCS_PLMNOperator)
            {
               LLOG(0,0,"Supported Feature-2: Dia-LCS-PLMNOperator");
            }
            if(l_vendorFeatureList.m_featureList & F2_DiaLCS_ServiceType)
            {
               LLOG(0,0,"Supported Feature-2: Dia-LCS-ServiceType");
            }
            if(l_vendorFeatureList.m_featureList & F2_DiaLCS_ALL_MOLRSS)
            {
               LLOG(0,0,"Supported Feature-2: Dia-LCS-all-MOLR-SS");
            }
            if(l_vendorFeatureList.m_featureList & F2_DiaLCS_BasicSelfLocation)
            {
               LLOG(0,0,"Supported Feature-2: Dia-LCS- BasicSelfLocation");
            }
            if(l_vendorFeatureList.m_featureList & F2_DiaLCS_AutonomousSelfLocation)
            {
               LLOG(0,0,"Supported Feature-2: Dia-LCS- AutonomousSelfLocation");
            }
            if(l_vendorFeatureList.m_featureList & F2_DiaLCS_TransferToThirdParty)
            {
               LLOG(0,0,"Supported Feature-2: Dia-LCS- TransferToThirdParty");
            }

            if(l_vendorFeatureList.m_featureList & F2_EXTENDED_FEATURES)
            {
               LLOG(0,0,"Supported Feature-2: Extended feature [%u]", l_vendorFeatureList.m_featureList);
            }

            // 5051A - 5gNSA
            if(l_vendorFeatureList.m_featureList & F2_NR_AS_SECONDARY_RAT)
            {
               LLOG(0,0,"Supported Feature-2: NR_AS_SECONDARY_RAT [%u] received", l_vendorFeatureList.m_featureList);
               m_5gSupportFlag = true;
            }
         }
         else
         {
            WLOG(0,0,"Some new feature list id %u with vendor id 10415 received", l_vendorFeatureList.m_featureListId);
         }
      }
      else
      {
         m_tdr.setUnsignedInteger(TDR_INDEX_REMOTE_EXT_SUPP_FEATURE, l_vendorFeatureList.m_featureList);
         LLOG(0,0,"Extended Feature List ID : [%u] from Different Vendor[%u]", l_vendorFeatureList.m_featureListId,l_vendorFeatureList.m_vendorId);
      }
   }
}

bool CtxtLteUpdateLocationRequest :: checkULR()
{
   diameter::s6a_r10::UpdateLocationRequest l_ulrRequest(*(diameter::CommandImpl*)((DiameterMsg*)m_MessagePtr)->m_cmd);
   diameter::s6a_r10::UpdateLocationRequest *l_ulrReq = &l_ulrRequest;

   LLOG(0,0,"ULR: SessionIndex[%d] Session[%s] OrigHost[%s] OrigRealm[%s]", l_ulrReq->getSessionIndex(),(char*)l_ulrReq->getSessionId().value().c_str(),(char*)l_ulrReq->getOriginHost().value().c_str(),(char*)l_ulrReq->getOriginRealm().value().c_str());
   //LLOG(0,0,"ULR AuthSessState[%d]", l_ulrReq->getAuthSessionState());
   strcpy(m_MmeHost,(char*)l_ulrReq->getOriginHost().value().c_str());
   strcpy(m_MmeRealm,(char*)l_ulrReq->getOriginRealm().value().c_str());

   //m_tdr.setString(TDR_INDEX_REMOTE_REALM, (char*)l_ulrReq->getOriginRealm().value().c_str());
   //m_tdr.setString(TDR_INDEX_LOCAL_HOST, (char*)l_ulrReq->getDestinationHost().value().c_str());
   //m_tdr.setString(TDR_INDEX_LOCAL_REALM, (char*)l_ulrReq->getDestinationRealm().value().c_str());

   // Mandatory Params Begin .. 
   // TODO imsi len validation
   if(15 != l_ulrReq->getUserName().value().size())
   {
      WLOG(0,0,"IMSI len %d is not 15 digits", l_ulrReq->getUserName().value().size());
      return false;
   }
   strcpy(m_UlrImsi,(char*)l_ulrReq->getUserName().value().c_str());
   m_tdr.setChar(TDR_INDEX_REQUEST_TYPE, 'I');
   m_tdr.setString(TDR_INDEX_REQUEST_IMSI, m_UlrImsi);

   m_UlrFlag = (l_ulrReq->getULRFlags()).value();
   m_tdr.setInteger(TDR_INDEX_REQUEST_FLAGS, m_UlrFlag);

   m_RatType = (RATType::Value)(l_ulrReq->getRATType().value());
   m_tdr.setInteger(TDR_INDEX_ULR_RAT_TYPE, m_RatType);

   LLOG(0,0,"ULR: Imsi[%s] UlrFlag[%d] RatType[%d]", m_UlrImsi,m_UlrFlag,m_RatType);

   if( HSS_VPLMNID_LEN == l_ulrReq->getVisitedPLMNId().value().size())
   {
      memcpy(m_VplmnId,l_ulrReq->getVisitedPLMNId().value().c_str(),HSS_VPLMNID_LEN);
      LLOG_HEX(0,0,"ULR VplmnId", m_VplmnId, HSS_VPLMNID_LEN); 
      m_tdr.setHex(TDR_INDEX_ULR_VPLMN_ID, (char*)m_VplmnId, HSS_VPLMNID_LEN);
   }
   else
   {
      WLOG(0,0,"VplmnId Length[%d] is not 3 octets .. sending Error",l_ulrReq->getVisitedPLMNId().value().size());
      return false;
   }

   // .. Mandatory Params End 

   LogULRFlags(); // logging ULR Flags

   if(m_nodeTypeInd == NODETYPE_SGSN)
   {
      WLOG(0,0,"Node Type Indicator ONLY SGSN .. not supporting sending Error");
      return false;
   }

   int l_numSuppFeatures = l_ulrReq->countSupportedFeatures();
   VendorIdFeatureList l_featureList;

   for(int i = 0; i < l_numSuppFeatures; i++) 
   {
      SupportedFeatures l_suppFeatures = l_ulrReq->getSupportedFeatures(i);
      memset(&l_featureList,'\0',sizeof(l_featureList));
      l_featureList.m_vendorId = (l_suppFeatures.getVendorId()).value();
      l_featureList.m_featureListId = (l_suppFeatures.getFeatureListID()).value();
      l_featureList.m_featureList = (l_suppFeatures.getFeatureList()).value();
      // l_suppFeatures.countExtra(); TODO check this and loop accordingly ... (assuming no extras)
      m_vendorIdFeatureList.push_back(l_featureList);
   }

   LogSupportedFeatures(); // logging Supported Features

   if(true == l_ulrReq->containsTerminalInformation())
   {
      TerminalInformation l_terminalInfo = l_ulrReq->getTerminalInformation();
      if(true == l_terminalInfo.containsIMEI())
      {
         if(15 <= strlen((char*)l_terminalInfo.getIMEI().value().c_str()))
         {
            //15th digit of the IMEI AVP is received, the HSS may discard the digit
            //LLOG(0,0,"Terminal Information: IMEI:[%s] .. 15th digit of IMEI recvd discarding it",(char*)l_terminalInfo.getIMEI().value().c_str());
            LLOG(0,0,"Terminal Information: IMEI:[%s] .. 15th digit of IMEI recvd discarding it","XXXXXXXX");
         }
         snprintf(m_terminalInformation.m_Imei, 15, (char*)l_terminalInfo.getIMEI().value().c_str());
         //LLOG(0,0,"Terminal Information: IMEI:[%s]",m_terminalInformation.m_Imei);
      }
      if(true == l_terminalInfo.containsS6a3GPP2MEID())
      {
         if( HSS_3GPP2_MEID_LEN == l_terminalInfo.getS6a3GPP2MEID().value().size() )
         {
            memcpy(m_terminalInformation.m_3gpp2Meid,l_terminalInfo.getS6a3GPP2MEID().value().c_str(),l_terminalInfo.getS6a3GPP2MEID().value().size());
            LLOG_HEX(0,0,"Terminal Information: 3GPP2MEID:", m_terminalInformation.m_3gpp2Meid, HSS_3GPP2_MEID_LEN); 
            m_tdr.setHex(TDR_INDEX_ULR_MEID, (char*)m_terminalInformation.m_3gpp2Meid, HSS_3GPP2_MEID_LEN);
         }
         else
         {
            CLOG(0,0,"3GPP2MEID Length[%d] is not 8 octets .. sending Roaming Not Allowed Error",l_terminalInfo.getS6a3GPP2MEID().value().size());
            return false;
         }
      }
      if(true == l_terminalInfo.containsSoftwareVersion())
      {
         strcpy(m_terminalInformation.m_SoftwareVersion,(char*)l_terminalInfo.getSoftwareVersion().value().c_str());
         LLOG(0,0,"Terminal Information: SOFTWAREVERSION: [%s]",m_terminalInformation.m_SoftwareVersion);
         m_tdr.setString(TDR_INDEX_ULR_SOFTWARE_VERSION, m_terminalInformation.m_SoftwareVersion);
         strncat(m_terminalInformation.m_Imei, m_terminalInformation.m_SoftwareVersion, 2);
      }

      //6.1.10.0 start
      snprintf((char*)m_Orig_Imei,sizeof(m_Orig_Imei),"%s",m_terminalInformation.m_Imei);
      DLOG(0,0,"Orig_Imei is [%s]",m_Orig_Imei);
      //6.1.10.0 end
      
      //4.0.2.0
      if(1 == g_IMEI_EncrFlag) 
      {
         char l_tempIMEI[200];
         memset(l_tempIMEI,'\0',sizeof(l_tempIMEI));
         bool res = Copy_encryptedIMEI((char*)m_terminalInformation.m_Imei,l_tempIMEI);
         unsigned char l_rawImei[200];
         memset(l_rawImei,'\0',sizeof(l_rawImei));
         hexToStringWithoutSpace(l_rawImei, 200, (unsigned char*)l_tempIMEI, 16);
         m_tdr.setString(TDR_INDEX_IMEI,(char*)l_rawImei);
         if(res == true)
         {
            memset((char*)m_terminalInformation.m_Imei,'\0',strlen((char*)m_terminalInformation.m_Imei));
            strncpy((char*)m_terminalInformation.m_Imei,(char*)l_rawImei,strlen((char*)l_rawImei));
         }
         else
         {
            CLOG(0,0,"Encryption of Imei Failed !!!!");
         }
         //LLOG(0,0,"IMEI+SV: %s", l_rawImei);

      }
      else
      {
         m_tdr.setString(TDR_INDEX_IMEI,m_terminalInformation.m_Imei);
      }
   }

   if(true == l_ulrReq->containsUESRVCCCapability())
   {
      m_UeSrvccCap = (UESRVCCCapability::Value)(l_ulrReq->getUESRVCCCapability().value());
      LLOG(0,0,"ULR UESRVCCCapability[%d]", m_UeSrvccCap);
      m_tdr.setInteger(TDR_INDEX_ULR_UE_SRVCC_CAP, m_UeSrvccCap);
   }

   if(true == l_ulrReq->containsHomogeneousSupportofIMSVoiceOverPSSessions())
   {
      m_HsImsPs = (HomogeneousSupportofIMSVoiceOverPSSessions::Value)(l_ulrReq->getHomogeneousSupportofIMSVoiceOverPSSessions().value());
      LLOG(0,0,"ULR HomogeneousSupportofIMSVoiceOverPSSessions[%d]", m_HsImsPs);
      m_tdr.setInteger(TDR_INDEX_ULR_HS_IMS_OVER_PS, m_HsImsPs);
   }

   if(true == l_ulrReq->containsGMLCAddress())
   {
      Address l_Address = l_ulrReq->getGMLCAddress().value();
      m_GmlcFamily = (Address::Family)(l_Address.family);
      convertHextoIPV4(l_Address.value, m_GmlcAddress);
      LLOG(0,0,"ULR GMLCAddress[%d:%s]", m_GmlcFamily, m_GmlcAddress);
      m_tdr.setString(TDR_INDEX_ULR_GMLC_ADDERSS, m_GmlcAddress);
   }

   if(1 == g_LteMmConfigReaderObj->m_ActiveApnUpdateFlag)
   {
      for(int l_Index = 0; l_Index < l_ulrReq->countActiveAPN(); l_Index++)
      {
         ActiveApnDetails l_ActiveApnDetails;
         memset(&(l_ActiveApnDetails.m_baseApn), '\0', sizeof(l_ActiveApnDetails.m_baseApn));

         ActiveAPN l_activeAPN = l_ulrReq->getActiveAPN(l_Index);

         l_ActiveApnDetails.m_ContextId = l_activeAPN.getContextIdentifier().value();

         if(true == l_activeAPN.containsServiceSelection())
         {
            strcpy(l_ActiveApnDetails.m_baseApn.m_ServiceSelection, l_activeAPN.getServiceSelection().value().c_str());
         }

         int l_NumHomeAgentAdd = 0;
         if(true == l_activeAPN.containsMIP6AgentInfo())
         {
            l_NumHomeAgentAdd = l_activeAPN.getMIP6AgentInfo().countMIPHomeAgentAddress();
            if(l_NumHomeAgentAdd > 2)
               LLOG(0,0,"Maximum 2 PGW addresses only allowed. Received [%d] addresses", l_NumHomeAgentAdd);

            if(l_NumHomeAgentAdd > 0)
            {
               Address l_Address = l_activeAPN.getMIP6AgentInfo().getMIPHomeAgentAddress(0).value();
               l_ActiveApnDetails.m_baseApn.m_MipHomeAgentFamily1 = (Address::Family)l_Address.family;
               convertHextoIPV4(l_Address.value, l_ActiveApnDetails.m_baseApn.m_MipHomeAgentAddress1);
            }

            if(l_NumHomeAgentAdd > 1)
            {
               Address l_Address = l_activeAPN.getMIP6AgentInfo().getMIPHomeAgentAddress(1).value();
               l_ActiveApnDetails.m_baseApn.m_MipHomeAgentFamily2 = (Address::Family)l_Address.family;
               convertHextoIPV4(l_Address.value, l_ActiveApnDetails.m_baseApn.m_MipHomeAgentAddress2);
            }


            if(true == l_activeAPN.getMIP6AgentInfo().containsMIPHomeAgentHost())
            {
               strcpy(l_ActiveApnDetails.m_baseApn.m_AgentHost, l_activeAPN.getMIP6AgentInfo().getMIPHomeAgentHost().getDestinationHost().value().c_str());
               strcpy(l_ActiveApnDetails.m_baseApn.m_AgentRealm, l_activeAPN.getMIP6AgentInfo().getMIPHomeAgentHost().getDestinationRealm().value().c_str());
            }

            if(true == l_activeAPN.getMIP6AgentInfo().containsMIP6HomeLinkPrefix())
            {
               strcpy(l_ActiveApnDetails.m_baseApn.m_MIP6HomeLinkPrefix, l_activeAPN.getMIP6AgentInfo().getMIP6HomeLinkPrefix().value().c_str());
            }
         }

         if(true == l_activeAPN.containsVisitedNetworkIdentifier())
         {
            strcpy(l_ActiveApnDetails.m_baseApn.m_VisitedNetworkId, l_activeAPN.getVisitedNetworkIdentifier().value().c_str());
         }

         LLOG(0,0,"ActiveAPNindex[%d]: ContextId[%d] ServiceSelection[%s] NumHomeAgentAdd[%d] HomeAgentAddress1[%d:%s], HomeAgentAddress2[%d:%s] AgentHost[%s] Realm[%s] LinkPrefix[%s] VisitedNetworkId[%s] SpecAPNCount[%d]", 
               l_Index+1, l_ActiveApnDetails.m_ContextId, l_ActiveApnDetails.m_baseApn.m_ServiceSelection, l_NumHomeAgentAdd, l_ActiveApnDetails.m_baseApn.m_MipHomeAgentFamily1, l_ActiveApnDetails.m_baseApn.m_MipHomeAgentAddress1, l_ActiveApnDetails.m_baseApn.m_MipHomeAgentFamily2, l_ActiveApnDetails.m_baseApn.m_MipHomeAgentAddress2, l_ActiveApnDetails.m_baseApn.m_AgentHost, l_ActiveApnDetails.m_baseApn.m_AgentRealm, l_ActiveApnDetails.m_baseApn.m_MIP6HomeLinkPrefix, l_ActiveApnDetails.m_baseApn.m_VisitedNetworkId, l_activeAPN.countSpecificAPNInfo());

         for(int l_SpecApnIndex =0; l_SpecApnIndex<l_activeAPN.countSpecificAPNInfo(); l_SpecApnIndex++)
         {
            SpecificApnDetails l_SpecificApnDetails;
            memset(&l_SpecificApnDetails, '\0', sizeof(l_SpecificApnDetails));

            SpecificAPNInfo l_specificAPN = l_activeAPN.getSpecificAPNInfo(l_SpecApnIndex);
            strcpy(l_SpecificApnDetails.m_ServiceSelection, l_specificAPN.getServiceSelection().value().c_str());

            int l_NumHomeAgentAdd = l_specificAPN.getMIP6AgentInfo().countMIPHomeAgentAddress();
            if(l_NumHomeAgentAdd > 2)
               LLOG(0,0,"Maximum 2 PGW addresses only allowed. Received [%d] addresses", l_NumHomeAgentAdd);

            if(l_NumHomeAgentAdd > 0)
            {
               Address l_Address = l_specificAPN.getMIP6AgentInfo().getMIPHomeAgentAddress(0).value();
               l_SpecificApnDetails.m_MipHomeAgentFamily1 = (Address::Family)l_Address.family;
               convertHextoIPV4(l_Address.value, l_SpecificApnDetails.m_MipHomeAgentAddress1);
            }

            if(l_NumHomeAgentAdd > 1)
            {
               Address l_Address = l_specificAPN.getMIP6AgentInfo().getMIPHomeAgentAddress(1).value();
               l_SpecificApnDetails.m_MipHomeAgentFamily2 = (Address::Family)l_Address.family;
               convertHextoIPV4(l_Address.value, l_SpecificApnDetails.m_MipHomeAgentAddress2);
            }


            if(true == l_specificAPN.getMIP6AgentInfo().containsMIPHomeAgentHost())
            {
               strcpy(l_SpecificApnDetails.m_AgentHost, l_specificAPN.getMIP6AgentInfo().getMIPHomeAgentHost().getDestinationHost().value().c_str());
               strcpy(l_SpecificApnDetails.m_AgentRealm, l_specificAPN.getMIP6AgentInfo().getMIPHomeAgentHost().getDestinationRealm().value().c_str());
            }

            if(true == l_specificAPN.getMIP6AgentInfo().containsMIP6HomeLinkPrefix())
            {
               strcpy(l_SpecificApnDetails.m_MIP6HomeLinkPrefix, l_specificAPN.getMIP6AgentInfo().getMIP6HomeLinkPrefix().value().c_str());
            }

            if(true == l_specificAPN.containsVisitedNetworkIdentifier())
            {
               strcpy(l_SpecificApnDetails.m_VisitedNetworkId, l_specificAPN.getVisitedNetworkIdentifier().value().c_str());
            }
            l_ActiveApnDetails.m_SpecificApnList.push_back(l_SpecificApnDetails);

            LLOG(0,0,"ActiveAPNindex[%d]: SpecificAPNindex[%d]: ServiceSelection[%s] NumHomeAgentAdd[%d] HomeAgentAddress1[%d:%s], HomeAgentAddress2[%d:%s] AgentHost[%s] Realm[%s] LinkPrefix[%s] VisitedNetworkId[%s]",l_Index+1,l_SpecApnIndex+1,l_SpecificApnDetails.m_ServiceSelection, l_NumHomeAgentAdd, l_SpecificApnDetails.m_MipHomeAgentFamily1, l_SpecificApnDetails.m_MipHomeAgentAddress1, l_SpecificApnDetails.m_MipHomeAgentFamily2, l_SpecificApnDetails.m_MipHomeAgentAddress2, l_SpecificApnDetails.m_AgentHost, l_SpecificApnDetails.m_AgentRealm, l_SpecificApnDetails.m_MIP6HomeLinkPrefix, l_SpecificApnDetails.m_VisitedNetworkId);
         }
         m_ActiveApnList.push_back(l_ActiveApnDetails);
      }
   }

   if(true == l_ulrReq->containsSGSNNumber())
   {
      BCDToString((u8*)m_SgsnNumber, (u8*)l_ulrReq->getSGSNNumber().value().c_str(), l_ulrReq->getSGSNNumber().value().size()) ;
      LLOG(0,0,"SGSN Number : [%s]",m_SgsnNumber);
      m_tdr.setString(TDR_INDEX_SGSN_ADDRESS, m_SgsnNumber);
   }
   return true;
}

bool CtxtLteUpdateLocationRequest :: handleDbQuery()
{
   LteSubsDbData *l_hssSubsData = NULL;
   l_hssSubsData = new LteSubsDbData;
   if(NULL != l_hssSubsData)
   {
      strcpy(l_hssSubsData->m_UlrImsi_IN,m_UlrImsi);
      strcpy(l_hssSubsData->m_MmeHost_IN,m_MmeHost);
      strcpy(l_hssSubsData->m_MmeRealm_IN,m_MmeRealm);
      l_hssSubsData->m_RatType_IN = m_RatType;
      l_hssSubsData->m_UlrFlag_IN = m_UlrFlag;
      memcpy(l_hssSubsData->m_VplmnId_IN,m_VplmnId,3);

      //6.4.0.0 MccMnc start
      //hexToString((unsigned char *)l_hssSubsData->m_MccMnc_IN, 6, m_VplmnId, 3);
      BCDToString((u8*)l_hssSubsData->m_MccMnc_IN, m_VplmnId, 3) ;
      //snprintf(l_hssSubsData->m_MccMnc_IN,sizeof(l_hssSubsData->m_MccMnc_IN),"%s","435363");
      if((l_hssSubsData->m_MccMnc_IN[3] == 'f') || (l_hssSubsData->m_MccMnc_IN[3] == 'F'))
      {  
         string l_MccMncRemoval = l_hssSubsData->m_MccMnc_IN;
         l_MccMncRemoval.erase(3,1);
         memset(l_hssSubsData->m_MccMnc_IN,'\0',sizeof(l_hssSubsData->m_MccMnc_IN));
         snprintf((char*)l_hssSubsData->m_MccMnc_IN,sizeof(l_hssSubsData->m_MccMnc_IN),"%s",l_MccMncRemoval.c_str());
      }
      //6.4.0.0 MccMnc End
      strcpy(l_hssSubsData->m_Imei_IN,m_terminalInformation.m_Imei);
      memcpy(l_hssSubsData->m_3gpp2Meid_IN,m_terminalInformation.m_3gpp2Meid,8);
      strcpy(l_hssSubsData->m_GmlcAddress_IN,m_GmlcAddress);
      l_hssSubsData->m_FeatureList1_IN = m_featureList1;
      l_hssSubsData->m_FeatureList2_IN = m_featureList2;
      l_hssSubsData->m_NodeTypeInd_IN = m_nodeTypeInd;
      l_hssSubsData->m_NodeTypeInd_IN = (int)m_nodeTypeInd;
      l_hssSubsData->m_UeSrvccCap_IN = m_UeSrvccCap;
      l_hssSubsData->m_HssImsVoipSessions_IN = m_HsImsPs;
      snprintf((char*)l_hssSubsData->m_Orig_Imei,sizeof(l_hssSubsData->m_Orig_Imei),"%s",m_Orig_Imei);
      LLOG(0,0,"DBIN: Imsi[%s] Sgsn[%s] InstanceId[%s] Imei[%s] GmlcAddr[%s] MmeHost[%s] MmeRealm[%s] UlrFlag[%u] RatType[%d] UeSrvcc[%d] ImsVoipSess[%d] FeatureList1[%u] FeatureList2[%u] ExtSuppFeature[%s] MmeSmsSup[%d] MmeNumMtSms[%s] ApnArrayCount[%d] SpecApnArrayCount[%d] NodeTypeInd[%d] MccMnc[%s]",l_hssSubsData->m_UlrImsi_IN,l_hssSubsData->m_SgsnNumber_IN,g_entityName,l_hssSubsData->m_Imei_IN,l_hssSubsData->m_GmlcAddress_IN,l_hssSubsData->m_MmeHost_IN,l_hssSubsData->m_MmeRealm_IN,l_hssSubsData->m_UlrFlag_IN,l_hssSubsData->m_RatType_IN,l_hssSubsData->m_UeSrvccCap_IN,l_hssSubsData->m_HssImsVoipSessions_IN,l_hssSubsData->m_FeatureList1_IN,l_hssSubsData->m_FeatureList2_IN,l_hssSubsData->m_ExtSuppFeatureList_IN,0,"",0,0,l_hssSubsData->m_NodeTypeInd_IN,l_hssSubsData->m_MccMnc_IN);
      DLOG(0,0,"OriginalImei[%s]",l_hssSubsData->m_Orig_Imei);
      LLOG_HEX(0,0,"DBIN: VplmnId", l_hssSubsData->m_VplmnId_IN, 3); 
      LLOG_HEX(0,0,"DBIN: ImeiMeid", l_hssSubsData->m_3gpp2Meid_IN, 8); 
   }
   else
   {
      CLOG(0,0,"Newing HssSubsData failed");
   }
   TLOG(0,0,"Pushing data to DB");
   l_hssSubsData->m_cb = this;
   l_hssSubsData->m_DbQueryType = 1;

   if((1 == g_ConfigData->m_MemcEnableFlag) && (1 == g_LteMmConfigReaderObj->m_ULRMemcachedFlag) && (false == m_fIdr))
   {
      l_hssSubsData->m_DbQueryCachedType = DB_QUERY_CACHED_TYPE_CACHED;
      l_hssSubsData->m_MemcQueryType = MEMC_QUERY_TYPE_GET;
   }

   if(true == m_fIdr)
   {
     LLOG(0,0,"Setting Full IDR DB indicator to 1");
     l_hssSubsData->m_FullIdrInd_IN = 1;
   }
   g_act.execute(l_hssSubsData);
   return true;
}

bool CtxtLteUpdateLocationRequest::SendCancelLocation()
{
   char l_CancelLocXml[500];
   memset(l_CancelLocXml,'\0',sizeof(l_CancelLocXml));
   int l_NodeChangeCL = 0;
   int l_CancelLocType = 0;
   bool l_sendCL = false;

   if(true == m_fIdr)
   {
      l_CancelLocType = CancellationType::MME_UPDATE_PROCEDURE;
      sprintf(l_CancelLocXml, "<CANCEL_LOC><IMSI>%s</IMSI><NODE_TYPE>%s</NODE_TYPE><ORIGIN_HOST>%s</ORIGIN_HOST><ORIGIN_REALM>%s</ORIGIN_REALM><DESTINATION_HOST>%s</DESTINATION_HOST><DESTINATION_REALM>%s</DESTINATION_REALM><UPDATE_SUBS_DATA>%d</UPDATE_SUBS_DATA><CL_TYPE>%d</CL_TYPE><IMSI_TYPE>%d</IMSI_TYPE><REQUEST_TYPE>%s</REQUEST_TYPE><NETWORK_ID>%d</NETWORK_ID></CANCEL_LOC>",
            m_UlrImsi, "MME", mp_HssSubsData->m_HssOriginHost_OUT, mp_HssSubsData->m_HssOriginRealm_OUT, mp_HssSubsData->m_OldMmeHost_OUT, mp_HssSubsData->m_OldMmeRealm_OUT, 1, l_CancelLocType, mp_HssSubsData->m_PartnerType_OUT, "LTE_UPDATE_LOC", mp_HssSubsData->m_NetworkId_OUT);
      LLOG(0,0,"IDR failed, sending Cancel Location towards MME Host [%s] CLR :%s:", mp_HssSubsData->m_OldMmeHost_OUT , l_CancelLocXml);
      g_esc.initiateIndependentContext(this, DIAM_COMM_CODE_S6A_S6D_CLR_CLA, l_CancelLocXml, INITIATION_TYPE_IMMEDIATE);

      return true;
   }

   l_NodeChangeCL = strcmp(m_MmeHost,mp_HssSubsData->m_OldMmeHost_OUT);

   if(l_NodeChangeCL != 0 )
   {
      l_sendCL = true;
      if(true == m_Initial_Attach_Ind)
      {
         l_CancelLocType = CancellationType::INITIAL_ATTACH_PROCEDURE;
         TLOG(0,0,"Initial Attach CL");
      }
      else
      {
         l_CancelLocType = CancellationType::MME_UPDATE_PROCEDURE;
         TLOG(0,0,"Node Change CL");
      }
      m_tdr.setString(TDR_INDEX_MM_PREVIOUS_NODE,mp_HssSubsData->m_OldMmeHost_OUT);
   }

   if( (true == l_sendCL) && (strlen(mp_HssSubsData->m_OldMmeHost_OUT) > 1) && (strlen(mp_HssSubsData->m_HssOriginHost_OUT) > 1)) 
   {
      sprintf(l_CancelLocXml, "<CANCEL_LOC><IMSI>%s</IMSI><NODE_TYPE>%s</NODE_TYPE><ORIGIN_HOST>%s</ORIGIN_HOST><ORIGIN_REALM>%s</ORIGIN_REALM><DESTINATION_HOST>%s</DESTINATION_HOST><DESTINATION_REALM>%s</DESTINATION_REALM><UPDATE_SUBS_DATA>%d</UPDATE_SUBS_DATA><CL_TYPE>%d</CL_TYPE><IMSI_TYPE>%d</IMSI_TYPE><REQUEST_TYPE>%s</REQUEST_TYPE><NETWORK_ID>%d</NETWORK_ID></CANCEL_LOC>", 
            m_UlrImsi, "MME", mp_HssSubsData->m_HssOriginHost_OUT, mp_HssSubsData->m_HssOriginRealm_OUT, mp_HssSubsData->m_OldMmeHost_OUT, mp_HssSubsData->m_OldMmeRealm_OUT, 0, l_CancelLocType, mp_HssSubsData->m_PartnerType_OUT, "LTE_UPDATE_LOC", mp_HssSubsData->m_NetworkId_OUT);
      LLOG(0,0,"Sending CL: Type[%d] NodeTypeInd[%d] InitAttachInd[%d] SingleRegInd[%d]",l_CancelLocType,m_nodeTypeInd,m_Initial_Attach_Ind,m_Single_Reg_Ind);
      g_esc.initiateIndependentContext(this, DIAM_COMM_CODE_S6A_S6D_CLR_CLA, l_CancelLocXml, INITIATION_TYPE_IMMEDIATE);
   }

   if( (strlen(mp_HssSubsData->m_HlrAddress_OUT) > 1) && (strlen(mp_HssSubsData->m_SgsnNumber_OUT) > 1))
   {
      //if(1 == g_LteMmConfigReaderObj->m_SendCrossCL)
      if(1)
      {
         //if( (true == m_Single_Reg_Ind) && (strlen(mp_HssSubsData->m_SgsnNumber_OUT) > 1) ) // to SGSN
         sprintf(l_CancelLocXml, "<CANCEL_LOC><IMSI>%s</IMSI><TYPE>%s</TYPE><LMSI>%s</LMSI><DEST_ADDRESS>%s</DEST_ADDRESS><ORIG_ADDRESS>%s</ORIG_ADDRESS><CL_TYPE>%d</CL_TYPE><CLR_SUBS_DATA>%d</CLR_SUBS_DATA><IMSI_TYPE>%d</IMSI_TYPE><REQUEST_TYPE>%s</REQUEST_TYPE><MSC_NUMBER>%s</MSC_NUMBER><NETWORK_ID>%d</NETWORK_ID></CANCEL_LOC>", 
               m_UlrImsi, "GPRS", "", mp_HssSubsData->m_SgsnNumber_OUT, mp_HssSubsData->m_HlrAddress_OUT, 0, 1, mp_HssSubsData->m_PartnerType_OUT, "CROSS_CL_LTE_ULR", "",mp_HssSubsData->m_NetworkId_OUT);
         LLOG(0,0,"Sending CL towards SGSN .. ");
         g_sc.initiateIndependentContext(this, MAP_OP_CODE_cancelLocation, l_CancelLocXml, INITIATION_TYPE_IMMEDIATE);
      }
      else
      {
         TLOG(0,0,"Cross-CL disabled");
      }
   }


   return true;
}

bool CtxtLteUpdateLocationRequest::handleDBResponse()
{
   g_EmergencyFlag = g_spdPtr->m_MsisdnPrefReplaceStruct.m_CongestionEmergencyFlag;
   LLOG(0,0,"DBRES: EmergencyFlag[%d]",g_EmergencyFlag);
   m_tdr.setInteger(TDR_INDEX_NOR_VISITED_NET_ID,g_EmergencyFlag);

   LLOG(0,0,"DBRES: ErrorCode[%d] ErrorMessage[%s]",mp_HssSubsData->m_ErrorCode_OUT,mp_HssSubsData->m_ErrorMsg_OUT);
   LLOG(0,0,"DBRES: AccountId[%s] NetworkId[%d] PartnerNkId[%d] AllocType[%d] ActiveMsisdn[%s] PrimaryMsisdn[%s] PrimaryImsi[%s] RoamInd[%d] Mwd[%d]",mp_HssSubsData->m_AccountId_OUT,mp_HssSubsData->m_NetworkId_OUT,mp_HssSubsData->m_PartnerNkId_OUT,mp_HssSubsData->m_AllocationType_OUT,mp_HssSubsData->m_Msisdn_OUT,mp_HssSubsData->m_PrimaryMsisdn_OUT,mp_HssSubsData->m_PrimaryImsi_OUT,mp_HssSubsData->m_RoamingInd_OUT,mp_HssSubsData->m_Mwd_OUT);
   m_tdr.setString(TDR_INDEX_ACCOUNT_ID, mp_HssSubsData->m_AccountId_OUT);
   m_tdr.setInteger(TDR_INDEX_CM_SRI_TCSI_STATUS,mp_HssSubsData->m_RoamingInd_OUT);
   LLOG(0,0,"DBRES: PartnerType[%d] AlertMsisdn[%s] OldMsisdn[%s] AllocStatus[%d] MsisdnFreeCount[%u] FirstULR[%d] ImsiBasedFUL[%s] MmeSeqNum[%u] LogPrefix[%s]",mp_HssSubsData->m_PartnerType_OUT,mp_HssSubsData->m_AlertMsisdn_OUT,mp_HssSubsData->m_OldMsisdn_OUT,mp_HssSubsData->m_AllocationStatus_OUT,mp_HssSubsData->m_MsisdnFreeCount_OUT,mp_HssSubsData->m_FirstUL_OUT,mp_HssSubsData->m_TdrResrvData_OUT,mp_HssSubsData->m_MmeSeqNum_OUT,mp_HssSubsData->m_LogPrefix_OUT);
   LLOG(0,0,"DBRES: LocalImsiSubscription[%d] LocalImsi[%s] LocalMsisdn[%s] PreBurntImsi[%d] RoamCC[%s]",mp_HssSubsData->m_LocalImsiSubscription_OUT,mp_HssSubsData->m_LocalImsi_OUT,mp_HssSubsData->m_LocalMsisdn_OUT,mp_HssSubsData->m_PreBurntImsi_OUT,mp_HssSubsData->m_RoamCC_OUT);
   LLOG(0,0,"DBRES: FreeCount[%u] ThreshCount[%u] SimStructure[%s] TempMsisdnFreeCount[%u] TempMsisdnThreshCount[%u] NAM[%d] SubsStatus[%d]",mp_HssSubsData->m_FreeCount_OUT,mp_HssSubsData->m_ThresholdCount_OUT,mp_HssSubsData->m_SimStructure_OUT,mp_HssSubsData->m_TempMsisdnFreeCount_OUT,mp_HssSubsData->m_ThresholdCount_OUT,mp_HssSubsData->m_Nam_OUT,mp_HssSubsData->m_SubscriberStatus_OUT);
   LLOG(0,0,"DBRES: OdbGen[%u] OdbHplmn[%u] PdpProfId[%u] LteProfId[%u] AccessRestr[%u] OldMmeHost[%s] OldMmeRealm[%s]",mp_HssSubsData->m_Odb_OUT,mp_HssSubsData->m_HplmnOdb_OUT,mp_HssSubsData->m_PdpProfId_OUT,mp_HssSubsData->m_LteConfigProfId_OUT,mp_HssSubsData->m_AccessRestriction_OUT,mp_HssSubsData->m_OldMmeHost_OUT,mp_HssSubsData->m_OldMmeRealm_OUT);
   LLOG(0,0,"DBRES: OldSgsnAddr[%s] OldSgsnNum[%s] HssOrigHost[%s] HssOrigRealm[%s] HlrAddr[%s] S6aReleaseNum[%d]",mp_HssSubsData->m_SgsnAddress_OUT,mp_HssSubsData->m_SgsnNumber_OUT,mp_HssSubsData->m_HssOriginHost_OUT,mp_HssSubsData->m_HssOriginRealm_OUT,mp_HssSubsData->m_HlrAddress_OUT,mp_HssSubsData->m_S6aRelease_OUT);
   LLOG(0,0,"DBRES: Count of OSS Triggers: [%d] ... TdrRestrData[%s]", mp_HssSubsData->m_ossTriggerDataCount_OUT, mp_HssSubsData->m_TdrRestrData_OUT);
   LLOG(0,0,"DBRES: DsrFlag[%d] DsrContexts[%s]",mp_HssSubsData->m_dsrFlag_OUT,mp_HssSubsData->m_dsrContexts_OUT);
   LLOG(0,0,"DBRES: IMSService[%d] ImsProfileId[%d]",mp_HssSubsData->m_ims_service_flag_OUT,mp_HssSubsData->m_ImsProfId_OUT);

   LLOG(0,0,"DBRES: Cancel Location RowId Flag[%d]",mp_HssSubsData->m_crossClType_OUT);

   LLOG(0,0,"DBRES: Stn-Sr [%s]",mp_HssSubsData->m_StnSr_OUT);

   LLOG(0,0,"DBRES: Template FTN Info [%s]",mp_HssSubsData->m_TemplateFtnInfo_OUT);
   m_tdr.setString(TDR_INDEX_AUC_NUM_VECTORS_SENT,mp_HssSubsData->m_TemplateFtnInfo_OUT);
   
   LLOG(0,0,"DBRES: TAC Info [%s]",mp_HssSubsData->m_TacInfo_OUT);
   m_tdr.setString(TDR_INDEX_SSM_NO_REP_TIMER,mp_HssSubsData->m_TacInfo_OUT);

   LLOG(0,0,"DBRES: Previous IMEI [%s]",mp_HssSubsData->m_PreviousImei_OUT);
   m_tdr.setString(TDR_INDEX_MM_PREVIOUS_IMEI,(char*)mp_HssSubsData->m_PreviousImei_OUT);

   LLOG(0,0,"DBRES: ImsApnMccMncData [%s]",mp_HssSubsData->m_MccMncWhitelist_OUT);
   LLOG(0,0,"DBRES: ISR VoLTE Roaming Capability[%s]",mp_HssSubsData->m_voLteRoamingCap_OUT);
   LLOG(0,0,"DBRES: Migration Helper Details [%s]",mp_HssSubsData->m_migrationHelperTdr_OUT);
   m_tdr.setString(TDR_INDEX_AUC_AFR_RAND,(char*)mp_HssSubsData->m_voLteRoamingCap_OUT);
   m_tdr.setString(TDR_INDEX_HLR_RESRV9,(char*)mp_HssSubsData->m_migrationHelperTdr_OUT);
   
   m_tdr.setInteger(TDR_INDEX_SSM_BS_TYPE, mp_HssSubsData->m_ApnOiOverrideInd_OUT); // 37th index
   m_tdr.setInteger(TDR_INDEX_AUC_RESYNC_INFO, mp_HssSubsData->m_PrimaryIndicator_OUT); // 51 index

   m_tdr.setInteger(TDR_INDEX_HLR_RESRV3,mp_HssSubsData->m_crossClType_OUT); // HLR 2.0.18.0_R1 
   char l_currentOssData[5000 + 1];
   char l_tokensOssData[10][5000 + 1];
   for (int l_i=0; l_i<mp_HssSubsData->m_ossTriggerDataCount_OUT; l_i++)
   {
      memset(l_tokensOssData,'\0',sizeof(l_tokensOssData));
      memset(l_currentOssData,'\0',sizeof(l_currentOssData));
      sprintf(l_currentOssData,"|%s|",mp_HssSubsData->m_ossTriggerData_OUT[l_i]);
      tokenize(l_currentOssData, (char*)l_tokensOssData, 5001);
      TLOG(0,0,"RowId[%s] TransId[%s] Opcode[%d] TransXmlLen[%d]", l_tokensOssData[1],l_tokensOssData[2],atoi(l_tokensOssData[3]),strlen(l_tokensOssData[4]));
      TLOG(0,0,"Current Data [%s]",l_currentOssData);

      LLOG(0,0, "Cancel Location CROSS CL sending flag [%d]",mp_HssSubsData->m_crossClType_OUT);
      if(1 == mp_HssSubsData->m_crossClType_OUT)
      {
         if(DIAM_COMM_CODE_S6A_S6D_CLR_CLA == atoi(l_tokensOssData[3]))
         {
            LLOG(0,0,"Initiating DIAM CL: RowId[%s] TransId[%s]",l_tokensOssData[1],l_tokensOssData[2]);
            g_esc.initiateIndependentContext(this, DIAM_COMM_CODE_S6A_S6D_CLR_CLA, l_tokensOssData[4], INITIATION_TYPE_IMMEDIATE);
         }
         else if(MAP_OP_CODE_cancelLocation == atoi(l_tokensOssData[3]))
         {
            LLOG(0,0,"Initiating MAP CL: RowId[%s] TransId[%s]",l_tokensOssData[1],l_tokensOssData[2]);
            g_sc.initiateIndependentContext(this, MAP_OP_CODE_cancelLocation, l_tokensOssData[4], INITIATION_TYPE_IMMEDIATE);
         }
      }
      else 
      {
         EMsgType l_msgType;
         if(true == whetherToProcess(atoi(l_tokensOssData[3]),&l_msgType))
         {
            if(MSG_TYPE_DIAMETER == l_msgType)
            {
               LLOG(0,0,"Initiating DIAM CL: RowId[%s] TransId[%s]",l_tokensOssData[1],l_tokensOssData[2]);
               g_esc.initiateIndependentContext(this, DIAM_COMM_CODE_S6A_S6D_CLR_CLA, l_tokensOssData[4], INITIATION_TYPE_IMMEDIATE);
            }
            else if(MSG_TYPE_MAP == l_msgType)
            {
               LLOG(0,0,"Initiating MAP CL: RowId[%s] TransId[%s]",l_tokensOssData[1],l_tokensOssData[2]);
               g_sc.initiateIndependentContext(this, MAP_OP_CODE_cancelLocation, l_tokensOssData[4], INITIATION_TYPE_IMMEDIATE);
            }
         }
         else
         {
            LLOG(0,0,"Not processing CL: RowId[%s] TransId[%s]",l_tokensOssData[1],l_tokensOssData[2]);
            if(0 == l_i)
               m_tdr.setString(TDR_INDEX_ULR_ROWID_ONE,l_tokensOssData[1]);
            else if(1 == l_i)
               m_tdr.setString(TDR_INDEX_ULR_ROWID_TWO,l_tokensOssData[1]);
            else if(2 == l_i)
               m_tdr.setString(TDR_INDEX_ULR_ROWID_THREE,l_tokensOssData[1]);
            else if(3 == l_i)
               m_tdr.setString(TDR_INDEX_ULR_ROWID_FOUR,l_tokensOssData[1]);
         }
      }
   }


   if(mp_HssSubsData->m_ErrorCode_OUT != 0)
   {
      m_tdr.setInteger(TDR_INDEX_DB_ERR_CODE, mp_HssSubsData->m_ErrorCode_OUT);
      m_tdr.setString(TDR_INDEX_DB_ERR_DESC, mp_HssSubsData->m_ErrorMsg_OUT);
   }
   m_tdr.setString(TDR_INDEX_LOCAL_ADDRESS,mp_HssSubsData->m_HlrAddress_OUT);
   m_tdr.setString(TDR_INDEX_SGSN_ADDRESS,mp_HssSubsData->m_SgsnAddress_OUT);
   m_tdr.setInteger(TDR_INDEX_MM_LOCAL_NUM_ALLOCATION_STATUS,mp_HssSubsData->m_LocalImsiSubscription_OUT);
   m_tdr.setString(TDR_INDEX_RESRV3,mp_HssSubsData->m_RoamCC_OUT);
   m_tdr.setInteger(TDR_INDEX_PARTNER_TYPE,mp_HssSubsData->m_PartnerType_OUT);
   m_tdr.setString(TDR_INDEX_RESRV7,(s8*)mp_HssSubsData->m_LocalRoamInfo_OUT);
   m_tdr.setString(TDR_INDEX_RESRV8,(s8*)mp_HssSubsData->m_TdrResrvData_OUT);
   m_tdr.setString(TDR_INDEX_HLR_RESRV1,(s8*)mp_HssSubsData->m_TdrRestrData_OUT);
   m_tdr.setString(TDR_INDEX_HLR_RESRV2,(s8*)mp_HssSubsData->m_TdrProfData_OUT);
   m_tdr.setString(TDR_INDEX_NOR_MIP6AI_HA_FAMILY2,(s8*)mp_HssSubsData->m_DualImsiInfo_OUT);  //6.4.4.0
   DLOG(0,0,"Dual Imsi Info [%s] Alt/DualImsi flag [%c] Dual Imsi Indicator [%c]",mp_HssSubsData->m_DualImsiInfo_OUT,mp_HssSubsData->m_DualImsiInfo_OUT[0],mp_HssSubsData->m_DualImsiInfo_OUT[2]);

   if((atoi((char*)mp_HssSubsData->m_TdrResrvData_OUT) == 1) && (mp_HssSubsData->m_PartnerType_OUT == 3))
   {
	   LLOG(0,0,"Stats written ... Subscriber latched with Alternate IMSI first time");
	   map<string,int>::iterator l_itr = g_globalMap.find("FirstAlternateIMSILatched");
	   if(l_itr != g_globalMap.end())
	   {
		   HLRStatisticsInitializer::logStatistics(l_itr->second);
	   }
   }


   if((atoi((char*)mp_HssSubsData->m_TdrResrvData_OUT) == 1) && (mp_HssSubsData->m_PartnerType_OUT == 2) && ('2' == mp_HssSubsData->m_DualImsiInfo_OUT[0]) && ('1' == mp_HssSubsData->m_DualImsiInfo_OUT[2]))
   {
	   LLOG(0,0,"Stats written ... Subscriber latched with Dual IMSI first time");
	   map<string,int>::iterator l_itr = g_globalMap.find("FirstDualIMSILatched");
	   if(l_itr != g_globalMap.end())
	   {
		   HLRStatisticsInitializer::logStatistics(l_itr->second);
	   }
   }


   //6.4.4.1

   LLOG(0,0,"DBRES: MNO Provisioning Parameters[%s]",mp_HssSubsData->m_MnoProvisioningTdr_OUT);
   m_tdr.setString(TDR_INDEX_HLR_RESRV10,mp_HssSubsData->m_MnoProvisioningTdr_OUT);//106
   m_tdr.setInteger(TDR_INDEX_NOR_MIP6AI_HA_DEST_REALM,mp_HssSubsData->m_ulr_mpg_indicator_OUT); //136

   char l_tempData2[200+1];
   memset(l_tempData2,'\0',sizeof(l_tempData2));
   snprintf(l_tempData2, sizeof(l_tempData2), "|%s|", mp_HssSubsData->m_MnoProvisioningTdr_OUT);
   char tempBuff2[5][20];
   memset(tempBuff2,'\0',sizeof(tempBuff2));
   tokenize2(l_tempData2,(char*)tempBuff2,20,'|');
   TLOG(0,1,"tokenized data: [%s] [%s] [%s] [%s] [%s]", tempBuff2[0], tempBuff2[1], tempBuff2[2], tempBuff2[3], tempBuff2[4]);

   if( (0 < strlen((char*)tempBuff2[4])) && (1 == atoi(tempBuff2[1])) && (0 == atoi(tempBuff2[3])) )
   {
	   LLOG(0,0,"MnoProvisioning Interested to be sent to MPG");
	   m_tdr.setString(TDR_INDEX_NOR_MIP6AI_HA_ADDR2,"1");//135

	   char l_tempData3[200+1];
	   memset(l_tempData3,'\0',sizeof(l_tempData3));
	   snprintf(l_tempData3, sizeof(l_tempData3), "|%s|", mp_HssSubsData->m_TdrProfData_OUT);
	   char tempBuff3[5][20];
	   memset(tempBuff3,'\0',sizeof(tempBuff3));
	   tokenize2(l_tempData3,(char*)tempBuff3,20,'|');
	   TLOG(0,1,"tokenized data: [%s] [%s] [%s] [%s] [%s]", tempBuff3[0], tempBuff3[1], tempBuff3[2], tempBuff3[3], tempBuff3[4]);
	   m_tdr.setString(TDR_INDEX_ICC_ID,tempBuff3[4]);//103
   }
   else
   {
	   m_tdr.setString(TDR_INDEX_NOR_MIP6AI_HA_ADDR2,"0");//135
   }


   //6.4.4.1


   LLOG(0,0,"DBRES: General TDR Data[%s]", mp_HssSubsData->m_generalTDRdata_OUT);
   char l_tokensGenTdr[13][100 + 1];
   memset(l_tokensGenTdr,'\0',sizeof(l_tokensGenTdr));
   tokenize(mp_HssSubsData->m_generalTDRdata_OUT, (char*)l_tokensGenTdr, 101);
   TLOG(1,1,"Tokenized General TDR Data 1[%s] 2[%s] 3[%s] 4[%s] 5[%s] 6[%s] 7[%s] 8[%s] 9[%s] 10[%s] 11[%s] 12[%s]",(char *)l_tokensGenTdr[1],(char *)l_tokensGenTdr[2],(char *)l_tokensGenTdr[3],(char *)l_tokensGenTdr[4],(char *)l_tokensGenTdr[5],(char *)l_tokensGenTdr[6],(char *)l_tokensGenTdr[7],(char *)l_tokensGenTdr[8],(char *)l_tokensGenTdr[9],(char *)l_tokensGenTdr[10],(char *)l_tokensGenTdr[11],(char *)l_tokensGenTdr[12]);
   m_tdr.setString(TDR_INDEX_CURRENT_ROAMING_ZONE,(char *)l_tokensGenTdr[1]);  //143
   m_tdr.setString(TDR_INDEX_CURRENT_ROAMING_AGE,(char *)l_tokensGenTdr[2]);   //144
   m_tdr.setString(TDR_INDEX_PREVIOUS_ROAMING_ZONE,(char *)l_tokensGenTdr[3]); //145
   m_tdr.setString(TDR_INDEX_PREVIOUS_ROAMING_AGE,(char *)l_tokensGenTdr[4]);  //146
   m_tdr.setString(TDR_INDEX_RESRV_POS147,(char *)l_tokensGenTdr[5]); 
   m_tdr.setString(TDR_INDEX_RESRV_POS148,(char *)l_tokensGenTdr[6]); 
   m_tdr.setString(TDR_INDEX_RESRV_POS149,(char *)l_tokensGenTdr[7]); 
   m_tdr.setString(TDR_INDEX_RESRV_POS150,(char *)l_tokensGenTdr[8]); 
   m_tdr.setString(TDR_INDEX_RESRV_POS151,(char *)l_tokensGenTdr[9]); 
   m_tdr.setString(TDR_INDEX_RESRV_POS152,(char *)l_tokensGenTdr[10]); 
   m_tdr.setString(TDR_INDEX_RESRV_POS153,(char *)l_tokensGenTdr[11]); 
   m_tdr.setString(TDR_INDEX_RESRV_POS154,(char *)l_tokensGenTdr[12]); 

   TLOG(0,0,"DBRES: FreeCount[%u] ThresholdCount[%u]",mp_HssSubsData->m_FreeCount_OUT,mp_HssSubsData->m_ThresholdCount_OUT);

   m_tdr.setInteger(TDR_INDEX_SSM_NBR_USR,mp_HssSubsData->m_First_Roam_To_Home_Flag);
   LLOG(0,0,"DBRES: First_Roam_To_Home_Flag [%d]",mp_HssSubsData->m_First_Roam_To_Home_Flag);
   m_tdr.setString(TDR_INDEX_SSM_DEF_PRIORITY,(char *)mp_HssSubsData->m_CC_Info);
   m_tdr.setString(TDR_INDEX_ALT_PRIMARYIMSI,(char *)mp_HssSubsData->m_AltImsi_OUT);
   m_tdr.setString(TDR_INDEX_ALT_PRIMARYIMSI2,(char *)mp_HssSubsData->m_IPAddress_OUT);
   LLOG(0,0,"DBRES:ALT_PRIM_IMSI [%s] STATIC_IP_ADDRESS[%s] AreaCode Based Alocation Info[%s] TrapCode[%s] TrapDesc[%s]", mp_HssSubsData->m_AltImsi_OUT, mp_HssSubsData->m_IPAddress_OUT, mp_HssSubsData->m_AreaCodeBasedAllocInfo_OUT, mp_HssSubsData->m_TrapCode_OUT, mp_HssSubsData->m_TrapDesc_OUT);
   m_tdr.setString(TDR_INDEX_NEW_RESERVED_SEVEN,(char*)mp_HssSubsData->m_AreaCodeBasedAllocInfo_OUT);

   char l_tempIpv4Ipv6Addr[100 + 1];
   char tempBuff[3][100];
   memset(l_tempIpv4Ipv6Addr,'\0',sizeof(l_tempIpv4Ipv6Addr));
   memset(tempBuff,'\0',sizeof(tempBuff));
   snprintf(l_tempIpv4Ipv6Addr,sizeof(l_tempIpv4Ipv6Addr),"|%s|",(char *)mp_HssSubsData->m_IPAddress_OUT);
   DLOG(0,0,"Static IP Address before tokenising [%s]", l_tempIpv4Ipv6Addr);
   tokenize2(l_tempIpv4Ipv6Addr,(char*)tempBuff,100,'|');
   TLOG(0,0,"tokenised data: [%s] [%s] [%s]", tempBuff[1], tempBuff[2], tempBuff[3]);
   m_IPv4Addr = tempBuff[1];
   m_IPv6Addr = tempBuff[2];
   DLOG(0,0,"After tokenising IPV4 Address[%s] IPV6 Address[%s]",m_IPv4Addr.c_str(),m_IPv6Addr.c_str());

   char l_tempDesc[200+1];
   snprintf(l_tempDesc, sizeof(l_tempDesc), "CC:%s NetID: %d", (char *)mp_HssSubsData->m_RoamCC_OUT, mp_HssSubsData->m_NetworkId_OUT);
   if(2 == mp_HssSubsData->m_LocalImsiSubscription_OUT)
   {
      LLOG(0,0,"DBRES: Unable to Allocate Local Msisdn");
      g_si.sendSnmpTrap(g_LocalMsisdnUnavailableTrap, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL, l_tempDesc);
   }
   else if(mp_HssSubsData->m_FreeCount_OUT < mp_HssSubsData->m_ThresholdCount_OUT)
   {
      LLOG(0,0,"DBRES: Threshold reached for Local Msisdn .. freeCount[%u] threshCount[%u]",mp_HssSubsData->m_FreeCount_OUT,mp_HssSubsData->m_ThresholdCount_OUT);
      g_si.sendSnmpTrap(g_LocalMsisdnThresholdTrap, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL, l_tempDesc);
   }

   m_tdr.setString(TDR_INDEX_MM_PRIMARY_MSISDN,mp_HssSubsData->m_PrimaryMsisdn_OUT);
   m_tdr.setString(TDR_INDEX_MM_PRIMARY_IMSI,mp_HssSubsData->m_PrimaryImsi_OUT);

   m_tdr.setString(TDR_INDEX_MM_LOCAL_IMSI,mp_HssSubsData->m_LocalImsi_OUT);
   m_tdr.setString(TDR_INDEX_MM_LOCAL_MSISDN,mp_HssSubsData->m_LocalMsisdn_OUT);
   m_tdr.setInteger(TDR_INDEX_MM_IMSI_BURNT_TYPE,mp_HssSubsData->m_PreBurntImsi_OUT);
   m_tdr.setString(TDR_INDEX_RESRV6,mp_HssSubsData->m_SimStructure_OUT);

   m_tdr.setInteger(TDR_INDEX_OAM_TRANSACTION_ID,mp_HssSubsData->m_MmeSeqNum_OUT);
   m_tdr.setString(TDR_INDEX_RESRV1,mp_HssSubsData->m_LogPrefix_OUT);

   if(1 == mp_HssSubsData->m_FirstUL_OUT)
   {
      m_tdr.setInteger(TDR_INDEX_MM_FIRST_UL,mp_HssSubsData->m_FirstUL_OUT);
   }
   m_tdr.setInteger(TDR_INDEX_MM_NETWORK_ID,mp_HssSubsData->m_NetworkId_OUT);
   m_tdr.setInteger(TDR_INDEX_MM_PARTNER_NW_ID,mp_HssSubsData->m_PartnerNkId_OUT);

   if(false == m_fIdr)
   {
      if( mp_HssSubsData->m_AllocationStatus_OUT >= 10 )
      {
         m_tdr.setInteger(TDR_INDEX_RESRV5,mp_HssSubsData->m_AllocationStatus_OUT);
         LLOG(0,0,"DBRES: Transient MSISDN allocation status [%d]",mp_HssSubsData->m_AllocationStatus_OUT);

         if( (14 == mp_HssSubsData->m_AllocationStatus_OUT ) || (11 == mp_HssSubsData->m_AllocationStatus_OUT ) )
         {
            LLOG(0,0,"DBRES: Unable to allocate Trasient Msisdn");
            g_si.sendSnmpTrap(g_TransientMsisdnUnavailableTrap, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL);
         }
         else if(mp_HssSubsData->m_TempMsisdnFreeCount_OUT < mp_HssSubsData->m_TempMsisdnThreshCount_OUT)
         {
            LLOG(0,0,"DBRES: Threshold reached for Transient msisdn .. freeCount[%u] threshCount[%u]",mp_HssSubsData->m_TempMsisdnFreeCount_OUT,mp_HssSubsData->m_TempMsisdnThreshCount_OUT);
            g_si.sendSnmpTrap(g_TransientMsisdnThresholdTrap, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL);
         }
      }

#if 0
      char l_temp[50];
      if(1 == g_LteMmConfigReaderObj->m_SendCrossCL)
      {
         memset(l_temp,'\0',sizeof(l_temp));
         if(strlen(mp_HssSubsData->m_rowIdGsm_OUT) > 5)
         {
            TLOG(0,0,"Pushing Gsm RowId[%s] into Queue", mp_HssSubsData->m_rowIdGsm_OUT);
            g_sc.initiateIndependentContext(this, MAP_OP_CODE_dummy_1, (char*)mp_HssSubsData->m_rowIdGsm_OUT, INITIATION_TYPE_TARDILY);
            m_tdr.setString(TDR_INDEX_ULR_ROWID_GSM, mp_HssSubsData->m_rowIdGsm_OUT);
            snprintf(l_temp, sizeof(l_temp), (char*)"ToGsmEnabled");
         }
         if(strlen(mp_HssSubsData->m_rowIdGprs_OUT) > 5)
         {
            TLOG(0,0,"Pushing Gprs RowId[%s] into Queue", mp_HssSubsData->m_rowIdGprs_OUT);
            g_sc.initiateIndependentContext(this, MAP_OP_CODE_dummy_1, (char*)mp_HssSubsData->m_rowIdGprs_OUT, INITIATION_TYPE_TARDILY);
            m_tdr.setString(TDR_INDEX_ULR_ROWID_GPRS, mp_HssSubsData->m_rowIdGprs_OUT);
            if(strlen(l_temp)>0)
            {
               strncat(l_temp,":ToGprsEnabled",13);
            }
            else
            {
               snprintf(l_temp,sizeof(l_temp), (char*)"ToGprsEnabled");
            }
         }
         m_tdr.setString(TDR_INDEX_ULR_CROSS_CL, l_temp);
      }
      else 
      {
         memset(l_temp,'\0',sizeof(l_temp));
         if(strlen(mp_HssSubsData->m_rowIdGsm_OUT) > 5)
         {
            m_tdr.setString(TDR_INDEX_ULR_ROWID_GSM, mp_HssSubsData->m_rowIdGsm_OUT);
            snprintf(l_temp,sizeof(l_temp), (char*)"ToGsmDisabled");
         }
         if(strlen(mp_HssSubsData->m_rowIdGprs_OUT) > 5)
         {
            m_tdr.setString(TDR_INDEX_ULR_ROWID_GPRS, mp_HssSubsData->m_rowIdGprs_OUT);

            if(strlen(l_temp)>0)
            {
               strncat(l_temp,":ToGprsDisabled",14);
            }
            else
            {
               snprintf(l_temp,sizeof(l_temp), (char*)"ToGprsDisabled");
            }
         }
         m_tdr.setString(TDR_INDEX_ULR_CROSS_CL, l_temp);
      }
      if(strlen(mp_HssSubsData->m_rowIdMme_OUT) > 5)
      {
         TLOG(0,0,"Pushing Mme RowId[%s] into Queue", mp_HssSubsData->m_rowIdMme_OUT);
         g_sc.initiateIndependentContext(this, MAP_OP_CODE_dummy_1, (char*)mp_HssSubsData->m_rowIdMme_OUT, INITIATION_TYPE_TARDILY);
         m_tdr.setString(TDR_INDEX_ULR_ROWID_MME, mp_HssSubsData->m_rowIdMme_OUT);
      }
#endif

      bool l_MsisdnAllocStatusFlag = false;
      if((mp_HssSubsData->m_ErrorCode_OUT == 0) || (mp_HssSubsData->m_ErrorCode_OUT == 12) || (mp_HssSubsData->m_ErrorCode_OUT == 13))
      {
         if((mp_HssSubsData->m_AllocationStatus_OUT == 0) || (mp_HssSubsData->m_AllocationStatus_OUT == 1))
         {
            if(mp_HssSubsData->m_AllocationStatus_OUT == 0)
            {
               LLOG(0,0,"DBRES: Dynamic MSISDN Allocation Success");
               m_tdr.setString(TDR_INDEX_MM_MSISDN_ALLOC_STATUS,"A");
               moduleLevelLogStats("PrimMSISDNAllocatedinULR");
               l_MsisdnAllocStatusFlag = true;
            }
            if(mp_HssSubsData->m_AllocationStatus_OUT == 1)
            {
               CLOG(0,0,"DBRES: Dynamic MSISDN Allocation Failed");
               m_tdr.setString(TDR_INDEX_MM_MSISDN_ALLOC_STATUS,"N");
            }
            m_tdr.setString(TDR_INDEX_OAM_FREE_FORMAT_DATA,mp_HssSubsData->m_OldMsisdn_OUT);
            DLOG(0,0,"DBRES: Configured Network Threshold [%d]",mp_HssSubsData->m_DynMsisdnMinFreeThreshold_OUT);
            if(mp_HssSubsData->m_MsisdnFreeCount_OUT < mp_HssSubsData->m_DynMsisdnMinFreeThreshold_OUT)
            {
               CLOG(0,0,"DBRES: Remaining Free MSISDNs count [%u] is less than Configured Network Threshold [%d]",mp_HssSubsData->m_MsisdnFreeCount_OUT,mp_HssSubsData->m_DynMsisdnMinFreeThreshold_OUT);
               g_si.sendSnmpTrap(g_FreeMsisdnRemainingTrap, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL);
            }
         }
      }
      else if(2 == mp_HssSubsData->m_ErrorCode_OUT)
      {
         if(NULL == strstr((char*)(mp_HssSubsData->m_ErrorMsg_OUT),"GET_"))
         {
            CLOG(0,0,"Dynamic Allocation Failed");
            g_si.sendSnmpTrap(g_DynamicAllocFailTrap, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL);
         }
      }

      char tmpBuff[5][100];
      char l_AreaCodeBuf[100+1];
      memset(tmpBuff,'\0',sizeof(tmpBuff));
      memset(l_AreaCodeBuf,'\0',sizeof(l_AreaCodeBuf));
      snprintf(l_AreaCodeBuf,sizeof(l_AreaCodeBuf),"|%s|",mp_HssSubsData->m_AreaCodeBasedAllocInfo_OUT);
      DLOG(0,0,"AreaCodeBuf[%s] before tokenizing",l_AreaCodeBuf);
      tokenize2(l_AreaCodeBuf,(char*)tmpBuff,100,'|');
      TLOG(0,0,"tokenised data: [%s] [%s] [%s] [%s] [%s]", tmpBuff[1], tmpBuff[2], tmpBuff[3], tmpBuff[4], tmpBuff[5]);

      if(strlen(mp_HssSubsData->m_TrapCode_OUT) > 0)
      {
         TLOG(0,0,"Trap Code is [%s]", mp_HssSubsData->m_TrapCode_OUT);
         if(NULL != g_prov)
         {
            int l_trapInt = ((CommonData*)g_prov)->getTrapInt(mp_HssSubsData->m_TrapCode_OUT);
            if(l_trapInt >= 0)
            {
               if(strlen(mp_HssSubsData->m_TrapDesc_OUT)> 0)
               {
                  char l_TrapDesc[200+1];
                  memset(l_TrapDesc,'\0',sizeof(l_TrapDesc));
                  snprintf(l_TrapDesc,sizeof(l_TrapDesc),"AreaShortCode:%s BusinessGroupID:%s",tmpBuff[2],tmpBuff[5]);
                  g_si.sendSnmpTrap(l_trapInt, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL, l_TrapDesc);
               }
               else
               {
                  g_si.sendSnmpTrap(l_trapInt, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL);
               }
            }
            else
            {
               ELOG(0,0,"Unable to get the integer for the trap [%s]", mp_HssSubsData->m_TrapCode_OUT);
            }
         }
         else
         {
            WLOG(0,0,"g_prov is null. not sending trap");
         }
      }

      if((true == l_MsisdnAllocStatusFlag) && (0 == strcmp("2", tmpBuff[1])))
      {
         DLOG(0,0,"checking for logging AreaCode Based stats");
         char l_TmpAreaShortCode[100+1];
         memset(l_TmpAreaShortCode,'\0',sizeof(l_TmpAreaShortCode));
         snprintf(l_TmpAreaShortCode,sizeof(l_TmpAreaShortCode),"TotalMsisdnAllocationsInAreaCode:%s",tmpBuff[2]);
         TLOG(0,0,"AreaCode[%s] Based MSISDN Allocated .. logging statistics",tmpBuff[2]);
         map<string,int>::iterator l_itr = g_globalMap.find(l_TmpAreaShortCode);
         if(l_itr != g_globalMap.end())
         {
            HLRStatisticsInitializer::logStatistics(l_itr->second);
         }
         else
         {
            DLOG(0,0,"%s not found in global map, not calling statistics",l_TmpAreaShortCode);
         }
      }
      else
      {
         TLOG(0,0,"Msisdn Alloc Status[%d] and AreaCode Flag Value[%s] not checking for statistics",l_MsisdnAllocStatusFlag,tmpBuff[1]);
      }

      //SendCancelLocation();
      switch(mp_HssSubsData->m_ErrorCode_OUT)
      {
         case 0:
         case 13:
            {
               sendULA();
            }
            break;

         case 1:
            handleError(DIAM_EXP_RESULT_CODE_ERROR_USER_UNKNOWN, ERROR_DIAGNOSTIC_NOT_REQUIRED);
            break;

         case 15: 
            handleError(DIAM_EXP_RESULT_CODE_ERROR_UNKNOWN_EPS_SUBSCRIPTION, (mp_HssSubsData->m_PdpProfId_OUT > 0)?(ERROR_DIAGNOSTIC_GPRS_DATA_SUBSCRIBED):(ERROR_DIAGNOSTIC_NO_GPRS_DATA_SUBSCRIBED));
            break;

         case 7:
            {
               if(mp_HssSubsData->m_Nam_OUT != 7)
               {
                  if(mp_HssSubsData->m_PdpProfId_OUT > 0)
                  {
                     LLOG(0,0,"NAM is NOT not 4G but PdpProfile present");
                     handleError(DIAM_EXP_RESULT_CODE_ERROR_UNKNOWN_EPS_SUBSCRIPTION, ERROR_DIAGNOSTIC_GPRS_DATA_SUBSCRIBED);
                  }
                  else
                  {
                     LLOG(0,0,"NAM is NOT not 4G and  PdpProfile not present");
                     handleError(DIAM_EXP_RESULT_CODE_ERROR_UNKNOWN_EPS_SUBSCRIPTION, ERROR_DIAGNOSTIC_NO_GPRS_DATA_SUBSCRIBED);
                  }
               }
               else
               {
                  LLOG(0,0,"NAM is not configured");
                  handleError(DIAM_EXP_RESULT_CODE_ERROR_USER_UNKNOWN, ERROR_DIAGNOSTIC_NOT_REQUIRED);
               }
               break;
            }

            /*case 4: //ODB errors
              handleError(DIAM_EXP_RESULT_CODE_ERROR_ROAMING_NOT_ALLOWED, ERROR_DIAGNOSTIC_NOT_REQUIRED);
              break;*/

         case 5: //Node type 2 not supported
            handleError(DIAM_EXP_RESULT_CODE_ERROR_ROAMING_NOT_ALLOWED, ERROR_DIAGNOSTIC_NOT_REQUIRED);
            break;

         case 8: //MME Host is black listed
            //handleError(DIAM_EXP_RESULT_CODE_ERROR_ROAMING_NOT_ALLOWED, ERROR_DIAGNOSTIC_NOT_REQUIRED);
            handleError(g_LteMmConfigReaderObj->m_UlrRejectCode, ERROR_DIAGNOSTIC_NOT_REQUIRED);
            break;

         case 10: //MME host and imsi prefix is black listed
            //handleError(DIAM_EXP_RESULT_CODE_ERROR_ROAMING_NOT_ALLOWED, ERROR_DIAGNOSTIC_NOT_REQUIRED);
            handleError(g_LteMmConfigReaderObj->m_UlrRejectCode, ERROR_DIAGNOSTIC_NOT_REQUIRED);
            break;

         case 11: //Secondary imsi received from HPLMN 
            //handleError(DIAM_EXP_RESULT_CODE_ERROR_ROAMING_NOT_ALLOWED, ERROR_DIAGNOSTIC_NOT_REQUIRED);
            handleError(g_LteMmConfigReaderObj->m_UlrRejectCode, ERROR_DIAGNOSTIC_NOT_REQUIRED);
            break;

         case 20: //update_mme_data failed
            handleError(DIAM_RESULT_CODE_UNABLE_TO_COMPLY, ERROR_DIAGNOSTIC_NOT_REQUIRED);
            break;

            // ODB Errors //
         case 21:
            handleError(DIAM_EXP_RESULT_CODE_ERROR_ROAMING_NOT_ALLOWED, ERROR_DIAGNOSTIC_ODB_ALL_APN);
            break;
         case 22:
            handleError(DIAM_EXP_RESULT_CODE_ERROR_ROAMING_NOT_ALLOWED, ERROR_DIAGNOSTIC_ODB_HPLMN_APN);
            break;
         case 23:
            handleError(DIAM_EXP_RESULT_CODE_ERROR_ROAMING_NOT_ALLOWED, ERROR_DIAGNOSTIC_ODB_VPLMN_APN);
            break;
         case 24:
         case 25:
         case 26:
         case 27:
         case 28:
         case 29:
            handleError(DIAM_EXP_RESULT_CODE_ERROR_ROAMING_NOT_ALLOWED, ERROR_DIAGNOSTIC_NOT_REQUIRED);
            break;
         case 31:
         case 32:
         case 33:
         case 34:
         case 35:
            handleError(DIAM_EXP_RESULT_CODE_ERROR_RAT_NOT_ALLOWED, ERROR_DIAGNOSTIC_NOT_REQUIRED);
            break;
         case 36:
         case 37:
            handleError(DIAM_EXP_RESULT_CODE_ERROR_ROAMING_NOT_ALLOWED, ERROR_DIAGNOSTIC_NOT_REQUIRED);
            break;

         default:
            handleError(DIAM_RESULT_CODE_UNABLE_TO_COMPLY, ERROR_DIAGNOSTIC_NOT_REQUIRED);
            LLOG(0,0,"Unknown Error Code from DB %d", mp_HssSubsData->m_ErrorCode_OUT);
            break;
      }
      DLOG(0,0,"Inside handleDBResponse func outside MEMC_QUERY_TYPE_GET");  
      DLOG(0,0,"memcached timer[%ld], old_mme_host[%s]",mp_HssSubsData->m_seconds,mp_HssSubsData->m_OldMmeHost_OUT);
      if(( (false == mp_HssSubsData->m_memcGETstatus)||(1 == mp_HssSubsData->m_updateMemcAfterDb)) && (mp_HssSubsData->m_MemcQueryType == MEMC_QUERY_TYPE_GET))
      {
         DLOG(0,0,"Inside handleDBResponse func MEMC_QUERY_TYPE_GET");  
         if((1 == g_ConfigData->m_MemcEnableFlag) && (1 == g_LteMmConfigReaderObj->m_ULRMemcachedFlag))
         {
            DLOG(0,0,"Checking whether the Imsi is home imsi or not");
            if((mp_HssSubsData->m_ErrorCode_OUT == 0) &&(mp_HssSubsData->m_RoamingInd_OUT == 0))
            {
               DLOG(0,0,"Imsi present is a home imsi");
               //mp_HssSubsData->m_DbQueryCachedType = DB_QUERY_CACHED_TYPE_CACHED;
               mp_HssSubsData->m_DbQueryCachedType = DB_QUERY_CACHED_TYPE_ONLY_MEMCACHED_NO_DB;

               mp_HssSubsData->m_MemcQueryType = MEMC_QUERY_TYPE_UPDATE;

               if(g_OtherConfigData->m_DbThresholdTps > 0)
                  mp_HssSubsData->m_DbQueryTpsCountable = DB_QUERY_TPS_NON_COUNTABLE;

               g_act.execute(mp_HssSubsData);
            }
         }

      }
   }
   else if( (true == m_fIdr) && (0 == mp_HssSubsData->m_ErrorCode_OUT) )
   {
      map<int, HlrNetworks* > :: iterator l_HlrNetworksDetailsIter;
      l_HlrNetworksDetailsIter = g_spdPtr->m_HlrNetworks.find(mp_HssSubsData->m_NetworkId_OUT);

      if(l_HlrNetworksDetailsIter == g_spdPtr->m_HlrNetworks.end())
      {
         LLOG(0,0,"Network ID not found in networks map[%d]",mp_HssSubsData->m_NetworkId_OUT);
      }
      else
      {
         DLOG(0,0,"Change Template Mme Action .. [%d]",((l_HlrNetworksDetailsIter->second)->m_ChangeTempMmeAction));
         m_tdr.setInteger(TDR_INDEX_SSM_USSD_SERV_CODE,((l_HlrNetworksDetailsIter->second)->m_ChangeTempMmeAction));

         DLOG(0,0,"Full Idr Flag value for Change Template... [%d]",((l_HlrNetworksDetailsIter->second)->m_FullIdrFlag));
         m_tdr.setInteger(TDR_INDEX_SSM_USSD_GW_ADDR,((l_HlrNetworksDetailsIter->second)->m_FullIdrFlag));
      }

      DLOG(0,0,"calling SendIdr function inside handleDBResponse since m_fIdr is set");
      SendIdr();
   }
   //g_act.execute(mp_HssSubsData);
   return true;
}


bool CtxtLteUpdateLocationRequest :: sendULA() 
{
   DiameterMsg l_answer(((DiameterMsg*)m_MessagePtr)->m_sessionId, DIAM_EVENT_ANSWER, DIAM_COMM_CODE_S6A_S6D_ULR_ULA);

   s6a_r10::UpdateLocationAnswer l_ula1; 
   s6a_r10::UpdateLocationAnswer *l_ula = &l_ula1;
   l_answer.m_cmd = l_ula;

   try
   {
      l_ula->setSessionIndex(((DiameterMsg*)m_MessagePtr)->m_sessionIndex);

      SessionId l_sid(((DiameterMsg*)m_MessagePtr)->m_sessionId);
      l_ula->setSessionId(l_sid);
      LLOG(0,0,"ULA: SessionIndex[%d] Session[%s] SessionState[NO_STATE_MAINTAINED]",((DiameterMsg*)m_MessagePtr)->m_sessionIndex,(char*)((DiameterMsg*)m_MessagePtr)->m_sessionId);

      AuthSessionState l_authSs(AuthSessionState::NO_STATE_MAINTAINED);
      l_ula->setAuthSessionState(l_authSs);

      OriginHost l_origHost(mp_HssSubsData->m_HssOriginHost_OUT);
      l_ula->setOriginHost(l_origHost);

      OriginRealm l_origRealm(mp_HssSubsData->m_HssOriginRealm_OUT);
      l_ula->setOriginRealm(l_origRealm);
      LLOG(0,0,"ULA: OrigHost[%s] OrigRealm[%s]",mp_HssSubsData->m_HssOriginHost_OUT,mp_HssSubsData->m_HssOriginRealm_OUT);

      ResultCode l_resultCode(DIAM_RESULT_CODE_SUCCESS);
      l_ula->setResultCode(l_resultCode);

      // ULA flags to be set only if result code is DIAM_RESULT_CODE_SUCCESS
      ULAFlags l_ulaFlag(1); // 1-Separation Indication set ..  2-MME Registered for MT SMS 
      l_ula->setULAFlags(l_ulaFlag);
      m_tdr.setInteger(TDR_INDEX_ANSWER_FLAGS, (int)l_ulaFlag.value());

      VendorSpecificApplicationId l_vendorSpecificApplicationId1;
      //VendorId l_vendorId(VENDOR_ID); using direct value(gcc)
      VendorId l_vendorId(10415); 
      l_vendorSpecificApplicationId1.addVendorId(l_vendorId);
      //AuthApplicationId l_authApplicationId(S6A_INTERFACE_APP_ID); using direct value(gcc)
      AuthApplicationId l_authApplicationId(16777251);
      l_vendorSpecificApplicationId1.setAuthApplicationId(l_authApplicationId);
      l_ula->setVendorSpecificApplicationId(l_vendorSpecificApplicationId1);
      // S6A_INTERFACE_APP_ID 16777251      VENDOR_ID 10415 in s6a_defines.h 
      LLOG(0,0,"ULA: ULAFlags Seperation Indication[1] VendorId[10415] AuthApplicationId[16777251] always");

      SubscriptionData l_subscriptionData;

      if(strlen(mp_HssSubsData->m_Msisdn_OUT) > 1)
      {
         unsigned char l_BcdStnSr[HSS_MSISDN_LEN + 1];
         memset(l_BcdStnSr,'\0',sizeof(l_BcdStnSr));
         int l_bcdLen = StringToBCD(l_BcdStnSr, (u8*)(mp_HssSubsData->m_Msisdn_OUT), strlen(mp_HssSubsData->m_Msisdn_OUT));

         string l_msisdn;
         l_msisdn.assign((char*)l_BcdStnSr, l_bcdLen);
         MSISDN msisdn(l_msisdn);
         l_subscriptionData.setMSISDN(msisdn);
         m_tdr.setString(TDR_INDEX_REQUEST_MSISDN, mp_HssSubsData->m_Msisdn_OUT);
         LLOG_HEX(0,0,"ULA: SubscriptionData: Msisdn", l_BcdStnSr, l_bcdLen); 
      }
      else
      {
         CLOG(0,0,"ULA: MSISDN not present in DB");
      }

      int l_Converted_Nam = 0;
      bool l_Nam_Applicable = true;
      if( (0 == mp_HssSubsData->m_Nam_OUT) || (5 == mp_HssSubsData->m_Nam_OUT) || (7 == mp_HssSubsData->m_Nam_OUT) )
      {
         l_Converted_Nam = 0;
      }
      else if( (2 == mp_HssSubsData->m_Nam_OUT) || (4 == mp_HssSubsData->m_Nam_OUT) || (6 == mp_HssSubsData->m_Nam_OUT) )
      {
         l_Converted_Nam = 2;
      }
      else
      {
         ELOG(0,0,"NAM[%d] not applicable.. not sending in subscription data",mp_HssSubsData->m_Nam_OUT);
         l_Nam_Applicable = false;
      }
      if(true == l_Nam_Applicable)
      {
         NetworkAccessMode l_nam((NetworkAccessMode::Value)l_Converted_Nam);
         l_subscriptionData.setNetworkAccessMode(l_nam);
      }
      m_tdr.setInteger(TDR_INDEX_MM_NAM, l_Converted_Nam);

      LLOG(0,0,"ULA: SubscriberStatus[%d] Msisdn[%s] Nam[%d]",mp_HssSubsData->m_SubscriberStatus_OUT,mp_HssSubsData->m_Msisdn_OUT,mp_HssSubsData->m_Nam_OUT);


      if(mp_HssSubsData->m_Odb_OUT > 0)
      {
         OperatorDeterminedBarring l_odb(mp_HssSubsData->m_Odb_OUT);
         l_subscriptionData.setOperatorDeterminedBarring(l_odb);
         LLOG(0,0,"ULA: ODB set[%d]",mp_HssSubsData->m_Odb_OUT);
      }

      if(mp_HssSubsData->m_HplmnOdb_OUT > 0)
      {
         HPLMNODB l_hplmnOdb(mp_HssSubsData->m_HplmnOdb_OUT);
         l_subscriptionData.setHPLMNODB(l_hplmnOdb);
         LLOG(0,0,"ULA: HPLMN ODB set[%d]",mp_HssSubsData->m_HplmnOdb_OUT);
      }

      if( (0 == mp_HssSubsData->m_Odb_OUT) && (0 == mp_HssSubsData->m_HplmnOdb_OUT))
      {
         SubscriberStatus l_subsStatus(SubscriberStatus::SERVICEGRANTED);
         l_subscriptionData.setSubscriberStatus(l_subsStatus);
      }
      else
      {
         SubscriberStatus l_subsStatus(SubscriberStatus::OPERATORDETERMINEDBARRING);
         l_subscriptionData.setSubscriberStatus(l_subsStatus);
      }

      bool l_accessRestrictionSet = false;
      //addRegionalSubscriptionZoneCode();
      if((0 != g_LteMmConfigReaderObj->m_ULRAccessRestriction) && (1 == mp_HssSubsData->m_ims_service_flag_OUT) && (mp_HssSubsData->m_ImsProfId_OUT > 0))
      {
         LLOG(0,0,"Access Restriction Value from lte mm config [%d]",g_LteMmConfigReaderObj->m_ULRAccessRestriction);
         AccessRestrictionData l_accessRestriction(g_LteMmConfigReaderObj->m_ULRAccessRestriction);
         l_subscriptionData.setAccessRestrictionData(l_accessRestriction);
         m_tdr.setInteger(TDR_INDEX_SMSM_PRIORITY_FLAG, g_LteMmConfigReaderObj->m_ULRAccessRestriction); // 59th index
         l_accessRestrictionSet = true;
      }
      else if( (786 != mp_HssSubsData->m_AccessRestriction_OUT) && (0 != mp_HssSubsData->m_AccessRestriction_OUT) )
      {
         //u8 l_convAccRes = reverseByte((mp_HssSubsData->m_AccessRestriction_OUT) & (0xFF));
         unsigned char l_convAccRes = 0x00;
         unsigned char l_old = mp_HssSubsData->m_AccessRestriction_OUT;
         for(int i=0;i<8;i++)
            l_convAccRes |= ((l_old>>i) & 1)<<(7-i);
         LLOG(0,0,"AccessRestriction[%d] ConvertedValue[%d]",mp_HssSubsData->m_AccessRestriction_OUT,l_convAccRes);
         AccessRestrictionData l_accessRestriction(l_convAccRes);
         l_subscriptionData.setAccessRestrictionData(l_accessRestriction);
         m_tdr.setChar(TDR_INDEX_SMSM_PRIORITY_FLAG, l_convAccRes);
      }

      LLOG(0,0,"ULA: Odb[%u] Hplmn-Odb[%u] AccessRestriction[%d]",mp_HssSubsData->m_Odb_OUT,mp_HssSubsData->m_HplmnOdb_OUT,mp_HssSubsData->m_AccessRestriction_OUT);

      //setLCSInfo();
      //setTeleserviceList(); only for sms_mme/sgsn or only s6d
      //setCallBarringInforList(); only for sms_mme/sgsn or only s6d
      //setGPRSSubscriptionData();
      //addCSGSubscriptionData();
      //setRoamingRestrictedDueToUnsupportedFeature();

      LteConfigProf* l_lteConfigProf = NULL;
      int l_LetProfId = mp_HssSubsData->m_LteConfigProfId_OUT;
      DLOG(0,0,"Lte Profile Id [%d]",l_LetProfId);
      if(0 == mp_HssSubsData->m_PartnerNkId_OUT)
      {
         LLOG(0,0,"Partner Network Id is 0, not checking for mapped Partner LteProfileId");
         mp_HssSubsData->m_LteConfigProfId_OUT = l_LetProfId;
      }
      else
      {
         TLOG(0,0,"Partner Network Id is not 0, checking for mapped partnerLteProfId");
         int l_tempPartLetProfId = getPartnerLteProfId(l_LetProfId,mp_HssSubsData->m_NetworkId_OUT,mp_HssSubsData->m_PartnerNkId_OUT);
         if(0 != l_tempPartLetProfId)
         {
            LLOG(0,0,"Partner LTE Profile found[%d]",l_tempPartLetProfId);
            mp_HssSubsData->m_LteConfigProfId_OUT = l_tempPartLetProfId;
         }
         else
         {
            mp_HssSubsData->m_LteConfigProfId_OUT = l_LetProfId;
            WLOG(0,0,"Partner LTE Profile Not found, using [%d]",l_LetProfId);
         }
      }
      l_lteConfigProf = g_spdPtr->m_hssProfile->getLteConfigProfDetailsPtr(mp_HssSubsData->m_LteConfigProfId_OUT);
      if(NULL != l_lteConfigProf)
      {
         if(false == l_accessRestrictionSet)
         {
            if( (1 == l_lteConfigProf->m_LteConfigProfStruct.m_Override5gNsaFeature) && (0 < l_lteConfigProf->m_LteConfigProfStruct.m_AccessRestrictionValue) )
            {
               LLOG(0,0,"Access Restriction Value from lte Profile [%d]",l_lteConfigProf->m_LteConfigProfStruct.m_AccessRestrictionValue);
               AccessRestrictionData l_accessRestriction(l_lteConfigProf->m_LteConfigProfStruct.m_AccessRestrictionValue);
               l_subscriptionData.setAccessRestrictionData(l_accessRestriction);
               m_tdr.setInteger(TDR_INDEX_SMSM_PRIORITY_FLAG, l_lteConfigProf->m_LteConfigProfStruct.m_AccessRestrictionValue); // 59th index
            }
            else
            {
               LLOG(0,0,"Either Override5gNsaFeature is not set or AccessRestrictionValue is not set in Lte profile");
            }
         }
         //FillSubscriptionData(l_lteConfigProf, l_subscriptionData);
         if( l_lteConfigProf->m_LteConfigProfStruct.m_feature_list_seq_id_1  > 0 )
         {
            HssFeatureList* l_hssFeatureList1 = NULL;
            l_hssFeatureList1 = g_spdPtr->m_hssProfile->getHssFeatureListPtr(l_lteConfigProf->m_LteConfigProfStruct.m_feature_list_seq_id_1);
            if(NULL != l_hssFeatureList1)
            {
               if(l_hssFeatureList1->m_featureListValue > 0)
               {
                  SupportedFeatures l_SupportedFeatures;
                  VendorId l_VendorId(10415);
                  l_SupportedFeatures.setVendorId(l_VendorId);
                  FeatureListID l_FeatureListID(1);
                  l_SupportedFeatures.setFeatureListID(l_FeatureListID);
                  FeatureList l_FeatureList(l_hssFeatureList1->m_featureListValue);
                  l_SupportedFeatures.setFeatureList(l_FeatureList);
                  l_ula->addSupportedFeatures(l_SupportedFeatures);
                  LLOG(0,0,"ULA: FeatureList1[%u]",l_hssFeatureList1->m_featureListValue);
                  m_tdr.setUnsignedInteger(TDR_INDEX_LOCAL_SUPP_FEATURE_1,l_hssFeatureList1->m_featureListValue);
               }
               else
               {
                  TLOG(0,0,"ULA: FeatureList1[%u] not sending",l_hssFeatureList1->m_featureListValue);
               }
            }
         }

         if( (l_lteConfigProf->m_LteConfigProfStruct.m_feature_list_seq_id_2  > 0) && (mp_HssSubsData->m_S6aRelease_OUT >= 12) )
         {
            HssFeatureList* l_hssFeatureList2 = NULL;
            l_hssFeatureList2 = g_spdPtr->m_hssProfile->getHssFeatureListPtr(l_lteConfigProf->m_LteConfigProfStruct.m_feature_list_seq_id_2);
            if(NULL != l_hssFeatureList2)
            {
               if(l_hssFeatureList2->m_featureListValue > 0)
               {
                  SupportedFeatures l_SupportedFeatures;
                  VendorId l_VendorId(10415);
                  l_SupportedFeatures.setVendorId(l_VendorId);
                  FeatureListID l_FeatureListID(2);
                  l_SupportedFeatures.setFeatureListID(l_FeatureListID);

                  u32 l_modified_f2 = 0;
                  l_modified_f2 = l_hssFeatureList2->m_featureListValue;
                  if(l_modified_f2 & F2_NR_AS_SECONDARY_RAT)
                  {
                     m_hlr_5gSupportFlag = true;
                     LLOG(0,0,"HLR supports NR_AS_SECONDARY_RAT flag[%d] and .. MME NR_AS_SECONDARY_RAT flag[%d]",m_hlr_5gSupportFlag,m_5gSupportFlag);
                     if(false == m_5gSupportFlag)
                     {
                        l_modified_f2 = 0;
                        l_modified_f2 = (l_hssFeatureList2->m_featureListValue) & (~F2_NR_AS_SECONDARY_RAT);
                        LLOG(0,0,"Not Sending NR_AS_SECONDARY_RAT as MME not supporting..Modified FeatureList2[%u]",l_modified_f2);
                     }
                  }
                  if(l_modified_f2 > 0)
                  {
                     FeatureList l_FeatureList(l_modified_f2);

                     l_SupportedFeatures.setFeatureList(l_FeatureList);
                     l_ula->addSupportedFeatures(l_SupportedFeatures);
                     LLOG(0,0,"ULA: FeatureList2[%u]",l_modified_f2);
                     m_tdr.setUnsignedInteger(TDR_INDEX_LOCAL_SUPP_FEATURE_2,l_hssFeatureList2->m_featureListValue);
                  }
                  else
                  {
                     LLOG(0,0,"ULA: FeatureList2 NOT sending as Modified value is zero");
                  }
               }
               else
               {
                  TLOG(0,0,"ULA: FeatureList2[%u] not sending",l_hssFeatureList2->m_featureListValue);
               }
            }
         }
         FillSubscriptionData(l_lteConfigProf, l_subscriptionData);
      }
      else
      {
         LLOG(0,0,"LTE Config Profile Details not found");
      }

      l_ula->setSubscriptionData(l_subscriptionData);
   }
   catch (NoSuchAttributeException e)
   {
      ELOG(0,1,"ERROR!! Exception NoSuchAttributeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
      return handleError(DIAM_RESULT_CODE_UNABLE_TO_COMPLY, ERROR_DIAGNOSTIC_NOT_REQUIRED);
   }
   catch (WrongCommandTypeException e)
   {
      ELOG(0,1,"ERROR!! Exception WrongCommandTypeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
      return handleError(DIAM_RESULT_CODE_UNABLE_TO_COMPLY, ERROR_DIAGNOSTIC_NOT_REQUIRED);
   }
   catch (UnknownTypeException e)
   {
      ELOG(0,1,"ERROR!! Exception UnknownTypeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
      return handleError(DIAM_RESULT_CODE_UNABLE_TO_COMPLY, ERROR_DIAGNOSTIC_NOT_REQUIRED);
   }
   catch (CodecException e)
   {
      ELOG(0,1,"ERROR!! Exception CodecException Caught: %s ,Error Cause: %s ",e.name(), e.what());
      return handleError(DIAM_RESULT_CODE_UNABLE_TO_COMPLY, ERROR_DIAGNOSTIC_NOT_REQUIRED);
   }
   catch (...)
   {
      CLOG(0,0,"Exception occurred while calling SendULA");
      return handleError(DIAM_RESULT_CODE_UNABLE_TO_COMPLY, ERROR_DIAGNOSTIC_NOT_REQUIRED);
   }

   g_esc.sendMsg(this, &l_answer);
   return true;
}

bool CtxtLteUpdateLocationRequest :: FillSubscriptionData(LteConfigProf* aLteConfigProf, SubscriptionData aSubscriptionData)
{
   unsigned char l_SrvccStnSr[255 + 1]; 
   memset(l_SrvccStnSr,'\0',sizeof(l_SrvccStnSr));
   map<int,ImsProf> :: iterator l_ImsProfMapIter;
   l_ImsProfMapIter = g_spdPtr->m_imsProfMap.find(mp_HssSubsData->m_ImsProfId_OUT);
   if(l_ImsProfMapIter != g_spdPtr->m_imsProfMap.end())
   {
      TLOG(0,0,"ULA: SubscriptionData: ImsProfId[%d] found in ImsProf Map",mp_HssSubsData->m_ImsProfId_OUT);
      if(' ' != l_ImsProfMapIter->second.m_SrvccStnSr[0])
      {
         if(1 == mp_HssSubsData->m_ims_service_flag_OUT)
         {
            TLOG(0,0,"STN-SR[%s] not NULL for ImsProfileId[%d], filling STN-SR",l_ImsProfMapIter->second.m_SrvccStnSr,mp_HssSubsData->m_ImsProfId_OUT);
            int l_bcdLen = 0;
            if(strlen(mp_HssSubsData->m_StnSr_OUT) > 1)
            {
              l_bcdLen = StringToBCD(l_SrvccStnSr, (u8*)mp_HssSubsData->m_StnSr_OUT, strlen(mp_HssSubsData->m_StnSr_OUT));
              LLOG(0,0,"STN-SR from PUR Update");
            }
            else
            {
              l_bcdLen = StringToBCD(l_SrvccStnSr, (u8*)l_ImsProfMapIter->second.m_SrvccStnSr, strlen(l_ImsProfMapIter->second.m_SrvccStnSr));
              LLOG(0,0,"STN-SR from IMS Profile");
            }

            string l_stnsr;
            l_stnsr.assign((char*)l_SrvccStnSr, l_bcdLen);
            STNSR stnsr(l_stnsr);
            aSubscriptionData.setSTNSR(stnsr);
            LLOG_HEX(0,0,"ULA: SubscriptionData: StnSr", l_SrvccStnSr, l_bcdLen); 
         }
         else
         {
            LLOG(0,0,"IMS service flag is 0, not sending STN-SR for Ims profile");
         }
      }
      else
      {
         LLOG(0,0,"STN-SR[%s] is NULL for ImsProfileId[%d]",l_ImsProfMapIter->second.m_SrvccStnSr,mp_HssSubsData->m_ImsProfId_OUT);
      }

   }
   else
   {
      TLOG(0,0,"ULA: SubscriptionData: ImsProfId[%d] Not found in ImsProf Map",mp_HssSubsData->m_ImsProfId_OUT);
      if(0 != (strcmp(aLteConfigProf->m_LteConfigProfStruct.m_stn_sr,"786STNSR786")))
      {
         unsigned char l_BcdStnSr[HSS_STNSR_LEN + 1];
         memset(l_BcdStnSr,'\0',sizeof(l_BcdStnSr));
         int l_bcdLen1 = 0;
         if(strlen(mp_HssSubsData->m_StnSr_OUT) > 1)
         {
            l_bcdLen1 = StringToBCD(l_BcdStnSr, (u8*)mp_HssSubsData->m_StnSr_OUT, strlen(mp_HssSubsData->m_StnSr_OUT));
            LLOG(0,0,"STN-SR from PUR Update");
         }
         else
         {
            l_bcdLen1 = StringToBCD(l_BcdStnSr, (u8*)aLteConfigProf->m_LteConfigProfStruct.m_stn_sr, strlen(aLteConfigProf->m_LteConfigProfStruct.m_stn_sr));
            LLOG(0,0,"STN-SR from LTE Profile");
         }
         string l_stnsr1;
         l_stnsr1.assign((char*)l_BcdStnSr, l_bcdLen1);
         STNSR stnsr1(l_stnsr1);
         aSubscriptionData.setSTNSR(stnsr1);
         LLOG_HEX(0,0,"ULA: SubscriptionData: StnSr", l_BcdStnSr, l_bcdLen1); 
      }
   }
   if(0 == mp_HssSubsData->m_ApnOiOverrideInd_OUT)
   {
	   DLOG(0,0,"Overriding ApnOi in ULR");
	   if(0 != strcmp(aLteConfigProf->m_LteConfigProfStruct.m_apn_oi_replacement,"786APNOI786"))
	   {
		   APNOIReplacement l_apnOIreplacement(aLteConfigProf->m_LteConfigProfStruct.m_apn_oi_replacement);
		   aSubscriptionData.setAPNOIReplacement(l_apnOIreplacement);
		   LLOG(0,0,"ULA: SubscriptionData: ApnOIreplacement[%s]",aLteConfigProf->m_LteConfigProfStruct.m_apn_oi_replacement);
	   }
   }
   else
   {
	   DLOG(0,0,"MnoProvisionFlag and MnoProvisioningStatus is 1 ... So not Overriding ApnOi");
   }

   if(HSS_3GPPCHARGINGCHAR_LEN == aLteConfigProf->m_LteConfigProfStruct.m_3gpp_charg_char_len)
   {
      string l_3gppChrgChr;
      char l_3gppChrgChrString[5];
      snprintf(l_3gppChrgChrString,sizeof(l_3gppChrgChrString),"%02x%02x",(s8*)aLteConfigProf->m_LteConfigProfStruct.m_3gpp_charg_char[0],(s8*)aLteConfigProf->m_LteConfigProfStruct.m_3gpp_charg_char[1]);
      l_3gppChrgChr.assign(l_3gppChrgChrString,HSS_3GPPCHARGINGCHAR_LEN+2);
      S6a3GPPChargingCharacteristics l_s6a3gppChrgChar(l_3gppChrgChr);
      aSubscriptionData.setS6a3GPPChargingCharacteristics(l_s6a3gppChrgChar);
      LLOG_HEX(0,0,"ULA: SubscriptionData: 3gppChrgChar",aLteConfigProf->m_LteConfigProfStruct.m_3gpp_charg_char,HSS_3GPPCHARGINGCHAR_LEN);
   }

   AMBR l_ambr;
   MaxRequestedBandwidthUL l_subsDataMaxReqBwUL(aLteConfigProf->m_LteConfigProfStruct.m_ambr_ul);
   MaxRequestedBandwidthDL l_subsDataMaxReqBwDL(aLteConfigProf->m_LteConfigProfStruct.m_ambr_dl);
   LLOG(0,0,"ULA: SubscriptionData: MaxReqBwUL[%u] MaxReqBwDL[%u]",aLteConfigProf->m_LteConfigProfStruct.m_ambr_ul,aLteConfigProf->m_LteConfigProfStruct.m_ambr_dl);
   l_ambr.setMaxRequestedBandwidthUL(l_subsDataMaxReqBwUL);
   l_ambr.setMaxRequestedBandwidthDL(l_subsDataMaxReqBwDL);
   //5056
   if((4294967295 == aLteConfigProf->m_LteConfigProfStruct.m_ambr_ul) && (true == m_5gSupportFlag) && (true == m_hlr_5gSupportFlag))
   {
      DLOG(0,0,"Both HLR and MME 5gSupportFlag is true, checking for ExtendedAmbrUpLink");
      LLOG(0,0,"ULA: SubscriptionData: ExtendedAmbrUpLink[%u]",aLteConfigProf->m_LteConfigProfStruct.m_ext_ambr_ul);
      if(aLteConfigProf->m_LteConfigProfStruct.m_ext_ambr_ul > 0)
      {
         ExtendedMaxRequestedBWUL l_extendedUL(aLteConfigProf->m_LteConfigProfStruct.m_ext_ambr_ul);
         l_ambr.setExtendedMaxRequestedBWUL(l_extendedUL);
      }
      else
      {
         LLOG(0,0,"ExtendedAmbrUpLink not configured");
      }
   }
   else
   {
      LLOG(0,0,"ExtendedAmbrUpLink NOT sending as limit not set to max 4294967295, it is [%u]",aLteConfigProf->m_LteConfigProfStruct.m_ambr_ul);
   }

   if((4294967295 == aLteConfigProf->m_LteConfigProfStruct.m_ambr_dl) && (true == m_5gSupportFlag) && (true == m_hlr_5gSupportFlag))
   {
      DLOG(0,0,"Both HLR and MME 5gSupportFlag is true, checking for ExtendedAmbrDownLink");
      LLOG(0,0,"ULA: SubscriptionData: ExtendedAmbrDownLink[%u]",aLteConfigProf->m_LteConfigProfStruct.m_ext_ambr_dl);
      if(aLteConfigProf->m_LteConfigProfStruct.m_ext_ambr_dl > 0)
      {
         ExtendedMaxRequestedBWDL l_extendedDL(aLteConfigProf->m_LteConfigProfStruct.m_ext_ambr_dl);
         l_ambr.setExtendedMaxRequestedBWDL(l_extendedDL);
      }
      else
      {
         LLOG(0,0,"ExtendedAmbrDownLink not configured");
      }
   }
   else
   {
      LLOG(0,0,"ExtendedAmbrDownLink NOT sending as limit not set to 4294967295, it is [%u]",aLteConfigProf->m_LteConfigProfStruct.m_ambr_dl);
   }
   //5056
   aSubscriptionData.setAMBR(l_ambr);

   int l_5gNsa = 0; //Both MME and HLR does not support NRAsSecondaryRAT
   if( (true == m_hlr_5gSupportFlag) && (true == m_5gSupportFlag) )
   {
     l_5gNsa = 1; //Both MME and HLR Supports NRAsSecondaryRAT
   }
   else if(true == m_5gSupportFlag)
   {
     l_5gNsa = 2; //Only MME Supports NRAsSecondaryRAT
   }
   else if(true == m_hlr_5gSupportFlag)
   {
     l_5gNsa = 3; //Only HLR Supports NRAsSecondaryRAT
   }

   m_tdr.setInteger(TDR_INDEX_AUC_NUM_VECTORS_SENT, l_5gNsa); // 50th index

   if( (aLteConfigProf->m_LteConfigProfStruct.m_rat_freq_sel_priority_id >= 1) && (aLteConfigProf->m_LteConfigProfStruct.m_rat_freq_sel_priority_id <= 256) )
   {
      RATFrequencySelectionPriorityID l_ratFreqSelectPriorityID(aLteConfigProf->m_LteConfigProfStruct.m_rat_freq_sel_priority_id);
      aSubscriptionData.setRATFrequencySelectionPriorityID(l_ratFreqSelectPriorityID);
      LLOG(0,0,"ULA: SubscriptionData: RatFreqSelPriId[%u]",aLteConfigProf->m_LteConfigProfStruct.m_rat_freq_sel_priority_id);
   }

   //ICSIndicator 
   if( (0 == aLteConfigProf->m_LteConfigProfStruct.m_icsInd) || (1 == aLteConfigProf->m_LteConfigProfStruct.m_icsInd) )
   {
      ICSIndicator l_icsInd((ICSIndicator::Value)aLteConfigProf->m_LteConfigProfStruct.m_icsInd);
      aSubscriptionData.setICSIndicator(l_icsInd);
      LLOG(0,0,"ULA: SubscriptionData: Ics-Indicator[%d]",aLteConfigProf->m_LteConfigProfStruct.m_icsInd);
   }

   //SubscribedPeriodicRAUTAUTimer
   if( aLteConfigProf->m_LteConfigProfStruct.m_subs_periodic_rau_tau_timer > 0 )
   {
      SubscribedPeriodicRAUTAUTimer l_subsRauTau(aLteConfigProf->m_LteConfigProfStruct.m_subs_periodic_rau_tau_timer);
      aSubscriptionData.setSubscribedPeriodicRAUTAUTimer(l_subsRauTau);
      LLOG(0,0,"ULA: SubscriptionData: Subscribed Periodic RAU TAU timer[%u]",aLteConfigProf->m_LteConfigProfStruct.m_subs_periodic_rau_tau_timer);
   }

   //MPSPriority
   if( (0 == aLteConfigProf->m_LteConfigProfStruct.m_mps_priority) || (1 == aLteConfigProf->m_LteConfigProfStruct.m_mps_priority) )
   {
      MPSPriority l_mpsPriority(aLteConfigProf->m_LteConfigProfStruct.m_mps_priority);
      aSubscriptionData.setMPSPriority(l_mpsPriority);
      LLOG(0,0,"ULA: SubscriptionData: MPS priority[%d]",aLteConfigProf->m_LteConfigProfStruct.m_mps_priority);
   }

   //VPLMNLIPAAllowed
   if( (0 == aLteConfigProf->m_LteConfigProfStruct.m_vplmn_lipa_allowed) || (1 == aLteConfigProf->m_LteConfigProfStruct.m_vplmn_lipa_allowed) )
   {
      VPLMNLIPAAllowed l_vplmnAllowed((VPLMNLIPAAllowed::Value)aLteConfigProf->m_LteConfigProfStruct.m_vplmn_lipa_allowed);
      aSubscriptionData.setVPLMNLIPAAllowed(l_vplmnAllowed);
      LLOG(0,0,"ULA: SubscriptionData: Vplmn Lipa Allowed[%d]",aLteConfigProf->m_LteConfigProfStruct.m_vplmn_lipa_allowed);
   }

   //RelayNodeIndicator
   if( (0 == aLteConfigProf->m_LteConfigProfStruct.m_relay_node_ind) || (1 == aLteConfigProf->m_LteConfigProfStruct.m_relay_node_ind) )
   {
      RelayNodeIndicator l_relayNode((RelayNodeIndicator::Value)aLteConfigProf->m_LteConfigProfStruct.m_relay_node_ind);
      aSubscriptionData.setRelayNodeIndicator(l_relayNode);
      LLOG(0,0,"ULA: SubscriptionData: Relay Node Indicator[%d]",aLteConfigProf->m_LteConfigProfStruct.m_relay_node_ind);
   }

   //MDTUserConsent
   if( (0 == aLteConfigProf->m_LteConfigProfStruct.m_mdt_user_consent) || (1 == aLteConfigProf->m_LteConfigProfStruct.m_mdt_user_consent) )
   {
      MDTUserConsent l_mdtUserConsent((MDTUserConsent::Value)aLteConfigProf->m_LteConfigProfStruct.m_mdt_user_consent);
      aSubscriptionData.setMDTUserConsent(l_mdtUserConsent);
      LLOG(0,0,"ULA: SubscriptionData: MDT User Consent[%d]",aLteConfigProf->m_LteConfigProfStruct.m_mdt_user_consent);
   }

   TLOG(0,0,"LTE Config profile details found");
   APNConfigurationProfile l_apnConfProfile;
   FillLteConfigurationProfile(aLteConfigProf, l_apnConfProfile);
   aSubscriptionData.setAPNConfigurationProfile(l_apnConfProfile);

   return true;
}

bool CtxtLteUpdateLocationRequest :: processMessage(Msg *p_MsgPtr,bool &p_DeleteFlag)
{
   DLOG(0, 0, "Start of CtxtLteUpdateLocationRequest::processMsg function Delete flag is %d",p_DeleteFlag);
   MapSpecificMsg *l_specMsg = NULL;
   if(1 == g_IMEI_EncrFlag)
   {
      TLOG(0,0,"Config reader IMEI encryption flag is set to 1");
      m_tdr.setInteger(TDR_INDEX_SMSM_GPRS_SM_DEL_OUTCOME,1);
   }

   switch (p_MsgPtr->m_MsgType)
   {
      case MSG_TYPE_MAP:
         {
            WLOG(0,0,"MAP message received");
         }
         break;

      case MSG_TYPE_DIAMETER:
         {
            DiameterMsg *l_dm = (DiameterMsg*)p_MsgPtr;
            switch(l_dm->m_det)
            {
               case DIAM_EVENT_REQUEST:
                  {
                     switch(l_dm->m_commandCode)
                     {
                        case DIAM_COMM_CODE_S6A_S6D_ULR_ULA:
                           {
                              //printf("\n #### Diameter Message ULR received ####\n");
                              LLOG(0,0,"Diameter Message ULR received");
                              p_DeleteFlag = false;
                              m_MessagePtr = p_MsgPtr;
                              if(NULL == g_spdPtr)
                              {
                                 CLOG(0,0,"Profile Loading is not completed. Sending Unable to Comply Error.");
                                 handleError(DIAM_RESULT_CODE_UNABLE_TO_COMPLY, ERROR_DIAGNOSTIC_NOT_REQUIRED);
                                 return false;
                              }
                              if (false == l_dm->m_allocatedFlag)
                              {
                                 CLOG(0,0,"ULR received is NULL. Sending Unable to Comply Error.");
                                 handleError(DIAM_RESULT_CODE_UNABLE_TO_COMPLY, ERROR_DIAGNOSTIC_NOT_REQUIRED);
                                 return false;
                              }
                              else
                              {
                                 //printf("\n #### calling check ulr ####\n");
                                 if(false == checkULR())
                                 {
                                    LLOG(0,0,"CheckULR failed");
                                    handleError(DIAM_RESULT_CODE_UNABLE_TO_COMPLY, ERROR_DIAGNOSTIC_NOT_REQUIRED);
                                    return false;
                                 }
                                 handleDbQuery();
                              }
                           }
                           break;
                        default:
                           {
                              CLOG(0,0,"Unknown Message[%d] Received",l_dm->m_commandCode);
                           }
                           break;
                     }
                  }
                  break;
#if 1
               case DIAM_EVENT_ANSWER:
#else
               case DIAM_EVENT_ERROR: //to remove
               case DIAM_EVENT_ANSWER:
#endif
                  {
                     LLOG(0,1,"DIAM_EVENT_ANSWER received");
                     //if(NULL != l_dm->m_cmd)
                     {
#if 1
                        diameter::s6a_r10::InsertSubscriberDataAnswer l_ida(*(diameter::CommandImpl*)l_dm->m_cmd);
#else
                        diameter::s6a_r10::InsertSubscriberDataAnswer l_ida;
                        OriginHost l_temporiginHost = diameter::base::OriginHost("MMEHost");
                        l_ida.setOriginHost(l_temporiginHost);
                        OriginRealm l_temporiginRealm("MMERealm");
                        l_ida.setOriginRealm(l_temporiginRealm);
                        //DestinationHost l_tempdestinationHost("MMEDestO");
                        //l_ida.setDestinationHost(l_tempdestinationHost);
                        //DestinationRealm l_tempdestinationRealm("MMEDestR");
                        //l_ida.setDestinationRealm(l_tempdestinationRealm);
                        l_ida.setSessionId(diameter::base::SessionId("abcd"));
                        l_ida.setSessionIndex(123);
                        AuthSessionState l_tempauthSessionState(AuthSessionState::NO_STATE_MAINTAINED);
                        l_ida.setAuthSessionState(l_tempauthSessionState);
                        ResultCode l_tempresult(2000);
                        l_ida.setResultCode(l_tempresult);
                        string cgi;
                        unsigned char cgi_u [] = {0x52,0xf5,0x60,0x0c,0x5d,0xd5,0x17};
                        cgi.assign(cgi_u);
                        EUTRANCellGlobalIdentity l_cgi(cgi);
                        unsigned int age = 2;
                        AgeOfLocationInformation l_age(age);
                        MMELocationInformation l_mli;
                        l_mli.setEUTRANCellGlobalIdentity(l_cgi);
                        l_mli.setAgeOfLocationInformation(l_age);
                        EPSLocationInformation l_eli;
                        l_eli.setMMELocationInformation(l_mli);
                        l_ida.setEPSLocationInformation(l_eli);
#endif
                        diameter::base::SessionId sess= l_ida.getSessionId();
                        ITS_UINT l_idx = l_ida.getSessionIndex();
                        LLOG(0,0,"IDA Session Id : %d", l_idx);

                        int l_errCode = -1;

                        const SessionId &sid1 = l_ida.getSessionId();
                        const OriginHost &oh1 = l_ida.getOriginHost();
                        const OriginRealm &or1 = l_ida.getOriginRealm();
                        const AuthSessionState &authSessState = l_ida.getAuthSessionState();
                        if(true == l_ida.containsResultCode())
                        {
                           const ResultCode &l_rel = l_ida.getResultCode();
                           l_errCode = l_rel.value();
                           if(l_rel.value() > 0)
                           {
                              m_tdr.setInteger(TDR_INDEX_ERR_CODE, l_rel.value());
                              LLOG(0,0,"IDA Result Code : %u", l_rel.value());
                           }
                        }
                        if( true == l_ida.containsExperimentalResult())
                        {
                           const ExperimentalResult &l_experimentalrel = l_ida.getExperimentalResult();
                           const ExperimentalResultCode &l_experimentalrelcode = l_experimentalrel.getExperimentalResultCode();
                           l_errCode = l_experimentalrelcode.value();
                           if(l_experimentalrelcode.value() > 0)
                           {
                              m_tdr.setInteger(TDR_INDEX_ERR_CODE, l_experimentalrelcode.value());
                              LLOG(0,0,"IDA Result Code : %u", l_experimentalrelcode.value());
                           }
                        }
                        if((l_errCode == DIAM_RESULT_CODE_SUCCESS) ||
                              ( l_errCode == DIAM_RESULT_CODE_LIMITED_SUCCESS) ||
                              (( l_errCode >= DIAM_RESULT_CODE_SUCCESS_MIN_RANGE) || ( l_errCode <= DIAM_RESULT_CODE_SUCCESS_MAX_RANGE)))
                        {
                           LLOG(0,0,"IDA Recv Success with Result Code : %u", l_errCode);
                           if(true == m_odbDataSend)
                           {
                              if( true == requireSendCancelLoc(&l_ida) )
                              {
                                 bool l_calLoc = SendCancelLocation();
                                 LLOG(0,0,"IDA Recv MME does not ODB feature list sending Cancel Location [%d]", l_calLoc);
                              }
                           }
                        }
                        else
                        {
                           LLOG(0,0,"IDA Recv Failure Response with Result Code : %u", l_errCode);
                           bool l_calLoc = SendCancelLocation();
                        }
                        if(true == l_ida.containsIDAFlags())
                        {
                           const IDAFlags &l_idaflags = l_ida.getIDAFlags();
                           l_errCode = l_idaflags.value();
                           LLOG(0,0,"IDA Flag  : %d", l_idaflags.value());
                        }

                     }
                  }
                  break;
               case DIAM_EVENT_TIME_OUT:
                  {
                     if(true == m_fIdr)
                     {
                        bool l_calLoc =SendCancelLocation();
                        LLOG(0,0,"DIAM_EVENT_TIME_OUT received Cancel Location [%d]",l_calLoc );
                     }
                     m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EVENT_TIME_OUT);
                     LLOG(0,1,"DIAM_EVENT_TIME_OUT received");
                  }
                  break;
#if 1
               case DIAM_EVENT_ERROR:
                  {
                     if(true == m_fIdr)
                     {
                        bool l_calLoc =SendCancelLocation();
                        LLOG(0,0,"DIAM_EVENT_ERROR received Cancel Location [%d]",l_calLoc);
                     }
                     m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EVENT_ERROR);
                     LLOG(0,1,"DIAM_EVENT_ERROR received");
                  }
                  break;
#endif
               case DIAM_EVENT_AUTH_LIFE_TIME_OUT:
                  {
                     m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EVENT_AUTH_LIFE_TIME_OUT);
                     LLOG(0,1,"DIAM_EVENT_AUTH_LIFE_TIME_OUT received");
                  }
                  break;
               case DIAM_EVENT_AUTH_GRACE_TIME_OUT:
                  {
                     m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EVENT_AUTH_GRACE_TIME_OUT);
                     LLOG(0,1,"DIAM_EVENT_AUTH_GRACE_TIME_OUT received");
                  }
                  break;
               case DIAM_EVENT_CORRUPTED_MSG:
                  {
                     if(true == m_fIdr)
                     {
                        bool l_calLoc =SendCancelLocation();
                        LLOG(0,0,"DIAM_EVENT_CORRUPTED_MSG received Cancel Location [%d]",l_calLoc );
                     }
                     m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EVENT_CORRUPTED_MSG);
                     LLOG(0,1,"DIAM_EVENT_CORRUPTED_MSG received");
                  }
                  break;
               case DIAM_EVENT_ACCT_INTERIM_TIME_OUT:
                  {
                     m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EVENT_ACCT_INTERIM_TIME_OUT);
                     LLOG(0,1,"DIAM_EVENT_ACCT_INTERIM_TIME_OUT received");
                  }
                  break;
               default:
                  LLOG(0,1,"UNKNOWN DIAMETER EVENT received");
                  return false;
            }
         }
         break;

      case MSG_TYPE_DB:
         {
            DLOG(0, 0, "DB message received");
            if(1 == ((DbQueryMsg*)p_MsgPtr)->m_DbQueryType)
            { 
               //  MemCachedQueryMsg* l_MemcQueryMsgPtr = ((MemCachedQueryMsg*)p_MsgPtr);
               switch (((MemCachedQueryMsg*)p_MsgPtr)->m_MemcQueryType)
               {
                  case MEMC_QUERY_TYPE_GET:
                     {
                        TLOG(0,0,"DBRES: Type:1");
                        LteSubsDbData *l_hssSubsData = (LteSubsDbData*)p_MsgPtr;
                        mp_HssSubsData = l_hssSubsData;
                        p_DeleteFlag = false;

                        if(DB_QUERY_CACHED_TYPE_CACHED == ((DbQueryMsg*)p_MsgPtr)->m_DbQueryCachedType)
                        {
                           if(MEMC_QUERY_RES_SUCCESS == ((DbQueryMsg*)p_MsgPtr)->m_MemcQueryRes)
                           {
                              m_tdr.setString(TDR_INDEX_MEMC_GET,"MCG|S");
                              mp_HssSubsData->m_memcGETstatus = true;
                              LLOG(0,0,"MEMCG: Memcached GET success");
                              DLOG(0,0,"MEMCG: Memcached GET success and going to check whether cross CL towards SGSN is enabled or not");

                              char l_tokens_Memcached_Parameters[10][100 + 1];
                              memset(l_tokens_Memcached_Parameters,'\0',sizeof(l_tokens_Memcached_Parameters));
                              tokenize(mp_HssSubsData->m_Memcached_Parameters_OUT, (char*)l_tokens_Memcached_Parameters, 101);
                              DLOG(0,0,"m_Memcached_Parameters_OUT [%s]",mp_HssSubsData->m_Memcached_Parameters_OUT);
                              DLOG(0,0,"Tokens 1[%s] 2[%s] 3[%s] 4[%s]",(char*)l_tokens_Memcached_Parameters[1],(char*)l_tokens_Memcached_Parameters[2],(char*)l_tokens_Memcached_Parameters[3],(char*)l_tokens_Memcached_Parameters[4]);
                              int l_CrossCl = (atoi(l_tokens_Memcached_Parameters[1]));

                              if( 1 == g_EmergencyFlag )
                              {
                                 l_CrossCl = mp_HssSubsData->m_Congestion_Cross_CL;

                              }

                              if(l_CrossCl == 1)
                              {  
                                 DLOG(0,0,"MEMCG: Cross CL towards SGSN is enabled");
                                 LLOG(0,0,"MEMCG: Cross CL towards SGSN is enabled calling executequery of CheckForCancelLocation");
                                 CheckForCancelLocations *l_temp = new CheckForCancelLocations();
                                 snprintf(l_temp->m_AccountId_OUT,100+1,"%s",mp_HssSubsData->m_AccountId_OUT);
                                 l_temp->m_NetworkId_OUT = mp_HssSubsData->m_NetworkId_OUT;
                                 snprintf(l_temp->m_UlrImsi_IN,15+1,"%s",mp_HssSubsData->m_UlrImsi_IN);
                                 DLOG(0,0,"MEMCG :CheckForCancelLocations m_AccountId_OUT [%s] m_NetworkId_OUT [%d] m_UlrImsi_IN [%s]",l_temp->m_AccountId_OUT,l_temp->m_NetworkId_OUT,l_temp->m_UlrImsi_IN);
                                 l_temp->m_DbQueryType = 2;
                                 l_temp->m_cb = this; 
                                 g_act.execute(l_temp);
                              }
                              LLOG(0,0,"MEMCG: EmergencyFlag[%d] CrossCL To SGSN [%d]",g_EmergencyFlag,l_CrossCl);

                           }
                           else if(MEMC_QUERY_RES_FAILURE == ((DbQueryMsg*)p_MsgPtr)->m_MemcQueryRes)
                           {
                              char l_errBuff[100];
                              snprintf(l_errBuff,sizeof(l_errBuff),"MCG|F|%d|%s",((DbQueryMsg*)p_MsgPtr)->m_MemcErrorCode,(char*)(((DbQueryMsg*)p_MsgPtr)->m_MemcErrorMessage).c_str());
                              m_tdr.setString(TDR_INDEX_MEMC_GET,l_errBuff);
                           }
                        }

                        DLOG(0,0,"*** Inside MSG_TYPE_DB MEMC_QUERY_TYPE_GET ... handleDBResponse called ***");
                        handleDBResponse();
                     }
                     break;
                  case MEMC_QUERY_TYPE_UPDATE:
                     {
                        DLOG(0,0,"*** Inside MSG_TYPE_DB MEMC_QUERY_TYPE_UPDATE ... no handleDBResponse call ***");
                        p_DeleteFlag = false;

                        if((DB_QUERY_CACHED_TYPE_CACHED == ((DbQueryMsg*)p_MsgPtr)->m_DbQueryCachedType) || (DB_QUERY_CACHED_TYPE_ONLY_MEMCACHED_NO_DB == ((DbQueryMsg*)p_MsgPtr)->m_DbQueryCachedType))
                        {
                           if(MEMC_QUERY_RES_SUCCESS == ((DbQueryMsg*)p_MsgPtr)->m_MemcQueryRes)
                           {
                              LLOG(0,0,"MEMCU: Memcached UPDATE success");
                              m_tdr.setString(TDR_INDEX_MEMC_SET,"MCU|S");
                           }
                           else if(MEMC_QUERY_RES_FAILURE == ((DbQueryMsg*)p_MsgPtr)->m_MemcQueryRes)
                           {
                              char l_errBuff[100];
                              snprintf(l_errBuff,sizeof(l_errBuff),"MCU|F|%d|%s",((DbQueryMsg*)p_MsgPtr)->m_MemcErrorCode,(char*)(((DbQueryMsg*)p_MsgPtr)->m_MemcErrorMessage).c_str());
                              m_tdr.setString(TDR_INDEX_MEMC_SET,l_errBuff);
                           }
                        }
                     }
                     break;
                  default:
                     {
                        DLOG(0,0,"No MEMC_QUERY_TYPE_GET or MEMC_QUERY_TYPE_UPDATE");
                        LLOG(0,0,"DB is used");
                        TLOG(0,0,"DBRES: Type:1");
                        LteSubsDbData *l_hssSubsData = (LteSubsDbData*)p_MsgPtr;
                        mp_HssSubsData = l_hssSubsData;
                        p_DeleteFlag = false;

                        handleDBResponse();

                     }
                     break;
               }
            }
            else if(2 == ((DbQueryMsg*)p_MsgPtr)->m_DbQueryType)
            {
               TLOG(0,0,"DBRES: Type:2");
               CheckForCancelLocations *l_checkForCL = (CheckForCancelLocations*)p_MsgPtr;
               LLOG(0,0,"MEMC: Type:2 m_ossTriggerDataCount [%d]",(l_checkForCL->m_ossTriggerDataCount));
               for (int l_i=0; l_i<(l_checkForCL->m_ossTriggerDataCount); l_i++)
               {
                  //LLOG(0,0, "Cancel Location CROSS CL sending flag [%d]",mp_HssSubsData->m_crossClType_OUT);
                  DLOG(0,0,"Type:2 m_opCode [%d]",(l_checkForCL->m_ossTriggerDataArray[l_i].m_opCode));
                  if(DIAM_COMM_CODE_S6A_S6D_CLR_CLA == (l_checkForCL->m_ossTriggerDataArray[l_i].m_opCode))
                  {
                     LLOG(0,0,"Initiating DIAM CL: RowId[%s] TransId[%s]",(l_checkForCL->m_ossTriggerDataArray[l_i].m_rowId),(l_checkForCL->m_ossTriggerDataArray[l_i].m_transId));
                     g_esc.initiateIndependentContext(this, DIAM_COMM_CODE_S6A_S6D_CLR_CLA, (l_checkForCL->m_ossTriggerDataArray[l_i].m_transXml), INITIATION_TYPE_IMMEDIATE);
                  }
                  else if(MAP_OP_CODE_cancelLocation == (l_checkForCL->m_ossTriggerDataArray[l_i].m_opCode))
                  {
                     LLOG(0,0,"Initiating MAP CL: RowId[%s] TransId[%s]",(l_checkForCL->m_ossTriggerDataArray[l_i].m_rowId),(l_checkForCL->m_ossTriggerDataArray[l_i].m_transId));
                     g_sc.initiateIndependentContext(this, MAP_OP_CODE_cancelLocation, (l_checkForCL->m_ossTriggerDataArray[l_i].m_transXml), INITIATION_TYPE_IMMEDIATE);
                  }
               }
            }
            else
            {
               ELOG(0,0,"Unknown DB message");
            }
         }
         break;

      default:
         ELOG(0, 0, "Unknown message received");
         break;

   }
   return true;
}

bool CtxtLteUpdateLocationRequest :: FillLteConfigurationProfile(LteConfigProf* aLteConfigProf,APNConfigurationProfile aApnConfProf)
{
   if(aLteConfigProf->m_apnProfDetails.m_DefaultCtxdID > 0)
   {
      ContextIdentifier l_defaultCtxtId(aLteConfigProf->m_apnProfDetails.m_DefaultCtxdID);
      aApnConfProf.setContextIdentifier(l_defaultCtxtId);
      LLOG(0,0,"ULA: SubscriptionData: APN: Default CtxtIdentifier[%u]",aLteConfigProf->m_apnProfDetails.m_DefaultCtxdID);
   }
   else
   {
      CLOG(0,0,"ULA: SubscriptionData: APN: Exception: Default CtxtIdentifier Mandatory Param missing or wrong[%u]",aLteConfigProf->m_apnProfDetails.m_DefaultCtxdID);
      return false;
   }

   AllAPNConfigurationsIncludedIndicator l_allApnConfInclInd(AllAPNConfigurationsIncludedIndicator :: All_APN_CONFIGURATIONS_INCLUDED);
   aApnConfProf.setAllAPNConfigurationsIncludedIndicator(l_allApnConfInclInd);
   LLOG(0,0,"ULA: SubscriptionData: APN: All_APN_CONFIGURATIONS_INCLUDED");

   map<u32, CtxtIDdetails>::iterator l_ctxtIdIter;
   LLOG(0,0,"ULA: SubscriptionData: APN: CtxtDetails Map Size[%d]",aLteConfigProf->m_apnProfDetails.m_CtxtIdMap.size());
   int l_count = 1;
   string l_apnTdrData;
   l_apnTdrData += "APN-";

   char l_voLteRoamingCapData[30+1];
   char l_TokensVoLteRoamingCap [5][10];
   memset(l_TokensVoLteRoamingCap,'\0',sizeof(l_TokensVoLteRoamingCap));
   memset(l_voLteRoamingCapData,'\0',sizeof(l_voLteRoamingCapData));
   sprintf(l_voLteRoamingCapData,"|%s|",mp_HssSubsData->m_voLteRoamingCap_OUT);
   TLOG(0,0,"Before Tokenizing ISR VoLTE Roaming Capabiltiy is [%s]",l_voLteRoamingCapData);
   tokenize2(l_voLteRoamingCapData,(char*)l_TokensVoLteRoamingCap,10,'|');
   DLOG(0,0,"Tokenized ISR VoLTE Roaming Capabiltiy 1[%s] 2[%s] 3[%s]", (char *)l_TokensVoLteRoamingCap[1], (char *)l_TokensVoLteRoamingCap[2],(char *)l_TokensVoLteRoamingCap[3]);

   for(l_ctxtIdIter = aLteConfigProf->m_apnProfDetails.m_CtxtIdMap.begin(); l_ctxtIdIter != aLteConfigProf->m_apnProfDetails.m_CtxtIdMap.end(); l_ctxtIdIter++)
   {
      if(mp_HssSubsData->m_dsrFlag_OUT & 0x08)
      {
         char l_dsrCtxtOut[110];
         memset(l_dsrCtxtOut,'\0',sizeof(l_dsrCtxtOut));
         sprintf(l_dsrCtxtOut,"|%s|",mp_HssSubsData->m_dsrContexts_OUT);
         char l_ctxt[11];
         memset(l_ctxt,'\0',sizeof(l_ctxt));
         sprintf(l_ctxt,"|%d|",l_ctxtIdIter->first);
         if( (NULL != strstr((char*)l_dsrCtxtOut,(char*)l_ctxt)) && (l_ctxtIdIter->first != aLteConfigProf->m_apnProfDetails.m_DefaultCtxdID) )
         {
            LLOG(0,0,"Found Dsr Context[%d] skipping",l_ctxtIdIter->first);
            continue;
         }
      }

      APNConfiguration l_apnConfiguration;

      if(l_ctxtIdIter->first > 0)
      {
         ContextIdentifier l_ctxtIdentifier(l_ctxtIdIter->first);
         l_apnConfiguration.setContextIdentifier(l_ctxtIdentifier);
         LLOG(0,0,"ULA: SubscriptionData: APN-[%u]: CtxtIdentifier[%d]",l_count,l_ctxtIdIter->first);
      }
      else
      {
         CLOG(0,0,"ULA: SubscriptionData: APN: Exception: CtxtIdentifier Mandatory Param missing or wrong[%d]",l_ctxtIdIter->first);
         return false;
      }

      if(1 == l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_applicability_flag)
      {
         if(0 == mp_HssSubsData->m_PartnerNkId_OUT)
         {
            TLOG(0,0,"Subscriber in Home and Applicability flag of CtxdId[%d] is 1 so ignoring", l_ctxtIdIter->first);
            continue;
         }
         else
         {
            if(l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_applicability_roam_parnter_id != mp_HssSubsData->m_PartnerNkId_OUT)
            {
               LLOG(0,0,"Roam: CtxtId[%d] ApplicableRoamPartner[%d] not matching ActualRoamParnter[%d] so ignoring",l_ctxtIdIter->first, l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_applicability_roam_parnter_id, mp_HssSubsData->m_PartnerNkId_OUT);
               continue;
            }
         }
      }

      // 0-IPv4 1-IPv6 2-IPv4v6 3-IPv4orv6
      if((l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_pdnType >= 0) && (l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_pdnType <= 3))  
      {
         PDNType l_pdnType((PDNType::Value)l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_pdnType);
         l_apnConfiguration.setPDNType(l_pdnType);
         LLOG(0,0,"ULA: SubscriptionData: APN-[%d]: PDNType[%d]",l_count,l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_pdnType);
      }
      else
      {
         CLOG(0,0,"ULA: SubscriptionData: APN: Exception: PDNType Mandatory Param missing or wrong[%d]",l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_pdnType);
         return false;
      }
      LLOG(0,0,"IMS mp_HssSubsData->m_ims_service_flag_OUT [%d]",mp_HssSubsData->m_ims_service_flag_OUT);
      LLOG(0,0,"IMS serviceSelection [%s]",l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_serviceSelection);

      char l_ImsApnMccMncData[20+1];
      char l_TokensImsApnMccMnc [5][10];
      memset(l_TokensImsApnMccMnc,'\0',sizeof(l_TokensImsApnMccMnc));
      memset(l_ImsApnMccMncData,'\0',sizeof(l_ImsApnMccMncData));
      sprintf(l_ImsApnMccMncData,"|%s|",mp_HssSubsData->m_MccMncWhitelist_OUT);
      LLOG(0,0,"Before Tokenizing ImsApnMccMncData is [%s]",l_ImsApnMccMncData);
      //tokenize(l_ImsApnMccMncData, (char*)l_TokensImsApnMccMnc, 11);
      tokenize2(l_ImsApnMccMncData,(char*)l_TokensImsApnMccMnc,10,'|');
      DLOG(0,0,"Tokenized Ims Apn MccMnc indicator 1[%s] 2[%s]", (char *)l_TokensImsApnMccMnc[1], (char *)l_TokensImsApnMccMnc[2]);

      int l_AllowImsApnForRoaming = 0;
      char l_AllowImsApnForRoamingTdr [25];
      memset(l_AllowImsApnForRoamingTdr,'\0',sizeof(l_AllowImsApnForRoamingTdr));
      if((0 == strcmp("1",l_TokensImsApnMccMnc[1])) && (0 != mp_HssSubsData->m_RoamingInd_OUT))
      { 
         DLOG(0,0,"Ims Apn Roaming MccMnc Whitelist Flag is enabled");
         if(0 == strcmp("1",l_TokensImsApnMccMnc[2]))
         {
            LLOG(0,0,"MccMncc received belongs to whitelisted list");
            l_AllowImsApnForRoaming = 1;
            m_tdr.setString(TDR_INDEX_GGSN_IP_ADDRESS,"ImsRoamWhitelist");
         }
         else
         {
            m_tdr.setString(TDR_INDEX_GGSN_IP_ADDRESS,"ImsRoamBlacklist");
         }
      }
      DLOG(0,0,"l_AllowImsApnForRoaming [%d]",l_AllowImsApnForRoaming);
      
      int l_SecondsToBeWaited = 0;
      bool l_ImsApnPresent = false;
      string l_ImsApnNotDownloadedTdrReason = "ImsApnNotSent|";

      //if(strlen(l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_serviceSelection) > 0)
      if(0 != strcmp("0",l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_serviceSelection))
      {
         if(0 == strcasecmp("ims",l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_serviceSelection))
         {
            if((0 == atoi(l_TokensVoLteRoamingCap[1])) && (1 == atoi(l_TokensVoLteRoamingCap[2])))
            {
               LLOG(0,0,"IMS apn not downloading.. Restricted for this partner [%d] Network Partner [%d]",mp_HssSubsData->m_PartnerNkId_OUT,atoi(l_TokensVoLteRoamingCap[3]))
               l_ImsApnNotDownloadedTdrReason += "ISR-VRC|";
               m_tdr.setString(TDR_INDEX_GGSN_ADDRESS,(char*)l_ImsApnNotDownloadedTdrReason.c_str());
               map<string,int>::iterator l_itr = g_globalMap.find("ImsApnNotDownloaded-NotApplicableForRoamPartner");
               if(l_itr != g_globalMap.end())
               {
                  HLRStatisticsInitializer::logStatistics(l_itr->second);
               }
               continue;
            }
            if( !((1 == mp_HssSubsData->m_ims_service_flag_OUT) && (mp_HssSubsData->m_ImsProfId_OUT > 0) && (0 == mp_HssSubsData->m_roamImsiBlacKInd_OUT)) )
            {
               LLOG(0,0,"IMS service disabled for the subscriber, not sending IMS APN Context.. ignoring");
               if(mp_HssSubsData->m_roamImsiBlacKInd_OUT == 1)
               {
	       LLOG(0,0,"Roaming IMSI is Blacklisted");
               m_tdr.setInteger(TDR_INDEX_SMSM_GPRS_FLAG,1);
               }
               else
               {
	       LLOG(0,0,"Not sending IMS APN because IMS Service is disabled or IMS Profile Id not present");
               m_tdr.setInteger(TDR_INDEX_SMSM_GPRS_FLAG,0);	 
               }
               if(!(1 == mp_HssSubsData->m_ims_service_flag_OUT))
               {
                  LLOG(0,0,"Stats written ... Ims Apn not downloaded because Ims Flag not enabled");
                  map<string,int>::iterator l_itr = g_globalMap.find("ImsApnNotDownloaded-ImsFlagDisabled");
                  if(l_itr != g_globalMap.end())
                  {
                     HLRStatisticsInitializer::logStatistics(l_itr->second);
                  }
                  l_ImsApnNotDownloadedTdrReason += "F|";
               }
               m_tdr.setString(TDR_INDEX_GGSN_ADDRESS,(char*)l_ImsApnNotDownloadedTdrReason.c_str());
               continue;
            }
            if( (2 == mp_HssSubsData->m_RoamingInd_OUT) && (0 == strcmp("1",l_TokensImsApnMccMnc[1])) )
            {
               DLOG(0,0,"Roaming Subscriber and RoamMCCMNC APN enabled");
               if(1 != l_AllowImsApnForRoaming)
               {
                  LLOG(0,0,"MccMnc is not Whitelisted for the roaming subscriber, not sending IMS APN Context.. ignoring");
                  LLOG(0,0,"Stats written ... Ims Apn not downloaded because Roaming MccMnc not whitelisted");
                  map<string,int>::iterator l_itr = g_globalMap.find("ImsApnNotDownloaded-MccMncRoamNotWhitelisted");
                  if(l_itr != g_globalMap.end())
                  {
                     HLRStatisticsInitializer::logStatistics(l_itr->second);
                  }
                  l_ImsApnNotDownloadedTdrReason += "R-MM|";
                  continue;
               }
            }
            l_ImsApnPresent = true;

            char l_currentOssData[200 + 1];
            char l_tokensOssData[10][200 + 1];
            memset(l_tokensOssData,'\0',sizeof(l_tokensOssData));
            memset(l_currentOssData,'\0',sizeof(l_currentOssData));
            sprintf(l_currentOssData,"|%s|",mp_HssSubsData->m_TacInfo_OUT);
            tokenize(l_currentOssData, (char*)l_tokensOssData, 201);
            TLOG(0,0,"TAC Profile Validation Flag[%s] TACAllowedOrNot [%d]", l_tokensOssData[1],atoi(l_tokensOssData[2]));
            TLOG(0,0,"Current Data [%s]",l_currentOssData);

            if(0 != strcmp("TN",l_tokensOssData[1]))
            {
               DLOG(0,0,"TAC Validation Flag is configured either as Whitelist or Blacklist");
               if(0 == atoi(l_tokensOssData[2]))
               {
                  LLOG(0,0,"TAC is Blacklisted for the subscriber, not sending IMS APN Context.. ignoring");
                  continue;
               }
            }

            map<int, HlrNetworks* > :: iterator l_HlrNetworksDetailsIter;
            l_HlrNetworksDetailsIter = g_spdPtr->m_HlrNetworks.find(mp_HssSubsData->m_NetworkId_OUT);

            if(l_HlrNetworksDetailsIter == g_spdPtr->m_HlrNetworks.end())
            {
               LLOG(0,0,"Network ID not found in networks map[%d]",mp_HssSubsData->m_NetworkId_OUT);
            }
            else
            {
               TrafficParams l_traf_in,l_traf_out;
               l_traf_in.m_maxTPS = ((l_HlrNetworksDetailsIter->second)->m_ImsApnTpsUla);
               int l_ImsApnDph = ((l_HlrNetworksDetailsIter->second)->m_ImsApnTpsUla);
               DLOG(0,0,"IMS APN configured DPH in networks is [%d]", l_ImsApnDph);
               string l_service;
               l_service = "IMSAPN";

               if( l_ImsApnDph <= 3600 )
               {
                  if(0 != l_ImsApnDph)
                  {
                     if(false == g_daf->getTrafficParameters(l_service, l_traf_in, l_traf_out))
                     {
                        DLOG(0,0,"getTrafficParameters returns false, making g_tp_out as NG MAX TPS ");
                        l_traf_out.m_maxTPS = ((l_HlrNetworksDetailsIter->second)->m_ImsApnTpsUla);
                     }
                     else
                     {
                        DLOG(0,0,"getTrafficParameters returns true for SS7, DAF TPS is %d",l_traf_out.m_maxTPS);
                     }
                     l_SecondsToBeWaited = 3600/l_traf_out.m_maxTPS;
                  }

                  g_CurrTimeExecuted=time(NULL);
                  DLOG(0,0,"Seconds To Be Waited to send the trigger for IMS APN[%d] CurrTime[%d] LastSentTime[%d]",l_SecondsToBeWaited, g_CurrTimeExecuted,g_LastTimerExecuted);
                  if(0 != l_SecondsToBeWaited)
                  {
                     if(g_CurrTimeExecuted >= g_LastTimerExecuted + l_SecondsToBeWaited)
                     {
                        g_LastTimerExecuted = g_CurrTimeExecuted;
                     }
                     else
                     {
                        DLOG(0,0,"Not sending IMS APN context because of IMS APN TPS control time not exceeded");
                        LLOG(0,0,"Stats written ... Ims Apn not downloaded because IMS APN TPS control time not exceeded");
                        map<string,int>::iterator l_itr = g_globalMap.find("ImsApnNotDownloaded-ImsTreshlodReached");
                        if(l_itr != g_globalMap.end())
                        {
                           HLRStatisticsInitializer::logStatistics(l_itr->second);
                        }
                        l_ImsApnNotDownloadedTdrReason += "TPS";
                        m_tdr.setString(TDR_INDEX_GGSN_ADDRESS,(char*)l_ImsApnNotDownloadedTdrReason.c_str());
                        continue;
                     }
                  }
                  else
                  {
                     LLOG(0,0,"DPH not Configured for IMS APN ....");
                     continue;
                  }
               }
               else
               {
                  LLOG(0,0,"IMS APN DPH threshold not applicable .. [%d]",l_ImsApnDph);
               }
            }

            m_tdr.setString(TDR_INDEX_NOR_MIP6AI_HA_FAMILY1, l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_serviceSelection);
            map<string,int>::iterator l_itr = g_globalMap.find("IMSAPNInterested");
            if(l_itr != g_globalMap.end())
            {
               DLOG(0,0,"Stats written ... IMSAPNInterested");
               HLRStatisticsInitializer::logStatistics(l_itr->second);
            }
         }
         ServiceSelection l_serviceSelection(l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_serviceSelection);
         l_apnConfiguration.setServiceSelection(l_serviceSelection);
         l_apnTdrData += l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_serviceSelection;
         l_apnTdrData += "|";
         LLOG(0,0,"ULA: SubscriptionData: APN-[%d]: ServiceSelection[%s]",l_count,l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_serviceSelection);
      }
      else
      {
         CLOG(0,0,"ULA: SubscriptionData: APN: Exception: ServiceSelection Mandatory Param missing or wrong[%s]",l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_serviceSelection);
         return false;
      }

      if( (m_IPv4Addr.length() > 1) && (m_IPv6Addr.length() > 1) )
      {
         TLOG(0,0,"Subscriber specific IPV4 Address [%s] and IPV6 Address [%s] present, Filling IPV4 Address as ServedPartyAddress1 and IPV6 Address as ServedPartyAddress2",(char *)m_IPv4Addr.c_str(), (char *)m_IPv6Addr.c_str());
         Address l_SPaddress1(Address::IPV4, (char *)m_IPv4Addr.c_str());
         ServedPartyIPAddress l_servedPartyAddress1(l_SPaddress1);
         l_apnConfiguration.addServedPartyIPAddress(l_servedPartyAddress1);
         Address l_SPaddress2(Address::IPV6, (char *)m_IPv6Addr.c_str());
         ServedPartyIPAddress l_servedPartyAddress2(l_SPaddress2);
         l_apnConfiguration.addServedPartyIPAddress(l_servedPartyAddress2);
      }
      else if((m_IPv4Addr.length() > 1) || (m_IPv6Addr.length() > 1))
      {
         if(m_IPv4Addr.length() > 1)
         {
            TLOG(0,0,"Subscriber specific IPV4 Address [%s] present, Filling IPV4 Address as ServedPartyAddress",(char *)m_IPv4Addr.c_str());
            Address l_SPaddress1(Address::IPV4, (char *)m_IPv4Addr.c_str());
            ServedPartyIPAddress l_servedPartyAddress1(l_SPaddress1);
            l_apnConfiguration.addServedPartyIPAddress(l_servedPartyAddress1);
         }
         else
         {
            TLOG(0,0,"Subscriber specific IPV6 Address [%s] present, Filling IPV6 Address as ServedPartyAddress",(char *)m_IPv6Addr.c_str());
            Address l_SPaddress1((Address::IPV6),(char *)m_IPv6Addr.c_str());
            ServedPartyIPAddress l_servedPartyAddress1(l_SPaddress1);
            l_apnConfiguration.addServedPartyIPAddress(l_servedPartyAddress1);
         }
      }
      else
      { 
         if( (l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_servedPartyFamily1 > 0) && (l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_servedPartyFamily1 <= 24) && (strlen(l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_servedPartyAddress1) > 1) )
         {
            if(1 == l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_servedPartyFamily1)
            {
               TLOG(0,0,"Subscriber specific IPV4 Address not present, Filling ServedPartyAddress1 from config[%s]",l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_servedPartyAddress1);
               Address l_SPaddress1(Address::IPV4, l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_servedPartyAddress1);
               ServedPartyIPAddress l_servedPartyAddress1(l_SPaddress1);
               l_apnConfiguration.addServedPartyIPAddress(l_servedPartyAddress1);
            }
            else if(2 == l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_servedPartyFamily1)
            {
               TLOG(0,0,"Subscriber specific IPV6 Address not present, Filling ServedPartyAddress1 from config[%s]",l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_servedPartyAddress1);
               Address l_SPaddress1((Address::IPV6), l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_servedPartyAddress1);
               ServedPartyIPAddress l_servedPartyAddress1(l_SPaddress1);
               l_apnConfiguration.addServedPartyIPAddress(l_servedPartyAddress1);
            }
            else
            {
               Address l_SPaddress1;
               l_SPaddress1.family = (Address::Family)l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_servedPartyFamily1;
               l_SPaddress1.value = l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_servedPartyAddress1;
               ServedPartyIPAddress l_servedPartyAddress1(l_SPaddress1);
               l_apnConfiguration.addServedPartyIPAddress(l_servedPartyAddress1);
            }
            LLOG(0,0,"ULA: SubscriptionData: APN-[%d]: ServedPartyFamily1[%d] ServedPartyAddress1[%s]",l_count,l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_servedPartyFamily1,l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_servedPartyAddress1);
         }
         if( (l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_servedPartyFamily2 > 0) && (l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_servedPartyFamily2 <= 24) && (strlen(l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_servedPartyAddress2) > 1) )
         {
            if(1 == l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_servedPartyFamily2)
            {
               TLOG(0,0,"Subscriber specific IPV4 Address not present, Filling ServedPartyAddress2 from config[%s]",l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_servedPartyAddress2);
               Address l_SPaddress2(Address::IPV4, l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_servedPartyAddress2);
               ServedPartyIPAddress l_servedPartyAddress2(l_SPaddress2);
               l_apnConfiguration.addServedPartyIPAddress(l_servedPartyAddress2);
            }
            else if(2 == l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_servedPartyFamily2)
            {
               TLOG(0,0,"Subscriber specific IPV6 Address not present, Filling ServedPartyAddress2 from config[%s]",l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_servedPartyAddress2);
               Address l_SPaddress2((Address::IPV6),l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_servedPartyAddress2);
               ServedPartyIPAddress l_servedPartyAddress2(l_SPaddress2);
               l_apnConfiguration.addServedPartyIPAddress(l_servedPartyAddress2);
            }
            else
            {
               Address l_SPaddress2;
               l_SPaddress2.family = (Address::Family)l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_servedPartyFamily2;
               l_SPaddress2.value = l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_servedPartyAddress2;
               ServedPartyIPAddress l_servedPartyAddress2(l_SPaddress2);
               l_apnConfiguration.addServedPartyIPAddress(l_servedPartyAddress2);
            }
            LLOG(0,0,"ULA: SubscriptionData: APN-[%d]: ServedPartyFamily2[%d] ServedPartyAddress2[%s]",l_count,l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_servedPartyFamily2,l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_servedPartyAddress2);
         }
      }
      EPSSubscribedQoSProfile l_epsSubscribedQosProfile;

      // qos_class_identifier - 0 (Reserved)
      bool l_qos_class_indentifier = false;
      if( (l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_esqp_qos_class_identifier > 0) && (l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_esqp_qos_class_identifier <= 255) )
      {
         QoSClassIdentifier l_qosClassIdentifier((QoSClassIdentifier::Value)l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_esqp_qos_class_identifier);
         l_epsSubscribedQosProfile.setQoSClassIdentifier(l_qosClassIdentifier);
         LLOG(0,0,"ULA: SubscriptionData: APN-[%d]: QosClassIdentifier[%d]",l_count,l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_esqp_qos_class_identifier);
         l_qos_class_indentifier = true;
      }

      if( true == l_qos_class_indentifier )
      {
         AllocationRetentionPriority l_allocRetentPriority;
         if( (l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_esqp_app_priority_level >= 1) && (l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_esqp_app_priority_level <= 15) )
         {
            PriorityLevel l_priorityLevel(l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_esqp_app_priority_level);
            l_allocRetentPriority.setPriorityLevel(l_priorityLevel);
            LLOG(0,0,"ULA: SubscriptionData: APN-[%d]: PriorityLevel[%d]",l_count,l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_esqp_app_priority_level);
         }
         else
         {
            CLOG(0,0,"ULA: SubscriptionData: APN: Exception: QosClassIdentifier present and AllocationRetentionPriorityLevel[%d] not present or wrong",l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_esqp_app_priority_level);
            return false;
         }

         if( (l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_esqp_arp_pre_empt_cap == 0) || (l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_esqp_arp_pre_empt_cap == 1) )
         {
            PreemptionCapability l_premptCap((PreemptionCapability::Value)l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_esqp_arp_pre_empt_cap);
            l_allocRetentPriority.setPreemptionCapability(l_premptCap);
            LLOG(0,0,"ULA: SubscriptionData: APN-[%d]: PreEmptCap[%d]",l_count,l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_esqp_arp_pre_empt_cap);
         }

         if( (l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_esqp_arp_pre_vlner == 0) || (l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_esqp_arp_pre_vlner == 1) )
         {
            PreemptionVulnerability l_premptVuln((PreemptionVulnerability::Value)l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_esqp_arp_pre_vlner);
            l_allocRetentPriority.setPreemptionVulnerability(l_premptVuln);
            l_epsSubscribedQosProfile.setAllocationRetentionPriority(l_allocRetentPriority);
            LLOG(0,0,"ULA: SubscriptionData: APN-[%d]: PreEmptVuln[%d]",l_count,l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_esqp_arp_pre_vlner);
         }

         l_apnConfiguration.setEPSSubscribedQoSProfile(l_epsSubscribedQosProfile);
      }

      if( (l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_vplmn_dyn_addr_allowed == 0) || (l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_vplmn_dyn_addr_allowed == 1) )
      {
         VPLMNDynamicAddressAllowed l_vplmnDynamicAddrAllowed((VPLMNDynamicAddressAllowed::Value)l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_vplmn_dyn_addr_allowed);
         l_apnConfiguration.setVPLMNDynamicAddressAllowed(l_vplmnDynamicAddrAllowed);
         LLOG(0,0,"ULA: SubscriptionData: APN-[%d]: VPLMNDynamicAddrAllowed[%d]",l_count,l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_vplmn_dyn_addr_allowed);
      }

      MIP6AgentInfo l_mip6AgentInfo;
      bool l_apnMip6Set = false;
      bool l_imsSarIpFlag = false;
      bool l_imsSarFQDNFlag = false;

      //ha_family 0 = Reserved
      if( (l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_family1 > 0) && (l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_family1 <= 24) && (strlen(l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_addr_1) > 1) )
      {
         if(1 == l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_family1)
         {
            Address l_mipHA1(Address::IPV4,l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_addr_1);
            MIPHomeAgentAddress l_mipHomeAgentAddr1(l_mipHA1);
            l_mip6AgentInfo.addMIPHomeAgentAddress(l_mipHomeAgentAddr1);
            l_apnMip6Set = true;
         }
         else if(2 == l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_family1)
         {
            Address l_mipHA1((Address::IPV6),l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_addr_1);
            MIPHomeAgentAddress l_mipHomeAgentAddr1(l_mipHA1);
            l_mip6AgentInfo.addMIPHomeAgentAddress(l_mipHomeAgentAddr1);
            l_apnMip6Set = true;
         }
         else
         {
            Address l_mipHA1;
            l_mipHA1.family = (Address::Family)l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_family1;
            l_mipHA1.value = l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_addr_1;
            MIPHomeAgentAddress l_mipHomeAgentAddr1(l_mipHA1);
            l_mip6AgentInfo.addMIPHomeAgentAddress(l_mipHomeAgentAddr1);
            l_apnMip6Set = true;
         }
         LLOG(0,0,"ULA: SubscriptionData: APN-[%d]: Mip6Family1[%d] Mip6ai_ha_addr1[%s]",l_count,l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_family1,l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_addr_1);


      }

      if( (l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_family2 > 0) && (l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_family2 <= 24) && (strlen(l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_addr_2) > 1) )
      {
         if(1 == l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_family2)
         {
            Address l_mipHA2(Address::IPV4,l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_addr_2);
            MIPHomeAgentAddress l_mipHomeAgentAddr2(l_mipHA2);
            l_mip6AgentInfo.addMIPHomeAgentAddress(l_mipHomeAgentAddr2);
            l_apnMip6Set = true;
         }
         else if(2 == l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_family2)
         {
            Address l_mipHA2((Address::IPV6),l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_addr_2);
            MIPHomeAgentAddress l_mipHomeAgentAddr2(l_mipHA2);
            l_mip6AgentInfo.addMIPHomeAgentAddress(l_mipHomeAgentAddr2);
            l_apnMip6Set = true;
         }
         else
         {
            Address l_mipHA2;
            l_mipHA2.family = (Address::Family)l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_family2;
            l_mipHA2.value = l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_addr_2;
            MIPHomeAgentAddress l_mipHomeAgentAddr2(l_mipHA2);
            l_mip6AgentInfo.addMIPHomeAgentAddress(l_mipHomeAgentAddr2);
            l_apnMip6Set = true;
         }
         LLOG(0,0,"ULA: SubscriptionData: APN-[%d]: Mip6Family2[%d] Mip6ai_ha_addr2[%s]",l_count,l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_family2,l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_addr_2);

      }
      //6.4.0.0 Start
      if(1 == g_spdPtr->m_MsisdnPrefReplaceStruct.m_HandOverWifiToVolte)
      {
         DLOG(0,0,"HandOver Wifi to Volte Flag is enabled in system setting ... So taking MIPVHomeAgent from SAR");
         if((0 != strlen(mp_HssSubsData->m_SarIpv4Address_OUT)) && (0 == strncmp("ims",l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_serviceSelection,strlen(l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_serviceSelection))))
         {
            LLOG(0,0,"SAR Ipv4Address [%s]",mp_HssSubsData->m_SarIpv4Address_OUT);
            m_tdr.setString(TDR_INDEX_NOR_MIP6AI_HA_ADDR1,mp_HssSubsData->m_SarIpv4Address_OUT);
	    Address l_mipHA2 (Address::IPV4,mp_HssSubsData->m_SarIpv4Address_OUT);
            MIPHomeAgentAddress l_mipHomeAgentAddr2(l_mipHA2);
            l_mip6AgentInfo.addMIPHomeAgentAddress(l_mipHomeAgentAddr2);
            l_apnMip6Set = true;
            l_imsSarIpFlag = true;
         }

         if(((0 != strlen(mp_HssSubsData->m_SarPgwHost_OUT)) && (0 != strlen(mp_HssSubsData->m_SarPgwRealm_OUT))) && (0 == strncmp("ims",l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_serviceSelection,strlen(l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_serviceSelection)))) 
         {
            MIPHomeAgentHost l_mipHomeAgentHost;
            l_mipHomeAgentHost.setDestinationRealm(base::DestinationRealm(mp_HssSubsData->m_SarPgwRealm_OUT));
            l_mipHomeAgentHost.setDestinationHost(base::DestinationHost(mp_HssSubsData->m_SarPgwHost_OUT));
            l_mip6AgentInfo.setMIPHomeAgentHost(l_mipHomeAgentHost);
            // l_mip6AgentInfo.setMIP6HomeLinkPrefix(); not used in S6a/S6d
            l_apnMip6Set = true;
            l_imsSarFQDNFlag = true;
            LLOG(0,0,"ULA: SubscriptionData: APN-[%d]: Mip6PGWDestRealm[%s] Mip6PGWDestHost[%s]",l_count,mp_HssSubsData->m_SarPgwRealm_OUT,mp_HssSubsData->m_SarPgwHost_OUT);
         }
      }
      //6.4.0.0 End

      if( (false == l_imsSarFQDNFlag) &&  ((strlen(l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_dest_host) > 1) && (strlen(l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_dest_realm) > 1)) )
      {
         MIPHomeAgentHost l_mipHomeAgentHost;
         l_mipHomeAgentHost.setDestinationRealm(base::DestinationRealm(l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_dest_realm));
         l_mipHomeAgentHost.setDestinationHost(base::DestinationHost(l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_dest_host));
         l_mip6AgentInfo.setMIPHomeAgentHost(l_mipHomeAgentHost);
         // l_mip6AgentInfo.setMIP6HomeLinkPrefix(); not used in S6a/S6d
         l_apnMip6Set = true;
         LLOG(0,0,"ULA: SubscriptionData: APN-[%d]: Mip6DestRealm[%s] Mip6DestHost[%s]",l_count,l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_dest_realm,l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_dest_host);
      }

      if(true == l_apnMip6Set)
      {
         l_apnConfiguration.setMIP6AgentInfo(l_mip6AgentInfo);
      }

      if( (strlen(l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_visited_net_ident) > 1) )
      {
         VisitedNetworkIdentifier l_visitedNkId(l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_visited_net_ident);
         l_apnConfiguration.setVisitedNetworkIdentifier(l_visitedNkId);
         LLOG(0,0,"ULA: SubscriptionData: APN-[%d]: VisitedNetworkId[%s]",l_count,l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_visited_net_ident);
      }

      if((0 == mp_HssSubsData->m_ApnOiOverrideInd_OUT) || (true == l_ImsApnPresent))
      {
         DLOG(0,0,"Overriding ApnOi in ULR");
         if( (strlen(l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_ctxt_apn_oi_replacement) > 1) )
         {
            APNOIReplacement l_apnOIReplacement(l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_ctxt_apn_oi_replacement); 
            l_apnConfiguration.setAPNOIReplacement(l_apnOIReplacement);
            LLOG(0,0,"ULA: SubscriptionData: APN-[%d]: APNOIReplacement[%s]",l_count,l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_ctxt_apn_oi_replacement);
         }
      }
      else
      {
         DLOG(0,0,"MnoProvisionFlag and MnoProvisioningStatus is 1 ... So not Overriding ApnOi");
      }

      if( (0 == l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_sipto_permission) || (1 == l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_sipto_permission) )
      {
         SIPTOPermission l_siptoPermission((SIPTOPermission::Value)l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_sipto_permission);
         l_apnConfiguration.setSIPTOPermission(l_siptoPermission);
         LLOG(0,0,"ULA: SubscriptionData: APN-[%d]: SIPTOPermission[%d]",l_count,l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_sipto_permission);
      }

      if( (0 == l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_lipa_permission) || (1 == l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_lipa_permission) || (2 == l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_lipa_permission))
      {
         LIPAPermission l_lipaPermission((LIPAPermission::Value)l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_lipa_permission);
         l_apnConfiguration.setLIPAPermission(l_lipaPermission);
         LLOG(0,0,"ULA: SubscriptionData: APN-[%d]: LIPAPermission[%d]",l_count,l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_lipa_permission);
      }

      if( (strlen(l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_dest_realm) > 1) || (strlen(l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_dest_host) > 1) )     
      {
         if( (0 == l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_pdn_gw_allocation_type) || (1 == l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_pdn_gw_allocation_type) )
         {
            PDNGWAllocationType l_pdnGwAllocType((PDNGWAllocationType::Value)l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_pdn_gw_allocation_type);
            l_apnConfiguration.setPDNGWAllocationType(l_pdnGwAllocType);
            LLOG(0,0,"ULA: SubscriptionData: APN-[%d]: PDNGWAllocationType[%d]",l_count,l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_pdn_gw_allocation_type);
         }
      }

      if ((l_imsSarIpFlag == true) || (true == l_imsSarFQDNFlag))
      {
         PDNGWAllocationType l_pdnGwAllocType((PDNGWAllocationType::Value)1);
         l_apnConfiguration.setPDNGWAllocationType(l_pdnGwAllocType);
         LLOG(0,0,"ULR: SAR IP is set so PDNGWAllocationType  marked as STATIC");
      }

      if(HSS_3GPPCHARGINGCHAR_LEN == l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_3gpp_charg_char_len)
      {
         string l_3gppChrgChar;
         char l_3gppChrgChrString[5];
         snprintf(l_3gppChrgChrString,sizeof(l_3gppChrgChrString),"%02x%02x",(s8*)l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_3gpp_charg_char[0],(s8*)l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_3gpp_charg_char[1]);
         l_3gppChrgChar.assign(l_3gppChrgChrString,HSS_3GPPCHARGINGCHAR_LEN+2);
         S6a3GPPChargingCharacteristics l_s6a3gppChrgChar(l_3gppChrgChar);
         l_apnConfiguration.setS6a3GPPChargingCharacteristics(l_s6a3gppChrgChar);
         LLOG_HEX(0,0,"ULA: SubscriptionData: APN: 3gppChrgChar",l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_3gpp_charg_char,HSS_3GPPCHARGINGCHAR_LEN);
      }

      AMBR l_ambr;
      MaxRequestedBandwidthUL l_maxReqBwUL(l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_ambr_max_req_bandwidth_ul);
      MaxRequestedBandwidthDL l_maxReqBwDL(l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_ambr_max_req_bandwidth_dl);
      l_ambr.setMaxRequestedBandwidthUL(l_maxReqBwUL);
      l_ambr.setMaxRequestedBandwidthDL(l_maxReqBwDL);
      //5056
      if((4294967295 == l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_ambr_max_req_bandwidth_ul) && (true == m_5gSupportFlag) && (true == m_hlr_5gSupportFlag))
      {
         DLOG(0,0,"Both HLR and MME 5gSupportFlag is true, checking for ExtendedAmbrMaxReqUpLink");
         LLOG(0,0,"ULA: SubscriptionData: APN: ExtendedAmbrMaxReqUpLink[%u]", l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_ext_ambr_max_req_bandwidth_ul);
         if(l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_ext_ambr_max_req_bandwidth_ul > 0)
         {
            ExtendedMaxRequestedBWUL l_extendedUL(l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_ext_ambr_max_req_bandwidth_ul);
            l_ambr.setExtendedMaxRequestedBWUL(l_extendedUL);
         }
         else
         {
            TLOG(0,0,"ExtendedAmbrMaxReqUpLink Not configured");
         }
      }
      else
      {
         LLOG(0,0,"ExtendedAmbrMaxReqUpLink NOT sending as limit not set to 4294967295, it is [%u]",l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_ambr_max_req_bandwidth_ul);
      }
      if((4294967295 == l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_ambr_max_req_bandwidth_dl) && (true == m_5gSupportFlag) && (true == m_hlr_5gSupportFlag))
      {
         DLOG(0,0,"Both HLR and MME 5gSupportFlag is true, checking for ExtendedAmbrMaxReqDownLink");
         LLOG(0,0,"ULA: SubscriptionData: APN: ExtendedAmbrMaxReqDownLink[%u]", l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_ext_ambr_max_req_bandwidth_dl);
         if(l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_ext_ambr_max_req_bandwidth_dl > 0)
         {
            ExtendedMaxRequestedBWDL l_extendedDL(l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_ext_ambr_max_req_bandwidth_dl);
            l_ambr.setExtendedMaxRequestedBWDL(l_extendedDL);
         }
         else
         {
            TLOG(0,0,"ExtendedAmbrMaxReqDownLink Not configured");
         }
      }
      else
      {
         LLOG(0,0,"ExtendedAmbrMaxReqDownLink NOT sending as limit not set to 4294967295, it is [%u]",l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_ambr_max_req_bandwidth_dl);
      }
      //5056
      l_apnConfiguration.setAMBR(l_ambr);
      LLOG(0,0,"ULA: SubscriptionData: APN: MaxReqBwUL[%u] MaxReqBwDL[%u]",l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_ambr_max_req_bandwidth_ul, l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_ambr_max_req_bandwidth_dl);

      int l_SpecCount = 1;
      list<SpecificApnInfo>::iterator l_specificApnIter;
      for(l_specificApnIter = l_ctxtIdIter->second.m_SepcificApnsList.begin(); l_specificApnIter != l_ctxtIdIter->second.m_SepcificApnsList.end(); l_specificApnIter++)
      {
         SpecificAPNInfo l_specificApnInfo;
         bool l_specInfo = false;

         /*char l_TokensImsApnMccMnc [5][10];
         memset(l_TokensImsApnMccMnc,'\0',sizeof(l_TokensImsApnMccMnc));
         tokenize(mp_HssSubsData->m_MccMncWhitelist_OUT, (char*)l_TokensImsApnMccMnc, 11);
         DLOG(0,0,"Tokenized Ims Apn MccMnc indicator 1[%s] 2[%s]", (char *)l_TokensImsApnMccMnc[1], (char *)l_TokensImsApnMccMnc[2]);*/

         char l_ImsApnMccMncData[20+1];
         char l_TokensImsApnMccMnc [5][10];
         memset(l_TokensImsApnMccMnc,'\0',sizeof(l_TokensImsApnMccMnc));
         memset(l_ImsApnMccMncData,'\0',sizeof(l_ImsApnMccMncData));
         sprintf(l_ImsApnMccMncData,"|%s|",mp_HssSubsData->m_MccMncWhitelist_OUT);
         DLOG(0,0,"Before Tokenizing ImsApnMccMncData is [%s]",l_ImsApnMccMncData);
         tokenize2(l_ImsApnMccMncData,(char*)l_TokensImsApnMccMnc,10,'|');
         DLOG(0,0,"Tokenized Ims Apn MccMnc indicator 1[%s] 2[%s]", (char *)l_TokensImsApnMccMnc[1], (char *)l_TokensImsApnMccMnc[2]);

         int l_AllowImsApnForRoaming = 0;
         char l_AllowImsApnForRoamingTdr [25];
         memset(l_AllowImsApnForRoamingTdr,'\0',sizeof(l_AllowImsApnForRoamingTdr));
         if((0 == strcmp("1",l_TokensImsApnMccMnc[1])) && (0 != mp_HssSubsData->m_RoamingInd_OUT))
         {
            DLOG(0,0,"Ims Apn Roaming MccMnc Whitelist Flag is enabled");
            if(0 == strcmp("1",l_TokensImsApnMccMnc[2]))
            {
               LLOG(0,0,"MccMncc received belongs to whitelisted list");
               l_AllowImsApnForRoaming = 1;
               m_tdr.setString(TDR_INDEX_GGSN_IP_ADDRESS,"ImsRoamWhitelist");
            }
            else
            {
               m_tdr.setString(TDR_INDEX_GGSN_IP_ADDRESS,"ImsRoamBlacklist");
            }
         }

         if(0 != strcmp("0",l_specificApnIter->m_serviceSelection))
         {
            if(0 == strcasecmp("ims",l_specificApnIter->m_serviceSelection))
            {
               if((0 == atoi(l_TokensVoLteRoamingCap[1])) && (1 == atoi(l_TokensVoLteRoamingCap[2])))
               {
                  LLOG(0,0,"IMS apn not downloading.. Restricted for this partner [%d] Network Partner [%d]",mp_HssSubsData->m_PartnerNkId_OUT,atoi(l_TokensVoLteRoamingCap[3]));
                  map<string,int>::iterator l_itr = g_globalMap.find("ImsApnNotDownloaded-NotApplicableForRoamPartner");
                  if(l_itr != g_globalMap.end())
                  {
                     HLRStatisticsInitializer::logStatistics(l_itr->second);
                  }
                  continue;
               }

               if( !((1 == mp_HssSubsData->m_ims_service_flag_OUT) && (mp_HssSubsData->m_ImsProfId_OUT > 0) && (0 == mp_HssSubsData->m_roamImsiBlacKInd_OUT)) )
               {
                  LLOG(0,0,"IMS service disabled for the subscriber, not sending IMS APN Specific Context.. ignoring");
		  if(mp_HssSubsData->m_roamImsiBlacKInd_OUT == 1)
                  {
                  LLOG(0,0,"Roaming IMSI is Blacklisted");
                  m_tdr.setInteger(TDR_INDEX_SMSM_GPRS_FLAG,1);
                  }
                  else
                  {
                  LLOG(0,0,"Not sending IMS APN because IMS Service is disabled or IMS Profile Id not present");
                  m_tdr.setInteger(TDR_INDEX_SMSM_GPRS_FLAG,0);
                  }  
                  if(!(1 == mp_HssSubsData->m_ims_service_flag_OUT))
                  {
                     LLOG(0,0,"Stats written ... Ims Apn not downloaded because Ims Flag not enabled");
                     map<string,int>::iterator l_itr = g_globalMap.find("ImsApnNotDownloaded-ImsFlagDisabled");
                     if(l_itr != g_globalMap.end())
                     {
                        HLRStatisticsInitializer::logStatistics(l_itr->second);
                     }
                  }
                  continue;
               }
               if( (2 == mp_HssSubsData->m_RoamingInd_OUT) && (0 == strcmp("1",l_TokensImsApnMccMnc[1])) )
               {
                  DLOG(0,0,"Roaming Subscriber and RoamMCCMNC APN enabled");
                  if(1 != l_AllowImsApnForRoaming)
                  {
                     LLOG(0,0,"MccMnc is not Whitelisted for the subscriber, not sending IMS APN Context.. ignoring");
                     LLOG(0,0,"Stats written ... Ims Apn not downloaded because Roaming MccMnc not whitelisted");
                     map<string,int>::iterator l_itr = g_globalMap.find("ImsApnNotDownloaded-MccMncRoamNotWhitelisted");
                     if(l_itr != g_globalMap.end())
                     {
                        HLRStatisticsInitializer::logStatistics(l_itr->second);
                     }
                     continue;
                  }
               }
            }
            ServiceSelection l_specServiceSelection(l_specificApnIter->m_serviceSelection);
            l_specificApnInfo.setServiceSelection(l_specServiceSelection);
            LLOG(0,0,"ULA: SubscriptionData: SpecificAPN-[%d]: ServiceSelection[%s]",l_SpecCount,l_specificApnIter->m_serviceSelection);
            l_specInfo = true;
         }

         MIP6AgentInfo l_specMip6AgentInfo;
         bool l_specMip6info = false;

         if( (strlen(l_specificApnIter->m_visited_net_ident) > 1 ) )
         {
            VisitedNetworkIdentifier l_specVisitedNkId(l_specificApnIter->m_visited_net_ident);
            l_specificApnInfo.setVisitedNetworkIdentifier(l_specVisitedNkId);
            LLOG(0,0,"ULA: SubscriptionData: SpecificAPN-[%d]: VisitedNetworkId[%s]",l_SpecCount,l_specificApnIter->m_visited_net_ident);
            l_specInfo = true;
         }

         if( (l_specificApnIter->m_mip6ai_ha_family1 > 0) && (l_specificApnIter->m_mip6ai_ha_family1 <= 24) && (strlen(l_specificApnIter->m_mip6ai_ha_addr_1) > 1) )
         {
            if(1 == l_specificApnIter->m_mip6ai_ha_family1)
            {
               Address l_specMipHA1(Address::IPV4,l_specificApnIter->m_mip6ai_ha_addr_1);
               MIPHomeAgentAddress l_specMipHomeAgentAddr1(l_specMipHA1);
               l_specMip6AgentInfo.addMIPHomeAgentAddress(l_specMipHomeAgentAddr1);
            }
            else if(2 == l_specificApnIter->m_mip6ai_ha_family1)
            {
               Address l_specMipHA1((Address::IPV6),l_specificApnIter->m_mip6ai_ha_addr_1);
               MIPHomeAgentAddress l_specMipHomeAgentAddr1(l_specMipHA1);
               l_specMip6AgentInfo.addMIPHomeAgentAddress(l_specMipHomeAgentAddr1);
            }
            else
            {
               Address l_specMipHA1;
               l_specMipHA1.family = (Address::Family)l_specificApnIter->m_mip6ai_ha_family1;
               l_specMipHA1.value = l_specificApnIter->m_mip6ai_ha_addr_1;
               MIPHomeAgentAddress l_specMipHomeAgentAddr1(l_specMipHA1);
               l_specMip6AgentInfo.addMIPHomeAgentAddress(l_specMipHomeAgentAddr1);
            }
            LLOG(0,0,"ULA: SubscriptionData: SpecificAPN-[%d]: ServiceSelection[%s] Mip6Family1[%d] Mip6ai_ha_addr1[%s]",l_SpecCount,l_specificApnIter->m_serviceSelection, l_specificApnIter->m_mip6ai_ha_family1,l_specificApnIter->m_mip6ai_ha_addr_1);
            l_specMip6info = true;
         }

         if( (l_specificApnIter->m_mip6ai_ha_family2 > 0) && (l_specificApnIter->m_mip6ai_ha_family2 <= 24) && (strlen(l_specificApnIter->m_mip6ai_ha_addr_2) > 1) )
         {
            if(1 == l_specificApnIter->m_mip6ai_ha_family2)
            {
               Address l_specMipHA2(Address::IPV4,l_specificApnIter->m_mip6ai_ha_addr_2);
               MIPHomeAgentAddress l_specMipHomeAgentAddr2(l_specMipHA2);
               l_specMip6AgentInfo.addMIPHomeAgentAddress(l_specMipHomeAgentAddr2);
            }
            else if(2 == l_specificApnIter->m_mip6ai_ha_family2)
            {
               Address l_specMipHA2(Address::IPV6,l_specificApnIter->m_mip6ai_ha_addr_2);
               MIPHomeAgentAddress l_specMipHomeAgentAddr2(l_specMipHA2);
               l_specMip6AgentInfo.addMIPHomeAgentAddress(l_specMipHomeAgentAddr2);
            }
            else
            {
               Address l_specMipHA2;
               l_specMipHA2.family = (Address::Family)l_specificApnIter->m_mip6ai_ha_family2;
               l_specMipHA2.value = l_specificApnIter->m_mip6ai_ha_addr_2;
               MIPHomeAgentAddress l_specMipHomeAgentAddr2(l_specMipHA2);
               l_specMip6AgentInfo.addMIPHomeAgentAddress(l_specMipHomeAgentAddr2);
            }
            LLOG(0,0,"ULA: SubscriptionData: SpecificAPN-[%d]: Mip6Family2[%d] Mip6ai_ha_addr2[%s]",l_SpecCount,l_specificApnIter->m_mip6ai_ha_family2,l_specificApnIter->m_mip6ai_ha_addr_2);
            l_specMip6info = true;
         }

         if( (strlen(l_specificApnIter->m_mip6ai_ha_dest_realm) > 1) && (strlen(l_specificApnIter->m_mip6ai_ha_dest_host) > 1) )
         {
            MIPHomeAgentHost l_specMipHomeAgentHost;

            l_specMipHomeAgentHost.setDestinationRealm(base::DestinationRealm(l_specificApnIter->m_mip6ai_ha_dest_realm));
            l_specMipHomeAgentHost.setDestinationHost(base::DestinationHost(l_specificApnIter->m_mip6ai_ha_dest_host));
            l_specMip6AgentInfo.setMIPHomeAgentHost(l_specMipHomeAgentHost);
            LLOG(0,0,"ULA: SubscriptionData: SpecificAPN-[%d]: DestRealm[%s] DestHost[%s]",l_SpecCount,l_specificApnIter->m_mip6ai_ha_dest_realm,l_specificApnIter->m_mip6ai_ha_dest_host);
            l_specMip6info = true;
         }
         // l_mip6AgentInfo.setMIP6HomeLinkPrefix(); not used in S6a/S6d
         if(true == l_specMip6info)
         {
            l_specificApnInfo.setMIP6AgentInfo(l_specMip6AgentInfo);
         }

         if(true == l_specInfo)
         {
            l_apnConfiguration.addSpecificAPNInfo(l_specificApnInfo);
         }
         ++l_SpecCount;
      }

      aApnConfProf.addAPNConfiguration(l_apnConfiguration);
      ++l_count;
   }
   m_tdr.setString(TDR_INDEX_NOR_SERVICE_SELECTION,(char*)l_apnTdrData.c_str());
   return true;
}

bool CtxtLteUpdateLocationRequest::startProcessing(InterModuleData *p_imd,bool &p_DeleteFlag)
{
   DLOG(0, 0, "Start of CtxtUpdateGPRSLocation::startProcessing function, Delete flag %d",p_DeleteFlag);
   LLOG(0,0,"InterModule data for ULR Received from [%s] Xml Request [%s]", p_imd->m_OriginatorModule,(NULL == p_imd->m_Parameters)?"":p_imd->m_Parameters);

   if(NULL == p_imd->m_Parameters)
   {
      CLOG(0,0,"p_imd->m_Parameters NULL returning");
      return false;
   }

   m_fIdr = true;

   m_tdr.setString(TDR_INDEX_AUC_NUM_VECTORS_REQUESTED,"FULL_IDR_MME");

   char *l_check = NULL;
   l_check = strchr(p_imd->m_Parameters, ':');
   if(l_check == NULL)
   {
      TLOG(0,0,"Transaction ID not present");
      //return false;
      //m_DataString.assign(&p_imd->m_Parameters[0]);
      m_DataString.assign(p_imd->m_Parameters);
   }
   else
   {
      strncpy(m_TransId,p_imd->m_Parameters, strlen(p_imd->m_Parameters)-strlen(l_check));
      LLOG(0,0,"Transaction ID :%s received from OAM", m_TransId);

      //m_DataString.assign(&p_imd->m_Parameters[strlen(p_imd->m_Parameters)-strlen(l_check)]);
      //m_DataString.assign(p_imd->m_Parameters[strlen(p_imd->m_Parameters)-strlen(l_check)]);
      m_DataString.assign(&p_imd->m_Parameters[strlen(p_imd->m_Parameters)-strlen(l_check)]);
      DLOG(0,0,"m_DataString [%s]",(char*)m_DataString.c_str());
      m_tdr.setString(TDR_INDEX_OAM_TRANSACTION_ID, m_TransId);
   }

   //m_tdr.setOpCode(112);
   //m_tdr.setContextId("LMMIDR");
   m_tdr.setOriginatingModule("MMEIDR");

   string l_imsi = ConfigReader::readValue(m_DataString, "ULRIMSI");
   if(1 > l_imsi.length())
   {
      CLOG(0,0,"Unknown IMSI");
      return false;
   }
   snprintf(m_UlrImsi, sizeof(m_UlrImsi),l_imsi.c_str());

   string l_mmehost = ConfigReader::readValue(m_DataString, "MMEHOST");
   if(1 > l_mmehost.length())
   {
      CLOG(0,0,"Unknown MMEHOST");
   }
   else
   {
      DLOG(0,0,"startProcessing: MMEHOST[%s]",l_mmehost.c_str());
   }
   snprintf(m_MmeHost, sizeof(m_MmeHost),l_mmehost.c_str());

   string l_mmerealm = ConfigReader::readValue(m_DataString, "MMEREALM");
   if(1 > l_mmerealm.length())
   {
      CLOG(0,0,"Unknown MMEREALM");
   }
   else
   {
      DLOG(0,0,"startProcessing: MMEREALM[%s]",l_mmerealm.c_str());
   }
   snprintf(m_MmeRealm, sizeof(m_MmeRealm),l_mmerealm.c_str());

   string l_ulrflag = ConfigReader::readValue(m_DataString, "ULRFLAG");
   if(1 > l_ulrflag.length())
   {
      CLOG(0,0,"Unknown ULRFLAG");
   }
   else
   {
      DLOG(0,0,"startProcessing: ULRFLAG[%d]",atoi(l_ulrflag.c_str()));
   }
   m_UlrFlag = atoi(l_ulrflag.c_str());

   string l_featurelist1 = ConfigReader::readValue(m_DataString, "FEATURELIST1");
   if(1 > l_featurelist1.length())
   {
      CLOG(0,0,"Unknown FEATURELIST1");
   }
   else
   {
      DLOG(0,0,"startProcessing: FEATURELIST1[%d]",atoi(l_featurelist1.c_str()));
   }
   m_featureList1 = atoi(l_featurelist1.c_str());

   string l_featurelist2 = ConfigReader::readValue(m_DataString, "FEATURELIST2");
   if(1 > l_featurelist2.length())
   {
      CLOG(0,0,"Unknown FEATURELIST2");
   }
   else
   {
      DLOG(0,0,"startProcessing: FEATURELIST2[%d]",atoi(l_featurelist2.c_str()));
   }
   m_featureList2 = atoi(l_featurelist2.c_str());

   string l_IDRFlag= ConfigReader::readValue(m_DataString, "IDR_FLAGS");
   if(1 > (atoi(l_IDRFlag.c_str())))
   {
      CLOG(0,0,"Unknown IDR_FLAGS");
   }
   m_IdrFlag = atoi(l_IDRFlag.c_str());

   /*string l_supportedfeature1 = ConfigReader::readValue(m_DataString, "SUPP_FEATURE_LIST1");
     if(1 > l_supportedfeature1.length())
     {
     CLOG(0,0,"Unknown SUPP_FEATURE_LIST1");
     }
     m_supFeatureList1 = atoi(l_supportedfeature1.c_str());

     string l_supportedfeature2 = ConfigReader::readValue(m_DataString, "SUPP_FEATURE_LIST2");
     if(1 > l_supportedfeature2.length())
     {
     CLOG(0,0,"Unknown SUPP_FEATURE_LIST2");
     }
     m_supFeatureList2 = atoi(l_supportedfeature2.c_str());*/

   m_nodeTypeInd = NODETYPE_MME;

   handleDbQuery();
   return true;
}

bool CtxtLteUpdateLocationRequest::SendIdr()
{
   DLOG(0,0,"CtxtLteUpdateLocationRequest::SendIdr()");

   if(0 != mp_HssSubsData->m_ErrorCode_OUT)
   {
      CLOG(0,0,"DBRES failed so not initiating IDR ... returning from SendIdr");
      return false;
   }

   diameter::s6a_r10::InsertSubscriberDataRequest l_idrData;
   try
   {
      diameter::s6a_r10::InsertSubscriberDataRequest *l_temp = &l_idrData;
      AuthSessionState l_tempauthSessionState(AuthSessionState::NO_STATE_MAINTAINED);
      l_temp->setAuthSessionState(l_tempauthSessionState);

      OriginHost l_temporiginHost = diameter::base::OriginHost(mp_HssSubsData->m_HssOriginHost_OUT);
      l_temp->setOriginHost(l_temporiginHost);

      OriginRealm l_temporiginRealm(mp_HssSubsData->m_HssOriginRealm_OUT);
      l_temp->setOriginRealm(l_temporiginRealm);

      DestinationHost l_tempdestinationHost(m_MmeHost);
      l_temp->setDestinationHost(l_tempdestinationHost);

      DestinationRealm l_tempdestinationRealm(m_MmeRealm);
      l_temp->setDestinationRealm(l_tempdestinationRealm);


      UserName l_tempuserName(m_UlrImsi);
      LLOG(0,0,"CtxtLteUpdateLocationRequest: IDR IMSI: %s", m_UlrImsi);
      l_temp->setUserName(l_tempuserName);
      m_tdr.setString(TDR_INDEX_REQUEST_IMSI,m_UlrImsi);

      SubscriberStatus l_tempsubStatus(SubscriberStatus::SERVICEGRANTED);

      SubscriptionData sub;

      if(0 != m_IdrFlag)
      {
         LLOG(0,0,"IDR Flag: %d", m_IdrFlag);
         IDRFlags l_tempidrFlag(m_IdrFlag);
         l_temp->setIDRFlags(l_tempidrFlag);
         //m_tdr.setInteger(TDR_INDEX_SSM_NO_REP_TIMER, m_IdrFlag);
      }
      else
      {
         DLOG(0,0,"Not sending IDR Flags as it is disabled");
      }

      if(strlen(mp_HssSubsData->m_Msisdn_OUT) > 1)
      {
         m_tdr.setChar(TDR_INDEX_REQUEST_TYPE, 'M');
         m_tdr.setString(TDR_INDEX_REQUEST_MSISDN, mp_HssSubsData->m_Msisdn_OUT); 
         unsigned char l_BcdStnSr[20 + 1];
         memset(l_BcdStnSr,'\0',sizeof(l_BcdStnSr));
         int l_bcdLen = StringToBCD(l_BcdStnSr, (u8*)(mp_HssSubsData->m_Msisdn_OUT), strlen(mp_HssSubsData->m_Msisdn_OUT));

         string l_msisdn1;
         l_msisdn1.assign((char*)l_BcdStnSr, l_bcdLen);
         MSISDN msisdn(l_msisdn1);
         sub.setMSISDN(msisdn);
         LLOG_HEX(0,0,"IDR: SubscriptionData: Msisdn", l_BcdStnSr, l_bcdLen);
      }
      else
      {
         CLOG(0,0,"IDR: MSISDN not present in DB");
      }

      if(mp_HssSubsData->m_Odb_OUT > 0)
      {
         m_odbDataSend = true;
         LLOG(0,0,"IDR ODB: %d", mp_HssSubsData->m_Odb_OUT);
         m_modifyOdb = mp_HssSubsData->m_Odb_OUT;
         OperatorDeterminedBarring l_tempopDet(mp_HssSubsData->m_Odb_OUT);
         sub.setOperatorDeterminedBarring(l_tempopDet);
      }

      if(mp_HssSubsData->m_HplmnOdb_OUT > 0)
      {
         LLOG(0,0,"IDR HPLMN: %d", mp_HssSubsData->m_HplmnOdb_OUT);
         unsigned int hplm = mp_HssSubsData->m_HplmnOdb_OUT;
         if( 15 == hplm)
         {
            HPLMNODB _l_temphplmnodb(4);
            sub.setHPLMNODB(_l_temphplmnodb);
         }
         else if( 7 == hplm)
         {
            HPLMNODB _l_temphplmnodb(3);
            sub.setHPLMNODB(_l_temphplmnodb);
         }
         else if( 3 == hplm)
         {
            HPLMNODB _l_temphplmnodb(2);
            sub.setHPLMNODB(_l_temphplmnodb);
         }
         else
         {
            HPLMNODB _l_temphplmnodb(1);
            sub.setHPLMNODB(_l_temphplmnodb);
         }
      }

      if((0 == mp_HssSubsData->m_Odb_OUT) && (0 == mp_HssSubsData->m_HplmnOdb_OUT))
      {
         m_odbDataSend = false;
         SubscriberStatus l_tempsubStatus(SubscriberStatus::SERVICEGRANTED);
         sub.setSubscriberStatus(l_tempsubStatus);
      }
      else
      {
         SubscriberStatus l_tempsubStatus(SubscriberStatus::OPERATORDETERMINEDBARRING);
         sub.setSubscriberStatus(l_tempsubStatus);
      }

      if(mp_HssSubsData->m_Nam_OUT > 0)
      {
         LLOG(0,0,"IDR NAM: %d", mp_HssSubsData->m_Nam_OUT);
         if( 0 == mp_HssSubsData->m_Nam_OUT)
         {
            NetworkAccessMode l_tempnetAccess(NetworkAccessMode::PACKET_AND_CIRCUIT);
            sub.setNetworkAccessMode(l_tempnetAccess);
         }
         else if ( 2 == mp_HssSubsData->m_Nam_OUT)
         {
            NetworkAccessMode l_tempnetAccess(NetworkAccessMode::ONLY_PACKET);
            sub.setNetworkAccessMode(l_tempnetAccess);
         }
      }

      bool l_accessRestrictionSet = false;
      //if(mp_HssSubsData->m_AccessRestriction_OUT > 0)
      if((0 != g_LteMmConfigReaderObj->m_ULRAccessRestriction) && (1 == mp_HssSubsData->m_ims_service_flag_OUT) && (mp_HssSubsData->m_ImsProfId_OUT > 0))
      {
         LLOG(0,0,"Access Restriction Value from lte mm config [%d]",g_LteMmConfigReaderObj->m_ULRAccessRestriction);
         AccessRestrictionData l_tempard(g_LteMmConfigReaderObj->m_ULRAccessRestriction);
         sub.setAccessRestrictionData(l_tempard);
         m_tdr.setInteger(TDR_INDEX_SMSM_PRIORITY_FLAG, g_LteMmConfigReaderObj->m_ULRAccessRestriction); // 59th index
         l_accessRestrictionSet = true;
      }
      else if( (786 != mp_HssSubsData->m_AccessRestriction_OUT) && (0 != mp_HssSubsData->m_AccessRestriction_OUT) )
      {
         unsigned char l_convAccRes = 0x00;
         unsigned char l_old = mp_HssSubsData->m_AccessRestriction_OUT;
         for(int i=0;i<8;i++)
            l_convAccRes |= ((l_old>>i) & 1)<<(7-i);
         LLOG(0,0,"IDR: AccessRestriction[%d] ConvertedValue[%d]",mp_HssSubsData->m_AccessRestriction_OUT,l_convAccRes);
         AccessRestrictionData l_tempard(l_convAccRes);
         sub.setAccessRestrictionData(l_tempard);
         m_tdr.setChar(TDR_INDEX_SMSM_PRIORITY_FLAG, l_convAccRes);
      }
      LLOG(0,0,"IDR: Odb[%u] Hplmn-Odb[%u] AccessRestriction[%d]",mp_HssSubsData->m_Odb_OUT,mp_HssSubsData->m_HplmnOdb_OUT,mp_HssSubsData->m_AccessRestriction_OUT);

      LteConfigProf* l_lteConfigProf = NULL;
      int l_LetProfId = mp_HssSubsData->m_LteConfigProfId_OUT;
      DLOG(0,0,"IDR: Lte Profile Id [%d]",l_LetProfId);
      if(0 == mp_HssSubsData->m_PartnerNkId_OUT)
      {
         LLOG(0,0,"IDR: Partner Network Id is 0, not checking for mapped Partner LteProfileId");
         mp_HssSubsData->m_LteConfigProfId_OUT = l_LetProfId;
      }
      else
      {
         TLOG(0,0,"IDR: Partner Network Id is not 0, checking for mapped partnerLteProfId");
         int l_tempPartLetProfId = getPartnerLteProfId(l_LetProfId,mp_HssSubsData->m_NetworkId_OUT,mp_HssSubsData->m_PartnerNkId_OUT);
         if(0 != l_tempPartLetProfId)
         {
            LLOG(0,0,"IDR: Partner LTE Profile found[%d]",l_tempPartLetProfId);
            mp_HssSubsData->m_LteConfigProfId_OUT = l_tempPartLetProfId;
         }
         else
         {
            mp_HssSubsData->m_LteConfigProfId_OUT = l_LetProfId;
            WLOG(0,0,"IDR: Partner LTE Profile Not found, using [%d]",l_LetProfId);
         }
      }
      l_lteConfigProf = g_spdPtr->m_hssProfile->getLteConfigProfDetailsPtr(mp_HssSubsData->m_LteConfigProfId_OUT);
      if(NULL != l_lteConfigProf)
      {
         if(false == l_accessRestrictionSet)
         {
            if( (1 == l_lteConfigProf->m_LteConfigProfStruct.m_Override5gNsaFeature) && (0 < l_lteConfigProf->m_LteConfigProfStruct.m_AccessRestrictionValue) )
            {
               LLOG(0,0,"Access Restriction Value from lte Profile [%d]",l_lteConfigProf->m_LteConfigProfStruct.m_AccessRestrictionValue);
               AccessRestrictionData l_tempard(l_lteConfigProf->m_LteConfigProfStruct.m_AccessRestrictionValue);
               sub.setAccessRestrictionData(l_tempard);
               m_tdr.setInteger(TDR_INDEX_SMSM_PRIORITY_FLAG, l_lteConfigProf->m_LteConfigProfStruct.m_AccessRestrictionValue); // 59th index
            }
            else
            {
               LLOG(0,0,"Either Override5gNsaFeature is not set or AccessRestrictionValue is not set in Lte profile");
            }
         }
         //FillSubscriptionData(l_lteConfigProf, l_subscriptionData);
         if( l_lteConfigProf->m_LteConfigProfStruct.m_feature_list_seq_id_1  > 0 )
         {
            HssFeatureList* l_hssFeatureList1 = NULL;
            l_hssFeatureList1 = g_spdPtr->m_hssProfile->getHssFeatureListPtr(l_lteConfigProf->m_LteConfigProfStruct.m_feature_list_seq_id_1);
            if(NULL != l_hssFeatureList1)
            {
               if(l_hssFeatureList1->m_featureListValue > 0)
               {
                  SupportedFeatures l_SupportedFeatures;
                  VendorId l_VendorId(10415);
                  l_SupportedFeatures.setVendorId(l_VendorId);
                  FeatureListID l_FeatureListID(1);
                  l_SupportedFeatures.setFeatureListID(l_FeatureListID);
                  FeatureList l_FeatureList(l_hssFeatureList1->m_featureListValue);
                  l_SupportedFeatures.setFeatureList(l_FeatureList);
                  l_temp->addSupportedFeatures(l_SupportedFeatures);
                  LLOG(0,0,"IDR: FeatureList1[%u]",l_hssFeatureList1->m_featureListValue);
                  m_tdr.setUnsignedInteger(TDR_INDEX_LOCAL_SUPP_FEATURE_1,l_hssFeatureList1->m_featureListValue);
               }
               else
               {
                  TLOG(0,0,"IDR: FeatureList1[%u] not sending",l_hssFeatureList1->m_featureListValue);
               }
            }
         }

         if( (l_lteConfigProf->m_LteConfigProfStruct.m_feature_list_seq_id_2  > 0) && (mp_HssSubsData->m_S6aRelease_OUT >= 12) )
         {
            HssFeatureList* l_hssFeatureList2 = NULL;
            l_hssFeatureList2 = g_spdPtr->m_hssProfile->getHssFeatureListPtr(l_lteConfigProf->m_LteConfigProfStruct.m_feature_list_seq_id_2);
            if(NULL != l_hssFeatureList2)
            {
               if(l_hssFeatureList2->m_featureListValue > 0)
               {
                  SupportedFeatures l_SupportedFeatures;
                  VendorId l_VendorId(10415);
                  l_SupportedFeatures.setVendorId(l_VendorId);
                  FeatureListID l_FeatureListID(2);
                  l_SupportedFeatures.setFeatureListID(l_FeatureListID);

                  u32 l_modified_f2 = 0;
                  l_modified_f2 = l_hssFeatureList2->m_featureListValue;
                  if(l_modified_f2 & F2_NR_AS_SECONDARY_RAT)
                  {
                     m_hlr_5gSupportFlag = true;
                     LLOG(0,0,"IDR: HLR supports NR_AS_SECONDARY_RAT flag[%d] and .. MME NR_AS_SECONDARY_RAT flag[%d]",m_hlr_5gSupportFlag,m_5gSupportFlag);
                     if(false == m_5gSupportFlag)
                     {
                        l_modified_f2 = 0;
                        l_modified_f2 = (l_hssFeatureList2->m_featureListValue) & (~F2_NR_AS_SECONDARY_RAT);
                        LLOG(0,0,"IDR: Not Sending NR_AS_SECONDARY_RAT as MME not supporting..Modified FeatureList2[%u]",l_modified_f2);
                     }
                  }
                  if(l_modified_f2 > 0)
                  {
                     FeatureList l_FeatureList(l_modified_f2);

                     l_SupportedFeatures.setFeatureList(l_FeatureList);
                     l_temp->addSupportedFeatures(l_SupportedFeatures);
                     LLOG(0,0,"IDR: FeatureList2[%u]",l_modified_f2);
                     m_tdr.setUnsignedInteger(TDR_INDEX_LOCAL_SUPP_FEATURE_2,l_hssFeatureList2->m_featureListValue);
                  }
                  else
                  {
                     LLOG(0,0,"IDR: FeatureList2 NOT sending as Modified value is zero");
                  }
               }
               else
               {
                  TLOG(0,0,"IDR: FeatureList2[%u] not sending",l_hssFeatureList2->m_featureListValue);
               }
            }
         }
         FillSubscriptionData(l_lteConfigProf, sub);
      }
      else
      {
         LLOG(0,0,"LTE Config Profile Details not found");
      }

      l_temp->setSubscriptionData(sub);
   }
   catch (NoSuchAttributeException e)
   {
      ELOG(0,1,"ERROR!! Exception NoSuchAttributeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EXCEPTION_OCCURRED);
      return false;
   }
   catch (WrongCommandTypeException e)
   {
      ELOG(0,1,"ERROR!! Exception WrongCommandTypeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EXCEPTION_OCCURRED);
      return false;
   }
   catch (UnknownTypeException e)
   {
      ELOG(0,1,"ERROR!! Exception UnknownTypeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EXCEPTION_OCCURRED);
      return false;
   }
   catch (CodecException e)
   {
      ELOG(0,1,"ERROR!! Exception CodecException Caught: %s ,Error Cause: %s ",e.name(), e.what());
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EXCEPTION_OCCURRED);
      return false;
   }
   catch(...)
   {
      LLOG(0,0,"Filling IDR throwing Exceptions");
      CLOG(0,0,"Exception occurred while calling FillIDR");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EXCEPTION_OCCURRED);
      return false;
   }

   unsigned int sIdx;
   string sessIdString;
   if(false == g_esc.allocateSession(DIAM_APP_ID_S6A_S6D,
            sIdx,
            sessIdString))
   {
      ELOG(0,1,"CtxtLteUpdateLocationRequest: Unable to allocate a session");
      m_tdr.setString(TDR_ERROR_UNABLE_TO_INITIATE, "Unable to allocate a session");
      return false;
   }
   DiameterMsg l_idr((char *)sessIdString.c_str(),DIAM_EVENT_REQUEST,DIAM_COMM_CODE_S6A_S6D_S7A_S7D_IDR_IDA);

   l_idrData.setSessionId(diameter::base::SessionId(sessIdString));
   l_idrData.setSessionIndex(sIdx);

   ITS_UINT l_idx = l_idrData.getSessionIndex();
   LLOG(0,0,"CtxtLteUpdateLocationRequest: IDR Session Id : %d", l_idx);

   l_idr.m_cmd = &l_idrData;
   g_esc.sendMsg(this, &l_idr);
   return true;
}

bool CtxtLteUpdateLocationRequest::requireSendCancelLoc(InsertSubscriberDataAnswer *p_answer)
{
   LLOG(0,0,"Checking for Cancel Location require to send");
   int l_countSupportedFeatures = 0;

   l_countSupportedFeatures = p_answer->countSupportedFeatures();
   if( 0 == l_countSupportedFeatures)
   {
      LLOG(0,0,"requireSendCancelLoc MME not supporting feature list of Operator Determined Barring");
      return true;
   }

   for(int l_count = 0 ; l_count < l_countSupportedFeatures; l_count++)
   {
      SupportedFeatures l_suppFeatures = p_answer->getSupportedFeatures(l_count);
      unsigned int l_respfeatureId = (l_suppFeatures.getFeatureListID()).value();
      unsigned int l_respfeatureList = (l_suppFeatures.getFeatureList()).value();
      unsigned int  l_venderId = (l_suppFeatures.getVendorId()).value();
      LLOG(0,0,"Feature Id[%u] Feature List [%u] Vender Id [%u]", l_respfeatureId, l_respfeatureList, l_venderId);
      if(VENDOR_FEATURE_ID != l_venderId)
      {
         WLOG(0,0,"MM is Sending MME fetaure list on Vender Id [%u]",l_venderId);
         continue;
      }
      if( 1 == l_respfeatureId)
      {
         if(m_modifyOdb & F1_ODB_ALL_APN)
         {
            if(!(l_respfeatureList & F1_ODB_ALL_APN))
            {
               LLOG(0,0,"requireSendCancelLoc MME not supporting feature of list F1_ODB_ALL_APN");
               return true;
            }
         }
         if( m_modifyOdb & F1_ODB_HPLMN_APN)
         {
            if(!(l_respfeatureList & F1_ODB_HPLMN_APN))
            {
               LLOG(0,0,"requireSendCancelLoc MME not supporting feature list of F1_ODB_HPLMN_APN");
               return true;
            }
         }
         if( m_modifyOdb & F1_ODB_VPLMN_APN)
         {
            if(!(l_respfeatureList & F1_ODB_VPLMN_APN))
            {
               LLOG(0,0,"requireSendCancelLoc MME not supporting feature list of F1_ODB_VPLMN_APN");
               return true;
            }
         }
         else if( m_modifyOdb & F1_ODB_ALL_OG)
         {
            if(!(l_respfeatureList & F1_ODB_ALL_OG))
            {
               LLOG(0,0,"requireSendCancelLoc MME not supporting feature list of F1_ODB_ALL_OG");
               return true;
            }
         }
         if( m_modifyOdb & F1_ODB_ALL_InternationalOG)
         {
            if(!(l_respfeatureList & F1_ODB_ALL_InternationalOG))
            {
               LLOG(0,0,"requireSendCancelLoc MME not supporting feature list of F1_ODB_ALL_InternationalOG");
               return true;
            }
         }
         if( m_modifyOdb & F1_ODB_ALL_InternationalOG_NotToHPLMNCountry)
         {
            if(!(l_respfeatureList & F1_ODB_ALL_InternationalOG_NotToHPLMNCountry))
            {
               LLOG(0,0,"requireSendCancelLoc MME not supporting feature list of F1_ODB_ALL_InternationalOG_NotToHPLMNCountry");
               return true;
            }
         }
         if( m_modifyOdb & F1_ODB_ALL_InterzonalOG)
         {
            if(!(l_respfeatureList & F1_ODB_ALL_InterzonalOG))
            {
               LLOG(0,0,"requireSendCancelLoc MME not supporting feature list of F1_ODB_ALL_InterzonalOG");
               return true;
            }
         }
         if( m_modifyOdb & F1_ODB_ALL_InterzonalOG_NotToHPLMNCountry)
         {
            if(!(l_respfeatureList & F1_ODB_ALL_InterzonalOG_NotToHPLMNCountry))
            {
               LLOG(0,0,"requireSendCancelLoc MME not supporting feature list of F1_ODB_ALL_InterzonalOG_NotToHPLMNCountry");
               return true;
            }
         }
         if( m_modifyOdb & F1_ODB_ALL_InterzonalOG_And_InternationalOG_NotToHPLMNCountry)
         {
            if(!(l_respfeatureList & F1_ODB_ALL_InterzonalOG_And_InternationalOG_NotToHPLMNCountry))
            {
               LLOG(0,0,"requireSendCancelLoc MME not supporting feature list of F1_ODB_ALL_InterzonalOG_And_InternationalOG_NotToHPLMNCountry");
               return true;
            }
         }
      }
      if(10415 != l_venderId)
         true;
   }
   return false;
}

