#include <LteMmSimulator.h>
#include <stdio.h>
#include <MapMessages.h>
#include <ServiceCoordinator.h>
#include <ExtendedServiceCoordinator.h>
#include <Logger.h>
#include <DataUnion.h>
#include <DbActiveObject.h>
#include <Utilities.h>
#include <LteCommonDefines.h>
#include <LteMmConfigReader.h>
#include <LteMmSimConfigReader.h>
#include <Utilities.h>

#include <DiameterConstants.h>
//#include <s6a_r10_stats.h>
#include <DiametriqInterface.h>


HssSimMmUpdateLocation :: HssSimMmUpdateLocation()
{
   DLOG(0, 0, "HssSimMmUpdateLocation::HssSimMmUpdateLocation()");
}

HssSimMmUpdateLocation :: ~HssSimMmUpdateLocation()
{
   DLOG(0, 0, "HssSimMmUpdateLocation::~HssSimMmUpdateLocation()");
}

bool HssSimMmUpdateLocation :: startProcessing()
{
   DLOG(0,0, "HssSimMmUpdateLocation startprocessing");
   LLOG(0,0,"selfSimulate: ULR");
   unsigned int sIdx;
   string sessIdString;
   if(false == g_esc.allocateSession(DIAM_APP_ID_S6A_S6D, 
            sIdx, 
            sessIdString))
   {
      ELOG(0,1,"Unable to allocate a session");
      return false;
   }

   //cout<<"--- sessionIDint---"<<sIdx<<endl<<"--- sessionIDstring ---"<<sessIdString<<endl;

   DiameterMsg l_test((char*)sessIdString.c_str(), DIAM_EVENT_REQUEST, DIAM_COMM_CODE_S6A_S6D_ULR_ULA);

   //Prepare ULR Message
   s6a_r10::UpdateLocationRequest *l_ulr = new s6a_r10::UpdateLocationRequest;
   l_ulr->setSessionId(base::SessionId(sessIdString));
   l_ulr->setSessionIndex(sIdx);


   AuthSessionState l_authSessionState(AuthSessionState::NO_STATE_MAINTAINED);
   l_ulr->setAuthSessionState(l_authSessionState);

   OriginHost l_originHost = base::OriginHost(g_OtherConfigData->m_dcd.m_originHost);
   l_ulr->setOriginHost(l_originHost);

   OriginRealm l_originRealm(g_OtherConfigData->m_dcd.m_originRealm);
   l_ulr->setOriginRealm(l_originRealm);

   DestinationRealm l_destinationRealm(g_OtherConfigData->m_dcd.m_destinationRealm);
   l_ulr->setDestinationRealm(l_destinationRealm);

   DestinationHost l_destinationHost(g_OtherConfigData->m_dcd.m_destinationHost);
   l_ulr->setDestinationHost(l_destinationHost);

   //UserName l_userName("123456789987654");
   UserName l_userName(g_LteMmSimConfigReaderObj->m_UlrImsi);
   l_ulr->setUserName(l_userName);

   ULRFlags l_ulrFlag(g_LteMmSimConfigReaderObj->m_UlrFlags);
   l_ulr->setULRFlags(l_ulrFlag);

   //VisitedPLMNId l_vplmnId("456");
   VisitedPLMNId l_vplmnId(g_LteMmSimConfigReaderObj->m_VplmnId);
   l_ulr->setVisitedPLMNId(l_vplmnId);

   //RATType l_ratType(RATType::GERAN);
   RATType l_ratType((RATType::Value)g_LteMmSimConfigReaderObj->m_RatType);
   l_ulr->setRATType(l_ratType);

   VendorSpecificApplicationId l_vendorSpecAppId1;
   VendorId l_vendorId(10415);
   l_vendorSpecAppId1.addVendorId(l_vendorId);
   l_ulr->setVendorSpecificApplicationId(l_vendorSpecAppId1);

   SupportedFeatures l_suppFeatures;
   VendorId l_vendorIdSup(10415);
   l_suppFeatures.setVendorId(l_vendorIdSup);
   FeatureListID l_featureListId(1);
   l_suppFeatures.setFeatureListID(l_featureListId);
   unsigned int l_flV = g_LteMmSimConfigReaderObj->m_SuppFeature1;
   FeatureList l_featurList(l_flV);
   l_suppFeatures.setFeatureList(l_featurList);
   l_ulr->addSupportedFeatures(l_suppFeatures);


   SupportedFeatures l_suppFeatures2;
   VendorId l_vendorIdSup2(10415);
   l_suppFeatures2.setVendorId(l_vendorIdSup2);
   FeatureListID l_featureListId2(2);
   l_suppFeatures2.setFeatureListID(l_featureListId2);
   unsigned int l_flV2 = g_LteMmSimConfigReaderObj->m_SuppFeature2;
   FeatureList l_featurList2(l_flV2);
   l_suppFeatures2.setFeatureList(l_featurList2);
   l_ulr->addSupportedFeatures(l_suppFeatures2);



   TerminalInformation l_terminalInfo;
   //S6a3GPP2MEID l_meid("11223344");
   S6a3GPP2MEID l_meid(g_LteMmSimConfigReaderObj->m_Meid);
   l_terminalInfo.setS6a3GPP2MEID(l_meid);
   l_ulr->setTerminalInformation(l_terminalInfo);



   /*<avp name="Active-APN">
     <avp name="Context-Identifier" value="145"></avp>
     <avp name="Service-Selection" value="gtmobile*.edu.com"></avp>
     <avp name="MIP6-Agent-Info" value="123.145.133.14"></avp>
     <avp name="Visited-Network-Identifier" value="mnc91.mcc984.3gppnetwork.in"></avp>
     <avp name="Specific-APN-Info">
     <avp name="Service-Selection" value="gtmobile*.edu.com"></avp>
     <avp name="MIP6-Agent-Info">
     <avp name="MIP-Home-Agent-Address" value="111.222.333.444"></avp>
     <avp name="MIP-Home-Agent-Host" value="epc.mnc44.mcc844.3gppnetwork.org"></avp>
     </avp>
     <avp name="Visited-Network-Identifier" value="mnc91.mcc984.3gppnetwork.in"></avp>
     </avp>*/



   //void addActiveAPN(const ActiveAPN &avp);
   if( 1 == g_LteMmSimConfigReaderObj->m_ActiveApnRequired )
   {
      ActiveAPN l_actApn;
      ContextIdentifier l_ctxId(145);
      l_actApn.setContextIdentifier(l_ctxId);
      ServiceSelection l_servSelapn("gtmobile*.edu.com");
      l_actApn.setServiceSelection(l_servSelapn);

      SpecificAPNInfo l_specApn;
      ServiceSelection l_servSel("gtmobile*.edu.com");
      l_specApn.setServiceSelection(l_servSel);
      MIP6AgentInfo l_specMip6AgentInfo;
      Address l_specMipHA1(Address::IPV4,"192.168.151.74");
      MIPHomeAgentAddress l_specMipHomeAgentAddr1(l_specMipHA1);
      l_specMip6AgentInfo.addMIPHomeAgentAddress(l_specMipHomeAgentAddr1);
      MIPHomeAgentHost l_specMipHomeAgentHost;
      l_specMipHomeAgentHost.setDestinationRealm(base::DestinationRealm("destRealm"));
      l_specMipHomeAgentHost.setDestinationHost(base::DestinationHost("destHost"));
      l_specMip6AgentInfo.setMIPHomeAgentHost(l_specMipHomeAgentHost);
      l_specApn.setMIP6AgentInfo(l_specMip6AgentInfo);
      l_actApn.addSpecificAPNInfo(l_specApn);

      l_ulr->addActiveAPN(l_actApn);
   }

   l_test.m_cmd = l_ulr;
   l_test.m_allocatedFlag = true;

   g_esc.sendMsg(this, &l_test);

   return true;
}

bool HssSimMmUpdateLocation :: processMessage(Msg *p_MsgPtr,bool &p_DeleteFlag)
{
   DLOG(0, 0, "Start of HssSimMmUpdateLocation::processMsg function Delete flag is %d",p_DeleteFlag);
   MapSpecificMsg *l_specMsg = NULL;

   switch (p_MsgPtr->m_MsgType)
   {
      case MSG_TYPE_MAP:
         {
            DLOG(0,0,"MAP message received");
         }
         break;

      case MSG_TYPE_DIAMETER:
         {
            DiameterMsg *l_dm = (DiameterMsg*)p_MsgPtr;
            if(NULL == l_dm->m_cmd)
            {
               CLOG(0,0,"Received Diameter Message is NULL");
               break;
            }
            switch(l_dm->m_commandCode)
            {
               case DIAM_COMM_CODE_S6A_S6D_ULR_ULA:
                  {
                     LLOG(0,0,"Diameter Message ULR received");
                  }
                  break;
               default:
                  {
                     CLOG(0,0,"Unknown Message[%d] Received",l_dm->m_commandCode);
                  }
                  break;
            }
         }
         break;

      case MSG_TYPE_DB:
         {
            DLOG(0, 0, "DB message received");
            if(1 == ((DbQueryMsg*)p_MsgPtr)->m_DbQueryType)
            {
               LLOG(0,0,"DBRES: Type:1");
            }
            else
            {
               ELOG(0,0,"Unknown DB message");
            }
         }
         break;

      default:
         ELOG(0, 0, "Unknown message received");
         break;

   }
   return true;
}
