#include "Slh_Routing_request.h"
#include <stdio.h>
#include <MapMessages.h>
#include <ServiceCoordinator.h>
#include <ExtendedServiceCoordinator.h>
#include <Logger.h>
#include <DataUnion.h>
#include <DbActiveObject.h>
#include <Utilities.h>
#include <LteCommonDefines.h>
#include <LteMmConfigReader.h>
#include <Utilities.h>
#include <SnmpInterface.h>

#include <DiameterConstants.h>
#include <DiametriqInterface.h>


using namespace diameter::slh_rel_10;

void set_SlhMmename(char *mmehost, char *mmename, char *mmerealm,char* slh_MmeNname)
{
   if(!strstr(mmehost,mmerealm))
   {
      LLOG(0,0,"\n host name not matched with realm..!!");
      strcpy(slh_MmeNname,mmehost);
   }
   else
   {
      char final[SLH_MME_NAME_LEN +1];
      memset(final,'\0',sizeof(final));
      char *l_match = strstr(mmehost,mmerealm);
      int len = l_match - mmehost ;
      snprintf(final,len+1,mmehost);
      sprintf(slh_MmeNname,"%s%s",final,mmename);
   }

}

/* Constructor for class SLH_routing_info */
SLH_routing_info::SLH_routing_info()
{
   DLOG(0, 0, "SLH_routing_info::SLH_routing_info() ---constuctor---");
   memset(m_LcsIMSI,'\0',sizeof(m_LcsIMSI));
   memset(m_LcsMSISDN,'\0',sizeof(m_LcsMSISDN));
   memset(m_GmlcNumber,'\0',sizeof(m_GmlcNumber));
   memset(m_LcsLMSI,'\0',sizeof(m_LcsLMSI));
   memset(m_MmeName,'\0',sizeof(m_MmeName));
   memset(m_MmeHost,'\0',sizeof(m_MmeHost));
   memset(m_MmeRealm,'\0',sizeof(m_MmeRealm));
   memset(m_GmlcAddress,'\0',sizeof(m_GmlcAddress));
   memset(m_MSCnumber,'\0',sizeof(m_MSCnumber));
   memset(m_SGSNnumber,'\0',sizeof(m_SGSNnumber));
   memset(m_OrigHost,'\0',sizeof(m_OrigHost));
   memset(m_OrigRealm,'\0',sizeof(m_OrigRealm));
   m_MessagePtr = NULL;
   m_slh_usrData = NULL;
   YES_IMSI = false;
}


/* Destructor for class SLH_routing_info */
SLH_routing_info::~SLH_routing_info()
{
   DLOG(0, 0, "SLH_routing_info::~SLH_routing_info()");
   if(NULL != m_MessagePtr)
   {
      delete m_MessagePtr;
      m_MessagePtr = NULL;
   }

   if(NULL != m_slh_usrData)
   {
      delete m_slh_usrData;
      m_slh_usrData = NULL;
   }

}

/* Checks the RIR request and fills the class SLH_routing_info values for futher move */
bool SLH_routing_info::check_RIR()
{
   diameter::slh_rel_10::LCSRoutingInfoRequest l_slhRequest(*(diameter::CommandImpl*)((DiameterMsg*)m_MessagePtr)->m_cmd);
   diameter::slh_rel_10::LCSRoutingInfoRequest * l_slhReq = &l_slhRequest; 

   /* copying session id from RIR request */
   LLOG(0,0,"SLH RIR: SessionIndex[%d] Session[%s] OrigHost[%s] OrigRealm[%s]", l_slhReq->getSessionIndex(),(char*)l_slhReq->getSessionId().value().c_str(),(char*)l_slhReq->getOriginHost().value().c_str(),(char*)l_slhReq->getOriginRealm().value().c_str());

   /* copying Username from RIR request */
   if( true == l_slhReq->containsUserName())
   {
      if(15 != l_slhReq->getUserName().value().size())
      {
         WLOG(0,0,"SLH IMSI len %d is not 15 digits", l_slhReq->getUserName().value().size());
         return false;
      }

      strcpy(m_LcsIMSI,(char*)l_slhReq->getUserName().value().c_str());
      LLOG(0,0,"RIR received with username (IMSI): [%s]",m_LcsIMSI);
      YES_IMSI = true;
      m_tdr.setChar(TDR_INDEX_REQUEST_TYPE, 'I');
      m_tdr.setString(TDR_INDEX_REQUEST_IMSI, m_LcsIMSI);
   }

   /* copying MSISDN from RIR request */
   else if( true == l_slhReq->containsMSISDN())
   {
      BCDToString((u8*)m_LcsMSISDN, (u8*)l_slhReq->getMSISDN().value().c_str(), l_slhReq->getMSISDN().value().size()) ;
      YES_IMSI = false;
      LLOG(0,0,"RIR received with MSISDN: [%s]",m_LcsMSISDN);
      m_tdr.setChar(TDR_INDEX_REQUEST_TYPE, 'M');
      m_tdr.setString(TDR_INDEX_REQUEST_IMSI, m_LcsMSISDN);
   }
   else
   {
      CLOG(0,0,"MSISDN and IMSI(username) missing in RIR");
      return false;
   }

   /* copying Destination host to form HSS origin host */
   if( true == l_slhReq->containsDestinationHost())
   {
      strcpy(m_OrigHost, (char*)l_slhReq->getDestinationHost().value().c_str());
      LLOG(0,0,"RIR received with Destination Host: [%s]",m_OrigHost);
   }

   /* copying Destination realm to form HSS origin realm */
   strcpy(m_OrigRealm, (char*)l_slhReq->getDestinationRealm().value().c_str());
   LLOG(0,0,"RIR received with Destination Realm: [%s]",m_OrigRealm);


   /* copying GMLSC number from RIR request */
   if(true == l_slhReq->containsGMLCNumber())
   {
      BCDToString((u8*)m_GmlcNumber, (u8*)l_slhReq->getGMLCNumber().value().c_str(), l_slhReq->getGMLCNumber().value().size()) ;
      LLOG(0,0,"RIR received with GMLC number : [%s]",m_GmlcNumber);
      m_tdr.setString(TDR_INDEX_ULR_GMLC_ADDERSS, m_GmlcNumber);
   }
   else
   {
      LLOG(0,0,"GMLC number is not present");
   }
   return true;

}

/* handling error responses */
bool SLH_routing_info::handleError(unsigned int aErrCode)
{
   DiameterMsg l_answer(((DiameterMsg*)m_MessagePtr)->m_sessionId, DIAM_EVENT_ANSWER, DIAM_COMM_CODE_SLH_RIR_RIA);
   slh_rel_10::LCSRoutingInfoAnswer l_RIA;
   try
   {
      l_RIA.setSessionIndex(((DiameterMsg*)m_MessagePtr)->m_sessionIndex);
      LLOG(0,0,"RIA Session index Added..!!");

      SessionId l_sid(((DiameterMsg*)m_MessagePtr)->m_sessionId);
      l_RIA.setSessionId(l_sid);
      LLOG(0,0,"RIA Session id added..!!");

      AuthSessionState l_authSs(AuthSessionState::NO_STATE_MAINTAINED);
      l_RIA.setAuthSessionState(l_authSs);
      LLOG(0,0,"RIA Session state added..!!");

      /* Adding origin Host */
      /*if(strlen(m_slh_usrData->d_HssOriginHost)<=1)
      {
         OriginHost l_originHost(m_OrigHost);
         l_RIA.setOriginHost(l_originHost);
         LLOG(0,0,"Sending RIA with Origination Host HLR_ORIGHOST: [%s]",m_OrigHost);
      }
      else
      {
         OriginHost l_originHost(m_slh_usrData->d_HssOriginHost);
         l_RIA.setOriginHost(l_originHost);
         LLOG(0,0,"Sending RIA with Origination Host HLR_ORIGHOST: [%s]",m_slh_usrData->d_HssOriginHost);
      }

      /// Adding origin Realm 
      if(strlen(m_slh_usrData->d_HssOriginRealm)<=1)
      {
         OriginRealm l_originRealm(m_OrigRealm);
         l_RIA.setOriginRealm(l_originRealm);
         LLOG(0,0,"Sending RIA for Origination Realm: [%s]",m_OrigRealm);
      }
      else
      {
         OriginRealm l_originRealm(m_slh_usrData->d_HssOriginRealm);
         l_RIA.setOriginRealm(l_originRealm);
         LLOG(0,0,"Sending RIA for Origination Realm: [%s]",m_slh_usrData->d_HssOriginRealm);
      }*/

      if(NULL != m_slh_usrData)
      {
         if(strlen(m_slh_usrData->d_HssOriginHost)<=1)
         {
            OriginHost l_originHost(m_OrigHost);
            l_RIA.setOriginHost(l_originHost);
            LLOG(0,0,"Sending RIA with Origination Host HLR_ORIGHOST: [%s]",m_OrigHost);
         }
         else
         {
            OriginHost l_originHost(m_slh_usrData->d_HssOriginHost);
            l_RIA.setOriginHost(l_originHost);
            LLOG(0,0,"Sending RIA with DB OriginHost[%s]",m_slh_usrData->d_HssOriginHost);
         }
         if(strlen(m_slh_usrData->d_HssOriginRealm)<=1)
         {
            OriginRealm l_originRealm(m_OrigRealm);
            l_RIA.setOriginRealm(l_originRealm);
            LLOG(0,0,"Sending RIA for Origination Realm: [%s]",m_OrigRealm);
         }
         else
         {
            OriginRealm l_originRealm(m_slh_usrData->d_HssOriginRealm);
            l_RIA.setOriginRealm(l_originRealm);
            LLOG(0,0,"Sending RIA with DB OriginRealm[%s]",m_slh_usrData->d_HssOriginRealm);
         }
      }
      else
      {
         OriginHost originHost("");
         OriginRealm originRealm("");
         l_RIA.setOriginHost(originHost);
         l_RIA.setOriginRealm(originRealm);
         TLOG(0,0,"DBresponse pointer null");
      }

      if(aErrCode == DIAM_RESULT_CODE_UNABLE_TO_COMPLY)
      {
         CLOG(0,1,"ErrorResp: SessionIndex[%d] Session[%s] ResultCode DIAM_RESULT_CODE_UNABLE_TO_COMPLY",((DiameterMsg*)m_MessagePtr)->m_sessionIndex,(char*)((DiameterMsg*)m_MessagePtr)->m_sessionId);
         ResultCode l_rc(aErrCode);
         l_RIA.setResultCode(l_rc);

      }

      else
      {
         LLOG(0,0,"ErrorResp: SessionIndex[%d] Session[%s] ExperimentalResultCode[%d]",((DiameterMsg*)m_MessagePtr)->m_sessionIndex,(char*)((DiameterMsg*)m_MessagePtr)->m_sessionId,aErrCode);

         ExperimentalResult l_experimentalResult;
         VendorId l_vendorId(10415);
         l_experimentalResult.setVendorId(l_vendorId);
         ExperimentalResultCode l_experimentalResultCode(aErrCode);
         l_experimentalResult.setExperimentalResultCode(l_experimentalResultCode);
         l_RIA.setExperimentalResult(l_experimentalResult);
      }

      l_answer.m_cmd = &l_RIA;

   }

   catch (NoSuchAttributeException e)
   {
      ELOG(0,1,"ERROR!! Exception NoSuchAttributeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EXCEPTION_OCCURRED);
      return false;
   }
   catch (WrongCommandTypeException e)
   {
      ELOG(0,1,"ERROR!! Exception WrongCommandTypeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EXCEPTION_OCCURRED);
      return false;
   }
   catch (UnknownTypeException e)
   {
      ELOG(0,1,"ERROR!! Exception UnknownTypeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EXCEPTION_OCCURRED);
      return false;
   }
   catch (CodecException e)
   {
      ELOG(0,1,"ERROR!! Exception CodecException Caught: %s ,Error Cause: %s ",e.name(), e.what());
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EXCEPTION_OCCURRED);
      return false;
   }
   catch (...)
   {
      CLOG(0,0,"Exception occurred while Sending Error");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EXCEPTION_OCCURRED);
      return false;
   }
   g_esc.sendMsg(this, &l_answer);
   m_tdr.setInteger(TDR_INDEX_ERR_CODE, aErrCode);
   return true;

}

/* Reply back with RIA success or error response */
bool SLH_routing_info::send_RIA()
{
   LLOG(0,0,"starting Send RIA ");
   DiameterMsg l_answer(((DiameterMsg*)m_MessagePtr)->m_sessionId, DIAM_EVENT_ANSWER, DIAM_COMM_CODE_SLH_RIR_RIA); 
   LLOG(0,0," successfully got Diameter message..!!");
   slh_rel_10::LCSRoutingInfoAnswer t_RIA;
   slh_rel_10::LCSRoutingInfoAnswer *l_RIA = &t_RIA;
   l_answer.m_cmd = l_RIA;
   LLOG(0,0," Assign ria request to l_anwer..!!");

   /* Framing RIA Response as per the diameter library */
   l_RIA->setSessionIndex(((DiameterMsg*)m_MessagePtr)->m_sessionIndex);
   LLOG(0,0,"RIA Session index Added..!!");

   SessionId l_sid(((DiameterMsg*)m_MessagePtr)->m_sessionId);
   l_RIA->setSessionId(l_sid);
   LLOG(0,0,"RIA Session id added..!!");

   AuthSessionState l_authSs(AuthSessionState::NO_STATE_MAINTAINED);
   l_RIA->setAuthSessionState(l_authSs);
   LLOG(0,0,"RIA Session state added..!!");


   /* Adding origin Host */
   if(strlen(m_slh_usrData->d_HssOriginHost)<=1)
   {
      OriginHost l_originHost(m_OrigHost);
      l_RIA->setOriginHost(l_originHost);
      LLOG(0,0,"Sending RIA with Origination Host HLR_ORIGHOST: [%s]",m_OrigHost);
   }
   else
   {
      OriginHost l_originHost(m_slh_usrData->d_HssOriginHost);
      l_RIA->setOriginHost(l_originHost);
      LLOG(0,0,"Sending RIA with Origination Host HLR_ORIGHOST: [%s]",m_slh_usrData->d_HssOriginHost);
   }

   /* Adding origin Realm */
   if(strlen(m_slh_usrData->d_HssOriginRealm)<=1)
   {
      OriginRealm l_originRealm(m_OrigRealm);
      l_RIA->setOriginRealm(l_originRealm);
      LLOG(0,0,"Sending RIA for Origination Realm: [%s]",m_OrigRealm);
   }
   else
   {
      OriginRealm l_originRealm(m_slh_usrData->d_HssOriginRealm);
      l_RIA->setOriginRealm(l_originRealm);
      LLOG(0,0,"Sending RIA for Origination Realm: [%s]",m_slh_usrData->d_HssOriginRealm);
   }



   if(false == YES_IMSI)
   {
      UserName l_username(m_slh_usrData->d_Act_imsi);
      l_RIA->setUserName(l_username);
      LLOG(0,0,"Sending RIA with Username(IMSI) : [%s]",m_slh_usrData->d_LcsIMSI_OUT);   
      m_tdr.setString(TDR_INDEX_MM_PRIMARY_IMSI, m_slh_usrData->d_LcsIMSI_OUT);
   }
   else
   {
      unsigned char l_Bcdmsisdn[HSS_MSISDN_LEN + 1];
      memset(l_Bcdmsisdn,'\0',sizeof(l_Bcdmsisdn));
      int l_bcdLen = StringToBCD(l_Bcdmsisdn, (u8*)(m_slh_usrData->d_Act_msisdn), strlen(m_slh_usrData->d_LcsMSISDN_OUT));
      string l_msisdn;
      l_msisdn.assign((char*)l_Bcdmsisdn, l_bcdLen);
      MSISDN final_msisdn(l_msisdn);
      l_RIA->setMSISDN(final_msisdn);
      LLOG_HEX(0,0,"RIA: Msisdn", l_Bcdmsisdn, l_bcdLen); 
      m_tdr.setString(TDR_INDEX_MM_PRIMARY_MSISDN, m_slh_usrData->d_LcsMSISDN_OUT);
   }

   /* Copying the result code */
   ResultCode l_resultCode(DIAM_RESULT_CODE_SUCCESS);
   l_RIA->setResultCode(l_resultCode);
   LLOG(0,0,"Sending RIA result DIAM_RESULT_CODE_SUCCESS");


   /* Adding LMSI */
   if(m_slh_usrData->d_Lmsi_len>1)
   {
      if(m_slh_usrData->d_Lmsi_len ==4)
      {
         LMSI l_LMSI((char*)m_slh_usrData->d_LcsLMSI);
         l_RIA->setLMSI(l_LMSI);;
         LLOG_HEX(0,0,"RIA: Additional LMSI", m_slh_usrData->d_LcsLMSI, m_slh_usrData->d_Lmsi_len); 
      m_tdr.setHex(TDR_INDEX_LMSI,(s8*)m_slh_usrData->d_LcsLMSI,4);
      }
      else
      {
         LLOG(0,0,"LMSI is shorter than 8 characters..!!");
      }
   }

   /* Adding PPR address */
#if 0
   if(strlen(m_slh_usrData->d_PprAddress)>1)
   {
      Address l_pprAddress(Address::IPV4, m_slh_usrData->d_PprAddress) ;
      PPRAddress l_PPRadd(l_pprAddress);
      l_RIA->setPPRAddress(l_PPRadd);
      LLOG(0,0,"Sending RIA PPR address [%s]", m_slh_usrData->d_PprAddress);
   }
#endif

   /* Adding Serving Node details */
   ServingNode l_servenode;

   if(strlen(m_slh_usrData->d_MmeHost)>1)
   {
      /* setting MME name as serving node */
      char l_FinalMmeName[SLH_MME_NAME_LEN + 1];
      memset(l_FinalMmeName, '\0', sizeof(l_FinalMmeName));
      set_SlhMmename(m_slh_usrData->d_MmeHost, m_slh_usrData->d_MmeName, m_slh_usrData->d_MmeRealm,l_FinalMmeName);
      LLOG(0,0,"Parsed MME name [%s]..!!",l_FinalMmeName);
      m_tdr.setString(TDR_INDEX_HLR_RESRV1, l_FinalMmeName);
      MMEName l_mmename(l_FinalMmeName);
      l_servenode.setMMEName(l_mmename);
      l_RIA->setServingNode(l_servenode);

      if(strlen(m_slh_usrData->d_MmeRealm) > 1)
      {
         MMERealm l_mmerealm(m_slh_usrData->d_MmeRealm);
         l_servenode.setMMERealm(l_mmerealm);
      }

#if 0
      /* Adding LCS Capability Set */
      if(m_slh_usrData->d_LcsCAPset > 0)
      {
         LCSCapabilitiesSets l_lCapSet(m_slh_usrData->d_LcsCAPset);
         l_servenode.setLCSCapabilitiesSets(l_lCapSet);
         LLOG(0,0,"Sending RIA for Serving Node LCapability set : [%d]",m_slh_usrData->d_LcsCAPset);

      }
      /* Adding GMLC address */
      if(strlen(m_slh_usrData->d_GmlcAddress)>1)
      {
         Address l_gmlcAddress(Address::IPV4, m_slh_usrData->d_GmlcAddress) ;
         GMLCAddress l_GMLCadd(l_gmlcAddress);
         l_RIA->setGMLCAddress(l_GMLCadd);
         LLOG(0,0,"Sending RIA for Serving Node GMLC address [%s]", m_slh_usrData->d_GmlcAddress);
      }
#endif
      LLOG(0,0,"Sending RIA for Serving Node (MME_NAME) : [%s]",l_FinalMmeName);
      LLOG(0,0,"Sending RIA for Serving Node (MME_HOST) : [%s]",m_slh_usrData->d_MmeHost);
      LLOG(0,0,"Sending RIA for Serving Node (MME_REALM) : [%s]",m_slh_usrData->d_MmeRealm);

      if(strlen(m_slh_usrData->d_MSCnumber)>1)
      {
         AdditionalServingNode l_addServnode;
         unsigned char l_BcdMsc[20];
         memset(l_BcdMsc,'\0',sizeof(l_BcdMsc));
         int l_bcdLen = StringToBCD(l_BcdMsc, (u8*)(m_slh_usrData->d_MSCnumber), strlen(m_slh_usrData->d_MSCnumber));
         string l_mscnumber;
         l_mscnumber.assign((char*)l_BcdMsc, l_bcdLen);
         MSCNumber MSC_number(l_mscnumber);
         l_addServnode.setMSCNumber(MSC_number);
         LLOG_HEX(0,0,"RIA: Additional Serving Node MSC", l_BcdMsc, l_bcdLen); 
         m_tdr.setString(TDR_INDEX_MSC_ADDRESS, m_slh_usrData->d_MSCnumber);

         //LCSCapabilitiesSets l_lCapSet(15);  // TODO take from DB, hardcoding to 15
         TLOG(0,0,"RIA: Supported LCS Set from DB[%d]",m_slh_usrData->d_SuppLcsCAPset);

         if(m_slh_usrData->d_SuppLcsCAPset > 0)
         {
            if( (m_slh_usrData->d_SuppLcsCAPset >> 3) & 0x01)
            {
               DLOG(0,0,"LCS PHASE 4");
               m_slh_usrData->d_SuppLcsCAPset = 4;
            }
            else if( (m_slh_usrData->d_SuppLcsCAPset >> 2) & 0x01)
            {
               DLOG(0,0,"LCS PHASE 3");
               m_slh_usrData->d_SuppLcsCAPset = 3;
            }
            else if( (m_slh_usrData->d_SuppLcsCAPset >> 1) & 0x01)
            {
               DLOG(0,0,"LCS PHASE 2");
               m_slh_usrData->d_SuppLcsCAPset = 2;
            }
            else
            {
               DLOG(0,0,"LCS PHASE 1");
               m_slh_usrData->d_SuppLcsCAPset = 1;
            }
            TLOG(0,0,"RIA: Highest Supported Phase of LCS Capbility |%d|",m_slh_usrData->d_SuppLcsCAPset);

            LCSCapabilitiesSets l_lCapSet(m_slh_usrData->d_SuppLcsCAPset);
            l_addServnode.setLCSCapabilitiesSets(l_lCapSet);
         }
         else
         {
            TLOG(0,0,"Supported LCS Set not present in DB");
         }
         //LLOG(0,0,"Sending RIA for Additional Serving Node LCapability set: 15");
         //LLOG(0,0,"Sending RIA for Additional Serving Node LCapability set: %d",m_slh_usrData->d_SuppLcsCAPset);
         l_RIA->addAdditionalServingNode(l_addServnode);
      }
   }
   else if(strlen(m_slh_usrData->d_SGSNnumber) > 1)
   {
      /* setting SGSN number as serving node */
      unsigned char l_BcdSgsn[HSS_SGSN_NUMBER_LEN + 1];
      memset(l_BcdSgsn,'\0',sizeof(l_BcdSgsn));
      int l_bcdLen = StringToBCD(l_BcdSgsn, (u8*)(m_slh_usrData->d_SGSNnumber), strlen(m_slh_usrData->d_SGSNnumber));
      string l_sgsnnumber;
      l_sgsnnumber.assign((char*)l_BcdSgsn, l_bcdLen);
      SGSNNumber SGSN_number(l_sgsnnumber);
      l_servenode.setSGSNNumber(SGSN_number);
      l_RIA->setServingNode(l_servenode);
      LLOG_HEX(0,0,"RIA: Serving Node: sgsnnumber", l_BcdSgsn, l_bcdLen); 
      m_tdr.setString(TDR_INDEX_SGSN_ADDRESS, m_slh_usrData->d_SGSNnumber);

#if 0
      /* Adding LCS Capability Set */
      if(m_slh_usrData->d_LcsCAPset > 0)
      {
         LCSCapabilitiesSets l_lCapSet(m_slh_usrData->d_LcsCAPset);
         l_servenode.setLCSCapabilitiesSets(l_lCapSet);
         LLOG(0,0,"Sending RIA for Serving Node LCapability set : [%d]",m_slh_usrData->d_LcsCAPset);

      }

      /* Adding GMLC address */
      if(strlen(m_slh_usrData->d_GmlcAddress)>1)
      {
         Address l_gmlcAddress(Address::IPV4, m_slh_usrData->d_GmlcAddress) ;
         GMLCAddress l_GMLCadd(l_gmlcAddress);
         l_RIA->setGMLCAddress(l_GMLCadd);
         LLOG(0,0,"Sending RIA GMLC address [%s]", m_slh_usrData->d_GmlcAddress);
      }
#endif

      if(strlen(m_slh_usrData->d_MSCnumber)>1)
      {
         AdditionalServingNode l_addServnode;
         unsigned char l_BcdMsc[20];
         memset(l_BcdMsc,'\0',sizeof(l_BcdMsc));
         int l_bcdLen = StringToBCD(l_BcdMsc, (u8*)(m_slh_usrData->d_MSCnumber), strlen(m_slh_usrData->d_MSCnumber));
         string l_mscnumber;
         l_mscnumber.assign((char*)l_BcdMsc, l_bcdLen);
         MSCNumber MSC_number(l_mscnumber);
         l_addServnode.setMSCNumber(MSC_number);
         l_RIA->addAdditionalServingNode(l_addServnode);
         LLOG_HEX(0,0,"RIA: Additional Serving Node: msc", l_BcdMsc, l_bcdLen); 
         m_tdr.setString(TDR_INDEX_MSC_ADDRESS, m_slh_usrData->d_MSCnumber);
      }
   }
   else if(strlen(m_slh_usrData->d_MSCnumber)>1)
   {
      /* only setting MSC number as serving node */
      unsigned char l_BcdMsc[20];
      memset(l_BcdMsc,'\0',sizeof(l_BcdMsc));
      int l_bcdLen = StringToBCD(l_BcdMsc, (u8*)(m_slh_usrData->d_MSCnumber), strlen(m_slh_usrData->d_MSCnumber));
      string l_mscnumber;
      l_mscnumber.assign((char*)l_BcdMsc, l_bcdLen);
      MSCNumber MSC_number(l_mscnumber);
      l_servenode.setMSCNumber(MSC_number);
      l_RIA->setServingNode(l_servenode);
      LLOG_HEX(0,0,"RIA: Serving Node MSC", l_BcdMsc, l_bcdLen); 
      m_tdr.setString(TDR_INDEX_MSC_ADDRESS, m_slh_usrData->d_MSCnumber);

#if 0
      /* Adding LCS Capability Set */
      if(m_slh_usrData->d_LcsCAPset > 0)
      {
         LCSCapabilitiesSets l_lCapSet(m_slh_usrData->d_LcsCAPset);
         l_servenode.setLCSCapabilitiesSets(l_lCapSet);
         LLOG(0,0,"Sending RIA for Serving Node LCapability set : [%d]",m_slh_usrData->d_LcsCAPset);

      }

      /* Adding GMLC address */
      if(strlen(m_slh_usrData->d_GmlcAddress)>1)
      {
         Address l_gmlcAddress(Address::IPV4, m_slh_usrData->d_GmlcAddress) ;
         GMLCAddress l_GMLCadd(l_gmlcAddress);
         l_RIA->setGMLCAddress(l_GMLCadd);
         LLOG(0,0,"Sending RIA GMLC address [%s]", m_slh_usrData->d_GmlcAddress);
      }
#endif   
   }


   g_esc.sendMsg(this, &l_answer);
}



/* Prepares the DB query to be sent and executes it */
bool SLH_routing_info::handleSlhDbQuery()
{
#if 1
   Slh_db_data *t_slhUsrdata = NULL;
   t_slhUsrdata = new Slh_db_data;
   if(NULL != t_slhUsrdata)
   {
      strcpy(t_slhUsrdata->d_LcsIMSI,m_LcsIMSI);
      strcpy(t_slhUsrdata->d_LcsMSISDN,m_LcsMSISDN);
      strcpy(t_slhUsrdata->d_GMLCnumber,m_GmlcNumber);
      if(YES_IMSI == true)
         t_slhUsrdata->d_flag_type = 1;
      else
         t_slhUsrdata->d_flag_type = 2;

      LLOG(0,0,"SLH DB INPUT DATA- IMSI [%s], MSISDN [%s], GMLC number [%s], Flag type [%d] (NOTE: 1->imsi, 2->msisdn)", t_slhUsrdata->d_LcsIMSI, t_slhUsrdata->d_LcsMSISDN, t_slhUsrdata->d_GMLCnumber, t_slhUsrdata->d_flag_type);
   }

   else
   {
      CLOG(0,0,"Newing Slh_db_data failed");
   }
   TLOG(0,0,"Pushing data to DB");
   t_slhUsrdata->m_cb = this;
   t_slhUsrdata->m_DbQueryType = 1;

   g_act.execute(t_slhUsrdata);
   return true;
#endif

}

/* Receives the DB response to which further actions are performed  as per the result */
bool SLH_routing_info::handleSlhDBResponse()
{
   LLOG(0,0,"For SLH db response ERRORCODE [%d], ERROR_MESSAGE[%s]",m_slh_usrData->d_ErrorCode_OUT,m_slh_usrData->d_ErrorMsg_OUT);
   
   LLOG(0,0," SLH DB Responses- Username IMSI: [%s], Active IMSI: [%s], MSISDN: [%s], Active MSISDN [%s], LMSI: [%s]", m_slh_usrData->d_LcsIMSI_OUT, m_slh_usrData->d_Act_imsi, m_slh_usrData->d_LcsMSISDN_OUT, m_slh_usrData->d_Act_msisdn, m_slh_usrData->d_LcsLMSI);

   LLOG(0,0,"Serving Node- MME name :[%s], MME host name :[%s], MME realm :[%s], MSC number :[%s], LCS capability set :[%d], SGSN number :[%s], GMLC address :[%s]", m_slh_usrData->d_MmeName, m_slh_usrData->d_MmeHost, m_slh_usrData->d_MmeRealm, m_slh_usrData->d_MSCnumber, m_slh_usrData->d_SuppLcsCAPset, m_slh_usrData->d_SGSNnumber, m_slh_usrData->d_GmlcAddress);
   LLOG(0,0,"SLH origin host: [%s], SLH origin realm: [%s]",m_slh_usrData->d_HssOriginHost, m_slh_usrData->d_HssOriginRealm);


#if 1
   switch(m_slh_usrData->d_ErrorCode_OUT)
   {
      case 0:
         send_RIA();
         LLOG(0,0,"SLH Request Ready to send..!!");
         break;

      case 1:
         handleError(DIAM_EXP_RESULT_CODE_ERROR_USER_UNKNOWN);
         LLOG(0,0,"PERMANENT FAILURE-> Invalid Subscriber..!!");
         break;

      case 2:
         handleError(DIAM_EXP_RESULT_CODE_ABSENT_USER);
         LLOG(0,0,"TRANSIENT FAILURE-> Subscriber currently not latched to the network..!!");
         break;


      case -10:
         handleError(DIAM_EXP_RESULT_CODE_ERROR_UNAUTHORIZED_REQUESTING_NETWORK);
         LLOG(0,0,"PERMANENT fAILURE-> GMLC network not matched..!!");
         break;

      default:
         handleError(DIAM_EXP_RESULT_CODE_UNKNOWN);
         LLOG(0,0,"PERMANENT fAILURE-> Unknown Error Code from DB %d", m_slh_usrData->d_ErrorCode_OUT);
         break;
   }
#endif
}


/* Receives and Initiates the Slh or DB message from map-ng */
bool SLH_routing_info::processMessage(Msg *p_MsgPtr,bool &p_DeleteFlag)
{
   DLOG(0, 0, "Start of CtxtLteUpdateLocationRequest::processMsg function Delete flag is %d",p_DeleteFlag);

   switch (p_MsgPtr->m_MsgType)
   {
      case MSG_TYPE_MAP:
         {
            WLOG(0,0,"MAP message received");;
         }
         break;

      case MSG_TYPE_DIAMETER:
         {
            DiameterMsg *l_dm = (DiameterMsg*)p_MsgPtr;
            switch(l_dm->m_det)
            {
               case DIAM_EVENT_REQUEST:
                  {
                     switch(l_dm->m_commandCode)
                     {
                        case DIAM_COMM_CODE_SLH_RIR_RIA: /* specially for slh */
                           {
                              LLOG(0,0,"Diameter Message RIR received");
                              p_DeleteFlag = false;
                              m_MessagePtr = p_MsgPtr;

                              if (false == l_dm->m_allocatedFlag)
                              {
                                 CLOG(0,0,"RIR received is NULL. Sending Unable to Comply Error.");
                                 handleError(DIAM_RESULT_CODE_UNABLE_TO_COMPLY);
                                 return false;
                              }

                              else
                              {
                                 if(false == check_RIR())
                                 {
                                    LLOG(0,0,"Check RIR failed");
                                    handleError(DIAM_RESULT_CODE_UNABLE_TO_COMPLY);
                                    return false;
                                 }

                                 handleSlhDbQuery();
                                 return true;
                              }
                           }
                           break;

                        default:
                           {
                              CLOG(0,0,"Unknown Message[%d] Received",l_dm->m_commandCode);
                           }
                           break;
                     }
                  }
               default:
                  {
                     LLOG(0,1,"UNKNOWN DIAMETER EVENT received");
                     return false;
                  }
            }
         }
         break;

      case MSG_TYPE_DB:
         {
            DLOG(0, 0, "DB message received");
            if(1 == ((DbQueryMsg*)p_MsgPtr)->m_DbQueryType)
            {
               LLOG(0,0,"DBRES: Type:1");
               Slh_db_data *l_slhData = (Slh_db_data*)p_MsgPtr;
               m_slh_usrData = l_slhData;
               p_DeleteFlag = false;

               handleSlhDBResponse();
            }
         }
         break;

      default:
         {
            ELOG(0, 0, "Unknown message received");
         }
         break;
   }
   return true;
}

