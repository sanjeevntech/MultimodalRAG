#include<LteMmMemCachedQueries.h>
#include<LteMmDbQueries.h>
#include <MemCachedUtilities.h>
#include <Logger.h>
#include <ConfigReader.h>
#include <SubsProfileData.h>
#include<LteMmConfigReader.h>

LteMmMemCachedQueries::LteMmMemCachedQueries()
{   
   DLOG(0,1,"LteMmMemCachedQueries :cons:");
}

LteMmMemCachedQueries::~LteMmMemCachedQueries()
{
   DLOG(0,1,"LteMmMemCachedQueries :des:");
}

void LteSubsDbData::executeMemcQuery()
{
   if(m_MemcQueryType == MEMC_QUERY_TYPE_GET)
   {
      DLOG(0,0,"Inside LteSubsDbData executeMemcQuery .. MEMC_QUERY_TYPE_GET");
      //RetrieveMemCached(m_memcActivePtr, m_MemcKey, m_MemcValue, m_MemcErrorCode, m_MemcErrorMessage, (0 == m_RoamPartnerId)?true:false, m_MemcIP, m_MemcPort);
      RetrieveMemCached(m_memcActivePtr, m_MemcKey, m_MemcValue, m_MemcErrorCode, m_MemcErrorMessage, 0, m_MemcIP, m_MemcPort);
      //DLOG(0,0,"m_RoamPartnerId [%d]",m_RoamPartnerId);
   }

   if(m_MemcQueryType == MEMC_QUERY_TYPE_UPDATE)
   {
      DLOG(0,0,"Inside LteSubsDbData executeMemcQuery .. MEMC_QUERY_TYPE_UPDATE");
      //UpdateMemCached(m_memcActivePtr, m_MemcKey, m_MemcValue, m_MemcErrorCode, m_MemcErrorMessage,(0 == m_RoamPartnerId)?true:false, m_MemcIP, m_MemcPort);
      UpdateMemCached(m_memcActivePtr, m_MemcKey, m_MemcValue, m_MemcErrorCode, m_MemcErrorMessage, 0, m_MemcIP, m_MemcPort);
   }

   if(m_MemcErrorCode != 0)
   {
      m_MemcQueryRes = MEMC_QUERY_RES_FAILURE;
   }
   else
   {
      m_MemcQueryRes = MEMC_QUERY_RES_SUCCESS;
   }
}

void LteSubsDbData::serializeMemc()
{  
   char l_memcKey[25];
   memset(l_memcKey,'\0',sizeof(l_memcKey));
   if(m_MemcQueryType == MEMC_QUERY_TYPE_GET)
   {
      DLOG(0,0,"Inside LteSubsDbData serializeMemc .. MEMC_QUERY_TYPE_GET"); 
      snprintf(l_memcKey,sizeof(l_memcKey),"%s_ULR",m_UlrImsi_IN);
      //snprintf(l_memcKey,sizeof(l_memcKey),"%s",m_UlrImsi_IN);
      snprintf(m_PriImsi4Distribution,sizeof(m_PriImsi4Distribution),"%s",m_UlrImsi_IN);
      m_MemcKey = l_memcKey;
      DLOG(0,0,"LteSubsDbData: serialize: MEMC_KEY[%s]",m_MemcKey.c_str());
   }

   if(m_MemcQueryType == MEMC_QUERY_TYPE_UPDATE)
   {
      DLOG(0,0,"Inside LteSubsDbData serializeMemc .. MEMC_QUERY_TYPE_UPDATE");
      snprintf(l_memcKey,sizeof(l_memcKey),"%s_ULR",m_UlrImsi_IN);
      /*if(m_RoamPartnerId > 0)
        {
        TLOG(0,0,"Other IMSI subscriber: Imsi[%s] Sgsn[%s] in memcached",m_UlrImsi_IN,m_SgsnNumber_IN);
        }*/
      snprintf(m_PriImsi4Distribution,sizeof(m_PriImsi4Distribution),"%s",m_UlrImsi_IN);
      m_MemcKey = l_memcKey;

      char l_memcvalue[5000];
      memset(l_memcvalue,'\0',sizeof(l_memcvalue));

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<A>%d</A>",m_Nam_OUT);
      m_MemcValue = l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<B>%d</B>",m_Mwd_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<C>%d</C>",m_FirstUL_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<D>%d</D>",m_NetworkId_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<E>%d</E>",m_RoamingInd_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<F>%d</F>",m_S6aRelease_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<G>%d</G>",m_PartnerNkId_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<H>%d</H>",m_PartnerType_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<I>%d</I>",m_PreBurntImsi_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<J>%d</J>",m_AllocationType_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<K>%d</K>",m_AllocationStatus_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<L>%d</L>",m_SubscriberStatus_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<M>%d</M>",m_LocalImsiSubscription_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<N>%d</N>",m_DynMsisdnMinFreeThreshold_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<O>%d</O>",m_Odb_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<P>%d</P>",m_HplmnOdb_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<Q>%d</Q>",m_MmeSeqNum_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<R>%d</R>",m_FreeCount_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<S>%d</S>",m_PdpProfId_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<T>%d</T>",m_ThresholdCount_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<U>%d</U>",m_LteConfigProfId_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<V>%d</V>",m_MsisdnFreeCount_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<W>%d</W>",m_AccessRestriction_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<X>%d</X>",m_TempMsisdnFreeCount_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<Y>%d</Y>",m_TempMsisdnThreshCount_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<Z>%s</Z>",m_AccountId_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<AA>%s</AA>",m_RoamCC_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<AB>%s</AB>",m_Msisdn_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<AC>%s</AC>",m_LocalImsi_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<AD>%s</AD>",m_OldMsisdn_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<AE>%s</AE>",m_PrimaryImsi_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<AF>%s</AF>",m_AlertMsisdn_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<AG>%s</AG>",m_LocalMsisdn_OUT);
      m_MemcValue+= l_memcvalue;


      snprintf(l_memcvalue,sizeof(l_memcvalue),"<AH>%s</AH>",m_Imei_IN);
      m_MemcValue+= l_memcvalue;

      /*snprintf(l_memcvalue,sizeof(l_memcvalue),"<AH>%s</AH>",m_rowIdGsm_OUT);
        m_MemcValue+= l_memcvalue;

        snprintf(l_memcvalue,sizeof(l_memcvalue),"<AI>%s</AI>",m_rowIdGprs_OUT);
        m_MemcValue+= l_memcvalue;

        snprintf(l_memcvalue,sizeof(l_memcvalue),"<AJ>%s</AJ>",m_rowIdMme_OUT);
        m_MemcValue+= l_memcvalue;*/

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<AK>%s</AK>",m_OldMmeHost_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<AL>%s</AL>",m_PrimaryMsisdn_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<AM>%s</AM>",m_LogPrefix_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<AN>%s</AN>",m_OldMmeRealm_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<AO>%s</AO>",m_SgsnNumber_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<AP>%s</AP>",m_SgsnAddress_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<AQ>%s</AQ>",m_SimStructure_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<AR>%s</AR>",m_HssOriginHost_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<AS>%s</AS>",m_HssOriginRealm_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<AT>%s</AT>",m_HlrAddress_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<AU>%s</AU>",m_AreaCodeBasedAllocInfo_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<AV>%s</AV>",m_TrapCode_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<AW>%s</AW>",m_TrapDesc_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<AX>%d</AX>",m_ossTriggerDataCount_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<AY>%s</AY>",m_MmeHost_IN);
      m_MemcValue+= l_memcvalue;

      /*snprintf(l_memcvalue,sizeof(l_memcvalue),"<AY>%s</AY>",m_ossTriggerData_OUT);
        m_MemcValue+= l_memcvalue;*/

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<AZ>%s</AZ>",m_LocalRoamInfo_OUT);
      m_MemcValue+= l_memcvalue;

      /*snprintf(l_memcvalue,sizeof(l_memcvalue),"<BA>%s</BA>",m_TdrResrvData_OUT);
      m_MemcValue+= l_memcvalue;*/

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<BB>%s</BB>",m_TdrRestrData_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<BC>%s</BC>",m_TdrProfData_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<BD>%s</BD>",m_generalTDRdata_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<BE>%d</BE>",m_dsrFlag_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<BF>%s</BF>",m_dsrContexts_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<BG>%d</BG>",m_crossClType_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<BH>%s</BH>",m_AltImsi_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<BI>%s</BI>",m_IPAddress_OUT);
      m_MemcValue+= l_memcvalue;


      snprintf(l_memcvalue,sizeof(l_memcvalue),"<BJ>%d</BJ>",m_ImsProfId_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<BK>%d</BK>",m_ims_service_flag_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<BM>%d</BM>",m_ErrorCode_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<BN>%s</BN>",m_ErrorMsg_OUT);
      m_MemcValue+= l_memcvalue;

      time_t l_seconds;
      l_seconds = time(NULL);
      //int a = l_seconds;
      //long double l_seconds = time(NULL);
      snprintf(l_memcvalue,sizeof(l_memcvalue),"<BO>%ld</BO>",(long)l_seconds);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<BP>%s</BP>",m_Memcached_Parameters_OUT);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<BQ>%d</BQ>",m_Congestion_Cross_CL);
      m_MemcValue+= l_memcvalue;

      snprintf(l_memcvalue,sizeof(l_memcvalue),"<BR>%s</BR>",m_TacInfo_OUT);
      m_MemcValue+= l_memcvalue;
      
      snprintf(l_memcvalue,sizeof(l_memcvalue),"<BS>%s</BS>",m_Imei_IN);
      m_MemcValue+= l_memcvalue;
      
      DLOG(0,0,"LteSubsDbData: serialize: MEMC_KEY[%s] MEMC_VALUE[%s]",m_MemcKey.c_str(),m_MemcValue.c_str());
   } 
}


bool LteSubsDbData::deSerializeMemc()
{  
   if(m_MemcQueryType == MEMC_QUERY_TYPE_GET)
   {
      DLOG(0,0,"Inside LteSubsDbData deSerializeMemc .. MEMC_QUERY_TYPE_GET");
      DLOG(0,0,"LteSubsDbData: deSerialize: MEMC_KEY[%s] MEMC_VALUE[%s]",m_MemcKey.c_str(),m_MemcValue.c_str());
      if('D' == m_MemcValue.c_str()[0])
      {
         LLOG(0,0,"SUBSCRIBER[%s] marked as soft delete... pushing into DBQ",m_MemcKey.c_str());
         m_updateMemcAfterDb = 1;
         return false;
      }

      unsigned long int l_Odb_OUT = 0;
      unsigned long int l_HplmnOdb_OUT = 0;
      unsigned long int l_MmeSeqNum_OUT = 0;
      unsigned long int l_FreeCount_OUT = 0;
      unsigned long int l_PdpProfId_OUT = 0;
      unsigned long int l_ThresholdCount_OUT = 0;
      unsigned long int l_LteConfigProfId_OUT = 0;
      unsigned long int l_MsisdnFreeCount_OUT = 0;
      unsigned long int l_AccessRestriction_OUT = 0;
      unsigned long int l_TempMsisdnFreeCount_OUT = 0;
      unsigned long int l_TempMsisdnThreshCount_OUT = 0;

      //u8 l_ossTriggerData_OUT[10][5000+1];
      //memset(l_ossTriggerData_OUT,'\0',sizeof(l_ossTriggerData_OUT));
      u8 l_LocalRoamInfo_OUT[100+1];
      memset(l_LocalRoamInfo_OUT,'\0',sizeof(l_LocalRoamInfo_OUT));
      u8 l_TdrResrvData_OUT[100+1];
      memset(l_TdrResrvData_OUT,'\0',sizeof(l_TdrResrvData_OUT));
      u8 l_TdrRestrData_OUT[100+1];
      memset(l_TdrRestrData_OUT,'\0',sizeof(l_TdrRestrData_OUT));
      u8 l_TdrProfData_OUT[100+1];
      memset(l_TdrProfData_OUT,'\0',sizeof(l_TdrProfData_OUT));
      unsigned long int l_dsrFlag_OUT = 0;
      char l_seconds[20];
      memset(l_seconds,'\0',sizeof(l_seconds));

      if(false == ConfigReader::readInteger(m_MemcValue.c_str(), "A", m_Nam_OUT, 0, 2147483647))
      {
         ELOG(0,0,"m_Nam_OUT not present in Memcached value");
         return false;
      }

      if(false == ConfigReader::readInteger(m_MemcValue.c_str(), "B", m_Mwd_OUT, 0, 2147483647))
      {
         ELOG(0,0,"m_Nam_OUT not present in Memcached value");
         return false;
      }

      if(false == ConfigReader::readInteger(m_MemcValue.c_str(), "C", m_FirstUL_OUT, 0, 2147483647))
      {
         ELOG(0,0,"m_FirstUL_OUT not present in Memcached value");
         return false;
      }

      if(false == ConfigReader::readInteger(m_MemcValue.c_str(), "D", m_NetworkId_OUT, 0, 2147483647))
      {
         ELOG(0,0,"m_NetworkId_OUT not present in Memcached value");
         return false;
      }

      if(false == ConfigReader::readInteger(m_MemcValue.c_str(), "E", m_RoamingInd_OUT, 0, 2147483647))
      {
         ELOG(0,0,"m_RoamingInd_OUT not present in Memcached value");
         return false;
      }

      if(false == ConfigReader::readInteger(m_MemcValue.c_str(), "F", m_S6aRelease_OUT, 0, 2147483647))
      {
         ELOG(0,0,"m_S6aRelease_OUT not present in Memcached value");
         return false;
      }

      if(false == ConfigReader::readInteger(m_MemcValue.c_str(), "G", m_PartnerNkId_OUT, 0, 2147483647))
      {
         ELOG(0,0,"m_PartnerNkId_OUT not present in Memcached value");
         return false;
      }

      if(false == ConfigReader::readInteger(m_MemcValue.c_str(), "H", m_PartnerType_OUT, 0, 2147483647))
      {
         ELOG(0,0,"m_PartnerType_OUT not present in Memcached value");
         return false;
      }

      if(false == ConfigReader::readInteger(m_MemcValue.c_str(), "I", m_PreBurntImsi_OUT, 0, 2147483647))
      {
         ELOG(0,0,"m_PreBurntImsi_OUT not present in Memcached value");
         return false;
      }

      if(false == ConfigReader::readInteger(m_MemcValue.c_str(), "J", m_AllocationType_OUT, 0, 2147483647))
      {
         ELOG(0,0,"m_AllocationType_OUT not present in Memcached value");
         return false;
      }

      if(false == ConfigReader::readInteger(m_MemcValue.c_str(), "K", m_AllocationStatus_OUT, 0, 2147483647))
      {
         ELOG(0,0,"m_AllocationStatus_OUT not present in Memcached value");
         return false;
      }

      if(false == ConfigReader::readInteger(m_MemcValue.c_str(), "L", m_SubscriberStatus_OUT, 0, 2147483647))
      {
         ELOG(0,0,"m_SubscriberStatus_OUT not present in Memcached value");
         return false;
      }

      if(false == ConfigReader::readInteger(m_MemcValue.c_str(), "M", m_LocalImsiSubscription_OUT, 0, 2147483647))
      {
         ELOG(0,0,"m_LocalImsiSubscription_OUT not present in Memcached value");
         return false;
      }

      if(false == ConfigReader::readInteger(m_MemcValue.c_str(), "N", m_DynMsisdnMinFreeThreshold_OUT, 0, 2147483647))
      {
         ELOG(0,0,"m_DynMsisdnMinFreeThreshold_OUT not present in Memcached value");
         return false;
      }

      if(false == ConfigReader::readUnsignedInteger(m_MemcValue.c_str(), "O", l_Odb_OUT, 0, 4294967295))
      {
         ELOG(0,0,"m_Odb_OUT not present in Memcached value");
         return false;
      }
      m_Odb_OUT = l_Odb_OUT;

      if(false == ConfigReader::readUnsignedInteger(m_MemcValue.c_str(), "P", l_HplmnOdb_OUT, 0, 4294967295))
      {
         ELOG(0,0,"m_HplmnOdb_OUT not present in Memcached value");
         return false;
      }
      m_HplmnOdb_OUT = l_HplmnOdb_OUT;

      if(false == ConfigReader::readUnsignedInteger(m_MemcValue.c_str(), "Q", l_MmeSeqNum_OUT, 0, 4294967295))
      {
         ELOG(0,0,"m_MmeSeqNum_OUT not present in Memcached value");
         //return false;
      }
      m_MmeSeqNum_OUT = l_MmeSeqNum_OUT;

      if(false == ConfigReader::readUnsignedInteger(m_MemcValue.c_str(), "R", l_FreeCount_OUT, 0, 4294967295))
      {
         ELOG(0,0,"m_FreeCount_OUT not present in Memcached value");
         return false;
      }
      m_FreeCount_OUT = l_FreeCount_OUT;

      if(false == ConfigReader::readUnsignedInteger(m_MemcValue.c_str(), "S", l_PdpProfId_OUT, 0, 4294967295))
      {
         ELOG(0,0,"m_PdpProfId_OUT not present in Memcached value");
         return false;
      }
      m_PdpProfId_OUT = l_PdpProfId_OUT;

      if(false == ConfigReader::readUnsignedInteger(m_MemcValue.c_str(), "T", l_ThresholdCount_OUT, 0, 4294967295))
      {
         ELOG(0,0,"m_ThresholdCount_OUT not present in Memcached value");
         return false;
      }
      m_ThresholdCount_OUT = l_ThresholdCount_OUT;

      if(false == ConfigReader::readUnsignedInteger(m_MemcValue.c_str(), "U", l_LteConfigProfId_OUT, 0, 4294967295))
      {
         ELOG(0,0,"m_LteConfigProfId_OUT not present in Memcached value");
         return false;
      }
      m_LteConfigProfId_OUT = l_LteConfigProfId_OUT;

      if(false == ConfigReader::readUnsignedInteger(m_MemcValue.c_str(), "V", l_MsisdnFreeCount_OUT, 0, 4294967295))
      {
         ELOG(0,0,"m_MsisdnFreeCount_OUT not present in Memcached value");
         return false;
      }
      m_MsisdnFreeCount_OUT = l_MsisdnFreeCount_OUT;

      if(false == ConfigReader::readUnsignedInteger(m_MemcValue.c_str(), "W", l_AccessRestriction_OUT, 0, 4294967295))
      {
         ELOG(0,0,"m_AccessRestriction_OUT not present in Memcached value");
         return false;
      }
      m_AccessRestriction_OUT = l_AccessRestriction_OUT;

      if(false == ConfigReader::readUnsignedInteger(m_MemcValue.c_str(), "X", l_TempMsisdnFreeCount_OUT, 0, 4294967295))
      {
         ELOG(0,0,"m_TempMsisdnFreeCount_OUT not present in Memcached value");
         return false;
      }
      m_TempMsisdnFreeCount_OUT = l_TempMsisdnFreeCount_OUT;

      if(false == ConfigReader::readUnsignedInteger(m_MemcValue.c_str(), "Y", l_TempMsisdnThreshCount_OUT, 0, 4294967295))
      {
         ELOG(0,0,"m_TempMsisdnThreshCount_OUT not present in Memcached value");
         return false;
      }
      m_TempMsisdnThreshCount_OUT = l_TempMsisdnThreshCount_OUT;
      if(false == ConfigReader::readString(m_MemcValue, "Z", (char*)m_AccountId_OUT, 0, 20))
      {
         ELOG(0,0,"m_AccountId_OUT not present in Memcached Value");
         return false;
      }
      else
      {
         DLOG(0,0,"m_AccountId_OUT %s present in Memcached Value",m_AccountId_OUT);
      }

      if(false == ConfigReader::readString(m_MemcValue, "AA", (char*)m_RoamCC_OUT, 0, 10))
      {
         ELOG(0,0,"m_RoamCC_OUT not present in Memcached Value");
         return false;
      }
      else
      {
         DLOG(0,0,"m_RoamCC_OUT %s present in Memcached Value",m_RoamCC_OUT);
      }

      if(false == ConfigReader::readString(m_MemcValue, "AB", (char*)m_Msisdn_OUT, 0, 20))
      {
         ELOG(0,0,"m_Msisdn_OUT not present in Memcached Value");
         return false;
      }
      else
      {
         DLOG(0,0,"m_Msisdn_OUT %s present in Memcached Value",m_Msisdn_OUT);
      }

      if(false == ConfigReader::readString(m_MemcValue, "AC", (char*)m_LocalImsi_OUT, 0, 20))
      {
         ELOG(0,0,"m_LocalImsi_OUT not present in Memcached Value");
         return false;
      }
      else
      {
         DLOG(0,0,"m_LocalImsi_OUT %s present in Memcached Value",m_LocalImsi_OUT);
      }

      if(false == ConfigReader::readString(m_MemcValue, "AD", (char*)m_OldMsisdn_OUT, 0, 20))
      {
         ELOG(0,0,"m_OldMsisdn_OUT not present in Memcached Value");
         return false;
      }
      else
      {
         DLOG(0,0,"m_OldMsisdn_OUT %s present in Memcached Value",m_OldMsisdn_OUT);
      }

      if(false == ConfigReader::readString(m_MemcValue, "AE", (char*)m_PrimaryImsi_OUT, 0, 20))
      {
         ELOG(0,0,"m_PrimaryImsi_OUT not present in Memcached Value");
         return false;
      }
      else
      {
         DLOG(0,0,"m_PrimaryImsi_OUT %s present in Memcached Value",m_PrimaryImsi_OUT);
      }

      if(false == ConfigReader::readString(m_MemcValue, "AF", (char*)m_AlertMsisdn_OUT, 0, 20))
      {
         ELOG(0,0,"m_AlertMsisdn_OUT not present in Memcached Value");
         return false;
      }
      else
      {
         DLOG(0,0,"m_AlertMsisdn_OUT %s present in Memcached Value",m_AlertMsisdn_OUT);
      }

      if(false == ConfigReader::readString(m_MemcValue, "AG", (char*)m_LocalMsisdn_OUT, 0, 20))
      {
         ELOG(0,0,"m_LocalMsisdn_OUT not present in Memcached Value");
         return false;
      }
      else
      {
         DLOG(0,0,"m_LocalMsisdn_OUT %s present in Memcached Value",m_LocalMsisdn_OUT);
      }

      /* if(false == ConfigReader::readString(m_MemcValue, "AH", (char*)m_rowIdGsm_OUT, 0, 30))
         {
         ELOG(0,0,"m_rowIdGsm_OUT not present in Memcached Value");
         return false;
         }
         else
         {
         DLOG(0,0,"m_rowIdGsm_OUT %s present in Memcached Value",m_rowIdGsm_OUT);
         }

         if(false == ConfigReader::readString(m_MemcValue, "AI", (char*)m_rowIdGprs_OUT, 0, 30))
         {
         ELOG(0,0,"m_rowIdGprs_OUT not present in Memcached Value");
         return false;
         }
         else
         {
         DLOG(0,0,"m_rowIdGprs_OUT %s present in Memcached Value",m_rowIdGprs_OUT);
         }

         if(false == ConfigReader::readString(m_MemcValue, "AJ", (char*)m_rowIdMme_OUT, 0, 30))
         {
         ELOG(0,0,"m_rowIdMme_OUT not present in Memcached Value");
         return false;
         }
         else
         {
         DLOG(0,0,"m_rowIdMme_OUT %s present in Memcached Value",m_rowIdMme_OUT);
         }*/

      if(false == ConfigReader::readString(m_MemcValue, "AK", (char*)m_OldMmeHost_OUT, 1, 100))
      {
         ELOG(0,0,"m_OldMmeHost_OUT not present in Memcached Value");
         m_updateMemcAfterDb = 1;
         return false;
      }
      else
      {
         DLOG(0,0,"m_OldMmeHost_OUT %s present in Memcached Value",m_OldMmeHost_OUT);
      }

      if(false == ConfigReader::readString(m_MemcValue, "AL", (char*)m_PrimaryMsisdn_OUT, 0, 20))
      {
         ELOG(0,0,"m_PrimaryMsisdn_OUT not present in Memcached Value");
         return false;
      }
      else
      {
         DLOG(0,0,"m_PrimaryMsisdn_OUT %s present in Memcached Value",m_PrimaryMsisdn_OUT);
      }

      if(false == ConfigReader::readString(m_MemcValue, "AM", (char*)m_LogPrefix_OUT, 0, 150))
      {
         ELOG(0,0,"m_LogPrefix_OUT not present in Memcached Value");
         return false;
      }
      else
      {
         DLOG(0,0,"m_LogPrefix_OUT %s present in Memcached Value",m_LogPrefix_OUT);
      }

      if(false == ConfigReader::readString(m_MemcValue, "AN", (char*)m_OldMmeRealm_OUT, 0, 100))
      {
         ELOG(0,0,"m_OldMmeRealm_OUT not present in Memcached Value");
         return false;
      }
      else
      {
         DLOG(0,0,"m_OldMmeRealm_OUT %s present in Memcached Value",m_OldMmeRealm_OUT);
      }

      if(false == ConfigReader::readString(m_MemcValue, "AO", (char*)m_SgsnNumber_OUT, 0, 20))
      {
         ELOG(0,0,"m_SgsnNumber_OUT not present in Memcached Value");
         return false;
      }
      else
      {
         DLOG(0,0,"m_SgsnNumber_OUT %s present in Memcached Value",m_SgsnNumber_OUT);
      }

      if(false == ConfigReader::readString(m_MemcValue, "AP", (char*)m_SgsnAddress_OUT, 0, 34))
      {
         ELOG(0,0,"m_SgsnAddress_OUT not present in Memcached Value");
         return false;
      }
      else
      {
         DLOG(0,0,"m_SgsnAddress_OUT %s present in Memcached Value",m_SgsnAddress_OUT);
      }

      if(false == ConfigReader::readString(m_MemcValue, "AQ", (char*)m_SimStructure_OUT, 0, 30))
      {
         ELOG(0,0,"m_SimStructure_OUT not present in Memcached Value");
         return false;
      }
      else
      {
         DLOG(0,0,"m_SimStructure_OUT %s present in Memcached Value",m_SimStructure_OUT);
      }

      if(false == ConfigReader::readString(m_MemcValue, "AR", (char*)m_HssOriginHost_OUT, 0, 100))
      {
         ELOG(0,0,"m_HssOriginHost_OUT not present in Memcached Value");
         return false;
      }
      else
      {
         DLOG(0,0,"m_HssOriginHost_OUT %s present in Memcached Value",m_HssOriginHost_OUT);
      }

      if(false == ConfigReader::readString(m_MemcValue, "AS", (char*)m_HssOriginRealm_OUT, 0, 100))
      {
         ELOG(0,0,"m_HssOriginRealm_OUT not present in Memcached Value");
         return false;
      }
      else
      {
         DLOG(0,0,"m_HssOriginRealm_OUT %s present in Memcached Value",m_HssOriginRealm_OUT);
      }

      if(false == ConfigReader::readString(m_MemcValue, "AT", (char*)m_HlrAddress_OUT, 0, 20))
      {
         ELOG(0,0,"m_HlrAddress_OUT not present in Memcached Value");
         return false;
      }
      else
      {
         DLOG(0,0,"m_HlrAddress_OUT %s present in Memcached Value",m_HlrAddress_OUT);
      }

      if(false == ConfigReader::readString(m_MemcValue, "AU", (char*)m_AreaCodeBasedAllocInfo_OUT, 0, 100))
      {
         ELOG(0,0,"m_AreaCodeBasedAllocInfo_OUT not present in Memcached Value");
         return false;
      }
      else
      {
         DLOG(0,0,"m_AreaCodeBasedAllocInfo_OUT %s present in Memcached Value",m_AreaCodeBasedAllocInfo_OUT);
      }

      if(false == ConfigReader::readString(m_MemcValue, "AV", (char*)m_TrapCode_OUT, 0, 50))
      {
         ELOG(0,0,"m_TrapCode_OUT not present in Memcached Value");
         return false;
      }
      else
      {
         DLOG(0,0,"m_TrapCode_OUT %s present in Memcached Value",m_TrapCode_OUT);
      }

      if(false == ConfigReader::readString(m_MemcValue, "AW", (char*)m_TrapDesc_OUT, 0, 500))
      {
         ELOG(0,0,"m_TrapDesc_OUT not present in Memcached Value");
         return false;
      }
      else
      {
         DLOG(0,0,"m_TrapDesc_OUT %s present in Memcached Value",m_TrapDesc_OUT);
      }

      if(false == ConfigReader::readInteger(m_MemcValue.c_str(), "AX", m_ossTriggerDataCount_OUT, 0, 2147483647))
      {
         ELOG(0,0,"m_ossTriggerDataCount_OUT not present in Memcached value");
         return false;
      }

      /*if(false == ConfigReader::readString(m_MemcValue, "AY", (char*)l_ossTriggerData_OUT, 0, 50000))
        {
        ELOG(0,0,"m_ossTriggerData_OUT not present in Memcached Value");
        return false;
        }
        else
        {
        DLOG(0,0,"m_ossTriggerData_OUT present in Memcached Value:%s",l_ossTriggerData_OUT);
        for(int i=0; i<m_ossTriggerDataCount_OUT; i++)
        snprintf((char *)m_ossTriggerData_OUT[i],sizeof(m_ossTriggerData_OUT[i]),"%s",l_ossTriggerData_OUT[i]);
        DLOG(0,0,"MEMCACHED: m_ossTriggerData_OUT : [%s]",m_ossTriggerData_OUT); 
        }*/

      if(false == ConfigReader::readString(m_MemcValue, "AZ", (char*)l_LocalRoamInfo_OUT, 0, 100))
      {
         ELOG(0,0,"m_LocalRoamInfo_OUT not present in Memcached Value");
         return false;
      }
      else
      {
         DLOG(0,0,"m_LocalRoamInfo_OUT present in Memcached Value:%s",l_LocalRoamInfo_OUT);
         snprintf((char *)m_LocalRoamInfo_OUT,sizeof(m_LocalRoamInfo_OUT),"%s",l_LocalRoamInfo_OUT);
         DLOG(0,0,"MEMCACHED: m_LocalRoamInfo_OUT : [%s]",m_LocalRoamInfo_OUT); 
      }

      /*if(false == ConfigReader::readString(m_MemcValue, "BA", (char*)l_TdrResrvData_OUT, 0, 100))
      {
         ELOG(0,0,"m_TdrResrvData_OUT not present in Memcached Value");
         return false;
      }
      else
      {
         DLOG(0,0,"m_TdrResrvData_OUT present in Memcached Value:%s",l_TdrResrvData_OUT);
         snprintf((char *)m_TdrResrvData_OUT,sizeof(m_TdrResrvData_OUT),"%s",l_TdrResrvData_OUT);
         DLOG(0,0,"MEMCACHED: m_TdrResrvData_OUT : [%s]",m_TdrResrvData_OUT); 
      }*/

      if(false == ConfigReader::readString(m_MemcValue, "BB", (char*)l_TdrRestrData_OUT, 0, 100))
      {
         ELOG(0,0,"m_TdrRestrData_OUT not present in Memcached Value");
         return false;
      }
      else
      {
         DLOG(0,0,"m_TdrRestrData_OUT present in Memcached Value:%s",l_TdrRestrData_OUT);
         snprintf((char *)m_TdrRestrData_OUT,sizeof(m_TdrRestrData_OUT),"%s",l_TdrRestrData_OUT);
         DLOG(0,0,"MEMCACHED: m_TdrRestrData_OUT : [%s]",m_TdrRestrData_OUT); 
      }

      if(false == ConfigReader::readString(m_MemcValue, "BC", (char*)l_TdrProfData_OUT, 0, 100))
      {
         ELOG(0,0,"m_TdrProfData_OUT not present in Memcached Value");
         return false;
      }
      else
      {
         DLOG(0,0,"m_TdrProfData_OUT present in Memcached Value:%s",l_TdrProfData_OUT);
         snprintf((char *)m_TdrProfData_OUT,sizeof(m_TdrProfData_OUT),"%s",l_TdrProfData_OUT);
         DLOG(0,0,"... m_TdrProfData_OUT : [%s] ...",m_TdrProfData_OUT); 
      }

      if(false == ConfigReader::readString(m_MemcValue, "BD", (char*)m_generalTDRdata_OUT, 0, 500))
      {
         ELOG(0,0,"m_generalTDRdata_OUT not present in Memcached Value");
         return false;
      }
      else
      {
         DLOG(0,0,"m_generalTDRdata_OUT %s present in Memcached Value",m_generalTDRdata_OUT);
      }

      if(false == ConfigReader::readUnsignedInteger(m_MemcValue.c_str(), "BE", l_dsrFlag_OUT, 0, 4294967295))
      {
         ELOG(0,0,"m_dsrFlag_OUT not present in Memcached value");
         return false;
      }
      m_dsrFlag_OUT = l_dsrFlag_OUT;

      if(false == ConfigReader::readString(m_MemcValue, "BF", (char*)m_dsrContexts_OUT, 0, 100))
      {
         ELOG(0,0,"m_dsrContexts_OUT not present in Memcached Value");
         return false;
      }
      else
      {
         DLOG(0,0,"m_dsrContexts_OUT %s present in Memcached Value",m_dsrContexts_OUT);
      }

      if(false == ConfigReader::readInteger(m_MemcValue.c_str(), "BG", m_crossClType_OUT, 0, 2147483647))
      {
         ELOG(0,0,"m_crossClType_OUT not present in Memcached value");
         return false;
      }

      if(false == ConfigReader::readString(m_MemcValue, "BH", (char*)m_AltImsi_OUT, 0, 20))
      {
         ELOG(0,0,"m_AltImsi_OUT not present in Memcached Value");
         return false;
      }
      else
      {
         DLOG(0,0,"m_AltImsi_OUT %s present in Memcached Value",m_AltImsi_OUT);
      }

      if(false == ConfigReader::readString(m_MemcValue, "BI", (char*)m_IPAddress_OUT, 0, 100))
      {
         ELOG(0,0,"m_IPAddress_OUT not present in Memcached Value");
         return false;
      }
      else
      {
         DLOG(0,0,"m_IPAddress_OUT %s present in Memcached Value",m_IPAddress_OUT);
      }

      if(false == ConfigReader::readInteger(m_MemcValue.c_str(), "BJ", m_ImsProfId_OUT, 0, 2147483647))
      {
         ELOG(0,0,"m_ImsProfId_OUT not present in Memcached value");
         return false;
      }

      if(false == ConfigReader::readInteger(m_MemcValue.c_str(), "BK", m_ims_service_flag_OUT, 0, 2147483647))
      {
         ELOG(0,0,"m_ims_service_flag_OUT not present in Memcached value");
         return false;
      }


      /*if(false == ConfigReader::readInteger(m_MemcValue.c_str(), "BO", l_seconds, 0, 9999999999))
        {
        ELOG(0,0,"m_seconds not present in Memcached value");
        return false;
        }
        m_seconds = l_seconds;*/

      if(false == ConfigReader::readString(m_MemcValue, "BO", l_seconds, 0, 20 ))
      {
         ELOG(0,0,"m_seconds not present in Memcached Value");
         return false;
      }
      else
      {  
         //strncpy(m_seconds,l_seconds,10);
         m_seconds = atol(l_seconds); 
         //m_seconds = m_seconds - 86401; 
         DLOG(0,0,"m_seconds %ld present in Memcached Value",m_seconds);

      }


      if(false == ConfigReader::readString(m_MemcValue, "BP", (char*)m_Memcached_Parameters_OUT, 0, 1000))
      {
         ELOG(0,0,"m_Memcached_Parameters_OUT not present in Memcached Value");
         return false;
      }
      else
      {
         DLOG(0,0,"m_Memcached_Parameters_OUT %s present in Memcached Value",m_Memcached_Parameters_OUT);
      }

      if(false == ConfigReader::readInteger(m_MemcValue.c_str(), "BQ", m_Congestion_Cross_CL, 0, 2147483647))
      {
         ELOG(0,0,"m_Congestion_Cross_CL not present in Memcached value");
         return false;
      }

      if(false == ConfigReader::readString(m_MemcValue, "BR", (char*)m_TacInfo_OUT, 0, 20))
      {
         ELOG(0,0,"m_TacInfo_OUT not present in Memcached Value");
         return false;
      }
      else
      {
         DLOG(0,0,"m_TacInfo_OUT %s present in Memcached Value",m_TacInfo_OUT);
      }
      
      /*if(false == ConfigReader::readString(m_MemcValue, "BS", (char*)m_PreviousImei_OUT, 1, 40))
      {
         ELOG(0,0,"m_PreviousImei_OUT not present in Memcached Value");
         return false;
      }
      else
      {
         DLOG(0,0,"m_PreviousImei_OUT %s present in Memcached Value",m_PreviousImei_OUT);
      }*/

      return true;
   }

   if(m_MemcQueryType == MEMC_QUERY_TYPE_UPDATE)
   {
      DLOG(0,0,"Inside LteSubsDbData deSerializeMemc .. MEMC_QUERY_TYPE_UPDATE");
      DLOG(0,0, "LteSubsDbData : deSerializeMemc");
      return true;
   }
}

bool LteSubsDbData::validateMemcachedContinuity()
{
   if(m_MemcQueryType == MEMC_QUERY_TYPE_GET)
   {
      DLOG(0,0,"Inside LteSubsDbData validateMemcachedContinuity .. MEMC_QUERY_TYPE_GET");
      time_t l_seconds;
      l_seconds = time(NULL);  
      unsigned long l_diff = l_seconds - m_seconds;
      DLOG(0,0,"m_seconds [%ld] l_seconds [%ld] l_diff[%ld] ULRMemcachedRecordTime[%d]",m_seconds,l_seconds,l_diff,g_LteMmConfigReaderObj->m_ULRMemcachedRecordTime);

      if(l_diff < g_LteMmConfigReaderObj->m_ULRMemcachedRecordTime)
      {
         DLOG(0,0,"Data stored in Memcached have not crossed configured time so using memcached data itself");

         char l_MmeHost_IN[100+1];

         if(false == ConfigReader::readString(m_MemcValue, "AY", (char*)l_MmeHost_IN, 0, 100))
         {
            ELOG(0,0,"m_MmeHost_IN not present in Memcached Value");
            return false;
         }
         else
         {
            DLOG(0,0,"MmeHost_IN %s present in Memcached Value",l_MmeHost_IN);
         }

         DLOG(0,0,"MmeHost_IN [%s] OldMmeHost_OUT[%s]",m_MmeHost_IN,l_MmeHost_IN);

         if(0 == strcmp(m_MmeHost_IN,l_MmeHost_IN))
         {
            DLOG(0,0,"m_MmeHost_IN and m_OldMmeHost_OUT are same");
            //  return true;
         }
         else
         { 
            DLOG(0,0,"m_MmeHost_IN [%s] and m_OldMmeHost_OUT [%s] are not same",m_MmeHost_IN,l_MmeHost_IN);
            m_updateMemcAfterDb = 1;
            return false;
         }


         char l_Imei_IN[37+1];

         if(false == ConfigReader::readString(m_MemcValue, "AH", (char*)l_Imei_IN, 0, 37))
         {
            ELOG(0,0,"old_Imei_IN not present in Memcached Value");
            return false;
         }
         else
         {
            DLOG(0,0,"old_Imei_IN %s present in Memcached Value",l_Imei_IN);
         }

         DLOG(0,0,"m_Imei_IN [%s] old_Imei_IN[%s]",m_Imei_IN,l_Imei_IN);

         if(0 == strcmp(m_Imei_IN,l_Imei_IN))
         {
            DLOG(0,0,"m_Imei_IN and old_Imei_IN are same");
            //  return true;
         }
         else
         { 
            DLOG(0,0,"m_Imei_IN [%s] and old_Imei_IN [%s] are not same",m_Imei_IN,l_Imei_IN);
            m_updateMemcAfterDb = 1;
            return false;
         }
         
         if(false == ConfigReader::readString(m_MemcValue, "BS", (char*)m_PreviousImei_OUT, 1, 40))
         {
            ELOG(0,0,"m_PreviousImei_OUT not present in Memcached Value");
            m_updateMemcAfterDb = 1;
            return false;
         }
         else
         {
            DLOG(0,0,"m_PreviousImei_OUT %s present in Memcached Value",m_PreviousImei_OUT);
         }

         LLOG(0,0,"MEMC: validateMemcachedContinuity is success ... Not going to DB");
      }
      else
      {
         LLOG(0,0,"Data stored in Memcached has crossed cofigured seconds[%d] .. resetting timer ang going to DB",g_LteMmConfigReaderObj->m_ULRMemcachedRecordTime);
         m_seconds = 0; 
         m_updateMemcAfterDb = 1;
         return false;
      }
   }

   if(m_MemcQueryType == MEMC_QUERY_TYPE_UPDATE)
   {
      DLOG(0,0,"Inside LteSubsDbData validateMemcachedContinuity .. MEMC_QUERY_TYPE_UPDATE");
      DLOG(0,0, "LteSubsDbData : validateMemcachedContinuity");
      return true;
   }
   return true;
}
