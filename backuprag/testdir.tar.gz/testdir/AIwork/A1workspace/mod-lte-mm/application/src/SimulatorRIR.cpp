#include <SimulatorRIR.h>
#include <stdio.h>
#include <MapMessages.h>
#include <ServiceCoordinator.h>
#include <ExtendedServiceCoordinator.h>
#include <Logger.h>
#include <DataUnion.h>
#include <DbActiveObject.h>
#include <Utilities.h>
#include <LteCommonDefines.h>
#include <LteMmConfigReader.h>
#include <LteMmSimConfigReader.h>
#include <Utilities.h>

#include <DiameterConstants.h>
//#include <s6a_r10_stats.h>
#include <DiametriqInterface.h>

RIRSimulator :: RIRSimulator()
{
   DLOG(0, 0, "RIRSimulator::RIRSimulator()");
}

RIRSimulator :: ~RIRSimulator()
{
   DLOG(0, 0, "RIRSimulator::~RIRSimulator()");
}

bool RIRSimulator :: startProcessing()
{
   DLOG(0,0, "RIRSimulator startprocessing");
   LLOG(0,0,"selfSimulate: ULR");
   unsigned int sIdx;
   string sessIdString;
   if(false == g_esc.allocateSession(DIAM_APP_ID_SLH, 
            sIdx, 
            sessIdString))
   {
      ELOG(0,1,"Unable to allocate a session");
      return false;
   }

   //cout<<"--- sessionIDint---"<<sIdx<<endl<<"--- sessionIDstring ---"<<sessIdString<<endl;

   DiameterMsg l_test((char*)sessIdString.c_str(), DIAM_EVENT_REQUEST, DIAM_COMM_CODE_SLH_RIR_RIA);

   //Prepare ULR Message
   slh_rel_10::LCSRoutingInfoRequest *l_rir = new slh_rel_10::LCSRoutingInfoRequest;
   l_rir->setSessionId(base::SessionId(sessIdString));
   l_rir->setSessionIndex(sIdx);

   AuthSessionState l_authSessionState(AuthSessionState::NO_STATE_MAINTAINED);
   l_rir->setAuthSessionState(l_authSessionState);

   OriginHost l_originHost = base::OriginHost(g_OtherConfigData->m_dcd.m_originHost);
   l_rir->setOriginHost(l_originHost);

   OriginRealm l_originRealm(g_OtherConfigData->m_dcd.m_originRealm);
   l_rir->setOriginRealm(l_originRealm);

   DestinationRealm l_destinationRealm(g_OtherConfigData->m_dcd.m_destinationRealm);
   l_rir->setDestinationRealm(l_destinationRealm);

   DestinationHost l_destinationHost(g_OtherConfigData->m_dcd.m_destinationHost);
   l_rir->setDestinationHost(l_destinationHost);

   /*char *send_type = getenv("SIM_TYPE");
   char *username = getenv("SIM_IMSI");
   char *msisdn = getenv("SIM_MSISDN");
   char *gmlc_number = getenv("SIM_GMLCNUMBER");*/

   /*if(!username || !gmlc_number || !strcmp(username,"") || !strcmp(gmlc_number,""))
   {
      if(!strncmp(send_type,"IMSI",4))
      {
         UserName l_userName("123456789876543");
         l_rir->setUserName(l_userName);
      }
      else if(!strncmp(send_type,"MSISDN",6))
      {
         MSISDN l_msisdn("1234567898765");
         l_rir->setMSISDN(l_msisdn);
      }
      else
         LLOG(0,0,"Wrong Send type in sim_export.sh..!!");

      GMLCNumber l_gmlc("56787654");
      l_rir->setGMLCNumber(l_gmlc);
   }
   else
   {
      if(!strncmp(send_type,"IMSI",4))
      {
         UserName l_userName(username);
         l_rir->setUserName(l_userName);
      }
      else if(!strncmp(send_type,"MSISDN",6))
      {
         unsigned char l_Bcdmsisdn[HSS_MSISDN_LEN + 1];
         memset(l_Bcdmsisdn,'\0', sizeof(l_Bcdmsisdn));
         int bcdlen = StringToBCD(l_Bcdmsisdn, (u8*)(msisdn), strlen(msisdn));
         string l_msisdn;
         l_msisdn.assign((char*)l_Bcdmsisdn, bcdlen);
         MSISDN MSisdn(l_msisdn);
         //MSISDN l_msisdn(msisdn);
         l_rir->setMSISDN(MSisdn);
      }
      else
         LLOG(0,0,"Wrong Send type in sim_export.sh..!!");

      
      unsigned char l_Bcdgmlc[20];
      memset(l_Bcdgmlc,'\0', sizeof(l_Bcdgmlc));
      int bcdlen = StringToBCD(l_Bcdgmlc, (u8*)(gmlc_number), strlen(gmlc_number));
      string l_gmlc;
      l_gmlc.assign((char*)l_Bcdgmlc, bcdlen);
      GMLCNumber gmlc_number(l_gmlc);
      //GMLCNumber l_gmlc(gmlc_number);
      l_rir->setGMLCNumber(gmlc_number);

   }*/

   UserName l_userName(g_LteMmSimConfigReaderObj->m_UlrImsi);
   l_rir->setUserName(l_userName);

   unsigned char l_Bcdgmlc[20];
   memset(l_Bcdgmlc,'\0', sizeof(l_Bcdgmlc));
   int bcdlen = StringToBCD(l_Bcdgmlc, (u8*)(g_LteMmSimConfigReaderObj->m_gmlc), strlen(g_LteMmSimConfigReaderObj->m_gmlc));
   string l_gmlc;
   l_gmlc.assign((char*)l_Bcdgmlc, bcdlen);
   GMLCNumber gmlc_number(l_gmlc);
   l_rir->setGMLCNumber(gmlc_number);

   l_test.m_cmd = l_rir;
   l_test.m_allocatedFlag = true;

   g_esc.sendMsg(this, &l_test);

   return true;
}

bool RIRSimulator :: processMessage(Msg *p_MsgPtr,bool &p_DeleteFlag)
{
   DLOG(0, 0, "Start of RIRSimulator::processMsg function Delete flag is %d",p_DeleteFlag);
   MapSpecificMsg *l_specMsg = NULL;

   switch (p_MsgPtr->m_MsgType)
   {
      case MSG_TYPE_MAP:
         {
            DLOG(0,0,"MAP message received");
         }
         break;

      case MSG_TYPE_DIAMETER:
         {
            DiameterMsg *l_dm = (DiameterMsg*)p_MsgPtr;
            if(NULL == l_dm->m_cmd)
            {
               CLOG(0,0,"Received Diameter Message is NULL");
               break;
            }
            switch(l_dm->m_commandCode)
            {
               case DIAM_COMM_CODE_S6A_S6D_ULR_ULA:
                  {
                     LLOG(0,0,"Diameter Message ULR received");
                  }
                  break;
               case DIAM_COMM_CODE_SLH_RIR_RIA:
                  {
                     LLOG(0,0,"Diameter Message RIR received");
                  }
                  break;
               default:
                  {
                     CLOG(0,0,"Unknown Message[%d] Received",l_dm->m_commandCode);
                  }
                  break;
            }
         }
         break;

      case MSG_TYPE_DB:
         {
            DLOG(0, 0, "DB message received");
            if(1 == ((DbQueryMsg*)p_MsgPtr)->m_DbQueryType)
            {
               LLOG(0,0,"DBRES: Type:1");
            }
            else
            {
               ELOG(0,0,"Unknown DB message");
            }
         }
         break;

      default:
         ELOG(0, 0, "Unknown message received");
         break;

   }
   return true;
}
