#include <LteMmConfigReader.h>
#include <Logger.h>
#include <DiameterConstants.h>

LteMmConfigReader *g_LteMmConfigReaderObj=NULL;

LteMmConfigReader::LteMmConfigReader()
{
   LLOG(0,0,"LteMmConfigReader cons");
   m_UlrRejectCode = 0;
   m_MinFreeMsisdnThreshold = 0;
   m_ActiveApnUpdateFlag = 0;
}

LteMmConfigReader::~LteMmConfigReader()
{
   LLOG(0,0,"LteMmConfigReader des");
}

bool LteMmConfigReader::readData()
{
   LLOG(0,0,"LteMmConfigReader::readData()");
   //string l_mm = readValue(m_DataString, "HSSMM");
   string l_mm = m_DataString;

   if( false == readInteger(l_mm, "DYN_MSISDN_MIN_FREE_THRESHOLD", m_MinFreeMsisdnThreshold, 0, 20000))
      //return false;
   LLOG(0,0,"DYN_MSISDN_MIN_FREE_THRESHOLD value [%d] - UNUSED",m_MinFreeMsisdnThreshold);

   if( false == readInteger(l_mm, "ULR_REJECT_CODE", m_UlrRejectCode, 5001, 5421))
      return false;
   if( (DIAM_EXP_RESULT_CODE_ERROR_USER_UNKNOWN == m_UlrRejectCode) || (DIAM_EXP_RESULT_CODE_ERROR_ROAMING_NOT_ALLOWED == m_UlrRejectCode) ||(DIAM_EXP_RESULT_CODE_ERROR_UNKNOWN_EPS_SUBSCRIPTION == m_UlrRejectCode) || (DIAM_EXP_RESULT_CODE_ERROR_RAT_NOT_ALLOWED == m_UlrRejectCode) )
   {
      LLOG(0,0,"ULR_REJECT_CODE value [%d]",m_UlrRejectCode);
   }
   else
   {
      ELOG(0,0,"ULR_REJECT_CODE value[%d] should be 5001[USER_UNKNOWN] 5004[ROAMING_NOT_ALLOWED] 5420[UNKNOWN_EPS_SUBSCRIPTION] 5421[RAT_NOT_ALLOWED]",m_UlrRejectCode);
   }

   if( false == readInteger(l_mm, "ACTIVE_APN_UPDATE_ENABLE", m_ActiveApnUpdateFlag, 0, 1))
      return false;
   LLOG(0,0,"ACTIVE_APN_UPDATE_ENABLE value [%d]",m_ActiveApnUpdateFlag);

   if( false == readInteger(l_mm, "ULR_MEMCACHED_FLAG", m_ULRMemcachedFlag, 0, 1))
      return false;
   LLOG(0,0,"ULR_MEMCACHED_FLAG value [%d]",m_ULRMemcachedFlag);
   
   if( false == readInteger(l_mm, "ULR_MEMCACHED_RECORD_TIME", m_ULRMemcachedRecordTime, 0, 8640000))
      return false;
   LLOG(0,0,"ULR_MEMCACHED_RECORD_TIME in seconds value [%d]",m_ULRMemcachedRecordTime);

   if( false == readInteger(l_mm, "ULR_ACCESS_RESTRICTION", m_ULRAccessRestriction, 0, 2147483647))
            return false;
      LLOG(0,0,"ULR_ACCESS_RESTRICTION value [%d]",m_ULRAccessRestriction);

   m_derivedObjectInitializedFlag=true;
   return true;

}

void LteMmConfigReader::printConfigData(char *p_output)
{
   sprintf(p_output,"\t\t%s: %d\t\t%s: %d\t\t%s: %d\n\t\t%s: %d\t\t%s: %d\n", 
         "UlrRejectCode",m_UlrRejectCode,
         "ActiveApnUpdateEnable",m_ActiveApnUpdateFlag,
         "ULRMemcachedFlag",m_ULRMemcachedFlag, 
         "ULRMemcachedRecordTime",m_ULRMemcachedRecordTime,
         "ULRAccessRestriction",m_ULRAccessRestriction);
}

