echo "Compiling AsnCodec..."
/usr/sfw/bin/gcc -c   ../src/AsnCodec.cpp -fPIC -I../inc/ -I../../MAP1/inc -I../../MAP2/inc -I../../MAP3/inc -I/usr/local/ossasn1/solaris7-64bit/8.3.1/include/ -D_REENTRANT -DC7_Q -g -m64 -w -DUNIX_PORT -m64 -D_REENTRANT -DC7_Q -Wall -g  -DMULTITHREAD -DAAA -Wno-deprecated

echo "Compiling DataUnion..."
/usr/sfw/bin/gcc -c   ../src/DataUnion.cpp -fPIC -I../inc/ -I../../MAP1/inc -I../../MAP2/inc -I../../MAP3/inc -I/usr/local/ossasn1/solaris7-64bit/8.3.1/include/ -D_REENTRANT -DC7_Q -g -m64 -w -DUNIX_PORT -m64 -D_REENTRANT -DC7_Q -Wall -g  -DMULTITHREAD -DAAA -Wno-deprecated

echo "Compiling MapConstants..."
/usr/sfw/bin/gcc -c   ../src/MapConstants.cpp -fPIC -I../inc/ -I../../MAP1/inc -I../../MAP2/inc -I../../MAP3/inc -I/usr/local/ossasn1/solaris7-64bit/8.3.1/include/ -D_REENTRANT -DC7_Q -g -m64 -w -DUNIX_PORT -m64 -D_REENTRANT -DC7_Q -Wall -g  -DMULTITHREAD -DAAA -Wno-deprecated

echo "Compiling RedirectConsole..."
/usr/sfw/bin/gcc -c   ../src/RedirectConsole.cpp -fPIC -I../inc/ -I../../MAP1/inc -I../../MAP2/inc -I../../MAP3/inc -I/usr/local/ossasn1/solaris7-64bit/8.3.1/include/ -D_REENTRANT -DC7_Q -g -m64 -w -DUNIX_PORT -m64 -D_REENTRANT -DC7_Q -Wall -g  -DMULTITHREAD -DAAA -Wno-deprecated

echo "Compiling ExtContainerParser..."
/usr/sfw/bin/gcc -c   ../src/ExtContainerParser.cpp -fPIC -I../inc/ -I../../MAP1/inc -I../../MAP2/inc -I../../MAP3/inc -I/usr/local/ossasn1/solaris7-64bit/8.3.1/include/ -D_REENTRANT -DC7_Q -g -m64 -w -DUNIX_PORT -m64 -D_REENTRANT -DC7_Q -Wall -g  -DMULTITHREAD -DAAA -Wno-deprecated

echo "Compiling ExtParserBase..."
/usr/sfw/bin/gcc -c   ../src/ExtParserBase.cpp -fPIC -I../inc/ -I../../MAP1/inc -I../../MAP2/inc -I../../MAP3/inc -I/usr/local/ossasn1/solaris7-64bit/8.3.1/include/ -D_REENTRANT -DC7_Q -g -m64 -w -DUNIX_PORT -m64 -D_REENTRANT -DC7_Q -Wall -g  -DMULTITHREAD -DAAA -Wno-deprecated

echo "Compiling ConstantsLogOverride..."
/usr/sfw/bin/gcc -c   ../src/ConstantsLogOverride.cpp -fPIC -I../inc/ -I../../MAP1/inc -I../../MAP2/inc -I../../MAP3/inc -I/usr/local/ossasn1/solaris7-64bit/8.3.1/include/ -D_REENTRANT -DC7_Q -g -m64 -w -DUNIX_PORT -m64 -D_REENTRANT -DC7_Q -Wall -g  -DMULTITHREAD -DAAA -Wno-deprecated

echo "Generating libmap-constants.so..."
/usr/sfw/bin/gcc -o libmap-constants.so  -shared MapConstants.o AsnCodec.o RedirectConsole.o DataUnion.o ExtContainerParser.o ExtParserBase.o ConstantsLogOverride.o -g -m64 -w -m64 -Wall -Wno-deprecated

mv libmap-constants.so ../lib/
