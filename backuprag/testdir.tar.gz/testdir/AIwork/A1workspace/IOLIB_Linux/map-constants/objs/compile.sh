OSS_NOKALVA_HOME=/usr/local/ossasn1/linux-x86-64/10.5.0/
GCC_BIN=/usr/bin/gcc
echo "Compiling AsnCodec..."
$GCC_BIN -c   ../src/AsnCodec.cpp -DOSSPRINT -DOSSDEBUG=2 -fPIC -I../inc/ -I../../MAP1/inc -I../../MAP2/inc -I../../MAP3/inc -I$OSS_NOKALVA_HOME/include/ -D_REENTRANT -DC7_Q -g -m64 -w -DUNIX_PORT -DLinux -m64 -D_REENTRANT -DC7_Q -Wall -g  -DMULTITHREAD -DAAA -Wno-deprecated

echo "Compiling DataUnion..."
$GCC_BIN -c   ../src/DataUnion.cpp -DOSSPRINT -DOSSDEBUG=2 -fPIC -I../inc/ -I../../MAP1/inc -I../../MAP2/inc -I../../MAP3/inc -I$OSS_NOKALVA_HOME/include/ -D_REENTRANT -DC7_Q -g -m64 -w -DUNIX_PORT -DLinux -m64 -D_REENTRANT -DC7_Q -Wall -g  -DMULTITHREAD -DAAA -Wno-deprecated

echo "Compiling MapConstants..."
$GCC_BIN -c   ../src/MapConstants.cpp -DOSSPRINT -DOSSDEBUG=2 -fPIC -I../inc/ -I../../MAP1/inc -I../../MAP2/inc -I../../MAP3/inc -I$OSS_NOKALVA_HOME/include/ -D_REENTRANT -DC7_Q -g -m64 -w -DUNIX_PORT -DLinux -m64 -D_REENTRANT -DC7_Q -Wall -g  -DMULTITHREAD -DAAA -Wno-deprecated

echo "Compiling RedirectConsole..."
$GCC_BIN -c   ../src/RedirectConsole.cpp -DOSSPRINT -DOSSDEBUG=2 -fPIC -I../inc/ -I../../MAP1/inc -I../../MAP2/inc -I../../MAP3/inc -I$OSS_NOKALVA_HOME/include/ -D_REENTRANT -DC7_Q -g -m64 -w -DUNIX_PORT -DLinux -m64 -D_REENTRANT -DC7_Q -Wall -g  -DMULTITHREAD -DAAA -Wno-deprecated

echo "Compiling ExtContainerParser..."
$GCC_BIN -c   ../src/ExtContainerParser.cpp -DOSSPRINT -DOSSDEBUG=2 -fPIC -I../inc/ -I../../MAP1/inc -I../../MAP2/inc -I../../MAP3/inc -I$OSS_NOKALVA_HOME/include/ -D_REENTRANT -DC7_Q -g -m64 -w -DUNIX_PORT -DLinux -m64 -D_REENTRANT -DC7_Q -Wall -g  -DMULTITHREAD -DAAA -Wno-deprecated

echo "Compiling ExtParserBase..."
$GCC_BIN -c   ../src/ExtParserBase.cpp -fPIC -DOSSPRINT -DOSSDEBUG=2 -I../inc/ -I../../MAP1/inc -I../../MAP2/inc -I../../MAP3/inc -I$OSS_NOKALVA_HOME/include/ -D_REENTRANT -DC7_Q -g -m64 -w -DUNIX_PORT -DLinux -m64 -D_REENTRANT -DC7_Q -Wall -g  -DMULTITHREAD -DAAA -Wno-deprecated

echo "Compiling ConstantsLogOverride..."
$GCC_BIN -c   ../src/ConstantsLogOverride.cpp -DOSSPRINT -DOSSDEBUG=2 -fPIC -I../inc/ -I../../MAP1/inc -I../../MAP2/inc -I../../MAP3/inc -I$OSS_NOKALVA_HOME/include/ -D_REENTRANT -DC7_Q -g -m64 -w -DUNIX_PORT -DLinux -m64 -D_REENTRANT -DC7_Q -Wall -g  -DMULTITHREAD -DAAA -Wno-deprecated

echo "Generating libmap-constants.so..."
$GCC_BIN -o libmap-constants.so -DOSSPRINT -DOSSDEBUG=2  -shared MapConstants.o AsnCodec.o RedirectConsole.o DataUnion.o ExtContainerParser.o ExtParserBase.o ConstantsLogOverride.o -g -m64 -w -m64 -Wall -Wno-deprecated

mv libmap-constants.so ../lib/
