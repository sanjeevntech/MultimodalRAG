#include<stdio.h>

int main()
{
   unsigned char l_x=0x40;
   unsigned char l_y=0x40;

   unsigned char l_temp = l_x & l_y;

   printf("\n ### value of l_temp{%02x] \n",l_temp);
   return 0;
}
