#include <ExtParserBase.h>

ExtParserBase::ExtParserBase()
{
}

ExtParserBase::~ExtParserBase()
{
}

