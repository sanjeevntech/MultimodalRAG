#include <RedirectConsole.h>

RedirectConsole::RedirectConsole()
{
    //m_fd_file=open("test4.txt",O_WRONLY);//Uncomment for debugging
}

RedirectConsole::~RedirectConsole()
{
}

bool RedirectConsole::start()
{
    int l_pipe_result = pipe(m_arr);
    if (-1 == l_pipe_result)
    {
        return false;
    }
    dup2(m_arr[1], 1);
    return true;
}

bool RedirectConsole::end(char *p_data, int p_maxLength)
{
    read(m_arr[0], p_data, p_maxLength);
    //write(l_fd_file, buf_pipe, strlen(buf_pipe));//Uncomment for debugging

    FILE *l_file = fdopen(1, "w+");
    if (NULL == l_file)
    {
        //write(l_fd_file, "opening failure", sizeof("opening failure"));//Uncomment for debugging
        close(m_arr[0]);
        close(m_arr[1]);
        return false;
    }
    freopen("/dev/tty", "wa", l_file);
    close(m_arr[0]);
    close(m_arr[1]);
    return true;
}

