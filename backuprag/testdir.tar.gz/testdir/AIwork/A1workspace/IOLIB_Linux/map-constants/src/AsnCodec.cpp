#include <iostream>
#include <AsnCodec.h>

#include <IMAP1.h>
#include <IMAP2.h>
#include <IMAP3.h>
#include <OMAP1.h>
#include <OMAP2.h>
#include <OMAP3.h>
#include <RedirectConsole.h>

#ifdef Linux
extern void strlcat(char* p_desc, char*p_src, int p_size);
#endif

AsnCodec g_AsnCodecI1;
AsnCodec g_AsnCodecI2;
AsnCodec g_AsnCodecI3;
AsnCodec g_AsnCodecO1;
AsnCodec g_AsnCodecO2;
AsnCodec g_AsnCodecO3;

int      g_PrintPduToBufFlag;
char     g_PrintPduBuffer[MAX_PDU_SIZE+1];



int OSSTraceFunc(FILE *pFile, const char *format, ...)
{
#define nBufLen 1024
   va_list args;
   char szBuf[nBufLen];
   int nRC;
   memset(szBuf, '\0', nBufLen);

   va_start(args, format);
   nRC = vsnprintf(szBuf, nBufLen, format, args);
   va_end(args);
   strlcat(g_PrintPduBuffer, szBuf, MAX_PDU_SIZE);

   return nRC;
}



AsnCodec::AsnCodec()
{
   m_AsnWorld = &m_AsnW;
   m_initialized = 0;
}

AsnCodec::~AsnCodec()
{

}

AsnCodec *getAsnCodec(int p_mapVersion, char p_ioflag)
{
   if ('I' == p_ioflag)
   {
      switch (p_mapVersion)
      {
         case 1:
            return &g_AsnCodecI1;
            break;
         case 2:
            return &g_AsnCodecI2;
            break;
         case 3:
            return &g_AsnCodecI3;
            break;
         default:
            printf("\nUnknown MAP Version. Cannot Encode");
            return NULL;
            break;
      }
   }
   else
   {
      switch (p_mapVersion)
      {
         case 1:
            return &g_AsnCodecO1;
            break;
         case 2:
            return &g_AsnCodecO2;
            break;
         case 3:
            return &g_AsnCodecO3;
            break;
         default:
            printf("\nUnknown MAP Version. Cannot Encode");
            return NULL;
            break;
      }
   }
}


int AsnCodec::initialize(void* p_data) 
{
   int L_retCode ;
   m_AsnVal = p_data;
   return init();
}


int AsnCodec::init() 
{
   int L_retCode ;
   L_retCode = ossinit(m_AsnWorld, m_AsnVal);
   if(1 == g_PrintPduToBufFlag)
   {
      //printf("\nInitializing AsnCodec with asn1prnt func");
      m_AsnWorld->asn1prnt = OSSTraceFunc;
   }

   if(L_retCode) 
      return L_retCode;

   m_initialized = 1;
   return 0;
}

void AsnCodec::close() 
{
   if(m_initialized)
      //Release the OSS runtime resources
      ossterm(m_AsnWorld);

   m_initialized = 0;
}


void AsnCodec::printPdu(int p_msgType,void *p_dataStruct, char *p_direction) 
{
   if(!m_initialized)
      init();

   if(1 == g_PrintPduToBufFlag)
   {
      /*struct tm *l_timeStruct=NULL;
      char *l_dateString=NULL;
      time_t l_tim =time(NULL);
      l_timeStruct = localtime(&l_tim);
      l_dateString = asctime(l_timeStruct);
      l_dateString[24] = 0;*/

      memset(g_PrintPduBuffer, '\0', MAX_PDU_SIZE);
      sprintf(g_PrintPduBuffer, "\n%s MAP_PDU\n", p_direction);
   }

   ossPrintPDU(m_AsnWorld,p_msgType,p_dataStruct);

}

void AsnCodec::printPdu(int p_msgType,void *p_dataStruct, int p_consolePrintFlag, int p_logPrintFlag) 
{
   //Not used func
   if(!m_initialized)
      init();

   memset(g_PrintPduBuffer, '\0', MAX_PDU_SIZE);

   if (p_consolePrintFlag)
   {
      ossPrintPDU(m_AsnWorld,p_msgType,p_dataStruct);
   }

   if (p_logPrintFlag)
   {
      //printf("\nRedirecting printPdu called");
      REDIRECT_CONSOLE_TO_BUF(g_PrintPduBuffer, MAX_PDU_SIZE, ossPrintPDU(m_AsnWorld,p_msgType,p_dataStruct));
      //printf("\nPrinting the PDU Buffer: [[[[%s]]]]", g_PrintPduBuffer);
   }
}

void AsnCodec::freePdu(int p_msgType, void* p_data) 
{
   if(!m_initialized)
      init();

   //Free the decoded PDU allocated from OSS memory pool.
   if (0 != ossFreePDU(m_AsnWorld,p_msgType,p_data))
   {
      printf("\nERROR!!!!!!!!!!!!!!!!!!!!    OSS FREE FAILURE\n");
   }
   p_data = NULL;
}

void AsnCodec::freeBuf(unsigned char *p_buff)
{
   if(!m_initialized)
      init();

   //Free the encoded buffer once you are done with the useage
   //from the OSS memory pool
   ossFreeBuf(m_AsnWorld,p_buff);
   p_buff = NULL;
}

int AsnCodec::encode(void *p_dataStruct,int p_msgType, 
      unsigned char **p_encodedData, int *p_dataLength) 
{
   OssBuf L_ossBuf;
   int L_retCode;

   if(!m_initialized)
      init();

   L_ossBuf.value = *p_encodedData;
   L_ossBuf.length = *p_dataLength;

   L_retCode = ossEncode(m_AsnWorld,p_msgType,
         p_dataStruct,&L_ossBuf);

   if(L_retCode != 0) 
   {
      return L_retCode;
   }
   *p_encodedData = L_ossBuf.value;
   *p_dataLength = L_ossBuf.length;
   return 0; //All fine, no error.
}


int AsnCodec::decode(unsigned char *p_encodedData,int p_buffLen,int p_msgType,
      void **p_decodedStruct) 
{
   //printf("\nThis one");
   OssBuf L_encodedData;
   int L_retCode;

   if(!m_initialized)
      init();

   L_encodedData.value = p_encodedData;
   L_encodedData.length = p_buffLen;

   /*printf("\nAsnCodec::decode   Buffer received [%d] ", L_encodedData.length);
     for (int i=0; i<L_encodedData.length; i++)
     {
     printf(" 0x%02x", L_encodedData.value[i]);
     }
     printf("\n");*/

   L_retCode = ossDecode(m_AsnWorld,&p_msgType,
         &L_encodedData,p_decodedStruct) ;

   if(L_retCode != 0) 
   {
      return L_retCode;
   }

   return 0;
}


int AsnCodec::decode(unsigned char **p_encodedData,int p_buffLen,int p_msgType,
      void **p_decodedStruct) 
{
   OssBuf L_encodedData;
   int L_retCode;

   if(!m_initialized)
      init();

   L_encodedData.value = *p_encodedData;
   L_encodedData.length = p_buffLen;

   /*printf("\nAsnCodec::decode   Buffer received [%d] ", L_encodedData.length);
     for (int i=0; i<L_encodedData.length; i++)
     {
     printf(" 0x%02x", L_encodedData.value[i]);
     }
     printf("\n");*/

   L_retCode = ossDecode(m_AsnWorld,&p_msgType,
         &L_encodedData,p_decodedStruct) ;

   if(L_retCode != 0) 
   {
      return L_retCode;
   }

   return 0;
}

long AsnCodec::setDecodingLength(long p_bufferLength) 
{
   if(!m_initialized)
      init();

   return ossSetDecodingLength(m_AsnWorld,p_bufferLength);
}

long AsnCodec::getEncodingLength(int p_msgType,void *p_data)
{
   //printf("\nAsnCodec::getEncodingLength called");
   long L_long;

   if(!m_initialized)
      init();

   L_long =  ossDetermineEncodingLength(m_AsnWorld,p_msgType,p_data);

   return L_long;
}

char *AsnCodec::getErrMsg()
{
   char *L_charPtr;

   if(!m_initialized)
      init();

   L_charPtr =  ossGetErrMsg(m_AsnWorld);
   return L_charPtr;
}



bool initializeAsnCodecs(int p_flag)
{
   g_PrintPduToBufFlag = p_flag;


   printf("\n\t           . IMAP1 ASN.1 Codec...");
   if (g_AsnCodecI1.initialize(IMAP1) != 0)
   {
      return false;
   }

   printf("\n\t           . IMAP2 ASN.1 Codec...");
   if (g_AsnCodecI2.initialize(IMAP2) != 0)
   {
      return false;
   }

   printf("\n\t           . IMAP3 ASN.1 Codec...");
   if (g_AsnCodecI3.initialize(IMAP3) != 0)
   {
      return false;
   }

   printf("\n\t           . OMAP1 ASN.1 Codec...");
   if (g_AsnCodecO1.initialize(OMAP1) != 0)
   {
      return false;
   }

   printf("\n\t           . OMAP2 ASN.1 Codec...");
   if (g_AsnCodecO2.initialize(OMAP2) != 0)
   {
      return false;
   }

   printf("\n\t           . OMAP3 ASN.1 Codec...");
   if (g_AsnCodecO3.initialize(OMAP3) != 0)
   {
      return false;
   }

   return true;
}
