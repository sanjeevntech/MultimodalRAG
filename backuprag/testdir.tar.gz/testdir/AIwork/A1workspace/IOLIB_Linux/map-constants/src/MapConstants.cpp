/***********************************************************************************************************

Note: 
    1. This file should be strictly compatible with the MAP1, MAP2 and MAP3 header files
    2. Please use only spaces (never use tabs) in this file, and PLEASE KEEP THE ALREADY SPACING IN THE FILE INTACT
    3. If you are using vim to edit this file, do use "se nowrap" for convenience 


***********************************************************************************************************/


#include <MapConstants.h>
#include <IMAP1.h>
#include <IMAP2.h>
#include <IMAP3.h>

/* Timer Values: 
 * Symbol    Value        Time from the Spec
 * d         0            = This is just a default placeholder - NG would decide the default timer
 * s         1            = from 3 seconds to 10 seconds;
 * m         2            = from 15 seconds to 30 seconds;
 * ml        3            = from 1 minute to 10 minutes; 
 * l         4            = from 28 hours to 38 hours.
 * */

 /*
   0 - Confirmed service
   1 - Non-Confirmed service
 */


int g_MapOpCodeMapping[][15]=
{
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                 Valid Flag        MAP1 Arg PDU                           MAP2 Arg PDU                            MAP3 Arg PDU                                        MAP1 Res PDU                    MAP2 Res PDU                            MAP3 Res PDU                                            Timer Value         Conf/Non-Conf         ExtFlag v1   ExtVal v1  ExtFlag v2   ExtVal v2                                                  ExtFlag v3   ExtVal v3
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/* 00 */    /* MAP_OP_CODE_UNKNOWN=0 */                                            {0,               0,                                     0,                                      0,                                                  0,                              0,                                      0,                                                      0,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 01 */    /* MAP_OP_CODE_dummy_1 */                                              {0,               1,                                     1,                                      1,                                                  0,                              0,                                      0,                                                      0,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 02 */    /* MAP_OP_CODE_updateLocation */                                       {1,               IMAP1_UpdateLocationArg_PDU,           IMAP2_UpdateLocationArg_PDU,            IMAP3_UpdateLocationArg_PDU,                        IMAP1_UpdateLocationRes_PDU,    IMAP2_UpdateLocationRes_PDU,            IMAP3_UpdateLocationRes_PDU,                            2,                  0,                    0,           0,         1,           IMAP2_UpdateLocationArg_extensionContainer_present,        1,           IMAP3_UpdateLocationArg_extensionContainer_present                  },
/* 03 */    /* MAP_OP_CODE_cancelLocation */                                       {1,               IMAP1_CancelLocationArg_PDU,           IMAP2_CancelLocationArg_PDU,            IMAP3_CancelLocationArg_PDU,                        0,                              IMAP2_CancelLocationRes_PDU,            IMAP3_CancelLocationRes_PDU,                            2,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 04 */    /* MAP_OP_CODE_provideRoamingNumber */                                 {1,               IMAP1_ProvideRoamingNumberArg_PDU,     IMAP2_ProvideRoamingNumberArg_PDU,      IMAP3_ProvideRoamingNumberArg_PDU,                  IMAP1_ProvideRoamingNumberRes_PDU,IMAP2_ProvideRoamingNumberRes_PDU,    IMAP3_ProvideRoamingNumberRes_PDU,                      2,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 05 */    /* MAP_OP_CODE_noteSubscriberDataModified */                           {1,               0,                                     0,                                      IMAP3_NoteSubscriberDataModifiedArg_PDU,            0,                              0,                                      IMAP3_NoteSubscriberDataModifiedRes_PDU,                2,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 06 */    /* MAP_OP_CODE_resumeCallHandling */                                   {1,               0,                                     IMAP2_ResumeCallHandling_PDU,           IMAP3_ResumeCallHandlingArg_PDU,                    0,                              IMAP2_ResumeCallHandlingRes_PDU,        IMAP3_ResumeCallHandlingRes_PDU,                        2,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 07 */    /* MAP_OP_CODE_insertSubscriberData */                                 {1,               IMAP1_InsertSubscriberDataArg_PDU,     IMAP2_InsertSubscriberDataArg_PDU,      IMAP3_InsertSubscriberDataArg_PDU,                  0,                              IMAP2_InsertSubscriberDataRes_PDU,      IMAP3_InsertSubscriberDataRes_PDU,                      2,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 08 */    /* MAP_OP_CODE_deleteSubscriberData */                                 {1,               IMAP1_DeleteSubscriberDataArg_PDU,     IMAP2_DeleteSubscriberDataArg_PDU,      IMAP3_DeleteSubscriberDataArg_PDU,                  0,                              IMAP2_DeleteSubscriberDataRes_PDU,      IMAP3_DeleteSubscriberDataRes_PDU,                      2,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 09 */    /* MAP_OP_CODE_sendParameters */                                       {1,               IMAP1_SendParametersArg_PDU,           0,                                      0,                                                  IMAP1_SendParametersRes_PDU,    0,                                      0,                                                      2,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 10 */    /* MAP_OP_CODE_registerSS */                                           {1,               IMAP1_RegisterSSArg_PDU,               IMAP2_RegisterSSArg_PDU,                IMAP3_RegisterSS_Arg_PDU,                           IMAP1_RegisterSSRes_PDU,        IMAP2_RegisterSSRes_PDU,                IMAP3_SS_Info_PDU,                                      2,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 11 */    /* MAP_OP_CODE_eraseSS */                                              {1,               IMAP1_EraseSSArg_PDU,                  IMAP2_EraseSSArg_PDU,                   0,                                                  IMAP1_EraseSSRes_PDU,           IMAP2_EraseSSRes_PDU,                   0,                                                      2,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 12 */    /* MAP_OP_CODE_activateSS */                                           {1,               IMAP1_ActivateSSArg_PDU,               IMAP2_ActivateSSArg_PDU,                IMAP3_SS_ForBS_Code_PDU,                            IMAP1_ActivateSSRes_PDU,        IMAP2_ActivateSSRes_PDU,                IMAP3_SS_Info_PDU,                                      2,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 13 */    /* MAP_OP_CODE_deactivateSS */                                         {1,               IMAP1_DeactivateSSArg_PDU,             IMAP2_DeactivateSSArg_PDU,              IMAP3_SS_ForBS_Code_PDU,                            IMAP1_DeactivateSSRes_PDU,      IMAP2_DeactivateSSRes_PDU,              IMAP3_SS_Info_PDU,                                      2,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 14 */    /* MAP_OP_CODE_interrogateSS */                                        {1,               IMAP1_InterrogateSSArg_PDU,            IMAP2_InterrogateSSArg_PDU,             IMAP3_SS_ForBS_Code_PDU,                            IMAP1_InterrogateSSRes_PDU,     IMAP2_InterrogateSSRes_PDU,             IMAP3_SS_Info_PDU,                                      2,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 15 */    /* MAP_OP_CODE_authenticationFailureReport */                          {1,               0,                                     0,                                      IMAP3_AuthenticationFailureReportArg_PDU,           0,                              0,                                      IMAP3_AuthenticationFailureReportRes_PDU,               2,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 16 */    /* MAP_OP_CODE_dummy_16 */                                             {0,               0,                                     0,                                      0,                                                  0,                              0,                                      0,                                                      0,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 17 */    /* MAP_OP_CODE_registerPassword */                                     {1,               IMAP1_RegisterPasswordArg_PDU,         IMAP2_RegisterPasswordArg_PDU,          IMAP3_SS_Code_PDU,                                  IMAP1_RegisterPasswordRes_PDU,  IMAP2_RegisterPasswordRes_PDU,          IMAP3_Password_PDU,                                     3,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 18 */    /* MAP_OP_CODE_getPassword */                                          {1,               IMAP1_GetPasswordArg_PDU,              IMAP2_GetPasswordArg_PDU,               0,                                                  IMAP1_GetPasswordRes_PDU,       IMAP2_GetPasswordRes_PDU,               IMAP3_Password_PDU,                                     2,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 19 */    /* MAP_OP_CODE_processUnstructuredSsData */                            {1,               IMAP1_ProcessUnstructuredSsDataArg_PDU,0,                                      0,                                                  IMAP1_ProcessUnstructuredSsDataRes_PDU,0,                               0,                                                      3,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 20 */    /* MAP_OP_CODE_releaseResources */                                     {1,               0,                                     0,                                      IMAP3_ReleaseResourcesArg_PDU,                      0,                              0,                                      IMAP3_ReleaseResourcesRes_PDU,                          2,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 21 */    /* MAP_OP_CODE_mtForwardSMVGCS */                                      {1,               0,                                     IMAP2_MT_ForwardSM_Arg_PDU,             IMAP3_MT_ForwardSM_Arg_PDU,                         0,                              IMAP2_MT_ForwardSM_Res_PDU,             IMAP3_MT_ForwardSM_Res_PDU,                             3,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 22 */    /* MAP_OP_CODE_sendRoutingInfo */                                      {1,               IMAP1_SendRoutingInformationArg_PDU,   IMAP2_SendRoutingInfoArg_PDU,           IMAP3_SendRoutingInfoArg_PDU,                       IMAP1_SendRoutingInformationRes_PDU,IMAP2_SendRoutingInfoRes_PDU,       IMAP3_SendRoutingInfoRes_PDU,                           2,                  0,                    0,           0,         0,           0,                                                         1,           IMAP3_SendRoutingInfoArg_extensionContainer_present                 },
/* 23 */    /* MAP_OP_CODE_updateGprsLocation */                                   {1,               0,                                     0,                                      IMAP3_UpdateGprsLocationArg_PDU,                    0,                              0,                                      IMAP3_UpdateGprsLocationRes_PDU,                        2,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 24 */    /* MAP_OP_CODE_sendRoutingInfoForGprs */                               {1,               0,                                     0,                                      IMAP3_SendRoutingInfoForGprsArg_PDU,                0,                              IMAP2_SendRoutingInfoRes_PDU,           IMAP3_SendRoutingInfoForGprsRes_PDU,                    2,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 25 */    /* MAP_OP_CODE_failureReport */                                        {1,               0,                                     0,                                      IMAP3_FailureReportArg_PDU,                         0,                              0,                                      IMAP3_FailureReportRes_PDU,                             2,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 26 */    /* MAP_OP_CODE_noteMsPresentForGprs */                                 {1,               0,                                     0,                                      IMAP3_NoteMsPresentForGprsArg_PDU,                  0,                              0,                                      IMAP3_NoteMsPresentForGprsRes_PDU,                      2,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 27 */    /* MAP_OP_CODE_dummy_27 */                                             {0,               0,                                     0,                                      0,                                                  0,                              0,                                      0,                                                      0,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 28 */    /* MAP_OP_CODE_dummy_28 */                                             {0,               0,                                     0,                                      0,                                                  0,                              0,                                      0,                                                      0,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 29 */    /* MAP_OP_CODE_sendEndSignal */                                        {1,               IMAP1_SendEndSignal_PDU,               IMAP2_SendEndSignal_PDU,                IMAP3_SendEndSignal_Arg_PDU,                        0,                              0,                                      IMAP3_SendEndSignal_Res_PDU,                            4,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 30 */    /* MAP_OP_CODE_dummy_30 */                                             {0,               0,                                     0,                                      0,                                                  0,                              0,                                      0,                                                      0,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 31 */    /* MAP_OP_CODE_ProvideSIWFSNumber */                                   {1,               0,                                     0,                                      0,                                                  0,                              0,                                      0,                                                      0,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 32 */    /* MAP_OP_CODE_SIWFSSignallingModify */                                {1,               0,                                     0,                                      0,                                                  0,                              0,                                      0,                                                      0,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 33 */    /* MAP_OP_CODE_processAccessSignalling */                              {1,               IMAP1_ProcessAccessSignallingArg_PDU,  IMAP2_ProcessAccessSignalling_PDU,      IMAP3_ProcessAccessSignalling_Arg_PDU,              0,                              0,                                      0,                                                      1,                  1,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 34 */    /* MAP_OP_CODE_forwardAccessSignalling */                              {1,               IMAP1_ForwardAccessSignallingArg_PDU,  IMAP2_ForwardAccessSignalling_PDU,      IMAP3_ForwardAccessSignalling_Arg_PDU,              0,                              0,                                      0,                                                      1,                  1,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 35 */    /* MAP_OP_CODE_dummy_35 */                                             {0,               0,                                     0,                                      0,                                                  0,                              0,                                      0,                                                      0,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 36 */    /* MAP_OP_CODE_dummy_36 */                                             {0,               0,                                     0,                                      0,                                                  0,                              0,                                      0,                                                      0,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 37 */    /* MAP_OP_CODE_reset */                                                {1,               IMAP1_ResetArg_PDU,                    IMAP2_ResetArg_PDU,                     IMAP3_ResetArg_PDU,                                 0,                              0,                                      0,                                                      2,                  1,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 38 */    /* MAP_OP_CODE_forwardCheckSSIndication */                             {1,               0,                                     0,                                      0,                                                  0,                              0,                                      0,                                                      1,                  1,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 39 */    /* MAP_OP_CODE_prepareGroupCall */                                     {1,               0,                                     IMAP2_PrepareGroupCallArg_PDU,          IMAP3_PrepareGroupCallArg_PDU,                      0,                              IMAP2_PrepareGroupCallRes_PDU,          IMAP3_PrepareGroupCallRes_PDU,                          2,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 40 */    /* MAP_OP_CODE_sendGroupCallEndSignal */                               {1,               0,                                     IMAP2_SendGroupCallEndSignalArg_PDU,    IMAP3_SendGroupCallEndSignalArg_PDU,                0,                              IMAP2_SendGroupCallEndSignalRes_PDU,    IMAP3_SendGroupCallEndSignalRes_PDU,                    4,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 41 */    /* MAP_OP_CODE_processGroupCallSignalling */                           {1,               0,                                     IMAP2_ProcessGroupCallSignallingArg_PDU,IMAP3_ProcessGroupCallSignallingArg_PDU,            0,                              0,                                      0,                                                      1,                  1,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 42 */    /* MAP_OP_CODE_forwardGroupCallSignalling */                           {1,               0,                                     IMAP2_ForwardGroupCallSignallingArg_PDU,IMAP3_ForwardGroupCallSignallingArg_PDU,            0,                              0,                                      0,                                                      1,                  1,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 43 */    /* MAP_OP_CODE_checkIMEI */                                            {1,               IMAP1_CheckIMEArg_PDU,                 IMAP2_CheckIMEI_PDU,                    IMAP3_CheckIMEI_Arg_PDU,                            IMAP1_CheckIMEIRes_PDU,         0,                                      IMAP3_CheckIMEI_Res_PDU,                                2,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 44 */    /* MAP_OP_CODE_mtForwardSM */                                          {1,               0,                                     0,                                      IMAP3_MT_ForwardSM_Arg_PDU,                         0,                              0,                                      IMAP3_MT_ForwardSM_Res_PDU,                             3,                  0,                    0,0,1,IMAP2_MT_ForwardSM_Arg_extensionContainer_present,                 1,           IMAP3_MT_ForwardSM_Arg_extensionContainer_present           },
/* 45 */    /* MAP_OP_CODE_sendRoutingInfoForSM */                                 {1,               IMAP1_SendRoutingInfoForSMArg_PDU,     IMAP2_RoutingInfoForSM_Arg_PDU,         IMAP3_RoutingInfoForSM_Arg_PDU,                     IMAP1_SendRoutingInfoForSMRes_PDU,IMAP2_RoutingInfoForSM_Res_PDU,       IMAP3_RoutingInfoForSM_Res_PDU,                         2,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 46 */    /* MAP_OP_CODE_moForwardSM */                                          {1,               IMAP1_ForwardShortMessageArg_PDU,      IMAP2_MT_ForwardSM_Arg_PDU,             IMAP3_MO_ForwardSM_Arg_PDU,                                                  0,                              IMAP2_MT_ForwardSM_Res_PDU,             IMAP3_MO_ForwardSM_Res_PDU,                                                      3,                  0,                    0,0,1,IMAP2_MO_ForwardSM_Arg_extensionContainer_present,                 1,           IMAP3_MO_ForwardSM_Arg_extensionContainer_present           },
/* 47 */    /* MAP_OP_CODE_reportSMDeliveryStatus */                               {1,               IMAP1_SetMessageWaitingDataArg_PDU,    IMAP2_ReportSM_DeliveryStatusArg_PDU,   IMAP3_ReportSM_DeliveryStatusArg_PDU,               0,                              IMAP2_ReportSM_DeliveryStatusRes_PDU,   IMAP3_ReportSM_DeliveryStatusRes_PDU,                   1,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 48 */    /* MAP_OP_CODE_noteMsPresent */                                        {1,               IMAP1_NoteMSPresentArg_PDU,            0,                                      0,                                                  0,                              0,                                      0,                                                      0,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 49 */    /* MAP_OP_CODE_alertServiceCentre_v1 */                                {1,               IMAP1_AlertServiceCentreArg_PDU,       0,                                      0,                                                  0,                              0,                                      0,                                                      0,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 50 */    /* MAP_OP_CODE_activateTraceMode */                                    {1,               IMAP1_ActivateTraceModeArg_PDU,        IMAP2_ActivateTraceModeArg_PDU,         IMAP3_ActivateTraceModeArg_PDU,                     0,                              IMAP2_ActivateTraceModeRes_PDU,         IMAP3_ActivateTraceModeRes_PDU,                         2,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 51 */    /* MAP_OP_CODE_deactivateTraceMode */                                  {1,               IMAP1_DeactivateTraceModeArg_PDU,      IMAP2_DeactivateTraceModeArg_PDU,       IMAP3_DeactivateTraceModeArg_PDU,                   0,                              IMAP2_DeactivateTraceModeRes_PDU,       IMAP3_DeactivateTraceModeRes_PDU,                       2,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 52 */    /* MAP_OP_CODE_dummy_52 */                                             {0,               0,                                     0,                                      0,                                                  0,                              0,                                      0,                                                      0,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 53 */    /* MAP_OP_CODE_dummy_53 */                                             {0,               0,                                     0,                                      0,                                                  0,                              0,                                      0,                                                      0,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 54 */    /* MAP_OP_CODE_beginSubscriberActivity */                              {1,               IMAP1_BeginSubscriberActivityArg_PDU,  0,                                      0,                                                  0,                              0,                                      0,                                                      0,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 55 */    /* MAP_OP_CODE_sendIdentification */                                   {1,               0,                                     IMAP2_SendIdentification_PDU,           IMAP3_SendIdentificationArg_PDU,                    0,                              IMAP2_SendIdentificationRes_PDU,        IMAP3_SendIdentificationRes_PDU,                        1,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 56 */    /* MAP_OP_CODE_sendAuthenticationInfo */                               {1,               0,                                     IMAP2_SendAuthenticationInfoArg_PDU,    IMAP3_SendAuthenticationInfoArg_PDU,                0,                              IMAP2_SendAuthenticationInfoRes_PDU,    IMAP3_SendAuthenticationInfoRes_PDU,                    2,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 57 */    /* MAP_OP_CODE_restoreData */                                          {1,               0,                                     IMAP2_RestoreDataArg_PDU,               IMAP3_RestoreDataArg_PDU,                           0,                              IMAP2_RestoreDataRes_PDU,               IMAP3_RestoreDataRes_PDU,                               2,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 58 */    /* MAP_OP_CODE_sendIMSI */                                             {1,               0,                                     IMAP2_SendIMSIArg_PDU,                  IMAP3_SendIMSIArg_PDU,                              0,                              IMAP2_SendIMSIRes_PDU,                  IMAP3_SendIMSIRes_PDU,                                  2,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 59 */    /* MAP_OP_CODE_processUnstructuredSSRequest */                         {1,               0,                                     IMAP2_ProcessUnstructuredSS_RequestArg_PDU,0,                                               0,                              IMAP2_ProcessUnstructuredSS_RequestRes_PDU,0,                                                   3,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 60 */    /* MAP_OP_CODE_unstructuredSSRequest */                                {1,               0,                                     IMAP2_UnstructuredSS_RequestArg_PDU,    0,                                                  0,                              IMAP2_UnstructuredSS_RequestRes_PDU,    0,                                                      3,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 61 */    /* MAP_OP_CODE_unstructuredSSNotify */                                 {1,               0,                                     IMAP2_UnstructuredSS_NotifyArg_PDU,     0,                                                  0,                              0,                                      0,                                                      3,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 62 */    /* MAP_OP_CODE_anyTimeSubscriptionInterrogation */                     {1,               0,                                     0,                                      IMAP3_AnyTimeSubscriptionInterrogationArg_PDU,      0,                              0,                                      IMAP3_AnyTimeSubscriptionInterrogationRes_PDU,          2,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 63 */    /* MAP_OP_CODE_informServiceCentre */                                  {1,               0,                                     IMAP2_InformServiceCentreArg_PDU,       IMAP3_InformServiceCentreArg_PDU,                   0,                              0,                                      0,                                                      1,                  1,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 64 */    /* MAP_OP_CODE_alertServiceCentre */                                   {1,               0,                                     IMAP2_AlertServiceCentreArg_PDU,        IMAP3_AlertServiceCentreArg_PDU,                    0,                              0,                                      0,                                                      1,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 65 */    /* MAP_OP_CODE_anyTimeModification */                                  {1,               0,                                     0,                                      IMAP3_AnyTimeModificationArg_PDU,                   0,                              0,                                      IMAP3_AnyTimeModificationRes_PDU,                       2,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 66 */    /* MAP_OP_CODE_readyForSM */                                           {1,               0,                                     IMAP2_ReadyForSM_Arg_PDU,               IMAP3_ReadyForSM_Arg_PDU,                           0,                              IMAP2_ReadyForSM_Res_PDU,               IMAP3_ReadyForSM_Res_PDU,                               2,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 67 */    /* MAP_OP_CODE_purgeMS */                                              {1,               0,                                     IMAP2_PurgeMS_Arg_PDU,                  IMAP3_PurgeMS_Arg_PDU,                              0,                              IMAP2_PurgeMS_Res_PDU,                  IMAP3_PurgeMS_Res_PDU,                                  2,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 68 */    /* MAP_OP_CODE_prepareHandover */                                      {1,               0,                                     IMAP2_PrepareHO_Arg_PDU,                IMAP3_PrepareHO_Arg_PDU,                            0,                              IMAP2_PrepareHO_Res_PDU,                IMAP3_PrepareHO_Res_PDU,                                2,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 69 */    /* MAP_OP_CODE_prepareSubsequentHandover */                            {1,               0,                                     IMAP2_PrepareSubsequentHO_Arg_PDU,      IMAP3_PrepareSubsequentHO_Arg_PDU,                  0,                              0,                                      IMAP3_PrepareSubsequentHO_Res_PDU,                      2,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 70 */    /* MAP_OP_CODE_provideSubscriberInfo */                                {1,               0,                                     0,                                      IMAP3_ProvideSubscriberInfoArg_PDU,                 0,                              0,                                      IMAP3_ProvideSubscriberInfoRes_PDU,                     2,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 71 */    /* MAP_OP_CODE_anyTimeInterrogation */                                 {1,               0,                                     0,                                      IMAP3_AnyTimeInterrogationArg_PDU,                  0,                              0,                                      IMAP3_AnyTimeInterrogationRes_PDU,                      2,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 72 */    /* MAP_OP_CODE_ssInvocationNotification */                             {1,               0,                                     0,                                      IMAP3_SS_InvocationNotificationArg_PDU,             0,                              0,                                      IMAP3_SS_InvocationNotificationRes_PDU,                 2,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 73 */    /* MAP_OP_CODE_setReportingState */                                    {1,               0,                                     0,                                      IMAP3_SetReportingStateArg_PDU,                     0,                              0,                                      IMAP3_SetReportingStateRes_PDU,                         2,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 74 */    /* MAP_OP_CODE_statusReport */                                         {1,               0,                                     IMAP2_StatusReportArg_PDU,              IMAP3_StatusReportArg_PDU,                          0,                              IMAP2_StatusReportRes_PDU,              IMAP3_StatusReportRes_PDU,                              2,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 75 */    /* MAP_OP_CODE_remoteUserFree */                                       {1,               0,                                     0,                                      IMAP3_RemoteUserFreeArg_PDU,                        0,                              0,                                      IMAP3_RemoteUserFreeRes_PDU,                            3,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 76 */    /* MAP_OP_CODE_registerCCEntry */                                      {1,               0,                                     0,                                      IMAP3_RegisterCC_EntryArg_PDU,                      0,                              0,                                      IMAP3_RegisterCC_EntryRes_PDU,                          2,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 77 */    /* MAP_OP_CODE_eraseCCEntry */                                         {1,               0,                                     0,                                      0,                                                  0,                              0,                                      0,                                                      2,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 78 */    /* MAP_OP_CODE_dummy_78 */                                             {0,               0,                                     0,                                      0,                                                  0,                              0,                                      0,                                                      0,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 79 */    /* MAP_OP_CODE_dummy_79 */                                             {0,               0,                                     0,                                      0,                                                  0,                              0,                                      0,                                                      0,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 80 */    /* MAP_OP_CODE_dummy_80 */                                             {0,               0,                                     0,                                      0,                                                  0,                              0,                                      0,                                                      0,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 81 */    /* MAP_OP_CODE_dummy_81 */                                             {1,               0,                                     0,                                      0,                                                  0,                              0,                                      0,                                                      0,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 82 */    /* MAP_OP_CODE_dummy_82 */                                             {1,               0,                                     0,                                      0,                                                  0,                              0,                                      0,                                                      0,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 83 */    /* MAP_OP_CODE_provideSubscriberLocation */                            {1,               0,                                     0,                                      IMAP3_ProvideSubscriberLocation_Arg_PDU,            0,                              0,                                      IMAP3_ProvideSubscriberLocation_Res_PDU,                3,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 84 */    /* MAP_OP_CODE_sendGroupCallInfo */                                    {1,               0,                                     0,                                      0,                                                  0,                              0,                                      0,                                                      2,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 85 */    /* MAP_OP_CODE_sendRoutingInfoForLCS */                                {1,               0,                                     0,                                      IMAP3_RoutingInfoForLCS_Arg_PDU,                    0,                              0,                                      IMAP3_RoutingInfoForLCS_Res_PDU,                        2,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 86 */    /* MAP_OP_CODE_subscriberLocationReport */                             {1,               0,                                     0,                                      IMAP3_SubscriberLocationReport_Arg_PDU,             0,                              0,                                      IMAP3_SubscriberLocationReport_Res_PDU,                 2,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 87 */    /* MAP_OP_CODE_istAlert */                                             {1,               0,                                     0,                                      IMAP3_IST_AlertArg_PDU,                             0,                              0,                                      IMAP3_IST_AlertRes_PDU,                                 2,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 88 */    /* MAP_OP_CODE_istCommand */                                           {1,               0,                                     0,                                      IMAP3_IST_CommandArg_PDU,                           0,                              0,                                      IMAP3_IST_CommandRes_PDU,                               2,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 89 */    /* MAP_OP_CODE_noteMMEvent */                                          {1,               0,                                     0,                                      IMAP3_NoteMM_EventArg_PDU,                          0,                              0,                                      IMAP3_NoteMM_EventRes_PDU,                              2,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   },
/* 90 */    /* MAP_OP_CODE_dummy_90 */                                             {1,               1,                                     1,                                      1,                                                  0,                              0,                                      0,                                                      2,                  0,                    0,           0,         0,           0,                                                         0,           0                                                                   } 
};


char g_MapOpCodeChar[][100]=                                                            
{                                                                                       
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                  OP Code Name
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/* 00 */    /* MAP_OP_CODE_UNKNOWN=0 */                                             "UNKNOWN",                             
/* 01 */    /* MAP_OP_CODE_dummy_1 */                                               "op_dummy_1",                          
/* 02 */    /* MAP_OP_CODE_updateLocation */                                        "updateLocation",                   
/* 03 */    /* MAP_OP_CODE_cancelLocation */                                        "cancelLocation",                   
/* 04 */    /* MAP_OP_CODE_provideRoamingNumber */                                  "provideRoamingNumber",             
/* 05 */    /* MAP_OP_CODE_noteSubscriberDataModified */                            "noteSubscriberDataModified",       
/* 06 */    /* MAP_OP_CODE_resumeCallHandling */                                    "resumeCallHandling",               
/* 07 */    /* MAP_OP_CODE_insertSubscriberData */                                  "insertSubscriberData",             
/* 08 */    /* MAP_OP_CODE_deleteSubscriberData */                                  "deleteSubscriberData",             
/* 09 */    /* MAP_OP_CODE_sendParameters */                                        "sendParameters",                          
/* 10 */    /* MAP_OP_CODE_registerSS */                                            "registerSS",                       
/* 11 */    /* MAP_OP_CODE_eraseSS */                                               "eraseSS",                          
/* 12 */    /* MAP_OP_CODE_activateSS */                                            "activateSS",                       
/* 13 */    /* MAP_OP_CODE_deactivateSS */                                          "deactivateSS",                     
/* 14 */    /* MAP_OP_CODE_interrogateSS */                                         "interrogateSS",                    
/* 15 */    /* MAP_OP_CODE_authenticationFailureReport */                           "authenticationFailureReport",      
/* 16 */    /* MAP_OP_CODE_dummy_16 */                                              "op_dummy_16",                         
/* 17 */    /* MAP_OP_CODE_registerPassword */                                      "registerPassword",                 
/* 18 */    /* MAP_OP_CODE_getPassword */                                           "getPassword",                      
/* 19 */    /* MAP_OP_CODE_processUnstructuredSsData */                             "processUnstructuredSsData",                         
/* 20 */    /* MAP_OP_CODE_releaseResources */                                      "releaseResources",                 
/* 21 */    /* MAP_OP_CODE_mtForwardSMVGCS */                                       "mtForwardSMVGCS",                  
/* 22 */    /* MAP_OP_CODE_sendRoutingInfo */                                       "sendRoutingInfo",                  
/* 23 */    /* MAP_OP_CODE_updateGprsLocation */                                    "updateGprsLocation",               
/* 24 */    /* MAP_OP_CODE_sendRoutingInfoForGprs */                                "sendRoutingInfoForGprs",           
/* 25 */    /* MAP_OP_CODE_failureReport */                                         "failureReport",                    
/* 26 */    /* MAP_OP_CODE_noteMsPresentForGprs */                                  "noteMsPresentForGprs",             
/* 27 */    /* MAP_OP_CODE_dummy_27 */                                              "op_dummy_27",                         
/* 28 */    /* MAP_OP_CODE_dummy_28 */                                              "op_dummy_28",                         
/* 29 */    /* MAP_OP_CODE_sendEndSignal */                                         "sendEndSignal",                    
/* 30 */    /* MAP_OP_CODE_dummy_30 */                                              "op_dummy_30",                         
/* 31 */    /* MAP_OP_CODE_ProvideSIWFSNumber */                                    "ProvideSIWFSNumber",               
/* 32 */    /* MAP_OP_CODE_SIWFSSignallingModify */                                 "SIWFSSignallingModify",            
/* 33 */    /* MAP_OP_CODE_processAccessSignalling */                               "processAccessSignalling",          
/* 34 */    /* MAP_OP_CODE_forwardAccessSignalling */                               "forwardAccessSignalling",          
/* 35 */    /* MAP_OP_CODE_dummy_35 */                                              "op_dummy_35",                         
/* 36 */    /* MAP_OP_CODE_dummy_36 */                                              "op_dummy_36",                         
/* 37 */    /* MAP_OP_CODE_reset */                                                 "reset",                            
/* 38 */    /* MAP_OP_CODE_forwardCheckSSIndication */                              "forwardCheckSSIndication",         
/* 39 */    /* MAP_OP_CODE_prepareGroupCall */                                      "prepareGroupCall",                 
/* 40 */    /* MAP_OP_CODE_sendGroupCallEndSignal */                                "sendGroupCallEndSignal",           
/* 41 */    /* MAP_OP_CODE_processGroupCallSignalling */                            "processGroupCallSignalling",       
/* 42 */    /* MAP_OP_CODE_forwardGroupCallSignalling */                            "forwardGroupCallSignalling",       
/* 43 */    /* MAP_OP_CODE_checkIMEI */                                             "checkIMEI",                        
/* 44 */    /* MAP_OP_CODE_mtForwardSM */                                           "mtForwardSM",                      
/* 45 */    /* MAP_OP_CODE_sendRoutingInfoForSM */                                  "sendRoutingInfoForSM",             
/* 46 */    /* MAP_OP_CODE_moForwardSM */                                           "ForwardSM",                      
/* 47 */    /* MAP_OP_CODE_reportSMDeliveryStatus */                                "reportSMDeliveryStatus",           
/* 48 */    /* MAP_OP_CODE_noteMsPresent */                                         "noteMsPresent",                         
/* 49 */    /* MAP_OP_CODE_alertServiceCentre_v1 */                                 "alertServiceCentre_v1",                         
/* 50 */    /* MAP_OP_CODE_activateTraceMode */                                     "activateTraceMode",                
/* 51 */    /* MAP_OP_CODE_deactivateTraceMode */                                   "deactivateTraceMode",              
/* 52 */    /* MAP_OP_CODE_dummy_52 */                                              "op_dummy_52",                         
/* 53 */    /* MAP_OP_CODE_dummy_53 */                                              "op_dummy_53",                         
/* 54 */    /* MAP_OP_CODE_beginSubscriberActivity */                               "beginSubscriberActivity",          
/* 55 */    /* MAP_OP_CODE_sendIdentification */                                    "sendIdentification",               
/* 56 */    /* MAP_OP_CODE_sendAuthenticationInfo */                                "sendAuthenticationInfo",           
/* 57 */    /* MAP_OP_CODE_restoreData */                                           "restoreData",                      
/* 58 */    /* MAP_OP_CODE_sendIMSI */                                              "sendIMSI",                         
/* 59 */    /* MAP_OP_CODE_processUnstructuredSSRequest */                          "processUnstructuredSSRequest",     
/* 60 */    /* MAP_OP_CODE_unstructuredSSRequest */                                 "unstructuredSSRequest",            
/* 61 */    /* MAP_OP_CODE_unstructuredSSNotify */                                  "unstructuredSSNotify",             
/* 62 */    /* MAP_OP_CODE_anyTimeSubscriptionInterrogation */                      "anyTimeSubscriptionInterrogation", 
/* 63 */    /* MAP_OP_CODE_informServiceCentre */                                   "informServiceCentre",              
/* 64 */    /* MAP_OP_CODE_alertServiceCentre */                                    "alertServiceCentre",               
/* 65 */    /* MAP_OP_CODE_anyTimeModification */                                   "anyTimeModification",              
/* 66 */    /* MAP_OP_CODE_readyForSM */                                            "readyForSM",                       
/* 67 */    /* MAP_OP_CODE_purgeMS */                                               "purgeMS",                          
/* 68 */    /* MAP_OP_CODE_prepareHandover */                                       "prepareHandover",                  
/* 69 */    /* MAP_OP_CODE_prepareSubsequentHandover */                             "prepareSubsequentHandover",        
/* 70 */    /* MAP_OP_CODE_provideSubscriberInfo */                                 "provideSubscriberInfo",            
/* 71 */    /* MAP_OP_CODE_anyTimeInterrogation */                                  "anyTimeInterrogation",             
/* 72 */    /* MAP_OP_CODE_ssInvocationNotification */                              "ssInvocationNotification",         
/* 73 */    /* MAP_OP_CODE_setReportingState */                                     "setReportingState",                
/* 74 */    /* MAP_OP_CODE_statusReport */                                          "statusReport",                     
/* 75 */    /* MAP_OP_CODE_remoteUserFree */                                        "remoteUserFree",                   
/* 76 */    /* MAP_OP_CODE_registerCCEntry */                                       "registerCCEntry",                  
/* 77 */    /* MAP_OP_CODE_eraseCCEntry */                                          "eraseCCEntry",                     
/* 78 */    /* MAP_OP_CODE_dummy_78 */                                              "op_dummy_78",                         
/* 79 */    /* MAP_OP_CODE_dummy_79 */                                              "op_dummy_79",                         
/* 80 */    /* MAP_OP_CODE_dummy_80 */                                              "op_dummy_80",                         
/* 81 */    /* MAP_OP_CODE_dummy_81 */                                              "op_dummy_81",                         
/* 82 */    /* MAP_OP_CODE_dummy_82 */                                              "op_dummy_82",                         
/* 83 */    /* MAP_OP_CODE_provideSubscriberLocation */                             "provideSubscriberLocation",        
/* 84 */    /* MAP_OP_CODE_sendGroupCallInfo */                                     "sendGroupCallInfo",                
/* 85 */    /* MAP_OP_CODE_sendRoutingInfoForLCS */                                 "sendRoutingInfoForLCS",            
/* 86 */    /* MAP_OP_CODE_subscriberLocationReport */                              "subscriberLocationReport",         
/* 87 */    /* MAP_OP_CODE_istAlert */                                              "istAlert",                         
/* 88 */    /* MAP_OP_CODE_istCommand */                                            "istCommand",                       
/* 89 */    /* MAP_OP_CODE_noteMMEvent */                                           "noteMMEvent",
/* 90 */    /* MAP_OP_CODE_dummy_90 */                                              "op_dummy_90"                           
};                                                                                      












int g_MapApplCtxtMapping[][2]=
{
//////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                      MIN VERSION      MAX VERSION
//////////////////////////////////////////////////////////////////////////////////////////////////////
/* 00 */   /* MAP_AC_UNKNOWN=0 */                                       {0,              0},
/* 01 */   /* MAP_AC_CODE_networkLocUp */                               {1,              3},
/* 02 */   /* MAP_AC_CODE_locationCancel */                             {1,              3},
/* 03 */   /* MAP_AC_CODE_roamingNbEnquiry */                           {1,              3},
/* 04 */   /* MAP_AC_CODE_IST_Alerting */                               {3,              3},
/* 05 */   /* MAP_AC_CODE_locInfoRetrieval */                           {1,              3},
/* 06 */   /* MAP_AC_CODE_callControlTransfer */                        {3,              4},
/* 07 */   /* MAP_AC_CODE_reporting */                                  {3,              3},
/* 08 */   /* MAP_AC_CODE_callCompletion */                             {3,              3},
/* 09 */   /* MAP_AC_CODE_ServiceTermination */                         {3,              3},
/* 10 */   /* MAP_AC_CODE_reset */                                      {1,              3},
/* 11 */   /* MAP_AC_CODE_handoverControl */                            {1,              3},
/* 12 */   /* MAP_AC_CODE_sIWFSAllocation */                            {3,              3},
/* 13 */   /* MAP_AC_CODE_equipmentMngt */                              {1,              3},
/* 14 */   /* MAP_AC_CODE_infoRetrieval */                              {1,              3},
/* 15 */   /* MAP_AC_CODE_interVlrInfoRetrieval */                      {1,              3},
/* 16 */   /* MAP_AC_CODE_subscriberDataMngt */                         {1,              3},
/* 17 */   /* MAP_AC_CODE_tracing */                                    {1,              3},
/* 18 */   /* MAP_AC_CODE_networkFunctionalSs */                        {1,              2},
/* 19 */   /* MAP_AC_CODE_networkUnstructuredSs */                      {1,              2},
/* 20 */   /* MAP_AC_CODE_shortMsgGateway */                            {1,              3},
/* 21 */   /* MAP_AC_CODE_shortMsgMORelay */                            {1,              3},
/* 22 */   /* MAP_AC_CODE_subscriberDataModificationNotification */     {3,              3},
/* 23 */   /* MAP_AC_CODE_shortMsgAlert */                              {1,              3},
/* 24 */   /* MAP_AC_CODE_mwdMngt */                                    {1,              3},
/* 25 */   /* MAP_AC_CODE_shortMsgMTRelay */                            {1,              3},
/* 26 */   /* MAP_AC_CODE_imsiRetrieval */                              {2,              3},
/* 27 */   /* MAP_AC_CODE_msPurging */                                  {2,              3},
/* 28 */   /* MAP_AC_CODE_subscriberInfoEnquiry */                      {3,              3},
/* 29 */   /* MAP_AC_CODE_anyTimeEnquiry */                             {3,              3},
/* 30 */   /* MAP_AC_CODE_dummy_30 */                                   {0,              0},
/* 31 */   /* MAP_AC_CODE_groupCallControl */                           {3,              3},
/* 32 */   /* MAP_AC_CODE_gprsLocationUpdate */                         {3,              3},
/* 33 */   /* MAP_AC_CODE_gprsLocationInfoRetrieval */                  {3,              4},
/* 34 */   /* MAP_AC_CODE_failureReport */                              {3,              3},
/* 35 */   /* MAP_AC_CODE_gprsNotify */                                 {3,              3},
/* 36 */   /* MAP_AC_CODE_ssInvocationNotification */                   {3,              3},
/* 37 */   /* MAP_AC_CODE_locationSvcGateway */                         {3,              3},
/* 38 */   /* MAP_AC_CODE_locationSvcEnquiry */                         {3,              3},
/* 39 */   /* MAP_AC_CODE_authenticationFailureReport */                {3,              3},
/* 40 */   /* MAP_AC_CODE_dummy_40 */                                   {3,              3},
/* 41 */   /* MAP_AC_CODE_shortMsgMT_Relay_VGCS */                      {3,              3},
/* 42 */   /* MAP_AC_CODE_mm_EventReporting */                          {3,              3},
/* 43 */   /* MAP_AC_CODE_anyTimeInfoHandling */                        {3,              3},
/* 44 */   /* MAP_AC_CODE_resourceManagement */                         {3,              3},
/* 45 */   /* MAP_AC_CODE_groupCallInfoRetrieval */                     {3,              3}
};


char g_MapApplCtxtMappingChar[][100]=
{
//////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                          Appl Ctxt Name
//////////////////////////////////////////////////////////////////////////////////////////////////////
/* 00 */   /* MAP_AC_UNKNOWN=0 */                                           "ac_unknown",                             
/* 01 */   /* MAP_AC_CODE_networkLocUp */                                   "networkLocUp",                                          
/* 02 */   /* MAP_AC_CODE_locationCancel */                                 "locationCancel",                          
/* 03 */   /* MAP_AC_CODE_roamingNbEnquiry */                               "roamingNbEnquiry",                        
/* 04 */   /* MAP_AC_CODE_IST_Alerting */                                   "IST_Alerting",                            
/* 05 */   /* MAP_AC_CODE_locInfoRetrieval */                               "locInfoRetrieval",                        
/* 06 */   /* MAP_AC_CODE_callControlTransfer */                            "callControlTransfer",                     
/* 07 */   /* MAP_AC_CODE_reporting */                                      "reporting",                               
/* 08 */   /* MAP_AC_CODE_callCompletion */                                 "callCompletion",                          
/* 09 */   /* MAP_AC_CODE_ServiceTermination */                             "ServiceTermination",                      
/* 10 */   /* MAP_AC_CODE_reset */                                          "reset",                                   
/* 11 */   /* MAP_AC_CODE_handoverControl */                                "handoverControl",                         
/* 12 */   /* MAP_AC_CODE_sIWFSAllocation */                                "sIWFSAllocation",                         
/* 13 */   /* MAP_AC_CODE_equipmentMngt */                                  "equipmentMngt",                           
/* 14 */   /* MAP_AC_CODE_infoRetrieval */                                  "infoRetrieval",                           
/* 15 */   /* MAP_AC_CODE_interVlrInfoRetrieval */                          "interVlrInfoRetrieval",                   
/* 16 */   /* MAP_AC_CODE_subscriberDataMngt */                             "subscriberDataMngt",                      
/* 17 */   /* MAP_AC_CODE_tracing */                                        "tracing",                                 
/* 18 */   /* MAP_AC_CODE_networkFunctionalSs */                            "networkFunctionalSs",                     
/* 19 */   /* MAP_AC_CODE_networkUnstructuredSs */                          "networkUnstructuredSs",                   
/* 20 */   /* MAP_AC_CODE_shortMsgGateway */                                "shortMsgGateway",                         
/* 21 */   /* MAP_AC_CODE_shortMsgMORelay */                                "shortMsgMORelay",                         
/* 22 */   /* MAP_AC_CODE_subscriberDataModificationNotification */         "subscriberDataModificationNotification",  
/* 23 */   /* MAP_AC_CODE_shortMsgAlert */                                  "shortMsgAlert",                           
/* 24 */   /* MAP_AC_CODE_mwdMngt */                                        "mwdMngt",                                 
/* 25 */   /* MAP_AC_CODE_shortMsgMTRelay */                                "shortMsgMTRelay",                         
/* 26 */   /* MAP_AC_CODE_imsiRetrieval */                                  "imsiRetrieval",                           
/* 27 */   /* MAP_AC_CODE_msPurging */                                      "msPurging",                               
/* 28 */   /* MAP_AC_CODE_subscriberInfoEnquiry */                          "subscriberInfoEnquiry",                   
/* 29 */   /* MAP_AC_CODE_anyTimeEnquiry */                                 "anyTimeEnquiry",                          
/* 30 */   /* MAP_AC_CODE_dummy_30 */                                       "ac_dummy_30",                                
/* 31 */   /* MAP_AC_CODE_groupCallControl */                               "groupCallControl",                        
/* 32 */   /* MAP_AC_CODE_gprsLocationUpdate */                             "gprsLocationUpdate",                      
/* 33 */   /* MAP_AC_CODE_gprsLocationInfoRetrieval */                      "gprsLocationInfoRetrieval",               
/* 34 */   /* MAP_AC_CODE_failureReport */                                  "ac_failureReport",                           
/* 35 */   /* MAP_AC_CODE_gprsNotify */                                     "gprsNotify",                              
/* 36 */   /* MAP_AC_CODE_ssInvocationNotification */                       "ssInvocationNotification",                
/* 37 */   /* MAP_AC_CODE_locationSvcGateway */                             "locationSvcGateway",                      
/* 38 */   /* MAP_AC_CODE_locationSvcEnquiry */                             "locationSvcEnquiry",                      
/* 39 */   /* MAP_AC_CODE_authenticationFailureReport */                    "ac_authenticationFailureReport",             
/* 40 */   /* MAP_AC_CODE_dummy_40 */                                       "ac_dummy_40",                                
/* 41 */   /* MAP_AC_CODE_shortMsgMT_Relay_VGCS */                          "shortMsgMT_Relay_VGCS",                   
/* 42 */   /* MAP_AC_CODE_mm_EventReporting */                              "mm_EventReporting",                       
/* 43 */   /* MAP_AC_CODE_anyTimeInfoHandling */                            "anyTimeInfoHandling",                     
/* 44 */   /* MAP_AC_CODE_resourceManagement */                             "resourceManagement",                      
/* 45 */   /* MAP_AC_CODE_groupCallInfoRetrieval */                         "groupCallInfoRetrieval"                  
};








int g_ApplCtxtOpCodeMapping[][2]=
{
//////////////////////////////////////////////////////////////////////////////////////////////////////
//          Appl Context                                            Op Code Supported
//////////////////////////////////////////////////////////////////////////////////////////////////////

        {(int)MAP_AC_CODE_locationCancel,                           (int)MAP_OP_CODE_cancelLocation},
        {(int)MAP_AC_CODE_equipmentMngt,                            (int)MAP_OP_CODE_checkIMEI},
        {(int)MAP_AC_CODE_imsiRetrieval,                            (int)MAP_OP_CODE_sendIMSI},
        {(int)MAP_AC_CODE_infoRetrieval,                            (int)MAP_OP_CODE_sendAuthenticationInfo},
        {(int)MAP_AC_CODE_infoRetrieval,                            (int)MAP_OP_CODE_sendParameters},
        {(int)MAP_AC_CODE_interVlrInfoRetrieval,                    (int)MAP_OP_CODE_sendIdentification},
        {(int)MAP_AC_CODE_handoverControl,                          (int)MAP_OP_CODE_prepareHandover},
        {(int)MAP_AC_CODE_handoverControl,                          (int)MAP_OP_CODE_forwardAccessSignalling},
        {(int)MAP_AC_CODE_handoverControl,                          (int)MAP_OP_CODE_sendEndSignal},
        {(int)MAP_AC_CODE_handoverControl,                          (int)MAP_OP_CODE_processAccessSignalling},
        {(int)MAP_AC_CODE_handoverControl,                          (int)MAP_OP_CODE_prepareSubsequentHandover},
        {(int)MAP_AC_CODE_mwdMngt,                                  (int)MAP_OP_CODE_readyForSM},
        {(int)MAP_AC_CODE_msPurging,                                (int)MAP_OP_CODE_purgeMS},
        {(int)MAP_AC_CODE_shortMsgAlert,                            (int)MAP_OP_CODE_alertServiceCentre},
        {(int)MAP_AC_CODE_shortMsgAlert,                            (int)MAP_OP_CODE_alertServiceCentre_v1},
        {(int)MAP_AC_CODE_reset,                                    (int)MAP_OP_CODE_reset},
        {(int)MAP_AC_CODE_networkUnstructuredSs,                    (int)MAP_OP_CODE_processUnstructuredSSRequest},
        {(int)MAP_AC_CODE_networkUnstructuredSs,                    (int)MAP_OP_CODE_unstructuredSSRequest},
        {(int)MAP_AC_CODE_networkUnstructuredSs,                    (int)MAP_OP_CODE_unstructuredSSNotify},
        {(int)MAP_AC_CODE_networkUnstructuredSs,                    (int)MAP_OP_CODE_beginSubscriberActivity},
        {(int)MAP_AC_CODE_networkUnstructuredSs,                    (int)MAP_OP_CODE_processUnstructuredSsData},
        {(int)MAP_AC_CODE_tracing,                                  (int)MAP_OP_CODE_activateTraceMode},
        {(int)MAP_AC_CODE_tracing,                                  (int)MAP_OP_CODE_deactivateTraceMode},
        {(int)MAP_AC_CODE_networkFunctionalSs,                      (int)MAP_OP_CODE_beginSubscriberActivity},
        {(int)MAP_AC_CODE_networkFunctionalSs,                      (int)MAP_OP_CODE_registerSS},
        {(int)MAP_AC_CODE_networkFunctionalSs,                      (int)MAP_OP_CODE_eraseSS},
        {(int)MAP_AC_CODE_networkFunctionalSs,                      (int)MAP_OP_CODE_activateSS},
        {(int)MAP_AC_CODE_networkFunctionalSs,                      (int)MAP_OP_CODE_deactivateSS},
        {(int)MAP_AC_CODE_networkFunctionalSs,                      (int)MAP_OP_CODE_registerPassword},
        {(int)MAP_AC_CODE_networkFunctionalSs,                      (int)MAP_OP_CODE_interrogateSS},
        {(int)MAP_AC_CODE_networkFunctionalSs,                      (int)MAP_OP_CODE_getPassword},
        {(int)MAP_AC_CODE_networkFunctionalSs,                      (int)MAP_OP_CODE_processUnstructuredSsData},
        {(int)MAP_AC_CODE_shortMsgMORelay,                          (int)MAP_OP_CODE_moForwardSM},
        {(int)MAP_AC_CODE_shortMsgMTRelay,                          (int)MAP_OP_CODE_moForwardSM},
        {(int)MAP_AC_CODE_shortMsgMTRelay,                          (int)MAP_OP_CODE_mtForwardSM},
        {(int)MAP_AC_CODE_shortMsgMT_Relay_VGCS,                    (int)MAP_OP_CODE_mtForwardSMVGCS},
        {(int)MAP_AC_CODE_shortMsgGateway,                          (int)MAP_OP_CODE_sendRoutingInfoForSM},
        {(int)MAP_AC_CODE_shortMsgGateway,                          (int)MAP_OP_CODE_reportSMDeliveryStatus},
        {(int)MAP_AC_CODE_shortMsgGateway,                          (int)MAP_OP_CODE_informServiceCentre},
        {(int)MAP_AC_CODE_networkLocUp,                             (int)MAP_OP_CODE_updateLocation},
        {(int)MAP_AC_CODE_networkLocUp,                             (int)MAP_OP_CODE_forwardCheckSSIndication},
        {(int)MAP_AC_CODE_networkLocUp,                             (int)MAP_OP_CODE_restoreData},
        {(int)MAP_AC_CODE_networkLocUp,                             (int)MAP_OP_CODE_insertSubscriberData},
        {(int)MAP_AC_CODE_networkLocUp,                             (int)MAP_OP_CODE_activateTraceMode},
        {(int)MAP_AC_CODE_networkLocUp,                             (int)MAP_OP_CODE_sendParameters},
        {(int)MAP_AC_CODE_gprsLocationUpdate,                       (int)MAP_OP_CODE_updateGprsLocation},
        {(int)MAP_AC_CODE_gprsLocationUpdate,                       (int)MAP_OP_CODE_insertSubscriberData},
        {(int)MAP_AC_CODE_gprsLocationUpdate,                       (int)MAP_OP_CODE_activateTraceMode},
        {(int)MAP_AC_CODE_subscriberDataMngt,                       (int)MAP_OP_CODE_insertSubscriberData},
        {(int)MAP_AC_CODE_subscriberDataMngt,                       (int)MAP_OP_CODE_deleteSubscriberData},
        {(int)MAP_AC_CODE_roamingNbEnquiry,                         (int)MAP_OP_CODE_provideRoamingNumber},
        {(int)MAP_AC_CODE_locInfoRetrieval,                         (int)MAP_OP_CODE_sendRoutingInfo},
        {(int)MAP_AC_CODE_gprsNotify,                               (int)MAP_OP_CODE_noteMsPresentForGprs},
        {(int)MAP_AC_CODE_gprsLocationInfoRetrieval,                (int)MAP_OP_CODE_sendRoutingInfoForGprs},
        {(int)MAP_AC_CODE_failureReport,                            (int)MAP_OP_CODE_failureReport},
        {(int)MAP_AC_CODE_callControlTransfer,                      (int)MAP_OP_CODE_resumeCallHandling},
        {(int)MAP_AC_CODE_subscriberInfoEnquiry,                    (int)MAP_OP_CODE_provideSubscriberInfo},
        {(int)MAP_AC_CODE_anyTimeEnquiry,                           (int)MAP_OP_CODE_anyTimeInterrogation},
        {(int)MAP_AC_CODE_anyTimeInfoHandling,                      (int)MAP_OP_CODE_anyTimeSubscriptionInterrogation},
        {(int)MAP_AC_CODE_anyTimeInfoHandling,                      (int)MAP_OP_CODE_anyTimeModification},
        {(int)MAP_AC_CODE_ssInvocationNotification,                 (int)MAP_OP_CODE_ssInvocationNotification},
        {(int)MAP_AC_CODE_groupCallControl,                         (int)MAP_OP_CODE_prepareGroupCall},
        {(int)MAP_AC_CODE_groupCallControl,                         (int)MAP_OP_CODE_processGroupCallSignalling},
        {(int)MAP_AC_CODE_groupCallControl,                         (int)MAP_OP_CODE_forwardGroupCallSignalling},
        {(int)MAP_AC_CODE_groupCallControl,                         (int)MAP_OP_CODE_sendGroupCallEndSignal},
        {(int)MAP_AC_CODE_reporting,                                (int)MAP_OP_CODE_setReportingState},
        {(int)MAP_AC_CODE_reporting,                                (int)MAP_OP_CODE_statusReport},
        {(int)MAP_AC_CODE_reporting,                                (int)MAP_OP_CODE_remoteUserFree},
        {(int)MAP_AC_CODE_callCompletion,                           (int)MAP_OP_CODE_registerCCEntry},
        {(int)MAP_AC_CODE_callCompletion,                           (int)MAP_OP_CODE_eraseCCEntry},
        {(int)MAP_AC_CODE_IST_Alerting,                             (int)MAP_OP_CODE_istAlert},
        {(int)MAP_AC_CODE_ServiceTermination,                       (int)MAP_OP_CODE_istCommand},
        {(int)MAP_AC_CODE_locationSvcEnquiry,                       (int)MAP_OP_CODE_provideSubscriberLocation},
        {(int)MAP_AC_CODE_locationSvcEnquiry,                       (int)MAP_OP_CODE_subscriberLocationReport},
        {(int)MAP_AC_CODE_locationSvcGateway,                       (int)MAP_OP_CODE_sendRoutingInfoForLCS},
        {(int)MAP_AC_CODE_mm_EventReporting,                        (int)MAP_OP_CODE_noteMMEvent},
        {(int)MAP_AC_CODE_subscriberDataModificationNotification,   (int)MAP_OP_CODE_noteSubscriberDataModified},
        {(int)MAP_AC_CODE_authenticationFailureReport,              (int)MAP_OP_CODE_authenticationFailureReport},
        {(int)MAP_AC_CODE_resourceManagement,                       (int)MAP_OP_CODE_releaseResources},
        {(int)MAP_AC_CODE_groupCallInfoRetrieval,                   (int)MAP_OP_CODE_sendGroupCallInfo},
        {(int)MAP_AC_CODE_mwdMngt,									        (int)MAP_OP_CODE_noteMsPresent},
			
};


        
int g_MapErrorCodeMapping[][3]=
{
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                           MAP1 PDU                                MAP2 PDU                                    MAP3 PDU
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/* 00 */   /* MAP_ERROR_UNKNOWN=0 */                         {0,                                     0,                                          0},
/* 01 */   /* MAP_ERROR_unknownSubscriber */                 {IMAP1_UnknownSubscriber_PDU,           IMAP2_UnknownSubscriberParam_PDU,           IMAP3_UnknownSubscriberParam_PDU},
/* 02 */   /* MAP_ERROR_dummy_2 */                           {0,                                     0,                                          0},
/* 03 */   /* MAP_ERROR_unknownMSC */                        {IMAP1_UnknownMSC_PDU,                  IMAP2_UnknownMSC_PDU,                       0},
/* 04 */   /* MAP_ERROR_dummy_4 */                           {0,                                     0,                                          0},
/* 05 */   /* MAP_ERROR_unidentifiedSub */                   {IMAP1_UnidentifiedSubscriber_PDU,      IMAP2_UnidentifiedSubscriber_PDU,           IMAP3_UnidentifiedSubParam_PDU},
/* 06 */   /* MAP_ERROR_absentSubscriberSM */                {0,                                     IMAP2_AbsentSubscriberSM_Param_PDU,         IMAP3_AbsentSubscriberSM_Param_PDU},
/* 07 */   /* MAP_ERROR_unknownEquipment */                  {IMAP1_UnknownEquipment_PDU,            IMAP2_UnknownEquipment_PDU,                 0},
/* 08 */   /* MAP_ERROR_roamingNotAllowed */                 {0,                                     IMAP2_RoamingNotAllowedParam_PDU,           IMAP3_RoamingNotAllowedParam_PDU},
/* 09 */   /* MAP_ERROR_illegalSubscriber */                 {0,                                     IMAP2_IllegalSubscriberParam_PDU,           IMAP3_IllegalSubscriberParam_PDU},
/* 10 */   /* MAP_ERROR_bearerServNotProv */                 {IMAP1_BearerServiceNotProvisioned_PDU, IMAP2_BearerServNotProvParam_PDU,           IMAP3_BearerServNotProvParam_PDU},
/* 11 */   /* MAP_ERROR_teleservNotProv */                   {IMAP1_TeleserviceNotProvisioned_PDU,   IMAP2_TeleservNotProvParam_PDU,             IMAP3_TeleservNotProvParam_PDU},
/* 12 */   /* MAP_ERROR_illegalEquipment */                  {0,                                     IMAP2_IllegalEquipmentParam_PDU,            IMAP3_IllegalEquipmentParam_PDU},
/* 13 */   /* MAP_ERROR_callBarred */                        {IMAP1_CallBarred_PARAMETER_PDU,        IMAP2_CallBarredParam_PDU,                  IMAP3_CallBarredParam_PDU},
/* 14 */   /* MAP_ERROR_forwardingViolation */               {IMAP1_ForwardingViolation_PDU,         IMAP2_ForwardingViolation_PDU,              IMAP3_ForwardingViolationParam_PDU},
/* 15 */   /* MAP_ERROR_CUG_Reject */                        {IMAP1_CUG_Reject_PARAMETER_PDU,        IMAP2_CUG_RejectParam_PDU,                  IMAP3_CUG_RejectParam_PDU},
/* 16 */   /* MAP_ERROR_illegalSS_Operation */               {IMAP1_IllegalSS_Operation_PDU,         IMAP2_IllegalSS_Operation_PDU,              IMAP3_IllegalSS_OperationParam_PDU},
/* 17 */   /* MAP_ERROR_ss_ErrorStatus */                    {IMAP1_SS_ErrorStatus_PDU,              IMAP2_SS_ErrorStatus_PDU,                   0},
/* 18 */   /* MAP_ERROR_SS_NotAvailable */                   {IMAP1_SS_NotAvailable_PDU,             IMAP2_SS_NotAvailable_PDU,                  IMAP3_SS_NotAvailableParam_PDU},
/* 19 */   /* MAP_ERROR_SS_SubscriptionViolation */          {IMAP1_SS_SubscriptionViolation_PDU,    IMAP2_SS_SubscriptionViolation_PDU,         IMAP3_SS_SubscriptionViolationParam_PDU},
/* 20 */   /* MAP_ERROR_SS_IncompatibilityCause */           {IMAP1_SS_Incompatibility_PARAMETER_PDU,IMAP2_SS_IncompatibilityCause_PDU,          IMAP3_SS_IncompatibilityCause_PDU},
/* 21 */   /* MAP_ERROR_facilityNotSup */                    {IMAP1_FacilityNotSupported_PDU,        IMAP2_FacilityNotSupported_PDU,             IMAP3_FacilityNotSupParam_PDU},
/* 22 */   /* MAP_ERROR_unauthorizedLCSClient */             {0,                                     0,                                          IMAP3_UnauthorizedLCSClient_Param_PDU},
/* 23 */   /* MAP_ERROR_dummy_23 */                          {0,                                     0,                                          0},
/* 24 */   /* MAP_ERROR_dummy_24 */                          {0,                                     0,                                          0},
/* 25 */   /* MAP_ERROR_noHandoverNumberAvailable */         {IMAP1_NoHandoverNumberAvailable_PDU,   IMAP2_NoHandoverNumberAvailable_PDU,        0},
/* 26 */   /* MAP_ERROR_subsequentHandoverFailure */         {IMAP1_SubsequentHandoverFailure_PDU,   IMAP2_SubsequentHandoverFailure_PDU,        0},
/* 27 */   /* MAP_ERROR_absentSubscriber */                  {IMAP1_AbsentSubscriber_PARAMETER_PDU,  IMAP2_AbsentSubscriberParam_PDU,            IMAP3_AbsentSubscriberParam_PDU},
/* 28 */   /* MAP_ERROR_incompatibleTerminal */              {0,                                     IMAP2_IncompatibleTerminalParam_PDU,        IMAP3_IncompatibleTerminalParam_PDU},
/* 29 */   /* MAP_ERROR_shortTermDenial */                   {0,                                     IMAP2_ShortTermDenialParam_PDU,             IMAP3_ShortTermDenialParam_PDU},
/* 30 */   /* MAP_ERROR_longTermDenial */                    {0,                                     IMAP2_LongTermDenialParam_PDU,              IMAP3_LongTermDenialParam_PDU},
/* 31 */   /* MAP_ERROR_subBusyForMT_SMS */                  {0,                                     IMAP2_SubBusyForMT_SMS_Param_PDU,           IMAP3_SubBusyForMT_SMS_Param_PDU},
/* 32 */   /* MAP_ERROR_SM_DeliveryFailureCause */           {0,                                     IMAP2_SM_DeliveryFailureCause_PDU,          IMAP3_SM_DeliveryFailureCause_PDU},
/* 33 */   /* MAP_ERROR_messageWaitingListFull */            {0,                                     0,                                          0},
/* 34 */   /* MAP_ERROR_systemFailure */                     {0,                                     IMAP2_SystemFailureParam_PDU,               IMAP3_SystemFailureParam_PDU},
/* 35 */   /* MAP_ERROR_dataMissing */                       {IMAP1_DataMissing_PDU,                 IMAP2_DataMissing_PDU,                      IMAP3_DataMissingParam_PDU},
/* 36 */   /* MAP_ERROR_unexpectedData */                    {IMAP1_UnexpectedDataValue_PDU,         IMAP2_UnexpectedDataValue_PDU,              IMAP3_UnexpectedDataParam_PDU},
/* 37 */   /* MAP_ERROR_pwRegistrationFailureCause */        {0,                                     IMAP2_PW_RegistrationFailureCause_PDU,      IMAP3_PW_RegistrationFailureCause_PDU},
/* 38 */   /* MAP_ERROR_negativePW_Check */                  {0,                                     IMAP2_NegativePW_Check_PDU,                 0},
/* 39 */   /* MAP_ERROR_noRoamingNb */                       {IMAP1_NoRoamingNumberAvailable_PDU,    IMAP2_NoRoamingNumberAvailable_PDU,         0},
/* 40 */   /* MAP_ERROR_tracingBufferFull */                 {IMAP1_TracingBufferFull_PDU,           IMAP2_TracingBufferFullParam_PDU,           IMAP3_TracingBufferFullParam_PDU},
/* 41 */   /* MAP_ERROR_dummy_41 */                          {0,                                     0,                                          0},
/* 42 */   /* MAP_ERROR_targetCellOutsideGCA */              {0,                                     0,                                          IMAP3_TargetCellOutsideGCA_Param_PDU},
/* 43 */   /* MAP_ERROR_numberOfPW_AttemptsViolation */      {0,                                     IMAP2_NumberOfPW_AttemptsViolation_PDU,     0},
/* 44 */   /* MAP_ERROR_numberChanged */                     {0,                                     IMAP2_NumberChangedParam_PDU,               IMAP3_NumberChangedParam_PDU},
/* 45 */   /* MAP_ERROR_busySubscriber */                    {IMAP1_BusySubscriber_PDU,              IMAP2_BusySubscriberParam_PDU,              IMAP3_BusySubscriberParam_PDU},
/* 46 */   /* MAP_ERROR_noSubscriberReply */                 {IMAP1_NoSubscriberReply_PDU,           IMAP2_NoSubscriberReplyParam_PDU,           IMAP3_NoSubscriberReplyParam_PDU},
/* 47 */   /* MAP_ERROR_forwardingFailed */                  {0,                                     IMAP2_ForwardingFailedParam_PDU,            IMAP3_ForwardingFailedParam_PDU},
/* 48 */   /* MAP_ERROR_OR_NotAllowed */                     {0,                                     IMAP2_OR_NotAllowedParam_PDU,               IMAP3_OR_NotAllowedParam_PDU},
/* 49 */   /* MAP_ERROR_ATI_NotAllowed */                    {0,                                     IMAP2_ATI_NotAllowedParam_PDU,              IMAP3_ATI_NotAllowedParam_PDU},
/* 50 */   /* MAP_ERROR_unauthorizedRequestingNetwork */     {0,                                     0,                                          IMAP3_UnauthorizedRequestingNetwork_Param_PDU},
/* 51 */   /* MAP_ERROR_ResourceLimitation */                {0,                                     IMAP2_ResourceLimitationParam_PDU,          IMAP3_ResourceLimitationParam_PDU},
/* 52 */   /* MAP_ERROR_PositionMethodFailure */             {0,                                     0,                                          IMAP3_PositionMethodFailure_Param_PDU},
/* 53 */   /* MAP_ERROR_unknownOrUnreachableLCSClient */     {0,                                     0,                                          IMAP3_UnknownOrUnreachableLCSClient_Param_PDU},
/* 54 */   /* MAP_ERROR_dummy_54 */                          {0,                                     0,                                          0},
/* 55 */   /* MAP_ERROR_dummy_55 */                          {0,                                     0,                                          0},
/* 56 */   /* MAP_ERROR_dummy_56 */                          {0,                                     0,                                          0},
/* 57 */   /* MAP_ERROR_dummy_57 */                          {0,                                     0,                                          0},
/* 58 */   /* MAP_ERROR_dummy_58 */                          {0,                                     0,                                          0},
/* 59 */   /* MAP_ERROR_dummy_59 */                          {0,                                     0,                                          0},
/* 60 */   /* MAP_ERROR_ATSI_NotAllowed */                   {0,                                     0,                                          IMAP3_ATSI_NotAllowedParam_PDU},
/* 61 */   /* MAP_ERROR_ATM_NotAllowed */                    {0,                                     0,                                          IMAP3_ATM_NotAllowedParam_PDU},
/* 62 */   /* MAP_ERROR_informationNotAvailable */           {0,                                     0,                                          IMAP3_InformationNotAvailableParam_PDU},
/* 63 */   /* MAP_ERROR_dummy_63 */                          {0,                                     0,                                          0},
/* 64 */   /* MAP_ERROR_dummy_64 */                          {0,                                     0,                                          0},
/* 65 */   /* MAP_ERROR_dummy_65 */                          {0,                                     0,                                          0},
/* 66 */   /* MAP_ERROR_dummy_66 */                          {0,                                     0,                                          0},
/* 67 */   /* MAP_ERROR_dummy_67 */                          {0,                                     0,                                          0},
/* 68 */   /* MAP_ERROR_dummy_68 */                          {0,                                     0,                                          0},
/* 69 */   /* MAP_ERROR_dummy_69 */                          {0,                                     0,                                          0},
/* 70 */   /* MAP_ERROR_dummy_70 */                          {0,                                     0,                                          0},
/* 71 */   /* MAP_ERROR_unknownAlphabet */                   {0,                                     IMAP2_UnknownAlphabet_PDU,                  0},
/* 72 */   /* MAP_ERROR_ussd_Busy */                         {0,                                     IMAP2_USSD_Busy_PDU,                        0}
};
       

char g_MapErrorCodeChar[][100] = {
   "UNKNOWN",
   "unknownSubscriber",
   "dummy_2",
   "unknownMSC",
   "dummy_4",
   "unidentifiedSub",
   "absentSubscriberSM",
   "unknownEquipment",
   "roamingNotAllowed",
   "illegalSubscriber",
   "bearerServNotProv",
   "teleservNotProv",
   "illegalEquipment",
   "callBarred",
   "forwardingViolation",
   "CUG_Reject",
   "illegalSS_Operation",
   "ss_ErrorStatus",
   "ssNotAvailable",
   "ssSubscriptionViolation",
   "ssIncompatibilityCause",
   "facilityNotSup",
   "ongoingGroupCall",
   "dummy_23",
   "dummy_24",
   "noHandoverNumberAvailable",
   "subsequentHandoverFailure",
   "absentSubscriber",
   "incompatibleTerminal",
   "shortTermDenial",
   "longTermDenial",
   "subBusyForMT_SMS",
   "smDeliveryFailureCause",
   "messageWaitingListFull",
   "systemFailure",
   "dataMissing",
   "unexpectedData",
   "pwRegistrationFailureCause",
   "negativePW_Check",
   "noRoamingNb",
   "tracingBufferFull",
   "dummy_41",
   "targetCellOutsideGCA",
   "numberOfPW_AttemptsViolation",
   "numberChanged",
   "busySubscriber",
   "noSubscriberReply",
   "forwardingFailed",
   "orNotAllowed",
   "atiNotAllowed",
   "noGroupCallNumberAvailable",
   "resourceLimitation",
   "unauthorizedRequestingNetwork",
   "unauthorizedLCSClient",
   "positionMethodFailure",
   "dummy_55",
   "dummy_56",
   "dummy_57",
   "unknownOrUnreachableLCSClient",
   "mmEventNotSupported",
   "atsiNotAllowed",
   "atmNotAllowed",
   "informationNotAvailable",
   "dummy_63",
   "dummy_64",
   "dummy_65",
   "dummy_66",
   "dummy_67",
   "dummy_68",
   "dummy_69",
   "dummy_70",
   "unknownAlphabet",
   "ussd_Busy",
   "MAXIMUM"
};


int MapConstants::getMapOpCodeArgPDU(EMapOpCode p_EMapOpCode, EMapVersion p_version)
{
   return g_MapOpCodeMapping[p_EMapOpCode][p_version];
}

int MapConstants::getMapOpCodeResPDU(EMapOpCode p_EMapOpCode, EMapVersion p_version)
{
   //printf("\ngetMapOpCodeResPDU  : p_EMapOpCode [%d] p_version [%d] PDU [%d]", p_EMapOpCode, p_version, g_MapOpCodeMapping[p_EMapOpCode][p_version+2]);
   return g_MapOpCodeMapping[p_EMapOpCode][p_version+3];
}

int MapConstants::getMapOpCodeTimerValue(EMapOpCode p_EMapOpCode)
{
   return g_MapOpCodeMapping[p_EMapOpCode][7];
}


/* Timer Values: 
 * Symbol    Value        Time from the Spec
 * d         0            = This is just a default placeholder - NG would decide the default timer
 * s         1            = from 3 seconds to 10 seconds;
 * m         2            = from 15 seconds to 30 seconds;
 * ml        3            = from 1 minute to 10 minutes; 
 * l         4            = from 28 hours to 38 hours.
 * */

int MapConstants::getMapOpCodeMaxTime(EMapOpCode p_EMapOpCode)
{
   switch (MapConstants::getMapOpCodeTimerValue(p_EMapOpCode))
   {
	   case 1:
		   return 10;
		   break;
	   case 2:
		   return 30;
		   break;
	   case 3:
		   return 600;//10 minutes
		   break;
	   case 4:
		   return 2280;//38 hours
		   break;
	   default:
		   return 60;//1 min
		   break;
   }
}


int MapConstants::getMapOpCodeMinTime(EMapOpCode p_EMapOpCode)
{
   switch (MapConstants::getMapOpCodeTimerValue(p_EMapOpCode))
   {
	   case 1:
		   return 3;
		   break;
	   case 2:
		   return 15;
		   break;
	   case 3:
		   return 60;//1 minute
		   break;
	   case 4:
		   return 1680;//28 hours
		   break;
	   default:
		   return 60;//1 min
		   break;
   }
}

int MapConstants::getMapOpCodeConfFlag(EMapOpCode p_EMapOpCode)
{
   return g_MapOpCodeMapping[p_EMapOpCode][8];
}

int MapConstants::getMapApplCtxtMinVersion(EMapApplicationContext p_EMapACCode)
{
   //printf("\nMin Appl Ctxt version for AC [%d] is [%d]", (int)p_EMapACCode, g_MapApplCtxtMapping[p_EMapACCode][0]);
   return g_MapApplCtxtMapping[p_EMapACCode][0];
}

int MapConstants::getMapApplCtxtMaxVersion(EMapApplicationContext p_EMapACCode)
{
   //printf("\nMax Appl Ctxt version for AC [%d] is [%d]", (int)p_EMapACCode, g_MapApplCtxtMapping[p_EMapACCode][1]);
   return g_MapApplCtxtMapping[p_EMapACCode][1];
}

int MapConstants::getMapErrorCodePDU(EMapErrorCode p_error, EMapVersion p_version)
{
    return g_MapErrorCodeMapping[p_error][p_version-1];
}

bool MapConstants::isMapOpCodeValid(EMapOpCode p_EMapOpCode)
{
    //printf("\nOpCode [%d] Validflag [%d]", p_EMapOpCode, g_MapOpCodeMapping[p_EMapOpCode][0]);
    return (1==g_MapOpCodeMapping[p_EMapOpCode][0])?true:false;
}

char *MapConstants::getMapOpCodeName(EMapOpCode p_EMapOpCode)
{
    return g_MapOpCodeChar[p_EMapOpCode];
}

char *MapConstants::getMapApplCtxtName(EMapApplicationContext p_EMapACCode)
{
    return g_MapApplCtxtMappingChar[p_EMapACCode];
}

char *MapConstants::getMapOpCodeChar(int p_OpCode)
{
   if ( 
         (p_OpCode > (int)(MAP_OP_CODE_UNKNOWN) ) &&
         (p_OpCode < (int)(MAP_OP_CODE_MAXIMUM) )
      )
   {
      return g_MapOpCodeChar[p_OpCode];
   }
   else
   {
      return "UNKNOWN_OPERATION";
   }
}

char *MapConstants::getMapApplCodeChar(int p_ApplCode)
{
   if ( 
         (p_ApplCode > (int)(MAP_AC_UNKNOWN) ) &&
         (p_ApplCode < (int)(MAP_AC_CODE_MAXIMUM) )
      )
   {
      return g_MapApplCtxtMappingChar[p_ApplCode];
   }
   else
   {
      return "UNKNOWN_APPL_CNTXT";
   }
}

char *MapConstants::getMapErrorCodeChar(int p_ErrorCode)
{
   if ( 
         (p_ErrorCode > (int)(MAP_ERROR_UNKNOWN) ) &&
         (p_ErrorCode < (int)(MAP_ERROR_MAXIMUM) )
      )
   {
      return g_MapErrorCodeChar[p_ErrorCode];
   }
   else
   {
      return "UNKNOWN_ERROR_CODE";
   }
}



char MapConstants::m_ApplCtxtOpCodeCharArr[1000];

bool MapConstants::initialize(ConstantsLogOverride *p_clo)
{
   if(p_clo == NULL)
   {
      printf("\nLog override is null");
      return false;
   }
   g_clo = p_clo;

    //printf("\ng_ApplCtxtOpCodeMapping size [%d]", sizeof(g_ApplCtxtOpCodeMapping));
    memset(m_ApplCtxtOpCodeCharArr, '\0', sizeof(m_ApplCtxtOpCodeCharArr));

    for (int l_i=0; l_i< (sizeof(g_ApplCtxtOpCodeMapping)/8); l_i++)
    {
        //printf("\nl_i [%d]", l_i);
        char l_temp[20];
        memset(l_temp, '\0', 20);
        sprintf(l_temp, "[%02d:%02d]", g_ApplCtxtOpCodeMapping[l_i][0], g_ApplCtxtOpCodeMapping[l_i][1]);
        strcat(m_ApplCtxtOpCodeCharArr, l_temp);
    }

    //printf("\n [%d] [%s] ", strlen(m_ApplCtxtOpCodeCharArr), m_ApplCtxtOpCodeCharArr);
    return true;
}


bool MapConstants::isApplCtxtOpCodeCombValid(EMapApplicationContext p_EMapACCode, EMapOpCode p_EMapOpCode)
{
    char l_temp[20];
    memset(l_temp, '\0', 20);
    sprintf(l_temp, "[%02d:%02d]", p_EMapACCode, p_EMapOpCode);

    //printf("\nchecking for [%s]", l_temp);

    if (strstr(m_ApplCtxtOpCodeCharArr, l_temp))
    {
        //printf("\nFound");
        return true;
    }
    else
    {
        //printf("\nNOT Found");
        return false;
    }
}


EMapApplicationContext MapConstants::getV1ApplCtxt(EMapOpCode p_opCode)
{
    switch(p_opCode)
    {
       case MAP_OP_CODE_provideRoamingNumber:
          return MAP_AC_CODE_roamingNbEnquiry;
          break;

        case MAP_OP_CODE_sendParameters:
        case MAP_OP_CODE_sendIdentification:
            return MAP_AC_CODE_infoRetrieval;
            break;

        case MAP_OP_CODE_prepareHandover:
        case MAP_OP_CODE_forwardAccessSignalling:
        case MAP_OP_CODE_sendEndSignal:
        case MAP_OP_CODE_processAccessSignalling:
            return MAP_AC_CODE_handoverControl;
            break;

        case MAP_OP_CODE_processUnstructuredSSRequest:
        case MAP_OP_CODE_processUnstructuredSsData:
        case MAP_OP_CODE_unstructuredSSRequest:
        case MAP_OP_CODE_unstructuredSSNotify:
        case MAP_OP_CODE_beginSubscriberActivity:
            return MAP_AC_CODE_networkUnstructuredSs;
            break;


        case MAP_OP_CODE_sendRoutingInfoForSM:
        case MAP_OP_CODE_reportSMDeliveryStatus:
        case MAP_OP_CODE_informServiceCentre:
            return MAP_AC_CODE_shortMsgGateway;
            break;

        case MAP_OP_CODE_cancelLocation:
            return MAP_AC_CODE_locationCancel;
            break;

        case MAP_OP_CODE_updateLocation:
        case MAP_OP_CODE_restoreData:
        case MAP_OP_CODE_insertSubscriberData:
        case MAP_OP_CODE_activateTraceMode:
            return MAP_AC_CODE_networkLocUp;
            break;

        case MAP_OP_CODE_sendIMSI:
            return MAP_AC_CODE_imsiRetrieval;
            break;

        case MAP_OP_CODE_noteMsPresent:
            return MAP_AC_CODE_mwdMngt;
            break;

        case MAP_OP_CODE_purgeMS:
            return MAP_AC_CODE_msPurging;
            break;

        case MAP_OP_CODE_reset:
            return MAP_AC_CODE_reset;
            break;

        case MAP_OP_CODE_registerSS:
        case MAP_OP_CODE_eraseSS:
        case MAP_OP_CODE_activateSS:
        case MAP_OP_CODE_deactivateSS:
        case MAP_OP_CODE_registerPassword:
        case MAP_OP_CODE_interrogateSS:
        case MAP_OP_CODE_getPassword:
            return MAP_AC_CODE_networkFunctionalSs;
            break;

        case MAP_OP_CODE_updateGprsLocation:
            return MAP_AC_CODE_gprsLocationUpdate;
            break;

        case MAP_OP_CODE_sendRoutingInfo:
            return MAP_AC_CODE_locInfoRetrieval;
            break;

        case MAP_OP_CODE_provideSubscriberLocation:
        case MAP_OP_CODE_subscriberLocationReport:
            return MAP_AC_CODE_locationSvcEnquiry;
            break;

        case MAP_AC_CODE_locationSvcEnquiry:
            return MAP_AC_CODE_locationSvcGateway;
            break;
        
        case MAP_OP_CODE_moForwardSM:
            return MAP_AC_CODE_shortMsgMTRelay;
            break;

        default:
            return MAP_AC_UNKNOWN;
            break;
    }
    return MAP_AC_UNKNOWN;
}

int MapConstants::getBeginSubscriberActivityPdu()
{
    return IMAP1_BeginSubscriberActivityArg_PDU;
}

int MapConstants::getMapDialoguePdu()
{
    return IMAP2_DialoguePDU_PDU;
}


int MapConstants::getExtensionContainerFlag(EMapOpCode p_OpCode, EMapVersion p_MapVersion)
{
   switch (p_MapVersion)
   {
      case 1:
         return g_MapOpCodeMapping[p_OpCode][9];
         break;
      case 2:
         return g_MapOpCodeMapping[p_OpCode][11];
         break;
      case 3:
         return g_MapOpCodeMapping[p_OpCode][13];
         break;
      default:
         printf("\ngetExtensionContainerFlag called with unknown map version: %d\n\n", p_MapVersion);
         return 0;
         break;
   }
}

unsigned char MapConstants::getExtensionContainerBitMaskValue(EMapOpCode p_OpCode, EMapVersion p_MapVersion)
{
   switch (p_MapVersion)
   {
      case 1:
         return g_MapOpCodeMapping[p_OpCode][10];
         break;
      case 2:
         return g_MapOpCodeMapping[p_OpCode][12];
         break;
      case 3:
         return g_MapOpCodeMapping[p_OpCode][14];
         break;
      default:
         printf("\ngetExtensionContainerFlag called with unknown map version: %d\n\n", p_MapVersion);
         return 0;
         break;
   }
}



