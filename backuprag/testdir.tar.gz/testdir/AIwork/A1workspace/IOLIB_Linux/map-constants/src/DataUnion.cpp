#include <DataUnion.h>
#include <OMAP1.h>
#include <OMAP2.h>
#include <OMAP3.h>
#include <MapConstants.h>

u g_u; 



bool checkSpecificReset(int p_version, int p_pdu)
{
    switch (p_version)
    {
        case 1:
            switch (p_pdu)
            {
                case OMAP1_RegisterSSArg_PDU:
                    // Put Code here to memset the bit_masks and choices
                    printf("\ncheckSpecificReset called for OMAP1_RegisterSSArg_PDU\n");
                    return true;
                    break;

                default:
                    return false;
                    break;
            }
            break;

        case 2:
            //Respective Initializations to be done
            return false;
            break;

        case 3:
            //Respective Initializations to be done
            return false;
            break;

        default:
            return false;
            break;
    }
    return false;
}


