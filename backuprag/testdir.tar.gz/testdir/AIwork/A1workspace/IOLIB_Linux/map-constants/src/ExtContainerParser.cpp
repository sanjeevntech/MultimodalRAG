#include <ExtContainerParser.h>
#include <IMAP1.h>
#include <IMAP2.h>
#include <IMAP3.h>

ExtContainerParser g_ecp;

ExtContainerParser::ExtContainerParser()
{
   m_count=0;
}

ExtContainerParser::~ExtContainerParser()
{
}

void *getExtContainerPtr(EMapOpCode p_OpCode, EMapVersion p_MapVersion, void *p_struct)
{
   switch (p_MapVersion)
   {
      case MAP_V3:
         {
            switch (p_OpCode)
            {
               case MAP_OP_CODE_updateLocation:
                  {
                     return &(((IMAP3_UpdateLocationArg*)p_struct)->extensionContainer);
                  }
                  break;

               case MAP_OP_CODE_sendRoutingInfo:
                  {
                     return &(((IMAP3_SendRoutingInfoArg*)p_struct)->extensionContainer);
                  }
                  break;

               default:
                  {
                     CONS_LOG('T',"getExtContainerPtr unknown opcode: %d\n", p_OpCode);
                     return NULL;
                  }
                  break;
            }
         }
         break;

      case MAP_V2:
         {
            switch (p_OpCode)
            {
               case MAP_OP_CODE_updateLocation:
                  {
                     return &(((IMAP2_UpdateLocationArg*)p_struct)->extensionContainer);
                  }
                  break;

               default:
                  {
                     CONS_LOG('T',"getExtContainerPtr unknown opcode: %d\n", p_OpCode);
                     return NULL;
                  }
                  break;
            }
         }
         break;

      default:
         {
            CONS_LOG('T',"getExtContainerPtr unknown version: %d\n", p_MapVersion);
            return NULL;
         }
         break;

   }

}


bool ExtContainerParser::registerModule(unsigned char *p_extIdValue, int p_extIdLength, ExtParserBase *p_extParserBase)
{
   CONS_LOG('T',"ExtContainerParser::registerModule called\n");
   if(p_extIdLength < 1)
   {
      CONS_LOG('T',"ExtContainerParser::registerModule p_extIdLength is not greater than zero");
      return false;
   }

   if(NULL == p_extParserBase)
   {
      CONS_LOG('T',"ExtContainerParser::registerModule p_extParserBase is NULL");
      return false;
   }

   if(MAX_EXT_PARSERS == m_count)
   {
      CONS_LOG('T',"ExtContainerParser::registerModule maximum number of ext parsers exceeded");
      return false;
   }

   m_list[m_count].m_extIdLength = p_extIdLength;
   memcpy(m_list[m_count].m_extIdValue, p_extIdValue, p_extIdLength);
   m_list[m_count].m_parserBase = p_extParserBase;

   m_count++;
   CONS_LOG('T',"ExtContainerParser::registerModule registered module successfully\n");
}

struct BitMaskStruct
{
   unsigned char bit_mask;
};

struct BitMaskStructInt
{
   int bit_mask;
};

bool ExtContainerParser::decodeExtensionContainer(EMapOpCode p_OpCode, EMapVersion p_MapVersion, void *p_struct, char *p_buffer, int p_bufferMaxSize)
{
   CONS_LOG('T',"decodeExtensionContainer called with opcode %d, version: %d", p_OpCode, p_MapVersion);


   //Check whether extension container is present for this opcode or not
   int l_flag = MapConstants::getExtensionContainerFlag(p_OpCode, p_MapVersion);
   if (0 == l_flag)
   {
      CONS_LOG('T',"decodeExtensionContainer No Extension ContaineR is possible for opcode %d, version: %d", p_OpCode, p_MapVersion);
      return true;
   }


   //Get the bitmask value for the extension container
#if 0 //TODO commented for Linux - for common source code needs to be highly re-visited
   unsigned char l_respectiveBitMask = MapConstants::getExtensionContainerFlag(p_OpCode, p_MapVersion);
   if (0 == l_respectiveBitMask)
   {
      CONS_LOG('T',"decodeExtensionContainer ERROR!! Unable to retrieve the bitmask indicator for opcode %d, version: %d", p_OpCode, p_MapVersion);
      return false;
   }
#endif
   if(p_MapVersion != MAP_V3)
   {
      CONS_LOG('T',"decodeExtensionContainer Other than V3");
      return true;
   }
   if(MAP_OP_CODE_updateLocation == p_OpCode) //TODO: to change later
   {
      //Get the Bit mask associated with opcode and version
      CONS_LOG('D',"UPD bit mask value[%d] IMAP3_UpdateLocationArg_extensionContainer_present[%d]",((IMAP3_UpdateLocationArg*)p_struct)->bit_mask, IMAP3_UpdateLocationArg_extensionContainer_present);
      struct BitMaskStruct *l_struct = (struct BitMaskStruct *)p_struct;
      if (0 ==  (l_struct->bit_mask & IMAP3_UpdateLocationArg_extensionContainer_present) )
      {
         CONS_LOG('T',"decodeExtensionContainer UPD No Extension Container present in the message for opcode %d, version: %d", p_OpCode, p_MapVersion);
         return true;
      }
      else
      {
         CONS_LOG('T',"decodeExtensionContainer UPD Extension Container present  %d, version: %d", p_OpCode, p_MapVersion);
      }
   }
   else if(MAP_OP_CODE_sendRoutingInfo == p_OpCode)
   {
      CONS_LOG('D',"SRI bit mask value[%d] IMAP3_SendRoutingInfoArg_extensionContainer_present[%d]",((IMAP3_SendRoutingInfoArg*)p_struct)->bit_mask, IMAP3_SendRoutingInfoArg_extensionContainer_present);
      //Get the Bit mask associated with opcode and version
      struct BitMaskStructInt *l_struct = (struct BitMaskStructInt *)p_struct;
      if (0 ==  (l_struct->bit_mask & IMAP3_SendRoutingInfoArg_extensionContainer_present) )
      {
         CONS_LOG('T',"decodeExtensionContainer SRI No Extension Container present in the message for opcode %d, version: %d", p_OpCode, p_MapVersion);
         return true;
      }
      else
      {
         CONS_LOG('T',"decodeExtensionContainer SRI Extension Container present  %d, version: %d", p_OpCode, p_MapVersion);
      }
   }
   else
   {
      CONS_LOG('T',"decodeExtensionContainer Invalid OpCode:%d", p_OpCode);
      return false;
   }

   //Ge the extension container pointer for the opcode and version
   void *l_extStruct = NULL;
   l_extStruct = getExtContainerPtr(p_OpCode, p_MapVersion, p_struct);
   if (NULL == l_extStruct)
   {
      CONS_LOG('T',"decodeExtensionContainer ERROR!!! Unable to retrieve the extension container pointer for  opcode %d, version: %d", p_OpCode, p_MapVersion);
      return false;
   }

   int l_extIdLength=0;
   unsigned char l_extIdValue[200];
   memset(l_extIdValue, '\0', sizeof(l_extIdValue));
   int l_extTypeLength=0;
   unsigned char l_extTypeValue[200];
   memset(l_extTypeValue, '\0', sizeof(l_extTypeValue));

   switch (p_MapVersion)
   {
      case MAP_V3:
         {
            IMAP3_ExtensionContainer *l_imap3 = (IMAP3_ExtensionContainer *)(void*)l_extStruct;
            if (l_imap3->bit_mask & IMAP3_ExtensionContainer_privateExtensionList_present)
            {
               CONS_LOG('T',"test decodeExtensionContainer Private extensions present");

               IMAP3_PrivateExtensionList_ *l_list;
               l_list = (IMAP3_PrivateExtensionList_*)l_imap3->privateExtensionList;
               CONS_LOG('D',"decodeExtensionContainer here %d", __LINE__);
               if(l_list != NULL)
               {
               CONS_LOG('D',"decodeExtensionContainer here %d", __LINE__);
                  IMAP3_PrivateExtension *l_pe = (IMAP3_PrivateExtension*)&(l_list->value);
               CONS_LOG('D',"decodeExtensionContainer here %d", __LINE__);
               CONS_LOG('D',"#############befr here %d", __LINE__);
               CONS_LOG('D',"decodeExtensionContainer l_pe->extId.length  %d",(l_pe->extId).length);
               CONS_LOG('D',"#############aftr here %d", __LINE__);
               CONS_LOG('D',"decodeExtensionContainer l_pe->extId.value  %s",(char*)(l_pe->extId).value);
               CONS_LOG('D',"#############aftr 2here %d", __LINE__);
                  CONS_LOG_HEX('T',"ExtType ID", (char*)l_pe->extId.value, l_pe->extId.length);
               CONS_LOG('D',"decodeExtensionContainer here %d", __LINE__);
                  for (int i=0; i<l_pe->extId.length; i++)
                  {
               CONS_LOG('D',"decodeExtensionContainer here %d", __LINE__);
                     l_extIdLength++;
                     //printf(" %02x", l_pe->extId.value[i]);
                     l_extIdValue[i]=l_pe->extId.value[i];
                  }
               CONS_LOG('D',"decodeExtensionContainer here %d", __LINE__);

#if 1 //TODO
                  CONS_LOG('T',"decodeExtensionContainer Ext Type pduNum: %d, length: %d", l_pe->extType.pduNum, l_pe->extType.encoded.length);
                  unsigned char *l_encoded = (unsigned char *)(l_pe->extType.encoded.value);
                  CONS_LOG_HEX('T',"ExtType Value", (char*)l_encoded, l_pe->extType.encoded.length);
                  if(l_encoded != NULL)
                  {
                     if(l_pe->extType.encoded.length <= sizeof(l_extTypeValue))
                     {
                        CONS_LOG('T',"decoded value length is within 200");
                        for (int i=0; i< l_pe->extType.encoded.length; i++)
                        {
                           l_extTypeLength++;
                           //CONS_LOG('T'," %02x", *(l_encoded + i));
                           l_extTypeValue[i]= *(l_encoded + i);
                        }
                     }
                     else
                     {
                        CONS_LOG('W',"decoded value length is more than 200 returning");
                        return false;
                     }
                  }
                  else
                  {
                     CONS_LOG('T',"decoded is null\n");
                     return false;
                  }
#endif
               }
               else
               {
                  CONS_LOG('T',"List is null");
                  return false;
               }
            }

            if (l_imap3->bit_mask & IMAP3_pcs_Extensions_present)
            {
               CONS_LOG('T',"decodeExtensionContainer PCS extensions present placeholder [%02x] \n", l_imap3->pcs_Extensions.placeholder);
            }
         }
         break;

      case MAP_V2:
         {
         }
         break;

      case MAP_V1:
         {
            return true;
         }
         break;

      default:
         {
            CONS_LOG('T',"decodeExtensionContainer not known\n");
            return false;
         }
         break;
   }

   for(int i=0; i<m_count; i++)
   {
      CONS_LOG('T',"Checking with the extension container [%d]", i);
      if(l_extIdLength == m_list[i].m_extIdLength)
      {
         CONS_LOG('T',"ExtTypeIdLength matched with ext container [%d]", i);
         if( 0 == memcmp(l_extIdValue, m_list[i].m_extIdValue, l_extIdLength))
         {
            CONS_LOG('T',"Ext Id matched with ext container [%d]", i);
            bool l_status = m_list[i].m_parserBase->callRespectiveDecoder(p_OpCode, p_MapVersion, 
                  l_extTypeValue, l_extTypeLength, p_buffer);
            if(false == l_status)
            {
               CONS_LOG('T',"decoding failed");
               return false;
            }
            else
            {
               CONS_LOG('T',"decoding success");
               return true;
            }
         }
      }
      else
      {
         CONS_LOG('T', "ext lengths did not match %d %d", l_extIdLength, m_list[i].m_extIdLength);
      }
   }

   CONS_LOG('T', "Didn't match with any of the extension containers registered");
   return false;
}









ExtList::ExtList()
{
   m_extIdLength=0;
   memset(m_extIdValue, '\0', sizeof(m_extIdValue));
   m_parserBase=NULL;
}

ExtList::~ExtList()
{
}

