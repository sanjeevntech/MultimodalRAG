#include <ConstantsLogOverride.h>
#include <stdio.h>

ConstantsLogOverride::ConstantsLogOverride()
{
}

ConstantsLogOverride::~ConstantsLogOverride()
{
}

ConstantsLogOverride *g_clo=NULL;

