#ifndef __CONSTANTS_LOG_OVERRIDE_H
#define __CONSTANTS_LOG_OVERRIDE_H

class ConstantsLogOverride
{
   private:

   public:
      ConstantsLogOverride();
      virtual ~ConstantsLogOverride();

      virtual bool override(char p_logLevel, char *p_data)=0;
};

extern ConstantsLogOverride *g_clo;

#endif  //__CONSTANTS_LOG_OVERRIDE_H

