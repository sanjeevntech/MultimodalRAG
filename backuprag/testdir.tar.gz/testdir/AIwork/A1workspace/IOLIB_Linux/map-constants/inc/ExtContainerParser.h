#ifndef __EXT_CONTAINER_PARSER_H
#define __EXT_CONTAINER_PARSER_H

#include <MapConstants.h>
#include <ExtParserBase.h>

#define MAX_EXT_PARSERS  10

class ExtList
{
   public:
      ExtList();
      ~ExtList();
      int           m_extIdLength;
      unsigned char m_extIdValue[200];
      ExtParserBase *m_parserBase;
};

class ExtContainerParser
{
   private:
      int      m_count;
      ExtList  m_list[MAX_EXT_PARSERS];

   public:
      ExtContainerParser();
      ~ExtContainerParser();

      bool decodeExtensionContainer(EMapOpCode p_OpCode, EMapVersion p_MapVersion,  void *p_struct, char *p_buffer, int p_bufferMaxSize);
      bool registerModule(unsigned char *p_extIdValue, int p_extIdLength, ExtParserBase *p_extParserBase);

};

extern ExtContainerParser g_ecp;

#endif  //__EXT_CONTAINER_PARSER_H
