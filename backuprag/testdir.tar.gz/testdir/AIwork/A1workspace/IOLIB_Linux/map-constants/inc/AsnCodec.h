#ifndef  __ASN_CODEC_H
#define  __ASN_CODEC_H

#include <ossasn1.h>

#define MAX_PDU_SIZE 10240


class AsnCodec
{
   private:
      OssGlobal m_AsnW, *m_AsnWorld;
      void* m_AsnVal;
      int m_initialized; //Vble to remember if the OSS was initialized previously.
      int init(); 

   public:
      AsnCodec();
      ~AsnCodec();

      int  initialize(void* P_data);
      void close();
      void printPdu(int P_msgType,void *P_dataStruct, char *p_direction);
      void printPdu(int P_msgType,void *P_dataStruct, int p_consolePrintFlag, int p_logPrintFlag);
      void freePdu(int P_msgType, void* P_data);
      void freeBuf(unsigned char *P_buff);
      int  encode(void *P_dataStruct,int P_msgType, unsigned char **P_encodedData, int *P_dataLength);
      int  decode(unsigned char **P_EncodedData,int P_BuffLen,int P_MsgType, void **P_DecodedStruct);
      int  decode(unsigned char *p_encodedData,int p_buffLen,int p_msgType,  void **p_decodedStruct);
      long setDecodingLength(long P_bufferLength);
      long getEncodingLength(int P_msgType,void *P_data);
      char *getErrMsg();
};

extern bool initializeAsnCodecs(int p_flag=0);

extern AsnCodec g_AsnCodecI1;
extern AsnCodec g_AsnCodecI2;
extern AsnCodec g_AsnCodecI3;
extern AsnCodec g_AsnCodecO1;
extern AsnCodec g_AsnCodecO2;
extern AsnCodec g_AsnCodecO3;

extern AsnCodec *getAsnCodec(int, char p_ioflag);
extern char     g_PrintPduBuffer[];

#endif   /* __ASN_CODEC_H */
