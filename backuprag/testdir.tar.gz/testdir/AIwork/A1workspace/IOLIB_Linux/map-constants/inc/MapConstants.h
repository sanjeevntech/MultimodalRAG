#ifndef __MAP_CONSTANTS_H
#define __MAP_CONSTANTS_H

#include <ConstantsLogOverride.h>

enum EMapVersion
{
   MAP_V_UNKNOWN   = 0,
   MAP_V1          = 1,
   MAP_V2          = 2,
   MAP_V3          = 3
};


enum EMapOpCode
{
   /* 00 */            MAP_OP_CODE_UNKNOWN=0,
   /* 01 */            MAP_OP_CODE_dummy_1,
   /* 02 */            MAP_OP_CODE_updateLocation,
   /* 03 */            MAP_OP_CODE_cancelLocation,
   /* 04 */            MAP_OP_CODE_provideRoamingNumber,
   /* 05 */            MAP_OP_CODE_noteSubscriberDataModified,
   /* 06 */            MAP_OP_CODE_resumeCallHandling,
   /* 07 */            MAP_OP_CODE_insertSubscriberData,
   /* 08 */            MAP_OP_CODE_deleteSubscriberData,
   /* 09 */            MAP_OP_CODE_sendParameters,
   /* 10 */            MAP_OP_CODE_registerSS,
   /* 11 */            MAP_OP_CODE_eraseSS,
   /* 12 */            MAP_OP_CODE_activateSS,
   /* 13 */            MAP_OP_CODE_deactivateSS,
   /* 14 */            MAP_OP_CODE_interrogateSS,
   /* 15 */            MAP_OP_CODE_authenticationFailureReport,
   /* 16 */            MAP_OP_CODE_dummy_16,
   /* 17 */            MAP_OP_CODE_registerPassword,
   /* 18 */            MAP_OP_CODE_getPassword,
   /* 19 */            MAP_OP_CODE_processUnstructuredSsData,
   /* 20 */            MAP_OP_CODE_releaseResources,
   /* 21 */            MAP_OP_CODE_mtForwardSMVGCS,  
   /* 22 */            MAP_OP_CODE_sendRoutingInfo,
   /* 23 */            MAP_OP_CODE_updateGprsLocation,
   /* 24 */            MAP_OP_CODE_sendRoutingInfoForGprs,
   /* 25 */            MAP_OP_CODE_failureReport,
   /* 26 */            MAP_OP_CODE_noteMsPresentForGprs,
   /* 27 */            MAP_OP_CODE_dummy_27,
   /* 28 */            MAP_OP_CODE_dummy_28,
   /* 29 */            MAP_OP_CODE_sendEndSignal,
   /* 30 */            MAP_OP_CODE_dummy_30,
   /* 31 */            MAP_OP_CODE_ProvideSIWFSNumber,
   /* 32 */            MAP_OP_CODE_SIWFSSignallingModify,
   /* 33 */            MAP_OP_CODE_processAccessSignalling,
   /* 34 */            MAP_OP_CODE_forwardAccessSignalling,
   /* 35 */            MAP_OP_CODE_dummy_35,
   /* 36 */            MAP_OP_CODE_dummy_36,
   /* 37 */            MAP_OP_CODE_reset,
   /* 38 */            MAP_OP_CODE_forwardCheckSSIndication,
   /* 39 */            MAP_OP_CODE_prepareGroupCall,
   /* 40 */            MAP_OP_CODE_sendGroupCallEndSignal,
   /* 41 */            MAP_OP_CODE_processGroupCallSignalling,
   /* 42 */            MAP_OP_CODE_forwardGroupCallSignalling,
   /* 43 */            MAP_OP_CODE_checkIMEI,
   /* 44 */            MAP_OP_CODE_mtForwardSM,
   /* 45 */            MAP_OP_CODE_sendRoutingInfoForSM,
   /* 46 */            MAP_OP_CODE_moForwardSM,
   /* 47 */            MAP_OP_CODE_reportSMDeliveryStatus,
   /* 48 */            MAP_OP_CODE_noteMsPresent,
   /* 49 */            MAP_OP_CODE_alertServiceCentre_v1,
   /* 50 */            MAP_OP_CODE_activateTraceMode,
   /* 51 */            MAP_OP_CODE_deactivateTraceMode,
   /* 52 */            MAP_OP_CODE_dummy_52,
   /* 53 */            MAP_OP_CODE_dummy_53,
   /* 54 */            MAP_OP_CODE_beginSubscriberActivity,
   /* 55 */            MAP_OP_CODE_sendIdentification,
   /* 56 */            MAP_OP_CODE_sendAuthenticationInfo,
   /* 57 */            MAP_OP_CODE_restoreData,
   /* 58 */            MAP_OP_CODE_sendIMSI,
   /* 59 */            MAP_OP_CODE_processUnstructuredSSRequest,
   /* 60 */            MAP_OP_CODE_unstructuredSSRequest,
   /* 61 */            MAP_OP_CODE_unstructuredSSNotify,
   /* 62 */            MAP_OP_CODE_anyTimeSubscriptionInterrogation,
   /* 63 */            MAP_OP_CODE_informServiceCentre,
   /* 64 */            MAP_OP_CODE_alertServiceCentre,
   /* 65 */            MAP_OP_CODE_anyTimeModification,
   /* 66 */            MAP_OP_CODE_readyForSM,
   /* 67 */            MAP_OP_CODE_purgeMS,
   /* 68 */            MAP_OP_CODE_prepareHandover,
   /* 69 */            MAP_OP_CODE_prepareSubsequentHandover,
   /* 70 */            MAP_OP_CODE_provideSubscriberInfo,
   /* 71 */            MAP_OP_CODE_anyTimeInterrogation,
   /* 72 */            MAP_OP_CODE_ssInvocationNotification,
   /* 73 */            MAP_OP_CODE_setReportingState,
   /* 74 */            MAP_OP_CODE_statusReport,
   /* 75 */            MAP_OP_CODE_remoteUserFree,
   /* 76 */            MAP_OP_CODE_registerCCEntry,
   /* 77 */            MAP_OP_CODE_eraseCCEntry,
   /* 78 */            MAP_OP_CODE_dummy_78,
   /* 79 */            MAP_OP_CODE_dummy_79,
   /* 80 */            MAP_OP_CODE_dummy_80,
   /* 81 */            MAP_OP_CODE_dummy_81,
   /* 82 */            MAP_OP_CODE_dummy_82,
   /* 83 */            MAP_OP_CODE_provideSubscriberLocation,
   /* 84 */            MAP_OP_CODE_sendGroupCallInfo,
   /* 85 */            MAP_OP_CODE_sendRoutingInfoForLCS,
   /* 86 */            MAP_OP_CODE_subscriberLocationReport,
   /* 87 */            MAP_OP_CODE_istAlert,
   /* 88 */            MAP_OP_CODE_istCommand,
   /* 89 */            MAP_OP_CODE_noteMMEvent,
   /* 90 */            MAP_OP_CODE_MAXIMUM
};






enum EMapApplicationContext
{
   /* 00 */            MAP_AC_UNKNOWN=0,
   /* 01 */            MAP_AC_CODE_networkLocUp,
   /* 02 */            MAP_AC_CODE_locationCancel,
   /* 03 */            MAP_AC_CODE_roamingNbEnquiry,
   /* 04 */            MAP_AC_CODE_IST_Alerting,
   /* 05 */            MAP_AC_CODE_locInfoRetrieval,
   /* 06 */            MAP_AC_CODE_callControlTransfer,
   /* 07 */            MAP_AC_CODE_reporting,
   /* 08 */            MAP_AC_CODE_callCompletion,
   /* 09 */            MAP_AC_CODE_ServiceTermination,
   /* 10 */            MAP_AC_CODE_reset,
   /* 11 */            MAP_AC_CODE_handoverControl,
   /* 12 */            MAP_AC_CODE_sIWFSAllocation,
   /* 13 */            MAP_AC_CODE_equipmentMngt,
   /* 14 */            MAP_AC_CODE_infoRetrieval,
   /* 15 */            MAP_AC_CODE_interVlrInfoRetrieval,
   /* 16 */            MAP_AC_CODE_subscriberDataMngt,
   /* 17 */            MAP_AC_CODE_tracing,
   /* 18 */            MAP_AC_CODE_networkFunctionalSs,
   /* 19 */            MAP_AC_CODE_networkUnstructuredSs,
   /* 20 */            MAP_AC_CODE_shortMsgGateway,
   /* 21 */            MAP_AC_CODE_shortMsgMORelay,
   /* 22 */            MAP_AC_CODE_subscriberDataModificationNotification,
   /* 23 */            MAP_AC_CODE_shortMsgAlert,
   /* 24 */            MAP_AC_CODE_mwdMngt,
   /* 25 */            MAP_AC_CODE_shortMsgMTRelay,
   /* 26 */            MAP_AC_CODE_imsiRetrieval,
   /* 27 */            MAP_AC_CODE_msPurging,
   /* 28 */            MAP_AC_CODE_subscriberInfoEnquiry,
   /* 29 */            MAP_AC_CODE_anyTimeEnquiry,
   /* 30 */            MAP_AC_CODE_dummy_30,
   /* 31 */            MAP_AC_CODE_groupCallControl,
   /* 32 */            MAP_AC_CODE_gprsLocationUpdate,
   /* 33 */            MAP_AC_CODE_gprsLocationInfoRetrieval,
   /* 34 */            MAP_AC_CODE_failureReport,
   /* 35 */            MAP_AC_CODE_gprsNotify,
   /* 36 */            MAP_AC_CODE_ssInvocationNotification,
   /* 37 */            MAP_AC_CODE_locationSvcGateway,
   /* 38 */            MAP_AC_CODE_locationSvcEnquiry,
   /* 39 */            MAP_AC_CODE_authenticationFailureReport,
   /* 40 */            MAP_AC_CODE_dummy_40,
   /* 41 */            MAP_AC_CODE_shortMsgMT_Relay_VGCS,
   /* 42 */            MAP_AC_CODE_mm_EventReporting,
   /* 43 */            MAP_AC_CODE_anyTimeInfoHandling,
   /* 44 */            MAP_AC_CODE_resourceManagement,
   /* 45 */            MAP_AC_CODE_groupCallInfoRetrieval,
   /* 46 */            MAP_AC_CODE_MAXIMUM
};










enum EMapErrorCode
{
   /* 00 */    MAP_ERROR_UNKNOWN=0,
   /* 01 */    MAP_ERROR_unknownSubscriber,
   /* 02 */    MAP_ERROR_dummy_2,
   /* 03 */    MAP_ERROR_unknownMSC,
   /* 04 */    MAP_ERROR_dummy_4,
   /* 05 */    MAP_ERROR_unidentifiedSub,
   /* 06 */    MAP_ERROR_absentSubscriberSM,
   /* 07 */    MAP_ERROR_unknownEquipment,
   /* 08 */    MAP_ERROR_roamingNotAllowed,
   /* 09 */    MAP_ERROR_illegalSubscriber,
   /* 10 */    MAP_ERROR_bearerServNotProv,
   /* 11 */    MAP_ERROR_teleservNotProv,
   /* 12 */    MAP_ERROR_illegalEquipment,
   /* 13 */    MAP_ERROR_callBarred,
   /* 14 */    MAP_ERROR_forwardingViolation,
   /* 15 */    MAP_ERROR_CUG_Reject,
   /* 16 */    MAP_ERROR_illegalSS_Operation,
   /* 17 */    MAP_ERROR_ss_ErrorStatus,
   /* 18 */    MAP_ERROR_ssNotAvailable,
   /* 19 */    MAP_ERROR_ssSubscriptionViolation,
   /* 20 */    MAP_ERROR_ssIncompatibilityCause,
   /* 21 */    MAP_ERROR_facilityNotSup,
   /* 22 */    MAP_ERROR_ongoingGroupCall,
   /* 23 */    MAP_ERROR_dummy_23,
   /* 24 */    MAP_ERROR_dummy_24,
   /* 25 */    MAP_ERROR_noHandoverNumberAvailable,
   /* 26 */    MAP_ERROR_subsequentHandoverFailure,
   /* 27 */    MAP_ERROR_absentSubscriber,
   /* 28 */    MAP_ERROR_incompatibleTerminal,
   /* 29 */    MAP_ERROR_shortTermDenial,
   /* 30 */    MAP_ERROR_longTermDenial,
   /* 31 */    MAP_ERROR_subBusyForMT_SMS,
   /* 32 */    MAP_ERROR_smDeliveryFailureCause,
   /* 33 */    MAP_ERROR_messageWaitingListFull,
   /* 34 */    MAP_ERROR_systemFailure,
   /* 35 */    MAP_ERROR_dataMissing,
   /* 36 */    MAP_ERROR_unexpectedData,
   /* 37 */    MAP_ERROR_pwRegistrationFailureCause,
   /* 38 */    MAP_ERROR_negativePW_Check,
   /* 39 */    MAP_ERROR_noRoamingNb,
   /* 40 */    MAP_ERROR_tracingBufferFull,
   /* 41 */    MAP_ERROR_dummy_41,
   /* 42 */    MAP_ERROR_targetCellOutsideGCA,
   /* 43 */    MAP_ERROR_numberOfPW_AttemptsViolation,
   /* 44 */    MAP_ERROR_numberChanged,
   /* 45 */    MAP_ERROR_busySubscriber,
   /* 46 */    MAP_ERROR_noSubscriberReply,
   /* 47 */    MAP_ERROR_forwardingFailed,
   /* 48 */    MAP_ERROR_orNotAllowed,
   /* 49 */    MAP_ERROR_atiNotAllowed,
   /* 50 */    MAP_ERROR_noGroupCallNumberAvailable,
   /* 51 */    MAP_ERROR_resourceLimitation,
   /* 52 */    MAP_ERROR_unauthorizedRequestingNetwork,
   /* 53 */    MAP_ERROR_unauthorizedLCSClient,
   /* 54 */    MAP_ERROR_positionMethodFailure,
   /* 55 */    MAP_ERROR_dummy_55,
   /* 56 */    MAP_ERROR_dummy_56,
   /* 57 */    MAP_ERROR_dummy_57,
   /* 58 */    MAP_ERROR_unknownOrUnreachableLCSClient,
   /* 59 */    MAP_ERROR_mmEventNotSupported,
   /* 60 */    MAP_ERROR_atsiNotAllowed,
   /* 61 */    MAP_ERROR_atmNotAllowed,
   /* 62 */    MAP_ERROR_informationNotAvailable,
   /* 63 */    MAP_ERROR_dummy_63,
   /* 64 */    MAP_ERROR_dummy_64,
   /* 65 */    MAP_ERROR_dummy_65,
   /* 66 */    MAP_ERROR_dummy_66,
   /* 67 */    MAP_ERROR_dummy_67,
   /* 68 */    MAP_ERROR_dummy_68,
   /* 69 */    MAP_ERROR_dummy_69,
   /* 70 */    MAP_ERROR_dummy_70,
   /* 71 */    MAP_ERROR_unknownAlphabet,
   /* 72 */    MAP_ERROR_ussd_Busy,
   /* 73 */    MAP_ERROR_MAXIMUM
};









class MapConstants
{
   private:
      static int getMapOpCodeTimerValue(EMapOpCode p_EMapOpCode);
      MapConstants(){}

      static char m_ApplCtxtOpCodeCharArr[1000];

   public:
      static bool initialize(ConstantsLogOverride *p_clo);

      // Op Code based Retrieval functions
      static bool isMapOpCodeValid(EMapOpCode p_EMapOpCode);       	
      static bool isApplCtxtOpCodeCombValid(EMapApplicationContext p_EMapACCode, EMapOpCode p_EMapOpCode);

      static int getMapOpCodeResPDU(EMapOpCode p_EMapOpCode,EMapVersion p_version);       	
      static int getMapOpCodeArgPDU(EMapOpCode p_EMapOpCode,EMapVersion p_version);      

      static int getMapOpCodeConfFlag(EMapOpCode p_EMapOpCode);

      // Application Context based Retrieval functions
      static int getMapApplCtxtMinVersion(EMapApplicationContext p_EMapACCode);                   
      static int getMapApplCtxtMaxVersion(EMapApplicationContext p_EMapACCode);  

      // Error Code based Retrieval functions
      static int getMapErrorCodePDU(EMapErrorCode p_error, EMapVersion p_version);         

      static int getMapOpCodeMaxTime(EMapOpCode p_EMapOpCode);
      static int getMapOpCodeMinTime(EMapOpCode p_EMapOpCode);

      static char *getMapOpCodeName(EMapOpCode p_EMapOpCode);       	
      static char *getMapApplCtxtName(EMapApplicationContext p_EMapACCode);      

      static char *getMapOpCodeChar(int p_OpCode);
      static char *getMapApplCodeChar(int p_ApplCode);
      static char *getMapErrorCodeChar(int p_ErrorCode);

      static EMapApplicationContext getV1ApplCtxt(EMapOpCode p_opCode);

      static int getBeginSubscriberActivityPdu();         
      static int getMapDialoguePdu();         

      static unsigned char getExtensionContainerBitMaskValue(EMapOpCode p_OpCode, EMapVersion p_MapVersion);
      static int getExtensionContainerFlag(EMapOpCode p_OpCode, EMapVersion p_MapVersion);

};

extern bool printHex(char *p_str, char *p_buf, int p_len, char *p_output);


#define CONS_LOG(LOG_LEVEL, ...) {if(g_clo != NULL) { char l_msg[1000]; memset(l_msg, '\0', 1000); sprintf(l_msg, __VA_ARGS__); g_clo->override(LOG_LEVEL, l_msg); } }

#define CONS_LOG_HEX(LOG_LEVEL, STRING, HEX_DATA, HEX_LEN)  { char l_tmpStr[1000];  memset(l_tmpStr, 0, sizeof(l_tmpStr)); snprintf(l_tmpStr, sizeof(l_tmpStr), "%s: Len:%d  Buffer: ", STRING, HEX_LEN); printHex(STRING, HEX_DATA, HEX_LEN, l_tmpStr); g_clo->override(LOG_LEVEL, l_tmpStr);  }

//#define CONS_LOG_HEX(LOG_LEVEL, STRING, HEX_DATA, HEX_LEN)  { printf("\n ### test ####\n"); char l_tmpStr[1000]; printf("\n ### test 0.5 ####\n");  memset(l_tmpStr, 0, sizeof(l_tmpStr)); printf("\n ### test 2 ####\n");snprintf(l_tmpStr, sizeof(l_tmpStr), "%s: Len:%d  Buffer: ", STRING, HEX_LEN); printf("\n ### test 3 ####\n"); printHex(STRING, HEX_DATA, HEX_LEN, l_tmpStr); printf("\n ### test 4####\n");   g_clo->override(LOG_LEVEL, l_tmpStr);  }


#endif
