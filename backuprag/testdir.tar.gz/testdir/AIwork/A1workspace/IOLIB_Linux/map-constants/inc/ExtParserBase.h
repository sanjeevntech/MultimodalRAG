#ifndef __EXT_PARSER_BASE_H
#define __EXT_PARSER_BASE_H

#include <MapConstants.h>

class ExtParserBase
{
   public:
      ExtParserBase();
      virtual ~ExtParserBase();
      virtual bool callRespectiveDecoder(EMapOpCode p_OpCode, EMapVersion p_MapVersion, 
                                         unsigned char *p_extTypeValue, int p_extTypeLength, 
                                         char *p_buffer)=0;
};


#endif  //__EXT_PARSER_BASE_H
