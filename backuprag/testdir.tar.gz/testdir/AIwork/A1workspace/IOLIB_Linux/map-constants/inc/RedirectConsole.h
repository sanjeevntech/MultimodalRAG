#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <string.h>

class RedirectConsole
{
    public:
        RedirectConsole();
        ~RedirectConsole();
        bool start();
        bool end(char *p_data, int p_maxLength);

    private:
        int m_arr[2];
        //int m_fd_file;//Uncomment for debugging
};

#define REDIRECT_CONSOLE_TO_BUF(DATA, LENGTH, FUNC)  \
                    RedirectConsole l_rc; \
                    if(l_rc.start()) \
                    { \
                        FUNC;  \
                        l_rc.end(DATA, LENGTH); \
                    }

