/*************************************************************/
/* Copyright (C) 2010 OSS Nokalva, Inc.  All rights reserved.*/
/*************************************************************/

/* THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC.
 * AND MAY BE USED ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC.
 * THIS FILE MAY NOT BE DISTRIBUTED. */

/* Generated for: Lyca Technologies Solutions Pvt. Ltd., Chennai, India - License 60124 for Solaris 64-bit */
/* Abstract syntax: MAP1 */
/* Created: Fri Jun 11 15:24:41 2010 */
/* ASN.1 compiler version: 8.4 */
/* Code generated for runtime version 8.4 or later */
/* Compiler operating system: Solaris 7 with 64-bit support */
/* Compiler machine type: SPARC */
/* Target operating system: Solaris 7 with 64-bit support */
/* Target machine type: SPARC */
/* C compiler options required: -xarch=v9 */
/* ASN.1 compiler options and file names specified:
 * -prefix OMAP1_ -c++ -relaxedMode -ber -root -compat v4.2defaults
 * -compat v4.2octetstringdefault -compat paddedfornamedbits
 * ../../asn1dflt.solaris7-64bit TCAP.asn MAP-ExtensionDataTypes.asn
 * MAP-Constants.asn MAP-DataTypes.asn MAP1-DataTypes.asn MAP-Errors.asn
 * MAP-Operations.asn MAP1.asn
 */

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */
#define    OSS_SOED_BER
#include   "osstype.h"
#include   "MAP1.h"

#ifndef _OSSNOVALUES

const int OMAP1_maxNumOfPrivateExtensions = 10;

const int OMAP1_maxSignalInfoLength = 200;

const int OMAP1_maxNumOfTeleServices = 20;

const int OMAP1_maxNumOfBearerServices = 50;

const int OMAP1_maxNumOfSS = 30;

const int OMAP1_maxNumOfCUG = 10;

const int OMAP1_maxNumOfBasicServices = 70;

const int OMAP1_maxNumOfForwardingFeatures = 13;

const int OMAP1_maxNumOfCallBarringFeatures = 13;

const int OMAP1_maxNumOfHlrId = 50;

const int OMAP1_maxPacketDataVolume = 100;

const int OMAP1_maxNumOfChargingUnit = 16777215;

const int OMAP1_maxCallDuration = 16777215;

const int OMAP1_maxAddressLength = 20;

const int OMAP1_maxNumOfSentParameters = 6;

const int OMAP1_maxNumOfBasicServiceGroups = 13;

OMAP1_UpdateLocationArea OMAP1_updateLocationArea = {
    OMAP1_localValue_chosen
};

OMAP1_UpdateLocation OMAP1_updateLocation = {
    OMAP1_localValue_chosen
};

OMAP1_CancelLocation OMAP1_cancelLocation = {
    OMAP1_localValue_chosen
};

OMAP1_ProvideRoamingNumber OMAP1_provideRoamingNumber = {
    OMAP1_localValue_chosen
};

OMAP1_DetachIMSI OMAP1_detachIMSI = {
    OMAP1_localValue_chosen
};

OMAP1_AttachIMSI OMAP1_attachIMSI = {
    OMAP1_localValue_chosen
};

OMAP1_InsertSubscriberData OMAP1_insertSubscriberData = {
    OMAP1_localValue_chosen
};

OMAP1_DeleteSubscriberData OMAP1_deleteSubscriberData = {
    OMAP1_localValue_chosen
};

OMAP1_SendParameters OMAP1_sendParameters = {
    OMAP1_localValue_chosen
};

OMAP1_RegisterSS OMAP1_registerSS = {
    OMAP1_localValue_chosen
};

OMAP1_EraseSS OMAP1_eraseSS = {
    OMAP1_localValue_chosen
};

OMAP1_ActivateSS OMAP1_activateSS = {
    OMAP1_localValue_chosen
};

OMAP1_DeactivateSS OMAP1_deactivateSS = {
    OMAP1_localValue_chosen
};

OMAP1_InterrogateSS OMAP1_interrogateSS = {
    OMAP1_localValue_chosen
};

OMAP1_InvokeSS OMAP1_invokeSS = {
    OMAP1_localValue_chosen
};

OMAP1_ForwardSsNotification OMAP1_forwardSsNotification = {
    OMAP1_localValue_chosen
};

OMAP1_RegisterPassword OMAP1_registerPassword = {
    OMAP1_localValue_chosen
};

OMAP1_GetPassword OMAP1_getPassword = {
    OMAP1_localValue_chosen
};

OMAP1_ProcessUnstructuredSsData OMAP1_processUnstructuredSsData = {
    OMAP1_localValue_chosen
};

OMAP1_SendInfoForIncomingCall OMAP1_sendInfoForIncomingCall = {
    OMAP1_localValue_chosen
};

OMAP1_SendInfoForOutgoingCall OMAP1_sendInfoForOutgoingCall = {
    OMAP1_localValue_chosen
};

OMAP1_SendRoutingInformation OMAP1_sendRoutingInformation = {
    OMAP1_localValue_chosen
};

OMAP1_CompleteCall OMAP1_completeCall = {
    OMAP1_localValue_chosen
};

OMAP1_ConnectToFollowingAddress OMAP1_connectToFollowingAddress = {
    OMAP1_localValue_chosen
};

OMAP1_ProcessCallWaiting OMAP1_processCallWaiting = {
    OMAP1_localValue_chosen
};

OMAP1_Page OMAP1_page = {
    OMAP1_localValue_chosen
};

OMAP1_SearchForMobileSubscriber OMAP1_searchForMobileSubscriber = {
    OMAP1_localValue_chosen
};

OMAP1_PerformHandover OMAP1_performHandover = {
    OMAP1_localValue_chosen
};

OMAP1_SendEndSignal OMAP1_sendEndSignal = {
    OMAP1_localValue_chosen
};

OMAP1_PerformSubsequentHandover OMAP1_performSubsequentHandover = {
    OMAP1_localValue_chosen
};

OMAP1_AllocateHandoverNumber OMAP1_allocateHandoverNumber = {
    OMAP1_localValue_chosen
};

OMAP1_SendHandoverReport OMAP1_sendHandoverReport = {
    OMAP1_localValue_chosen
};

OMAP1_ProcessAccessSignalling OMAP1_processAccessSignalling = {
    OMAP1_localValue_chosen
};

OMAP1_ForwardAccessSignalling OMAP1_forwardAccessSignalling = {
    OMAP1_localValue_chosen
};

OMAP1_NoteInternalHandover OMAP1_noteInternalHandover = {
    OMAP1_localValue_chosen
};

OMAP1_RegisterChargingInformation OMAP1_registerChargingInformation = {
    OMAP1_localValue_chosen
};

OMAP1_Reset OMAP1_reset = {
    OMAP1_localValue_chosen
};

OMAP1_ForwardCheckSsIndication OMAP1_forwardCheckSsIndication = {
    OMAP1_localValue_chosen
};

OMAP1_Authenticate OMAP1_authenticate = {
    OMAP1_localValue_chosen
};

OMAP1_ProvideIMSI OMAP1_provideIMSi = {
    OMAP1_localValue_chosen
};

OMAP1_ForwardNewTMSI OMAP1_forwardNewTMSI = {
    OMAP1_localValue_chosen
};

OMAP1_SetCipheringMode OMAP1_setCipheringMode = {
    OMAP1_localValue_chosen
};

OMAP1_CheckIMEI OMAP1_checkIMEI = {
    OMAP1_localValue_chosen
};

OMAP1_SendRoutingInfoForSM OMAP1_sendRoutingInfoForSM = {
    OMAP1_localValue_chosen
};

OMAP1_ForwardShortMessage OMAP1_forwardShortMessage = {
    OMAP1_localValue_chosen
};

OMAP1_SetMessageWaitingData OMAP1_setMessageWaitingData = {
    OMAP1_localValue_chosen
};

OMAP1_NoteMSPresent OMAP1_noteMSPresent = {
    OMAP1_localValue_chosen
};

OMAP1_AlertServiceCentre OMAP1_alertServiceCentre = {
    OMAP1_localValue_chosen
};

OMAP1_ActivateTraceMode OMAP1_activateTraceMode = {
    OMAP1_localValue_chosen
};

OMAP1_DeactivateTraceMode OMAP1_deactivateTraceMode = {
    OMAP1_localValue_chosen
};

OMAP1_TraceSubscriberActivity OMAP1_traceSubscriberActivity = {
    OMAP1_localValue_chosen
};

OMAP1_ProcessAccessRequest OMAP1_processAccessRequest = {
    OMAP1_localValue_chosen
};

OMAP1_BeginSubscriberActivity OMAP1_beginSubscriberActivity = {
    OMAP1_localValue_chosen
};

OMAP1_UnknownSubscriber OMAP1_unknownSubscriber = {
    OMAP1_localValue_chosen
};

OMAP1_UnknownBaseStation OMAP1_unknownBaseStation = {
    OMAP1_localValue_chosen
};

OMAP1_UnknownMSC OMAP1_unknownMSC = {
    OMAP1_localValue_chosen
};

OMAP1_UnknownLocArea OMAP1_unknownLocArea = {
    OMAP1_localValue_chosen
};

OMAP1_UnidentifiedSubscriber OMAP1_unidentifiedSubscriber = {
    OMAP1_localValue_chosen
};

OMAP1_UnallocatedRoamingNumber OMAP1_unallocatedRoamingNumber = {
    OMAP1_localValue_chosen
};

OMAP1_UnknownEquipment OMAP1_unknownEquipment = {
    OMAP1_localValue_chosen
};

OMAP1_RoamingNotAllowed OMAP1_roamingNotAllowed = {
    OMAP1_localValue_chosen
};

OMAP1_IllegalMS OMAP1_illegalMS = {
    OMAP1_localValue_chosen
};

OMAP1_BearerServiceNotProvisioned OMAP1_bearerServiceNotProvisioned = {
    OMAP1_localValue_chosen
};

OMAP1_TeleserviceNotProvisioned OMAP1_teleServiceNotProvisioned = {
    OMAP1_localValue_chosen
};

OMAP1_InsufficientBearerCapabilities OMAP1_insufficientBearerCapabilities = {
    OMAP1_localValue_chosen
};

OMAP1_CallBarred OMAP1_callBarred = {
    OMAP1_localValue_chosen
};

OMAP1_ForwardingViolation OMAP1_forwardingViolation = {
    OMAP1_localValue_chosen
};

OMAP1_CUG_Reject OMAP1_cug_Reject = {
    OMAP1_localValue_chosen
};

OMAP1_IllegalSS_Operation OMAP1_illegalSS_Operation = {
    OMAP1_localValue_chosen
};

OMAP1_SS_ErrorStatus OMAP1_ss_ErrorStatus = {
    OMAP1_localValue_chosen
};

OMAP1_SS_NotAvailable OMAP1_ss_NotAvailable = {
    OMAP1_localValue_chosen
};

OMAP1_SS_SubscriptionViolation OMAP1_ss_SubscriptionViolation = {
    OMAP1_localValue_chosen
};

OMAP1_SS_Incompatibility OMAP1_ss_Incompatibility = {
    OMAP1_localValue_chosen
};

OMAP1_FacilityNotSupported OMAP1_facilityNotSupported = {
    OMAP1_localValue_chosen
};

OMAP1_InvalidTargetBaseStation OMAP1_invalidTargetBaseStation = {
    OMAP1_localValue_chosen
};

OMAP1_NoRadioResourceAvailable OMAP1_noRadioResourceAvailable = {
    OMAP1_localValue_chosen
};

OMAP1_NoHandoverNumberAvailable OMAP1_noHandoverNumberAvailable = {
    OMAP1_localValue_chosen
};

OMAP1_SubsequentHandoverFailure OMAP1_subsequentHandoverFailure = {
    OMAP1_localValue_chosen
};

OMAP1_AbsentSubscriber OMAP1_absentSubscriber = {
    OMAP1_localValue_chosen
};

OMAP1_BusySubscriber OMAP1_busySubscriber = {
    OMAP1_localValue_chosen
};

OMAP1_NoSubscriberReply OMAP1_noSubscriberReply = {
    OMAP1_localValue_chosen
};

OMAP1_RadioCongestion OMAP1_radioCongestion = {
    OMAP1_localValue_chosen
};

OMAP1_ImpossibleCallCompletion OMAP1_impossibleCallCompletion = {
    OMAP1_localValue_chosen
};

OMAP1_SM_DeliveryFailure OMAP1_sm_DeliveryFailure = {
    OMAP1_localValue_chosen
};

OMAP1_MessageWaitingListFull OMAP1_messageWaitingListFull = {
    OMAP1_localValue_chosen
};

OMAP1_SystemFailure OMAP1_systemFailure = {
    OMAP1_localValue_chosen
};

OMAP1_DataMissing OMAP1_dataMissing = {
    OMAP1_localValue_chosen
};

OMAP1_UnexpectedDataValue OMAP1_unexpectedDataValue = {
    OMAP1_localValue_chosen
};

OMAP1_PasswordRegistrationFailure OMAP1_passwordRegistrationFailure = {
    OMAP1_localValue_chosen
};

OMAP1_NegativePasswordCheck OMAP1_negativePasswordCheck = {
    OMAP1_localValue_chosen
};

OMAP1_NoRoamingNumberAvailable OMAP1_noRoamingNumberAvailable = {
    OMAP1_localValue_chosen
};

OMAP1_TracingBufferFull OMAP1_tracingBufferFull = {
    OMAP1_localValue_chosen
};


#if !defined(OSS_SPARTAN_AWARE) || ((OSS_SPARTAN_AWARE + 0) < 2)
static ObjectSetEntry const OMAP1_ExtensionSet[] = {
{0}};

#else /* OSS_SPARTAN_AWARE >= 2 */

#if ((OSS_SPARTAN_AWARE + 0) > 12)
static ObjectSetEntry const OMAP1_ExtensionSet[] = {
{0}};
#else /* OSS_SPARTAN_AWARE <= 12 */
static ObjectSetEntry const OMAP1_ExtensionSet[] = {
{0}};
#endif /* (OSS_SPARTAN_AWARE + 0) > 12 */

static unsigned short const _oss_OSet_info[] =  {
    4
};
#endif /* !OSS_SPARTAN_AWARE || OSS_SPARTAN_AWARE < 2 */

#endif  /* #ifndef _OSSNOVALUES */

#ifdef OSS_SPARTAN_AWARE
#if ((OSS_SPARTAN_AWARE + 0) >= 3)
extern void _oss_run_SOED_on_SPARC_SOLARIS_7_64BIT(void);
static void _oss_post_init(struct ossGlobal *world);
#endif /* OSS_SPARTAN_AWARE >= 3 */
#endif /* OSS_SPARTAN_AWARE */

#ifdef OSS_SPARTAN_AWARE
#if ((OSS_SPARTAN_AWARE + 0) >= 12)
static unsigned char _privateFlags[] = {0x01,0x00};
#endif /* OSS_SPARTAN_AWARE >= 12 */
#endif /* OSS_SPARTAN_AWARE */

static void _ossinit_MAP1(struct ossGlobal *world) {
#ifndef _OSSNOVALUES

    OMAP1_updateLocationArea.u.localValue = 1;
    OMAP1_updateLocation.u.localValue = 2;
    OMAP1_cancelLocation.u.localValue = 3;
    OMAP1_provideRoamingNumber.u.localValue = 4;
    OMAP1_detachIMSI.u.localValue = 5;
    OMAP1_attachIMSI.u.localValue = 6;
    OMAP1_insertSubscriberData.u.localValue = 7;
    OMAP1_deleteSubscriberData.u.localValue = 8;
    OMAP1_sendParameters.u.localValue = 9;
    OMAP1_registerSS.u.localValue = 10;
    OMAP1_eraseSS.u.localValue = 11;
    OMAP1_activateSS.u.localValue = 12;
    OMAP1_deactivateSS.u.localValue = 13;
    OMAP1_interrogateSS.u.localValue = 14;
    OMAP1_invokeSS.u.localValue = 15;
    OMAP1_forwardSsNotification.u.localValue = 16;
    OMAP1_registerPassword.u.localValue = 17;
    OMAP1_getPassword.u.localValue = 18;
    OMAP1_processUnstructuredSsData.u.localValue = 19;
    OMAP1_sendInfoForIncomingCall.u.localValue = 20;
    OMAP1_sendInfoForOutgoingCall.u.localValue = 21;
    OMAP1_sendRoutingInformation.u.localValue = 22;
    OMAP1_completeCall.u.localValue = 23;
    OMAP1_connectToFollowingAddress.u.localValue = 24;
    OMAP1_processCallWaiting.u.localValue = 25;
    OMAP1_page.u.localValue = 26;
    OMAP1_searchForMobileSubscriber.u.localValue = 27;
    OMAP1_performHandover.u.localValue = 28;
    OMAP1_sendEndSignal.u.localValue = 29;
    OMAP1_performSubsequentHandover.u.localValue = 30;
    OMAP1_allocateHandoverNumber.u.localValue = 31;
    OMAP1_sendHandoverReport.u.localValue = 32;
    OMAP1_processAccessSignalling.u.localValue = 33;
    OMAP1_forwardAccessSignalling.u.localValue = 34;
    OMAP1_noteInternalHandover.u.localValue = 35;
    OMAP1_registerChargingInformation.u.localValue = 36;
    OMAP1_reset.u.localValue = 37;
    OMAP1_forwardCheckSsIndication.u.localValue = 38;
    OMAP1_authenticate.u.localValue = 39;
    OMAP1_provideIMSi.u.localValue = 40;
    OMAP1_forwardNewTMSI.u.localValue = 41;
    OMAP1_setCipheringMode.u.localValue = 42;
    OMAP1_checkIMEI.u.localValue = 43;
    OMAP1_sendRoutingInfoForSM.u.localValue = 45;
    OMAP1_forwardShortMessage.u.localValue = 46;
    OMAP1_setMessageWaitingData.u.localValue = 47;
    OMAP1_noteMSPresent.u.localValue = 48;
    OMAP1_alertServiceCentre.u.localValue = 49;
    OMAP1_activateTraceMode.u.localValue = 50;
    OMAP1_deactivateTraceMode.u.localValue = 51;
    OMAP1_traceSubscriberActivity.u.localValue = 52;
    OMAP1_processAccessRequest.u.localValue = 53;
    OMAP1_beginSubscriberActivity.u.localValue = 54;
    OMAP1_unknownSubscriber.u.localValue = 1;
    OMAP1_unknownBaseStation.u.localValue = 2;
    OMAP1_unknownMSC.u.localValue = 3;
    OMAP1_unknownLocArea.u.localValue = 4;
    OMAP1_unidentifiedSubscriber.u.localValue = 5;
    OMAP1_unallocatedRoamingNumber.u.localValue = 6;
    OMAP1_unknownEquipment.u.localValue = 7;
    OMAP1_roamingNotAllowed.u.localValue = 8;
    OMAP1_illegalMS.u.localValue = 9;
    OMAP1_bearerServiceNotProvisioned.u.localValue = 10;
    OMAP1_teleServiceNotProvisioned.u.localValue = 11;
    OMAP1_insufficientBearerCapabilities.u.localValue = 12;
    OMAP1_callBarred.u.localValue = 13;
    OMAP1_forwardingViolation.u.localValue = 14;
    OMAP1_cug_Reject.u.localValue = 15;
    OMAP1_illegalSS_Operation.u.localValue = 16;
    OMAP1_ss_ErrorStatus.u.localValue = 17;
    OMAP1_ss_NotAvailable.u.localValue = 18;
    OMAP1_ss_SubscriptionViolation.u.localValue = 19;
    OMAP1_ss_Incompatibility.u.localValue = 20;
    OMAP1_facilityNotSupported.u.localValue = 21;
    OMAP1_invalidTargetBaseStation.u.localValue = 23;
    OMAP1_noRadioResourceAvailable.u.localValue = 24;
    OMAP1_noHandoverNumberAvailable.u.localValue = 25;
    OMAP1_subsequentHandoverFailure.u.localValue = 26;
    OMAP1_absentSubscriber.u.localValue = 27;
    OMAP1_busySubscriber.u.localValue = 28;
    OMAP1_noSubscriberReply.u.localValue = 29;
    OMAP1_radioCongestion.u.localValue = 30;
    OMAP1_impossibleCallCompletion.u.localValue = 31;
    OMAP1_sm_DeliveryFailure.u.localValue = 32;
    OMAP1_messageWaitingListFull.u.localValue = 33;
    OMAP1_systemFailure.u.localValue = 34;
    OMAP1_dataMissing.u.localValue = 35;
    OMAP1_unexpectedDataValue.u.localValue = 36;
    OMAP1_passwordRegistrationFailure.u.localValue = 37;
    OMAP1_negativePasswordCheck.u.localValue = 38;
    OMAP1_noRoamingNumberAvailable.u.localValue = 39;
    OMAP1_tracingBufferFull.u.localValue = 40;
#endif  /* #ifdef _OSSNOVALUES */

#ifdef OSS_SPARTAN_AWARE
#if ((OSS_SPARTAN_AWARE + 0) >= 3)
    _oss_run_SOED_on_SPARC_SOLARIS_7_64BIT();
#endif /* OSS_SPARTAN_AWARE >= 3 */
#endif /* OSS_SPARTAN_AWARE */
#ifdef OSS_SPARTAN_AWARE
#if ((OSS_SPARTAN_AWARE + 0) >= 12)
    ossPrivateSetMoreFlags(world, 12, _privateFlags);
#endif /* OSS_SPARTAN_AWARE >= 12 */
#endif /* OSS_SPARTAN_AWARE */
    ossLinkBer(world);
#ifdef OSS_SPARTAN_AWARE
    ossLinkCmpValue(world);
#if ((OSS_SPARTAN_AWARE + 0) >= 2)
    ossInitObjectSetInfo(world, (unsigned short *)_oss_OSet_info);
#endif /* OSS_SPARTAN_AWARE >= 2 */
#endif /* OSS_SPARTAN_AWARE */

#ifdef OSS_SPARTAN_AWARE
#if ((OSS_SPARTAN_AWARE + 0) >= 3)
    _oss_post_init(world);
#endif /* OSS_SPARTAN_AWARE >= 3 */
#endif /* OSS_SPARTAN_AWARE */
}

static int const _v18[13] = {
  0, 1, 2, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13
};
static int const _v22[8] = {
  0, 1, 2, 3, 4, 5, 6, 7
};
static int const _v24[6] = {
  1, 2, 4, 8, 9, 10
};
static unsigned short const _v21[4] = {
  0, 1, 2, 255
};
static int const _v9[4] = {
  1, 2, 3, 4
};

static const unsigned short _pduarray[] = {
    1, 2, 3, 4, 5, 6, 7, 8, 9, 10,
    11, 12, 13, 14, 15, 16, 17, 18, 19, 20,
    21, 22, 23, 24, 25, 26, 27, 28, 29, 30,
    31, 32, 33, 34, 35, 36, 37, 38, 39, 40,
    41, 42, 43, 44, 45, 46, 47, 48, 49, 50,
    51, 52, 53, 54, 55, 56, 57, 58, 59, 60,
    61, 62, 63, 64, 65, 66, 67, 68, 69, 70,
    71, 72, 73, 74, 75, 76, 77, 78, 79, 80,
    81, 82, 83, 84, 85, 86, 87, 88, 89, 90,
    91, 92, 93, 94, 95, 96, 97, 98, 99, 100,
    101, 102, 103, 104, 105, 106, 107, 108, 109, 110,
    111, 112, 113, 114, 115, 116, 117, 118, 119, 120,
    121, 122, 123, 124, 125, 126, 127, 128, 129, 130,
    131, 132, 133, 134, 135, 136, 137, 138, 139, 140,
    141, 142, 143, 144, 145, 146, 147, 148, 149, 150,
    151, 152, 153, 154, 155, 156, 157, 158, 159, 160,
    161, 162, 163, 164, 165, 166, 167, 168, 169, 170,
    171, 172, 0
};

static const struct etype _etypearray[] = {
    {-1, 0, 0, (char *)"_ObjectID", 8, 8, 2, 8, 40, 0, 27, 0},
    {-1, 2, 3, (char *)"MessageType", 104, 5, 2, 8, 8, 0, 13, 0},
    {-1, 14, 16, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 5, 12, 0},
    {-1, 2, 26, (char *)"SS-SubscriptionOption", 8, 5, 2, 4, 8, 7, 13, 0},
    {-1, 14, 37, (char *)"UpdateLocationAreaArg", 34, 4, 0, 0, 8, 12, 12, 0},
    {-1, 14, 57, (char *)"UpdateLocationArg", 44, 4, 1, 0, 8, 16, 12, 0},
    {9, 75, 0, (char *)"UpdateLocationRes", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2, 77, (char *)"CancelLocationArg", 18, 2, 2, 2, 8, 20, 13, 0},
    {-1, 14, 82, (char *)"DetachIMSIArg", 12, 1, 0, 0, 8, 22, 12, 0},
    {-1, 14, 82, (char *)"AttachIMSIArg", 12, 1, 0, 0, 8, 22, 12, 0},
    {-1, 14, 88, (char *)"DeregisterMobileSubscriberArg", 10, 1, 0, 0, 8, 23, 12, 0},
    {-1, 14, 92, (char *)"InsertSubscriberDataArg", 35000, 7, 1, 0, 8, 24, 12, 0},
    {-1, 14, 162, (char *)"DeleteSubscriberDataArg", 556, 3, 1, 0, 8, 31, 12, 0},
    {-1, 14, 176, (char *)"SendParametersArg", 24, 2, 0, 0, 8, 34, 12, 0},
    {-1, 14, 186, (char *)"SendParametersRes", 209980, 1, 0, 0, 8, 36, 12, 0},
    {-1, 14, 190, (char *)"RegisterSSArg", 26, 4, 1, 0, 8, 37, 12, 0},
    {-1, 14, 214, (char *)"RegisterSSRes", 1156, 1, 0, 0, 8, 41, 12, 0},
    {-1, 14, 224, (char *)"EraseSSArg", 12, 2, 1, 0, 8, 42, 12, 0},
    {-1, 14, 214, (char *)"EraseSSRes", 1156, 1, 0, 0, 8, 41, 12, 0},
    {-1, 14, 224, (char *)"ActivateSSArg", 12, 2, 1, 0, 8, 44, 12, 0},
    {-1, 14, 214, (char *)"ActivateSSRes", 1156, 1, 0, 0, 8, 41, 12, 0},
    {-1, 14, 224, (char *)"DeactivateSSArg", 12, 2, 1, 0, 8, 46, 12, 0},
    {-1, 14, 214, (char *)"DeactivateSSRes", 1156, 1, 0, 0, 8, 41, 12, 0},
    {-1, 14, 224, (char *)"InterrogateSSArg", 12, 2, 1, 0, 8, 48, 12, 0},
    {-1, 14, 214, (char *)"InterrogateSSRes", 394, 1, 0, 0, 8, 50, 12, 0},
    {-1, 14, 234, (char *)"InvokeSSArg", 20, 5, 1, 0, 8, 51, 12, 0},
    {-1, 14, 88, (char *)"InvokeSSRes", 6, 1, 0, 0, 8, 56, 12, 0},
    {-1, 14, 268, (char *)"ForwardSsNotificationArg", 32, 6, 1, 0, 8, 57, 12, 0},
    {-1, 14, 88, (char *)"RegisterPasswordArg", 4, 1, 0, 0, 8, 63, 12, 0},
    {5, 322, 18, (char *)"RegisterPasswordRes", 1, 0, 2, 0, 16408, 0, 24, 0},
    {-1, 14, 324, (char *)"GetPasswordArg", 4, 1, 0, 0, 8, 64, 12, 0},
    {5, 322, 18, (char *)"GetPasswordRes", 1, 0, 2, 0, 16408, 0, 24, 0},
    {-1, 14, 328, (char *)"ProcessUnstructuredSsDataArg", 201, 1, 0, 0, 8, 65, 12, 0},
    {-1, 14, 328, (char *)"ProcessUnstructuredSsDataRes", 201, 1, 0, 0, 8, 65, 12, 0},
    {-1, 14, 332, (char *)"SendInfoForIncomingCallArg", 50, 7, 1, 0, 8, 66, 12, 0},
    {-1, 14, 392, (char *)"SendInfoForOutgoingCallArg", 22, 3, 1, 0, 8, 73, 12, 0},
    {-1, 14, 406, (char *)"SendRoutingInformationArg", 232, 4, 1, 0, 8, 76, 12, 0},
    {-1, 14, 428, (char *)"SendRoutingInformationRes", 30, 2, 0, 0, 8, 80, 12, 0},
    {-1, 14, 438, (char *)"ProvideRoamingNumberArg", 472, 7, 1, 0, 8, 82, 12, 0},
    {-1, 14, 88, (char *)"ProvideRoamingNumberRes", 12, 1, 0, 0, 8, 89, 12, 0},
    {-1, 14, 496, (char *)"CompleteCallArg", 532, 6, 1, 0, 8, 90, 12, 0},
    {-1, 14, 540, (char *)"ConnectToFollowingAddressArg", 32, 2, 1, 0, 8, 96, 12, 0},
    {-1, 14, 162, (char *)"PageArg", 26, 3, 1, 0, 8, 98, 12, 0},
    {-1, 14, 548, (char *)"SearchForMobileSubscriberArg", 20, 2, 0, 0, 8, 101, 12, 0},
    {-1, 14, 88, (char *)"SearchForMobileSubscriberRes", 8, 1, 0, 0, 8, 103, 12, 0},
    {-1, 14, 558, (char *)"PerformHandoverArg", 52, 6, 1, 0, 8, 104, 12, 0},
    {-1, 14, 584, (char *)"PerformHandoverRes", 220, 2, 0, 0, 8, 110, 12, 0},
    {-1, 14, 592, (char *)"PerformSubsequentHandoverArg", 38, 4, 1, 0, 8, 112, 12, 0},
    {-1, 14, 186, (char *)"PerformSubsequentHandoverRes", 208, 1, 0, 0, 8, 116, 12, 0},
    {-1, 14, 186, (char *)"ProcessAccessSignallingArg", 208, 1, 0, 0, 8, 117, 12, 0},
    {-1, 14, 186, (char *)"ForwardAccessSignallingArg", 208, 1, 0, 0, 8, 117, 12, 0},
    {-1, 14, 88, (char *)"SendHandoverReportArg", 12, 1, 0, 0, 8, 118, 12, 0},
    {-1, 14, 608, (char *)"RegisterChargingInformationArg", 612, 16, 1, 0, 8, 119, 12, 0},
    {-1, 14, 728, (char *)"ResetArg", 524, 3, 1, 0, 8, 135, 12, 0},
    {-1, 14, 740, (char *)"ActivateTraceModeArg", 40, 4, 1, 0, 8, 138, 12, 0},
    {-1, 14, 16, (char *)"DeactivateTraceModeArg", 16, 2, 1, 0, 8, 142, 12, 0},
    {-1, 14, 758, (char *)"TraceSubscriberActivityArg", 46, 5, 1, 0, 8, 144, 12, 0},
    {-1, 14, 782, (char *)"NoteInternalHandoverArg", 228, 3, 1, 0, 8, 149, 12, 0},
    {-1, 14, 88, (char *)"CheckIMEArg", 10, 1, 0, 0, 8, 152, 12, 0},
    {-1, 14, 324, (char *)"CheckIMEIRes", 4, 1, 0, 0, 8, 153, 12, 0},
    {-1, 14, 796, (char *)"AuthenticateArg", 22, 2, 0, 0, 8, 154, 12, 0},
    {-1, 14, 88, (char *)"AuthenticateRes", 6, 1, 0, 0, 8, 156, 12, 0},
    {-1, 14, 88, (char *)"ProvideIMSIRes", 10, 1, 0, 0, 8, 23, 12, 0},
    {-1, 14, 804, (char *)"SetCipheringModeArg", 20, 2, 1, 0, 8, 157, 12, 0},
    {-1, 14, 812, (char *)"SendRoutingInfoForSMArg", 48, 5, 1, 0, 8, 159, 12, 0},
    {-1, 14, 88, (char *)"ForwardNewTMSIArg", 6, 1, 0, 0, 8, 164, 12, 0},
    {-1, 14, 834, (char *)"SendRoutingInfoForSMRes", 38, 3, 1, 0, 8, 165, 12, 0},
    {-1, 14, 848, (char *)"ForwardShortMessageArg", 250, 3, 0, 0, 8, 168, 12, 0},
    {-1, 14, 796, (char *)"SetMessageWaitingDataArg", 34, 2, 0, 0, 8, 171, 12, 0},
    {8, 75, 0, (char *)"NoteMSPresentArg", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 14, 796, (char *)"AlertServiceCentreArg", 34, 2, 0, 0, 8, 171, 12, 0},
    {-1, 14, 868, (char *)"ProcessAccessRequestArg", 24, 4, 0, 0, 8, 173, 12, 0},
    {-1, 14, 796, (char *)"ProcessAccessRequestRes", 24, 2, 1, 0, 8, 177, 12, 0},
    {-1, 14, 796, (char *)"BeginSubscriberActivityArg", 22, 2, 0, 0, 8, 179, 12, 0},
    {-1, 2, 886, (char *)"UnknownSubscriber", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"UnknownBaseStation", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"UnknownMSC", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"UnknownLocArea", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"UnidentifiedSubscriber", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"UnallocatedRoamingNumber", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"UnknownEquipment", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"RoamingNotAllowed", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"IllegalMS", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"BearerServiceNotProvisioned", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"TeleserviceNotProvisioned", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"InsufficientBearerCapabilities", 16, 2, 2, 8, 8, 181, 13, 0},
    {1, 891, 0, (char *)"CallBarred-PARAMETER", 4, 0, 4, 0, 24, 1, 58, 0},
    {-1, 2, 886, (char *)"CallBarred", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"ForwardingViolation", 16, 2, 2, 8, 8, 181, 13, 0},
    {1, 891, 0, (char *)"CUG-Reject-PARAMETER", 4, 0, 4, 0, 24, 5, 58, 0},
    {-1, 2, 886, (char *)"CUG-Reject", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"IllegalSS-Operation", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"SS-ErrorStatus", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"SS-NotAvailable", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"SS-SubscriptionViolation", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 14, 893, (char *)"SS-Incompatibility-PARAMETER", 16, 3, 1, 0, 8, 183, 12, 0},
    {-1, 2, 886, (char *)"SS-Incompatibility", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"FacilityNotSupported", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"InvalidTargetBaseStation", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"NoRadioResourceAvailable", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"NoHandoverNumberAvailable", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"SubsequentHandoverFailure", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 915, 0, (char *)"AbsentSubscriber-PARAMETER", 1, 0, 0, 0, 8, 0, 8, 0},
    {-1, 2, 886, (char *)"AbsentSubscriber", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"BusySubscriber", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"NoSubscriberReply", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"RadioCongestion", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"ImpossibleCallCompletion", 16, 2, 2, 8, 8, 181, 13, 0},
    {6, 891, 0, (char *)"SM-DeliveryFailure-PARAMETER", 4, 0, 4, 0, 24, 9, 58, 0},
    {-1, 2, 886, (char *)"SM-DeliveryFailure", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"MessageWaitingListFull", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"SystemFailure", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"DataMissing", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"UnexpectedDataValue", 16, 2, 2, 8, 8, 181, 13, 0},
    {2, 891, 0, (char *)"PasswordRegistrationFailure-PARAMETER", 4, 0, 4, 0, 24, 18, 58, 0},
    {-1, 2, 886, (char *)"PasswordRegistrationFailure", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"NegativePasswordCheck", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"NoRoamingNumberAvailable", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"TracingBufferFull", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"UpdateLocationArea", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"UpdateLocation", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"CancelLocation", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"DetachIMSI", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"AttachIMSI", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"DeregisterMobileSubscriber", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"InsertSubscriberData", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"DeleteSubscriberData", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"SendParameters", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"RegisterSS", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"EraseSS", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"ActivateSS", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"DeactivateSS", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"InterrogateSS", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"InvokeSS", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"ForwardSsNotification", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"RegisterPassword", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"GetPassword", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"ProcessUnstructuredSsData", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"SendInfoForIncomingCall", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"SendInfoForOutgoingCall", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"SendRoutingInformation", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"ProvideRoamingNumber", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"CompleteCall", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"ConnectToFollowingAddress", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"ProcessCallWaiting", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"Page", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"SearchForMobileSubscriber", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"PerformHandover", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"SendEndSignal", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"PerformSubsequentHandover", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"AllocateHandoverNumber", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"SendHandoverReport", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"ProcessAccessSignalling", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"ForwardAccessSignalling", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"RegisterChargingInformation", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"Reset", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"ForwardCheckSsIndication", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"ActivateTraceMode", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"DeactivateTraceMode", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"TraceSubscriberActivity", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"NoteInternalHandover", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"CheckIMEI", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"Authenticate", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"ProvideIMSI", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"ForwardNewTMSI", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"SetCipheringMode", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"SendRoutingInfoForSM", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"ForwardShortMessage", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"SetMessageWaitingData", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"NoteMSPresent", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"AlertServiceCentre", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"ProcessAccessRequest", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 886, (char *)"BeginSubscriberActivity", 16, 2, 2, 8, 8, 181, 13, 0},
    {-1, 2, 0, (char *)"_Any", 16, 0, 8, 8, 40, 0, 10, 0},
    {-1, 0, 0, (char *)"_ObjectID", 8, 8, 2, 8, 40, 0, 27, 0},
    {-1, 917, 0, NULL, 4, 0, 4, 0, 8, 0, 0, 0},
    {0, 919, 7, NULL, 1, 0, 8, 0, 9, 0, 24, 0},
    {-1, 921, 0, NULL, 32, 0, 0, 0, 8, 0, 51, 0},
    {-1, 923, 0, (char *)"External_octet_aligned", 16, 0, 4, 8, 40, 0, 20, 0},
    {-1, 925, 0, (char *)"External_arbitrary", 16, 0, 4, 8, 40, 0, 3, 0},
    {-1, 2, 927, (char *)"_choice1", 40, 3, 2, 8, 40, 186, 13, 0},
    {-1, 934, 936, (char *)"_External", 72, 4, 1, 0, 40, 189, 12, 0},
    {-1, 980, 936, (char *)"DialoguePortion", 72, 4, 1, 0, 8, 189, 12, 0},
    {-1, 14, 983, (char *)"Unidirectional", 88, 2, 1, 0, 8, 193, 12, 0},
    {4, 993, 0, (char *)"OrigTransactionID", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 14, 995, (char *)"Begin", 88, 3, 1, 0, 8, 195, 12, 0},
    {4, 1009, 0, (char *)"DestTransactionID", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 14, 1011, (char *)"End", 88, 3, 1, 0, 8, 198, 12, 0},
    {-1, 14, 1025, (char *)"Continue", 96, 4, 1, 0, 8, 201, 12, 0},
    {-1, 1043, 0, (char *)"P-AbortCause", 4, 0, 4, 0, 8, 23, 0, 0},
    {-1, 2, 1045, (char *)"_choice2", 80, 2, 2, 8, 40, 205, 13, 0},
    {-1, 14, 1050, (char *)"Abort", 88, 2, 1, 0, 8, 207, 12, 0},
    {-1, 1060, 983, (char *)"Unidirectional", 88, 2, 1, 0, 8, 193, 12, 0},
    {-1, 1062, 995, (char *)"Begin", 88, 3, 1, 0, 8, 195, 12, 0},
    {-1, 1064, 1011, (char *)"End", 88, 3, 1, 0, 8, 198, 12, 0},
    {-1, 1066, 1025, (char *)"Continue", 96, 4, 1, 0, 8, 201, 12, 0},
    {-1, 1068, 1050, (char *)"Abort", 88, 2, 1, 0, 8, 207, 12, 0},
    {-1, 917, 0, (char *)"InvokeIdType", 2, 0, 2, 0, 8, 0, 0, 0},
    {-1, 921, 0, (char *)"InvokeIdType", 2, 0, 2, 0, 8, 0, 0, 0},
    {-1, 917, 0, NULL, 4, 0, 4, 0, 8, 0, 0, 0},
    {-1, 2, 886, (char *)"_choice3", 16, 2, 2, 8, 40, 181, 13, 0},
    {-1, 2, 0, (char *)"_Any", 16, 0, 8, 8, 40, 0, 10, 0},
    {-1, 14, 1070, (char *)"Invoke", 40, 4, 1, 0, 8, 209, 12, 0},
    {-1, 14, 1090, (char *)"_seq1", 32, 2, 0, 0, 40, 213, 12, 0},
    {-1, 14, 1098, (char *)"ReturnResult", 40, 2, 1, 0, 8, 215, 12, 0},
    {-1, 2, 0, (char *)"_Any", 16, 0, 8, 8, 40, 0, 10, 0},
    {-1, 14, 1106, (char *)"ReturnError", 40, 3, 1, 0, 8, 217, 12, 0},
    {-1, 917, 0, (char *)"GeneralProblem", 4, 0, 4, 0, 8, 30, 0, 0},
    {-1, 917, 0, (char *)"InvokeProblem", 4, 0, 4, 0, 8, 35, 0, 0},
    {-1, 917, 0, (char *)"ReturnResultProblem", 4, 0, 4, 0, 8, 45, 0, 0},
    {-1, 917, 0, (char *)"ReturnErrorProblem", 4, 0, 4, 0, 8, 50, 0, 0},
    {-1, 1118, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2, 1120, (char *)"_choice4", 4, 2, 2, 2, 40, 220, 13, 0},
    {-1, 921, 0, (char *)"GeneralProblem", 4, 0, 4, 0, 8, 30, 0, 0},
    {-1, 923, 0, (char *)"InvokeProblem", 4, 0, 4, 0, 8, 35, 0, 0},
    {-1, 925, 0, (char *)"ReturnResultProblem", 4, 0, 4, 0, 8, 45, 0, 0},
    {-1, 1125, 0, (char *)"ReturnErrorProblem", 4, 0, 4, 0, 8, 50, 0, 0},
    {-1, 2, 1127, (char *)"_choice5", 8, 4, 2, 4, 40, 222, 13, 0},
    {-1, 14, 1136, (char *)"Reject", 12, 2, 0, 0, 8, 226, 12, 0},
    {-1, 923, 1070, (char *)"Invoke", 40, 4, 1, 0, 8, 209, 12, 0},
    {-1, 925, 1098, (char *)"ReturnResult", 40, 2, 1, 0, 8, 215, 12, 0},
    {-1, 1125, 1106, (char *)"ReturnError", 40, 3, 1, 0, 8, 217, 12, 0},
    {-1, 1152, 1136, (char *)"Reject", 12, 2, 0, 0, 8, 226, 12, 0},
    {-1, 1154, 1098, (char *)"ReturnResult", 40, 2, 1, 0, 8, 215, 12, 0},
    {-1, 2, 1156, (char *)"Component", 48, 5, 2, 8, 8, 228, 13, 0},
    {-1, 1167, 0, (char *)"ComponentPortion", 8, 48, 4, 8, 8, 224, 18, 0},
    {-1, 2, 0, NULL, 2, 0, 0, 0, 8, 0, 50, 0},
    {-1, 917, 0, NULL, 8, 0, 8, 0, 8, 0, 0, 0},
    {-1, 2, 0, (char *)"EXTENSION", 24, 3, 1, 0, 8, 233, 49, 0},
    {-1, 0, 0, (char *)"_ObjectID", 8, 8, 2, 8, 40, 0, 27, 0},
    {-1, 2, 0, NULL, 32, 0, 0, 0, 8, 0, 51, 0},
    {-1, 14, 1169, (char *)"PrivateExtension", 48, 2, 1, 0, 264, 236, 12, 0},
    {10, 14, 0, (char *)"PrivateExtensionList", 2, 48, 2, 8, 24, 231, 17, 0},
    {-1, 14, 0, (char *)"PCS-Extensions", 1, 0, 0, 0, 12, 238, 12, 0},
    {10, 921, 0, (char *)"PrivateExtensionList", 2, 48, 2, 8, 24, 231, 17, 0},
    {-1, 923, 0, (char *)"PCS-Extensions", 1, 0, 0, 0, 12, 238, 12, 0},
    {20, 75, 0, (char *)"AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 75, 0, (char *)"IsdnAddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 891, 0, (char *)"ProtocolId", 4, 0, 4, 0, 24, 57, 58, 0},
    {200, 75, 0, (char *)"SignalInfo", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 14, 804, (char *)"ExternalSignalInfo", 208, 2, 0, 0, 8, 238, 12, 0},
    {8, 75, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 75, 0, (char *)"TMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {8, 921, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 923, 0, (char *)"TMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2, 1175, (char *)"SubscriberId", 12, 2, 2, 2, 8, 240, 13, 0},
    {8, 75, 0, (char *)"IMEI", 2, 0, 2, 2, 24, 0, 21, 0},
    {5, 75, 0, (char *)"LocAreaId", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 921, 0, (char *)"IsdnAddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 923, 0, (char *)"IsdnAddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2, 1175, (char *)"LocationInfo", 14, 2, 2, 2, 8, 242, 13, 0},
    {8, 75, 0, (char *)"HlrId", 2, 0, 2, 2, 24, 0, 21, 0},
    {50, 14, 0, (char *)"HlrList", 2, 10, 2, 2, 24, 251, 17, 0},
    {4, 75, 0, (char *)"LMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {7, 75, 0, (char *)"GlobalCellId", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 75, 0, (char *)"Category", 2, 0, 2, 2, 24, 0, 21, 0},
    {2, 891, 0, (char *)"EquipStatus", 4, 0, 4, 0, 24, 63, 58, 0},
    {1, 75, 0, (char *)"BearerServiceCode", 2, 0, 2, 2, 24, 0, 21, 0},
    {50, 14, 0, (char *)"BearerServiceList", 2, 4, 2, 2, 24, 257, 17, 0},
    {1, 75, 0, (char *)"TeleserviceCode", 2, 0, 2, 2, 24, 0, 21, 0},
    {20, 14, 0, (char *)"TeleserviceList", 2, 4, 2, 2, 24, 259, 17, 0},
    {1, 925, 0, (char *)"BearerServiceCode", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 1125, 0, (char *)"TeleserviceCode", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2, 1180, (char *)"BasicServiceCode", 6, 2, 2, 2, 8, 244, 13, 0},
    {70, 14, 0, (char *)"BasicServiceList", 2, 6, 2, 2, 24, 263, 17, 0},
    {1, 891, 0, (char *)"SubscriberStatus", 4, 0, 4, 0, 24, 68, 58, 0},
    {1, 75, 0, (char *)"SS-Code", 2, 0, 2, 2, 24, 0, 21, 0},
    {30, 14, 0, (char *)"SS-CodeList", 2, 4, 2, 2, 24, 266, 17, 0},
    {1, 75, 0, (char *)"SS-Status", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 75, 0, (char *)"ForwardingOptions", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 917, 0, (char *)"NoReplyConditionTime", 2, 0, 2, 0, 8, 0, 55, 0},
    {1, 1152, 0, (char *)"SS-Status", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 1185, 0, (char *)"IsdnAddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 1187, 0, (char *)"ForwardingOptions", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 1154, 0, (char *)"NoReplyConditionTime", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 14, 1189, (char *)"ForwardingFeature", 30, 5, 1, 0, 8, 246, 12, 0},
    {13, 14, 0, (char *)"ForwardingFeatureList", 2, 30, 2, 2, 24, 275, 17, 0},
    {-1, 14, 1219, (char *)"ForwardingInfo", 398, 2, 1, 0, 8, 251, 12, 0},
    {1, 1152, 0, (char *)"SS-Status", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 14, 1229, (char *)"CallBarringFeature", 12, 2, 1, 0, 8, 253, 12, 0},
    {13, 14, 0, (char *)"CallBarringFeatureList", 2, 12, 2, 2, 24, 279, 17, 0},
    {-1, 14, 584, (char *)"CallBarringInfo", 162, 2, 0, 0, 8, 255, 12, 0},
    {-1, 917, 0, (char *)"CUG-Index", 2, 0, 2, 0, 8, 0, 55, 0},
    {4, 75, 0, (char *)"CUG-Interlock", 2, 0, 2, 2, 24, 0, 21, 0},
    {2, 891, 0, (char *)"IntraCUG-Options", 4, 0, 4, 0, 24, 72, 58, 0},
    {13, 14, 0, (char *)"BasicServiceGroupList", 2, 6, 2, 2, 24, 263, 17, 0},
    {-1, 14, 1241, (char *)"CUG-Subscription", 96, 4, 1, 0, 12, 257, 12, 0},
    {10, 14, 0, (char *)"CUG-SubscriptionList", 2, 96, 2, 4, 24, 286, 17, 0},
    {1, 75, 0, (char *)"InterCUG-Restrictions", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 14, 1257, (char *)"CUG-Feature", 14, 3, 1, 0, 12, 261, 12, 0},
    {13, 14, 0, (char *)"CUG-FeatureList", 2, 14, 2, 2, 24, 289, 17, 0},
    {-1, 14, 1277, (char *)"CUG-Info", 1152, 2, 1, 0, 12, 264, 12, 0},
    {1, 1152, 0, (char *)"SS-Status", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 14, 1285, (char *)"SS-Data", 10, 2, 1, 0, 8, 266, 12, 0},
    {-1, 921, 1219, (char *)"ForwardingInfo", 398, 2, 1, 0, 8, 251, 12, 0},
    {-1, 923, 584, (char *)"CallBarringInfo", 162, 2, 0, 0, 8, 255, 12, 0},
    {-1, 925, 1277, (char *)"CUG-Info", 1152, 2, 1, 0, 12, 264, 12, 0},
    {-1, 1125, 1285, (char *)"SS-Data", 10, 2, 1, 0, 8, 266, 12, 0},
    {-1, 2, 1127, (char *)"SS-Information", 1156, 4, 2, 4, 8, 268, 13, 0},
    {30, 14, 0, (char *)"SS-InfoList", 2, 1156, 2, 4, 24, 298, 17, 0},
    {30, 14, 0, (char *)"SS-DataList", 2, 10, 2, 2, 24, 293, 17, 0},
    {5, 891, 0, (char *)"SS-Request", 4, 0, 4, 0, 24, 77, 58, 0},
    {1, 75, 0, (char *)"UserToUserServiceIndicator", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 917, 0, (char *)"MaximumConfereesNumber", 2, 0, 2, 0, 8, 0, 55, 0},
    {1, 891, 0, (char *)"HuntGroupAccessSelectionOrder", 4, 0, 4, 0, 24, 85, 58, 0},
    {-1, 1185, 0, NULL, 1, 0, 0, 0, 8, 0, 8, 0},
    {-1, 1187, 0, NULL, 1, 0, 0, 0, 8, 0, 8, 0},
    {1, 1154, 0, (char *)"UserToUserServiceIndicator", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 1293, 0, (char *)"MaximumConfereesNumber", 2, 0, 2, 0, 8, 0, 55, 0},
    {1, 1295, 0, (char *)"HuntGroupAccessSelectionOrder", 4, 0, 4, 0, 24, 85, 58, 0},
    {-1, 917, 0, (char *)"NumberOfConferees", 2, 0, 2, 0, 8, 0, 55, 0},
    {9, 1185, 0, (char *)"IsdnAddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 1187, 0, (char *)"ForwardingOptions", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 14, 1297, (char *)"ForwardingData", 18, 2, 1, 0, 8, 272, 12, 0},
    {9, 923, 0, (char *)"IsdnAddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 925, 0, (char *)"Category", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 1125, 0, (char *)"SubscriberStatus", 4, 0, 4, 0, 24, 68, 58, 0},
    {50, 1152, 0, (char *)"BearerServiceList", 2, 4, 2, 2, 24, 257, 17, 0},
    {20, 1187, 0, (char *)"TeleserviceList", 2, 4, 2, 2, 24, 259, 17, 0},
    {30, 1154, 0, (char *)"SS-InfoList", 2, 1156, 2, 4, 24, 298, 17, 0},
    {-1, 14, 1305, (char *)"SubscriberData", 34992, 6, 1, 0, 8, 274, 12, 0},
    {1, 75, 0, (char *)"SS-Notification", 2, 0, 2, 2, 24, 0, 21, 0},
    {5, 322, 18, (char *)"Password", 1, 0, 2, 0, 16408, 0, 24, 0},
    {4, 891, 0, (char *)"GuidanceInfo", 4, 0, 4, 0, 24, 89, 58, 0},
    {201, 1359, 22, (char *)"SS-UserData", 1, 0, 2, 0, 24, 0, 24, 0},
    {3, 75, 0, (char *)"CallReference", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 891, 0, (char *)"CallType", 4, 0, 4, 0, 24, 96, 58, 0},
    {-1, 917, 0, (char *)"Charge", 4, 0, 4, 0, 8, 0, 55, 0},
    {1, 923, 0, (char *)"SS-Code", 2, 0, 2, 2, 24, 0, 21, 0},
    {5, 925, 0, (char *)"SS-Request", 4, 0, 4, 0, 24, 77, 58, 0},
    {-1, 1125, 0, (char *)"Charge", 4, 0, 4, 0, 8, 0, 55, 0},
    {-1, 14, 1361, (char *)"SS-ChargingData", 16, 3, 1, 0, 8, 280, 12, 0},
    {30, 14, 0, (char *)"SS-ChargingInfo", 2, 16, 2, 4, 24, 331, 17, 0},
    {-1, 917, 0, (char *)"CallDuration", 4, 0, 4, 0, 8, 0, 55, 0},
    {24, 75, 0, (char *)"CallDateTime", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 917, 0, (char *)"PacketDataVolume", 2, 0, 2, 0, 8, 0, 55, 0},
    {0, 891, 0, (char *)"ChargingUnit", 4, 0, 4, 0, 24, 103, 58, 0},
    {13, 891, 0, (char *)"CallStatus", 4, 0, 4, 0, 24, 106, 58, 0},
    {-1, 917, 0, (char *)"NumberOfForwarding", 2, 0, 2, 0, 8, 0, 55, 0},
    {10, 75, 0, (char *)"ChannelType", 2, 0, 2, 2, 24, 0, 21, 0},
    {2, 75, 0, (char *)"ClassmarkInformation", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 75, 0, (char *)"HandoverPriority", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 891, 0, (char *)"HandoverType", 4, 0, 4, 0, 24, 121, 58, 0},
    {16, 75, 0, (char *)"Rand", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 75, 0, (char *)"Sres", 2, 0, 2, 2, 24, 0, 21, 0},
    {8, 75, 0, (char *)"Kc", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 14, 1373, (char *)"AuthenticationSet", 34, 3, 0, 0, 8, 283, 12, 0},
    {16, 75, 0, (char *)"Ki", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 75, 0, (char *)"CKSN", 2, 0, 2, 2, 24, 0, 21, 0},
    {2, 891, 0, (char *)"CipheringMode", 4, 0, 4, 0, 24, 125, 58, 0},
    {8, 921, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 923, 0, (char *)"LMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 1125, 0, (char *)"IsdnAddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {20, 1152, 0, (char *)"AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2, 1385, (char *)"SM-RP-DA", 24, 4, 2, 2, 8, 286, 13, 0},
    {9, 925, 0, (char *)"IsdnAddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {20, 1152, 0, (char *)"AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2, 1394, (char *)"SM-RP-OA", 24, 2, 2, 2, 8, 290, 13, 0},
    {200, 75, 0, (char *)"SM-RP-UI", 2, 0, 2, 2, 24, 0, 21, 0},
    {2, 75, 0, (char *)"TraceReference", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 917, 0, (char *)"TraceType", 2, 0, 2, 0, 8, 129, 55, 0},
    {7, 891, 0, (char *)"NetworkResource", 4, 0, 4, 0, 24, 135, 58, 0},
    {4, 891, 0, (char *)"RequestParameter", 4, 0, 4, 0, 24, 145, 58, 0},
    {2, 14, 0, (char *)"RequestParameters", 2, 4, 2, 4, 24, 362, 17, 0},
    {8, 921, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 923, 1373, (char *)"AuthenticationSet", 34, 3, 0, 0, 8, 283, 12, 0},
    {-1, 925, 1305, (char *)"SubscriberData", 34992, 6, 1, 0, 8, 274, 12, 0},
    {-1, 1125, 1277, (char *)"CUG-Info", 1152, 2, 1, 0, 12, 264, 12, 0},
    {16, 1152, 0, (char *)"Ki", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2, 1399, (char *)"SentParameter", 34996, 5, 2, 4, 8, 292, 13, 0},
    {6, 14, 0, (char *)"SentParameters", 2, 34996, 2, 4, 24, 369, 17, 0},
    {10, 891, 0, (char *)"CmServiceType", 4, 0, 4, 0, 24, 152, 58, 0},
    {1, 75, 0, (char *)"AccessConnectionStatus", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2, 1410, (char *)"_choice6", 10, 2, 2, 2, 40, 297, 13, 0},
    {4, 1415, 0, (char *)"LMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 14, 796, (char *)"IMSI-WithLMSI", 16, 2, 0, 0, 12, 299, 12, 0},
    {8, 921, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {8, 921, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {70, 923, 0, (char *)"BasicServiceList", 2, 6, 2, 2, 24, 263, 17, 0},
    {30, 925, 0, (char *)"SS-CodeList", 2, 4, 2, 2, 24, 266, 17, 0},
    {9, 1152, 0, (char *)"IsdnAddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 1185, 0, (char *)"NoReplyConditionTime", 2, 0, 2, 0, 8, 0, 55, 0},
    {1, 921, 0, (char *)"SS-Status", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 923, 0, (char *)"IsdnAddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {13, 925, 0, (char *)"BasicServiceGroupList", 2, 6, 2, 2, 24, 263, 17, 0},
    {13, 1125, 0, (char *)"ForwardingFeatureList", 2, 30, 2, 2, 24, 275, 17, 0},
    {-1, 2, 1127, (char *)"_choice7", 394, 4, 2, 2, 40, 301, 13, 0},
    {1, 1152, 0, (char *)"UserToUserServiceIndicator", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 1185, 0, (char *)"CUG-Index", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 1187, 0, (char *)"NumberOfConferees", 2, 0, 2, 0, 8, 0, 55, 0},
    {8, 921, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 923, 0, (char *)"SS-Code", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 925, 0, (char *)"TeleserviceCode", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 1125, 0, (char *)"BearerServiceCode", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 1152, 0, (char *)"SS-Status", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 1185, 0, (char *)"SS-Notification", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 921, 0, (char *)"IsdnAddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {8, 923, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2, 1175, (char *)"_choice8", 14, 2, 2, 2, 40, 305, 13, 0},
    {1, 925, 0, (char *)"BearerServiceCode", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 1125, 0, (char *)"TeleserviceCode", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 1152, 0, (char *)"LMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 1185, 0, (char *)"IsdnAddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 1187, 0, (char *)"CUG-Interlock", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 1154, 0, (char *)"NumberOfForwarding", 2, 0, 2, 0, 8, 0, 55, 0},
    {9, 921, 0, (char *)"IsdnAddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 925, 0, (char *)"BearerServiceCode", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 1125, 0, (char *)"TeleserviceCode", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 921, 0, (char *)"IsdnAddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 923, 0, (char *)"CUG-Interlock", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 925, 0, (char *)"NumberOfForwarding", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 1415, 804, (char *)"ExternalSignalInfo", 208, 2, 0, 0, 8, 238, 12, 0},
    {-1, 2, 77, (char *)"_choice9", 20, 2, 2, 2, 40, 307, 13, 0},
    {8, 921, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 923, 0, (char *)"IsdnAddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 925, 0, (char *)"IsdnAddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 1125, 0, (char *)"IsdnAddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 1152, 0, (char *)"LMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 1185, 804, (char *)"ExternalSignalInfo", 208, 2, 0, 0, 8, 238, 12, 0},
    {-1, 1187, 804, (char *)"ExternalSignalInfo", 208, 2, 0, 0, 8, 238, 12, 0},
    {9, 921, 0, (char *)"IsdnAddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 923, 0, (char *)"Category", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 925, 0, (char *)"CUG-Index", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 1125, 804, (char *)"ExternalSignalInfo", 208, 2, 0, 0, 8, 238, 12, 0},
    {-1, 1152, 0, (char *)"NoReplyConditionTime", 2, 0, 2, 0, 8, 0, 55, 0},
    {30, 1185, 0, (char *)"SS-DataList", 2, 10, 2, 2, 24, 293, 17, 0},
    {8, 921, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 923, 0, (char *)"TMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {5, 925, 0, (char *)"LocAreaId", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 1417, 0, (char *)"HandoverPriority", 2, 0, 2, 2, 24, 0, 21, 0},
    {8, 1419, 0, (char *)"Kc", 2, 0, 2, 2, 24, 0, 21, 0},
    {2, 1415, 0, (char *)"ClassmarkInformation", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 1415, 0, (char *)"BearerServiceCode", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 1417, 0, (char *)"TeleserviceCode", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 1419, 0, (char *)"IsdnAddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 1421, 0, (char *)"IsdnAddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 1423, 0, (char *)"PacketDataVolume", 2, 0, 2, 0, 8, 0, 55, 0},
    {0, 1425, 0, (char *)"ChargingUnit", 4, 0, 4, 0, 24, 103, 58, 0},
    {-1, 1427, 0, (char *)"Charge", 4, 0, 4, 0, 8, 0, 55, 0},
    {30, 1429, 0, (char *)"SS-ChargingInfo", 2, 16, 2, 4, 24, 331, 17, 0},
    {8, 921, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {2, 923, 0, (char *)"TraceReference", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 925, 0, (char *)"TraceType", 2, 0, 2, 0, 8, 129, 55, 0},
    {20, 1125, 0, (char *)"AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {8, 921, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {2, 923, 0, (char *)"TraceReference", 2, 0, 2, 2, 24, 0, 21, 0},
    {8, 921, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {2, 923, 0, (char *)"TraceReference", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 925, 0, (char *)"TraceType", 2, 0, 2, 0, 8, 129, 55, 0},
    {20, 1125, 0, (char *)"AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {3, 1152, 0, (char *)"CallReference", 2, 0, 2, 2, 24, 0, 21, 0},
    {7, 923, 0, (char *)"GlobalCellId", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 925, 804, (char *)"ExternalSignalInfo", 208, 2, 0, 0, 8, 238, 12, 0},
    {9, 921, 0, (char *)"IsdnAddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 923, 0, NULL, 1, 0, 0, 0, 8, 0, 8, 0},
    {20, 925, 0, (char *)"AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 1125, 0, (char *)"CUG-Interlock", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 1185, 0, (char *)"TeleserviceCode", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 921, 1431, (char *)"_seq2", 22, 2, 1, 0, 40, 309, 12, 0},
    {-1, 923, 1297, (char *)"ForwardingData", 18, 2, 1, 0, 8, 272, 12, 0},
    {-1, 2, 1175, (char *)"_choice10", 24, 2, 2, 2, 40, 311, 13, 0},
    {-1, 925, 0, NULL, 1, 0, 0, 0, 8, 0, 8, 0},
    {1, 923, 0, (char *)"SS-Code", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 1152, 0, (char *)"SS-Status", 2, 0, 2, 2, 24, 0, 21, 0}
};

static const struct efield _efieldarray[] = {
    {8, 192, -1, 160, 2},
    {8, 193, -1, 161, 2},
    {8, 194, -1, 162, 2},
    {8, 195, -1, 163, 2},
    {8, 196, -1, 164, 2},
    {8, 234, 0, 165, 3},
    {496, 235, 1, 166, 3},
    {4, 305, -1, 167, 2},
    {4, 306, -1, 168, 2},
    {4, 307, -1, 169, 2},
    {4, 308, -1, 170, 2},
    {4, 309, -1, 171, 2},
    {0, 245, -1, 172, 2},
    {12, 373, -1, 173, 2},
    {22, 247, -1, 174, 2},
    {30, 348, -1, 175, 2},
    {2, 241, -1, 176, 2},
    {12, 250, -1, 177, 2},
    {26, 237, -1, 178, 2},
    {38, 374, 0, 179, 3},
    {2, 241, -1, 176, 2},
    {2, 375, -1, 180, 2},
    {0, 245, -1, 172, 2},
    {0, 241, -1, 176, 2},
    {2, 376, 0, 176, 3},
    {12, 314, 1, 181, 3},
    {24, 315, 2, 182, 3},
    {28, 316, 3, 183, 3},
    {32, 317, 4, 184, 3},
    {234, 318, 5, 185, 3},
    {316, 319, 6, 186, 3},
    {2, 377, -1, 176, 2},
    {12, 378, 0, 187, 3},
    {434, 379, 1, 188, 3},
    {0, 245, -1, 172, 2},
    {12, 363, -1, 189, 2},
    {0, 370, -1, 190, 2},
    {2, 266, -1, 188, 2},
    {6, 263, 0, 187, 3},
    {12, 380, 1, 191, 3},
    {24, 381, 2, 192, 3},
    {0, 298, -1, 193, 2},
    {2, 266, -1, 188, 2},
    {6, 263, 0, 187, 3},
    {2, 266, -1, 188, 2},
    {6, 263, 0, 187, 3},
    {2, 266, -1, 188, 2},
    {6, 263, 0, 187, 3},
    {2, 266, -1, 188, 2},
    {6, 263, 0, 187, 3},
    {0, 386, -1, 194, 34},
    {2, 266, -1, 188, 2},
    {6, 263, 0, 187, 3},
    {12, 387, 1, 169, 3},
    {16, 388, 2, 195, 3},
    {18, 389, 3, 196, 3},
    {0, 283, -1, 197, 2},
    {2, 390, 0, 176, 3},
    {12, 391, 1, 188, 3},
    {16, 392, 2, 198, 3},
    {20, 393, 3, 199, 3},
    {24, 394, 4, 200, 3},
    {28, 395, 5, 201, 3},
    {0, 266, -1, 188, 2},
    {0, 323, -1, 202, 2},
    {0, 324, -1, 203, 2},
    {2, 398, -1, 204, 2},
    {16, 399, 0, 199, 3},
    {20, 400, 1, 198, 3},
    {24, 401, 2, 179, 3},
    {30, 402, 3, 205, 3},
    {42, 403, 4, 197, 3},
    {48, 404, 5, 206, 3},
    {2, 405, -1, 207, 2},
    {14, 406, 0, 199, 3},
    {18, 407, 1, 208, 3},
    {2, 408, -1, 181, 2},
    {14, 409, 0, 197, 3},
    {20, 410, 1, 206, 3},
    {24, 411, 2, 209, 3},
    {0, 241, -1, 176, 2},
    {10, 412, -1, 210, 2},
    {2, 413, -1, 176, 2},
    {12, 414, 0, 211, 3},
    {24, 415, 1, 181, 3},
    {36, 416, 2, 212, 3},
    {48, 417, 3, 179, 3},
    {56, 418, 4, 213, 3},
    {264, 419, 5, 209, 3},
    {0, 237, -1, 214, 2},
    {2, 420, -1, 181, 2},
    {14, 421, 0, 182, 3},
    {18, 422, 1, 195, 3},
    {20, 423, 2, 213, 3},
    {228, 424, 3, 192, 3},
    {230, 425, 4, 215, 3},
    {2, 313, -1, 216, 2},
    {20, 237, 0, 181, 3},
    {2, 426, -1, 176, 2},
    {12, 427, 0, 217, 3},
    {18, 428, -1, 218, 2},
    {0, 241, -1, 176, 2},
    {10, 373, -1, 219, 2},
    {0, 247, -1, 220, 2},
    {2, 254, -1, 221, 2},
    {12, 254, -1, 222, 2},
    {22, 339, -1, 223, 2},
    {34, 340, -1, 224, 2},
    {38, 429, 0, 225, 3},
    {42, 430, 1, 226, 3},
    {0, 237, -1, 227, 2},
    {12, 240, -1, 228, 2},
    {2, 254, -1, 221, 2},
    {12, 254, -1, 222, 2},
    {22, 237, -1, 229, 2},
    {34, 431, 0, 224, 3},
    {0, 240, -1, 228, 2},
    {0, 240, -1, 230, 2},
    {0, 237, -1, 227, 2},
    {2, 237, -1, 181, 2},
    {14, 237, -1, 211, 2},
    {26, 241, -1, 176, 2},
    {36, 325, -1, 231, 2},
    {44, 326, -1, 232, 2},
    {48, 337, -1, 233, 2},
    {52, 334, -1, 234, 2},
    {80, 333, -1, 235, 2},
    {84, 432, 0, 236, 3},
    {88, 433, 1, 237, 3},
    {92, 434, 2, 207, 3},
    {104, 435, 3, 238, 3},
    {116, 436, 4, 239, 3},
    {120, 437, 5, 240, 3},
    {124, 438, 6, 241, 3},
    {128, 439, 7, 242, 3},
    {4, 361, -1, 243, 2},
    {8, 237, -1, 244, 2},
    {20, 252, 0, 245, 3},
    {2, 440, 0, 176, 3},
    {12, 441, -1, 246, 2},
    {16, 442, -1, 247, 2},
    {18, 443, 1, 248, 3},
    {2, 444, 0, 176, 3},
    {12, 445, -1, 246, 2},
    {2, 446, 0, 176, 3},
    {12, 447, -1, 246, 2},
    {16, 448, -1, 247, 2},
    {18, 449, 1, 248, 3},
    {40, 450, 2, 231, 3},
    {4, 342, -1, 249, 2},
    {8, 451, 0, 221, 3},
    {20, 452, 1, 250, 3},
    {0, 246, -1, 251, 2},
    {0, 256, -1, 252, 2},
    {0, 343, -1, 253, 2},
    {18, 348, -1, 175, 2},
    {0, 344, -1, 254, 2},
    {4, 349, -1, 255, 2},
    {8, 345, 0, 226, 3},
    {2, 453, -1, 181, 2},
    {14, 454, -1, 256, 2},
    {16, 455, -1, 257, 2},
    {38, 456, 0, 197, 3},
    {44, 457, 1, 237, 3},
    {0, 242, -1, 217, 2},
    {2, 241, -1, 176, 2},
    {12, 460, -1, 194, 34},
    {36, 461, 0, 258, 3},
    {0, 354, -1, 259, 2},
    {24, 357, -1, 260, 2},
    {48, 358, -1, 261, 2},
    {0, 237, -1, 181, 2},
    {12, 236, -1, 257, 2},
    {0, 245, -1, 172, 2},
    {12, 371, -1, 262, 2},
    {16, 372, -1, 263, 2},
    {20, 348, -1, 175, 2},
    {2, 241, -1, 176, 2},
    {12, 237, 0, 181, 3},
    {0, 241, -1, 176, 2},
    {10, 237, -1, 244, 2},
    {8, 199, -1, 264, 2},
    {8, 0, -1, 265, 2},
    {2, 462, 0, 188, 3},
    {6, 263, 1, 187, 3},
    {12, 463, 2, 200, 3},
    {8, 177, -1, 266, 2},
    {8, 178, -1, 267, 2},
    {8, 179, -1, 268, 2},
    {8, 174, 0, 269, 3},
    {16, 175, 1, 270, 3},
    {24, 176, -1, 271, 3},
    {32, 180, -1, 272, 2},
    {8, 182, 0, 273, 3},
    {80, 225, -1, 274, 2},
    {2, 184, -1, 275, 2},
    {8, 182, 0, 273, 3},
    {80, 225, 1, 274, 3},
    {2, 186, -1, 276, 2},
    {8, 182, 0, 273, 3},
    {80, 225, 1, 274, 3},
    {2, 184, -1, 275, 2},
    {8, 186, -1, 276, 2},
    {16, 182, 0, 273, 3},
    {88, 225, 1, 274, 3},
    {8, 189, -1, 277, 2},
    {8, 182, -1, 278, 2},
    {2, 186, -1, 276, 2},
    {8, 190, 0, 279, 3},
    {2, 197, -1, 280, 2},
    {4, 198, 0, 281, 3},
    {8, 200, -1, 282, 2},
    {24, 201, 1, 283, 3},
    {0, 200, -1, 282, 2},
    {16, 201, -1, 283, 2},
    {2, 197, -1, 280, 2},
    {8, 203, 0, 284, 3},
    {2, 197, -1, 280, 2},
    {8, 200, -1, 285, 2},
    {24, 205, 0, 283, 3},
    {2, 197, -1, 286, 2},
    {2, 211, -1, 287, 2},
    {4, 213, -1, 288, 2},
    {4, 214, -1, 289, 2},
    {4, 215, -1, 290, 2},
    {4, 216, -1, 291, 2},
    {0, 212, -1, 280, 2},
    {4, 217, -1, 292, 2},
    {8, 219, -1, 293, 2},
    {8, 220, -1, 294, 2},
    {8, 221, -1, 295, 2},
    {8, 222, -1, 296, 2},
    {8, 223, -1, 297, 2},
    {2, 226, 0, 298, 3},
    {8, 0, -1, 299, 2},
    {16, 227, -1, 300, 66},
    {8, 229, -1, 301, 18},
    {16, 230, 0, 302, 3},
    {0, 238, -1, 303, 2},
    {4, 239, -1, 304, 2},
    {2, 243, -1, 176, 2},
    {2, 244, -1, 217, 2},
    {2, 248, -1, 214, 2},
    {2, 249, -1, 211, 2},
    {2, 261, -1, 199, 2},
    {2, 262, -1, 198, 2},
    {2, 263, 0, 187, 3},
    {8, 271, -1, 200, 2},
    {12, 272, 1, 191, 3},
    {24, 273, 2, 305, 3},
    {28, 274, 3, 192, 3},
    {2, 266, 0, 188, 3},
    {6, 276, -1, 306, 2},
    {2, 263, 0, 307, 3},
    {8, 278, -1, 200, 2},
    {0, 266, -1, 188, 2},
    {4, 280, -1, 308, 2},
    {2, 282, -1, 195, 2},
    {4, 283, -1, 197, 2},
    {12, 284, -1, 309, 2},
    {16, 285, 0, 310, 3},
    {2, 263, 0, 187, 3},
    {8, 282, 1, 311, 3},
    {10, 288, -1, 312, 2},
    {4, 287, -1, 313, 2},
    {968, 290, 0, 314, 3},
    {2, 266, -1, 188, 2},
    {6, 292, 0, 200, 3},
    {4, 294, -1, 315, 2},
    {4, 295, -1, 316, 2},
    {4, 296, -1, 317, 2},
    {4, 297, -1, 318, 2},
    {2, 311, -1, 191, 2},
    {14, 312, 0, 305, 3},
    {2, 314, 0, 181, 3},
    {14, 315, 1, 182, 3},
    {20, 316, 2, 183, 3},
    {24, 317, 3, 184, 3},
    {226, 318, 4, 185, 3},
    {308, 319, 5, 186, 3},
    {2, 328, -1, 188, 2},
    {8, 329, -1, 319, 2},
    {12, 330, 0, 241, 3},
    {0, 343, -1, 253, 2},
    {18, 344, -1, 254, 2},
    {24, 345, -1, 226, 2},
    {2, 350, -1, 176, 2},
    {2, 351, -1, 179, 2},
    {2, 352, -1, 214, 2},
    {2, 353, -1, 257, 2},
    {2, 355, -1, 181, 2},
    {2, 356, -1, 257, 2},
    {4, 364, -1, 176, 2},
    {4, 365, -1, 320, 2},
    {4, 366, -1, 321, 2},
    {4, 367, -1, 322, 2},
    {4, 368, -1, 323, 2},
    {2, 247, -1, 218, 34},
    {2, 211, -1, 324, 34},
    {0, 241, -1, 176, 2},
    {10, 253, -1, 179, 2},
    {2, 382, -1, 200, 2},
    {2, 383, -1, 191, 2},
    {2, 384, -1, 310, 2},
    {2, 385, -1, 306, 2},
    {2, 396, -1, 214, 2},
    {2, 397, -1, 176, 2},
    {2, 237, -1, 214, 2},
    {2, 313, -1, 216, 2},
    {2, 250, -1, 177, 2},
    {16, 253, 0, 179, 3},
    {2, 458, -1, 325, 34},
    {2, 459, -1, 216, 2}
};

#ifdef OSS_SPARTAN_AWARE
#if ((OSS_SPARTAN_AWARE + 0) > 12)
typedef struct ExtParms {
    int           versId;
    const void    *xparm[7];
} ExtParms;
static ExtParms const extParms = {
    25,
    {NULL, NULL, NULL, NULL, (void *)0, (void *)0, (void *)8}
};
#endif /* OSS_SPARTAN_AWARE  > 12 */
#endif /* OSS_SPARTAN_AWARE */

static void * const _enamearray[] = {
    (void *)0,
    (void *)0x2, (void *)_v18,
    (void *)"barringServiceActive", (void *)"operatorBarring",
    (void *)0x2, (void *)_v18,
    (void *)"incomingCallBarred", (void *)"nonCUGmember",
    (void *)0x7, (void *)_v22,
    (void *)"memoryCapacityExceeded", (void *)"msProtocolError", (void *)"msNotEquiped", (void *)"unknownServiceCentre", (void *)"scCongestion",
    (void *)"invalidSmeAddress", (void *)"msNotScSubscriber",
    (void *)0x3, (void *)_v18,
    (void *)"undetermined", (void *)"invalidFormat", (void *)"newPasswordsMismatch",
    (void *)0x5, (void *)_v22,
    (void *)"unrecognizedMessageType", (void *)"unrecognizedTransactionID", (void *)"badlyFormattedTransactionPortion", (void *)"incorrectTransactionPortion", (void *)"resourceLimitation",
    (void *)0x3, (void *)_v18,
    (void *)"unrecognizedComponent", (void *)"mistypedComponent", (void *)"badlyStructuredComponent",
    (void *)0x8, (void *)_v22,
    (void *)"duplicateInvokeID", (void *)"unrecognizedOperation", (void *)"mistypedParameter", (void *)"resourceLimitation", (void *)"initiatingRelease",
    (void *)"unrecognizedLinkedID", (void *)"linkedResponseUnexpected", (void *)"unexpectedLinkedOperation",
    (void *)0x3, (void *)_v18,
    (void *)"unrecognizedInvokeID", (void *)"returnResultUnexpected", (void *)"mistypedParameter",
    (void *)0x5, (void *)_v22,
    (void *)"unrecognizedInvokeID", (void *)"returnErrorUnexpected", (void *)"unrecognizedError", (void *)"unexpectedError", (void *)"mistypedParameter",
    (void *)0x4, (void *)_v9,
    (void *)"gsm-0408", (void *)"gsm-0806", (void *)"gsm-0808-bssmap", (void *)"ets300102-1",
    (void *)0x3, (void *)_v18,
    (void *)"white-listed", (void *)"black-listed", (void *)"grey-listed",
    (void *)0x2, (void *)_v18,
    (void *)"serviceGranted", (void *)"operatorOGCallBarring",
    (void *)0x3, (void *)_v18,
    (void *)"noCUG-Restrictions", (void *)"cugIC-CallBarred", (void *)"cugOG-CallBarred",
    (void *)0x6, (void *)_v22,
    (void *)"registration", (void *)"erasure", (void *)"activation", (void *)"deactivation", (void *)"interrogation",
    (void *)"invoke",
    (void *)0x2, (void *)_v18,
    (void *)"random", (void *)"sequential",
    (void *)0x5, (void *)_v22,
    (void *)"enterPW", (void *)"enterNewPW", (void *)"enterNewPW-Again", (void *)"badPW-TryAgain", (void *)"badPW-FormatTryAgain",
    (void *)0x5, (void *)_v22,
    (void *)"incomingCall", (void *)"forwardedCallPortion", (void *)"reroutedCallPortion", (void *)"outgoingCall", (void *)"ss-Request",
    (void *)0x1, (void *)_v18,
    (void *)"specialDrawingRights",
    (void *)0xd, (void *)_v18,
    (void *)"undetermined", (void *)"successfulNormalTermination", (void *)"successfulAbnormalTermination", (void *)"forwarded", (void *)"forwardedWithAbnormalTermination",
    (void *)"rerouted", (void *)"reroutedWithAbnormalTermination", (void *)"unsuccessfulNoRadioContact", (void *)"unsuccessfulNoResponse", (void *)"unsuccessfulBusySubscriber",
    (void *)"unsuccessfulSystemFailed", (void *)"unsuccessfulSusbcriptionViolation", (void *)"unsuccessfulUnsupportedFacility",
    (void *)0x2, (void *)_v18,
    (void *)"interBSS", (void *)"intraBSS",
    (void *)0x2, (void *)_v24,
    (void *)"noEncryption", (void *)"version1-GSM",
    (void *)0x4, (void *)_v21,
    (void *)"allEvents", (void *)"onlyCalls", (void *)"eventSet1", (void *)"eventSet254",
    (void *)0x8, (void *)_v22,
    (void *)"pLMN", (void *)"hLR", (void *)"vLR", (void *)"previous-VLR", (void *)"controlling-MSC",
    (void *)"vMSC", (void *)"eIR", (void *)"radioSubSystem",
    (void *)0x5, (void *)_v22,
    (void *)"request-IMSI", (void *)"request-AuthenticationSet", (void *)"request-SubscriberData", (void *)"request-CUG-Information", (void *)"request-Ki",
    (void *)0x6, (void *)_v24,
    (void *)"mobileOriginatingCall", (void *)"emergencyCallEstablishment", (void *)"shortMessageService", (void *)"ss-request", (void *)"mobileOriginatingCallRe-establishment",
    (void *)"mobileTerminatingCall",
    (void *)"unidirectional",
    (void *)"begin",
    (void *)"end",
    (void *)"continue",
    (void *)"abort",
    (void *)"privateExtensionList",
    (void *)"pcs-Extensions",
    (void *)"perCallBasis",
    (void *)"notificationToHeldRetrievedParty",
    (void *)"userToUserServiceIndicator",
    (void *)"maximumConfereesNumber",
    (void *)"huntGroupAccessSelectionOrder",
    (void *)"subscriberId",
    (void *)"previousLocAreaId",
    (void *)"targetLocAreaId",
    (void *)"cksn",
    (void *)"imsi",
    (void *)"locationInfo",
    (void *)"vlrNumber",
    (void *)"lmsi",
    (void *)"imsi-WithLMSI",
    (void *)"msIsdn",
    (void *)"category",
    (void *)"subscriberStatus",
    (void *)"bearerServiceList",
    (void *)"teleserviceList",
    (void *)"provisonedSS",
    (void *)"basicService",
    (void *)"ss-Code",
    (void *)"requestParameters",
    (void *)"sentParameters",
    (void *)"forwardedToNumber",
    (void *)"noReplyConditionTime",
    (void *)"ss-Information",
    (void *)"choice",
    (void *)"cug-Index",
    (void *)"numberOfConferees",
    (void *)"cug-Interlock",
    (void *)"teleservice",
    (void *)"bearerService",
    (void *)"ss-Status",
    (void *)"ss-Notification",
    (void *)"guidanceInfo",
    (void *)"ss-UserData",
    (void *)"incomingId",
    (void *)"dialledNumber",
    (void *)"numberOfForwarding",
    (void *)"calledNumber",
    (void *)"teleService",
    (void *)"networkSignalInfo",
    (void *)"routingInfo",
    (void *)"mscNumber",
    (void *)"previousRoamingNumber",
    (void *)"gSM-BearerCapability",
    (void *)"roamingNumber",
    (void *)"ss-DataList",
    (void *)"forwardingData",
    (void *)"tmsi",
    (void *)"locAreaId",
    (void *)"storedLocationArea",
    (void *)"currentLocAreaId",
    (void *)"targetCellId",
    (void *)"servingCellId",
    (void *)"channelType",
    (void *)"classmarkInformation",
    (void *)"handoverPriority",
    (void *)"kc",
    (void *)"handoverNumber",
    (void *)"accessSignalInfo",
    (void *)"targetMscNumber",
    (void *)"bss-APDU",
    (void *)"callReference",
    (void *)"callType",
    (void *)"callStatus",
    (void *)"callDateTime",
    (void *)"callDuration",
    (void *)"bearerServiceCode",
    (void *)"teleserviceCode",
    (void *)"callingNumber",
    (void *)"packetDataVolume",
    (void *)"chargingUnit",
    (void *)"charge",
    (void *)"ss-ChargingInfo",
    (void *)"networkResource",
    (void *)"originatingEntityNumber",
    (void *)"hlrId",
    (void *)"traceReference",
    (void *)"traceType",
    (void *)"omcId",
    (void *)"handoverType",
    (void *)"channelId",
    (void *)"imei",
    (void *)"equipStatus",
    (void *)"rand",
    (void *)"sres",
    (void *)"cipheringMode",
    (void *)"sm-RP-PRI",
    (void *)"serviceCentreAddress",
    (void *)"mwd-Set",
    (void *)"sm-RP-DA",
    (void *)"sm-RP-OA",
    (void *)"sm-RP-UI",
    (void *)"cmServiceType",
    (void *)"accessConnectionStatus",
    (void *)"localValue",
    (void *)"globalValue",
    (void *)"single-ASN1-type",
    (void *)"octet-aligned",
    (void *)"arbitrary",
    (void *)"direct-reference",
    (void *)"indirect-reference",
    (void *)"data-value-descriptor",
    (void *)"encoding",
    (void *)"dialoguePortion",
    (void *)"components",
    (void *)"otid",
    (void *)"dtid",
    (void *)"p-abortCause",
    (void *)"u-abortCause",
    (void *)"reason",
    (void *)"invokeID",
    (void *)"linkedID",
    (void *)"operationCode",
    (void *)"parameter",
    (void *)"result",
    (void *)"errorCode",
    (void *)"derivable",
    (void *)"not-derivable",
    (void *)"generalProblem",
    (void *)"invokeProblem",
    (void *)"returnResultProblem",
    (void *)"returnErrorProblem",
    (void *)"problem",
    (void *)"invoke",
    (void *)"returnResultLast",
    (void *)"returnError",
    (void *)"reject",
    (void *)"returnResultNotLast",
    (void *)"ExtensionType",
    (void *)"extensionId",
    (void *)"_oss_unique_index",
    (void *)"extId",
    (void *)"extType",
    (void *)"protocolId",
    (void *)"signalInfo",
    (void *)"forwardingOptions",
    (void *)"forwardingFeatureList",
    (void *)"basicServiceCode",
    (void *)"callBarringFeatureList",
    (void *)"intraCUG-Options",
    (void *)"basicServiceGroupList",
    (void *)"preferentialCUG-Indicator",
    (void *)"interCUG-Restrictions",
    (void *)"cug-SubscriptionList",
    (void *)"cug-FeatureList",
    (void *)"forwardingInfo",
    (void *)"callBarringInfo",
    (void *)"cug-Info",
    (void *)"ss-Data",
    (void *)"ss-Request",
    (void *)"authenticationSet",
    (void *)"susbcriberData",
    (void *)"cug-information",
    (void *)"ki",
    (void *)"null",
    (void *)"sequence"
};

static const Etag _tagarray[] = {
    1, 0x0006, 0, 5, 0x4001, 1, 0x4002, 2, 0x4004, 3,
    0x4005, 4, 0x4007, 5, 1, 0x0010, 18, 23, 2, 0x8000,
    1, 0x8001, 2, 1, 0x8001, 2, 5, 0x8005, 1, 0x8006,
    2, 0x8007, 3, 0x8008, 4, 0x8009, 5, 41, 46, 51,
    54, 2, 0x8000, 1, 0x8001, 1, 2, 0x0004, 2, 0x0005,
    2, 1, 0x0004, 3, 1, 0x0004, 4, 61, 64, 69,
    72, 1, 0x0004, 1, 2, 0x8000, 2, 0x8001, 2, 1,
    0x0004, 3, 1, 0x800a, 4, 1, 0x0004, 2, 0x0004, 1,
    0x0010, 2, 83, 2, 0x8000, 1, 0x8001, 1, 89, 1,
    0x0004, 1, 99, 114, 127, 138, 147, 154, 159, 7,
    0x8000, 1, 0x8001, 2, 0x8002, 3, 0x8003, 4, 0x8004, 5,
    0x8006, 6, 0x8007, 7, 6, 0x8001, 2, 0x8002, 3, 0x8003,
    4, 0x8004, 5, 0x8006, 6, 0x8007, 7, 5, 0x8002, 3,
    0x8003, 4, 0x8004, 5, 0x8006, 6, 0x8007, 7, 4, 0x8003,
    4, 0x8004, 5, 0x8006, 6, 0x8007, 7, 3, 0x8004, 5,
    0x8006, 6, 0x8007, 7, 2, 0x8006, 6, 0x8007, 7, 1,
    0x8007, 7, 165, 168, 173, 1, 0x8000, 1, 2, 0x8001,
    2, 0x8002, 3, 1, 0x8002, 3, 178, 183, 2, 0x8000,
    1, 0x8001, 1, 1, 0x0010, 2, 187, 1, 0x0010, 1,
    194, 197, 206, 211, 1, 0x0004, 1, 4, 0x8002, 2,
    0x8003, 2, 0x8004, 3, 0x8005, 4, 2, 0x8004, 3, 0x8005,
    4, 1, 0x8005, 4, 215, 4, 0x8000, 1, 0x8001, 1,
    0x8002, 1, 0x8003, 1, 226, 229, 1, 0x0004, 1, 2,
    0x8002, 2, 0x8003, 2, 239, 242, 253, 260, 265, 1,
    0x0004, 1, 5, 0x8002, 2, 0x8003, 2, 0x8004, 3, 0x8005,
    4, 0x8006, 5, 3, 0x8004, 3, 0x8005, 4, 0x8006, 5,
    2, 0x8005, 4, 0x8006, 5, 1, 0x8006, 5, 274, 287,
    298, 307, 314, 319, 6, 0x8000, 1, 0x8001, 2, 0x8002,
    3, 0x8003, 4, 0x8004, 5, 0x8005, 6, 5, 0x8001, 2,
    0x8002, 3, 0x8003, 4, 0x8004, 5, 0x8005, 6, 4, 0x8002,
    3, 0x8003, 4, 0x8004, 5, 0x8005, 6, 3, 0x8003, 4,
    0x8004, 5, 0x8005, 6, 2, 0x8004, 5, 0x8005, 6, 1,
    0x8005, 6, 1, 0x0012, 325, 1, 0x000a, 1, 329, 1,
    0x0016, 1, 339, 344, 357, 368, 377, 384, 389, 2,
    0x8000, 1, 0x8001, 1, 6, 0x8002, 2, 0x8003, 3, 0x8004,
    4, 0x8005, 5, 0x8006, 6, 0x8007, 7, 5, 0x8003, 3,
    0x8004, 4, 0x8005, 5, 0x8006, 6, 0x8007, 7, 4, 0x8004,
    4, 0x8005, 5, 0x8006, 6, 0x8007, 7, 3, 0x8005, 5,
    0x8006, 6, 0x8007, 7, 2, 0x8006, 6, 0x8007, 7, 1,
    0x8007, 7, 395, 398, 403, 1, 0x8000, 1, 2, 0x8002,
    2, 0x8003, 3, 1, 0x8003, 3, 410, 413, 420, 425,
    1, 0x8000, 1, 3, 0x8001, 2, 0x8002, 3, 0x800a, 4,
    2, 0x8002, 3, 0x800a, 4, 1, 0x800a, 4, 430, 433,
    1, 0x0004, 1, 2, 0x0004, 2, 0x0010, 2, 445, 448,
    461, 472, 481, 488, 493, 1, 0x8000, 1, 6, 0x8001,
    2, 0x8002, 3, 0x8003, 4, 0x8004, 5, 0x8005, 6, 0x8006,
    7, 5, 0x8002, 3, 0x8003, 4, 0x8004, 5, 0x8005, 6,
    0x8006, 7, 4, 0x8003, 4, 0x8004, 5, 0x8005, 6, 0x8006,
    7, 3, 0x8004, 5, 0x8005, 6, 0x8006, 7, 2, 0x8005,
    6, 0x8006, 7, 1, 0x8006, 7, 502, 505, 516, 525,
    532, 537, 1, 0x8000, 1, 5, 0x8001, 2, 0x8002, 3,
    0x8003, 4, 0x8004, 5, 0x8005, 6, 4, 0x8002, 3, 0x8003,
    4, 0x8004, 5, 0x8005, 6, 3, 0x8003, 4, 0x8004, 5,
    0x8005, 6, 2, 0x8004, 5, 0x8005, 6, 1, 0x8005, 6,
    542, 545, 1, 0x0010, 1, 1, 0x0004, 2, 550, 553,
    1, 0x0004, 1, 2, 0x0004, 2, 0x0005, 2, 564, 567,
    570, 573, 576, 581, 1, 0x0004, 1, 1, 0x0004, 2,
    1, 0x0004, 3, 1, 0x0004, 4, 2, 0x800b, 5, 0x800c,
    6, 1, 0x800c, 6, 586, 589, 1, 0x0004, 1, 1,
    0x0010, 2, 596, 599, 602, 605, 1, 0x0004, 1, 1,
    0x0004, 2, 1, 0x0004, 3, 1, 0x800a, 4, 624, 627,
    630, 633, 636, 639, 642, 645, 648, 665, 680, 693,
    704, 713, 720, 725, 1, 0x0004, 1, 1, 0x0004, 2,
    1, 0x0004, 3, 1, 0x0004, 4, 1, 0x000a, 5, 1,
    0x000a, 6, 1, 0x0004, 7, 1, 0x0002, 8, 8, 0x800a,
    9, 0x800b, 10, 0x800c, 11, 0x800d, 12, 0x800e, 13, 0x800f,
    14, 0x8010, 15, 0x8011, 16, 7, 0x800b, 10, 0x800c, 11,
    0x800d, 12, 0x800e, 13, 0x800f, 14, 0x8010, 15, 0x8011, 16,
    6, 0x800c, 11, 0x800d, 12, 0x800e, 13, 0x800f, 14, 0x8010,
    15, 0x8011, 16, 5, 0x800d, 12, 0x800e, 13, 0x800f, 14,
    0x8010, 15, 0x8011, 16, 4, 0x800e, 13, 0x800f, 14, 0x8010,
    15, 0x8011, 16, 3, 0x800f, 14, 0x8010, 15, 0x8011, 16,
    2, 0x8010, 15, 0x8011, 16, 1, 0x8011, 16, 731, 734,
    737, 1, 0x000a, 1, 1, 0x0004, 2, 1, 0x0010, 3,
    744, 749, 752, 755, 2, 0x8000, 1, 0x8001, 2, 1,
    0x8001, 2, 1, 0x8002, 3, 1, 0x8003, 4, 763, 768,
    771, 774, 779, 2, 0x8000, 1, 0x8001, 2, 1, 0x8001,
    2, 1, 0x8002, 3, 2, 0x8003, 4, 0x8004, 5, 1,
    0x8004, 5, 785, 788, 793, 1, 0x000a, 1, 2, 0x8001,
    2, 0x8002, 3, 1, 0x8002, 3, 798, 801, 1, 0x0004,
    1, 1, 0x0004, 2, 806, 809, 1, 0x000a, 1, 1,
    0x0004, 2, 817, 820, 823, 826, 831, 1, 0x8000, 1,
    1, 0x8001, 2, 1, 0x8002, 3, 2, 0x8003, 4, 0x8005,
    5, 1, 0x8005, 5, 837, 840, 845, 1, 0x0004, 1,
    2, 0x8000, 2, 0x8001, 2, 1, 0x8002, 3, 851, 860,
    865, 4, 0x8000, 1, 0x8001, 1, 0x8003, 1, 0x8004, 1,
    2, 0x8002, 2, 0x8004, 2, 1, 0x0004, 3, 872, 877,
    880, 883, 2, 0x8000, 1, 0x8001, 1, 1, 0x000a, 2,
    1, 0x0004, 3, 1, 0x0004, 4, 2, 0x0002, 1, 0x0006,
    2, 1, 0x000a, 896, 905, 912, 4, 0x8001, 1, 0x8002,
    2, 0x8003, 2, 0x8004, 3, 3, 0x8002, 2, 0x8003, 2,
    0x8004, 3, 1, 0x8004, 3, 1, 0x0001, 1, 0x0002, 1,
    0x0007, 1, 0x8000, 1, 0x8001, 1, 0x8002, 3, 0x8000, 1,
    0x8001, 2, 0x8002, 3, 1, 0x0008, 940, 953, 964, 973,
    6, 0x0002, 2, 0x0006, 1, 0x0007, 3, 0x8000, 4, 0x8001,
    4, 0x8002, 4, 5, 0x0002, 2, 0x0007, 3, 0x8000, 4,
    0x8001, 4, 0x8002, 4, 4, 0x0007, 3, 0x8000, 4, 0x8001,
    4, 0x8002, 4, 3, 0x8000, 4, 0x8001, 4, 0x8002, 4,
    2, 0x400b, 0x0008, 985, 990, 2, 0x400b, 1, 0x400c, 2,
    1, 0x400c, 2, 1, 0x4008, 998, 1001, 1006, 1, 0x4008,
    1, 2, 0x400b, 2, 0x400c, 3, 1, 0x400c, 3, 1,
    0x4009, 1014, 1017, 1022, 1, 0x4009, 1, 2, 0x400b, 2,
    0x400c, 3, 1, 0x400c, 3, 1029, 1032, 1035, 1040, 1,
    0x4008, 1, 1, 0x4009, 2, 2, 0x400b, 3, 0x400c, 4,
    1, 0x400c, 4, 1, 0x400a, 2, 0x400a, 1, 0x400b, 2,
    1052, 1055, 1, 0x4009, 1, 2, 0x400a, 2, 0x400b, 2,
    1, 0x4001, 1, 0x4002, 1, 0x4004, 1, 0x4005, 1, 0x4007,
    1074, 1077, 1084, 1089, 1, 0x0002, 1, 3, 0x0002, 3,
    0x0006, 3, 0x8000, 2, 2, 0x0002, 3, 0x0006, 3, 0,
    1092, 1097, 2, 0x0002, 1, 0x0006, 1, 0, 1100, 1103,
    1, 0x0002, 1, 1, 0x0010, 2, 1109, 1112, 1117, 1,
    0x0002, 1, 2, 0x0002, 2, 0x0006, 2, 0, 1, 0x0005,
    2, 0x0002, 1, 0x0005, 2, 1, 0x8003, 4, 0x8000, 1,
    0x8001, 2, 0x8002, 3, 0x8003, 4, 1138, 1143, 2, 0x0002,
    1, 0x0005, 1, 4, 0x8000, 2, 0x8001, 2, 0x8002, 2,
    0x8003, 2, 1, 0x8004, 1, 0x8007, 5, 0x8001, 1, 0x8002,
    2, 0x8003, 3, 0x8004, 4, 0x8007, 5, 1, 0x400c, 1171,
    1174, 1, 0x0006, 1, 0, 2, 0x8000, 1, 0x8001, 2,
    2, 0x8002, 1, 0x8003, 2, 1, 0x8005, 1, 0x8006, 1194,
    1201, 1204, 1211, 1216, 3, 0x8002, 1, 0x8003, 1, 0x8004,
    2, 1, 0x8004, 2, 3, 0x8005, 3, 0x8006, 4, 0x8007,
    5, 2, 0x8006, 4, 0x8007, 5, 1, 0x8007, 5, 1221,
    1226, 2, 0x0004, 1, 0x0010, 2, 1, 0x0010, 2, 1231,
    1238, 3, 0x8002, 1, 0x8003, 1, 0x8004, 2, 1, 0x8004,
    2, 1245, 1248, 1251, 1254, 1, 0x0002, 1, 1, 0x0004,
    2, 1, 0x000a, 3, 1, 0x0010, 4, 1260, 1269, 1274,
    4, 0x0002, 2, 0x0004, 3, 0x8002, 1, 0x8003, 1, 2,
    0x0002, 2, 0x0004, 3, 1, 0x0004, 3, 1279, 1282, 1,
    0x0010, 1, 1, 0x0010, 2, 1287, 1290, 1, 0x0004, 1,
    1, 0x8004, 2, 1, 0x8008, 1, 0x8009, 1299, 1302, 1,
    0x8005, 1, 1, 0x8006, 2, 1311, 1324, 1335, 1344, 1351,
    1356, 6, 0x8001, 1, 0x8002, 2, 0x8003, 3, 0x8004, 4,
    0x8006, 5, 0x8007, 6, 5, 0x8002, 2, 0x8003, 3, 0x8004,
    4, 0x8006, 5, 0x8007, 6, 4, 0x8003, 3, 0x8004, 4,
    0x8006, 5, 0x8007, 6, 3, 0x8004, 4, 0x8006, 5, 0x8007,
    6, 2, 0x8006, 5, 0x8007, 6, 1, 0x8007, 6, 1,
    0x0016, 1364, 1367, 1370, 1, 0x8001, 1, 1, 0x8002, 2,
    1, 0x8003, 3, 1376, 1379, 1382, 1, 0x0004, 1, 1,
    0x0004, 2, 1, 0x0004, 3, 4, 0x8000, 1, 0x8001, 2,
    0x8003, 3, 0x8004, 4, 2, 0x8002, 1, 0x8004, 2, 5,
    0x8000, 1, 0x8001, 2, 0x8002, 3, 0x8003, 4, 0x8004, 5,
    2, 0x0004, 1, 0x0005, 2, 1, 0x800a, 1, 0x800b, 1,
    0x800c, 1, 0x800d, 1, 0x800e, 1, 0x800f, 1, 0x8010, 1,
    0x8011, 1433, 1438, 2, 0x8000, 1, 0x8001, 1, 1, 0x0004,
    2
};

#if !defined(OSS_SPARTAN_AWARE) || ((OSS_SPARTAN_AWARE + 0) <= 5)
typedef struct OSetTableEntry {
    void *a;
    unsigned short b;
    void *c;
    unsigned short d;
} OSetTableEntry;
#endif /* OSS_SPARTAN_AWARE  <= 5 */

static struct OSetTableEntry const _objectsettable[] = {
#if defined(OSS_SPARTAN_AWARE) && ((OSS_SPARTAN_AWARE + 0) > 12)
    {(void *)OMAP1_ExtensionSet, 228, NULL, 0, NULL, -1, -1}
#else
    {(void *)OMAP1_ExtensionSet, 228, NULL, 0}
#endif /* OSS_SPARTAN_AWARE  > 12 */
};


#ifdef OSS_SPARTAN_AWARE
#if ((OSS_SPARTAN_AWARE + 0) >= 3)
static void _oss_post_init(struct ossGlobal *world) {
    static const unsigned char _oss_typeinfo[] = {
        0x00, 0x8f, 0x33, 0x21, 0xfc, 0x86, 0x96, 0x99, 0xb2, 0x87,
        0x4a, 0x81, 0xb2, 0xba, 0x4a, 0x97, 0x00, 0x6f, 0x95, 0x27,
        0x06, 0x73, 0x26, 0x40, 0xee, 0xa7, 0x50, 0x3e, 0xd9, 0x57,
        0xe6, 0x36, 0x08, 0x8f, 0x59, 0x8a, 0xd3, 0x51, 0xb2, 0xa8,
        0x3a, 0x49, 0xe3, 0x7f, 0x41, 0xff, 0x77, 0x93, 0x5e, 0xf5,
        0x95, 0x7d, 0x0d, 0x73, 0x1a, 0x5a, 0xb1, 0x76, 0x64, 0xeb,
        0x2e, 0xbd, 0x66, 0x17, 0x47, 0x5a, 0x69, 0xef, 0xa1, 0x16,
        0xac, 0xfb, 0xb7, 0xbf, 0xeb, 0xdf, 0x97, 0xcd, 0xc9, 0xc5,
        0xab, 0xc2, 0x9e, 0x3e, 0x37, 0xf4, 0xf6, 0xd7, 0xf8, 0x38,
        0xbe, 0xc4, 0x6b, 0x38, 0x46, 0xf4, 0x02, 0xde, 0x81, 0xbe,
        0x42, 0xaf, 0x08, 0xd6, 0xdc, 0x18, 0x4b, 0xdb, 0xd3, 0x5c,
        0xe2, 0xef, 0x3c, 0x4b, 0x37, 0xf3, 0xd8, 0xdd, 0x60, 0xb1,
        0xdd, 0xa3, 0x95, 0x45, 0xcb, 0xaf, 0xcb, 0x06, 0xc1, 0xa6,
        0xf1, 0xb8, 0x21, 0xf3, 0x26, 0xda, 0x6b, 0x26, 0x26, 0xd3,
        0xa7, 0xfd, 0xef, 0xf9, 0x5b
    };
    ossInitRootContext(world, (unsigned char *)_oss_typeinfo);
#ifdef OSS_SPARTAN_AWARE
#if ((OSS_SPARTAN_AWARE + 0) > 12)
    ossSetExtParms(world, (void *)&extParms);
#endif /* OSS_SPARTAN_AWARE  > 12 */
#endif /* OSS_SPARTAN_AWARE */
}
#endif /* OSS_SPARTAN_AWARE >= 3 */
#endif /* OSS_SPARTAN_AWARE */

static const struct eheader _head = {_ossinit_MAP1, -1, 15, 2853, 172, 464,
    (unsigned short *)_pduarray, (struct etype *)_etypearray,
    (struct efield *)_efieldarray, (void **)_enamearray, (Etag *)_tagarray,
    NULL, NULL, NULL, 0, (void *)_objectsettable, 1};

#ifdef _OSSGETHEADER
void *DLL_ENTRY_FDEF ossGetHeader()
{
    return (void *)&_head;
}
#endif /* _OSSGETHEADER */

void *MAP1 = (void *)&_head;
#ifdef __cplusplus
}	/* extern "C" */
#endif /* __cplusplus */
