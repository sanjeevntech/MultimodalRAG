#include "MAP1Code.h"
#include "MAP1.h"


OssGlobal gMAP1W, *gMAP1World = &gMAP1W;

//Vble to remember if the OSS was initialized previously.
int g_initialized = 0;

int MAP1_initialize() 
{
	int L_retCode ;
	//Initialise the OSS runtime environment
	L_retCode = ossinit(gMAP1World, MAP1);

	if(L_retCode) 
		return L_retCode;

	g_initialized = 1;
    	return 0;
}

void MAP1_close() 
{
	if(g_initialized)
		//Release the OSS runtime resources
		ossterm(gMAP1World);

	g_initialized = 0;
}


void MAP1_printPDU(int P_msgType,void *P_dataStruct) 
{
	if(!g_initialized)
		MAP1_initialize();

	//Call OSS API to print the PDU
	ossPrintPDU(gMAP1World,P_msgType,P_dataStruct);
}

void MAP1_freePDU(int P_msgType, void* P_data) 
{
	if(!g_initialized)
		MAP1_initialize();

	//Free the decoded PDU allocated from OSS memory pool.
	ossFreePDU(gMAP1World,P_msgType,P_data);
}

void MAP1_freeBuf(unsigned char *P_buff)
{
	if(!g_initialized)
		MAP1_initialize();

	//Free the encoded buffer once you are done with the useage
	//from the OSS memory pool
	ossFreeBuf(gMAP1World,P_buff);
}

int MAP1_encode(void *P_dataStruct,int P_msgType, 
	unsigned char **P_encodedData, int *P_dataLength) 
{
	OssBuf L_ossBuf;
	int L_retCode;

	if(!g_initialized)
		MAP1_initialize();

	L_ossBuf.value = *P_encodedData;
	L_ossBuf.length = *P_dataLength;

	L_retCode = ossEncode(gMAP1World,P_msgType,
				P_dataStruct,&L_ossBuf);
	if(L_retCode != 0) {
		return L_retCode;
	}
	*P_encodedData = L_ossBuf.value;
	*P_dataLength = L_ossBuf.length;
    	return 0; //All fine, no error.
}


int MAP1_decode(unsigned char **P_encodedData,int P_buffLen,int P_msgType,
 void **P_decodedStruct) 
{
	OssBuf L_encodedData;
	int L_retCode;

	if(!g_initialized)
		MAP1_initialize();

	L_encodedData.value = *P_encodedData;
	L_encodedData.length = P_buffLen;

	L_retCode = ossDecode(gMAP1World,&P_msgType,
			&L_encodedData,P_decodedStruct) ;

	if(L_retCode != 0) {
		return L_retCode;
	}

	return 0;
}

long MAP1_setDecodingLength(long P_bufferLength) 
{
	 if(!g_initialized)
                MAP1_initialize();

	return ossSetDecodingLength(gMAP1World,P_bufferLength);
}

long MAP1_getEncodingLength(int P_msgType,void *P_data)
{
	long L_long;

	if(!g_initialized)
                MAP1_initialize();

	L_long =  ossDetermineEncodingLength(gMAP1World,P_msgType,P_data);

	return L_long;
}

char *MAP1_getErrMsg()
{
	char *L_charPtr;

	if(!g_initialized)
                MAP1_initialize();

	L_charPtr =  ossGetErrMsg(gMAP1World);
	return L_charPtr;
}


