/*************************************************************/
/* Copyright (C) 2017 OSS Nokalva, Inc.  All rights reserved.*/
/*************************************************************/

/* THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC.
 * AND MAY BE USED ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC.
 * THIS FILE MAY NOT BE DISTRIBUTED.
 * THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED. */

/* Generated for: Plintron Global Technology Solutions Pvt. Ltd. - Site-based, License 75139 75139,
 * at GKS Tech Park, DLT IT SEZ, Chennai 600089, India. */
/* Abstract syntax: OMAP1 */
/* Created: Fri Oct  6 15:46:02 2017 */
/* ASN.1 compiler version: 10.5 */
/* Code generated for runtime version 10.5 or later */
/* Compiler operating system: Linux with 64-bit support */
/* Compiler machine type: AMD64 */
/* Target operating system: Linux with 64-bit support */
/* Target machine type: AMD64 */
/* C compiler options required: -m64 */
/* ASN.1 compiler options and file names specified:
 * -prefix OMAP1_ -c++ -nowarningmessages -ber -root -ignoreIncompleteItems
 * -compat v4.2defaults -compat v4.2octetstringdefault
 * /usr/local/ossasn1/linux-x86-64/10.5.0//asn1dflt.linux-amd64 TCAP.asn
 * MAP-ExtensionDataTypes.asn MAP-Constants.asn MAP-DataTypes.asn
 * MAP1-DataTypes.asn MAP-Errors.asn MAP-Operations.asn OMAP1.asn
 */

#ifndef OSS_OMAP1
#define OSS_OMAP1

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include "ossasn1.h"

#define          OMAP1_MessageType_PDU 1
#define          OMAP1_ExtensionContainer_PDU 2
#define          OMAP1_SS_SubscriptionOption_PDU 3
#define          OMAP1_UpdateLocationAreaArg_PDU 4
#define          OMAP1_UpdateLocationArg_PDU 5
#define          OMAP1_UpdateLocationRes_PDU 6
#define          OMAP1_CancelLocationArg_PDU 7
#define          OMAP1_DetachIMSIArg_PDU 8
#define          OMAP1_AttachIMSIArg_PDU 9
#define          OMAP1_DeregisterMobileSubscriberArg_PDU 10
#define          OMAP1_InsertSubscriberDataArg_PDU 11
#define          OMAP1_DeleteSubscriberDataArg_PDU 12
#define          OMAP1_SendParametersArg_PDU 13
#define          OMAP1_SendParametersRes_PDU 14
#define          OMAP1_RegisterSSArg_PDU 15
#define          OMAP1_RegisterSSRes_PDU 16
#define          OMAP1_EraseSSArg_PDU 17
#define          OMAP1_EraseSSRes_PDU 18
#define          OMAP1_ActivateSSArg_PDU 19
#define          OMAP1_ActivateSSRes_PDU 20
#define          OMAP1_DeactivateSSArg_PDU 21
#define          OMAP1_DeactivateSSRes_PDU 22
#define          OMAP1_InterrogateSSArg_PDU 23
#define          OMAP1_InterrogateSSRes_PDU 24
#define          OMAP1_InvokeSSArg_PDU 25
#define          OMAP1_InvokeSSRes_PDU 26
#define          OMAP1_ForwardSsNotificationArg_PDU 27
#define          OMAP1_RegisterPasswordArg_PDU 28
#define          OMAP1_RegisterPasswordRes_PDU 29
#define          OMAP1_GetPasswordArg_PDU 30
#define          OMAP1_GetPasswordRes_PDU 31
#define          OMAP1_ProcessUnstructuredSsDataArg_PDU 32
#define          OMAP1_ProcessUnstructuredSsDataRes_PDU 33
#define          OMAP1_SendInfoForIncomingCallArg_PDU 34
#define          OMAP1_SendInfoForOutgoingCallArg_PDU 35
#define          OMAP1_SendRoutingInformationArg_PDU 36
#define          OMAP1_SendRoutingInformationRes_PDU 37
#define          OMAP1_ProvideRoamingNumberArg_PDU 38
#define          OMAP1_ProvideRoamingNumberRes_PDU 39
#define          OMAP1_CompleteCallArg_PDU 40
#define          OMAP1_ConnectToFollowingAddressArg_PDU 41
#define          OMAP1_PageArg_PDU 42
#define          OMAP1_SearchForMobileSubscriberArg_PDU 43
#define          OMAP1_SearchForMobileSubscriberRes_PDU 44
#define          OMAP1_PerformHandoverArg_PDU 45
#define          OMAP1_PerformHandoverRes_PDU 46
#define          OMAP1_PerformSubsequentHandoverArg_PDU 47
#define          OMAP1_PerformSubsequentHandoverRes_PDU 48
#define          OMAP1_ProcessAccessSignallingArg_PDU 49
#define          OMAP1_ForwardAccessSignallingArg_PDU 50
#define          OMAP1_SendHandoverReportArg_PDU 51
#define          OMAP1_RegisterChargingInformationArg_PDU 52
#define          OMAP1_ResetArg_PDU 53
#define          OMAP1_ActivateTraceModeArg_PDU 54
#define          OMAP1_DeactivateTraceModeArg_PDU 55
#define          OMAP1_TraceSubscriberActivityArg_PDU 56
#define          OMAP1_NoteInternalHandoverArg_PDU 57
#define          OMAP1_CheckIMEArg_PDU 58
#define          OMAP1_CheckIMEIRes_PDU 59
#define          OMAP1_AuthenticateArg_PDU 60
#define          OMAP1_AuthenticateRes_PDU 61
#define          OMAP1_ProvideIMSIRes_PDU 62
#define          OMAP1_SetCipheringModeArg_PDU 63
#define          OMAP1_SendRoutingInfoForSMArg_PDU 64
#define          OMAP1_ForwardNewTMSIArg_PDU 65
#define          OMAP1_SendRoutingInfoForSMRes_PDU 66
#define          OMAP1_ForwardShortMessageArg_PDU 67
#define          OMAP1_SetMessageWaitingDataArg_PDU 68
#define          OMAP1_NoteMSPresentArg_PDU 69
#define          OMAP1_AlertServiceCentreArg_PDU 70
#define          OMAP1_ProcessAccessRequestArg_PDU 71
#define          OMAP1_ProcessAccessRequestRes_PDU 72
#define          OMAP1_BeginSubscriberActivityArg_PDU 73
#define          OMAP1_UnknownSubscriber_PDU 74
#define          OMAP1_UnknownBaseStation_PDU 75
#define          OMAP1_UnknownMSC_PDU 76
#define          OMAP1_UnknownLocArea_PDU 77
#define          OMAP1_UnidentifiedSubscriber_PDU 78
#define          OMAP1_UnallocatedRoamingNumber_PDU 79
#define          OMAP1_UnknownEquipment_PDU 80
#define          OMAP1_RoamingNotAllowed_PDU 81
#define          OMAP1_IllegalMS_PDU 82
#define          OMAP1_BearerServiceNotProvisioned_PDU 83
#define          OMAP1_TeleserviceNotProvisioned_PDU 84
#define          OMAP1_InsufficientBearerCapabilities_PDU 85
#define          OMAP1_CallBarred_PARAMETER_PDU 86
#define          OMAP1_CallBarred_PDU 87
#define          OMAP1_ForwardingViolation_PDU 88
#define          OMAP1_CUG_Reject_PARAMETER_PDU 89
#define          OMAP1_CUG_Reject_PDU 90
#define          OMAP1_IllegalSS_Operation_PDU 91
#define          OMAP1_SS_ErrorStatus_PDU 92
#define          OMAP1_SS_NotAvailable_PDU 93
#define          OMAP1_SS_SubscriptionViolation_PDU 94
#define          OMAP1_SS_Incompatibility_PARAMETER_PDU 95
#define          OMAP1_SS_Incompatibility_PDU 96
#define          OMAP1_FacilityNotSupported_PDU 97
#define          OMAP1_InvalidTargetBaseStation_PDU 98
#define          OMAP1_NoRadioResourceAvailable_PDU 99
#define          OMAP1_NoHandoverNumberAvailable_PDU 100
#define          OMAP1_SubsequentHandoverFailure_PDU 101
#define          OMAP1_AbsentSubscriber_PARAMETER_PDU 102
#define          OMAP1_AbsentSubscriber_PDU 103
#define          OMAP1_BusySubscriber_PDU 104
#define          OMAP1_NoSubscriberReply_PDU 105
#define          OMAP1_RadioCongestion_PDU 106
#define          OMAP1_ImpossibleCallCompletion_PDU 107
#define          OMAP1_SM_DeliveryFailure_PARAMETER_PDU 108
#define          OMAP1_SM_DeliveryFailure_PDU 109
#define          OMAP1_MessageWaitingListFull_PDU 110
#define          OMAP1_SystemFailure_PDU 111
#define          OMAP1_DataMissing_PDU 112
#define          OMAP1_UnexpectedDataValue_PDU 113
#define          OMAP1_PasswordRegistrationFailure_PARAMETER_PDU 114
#define          OMAP1_PasswordRegistrationFailure_PDU 115
#define          OMAP1_NegativePasswordCheck_PDU 116
#define          OMAP1_NoRoamingNumberAvailable_PDU 117
#define          OMAP1_TracingBufferFull_PDU 118
#define          OMAP1_UpdateLocationArea_PDU 119
#define          OMAP1_UpdateLocation_PDU 120
#define          OMAP1_CancelLocation_PDU 121
#define          OMAP1_DetachIMSI_PDU 122
#define          OMAP1_AttachIMSI_PDU 123
#define          OMAP1_DeregisterMobileSubscriber_PDU 124
#define          OMAP1_InsertSubscriberData_PDU 125
#define          OMAP1_DeleteSubscriberData_PDU 126
#define          OMAP1_SendParameters_PDU 127
#define          OMAP1_RegisterSS_PDU 128
#define          OMAP1_EraseSS_PDU 129
#define          OMAP1_ActivateSS_PDU 130
#define          OMAP1_DeactivateSS_PDU 131
#define          OMAP1_InterrogateSS_PDU 132
#define          OMAP1_InvokeSS_PDU 133
#define          OMAP1_ForwardSsNotification_PDU 134
#define          OMAP1_RegisterPassword_PDU 135
#define          OMAP1_GetPassword_PDU 136
#define          OMAP1_ProcessUnstructuredSsData_PDU 137
#define          OMAP1_SendInfoForIncomingCall_PDU 138
#define          OMAP1_SendInfoForOutgoingCall_PDU 139
#define          OMAP1_SendRoutingInformation_PDU 140
#define          OMAP1_ProvideRoamingNumber_PDU 141
#define          OMAP1_CompleteCall_PDU 142
#define          OMAP1_ConnectToFollowingAddress_PDU 143
#define          OMAP1_ProcessCallWaiting_PDU 144
#define          OMAP1_Page_PDU 145
#define          OMAP1_SearchForMobileSubscriber_PDU 146
#define          OMAP1_PerformHandover_PDU 147
#define          OMAP1_SendEndSignal_PDU 148
#define          OMAP1_PerformSubsequentHandover_PDU 149
#define          OMAP1_AllocateHandoverNumber_PDU 150
#define          OMAP1_SendHandoverReport_PDU 151
#define          OMAP1_ProcessAccessSignalling_PDU 152
#define          OMAP1_ForwardAccessSignalling_PDU 153
#define          OMAP1_RegisterChargingInformation_PDU 154
#define          OMAP1_Reset_PDU 155
#define          OMAP1_ForwardCheckSsIndication_PDU 156
#define          OMAP1_ActivateTraceMode_PDU 157
#define          OMAP1_DeactivateTraceMode_PDU 158
#define          OMAP1_TraceSubscriberActivity_PDU 159
#define          OMAP1_NoteInternalHandover_PDU 160
#define          OMAP1_CheckIMEI_PDU 161
#define          OMAP1_Authenticate_PDU 162
#define          OMAP1_ProvideIMSI_PDU 163
#define          OMAP1_ForwardNewTMSI_PDU 164
#define          OMAP1_SetCipheringMode_PDU 165
#define          OMAP1_SendRoutingInfoForSM_PDU 166
#define          OMAP1_ForwardShortMessage_PDU 167
#define          OMAP1_SetMessageWaitingData_PDU 168
#define          OMAP1_NoteMSPresent_PDU 169
#define          OMAP1_AlertServiceCentre_PDU 170
#define          OMAP1_ProcessAccessRequest_PDU 171
#define          OMAP1_BeginSubscriberActivity_PDU 172

typedef struct OMAP1__ObjectID_ {
    struct OMAP1__ObjectID_ *next;
    unsigned short  value;
} *OMAP1__ObjectID;

typedef struct OMAP1__Any {
    unsigned long   length;
    unsigned char   *value;
} OMAP1__Any;

typedef struct OMAP1__choice1 {
    unsigned short  choice;
#       define      OMAP1_single_ASN1_type_chosen 1
#       define      OMAP1_octet_aligned_chosen 2
#       define      OMAP1_arbitrary_chosen 3
    union _union {
        OpenType        single_ASN1_type;  /* to choose, set choice to
                                            * OMAP1_single_ASN1_type_chosen */
        struct OMAP1_External_octet_aligned {
            unsigned int    length;
            unsigned char   *value;
        } octet_aligned;  /* to choose, set choice to
                           * OMAP1_octet_aligned_chosen */
        struct OMAP1_External_arbitrary {
            unsigned int    length;  /* number of significant bits */
            unsigned char   *value;
        } arbitrary;  /* to choose, set choice to OMAP1_arbitrary_chosen */
    } u;
} OMAP1__choice1;

typedef struct OMAP1__External {
    unsigned char   bit_mask;
#       define      OMAP1_direct_reference_present 0x80
#       define      OMAP1_indirect_reference_present 0x40
    struct OMAP1__ObjectID_ *direct_reference;  /* optional; set in bit_mask
                                            * OMAP1_direct_reference_present if
                                            * present */
    int             indirect_reference;  /* optional; set in bit_mask
                                          * OMAP1_indirect_reference_present if
                                          * present */
    char            *data_value_descriptor;  /* NULL for not present */
    OMAP1__choice1  encoding;
} OMAP1__External;

// NOTE � When the Abort Message is generated by the Transaction sublayer, a p-Abort Cause must be
// present.The u-abortCause may be generated by the component sublayer in which case it is an ABRT
// APDU, or by the TC-User in which case it could be either an ABRT APDU or data in some user-defined
// abstract syntax.
typedef OMAP1__External OMAP1_DialoguePortion;

typedef struct OMAP1_Unidirectional {
    unsigned char   bit_mask;
#       define      OMAP1_Unidirectional_dialoguePortion_present 0x80
    OMAP1_DialoguePortion dialoguePortion;  /* optional; set in bit_mask
                              * OMAP1_Unidirectional_dialoguePortion_present if
                              * present */
    struct OMAP1_ComponentPortion_ *components;
} OMAP1_Unidirectional;

// The dialogue portion carries the dialogue control PDUs as value of the external data type.
// The direct reference should be set to { ccitt recommendation q 773 as (1) dialogue-as (1) version (1) }
// if structured dialogue is used and to { ccitt recommendation q 773 as (1) unidialogue-as (2) version (1) }
// if unstructured dialogue is used or any user defined abstract syntax name when only user information
// is carried (e.g. when user information is sent in a 1988 Abort message).
typedef struct OMAP1_OrigTransactionID {
    unsigned short  length;
    unsigned char   value[4];
} OMAP1_OrigTransactionID;

typedef struct OMAP1_Begin {
    unsigned char   bit_mask;
#       define      OMAP1_Begin_dialoguePortion_present 0x80
#       define      OMAP1_Begin_components_present 0x40
    OMAP1_OrigTransactionID otid;
    OMAP1_DialoguePortion dialoguePortion;  /* optional; set in bit_mask
                                       * OMAP1_Begin_dialoguePortion_present if
                                       * present */
    struct OMAP1_ComponentPortion_ *components;  /* optional; set in bit_mask
                                            * OMAP1_Begin_components_present if
                                            * present */
} OMAP1_Begin;

typedef struct OMAP1_DestTransactionID {
    unsigned short  length;
    unsigned char   value[4];
} OMAP1_DestTransactionID;

typedef struct OMAP1_End {
    unsigned char   bit_mask;
#       define      OMAP1_End_dialoguePortion_present 0x80
#       define      OMAP1_End_components_present 0x40
    OMAP1_DestTransactionID dtid;
    OMAP1_DialoguePortion dialoguePortion;  /* optional; set in bit_mask
                                             * OMAP1_End_dialoguePortion_present
                                             * if present */
    struct OMAP1_ComponentPortion_ *components;  /* optional; set in bit_mask
                                                  * OMAP1_End_components_present
                                                  * if present */
} OMAP1_End;

typedef struct OMAP1_Continue {
    unsigned char   bit_mask;
#       define      OMAP1_Continue_dialoguePortion_present 0x80
#       define      OMAP1_Continue_components_present 0x40
    OMAP1_OrigTransactionID otid;
    OMAP1_DestTransactionID dtid;
    OMAP1_DialoguePortion dialoguePortion;  /* optional; set in bit_mask
                                    * OMAP1_Continue_dialoguePortion_present if
                                    * present */
    struct OMAP1_ComponentPortion_ *components;  /* optional; set in bit_mask
                                         * OMAP1_Continue_components_present if
                                         * present */
} OMAP1_Continue;

typedef int             OMAP1_P_AbortCause;
#define                     OMAP1_unrecognizedMessageType 0
#define                     OMAP1_unrecognizedTransactionID 1
#define                     OMAP1_badlyFormattedTransactionPortion 2
#define                     OMAP1_incorrectTransactionPortion 3
#define                     OMAP1_P_AbortCause_resourceLimitation 4

typedef struct OMAP1__choice2 {
    unsigned short  choice;
#       define      OMAP1_p_abortCause_chosen 1
#       define      OMAP1_u_abortCause_chosen 2
    union _union {
        OMAP1_P_AbortCause p_abortCause;  /* to choose, set choice to
                                           * OMAP1_p_abortCause_chosen */
        OMAP1_DialoguePortion u_abortCause;  /* to choose, set choice to
                                              * OMAP1_u_abortCause_chosen */
    } u;
} OMAP1__choice2;

typedef struct OMAP1_Abort {
    unsigned char   bit_mask;
#       define      OMAP1_reason_present 0x80
    OMAP1_DestTransactionID dtid;
    OMAP1__choice2  reason;  /* optional; set in bit_mask OMAP1_reason_present
                              * if present */
} OMAP1_Abort;

// Transaction Portion fields
typedef struct OMAP1_MessageType {
    unsigned short  choice;
#       define      OMAP1_unidirectional_chosen 1
#       define      OMAP1_begin_chosen 2
#       define      OMAP1_end_chosen 3
#       define      OMAP1_continue_chosen 4
#       define      OMAP1_abort_chosen 5
    union _union {
        OMAP1_Unidirectional unidirectional;  /* to choose, set choice to
                                               * OMAP1_unidirectional_chosen */
        OMAP1_Begin     begin;  /* to choose, set choice to
                                 * OMAP1_begin_chosen */
        OMAP1_End       end;  /* to choose, set choice to OMAP1_end_chosen */
        OMAP1_Continue  MessageType_continue;  /* to choose, set choice to
                                                * OMAP1_continue_chosen */
        OMAP1_Abort     abort;  /* to choose, set choice to
                                 * OMAP1_abort_chosen */
    } u;
} OMAP1_MessageType;

typedef short           OMAP1_InvokeIdType;

typedef struct OMAP1__choice3 {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1__choice3;

// The Components are sequences of data elements.
typedef struct OMAP1_Invoke {
    unsigned char   bit_mask;
#       define      OMAP1_linkedID_present 0x80
#       define      OMAP1_Invoke_parameter_present 0x40
    OMAP1_InvokeIdType invokeID;
    OMAP1_InvokeIdType linkedID;  /* optional; set in bit_mask
                                   * OMAP1_linkedID_present if present */
    OMAP1__choice3  operationCode;
    OMAP1__Any      parameter;  /* optional; set in bit_mask
                                 * OMAP1_Invoke_parameter_present if present */
} OMAP1_Invoke;

// ANY is filled by the single ASN.1 data type following the keyword PARAMETER or the keyword ARGUMENT
// in the type definition of a particular operation.
typedef struct OMAP1_ReturnResult {
    unsigned char   bit_mask;
#       define      OMAP1_result_present 0x80
    OMAP1_InvokeIdType invokeID;
    struct OMAP1__seq1 {
        OMAP1__choice3  operationCode;
        OMAP1__Any      parameter;
    } result;  /* optional; set in bit_mask OMAP1_result_present if present */
} OMAP1_ReturnResult;

// ANY is filled by the single ASN.1 data type following the keyword RESULT in the type definition
// of a particular operation.
typedef struct OMAP1_ReturnError {
    unsigned char   bit_mask;
#       define      OMAP1_ReturnError_parameter_present 0x80
    OMAP1_InvokeIdType invokeID;
    OMAP1__choice3  errorCode;
    OMAP1__Any      parameter;  /* optional; set in bit_mask
                                 * OMAP1_ReturnError_parameter_present if
                                 * present */
} OMAP1_ReturnError;

// PROBLEMS
typedef int             OMAP1_GeneralProblem;
#define                     OMAP1_unrecognizedComponent 0
#define                     OMAP1_mistypedComponent 1
#define                     OMAP1_badlyStructuredComponent 2

typedef int             OMAP1_InvokeProblem;
#define                     OMAP1_duplicateInvokeID 0
#define                     OMAP1_unrecognizedOperation 1
#define                     OMAP1_InvokeProblem_mistypedParameter 2
#define                     OMAP1_InvokeProblem_resourceLimitation 3
#define                     OMAP1_initiatingRelease 4
#define                     OMAP1_unrecognizedLinkedID 5
#define                     OMAP1_linkedResponseUnexpected 6
#define                     OMAP1_unexpectedLinkedOperation 7

typedef int             OMAP1_ReturnResultProblem;
#define                     OMAP1_ReturnResultProblem_unrecognizedInvokeID 0
#define                     OMAP1_returnResultUnexpected 1
#define                     OMAP1_ReturnResultProblem_mistypedParameter 2

typedef int             OMAP1_ReturnErrorProblem;
#define                     OMAP1_ReturnErrorProblem_unrecognizedInvokeID 0
#define                     OMAP1_returnErrorUnexpected 1
#define                     OMAP1_unrecognizedError 2
#define                     OMAP1_unexpectedError 3
#define                     OMAP1_ReturnErrorProblem_mistypedParameter 4

typedef struct OMAP1__choice4 {
    unsigned short  choice;
#       define      OMAP1_derivable_chosen 1
#       define      OMAP1_not_derivable_chosen 2
    union _union {
        OMAP1_InvokeIdType derivable;  /* to choose, set choice to
                                        * OMAP1_derivable_chosen */
        Nulltype        not_derivable;  /* to choose, set choice to
                                         * OMAP1_not_derivable_chosen */
    } u;
} OMAP1__choice4;

typedef struct OMAP1__choice5 {
    unsigned short  choice;
#       define      OMAP1_generalProblem_chosen 1
#       define      OMAP1_invokeProblem_chosen 2
#       define      OMAP1_returnResultProblem_chosen 3
#       define      OMAP1_returnErrorProblem_chosen 4
    union _union {
        OMAP1_GeneralProblem generalProblem;  /* to choose, set choice to
                                               * OMAP1_generalProblem_chosen */
        OMAP1_InvokeProblem invokeProblem;  /* to choose, set choice to
                                             * OMAP1_invokeProblem_chosen */
        OMAP1_ReturnResultProblem returnResultProblem;  /* to choose, set choice
                                       * to OMAP1_returnResultProblem_chosen */
        OMAP1_ReturnErrorProblem returnErrorProblem;  /* to choose, set choice
                                        * to OMAP1_returnErrorProblem_chosen */
    } u;
} OMAP1__choice5;

// ANY is filled by the single ASN.1 data type following the keyword PARAMETER in the type definition
// of a particular error.
typedef struct OMAP1_Reject {
    OMAP1__choice4  invokeID;
    OMAP1__choice5  problem;
} OMAP1_Reject;

// Component Portion fields
// COMPONENT TYPE. Recommendation X.229 defines four Application Protocol Data Units (APDUs).
// TCAP adds returnResultNotLast to allow for the segmentation of a result.
typedef struct OMAP1_Component {
    unsigned short  choice;
#       define      OMAP1_invoke_chosen 1
#       define      OMAP1_returnResultLast_chosen 2
#       define      OMAP1_returnError_chosen 3
#       define      OMAP1_reject_chosen 4
#       define      OMAP1_returnResultNotLast_chosen 5
    union _union {
        OMAP1_Invoke    invoke;  /* to choose, set choice to
                                  * OMAP1_invoke_chosen */
        OMAP1_ReturnResult returnResultLast;  /* to choose, set choice to
                                             * OMAP1_returnResultLast_chosen */
        OMAP1_ReturnError returnError;  /* to choose, set choice to
                                         * OMAP1_returnError_chosen */
        OMAP1_Reject    reject;  /* to choose, set choice to
                                  * OMAP1_reject_chosen */
        OMAP1_ReturnResult returnResultNotLast;  /* to choose, set choice to
                                          * OMAP1_returnResultNotLast_chosen */
    } u;
} OMAP1_Component;

// COMPONENT PORTION. The last field in the transaction portion of the TCAP message is the Component Portion.
// The Component Portion may be absent.
typedef struct OMAP1_ComponentPortion_ {
    struct OMAP1_ComponentPortion_ *next;
    OMAP1_Component value;
} *OMAP1_ComponentPortion;

// IOC for private extensions
typedef struct OMAP1_EXTENSION {
    unsigned char   bit_mask;
#       define      OMAP1_ExtensionType_present 0x80
    unsigned short  ExtensionType;  /* optional; set in bit_mask
                                     * OMAP1_ExtensionType_present if present */
    struct OMAP1__ObjectID_ *extensionId;
    long            _oss_unique_index;
} OMAP1_EXTENSION;

		// 1 bit per defined indication

//Password	 ::= CHOICE {
//		PrintableString (SIZE(4..8)),
//		NumericString (FROM (
//		"0"|"1"|"2"|"3"|"4"|
//		"5"|"6"|"7"|"8"|"9")|
//		SIZE(4))}
		// only the second form is used for GSM systems.
typedef char            OMAP1_Password[5];

//RegisterPasswordRes	::=	SEQUENCE { newPassword 	Password}
typedef OMAP1_Password  OMAP1_RegisterPasswordRes;

//GetPasswordRes ::=	SEQUENCE { currentPassword	Password}
typedef OMAP1_Password  OMAP1_GetPasswordRes;

		// the identifiers used in this description represent
		// the information which has to be delivered to the subscriber
		// according to table 6.4/4.
		// How this information is really delivered to the subscriber
		// (display, announcement, ...) is not part of this specification.
typedef char            OMAP1_SS_UserData[201];

//ProcessUnstructuredSsDataArg ::=	SEQUENCE {
//ss-UserData		SS-UserData}
typedef OMAP1_SS_UserData OMAP1_ProcessUnstructuredSsDataArg;

typedef enum OMAP1_CallBarred_PARAMETER {
    OMAP1_barringServiceActive = 0,
    OMAP1_operatorBarring = 1
} OMAP1_CallBarred_PARAMETER;

typedef enum OMAP1_CUG_Reject_PARAMETER {
    OMAP1_incomingCallBarred = 0,
    OMAP1_nonCUGmember = 1
} OMAP1_CUG_Reject_PARAMETER;

typedef enum OMAP1_SM_DeliveryFailure_PARAMETER {
    OMAP1_memoryCapacityExceeded = 0,
    OMAP1_msProtocolError = 1,
    OMAP1_msNotEquiped = 2,
    OMAP1_unknownServiceCentre = 3,
    OMAP1_scCongestion = 4,
    OMAP1_invalidSmeAddress = 5,
    OMAP1_msNotScSubscriber = 6
} OMAP1_SM_DeliveryFailure_PARAMETER;

typedef enum OMAP1_PasswordRegistrationFailure_PARAMETER {
    OMAP1_PasswordRegistrationFailure_PARAMETER_undetermined = 0,
    OMAP1_invalidFormat = 1,
    OMAP1_newPasswordsMismatch = 2
} OMAP1_PasswordRegistrationFailure_PARAMETER;

typedef ossBoolean      OMAP1_AbsentSubscriber_PARAMETER;

union OMAP1_All_PDU_Types_union {
    OMAP1_MessageType *pdu_MessageType;  /* OMAP1_MessageType_PDU */
    struct OMAP1_ExtensionContainer *pdu_ExtensionContainer;  
                                             /* OMAP1_ExtensionContainer_PDU */
    struct OMAP1_SS_SubscriptionOption *pdu_SS_SubscriptionOption;  
                                          /* OMAP1_SS_SubscriptionOption_PDU */
    struct OMAP1_UpdateLocationAreaArg *pdu_UpdateLocationAreaArg;  
                                          /* OMAP1_UpdateLocationAreaArg_PDU */
    struct OMAP1_UpdateLocationArg *pdu_UpdateLocationArg;  
                                              /* OMAP1_UpdateLocationArg_PDU */
    struct OMAP1_IsdnAddressString *pdu_UpdateLocationRes;  
                                              /* OMAP1_UpdateLocationRes_PDU */
    struct OMAP1_CancelLocationArg *pdu_CancelLocationArg;  
                                              /* OMAP1_CancelLocationArg_PDU */
    struct OMAP1_DetachIMSIArg *pdu_DetachIMSIArg;  
                                                  /* OMAP1_DetachIMSIArg_PDU */
    struct OMAP1_AttachIMSIArg *pdu_AttachIMSIArg;  
                                                  /* OMAP1_AttachIMSIArg_PDU */
    struct OMAP1_DeregisterMobileSubscriberArg *pdu_DeregisterMobileSubscriberArg;                                      /* OMAP1_DeregisterMobileSubscriberArg_PDU */
    struct OMAP1_InsertSubscriberDataArg *pdu_InsertSubscriberDataArg;  
                                        /* OMAP1_InsertSubscriberDataArg_PDU */
    struct OMAP1_DeleteSubscriberDataArg *pdu_DeleteSubscriberDataArg;  
                                        /* OMAP1_DeleteSubscriberDataArg_PDU */
    struct OMAP1_SendParametersArg *pdu_SendParametersArg;  
                                              /* OMAP1_SendParametersArg_PDU */
    struct OMAP1_SendParametersRes *pdu_SendParametersRes;  
                                              /* OMAP1_SendParametersRes_PDU */
    struct OMAP1_RegisterSSArg *pdu_RegisterSSArg;  
                                                  /* OMAP1_RegisterSSArg_PDU */
    struct OMAP1_RegisterSSRes *pdu_RegisterSSRes;  
                                                  /* OMAP1_RegisterSSRes_PDU */
    struct OMAP1_EraseSSArg *pdu_EraseSSArg;  /* OMAP1_EraseSSArg_PDU */
    struct OMAP1_EraseSSRes *pdu_EraseSSRes;  /* OMAP1_EraseSSRes_PDU */
    struct OMAP1_ActivateSSArg *pdu_ActivateSSArg;  
                                                  /* OMAP1_ActivateSSArg_PDU */
    struct OMAP1_ActivateSSRes *pdu_ActivateSSRes;  
                                                  /* OMAP1_ActivateSSRes_PDU */
    struct OMAP1_DeactivateSSArg *pdu_DeactivateSSArg;  
                                                /* OMAP1_DeactivateSSArg_PDU */
    struct OMAP1_DeactivateSSRes *pdu_DeactivateSSRes;  
                                                /* OMAP1_DeactivateSSRes_PDU */
    struct OMAP1_InterrogateSSArg *pdu_InterrogateSSArg;  
                                               /* OMAP1_InterrogateSSArg_PDU */
    struct OMAP1_InterrogateSSRes *pdu_InterrogateSSRes;  
                                               /* OMAP1_InterrogateSSRes_PDU */
    struct OMAP1_InvokeSSArg *pdu_InvokeSSArg;  /* OMAP1_InvokeSSArg_PDU */
    struct OMAP1_InvokeSSRes *pdu_InvokeSSRes;  /* OMAP1_InvokeSSRes_PDU */
    struct OMAP1_ForwardSsNotificationArg *pdu_ForwardSsNotificationArg;  
                                        /* OMAP1_ForwardSsNotificationArg_PDU */
    struct OMAP1_RegisterPasswordArg *pdu_RegisterPasswordArg;  
                                            /* OMAP1_RegisterPasswordArg_PDU */
    OMAP1_RegisterPasswordRes *pdu_RegisterPasswordRes;  
                                            /* OMAP1_RegisterPasswordRes_PDU */
    struct OMAP1_GetPasswordArg *pdu_GetPasswordArg;  
                                                 /* OMAP1_GetPasswordArg_PDU */
    OMAP1_GetPasswordRes *pdu_GetPasswordRes;  /* OMAP1_GetPasswordRes_PDU */
    OMAP1_ProcessUnstructuredSsDataArg *pdu_ProcessUnstructuredSsDataArg;  
                                        /* OMAP1_ProcessUnstructuredSsDataArg_PDU */
    struct OMAP1_ProcessUnstructuredSsDataRes *pdu_ProcessUnstructuredSsDataRes;                                        /* OMAP1_ProcessUnstructuredSsDataRes_PDU */
    struct OMAP1_SendInfoForIncomingCallArg *pdu_SendInfoForIncomingCallArg;  
                                        /* OMAP1_SendInfoForIncomingCallArg_PDU */
    struct OMAP1_SendInfoForOutgoingCallArg *pdu_SendInfoForOutgoingCallArg;  
                                        /* OMAP1_SendInfoForOutgoingCallArg_PDU */
    struct OMAP1_SendRoutingInformationArg *pdu_SendRoutingInformationArg;  
                                        /* OMAP1_SendRoutingInformationArg_PDU */
    struct OMAP1_SendRoutingInformationRes *pdu_SendRoutingInformationRes;  
                                        /* OMAP1_SendRoutingInformationRes_PDU */
    struct OMAP1_ProvideRoamingNumberArg *pdu_ProvideRoamingNumberArg;  
                                        /* OMAP1_ProvideRoamingNumberArg_PDU */
    struct OMAP1_IsdnAddressString *pdu_ProvideRoamingNumberRes;  
                                        /* OMAP1_ProvideRoamingNumberRes_PDU */
    struct OMAP1_CompleteCallArg *pdu_CompleteCallArg;  
                                                /* OMAP1_CompleteCallArg_PDU */
    struct OMAP1_ConnectToFollowingAddressArg *pdu_ConnectToFollowingAddressArg;                                        /* OMAP1_ConnectToFollowingAddressArg_PDU */
    struct OMAP1_PageArg *pdu_PageArg;  /* OMAP1_PageArg_PDU */
    struct OMAP1_SearchForMobileSubscriberArg *pdu_SearchForMobileSubscriberArg;                                        /* OMAP1_SearchForMobileSubscriberArg_PDU */
    struct OMAP1_SearchForMobileSubscriberRes *pdu_SearchForMobileSubscriberRes;                                        /* OMAP1_SearchForMobileSubscriberRes_PDU */
    struct OMAP1_PerformHandoverArg *pdu_PerformHandoverArg;  
                                             /* OMAP1_PerformHandoverArg_PDU */
    struct OMAP1_PerformHandoverRes *pdu_PerformHandoverRes;  
                                             /* OMAP1_PerformHandoverRes_PDU */
    struct OMAP1_PerformSubsequentHandoverArg *pdu_PerformSubsequentHandoverArg;                                        /* OMAP1_PerformSubsequentHandoverArg_PDU */
    struct OMAP1_PerformSubsequentHandoverRes *pdu_PerformSubsequentHandoverRes;                                        /* OMAP1_PerformSubsequentHandoverRes_PDU */
    struct OMAP1_ProcessAccessSignallingArg *pdu_ProcessAccessSignallingArg;  
                                        /* OMAP1_ProcessAccessSignallingArg_PDU */
    struct OMAP1_ForwardAccessSignallingArg *pdu_ForwardAccessSignallingArg;  
                                        /* OMAP1_ForwardAccessSignallingArg_PDU */
    struct OMAP1_SendHandoverReportArg *pdu_SendHandoverReportArg;  
                                          /* OMAP1_SendHandoverReportArg_PDU */
    struct OMAP1_RegisterChargingInformationArg *pdu_RegisterChargingInformationArg;                                    /* OMAP1_RegisterChargingInformationArg_PDU */
    struct OMAP1_ResetArg *pdu_ResetArg;  /* OMAP1_ResetArg_PDU */
    struct OMAP1_ActivateTraceModeArg *pdu_ActivateTraceModeArg;  
                                           /* OMAP1_ActivateTraceModeArg_PDU */
    struct OMAP1_DeactivateTraceModeArg *pdu_DeactivateTraceModeArg;  
                                         /* OMAP1_DeactivateTraceModeArg_PDU */
    struct OMAP1_TraceSubscriberActivityArg *pdu_TraceSubscriberActivityArg;  
                                        /* OMAP1_TraceSubscriberActivityArg_PDU */
    struct OMAP1_NoteInternalHandoverArg *pdu_NoteInternalHandoverArg;  
                                        /* OMAP1_NoteInternalHandoverArg_PDU */
    struct OMAP1_CheckIMEArg *pdu_CheckIMEArg;  /* OMAP1_CheckIMEArg_PDU */
    struct OMAP1_CheckIMEIRes *pdu_CheckIMEIRes;  /* OMAP1_CheckIMEIRes_PDU */
    struct OMAP1_AuthenticateArg *pdu_AuthenticateArg;  
                                                /* OMAP1_AuthenticateArg_PDU */
    struct OMAP1_AuthenticateRes *pdu_AuthenticateRes;  
                                                /* OMAP1_AuthenticateRes_PDU */
    struct OMAP1_ProvideIMSIRes *pdu_ProvideIMSIRes;  
                                                 /* OMAP1_ProvideIMSIRes_PDU */
    struct OMAP1_SetCipheringModeArg *pdu_SetCipheringModeArg;  
                                            /* OMAP1_SetCipheringModeArg_PDU */
    struct OMAP1_SendRoutingInfoForSMArg *pdu_SendRoutingInfoForSMArg;  
                                        /* OMAP1_SendRoutingInfoForSMArg_PDU */
    struct OMAP1_ForwardNewTMSIArg *pdu_ForwardNewTMSIArg;  
                                              /* OMAP1_ForwardNewTMSIArg_PDU */
    struct OMAP1_SendRoutingInfoForSMRes *pdu_SendRoutingInfoForSMRes;  
                                        /* OMAP1_SendRoutingInfoForSMRes_PDU */
    struct OMAP1_ForwardShortMessageArg *pdu_ForwardShortMessageArg;  
                                         /* OMAP1_ForwardShortMessageArg_PDU */
    struct OMAP1_SetMessageWaitingDataArg *pdu_SetMessageWaitingDataArg;  
                                        /* OMAP1_SetMessageWaitingDataArg_PDU */
    struct OMAP1_IMSI *pdu_NoteMSPresentArg;  /* OMAP1_NoteMSPresentArg_PDU */
    struct OMAP1_AlertServiceCentreArg *pdu_AlertServiceCentreArg;  
                                          /* OMAP1_AlertServiceCentreArg_PDU */
    struct OMAP1_ProcessAccessRequestArg *pdu_ProcessAccessRequestArg;  
                                        /* OMAP1_ProcessAccessRequestArg_PDU */
    struct OMAP1_ProcessAccessRequestRes *pdu_ProcessAccessRequestRes;  
                                        /* OMAP1_ProcessAccessRequestRes_PDU */
    struct OMAP1_BeginSubscriberActivityArg *pdu_BeginSubscriberActivityArg;  
                                        /* OMAP1_BeginSubscriberActivityArg_PDU */
    struct OMAP1_UnknownSubscriber *pdu_UnknownSubscriber;  
                                              /* OMAP1_UnknownSubscriber_PDU */
    struct OMAP1_UnknownBaseStation *pdu_UnknownBaseStation;  
                                             /* OMAP1_UnknownBaseStation_PDU */
    struct OMAP1_UnknownMSC *pdu_UnknownMSC;  /* OMAP1_UnknownMSC_PDU */
    struct OMAP1_UnknownLocArea *pdu_UnknownLocArea;  
                                                 /* OMAP1_UnknownLocArea_PDU */
    struct OMAP1_UnidentifiedSubscriber *pdu_UnidentifiedSubscriber;  
                                         /* OMAP1_UnidentifiedSubscriber_PDU */
    struct OMAP1_UnallocatedRoamingNumber *pdu_UnallocatedRoamingNumber;  
                                        /* OMAP1_UnallocatedRoamingNumber_PDU */
    struct OMAP1_UnknownEquipment *pdu_UnknownEquipment;  
                                               /* OMAP1_UnknownEquipment_PDU */
    struct OMAP1_RoamingNotAllowed *pdu_RoamingNotAllowed;  
                                              /* OMAP1_RoamingNotAllowed_PDU */
    struct OMAP1_IllegalMS *pdu_IllegalMS;  /* OMAP1_IllegalMS_PDU */
    struct OMAP1_BearerServiceNotProvisioned *pdu_BearerServiceNotProvisioned;                                          /* OMAP1_BearerServiceNotProvisioned_PDU */
    struct OMAP1_TeleserviceNotProvisioned *pdu_TeleserviceNotProvisioned;  
                                        /* OMAP1_TeleserviceNotProvisioned_PDU */
    struct OMAP1_InsufficientBearerCapabilities *pdu_InsufficientBearerCapabilities;                                    /* OMAP1_InsufficientBearerCapabilities_PDU */
    OMAP1_CallBarred_PARAMETER *pdu_CallBarred_PARAMETER;  
                                           /* OMAP1_CallBarred_PARAMETER_PDU */
    struct OMAP1_CallBarred *pdu_CallBarred;  /* OMAP1_CallBarred_PDU */
    struct OMAP1_ForwardingViolation *pdu_ForwardingViolation;  
                                            /* OMAP1_ForwardingViolation_PDU */
    OMAP1_CUG_Reject_PARAMETER *pdu_CUG_Reject_PARAMETER;  
                                           /* OMAP1_CUG_Reject_PARAMETER_PDU */
    struct OMAP1_CUG_Reject *pdu_CUG_Reject;  /* OMAP1_CUG_Reject_PDU */
    struct OMAP1_IllegalSS_Operation *pdu_IllegalSS_Operation;  
                                            /* OMAP1_IllegalSS_Operation_PDU */
    struct OMAP1_SS_ErrorStatus *pdu_SS_ErrorStatus;  
                                                 /* OMAP1_SS_ErrorStatus_PDU */
    struct OMAP1_SS_NotAvailable *pdu_SS_NotAvailable;  
                                                /* OMAP1_SS_NotAvailable_PDU */
    struct OMAP1_SS_SubscriptionViolation *pdu_SS_SubscriptionViolation;  
                                        /* OMAP1_SS_SubscriptionViolation_PDU */
    struct OMAP1_SS_Incompatibility_PARAMETER *pdu_SS_Incompatibility_PARAMETER;                                        /* OMAP1_SS_Incompatibility_PARAMETER_PDU */
    struct OMAP1_SS_Incompatibility *pdu_SS_Incompatibility;  
                                             /* OMAP1_SS_Incompatibility_PDU */
    struct OMAP1_FacilityNotSupported *pdu_FacilityNotSupported;  
                                           /* OMAP1_FacilityNotSupported_PDU */
    struct OMAP1_InvalidTargetBaseStation *pdu_InvalidTargetBaseStation;  
                                        /* OMAP1_InvalidTargetBaseStation_PDU */
    struct OMAP1_NoRadioResourceAvailable *pdu_NoRadioResourceAvailable;  
                                        /* OMAP1_NoRadioResourceAvailable_PDU */
    struct OMAP1_NoHandoverNumberAvailable *pdu_NoHandoverNumberAvailable;  
                                        /* OMAP1_NoHandoverNumberAvailable_PDU */
    struct OMAP1_SubsequentHandoverFailure *pdu_SubsequentHandoverFailure;  
                                        /* OMAP1_SubsequentHandoverFailure_PDU */
    OMAP1_AbsentSubscriber_PARAMETER *pdu_AbsentSubscriber_PARAMETER;  
                                     /* OMAP1_AbsentSubscriber_PARAMETER_PDU */
    struct OMAP1_AbsentSubscriber *pdu_AbsentSubscriber;  
                                               /* OMAP1_AbsentSubscriber_PDU */
    struct OMAP1_BusySubscriber *pdu_BusySubscriber;  
                                                 /* OMAP1_BusySubscriber_PDU */
    struct OMAP1_NoSubscriberReply *pdu_NoSubscriberReply;  
                                              /* OMAP1_NoSubscriberReply_PDU */
    struct OMAP1_RadioCongestion *pdu_RadioCongestion;  
                                                /* OMAP1_RadioCongestion_PDU */
    struct OMAP1_ImpossibleCallCompletion *pdu_ImpossibleCallCompletion;  
                                        /* OMAP1_ImpossibleCallCompletion_PDU */
    OMAP1_SM_DeliveryFailure_PARAMETER *pdu_SM_DeliveryFailure_PARAMETER;  
                                        /* OMAP1_SM_DeliveryFailure_PARAMETER_PDU */
    struct OMAP1_SM_DeliveryFailure *pdu_SM_DeliveryFailure;  
                                             /* OMAP1_SM_DeliveryFailure_PDU */
    struct OMAP1_MessageWaitingListFull *pdu_MessageWaitingListFull;  
                                         /* OMAP1_MessageWaitingListFull_PDU */
    struct OMAP1_SystemFailure *pdu_SystemFailure;  
                                                  /* OMAP1_SystemFailure_PDU */
    struct OMAP1_DataMissing *pdu_DataMissing;  /* OMAP1_DataMissing_PDU */
    struct OMAP1_UnexpectedDataValue *pdu_UnexpectedDataValue;  
                                            /* OMAP1_UnexpectedDataValue_PDU */
    OMAP1_PasswordRegistrationFailure_PARAMETER *pdu_PasswordRegistrationFailure_PARAMETER;                             /* OMAP1_PasswordRegistrationFailure_PARAMETER_PDU */
    struct OMAP1_PasswordRegistrationFailure *pdu_PasswordRegistrationFailure;                                          /* OMAP1_PasswordRegistrationFailure_PDU */
    struct OMAP1_NegativePasswordCheck *pdu_NegativePasswordCheck;  
                                          /* OMAP1_NegativePasswordCheck_PDU */
    struct OMAP1_NoRoamingNumberAvailable *pdu_NoRoamingNumberAvailable;  
                                        /* OMAP1_NoRoamingNumberAvailable_PDU */
    struct OMAP1_TracingBufferFull *pdu_TracingBufferFull;  
                                              /* OMAP1_TracingBufferFull_PDU */
    struct OMAP1_UpdateLocationArea *pdu_UpdateLocationArea;  
                                             /* OMAP1_UpdateLocationArea_PDU */
    struct OMAP1_UpdateLocation *pdu_UpdateLocation;  
                                                 /* OMAP1_UpdateLocation_PDU */
    struct OMAP1_CancelLocation *pdu_CancelLocation;  
                                                 /* OMAP1_CancelLocation_PDU */
    struct OMAP1_DetachIMSI *pdu_DetachIMSI;  /* OMAP1_DetachIMSI_PDU */
    struct OMAP1_AttachIMSI *pdu_AttachIMSI;  /* OMAP1_AttachIMSI_PDU */
    struct OMAP1_DeregisterMobileSubscriber *pdu_DeregisterMobileSubscriber;  
                                        /* OMAP1_DeregisterMobileSubscriber_PDU */
    struct OMAP1_InsertSubscriberData *pdu_InsertSubscriberData;  
                                           /* OMAP1_InsertSubscriberData_PDU */
    struct OMAP1_DeleteSubscriberData *pdu_DeleteSubscriberData;  
                                           /* OMAP1_DeleteSubscriberData_PDU */
    struct OMAP1_SendParameters *pdu_SendParameters;  
                                                 /* OMAP1_SendParameters_PDU */
    struct OMAP1_RegisterSS *pdu_RegisterSS;  /* OMAP1_RegisterSS_PDU */
    struct OMAP1_EraseSS *pdu_EraseSS;  /* OMAP1_EraseSS_PDU */
    struct OMAP1_ActivateSS *pdu_ActivateSS;  /* OMAP1_ActivateSS_PDU */
    struct OMAP1_DeactivateSS *pdu_DeactivateSS;  /* OMAP1_DeactivateSS_PDU */
    struct OMAP1_InterrogateSS *pdu_InterrogateSS;  
                                                  /* OMAP1_InterrogateSS_PDU */
    struct OMAP1_InvokeSS *pdu_InvokeSS;  /* OMAP1_InvokeSS_PDU */
    struct OMAP1_ForwardSsNotification *pdu_ForwardSsNotification;  
                                          /* OMAP1_ForwardSsNotification_PDU */
    struct OMAP1_RegisterPassword *pdu_RegisterPassword;  
                                               /* OMAP1_RegisterPassword_PDU */
    struct OMAP1_GetPassword *pdu_GetPassword;  /* OMAP1_GetPassword_PDU */
    struct OMAP1_ProcessUnstructuredSsData *pdu_ProcessUnstructuredSsData;  
                                        /* OMAP1_ProcessUnstructuredSsData_PDU */
    struct OMAP1_SendInfoForIncomingCall *pdu_SendInfoForIncomingCall;  
                                        /* OMAP1_SendInfoForIncomingCall_PDU */
    struct OMAP1_SendInfoForOutgoingCall *pdu_SendInfoForOutgoingCall;  
                                        /* OMAP1_SendInfoForOutgoingCall_PDU */
    struct OMAP1_SendRoutingInformation *pdu_SendRoutingInformation;  
                                         /* OMAP1_SendRoutingInformation_PDU */
    struct OMAP1_ProvideRoamingNumber *pdu_ProvideRoamingNumber;  
                                           /* OMAP1_ProvideRoamingNumber_PDU */
    struct OMAP1_CompleteCall *pdu_CompleteCall;  /* OMAP1_CompleteCall_PDU */
    struct OMAP1_ConnectToFollowingAddress *pdu_ConnectToFollowingAddress;  
                                        /* OMAP1_ConnectToFollowingAddress_PDU */
    struct OMAP1_ProcessCallWaiting *pdu_ProcessCallWaiting;  
                                             /* OMAP1_ProcessCallWaiting_PDU */
    struct OMAP1_Page *pdu_Page;  /* OMAP1_Page_PDU */
    struct OMAP1_SearchForMobileSubscriber *pdu_SearchForMobileSubscriber;  
                                        /* OMAP1_SearchForMobileSubscriber_PDU */
    struct OMAP1_PerformHandover *pdu_PerformHandover;  
                                                /* OMAP1_PerformHandover_PDU */
    struct OMAP1_SendEndSignal *pdu_SendEndSignal;  
                                                  /* OMAP1_SendEndSignal_PDU */
    struct OMAP1_PerformSubsequentHandover *pdu_PerformSubsequentHandover;  
                                        /* OMAP1_PerformSubsequentHandover_PDU */
    struct OMAP1_AllocateHandoverNumber *pdu_AllocateHandoverNumber;  
                                         /* OMAP1_AllocateHandoverNumber_PDU */
    struct OMAP1_SendHandoverReport *pdu_SendHandoverReport;  
                                             /* OMAP1_SendHandoverReport_PDU */
    struct OMAP1_ProcessAccessSignalling *pdu_ProcessAccessSignalling;  
                                        /* OMAP1_ProcessAccessSignalling_PDU */
    struct OMAP1_ForwardAccessSignalling *pdu_ForwardAccessSignalling;  
                                        /* OMAP1_ForwardAccessSignalling_PDU */
    struct OMAP1_RegisterChargingInformation *pdu_RegisterChargingInformation;                                          /* OMAP1_RegisterChargingInformation_PDU */
    struct OMAP1_Reset *pdu_Reset;  /* OMAP1_Reset_PDU */
    struct OMAP1_ForwardCheckSsIndication *pdu_ForwardCheckSsIndication;  
                                        /* OMAP1_ForwardCheckSsIndication_PDU */
    struct OMAP1_ActivateTraceMode *pdu_ActivateTraceMode;  
                                              /* OMAP1_ActivateTraceMode_PDU */
    struct OMAP1_DeactivateTraceMode *pdu_DeactivateTraceMode;  
                                            /* OMAP1_DeactivateTraceMode_PDU */
    struct OMAP1_TraceSubscriberActivity *pdu_TraceSubscriberActivity;  
                                        /* OMAP1_TraceSubscriberActivity_PDU */
    struct OMAP1_NoteInternalHandover *pdu_NoteInternalHandover;  
                                           /* OMAP1_NoteInternalHandover_PDU */
    struct OMAP1_CheckIMEI *pdu_CheckIMEI;  /* OMAP1_CheckIMEI_PDU */
    struct OMAP1_Authenticate *pdu_Authenticate;  /* OMAP1_Authenticate_PDU */
    struct OMAP1_ProvideIMSI *pdu_ProvideIMSI;  /* OMAP1_ProvideIMSI_PDU */
    struct OMAP1_ForwardNewTMSI *pdu_ForwardNewTMSI;  
                                                 /* OMAP1_ForwardNewTMSI_PDU */
    struct OMAP1_SetCipheringMode *pdu_SetCipheringMode;  
                                               /* OMAP1_SetCipheringMode_PDU */
    struct OMAP1_SendRoutingInfoForSM *pdu_SendRoutingInfoForSM;  
                                           /* OMAP1_SendRoutingInfoForSM_PDU */
    struct OMAP1_ForwardShortMessage *pdu_ForwardShortMessage;  
                                            /* OMAP1_ForwardShortMessage_PDU */
    struct OMAP1_SetMessageWaitingData *pdu_SetMessageWaitingData;  
                                          /* OMAP1_SetMessageWaitingData_PDU */
    struct OMAP1_NoteMSPresent *pdu_NoteMSPresent;  
                                                  /* OMAP1_NoteMSPresent_PDU */
    struct OMAP1_AlertServiceCentre *pdu_AlertServiceCentre;  
                                             /* OMAP1_AlertServiceCentre_PDU */
    struct OMAP1_ProcessAccessRequest *pdu_ProcessAccessRequest;  
                                           /* OMAP1_ProcessAccessRequest_PDU */
    struct OMAP1_BeginSubscriberActivity *pdu_BeginSubscriberActivity;  
                                        /* OMAP1_BeginSubscriberActivity_PDU */
};

enum OMAP1_ExtensionSet_ExtensionType_PDUs {
    OMAP1_PDU_ExtensionSet_ExtensionType_UNKNOWN = 0,
    OMAP1_PDU_ExtensionSet_ExtensionType_MAX = INT_MAX
};

union OMAP1_ExtensionSet_ExtensionType_union {
    OMAP1_All_PDU_Types_union other;  /* for known extensions */
};

typedef struct OMAP1_ExtensionSet_ExtensionType {
    OMAP1_ExtensionSet_ExtensionType_PDUs pduNum;
    OssBuf          encoded;
    OMAP1_ExtensionSet_ExtensionType_union decoded;
} OMAP1_ExtensionSet_ExtensionType;

typedef struct OMAP1_PrivateExtension {
    unsigned char   bit_mask;
#       define      OMAP1_extType_present 0x80
    struct OMAP1__ObjectID_ *extId;
    OMAP1_ExtensionSet_ExtensionType extType;  /* optional; set in bit_mask
                                                * OMAP1_extType_present if
                                                * present */
} OMAP1_PrivateExtension;

typedef struct OMAP1_PrivateExtensionList {
    unsigned short  count;
    OMAP1_PrivateExtension value[10];
} OMAP1_PrivateExtensionList;

	// Unsupported private extensions shall be discarded if received.
typedef struct OMAP1_PCS_Extensions {
    char            placeholder;
} OMAP1_PCS_Extensions;

	// The length of the Object Identifier shall not exceed 16 octets and the
	// number of components of the Object Identifier shall not exceed 16
// data types
typedef struct OMAP1_ExtensionContainer {
    unsigned char   bit_mask;
#       define      OMAP1_privateExtensionList_present 0x80
#       define      OMAP1_pcs_Extensions_present 0x40
    OMAP1_PrivateExtensionList privateExtensionList;  /* optional; set in
                                   * bit_mask OMAP1_privateExtensionList_present
                                   * if present */
    OMAP1_PCS_Extensions pcs_Extensions;  /* optional; set in bit_mask
                                           * OMAP1_pcs_Extensions_present if
                                           * present */
} OMAP1_ExtensionContainer;

		// digits 0 through 9, two digits per octet,
		// each digit encoded 0000 to 1001,
		// 1111 used as filler when there is an odd number of digit.
typedef struct OMAP1_AddressString {
    unsigned short  length;
    unsigned char   value[20];
} OMAP1_AddressString;

		// see internal description in section 6.4.1
typedef struct OMAP1_IsdnAddressString {
    unsigned short  length;
    unsigned char   value[9];
} OMAP1_IsdnAddressString;

typedef enum OMAP1_ProtocolId {
    OMAP1_gsm_0408 = 1,
    OMAP1_gsm_0806 = 2,
    OMAP1_gsm_0808_bssmap = 3,
    OMAP1_ets300102_1 = 4
} OMAP1_ProtocolId;

typedef struct OMAP1_SignalInfo {
    unsigned short  length;
    unsigned char   value[200];
} OMAP1_SignalInfo;

typedef struct OMAP1_ExternalSignalInfo {
    OMAP1_ProtocolId protocolId;
    OMAP1_SignalInfo signalInfo;
} OMAP1_ExternalSignalInfo;

// data types for numbering and identification
typedef struct OMAP1_IMSI {
    unsigned short  length;
    unsigned char   value[8];
} OMAP1_IMSI;

		// MCC, MNC, MSIN concatenated in this order
typedef struct OMAP1_TMSI {
    unsigned short  length;
    unsigned char   value[4];
} OMAP1_TMSI;

typedef struct OMAP1_SubscriberId {
    unsigned short  choice;
#       define      OMAP1_SubscriberId_imsi_chosen 1
#       define      OMAP1_tmsi_chosen 2
    union _union {
        OMAP1_IMSI      imsi;  /* to choose, set choice to
                                * OMAP1_SubscriberId_imsi_chosen */
        OMAP1_TMSI      tmsi;  /* to choose, set choice to OMAP1_tmsi_chosen */
    } u;
} OMAP1_SubscriberId;

//
typedef struct OMAP1_IMEI {
    unsigned short  length;
    unsigned char   value[8];
} OMAP1_IMEI;

		// Internal Structure
		// Type Approval Code : 6 digits
		// manufacturer place : 2 digits
		// individual serial number : 6 digits
		// unassigned : 1 digit
typedef struct OMAP1_LocAreaId {
    unsigned short  length;
    unsigned char   value[5];
} OMAP1_LocAreaId;

		// Octets coded according to
		// Recommendation GSM 04.08
		// Internal structure
		// Mobile Country Code	: 3 digits according to Rec E.212
		//		: 1 filler (1111)
		// Mobile Network Code	: 2 digits according to Rec E.212
		// Location Area Code	: 2 octets according to GSM 04.08
typedef struct OMAP1_LocationInfo {
    unsigned short  choice;
#       define      OMAP1_LocationInfo_roamingNumber_chosen 1
#       define      OMAP1_mscNumber_chosen 2
    union _union {
        OMAP1_IsdnAddressString roamingNumber;  /* to choose, set choice to
                                   * OMAP1_LocationInfo_roamingNumber_chosen */
        OMAP1_IsdnAddressString mscNumber;  /* to choose, set choice to
                                             * OMAP1_mscNumber_chosen */
    } u;
} OMAP1_LocationInfo;

typedef OMAP1_IMSI      OMAP1_HlrId;

		// leading digits of IMSI
typedef struct OMAP1_HlrList {
    unsigned short  count;
    OMAP1_HlrId     value[50];
} OMAP1_HlrList;

typedef struct OMAP1_LMSI {
    unsigned short  length;
    unsigned char   value[4];
} OMAP1_LMSI;

typedef struct OMAP1_GlobalCellId {
    unsigned short  length;
    unsigned char   value[7];
} OMAP1_GlobalCellId;

		// Octets coded according to
		// Recommendation GSM 04.08
		// Internal structure
		// Mobile Country Code	: 3 digits according to Rec E.212
		//		: 1 filler (1111)
		// Mobile Network Code	: 2 digits according to Rec E.212
		// Location Area Code	: 2 octets (LAC) according 
		// to GSM 04.08
		// Cell identity	: 2 octets (CI) according to GSM 04.08

// data types for subscriber management

//
typedef struct OMAP1_Category {
    unsigned short  length;
    unsigned char   value[1];
} OMAP1_Category;

		// internal structure defined in CCITT Rec Q.763
typedef enum OMAP1_EquipStatus {
    OMAP1_white_listed = 0,
    OMAP1_black_listed = 1,
    OMAP1_grey_listed = 2
} OMAP1_EquipStatus;

typedef struct OMAP1_BearerServiceCode {
    unsigned short  length;
    unsigned char   value[1];
} OMAP1_BearerServiceCode;

		// Internal structure according to table 6.4/1
		// BIT 8 Transparency indicator (if applicable)
		//     0 transparent
		//     1 non transparent

		// BIT 7654  Bearer service group
		//    0001 3.1 kHz ex PLMN
		//    0010 Circuit data asynchronous
		//    0011 Circuit data synchronous
		//    0100 PAD access c.d.a
		//    0101 Packet data synchrounous
		//    0110 Alternate speech/c.d.a
		//    0111 Alternate speech c.d.s
		//    1000 Speech followed by data c.d.a
		//    1001 Speech followed by data c.d.s
		//    1111 12.6 kb/s unrestricted digital

		// BIT 321  Rate (when applicable)
		//    000 Any
		//    001 300-300 b/s
		//    010 1200-1200 b/s
		//    011 1200-75 b/s
		//    100 2400-2400 b/s
		//    101 4800-4800 b/s
		//    110 9600-9600 b/s

		// Bits 321 = 000 can be used to refer to all
		// the bearer services of the corresponding group.
		// Value "00000000" can be used to refer to all the defined
		// bearer services.
		// For the codes referring to a group or all bearer services
		// the Transparency Indicator is not applicable and has to be set to "0"
typedef struct OMAP1_BearerServiceList {
    unsigned short  count;
    OMAP1_BearerServiceCode value[50];
} OMAP1_BearerServiceList;

typedef struct OMAP1_TeleserviceCode {
    unsigned short  length;
    unsigned char   value[1];
} OMAP1_TeleserviceCode;

		// Internal structure according to table 6.4/2
		// Bit 8-5 encode the teleservice group

		// Bit 4-1 = 0000 can be used to refer to all the
		// teleservices of the corresponding group.
		// Value "00000000" can be used to refer to all the defined
		// teleservices
typedef struct OMAP1_TeleserviceList {
    unsigned short  count;
    OMAP1_TeleserviceCode value[20];
} OMAP1_TeleserviceList;

typedef struct OMAP1_BasicServiceCode {
    unsigned short  choice;
#       define      OMAP1_bearerService_chosen 1
#       define      OMAP1_teleservice_chosen 2
    union _union {
        OMAP1_BearerServiceCode bearerService;  /* to choose, set choice to
                                                * OMAP1_bearerService_chosen */
        OMAP1_TeleserviceCode teleservice;  /* to choose, set choice to
                                             * OMAP1_teleservice_chosen */
    } u;
} OMAP1_BasicServiceCode;

typedef struct OMAP1_BasicServiceList {
    unsigned short  count;
    OMAP1_BasicServiceCode value[70];
} OMAP1_BasicServiceList;

//
typedef enum OMAP1_SubscriberStatus {
    OMAP1_serviceGranted = 0,
    OMAP1_operatorOGCallBarring = 1
} OMAP1_SubscriberStatus;

typedef struct OMAP1_SS_Code {
    unsigned short  length;
    unsigned char   value[1];
} OMAP1_SS_Code;

		// Internal structure according to
		// table 6.4/3
		// Bit 8-5
		// 0001 Number Identification services
		// 0010 Forwarding services
		// 0011 Call offering services
		// 0100 Call completion services
		// 0101 Multi-party services
		// 0110 Community of interest services
		// 0111 Charging services
		// 1000 Additional information transfer services
		// 1001 Call restriction services
		// Bit 4-1 = 0000 can be use to refer to
		// a group of supplementary services
		// eg, "00100000" can be used to refer to all
		// forwarding services
		// "00101000" can be used to refer to all
		// conditional forwarding services
		// "00000000" can be used to refer to all
		// supplementary services
typedef struct OMAP1_SS_CodeList {
    unsigned short  count;
    OMAP1_SS_Code   value[30];
} OMAP1_SS_CodeList;

typedef struct OMAP1_SS_Status {
    unsigned short  length;
    unsigned char   value[1];
} OMAP1_SS_Status;

typedef struct OMAP1_ForwardingOptions {
    unsigned short  length;
    unsigned char   value[1];
} OMAP1_ForwardingOptions;

typedef unsigned short  OMAP1_NoReplyConditionTime;

typedef struct OMAP1_ForwardingFeature {
    unsigned char   bit_mask;
#       define      OMAP1_ForwardingFeature_basicService_present 0x80
#       define      OMAP1_ForwardingFeature_forwardedToNumber_present 0x40
#       define      OMAP1_ForwardingFeature_forwardingOptions_present 0x20
#       define      OMAP1_ForwardingFeature_noReplyConditionTime_present 0x10
    OMAP1_BasicServiceCode basicService;  /* optional; set in bit_mask
                              * OMAP1_ForwardingFeature_basicService_present if
                              * present */
    OMAP1_SS_Status ss_Status;
    OMAP1_IsdnAddressString forwardedToNumber;  /* optional; set in bit_mask
                         * OMAP1_ForwardingFeature_forwardedToNumber_present if
                         * present */
    OMAP1_ForwardingOptions forwardingOptions;  /* optional; set in bit_mask
                         * OMAP1_ForwardingFeature_forwardingOptions_present if
                         * present */
    OMAP1_NoReplyConditionTime noReplyConditionTime;  /* optional; set in
                                   * bit_mask
                      * OMAP1_ForwardingFeature_noReplyConditionTime_present if
                      * present */
} OMAP1_ForwardingFeature;

typedef struct OMAP1_ForwardingFeatureList {
    unsigned short  count;
    OMAP1_ForwardingFeature value[13];
} OMAP1_ForwardingFeatureList;

   // bits 876543: 000000 (unused)

   // bits 21
   // 00  CUG only facilities
   // 01  CUG with outgoing access
   // 10  CUG with incoming access
   // 11  CUG with both outgoing and incoming access
typedef struct OMAP1_ForwardingInfo {
    unsigned char   bit_mask;
#       define      OMAP1_ForwardingInfo_ss_Code_present 0x80
    OMAP1_SS_Code   ss_Code;  /* optional; set in bit_mask
                               * OMAP1_ForwardingInfo_ss_Code_present if
                               * present */
    OMAP1_ForwardingFeatureList forwardingFeatureList;
} OMAP1_ForwardingInfo;

typedef struct OMAP1_CallBarringFeature {
    unsigned char   bit_mask;
#       define      OMAP1_basicServiceCode_present 0x80
    OMAP1_BasicServiceCode basicServiceCode;  /* optional; set in bit_mask
                                               * OMAP1_basicServiceCode_present
                                               * if present */
    OMAP1_SS_Status ss_Status;
} OMAP1_CallBarringFeature;

typedef struct OMAP1_CallBarringFeatureList {
    unsigned short  count;
    OMAP1_CallBarringFeature value[13];
} OMAP1_CallBarringFeatureList;

typedef struct OMAP1_CallBarringInfo {
    OMAP1_SS_Code   ss_Code;
    OMAP1_CallBarringFeatureList callBarringFeatureList;
} OMAP1_CallBarringInfo;

typedef unsigned short  OMAP1_CUG_Index;

   // The internal structure is defined in ETS 300 138.
typedef struct OMAP1_CUG_Interlock {
    unsigned short  length;
    unsigned char   value[4];
} OMAP1_CUG_Interlock;

typedef enum OMAP1_IntraCUG_Options {
    OMAP1_noCUG_Restrictions = 0,
    OMAP1_cugIC_CallBarred = 1,
    OMAP1_cugOG_CallBarred = 2
} OMAP1_IntraCUG_Options;

//
typedef struct OMAP1_BasicServiceGroupList {
    unsigned short  count;
    OMAP1_BasicServiceCode value[13];
} OMAP1_BasicServiceGroupList;

typedef struct OMAP1_CUG_Subscription {
    unsigned char   bit_mask;
#       define      OMAP1_basicServiceGroupList_present 0x80
    OMAP1_CUG_Index cug_Index;
    OMAP1_CUG_Interlock cug_Interlock;
    OMAP1_IntraCUG_Options intraCUG_Options;
    OMAP1_BasicServiceGroupList basicServiceGroupList;  /* optional; set in
                                   * bit_mask
                                   * OMAP1_basicServiceGroupList_present if
                                   * present */
} OMAP1_CUG_Subscription;

typedef struct OMAP1_CUG_SubscriptionList {
    unsigned short  count;
    OMAP1_CUG_Subscription value[10];
} OMAP1_CUG_SubscriptionList;

typedef struct OMAP1_InterCUG_Restrictions {
    unsigned short  length;
    unsigned char   value[1];
} OMAP1_InterCUG_Restrictions;

typedef struct OMAP1_CUG_Feature {
    unsigned char   bit_mask;
#       define      OMAP1_CUG_Feature_basicService_present 0x80
#       define      OMAP1_preferentialCUG_Indicator_present 0x40
    OMAP1_BasicServiceCode basicService;  /* optional; set in bit_mask
                                    * OMAP1_CUG_Feature_basicService_present if
                                    * present */
    OMAP1_CUG_Index preferentialCUG_Indicator;  /* optional; set in bit_mask
                                   * OMAP1_preferentialCUG_Indicator_present if
                                   * present */
    OMAP1_InterCUG_Restrictions interCUG_Restrictions;
} OMAP1_CUG_Feature;

typedef struct OMAP1_CUG_FeatureList {
    unsigned short  count;
    OMAP1_CUG_Feature value[13];
} OMAP1_CUG_FeatureList;

typedef struct OMAP1_CUG_Info {
    unsigned char   bit_mask;
#       define      OMAP1_cug_FeatureList_present 0x80
    OMAP1_CUG_SubscriptionList cug_SubscriptionList;
    OMAP1_CUG_FeatureList cug_FeatureList;  /* optional; set in bit_mask
                                             * OMAP1_cug_FeatureList_present if
                                             * present */
} OMAP1_CUG_Info;

	//
typedef struct OMAP1_SS_Data {
    unsigned char   bit_mask;
#       define      OMAP1_SS_Data_ss_Status_present 0x80
    OMAP1_SS_Code   ss_Code;
    OMAP1_SS_Status ss_Status;  /* optional; set in bit_mask
                                 * OMAP1_SS_Data_ss_Status_present if present */
} OMAP1_SS_Data;

		// Bit 8-4 Unused
		// Bit 3   Provision indicator
		//     0 : Not provisioned
		//     1 : Provisioned
		// Bit 2   Registration indicator (if applicable)
		//     0 : Not Registered
		//     1 : Registered
		// Bit 1   Activation indicator (If applicable)
		//     0 : Not Active
		//     1 : Active
typedef struct OMAP1_SS_Information {
    unsigned short  choice;
#       define      OMAP1_forwardingInfo_chosen 1
#       define      OMAP1_callBarringInfo_chosen 2
#       define      OMAP1_cug_Info_chosen 3
#       define      OMAP1_ss_Data_chosen 4
    union _union {
        OMAP1_ForwardingInfo forwardingInfo;  /* to choose, set choice to
                                               * OMAP1_forwardingInfo_chosen */
        OMAP1_CallBarringInfo callBarringInfo;  /* to choose, set choice to
                                              * OMAP1_callBarringInfo_chosen */
        OMAP1_CUG_Info  cug_Info;  /* to choose, set choice to
                                    * OMAP1_cug_Info_chosen */
        OMAP1_SS_Data   ss_Data;  /* to choose, set choice to
                                   * OMAP1_ss_Data_chosen */
    } u;
} OMAP1_SS_Information;

typedef struct OMAP1_SS_InfoList {
    unsigned short  count;
    OMAP1_SS_Information value[30];
} OMAP1_SS_InfoList;

typedef struct OMAP1_SS_DataList {
    unsigned short  count;
    OMAP1_SS_Data   value[30];
} OMAP1_SS_DataList;

typedef enum OMAP1_SS_Request {
    OMAP1_registration = 0,
    OMAP1_erasure = 1,
    OMAP1_activation = 2,
    OMAP1_deactivation = 3,
    OMAP1_interrogation = 4,
    OMAP1_invoke = 5
} OMAP1_SS_Request;

		// Bit 8-7  Notification to forwarding party
		//          00  No notification
		//          01  notification with calling number identity
		//          10  notification without calling number identity
		// Bit 6-5  Notification to calling party
		//          00 No notification
		//          01 Notification with forwarded-to number
		//          10 Notification without forwarded-to number
typedef struct OMAP1_UserToUserServiceIndicator {
    unsigned short  length;
    unsigned char   value[1];
} OMAP1_UserToUserServiceIndicator;

		// Bit 8   : service 1
		// Bit 7   : service 2
		// Bit 6   : service 3
		// Bit 5-1 : Reserved
		// Bit 8 to 6 coded "1" if the service
		// is available to the subscriber
typedef unsigned short  OMAP1_MaximumConfereesNumber;

typedef enum OMAP1_HuntGroupAccessSelectionOrder {
    OMAP1_random = 0,
    OMAP1_sequential = 1
} OMAP1_HuntGroupAccessSelectionOrder;

typedef struct OMAP1_SS_SubscriptionOption {
    unsigned short  choice;
#       define      OMAP1_perCallBasis_chosen 1
#       define      OMAP1_notificationToHeldRetrievedParty_chosen 2
#       define      OMAP1_userToUserServiceIndicator_chosen 3
#       define      OMAP1_maximumConfereesNumber_chosen 4
#       define      OMAP1_huntGroupAccessSelectionOrder_chosen 5
    union _union {
        ossBoolean      perCallBasis;  /* to choose, set choice to
                                        * OMAP1_perCallBasis_chosen */
        ossBoolean      notificationToHeldRetrievedParty;  /* to choose, set
                                   * choice to
                             * OMAP1_notificationToHeldRetrievedParty_chosen */
        OMAP1_UserToUserServiceIndicator userToUserServiceIndicator;  /* to
                                   * choose, set choice to
                                   * OMAP1_userToUserServiceIndicator_chosen */
        OMAP1_MaximumConfereesNumber maximumConfereesNumber;  /* to choose, set
                                   * choice to
                                   * OMAP1_maximumConfereesNumber_chosen */
        OMAP1_HuntGroupAccessSelectionOrder huntGroupAccessSelectionOrder;  
                                        /* to choose, set choice to
                                * OMAP1_huntGroupAccessSelectionOrder_chosen */
    } u;
} OMAP1_SS_SubscriptionOption;

typedef unsigned short  OMAP1_NumberOfConferees;

typedef struct OMAP1_ForwardingData {
    unsigned char   bit_mask;
#       define      OMAP1_ForwardingData_forwardingOptions_present 0x80
    OMAP1_IsdnAddressString forwardedToNumber;
    OMAP1_ForwardingOptions forwardingOptions;  /* optional; set in bit_mask
                            * OMAP1_ForwardingData_forwardingOptions_present if
                            * present */
} OMAP1_ForwardingData;

typedef struct OMAP1_SubscriberData {
    unsigned char   bit_mask;
#       define      OMAP1_SubscriberData_msIsdn_present 0x80
#       define      OMAP1_SubscriberData_category_present 0x40
#       define      OMAP1_SubscriberData_subscriberStatus_present 0x20
#       define      OMAP1_SubscriberData_bearerServiceList_present 0x10
#       define      OMAP1_SubscriberData_teleserviceList_present 0x08
#       define      OMAP1_SubscriberData_provisonedSS_present 0x04
    OMAP1_IsdnAddressString msIsdn;  /* optional; set in bit_mask
                                      * OMAP1_SubscriberData_msIsdn_present if
                                      * present */
    OMAP1_Category  category;  /* optional; set in bit_mask
                                * OMAP1_SubscriberData_category_present if
                                * present */
    OMAP1_SubscriberStatus subscriberStatus;  /* optional; set in bit_mask
                             * OMAP1_SubscriberData_subscriberStatus_present if
                             * present */
    OMAP1_BearerServiceList bearerServiceList;  /* optional; set in bit_mask
                            * OMAP1_SubscriberData_bearerServiceList_present if
                            * present */
    OMAP1_TeleserviceList teleserviceList;  /* optional; set in bit_mask
                              * OMAP1_SubscriberData_teleserviceList_present if
                              * present */
    OMAP1_SS_InfoList provisonedSS;  /* optional; set in bit_mask
                                 * OMAP1_SubscriberData_provisonedSS_present if
                                 * present */
} OMAP1_SubscriberData;

typedef struct OMAP1_SS_Notification {
    unsigned short  length;
    unsigned char   value[1];
} OMAP1_SS_Notification;

typedef enum OMAP1_GuidanceInfo {
    OMAP1_enterPW = 0,
    OMAP1_enterNewPW = 1,
    OMAP1_enterNewPW_Again = 2,
    OMAP1_badPW_TryAgain = 3,
    OMAP1_badPW_FormatTryAgain = 4
} OMAP1_GuidanceInfo;

// Data types for call parameters
typedef struct OMAP1_CallReference {
    unsigned short  length;
    unsigned char   value[3];
} OMAP1_CallReference;

typedef enum OMAP1_CallType {
    OMAP1_incomingCall = 0,
    OMAP1_forwardedCallPortion = 1,
    OMAP1_reroutedCallPortion = 2,
    OMAP1_outgoingCall = 3,
    OMAP1_ss_Request = 4
} OMAP1_CallType;

typedef unsigned int    OMAP1_Charge;

typedef struct OMAP1_SS_ChargingData {
    unsigned char   bit_mask;
#       define      OMAP1_SS_ChargingData_charge_present 0x80
    OMAP1_SS_Code   ss_Code;
    OMAP1_SS_Request ss_Request;
    OMAP1_Charge    charge;  /* optional; set in bit_mask
                              * OMAP1_SS_ChargingData_charge_present if
                              * present */
} OMAP1_SS_ChargingData;

typedef struct OMAP1_SS_ChargingInfo {
    unsigned short  count;
    OMAP1_SS_ChargingData value[30];
} OMAP1_SS_ChargingInfo;

typedef unsigned int    OMAP1_CallDuration;

typedef struct OMAP1_CallDateTime {
    unsigned short  length;
    unsigned char   value[24];
} OMAP1_CallDateTime;

		// local time and time differential
		// to UTC time
typedef unsigned short  OMAP1_PacketDataVolume;

typedef enum OMAP1_ChargingUnit {
    OMAP1_specialDrawingRights = 0
} OMAP1_ChargingUnit;

typedef enum OMAP1_CallStatus {
    OMAP1_CallStatus_undetermined = 0,
    OMAP1_successfulNormalTermination = 1,
    OMAP1_successfulAbnormalTermination = 2,
    OMAP1_forwarded = 4,
    OMAP1_forwardedWithAbnormalTermination = 5,
    OMAP1_rerouted = 6,
    OMAP1_reroutedWithAbnormalTermination = 7,
    OMAP1_unsuccessfulNoRadioContact = 8,
    OMAP1_unsuccessfulNoResponse = 9,
    OMAP1_unsuccessfulBusySubscriber = 10,
    OMAP1_unsuccessfulSystemFailed = 11,
    OMAP1_unsuccessfulSusbcriptionViolation = 12,
    OMAP1_unsuccessfulUnsupportedFacility = 13
} OMAP1_CallStatus;

		// Data types for radio parameters
typedef unsigned short  OMAP1_NumberOfForwarding;

typedef struct OMAP1_ChannelType {
    unsigned short  length;
    unsigned char   value[10];
} OMAP1_ChannelType;

		// Concatenation of
		// Speech data indicator
		// Channel rate
		// Speech encoding algorithm/data rate
		// + transparency indicator
		// as defined in Recommendation GSM 08.08
typedef struct OMAP1_ClassmarkInformation {
    unsigned short  length;
    unsigned char   value[2];
} OMAP1_ClassmarkInformation;

		// classmark information element type 1 or 2
		// contents as defined in Recommendation 08.08
typedef struct OMAP1_HandoverPriority {
    unsigned short  length;
    unsigned char   value[1];
} OMAP1_HandoverPriority;

		// internal structure defined in Recommendation GSM 08.08
typedef enum OMAP1_HandoverType {
    OMAP1_interBSS = 0,
    OMAP1_intraBSS = 1
} OMAP1_HandoverType;

typedef struct OMAP1_Rand {
    unsigned short  length;
    unsigned char   value[16];
} OMAP1_Rand;

typedef struct OMAP1_Sres {
    unsigned short  length;
    unsigned char   value[4];
} OMAP1_Sres;

typedef struct OMAP1_Kc {
    unsigned short  length;
    unsigned char   value[8];
} OMAP1_Kc;

// Data types for security procedures
typedef struct OMAP1_AuthenticationSet {
    OMAP1_Rand      rand;
    OMAP1_Sres      sres;
    OMAP1_Kc        kc;
} OMAP1_AuthenticationSet;

typedef struct OMAP1_Ki {
    unsigned short  length;
    unsigned char   value[16];
} OMAP1_Ki;

typedef struct OMAP1_CKSN {
    unsigned short  length;
    unsigned char   value[1];
} OMAP1_CKSN;

		// bits 8-4 unused
		// bits 3-1 coded as specified in recommendation GSM 04.08
typedef enum OMAP1_CipheringMode {
    OMAP1_noEncryption = 1,
    OMAP1_version1_GSM = 2
} OMAP1_CipheringMode;

// Data types for short message services
typedef struct OMAP1_SM_RP_DA {
    unsigned short  choice;
#       define      OMAP1_SM_RP_DA_imsi_chosen 1
#       define      OMAP1_lmsi_chosen 2
#       define      OMAP1_SM_RP_DA_roamingNumber_chosen 3
#       define      OMAP1_SM_RP_DA_serviceCentreAddress_chosen 4
    union _union {
        OMAP1_IMSI      imsi;  /* to choose, set choice to
                                * OMAP1_SM_RP_DA_imsi_chosen */
        OMAP1_LMSI      lmsi;  /* to choose, set choice to OMAP1_lmsi_chosen */
        OMAP1_IsdnAddressString roamingNumber;  /* to choose, set choice to
                                       * OMAP1_SM_RP_DA_roamingNumber_chosen */
        OMAP1_AddressString serviceCentreAddress;  /* to choose, set choice to
                                * OMAP1_SM_RP_DA_serviceCentreAddress_chosen */
    } u;
} OMAP1_SM_RP_DA;

typedef struct OMAP1_SM_RP_OA {
    unsigned short  choice;
#       define      OMAP1_msIsdn_chosen 1
#       define      OMAP1_SM_RP_OA_serviceCentreAddress_chosen 2
    union _union {
        OMAP1_IsdnAddressString msIsdn;  /* to choose, set choice to
                                          * OMAP1_msIsdn_chosen */
        OMAP1_AddressString serviceCentreAddress;  /* to choose, set choice to
                                * OMAP1_SM_RP_OA_serviceCentreAddress_chosen */
    } u;
} OMAP1_SM_RP_OA;

typedef struct OMAP1_SM_RP_UI {
    unsigned short  length;
    unsigned char   value[200];
} OMAP1_SM_RP_UI;

// fault recovery, call tracing
typedef struct OMAP1_TraceReference {
    unsigned short  length;
    unsigned char   value[2];
} OMAP1_TraceReference;

typedef unsigned short  OMAP1_TraceType;
#define                     OMAP1_allEvents 0U
#define                     OMAP1_onlyCalls 1U
#define                     OMAP1_eventSet1 2U
#define                     OMAP1_eventSet254 255U

		// Identifiers eventSet1 to eventSet254 corresponds to
		// sets of events pre-defined by each operator.
typedef enum OMAP1_NetworkResource {
    OMAP1_pLMN = 0,
    OMAP1_hLR = 1,
    OMAP1_vLR = 2,
    OMAP1_previous_VLR = 3,
    OMAP1_controlling_MSC = 4,
    OMAP1_vMSC = 5,
    OMAP1_eIR = 6,
    OMAP1_radioSubSystem = 7
} OMAP1_NetworkResource;

// other data types
typedef enum OMAP1_RequestParameter {
    OMAP1_request_IMSI = 0,
    OMAP1_request_AuthenticationSet = 1,
    OMAP1_request_SubscriberData = 2,
    OMAP1_request_CUG_Information = 3,
    OMAP1_request_Ki = 4
} OMAP1_RequestParameter;

typedef struct OMAP1_RequestParameters {
    unsigned short  count;
    OMAP1_RequestParameter value[2];
} OMAP1_RequestParameters;

typedef struct OMAP1_SentParameter {
    unsigned short  choice;
#       define      OMAP1_SentParameter_imsi_chosen 1
#       define      OMAP1_authenticationSet_chosen 2
#       define      OMAP1_susbcriberData_chosen 3
#       define      OMAP1_cug_information_chosen 4
#       define      OMAP1_ki_chosen 5
    union _union {
        OMAP1_IMSI      imsi;  /* to choose, set choice to
                                * OMAP1_SentParameter_imsi_chosen */
        OMAP1_AuthenticationSet authenticationSet;  /* to choose, set choice to
                                            * OMAP1_authenticationSet_chosen */
        OMAP1_SubscriberData susbcriberData;  /* to choose, set choice to
                                               * OMAP1_susbcriberData_chosen */
        OMAP1_CUG_Info  cug_information;  /* to choose, set choice to
                                           * OMAP1_cug_information_chosen */
        OMAP1_Ki        ki;  /* to choose, set choice to OMAP1_ki_chosen */
    } u;
} OMAP1_SentParameter;

typedef struct OMAP1_SentParameters {
    unsigned short  count;
    OMAP1_SentParameter value[6];
} OMAP1_SentParameters;

typedef enum OMAP1_CmServiceType {
    OMAP1_mobileOriginatingCall = 1,
    OMAP1_emergencyCallEstablishment = 2,
    OMAP1_shortMessageService = 4,
    OMAP1_ss_request = 8,
    OMAP1_mobileOriginatingCallRe_establishment = 9,
    OMAP1_mobileTerminatingCall = 10
} OMAP1_CmServiceType;

//
typedef struct OMAP1_AccessConnectionStatus {
    unsigned short  length;
    unsigned char   value[1];
} OMAP1_AccessConnectionStatus;
		// Bit 8-4 Reserved
		// Bit 3
		//     0 No RR- connection
		//     1 RR-connection established
		// Bit 2
		//     0 Ciphering mode off
		//     1 Ciphering mode on
		// Bit 1
		//     0 MM-connection existing and authenticated
		//     1 MM-connection existing and not authenticated

typedef struct OMAP1__choice6 {
    unsigned short  choice;
#       define      OMAP1_locAreaId_chosen 1
#       define      OMAP1_null_chosen 2
    union _union {
        OMAP1_LocAreaId locAreaId;  /* to choose, set choice to
                                     * OMAP1_locAreaId_chosen */
        Nulltype        null;  /* to choose, set choice to OMAP1_null_chosen */
    } u;
} OMAP1__choice6;

typedef struct OMAP1_UpdateLocationAreaArg {
    OMAP1_SubscriberId subscriberId;
    OMAP1__choice6  previousLocAreaId;
    OMAP1_LocAreaId targetLocAreaId;
    OMAP1_CKSN      cksn;
} OMAP1_UpdateLocationAreaArg;

typedef struct OMAP1_UpdateLocationArg {
    unsigned char   bit_mask;
#       define      OMAP1_UpdateLocationArg_lmsi_present 0x80
    OMAP1_IMSI      imsi;
    OMAP1_LocationInfo locationInfo;
    OMAP1_IsdnAddressString vlrNumber;
    OMAP1_LMSI      lmsi;  /* optional; set in bit_mask
                            * OMAP1_UpdateLocationArg_lmsi_present if present */
} OMAP1_UpdateLocationArg;

// UpdateLocationRes ::= SEQUENCE {
// hlrNumber		IsdnAddressString}
typedef OMAP1_IsdnAddressString OMAP1_UpdateLocationRes;

//CancelLocationArg	::= IMSI
typedef struct OMAP1_IMSI_WithLMSI {
    OMAP1_IMSI      imsi;
    OMAP1_LMSI      lmsi;
      // a special value 00000000 indicates that the LMSI is not in use
} OMAP1_IMSI_WithLMSI;

typedef struct OMAP1_CancelLocationArg {
    unsigned short  choice;
#       define      OMAP1_CancelLocationArg_imsi_chosen 1
#       define      OMAP1_imsi_WithLMSI_chosen 2
    union _union {
        OMAP1_IMSI      imsi;  /* to choose, set choice to
                                * OMAP1_CancelLocationArg_imsi_chosen */
        OMAP1_IMSI_WithLMSI imsi_WithLMSI;  /* to choose, set choice to
                                             * OMAP1_imsi_WithLMSI_chosen */
    } u;
} OMAP1_CancelLocationArg;

typedef struct OMAP1_DetachIMSIArg {
    OMAP1_SubscriberId subscriberId;
} OMAP1_DetachIMSIArg;

typedef struct OMAP1_AttachIMSIArg {
    OMAP1_SubscriberId subscriberId;
} OMAP1_AttachIMSIArg;

typedef struct OMAP1_DeregisterMobileSubscriberArg {
    OMAP1_IMSI      imsi;
} OMAP1_DeregisterMobileSubscriberArg;

typedef struct OMAP1_InsertSubscriberDataArg {
    unsigned char   bit_mask;
#       define      OMAP1_InsertSubscriberDataArg_imsi_present 0x80
#       define      OMAP1_InsertSubscriberDataArg_msIsdn_present 0x40
#       define      OMAP1_InsertSubscriberDataArg_category_present 0x20
#       define      OMAP1_InsertSubscriberDataArg_subscriberStatus_present 0x10
#       define      OMAP1_InsertSubscriberDataArg_bearerServiceList_present 0x08
#       define      OMAP1_InsertSubscriberDataArg_teleserviceList_present 0x04
#       define      OMAP1_InsertSubscriberDataArg_provisonedSS_present 0x02
    OMAP1_IMSI      imsi;  /* optional; set in bit_mask
                            * OMAP1_InsertSubscriberDataArg_imsi_present if
                            * present */
    OMAP1_IsdnAddressString msIsdn;  /* optional; set in bit_mask
                              * OMAP1_InsertSubscriberDataArg_msIsdn_present if
                              * present */
    OMAP1_Category  category;  /* optional; set in bit_mask
                                * OMAP1_InsertSubscriberDataArg_category_present
                                * if present */
    OMAP1_SubscriberStatus subscriberStatus;  /* optional; set in bit_mask
                    * OMAP1_InsertSubscriberDataArg_subscriberStatus_present if
                    * present */
    OMAP1_BearerServiceList bearerServiceList;  /* optional; set in bit_mask
                   * OMAP1_InsertSubscriberDataArg_bearerServiceList_present if
                   * present */
    OMAP1_TeleserviceList teleserviceList;  /* optional; set in bit_mask
                     * OMAP1_InsertSubscriberDataArg_teleserviceList_present if
                     * present */
    OMAP1_SS_InfoList provisonedSS;  /* optional; set in bit_mask
                        * OMAP1_InsertSubscriberDataArg_provisonedSS_present if
                        * present */
} OMAP1_InsertSubscriberDataArg;

typedef struct OMAP1_DeleteSubscriberDataArg {
    unsigned char   bit_mask;
#       define      OMAP1_DeleteSubscriberDataArg_basicService_present 0x80
#       define      OMAP1_DeleteSubscriberDataArg_ss_Code_present 0x40
    OMAP1_IMSI      imsi;
    OMAP1_BasicServiceList basicService;  /* optional; set in bit_mask
                        * OMAP1_DeleteSubscriberDataArg_basicService_present if
                        * present */
    OMAP1_SS_CodeList ss_Code;  /* optional; set in bit_mask
                                 * OMAP1_DeleteSubscriberDataArg_ss_Code_present
                                 * if present */
} OMAP1_DeleteSubscriberDataArg;

typedef struct OMAP1_SendParametersArg {
    OMAP1_SubscriberId subscriberId;
    OMAP1_RequestParameters requestParameters;
} OMAP1_SendParametersArg;

typedef struct OMAP1_SendParametersRes {
    OMAP1_SentParameters sentParameters;
} OMAP1_SendParametersRes;

typedef struct OMAP1_RegisterSSArg {
    unsigned char   bit_mask;
#       define      OMAP1_RegisterSSArg_basicService_present 0x80
#       define      OMAP1_RegisterSSArg_forwardedToNumber_present 0x40
#       define      OMAP1_RegisterSSArg_noReplyConditionTime_present 0x20
    OMAP1_SS_Code   ss_Code;
    OMAP1_BasicServiceCode basicService;  /* optional; set in bit_mask
                                  * OMAP1_RegisterSSArg_basicService_present if
                                  * present */
    OMAP1_IsdnAddressString forwardedToNumber;  /* optional; set in bit_mask
                             * OMAP1_RegisterSSArg_forwardedToNumber_present if
                             * present */
    OMAP1_NoReplyConditionTime noReplyConditionTime;  /* optional; set in
                                   * bit_mask
                          * OMAP1_RegisterSSArg_noReplyConditionTime_present if
                          * present */
} OMAP1_RegisterSSArg;

typedef struct OMAP1_RegisterSSRes {
    OMAP1_SS_Information ss_Information;
} OMAP1_RegisterSSRes;

typedef struct OMAP1_EraseSSArg {
    unsigned char   bit_mask;
#       define      OMAP1_EraseSSArg_basicService_present 0x80
    OMAP1_SS_Code   ss_Code;
    OMAP1_BasicServiceCode basicService;  /* optional; set in bit_mask
                                     * OMAP1_EraseSSArg_basicService_present if
                                     * present */
} OMAP1_EraseSSArg;

typedef struct OMAP1_EraseSSRes {
    OMAP1_SS_Information ss_Information;
} OMAP1_EraseSSRes;

typedef struct OMAP1_ActivateSSArg {
    unsigned char   bit_mask;
#       define      OMAP1_ActivateSSArg_basicService_present 0x80
    OMAP1_SS_Code   ss_Code;
    OMAP1_BasicServiceCode basicService;  /* optional; set in bit_mask
                                  * OMAP1_ActivateSSArg_basicService_present if
                                  * present */
} OMAP1_ActivateSSArg;

typedef struct OMAP1_ActivateSSRes {
    OMAP1_SS_Information ss_Information;
} OMAP1_ActivateSSRes;

typedef struct OMAP1_DeactivateSSArg {
    unsigned char   bit_mask;
#       define      OMAP1_DeactivateSSArg_basicService_present 0x80
    OMAP1_SS_Code   ss_Code;
    OMAP1_BasicServiceCode basicService;  /* optional; set in bit_mask
                                * OMAP1_DeactivateSSArg_basicService_present if
                                * present */
} OMAP1_DeactivateSSArg;

typedef struct OMAP1_DeactivateSSRes {
    OMAP1_SS_Information ss_Information;
} OMAP1_DeactivateSSRes;

typedef struct OMAP1_InterrogateSSArg {
    unsigned char   bit_mask;
#       define      OMAP1_InterrogateSSArg_basicService_present 0x80
    OMAP1_SS_Code   ss_Code;
    OMAP1_BasicServiceCode basicService;  /* optional; set in bit_mask
                               * OMAP1_InterrogateSSArg_basicService_present if
                               * present */
} OMAP1_InterrogateSSArg;

typedef struct OMAP1__choice7 {
    unsigned short  choice;
#       define      OMAP1_ss_Status_chosen 1
#       define      OMAP1_forwardedToNumber_chosen 2
#       define      OMAP1_basicServiceGroupList_chosen 3
#       define      OMAP1_forwardingFeatureList_chosen 4
    union _union {
        OMAP1_SS_Status ss_Status;  /* to choose, set choice to
                                     * OMAP1_ss_Status_chosen */
        OMAP1_IsdnAddressString forwardedToNumber;  /* to choose, set choice to
                                            * OMAP1_forwardedToNumber_chosen */
        OMAP1_BasicServiceGroupList basicServiceGroupList;  /* to choose, set
                                   * choice to
                                   * OMAP1_basicServiceGroupList_chosen */
        OMAP1_ForwardingFeatureList forwardingFeatureList;  /* to choose, set
                                   * choice to
                                   * OMAP1_forwardingFeatureList_chosen */
    } u;
} OMAP1__choice7;

typedef struct OMAP1_InterrogateSSRes {
    OMAP1__choice7  choice;
} OMAP1_InterrogateSSRes;

typedef struct OMAP1_InvokeSSArg {
    unsigned char   bit_mask;
#       define      OMAP1_InvokeSSArg_basicService_present 0x80
#       define      OMAP1_userToUserServiceIndicator_present 0x40
#       define      OMAP1_InvokeSSArg_cug_Index_present 0x20
#       define      OMAP1_numberOfConferees_present 0x10
    OMAP1_SS_Code   ss_Code;
    OMAP1_BasicServiceCode basicService;  /* optional; set in bit_mask
                                    * OMAP1_InvokeSSArg_basicService_present if
                                    * present */
    OMAP1_UserToUserServiceIndicator userToUserServiceIndicator;  /* optional;
                                   * set in bit_mask
                                   * OMAP1_userToUserServiceIndicator_present if
                                   * present */
    OMAP1_CUG_Index cug_Index;  /* optional; set in bit_mask
                                 * OMAP1_InvokeSSArg_cug_Index_present if
                                 * present */
    OMAP1_NumberOfConferees numberOfConferees;  /* optional; set in bit_mask
                                           * OMAP1_numberOfConferees_present if
                                           * present */
} OMAP1_InvokeSSArg;

typedef struct OMAP1_InvokeSSRes {
    OMAP1_CUG_Interlock cug_Interlock;
} OMAP1_InvokeSSRes;

typedef struct OMAP1_ForwardSsNotificationArg {
    unsigned char   bit_mask;
#       define      OMAP1_ForwardSsNotificationArg_imsi_present 0x80
#       define      OMAP1_ForwardSsNotificationArg_ss_Code_present 0x40
#       define      OMAP1_ForwardSsNotificationArg_teleservice_present 0x20
#       define      OMAP1_ForwardSsNotificationArg_bearerService_present 0x10
#       define      OMAP1_ForwardSsNotificationArg_ss_Status_present 0x08
#       define      OMAP1_ss_Notification_present 0x04
    OMAP1_IMSI      imsi;  /* optional; set in bit_mask
                            * OMAP1_ForwardSsNotificationArg_imsi_present if
                            * present */
    OMAP1_SS_Code   ss_Code;  /* optional; set in bit_mask
                               * OMAP1_ForwardSsNotificationArg_ss_Code_present
                               * if present */
    OMAP1_TeleserviceCode teleservice;  /* optional; set in bit_mask
                        * OMAP1_ForwardSsNotificationArg_teleservice_present if
                        * present */
    OMAP1_BearerServiceCode bearerService;  /* optional; set in bit_mask
                      * OMAP1_ForwardSsNotificationArg_bearerService_present if
                      * present */
    OMAP1_SS_Status ss_Status;  /* optional; set in bit_mask
                          * OMAP1_ForwardSsNotificationArg_ss_Status_present if
                          * present */
    OMAP1_SS_Notification ss_Notification;  /* optional; set in bit_mask
                                             * OMAP1_ss_Notification_present if
                                             * present */
} OMAP1_ForwardSsNotificationArg;

typedef struct OMAP1_RegisterPasswordArg {
    OMAP1_SS_Code   ss_Code;
} OMAP1_RegisterPasswordArg;

typedef struct OMAP1_GetPasswordArg {
    OMAP1_GuidanceInfo guidanceInfo;
} OMAP1_GetPasswordArg;

typedef struct OMAP1_ProcessUnstructuredSsDataRes {
    OMAP1_SS_UserData ss_UserData;
} OMAP1_ProcessUnstructuredSsDataRes;

typedef struct OMAP1__choice8 {
    unsigned short  choice;
#       define      OMAP1_incomingId_roamingNumber_chosen 1
#       define      OMAP1_incomingId_imsi_chosen 2
    union _union {
        OMAP1_IsdnAddressString roamingNumber;  /* to choose, set choice to
                                     * OMAP1_incomingId_roamingNumber_chosen */
        OMAP1_IMSI      imsi;  /* to choose, set choice to
                                * OMAP1_incomingId_imsi_chosen */
    } u;
} OMAP1__choice8;

typedef struct OMAP1_SendInfoForIncomingCallArg {
    unsigned char   bit_mask;
#       define      OMAP1_SendInfoForIncomingCallArg_bearerService_present 0x80
#       define      OMAP1_SendInfoForIncomingCallArg_teleservice_present 0x40
#       define      OMAP1_SendInfoForIncomingCallArg_lmsi_present 0x20
#       define      OMAP1_dialledNumber_present 0x10
#       define      OMAP1_SendInfoForIncomingCallArg_cug_Interlock_present 0x08
#       define      OMAP1_SendInfoForIncomingCallArg_numberOfForwarding_present 0x04
    OMAP1__choice8  incomingId;
    OMAP1_BearerServiceCode bearerService;  /* optional; set in bit_mask
                    * OMAP1_SendInfoForIncomingCallArg_bearerService_present if
                    * present */
    OMAP1_TeleserviceCode teleservice;  /* optional; set in bit_mask
                      * OMAP1_SendInfoForIncomingCallArg_teleservice_present if
                      * present */
    OMAP1_LMSI      lmsi;  /* optional; set in bit_mask
                            * OMAP1_SendInfoForIncomingCallArg_lmsi_present if
                            * present */
    OMAP1_IsdnAddressString dialledNumber;  /* optional; set in bit_mask
                                             * OMAP1_dialledNumber_present if
                                             * present */
    OMAP1_CUG_Interlock cug_Interlock;  /* optional; set in bit_mask
                    * OMAP1_SendInfoForIncomingCallArg_cug_Interlock_present if
                    * present */
    OMAP1_NumberOfForwarding numberOfForwarding;  /* optional; set in bit_mask
               * OMAP1_SendInfoForIncomingCallArg_numberOfForwarding_present if
               * present */
} OMAP1_SendInfoForIncomingCallArg;

typedef struct OMAP1_SendInfoForOutgoingCallArg {
    unsigned char   bit_mask;
#       define      OMAP1_SendInfoForOutgoingCallArg_bearerService_present 0x80
#       define      OMAP1_teleService_present 0x40
    OMAP1_IsdnAddressString calledNumber;
    OMAP1_BearerServiceCode bearerService;  /* optional; set in bit_mask
                    * OMAP1_SendInfoForOutgoingCallArg_bearerService_present if
                    * present */
    OMAP1_TeleserviceCode teleService;  /* optional; set in bit_mask
                                         * OMAP1_teleService_present if
                                         * present */
} OMAP1_SendInfoForOutgoingCallArg;

typedef struct OMAP1_SendRoutingInformationArg {
    unsigned char   bit_mask;
#       define      OMAP1_SendRoutingInformationArg_cug_Interlock_present 0x80
#       define      OMAP1_SendRoutingInformationArg_numberOfForwarding_present 0x40
#       define      OMAP1_SendRoutingInformationArg_networkSignalInfo_present 0x20
    OMAP1_IsdnAddressString msIsdn;
    OMAP1_CUG_Interlock cug_Interlock;  /* optional; set in bit_mask
                     * OMAP1_SendRoutingInformationArg_cug_Interlock_present if
                     * present */
    OMAP1_NumberOfForwarding numberOfForwarding;  /* optional; set in bit_mask
                * OMAP1_SendRoutingInformationArg_numberOfForwarding_present if
                * present */
    OMAP1_ExternalSignalInfo networkSignalInfo;  /* optional; set in bit_mask
                 * OMAP1_SendRoutingInformationArg_networkSignalInfo_present if
                 * present */
} OMAP1_SendRoutingInformationArg;

typedef struct OMAP1__choice9 {
    unsigned short  choice;
#       define      OMAP1_routingInfo_roamingNumber_chosen 1
#       define      OMAP1_routingInfo_forwardingData_chosen 2
    union _union {
        OMAP1_IsdnAddressString roamingNumber;  /* to choose, set choice to
                                    * OMAP1_routingInfo_roamingNumber_chosen */
        OMAP1_ForwardingData forwardingData;  /* to choose, set choice to
                                   * OMAP1_routingInfo_forwardingData_chosen */
    } u;
} OMAP1__choice9;

typedef struct OMAP1_SendRoutingInformationRes {
    OMAP1_IMSI      imsi;
    OMAP1__choice9  routingInfo;
} OMAP1_SendRoutingInformationRes;

typedef struct OMAP1_ProvideRoamingNumberArg {
    unsigned char   bit_mask;
#       define      OMAP1_mscNumber_present 0x80
#       define      OMAP1_ProvideRoamingNumberArg_msIsdn_present 0x40
#       define      OMAP1_previousRoamingNumber_present 0x20
#       define      OMAP1_ProvideRoamingNumberArg_lmsi_present 0x10
#       define      OMAP1_ProvideRoamingNumberArg_gSM_BearerCapability_present 0x08
#       define      OMAP1_ProvideRoamingNumberArg_networkSignalInfo_present 0x04
    OMAP1_IMSI      imsi;
    OMAP1_IsdnAddressString mscNumber;  /* optional; set in bit_mask
                                         * OMAP1_mscNumber_present if present */
    OMAP1_IsdnAddressString msIsdn;  /* optional; set in bit_mask
                              * OMAP1_ProvideRoamingNumberArg_msIsdn_present if
                              * present */
    OMAP1_IsdnAddressString previousRoamingNumber;  /* optional; set in bit_mask
                                       * OMAP1_previousRoamingNumber_present if
                                       * present */
    OMAP1_LMSI      lmsi;  /* optional; set in bit_mask
                            * OMAP1_ProvideRoamingNumberArg_lmsi_present if
                            * present */
    OMAP1_ExternalSignalInfo gSM_BearerCapability;  /* optional; set in bit_mask
                * OMAP1_ProvideRoamingNumberArg_gSM_BearerCapability_present if
                * present */
    OMAP1_ExternalSignalInfo networkSignalInfo;  /* optional; set in bit_mask
                   * OMAP1_ProvideRoamingNumberArg_networkSignalInfo_present if
                   * present */
} OMAP1_ProvideRoamingNumberArg;

//ProvideRoamingNumberRes	::=	SEQUENCE {
//roamingNumber	IsdnAddressString}
typedef OMAP1_IsdnAddressString OMAP1_ProvideRoamingNumberRes;

typedef struct OMAP1_CompleteCallArg {
    unsigned char   bit_mask;
#       define      OMAP1_CompleteCallArg_category_present 0x80
#       define      OMAP1_CompleteCallArg_cug_Index_present 0x40
#       define      OMAP1_CompleteCallArg_gSM_BearerCapability_present 0x20
#       define      OMAP1_CompleteCallArg_noReplyConditionTime_present 0x10
#       define      OMAP1_ss_DataList_present 0x08
    OMAP1_IsdnAddressString msIsdn;
    OMAP1_Category  category;  /* optional; set in bit_mask
                                * OMAP1_CompleteCallArg_category_present if
                                * present */
    OMAP1_CUG_Index cug_Index;  /* optional; set in bit_mask
                                 * OMAP1_CompleteCallArg_cug_Index_present if
                                 * present */
    OMAP1_ExternalSignalInfo gSM_BearerCapability;  /* optional; set in bit_mask
                        * OMAP1_CompleteCallArg_gSM_BearerCapability_present if
                        * present */
    OMAP1_NoReplyConditionTime noReplyConditionTime;  /* optional; set in
                                   * bit_mask
                        * OMAP1_CompleteCallArg_noReplyConditionTime_present if
                        * present */
    OMAP1_SS_DataList ss_DataList;  /* optional; set in bit_mask
                                     * OMAP1_ss_DataList_present if present */
} OMAP1_CompleteCallArg;

typedef struct OMAP1_ConnectToFollowingAddressArg {
    unsigned char   bit_mask;
#       define      OMAP1_ConnectToFollowingAddressArg_msIsdn_present 0x80
    OMAP1_ForwardingData forwardingData;
    OMAP1_IsdnAddressString msIsdn;  /* optional; set in bit_mask
                         * OMAP1_ConnectToFollowingAddressArg_msIsdn_present if
                         * present */
} OMAP1_ConnectToFollowingAddressArg;

typedef struct OMAP1_PageArg {
    unsigned char   bit_mask;
#       define      OMAP1_tmsi_present 0x80
    OMAP1_IMSI      imsi;
    OMAP1_TMSI      tmsi;  /* optional; set in bit_mask OMAP1_tmsi_present if
                            * present */
    OMAP1_LocAreaId locAreaId;
} OMAP1_PageArg;

typedef struct OMAP1_SearchForMobileSubscriberArg {
    OMAP1_IMSI      imsi;
    OMAP1__choice6  storedLocationArea;
} OMAP1_SearchForMobileSubscriberArg;

typedef struct OMAP1_SearchForMobileSubscriberRes {
    OMAP1_LocAreaId currentLocAreaId;
} OMAP1_SearchForMobileSubscriberRes;

typedef struct OMAP1_PerformHandoverArg {
    unsigned char   bit_mask;
#       define      OMAP1_handoverPriority_present 0x80
#       define      OMAP1_PerformHandoverArg_kc_present 0x40
    OMAP1_GlobalCellId targetCellId;
    OMAP1_GlobalCellId servingCellId;
    OMAP1_ChannelType channelType;
    OMAP1_ClassmarkInformation classmarkInformation;
    OMAP1_HandoverPriority handoverPriority;  /* optional; set in bit_mask
                                               * OMAP1_handoverPriority_present
                                               * if present */
    OMAP1_Kc        kc;  /* optional; set in bit_mask
                          * OMAP1_PerformHandoverArg_kc_present if present */
} OMAP1_PerformHandoverArg;

typedef struct OMAP1_PerformHandoverRes {
    OMAP1_IsdnAddressString handoverNumber;
    OMAP1_ExternalSignalInfo accessSignalInfo;
} OMAP1_PerformHandoverRes;

typedef struct OMAP1_PerformSubsequentHandoverArg {
    unsigned char   bit_mask;
#       define      OMAP1_classmarkInformation_present 0x80
    OMAP1_GlobalCellId targetCellId;
    OMAP1_GlobalCellId servingCellId;
    OMAP1_IsdnAddressString targetMscNumber;
    OMAP1_ClassmarkInformation classmarkInformation;  /* optional; set in
                                   * bit_mask OMAP1_classmarkInformation_present
                                   * if present */
} OMAP1_PerformSubsequentHandoverArg;

typedef struct OMAP1_PerformSubsequentHandoverRes {
    OMAP1_ExternalSignalInfo accessSignalInfo;
} OMAP1_PerformSubsequentHandoverRes;

typedef struct OMAP1_ProcessAccessSignallingArg {
    OMAP1_ExternalSignalInfo bss_APDU;
} OMAP1_ProcessAccessSignallingArg;

typedef struct OMAP1_ForwardAccessSignallingArg {
    OMAP1_ExternalSignalInfo bss_APDU;
} OMAP1_ForwardAccessSignallingArg;

typedef struct OMAP1_SendHandoverReportArg {
    OMAP1_IsdnAddressString handoverNumber;
} OMAP1_SendHandoverReportArg;

typedef struct OMAP1_RegisterChargingInformationArg {
    unsigned char   bit_mask;
#       define      OMAP1_bearerServiceCode_present 0x80
#       define      OMAP1_RegisterChargingInformationArg_teleserviceCode_present 0x40
#       define      OMAP1_calledNumber_present 0x20
#       define      OMAP1_callingNumber_present 0x10
#       define      OMAP1_packetDataVolume_present 0x08
#       define      OMAP1_chargingUnit_present 0x04
#       define      OMAP1_RegisterChargingInformationArg_charge_present 0x02
#       define      OMAP1_ss_ChargingInfo_present 0x01
    OMAP1_IsdnAddressString msIsdn;
    OMAP1_IsdnAddressString mscNumber;
    OMAP1_IMSI      imsi;
    OMAP1_CallReference callReference;
    OMAP1_CallType  callType;
    OMAP1_CallStatus callStatus;
    OMAP1_CallDateTime callDateTime;
    OMAP1_CallDuration callDuration;
    OMAP1_BearerServiceCode bearerServiceCode;  /* optional; set in bit_mask
                                           * OMAP1_bearerServiceCode_present if
                                           * present */
    OMAP1_TeleserviceCode teleserviceCode;  /* optional; set in bit_mask
              * OMAP1_RegisterChargingInformationArg_teleserviceCode_present if
              * present */
    OMAP1_IsdnAddressString calledNumber;  /* optional; set in bit_mask
                                            * OMAP1_calledNumber_present if
                                            * present */
    OMAP1_IsdnAddressString callingNumber;  /* optional; set in bit_mask
                                             * OMAP1_callingNumber_present if
                                             * present */
    OMAP1_PacketDataVolume packetDataVolume;  /* optional; set in bit_mask
                                               * OMAP1_packetDataVolume_present
                                               * if present */
    OMAP1_ChargingUnit chargingUnit;  /* optional; set in bit_mask
                                       * OMAP1_chargingUnit_present if
                                       * present */
    OMAP1_Charge    charge;  /* optional; set in bit_mask
                       * OMAP1_RegisterChargingInformationArg_charge_present if
                       * present */
    OMAP1_SS_ChargingInfo ss_ChargingInfo;  /* optional; set in bit_mask
                                             * OMAP1_ss_ChargingInfo_present if
                                             * present */
} OMAP1_RegisterChargingInformationArg;

typedef struct OMAP1_ResetArg {
    unsigned char   bit_mask;
#       define      OMAP1_hlrId_present 0x80
    OMAP1_NetworkResource networkResource;
    OMAP1_IsdnAddressString originatingEntityNumber;
    OMAP1_HlrList   hlrId;  /* optional; set in bit_mask OMAP1_hlrId_present if
                             * present */
} OMAP1_ResetArg;

typedef struct OMAP1_ActivateTraceModeArg {
    unsigned char   bit_mask;
#       define      OMAP1_ActivateTraceModeArg_imsi_present 0x80
#       define      OMAP1_ActivateTraceModeArg_omcId_present 0x40
    OMAP1_IMSI      imsi;  /* optional; set in bit_mask
                            * OMAP1_ActivateTraceModeArg_imsi_present if
                            * present */
    OMAP1_TraceReference traceReference;
    OMAP1_TraceType traceType;
    OMAP1_AddressString omcId;  /* optional; set in bit_mask
                                 * OMAP1_ActivateTraceModeArg_omcId_present if
                                 * present */
} OMAP1_ActivateTraceModeArg;

typedef struct OMAP1_DeactivateTraceModeArg {
    unsigned char   bit_mask;
#       define      OMAP1_DeactivateTraceModeArg_imsi_present 0x80
    OMAP1_IMSI      imsi;  /* optional; set in bit_mask
                            * OMAP1_DeactivateTraceModeArg_imsi_present if
                            * present */
    OMAP1_TraceReference traceReference;
} OMAP1_DeactivateTraceModeArg;

typedef struct OMAP1_TraceSubscriberActivityArg {
    unsigned char   bit_mask;
#       define      OMAP1_TraceSubscriberActivityArg_imsi_present 0x80
#       define      OMAP1_TraceSubscriberActivityArg_omcId_present 0x40
#       define      OMAP1_callReference_present 0x20
    OMAP1_IMSI      imsi;  /* optional; set in bit_mask
                            * OMAP1_TraceSubscriberActivityArg_imsi_present if
                            * present */
    OMAP1_TraceReference traceReference;
    OMAP1_TraceType traceType;
    OMAP1_AddressString omcId;  /* optional; set in bit_mask
                            * OMAP1_TraceSubscriberActivityArg_omcId_present if
                            * present */
    OMAP1_CallReference callReference;  /* optional; set in bit_mask
                                         * OMAP1_callReference_present if
                                         * present */
} OMAP1_TraceSubscriberActivityArg;

typedef struct OMAP1_NoteInternalHandoverArg {
    unsigned char   bit_mask;
#       define      OMAP1_targetCellId_present 0x80
#       define      OMAP1_channelId_present 0x40
    OMAP1_HandoverType handoverType;
    OMAP1_GlobalCellId targetCellId;  /* optional; set in bit_mask
                                       * OMAP1_targetCellId_present if
                                       * present */
    OMAP1_ExternalSignalInfo channelId;  /* optional; set in bit_mask
                                          * OMAP1_channelId_present if
                                          * present */
} OMAP1_NoteInternalHandoverArg;

typedef struct OMAP1_CheckIMEArg {
    OMAP1_IMEI      imei;
} OMAP1_CheckIMEArg;

typedef struct OMAP1_CheckIMEIRes {
    OMAP1_EquipStatus equipStatus;
} OMAP1_CheckIMEIRes;

typedef struct OMAP1_AuthenticateArg {
    OMAP1_Rand      rand;
    OMAP1_CKSN      cksn;
} OMAP1_AuthenticateArg;

typedef struct OMAP1_AuthenticateRes {
    OMAP1_Sres      sres;
} OMAP1_AuthenticateRes;

typedef struct OMAP1_ProvideIMSIRes {
    OMAP1_IMSI      imsi;
} OMAP1_ProvideIMSIRes;

typedef struct OMAP1_SetCipheringModeArg {
    unsigned char   bit_mask;
#       define      OMAP1_SetCipheringModeArg_kc_present 0x80
    OMAP1_CipheringMode cipheringMode;
    OMAP1_Kc        kc;  /* optional; set in bit_mask
                          * OMAP1_SetCipheringModeArg_kc_present if present */
} OMAP1_SetCipheringModeArg;

typedef struct OMAP1_SendRoutingInfoForSMArg {
    unsigned char   bit_mask;
#       define      OMAP1_SendRoutingInfoForSMArg_cug_Interlock_present 0x80
#       define      OMAP1_SendRoutingInfoForSMArg_teleserviceCode_present 0x40
    OMAP1_IsdnAddressString msIsdn;
    ossBoolean      sm_RP_PRI;
    OMAP1_AddressString serviceCentreAddress;
    OMAP1_CUG_Interlock cug_Interlock;  /* optional; set in bit_mask
                       * OMAP1_SendRoutingInfoForSMArg_cug_Interlock_present if
                       * present */
    OMAP1_TeleserviceCode teleserviceCode;  /* optional; set in bit_mask
                     * OMAP1_SendRoutingInfoForSMArg_teleserviceCode_present if
                     * present */
} OMAP1_SendRoutingInfoForSMArg;

typedef struct OMAP1_ForwardNewTMSIArg {
    OMAP1_TMSI      tmsi;
} OMAP1_ForwardNewTMSIArg;

typedef struct OMAP1__choice10 {
    unsigned short  choice;
#       define      OMAP1_sequence_chosen 1
#       define      OMAP1_choice_forwardingData_chosen 2
    union _union {
        struct OMAP1__seq2 {
            unsigned char   bit_mask;
#               define      OMAP1_sequence_lmsi_present 0x80
            OMAP1_LocationInfo locationInfo;
            OMAP1_LMSI      lmsi;  /* optional; set in bit_mask
                                    * OMAP1_sequence_lmsi_present if present */
        } sequence;  /* to choose, set choice to OMAP1_sequence_chosen */
        OMAP1_ForwardingData forwardingData;  /* to choose, set choice to
                                        * OMAP1_choice_forwardingData_chosen */
    } u;
} OMAP1__choice10;

typedef struct OMAP1_SendRoutingInfoForSMRes {
    unsigned char   bit_mask;
#       define      OMAP1_mwd_Set_present 0x80
    OMAP1_IMSI      imsi;
    OMAP1__choice10 choice;
    ossBoolean      mwd_Set;  /* optional; set in bit_mask OMAP1_mwd_Set_present
                               * if present */
} OMAP1_SendRoutingInfoForSMRes;

typedef struct OMAP1_ForwardShortMessageArg {
    OMAP1_SM_RP_DA  sm_RP_DA;
    OMAP1_SM_RP_OA  sm_RP_OA;
    OMAP1_SM_RP_UI  sm_RP_UI;
} OMAP1_ForwardShortMessageArg;

typedef struct OMAP1_SetMessageWaitingDataArg {
    OMAP1_IsdnAddressString msIsdn;
    OMAP1_AddressString serviceCentreAddress;
} OMAP1_SetMessageWaitingDataArg;

// NoteMSPresentArg	::=	SEQUENCE {
// imsi		IMSI}
typedef OMAP1_IMSI      OMAP1_NoteMSPresentArg;

typedef struct OMAP1_AlertServiceCentreArg {
    OMAP1_IsdnAddressString msIsdn;
    OMAP1_AddressString serviceCentreAddress;
} OMAP1_AlertServiceCentreArg;

typedef struct OMAP1_ProcessAccessRequestArg {
    OMAP1_SubscriberId subscriberId;
    OMAP1_CmServiceType cmServiceType;
    OMAP1_AccessConnectionStatus accessConnectionStatus;
    OMAP1_CKSN      cksn;
} OMAP1_ProcessAccessRequestArg;

typedef struct OMAP1_ProcessAccessRequestRes {
    unsigned char   bit_mask;
#       define      OMAP1_ProcessAccessRequestRes_msIsdn_present 0x80
    OMAP1_IMSI      imsi;
    OMAP1_IsdnAddressString msIsdn;  /* optional; set in bit_mask
                              * OMAP1_ProcessAccessRequestRes_msIsdn_present if
                              * present */
} OMAP1_ProcessAccessRequestRes;

typedef struct OMAP1_BeginSubscriberActivityArg {
    OMAP1_IMSI      imsi;
    OMAP1_IsdnAddressString originatingEntityNumber;
} OMAP1_BeginSubscriberActivityArg;

// error types definitions
typedef struct OMAP1_UnknownSubscriber {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_UnknownSubscriber;

typedef struct OMAP1_UnknownBaseStation {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_UnknownBaseStation;

typedef struct OMAP1_UnknownMSC {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_UnknownMSC;

typedef struct OMAP1_UnknownLocArea {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_UnknownLocArea;

typedef struct OMAP1_UnidentifiedSubscriber {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_UnidentifiedSubscriber;

typedef struct OMAP1_UnallocatedRoamingNumber {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_UnallocatedRoamingNumber;

typedef struct OMAP1_UnknownEquipment {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_UnknownEquipment;

typedef struct OMAP1_RoamingNotAllowed {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_RoamingNotAllowed;

typedef struct OMAP1_IllegalMS {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_IllegalMS;

typedef struct OMAP1_BearerServiceNotProvisioned {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_BearerServiceNotProvisioned;

typedef struct OMAP1_TeleserviceNotProvisioned {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_TeleserviceNotProvisioned;

typedef struct OMAP1_InsufficientBearerCapabilities {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_InsufficientBearerCapabilities;

typedef struct OMAP1_CallBarred {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_CallBarred; // optional

//
typedef struct OMAP1_ForwardingViolation {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_ForwardingViolation;

//
typedef struct OMAP1_CUG_Reject {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_CUG_Reject; // optional

//
typedef struct OMAP1_IllegalSS_Operation {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_IllegalSS_Operation;

//
typedef struct OMAP1_SS_ErrorStatus {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_SS_ErrorStatus; // optional

//
typedef struct OMAP1_SS_NotAvailable {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_SS_NotAvailable;

typedef struct OMAP1_SS_SubscriptionViolation {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_SS_SubscriptionViolation; // optional

typedef struct OMAP1_SS_Incompatibility_PARAMETER {
    unsigned char   bit_mask;
#       define      OMAP1_SS_Incompatibility_PARAMETER_ss_Code_present 0x80
#       define      OMAP1_SS_Incompatibility_PARAMETER_basicService_present 0x40
#       define      OMAP1_SS_Incompatibility_PARAMETER_ss_Status_present 0x20
    OMAP1_SS_Code   ss_Code;  /* optional; set in bit_mask
                        * OMAP1_SS_Incompatibility_PARAMETER_ss_Code_present if
                        * present */
    OMAP1_BasicServiceCode basicService;  /* optional; set in bit_mask
                   * OMAP1_SS_Incompatibility_PARAMETER_basicService_present if
                   * present */
    OMAP1_SS_Status ss_Status;  /* optional; set in bit_mask
                      * OMAP1_SS_Incompatibility_PARAMETER_ss_Status_present if
                      * present */
} OMAP1_SS_Incompatibility_PARAMETER;

//
typedef struct OMAP1_SS_Incompatibility {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_SS_Incompatibility; // optional

//
typedef struct OMAP1_FacilityNotSupported {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_FacilityNotSupported;

//
typedef struct OMAP1_InvalidTargetBaseStation {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_InvalidTargetBaseStation;

typedef struct OMAP1_NoRadioResourceAvailable {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_NoRadioResourceAvailable;

typedef struct OMAP1_NoHandoverNumberAvailable {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_NoHandoverNumberAvailable;

typedef struct OMAP1_SubsequentHandoverFailure {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_SubsequentHandoverFailure;

typedef struct OMAP1_AbsentSubscriber {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_AbsentSubscriber; // optional

typedef struct OMAP1_BusySubscriber {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_BusySubscriber;

typedef struct OMAP1_NoSubscriberReply {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_NoSubscriberReply;

typedef struct OMAP1_RadioCongestion {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_RadioCongestion;

typedef struct OMAP1_ImpossibleCallCompletion {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_ImpossibleCallCompletion; // optional

typedef struct OMAP1_SM_DeliveryFailure {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_SM_DeliveryFailure;

typedef struct OMAP1_MessageWaitingListFull {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_MessageWaitingListFull;

//
typedef struct OMAP1_SystemFailure {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_SystemFailure; // optional

typedef struct OMAP1_DataMissing {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_DataMissing;

typedef struct OMAP1_UnexpectedDataValue {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_UnexpectedDataValue;

typedef struct OMAP1_PasswordRegistrationFailure {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_PasswordRegistrationFailure;

typedef struct OMAP1_NegativePasswordCheck {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_NegativePasswordCheck;

typedef struct OMAP1_NoRoamingNumberAvailable {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_NoRoamingNumberAvailable;

typedef struct OMAP1_TracingBufferFull {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_TracingBufferFull;

// exports operations types	

// Location management
// Subscriber data management
// Supplementary Services Handling
// Call set-up
// Paging
// Handover
// Charging
// Fault recovery
// Tracing
// Equipment management
// Authentication and security
// Short messages
// Access request
// imports errors types
typedef struct OMAP1_UpdateLocationArea {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_UpdateLocationArea;

//
typedef struct OMAP1_UpdateLocation {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_UpdateLocation;

//
typedef struct OMAP1_CancelLocation {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_CancelLocation;

	//
typedef struct OMAP1_DetachIMSI {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_DetachIMSI;

//
typedef struct OMAP1_AttachIMSI {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_AttachIMSI;

//
typedef struct OMAP1_DeregisterMobileSubscriber {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_DeregisterMobileSubscriber;

	// Subscriber data management
typedef struct OMAP1_InsertSubscriberData {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_InsertSubscriberData;

//
typedef struct OMAP1_DeleteSubscriberData {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_DeleteSubscriberData;

//
typedef struct OMAP1_SendParameters {	// optional (nothing is returned, if the requested
	// parameters are not available or do not exist)
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_SendParameters;

	// Supplementary services handling
//
typedef struct OMAP1_RegisterSS {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_RegisterSS;

//
typedef struct OMAP1_EraseSS {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_EraseSS;

typedef struct OMAP1_ActivateSS {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_ActivateSS;

//
typedef struct OMAP1_DeactivateSS {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_DeactivateSS;

	//
typedef struct OMAP1_InterrogateSS {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_InterrogateSS;

//
typedef struct OMAP1_InvokeSS {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_InvokeSS;

	//
typedef struct OMAP1_ForwardSsNotification {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_ForwardSsNotification;

//
typedef struct OMAP1_RegisterPassword {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_RegisterPassword;

//
typedef struct OMAP1_GetPassword {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_GetPassword;

//
typedef struct OMAP1_ProcessUnstructuredSsData {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_ProcessUnstructuredSsData;

	// UnexpectedDataValue is used when data from MS does not correspond
	// to any service implemented in HLR
	// Call set-up
//
typedef struct OMAP1_SendInfoForIncomingCall {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_SendInfoForIncomingCall;

//
typedef struct OMAP1_SendInfoForOutgoingCall {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_SendInfoForOutgoingCall;

typedef struct OMAP1_SendRoutingInformation {// If available from the network the ISDN Bearer Capabilities and the ISDN High Layer
// Compatibility and Low Layer Compatibility information elements are included in
// the networkSignalInfo parameter as defined in section 6.4.3.8.9.
// The information is passed according to the rules specified in GSM 09.07.
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_SendRoutingInformation;

typedef struct OMAP1_ProvideRoamingNumber {// If available from the network the ISDN High Layer Compatibility information element is
// carried in the networkSignalInfo parameter as shown in section 6.4.3.8.9.
// The information is passed according to the rules specified in GSM 09.07.
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_ProvideRoamingNumber;

//
typedef struct OMAP1_CompleteCall {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_CompleteCall;

//
typedef struct OMAP1_ConnectToFollowingAddress {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_ConnectToFollowingAddress;

//
typedef struct OMAP1_ProcessCallWaiting {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_ProcessCallWaiting;

// Paging
//
typedef struct OMAP1_Page {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_Page;

//
typedef struct OMAP1_SearchForMobileSubscriber {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_SearchForMobileSubscriber;

//

// Handover
typedef struct OMAP1_PerformHandover {	// protocolId for ExternalSignalInfo
	// should indicate "gsm-04.08-version1"
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_PerformHandover;

//
typedef struct OMAP1_SendEndSignal {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_SendEndSignal;

//RESULT
typedef struct OMAP1_PerformSubsequentHandover {// protocolId should indicate "gsm-04.08-version1"}
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_PerformSubsequentHandover;

//
typedef struct OMAP1_AllocateHandoverNumber {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_AllocateHandoverNumber;

//
typedef struct OMAP1_SendHandoverReport {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_SendHandoverReport;

//RESULT

//
typedef struct OMAP1_ProcessAccessSignalling {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_ProcessAccessSignalling;

// protocolId should indicate "gsm-0806-version1"

//
typedef struct OMAP1_ForwardAccessSignalling {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_ForwardAccessSignalling;

// protocolId should indicate "gsm-0806-version1"

// Charging
//
typedef struct OMAP1_RegisterChargingInformation {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_RegisterChargingInformation;

// Fault recovery
//
typedef struct OMAP1_Reset {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_Reset;

//
typedef struct OMAP1_ForwardCheckSsIndication {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_ForwardCheckSsIndication;

// Tracing
//
typedef struct OMAP1_ActivateTraceMode {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_ActivateTraceMode;

//
typedef struct OMAP1_DeactivateTraceMode {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_DeactivateTraceMode;

//
typedef struct OMAP1_TraceSubscriberActivity {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_TraceSubscriberActivity;

//
typedef struct OMAP1_NoteInternalHandover {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_NoteInternalHandover;

	// Equipment management
//
typedef struct OMAP1_CheckIMEI {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_CheckIMEI;

// Authentication and security
//
typedef struct OMAP1_Authenticate {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_Authenticate;

//
typedef struct OMAP1_ProvideIMSI {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_ProvideIMSI;

typedef struct OMAP1_ForwardNewTMSI {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_ForwardNewTMSI;

//RESULT

//
typedef struct OMAP1_SetCipheringMode {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_SetCipheringMode;

// Kc should be included when cipheringMode indicates
// that ciphering must be performed

// Short messages
typedef struct OMAP1_SendRoutingInfoForSM {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_SendRoutingInfoForSM;

	//
typedef struct OMAP1_ForwardShortMessage {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_ForwardShortMessage;

//
typedef struct OMAP1_SetMessageWaitingData {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_SetMessageWaitingData;

//
typedef struct OMAP1_NoteMSPresent {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_NoteMSPresent;

//
typedef struct OMAP1_AlertServiceCentre {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_AlertServiceCentre;

// Access request
//
typedef struct OMAP1_ProcessAccessRequest {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_ProcessAccessRequest;

//
typedef struct OMAP1_BeginSubscriberActivity {
    unsigned short  choice;
#       define      OMAP1_localValue_chosen 1
#       define      OMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP1_localValue_chosen */
        struct OMAP1__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP1_globalValue_chosen */
    } u;
} OMAP1_BeginSubscriberActivity;

#ifndef _OSSNOVALUES

extern const int OMAP1_maxNumOfPrivateExtensions;

// value assignment
extern const int OMAP1_maxSignalInfoLength;

extern const int OMAP1_maxNumOfTeleServices;

extern const int OMAP1_maxNumOfBearerServices;

extern const int OMAP1_maxNumOfSS;

extern const int OMAP1_maxNumOfCUG;

extern const int OMAP1_maxNumOfBasicServices;

extern const int OMAP1_maxNumOfForwardingFeatures;

extern const int OMAP1_maxNumOfCallBarringFeatures;

extern const int OMAP1_maxNumOfHlrId;

extern const int OMAP1_maxPacketDataVolume;

extern const int OMAP1_maxNumOfChargingUnit;

extern const int OMAP1_maxCallDuration;

extern const int OMAP1_maxAddressLength;

extern const int OMAP1_maxNumOfSentParameters;
// this named value should correspond to the maximum of
// the maxNumOfCUG and the maximum number of authentication
// set which may be returned by a HLR plus 1.

extern const int OMAP1_maxNumOfBasicServiceGroups;

// Imports operation types

// Location management
// Data management
// Supplementary Services Handling
// Call set-up
// Paging
// Handover
// Charging
// Restoration
// Authentication and security
// Equipment management
// Short messages
// Tracing
// Others
// imports error types
// allocation of local value to operations
extern OMAP1_UpdateLocationArea OMAP1_updateLocationArea;

extern OMAP1_UpdateLocation OMAP1_updateLocation;

extern OMAP1_CancelLocation OMAP1_cancelLocation;

extern OMAP1_ProvideRoamingNumber OMAP1_provideRoamingNumber;

extern OMAP1_DetachIMSI OMAP1_detachIMSI;

extern OMAP1_AttachIMSI OMAP1_attachIMSI;

extern OMAP1_InsertSubscriberData OMAP1_insertSubscriberData;

extern OMAP1_DeleteSubscriberData OMAP1_deleteSubscriberData;

extern OMAP1_SendParameters OMAP1_sendParameters;

extern OMAP1_RegisterSS OMAP1_registerSS;

extern OMAP1_EraseSS OMAP1_eraseSS;

extern OMAP1_ActivateSS OMAP1_activateSS;

extern OMAP1_DeactivateSS OMAP1_deactivateSS;

extern OMAP1_InterrogateSS OMAP1_interrogateSS;

extern OMAP1_InvokeSS OMAP1_invokeSS;

extern OMAP1_ForwardSsNotification OMAP1_forwardSsNotification;

extern OMAP1_RegisterPassword OMAP1_registerPassword;

extern OMAP1_GetPassword OMAP1_getPassword;

extern OMAP1_ProcessUnstructuredSsData OMAP1_processUnstructuredSsData;

extern OMAP1_SendInfoForIncomingCall OMAP1_sendInfoForIncomingCall;

extern OMAP1_SendInfoForOutgoingCall OMAP1_sendInfoForOutgoingCall;

extern OMAP1_SendRoutingInformation OMAP1_sendRoutingInformation;

extern OMAP1_CompleteCall OMAP1_completeCall;

extern OMAP1_ConnectToFollowingAddress OMAP1_connectToFollowingAddress;

extern OMAP1_ProcessCallWaiting OMAP1_processCallWaiting;

extern OMAP1_Page OMAP1_page;

extern OMAP1_SearchForMobileSubscriber OMAP1_searchForMobileSubscriber;

extern OMAP1_PerformHandover OMAP1_performHandover;

extern OMAP1_SendEndSignal OMAP1_sendEndSignal;

extern OMAP1_PerformSubsequentHandover OMAP1_performSubsequentHandover;

extern OMAP1_AllocateHandoverNumber OMAP1_allocateHandoverNumber;

extern OMAP1_SendHandoverReport OMAP1_sendHandoverReport;

extern OMAP1_ProcessAccessSignalling OMAP1_processAccessSignalling;

extern OMAP1_ForwardAccessSignalling OMAP1_forwardAccessSignalling;

extern OMAP1_NoteInternalHandover OMAP1_noteInternalHandover;

extern OMAP1_RegisterChargingInformation OMAP1_registerChargingInformation;

extern OMAP1_Reset OMAP1_reset;

extern OMAP1_ForwardCheckSsIndication OMAP1_forwardCheckSsIndication;

extern OMAP1_Authenticate OMAP1_authenticate;

extern OMAP1_ProvideIMSI OMAP1_provideIMSi;

extern OMAP1_ForwardNewTMSI OMAP1_forwardNewTMSI;

extern OMAP1_SetCipheringMode OMAP1_setCipheringMode;

extern OMAP1_CheckIMEI OMAP1_checkIMEI;

extern OMAP1_SendRoutingInfoForSM OMAP1_sendRoutingInfoForSM;

extern OMAP1_ForwardShortMessage OMAP1_forwardShortMessage;

extern OMAP1_SetMessageWaitingData OMAP1_setMessageWaitingData;

extern OMAP1_NoteMSPresent OMAP1_noteMSPresent;

extern OMAP1_AlertServiceCentre OMAP1_alertServiceCentre;

extern OMAP1_ActivateTraceMode OMAP1_activateTraceMode;

extern OMAP1_DeactivateTraceMode OMAP1_deactivateTraceMode;

extern OMAP1_TraceSubscriberActivity OMAP1_traceSubscriberActivity;

extern OMAP1_ProcessAccessRequest OMAP1_processAccessRequest;

extern OMAP1_BeginSubscriberActivity OMAP1_beginSubscriberActivity;

//
// allocation of local value to errors
extern OMAP1_UnknownSubscriber OMAP1_unknownSubscriber;

extern OMAP1_UnknownBaseStation OMAP1_unknownBaseStation;

extern OMAP1_UnknownMSC OMAP1_unknownMSC;

extern OMAP1_UnknownLocArea OMAP1_unknownLocArea;

extern OMAP1_UnidentifiedSubscriber OMAP1_unidentifiedSubscriber;

extern OMAP1_UnallocatedRoamingNumber OMAP1_unallocatedRoamingNumber;

extern OMAP1_UnknownEquipment OMAP1_unknownEquipment;

extern OMAP1_RoamingNotAllowed OMAP1_roamingNotAllowed;

extern OMAP1_IllegalMS OMAP1_illegalMS;

extern OMAP1_BearerServiceNotProvisioned OMAP1_bearerServiceNotProvisioned;

extern OMAP1_TeleserviceNotProvisioned OMAP1_teleServiceNotProvisioned;

extern OMAP1_InsufficientBearerCapabilities OMAP1_insufficientBearerCapabilities;

extern OMAP1_CallBarred OMAP1_callBarred;

extern OMAP1_ForwardingViolation OMAP1_forwardingViolation;

extern OMAP1_CUG_Reject OMAP1_cug_Reject;

extern OMAP1_IllegalSS_Operation OMAP1_illegalSS_Operation;

extern OMAP1_SS_ErrorStatus OMAP1_ss_ErrorStatus;

extern OMAP1_SS_NotAvailable OMAP1_ss_NotAvailable;

extern OMAP1_SS_SubscriptionViolation OMAP1_ss_SubscriptionViolation;

extern OMAP1_SS_Incompatibility OMAP1_ss_Incompatibility;

extern OMAP1_FacilityNotSupported OMAP1_facilityNotSupported;

extern OMAP1_InvalidTargetBaseStation OMAP1_invalidTargetBaseStation;

extern OMAP1_NoRadioResourceAvailable OMAP1_noRadioResourceAvailable;

extern OMAP1_NoHandoverNumberAvailable OMAP1_noHandoverNumberAvailable;

extern OMAP1_SubsequentHandoverFailure OMAP1_subsequentHandoverFailure;

extern OMAP1_AbsentSubscriber OMAP1_absentSubscriber;

extern OMAP1_BusySubscriber OMAP1_busySubscriber;

extern OMAP1_NoSubscriberReply OMAP1_noSubscriberReply;

extern OMAP1_RadioCongestion OMAP1_radioCongestion;

extern OMAP1_ImpossibleCallCompletion OMAP1_impossibleCallCompletion;

extern OMAP1_SM_DeliveryFailure OMAP1_sm_DeliveryFailure;

extern OMAP1_MessageWaitingListFull OMAP1_messageWaitingListFull;

extern OMAP1_SystemFailure OMAP1_systemFailure;

extern OMAP1_DataMissing OMAP1_dataMissing;

extern OMAP1_UnexpectedDataValue OMAP1_unexpectedDataValue;

extern OMAP1_PasswordRegistrationFailure OMAP1_passwordRegistrationFailure;

extern OMAP1_NegativePasswordCheck OMAP1_negativePasswordCheck;

extern OMAP1_NoRoamingNumberAvailable OMAP1_noRoamingNumberAvailable;

extern OMAP1_TracingBufferFull OMAP1_tracingBufferFull;

#endif  /* #ifndef _OSSNOVALUES */


extern void *OMAP1;    /* encoder-decoder control table */
#ifdef __cplusplus
}	/* extern "C" */
#endif /* __cplusplus */
#endif /* OSS_OMAP1 */
