/*************************************************************/
/* Copyright (C) 2017 OSS Nokalva, Inc.  All rights reserved.*/
/*************************************************************/

/* THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC.
 * AND MAY BE USED ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC.
 * THIS FILE MAY NOT BE DISTRIBUTED.
 * THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED. */

/* Generated for: Plintron Global Technology Solutions Pvt. Ltd. - Site-based, License 75139 75139,
 * at GKS Tech Park, DLT IT SEZ, Chennai 600089, India. */
/* Abstract syntax: IMAP1 */
/* Created: Fri Oct  6 15:46:02 2017 */
/* ASN.1 compiler version: 10.5 */
/* Code generated for runtime version 10.5 or later */
/* Compiler operating system: Linux with 64-bit support */
/* Compiler machine type: AMD64 */
/* Target operating system: Linux with 64-bit support */
/* Target machine type: AMD64 */
/* C compiler options required: -m64 */
/* ASN.1 compiler options and file names specified:
 * -prefix IMAP1_ -c++ -nowarningmessages -ber -root -ignoreIncompleteItems
 * /usr/local/ossasn1/linux-x86-64/10.5.0/asn1dflt.linux-amd64 TCAP.asn
 * MAP-ExtensionDataTypes.asn MAP-Constants.asn MAP-DataTypes.asn
 * MAP1-DataTypes.asn MAP-Errors.asn MAP-Operations.asn IMAP1.asn
 */

#ifndef OSS_IMAP1
#define OSS_IMAP1

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include "ossasn1.h"

#define          IMAP1_MessageType_PDU 1
#define          IMAP1_ExtensionContainer_PDU 2
#define          IMAP1_SS_SubscriptionOption_PDU 3
#define          IMAP1_UpdateLocationAreaArg_PDU 4
#define          IMAP1_UpdateLocationArg_PDU 5
#define          IMAP1_UpdateLocationRes_PDU 6
#define          IMAP1_CancelLocationArg_PDU 7
#define          IMAP1_DetachIMSIArg_PDU 8
#define          IMAP1_AttachIMSIArg_PDU 9
#define          IMAP1_DeregisterMobileSubscriberArg_PDU 10
#define          IMAP1_InsertSubscriberDataArg_PDU 11
#define          IMAP1_DeleteSubscriberDataArg_PDU 12
#define          IMAP1_SendParametersArg_PDU 13
#define          IMAP1_SendParametersRes_PDU 14
#define          IMAP1_RegisterSSArg_PDU 15
#define          IMAP1_RegisterSSRes_PDU 16
#define          IMAP1_EraseSSArg_PDU 17
#define          IMAP1_EraseSSRes_PDU 18
#define          IMAP1_ActivateSSArg_PDU 19
#define          IMAP1_ActivateSSRes_PDU 20
#define          IMAP1_DeactivateSSArg_PDU 21
#define          IMAP1_DeactivateSSRes_PDU 22
#define          IMAP1_InterrogateSSArg_PDU 23
#define          IMAP1_InterrogateSSRes_PDU 24
#define          IMAP1_InvokeSSArg_PDU 25
#define          IMAP1_InvokeSSRes_PDU 26
#define          IMAP1_ForwardSsNotificationArg_PDU 27
#define          IMAP1_RegisterPasswordArg_PDU 28
#define          IMAP1_RegisterPasswordRes_PDU 29
#define          IMAP1_GetPasswordArg_PDU 30
#define          IMAP1_GetPasswordRes_PDU 31
#define          IMAP1_ProcessUnstructuredSsDataArg_PDU 32
#define          IMAP1_ProcessUnstructuredSsDataRes_PDU 33
#define          IMAP1_SendInfoForIncomingCallArg_PDU 34
#define          IMAP1_SendInfoForOutgoingCallArg_PDU 35
#define          IMAP1_SendRoutingInformationArg_PDU 36
#define          IMAP1_SendRoutingInformationRes_PDU 37
#define          IMAP1_ProvideRoamingNumberArg_PDU 38
#define          IMAP1_ProvideRoamingNumberRes_PDU 39
#define          IMAP1_CompleteCallArg_PDU 40
#define          IMAP1_ConnectToFollowingAddressArg_PDU 41
#define          IMAP1_PageArg_PDU 42
#define          IMAP1_SearchForMobileSubscriberArg_PDU 43
#define          IMAP1_SearchForMobileSubscriberRes_PDU 44
#define          IMAP1_PerformHandoverArg_PDU 45
#define          IMAP1_PerformHandoverRes_PDU 46
#define          IMAP1_PerformSubsequentHandoverArg_PDU 47
#define          IMAP1_PerformSubsequentHandoverRes_PDU 48
#define          IMAP1_ProcessAccessSignallingArg_PDU 49
#define          IMAP1_ForwardAccessSignallingArg_PDU 50
#define          IMAP1_SendHandoverReportArg_PDU 51
#define          IMAP1_RegisterChargingInformationArg_PDU 52
#define          IMAP1_ResetArg_PDU 53
#define          IMAP1_ActivateTraceModeArg_PDU 54
#define          IMAP1_DeactivateTraceModeArg_PDU 55
#define          IMAP1_TraceSubscriberActivityArg_PDU 56
#define          IMAP1_NoteInternalHandoverArg_PDU 57
#define          IMAP1_CheckIMEArg_PDU 58
#define          IMAP1_CheckIMEIRes_PDU 59
#define          IMAP1_AuthenticateArg_PDU 60
#define          IMAP1_AuthenticateRes_PDU 61
#define          IMAP1_ProvideIMSIRes_PDU 62
#define          IMAP1_SetCipheringModeArg_PDU 63
#define          IMAP1_SendRoutingInfoForSMArg_PDU 64
#define          IMAP1_ForwardNewTMSIArg_PDU 65
#define          IMAP1_SendRoutingInfoForSMRes_PDU 66
#define          IMAP1_ForwardShortMessageArg_PDU 67
#define          IMAP1_SetMessageWaitingDataArg_PDU 68
#define          IMAP1_NoteMSPresentArg_PDU 69
#define          IMAP1_AlertServiceCentreArg_PDU 70
#define          IMAP1_ProcessAccessRequestArg_PDU 71
#define          IMAP1_ProcessAccessRequestRes_PDU 72
#define          IMAP1_BeginSubscriberActivityArg_PDU 73
#define          IMAP1_UnknownSubscriber_PDU 74
#define          IMAP1_UnknownBaseStation_PDU 75
#define          IMAP1_UnknownMSC_PDU 76
#define          IMAP1_UnknownLocArea_PDU 77
#define          IMAP1_UnidentifiedSubscriber_PDU 78
#define          IMAP1_UnallocatedRoamingNumber_PDU 79
#define          IMAP1_UnknownEquipment_PDU 80
#define          IMAP1_RoamingNotAllowed_PDU 81
#define          IMAP1_IllegalMS_PDU 82
#define          IMAP1_BearerServiceNotProvisioned_PDU 83
#define          IMAP1_TeleserviceNotProvisioned_PDU 84
#define          IMAP1_InsufficientBearerCapabilities_PDU 85
#define          IMAP1_CallBarred_PARAMETER_PDU 86
#define          IMAP1_CallBarred_PDU 87
#define          IMAP1_ForwardingViolation_PDU 88
#define          IMAP1_CUG_Reject_PARAMETER_PDU 89
#define          IMAP1_CUG_Reject_PDU 90
#define          IMAP1_IllegalSS_Operation_PDU 91
#define          IMAP1_SS_ErrorStatus_PDU 92
#define          IMAP1_SS_NotAvailable_PDU 93
#define          IMAP1_SS_SubscriptionViolation_PDU 94
#define          IMAP1_SS_Incompatibility_PARAMETER_PDU 95
#define          IMAP1_SS_Incompatibility_PDU 96
#define          IMAP1_FacilityNotSupported_PDU 97
#define          IMAP1_InvalidTargetBaseStation_PDU 98
#define          IMAP1_NoRadioResourceAvailable_PDU 99
#define          IMAP1_NoHandoverNumberAvailable_PDU 100
#define          IMAP1_SubsequentHandoverFailure_PDU 101
#define          IMAP1_AbsentSubscriber_PARAMETER_PDU 102
#define          IMAP1_AbsentSubscriber_PDU 103
#define          IMAP1_BusySubscriber_PDU 104
#define          IMAP1_NoSubscriberReply_PDU 105
#define          IMAP1_RadioCongestion_PDU 106
#define          IMAP1_ImpossibleCallCompletion_PDU 107
#define          IMAP1_SM_DeliveryFailure_PARAMETER_PDU 108
#define          IMAP1_SM_DeliveryFailure_PDU 109
#define          IMAP1_MessageWaitingListFull_PDU 110
#define          IMAP1_SystemFailure_PDU 111
#define          IMAP1_DataMissing_PDU 112
#define          IMAP1_UnexpectedDataValue_PDU 113
#define          IMAP1_PasswordRegistrationFailure_PARAMETER_PDU 114
#define          IMAP1_PasswordRegistrationFailure_PDU 115
#define          IMAP1_NegativePasswordCheck_PDU 116
#define          IMAP1_NoRoamingNumberAvailable_PDU 117
#define          IMAP1_TracingBufferFull_PDU 118
#define          IMAP1_UpdateLocationArea_PDU 119
#define          IMAP1_UpdateLocation_PDU 120
#define          IMAP1_CancelLocation_PDU 121
#define          IMAP1_DetachIMSI_PDU 122
#define          IMAP1_AttachIMSI_PDU 123
#define          IMAP1_DeregisterMobileSubscriber_PDU 124
#define          IMAP1_InsertSubscriberData_PDU 125
#define          IMAP1_DeleteSubscriberData_PDU 126
#define          IMAP1_SendParameters_PDU 127
#define          IMAP1_RegisterSS_PDU 128
#define          IMAP1_EraseSS_PDU 129
#define          IMAP1_ActivateSS_PDU 130
#define          IMAP1_DeactivateSS_PDU 131
#define          IMAP1_InterrogateSS_PDU 132
#define          IMAP1_InvokeSS_PDU 133
#define          IMAP1_ForwardSsNotification_PDU 134
#define          IMAP1_RegisterPassword_PDU 135
#define          IMAP1_GetPassword_PDU 136
#define          IMAP1_ProcessUnstructuredSsData_PDU 137
#define          IMAP1_SendInfoForIncomingCall_PDU 138
#define          IMAP1_SendInfoForOutgoingCall_PDU 139
#define          IMAP1_SendRoutingInformation_PDU 140
#define          IMAP1_ProvideRoamingNumber_PDU 141
#define          IMAP1_CompleteCall_PDU 142
#define          IMAP1_ConnectToFollowingAddress_PDU 143
#define          IMAP1_ProcessCallWaiting_PDU 144
#define          IMAP1_Page_PDU 145
#define          IMAP1_SearchForMobileSubscriber_PDU 146
#define          IMAP1_PerformHandover_PDU 147
#define          IMAP1_SendEndSignal_PDU 148
#define          IMAP1_PerformSubsequentHandover_PDU 149
#define          IMAP1_AllocateHandoverNumber_PDU 150
#define          IMAP1_SendHandoverReport_PDU 151
#define          IMAP1_ProcessAccessSignalling_PDU 152
#define          IMAP1_ForwardAccessSignalling_PDU 153
#define          IMAP1_RegisterChargingInformation_PDU 154
#define          IMAP1_Reset_PDU 155
#define          IMAP1_ForwardCheckSsIndication_PDU 156
#define          IMAP1_ActivateTraceMode_PDU 157
#define          IMAP1_DeactivateTraceMode_PDU 158
#define          IMAP1_TraceSubscriberActivity_PDU 159
#define          IMAP1_NoteInternalHandover_PDU 160
#define          IMAP1_CheckIMEI_PDU 161
#define          IMAP1_Authenticate_PDU 162
#define          IMAP1_ProvideIMSI_PDU 163
#define          IMAP1_ForwardNewTMSI_PDU 164
#define          IMAP1_SetCipheringMode_PDU 165
#define          IMAP1_SendRoutingInfoForSM_PDU 166
#define          IMAP1_ForwardShortMessage_PDU 167
#define          IMAP1_SetMessageWaitingData_PDU 168
#define          IMAP1_NoteMSPresent_PDU 169
#define          IMAP1_AlertServiceCentre_PDU 170
#define          IMAP1_ProcessAccessRequest_PDU 171
#define          IMAP1_BeginSubscriberActivity_PDU 172

typedef struct IMAP1__ObjectID {
    unsigned short  length;
    unsigned char   *value;
} IMAP1__ObjectID;

typedef struct IMAP1__Any {
    unsigned long   length;
    unsigned char   *value;
} IMAP1__Any;

typedef struct IMAP1__choice1 {
    unsigned short  choice;
#       define      IMAP1_single_ASN1_type_chosen 1
#       define      IMAP1_octet_aligned_chosen 2
#       define      IMAP1_arbitrary_chosen 3
    union _union {
        OpenType        single_ASN1_type;  /* to choose, set choice to
                                            * IMAP1_single_ASN1_type_chosen */
        struct IMAP1_External_octet_aligned {
            unsigned int    length;
            unsigned char   *value;
        } octet_aligned;  /* to choose, set choice to
                           * IMAP1_octet_aligned_chosen */
        struct IMAP1_External_arbitrary {
            unsigned int    length;  /* number of significant bits */
            unsigned char   *value;
        } arbitrary;  /* to choose, set choice to IMAP1_arbitrary_chosen */
    } u;
} IMAP1__choice1;

typedef struct IMAP1__External {
    unsigned char   bit_mask;
#       define      IMAP1_direct_reference_present 0x80
#       define      IMAP1_indirect_reference_present 0x40
    IMAP1__ObjectID direct_reference;  /* optional; set in bit_mask
                                        * IMAP1_direct_reference_present if
                                        * present */
    int             indirect_reference;  /* optional; set in bit_mask
                                          * IMAP1_indirect_reference_present if
                                          * present */
    char            *data_value_descriptor;  /* NULL for not present */
    IMAP1__choice1  encoding;
} IMAP1__External;

// NOTE � When the Abort Message is generated by the Transaction sublayer, a p-Abort Cause must be
// present.The u-abortCause may be generated by the component sublayer in which case it is an ABRT
// APDU, or by the TC-User in which case it could be either an ABRT APDU or data in some user-defined
// abstract syntax.
typedef IMAP1__External IMAP1_DialoguePortion;

typedef struct IMAP1_Unidirectional {
    unsigned char   bit_mask;
#       define      IMAP1_Unidirectional_dialoguePortion_present 0x80
    IMAP1_DialoguePortion dialoguePortion;  /* optional; set in bit_mask
                              * IMAP1_Unidirectional_dialoguePortion_present if
                              * present */
    struct IMAP1_ComponentPortion_ *components;
} IMAP1_Unidirectional;

// The dialogue portion carries the dialogue control PDUs as value of the external data type.
// The direct reference should be set to { ccitt recommendation q 773 as (1) dialogue-as (1) version (1) }
// if structured dialogue is used and to { ccitt recommendation q 773 as (1) unidialogue-as (2) version (1) }
// if unstructured dialogue is used or any user defined abstract syntax name when only user information
// is carried (e.g. when user information is sent in a 1988 Abort message).
typedef struct IMAP1_OrigTransactionID {
    unsigned short  length;
    unsigned char   value[4];
} IMAP1_OrigTransactionID;

typedef struct IMAP1_Begin {
    unsigned char   bit_mask;
#       define      IMAP1_Begin_dialoguePortion_present 0x80
#       define      IMAP1_Begin_components_present 0x40
    IMAP1_OrigTransactionID otid;
    IMAP1_DialoguePortion dialoguePortion;  /* optional; set in bit_mask
                                       * IMAP1_Begin_dialoguePortion_present if
                                       * present */
    struct IMAP1_ComponentPortion_ *components;  /* optional; set in bit_mask
                                            * IMAP1_Begin_components_present if
                                            * present */
} IMAP1_Begin;

typedef struct IMAP1_DestTransactionID {
    unsigned short  length;
    unsigned char   value[4];
} IMAP1_DestTransactionID;

typedef struct IMAP1_End {
    unsigned char   bit_mask;
#       define      IMAP1_End_dialoguePortion_present 0x80
#       define      IMAP1_End_components_present 0x40
    IMAP1_DestTransactionID dtid;
    IMAP1_DialoguePortion dialoguePortion;  /* optional; set in bit_mask
                                             * IMAP1_End_dialoguePortion_present
                                             * if present */
    struct IMAP1_ComponentPortion_ *components;  /* optional; set in bit_mask
                                                  * IMAP1_End_components_present
                                                  * if present */
} IMAP1_End;

typedef struct IMAP1_Continue {
    unsigned char   bit_mask;
#       define      IMAP1_Continue_dialoguePortion_present 0x80
#       define      IMAP1_Continue_components_present 0x40
    IMAP1_OrigTransactionID otid;
    IMAP1_DestTransactionID dtid;
    IMAP1_DialoguePortion dialoguePortion;  /* optional; set in bit_mask
                                    * IMAP1_Continue_dialoguePortion_present if
                                    * present */
    struct IMAP1_ComponentPortion_ *components;  /* optional; set in bit_mask
                                         * IMAP1_Continue_components_present if
                                         * present */
} IMAP1_Continue;

typedef int             IMAP1_P_AbortCause;
#define                     IMAP1_unrecognizedMessageType 0
#define                     IMAP1_unrecognizedTransactionID 1
#define                     IMAP1_badlyFormattedTransactionPortion 2
#define                     IMAP1_incorrectTransactionPortion 3
#define                     IMAP1_P_AbortCause_resourceLimitation 4

typedef struct IMAP1__choice2 {
    unsigned short  choice;
#       define      IMAP1_p_abortCause_chosen 1
#       define      IMAP1_u_abortCause_chosen 2
    union _union {
        IMAP1_P_AbortCause p_abortCause;  /* to choose, set choice to
                                           * IMAP1_p_abortCause_chosen */
        IMAP1_DialoguePortion u_abortCause;  /* to choose, set choice to
                                              * IMAP1_u_abortCause_chosen */
    } u;
} IMAP1__choice2;

typedef struct IMAP1_Abort {
    unsigned char   bit_mask;
#       define      IMAP1_reason_present 0x80
    IMAP1_DestTransactionID dtid;
    IMAP1__choice2  reason;  /* optional; set in bit_mask IMAP1_reason_present
                              * if present */
} IMAP1_Abort;

// Transaction Portion fields
typedef struct IMAP1_MessageType {
    unsigned short  choice;
#       define      IMAP1_unidirectional_chosen 1
#       define      IMAP1_begin_chosen 2
#       define      IMAP1_end_chosen 3
#       define      IMAP1_continue_chosen 4
#       define      IMAP1_abort_chosen 5
    union _union {
        IMAP1_Unidirectional unidirectional;  /* to choose, set choice to
                                               * IMAP1_unidirectional_chosen */
        IMAP1_Begin     begin;  /* to choose, set choice to
                                 * IMAP1_begin_chosen */
        IMAP1_End       end;  /* to choose, set choice to IMAP1_end_chosen */
        IMAP1_Continue  MessageType_continue;  /* to choose, set choice to
                                                * IMAP1_continue_chosen */
        IMAP1_Abort     abort;  /* to choose, set choice to
                                 * IMAP1_abort_chosen */
    } u;
} IMAP1_MessageType;

typedef short           IMAP1_InvokeIdType;

typedef struct IMAP1__choice3 {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1__choice3;

// The Components are sequences of data elements.
typedef struct IMAP1_Invoke {
    unsigned char   bit_mask;
#       define      IMAP1_linkedID_present 0x80
#       define      IMAP1_Invoke_parameter_present 0x40
    IMAP1_InvokeIdType invokeID;
    IMAP1_InvokeIdType linkedID;  /* optional; set in bit_mask
                                   * IMAP1_linkedID_present if present */
    IMAP1__choice3  operationCode;
    IMAP1__Any      parameter;  /* optional; set in bit_mask
                                 * IMAP1_Invoke_parameter_present if present */
} IMAP1_Invoke;

// ANY is filled by the single ASN.1 data type following the keyword PARAMETER or the keyword ARGUMENT
// in the type definition of a particular operation.
typedef struct IMAP1_ReturnResult {
    unsigned char   bit_mask;
#       define      IMAP1_result_present 0x80
    IMAP1_InvokeIdType invokeID;
    struct IMAP1__seq1 {
        IMAP1__choice3  operationCode;
        IMAP1__Any      parameter;
    } result;  /* optional; set in bit_mask IMAP1_result_present if present */
} IMAP1_ReturnResult;

// ANY is filled by the single ASN.1 data type following the keyword RESULT in the type definition
// of a particular operation.
typedef struct IMAP1_ReturnError {
    unsigned char   bit_mask;
#       define      IMAP1_ReturnError_parameter_present 0x80
    IMAP1_InvokeIdType invokeID;
    IMAP1__choice3  errorCode;
    IMAP1__Any      parameter;  /* optional; set in bit_mask
                                 * IMAP1_ReturnError_parameter_present if
                                 * present */
} IMAP1_ReturnError;

// PROBLEMS
typedef int             IMAP1_GeneralProblem;
#define                     IMAP1_unrecognizedComponent 0
#define                     IMAP1_mistypedComponent 1
#define                     IMAP1_badlyStructuredComponent 2

typedef int             IMAP1_InvokeProblem;
#define                     IMAP1_duplicateInvokeID 0
#define                     IMAP1_unrecognizedOperation 1
#define                     IMAP1_InvokeProblem_mistypedParameter 2
#define                     IMAP1_InvokeProblem_resourceLimitation 3
#define                     IMAP1_initiatingRelease 4
#define                     IMAP1_unrecognizedLinkedID 5
#define                     IMAP1_linkedResponseUnexpected 6
#define                     IMAP1_unexpectedLinkedOperation 7

typedef int             IMAP1_ReturnResultProblem;
#define                     IMAP1_ReturnResultProblem_unrecognizedInvokeID 0
#define                     IMAP1_returnResultUnexpected 1
#define                     IMAP1_ReturnResultProblem_mistypedParameter 2

typedef int             IMAP1_ReturnErrorProblem;
#define                     IMAP1_ReturnErrorProblem_unrecognizedInvokeID 0
#define                     IMAP1_returnErrorUnexpected 1
#define                     IMAP1_unrecognizedError 2
#define                     IMAP1_unexpectedError 3
#define                     IMAP1_ReturnErrorProblem_mistypedParameter 4

typedef struct IMAP1__choice4 {
    unsigned short  choice;
#       define      IMAP1_derivable_chosen 1
#       define      IMAP1_not_derivable_chosen 2
    union _union {
        IMAP1_InvokeIdType derivable;  /* to choose, set choice to
                                        * IMAP1_derivable_chosen */
        Nulltype        not_derivable;  /* to choose, set choice to
                                         * IMAP1_not_derivable_chosen */
    } u;
} IMAP1__choice4;

typedef struct IMAP1__choice5 {
    unsigned short  choice;
#       define      IMAP1_generalProblem_chosen 1
#       define      IMAP1_invokeProblem_chosen 2
#       define      IMAP1_returnResultProblem_chosen 3
#       define      IMAP1_returnErrorProblem_chosen 4
    union _union {
        IMAP1_GeneralProblem generalProblem;  /* to choose, set choice to
                                               * IMAP1_generalProblem_chosen */
        IMAP1_InvokeProblem invokeProblem;  /* to choose, set choice to
                                             * IMAP1_invokeProblem_chosen */
        IMAP1_ReturnResultProblem returnResultProblem;  /* to choose, set choice
                                       * to IMAP1_returnResultProblem_chosen */
        IMAP1_ReturnErrorProblem returnErrorProblem;  /* to choose, set choice
                                        * to IMAP1_returnErrorProblem_chosen */
    } u;
} IMAP1__choice5;

// ANY is filled by the single ASN.1 data type following the keyword PARAMETER in the type definition
// of a particular error.
typedef struct IMAP1_Reject {
    IMAP1__choice4  invokeID;
    IMAP1__choice5  problem;
} IMAP1_Reject;

// Component Portion fields
// COMPONENT TYPE. Recommendation X.229 defines four Application Protocol Data Units (APDUs).
// TCAP adds returnResultNotLast to allow for the segmentation of a result.
typedef struct IMAP1_Component {
    unsigned short  choice;
#       define      IMAP1_invoke_chosen 1
#       define      IMAP1_returnResultLast_chosen 2
#       define      IMAP1_returnError_chosen 3
#       define      IMAP1_reject_chosen 4
#       define      IMAP1_returnResultNotLast_chosen 5
    union _union {
        IMAP1_Invoke    invoke;  /* to choose, set choice to
                                  * IMAP1_invoke_chosen */
        IMAP1_ReturnResult returnResultLast;  /* to choose, set choice to
                                             * IMAP1_returnResultLast_chosen */
        IMAP1_ReturnError returnError;  /* to choose, set choice to
                                         * IMAP1_returnError_chosen */
        IMAP1_Reject    reject;  /* to choose, set choice to
                                  * IMAP1_reject_chosen */
        IMAP1_ReturnResult returnResultNotLast;  /* to choose, set choice to
                                          * IMAP1_returnResultNotLast_chosen */
    } u;
} IMAP1_Component;

// COMPONENT PORTION. The last field in the transaction portion of the TCAP message is the Component Portion.
// The Component Portion may be absent.
typedef struct IMAP1_ComponentPortion_ {
    struct IMAP1_ComponentPortion_ *next;
    IMAP1_Component value;
} *IMAP1_ComponentPortion;

// IOC for private extensions
typedef struct IMAP1_EXTENSION {
    unsigned char   bit_mask;
#       define      IMAP1_ExtensionType_present 0x80
    unsigned short  ExtensionType;  /* optional; set in bit_mask
                                     * IMAP1_ExtensionType_present if present */
    IMAP1__ObjectID extensionId;
    long            _oss_unique_index;
} IMAP1_EXTENSION;

	// Unsupported private extensions shall be discarded if received.
typedef struct IMAP1_PCS_Extensions {
    char            placeholder;
} IMAP1_PCS_Extensions;

	// The length of the Object Identifier shall not exceed 16 octets and the
	// number of components of the Object Identifier shall not exceed 16
// data types
typedef struct IMAP1_ExtensionContainer {
    unsigned char   bit_mask;
#       define      IMAP1_privateExtensionList_present 0x80
#       define      IMAP1_pcs_Extensions_present 0x40
    struct IMAP1_PrivateExtensionList_ *privateExtensionList;  /* optional; set
                                   * in bit_mask
                                   * IMAP1_privateExtensionList_present if
                                   * present */
    IMAP1_PCS_Extensions pcs_Extensions;  /* optional; set in bit_mask
                                           * IMAP1_pcs_Extensions_present if
                                           * present */
} IMAP1_ExtensionContainer;

		// 1 bit per defined indication

//Password	 ::= CHOICE {
//		PrintableString (SIZE(4..8)),
//		NumericString (FROM (
//		"0"|"1"|"2"|"3"|"4"|
//		"5"|"6"|"7"|"8"|"9")|
//		SIZE(4))}
		// only the second form is used for GSM systems.
typedef char            IMAP1_Password[5];

//RegisterPasswordRes	::=	SEQUENCE { newPassword 	Password}
typedef IMAP1_Password  IMAP1_RegisterPasswordRes;

//GetPasswordRes ::=	SEQUENCE { currentPassword	Password}
typedef IMAP1_Password  IMAP1_GetPasswordRes;

		// the identifiers used in this description represent
		// the information which has to be delivered to the subscriber
		// according to table 6.4/4.
		// How this information is really delivered to the subscriber
		// (display, announcement, ...) is not part of this specification.
typedef char            IMAP1_SS_UserData[201];

//ProcessUnstructuredSsDataArg ::=	SEQUENCE {
//ss-UserData		SS-UserData}
typedef IMAP1_SS_UserData IMAP1_ProcessUnstructuredSsDataArg;

typedef enum IMAP1_CallBarred_PARAMETER {
    IMAP1_barringServiceActive = 0,
    IMAP1_operatorBarring = 1
} IMAP1_CallBarred_PARAMETER;

typedef enum IMAP1_CUG_Reject_PARAMETER {
    IMAP1_incomingCallBarred = 0,
    IMAP1_nonCUGmember = 1
} IMAP1_CUG_Reject_PARAMETER;

typedef enum IMAP1_SM_DeliveryFailure_PARAMETER {
    IMAP1_memoryCapacityExceeded = 0,
    IMAP1_msProtocolError = 1,
    IMAP1_msNotEquiped = 2,
    IMAP1_unknownServiceCentre = 3,
    IMAP1_scCongestion = 4,
    IMAP1_invalidSmeAddress = 5,
    IMAP1_msNotScSubscriber = 6
} IMAP1_SM_DeliveryFailure_PARAMETER;

typedef enum IMAP1_PasswordRegistrationFailure_PARAMETER {
    IMAP1_PasswordRegistrationFailure_PARAMETER_undetermined = 0,
    IMAP1_invalidFormat = 1,
    IMAP1_newPasswordsMismatch = 2
} IMAP1_PasswordRegistrationFailure_PARAMETER;

typedef ossBoolean      IMAP1_AbsentSubscriber_PARAMETER;

union IMAP1_All_PDU_Types_union {
    IMAP1_MessageType *pdu_MessageType;  /* IMAP1_MessageType_PDU */
    IMAP1_ExtensionContainer *pdu_ExtensionContainer;  
                                             /* IMAP1_ExtensionContainer_PDU */
    struct IMAP1_SS_SubscriptionOption *pdu_SS_SubscriptionOption;  
                                          /* IMAP1_SS_SubscriptionOption_PDU */
    struct IMAP1_UpdateLocationAreaArg *pdu_UpdateLocationAreaArg;  
                                          /* IMAP1_UpdateLocationAreaArg_PDU */
    struct IMAP1_UpdateLocationArg *pdu_UpdateLocationArg;  
                                              /* IMAP1_UpdateLocationArg_PDU */
    struct IMAP1_IsdnAddressString *pdu_UpdateLocationRes;  
                                              /* IMAP1_UpdateLocationRes_PDU */
    struct IMAP1_CancelLocationArg *pdu_CancelLocationArg;  
                                              /* IMAP1_CancelLocationArg_PDU */
    struct IMAP1_DetachIMSIArg *pdu_DetachIMSIArg;  
                                                  /* IMAP1_DetachIMSIArg_PDU */
    struct IMAP1_AttachIMSIArg *pdu_AttachIMSIArg;  
                                                  /* IMAP1_AttachIMSIArg_PDU */
    struct IMAP1_DeregisterMobileSubscriberArg *pdu_DeregisterMobileSubscriberArg;                                      /* IMAP1_DeregisterMobileSubscriberArg_PDU */
    struct IMAP1_InsertSubscriberDataArg *pdu_InsertSubscriberDataArg;  
                                        /* IMAP1_InsertSubscriberDataArg_PDU */
    struct IMAP1_DeleteSubscriberDataArg *pdu_DeleteSubscriberDataArg;  
                                        /* IMAP1_DeleteSubscriberDataArg_PDU */
    struct IMAP1_SendParametersArg *pdu_SendParametersArg;  
                                              /* IMAP1_SendParametersArg_PDU */
    struct IMAP1_SendParametersRes *pdu_SendParametersRes;  
                                              /* IMAP1_SendParametersRes_PDU */
    struct IMAP1_RegisterSSArg *pdu_RegisterSSArg;  
                                                  /* IMAP1_RegisterSSArg_PDU */
    struct IMAP1_RegisterSSRes *pdu_RegisterSSRes;  
                                                  /* IMAP1_RegisterSSRes_PDU */
    struct IMAP1_EraseSSArg *pdu_EraseSSArg;  /* IMAP1_EraseSSArg_PDU */
    struct IMAP1_EraseSSRes *pdu_EraseSSRes;  /* IMAP1_EraseSSRes_PDU */
    struct IMAP1_ActivateSSArg *pdu_ActivateSSArg;  
                                                  /* IMAP1_ActivateSSArg_PDU */
    struct IMAP1_ActivateSSRes *pdu_ActivateSSRes;  
                                                  /* IMAP1_ActivateSSRes_PDU */
    struct IMAP1_DeactivateSSArg *pdu_DeactivateSSArg;  
                                                /* IMAP1_DeactivateSSArg_PDU */
    struct IMAP1_DeactivateSSRes *pdu_DeactivateSSRes;  
                                                /* IMAP1_DeactivateSSRes_PDU */
    struct IMAP1_InterrogateSSArg *pdu_InterrogateSSArg;  
                                               /* IMAP1_InterrogateSSArg_PDU */
    struct IMAP1_InterrogateSSRes *pdu_InterrogateSSRes;  
                                               /* IMAP1_InterrogateSSRes_PDU */
    struct IMAP1_InvokeSSArg *pdu_InvokeSSArg;  /* IMAP1_InvokeSSArg_PDU */
    struct IMAP1_InvokeSSRes *pdu_InvokeSSRes;  /* IMAP1_InvokeSSRes_PDU */
    struct IMAP1_ForwardSsNotificationArg *pdu_ForwardSsNotificationArg;  
                                        /* IMAP1_ForwardSsNotificationArg_PDU */
    struct IMAP1_RegisterPasswordArg *pdu_RegisterPasswordArg;  
                                            /* IMAP1_RegisterPasswordArg_PDU */
    IMAP1_RegisterPasswordRes *pdu_RegisterPasswordRes;  
                                            /* IMAP1_RegisterPasswordRes_PDU */
    struct IMAP1_GetPasswordArg *pdu_GetPasswordArg;  
                                                 /* IMAP1_GetPasswordArg_PDU */
    IMAP1_GetPasswordRes *pdu_GetPasswordRes;  /* IMAP1_GetPasswordRes_PDU */
    IMAP1_ProcessUnstructuredSsDataArg *pdu_ProcessUnstructuredSsDataArg;  
                                        /* IMAP1_ProcessUnstructuredSsDataArg_PDU */
    struct IMAP1_ProcessUnstructuredSsDataRes *pdu_ProcessUnstructuredSsDataRes;                                        /* IMAP1_ProcessUnstructuredSsDataRes_PDU */
    struct IMAP1_SendInfoForIncomingCallArg *pdu_SendInfoForIncomingCallArg;  
                                        /* IMAP1_SendInfoForIncomingCallArg_PDU */
    struct IMAP1_SendInfoForOutgoingCallArg *pdu_SendInfoForOutgoingCallArg;  
                                        /* IMAP1_SendInfoForOutgoingCallArg_PDU */
    struct IMAP1_SendRoutingInformationArg *pdu_SendRoutingInformationArg;  
                                        /* IMAP1_SendRoutingInformationArg_PDU */
    struct IMAP1_SendRoutingInformationRes *pdu_SendRoutingInformationRes;  
                                        /* IMAP1_SendRoutingInformationRes_PDU */
    struct IMAP1_ProvideRoamingNumberArg *pdu_ProvideRoamingNumberArg;  
                                        /* IMAP1_ProvideRoamingNumberArg_PDU */
    struct IMAP1_IsdnAddressString *pdu_ProvideRoamingNumberRes;  
                                        /* IMAP1_ProvideRoamingNumberRes_PDU */
    struct IMAP1_CompleteCallArg *pdu_CompleteCallArg;  
                                                /* IMAP1_CompleteCallArg_PDU */
    struct IMAP1_ConnectToFollowingAddressArg *pdu_ConnectToFollowingAddressArg;                                        /* IMAP1_ConnectToFollowingAddressArg_PDU */
    struct IMAP1_PageArg *pdu_PageArg;  /* IMAP1_PageArg_PDU */
    struct IMAP1_SearchForMobileSubscriberArg *pdu_SearchForMobileSubscriberArg;                                        /* IMAP1_SearchForMobileSubscriberArg_PDU */
    struct IMAP1_SearchForMobileSubscriberRes *pdu_SearchForMobileSubscriberRes;                                        /* IMAP1_SearchForMobileSubscriberRes_PDU */
    struct IMAP1_PerformHandoverArg *pdu_PerformHandoverArg;  
                                             /* IMAP1_PerformHandoverArg_PDU */
    struct IMAP1_PerformHandoverRes *pdu_PerformHandoverRes;  
                                             /* IMAP1_PerformHandoverRes_PDU */
    struct IMAP1_PerformSubsequentHandoverArg *pdu_PerformSubsequentHandoverArg;                                        /* IMAP1_PerformSubsequentHandoverArg_PDU */
    struct IMAP1_PerformSubsequentHandoverRes *pdu_PerformSubsequentHandoverRes;                                        /* IMAP1_PerformSubsequentHandoverRes_PDU */
    struct IMAP1_ProcessAccessSignallingArg *pdu_ProcessAccessSignallingArg;  
                                        /* IMAP1_ProcessAccessSignallingArg_PDU */
    struct IMAP1_ForwardAccessSignallingArg *pdu_ForwardAccessSignallingArg;  
                                        /* IMAP1_ForwardAccessSignallingArg_PDU */
    struct IMAP1_SendHandoverReportArg *pdu_SendHandoverReportArg;  
                                          /* IMAP1_SendHandoverReportArg_PDU */
    struct IMAP1_RegisterChargingInformationArg *pdu_RegisterChargingInformationArg;                                    /* IMAP1_RegisterChargingInformationArg_PDU */
    struct IMAP1_ResetArg *pdu_ResetArg;  /* IMAP1_ResetArg_PDU */
    struct IMAP1_ActivateTraceModeArg *pdu_ActivateTraceModeArg;  
                                           /* IMAP1_ActivateTraceModeArg_PDU */
    struct IMAP1_DeactivateTraceModeArg *pdu_DeactivateTraceModeArg;  
                                         /* IMAP1_DeactivateTraceModeArg_PDU */
    struct IMAP1_TraceSubscriberActivityArg *pdu_TraceSubscriberActivityArg;  
                                        /* IMAP1_TraceSubscriberActivityArg_PDU */
    struct IMAP1_NoteInternalHandoverArg *pdu_NoteInternalHandoverArg;  
                                        /* IMAP1_NoteInternalHandoverArg_PDU */
    struct IMAP1_CheckIMEArg *pdu_CheckIMEArg;  /* IMAP1_CheckIMEArg_PDU */
    struct IMAP1_CheckIMEIRes *pdu_CheckIMEIRes;  /* IMAP1_CheckIMEIRes_PDU */
    struct IMAP1_AuthenticateArg *pdu_AuthenticateArg;  
                                                /* IMAP1_AuthenticateArg_PDU */
    struct IMAP1_AuthenticateRes *pdu_AuthenticateRes;  
                                                /* IMAP1_AuthenticateRes_PDU */
    struct IMAP1_ProvideIMSIRes *pdu_ProvideIMSIRes;  
                                                 /* IMAP1_ProvideIMSIRes_PDU */
    struct IMAP1_SetCipheringModeArg *pdu_SetCipheringModeArg;  
                                            /* IMAP1_SetCipheringModeArg_PDU */
    struct IMAP1_SendRoutingInfoForSMArg *pdu_SendRoutingInfoForSMArg;  
                                        /* IMAP1_SendRoutingInfoForSMArg_PDU */
    struct IMAP1_ForwardNewTMSIArg *pdu_ForwardNewTMSIArg;  
                                              /* IMAP1_ForwardNewTMSIArg_PDU */
    struct IMAP1_SendRoutingInfoForSMRes *pdu_SendRoutingInfoForSMRes;  
                                        /* IMAP1_SendRoutingInfoForSMRes_PDU */
    struct IMAP1_ForwardShortMessageArg *pdu_ForwardShortMessageArg;  
                                         /* IMAP1_ForwardShortMessageArg_PDU */
    struct IMAP1_SetMessageWaitingDataArg *pdu_SetMessageWaitingDataArg;  
                                        /* IMAP1_SetMessageWaitingDataArg_PDU */
    struct IMAP1_IMSI *pdu_NoteMSPresentArg;  /* IMAP1_NoteMSPresentArg_PDU */
    struct IMAP1_AlertServiceCentreArg *pdu_AlertServiceCentreArg;  
                                          /* IMAP1_AlertServiceCentreArg_PDU */
    struct IMAP1_ProcessAccessRequestArg *pdu_ProcessAccessRequestArg;  
                                        /* IMAP1_ProcessAccessRequestArg_PDU */
    struct IMAP1_ProcessAccessRequestRes *pdu_ProcessAccessRequestRes;  
                                        /* IMAP1_ProcessAccessRequestRes_PDU */
    struct IMAP1_BeginSubscriberActivityArg *pdu_BeginSubscriberActivityArg;  
                                        /* IMAP1_BeginSubscriberActivityArg_PDU */
    struct IMAP1_UnknownSubscriber *pdu_UnknownSubscriber;  
                                              /* IMAP1_UnknownSubscriber_PDU */
    struct IMAP1_UnknownBaseStation *pdu_UnknownBaseStation;  
                                             /* IMAP1_UnknownBaseStation_PDU */
    struct IMAP1_UnknownMSC *pdu_UnknownMSC;  /* IMAP1_UnknownMSC_PDU */
    struct IMAP1_UnknownLocArea *pdu_UnknownLocArea;  
                                                 /* IMAP1_UnknownLocArea_PDU */
    struct IMAP1_UnidentifiedSubscriber *pdu_UnidentifiedSubscriber;  
                                         /* IMAP1_UnidentifiedSubscriber_PDU */
    struct IMAP1_UnallocatedRoamingNumber *pdu_UnallocatedRoamingNumber;  
                                        /* IMAP1_UnallocatedRoamingNumber_PDU */
    struct IMAP1_UnknownEquipment *pdu_UnknownEquipment;  
                                               /* IMAP1_UnknownEquipment_PDU */
    struct IMAP1_RoamingNotAllowed *pdu_RoamingNotAllowed;  
                                              /* IMAP1_RoamingNotAllowed_PDU */
    struct IMAP1_IllegalMS *pdu_IllegalMS;  /* IMAP1_IllegalMS_PDU */
    struct IMAP1_BearerServiceNotProvisioned *pdu_BearerServiceNotProvisioned;                                          /* IMAP1_BearerServiceNotProvisioned_PDU */
    struct IMAP1_TeleserviceNotProvisioned *pdu_TeleserviceNotProvisioned;  
                                        /* IMAP1_TeleserviceNotProvisioned_PDU */
    struct IMAP1_InsufficientBearerCapabilities *pdu_InsufficientBearerCapabilities;                                    /* IMAP1_InsufficientBearerCapabilities_PDU */
    IMAP1_CallBarred_PARAMETER *pdu_CallBarred_PARAMETER;  
                                           /* IMAP1_CallBarred_PARAMETER_PDU */
    struct IMAP1_CallBarred *pdu_CallBarred;  /* IMAP1_CallBarred_PDU */
    struct IMAP1_ForwardingViolation *pdu_ForwardingViolation;  
                                            /* IMAP1_ForwardingViolation_PDU */
    IMAP1_CUG_Reject_PARAMETER *pdu_CUG_Reject_PARAMETER;  
                                           /* IMAP1_CUG_Reject_PARAMETER_PDU */
    struct IMAP1_CUG_Reject *pdu_CUG_Reject;  /* IMAP1_CUG_Reject_PDU */
    struct IMAP1_IllegalSS_Operation *pdu_IllegalSS_Operation;  
                                            /* IMAP1_IllegalSS_Operation_PDU */
    struct IMAP1_SS_ErrorStatus *pdu_SS_ErrorStatus;  
                                                 /* IMAP1_SS_ErrorStatus_PDU */
    struct IMAP1_SS_NotAvailable *pdu_SS_NotAvailable;  
                                                /* IMAP1_SS_NotAvailable_PDU */
    struct IMAP1_SS_SubscriptionViolation *pdu_SS_SubscriptionViolation;  
                                        /* IMAP1_SS_SubscriptionViolation_PDU */
    struct IMAP1_SS_Incompatibility_PARAMETER *pdu_SS_Incompatibility_PARAMETER;                                        /* IMAP1_SS_Incompatibility_PARAMETER_PDU */
    struct IMAP1_SS_Incompatibility *pdu_SS_Incompatibility;  
                                             /* IMAP1_SS_Incompatibility_PDU */
    struct IMAP1_FacilityNotSupported *pdu_FacilityNotSupported;  
                                           /* IMAP1_FacilityNotSupported_PDU */
    struct IMAP1_InvalidTargetBaseStation *pdu_InvalidTargetBaseStation;  
                                        /* IMAP1_InvalidTargetBaseStation_PDU */
    struct IMAP1_NoRadioResourceAvailable *pdu_NoRadioResourceAvailable;  
                                        /* IMAP1_NoRadioResourceAvailable_PDU */
    struct IMAP1_NoHandoverNumberAvailable *pdu_NoHandoverNumberAvailable;  
                                        /* IMAP1_NoHandoverNumberAvailable_PDU */
    struct IMAP1_SubsequentHandoverFailure *pdu_SubsequentHandoverFailure;  
                                        /* IMAP1_SubsequentHandoverFailure_PDU */
    IMAP1_AbsentSubscriber_PARAMETER *pdu_AbsentSubscriber_PARAMETER;  
                                     /* IMAP1_AbsentSubscriber_PARAMETER_PDU */
    struct IMAP1_AbsentSubscriber *pdu_AbsentSubscriber;  
                                               /* IMAP1_AbsentSubscriber_PDU */
    struct IMAP1_BusySubscriber *pdu_BusySubscriber;  
                                                 /* IMAP1_BusySubscriber_PDU */
    struct IMAP1_NoSubscriberReply *pdu_NoSubscriberReply;  
                                              /* IMAP1_NoSubscriberReply_PDU */
    struct IMAP1_RadioCongestion *pdu_RadioCongestion;  
                                                /* IMAP1_RadioCongestion_PDU */
    struct IMAP1_ImpossibleCallCompletion *pdu_ImpossibleCallCompletion;  
                                        /* IMAP1_ImpossibleCallCompletion_PDU */
    IMAP1_SM_DeliveryFailure_PARAMETER *pdu_SM_DeliveryFailure_PARAMETER;  
                                        /* IMAP1_SM_DeliveryFailure_PARAMETER_PDU */
    struct IMAP1_SM_DeliveryFailure *pdu_SM_DeliveryFailure;  
                                             /* IMAP1_SM_DeliveryFailure_PDU */
    struct IMAP1_MessageWaitingListFull *pdu_MessageWaitingListFull;  
                                         /* IMAP1_MessageWaitingListFull_PDU */
    struct IMAP1_SystemFailure *pdu_SystemFailure;  
                                                  /* IMAP1_SystemFailure_PDU */
    struct IMAP1_DataMissing *pdu_DataMissing;  /* IMAP1_DataMissing_PDU */
    struct IMAP1_UnexpectedDataValue *pdu_UnexpectedDataValue;  
                                            /* IMAP1_UnexpectedDataValue_PDU */
    IMAP1_PasswordRegistrationFailure_PARAMETER *pdu_PasswordRegistrationFailure_PARAMETER;                             /* IMAP1_PasswordRegistrationFailure_PARAMETER_PDU */
    struct IMAP1_PasswordRegistrationFailure *pdu_PasswordRegistrationFailure;                                          /* IMAP1_PasswordRegistrationFailure_PDU */
    struct IMAP1_NegativePasswordCheck *pdu_NegativePasswordCheck;  
                                          /* IMAP1_NegativePasswordCheck_PDU */
    struct IMAP1_NoRoamingNumberAvailable *pdu_NoRoamingNumberAvailable;  
                                        /* IMAP1_NoRoamingNumberAvailable_PDU */
    struct IMAP1_TracingBufferFull *pdu_TracingBufferFull;  
                                              /* IMAP1_TracingBufferFull_PDU */
    struct IMAP1_UpdateLocationArea *pdu_UpdateLocationArea;  
                                             /* IMAP1_UpdateLocationArea_PDU */
    struct IMAP1_UpdateLocation *pdu_UpdateLocation;  
                                                 /* IMAP1_UpdateLocation_PDU */
    struct IMAP1_CancelLocation *pdu_CancelLocation;  
                                                 /* IMAP1_CancelLocation_PDU */
    struct IMAP1_DetachIMSI *pdu_DetachIMSI;  /* IMAP1_DetachIMSI_PDU */
    struct IMAP1_AttachIMSI *pdu_AttachIMSI;  /* IMAP1_AttachIMSI_PDU */
    struct IMAP1_DeregisterMobileSubscriber *pdu_DeregisterMobileSubscriber;  
                                        /* IMAP1_DeregisterMobileSubscriber_PDU */
    struct IMAP1_InsertSubscriberData *pdu_InsertSubscriberData;  
                                           /* IMAP1_InsertSubscriberData_PDU */
    struct IMAP1_DeleteSubscriberData *pdu_DeleteSubscriberData;  
                                           /* IMAP1_DeleteSubscriberData_PDU */
    struct IMAP1_SendParameters *pdu_SendParameters;  
                                                 /* IMAP1_SendParameters_PDU */
    struct IMAP1_RegisterSS *pdu_RegisterSS;  /* IMAP1_RegisterSS_PDU */
    struct IMAP1_EraseSS *pdu_EraseSS;  /* IMAP1_EraseSS_PDU */
    struct IMAP1_ActivateSS *pdu_ActivateSS;  /* IMAP1_ActivateSS_PDU */
    struct IMAP1_DeactivateSS *pdu_DeactivateSS;  /* IMAP1_DeactivateSS_PDU */
    struct IMAP1_InterrogateSS *pdu_InterrogateSS;  
                                                  /* IMAP1_InterrogateSS_PDU */
    struct IMAP1_InvokeSS *pdu_InvokeSS;  /* IMAP1_InvokeSS_PDU */
    struct IMAP1_ForwardSsNotification *pdu_ForwardSsNotification;  
                                          /* IMAP1_ForwardSsNotification_PDU */
    struct IMAP1_RegisterPassword *pdu_RegisterPassword;  
                                               /* IMAP1_RegisterPassword_PDU */
    struct IMAP1_GetPassword *pdu_GetPassword;  /* IMAP1_GetPassword_PDU */
    struct IMAP1_ProcessUnstructuredSsData *pdu_ProcessUnstructuredSsData;  
                                        /* IMAP1_ProcessUnstructuredSsData_PDU */
    struct IMAP1_SendInfoForIncomingCall *pdu_SendInfoForIncomingCall;  
                                        /* IMAP1_SendInfoForIncomingCall_PDU */
    struct IMAP1_SendInfoForOutgoingCall *pdu_SendInfoForOutgoingCall;  
                                        /* IMAP1_SendInfoForOutgoingCall_PDU */
    struct IMAP1_SendRoutingInformation *pdu_SendRoutingInformation;  
                                         /* IMAP1_SendRoutingInformation_PDU */
    struct IMAP1_ProvideRoamingNumber *pdu_ProvideRoamingNumber;  
                                           /* IMAP1_ProvideRoamingNumber_PDU */
    struct IMAP1_CompleteCall *pdu_CompleteCall;  /* IMAP1_CompleteCall_PDU */
    struct IMAP1_ConnectToFollowingAddress *pdu_ConnectToFollowingAddress;  
                                        /* IMAP1_ConnectToFollowingAddress_PDU */
    struct IMAP1_ProcessCallWaiting *pdu_ProcessCallWaiting;  
                                             /* IMAP1_ProcessCallWaiting_PDU */
    struct IMAP1_Page *pdu_Page;  /* IMAP1_Page_PDU */
    struct IMAP1_SearchForMobileSubscriber *pdu_SearchForMobileSubscriber;  
                                        /* IMAP1_SearchForMobileSubscriber_PDU */
    struct IMAP1_PerformHandover *pdu_PerformHandover;  
                                                /* IMAP1_PerformHandover_PDU */
    struct IMAP1_SendEndSignal *pdu_SendEndSignal;  
                                                  /* IMAP1_SendEndSignal_PDU */
    struct IMAP1_PerformSubsequentHandover *pdu_PerformSubsequentHandover;  
                                        /* IMAP1_PerformSubsequentHandover_PDU */
    struct IMAP1_AllocateHandoverNumber *pdu_AllocateHandoverNumber;  
                                         /* IMAP1_AllocateHandoverNumber_PDU */
    struct IMAP1_SendHandoverReport *pdu_SendHandoverReport;  
                                             /* IMAP1_SendHandoverReport_PDU */
    struct IMAP1_ProcessAccessSignalling *pdu_ProcessAccessSignalling;  
                                        /* IMAP1_ProcessAccessSignalling_PDU */
    struct IMAP1_ForwardAccessSignalling *pdu_ForwardAccessSignalling;  
                                        /* IMAP1_ForwardAccessSignalling_PDU */
    struct IMAP1_RegisterChargingInformation *pdu_RegisterChargingInformation;                                          /* IMAP1_RegisterChargingInformation_PDU */
    struct IMAP1_Reset *pdu_Reset;  /* IMAP1_Reset_PDU */
    struct IMAP1_ForwardCheckSsIndication *pdu_ForwardCheckSsIndication;  
                                        /* IMAP1_ForwardCheckSsIndication_PDU */
    struct IMAP1_ActivateTraceMode *pdu_ActivateTraceMode;  
                                              /* IMAP1_ActivateTraceMode_PDU */
    struct IMAP1_DeactivateTraceMode *pdu_DeactivateTraceMode;  
                                            /* IMAP1_DeactivateTraceMode_PDU */
    struct IMAP1_TraceSubscriberActivity *pdu_TraceSubscriberActivity;  
                                        /* IMAP1_TraceSubscriberActivity_PDU */
    struct IMAP1_NoteInternalHandover *pdu_NoteInternalHandover;  
                                           /* IMAP1_NoteInternalHandover_PDU */
    struct IMAP1_CheckIMEI *pdu_CheckIMEI;  /* IMAP1_CheckIMEI_PDU */
    struct IMAP1_Authenticate *pdu_Authenticate;  /* IMAP1_Authenticate_PDU */
    struct IMAP1_ProvideIMSI *pdu_ProvideIMSI;  /* IMAP1_ProvideIMSI_PDU */
    struct IMAP1_ForwardNewTMSI *pdu_ForwardNewTMSI;  
                                                 /* IMAP1_ForwardNewTMSI_PDU */
    struct IMAP1_SetCipheringMode *pdu_SetCipheringMode;  
                                               /* IMAP1_SetCipheringMode_PDU */
    struct IMAP1_SendRoutingInfoForSM *pdu_SendRoutingInfoForSM;  
                                           /* IMAP1_SendRoutingInfoForSM_PDU */
    struct IMAP1_ForwardShortMessage *pdu_ForwardShortMessage;  
                                            /* IMAP1_ForwardShortMessage_PDU */
    struct IMAP1_SetMessageWaitingData *pdu_SetMessageWaitingData;  
                                          /* IMAP1_SetMessageWaitingData_PDU */
    struct IMAP1_NoteMSPresent *pdu_NoteMSPresent;  
                                                  /* IMAP1_NoteMSPresent_PDU */
    struct IMAP1_AlertServiceCentre *pdu_AlertServiceCentre;  
                                             /* IMAP1_AlertServiceCentre_PDU */
    struct IMAP1_ProcessAccessRequest *pdu_ProcessAccessRequest;  
                                           /* IMAP1_ProcessAccessRequest_PDU */
    struct IMAP1_BeginSubscriberActivity *pdu_BeginSubscriberActivity;  
                                        /* IMAP1_BeginSubscriberActivity_PDU */
};

enum IMAP1_ExtensionSet_ExtensionType_PDUs {
    IMAP1_PDU_ExtensionSet_ExtensionType_UNKNOWN = 0,
    IMAP1_PDU_ExtensionSet_ExtensionType_MAX = INT_MAX
};

union IMAP1_ExtensionSet_ExtensionType_union {
    IMAP1_All_PDU_Types_union other;  /* for known extensions */
};

typedef struct IMAP1_ExtensionSet_ExtensionType {
    IMAP1_ExtensionSet_ExtensionType_PDUs pduNum;
    OssBuf          encoded;
    IMAP1_ExtensionSet_ExtensionType_union decoded;
} IMAP1_ExtensionSet_ExtensionType;

typedef struct IMAP1_PrivateExtension {
    unsigned char   bit_mask;
#       define      IMAP1_extType_present 0x80
    IMAP1__ObjectID extId;
    IMAP1_ExtensionSet_ExtensionType extType;  /* optional; set in bit_mask
                                                * IMAP1_extType_present if
                                                * present */
} IMAP1_PrivateExtension;

typedef struct IMAP1_PrivateExtensionList_ {
    struct IMAP1_PrivateExtensionList_ *next;
    IMAP1_PrivateExtension value;
} *IMAP1_PrivateExtensionList;

		// digits 0 through 9, two digits per octet,
		// each digit encoded 0000 to 1001,
		// 1111 used as filler when there is an odd number of digit.
typedef struct IMAP1_AddressString {
    unsigned short  length;
    unsigned char   value[20];
} IMAP1_AddressString;

		// see internal description in section 6.4.1
typedef struct IMAP1_IsdnAddressString {
    unsigned short  length;
    unsigned char   value[9];
} IMAP1_IsdnAddressString;

typedef enum IMAP1_ProtocolId {
    IMAP1_gsm_0408 = 1,
    IMAP1_gsm_0806 = 2,
    IMAP1_gsm_0808_bssmap = 3,
    IMAP1_ets300102_1 = 4
} IMAP1_ProtocolId;

typedef struct IMAP1_SignalInfo {
    unsigned short  length;
    unsigned char   value[200];
} IMAP1_SignalInfo;

typedef struct IMAP1_ExternalSignalInfo {
    IMAP1_ProtocolId protocolId;
    IMAP1_SignalInfo signalInfo;
} IMAP1_ExternalSignalInfo;

// data types for numbering and identification
typedef struct IMAP1_IMSI {
    unsigned short  length;
    unsigned char   value[8];
} IMAP1_IMSI;

		// MCC, MNC, MSIN concatenated in this order
typedef struct IMAP1_TMSI {
    unsigned short  length;
    unsigned char   value[4];
} IMAP1_TMSI;

typedef struct IMAP1_SubscriberId {
    unsigned short  choice;
#       define      IMAP1_SubscriberId_imsi_chosen 1
#       define      IMAP1_tmsi_chosen 2
    union _union {
        IMAP1_IMSI      imsi;  /* to choose, set choice to
                                * IMAP1_SubscriberId_imsi_chosen */
        IMAP1_TMSI      tmsi;  /* to choose, set choice to IMAP1_tmsi_chosen */
    } u;
} IMAP1_SubscriberId;

//
typedef struct IMAP1_IMEI {
    unsigned short  length;
    unsigned char   value[8];
} IMAP1_IMEI;

		// Internal Structure
		// Type Approval Code : 6 digits
		// manufacturer place : 2 digits
		// individual serial number : 6 digits
		// unassigned : 1 digit
typedef struct IMAP1_LocAreaId {
    unsigned short  length;
    unsigned char   value[5];
} IMAP1_LocAreaId;

		// Octets coded according to
		// Recommendation GSM 04.08
		// Internal structure
		// Mobile Country Code	: 3 digits according to Rec E.212
		//		: 1 filler (1111)
		// Mobile Network Code	: 2 digits according to Rec E.212
		// Location Area Code	: 2 octets according to GSM 04.08
typedef struct IMAP1_LocationInfo {
    unsigned short  choice;
#       define      IMAP1_LocationInfo_roamingNumber_chosen 1
#       define      IMAP1_mscNumber_chosen 2
    union _union {
        IMAP1_IsdnAddressString roamingNumber;  /* to choose, set choice to
                                   * IMAP1_LocationInfo_roamingNumber_chosen */
        IMAP1_IsdnAddressString mscNumber;  /* to choose, set choice to
                                             * IMAP1_mscNumber_chosen */
    } u;
} IMAP1_LocationInfo;

typedef IMAP1_IMSI      IMAP1_HlrId;

		// leading digits of IMSI
typedef struct IMAP1_HlrList_ {
    struct IMAP1_HlrList_ *next;
    IMAP1_HlrId     value;
} *IMAP1_HlrList;

typedef struct IMAP1_LMSI {
    unsigned short  length;
    unsigned char   value[4];
} IMAP1_LMSI;

typedef struct IMAP1_GlobalCellId {
    unsigned short  length;
    unsigned char   value[7];
} IMAP1_GlobalCellId;

		// Octets coded according to
		// Recommendation GSM 04.08
		// Internal structure
		// Mobile Country Code	: 3 digits according to Rec E.212
		//		: 1 filler (1111)
		// Mobile Network Code	: 2 digits according to Rec E.212
		// Location Area Code	: 2 octets (LAC) according 
		// to GSM 04.08
		// Cell identity	: 2 octets (CI) according to GSM 04.08

// data types for subscriber management

//
typedef struct IMAP1_Category {
    unsigned short  length;
    unsigned char   value[1];
} IMAP1_Category;

		// internal structure defined in CCITT Rec Q.763
typedef enum IMAP1_EquipStatus {
    IMAP1_white_listed = 0,
    IMAP1_black_listed = 1,
    IMAP1_grey_listed = 2
} IMAP1_EquipStatus;

typedef struct IMAP1_BearerServiceCode {
    unsigned short  length;
    unsigned char   value[1];
} IMAP1_BearerServiceCode;

		// Internal structure according to table 6.4/1
		// BIT 8 Transparency indicator (if applicable)
		//     0 transparent
		//     1 non transparent

		// BIT 7654  Bearer service group
		//    0001 3.1 kHz ex PLMN
		//    0010 Circuit data asynchronous
		//    0011 Circuit data synchronous
		//    0100 PAD access c.d.a
		//    0101 Packet data synchrounous
		//    0110 Alternate speech/c.d.a
		//    0111 Alternate speech c.d.s
		//    1000 Speech followed by data c.d.a
		//    1001 Speech followed by data c.d.s
		//    1111 12.6 kb/s unrestricted digital

		// BIT 321  Rate (when applicable)
		//    000 Any
		//    001 300-300 b/s
		//    010 1200-1200 b/s
		//    011 1200-75 b/s
		//    100 2400-2400 b/s
		//    101 4800-4800 b/s
		//    110 9600-9600 b/s

		// Bits 321 = 000 can be used to refer to all
		// the bearer services of the corresponding group.
		// Value "00000000" can be used to refer to all the defined
		// bearer services.
		// For the codes referring to a group or all bearer services
		// the Transparency Indicator is not applicable and has to be set to "0"
typedef struct IMAP1_BearerServiceList_ {
    struct IMAP1_BearerServiceList_ *next;
    IMAP1_BearerServiceCode value;
} *IMAP1_BearerServiceList;

typedef struct IMAP1_TeleserviceCode {
    unsigned short  length;
    unsigned char   value[1];
} IMAP1_TeleserviceCode;

		// Internal structure according to table 6.4/2
		// Bit 8-5 encode the teleservice group

		// Bit 4-1 = 0000 can be used to refer to all the
		// teleservices of the corresponding group.
		// Value "00000000" can be used to refer to all the defined
		// teleservices
typedef struct IMAP1_TeleserviceList_ {
    struct IMAP1_TeleserviceList_ *next;
    IMAP1_TeleserviceCode value;
} *IMAP1_TeleserviceList;

typedef struct IMAP1_BasicServiceCode {
    unsigned short  choice;
#       define      IMAP1_bearerService_chosen 1
#       define      IMAP1_teleservice_chosen 2
    union _union {
        IMAP1_BearerServiceCode bearerService;  /* to choose, set choice to
                                                * IMAP1_bearerService_chosen */
        IMAP1_TeleserviceCode teleservice;  /* to choose, set choice to
                                             * IMAP1_teleservice_chosen */
    } u;
} IMAP1_BasicServiceCode;

typedef struct IMAP1_BasicServiceList_ {
    struct IMAP1_BasicServiceList_ *next;
    IMAP1_BasicServiceCode value;
} *IMAP1_BasicServiceList;

//
typedef enum IMAP1_SubscriberStatus {
    IMAP1_serviceGranted = 0,
    IMAP1_operatorOGCallBarring = 1
} IMAP1_SubscriberStatus;

typedef struct IMAP1_SS_Code {
    unsigned short  length;
    unsigned char   value[1];
} IMAP1_SS_Code;

		// Internal structure according to
		// table 6.4/3
		// Bit 8-5
		// 0001 Number Identification services
		// 0010 Forwarding services
		// 0011 Call offering services
		// 0100 Call completion services
		// 0101 Multi-party services
		// 0110 Community of interest services
		// 0111 Charging services
		// 1000 Additional information transfer services
		// 1001 Call restriction services
		// Bit 4-1 = 0000 can be use to refer to
		// a group of supplementary services
		// eg, "00100000" can be used to refer to all
		// forwarding services
		// "00101000" can be used to refer to all
		// conditional forwarding services
		// "00000000" can be used to refer to all
		// supplementary services
typedef struct IMAP1_SS_CodeList_ {
    struct IMAP1_SS_CodeList_ *next;
    IMAP1_SS_Code   value;
} *IMAP1_SS_CodeList;

typedef struct IMAP1_SS_Status {
    unsigned short  length;
    unsigned char   value[1];
} IMAP1_SS_Status;

   // bits 876543: 000000 (unused)

   // bits 21
   // 00  CUG only facilities
   // 01  CUG with outgoing access
   // 10  CUG with incoming access
   // 11  CUG with both outgoing and incoming access
typedef struct IMAP1_ForwardingInfo {
    unsigned char   bit_mask;
#       define      IMAP1_ForwardingInfo_ss_Code_present 0x80
    IMAP1_SS_Code   ss_Code;  /* optional; set in bit_mask
                               * IMAP1_ForwardingInfo_ss_Code_present if
                               * present */
    struct IMAP1_ForwardingFeatureList_ *forwardingFeatureList;
} IMAP1_ForwardingInfo;

typedef struct IMAP1_CallBarringInfo {
    IMAP1_SS_Code   ss_Code;
    struct IMAP1_CallBarringFeatureList_ *callBarringFeatureList;
} IMAP1_CallBarringInfo;

typedef struct IMAP1_CUG_Info {
    unsigned char   bit_mask;
#       define      IMAP1_cug_FeatureList_present 0x80
    struct IMAP1_CUG_SubscriptionList_ *cug_SubscriptionList;
    struct IMAP1_CUG_FeatureList_ *cug_FeatureList;  /* optional; set in
                                   * bit_mask IMAP1_cug_FeatureList_present if
                                   * present */
} IMAP1_CUG_Info;

	//
typedef struct IMAP1_SS_Data {
    unsigned char   bit_mask;
#       define      IMAP1_SS_Data_ss_Status_present 0x80
    IMAP1_SS_Code   ss_Code;
    IMAP1_SS_Status ss_Status;  /* optional; set in bit_mask
                                 * IMAP1_SS_Data_ss_Status_present if present */
} IMAP1_SS_Data;

		// Bit 8-4 Unused
		// Bit 3   Provision indicator
		//     0 : Not provisioned
		//     1 : Provisioned
		// Bit 2   Registration indicator (if applicable)
		//     0 : Not Registered
		//     1 : Registered
		// Bit 1   Activation indicator (If applicable)
		//     0 : Not Active
		//     1 : Active
typedef struct IMAP1_SS_Information {
    unsigned short  choice;
#       define      IMAP1_forwardingInfo_chosen 1
#       define      IMAP1_callBarringInfo_chosen 2
#       define      IMAP1_cug_Info_chosen 3
#       define      IMAP1_ss_Data_chosen 4
    union _union {
        IMAP1_ForwardingInfo forwardingInfo;  /* to choose, set choice to
                                               * IMAP1_forwardingInfo_chosen */
        IMAP1_CallBarringInfo callBarringInfo;  /* to choose, set choice to
                                              * IMAP1_callBarringInfo_chosen */
        IMAP1_CUG_Info  cug_Info;  /* to choose, set choice to
                                    * IMAP1_cug_Info_chosen */
        IMAP1_SS_Data   ss_Data;  /* to choose, set choice to
                                   * IMAP1_ss_Data_chosen */
    } u;
} IMAP1_SS_Information;

typedef struct IMAP1_SS_InfoList_ {
    struct IMAP1_SS_InfoList_ *next;
    IMAP1_SS_Information value;
} *IMAP1_SS_InfoList;

typedef struct IMAP1_SS_DataList_ {
    struct IMAP1_SS_DataList_ *next;
    IMAP1_SS_Data   value;
} *IMAP1_SS_DataList;

typedef enum IMAP1_SS_Request {
    IMAP1_registration = 0,
    IMAP1_erasure = 1,
    IMAP1_activation = 2,
    IMAP1_deactivation = 3,
    IMAP1_interrogation = 4,
    IMAP1_invoke = 5
} IMAP1_SS_Request;

		// Bit 8-7  Notification to forwarding party
		//          00  No notification
		//          01  notification with calling number identity
		//          10  notification without calling number identity
		// Bit 6-5  Notification to calling party
		//          00 No notification
		//          01 Notification with forwarded-to number
		//          10 Notification without forwarded-to number
typedef struct IMAP1_UserToUserServiceIndicator {
    unsigned short  length;
    unsigned char   value[1];
} IMAP1_UserToUserServiceIndicator;

		// Bit 8   : service 1
		// Bit 7   : service 2
		// Bit 6   : service 3
		// Bit 5-1 : Reserved
		// Bit 8 to 6 coded "1" if the service
		// is available to the subscriber
typedef unsigned short  IMAP1_MaximumConfereesNumber;

typedef enum IMAP1_HuntGroupAccessSelectionOrder {
    IMAP1_random = 0,
    IMAP1_sequential = 1
} IMAP1_HuntGroupAccessSelectionOrder;

typedef struct IMAP1_SS_SubscriptionOption {
    unsigned short  choice;
#       define      IMAP1_perCallBasis_chosen 1
#       define      IMAP1_notificationToHeldRetrievedParty_chosen 2
#       define      IMAP1_userToUserServiceIndicator_chosen 3
#       define      IMAP1_maximumConfereesNumber_chosen 4
#       define      IMAP1_huntGroupAccessSelectionOrder_chosen 5
    union _union {
        ossBoolean      perCallBasis;  /* to choose, set choice to
                                        * IMAP1_perCallBasis_chosen */
        ossBoolean      notificationToHeldRetrievedParty;  /* to choose, set
                                   * choice to
                             * IMAP1_notificationToHeldRetrievedParty_chosen */
        IMAP1_UserToUserServiceIndicator userToUserServiceIndicator;  /* to
                                   * choose, set choice to
                                   * IMAP1_userToUserServiceIndicator_chosen */
        IMAP1_MaximumConfereesNumber maximumConfereesNumber;  /* to choose, set
                                   * choice to
                                   * IMAP1_maximumConfereesNumber_chosen */
        IMAP1_HuntGroupAccessSelectionOrder huntGroupAccessSelectionOrder;  
                                        /* to choose, set choice to
                                * IMAP1_huntGroupAccessSelectionOrder_chosen */
    } u;
} IMAP1_SS_SubscriptionOption;

typedef struct IMAP1_ForwardingOptions {
    unsigned short  length;
    unsigned char   value[1];
} IMAP1_ForwardingOptions;

typedef unsigned short  IMAP1_NoReplyConditionTime;

typedef unsigned short  IMAP1_NumberOfConferees;

//
typedef struct IMAP1_BasicServiceGroupList_ {
    struct IMAP1_BasicServiceGroupList_ *next;
    IMAP1_BasicServiceCode value;
} *IMAP1_BasicServiceGroupList;

typedef unsigned short  IMAP1_CUG_Index;

   // The internal structure is defined in ETS 300 138.
typedef struct IMAP1_CUG_Interlock {
    unsigned short  length;
    unsigned char   value[4];
} IMAP1_CUG_Interlock;

typedef enum IMAP1_IntraCUG_Options {
    IMAP1_noCUG_Restrictions = 0,
    IMAP1_cugIC_CallBarred = 1,
    IMAP1_cugOG_CallBarred = 2
} IMAP1_IntraCUG_Options;

typedef struct IMAP1_CUG_Subscription {
    unsigned char   bit_mask;
#       define      IMAP1_basicServiceGroupList_present 0x80
    IMAP1_CUG_Index cug_Index;
    IMAP1_CUG_Interlock cug_Interlock;
    IMAP1_IntraCUG_Options intraCUG_Options;
    struct IMAP1_BasicServiceGroupList_ *basicServiceGroupList;  /* optional;
                                   * set in bit_mask
                                   * IMAP1_basicServiceGroupList_present if
                                   * present */
} IMAP1_CUG_Subscription;

typedef struct IMAP1_CUG_SubscriptionList_ {
    struct IMAP1_CUG_SubscriptionList_ *next;
    IMAP1_CUG_Subscription value;
} *IMAP1_CUG_SubscriptionList;

typedef struct IMAP1_InterCUG_Restrictions {
    unsigned short  length;
    unsigned char   value[1];
} IMAP1_InterCUG_Restrictions;

typedef struct IMAP1_CUG_Feature {
    unsigned char   bit_mask;
#       define      IMAP1_CUG_Feature_basicService_present 0x80
#       define      IMAP1_preferentialCUG_Indicator_present 0x40
    IMAP1_BasicServiceCode basicService;  /* optional; set in bit_mask
                                    * IMAP1_CUG_Feature_basicService_present if
                                    * present */
    IMAP1_CUG_Index preferentialCUG_Indicator;  /* optional; set in bit_mask
                                   * IMAP1_preferentialCUG_Indicator_present if
                                   * present */
    IMAP1_InterCUG_Restrictions interCUG_Restrictions;
} IMAP1_CUG_Feature;

typedef struct IMAP1_CUG_FeatureList_ {
    struct IMAP1_CUG_FeatureList_ *next;
    IMAP1_CUG_Feature value;
} *IMAP1_CUG_FeatureList;

typedef struct IMAP1_ForwardingData {
    unsigned char   bit_mask;
#       define      IMAP1_ForwardingData_forwardingOptions_present 0x80
    IMAP1_IsdnAddressString forwardedToNumber;
    IMAP1_ForwardingOptions forwardingOptions;  /* optional; set in bit_mask
                            * IMAP1_ForwardingData_forwardingOptions_present if
                            * present */
} IMAP1_ForwardingData;

typedef struct IMAP1_ForwardingFeature {
    unsigned char   bit_mask;
#       define      IMAP1_ForwardingFeature_basicService_present 0x80
#       define      IMAP1_ForwardingFeature_forwardedToNumber_present 0x40
#       define      IMAP1_ForwardingFeature_forwardingOptions_present 0x20
#       define      IMAP1_ForwardingFeature_noReplyConditionTime_present 0x10
    IMAP1_BasicServiceCode basicService;  /* optional; set in bit_mask
                              * IMAP1_ForwardingFeature_basicService_present if
                              * present */
    IMAP1_SS_Status ss_Status;
    IMAP1_IsdnAddressString forwardedToNumber;  /* optional; set in bit_mask
                         * IMAP1_ForwardingFeature_forwardedToNumber_present if
                         * present */
    IMAP1_ForwardingOptions forwardingOptions;  /* optional; set in bit_mask
                         * IMAP1_ForwardingFeature_forwardingOptions_present if
                         * present */
    IMAP1_NoReplyConditionTime noReplyConditionTime;  /* optional; set in
                                   * bit_mask
                      * IMAP1_ForwardingFeature_noReplyConditionTime_present if
                      * present */
} IMAP1_ForwardingFeature;

typedef struct IMAP1_ForwardingFeatureList_ {
    struct IMAP1_ForwardingFeatureList_ *next;
    IMAP1_ForwardingFeature value;
} *IMAP1_ForwardingFeatureList;

typedef struct IMAP1_CallBarringFeature {
    unsigned char   bit_mask;
#       define      IMAP1_basicServiceCode_present 0x80
    IMAP1_BasicServiceCode basicServiceCode;  /* optional; set in bit_mask
                                               * IMAP1_basicServiceCode_present
                                               * if present */
    IMAP1_SS_Status ss_Status;
} IMAP1_CallBarringFeature;

typedef struct IMAP1_CallBarringFeatureList_ {
    struct IMAP1_CallBarringFeatureList_ *next;
    IMAP1_CallBarringFeature value;
} *IMAP1_CallBarringFeatureList;

typedef struct IMAP1_SubscriberData {
    unsigned char   bit_mask;
#       define      IMAP1_SubscriberData_msIsdn_present 0x80
#       define      IMAP1_SubscriberData_category_present 0x40
#       define      IMAP1_SubscriberData_subscriberStatus_present 0x20
#       define      IMAP1_SubscriberData_bearerServiceList_present 0x10
#       define      IMAP1_SubscriberData_teleserviceList_present 0x08
#       define      IMAP1_SubscriberData_provisonedSS_present 0x04
    IMAP1_IsdnAddressString msIsdn;  /* optional; set in bit_mask
                                      * IMAP1_SubscriberData_msIsdn_present if
                                      * present */
    IMAP1_Category  category;  /* optional; set in bit_mask
                                * IMAP1_SubscriberData_category_present if
                                * present */
    IMAP1_SubscriberStatus subscriberStatus;  /* optional; set in bit_mask
                             * IMAP1_SubscriberData_subscriberStatus_present if
                             * present */
    struct IMAP1_BearerServiceList_ *bearerServiceList;  /* optional; set in
                                   * bit_mask
                            * IMAP1_SubscriberData_bearerServiceList_present if
                            * present */
    struct IMAP1_TeleserviceList_ *teleserviceList;  /* optional; set in
                                   * bit_mask
                              * IMAP1_SubscriberData_teleserviceList_present if
                              * present */
    struct IMAP1_SS_InfoList_ *provisonedSS;  /* optional; set in bit_mask
                                 * IMAP1_SubscriberData_provisonedSS_present if
                                 * present */
} IMAP1_SubscriberData;

typedef struct IMAP1_SS_Notification {
    unsigned short  length;
    unsigned char   value[1];
} IMAP1_SS_Notification;

typedef enum IMAP1_GuidanceInfo {
    IMAP1_enterPW = 0,
    IMAP1_enterNewPW = 1,
    IMAP1_enterNewPW_Again = 2,
    IMAP1_badPW_TryAgain = 3,
    IMAP1_badPW_FormatTryAgain = 4
} IMAP1_GuidanceInfo;

// Data types for call parameters
typedef struct IMAP1_CallReference {
    unsigned short  length;
    unsigned char   value[3];
} IMAP1_CallReference;

typedef enum IMAP1_CallType {
    IMAP1_incomingCall = 0,
    IMAP1_forwardedCallPortion = 1,
    IMAP1_reroutedCallPortion = 2,
    IMAP1_outgoingCall = 3,
    IMAP1_ss_Request = 4
} IMAP1_CallType;

typedef unsigned int    IMAP1_Charge;

typedef struct IMAP1_SS_ChargingData {
    unsigned char   bit_mask;
#       define      IMAP1_SS_ChargingData_charge_present 0x80
    IMAP1_SS_Code   ss_Code;
    IMAP1_SS_Request ss_Request;
    IMAP1_Charge    charge;  /* optional; set in bit_mask
                              * IMAP1_SS_ChargingData_charge_present if
                              * present */
} IMAP1_SS_ChargingData;

typedef struct IMAP1_SS_ChargingInfo_ {
    struct IMAP1_SS_ChargingInfo_ *next;
    IMAP1_SS_ChargingData value;
} *IMAP1_SS_ChargingInfo;

typedef unsigned int    IMAP1_CallDuration;

typedef struct IMAP1_CallDateTime {
    unsigned short  length;
    unsigned char   value[24];
} IMAP1_CallDateTime;

		// local time and time differential
		// to UTC time
typedef unsigned short  IMAP1_PacketDataVolume;

typedef enum IMAP1_ChargingUnit {
    IMAP1_specialDrawingRights = 0
} IMAP1_ChargingUnit;

typedef enum IMAP1_CallStatus {
    IMAP1_CallStatus_undetermined = 0,
    IMAP1_successfulNormalTermination = 1,
    IMAP1_successfulAbnormalTermination = 2,
    IMAP1_forwarded = 4,
    IMAP1_forwardedWithAbnormalTermination = 5,
    IMAP1_rerouted = 6,
    IMAP1_reroutedWithAbnormalTermination = 7,
    IMAP1_unsuccessfulNoRadioContact = 8,
    IMAP1_unsuccessfulNoResponse = 9,
    IMAP1_unsuccessfulBusySubscriber = 10,
    IMAP1_unsuccessfulSystemFailed = 11,
    IMAP1_unsuccessfulSusbcriptionViolation = 12,
    IMAP1_unsuccessfulUnsupportedFacility = 13
} IMAP1_CallStatus;

		// Data types for radio parameters
typedef unsigned short  IMAP1_NumberOfForwarding;

typedef struct IMAP1_ChannelType {
    unsigned short  length;
    unsigned char   value[10];
} IMAP1_ChannelType;

		// Concatenation of
		// Speech data indicator
		// Channel rate
		// Speech encoding algorithm/data rate
		// + transparency indicator
		// as defined in Recommendation GSM 08.08
typedef struct IMAP1_ClassmarkInformation {
    unsigned short  length;
    unsigned char   value[2];
} IMAP1_ClassmarkInformation;

		// classmark information element type 1 or 2
		// contents as defined in Recommendation 08.08
typedef struct IMAP1_HandoverPriority {
    unsigned short  length;
    unsigned char   value[1];
} IMAP1_HandoverPriority;

		// internal structure defined in Recommendation GSM 08.08
typedef enum IMAP1_HandoverType {
    IMAP1_interBSS = 0,
    IMAP1_intraBSS = 1
} IMAP1_HandoverType;

typedef struct IMAP1_Rand {
    unsigned short  length;
    unsigned char   value[16];
} IMAP1_Rand;

typedef struct IMAP1_Sres {
    unsigned short  length;
    unsigned char   value[4];
} IMAP1_Sres;

typedef struct IMAP1_Kc {
    unsigned short  length;
    unsigned char   value[8];
} IMAP1_Kc;

// Data types for security procedures
typedef struct IMAP1_AuthenticationSet {
    IMAP1_Rand      rand;
    IMAP1_Sres      sres;
    IMAP1_Kc        kc;
} IMAP1_AuthenticationSet;

typedef struct IMAP1_Ki {
    unsigned short  length;
    unsigned char   value[16];
} IMAP1_Ki;

typedef struct IMAP1_CKSN {
    unsigned short  length;
    unsigned char   value[1];
} IMAP1_CKSN;

		// bits 8-4 unused
		// bits 3-1 coded as specified in recommendation GSM 04.08
typedef enum IMAP1_CipheringMode {
    IMAP1_noEncryption = 1,
    IMAP1_version1_GSM = 2
} IMAP1_CipheringMode;

// Data types for short message services
typedef struct IMAP1_SM_RP_DA {
    unsigned short  choice;
#       define      IMAP1_SM_RP_DA_imsi_chosen 1
#       define      IMAP1_lmsi_chosen 2
#       define      IMAP1_SM_RP_DA_roamingNumber_chosen 3
#       define      IMAP1_SM_RP_DA_serviceCentreAddress_chosen 4
    union _union {
        IMAP1_IMSI      imsi;  /* to choose, set choice to
                                * IMAP1_SM_RP_DA_imsi_chosen */
        IMAP1_LMSI      lmsi;  /* to choose, set choice to IMAP1_lmsi_chosen */
        IMAP1_IsdnAddressString roamingNumber;  /* to choose, set choice to
                                       * IMAP1_SM_RP_DA_roamingNumber_chosen */
        IMAP1_AddressString serviceCentreAddress;  /* to choose, set choice to
                                * IMAP1_SM_RP_DA_serviceCentreAddress_chosen */
    } u;
} IMAP1_SM_RP_DA;

typedef struct IMAP1_SM_RP_OA {
    unsigned short  choice;
#       define      IMAP1_msIsdn_chosen 1
#       define      IMAP1_SM_RP_OA_serviceCentreAddress_chosen 2
    union _union {
        IMAP1_IsdnAddressString msIsdn;  /* to choose, set choice to
                                          * IMAP1_msIsdn_chosen */
        IMAP1_AddressString serviceCentreAddress;  /* to choose, set choice to
                                * IMAP1_SM_RP_OA_serviceCentreAddress_chosen */
    } u;
} IMAP1_SM_RP_OA;

typedef struct IMAP1_SM_RP_UI {
    unsigned short  length;
    unsigned char   value[200];
} IMAP1_SM_RP_UI;

// fault recovery, call tracing
typedef struct IMAP1_TraceReference {
    unsigned short  length;
    unsigned char   value[2];
} IMAP1_TraceReference;

typedef unsigned short  IMAP1_TraceType;
#define                     IMAP1_allEvents 0U
#define                     IMAP1_onlyCalls 1U
#define                     IMAP1_eventSet1 2U
#define                     IMAP1_eventSet254 255U

		// Identifiers eventSet1 to eventSet254 corresponds to
		// sets of events pre-defined by each operator.
typedef enum IMAP1_NetworkResource {
    IMAP1_pLMN = 0,
    IMAP1_hLR = 1,
    IMAP1_vLR = 2,
    IMAP1_previous_VLR = 3,
    IMAP1_controlling_MSC = 4,
    IMAP1_vMSC = 5,
    IMAP1_eIR = 6,
    IMAP1_radioSubSystem = 7
} IMAP1_NetworkResource;

// other data types
typedef enum IMAP1_RequestParameter {
    IMAP1_request_IMSI = 0,
    IMAP1_request_AuthenticationSet = 1,
    IMAP1_request_SubscriberData = 2,
    IMAP1_request_CUG_Information = 3,
    IMAP1_request_Ki = 4
} IMAP1_RequestParameter;

typedef struct IMAP1_RequestParameters_ {
    struct IMAP1_RequestParameters_ *next;
    IMAP1_RequestParameter value;
} *IMAP1_RequestParameters;

typedef struct IMAP1_SentParameter {
    unsigned short  choice;
#       define      IMAP1_SentParameter_imsi_chosen 1
#       define      IMAP1_authenticationSet_chosen 2
#       define      IMAP1_susbcriberData_chosen 3
#       define      IMAP1_cug_information_chosen 4
#       define      IMAP1_ki_chosen 5
    union _union {
        IMAP1_IMSI      imsi;  /* to choose, set choice to
                                * IMAP1_SentParameter_imsi_chosen */
        IMAP1_AuthenticationSet authenticationSet;  /* to choose, set choice to
                                            * IMAP1_authenticationSet_chosen */
        IMAP1_SubscriberData susbcriberData;  /* to choose, set choice to
                                               * IMAP1_susbcriberData_chosen */
        IMAP1_CUG_Info  cug_information;  /* to choose, set choice to
                                           * IMAP1_cug_information_chosen */
        IMAP1_Ki        ki;  /* to choose, set choice to IMAP1_ki_chosen */
    } u;
} IMAP1_SentParameter;

typedef struct IMAP1_SentParameters_ {
    struct IMAP1_SentParameters_ *next;
    IMAP1_SentParameter value;
} *IMAP1_SentParameters;

typedef enum IMAP1_CmServiceType {
    IMAP1_mobileOriginatingCall = 1,
    IMAP1_emergencyCallEstablishment = 2,
    IMAP1_shortMessageService = 4,
    IMAP1_ss_request = 8,
    IMAP1_mobileOriginatingCallRe_establishment = 9,
    IMAP1_mobileTerminatingCall = 10
} IMAP1_CmServiceType;

//
typedef struct IMAP1_AccessConnectionStatus {
    unsigned short  length;
    unsigned char   value[1];
} IMAP1_AccessConnectionStatus;
		// Bit 8-4 Reserved
		// Bit 3
		//     0 No RR- connection
		//     1 RR-connection established
		// Bit 2
		//     0 Ciphering mode off
		//     1 Ciphering mode on
		// Bit 1
		//     0 MM-connection existing and authenticated
		//     1 MM-connection existing and not authenticated

typedef struct IMAP1__choice6 {
    unsigned short  choice;
#       define      IMAP1_locAreaId_chosen 1
#       define      IMAP1_null_chosen 2
    union _union {
        IMAP1_LocAreaId locAreaId;  /* to choose, set choice to
                                     * IMAP1_locAreaId_chosen */
        Nulltype        null;  /* to choose, set choice to IMAP1_null_chosen */
    } u;
} IMAP1__choice6;

typedef struct IMAP1_UpdateLocationAreaArg {
    IMAP1_SubscriberId subscriberId;
    IMAP1__choice6  previousLocAreaId;
    IMAP1_LocAreaId targetLocAreaId;
    IMAP1_CKSN      cksn;
} IMAP1_UpdateLocationAreaArg;

typedef struct IMAP1_UpdateLocationArg {
    unsigned char   bit_mask;
#       define      IMAP1_UpdateLocationArg_lmsi_present 0x80
    IMAP1_IMSI      imsi;
    IMAP1_LocationInfo locationInfo;
    IMAP1_IsdnAddressString vlrNumber;
    IMAP1_LMSI      lmsi;  /* optional; set in bit_mask
                            * IMAP1_UpdateLocationArg_lmsi_present if present */
} IMAP1_UpdateLocationArg;

// UpdateLocationRes ::= SEQUENCE {
// hlrNumber		IsdnAddressString}
typedef IMAP1_IsdnAddressString IMAP1_UpdateLocationRes;

//CancelLocationArg	::= IMSI
typedef struct IMAP1_IMSI_WithLMSI {
    IMAP1_IMSI      imsi;
    IMAP1_LMSI      lmsi;
      // a special value 00000000 indicates that the LMSI is not in use
} IMAP1_IMSI_WithLMSI;

typedef struct IMAP1_CancelLocationArg {
    unsigned short  choice;
#       define      IMAP1_CancelLocationArg_imsi_chosen 1
#       define      IMAP1_imsi_WithLMSI_chosen 2
    union _union {
        IMAP1_IMSI      imsi;  /* to choose, set choice to
                                * IMAP1_CancelLocationArg_imsi_chosen */
        IMAP1_IMSI_WithLMSI imsi_WithLMSI;  /* to choose, set choice to
                                             * IMAP1_imsi_WithLMSI_chosen */
    } u;
} IMAP1_CancelLocationArg;

typedef struct IMAP1_DetachIMSIArg {
    IMAP1_SubscriberId subscriberId;
} IMAP1_DetachIMSIArg;

typedef struct IMAP1_AttachIMSIArg {
    IMAP1_SubscriberId subscriberId;
} IMAP1_AttachIMSIArg;

typedef struct IMAP1_DeregisterMobileSubscriberArg {
    IMAP1_IMSI      imsi;
} IMAP1_DeregisterMobileSubscriberArg;

typedef struct IMAP1_InsertSubscriberDataArg {
    unsigned char   bit_mask;
#       define      IMAP1_InsertSubscriberDataArg_imsi_present 0x80
#       define      IMAP1_InsertSubscriberDataArg_msIsdn_present 0x40
#       define      IMAP1_InsertSubscriberDataArg_category_present 0x20
#       define      IMAP1_InsertSubscriberDataArg_subscriberStatus_present 0x10
#       define      IMAP1_InsertSubscriberDataArg_bearerServiceList_present 0x08
#       define      IMAP1_InsertSubscriberDataArg_teleserviceList_present 0x04
#       define      IMAP1_InsertSubscriberDataArg_provisonedSS_present 0x02
    IMAP1_IMSI      imsi;  /* optional; set in bit_mask
                            * IMAP1_InsertSubscriberDataArg_imsi_present if
                            * present */
    IMAP1_IsdnAddressString msIsdn;  /* optional; set in bit_mask
                              * IMAP1_InsertSubscriberDataArg_msIsdn_present if
                              * present */
    IMAP1_Category  category;  /* optional; set in bit_mask
                                * IMAP1_InsertSubscriberDataArg_category_present
                                * if present */
    IMAP1_SubscriberStatus subscriberStatus;  /* optional; set in bit_mask
                    * IMAP1_InsertSubscriberDataArg_subscriberStatus_present if
                    * present */
    struct IMAP1_BearerServiceList_ *bearerServiceList;  /* optional; set in
                                   * bit_mask
                   * IMAP1_InsertSubscriberDataArg_bearerServiceList_present if
                   * present */
    struct IMAP1_TeleserviceList_ *teleserviceList;  /* optional; set in
                                   * bit_mask
                     * IMAP1_InsertSubscriberDataArg_teleserviceList_present if
                     * present */
    struct IMAP1_SS_InfoList_ *provisonedSS;  /* optional; set in bit_mask
                        * IMAP1_InsertSubscriberDataArg_provisonedSS_present if
                        * present */
} IMAP1_InsertSubscriberDataArg;

typedef struct IMAP1_DeleteSubscriberDataArg {
    unsigned char   bit_mask;
#       define      IMAP1_DeleteSubscriberDataArg_basicService_present 0x80
#       define      IMAP1_DeleteSubscriberDataArg_ss_Code_present 0x40
    IMAP1_IMSI      imsi;
    struct IMAP1_BasicServiceList_ *basicService;  /* optional; set in bit_mask
                        * IMAP1_DeleteSubscriberDataArg_basicService_present if
                        * present */
    struct IMAP1_SS_CodeList_ *ss_Code;  /* optional; set in bit_mask
                             * IMAP1_DeleteSubscriberDataArg_ss_Code_present if
                             * present */
} IMAP1_DeleteSubscriberDataArg;

typedef struct IMAP1_SendParametersArg {
    IMAP1_SubscriberId subscriberId;
    struct IMAP1_RequestParameters_ *requestParameters;
} IMAP1_SendParametersArg;

typedef struct IMAP1_SendParametersRes {
    struct IMAP1_SentParameters_ *sentParameters;
} IMAP1_SendParametersRes;

typedef struct IMAP1_RegisterSSArg {
    unsigned char   bit_mask;
#       define      IMAP1_RegisterSSArg_basicService_present 0x80
#       define      IMAP1_RegisterSSArg_forwardedToNumber_present 0x40
#       define      IMAP1_RegisterSSArg_noReplyConditionTime_present 0x20
    IMAP1_SS_Code   ss_Code;
    IMAP1_BasicServiceCode basicService;  /* optional; set in bit_mask
                                  * IMAP1_RegisterSSArg_basicService_present if
                                  * present */
    IMAP1_IsdnAddressString forwardedToNumber;  /* optional; set in bit_mask
                             * IMAP1_RegisterSSArg_forwardedToNumber_present if
                             * present */
    IMAP1_NoReplyConditionTime noReplyConditionTime;  /* optional; set in
                                   * bit_mask
                          * IMAP1_RegisterSSArg_noReplyConditionTime_present if
                          * present */
} IMAP1_RegisterSSArg;

typedef struct IMAP1_RegisterSSRes {
    IMAP1_SS_Information ss_Information;
} IMAP1_RegisterSSRes;

typedef struct IMAP1_EraseSSArg {
    unsigned char   bit_mask;
#       define      IMAP1_EraseSSArg_basicService_present 0x80
    IMAP1_SS_Code   ss_Code;
    IMAP1_BasicServiceCode basicService;  /* optional; set in bit_mask
                                     * IMAP1_EraseSSArg_basicService_present if
                                     * present */
} IMAP1_EraseSSArg;

typedef struct IMAP1_EraseSSRes {
    IMAP1_SS_Information ss_Information;
} IMAP1_EraseSSRes;

typedef struct IMAP1_ActivateSSArg {
    unsigned char   bit_mask;
#       define      IMAP1_ActivateSSArg_basicService_present 0x80
    IMAP1_SS_Code   ss_Code;
    IMAP1_BasicServiceCode basicService;  /* optional; set in bit_mask
                                  * IMAP1_ActivateSSArg_basicService_present if
                                  * present */
} IMAP1_ActivateSSArg;

typedef struct IMAP1_ActivateSSRes {
    IMAP1_SS_Information ss_Information;
} IMAP1_ActivateSSRes;

typedef struct IMAP1_DeactivateSSArg {
    unsigned char   bit_mask;
#       define      IMAP1_DeactivateSSArg_basicService_present 0x80
    IMAP1_SS_Code   ss_Code;
    IMAP1_BasicServiceCode basicService;  /* optional; set in bit_mask
                                * IMAP1_DeactivateSSArg_basicService_present if
                                * present */
} IMAP1_DeactivateSSArg;

typedef struct IMAP1_DeactivateSSRes {
    IMAP1_SS_Information ss_Information;
} IMAP1_DeactivateSSRes;

typedef struct IMAP1_InterrogateSSArg {
    unsigned char   bit_mask;
#       define      IMAP1_InterrogateSSArg_basicService_present 0x80
    IMAP1_SS_Code   ss_Code;
    IMAP1_BasicServiceCode basicService;  /* optional; set in bit_mask
                               * IMAP1_InterrogateSSArg_basicService_present if
                               * present */
} IMAP1_InterrogateSSArg;

typedef struct IMAP1__choice7 {
    unsigned short  choice;
#       define      IMAP1_ss_Status_chosen 1
#       define      IMAP1_forwardedToNumber_chosen 2
#       define      IMAP1_basicServiceGroupList_chosen 3
#       define      IMAP1_forwardingFeatureList_chosen 4
    union _union {
        IMAP1_SS_Status ss_Status;  /* to choose, set choice to
                                     * IMAP1_ss_Status_chosen */
        IMAP1_IsdnAddressString forwardedToNumber;  /* to choose, set choice to
                                            * IMAP1_forwardedToNumber_chosen */
        struct IMAP1_BasicServiceGroupList_ *basicServiceGroupList;  /* to
                                   * choose, set choice to
                                   * IMAP1_basicServiceGroupList_chosen */
        struct IMAP1_ForwardingFeatureList_ *forwardingFeatureList;  /* to
                                   * choose, set choice to
                                   * IMAP1_forwardingFeatureList_chosen */
    } u;
} IMAP1__choice7;

typedef struct IMAP1_InterrogateSSRes {
    IMAP1__choice7  choice;
} IMAP1_InterrogateSSRes;

typedef struct IMAP1_InvokeSSArg {
    unsigned char   bit_mask;
#       define      IMAP1_InvokeSSArg_basicService_present 0x80
#       define      IMAP1_userToUserServiceIndicator_present 0x40
#       define      IMAP1_InvokeSSArg_cug_Index_present 0x20
#       define      IMAP1_numberOfConferees_present 0x10
    IMAP1_SS_Code   ss_Code;
    IMAP1_BasicServiceCode basicService;  /* optional; set in bit_mask
                                    * IMAP1_InvokeSSArg_basicService_present if
                                    * present */
    IMAP1_UserToUserServiceIndicator userToUserServiceIndicator;  /* optional;
                                   * set in bit_mask
                                   * IMAP1_userToUserServiceIndicator_present if
                                   * present */
    IMAP1_CUG_Index cug_Index;  /* optional; set in bit_mask
                                 * IMAP1_InvokeSSArg_cug_Index_present if
                                 * present */
    IMAP1_NumberOfConferees numberOfConferees;  /* optional; set in bit_mask
                                           * IMAP1_numberOfConferees_present if
                                           * present */
} IMAP1_InvokeSSArg;

typedef struct IMAP1_InvokeSSRes {
    IMAP1_CUG_Interlock cug_Interlock;
} IMAP1_InvokeSSRes;

typedef struct IMAP1_ForwardSsNotificationArg {
    unsigned char   bit_mask;
#       define      IMAP1_ForwardSsNotificationArg_imsi_present 0x80
#       define      IMAP1_ForwardSsNotificationArg_ss_Code_present 0x40
#       define      IMAP1_ForwardSsNotificationArg_teleservice_present 0x20
#       define      IMAP1_ForwardSsNotificationArg_bearerService_present 0x10
#       define      IMAP1_ForwardSsNotificationArg_ss_Status_present 0x08
#       define      IMAP1_ss_Notification_present 0x04
    IMAP1_IMSI      imsi;  /* optional; set in bit_mask
                            * IMAP1_ForwardSsNotificationArg_imsi_present if
                            * present */
    IMAP1_SS_Code   ss_Code;  /* optional; set in bit_mask
                               * IMAP1_ForwardSsNotificationArg_ss_Code_present
                               * if present */
    IMAP1_TeleserviceCode teleservice;  /* optional; set in bit_mask
                        * IMAP1_ForwardSsNotificationArg_teleservice_present if
                        * present */
    IMAP1_BearerServiceCode bearerService;  /* optional; set in bit_mask
                      * IMAP1_ForwardSsNotificationArg_bearerService_present if
                      * present */
    IMAP1_SS_Status ss_Status;  /* optional; set in bit_mask
                          * IMAP1_ForwardSsNotificationArg_ss_Status_present if
                          * present */
    IMAP1_SS_Notification ss_Notification;  /* optional; set in bit_mask
                                             * IMAP1_ss_Notification_present if
                                             * present */
} IMAP1_ForwardSsNotificationArg;

typedef struct IMAP1_RegisterPasswordArg {
    IMAP1_SS_Code   ss_Code;
} IMAP1_RegisterPasswordArg;

typedef struct IMAP1_GetPasswordArg {
    IMAP1_GuidanceInfo guidanceInfo;
} IMAP1_GetPasswordArg;

typedef struct IMAP1_ProcessUnstructuredSsDataRes {
    IMAP1_SS_UserData ss_UserData;
} IMAP1_ProcessUnstructuredSsDataRes;

typedef struct IMAP1__choice8 {
    unsigned short  choice;
#       define      IMAP1_incomingId_roamingNumber_chosen 1
#       define      IMAP1_incomingId_imsi_chosen 2
    union _union {
        IMAP1_IsdnAddressString roamingNumber;  /* to choose, set choice to
                                     * IMAP1_incomingId_roamingNumber_chosen */
        IMAP1_IMSI      imsi;  /* to choose, set choice to
                                * IMAP1_incomingId_imsi_chosen */
    } u;
} IMAP1__choice8;

typedef struct IMAP1_SendInfoForIncomingCallArg {
    unsigned char   bit_mask;
#       define      IMAP1_SendInfoForIncomingCallArg_bearerService_present 0x80
#       define      IMAP1_SendInfoForIncomingCallArg_teleservice_present 0x40
#       define      IMAP1_SendInfoForIncomingCallArg_lmsi_present 0x20
#       define      IMAP1_dialledNumber_present 0x10
#       define      IMAP1_SendInfoForIncomingCallArg_cug_Interlock_present 0x08
#       define      IMAP1_SendInfoForIncomingCallArg_numberOfForwarding_present 0x04
    IMAP1__choice8  incomingId;
    IMAP1_BearerServiceCode bearerService;  /* optional; set in bit_mask
                    * IMAP1_SendInfoForIncomingCallArg_bearerService_present if
                    * present */
    IMAP1_TeleserviceCode teleservice;  /* optional; set in bit_mask
                      * IMAP1_SendInfoForIncomingCallArg_teleservice_present if
                      * present */
    IMAP1_LMSI      lmsi;  /* optional; set in bit_mask
                            * IMAP1_SendInfoForIncomingCallArg_lmsi_present if
                            * present */
    IMAP1_IsdnAddressString dialledNumber;  /* optional; set in bit_mask
                                             * IMAP1_dialledNumber_present if
                                             * present */
    IMAP1_CUG_Interlock cug_Interlock;  /* optional; set in bit_mask
                    * IMAP1_SendInfoForIncomingCallArg_cug_Interlock_present if
                    * present */
    IMAP1_NumberOfForwarding numberOfForwarding;  /* optional; set in bit_mask
               * IMAP1_SendInfoForIncomingCallArg_numberOfForwarding_present if
               * present */
} IMAP1_SendInfoForIncomingCallArg;

typedef struct IMAP1_SendInfoForOutgoingCallArg {
    unsigned char   bit_mask;
#       define      IMAP1_SendInfoForOutgoingCallArg_bearerService_present 0x80
#       define      IMAP1_teleService_present 0x40
    IMAP1_IsdnAddressString calledNumber;
    IMAP1_BearerServiceCode bearerService;  /* optional; set in bit_mask
                    * IMAP1_SendInfoForOutgoingCallArg_bearerService_present if
                    * present */
    IMAP1_TeleserviceCode teleService;  /* optional; set in bit_mask
                                         * IMAP1_teleService_present if
                                         * present */
} IMAP1_SendInfoForOutgoingCallArg;

typedef struct IMAP1_SendRoutingInformationArg {
    unsigned char   bit_mask;
#       define      IMAP1_SendRoutingInformationArg_cug_Interlock_present 0x80
#       define      IMAP1_SendRoutingInformationArg_numberOfForwarding_present 0x40
#       define      IMAP1_SendRoutingInformationArg_networkSignalInfo_present 0x20
    IMAP1_IsdnAddressString msIsdn;
    IMAP1_CUG_Interlock cug_Interlock;  /* optional; set in bit_mask
                     * IMAP1_SendRoutingInformationArg_cug_Interlock_present if
                     * present */
    IMAP1_NumberOfForwarding numberOfForwarding;  /* optional; set in bit_mask
                * IMAP1_SendRoutingInformationArg_numberOfForwarding_present if
                * present */
    IMAP1_ExternalSignalInfo networkSignalInfo;  /* optional; set in bit_mask
                 * IMAP1_SendRoutingInformationArg_networkSignalInfo_present if
                 * present */
} IMAP1_SendRoutingInformationArg;

typedef struct IMAP1__choice9 {
    unsigned short  choice;
#       define      IMAP1_routingInfo_roamingNumber_chosen 1
#       define      IMAP1_routingInfo_forwardingData_chosen 2
    union _union {
        IMAP1_IsdnAddressString roamingNumber;  /* to choose, set choice to
                                    * IMAP1_routingInfo_roamingNumber_chosen */
        IMAP1_ForwardingData forwardingData;  /* to choose, set choice to
                                   * IMAP1_routingInfo_forwardingData_chosen */
    } u;
} IMAP1__choice9;

typedef struct IMAP1_SendRoutingInformationRes {
    IMAP1_IMSI      imsi;
    IMAP1__choice9  routingInfo;
} IMAP1_SendRoutingInformationRes;

typedef struct IMAP1_ProvideRoamingNumberArg {
    unsigned char   bit_mask;
#       define      IMAP1_mscNumber_present 0x80
#       define      IMAP1_ProvideRoamingNumberArg_msIsdn_present 0x40
#       define      IMAP1_previousRoamingNumber_present 0x20
#       define      IMAP1_ProvideRoamingNumberArg_lmsi_present 0x10
#       define      IMAP1_ProvideRoamingNumberArg_gSM_BearerCapability_present 0x08
#       define      IMAP1_ProvideRoamingNumberArg_networkSignalInfo_present 0x04
    IMAP1_IMSI      imsi;
    IMAP1_IsdnAddressString mscNumber;  /* optional; set in bit_mask
                                         * IMAP1_mscNumber_present if present */
    IMAP1_IsdnAddressString msIsdn;  /* optional; set in bit_mask
                              * IMAP1_ProvideRoamingNumberArg_msIsdn_present if
                              * present */
    IMAP1_IsdnAddressString previousRoamingNumber;  /* optional; set in bit_mask
                                       * IMAP1_previousRoamingNumber_present if
                                       * present */
    IMAP1_LMSI      lmsi;  /* optional; set in bit_mask
                            * IMAP1_ProvideRoamingNumberArg_lmsi_present if
                            * present */
    IMAP1_ExternalSignalInfo gSM_BearerCapability;  /* optional; set in bit_mask
                * IMAP1_ProvideRoamingNumberArg_gSM_BearerCapability_present if
                * present */
    IMAP1_ExternalSignalInfo networkSignalInfo;  /* optional; set in bit_mask
                   * IMAP1_ProvideRoamingNumberArg_networkSignalInfo_present if
                   * present */
} IMAP1_ProvideRoamingNumberArg;

//ProvideRoamingNumberRes	::=	SEQUENCE {
//roamingNumber	IsdnAddressString}
typedef IMAP1_IsdnAddressString IMAP1_ProvideRoamingNumberRes;

typedef struct IMAP1_CompleteCallArg {
    unsigned char   bit_mask;
#       define      IMAP1_CompleteCallArg_category_present 0x80
#       define      IMAP1_CompleteCallArg_cug_Index_present 0x40
#       define      IMAP1_CompleteCallArg_gSM_BearerCapability_present 0x20
#       define      IMAP1_CompleteCallArg_noReplyConditionTime_present 0x10
#       define      IMAP1_ss_DataList_present 0x08
    IMAP1_IsdnAddressString msIsdn;
    IMAP1_Category  category;  /* optional; set in bit_mask
                                * IMAP1_CompleteCallArg_category_present if
                                * present */
    IMAP1_CUG_Index cug_Index;  /* optional; set in bit_mask
                                 * IMAP1_CompleteCallArg_cug_Index_present if
                                 * present */
    IMAP1_ExternalSignalInfo gSM_BearerCapability;  /* optional; set in bit_mask
                        * IMAP1_CompleteCallArg_gSM_BearerCapability_present if
                        * present */
    IMAP1_NoReplyConditionTime noReplyConditionTime;  /* optional; set in
                                   * bit_mask
                        * IMAP1_CompleteCallArg_noReplyConditionTime_present if
                        * present */
    struct IMAP1_SS_DataList_ *ss_DataList;  /* optional; set in bit_mask
                                              * IMAP1_ss_DataList_present if
                                              * present */
} IMAP1_CompleteCallArg;

typedef struct IMAP1_ConnectToFollowingAddressArg {
    unsigned char   bit_mask;
#       define      IMAP1_ConnectToFollowingAddressArg_msIsdn_present 0x80
    IMAP1_ForwardingData forwardingData;
    IMAP1_IsdnAddressString msIsdn;  /* optional; set in bit_mask
                         * IMAP1_ConnectToFollowingAddressArg_msIsdn_present if
                         * present */
} IMAP1_ConnectToFollowingAddressArg;

typedef struct IMAP1_PageArg {
    unsigned char   bit_mask;
#       define      IMAP1_tmsi_present 0x80
    IMAP1_IMSI      imsi;
    IMAP1_TMSI      tmsi;  /* optional; set in bit_mask IMAP1_tmsi_present if
                            * present */
    IMAP1_LocAreaId locAreaId;
} IMAP1_PageArg;

typedef struct IMAP1_SearchForMobileSubscriberArg {
    IMAP1_IMSI      imsi;
    IMAP1__choice6  storedLocationArea;
} IMAP1_SearchForMobileSubscriberArg;

typedef struct IMAP1_SearchForMobileSubscriberRes {
    IMAP1_LocAreaId currentLocAreaId;
} IMAP1_SearchForMobileSubscriberRes;

typedef struct IMAP1_PerformHandoverArg {
    unsigned char   bit_mask;
#       define      IMAP1_handoverPriority_present 0x80
#       define      IMAP1_PerformHandoverArg_kc_present 0x40
    IMAP1_GlobalCellId targetCellId;
    IMAP1_GlobalCellId servingCellId;
    IMAP1_ChannelType channelType;
    IMAP1_ClassmarkInformation classmarkInformation;
    IMAP1_HandoverPriority handoverPriority;  /* optional; set in bit_mask
                                               * IMAP1_handoverPriority_present
                                               * if present */
    IMAP1_Kc        kc;  /* optional; set in bit_mask
                          * IMAP1_PerformHandoverArg_kc_present if present */
} IMAP1_PerformHandoverArg;

typedef struct IMAP1_PerformHandoverRes {
    IMAP1_IsdnAddressString handoverNumber;
    IMAP1_ExternalSignalInfo accessSignalInfo;
} IMAP1_PerformHandoverRes;

typedef struct IMAP1_PerformSubsequentHandoverArg {
    unsigned char   bit_mask;
#       define      IMAP1_classmarkInformation_present 0x80
    IMAP1_GlobalCellId targetCellId;
    IMAP1_GlobalCellId servingCellId;
    IMAP1_IsdnAddressString targetMscNumber;
    IMAP1_ClassmarkInformation classmarkInformation;  /* optional; set in
                                   * bit_mask IMAP1_classmarkInformation_present
                                   * if present */
} IMAP1_PerformSubsequentHandoverArg;

typedef struct IMAP1_PerformSubsequentHandoverRes {
    IMAP1_ExternalSignalInfo accessSignalInfo;
} IMAP1_PerformSubsequentHandoverRes;

typedef struct IMAP1_ProcessAccessSignallingArg {
    IMAP1_ExternalSignalInfo bss_APDU;
} IMAP1_ProcessAccessSignallingArg;

typedef struct IMAP1_ForwardAccessSignallingArg {
    IMAP1_ExternalSignalInfo bss_APDU;
} IMAP1_ForwardAccessSignallingArg;

typedef struct IMAP1_SendHandoverReportArg {
    IMAP1_IsdnAddressString handoverNumber;
} IMAP1_SendHandoverReportArg;

typedef struct IMAP1_RegisterChargingInformationArg {
    unsigned char   bit_mask;
#       define      IMAP1_bearerServiceCode_present 0x80
#       define      IMAP1_RegisterChargingInformationArg_teleserviceCode_present 0x40
#       define      IMAP1_calledNumber_present 0x20
#       define      IMAP1_callingNumber_present 0x10
#       define      IMAP1_packetDataVolume_present 0x08
#       define      IMAP1_chargingUnit_present 0x04
#       define      IMAP1_RegisterChargingInformationArg_charge_present 0x02
#       define      IMAP1_ss_ChargingInfo_present 0x01
    IMAP1_IsdnAddressString msIsdn;
    IMAP1_IsdnAddressString mscNumber;
    IMAP1_IMSI      imsi;
    IMAP1_CallReference callReference;
    IMAP1_CallType  callType;
    IMAP1_CallStatus callStatus;
    IMAP1_CallDateTime callDateTime;
    IMAP1_CallDuration callDuration;
    IMAP1_BearerServiceCode bearerServiceCode;  /* optional; set in bit_mask
                                           * IMAP1_bearerServiceCode_present if
                                           * present */
    IMAP1_TeleserviceCode teleserviceCode;  /* optional; set in bit_mask
              * IMAP1_RegisterChargingInformationArg_teleserviceCode_present if
              * present */
    IMAP1_IsdnAddressString calledNumber;  /* optional; set in bit_mask
                                            * IMAP1_calledNumber_present if
                                            * present */
    IMAP1_IsdnAddressString callingNumber;  /* optional; set in bit_mask
                                             * IMAP1_callingNumber_present if
                                             * present */
    IMAP1_PacketDataVolume packetDataVolume;  /* optional; set in bit_mask
                                               * IMAP1_packetDataVolume_present
                                               * if present */
    IMAP1_ChargingUnit chargingUnit;  /* optional; set in bit_mask
                                       * IMAP1_chargingUnit_present if
                                       * present */
    IMAP1_Charge    charge;  /* optional; set in bit_mask
                       * IMAP1_RegisterChargingInformationArg_charge_present if
                       * present */
    struct IMAP1_SS_ChargingInfo_ *ss_ChargingInfo;  /* optional; set in
                                   * bit_mask IMAP1_ss_ChargingInfo_present if
                                   * present */
} IMAP1_RegisterChargingInformationArg;

typedef struct IMAP1_ResetArg {
    unsigned char   bit_mask;
#       define      IMAP1_hlrId_present 0x80
    IMAP1_NetworkResource networkResource;
    IMAP1_IsdnAddressString originatingEntityNumber;
    struct IMAP1_HlrList_ *hlrId;  /* optional; set in bit_mask
                                    * IMAP1_hlrId_present if present */
} IMAP1_ResetArg;

typedef struct IMAP1_ActivateTraceModeArg {
    unsigned char   bit_mask;
#       define      IMAP1_ActivateTraceModeArg_imsi_present 0x80
#       define      IMAP1_ActivateTraceModeArg_omcId_present 0x40
    IMAP1_IMSI      imsi;  /* optional; set in bit_mask
                            * IMAP1_ActivateTraceModeArg_imsi_present if
                            * present */
    IMAP1_TraceReference traceReference;
    IMAP1_TraceType traceType;
    IMAP1_AddressString omcId;  /* optional; set in bit_mask
                                 * IMAP1_ActivateTraceModeArg_omcId_present if
                                 * present */
} IMAP1_ActivateTraceModeArg;

typedef struct IMAP1_DeactivateTraceModeArg {
    unsigned char   bit_mask;
#       define      IMAP1_DeactivateTraceModeArg_imsi_present 0x80
    IMAP1_IMSI      imsi;  /* optional; set in bit_mask
                            * IMAP1_DeactivateTraceModeArg_imsi_present if
                            * present */
    IMAP1_TraceReference traceReference;
} IMAP1_DeactivateTraceModeArg;

typedef struct IMAP1_TraceSubscriberActivityArg {
    unsigned char   bit_mask;
#       define      IMAP1_TraceSubscriberActivityArg_imsi_present 0x80
#       define      IMAP1_TraceSubscriberActivityArg_omcId_present 0x40
#       define      IMAP1_callReference_present 0x20
    IMAP1_IMSI      imsi;  /* optional; set in bit_mask
                            * IMAP1_TraceSubscriberActivityArg_imsi_present if
                            * present */
    IMAP1_TraceReference traceReference;
    IMAP1_TraceType traceType;
    IMAP1_AddressString omcId;  /* optional; set in bit_mask
                            * IMAP1_TraceSubscriberActivityArg_omcId_present if
                            * present */
    IMAP1_CallReference callReference;  /* optional; set in bit_mask
                                         * IMAP1_callReference_present if
                                         * present */
} IMAP1_TraceSubscriberActivityArg;

typedef struct IMAP1_NoteInternalHandoverArg {
    unsigned char   bit_mask;
#       define      IMAP1_targetCellId_present 0x80
#       define      IMAP1_channelId_present 0x40
    IMAP1_HandoverType handoverType;
    IMAP1_GlobalCellId targetCellId;  /* optional; set in bit_mask
                                       * IMAP1_targetCellId_present if
                                       * present */
    IMAP1_ExternalSignalInfo channelId;  /* optional; set in bit_mask
                                          * IMAP1_channelId_present if
                                          * present */
} IMAP1_NoteInternalHandoverArg;

typedef struct IMAP1_CheckIMEArg {
    IMAP1_IMEI      imei;
} IMAP1_CheckIMEArg;

typedef struct IMAP1_CheckIMEIRes {
    IMAP1_EquipStatus equipStatus;
} IMAP1_CheckIMEIRes;

typedef struct IMAP1_AuthenticateArg {
    IMAP1_Rand      rand;
    IMAP1_CKSN      cksn;
} IMAP1_AuthenticateArg;

typedef struct IMAP1_AuthenticateRes {
    IMAP1_Sres      sres;
} IMAP1_AuthenticateRes;

typedef struct IMAP1_ProvideIMSIRes {
    IMAP1_IMSI      imsi;
} IMAP1_ProvideIMSIRes;

typedef struct IMAP1_SetCipheringModeArg {
    unsigned char   bit_mask;
#       define      IMAP1_SetCipheringModeArg_kc_present 0x80
    IMAP1_CipheringMode cipheringMode;
    IMAP1_Kc        kc;  /* optional; set in bit_mask
                          * IMAP1_SetCipheringModeArg_kc_present if present */
} IMAP1_SetCipheringModeArg;

typedef struct IMAP1_SendRoutingInfoForSMArg {
    unsigned char   bit_mask;
#       define      IMAP1_SendRoutingInfoForSMArg_cug_Interlock_present 0x80
#       define      IMAP1_SendRoutingInfoForSMArg_teleserviceCode_present 0x40
    IMAP1_IsdnAddressString msIsdn;
    ossBoolean      sm_RP_PRI;
    IMAP1_AddressString serviceCentreAddress;
    IMAP1_CUG_Interlock cug_Interlock;  /* optional; set in bit_mask
                       * IMAP1_SendRoutingInfoForSMArg_cug_Interlock_present if
                       * present */
    IMAP1_TeleserviceCode teleserviceCode;  /* optional; set in bit_mask
                     * IMAP1_SendRoutingInfoForSMArg_teleserviceCode_present if
                     * present */
} IMAP1_SendRoutingInfoForSMArg;

typedef struct IMAP1_ForwardNewTMSIArg {
    IMAP1_TMSI      tmsi;
} IMAP1_ForwardNewTMSIArg;

typedef struct IMAP1__choice10 {
    unsigned short  choice;
#       define      IMAP1_sequence_chosen 1
#       define      IMAP1_choice_forwardingData_chosen 2
    union _union {
        struct IMAP1__seq2 {
            unsigned char   bit_mask;
#               define      IMAP1_sequence_lmsi_present 0x80
            IMAP1_LocationInfo locationInfo;
            IMAP1_LMSI      lmsi;  /* optional; set in bit_mask
                                    * IMAP1_sequence_lmsi_present if present */
        } sequence;  /* to choose, set choice to IMAP1_sequence_chosen */
        IMAP1_ForwardingData forwardingData;  /* to choose, set choice to
                                        * IMAP1_choice_forwardingData_chosen */
    } u;
} IMAP1__choice10;

typedef struct IMAP1_SendRoutingInfoForSMRes {
    unsigned char   bit_mask;
#       define      IMAP1_mwd_Set_present 0x80
    IMAP1_IMSI      imsi;
    IMAP1__choice10 choice;
    ossBoolean      mwd_Set;  /* optional; set in bit_mask IMAP1_mwd_Set_present
                               * if present */
} IMAP1_SendRoutingInfoForSMRes;

typedef struct IMAP1_ForwardShortMessageArg {
    IMAP1_SM_RP_DA  sm_RP_DA;
    IMAP1_SM_RP_OA  sm_RP_OA;
    IMAP1_SM_RP_UI  sm_RP_UI;
} IMAP1_ForwardShortMessageArg;

typedef struct IMAP1_SetMessageWaitingDataArg {
    IMAP1_IsdnAddressString msIsdn;
    IMAP1_AddressString serviceCentreAddress;
} IMAP1_SetMessageWaitingDataArg;

// NoteMSPresentArg	::=	SEQUENCE {
// imsi		IMSI}
typedef IMAP1_IMSI      IMAP1_NoteMSPresentArg;

typedef struct IMAP1_AlertServiceCentreArg {
    IMAP1_IsdnAddressString msIsdn;
    IMAP1_AddressString serviceCentreAddress;
} IMAP1_AlertServiceCentreArg;

typedef struct IMAP1_ProcessAccessRequestArg {
    IMAP1_SubscriberId subscriberId;
    IMAP1_CmServiceType cmServiceType;
    IMAP1_AccessConnectionStatus accessConnectionStatus;
    IMAP1_CKSN      cksn;
} IMAP1_ProcessAccessRequestArg;

typedef struct IMAP1_ProcessAccessRequestRes {
    unsigned char   bit_mask;
#       define      IMAP1_ProcessAccessRequestRes_msIsdn_present 0x80
    IMAP1_IMSI      imsi;
    IMAP1_IsdnAddressString msIsdn;  /* optional; set in bit_mask
                              * IMAP1_ProcessAccessRequestRes_msIsdn_present if
                              * present */
} IMAP1_ProcessAccessRequestRes;

typedef struct IMAP1_BeginSubscriberActivityArg {
    IMAP1_IMSI      imsi;
    IMAP1_IsdnAddressString originatingEntityNumber;
} IMAP1_BeginSubscriberActivityArg;

// error types definitions
typedef struct IMAP1_UnknownSubscriber {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_UnknownSubscriber;

typedef struct IMAP1_UnknownBaseStation {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_UnknownBaseStation;

typedef struct IMAP1_UnknownMSC {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_UnknownMSC;

typedef struct IMAP1_UnknownLocArea {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_UnknownLocArea;

typedef struct IMAP1_UnidentifiedSubscriber {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_UnidentifiedSubscriber;

typedef struct IMAP1_UnallocatedRoamingNumber {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_UnallocatedRoamingNumber;

typedef struct IMAP1_UnknownEquipment {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_UnknownEquipment;

typedef struct IMAP1_RoamingNotAllowed {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_RoamingNotAllowed;

typedef struct IMAP1_IllegalMS {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_IllegalMS;

typedef struct IMAP1_BearerServiceNotProvisioned {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_BearerServiceNotProvisioned;

typedef struct IMAP1_TeleserviceNotProvisioned {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_TeleserviceNotProvisioned;

typedef struct IMAP1_InsufficientBearerCapabilities {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_InsufficientBearerCapabilities;

typedef struct IMAP1_CallBarred {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_CallBarred; // optional

//
typedef struct IMAP1_ForwardingViolation {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_ForwardingViolation;

//
typedef struct IMAP1_CUG_Reject {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_CUG_Reject; // optional

//
typedef struct IMAP1_IllegalSS_Operation {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_IllegalSS_Operation;

//
typedef struct IMAP1_SS_ErrorStatus {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_SS_ErrorStatus; // optional

//
typedef struct IMAP1_SS_NotAvailable {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_SS_NotAvailable;

typedef struct IMAP1_SS_SubscriptionViolation {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_SS_SubscriptionViolation; // optional

typedef struct IMAP1_SS_Incompatibility_PARAMETER {
    unsigned char   bit_mask;
#       define      IMAP1_SS_Incompatibility_PARAMETER_ss_Code_present 0x80
#       define      IMAP1_SS_Incompatibility_PARAMETER_basicService_present 0x40
#       define      IMAP1_SS_Incompatibility_PARAMETER_ss_Status_present 0x20
    IMAP1_SS_Code   ss_Code;  /* optional; set in bit_mask
                        * IMAP1_SS_Incompatibility_PARAMETER_ss_Code_present if
                        * present */
    IMAP1_BasicServiceCode basicService;  /* optional; set in bit_mask
                   * IMAP1_SS_Incompatibility_PARAMETER_basicService_present if
                   * present */
    IMAP1_SS_Status ss_Status;  /* optional; set in bit_mask
                      * IMAP1_SS_Incompatibility_PARAMETER_ss_Status_present if
                      * present */
} IMAP1_SS_Incompatibility_PARAMETER;

//
typedef struct IMAP1_SS_Incompatibility {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_SS_Incompatibility; // optional

//
typedef struct IMAP1_FacilityNotSupported {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_FacilityNotSupported;

//
typedef struct IMAP1_InvalidTargetBaseStation {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_InvalidTargetBaseStation;

typedef struct IMAP1_NoRadioResourceAvailable {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_NoRadioResourceAvailable;

typedef struct IMAP1_NoHandoverNumberAvailable {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_NoHandoverNumberAvailable;

typedef struct IMAP1_SubsequentHandoverFailure {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_SubsequentHandoverFailure;

typedef struct IMAP1_AbsentSubscriber {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_AbsentSubscriber; // optional

typedef struct IMAP1_BusySubscriber {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_BusySubscriber;

typedef struct IMAP1_NoSubscriberReply {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_NoSubscriberReply;

typedef struct IMAP1_RadioCongestion {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_RadioCongestion;

typedef struct IMAP1_ImpossibleCallCompletion {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_ImpossibleCallCompletion; // optional

typedef struct IMAP1_SM_DeliveryFailure {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_SM_DeliveryFailure;

typedef struct IMAP1_MessageWaitingListFull {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_MessageWaitingListFull;

//
typedef struct IMAP1_SystemFailure {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_SystemFailure; // optional

typedef struct IMAP1_DataMissing {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_DataMissing;

typedef struct IMAP1_UnexpectedDataValue {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_UnexpectedDataValue;

typedef struct IMAP1_PasswordRegistrationFailure {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_PasswordRegistrationFailure;

typedef struct IMAP1_NegativePasswordCheck {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_NegativePasswordCheck;

typedef struct IMAP1_NoRoamingNumberAvailable {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_NoRoamingNumberAvailable;

typedef struct IMAP1_TracingBufferFull {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_TracingBufferFull;

// exports operations types	

// Location management
// Subscriber data management
// Supplementary Services Handling
// Call set-up
// Paging
// Handover
// Charging
// Fault recovery
// Tracing
// Equipment management
// Authentication and security
// Short messages
// Access request
// imports errors types
typedef struct IMAP1_UpdateLocationArea {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_UpdateLocationArea;

//
typedef struct IMAP1_UpdateLocation {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_UpdateLocation;

//
typedef struct IMAP1_CancelLocation {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_CancelLocation;

	//
typedef struct IMAP1_DetachIMSI {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_DetachIMSI;

//
typedef struct IMAP1_AttachIMSI {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_AttachIMSI;

//
typedef struct IMAP1_DeregisterMobileSubscriber {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_DeregisterMobileSubscriber;

	// Subscriber data management
typedef struct IMAP1_InsertSubscriberData {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_InsertSubscriberData;

//
typedef struct IMAP1_DeleteSubscriberData {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_DeleteSubscriberData;

//
typedef struct IMAP1_SendParameters {	// optional (nothing is returned, if the requested
	// parameters are not available or do not exist)
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_SendParameters;

	// Supplementary services handling
//
typedef struct IMAP1_RegisterSS {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_RegisterSS;

//
typedef struct IMAP1_EraseSS {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_EraseSS;

typedef struct IMAP1_ActivateSS {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_ActivateSS;

//
typedef struct IMAP1_DeactivateSS {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_DeactivateSS;

	//
typedef struct IMAP1_InterrogateSS {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_InterrogateSS;

//
typedef struct IMAP1_InvokeSS {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_InvokeSS;

	//
typedef struct IMAP1_ForwardSsNotification {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_ForwardSsNotification;

//
typedef struct IMAP1_RegisterPassword {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_RegisterPassword;

//
typedef struct IMAP1_GetPassword {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_GetPassword;

//
typedef struct IMAP1_ProcessUnstructuredSsData {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_ProcessUnstructuredSsData;

	// UnexpectedDataValue is used when data from MS does not correspond
	// to any service implemented in HLR
	// Call set-up
//
typedef struct IMAP1_SendInfoForIncomingCall {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_SendInfoForIncomingCall;

//
typedef struct IMAP1_SendInfoForOutgoingCall {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_SendInfoForOutgoingCall;

typedef struct IMAP1_SendRoutingInformation {// If available from the network the ISDN Bearer Capabilities and the ISDN High Layer
// Compatibility and Low Layer Compatibility information elements are included in
// the networkSignalInfo parameter as defined in section 6.4.3.8.9.
// The information is passed according to the rules specified in GSM 09.07.
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_SendRoutingInformation;

typedef struct IMAP1_ProvideRoamingNumber {// If available from the network the ISDN High Layer Compatibility information element is
// carried in the networkSignalInfo parameter as shown in section 6.4.3.8.9.
// The information is passed according to the rules specified in GSM 09.07.
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_ProvideRoamingNumber;

//
typedef struct IMAP1_CompleteCall {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_CompleteCall;

//
typedef struct IMAP1_ConnectToFollowingAddress {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_ConnectToFollowingAddress;

//
typedef struct IMAP1_ProcessCallWaiting {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_ProcessCallWaiting;

// Paging
//
typedef struct IMAP1_Page {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_Page;

//
typedef struct IMAP1_SearchForMobileSubscriber {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_SearchForMobileSubscriber;

//

// Handover
typedef struct IMAP1_PerformHandover {	// protocolId for ExternalSignalInfo
	// should indicate "gsm-04.08-version1"
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_PerformHandover;

//
typedef struct IMAP1_SendEndSignal {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_SendEndSignal;

//RESULT
typedef struct IMAP1_PerformSubsequentHandover {// protocolId should indicate "gsm-04.08-version1"}
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_PerformSubsequentHandover;

//
typedef struct IMAP1_AllocateHandoverNumber {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_AllocateHandoverNumber;

//
typedef struct IMAP1_SendHandoverReport {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_SendHandoverReport;

//RESULT

//
typedef struct IMAP1_ProcessAccessSignalling {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_ProcessAccessSignalling;

// protocolId should indicate "gsm-0806-version1"

//
typedef struct IMAP1_ForwardAccessSignalling {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_ForwardAccessSignalling;

// protocolId should indicate "gsm-0806-version1"

// Charging
//
typedef struct IMAP1_RegisterChargingInformation {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_RegisterChargingInformation;

// Fault recovery
//
typedef struct IMAP1_Reset {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_Reset;

//
typedef struct IMAP1_ForwardCheckSsIndication {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_ForwardCheckSsIndication;

// Tracing
//
typedef struct IMAP1_ActivateTraceMode {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_ActivateTraceMode;

//
typedef struct IMAP1_DeactivateTraceMode {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_DeactivateTraceMode;

//
typedef struct IMAP1_TraceSubscriberActivity {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_TraceSubscriberActivity;

//
typedef struct IMAP1_NoteInternalHandover {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_NoteInternalHandover;

	// Equipment management
//
typedef struct IMAP1_CheckIMEI {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_CheckIMEI;

// Authentication and security
//
typedef struct IMAP1_Authenticate {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_Authenticate;

//
typedef struct IMAP1_ProvideIMSI {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_ProvideIMSI;

typedef struct IMAP1_ForwardNewTMSI {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_ForwardNewTMSI;

//RESULT

//
typedef struct IMAP1_SetCipheringMode {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_SetCipheringMode;

// Kc should be included when cipheringMode indicates
// that ciphering must be performed

// Short messages
typedef struct IMAP1_SendRoutingInfoForSM {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_SendRoutingInfoForSM;

	//
typedef struct IMAP1_ForwardShortMessage {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_ForwardShortMessage;

//
typedef struct IMAP1_SetMessageWaitingData {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_SetMessageWaitingData;

//
typedef struct IMAP1_NoteMSPresent {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_NoteMSPresent;

//
typedef struct IMAP1_AlertServiceCentre {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_AlertServiceCentre;

// Access request
//
typedef struct IMAP1_ProcessAccessRequest {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_ProcessAccessRequest;

//
typedef struct IMAP1_BeginSubscriberActivity {
    unsigned short  choice;
#       define      IMAP1_localValue_chosen 1
#       define      IMAP1_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP1_localValue_chosen */
        IMAP1__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP1_globalValue_chosen */
    } u;
} IMAP1_BeginSubscriberActivity;

#ifndef _OSSNOVALUES

extern const int IMAP1_maxNumOfPrivateExtensions;

// value assignment
extern const int IMAP1_maxSignalInfoLength;

extern const int IMAP1_maxNumOfTeleServices;

extern const int IMAP1_maxNumOfBearerServices;

extern const int IMAP1_maxNumOfSS;

extern const int IMAP1_maxNumOfCUG;

extern const int IMAP1_maxNumOfBasicServices;

extern const int IMAP1_maxNumOfForwardingFeatures;

extern const int IMAP1_maxNumOfCallBarringFeatures;

extern const int IMAP1_maxNumOfHlrId;

extern const int IMAP1_maxPacketDataVolume;

extern const int IMAP1_maxNumOfChargingUnit;

extern const int IMAP1_maxCallDuration;

extern const int IMAP1_maxAddressLength;

extern const int IMAP1_maxNumOfSentParameters;
// this named value should correspond to the maximum of
// the maxNumOfCUG and the maximum number of authentication
// set which may be returned by a HLR plus 1.

extern const int IMAP1_maxNumOfBasicServiceGroups;

// Imports operation types

// Location management
// Data management
// Supplementary Services Handling
// Call set-up
// Paging
// Handover
// Charging
// Restoration
// Authentication and security
// Equipment management
// Short messages
// Tracing
// Others
// imports error types
// allocation of local value to operations
extern IMAP1_UpdateLocationArea IMAP1_updateLocationArea;

extern IMAP1_UpdateLocation IMAP1_updateLocation;

extern IMAP1_CancelLocation IMAP1_cancelLocation;

extern IMAP1_ProvideRoamingNumber IMAP1_provideRoamingNumber;

extern IMAP1_DetachIMSI IMAP1_detachIMSI;

extern IMAP1_AttachIMSI IMAP1_attachIMSI;

extern IMAP1_InsertSubscriberData IMAP1_insertSubscriberData;

extern IMAP1_DeleteSubscriberData IMAP1_deleteSubscriberData;

extern IMAP1_SendParameters IMAP1_sendParameters;

extern IMAP1_RegisterSS IMAP1_registerSS;

extern IMAP1_EraseSS IMAP1_eraseSS;

extern IMAP1_ActivateSS IMAP1_activateSS;

extern IMAP1_DeactivateSS IMAP1_deactivateSS;

extern IMAP1_InterrogateSS IMAP1_interrogateSS;

extern IMAP1_InvokeSS IMAP1_invokeSS;

extern IMAP1_ForwardSsNotification IMAP1_forwardSsNotification;

extern IMAP1_RegisterPassword IMAP1_registerPassword;

extern IMAP1_GetPassword IMAP1_getPassword;

extern IMAP1_ProcessUnstructuredSsData IMAP1_processUnstructuredSsData;

extern IMAP1_SendInfoForIncomingCall IMAP1_sendInfoForIncomingCall;

extern IMAP1_SendInfoForOutgoingCall IMAP1_sendInfoForOutgoingCall;

extern IMAP1_SendRoutingInformation IMAP1_sendRoutingInformation;

extern IMAP1_CompleteCall IMAP1_completeCall;

extern IMAP1_ConnectToFollowingAddress IMAP1_connectToFollowingAddress;

extern IMAP1_ProcessCallWaiting IMAP1_processCallWaiting;

extern IMAP1_Page IMAP1_page;

extern IMAP1_SearchForMobileSubscriber IMAP1_searchForMobileSubscriber;

extern IMAP1_PerformHandover IMAP1_performHandover;

extern IMAP1_SendEndSignal IMAP1_sendEndSignal;

extern IMAP1_PerformSubsequentHandover IMAP1_performSubsequentHandover;

extern IMAP1_AllocateHandoverNumber IMAP1_allocateHandoverNumber;

extern IMAP1_SendHandoverReport IMAP1_sendHandoverReport;

extern IMAP1_ProcessAccessSignalling IMAP1_processAccessSignalling;

extern IMAP1_ForwardAccessSignalling IMAP1_forwardAccessSignalling;

extern IMAP1_NoteInternalHandover IMAP1_noteInternalHandover;

extern IMAP1_RegisterChargingInformation IMAP1_registerChargingInformation;

extern IMAP1_Reset IMAP1_reset;

extern IMAP1_ForwardCheckSsIndication IMAP1_forwardCheckSsIndication;

extern IMAP1_Authenticate IMAP1_authenticate;

extern IMAP1_ProvideIMSI IMAP1_provideIMSi;

extern IMAP1_ForwardNewTMSI IMAP1_forwardNewTMSI;

extern IMAP1_SetCipheringMode IMAP1_setCipheringMode;

extern IMAP1_CheckIMEI IMAP1_checkIMEI;

extern IMAP1_SendRoutingInfoForSM IMAP1_sendRoutingInfoForSM;

extern IMAP1_ForwardShortMessage IMAP1_forwardShortMessage;

extern IMAP1_SetMessageWaitingData IMAP1_setMessageWaitingData;

extern IMAP1_NoteMSPresent IMAP1_noteMSPresent;

extern IMAP1_AlertServiceCentre IMAP1_alertServiceCentre;

extern IMAP1_ActivateTraceMode IMAP1_activateTraceMode;

extern IMAP1_DeactivateTraceMode IMAP1_deactivateTraceMode;

extern IMAP1_TraceSubscriberActivity IMAP1_traceSubscriberActivity;

extern IMAP1_ProcessAccessRequest IMAP1_processAccessRequest;

extern IMAP1_BeginSubscriberActivity IMAP1_beginSubscriberActivity;

//
// allocation of local value to errors
extern IMAP1_UnknownSubscriber IMAP1_unknownSubscriber;

extern IMAP1_UnknownBaseStation IMAP1_unknownBaseStation;

extern IMAP1_UnknownMSC IMAP1_unknownMSC;

extern IMAP1_UnknownLocArea IMAP1_unknownLocArea;

extern IMAP1_UnidentifiedSubscriber IMAP1_unidentifiedSubscriber;

extern IMAP1_UnallocatedRoamingNumber IMAP1_unallocatedRoamingNumber;

extern IMAP1_UnknownEquipment IMAP1_unknownEquipment;

extern IMAP1_RoamingNotAllowed IMAP1_roamingNotAllowed;

extern IMAP1_IllegalMS IMAP1_illegalMS;

extern IMAP1_BearerServiceNotProvisioned IMAP1_bearerServiceNotProvisioned;

extern IMAP1_TeleserviceNotProvisioned IMAP1_teleServiceNotProvisioned;

extern IMAP1_InsufficientBearerCapabilities IMAP1_insufficientBearerCapabilities;

extern IMAP1_CallBarred IMAP1_callBarred;

extern IMAP1_ForwardingViolation IMAP1_forwardingViolation;

extern IMAP1_CUG_Reject IMAP1_cug_Reject;

extern IMAP1_IllegalSS_Operation IMAP1_illegalSS_Operation;

extern IMAP1_SS_ErrorStatus IMAP1_ss_ErrorStatus;

extern IMAP1_SS_NotAvailable IMAP1_ss_NotAvailable;

extern IMAP1_SS_SubscriptionViolation IMAP1_ss_SubscriptionViolation;

extern IMAP1_SS_Incompatibility IMAP1_ss_Incompatibility;

extern IMAP1_FacilityNotSupported IMAP1_facilityNotSupported;

extern IMAP1_InvalidTargetBaseStation IMAP1_invalidTargetBaseStation;

extern IMAP1_NoRadioResourceAvailable IMAP1_noRadioResourceAvailable;

extern IMAP1_NoHandoverNumberAvailable IMAP1_noHandoverNumberAvailable;

extern IMAP1_SubsequentHandoverFailure IMAP1_subsequentHandoverFailure;

extern IMAP1_AbsentSubscriber IMAP1_absentSubscriber;

extern IMAP1_BusySubscriber IMAP1_busySubscriber;

extern IMAP1_NoSubscriberReply IMAP1_noSubscriberReply;

extern IMAP1_RadioCongestion IMAP1_radioCongestion;

extern IMAP1_ImpossibleCallCompletion IMAP1_impossibleCallCompletion;

extern IMAP1_SM_DeliveryFailure IMAP1_sm_DeliveryFailure;

extern IMAP1_MessageWaitingListFull IMAP1_messageWaitingListFull;

extern IMAP1_SystemFailure IMAP1_systemFailure;

extern IMAP1_DataMissing IMAP1_dataMissing;

extern IMAP1_UnexpectedDataValue IMAP1_unexpectedDataValue;

extern IMAP1_PasswordRegistrationFailure IMAP1_passwordRegistrationFailure;

extern IMAP1_NegativePasswordCheck IMAP1_negativePasswordCheck;

extern IMAP1_NoRoamingNumberAvailable IMAP1_noRoamingNumberAvailable;

extern IMAP1_TracingBufferFull IMAP1_tracingBufferFull;

#endif  /* #ifndef _OSSNOVALUES */


extern void *IMAP1;    /* encoder-decoder control table */
#ifdef __cplusplus
}	/* extern "C" */
#endif /* __cplusplus */
#endif /* OSS_IMAP1 */
