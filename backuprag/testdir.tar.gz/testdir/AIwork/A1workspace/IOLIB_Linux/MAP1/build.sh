PATH=$PATH:/usr/ccs/bin:/usr/local/ossasn1/linux-x86-64/10.5.0/bin

cp MAP1.asn OMAP1.asn
asn1 -c++ -compat v4.2octetStringDefault -compat v4.2defaults -root -ber -noWarning -ignoreIncompleteItems -prefix OMAP1_ /usr/local/ossasn1/linux-x86-64/10.5.0//asn1dflt.linux-amd64 TCAP.asn MAP-ExtensionDataTypes.asn MAP-Constants.asn MAP-DataTypes.asn MAP1-DataTypes.asn MAP-Errors.asn MAP-Operations.asn OMAP1.asn

mv OMAP1.asn IMAP1.asn
asn1 -c++ -root -ber -noWarning -ignoreIncompleteItems -prefix IMAP1_ /usr/local/ossasn1/linux-x86-64/10.5.0/asn1dflt.linux-amd64 TCAP.asn MAP-ExtensionDataTypes.asn MAP-Constants.asn MAP-DataTypes.asn MAP1-DataTypes.asn MAP-Errors.asn MAP-Operations.asn IMAP1.asn

rm *.o
rm IMAP1.asn

mv *.cpp src/

mv *.h inc/

make all

rm *.o
