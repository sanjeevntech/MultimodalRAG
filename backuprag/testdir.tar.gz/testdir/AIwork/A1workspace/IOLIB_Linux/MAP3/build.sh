PATH=$PATH:/usr/ccs/bin:/usr/local/ossasn1/linux-x86-64/10.5.0/bin

cp MAP3.asn IMAP3.asn
asn1 -c++ -root -ber -noWarning -ignoreIncompleteItems  -prefix IMAP3_ /usr/local/ossasn1/linux-x86-64/10.5.0/asn1dflt.linux-amd64 MAP-SecureTransportOperations.asn MAP-LCS-DataTypes.asn MAP-LocationServiceOperations.asn MAP-ST-DataTypes.asn MAP-CommonDataTypes.asn MAP-BS-Code.asn MAP-GR-DataTypes.asn MAP-ExtensionDataTypes.asn MAP-Errors.asn MAP-ER-DataTypes.asn MAP-CH-DataTypes.asn MAP-CallHandlingOperations.asn MAP-MobileServiceOperations.asn MAP-SS-DataTypes.asn MAP-SS-Code.asn MAP-SupplementaryServiceOperations.asn MAP-SM-DataTypes.asn MAP-ShortMessageServiceOperations.asn MAP-OperationAndMaintenanceOperations.asn MAP-OM-DataTypes.asn MAP-TS-Code.asn MAP-Group-Call-Operations.asn MAP-MS-DataTypes.asn TCAP.asn IMAP3.asn

mv IMAP3.asn OMAP3.asn
asn1 -c++ -compat v4.2octetStringDefault -compat v4.2defaults -compat v6.1.3varyingbitstring -root -ber -noWarning -ignoreIncompleteItems -prefix OMAP3_ /usr/local/ossasn1/linux-x86-64/10.5.0/asn1dflt.linux-amd64 MAP-SecureTransportOperations.asn MAP-LCS-DataTypes.asn MAP-LocationServiceOperations.asn MAP-ST-DataTypes.asn MAP-CommonDataTypes.asn MAP-BS-Code.asn MAP-GR-DataTypes.asn MAP-ExtensionDataTypes.asn MAP-Errors.asn MAP-ER-DataTypes.asn MAP-CH-DataTypes.asn MAP-CallHandlingOperations.asn MAP-MobileServiceOperations.asn MAP-SS-DataTypes.asn MAP-SS-Code.asn MAP-SupplementaryServiceOperations.asn MAP-SM-DataTypes.asn MAP-ShortMessageServiceOperations.asn MAP-OperationAndMaintenanceOperations.asn MAP-OM-DataTypes.asn MAP-TS-Code.asn MAP-Group-Call-Operations.asn MAP-MS-DataTypes.asn TCAP.asn OMAP3.asn

mv *.cpp src/

mv *.h inc/

make all

rm *.o
rm OMAP3.asn
