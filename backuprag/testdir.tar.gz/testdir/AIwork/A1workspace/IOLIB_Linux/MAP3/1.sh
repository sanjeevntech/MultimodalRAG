PATH=$PATH:/usr/ccs/bin:/usr/local/ossasn1/solaris7-64bit/8.4.0/bin

asn1 -c++ -compat v4.2octetStringDefault -compat paddedForNamedBits -compat v4.2defaults -root -relaxedMode -ber -prefix MAP3_ ../../asn1dflt.solaris7-64bit MAP-SecureTransportOperations.asn MAP-LCS-DataTypes.asn MAP-LocationServiceOperations.asn MAP-ST-DataTypes.asn MAP-CommonDataTypes.asn MAP-BS-Code.asn MAP-GR-DataTypes.asn MAP-ExtensionDataTypes.asn MAP-Errors.asn MAP-ER-DataTypes.asn MAP-CH-DataTypes.asn MAP-CallHandlingOperations.asn MAP-MobileServiceOperations.asn MAP-SS-DataTypes.asn MAP-SS-Code.asn MAP-SupplementaryServiceOperations.asn MAP-SM-DataTypes.asn MAP-ShortMessageServiceOperations.asn MAP-OperationAndMaintenanceOperations.asn MAP-OM-DataTypes.asn MAP-TS-Code.asn MAP-Group-Call-Operations.asn MAP-MS-DataTypes.asn MAP3.asn

mv *.cpp src/

mv *.h inc/

make all

rm *.o
