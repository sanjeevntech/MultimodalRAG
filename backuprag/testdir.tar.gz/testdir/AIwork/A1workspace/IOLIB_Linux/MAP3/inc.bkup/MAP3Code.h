
#ifndef _MAP3_H
#define _MAP3_H


#ifdef __cplusplus
extern "C" {
#endif



#include "ossasn1.h"

//!
/*! @brief  Defined all Encoding calls.
*  Contains encoding calls
*/

/**
 * @defgroup MAP3 MAP3 ASN Encoder Decoder API
 * @brief MAP3 ASN Encoder Decoder API, used to encode decode MAP3 Messages using Binary Encoding Rules.
 *
 *
 *   	MAP3 Encode Decode Library has two main functions. The first part is to
 *   encode data in ASN.1 BER format. The second part is to decode the encoded data
 *   and reconstruct the data in structure format.
 *   	When a MAP3 message is to be sent, the appropriate structure needs to be filled
 *   in with the data that needs to be sent. When the filled in structure is passed
 *   to the encoding function, it encodes them into a character buffer that can be
 *   transmitted using TCAP. The length of data that is to be sent is also given.
 *   Similarly when a MAP3 message in ASN.1 format is received, the received buffer is
 *   to be passed to the decode function which will decode the message and populate
 *   the structure.
 *
 *   <h3>Memory Management</h3>
 *
 *   	When encoding is done, the encoder allocates a buffer to store the encoded data.
 *   Similarly on decoding, the decoder creates the structure and fills up. To release
 *   these memory space once the operation(s) are done or when appropriate, the following
 *   functions need to be called.
 *   MAP3_FreePDU() - for releasing the structure allocated by decoder.
 *   MAP3_FreeBuf() - for releasing the buffer.
 *   	It is advisible to free encoded / decoded data resources through these functions.
 *
 *   <h3>Debugging</h3>
 *
 *   	The function MAP3_PrintPDU() can be used to print the MAP3 message in a human
 *   readable format.
 *
 *   The MAP3_PrintPDU() prints the datastructure in a formatted manner. It would be helpful
 *   if encoding fails to see the reason in a more friendly manner.
 *
 *   The MAP3_GetErrMsg() function gives the most recent errors the encoder / decoder encountered.
 *
 *  Action On Errors :
 *  	The errors that are encountered can be classified into the following categories.\n
 *  	1. Encoding errors.\n
 *  	2. Decoding Errors.\n
 *  	3. System Errors.\n
 *	1. Encoding errors\n
 * 		These are the errors that are encountered when trying to encode a MAP3 message.\n
 *		To fix these errors, proper data need to be passed on to the encoder.\n
 *	2. Decoding Errors.\n
 *		These are the errors that are encountered when decoding data received.\n
 *		Ensure that full data that is received is passed on to decoder.\n
 *		If all at this end are fine, TCAP retransmission / error need to be raised.\n
 *		Refer to TCAP manual for the procedures.\n
 *  	3. System Errors \n
 *		Appropriate messages that vary from dropping connection need to be decided by \n 
 *		the application and sent. The necessary actions to be taken varies according to application's needs.\n
 *
 *
 * <h3>Example</h3>
 * <pre>
 * @code
 *
 * The following piece of code demonstrates the use of MAP3 Encode Decode API.
 *
 * Using a message structure defined in the MAP3 message set, the message is first
 * filled up with data. Then it is encoded to a buffer, then it is decoded.
 * The message is printed in PDU format before encoding and after decoding.
 *
 * #include <MAP3Code.h>
 * #include <MAP3.h>
 * #include <string.h>

 * void init();
 * unsigned char*  testEncodeIDP(int* P_buffLen);
 * int testDecodeIDP(unsigned char* P_buff,int P_buffLen);

 * int main()
 * {
 *  int L_buffLen=0;
 *  unsigned char* L_buffer = NULL;
 *  init();
 *  L_buffer = testEncodeIDP(&L_buffLen);

 *  if ( L_buffer != 0 )
        printf( " Testing of the testEncodeRandVarReq sucessfull =========>  \n");
 *  else
 *  {
        printf( " Testing of the testEncodeRandVarReq failed  =========>  \n");
        exit(-1);
 *   }

 * if ( testDecodeIDP (L_buffer,L_buffLen) == 0 )
        printf( " Testing of the testDecodeRandVarReq sucessfull =========>  \n");
 * else
        printf( " Testing of the testDecodeRandVarReq failed  =========>  \n");

 * return 0;
 * }

 * void init()
 * {
 *  int L_result;
 *  L_result = MAP3_initialize();
 *  if (L_result == 0 )
 *   printf(" Intialsation completed sucessfully ====> \n");
 *  else
 *   printf(" Intialsation completed failed and result is %d ====> \n", L_result);
 * }

 * unsigned char* testEncodeIDP(int *P_buffLen)
 * {
 *  unsigned char* L_encodedBuffer = NULL;
 *  int L_bufferLen=0;
 *  int L_result;
 *  InitialDPArg L_iDP;

 *  L_iDP.bit_mask = calledPartyNumber_present | InitialDPArg_callingPartyNumber_present;
 *  L_iDP.serviceKey = 1234;
 *  L_iDP.calledPartyNumber.length = 12;
 *  strcpy((char*)L_iDP.calledPartyNumber.value,"98450123456");

 *  L_iDP.callingPartyNumber.length = 10;
 *  strcpy((char*)L_iDP.callingPartyNumber.value,"984501234");

 *  L_result = MAP3_encode(&L_iDP,InitialDPArg_PDU,&L_encodedBuffer,&L_bufferLen);

 *  if (L_result == 0 )
 *  {
 *   *P_buffLen = L_bufferLen;
 *   return L_encodedBuffer;
 *  }
 *  else
 *  {
 *   printf("+++++> %s      \n",MAP3_getErrMsg());
 *   return NULL;
 *  }
 * }

 * int testDecodeIDP(unsigned char* P_buff,int P_buffLen)
 * {
 *  void* L_decodedStruct=NULL;
 *  if ( MAP3_decode(&P_buff,P_buffLen,InitialDPArg_PDU,&L_decodedStruct) != 0 )
 *  {
 *    printf(" testDecodeRandVarReq failed ====> \n");
 *    exit(-1);
 *  }
 *  MAP3_printPDU(InitialDPArg_PDU,L_decodedStruct);
 *  return 0;
 * }
 *
 *  @endcode 
 *  </pre>
 *	 Please note that an application may use preallocated buffers for encoding and decoding.
 * @{
 */

/**
 *	MAP3_PrintPDU prints the MAP3 message in formatted manner.
 * 	Takes in the message type (PDU number) in MAP3.h and the filled up
 * 	data structure as arguments.
 *	On successful return, the passed PDU will have been printed in current system out file.
 * @param  P_MsgType    PDU Number of the datastructure to be printed.
 * @param  P_DataStruct Filled up datastructure that is to be printed.
 * @return void
**/
int  MAP3_initialize();

/**
 * MAP3_PrintPDU prints the MAP3 message in formatted manner. Takes in the message type (PDU number)
 * in MAP3.h and the filled up data structure as arguments. On successful return, the passed PDU
 * will have been printed in current system out file. 

 * @param P_MsgType  PDU Number of the datastructure to be printed.  
 * @param P_DataStruct  Filled up datastructure that is to be printed.  
 * @return void 
 **/
void MAP3_printPDU(int P_msgType,void *P_dataStruct);

/**
 *	Frees the allocated structure. It is recommended that this function be used
 * 	wherever MAP3 structures are to be freed as this would also clean up the data
 * 	stored in the structures as pointers are also cleaned up intelligently.
 *
 * 	On successful return, the pointed memory will have been freed up.
 * @param  P_MsgType    PDU Number of the datastructure to be printed.
 * @param  P_Data       Pointer to the structure to be freed.
 * @return void
 */
void MAP3_freePDU(int P_msgType, void* P_data);

/**
 *	Releases the memory buffer allocated by the encoder. This function must be used
 * 	wherever any encoded message is to be freed as encoder owns the memory and cannot
 * 	release unless specified by the user. (If preallocated memory is used for encoded
 *	data then this call is not required.
 * 	On successful return, the pointed memory will have been freed up.
 * @param  P_Buff  Pointer to be buffer to be freed.
 * @return void
 */
void MAP3_freeBuf(unsigned char *P_buff);

/**
 *    	The value filled structure dataStruct is encoded in ASN.1 format using BER.
 *    On return encodedData points to the encoded buffer, datalength points to the
 *    length of encoded buffer.
 *    	If you initialize the length and value fields of the output variable to
 *    NULL and zero, respectively, the encoder will automatically allocate the space
 *    needed for the output buffer. Alternatively if you pre-allocate a memory buffer
 *    by yourself for the finished encoding, you should set the buffer
 *    to reference the beginning of the buffer and the length field to the length in
 *    bytes of the allocated buffer.After a successful return, the encoded data will
 *    be pointed to by the value field of the buffer variable.In addition, the buffer
 *    length field will contain the length in bytes of the finished encoding.
 * @param  P_DataStruct	Pointer to the filled up Datastructure PDU to be encoded.
 * @param  P_MsgType      PDU Number of the message.
 * @param  P_EncodedData  On return, points to the encoded data. (If preallocated buffer
 *                      is to be used, then the address of the buffer where encoded data
 *                      is to be written is passed.
 * @param  P_DataLength   On return, points to the no of bytes in encoded data. (If preallocation
 *                      is used, on return points to the no. of bytes to be taken from buffer. This
 *                      can be determined using the MAP3_getEncodingLength API).
 * @return 0 in case of success, +ve integer in case of failure. Refer to error codes for details.
 */
int MAP3_encode(void *P_dataStruct,int P_msgType, unsigned char **P_encodedData, int *P_dataLength);

/**
 *     Decodes the ASN.1 (BER) encoded buffer into the structure specified.
 *   The type of the message that this buffer represents is specified by the P_MsgType parameter.
 *   input is the address of an P_EncodedData whose value field references the BER
 *   encoding to be decoded and whose length field holds the length in bytes of this
 *   encoding, and output is the address of a pointer to the memory block designated to hold
 *   the decoded PDU.
 * @param  P_EncodedData   Pointer to the encoded (received) buffer.
 * @param  P_BuffLen       No. of bytes to be taken from the buffer.
 * @param  P_MsgType       PDU number of the message to be decoded.
 * @param  P_DecodedStruct On return points to the decoded structure. ( If preallocation is used,
 *                       pass the pointer to the structure where data is to be filled in).
 * @return 0 in case of success, +ve integer in case of failure. Refer to error codes for details.
 */
int MAP3_decode(unsigned char **P_EncodedData,int P_BuffLen,int P_MsgType, void **P_DecodedStruct);

/**
 * This is for use by applications that pre-allocate memory for the decoder's output
 * buffer. This function makes the length of the pre-allocated memory buffer available to the
 * decoder at run-time. The MAP3_SetDecodingLength() function must be called prior to the call to
 * MAP3_Decode(), if you pre-allocated the decoder's output buffer.
 *
 * bufferLength is the length in bytes of the pre-allocated decoder output buffer.
 * This argument is referenced by the MAP3_Decode() only if the MAP3_Decode() is sent
 * a non-NULL value in its output field. After a successful return, the length of
 * the pre-allocated decoder output buffer will be available for reference by the
 * decoder.
 *
 * @param  P_BufferLength The length of the buffer allocated for decoding.
 * @return 0 on success; otherwise, a non-zero value is returned.
 */
long MAP3_setDecodingLength(long P_bufferLength);

/**
 * The MAP3_GetEncodingLength() function returns the size of the encoded data that MAP3_Encode()
 * would create if it were called to encode the sent PDU. This function allows you to find the size of the buffer
 * needed to store the encoder's output, without calling MAP3_Encode().
 * The MAP3_GetEncodingLength() function has the following prototype:
 * where pdunum is the PDU number for the compiler-generated data structure whose
 * encoding length is desired, and data is the address of this data structure.
 * Return value: a long integer. Upon a successful call, the number of octets to be
 * 	occupied by the data's encoding is returned; otherwise, a length of zero is returned.
 *
 * @param  P_MsgType PDU number of the message to be checked.
 * @param  P_Data    Filled in datastructure (message) to be checked.
 * @return         No of bytes the message would occupy if encoded.
 */
long MAP3_getEncodingLength(int P_msgType,void *P_data);


/** Retrieves error messages generated by the MAP3_Encode() and MAP3_Decode() functions.
 *  This function should be called when MAP3_Encode() / MAP3_Decode() return a nonzero
 *  value.
 *
 * The MAP3_GetErrMsg() function has the following prototype:
 *
 * Return value: The MAP3_GetErrMsg() function returns a character string pointer. If the encoder/decoder
 * experienced runtime errors, the first error message generated in the last call to the encoder/decoder is returned. If
 * the last call to the encoder/decoder did not result in an error, an empty character string ("") is returned.
 *
 * @return A string describing the last error encountered by encoder/decoder.
 */
char *MAP3_getErrMsg();

/**
* @}
*/


#ifdef  __cplusplus
}
#endif

#endif

