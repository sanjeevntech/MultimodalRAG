#include <iostream.h>
#include <stdio.h>

#include "MAP3.h"
#include "MAP3Code.h"

#if 0
typedef struct MAP2_MAP_DialoguePDU {
    unsigned short  choice;
#       define      MAP2_map_open_chosen 1
#       define      MAP2_map_accept_chosen 2
#       define      MAP2_map_close_chosen 3
#       define      MAP2_map_refuse_chosen 4
#       define      MAP2_map_userAbort_chosen 5
#       define      MAP2_map_providerAbort_chosen 6
    union _union {
        struct MAP2__seq2 {
            unsigned char   bit_mask;
#               define      MAP2_map_open_destinationReference_present 0x80
#               define      MAP2_map_open_originationReference_present 0x40
            MAP2__octet1    destinationReference;  /* optional; set in bit_mask
                                * MAP2_map_open_destinationReference_present if
                                * present */
            MAP2__octet1    originationReference;  /* optional; set in bit_mask
                                * MAP2_map_open_originationReference_present if
                                * present */
        } map_open;  /* to choose, set choice to MAP2_map_open_chosen */
        MAP2__seq3      map_accept;  /* to choose, set choice to
                                      * MAP2_map_accept_chosen */
        MAP2__seq3      map_close;  /* to choose, set choice to
                                     * MAP2_map_close_chosen */
        struct MAP2__seq4 {
            MAP2__enum1     reason;
        } map_refuse;  /* to choose, set choice to MAP2_map_refuse_chosen */
        struct MAP2__seq5 {
            MAP2__choice6   map_UserAbortChoice;
        } map_userAbort;  /* to choose, set choice to
                           * MAP2_map_userAbort_chosen */
        struct MAP2__seq6 {
            MAP2__enum4     map_ProviderAbortReason;
        } map_providerAbort;  /* to choose, set choice to
                               * MAP2_map_providerAbort_chosen */
    } u;
} MAP2_MAP_DialoguePDU;
#endif

int main()
{
  int L_result, L_bufferLen = 0;
  unsigned char *L_encodedBuffer = NULL;

  MAP3_InsertSubscriberDataArg arr[1];
  MAP3_SendRoutingInfoRes arr2[1];

 printf("Size of ISD %d ====> \n", sizeof(MAP3_InsertSubscriberDataArg));
 printf("Size of SRI Res %d ====> \n", sizeof(MAP3_SendRoutingInfoRes));
 printf("time %d\n", time(NULL));
 for(int i = 0 ; i < 100000; i++)
   memset(&arr, '\0', sizeof(MAP3_InsertSubscriberDataArg));
 printf("time %d\n", time(NULL));
 

#if 0
  MAP2_MAP_DialoguePDU mapDilogue;

  if (0 == (L_result = MAP2_initialize()))
    printf(" Intialsation completed sucessfully ====> \n");
  else
    printf(" Intialsation completed failed and result is %d ====> \n", L_result);


  mapDilogue.choice = MAP2_map_open_chosen;
  mapDilogue.u.map_open.bit_mask = MAP2_map_open_destinationReference_present;
  mapDilogue.u.map_open.bit_mask |= MAP2_map_open_originationReference_present;
  mapDilogue.u.map_open.destinationReference.length = 9;
  mapDilogue.u.map_open.destinationReference.value[0] = 0x19;
  mapDilogue.u.map_open.destinationReference.value[1] = 0x79;
  mapDilogue.u.map_open.destinationReference.value[2] = 0x98;
  mapDilogue.u.map_open.destinationReference.value[3] = 0x00;
  mapDilogue.u.map_open.destinationReference.value[4] = 0x64;
  mapDilogue.u.map_open.destinationReference.value[5] = 0x09;
  mapDilogue.u.map_open.destinationReference.value[6] = 0x98;
  mapDilogue.u.map_open.destinationReference.value[7] = 0x00;
  mapDilogue.u.map_open.destinationReference.value[8] = 0x64;

  mapDilogue.u.map_open.originationReference.length = 7;
  mapDilogue.u.map_open.originationReference.value[0] = 0x19;
  mapDilogue.u.map_open.originationReference.value[1] = 0x19;
  mapDilogue.u.map_open.originationReference.value[2] = 0x14;
  mapDilogue.u.map_open.originationReference.value[3] = 0x19;
  mapDilogue.u.map_open.originationReference.value[4] = 0x19;
  mapDilogue.u.map_open.originationReference.value[5] = 0x19;
  mapDilogue.u.map_open.originationReference.value[6] = 0x19;

  if(0 == (L_result = MAP2_encode(&mapDilogue, MAP2_MAP_DialoguePDU_PDU, &L_encodedBuffer, &L_bufferLen)))
  {
    printf("Encoded sucessfully ====> \n");
    printf("Encoded Buffer: \n");
    for(int i = 0; i < L_bufferLen; i++)
      printf("%2x ", L_encodedBuffer[i]);
    printf("\n");
    MAP2_MAP_DialoguePDU *decUserInfo = NULL;
    printf("length: %x\n", L_bufferLen);
    if(0 == (L_result = MAP2_decode(&L_encodedBuffer, L_bufferLen, MAP2_MAP_DialoguePDU_PDU, (void **)&decUserInfo)))
    {
      MAP2_printPDU(MAP2_MAP_DialoguePDU_PDU, decUserInfo);
    }
  }
  else
    printf("Failed to encode %d ====> \n", L_result);
#endif
  
  return 0;
}
