/*************************************************************/
/* Copyright (C) 2021 OSS Nokalva, Inc.  All rights reserved.*/
/*************************************************************/

/* THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC.
 * AND MAY BE USED ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC.
 * THIS FILE MAY NOT BE DISTRIBUTED.
 * THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED. */

/* Generated for: Plintron Global Technology Solutions Pvt. Ltd. - Site-based, License 75139 75139,
 * at GKS Tech Park, DLT IT SEZ, Chennai 600089, India. */
/* Abstract syntax: OMAP3 */
/* Created: Thu Jun 10 21:57:50 2021 */
/* ASN.1 compiler version: 10.5 */
/* Code generated for runtime version 10.5 or later */
/* Compiler operating system: Linux with 64-bit support */
/* Compiler machine type: AMD64 */
/* Target operating system: Linux with 64-bit support */
/* Target machine type: AMD64 */
/* C compiler options required: -m64 */
/* ASN.1 compiler options and file names specified:
 * -prefix OMAP3_ -c++ -nowarningmessages -ber -root -ignoreIncompleteItems
 * -compat v4.2defaults -compat v4.2octetstringdefault
 * -compat v6.1.3varyingbitstring
 * /usr/local/ossasn1/linux-x86-64/10.5.0/asn1dflt.linux-amd64
 * MAP-SecureTransportOperations.asn MAP-LCS-DataTypes.asn
 * MAP-LocationServiceOperations.asn MAP-ST-DataTypes.asn
 * MAP-CommonDataTypes.asn MAP-BS-Code.asn MAP-GR-DataTypes.asn
 * MAP-ExtensionDataTypes.asn MAP-Errors.asn MAP-ER-DataTypes.asn
 * MAP-CH-DataTypes.asn MAP-CallHandlingOperations.asn
 * MAP-MobileServiceOperations.asn MAP-SS-DataTypes.asn MAP-SS-Code.asn
 * MAP-SupplementaryServiceOperations.asn MAP-SM-DataTypes.asn
 * MAP-ShortMessageServiceOperations.asn
 * MAP-OperationAndMaintenanceOperations.asn MAP-OM-DataTypes.asn
 * MAP-TS-Code.asn MAP-Group-Call-Operations.asn MAP-MS-DataTypes.asn
 * TCAP.asn OMAP3.asn
 */

#ifndef OSS_OMAP3
#define OSS_OMAP3

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include "ossasn1.h"

#define          OMAP3_RoutingInfoForLCS_Arg_PDU 1
#define          OMAP3_RoutingInfoForLCS_Res_PDU 2
#define          OMAP3_ProvideSubscriberLocation_Arg_PDU 3
#define          OMAP3_ProvideSubscriberLocation_Res_PDU 4
#define          OMAP3_SubscriberLocationReport_Arg_PDU 5
#define          OMAP3_SubscriberLocationReport_Res_PDU 6
#define          OMAP3_SecureTransportArg_PDU 7
#define          OMAP3_SecureTransportRes_PDU 8
#define          OMAP3_SubscriberId_PDU 9
#define          OMAP3_NetworkNodeDiameterAddress_PDU 10
#define          OMAP3_PrepareGroupCallArg_PDU 11
#define          OMAP3_PrepareGroupCallRes_PDU 12
#define          OMAP3_SendGroupCallEndSignalArg_PDU 13
#define          OMAP3_SendGroupCallEndSignalRes_PDU 14
#define          OMAP3_ForwardGroupCallSignallingArg_PDU 15
#define          OMAP3_ProcessGroupCallSignallingArg_PDU 16
#define          OMAP3_Errors_SS_Status_PDU 17
#define          OMAP3_RoamingNotAllowedParam_PDU 18
#define          OMAP3_CallBarredParam_PDU 19
#define          OMAP3_CUG_RejectParam_PDU 20
#define          OMAP3_SS_IncompatibilityCause_PDU 21
#define          OMAP3_PW_RegistrationFailureCause_PDU 22
#define          OMAP3_SM_DeliveryFailureCause_PDU 23
#define          OMAP3_AbsentSubscriberSM_Param_PDU 24
#define          OMAP3_SystemFailureParam_PDU 25
#define          OMAP3_DataMissingParam_PDU 26
#define          OMAP3_UnexpectedDataParam_PDU 27
#define          OMAP3_FacilityNotSupParam_PDU 28
#define          OMAP3_OR_NotAllowedParam_PDU 29
#define          OMAP3_UnknownSubscriberParam_PDU 30
#define          OMAP3_NumberChangedParam_PDU 31
#define          OMAP3_UnidentifiedSubParam_PDU 32
#define          OMAP3_IllegalSubscriberParam_PDU 33
#define          OMAP3_IllegalEquipmentParam_PDU 34
#define          OMAP3_BearerServNotProvParam_PDU 35
#define          OMAP3_TeleservNotProvParam_PDU 36
#define          OMAP3_TracingBufferFullParam_PDU 37
#define          OMAP3_NoRoamingNbParam_PDU 38
#define          OMAP3_AbsentSubscriberParam_PDU 39
#define          OMAP3_BusySubscriberParam_PDU 40
#define          OMAP3_NoSubscriberReplyParam_PDU 41
#define          OMAP3_ForwardingViolationParam_PDU 42
#define          OMAP3_ForwardingFailedParam_PDU 43
#define          OMAP3_ATI_NotAllowedParam_PDU 44
#define          OMAP3_ATSI_NotAllowedParam_PDU 45
#define          OMAP3_ATM_NotAllowedParam_PDU 46
#define          OMAP3_IllegalSS_OperationParam_PDU 47
#define          OMAP3_SS_NotAvailableParam_PDU 48
#define          OMAP3_SS_SubscriptionViolationParam_PDU 49
#define          OMAP3_InformationNotAvailableParam_PDU 50
#define          OMAP3_SubBusyForMT_SMS_Param_PDU 51
#define          OMAP3_MessageWaitListFullParam_PDU 52
#define          OMAP3_ResourceLimitationParam_PDU 53
#define          OMAP3_NoGroupCallNbParam_PDU 54
#define          OMAP3_IncompatibleTerminalParam_PDU 55
#define          OMAP3_ShortTermDenialParam_PDU 56
#define          OMAP3_LongTermDenialParam_PDU 57
#define          OMAP3_UnauthorizedRequestingNetwork_Param_PDU 58
#define          OMAP3_UnauthorizedLCSClient_Param_PDU 59
#define          OMAP3_PositionMethodFailure_Param_PDU 60
#define          OMAP3_UnknownOrUnreachableLCSClient_Param_PDU 61
#define          OMAP3_MM_EventNotSupported_Param_PDU 62
#define          OMAP3_TargetCellOutsideGCA_Param_PDU 63
#define          OMAP3_SecureTransportErrorParam_PDU 64
#define          OMAP3_SendRoutingInfoArg_PDU 65
#define          OMAP3_SendRoutingInfoRes_PDU 66
#define          OMAP3_ProvideRoamingNumberArg_PDU 67
#define          OMAP3_ProvideRoamingNumberRes_PDU 68
#define          OMAP3_ResumeCallHandlingArg_PDU 69
#define          OMAP3_ResumeCallHandlingRes_PDU 70
#define          OMAP3_SetReportingStateArg_PDU 71
#define          OMAP3_SetReportingStateRes_PDU 72
#define          OMAP3_StatusReportArg_PDU 73
#define          OMAP3_StatusReportRes_PDU 74
#define          OMAP3_RemoteUserFreeArg_PDU 75
#define          OMAP3_RemoteUserFreeRes_PDU 76
#define          OMAP3_IST_AlertArg_PDU 77
#define          OMAP3_IST_AlertRes_PDU 78
#define          OMAP3_IST_CommandArg_PDU 79
#define          OMAP3_IST_CommandRes_PDU 80
#define          OMAP3_ReleaseResourcesArg_PDU 81
#define          OMAP3_ReleaseResourcesRes_PDU 82
#define          OMAP3_RegisterSS_Arg_PDU 83
#define          OMAP3_SS_Info_PDU 84
#define          OMAP3_SS_ForBS_Code_PDU 85
#define          OMAP3_InterrogateSS_Res_PDU 86
#define          OMAP3_USSD_Arg_PDU 87
#define          OMAP3_USSD_Res_PDU 88
#define          OMAP3_Password_PDU 89
#define          OMAP3_GuidanceInfo_PDU 90
#define          OMAP3_SS_InfoList_PDU 91
#define          OMAP3_SS_InvocationNotificationArg_PDU 92
#define          OMAP3_SS_InvocationNotificationRes_PDU 93
#define          OMAP3_RegisterCC_EntryArg_PDU 94
#define          OMAP3_RegisterCC_EntryRes_PDU 95
#define          OMAP3_EraseCC_EntryArg_PDU 96
#define          OMAP3_EraseCC_EntryRes_PDU 97
#define          OMAP3_SS_Code_PDU 98
#define          OMAP3_RoutingInfoForSM_Arg_PDU 99
#define          OMAP3_RoutingInfoForSM_Res_PDU 100
#define          OMAP3_MO_ForwardSM_Arg_PDU 101
#define          OMAP3_MO_ForwardSM_Res_PDU 102
#define          OMAP3_MT_ForwardSM_Arg_PDU 103
#define          OMAP3_MT_ForwardSM_Res_PDU 104
#define          OMAP3_ReportSM_DeliveryStatusArg_PDU 105
#define          OMAP3_ReportSM_DeliveryStatusRes_PDU 106
#define          OMAP3_AlertServiceCentreArg_PDU 107
#define          OMAP3_InformServiceCentreArg_PDU 108
#define          OMAP3_ReadyForSM_Arg_PDU 109
#define          OMAP3_ReadyForSM_Res_PDU 110
#define          OMAP3_MT_ForwardSM_VGCS_Arg_PDU 111
#define          OMAP3_MT_ForwardSM_VGCS_Res_PDU 112
#define          OMAP3_ActivateTraceModeArg_PDU 113
#define          OMAP3_SendIMSIArg_PDU 114
#define          OMAP3_SendIMSIRes_PDU 115
#define          OMAP3_ActivateTraceModeRes_PDU 116
#define          OMAP3_DeactivateTraceModeArg_PDU 117
#define          OMAP3_DeactivateTraceModeRes_PDU 118
#define          OMAP3_UpdateLocationArg_PDU 119
#define          OMAP3_UpdateLocationRes_PDU 120
#define          OMAP3_CancelLocationArg_PDU 121
#define          OMAP3_CancelLocationRes_PDU 122
#define          OMAP3_PurgeMS_Arg_PDU 123
#define          OMAP3_PurgeMS_Res_PDU 124
#define          OMAP3_SendIdentificationArg_PDU 125
#define          OMAP3_SendIdentificationRes_PDU 126
#define          OMAP3_AuthenticationFailureReportArg_PDU 127
#define          OMAP3_AuthenticationFailureReportRes_PDU 128
#define          OMAP3_UpdateGprsLocationArg_PDU 129
#define          OMAP3_UpdateGprsLocationRes_PDU 130
#define          OMAP3_ForwardAccessSignalling_Arg_PDU 131
#define          OMAP3_PrepareHO_Arg_PDU 132
#define          OMAP3_PrepareHO_Res_PDU 133
#define          OMAP3_PrepareSubsequentHO_Arg_PDU 134
#define          OMAP3_PrepareSubsequentHO_Res_PDU 135
#define          OMAP3_ProcessAccessSignalling_Arg_PDU 136
#define          OMAP3_SendEndSignal_Arg_PDU 137
#define          OMAP3_SendEndSignal_Res_PDU 138
#define          OMAP3_SendAuthenticationInfoArg_PDU 139
#define          OMAP3_SendAuthenticationInfoRes_PDU 140
#define          OMAP3_CheckIMEI_Arg_PDU 141
#define          OMAP3_CheckIMEI_Res_PDU 142
#define          OMAP3_InsertSubscriberDataArg_PDU 143
#define          OMAP3_InsertSubscriberDataRes_PDU 144
#define          OMAP3_DeleteSubscriberDataArg_PDU 145
#define          OMAP3_DeleteSubscriberDataRes_PDU 146
#define          OMAP3_SendRoutingInfoForGprsArg_PDU 147
#define          OMAP3_SendRoutingInfoForGprsRes_PDU 148
#define          OMAP3_FailureReportArg_PDU 149
#define          OMAP3_FailureReportRes_PDU 150
#define          OMAP3_NoteMsPresentForGprsArg_PDU 151
#define          OMAP3_NoteMsPresentForGprsRes_PDU 152
#define          OMAP3_ResetArg_PDU 153
#define          OMAP3_RestoreDataArg_PDU 154
#define          OMAP3_RestoreDataRes_PDU 155
#define          OMAP3_ProvideSubscriberInfoArg_PDU 156
#define          OMAP3_ProvideSubscriberInfoRes_PDU 157
#define          OMAP3_AnyTimeInterrogationArg_PDU 158
#define          OMAP3_AnyTimeInterrogationRes_PDU 159
#define          OMAP3_AnyTimeSubscriptionInterrogationArg_PDU 160
#define          OMAP3_AnyTimeSubscriptionInterrogationRes_PDU 161
#define          OMAP3_AnyTimeModificationArg_PDU 162
#define          OMAP3_AnyTimeModificationRes_PDU 163
#define          OMAP3_NoteSubscriberDataModifiedArg_PDU 164
#define          OMAP3_NoteSubscriberDataModifiedRes_PDU 165
#define          OMAP3_NoteMM_EventArg_PDU 166
#define          OMAP3_NoteMM_EventRes_PDU 167

typedef struct OMAP3__ObjectID_ {
    struct OMAP3__ObjectID_ *next;
    unsigned short  value;
} *OMAP3__ObjectID;

typedef struct OMAP3_ISDN_AddressString {
    unsigned short  length;
    unsigned char   value[9];
} OMAP3_ISDN_AddressString;

	// all other values of Alerting Category are reserved
	// Alerting categories are defined in GSM 02.07

// data types for numbering and identification
typedef struct OMAP3_IMSI {
    unsigned short  length;
    unsigned char   value[8];
} OMAP3_IMSI;

	// The internal structure is defined by the Carrier Identification
	// parameter in ANSI T1.113.3. Carrier codes between .000. and .999. may
	// be encoded as 3 digits using .000. to .999. or as 4 digits using 
	// .0000. to .0999.. Carrier codes between .1000. and .9999. are encoded
	// using 4 digits.
typedef struct OMAP3_SubscriberIdentity {
    unsigned short  choice;
#       define      OMAP3_SubscriberIdentity_imsi_chosen 1
#       define      OMAP3_SubscriberIdentity_msisdn_chosen 2
    union _union {
        OMAP3_IMSI      imsi;  /* to choose, set choice to
                                * OMAP3_SubscriberIdentity_imsi_chosen */
        OMAP3_ISDN_AddressString msisdn;  /* to choose, set choice to
                                    * OMAP3_SubscriberIdentity_msisdn_chosen */
    } u;
} OMAP3_SubscriberIdentity;

typedef enum OMAP3_PW_RegistrationFailureCause {
    OMAP3_undetermined = 0,
    OMAP3_invalidFormat = 1,
    OMAP3_newPasswordsMismatch = 2
} OMAP3_PW_RegistrationFailureCause;

typedef char            OMAP3_Password[5];

typedef enum OMAP3_GuidanceInfo {
    OMAP3_enterPW = 0,
    OMAP3_enterNewPW = 1,
    OMAP3_enterNewPW_Again = 2
} OMAP3_GuidanceInfo;

union OMAP3_All_PDU_Types_union {
    struct OMAP3_RoutingInfoForLCS_Arg *pdu_RoutingInfoForLCS_Arg;  
                                          /* OMAP3_RoutingInfoForLCS_Arg_PDU */
    struct OMAP3_RoutingInfoForLCS_Res *pdu_RoutingInfoForLCS_Res;  
                                          /* OMAP3_RoutingInfoForLCS_Res_PDU */
    struct OMAP3_ProvideSubscriberLocation_Arg *pdu_ProvideSubscriberLocation_Arg;                                      /* OMAP3_ProvideSubscriberLocation_Arg_PDU */
    struct OMAP3_ProvideSubscriberLocation_Res *pdu_ProvideSubscriberLocation_Res;                                      /* OMAP3_ProvideSubscriberLocation_Res_PDU */
    struct OMAP3_SubscriberLocationReport_Arg *pdu_SubscriberLocationReport_Arg;                                        /* OMAP3_SubscriberLocationReport_Arg_PDU */
    struct OMAP3_SubscriberLocationReport_Res *pdu_SubscriberLocationReport_Res;                                        /* OMAP3_SubscriberLocationReport_Res_PDU */
    struct OMAP3_SecureTransportArg *pdu_SecureTransportArg;  
                                             /* OMAP3_SecureTransportArg_PDU */
    struct OMAP3_SecureTransportRes *pdu_SecureTransportRes;  
                                             /* OMAP3_SecureTransportRes_PDU */
    struct OMAP3_SubscriberId *pdu_SubscriberId;  /* OMAP3_SubscriberId_PDU */
    struct OMAP3_NetworkNodeDiameterAddress *pdu_NetworkNodeDiameterAddress;  
                                        /* OMAP3_NetworkNodeDiameterAddress_PDU */
    struct OMAP3_PrepareGroupCallArg *pdu_PrepareGroupCallArg;  
                                            /* OMAP3_PrepareGroupCallArg_PDU */
    struct OMAP3_PrepareGroupCallRes *pdu_PrepareGroupCallRes;  
                                            /* OMAP3_PrepareGroupCallRes_PDU */
    struct OMAP3_SendGroupCallEndSignalArg *pdu_SendGroupCallEndSignalArg;  
                                        /* OMAP3_SendGroupCallEndSignalArg_PDU */
    struct OMAP3_SendGroupCallEndSignalRes *pdu_SendGroupCallEndSignalRes;  
                                        /* OMAP3_SendGroupCallEndSignalRes_PDU */
    struct OMAP3_ForwardGroupCallSignallingArg *pdu_ForwardGroupCallSignallingArg;                                      /* OMAP3_ForwardGroupCallSignallingArg_PDU */
    struct OMAP3_ProcessGroupCallSignallingArg *pdu_ProcessGroupCallSignallingArg;                                      /* OMAP3_ProcessGroupCallSignallingArg_PDU */
    struct OMAP3_Errors_SS_Status *pdu_SS_Status;  
                                               /* OMAP3_Errors_SS_Status_PDU */
    struct OMAP3_RoamingNotAllowedParam *pdu_RoamingNotAllowedParam;  
                                         /* OMAP3_RoamingNotAllowedParam_PDU */
    struct OMAP3_CallBarredParam *pdu_CallBarredParam;  
                                                /* OMAP3_CallBarredParam_PDU */
    struct OMAP3_CUG_RejectParam *pdu_CUG_RejectParam;  
                                                /* OMAP3_CUG_RejectParam_PDU */
    struct OMAP3_SS_IncompatibilityCause *pdu_SS_IncompatibilityCause;  
                                        /* OMAP3_SS_IncompatibilityCause_PDU */
    OMAP3_PW_RegistrationFailureCause *pdu_PW_RegistrationFailureCause;  
                                    /* OMAP3_PW_RegistrationFailureCause_PDU */
    struct OMAP3_SM_DeliveryFailureCause *pdu_SM_DeliveryFailureCause;  
                                        /* OMAP3_SM_DeliveryFailureCause_PDU */
    struct OMAP3_AbsentSubscriberSM_Param *pdu_AbsentSubscriberSM_Param;  
                                        /* OMAP3_AbsentSubscriberSM_Param_PDU */
    struct OMAP3_SystemFailureParam *pdu_SystemFailureParam;  
                                             /* OMAP3_SystemFailureParam_PDU */
    struct OMAP3_DataMissingParam *pdu_DataMissingParam;  
                                               /* OMAP3_DataMissingParam_PDU */
    struct OMAP3_UnexpectedDataParam *pdu_UnexpectedDataParam;  
                                            /* OMAP3_UnexpectedDataParam_PDU */
    struct OMAP3_FacilityNotSupParam *pdu_FacilityNotSupParam;  
                                            /* OMAP3_FacilityNotSupParam_PDU */
    struct OMAP3_OR_NotAllowedParam *pdu_OR_NotAllowedParam;  
                                             /* OMAP3_OR_NotAllowedParam_PDU */
    struct OMAP3_UnknownSubscriberParam *pdu_UnknownSubscriberParam;  
                                         /* OMAP3_UnknownSubscriberParam_PDU */
    struct OMAP3_NumberChangedParam *pdu_NumberChangedParam;  
                                             /* OMAP3_NumberChangedParam_PDU */
    struct OMAP3_UnidentifiedSubParam *pdu_UnidentifiedSubParam;  
                                           /* OMAP3_UnidentifiedSubParam_PDU */
    struct OMAP3_IllegalSubscriberParam *pdu_IllegalSubscriberParam;  
                                         /* OMAP3_IllegalSubscriberParam_PDU */
    struct OMAP3_IllegalEquipmentParam *pdu_IllegalEquipmentParam;  
                                          /* OMAP3_IllegalEquipmentParam_PDU */
    struct OMAP3_BearerServNotProvParam *pdu_BearerServNotProvParam;  
                                         /* OMAP3_BearerServNotProvParam_PDU */
    struct OMAP3_TeleservNotProvParam *pdu_TeleservNotProvParam;  
                                           /* OMAP3_TeleservNotProvParam_PDU */
    struct OMAP3_TracingBufferFullParam *pdu_TracingBufferFullParam;  
                                         /* OMAP3_TracingBufferFullParam_PDU */
    struct OMAP3_NoRoamingNbParam *pdu_NoRoamingNbParam;  
                                               /* OMAP3_NoRoamingNbParam_PDU */
    struct OMAP3_AbsentSubscriberParam *pdu_AbsentSubscriberParam;  
                                          /* OMAP3_AbsentSubscriberParam_PDU */
    struct OMAP3_BusySubscriberParam *pdu_BusySubscriberParam;  
                                            /* OMAP3_BusySubscriberParam_PDU */
    struct OMAP3_NoSubscriberReplyParam *pdu_NoSubscriberReplyParam;  
                                         /* OMAP3_NoSubscriberReplyParam_PDU */
    struct OMAP3_ForwardingViolationParam *pdu_ForwardingViolationParam;  
                                        /* OMAP3_ForwardingViolationParam_PDU */
    struct OMAP3_ForwardingFailedParam *pdu_ForwardingFailedParam;  
                                          /* OMAP3_ForwardingFailedParam_PDU */
    struct OMAP3_ATI_NotAllowedParam *pdu_ATI_NotAllowedParam;  
                                            /* OMAP3_ATI_NotAllowedParam_PDU */
    struct OMAP3_ATSI_NotAllowedParam *pdu_ATSI_NotAllowedParam;  
                                           /* OMAP3_ATSI_NotAllowedParam_PDU */
    struct OMAP3_ATM_NotAllowedParam *pdu_ATM_NotAllowedParam;  
                                            /* OMAP3_ATM_NotAllowedParam_PDU */
    struct OMAP3_IllegalSS_OperationParam *pdu_IllegalSS_OperationParam;  
                                        /* OMAP3_IllegalSS_OperationParam_PDU */
    struct OMAP3_SS_NotAvailableParam *pdu_SS_NotAvailableParam;  
                                           /* OMAP3_SS_NotAvailableParam_PDU */
    struct OMAP3_SS_SubscriptionViolationParam *pdu_SS_SubscriptionViolationParam;                                      /* OMAP3_SS_SubscriptionViolationParam_PDU */
    struct OMAP3_InformationNotAvailableParam *pdu_InformationNotAvailableParam;                                        /* OMAP3_InformationNotAvailableParam_PDU */
    struct OMAP3_SubBusyForMT_SMS_Param *pdu_SubBusyForMT_SMS_Param;  
                                         /* OMAP3_SubBusyForMT_SMS_Param_PDU */
    struct OMAP3_MessageWaitListFullParam *pdu_MessageWaitListFullParam;  
                                        /* OMAP3_MessageWaitListFullParam_PDU */
    struct OMAP3_ResourceLimitationParam *pdu_ResourceLimitationParam;  
                                        /* OMAP3_ResourceLimitationParam_PDU */
    struct OMAP3_NoGroupCallNbParam *pdu_NoGroupCallNbParam;  
                                             /* OMAP3_NoGroupCallNbParam_PDU */
    struct OMAP3_IncompatibleTerminalParam *pdu_IncompatibleTerminalParam;  
                                        /* OMAP3_IncompatibleTerminalParam_PDU */
    struct OMAP3_ShortTermDenialParam *pdu_ShortTermDenialParam;  
                                           /* OMAP3_ShortTermDenialParam_PDU */
    struct OMAP3_LongTermDenialParam *pdu_LongTermDenialParam;  
                                            /* OMAP3_LongTermDenialParam_PDU */
    struct OMAP3_UnauthorizedRequestingNetwork_Param *pdu_UnauthorizedRequestingNetwork_Param;                          /* OMAP3_UnauthorizedRequestingNetwork_Param_PDU */
    struct OMAP3_UnauthorizedLCSClient_Param *pdu_UnauthorizedLCSClient_Param;                                          /* OMAP3_UnauthorizedLCSClient_Param_PDU */
    struct OMAP3_PositionMethodFailure_Param *pdu_PositionMethodFailure_Param;                                          /* OMAP3_PositionMethodFailure_Param_PDU */
    struct OMAP3_UnknownOrUnreachableLCSClient_Param *pdu_UnknownOrUnreachableLCSClient_Param;                          /* OMAP3_UnknownOrUnreachableLCSClient_Param_PDU */
    struct OMAP3_MM_EventNotSupported_Param *pdu_MM_EventNotSupported_Param;  
                                        /* OMAP3_MM_EventNotSupported_Param_PDU */
    struct OMAP3_TargetCellOutsideGCA_Param *pdu_TargetCellOutsideGCA_Param;  
                                        /* OMAP3_TargetCellOutsideGCA_Param_PDU */
    struct OMAP3_SecureTransportErrorParam *pdu_SecureTransportErrorParam;  
                                        /* OMAP3_SecureTransportErrorParam_PDU */
    struct OMAP3_SendRoutingInfoArg *pdu_SendRoutingInfoArg;  
                                             /* OMAP3_SendRoutingInfoArg_PDU */
    struct OMAP3_SendRoutingInfoRes *pdu_SendRoutingInfoRes;  
                                             /* OMAP3_SendRoutingInfoRes_PDU */
    struct OMAP3_ProvideRoamingNumberArg *pdu_ProvideRoamingNumberArg;  
                                        /* OMAP3_ProvideRoamingNumberArg_PDU */
    struct OMAP3_ProvideRoamingNumberRes *pdu_ProvideRoamingNumberRes;  
                                        /* OMAP3_ProvideRoamingNumberRes_PDU */
    struct OMAP3_ResumeCallHandlingArg *pdu_ResumeCallHandlingArg;  
                                          /* OMAP3_ResumeCallHandlingArg_PDU */
    struct OMAP3_ResumeCallHandlingRes *pdu_ResumeCallHandlingRes;  
                                          /* OMAP3_ResumeCallHandlingRes_PDU */
    struct OMAP3_SetReportingStateArg *pdu_SetReportingStateArg;  
                                           /* OMAP3_SetReportingStateArg_PDU */
    struct OMAP3_SetReportingStateRes *pdu_SetReportingStateRes;  
                                           /* OMAP3_SetReportingStateRes_PDU */
    struct OMAP3_StatusReportArg *pdu_StatusReportArg;  
                                                /* OMAP3_StatusReportArg_PDU */
    struct OMAP3_StatusReportRes *pdu_StatusReportRes;  
                                                /* OMAP3_StatusReportRes_PDU */
    struct OMAP3_RemoteUserFreeArg *pdu_RemoteUserFreeArg;  
                                              /* OMAP3_RemoteUserFreeArg_PDU */
    struct OMAP3_RemoteUserFreeRes *pdu_RemoteUserFreeRes;  
                                              /* OMAP3_RemoteUserFreeRes_PDU */
    struct OMAP3_IST_AlertArg *pdu_IST_AlertArg;  /* OMAP3_IST_AlertArg_PDU */
    struct OMAP3_IST_AlertRes *pdu_IST_AlertRes;  /* OMAP3_IST_AlertRes_PDU */
    struct OMAP3_IST_CommandArg *pdu_IST_CommandArg;  
                                                 /* OMAP3_IST_CommandArg_PDU */
    struct OMAP3_IST_CommandRes *pdu_IST_CommandRes;  
                                                 /* OMAP3_IST_CommandRes_PDU */
    struct OMAP3_ReleaseResourcesArg *pdu_ReleaseResourcesArg;  
                                            /* OMAP3_ReleaseResourcesArg_PDU */
    struct OMAP3_ReleaseResourcesRes *pdu_ReleaseResourcesRes;  
                                            /* OMAP3_ReleaseResourcesRes_PDU */
    struct OMAP3_RegisterSS_Arg *pdu_RegisterSS_Arg;  
                                                 /* OMAP3_RegisterSS_Arg_PDU */
    struct OMAP3_SS_Info *pdu_SS_Info;  /* OMAP3_SS_Info_PDU */
    struct OMAP3_SS_ForBS_Code *pdu_SS_ForBS_Code;  
                                                  /* OMAP3_SS_ForBS_Code_PDU */
    struct OMAP3_InterrogateSS_Res *pdu_InterrogateSS_Res;  
                                              /* OMAP3_InterrogateSS_Res_PDU */
    struct OMAP3_USSD_Arg *pdu_USSD_Arg;  /* OMAP3_USSD_Arg_PDU */
    struct OMAP3_USSD_Res *pdu_USSD_Res;  /* OMAP3_USSD_Res_PDU */
    OMAP3_Password  *pdu_Password;  /* OMAP3_Password_PDU */
    OMAP3_GuidanceInfo *pdu_GuidanceInfo;  /* OMAP3_GuidanceInfo_PDU */
    struct OMAP3_SS_InfoList *pdu_SS_InfoList;  /* OMAP3_SS_InfoList_PDU */
    struct OMAP3_SS_InvocationNotificationArg *pdu_SS_InvocationNotificationArg;                                        /* OMAP3_SS_InvocationNotificationArg_PDU */
    struct OMAP3_SS_InvocationNotificationRes *pdu_SS_InvocationNotificationRes;                                        /* OMAP3_SS_InvocationNotificationRes_PDU */
    struct OMAP3_RegisterCC_EntryArg *pdu_RegisterCC_EntryArg;  
                                            /* OMAP3_RegisterCC_EntryArg_PDU */
    struct OMAP3_RegisterCC_EntryRes *pdu_RegisterCC_EntryRes;  
                                            /* OMAP3_RegisterCC_EntryRes_PDU */
    struct OMAP3_EraseCC_EntryArg *pdu_EraseCC_EntryArg;  
                                               /* OMAP3_EraseCC_EntryArg_PDU */
    struct OMAP3_EraseCC_EntryRes *pdu_EraseCC_EntryRes;  
                                               /* OMAP3_EraseCC_EntryRes_PDU */
    struct OMAP3_SS_Code *pdu_SS_Code;  /* OMAP3_SS_Code_PDU */
    struct OMAP3_RoutingInfoForSM_Arg *pdu_RoutingInfoForSM_Arg;  
                                           /* OMAP3_RoutingInfoForSM_Arg_PDU */
    struct OMAP3_RoutingInfoForSM_Res *pdu_RoutingInfoForSM_Res;  
                                           /* OMAP3_RoutingInfoForSM_Res_PDU */
    struct OMAP3_MO_ForwardSM_Arg *pdu_MO_ForwardSM_Arg;  
                                               /* OMAP3_MO_ForwardSM_Arg_PDU */
    struct OMAP3_MO_ForwardSM_Res *pdu_MO_ForwardSM_Res;  
                                               /* OMAP3_MO_ForwardSM_Res_PDU */
    struct OMAP3_MT_ForwardSM_Arg *pdu_MT_ForwardSM_Arg;  
                                               /* OMAP3_MT_ForwardSM_Arg_PDU */
    struct OMAP3_MT_ForwardSM_Res *pdu_MT_ForwardSM_Res;  
                                               /* OMAP3_MT_ForwardSM_Res_PDU */
    struct OMAP3_ReportSM_DeliveryStatusArg *pdu_ReportSM_DeliveryStatusArg;  
                                        /* OMAP3_ReportSM_DeliveryStatusArg_PDU */
    struct OMAP3_ReportSM_DeliveryStatusRes *pdu_ReportSM_DeliveryStatusRes;  
                                        /* OMAP3_ReportSM_DeliveryStatusRes_PDU */
    struct OMAP3_AlertServiceCentreArg *pdu_AlertServiceCentreArg;  
                                          /* OMAP3_AlertServiceCentreArg_PDU */
    struct OMAP3_InformServiceCentreArg *pdu_InformServiceCentreArg;  
                                         /* OMAP3_InformServiceCentreArg_PDU */
    struct OMAP3_ReadyForSM_Arg *pdu_ReadyForSM_Arg;  
                                                 /* OMAP3_ReadyForSM_Arg_PDU */
    struct OMAP3_ReadyForSM_Res *pdu_ReadyForSM_Res;  
                                                 /* OMAP3_ReadyForSM_Res_PDU */
    struct OMAP3_MT_ForwardSM_VGCS_Arg *pdu_MT_ForwardSM_VGCS_Arg;  
                                          /* OMAP3_MT_ForwardSM_VGCS_Arg_PDU */
    struct OMAP3_MT_ForwardSM_VGCS_Res *pdu_MT_ForwardSM_VGCS_Res;  
                                          /* OMAP3_MT_ForwardSM_VGCS_Res_PDU */
    struct OMAP3_ActivateTraceModeArg *pdu_ActivateTraceModeArg;  
                                           /* OMAP3_ActivateTraceModeArg_PDU */
    struct OMAP3_ISDN_AddressString *pdu_SendIMSIArg;  
                                                    /* OMAP3_SendIMSIArg_PDU */
    struct OMAP3_IMSI *pdu_SendIMSIRes;  /* OMAP3_SendIMSIRes_PDU */
    struct OMAP3_ActivateTraceModeRes *pdu_ActivateTraceModeRes;  
                                           /* OMAP3_ActivateTraceModeRes_PDU */
    struct OMAP3_DeactivateTraceModeArg *pdu_DeactivateTraceModeArg;  
                                         /* OMAP3_DeactivateTraceModeArg_PDU */
    struct OMAP3_DeactivateTraceModeRes *pdu_DeactivateTraceModeRes;  
                                         /* OMAP3_DeactivateTraceModeRes_PDU */
    struct OMAP3_UpdateLocationArg *pdu_UpdateLocationArg;  
                                              /* OMAP3_UpdateLocationArg_PDU */
    struct OMAP3_UpdateLocationRes *pdu_UpdateLocationRes;  
                                              /* OMAP3_UpdateLocationRes_PDU */
    struct OMAP3_CancelLocationArg *pdu_CancelLocationArg;  
                                              /* OMAP3_CancelLocationArg_PDU */
    struct OMAP3_CancelLocationRes *pdu_CancelLocationRes;  
                                              /* OMAP3_CancelLocationRes_PDU */
    struct OMAP3_PurgeMS_Arg *pdu_PurgeMS_Arg;  /* OMAP3_PurgeMS_Arg_PDU */
    struct OMAP3_PurgeMS_Res *pdu_PurgeMS_Res;  /* OMAP3_PurgeMS_Res_PDU */
    struct OMAP3_SendIdentificationArg *pdu_SendIdentificationArg;  
                                          /* OMAP3_SendIdentificationArg_PDU */
    struct OMAP3_SendIdentificationRes *pdu_SendIdentificationRes;  
                                          /* OMAP3_SendIdentificationRes_PDU */
    struct OMAP3_AuthenticationFailureReportArg *pdu_AuthenticationFailureReportArg;                                    /* OMAP3_AuthenticationFailureReportArg_PDU */
    struct OMAP3_AuthenticationFailureReportRes *pdu_AuthenticationFailureReportRes;                                    /* OMAP3_AuthenticationFailureReportRes_PDU */
    struct OMAP3_UpdateGprsLocationArg *pdu_UpdateGprsLocationArg;  
                                          /* OMAP3_UpdateGprsLocationArg_PDU */
    struct OMAP3_UpdateGprsLocationRes *pdu_UpdateGprsLocationRes;  
                                          /* OMAP3_UpdateGprsLocationRes_PDU */
    struct OMAP3_ForwardAccessSignalling_Arg *pdu_ForwardAccessSignalling_Arg;                                          /* OMAP3_ForwardAccessSignalling_Arg_PDU */
    struct OMAP3_PrepareHO_Arg *pdu_PrepareHO_Arg;  
                                                  /* OMAP3_PrepareHO_Arg_PDU */
    struct OMAP3_PrepareHO_Res *pdu_PrepareHO_Res;  
                                                  /* OMAP3_PrepareHO_Res_PDU */
    struct OMAP3_PrepareSubsequentHO_Arg *pdu_PrepareSubsequentHO_Arg;  
                                        /* OMAP3_PrepareSubsequentHO_Arg_PDU */
    struct OMAP3_PrepareSubsequentHO_Res *pdu_PrepareSubsequentHO_Res;  
                                        /* OMAP3_PrepareSubsequentHO_Res_PDU */
    struct OMAP3_ProcessAccessSignalling_Arg *pdu_ProcessAccessSignalling_Arg;                                          /* OMAP3_ProcessAccessSignalling_Arg_PDU */
    struct OMAP3_SendEndSignal_Arg *pdu_SendEndSignal_Arg;  
                                              /* OMAP3_SendEndSignal_Arg_PDU */
    struct OMAP3_SendEndSignal_Res *pdu_SendEndSignal_Res;  
                                              /* OMAP3_SendEndSignal_Res_PDU */
    struct OMAP3_SendAuthenticationInfoArg *pdu_SendAuthenticationInfoArg;  
                                        /* OMAP3_SendAuthenticationInfoArg_PDU */
    struct OMAP3_SendAuthenticationInfoRes *pdu_SendAuthenticationInfoRes;  
                                        /* OMAP3_SendAuthenticationInfoRes_PDU */
    struct OMAP3_CheckIMEI_Arg *pdu_CheckIMEI_Arg;  
                                                  /* OMAP3_CheckIMEI_Arg_PDU */
    struct OMAP3_CheckIMEI_Res *pdu_CheckIMEI_Res;  
                                                  /* OMAP3_CheckIMEI_Res_PDU */
    struct OMAP3_InsertSubscriberDataArg *pdu_InsertSubscriberDataArg;  
                                        /* OMAP3_InsertSubscriberDataArg_PDU */
    struct OMAP3_InsertSubscriberDataRes *pdu_InsertSubscriberDataRes;  
                                        /* OMAP3_InsertSubscriberDataRes_PDU */
    struct OMAP3_DeleteSubscriberDataArg *pdu_DeleteSubscriberDataArg;  
                                        /* OMAP3_DeleteSubscriberDataArg_PDU */
    struct OMAP3_DeleteSubscriberDataRes *pdu_DeleteSubscriberDataRes;  
                                        /* OMAP3_DeleteSubscriberDataRes_PDU */
    struct OMAP3_SendRoutingInfoForGprsArg *pdu_SendRoutingInfoForGprsArg;  
                                        /* OMAP3_SendRoutingInfoForGprsArg_PDU */
    struct OMAP3_SendRoutingInfoForGprsRes *pdu_SendRoutingInfoForGprsRes;  
                                        /* OMAP3_SendRoutingInfoForGprsRes_PDU */
    struct OMAP3_FailureReportArg *pdu_FailureReportArg;  
                                               /* OMAP3_FailureReportArg_PDU */
    struct OMAP3_FailureReportRes *pdu_FailureReportRes;  
                                               /* OMAP3_FailureReportRes_PDU */
    struct OMAP3_NoteMsPresentForGprsArg *pdu_NoteMsPresentForGprsArg;  
                                        /* OMAP3_NoteMsPresentForGprsArg_PDU */
    struct OMAP3_NoteMsPresentForGprsRes *pdu_NoteMsPresentForGprsRes;  
                                        /* OMAP3_NoteMsPresentForGprsRes_PDU */
    struct OMAP3_ResetArg *pdu_ResetArg;  /* OMAP3_ResetArg_PDU */
    struct OMAP3_RestoreDataArg *pdu_RestoreDataArg;  
                                                 /* OMAP3_RestoreDataArg_PDU */
    struct OMAP3_RestoreDataRes *pdu_RestoreDataRes;  
                                                 /* OMAP3_RestoreDataRes_PDU */
    struct OMAP3_ProvideSubscriberInfoArg *pdu_ProvideSubscriberInfoArg;  
                                        /* OMAP3_ProvideSubscriberInfoArg_PDU */
    struct OMAP3_ProvideSubscriberInfoRes *pdu_ProvideSubscriberInfoRes;  
                                        /* OMAP3_ProvideSubscriberInfoRes_PDU */
    struct OMAP3_AnyTimeInterrogationArg *pdu_AnyTimeInterrogationArg;  
                                        /* OMAP3_AnyTimeInterrogationArg_PDU */
    struct OMAP3_AnyTimeInterrogationRes *pdu_AnyTimeInterrogationRes;  
                                        /* OMAP3_AnyTimeInterrogationRes_PDU */
    struct OMAP3_AnyTimeSubscriptionInterrogationArg *pdu_AnyTimeSubscriptionInterrogationArg;                          /* OMAP3_AnyTimeSubscriptionInterrogationArg_PDU */
    struct OMAP3_AnyTimeSubscriptionInterrogationRes *pdu_AnyTimeSubscriptionInterrogationRes;                          /* OMAP3_AnyTimeSubscriptionInterrogationRes_PDU */
    struct OMAP3_AnyTimeModificationArg *pdu_AnyTimeModificationArg;  
                                         /* OMAP3_AnyTimeModificationArg_PDU */
    struct OMAP3_AnyTimeModificationRes *pdu_AnyTimeModificationRes;  
                                         /* OMAP3_AnyTimeModificationRes_PDU */
    struct OMAP3_NoteSubscriberDataModifiedArg *pdu_NoteSubscriberDataModifiedArg;                                      /* OMAP3_NoteSubscriberDataModifiedArg_PDU */
    struct OMAP3_NoteSubscriberDataModifiedRes *pdu_NoteSubscriberDataModifiedRes;                                      /* OMAP3_NoteSubscriberDataModifiedRes_PDU */
    struct OMAP3_NoteMM_EventArg *pdu_NoteMM_EventArg;  
                                                /* OMAP3_NoteMM_EventArg_PDU */
    struct OMAP3_NoteMM_EventRes *pdu_NoteMM_EventRes;  
                                                /* OMAP3_NoteMM_EventRes_PDU */
};

enum OMAP3_ExtensionSet_ExtensionType_PDUs {
    OMAP3_PDU_ExtensionSet_ExtensionType_UNKNOWN = 0,
    OMAP3_PDU_ExtensionSet_ExtensionType_MAX = INT_MAX
};

union OMAP3_ExtensionSet_ExtensionType_union {
    OMAP3_All_PDU_Types_union other;  /* for known extensions */
};

typedef struct OMAP3_ExtensionSet_ExtensionType {
    OMAP3_ExtensionSet_ExtensionType_PDUs pduNum;
    OssBuf          encoded;
    OMAP3_ExtensionSet_ExtensionType_union decoded;
} OMAP3_ExtensionSet_ExtensionType;

typedef struct OMAP3_PrivateExtension {
    unsigned char   bit_mask;
#       define      OMAP3_extType_present 0x80
    struct OMAP3__ObjectID_ *extId;
    OMAP3_ExtensionSet_ExtensionType extType;  /* optional; set in bit_mask
                                                * OMAP3_extType_present if
                                                * present */
} OMAP3_PrivateExtension;

typedef struct OMAP3_PrivateExtensionList {
    unsigned short  count;
    OMAP3_PrivateExtension value[10];
} OMAP3_PrivateExtensionList;

	// Unsupported private extensions shall be discarded if received.
typedef struct OMAP3_PCS_Extensions {
    char            placeholder;
} OMAP3_PCS_Extensions;

	// The length of the Object Identifier shall not exceed 16 octets and the
	// number of components of the Object Identifier shall not exceed 16
// data types
typedef struct OMAP3_ExtensionContainer {
    unsigned char   bit_mask;
#       define      OMAP3_ExtensionContainer_privateExtensionList_present 0x80
#       define      OMAP3_pcs_Extensions_present 0x40
    OMAP3_PrivateExtensionList privateExtensionList;  /* optional; set in
                                   * bit_mask
                     * OMAP3_ExtensionContainer_privateExtensionList_present if
                     * present */
    OMAP3_PCS_Extensions pcs_Extensions;  /* optional; set in bit_mask
                                           * OMAP3_pcs_Extensions_present if
                                           * present */
} OMAP3_ExtensionContainer;

typedef struct OMAP3_RoutingInfoForLCS_Arg {
    unsigned char   bit_mask;
#       define      OMAP3_RoutingInfoForLCS_Arg_extensionContainer_present 0x80
    OMAP3_ISDN_AddressString mlcNumber;
    OMAP3_SubscriberIdentity targetMS;
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                    * OMAP3_RoutingInfoForLCS_Arg_extensionContainer_present if
                    * present */
} OMAP3_RoutingInfoForLCS_Arg;

typedef struct OMAP3_LMSI {
    unsigned short  length;
    unsigned char   value[4];
} OMAP3_LMSI;

typedef struct OMAP3_Additional_Number {
    unsigned short  choice;
#       define      OMAP3_msc_Number_chosen 1
#       define      OMAP3_sgsn_Number_chosen 2
    union _union {
        OMAP3_ISDN_AddressString msc_Number;  /* to choose, set choice to
                                               * OMAP3_msc_Number_chosen */
        OMAP3_ISDN_AddressString sgsn_Number;  /* to choose, set choice to
                                                * OMAP3_sgsn_Number_chosen */
    } u;
} OMAP3_Additional_Number;

// exception handling:
// reception of values > 1 shall be mapped to ' istCommandSupported '
typedef struct OMAP3_SupportedLCS_CapabilitySets {
    unsigned short  length;  /* number of significant bits */
    unsigned char   value[2];
} OMAP3_SupportedLCS_CapabilitySets;
#define                     OMAP3_lcsCapabilitySet1 0x80
#define                     OMAP3_lcsCapabilitySet1_byte 0
#define                     OMAP3_lcsCapabilitySet2 0x40
#define                     OMAP3_lcsCapabilitySet2_byte 0
#define                     OMAP3_lcsCapabilitySet3 0x20
#define                     OMAP3_lcsCapabilitySet3_byte 0
#define                     OMAP3_lcsCapabilitySet4 0x10
#define                     OMAP3_lcsCapabilitySet4_byte 0

typedef struct OMAP3_LCSLocationInfo {
    unsigned char   bit_mask;
#       define      OMAP3_LCSLocationInfo_lmsi_present 0x80
#       define      OMAP3_LCSLocationInfo_extensionContainer_present 0x40
#       define      OMAP3_LCSLocationInfo_gprsNodeIndicator_present 0x20
#       define      OMAP3_LCSLocationInfo_additional_Number_present 0x10
#       define      OMAP3_LCSLocationInfo_supportedLCS_CapabilitySets_present 0x08
#       define      OMAP3_additional_LCS_CapabilitySets_present 0x04
    OMAP3_ISDN_AddressString networkNode_Number;
	// NetworkNode-number can be either msc-number or sgsn-number
    OMAP3_LMSI      lmsi;  /* optional; set in bit_mask
                            * OMAP3_LCSLocationInfo_lmsi_present if present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                          * OMAP3_LCSLocationInfo_extensionContainer_present if
                          * present */
    Nulltype        gprsNodeIndicator;  /* extension #1; optional; set in
                                   * bit_mask
                           * OMAP3_LCSLocationInfo_gprsNodeIndicator_present if
                           * present */
	// gprsNodeIndicator is set only if the SGSN number is sent as the Network Node Number
    OMAP3_Additional_Number additional_Number;  /* extension #2; optional; set
                                   * in bit_mask
                           * OMAP3_LCSLocationInfo_additional_Number_present if
                           * present */
    OMAP3_SupportedLCS_CapabilitySets supportedLCS_CapabilitySets;  
                                  /* extension #3; optional; set in bit_mask
                 * OMAP3_LCSLocationInfo_supportedLCS_CapabilitySets_present if
                 * present */
    OMAP3_SupportedLCS_CapabilitySets additional_LCS_CapabilitySets;  
                                  /* extension #4; optional; set in bit_mask
                                   * OMAP3_additional_LCS_CapabilitySets_present
                                   * if present */
} OMAP3_LCSLocationInfo;

typedef struct OMAP3_GSN_Address {
    unsigned short  length;
    unsigned char   value[17];
} OMAP3_GSN_Address;

typedef struct OMAP3_RoutingInfoForLCS_Res {
    unsigned char   bit_mask;
#       define      OMAP3_RoutingInfoForLCS_Res_extensionContainer_present 0x80
#       define      OMAP3_RoutingInfoForLCS_Res_v_gmlc_Address_present 0x40
#       define      OMAP3_RoutingInfoForLCS_Res_h_gmlc_Address_present 0x20
#       define      OMAP3_ppr_Address_present 0x10
#       define      OMAP3_additional_v_gmlc_Address_present 0x08
    OMAP3_SubscriberIdentity targetMS;
    OMAP3_LCSLocationInfo lcsLocationInfo;
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                    * OMAP3_RoutingInfoForLCS_Res_extensionContainer_present if
                    * present */
    OMAP3_GSN_Address v_gmlc_Address;  /* extension #1; optional; set in
                                   * bit_mask
                        * OMAP3_RoutingInfoForLCS_Res_v_gmlc_Address_present if
                        * present */
    OMAP3_GSN_Address h_gmlc_Address;  /* extension #2; optional; set in
                                   * bit_mask
                        * OMAP3_RoutingInfoForLCS_Res_h_gmlc_Address_present if
                        * present */
    OMAP3_GSN_Address ppr_Address;  /* extension #3; optional; set in bit_mask
                                     * OMAP3_ppr_Address_present if present */
    OMAP3_GSN_Address additional_v_gmlc_Address;  /* extension #4; optional; set
                                   * in bit_mask
                                   * OMAP3_additional_v_gmlc_Address_present if
                                   * present */
} OMAP3_RoutingInfoForLCS_Res;

typedef enum OMAP3_LocationEstimateType {
    OMAP3_currentLocation = 0,
    OMAP3_currentOrLastKnownLocation = 1,
    OMAP3_initialLocation = 2,
    OMAP3_activateDeferredLocation = 3,
    OMAP3_cancelDeferredLocation = 4
} OMAP3_LocationEstimateType;

//	exception handling:
//	a ProvideSubscriberLocation-Arg containing an unrecognized LocationEstimateType
//	shall be rejected by the receiver with a return error cause of unexpected data value
typedef struct OMAP3_DeferredLocationEventType {
    unsigned short  length;  /* number of significant bits */
    unsigned char   *value;
} OMAP3_DeferredLocationEventType;
#define                     OMAP3_msAvailable 0x80
#define                     OMAP3_msAvailable_byte 0
#define                     OMAP3_enteringIntoArea 0x40
#define                     OMAP3_enteringIntoArea_byte 0
#define                     OMAP3_leavingFromArea 0x20
#define                     OMAP3_leavingFromArea_byte 0
#define                     OMAP3_beingInsideArea 0x10
#define                     OMAP3_beingInsideArea_byte 0

	// one of imsi or msisdn is mandatory
	// If a location estimate type indicates activate deferred location or cancel deferred 
	// location, a lcs-Reference number shall be included.
typedef struct OMAP3_LocationType {
    unsigned char   bit_mask;
#       define      OMAP3_deferredLocationEventType_present 0x80
    OMAP3_LocationEstimateType locationEstimateType;
    OMAP3_DeferredLocationEventType deferredLocationEventType;  /* extension #1;
                                   * optional; set in bit_mask
                                   * OMAP3_deferredLocationEventType_present if
                                   * present */
} OMAP3_LocationType;

typedef enum OMAP3_LCSClientType {
    OMAP3_LCSClientType_emergencyServices = 0,
    OMAP3_valueAddedServices = 1,
    OMAP3_plmnOperatorServices = 2,
    OMAP3_lawfulInterceptServices = 3
} OMAP3_LCSClientType;

typedef struct OMAP3_LCSClientExternalID {
    unsigned char   bit_mask;
#       define      OMAP3_externalAddress_present 0x80
#       define      OMAP3_LCSClientExternalID_extensionContainer_present 0x40
    OMAP3_ISDN_AddressString externalAddress;  /* optional; set in bit_mask
                                                * OMAP3_externalAddress_present
                                                * if present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                      * OMAP3_LCSClientExternalID_extensionContainer_present if
                      * present */
} OMAP3_LCSClientExternalID;

// content of DiameterIdentity is defined in IETF RFC 3588 [139]
typedef struct OMAP3_AddressString {
    unsigned short  length;
    unsigned char   value[20];
} OMAP3_AddressString;

typedef enum OMAP3_LCSClientInternalID {
    OMAP3_broadcastService = 0,
    OMAP3_o_andM_HPLMN = 1,
    OMAP3_o_andM_VPLMN = 2,
    OMAP3_anonymousLocation = 3,
    OMAP3_targetMSsubscribedService = 4
} OMAP3_LCSClientInternalID;

typedef struct OMAP3_USSD_DataCodingScheme {
    unsigned short  length;
    unsigned char   value[1];
} OMAP3_USSD_DataCodingScheme;

// The USSD-DataCodingScheme shall indicate use of the default alphabet through the
// following encoding
//	bit	7 6 5 4 3 2 1 0
//		0 0 0 0 1 1 1 1
typedef struct OMAP3_NameString {
    unsigned short  length;
    unsigned char   value[63];
} OMAP3_NameString;

typedef enum OMAP3_LCS_FormatIndicator {
    OMAP3_logicalName = 0,
    OMAP3_e_mailAddress = 1,
    OMAP3_msisdn = 2,
    OMAP3_url = 3,
    OMAP3_sipUrl = 4
} OMAP3_LCS_FormatIndicator;

	//	exception handling:
	//	unrecognized values may be ignored if the LCS client uses the privacy override
	//	otherwise, an unrecognized value shall be treated as unexpected data by a receiver
	//	a return error shall then be returned if received in a MAP invoke 
typedef struct OMAP3_LCSClientName {
    unsigned char   bit_mask;
#       define      OMAP3_LCSClientName_lcs_FormatIndicator_present 0x80
    OMAP3_USSD_DataCodingScheme dataCodingScheme;
    OMAP3_NameString nameString;
    OMAP3_LCS_FormatIndicator lcs_FormatIndicator;  /* extension #1; optional;
                                   * set in bit_mask
                           * OMAP3_LCSClientName_lcs_FormatIndicator_present if
                           * present */
} OMAP3_LCSClientName;

// exception handling:
// For GPRS-CamelTDPData sequences containing this parameter with any
// other value than the ones listed the receiver shall ignore the whole 
// GPRS-CamelTDPDatasequence.
typedef struct OMAP3_APN {
    unsigned short  length;
    unsigned char   value[63];
} OMAP3_APN;

typedef struct OMAP3_RequestorIDString {
    unsigned short  length;
    unsigned char   value[63];
} OMAP3_RequestorIDString;

typedef struct OMAP3_LCSRequestorID {
    unsigned char   bit_mask;
#       define      OMAP3_LCSRequestorID_lcs_FormatIndicator_present 0x80
    OMAP3_USSD_DataCodingScheme dataCodingScheme;
    OMAP3_RequestorIDString requestorIDString;
    OMAP3_LCS_FormatIndicator lcs_FormatIndicator;  /* extension #1; optional;
                                   * set in bit_mask
                          * OMAP3_LCSRequestorID_lcs_FormatIndicator_present if
                          * present */
} OMAP3_LCSRequestorID;

// beingInsideArea is always treated as oneTimeEvent regardless of the possible value
// of occurrenceInfo inside areaEventInfo.
// exception handling:
// a ProvideSubscriberLocation-Arg containing other values than listed above in 
// DeferredLocationEventType shall be rejected by the receiver with a return error cause of 
// unexpected data value.
typedef struct OMAP3_LCS_ClientID {
    unsigned char   bit_mask;
#       define      OMAP3_lcsClientExternalID_present 0x80
#       define      OMAP3_lcsClientDialedByMS_present 0x40
#       define      OMAP3_lcsClientInternalID_present 0x20
#       define      OMAP3_lcsClientName_present 0x10
#       define      OMAP3_lcsAPN_present 0x08
#       define      OMAP3_lcsRequestorID_present 0x04
    OMAP3_LCSClientType lcsClientType;
    OMAP3_LCSClientExternalID lcsClientExternalID;  /* optional; set in bit_mask
                                         * OMAP3_lcsClientExternalID_present if
                                         * present */
    OMAP3_AddressString lcsClientDialedByMS;  /* optional; set in bit_mask
                                         * OMAP3_lcsClientDialedByMS_present if
                                         * present */
    OMAP3_LCSClientInternalID lcsClientInternalID;  /* optional; set in bit_mask
                                         * OMAP3_lcsClientInternalID_present if
                                         * present */
    OMAP3_LCSClientName lcsClientName;  /* optional; set in bit_mask
                                         * OMAP3_lcsClientName_present if
                                         * present */
    OMAP3_APN       lcsAPN;  /* extension #1; optional; set in bit_mask
                              * OMAP3_lcsAPN_present if present */
    OMAP3_LCSRequestorID lcsRequestorID;  /* extension #2; optional; set in
                                   * bit_mask OMAP3_lcsRequestorID_present if
                                   * present */
} OMAP3_LCS_ClientID;

typedef struct OMAP3_IMEI {
    unsigned short  length;
    unsigned char   value[8];
} OMAP3_IMEI;

typedef struct OMAP3_LCS_Priority {
    unsigned short  length;
    unsigned char   value[1];
} OMAP3_LCS_Priority;

typedef struct OMAP3_Horizontal_Accuracy {
    unsigned short  length;
    unsigned char   value[1];
} OMAP3_Horizontal_Accuracy;

	// bit 8 = 0
	// bits 7-1 = 7 bit Uncertainty Code defined in 3GPP TS 23.032. The horizontal location 
	// error should be less than the error indicated by the uncertainty code with 67%
	// confidence.
typedef struct OMAP3_Vertical_Accuracy {
    unsigned short  length;
    unsigned char   value[1];
} OMAP3_Vertical_Accuracy;

//	note: an expandable SEQUENCE simplifies later addition of a numeric response time.
typedef enum OMAP3_ResponseTimeCategory {
    OMAP3_lowdelay = 0,
    OMAP3_delaytolerant = 1
} OMAP3_ResponseTimeCategory;

	// bit 8 = 0
	// bits 7-1 = 7 bit Vertical Uncertainty Code defined in 3GPP TS 23.032. 
	// The vertical location error should be less than the error indicated 
	// by the uncertainty code with 67% confidence.
typedef struct OMAP3_ResponseTime {
    OMAP3_ResponseTimeCategory responseTimeCategory;
} OMAP3_ResponseTime;

	// 0 = highest priority
	// 1 = normal priority
	// all other values treated as 1 
typedef struct OMAP3_LCS_QoS {
    unsigned char   bit_mask;
#       define      OMAP3_horizontal_accuracy_present 0x80
#       define      OMAP3_verticalCoordinateRequest_present 0x40
#       define      OMAP3_vertical_accuracy_present 0x20
#       define      OMAP3_responseTime_present 0x10
#       define      OMAP3_LCS_QoS_extensionContainer_present 0x08
#       define      OMAP3_velocityRequest_present 0x04
    OMAP3_Horizontal_Accuracy horizontal_accuracy;  /* optional; set in bit_mask
                                         * OMAP3_horizontal_accuracy_present if
                                         * present */
    Nulltype        verticalCoordinateRequest;  /* optional; set in bit_mask
                                   * OMAP3_verticalCoordinateRequest_present if
                                   * present */
    OMAP3_Vertical_Accuracy vertical_accuracy;  /* optional; set in bit_mask
                                           * OMAP3_vertical_accuracy_present if
                                           * present */
    OMAP3_ResponseTime responseTime;  /* optional; set in bit_mask
                                       * OMAP3_responseTime_present if
                                       * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                                  * OMAP3_LCS_QoS_extensionContainer_present if
                                  * present */
    Nulltype        velocityRequest;  /* extension #1; optional; set in bit_mask
                                       * OMAP3_velocityRequest_present if
                                       * present */
} OMAP3_LCS_QoS;

//	exception handling:
//	an unrecognized value shall be treated the same as value 1 (delaytolerant)
typedef struct OMAP3_SupportedGADShapes {
    unsigned short  length;  /* number of significant bits */
    unsigned char   *value;
} OMAP3_SupportedGADShapes;
#define                     OMAP3_ellipsoidPoint 0x80
#define                     OMAP3_ellipsoidPoint_byte 0
#define                     OMAP3_ellipsoidPointWithUncertaintyCircle 0x40
#define                     OMAP3_ellipsoidPointWithUncertaintyCircle_byte 0
#define                     OMAP3_ellipsoidPointWithUncertaintyEllipse 0x20
#define                     OMAP3_ellipsoidPointWithUncertaintyEllipse_byte 0
#define                     OMAP3_polygon 0x10
#define                     OMAP3_polygon_byte 0
#define                     OMAP3_ellipsoidPointWithAltitude 0x08
#define                     OMAP3_ellipsoidPointWithAltitude_byte 0
#define                     OMAP3_ellipsoidPointWithAltitudeAndUncertaintyElipsoid 0x04
#define                     OMAP3_ellipsoidPointWithAltitudeAndUncertaintyElipsoid_byte 0
#define                     OMAP3_ellipsoidArc 0x02
#define                     OMAP3_ellipsoidArc_byte 0

// A node shall mark in the BIT STRING all Shapes defined in 3GPP TS 23.032 it supports.
// exception handling: bits 7 to 15 shall be ignored if received.
typedef struct OMAP3_LCS_ReferenceNumber {
    unsigned short  length;
    unsigned char   value[1];
} OMAP3_LCS_ReferenceNumber;

// for a CAMEL phase 3 PLMN operator client, the value targetMSsubscribedService shall be used
typedef unsigned short  OMAP3_LCSServiceTypeID;

typedef struct OMAP3_LCSCodewordString {
    unsigned short  length;
    unsigned char   value[20];
} OMAP3_LCSCodewordString;

typedef struct OMAP3_LCSCodeword {
    OMAP3_USSD_DataCodingScheme dataCodingScheme;
    OMAP3_LCSCodewordString lcsCodewordString;
} OMAP3_LCSCodeword;

typedef enum OMAP3_PrivacyCheckRelatedAction {
    OMAP3_allowedWithoutNotification = 0,
    OMAP3_allowedWithNotification = 1,
    OMAP3_allowedIfNoResponse = 2,
    OMAP3_restrictedIfNoResponse = 3,
    OMAP3_notAllowed = 4
} OMAP3_PrivacyCheckRelatedAction;

typedef struct OMAP3_LCS_PrivacyCheck {
    unsigned char   bit_mask;
#       define      OMAP3_callSessionRelated_present 0x80
    OMAP3_PrivacyCheckRelatedAction callSessionUnrelated;
    OMAP3_PrivacyCheckRelatedAction callSessionRelated;  /* optional; set in
                                   * bit_mask OMAP3_callSessionRelated_present
                                   * if present */
} OMAP3_LCS_PrivacyCheck;

typedef enum OMAP3_AreaType {
    OMAP3_countryCode = 0,
    OMAP3_plmnId = 1,
    OMAP3_locationAreaId = 2,
    OMAP3_routingAreaId = 3,
    OMAP3_cellGlobalId = 4,
    OMAP3_utranCellId = 5
} OMAP3_AreaType;

typedef struct OMAP3_AreaIdentification {
    unsigned short  length;
    unsigned char   value[7];
} OMAP3_AreaIdentification;

typedef struct OMAP3_Area {
    OMAP3_AreaType  areaType;
    OMAP3_AreaIdentification areaIdentification;
} OMAP3_Area;

typedef struct OMAP3_AreaList {
    unsigned short  count;
    OMAP3_Area      value[10];
} OMAP3_AreaList;

typedef struct OMAP3_AreaDefinition {
    OMAP3_AreaList  areaList;
} OMAP3_AreaDefinition;

	// The internal structure is defined as follows:
	// octet 1 bits 4321	Mobile Country Code 1st digit
	//         bits 8765	Mobile Country Code 2nd digit
	// octet 2 bits 4321	Mobile Country Code 3rd digit
	//         bits 8765	Mobile Network Code 3rd digit if 3 digit MNC included
	//			or filler (1111)
	// octet 3 bits 4321	Mobile Network Code 1st digit
	//         bits 8765	Mobile Network Code 2nd digit
	// octets 4 and 5	Location Area Code (LAC) for Local Area Id,
	//			Routing Area Id and Cell Global Id
	// octet 6	Routing Area Code (RAC) for Routing Area Id
	// octets 6 and 7	Cell Identity (CI) for Cell Global Id
	// octets 4 until 7	Utran Cell Identity (UC-Id) for Utran Cell Id
typedef enum OMAP3_OccurrenceInfo {
    OMAP3_oneTimeEvent = 0,
    OMAP3_multipleTimeEvent = 1
} OMAP3_OccurrenceInfo;

typedef unsigned short  OMAP3_IntervalTime;

//	exception handling:
//	a ProvideSubscriberLocation-Arg containing an unrecognized PrivacyCheckRelatedAction
//	shall be rejected by the receiver with a return error cause of unexpected data value
typedef struct OMAP3_AreaEventInfo {
    unsigned char   bit_mask;
#       define      OMAP3_occurrenceInfo_present 0x80
#       define      OMAP3_intervalTime_present 0x40
    OMAP3_AreaDefinition areaDefinition;
    OMAP3_OccurrenceInfo occurrenceInfo;  /* optional; set in bit_mask
                                           * OMAP3_occurrenceInfo_present if
                                           * present */
    OMAP3_IntervalTime intervalTime;  /* optional; set in bit_mask
                                       * OMAP3_intervalTime_present if
                                       * present */
} OMAP3_AreaEventInfo;

typedef struct OMAP3_ProvideSubscriberLocation_Arg {
    unsigned short  bit_mask;
#       define      OMAP3_lcs_ClientID_present 0x8000
#       define      OMAP3_privacyOverride_present 0x4000
#       define      OMAP3_ProvideSubscriberLocation_Arg_imsi_present 0x2000
#       define      OMAP3_ProvideSubscriberLocation_Arg_msisdn_present 0x1000
#       define      OMAP3_ProvideSubscriberLocation_Arg_lmsi_present 0x0800
#       define      OMAP3_ProvideSubscriberLocation_Arg_imei_present 0x0400
#       define      OMAP3_lcs_Priority_present 0x0200
#       define      OMAP3_lcs_QoS_present 0x0100
#       define      OMAP3_ProvideSubscriberLocation_Arg_extensionContainer_present 0x0080
#       define      OMAP3_supportedGADShapes_present 0x0040
#       define      OMAP3_ProvideSubscriberLocation_Arg_lcs_ReferenceNumber_present 0x0020
#       define      OMAP3_ProvideSubscriberLocation_Arg_lcsServiceTypeID_present 0x0010
#       define      OMAP3_lcsCodeword_present 0x0008
#       define      OMAP3_lcs_PrivacyCheck_present 0x0004
#       define      OMAP3_areaEventInfo_present 0x0002
#       define      OMAP3_ProvideSubscriberLocation_Arg_h_gmlc_Address_present 0x0001
    OMAP3_LocationType locationType;
    OMAP3_ISDN_AddressString mlc_Number;
    OMAP3_LCS_ClientID lcs_ClientID;  /* optional; set in bit_mask
                                       * OMAP3_lcs_ClientID_present if
                                       * present */
    Nulltype        privacyOverride;  /* optional; set in bit_mask
                                       * OMAP3_privacyOverride_present if
                                       * present */
    OMAP3_IMSI      imsi;  /* optional; set in bit_mask
                            * OMAP3_ProvideSubscriberLocation_Arg_imsi_present
                            * if present */
    OMAP3_ISDN_AddressString msisdn;  /* optional; set in bit_mask
                        * OMAP3_ProvideSubscriberLocation_Arg_msisdn_present if
                        * present */
    OMAP3_LMSI      lmsi;  /* optional; set in bit_mask
                            * OMAP3_ProvideSubscriberLocation_Arg_lmsi_present
                            * if present */
    OMAP3_IMEI      imei;  /* optional; set in bit_mask
                            * OMAP3_ProvideSubscriberLocation_Arg_imei_present
                            * if present */
    OMAP3_LCS_Priority lcs_Priority;  /* optional; set in bit_mask
                                       * OMAP3_lcs_Priority_present if
                                       * present */
    OMAP3_LCS_QoS   lcs_QoS;  /* optional; set in bit_mask OMAP3_lcs_QoS_present
                               * if present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
            * OMAP3_ProvideSubscriberLocation_Arg_extensionContainer_present if
            * present */
    OMAP3_SupportedGADShapes supportedGADShapes;  /* extension #1; optional; set
                                   * in bit_mask
                                   * OMAP3_supportedGADShapes_present if
                                   * present */
    OMAP3_LCS_ReferenceNumber lcs_ReferenceNumber;  /* extension #2; optional;
                                   * set in bit_mask
           * OMAP3_ProvideSubscriberLocation_Arg_lcs_ReferenceNumber_present if
           * present */
    OMAP3_LCSServiceTypeID lcsServiceTypeID;  /* extension #3; optional; set in
                                   * bit_mask
              * OMAP3_ProvideSubscriberLocation_Arg_lcsServiceTypeID_present if
              * present */
    OMAP3_LCSCodeword lcsCodeword;  /* extension #4; optional; set in bit_mask
                                     * OMAP3_lcsCodeword_present if present */
    OMAP3_LCS_PrivacyCheck lcs_PrivacyCheck;  /* extension #5; optional; set in
                                   * bit_mask OMAP3_lcs_PrivacyCheck_present if
                                   * present */
    OMAP3_AreaEventInfo areaEventInfo;  /* extension #6; optional; set in
                                   * bit_mask OMAP3_areaEventInfo_present if
                                   * present */
    OMAP3_GSN_Address h_gmlc_Address;  /* extension #7; optional; set in
                                   * bit_mask
                * OMAP3_ProvideSubscriberLocation_Arg_h_gmlc_Address_present if
                * present */
} OMAP3_ProvideSubscriberLocation_Arg;

typedef struct OMAP3_Ext_GeographicalInformation {
    unsigned short  length;
    unsigned char   value[20];
} OMAP3_Ext_GeographicalInformation;

	// OCTET 1:
	//
	// bits 8765: 0000 (unused)
	// bits 4321: Used to convey the "P bit","R bit","A bit" and "Q bit",
	//		    representing supplementary service state information
	//		    as defined in TS 3GPP TS 23.011 [22]

	// bit 4: "Q bit"

	// bit 3: "P bit"

	// bit 2: "R bit"

	// bit 1: "A bit"

	// OCTETS 2-5: reserved for future use. They shall be discarded if
	// received and not understood.

	// data types for geographic location
typedef unsigned short  OMAP3_AgeOfLocationInformation;
// the value represents the elapsed time in minutes since the last
// network contact of the mobile station (i.e. the actuality of the
// location information).
// value .0. indicates that the MS is currently in contact with the
//           network
// value .32767. indicates that the location information is at least
//               32767 minutes old

	// 
typedef struct OMAP3_Add_GeographicalInformation {
    unsigned short  length;
    unsigned char   value[91];
} OMAP3_Add_GeographicalInformation;

	// Refers to Velocity description defined in 3GPP TS 23.032.
	// This is composed of 4 or more octets with an internal structure according to
	// 3GPP TS 23.032
	// Octet 1: Type of velocity, only the following types in 3GPP TS 23.032 are allowed:
	//		(a) Horizontal Velocity
	//		(b) Horizontal with Vertical Velocity
	//		(c) Horizontal Velocity with Uncertainty
	//		(d) Horizontal with Vertical Velocity and Uncertainty
	// For types Horizontal with Vertical Velocity and Horizontal with Vertical Velocity
	// and Uncertainty, the direction of the Vertical Speed is also included in Octet 1
	// Any other value in octet 1 shall be treated as invalid
	// Octets 2 to 4 for case (a) Horizontal velocity:
	//		Bearing				1 octet
	//		Horizontal Speed				2 octets
	// Octets 2 to 5 for case (b) . Horizontal with Vertical Velocity:
	//		Bearing				1 octet
	//		Horizontal Speed				2 octets
	//		Vertical Speed				1 octet
	// Octets 2 to 5 for case (c) . Horizontal velocity with Uncertainty:
	//		Bearing				1 octet
	//		Horizontal Speed				2 octets
	//		Uncertainty Speed				1 octet
	// Octets 2 to 7 for case (d) . Horizontal with Vertical Velocity and Uncertainty:
	//		Bearing				1 octet
	//		Horizontal Speed				2 octets
	//		Vertical Speed				1 octet
	//		Horizontal Uncertainty Speed			1 octet
	//		Vertical Uncertainty Speed				1 octet
typedef struct OMAP3_PositioningDataInformation {
    unsigned short  length;
    unsigned char   value[10];
} OMAP3_PositioningDataInformation;

	// 
typedef struct OMAP3_UtranPositioningDataInfo {
    unsigned short  length;
    unsigned char   value[11];
} OMAP3_UtranPositioningDataInfo;

typedef struct OMAP3_CellGlobalIdOrServiceAreaIdFixedLength {
    unsigned short  length;
    unsigned char   value[7];
} OMAP3_CellGlobalIdOrServiceAreaIdFixedLength;

	// Refers to Cell Global Identification or Service Are Identification
	// defined in 3GPP TS 23.003.
	// The internal structure is defined as follows:
	// octet 1 bits 4321	Mobile Country Code 1st digit
	//         bits 8765	Mobile Country Code 2nd digit
	// octet 2 bits 4321	Mobile Country Code 3rd digit
	//         bits 8765	Mobile Network Code 3rd digit
	//			or filler (1111) for 2 digit MNCs
	// octet 3 bits 4321	Mobile Network Code 1st digit
	//         bits 8765	Mobile Network Code 2nd digit
	// octets 4 and 5	Location Area Code according to 3GPP TS 24.008
	// octets 6 and 7	Cell Identity (CI) value or 
	// 			Service Area Code (SAC) value 
	//			according to 3GPP TS 23.003
typedef struct OMAP3_LAIFixedLength {
    unsigned short  length;
    unsigned char   value[5];
} OMAP3_LAIFixedLength;

// data types for CAMEL
typedef struct OMAP3_CellGlobalIdOrServiceAreaIdOrLAI {
    unsigned short  choice;
#       define      OMAP3_cellGlobalIdOrServiceAreaIdFixedLength_chosen 1
#       define      OMAP3_laiFixedLength_chosen 2
    union _union {
        OMAP3_CellGlobalIdOrServiceAreaIdFixedLength cellGlobalIdOrServiceAreaIdFixedLength;                            /* to choose, set choice to
                       * OMAP3_cellGlobalIdOrServiceAreaIdFixedLength_chosen */
        OMAP3_LAIFixedLength laiFixedLength;  /* to choose, set choice to
                                               * OMAP3_laiFixedLength_chosen */
    } u;
} OMAP3_CellGlobalIdOrServiceAreaIdOrLAI;

//	if deferredmt-lrResponseIndicator is set, locationEstimate is ignored.

// the add-LocationEstimate parameter shall not be sent to a node that did not indicate the
// geographic shapes supported in the ProvideSubscriberLocation-Arg
// The locationEstimate and the add-locationEstimate parameters shall not be sent if
// the supportedGADShapes parameter has been received in ProvideSubscriberLocation-Arg
// and the shape encoded in locationEstimate or add-LocationEstimate is not marked
// as supported in supportedGADShapes. In such a case ProvideSubscriberLocation
// shall be rejected with error FacilityNotSupported with additional indication
// shapeOfLocationEstimateNotSupported.
// sai-Present indicates that the cellIdOrSai parameter contains a Service Area Identity.
typedef enum OMAP3_AccuracyFulfilmentIndicator {
    OMAP3_requestedAccuracyFulfilled = 0,
    OMAP3_requestedAccuracyNotFulfilled = 1
} OMAP3_AccuracyFulfilmentIndicator;

	// the maximum length allows for further shapes in 3GPP TS 23.032 to be included in later 
	// versions of 3GPP TS 29.002
typedef struct OMAP3_VelocityEstimate {
    unsigned short  length;
    unsigned char   value[7];
} OMAP3_VelocityEstimate;

	// minimum interval time between area reports in seconds
typedef struct OMAP3_ProvideSubscriberLocation_Res {
    unsigned short  bit_mask;
#       define      OMAP3_ProvideSubscriberLocation_Res_ageOfLocationEstimate_present 0x8000
#       define      OMAP3_ProvideSubscriberLocation_Res_extensionContainer_present 0x4000
#       define      OMAP3_ProvideSubscriberLocation_Res_add_LocationEstimate_present 0x2000
#       define      OMAP3_deferredmt_lrResponseIndicator_present 0x1000
#       define      OMAP3_ProvideSubscriberLocation_Res_geranPositioningData_present 0x0800
#       define      OMAP3_ProvideSubscriberLocation_Res_utranPositioningData_present 0x0400
#       define      OMAP3_ProvideSubscriberLocation_Res_cellIdOrSai_present 0x0200
#       define      OMAP3_ProvideSubscriberLocation_Res_sai_Present_present 0x0100
#       define      OMAP3_accuracyFulfilmentIndicator_present 0x0080
#       define      OMAP3_ProvideSubscriberLocation_Res_velocityEstimate_present 0x0040
    OMAP3_Ext_GeographicalInformation locationEstimate;
    OMAP3_AgeOfLocationInformation ageOfLocationEstimate;  /* optional; set in
                                   * bit_mask
         * OMAP3_ProvideSubscriberLocation_Res_ageOfLocationEstimate_present if
         * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
            * OMAP3_ProvideSubscriberLocation_Res_extensionContainer_present if
            * present */
    OMAP3_Add_GeographicalInformation add_LocationEstimate;  /* extension #1;
                                   * optional; set in bit_mask
          * OMAP3_ProvideSubscriberLocation_Res_add_LocationEstimate_present if
          * present */
    Nulltype        deferredmt_lrResponseIndicator;  /* extension #2; optional;
                                   * set in bit_mask
                              * OMAP3_deferredmt_lrResponseIndicator_present if
                              * present */
    OMAP3_PositioningDataInformation geranPositioningData;  /* extension #3;
                                   * optional; set in bit_mask
          * OMAP3_ProvideSubscriberLocation_Res_geranPositioningData_present if
          * present */
    OMAP3_UtranPositioningDataInfo utranPositioningData;  /* extension #4;
                                   * optional; set in bit_mask
          * OMAP3_ProvideSubscriberLocation_Res_utranPositioningData_present if
          * present */
    OMAP3_CellGlobalIdOrServiceAreaIdOrLAI cellIdOrSai;  /* extension #5;
                                   * optional; set in bit_mask
                   * OMAP3_ProvideSubscriberLocation_Res_cellIdOrSai_present if
                   * present */
    Nulltype        sai_Present;  /* extension #6; optional; set in bit_mask
                   * OMAP3_ProvideSubscriberLocation_Res_sai_Present_present if
                   * present */
    OMAP3_AccuracyFulfilmentIndicator accuracyFulfilmentIndicator;  
                                  /* extension #7; optional; set in bit_mask
                                   * OMAP3_accuracyFulfilmentIndicator_present
                                   * if present */
    OMAP3_VelocityEstimate velocityEstimate;  /* extension #8; optional; set in
                                   * bit_mask
              * OMAP3_ProvideSubscriberLocation_Res_velocityEstimate_present if
              * present */
} OMAP3_ProvideSubscriberLocation_Res;

	// lcsLocationInfo may be included only if a terminationCause is present 
	// indicating mt-lrRestart.
typedef enum OMAP3_LCS_Event {
    OMAP3_emergencyCallOrigination = 0,
    OMAP3_emergencyCallRelease = 1,
    OMAP3_mo_lr = 2,
    OMAP3_deferredmt_lrResponse = 3
} OMAP3_LCS_Event;

typedef struct OMAP3_SLR_Arg_PCS_Extensions {
    unsigned char   bit_mask;
#       define      OMAP3_na_ESRK_Request_present 0x80
    Nulltype        na_ESRK_Request;  /* extension #1; optional; set in bit_mask
                                       * OMAP3_na_ESRK_Request_present if
                                       * present */
} OMAP3_SLR_Arg_PCS_Extensions;

typedef struct OMAP3_SLR_ArgExtensionContainer {
    unsigned char   bit_mask;
#       define      OMAP3_SLR_ArgExtensionContainer_privateExtensionList_present 0x80
#       define      OMAP3_slr_Arg_PCS_Extensions_present 0x40
    OMAP3_PrivateExtensionList privateExtensionList;  /* optional; set in
                                   * bit_mask
              * OMAP3_SLR_ArgExtensionContainer_privateExtensionList_present if
              * present */
    OMAP3_SLR_Arg_PCS_Extensions slr_Arg_PCS_Extensions;  /* optional; set in
                                   * bit_mask
                                   * OMAP3_slr_Arg_PCS_Extensions_present if
                                   * present */
} OMAP3_SLR_ArgExtensionContainer;

	//	exception handling:
	//	a SubscriberLocationReport-Arg containing an unrecognized LCS-Event
	//	shall be rejected by a receiver with a return error cause of unexpected data value
typedef enum OMAP3_TerminationCause {
    OMAP3_TerminationCause_normal = 0,
    OMAP3_errorundefined = 1,
    OMAP3_internalTimeout = 2,
    OMAP3_TerminationCause_congestion = 3,
    OMAP3_mt_lrRestart = 4,
    OMAP3_privacyViolation = 5,
    OMAP3_shapeOfLocationEstimateNotSupported = 6
} OMAP3_TerminationCause;

	// one of msisdn or imsi is mandatory
	// a location estimate that is valid for the locationEstimate parameter should 
	// be transferred in this parameter in preference to the add-LocationEstimate.
	// the deferredmt-lrData parameter shall be included if and only if the lcs-Event
	// indicates a deferredmt-lrResponse.
	// if the lcs-Event indicates a deferredmt-lrResponse then the locationEstimate 
	// and the add-locationEstimate parameters shall not be sent if the 
	// supportedGADShapes parameter had been received in ProvideSubscriberLocation-Arg
	// and the shape encoded in locationEstimate or add-LocationEstimate was not marked
	// as supported in supportedGADShapes. In such a case terminationCause 
	// in deferredmt-lrData shall be present with value 
	// shapeOfLocationEstimateNotSupported. 
	// If a lcs event indicates deferred mt-lr response, the lcs-Reference number shall be 
	// included. 
	// sai-Present indicates that the cellIdOrSai parameter contains a Service Area Identity.
typedef struct OMAP3_Deferredmt_lrData {
    unsigned char   bit_mask;
#       define      OMAP3_terminationCause_present 0x80
#       define      OMAP3_lcsLocationInfo_present 0x40
    OMAP3_DeferredLocationEventType deferredLocationEventType;
    OMAP3_TerminationCause terminationCause;  /* optional; set in bit_mask
                                               * OMAP3_terminationCause_present
                                               * if present */
    OMAP3_LCSLocationInfo lcsLocationInfo;  /* optional; set in bit_mask
                                             * OMAP3_lcsLocationInfo_present if
                                             * present */
} OMAP3_Deferredmt_lrData;

	// the maximum length allows support for all the shapes currently defined in 3GPP TS 23.032
typedef struct OMAP3_SubscriberLocationReport_Arg {
    unsigned int    bit_mask;
#       define      OMAP3_SubscriberLocationReport_Arg_msisdn_present 0x80000000
#       define      OMAP3_SubscriberLocationReport_Arg_imsi_present 0x40000000
#       define      OMAP3_SubscriberLocationReport_Arg_imei_present 0x20000000
#       define      OMAP3_SubscriberLocationReport_Arg_na_ESRD_present 0x10000000
#       define      OMAP3_SubscriberLocationReport_Arg_na_ESRK_present 0x08000000
#       define      OMAP3_locationEstimate_present 0x04000000
#       define      OMAP3_SubscriberLocationReport_Arg_ageOfLocationEstimate_present 0x02000000
#       define      OMAP3_slr_ArgExtensionContainer_present 0x01000000
#       define      OMAP3_SubscriberLocationReport_Arg_add_LocationEstimate_present 0x00800000
#       define      OMAP3_deferredmt_lrData_present 0x00400000
#       define      OMAP3_SubscriberLocationReport_Arg_lcs_ReferenceNumber_present 0x00200000
#       define      OMAP3_SubscriberLocationReport_Arg_geranPositioningData_present 0x00100000
#       define      OMAP3_SubscriberLocationReport_Arg_utranPositioningData_present 0x00080000
#       define      OMAP3_SubscriberLocationReport_Arg_cellIdOrSai_present 0x00040000
#       define      OMAP3_SubscriberLocationReport_Arg_h_gmlc_Address_present 0x00020000
#       define      OMAP3_SubscriberLocationReport_Arg_lcsServiceTypeID_present 0x00010000
#       define      OMAP3_SubscriberLocationReport_Arg_sai_Present_present 0x00008000
#       define      OMAP3_pseudonymIndicator_present 0x00004000
#       define      OMAP3_SubscriberLocationReport_Arg_velocityEstimate_present 0x00002000
    OMAP3_LCS_Event lcs_Event;
    OMAP3_LCS_ClientID lcs_ClientID;
    OMAP3_LCSLocationInfo lcsLocationInfo;
    OMAP3_ISDN_AddressString msisdn;  /* optional; set in bit_mask
                         * OMAP3_SubscriberLocationReport_Arg_msisdn_present if
                         * present */
    OMAP3_IMSI      imsi;  /* optional; set in bit_mask
                            * OMAP3_SubscriberLocationReport_Arg_imsi_present if
                            * present */
    OMAP3_IMEI      imei;  /* optional; set in bit_mask
                            * OMAP3_SubscriberLocationReport_Arg_imei_present if
                            * present */
    OMAP3_ISDN_AddressString na_ESRD;  /* optional; set in bit_mask
                        * OMAP3_SubscriberLocationReport_Arg_na_ESRD_present if
                        * present */
    OMAP3_ISDN_AddressString na_ESRK;  /* optional; set in bit_mask
                        * OMAP3_SubscriberLocationReport_Arg_na_ESRK_present if
                        * present */
    OMAP3_Ext_GeographicalInformation locationEstimate;  /* optional; set in
                                   * bit_mask OMAP3_locationEstimate_present if
                                   * present */
    OMAP3_AgeOfLocationInformation ageOfLocationEstimate;  /* optional; set in
                                   * bit_mask
          * OMAP3_SubscriberLocationReport_Arg_ageOfLocationEstimate_present if
          * present */
    OMAP3_SLR_ArgExtensionContainer slr_ArgExtensionContainer;  /* optional; set
                                   * in bit_mask
                                   * OMAP3_slr_ArgExtensionContainer_present if
                                   * present */
    OMAP3_Add_GeographicalInformation add_LocationEstimate;  /* extension #1;
                                   * optional; set in bit_mask
           * OMAP3_SubscriberLocationReport_Arg_add_LocationEstimate_present if
           * present */
    OMAP3_Deferredmt_lrData deferredmt_lrData;  /* extension #2; optional; set
                                   * in bit_mask OMAP3_deferredmt_lrData_present
                                   * if present */
    OMAP3_LCS_ReferenceNumber lcs_ReferenceNumber;  /* extension #3; optional;
                                   * set in bit_mask
            * OMAP3_SubscriberLocationReport_Arg_lcs_ReferenceNumber_present if
            * present */
    OMAP3_PositioningDataInformation geranPositioningData;  /* extension #4;
                                   * optional; set in bit_mask
           * OMAP3_SubscriberLocationReport_Arg_geranPositioningData_present if
           * present */
    OMAP3_UtranPositioningDataInfo utranPositioningData;  /* extension #5;
                                   * optional; set in bit_mask
           * OMAP3_SubscriberLocationReport_Arg_utranPositioningData_present if
           * present */
    OMAP3_CellGlobalIdOrServiceAreaIdOrLAI cellIdOrSai;  /* extension #6;
                                   * optional; set in bit_mask
                    * OMAP3_SubscriberLocationReport_Arg_cellIdOrSai_present if
                    * present */
    OMAP3_GSN_Address h_gmlc_Address;  /* extension #7; optional; set in
                                   * bit_mask
                 * OMAP3_SubscriberLocationReport_Arg_h_gmlc_Address_present if
                 * present */
    OMAP3_LCSServiceTypeID lcsServiceTypeID;  /* extension #8; optional; set in
                                   * bit_mask
               * OMAP3_SubscriberLocationReport_Arg_lcsServiceTypeID_present if
               * present */
    Nulltype        sai_Present;  /* extension #9; optional; set in bit_mask
                    * OMAP3_SubscriberLocationReport_Arg_sai_Present_present if
                    * present */
    Nulltype        pseudonymIndicator;  /* extension #10; optional; set in
                                   * bit_mask OMAP3_pseudonymIndicator_present
                                   * if present */
    OMAP3_VelocityEstimate velocityEstimate;  /* extension #11; optional; set in
                                   * bit_mask
               * OMAP3_SubscriberLocationReport_Arg_velocityEstimate_present if
               * present */
} OMAP3_SubscriberLocationReport_Arg;

// mt-lrRestart shall be used to trigger the GMLC to restart the location procedure, 
// either because the sending node knows that the terminal has moved under coverage 
// of another MSC or SGSN (e.g. Send Identification received), or because the subscriber
// has been deregistered due to a Cancel Location received from HLR.
//
// exception handling
// an unrecognized value shall be treated the same as value 1 (errorundefined) 
typedef struct OMAP3_SubscriberLocationReport_Res {
    unsigned char   bit_mask;
#       define      OMAP3_SubscriberLocationReport_Res_extensionContainer_present 0x80
#       define      OMAP3_SubscriberLocationReport_Res_na_ESRK_present 0x40
#       define      OMAP3_SubscriberLocationReport_Res_na_ESRD_present 0x20
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
             * OMAP3_SubscriberLocationReport_Res_extensionContainer_present if
             * present */
    OMAP3_ISDN_AddressString na_ESRK;  /* extension #1; optional; set in
                                   * bit_mask
                        * OMAP3_SubscriberLocationReport_Res_na_ESRK_present if
                        * present */
    OMAP3_ISDN_AddressString na_ESRD;  /* extension #2; optional; set in
                                   * bit_mask
                        * OMAP3_SubscriberLocationReport_Res_na_ESRD_present if
                        * present */
} OMAP3_SubscriberLocationReport_Res;
// na-ESRK and na-ESRD are mutually exclusive
//
// exception handling
// receipt of both na-ESRK and na-ESRD shall be treated the same as a return error

	// In protection mode 0 (noProtection) the ProtectedPayload carries the transfer
		// syntax value of the component parameter identified by the
		// originalComponentIdentifier.
	// In protection mode 1 (integrityAuthenticity) the protectedPayload carries 
		//  the transfer syntax value of the component
		// parameter identified by the originalComponentIdentifier, followed by
		// the 32 bit integrity check value.
		// The integrity check value is the result of applying the hash algorithm
		// to the concatenation of the transfer syntax value of the SecurityHeader,
		// and the transfer syntax value of the component parameter. 
	// In protection mode 2 (confidentialityIntegrityAuthenticity) the protected
		// payload carries the encrypted transfer syntax
		// value of the component parameter identified by the
		// originalComponentIdentifier, followed by the 32 bit integrity check value.
		// The integrity check value is the result of applying the hash algorithm
		// to the concatenation of the transfer syntax value of the SecurityHeader,
		// and the encrypted transfer syntax value of the component parameter. 
	// See 33.200.
	// The length of the protectedPayload is adjusted according to the capabilities of
	// the lower protocol layers
typedef struct OMAP3_SecurityParametersIndex {
    unsigned short  length;
    unsigned char   value[4];
} OMAP3_SecurityParametersIndex;

typedef struct OMAP3_OperationCode {
    unsigned short  choice;
#       define      OMAP3_localValue_chosen 1
#       define      OMAP3_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP3_localValue_chosen */
        struct OMAP3__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP3_globalValue_chosen */
    } u;
} OMAP3_OperationCode;

typedef struct OMAP3_ErrorCode {
    unsigned short  choice;
#       define      OMAP3_localValue_chosen 1
#       define      OMAP3_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP3_localValue_chosen */
        struct OMAP3__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP3_globalValue_chosen */
    } u;
} OMAP3_ErrorCode;

	// the internal structure is defined as follows:
	// Octets 1 to 4 : TVP. The TVP is a 32 bit time stamp. Its value is binary coded
	//		          and indicates the number of intervals of 100 milliseconds
	//		          elapsed since 1st January 2002, 0:00:00 UTC
	// Octets 5 to 10: NE-Id. The NE-Id uniquely identifies the sending network entity
	//		          within the PLMN. It is the entity's E.164 number without CC and
	//		          NDC. It is TBCD-coded, padded with zeros.
	// Octets 11 to 14: PROP. This 32 bit value is used to make the
	//		          InitialisationVector unique within the same TVP period.
	//		          The content is not standardized.
typedef struct OMAP3_OriginalComponentIdentifier {
    unsigned short  choice;
#       define      OMAP3_operationCode_chosen 1
#       define      OMAP3_errorCode_chosen 2
#       define      OMAP3_userInfo_chosen 3
    union _union {
        OMAP3_OperationCode operationCode;  /* to choose, set choice to
                                             * OMAP3_operationCode_chosen */
        OMAP3_ErrorCode errorCode;  /* to choose, set choice to
                                     * OMAP3_errorCode_chosen */
        Nulltype        userInfo;  /* to choose, set choice to
                                    * OMAP3_userInfo_chosen */
    } u;
} OMAP3_OriginalComponentIdentifier;

typedef struct OMAP3_InitialisationVector {
    unsigned short  length;
    unsigned char   value[14];
} OMAP3_InitialisationVector;

	// The protectedPayload carries the result of applying the security function 
	// defined in 3GPP TS 33.200 to the encoding of the result of the securely
	// transported operation
typedef struct OMAP3_SecurityHeader {
    unsigned char   bit_mask;
#       define      OMAP3_initialisationVector_present 0x80
    OMAP3_SecurityParametersIndex securityParametersIndex;
    OMAP3_OriginalComponentIdentifier originalComponentIdentifier;
    OMAP3_InitialisationVector initialisationVector;  /* optional; set in
                                   * bit_mask OMAP3_initialisationVector_present
                                   * if present */
} OMAP3_SecurityHeader;

typedef struct OMAP3_ProtectedPayload {
    unsigned short  length;
    unsigned char   value[3438];
} OMAP3_ProtectedPayload;

typedef struct OMAP3_SecureTransportArg {
    unsigned char   bit_mask;
#       define      OMAP3_protectedPayload_present 0x80
    OMAP3_SecurityHeader securityHeader;
    OMAP3_ProtectedPayload protectedPayload;  /* optional; set in bit_mask
                                               * OMAP3_protectedPayload_present
                                               * if present */
} OMAP3_SecureTransportArg;

	// The protectedPayload carries the result of applying the security function 
	// defined in 3GPP TS 33.200 to the encoding of the argument of the securely
	// transported operation
typedef struct OMAP3_SecureTransportRes {
    unsigned char   bit_mask;
#       define      OMAP3_protectedPayload_present 0x80
    OMAP3_SecurityHeader securityHeader;
    OMAP3_ProtectedPayload protectedPayload;  /* optional; set in bit_mask
                                               * OMAP3_protectedPayload_present
                                               * if present */
} OMAP3_SecureTransportRes;

	// This type (Telephony Binary Coded Decimal String) is used to
	// represent several digits from 0 through 9, *, #, a, b, c, two
	// digits per octet, each digit encoded 0000 to 1001 (0 to 9),
	// 1010 (*), 1011 (#), 1100 (a), 1101 (b) or 1110 (c); 1111 used
	// as filler when there is an odd number of digits.

	// bits 8765 of octet n encoding digit 2n
	// bits 4321 of octet n encoding digit 2(n-1) +1
typedef struct OMAP3_DiameterIdentity {
    unsigned short  length;
    unsigned char   value[255];
} OMAP3_DiameterIdentity;

typedef struct OMAP3_FTN_AddressString {
    unsigned short  length;
    unsigned char   value[15];
} OMAP3_FTN_AddressString;

typedef struct OMAP3_ISDN_SubaddressString {
    unsigned short  length;
    unsigned char   value[21];
} OMAP3_ISDN_SubaddressString;

	// This NamedValue represents the theoretical maximum number of octets which is
	// available to carry a single instance of the SignalInfo data type,
	// without requiring segmentation to cope with the network layer service.
	// However, the actual maximum size available for an instance of the data
	// type may be lower, especially when other information elements
	// have to be included in the same component.
typedef enum OMAP3_ProtocolId {
    OMAP3_gsm_0408 = 1,
    OMAP3_gsm_0806 = 2,
    OMAP3_gsm_BSSMAP = 3,
	// Value 3 is reserved and must not be used
    OMAP3_ets_300102_1 = 4
} OMAP3_ProtocolId;

typedef struct OMAP3_SignalInfo {
    unsigned short  length;
    unsigned char   value[200];
} OMAP3_SignalInfo;

typedef struct OMAP3_ExternalSignalInfo {
    unsigned char   bit_mask;
#       define      OMAP3_ExternalSignalInfo_extensionContainer_present 0x80
    OMAP3_ProtocolId protocolId;
    OMAP3_SignalInfo signalInfo;
	// Information about the internal structure is given in
	// clause 7.6.9.
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                       * OMAP3_ExternalSignalInfo_extensionContainer_present if
                       * present */
	// extensionContainer must not be used in version 2
} OMAP3_ExternalSignalInfo;

typedef enum OMAP3_Ext_ProtocolId {
    OMAP3_ets_300356 = 1
} OMAP3_Ext_ProtocolId;

typedef struct OMAP3_Ext_ExternalSignalInfo {
    unsigned char   bit_mask;
#       define      OMAP3_Ext_ExternalSignalInfo_extensionContainer_present 0x80
    OMAP3_Ext_ProtocolId ext_ProtocolId;
    OMAP3_SignalInfo signalInfo;
	// Information about the internal structure is given in
	// clause 7.6.9.10
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                   * OMAP3_Ext_ExternalSignalInfo_extensionContainer_present if
                   * present */
} OMAP3_Ext_ExternalSignalInfo;

	// This Named Value represents the maximum number of octets which is available
	// to carry a single instance of the LongSignalInfo data type using
	// White Book SCCP with the maximum number of segments.
	// It takes account of the octets used by the lower layers of the protocol, and
	// other information elements which may be included in the same component.
typedef enum OMAP3_AccessNetworkProtocolId {
    OMAP3_ts3G_48006 = 1,
    OMAP3_ts3G_25413 = 2
} OMAP3_AccessNetworkProtocolId;

typedef struct OMAP3_LongSignalInfo {
    unsigned short  length;
    unsigned char   value[2560];
} OMAP3_LongSignalInfo;

// exception handling:
// For Ext-ExternalSignalInfo sequences containing this parameter with any
// other value than the ones listed the receiver shall ignore the whole 
// Ext-ExternalSignalInfo sequence.
typedef struct OMAP3_AccessNetworkSignalInfo {
    unsigned char   bit_mask;
#       define      OMAP3_AccessNetworkSignalInfo_extensionContainer_present 0x80
    OMAP3_AccessNetworkProtocolId accessNetworkProtocolId;
    OMAP3_LongSignalInfo signalInfo;
	// Information about the internal structure is given in clause 7.6.9.1
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                  * OMAP3_AccessNetworkSignalInfo_extensionContainer_present if
                  * present */
} OMAP3_AccessNetworkSignalInfo;

	// exception handling:
	// For AccessNetworkSignalInfo sequences containing this parameter with any
	// other value than the ones listed the receiver shall ignore the whole 
	// AccessNetworkSignalInfo sequence.
typedef struct OMAP3_AlertingPattern {
    unsigned short  length;
    unsigned char   value[1];
} OMAP3_AlertingPattern;

typedef struct OMAP3_IMSI_WithLMSI {
    OMAP3_IMSI      imsi;
    OMAP3_LMSI      lmsi;
	// a special value 00000000 indicates that the LMSI is not in use
} OMAP3_IMSI_WithLMSI;

	// digits of MCC, MNC, MSIN are concatenated in this order.
typedef struct OMAP3_Identity {
    unsigned short  choice;
#       define      OMAP3_Identity_imsi_chosen 1
#       define      OMAP3_imsi_WithLMSI_chosen 2
    union _union {
        OMAP3_IMSI      imsi;  /* to choose, set choice to
                                * OMAP3_Identity_imsi_chosen */
        OMAP3_IMSI_WithLMSI imsi_WithLMSI;  /* to choose, set choice to
                                             * OMAP3_imsi_WithLMSI_chosen */
    } u;
} OMAP3_Identity;

typedef struct OMAP3_ASCI_CallReference {
    unsigned short  length;
    unsigned char   value[8];
} OMAP3_ASCI_CallReference;

	// digits of VGCS/VBC-area,Group-ID are concatenated in this order.
typedef struct OMAP3_TMSI {
    unsigned short  length;
    unsigned char   value[4];
} OMAP3_TMSI;

typedef struct OMAP3_SubscriberId {
    unsigned short  choice;
#       define      OMAP3_SubscriberId_imsi_chosen 1
#       define      OMAP3_tmsi_chosen 2
    union _union {
        OMAP3_IMSI      imsi;  /* to choose, set choice to
                                * OMAP3_SubscriberId_imsi_chosen */
        OMAP3_TMSI      tmsi;  /* to choose, set choice to OMAP3_tmsi_chosen */
    } u;
} OMAP3_SubscriberId;

	//	Refers to International Mobile Station Equipment Identity
	//	and Software Version Number (SVN) defined in TS 3GPP TS 23.003 [17].
	//	If the SVN is not present the last octet shall contain the
	//	digit 0 and a filler.
	//	If present the SVN shall be included in the last octet.
typedef OMAP3_IMSI      OMAP3_HLR_Id;

	// leading digits of IMSI, i.e. (MCC, MNC, leading digits of
	// MSIN) forming HLR Id defined in TS 3GPP TS 23.003 [17].
typedef struct OMAP3_HLR_List {
    unsigned short  count;
    OMAP3_HLR_Id    value[50];
} OMAP3_HLR_List;

typedef struct OMAP3_GlobalCellId {
    unsigned short  length;
    unsigned char   value[7];
} OMAP3_GlobalCellId;

	// Refers to Cell Global Identification defined in TS 3GPP TS 23.003 [17].
	// The internal structure is defined as follows:
	// octet 1 bits 4321	Mobile Country Code 1st digit
	//         bits 8765	Mobile Country Code 2nd digit
	// octet 2 bits 4321	Mobile Country Code 3rd digit
	//         bits 8765	Mobile Network Code 3rd digit
	//			or filler (1111) for 2 digit MNCs
	// octet 3 bits 4321	Mobile Network Code 1st digit
	//         bits 8765	Mobile Network Code 2nd digit
	// octets 4 and 5	Location Area Code according to TS 3GPP TS 24.008 [35]
	// octets 6 and 7	Cell Identity (CI) according to TS 3GPP TS 24.008 [35]
typedef enum OMAP3_NetworkResource {
    OMAP3_plmn = 0,
    OMAP3_hlr = 1,
    OMAP3_NetworkResource_vlr = 2,
    OMAP3_pvlr = 3,
    OMAP3_controllingMSC = 4,
    OMAP3_vmsc = 5,
    OMAP3_eir = 6,
    OMAP3_rss = 7
} OMAP3_NetworkResource;

typedef enum OMAP3_AdditionalNetworkResource {
    OMAP3_AdditionalNetworkResource_sgsn = 0,
    OMAP3_AdditionalNetworkResource_ggsn = 1,
    OMAP3_gmlc = 2,
    OMAP3_gsmSCF = 3,
    OMAP3_nplr = 4,
    OMAP3_auc = 5
} OMAP3_AdditionalNetworkResource;

typedef struct OMAP3_NAEA_CIC {
    unsigned short  length;
    unsigned char   value[3];
} OMAP3_NAEA_CIC;

	// if unknown value is received in AdditionalNetworkResource
	// it shall be ignored.
typedef struct OMAP3_NAEA_PreferredCI {
    unsigned char   bit_mask;
#       define      OMAP3_NAEA_PreferredCI_extensionContainer_present 0x80
    OMAP3_NAEA_CIC  naea_PreferredCIC;
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                         * OMAP3_NAEA_PreferredCI_extensionContainer_present if
                         * present */
} OMAP3_NAEA_PreferredCI;

typedef struct OMAP3_NetworkNodeDiameterAddress {
    OMAP3_DiameterIdentity diameter_Name;
    OMAP3_DiameterIdentity diameter_Realm;
} OMAP3_NetworkNodeDiameterAddress;

typedef struct OMAP3_BearerServiceCode {
    unsigned short  length;
    unsigned char   value[1];
} OMAP3_BearerServiceCode;

typedef struct OMAP3_TeleserviceCode {
    unsigned short  length;
    unsigned char   value[1];
} OMAP3_TeleserviceCode;

	// Refers to Location Area Identification defined in TS 3GPP TS 23.003 [17].
	// The internal structure is defined as follows:
	// octet 1 bits 4321	Mobile Country Code 1st digit
	//         bits 8765	Mobile Country Code 2nd digit
	// octet 2 bits 4321	Mobile Country Code 3rd digit
	//         bits 8765	Mobile Network Code 3rd digit
	//			or filler (1111) for 2 digit MNCs
	// octet 3 bits 4321	Mobile Network Code 1st digit
	//         bits 8765	Mobile Network Code 2nd digit
	// octets 4 and 5	Location Area Code according to TS 3GPP TS 24.008 [35]

// data types for subscriber management
typedef struct OMAP3_BasicServiceCode {
    unsigned short  choice;
#       define      OMAP3_bearerService_chosen 1
#       define      OMAP3_teleservice_chosen 2
    union _union {
        OMAP3_BearerServiceCode bearerService;  /* to choose, set choice to
                                                * OMAP3_bearerService_chosen */
        OMAP3_TeleserviceCode teleservice;  /* to choose, set choice to
                                             * OMAP3_teleservice_chosen */
    } u;
} OMAP3_BasicServiceCode;

	// This type is used to represent the code identifying a single
	// bearer service, a group of bearer services, or all bearer
	// services. The services are defined in TS 3GPP TS 22.002 [3].
	// The internal structure is defined as follows:
	//
	// plmn-specific bearer services:
	// bits 87654321: defined by the HPLMN operator

	// rest of bearer services:
	// bit 8: 0 (unused)
	// bits 7654321: group (bits 7654), and rate, if applicable
	// (bits 321)
typedef struct OMAP3_Ext_BearerServiceCode {
    unsigned short  length;
    unsigned char   value[5];
} OMAP3_Ext_BearerServiceCode;

	// This type is used to represent the code identifying a single
	// teleservice, a group of teleservices, or all teleservices. The
	// services are defined in TS GSM 22.003 [4].
	// The internal structure is defined as follows:

	// bits 87654321: group (bits 8765) and specific service
	// (bits 4321)
typedef struct OMAP3_Ext_TeleserviceCode {
    unsigned short  length;
    unsigned char   value[5];
} OMAP3_Ext_TeleserviceCode;

typedef struct OMAP3_Ext_BasicServiceCode {
    unsigned short  choice;
#       define      OMAP3_Ext_BasicServiceCode_ext_BearerService_chosen 1
#       define      OMAP3_Ext_BasicServiceCode_ext_Teleservice_chosen 2
    union _union {
        OMAP3_Ext_BearerServiceCode ext_BearerService;  /* to choose, set choice
                                   * to
                       * OMAP3_Ext_BasicServiceCode_ext_BearerService_chosen */
        OMAP3_Ext_TeleserviceCode ext_Teleservice;  /* to choose, set choice to
                         * OMAP3_Ext_BasicServiceCode_ext_Teleservice_chosen */
    } u;
} OMAP3_Ext_BasicServiceCode;

typedef unsigned short  OMAP3_EMLPP_Priority;

typedef struct OMAP3_EMLPP_Info {
    unsigned char   bit_mask;
#       define      OMAP3_EMLPP_Info_extensionContainer_present 0x80
    OMAP3_EMLPP_Priority maximumentitledPriority;
    OMAP3_EMLPP_Priority defaultPriority;
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                               * OMAP3_EMLPP_Info_extensionContainer_present if
                               * present */
} OMAP3_EMLPP_Info;

typedef struct OMAP3_SS_Code {
    unsigned short  length;
    unsigned char   value[1];
} OMAP3_SS_Code;

typedef struct OMAP3_Ext_SS_Status {
    unsigned short  length;
    unsigned char   value[5];
} OMAP3_Ext_SS_Status;

typedef unsigned short  OMAP3_MaxMC_Bearers;

typedef unsigned short  OMAP3_MC_Bearers;

typedef struct OMAP3_MC_SS_Info {
    unsigned char   bit_mask;
#       define      OMAP3_MC_SS_Info_extensionContainer_present 0x80
    OMAP3_SS_Code   ss_Code;
    OMAP3_Ext_SS_Status ss_Status;
    OMAP3_MaxMC_Bearers nbrSB;
    OMAP3_MC_Bearers nbrUser;
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                               * OMAP3_MC_SS_Info_extensionContainer_present if
                               * present */
} OMAP3_MC_SS_Info;

typedef struct OMAP3_CODEC_Info {
    unsigned short  length;
    unsigned char   value[10];
} OMAP3_CODEC_Info;

	// Refers to channel type
	// coded according to 3GPP TS 48.008 [49] and including Element identifier and Length	
typedef struct OMAP3_CipheringAlgorithm {
    unsigned short  length;
    unsigned char   value[1];
} OMAP3_CipheringAlgorithm;

typedef unsigned short  OMAP3_GroupKeyNumber;

typedef struct OMAP3_Kc {
    unsigned short  length;
    unsigned char   value[8];
} OMAP3_Kc;

typedef struct OMAP3_VSTK {
    unsigned short  length;
    unsigned char   value[16];
} OMAP3_VSTK;

typedef struct OMAP3_VSTK_RAND {
    unsigned short  length;
    unsigned char   value[5];
} OMAP3_VSTK_RAND;

typedef struct OMAP3_PrepareGroupCallArg {
    unsigned char   bit_mask;
#       define      OMAP3_groupKeyNumber_Vk_Id_present 0x80
#       define      OMAP3_groupKey_present 0x40
#       define      OMAP3_priority_present 0x20
#       define      OMAP3_uplinkFree_present 0x10
#       define      OMAP3_PrepareGroupCallArg_extensionContainer_present 0x08
#       define      OMAP3_vstk_present 0x04
#       define      OMAP3_vstk_rand_present 0x02
    OMAP3_Ext_TeleserviceCode teleservice;
    OMAP3_ASCI_CallReference asciCallReference;
    OMAP3_CODEC_Info codec_Info;
    OMAP3_CipheringAlgorithm cipheringAlgorithm;
    OMAP3_GroupKeyNumber groupKeyNumber_Vk_Id;  /* optional; set in bit_mask
                                        * OMAP3_groupKeyNumber_Vk_Id_present if
                                        * present */
    OMAP3_Kc        groupKey;  /* optional; set in bit_mask
                                * OMAP3_groupKey_present if present */
	// this parameter shall not be sent and shall be discarded if received
    OMAP3_EMLPP_Priority priority;  /* optional; set in bit_mask
                                     * OMAP3_priority_present if present */
    Nulltype        uplinkFree;  /* optional; set in bit_mask
                                  * OMAP3_uplinkFree_present if present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                      * OMAP3_PrepareGroupCallArg_extensionContainer_present if
                      * present */
    OMAP3_VSTK      vstk;  /* extension #1; optional; set in bit_mask
                            * OMAP3_vstk_present if present */
    OMAP3_VSTK_RAND vstk_rand;  /* extension #2; optional; set in bit_mask
                                 * OMAP3_vstk_rand_present if present */
} OMAP3_PrepareGroupCallArg;

	// The 36 bit value is carried in bit 7 of octet 1 to bit 4 of octet 5
	// bits 3, 2, 1, and 0 of octet 5 are padded with zeros.
typedef struct OMAP3_PrepareGroupCallRes {
    unsigned char   bit_mask;
#       define      OMAP3_PrepareGroupCallRes_extensionContainer_present 0x80
    OMAP3_ISDN_AddressString groupCallNumber;
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                      * OMAP3_PrepareGroupCallRes_extensionContainer_present if
                      * present */
} OMAP3_PrepareGroupCallRes;

typedef enum OMAP3_TalkerPriority {
    OMAP3_TalkerPriority_normal = 0,
    OMAP3_privileged = 1,
    OMAP3_emergency = 2
} OMAP3_TalkerPriority;

typedef struct OMAP3_AdditionalInfo {
    unsigned short  length;  /* number of significant bits */
    unsigned char   value[17];
} OMAP3_AdditionalInfo;

typedef struct OMAP3_SendGroupCallEndSignalArg {
    unsigned char   bit_mask;
#       define      OMAP3_SendGroupCallEndSignalArg_imsi_present 0x80
#       define      OMAP3_SendGroupCallEndSignalArg_extensionContainer_present 0x40
#       define      OMAP3_SendGroupCallEndSignalArg_talkerPriority_present 0x20
#       define      OMAP3_SendGroupCallEndSignalArg_additionalInfo_present 0x10
    OMAP3_IMSI      imsi;  /* optional; set in bit_mask
                            * OMAP3_SendGroupCallEndSignalArg_imsi_present if
                            * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                * OMAP3_SendGroupCallEndSignalArg_extensionContainer_present if
                * present */
    OMAP3_TalkerPriority talkerPriority;  /* extension #1; optional; set in
                                   * bit_mask
                    * OMAP3_SendGroupCallEndSignalArg_talkerPriority_present if
                    * present */
    OMAP3_AdditionalInfo additionalInfo;  /* extension #2; optional; set in
                                   * bit_mask
                    * OMAP3_SendGroupCallEndSignalArg_additionalInfo_present if
                    * present */
} OMAP3_SendGroupCallEndSignalArg;

typedef struct OMAP3_SendGroupCallEndSignalRes {
    unsigned char   bit_mask;
#       define      OMAP3_SendGroupCallEndSignalRes_extensionContainer_present 0x80
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                * OMAP3_SendGroupCallEndSignalRes_extensionContainer_present if
                * present */
} OMAP3_SendGroupCallEndSignalRes;

	// Refers to 'permitted algorithms' in 'encryption information'
	// coded according to 3GPP TS 48.008 [49]:

	// Bits 8-1 
	// 8765 4321
	// 0000 0001	No encryption
	// 0000 0010	GSM A5/1
	// 0000 0100	GSM A5/2
	// 0000 1000	GSM A5/3
	// 0001 0000	GSM A5/4
	// 0010 0000	GSM A5/5
	// 0100 0000	GSM A5/6
	// 1000 0000	GSM A5/7
typedef struct OMAP3_StateAttributes {
    unsigned char   bit_mask;
#       define      OMAP3_downlinkAttached_present 0x80
#       define      OMAP3_uplinkAttached_present 0x40
#       define      OMAP3_dualCommunication_present 0x20
#       define      OMAP3_callOriginator_present 0x10
    Nulltype        downlinkAttached;  /* optional; set in bit_mask
                                        * OMAP3_downlinkAttached_present if
                                        * present */
    Nulltype        uplinkAttached;  /* optional; set in bit_mask
                                      * OMAP3_uplinkAttached_present if
                                      * present */
    Nulltype        dualCommunication;  /* optional; set in bit_mask
                                         * OMAP3_dualCommunication_present if
                                         * present */
    Nulltype        callOriginator;  /* optional; set in bit_mask
                                      * OMAP3_callOriginator_present if
                                      * present */
} OMAP3_StateAttributes;
	// Refers to 3GPP TS 44.068 for definitions of StateAttributes fields. 

typedef struct OMAP3_ForwardGroupCallSignallingArg {
    unsigned short  bit_mask;
#       define      OMAP3_ForwardGroupCallSignallingArg_imsi_present 0x8000
#       define      OMAP3_uplinkRequestAck_present 0x4000
#       define      OMAP3_ForwardGroupCallSignallingArg_uplinkReleaseIndication_present 0x2000
#       define      OMAP3_uplinkRejectCommand_present 0x1000
#       define      OMAP3_uplinkSeizedCommand_present 0x0800
#       define      OMAP3_uplinkReleaseCommand_present 0x0400
#       define      OMAP3_ForwardGroupCallSignallingArg_extensionContainer_present 0x0200
#       define      OMAP3_stateAttributes_present 0x0100
#       define      OMAP3_ForwardGroupCallSignallingArg_talkerPriority_present 0x0080
#       define      OMAP3_ForwardGroupCallSignallingArg_additionalInfo_present 0x0040
#       define      OMAP3_ForwardGroupCallSignallingArg_emergencyModeResetCommandFlag_present 0x0020
#       define      OMAP3_ForwardGroupCallSignallingArg_sm_RP_UI_present 0x0010
    OMAP3_IMSI      imsi;  /* optional; set in bit_mask
                            * OMAP3_ForwardGroupCallSignallingArg_imsi_present
                            * if present */
    Nulltype        uplinkRequestAck;  /* optional; set in bit_mask
                                        * OMAP3_uplinkRequestAck_present if
                                        * present */
    Nulltype        uplinkReleaseIndication;  /* optional; set in bit_mask
       * OMAP3_ForwardGroupCallSignallingArg_uplinkReleaseIndication_present if
       * present */
    Nulltype        uplinkRejectCommand;  /* optional; set in bit_mask
                                           * OMAP3_uplinkRejectCommand_present
                                           * if present */
    Nulltype        uplinkSeizedCommand;  /* optional; set in bit_mask
                                           * OMAP3_uplinkSeizedCommand_present
                                           * if present */
    Nulltype        uplinkReleaseCommand;  /* optional; set in bit_mask
                                            * OMAP3_uplinkReleaseCommand_present
                                            * if present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
            * OMAP3_ForwardGroupCallSignallingArg_extensionContainer_present if
            * present */
    OMAP3_StateAttributes stateAttributes;  /* extension #1; optional; set in
                                   * bit_mask OMAP3_stateAttributes_present if
                                   * present */
    OMAP3_TalkerPriority talkerPriority;  /* extension #2; optional; set in
                                   * bit_mask
                * OMAP3_ForwardGroupCallSignallingArg_talkerPriority_present if
                * present */
    OMAP3_AdditionalInfo additionalInfo;  /* extension #3; optional; set in
                                   * bit_mask
                * OMAP3_ForwardGroupCallSignallingArg_additionalInfo_present if
                * present */
    Nulltype        emergencyModeResetCommandFlag;  /* extension #4; optional;
                                   * set in bit_mask
 * OMAP3_ForwardGroupCallSignallingArg_emergencyModeResetCommandFlag_present if
 * present */
    OMAP3_SignalInfo sm_RP_UI;  /* extension #5; optional; set in bit_mask
                      * OMAP3_ForwardGroupCallSignallingArg_sm_RP_UI_present if
                      * present */
} OMAP3_ForwardGroupCallSignallingArg;

typedef struct OMAP3_ProcessGroupCallSignallingArg {
    unsigned char   bit_mask;
#       define      OMAP3_uplinkRequest_present 0x80
#       define      OMAP3_ProcessGroupCallSignallingArg_uplinkReleaseIndication_present 0x40
#       define      OMAP3_releaseGroupCall_present 0x20
#       define      OMAP3_ProcessGroupCallSignallingArg_extensionContainer_present 0x10
#       define      OMAP3_ProcessGroupCallSignallingArg_talkerPriority_present 0x08
#       define      OMAP3_ProcessGroupCallSignallingArg_additionalInfo_present 0x04
#       define      OMAP3_ProcessGroupCallSignallingArg_emergencyModeResetCommandFlag_present 0x02
    Nulltype        uplinkRequest;  /* optional; set in bit_mask
                                     * OMAP3_uplinkRequest_present if present */
    Nulltype        uplinkReleaseIndication;  /* optional; set in bit_mask
       * OMAP3_ProcessGroupCallSignallingArg_uplinkReleaseIndication_present if
       * present */
    Nulltype        releaseGroupCall;  /* optional; set in bit_mask
                                        * OMAP3_releaseGroupCall_present if
                                        * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
            * OMAP3_ProcessGroupCallSignallingArg_extensionContainer_present if
            * present */
    OMAP3_TalkerPriority talkerPriority;  /* extension #1; optional; set in
                                   * bit_mask
                * OMAP3_ProcessGroupCallSignallingArg_talkerPriority_present if
                * present */
    OMAP3_AdditionalInfo additionalInfo;  /* extension #2; optional; set in
                                   * bit_mask
                * OMAP3_ProcessGroupCallSignallingArg_additionalInfo_present if
                * present */
    Nulltype        emergencyModeResetCommandFlag;  /* extension #3; optional;
                                   * set in bit_mask
 * OMAP3_ProcessGroupCallSignallingArg_emergencyModeResetCommandFlag_present if
 * present */
} OMAP3_ProcessGroupCallSignallingArg;

// IOC for private MAP extensions
typedef struct OMAP3_EXTENSION {
    unsigned char   bit_mask;
#       define      OMAP3_ExtensionType_present 0x80
    unsigned short  ExtensionType;  /* optional; set in bit_mask
                                     * OMAP3_ExtensionType_present if present */
    struct OMAP3__ObjectID_ *extensionId;
    long            _oss_unique_index;
} OMAP3_EXTENSION;

	// generic errors
	// identification and numbering errors
	// subscription errors
	// handover errors
	// operation and maintenance errors
	// call handling errors
	// any time interrogation errors
	// any time information handling errors
	// supplementary service errors
	// short message service errors
	// Group Call errors
	// location service errors
	// Mobility Management errors
	// Secure transport errors
// generic errors
typedef struct OMAP3_Errors_SS_Status {
    unsigned short  length;
    unsigned char   value[1];
} OMAP3_Errors_SS_Status;

typedef enum OMAP3_RoamingNotAllowedCause {
    OMAP3_plmnRoamingNotAllowed = 0,
    OMAP3_RoamingNotAllowedCause_operatorDeterminedBarring = 3
} OMAP3_RoamingNotAllowedCause;

typedef struct OMAP3_RoamingNotAllowedParam {
    unsigned char   bit_mask;
#       define      OMAP3_RoamingNotAllowedParam_extensionContainer_present 0x80
    OMAP3_RoamingNotAllowedCause roamingNotAllowedCause;
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                   * OMAP3_RoamingNotAllowedParam_extensionContainer_present if
                   * present */
} OMAP3_RoamingNotAllowedParam;

typedef enum OMAP3_CallBarringCause {
    OMAP3_barringServiceActive = 0,
    OMAP3_operatorBarring = 1
} OMAP3_CallBarringCause;

typedef struct OMAP3_ExtensibleCallBarredParam {
    unsigned char   bit_mask;
#       define      OMAP3_callBarringCause_present 0x80
#       define      OMAP3_ExtensibleCallBarredParam_extensionContainer_present 0x40
#       define      OMAP3_unauthorisedMessageOriginator_present 0x20
    OMAP3_CallBarringCause callBarringCause;  /* optional; set in bit_mask
                                               * OMAP3_callBarringCause_present
                                               * if present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                * OMAP3_ExtensibleCallBarredParam_extensionContainer_present if
                * present */
    Nulltype        unauthorisedMessageOriginator;  /* extension #1; optional;
                                   * set in bit_mask
                                   * OMAP3_unauthorisedMessageOriginator_present
                                   * if present */
} OMAP3_ExtensibleCallBarredParam;

typedef struct OMAP3_CallBarredParam {
    unsigned short  choice;
#       define      OMAP3_callBarringCause_chosen 1
#       define      OMAP3_extensibleCallBarredParam_chosen 2
    union _union {
        OMAP3_CallBarringCause callBarringCause;  /* to choose, set choice to
                                             * OMAP3_callBarringCause_chosen */
	// call BarringCause must not be used in version 3 and higher
        OMAP3_ExtensibleCallBarredParam extensibleCallBarredParam;  /* to
                                   * choose, set choice to
                                   * OMAP3_extensibleCallBarredParam_chosen */
	// extensibleCallBarredParam must not be used in version <3
    } u;
} OMAP3_CallBarredParam;

typedef enum OMAP3_CUG_RejectCause {
    OMAP3_incomingCallsBarredWithinCUG = 0,
    OMAP3_subscriberNotMemberOfCUG = 1,
    OMAP3_requestedBasicServiceViolatesCUG_Constraints = 5,
    OMAP3_calledPartySS_InteractionViolation = 7
} OMAP3_CUG_RejectCause;

typedef struct OMAP3_CUG_RejectParam {
    unsigned char   bit_mask;
#       define      OMAP3_cug_RejectCause_present 0x80
#       define      OMAP3_CUG_RejectParam_extensionContainer_present 0x40
    OMAP3_CUG_RejectCause cug_RejectCause;  /* optional; set in bit_mask
                                             * OMAP3_cug_RejectCause_present if
                                             * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                          * OMAP3_CUG_RejectParam_extensionContainer_present if
                          * present */
} OMAP3_CUG_RejectParam;

typedef struct OMAP3_SS_DataTypes_SS_Status {
    unsigned short  length;
    unsigned char   value[1];
} OMAP3_SS_DataTypes_SS_Status;

typedef struct OMAP3_SS_IncompatibilityCause {
    unsigned char   bit_mask;
#       define      OMAP3_SS_IncompatibilityCause_ss_Code_present 0x80
#       define      OMAP3_SS_IncompatibilityCause_basicService_present 0x40
#       define      OMAP3_SS_IncompatibilityCause_ss_Status_present 0x20
    OMAP3_SS_Code   ss_Code;  /* optional; set in bit_mask
                               * OMAP3_SS_IncompatibilityCause_ss_Code_present
                               * if present */
    OMAP3_BasicServiceCode basicService;  /* optional; set in bit_mask
                        * OMAP3_SS_IncompatibilityCause_basicService_present if
                        * present */
    OMAP3_SS_DataTypes_SS_Status ss_Status;  /* optional; set in bit_mask
                           * OMAP3_SS_IncompatibilityCause_ss_Status_present if
                           * present */
} OMAP3_SS_IncompatibilityCause;

typedef enum OMAP3_SM_EnumeratedDeliveryFailureCause {
    OMAP3_SM_EnumeratedDeliveryFailureCause_memoryCapacityExceeded = 0,
    OMAP3_equipmentProtocolError = 1,
    OMAP3_equipmentNotSM_Equipped = 2,
    OMAP3_unknownServiceCentre = 3,
    OMAP3_sc_Congestion = 4,
    OMAP3_invalidSME_Address = 5,
    OMAP3_subscriberNotSC_Subscriber = 6
} OMAP3_SM_EnumeratedDeliveryFailureCause;

typedef struct OMAP3_SM_DeliveryFailureCause {
    unsigned char   bit_mask;
#       define      OMAP3_diagnosticInfo_present 0x80
#       define      OMAP3_SM_DeliveryFailureCause_extensionContainer_present 0x40
    OMAP3_SM_EnumeratedDeliveryFailureCause sm_EnumeratedDeliveryFailureCause;
    OMAP3_SignalInfo diagnosticInfo;  /* optional; set in bit_mask
                                       * OMAP3_diagnosticInfo_present if
                                       * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                  * OMAP3_SM_DeliveryFailureCause_extensionContainer_present if
                  * present */
} OMAP3_SM_DeliveryFailureCause;

	// if received, additionalAbsentSubscriberDiagnosticSM 
	// is for GPRS and absentSubscriberDiagnosticSM is 
	// for non-GPRS
typedef unsigned short  OMAP3_AbsentSubscriberDiagnosticSM;

typedef struct OMAP3_AbsentSubscriberSM_Param {
    unsigned char   bit_mask;
#       define      OMAP3_AbsentSubscriberSM_Param_absentSubscriberDiagnosticSM_present 0x80
#       define      OMAP3_AbsentSubscriberSM_Param_extensionContainer_present 0x40
#       define      OMAP3_AbsentSubscriberSM_Param_additionalAbsentSubscriberDiagnosticSM_present 0x20
    OMAP3_AbsentSubscriberDiagnosticSM absentSubscriberDiagnosticSM;  
                                  /* optional; set in bit_mask
       * OMAP3_AbsentSubscriberSM_Param_absentSubscriberDiagnosticSM_present if
       * present */
	// AbsentSubscriberDiagnosticSM can be either for non-GPRS 
	// or for GPRS
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                 * OMAP3_AbsentSubscriberSM_Param_extensionContainer_present if
                 * present */
    OMAP3_AbsentSubscriberDiagnosticSM additionalAbsentSubscriberDiagnosticSM;                                          /* extension #1; optional; set in
                                   * bit_mask
     * OMAP3_AbsentSubscriberSM_Param_additionalAbsentSubscriberDiagnosticSM_present if
     * present */
} OMAP3_AbsentSubscriberSM_Param;

typedef struct OMAP3_ExtensibleSystemFailureParam {
    unsigned char   bit_mask;
#       define      OMAP3_networkResource_present 0x80
#       define      OMAP3_ExtensibleSystemFailureParam_extensionContainer_present 0x40
#       define      OMAP3_additionalNetworkResource_present 0x20
    OMAP3_NetworkResource networkResource;  /* optional; set in bit_mask
                                             * OMAP3_networkResource_present if
                                             * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
             * OMAP3_ExtensibleSystemFailureParam_extensionContainer_present if
             * present */
    OMAP3_AdditionalNetworkResource additionalNetworkResource;  /* extension #1;
                                   * optional; set in bit_mask
                                   * OMAP3_additionalNetworkResource_present if
                                   * present */
} OMAP3_ExtensibleSystemFailureParam;

	// AbsentSubscriberDiagnosticSM values are defined in 3GPP TS 23.040
typedef struct OMAP3_SystemFailureParam {
    unsigned short  choice;
#       define      OMAP3_networkResource_chosen 1
#       define      OMAP3_extensibleSystemFailureParam_chosen 2
    union _union {
        OMAP3_NetworkResource networkResource;  /* to choose, set choice to
                                              * OMAP3_networkResource_chosen */
	// networkResource must not be used in version 3
        OMAP3_ExtensibleSystemFailureParam extensibleSystemFailureParam;  
                                        /* to choose, set choice to
                                 * OMAP3_extensibleSystemFailureParam_chosen */
	// extensibleSystemFailureParam must not be used in version <3
    } u;
} OMAP3_SystemFailureParam;

typedef struct OMAP3_DataMissingParam {
    unsigned char   bit_mask;
#       define      OMAP3_DataMissingParam_extensionContainer_present 0x80
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                         * OMAP3_DataMissingParam_extensionContainer_present if
                         * present */
} OMAP3_DataMissingParam;

typedef struct OMAP3_UnexpectedDataParam {
    unsigned char   bit_mask;
#       define      OMAP3_UnexpectedDataParam_extensionContainer_present 0x80
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                      * OMAP3_UnexpectedDataParam_extensionContainer_present if
                      * present */
} OMAP3_UnexpectedDataParam;

typedef struct OMAP3_FacilityNotSupParam {
    unsigned char   bit_mask;
#       define      OMAP3_FacilityNotSupParam_extensionContainer_present 0x80
#       define      OMAP3_shapeOfLocationEstimateNotSupported_present 0x40
#       define      OMAP3_neededLcsCapabilityNotSupportedInServingNode_present 0x20
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                      * OMAP3_FacilityNotSupParam_extensionContainer_present if
                      * present */
    Nulltype        shapeOfLocationEstimateNotSupported;  /* extension #1;
                                   * optional; set in bit_mask
                         * OMAP3_shapeOfLocationEstimateNotSupported_present if
                         * present */
    Nulltype        neededLcsCapabilityNotSupportedInServingNode;  /* extension
                                   * #2; optional; set in bit_mask
                * OMAP3_neededLcsCapabilityNotSupportedInServingNode_present if
                * present */
} OMAP3_FacilityNotSupParam;

typedef struct OMAP3_OR_NotAllowedParam {
    unsigned char   bit_mask;
#       define      OMAP3_OR_NotAllowedParam_extensionContainer_present 0x80
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                       * OMAP3_OR_NotAllowedParam_extensionContainer_present if
                       * present */
} OMAP3_OR_NotAllowedParam;

typedef enum OMAP3_UnknownSubscriberDiagnostic {
    OMAP3_imsiUnknown = 0,
    OMAP3_gprsSubscriptionUnknown = 1,
    OMAP3_npdbMismatch = 2
} OMAP3_UnknownSubscriberDiagnostic;

typedef struct OMAP3_UnknownSubscriberParam {
    unsigned char   bit_mask;
#       define      OMAP3_UnknownSubscriberParam_extensionContainer_present 0x80
#       define      OMAP3_unknownSubscriberDiagnostic_present 0x40
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                   * OMAP3_UnknownSubscriberParam_extensionContainer_present if
                   * present */
    OMAP3_UnknownSubscriberDiagnostic unknownSubscriberDiagnostic;  
                                  /* extension #1; optional; set in bit_mask
                                   * OMAP3_unknownSubscriberDiagnostic_present
                                   * if present */
} OMAP3_UnknownSubscriberParam;

	// if unknown values are received in 	
	// UnknownSubscriberDiagnostic they shall be discarded
typedef struct OMAP3_NumberChangedParam {
    unsigned char   bit_mask;
#       define      OMAP3_NumberChangedParam_extensionContainer_present 0x80
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                       * OMAP3_NumberChangedParam_extensionContainer_present if
                       * present */
} OMAP3_NumberChangedParam;

typedef struct OMAP3_UnidentifiedSubParam {
    unsigned char   bit_mask;
#       define      OMAP3_UnidentifiedSubParam_extensionContainer_present 0x80
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                     * OMAP3_UnidentifiedSubParam_extensionContainer_present if
                     * present */
} OMAP3_UnidentifiedSubParam;

typedef struct OMAP3_IllegalSubscriberParam {
    unsigned char   bit_mask;
#       define      OMAP3_IllegalSubscriberParam_extensionContainer_present 0x80
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                   * OMAP3_IllegalSubscriberParam_extensionContainer_present if
                   * present */
} OMAP3_IllegalSubscriberParam;

typedef struct OMAP3_IllegalEquipmentParam {
    unsigned char   bit_mask;
#       define      OMAP3_IllegalEquipmentParam_extensionContainer_present 0x80
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                    * OMAP3_IllegalEquipmentParam_extensionContainer_present if
                    * present */
} OMAP3_IllegalEquipmentParam;

typedef struct OMAP3_BearerServNotProvParam {
    unsigned char   bit_mask;
#       define      OMAP3_BearerServNotProvParam_extensionContainer_present 0x80
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                   * OMAP3_BearerServNotProvParam_extensionContainer_present if
                   * present */
} OMAP3_BearerServNotProvParam;

typedef struct OMAP3_TeleservNotProvParam {
    unsigned char   bit_mask;
#       define      OMAP3_TeleservNotProvParam_extensionContainer_present 0x80
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                     * OMAP3_TeleservNotProvParam_extensionContainer_present if
                     * present */
} OMAP3_TeleservNotProvParam;

typedef struct OMAP3_TracingBufferFullParam {
    unsigned char   bit_mask;
#       define      OMAP3_TracingBufferFullParam_extensionContainer_present 0x80
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                   * OMAP3_TracingBufferFullParam_extensionContainer_present if
                   * present */
} OMAP3_TracingBufferFullParam;

typedef struct OMAP3_NoRoamingNbParam {
    unsigned char   bit_mask;
#       define      OMAP3_NoRoamingNbParam_extensionContainer_present 0x80
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                         * OMAP3_NoRoamingNbParam_extensionContainer_present if
                         * present */
} OMAP3_NoRoamingNbParam;

typedef enum OMAP3_AbsentSubscriberReason {
    OMAP3_imsiDetach = 0,
    OMAP3_AbsentSubscriberReason_restrictedArea = 1,
    OMAP3_noPageResponse = 2,
    OMAP3_purgedMS = 3
} OMAP3_AbsentSubscriberReason;

typedef struct OMAP3_AbsentSubscriberParam {
    unsigned char   bit_mask;
#       define      OMAP3_AbsentSubscriberParam_extensionContainer_present 0x80
#       define      OMAP3_absentSubscriberReason_present 0x40
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                    * OMAP3_AbsentSubscriberParam_extensionContainer_present if
                    * present */
    OMAP3_AbsentSubscriberReason absentSubscriberReason;  /* extension #1;
                                   * optional; set in bit_mask
                                   * OMAP3_absentSubscriberReason_present if
                                   * present */
} OMAP3_AbsentSubscriberParam;

// exception handling: at reception of other values than the ones listed the 
// AbsentSubscriberReason shall be ignored. 
// The AbsentSubscriberReason: purgedMS is defined for the Super-Charger feature 
// (see TS 23.116). If this value is received in a Provide Roaming Number response
// it shall be mapped to the AbsentSubscriberReason: imsiDetach in the Send Routeing
// Information response
typedef struct OMAP3_BusySubscriberParam {
    unsigned char   bit_mask;
#       define      OMAP3_BusySubscriberParam_extensionContainer_present 0x80
#       define      OMAP3_BusySubscriberParam_ccbs_Possible_present 0x40
#       define      OMAP3_ccbs_Busy_present 0x20
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                      * OMAP3_BusySubscriberParam_extensionContainer_present if
                      * present */
    Nulltype        ccbs_Possible;  /* extension #1; optional; set in bit_mask
                           * OMAP3_BusySubscriberParam_ccbs_Possible_present if
                           * present */
    Nulltype        ccbs_Busy;  /* extension #2; optional; set in bit_mask
                                 * OMAP3_ccbs_Busy_present if present */
} OMAP3_BusySubscriberParam;

typedef struct OMAP3_NoSubscriberReplyParam {
    unsigned char   bit_mask;
#       define      OMAP3_NoSubscriberReplyParam_extensionContainer_present 0x80
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                   * OMAP3_NoSubscriberReplyParam_extensionContainer_present if
                   * present */
} OMAP3_NoSubscriberReplyParam;

typedef struct OMAP3_ForwardingViolationParam {
    unsigned char   bit_mask;
#       define      OMAP3_ForwardingViolationParam_extensionContainer_present 0x80
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                 * OMAP3_ForwardingViolationParam_extensionContainer_present if
                 * present */
} OMAP3_ForwardingViolationParam;

typedef struct OMAP3_ForwardingFailedParam {
    unsigned char   bit_mask;
#       define      OMAP3_ForwardingFailedParam_extensionContainer_present 0x80
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                    * OMAP3_ForwardingFailedParam_extensionContainer_present if
                    * present */
} OMAP3_ForwardingFailedParam;

typedef struct OMAP3_ATI_NotAllowedParam {
    unsigned char   bit_mask;
#       define      OMAP3_ATI_NotAllowedParam_extensionContainer_present 0x80
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                      * OMAP3_ATI_NotAllowedParam_extensionContainer_present if
                      * present */
} OMAP3_ATI_NotAllowedParam;

typedef struct OMAP3_ATSI_NotAllowedParam {
    unsigned char   bit_mask;
#       define      OMAP3_ATSI_NotAllowedParam_extensionContainer_present 0x80
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                     * OMAP3_ATSI_NotAllowedParam_extensionContainer_present if
                     * present */
} OMAP3_ATSI_NotAllowedParam;

typedef struct OMAP3_ATM_NotAllowedParam {
    unsigned char   bit_mask;
#       define      OMAP3_ATM_NotAllowedParam_extensionContainer_present 0x80
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                      * OMAP3_ATM_NotAllowedParam_extensionContainer_present if
                      * present */
} OMAP3_ATM_NotAllowedParam;

typedef struct OMAP3_IllegalSS_OperationParam {
    unsigned char   bit_mask;
#       define      OMAP3_IllegalSS_OperationParam_extensionContainer_present 0x80
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                 * OMAP3_IllegalSS_OperationParam_extensionContainer_present if
                 * present */
} OMAP3_IllegalSS_OperationParam;

typedef struct OMAP3_SS_NotAvailableParam {
    unsigned char   bit_mask;
#       define      OMAP3_SS_NotAvailableParam_extensionContainer_present 0x80
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                     * OMAP3_SS_NotAvailableParam_extensionContainer_present if
                     * present */
} OMAP3_SS_NotAvailableParam;

typedef struct OMAP3_SS_SubscriptionViolationParam {
    unsigned char   bit_mask;
#       define      OMAP3_SS_SubscriptionViolationParam_extensionContainer_present 0x80
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
            * OMAP3_SS_SubscriptionViolationParam_extensionContainer_present if
            * present */
} OMAP3_SS_SubscriptionViolationParam;

typedef struct OMAP3_InformationNotAvailableParam {
    unsigned char   bit_mask;
#       define      OMAP3_InformationNotAvailableParam_extensionContainer_present 0x80
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
             * OMAP3_InformationNotAvailableParam_extensionContainer_present if
             * present */
} OMAP3_InformationNotAvailableParam;

typedef struct OMAP3_SubBusyForMT_SMS_Param {
    unsigned char   bit_mask;
#       define      OMAP3_SubBusyForMT_SMS_Param_extensionContainer_present 0x80
#       define      OMAP3_gprsConnectionSuspended_present 0x40
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                   * OMAP3_SubBusyForMT_SMS_Param_extensionContainer_present if
                   * present */
    Nulltype        gprsConnectionSuspended;  /* extension #1; optional; set in
                                   * bit_mask
                                   * OMAP3_gprsConnectionSuspended_present if
                                   * present */
} OMAP3_SubBusyForMT_SMS_Param;

	// If GprsConnectionSuspended is not understood it shall 
	// be discarded
typedef struct OMAP3_MessageWaitListFullParam {
    unsigned char   bit_mask;
#       define      OMAP3_MessageWaitListFullParam_extensionContainer_present 0x80
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                 * OMAP3_MessageWaitListFullParam_extensionContainer_present if
                 * present */
} OMAP3_MessageWaitListFullParam;

typedef struct OMAP3_ResourceLimitationParam {
    unsigned char   bit_mask;
#       define      OMAP3_ResourceLimitationParam_extensionContainer_present 0x80
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                  * OMAP3_ResourceLimitationParam_extensionContainer_present if
                  * present */
} OMAP3_ResourceLimitationParam;

typedef struct OMAP3_NoGroupCallNbParam {
    unsigned char   bit_mask;
#       define      OMAP3_NoGroupCallNbParam_extensionContainer_present 0x80
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                       * OMAP3_NoGroupCallNbParam_extensionContainer_present if
                       * present */
} OMAP3_NoGroupCallNbParam;

typedef struct OMAP3_IncompatibleTerminalParam {
    unsigned char   bit_mask;
#       define      OMAP3_IncompatibleTerminalParam_extensionContainer_present 0x80
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                * OMAP3_IncompatibleTerminalParam_extensionContainer_present if
                * present */
} OMAP3_IncompatibleTerminalParam;

typedef struct OMAP3_ShortTermDenialParam {
    char            placeholder;
} OMAP3_ShortTermDenialParam;

typedef struct OMAP3_LongTermDenialParam {
    char            placeholder;
} OMAP3_LongTermDenialParam;

typedef struct OMAP3_UnauthorizedRequestingNetwork_Param {
    unsigned char   bit_mask;
#       define      OMAP3_UnauthorizedRequestingNetwork_Param_extensionContainer_present 0x80
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
      * OMAP3_UnauthorizedRequestingNetwork_Param_extensionContainer_present if
      * present */
} OMAP3_UnauthorizedRequestingNetwork_Param;

typedef enum OMAP3_UnauthorizedLCSClient_Diagnostic {
    OMAP3_noAdditionalInformation = 0,
    OMAP3_clientNotInMSPrivacyExceptionList = 1,
    OMAP3_callToClientNotSetup = 2,
    OMAP3_privacyOverrideNotApplicable = 3,
    OMAP3_disallowedByLocalRegulatoryRequirements = 4,
    OMAP3_unauthorizedPrivacyClass = 5,
    OMAP3_unauthorizedCallSessionUnrelatedExternalClient = 6,
    OMAP3_unauthorizedCallSessionRelatedExternalClient = 7
} OMAP3_UnauthorizedLCSClient_Diagnostic;

typedef struct OMAP3_UnauthorizedLCSClient_Param {
    unsigned char   bit_mask;
#       define      OMAP3_unauthorizedLCSClient_Diagnostic_present 0x80
#       define      OMAP3_UnauthorizedLCSClient_Param_extensionContainer_present 0x40
    OMAP3_UnauthorizedLCSClient_Diagnostic unauthorizedLCSClient_Diagnostic;  
                                        /* optional; set in bit_mask
                            * OMAP3_unauthorizedLCSClient_Diagnostic_present if
                            * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
              * OMAP3_UnauthorizedLCSClient_Param_extensionContainer_present if
              * present */
} OMAP3_UnauthorizedLCSClient_Param;

typedef enum OMAP3_PositionMethodFailure_Diagnostic {
    OMAP3_PositionMethodFailure_Diagnostic_congestion = 0,
    OMAP3_insufficientResources = 1,
    OMAP3_insufficientMeasurementData = 2,
    OMAP3_inconsistentMeasurementData = 3,
    OMAP3_locationProcedureNotCompleted = 4,
    OMAP3_locationProcedureNotSupportedByTargetMS = 5,
    OMAP3_qoSNotAttainable = 6,
    OMAP3_positionMethodNotAvailableInNetwork = 7,
    OMAP3_positionMethodNotAvailableInLocationArea = 8
} OMAP3_PositionMethodFailure_Diagnostic;

//	exception handling:
//	any unrecognized value shall be ignored
typedef struct OMAP3_PositionMethodFailure_Param {
    unsigned char   bit_mask;
#       define      OMAP3_positionMethodFailure_Diagnostic_present 0x80
#       define      OMAP3_PositionMethodFailure_Param_extensionContainer_present 0x40
    OMAP3_PositionMethodFailure_Diagnostic positionMethodFailure_Diagnostic;  
                                        /* optional; set in bit_mask
                            * OMAP3_positionMethodFailure_Diagnostic_present if
                            * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
              * OMAP3_PositionMethodFailure_Param_extensionContainer_present if
              * present */
} OMAP3_PositionMethodFailure_Param;

//	exception handling:
//	any unrecognized value shall be ignored
typedef struct OMAP3_UnknownOrUnreachableLCSClient_Param {
    unsigned char   bit_mask;
#       define      OMAP3_UnknownOrUnreachableLCSClient_Param_extensionContainer_present 0x80
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
      * OMAP3_UnknownOrUnreachableLCSClient_Param_extensionContainer_present if
      * present */
} OMAP3_UnknownOrUnreachableLCSClient_Param;

typedef struct OMAP3_MM_EventNotSupported_Param {
    unsigned char   bit_mask;
#       define      OMAP3_MM_EventNotSupported_Param_extensionContainer_present 0x80
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
               * OMAP3_MM_EventNotSupported_Param_extensionContainer_present if
               * present */
} OMAP3_MM_EventNotSupported_Param;

typedef struct OMAP3_TargetCellOutsideGCA_Param {
    unsigned char   bit_mask;
#       define      OMAP3_TargetCellOutsideGCA_Param_extensionContainer_present 0x80
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
               * OMAP3_TargetCellOutsideGCA_Param_extensionContainer_present if
               * present */
} OMAP3_TargetCellOutsideGCA_Param;

typedef struct OMAP3_SecureTransportErrorParam {
    unsigned char   bit_mask;
#       define      OMAP3_protectedPayload_present 0x80
    OMAP3_SecurityHeader securityHeader;
    OMAP3_ProtectedPayload protectedPayload;  /* optional; set in bit_mask
                                               * OMAP3_protectedPayload_present
                                               * if present */
} OMAP3_SecureTransportErrorParam;
	// The protectedPayload carries the result of applying the security function 
	// defined in 3GPP TS 33.200 to the encoding of the securely transported error 
	// parameter

	// The internal structure is defined in ETS 300 138.
typedef struct OMAP3_CUG_Interlock {
    unsigned short  length;
    unsigned char   value[4];
} OMAP3_CUG_Interlock;

typedef struct OMAP3_CUG_CheckInfo {
    unsigned char   bit_mask;
#       define      OMAP3_cug_OutgoingAccess_present 0x80
#       define      OMAP3_CUG_CheckInfo_extensionContainer_present 0x40
    OMAP3_CUG_Interlock cug_Interlock;
    Nulltype        cug_OutgoingAccess;  /* optional; set in bit_mask
                                          * OMAP3_cug_OutgoingAccess_present if
                                          * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                            * OMAP3_CUG_CheckInfo_extensionContainer_present if
                            * present */
} OMAP3_CUG_CheckInfo;

typedef unsigned short  OMAP3_NumberOfForwarding;

typedef enum OMAP3_InterrogationType {
    OMAP3_basicCall = 0,
    OMAP3_forwarding = 1,
    OMAP3_unknown = 2
} OMAP3_InterrogationType;

typedef unsigned short  OMAP3_OR_Phase;

typedef struct OMAP3_CallReferenceNumber {
    unsigned short  length;
    unsigned char   value[8];
} OMAP3_CallReferenceNumber;

typedef enum OMAP3_ForwardingReason {
    OMAP3_notReachable = 0,
    OMAP3_ForwardingReason_busy = 1,
    OMAP3_noReply = 2
} OMAP3_ForwardingReason;

	// value 1 = CAMEL phase 1,
	// value 2 = CAMEL phase 2,
	// value 3 = CAMEL Phase 3,
	// value 4 = CAMEL phase 4:
	// reception of values greater than 4 shall be treated as CAMEL phase 4.
typedef struct OMAP3_SupportedCamelPhases {
    unsigned short  length;  /* number of significant bits */
    unsigned char   value[2];
} OMAP3_SupportedCamelPhases;
#define                     OMAP3_phase1 0x80
#define                     OMAP3_phase1_byte 0
#define                     OMAP3_phase2 0x40
#define                     OMAP3_phase2_byte 0
#define                     OMAP3_phase3 0x20
#define                     OMAP3_phase3_byte 0
#define                     OMAP3_phase4 0x10
#define                     OMAP3_phase4_byte 0

// A node shall mark in the BIT STRING all CAMEL Phases it supports.
// Other values than listed above shall be discarded.
typedef struct OMAP3_OfferedCamel4CSIs {
    unsigned short  length;  /* number of significant bits */
    unsigned char   value[2];
} OMAP3_OfferedCamel4CSIs;
#define                     OMAP3_OfferedCamel4CSIs_o_csi 0x80
#define                     OMAP3_OfferedCamel4CSIs_o_csi_byte 0
#define                     OMAP3_OfferedCamel4CSIs_d_csi 0x40
#define                     OMAP3_OfferedCamel4CSIs_d_csi_byte 0
#define                     OMAP3_OfferedCamel4CSIs_vt_csi 0x20
#define                     OMAP3_OfferedCamel4CSIs_vt_csi_byte 0
#define                     OMAP3_OfferedCamel4CSIs_t_csi 0x10
#define                     OMAP3_OfferedCamel4CSIs_t_csi_byte 0
#define                     OMAP3_OfferedCamel4CSIs_mt_sms_csi 0x08
#define                     OMAP3_OfferedCamel4CSIs_mt_sms_csi_byte 0
#define                     OMAP3_OfferedCamel4CSIs_mg_csi 0x04
#define                     OMAP3_OfferedCamel4CSIs_mg_csi_byte 0
#define                     OMAP3_psi_enhancements 0x02
#define                     OMAP3_psi_enhancements_byte 0

typedef struct OMAP3_CamelInfo {
    unsigned char   bit_mask;
#       define      OMAP3_suppress_T_CSI_present 0x80
#       define      OMAP3_CamelInfo_extensionContainer_present 0x40
#       define      OMAP3_CamelInfo_offeredCamel4CSIs_present 0x20
    OMAP3_SupportedCamelPhases supportedCamelPhases;
    Nulltype        suppress_T_CSI;  /* optional; set in bit_mask
                                      * OMAP3_suppress_T_CSI_present if
                                      * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                                * OMAP3_CamelInfo_extensionContainer_present if
                                * present */
    OMAP3_OfferedCamel4CSIs offeredCamel4CSIs;  /* extension #1; optional; set
                                   * in bit_mask
                                   * OMAP3_CamelInfo_offeredCamel4CSIs_present
                                   * if present */
} OMAP3_CamelInfo;

typedef Nulltype        OMAP3_SuppressionOfAnnouncement;

typedef unsigned short  OMAP3_SupportedCCBS_Phase;

	// The internal structure of this parameter is implementation specific.
typedef enum OMAP3_IST_SupportIndicator {
    OMAP3_basicISTSupported = 0,
    OMAP3_istCommandSupported = 1
} OMAP3_IST_SupportIndicator;

// exception handling:
// Only value 1 is used.
// Values in the ranges 2-127 are reserved for future use.
// If received values 2-127 shall be mapped on to value 1.
typedef struct OMAP3_CallDiversionTreatmentIndicator {
    unsigned short  length;
    unsigned char   value[1];
} OMAP3_CallDiversionTreatmentIndicator;

typedef struct OMAP3_SendRoutingInfoArg {
    unsigned int    bit_mask;
#       define      OMAP3_SendRoutingInfoArg_cug_CheckInfo_present 0x80000000
#       define      OMAP3_numberOfForwarding_present 0x40000000
#       define      OMAP3_SendRoutingInfoArg_or_Interrogation_present 0x20000000
#       define      OMAP3_or_Capability_present 0x10000000
#       define      OMAP3_SendRoutingInfoArg_callReferenceNumber_present 0x08000000
#       define      OMAP3_forwardingReason_present 0x04000000
#       define      OMAP3_SendRoutingInfoArg_basicServiceGroup_present 0x02000000
#       define      OMAP3_SendRoutingInfoArg_networkSignalInfo_present 0x01000000
#       define      OMAP3_camelInfo_present 0x00800000
#       define      OMAP3_SendRoutingInfoArg_suppressionOfAnnouncement_present 0x00400000
#       define      OMAP3_SendRoutingInfoArg_extensionContainer_present 0x00200000
#       define      OMAP3_SendRoutingInfoArg_alertingPattern_present 0x00100000
#       define      OMAP3_SendRoutingInfoArg_ccbs_Call_present 0x00080000
#       define      OMAP3_supportedCCBS_Phase_present 0x00040000
#       define      OMAP3_SendRoutingInfoArg_additionalSignalInfo_present 0x00020000
#       define      OMAP3_SendRoutingInfoArg_istSupportIndicator_present 0x00010000
#       define      OMAP3_SendRoutingInfoArg_pre_pagingSupported_present 0x00008000
#       define      OMAP3_callDiversionTreatmentIndicator_present 0x00004000
#       define      OMAP3_SendRoutingInfoArg_longFTN_Supported_present 0x00002000
#       define      OMAP3_SendRoutingInfoArg_suppress_VT_CSI_present 0x00001000
#       define      OMAP3_suppressIncomingCallBarring_present 0x00000800
#       define      OMAP3_gsmSCF_InitiatedCall_present 0x00000400
#       define      OMAP3_SendRoutingInfoArg_basicServiceGroup2_present 0x00000200
#       define      OMAP3_networkSignalInfo2_present 0x00000100
#       define      OMAP3_suppressMTSS_present 0x00000080
#       define      OMAP3_SendRoutingInfoArg_mtRoamingRetrySupported_present 0x00000040
#       define      OMAP3_callPriority_present 0x00000020
    OMAP3_ISDN_AddressString msisdn;
    OMAP3_CUG_CheckInfo cug_CheckInfo;  /* optional; set in bit_mask
                            * OMAP3_SendRoutingInfoArg_cug_CheckInfo_present if
                            * present */
    OMAP3_NumberOfForwarding numberOfForwarding;  /* optional; set in bit_mask
                                          * OMAP3_numberOfForwarding_present if
                                          * present */
    OMAP3_InterrogationType interrogationType;
    Nulltype        or_Interrogation;  /* optional; set in bit_mask
                         * OMAP3_SendRoutingInfoArg_or_Interrogation_present if
                         * present */
    OMAP3_OR_Phase  or_Capability;  /* optional; set in bit_mask
                                     * OMAP3_or_Capability_present if present */
    OMAP3_ISDN_AddressString gmsc_OrGsmSCF_Address;
    OMAP3_CallReferenceNumber callReferenceNumber;  /* optional; set in bit_mask
                      * OMAP3_SendRoutingInfoArg_callReferenceNumber_present if
                      * present */
    OMAP3_ForwardingReason forwardingReason;  /* optional; set in bit_mask
                                               * OMAP3_forwardingReason_present
                                               * if present */
    OMAP3_Ext_BasicServiceCode basicServiceGroup;  /* optional; set in bit_mask
                        * OMAP3_SendRoutingInfoArg_basicServiceGroup_present if
                        * present */
    OMAP3_ExternalSignalInfo networkSignalInfo;  /* optional; set in bit_mask
                        * OMAP3_SendRoutingInfoArg_networkSignalInfo_present if
                        * present */
    OMAP3_CamelInfo camelInfo;  /* optional; set in bit_mask
                                 * OMAP3_camelInfo_present if present */
    OMAP3_SuppressionOfAnnouncement suppressionOfAnnouncement;  /* optional; set
                                   * in bit_mask
                * OMAP3_SendRoutingInfoArg_suppressionOfAnnouncement_present if
                * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                       * OMAP3_SendRoutingInfoArg_extensionContainer_present if
                       * present */
    OMAP3_AlertingPattern alertingPattern;  /* extension #1; optional; set in
                                   * bit_mask
                          * OMAP3_SendRoutingInfoArg_alertingPattern_present if
                          * present */
    Nulltype        ccbs_Call;  /* extension #2; optional; set in bit_mask
                                 * OMAP3_SendRoutingInfoArg_ccbs_Call_present if
                                 * present */
    OMAP3_SupportedCCBS_Phase supportedCCBS_Phase;  /* extension #3; optional;
                                   * set in bit_mask
                                   * OMAP3_supportedCCBS_Phase_present if
                                   * present */
    OMAP3_Ext_ExternalSignalInfo additionalSignalInfo;  /* extension #4;
                                   * optional; set in bit_mask
                     * OMAP3_SendRoutingInfoArg_additionalSignalInfo_present if
                     * present */
    OMAP3_IST_SupportIndicator istSupportIndicator;  /* extension #5; optional;
                                   * set in bit_mask
                      * OMAP3_SendRoutingInfoArg_istSupportIndicator_present if
                      * present */
    Nulltype        pre_pagingSupported;  /* extension #6; optional; set in
                                   * bit_mask
                      * OMAP3_SendRoutingInfoArg_pre_pagingSupported_present if
                      * present */
    OMAP3_CallDiversionTreatmentIndicator callDiversionTreatmentIndicator;  
                                        /* extension #7; optional; set in
                                   * bit_mask
                             * OMAP3_callDiversionTreatmentIndicator_present if
                             * present */
    Nulltype        longFTN_Supported;  /* extension #8; optional; set in
                                   * bit_mask
                        * OMAP3_SendRoutingInfoArg_longFTN_Supported_present if
                        * present */
    Nulltype        suppress_VT_CSI;  /* extension #9; optional; set in bit_mask
                          * OMAP3_SendRoutingInfoArg_suppress_VT_CSI_present if
                          * present */
    Nulltype        suppressIncomingCallBarring;  /* extension #10; optional;
                                   * set in bit_mask
                                   * OMAP3_suppressIncomingCallBarring_present
                                   * if present */
    Nulltype        gsmSCF_InitiatedCall;  /* extension #11; optional; set in
                                   * bit_mask OMAP3_gsmSCF_InitiatedCall_present
                                   * if present */
    OMAP3_Ext_BasicServiceCode basicServiceGroup2;  /* extension #12; optional;
                                   * set in bit_mask
                       * OMAP3_SendRoutingInfoArg_basicServiceGroup2_present if
                       * present */
    OMAP3_ExternalSignalInfo networkSignalInfo2;  /* extension #13; optional;
                                   * set in bit_mask
                                   * OMAP3_networkSignalInfo2_present if
                                   * present */
    struct OMAP3__bit1 {
        unsigned short  length;  /* number of significant bits */
        unsigned char   *value;
    } suppressMTSS;  /* extension #14; optional; set in bit_mask
                      * OMAP3_suppressMTSS_present if present */
#       define      OMAP3_suppressCUG 0x80
#       define      OMAP3_suppressCUG_byte 0
#       define      OMAP3_suppressCCBS 0x40
#       define      OMAP3_suppressCCBS_byte 0
    Nulltype        mtRoamingRetrySupported;  /* extension #15; optional; set in
                                   * bit_mask
                  * OMAP3_SendRoutingInfoArg_mtRoamingRetrySupported_present if
                  * present */
    unsigned short  callPriority;  /* extension #16; optional; set in bit_mask
                                    * OMAP3_callPriority_present if present */
} OMAP3_SendRoutingInfoArg;

	// bits 8765: 0000 (unused)
	// bits 4321: Used to convey the "P bit","R bit","A bit" and "Q bit",
	//		    representing supplementary service state information
	//		    as defined in TS 3GPP TS 23.011 [22]

	// bit 4: "Q bit"

	// bit 3: "P bit"

	// bit 2: "R bit"

	// bit 1: "A bit"
typedef struct OMAP3_ForwardingOptions {
    unsigned short  length;
    unsigned char   value[1];
} OMAP3_ForwardingOptions;

typedef struct OMAP3_ForwardingData {
    unsigned char   bit_mask;
#       define      OMAP3_ForwardingData_forwardedToNumber_present 0x80
#       define      OMAP3_ForwardingData_forwardedToSubaddress_present 0x40
#       define      OMAP3_ForwardingData_forwardingOptions_present 0x20
#       define      OMAP3_ForwardingData_extensionContainer_present 0x10
#       define      OMAP3_ForwardingData_longForwardedToNumber_present 0x08
    OMAP3_ISDN_AddressString forwardedToNumber;  /* optional; set in bit_mask
                            * OMAP3_ForwardingData_forwardedToNumber_present if
                            * present */
	// When this datatype is sent from an HLR which supports CAMEL Phase 2
	// to a GMSC which supports CAMEL Phase 2 the GMSC shall not check the
	// format of the number
    OMAP3_ISDN_SubaddressString forwardedToSubaddress;  /* optional; set in
                                   * bit_mask
                        * OMAP3_ForwardingData_forwardedToSubaddress_present if
                        * present */
    OMAP3_ForwardingOptions forwardingOptions;  /* optional; set in bit_mask
                            * OMAP3_ForwardingData_forwardingOptions_present if
                            * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                           * OMAP3_ForwardingData_extensionContainer_present if
                           * present */
    OMAP3_FTN_AddressString longForwardedToNumber;  /* extension #1; optional;
                                   * set in bit_mask
                        * OMAP3_ForwardingData_longForwardedToNumber_present if
                        * present */
} OMAP3_ForwardingData;

typedef struct OMAP3_RoutingInfo {
    unsigned short  choice;
#       define      OMAP3_roamingNumber_chosen 1
#       define      OMAP3_forwardingData_chosen 2
    union _union {
        OMAP3_ISDN_AddressString roamingNumber;  /* to choose, set choice to
                                                * OMAP3_roamingNumber_chosen */
        OMAP3_ForwardingData forwardingData;  /* to choose, set choice to
                                               * OMAP3_forwardingData_chosen */
    } u;
} OMAP3_RoutingInfo;

typedef enum OMAP3_T_BcsmTriggerDetectionPoint {
    OMAP3_termAttemptAuthorized = 12,
    OMAP3_tBusy = 13,
    OMAP3_tNoAnswer = 14
} OMAP3_T_BcsmTriggerDetectionPoint;

typedef unsigned int    OMAP3_ServiceKey;

// Type extracted from Cause parameter in ITU-T Recommendation Q.763.
// For the use of cause value refer to ITU-T Recommendation Q.850.
typedef enum OMAP3_DefaultCallHandling {
    OMAP3_continueCall = 0,
    OMAP3_releaseCall = 1
} OMAP3_DefaultCallHandling;

	//- T-BcsmCamelTDPDataList shall not contain more than one instance of
	//- T-BcsmCamelTDPData containing the same value for t-BcsmTriggerDetectionPoint.
	//- For CAMEL Phase 2, this means that only one instance of T-BcsmCamelTDPData is allowed
	//- with t-BcsmTriggerDetectionPoint being equal to DP12. 
	//- For CAMEL Phase 3, more TDP.s are allowed.
typedef struct OMAP3_T_BcsmCamelTDPData {
    unsigned char   bit_mask;
#       define      OMAP3_T_BcsmCamelTDPData_extensionContainer_present 0x80
    OMAP3_T_BcsmTriggerDetectionPoint t_BcsmTriggerDetectionPoint;
    OMAP3_ServiceKey serviceKey;
    OMAP3_ISDN_AddressString gsmSCF_Address;
    OMAP3_DefaultCallHandling defaultCallHandling;
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                       * OMAP3_T_BcsmCamelTDPData_extensionContainer_present if
                       * present */
} OMAP3_T_BcsmCamelTDPData;

//	notificationToCSE and csi-Active shall not be present when VT-CSI/T-CSI is sent
//	to VLR/GMSC.
//	They may only be included in ATSI/ATM ack/NSDC message.
//	T-CSI shall not be segmented.
typedef struct OMAP3_T_BcsmCamelTDPDataList {
    unsigned short  count;
    OMAP3_T_BcsmCamelTDPData value[10];
} OMAP3_T_BcsmCamelTDPDataList;

	// exception handling:
	// reception of values in range 2-31 shall be treated as "continueCall"
	// reception of values greater than 31 shall be treated as "releaseCall"
typedef unsigned short  OMAP3_CamelCapabilityHandling;

//	This type is used to indicate a Mobility Management event.
//	Actions for the following MM-Code values are defined in CAMEL Phase 4:
//
//	CS domain MM events:
//	Location-update-in-same-VLR	MM-Code ::= '00000000'B
//	Location-update-to-other-VLR	MM-Code ::= '00000001'B
//	IMSI-Attach	MM-Code ::= '00000010'B
//	MS-initiated-IMSI-Detach	MM-Code ::= '00000011'B
//	Network-initiated-IMSI-Detach	MM-Code ::= '00000100'B
//
//	PS domain MM events:
//	Routeing-Area-update-in-same-SGSN	MM-Code ::= '10000000'B
//	Routeing-Area-update-to-other-SGSN-update-from-new-SGSN
//				MM-Code ::= '10000001'B
//	Routeing-Area-update-to-other-SGSN-disconnect-by-detach
//				MM-Code ::= '10000010'B
//	GPRS-Attach	MM-Code ::= '10000011'B
//	MS-initiated-GPRS-Detach	MM-Code ::= '10000100'B
//	Network-initiated-GPRS-Detach	MM-Code ::= '10000101'B 
//	Network-initiated-transfer-to-MS-not-reachable-for-paging
//				MM-Code ::= '10000110'B
//
//	If the MSC receives any other MM-code than the ones listed above for the
//	CS domain, then the MSC shall ignore that MM-code.
//	If the SGSN receives any other MM-code than the ones listed above for the
//	PS domain, then the SGSN shall ignore that MM-code.
typedef struct OMAP3_T_CSI {
    unsigned char   bit_mask;
#       define      OMAP3_T_CSI_extensionContainer_present 0x80
#       define      OMAP3_T_CSI_camelCapabilityHandling_present 0x40
#       define      OMAP3_T_CSI_notificationToCSE_present 0x20
#       define      OMAP3_T_CSI_csi_Active_present 0x10
    OMAP3_T_BcsmCamelTDPDataList t_BcsmCamelTDPDataList;
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                                    * OMAP3_T_CSI_extensionContainer_present if
                                    * present */
    OMAP3_CamelCapabilityHandling camelCapabilityHandling;  /* extension #1;
                                   * optional; set in bit_mask
                                   * OMAP3_T_CSI_camelCapabilityHandling_present
                                   * if present */
    Nulltype        notificationToCSE;  /* extension #2; optional; set in
                                   * bit_mask
                                   * OMAP3_T_CSI_notificationToCSE_present if
                                   * present */
    Nulltype        csi_Active;  /* extension #3; optional; set in bit_mask
                                  * OMAP3_T_CSI_csi_Active_present if present */
} OMAP3_T_CSI;

typedef enum OMAP3_O_BcsmTriggerDetectionPoint {
    OMAP3_collectedInfo = 2,
    OMAP3_routeSelectFailure = 4
} OMAP3_O_BcsmTriggerDetectionPoint;

typedef struct OMAP3_O_BcsmCamelTDPData {
    unsigned char   bit_mask;
#       define      OMAP3_O_BcsmCamelTDPData_extensionContainer_present 0x80
    OMAP3_O_BcsmTriggerDetectionPoint o_BcsmTriggerDetectionPoint;
    OMAP3_ServiceKey serviceKey;
    OMAP3_ISDN_AddressString gsmSCF_Address;
    OMAP3_DefaultCallHandling defaultCallHandling;
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                       * OMAP3_O_BcsmCamelTDPData_extensionContainer_present if
                       * present */
} OMAP3_O_BcsmCamelTDPData;

//	notificationtoCSE and csiActive shall not be present when O-CSI is sent to VLR/GMSC.
//	They may only be included in ATSI/ATM ack/NSDC message.
//	O-CSI shall not be segmented.
typedef struct OMAP3_O_BcsmCamelTDPDataList {
    unsigned short  count;
    OMAP3_O_BcsmCamelTDPData value[10];
} OMAP3_O_BcsmCamelTDPDataList;

typedef struct OMAP3_O_CSI {
    unsigned char   bit_mask;
#       define      OMAP3_O_CSI_extensionContainer_present 0x80
#       define      OMAP3_O_CSI_camelCapabilityHandling_present 0x40
#       define      OMAP3_O_CSI_notificationToCSE_present 0x20
#       define      OMAP3_csiActive_present 0x10
    OMAP3_O_BcsmCamelTDPDataList o_BcsmCamelTDPDataList;
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                                    * OMAP3_O_CSI_extensionContainer_present if
                                    * present */
    OMAP3_CamelCapabilityHandling camelCapabilityHandling;  /* extension #1;
                                   * optional; set in bit_mask
                                   * OMAP3_O_CSI_camelCapabilityHandling_present
                                   * if present */
    Nulltype        notificationToCSE;  /* extension #2; optional; set in
                                   * bit_mask
                                   * OMAP3_O_CSI_notificationToCSE_present if
                                   * present */
    Nulltype        csiActive;  /* extension #3; optional; set in bit_mask
                                 * OMAP3_csiActive_present if present */
} OMAP3_O_CSI;

typedef enum OMAP3_MatchType {
    OMAP3_inhibiting = 0,
    OMAP3_enabling = 1
} OMAP3_MatchType;

typedef struct OMAP3_DestinationNumberList {
    unsigned short  count;
    OMAP3_ISDN_AddressString value[10];
} OMAP3_DestinationNumberList;

	// The receiving entity shall not check the format of a number in
	// the dialled number list
typedef struct OMAP3_DestinationNumberLengthList {
    unsigned short  count;
    unsigned short  value[3];
} OMAP3_DestinationNumberLengthList;

typedef struct OMAP3_DestinationNumberCriteria {
    unsigned char   bit_mask;
#       define      OMAP3_destinationNumberList_present 0x80
#       define      OMAP3_destinationNumberLengthList_present 0x40
    OMAP3_MatchType matchType;
    OMAP3_DestinationNumberList destinationNumberList;  /* optional; set in
                                   * bit_mask
                                   * OMAP3_destinationNumberList_present if
                                   * present */
    OMAP3_DestinationNumberLengthList destinationNumberLengthList;  
                                  /* optional; set in bit_mask
                                   * OMAP3_destinationNumberLengthList_present
                                   * if present */
	// one or both of destinationNumberList and destinationNumberLengthList 
	// shall be present
} OMAP3_DestinationNumberCriteria;

typedef struct OMAP3_BasicServiceCriteria {
    unsigned short  count;
    OMAP3_Ext_BasicServiceCode value[5];
} OMAP3_BasicServiceCriteria;

typedef enum OMAP3_CallTypeCriteria {
    OMAP3_forwarded = 0,
    OMAP3_notForwarded = 1
} OMAP3_CallTypeCriteria;

typedef struct OMAP3_CauseValue {
    unsigned short  length;
    unsigned char   value[1];
} OMAP3_CauseValue;

typedef struct OMAP3_O_CauseValueCriteria {
    unsigned short  count;
    OMAP3_CauseValue value[5];
} OMAP3_O_CauseValueCriteria;

typedef struct OMAP3_O_BcsmCamelTDP_Criteria {
    unsigned char   bit_mask;
#       define      OMAP3_destinationNumberCriteria_present 0x80
#       define      OMAP3_O_BcsmCamelTDP_Criteria_basicServiceCriteria_present 0x40
#       define      OMAP3_callTypeCriteria_present 0x20
#       define      OMAP3_o_CauseValueCriteria_present 0x10
#       define      OMAP3_O_BcsmCamelTDP_Criteria_extensionContainer_present 0x08
    OMAP3_O_BcsmTriggerDetectionPoint o_BcsmTriggerDetectionPoint;
    OMAP3_DestinationNumberCriteria destinationNumberCriteria;  /* optional; set
                                   * in bit_mask
                                   * OMAP3_destinationNumberCriteria_present if
                                   * present */
    OMAP3_BasicServiceCriteria basicServiceCriteria;  /* optional; set in
                                   * bit_mask
                * OMAP3_O_BcsmCamelTDP_Criteria_basicServiceCriteria_present if
                * present */
    OMAP3_CallTypeCriteria callTypeCriteria;  /* optional; set in bit_mask
                                               * OMAP3_callTypeCriteria_present
                                               * if present */
    OMAP3_O_CauseValueCriteria o_CauseValueCriteria;  /* extension #1; optional;
                                   * set in bit_mask
                                   * OMAP3_o_CauseValueCriteria_present if
                                   * present */
    OMAP3_ExtensionContainer extensionContainer;  /* extension #2; optional; set
                                   * in bit_mask
                  * OMAP3_O_BcsmCamelTDP_Criteria_extensionContainer_present if
                  * present */
} OMAP3_O_BcsmCamelTDP_Criteria;

	// exception handling:
	// For O-BcsmCamelTDPData sequences containing this parameter with any
	// other value than the ones listed the receiver shall ignore the whole 
	// O-BcsmCamelTDPDatasequence. 
	// For O-BcsmCamelTDP-Criteria sequences containing this parameter with any
	// other value than the ones listed the receiver shall ignore the whole
	// O-BcsmCamelTDP-Criteria sequence.
typedef struct OMAP3_O_BcsmCamelTDPCriteriaList {
    unsigned short  count;
    OMAP3_O_BcsmCamelTDP_Criteria value[10];
} OMAP3_O_BcsmCamelTDPCriteriaList;

typedef struct OMAP3_T_CauseValueCriteria {
    unsigned short  count;
    OMAP3_CauseValue value[5];
} OMAP3_T_CauseValueCriteria;

typedef struct OMAP3_T_BCSM_CAMEL_TDP_Criteria {
    unsigned char   bit_mask;
#       define      OMAP3_T_BCSM_CAMEL_TDP_Criteria_basicServiceCriteria_present 0x80
#       define      OMAP3_t_CauseValueCriteria_present 0x40
    OMAP3_T_BcsmTriggerDetectionPoint t_BCSM_TriggerDetectionPoint;
    OMAP3_BasicServiceCriteria basicServiceCriteria;  /* optional; set in
                                   * bit_mask
              * OMAP3_T_BCSM_CAMEL_TDP_Criteria_basicServiceCriteria_present if
              * present */
    OMAP3_T_CauseValueCriteria t_CauseValueCriteria;  /* optional; set in
                                   * bit_mask OMAP3_t_CauseValueCriteria_present
                                   * if present */
} OMAP3_T_BCSM_CAMEL_TDP_Criteria;

typedef struct OMAP3_T_BCSM_CAMEL_TDP_CriteriaList {
    unsigned short  count;
    OMAP3_T_BCSM_CAMEL_TDP_Criteria value[10];
} OMAP3_T_BCSM_CAMEL_TDP_CriteriaList;

typedef struct OMAP3_DP_AnalysedInfoCriterium {
    unsigned char   bit_mask;
#       define      OMAP3_DP_AnalysedInfoCriterium_extensionContainer_present 0x80
    OMAP3_ISDN_AddressString dialledNumber;
    OMAP3_ServiceKey serviceKey;
    OMAP3_ISDN_AddressString gsmSCF_Address;
    OMAP3_DefaultCallHandling defaultCallHandling;
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                 * OMAP3_DP_AnalysedInfoCriterium_extensionContainer_present if
                 * present */
} OMAP3_DP_AnalysedInfoCriterium;

//	notificationToCSE and csi-Active shall not be present when D-CSI is sent to VLR/GMSC.
//	They may only be included in ATSI/ATM ack/NSDC message.
//	DP-AnalysedInfoCriteria and  camelCapabilityHandling shall be present in 
//	the D-CSI sequence.
//	If D-CSI is segmented, then the first segment shall contain dp-AnalysedInfoCriteriaList
//	and camelCapabilityHandling. Subsequent segments shall not contain
//	camelCapabilityHandling, but may contain dp-AnalysedInfoCriteriaList.
typedef struct OMAP3_DP_AnalysedInfoCriteriaList {
    unsigned short  count;
    OMAP3_DP_AnalysedInfoCriterium value[10];
} OMAP3_DP_AnalysedInfoCriteriaList;

//	exception handling:
//	For TPDU-TypeCriterion sequences containing this parameter with any
//	other value than the ones listed above the receiver shall ignore 
//	the whole TPDU-TypeCriterion sequence.
//	In CAMEL phase 4, sms-SUBMIT-REPORT shall not be used and a received TPDU-TypeCriterion
//	sequence containing sms-SUBMIT-REPORT shall be wholly ignored.
typedef struct OMAP3_D_CSI {
    unsigned char   bit_mask;
#       define      OMAP3_dp_AnalysedInfoCriteriaList_present 0x80
#       define      OMAP3_D_CSI_camelCapabilityHandling_present 0x40
#       define      OMAP3_D_CSI_extensionContainer_present 0x20
#       define      OMAP3_D_CSI_notificationToCSE_present 0x10
#       define      OMAP3_D_CSI_csi_Active_present 0x08
    OMAP3_DP_AnalysedInfoCriteriaList dp_AnalysedInfoCriteriaList;  
                                  /* optional; set in bit_mask
                                   * OMAP3_dp_AnalysedInfoCriteriaList_present
                                   * if present */
    OMAP3_CamelCapabilityHandling camelCapabilityHandling;  /* optional; set in
                                   * bit_mask
                                   * OMAP3_D_CSI_camelCapabilityHandling_present
                                   * if present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                                    * OMAP3_D_CSI_extensionContainer_present if
                                    * present */
    Nulltype        notificationToCSE;  /* optional; set in bit_mask
                                         * OMAP3_D_CSI_notificationToCSE_present
                                         * if present */
    Nulltype        csi_Active;  /* optional; set in bit_mask
                                  * OMAP3_D_CSI_csi_Active_present if present */
} OMAP3_D_CSI;

typedef struct OMAP3_GmscCamelSubscriptionInfo {
    unsigned char   bit_mask;
#       define      OMAP3_GmscCamelSubscriptionInfo_t_CSI_present 0x80
#       define      OMAP3_GmscCamelSubscriptionInfo_o_CSI_present 0x40
#       define      OMAP3_GmscCamelSubscriptionInfo_extensionContainer_present 0x20
#       define      OMAP3_GmscCamelSubscriptionInfo_o_BcsmCamelTDP_CriteriaList_present 0x10
#       define      OMAP3_GmscCamelSubscriptionInfo_t_BCSM_CAMEL_TDP_CriteriaList_present 0x08
#       define      OMAP3_GmscCamelSubscriptionInfo_d_csi_present 0x04
    OMAP3_T_CSI     t_CSI;  /* optional; set in bit_mask
                             * OMAP3_GmscCamelSubscriptionInfo_t_CSI_present if
                             * present */
    OMAP3_O_CSI     o_CSI;  /* optional; set in bit_mask
                             * OMAP3_GmscCamelSubscriptionInfo_o_CSI_present if
                             * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                * OMAP3_GmscCamelSubscriptionInfo_extensionContainer_present if
                * present */
    OMAP3_O_BcsmCamelTDPCriteriaList o_BcsmCamelTDP_CriteriaList;  /* extension
                                   * #1; optional; set in bit_mask
       * OMAP3_GmscCamelSubscriptionInfo_o_BcsmCamelTDP_CriteriaList_present if
       * present */
    OMAP3_T_BCSM_CAMEL_TDP_CriteriaList t_BCSM_CAMEL_TDP_CriteriaList;  
                                  /* extension #2; optional; set in bit_mask
     * OMAP3_GmscCamelSubscriptionInfo_t_BCSM_CAMEL_TDP_CriteriaList_present if
     * present */
    OMAP3_D_CSI     d_csi;  /* extension #3; optional; set in bit_mask
                             * OMAP3_GmscCamelSubscriptionInfo_d_csi_present if
                             * present */
} OMAP3_GmscCamelSubscriptionInfo;

typedef struct OMAP3_CamelRoutingInfo {
    unsigned char   bit_mask;
#       define      OMAP3_CamelRoutingInfo_forwardingData_present 0x80
#       define      OMAP3_CamelRoutingInfo_extensionContainer_present 0x40
    OMAP3_ForwardingData forwardingData;  /* optional; set in bit_mask
                             * OMAP3_CamelRoutingInfo_forwardingData_present if
                             * present */
    OMAP3_GmscCamelSubscriptionInfo gmscCamelSubscriptionInfo;
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                         * OMAP3_CamelRoutingInfo_extensionContainer_present if
                         * present */
} OMAP3_CamelRoutingInfo;

typedef struct OMAP3_ExtendedRoutingInfo {
    unsigned short  choice;
#       define      OMAP3_routingInfo_chosen 1
#       define      OMAP3_camelRoutingInfo_chosen 2
    union _union {
        OMAP3_RoutingInfo routingInfo;  /* to choose, set choice to
                                         * OMAP3_routingInfo_chosen */
        OMAP3_CamelRoutingInfo camelRoutingInfo;  /* to choose, set choice to
                                             * OMAP3_camelRoutingInfo_chosen */
    } u;
} OMAP3_ExtendedRoutingInfo;

// Routing Area Identity is coded in accordance with 3GPP TS 29.060 [105].
// It shall contain the value part defined in 3GPP TS 29.060 only. I.e. the 3GPP TS 29.060
// type identifier octet shall not be included.
typedef struct OMAP3_GeographicalInformation {
    unsigned short  length;
    unsigned char   value[8];
} OMAP3_GeographicalInformation;

//	Refers to Calling Geodetic Location defined in Q.763 (1999).
//	Only the description of an ellipsoid point with uncertainty circle
//	as specified in Q.763 (1999) is allowed to be used
//	The internal structure according to Q.763 (1999) is as follows:
//		Screening and presentation indicators		1 octet
//		Type of shape (ellipsoid point with uncertainty circle)	1 octet
//		Degrees of Latitude				3 octets
//		Degrees of Longitude				3 octets
//		Uncertainty code				1 octet
//		Confidence				1 octet
typedef struct OMAP3_LocationNumber {
    unsigned short  length;
    unsigned char   value[10];
} OMAP3_LocationNumber;

typedef struct OMAP3_LSAIdentity {
    unsigned short  length;
    unsigned char   value[3];
} OMAP3_LSAIdentity;

//	Refers to geographical Information defined in 3GPP TS 23.032.
//	Only the description of an ellipsoid point with uncertainty circle
//	as specified in 3GPP TS 23.032 is allowed to be used
//	The internal structure according to 3GPP TS 23.032 is as follows:
//		Type of shape (ellipsoid point with uncertainty circle)	1 octet
//		Degrees of Latitude				3 octets
//		Degrees of Longitude				3 octets
//		Uncertainty code				1 octet
typedef struct OMAP3_GeodeticInformation {
    unsigned short  length;
    unsigned char   value[10];
} OMAP3_GeodeticInformation;

// exception handling:
// reception of values > 1 shall be mapped to 'cs-Domain'
typedef struct OMAP3_LocationInformation {
    unsigned short  bit_mask;
#       define      OMAP3_LocationInformation_ageOfLocationInformation_present 0x8000
#       define      OMAP3_LocationInformation_geographicalInformation_present 0x4000
#       define      OMAP3_vlr_number_present 0x2000
#       define      OMAP3_locationNumber_present 0x1000
#       define      OMAP3_LocationInformation_cellGlobalIdOrServiceAreaIdOrLAI_present 0x0800
#       define      OMAP3_LocationInformation_extensionContainer_present 0x0400
#       define      OMAP3_selectedLSA_Id_present 0x0200
#       define      OMAP3_LocationInformation_msc_Number_present 0x0100
#       define      OMAP3_LocationInformation_geodeticInformation_present 0x0080
#       define      OMAP3_LocationInformation_currentLocationRetrieved_present 0x0040
#       define      OMAP3_LocationInformation_sai_Present_present 0x0020
    OMAP3_AgeOfLocationInformation ageOfLocationInformation;  /* optional; set
                                   * in bit_mask
                * OMAP3_LocationInformation_ageOfLocationInformation_present if
                * present */
    OMAP3_GeographicalInformation geographicalInformation;  /* optional; set in
                                   * bit_mask
                 * OMAP3_LocationInformation_geographicalInformation_present if
                 * present */
    OMAP3_ISDN_AddressString vlr_number;  /* optional; set in bit_mask
                                           * OMAP3_vlr_number_present if
                                           * present */
    OMAP3_LocationNumber locationNumber;  /* optional; set in bit_mask
                                           * OMAP3_locationNumber_present if
                                           * present */
    OMAP3_CellGlobalIdOrServiceAreaIdOrLAI cellGlobalIdOrServiceAreaIdOrLAI;  
                                        /* optional; set in bit_mask
        * OMAP3_LocationInformation_cellGlobalIdOrServiceAreaIdOrLAI_present if
        * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                      * OMAP3_LocationInformation_extensionContainer_present if
                      * present */
    OMAP3_LSAIdentity selectedLSA_Id;  /* extension #1; optional; set in
                                   * bit_mask OMAP3_selectedLSA_Id_present if
                                   * present */
    OMAP3_ISDN_AddressString msc_Number;  /* extension #2; optional; set in
                                   * bit_mask
                              * OMAP3_LocationInformation_msc_Number_present if
                              * present */
    OMAP3_GeodeticInformation geodeticInformation;  /* extension #3; optional;
                                   * set in bit_mask
                     * OMAP3_LocationInformation_geodeticInformation_present if
                     * present */
    Nulltype        currentLocationRetrieved;  /* extension #4; optional; set in
                                   * bit_mask
                * OMAP3_LocationInformation_currentLocationRetrieved_present if
                * present */
    Nulltype        sai_Present;  /* extension #5; optional; set in bit_mask
                             * OMAP3_LocationInformation_sai_Present_present if
                             * present */
} OMAP3_LocationInformation;

//	The Charging ID is a unique four octet value generated by the GGSN when 
//	a PDP Context is activated. A Charging ID is generated for each activated context.
//	The encoding is defined in 3GPP TS 29.060.
typedef enum OMAP3_NotReachableReason {
    OMAP3_msPurged = 0,
    OMAP3_imsiDetached = 1,
    OMAP3_NotReachableReason_restrictedArea = 2,
    OMAP3_notRegistered = 3
} OMAP3_NotReachableReason;

	// the internal structure is defined in ITU-T Rec Q.763
typedef struct OMAP3_SubscriberState {
    unsigned short  choice;
#       define      OMAP3_assumedIdle_chosen 1
#       define      OMAP3_camelBusy_chosen 2
#       define      OMAP3_SubscriberState_netDetNotReachable_chosen 3
#       define      OMAP3_notProvidedFromVLR_chosen 4
    union _union {
        Nulltype        assumedIdle;  /* to choose, set choice to
                                       * OMAP3_assumedIdle_chosen */
        Nulltype        camelBusy;  /* to choose, set choice to
                                     * OMAP3_camelBusy_chosen */
        OMAP3_NotReachableReason netDetNotReachable;  /* to choose, set choice
                                   * to
                           * OMAP3_SubscriberState_netDetNotReachable_chosen */
        Nulltype        notProvidedFromVLR;  /* to choose, set choice to
                                           * OMAP3_notProvidedFromVLR_chosen */
    } u;
} OMAP3_SubscriberState;

// sai-Present indicates that the cellGlobalIdOrServiceAreaIdOrLAI parameter contains
// a Service Area Identity.
// currentLocationRetrieved shall be present if the location information
// was retrieved after successful paging.
typedef struct OMAP3_RAIdentity {
    unsigned short  length;
    unsigned char   value[6];
} OMAP3_RAIdentity;

// sai-Present indicates that the cellGlobalIdOrServiceAreaIdOrLAI parameter contains
// a Service Area Identity.
// currentLocationRetrieved shall be present 
// if the location information were retrieved after a successfull paging.
typedef struct OMAP3_LocationInformationGPRS {
    unsigned short  bit_mask;
#       define      OMAP3_LocationInformationGPRS_cellGlobalIdOrServiceAreaIdOrLAI_present 0x8000
#       define      OMAP3_routeingAreaIdentity_present 0x4000
#       define      OMAP3_LocationInformationGPRS_geographicalInformation_present 0x2000
#       define      OMAP3_LocationInformationGPRS_sgsn_Number_present 0x1000
#       define      OMAP3_selectedLSAIdentity_present 0x0800
#       define      OMAP3_LocationInformationGPRS_extensionContainer_present 0x0400
#       define      OMAP3_LocationInformationGPRS_sai_Present_present 0x0200
#       define      OMAP3_LocationInformationGPRS_geodeticInformation_present 0x0100
#       define      OMAP3_LocationInformationGPRS_currentLocationRetrieved_present 0x0080
#       define      OMAP3_LocationInformationGPRS_ageOfLocationInformation_present 0x0040
    OMAP3_CellGlobalIdOrServiceAreaIdOrLAI cellGlobalIdOrServiceAreaIdOrLAI;  
                                        /* optional; set in bit_mask
    * OMAP3_LocationInformationGPRS_cellGlobalIdOrServiceAreaIdOrLAI_present if
    * present */
    OMAP3_RAIdentity routeingAreaIdentity;  /* optional; set in bit_mask
                                        * OMAP3_routeingAreaIdentity_present if
                                        * present */
    OMAP3_GeographicalInformation geographicalInformation;  /* optional; set in
                                   * bit_mask
             * OMAP3_LocationInformationGPRS_geographicalInformation_present if
             * present */
    OMAP3_ISDN_AddressString sgsn_Number;  /* optional; set in bit_mask
                         * OMAP3_LocationInformationGPRS_sgsn_Number_present if
                         * present */
    OMAP3_LSAIdentity selectedLSAIdentity;  /* optional; set in bit_mask
                                             * OMAP3_selectedLSAIdentity_present
                                             * if present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                  * OMAP3_LocationInformationGPRS_extensionContainer_present if
                  * present */
    Nulltype        sai_Present;  /* extension #1; optional; set in bit_mask
                         * OMAP3_LocationInformationGPRS_sai_Present_present if
                         * present */
    OMAP3_GeodeticInformation geodeticInformation;  /* extension #2; optional;
                                   * set in bit_mask
                 * OMAP3_LocationInformationGPRS_geodeticInformation_present if
                 * present */
    Nulltype        currentLocationRetrieved;  /* extension #3; optional; set in
                                   * bit_mask
            * OMAP3_LocationInformationGPRS_currentLocationRetrieved_present if
            * present */
    OMAP3_AgeOfLocationInformation ageOfLocationInformation;  /* extension #4;
                                   * optional; set in bit_mask
            * OMAP3_LocationInformationGPRS_ageOfLocationInformation_present if
            * present */
} OMAP3_LocationInformationGPRS;

typedef unsigned short  OMAP3_ContextId;

	// Octets are coded according to TS 3GPP TS 23.003 [17] 
typedef struct OMAP3_PDP_Type {
    unsigned short  length;
    unsigned char   value[2];
} OMAP3_PDP_Type;

	// Octets are coded according to TS 3GPP TS 29.060 [105]
typedef struct OMAP3_PDP_Address {
    unsigned short  length;
    unsigned char   value[16];
} OMAP3_PDP_Address;

typedef unsigned short  OMAP3_NSAPI;

//	This type is used to indicate the Network layer Service Access Point
typedef struct OMAP3_TransactionId {
    unsigned short  length;
    unsigned char   value[2];
} OMAP3_TransactionId;

//	This type carries the value part of the transaction identifier which is used in the 
//	session management messages on the access interface. The encoding is defined in 
//	3GPP TS 24.008
typedef struct OMAP3_TEID {
    unsigned short  length;
    unsigned char   value[4];
} OMAP3_TEID;

	// Octets are coded according to TS 3GPP TS 24.008 [35] Quality of Service Octets 
	// 3-5.
typedef struct OMAP3_Ext_QoS_Subscribed {
    unsigned short  length;
    unsigned char   value[9];
} OMAP3_Ext_QoS_Subscribed;

//	This type carries the value part of the Tunnel Endpoint Identifier which is used to 
//	distinguish between different tunnels between the same pair of entities which communicate 
//	using the GPRS Tunnelling Protocol The encoding is defined in 3GPP TS 29.060.
typedef struct OMAP3_GPRSChargingID {
    unsigned short  length;
    unsigned char   value[4];
} OMAP3_GPRSChargingID;

	// Octets 1-3 are coded according to 3GPP TS 24.008 [35] Quality of Service Octets 14-16.
	// If Quality of Service information is structured with 14 octet length, then
	// Octet 1 is coded according to 3GPP TS 24.008 [35] Quality of Service Octet 14.
typedef struct OMAP3_ChargingCharacteristics {
    unsigned short  length;
    unsigned char   value[2];
} OMAP3_ChargingCharacteristics;

	// OCTET 1: 
	//  Allocation/Retention Priority (This octet encodes each priority level defined in
	//     23.107 as the binary value of the priority level, declaration in 29.060)
	// Octets 2-9 are coded according to 3GPP TS 24.008 [35] Quality of Service Octets 
	// 6-13.
typedef struct OMAP3_Ext2_QoS_Subscribed {
    unsigned short  length;
    unsigned char   value[3];
} OMAP3_Ext2_QoS_Subscribed;

typedef struct OMAP3_PDP_ContextInfo {
    unsigned int    bit_mask;
#       define      OMAP3_pdp_ContextActive_present 0x80000000
#       define      OMAP3_PDP_ContextInfo_pdp_Address_present 0x40000000
#       define      OMAP3_apn_Subscribed_present 0x20000000
#       define      OMAP3_apn_InUse_present 0x10000000
#       define      OMAP3_nsapi_present 0x08000000
#       define      OMAP3_transactionId_present 0x04000000
#       define      OMAP3_teid_ForGnAndGp_present 0x02000000
#       define      OMAP3_teid_ForIu_present 0x01000000
#       define      OMAP3_PDP_ContextInfo_ggsn_Address_present 0x00800000
#       define      OMAP3_qos_Subscribed_present 0x00400000
#       define      OMAP3_qos_Requested_present 0x00200000
#       define      OMAP3_qos_Negotiated_present 0x00100000
#       define      OMAP3_chargingId_present 0x00080000
#       define      OMAP3_PDP_ContextInfo_chargingCharacteristics_present 0x00040000
#       define      OMAP3_rnc_Address_present 0x00020000
#       define      OMAP3_PDP_ContextInfo_extensionContainer_present 0x00010000
#       define      OMAP3_qos2_Subscribed_present 0x00008000
#       define      OMAP3_qos2_Requested_present 0x00004000
#       define      OMAP3_qos2_Negotiated_present 0x00002000
    OMAP3_ContextId pdp_ContextIdentifier;
    Nulltype        pdp_ContextActive;  /* optional; set in bit_mask
                                         * OMAP3_pdp_ContextActive_present if
                                         * present */
    OMAP3_PDP_Type  pdp_Type;
    OMAP3_PDP_Address pdp_Address;  /* optional; set in bit_mask
                                     * OMAP3_PDP_ContextInfo_pdp_Address_present
                                     * if present */
    OMAP3_APN       apn_Subscribed;  /* optional; set in bit_mask
                                      * OMAP3_apn_Subscribed_present if
                                      * present */
    OMAP3_APN       apn_InUse;  /* optional; set in bit_mask
                                 * OMAP3_apn_InUse_present if present */
    OMAP3_NSAPI     nsapi;  /* optional; set in bit_mask OMAP3_nsapi_present if
                             * present */
    OMAP3_TransactionId transactionId;  /* optional; set in bit_mask
                                         * OMAP3_transactionId_present if
                                         * present */
    OMAP3_TEID      teid_ForGnAndGp;  /* optional; set in bit_mask
                                       * OMAP3_teid_ForGnAndGp_present if
                                       * present */
    OMAP3_TEID      teid_ForIu;  /* optional; set in bit_mask
                                  * OMAP3_teid_ForIu_present if present */
    OMAP3_GSN_Address ggsn_Address;  /* optional; set in bit_mask
                                * OMAP3_PDP_ContextInfo_ggsn_Address_present if
                                * present */
    OMAP3_Ext_QoS_Subscribed qos_Subscribed;  /* optional; set in bit_mask
                                               * OMAP3_qos_Subscribed_present if
                                               * present */
    OMAP3_Ext_QoS_Subscribed qos_Requested;  /* optional; set in bit_mask
                                              * OMAP3_qos_Requested_present if
                                              * present */
    OMAP3_Ext_QoS_Subscribed qos_Negotiated;  /* optional; set in bit_mask
                                               * OMAP3_qos_Negotiated_present if
                                               * present */
    OMAP3_GPRSChargingID chargingId;  /* optional; set in bit_mask
                                       * OMAP3_chargingId_present if present */
    OMAP3_ChargingCharacteristics chargingCharacteristics;  /* optional; set in
                                   * bit_mask
                     * OMAP3_PDP_ContextInfo_chargingCharacteristics_present if
                     * present */
    OMAP3_GSN_Address rnc_Address;  /* optional; set in bit_mask
                                     * OMAP3_rnc_Address_present if present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                          * OMAP3_PDP_ContextInfo_extensionContainer_present if
                          * present */
    OMAP3_Ext2_QoS_Subscribed qos2_Subscribed;  /* extension #1; optional; set
                                   * in bit_mask OMAP3_qos2_Subscribed_present
                                   * if present */
	// qos2-Subscribed may be present only if qos-Subscribed is present.
    OMAP3_Ext2_QoS_Subscribed qos2_Requested;  /* extension #2; optional; set in
                                   * bit_mask OMAP3_qos2_Requested_present if
                                   * present */
	// qos2-Requested may be present only if qos-Requested is present.
    OMAP3_Ext2_QoS_Subscribed qos2_Negotiated;  /* extension #3; optional; set
                                   * in bit_mask OMAP3_qos2_Negotiated_present
                                   * if present */
	// qos2-Negotiated may be present only if qos-Negotiated is present.
} OMAP3_PDP_ContextInfo;

typedef struct OMAP3_PDP_ContextInfoList {
    unsigned short  count;
    OMAP3_PDP_ContextInfo value[50];
} OMAP3_PDP_ContextInfoList;

typedef struct OMAP3_PS_SubscriberState {
    unsigned short  choice;
#       define      OMAP3_notProvidedFromSGSN_chosen 1
#       define      OMAP3_ps_Detached_chosen 2
#       define      OMAP3_ps_AttachedNotReachableForPaging_chosen 3
#       define      OMAP3_ps_AttachedReachableForPaging_chosen 4
#       define      OMAP3_ps_PDP_ActiveNotReachableForPaging_chosen 5
#       define      OMAP3_ps_PDP_ActiveReachableForPaging_chosen 6
#       define      OMAP3_PS_SubscriberState_netDetNotReachable_chosen 7
    union _union {
        Nulltype        notProvidedFromSGSN;  /* to choose, set choice to
                                          * OMAP3_notProvidedFromSGSN_chosen */
        Nulltype        ps_Detached;  /* to choose, set choice to
                                       * OMAP3_ps_Detached_chosen */
        Nulltype        ps_AttachedNotReachableForPaging;  /* to choose, set
                                   * choice to
                             * OMAP3_ps_AttachedNotReachableForPaging_chosen */
        Nulltype        ps_AttachedReachableForPaging;  /* to choose, set choice
                                   * to
                                * OMAP3_ps_AttachedReachableForPaging_chosen */
        OMAP3_PDP_ContextInfoList ps_PDP_ActiveNotReachableForPaging;  /* to
                                   * choose, set choice to
                           * OMAP3_ps_PDP_ActiveNotReachableForPaging_chosen */
        OMAP3_PDP_ContextInfoList ps_PDP_ActiveReachableForPaging;  /* to
                                   * choose, set choice to
                              * OMAP3_ps_PDP_ActiveReachableForPaging_chosen */
        OMAP3_NotReachableReason netDetNotReachable;  /* to choose, set choice
                                   * to
                        * OMAP3_PS_SubscriberState_netDetNotReachable_chosen */
    } u;
} OMAP3_PS_SubscriberState;

	//	exception handling: 
	//  reception of other values than the ones listed the receiver shall ignore the 
	//  whole NumberPortabilityStatus;
	//  ownNumberNotPortedOut or foreignNumberPortedIn may only be included in Any Time 
	//  Interrogation message.
typedef struct OMAP3_MS_Classmark2 {
    unsigned short  length;
    unsigned char   value[3];
} OMAP3_MS_Classmark2;

typedef struct OMAP3_MSNetworkCapability {
    unsigned short  length;
    unsigned char   value[8];
} OMAP3_MSNetworkCapability;

	// This parameter carries the value part of the MS Network Capability IE defined in 
	// 3GPP TS 24.008 [35].
typedef struct OMAP3_MSRadioAccessCapability {
    unsigned short  length;
    unsigned char   value[50];
} OMAP3_MSRadioAccessCapability;

	// This parameter carries the value part of the MS Classmark 2 IE defined in 
	// 3GPP TS 24.008 [35].
typedef struct OMAP3_GPRSMSClass {
    unsigned char   bit_mask;
#       define      OMAP3_mSRadioAccessCapability_present 0x80
    OMAP3_MSNetworkCapability mSNetworkCapability;
    OMAP3_MSRadioAccessCapability mSRadioAccessCapability;  /* optional; set in
                                   * bit_mask
                                   * OMAP3_mSRadioAccessCapability_present if
                                   * present */
} OMAP3_GPRSMSClass;

//	The IMSI parameter contains a generic IMSI, i.e. it is not tied necessarily to the 
//	Subscriber. MCC and MNC values in this IMSI shall point to the Subscription Network of 
//	the Subscriber. See 3GPP TS 23.066 [108].
typedef struct OMAP3_RouteingNumber {
    unsigned short  length;
    unsigned char   value[5];
} OMAP3_RouteingNumber;

typedef enum OMAP3_NumberPortabilityStatus {
    OMAP3_notKnownToBePorted = 0,
    OMAP3_ownNumberPortedOut = 1,
    OMAP3_foreignNumberPortedToForeignNetwork = 2,
    OMAP3_ownNumberNotPortedOut = 4,
    OMAP3_foreignNumberPortedIn = 5
} OMAP3_NumberPortabilityStatus;

//	If the HLR receives locationInformation, subscriberState or ms-Classmark2 from an SGSN
//	it shall discard them.
//	If the HLR receives locationInformationGPRS, ps-SubscriberState or gprs-MS-Class from
//	a VLR it shall discard them.
//	If the HLR receives parameters which it has not requested, it shall discard them.
typedef struct OMAP3_MNPInfoRes {
    unsigned char   bit_mask;
#       define      OMAP3_routeingNumber_present 0x80
#       define      OMAP3_MNPInfoRes_imsi_present 0x40
#       define      OMAP3_MNPInfoRes_msisdn_present 0x20
#       define      OMAP3_MNPInfoRes_numberPortabilityStatus_present 0x10
#       define      OMAP3_MNPInfoRes_extensionContainer_present 0x08
    OMAP3_RouteingNumber routeingNumber;  /* optional; set in bit_mask
                                           * OMAP3_routeingNumber_present if
                                           * present */
    OMAP3_IMSI      imsi;  /* optional; set in bit_mask
                            * OMAP3_MNPInfoRes_imsi_present if present */
    OMAP3_ISDN_AddressString msisdn;  /* optional; set in bit_mask
                                       * OMAP3_MNPInfoRes_msisdn_present if
                                       * present */
    OMAP3_NumberPortabilityStatus numberPortabilityStatus;  /* optional; set in
                                   * bit_mask
                          * OMAP3_MNPInfoRes_numberPortabilityStatus_present if
                          * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                               * OMAP3_MNPInfoRes_extensionContainer_present if
                               * present */
} OMAP3_MNPInfoRes;

typedef struct OMAP3_SubscriberInfo {
    unsigned short  bit_mask;
#       define      OMAP3_SubscriberInfo_locationInformation_present 0x8000
#       define      OMAP3_SubscriberInfo_subscriberState_present 0x4000
#       define      OMAP3_SubscriberInfo_extensionContainer_present 0x2000
#       define      OMAP3_SubscriberInfo_locationInformationGPRS_present 0x1000
#       define      OMAP3_ps_SubscriberState_present 0x0800
#       define      OMAP3_SubscriberInfo_imei_present 0x0400
#       define      OMAP3_ms_Classmark2_present 0x0200
#       define      OMAP3_gprs_MS_Class_present 0x0100
#       define      OMAP3_mnpInfoRes_present 0x0080
    OMAP3_LocationInformation locationInformation;  /* optional; set in bit_mask
                          * OMAP3_SubscriberInfo_locationInformation_present if
                          * present */
    OMAP3_SubscriberState subscriberState;  /* optional; set in bit_mask
                              * OMAP3_SubscriberInfo_subscriberState_present if
                              * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                           * OMAP3_SubscriberInfo_extensionContainer_present if
                           * present */
    OMAP3_LocationInformationGPRS locationInformationGPRS;  /* extension #1;
                                   * optional; set in bit_mask
                      * OMAP3_SubscriberInfo_locationInformationGPRS_present if
                      * present */
    OMAP3_PS_SubscriberState ps_SubscriberState;  /* extension #2; optional; set
                                   * in bit_mask
                                   * OMAP3_ps_SubscriberState_present if
                                   * present */
    OMAP3_IMEI      imei;  /* extension #3; optional; set in bit_mask
                            * OMAP3_SubscriberInfo_imei_present if present */
    OMAP3_MS_Classmark2 ms_Classmark2;  /* extension #4; optional; set in
                                   * bit_mask OMAP3_ms_Classmark2_present if
                                   * present */
    OMAP3_GPRSMSClass gprs_MS_Class;  /* extension #5; optional; set in bit_mask
                                       * OMAP3_gprs_MS_Class_present if
                                       * present */
    OMAP3_MNPInfoRes mnpInfoRes;  /* extension #6; optional; set in bit_mask
                                   * OMAP3_mnpInfoRes_present if present */
} OMAP3_SubscriberInfo;

	// How this information is really delivered to the subscriber
	// (display, announcement, ...) is not part of this
	// specification.
typedef struct OMAP3_SS_List {
    unsigned short  count;
    OMAP3_SS_Code   value[30];
} OMAP3_SS_List;

	//	exception handling: 
	//	Reception of other values than the ones listed shall result in the service
	//	being unavailable for that call.
typedef struct OMAP3_CCBS_Indicators {
    unsigned char   bit_mask;
#       define      OMAP3_CCBS_Indicators_ccbs_Possible_present 0x80
#       define      OMAP3_keepCCBS_CallIndicator_present 0x40
#       define      OMAP3_CCBS_Indicators_extensionContainer_present 0x20
    Nulltype        ccbs_Possible;  /* optional; set in bit_mask
                               * OMAP3_CCBS_Indicators_ccbs_Possible_present if
                               * present */
    Nulltype        keepCCBS_CallIndicator;  /* optional; set in bit_mask
                                      * OMAP3_keepCCBS_CallIndicator_present if
                                      * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                          * OMAP3_CCBS_Indicators_extensionContainer_present if
                          * present */
} OMAP3_CCBS_Indicators;

	// This data type encodes each priority level defined in TS 23.107 as the binary value
	// of the priority level.
typedef unsigned short  OMAP3_IST_AlertTimerValue;

typedef struct OMAP3_AllowedServices {
    unsigned short  length;  /* number of significant bits */
    unsigned char   *value;
} OMAP3_AllowedServices;
#define                     OMAP3_firstServiceAllowed 0x80
#define                     OMAP3_firstServiceAllowed_byte 0
#define                     OMAP3_secondServiceAllowed 0x40
#define                     OMAP3_secondServiceAllowed_byte 0

	//	firstService is the service indicated in the networkSignalInfo
	//	secondService is the service indicated in the networkSignalInfo2
	//	Other bits than listed above shall be discarded
typedef enum OMAP3_UnavailabilityCause {
    OMAP3_UnavailabilityCause_bearerServiceNotProvisioned = 1,
    OMAP3_UnavailabilityCause_teleserviceNotProvisioned = 2,
    OMAP3_UnavailabilityCause_absentSubscriber = 3,
    OMAP3_UnavailabilityCause_busySubscriber = 4,
    OMAP3_UnavailabilityCause_callBarred = 5,
    OMAP3_UnavailabilityCause_cug_Reject = 6
} OMAP3_UnavailabilityCause;

//	callDiversionAllowed (xxxx xx01)
//	callDiversionNotAllowed (xxxx xx10)
//	network default is call diversion allowed
typedef struct OMAP3_SendRoutingInfoRes {
    unsigned int    bit_mask;
#       define      OMAP3_SendRoutingInfoRes_imsi_present 0x80000000
#       define      OMAP3_extendedRoutingInfo_present 0x40000000
#       define      OMAP3_SendRoutingInfoRes_cug_CheckInfo_present 0x20000000
#       define      OMAP3_cugSubscriptionFlag_present 0x10000000
#       define      OMAP3_subscriberInfo_present 0x08000000
#       define      OMAP3_SendRoutingInfoRes_ss_List_present 0x04000000
#       define      OMAP3_SendRoutingInfoRes_basicService_present 0x02000000
#       define      OMAP3_forwardingInterrogationRequired_present 0x01000000
#       define      OMAP3_vmsc_Address_present 0x00800000
#       define      OMAP3_SendRoutingInfoRes_extensionContainer_present 0x00400000
#       define      OMAP3_SendRoutingInfoRes_naea_PreferredCI_present 0x00200000
#       define      OMAP3_ccbs_Indicators_present 0x00100000
#       define      OMAP3_SendRoutingInfoRes_msisdn_present 0x00080000
#       define      OMAP3_SendRoutingInfoRes_numberPortabilityStatus_present 0x00040000
#       define      OMAP3_SendRoutingInfoRes_istAlertTimer_present 0x00020000
#       define      OMAP3_supportedCamelPhasesInVMSC_present 0x00010000
#       define      OMAP3_offeredCamel4CSIsInVMSC_present 0x00008000
#       define      OMAP3_routingInfo2_present 0x00004000
#       define      OMAP3_ss_List2_present 0x00002000
#       define      OMAP3_basicService2_present 0x00001000
#       define      OMAP3_allowedServices_present 0x00000800
#       define      OMAP3_unavailabilityCause_present 0x00000400
#       define      OMAP3_SendRoutingInfoRes_releaseResourcesSupported_present 0x00000200
#       define      OMAP3_SendRoutingInfoRes_gsm_BearerCapability_present 0x00000100
    OMAP3_IMSI      imsi;  /* optional; set in bit_mask
                            * OMAP3_SendRoutingInfoRes_imsi_present if
                            * present */
	// IMSI must be present if SendRoutingInfoRes is not segmented.
	// If the TC-Result-NL segmentation option is taken the IMSI must be
	// present in one segmented transmission of SendRoutingInfoRes.
    OMAP3_ExtendedRoutingInfo extendedRoutingInfo;  /* optional; set in bit_mask
                                         * OMAP3_extendedRoutingInfo_present if
                                         * present */
    OMAP3_CUG_CheckInfo cug_CheckInfo;  /* optional; set in bit_mask
                            * OMAP3_SendRoutingInfoRes_cug_CheckInfo_present if
                            * present */
    Nulltype        cugSubscriptionFlag;  /* optional; set in bit_mask
                                           * OMAP3_cugSubscriptionFlag_present
                                           * if present */
    OMAP3_SubscriberInfo subscriberInfo;  /* optional; set in bit_mask
                                           * OMAP3_subscriberInfo_present if
                                           * present */
    OMAP3_SS_List   ss_List;  /* optional; set in bit_mask
                               * OMAP3_SendRoutingInfoRes_ss_List_present if
                               * present */
    OMAP3_Ext_BasicServiceCode basicService;  /* optional; set in bit_mask
                             * OMAP3_SendRoutingInfoRes_basicService_present if
                             * present */
    Nulltype        forwardingInterrogationRequired;  /* optional; set in
                                   * bit_mask
                             * OMAP3_forwardingInterrogationRequired_present if
                             * present */
    OMAP3_ISDN_AddressString vmsc_Address;  /* optional; set in bit_mask
                                             * OMAP3_vmsc_Address_present if
                                             * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                       * OMAP3_SendRoutingInfoRes_extensionContainer_present if
                       * present */
    OMAP3_NAEA_PreferredCI naea_PreferredCI;  /* extension #1; optional; set in
                                   * bit_mask
                         * OMAP3_SendRoutingInfoRes_naea_PreferredCI_present if
                         * present */
	// naea-PreferredCI is included at the discretion of the HLR operator.
    OMAP3_CCBS_Indicators ccbs_Indicators;  /* extension #2; optional; set in
                                   * bit_mask OMAP3_ccbs_Indicators_present if
                                   * present */
    OMAP3_ISDN_AddressString msisdn;  /* extension #3; optional; set in bit_mask
                                       * OMAP3_SendRoutingInfoRes_msisdn_present
                                       * if present */
    OMAP3_NumberPortabilityStatus numberPortabilityStatus;  /* extension #4;
                                   * optional; set in bit_mask
                  * OMAP3_SendRoutingInfoRes_numberPortabilityStatus_present if
                  * present */
    OMAP3_IST_AlertTimerValue istAlertTimer;  /* extension #5; optional; set in
                                   * bit_mask
                            * OMAP3_SendRoutingInfoRes_istAlertTimer_present if
                            * present */
    OMAP3_SupportedCamelPhases supportedCamelPhasesInVMSC;  /* extension #6;
                                   * optional; set in bit_mask
                                   * OMAP3_supportedCamelPhasesInVMSC_present if
                                   * present */
    OMAP3_OfferedCamel4CSIs offeredCamel4CSIsInVMSC;  /* extension #7; optional;
                                   * set in bit_mask
                                   * OMAP3_offeredCamel4CSIsInVMSC_present if
                                   * present */
    OMAP3_RoutingInfo routingInfo2;  /* extension #8; optional; set in bit_mask
                                      * OMAP3_routingInfo2_present if present */
    OMAP3_SS_List   ss_List2;  /* extension #9; optional; set in bit_mask
                                * OMAP3_ss_List2_present if present */
    OMAP3_Ext_BasicServiceCode basicService2;  /* extension #10; optional; set
                                   * in bit_mask OMAP3_basicService2_present if
                                   * present */
    OMAP3_AllowedServices allowedServices;  /* extension #11; optional; set in
                                   * bit_mask OMAP3_allowedServices_present if
                                   * present */
    OMAP3_UnavailabilityCause unavailabilityCause;  /* extension #12; optional;
                                   * set in bit_mask
                                   * OMAP3_unavailabilityCause_present if
                                   * present */
    Nulltype        releaseResourcesSupported;  /* extension #13; optional; set
                                   * in bit_mask
                * OMAP3_SendRoutingInfoRes_releaseResourcesSupported_present if
                * present */
    OMAP3_ExternalSignalInfo gsm_BearerCapability;  /* extension #14; optional;
                                   * set in bit_mask
                     * OMAP3_SendRoutingInfoRes_gsm_BearerCapability_present if
                     * present */
} OMAP3_SendRoutingInfoRes;

typedef struct OMAP3_ProvideRoamingNumberArg {
    unsigned int    bit_mask;
#       define      OMAP3_ProvideRoamingNumberArg_msisdn_present 0x80000000
#       define      OMAP3_ProvideRoamingNumberArg_lmsi_present 0x40000000
#       define      OMAP3_ProvideRoamingNumberArg_gsm_BearerCapability_present 0x20000000
#       define      OMAP3_ProvideRoamingNumberArg_networkSignalInfo_present 0x10000000
#       define      OMAP3_ProvideRoamingNumberArg_suppressionOfAnnouncement_present 0x08000000
#       define      OMAP3_gmsc_Address_present 0x04000000
#       define      OMAP3_ProvideRoamingNumberArg_callReferenceNumber_present 0x02000000
#       define      OMAP3_ProvideRoamingNumberArg_or_Interrogation_present 0x01000000
#       define      OMAP3_ProvideRoamingNumberArg_extensionContainer_present 0x00800000
#       define      OMAP3_ProvideRoamingNumberArg_alertingPattern_present 0x00400000
#       define      OMAP3_ProvideRoamingNumberArg_ccbs_Call_present 0x00200000
#       define      OMAP3_supportedCamelPhasesInInterrogatingNode_present 0x00100000
#       define      OMAP3_ProvideRoamingNumberArg_additionalSignalInfo_present 0x00080000
#       define      OMAP3_orNotSupportedInGMSC_present 0x00040000
#       define      OMAP3_ProvideRoamingNumberArg_pre_pagingSupported_present 0x00020000
#       define      OMAP3_ProvideRoamingNumberArg_longFTN_Supported_present 0x00010000
#       define      OMAP3_ProvideRoamingNumberArg_suppress_VT_CSI_present 0x00008000
#       define      OMAP3_offeredCamel4CSIsInInterrogatingNode_present 0x00004000
#       define      OMAP3_ProvideRoamingNumberArg_mtRoamingRetrySupported_present 0x00002000
    OMAP3_IMSI      imsi;
    OMAP3_ISDN_AddressString msc_Number;
    OMAP3_ISDN_AddressString msisdn;  /* optional; set in bit_mask
                              * OMAP3_ProvideRoamingNumberArg_msisdn_present if
                              * present */
    OMAP3_LMSI      lmsi;  /* optional; set in bit_mask
                            * OMAP3_ProvideRoamingNumberArg_lmsi_present if
                            * present */
    OMAP3_ExternalSignalInfo gsm_BearerCapability;  /* optional; set in bit_mask
                * OMAP3_ProvideRoamingNumberArg_gsm_BearerCapability_present if
                * present */
    OMAP3_ExternalSignalInfo networkSignalInfo;  /* optional; set in bit_mask
                   * OMAP3_ProvideRoamingNumberArg_networkSignalInfo_present if
                   * present */
    OMAP3_SuppressionOfAnnouncement suppressionOfAnnouncement;  /* optional; set
                                   * in bit_mask
           * OMAP3_ProvideRoamingNumberArg_suppressionOfAnnouncement_present if
           * present */
    OMAP3_ISDN_AddressString gmsc_Address;  /* optional; set in bit_mask
                                             * OMAP3_gmsc_Address_present if
                                             * present */
    OMAP3_CallReferenceNumber callReferenceNumber;  /* optional; set in bit_mask
                 * OMAP3_ProvideRoamingNumberArg_callReferenceNumber_present if
                 * present */
    Nulltype        or_Interrogation;  /* optional; set in bit_mask
                    * OMAP3_ProvideRoamingNumberArg_or_Interrogation_present if
                    * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                  * OMAP3_ProvideRoamingNumberArg_extensionContainer_present if
                  * present */
    OMAP3_AlertingPattern alertingPattern;  /* extension #1; optional; set in
                                   * bit_mask
                     * OMAP3_ProvideRoamingNumberArg_alertingPattern_present if
                     * present */
    Nulltype        ccbs_Call;  /* extension #2; optional; set in bit_mask
                           * OMAP3_ProvideRoamingNumberArg_ccbs_Call_present if
                           * present */
    OMAP3_SupportedCamelPhases supportedCamelPhasesInInterrogatingNode;  
                                  /* extension #3; optional; set in bit_mask
                     * OMAP3_supportedCamelPhasesInInterrogatingNode_present if
                     * present */
    OMAP3_Ext_ExternalSignalInfo additionalSignalInfo;  /* extension #4;
                                   * optional; set in bit_mask
                * OMAP3_ProvideRoamingNumberArg_additionalSignalInfo_present if
                * present */
    Nulltype        orNotSupportedInGMSC;  /* extension #5; optional; set in
                                   * bit_mask OMAP3_orNotSupportedInGMSC_present
                                   * if present */
    Nulltype        pre_pagingSupported;  /* extension #6; optional; set in
                                   * bit_mask
                 * OMAP3_ProvideRoamingNumberArg_pre_pagingSupported_present if
                 * present */
    Nulltype        longFTN_Supported;  /* extension #7; optional; set in
                                   * bit_mask
                   * OMAP3_ProvideRoamingNumberArg_longFTN_Supported_present if
                   * present */
    Nulltype        suppress_VT_CSI;  /* extension #8; optional; set in bit_mask
                     * OMAP3_ProvideRoamingNumberArg_suppress_VT_CSI_present if
                     * present */
    OMAP3_OfferedCamel4CSIs offeredCamel4CSIsInInterrogatingNode;  /* extension
                                   * #9; optional; set in bit_mask
                        * OMAP3_offeredCamel4CSIsInInterrogatingNode_present if
                        * present */
    Nulltype        mtRoamingRetrySupported;  /* extension #10; optional; set in
                                   * bit_mask
             * OMAP3_ProvideRoamingNumberArg_mtRoamingRetrySupported_present if
             * present */
} OMAP3_ProvideRoamingNumberArg;

typedef struct OMAP3_ProvideRoamingNumberRes {
    unsigned char   bit_mask;
#       define      OMAP3_ProvideRoamingNumberRes_extensionContainer_present 0x80
#       define      OMAP3_ProvideRoamingNumberRes_releaseResourcesSupported_present 0x40
    OMAP3_ISDN_AddressString roamingNumber;
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                  * OMAP3_ProvideRoamingNumberRes_extensionContainer_present if
                  * present */
    Nulltype        releaseResourcesSupported;  /* extension #1; optional; set
                                   * in bit_mask
           * OMAP3_ProvideRoamingNumberRes_releaseResourcesSupported_present if
           * present */
} OMAP3_ProvideRoamingNumberRes;

typedef struct OMAP3_UUIndicator {
    unsigned short  length;
    unsigned char   value[1];
} OMAP3_UUIndicator;

	// Octets are coded according to ETS 300 356
typedef struct OMAP3_UUI {
    unsigned short  length;
    unsigned char   value[131];
} OMAP3_UUI;

typedef struct OMAP3_UU_Data {
    unsigned char   bit_mask;
#       define      OMAP3_uuIndicator_present 0x80
#       define      OMAP3_uui_present 0x40
#       define      OMAP3_uusCFInteraction_present 0x20
#       define      OMAP3_UU_Data_extensionContainer_present 0x10
    OMAP3_UUIndicator uuIndicator;  /* optional; set in bit_mask
                                     * OMAP3_uuIndicator_present if present */
    OMAP3_UUI       uui;  /* optional; set in bit_mask OMAP3_uui_present if
                           * present */
    Nulltype        uusCFInteraction;  /* optional; set in bit_mask
                                        * OMAP3_uusCFInteraction_present if
                                        * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                                  * OMAP3_UU_Data_extensionContainer_present if
                                  * present */
} OMAP3_UU_Data;

typedef struct OMAP3_ResumeCallHandlingArg {
    unsigned short  bit_mask;
#       define      OMAP3_ResumeCallHandlingArg_callReferenceNumber_present 0x8000
#       define      OMAP3_ResumeCallHandlingArg_basicServiceGroup_present 0x4000
#       define      OMAP3_ResumeCallHandlingArg_forwardingData_present 0x2000
#       define      OMAP3_ResumeCallHandlingArg_imsi_present 0x1000
#       define      OMAP3_ResumeCallHandlingArg_cug_CheckInfo_present 0x0800
#       define      OMAP3_ResumeCallHandlingArg_o_CSI_present 0x0400
#       define      OMAP3_ResumeCallHandlingArg_extensionContainer_present 0x0200
#       define      OMAP3_ResumeCallHandlingArg_ccbs_Possible_present 0x0100
#       define      OMAP3_ResumeCallHandlingArg_msisdn_present 0x0080
#       define      OMAP3_uu_Data_present 0x0040
#       define      OMAP3_ResumeCallHandlingArg_allInformationSent_present 0x0020
#       define      OMAP3_ResumeCallHandlingArg_d_csi_present 0x0010
#       define      OMAP3_o_BcsmCamelTDPCriteriaList_present 0x0008
#       define      OMAP3_ResumeCallHandlingArg_basicServiceGroup2_present 0x0004
    OMAP3_CallReferenceNumber callReferenceNumber;  /* optional; set in bit_mask
                   * OMAP3_ResumeCallHandlingArg_callReferenceNumber_present if
                   * present */
    OMAP3_Ext_BasicServiceCode basicServiceGroup;  /* optional; set in bit_mask
                     * OMAP3_ResumeCallHandlingArg_basicServiceGroup_present if
                     * present */
    OMAP3_ForwardingData forwardingData;  /* optional; set in bit_mask
                        * OMAP3_ResumeCallHandlingArg_forwardingData_present if
                        * present */
    OMAP3_IMSI      imsi;  /* optional; set in bit_mask
                            * OMAP3_ResumeCallHandlingArg_imsi_present if
                            * present */
    OMAP3_CUG_CheckInfo cug_CheckInfo;  /* optional; set in bit_mask
                         * OMAP3_ResumeCallHandlingArg_cug_CheckInfo_present if
                         * present */
    OMAP3_O_CSI     o_CSI;  /* optional; set in bit_mask
                             * OMAP3_ResumeCallHandlingArg_o_CSI_present if
                             * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                    * OMAP3_ResumeCallHandlingArg_extensionContainer_present if
                    * present */
    Nulltype        ccbs_Possible;  /* optional; set in bit_mask
                         * OMAP3_ResumeCallHandlingArg_ccbs_Possible_present if
                         * present */
    OMAP3_ISDN_AddressString msisdn;  /* optional; set in bit_mask
                                * OMAP3_ResumeCallHandlingArg_msisdn_present if
                                * present */
    OMAP3_UU_Data   uu_Data;  /* optional; set in bit_mask OMAP3_uu_Data_present
                               * if present */
    Nulltype        allInformationSent;  /* optional; set in bit_mask
                    * OMAP3_ResumeCallHandlingArg_allInformationSent_present if
                    * present */
    OMAP3_D_CSI     d_csi;  /* extension #1; optional; set in bit_mask
                             * OMAP3_ResumeCallHandlingArg_d_csi_present if
                             * present */
    OMAP3_O_BcsmCamelTDPCriteriaList o_BcsmCamelTDPCriteriaList;  /* extension
                                   * #2; optional; set in bit_mask
                                   * OMAP3_o_BcsmCamelTDPCriteriaList_present if
                                   * present */
    OMAP3_Ext_BasicServiceCode basicServiceGroup2;  /* extension #3; optional;
                                   * set in bit_mask
                    * OMAP3_ResumeCallHandlingArg_basicServiceGroup2_present if
                    * present */
} OMAP3_ResumeCallHandlingArg;

	// Octets are coded according to ETS 300 356
typedef struct OMAP3_ResumeCallHandlingRes {
    unsigned char   bit_mask;
#       define      OMAP3_ResumeCallHandlingRes_extensionContainer_present 0x80
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                    * OMAP3_ResumeCallHandlingRes_extensionContainer_present if
                    * present */
} OMAP3_ResumeCallHandlingRes;

typedef enum OMAP3_ReportingState {
    OMAP3_stopMonitoring = 0,
    OMAP3_startMonitoring = 1
} OMAP3_ReportingState;

typedef struct OMAP3_SetReportingStateArg {
    unsigned char   bit_mask;
#       define      OMAP3_SetReportingStateArg_imsi_present 0x80
#       define      OMAP3_SetReportingStateArg_lmsi_present 0x40
#       define      OMAP3_ccbs_Monitoring_present 0x20
#       define      OMAP3_SetReportingStateArg_extensionContainer_present 0x10
    OMAP3_IMSI      imsi;  /* optional; set in bit_mask
                            * OMAP3_SetReportingStateArg_imsi_present if
                            * present */
    OMAP3_LMSI      lmsi;  /* optional; set in bit_mask
                            * OMAP3_SetReportingStateArg_lmsi_present if
                            * present */
    OMAP3_ReportingState ccbs_Monitoring;  /* optional; set in bit_mask
                                            * OMAP3_ccbs_Monitoring_present if
                                            * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                     * OMAP3_SetReportingStateArg_extensionContainer_present if
                     * present */
} OMAP3_SetReportingStateArg;

typedef enum OMAP3_CCBS_SubscriberStatus {
    OMAP3_ccbsNotIdle = 0,
    OMAP3_ccbsIdle = 1,
    OMAP3_ccbsNotReachable = 2
} OMAP3_CCBS_SubscriberStatus;

	// exception handling:
	// reception of values 2-10 shall be mapped to 'stopMonitoring' 
	// reception of values > 10 shall be mapped to 'startMonitoring'
typedef struct OMAP3_SetReportingStateRes {
    unsigned char   bit_mask;
#       define      OMAP3_SetReportingStateRes_ccbs_SubscriberStatus_present 0x80
#       define      OMAP3_SetReportingStateRes_extensionContainer_present 0x40
    OMAP3_CCBS_SubscriberStatus ccbs_SubscriberStatus;  /* optional; set in
                                   * bit_mask
                  * OMAP3_SetReportingStateRes_ccbs_SubscriberStatus_present if
                  * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                     * OMAP3_SetReportingStateRes_extensionContainer_present if
                     * present */
} OMAP3_SetReportingStateRes;

typedef struct OMAP3_EventReportData {
    unsigned char   bit_mask;
#       define      OMAP3_EventReportData_ccbs_SubscriberStatus_present 0x80
#       define      OMAP3_EventReportData_extensionContainer_present 0x40
    OMAP3_CCBS_SubscriberStatus ccbs_SubscriberStatus;  /* optional; set in
                                   * bit_mask
                       * OMAP3_EventReportData_ccbs_SubscriberStatus_present if
                       * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                          * OMAP3_EventReportData_extensionContainer_present if
                          * present */
} OMAP3_EventReportData;

typedef enum OMAP3_MonitoringMode {
    OMAP3_a_side = 0,
    OMAP3_b_side = 1
} OMAP3_MonitoringMode;

	//	exception handling: 
	//  reception of values 2-10 shall be mapped 'a-side'
	//  reception of values > 10 shall be mapped to 'b-side'
typedef enum OMAP3_CallOutcome {
    OMAP3_success = 0,
    OMAP3_failure = 1,
    OMAP3_CallOutcome_busy = 2
} OMAP3_CallOutcome;

typedef struct OMAP3_CallReportData {
    unsigned char   bit_mask;
#       define      OMAP3_monitoringMode_present 0x80
#       define      OMAP3_callOutcome_present 0x40
#       define      OMAP3_CallReportData_extensionContainer_present 0x20
    OMAP3_MonitoringMode monitoringMode;  /* optional; set in bit_mask
                                           * OMAP3_monitoringMode_present if
                                           * present */
    OMAP3_CallOutcome callOutcome;  /* optional; set in bit_mask
                                     * OMAP3_callOutcome_present if present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                           * OMAP3_CallReportData_extensionContainer_present if
                           * present */
} OMAP3_CallReportData;

	//  exception handling: 
	//  reception of values 3-10 shall be mapped to 'ccbsNotIdle'
	//  reception of values 11-20 shall be mapped to 'ccbsIdle'
	//  reception of values > 20 shall be mapped to 'ccbsNotReachable' 
typedef struct OMAP3_StatusReportArg {
    unsigned char   bit_mask;
#       define      OMAP3_eventReportData_present 0x80
#       define      OMAP3_callReportdata_present 0x40
#       define      OMAP3_StatusReportArg_extensionContainer_present 0x20
    OMAP3_IMSI      imsi;
    OMAP3_EventReportData eventReportData;  /* optional; set in bit_mask
                                             * OMAP3_eventReportData_present if
                                             * present */
    OMAP3_CallReportData callReportdata;  /* optional; set in bit_mask
                                           * OMAP3_callReportdata_present if
                                           * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                          * OMAP3_StatusReportArg_extensionContainer_present if
                          * present */
} OMAP3_StatusReportArg;

	//	exception handling: 
	//  reception of values 3-10 shall be mapped to 'success'
	//  reception of values 11-20 shall be mapped to 'failure'
	//  reception of values > 20 shall be mapped to 'busy'
typedef struct OMAP3_StatusReportRes {
    unsigned char   bit_mask;
#       define      OMAP3_StatusReportRes_extensionContainer_present 0x80
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                          * OMAP3_StatusReportRes_extensionContainer_present if
                          * present */
} OMAP3_StatusReportRes;

typedef unsigned short  OMAP3_CCBS_Index;

typedef struct OMAP3_CCBS_Feature {
    unsigned char   bit_mask;
#       define      OMAP3_CCBS_Feature_ccbs_Index_present 0x80
#       define      OMAP3_CCBS_Feature_b_subscriberNumber_present 0x40
#       define      OMAP3_b_subscriberSubaddress_present 0x20
#       define      OMAP3_CCBS_Feature_basicServiceGroup_present 0x10
    OMAP3_CCBS_Index ccbs_Index;  /* optional; set in bit_mask
                                   * OMAP3_CCBS_Feature_ccbs_Index_present if
                                   * present */
    OMAP3_ISDN_AddressString b_subscriberNumber;  /* optional; set in bit_mask
                             * OMAP3_CCBS_Feature_b_subscriberNumber_present if
                             * present */
    OMAP3_ISDN_SubaddressString b_subscriberSubaddress;  /* optional; set in
                                   * bit_mask
                                   * OMAP3_b_subscriberSubaddress_present if
                                   * present */
    OMAP3_BasicServiceCode basicServiceGroup;  /* optional; set in bit_mask
                              * OMAP3_CCBS_Feature_basicServiceGroup_present if
                              * present */
} OMAP3_CCBS_Feature;

typedef struct OMAP3_RemoteUserFreeArg {
    unsigned char   bit_mask;
#       define      OMAP3_replaceB_Number_present 0x80
#       define      OMAP3_RemoteUserFreeArg_alertingPattern_present 0x40
#       define      OMAP3_RemoteUserFreeArg_extensionContainer_present 0x20
    OMAP3_IMSI      imsi;
    OMAP3_ExternalSignalInfo callInfo;
    OMAP3_CCBS_Feature ccbs_Feature;
    OMAP3_ISDN_AddressString translatedB_Number;
    Nulltype        replaceB_Number;  /* optional; set in bit_mask
                                       * OMAP3_replaceB_Number_present if
                                       * present */
    OMAP3_AlertingPattern alertingPattern;  /* optional; set in bit_mask
                           * OMAP3_RemoteUserFreeArg_alertingPattern_present if
                           * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                        * OMAP3_RemoteUserFreeArg_extensionContainer_present if
                        * present */
} OMAP3_RemoteUserFreeArg;

typedef enum OMAP3_RUF_Outcome {
    OMAP3_accepted = 0,
    OMAP3_rejected = 1,
    OMAP3_noResponseFromFreeMS = 2, // T4 Expiry
    OMAP3_noResponseFromBusyMS = 3, // T10 Expiry
    OMAP3_udubFromFreeMS = 4,
    OMAP3_udubFromBusyMS = 5
} OMAP3_RUF_Outcome;

typedef struct OMAP3_RemoteUserFreeRes {
    unsigned char   bit_mask;
#       define      OMAP3_RemoteUserFreeRes_extensionContainer_present 0x80
    OMAP3_RUF_Outcome ruf_Outcome;
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                        * OMAP3_RemoteUserFreeRes_extensionContainer_present if
                        * present */
} OMAP3_RemoteUserFreeRes;

	// exception handling:
	// reception of values 6-20 shall be mapped to 'accepted'
	// reception of values 21-30 shall be mapped to 'rejected'
	// reception of values 31-40 shall be mapped to 'noResponseFromFreeMS'
	// reception of values 41-50 shall be mapped to 'noResponseFromBusyMS'
	// reception of values 51-60 shall be mapped to 'udubFromFreeMS'
	// reception of values > 60 shall be mapped to 'udubFromBusyMS'
typedef struct OMAP3_IST_AlertArg {
    unsigned char   bit_mask;
#       define      OMAP3_IST_AlertArg_extensionContainer_present 0x80
    OMAP3_IMSI      imsi;
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                             * OMAP3_IST_AlertArg_extensionContainer_present if
                             * present */
} OMAP3_IST_AlertArg;

typedef enum OMAP3_CallTerminationIndicator {
    OMAP3_terminateCallActivityReferred = 0,
    OMAP3_terminateAllCallActivities = 1
} OMAP3_CallTerminationIndicator;

typedef struct OMAP3_IST_AlertRes {
    unsigned char   bit_mask;
#       define      OMAP3_IST_AlertRes_istAlertTimer_present 0x80
#       define      OMAP3_IST_AlertRes_istInformationWithdraw_present 0x40
#       define      OMAP3_callTerminationIndicator_present 0x20
#       define      OMAP3_IST_AlertRes_extensionContainer_present 0x10
    OMAP3_IST_AlertTimerValue istAlertTimer;  /* optional; set in bit_mask
                                  * OMAP3_IST_AlertRes_istAlertTimer_present if
                                  * present */
    Nulltype        istInformationWithdraw;  /* optional; set in bit_mask
                         * OMAP3_IST_AlertRes_istInformationWithdraw_present if
                         * present */
    OMAP3_CallTerminationIndicator callTerminationIndicator;  /* optional; set
                                   * in bit_mask
                                   * OMAP3_callTerminationIndicator_present if
                                   * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                             * OMAP3_IST_AlertRes_extensionContainer_present if
                             * present */
} OMAP3_IST_AlertRes;

typedef struct OMAP3_IST_CommandArg {
    unsigned char   bit_mask;
#       define      OMAP3_IST_CommandArg_extensionContainer_present 0x80
    OMAP3_IMSI      imsi;
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                           * OMAP3_IST_CommandArg_extensionContainer_present if
                           * present */
} OMAP3_IST_CommandArg;

typedef struct OMAP3_IST_CommandRes {
    unsigned char   bit_mask;
#       define      OMAP3_IST_CommandRes_extensionContainer_present 0x80
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                           * OMAP3_IST_CommandRes_extensionContainer_present if
                           * present */
} OMAP3_IST_CommandRes;

	// exception handling:
	// reception of values 2-10 shall be mapped to ' terminateCallActivityReferred ' 
	// reception of values > 10 shall be mapped to ' terminateAllCallActivities '
	// In MSCs not supporting linkage of all call activities, any value received shall
	// be interpreted as ' terminateCallActivityReferred '
typedef struct OMAP3_ReleaseResourcesArg {
    unsigned char   bit_mask;
#       define      OMAP3_ReleaseResourcesArg_extensionContainer_present 0x80
    OMAP3_ISDN_AddressString msrn;
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                      * OMAP3_ReleaseResourcesArg_extensionContainer_present if
                      * present */
} OMAP3_ReleaseResourcesArg;

typedef struct OMAP3_ReleaseResourcesRes {
    unsigned char   bit_mask;
#       define      OMAP3_ReleaseResourcesRes_extensionContainer_present 0x80
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                      * OMAP3_ReleaseResourcesRes_extensionContainer_present if
                      * present */
} OMAP3_ReleaseResourcesRes;

typedef unsigned short  OMAP3_NoReplyConditionTime;

typedef struct OMAP3_RegisterSS_Arg {
    unsigned char   bit_mask;
#       define      OMAP3_RegisterSS_Arg_basicService_present 0x80
#       define      OMAP3_RegisterSS_Arg_forwardedToNumber_present 0x40
#       define      OMAP3_RegisterSS_Arg_forwardedToSubaddress_present 0x20
#       define      OMAP3_RegisterSS_Arg_noReplyConditionTime_present 0x10
#       define      OMAP3_RegisterSS_Arg_defaultPriority_present 0x08
#       define      OMAP3_RegisterSS_Arg_nbrUser_present 0x04
#       define      OMAP3_RegisterSS_Arg_longFTN_Supported_present 0x02
    OMAP3_SS_Code   ss_Code;
    OMAP3_BasicServiceCode basicService;  /* optional; set in bit_mask
                                 * OMAP3_RegisterSS_Arg_basicService_present if
                                 * present */
    OMAP3_AddressString forwardedToNumber;  /* optional; set in bit_mask
                            * OMAP3_RegisterSS_Arg_forwardedToNumber_present if
                            * present */
    OMAP3_ISDN_SubaddressString forwardedToSubaddress;  /* optional; set in
                                   * bit_mask
                        * OMAP3_RegisterSS_Arg_forwardedToSubaddress_present if
                        * present */
    OMAP3_NoReplyConditionTime noReplyConditionTime;  /* optional; set in
                                   * bit_mask
                         * OMAP3_RegisterSS_Arg_noReplyConditionTime_present if
                         * present */
    OMAP3_EMLPP_Priority defaultPriority;  /* extension #1; optional; set in
                                   * bit_mask
                              * OMAP3_RegisterSS_Arg_defaultPriority_present if
                              * present */
    OMAP3_MC_Bearers nbrUser;  /* extension #2; optional; set in bit_mask
                                * OMAP3_RegisterSS_Arg_nbrUser_present if
                                * present */
    Nulltype        longFTN_Supported;  /* extension #3; optional; set in
                                   * bit_mask
                            * OMAP3_RegisterSS_Arg_longFTN_Supported_present if
                            * present */
} OMAP3_RegisterSS_Arg;

typedef struct OMAP3_ForwardingFeature {
    unsigned char   bit_mask;
#       define      OMAP3_ForwardingFeature_basicService_present 0x80
#       define      OMAP3_ForwardingFeature_ss_Status_present 0x40
#       define      OMAP3_ForwardingFeature_forwardedToNumber_present 0x20
#       define      OMAP3_ForwardingFeature_forwardedToSubaddress_present 0x10
#       define      OMAP3_ForwardingFeature_forwardingOptions_present 0x08
#       define      OMAP3_ForwardingFeature_noReplyConditionTime_present 0x04
#       define      OMAP3_ForwardingFeature_longForwardedToNumber_present 0x02
    OMAP3_BasicServiceCode basicService;  /* optional; set in bit_mask
                              * OMAP3_ForwardingFeature_basicService_present if
                              * present */
    OMAP3_SS_DataTypes_SS_Status ss_Status;  /* optional; set in bit_mask
                                 * OMAP3_ForwardingFeature_ss_Status_present if
                                 * present */
    OMAP3_ISDN_AddressString forwardedToNumber;  /* optional; set in bit_mask
                         * OMAP3_ForwardingFeature_forwardedToNumber_present if
                         * present */
    OMAP3_ISDN_SubaddressString forwardedToSubaddress;  /* optional; set in
                                   * bit_mask
                     * OMAP3_ForwardingFeature_forwardedToSubaddress_present if
                     * present */
    OMAP3_ForwardingOptions forwardingOptions;  /* optional; set in bit_mask
                         * OMAP3_ForwardingFeature_forwardingOptions_present if
                         * present */
    OMAP3_NoReplyConditionTime noReplyConditionTime;  /* optional; set in
                                   * bit_mask
                      * OMAP3_ForwardingFeature_noReplyConditionTime_present if
                      * present */
    OMAP3_FTN_AddressString longForwardedToNumber;  /* extension #1; optional;
                                   * set in bit_mask
                     * OMAP3_ForwardingFeature_longForwardedToNumber_present if
                     * present */
} OMAP3_ForwardingFeature;

typedef struct OMAP3_ForwardingFeatureList {
    unsigned short  count;
    OMAP3_ForwardingFeature value[13];
} OMAP3_ForwardingFeatureList;

typedef struct OMAP3_ForwardingInfo {
    unsigned char   bit_mask;
#       define      OMAP3_ForwardingInfo_ss_Code_present 0x80
    OMAP3_SS_Code   ss_Code;  /* optional; set in bit_mask
                               * OMAP3_ForwardingInfo_ss_Code_present if
                               * present */
    OMAP3_ForwardingFeatureList forwardingFeatureList;
} OMAP3_ForwardingInfo;

typedef struct OMAP3_CallBarringFeature {
    unsigned char   bit_mask;
#       define      OMAP3_CallBarringFeature_basicService_present 0x80
#       define      OMAP3_CallBarringFeature_ss_Status_present 0x40
    OMAP3_BasicServiceCode basicService;  /* optional; set in bit_mask
                             * OMAP3_CallBarringFeature_basicService_present if
                             * present */
    OMAP3_SS_DataTypes_SS_Status ss_Status;  /* optional; set in bit_mask
                                * OMAP3_CallBarringFeature_ss_Status_present if
                                * present */
} OMAP3_CallBarringFeature;

typedef struct OMAP3_CallBarringFeatureList {
    unsigned short  count;
    OMAP3_CallBarringFeature value[13];
} OMAP3_CallBarringFeatureList;

	// bit 8: notification to forwarding party
	//	0  no notification
	//	1  notification

	// bit 7: redirecting presentation
	//	0 no presentation  
	//	1  presentation

	// bit 6: notification to calling party
	//	0  no notification
	//	1  notification

	// bit 5: 0 (unused)

	// bits 43: forwarding reason
	//	00  ms not reachable
	//	01  ms busy
	//	10  no reply
	//	11  unconditional when used in a SRI Result, 
	//	    or call deflection when used in a RCH Argument
	// bits 21: 00 (unused)
typedef struct OMAP3_CallBarringInfo {
    unsigned char   bit_mask;
#       define      OMAP3_CallBarringInfo_ss_Code_present 0x80
    OMAP3_SS_Code   ss_Code;  /* optional; set in bit_mask
                               * OMAP3_CallBarringInfo_ss_Code_present if
                               * present */
    OMAP3_CallBarringFeatureList callBarringFeatureList;
} OMAP3_CallBarringInfo;

typedef enum OMAP3_CliRestrictionOption {
    OMAP3_permanent = 0,
    OMAP3_temporaryDefaultRestricted = 1,
    OMAP3_temporaryDefaultAllowed = 2
} OMAP3_CliRestrictionOption;

typedef enum OMAP3_OverrideCategory {
    OMAP3_overrideEnabled = 0,
    OMAP3_overrideDisabled = 1
} OMAP3_OverrideCategory;

typedef struct OMAP3_SS_SubscriptionOption {
    unsigned short  choice;
#       define      OMAP3_cliRestrictionOption_chosen 1
#       define      OMAP3_overrideCategory_chosen 2
    union _union {
        OMAP3_CliRestrictionOption cliRestrictionOption;  /* to choose, set
                                   * choice to
                                   * OMAP3_cliRestrictionOption_chosen */
        OMAP3_OverrideCategory overrideCategory;  /* to choose, set choice to
                                             * OMAP3_overrideCategory_chosen */
    } u;
} OMAP3_SS_SubscriptionOption;

typedef struct OMAP3_BasicServiceGroupList {
    unsigned short  count;
    OMAP3_BasicServiceCode value[13];
} OMAP3_BasicServiceGroupList;

typedef struct OMAP3_SS_Data {
    unsigned char   bit_mask;
#       define      OMAP3_SS_Data_ss_Code_present 0x80
#       define      OMAP3_SS_Data_ss_Status_present 0x40
#       define      OMAP3_SS_Data_ss_SubscriptionOption_present 0x20
#       define      OMAP3_SS_Data_basicServiceGroupList_present 0x10
#       define      OMAP3_SS_Data_defaultPriority_present 0x08
#       define      OMAP3_SS_Data_nbrUser_present 0x04
    OMAP3_SS_Code   ss_Code;  /* optional; set in bit_mask
                               * OMAP3_SS_Data_ss_Code_present if present */
    OMAP3_SS_DataTypes_SS_Status ss_Status;  /* optional; set in bit_mask
                                              * OMAP3_SS_Data_ss_Status_present
                                              * if present */
    OMAP3_SS_SubscriptionOption ss_SubscriptionOption;  /* optional; set in
                                   * bit_mask
                                   * OMAP3_SS_Data_ss_SubscriptionOption_present
                                   * if present */
    OMAP3_BasicServiceGroupList basicServiceGroupList;  /* optional; set in
                                   * bit_mask
                                   * OMAP3_SS_Data_basicServiceGroupList_present
                                   * if present */
    OMAP3_EMLPP_Priority defaultPriority;  /* extension #1; optional; set in
                                   * bit_mask
                                   * OMAP3_SS_Data_defaultPriority_present if
                                   * present */
    OMAP3_MC_Bearers nbrUser;  /* extension #2; optional; set in bit_mask
                                * OMAP3_SS_Data_nbrUser_present if present */
} OMAP3_SS_Data;

typedef struct OMAP3_SS_Info {
    unsigned short  choice;
#       define      OMAP3_SS_Info_forwardingInfo_chosen 1
#       define      OMAP3_SS_Info_callBarringInfo_chosen 2
#       define      OMAP3_SS_Info_ss_Data_chosen 3
    union _union {
        OMAP3_ForwardingInfo forwardingInfo;  /* to choose, set choice to
                                       * OMAP3_SS_Info_forwardingInfo_chosen */
        OMAP3_CallBarringInfo callBarringInfo;  /* to choose, set choice to
                                      * OMAP3_SS_Info_callBarringInfo_chosen */
        OMAP3_SS_Data   ss_Data;  /* to choose, set choice to
                                   * OMAP3_SS_Info_ss_Data_chosen */
    } u;
} OMAP3_SS_Info;

typedef struct OMAP3_SS_ForBS_Code {
    unsigned char   bit_mask;
#       define      OMAP3_SS_ForBS_Code_basicService_present 0x80
#       define      OMAP3_SS_ForBS_Code_longFTN_Supported_present 0x40
    OMAP3_SS_Code   ss_Code;
    OMAP3_BasicServiceCode basicService;  /* optional; set in bit_mask
                                  * OMAP3_SS_ForBS_Code_basicService_present if
                                  * present */
    Nulltype        longFTN_Supported;  /* extension #1; optional; set in
                                   * bit_mask
                             * OMAP3_SS_ForBS_Code_longFTN_Supported_present if
                             * present */
} OMAP3_SS_ForBS_Code;

typedef struct OMAP3_CCBS_FeatureList {
    unsigned short  count;
    OMAP3_CCBS_Feature value[5];
} OMAP3_CCBS_FeatureList;

typedef struct OMAP3_GenericServiceInfo {
    unsigned char   bit_mask;
#       define      OMAP3_cliRestrictionOption_present 0x80
#       define      OMAP3_maximumEntitledPriority_present 0x40
#       define      OMAP3_GenericServiceInfo_defaultPriority_present 0x20
#       define      OMAP3_ccbs_FeatureList_present 0x10
#       define      OMAP3_nbrSB_present 0x08
#       define      OMAP3_GenericServiceInfo_nbrUser_present 0x04
#       define      OMAP3_nbrSN_present 0x02
    OMAP3_SS_DataTypes_SS_Status ss_Status;
    OMAP3_CliRestrictionOption cliRestrictionOption;  /* optional; set in
                                   * bit_mask OMAP3_cliRestrictionOption_present
                                   * if present */
    OMAP3_EMLPP_Priority maximumEntitledPriority;  /* extension #1; optional;
                                   * set in bit_mask
                                   * OMAP3_maximumEntitledPriority_present if
                                   * present */
    OMAP3_EMLPP_Priority defaultPriority;  /* extension #2; optional; set in
                                   * bit_mask
                          * OMAP3_GenericServiceInfo_defaultPriority_present if
                          * present */
    OMAP3_CCBS_FeatureList ccbs_FeatureList;  /* extension #3; optional; set in
                                   * bit_mask OMAP3_ccbs_FeatureList_present if
                                   * present */
    OMAP3_MaxMC_Bearers nbrSB;  /* extension #4; optional; set in bit_mask
                                 * OMAP3_nbrSB_present if present */
    OMAP3_MC_Bearers nbrUser;  /* extension #5; optional; set in bit_mask
                                * OMAP3_GenericServiceInfo_nbrUser_present if
                                * present */
    OMAP3_MC_Bearers nbrSN;  /* extension #6; optional; set in bit_mask
                              * OMAP3_nbrSN_present if present */
} OMAP3_GenericServiceInfo;

typedef struct OMAP3_InterrogateSS_Res {
    unsigned short  choice;
#       define      OMAP3_ss_Status_chosen 1
#       define      OMAP3_basicServiceGroupList_chosen 2
#       define      OMAP3_forwardingFeatureList_chosen 3
#       define      OMAP3_genericServiceInfo_chosen 4
    union _union {
        OMAP3_SS_DataTypes_SS_Status ss_Status;  /* to choose, set choice to
                                                  * OMAP3_ss_Status_chosen */
        OMAP3_BasicServiceGroupList basicServiceGroupList;  /* to choose, set
                                   * choice to
                                   * OMAP3_basicServiceGroupList_chosen */
        OMAP3_ForwardingFeatureList forwardingFeatureList;  /* to choose, set
                                   * choice to
                                   * OMAP3_forwardingFeatureList_chosen */
        OMAP3_GenericServiceInfo genericServiceInfo;  /* to choose, set choice
                                        * to OMAP3_genericServiceInfo_chosen */
    } u;
} OMAP3_InterrogateSS_Res;

	// The structure of the USSD-DataCodingScheme is defined by
	// the Cell Broadcast Data Coding Scheme as described in
	// TS 3GPP TS 23.038 [25]
typedef struct OMAP3_USSD_String {
    unsigned short  length;
    unsigned char   value[160];
} OMAP3_USSD_String;

typedef struct OMAP3_USSD_Arg {
    unsigned char   bit_mask;
#       define      OMAP3_USSD_Arg_alertingPattern_present 0x80
#       define      OMAP3_USSD_Arg_msisdn_present 0x40
    OMAP3_USSD_DataCodingScheme ussd_DataCodingScheme;
    OMAP3_USSD_String ussd_String;
    OMAP3_AlertingPattern alertingPattern;  /* extension #1; optional; set in
                                   * bit_mask
                                   * OMAP3_USSD_Arg_alertingPattern_present if
                                   * present */
    OMAP3_ISDN_AddressString msisdn;  /* extension #2; optional; set in bit_mask
                                       * OMAP3_USSD_Arg_msisdn_present if
                                       * present */
} OMAP3_USSD_Arg;

typedef struct OMAP3_USSD_Res {
    OMAP3_USSD_DataCodingScheme ussd_DataCodingScheme;
    OMAP3_USSD_String ussd_String;
} OMAP3_USSD_Res;

typedef struct OMAP3_SS_InfoList {
    unsigned short  count;
    OMAP3_SS_Info   value[30];
} OMAP3_SS_InfoList;

typedef struct OMAP3_SS_EventSpecification {
    unsigned short  count;
    OMAP3_AddressString value[2];
} OMAP3_SS_EventSpecification;

typedef enum OMAP3_CCBS_RequestState {
    OMAP3_request = 0,
    OMAP3_recall = 1,
    OMAP3_active = 2,
    OMAP3_completed = 3,
    OMAP3_suspended = 4,
    OMAP3_frozen = 5,
    OMAP3_deleted = 6
} OMAP3_CCBS_RequestState;

typedef struct OMAP3_SS_InvocationNotificationArg {
    unsigned char   bit_mask;
#       define      OMAP3_ss_EventSpecification_present 0x80
#       define      OMAP3_SS_InvocationNotificationArg_extensionContainer_present 0x40
#       define      OMAP3_SS_InvocationNotificationArg_b_subscriberNumber_present 0x20
#       define      OMAP3_ccbs_RequestState_present 0x10
    OMAP3_IMSI      imsi;
    OMAP3_ISDN_AddressString msisdn;
    OMAP3_SS_Code   ss_Event;
	// The following SS-Code values are allowed :
	// ect		SS-Code ::= '00110001'B
	// multiPTY	SS-Code ::= '01010001'B
	// cd		SS-Code ::= '00100100'B
	// ccbs		SS-Code ::= '01000100'B
    OMAP3_SS_EventSpecification ss_EventSpecification;  /* optional; set in
                                   * bit_mask
                                   * OMAP3_ss_EventSpecification_present if
                                   * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
             * OMAP3_SS_InvocationNotificationArg_extensionContainer_present if
             * present */
    OMAP3_ISDN_AddressString b_subscriberNumber;  /* extension #1; optional; set
                                   * in bit_mask
             * OMAP3_SS_InvocationNotificationArg_b_subscriberNumber_present if
             * present */
    OMAP3_CCBS_RequestState ccbs_RequestState;  /* extension #2; optional; set
                                   * in bit_mask OMAP3_ccbs_RequestState_present
                                   * if present */
} OMAP3_SS_InvocationNotificationArg;

typedef struct OMAP3_SS_InvocationNotificationRes {
    unsigned char   bit_mask;
#       define      OMAP3_SS_InvocationNotificationRes_extensionContainer_present 0x80
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
             * OMAP3_SS_InvocationNotificationRes_extensionContainer_present if
             * present */
} OMAP3_SS_InvocationNotificationRes;

typedef struct OMAP3_ServiceIndicator {
    unsigned short  length;  /* number of significant bits */
    unsigned char   value[4];
} OMAP3_ServiceIndicator;
#define                     OMAP3_clir_invoked 0x80
#define                     OMAP3_clir_invoked_byte 0
#define                     OMAP3_camel_invoked 0x40
#define                     OMAP3_camel_invoked_byte 0

typedef struct OMAP3_CCBS_Data {
    unsigned char   bit_mask;
#       define      OMAP3_serviceIndicator_present 0x80
    OMAP3_CCBS_Feature ccbs_Feature;
    OMAP3_ISDN_AddressString translatedB_Number;
    OMAP3_ServiceIndicator serviceIndicator;  /* optional; set in bit_mask
                                               * OMAP3_serviceIndicator_present
                                               * if present */
    OMAP3_ExternalSignalInfo callInfo;
    OMAP3_ExternalSignalInfo networkSignalInfo;
} OMAP3_CCBS_Data;

typedef struct OMAP3_RegisterCC_EntryArg {
    unsigned char   bit_mask;
#       define      OMAP3_ccbs_Data_present 0x80
    OMAP3_SS_Code   ss_Code;
    OMAP3_CCBS_Data ccbs_Data;  /* optional; set in bit_mask
                                 * OMAP3_ccbs_Data_present if present */
} OMAP3_RegisterCC_EntryArg;

	// exception handling:
	// bits 2 to 31 shall be ignored if received and not understood
typedef struct OMAP3_RegisterCC_EntryRes {
    unsigned char   bit_mask;
#       define      OMAP3_ccbs_Feature_present 0x80
    OMAP3_CCBS_Feature ccbs_Feature;  /* optional; set in bit_mask
                                       * OMAP3_ccbs_Feature_present if
                                       * present */
} OMAP3_RegisterCC_EntryRes;

typedef struct OMAP3_EraseCC_EntryArg {
    unsigned char   bit_mask;
#       define      OMAP3_EraseCC_EntryArg_ccbs_Index_present 0x80
    OMAP3_SS_Code   ss_Code;
    OMAP3_CCBS_Index ccbs_Index;  /* optional; set in bit_mask
                                   * OMAP3_EraseCC_EntryArg_ccbs_Index_present
                                   * if present */
} OMAP3_EraseCC_EntryArg;

typedef struct OMAP3_EraseCC_EntryRes {
    unsigned char   bit_mask;
#       define      OMAP3_EraseCC_EntryRes_ss_Status_present 0x80
    OMAP3_SS_Code   ss_Code;
    OMAP3_SS_DataTypes_SS_Status ss_Status;  /* optional; set in bit_mask
                                  * OMAP3_EraseCC_EntryRes_ss_Status_present if
                                  * present */
} OMAP3_EraseCC_EntryRes;

typedef unsigned short  OMAP3_SM_RP_MTI;

	// 0 SMS Deliver 
	// 1 SMS Status Report
	// other values are reserved for future use and shall be discarded if
	// received
typedef struct OMAP3_SM_RP_SMEA {
    unsigned short  length;
    unsigned char   value[12];
} OMAP3_SM_RP_SMEA;

typedef enum OMAP3__enum1 {
    OMAP3_onlyIMSI_requested = 0,
    OMAP3_onlyMCC_MNC_requested = 1
} OMAP3__enum1;

typedef struct OMAP3_RoutingInfoForSM_Arg {
    unsigned char   bit_mask;
#       define      OMAP3_RoutingInfoForSM_Arg_extensionContainer_present 0x80
#       define      OMAP3_RoutingInfoForSM_Arg_gprsSupportIndicator_present 0x40
#       define      OMAP3_sm_RP_MTI_present 0x20
#       define      OMAP3_sm_RP_SMEA_present 0x10
#       define      OMAP3_sm_deliveryNotIntended_present 0x08
    OMAP3_ISDN_AddressString msisdn;
    ossBoolean      sm_RP_PRI;
    OMAP3_AddressString serviceCentreAddress;
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                     * OMAP3_RoutingInfoForSM_Arg_extensionContainer_present if
                     * present */
    Nulltype        gprsSupportIndicator;  /* extension #1; optional; set in
                                   * bit_mask
                   * OMAP3_RoutingInfoForSM_Arg_gprsSupportIndicator_present if
                   * present */
	// gprsSupportIndicator is set only if the SMS-GMSC supports
	// receiving of two numbers from the HLR
    OMAP3_SM_RP_MTI sm_RP_MTI;  /* extension #2; optional; set in bit_mask
                                 * OMAP3_sm_RP_MTI_present if present */
    OMAP3_SM_RP_SMEA sm_RP_SMEA;  /* extension #3; optional; set in bit_mask
                                   * OMAP3_sm_RP_SMEA_present if present */
    OMAP3__enum1    sm_deliveryNotIntended;  /* extension #4; optional; set in
                                   * bit_mask
                                   * OMAP3_sm_deliveryNotIntended_present if
                                   * present */
} OMAP3_RoutingInfoForSM_Arg;

typedef struct OMAP3_LocationInfoWithLMSI {
    unsigned char   bit_mask;
#       define      OMAP3_LocationInfoWithLMSI_lmsi_present 0x80
#       define      OMAP3_LocationInfoWithLMSI_extensionContainer_present 0x40
#       define      OMAP3_LocationInfoWithLMSI_gprsNodeIndicator_present 0x20
#       define      OMAP3_LocationInfoWithLMSI_additional_Number_present 0x10
    OMAP3_ISDN_AddressString networkNode_Number;
    OMAP3_LMSI      lmsi;  /* optional; set in bit_mask
                            * OMAP3_LocationInfoWithLMSI_lmsi_present if
                            * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                     * OMAP3_LocationInfoWithLMSI_extensionContainer_present if
                     * present */
    Nulltype        gprsNodeIndicator;  /* extension #1; optional; set in
                                   * bit_mask
                      * OMAP3_LocationInfoWithLMSI_gprsNodeIndicator_present if
                      * present */
	// gprsNodeIndicator is set only if the SGSN number is sent as the 
	// Network Node Number
    OMAP3_Additional_Number additional_Number;  /* extension #2; optional; set
                                   * in bit_mask
                      * OMAP3_LocationInfoWithLMSI_additional_Number_present if
                      * present */
	// NetworkNode-number can be either msc-number or sgsn-number
} OMAP3_LocationInfoWithLMSI;

	// this parameter contains an address field which is encoded 
	// as defined in 3GPP TS 23.040. An address field contains 3 elements :
	// 		address-length
	// 		type-of-address
	// 		address-value
typedef struct OMAP3_RoutingInfoForSM_Res {
    unsigned char   bit_mask;
#       define      OMAP3_RoutingInfoForSM_Res_extensionContainer_present 0x80
    OMAP3_IMSI      imsi;
    OMAP3_LocationInfoWithLMSI locationInfoWithLMSI;
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                     * OMAP3_RoutingInfoForSM_Res_extensionContainer_present if
                     * present */
} OMAP3_RoutingInfoForSM_Res;

typedef struct OMAP3_SM_RP_DA {
    unsigned short  choice;
#       define      OMAP3_SM_RP_DA_imsi_chosen 1
#       define      OMAP3_lmsi_chosen 2
#       define      OMAP3_serviceCentreAddressDA_chosen 3
#       define      OMAP3_noSM_RP_DA_chosen 4
    union _union {
        OMAP3_IMSI      imsi;  /* to choose, set choice to
                                * OMAP3_SM_RP_DA_imsi_chosen */
        OMAP3_LMSI      lmsi;  /* to choose, set choice to OMAP3_lmsi_chosen */
        OMAP3_AddressString serviceCentreAddressDA;  /* to choose, set choice to
                                       * OMAP3_serviceCentreAddressDA_chosen */
        Nulltype        noSM_RP_DA;  /* to choose, set choice to
                                      * OMAP3_noSM_RP_DA_chosen */
    } u;
} OMAP3_SM_RP_DA;

typedef struct OMAP3_SM_RP_OA {
    unsigned short  choice;
#       define      OMAP3_SM_RP_OA_msisdn_chosen 1
#       define      OMAP3_serviceCentreAddressOA_chosen 2
#       define      OMAP3_noSM_RP_OA_chosen 3
    union _union {
        OMAP3_ISDN_AddressString msisdn;  /* to choose, set choice to
                                           * OMAP3_SM_RP_OA_msisdn_chosen */
        OMAP3_AddressString serviceCentreAddressOA;  /* to choose, set choice to
                                       * OMAP3_serviceCentreAddressOA_chosen */
        Nulltype        noSM_RP_OA;  /* to choose, set choice to
                                      * OMAP3_noSM_RP_OA_chosen */
    } u;
} OMAP3_SM_RP_OA;

	// additional-number can be either msc-number or sgsn-number
	// if received networkNode-number is msc-number then the 	
	// additional number is sgsn-number 
	// if received networkNode-number is sgsn-number then the 
	// additional number is msc-number 
typedef struct OMAP3_MO_ForwardSM_Arg {
    unsigned char   bit_mask;
#       define      OMAP3_MO_ForwardSM_Arg_extensionContainer_present 0x80
#       define      OMAP3_MO_ForwardSM_Arg_imsi_present 0x40
    OMAP3_SM_RP_DA  sm_RP_DA;
    OMAP3_SM_RP_OA  sm_RP_OA;
    OMAP3_SignalInfo sm_RP_UI;
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                         * OMAP3_MO_ForwardSM_Arg_extensionContainer_present if
                         * present */
    OMAP3_IMSI      imsi;  /* extension #1; optional; set in bit_mask
                            * OMAP3_MO_ForwardSM_Arg_imsi_present if present */
} OMAP3_MO_ForwardSM_Arg;

typedef struct OMAP3_MO_ForwardSM_Res {
    unsigned char   bit_mask;
#       define      OMAP3_MO_ForwardSM_Res_sm_RP_UI_present 0x80
#       define      OMAP3_MO_ForwardSM_Res_extensionContainer_present 0x40
    OMAP3_SignalInfo sm_RP_UI;  /* optional; set in bit_mask
                                 * OMAP3_MO_ForwardSM_Res_sm_RP_UI_present if
                                 * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                         * OMAP3_MO_ForwardSM_Res_extensionContainer_present if
                         * present */
} OMAP3_MO_ForwardSM_Res;

typedef struct OMAP3_MT_ForwardSM_Arg {
    unsigned char   bit_mask;
#       define      OMAP3_moreMessagesToSend_present 0x80
#       define      OMAP3_MT_ForwardSM_Arg_extensionContainer_present 0x40
    OMAP3_SM_RP_DA  sm_RP_DA;
    OMAP3_SM_RP_OA  sm_RP_OA;
    OMAP3_SignalInfo sm_RP_UI;
    Nulltype        moreMessagesToSend;  /* optional; set in bit_mask
                                          * OMAP3_moreMessagesToSend_present if
                                          * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                         * OMAP3_MT_ForwardSM_Arg_extensionContainer_present if
                         * present */
} OMAP3_MT_ForwardSM_Arg;

typedef struct OMAP3_MT_ForwardSM_Res {
    unsigned char   bit_mask;
#       define      OMAP3_MT_ForwardSM_Res_sm_RP_UI_present 0x80
#       define      OMAP3_MT_ForwardSM_Res_extensionContainer_present 0x40
    OMAP3_SignalInfo sm_RP_UI;  /* optional; set in bit_mask
                                 * OMAP3_MT_ForwardSM_Res_sm_RP_UI_present if
                                 * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                         * OMAP3_MT_ForwardSM_Res_extensionContainer_present if
                         * present */
} OMAP3_MT_ForwardSM_Res;

typedef enum OMAP3_SM_DeliveryOutcome {
    OMAP3_SM_DeliveryOutcome_memoryCapacityExceeded = 0,
    OMAP3_SM_DeliveryOutcome_absentSubscriber = 1,
    OMAP3_SM_DeliveryOutcome_successfulTransfer = 2
} OMAP3_SM_DeliveryOutcome;

typedef enum OMAP3__enum2 {
    OMAP3_ip_sm_gw_sm_deliveryOutcome_memoryCapacityExceeded = 0,
    OMAP3_ip_sm_gw_sm_deliveryOutcome_absentSubscriber = 1,
    OMAP3_ip_sm_gw_sm_deliveryOutcome_successfulTransfer = 2
} OMAP3__enum2;

typedef struct OMAP3_ReportSM_DeliveryStatusArg {
    unsigned short  bit_mask;
#       define      OMAP3_ReportSM_DeliveryStatusArg_absentSubscriberDiagnosticSM_present 0x8000
#       define      OMAP3_ReportSM_DeliveryStatusArg_extensionContainer_present 0x4000
#       define      OMAP3_ReportSM_DeliveryStatusArg_gprsSupportIndicator_present 0x2000
#       define      OMAP3_deliveryOutcomeIndicator_present 0x1000
#       define      OMAP3_additionalSM_DeliveryOutcome_present 0x0800
#       define      OMAP3_ReportSM_DeliveryStatusArg_additionalAbsentSubscriberDiagnosticSM_present 0x0400
#       define      OMAP3_ip_sm_gw_Indicator_present 0x0200
#       define      OMAP3_ip_sm_gw_sm_deliveryOutcome_present 0x0100
#       define      OMAP3_ip_sm_gw_absentSubscriberDiagnosticSM_present 0x0080
    OMAP3_ISDN_AddressString msisdn;
    OMAP3_AddressString serviceCentreAddress;
    OMAP3_SM_DeliveryOutcome sm_DeliveryOutcome;
    OMAP3_AbsentSubscriberDiagnosticSM absentSubscriberDiagnosticSM;  
                                  /* optional; set in bit_mask
     * OMAP3_ReportSM_DeliveryStatusArg_absentSubscriberDiagnosticSM_present if
     * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
               * OMAP3_ReportSM_DeliveryStatusArg_extensionContainer_present if
               * present */
    Nulltype        gprsSupportIndicator;  /* extension #1; optional; set in
                                   * bit_mask
             * OMAP3_ReportSM_DeliveryStatusArg_gprsSupportIndicator_present if
             * present */
	// gprsSupportIndicator is set only if the SMS-GMSC supports 
	// handling of two delivery outcomes
    Nulltype        deliveryOutcomeIndicator;  /* extension #2; optional; set in
                                   * bit_mask
                                   * OMAP3_deliveryOutcomeIndicator_present if
                                   * present */
	// DeliveryOutcomeIndicator is set when the SM-DeliveryOutcome
	// is for GPRS
    OMAP3_SM_DeliveryOutcome additionalSM_DeliveryOutcome;  /* extension #3;
                                   * optional; set in bit_mask
                                   * OMAP3_additionalSM_DeliveryOutcome_present
                                   * if present */
	// If received, additionalSM-DeliveryOutcome is for GPRS
	// If DeliveryOutcomeIndicator is set, then AdditionalSM-DeliveryOutcome shall be absent
    OMAP3_AbsentSubscriberDiagnosticSM additionalAbsentSubscriberDiagnosticSM;                                          /* extension #4; optional; set in
                                   * bit_mask
       * OMAP3_ReportSM_DeliveryStatusArg_additionalAbsentSubscriberDiagnosticSM_present if
       * present */
	// If received additionalAbsentSubscriberDiagnosticSM is for GPRS
	// If DeliveryOutcomeIndicator is set, then AdditionalAbsentSubscriberDiagnosticSM 
	// shall be absent
    Nulltype        ip_sm_gw_Indicator;  /* extension #5; optional; set in
                                   * bit_mask OMAP3_ip_sm_gw_Indicator_present
                                   * if present */
    OMAP3__enum2    ip_sm_gw_sm_deliveryOutcome;  /* extension #6; optional; set
                                   * in bit_mask
                                   * OMAP3_ip_sm_gw_sm_deliveryOutcome_present
                                   * if present */
    unsigned short  ip_sm_gw_absentSubscriberDiagnosticSM;  /* extension #7;
                                   * optional; set in bit_mask
                       * OMAP3_ip_sm_gw_absentSubscriberDiagnosticSM_present if
                       * present */
} OMAP3_ReportSM_DeliveryStatusArg;

typedef struct OMAP3_ReportSM_DeliveryStatusRes {
    unsigned char   bit_mask;
#       define      OMAP3_ReportSM_DeliveryStatusRes_storedMSISDN_present 0x80
#       define      OMAP3_ReportSM_DeliveryStatusRes_extensionContainer_present 0x40
    OMAP3_ISDN_AddressString storedMSISDN;  /* optional; set in bit_mask
                     * OMAP3_ReportSM_DeliveryStatusRes_storedMSISDN_present if
                     * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
               * OMAP3_ReportSM_DeliveryStatusRes_extensionContainer_present if
               * present */
} OMAP3_ReportSM_DeliveryStatusRes;

typedef struct OMAP3_AlertServiceCentreArg {
    OMAP3_ISDN_AddressString msisdn;
    OMAP3_AddressString serviceCentreAddress;
} OMAP3_AlertServiceCentreArg;

	// additionalAbsentSubscriberDiagnosticSM may be present only if 
	// absentSubscriberDiagnosticSM is present.
	// if included, additionalAbsentSubscriberDiagnosticSM is for GPRS and
	// absentSubscriberDiagnosticSM is for non-GPRS
typedef struct OMAP3_MW_Status {
    unsigned short  length;  /* number of significant bits */
    unsigned char   value[2];
} OMAP3_MW_Status;
#define                     OMAP3_sc_AddressNotIncluded 0x80
#define                     OMAP3_sc_AddressNotIncluded_byte 0
#define                     OMAP3_mnrf_Set 0x40
#define                     OMAP3_mnrf_Set_byte 0
#define                     OMAP3_mcef_Set 0x20
#define                     OMAP3_mcef_Set_byte 0
#define                     OMAP3_mnrg_Set 0x10
#define                     OMAP3_mnrg_Set_byte 0

typedef struct OMAP3_InformServiceCentreArg {
    unsigned char   bit_mask;
#       define      OMAP3_InformServiceCentreArg_storedMSISDN_present 0x80
#       define      OMAP3_mw_Status_present 0x40
#       define      OMAP3_InformServiceCentreArg_extensionContainer_present 0x20
#       define      OMAP3_InformServiceCentreArg_absentSubscriberDiagnosticSM_present 0x10
#       define      OMAP3_InformServiceCentreArg_additionalAbsentSubscriberDiagnosticSM_present 0x08
    OMAP3_ISDN_AddressString storedMSISDN;  /* optional; set in bit_mask
                         * OMAP3_InformServiceCentreArg_storedMSISDN_present if
                         * present */
    OMAP3_MW_Status mw_Status;  /* optional; set in bit_mask
                                 * OMAP3_mw_Status_present if present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                   * OMAP3_InformServiceCentreArg_extensionContainer_present if
                   * present */
    OMAP3_AbsentSubscriberDiagnosticSM absentSubscriberDiagnosticSM;  
                                  /* extension #1; optional; set in bit_mask
         * OMAP3_InformServiceCentreArg_absentSubscriberDiagnosticSM_present if
         * present */
    OMAP3_AbsentSubscriberDiagnosticSM additionalAbsentSubscriberDiagnosticSM;                                          /* extension #2; optional; set in
                                   * bit_mask
   * OMAP3_InformServiceCentreArg_additionalAbsentSubscriberDiagnosticSM_present if
   * present */
} OMAP3_InformServiceCentreArg;

typedef enum OMAP3_AlertReason {
    OMAP3_ms_Present = 0,
    OMAP3_memoryAvailable = 1
} OMAP3_AlertReason;

	// exception handling:
	// bits 4 to 15 shall be ignored if received and not understood
typedef struct OMAP3_ReadyForSM_Arg {
    unsigned char   bit_mask;
#       define      OMAP3_alertReasonIndicator_present 0x80
#       define      OMAP3_ReadyForSM_Arg_extensionContainer_present 0x40
#       define      OMAP3_additionalAlertReasonIndicator_present 0x20
    OMAP3_IMSI      imsi;
    OMAP3_AlertReason alertReason;
    Nulltype        alertReasonIndicator;  /* optional; set in bit_mask
                                            * OMAP3_alertReasonIndicator_present
                                            * if present */
	// alertReasonIndicator is set only when the alertReason 
	// sent to HLR is for GPRS
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                           * OMAP3_ReadyForSM_Arg_extensionContainer_present if
                           * present */
    Nulltype        additionalAlertReasonIndicator;  /* extension #1; optional;
                                   * set in bit_mask
                              * OMAP3_additionalAlertReasonIndicator_present if
                              * present */
} OMAP3_ReadyForSM_Arg;

typedef struct OMAP3_ReadyForSM_Res {
    unsigned char   bit_mask;
#       define      OMAP3_ReadyForSM_Res_extensionContainer_present 0x80
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                           * OMAP3_ReadyForSM_Res_extensionContainer_present if
                           * present */
} OMAP3_ReadyForSM_Res;

typedef struct OMAP3_MT_ForwardSM_VGCS_Arg {
    unsigned char   bit_mask;
#       define      OMAP3_MT_ForwardSM_VGCS_Arg_extensionContainer_present 0x80
    OMAP3_ASCI_CallReference asciCallReference;
    OMAP3_SM_RP_OA  sm_RP_OA;
    OMAP3_SignalInfo sm_RP_UI;
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                    * OMAP3_MT_ForwardSM_VGCS_Arg_extensionContainer_present if
                    * present */
} OMAP3_MT_ForwardSM_VGCS_Arg;

typedef struct OMAP3_DispatcherList {
    unsigned short  count;
    OMAP3_ISDN_AddressString value[5];
} OMAP3_DispatcherList;

typedef struct OMAP3_MT_ForwardSM_VGCS_Res {
    unsigned char   bit_mask;
#       define      OMAP3_MT_ForwardSM_VGCS_Res_sm_RP_UI_present 0x80
#       define      OMAP3_dispatcherList_present 0x40
#       define      OMAP3_ongoingCall_present 0x20
#       define      OMAP3_MT_ForwardSM_VGCS_Res_extensionContainer_present 0x10
    OMAP3_SignalInfo sm_RP_UI;  /* optional; set in bit_mask
                                 * OMAP3_MT_ForwardSM_VGCS_Res_sm_RP_UI_present
                                 * if present */
    OMAP3_DispatcherList dispatcherList;  /* optional; set in bit_mask
                                           * OMAP3_dispatcherList_present if
                                           * present */
    Nulltype        ongoingCall;  /* optional; set in bit_mask
                                   * OMAP3_ongoingCall_present if present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                    * OMAP3_MT_ForwardSM_VGCS_Res_extensionContainer_present if
                    * present */
} OMAP3_MT_ForwardSM_VGCS_Res;

typedef struct OMAP3_TraceReference {
    unsigned short  length;
    unsigned char   value[2];
} OMAP3_TraceReference;

typedef unsigned short  OMAP3_TraceType;

typedef struct OMAP3_TraceReference2 {
    unsigned short  length;
    unsigned char   value[3];
} OMAP3_TraceReference2;

typedef enum OMAP3_TraceDepth {
    OMAP3_minimum = 0,
    OMAP3_medium = 1,
    OMAP3_maximum = 2
} OMAP3_TraceDepth;

	// Trace types are fully defined in  3GPP TS 52.008. [61]
typedef struct OMAP3_TraceDepthList {
    unsigned char   bit_mask;
#       define      OMAP3_msc_s_TraceDepth_present 0x80
#       define      OMAP3_mgw_TraceDepth_present 0x40
#       define      OMAP3_sgsn_TraceDepth_present 0x20
#       define      OMAP3_ggsn_TraceDepth_present 0x10
#       define      OMAP3_rnc_TraceDepth_present 0x08
#       define      OMAP3_bmsc_TraceDepth_present 0x04
    OMAP3_TraceDepth msc_s_TraceDepth;  /* optional; set in bit_mask
                                         * OMAP3_msc_s_TraceDepth_present if
                                         * present */
    OMAP3_TraceDepth mgw_TraceDepth;  /* optional; set in bit_mask
                                       * OMAP3_mgw_TraceDepth_present if
                                       * present */
    OMAP3_TraceDepth sgsn_TraceDepth;  /* optional; set in bit_mask
                                        * OMAP3_sgsn_TraceDepth_present if
                                        * present */
    OMAP3_TraceDepth ggsn_TraceDepth;  /* optional; set in bit_mask
                                        * OMAP3_ggsn_TraceDepth_present if
                                        * present */
    OMAP3_TraceDepth rnc_TraceDepth;  /* optional; set in bit_mask
                                       * OMAP3_rnc_TraceDepth_present if
                                       * present */
    OMAP3_TraceDepth bmsc_TraceDepth;  /* optional; set in bit_mask
                                        * OMAP3_bmsc_TraceDepth_present if
                                        * present */
} OMAP3_TraceDepthList;

// The value medium is applicable only for RNC. For other network elements, if value medium
// is received, value minimum shall be applied.
typedef struct OMAP3_TraceNE_TypeList {
    unsigned short  length;  /* number of significant bits */
    unsigned char   *value;
} OMAP3_TraceNE_TypeList;
#define                     OMAP3_msc_s 0x80
#define                     OMAP3_msc_s_byte 0
#define                     OMAP3_mgw 0x40
#define                     OMAP3_mgw_byte 0
#define                     OMAP3_TraceNE_TypeList_sgsn 0x20
#define                     OMAP3_TraceNE_TypeList_sgsn_byte 0
#define                     OMAP3_TraceNE_TypeList_ggsn 0x10
#define                     OMAP3_TraceNE_TypeList_ggsn_byte 0
#define                     OMAP3_rnc 0x08
#define                     OMAP3_rnc_byte 0
#define                     OMAP3_bm_sc 0x04
#define                     OMAP3_bm_sc_byte 0

typedef struct OMAP3_MSC_S_InterfaceList {
    unsigned short  length;  /* number of significant bits */
    unsigned char   *value;
} OMAP3_MSC_S_InterfaceList;
#define                     OMAP3_a 0x80
#define                     OMAP3_a_byte 0
#define                     OMAP3_MSC_S_InterfaceList_iu 0x40
#define                     OMAP3_MSC_S_InterfaceList_iu_byte 0
#define                     OMAP3_MSC_S_InterfaceList_mc 0x20
#define                     OMAP3_MSC_S_InterfaceList_mc_byte 0
#define                     OMAP3_map_g 0x10
#define                     OMAP3_map_g_byte 0
#define                     OMAP3_map_b 0x08
#define                     OMAP3_map_b_byte 0
#define                     OMAP3_map_e 0x04
#define                     OMAP3_map_e_byte 0
#define                     OMAP3_map_f 0x02
#define                     OMAP3_map_f_byte 0
#define                     OMAP3_cap 0x01
#define                     OMAP3_cap_byte 0
#define                     OMAP3_map_d 0x80
#define                     OMAP3_map_d_byte 1
#define                     OMAP3_map_c 0x40
#define                     OMAP3_map_c_byte 1

// Other bits than listed above shall be discarded.
typedef struct OMAP3_MGW_InterfaceList {
    unsigned short  length;  /* number of significant bits */
    unsigned char   *value;
} OMAP3_MGW_InterfaceList;
#define                     OMAP3_MGW_InterfaceList_mc 0x80
#define                     OMAP3_MGW_InterfaceList_mc_byte 0
#define                     OMAP3_nb_up 0x40
#define                     OMAP3_nb_up_byte 0
#define                     OMAP3_iu_up 0x20
#define                     OMAP3_iu_up_byte 0

// Other bits than listed above shall be discarded.
typedef struct OMAP3_SGSN_InterfaceList {
    unsigned short  length;  /* number of significant bits */
    unsigned char   *value;
} OMAP3_SGSN_InterfaceList;
#define                     OMAP3_gb 0x80
#define                     OMAP3_gb_byte 0
#define                     OMAP3_SGSN_InterfaceList_iu 0x40
#define                     OMAP3_SGSN_InterfaceList_iu_byte 0
#define                     OMAP3_SGSN_InterfaceList_gn 0x20
#define                     OMAP3_SGSN_InterfaceList_gn_byte 0
#define                     OMAP3_map_gr 0x10
#define                     OMAP3_map_gr_byte 0
#define                     OMAP3_map_gd 0x08
#define                     OMAP3_map_gd_byte 0
#define                     OMAP3_map_gf 0x04
#define                     OMAP3_map_gf_byte 0
#define                     OMAP3_gs 0x02
#define                     OMAP3_gs_byte 0
#define                     OMAP3_ge 0x01
#define                     OMAP3_ge_byte 0

// Other bits than listed above shall be discarded.
typedef struct OMAP3_GGSN_InterfaceList {
    unsigned short  length;  /* number of significant bits */
    unsigned char   *value;
} OMAP3_GGSN_InterfaceList;
#define                     OMAP3_GGSN_InterfaceList_gn 0x80
#define                     OMAP3_GGSN_InterfaceList_gn_byte 0
#define                     OMAP3_gi 0x40
#define                     OMAP3_gi_byte 0
#define                     OMAP3_GGSN_InterfaceList_gmb 0x20
#define                     OMAP3_GGSN_InterfaceList_gmb_byte 0

// Other bits than listed above shall be discarded.
typedef struct OMAP3_RNC_InterfaceList {
    unsigned short  length;  /* number of significant bits */
    unsigned char   *value;
} OMAP3_RNC_InterfaceList;
#define                     OMAP3_RNC_InterfaceList_iu 0x80
#define                     OMAP3_RNC_InterfaceList_iu_byte 0
#define                     OMAP3_iur 0x40
#define                     OMAP3_iur_byte 0
#define                     OMAP3_iub 0x20
#define                     OMAP3_iub_byte 0
#define                     OMAP3_uu 0x10
#define                     OMAP3_uu_byte 0

// Other bits than listed above shall be discarded.
typedef struct OMAP3_BMSC_InterfaceList {
    unsigned short  length;  /* number of significant bits */
    unsigned char   *value;
} OMAP3_BMSC_InterfaceList;
#define                     OMAP3_BMSC_InterfaceList_gmb 0x80
#define                     OMAP3_BMSC_InterfaceList_gmb_byte 0

// Other bits than listed above shall be discarded.
typedef struct OMAP3_TraceInterfaceList {
    unsigned char   bit_mask;
#       define      OMAP3_TraceInterfaceList_msc_s_List_present 0x80
#       define      OMAP3_TraceInterfaceList_mgw_List_present 0x40
#       define      OMAP3_TraceInterfaceList_sgsn_List_present 0x20
#       define      OMAP3_TraceInterfaceList_ggsn_List_present 0x10
#       define      OMAP3_rnc_List_present 0x08
#       define      OMAP3_TraceInterfaceList_bmsc_List_present 0x04
    OMAP3_MSC_S_InterfaceList msc_s_List;  /* optional; set in bit_mask
                               * OMAP3_TraceInterfaceList_msc_s_List_present if
                               * present */
    OMAP3_MGW_InterfaceList mgw_List;  /* optional; set in bit_mask
                                 * OMAP3_TraceInterfaceList_mgw_List_present if
                                 * present */
    OMAP3_SGSN_InterfaceList sgsn_List;  /* optional; set in bit_mask
                                * OMAP3_TraceInterfaceList_sgsn_List_present if
                                * present */
    OMAP3_GGSN_InterfaceList ggsn_List;  /* optional; set in bit_mask
                                * OMAP3_TraceInterfaceList_ggsn_List_present if
                                * present */
    OMAP3_RNC_InterfaceList rnc_List;  /* optional; set in bit_mask
                                        * OMAP3_rnc_List_present if present */
    OMAP3_BMSC_InterfaceList bmsc_List;  /* optional; set in bit_mask
                                * OMAP3_TraceInterfaceList_bmsc_List_present if
                                * present */
} OMAP3_TraceInterfaceList;

typedef struct OMAP3_MSC_S_EventList {
    unsigned short  length;  /* number of significant bits */
    unsigned char   *value;
} OMAP3_MSC_S_EventList;
#define                     OMAP3_mo_mtCall 0x80
#define                     OMAP3_mo_mtCall_byte 0
#define                     OMAP3_MSC_S_EventList_mo_mt_sms 0x40
#define                     OMAP3_MSC_S_EventList_mo_mt_sms_byte 0
#define                     OMAP3_lu_imsiAttach_imsiDetach 0x20
#define                     OMAP3_lu_imsiAttach_imsiDetach_byte 0
#define                     OMAP3_handovers 0x10
#define                     OMAP3_handovers_byte 0
#define                     OMAP3_ss 0x08
#define                     OMAP3_ss_byte 0

// Other bits than listed above shall be discarded.
typedef struct OMAP3_MGW_EventList {
    unsigned short  length;  /* number of significant bits */
    unsigned char   *value;
} OMAP3_MGW_EventList;
#define                     OMAP3_context 0x80
#define                     OMAP3_context_byte 0

// Other bits than listed above shall be discarded.
typedef struct OMAP3_SGSN_EventList {
    unsigned short  length;  /* number of significant bits */
    unsigned char   *value;
} OMAP3_SGSN_EventList;
#define                     OMAP3_SGSN_EventList_pdpContext 0x80
#define                     OMAP3_SGSN_EventList_pdpContext_byte 0
#define                     OMAP3_SGSN_EventList_mo_mt_sms 0x40
#define                     OMAP3_SGSN_EventList_mo_mt_sms_byte 0
#define                     OMAP3_rau_gprsAttach_gprsDetach 0x20
#define                     OMAP3_rau_gprsAttach_gprsDetach_byte 0
#define                     OMAP3_SGSN_EventList_mbmsContext 0x10
#define                     OMAP3_SGSN_EventList_mbmsContext_byte 0

// Other bits than listed above shall be discarded.
typedef struct OMAP3_GGSN_EventList {
    unsigned short  length;  /* number of significant bits */
    unsigned char   *value;
} OMAP3_GGSN_EventList;
#define                     OMAP3_GGSN_EventList_pdpContext 0x80
#define                     OMAP3_GGSN_EventList_pdpContext_byte 0
#define                     OMAP3_GGSN_EventList_mbmsContext 0x40
#define                     OMAP3_GGSN_EventList_mbmsContext_byte 0

// Other bits than listed above shall be discarded.
typedef struct OMAP3_BMSC_EventList {
    unsigned short  length;  /* number of significant bits */
    unsigned char   *value;
} OMAP3_BMSC_EventList;
#define                     OMAP3_mbmsMulticastServiceActivation 0x80
#define                     OMAP3_mbmsMulticastServiceActivation_byte 0

// Other bits than listed above shall be discarded.
typedef struct OMAP3_TraceEventList {
    unsigned char   bit_mask;
#       define      OMAP3_TraceEventList_msc_s_List_present 0x80
#       define      OMAP3_TraceEventList_mgw_List_present 0x40
#       define      OMAP3_TraceEventList_sgsn_List_present 0x20
#       define      OMAP3_TraceEventList_ggsn_List_present 0x10
#       define      OMAP3_TraceEventList_bmsc_List_present 0x08
    OMAP3_MSC_S_EventList msc_s_List;  /* optional; set in bit_mask
                                   * OMAP3_TraceEventList_msc_s_List_present if
                                   * present */
    OMAP3_MGW_EventList mgw_List;  /* optional; set in bit_mask
                                    * OMAP3_TraceEventList_mgw_List_present if
                                    * present */
    OMAP3_SGSN_EventList sgsn_List;  /* optional; set in bit_mask
                                      * OMAP3_TraceEventList_sgsn_List_present
                                      * if present */
    OMAP3_GGSN_EventList ggsn_List;  /* optional; set in bit_mask
                                      * OMAP3_TraceEventList_ggsn_List_present
                                      * if present */
    OMAP3_BMSC_EventList bmsc_List;  /* optional; set in bit_mask
                                      * OMAP3_TraceEventList_bmsc_List_present
                                      * if present */
} OMAP3_TraceEventList;

typedef struct OMAP3_ActivateTraceModeArg {
    unsigned char   bit_mask;
#       define      OMAP3_ActivateTraceModeArg_imsi_present 0x80
#       define      OMAP3_omc_Id_present 0x40
#       define      OMAP3_ActivateTraceModeArg_extensionContainer_present 0x20
#       define      OMAP3_ActivateTraceModeArg_traceReference2_present 0x10
#       define      OMAP3_traceDepthList_present 0x08
#       define      OMAP3_traceNE_TypeList_present 0x04
#       define      OMAP3_traceInterfaceList_present 0x02
#       define      OMAP3_traceEventList_present 0x01
    OMAP3_IMSI      imsi;  /* optional; set in bit_mask
                            * OMAP3_ActivateTraceModeArg_imsi_present if
                            * present */
    OMAP3_TraceReference traceReference;
    OMAP3_TraceType traceType;
    OMAP3_AddressString omc_Id;  /* optional; set in bit_mask
                                  * OMAP3_omc_Id_present if present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                     * OMAP3_ActivateTraceModeArg_extensionContainer_present if
                     * present */
    OMAP3_TraceReference2 traceReference2;  /* extension #1; optional; set in
                                   * bit_mask
                        * OMAP3_ActivateTraceModeArg_traceReference2_present if
                        * present */
    OMAP3_TraceDepthList traceDepthList;  /* extension #2; optional; set in
                                   * bit_mask OMAP3_traceDepthList_present if
                                   * present */
    OMAP3_TraceNE_TypeList traceNE_TypeList;  /* extension #3; optional; set in
                                   * bit_mask OMAP3_traceNE_TypeList_present if
                                   * present */
    OMAP3_TraceInterfaceList traceInterfaceList;  /* extension #4; optional; set
                                   * in bit_mask
                                   * OMAP3_traceInterfaceList_present if
                                   * present */
    OMAP3_TraceEventList traceEventList;  /* extension #5; optional; set in
                                   * bit_mask OMAP3_traceEventList_present if
                                   * present */
} OMAP3_ActivateTraceModeArg;

typedef OMAP3_ISDN_AddressString OMAP3_SendIMSIArg;

typedef OMAP3_IMSI      OMAP3_SendIMSIRes;

// Other bits than listed above shall be discarded.
typedef struct OMAP3_TracePropagationParameters {
    unsigned short  length;
    unsigned char   value[16];
} OMAP3_TracePropagationParameters;

typedef struct OMAP3_ActivateTraceModeRes {
    unsigned char   bit_mask;
#       define      OMAP3_ActivateTraceModeRes_extensionContainer_present 0x80
#       define      OMAP3_traceSupportIndicator_present 0x40
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                     * OMAP3_ActivateTraceModeRes_extensionContainer_present if
                     * present */
    Nulltype        traceSupportIndicator;  /* extension #1; optional; set in
                                   * bit_mask
                                   * OMAP3_traceSupportIndicator_present if
                                   * present */
} OMAP3_ActivateTraceModeRes;

typedef struct OMAP3_DeactivateTraceModeArg {
    unsigned char   bit_mask;
#       define      OMAP3_DeactivateTraceModeArg_imsi_present 0x80
#       define      OMAP3_DeactivateTraceModeArg_extensionContainer_present 0x40
#       define      OMAP3_DeactivateTraceModeArg_traceReference2_present 0x20
    OMAP3_IMSI      imsi;  /* optional; set in bit_mask
                            * OMAP3_DeactivateTraceModeArg_imsi_present if
                            * present */
    OMAP3_TraceReference traceReference;
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                   * OMAP3_DeactivateTraceModeArg_extensionContainer_present if
                   * present */
    OMAP3_TraceReference2 traceReference2;  /* extension #1; optional; set in
                                   * bit_mask
                      * OMAP3_DeactivateTraceModeArg_traceReference2_present if
                      * present */
} OMAP3_DeactivateTraceModeArg;

typedef struct OMAP3_DeactivateTraceModeRes {
    unsigned char   bit_mask;
#       define      OMAP3_DeactivateTraceModeRes_extensionContainer_present 0x80
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                   * OMAP3_DeactivateTraceModeRes_extensionContainer_present if
                   * present */
} OMAP3_DeactivateTraceModeRes;

typedef struct OMAP3_AgeIndicator {
    unsigned short  length;
    unsigned char   value[6];
} OMAP3_AgeIndicator;

typedef struct OMAP3_SuperChargerInfo {
    unsigned short  choice;
#       define      OMAP3_sendSubscriberData_chosen 1
#       define      OMAP3_subscriberDataStored_chosen 2
    union _union {
        Nulltype        sendSubscriberData;  /* to choose, set choice to
                                           * OMAP3_sendSubscriberData_chosen */
        OMAP3_AgeIndicator subscriberDataStored;  /* to choose, set choice to
                                         * OMAP3_subscriberDataStored_chosen */
    } u;
} OMAP3_SuperChargerInfo;

typedef struct OMAP3__bit2 {
    unsigned short  length;  /* number of significant bits */
    unsigned char   value[1];
} OMAP3__bit2;
#define                     OMAP3_utran 0x80
#define                     OMAP3_utran_byte 0
#define                     OMAP3_geran 0x40
#define                     OMAP3_geran_byte 0

typedef struct OMAP3_VLR_Capability {
    unsigned short  bit_mask;
#       define      OMAP3_VLR_Capability_supportedCamelPhases_present 0x8000
#       define      OMAP3_VLR_Capability_extensionContainer_present 0x4000
#       define      OMAP3_VLR_Capability_solsaSupportIndicator_present 0x2000
#       define      OMAP3_VLR_Capability_istSupportIndicator_present 0x1000
#       define      OMAP3_VLR_Capability_superChargerSupportedInServingNetworkEntity_present 0x0800
#       define      OMAP3_VLR_Capability_longFTN_Supported_present 0x0400
#       define      OMAP3_VLR_Capability_supportedLCS_CapabilitySets_present 0x0200
#       define      OMAP3_VLR_Capability_offeredCamel4CSIs_present 0x0100
#       define      OMAP3_VLR_Capability_supportedRAT_TypesIndicator_present 0x0080
#       define      OMAP3_longGroupID_Supported_present 0x0040
#       define      OMAP3_mtRoamingForwardingSupported_present 0x0020
    OMAP3_SupportedCamelPhases supportedCamelPhases;  /* optional; set in
                                   * bit_mask
                         * OMAP3_VLR_Capability_supportedCamelPhases_present if
                         * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                           * OMAP3_VLR_Capability_extensionContainer_present if
                           * present */
    Nulltype        solsaSupportIndicator;  /* extension #1; optional; set in
                                   * bit_mask
                        * OMAP3_VLR_Capability_solsaSupportIndicator_present if
                        * present */
    OMAP3_IST_SupportIndicator istSupportIndicator;  /* extension #2; optional;
                                   * set in bit_mask
                          * OMAP3_VLR_Capability_istSupportIndicator_present if
                          * present */
    OMAP3_SuperChargerInfo superChargerSupportedInServingNetworkEntity;  
                                  /* extension #3; optional; set in bit_mask
  * OMAP3_VLR_Capability_superChargerSupportedInServingNetworkEntity_present if
  * present */
    Nulltype        longFTN_Supported;  /* extension #4; optional; set in
                                   * bit_mask
                            * OMAP3_VLR_Capability_longFTN_Supported_present if
                            * present */
    OMAP3_SupportedLCS_CapabilitySets supportedLCS_CapabilitySets;  
                                  /* extension #5; optional; set in bit_mask
                  * OMAP3_VLR_Capability_supportedLCS_CapabilitySets_present if
                  * present */
    OMAP3_OfferedCamel4CSIs offeredCamel4CSIs;  /* extension #6; optional; set
                                   * in bit_mask
                            * OMAP3_VLR_Capability_offeredCamel4CSIs_present if
                            * present */
    OMAP3__bit2     supportedRAT_TypesIndicator;  /* extension #7; optional; set
                                   * in bit_mask
                  * OMAP3_VLR_Capability_supportedRAT_TypesIndicator_present if
                  * present */
    Nulltype        longGroupID_Supported;  /* extension #8; optional; set in
                                   * bit_mask
                                   * OMAP3_longGroupID_Supported_present if
                                   * present */
    Nulltype        mtRoamingForwardingSupported;  /* extension #9; optional;
                                   * set in bit_mask
                                   * OMAP3_mtRoamingForwardingSupported_present
                                   * if present */
} OMAP3_VLR_Capability;

typedef struct OMAP3_ADD_Info {
    unsigned char   bit_mask;
#       define      OMAP3_skipSubscriberDataUpdate_present 0x80
    OMAP3_IMEI      imeisv;
    Nulltype        skipSubscriberDataUpdate;  /* optional; set in bit_mask
                                    * OMAP3_skipSubscriberDataUpdate_present if
                                    * present */
} OMAP3_ADD_Info;

	// location registration types
	// gprs location registration types
	// handover types
	// authentication management types
	// security management types
	// equipment management types
	// subscriber management types
	// fault recovery types
	// provide subscriber info types 
	// subscriber information enquiry types
	// any time information enquiry types
	// any time information handling types
	// subscriber data modification notification types
	// gprs location information retrieval types
	// failure reporting types
	// gprs notification types
	// Mobility Management types
// location registration types
typedef struct OMAP3_UpdateLocationArg {
    unsigned char   bit_mask;
#       define      OMAP3_UpdateLocationArg_lmsi_present 0x80
#       define      OMAP3_UpdateLocationArg_extensionContainer_present 0x40
#       define      OMAP3_UpdateLocationArg_vlr_Capability_present 0x20
#       define      OMAP3_UpdateLocationArg_informPreviousNetworkEntity_present 0x10
#       define      OMAP3_cs_LCS_NotSupportedByUE_present 0x08
#       define      OMAP3_UpdateLocationArg_v_gmlc_Address_present 0x04
#       define      OMAP3_UpdateLocationArg_add_info_present 0x02
    OMAP3_IMSI      imsi;
    OMAP3_ISDN_AddressString msc_Number;
    OMAP3_ISDN_AddressString vlr_Number;
    OMAP3_LMSI      lmsi;  /* optional; set in bit_mask
                            * OMAP3_UpdateLocationArg_lmsi_present if present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                        * OMAP3_UpdateLocationArg_extensionContainer_present if
                        * present */
    OMAP3_VLR_Capability vlr_Capability;  /* extension #1; optional; set in
                                   * bit_mask
                            * OMAP3_UpdateLocationArg_vlr_Capability_present if
                            * present */
    Nulltype        informPreviousNetworkEntity;  /* extension #2; optional; set
                                   * in bit_mask
               * OMAP3_UpdateLocationArg_informPreviousNetworkEntity_present if
               * present */
    Nulltype        cs_LCS_NotSupportedByUE;  /* extension #3; optional; set in
                                   * bit_mask
                                   * OMAP3_cs_LCS_NotSupportedByUE_present if
                                   * present */
    OMAP3_GSN_Address v_gmlc_Address;  /* extension #4; optional; set in
                                   * bit_mask
                            * OMAP3_UpdateLocationArg_v_gmlc_Address_present if
                            * present */
    OMAP3_ADD_Info  add_info;  /* extension #5; optional; set in bit_mask
                                * OMAP3_UpdateLocationArg_add_info_present if
                                * present */
} OMAP3_UpdateLocationArg;

// Core network signalling capability set1 indicates LCS Release98 or Release99 version.
// Core network signalling capability set2 indicates LCS Release4.
// Core network signalling capability set3 indicates LCS Release5.
// Core network signalling capability set4 indicates LCS Release6 or later version.
// A node shall mark in the BIT STRING all LCS capability sets it supports. 
// If no bit is set then the sending node does not support LCS.
// If the parameter is not sent by an VLR then the VLR may support at most capability set1.
// If the parameter is not sent by an SGSN then no support for LCS is assumed.
// An SGSN is not allowed to indicate support of capability set1.
// Other bits than listed above shall be discarded.
typedef struct OMAP3_UpdateLocationRes {
    unsigned char   bit_mask;
#       define      OMAP3_UpdateLocationRes_extensionContainer_present 0x80
#       define      OMAP3_UpdateLocationRes_add_Capability_present 0x40
    OMAP3_ISDN_AddressString hlr_Number;
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                        * OMAP3_UpdateLocationRes_extensionContainer_present if
                        * present */
    Nulltype        add_Capability;  /* extension #1; optional; set in bit_mask
                            * OMAP3_UpdateLocationRes_add_Capability_present if
                            * present */
} OMAP3_UpdateLocationRes;

typedef enum OMAP3_TypeOfUpdate {
    OMAP3_sgsn_change = 0,
    OMAP3_mme_change = 1
} OMAP3_TypeOfUpdate;

typedef enum OMAP3_CancellationType {
    OMAP3_updateProcedure = 0,
    OMAP3_subscriptionWithdraw = 1
} OMAP3_CancellationType;

// TypeOfUpdate shall be absent if CancellationType is different from updateProcedure
// and initialAttachProcedure
typedef struct OMAP3_CancelLocationArg {
    unsigned char   bit_mask;
#       define      OMAP3_cancellationType_present 0x80
#       define      OMAP3_CancelLocationArg_extensionContainer_present 0x40
#       define      OMAP3_typeOfUpdate_present 0x20
#       define      OMAP3_mtrf_SupportedAndAuthorized_present 0x10
#       define      OMAP3_mtrf_SupportedAndNotAuthorized_present 0x08
#       define      OMAP3_newMSC_Number_present 0x04
#       define      OMAP3_newVLR_Number_present 0x02
#       define      OMAP3_new_lmsi_present 0x01
    OMAP3_Identity  identity;
    OMAP3_CancellationType cancellationType;  /* optional; set in bit_mask
                                               * OMAP3_cancellationType_present
                                               * if present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                        * OMAP3_CancelLocationArg_extensionContainer_present if
                        * present */
    OMAP3_TypeOfUpdate typeOfUpdate;  /* extension #1; optional; set in bit_mask
                                       * OMAP3_typeOfUpdate_present if
                                       * present */
    Nulltype        mtrf_SupportedAndAuthorized;  /* extension #2; optional; set
                                   * in bit_mask
                                   * OMAP3_mtrf_SupportedAndAuthorized_present
                                   * if present */
    Nulltype        mtrf_SupportedAndNotAuthorized;  /* extension #3; optional;
                                   * set in bit_mask
                              * OMAP3_mtrf_SupportedAndNotAuthorized_present if
                              * present */
    OMAP3_ISDN_AddressString newMSC_Number;  /* extension #4; optional; set in
                                   * bit_mask OMAP3_newMSC_Number_present if
                                   * present */
    OMAP3_ISDN_AddressString newVLR_Number;  /* extension #5; optional; set in
                                   * bit_mask OMAP3_newVLR_Number_present if
                                   * present */
    OMAP3_LMSI      new_lmsi;  /* extension #6; optional; set in bit_mask
                                * OMAP3_new_lmsi_present if present */
} OMAP3_CancelLocationArg;

	// The HLR shall not send values other than listed above
typedef struct OMAP3_CancelLocationRes {
    unsigned char   bit_mask;
#       define      OMAP3_CancelLocationRes_extensionContainer_present 0x80
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                        * OMAP3_CancelLocationRes_extensionContainer_present if
                        * present */
} OMAP3_CancelLocationRes;

typedef struct OMAP3_PurgeMS_Arg {
    unsigned char   bit_mask;
#       define      OMAP3_PurgeMS_Arg_vlr_Number_present 0x80
#       define      OMAP3_PurgeMS_Arg_sgsn_Number_present 0x40
#       define      OMAP3_PurgeMS_Arg_extensionContainer_present 0x20
    OMAP3_IMSI      imsi;
    OMAP3_ISDN_AddressString vlr_Number;  /* optional; set in bit_mask
                                      * OMAP3_PurgeMS_Arg_vlr_Number_present if
                                      * present */
    OMAP3_ISDN_AddressString sgsn_Number;  /* optional; set in bit_mask
                                     * OMAP3_PurgeMS_Arg_sgsn_Number_present if
                                     * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                              * OMAP3_PurgeMS_Arg_extensionContainer_present if
                              * present */
} OMAP3_PurgeMS_Arg;

typedef struct OMAP3_PurgeMS_Res {
    unsigned char   bit_mask;
#       define      OMAP3_freezeTMSI_present 0x80
#       define      OMAP3_freezeP_TMSI_present 0x40
#       define      OMAP3_PurgeMS_Res_extensionContainer_present 0x20
    Nulltype        freezeTMSI;  /* optional; set in bit_mask
                                  * OMAP3_freezeTMSI_present if present */
    Nulltype        freezeP_TMSI;  /* optional; set in bit_mask
                                    * OMAP3_freezeP_TMSI_present if present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                              * OMAP3_PurgeMS_Res_extensionContainer_present if
                              * present */
} OMAP3_PurgeMS_Res;

	// The internal structure is defined as follows:
	// octet 1 bits 4321	Mobile Country Code 1st digit
	//         bits 8765	Mobile Country Code 2nd digit
	// octet 2 bits 4321	Mobile Country Code 3rd digit
	//         bits 8765	Mobile Network Code 3rd digit
	//			or filler (1111) for 2 digit MNCs
	// octet 3 bits 4321	Mobile Network Code 1st digit
	//         bits 8765	Mobile Network Code 2nd digit
typedef unsigned short  OMAP3_NumberOfRequestedVectors;

typedef unsigned short  OMAP3_HopCounter;

typedef struct OMAP3_SendIdentificationArg {
    unsigned char   bit_mask;
#       define      OMAP3_numberOfRequestedVectors_present 0x80
#       define      OMAP3_SendIdentificationArg_segmentationProhibited_present 0x40
#       define      OMAP3_SendIdentificationArg_extensionContainer_present 0x20
#       define      OMAP3_SendIdentificationArg_msc_Number_present 0x10
#       define      OMAP3_previous_LAI_present 0x08
#       define      OMAP3_hopCounter_present 0x04
    OMAP3_TMSI      tmsi;
    OMAP3_NumberOfRequestedVectors numberOfRequestedVectors;  /* optional; set
                                   * in bit_mask
                                   * OMAP3_numberOfRequestedVectors_present if
                                   * present */
	// within a dialogue numberOfRequestedVectors shall be present in 
	// the first service request and shall not be present in subsequent service requests. 
	// If received in a subsequent service request it shall be discarded. 
    Nulltype        segmentationProhibited;  /* optional; set in bit_mask
                * OMAP3_SendIdentificationArg_segmentationProhibited_present if
                * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                    * OMAP3_SendIdentificationArg_extensionContainer_present if
                    * present */
    OMAP3_ISDN_AddressString msc_Number;  /* extension #1; optional; set in
                                   * bit_mask
                            * OMAP3_SendIdentificationArg_msc_Number_present if
                            * present */
    OMAP3_LAIFixedLength previous_LAI;  /* extension #2; optional; set in
                                   * bit_mask OMAP3_previous_LAI_present if
                                   * present */
    OMAP3_HopCounter hopCounter;  /* extension #3; optional; set in bit_mask
                                   * OMAP3_hopCounter_present if present */
} OMAP3_SendIdentificationArg;

typedef struct OMAP3_RAND {
    unsigned short  length;
    unsigned char   value[16];
} OMAP3_RAND;

typedef struct OMAP3_SRES {
    unsigned short  length;
    unsigned char   value[4];
} OMAP3_SRES;

typedef struct OMAP3_AuthenticationTriplet {
    OMAP3_RAND      rand;
    OMAP3_SRES      sres;
    OMAP3_Kc        kc;
} OMAP3_AuthenticationTriplet;

typedef struct OMAP3_TripletList {
    unsigned short  count;
    OMAP3_AuthenticationTriplet value[5];
} OMAP3_TripletList;

typedef struct OMAP3_XRES {
    unsigned short  length;
    unsigned char   value[16];
} OMAP3_XRES;

typedef struct OMAP3_CK {
    unsigned short  length;
    unsigned char   value[16];
} OMAP3_CK;

typedef struct OMAP3_IK {
    unsigned short  length;
    unsigned char   value[16];
} OMAP3_IK;

typedef struct OMAP3_AUTN {
    unsigned short  length;
    unsigned char   value[16];
} OMAP3_AUTN;

typedef struct OMAP3_AuthenticationQuintuplet {
    OMAP3_RAND      rand;
    OMAP3_XRES      xres;
    OMAP3_CK        ck;
    OMAP3_IK        ik;
    OMAP3_AUTN      autn;
} OMAP3_AuthenticationQuintuplet;

typedef struct OMAP3_QuintupletList {
    unsigned short  count;
    OMAP3_AuthenticationQuintuplet value[5];
} OMAP3_QuintupletList;

// authentication management types
typedef struct OMAP3_AuthenticationSetList {
    unsigned short  choice;
#       define      OMAP3_tripletList_chosen 1
#       define      OMAP3_quintupletList_chosen 2
    union _union {
        OMAP3_TripletList tripletList;  /* to choose, set choice to
                                         * OMAP3_tripletList_chosen */
        OMAP3_QuintupletList quintupletList;  /* to choose, set choice to
                                               * OMAP3_quintupletList_chosen */
    } u;
} OMAP3_AuthenticationSetList;

typedef struct OMAP3_Cksn {
    unsigned short  length;
    unsigned char   value[1];
} OMAP3_Cksn;

typedef struct OMAP3_GSM_SecurityContextData {
    OMAP3_Kc        kc;
    OMAP3_Cksn      cksn;
} OMAP3_GSM_SecurityContextData;

	// The internal structure is defined in 3GPP TS 24.008
typedef struct OMAP3_KSI {
    unsigned short  length;
    unsigned char   value[1];
} OMAP3_KSI;

typedef struct OMAP3_UMTS_SecurityContextData {
    OMAP3_CK        ck;
    OMAP3_IK        ik;
    OMAP3_KSI       ksi;
} OMAP3_UMTS_SecurityContextData;

typedef struct OMAP3_CurrentSecurityContext {
    unsigned short  choice;
#       define      OMAP3_gsm_SecurityContextData_chosen 1
#       define      OMAP3_umts_SecurityContextData_chosen 2
    union _union {
        OMAP3_GSM_SecurityContextData gsm_SecurityContextData;  /* to choose,
                                   * set choice to
                                   * OMAP3_gsm_SecurityContextData_chosen */
        OMAP3_UMTS_SecurityContextData umts_SecurityContextData;  /* to choose,
                                   * set choice to
                                   * OMAP3_umts_SecurityContextData_chosen */
    } u;
} OMAP3_CurrentSecurityContext;

typedef struct OMAP3_SendIdentificationRes {
    unsigned char   bit_mask;
#       define      OMAP3_SendIdentificationRes_imsi_present 0x80
#       define      OMAP3_SendIdentificationRes_authenticationSetList_present 0x40
#       define      OMAP3_currentSecurityContext_present 0x20
#       define      OMAP3_SendIdentificationRes_extensionContainer_present 0x10
    OMAP3_IMSI      imsi;  /* optional; set in bit_mask
                            * OMAP3_SendIdentificationRes_imsi_present if
                            * present */
	// IMSI shall be present in the first (or only) service response of a dialogue.
	// If multiple service requests are present in a dialogue then IMSI
	// shall not be present in any service response other than the first one.
    OMAP3_AuthenticationSetList authenticationSetList;  /* optional; set in
                                   * bit_mask
                 * OMAP3_SendIdentificationRes_authenticationSetList_present if
                 * present */
    OMAP3_CurrentSecurityContext currentSecurityContext;  /* optional; set in
                                   * bit_mask
                                   * OMAP3_currentSecurityContext_present if
                                   * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                    * OMAP3_SendIdentificationRes_extensionContainer_present if
                    * present */
} OMAP3_SendIdentificationRes;

typedef struct OMAP3_AUTS {
    unsigned short  length;
    unsigned char   value[14];
} OMAP3_AUTS;

typedef enum OMAP3_FailureCause {
    OMAP3_wrongUserResponse = 0,
    OMAP3_wrongNetworkSignature = 1
} OMAP3_FailureCause;

typedef enum OMAP3_AccessType {
    OMAP3_call = 0,
    OMAP3_emergencyCall = 1,
    OMAP3_locationUpdating = 2,
    OMAP3_supplementaryService = 3,
    OMAP3_shortMessage = 4,
    OMAP3_gprsAttach = 5,
    OMAP3_routingAreaUpdating = 6,
    OMAP3_serviceRequest = 7,
    OMAP3_pdpContextActivation = 8,
    OMAP3_pdpContextDeactivation = 9,
    OMAP3_gprsDetach = 10
} OMAP3_AccessType;

	// The internal structure is defined in 3GPP TS 24.008
typedef struct OMAP3_AuthenticationFailureReportArg {
    unsigned char   bit_mask;
#       define      OMAP3_AuthenticationFailureReportArg_extensionContainer_present 0x80
#       define      OMAP3_re_attempt_present 0x40
#       define      OMAP3_accessType_present 0x20
#       define      OMAP3_rand_present 0x10
#       define      OMAP3_AuthenticationFailureReportArg_vlr_Number_present 0x08
#       define      OMAP3_AuthenticationFailureReportArg_sgsn_Number_present 0x04
    OMAP3_IMSI      imsi;
    OMAP3_FailureCause failureCause;
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
           * OMAP3_AuthenticationFailureReportArg_extensionContainer_present if
           * present */
    ossBoolean      re_attempt;  /* extension #1; optional; set in bit_mask
                                  * OMAP3_re_attempt_present if present */
    OMAP3_AccessType accessType;  /* extension #2; optional; set in bit_mask
                                   * OMAP3_accessType_present if present */
    OMAP3_RAND      rand;  /* extension #3; optional; set in bit_mask
                            * OMAP3_rand_present if present */
    OMAP3_ISDN_AddressString vlr_Number;  /* extension #4; optional; set in
                                   * bit_mask
                   * OMAP3_AuthenticationFailureReportArg_vlr_Number_present if
                   * present */
    OMAP3_ISDN_AddressString sgsn_Number;  /* extension #5; optional; set in
                                   * bit_mask
                  * OMAP3_AuthenticationFailureReportArg_sgsn_Number_present if
                  * present */
} OMAP3_AuthenticationFailureReportArg;

	// exception handling:
	// received values greater than 10 shall be ignored.
typedef struct OMAP3_AuthenticationFailureReportRes {
    unsigned char   bit_mask;
#       define      OMAP3_AuthenticationFailureReportRes_extensionContainer_present 0x80
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
           * OMAP3_AuthenticationFailureReportRes_extensionContainer_present if
           * present */
} OMAP3_AuthenticationFailureReportRes;

typedef struct OMAP3_SGSN_Capability {
    unsigned short  bit_mask;
#       define      OMAP3_SGSN_Capability_solsaSupportIndicator_present 0x8000
#       define      OMAP3_SGSN_Capability_extensionContainer_present 0x4000
#       define      OMAP3_SGSN_Capability_superChargerSupportedInServingNetworkEntity_present 0x2000
#       define      OMAP3_gprsEnhancementsSupportIndicator_present 0x1000
#       define      OMAP3_SGSN_Capability_supportedCamelPhases_present 0x0800
#       define      OMAP3_SGSN_Capability_supportedLCS_CapabilitySets_present 0x0400
#       define      OMAP3_SGSN_Capability_offeredCamel4CSIs_present 0x0200
#       define      OMAP3_smsCallBarringSupportIndicator_present 0x0100
#       define      OMAP3_SGSN_Capability_supportedRAT_TypesIndicator_present 0x0080
    Nulltype        solsaSupportIndicator;  /* optional; set in bit_mask
                       * OMAP3_SGSN_Capability_solsaSupportIndicator_present if
                       * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                          * OMAP3_SGSN_Capability_extensionContainer_present if
                          * present */
    OMAP3_SuperChargerInfo superChargerSupportedInServingNetworkEntity;  
                                  /* extension #1; optional; set in bit_mask
 * OMAP3_SGSN_Capability_superChargerSupportedInServingNetworkEntity_present if
 * present */
    Nulltype        gprsEnhancementsSupportIndicator;  /* extension #2;
                                   * optional; set in bit_mask
                            * OMAP3_gprsEnhancementsSupportIndicator_present if
                            * present */
    OMAP3_SupportedCamelPhases supportedCamelPhases;  /* extension #3; optional;
                                   * set in bit_mask
                        * OMAP3_SGSN_Capability_supportedCamelPhases_present if
                        * present */
    OMAP3_SupportedLCS_CapabilitySets supportedLCS_CapabilitySets;  
                                  /* extension #4; optional; set in bit_mask
                 * OMAP3_SGSN_Capability_supportedLCS_CapabilitySets_present if
                 * present */
    OMAP3_OfferedCamel4CSIs offeredCamel4CSIs;  /* extension #5; optional; set
                                   * in bit_mask
                           * OMAP3_SGSN_Capability_offeredCamel4CSIs_present if
                           * present */
    Nulltype        smsCallBarringSupportIndicator;  /* extension #6; optional;
                                   * set in bit_mask
                              * OMAP3_smsCallBarringSupportIndicator_present if
                              * present */
    OMAP3__bit2     supportedRAT_TypesIndicator;  /* extension #7; optional; set
                                   * in bit_mask
                 * OMAP3_SGSN_Capability_supportedRAT_TypesIndicator_present if
                 * present */
#       define      OMAP3_utran_1 0x80
#       define      OMAP3_utran_1_byte 0
#       define      OMAP3_geran_1 0x40
#       define      OMAP3_geran_1_byte 0
} OMAP3_SGSN_Capability;

// gprs location registration types
typedef struct OMAP3_UpdateGprsLocationArg {
    unsigned char   bit_mask;
#       define      OMAP3_UpdateGprsLocationArg_extensionContainer_present 0x80
#       define      OMAP3_sgsn_Capability_present 0x40
#       define      OMAP3_UpdateGprsLocationArg_informPreviousNetworkEntity_present 0x20
#       define      OMAP3_ps_LCS_NotSupportedByUE_present 0x10
#       define      OMAP3_UpdateGprsLocationArg_v_gmlc_Address_present 0x08
#       define      OMAP3_UpdateGprsLocationArg_add_info_present 0x04
    OMAP3_IMSI      imsi;
    OMAP3_ISDN_AddressString sgsn_Number;
    OMAP3_GSN_Address sgsn_Address;
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                    * OMAP3_UpdateGprsLocationArg_extensionContainer_present if
                    * present */
    OMAP3_SGSN_Capability sgsn_Capability;  /* extension #1; optional; set in
                                   * bit_mask OMAP3_sgsn_Capability_present if
                                   * present */
    Nulltype        informPreviousNetworkEntity;  /* extension #2; optional; set
                                   * in bit_mask
           * OMAP3_UpdateGprsLocationArg_informPreviousNetworkEntity_present if
           * present */
    Nulltype        ps_LCS_NotSupportedByUE;  /* extension #3; optional; set in
                                   * bit_mask
                                   * OMAP3_ps_LCS_NotSupportedByUE_present if
                                   * present */
    OMAP3_GSN_Address v_gmlc_Address;  /* extension #4; optional; set in
                                   * bit_mask
                        * OMAP3_UpdateGprsLocationArg_v_gmlc_Address_present if
                        * present */
    OMAP3_ADD_Info  add_info;  /* extension #5; optional; set in bit_mask
                                * OMAP3_UpdateGprsLocationArg_add_info_present
                                * if present */
} OMAP3_UpdateGprsLocationArg;

	// Octets are coded according to TS 3GPP TS 23.003 [17]
typedef struct OMAP3_UpdateGprsLocationRes {
    unsigned char   bit_mask;
#       define      OMAP3_UpdateGprsLocationRes_extensionContainer_present 0x80
#       define      OMAP3_UpdateGprsLocationRes_add_Capability_present 0x40
    OMAP3_ISDN_AddressString hlr_Number;
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                    * OMAP3_UpdateGprsLocationRes_extensionContainer_present if
                    * present */
    Nulltype        add_Capability;  /* extension #1; optional; set in bit_mask
                        * OMAP3_UpdateGprsLocationRes_add_Capability_present if
                        * present */
} OMAP3_UpdateGprsLocationRes;

	// Octets are coded according the Channel Type information element in 3GPP TS 48.008
typedef struct OMAP3_IntegrityProtectionInformation {
    unsigned short  length;
    unsigned char   value[100];
} OMAP3_IntegrityProtectionInformation;

typedef struct OMAP3_EncryptionInformation {
    unsigned short  length;
    unsigned char   value[100];
} OMAP3_EncryptionInformation;

typedef enum OMAP3_KeyStatus {
    OMAP3_old = 0,
    OMAP3_new = 1
} OMAP3_KeyStatus;

typedef struct OMAP3_AllowedGSM_Algorithms {
    unsigned short  length;
    unsigned char   value[1];
} OMAP3_AllowedGSM_Algorithms;

typedef struct OMAP3_PermittedIntegrityProtectionAlgorithms {
    unsigned short  length;
    unsigned char   value[9];
} OMAP3_PermittedIntegrityProtectionAlgorithms;

typedef struct OMAP3_PermittedEncryptionAlgorithms {
    unsigned short  length;
    unsigned char   value[9];
} OMAP3_PermittedEncryptionAlgorithms;

	// internal structure is coded as Algorithm identifier octet from
	// Permitted Algorithms defined in 3GPP TS 48.008
	// A node shall mark all GSM algorithms that are allowed in MSC-B
typedef struct OMAP3_AllowedUMTS_Algorithms {
    unsigned char   bit_mask;
#       define      OMAP3_integrityProtectionAlgorithms_present 0x80
#       define      OMAP3_encryptionAlgorithms_present 0x40
#       define      OMAP3_AllowedUMTS_Algorithms_extensionContainer_present 0x20
    OMAP3_PermittedIntegrityProtectionAlgorithms integrityProtectionAlgorithms;                                         /* optional; set in bit_mask
                               * OMAP3_integrityProtectionAlgorithms_present if
                               * present */
    OMAP3_PermittedEncryptionAlgorithms encryptionAlgorithms;  /* optional; set
                                   * in bit_mask
                                   * OMAP3_encryptionAlgorithms_present if
                                   * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                   * OMAP3_AllowedUMTS_Algorithms_extensionContainer_present if
                   * present */
} OMAP3_AllowedUMTS_Algorithms;

typedef struct OMAP3_RadioResourceInformation {
    unsigned short  length;
    unsigned char   value[13];
} OMAP3_RadioResourceInformation;

typedef unsigned short  OMAP3_RAB_Id;

typedef struct OMAP3_RadioResource {
    OMAP3_RadioResourceInformation radioResourceInformation;
    OMAP3_RAB_Id    rab_Id;
	// RAB Identity is needed to relate the radio resources with the radio access bearers. 
} OMAP3_RadioResource;

	// Octet contains a complete Service-Handover data type 
	// as defined in 3GPP TS 25.413, encoded according to the encoding scheme 
	// mandated by 3GPP TS 25.413
	// Padding bits are included in the least significant bits. 
typedef struct OMAP3_RadioResourceList {
    unsigned short  count;
    OMAP3_RadioResource value[7];
} OMAP3_RadioResourceList;

typedef struct OMAP3_BSSMAP_ServiceHandover {
    unsigned short  length;
    unsigned char   value[1];
} OMAP3_BSSMAP_ServiceHandover;

	// Octets are coded according the Service Handover information element in
	// 3GPP TS 48.008.
typedef struct OMAP3_RANAP_ServiceHandover {
    unsigned short  length;
    unsigned char   value[1];
} OMAP3_RANAP_ServiceHandover;

typedef struct OMAP3_BSSMAP_ServiceHandoverInfo {
    OMAP3_BSSMAP_ServiceHandover bssmap_ServiceHandover;
    OMAP3_RAB_Id    rab_Id;
	// RAB Identity is needed to relate the service handovers with the radio access bearers. 
} OMAP3_BSSMAP_ServiceHandoverInfo;

typedef struct OMAP3_BSSMAP_ServiceHandoverList {
    unsigned short  count;
    OMAP3_BSSMAP_ServiceHandoverInfo value[7];
} OMAP3_BSSMAP_ServiceHandoverList;

	// Codecs are sent in priority order where codec1 has highest priority
typedef struct OMAP3_Codec {
    unsigned short  length;
    unsigned char   value[4];
} OMAP3_Codec;

typedef struct OMAP3_CodecList {
    unsigned char   bit_mask;
#       define      OMAP3_codec2_present 0x80
#       define      OMAP3_codec3_present 0x40
#       define      OMAP3_codec4_present 0x20
#       define      OMAP3_codec5_present 0x10
#       define      OMAP3_codec6_present 0x08
#       define      OMAP3_codec7_present 0x04
#       define      OMAP3_codec8_present 0x02
#       define      OMAP3_CodecList_extensionContainer_present 0x01
    OMAP3_Codec     codec1;
    OMAP3_Codec     codec2;  /* optional; set in bit_mask OMAP3_codec2_present
                              * if present */
    OMAP3_Codec     codec3;  /* optional; set in bit_mask OMAP3_codec3_present
                              * if present */
    OMAP3_Codec     codec4;  /* optional; set in bit_mask OMAP3_codec4_present
                              * if present */
    OMAP3_Codec     codec5;  /* optional; set in bit_mask OMAP3_codec5_present
                              * if present */
    OMAP3_Codec     codec6;  /* optional; set in bit_mask OMAP3_codec6_present
                              * if present */
    OMAP3_Codec     codec7;  /* optional; set in bit_mask OMAP3_codec7_present
                              * if present */
    OMAP3_Codec     codec8;  /* optional; set in bit_mask OMAP3_codec8_present
                              * if present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                                * OMAP3_CodecList_extensionContainer_present if
                                * present */
} OMAP3_CodecList;

typedef struct OMAP3_SupportedCodecsList {
    unsigned char   bit_mask;
#       define      OMAP3_utranCodecList_present 0x80
#       define      OMAP3_geranCodecList_present 0x40
#       define      OMAP3_SupportedCodecsList_extensionContainer_present 0x20
    OMAP3_CodecList utranCodecList;  /* optional; set in bit_mask
                                      * OMAP3_utranCodecList_present if
                                      * present */
    OMAP3_CodecList geranCodecList;  /* optional; set in bit_mask
                                      * OMAP3_geranCodecList_present if
                                      * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                      * OMAP3_SupportedCodecsList_extensionContainer_present if
                      * present */
} OMAP3_SupportedCodecsList;

// handover types
typedef struct OMAP3_ForwardAccessSignalling_Arg {
    unsigned int    bit_mask;
#       define      OMAP3_ForwardAccessSignalling_Arg_integrityProtectionInfo_present 0x80000000
#       define      OMAP3_ForwardAccessSignalling_Arg_encryptionInfo_present 0x40000000
#       define      OMAP3_keyStatus_present 0x20000000
#       define      OMAP3_ForwardAccessSignalling_Arg_allowedGSM_Algorithms_present 0x10000000
#       define      OMAP3_ForwardAccessSignalling_Arg_allowedUMTS_Algorithms_present 0x08000000
#       define      OMAP3_ForwardAccessSignalling_Arg_radioResourceInformation_present 0x04000000
#       define      OMAP3_ForwardAccessSignalling_Arg_extensionContainer_present 0x02000000
#       define      OMAP3_ForwardAccessSignalling_Arg_radioResourceList_present 0x01000000
#       define      OMAP3_ForwardAccessSignalling_Arg_bssmap_ServiceHandover_present 0x00800000
#       define      OMAP3_ForwardAccessSignalling_Arg_ranap_ServiceHandover_present 0x00400000
#       define      OMAP3_ForwardAccessSignalling_Arg_bssmap_ServiceHandoverList_present 0x00200000
#       define      OMAP3_currentlyUsedCodec_present 0x00100000
#       define      OMAP3_ForwardAccessSignalling_Arg_iuSupportedCodecsList_present 0x00080000
#       define      OMAP3_ForwardAccessSignalling_Arg_rab_ConfigurationIndicator_present 0x00040000
#       define      OMAP3_ForwardAccessSignalling_Arg_iuSelectedCodec_present 0x00020000
#       define      OMAP3_ForwardAccessSignalling_Arg_alternativeChannelType_present 0x00010000
#       define      OMAP3_ForwardAccessSignalling_Arg_traceReference2_present 0x00008000
#       define      OMAP3_ForwardAccessSignalling_Arg_tracePropagationParameters_present 0x00004000
    OMAP3_AccessNetworkSignalInfo an_APDU;
    OMAP3_IntegrityProtectionInformation integrityProtectionInfo;  /* optional;
                                   * set in bit_mask
         * OMAP3_ForwardAccessSignalling_Arg_integrityProtectionInfo_present if
         * present */
    OMAP3_EncryptionInformation encryptionInfo;  /* optional; set in bit_mask
                  * OMAP3_ForwardAccessSignalling_Arg_encryptionInfo_present if
                  * present */
    OMAP3_KeyStatus keyStatus;  /* optional; set in bit_mask
                                 * OMAP3_keyStatus_present if present */
    OMAP3_AllowedGSM_Algorithms allowedGSM_Algorithms;  /* optional; set in
                                   * bit_mask
           * OMAP3_ForwardAccessSignalling_Arg_allowedGSM_Algorithms_present if
           * present */
    OMAP3_AllowedUMTS_Algorithms allowedUMTS_Algorithms;  /* optional; set in
                                   * bit_mask
          * OMAP3_ForwardAccessSignalling_Arg_allowedUMTS_Algorithms_present if
          * present */
    OMAP3_RadioResourceInformation radioResourceInformation;  /* optional; set
                                   * in bit_mask
        * OMAP3_ForwardAccessSignalling_Arg_radioResourceInformation_present if
        * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
              * OMAP3_ForwardAccessSignalling_Arg_extensionContainer_present if
              * present */
    OMAP3_RadioResourceList radioResourceList;  /* extension #1; optional; set
                                   * in bit_mask
               * OMAP3_ForwardAccessSignalling_Arg_radioResourceList_present if
               * present */
    OMAP3_BSSMAP_ServiceHandover bssmap_ServiceHandover;  /* extension #2;
                                   * optional; set in bit_mask
          * OMAP3_ForwardAccessSignalling_Arg_bssmap_ServiceHandover_present if
          * present */
    OMAP3_RANAP_ServiceHandover ranap_ServiceHandover;  /* extension #3;
                                   * optional; set in bit_mask
           * OMAP3_ForwardAccessSignalling_Arg_ranap_ServiceHandover_present if
           * present */
    OMAP3_BSSMAP_ServiceHandoverList bssmap_ServiceHandoverList;  /* extension
                                   * #4; optional; set in bit_mask
      * OMAP3_ForwardAccessSignalling_Arg_bssmap_ServiceHandoverList_present if
      * present */
    OMAP3_Codec     currentlyUsedCodec;  /* extension #5; optional; set in
                                   * bit_mask OMAP3_currentlyUsedCodec_present
                                   * if present */
    OMAP3_SupportedCodecsList iuSupportedCodecsList;  /* extension #6; optional;
                                   * set in bit_mask
           * OMAP3_ForwardAccessSignalling_Arg_iuSupportedCodecsList_present if
           * present */
    Nulltype        rab_ConfigurationIndicator;  /* extension #7; optional; set
                                   * in bit_mask
      * OMAP3_ForwardAccessSignalling_Arg_rab_ConfigurationIndicator_present if
      * present */
    OMAP3_Codec     iuSelectedCodec;  /* extension #8; optional; set in bit_mask
                 * OMAP3_ForwardAccessSignalling_Arg_iuSelectedCodec_present if
                 * present */
    OMAP3_RadioResourceInformation alternativeChannelType;  /* extension #9;
                                   * optional; set in bit_mask
          * OMAP3_ForwardAccessSignalling_Arg_alternativeChannelType_present if
          * present */
    OMAP3_TraceReference2 traceReference2;  /* extension #10; optional; set in
                                   * bit_mask
                 * OMAP3_ForwardAccessSignalling_Arg_traceReference2_present if
                 * present */
    OMAP3_TracePropagationParameters tracePropagationParameters;  /* extension
                                   * #11; optional; set in bit_mask
      * OMAP3_ForwardAccessSignalling_Arg_tracePropagationParameters_present if
      * present */
} OMAP3_ForwardAccessSignalling_Arg;

typedef struct OMAP3_RNCId {
    unsigned short  length;
    unsigned char   value[7];
} OMAP3_RNCId;

	// The internal structure is defined as follows:
	// octet 1	Coded as Codec Identification code in 3GPP TS 26.103
	// octets 2,3,4	Parameters for the Codec as defined in 3GPP TS
	//		
typedef struct OMAP3_GERAN_Classmark {
    unsigned short  length;
    unsigned char   value[87];
} OMAP3_GERAN_Classmark;

typedef struct OMAP3_UESBI_IuA {
    unsigned short  length;  /* number of significant bits */
    unsigned char   value[16];
} OMAP3_UESBI_IuA;

// See 3GPP TS 25.413
typedef struct OMAP3_UESBI_IuB {
    unsigned short  length;  /* number of significant bits */
    unsigned char   value[16];
} OMAP3_UESBI_IuB;

	// exception handling: reception of unknown bit assignments in the
	// RequestedEquipmentInfo data type shall be discarded by the receiver 
typedef struct OMAP3_UESBI_Iu {
    unsigned char   bit_mask;
#       define      OMAP3_uesbi_IuA_present 0x80
#       define      OMAP3_uesbi_IuB_present 0x40
    OMAP3_UESBI_IuA uesbi_IuA;  /* optional; set in bit_mask
                                 * OMAP3_uesbi_IuA_present if present */
    OMAP3_UESBI_IuB uesbi_IuB;  /* optional; set in bit_mask
                                 * OMAP3_uesbi_IuB_present if present */
} OMAP3_UESBI_Iu;

	// exception handling:
	// received values in range 2-31 shall be treated as "old"
	// received values greater than 31 shall be treated as "new"
typedef struct OMAP3_PrepareHO_Arg {
    unsigned int    bit_mask;
#       define      OMAP3_PrepareHO_Arg_targetCellId_present 0x80000000
#       define      OMAP3_ho_NumberNotRequired_present 0x40000000
#       define      OMAP3_PrepareHO_Arg_targetRNCId_present 0x20000000
#       define      OMAP3_PrepareHO_Arg_an_APDU_present 0x10000000
#       define      OMAP3_multipleBearerRequested_present 0x08000000
#       define      OMAP3_PrepareHO_Arg_imsi_present 0x04000000
#       define      OMAP3_PrepareHO_Arg_integrityProtectionInfo_present 0x02000000
#       define      OMAP3_PrepareHO_Arg_encryptionInfo_present 0x01000000
#       define      OMAP3_PrepareHO_Arg_radioResourceInformation_present 0x00800000
#       define      OMAP3_PrepareHO_Arg_allowedGSM_Algorithms_present 0x00400000
#       define      OMAP3_PrepareHO_Arg_allowedUMTS_Algorithms_present 0x00200000
#       define      OMAP3_PrepareHO_Arg_radioResourceList_present 0x00100000
#       define      OMAP3_PrepareHO_Arg_extensionContainer_present 0x00080000
#       define      OMAP3_rab_Id_present 0x00040000
#       define      OMAP3_PrepareHO_Arg_bssmap_ServiceHandover_present 0x00020000
#       define      OMAP3_PrepareHO_Arg_ranap_ServiceHandover_present 0x00010000
#       define      OMAP3_PrepareHO_Arg_bssmap_ServiceHandoverList_present 0x00008000
#       define      OMAP3_asciCallReference_present 0x00004000
#       define      OMAP3_PrepareHO_Arg_geran_classmark_present 0x00002000
#       define      OMAP3_iuCurrentlyUsedCodec_present 0x00001000
#       define      OMAP3_PrepareHO_Arg_iuSupportedCodecsList_present 0x00000800
#       define      OMAP3_PrepareHO_Arg_rab_ConfigurationIndicator_present 0x00000400
#       define      OMAP3_uesbi_Iu_present 0x00000200
#       define      OMAP3_imeisv_present 0x00000100
#       define      OMAP3_PrepareHO_Arg_alternativeChannelType_present 0x00000080
#       define      OMAP3_PrepareHO_Arg_traceReference2_present 0x00000040
#       define      OMAP3_PrepareHO_Arg_tracePropagationParameters_present 0x00000020
    OMAP3_GlobalCellId targetCellId;  /* optional; set in bit_mask
                                  * OMAP3_PrepareHO_Arg_targetCellId_present if
                                  * present */
    Nulltype        ho_NumberNotRequired;  /* optional; set in bit_mask
                                            * OMAP3_ho_NumberNotRequired_present
                                            * if present */
    OMAP3_RNCId     targetRNCId;  /* optional; set in bit_mask
                                   * OMAP3_PrepareHO_Arg_targetRNCId_present if
                                   * present */
    OMAP3_AccessNetworkSignalInfo an_APDU;  /* optional; set in bit_mask
                                       * OMAP3_PrepareHO_Arg_an_APDU_present if
                                       * present */
    Nulltype        multipleBearerRequested;  /* optional; set in bit_mask
                                     * OMAP3_multipleBearerRequested_present if
                                     * present */
    OMAP3_IMSI      imsi;  /* optional; set in bit_mask
                            * OMAP3_PrepareHO_Arg_imsi_present if present */
    OMAP3_IntegrityProtectionInformation integrityProtectionInfo;  /* optional;
                                   * set in bit_mask
                       * OMAP3_PrepareHO_Arg_integrityProtectionInfo_present if
                       * present */
    OMAP3_EncryptionInformation encryptionInfo;  /* optional; set in bit_mask
                                * OMAP3_PrepareHO_Arg_encryptionInfo_present if
                                * present */
    OMAP3_RadioResourceInformation radioResourceInformation;  /* optional; set
                                   * in bit_mask
                      * OMAP3_PrepareHO_Arg_radioResourceInformation_present if
                      * present */
    OMAP3_AllowedGSM_Algorithms allowedGSM_Algorithms;  /* optional; set in
                                   * bit_mask
                         * OMAP3_PrepareHO_Arg_allowedGSM_Algorithms_present if
                         * present */
    OMAP3_AllowedUMTS_Algorithms allowedUMTS_Algorithms;  /* optional; set in
                                   * bit_mask
                        * OMAP3_PrepareHO_Arg_allowedUMTS_Algorithms_present if
                        * present */
    OMAP3_RadioResourceList radioResourceList;  /* optional; set in bit_mask
                             * OMAP3_PrepareHO_Arg_radioResourceList_present if
                             * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                            * OMAP3_PrepareHO_Arg_extensionContainer_present if
                            * present */
    OMAP3_RAB_Id    rab_Id;  /* extension #1; optional; set in bit_mask
                              * OMAP3_rab_Id_present if present */
    OMAP3_BSSMAP_ServiceHandover bssmap_ServiceHandover;  /* extension #2;
                                   * optional; set in bit_mask
                        * OMAP3_PrepareHO_Arg_bssmap_ServiceHandover_present if
                        * present */
    OMAP3_RANAP_ServiceHandover ranap_ServiceHandover;  /* extension #3;
                                   * optional; set in bit_mask
                         * OMAP3_PrepareHO_Arg_ranap_ServiceHandover_present if
                         * present */
    OMAP3_BSSMAP_ServiceHandoverList bssmap_ServiceHandoverList;  /* extension
                                   * #4; optional; set in bit_mask
                    * OMAP3_PrepareHO_Arg_bssmap_ServiceHandoverList_present if
                    * present */
    OMAP3_ASCI_CallReference asciCallReference;  /* extension #5; optional; set
                                   * in bit_mask OMAP3_asciCallReference_present
                                   * if present */
    OMAP3_GERAN_Classmark geran_classmark;  /* extension #6; optional; set in
                                   * bit_mask
                                   * OMAP3_PrepareHO_Arg_geran_classmark_present
                                   * if present */
    OMAP3_Codec     iuCurrentlyUsedCodec;  /* extension #7; optional; set in
                                   * bit_mask OMAP3_iuCurrentlyUsedCodec_present
                                   * if present */
    OMAP3_SupportedCodecsList iuSupportedCodecsList;  /* extension #8; optional;
                                   * set in bit_mask
                         * OMAP3_PrepareHO_Arg_iuSupportedCodecsList_present if
                         * present */
    Nulltype        rab_ConfigurationIndicator;  /* extension #9; optional; set
                                   * in bit_mask
                    * OMAP3_PrepareHO_Arg_rab_ConfigurationIndicator_present if
                    * present */
    OMAP3_UESBI_Iu  uesbi_Iu;  /* extension #10; optional; set in bit_mask
                                * OMAP3_uesbi_Iu_present if present */
    OMAP3_IMEI      imeisv;  /* extension #11; optional; set in bit_mask
                              * OMAP3_imeisv_present if present */
    OMAP3_RadioResourceInformation alternativeChannelType;  /* extension #12;
                                   * optional; set in bit_mask
                        * OMAP3_PrepareHO_Arg_alternativeChannelType_present if
                        * present */
    OMAP3_TraceReference2 traceReference2;  /* extension #13; optional; set in
                                   * bit_mask
                                   * OMAP3_PrepareHO_Arg_traceReference2_present
                                   * if present */
    OMAP3_TracePropagationParameters tracePropagationParameters;  /* extension
                                   * #14; optional; set in bit_mask
                    * OMAP3_PrepareHO_Arg_tracePropagationParameters_present if
                    * present */
} OMAP3_PrepareHO_Arg;

typedef struct OMAP3_RelocationNumber {
    OMAP3_ISDN_AddressString handoverNumber;
    OMAP3_RAB_Id    rab_Id;
	// RAB Identity is needed to relate the calls with the radio access bearers. 
} OMAP3_RelocationNumber;

	// The internal structure is defined as follows:
	// octet 1 bits 4321	Mobile Country Code 1st digit
	//         bits 8765	Mobile Country Code 2nd digit
	// octet 2 bits 4321	Mobile Country Code 3rd digit
	//         bits 8765	Mobile Network Code 3rd digit
	//			or filler (1111) for 2 digit MNCs
	// octet 3 bits 4321	Mobile Network Code 1st digit
	//         bits 8765	Mobile Network Code 2nd digit
	// octets 4 and 5	Location Area Code according to 3GPP TS 24.008
	// octets 6 and 7	RNC Id value according to 3GPP TS 25.413
typedef struct OMAP3_RelocationNumberList {
    unsigned short  count;
    OMAP3_RelocationNumber value[7];
} OMAP3_RelocationNumberList;

typedef unsigned short  OMAP3_MulticallBearerInfo;

typedef struct OMAP3_ChosenIntegrityProtectionAlgorithm {
    unsigned short  length;
    unsigned char   value[1];
} OMAP3_ChosenIntegrityProtectionAlgorithm;

	// Octet contains a complete IntegrityProtectionAlgorithm data type 
	// as defined in 3GPP TS 25.413, encoded according to the encoding scheme 
	// mandated by 3GPP TS 25.413
	// Padding bits are included in the least significant bits. 
typedef struct OMAP3_ChosenEncryptionAlgorithm {
    unsigned short  length;
    unsigned char   value[1];
} OMAP3_ChosenEncryptionAlgorithm;

typedef struct OMAP3_SelectedUMTS_Algorithms {
    unsigned char   bit_mask;
#       define      OMAP3_integrityProtectionAlgorithm_present 0x80
#       define      OMAP3_encryptionAlgorithm_present 0x40
#       define      OMAP3_SelectedUMTS_Algorithms_extensionContainer_present 0x20
    OMAP3_ChosenIntegrityProtectionAlgorithm integrityProtectionAlgorithm;  
                                        /* optional; set in bit_mask
                                * OMAP3_integrityProtectionAlgorithm_present if
                                * present */
    OMAP3_ChosenEncryptionAlgorithm encryptionAlgorithm;  /* optional; set in
                                   * bit_mask OMAP3_encryptionAlgorithm_present
                                   * if present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                  * OMAP3_SelectedUMTS_Algorithms_extensionContainer_present if
                  * present */
} OMAP3_SelectedUMTS_Algorithms;

typedef struct OMAP3_ChosenChannelInfo {
    unsigned short  length;
    unsigned char   value[1];
} OMAP3_ChosenChannelInfo;

	// Octets are coded according the Chosen Channel information element in 3GPP TS 48.008
typedef struct OMAP3_ChosenSpeechVersion {
    unsigned short  length;
    unsigned char   value[1];
} OMAP3_ChosenSpeechVersion;

	// Octet contains a complete EncryptionAlgorithm data type 
	// as defined in 3GPP TS 25.413, encoded according to the encoding scheme 
	// mandated by 3GPP TS 25.413
	// Padding bits are included in the least significant bits. 
typedef struct OMAP3_ChosenRadioResourceInformation {
    unsigned char   bit_mask;
#       define      OMAP3_chosenChannelInfo_present 0x80
#       define      OMAP3_chosenSpeechVersion_present 0x40
    OMAP3_ChosenChannelInfo chosenChannelInfo;  /* optional; set in bit_mask
                                           * OMAP3_chosenChannelInfo_present if
                                           * present */
    OMAP3_ChosenSpeechVersion chosenSpeechVersion;  /* optional; set in bit_mask
                                         * OMAP3_chosenSpeechVersion_present if
                                         * present */
} OMAP3_ChosenRadioResourceInformation;

typedef struct OMAP3_PrepareHO_Res {
    unsigned short  bit_mask;
#       define      OMAP3_handoverNumber_present 0x8000
#       define      OMAP3_relocationNumberList_present 0x4000
#       define      OMAP3_PrepareHO_Res_an_APDU_present 0x2000
#       define      OMAP3_multicallBearerInfo_present 0x1000
#       define      OMAP3_multipleBearerNotSupported_present 0x0800
#       define      OMAP3_PrepareHO_Res_selectedUMTS_Algorithms_present 0x0400
#       define      OMAP3_PrepareHO_Res_chosenRadioResourceInformation_present 0x0200
#       define      OMAP3_PrepareHO_Res_extensionContainer_present 0x0100
#       define      OMAP3_PrepareHO_Res_iuSelectedCodec_present 0x0080
#       define      OMAP3_PrepareHO_Res_iuAvailableCodecsList_present 0x0040
    OMAP3_ISDN_AddressString handoverNumber;  /* optional; set in bit_mask
                                               * OMAP3_handoverNumber_present if
                                               * present */
    OMAP3_RelocationNumberList relocationNumberList;  /* optional; set in
                                   * bit_mask OMAP3_relocationNumberList_present
                                   * if present */
    OMAP3_AccessNetworkSignalInfo an_APDU;  /* optional; set in bit_mask
                                       * OMAP3_PrepareHO_Res_an_APDU_present if
                                       * present */
    OMAP3_MulticallBearerInfo multicallBearerInfo;  /* optional; set in bit_mask
                                         * OMAP3_multicallBearerInfo_present if
                                         * present */
    Nulltype        multipleBearerNotSupported;  /* optional; set in bit_mask
                                  * OMAP3_multipleBearerNotSupported_present if
                                  * present */
    OMAP3_SelectedUMTS_Algorithms selectedUMTS_Algorithms;  /* optional; set in
                                   * bit_mask
                       * OMAP3_PrepareHO_Res_selectedUMTS_Algorithms_present if
                       * present */
    OMAP3_ChosenRadioResourceInformation chosenRadioResourceInformation;  
                                        /* optional; set in bit_mask
                * OMAP3_PrepareHO_Res_chosenRadioResourceInformation_present if
                * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                            * OMAP3_PrepareHO_Res_extensionContainer_present if
                            * present */
    OMAP3_Codec     iuSelectedCodec;  /* extension #1; optional; set in bit_mask
                               * OMAP3_PrepareHO_Res_iuSelectedCodec_present if
                               * present */
    OMAP3_CodecList iuAvailableCodecsList;  /* extension #2; optional; set in
                                   * bit_mask
                         * OMAP3_PrepareHO_Res_iuAvailableCodecsList_present if
                         * present */
} OMAP3_PrepareHO_Res;

	// Octets are coded according the Speech Version (chosen) information element in 3GPP TS
	// 48.008 
typedef struct OMAP3_PrepareSubsequentHO_Arg {
    unsigned char   bit_mask;
#       define      OMAP3_PrepareSubsequentHO_Arg_targetCellId_present 0x80
#       define      OMAP3_PrepareSubsequentHO_Arg_targetRNCId_present 0x40
#       define      OMAP3_PrepareSubsequentHO_Arg_an_APDU_present 0x20
#       define      OMAP3_PrepareSubsequentHO_Arg_selectedRab_Id_present 0x10
#       define      OMAP3_PrepareSubsequentHO_Arg_extensionContainer_present 0x08
#       define      OMAP3_PrepareSubsequentHO_Arg_geran_classmark_present 0x04
#       define      OMAP3_PrepareSubsequentHO_Arg_rab_ConfigurationIndicator_present 0x02
    OMAP3_GlobalCellId targetCellId;  /* optional; set in bit_mask
                        * OMAP3_PrepareSubsequentHO_Arg_targetCellId_present if
                        * present */
    OMAP3_ISDN_AddressString targetMSC_Number;
    OMAP3_RNCId     targetRNCId;  /* optional; set in bit_mask
                         * OMAP3_PrepareSubsequentHO_Arg_targetRNCId_present if
                         * present */
    OMAP3_AccessNetworkSignalInfo an_APDU;  /* optional; set in bit_mask
                             * OMAP3_PrepareSubsequentHO_Arg_an_APDU_present if
                             * present */
    OMAP3_RAB_Id    selectedRab_Id;  /* optional; set in bit_mask
                      * OMAP3_PrepareSubsequentHO_Arg_selectedRab_Id_present if
                      * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                  * OMAP3_PrepareSubsequentHO_Arg_extensionContainer_present if
                  * present */
    OMAP3_GERAN_Classmark geran_classmark;  /* extension #1; optional; set in
                                   * bit_mask
                     * OMAP3_PrepareSubsequentHO_Arg_geran_classmark_present if
                     * present */
    Nulltype        rab_ConfigurationIndicator;  /* extension #2; optional; set
                                   * in bit_mask
          * OMAP3_PrepareSubsequentHO_Arg_rab_ConfigurationIndicator_present if
          * present */
} OMAP3_PrepareSubsequentHO_Arg;

typedef struct OMAP3_PrepareSubsequentHO_Res {
    unsigned char   bit_mask;
#       define      OMAP3_PrepareSubsequentHO_Res_extensionContainer_present 0x80
    OMAP3_AccessNetworkSignalInfo an_APDU;
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                  * OMAP3_PrepareSubsequentHO_Res_extensionContainer_present if
                  * present */
} OMAP3_PrepareSubsequentHO_Res;

	// Octets are coded according the GERAN Classmark information element in 3GPP TS 48.008
typedef struct OMAP3_SelectedGSM_Algorithm {
    unsigned short  length;
    unsigned char   value[1];
} OMAP3_SelectedGSM_Algorithm;

typedef struct OMAP3_ProcessAccessSignalling_Arg {
    unsigned char   bit_mask;
#       define      OMAP3_ProcessAccessSignalling_Arg_selectedUMTS_Algorithms_present 0x80
#       define      OMAP3_selectedGSM_Algorithm_present 0x40
#       define      OMAP3_ProcessAccessSignalling_Arg_chosenRadioResourceInformation_present 0x20
#       define      OMAP3_ProcessAccessSignalling_Arg_selectedRab_Id_present 0x10
#       define      OMAP3_ProcessAccessSignalling_Arg_extensionContainer_present 0x08
#       define      OMAP3_iUSelectedCodec_present 0x04
#       define      OMAP3_ProcessAccessSignalling_Arg_iuAvailableCodecsList_present 0x02
    OMAP3_AccessNetworkSignalInfo an_APDU;
    OMAP3_SelectedUMTS_Algorithms selectedUMTS_Algorithms;  /* optional; set in
                                   * bit_mask
         * OMAP3_ProcessAccessSignalling_Arg_selectedUMTS_Algorithms_present if
         * present */
    OMAP3_SelectedGSM_Algorithm selectedGSM_Algorithm;  /* optional; set in
                                   * bit_mask
                                   * OMAP3_selectedGSM_Algorithm_present if
                                   * present */
    OMAP3_ChosenRadioResourceInformation chosenRadioResourceInformation;  
                                        /* optional; set in bit_mask
  * OMAP3_ProcessAccessSignalling_Arg_chosenRadioResourceInformation_present if
  * present */
    OMAP3_RAB_Id    selectedRab_Id;  /* optional; set in bit_mask
                  * OMAP3_ProcessAccessSignalling_Arg_selectedRab_Id_present if
                  * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
              * OMAP3_ProcessAccessSignalling_Arg_extensionContainer_present if
              * present */
    OMAP3_Codec     iUSelectedCodec;  /* extension #1; optional; set in bit_mask
                                       * OMAP3_iUSelectedCodec_present if
                                       * present */
    OMAP3_CodecList iuAvailableCodecsList;  /* extension #2; optional; set in
                                   * bit_mask
           * OMAP3_ProcessAccessSignalling_Arg_iuAvailableCodecsList_present if
           * present */
} OMAP3_ProcessAccessSignalling_Arg;

	// internal structure is coded as Algorithm identifier octet from Chosen Encryption
	// Algorithm defined in 3GPP TS 48.008
	// A node shall mark only the selected GSM algorithm
typedef struct OMAP3_SendEndSignal_Arg {
    unsigned char   bit_mask;
#       define      OMAP3_SendEndSignal_Arg_extensionContainer_present 0x80
    OMAP3_AccessNetworkSignalInfo an_APDU;
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                        * OMAP3_SendEndSignal_Arg_extensionContainer_present if
                        * present */
} OMAP3_SendEndSignal_Arg;

typedef struct OMAP3_SendEndSignal_Res {
    unsigned char   bit_mask;
#       define      OMAP3_SendEndSignal_Res_extensionContainer_present 0x80
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                        * OMAP3_SendEndSignal_Res_extensionContainer_present if
                        * present */
} OMAP3_SendEndSignal_Res;

typedef struct OMAP3_Re_synchronisationInfo {
    OMAP3_RAND      rand;
    OMAP3_AUTS      auts;
} OMAP3_Re_synchronisationInfo;

typedef enum OMAP3_RequestingNodeType {
    OMAP3_RequestingNodeType_vlr = 0,
    OMAP3_RequestingNodeType_sgsn = 1
} OMAP3_RequestingNodeType;

typedef struct OMAP3_PLMN_Id {
    unsigned short  length;
    unsigned char   value[3];
} OMAP3_PLMN_Id;

typedef struct OMAP3_SendAuthenticationInfoArg {
    unsigned char   bit_mask;
#       define      OMAP3_SendAuthenticationInfoArg_segmentationProhibited_present 0x80
#       define      OMAP3_immediateResponsePreferred_present 0x40
#       define      OMAP3_re_synchronisationInfo_present 0x20
#       define      OMAP3_SendAuthenticationInfoArg_extensionContainer_present 0x10
#       define      OMAP3_requestingNodeType_present 0x08
#       define      OMAP3_requestingPLMN_Id_present 0x04
    OMAP3_IMSI      imsi;
    OMAP3_NumberOfRequestedVectors numberOfRequestedVectors;
    Nulltype        segmentationProhibited;  /* optional; set in bit_mask
            * OMAP3_SendAuthenticationInfoArg_segmentationProhibited_present if
            * present */
    Nulltype        immediateResponsePreferred;  /* optional; set in bit_mask
                                  * OMAP3_immediateResponsePreferred_present if
                                  * present */
    OMAP3_Re_synchronisationInfo re_synchronisationInfo;  /* optional; set in
                                   * bit_mask
                                   * OMAP3_re_synchronisationInfo_present if
                                   * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                * OMAP3_SendAuthenticationInfoArg_extensionContainer_present if
                * present */
    OMAP3_RequestingNodeType requestingNodeType;  /* extension #1; optional; set
                                   * in bit_mask
                                   * OMAP3_requestingNodeType_present if
                                   * present */
    OMAP3_PLMN_Id   requestingPLMN_Id;  /* extension #2; optional; set in
                                   * bit_mask OMAP3_requestingPLMN_Id_present if
                                   * present */
} OMAP3_SendAuthenticationInfoArg;

typedef struct OMAP3_SendAuthenticationInfoRes {
    unsigned char   bit_mask;
#       define      OMAP3_SendAuthenticationInfoRes_authenticationSetList_present 0x80
#       define      OMAP3_SendAuthenticationInfoRes_extensionContainer_present 0x40
    OMAP3_AuthenticationSetList authenticationSetList;  /* optional; set in
                                   * bit_mask
             * OMAP3_SendAuthenticationInfoRes_authenticationSetList_present if
             * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                * OMAP3_SendAuthenticationInfoRes_extensionContainer_present if
                * present */
} OMAP3_SendAuthenticationInfoRes;

typedef struct OMAP3_RequestedEquipmentInfo {
    unsigned short  length;  /* number of significant bits */
    unsigned char   value[1];
} OMAP3_RequestedEquipmentInfo;
#define                     OMAP3_RequestedEquipmentInfo_equipmentStatus 0x80
#define                     OMAP3_RequestedEquipmentInfo_equipmentStatus_byte 0
#define                     OMAP3_RequestedEquipmentInfo_bmuef 0x40
#define                     OMAP3_RequestedEquipmentInfo_bmuef_byte 0

	// exception handling:
	// received values in the range 2-15 shall be treated as "vlr"
	// received values greater than 15 shall be treated as "sgsn"
// equipment management types
typedef struct OMAP3_CheckIMEI_Arg {
    unsigned char   bit_mask;
#       define      OMAP3_CheckIMEI_Arg_extensionContainer_present 0x80
    OMAP3_IMEI      imei;
    OMAP3_RequestedEquipmentInfo requestedEquipmentInfo;
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                            * OMAP3_CheckIMEI_Arg_extensionContainer_present if
                            * present */
} OMAP3_CheckIMEI_Arg;

// See 3GPP TS 25.413
typedef enum OMAP3_EquipmentStatus {
    OMAP3_whiteListed = 0,
    OMAP3_blackListed = 1,
    OMAP3_greyListed = 2
} OMAP3_EquipmentStatus;

typedef struct OMAP3_CheckIMEI_Res {
    unsigned char   bit_mask;
#       define      OMAP3_equipmentStatus_present 0x80
#       define      OMAP3_bmuef_present 0x40
#       define      OMAP3_CheckIMEI_Res_extensionContainer_present 0x20
    OMAP3_EquipmentStatus equipmentStatus;  /* optional; set in bit_mask
                                             * OMAP3_equipmentStatus_present if
                                             * present */
    OMAP3_UESBI_Iu  bmuef;  /* optional; set in bit_mask OMAP3_bmuef_present if
                             * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                            * OMAP3_CheckIMEI_Res_extensionContainer_present if
                            * present */
} OMAP3_CheckIMEI_Res;

typedef struct OMAP3_Category {
    unsigned short  length;
    unsigned char   value[1];
} OMAP3_Category;

	// The internal structure is defined in ITU-T Rec Q.763.
typedef enum OMAP3_SubscriberStatus {
    OMAP3_serviceGranted = 0,
    OMAP3_SubscriberStatus_operatorDeterminedBarring = 1
} OMAP3_SubscriberStatus;

typedef struct OMAP3_BearerServiceList {
    unsigned short  count;
    OMAP3_Ext_BearerServiceCode value[50];
} OMAP3_BearerServiceList;

typedef struct OMAP3_TeleserviceList {
    unsigned short  count;
    OMAP3_Ext_TeleserviceCode value[20];
} OMAP3_TeleserviceList;

typedef struct OMAP3_Ext_ForwOptions {
    unsigned short  length;
    unsigned char   value[5];
} OMAP3_Ext_ForwOptions;

	// OCTET 1:

	//  bit 8: notification to forwarding party
	//	0  no notification
	//	1  notification

	//  bit 7: redirecting presentation
	//	0 no presentation  
	//	1  presentation

	//  bit 6: notification to calling party
	//	0  no notification
	//	1  notification

	//  bit 5: 0 (unused)

	//  bits 43: forwarding reason
	//	00  ms not reachable
	//	01  ms busy
	//	10  no reply
	//	11  unconditional

	// bits 21: 00 (unused)

	// OCTETS 2-5: reserved for future use. They shall be discarded if
	// received and not understood.
typedef unsigned short  OMAP3_Ext_NoRepCondTime;

typedef struct OMAP3_Ext_ForwFeature {
    unsigned char   bit_mask;
#       define      OMAP3_Ext_ForwFeature_basicService_present 0x80
#       define      OMAP3_Ext_ForwFeature_forwardedToNumber_present 0x40
#       define      OMAP3_Ext_ForwFeature_forwardedToSubaddress_present 0x20
#       define      OMAP3_Ext_ForwFeature_forwardingOptions_present 0x10
#       define      OMAP3_Ext_ForwFeature_noReplyConditionTime_present 0x08
#       define      OMAP3_Ext_ForwFeature_extensionContainer_present 0x04
#       define      OMAP3_Ext_ForwFeature_longForwardedToNumber_present 0x02
    OMAP3_Ext_BasicServiceCode basicService;  /* optional; set in bit_mask
                                * OMAP3_Ext_ForwFeature_basicService_present if
                                * present */
    OMAP3_Ext_SS_Status ss_Status;
    OMAP3_ISDN_AddressString forwardedToNumber;  /* optional; set in bit_mask
                           * OMAP3_Ext_ForwFeature_forwardedToNumber_present if
                           * present */
	// When this data type is sent from an HLR which supports CAMEL Phase 2
	// to a VLR that supports CAMEL Phase 2 the VLR shall not check the
	// format of the number
    OMAP3_ISDN_SubaddressString forwardedToSubaddress;  /* optional; set in
                                   * bit_mask
                       * OMAP3_Ext_ForwFeature_forwardedToSubaddress_present if
                       * present */
    OMAP3_Ext_ForwOptions forwardingOptions;  /* optional; set in bit_mask
                           * OMAP3_Ext_ForwFeature_forwardingOptions_present if
                           * present */
    OMAP3_Ext_NoRepCondTime noReplyConditionTime;  /* optional; set in bit_mask
                        * OMAP3_Ext_ForwFeature_noReplyConditionTime_present if
                        * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                          * OMAP3_Ext_ForwFeature_extensionContainer_present if
                          * present */
    OMAP3_FTN_AddressString longForwardedToNumber;  /* extension #1; optional;
                                   * set in bit_mask
                       * OMAP3_Ext_ForwFeature_longForwardedToNumber_present if
                       * present */
} OMAP3_Ext_ForwFeature;

typedef struct OMAP3_Ext_ForwFeatureList {
    unsigned short  count;
    OMAP3_Ext_ForwFeature value[32];
} OMAP3_Ext_ForwFeatureList;

typedef struct OMAP3_Ext_ForwInfo {
    unsigned char   bit_mask;
#       define      OMAP3_Ext_ForwInfo_extensionContainer_present 0x80
    OMAP3_SS_Code   ss_Code;
    OMAP3_Ext_ForwFeatureList forwardingFeatureList;
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                             * OMAP3_Ext_ForwInfo_extensionContainer_present if
                             * present */
} OMAP3_Ext_ForwInfo;

typedef struct OMAP3_Ext_CallBarringFeature {
    unsigned char   bit_mask;
#       define      OMAP3_Ext_CallBarringFeature_basicService_present 0x80
#       define      OMAP3_Ext_CallBarringFeature_extensionContainer_present 0x40
    OMAP3_Ext_BasicServiceCode basicService;  /* optional; set in bit_mask
                         * OMAP3_Ext_CallBarringFeature_basicService_present if
                         * present */
    OMAP3_Ext_SS_Status ss_Status;
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                   * OMAP3_Ext_CallBarringFeature_extensionContainer_present if
                   * present */
} OMAP3_Ext_CallBarringFeature;

typedef struct OMAP3_Ext_CallBarFeatureList {
    unsigned short  count;
    OMAP3_Ext_CallBarringFeature value[32];
} OMAP3_Ext_CallBarFeatureList;

	// Only values 5-30 are used.
	// Values in the ranges 1-4 and 31-100 are reserved for future use
	// If received:
	//		values 1-4 shall be mapped on to value 5
	//		values 31-100 shall be mapped on to value 30
typedef struct OMAP3_Ext_CallBarInfo {
    unsigned char   bit_mask;
#       define      OMAP3_Ext_CallBarInfo_extensionContainer_present 0x80
    OMAP3_SS_Code   ss_Code;
    OMAP3_Ext_CallBarFeatureList callBarringFeatureList;
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                          * OMAP3_Ext_CallBarInfo_extensionContainer_present if
                          * present */
} OMAP3_Ext_CallBarInfo;

typedef unsigned short  OMAP3_CUG_Index;

typedef enum OMAP3_IntraCUG_Options {
    OMAP3_noCUG_Restrictions = 0,
    OMAP3_cugIC_CallBarred = 1,
    OMAP3_cugOG_CallBarred = 2
} OMAP3_IntraCUG_Options;

typedef struct OMAP3_Ext_BasicServiceGroupList {
    unsigned short  count;
    OMAP3_Ext_BasicServiceCode value[32];
} OMAP3_Ext_BasicServiceGroupList;

typedef struct OMAP3_CUG_Subscription {
    unsigned char   bit_mask;
#       define      OMAP3_CUG_Subscription_basicServiceGroupList_present 0x80
#       define      OMAP3_CUG_Subscription_extensionContainer_present 0x40
    OMAP3_CUG_Index cug_Index;
    OMAP3_CUG_Interlock cug_Interlock;
    OMAP3_IntraCUG_Options intraCUG_Options;
    OMAP3_Ext_BasicServiceGroupList basicServiceGroupList;  /* optional; set in
                                   * bit_mask
                      * OMAP3_CUG_Subscription_basicServiceGroupList_present if
                      * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                         * OMAP3_CUG_Subscription_extensionContainer_present if
                         * present */
} OMAP3_CUG_Subscription;

typedef struct OMAP3_CUG_SubscriptionList {
    unsigned short  count;
    OMAP3_CUG_Subscription value[10];
} OMAP3_CUG_SubscriptionList;

typedef struct OMAP3_InterCUG_Restrictions {
    unsigned short  length;
    unsigned char   value[1];
} OMAP3_InterCUG_Restrictions;

typedef struct OMAP3_CUG_Feature {
    unsigned char   bit_mask;
#       define      OMAP3_CUG_Feature_basicService_present 0x80
#       define      OMAP3_preferentialCUG_Indicator_present 0x40
#       define      OMAP3_CUG_Feature_extensionContainer_present 0x20
    OMAP3_Ext_BasicServiceCode basicService;  /* optional; set in bit_mask
                                    * OMAP3_CUG_Feature_basicService_present if
                                    * present */
    OMAP3_CUG_Index preferentialCUG_Indicator;  /* optional; set in bit_mask
                                   * OMAP3_preferentialCUG_Indicator_present if
                                   * present */
    OMAP3_InterCUG_Restrictions interCUG_Restrictions;
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                              * OMAP3_CUG_Feature_extensionContainer_present if
                              * present */
} OMAP3_CUG_Feature;

typedef struct OMAP3_CUG_FeatureList {
    unsigned short  count;
    OMAP3_CUG_Feature value[32];
} OMAP3_CUG_FeatureList;

typedef struct OMAP3_CUG_Info {
    unsigned char   bit_mask;
#       define      OMAP3_cug_FeatureList_present 0x80
#       define      OMAP3_CUG_Info_extensionContainer_present 0x40
    OMAP3_CUG_SubscriptionList cug_SubscriptionList;
    OMAP3_CUG_FeatureList cug_FeatureList;  /* optional; set in bit_mask
                                             * OMAP3_cug_FeatureList_present if
                                             * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                                 * OMAP3_CUG_Info_extensionContainer_present if
                                 * present */
} OMAP3_CUG_Info;

	// bits 876543: 000000 (unused)
	// Exception handling:
	// bits 876543 shall be ignored if received and not understood

	// bits 21
	//	00  CUG only facilities
	//	01  CUG with outgoing access
	//	10  CUG with incoming access
	//	11  CUG with both outgoing and incoming access
typedef struct OMAP3_Ext_SS_Data {
    unsigned char   bit_mask;
#       define      OMAP3_Ext_SS_Data_ss_SubscriptionOption_present 0x80
#       define      OMAP3_Ext_SS_Data_basicServiceGroupList_present 0x40
#       define      OMAP3_Ext_SS_Data_extensionContainer_present 0x20
    OMAP3_SS_Code   ss_Code;
    OMAP3_Ext_SS_Status ss_Status;
    OMAP3_SS_SubscriptionOption ss_SubscriptionOption;  /* optional; set in
                                   * bit_mask
                           * OMAP3_Ext_SS_Data_ss_SubscriptionOption_present if
                           * present */
    OMAP3_Ext_BasicServiceGroupList basicServiceGroupList;  /* optional; set in
                                   * bit_mask
                           * OMAP3_Ext_SS_Data_basicServiceGroupList_present if
                           * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                              * OMAP3_Ext_SS_Data_extensionContainer_present if
                              * present */
} OMAP3_Ext_SS_Data;

typedef struct OMAP3_Ext_SS_Info {
    unsigned short  choice;
#       define      OMAP3_Ext_SS_Info_forwardingInfo_chosen 1
#       define      OMAP3_Ext_SS_Info_callBarringInfo_chosen 2
#       define      OMAP3_cug_Info_chosen 3
#       define      OMAP3_Ext_SS_Info_ss_Data_chosen 4
#       define      OMAP3_emlpp_Info_chosen 5
    union _union {
        OMAP3_Ext_ForwInfo forwardingInfo;  /* to choose, set choice to
                                   * OMAP3_Ext_SS_Info_forwardingInfo_chosen */
        OMAP3_Ext_CallBarInfo callBarringInfo;  /* to choose, set choice to
                                  * OMAP3_Ext_SS_Info_callBarringInfo_chosen */
        OMAP3_CUG_Info  cug_Info;  /* to choose, set choice to
                                    * OMAP3_cug_Info_chosen */
        OMAP3_Ext_SS_Data ss_Data;  /* to choose, set choice to
                                     * OMAP3_Ext_SS_Info_ss_Data_chosen */
        OMAP3_EMLPP_Info emlpp_Info;  /* to choose, set choice to
                                       * OMAP3_emlpp_Info_chosen */
    } u;
} OMAP3_Ext_SS_Info;

	// exception handling: reception of unknown bit assignments in the
	// ODB-HPLMN-Data type shall be treated like unsupported ODB-HPLMN-Data 
	// When the ODB-HPLMN-Data type is removed from the HLR for a given subscriber, 
	// in NoteSubscriberDataModified operation sent toward the gsmSCF
	// all bits shall be set to .O..
typedef struct OMAP3_Ext_SS_InfoList {
    unsigned short  count;
    OMAP3_Ext_SS_Info value[30];
} OMAP3_Ext_SS_InfoList;

typedef struct OMAP3_ODB_GeneralData {
    unsigned short  length;  /* number of significant bits */
    unsigned char   value[4];
} OMAP3_ODB_GeneralData;
#define                     OMAP3_allOG_CallsBarred 0x80
#define                     OMAP3_allOG_CallsBarred_byte 0
#define                     OMAP3_internationalOGCallsBarred 0x40
#define                     OMAP3_internationalOGCallsBarred_byte 0
#define                     OMAP3_internationalOGCallsNotToHPLMN_CountryBarred 0x20
#define                     OMAP3_internationalOGCallsNotToHPLMN_CountryBarred_byte 0
#define                     OMAP3_premiumRateInformationOGCallsBarred 0x10
#define                     OMAP3_premiumRateInformationOGCallsBarred_byte 0
#define                     OMAP3_premiumRateEntertainementOGCallsBarred 0x08
#define                     OMAP3_premiumRateEntertainementOGCallsBarred_byte 0
#define                     OMAP3_ss_AccessBarred 0x04
#define                     OMAP3_ss_AccessBarred_byte 0
#define                     OMAP3_interzonalOGCallsBarred 0x02
#define                     OMAP3_interzonalOGCallsBarred_byte 0
#define                     OMAP3_interzonalOGCallsNotToHPLMN_CountryBarred 0x01
#define                     OMAP3_interzonalOGCallsNotToHPLMN_CountryBarred_byte 0
#define                     OMAP3_interzonalOGCallsAndInternationalOGCallsNotToHPLMN_CountryBarred 0x80
#define                     OMAP3_interzonalOGCallsAndInternationalOGCallsNotToHPLMN_CountryBarred_byte 1
#define                     OMAP3_allECT_Barred 0x40
#define                     OMAP3_allECT_Barred_byte 1
#define                     OMAP3_chargeableECT_Barred 0x20
#define                     OMAP3_chargeableECT_Barred_byte 1
#define                     OMAP3_internationalECT_Barred 0x10
#define                     OMAP3_internationalECT_Barred_byte 1
#define                     OMAP3_interzonalECT_Barred 0x08
#define                     OMAP3_interzonalECT_Barred_byte 1
#define                     OMAP3_doublyChargeableECT_Barred 0x04
#define                     OMAP3_doublyChargeableECT_Barred_byte 1
#define                     OMAP3_multipleECT_Barred 0x02
#define                     OMAP3_multipleECT_Barred_byte 1
#define                     OMAP3_allPacketOrientedServicesBarred 0x01
#define                     OMAP3_allPacketOrientedServicesBarred_byte 1
#define                     OMAP3_roamerAccessToHPLMN_AP_Barred 0x80
#define                     OMAP3_roamerAccessToHPLMN_AP_Barred_byte 2
#define                     OMAP3_roamerAccessToVPLMN_AP_Barred 0x40
#define                     OMAP3_roamerAccessToVPLMN_AP_Barred_byte 2
#define                     OMAP3_roamingOutsidePLMNOG_CallsBarred 0x20
#define                     OMAP3_roamingOutsidePLMNOG_CallsBarred_byte 2
#define                     OMAP3_allIC_CallsBarred 0x10
#define                     OMAP3_allIC_CallsBarred_byte 2
#define                     OMAP3_roamingOutsidePLMNIC_CallsBarred 0x08
#define                     OMAP3_roamingOutsidePLMNIC_CallsBarred_byte 2
#define                     OMAP3_roamingOutsidePLMNICountryIC_CallsBarred 0x04
#define                     OMAP3_roamingOutsidePLMNICountryIC_CallsBarred_byte 2
#define                     OMAP3_roamingOutsidePLMN_Barred 0x02
#define                     OMAP3_roamingOutsidePLMN_Barred_byte 2
#define                     OMAP3_roamingOutsidePLMN_CountryBarred 0x01
#define                     OMAP3_roamingOutsidePLMN_CountryBarred_byte 2
#define                     OMAP3_registrationAllCF_Barred 0x80
#define                     OMAP3_registrationAllCF_Barred_byte 3
#define                     OMAP3_registrationCFNotToHPLMN_Barred 0x40
#define                     OMAP3_registrationCFNotToHPLMN_Barred_byte 3
#define                     OMAP3_registrationInterzonalCF_Barred 0x20
#define                     OMAP3_registrationInterzonalCF_Barred_byte 3
#define                     OMAP3_registrationInterzonalCFNotToHPLMN_Barred 0x10
#define                     OMAP3_registrationInterzonalCFNotToHPLMN_Barred_byte 3
#define                     OMAP3_registrationInternationalCF_Barred 0x08
#define                     OMAP3_registrationInternationalCF_Barred_byte 3

	// exception handling: reception of unknown bit assignments in the
	// ODB-GeneralData type shall be treated like unsupported ODB-GeneralData
	// When the ODB-GeneralData type is removed from the HLR for a given subscriber, 
	// in NoteSubscriberDataModified operation sent toward the gsmSCF 
	// all bits shall be set to .O..
typedef struct OMAP3_ODB_HPLMN_Data {
    unsigned short  length;  /* number of significant bits */
    unsigned char   value[4];
} OMAP3_ODB_HPLMN_Data;
#define                     OMAP3_plmn_SpecificBarringType1 0x80
#define                     OMAP3_plmn_SpecificBarringType1_byte 0
#define                     OMAP3_plmn_SpecificBarringType2 0x40
#define                     OMAP3_plmn_SpecificBarringType2_byte 0
#define                     OMAP3_plmn_SpecificBarringType3 0x20
#define                     OMAP3_plmn_SpecificBarringType3_byte 0
#define                     OMAP3_plmn_SpecificBarringType4 0x10
#define                     OMAP3_plmn_SpecificBarringType4_byte 0

typedef struct OMAP3_ODB_Data {
    unsigned char   bit_mask;
#       define      OMAP3_odb_HPLMN_Data_present 0x80
#       define      OMAP3_ODB_Data_extensionContainer_present 0x40
    OMAP3_ODB_GeneralData odb_GeneralData;
    OMAP3_ODB_HPLMN_Data odb_HPLMN_Data;  /* optional; set in bit_mask
                                           * OMAP3_odb_HPLMN_Data_present if
                                           * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                                 * OMAP3_ODB_Data_extensionContainer_present if
                                 * present */
} OMAP3_ODB_Data;

typedef struct OMAP3_ZoneCode {
    unsigned short  length;
    unsigned char   value[2];
} OMAP3_ZoneCode;

typedef struct OMAP3_ZoneCodeList {
    unsigned short  count;
    OMAP3_ZoneCode  value[10];
} OMAP3_ZoneCodeList;

typedef struct OMAP3_GroupId {
    unsigned short  length;
    unsigned char   value[3];
} OMAP3_GroupId;

// Other bits than listed above shall be discarded.
typedef struct OMAP3_VoiceBroadcastData {
    unsigned char   bit_mask;
#       define      OMAP3_broadcastInitEntitlement_present 0x80
#       define      OMAP3_VoiceBroadcastData_extensionContainer_present 0x40
    OMAP3_GroupId   groupid;
    Nulltype        broadcastInitEntitlement;  /* optional; set in bit_mask
                                    * OMAP3_broadcastInitEntitlement_present if
                                    * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                       * OMAP3_VoiceBroadcastData_extensionContainer_present if
                       * present */
} OMAP3_VoiceBroadcastData;

// VBS/VGCS types
typedef struct OMAP3_VBSDataList {
    unsigned short  count;
    OMAP3_VoiceBroadcastData value[50];
} OMAP3_VBSDataList;

//	 Refers to Additional Info as specified in 3GPP TS 43.068 
typedef struct OMAP3_AdditionalSubscriptions {
    unsigned short  length;  /* number of significant bits */
    unsigned char   value[1];
} OMAP3_AdditionalSubscriptions;
#define                     OMAP3_privilegedUplinkRequest 0x80
#define                     OMAP3_privilegedUplinkRequest_byte 0
#define                     OMAP3_emergencyUplinkRequest 0x40
#define                     OMAP3_emergencyUplinkRequest_byte 0
#define                     OMAP3_emergencyReset 0x20
#define                     OMAP3_emergencyReset_byte 0

	// When Group-Id is less than six characters in length, the TBCD filler (1111)
	// is used to fill unused half octets.
	// Refers to the Group Identification as specified in 3GPP TS 23.003 
	// and 3GPP TS 43.068/ 43.069

// provide subscriber info types
typedef struct OMAP3_Long_GroupId {
    unsigned short  length;
    unsigned char   value[4];
} OMAP3_Long_GroupId;

typedef struct OMAP3_VoiceGroupCallData {
    unsigned char   bit_mask;
#       define      OMAP3_VoiceGroupCallData_extensionContainer_present 0x80
#       define      OMAP3_additionalSubscriptions_present 0x40
#       define      OMAP3_VoiceGroupCallData_additionalInfo_present 0x20
#       define      OMAP3_longGroupId_present 0x10
    OMAP3_GroupId   groupId;
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                       * OMAP3_VoiceGroupCallData_extensionContainer_present if
                       * present */
    OMAP3_AdditionalSubscriptions additionalSubscriptions;  /* extension #1;
                                   * optional; set in bit_mask
                                   * OMAP3_additionalSubscriptions_present if
                                   * present */
    OMAP3_AdditionalInfo additionalInfo;  /* extension #2; optional; set in
                                   * bit_mask
                           * OMAP3_VoiceGroupCallData_additionalInfo_present if
                           * present */
    OMAP3_Long_GroupId longGroupId;  /* extension #3; optional; set in bit_mask
                                      * OMAP3_longGroupId_present if present */
} OMAP3_VoiceGroupCallData;

typedef struct OMAP3_VGCSDataList {
    unsigned short  count;
    OMAP3_VoiceGroupCallData value[50];
} OMAP3_VGCSDataList;

typedef struct OMAP3_SS_EventList {
    unsigned short  count;
    OMAP3_SS_Code   value[10];
} OMAP3_SS_EventList;

typedef struct OMAP3_SS_CamelData {
    unsigned char   bit_mask;
#       define      OMAP3_SS_CamelData_extensionContainer_present 0x80
    OMAP3_SS_EventList ss_EventList;
    OMAP3_ISDN_AddressString gsmSCF_Address;
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                             * OMAP3_SS_CamelData_extensionContainer_present if
                             * present */
} OMAP3_SS_CamelData;

typedef struct OMAP3_SS_CSI {
    unsigned char   bit_mask;
#       define      OMAP3_SS_CSI_extensionContainer_present 0x80
#       define      OMAP3_SS_CSI_notificationToCSE_present 0x40
#       define      OMAP3_SS_CSI_csi_Active_present 0x20
    OMAP3_SS_CamelData ss_CamelData;
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                                   * OMAP3_SS_CSI_extensionContainer_present if
                                   * present */
    Nulltype        notificationToCSE;  /* extension #1; optional; set in
                                   * bit_mask
                                   * OMAP3_SS_CSI_notificationToCSE_present if
                                   * present */
    Nulltype        csi_Active;  /* extension #2; optional; set in bit_mask
                                  * OMAP3_SS_CSI_csi_Active_present if
                                  * present */
//	notificationToCSE and csi-Active shall not be present when SS-CSI is sent to VLR.
//	They may only be included in ATSI/ATM ack/NSDC message.
} OMAP3_SS_CSI;

typedef struct OMAP3_MM_Code {
    unsigned short  length;
    unsigned char   value[1];
} OMAP3_MM_Code;

//	notificationToCSE and csi-Active shall not be present when MG-CSI is sent to SGSN.
//	They may only be included in ATSI/ATM ack/NSDC message.
typedef struct OMAP3_MobilityTriggers {
    unsigned short  count;
    OMAP3_MM_Code   value[10];
} OMAP3_MobilityTriggers;

//	exception handling:
//	reception of values in range 2-31 shall be treated as "continueTransaction"
//	reception of values greater than 31 shall be treated as "releaseTransaction"
typedef struct OMAP3_M_CSI {
    unsigned char   bit_mask;
#       define      OMAP3_M_CSI_extensionContainer_present 0x80
#       define      OMAP3_M_CSI_notificationToCSE_present 0x40
#       define      OMAP3_M_CSI_csi_Active_present 0x20
    OMAP3_MobilityTriggers mobilityTriggers;
    OMAP3_ServiceKey serviceKey;
    OMAP3_ISDN_AddressString gsmSCF_Address;
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                                    * OMAP3_M_CSI_extensionContainer_present if
                                    * present */
    Nulltype        notificationToCSE;  /* optional; set in bit_mask
                                         * OMAP3_M_CSI_notificationToCSE_present
                                         * if present */
    Nulltype        csi_Active;  /* optional; set in bit_mask
                                  * OMAP3_M_CSI_csi_Active_present if present */
} OMAP3_M_CSI;

typedef enum OMAP3_SMS_TriggerDetectionPoint {
    OMAP3_sms_CollectedInfo = 1,
    OMAP3_sms_DeliveryRequest = 2
} OMAP3_SMS_TriggerDetectionPoint;

//	exception handling:
//	For SMS-CAMEL-TDP-Data and MT-smsCAMELTDP-Criteria sequences containing this 
//	parameter with any other value than the ones listed the receiver shall ignore
//	the whole sequence.
//
//	If this parameter is received with any other value than sms-CollectedInfo
//	in an SMS-CAMEL-TDP-Data sequence contained in mo-sms-CSI, then the receiver shall
//	ignore the whole SMS-CAMEL-TDP-Data sequence.
//
//	If this parameter is received with any other value than sms-DeliveryRequest
//	in an SMS-CAMEL-TDP-Data sequence contained in mt-sms-CSI then the receiver shall
//	ignore the whole SMS-CAMEL-TDP-Data sequence.
//
//	If this parameter is received with any other value than sms-DeliveryRequest
//	in an MT-smsCAMELTDP-Criteria sequence then the receiver shall
//	ignore the whole MT-smsCAMELTDP-Criteria sequence.
typedef enum OMAP3_DefaultSMS_Handling {
    OMAP3_DefaultSMS_Handling_continueTransaction = 0,
    OMAP3_DefaultSMS_Handling_releaseTransaction = 1
} OMAP3_DefaultSMS_Handling;

//	SMS-CAMEL-TDP-DataList shall not contain more than one instance of
//	SMS-CAMEL-TDP-Data containing the same value for sms-TriggerDetectionPoint.
typedef struct OMAP3_SMS_CAMEL_TDP_Data {
    unsigned char   bit_mask;
#       define      OMAP3_SMS_CAMEL_TDP_Data_extensionContainer_present 0x80
    OMAP3_SMS_TriggerDetectionPoint sms_TriggerDetectionPoint;
    OMAP3_ServiceKey serviceKey;
    OMAP3_ISDN_AddressString gsmSCF_Address;
    OMAP3_DefaultSMS_Handling defaultSMS_Handling;
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                       * OMAP3_SMS_CAMEL_TDP_Data_extensionContainer_present if
                       * present */
} OMAP3_SMS_CAMEL_TDP_Data;

//	notificationToCSE and csi-Active shall not be present
//	when MO-SMS-CSI or MT-SMS-CSI is sent to VLR or SGSN.
//	They may only be included in ATSI/ATM ack/NSDC message.
//	SMS-CAMEL-TDP-Data and  camelCapabilityHandling shall be present in 
//	the SMS-CSI sequence.
//	If SMS-CSI is segmented, sms-CAMEL-TDP-DataList and camelCapabilityHandling shall be 
//	present in the first segment
typedef struct OMAP3_SMS_CAMEL_TDP_DataList {
    unsigned short  count;
    OMAP3_SMS_CAMEL_TDP_Data value[10];
} OMAP3_SMS_CAMEL_TDP_DataList;

// A node supporting Camel phase 4 shall mark in the BIT STRING all CAMEL4 
// functionalities it offers.
// Other values than listed above shall be discarded.
typedef struct OMAP3_SMS_CSI {
    unsigned char   bit_mask;
#       define      OMAP3_sms_CAMEL_TDP_DataList_present 0x80
#       define      OMAP3_SMS_CSI_camelCapabilityHandling_present 0x40
#       define      OMAP3_SMS_CSI_extensionContainer_present 0x20
#       define      OMAP3_SMS_CSI_notificationToCSE_present 0x10
#       define      OMAP3_SMS_CSI_csi_Active_present 0x08
    OMAP3_SMS_CAMEL_TDP_DataList sms_CAMEL_TDP_DataList;  /* optional; set in
                                   * bit_mask
                                   * OMAP3_sms_CAMEL_TDP_DataList_present if
                                   * present */
    OMAP3_CamelCapabilityHandling camelCapabilityHandling;  /* optional; set in
                                   * bit_mask
                             * OMAP3_SMS_CSI_camelCapabilityHandling_present if
                             * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                                  * OMAP3_SMS_CSI_extensionContainer_present if
                                  * present */
    Nulltype        notificationToCSE;  /* optional; set in bit_mask
                                   * OMAP3_SMS_CSI_notificationToCSE_present if
                                   * present */
    Nulltype        csi_Active;  /* optional; set in bit_mask
                                  * OMAP3_SMS_CSI_csi_Active_present if
                                  * present */
} OMAP3_SMS_CSI;

typedef enum OMAP3_MT_SMS_TPDU_Type {
    OMAP3_sms_DELIVER = 0,
    OMAP3_sms_SUBMIT_REPORT = 1,
    OMAP3_sms_STATUS_REPORT = 2
} OMAP3_MT_SMS_TPDU_Type;

typedef struct OMAP3_TPDU_TypeCriterion {
    unsigned short  count;
    OMAP3_MT_SMS_TPDU_Type value[5];
} OMAP3_TPDU_TypeCriterion;

typedef struct OMAP3_MT_smsCAMELTDP_Criteria {
    unsigned char   bit_mask;
#       define      OMAP3_tpdu_TypeCriterion_present 0x80
    OMAP3_SMS_TriggerDetectionPoint sms_TriggerDetectionPoint;
    OMAP3_TPDU_TypeCriterion tpdu_TypeCriterion;  /* optional; set in bit_mask
                                          * OMAP3_tpdu_TypeCriterion_present if
                                          * present */
} OMAP3_MT_smsCAMELTDP_Criteria;

typedef struct OMAP3_MT_smsCAMELTDP_CriteriaList {
    unsigned short  count;
    OMAP3_MT_smsCAMELTDP_Criteria value[10];
} OMAP3_MT_smsCAMELTDP_CriteriaList;

typedef struct OMAP3_VlrCamelSubscriptionInfo {
    unsigned short  bit_mask;
#       define      OMAP3_VlrCamelSubscriptionInfo_o_CSI_present 0x8000
#       define      OMAP3_VlrCamelSubscriptionInfo_extensionContainer_present 0x4000
#       define      OMAP3_VlrCamelSubscriptionInfo_ss_CSI_present 0x2000
#       define      OMAP3_VlrCamelSubscriptionInfo_o_BcsmCamelTDP_CriteriaList_present 0x1000
#       define      OMAP3_VlrCamelSubscriptionInfo_tif_CSI_present 0x0800
#       define      OMAP3_VlrCamelSubscriptionInfo_m_CSI_present 0x0400
#       define      OMAP3_VlrCamelSubscriptionInfo_mo_sms_CSI_present 0x0200
#       define      OMAP3_VlrCamelSubscriptionInfo_vt_CSI_present 0x0100
#       define      OMAP3_VlrCamelSubscriptionInfo_t_BCSM_CAMEL_TDP_CriteriaList_present 0x0080
#       define      OMAP3_VlrCamelSubscriptionInfo_d_CSI_present 0x0040
#       define      OMAP3_VlrCamelSubscriptionInfo_mt_sms_CSI_present 0x0020
#       define      OMAP3_VlrCamelSubscriptionInfo_mt_smsCAMELTDP_CriteriaList_present 0x0010
    OMAP3_O_CSI     o_CSI;  /* optional; set in bit_mask
                             * OMAP3_VlrCamelSubscriptionInfo_o_CSI_present if
                             * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                 * OMAP3_VlrCamelSubscriptionInfo_extensionContainer_present if
                 * present */
    OMAP3_SS_CSI    ss_CSI;  /* extension #1; optional; set in bit_mask
                              * OMAP3_VlrCamelSubscriptionInfo_ss_CSI_present if
                              * present */
    OMAP3_O_BcsmCamelTDPCriteriaList o_BcsmCamelTDP_CriteriaList;  /* extension
                                   * #2; optional; set in bit_mask
        * OMAP3_VlrCamelSubscriptionInfo_o_BcsmCamelTDP_CriteriaList_present if
        * present */
    Nulltype        tif_CSI;  /* extension #3; optional; set in bit_mask
                               * OMAP3_VlrCamelSubscriptionInfo_tif_CSI_present
                               * if present */
    OMAP3_M_CSI     m_CSI;  /* extension #4; optional; set in bit_mask
                             * OMAP3_VlrCamelSubscriptionInfo_m_CSI_present if
                             * present */
    OMAP3_SMS_CSI   mo_sms_CSI;  /* extension #5; optional; set in bit_mask
                         * OMAP3_VlrCamelSubscriptionInfo_mo_sms_CSI_present if
                         * present */
    OMAP3_T_CSI     vt_CSI;  /* extension #6; optional; set in bit_mask
                              * OMAP3_VlrCamelSubscriptionInfo_vt_CSI_present if
                              * present */
    OMAP3_T_BCSM_CAMEL_TDP_CriteriaList t_BCSM_CAMEL_TDP_CriteriaList;  
                                  /* extension #7; optional; set in bit_mask
      * OMAP3_VlrCamelSubscriptionInfo_t_BCSM_CAMEL_TDP_CriteriaList_present if
      * present */
    OMAP3_D_CSI     d_CSI;  /* extension #8; optional; set in bit_mask
                             * OMAP3_VlrCamelSubscriptionInfo_d_CSI_present if
                             * present */
    OMAP3_SMS_CSI   mt_sms_CSI;  /* extension #9; optional; set in bit_mask
                         * OMAP3_VlrCamelSubscriptionInfo_mt_sms_CSI_present if
                         * present */
    OMAP3_MT_smsCAMELTDP_CriteriaList mt_smsCAMELTDP_CriteriaList;  
                                  /* extension #10; optional; set in bit_mask
        * OMAP3_VlrCamelSubscriptionInfo_mt_smsCAMELTDP_CriteriaList_present if
        * present */
} OMAP3_VlrCamelSubscriptionInfo;

	// Octets are coded according to TS 3GPP TS 29.060 [105]

	// The possible size values are:
	// 1-7 octets  X.25 address type
	//  4  octets  IPv4 address type
	// 16  octets  Ipv6 address type
typedef struct OMAP3_QoS_Subscribed {
    unsigned short  length;
    unsigned char   value[3];
} OMAP3_QoS_Subscribed;

typedef struct OMAP3_PDP_Context {
    unsigned char   bit_mask;
#       define      OMAP3_PDP_Context_pdp_Address_present 0x80
#       define      OMAP3_PDP_Context_vplmnAddressAllowed_present 0x40
#       define      OMAP3_PDP_Context_extensionContainer_present 0x20
#       define      OMAP3_ext_QoS_Subscribed_present 0x10
#       define      OMAP3_pdp_ChargingCharacteristics_present 0x08
#       define      OMAP3_ext2_QoS_Subscribed_present 0x04
    OMAP3_ContextId pdp_ContextId;
    OMAP3_PDP_Type  pdp_Type;
    OMAP3_PDP_Address pdp_Address;  /* optional; set in bit_mask
                                     * OMAP3_PDP_Context_pdp_Address_present if
                                     * present */
    OMAP3_QoS_Subscribed qos_Subscribed;
    Nulltype        vplmnAddressAllowed;  /* optional; set in bit_mask
                             * OMAP3_PDP_Context_vplmnAddressAllowed_present if
                             * present */
    OMAP3_APN       apn;
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                              * OMAP3_PDP_Context_extensionContainer_present if
                              * present */
    OMAP3_Ext_QoS_Subscribed ext_QoS_Subscribed;  /* extension #1; optional; set
                                   * in bit_mask
                                   * OMAP3_ext_QoS_Subscribed_present if
                                   * present */
    OMAP3_ChargingCharacteristics pdp_ChargingCharacteristics;  /* extension #2;
                                   * optional; set in bit_mask
                                   * OMAP3_pdp_ChargingCharacteristics_present
                                   * if present */
    OMAP3_Ext2_QoS_Subscribed ext2_QoS_Subscribed;  /* extension #3; optional;
                                   * set in bit_mask
                                   * OMAP3_ext2_QoS_Subscribed_present if
                                   * present */
	// ext2-QoS-Subscribed may be present only if ext-QoS-Subscribed is present.
} OMAP3_PDP_Context;

	// if unknown values are received in NetworkAccessMode
	// they shall be discarded.
typedef struct OMAP3_GPRSDataList {
    unsigned short  count;
    OMAP3_PDP_Context value[50];
} OMAP3_GPRSDataList;

typedef struct OMAP3_APN_OI_Replacement {
    unsigned short  length;
    unsigned char   value[100];
} OMAP3_APN_OI_Replacement;

                // Octets are coded as APN Operator Identifier according to TS 3GPP TS 23.003 [17]
typedef struct OMAP3_GPRSSubscriptionData {
    unsigned char   bit_mask;
#       define      OMAP3_GPRSSubscriptionData_completeDataListIncluded_present 0x80
#       define      OMAP3_GPRSSubscriptionData_extensionContainer_present 0x40
#       define      OMAP3_GPRSSubscriptionData_apn_oi_Replacement_present 0x20
    Nulltype        completeDataListIncluded;  /* optional; set in bit_mask
               * OMAP3_GPRSSubscriptionData_completeDataListIncluded_present if
               * present */
		// If segmentation is used, completeDataListIncluded may only be present in the
		// first segment.
    OMAP3_GPRSDataList gprsDataList;
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                     * OMAP3_GPRSSubscriptionData_extensionContainer_present if
                     * present */
    OMAP3_APN_OI_Replacement apn_oi_Replacement;  /* extension #1; optional; set
                                   * in bit_mask
                     * OMAP3_GPRSSubscriptionData_apn_oi_Replacement_present if
                     * present */
        // this apn-oi-Replacement refers to the UE level apn-oi-Replacement.        
} OMAP3_GPRSSubscriptionData;

typedef enum OMAP3_NetworkAccessMode {
    OMAP3_bothMSCAndSGSN = 0,
    OMAP3_onlyMSC = 1,
    OMAP3_onlySGSN = 2
} OMAP3_NetworkAccessMode;

	// Octets are coded according to 3GPP TS 32.215.
typedef enum OMAP3_LSAOnlyAccessIndicator {
    OMAP3_accessOutsideLSAsAllowed = 0,
    OMAP3_accessOutsideLSAsRestricted = 1
} OMAP3_LSAOnlyAccessIndicator;

	// Octets are coded according to TS 3GPP TS 23.003 [17]
typedef struct OMAP3_LSAAttributes {
    unsigned short  length;
    unsigned char   value[1];
} OMAP3_LSAAttributes;

typedef struct OMAP3_LSAData {
    unsigned char   bit_mask;
#       define      OMAP3_lsaActiveModeIndicator_present 0x80
#       define      OMAP3_LSAData_extensionContainer_present 0x40
    OMAP3_LSAIdentity lsaIdentity;
    OMAP3_LSAAttributes lsaAttributes;
    Nulltype        lsaActiveModeIndicator;  /* optional; set in bit_mask
                                      * OMAP3_lsaActiveModeIndicator_present if
                                      * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                                  * OMAP3_LSAData_extensionContainer_present if
                                  * present */
} OMAP3_LSAData;

typedef struct OMAP3_LSADataList {
    unsigned short  count;
    OMAP3_LSAData   value[20];
} OMAP3_LSADataList;

typedef struct OMAP3_LSAInformation {
    unsigned char   bit_mask;
#       define      OMAP3_LSAInformation_completeDataListIncluded_present 0x80
#       define      OMAP3_lsaOnlyAccessIndicator_present 0x40
#       define      OMAP3_lsaDataList_present 0x20
#       define      OMAP3_LSAInformation_extensionContainer_present 0x10
    Nulltype        completeDataListIncluded;  /* optional; set in bit_mask
                     * OMAP3_LSAInformation_completeDataListIncluded_present if
                     * present */
		// If segmentation is used, completeDataListIncluded may only be present in the
		// first segment.
    OMAP3_LSAOnlyAccessIndicator lsaOnlyAccessIndicator;  /* optional; set in
                                   * bit_mask
                                   * OMAP3_lsaOnlyAccessIndicator_present if
                                   * present */
    OMAP3_LSADataList lsaDataList;  /* optional; set in bit_mask
                                     * OMAP3_lsaDataList_present if present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                           * OMAP3_LSAInformation_extensionContainer_present if
                           * present */
} OMAP3_LSAInformation;

	// add-lcs-PrivacyExceptionList may be sent only if lcs-PrivacyExceptionList is
	// present and contains four instances of LCS-PrivacyClass. If the mentioned condition
	// is not satisfied the receiving node shall discard add-lcs-PrivacyExceptionList.
	// If an LCS-PrivacyClass is received both in lcs-PrivacyExceptionList and in
	// add-lcs-PrivacyExceptionList with the same SS-Code, then the error unexpected 
	// data value shall be returned.
typedef struct OMAP3_GMLC_List {
    unsigned short  count;
    OMAP3_ISDN_AddressString value[5];
} OMAP3_GMLC_List;

// exception handling:
// At reception of any other value than the ones listed the receiver shall ignore
// GMLC-Restriction.
typedef enum OMAP3_NotificationToMSUser {
    OMAP3_notifyLocationAllowed = 0,
    OMAP3_notifyAndVerify_LocationAllowedIfNoResponse = 1,
    OMAP3_notifyAndVerify_LocationNotAllowedIfNoResponse = 2,
    OMAP3_locationNotAllowed = 3
} OMAP3_NotificationToMSUser;

typedef enum OMAP3_GMLC_Restriction {
    OMAP3_gmlc_List = 0,
    OMAP3_home_Country = 1
} OMAP3_GMLC_Restriction;

typedef struct OMAP3_ExternalClient {
    unsigned char   bit_mask;
#       define      OMAP3_ExternalClient_gmlc_Restriction_present 0x80
#       define      OMAP3_ExternalClient_notificationToMSUser_present 0x40
#       define      OMAP3_ExternalClient_extensionContainer_present 0x20
    OMAP3_LCSClientExternalID clientIdentity;
    OMAP3_GMLC_Restriction gmlc_Restriction;  /* optional; set in bit_mask
                             * OMAP3_ExternalClient_gmlc_Restriction_present if
                             * present */
    OMAP3_NotificationToMSUser notificationToMSUser;  /* optional; set in
                                   * bit_mask
                         * OMAP3_ExternalClient_notificationToMSUser_present if
                         * present */
	// If notificationToMSUser is not received, the default value according to 
	// 3GPP TS 23.271 shall be assumed.
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                           * OMAP3_ExternalClient_extensionContainer_present if
                           * present */
} OMAP3_ExternalClient;

typedef struct OMAP3_ExternalClientList {
    unsigned short  count;
    OMAP3_ExternalClient value[5];
} OMAP3_ExternalClientList;

typedef struct OMAP3_PLMNClientList {
    unsigned short  count;
    OMAP3_LCSClientInternalID value[5];
} OMAP3_PLMNClientList;

typedef struct OMAP3_Ext_ExternalClientList {
    unsigned short  count;
    OMAP3_ExternalClient value[35];
} OMAP3_Ext_ExternalClientList;

typedef struct OMAP3_ServiceType {
    unsigned char   bit_mask;
#       define      OMAP3_ServiceType_gmlc_Restriction_present 0x80
#       define      OMAP3_ServiceType_notificationToMSUser_present 0x40
#       define      OMAP3_ServiceType_extensionContainer_present 0x20
    OMAP3_LCSServiceTypeID serviceTypeIdentity;
    OMAP3_GMLC_Restriction gmlc_Restriction;  /* optional; set in bit_mask
                                * OMAP3_ServiceType_gmlc_Restriction_present if
                                * present */
    OMAP3_NotificationToMSUser notificationToMSUser;  /* optional; set in
                                   * bit_mask
                            * OMAP3_ServiceType_notificationToMSUser_present if
                            * present */
	// If notificationToMSUser is not received, the default value according to 
	// 3GPP TS 23.271 shall be assumed.
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                              * OMAP3_ServiceType_extensionContainer_present if
                              * present */
} OMAP3_ServiceType;

// exception handling:
// At reception of any other value than the ones listed the receiver shall ignore
// NotificationToMSUser.
typedef struct OMAP3_ServiceTypeList {
    unsigned short  count;
    OMAP3_ServiceType value[32];
} OMAP3_ServiceTypeList;

typedef struct OMAP3_LCS_PrivacyClass {
    unsigned char   bit_mask;
#       define      OMAP3_LCS_PrivacyClass_notificationToMSUser_present 0x80
#       define      OMAP3_externalClientList_present 0x40
#       define      OMAP3_plmnClientList_present 0x20
#       define      OMAP3_LCS_PrivacyClass_extensionContainer_present 0x10
#       define      OMAP3_ext_externalClientList_present 0x08
#       define      OMAP3_serviceTypeList_present 0x04
    OMAP3_SS_Code   ss_Code;
    OMAP3_Ext_SS_Status ss_Status;
    OMAP3_NotificationToMSUser notificationToMSUser;  /* optional; set in
                                   * bit_mask
                       * OMAP3_LCS_PrivacyClass_notificationToMSUser_present if
                       * present */
	// notificationToMSUser may be sent only for SS-codes callSessionRelated
	// and callSessionUnrelated. If not received for SS-codes callSessionRelated
	// and callSessionUnrelated,
	// the default values according to 3GPP TS 23.271 shall be assumed.
    OMAP3_ExternalClientList externalClientList;  /* optional; set in bit_mask
                                          * OMAP3_externalClientList_present if
                                          * present */
	// externalClientList may be sent only for SS-code callSessionUnrelated to a
	// visited node that does not support LCS Release 4 or later versions.
	// externalClientList may be sent only for SS-codes callSessionUnrelated and
	// callSessionRelated to a visited node that supports LCS Release 4 or later versions.
    OMAP3_PLMNClientList plmnClientList;  /* optional; set in bit_mask
                                           * OMAP3_plmnClientList_present if
                                           * present */
	// plmnClientList may be sent only for SS-code plmnoperator.
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                         * OMAP3_LCS_PrivacyClass_extensionContainer_present if
                         * present */
    OMAP3_Ext_ExternalClientList ext_externalClientList;  /* extension #1;
                                   * optional; set in bit_mask
                                   * OMAP3_ext_externalClientList_present if
                                   * present */
	// Ext-externalClientList may be sent only if the visited node supports LCS Release 4 or
	// later versions, the user did specify more than 5 clients, and White Book SCCP is used.
    OMAP3_ServiceTypeList serviceTypeList;  /* extension #2; optional; set in
                                   * bit_mask OMAP3_serviceTypeList_present if
                                   * present */
	// serviceTypeList may be sent only for SS-code serviceType and if the visited node
	// supports LCS Release 5 or later versions.
	// 
	// if segmentation is used, the complete LCS-PrivacyClass shall be sent in one segment
} OMAP3_LCS_PrivacyClass;

typedef struct OMAP3_LCS_PrivacyExceptionList {
    unsigned short  count;
    OMAP3_LCS_PrivacyClass value[4];
} OMAP3_LCS_PrivacyExceptionList;

typedef struct OMAP3_MOLR_Class {
    unsigned char   bit_mask;
#       define      OMAP3_MOLR_Class_extensionContainer_present 0x80
    OMAP3_SS_Code   ss_Code;
    OMAP3_Ext_SS_Status ss_Status;
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                               * OMAP3_MOLR_Class_extensionContainer_present if
                               * present */
} OMAP3_MOLR_Class;

typedef struct OMAP3_MOLR_List {
    unsigned short  count;
    OMAP3_MOLR_Class value[3];
} OMAP3_MOLR_List;

typedef struct OMAP3_LCSInformation {
    unsigned char   bit_mask;
#       define      OMAP3_gmlc_List_present 0x80
#       define      OMAP3_lcs_PrivacyExceptionList_present 0x40
#       define      OMAP3_molr_List_present 0x20
#       define      OMAP3_add_lcs_PrivacyExceptionList_present 0x10
    OMAP3_GMLC_List gmlc_List;  /* optional; set in bit_mask
                                 * OMAP3_gmlc_List_present if present */
    OMAP3_LCS_PrivacyExceptionList lcs_PrivacyExceptionList;  /* optional; set
                                   * in bit_mask
                                   * OMAP3_lcs_PrivacyExceptionList_present if
                                   * present */
    OMAP3_MOLR_List molr_List;  /* optional; set in bit_mask
                                 * OMAP3_molr_List_present if present */
    OMAP3_LCS_PrivacyExceptionList add_lcs_PrivacyExceptionList;  /* extension
                                   * #1; optional; set in bit_mask
                                   * OMAP3_add_lcs_PrivacyExceptionList_present
                                   * if present */
} OMAP3_LCSInformation;

	// exception handling:
	// bits 2 to 7 shall be ignored if received and not understood
typedef struct OMAP3_CS_AllocationRetentionPriority {
    unsigned short  length;
    unsigned char   value[1];
} OMAP3_CS_AllocationRetentionPriority;

// exception handling:
// reception of values in range 2-31 shall be treated as "continueTransaction"
// reception of values greater than 31 shall be treated as "releaseTransaction"
typedef enum OMAP3_GPRS_TriggerDetectionPoint {
    OMAP3_attach = 1,
    OMAP3_attachChangeOfPosition = 2,
    OMAP3_pdp_ContextEstablishment = 11,
    OMAP3_pdp_ContextEstablishmentAcknowledgement = 12,
    OMAP3_pdp_ContextChangeOfPosition = 14
} OMAP3_GPRS_TriggerDetectionPoint;

typedef enum OMAP3_DefaultGPRS_Handling {
    OMAP3_DefaultGPRS_Handling_continueTransaction = 0,
    OMAP3_DefaultGPRS_Handling_releaseTransaction = 1
} OMAP3_DefaultGPRS_Handling;

//	GPRS-CamelTDPDataList shall not contain more than one instance of
//	GPRS-CamelTDPData containing the same value for gprs-TriggerDetectionPoint.
typedef struct OMAP3_GPRS_CamelTDPData {
    unsigned char   bit_mask;
#       define      OMAP3_GPRS_CamelTDPData_extensionContainer_present 0x80
    OMAP3_GPRS_TriggerDetectionPoint gprs_TriggerDetectionPoint;
    OMAP3_ServiceKey serviceKey;
    OMAP3_ISDN_AddressString gsmSCF_Address;
    OMAP3_DefaultGPRS_Handling defaultSessionHandling;
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                        * OMAP3_GPRS_CamelTDPData_extensionContainer_present if
                        * present */
} OMAP3_GPRS_CamelTDPData;

//	notificationToCSE and csi-Active shall not be present when GPRS-CSI is sent to SGSN.
//	They may only be included in ATSI/ATM ack/NSDC message. 
//	GPRS-CamelTDPData and  camelCapabilityHandling shall be present in 
//	the GPRS-CSI sequence.
//	If GPRS-CSI is segmented, gprs-CamelTDPDataList and camelCapabilityHandling shall be 
//	present in the first segment
typedef struct OMAP3_GPRS_CamelTDPDataList {
    unsigned short  count;
    OMAP3_GPRS_CamelTDPData value[10];
} OMAP3_GPRS_CamelTDPDataList;

typedef struct OMAP3_GPRS_CSI {
    unsigned char   bit_mask;
#       define      OMAP3_gprs_CamelTDPDataList_present 0x80
#       define      OMAP3_GPRS_CSI_camelCapabilityHandling_present 0x40
#       define      OMAP3_GPRS_CSI_extensionContainer_present 0x20
#       define      OMAP3_GPRS_CSI_notificationToCSE_present 0x10
#       define      OMAP3_GPRS_CSI_csi_Active_present 0x08
    OMAP3_GPRS_CamelTDPDataList gprs_CamelTDPDataList;  /* optional; set in
                                   * bit_mask
                                   * OMAP3_gprs_CamelTDPDataList_present if
                                   * present */
    OMAP3_CamelCapabilityHandling camelCapabilityHandling;  /* optional; set in
                                   * bit_mask
                            * OMAP3_GPRS_CSI_camelCapabilityHandling_present if
                            * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                                 * OMAP3_GPRS_CSI_extensionContainer_present if
                                 * present */
    Nulltype        notificationToCSE;  /* optional; set in bit_mask
                                  * OMAP3_GPRS_CSI_notificationToCSE_present if
                                  * present */
    Nulltype        csi_Active;  /* optional; set in bit_mask
                                  * OMAP3_GPRS_CSI_csi_Active_present if
                                  * present */
} OMAP3_GPRS_CSI;

//	notificationToCSE and csi-Active shall not be present when M-CSI is sent to VLR.
//	They may only be included in ATSI/ATM ack/NSDC message.
typedef struct OMAP3_MG_CSI {
    unsigned char   bit_mask;
#       define      OMAP3_MG_CSI_extensionContainer_present 0x80
#       define      OMAP3_MG_CSI_notificationToCSE_present 0x40
#       define      OMAP3_MG_CSI_csi_Active_present 0x20
    OMAP3_MobilityTriggers mobilityTriggers;
    OMAP3_ServiceKey serviceKey;
    OMAP3_ISDN_AddressString gsmSCF_Address;
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                                   * OMAP3_MG_CSI_extensionContainer_present if
                                   * present */
    Nulltype        notificationToCSE;  /* optional; set in bit_mask
                                    * OMAP3_MG_CSI_notificationToCSE_present if
                                    * present */
    Nulltype        csi_Active;  /* optional; set in bit_mask
                                  * OMAP3_MG_CSI_csi_Active_present if
                                  * present */
} OMAP3_MG_CSI;

typedef struct OMAP3_SGSN_CAMEL_SubscriptionInfo {
    unsigned char   bit_mask;
#       define      OMAP3_SGSN_CAMEL_SubscriptionInfo_gprs_CSI_present 0x80
#       define      OMAP3_SGSN_CAMEL_SubscriptionInfo_mo_sms_CSI_present 0x40
#       define      OMAP3_SGSN_CAMEL_SubscriptionInfo_extensionContainer_present 0x20
#       define      OMAP3_SGSN_CAMEL_SubscriptionInfo_mt_sms_CSI_present 0x10
#       define      OMAP3_SGSN_CAMEL_SubscriptionInfo_mt_smsCAMELTDP_CriteriaList_present 0x08
#       define      OMAP3_SGSN_CAMEL_SubscriptionInfo_mg_csi_present 0x04
    OMAP3_GPRS_CSI  gprs_CSI;  /* optional; set in bit_mask
                        * OMAP3_SGSN_CAMEL_SubscriptionInfo_gprs_CSI_present if
                        * present */
    OMAP3_SMS_CSI   mo_sms_CSI;  /* optional; set in bit_mask
                      * OMAP3_SGSN_CAMEL_SubscriptionInfo_mo_sms_CSI_present if
                      * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
              * OMAP3_SGSN_CAMEL_SubscriptionInfo_extensionContainer_present if
              * present */
    OMAP3_SMS_CSI   mt_sms_CSI;  /* extension #1; optional; set in bit_mask
                      * OMAP3_SGSN_CAMEL_SubscriptionInfo_mt_sms_CSI_present if
                      * present */
    OMAP3_MT_smsCAMELTDP_CriteriaList mt_smsCAMELTDP_CriteriaList;  
                                  /* extension #2; optional; set in bit_mask
     * OMAP3_SGSN_CAMEL_SubscriptionInfo_mt_smsCAMELTDP_CriteriaList_present if
     * present */
    OMAP3_MG_CSI    mg_csi;  /* extension #3; optional; set in bit_mask
                              * OMAP3_SGSN_CAMEL_SubscriptionInfo_mg_csi_present
                              * if present */
} OMAP3_SGSN_CAMEL_SubscriptionInfo;

	// If the Network Access Mode parameter is sent, it shall be present only in 
	// the first sequence if seqmentation is used
typedef struct OMAP3_AccessRestrictionData {
    unsigned short  length;  /* number of significant bits */
    unsigned char   value[1];
} OMAP3_AccessRestrictionData;
#define                     OMAP3_utranNotAllowed 0x80
#define                     OMAP3_utranNotAllowed_byte 0
#define                     OMAP3_geranNotAllowed 0x40
#define                     OMAP3_geranNotAllowed_byte 0

typedef struct OMAP3__octet5 {
    unsigned short  length;
    unsigned char   value[100];
} OMAP3__octet5;

typedef struct OMAP3__seq6 {
    unsigned char   bit_mask;
#       define      OMAP3_ambr_extensionContainer_present 0x80
    int             max_RequestedBandwidth_UL;
    int             max_RequestedBandwidth_DL;
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                                     * OMAP3_ambr_extensionContainer_present if
                                     * present */
} OMAP3__seq6;

typedef struct OMAP3__octet2 {
    unsigned short  length;
    unsigned char   value[16];
} OMAP3__octet2;

typedef struct OMAP3__octet3 {
    unsigned short  length;
    unsigned char   value[63];
} OMAP3__octet3;

typedef struct OMAP3__seq4 {
    unsigned char   bit_mask;
#       define      OMAP3_pdn_gw_ipv4_Address_present 0x80
#       define      OMAP3_pdn_gw_ipv6_Address_present 0x40
#       define      OMAP3_pdn_gw_name_present 0x20
#       define      OMAP3_pdn_gw_Identity_extensionContainer_present 0x10
    OMAP3__octet2   pdn_gw_ipv4_Address;  /* optional; set in bit_mask
                                           * OMAP3_pdn_gw_ipv4_Address_present
                                           * if present */
    OMAP3__octet2   pdn_gw_ipv6_Address;  /* optional; set in bit_mask
                                           * OMAP3_pdn_gw_ipv6_Address_present
                                           * if present */
    OMAP3__octet5   pdn_gw_name;  /* optional; set in bit_mask
                                   * OMAP3_pdn_gw_name_present if present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                          * OMAP3_pdn_gw_Identity_extensionContainer_present if
                          * present */
} OMAP3__seq4;

typedef enum OMAP3__enum3 {
    OMAP3_static = 0,
    OMAP3_dynamic = 1
} OMAP3__enum3;

typedef struct OMAP3__seq2 {
    unsigned char   bit_mask;
#       define      OMAP3_specificAPNInfoList_extensionContainer_present 0x80
    OMAP3__octet3   apn;
    OMAP3__seq4     pdn_gw_Identity;
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                      * OMAP3_specificAPNInfoList_extensionContainer_present if
                      * present */
} OMAP3__seq2;

typedef struct OMAP3__seq5 {
    unsigned short  bit_mask;
#       define      OMAP3_servedPartyIP_IPv4_Address_present 0x8000
#       define      OMAP3_pdn_gw_Identity_present 0x4000
#       define      OMAP3_pdn_gw_AllocationType_present 0x2000
#       define      OMAP3_epsDataList_vplmnAddressAllowed_present 0x1000
#       define      OMAP3_epsDataList_chargingCharacteristics_present 0x0800
#       define      OMAP3_epsDataList_ambr_present 0x0400
#       define      OMAP3_specificAPNInfoList_present 0x0200
#       define      OMAP3_epsDataList_extensionContainer_present 0x0100
#       define      OMAP3_servedPartyIP_IPv6_Address_present 0x0080
    unsigned short  contextId;
    struct OMAP3__octet1 {
        unsigned short  length;
        unsigned char   value[1];
    } pdn_Type;
    OMAP3__octet2   servedPartyIP_IPv4_Address;  /* optional; set in bit_mask
                                  * OMAP3_servedPartyIP_IPv4_Address_present if
                                  * present */
    OMAP3__octet3   apn;
    struct OMAP3__seq3 {
        unsigned char   bit_mask;
#           define      OMAP3_eps_qos_Subscribed_extensionContainer_present 0x80
        unsigned short  qos_Class_Identifier;
        struct OMAP3__seq1 {
            unsigned char   bit_mask;
#               define      OMAP3_pre_emption_capability_present 0x80
#               define      OMAP3_pre_emption_vulnerability_present 0x40
#               define      OMAP3_allocation_Retention_Priority_extensionContainer_present 0x20
            int             priority_level;
            ossBoolean      pre_emption_capability;  /* optional; set in
                                   * bit_mask
                                   * OMAP3_pre_emption_capability_present if
                                   * present */
            ossBoolean      pre_emption_vulnerability;  /* optional; set in
                                   * bit_mask
                                   * OMAP3_pre_emption_vulnerability_present if
                                   * present */
            OMAP3_ExtensionContainer extensionContainer;  /* optional; set in
                                   * bit_mask
            * OMAP3_allocation_Retention_Priority_extensionContainer_present if
            * present */
        } allocation_Retention_Priority;
        OMAP3_ExtensionContainer extensionContainer;  /* optional; set in
                                   * bit_mask
                       * OMAP3_eps_qos_Subscribed_extensionContainer_present if
                       * present */
    } eps_qos_Subscribed;
    OMAP3__seq4     pdn_gw_Identity;  /* optional; set in bit_mask
                                       * OMAP3_pdn_gw_Identity_present if
                                       * present */
    OMAP3__enum3    pdn_gw_AllocationType;  /* optional; set in bit_mask
                                       * OMAP3_pdn_gw_AllocationType_present if
                                       * present */
    Nulltype        vplmnAddressAllowed;  /* optional; set in bit_mask
                             * OMAP3_epsDataList_vplmnAddressAllowed_present if
                             * present */
    struct OMAP3__octet4 {
        unsigned short  length;
        unsigned char   value[2];
    } chargingCharacteristics;  /* optional; set in bit_mask
                         * OMAP3_epsDataList_chargingCharacteristics_present if
                         * present */
    OMAP3__seq6     ambr;  /* optional; set in bit_mask
                            * OMAP3_epsDataList_ambr_present if present */
    struct OMAP3__seqof1 {
        unsigned short  count;
        OMAP3__seq2     value[50];
    } specificAPNInfoList;  /* optional; set in bit_mask
                             * OMAP3_specificAPNInfoList_present if present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                              * OMAP3_epsDataList_extensionContainer_present if
                              * present */
    OMAP3__octet2   servedPartyIP_IPv6_Address;  /* optional; set in bit_mask
                                  * OMAP3_servedPartyIP_IPv6_Address_present if
                                  * present */
} OMAP3__seq5;

typedef struct OMAP3__octet6 {
    unsigned short  length;
    unsigned char   value[9];
} OMAP3__octet6;

typedef struct OMAP3__seq8 {
    unsigned char   bit_mask;
#       define      OMAP3_expirationDate_present 0x80
#       define      OMAP3_csg_SubscriptionDataList_extensionContainer_present 0x40
    struct OMAP3__bit3 {
        unsigned short  length;  /* number of significant bits */
        unsigned char   value[4];
    } csg_Id;
    struct OMAP3__octet7 {
        unsigned short  length;
        unsigned char   value[4];
    } expirationDate;  /* optional; set in bit_mask OMAP3_expirationDate_present
                        * if present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                 * OMAP3_csg_SubscriptionDataList_extensionContainer_present if
                 * present */
} OMAP3__seq8;

// subscriber management types
typedef struct OMAP3_InsertSubscriberDataArg {
    unsigned int    bit_mask;
#       define      OMAP3_InsertSubscriberDataArg_imsi_present 0x80000000
#       define      OMAP3_InsertSubscriberDataArg_msisdn_present 0x40000000
#       define      OMAP3_category_present 0x20000000
#       define      OMAP3_subscriberStatus_present 0x10000000
#       define      OMAP3_InsertSubscriberDataArg_bearerServiceList_present 0x08000000
#       define      OMAP3_InsertSubscriberDataArg_teleserviceList_present 0x04000000
#       define      OMAP3_provisionedSS_present 0x02000000
#       define      OMAP3_odb_Data_present 0x01000000
#       define      OMAP3_InsertSubscriberDataArg_roamingRestrictionDueToUnsupportedFeature_present 0x00800000
#       define      OMAP3_regionalSubscriptionData_present 0x00400000
#       define      OMAP3_vbsSubscriptionData_present 0x00200000
#       define      OMAP3_vgcsSubscriptionData_present 0x00100000
#       define      OMAP3_vlrCamelSubscriptionInfo_present 0x00080000
#       define      OMAP3_InsertSubscriberDataArg_extensionContainer_present 0x00040000
#       define      OMAP3_InsertSubscriberDataArg_naea_PreferredCI_present 0x00020000
#       define      OMAP3_gprsSubscriptionData_present 0x00010000
#       define      OMAP3_roamingRestrictedInSgsnDueToUnsupportedFeature_present 0x00008000
#       define      OMAP3_networkAccessMode_present 0x00004000
#       define      OMAP3_lsaInformation_present 0x00002000
#       define      OMAP3_lmu_Indicator_present 0x00001000
#       define      OMAP3_lcsInformation_present 0x00000800
#       define      OMAP3_InsertSubscriberDataArg_istAlertTimer_present 0x00000400
#       define      OMAP3_superChargerSupportedInHLR_present 0x00000200
#       define      OMAP3_mc_SS_Info_present 0x00000100
#       define      OMAP3_cs_AllocationRetentionPriority_present 0x00000080
#       define      OMAP3_sgsn_CAMEL_SubscriptionInfo_present 0x00000040
#       define      OMAP3_InsertSubscriberDataArg_chargingCharacteristics_present 0x00000020
#       define      OMAP3_accessRestrictionData_present 0x00000010
#       define      OMAP3_ics_Indicator_present 0x00000008
#       define      OMAP3_eps_SubscriptionData_present 0x00000004
#       define      OMAP3_csg_SubscriptionDataList_present 0x00000002
#       define      OMAP3_ue_ReachabilityRequestIndicator_present 0x00000001
    OMAP3_IMSI      imsi;  /* optional; set in bit_mask
                            * OMAP3_InsertSubscriberDataArg_imsi_present if
                            * present */
    OMAP3_ISDN_AddressString msisdn;  /* optional; set in bit_mask
                              * OMAP3_InsertSubscriberDataArg_msisdn_present if
                              * present */
    OMAP3_Category  category;  /* optional; set in bit_mask
                                * OMAP3_category_present if present */
    OMAP3_SubscriberStatus subscriberStatus;  /* optional; set in bit_mask
                                               * OMAP3_subscriberStatus_present
                                               * if present */
    OMAP3_BearerServiceList bearerServiceList;  /* optional; set in bit_mask
                   * OMAP3_InsertSubscriberDataArg_bearerServiceList_present if
                   * present */
	// The exception handling for reception of unsupported / not allocated
	// bearerServiceCodes is defined in section 8.8.1
    OMAP3_TeleserviceList teleserviceList;  /* optional; set in bit_mask
                     * OMAP3_InsertSubscriberDataArg_teleserviceList_present if
                     * present */
	// The exception handling for reception of unsupported / not allocated
	// teleserviceCodes is defined in section 8.8.1
    OMAP3_Ext_SS_InfoList provisionedSS;  /* optional; set in bit_mask
                                           * OMAP3_provisionedSS_present if
                                           * present */
    OMAP3_ODB_Data  odb_Data;  /* optional; set in bit_mask
                                * OMAP3_odb_Data_present if present */
    Nulltype        roamingRestrictionDueToUnsupportedFeature;  /* optional; set
                                   * in bit_mask
       * OMAP3_InsertSubscriberDataArg_roamingRestrictionDueToUnsupportedFeature_present if
       * present */
    OMAP3_ZoneCodeList regionalSubscriptionData;  /* optional; set in bit_mask
                                    * OMAP3_regionalSubscriptionData_present if
                                    * present */
    OMAP3_VBSDataList vbsSubscriptionData;  /* optional; set in bit_mask
                                             * OMAP3_vbsSubscriptionData_present
                                             * if present */
    OMAP3_VGCSDataList vgcsSubscriptionData;  /* optional; set in bit_mask
                                        * OMAP3_vgcsSubscriptionData_present if
                                        * present */
    OMAP3_VlrCamelSubscriptionInfo vlrCamelSubscriptionInfo;  /* optional; set
                                   * in bit_mask
                                   * OMAP3_vlrCamelSubscriptionInfo_present if
                                   * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                  * OMAP3_InsertSubscriberDataArg_extensionContainer_present if
                  * present */
    OMAP3_NAEA_PreferredCI naea_PreferredCI;  /* extension #1; optional; set in
                                   * bit_mask
                    * OMAP3_InsertSubscriberDataArg_naea_PreferredCI_present if
                    * present */
	// naea-PreferredCI is included at the discretion of the HLR operator.
    OMAP3_GPRSSubscriptionData gprsSubscriptionData;  /* extension #2; optional;
                                   * set in bit_mask
                                   * OMAP3_gprsSubscriptionData_present if
                                   * present */
    Nulltype        roamingRestrictedInSgsnDueToUnsupportedFeature;  
                                  /* extension #3; optional; set in bit_mask
              * OMAP3_roamingRestrictedInSgsnDueToUnsupportedFeature_present if
              * present */
    OMAP3_NetworkAccessMode networkAccessMode;  /* extension #4; optional; set
                                   * in bit_mask OMAP3_networkAccessMode_present
                                   * if present */
    OMAP3_LSAInformation lsaInformation;  /* extension #5; optional; set in
                                   * bit_mask OMAP3_lsaInformation_present if
                                   * present */
    Nulltype        lmu_Indicator;  /* extension #6; optional; set in bit_mask
                                     * OMAP3_lmu_Indicator_present if present */
    OMAP3_LCSInformation lcsInformation;  /* extension #7; optional; set in
                                   * bit_mask OMAP3_lcsInformation_present if
                                   * present */
    OMAP3_IST_AlertTimerValue istAlertTimer;  /* extension #8; optional; set in
                                   * bit_mask
                       * OMAP3_InsertSubscriberDataArg_istAlertTimer_present if
                       * present */
    OMAP3_AgeIndicator superChargerSupportedInHLR;  /* extension #9; optional;
                                   * set in bit_mask
                                   * OMAP3_superChargerSupportedInHLR_present if
                                   * present */
    OMAP3_MC_SS_Info mc_SS_Info;  /* extension #10; optional; set in bit_mask
                                   * OMAP3_mc_SS_Info_present if present */
    OMAP3_CS_AllocationRetentionPriority cs_AllocationRetentionPriority;  
                                        /* extension #11; optional; set in
                                   * bit_mask
                              * OMAP3_cs_AllocationRetentionPriority_present if
                              * present */
    OMAP3_SGSN_CAMEL_SubscriptionInfo sgsn_CAMEL_SubscriptionInfo;  
                                  /* extension #12; optional; set in bit_mask
                                   * OMAP3_sgsn_CAMEL_SubscriptionInfo_present
                                   * if present */
    OMAP3_ChargingCharacteristics chargingCharacteristics;  /* extension #13;
                                   * optional; set in bit_mask
             * OMAP3_InsertSubscriberDataArg_chargingCharacteristics_present if
             * present */
    OMAP3_AccessRestrictionData accessRestrictionData;  /* extension #14;
                                   * optional; set in bit_mask
                                   * OMAP3_accessRestrictionData_present if
                                   * present */
    ossBoolean      ics_Indicator;  /* extension #15; optional; set in bit_mask
                                     * OMAP3_ics_Indicator_present if present */
    struct OMAP3__seq9 {
        unsigned char   bit_mask;
#           define      OMAP3_eps_SubscriptionData_apn_oi_Replacement_present 0x80
#           define      OMAP3_rfsp_id_present 0x40
#           define      OMAP3_eps_SubscriptionData_ambr_present 0x20
#           define      OMAP3_apn_ConfigurationProfile_present 0x10
#           define      OMAP3_stn_sr_present 0x08
#           define      OMAP3_eps_SubscriptionData_extensionContainer_present 0x04
        OMAP3__octet5   apn_oi_Replacement;  /* optional; set in bit_mask
                     * OMAP3_eps_SubscriptionData_apn_oi_Replacement_present if
                     * present */
        unsigned short  rfsp_id;  /* optional; set in bit_mask
                                   * OMAP3_rfsp_id_present if present */
        OMAP3__seq6     ambr;  /* optional; set in bit_mask
                                * OMAP3_eps_SubscriptionData_ambr_present if
                                * present */
        struct OMAP3__seq7 {
            unsigned char   bit_mask;
#               define      OMAP3_apn_ConfigurationProfile_completeDataListIncluded_present 0x80
#               define      OMAP3_apn_ConfigurationProfile_extensionContainer_present 0x40
            unsigned short  defaultContext;
            Nulltype        completeDataListIncluded;  /* optional; set in
                                   * bit_mask
           * OMAP3_apn_ConfigurationProfile_completeDataListIncluded_present if
           * present */
            struct OMAP3__seqof2 {
                unsigned short  count;
                OMAP3__seq5     value[50];
            } epsDataList;
            OMAP3_ExtensionContainer extensionContainer;  /* optional; set in
                                   * bit_mask
                 * OMAP3_apn_ConfigurationProfile_extensionContainer_present if
                 * present */
        } apn_ConfigurationProfile;  /* optional; set in bit_mask
                                      * OMAP3_apn_ConfigurationProfile_present
                                      * if present */
        OMAP3__octet6   stn_sr;  /* optional; set in bit_mask
                                  * OMAP3_stn_sr_present if present */
        OMAP3_ExtensionContainer extensionContainer;  /* optional; set in
                                   * bit_mask
                     * OMAP3_eps_SubscriptionData_extensionContainer_present if
                     * present */
    } eps_SubscriptionData;  /* extension #16; optional; set in bit_mask
                              * OMAP3_eps_SubscriptionData_present if present */
    struct OMAP3__seqof3 {
        unsigned short  count;
        OMAP3__seq8     value[50];
    } csg_SubscriptionDataList;  /* extension #17; optional; set in bit_mask
                                  * OMAP3_csg_SubscriptionDataList_present if
                                  * present */
    Nulltype        ue_ReachabilityRequestIndicator;  /* extension #18;
                                   * optional; set in bit_mask
                             * OMAP3_ue_ReachabilityRequestIndicator_present if
                             * present */
} OMAP3_InsertSubscriberDataArg;

typedef enum OMAP3_RegionalSubscriptionResponse {
    OMAP3_networkNode_AreaRestricted = 0,
    OMAP3_tooManyZoneCodes = 1,
    OMAP3_zoneCodesConflict = 2,
    OMAP3_regionalSubscNotSupported = 3
} OMAP3_RegionalSubscriptionResponse;

typedef struct OMAP3_InsertSubscriberDataRes {
    unsigned char   bit_mask;
#       define      OMAP3_InsertSubscriberDataRes_teleserviceList_present 0x80
#       define      OMAP3_InsertSubscriberDataRes_bearerServiceList_present 0x40
#       define      OMAP3_InsertSubscriberDataRes_ss_List_present 0x20
#       define      OMAP3_odb_GeneralData_present 0x10
#       define      OMAP3_InsertSubscriberDataRes_regionalSubscriptionResponse_present 0x08
#       define      OMAP3_InsertSubscriberDataRes_supportedCamelPhases_present 0x04
#       define      OMAP3_InsertSubscriberDataRes_extensionContainer_present 0x02
#       define      OMAP3_InsertSubscriberDataRes_offeredCamel4CSIs_present 0x01
    OMAP3_TeleserviceList teleserviceList;  /* optional; set in bit_mask
                     * OMAP3_InsertSubscriberDataRes_teleserviceList_present if
                     * present */
    OMAP3_BearerServiceList bearerServiceList;  /* optional; set in bit_mask
                   * OMAP3_InsertSubscriberDataRes_bearerServiceList_present if
                   * present */
    OMAP3_SS_List   ss_List;  /* optional; set in bit_mask
                               * OMAP3_InsertSubscriberDataRes_ss_List_present
                               * if present */
    OMAP3_ODB_GeneralData odb_GeneralData;  /* optional; set in bit_mask
                                             * OMAP3_odb_GeneralData_present if
                                             * present */
    OMAP3_RegionalSubscriptionResponse regionalSubscriptionResponse;  
                                  /* optional; set in bit_mask
        * OMAP3_InsertSubscriberDataRes_regionalSubscriptionResponse_present if
        * present */
    OMAP3_SupportedCamelPhases supportedCamelPhases;  /* optional; set in
                                   * bit_mask
                * OMAP3_InsertSubscriberDataRes_supportedCamelPhases_present if
                * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                  * OMAP3_InsertSubscriberDataRes_extensionContainer_present if
                  * present */
    OMAP3_OfferedCamel4CSIs offeredCamel4CSIs;  /* extension #1; optional; set
                                   * in bit_mask
                   * OMAP3_InsertSubscriberDataRes_offeredCamel4CSIs_present if
                   * present */
} OMAP3_InsertSubscriberDataRes;

typedef struct OMAP3_BasicServiceList {
    unsigned short  count;
    OMAP3_Ext_BasicServiceCode value[70];
} OMAP3_BasicServiceList;

typedef struct OMAP3_ContextIdList {
    unsigned short  count;
    OMAP3_ContextId value[50];
} OMAP3_ContextIdList;

// exception handling:
// bits 11 to 31 shall be ignored if received by a non-IP Multimedia Core Network entity.
// bits 0-10 and 14-31 shall be ignored if received by an IP Multimedia Core Network entity.
// bits 11-13 are only applicable in an IP Multimedia Core Network.
// Bit 8 and bits 11-13 are only applicable for the NoteSubscriberDataModified operation.
typedef struct OMAP3_GPRSSubscriptionDataWithdraw {
    unsigned short  choice;
#       define      OMAP3_allGPRSData_chosen 1
#       define      OMAP3_contextIdList_chosen 2
    union _union {
        Nulltype        allGPRSData;  /* to choose, set choice to
                                       * OMAP3_allGPRSData_chosen */
        OMAP3_ContextIdList contextIdList;  /* to choose, set choice to
                                             * OMAP3_contextIdList_chosen */
    } u;
} OMAP3_GPRSSubscriptionDataWithdraw;

typedef struct OMAP3_LSAIdentityList {
    unsigned short  count;
    OMAP3_LSAIdentity value[20];
} OMAP3_LSAIdentityList;

typedef struct OMAP3_LSAInformationWithdraw {
    unsigned short  choice;
#       define      OMAP3_allLSAData_chosen 1
#       define      OMAP3_lsaIdentityList_chosen 2
    union _union {
        Nulltype        allLSAData;  /* to choose, set choice to
                                      * OMAP3_allLSAData_chosen */
        OMAP3_LSAIdentityList lsaIdentityList;  /* to choose, set choice to
                                              * OMAP3_lsaIdentityList_chosen */
    } u;
} OMAP3_LSAInformationWithdraw;

typedef struct OMAP3_SpecificCSI_Withdraw {
    unsigned short  length;  /* number of significant bits */
    unsigned char   value[4];
} OMAP3_SpecificCSI_Withdraw;
#define                     OMAP3_SpecificCSI_Withdraw_o_csi 0x80
#define                     OMAP3_SpecificCSI_Withdraw_o_csi_byte 0
#define                     OMAP3_ss_csi 0x40
#define                     OMAP3_ss_csi_byte 0
#define                     OMAP3_tif_csi 0x20
#define                     OMAP3_tif_csi_byte 0
#define                     OMAP3_SpecificCSI_Withdraw_d_csi 0x10
#define                     OMAP3_SpecificCSI_Withdraw_d_csi_byte 0
#define                     OMAP3_SpecificCSI_Withdraw_vt_csi 0x08
#define                     OMAP3_SpecificCSI_Withdraw_vt_csi_byte 0
#define                     OMAP3_mo_sms_csi 0x04
#define                     OMAP3_mo_sms_csi_byte 0
#define                     OMAP3_m_csi 0x02
#define                     OMAP3_m_csi_byte 0
#define                     OMAP3_gprs_csi 0x01
#define                     OMAP3_gprs_csi_byte 0
#define                     OMAP3_SpecificCSI_Withdraw_t_csi 0x80
#define                     OMAP3_SpecificCSI_Withdraw_t_csi_byte 1
#define                     OMAP3_SpecificCSI_Withdraw_mt_sms_csi 0x40
#define                     OMAP3_SpecificCSI_Withdraw_mt_sms_csi_byte 1
#define                     OMAP3_SpecificCSI_Withdraw_mg_csi 0x20
#define                     OMAP3_SpecificCSI_Withdraw_mg_csi_byte 1
#define                     OMAP3_SpecificCSI_Withdraw_o_IM_CSI 0x10
#define                     OMAP3_SpecificCSI_Withdraw_o_IM_CSI_byte 1
#define                     OMAP3_SpecificCSI_Withdraw_d_IM_CSI 0x08
#define                     OMAP3_SpecificCSI_Withdraw_d_IM_CSI_byte 1
#define                     OMAP3_SpecificCSI_Withdraw_vt_IM_CSI 0x04
#define                     OMAP3_SpecificCSI_Withdraw_vt_IM_CSI_byte 1

typedef struct OMAP3_DeleteSubscriberDataArg {
    unsigned short  bit_mask;
#       define      OMAP3_DeleteSubscriberDataArg_basicServiceList_present 0x8000
#       define      OMAP3_DeleteSubscriberDataArg_ss_List_present 0x4000
#       define      OMAP3_DeleteSubscriberDataArg_roamingRestrictionDueToUnsupportedFeature_present 0x2000
#       define      OMAP3_regionalSubscriptionIdentifier_present 0x1000
#       define      OMAP3_vbsGroupIndication_present 0x0800
#       define      OMAP3_vgcsGroupIndication_present 0x0400
#       define      OMAP3_camelSubscriptionInfoWithdraw_present 0x0200
#       define      OMAP3_DeleteSubscriberDataArg_extensionContainer_present 0x0100
#       define      OMAP3_gprsSubscriptionDataWithdraw_present 0x0080
#       define      OMAP3_roamingRestrictedInSgsnDueToUnsuppportedFeature_present 0x0040
#       define      OMAP3_lsaInformationWithdraw_present 0x0020
#       define      OMAP3_gmlc_ListWithdraw_present 0x0010
#       define      OMAP3_DeleteSubscriberDataArg_istInformationWithdraw_present 0x0008
#       define      OMAP3_specificCSI_Withdraw_present 0x0004
#       define      OMAP3_chargingCharacteristicsWithdraw_present 0x0002
    OMAP3_IMSI      imsi;
    OMAP3_BasicServiceList basicServiceList;  /* optional; set in bit_mask
                    * OMAP3_DeleteSubscriberDataArg_basicServiceList_present if
                    * present */
	// The exception handling for reception of unsupported/not allocated
	// basicServiceCodes is defined in section 6.8.2
    OMAP3_SS_List   ss_List;  /* optional; set in bit_mask
                               * OMAP3_DeleteSubscriberDataArg_ss_List_present
                               * if present */
    Nulltype        roamingRestrictionDueToUnsupportedFeature;  /* optional; set
                                   * in bit_mask
       * OMAP3_DeleteSubscriberDataArg_roamingRestrictionDueToUnsupportedFeature_present if
       * present */
    OMAP3_ZoneCode  regionalSubscriptionIdentifier;  /* optional; set in
                                   * bit_mask
                              * OMAP3_regionalSubscriptionIdentifier_present if
                              * present */
    Nulltype        vbsGroupIndication;  /* optional; set in bit_mask
                                          * OMAP3_vbsGroupIndication_present if
                                          * present */
    Nulltype        vgcsGroupIndication;  /* optional; set in bit_mask
                                           * OMAP3_vgcsGroupIndication_present
                                           * if present */
    Nulltype        camelSubscriptionInfoWithdraw;  /* optional; set in bit_mask
                               * OMAP3_camelSubscriptionInfoWithdraw_present if
                               * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                  * OMAP3_DeleteSubscriberDataArg_extensionContainer_present if
                  * present */
    OMAP3_GPRSSubscriptionDataWithdraw gprsSubscriptionDataWithdraw;  
                                  /* extension #1; optional; set in bit_mask
                                   * OMAP3_gprsSubscriptionDataWithdraw_present
                                   * if present */
    Nulltype        roamingRestrictedInSgsnDueToUnsuppportedFeature;  
                                  /* extension #2; optional; set in bit_mask
             * OMAP3_roamingRestrictedInSgsnDueToUnsuppportedFeature_present if
             * present */
    OMAP3_LSAInformationWithdraw lsaInformationWithdraw;  /* extension #3;
                                   * optional; set in bit_mask
                                   * OMAP3_lsaInformationWithdraw_present if
                                   * present */
    Nulltype        gmlc_ListWithdraw;  /* extension #4; optional; set in
                                   * bit_mask OMAP3_gmlc_ListWithdraw_present if
                                   * present */
    Nulltype        istInformationWithdraw;  /* extension #5; optional; set in
                                   * bit_mask
              * OMAP3_DeleteSubscriberDataArg_istInformationWithdraw_present if
              * present */
    OMAP3_SpecificCSI_Withdraw specificCSI_Withdraw;  /* extension #6; optional;
                                   * set in bit_mask
                                   * OMAP3_specificCSI_Withdraw_present if
                                   * present */
    Nulltype        chargingCharacteristicsWithdraw;  /* extension #7; optional;
                                   * set in bit_mask
                             * OMAP3_chargingCharacteristicsWithdraw_present if
                             * present */
} OMAP3_DeleteSubscriberDataArg;

typedef struct OMAP3_DeleteSubscriberDataRes {
    unsigned char   bit_mask;
#       define      OMAP3_DeleteSubscriberDataRes_regionalSubscriptionResponse_present 0x80
#       define      OMAP3_DeleteSubscriberDataRes_extensionContainer_present 0x40
    OMAP3_RegionalSubscriptionResponse regionalSubscriptionResponse;  
                                  /* optional; set in bit_mask
        * OMAP3_DeleteSubscriberDataRes_regionalSubscriptionResponse_present if
        * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                  * OMAP3_DeleteSubscriberDataRes_extensionContainer_present if
                  * present */
} OMAP3_DeleteSubscriberDataRes;

// A node supporting Camel phase 4 shall mark in the BIT STRING all Camel4 CSIs 
// it offers.
// Other values than listed above shall be discarded.
typedef struct OMAP3_OfferedCamel4Functionalities {
    unsigned short  length;  /* number of significant bits */
    unsigned char   value[8];
} OMAP3_OfferedCamel4Functionalities;
#define                     OMAP3_initiateCallAttempt 0x80
#define                     OMAP3_initiateCallAttempt_byte 0
#define                     OMAP3_splitLeg 0x40
#define                     OMAP3_splitLeg_byte 0
#define                     OMAP3_moveLeg 0x20
#define                     OMAP3_moveLeg_byte 0
#define                     OMAP3_disconnectLeg 0x10
#define                     OMAP3_disconnectLeg_byte 0
#define                     OMAP3_entityReleased 0x08
#define                     OMAP3_entityReleased_byte 0
#define                     OMAP3_dfc_WithArgument 0x04
#define                     OMAP3_dfc_WithArgument_byte 0
#define                     OMAP3_playTone 0x02
#define                     OMAP3_playTone_byte 0
#define                     OMAP3_dtmf_MidCall 0x01
#define                     OMAP3_dtmf_MidCall_byte 0
#define                     OMAP3_chargingIndicator 0x80
#define                     OMAP3_chargingIndicator_byte 1
#define                     OMAP3_alertingDP 0x40
#define                     OMAP3_alertingDP_byte 1
#define                     OMAP3_locationAtAlerting 0x20
#define                     OMAP3_locationAtAlerting_byte 1
#define                     OMAP3_changeOfPositionDP 0x10
#define                     OMAP3_changeOfPositionDP_byte 1
#define                     OMAP3_or_Interactions 0x08
#define                     OMAP3_or_Interactions_byte 1
#define                     OMAP3_warningToneEnhancements 0x04
#define                     OMAP3_warningToneEnhancements_byte 1
#define                     OMAP3_cf_Enhancements 0x02
#define                     OMAP3_cf_Enhancements_byte 1
#define                     OMAP3_subscribedEnhancedDialledServices 0x01
#define                     OMAP3_subscribedEnhancedDialledServices_byte 1
#define                     OMAP3_servingNetworkEnhancedDialledServices 0x80
#define                     OMAP3_servingNetworkEnhancedDialledServices_byte 2
#define                     OMAP3_criteriaForChangeOfPositionDP 0x40
#define                     OMAP3_criteriaForChangeOfPositionDP_byte 2
#define                     OMAP3_serviceChangeDP 0x20
#define                     OMAP3_serviceChangeDP_byte 2
#define                     OMAP3_collectInformation 0x10
#define                     OMAP3_collectInformation_byte 2

	// exception handling:
	// For T-BcsmCamelTDPData sequences containing this parameter with any other
	// value than the ones listed above, the receiver shall ignore the whole
	// T-BcsmCamelTDPData sequence.
// gprs location information retrieval types
typedef struct OMAP3_SendRoutingInfoForGprsArg {
    unsigned char   bit_mask;
#       define      OMAP3_SendRoutingInfoForGprsArg_ggsn_Address_present 0x80
#       define      OMAP3_SendRoutingInfoForGprsArg_extensionContainer_present 0x40
    OMAP3_IMSI      imsi;
    OMAP3_GSN_Address ggsn_Address;  /* optional; set in bit_mask
                      * OMAP3_SendRoutingInfoForGprsArg_ggsn_Address_present if
                      * present */
    OMAP3_ISDN_AddressString ggsn_Number;
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                * OMAP3_SendRoutingInfoForGprsArg_extensionContainer_present if
                * present */
} OMAP3_SendRoutingInfoForGprsArg;

typedef struct OMAP3_SendRoutingInfoForGprsRes {
    unsigned char   bit_mask;
#       define      OMAP3_SendRoutingInfoForGprsRes_ggsn_Address_present 0x80
#       define      OMAP3_mobileNotReachableReason_present 0x40
#       define      OMAP3_SendRoutingInfoForGprsRes_extensionContainer_present 0x20
    OMAP3_GSN_Address sgsn_Address;
    OMAP3_GSN_Address ggsn_Address;  /* optional; set in bit_mask
                      * OMAP3_SendRoutingInfoForGprsRes_ggsn_Address_present if
                      * present */
    OMAP3_AbsentSubscriberDiagnosticSM mobileNotReachableReason;  /* optional;
                                   * set in bit_mask
                                   * OMAP3_mobileNotReachableReason_present if
                                   * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                * OMAP3_SendRoutingInfoForGprsRes_extensionContainer_present if
                * present */
} OMAP3_SendRoutingInfoForGprsRes;

// failure report types
typedef struct OMAP3_FailureReportArg {
    unsigned char   bit_mask;
#       define      OMAP3_FailureReportArg_ggsn_Address_present 0x80
#       define      OMAP3_FailureReportArg_extensionContainer_present 0x40
    OMAP3_IMSI      imsi;
    OMAP3_ISDN_AddressString ggsn_Number;
    OMAP3_GSN_Address ggsn_Address;  /* optional; set in bit_mask
                               * OMAP3_FailureReportArg_ggsn_Address_present if
                               * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                         * OMAP3_FailureReportArg_extensionContainer_present if
                         * present */
} OMAP3_FailureReportArg;

typedef struct OMAP3_FailureReportRes {
    unsigned char   bit_mask;
#       define      OMAP3_FailureReportRes_ggsn_Address_present 0x80
#       define      OMAP3_FailureReportRes_extensionContainer_present 0x40
    OMAP3_GSN_Address ggsn_Address;  /* optional; set in bit_mask
                               * OMAP3_FailureReportRes_ggsn_Address_present if
                               * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                         * OMAP3_FailureReportRes_extensionContainer_present if
                         * present */
} OMAP3_FailureReportRes;

// gprs notification types
typedef struct OMAP3_NoteMsPresentForGprsArg {
    unsigned char   bit_mask;
#       define      OMAP3_NoteMsPresentForGprsArg_ggsn_Address_present 0x80
#       define      OMAP3_NoteMsPresentForGprsArg_extensionContainer_present 0x40
    OMAP3_IMSI      imsi;
    OMAP3_GSN_Address sgsn_Address;
    OMAP3_GSN_Address ggsn_Address;  /* optional; set in bit_mask
                        * OMAP3_NoteMsPresentForGprsArg_ggsn_Address_present if
                        * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                  * OMAP3_NoteMsPresentForGprsArg_extensionContainer_present if
                  * present */
} OMAP3_NoteMsPresentForGprsArg;

typedef struct OMAP3_NoteMsPresentForGprsRes {
    unsigned char   bit_mask;
#       define      OMAP3_NoteMsPresentForGprsRes_extensionContainer_present 0x80
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                  * OMAP3_NoteMsPresentForGprsRes_extensionContainer_present if
                  * present */
} OMAP3_NoteMsPresentForGprsRes;

// fault recovery types
typedef struct OMAP3_ResetArg {
    unsigned char   bit_mask;
#       define      OMAP3_hlr_List_present 0x80
    OMAP3_ISDN_AddressString hlr_Number;
    OMAP3_HLR_List  hlr_List;  /* optional; set in bit_mask
                                * OMAP3_hlr_List_present if present */
} OMAP3_ResetArg;

typedef struct OMAP3_RestoreDataArg {
    unsigned char   bit_mask;
#       define      OMAP3_RestoreDataArg_lmsi_present 0x80
#       define      OMAP3_RestoreDataArg_extensionContainer_present 0x40
#       define      OMAP3_RestoreDataArg_vlr_Capability_present 0x20
    OMAP3_IMSI      imsi;
    OMAP3_LMSI      lmsi;  /* optional; set in bit_mask
                            * OMAP3_RestoreDataArg_lmsi_present if present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                           * OMAP3_RestoreDataArg_extensionContainer_present if
                           * present */
    OMAP3_VLR_Capability vlr_Capability;  /* extension #1; optional; set in
                                   * bit_mask
                                   * OMAP3_RestoreDataArg_vlr_Capability_present
                                   * if present */
} OMAP3_RestoreDataArg;

typedef struct OMAP3_RestoreDataRes {
    unsigned char   bit_mask;
#       define      OMAP3_msNotReachable_present 0x80
#       define      OMAP3_RestoreDataRes_extensionContainer_present 0x40
    OMAP3_ISDN_AddressString hlr_Number;
    Nulltype        msNotReachable;  /* optional; set in bit_mask
                                      * OMAP3_msNotReachable_present if
                                      * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                           * OMAP3_RestoreDataRes_extensionContainer_present if
                           * present */
} OMAP3_RestoreDataRes;

//	currentLocation shall be absent if locationInformation is absent
typedef enum OMAP3_DomainType {
    OMAP3_cs_Domain = 0,
    OMAP3_ps_Domain = 1
} OMAP3_DomainType;

	// This parameter carries the value part of the MS Radio Access Capability IE defined in
	// 3GPP TS 24.008 [35].
typedef struct OMAP3_RequestedInfo {
    unsigned char   bit_mask;
#       define      OMAP3_RequestedInfo_locationInformation_present 0x80
#       define      OMAP3_RequestedInfo_subscriberState_present 0x40
#       define      OMAP3_RequestedInfo_extensionContainer_present 0x20
#       define      OMAP3_currentLocation_present 0x10
#       define      OMAP3_requestedDomain_present 0x08
#       define      OMAP3_RequestedInfo_imei_present 0x04
#       define      OMAP3_ms_classmark_present 0x02
#       define      OMAP3_mnpRequestedInfo_present 0x01
    Nulltype        locationInformation;  /* optional; set in bit_mask
                           * OMAP3_RequestedInfo_locationInformation_present if
                           * present */
    Nulltype        subscriberState;  /* optional; set in bit_mask
                               * OMAP3_RequestedInfo_subscriberState_present if
                               * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                            * OMAP3_RequestedInfo_extensionContainer_present if
                            * present */
    Nulltype        currentLocation;  /* extension #1; optional; set in bit_mask
                                       * OMAP3_currentLocation_present if
                                       * present */
    OMAP3_DomainType requestedDomain;  /* extension #2; optional; set in
                                   * bit_mask OMAP3_requestedDomain_present if
                                   * present */
    Nulltype        imei;  /* extension #3; optional; set in bit_mask
                            * OMAP3_RequestedInfo_imei_present if present */
    Nulltype        ms_classmark;  /* extension #4; optional; set in bit_mask
                                    * OMAP3_ms_classmark_present if present */
    Nulltype        mnpRequestedInfo;  /* extension #5; optional; set in
                                   * bit_mask OMAP3_mnpRequestedInfo_present if
                                   * present */
} OMAP3_RequestedInfo;

    // When Long-Group-Id is less than eight characters in length, the TBCD filler (1111)
    // is used to fill unused half octets.
      // Refers to the Group Identification as specified in 3GPP TS 23.003 
        // and 3GPP TS 43.068/ 43.069
typedef struct OMAP3_ProvideSubscriberInfoArg {
    unsigned char   bit_mask;
#       define      OMAP3_ProvideSubscriberInfoArg_lmsi_present 0x80
#       define      OMAP3_ProvideSubscriberInfoArg_extensionContainer_present 0x40
    OMAP3_IMSI      imsi;
    OMAP3_LMSI      lmsi;  /* optional; set in bit_mask
                            * OMAP3_ProvideSubscriberInfoArg_lmsi_present if
                            * present */
    OMAP3_RequestedInfo requestedInfo;
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                 * OMAP3_ProvideSubscriberInfoArg_extensionContainer_present if
                 * present */
} OMAP3_ProvideSubscriberInfoArg;

typedef struct OMAP3_ProvideSubscriberInfoRes {
    unsigned char   bit_mask;
#       define      OMAP3_ProvideSubscriberInfoRes_extensionContainer_present 0x80
    OMAP3_SubscriberInfo subscriberInfo;
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                 * OMAP3_ProvideSubscriberInfoRes_extensionContainer_present if
                 * present */
} OMAP3_ProvideSubscriberInfoRes;

// any time interrogation info types
typedef struct OMAP3_AnyTimeInterrogationArg {
    unsigned char   bit_mask;
#       define      OMAP3_AnyTimeInterrogationArg_extensionContainer_present 0x80
    OMAP3_SubscriberIdentity subscriberIdentity;
    OMAP3_RequestedInfo requestedInfo;
    OMAP3_ISDN_AddressString gsmSCF_Address;
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                  * OMAP3_AnyTimeInterrogationArg_extensionContainer_present if
                  * present */
} OMAP3_AnyTimeInterrogationArg;

typedef struct OMAP3_AnyTimeInterrogationRes {
    unsigned char   bit_mask;
#       define      OMAP3_AnyTimeInterrogationRes_extensionContainer_present 0x80
    OMAP3_SubscriberInfo subscriberInfo;
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                  * OMAP3_AnyTimeInterrogationRes_extensionContainer_present if
                  * present */
} OMAP3_AnyTimeInterrogationRes;

typedef enum OMAP3_RequestedCAMEL_SubscriptionInfo {
    OMAP3_o_CSI = 0,
    OMAP3_t_CSI = 1,
    OMAP3_vt_CSI = 2,
    OMAP3_tif_CSI = 3,
    OMAP3_gprs_CSI = 4,
    OMAP3_mo_sms_CSI = 5,
    OMAP3_ss_CSI = 6,
    OMAP3_m_CSI = 7,
    OMAP3_RequestedCAMEL_SubscriptionInfo_d_csi = 8
} OMAP3_RequestedCAMEL_SubscriptionInfo;

typedef enum OMAP3_AdditionalRequestedCAMEL_SubscriptionInfo {
    OMAP3_mt_sms_CSI = 0,
    OMAP3_AdditionalRequestedCAMEL_SubscriptionInfo_mg_csi = 1,
    OMAP3_AdditionalRequestedCAMEL_SubscriptionInfo_o_IM_CSI = 2,
    OMAP3_AdditionalRequestedCAMEL_SubscriptionInfo_d_IM_CSI = 3,
    OMAP3_AdditionalRequestedCAMEL_SubscriptionInfo_vt_IM_CSI = 4
} OMAP3_AdditionalRequestedCAMEL_SubscriptionInfo;

typedef struct OMAP3_RequestedSubscriptionInfo {
    unsigned char   bit_mask;
#       define      OMAP3_requestedSS_Info_present 0x80
#       define      OMAP3_odb_present 0x40
#       define      OMAP3_requestedCAMEL_SubscriptionInfo_present 0x20
#       define      OMAP3_RequestedSubscriptionInfo_supportedVLR_CAMEL_Phases_present 0x10
#       define      OMAP3_RequestedSubscriptionInfo_supportedSGSN_CAMEL_Phases_present 0x08
#       define      OMAP3_RequestedSubscriptionInfo_extensionContainer_present 0x04
#       define      OMAP3_RequestedSubscriptionInfo_additionalRequestedCAMEL_SubscriptionInfo_present 0x02
    OMAP3_SS_ForBS_Code requestedSS_Info;  /* optional; set in bit_mask
                                            * OMAP3_requestedSS_Info_present if
                                            * present */
    Nulltype        odb;  /* optional; set in bit_mask OMAP3_odb_present if
                           * present */
    OMAP3_RequestedCAMEL_SubscriptionInfo requestedCAMEL_SubscriptionInfo;  
                                        /* optional; set in bit_mask
                             * OMAP3_requestedCAMEL_SubscriptionInfo_present if
                             * present */
    Nulltype        supportedVLR_CAMEL_Phases;  /* optional; set in bit_mask
         * OMAP3_RequestedSubscriptionInfo_supportedVLR_CAMEL_Phases_present if
         * present */
    Nulltype        supportedSGSN_CAMEL_Phases;  /* optional; set in bit_mask
        * OMAP3_RequestedSubscriptionInfo_supportedSGSN_CAMEL_Phases_present if
        * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                * OMAP3_RequestedSubscriptionInfo_extensionContainer_present if
                * present */
    OMAP3_AdditionalRequestedCAMEL_SubscriptionInfo additionalRequestedCAMEL_SubscriptionInfo;                          /* extension #1; optional; set in
                                   * bit_mask
         * OMAP3_RequestedSubscriptionInfo_additionalRequestedCAMEL_SubscriptionInfo_present if
         * present */
} OMAP3_RequestedSubscriptionInfo;

// any time information handling types
typedef struct OMAP3_AnyTimeSubscriptionInterrogationArg {
    unsigned char   bit_mask;
#       define      OMAP3_AnyTimeSubscriptionInterrogationArg_extensionContainer_present 0x80
#       define      OMAP3_AnyTimeSubscriptionInterrogationArg_longFTN_Supported_present 0x40
    OMAP3_SubscriberIdentity subscriberIdentity;
    OMAP3_RequestedSubscriptionInfo requestedSubscriptionInfo;
    OMAP3_ISDN_AddressString gsmSCF_Address;
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
      * OMAP3_AnyTimeSubscriptionInterrogationArg_extensionContainer_present if
      * present */
    Nulltype        longFTN_Supported;  /* optional; set in bit_mask
       * OMAP3_AnyTimeSubscriptionInterrogationArg_longFTN_Supported_present if
       * present */
} OMAP3_AnyTimeSubscriptionInterrogationArg;

//	exception handling: unknown values shall be discarded by the receiver.
typedef struct OMAP3_CallForwardingData {
    unsigned char   bit_mask;
#       define      OMAP3_CallForwardingData_notificationToCSE_present 0x80
#       define      OMAP3_CallForwardingData_extensionContainer_present 0x40
    OMAP3_Ext_ForwFeatureList forwardingFeatureList;
    Nulltype        notificationToCSE;  /* optional; set in bit_mask
                        * OMAP3_CallForwardingData_notificationToCSE_present if
                        * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                       * OMAP3_CallForwardingData_extensionContainer_present if
                       * present */
} OMAP3_CallForwardingData;

typedef unsigned short  OMAP3_WrongPasswordAttemptsCounter;

typedef struct OMAP3_CallBarringData {
    unsigned char   bit_mask;
#       define      OMAP3_CallBarringData_password_present 0x80
#       define      OMAP3_CallBarringData_wrongPasswordAttemptsCounter_present 0x40
#       define      OMAP3_CallBarringData_notificationToCSE_present 0x20
#       define      OMAP3_CallBarringData_extensionContainer_present 0x10
    OMAP3_Ext_CallBarFeatureList callBarringFeatureList;
    OMAP3_Password  password;  /* optional; set in bit_mask
                                * OMAP3_CallBarringData_password_present if
                                * present */
    OMAP3_WrongPasswordAttemptsCounter wrongPasswordAttemptsCounter;  
                                  /* optional; set in bit_mask
                * OMAP3_CallBarringData_wrongPasswordAttemptsCounter_present if
                * present */
    Nulltype        notificationToCSE;  /* optional; set in bit_mask
                           * OMAP3_CallBarringData_notificationToCSE_present if
                           * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                          * OMAP3_CallBarringData_extensionContainer_present if
                          * present */
} OMAP3_CallBarringData;

typedef struct OMAP3_ODB_Info {
    unsigned char   bit_mask;
#       define      OMAP3_ODB_Info_notificationToCSE_present 0x80
#       define      OMAP3_ODB_Info_extensionContainer_present 0x40
    OMAP3_ODB_Data  odb_Data;
    Nulltype        notificationToCSE;  /* optional; set in bit_mask
                                  * OMAP3_ODB_Info_notificationToCSE_present if
                                  * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                                 * OMAP3_ODB_Info_extensionContainer_present if
                                 * present */
} OMAP3_ODB_Info;

typedef struct OMAP3_CAMEL_SubscriptionInfo {
    unsigned int    bit_mask;
#       define      OMAP3_CAMEL_SubscriptionInfo_o_CSI_present 0x80000000
#       define      OMAP3_CAMEL_SubscriptionInfo_o_BcsmCamelTDP_CriteriaList_present 0x40000000
#       define      OMAP3_CAMEL_SubscriptionInfo_d_CSI_present 0x20000000
#       define      OMAP3_CAMEL_SubscriptionInfo_t_CSI_present 0x10000000
#       define      OMAP3_CAMEL_SubscriptionInfo_t_BCSM_CAMEL_TDP_CriteriaList_present 0x08000000
#       define      OMAP3_CAMEL_SubscriptionInfo_vt_CSI_present 0x04000000
#       define      OMAP3_vt_BCSM_CAMEL_TDP_CriteriaList_present 0x02000000
#       define      OMAP3_CAMEL_SubscriptionInfo_tif_CSI_present 0x01000000
#       define      OMAP3_tif_CSI_NotificationToCSE_present 0x00800000
#       define      OMAP3_CAMEL_SubscriptionInfo_gprs_CSI_present 0x00400000
#       define      OMAP3_CAMEL_SubscriptionInfo_mo_sms_CSI_present 0x00200000
#       define      OMAP3_CAMEL_SubscriptionInfo_ss_CSI_present 0x00100000
#       define      OMAP3_CAMEL_SubscriptionInfo_m_CSI_present 0x00080000
#       define      OMAP3_CAMEL_SubscriptionInfo_extensionContainer_present 0x00040000
#       define      OMAP3_specificCSIDeletedList_present 0x00020000
#       define      OMAP3_CAMEL_SubscriptionInfo_mt_sms_CSI_present 0x00010000
#       define      OMAP3_CAMEL_SubscriptionInfo_mt_smsCAMELTDP_CriteriaList_present 0x00008000
#       define      OMAP3_CAMEL_SubscriptionInfo_mg_csi_present 0x00004000
#       define      OMAP3_o_IM_CSI_present 0x00002000
#       define      OMAP3_o_IM_BcsmCamelTDP_CriteriaList_present 0x00001000
#       define      OMAP3_d_IM_CSI_present 0x00000800
#       define      OMAP3_vt_IM_CSI_present 0x00000400
#       define      OMAP3_vt_IM_BCSM_CAMEL_TDP_CriteriaList_present 0x00000200
    OMAP3_O_CSI     o_CSI;  /* optional; set in bit_mask
                             * OMAP3_CAMEL_SubscriptionInfo_o_CSI_present if
                             * present */
    OMAP3_O_BcsmCamelTDPCriteriaList o_BcsmCamelTDP_CriteriaList;  /* optional;
                                   * set in bit_mask
          * OMAP3_CAMEL_SubscriptionInfo_o_BcsmCamelTDP_CriteriaList_present if
          * present */
    OMAP3_D_CSI     d_CSI;  /* optional; set in bit_mask
                             * OMAP3_CAMEL_SubscriptionInfo_d_CSI_present if
                             * present */
    OMAP3_T_CSI     t_CSI;  /* optional; set in bit_mask
                             * OMAP3_CAMEL_SubscriptionInfo_t_CSI_present if
                             * present */
    OMAP3_T_BCSM_CAMEL_TDP_CriteriaList t_BCSM_CAMEL_TDP_CriteriaList;  
                                  /* optional; set in bit_mask
        * OMAP3_CAMEL_SubscriptionInfo_t_BCSM_CAMEL_TDP_CriteriaList_present if
        * present */
    OMAP3_T_CSI     vt_CSI;  /* optional; set in bit_mask
                              * OMAP3_CAMEL_SubscriptionInfo_vt_CSI_present if
                              * present */
    OMAP3_T_BCSM_CAMEL_TDP_CriteriaList vt_BCSM_CAMEL_TDP_CriteriaList;  
                                  /* optional; set in bit_mask
                              * OMAP3_vt_BCSM_CAMEL_TDP_CriteriaList_present if
                              * present */
    Nulltype        tif_CSI;  /* optional; set in bit_mask
                               * OMAP3_CAMEL_SubscriptionInfo_tif_CSI_present if
                               * present */
    Nulltype        tif_CSI_NotificationToCSE;  /* optional; set in bit_mask
                                   * OMAP3_tif_CSI_NotificationToCSE_present if
                                   * present */
    OMAP3_GPRS_CSI  gprs_CSI;  /* optional; set in bit_mask
                                * OMAP3_CAMEL_SubscriptionInfo_gprs_CSI_present
                                * if present */
    OMAP3_SMS_CSI   mo_sms_CSI;  /* optional; set in bit_mask
                           * OMAP3_CAMEL_SubscriptionInfo_mo_sms_CSI_present if
                           * present */
    OMAP3_SS_CSI    ss_CSI;  /* optional; set in bit_mask
                              * OMAP3_CAMEL_SubscriptionInfo_ss_CSI_present if
                              * present */
    OMAP3_M_CSI     m_CSI;  /* optional; set in bit_mask
                             * OMAP3_CAMEL_SubscriptionInfo_m_CSI_present if
                             * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                   * OMAP3_CAMEL_SubscriptionInfo_extensionContainer_present if
                   * present */
    OMAP3_SpecificCSI_Withdraw specificCSIDeletedList;  /* extension #1;
                                   * optional; set in bit_mask
                                   * OMAP3_specificCSIDeletedList_present if
                                   * present */
    OMAP3_SMS_CSI   mt_sms_CSI;  /* extension #2; optional; set in bit_mask
                           * OMAP3_CAMEL_SubscriptionInfo_mt_sms_CSI_present if
                           * present */
    OMAP3_MT_smsCAMELTDP_CriteriaList mt_smsCAMELTDP_CriteriaList;  
                                  /* extension #3; optional; set in bit_mask
          * OMAP3_CAMEL_SubscriptionInfo_mt_smsCAMELTDP_CriteriaList_present if
          * present */
    OMAP3_MG_CSI    mg_csi;  /* extension #4; optional; set in bit_mask
                              * OMAP3_CAMEL_SubscriptionInfo_mg_csi_present if
                              * present */
    OMAP3_O_CSI     o_IM_CSI;  /* extension #5; optional; set in bit_mask
                                * OMAP3_o_IM_CSI_present if present */
    OMAP3_O_BcsmCamelTDPCriteriaList o_IM_BcsmCamelTDP_CriteriaList;  
                                  /* extension #6; optional; set in bit_mask
                              * OMAP3_o_IM_BcsmCamelTDP_CriteriaList_present if
                              * present */
    OMAP3_D_CSI     d_IM_CSI;  /* extension #7; optional; set in bit_mask
                                * OMAP3_d_IM_CSI_present if present */
    OMAP3_T_CSI     vt_IM_CSI;  /* extension #8; optional; set in bit_mask
                                 * OMAP3_vt_IM_CSI_present if present */
    OMAP3_T_BCSM_CAMEL_TDP_CriteriaList vt_IM_BCSM_CAMEL_TDP_CriteriaList;  
                                        /* extension #9; optional; set in
                                   * bit_mask
                           * OMAP3_vt_IM_BCSM_CAMEL_TDP_CriteriaList_present if
                           * present */
} OMAP3_CAMEL_SubscriptionInfo;

typedef struct OMAP3__octet8 {
    unsigned short  length;
    unsigned char   value[5];
} OMAP3__octet8;

typedef struct OMAP3__choice1 {
    unsigned short  choice;
#       define      OMAP3_basicServiceList_ext_BearerService_chosen 1
#       define      OMAP3_basicServiceList_ext_Teleservice_chosen 2
    union _union {
        OMAP3__octet8   ext_BearerService;  /* to choose, set choice to
                           * OMAP3_basicServiceList_ext_BearerService_chosen */
        OMAP3__octet8   ext_Teleservice;  /* to choose, set choice to
                             * OMAP3_basicServiceList_ext_Teleservice_chosen */
    } u;
} OMAP3__choice1;

typedef struct OMAP3__seq10 {
    unsigned char   bit_mask;
#       define      OMAP3_msisdn_BS_List_basicServiceList_present 0x80
#       define      OMAP3_msisdn_BS_List_extensionContainer_present 0x40
    OMAP3__octet6   msisdn;
    struct OMAP3__seqof4 {
        unsigned short  count;
        OMAP3__choice1  value[70];
    } basicServiceList;  /* optional; set in bit_mask
                          * OMAP3_msisdn_BS_List_basicServiceList_present if
                          * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                           * OMAP3_msisdn_BS_List_extensionContainer_present if
                           * present */
} OMAP3__seq10;

typedef struct OMAP3_AnyTimeSubscriptionInterrogationRes {
    unsigned short  bit_mask;
#       define      OMAP3_callForwardingData_present 0x8000
#       define      OMAP3_callBarringData_present 0x4000
#       define      OMAP3_AnyTimeSubscriptionInterrogationRes_odb_Info_present 0x2000
#       define      OMAP3_AnyTimeSubscriptionInterrogationRes_camel_SubscriptionInfo_present 0x1000
#       define      OMAP3_AnyTimeSubscriptionInterrogationRes_supportedVLR_CAMEL_Phases_present 0x0800
#       define      OMAP3_AnyTimeSubscriptionInterrogationRes_supportedSGSN_CAMEL_Phases_present 0x0400
#       define      OMAP3_AnyTimeSubscriptionInterrogationRes_extensionContainer_present 0x0200
#       define      OMAP3_offeredCamel4CSIsInVLR_present 0x0100
#       define      OMAP3_offeredCamel4CSIsInSGSN_present 0x0080
#       define      OMAP3_msisdn_BS_List_present 0x0040
    OMAP3_CallForwardingData callForwardingData;  /* optional; set in bit_mask
                                          * OMAP3_callForwardingData_present if
                                          * present */
    OMAP3_CallBarringData callBarringData;  /* optional; set in bit_mask
                                             * OMAP3_callBarringData_present if
                                             * present */
    OMAP3_ODB_Info  odb_Info;  /* optional; set in bit_mask
                * OMAP3_AnyTimeSubscriptionInterrogationRes_odb_Info_present if
                * present */
    OMAP3_CAMEL_SubscriptionInfo camel_SubscriptionInfo;  /* optional; set in
                                   * bit_mask
  * OMAP3_AnyTimeSubscriptionInterrogationRes_camel_SubscriptionInfo_present if
  * present */
    OMAP3_SupportedCamelPhases supportedVLR_CAMEL_Phases;  /* optional; set in
                                   * bit_mask
   * OMAP3_AnyTimeSubscriptionInterrogationRes_supportedVLR_CAMEL_Phases_present if
   * present */
    OMAP3_SupportedCamelPhases supportedSGSN_CAMEL_Phases;  /* optional; set in
                                   * bit_mask
    * OMAP3_AnyTimeSubscriptionInterrogationRes_supportedSGSN_CAMEL_Phases_present if
    * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
      * OMAP3_AnyTimeSubscriptionInterrogationRes_extensionContainer_present if
      * present */
    OMAP3_OfferedCamel4CSIs offeredCamel4CSIsInVLR;  /* extension #1; optional;
                                   * set in bit_mask
                                   * OMAP3_offeredCamel4CSIsInVLR_present if
                                   * present */
    OMAP3_OfferedCamel4CSIs offeredCamel4CSIsInSGSN;  /* extension #2; optional;
                                   * set in bit_mask
                                   * OMAP3_offeredCamel4CSIsInSGSN_present if
                                   * present */
    struct OMAP3__seqof5 {
        unsigned short  count;
        OMAP3__seq10    value[50];
    } msisdn_BS_List;  /* extension #3; optional; set in bit_mask
                        * OMAP3_msisdn_BS_List_present if present */
} OMAP3_AnyTimeSubscriptionInterrogationRes;

typedef enum OMAP3_ModificationInstruction {
    OMAP3_deactivate = 0,
    OMAP3_activate = 1
} OMAP3_ModificationInstruction;

typedef struct OMAP3_ModificationRequestFor_CF_Info {
    unsigned char   bit_mask;
#       define      OMAP3_ModificationRequestFor_CF_Info_basicService_present 0x80
#       define      OMAP3_ModificationRequestFor_CF_Info_ss_Status_present 0x40
#       define      OMAP3_ModificationRequestFor_CF_Info_forwardedToNumber_present 0x20
#       define      OMAP3_ModificationRequestFor_CF_Info_forwardedToSubaddress_present 0x10
#       define      OMAP3_ModificationRequestFor_CF_Info_noReplyConditionTime_present 0x08
#       define      OMAP3_ModificationRequestFor_CF_Info_modifyNotificationToCSE_present 0x04
#       define      OMAP3_ModificationRequestFor_CF_Info_extensionContainer_present 0x02
    OMAP3_SS_Code   ss_Code;
    OMAP3_Ext_BasicServiceCode basicService;  /* optional; set in bit_mask
                 * OMAP3_ModificationRequestFor_CF_Info_basicService_present if
                 * present */
    OMAP3_Ext_SS_Status ss_Status;  /* optional; set in bit_mask
                    * OMAP3_ModificationRequestFor_CF_Info_ss_Status_present if
                    * present */
    OMAP3_AddressString forwardedToNumber;  /* optional; set in bit_mask
            * OMAP3_ModificationRequestFor_CF_Info_forwardedToNumber_present if
            * present */
    OMAP3_ISDN_SubaddressString forwardedToSubaddress;  /* optional; set in
                                   * bit_mask
        * OMAP3_ModificationRequestFor_CF_Info_forwardedToSubaddress_present if
        * present */
    OMAP3_Ext_NoRepCondTime noReplyConditionTime;  /* optional; set in bit_mask
         * OMAP3_ModificationRequestFor_CF_Info_noReplyConditionTime_present if
         * present */
    OMAP3_ModificationInstruction modifyNotificationToCSE;  /* optional; set in
                                   * bit_mask
      * OMAP3_ModificationRequestFor_CF_Info_modifyNotificationToCSE_present if
      * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
           * OMAP3_ModificationRequestFor_CF_Info_extensionContainer_present if
           * present */
} OMAP3_ModificationRequestFor_CF_Info;

typedef struct OMAP3_ModificationRequestFor_CB_Info {
    unsigned char   bit_mask;
#       define      OMAP3_ModificationRequestFor_CB_Info_basicService_present 0x80
#       define      OMAP3_ModificationRequestFor_CB_Info_ss_Status_present 0x40
#       define      OMAP3_ModificationRequestFor_CB_Info_password_present 0x20
#       define      OMAP3_ModificationRequestFor_CB_Info_wrongPasswordAttemptsCounter_present 0x10
#       define      OMAP3_ModificationRequestFor_CB_Info_modifyNotificationToCSE_present 0x08
#       define      OMAP3_ModificationRequestFor_CB_Info_extensionContainer_present 0x04
    OMAP3_SS_Code   ss_Code;
    OMAP3_Ext_BasicServiceCode basicService;  /* optional; set in bit_mask
                 * OMAP3_ModificationRequestFor_CB_Info_basicService_present if
                 * present */
    OMAP3_Ext_SS_Status ss_Status;  /* optional; set in bit_mask
                    * OMAP3_ModificationRequestFor_CB_Info_ss_Status_present if
                    * present */
    OMAP3_Password  password;  /* optional; set in bit_mask
                     * OMAP3_ModificationRequestFor_CB_Info_password_present if
                     * present */
    OMAP3_WrongPasswordAttemptsCounter wrongPasswordAttemptsCounter;  
                                  /* optional; set in bit_mask
 * OMAP3_ModificationRequestFor_CB_Info_wrongPasswordAttemptsCounter_present if
 * present */
    OMAP3_ModificationInstruction modifyNotificationToCSE;  /* optional; set in
                                   * bit_mask
      * OMAP3_ModificationRequestFor_CB_Info_modifyNotificationToCSE_present if
      * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
           * OMAP3_ModificationRequestFor_CB_Info_extensionContainer_present if
           * present */
} OMAP3_ModificationRequestFor_CB_Info;

typedef struct OMAP3_ModificationRequestFor_CSI {
    unsigned char   bit_mask;
#       define      OMAP3_ModificationRequestFor_CSI_modifyNotificationToCSE_present 0x80
#       define      OMAP3_modifyCSI_State_present 0x40
#       define      OMAP3_ModificationRequestFor_CSI_extensionContainer_present 0x20
#       define      OMAP3_ModificationRequestFor_CSI_additionalRequestedCAMEL_SubscriptionInfo_present 0x10
    OMAP3_RequestedCAMEL_SubscriptionInfo requestedCamel_SubscriptionInfo;
    OMAP3_ModificationInstruction modifyNotificationToCSE;  /* optional; set in
                                   * bit_mask
          * OMAP3_ModificationRequestFor_CSI_modifyNotificationToCSE_present if
          * present */
    OMAP3_ModificationInstruction modifyCSI_State;  /* optional; set in bit_mask
                                             * OMAP3_modifyCSI_State_present if
                                             * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
               * OMAP3_ModificationRequestFor_CSI_extensionContainer_present if
               * present */
    OMAP3_AdditionalRequestedCAMEL_SubscriptionInfo additionalRequestedCAMEL_SubscriptionInfo;                          /* extension #1; optional; set in
                                   * bit_mask
          * OMAP3_ModificationRequestFor_CSI_additionalRequestedCAMEL_SubscriptionInfo_present if
          * present */
} OMAP3_ModificationRequestFor_CSI;

typedef struct OMAP3_ModificationRequestFor_ODB_data {
    unsigned char   bit_mask;
#       define      OMAP3_odb_data_present 0x80
#       define      OMAP3_ModificationRequestFor_ODB_data_modifyNotificationToCSE_present 0x40
#       define      OMAP3_ModificationRequestFor_ODB_data_extensionContainer_present 0x20
    OMAP3_ODB_Data  odb_data;  /* optional; set in bit_mask
                                * OMAP3_odb_data_present if present */
    OMAP3_ModificationInstruction modifyNotificationToCSE;  /* optional; set in
                                   * bit_mask
     * OMAP3_ModificationRequestFor_ODB_data_modifyNotificationToCSE_present if
     * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
          * OMAP3_ModificationRequestFor_ODB_data_extensionContainer_present if
          * present */
} OMAP3_ModificationRequestFor_ODB_data;

typedef struct OMAP3__octet9 {
    unsigned short  length;
    unsigned char   value[255];
} OMAP3__octet9;

// requestedCamel-SubscriptionInfo shall be discarded if
// additionalRequestedCAMEL-SubscriptionInfo is received
typedef struct OMAP3_ModificationRequestFor_IP_SM_GW_Data {
    unsigned char   bit_mask;
#       define      OMAP3_modifyRegistrationStatus_present 0x80
#       define      OMAP3_ModificationRequestFor_IP_SM_GW_Data_extensionContainer_present 0x40
#       define      OMAP3_ip_sm_gw_DiameterAddress_present 0x20
    OMAP3_ModificationInstruction modifyRegistrationStatus;  /* optional; set in
                                   * bit_mask
                                   * OMAP3_modifyRegistrationStatus_present if
                                   * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
     * OMAP3_ModificationRequestFor_IP_SM_GW_Data_extensionContainer_present if
     * present */
   // ip-sm-gw-DiameterAddress may be present when ModificationInstruction is "activate"
   // ip-sm-gw-DiameterAddress   [2]   NetworkNodeDiameterAddress    OPTIONAL
    struct OMAP3__seq11 {
        OMAP3__octet9   diameter_Name;
        OMAP3__octet9   diameter_Realm;
    } ip_sm_gw_DiameterAddress;  /* extension #1; optional; set in bit_mask
                                  * OMAP3_ip_sm_gw_DiameterAddress_present if
                                  * present */
} OMAP3_ModificationRequestFor_IP_SM_GW_Data;

typedef struct OMAP3_AnyTimeModificationArg {
    unsigned char   bit_mask;
#       define      OMAP3_modificationRequestFor_CF_Info_present 0x80
#       define      OMAP3_modificationRequestFor_CB_Info_present 0x40
#       define      OMAP3_modificationRequestFor_CSI_present 0x20
#       define      OMAP3_AnyTimeModificationArg_extensionContainer_present 0x10
#       define      OMAP3_AnyTimeModificationArg_longFTN_Supported_present 0x08
#       define      OMAP3_modificationRequestFor_ODB_data_present 0x04
#       define      OMAP3_modificationRequestFor_IP_SM_GW_Data_present 0x02
    OMAP3_SubscriberIdentity subscriberIdentity;
    OMAP3_ISDN_AddressString gsmSCF_Address;
    OMAP3_ModificationRequestFor_CF_Info modificationRequestFor_CF_Info;  
                                        /* optional; set in bit_mask
                              * OMAP3_modificationRequestFor_CF_Info_present if
                              * present */
    OMAP3_ModificationRequestFor_CB_Info modificationRequestFor_CB_Info;  
                                        /* optional; set in bit_mask
                              * OMAP3_modificationRequestFor_CB_Info_present if
                              * present */
    OMAP3_ModificationRequestFor_CSI modificationRequestFor_CSI;  /* optional;
                                   * set in bit_mask
                                   * OMAP3_modificationRequestFor_CSI_present if
                                   * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                   * OMAP3_AnyTimeModificationArg_extensionContainer_present if
                   * present */
    Nulltype        longFTN_Supported;  /* optional; set in bit_mask
                    * OMAP3_AnyTimeModificationArg_longFTN_Supported_present if
                    * present */
    OMAP3_ModificationRequestFor_ODB_data modificationRequestFor_ODB_data;  
                                        /* extension #1; optional; set in
                                   * bit_mask
                             * OMAP3_modificationRequestFor_ODB_data_present if
                             * present */
    OMAP3_ModificationRequestFor_IP_SM_GW_Data modificationRequestFor_IP_SM_GW_Data;                                    /* extension #2; optional; set in
                                   * bit_mask
                        * OMAP3_modificationRequestFor_IP_SM_GW_Data_present if
                        * present */
} OMAP3_AnyTimeModificationArg;

typedef struct OMAP3_Ext_ForwardingInfoFor_CSE {
    unsigned char   bit_mask;
#       define      OMAP3_Ext_ForwardingInfoFor_CSE_notificationToCSE_present 0x80
#       define      OMAP3_Ext_ForwardingInfoFor_CSE_extensionContainer_present 0x40
    OMAP3_SS_Code   ss_Code;
    OMAP3_Ext_ForwFeatureList forwardingFeatureList;
    Nulltype        notificationToCSE;  /* optional; set in bit_mask
                 * OMAP3_Ext_ForwardingInfoFor_CSE_notificationToCSE_present if
                 * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                * OMAP3_Ext_ForwardingInfoFor_CSE_extensionContainer_present if
                * present */
} OMAP3_Ext_ForwardingInfoFor_CSE;

typedef struct OMAP3_Ext_CallBarringInfoFor_CSE {
    unsigned char   bit_mask;
#       define      OMAP3_Ext_CallBarringInfoFor_CSE_password_present 0x80
#       define      OMAP3_Ext_CallBarringInfoFor_CSE_wrongPasswordAttemptsCounter_present 0x40
#       define      OMAP3_Ext_CallBarringInfoFor_CSE_notificationToCSE_present 0x20
#       define      OMAP3_Ext_CallBarringInfoFor_CSE_extensionContainer_present 0x10
    OMAP3_SS_Code   ss_Code;
    OMAP3_Ext_CallBarFeatureList callBarringFeatureList;
    OMAP3_Password  password;  /* optional; set in bit_mask
                         * OMAP3_Ext_CallBarringInfoFor_CSE_password_present if
                         * present */
    OMAP3_WrongPasswordAttemptsCounter wrongPasswordAttemptsCounter;  
                                  /* optional; set in bit_mask
     * OMAP3_Ext_CallBarringInfoFor_CSE_wrongPasswordAttemptsCounter_present if
     * present */
    Nulltype        notificationToCSE;  /* optional; set in bit_mask
                * OMAP3_Ext_CallBarringInfoFor_CSE_notificationToCSE_present if
                * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
               * OMAP3_Ext_CallBarringInfoFor_CSE_extensionContainer_present if
               * present */
} OMAP3_Ext_CallBarringInfoFor_CSE;

typedef struct OMAP3_Ext_SS_InfoFor_CSE {
    unsigned short  choice;
#       define      OMAP3_forwardingInfoFor_CSE_chosen 1
#       define      OMAP3_callBarringInfoFor_CSE_chosen 2
    union _union {
        OMAP3_Ext_ForwardingInfoFor_CSE forwardingInfoFor_CSE;  /* to choose,
                                   * set choice to
                                   * OMAP3_forwardingInfoFor_CSE_chosen */
        OMAP3_Ext_CallBarringInfoFor_CSE callBarringInfoFor_CSE;  /* to choose,
                                   * set choice to
                                   * OMAP3_callBarringInfoFor_CSE_chosen */
    } u;
} OMAP3_Ext_SS_InfoFor_CSE;

        //activationRequestForUE-reachability [9]   RequestedServingNode OPTIONAL }
typedef struct OMAP3_AnyTimeModificationRes {
    unsigned char   bit_mask;
#       define      OMAP3_ss_InfoFor_CSE_present 0x80
#       define      OMAP3_AnyTimeModificationRes_camel_SubscriptionInfo_present 0x40
#       define      OMAP3_AnyTimeModificationRes_extensionContainer_present 0x20
#       define      OMAP3_AnyTimeModificationRes_odb_Info_present 0x10
    OMAP3_Ext_SS_InfoFor_CSE ss_InfoFor_CSE;  /* optional; set in bit_mask
                                               * OMAP3_ss_InfoFor_CSE_present if
                                               * present */
    OMAP3_CAMEL_SubscriptionInfo camel_SubscriptionInfo;  /* optional; set in
                                   * bit_mask
               * OMAP3_AnyTimeModificationRes_camel_SubscriptionInfo_present if
               * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                   * OMAP3_AnyTimeModificationRes_extensionContainer_present if
                   * present */
    OMAP3_ODB_Info  odb_Info;  /* extension #1; optional; set in bit_mask
                                * OMAP3_AnyTimeModificationRes_odb_Info_present
                                * if present */
} OMAP3_AnyTimeModificationRes;

// subscriber data modification notification types
typedef struct OMAP3_NoteSubscriberDataModifiedArg {
    unsigned char   bit_mask;
#       define      OMAP3_forwardingInfoFor_CSE_present 0x80
#       define      OMAP3_callBarringInfoFor_CSE_present 0x40
#       define      OMAP3_NoteSubscriberDataModifiedArg_odb_Info_present 0x20
#       define      OMAP3_NoteSubscriberDataModifiedArg_camel_SubscriptionInfo_present 0x10
#       define      OMAP3_NoteSubscriberDataModifiedArg_allInformationSent_present 0x08
#       define      OMAP3_NoteSubscriberDataModifiedArg_extensionContainer_present 0x04
    OMAP3_IMSI      imsi;
    OMAP3_ISDN_AddressString msisdn;
    OMAP3_Ext_ForwardingInfoFor_CSE forwardingInfoFor_CSE;  /* optional; set in
                                   * bit_mask
                                   * OMAP3_forwardingInfoFor_CSE_present if
                                   * present */
    OMAP3_Ext_CallBarringInfoFor_CSE callBarringInfoFor_CSE;  /* optional; set
                                   * in bit_mask
                                   * OMAP3_callBarringInfoFor_CSE_present if
                                   * present */
    OMAP3_ODB_Info  odb_Info;  /* optional; set in bit_mask
                      * OMAP3_NoteSubscriberDataModifiedArg_odb_Info_present if
                      * present */
    OMAP3_CAMEL_SubscriptionInfo camel_SubscriptionInfo;  /* optional; set in
                                   * bit_mask
        * OMAP3_NoteSubscriberDataModifiedArg_camel_SubscriptionInfo_present if
        * present */
    Nulltype        allInformationSent;  /* optional; set in bit_mask
            * OMAP3_NoteSubscriberDataModifiedArg_allInformationSent_present if
            * present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
            * OMAP3_NoteSubscriberDataModifiedArg_extensionContainer_present if
            * present */
} OMAP3_NoteSubscriberDataModifiedArg;

typedef struct OMAP3_NoteSubscriberDataModifiedRes {
    unsigned char   bit_mask;
#       define      OMAP3_NoteSubscriberDataModifiedRes_extensionContainer_present 0x80
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
            * OMAP3_NoteSubscriberDataModifiedRes_extensionContainer_present if
            * present */
} OMAP3_NoteSubscriberDataModifiedRes;

// mobility management event notificatioon info types
typedef struct OMAP3_NoteMM_EventArg {
    unsigned char   bit_mask;
#       define      OMAP3_NoteMM_EventArg_locationInformation_present 0x80
#       define      OMAP3_supportedCAMELPhases_present 0x40
#       define      OMAP3_NoteMM_EventArg_extensionContainer_present 0x20
#       define      OMAP3_NoteMM_EventArg_locationInformationGPRS_present 0x10
#       define      OMAP3_offeredCamel4Functionalities_present 0x08
    OMAP3_ServiceKey serviceKey;
    OMAP3_MM_Code   eventMet;
    OMAP3_IMSI      imsi;
    OMAP3_ISDN_AddressString msisdn;
    OMAP3_LocationInformation locationInformation;  /* optional; set in bit_mask
                         * OMAP3_NoteMM_EventArg_locationInformation_present if
                         * present */
    OMAP3_SupportedCamelPhases supportedCAMELPhases;  /* optional; set in
                                   * bit_mask OMAP3_supportedCAMELPhases_present
                                   * if present */
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                          * OMAP3_NoteMM_EventArg_extensionContainer_present if
                          * present */
    OMAP3_LocationInformationGPRS locationInformationGPRS;  /* extension #1;
                                   * optional; set in bit_mask
                     * OMAP3_NoteMM_EventArg_locationInformationGPRS_present if
                     * present */
    OMAP3_OfferedCamel4Functionalities offeredCamel4Functionalities;  
                                  /* extension #2; optional; set in bit_mask
                                   * OMAP3_offeredCamel4Functionalities_present
                                   * if present */
} OMAP3_NoteMM_EventArg;

typedef struct OMAP3_NoteMM_EventRes {
    unsigned char   bit_mask;
#       define      OMAP3_NoteMM_EventRes_extensionContainer_present 0x80
    OMAP3_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                          * OMAP3_NoteMM_EventRes_extensionContainer_present if
                          * present */
} OMAP3_NoteMM_EventRes;

typedef struct OMAP3_OPERATION {
    unsigned char   bit_mask;
#       define      OMAP3_ArgumentType_present 0x80
#       define      OMAP3_ResultType_present 0x40
#       define      OMAP3_resultReturned_present 0x20
    unsigned short  ArgumentType;  /* optional; set in bit_mask
                                    * OMAP3_ArgumentType_present if present */
    unsigned short  ResultType;  /* optional; set in bit_mask
                                  * OMAP3_ResultType_present if present */
    ObjectSetEntry  *Errors;  /* NULL for not present */
    ObjectSetEntry  *Linked;  /* NULL for not present */
    ossBoolean      resultReturned;  /* OMAP3_resultReturned_present not set in
                                      * bit_mask implies value is TRUE */
    int             operationCode;
} OMAP3_OPERATION;

typedef struct OMAP3_ERROR {
    unsigned char   bit_mask;
#       define      OMAP3_ParameterType_present 0x80
    unsigned short  ParameterType;  /* optional; set in bit_mask
                                     * OMAP3_ParameterType_present if present */
    int             errorCode;
} OMAP3_ERROR;

#ifndef _OSSNOVALUES

extern OMAP3_OPERATION OMAP3_secureTransportClass1;                  //Timer shall be the same as for the

extern OMAP3_OPERATION OMAP3_secureTransportClass2;                  //Timer shall be the same as for the

extern OMAP3_OPERATION OMAP3_secureTransportClass3;                  //Timer shall be the same as for the

extern OMAP3_OPERATION OMAP3_secureTransportClass4;                  //Timer shall be the same as for the

extern const int OMAP3_maxNameStringLength;

extern const int OMAP3_maxRequestorIDStringLength;

extern const int OMAP3_maxLCSCodewordStringLength;

extern const int OMAP3_maxNumOfAreas;

	// Refers to geographical Information defined in 3GPP TS 23.032.
	// This is composed of 1 or more octets with an internal structure according to
	// 3GPP TS 23.032
	// Octet 1: Type of shape, only the following shapes in 3GPP TS 23.032 are allowed:
	//		(a) Ellipsoid point with uncertainty circle
	//		(b) Ellipsoid point with uncertainty ellipse
	//		(c) Ellipsoid point with altitude and uncertainty ellipsoid
	//		(d) Ellipsoid Arc
	//		(e) Ellipsoid Point
	// Any other value in octet 1 shall be treated as invalid
	// Octets 2 to 8 for case (a) . Ellipsoid point with uncertainty circle
	//		Degrees of Latitude				3 octets
	//		Degrees of Longitude				3 octets
	//		Uncertainty code				1 octet
	// Octets 2 to 11 for case (b) . Ellipsoid point with uncertainty ellipse:
	//		Degrees of Latitude				3 octets
	//		Degrees of Longitude				3 octets
	//		Uncertainty semi-major axis				1 octet
	//		Uncertainty semi-minor axis				1 octet
	//		Angle of major axis				1 octet
	//		Confidence				1 octet
	// Octets 2 to 14 for case (c) . Ellipsoid point with altitude and uncertainty ellipsoid
	//		Degrees of Latitude				3 octets
	//		Degrees of Longitude				3 octets
	//		Altitude				2 octets
	//		Uncertainty semi-major axis				1 octet
	//		Uncertainty semi-minor axis				1 octet
	//		Angle of major axis				1 octet
	//		Uncertainty altitude				1 octet
	//		Confidence				1 octet
	// Octets 2 to 13 for case (d) . Ellipsoid Arc
	//		Degrees of Latitude				3 octets
	//		Degrees of Longitude				3 octets
	//		Inner radius				2 octets
	//		Uncertainty radius				1 octet
	//		Offset angle				1 octet
	//		Included angle				1 octet
	//		Confidence				1 octet
	// Octets 2 to 7 for case (e) . Ellipsoid Point
	//		Degrees of Latitude				3 octets
	//		Degrees of Longitude				3 octets

	//
	// An Ext-GeographicalInformation parameter comprising more than one octet and
	// containing any other shape or an incorrect number of octets or coding according
	// to 3GPP TS 23.032 shall be treated as invalid data by a receiver.
	//
	// An Ext-GeographicalInformation parameter comprising one octet shall be discarded
	// by the receiver if an Add-GeographicalInformation parameter is received 
	// in the same message.
	//
	// An Ext-GeographicalInformation parameter comprising one octet shall be treated as
	// invalid data by the receiver if an Add-GeographicalInformation parameter is not
	// received in the same message.
extern const int OMAP3_maxExt_GeographicalInformation;

	// Refers to the Positioning Data defined in 3GPP TS 49.031.
	// This is composed of 2 or more octets with an internal structure according to
	// 3GPP TS 49.031. 
extern const int OMAP3_maxPositioningDataInformation;

	// Refers to the Position Data defined in 3GPP TS 25.413.
	// This is composed of the positioningDataDiscriminator and the positioningDataSet
	// included in positionData as defined in 3GPP TS 25.413.
extern const int OMAP3_maxUtranPositioningDataInfo;

	// Refers to geographical Information defined in 3GPP TS 23.032.
	// This is composed of 1 or more octets with an internal structure according to 
	// 3GPP TS 23.032
	// Octet 1: Type of shape, all the shapes defined in 3GPP TS 23.032 are allowed:
	// Octets 2 to n (where n is the total number of octets necessary to encode the shape
	// according to 3GPP TS 23.032) are used to encode the shape itself in accordance with the
	// encoding defined in 3GPP TS 23.032
	//
	// An Add-GeographicalInformation parameter, whether valid or invalid, received 
	// together with a valid Ext-GeographicalInformation parameter in the same message 
	// shall be discarded.
	//
	// An Add-GeographicalInformation parameter containing any shape not defined in 
	// 3GPP TS 23.032 or an incorrect number of octets or coding according to 
	// 3GPP TS 23.032 shall be treated as invalid data by a receiver if not received 
	// together with a valid Ext-GeographicalInformation parameter in the same message.
extern const int OMAP3_maxAdd_GeographicalInformation;

extern OMAP3_OPERATION OMAP3_sendRoutingInfoForLCS;                          //Timer m

extern OMAP3_OPERATION OMAP3_provideSubscriberLocation;                              //Timer ml

extern OMAP3_OPERATION OMAP3_subscriberLocationReport;                               //Timer m

	// This type is used to represent a number for addressing
	// purposes. It is composed of
	//	a)	one octet for nature of address, and numbering plan
	//		indicator.
	//	b)	digits of an address encoded as TBCD-String.

	// a)	The first octet includes a one bit extension indicator, a
	//		3 bits nature of address indicator and a 4 bits numbering
	//		plan indicator, encoded as follows:

	// bit 8: 1  (no extension)

	// bits 765: nature of address indicator
	//	000  unknown
	//	001  international number
	//	010  national significant number
	//	011  network specific number
	//	100  subscriber number
	//	101  reserved
	//	110  abbreviated number
	//	111  reserved for extension

	// bits 4321: numbering plan indicator
	//	0000  unknown
	//	0001  ISDN/Telephony Numbering Plan (Rec ITU-T E.164)
	//	0010  spare
	//	0011  data numbering plan (ITU-T Rec X.121)
	//	0100  telex numbering plan (ITU-T Rec F.69)
	//	0101  spare
	//	0110  land mobile numbering plan (ITU-T Rec E.212)
	//	0111  spare
	//	1000  national numbering plan
	//	1001  private numbering plan
	//	1111  reserved for extension

	//	all other values are reserved.

	// b)	The following octets representing digits of an address
	//		encoded as a TBCD-STRING.
extern const int OMAP3_maxAddressLength;

	// This type is used to represent ISDN numbers.
// Modified by Nilendra
extern const int OMAP3_maxISDN_AddressLength;

	// This type is used to represent forwarded-to numbers. 
	// For long forwarded-to numbers (longer than 15 digits) NPI shall be unknown;
	// if NAI = international the first digits represent the country code (CC)
	// and the network destination code (NDC) as for E.164.
extern const int OMAP3_maxFTN_AddressLength;

	// This type is used to represent ISDN subaddresses.
	// It is composed of
	//	a)	one octet for type of subaddress and odd/even indicator.
	//	b)	20 octets for subaddress information.

	//	a)	The first octet includes a one bit extension indicator, a
	//		3 bits type of subaddress and a one bit odd/even indicator,
	//		encoded as follows:

	//	bit 8: 1  (no extension)

	//	bits 765: type of subaddress
	//		000  NSAP (X.213/ISO 8348 AD2)
	//		010  User Specified
	//		All other values are reserved

	//	bit 4: odd/even indicator
	//		0  even number of address signals
	//		1  odd number of address signals
	//		The odd/even indicator is used when the type of subaddress
	//		is "user specified" and the coding is BCD.

	//	bits 321: 000 (unused)

	//	b) Subaddress information.
	//	The NSAP X.213/ISO8348AD2 address shall be formatted as specified
	//	by octet 4 which contains the Authority and Format Identifier
	//	(AFI). The encoding is made according to the "preferred binary
	//	encoding" as defined in X.213/ISO834AD2. For the definition
	//	of this type of subaddress, see ITU-T Rec I.334.

	//	For User-specific subaddress, this field is encoded according
	//	to the user specification, subject to a maximum length of 20
	//	octets. When interworking with X.25 networks BCD coding should
	//	be applied.
extern const int OMAP3_maxISDN_SubaddressLength;

extern const int OMAP3_maxSignalInfoLength;

extern const int OMAP3_maxLongSignalInfoLength;

	// This type is used to represent Alerting Pattern

	//	bits 8765 : 0000 (unused)

	//	bits 43 : type of Pattern
	//		00 level
	//		01 category
	//		10 category
	//		all other values are reserved.

	//	bits 21 : type of alerting
extern OMAP3_AlertingPattern OMAP3_alertingLevel_0;

extern OMAP3_AlertingPattern OMAP3_alertingLevel_1;

extern OMAP3_AlertingPattern OMAP3_alertingLevel_2;

	// all other values of Alerting level are reserved
	// Alerting Levels are defined in GSM 02.07
extern OMAP3_AlertingPattern OMAP3_alertingCategory_1;

extern OMAP3_AlertingPattern OMAP3_alertingCategory_2;

extern OMAP3_AlertingPattern OMAP3_alertingCategory_3;

extern OMAP3_AlertingPattern OMAP3_alertingCategory_4;

extern OMAP3_AlertingPattern OMAP3_alertingCategory_5;

extern const int OMAP3_maxNumOfHLR_Id;

	// the integer values 0-63 are reserved for Standard LCS service types
	// the integer values 64-127 are reserved for Non Standard LCS service types

// Standard LCS Service Types
extern const OMAP3_LCSServiceTypeID OMAP3_emergencyServices;

extern const OMAP3_LCSServiceTypeID OMAP3_emergencyAlertServices;

extern const OMAP3_LCSServiceTypeID OMAP3_personTracking;

extern const OMAP3_LCSServiceTypeID OMAP3_fleetManagement;

extern const OMAP3_LCSServiceTypeID OMAP3_assetManagement;

extern const OMAP3_LCSServiceTypeID OMAP3_trafficCongestionReporting;

extern const OMAP3_LCSServiceTypeID OMAP3_roadsideAssistance;

extern const OMAP3_LCSServiceTypeID OMAP3_routingToNearestCommercialEnterprise;

extern const OMAP3_LCSServiceTypeID OMAP3_navigation;

	//this service type is reserved for use in previous releases
extern const OMAP3_LCSServiceTypeID OMAP3_citySightseeing;

extern const OMAP3_LCSServiceTypeID OMAP3_localizedAdvertising;

extern const OMAP3_LCSServiceTypeID OMAP3_mobileYellowPages;

extern const OMAP3_LCSServiceTypeID OMAP3_trafficAndPublicTransportationInfo;

extern const OMAP3_LCSServiceTypeID OMAP3_weather;

extern const OMAP3_LCSServiceTypeID OMAP3_assetAndServiceFinding;

extern const OMAP3_LCSServiceTypeID OMAP3_gaming;

extern const OMAP3_LCSServiceTypeID OMAP3_findYourFriend;

extern const OMAP3_LCSServiceTypeID OMAP3_dating;

extern const OMAP3_LCSServiceTypeID OMAP3_chatting;

extern const OMAP3_LCSServiceTypeID OMAP3_routeFinding;

extern const OMAP3_LCSServiceTypeID OMAP3_whereAmI;

// The values of LCSServiceTypeID are defined according to 3GPP TS 22.071.

// Non Standard LCS Service Types
extern const OMAP3_LCSServiceTypeID OMAP3_serv64;

extern const OMAP3_LCSServiceTypeID OMAP3_serv65;

extern const OMAP3_LCSServiceTypeID OMAP3_serv66;

extern const OMAP3_LCSServiceTypeID OMAP3_serv67;

extern const OMAP3_LCSServiceTypeID OMAP3_serv68;

extern const OMAP3_LCSServiceTypeID OMAP3_serv69;

extern const OMAP3_LCSServiceTypeID OMAP3_serv70;

extern const OMAP3_LCSServiceTypeID OMAP3_serv71;

extern const OMAP3_LCSServiceTypeID OMAP3_serv72;

extern const OMAP3_LCSServiceTypeID OMAP3_serv73;

extern const OMAP3_LCSServiceTypeID OMAP3_serv74;

extern const OMAP3_LCSServiceTypeID OMAP3_serv75;

extern const OMAP3_LCSServiceTypeID OMAP3_serv76;

extern const OMAP3_LCSServiceTypeID OMAP3_serv77;

extern const OMAP3_LCSServiceTypeID OMAP3_serv78;

extern const OMAP3_LCSServiceTypeID OMAP3_serv79;

extern const OMAP3_LCSServiceTypeID OMAP3_serv80;

extern const OMAP3_LCSServiceTypeID OMAP3_serv81;

extern const OMAP3_LCSServiceTypeID OMAP3_serv82;

extern const OMAP3_LCSServiceTypeID OMAP3_serv83;

extern const OMAP3_LCSServiceTypeID OMAP3_serv84;

extern const OMAP3_LCSServiceTypeID OMAP3_serv85;

extern const OMAP3_LCSServiceTypeID OMAP3_serv86;

extern const OMAP3_LCSServiceTypeID OMAP3_serv87;

extern const OMAP3_LCSServiceTypeID OMAP3_serv88;

extern const OMAP3_LCSServiceTypeID OMAP3_serv89;

extern const OMAP3_LCSServiceTypeID OMAP3_serv90;

extern const OMAP3_LCSServiceTypeID OMAP3_serv91;

extern const OMAP3_LCSServiceTypeID OMAP3_serv92;

extern const OMAP3_LCSServiceTypeID OMAP3_serv93;

extern const OMAP3_LCSServiceTypeID OMAP3_serv94;

extern const OMAP3_LCSServiceTypeID OMAP3_serv95;

extern const OMAP3_LCSServiceTypeID OMAP3_serv96;

extern const OMAP3_LCSServiceTypeID OMAP3_serv97;

extern const OMAP3_LCSServiceTypeID OMAP3_serv98;

extern const OMAP3_LCSServiceTypeID OMAP3_serv99;

extern const OMAP3_LCSServiceTypeID OMAP3_serv100;

extern const OMAP3_LCSServiceTypeID OMAP3_serv101;

extern const OMAP3_LCSServiceTypeID OMAP3_serv102;

extern const OMAP3_LCSServiceTypeID OMAP3_serv103;

extern const OMAP3_LCSServiceTypeID OMAP3_serv104;

extern const OMAP3_LCSServiceTypeID OMAP3_serv105;

extern const OMAP3_LCSServiceTypeID OMAP3_serv106;

extern const OMAP3_LCSServiceTypeID OMAP3_serv107;

extern const OMAP3_LCSServiceTypeID OMAP3_serv108;

extern const OMAP3_LCSServiceTypeID OMAP3_serv109;

extern const OMAP3_LCSServiceTypeID OMAP3_serv110;

extern const OMAP3_LCSServiceTypeID OMAP3_serv111;

extern const OMAP3_LCSServiceTypeID OMAP3_serv112;

extern const OMAP3_LCSServiceTypeID OMAP3_serv113;

extern const OMAP3_LCSServiceTypeID OMAP3_serv114;

extern const OMAP3_LCSServiceTypeID OMAP3_serv115;

extern const OMAP3_LCSServiceTypeID OMAP3_serv116;

extern const OMAP3_LCSServiceTypeID OMAP3_serv117;

extern const OMAP3_LCSServiceTypeID OMAP3_serv118;

extern const OMAP3_LCSServiceTypeID OMAP3_serv119;

extern const OMAP3_LCSServiceTypeID OMAP3_serv120;

extern const OMAP3_LCSServiceTypeID OMAP3_serv121;

extern const OMAP3_LCSServiceTypeID OMAP3_serv122;

extern const OMAP3_LCSServiceTypeID OMAP3_serv123;

extern const OMAP3_LCSServiceTypeID OMAP3_serv124;

extern const OMAP3_LCSServiceTypeID OMAP3_serv125;

extern const OMAP3_LCSServiceTypeID OMAP3_serv126;

extern const OMAP3_LCSServiceTypeID OMAP3_serv127;

	// The mapping from the values A,B,0,1,2,3,4 to the integer-value is
	// specified as follows where A is the highest and 4 is the lowest
	// priority level
	// the integer values 7-15 are spare and shall be mapped to value 4
extern const OMAP3_EMLPP_Priority OMAP3_priorityLevelA;

extern const OMAP3_EMLPP_Priority OMAP3_priorityLevelB;

extern const OMAP3_EMLPP_Priority OMAP3_priorityLevel0;

extern const OMAP3_EMLPP_Priority OMAP3_priorityLevel1;

extern const OMAP3_EMLPP_Priority OMAP3_priorityLevel2;

extern const OMAP3_EMLPP_Priority OMAP3_priorityLevel3;

extern const OMAP3_EMLPP_Priority OMAP3_priorityLevel4;

extern const int OMAP3_maxNumOfMC_Bearers;

	// This type is used to represent the code identifying a single
	// bearer service, a group of bearer services, or all bearer
	// services. The services are defined in TS 3GPP TS 22.002 [3].
	// The internal structure is defined as follows:
	//
	// OCTET 1:
	// plmn-specific bearer services:
	// bits 87654321: defined by the HPLMN operator
	//
	// rest of bearer services:
	// bit 8: 0 (unused)
	// bits 7654321: group (bits 7654), and rate, if applicable
	// (bits 321)

	// OCTETS 2-5: reserved for future use. If received the
    // Ext-TeleserviceCode shall be
	// treated according to the exception handling defined for the
	// operation that uses this type. 

	// Ext-BearerServiceCode includes all values defined for BearerServiceCode.
extern OMAP3_BearerServiceCode OMAP3_allBearerServices;

extern OMAP3_BearerServiceCode OMAP3_allDataCDA_Services;

extern OMAP3_BearerServiceCode OMAP3_dataCDA_300bps;

extern OMAP3_BearerServiceCode OMAP3_dataCDA_1200bps;

extern OMAP3_BearerServiceCode OMAP3_dataCDA_1200_75bps;

extern OMAP3_BearerServiceCode OMAP3_dataCDA_2400bps;

extern OMAP3_BearerServiceCode OMAP3_dataCDA_4800bps;

extern OMAP3_BearerServiceCode OMAP3_dataCDA_9600bps;

extern OMAP3_BearerServiceCode OMAP3_general_dataCDA;

extern OMAP3_BearerServiceCode OMAP3_allDataCDS_Services;

extern OMAP3_BearerServiceCode OMAP3_dataCDS_1200bps;

extern OMAP3_BearerServiceCode OMAP3_dataCDS_2400bps;

extern OMAP3_BearerServiceCode OMAP3_dataCDS_4800bps;

extern OMAP3_BearerServiceCode OMAP3_dataCDS_9600bps;

extern OMAP3_BearerServiceCode OMAP3_general_dataCDS;

extern OMAP3_BearerServiceCode OMAP3_allPadAccessCA_Services;

extern OMAP3_BearerServiceCode OMAP3_padAccessCA_300bps;

extern OMAP3_BearerServiceCode OMAP3_padAccessCA_1200bps;

extern OMAP3_BearerServiceCode OMAP3_padAccessCA_1200_75bps;

extern OMAP3_BearerServiceCode OMAP3_padAccessCA_2400bps;

extern OMAP3_BearerServiceCode OMAP3_padAccessCA_4800bps;

extern OMAP3_BearerServiceCode OMAP3_padAccessCA_9600bps;

extern OMAP3_BearerServiceCode OMAP3_general_padAccessCA;

extern OMAP3_BearerServiceCode OMAP3_allDataPDS_Services;

extern OMAP3_BearerServiceCode OMAP3_dataPDS_2400bps;

extern OMAP3_BearerServiceCode OMAP3_dataPDS_4800bps;

extern OMAP3_BearerServiceCode OMAP3_dataPDS_9600bps;

extern OMAP3_BearerServiceCode OMAP3_general_dataPDS;

extern OMAP3_BearerServiceCode OMAP3_allAlternateSpeech_DataCDA;

extern OMAP3_BearerServiceCode OMAP3_allAlternateSpeech_DataCDS;

extern OMAP3_BearerServiceCode OMAP3_allSpeechFollowedByDataCDA;

extern OMAP3_BearerServiceCode OMAP3_allSpeechFollowedByDataCDS;

// The following non-hierarchical Compound Bearer Service
// Groups are defined in TS 3GPP TS 22.030:
extern OMAP3_BearerServiceCode OMAP3_allDataCircuitAsynchronous;

	// covers "allDataCDA-Services", "allAlternateSpeech-DataCDA" and
	// "allSpeechFollowedByDataCDA"
extern OMAP3_BearerServiceCode OMAP3_allAsynchronousServices;

	// covers "allDataCDA-Services", "allAlternateSpeech-DataCDA",
	// "allSpeechFollowedByDataCDA" and "allPadAccessCDA-Services"
extern OMAP3_BearerServiceCode OMAP3_allDataCircuitSynchronous;

	// covers "allDataCDS-Services", "allAlternateSpeech-DataCDS" and
	// "allSpeechFollowedByDataCDS"
extern OMAP3_BearerServiceCode OMAP3_allSynchronousServices;

	// covers "allDataCDS-Services", "allAlternateSpeech-DataCDS",
	// "allSpeechFollowedByDataCDS" and "allDataPDS-Services"
//
// Compound Bearer Service Group Codes are only used in call
// independent supplementary service operations, i.e. they
// are not used in InsertSubscriberData or in
// DeleteSubscriberData messages.
extern OMAP3_BearerServiceCode OMAP3_allPLMN_specificBS;

extern OMAP3_BearerServiceCode OMAP3_plmn_specificBS_1;

extern OMAP3_BearerServiceCode OMAP3_plmn_specificBS_2;

extern OMAP3_BearerServiceCode OMAP3_plmn_specificBS_3;

extern OMAP3_BearerServiceCode OMAP3_plmn_specificBS_4;

extern OMAP3_BearerServiceCode OMAP3_plmn_specificBS_5;

extern OMAP3_BearerServiceCode OMAP3_plmn_specificBS_6;

extern OMAP3_BearerServiceCode OMAP3_plmn_specificBS_7;

extern OMAP3_BearerServiceCode OMAP3_plmn_specificBS_8;

extern OMAP3_BearerServiceCode OMAP3_plmn_specificBS_9;

extern OMAP3_BearerServiceCode OMAP3_plmn_specificBS_A;

extern OMAP3_BearerServiceCode OMAP3_plmn_specificBS_B;

extern OMAP3_BearerServiceCode OMAP3_plmn_specificBS_C;

extern OMAP3_BearerServiceCode OMAP3_plmn_specificBS_D;

extern OMAP3_BearerServiceCode OMAP3_plmn_specificBS_E;

extern OMAP3_BearerServiceCode OMAP3_plmn_specificBS_F;

extern const int OMAP3_maxNumOfPrivateExtensions;

extern OMAP3_ERROR OMAP3_systemFailure;

extern OMAP3_ERROR OMAP3_dataMissing;

extern OMAP3_ERROR OMAP3_unexpectedDataValue;

extern OMAP3_ERROR OMAP3_facilityNotSupported;

extern OMAP3_ERROR OMAP3_incompatibleTerminal;

extern OMAP3_ERROR OMAP3_resourceLimitation;

// identification and numbering errors
extern OMAP3_ERROR OMAP3_unknownSubscriber;

extern OMAP3_ERROR OMAP3_numberChanged;

extern OMAP3_ERROR OMAP3_unknownMSC;

extern OMAP3_ERROR OMAP3_unidentifiedSubscriber;

extern OMAP3_ERROR OMAP3_unknownEquipment;

// subscription errors
extern OMAP3_ERROR OMAP3_roamingNotAllowed;

extern OMAP3_ERROR OMAP3_illegalSubscriber;

extern OMAP3_ERROR OMAP3_illegalEquipment;

extern OMAP3_ERROR OMAP3_bearerServiceNotProvisioned;

extern OMAP3_ERROR OMAP3_teleserviceNotProvisioned;

// handover errors
extern OMAP3_ERROR OMAP3_noHandoverNumberAvailable;

extern OMAP3_ERROR OMAP3_subsequentHandoverFailure;

extern OMAP3_ERROR OMAP3_targetCellOutsideGroupCallArea;

// operation and maintenance errors
extern OMAP3_ERROR OMAP3_tracingBufferFull;

// call handling errors
extern OMAP3_ERROR OMAP3_noRoamingNumberAvailable;

extern OMAP3_ERROR OMAP3_absentSubscriber;

extern OMAP3_ERROR OMAP3_busySubscriber;

extern OMAP3_ERROR OMAP3_noSubscriberReply;

extern OMAP3_ERROR OMAP3_callBarred;

extern OMAP3_ERROR OMAP3_forwardingViolation;

extern OMAP3_ERROR OMAP3_forwardingFailed;

extern OMAP3_ERROR OMAP3_cug_Reject;

extern OMAP3_ERROR OMAP3_or_NotAllowed;

// any time interrogation errors
extern OMAP3_ERROR OMAP3_ati_NotAllowed;

// any time information handling errors
extern OMAP3_ERROR OMAP3_atsi_NotAllowed;

extern OMAP3_ERROR OMAP3_atm_NotAllowed;

extern OMAP3_ERROR OMAP3_informationNotAvailable;

// supplementary service errors
extern OMAP3_ERROR OMAP3_illegalSS_Operation;

extern OMAP3_ERROR OMAP3_ss_ErrorStatus;

extern OMAP3_ERROR OMAP3_ss_NotAvailable;

extern OMAP3_ERROR OMAP3_ss_SubscriptionViolation;

extern OMAP3_ERROR OMAP3_ss_Incompatibility;

extern OMAP3_ERROR OMAP3_unknownAlphabet;

extern OMAP3_ERROR OMAP3_ussd_Busy;

extern OMAP3_ERROR OMAP3_pw_RegistrationFailure;

extern OMAP3_ERROR OMAP3_negativePW_Check;

extern OMAP3_ERROR OMAP3_numberOfPW_AttemptsViolation;

extern OMAP3_ERROR OMAP3_shortTermDenial;

extern OMAP3_ERROR OMAP3_longTermDenial;

// short message service errors
extern OMAP3_ERROR OMAP3_subscriberBusyForMT_SMS;

extern OMAP3_ERROR OMAP3_sm_DeliveryFailure;

extern OMAP3_ERROR OMAP3_messageWaitingListFull;

extern OMAP3_ERROR OMAP3_absentSubscriberSM;

// Group Call errors
extern OMAP3_ERROR OMAP3_noGroupCallNumberAvailable;

// location service errors
extern OMAP3_ERROR OMAP3_unauthorizedRequestingNetwork;

extern OMAP3_ERROR OMAP3_unauthorizedLCSClient;

extern OMAP3_ERROR OMAP3_positionMethodFailure;

extern OMAP3_ERROR OMAP3_unknownOrUnreachableLCSClient;

extern OMAP3_ERROR OMAP3_mm_EventNotSupported;

// Secure transport errors
extern OMAP3_ERROR OMAP3_secureTransportError;

extern OMAP3_OPERATION OMAP3_sendRoutingInfo;                                //Timer m

extern OMAP3_OPERATION OMAP3_provideRoamingNumber;                           //Timer m

extern OMAP3_OPERATION OMAP3_resumeCallHandling;                             //Timer m

extern OMAP3_OPERATION OMAP3_setReportingState;                              //Timer m

extern OMAP3_OPERATION OMAP3_statusReport;                           //Timer m

extern OMAP3_OPERATION OMAP3_remoteUserFree;                         //Timer ml

extern OMAP3_OPERATION OMAP3_ist_Alert;                              //Timer m

extern OMAP3_OPERATION OMAP3_ist_Command;                             //Timer m

extern OMAP3_OPERATION OMAP3_releaseResources;                                //Timer m

	// location registration operations
	// gprs location registration operations
	// subscriber information enquiry operations
	// any time information enquiry operations
	// any time information handling operations
	// subscriber data modification notification operations
	// handover operations
	// authentication management operations
	// IMEI management operations
	// subscriber management operations
	// fault recovery operations
// gprs location information retrieval operations
	// failure reporting operations
	// gprs notification operations
// Mobility Management operations
// location registration operations
extern OMAP3_OPERATION OMAP3_updateLocation;                         //Timer m

extern OMAP3_OPERATION OMAP3_cancelLocation;                         //Timer m

extern OMAP3_OPERATION OMAP3_purgeMS;                                //Timer m

extern OMAP3_OPERATION OMAP3_sendIdentification;                             //Timer s

// gprs location registration operations
extern OMAP3_OPERATION OMAP3_updateGprsLocation;                             //Timer m

// subscriber information enquiry operations
extern OMAP3_OPERATION OMAP3_provideSubscriberInfo;                          //Timer m

// any time information enquiry operations
extern OMAP3_OPERATION OMAP3_anyTimeInterrogation;                           //Timer m

// any time information handling operations
extern OMAP3_OPERATION OMAP3_anyTimeSubscriptionInterrogation;                       //Timer m

extern OMAP3_OPERATION OMAP3_anyTimeModification;                            //Timer m

// subscriber data modification notification operations
extern OMAP3_OPERATION OMAP3_noteSubscriberDataModified;                             //Timer m

// handover operations
extern OMAP3_OPERATION OMAP3_prepareHandover;                                //Timer m

extern OMAP3_OPERATION OMAP3_sendEndSignal;                          //Timer l

extern OMAP3_OPERATION OMAP3_processAccessSignalling;                                //Timer s

extern OMAP3_OPERATION OMAP3_forwardAccessSignalling;                                //Timer s

extern OMAP3_OPERATION OMAP3_prepareSubsequentHandover;                              //Timer m

// authentication management operations
extern OMAP3_OPERATION OMAP3_sendAuthenticationInfo;                         //Timer m

extern OMAP3_OPERATION OMAP3_authenticationFailureReport;                    //Timer m

// IMEI management operations
extern OMAP3_OPERATION OMAP3_checkIMEI;                              //Timer m

// subscriber management operations
extern OMAP3_OPERATION OMAP3_insertSubscriberData;                           //Timer m

extern OMAP3_OPERATION OMAP3_deleteSubscriberData;                           //Timer m

// fault recovery operations
extern OMAP3_OPERATION OMAP3_reset;                          //Timer m

extern OMAP3_OPERATION OMAP3_forwardCheckSS_Indication;                      //Timer s

extern OMAP3_OPERATION OMAP3_restoreData;                            //Timer m

// gprs location information retrieval operations
extern OMAP3_OPERATION OMAP3_sendRoutingInfoForGprs;                         //Timer m

// failure reporting operations
extern OMAP3_OPERATION OMAP3_failureReport;                          //Timer m

// gprs notification operations
extern OMAP3_OPERATION OMAP3_noteMsPresentForGprs;                           //Timer m

extern OMAP3_OPERATION OMAP3_noteMM_Event;                           //Timer m

extern const int OMAP3_maxNumOfCCBS_Requests;

	// The structure of the contents of the USSD-String is dependent
	// on the USSD-DataCodingScheme as described in TS 3GPP TS 23.038 [25].
extern const int OMAP3_maxUSSD_StringLength;

extern const int OMAP3_maxNumOfSS;

extern const int OMAP3_maxNumOfBasicServiceGroups;

extern const int OMAP3_maxEventSpecification;

	// This type is used to represent the code identifying a single
	// supplementary service, a group of supplementary services, or
	// all supplementary services. The services and abbreviations
	// used are defined in TS 3GPP TS 22.004 [5]. The internal structure is
	// defined as follows:
	//
	// bits 87654321: group (bits 8765), and specific service
	// (bits 4321)
extern OMAP3_SS_Code OMAP3_allSS;

	// reserved for possible future use
	// all SS
extern OMAP3_SS_Code OMAP3_allLineIdentificationSS;

	// reserved for possible future use
	// all line identification SS
extern OMAP3_SS_Code OMAP3_clip;

	// calling line identification presentation
extern OMAP3_SS_Code OMAP3_clir;

	// calling line identification restriction
extern OMAP3_SS_Code OMAP3_colp;

	// connected line identification presentation
extern OMAP3_SS_Code OMAP3_colr;

	// connected line identification restriction
extern OMAP3_SS_Code OMAP3_mci;

	// reserved for possible future use
	// malicious call identification
extern OMAP3_SS_Code OMAP3_allNameIdentificationSS;

	// all name identification SS
extern OMAP3_SS_Code OMAP3_cnap;

	// calling name presentation

	// SS-Codes '00011010'B to '00011111'B are reserved for future 
	// NameIdentification Supplementary Service use.
extern OMAP3_SS_Code OMAP3_allForwardingSS;

	// all forwarding SS
extern OMAP3_SS_Code OMAP3_cfu;

	// call forwarding unconditional
extern OMAP3_SS_Code OMAP3_allCondForwardingSS;

	// all conditional forwarding SS
extern OMAP3_SS_Code OMAP3_cfb;

	// call forwarding on mobile subscriber busy
extern OMAP3_SS_Code OMAP3_cfnry;

	// call forwarding on no reply
extern OMAP3_SS_Code OMAP3_cfnrc;

	// call forwarding on mobile subscriber not reachable 
extern OMAP3_SS_Code OMAP3_cd;

	// call deflection
extern OMAP3_SS_Code OMAP3_allCallOfferingSS;

	// reserved for possible future use
	// all call offering SS includes also all forwarding SS
extern OMAP3_SS_Code OMAP3_ect;

		// explicit call transfer
extern OMAP3_SS_Code OMAP3_mah;

	// reserved for possible future use
	// mobile access hunting
extern OMAP3_SS_Code OMAP3_allCallCompletionSS;

	// reserved for possible future use
	// all Call completion SS
extern OMAP3_SS_Code OMAP3_cw;

	// call waiting
extern OMAP3_SS_Code OMAP3_hold;

	// call hold
extern OMAP3_SS_Code OMAP3_ccbs_A;

	// completion of call to busy subscribers, originating side
extern OMAP3_SS_Code OMAP3_ccbs_B;

	// completion of call to busy subscribers, destination side
	// this SS-Code is used only in InsertSubscriberData and DeleteSubscriberData
extern OMAP3_SS_Code OMAP3_mc;

	// multicall
extern OMAP3_SS_Code OMAP3_allMultiPartySS;

	// reserved for possible future use
	// all multiparty SS
extern OMAP3_SS_Code OMAP3_multiPTY;

	// multiparty
extern OMAP3_SS_Code OMAP3_allCommunityOfInterest_SS;

	// reserved for possible future use
	// all community of interest SS
extern OMAP3_SS_Code OMAP3_cug;

	// closed user group
extern OMAP3_SS_Code OMAP3_allChargingSS;

	// reserved for possible future use
	// all charging SS
extern OMAP3_SS_Code OMAP3_aoci;

	// advice of charge information
extern OMAP3_SS_Code OMAP3_aocc;

	// advice of charge charging
extern OMAP3_SS_Code OMAP3_allAdditionalInfoTransferSS;

	// reserved for possible future use
	// all additional information transfer SS
extern OMAP3_SS_Code OMAP3_uus1;

	// UUS1 user-to-user signalling 
extern OMAP3_SS_Code OMAP3_uus2;

	// UUS2 user-to-user signalling
extern OMAP3_SS_Code OMAP3_uus3;

	// UUS3 user-to-user signalling
extern OMAP3_SS_Code OMAP3_allBarringSS;

	// all barring SS
extern OMAP3_SS_Code OMAP3_barringOfOutgoingCalls;

	// barring of outgoing calls
extern OMAP3_SS_Code OMAP3_baoc;

	// barring of all outgoing calls
extern OMAP3_SS_Code OMAP3_boic;

	// barring of outgoing international calls
extern OMAP3_SS_Code OMAP3_boicExHC;

	// barring of outgoing international calls except those directed
	// to the home PLMN Country
extern OMAP3_SS_Code OMAP3_barringOfIncomingCalls;

	// barring of incoming calls
extern OMAP3_SS_Code OMAP3_baic;

	// barring of all incoming calls
extern OMAP3_SS_Code OMAP3_bicRoam;

	// barring of incoming calls when roaming outside home PLMN
	// Country
extern OMAP3_SS_Code OMAP3_allPLMN_specificSS;

extern OMAP3_SS_Code OMAP3_plmn_specificSS_1;

extern OMAP3_SS_Code OMAP3_plmn_specificSS_2;

extern OMAP3_SS_Code OMAP3_plmn_specificSS_3;

extern OMAP3_SS_Code OMAP3_plmn_specificSS_4;

extern OMAP3_SS_Code OMAP3_plmn_specificSS_5;

extern OMAP3_SS_Code OMAP3_plmn_specificSS_6;

extern OMAP3_SS_Code OMAP3_plmn_specificSS_7;

extern OMAP3_SS_Code OMAP3_plmn_specificSS_8;

extern OMAP3_SS_Code OMAP3_plmn_specificSS_9;

extern OMAP3_SS_Code OMAP3_plmn_specificSS_A;

extern OMAP3_SS_Code OMAP3_plmn_specificSS_B;

extern OMAP3_SS_Code OMAP3_plmn_specificSS_C;

extern OMAP3_SS_Code OMAP3_plmn_specificSS_D;

extern OMAP3_SS_Code OMAP3_plmn_specificSS_E;

extern OMAP3_SS_Code OMAP3_plmn_specificSS_F;

extern OMAP3_SS_Code OMAP3_allCallPrioritySS;

	// reserved for possible future use
	// all call priority SS
extern OMAP3_SS_Code OMAP3_emlpp;

	// enhanced Multilevel Precedence Pre-emption (EMLPP) service
extern OMAP3_SS_Code OMAP3_allLCSPrivacyException;

	// all LCS Privacy Exception Classes
extern OMAP3_SS_Code OMAP3_universal;

	// allow location by any LCS client
extern OMAP3_SS_Code OMAP3_callSessionRelated;

	// allow location by any value added LCS client to which a call/session 
	// is established from the target MS
extern OMAP3_SS_Code OMAP3_callSessionUnrelated;

	// allow location by designated external value added LCS clients
extern OMAP3_SS_Code OMAP3_plmnoperator;

	// allow location by designated PLMN operator LCS clients 
extern OMAP3_SS_Code OMAP3_serviceType;

	// allow location by LCS clients of a designated LCS service type
extern OMAP3_SS_Code OMAP3_allMOLR_SS;

	// all Mobile Originating Location Request Classes
extern OMAP3_SS_Code OMAP3_basicSelfLocation;

	// allow an MS to request its own location
extern OMAP3_SS_Code OMAP3_autonomousSelfLocation;

	// allow an MS to perform self location without interaction
	// with the PLMN for a predetermined period of time
extern OMAP3_SS_Code OMAP3_transferToThirdParty;
	// allow an MS to request transfer of its location to another LCS client

// supplementary service handling operations
extern OMAP3_OPERATION OMAP3_registerSS;                             //Timer m

extern OMAP3_OPERATION OMAP3_eraseSS;                                //Timer m

extern OMAP3_OPERATION OMAP3_activateSS;

extern OMAP3_OPERATION OMAP3_deactivateSS;                           //Timer m

extern OMAP3_OPERATION OMAP3_interrogateSS;                          //Timer m

extern OMAP3_OPERATION OMAP3_processUnstructuredSS_Request;                          //Timer 10 minutes

extern OMAP3_OPERATION OMAP3_unstructuredSS_Request;                         //Timer ml

extern OMAP3_OPERATION OMAP3_unstructuredSS_Notify;                          //Timer ml

extern OMAP3_OPERATION OMAP3_registerPassword;                               //Timer ml

extern OMAP3_OPERATION OMAP3_getPassword;                            //Timer m

extern OMAP3_OPERATION OMAP3_ss_InvocationNotification;                              //Timer m

extern OMAP3_OPERATION OMAP3_registerCC_Entry;                               //Timer m

extern OMAP3_OPERATION OMAP3_eraseCC_Entry;                          //Timer m

extern const int OMAP3_maxNumOfDispatchers;

extern OMAP3_OPERATION OMAP3_sendRoutingInfoForSM;                           //Timer m

extern OMAP3_OPERATION OMAP3_mo_ForwardSM;                           //Timer ml

extern OMAP3_OPERATION OMAP3_mt_ForwardSM;                           //Timer ml

extern OMAP3_OPERATION OMAP3_reportSM_DeliveryStatus;                        //Timer s

extern OMAP3_OPERATION OMAP3_alertServiceCentre;                             //Timer s

extern OMAP3_OPERATION OMAP3_informServiceCentre;                            //Timer s

extern OMAP3_OPERATION OMAP3_readyForSM;                             //Timer m

extern OMAP3_OPERATION OMAP3_mt_ForwardSM_VGCS;                              //Timer ml

extern OMAP3_OPERATION OMAP3_activateTraceMode;                              //Timer m

extern OMAP3_OPERATION OMAP3_deactivateTraceMode;                            //Timer m

extern OMAP3_OPERATION OMAP3_sendIMSI;                               //Timer m

	// Octets contain a complete TracePropagationParameters data type 
	// as defined in 3GPP TS 25.413, encoded according to the encoding scheme 
	// mandated by 3GPP TS 25.413. 
	// Padding bits are included, if needed, in the least significant bits of the 
	// last octet of the octet string. 
extern const int OMAP3_maxTracePropagationParametersLength;

	// This type is used to represent the code identifying a single
	// teleservice, a group of teleservices, or all teleservices. The
	// services are defined in TS GSM 22.003 [4].
	// The internal structure is defined as follows:

	// OCTET 1:
	// bits 87654321: group (bits 8765) and specific service
	// (bits 4321)

	// OCTETS 2-5: reserved for future use. If received the
    // Ext-TeleserviceCode shall be
 	// treated according to the exception handling defined for the
	// operation that uses this type.

	// Ext-TeleserviceCode includes all values defined for TeleserviceCode.
extern OMAP3_TeleserviceCode OMAP3_allTeleservices;

extern OMAP3_TeleserviceCode OMAP3_allSpeechTransmissionServices;

extern OMAP3_TeleserviceCode OMAP3_telephony;

extern OMAP3_TeleserviceCode OMAP3_emergencyCalls;

extern OMAP3_TeleserviceCode OMAP3_allShortMessageServices;

extern OMAP3_TeleserviceCode OMAP3_shortMessageMT_PP;

extern OMAP3_TeleserviceCode OMAP3_shortMessageMO_PP;

extern OMAP3_TeleserviceCode OMAP3_allFacsimileTransmissionServices;

extern OMAP3_TeleserviceCode OMAP3_facsimileGroup3AndAlterSpeech;

extern OMAP3_TeleserviceCode OMAP3_automaticFacsimileGroup3;

extern OMAP3_TeleserviceCode OMAP3_facsimileGroup4;

// The following non-hierarchical Compound Teleservice Groups
// are defined in TS 3GPP TS 22.030:
extern OMAP3_TeleserviceCode OMAP3_allDataTeleservices;

	// covers Teleservice Groups 'allFacsimileTransmissionServices'
	// and 'allShortMessageServices'
extern OMAP3_TeleserviceCode OMAP3_allTeleservices_ExeptSMS;

	// covers Teleservice Groups 'allSpeechTransmissionServices' and
	// 'allFacsimileTransmissionServices'
//
// Compound Teleservice Group Codes are only used in call
// independent supplementary service operations, i.e. they
// are not used in InsertSubscriberData or in
// DeleteSubscriberData messages.
extern OMAP3_TeleserviceCode OMAP3_allVoiceGroupCallServices;

extern OMAP3_TeleserviceCode OMAP3_voiceGroupCall;

extern OMAP3_TeleserviceCode OMAP3_voiceBroadcastCall;

extern OMAP3_TeleserviceCode OMAP3_allPLMN_specificTS;

extern OMAP3_TeleserviceCode OMAP3_plmn_specificTS_1;

extern OMAP3_TeleserviceCode OMAP3_plmn_specificTS_2;

extern OMAP3_TeleserviceCode OMAP3_plmn_specificTS_3;

extern OMAP3_TeleserviceCode OMAP3_plmn_specificTS_4;

extern OMAP3_TeleserviceCode OMAP3_plmn_specificTS_5;

extern OMAP3_TeleserviceCode OMAP3_plmn_specificTS_6;

extern OMAP3_TeleserviceCode OMAP3_plmn_specificTS_7;

extern OMAP3_TeleserviceCode OMAP3_plmn_specificTS_8;

extern OMAP3_TeleserviceCode OMAP3_plmn_specificTS_9;

extern OMAP3_TeleserviceCode OMAP3_plmn_specificTS_A;

extern OMAP3_TeleserviceCode OMAP3_plmn_specificTS_B;

extern OMAP3_TeleserviceCode OMAP3_plmn_specificTS_C;

extern OMAP3_TeleserviceCode OMAP3_plmn_specificTS_D;

extern OMAP3_TeleserviceCode OMAP3_plmn_specificTS_E;

extern OMAP3_TeleserviceCode OMAP3_plmn_specificTS_F;

extern OMAP3_OPERATION OMAP3_prepareGroupCall;                               //Timer m

extern OMAP3_OPERATION OMAP3_sendGroupCallEndSignal;                         //Timer l

extern OMAP3_OPERATION OMAP3_processGroupCallSignalling;                             //Timer s

extern OMAP3_OPERATION OMAP3_forwardGroupCallSignalling;                             //Timer s

	// Octets contain a complete PermittedIntegrityProtectionAlgorithms data type 
	// as defined in 3GPP TS 25.413, encoded according to the encoding scheme 
	// mandated by 3GPP TS 25.413. 
	// Padding bits are included, if needed, in the least significant bits of the 
	// last octet of the octet string. 
extern const int OMAP3_maxPermittedIntegrityProtectionAlgorithmsLength;

	// Octets contain a complete PermittedEncryptionAlgorithms data type 
	// as defined in 3GPP TS 25.413, encoded according to the encoding scheme 
	// mandated by 3GPP TS 25.413
	// Padding bits are included, if needed, in the least significant bits of the 
	// last octet of the octet string. 
extern const int OMAP3_maxPermittedEncryptionAlgorithmsLength;

extern const int OMAP3_maxNumOfServiceHandovers;

extern const int OMAP3_maxNumOfRadioResources;

extern const int OMAP3_maxNrOfRABs;

extern const int OMAP3_maxNumOfRelocationNumber;

	// Octets contain a complete IntegrityProtectionInformation data type 
	// as defined in 3GPP TS 25.413, encoded according to the encoding scheme 
	// mandated by 3GPP TS 25.413
	// Padding bits are included, if needed, in the least significant bits of the 
	// last octet of the octet string. 
extern const int OMAP3_maxNumOfIntegrityInfo;

	// Octets contain a complete EncryptionInformation data type 
	// as defined in 3GPP TS 25.413, encoded according to the encoding scheme 
	// mandated by 3GPP TS 25.413
	// Padding bits are included, if needed, in the least significant bits of the 
	// last octet of the octet string. 
extern const int OMAP3_maxNumOfEncryptionInfo;

	// if segmentation is used, the complete GMLC-List shall be sent in one segment
extern const int OMAP3_maxNumOfGMLC;

extern const int OMAP3_maxNumOfPDP_Contexts;

extern const int OMAP3_maxNumOfLSAs;

extern const int OMAP3_maxNumOfBearerServices;

extern const int OMAP3_maxNumOfTeleservices;

extern const int OMAP3_maxNumOfCUG;

extern const int OMAP3_maxNumOfExt_BasicServiceGroups;

extern const int OMAP3_maxNumOfPrivacyClass;

extern const int OMAP3_maxNumOfExternalClient;

extern const int OMAP3_maxNumOfPLMNClient;

extern const int OMAP3_maxNumOfExt_ExternalClient;

extern const int OMAP3_maxNumOfServiceType;

extern const int OMAP3_maxNumOfMOLR_Class;

	// internal structure is defined in TS 3GPP TS 23.003 [17]
extern const int OMAP3_maxNumOfZoneCodes;

extern const int OMAP3_maxNumOfBasicServices;

extern const int OMAP3_maxNumOfTPDUTypes;

extern const int OMAP3_maxNumOfDP_AnalysedInfoCriteria;

	// Actions for the following SS-Code values are defined in CAMEL Phase 3:
	// ect		SS-Code ::= '00110001'B
	// multiPTY	SS-Code ::= '01010001'B
	// cd		SS-Code ::= '00100100'B
	// ccbs		SS-Code ::= '01000100'B
	// all other SS codes shall be ignored
	// When SS-CSI is sent to the VLR, it shall not contain a marking for ccbs.
	// If the VLR receives SS-CSI containing a marking for ccbs, the VLR shall discard the
	// ccbs marking in SS-CSI.
extern const int OMAP3_maxNumOfCamelSSEvents;

	// O-BcsmCamelTDPDataList shall not contain more than one instance of
	// O-BcsmCamelTDPData containing the same value for o-BcsmTriggerDetectionPoint.
	// For CAMEL Phase 2, this means that only one instance of O-BcsmCamelTDPData is allowed
	// with o-BcsmTriggerDetectionPoint being equal to DP2.
extern const int OMAP3_maxNumOfCamelTDPData;

extern const int OMAP3_maxNumOfISDN_AddressDigits;

extern const int OMAP3_maxNumOfCamelDestinationNumbers;

extern const int OMAP3_maxNumOfCamelDestinationNumberLengths;

extern const int OMAP3_maxNumOfCamelBasicServiceCriteria;

extern const int OMAP3_maxNumOfCAMEL_O_CauseValueCriteria;

extern const int OMAP3_maxNumOfCAMEL_T_CauseValueCriteria;

extern const int OMAP3_maxNumOfMobilityTriggers;

extern const int OMAP3_maxNumOfVBSGroupIds;

extern const int OMAP3_maxNumOfVGCSGroupIds;

#endif  /* #ifndef _OSSNOVALUES */


extern void *OMAP3;    /* encoder-decoder control table */
#ifdef __cplusplus
}	/* extern "C" */
#endif /* __cplusplus */
#endif /* OSS_OMAP3 */
