#include "MAP3Code.h"
#include "MAP3.h"


OssGlobal gMAP3W, *gMAP3World = &gMAP3W;

//Vble to remember if the OSS was initialized previously.
int g_initialized = 0;

int MAP3_initialize() 
{
	int L_retCode ;
	//Initialise the OSS runtime environment
	L_retCode = ossinit(gMAP3World, MAP3);

	if(L_retCode) 
		return L_retCode;

	g_initialized = 1;
    	return 0;
}

void MAP3_close() 
{
	if(g_initialized)
		//Release the OSS runtime resources
		ossterm(gMAP3World);

	g_initialized = 0;
}


void MAP3_printPDU(int P_msgType,void *P_dataStruct) 
{
	if(!g_initialized)
		MAP3_initialize();

	//Call OSS API to print the PDU
	ossPrintPDU(gMAP3World,P_msgType,P_dataStruct);
}

void MAP3_freePDU(int P_msgType, void* P_data) 
{
	if(!g_initialized)
		MAP3_initialize();

	//Free the decoded PDU allocated from OSS memory pool.
	ossFreePDU(gMAP3World,P_msgType,P_data);
}

void MAP3_freeBuf(unsigned char *P_buff)
{
	if(!g_initialized)
		MAP3_initialize();

	//Free the encoded buffer once you are done with the useage
	//from the OSS memory pool
	ossFreeBuf(gMAP3World,P_buff);
}

int MAP3_encode(void *P_dataStruct,int P_msgType, 
	unsigned char **P_encodedData, int *P_dataLength) 
{
	OssBuf L_ossBuf;
	int L_retCode;

	if(!g_initialized)
		MAP3_initialize();

	L_ossBuf.value = *P_encodedData;
	L_ossBuf.length = *P_dataLength;

	L_retCode = ossEncode(gMAP3World,P_msgType,
				P_dataStruct,&L_ossBuf);
	if(L_retCode != 0) {
		return L_retCode;
	}
	*P_encodedData = L_ossBuf.value;
	*P_dataLength = L_ossBuf.length;
    	return 0; //All fine, no error.
}


int MAP3_decode(unsigned char **P_encodedData,int P_buffLen,int P_msgType,
 void **P_decodedStruct) 
{
	OssBuf L_encodedData;
	int L_retCode;

	if(!g_initialized)
		MAP3_initialize();

	L_encodedData.value = *P_encodedData;
	L_encodedData.length = P_buffLen;

	L_retCode = ossDecode(gMAP3World,&P_msgType,
			&L_encodedData,P_decodedStruct) ;

	if(L_retCode != 0) {
		return L_retCode;
	}

	return 0;
}

long MAP3_setDecodingLength(long P_bufferLength) 
{
	 if(!g_initialized)
                MAP3_initialize();

	return ossSetDecodingLength(gMAP3World,P_bufferLength);
}

long MAP3_getEncodingLength(int P_msgType,void *P_data)
{
	long L_long;

	if(!g_initialized)
                MAP3_initialize();

	L_long =  ossDetermineEncodingLength(gMAP3World,P_msgType,P_data);

	return L_long;
}

char *MAP3_getErrMsg()
{
	char *L_charPtr;

	if(!g_initialized)
                MAP3_initialize();

	L_charPtr =  ossGetErrMsg(gMAP3World);
	return L_charPtr;
}


