/*************************************************************/
/* Copyright (C) 2010 OSS Nokalva, Inc.  All rights reserved.*/
/*************************************************************/

/* THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC.
 * AND MAY BE USED ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC.
 * THIS FILE MAY NOT BE DISTRIBUTED. */

/* Generated for: Lyca Technologies Solutions Pvt. Ltd., Chennai, India - License 60124 for Solaris 64-bit */
/* Abstract syntax: MAP3 */
/* Created: Fri Jun 11 12:00:15 2010 */
/* ASN.1 compiler version: 8.4 */
/* Code generated for runtime version 8.4 or later */
/* Compiler operating system: Solaris 7 with 64-bit support */
/* Compiler machine type: SPARC */
/* Target operating system: Solaris 7 with 64-bit support */
/* Target machine type: SPARC */
/* C compiler options required: -xarch=v9 */
/* ASN.1 compiler options and file names specified:
 * -prefix MAP3_ -c++ -relaxedMode -ber -root -compat v4.2defaults
 * -compat v4.2octetstringdefault -compat paddedfornamedbits
 * ../../asn1dflt.solaris7-64bit MAP-SecureTransportOperations.asn
 * MAP-LCS-DataTypes.asn MAP-LocationServiceOperations.asn
 * MAP-ST-DataTypes.asn MAP-CommonDataTypes.asn MAP-BS-Code.asn
 * MAP-GR-DataTypes.asn MAP-ExtensionDataTypes.asn MAP-Errors.asn
 * MAP-ER-DataTypes.asn MAP-CH-DataTypes.asn MAP-CallHandlingOperations.asn
 * MAP-MobileServiceOperations.asn MAP-SS-DataTypes.asn MAP-SS-Code.asn
 * MAP-SupplementaryServiceOperations.asn MAP-SM-DataTypes.asn
 * MAP-ShortMessageServiceOperations.asn
 * MAP-OperationAndMaintenanceOperations.asn MAP-OM-DataTypes.asn
 * MAP-TS-Code.asn MAP-Group-Call-Operations.asn MAP-MS-DataTypes.asn
 * MAP3.asn
 */

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */
#define    OSS_SOED_BER
#include   "osstype.h"
#include   "MAP3.h"

#ifndef _OSSNOVALUES

const int MAP3_maxNameStringLength = 63;

const int MAP3_maxRequestorIDStringLength = 63;

const int MAP3_maxLCSCodewordStringLength = 20;

const int MAP3_maxNumOfAreas = 10;

const int MAP3_maxExt_GeographicalInformation = 20;

const int MAP3_maxPositioningDataInformation = 10;

const int MAP3_maxUtranPositioningDataInfo = 11;

const int MAP3_maxAdd_GeographicalInformation = 91;

const int MAP3_maxAddressLength = 20;

const int MAP3_maxISDN_AddressLength = 9;

const int MAP3_maxFTN_AddressLength = 15;

const int MAP3_maxISDN_SubaddressLength = 21;

const int MAP3_maxSignalInfoLength = 200;

const int MAP3_maxLongSignalInfoLength = 2560;

MAP3_AlertingPattern MAP3_alertingLevel_0 = {
    1,
    {
        0x00
    }
};

MAP3_AlertingPattern MAP3_alertingLevel_1 = {
    1,
    {
        0x01
    }
};

MAP3_AlertingPattern MAP3_alertingLevel_2 = {
    1,
    {
        0x02
    }
};

MAP3_AlertingPattern MAP3_alertingCategory_1 = {
    1,
    {
        0x04
    }
};

MAP3_AlertingPattern MAP3_alertingCategory_2 = {
    1,
    {
        0x05
    }
};

MAP3_AlertingPattern MAP3_alertingCategory_3 = {
    1,
    {
        0x06
    }
};

MAP3_AlertingPattern MAP3_alertingCategory_4 = {
    1,
    {
        0x07
    }
};

MAP3_AlertingPattern MAP3_alertingCategory_5 = {
    1,
    {
        0x08
    }
};

const int MAP3_maxNumOfHLR_Id = 50;

const MAP3_LCSServiceTypeID MAP3_emergencyServices = 0;

const MAP3_LCSServiceTypeID MAP3_emergencyAlertServices = 1;

const MAP3_LCSServiceTypeID MAP3_personTracking = 2;

const MAP3_LCSServiceTypeID MAP3_fleetManagement = 3;

const MAP3_LCSServiceTypeID MAP3_assetManagement = 4;

const MAP3_LCSServiceTypeID MAP3_trafficCongestionReporting = 5;

const MAP3_LCSServiceTypeID MAP3_roadsideAssistance = 6;

const MAP3_LCSServiceTypeID MAP3_routingToNearestCommercialEnterprise = 7;

const MAP3_LCSServiceTypeID MAP3_navigation = 8;

const MAP3_LCSServiceTypeID MAP3_citySightseeing = 9;

const MAP3_LCSServiceTypeID MAP3_localizedAdvertising = 10;

const MAP3_LCSServiceTypeID MAP3_mobileYellowPages = 11;

const MAP3_LCSServiceTypeID MAP3_trafficAndPublicTransportationInfo = 12;

const MAP3_LCSServiceTypeID MAP3_weather = 13;

const MAP3_LCSServiceTypeID MAP3_assetAndServiceFinding = 14;

const MAP3_LCSServiceTypeID MAP3_gaming = 15;

const MAP3_LCSServiceTypeID MAP3_findYourFriend = 16;

const MAP3_LCSServiceTypeID MAP3_dating = 17;

const MAP3_LCSServiceTypeID MAP3_chatting = 18;

const MAP3_LCSServiceTypeID MAP3_routeFinding = 19;

const MAP3_LCSServiceTypeID MAP3_whereAmI = 20;

const MAP3_LCSServiceTypeID MAP3_serv64 = 64;

const MAP3_LCSServiceTypeID MAP3_serv65 = 65;

const MAP3_LCSServiceTypeID MAP3_serv66 = 66;

const MAP3_LCSServiceTypeID MAP3_serv67 = 67;

const MAP3_LCSServiceTypeID MAP3_serv68 = 68;

const MAP3_LCSServiceTypeID MAP3_serv69 = 69;

const MAP3_LCSServiceTypeID MAP3_serv70 = 70;

const MAP3_LCSServiceTypeID MAP3_serv71 = 71;

const MAP3_LCSServiceTypeID MAP3_serv72 = 72;

const MAP3_LCSServiceTypeID MAP3_serv73 = 73;

const MAP3_LCSServiceTypeID MAP3_serv74 = 74;

const MAP3_LCSServiceTypeID MAP3_serv75 = 75;

const MAP3_LCSServiceTypeID MAP3_serv76 = 76;

const MAP3_LCSServiceTypeID MAP3_serv77 = 77;

const MAP3_LCSServiceTypeID MAP3_serv78 = 78;

const MAP3_LCSServiceTypeID MAP3_serv79 = 79;

const MAP3_LCSServiceTypeID MAP3_serv80 = 80;

const MAP3_LCSServiceTypeID MAP3_serv81 = 81;

const MAP3_LCSServiceTypeID MAP3_serv82 = 82;

const MAP3_LCSServiceTypeID MAP3_serv83 = 83;

const MAP3_LCSServiceTypeID MAP3_serv84 = 84;

const MAP3_LCSServiceTypeID MAP3_serv85 = 85;

const MAP3_LCSServiceTypeID MAP3_serv86 = 86;

const MAP3_LCSServiceTypeID MAP3_serv87 = 87;

const MAP3_LCSServiceTypeID MAP3_serv88 = 88;

const MAP3_LCSServiceTypeID MAP3_serv89 = 89;

const MAP3_LCSServiceTypeID MAP3_serv90 = 90;

const MAP3_LCSServiceTypeID MAP3_serv91 = 91;

const MAP3_LCSServiceTypeID MAP3_serv92 = 92;

const MAP3_LCSServiceTypeID MAP3_serv93 = 93;

const MAP3_LCSServiceTypeID MAP3_serv94 = 94;

const MAP3_LCSServiceTypeID MAP3_serv95 = 95;

const MAP3_LCSServiceTypeID MAP3_serv96 = 96;

const MAP3_LCSServiceTypeID MAP3_serv97 = 97;

const MAP3_LCSServiceTypeID MAP3_serv98 = 98;

const MAP3_LCSServiceTypeID MAP3_serv99 = 99;

const MAP3_LCSServiceTypeID MAP3_serv100 = 100;

const MAP3_LCSServiceTypeID MAP3_serv101 = 101;

const MAP3_LCSServiceTypeID MAP3_serv102 = 102;

const MAP3_LCSServiceTypeID MAP3_serv103 = 103;

const MAP3_LCSServiceTypeID MAP3_serv104 = 104;

const MAP3_LCSServiceTypeID MAP3_serv105 = 105;

const MAP3_LCSServiceTypeID MAP3_serv106 = 106;

const MAP3_LCSServiceTypeID MAP3_serv107 = 107;

const MAP3_LCSServiceTypeID MAP3_serv108 = 108;

const MAP3_LCSServiceTypeID MAP3_serv109 = 109;

const MAP3_LCSServiceTypeID MAP3_serv110 = 110;

const MAP3_LCSServiceTypeID MAP3_serv111 = 111;

const MAP3_LCSServiceTypeID MAP3_serv112 = 112;

const MAP3_LCSServiceTypeID MAP3_serv113 = 113;

const MAP3_LCSServiceTypeID MAP3_serv114 = 114;

const MAP3_LCSServiceTypeID MAP3_serv115 = 115;

const MAP3_LCSServiceTypeID MAP3_serv116 = 116;

const MAP3_LCSServiceTypeID MAP3_serv117 = 117;

const MAP3_LCSServiceTypeID MAP3_serv118 = 118;

const MAP3_LCSServiceTypeID MAP3_serv119 = 119;

const MAP3_LCSServiceTypeID MAP3_serv120 = 120;

const MAP3_LCSServiceTypeID MAP3_serv121 = 121;

const MAP3_LCSServiceTypeID MAP3_serv122 = 122;

const MAP3_LCSServiceTypeID MAP3_serv123 = 123;

const MAP3_LCSServiceTypeID MAP3_serv124 = 124;

const MAP3_LCSServiceTypeID MAP3_serv125 = 125;

const MAP3_LCSServiceTypeID MAP3_serv126 = 126;

const MAP3_LCSServiceTypeID MAP3_serv127 = 127;

const MAP3_EMLPP_Priority MAP3_priorityLevelA = 6;

const MAP3_EMLPP_Priority MAP3_priorityLevelB = 5;

const MAP3_EMLPP_Priority MAP3_priorityLevel0 = 0;

const MAP3_EMLPP_Priority MAP3_priorityLevel1 = 1;

const MAP3_EMLPP_Priority MAP3_priorityLevel2 = 2;

const MAP3_EMLPP_Priority MAP3_priorityLevel3 = 3;

const MAP3_EMLPP_Priority MAP3_priorityLevel4 = 4;

const int MAP3_maxNumOfMC_Bearers = 7;

MAP3_BearerServiceCode MAP3_allBearerServices = {
    1,
    {
        0x00
    }
};

MAP3_BearerServiceCode MAP3_allDataCDA_Services = {
    1,
    {
        0x10
    }
};

MAP3_BearerServiceCode MAP3_dataCDA_300bps = {
    1,
    {
        0x11
    }
};

MAP3_BearerServiceCode MAP3_dataCDA_1200bps = {
    1,
    {
        0x12
    }
};

MAP3_BearerServiceCode MAP3_dataCDA_1200_75bps = {
    1,
    {
        0x13
    }
};

MAP3_BearerServiceCode MAP3_dataCDA_2400bps = {
    1,
    {
        0x14
    }
};

MAP3_BearerServiceCode MAP3_dataCDA_4800bps = {
    1,
    {
        0x15
    }
};

MAP3_BearerServiceCode MAP3_dataCDA_9600bps = {
    1,
    {
        0x16
    }
};

MAP3_BearerServiceCode MAP3_general_dataCDA = {
    1,
    {
        0x17
    }
};

MAP3_BearerServiceCode MAP3_allDataCDS_Services = {
    1,
    {
        0x18
    }
};

MAP3_BearerServiceCode MAP3_dataCDS_1200bps = {
    1,
    {
        0x1A
    }
};

MAP3_BearerServiceCode MAP3_dataCDS_2400bps = {
    1,
    {
        0x1C
    }
};

MAP3_BearerServiceCode MAP3_dataCDS_4800bps = {
    1,
    {
        0x1D
    }
};

MAP3_BearerServiceCode MAP3_dataCDS_9600bps = {
    1,
    {
        0x1E
    }
};

MAP3_BearerServiceCode MAP3_general_dataCDS = {
    1,
    {
        0x1F
    }
};

MAP3_BearerServiceCode MAP3_allPadAccessCA_Services = {
    1,
    {
        0x20
    }
};

MAP3_BearerServiceCode MAP3_padAccessCA_300bps = {
    1,
    {
        0x21
    }
};

MAP3_BearerServiceCode MAP3_padAccessCA_1200bps = {
    1,
    {
        0x22
    }
};

MAP3_BearerServiceCode MAP3_padAccessCA_1200_75bps = {
    1,
    {
        0x23
    }
};

MAP3_BearerServiceCode MAP3_padAccessCA_2400bps = {
    1,
    {
        0x24
    }
};

MAP3_BearerServiceCode MAP3_padAccessCA_4800bps = {
    1,
    {
        0x25
    }
};

MAP3_BearerServiceCode MAP3_padAccessCA_9600bps = {
    1,
    {
        0x26
    }
};

MAP3_BearerServiceCode MAP3_general_padAccessCA = {
    1,
    {
        0x27
    }
};

MAP3_BearerServiceCode MAP3_allDataPDS_Services = {
    1,
    {
        0x28
    }
};

MAP3_BearerServiceCode MAP3_dataPDS_2400bps = {
    1,
    {
        0x2C
    }
};

MAP3_BearerServiceCode MAP3_dataPDS_4800bps = {
    1,
    {
        0x2D
    }
};

MAP3_BearerServiceCode MAP3_dataPDS_9600bps = {
    1,
    {
        0x2E
    }
};

MAP3_BearerServiceCode MAP3_general_dataPDS = {
    1,
    {
        0x2F
    }
};

MAP3_BearerServiceCode MAP3_allAlternateSpeech_DataCDA = {
    1,
    {
        0x30
    }
};

MAP3_BearerServiceCode MAP3_allAlternateSpeech_DataCDS = {
    1,
    {
        0x38
    }
};

MAP3_BearerServiceCode MAP3_allSpeechFollowedByDataCDA = {
    1,
    {
        0x40
    }
};

MAP3_BearerServiceCode MAP3_allSpeechFollowedByDataCDS = {
    1,
    {
        0x48
    }
};

MAP3_BearerServiceCode MAP3_allDataCircuitAsynchronous = {
    1,
    {
        0x50
    }
};

MAP3_BearerServiceCode MAP3_allAsynchronousServices = {
    1,
    {
        0x60
    }
};

MAP3_BearerServiceCode MAP3_allDataCircuitSynchronous = {
    1,
    {
        0x58
    }
};

MAP3_BearerServiceCode MAP3_allSynchronousServices = {
    1,
    {
        0x68
    }
};

MAP3_BearerServiceCode MAP3_allPLMN_specificBS = {
    1,
    {
        0xD0
    }
};

MAP3_BearerServiceCode MAP3_plmn_specificBS_1 = {
    1,
    {
        0xD1
    }
};

MAP3_BearerServiceCode MAP3_plmn_specificBS_2 = {
    1,
    {
        0xD2
    }
};

MAP3_BearerServiceCode MAP3_plmn_specificBS_3 = {
    1,
    {
        0xD3
    }
};

MAP3_BearerServiceCode MAP3_plmn_specificBS_4 = {
    1,
    {
        0xD4
    }
};

MAP3_BearerServiceCode MAP3_plmn_specificBS_5 = {
    1,
    {
        0xD5
    }
};

MAP3_BearerServiceCode MAP3_plmn_specificBS_6 = {
    1,
    {
        0xD6
    }
};

MAP3_BearerServiceCode MAP3_plmn_specificBS_7 = {
    1,
    {
        0xD7
    }
};

MAP3_BearerServiceCode MAP3_plmn_specificBS_8 = {
    1,
    {
        0xD8
    }
};

MAP3_BearerServiceCode MAP3_plmn_specificBS_9 = {
    1,
    {
        0xD9
    }
};

MAP3_BearerServiceCode MAP3_plmn_specificBS_A = {
    1,
    {
        0xDA
    }
};

MAP3_BearerServiceCode MAP3_plmn_specificBS_B = {
    1,
    {
        0xDB
    }
};

MAP3_BearerServiceCode MAP3_plmn_specificBS_C = {
    1,
    {
        0xDC
    }
};

MAP3_BearerServiceCode MAP3_plmn_specificBS_D = {
    1,
    {
        0xDD
    }
};

MAP3_BearerServiceCode MAP3_plmn_specificBS_E = {
    1,
    {
        0xDE
    }
};

MAP3_BearerServiceCode MAP3_plmn_specificBS_F = {
    1,
    {
        0xDF
    }
};

const int MAP3_maxNumOfPrivateExtensions = 10;

const int MAP3_maxNumOfCCBS_Requests = 5;

const int MAP3_maxUSSD_StringLength = 160;

const int MAP3_maxNumOfSS = 30;

const int MAP3_maxNumOfBasicServiceGroups = 13;

const int MAP3_maxEventSpecification = 2;

MAP3_SS_Code MAP3_allSS = {
    1,
    {
        0x00
    }
};

MAP3_SS_Code MAP3_allLineIdentificationSS = {
    1,
    {
        0x10
    }
};

MAP3_SS_Code MAP3_clip = {
    1,
    {
        0x11
    }
};

MAP3_SS_Code MAP3_clir = {
    1,
    {
        0x12
    }
};

MAP3_SS_Code MAP3_colp = {
    1,
    {
        0x13
    }
};

MAP3_SS_Code MAP3_colr = {
    1,
    {
        0x14
    }
};

MAP3_SS_Code MAP3_mci = {
    1,
    {
        0x15
    }
};

MAP3_SS_Code MAP3_allNameIdentificationSS = {
    1,
    {
        0x18
    }
};

MAP3_SS_Code MAP3_cnap = {
    1,
    {
        0x19
    }
};

MAP3_SS_Code MAP3_allForwardingSS = {
    1,
    {
        0x20
    }
};

MAP3_SS_Code MAP3_cfu = {
    1,
    {
        0x21
    }
};

MAP3_SS_Code MAP3_allCondForwardingSS = {
    1,
    {
        0x28
    }
};

MAP3_SS_Code MAP3_cfb = {
    1,
    {
        0x29
    }
};

MAP3_SS_Code MAP3_cfnry = {
    1,
    {
        0x2A
    }
};

MAP3_SS_Code MAP3_cfnrc = {
    1,
    {
        0x2B
    }
};

MAP3_SS_Code MAP3_cd = {
    1,
    {
        0x24
    }
};

MAP3_SS_Code MAP3_allCallOfferingSS = {
    1,
    {
        0x30
    }
};

MAP3_SS_Code MAP3_ect = {
    1,
    {
        0x31
    }
};

MAP3_SS_Code MAP3_mah = {
    1,
    {
        0x32
    }
};

MAP3_SS_Code MAP3_allCallCompletionSS = {
    1,
    {
        0x40
    }
};

MAP3_SS_Code MAP3_cw = {
    1,
    {
        0x41
    }
};

MAP3_SS_Code MAP3_hold = {
    1,
    {
        0x42
    }
};

MAP3_SS_Code MAP3_ccbs_A = {
    1,
    {
        0x43
    }
};

MAP3_SS_Code MAP3_ccbs_B = {
    1,
    {
        0x44
    }
};

MAP3_SS_Code MAP3_mc = {
    1,
    {
        0x45
    }
};

MAP3_SS_Code MAP3_allMultiPartySS = {
    1,
    {
        0x50
    }
};

MAP3_SS_Code MAP3_multiPTY = {
    1,
    {
        0x51
    }
};

MAP3_SS_Code MAP3_allCommunityOfInterest_SS = {
    1,
    {
        0x60
    }
};

MAP3_SS_Code MAP3_cug = {
    1,
    {
        0x61
    }
};

MAP3_SS_Code MAP3_allChargingSS = {
    1,
    {
        0x70
    }
};

MAP3_SS_Code MAP3_aoci = {
    1,
    {
        0x71
    }
};

MAP3_SS_Code MAP3_aocc = {
    1,
    {
        0x72
    }
};

MAP3_SS_Code MAP3_allAdditionalInfoTransferSS = {
    1,
    {
        0x80
    }
};

MAP3_SS_Code MAP3_uus1 = {
    1,
    {
        0x81
    }
};

MAP3_SS_Code MAP3_uus2 = {
    1,
    {
        0x82
    }
};

MAP3_SS_Code MAP3_uus3 = {
    1,
    {
        0x83
    }
};

MAP3_SS_Code MAP3_allBarringSS = {
    1,
    {
        0x90
    }
};

MAP3_SS_Code MAP3_barringOfOutgoingCalls = {
    1,
    {
        0x91
    }
};

MAP3_SS_Code MAP3_baoc = {
    1,
    {
        0x92
    }
};

MAP3_SS_Code MAP3_boic = {
    1,
    {
        0x93
    }
};

MAP3_SS_Code MAP3_boicExHC = {
    1,
    {
        0x94
    }
};

MAP3_SS_Code MAP3_barringOfIncomingCalls = {
    1,
    {
        0x99
    }
};

MAP3_SS_Code MAP3_baic = {
    1,
    {
        0x9A
    }
};

MAP3_SS_Code MAP3_bicRoam = {
    1,
    {
        0x9B
    }
};

MAP3_SS_Code MAP3_allPLMN_specificSS = {
    1,
    {
        0xF0
    }
};

MAP3_SS_Code MAP3_plmn_specificSS_1 = {
    1,
    {
        0xF1
    }
};

MAP3_SS_Code MAP3_plmn_specificSS_2 = {
    1,
    {
        0xF2
    }
};

MAP3_SS_Code MAP3_plmn_specificSS_3 = {
    1,
    {
        0xF3
    }
};

MAP3_SS_Code MAP3_plmn_specificSS_4 = {
    1,
    {
        0xF4
    }
};

MAP3_SS_Code MAP3_plmn_specificSS_5 = {
    1,
    {
        0xF5
    }
};

MAP3_SS_Code MAP3_plmn_specificSS_6 = {
    1,
    {
        0xF6
    }
};

MAP3_SS_Code MAP3_plmn_specificSS_7 = {
    1,
    {
        0xF7
    }
};

MAP3_SS_Code MAP3_plmn_specificSS_8 = {
    1,
    {
        0xF8
    }
};

MAP3_SS_Code MAP3_plmn_specificSS_9 = {
    1,
    {
        0xF9
    }
};

MAP3_SS_Code MAP3_plmn_specificSS_A = {
    1,
    {
        0xFA
    }
};

MAP3_SS_Code MAP3_plmn_specificSS_B = {
    1,
    {
        0xFB
    }
};

MAP3_SS_Code MAP3_plmn_specificSS_C = {
    1,
    {
        0xFC
    }
};

MAP3_SS_Code MAP3_plmn_specificSS_D = {
    1,
    {
        0xFD
    }
};

MAP3_SS_Code MAP3_plmn_specificSS_E = {
    1,
    {
        0xFE
    }
};

MAP3_SS_Code MAP3_plmn_specificSS_F = {
    1,
    {
        0xFF
    }
};

MAP3_SS_Code MAP3_allCallPrioritySS = {
    1,
    {
        0xA0
    }
};

MAP3_SS_Code MAP3_emlpp = {
    1,
    {
        0xA1
    }
};

MAP3_SS_Code MAP3_allLCSPrivacyException = {
    1,
    {
        0xB0
    }
};

MAP3_SS_Code MAP3_universal = {
    1,
    {
        0xB1
    }
};

MAP3_SS_Code MAP3_callSessionRelated = {
    1,
    {
        0xB2
    }
};

MAP3_SS_Code MAP3_callSessionUnrelated = {
    1,
    {
        0xB3
    }
};

MAP3_SS_Code MAP3_plmnoperator = {
    1,
    {
        0xB4
    }
};

MAP3_SS_Code MAP3_serviceType = {
    1,
    {
        0xB5
    }
};

MAP3_SS_Code MAP3_allMOLR_SS = {
    1,
    {
        0xC0
    }
};

MAP3_SS_Code MAP3_basicSelfLocation = {
    1,
    {
        0xC1
    }
};

MAP3_SS_Code MAP3_autonomousSelfLocation = {
    1,
    {
        0xC2
    }
};

MAP3_SS_Code MAP3_transferToThirdParty = {
    1,
    {
        0xC3
    }
};

const int MAP3_maxNumOfDispatchers = 5;

const int MAP3_maxTracePropagationParametersLength = 16;

MAP3_TeleserviceCode MAP3_allTeleservices = {
    1,
    {
        0x00
    }
};

MAP3_TeleserviceCode MAP3_allSpeechTransmissionServices = {
    1,
    {
        0x10
    }
};

MAP3_TeleserviceCode MAP3_telephony = {
    1,
    {
        0x11
    }
};

MAP3_TeleserviceCode MAP3_emergencyCalls = {
    1,
    {
        0x12
    }
};

MAP3_TeleserviceCode MAP3_allShortMessageServices = {
    1,
    {
        0x20
    }
};

MAP3_TeleserviceCode MAP3_shortMessageMT_PP = {
    1,
    {
        0x21
    }
};

MAP3_TeleserviceCode MAP3_shortMessageMO_PP = {
    1,
    {
        0x22
    }
};

MAP3_TeleserviceCode MAP3_allFacsimileTransmissionServices = {
    1,
    {
        0x60
    }
};

MAP3_TeleserviceCode MAP3_facsimileGroup3AndAlterSpeech = {
    1,
    {
        0x61
    }
};

MAP3_TeleserviceCode MAP3_automaticFacsimileGroup3 = {
    1,
    {
        0x62
    }
};

MAP3_TeleserviceCode MAP3_facsimileGroup4 = {
    1,
    {
        0x63
    }
};

MAP3_TeleserviceCode MAP3_allDataTeleservices = {
    1,
    {
        0x70
    }
};

MAP3_TeleserviceCode MAP3_allTeleservices_ExeptSMS = {
    1,
    {
        0x80
    }
};

MAP3_TeleserviceCode MAP3_allVoiceGroupCallServices = {
    1,
    {
        0x90
    }
};

MAP3_TeleserviceCode MAP3_voiceGroupCall = {
    1,
    {
        0x91
    }
};

MAP3_TeleserviceCode MAP3_voiceBroadcastCall = {
    1,
    {
        0x92
    }
};

MAP3_TeleserviceCode MAP3_allPLMN_specificTS = {
    1,
    {
        0xD0
    }
};

MAP3_TeleserviceCode MAP3_plmn_specificTS_1 = {
    1,
    {
        0xD1
    }
};

MAP3_TeleserviceCode MAP3_plmn_specificTS_2 = {
    1,
    {
        0xD2
    }
};

MAP3_TeleserviceCode MAP3_plmn_specificTS_3 = {
    1,
    {
        0xD3
    }
};

MAP3_TeleserviceCode MAP3_plmn_specificTS_4 = {
    1,
    {
        0xD4
    }
};

MAP3_TeleserviceCode MAP3_plmn_specificTS_5 = {
    1,
    {
        0xD5
    }
};

MAP3_TeleserviceCode MAP3_plmn_specificTS_6 = {
    1,
    {
        0xD6
    }
};

MAP3_TeleserviceCode MAP3_plmn_specificTS_7 = {
    1,
    {
        0xD7
    }
};

MAP3_TeleserviceCode MAP3_plmn_specificTS_8 = {
    1,
    {
        0xD8
    }
};

MAP3_TeleserviceCode MAP3_plmn_specificTS_9 = {
    1,
    {
        0xD9
    }
};

MAP3_TeleserviceCode MAP3_plmn_specificTS_A = {
    1,
    {
        0xDA
    }
};

MAP3_TeleserviceCode MAP3_plmn_specificTS_B = {
    1,
    {
        0xDB
    }
};

MAP3_TeleserviceCode MAP3_plmn_specificTS_C = {
    1,
    {
        0xDC
    }
};

MAP3_TeleserviceCode MAP3_plmn_specificTS_D = {
    1,
    {
        0xDD
    }
};

MAP3_TeleserviceCode MAP3_plmn_specificTS_E = {
    1,
    {
        0xDE
    }
};

MAP3_TeleserviceCode MAP3_plmn_specificTS_F = {
    1,
    {
        0xDF
    }
};

const int MAP3_maxPermittedIntegrityProtectionAlgorithmsLength = 9;

const int MAP3_maxPermittedEncryptionAlgorithmsLength = 9;

const int MAP3_maxNumOfServiceHandovers = 7;

const int MAP3_maxNumOfRadioResources = 7;

const int MAP3_maxNrOfRABs = 255;

const int MAP3_maxNumOfRelocationNumber = 7;

const int MAP3_maxNumOfIntegrityInfo = 100;

const int MAP3_maxNumOfEncryptionInfo = 100;

const int MAP3_maxNumOfGMLC = 5;

const int MAP3_maxNumOfPDP_Contexts = 50;

const int MAP3_maxNumOfLSAs = 20;

const int MAP3_maxNumOfBearerServices = 50;

const int MAP3_maxNumOfTeleservices = 20;

const int MAP3_maxNumOfCUG = 10;

const int MAP3_maxNumOfExt_BasicServiceGroups = 32;

const int MAP3_maxNumOfPrivacyClass = 4;

const int MAP3_maxNumOfExternalClient = 5;

const int MAP3_maxNumOfPLMNClient = 5;

const int MAP3_maxNumOfExt_ExternalClient = 35;

const int MAP3_maxNumOfServiceType = 32;

const int MAP3_maxNumOfMOLR_Class = 3;

const int MAP3_maxNumOfZoneCodes = 10;

const int MAP3_maxNumOfBasicServices = 70;

const int MAP3_maxNumOfTPDUTypes = 5;

const int MAP3_maxNumOfDP_AnalysedInfoCriteria = 10;

const int MAP3_maxNumOfCamelSSEvents = 10;

const int MAP3_maxNumOfCamelTDPData = 10;

const int MAP3_maxNumOfISDN_AddressDigits = 15;

const int MAP3_maxNumOfCamelDestinationNumbers = 10;

const int MAP3_maxNumOfCamelDestinationNumberLengths = 3;

const int MAP3_maxNumOfCamelBasicServiceCriteria = 5;

const int MAP3_maxNumOfCAMEL_O_CauseValueCriteria = 5;

const int MAP3_maxNumOfCAMEL_T_CauseValueCriteria = 5;

const int MAP3_maxNumOfMobilityTriggers = 10;

const int MAP3_maxNumOfVBSGroupIds = 50;

const int MAP3_maxNumOfVGCSGroupIds = 50;


#if !defined(OSS_SPARTAN_AWARE) || ((OSS_SPARTAN_AWARE + 0) < 2)
static ObjectSetEntry const MAP3_ExtensionSet[] = {
{0}};

#else /* OSS_SPARTAN_AWARE >= 2 */

#if ((OSS_SPARTAN_AWARE + 0) > 12)
static ObjectSetEntry const MAP3_ExtensionSet[] = {
{0}};
#else /* OSS_SPARTAN_AWARE <= 12 */
static ObjectSetEntry const MAP3_ExtensionSet[] = {
{0}};
#endif /* (OSS_SPARTAN_AWARE + 0) > 12 */

static unsigned short const _oss_OSet_info[] =  {
    4
};
#endif /* !OSS_SPARTAN_AWARE || OSS_SPARTAN_AWARE < 2 */

#endif  /* #ifndef _OSSNOVALUES */

#ifdef OSS_SPARTAN_AWARE
#if ((OSS_SPARTAN_AWARE + 0) >= 3)
extern void _oss_run_SOED_on_SPARC_SOLARIS_7_64BIT(void);
static void _oss_post_init(struct ossGlobal *world);
#endif /* OSS_SPARTAN_AWARE >= 3 */
#endif /* OSS_SPARTAN_AWARE */

#ifdef OSS_SPARTAN_AWARE
#if ((OSS_SPARTAN_AWARE + 0) >= 12)
static unsigned char _privateFlags[] = {0x01,0x00};
#endif /* OSS_SPARTAN_AWARE >= 12 */
#endif /* OSS_SPARTAN_AWARE */

static void _ossinit_MAP3(struct ossGlobal *world) {
#ifdef OSS_SPARTAN_AWARE
#if ((OSS_SPARTAN_AWARE + 0) >= 3)
    _oss_run_SOED_on_SPARC_SOLARIS_7_64BIT();
#endif /* OSS_SPARTAN_AWARE >= 3 */
#endif /* OSS_SPARTAN_AWARE */
#ifdef OSS_SPARTAN_AWARE
#if ((OSS_SPARTAN_AWARE + 0) >= 12)
    ossPrivateSetMoreFlags(world, 12, _privateFlags);
#endif /* OSS_SPARTAN_AWARE >= 12 */
#endif /* OSS_SPARTAN_AWARE */
    ossLinkBer(world);
#ifdef OSS_SPARTAN_AWARE
    ossLinkCmpValue(world);
#if ((OSS_SPARTAN_AWARE + 0) >= 2)
    ossInitObjectSetInfo(world, (unsigned short *)_oss_OSet_info);
#endif /* OSS_SPARTAN_AWARE >= 2 */
#endif /* OSS_SPARTAN_AWARE */

#ifdef OSS_SPARTAN_AWARE
#if ((OSS_SPARTAN_AWARE + 0) >= 3)
    _oss_post_init(world);
#endif /* OSS_SPARTAN_AWARE >= 3 */
#endif /* OSS_SPARTAN_AWARE */
}

static int const _v106[10] = {
  0, 1, 2, 3, 4, 5, 6, 7, 8, 9
};
static int const _v67[6] = {
  1, 2, 3, 4, 5, 6
};
static int const _v133[5] = {
  1, 2, 11, 12, 14
};
static unsigned char const _v117[4] = {
  0x0, 0x0, 0x0, 0x7
};
static int const _v45[4] = {
  5, 6, 7, INT_MAX
};
static int const _v38[4] = {
  0, 1, 5, 7
};
static unsigned char const _v141[3] = {0x0, 0x0, 0xf};
static int const _v65[3] = {4, 5, INT_MAX};
static int const _v56[3] = {13, 14, INT_MAX};
static int const _v4[3] = {3, 4, INT_MAX};
static unsigned char const _v140[2] = {0x0, 0x3};
static int const _v130[2] = {3, INT_MAX};
static int const _v121[2] = {2, INT_MAX};
static int const _v107[2] = {10, INT_MAX};
static unsigned char const _v91[2] = {0x0, 0x3f};
static int const _v60[2] = {4, INT_MAX};
static int const _v36[2] = {0, 3};
static int const _v26[2] = {6, INT_MAX};
static int const _v18[2] = {5, INT_MAX};
static int const _v146[1] = {INT_MAX};
static unsigned char const _v137[1] = {0x3f};
static unsigned char const _v119[1] = {0x1f};
static unsigned char const _v118[1] = {0xf};
static unsigned char const _v101[1] = {0x7f};
static unsigned char const _v97[1] = {0x7};
static unsigned char const _v90[1] = {0x3};
static int const _v55[1] = {12};
static unsigned char const _v51[1] = {0x1};

static const unsigned short _pduarray[] = {
    1, 2, 3, 4, 5, 6, 7, 8, 9, 10,
    11, 12, 13, 14, 15, 16, 17, 18, 19, 20,
    21, 22, 23, 24, 25, 26, 27, 28, 29, 30,
    31, 32, 33, 34, 35, 36, 37, 38, 39, 40,
    41, 42, 43, 44, 45, 46, 47, 48, 49, 50,
    51, 52, 53, 54, 55, 56, 57, 58, 59, 60,
    61, 62, 63, 64, 65, 66, 67, 68, 69, 70,
    71, 72, 73, 74, 75, 76, 77, 78, 79, 80,
    81, 82, 83, 84, 85, 86, 87, 88, 89, 90,
    91, 92, 93, 94, 95, 96, 97, 98, 99, 100,
    101, 102, 103, 104, 105, 106, 107, 108, 109, 110,
    111, 112, 113, 114, 115, 116, 117, 118, 119, 120,
    121, 122, 123, 124, 125, 126, 127, 128, 129, 130,
    131, 132, 133, 134, 135, 136, 137, 138, 139, 140,
    141, 142, 143, 144, 145, 146, 147, 148, 149, 150,
    151, 152, 153, 154, 155, 156, 157, 158, 159, 160,
    0
};

static const struct etype _etypearray[] = {
    {-1, 0, 0, (char *)"_ObjectID", 8, 8, 2, 8, 40, 0, 27, 0},
    {-1, 2, 4, (char *)"RoutingInfoForLCS-Arg", 536, 3, 1, 0, 12, 0, 12, 0},
    {4, 2, 16, (char *)"RoutingInfoForLCS-Res", 1152, 7, 1, 0, 2076, 3, 12, 0},
    {7, 2, 64, (char *)"ProvideSubscriberLocation-Arg", 2136, 18, 2, 0, 2076, 10, 12, 0},
    {8, 2, 376, (char *)"ProvideSubscriberLocation-Res", 688, 11, 2, 0, 2076, 28, 12, 0},
    {11, 2, 510, (char *)"SubscriberLocationReport-Arg", 2656, 22, 4, 0, 2076, 39, 12, 0},
    {2, 2, 940, (char *)"SubscriberLocationReport-Res", 536, 3, 1, 0, 2076, 61, 12, 0},
    {-1, 2, 958, (char *)"SecureTransportArg", 3496, 2, 1, 0, 8, 64, 12, 0},
    {-1, 2, 958, (char *)"SecureTransportRes", 3496, 2, 1, 0, 8, 64, 12, 0},
    {-1, 966, 967, (char *)"SubscriberId", 12, 2, 2, 2, 8, 66, 13, 0},
    {2, 2, 972, (char *)"PrepareGroupCallArg", 592, 11, 1, 0, 2076, 68, 12, 0},
    {-1, 2, 1058, (char *)"PrepareGroupCallRes", 520, 2, 1, 0, 12, 79, 12, 0},
    {2, 2, 1066, (char *)"SendGroupCallEndSignalArg", 544, 4, 1, 0, 2076, 81, 12, 0},
    {-1, 2, 1094, (char *)"SendGroupCallEndSignalRes", 512, 1, 1, 0, 12, 85, 12, 0},
    {5, 2, 1098, (char *)"ForwardGroupCallSignallingArg", 768, 12, 2, 0, 2076, 86, 12, 0},
    {3, 2, 1278, (char *)"ProcessGroupCallSignallingArg", 544, 7, 1, 0, 2076, 98, 12, 0},
    {1, 1348, 0, (char *)"SS-Status", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2, 1350, (char *)"RoamingNotAllowedParam", 512, 2, 1, 0, 12, 105, 12, 0},
    {-1, 966, 1358, (char *)"CallBarredParam", 528, 2, 2, 8, 8, 107, 13, 0},
    {-1, 2, 1363, (char *)"CUG-RejectParam", 512, 2, 1, 0, 12, 109, 12, 0},
    {-1, 2, 1373, (char *)"SS-IncompatibilityCause", 16, 3, 1, 0, 12, 111, 12, 0},
    {2, 1395, 0, (char *)"PW-RegistrationFailureCause", 4, 0, 4, 0, 24, 1, 58, 0},
    {-1, 2, 1397, (char *)"SM-DeliveryFailureCause", 720, 3, 1, 0, 12, 114, 12, 0},
    {1, 2, 1411, (char *)"AbsentSubscriberSM-Param", 520, 3, 1, 0, 2076, 117, 12, 0},
    {-1, 966, 1358, (char *)"SystemFailureParam", 528, 2, 2, 8, 8, 120, 13, 0},
    {-1, 2, 1094, (char *)"DataMissingParam", 512, 1, 1, 0, 12, 122, 12, 0},
    {-1, 2, 1094, (char *)"UnexpectedDataParam", 512, 1, 1, 0, 12, 123, 12, 0},
    {2, 2, 940, (char *)"FacilityNotSupParam", 520, 3, 1, 0, 2076, 124, 12, 0},
    {-1, 2, 1094, (char *)"OR-NotAllowedParam", 512, 1, 1, 0, 12, 127, 12, 0},
    {1, 2, 1429, (char *)"UnknownSubscriberParam", 520, 2, 1, 0, 2076, 128, 12, 0},
    {-1, 2, 1094, (char *)"NumberChangedParam", 512, 1, 1, 0, 12, 130, 12, 0},
    {-1, 2, 1094, (char *)"UnidentifiedSubParam", 512, 1, 1, 0, 12, 131, 12, 0},
    {-1, 2, 1094, (char *)"IllegalSubscriberParam", 512, 1, 1, 0, 12, 132, 12, 0},
    {-1, 2, 1094, (char *)"IllegalEquipmentParam", 512, 1, 1, 0, 12, 133, 12, 0},
    {-1, 2, 1094, (char *)"BearerServNotProvParam", 512, 1, 1, 0, 12, 134, 12, 0},
    {-1, 2, 1094, (char *)"TeleservNotProvParam", 512, 1, 1, 0, 12, 135, 12, 0},
    {-1, 2, 1094, (char *)"TracingBufferFullParam", 512, 1, 1, 0, 12, 136, 12, 0},
    {-1, 2, 1094, (char *)"NoRoamingNbParam", 512, 1, 1, 0, 12, 137, 12, 0},
    {1, 2, 1439, (char *)"AbsentSubscriberParam", 520, 2, 1, 0, 2076, 138, 12, 0},
    {2, 2, 940, (char *)"BusySubscriberParam", 520, 3, 1, 0, 2076, 140, 12, 0},
    {-1, 2, 1094, (char *)"NoSubscriberReplyParam", 512, 1, 1, 0, 12, 143, 12, 0},
    {-1, 2, 1094, (char *)"ForwardingViolationParam", 512, 1, 1, 0, 12, 144, 12, 0},
    {-1, 2, 1094, (char *)"ForwardingFailedParam", 512, 1, 1, 0, 12, 145, 12, 0},
    {-1, 2, 1094, (char *)"ATI-NotAllowedParam", 512, 1, 1, 0, 12, 146, 12, 0},
    {-1, 2, 1094, (char *)"ATSI-NotAllowedParam", 512, 1, 1, 0, 12, 147, 12, 0},
    {-1, 2, 1094, (char *)"ATM-NotAllowedParam", 512, 1, 1, 0, 12, 148, 12, 0},
    {-1, 2, 1094, (char *)"IllegalSS-OperationParam", 512, 1, 1, 0, 12, 149, 12, 0},
    {-1, 2, 1094, (char *)"SS-NotAvailableParam", 512, 1, 1, 0, 12, 150, 12, 0},
    {-1, 2, 1094, (char *)"SS-SubscriptionViolationParam", 512, 1, 1, 0, 12, 151, 12, 0},
    {-1, 2, 1094, (char *)"InformationNotAvailableParam", 512, 1, 1, 0, 12, 152, 12, 0},
    {1, 2, 1449, (char *)"SubBusyForMT-SMS-Param", 520, 2, 1, 0, 2076, 153, 12, 0},
    {-1, 2, 1094, (char *)"MessageWaitListFullParam", 512, 1, 1, 0, 12, 155, 12, 0},
    {-1, 2, 1094, (char *)"ResourceLimitationParam", 512, 1, 1, 0, 12, 156, 12, 0},
    {-1, 2, 1094, (char *)"NoGroupCallNbParam", 512, 1, 1, 0, 12, 157, 12, 0},
    {-1, 2, 1094, (char *)"IncompatibleTerminalParam", 512, 1, 1, 0, 12, 158, 12, 0},
    {-1, 2, 0, (char *)"ShortTermDenialParam", 1, 0, 0, 0, 12, 159, 12, 0},
    {-1, 2, 0, (char *)"LongTermDenialParam", 1, 0, 0, 0, 12, 159, 12, 0},
    {-1, 2, 1094, (char *)"UnauthorizedRequestingNetwork-Param", 512, 1, 1, 0, 12, 159, 12, 0},
    {-1, 2, 1459, (char *)"UnauthorizedLCSClient-Param", 512, 2, 1, 0, 12, 160, 12, 0},
    {-1, 2, 1459, (char *)"PositionMethodFailure-Param", 512, 2, 1, 0, 12, 162, 12, 0},
    {-1, 2, 1094, (char *)"UnknownOrUnreachableLCSClient-Param", 512, 1, 1, 0, 12, 164, 12, 0},
    {-1, 2, 1094, (char *)"MM-EventNotSupported-Param", 512, 1, 1, 0, 12, 165, 12, 0},
    {-1, 2, 1094, (char *)"TargetCellOutsideGCA-Param", 512, 1, 1, 0, 12, 166, 12, 0},
    {-1, 2, 958, (char *)"SecureTransportErrorParam", 3496, 2, 1, 0, 8, 64, 12, 0},
    {16, 2, 1469, (char *)"SendRoutingInfoArg", 3824, 30, 4, 0, 2076, 167, 12, 0},
    {14, 2107, 2109, (char *)"SendRoutingInfoRes", 73608, 24, 4, 0, 2076, 197, 12, 0},
    {9, 2, 2765, (char *)"ProvideRoamingNumberArg", 2760, 20, 4, 0, 2076, 221, 12, 0},
    {1, 2, 3151, (char *)"ProvideRoamingNumberRes", 528, 3, 1, 0, 2076, 241, 12, 0},
    {3, 2, 3165, (char *)"ResumeCallHandlingArg", 21560, 14, 2, 0, 2076, 244, 12, 0},
    {-1, 2, 1094, (char *)"ResumeCallHandlingRes", 512, 1, 1, 0, 12, 258, 12, 0},
    {-1, 2, 3403, (char *)"SetReportingStateArg", 528, 4, 1, 0, 12, 259, 12, 0},
    {-1, 2, 1459, (char *)"SetReportingStateRes", 512, 2, 1, 0, 12, 263, 12, 0},
    {-1, 2, 3431, (char *)"StatusReportArg", 1552, 4, 1, 0, 12, 265, 12, 0},
    {-1, 2, 3453, (char *)"StatusReportRes", 512, 1, 1, 0, 12, 269, 12, 0},
    {-1, 2, 3457, (char *)"RemoteUserFreeArg", 1304, 7, 1, 0, 12, 270, 12, 0},
    {-1, 2, 3491, (char *)"RemoteUserFreeRes", 512, 2, 1, 0, 12, 277, 12, 0},
    {-1, 2, 3491, (char *)"IST-AlertArg", 520, 2, 1, 0, 12, 279, 12, 0},
    {-1, 2, 3403, (char *)"IST-AlertRes", 520, 4, 1, 0, 12, 281, 12, 0},
    {-1, 2, 3491, (char *)"IST-CommandArg", 520, 2, 1, 0, 12, 285, 12, 0},
    {-1, 2, 1094, (char *)"IST-CommandRes", 512, 1, 1, 0, 12, 287, 12, 0},
    {-1, 2, 1058, (char *)"ReleaseResourcesArg", 520, 2, 1, 0, 12, 288, 12, 0},
    {-1, 2, 1094, (char *)"ReleaseResourcesRes", 512, 1, 1, 0, 12, 290, 12, 0},
    {3, 2, 3499, (char *)"RegisterSS-Arg", 66, 8, 1, 0, 2076, 291, 12, 0},
    {-1, 966, 3575, (char *)"InterrogateSS-Res", 944, 4, 2, 4, 8, 299, 13, 0},
    {2, 2, 3584, (char *)"USSD-Arg", 184, 4, 1, 0, 2076, 303, 12, 0},
    {-1, 2, 3602, (char *)"USSD-Res", 166, 2, 0, 0, 12, 307, 12, 0},
    {2, 1395, 0, (char *)"GuidanceInfo", 4, 0, 4, 0, 24, 6, 58, 0},
    {30, 2, 0, (char *)"SS-InfoList", 2, 948, 2, 4, 24, 830, 17, 0},
    {2, 2, 3610, (char *)"SS-InvocationNotificationArg", 600, 7, 1, 0, 2076, 309, 12, 0},
    {-1, 2, 1094, (char *)"SS-InvocationNotificationRes", 512, 1, 1, 0, 12, 316, 12, 0},
    {-1, 2, 3491, (char *)"RegisterCC-EntryArg", 1512, 2, 1, 0, 12, 317, 12, 0},
    {-1, 2, 3453, (char *)"RegisterCC-EntryRes", 48, 1, 1, 0, 12, 319, 12, 0},
    {-1, 2, 3491, (char *)"EraseCC-EntryArg", 8, 2, 1, 0, 12, 320, 12, 0},
    {-1, 2, 3491, (char *)"EraseCC-EntryRes", 10, 2, 1, 0, 12, 322, 12, 0},
    {3, 2, 3650, (char *)"RoutingInfoForSM-Arg", 568, 7, 1, 0, 2076, 324, 12, 0},
    {-1, 2, 3690, (char *)"RoutingInfoForSM-Res", 1064, 3, 1, 0, 12, 331, 12, 0},
    {1, 2, 3702, (char *)"MO-ForwardSM-Arg", 776, 5, 1, 0, 2076, 334, 12, 0},
    {-1, 2, 3734, (char *)"MO-ForwardSM-Res", 712, 2, 1, 0, 12, 339, 12, 0},
    {-1, 2, 3744, (char *)"MT-ForwardSM-Arg", 760, 5, 1, 0, 12, 341, 12, 0},
    {-1, 2, 3734, (char *)"MT-ForwardSM-Res", 712, 2, 1, 0, 12, 346, 12, 0},
    {4, 2, 3776, (char *)"ReportSM-DeliveryStatusArg", 568, 9, 1, 0, 2076, 348, 12, 0},
    {-1, 2, 3734, (char *)"ReportSM-DeliveryStatusRes", 520, 2, 1, 0, 12, 357, 12, 0},
    {-1, 2, 3602, (char *)"AlertServiceCentreArg", 34, 2, 0, 0, 12, 359, 12, 0},
    {2, 2, 3842, (char *)"InformServiceCentreArg", 528, 5, 1, 0, 2076, 361, 12, 0},
    {-1, 2, 3882, (char *)"ReadyForSM-Arg", 528, 4, 1, 0, 12, 366, 12, 0},
    {-1, 2, 1094, (char *)"ReadyForSM-Res", 512, 1, 1, 0, 12, 370, 12, 0},
    {-1, 2, 3900, (char *)"MT-ForwardSM-VGCS-Arg", 744, 4, 1, 0, 12, 371, 12, 0},
    {-1, 2, 3920, (char *)"MT-ForwardSM-VGCS-Res", 776, 4, 1, 0, 12, 375, 12, 0},
    {5, 2, 3948, (char *)"ActivateTraceModeArg", 608, 10, 1, 0, 2076, 379, 12, 0},
    {1, 2, 1459, (char *)"ActivateTraceModeRes", 520, 2, 1, 0, 2076, 389, 12, 0},
    {1, 2, 4032, (char *)"DeactivateTraceModeArg", 528, 4, 1, 0, 2076, 391, 12, 0},
    {-1, 2, 3453, (char *)"DeactivateTraceModeRes", 512, 1, 1, 0, 12, 395, 12, 0},
    {5, 2, 4052, (char *)"UpdateLocationArg", 1136, 10, 1, 0, 2076, 396, 12, 0},
    {1, 2, 3151, (char *)"UpdateLocationRes", 528, 3, 1, 0, 2076, 406, 12, 0},
    {-1, 2107, 4134, (char *)"CancelLocationArg", 528, 3, 1, 0, 12, 409, 12, 0},
    {-1, 2, 1094, (char *)"CancelLocationRes", 512, 1, 1, 0, 12, 412, 12, 0},
    {-1, 2107, 4150, (char *)"PurgeMS-Arg", 544, 4, 1, 0, 12, 413, 12, 0},
    {-1, 2, 4172, (char *)"PurgeMS-Res", 512, 3, 1, 0, 12, 417, 12, 0},
    {3, 2, 4190, (char *)"SendIdentificationArg", 544, 7, 1, 0, 2076, 420, 12, 0},
    {-1, 2107, 4248, (char *)"SendIdentificationRes", 1016, 4, 1, 0, 12, 427, 12, 0},
    {5, 2, 4280, (char *)"AuthenticationFailureReportArg", 576, 8, 1, 0, 2076, 431, 12, 0},
    {-1, 2, 1094, (char *)"AuthenticationFailureReportRes", 512, 1, 1, 0, 12, 439, 12, 0},
    {5, 2, 4342, (char *)"UpdateGprsLocationArg", 1128, 9, 1, 0, 2076, 440, 12, 0},
    {1, 2, 3151, (char *)"UpdateGprsLocationRes", 528, 3, 1, 0, 2076, 449, 12, 0},
    {11, 2107, 4408, (char *)"ForwardAccessSignalling-Arg", 6232, 19, 4, 0, 2076, 452, 12, 0},
    {14, 2107, 4790, (char *)"PrepareHO-Arg", 6416, 27, 4, 0, 2076, 471, 12, 0},
    {2, 2107, 5600, (char *)"PrepareHO-Res", 4816, 10, 2, 0, 2076, 498, 12, 0},
    {2, 2107, 5730, (char *)"PrepareSubsequentHO-Arg", 3728, 8, 1, 0, 2076, 508, 12, 0},
    {-1, 2107, 5794, (char *)"PrepareSubsequentHO-Res", 3592, 2, 1, 0, 12, 516, 12, 0},
    {2, 2107, 5802, (char *)"ProcessAccessSignalling-Arg", 4696, 8, 1, 0, 2076, 518, 12, 0},
    {-1, 2107, 5794, (char *)"SendEndSignal-Arg", 3592, 2, 1, 0, 12, 526, 12, 0},
    {-1, 2, 3453, (char *)"SendEndSignal-Res", 512, 1, 1, 0, 12, 528, 12, 0},
    {2, 2, 5876, (char *)"SendAuthenticationInfoArg", 576, 8, 1, 0, 2076, 529, 12, 0},
    {-1, 2107, 5938, (char *)"SendAuthenticationInfoRes", 960, 2, 1, 0, 12, 537, 12, 0},
    {-1, 2, 5950, (char *)"CheckIMEI-Arg", 520, 3, 1, 0, 12, 539, 12, 0},
    {-1, 2, 5962, (char *)"CheckIMEI-Res", 552, 3, 1, 0, 12, 542, 12, 0},
    {18, 2, 5980, (char *)"InsertSubscriberDataArg", 4638816, 32, 4, 0, 2076, 545, 12, 0},
    {1, 2, 7100, (char *)"InsertSubscriberDataRes", 1216, 8, 1, 0, 2076, 577, 12, 0},
    {7, 2, 7188, (char *)"DeleteSubscriberDataArg", 1592, 16, 2, 0, 2076, 585, 12, 0},
    {-1, 2, 7462, (char *)"DeleteSubscriberDataRes", 512, 2, 1, 0, 12, 601, 12, 0},
    {-1, 2, 7472, (char *)"SendRoutingInfoForGprsArg", 552, 4, 1, 0, 12, 603, 12, 0},
    {-1, 2, 3431, (char *)"SendRoutingInfoForGprsRes", 552, 4, 1, 0, 12, 607, 12, 0},
    {-1, 2, 7490, (char *)"FailureReportArg", 552, 4, 1, 0, 12, 611, 12, 0},
    {-1, 2, 1459, (char *)"FailureReportRes", 528, 2, 1, 0, 12, 615, 12, 0},
    {-1, 2, 7490, (char *)"NoteMsPresentForGprsArg", 560, 4, 1, 0, 12, 617, 12, 0},
    {-1, 2, 3453, (char *)"NoteMsPresentForGprsRes", 512, 1, 1, 0, 12, 621, 12, 0},
    {-1, 2, 1058, (char *)"ResetArg", 516, 2, 1, 0, 12, 622, 12, 0},
    {1, 2, 7508, (char *)"RestoreDataArg", 1072, 4, 1, 0, 2076, 624, 12, 0},
    {-1, 2, 7530, (char *)"RestoreDataRes", 520, 3, 1, 0, 12, 628, 12, 0},
    {-1, 2, 7472, (char *)"ProvideSubscriberInfoArg", 1056, 4, 1, 0, 12, 631, 12, 0},
    {-1, 2, 7544, (char *)"ProvideSubscriberInfoRes", 42848, 2, 1, 0, 12, 635, 12, 0},
    {-1, 2, 7552, (char *)"AnyTimeInterrogationArg", 1064, 4, 1, 0, 12, 637, 12, 0},
    {-1, 2, 7544, (char *)"AnyTimeInterrogationRes", 42848, 2, 1, 0, 12, 641, 12, 0},
    {-1, 2, 7568, (char *)"AnyTimeSubscriptionInterrogationArg", 1088, 5, 1, 0, 12, 643, 12, 0},
    {3, 2, 7590, (char *)"AnyTimeSubscriptionInterrogationRes", 179376, 10, 2, 0, 2076, 648, 12, 0},
    {1, 2, 7720, (char *)"AnyTimeModificationArg", 3240, 8, 1, 0, 2076, 658, 12, 0},
    {1, 2, 3403, (char *)"AnyTimeModificationRes", 100728, 4, 1, 0, 2076, 666, 12, 0},
    {-1, 2, 7782, (char *)"NoteSubscriberDataModifiedArg", 118176, 8, 1, 0, 12, 670, 12, 0},
    {-1, 2, 1094, (char *)"NoteSubscriberDataModifiedRes", 512, 1, 1, 0, 12, 678, 12, 0},
    {2, 2, 7844, (char *)"NoteMM-EventArg", 1736, 9, 1, 0, 2076, 679, 12, 0},
    {-1, 2, 1094, (char *)"NoteMM-EventRes", 512, 1, 1, 0, 12, 688, 12, 0},
    {9, 1348, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {8, 1348, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {8, 7900, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 7902, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 966, 967, (char *)"SubscriberIdentity", 14, 2, 2, 2, 8, 689, 13, 0},
    {-1, 0, 0, (char *)"_ObjectID", 8, 8, 2, 8, 40, 0, 27, 0},
    {-1, 966, 0, NULL, 32, 0, 0, 0, 8, 0, 51, 0},
    {-1, 2, 7904, (char *)"PrivateExtension", 48, 2, 1, 0, 264, 691, 12, 0},
    {10, 2, 0, (char *)"PrivateExtensionList", 2, 48, 2, 8, 24, 168, 17, 0},
    {-1, 2, 0, (char *)"PCS-Extensions", 1, 0, 0, 0, 12, 159, 12, 0},
    {10, 7900, 0, (char *)"PrivateExtensionList", 2, 48, 2, 8, 24, 168, 17, 0},
    {-1, 7902, 0, (char *)"PCS-Extensions", 1, 0, 0, 0, 12, 159, 12, 0},
    {-1, 2, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {9, 7900, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7902, 967, (char *)"SubscriberIdentity", 14, 2, 2, 2, 8, 689, 13, 0},
    {-1, 7910, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {4, 1348, 0, (char *)"LMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 7900, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 7902, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 966, 967, (char *)"Additional-Number", 14, 2, 2, 2, 8, 695, 13, 0},
    {16, 7912, 0, (char *)"SupportedLCS-CapabilitySets", 2, 0, 2, 0, 24, 11, 1, 0},
    {4, 7900, 0, (char *)"LMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7902, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 7910, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2107, 967, (char *)"Additional-Number", 14, 2, 2, 2, 8, 695, 13, 0},
    {16, 7914, 0, (char *)"SupportedLCS-CapabilitySets", 2, 0, 2, 0, 24, 11, 1, 0},
    {16, 7916, 0, (char *)"SupportedLCS-CapabilitySets", 2, 0, 2, 0, 24, 11, 1, 0},
    {4, 2, 7918, (char *)"LCSLocationInfo", 552, 7, 1, 0, 2076, 697, 12, 0},
    {17, 1348, 0, (char *)"GSN-Address", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7900, 967, (char *)"SubscriberIdentity", 14, 2, 2, 2, 8, 689, 13, 0},
    {4, 7902, 7918, (char *)"LCSLocationInfo", 552, 7, 1, 0, 2076, 697, 12, 0},
    {-1, 7910, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {17, 2107, 0, (char *)"GSN-Address", 2, 0, 2, 2, 24, 0, 21, 0},
    {17, 7914, 0, (char *)"GSN-Address", 2, 0, 2, 2, 24, 0, 21, 0},
    {17, 7916, 0, (char *)"GSN-Address", 2, 0, 2, 2, 24, 0, 21, 0},
    {17, 7976, 0, (char *)"GSN-Address", 2, 0, 2, 2, 24, 0, 21, 0},
    {INT_MAX, 1395, 0, (char *)"LocationEstimateType", 4, 0, 4, 0, 2076, 17, 58, 0},
    {16, 7912, 0, (char *)"DeferredLocationEventType", 2, 0, 2, 0, 24, 27, 1, 0},
    {INT_MAX, 7900, 0, (char *)"LocationEstimateType", 4, 0, 4, 0, 2076, 17, 58, 0},
    {16, 7902, 0, (char *)"DeferredLocationEventType", 2, 0, 2, 0, 24, 27, 1, 0},
    {1, 2, 3491, (char *)"LocationType", 12, 2, 1, 0, 2076, 704, 12, 0},
    {INT_MAX, 1395, 0, (char *)"LCSClientType", 4, 0, 4, 0, 2076, 33, 58, 0},
    {9, 7900, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7902, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 2, 1459, (char *)"LCSClientExternalID", 520, 2, 1, 0, 12, 706, 12, 0},
    {20, 1348, 0, (char *)"AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {INT_MAX, 1395, 0, (char *)"LCSClientInternalID", 4, 0, 4, 0, 2076, 42, 58, 0},
    {1, 1348, 0, (char *)"USSD-DataCodingScheme", 2, 0, 2, 2, 24, 0, 21, 0},
    {63, 1348, 0, (char *)"NameString", 2, 0, 2, 2, 24, 0, 21, 0},
    {INT_MAX, 1395, 0, (char *)"LCS-FormatIndicator", 4, 0, 4, 0, 2076, 52, 58, 0},
    {1, 7900, 0, (char *)"USSD-DataCodingScheme", 2, 0, 2, 2, 24, 0, 21, 0},
    {63, 7910, 0, (char *)"NameString", 2, 0, 2, 2, 24, 0, 21, 0},
    {INT_MAX, 2107, 0, (char *)"LCS-FormatIndicator", 4, 0, 4, 0, 2076, 52, 58, 0},
    {1, 2, 7978, (char *)"LCSClientName", 76, 3, 1, 0, 2076, 708, 12, 0},
    {63, 1348, 0, (char *)"APN", 2, 0, 2, 2, 24, 0, 21, 0},
    {63, 1348, 0, (char *)"RequestorIDString", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 7900, 0, (char *)"USSD-DataCodingScheme", 2, 0, 2, 2, 24, 0, 21, 0},
    {63, 7902, 0, (char *)"RequestorIDString", 2, 0, 2, 2, 24, 0, 21, 0},
    {INT_MAX, 7910, 0, (char *)"LCS-FormatIndicator", 4, 0, 4, 0, 2076, 52, 58, 0},
    {1, 2, 4, (char *)"LCSRequestorID", 76, 3, 1, 0, 2076, 711, 12, 0},
    {INT_MAX, 7900, 0, (char *)"LCSClientType", 4, 0, 4, 0, 2076, 33, 58, 0},
    {-1, 7902, 1459, (char *)"LCSClientExternalID", 520, 2, 1, 0, 12, 706, 12, 0},
    {20, 7910, 0, (char *)"AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {INT_MAX, 2107, 0, (char *)"LCSClientInternalID", 4, 0, 4, 0, 2076, 42, 58, 0},
    {1, 7914, 7978, (char *)"LCSClientName", 76, 3, 1, 0, 2076, 708, 12, 0},
    {63, 7916, 0, (char *)"APN", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 7976, 4, (char *)"LCSRequestorID", 76, 3, 1, 0, 2076, 711, 12, 0},
    {2, 2, 7990, (char *)"LCS-ClientID", 776, 7, 1, 0, 2076, 714, 12, 0},
    {8, 1348, 0, (char *)"IMEI", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 1348, 0, (char *)"LCS-Priority", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 1348, 0, (char *)"Horizontal-Accuracy", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 1348, 0, (char *)"Vertical-Accuracy", 2, 0, 2, 2, 24, 0, 21, 0},
    {INT_MAX, 1395, 0, (char *)"ResponseTimeCategory", 4, 0, 4, 0, 2076, 62, 58, 0},
    {-1, 2, 8048, (char *)"ResponseTime", 4, 1, 0, 0, 12, 721, 12, 0},
    {1, 7900, 0, (char *)"Horizontal-Accuracy", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7902, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {1, 7910, 0, (char *)"Vertical-Accuracy", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2107, 8048, (char *)"ResponseTime", 4, 1, 0, 0, 12, 721, 12, 0},
    {-1, 7914, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 7916, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {1, 2, 8052, (char *)"LCS-QoS", 528, 6, 1, 0, 2076, 722, 12, 0},
    {16, 7912, 0, (char *)"SupportedGADShapes", 2, 0, 2, 0, 24, 69, 1, 0},
    {1, 1348, 0, (char *)"LCS-ReferenceNumber", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 8106, 0, (char *)"LCSServiceTypeID", 2, 0, 2, 0, 8, 0, 55, 0},
    {20, 1348, 0, (char *)"LCSCodewordString", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 7900, 0, (char *)"USSD-DataCodingScheme", 2, 0, 2, 2, 24, 0, 21, 0},
    {20, 7902, 0, (char *)"LCSCodewordString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2, 3491, (char *)"LCSCodeword", 26, 2, 0, 0, 12, 728, 12, 0},
    {INT_MAX, 1395, 0, (char *)"PrivacyCheckRelatedAction", 4, 0, 4, 0, 2076, 78, 58, 0},
    {INT_MAX, 7900, 0, (char *)"PrivacyCheckRelatedAction", 4, 0, 4, 0, 2076, 78, 58, 0},
    {INT_MAX, 7902, 0, (char *)"PrivacyCheckRelatedAction", 4, 0, 4, 0, 2076, 78, 58, 0},
    {-1, 2, 3491, (char *)"LCS-PrivacyCheck", 12, 2, 1, 0, 12, 730, 12, 0},
    {INT_MAX, 1395, 0, (char *)"AreaType", 4, 0, 4, 0, 2076, 88, 58, 0},
    {7, 1348, 0, (char *)"AreaIdentification", 2, 0, 2, 2, 24, 0, 21, 0},
    {INT_MAX, 7900, 0, (char *)"AreaType", 4, 0, 4, 0, 2076, 88, 58, 0},
    {7, 7902, 0, (char *)"AreaIdentification", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2, 3491, (char *)"Area", 16, 2, 0, 0, 12, 732, 12, 0},
    {10, 2, 0, (char *)"AreaList", 2, 16, 2, 4, 24, 257, 17, 0},
    {10, 7900, 0, (char *)"AreaList", 2, 16, 2, 4, 24, 257, 17, 0},
    {-1, 2, 3453, (char *)"AreaDefinition", 164, 1, 0, 0, 12, 734, 12, 0},
    {INT_MAX, 1395, 0, (char *)"OccurrenceInfo", 4, 0, 4, 0, 2076, 99, 58, 0},
    {-1, 8106, 0, (char *)"IntervalTime", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 7900, 3453, (char *)"AreaDefinition", 164, 1, 0, 0, 12, 734, 12, 0},
    {INT_MAX, 7902, 0, (char *)"OccurrenceInfo", 4, 0, 4, 0, 2076, 99, 58, 0},
    {-1, 7910, 0, (char *)"IntervalTime", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 2, 8108, (char *)"AreaEventInfo", 176, 3, 1, 0, 12, 735, 12, 0},
    {2, 7900, 7990, (char *)"LCS-ClientID", 776, 7, 1, 0, 2076, 714, 12, 0},
    {-1, 7902, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {8, 7910, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 2107, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 7914, 0, (char *)"LMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {8, 7916, 0, (char *)"IMEI", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 7976, 0, (char *)"LCS-Priority", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 8122, 8052, (char *)"LCS-QoS", 528, 6, 1, 0, 2076, 722, 12, 0},
    {-1, 8124, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {16, 8126, 0, (char *)"SupportedGADShapes", 2, 0, 2, 0, 24, 69, 1, 0},
    {1, 8128, 0, (char *)"LCS-ReferenceNumber", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 8130, 0, (char *)"LCSServiceTypeID", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 8132, 3491, (char *)"LCSCodeword", 26, 2, 0, 0, 12, 728, 12, 0},
    {-1, 8134, 3491, (char *)"LCS-PrivacyCheck", 12, 2, 1, 0, 12, 730, 12, 0},
    {-1, 8136, 8108, (char *)"AreaEventInfo", 176, 3, 1, 0, 12, 735, 12, 0},
    {17, 8138, 0, (char *)"GSN-Address", 2, 0, 2, 2, 24, 0, 21, 0},
    {20, 1348, 0, (char *)"Ext-GeographicalInformation", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 8106, 0, (char *)"AgeOfLocationInformation", 2, 0, 2, 0, 8, 0, 55, 0},
    {91, 1348, 0, (char *)"Add-GeographicalInformation", 2, 0, 2, 2, 24, 0, 21, 0},
    {10, 1348, 0, (char *)"PositioningDataInformation", 2, 0, 2, 2, 24, 0, 21, 0},
    {11, 1348, 0, (char *)"UtranPositioningDataInfo", 2, 0, 2, 2, 24, 0, 21, 0},
    {7, 1348, 0, (char *)"CellGlobalIdOrServiceAreaIdFixedLength", 2, 0, 2, 2, 24, 0, 21, 0},
    {5, 1348, 0, (char *)"LAIFixedLength", 2, 0, 2, 2, 24, 0, 21, 0},
    {7, 7900, 0, (char *)"CellGlobalIdOrServiceAreaIdFixedLength", 2, 0, 2, 2, 24, 0, 21, 0},
    {5, 7902, 0, (char *)"LAIFixedLength", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 966, 967, (char *)"CellGlobalIdOrServiceAreaIdOrLAI", 12, 2, 2, 2, 8, 738, 13, 0},
    {INT_MAX, 1395, 0, (char *)"AccuracyFulfilmentIndicator", 4, 0, 4, 0, 2076, 106, 58, 0},
    {7, 1348, 0, (char *)"VelocityEstimate", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7900, 0, (char *)"AgeOfLocationInformation", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 7902, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {91, 7910, 0, (char *)"Add-GeographicalInformation", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2107, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {10, 7914, 0, (char *)"PositioningDataInformation", 2, 0, 2, 2, 24, 0, 21, 0},
    {11, 7916, 0, (char *)"UtranPositioningDataInfo", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7976, 967, (char *)"CellGlobalIdOrServiceAreaIdOrLAI", 12, 2, 2, 2, 8, 738, 13, 0},
    {-1, 8122, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {INT_MAX, 8124, 0, (char *)"AccuracyFulfilmentIndicator", 4, 0, 4, 0, 2076, 106, 58, 0},
    {7, 8126, 0, (char *)"VelocityEstimate", 2, 0, 2, 2, 24, 0, 21, 0},
    {INT_MAX, 1395, 0, (char *)"LCS-Event", 4, 0, 4, 0, 2076, 113, 58, 0},
    {-1, 7900, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {1, 2, 3453, (char *)"SLR-Arg-PCS-Extensions", 2, 1, 1, 0, 2076, 740, 12, 0},
    {10, 7900, 0, (char *)"PrivateExtensionList", 2, 48, 2, 8, 24, 168, 17, 0},
    {1, 7902, 3453, (char *)"SLR-Arg-PCS-Extensions", 2, 1, 1, 0, 2076, 740, 12, 0},
    {-1, 2, 1459, (char *)"SLR-ArgExtensionContainer", 504, 2, 1, 0, 12, 741, 12, 0},
    {INT_MAX, 1395, 0, (char *)"TerminationCause", 4, 0, 4, 0, 2076, 122, 58, 0},
    {INT_MAX, 7900, 0, (char *)"TerminationCause", 4, 0, 4, 0, 2076, 122, 58, 0},
    {4, 7902, 7918, (char *)"LCSLocationInfo", 552, 7, 1, 0, 2076, 697, 12, 0},
    {-1, 2, 8140, (char *)"Deferredmt-lrData", 560, 3, 1, 0, 12, 743, 12, 0},
    {9, 7900, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {8, 7902, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {8, 7910, 0, (char *)"IMEI", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 2107, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 7914, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {20, 7916, 0, (char *)"Ext-GeographicalInformation", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7976, 0, (char *)"AgeOfLocationInformation", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 8122, 1459, (char *)"SLR-ArgExtensionContainer", 504, 2, 1, 0, 12, 741, 12, 0},
    {91, 8124, 0, (char *)"Add-GeographicalInformation", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 8126, 8140, (char *)"Deferredmt-lrData", 560, 3, 1, 0, 12, 743, 12, 0},
    {1, 8128, 0, (char *)"LCS-ReferenceNumber", 2, 0, 2, 2, 24, 0, 21, 0},
    {10, 8130, 0, (char *)"PositioningDataInformation", 2, 0, 2, 2, 24, 0, 21, 0},
    {11, 8132, 0, (char *)"UtranPositioningDataInfo", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 8134, 967, (char *)"CellGlobalIdOrServiceAreaIdOrLAI", 12, 2, 2, 2, 8, 738, 13, 0},
    {17, 8136, 0, (char *)"GSN-Address", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 8138, 0, (char *)"LCSServiceTypeID", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 8154, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 8156, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {7, 8158, 0, (char *)"VelocityEstimate", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 7900, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 7902, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 1348, 0, (char *)"SecurityParametersIndex", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 8106, 0, NULL, 4, 0, 4, 0, 8, 0, 0, 0},
    {-1, 966, 8160, (char *)"OperationCode", 16, 2, 2, 8, 8, 746, 13, 0},
    {-1, 966, 8160, (char *)"ErrorCode", 16, 2, 2, 8, 8, 746, 13, 0},
    {-1, 7900, 8160, (char *)"OperationCode", 16, 2, 2, 8, 8, 746, 13, 0},
    {-1, 7902, 8160, (char *)"ErrorCode", 16, 2, 2, 8, 8, 746, 13, 0},
    {-1, 7910, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 966, 8165, (char *)"OriginalComponentIdentifier", 24, 3, 2, 8, 8, 748, 13, 0},
    {14, 1348, 0, (char *)"InitialisationVector", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2, 8172, (char *)"SecurityHeader", 48, 3, 1, 0, 12, 751, 12, 0},
    {3438, 1348, 0, (char *)"ProtectedPayload", 2, 0, 2, 2, 24, 0, 21, 0},
    {15, 1348, 0, (char *)"FTN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {21, 1348, 0, (char *)"ISDN-SubaddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 1395, 0, (char *)"ProtocolId", 4, 0, 4, 0, 24, 134, 58, 0},
    {200, 1348, 0, (char *)"SignalInfo", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2, 8188, (char *)"ExternalSignalInfo", 720, 3, 1, 0, 12, 754, 12, 0},
    {INT_MAX, 1395, 0, (char *)"Ext-ProtocolId", 4, 0, 4, 0, 2076, 140, 58, 0},
    {-1, 2, 8188, (char *)"Ext-ExternalSignalInfo", 720, 3, 1, 0, 12, 757, 12, 0},
    {INT_MAX, 1395, 0, (char *)"AccessNetworkProtocolId", 4, 0, 4, 0, 2076, 146, 58, 0},
    {2560, 1348, 0, (char *)"LongSignalInfo", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2, 8188, (char *)"AccessNetworkSignalInfo", 3080, 3, 1, 0, 12, 760, 12, 0},
    {1, 1348, 0, (char *)"AlertingPattern", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2, 3602, (char *)"IMSI-WithLMSI", 16, 2, 0, 0, 12, 763, 12, 0},
    {-1, 966, 8200, (char *)"Identity", 18, 2, 2, 2, 8, 765, 13, 0},
    {8, 1348, 0, (char *)"ASCI-CallReference", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 1348, 0, (char *)"TMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {8, 7900, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 7902, 0, (char *)"TMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {8, 1348, 0, (char *)"HLR-Id", 2, 0, 2, 2, 24, 0, 21, 0},
    {50, 2, 0, (char *)"HLR-List", 2, 10, 2, 2, 24, 364, 17, 0},
    {7, 1348, 0, (char *)"GlobalCellId", 2, 0, 2, 2, 24, 0, 21, 0},
    {7, 1395, 0, (char *)"NetworkResource", 4, 0, 4, 0, 24, 153, 58, 0},
    {INT_MAX, 1395, 0, (char *)"AdditionalNetworkResource", 4, 0, 4, 0, 2076, 163, 58, 0},
    {3, 1348, 0, (char *)"NAEA-CIC", 2, 0, 2, 2, 24, 0, 21, 0},
    {3, 7900, 0, (char *)"NAEA-CIC", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7902, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 2, 3491, (char *)"NAEA-PreferredCI", 512, 2, 1, 0, 12, 767, 12, 0},
    {1, 1348, 0, (char *)"BearerServiceCode", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 1348, 0, (char *)"TeleserviceCode", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 7910, 0, (char *)"BearerServiceCode", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 2107, 0, (char *)"TeleserviceCode", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 966, 8205, (char *)"BasicServiceCode", 6, 2, 2, 2, 8, 769, 13, 0},
    {5, 1348, 0, (char *)"Ext-BearerServiceCode", 2, 0, 2, 2, 24, 0, 21, 0},
    {5, 1348, 0, (char *)"Ext-TeleserviceCode", 2, 0, 2, 2, 24, 0, 21, 0},
    {5, 7910, 0, (char *)"Ext-BearerServiceCode", 2, 0, 2, 2, 24, 0, 21, 0},
    {5, 2107, 0, (char *)"Ext-TeleserviceCode", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 966, 8205, (char *)"Ext-BasicServiceCode", 10, 2, 2, 2, 8, 771, 13, 0},
    {-1, 8106, 0, (char *)"EMLPP-Priority", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 2, 8210, (char *)"EMLPP-Info", 512, 3, 1, 0, 12, 773, 12, 0},
    {1, 1348, 0, (char *)"SS-Code", 2, 0, 2, 2, 24, 0, 21, 0},
    {5, 1348, 0, (char *)"Ext-SS-Status", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 8106, 0, (char *)"MaxMC-Bearers", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 8106, 0, (char *)"MC-Bearers", 2, 0, 2, 0, 8, 0, 55, 0},
    {1, 7900, 0, (char *)"SS-Code", 2, 0, 2, 2, 24, 0, 21, 0},
    {5, 7902, 0, (char *)"Ext-SS-Status", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7910, 0, (char *)"MaxMC-Bearers", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 2107, 0, (char *)"MC-Bearers", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 7914, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 2, 8222, (char *)"MC-SS-Info", 528, 5, 1, 0, 12, 776, 12, 0},
    {10, 1348, 0, (char *)"CODEC-Info", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 1348, 0, (char *)"CipheringAlgorithm", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 8106, 0, (char *)"GroupKeyNumber", 2, 0, 2, 0, 8, 0, 55, 0},
    {8, 1348, 0, (char *)"Kc", 2, 0, 2, 2, 24, 0, 21, 0},
    {16, 1348, 0, (char *)"VSTK", 2, 0, 2, 2, 24, 0, 21, 0},
    {5, 1348, 0, (char *)"VSTK-RAND", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7900, 0, (char *)"GroupKeyNumber", 2, 0, 2, 0, 8, 0, 55, 0},
    {8, 7902, 0, (char *)"Kc", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7910, 0, (char *)"EMLPP-Priority", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 2107, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 7914, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {16, 7916, 0, (char *)"VSTK", 2, 0, 2, 2, 24, 0, 21, 0},
    {5, 7976, 0, (char *)"VSTK-RAND", 2, 0, 2, 2, 24, 0, 21, 0},
    {2, 1395, 0, (char *)"TalkerPriority", 4, 0, 4, 0, 24, 174, 58, 0},
    {136, 7912, 0, (char *)"AdditionalInfo", 16, 0, 2, 8, 24, 0, 3, 0},
    {2, 7900, 0, (char *)"TalkerPriority", 4, 0, 4, 0, 24, 174, 58, 0},
    {136, 7902, 0, (char *)"AdditionalInfo", 16, 0, 2, 8, 24, 0, 3, 0},
    {-1, 7916, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 7976, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 8122, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 8124, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2, 8242, (char *)"StateAttributes", 5, 4, 1, 0, 8, 781, 12, 0},
    {-1, 7900, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 7902, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 7910, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2107, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 7914, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 7916, 8242, (char *)"StateAttributes", 5, 4, 1, 0, 8, 781, 12, 0},
    {2, 7976, 0, (char *)"TalkerPriority", 4, 0, 4, 0, 24, 174, 58, 0},
    {136, 8122, 0, (char *)"AdditionalInfo", 16, 0, 2, 8, 24, 0, 3, 0},
    {-1, 8124, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {200, 8126, 0, (char *)"SignalInfo", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7900, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 7902, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 7910, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {2, 2107, 0, (char *)"TalkerPriority", 4, 0, 4, 0, 24, 174, 58, 0},
    {136, 7914, 0, (char *)"AdditionalInfo", 16, 0, 2, 8, 24, 0, 3, 0},
    {-1, 7916, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 966, 0, NULL, 2, 0, 0, 0, 8, 0, 50, 0},
    {-1, 8106, 0, NULL, 8, 0, 8, 0, 8, 0, 0, 0},
    {-1, 966, 0, (char *)"EXTENSION", 24, 3, 1, 0, 8, 785, 49, 0},
    {3, 1395, 0, (char *)"RoamingNotAllowedCause", 4, 0, 4, 0, 24, 179, 58, 0},
    {1, 1395, 0, (char *)"CallBarringCause", 4, 0, 4, 0, 24, 183, 58, 0},
    {-1, 7902, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {1, 2, 8270, (char *)"ExtensibleCallBarredParam", 520, 3, 1, 0, 2076, 788, 12, 0},
    {7, 1395, 0, (char *)"CUG-RejectCause", 4, 0, 4, 0, 24, 187, 58, 0},
    {1, 1348, 0, (char *)"SS-Status", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 7902, 0, (char *)"SS-Code", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 7914, 0, (char *)"SS-Status", 2, 0, 2, 2, 24, 0, 21, 0},
    {6, 1395, 0, (char *)"SM-EnumeratedDeliveryFailureCause", 4, 0, 4, 0, 24, 193, 58, 0},
    {-1, 8106, 0, (char *)"AbsentSubscriberDiagnosticSM", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 7900, 0, (char *)"AbsentSubscriberDiagnosticSM", 2, 0, 2, 0, 8, 0, 55, 0},
    {INT_MAX, 7900, 0, (char *)"AdditionalNetworkResource", 4, 0, 4, 0, 2076, 163, 58, 0},
    {1, 2, 5962, (char *)"ExtensibleSystemFailureParam", 520, 3, 1, 0, 2076, 791, 12, 0},
    {-1, 7900, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 7902, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {INT_MAX, 1395, 0, (char *)"UnknownSubscriberDiagnostic", 4, 0, 4, 0, 2076, 202, 58, 0},
    {INT_MAX, 1395, 0, (char *)"AbsentSubscriberReason", 4, 0, 4, 0, 2076, 210, 58, 0},
    {INT_MAX, 7900, 0, (char *)"AbsentSubscriberReason", 4, 0, 4, 0, 2076, 210, 58, 0},
    {-1, 7900, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 7902, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 8288, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {INT_MAX, 1395, 0, (char *)"UnauthorizedLCSClient-Diagnostic", 4, 0, 4, 0, 2076, 219, 58, 0},
    {INT_MAX, 7900, 0, (char *)"UnauthorizedLCSClient-Diagnostic", 4, 0, 4, 0, 2076, 219, 58, 0},
    {-1, 7902, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {INT_MAX, 1395, 0, (char *)"PositionMethodFailure-Diagnostic", 4, 0, 4, 0, 2076, 232, 58, 0},
    {INT_MAX, 7900, 0, (char *)"PositionMethodFailure-Diagnostic", 4, 0, 4, 0, 2076, 232, 58, 0},
    {-1, 7902, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {4, 1348, 0, (char *)"CUG-Interlock", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2, 7530, (char *)"CUG-CheckInfo", 520, 3, 1, 0, 12, 794, 12, 0},
    {-1, 8106, 0, (char *)"NumberOfForwarding", 2, 0, 2, 0, 8, 0, 55, 0},
    {1, 1395, 0, (char *)"InterrogationType", 4, 0, 4, 0, 24, 246, 58, 0},
    {-1, 8106, 0, (char *)"OR-Phase", 2, 0, 2, 0, 8, 0, 55, 0},
    {8, 1348, 0, (char *)"CallReferenceNumber", 2, 0, 2, 2, 24, 0, 21, 0},
    {2, 1395, 0, (char *)"ForwardingReason", 4, 0, 4, 0, 24, 250, 58, 0},
    {16, 7912, 0, (char *)"SupportedCamelPhases", 2, 0, 2, 0, 24, 255, 1, 0},
    {16, 7912, 0, (char *)"OfferedCamel4CSIs", 2, 0, 2, 0, 24, 261, 1, 0},
    {16, 7900, 0, (char *)"OfferedCamel4CSIs", 2, 0, 2, 0, 24, 261, 1, 0},
    {1, 2, 8290, (char *)"CamelInfo", 520, 4, 1, 0, 2076, 797, 12, 0},
    {-1, 8288, 0, (char *)"SuppressionOfAnnouncement", 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 8106, 0, (char *)"SupportedCCBS-Phase", 2, 0, 2, 0, 8, 0, 55, 0},
    {INT_MAX, 1395, 0, (char *)"IST-SupportIndicator", 4, 0, 4, 0, 2076, 270, 58, 0},
    {1, 1348, 0, (char *)"CallDiversionTreatmentIndicator", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 7900, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7902, 7530, (char *)"CUG-CheckInfo", 520, 3, 1, 0, 12, 794, 12, 0},
    {-1, 7910, 0, (char *)"NumberOfForwarding", 2, 0, 2, 0, 8, 0, 55, 0},
    {1, 2107, 0, (char *)"InterrogationType", 4, 0, 4, 0, 24, 246, 58, 0},
    {-1, 7914, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 7916, 0, (char *)"OR-Phase", 2, 0, 2, 0, 8, 0, 55, 0},
    {9, 7976, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {8, 8122, 0, (char *)"CallReferenceNumber", 2, 0, 2, 2, 24, 0, 21, 0},
    {2, 8124, 0, (char *)"ForwardingReason", 4, 0, 4, 0, 24, 250, 58, 0},
    {-1, 8126, 8205, (char *)"Ext-BasicServiceCode", 10, 2, 2, 2, 8, 771, 13, 0},
    {-1, 8128, 8188, (char *)"ExternalSignalInfo", 720, 3, 1, 0, 12, 754, 12, 0},
    {1, 8130, 8290, (char *)"CamelInfo", 520, 4, 1, 0, 2076, 797, 12, 0},
    {-1, 8132, 0, (char *)"SuppressionOfAnnouncement", 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 8134, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {1, 8136, 0, (char *)"AlertingPattern", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 8138, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 8312, 0, (char *)"SupportedCCBS-Phase", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 8154, 8188, (char *)"Ext-ExternalSignalInfo", 720, 3, 1, 0, 12, 757, 12, 0},
    {INT_MAX, 8156, 0, (char *)"IST-SupportIndicator", 4, 0, 4, 0, 2076, 270, 58, 0},
    {-1, 8158, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {1, 8314, 0, (char *)"CallDiversionTreatmentIndicator", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 8316, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 8318, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 8320, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 8322, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 8324, 8205, (char *)"Ext-BasicServiceCode", 10, 2, 2, 2, 8, 771, 13, 0},
    {-1, 8326, 8188, (char *)"ExternalSignalInfo", 720, 3, 1, 0, 12, 754, 12, 0},
    {16, 8328, 0, NULL, 2, 0, 2, 0, 24, 277, 1, 0},
    {-1, 8330, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 8332, 0, NULL, 2, 0, 2, 0, 8, 0, 55, 0},
    {1, 1348, 0, (char *)"ForwardingOptions", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 7916, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {21, 7914, 0, (char *)"ISDN-SubaddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 7976, 0, (char *)"ForwardingOptions", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 8122, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {15, 8124, 0, (char *)"FTN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 2, 8334, (char *)"ForwardingData", 576, 5, 1, 0, 2076, 801, 12, 0},
    {-1, 966, 8200, (char *)"RoutingInfo", 584, 2, 2, 8, 8, 806, 13, 0},
    {INT_MAX, 1395, 0, (char *)"T-BcsmTriggerDetectionPoint", 4, 0, 4, 0, 2076, 281, 58, 0},
    {-1, 8106, 0, (char *)"ServiceKey", 4, 0, 4, 0, 8, 0, 55, 0},
    {INT_MAX, 1395, 0, (char *)"DefaultCallHandling", 4, 0, 4, 0, 2076, 289, 58, 0},
    {9, 7900, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {INT_MAX, 7902, 0, (char *)"DefaultCallHandling", 4, 0, 4, 0, 2076, 289, 58, 0},
    {-1, 7910, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 2, 8374, (char *)"T-BcsmCamelTDPData", 536, 5, 1, 0, 12, 808, 12, 0},
    {10, 2, 0, (char *)"T-BcsmCamelTDPDataList", 2, 536, 2, 8, 24, 522, 17, 0},
    {-1, 8106, 0, (char *)"CamelCapabilityHandling", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 7900, 0, (char *)"CamelCapabilityHandling", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 7902, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 7910, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {3, 2, 8394, (char *)"T-CSI", 5888, 5, 1, 0, 2076, 813, 12, 0},
    {INT_MAX, 1395, 0, (char *)"O-BcsmTriggerDetectionPoint", 4, 0, 4, 0, 2076, 296, 58, 0},
    {9, 7900, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {INT_MAX, 7902, 0, (char *)"DefaultCallHandling", 4, 0, 4, 0, 2076, 289, 58, 0},
    {-1, 7910, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 2, 8374, (char *)"O-BcsmCamelTDPData", 536, 5, 1, 0, 12, 818, 12, 0},
    {10, 2, 0, (char *)"O-BcsmCamelTDPDataList", 2, 536, 2, 8, 24, 533, 17, 0},
    {-1, 7900, 0, (char *)"CamelCapabilityHandling", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 7902, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 7910, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {3, 2, 8394, (char *)"O-CSI", 5888, 5, 1, 0, 2076, 823, 12, 0},
    {1, 1395, 0, (char *)"MatchType", 4, 0, 4, 0, 24, 303, 58, 0},
    {10, 2, 0, (char *)"DestinationNumberList", 2, 12, 2, 2, 24, 161, 17, 0},
    {-1, 8106, 0, NULL, 2, 0, 2, 0, 8, 0, 55, 0},
    {3, 2, 0, (char *)"DestinationNumberLengthList", 2, 2, 2, 2, 24, 541, 17, 0},
    {1, 7900, 0, (char *)"MatchType", 4, 0, 4, 0, 24, 303, 58, 0},
    {10, 7902, 0, (char *)"DestinationNumberList", 2, 12, 2, 2, 24, 161, 17, 0},
    {3, 7910, 0, (char *)"DestinationNumberLengthList", 2, 2, 2, 2, 24, 541, 17, 0},
    {-1, 2, 8108, (char *)"DestinationNumberCriteria", 140, 3, 1, 0, 12, 828, 12, 0},
    {5, 2, 0, (char *)"BasicServiceCriteria", 2, 10, 2, 2, 24, 382, 17, 0},
    {1, 1395, 0, (char *)"CallTypeCriteria", 4, 0, 4, 0, 24, 307, 58, 0},
    {1, 1348, 0, (char *)"CauseValue", 2, 0, 2, 2, 24, 0, 21, 0},
    {5, 2, 0, (char *)"O-CauseValueCriteria", 2, 4, 2, 2, 24, 549, 17, 0},
    {-1, 7900, 8108, (char *)"DestinationNumberCriteria", 140, 3, 1, 0, 12, 828, 12, 0},
    {5, 7902, 0, (char *)"BasicServiceCriteria", 2, 10, 2, 2, 24, 382, 17, 0},
    {1, 7910, 0, (char *)"CallTypeCriteria", 4, 0, 4, 0, 24, 307, 58, 0},
    {5, 2107, 0, (char *)"O-CauseValueCriteria", 2, 4, 2, 2, 24, 549, 17, 0},
    {-1, 7914, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {2, 2, 8426, (char *)"O-BcsmCamelTDP-Criteria", 736, 6, 1, 0, 2076, 831, 12, 0},
    {10, 2, 0, (char *)"O-BcsmCamelTDPCriteriaList", 2, 736, 2, 8, 24, 556, 17, 0},
    {5, 2, 0, (char *)"T-CauseValueCriteria", 2, 4, 2, 2, 24, 549, 17, 0},
    {5, 7900, 0, (char *)"BasicServiceCriteria", 2, 10, 2, 2, 24, 382, 17, 0},
    {5, 7902, 0, (char *)"T-CauseValueCriteria", 2, 4, 2, 2, 24, 549, 17, 0},
    {-1, 2, 8470, (char *)"T-BCSM-CAMEL-TDP-Criteria", 84, 3, 1, 0, 12, 837, 12, 0},
    {10, 2, 0, (char *)"T-BCSM-CAMEL-TDP-CriteriaList", 2, 84, 2, 4, 24, 561, 17, 0},
    {-1, 2, 8484, (char *)"DP-AnalysedInfoCriterium", 544, 5, 1, 0, 12, 840, 12, 0},
    {10, 2, 0, (char *)"DP-AnalysedInfoCriteriaList", 2, 544, 2, 8, 24, 563, 17, 0},
    {10, 7900, 0, (char *)"DP-AnalysedInfoCriteriaList", 2, 544, 2, 8, 24, 563, 17, 0},
    {-1, 7902, 0, (char *)"CamelCapabilityHandling", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 7910, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 2107, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 7914, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2, 8504, (char *)"D-CSI", 5976, 5, 1, 0, 12, 845, 12, 0},
    {3, 7900, 8394, (char *)"T-CSI", 5888, 5, 1, 0, 2076, 813, 12, 0},
    {3, 7902, 8394, (char *)"O-CSI", 5888, 5, 1, 0, 2076, 823, 12, 0},
    {-1, 7910, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {10, 2107, 0, (char *)"O-BcsmCamelTDPCriteriaList", 2, 736, 2, 8, 24, 556, 17, 0},
    {10, 7914, 0, (char *)"T-BCSM-CAMEL-TDP-CriteriaList", 2, 84, 2, 4, 24, 561, 17, 0},
    {-1, 7916, 8504, (char *)"D-CSI", 5976, 5, 1, 0, 12, 845, 12, 0},
    {3, 2, 8052, (char *)"GmscCamelSubscriptionInfo", 26480, 6, 1, 0, 2076, 850, 12, 0},
    {3, 7900, 8052, (char *)"GmscCamelSubscriptionInfo", 26480, 6, 1, 0, 2076, 850, 12, 0},
    {-1, 7902, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 2, 8544, (char *)"CamelRoutingInfo", 27568, 3, 1, 0, 12, 856, 12, 0},
    {-1, 8124, 8544, (char *)"CamelRoutingInfo", 27568, 3, 1, 0, 12, 856, 12, 0},
    {-1, 966, 8558, (char *)"ExtendedRoutingInfo", 27576, 2, 2, 8, 8, 859, 13, 0},
    {8, 1348, 0, (char *)"GeographicalInformation", 2, 0, 2, 2, 24, 0, 21, 0},
    {10, 1348, 0, (char *)"LocationNumber", 2, 0, 2, 2, 24, 0, 21, 0},
    {3, 1348, 0, (char *)"LSAIdentity", 2, 0, 2, 2, 24, 0, 21, 0},
    {10, 1348, 0, (char *)"GeodeticInformation", 2, 0, 2, 2, 24, 0, 21, 0},
    {8, 7900, 0, (char *)"GeographicalInformation", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 7902, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {10, 7910, 0, (char *)"LocationNumber", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2107, 967, (char *)"CellGlobalIdOrServiceAreaIdOrLAI", 12, 2, 2, 2, 8, 738, 13, 0},
    {-1, 7914, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {3, 7916, 0, (char *)"LSAIdentity", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 7976, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {10, 8122, 0, (char *)"GeodeticInformation", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 8124, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 8126, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {5, 2, 8565, (char *)"LocationInformation", 592, 11, 2, 0, 2076, 861, 12, 0},
    {3, 1395, 0, (char *)"NotReachableReason", 4, 0, 4, 0, 24, 311, 58, 0},
    {-1, 7900, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 7902, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 7910, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 966, 8719, (char *)"SubscriberState", 8, 4, 2, 4, 8, 872, 13, 0},
    {6, 1348, 0, (char *)"RAIdentity", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7900, 967, (char *)"CellGlobalIdOrServiceAreaIdOrLAI", 12, 2, 2, 2, 8, 738, 13, 0},
    {6, 7902, 0, (char *)"RAIdentity", 2, 0, 2, 2, 24, 0, 21, 0},
    {8, 7910, 0, (char *)"GeographicalInformation", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 2107, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {3, 7914, 0, (char *)"LSAIdentity", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7916, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 7976, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {10, 8122, 0, (char *)"GeodeticInformation", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 8124, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 8126, 0, (char *)"AgeOfLocationInformation", 2, 0, 2, 0, 8, 0, 55, 0},
    {4, 2, 8728, (char *)"LocationInformationGPRS", 584, 10, 2, 0, 2076, 876, 12, 0},
    {-1, 8106, 0, (char *)"ContextId", 2, 0, 2, 0, 8, 0, 55, 0},
    {2, 1348, 0, (char *)"PDP-Type", 2, 0, 2, 2, 24, 0, 21, 0},
    {16, 1348, 0, (char *)"PDP-Address", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 8106, 0, (char *)"NSAPI", 2, 0, 2, 0, 8, 0, 55, 0},
    {2, 1348, 0, (char *)"TransactionId", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 1348, 0, (char *)"TEID", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 1348, 0, (char *)"Ext-QoS-Subscribed", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 1348, 0, (char *)"GPRSChargingID", 2, 0, 2, 2, 24, 0, 21, 0},
    {2, 1348, 0, (char *)"ChargingCharacteristics", 2, 0, 2, 2, 24, 0, 21, 0},
    {3, 1348, 0, (char *)"Ext2-QoS-Subscribed", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7900, 0, (char *)"ContextId", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 7902, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {2, 7910, 0, (char *)"PDP-Type", 2, 0, 2, 2, 24, 0, 21, 0},
    {16, 2107, 0, (char *)"PDP-Address", 2, 0, 2, 2, 24, 0, 21, 0},
    {63, 7914, 0, (char *)"APN", 2, 0, 2, 2, 24, 0, 21, 0},
    {63, 7916, 0, (char *)"APN", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7976, 0, (char *)"NSAPI", 2, 0, 2, 0, 8, 0, 55, 0},
    {2, 8122, 0, (char *)"TransactionId", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 8124, 0, (char *)"TEID", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 8126, 0, (char *)"TEID", 2, 0, 2, 2, 24, 0, 21, 0},
    {17, 8128, 0, (char *)"GSN-Address", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 8130, 0, (char *)"Ext-QoS-Subscribed", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 8132, 0, (char *)"Ext-QoS-Subscribed", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 8134, 0, (char *)"Ext-QoS-Subscribed", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 8136, 0, (char *)"GPRSChargingID", 2, 0, 2, 2, 24, 0, 21, 0},
    {2, 8138, 0, (char *)"ChargingCharacteristics", 2, 0, 2, 2, 24, 0, 21, 0},
    {17, 8312, 0, (char *)"GSN-Address", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 8154, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {3, 8156, 0, (char *)"Ext2-QoS-Subscribed", 2, 0, 2, 2, 24, 0, 21, 0},
    {3, 8158, 0, (char *)"Ext2-QoS-Subscribed", 2, 0, 2, 2, 24, 0, 21, 0},
    {3, 8314, 0, (char *)"Ext2-QoS-Subscribed", 2, 0, 2, 2, 24, 0, 21, 0},
    {3, 2, 8858, (char *)"PDP-ContextInfo", 800, 21, 4, 0, 2076, 886, 12, 0},
    {50, 2, 0, (char *)"PDP-ContextInfoList", 2, 800, 2, 8, 24, 646, 17, 0},
    {-1, 7900, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 7902, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 7910, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2107, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {50, 7914, 0, (char *)"PDP-ContextInfoList", 2, 800, 2, 8, 24, 646, 17, 0},
    {50, 7916, 0, (char *)"PDP-ContextInfoList", 2, 800, 2, 8, 24, 646, 17, 0},
    {-1, 966, 9250, (char *)"PS-SubscriberState", 40016, 7, 2, 8, 8, 907, 13, 0},
    {3, 1348, 0, (char *)"MS-Classmark2", 2, 0, 2, 2, 24, 0, 21, 0},
    {8, 1348, 0, (char *)"MSNetworkCapability", 2, 0, 2, 2, 24, 0, 21, 0},
    {50, 1348, 0, (char *)"MSRadioAccessCapability", 2, 0, 2, 2, 24, 0, 21, 0},
    {8, 7900, 0, (char *)"MSNetworkCapability", 2, 0, 2, 2, 24, 0, 21, 0},
    {50, 7902, 0, (char *)"MSRadioAccessCapability", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2, 3491, (char *)"GPRSMSClass", 64, 2, 1, 0, 8, 914, 12, 0},
    {5, 1348, 0, (char *)"RouteingNumber", 2, 0, 2, 2, 24, 0, 21, 0},
    {INT_MAX, 1395, 0, (char *)"NumberPortabilityStatus", 4, 0, 4, 0, 2076, 317, 58, 0},
    {5, 7900, 0, (char *)"RouteingNumber", 2, 0, 2, 2, 24, 0, 21, 0},
    {8, 7902, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 7910, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {INT_MAX, 2107, 0, (char *)"NumberPortabilityStatus", 4, 0, 4, 0, 2076, 317, 58, 0},
    {-1, 7914, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 2, 8504, (char *)"MNPInfoRes", 544, 5, 1, 0, 12, 916, 12, 0},
    {5, 7900, 8565, (char *)"LocationInformation", 592, 11, 2, 0, 2076, 861, 12, 0},
    {-1, 7902, 8719, (char *)"SubscriberState", 8, 4, 2, 4, 8, 872, 13, 0},
    {-1, 7910, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {4, 2107, 8728, (char *)"LocationInformationGPRS", 584, 10, 2, 0, 2076, 876, 12, 0},
    {-1, 7914, 9250, (char *)"PS-SubscriberState", 40016, 7, 2, 8, 8, 907, 13, 0},
    {8, 7916, 0, (char *)"IMEI", 2, 0, 2, 2, 24, 0, 21, 0},
    {3, 7976, 0, (char *)"MS-Classmark2", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 8122, 3491, (char *)"GPRSMSClass", 64, 2, 1, 0, 8, 914, 12, 0},
    {-1, 8124, 8504, (char *)"MNPInfoRes", 544, 5, 1, 0, 12, 916, 12, 0},
    {6, 2, 9265, (char *)"SubscriberInfo", 42336, 9, 2, 0, 2076, 921, 12, 0},
    {30, 2, 0, (char *)"SS-List", 2, 4, 2, 2, 24, 385, 17, 0},
    {-1, 7900, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 7902, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 7910, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 2, 9373, (char *)"CCBS-Indicators", 512, 3, 1, 0, 12, 930, 12, 0},
    {-1, 8106, 0, (char *)"IST-AlertTimerValue", 2, 0, 2, 0, 8, 0, 55, 0},
    {8, 7912, 0, (char *)"AllowedServices", 1, 0, 2, 0, 24, 327, 1, 0},
    {INT_MAX, 1395, 0, (char *)"UnavailabilityCause", 4, 0, 4, 0, 2076, 331, 58, 0},
    {8, 8126, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2107, 7530, (char *)"CUG-CheckInfo", 520, 3, 1, 0, 12, 794, 12, 0},
    {-1, 7976, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {6, 8122, 9265, (char *)"SubscriberInfo", 42336, 9, 2, 0, 2076, 921, 12, 0},
    {30, 7902, 0, (char *)"SS-List", 2, 4, 2, 2, 24, 385, 17, 0},
    {-1, 7916, 8205, (char *)"Ext-BasicServiceCode", 10, 2, 2, 2, 8, 771, 13, 0},
    {-1, 7914, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {9, 7910, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7900, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 8128, 3491, (char *)"NAEA-PreferredCI", 512, 2, 1, 0, 12, 767, 12, 0},
    {-1, 8130, 9373, (char *)"CCBS-Indicators", 512, 3, 1, 0, 12, 930, 12, 0},
    {9, 8132, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {INT_MAX, 8134, 0, (char *)"NumberPortabilityStatus", 4, 0, 4, 0, 2076, 317, 58, 0},
    {-1, 8136, 0, (char *)"IST-AlertTimerValue", 2, 0, 2, 0, 8, 0, 55, 0},
    {16, 8138, 0, (char *)"SupportedCamelPhases", 2, 0, 2, 0, 24, 255, 1, 0},
    {16, 8312, 0, (char *)"OfferedCamel4CSIs", 2, 0, 2, 0, 24, 261, 1, 0},
    {-1, 8154, 8200, (char *)"RoutingInfo", 584, 2, 2, 8, 8, 806, 13, 0},
    {30, 8156, 0, (char *)"SS-List", 2, 4, 2, 2, 24, 385, 17, 0},
    {-1, 8158, 8205, (char *)"Ext-BasicServiceCode", 10, 2, 2, 2, 8, 771, 13, 0},
    {8, 8314, 0, (char *)"AllowedServices", 1, 0, 2, 0, 24, 327, 1, 0},
    {INT_MAX, 8316, 0, (char *)"UnavailabilityCause", 4, 0, 4, 0, 2076, 331, 58, 0},
    {-1, 8318, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 8320, 8188, (char *)"ExternalSignalInfo", 720, 3, 1, 0, 12, 754, 12, 0},
    {8, 7900, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 7902, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 7910, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 7914, 0, (char *)"LMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7916, 8188, (char *)"ExternalSignalInfo", 720, 3, 1, 0, 12, 754, 12, 0},
    {-1, 7976, 8188, (char *)"ExternalSignalInfo", 720, 3, 1, 0, 12, 754, 12, 0},
    {-1, 8122, 0, (char *)"SuppressionOfAnnouncement", 1, 0, 0, 0, 8, 0, 5, 0},
    {9, 8124, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {8, 8126, 0, (char *)"CallReferenceNumber", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 8128, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 8130, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {1, 8132, 0, (char *)"AlertingPattern", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 8134, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {16, 8138, 0, (char *)"SupportedCamelPhases", 2, 0, 2, 0, 24, 255, 1, 0},
    {-1, 8136, 8188, (char *)"Ext-ExternalSignalInfo", 720, 3, 1, 0, 12, 757, 12, 0},
    {-1, 8312, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 8154, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 8156, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 8158, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {16, 8314, 0, (char *)"OfferedCamel4CSIs", 2, 0, 2, 0, 24, 261, 1, 0},
    {1, 1348, 0, (char *)"UUIndicator", 2, 0, 2, 2, 24, 0, 21, 0},
    {131, 1348, 0, (char *)"UUI", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 7900, 0, (char *)"UUIndicator", 2, 0, 2, 2, 24, 0, 21, 0},
    {131, 7902, 0, (char *)"UUI", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7910, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2107, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 2, 3403, (char *)"UU-Data", 648, 4, 1, 0, 12, 933, 12, 0},
    {8, 7900, 0, (char *)"CallReferenceNumber", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7902, 8205, (char *)"Ext-BasicServiceCode", 10, 2, 2, 2, 8, 771, 13, 0},
    {1, 7910, 8334, (char *)"ForwardingData", 576, 5, 1, 0, 2076, 801, 12, 0},
    {8, 2107, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7914, 7530, (char *)"CUG-CheckInfo", 520, 3, 1, 0, 12, 794, 12, 0},
    {3, 7916, 8394, (char *)"O-CSI", 5888, 5, 1, 0, 2076, 823, 12, 0},
    {-1, 8122, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 8124, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {9, 8126, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 8128, 3403, (char *)"UU-Data", 648, 4, 1, 0, 12, 933, 12, 0},
    {-1, 8130, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 8132, 8504, (char *)"D-CSI", 5976, 5, 1, 0, 12, 845, 12, 0},
    {10, 8134, 0, (char *)"O-BcsmCamelTDPCriteriaList", 2, 736, 2, 8, 24, 556, 17, 0},
    {-1, 8136, 8205, (char *)"Ext-BasicServiceCode", 10, 2, 2, 2, 8, 771, 13, 0},
    {INT_MAX, 1395, 0, (char *)"ReportingState", 4, 0, 4, 0, 2076, 342, 58, 0},
    {8, 7900, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 7902, 0, (char *)"LMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {INT_MAX, 7910, 0, (char *)"ReportingState", 4, 0, 4, 0, 2076, 342, 58, 0},
    {-1, 2107, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {INT_MAX, 1395, 0, (char *)"CCBS-SubscriberStatus", 4, 0, 4, 0, 2076, 349, 58, 0},
    {INT_MAX, 7900, 0, (char *)"CCBS-SubscriberStatus", 4, 0, 4, 0, 2076, 349, 58, 0},
    {-1, 7902, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {INT_MAX, 7900, 0, (char *)"CCBS-SubscriberStatus", 4, 0, 4, 0, 2076, 349, 58, 0},
    {-1, 7902, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 2, 1459, (char *)"EventReportData", 512, 2, 1, 0, 12, 937, 12, 0},
    {INT_MAX, 1395, 0, (char *)"MonitoringMode", 4, 0, 4, 0, 2076, 357, 58, 0},
    {INT_MAX, 1395, 0, (char *)"CallOutcome", 4, 0, 4, 0, 2076, 364, 58, 0},
    {INT_MAX, 7900, 0, (char *)"MonitoringMode", 4, 0, 4, 0, 2076, 357, 58, 0},
    {INT_MAX, 7902, 0, (char *)"CallOutcome", 4, 0, 4, 0, 2076, 364, 58, 0},
    {-1, 7910, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 2, 9373, (char *)"CallReportData", 520, 3, 1, 0, 12, 939, 12, 0},
    {8, 7900, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7902, 1459, (char *)"EventReportData", 512, 2, 1, 0, 12, 937, 12, 0},
    {-1, 7910, 9373, (char *)"CallReportData", 520, 3, 1, 0, 12, 939, 12, 0},
    {-1, 2107, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 7900, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 8106, 0, (char *)"CCBS-Index", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 7900, 0, (char *)"CCBS-Index", 2, 0, 2, 0, 8, 0, 55, 0},
    {9, 7902, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {21, 7910, 0, (char *)"ISDN-SubaddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2107, 8205, (char *)"BasicServiceCode", 6, 2, 2, 2, 8, 769, 13, 0},
    {-1, 2, 3403, (char *)"CCBS-Feature", 46, 4, 1, 0, 12, 942, 12, 0},
    {8, 7900, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7902, 8188, (char *)"ExternalSignalInfo", 720, 3, 1, 0, 12, 754, 12, 0},
    {-1, 7910, 3403, (char *)"CCBS-Feature", 46, 4, 1, 0, 12, 942, 12, 0},
    {9, 2107, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7914, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {1, 7916, 0, (char *)"AlertingPattern", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7976, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {INT_MAX, 1395, 0, (char *)"RUF-Outcome", 4, 0, 4, 0, 2076, 372, 58, 0},
    {INT_MAX, 7900, 0, (char *)"RUF-Outcome", 4, 0, 4, 0, 2076, 372, 58, 0},
    {-1, 7902, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {8, 7900, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7902, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {INT_MAX, 1395, 0, (char *)"CallTerminationIndicator", 4, 0, 4, 0, 2076, 383, 58, 0},
    {-1, 7900, 0, (char *)"IST-AlertTimerValue", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 7902, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {INT_MAX, 7910, 0, (char *)"CallTerminationIndicator", 4, 0, 4, 0, 2076, 383, 58, 0},
    {-1, 2107, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {8, 7900, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7902, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 8106, 0, (char *)"NoReplyConditionTime", 2, 0, 2, 0, 8, 0, 55, 0},
    {20, 7914, 0, (char *)"AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {21, 7976, 0, (char *)"ISDN-SubaddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7916, 0, (char *)"NoReplyConditionTime", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 8122, 0, (char *)"EMLPP-Priority", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 8124, 0, (char *)"MC-Bearers", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 8126, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {1, 7914, 0, (char *)"SS-Status", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 7916, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {21, 8124, 0, (char *)"ISDN-SubaddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 7976, 0, (char *)"ForwardingOptions", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 8122, 0, (char *)"NoReplyConditionTime", 2, 0, 2, 0, 8, 0, 55, 0},
    {15, 8126, 0, (char *)"FTN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 2, 9391, (char *)"ForwardingFeature", 72, 7, 1, 0, 2076, 946, 12, 0},
    {13, 2, 0, (char *)"ForwardingFeatureList", 2, 72, 2, 2, 24, 811, 17, 0},
    {-1, 2, 3734, (char *)"ForwardingInfo", 944, 2, 1, 0, 12, 953, 12, 0},
    {1, 7914, 0, (char *)"SS-Status", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2, 9463, (char *)"CallBarringFeature", 12, 2, 1, 0, 12, 955, 12, 0},
    {13, 2, 0, (char *)"CallBarringFeatureList", 2, 12, 2, 2, 24, 815, 17, 0},
    {-1, 2, 3734, (char *)"CallBarringInfo", 164, 2, 1, 0, 12, 957, 12, 0},
    {2, 1395, 0, (char *)"CliRestrictionOption", 4, 0, 4, 0, 24, 390, 58, 0},
    {1, 1395, 0, (char *)"OverrideCategory", 4, 0, 4, 0, 24, 395, 58, 0},
    {2, 7910, 0, (char *)"CliRestrictionOption", 4, 0, 4, 0, 24, 390, 58, 0},
    {1, 7902, 0, (char *)"OverrideCategory", 4, 0, 4, 0, 24, 395, 58, 0},
    {-1, 966, 9475, (char *)"SS-SubscriptionOption", 8, 2, 2, 4, 8, 959, 13, 0},
    {13, 2, 0, (char *)"BasicServiceGroupList", 2, 6, 2, 2, 24, 377, 17, 0},
    {1, 7914, 0, (char *)"SS-Status", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7916, 0, (char *)"MC-Bearers", 2, 0, 2, 0, 8, 0, 55, 0},
    {2, 2, 9480, (char *)"SS-Data", 104, 6, 1, 0, 2076, 961, 12, 0},
    {-1, 7900, 3734, (char *)"ForwardingInfo", 944, 2, 1, 0, 12, 953, 12, 0},
    {-1, 7902, 3734, (char *)"CallBarringInfo", 164, 2, 1, 0, 12, 957, 12, 0},
    {2, 2107, 9480, (char *)"SS-Data", 104, 6, 1, 0, 2076, 961, 12, 0},
    {-1, 966, 9540, (char *)"SS-Info", 948, 3, 2, 4, 8, 967, 13, 0},
    {-1, 7914, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {1, 2, 9547, (char *)"SS-ForBS-Code", 14, 3, 1, 0, 2076, 970, 12, 0},
    {5, 2, 0, (char *)"CCBS-FeatureList", 2, 46, 2, 2, 24, 778, 17, 0},
    {-1, 7900, 0, (char *)"EMLPP-Priority", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 7902, 0, (char *)"EMLPP-Priority", 2, 0, 2, 0, 8, 0, 55, 0},
    {5, 7910, 0, (char *)"CCBS-FeatureList", 2, 46, 2, 2, 24, 778, 17, 0},
    {-1, 2107, 0, (char *)"MaxMC-Bearers", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 7914, 0, (char *)"MC-Bearers", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 7916, 0, (char *)"MC-Bearers", 2, 0, 2, 0, 8, 0, 55, 0},
    {6, 2, 9563, (char *)"GenericServiceInfo", 256, 8, 1, 0, 2076, 973, 12, 0},
    {1, 7900, 0, (char *)"SS-Status", 2, 0, 2, 2, 24, 0, 21, 0},
    {13, 7910, 0, (char *)"BasicServiceGroupList", 2, 6, 2, 2, 24, 377, 17, 0},
    {13, 2107, 0, (char *)"ForwardingFeatureList", 2, 72, 2, 2, 24, 811, 17, 0},
    {6, 7914, 9563, (char *)"GenericServiceInfo", 256, 8, 1, 0, 2076, 973, 12, 0},
    {160, 1348, 0, (char *)"USSD-String", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 7900, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {5, 9637, 18, (char *)"Password", 1, 0, 2, 0, 16408, 0, 24, 0},
    {2, 2, 0, (char *)"SS-EventSpecification", 2, 22, 2, 2, 24, 206, 17, 0},
    {6, 1395, 0, (char *)"CCBS-RequestState", 4, 0, 4, 0, 24, 399, 58, 0},
    {8, 7900, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 7902, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 7910, 0, (char *)"SS-Code", 2, 0, 2, 2, 24, 0, 21, 0},
    {2, 2107, 0, (char *)"SS-EventSpecification", 2, 22, 2, 2, 24, 206, 17, 0},
    {-1, 7914, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {9, 7916, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {6, 7976, 0, (char *)"CCBS-RequestState", 4, 0, 4, 0, 24, 399, 58, 0},
    {32, 7912, 0, (char *)"ServiceIndicator", 4, 0, 2, 0, 24, 408, 1, 0},
    {-1, 7900, 3403, (char *)"CCBS-Feature", 46, 4, 1, 0, 12, 942, 12, 0},
    {9, 7902, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {32, 7910, 0, (char *)"ServiceIndicator", 4, 0, 2, 0, 24, 408, 1, 0},
    {-1, 2107, 8188, (char *)"ExternalSignalInfo", 720, 3, 1, 0, 12, 754, 12, 0},
    {-1, 7914, 8188, (char *)"ExternalSignalInfo", 720, 3, 1, 0, 12, 754, 12, 0},
    {-1, 2, 9639, (char *)"CCBS-Data", 1504, 5, 1, 0, 12, 981, 12, 0},
    {1, 7900, 0, (char *)"SS-Code", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7902, 9639, (char *)"CCBS-Data", 1504, 5, 1, 0, 12, 981, 12, 0},
    {-1, 7900, 3403, (char *)"CCBS-Feature", 46, 4, 1, 0, 12, 942, 12, 0},
    {1, 7900, 0, (char *)"SS-Code", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7902, 0, (char *)"CCBS-Index", 2, 0, 2, 0, 8, 0, 55, 0},
    {1, 7900, 0, (char *)"SS-Code", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 7902, 0, (char *)"SS-Status", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 8106, 0, (char *)"SM-RP-MTI", 2, 0, 2, 0, 8, 0, 55, 0},
    {12, 1348, 0, (char *)"SM-RP-SMEA", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 7900, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7902, 0, NULL, 1, 0, 0, 0, 8, 0, 8, 0},
    {20, 7910, 0, (char *)"AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7976, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 8122, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 8124, 0, (char *)"SM-RP-MTI", 2, 0, 2, 0, 8, 0, 55, 0},
    {12, 8126, 0, (char *)"SM-RP-SMEA", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 7902, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7916, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 7976, 967, (char *)"Additional-Number", 14, 2, 2, 2, 8, 695, 13, 0},
    {2, 2, 9661, (char *)"LocationInfoWithLMSI", 544, 5, 1, 0, 2076, 986, 12, 0},
    {2, 7900, 9661, (char *)"LocationInfoWithLMSI", 544, 5, 1, 0, 2076, 986, 12, 0},
    {-1, 7914, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {8, 7900, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 7902, 0, (char *)"LMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {20, 7914, 0, (char *)"AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7916, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 966, 9693, (char *)"SM-RP-DA", 24, 4, 2, 2, 8, 991, 13, 0},
    {9, 7910, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {20, 7914, 0, (char *)"AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7916, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 966, 9702, (char *)"SM-RP-OA", 24, 3, 2, 2, 8, 995, 13, 0},
    {2, 1395, 0, (char *)"SM-DeliveryOutcome", 4, 0, 4, 0, 24, 412, 58, 0},
    {-1, 7900, 0, (char *)"AbsentSubscriberDiagnosticSM", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 7902, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 7910, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2107, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {2, 7914, 0, (char *)"SM-DeliveryOutcome", 4, 0, 4, 0, 24, 412, 58, 0},
    {-1, 7916, 0, (char *)"AbsentSubscriberDiagnosticSM", 2, 0, 2, 0, 8, 0, 55, 0},
    {16, 7912, 0, (char *)"MW-Status", 2, 0, 2, 0, 24, 417, 1, 0},
    {-1, 7900, 0, (char *)"AbsentSubscriberDiagnosticSM", 2, 0, 2, 0, 8, 0, 55, 0},
    {1, 1395, 0, (char *)"AlertReason", 4, 0, 4, 0, 24, 423, 58, 0},
    {8, 7900, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {5, 2, 0, (char *)"DispatcherList", 2, 12, 2, 2, 24, 161, 17, 0},
    {200, 7900, 0, (char *)"SignalInfo", 2, 0, 2, 2, 24, 0, 21, 0},
    {5, 7902, 0, (char *)"DispatcherList", 2, 12, 2, 2, 24, 161, 17, 0},
    {-1, 7910, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {2, 1348, 0, (char *)"TraceReference", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 8106, 0, (char *)"TraceType", 2, 0, 2, 0, 8, 0, 55, 0},
    {3, 1348, 0, (char *)"TraceReference2", 2, 0, 2, 2, 24, 0, 21, 0},
    {INT_MAX, 1395, 0, (char *)"TraceDepth", 4, 0, 4, 0, 2076, 427, 58, 0},
    {INT_MAX, 7900, 0, (char *)"TraceDepth", 4, 0, 4, 0, 2076, 427, 58, 0},
    {INT_MAX, 7902, 0, (char *)"TraceDepth", 4, 0, 4, 0, 2076, 427, 58, 0},
    {INT_MAX, 7910, 0, (char *)"TraceDepth", 4, 0, 4, 0, 2076, 427, 58, 0},
    {INT_MAX, 2107, 0, (char *)"TraceDepth", 4, 0, 4, 0, 2076, 427, 58, 0},
    {INT_MAX, 7914, 0, (char *)"TraceDepth", 4, 0, 4, 0, 2076, 427, 58, 0},
    {INT_MAX, 7916, 0, (char *)"TraceDepth", 4, 0, 4, 0, 2076, 427, 58, 0},
    {-1, 2, 8052, (char *)"TraceDepthList", 28, 6, 1, 0, 12, 998, 12, 0},
    {16, 7912, 0, (char *)"TraceNE-TypeList", 2, 0, 2, 0, 24, 435, 1, 0},
    {16, 7912, 0, (char *)"MSC-S-InterfaceList", 2, 0, 2, 0, 24, 443, 1, 0},
    {8, 7912, 0, (char *)"MGW-InterfaceList", 1, 0, 2, 0, 24, 455, 1, 0},
    {16, 7912, 0, (char *)"SGSN-InterfaceList", 2, 0, 2, 0, 24, 460, 1, 0},
    {8, 7912, 0, (char *)"GGSN-InterfaceList", 1, 0, 2, 0, 24, 470, 1, 0},
    {8, 7912, 0, (char *)"RNC-InterfaceList", 1, 0, 2, 0, 24, 475, 1, 0},
    {8, 7912, 0, (char *)"BMSC-InterfaceList", 1, 0, 2, 0, 24, 481, 1, 0},
    {16, 7900, 0, (char *)"MSC-S-InterfaceList", 2, 0, 2, 0, 24, 443, 1, 0},
    {8, 7902, 0, (char *)"MGW-InterfaceList", 1, 0, 2, 0, 24, 455, 1, 0},
    {16, 7910, 0, (char *)"SGSN-InterfaceList", 2, 0, 2, 0, 24, 460, 1, 0},
    {8, 2107, 0, (char *)"GGSN-InterfaceList", 1, 0, 2, 0, 24, 470, 1, 0},
    {8, 7914, 0, (char *)"RNC-InterfaceList", 1, 0, 2, 0, 24, 475, 1, 0},
    {8, 7916, 0, (char *)"BMSC-InterfaceList", 1, 0, 2, 0, 24, 481, 1, 0},
    {-1, 2, 8052, (char *)"TraceInterfaceList", 12, 6, 1, 0, 12, 1004, 12, 0},
    {16, 7912, 0, (char *)"MSC-S-EventList", 2, 0, 2, 0, 24, 484, 1, 0},
    {8, 7912, 0, (char *)"MGW-EventList", 1, 0, 2, 0, 24, 491, 1, 0},
    {16, 7912, 0, (char *)"SGSN-EventList", 2, 0, 2, 0, 24, 494, 1, 0},
    {8, 7912, 0, (char *)"GGSN-EventList", 1, 0, 2, 0, 24, 500, 1, 0},
    {8, 7912, 0, (char *)"BMSC-EventList", 1, 0, 2, 0, 24, 504, 1, 0},
    {16, 7900, 0, (char *)"MSC-S-EventList", 2, 0, 2, 0, 24, 484, 1, 0},
    {8, 7902, 0, (char *)"MGW-EventList", 1, 0, 2, 0, 24, 491, 1, 0},
    {16, 7910, 0, (char *)"SGSN-EventList", 2, 0, 2, 0, 24, 494, 1, 0},
    {8, 2107, 0, (char *)"GGSN-EventList", 1, 0, 2, 0, 24, 500, 1, 0},
    {8, 7914, 0, (char *)"BMSC-EventList", 1, 0, 2, 0, 24, 504, 1, 0},
    {-1, 2, 8504, (char *)"TraceEventList", 10, 5, 1, 0, 12, 1010, 12, 0},
    {8, 7900, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {2, 7902, 0, (char *)"TraceReference", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7910, 0, (char *)"TraceType", 2, 0, 2, 0, 8, 0, 55, 0},
    {20, 2107, 0, (char *)"AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7914, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {3, 7916, 0, (char *)"TraceReference2", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7976, 8052, (char *)"TraceDepthList", 28, 6, 1, 0, 12, 998, 12, 0},
    {16, 8122, 0, (char *)"TraceNE-TypeList", 2, 0, 2, 0, 24, 435, 1, 0},
    {-1, 8124, 8052, (char *)"TraceInterfaceList", 12, 6, 1, 0, 12, 1004, 12, 0},
    {-1, 8126, 8504, (char *)"TraceEventList", 10, 5, 1, 0, 12, 1010, 12, 0},
    {16, 1348, 0, (char *)"TracePropagationParameters", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7900, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 7902, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {8, 7900, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {2, 7902, 0, (char *)"TraceReference", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7910, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {3, 2107, 0, (char *)"TraceReference2", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7900, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {6, 1348, 0, (char *)"AgeIndicator", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7900, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {6, 7902, 0, (char *)"AgeIndicator", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 966, 967, (char *)"SuperChargerInfo", 10, 2, 2, 2, 8, 1015, 13, 0},
    {16, 7900, 0, (char *)"SupportedCamelPhases", 2, 0, 2, 0, 24, 255, 1, 0},
    {-1, 7910, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {INT_MAX, 7902, 0, (char *)"IST-SupportIndicator", 4, 0, 4, 0, 2076, 270, 58, 0},
    {-1, 2107, 967, (char *)"SuperChargerInfo", 10, 2, 2, 2, 8, 1015, 13, 0},
    {-1, 7914, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {16, 7916, 0, (char *)"SupportedLCS-CapabilitySets", 2, 0, 2, 0, 24, 11, 1, 0},
    {16, 7976, 0, (char *)"OfferedCamel4CSIs", 2, 0, 2, 0, 24, 261, 1, 0},
    {8, 8122, 0, NULL, 1, 0, 2, 0, 24, 507, 1, 0},
    {-1, 8124, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {8, 2, 9709, (char *)"VLR-Capability", 544, 10, 2, 0, 2076, 1017, 12, 0},
    {8, 7900, 0, (char *)"IMEI", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7902, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2, 3491, (char *)"ADD-Info", 14, 2, 1, 0, 12, 1027, 12, 0},
    {9, 7902, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 8128, 0, (char *)"LMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {8, 7976, 9709, (char *)"VLR-Capability", 544, 10, 2, 0, 2076, 1017, 12, 0},
    {-1, 8130, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 8132, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {17, 7910, 0, (char *)"GSN-Address", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 8134, 3491, (char *)"ADD-Info", 14, 2, 1, 0, 12, 1027, 12, 0},
    {INT_MAX, 1395, 0, (char *)"CancellationType", 4, 0, 4, 0, 2076, 511, 58, 0},
    {9, 7900, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 7902, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7900, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 7902, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 8106, 0, (char *)"NumberOfRequestedVectors", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 8106, 0, (char *)"HopCounter", 2, 0, 2, 0, 8, 0, 55, 0},
    {5, 7900, 0, (char *)"LAIFixedLength", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7902, 0, (char *)"HopCounter", 2, 0, 2, 0, 8, 0, 55, 0},
    {16, 1348, 0, (char *)"RAND", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 1348, 0, (char *)"SRES", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2, 9839, (char *)"AuthenticationTriplet", 34, 3, 0, 0, 12, 1029, 12, 0},
    {5, 2, 0, (char *)"TripletList", 2, 34, 2, 2, 24, 999, 17, 0},
    {16, 1348, 0, (char *)"XRES", 2, 0, 2, 2, 24, 0, 21, 0},
    {16, 1348, 0, (char *)"CK", 2, 0, 2, 2, 24, 0, 21, 0},
    {16, 1348, 0, (char *)"IK", 2, 0, 2, 2, 24, 0, 21, 0},
    {16, 1348, 0, (char *)"AUTN", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2, 9851, (char *)"AuthenticationQuintuplet", 90, 5, 0, 0, 12, 1032, 12, 0},
    {5, 2, 0, (char *)"QuintupletList", 2, 90, 2, 2, 24, 1005, 17, 0},
    {5, 7900, 0, (char *)"TripletList", 2, 34, 2, 2, 24, 999, 17, 0},
    {5, 7902, 0, (char *)"QuintupletList", 2, 90, 2, 2, 24, 1005, 17, 0},
    {-1, 966, 967, (char *)"AuthenticationSetList", 454, 2, 2, 2, 8, 1037, 13, 0},
    {1, 1348, 0, (char *)"Cksn", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2, 3602, (char *)"GSM-SecurityContextData", 14, 2, 0, 0, 12, 1039, 12, 0},
    {1, 1348, 0, (char *)"KSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2, 9839, (char *)"UMTS-SecurityContextData", 40, 3, 0, 0, 12, 1041, 12, 0},
    {-1, 7900, 3602, (char *)"GSM-SecurityContextData", 14, 2, 0, 0, 12, 1039, 12, 0},
    {-1, 7902, 9839, (char *)"UMTS-SecurityContextData", 40, 3, 0, 0, 12, 1041, 12, 0},
    {-1, 966, 967, (char *)"CurrentSecurityContext", 42, 2, 2, 2, 8, 1044, 13, 0},
    {-1, 7910, 967, (char *)"CurrentSecurityContext", 42, 2, 2, 2, 8, 1044, 13, 0},
    {-1, 2107, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {14, 1348, 0, (char *)"AUTS", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 1395, 0, (char *)"FailureCause", 4, 0, 4, 0, 24, 518, 58, 0},
    {INT_MAX, 1395, 0, (char *)"AccessType", 4, 0, 4, 0, 2076, 522, 58, 0},
    {-1, 9871, 0, NULL, 1, 0, 0, 0, 8, 0, 8, 0},
    {9, 7900, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 7902, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7902, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 7910, 967, (char *)"SuperChargerInfo", 10, 2, 2, 2, 8, 1015, 13, 0},
    {-1, 2107, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {16, 7914, 0, (char *)"SupportedCamelPhases", 2, 0, 2, 0, 24, 255, 1, 0},
    {16, 7916, 0, (char *)"SupportedLCS-CapabilitySets", 2, 0, 2, 0, 24, 11, 1, 0},
    {16, 7976, 0, (char *)"OfferedCamel4CSIs", 2, 0, 2, 0, 24, 261, 1, 0},
    {-1, 8122, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {8, 8124, 0, NULL, 1, 0, 2, 0, 24, 507, 1, 0},
    {7, 2, 9873, (char *)"SGSN-Capability", 536, 9, 2, 0, 2076, 1046, 12, 0},
    {7, 7900, 9873, (char *)"SGSN-Capability", 536, 9, 2, 0, 2076, 1046, 12, 0},
    {-1, 7902, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 7910, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {17, 2107, 0, (char *)"GSN-Address", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7914, 3491, (char *)"ADD-Info", 14, 2, 1, 0, 12, 1027, 12, 0},
    {100, 1348, 0, (char *)"IntegrityProtectionInformation", 2, 0, 2, 2, 24, 0, 21, 0},
    {100, 1348, 0, (char *)"EncryptionInformation", 2, 0, 2, 2, 24, 0, 21, 0},
    {INT_MAX, 1395, 0, (char *)"KeyStatus", 4, 0, 4, 0, 2076, 538, 58, 0},
    {1, 1348, 0, (char *)"AllowedGSM-Algorithms", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 1348, 0, (char *)"PermittedIntegrityProtectionAlgorithms", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 1348, 0, (char *)"PermittedEncryptionAlgorithms", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 7900, 0, (char *)"PermittedIntegrityProtectionAlgorithms", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 7902, 0, (char *)"PermittedEncryptionAlgorithms", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7910, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 2, 9373, (char *)"AllowedUMTS-Algorithms", 536, 3, 1, 0, 12, 1055, 12, 0},
    {13, 1348, 0, (char *)"RadioResourceInformation", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 8106, 0, (char *)"RAB-Id", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 2, 9981, (char *)"RadioResource", 18, 2, 0, 0, 12, 1058, 12, 0},
    {7, 2, 0, (char *)"RadioResourceList", 2, 18, 2, 2, 24, 1051, 17, 0},
    {1, 1348, 0, (char *)"BSSMAP-ServiceHandover", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 1348, 0, (char *)"RANAP-ServiceHandover", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2, 9981, (char *)"BSSMAP-ServiceHandoverInfo", 6, 2, 0, 0, 12, 1060, 12, 0},
    {7, 2, 0, (char *)"BSSMAP-ServiceHandoverList", 2, 6, 2, 2, 24, 1055, 17, 0},
    {4, 1348, 0, (char *)"Codec", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 7902, 0, (char *)"Codec", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 7910, 0, (char *)"Codec", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 2107, 0, (char *)"Codec", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 7914, 0, (char *)"Codec", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 7916, 0, (char *)"Codec", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 7976, 0, (char *)"Codec", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 8122, 0, (char *)"Codec", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 8124, 0, (char *)"Codec", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 8126, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 2, 9989, (char *)"CodecList", 560, 9, 1, 0, 12, 1062, 12, 0},
    {-1, 7900, 9989, (char *)"CodecList", 560, 9, 1, 0, 12, 1062, 12, 0},
    {-1, 7902, 9989, (char *)"CodecList", 560, 9, 1, 0, 12, 1062, 12, 0},
    {-1, 7910, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 2, 9373, (char *)"SupportedCodecsList", 1632, 3, 1, 0, 12, 1071, 12, 0},
    {100, 7900, 0, (char *)"IntegrityProtectionInformation", 2, 0, 2, 2, 24, 0, 21, 0},
    {100, 7902, 0, (char *)"EncryptionInformation", 2, 0, 2, 2, 24, 0, 21, 0},
    {INT_MAX, 7910, 0, (char *)"KeyStatus", 4, 0, 4, 0, 2076, 538, 58, 0},
    {1, 7914, 0, (char *)"AllowedGSM-Algorithms", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7916, 9373, (char *)"AllowedUMTS-Algorithms", 536, 3, 1, 0, 12, 1055, 12, 0},
    {13, 7976, 0, (char *)"RadioResourceInformation", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2107, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {7, 8122, 0, (char *)"RadioResourceList", 2, 18, 2, 2, 24, 1051, 17, 0},
    {1, 8126, 0, (char *)"BSSMAP-ServiceHandover", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 8124, 0, (char *)"RANAP-ServiceHandover", 2, 0, 2, 2, 24, 0, 21, 0},
    {7, 8128, 0, (char *)"BSSMAP-ServiceHandoverList", 2, 6, 2, 2, 24, 1055, 17, 0},
    {4, 8130, 0, (char *)"Codec", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 8132, 9373, (char *)"SupportedCodecsList", 1632, 3, 1, 0, 12, 1071, 12, 0},
    {-1, 8134, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {4, 8136, 0, (char *)"Codec", 2, 0, 2, 2, 24, 0, 21, 0},
    {13, 8138, 0, (char *)"RadioResourceInformation", 2, 0, 2, 2, 24, 0, 21, 0},
    {3, 8312, 0, (char *)"TraceReference2", 2, 0, 2, 2, 24, 0, 21, 0},
    {16, 8154, 0, (char *)"TracePropagationParameters", 2, 0, 2, 2, 24, 0, 21, 0},
    {7, 1348, 0, (char *)"RNCId", 2, 0, 2, 2, 24, 0, 21, 0},
    {87, 1348, 0, (char *)"GERAN-Classmark", 2, 0, 2, 2, 24, 0, 21, 0},
    {128, 7912, 0, (char *)"UESBI-IuA", 16, 0, 2, 8, 24, 0, 3, 0},
    {128, 7912, 0, (char *)"UESBI-IuB", 16, 0, 2, 8, 24, 0, 3, 0},
    {128, 7900, 0, (char *)"UESBI-IuA", 16, 0, 2, 8, 24, 0, 3, 0},
    {128, 7902, 0, (char *)"UESBI-IuB", 16, 0, 2, 8, 24, 0, 3, 0},
    {-1, 2, 1459, (char *)"UESBI-Iu", 40, 2, 1, 0, 12, 1074, 12, 0},
    {7, 7900, 0, (char *)"GlobalCellId", 2, 0, 2, 2, 24, 0, 21, 0},
    {7, 7902, 0, (char *)"RNCId", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7910, 8188, (char *)"AccessNetworkSignalInfo", 3080, 3, 1, 0, 12, 760, 12, 0},
    {-1, 2107, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {8, 7914, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {100, 7916, 0, (char *)"IntegrityProtectionInformation", 2, 0, 2, 2, 24, 0, 21, 0},
    {100, 7976, 0, (char *)"EncryptionInformation", 2, 0, 2, 2, 24, 0, 21, 0},
    {13, 8122, 0, (char *)"RadioResourceInformation", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 8126, 0, (char *)"AllowedGSM-Algorithms", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 8128, 9373, (char *)"AllowedUMTS-Algorithms", 536, 3, 1, 0, 12, 1055, 12, 0},
    {7, 8130, 0, (char *)"RadioResourceList", 2, 18, 2, 2, 24, 1051, 17, 0},
    {-1, 8124, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 8132, 0, (char *)"RAB-Id", 2, 0, 2, 0, 8, 0, 55, 0},
    {1, 8134, 0, (char *)"BSSMAP-ServiceHandover", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 8136, 0, (char *)"RANAP-ServiceHandover", 2, 0, 2, 2, 24, 0, 21, 0},
    {7, 8138, 0, (char *)"BSSMAP-ServiceHandoverList", 2, 6, 2, 2, 24, 1055, 17, 0},
    {8, 8314, 0, (char *)"ASCI-CallReference", 2, 0, 2, 2, 24, 0, 21, 0},
    {87, 8312, 0, (char *)"GERAN-Classmark", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 8154, 0, (char *)"Codec", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 8156, 9373, (char *)"SupportedCodecsList", 1632, 3, 1, 0, 12, 1071, 12, 0},
    {-1, 8158, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 8316, 1459, (char *)"UESBI-Iu", 40, 2, 1, 0, 12, 1074, 12, 0},
    {8, 8318, 0, (char *)"IMEI", 2, 0, 2, 2, 24, 0, 21, 0},
    {13, 8320, 0, (char *)"RadioResourceInformation", 2, 0, 2, 2, 24, 0, 21, 0},
    {3, 8322, 0, (char *)"TraceReference2", 2, 0, 2, 2, 24, 0, 21, 0},
    {16, 8324, 0, (char *)"TracePropagationParameters", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2, 9981, (char *)"RelocationNumber", 14, 2, 0, 0, 12, 1076, 12, 0},
    {7, 2, 0, (char *)"RelocationNumberList", 2, 14, 2, 2, 24, 1123, 17, 0},
    {-1, 8106, 0, (char *)"MulticallBearerInfo", 2, 0, 2, 0, 8, 0, 55, 0},
    {1, 1348, 0, (char *)"ChosenIntegrityProtectionAlgorithm", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 1348, 0, (char *)"ChosenEncryptionAlgorithm", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 7900, 0, (char *)"ChosenIntegrityProtectionAlgorithm", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 7902, 0, (char *)"ChosenEncryptionAlgorithm", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7910, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 2, 9373, (char *)"SelectedUMTS-Algorithms", 520, 3, 1, 0, 12, 1078, 12, 0},
    {1, 1348, 0, (char *)"ChosenChannelInfo", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 1348, 0, (char *)"ChosenSpeechVersion", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 7900, 0, (char *)"ChosenChannelInfo", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 7902, 0, (char *)"ChosenSpeechVersion", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2, 1459, (char *)"ChosenRadioResourceInformation", 10, 2, 1, 0, 12, 1081, 12, 0},
    {9, 7900, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {7, 7902, 0, (char *)"RelocationNumberList", 2, 14, 2, 2, 24, 1123, 17, 0},
    {-1, 7910, 8188, (char *)"AccessNetworkSignalInfo", 3080, 3, 1, 0, 12, 760, 12, 0},
    {-1, 2107, 0, (char *)"MulticallBearerInfo", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 7916, 9373, (char *)"SelectedUMTS-Algorithms", 520, 3, 1, 0, 12, 1078, 12, 0},
    {-1, 7976, 1459, (char *)"ChosenRadioResourceInformation", 10, 2, 1, 0, 12, 1081, 12, 0},
    {-1, 7914, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {4, 8122, 0, (char *)"Codec", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 8124, 9989, (char *)"CodecList", 560, 9, 1, 0, 12, 1062, 12, 0},
    {7, 7900, 0, (char *)"GlobalCellId", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 7902, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {7, 7910, 0, (char *)"RNCId", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2107, 8188, (char *)"AccessNetworkSignalInfo", 3080, 3, 1, 0, 12, 760, 12, 0},
    {-1, 7914, 0, (char *)"RAB-Id", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 7916, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {87, 7976, 0, (char *)"GERAN-Classmark", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 8122, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 7900, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {1, 1348, 0, (char *)"SelectedGSM-Algorithm", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7902, 9373, (char *)"SelectedUMTS-Algorithms", 520, 3, 1, 0, 12, 1078, 12, 0},
    {1, 7910, 0, (char *)"SelectedGSM-Algorithm", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2107, 1459, (char *)"ChosenRadioResourceInformation", 10, 2, 1, 0, 12, 1081, 12, 0},
    {-1, 7914, 0, (char *)"RAB-Id", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 7900, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {4, 7916, 0, (char *)"Codec", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7976, 9989, (char *)"CodecList", 560, 9, 1, 0, 12, 1062, 12, 0},
    {-1, 7900, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 7900, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 2, 3602, (char *)"Re-synchronisationInfo", 34, 2, 0, 0, 12, 1083, 12, 0},
    {INT_MAX, 1395, 0, (char *)"RequestingNodeType", 4, 0, 4, 0, 2076, 545, 58, 0},
    {3, 1348, 0, (char *)"PLMN-Id", 2, 0, 2, 2, 24, 0, 21, 0},
    {8, 7900, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7902, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 7910, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {INT_MAX, 2107, 0, (char *)"RequestingNodeType", 4, 0, 4, 0, 2076, 545, 58, 0},
    {3, 7914, 0, (char *)"PLMN-Id", 2, 0, 2, 2, 24, 0, 21, 0},
    {8, 7912, 0, (char *)"RequestedEquipmentInfo", 1, 0, 2, 0, 24, 552, 1, 0},
    {2, 1395, 0, (char *)"EquipmentStatus", 4, 0, 4, 0, 24, 556, 58, 0},
    {-1, 7900, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {1, 1348, 0, (char *)"Category", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 1395, 0, (char *)"SubscriberStatus", 4, 0, 4, 0, 24, 561, 58, 0},
    {50, 2, 0, (char *)"BearerServiceList", 2, 8, 2, 2, 24, 378, 17, 0},
    {20, 2, 0, (char *)"TeleserviceList", 2, 8, 2, 2, 24, 379, 17, 0},
    {5, 1348, 0, (char *)"Ext-ForwOptions", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 8106, 0, (char *)"Ext-NoRepCondTime", 2, 0, 2, 0, 8, 0, 55, 0},
    {5, 7914, 0, (char *)"Ext-SS-Status", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 7916, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {21, 8124, 0, (char *)"ISDN-SubaddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {5, 7976, 0, (char *)"Ext-ForwOptions", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 8122, 0, (char *)"Ext-NoRepCondTime", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 8126, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {15, 8128, 0, (char *)"FTN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 2, 10081, (char *)"Ext-ForwFeature", 600, 8, 1, 0, 2076, 1085, 12, 0},
    {32, 2, 0, (char *)"Ext-ForwFeatureList", 2, 600, 2, 8, 24, 1189, 17, 0},
    {-1, 7900, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 2, 10147, (char *)"Ext-ForwInfo", 19720, 3, 1, 0, 12, 1093, 12, 0},
    {5, 7914, 0, (char *)"Ext-SS-Status", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2, 10159, (char *)"Ext-CallBarringFeature", 528, 3, 1, 0, 12, 1096, 12, 0},
    {32, 2, 0, (char *)"Ext-CallBarFeatureList", 2, 528, 2, 8, 24, 1194, 17, 0},
    {-1, 2, 10175, (char *)"Ext-CallBarInfo", 17416, 3, 1, 0, 12, 1099, 12, 0},
    {-1, 8106, 0, (char *)"CUG-Index", 2, 0, 2, 0, 8, 0, 55, 0},
    {2, 1395, 0, (char *)"IntraCUG-Options", 4, 0, 4, 0, 24, 565, 58, 0},
    {32, 2, 0, (char *)"Ext-BasicServiceGroupList", 2, 10, 2, 2, 24, 382, 17, 0},
    {-1, 7900, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 2, 10187, (char *)"CUG-Subscription", 848, 5, 1, 0, 12, 1102, 12, 0},
    {10, 2, 0, (char *)"CUG-SubscriptionList", 2, 848, 2, 8, 24, 1201, 17, 0},
    {1, 1348, 0, (char *)"InterCUG-Restrictions", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2, 10209, (char *)"CUG-Feature", 528, 4, 1, 0, 12, 1107, 12, 0},
    {32, 2, 0, (char *)"CUG-FeatureList", 2, 528, 2, 8, 24, 1204, 17, 0},
    {-1, 7900, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 2, 10233, (char *)"CUG-Info", 25904, 3, 1, 0, 12, 1111, 12, 0},
    {5, 7914, 0, (char *)"Ext-SS-Status", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7916, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 2, 10247, (char *)"Ext-SS-Data", 856, 5, 1, 0, 12, 1114, 12, 0},
    {-1, 7900, 10147, (char *)"Ext-ForwInfo", 19720, 3, 1, 0, 12, 1093, 12, 0},
    {-1, 7902, 10175, (char *)"Ext-CallBarInfo", 17416, 3, 1, 0, 12, 1099, 12, 0},
    {-1, 7910, 10233, (char *)"CUG-Info", 25904, 3, 1, 0, 12, 1111, 12, 0},
    {-1, 2107, 10247, (char *)"Ext-SS-Data", 856, 5, 1, 0, 12, 1114, 12, 0},
    {-1, 7914, 8210, (char *)"EMLPP-Info", 512, 3, 1, 0, 12, 773, 12, 0},
    {-1, 966, 10275, (char *)"Ext-SS-Info", 25912, 5, 2, 8, 8, 1119, 13, 0},
    {30, 2, 0, (char *)"Ext-SS-InfoList", 2, 25912, 2, 8, 24, 1216, 17, 0},
    {32, 7912, 0, (char *)"ODB-GeneralData", 4, 0, 2, 0, 24, 570, 1, 0},
    {32, 7912, 0, (char *)"ODB-HPLMN-Data", 4, 0, 2, 0, 24, 601, 1, 0},
    {-1, 2, 10286, (char *)"ODB-Data", 520, 3, 1, 0, 12, 1124, 12, 0},
    {2, 1348, 0, (char *)"ZoneCode", 2, 0, 2, 2, 24, 0, 21, 0},
    {10, 2, 0, (char *)"ZoneCodeList", 2, 4, 2, 2, 24, 1221, 17, 0},
    {3, 1348, 0, (char *)"GroupId", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2, 7530, (char *)"VoiceBroadcastData", 520, 3, 1, 0, 12, 1127, 12, 0},
    {50, 2, 0, (char *)"VBSDataList", 2, 520, 2, 8, 24, 1224, 17, 0},
    {8, 7912, 0, (char *)"AdditionalSubscriptions", 1, 0, 2, 0, 24, 607, 1, 0},
    {4, 1348, 0, (char *)"Long-GroupId", 2, 0, 2, 2, 24, 0, 21, 0},
    {136, 7900, 0, (char *)"AdditionalInfo", 16, 0, 2, 8, 24, 0, 3, 0},
    {4, 7902, 0, (char *)"Long-GroupId", 2, 0, 2, 2, 24, 0, 21, 0},
    {3, 2, 10300, (char *)"VoiceGroupCallData", 544, 5, 1, 0, 2076, 1130, 12, 0},
    {50, 2, 0, (char *)"VGCSDataList", 2, 544, 2, 8, 24, 1230, 17, 0},
    {10, 2, 0, (char *)"SS-EventList", 2, 4, 2, 2, 24, 385, 17, 0},
    {-1, 7900, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 2, 10332, (char *)"SS-CamelData", 560, 3, 1, 0, 12, 1135, 12, 0},
    {-1, 7900, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 7902, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {2, 2, 10344, (char *)"SS-CSI", 1080, 4, 1, 0, 2076, 1138, 12, 0},
    {1, 1348, 0, (char *)"MM-Code", 2, 0, 2, 2, 24, 0, 21, 0},
    {10, 2, 0, (char *)"MobilityTriggers", 2, 4, 2, 2, 24, 1238, 17, 0},
    {9, 7900, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7902, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 7910, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2107, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2, 10366, (char *)"M-CSI", 576, 6, 1, 0, 12, 1142, 12, 0},
    {INT_MAX, 1395, 0, (char *)"SMS-TriggerDetectionPoint", 4, 0, 4, 0, 2076, 612, 58, 0},
    {INT_MAX, 1395, 0, (char *)"DefaultSMS-Handling", 4, 0, 4, 0, 2076, 619, 58, 0},
    {INT_MAX, 7900, 0, (char *)"SMS-TriggerDetectionPoint", 4, 0, 4, 0, 2076, 612, 58, 0},
    {-1, 7902, 0, (char *)"ServiceKey", 4, 0, 4, 0, 8, 0, 55, 0},
    {9, 7910, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {INT_MAX, 2107, 0, (char *)"DefaultSMS-Handling", 4, 0, 4, 0, 2076, 619, 58, 0},
    {-1, 7914, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 2, 8222, (char *)"SMS-CAMEL-TDP-Data", 536, 5, 1, 0, 12, 1148, 12, 0},
    {10, 2, 0, (char *)"SMS-CAMEL-TDP-DataList", 2, 536, 2, 8, 24, 1252, 17, 0},
    {10, 7900, 0, (char *)"SMS-CAMEL-TDP-DataList", 2, 536, 2, 8, 24, 1252, 17, 0},
    {-1, 7902, 0, (char *)"CamelCapabilityHandling", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 7910, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 2107, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 7914, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2, 8504, (char *)"SMS-CSI", 5896, 5, 1, 0, 12, 1153, 12, 0},
    {INT_MAX, 1395, 0, (char *)"MT-SMS-TPDU-Type", 4, 0, 4, 0, 2076, 626, 58, 0},
    {5, 2, 0, (char *)"TPDU-TypeCriterion", 2, 4, 2, 4, 24, 1260, 17, 0},
    {5, 7900, 0, (char *)"TPDU-TypeCriterion", 2, 4, 2, 4, 24, 1260, 17, 0},
    {-1, 2, 10396, (char *)"MT-smsCAMELTDP-Criteria", 32, 2, 1, 0, 12, 1158, 12, 0},
    {10, 2, 0, (char *)"MT-smsCAMELTDP-CriteriaList", 2, 32, 2, 4, 24, 1263, 17, 0},
    {3, 7900, 8394, (char *)"O-CSI", 5888, 5, 1, 0, 2076, 823, 12, 0},
    {-1, 7902, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {2, 7910, 10344, (char *)"SS-CSI", 1080, 4, 1, 0, 2076, 1138, 12, 0},
    {10, 7914, 0, (char *)"O-BcsmCamelTDPCriteriaList", 2, 736, 2, 8, 24, 556, 17, 0},
    {-1, 2107, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 7916, 10366, (char *)"M-CSI", 576, 6, 1, 0, 12, 1142, 12, 0},
    {-1, 7976, 8504, (char *)"SMS-CSI", 5896, 5, 1, 0, 12, 1153, 12, 0},
    {3, 8122, 8394, (char *)"T-CSI", 5888, 5, 1, 0, 2076, 813, 12, 0},
    {10, 8124, 0, (char *)"T-BCSM-CAMEL-TDP-CriteriaList", 2, 84, 2, 4, 24, 561, 17, 0},
    {-1, 8126, 8504, (char *)"D-CSI", 5976, 5, 1, 0, 12, 845, 12, 0},
    {-1, 8128, 8504, (char *)"SMS-CSI", 5896, 5, 1, 0, 12, 1153, 12, 0},
    {10, 8130, 0, (char *)"MT-smsCAMELTDP-CriteriaList", 2, 32, 2, 4, 24, 1263, 17, 0},
    {10, 2, 10404, (char *)"VlrCamelSubscriptionInfo", 40264, 12, 2, 0, 2076, 1160, 12, 0},
    {3, 1348, 0, (char *)"QoS-Subscribed", 2, 0, 2, 2, 24, 0, 21, 0},
    {2, 8312, 0, (char *)"PDP-Type", 2, 0, 2, 2, 24, 0, 21, 0},
    {16, 8154, 0, (char *)"PDP-Address", 2, 0, 2, 2, 24, 0, 21, 0},
    {3, 8156, 0, (char *)"QoS-Subscribed", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 8158, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {63, 8314, 0, (char *)"APN", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 8316, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {9, 7900, 0, (char *)"Ext-QoS-Subscribed", 2, 0, 2, 2, 24, 0, 21, 0},
    {2, 7902, 0, (char *)"ChargingCharacteristics", 2, 0, 2, 2, 24, 0, 21, 0},
    {3, 7910, 0, (char *)"Ext2-QoS-Subscribed", 2, 0, 2, 2, 24, 0, 21, 0},
    {3, 2, 10584, (char *)"PDP-Context", 632, 10, 1, 0, 2076, 1172, 12, 0},
    {50, 2, 0, (char *)"GPRSDataList", 2, 632, 2, 8, 24, 1288, 17, 0},
    {50, 7902, 0, (char *)"GPRSDataList", 2, 632, 2, 8, 24, 1288, 17, 0},
    {-1, 7910, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 2, 10640, (char *)"GPRSSubscriptionData", 32120, 3, 1, 0, 12, 1182, 12, 0},
    {INT_MAX, 1395, 0, (char *)"NetworkAccessMode", 4, 0, 4, 0, 2076, 634, 58, 0},
    {1, 1395, 0, (char *)"LSAOnlyAccessIndicator", 4, 0, 4, 0, 24, 642, 58, 0},
    {1, 1348, 0, (char *)"LSAAttributes", 2, 0, 2, 2, 24, 0, 21, 0},
    {3, 7900, 0, (char *)"LSAIdentity", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 7902, 0, (char *)"LSAAttributes", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7910, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2107, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 2, 7490, (char *)"LSAData", 520, 4, 1, 0, 12, 1185, 12, 0},
    {20, 2, 0, (char *)"LSADataList", 2, 520, 2, 8, 24, 1300, 17, 0},
    {1, 7902, 0, (char *)"LSAOnlyAccessIndicator", 4, 0, 4, 0, 24, 642, 58, 0},
    {20, 7910, 0, (char *)"LSADataList", 2, 520, 2, 8, 24, 1300, 17, 0},
    {-1, 2107, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 2, 10654, (char *)"LSAInformation", 10920, 4, 1, 0, 12, 1189, 12, 0},
    {5, 2, 0, (char *)"GMLC-List", 2, 12, 2, 2, 24, 161, 17, 0},
    {INT_MAX, 1395, 0, (char *)"NotificationToMSUser", 4, 0, 4, 0, 2076, 646, 58, 0},
    {INT_MAX, 1395, 0, (char *)"GMLC-Restriction", 4, 0, 4, 0, 2076, 655, 58, 0},
    {INT_MAX, 7900, 0, (char *)"GMLC-Restriction", 4, 0, 4, 0, 2076, 655, 58, 0},
    {INT_MAX, 7902, 0, (char *)"NotificationToMSUser", 4, 0, 4, 0, 2076, 646, 58, 0},
    {-1, 7910, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 2, 10682, (char *)"ExternalClient", 1040, 4, 1, 0, 12, 1193, 12, 0},
    {5, 2, 0, (char *)"ExternalClientList", 2, 1040, 2, 8, 24, 1312, 17, 0},
    {5, 2, 0, (char *)"PLMNClientList", 2, 4, 2, 4, 24, 207, 17, 0},
    {35, 2, 0, (char *)"Ext-ExternalClientList", 2, 1040, 2, 8, 24, 1312, 17, 0},
    {INT_MAX, 7900, 0, (char *)"GMLC-Restriction", 4, 0, 4, 0, 2076, 655, 58, 0},
    {INT_MAX, 7902, 0, (char *)"NotificationToMSUser", 4, 0, 4, 0, 2076, 646, 58, 0},
    {-1, 7910, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 2, 10704, (char *)"ServiceType", 520, 4, 1, 0, 12, 1197, 12, 0},
    {32, 2, 0, (char *)"ServiceTypeList", 2, 520, 2, 8, 24, 1319, 17, 0},
    {INT_MAX, 7900, 0, (char *)"NotificationToMSUser", 4, 0, 4, 0, 2076, 646, 58, 0},
    {5, 7902, 0, (char *)"ExternalClientList", 2, 1040, 2, 8, 24, 1312, 17, 0},
    {5, 7910, 0, (char *)"PLMNClientList", 2, 4, 2, 4, 24, 207, 17, 0},
    {-1, 2107, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {35, 7914, 0, (char *)"Ext-ExternalClientList", 2, 1040, 2, 8, 24, 1312, 17, 0},
    {32, 7916, 0, (char *)"ServiceTypeList", 2, 520, 2, 8, 24, 1319, 17, 0},
    {2, 2, 10726, (char *)"LCS-PrivacyClass", 58816, 8, 1, 0, 2076, 1201, 12, 0},
    {4, 2, 0, (char *)"LCS-PrivacyExceptionList", 2, 58816, 2, 8, 24, 1327, 17, 0},
    {-1, 7900, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 2, 10788, (char *)"MOLR-Class", 520, 3, 1, 0, 12, 1209, 12, 0},
    {3, 2, 0, (char *)"MOLR-List", 2, 520, 2, 8, 24, 1330, 17, 0},
    {5, 7900, 0, (char *)"GMLC-List", 2, 12, 2, 2, 24, 161, 17, 0},
    {4, 7902, 0, (char *)"LCS-PrivacyExceptionList", 2, 58816, 2, 8, 24, 1327, 17, 0},
    {3, 7910, 0, (char *)"MOLR-List", 2, 520, 2, 8, 24, 1330, 17, 0},
    {4, 2107, 0, (char *)"LCS-PrivacyExceptionList", 2, 58816, 2, 8, 24, 1327, 17, 0},
    {1, 2, 3403, (char *)"LCSInformation", 472176, 4, 1, 0, 2076, 1212, 12, 0},
    {1, 1348, 0, (char *)"CS-AllocationRetentionPriority", 2, 0, 2, 2, 24, 0, 21, 0},
    {INT_MAX, 1395, 0, (char *)"GPRS-TriggerDetectionPoint", 4, 0, 4, 0, 2076, 662, 58, 0},
    {INT_MAX, 1395, 0, (char *)"DefaultGPRS-Handling", 4, 0, 4, 0, 2076, 619, 58, 0},
    {INT_MAX, 7900, 0, (char *)"GPRS-TriggerDetectionPoint", 4, 0, 4, 0, 2076, 662, 58, 0},
    {-1, 7902, 0, (char *)"ServiceKey", 4, 0, 4, 0, 8, 0, 55, 0},
    {9, 7910, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {INT_MAX, 2107, 0, (char *)"DefaultGPRS-Handling", 4, 0, 4, 0, 2076, 619, 58, 0},
    {-1, 7914, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 2, 8222, (char *)"GPRS-CamelTDPData", 536, 5, 1, 0, 12, 1216, 12, 0},
    {10, 2, 0, (char *)"GPRS-CamelTDPDataList", 2, 536, 2, 8, 24, 1345, 17, 0},
    {10, 7900, 0, (char *)"GPRS-CamelTDPDataList", 2, 536, 2, 8, 24, 1345, 17, 0},
    {-1, 7902, 0, (char *)"CamelCapabilityHandling", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 7910, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 2107, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 7914, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2, 8504, (char *)"GPRS-CSI", 5896, 5, 1, 0, 12, 1221, 12, 0},
    {9, 7900, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7902, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 7910, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2107, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2, 10366, (char *)"MG-CSI", 576, 6, 1, 0, 12, 1226, 12, 0},
    {-1, 7900, 8504, (char *)"GPRS-CSI", 5896, 5, 1, 0, 12, 1221, 12, 0},
    {-1, 7902, 8504, (char *)"SMS-CSI", 5896, 5, 1, 0, 12, 1153, 12, 0},
    {-1, 7910, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 2107, 8504, (char *)"SMS-CSI", 5896, 5, 1, 0, 12, 1153, 12, 0},
    {10, 7914, 0, (char *)"MT-smsCAMELTDP-CriteriaList", 2, 32, 2, 4, 24, 1263, 17, 0},
    {-1, 7916, 10366, (char *)"MG-CSI", 576, 6, 1, 0, 12, 1226, 12, 0},
    {3, 2, 8052, (char *)"SGSN-CAMEL-SubscriptionInfo", 19104, 6, 1, 0, 2076, 1232, 12, 0},
    {8, 7912, 0, (char *)"AccessRestrictionData", 1, 0, 2, 0, 24, 672, 1, 0},
    {8, 7900, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 7902, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 7910, 0, (char *)"Category", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 2107, 0, (char *)"SubscriberStatus", 4, 0, 4, 0, 24, 561, 58, 0},
    {50, 7914, 0, (char *)"BearerServiceList", 2, 8, 2, 2, 24, 378, 17, 0},
    {20, 7976, 0, (char *)"TeleserviceList", 2, 8, 2, 2, 24, 379, 17, 0},
    {30, 8122, 0, (char *)"Ext-SS-InfoList", 2, 25912, 2, 8, 24, 1216, 17, 0},
    {-1, 8124, 10286, (char *)"ODB-Data", 520, 3, 1, 0, 12, 1124, 12, 0},
    {-1, 8126, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {10, 8128, 0, (char *)"ZoneCodeList", 2, 4, 2, 2, 24, 1221, 17, 0},
    {50, 8130, 0, (char *)"VBSDataList", 2, 520, 2, 8, 24, 1224, 17, 0},
    {50, 8132, 0, (char *)"VGCSDataList", 2, 544, 2, 8, 24, 1230, 17, 0},
    {10, 8134, 10404, (char *)"VlrCamelSubscriptionInfo", 40264, 12, 2, 0, 2076, 1160, 12, 0},
    {-1, 8136, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 8138, 3491, (char *)"NAEA-PreferredCI", 512, 2, 1, 0, 12, 767, 12, 0},
    {-1, 8312, 10640, (char *)"GPRSSubscriptionData", 32120, 3, 1, 0, 12, 1182, 12, 0},
    {-1, 8320, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {INT_MAX, 8322, 0, (char *)"NetworkAccessMode", 4, 0, 4, 0, 2076, 634, 58, 0},
    {-1, 8324, 10654, (char *)"LSAInformation", 10920, 4, 1, 0, 12, 1189, 12, 0},
    {-1, 8316, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {1, 8318, 3403, (char *)"LCSInformation", 472176, 4, 1, 0, 2076, 1212, 12, 0},
    {-1, 8326, 0, (char *)"IST-AlertTimerValue", 2, 0, 2, 0, 8, 0, 55, 0},
    {6, 8328, 0, (char *)"AgeIndicator", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 8330, 8222, (char *)"MC-SS-Info", 528, 5, 1, 0, 12, 776, 12, 0},
    {1, 8332, 0, (char *)"CS-AllocationRetentionPriority", 2, 0, 2, 2, 24, 0, 21, 0},
    {3, 8154, 8052, (char *)"SGSN-CAMEL-SubscriptionInfo", 19104, 6, 1, 0, 2076, 1232, 12, 0},
    {2, 8156, 0, (char *)"ChargingCharacteristics", 2, 0, 2, 2, 24, 0, 21, 0},
    {8, 8158, 0, (char *)"AccessRestrictionData", 1, 0, 2, 0, 24, 672, 1, 0},
    {-1, 8314, 0, NULL, 1, 0, 0, 0, 8, 0, 8, 0},
    {100, 7900, 0, (char *)"_octet5", 2, 0, 2, 2, 56, 0, 21, 0},
    {-1, 7910, 0, NULL, 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 7900, 0, NULL, 4, 0, 4, 0, 8, 0, 0, 0},
    {-1, 7902, 0, NULL, 4, 0, 4, 0, 8, 0, 0, 0},
    {-1, 7910, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 2107, 4, (char *)"_seq6", 520, 3, 1, 0, 44, 1238, 12, 0},
    {-1, 8106, 0, NULL, 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 7900, 0, NULL, 2, 0, 2, 0, 8, 0, 55, 0},
    {1, 7902, 0, (char *)"_octet1", 2, 0, 2, 2, 56, 0, 21, 0},
    {16, 7910, 0, (char *)"_octet2", 2, 0, 2, 2, 56, 0, 21, 0},
    {63, 2107, 0, (char *)"_octet3", 2, 0, 2, 2, 56, 0, 21, 0},
    {-1, 7900, 0, NULL, 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 7900, 0, NULL, 4, 0, 4, 0, 8, 0, 0, 0},
    {-1, 7902, 0, NULL, 1, 0, 0, 0, 8, 0, 8, 0},
    {-1, 7910, 0, NULL, 1, 0, 0, 0, 8, 0, 8, 0},
    {-1, 2107, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 7902, 3431, (char *)"_seq1", 520, 4, 1, 0, 44, 1241, 12, 0},
    {-1, 7910, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 7914, 4, (char *)"_seq3", 1032, 3, 1, 0, 44, 1245, 12, 0},
    {16, 7900, 0, (char *)"", 2, 0, 2, 2, 56, 0, 21, 0},
    {16, 7902, 0, (char *)"", 2, 0, 2, 2, 56, 0, 21, 0},
    {100, 7910, 0, (char *)"", 2, 0, 2, 2, 56, 0, 21, 0},
    {-1, 2107, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 7916, 3403, (char *)"_seq4", 648, 4, 1, 0, 44, 1248, 12, 0},
    {1, 7976, 0, (char *)"_enum1", 4, 0, 4, 0, 56, 676, 58, 0},
    {-1, 8122, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {2, 8124, 0, (char *)"_octet4", 2, 0, 2, 2, 56, 0, 21, 0},
    {-1, 7900, 0, NULL, 4, 0, 4, 0, 8, 0, 0, 0},
    {-1, 7902, 0, NULL, 4, 0, 4, 0, 8, 0, 0, 0},
    {-1, 7910, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 8126, 4, (char *)"", 520, 3, 1, 0, 44, 1252, 12, 0},
    {63, 7900, 0, (char *)"", 2, 0, 2, 2, 56, 0, 21, 0},
    {16, 7900, 0, (char *)"", 2, 0, 2, 2, 56, 0, 21, 0},
    {16, 7902, 0, (char *)"", 2, 0, 2, 2, 56, 0, 21, 0},
    {100, 7910, 0, (char *)"", 2, 0, 2, 2, 56, 0, 21, 0},
    {-1, 2107, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 7902, 3403, (char *)"", 648, 4, 1, 0, 44, 1255, 12, 0},
    {-1, 7910, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 2, 4, (char *)"_seq2", 1224, 3, 1, 0, 44, 1259, 12, 0},
    {50, 8128, 0, (char *)"_seqof1", 2, 1224, 2, 8, 56, 1433, 17, 0},
    {-1, 8130, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {16, 8132, 0, (char *)"", 2, 0, 2, 2, 56, 0, 21, 0},
    {-1, 2, 10800, (char *)"_seq5", 64048, 13, 2, 0, 44, 1262, 12, 0},
    {50, 7902, 0, (char *)"_seqof2", 2, 64048, 2, 8, 56, 1437, 17, 0},
    {-1, 7910, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 7914, 10910, (char *)"_seq7", 3202920, 4, 1, 0, 44, 1275, 12, 0},
    {9, 7976, 0, (char *)"_octet6", 2, 0, 2, 2, 56, 0, 21, 0},
    {-1, 7916, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 10928, 10930, (char *)"_seq9", 3204072, 6, 1, 0, 44, 1279, 12, 0},
    {27, 7912, 0, (char *)"_bit1", 16, 0, 2, 8, 56, 0, 3, 0},
    {4, 1348, 0, (char *)"_octet7", 2, 0, 2, 2, 56, 0, 21, 0},
    {-1, 2, 10984, (char *)"_seq8", 536, 3, 1, 0, 44, 1285, 12, 0},
    {50, 10998, 0, (char *)"_seqof3", 2, 536, 2, 8, 56, 1446, 17, 0},
    {-1, 11000, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {3, 1395, 0, (char *)"RegionalSubscriptionResponse", 4, 0, 4, 0, 24, 680, 58, 0},
    {20, 7902, 0, (char *)"TeleserviceList", 2, 8, 2, 2, 24, 379, 17, 0},
    {50, 7910, 0, (char *)"BearerServiceList", 2, 8, 2, 2, 24, 378, 17, 0},
    {30, 2107, 0, (char *)"SS-List", 2, 4, 2, 2, 24, 385, 17, 0},
    {32, 7914, 0, (char *)"ODB-GeneralData", 4, 0, 2, 0, 24, 570, 1, 0},
    {3, 7916, 0, (char *)"RegionalSubscriptionResponse", 4, 0, 4, 0, 24, 680, 58, 0},
    {16, 7976, 0, (char *)"SupportedCamelPhases", 2, 0, 2, 0, 24, 255, 1, 0},
    {-1, 8122, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {16, 8124, 0, (char *)"OfferedCamel4CSIs", 2, 0, 2, 0, 24, 261, 1, 0},
    {70, 2, 0, (char *)"BasicServiceList", 2, 10, 2, 2, 24, 382, 17, 0},
    {50, 2, 0, (char *)"ContextIdList", 2, 2, 2, 2, 24, 615, 17, 0},
    {-1, 966, 11002, (char *)"GPRSSubscriptionDataWithdraw", 104, 2, 2, 2, 8, 1288, 13, 0},
    {20, 2, 0, (char *)"LSAIdentityList", 2, 6, 2, 2, 24, 585, 17, 0},
    {-1, 966, 11002, (char *)"LSAInformationWithdraw", 124, 2, 2, 2, 8, 1290, 13, 0},
    {32, 7912, 0, (char *)"SpecificCSI-Withdraw", 4, 0, 2, 0, 24, 686, 1, 0},
    {8, 7900, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {70, 7902, 0, (char *)"BasicServiceList", 2, 10, 2, 2, 24, 382, 17, 0},
    {30, 7910, 0, (char *)"SS-List", 2, 4, 2, 2, 24, 385, 17, 0},
    {-1, 7914, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {2, 7916, 0, (char *)"ZoneCode", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 8122, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 8124, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 8126, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 7976, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 8128, 11002, (char *)"GPRSSubscriptionDataWithdraw", 104, 2, 2, 2, 8, 1288, 13, 0},
    {-1, 8130, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 8132, 11002, (char *)"LSAInformationWithdraw", 124, 2, 2, 2, 8, 1290, 13, 0},
    {-1, 8134, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 8136, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {32, 8138, 0, (char *)"SpecificCSI-Withdraw", 4, 0, 2, 0, 24, 686, 1, 0},
    {-1, 8312, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {3, 7900, 0, (char *)"RegionalSubscriptionResponse", 4, 0, 4, 0, 24, 680, 58, 0},
    {64, 7912, 0, (char *)"OfferedCamel4Functionalities", 8, 0, 2, 0, 24, 702, 2, 0},
    {8, 7900, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {17, 7902, 0, (char *)"GSN-Address", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 7910, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2107, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {17, 7900, 0, (char *)"GSN-Address", 2, 0, 2, 2, 24, 0, 21, 0},
    {17, 7902, 0, (char *)"GSN-Address", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7910, 0, (char *)"AbsentSubscriberDiagnosticSM", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 2107, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {8, 7900, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 7902, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {17, 7910, 0, (char *)"GSN-Address", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2107, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {17, 7900, 0, (char *)"GSN-Address", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7902, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {8, 7900, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {17, 7902, 0, (char *)"GSN-Address", 2, 0, 2, 2, 24, 0, 21, 0},
    {17, 7910, 0, (char *)"GSN-Address", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2107, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 7900, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {8, 7976, 9709, (char *)"VLR-Capability", 544, 10, 2, 0, 2076, 1017, 12, 0},
    {INT_MAX, 1395, 0, (char *)"DomainType", 4, 0, 4, 0, 2076, 724, 58, 0},
    {-1, 7900, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 7902, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 7910, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 2107, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {INT_MAX, 7914, 0, (char *)"DomainType", 4, 0, 4, 0, 2076, 724, 58, 0},
    {-1, 7976, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 7916, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 8122, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {5, 2, 11007, (char *)"RequestedInfo", 528, 8, 1, 0, 2076, 1292, 12, 0},
    {8, 7900, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 7902, 0, (char *)"LMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {5, 7910, 11007, (char *)"RequestedInfo", 528, 8, 1, 0, 2076, 1292, 12, 0},
    {-1, 2107, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 7900, 967, (char *)"SubscriberIdentity", 14, 2, 2, 2, 8, 689, 13, 0},
    {5, 7902, 11007, (char *)"RequestedInfo", 528, 8, 1, 0, 2076, 1292, 12, 0},
    {9, 2107, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7910, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {8, 1395, 0, (char *)"RequestedCAMEL-SubscriptionInfo", 4, 0, 4, 0, 24, 731, 58, 0},
    {INT_MAX, 1395, 0, (char *)"AdditionalRequestedCAMEL-SubscriptionInfo", 4, 0, 4, 0, 2076, 742, 58, 0},
    {1, 7902, 9547, (char *)"SS-ForBS-Code", 14, 3, 1, 0, 2076, 970, 12, 0},
    {-1, 7910, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {8, 2107, 0, (char *)"RequestedCAMEL-SubscriptionInfo", 4, 0, 4, 0, 24, 731, 58, 0},
    {-1, 7914, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 7916, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 7976, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {INT_MAX, 8122, 0, (char *)"AdditionalRequestedCAMEL-SubscriptionInfo", 4, 0, 4, 0, 2076, 742, 58, 0},
    {1, 2, 11095, (char *)"RequestedSubscriptionInfo", 544, 7, 1, 0, 2076, 1300, 12, 0},
    {-1, 7900, 967, (char *)"SubscriberIdentity", 14, 2, 2, 2, 8, 689, 13, 0},
    {1, 7902, 11095, (char *)"RequestedSubscriptionInfo", 544, 7, 1, 0, 2076, 1300, 12, 0},
    {9, 7910, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2107, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 7914, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 7900, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 2, 11165, (char *)"CallForwardingData", 19728, 3, 1, 0, 12, 1307, 12, 0},
    {-1, 8106, 0, (char *)"WrongPasswordAttemptsCounter", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 2, 11179, (char *)"CallBarringData", 17432, 5, 1, 0, 12, 1310, 12, 0},
    {-1, 2, 11211, (char *)"ODB-Info", 1040, 3, 1, 0, 12, 1315, 12, 0},
    {3, 7900, 8394, (char *)"O-CSI", 5888, 5, 1, 0, 2076, 823, 12, 0},
    {10, 7902, 0, (char *)"O-BcsmCamelTDPCriteriaList", 2, 736, 2, 8, 24, 556, 17, 0},
    {-1, 7910, 8504, (char *)"D-CSI", 5976, 5, 1, 0, 12, 845, 12, 0},
    {3, 2107, 8394, (char *)"T-CSI", 5888, 5, 1, 0, 2076, 813, 12, 0},
    {10, 7914, 0, (char *)"T-BCSM-CAMEL-TDP-CriteriaList", 2, 84, 2, 4, 24, 561, 17, 0},
    {3, 7916, 8394, (char *)"T-CSI", 5888, 5, 1, 0, 2076, 813, 12, 0},
    {10, 7976, 0, (char *)"T-BCSM-CAMEL-TDP-CriteriaList", 2, 84, 2, 4, 24, 561, 17, 0},
    {-1, 8122, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 8124, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 8126, 8504, (char *)"GPRS-CSI", 5896, 5, 1, 0, 12, 1221, 12, 0},
    {-1, 8128, 8504, (char *)"SMS-CSI", 5896, 5, 1, 0, 12, 1153, 12, 0},
    {2, 8130, 10344, (char *)"SS-CSI", 1080, 4, 1, 0, 2076, 1138, 12, 0},
    {-1, 8132, 10366, (char *)"M-CSI", 576, 6, 1, 0, 12, 1142, 12, 0},
    {-1, 8134, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {32, 8136, 0, (char *)"SpecificCSI-Withdraw", 4, 0, 2, 0, 24, 686, 1, 0},
    {-1, 8138, 8504, (char *)"SMS-CSI", 5896, 5, 1, 0, 12, 1153, 12, 0},
    {10, 8312, 0, (char *)"MT-smsCAMELTDP-CriteriaList", 2, 32, 2, 4, 24, 1263, 17, 0},
    {-1, 8154, 10366, (char *)"MG-CSI", 576, 6, 1, 0, 12, 1226, 12, 0},
    {3, 8156, 8394, (char *)"O-CSI", 5888, 5, 1, 0, 2076, 823, 12, 0},
    {10, 8158, 0, (char *)"O-BcsmCamelTDPCriteriaList", 2, 736, 2, 8, 24, 556, 17, 0},
    {-1, 8314, 8504, (char *)"D-CSI", 5976, 5, 1, 0, 12, 845, 12, 0},
    {3, 8316, 8394, (char *)"T-CSI", 5888, 5, 1, 0, 2076, 813, 12, 0},
    {10, 8318, 0, (char *)"T-BCSM-CAMEL-TDP-CriteriaList", 2, 84, 2, 4, 24, 561, 17, 0},
    {9, 2, 11225, (char *)"CAMEL-SubscriptionInfo", 79440, 23, 4, 0, 2076, 1318, 12, 0},
    {-1, 7902, 11165, (char *)"CallForwardingData", 19728, 3, 1, 0, 12, 1307, 12, 0},
    {-1, 7910, 11179, (char *)"CallBarringData", 17432, 5, 1, 0, 12, 1310, 12, 0},
    {-1, 2107, 11211, (char *)"ODB-Info", 1040, 3, 1, 0, 12, 1315, 12, 0},
    {9, 7914, 11225, (char *)"CAMEL-SubscriptionInfo", 79440, 23, 4, 0, 2076, 1318, 12, 0},
    {16, 7916, 0, (char *)"SupportedCamelPhases", 2, 0, 2, 0, 24, 255, 1, 0},
    {16, 7976, 0, (char *)"SupportedCamelPhases", 2, 0, 2, 0, 24, 255, 1, 0},
    {-1, 8122, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {16, 8124, 0, (char *)"OfferedCamel4CSIs", 2, 0, 2, 0, 24, 261, 1, 0},
    {16, 8126, 0, (char *)"OfferedCamel4CSIs", 2, 0, 2, 0, 24, 261, 1, 0},
    {9, 1348, 0, (char *)"", 2, 0, 2, 2, 56, 0, 21, 0},
    {5, 7910, 0, (char *)"_octet8", 2, 0, 2, 2, 56, 0, 21, 0},
    {5, 2107, 0, (char *)"", 2, 0, 2, 2, 56, 0, 21, 0},
    {-1, 966, 8205, (char *)"_choice1", 10, 2, 2, 2, 40, 1341, 13, 0},
    {70, 7900, 0, (char *)"_seqof4", 2, 10, 2, 2, 56, 1576, 17, 0},
    {-1, 7902, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 2, 11823, (char *)"_seq10", 1224, 3, 1, 0, 44, 1343, 12, 0},
    {50, 8128, 0, (char *)"_seqof5", 2, 1224, 2, 8, 56, 1579, 17, 0},
    {1, 1395, 0, (char *)"ModificationInstruction", 4, 0, 4, 0, 24, 752, 58, 0},
    {1, 7900, 0, (char *)"SS-Code", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7902, 8205, (char *)"Ext-BasicServiceCode", 10, 2, 2, 2, 8, 771, 13, 0},
    {5, 7910, 0, (char *)"Ext-SS-Status", 2, 0, 2, 2, 24, 0, 21, 0},
    {20, 2107, 0, (char *)"AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {21, 7914, 0, (char *)"ISDN-SubaddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7916, 0, (char *)"Ext-NoRepCondTime", 2, 0, 2, 0, 8, 0, 55, 0},
    {1, 7976, 0, (char *)"ModificationInstruction", 4, 0, 4, 0, 24, 752, 58, 0},
    {-1, 8122, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 2, 11837, (char *)"ModificationRequestFor-CF-Info", 584, 8, 1, 0, 12, 1346, 12, 0},
    {1, 7900, 0, (char *)"SS-Code", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7902, 8205, (char *)"Ext-BasicServiceCode", 10, 2, 2, 2, 8, 771, 13, 0},
    {5, 7910, 0, (char *)"Ext-SS-Status", 2, 0, 2, 2, 24, 0, 21, 0},
    {5, 2107, 18, (char *)"Password", 1, 0, 2, 0, 16408, 0, 24, 0},
    {-1, 7914, 0, (char *)"WrongPasswordAttemptsCounter", 2, 0, 2, 0, 8, 0, 55, 0},
    {1, 7916, 0, (char *)"ModificationInstruction", 4, 0, 4, 0, 24, 752, 58, 0},
    {-1, 7976, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 2, 7990, (char *)"ModificationRequestFor-CB-Info", 544, 7, 1, 0, 12, 1354, 12, 0},
    {8, 7900, 0, (char *)"RequestedCAMEL-SubscriptionInfo", 4, 0, 4, 0, 24, 731, 58, 0},
    {1, 7902, 0, (char *)"ModificationInstruction", 4, 0, 4, 0, 24, 752, 58, 0},
    {1, 7910, 0, (char *)"ModificationInstruction", 4, 0, 4, 0, 24, 752, 58, 0},
    {-1, 2107, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {INT_MAX, 7914, 0, (char *)"AdditionalRequestedCAMEL-SubscriptionInfo", 4, 0, 4, 0, 2076, 742, 58, 0},
    {1, 2, 11911, (char *)"ModificationRequestFor-CSI", 528, 5, 1, 0, 2076, 1361, 12, 0},
    {-1, 7900, 10286, (char *)"ODB-Data", 520, 3, 1, 0, 12, 1124, 12, 0},
    {1, 7902, 0, (char *)"ModificationInstruction", 4, 0, 4, 0, 24, 752, 58, 0},
    {-1, 7910, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 2, 9373, (char *)"ModificationRequestFor-ODB-data", 1040, 3, 1, 0, 12, 1366, 12, 0},
    {-1, 7900, 967, (char *)"SubscriberIdentity", 14, 2, 2, 2, 8, 689, 13, 0},
    {9, 7902, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 7910, 11837, (char *)"ModificationRequestFor-CF-Info", 584, 8, 1, 0, 12, 1346, 12, 0},
    {-1, 2107, 7990, (char *)"ModificationRequestFor-CB-Info", 544, 7, 1, 0, 12, 1354, 12, 0},
    {1, 7914, 11911, (char *)"ModificationRequestFor-CSI", 528, 5, 1, 0, 2076, 1361, 12, 0},
    {-1, 7916, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 7976, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 8122, 9373, (char *)"ModificationRequestFor-ODB-data", 1040, 3, 1, 0, 12, 1366, 12, 0},
    {1, 7900, 0, (char *)"SS-Code", 2, 0, 2, 2, 24, 0, 21, 0},
    {32, 7902, 0, (char *)"Ext-ForwFeatureList", 2, 600, 2, 8, 24, 1189, 17, 0},
    {-1, 7910, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2107, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 2, 7490, (char *)"Ext-ForwardingInfoFor-CSE", 19728, 4, 1, 0, 12, 1369, 12, 0},
    {1, 7900, 0, (char *)"SS-Code", 2, 0, 2, 2, 24, 0, 21, 0},
    {32, 7902, 0, (char *)"Ext-CallBarFeatureList", 2, 528, 2, 8, 24, 1194, 17, 0},
    {5, 7910, 18, (char *)"Password", 1, 0, 2, 0, 16408, 0, 24, 0},
    {-1, 2107, 0, (char *)"WrongPasswordAttemptsCounter", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 7914, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 7916, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 2, 11943, (char *)"Ext-CallBarringInfoFor-CSE", 17432, 6, 1, 0, 12, 1373, 12, 0},
    {-1, 7900, 7490, (char *)"Ext-ForwardingInfoFor-CSE", 19728, 4, 1, 0, 12, 1369, 12, 0},
    {-1, 7902, 11943, (char *)"Ext-CallBarringInfoFor-CSE", 17432, 6, 1, 0, 12, 1373, 12, 0},
    {-1, 966, 967, (char *)"Ext-SS-InfoFor-CSE", 19736, 2, 2, 8, 8, 1379, 13, 0},
    {-1, 7900, 967, (char *)"Ext-SS-InfoFor-CSE", 19736, 2, 2, 8, 8, 1379, 13, 0},
    {9, 7902, 11225, (char *)"CAMEL-SubscriptionInfo", 79440, 23, 4, 0, 2076, 1318, 12, 0},
    {-1, 7910, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {-1, 2107, 11211, (char *)"ODB-Info", 1040, 3, 1, 0, 12, 1315, 12, 0},
    {-1, 7900, 7490, (char *)"Ext-ForwardingInfoFor-CSE", 19728, 4, 1, 0, 12, 1369, 12, 0},
    {-1, 7902, 11943, (char *)"Ext-CallBarringInfoFor-CSE", 17432, 6, 1, 0, 12, 1373, 12, 0},
    {-1, 7910, 11211, (char *)"ODB-Info", 1040, 3, 1, 0, 12, 1315, 12, 0},
    {9, 2107, 11225, (char *)"CAMEL-SubscriptionInfo", 79440, 23, 4, 0, 2076, 1318, 12, 0},
    {-1, 7914, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {1, 7900, 0, (char *)"MM-Code", 2, 0, 2, 2, 24, 0, 21, 0},
    {8, 7902, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 7910, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {5, 2107, 8565, (char *)"LocationInformation", 592, 11, 2, 0, 2076, 861, 12, 0},
    {16, 7916, 0, (char *)"SupportedCamelPhases", 2, 0, 2, 0, 24, 255, 1, 0},
    {-1, 7976, 1459, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 693, 12, 0},
    {4, 8122, 8728, (char *)"LocationInformationGPRS", 584, 10, 2, 0, 2076, 876, 12, 0},
    {64, 8124, 0, (char *)"OfferedCamel4Functionalities", 8, 0, 2, 0, 24, 702, 2, 0}
};

static const struct efield _efieldarray[] = {
    {2, 174, -1, 756, 2},
    {14, 175, -1, 757, 2},
    {32, 176, 0, 758, 3},
    {2, 190, -1, 757, 2},
    {16, 191, -1, 759, 2},
    {568, 192, 0, 758, 3},
    {1072, 193, 1, 760, 11},
    {1092, 194, 2, 761, 11},
    {1112, 195, 3, 762, 11},
    {1132, 196, 4, 763, 11},
    {4, 201, -1, 764, 2},
    {16, 161, -1, 765, 2},
    {32, 267, 0, 766, 3},
    {808, 268, 1, 767, 3},
    {810, 269, 2, 768, 3},
    {820, 270, 3, 769, 3},
    {832, 271, 4, 770, 3},
    {838, 272, 5, 771, 3},
    {848, 273, 6, 772, 3},
    {856, 274, 7, 773, 3},
    {1384, 275, 8, 758, 3},
    {1888, 276, 9, 774, 11},
    {1890, 277, 10, 775, 11},
    {1894, 278, 11, 776, 11},
    {1896, 279, 12, 777, 11},
    {1924, 280, 13, 778, 11},
    {1936, 281, 14, 779, 11},
    {2112, 282, 15, 761, 11},
    {2, 283, -1, 780, 2},
    {24, 295, 0, 781, 3},
    {32, 296, 1, 758, 3},
    {536, 297, 2, 782, 11},
    {630, 298, 3, 783, 11},
    {632, 299, 4, 784, 11},
    {644, 300, 5, 785, 11},
    {658, 301, 6, 786, 11},
    {670, 302, 7, 787, 11},
    {672, 303, 8, 788, 11},
    {676, 304, 9, 789, 11},
    {4, 305, -1, 790, 2},
    {8, 228, -1, 766, 2},
    {784, 188, -1, 759, 2},
    {1336, 315, 0, 769, 3},
    {1348, 316, 1, 768, 3},
    {1358, 317, 2, 771, 3},
    {1368, 318, 3, 791, 3},
    {1380, 319, 4, 792, 3},
    {1392, 320, 5, 780, 3},
    {1414, 321, 6, 781, 3},
    {1416, 322, 7, 793, 3},
    {1920, 323, 8, 782, 11},
    {2016, 324, 9, 794, 11},
    {2576, 325, 10, 775, 11},
    {2580, 326, 11, 784, 11},
    {2592, 327, 12, 785, 11},
    {2606, 328, 13, 786, 11},
    {2618, 329, 14, 761, 11},
    {2638, 330, 15, 776, 11},
    {2640, 331, 16, 787, 11},
    {2641, 332, 17, 795, 11},
    {2642, 333, 18, 789, 11},
    {8, 173, 0, 758, 3},
    {512, 334, 1, 792, 11},
    {524, 335, 2, 791, 11},
    {8, 345, -1, 796, 2},
    {56, 346, 0, 797, 3},
    {2, 362, -1, 768, 2},
    {2, 363, -1, 798, 2},
    {2, 379, -1, 799, 2},
    {10, 360, -1, 800, 2},
    {20, 395, -1, 801, 2},
    {32, 396, -1, 802, 2},
    {36, 401, 0, 803, 3},
    {38, 402, 1, 804, 3},
    {48, 403, 2, 805, 3},
    {50, 404, 3, 806, 3},
    {56, 405, 4, 758, 3},
    {560, 406, 5, 807, 11},
    {578, 407, 6, 808, 11},
    {2, 161, -1, 809, 2},
    {16, 173, 0, 758, 3},
    {2, 162, 0, 768, 3},
    {16, 173, 1, 758, 3},
    {520, 410, 2, 810, 11},
    {528, 411, 3, 811, 11},
    {8, 173, 0, 758, 3},
    {2, 162, 0, 768, 3},
    {12, 417, 1, 812, 3},
    {13, 418, 2, 813, 3},
    {14, 419, 3, 814, 3},
    {15, 420, 4, 815, 3},
    {16, 421, 5, 816, 3},
    {24, 173, 6, 758, 3},
    {528, 422, 7, 817, 11},
    {536, 423, 8, 810, 11},
    {544, 424, 9, 811, 11},
    {560, 425, 10, 818, 11},
    {562, 426, 11, 819, 11},
    {1, 427, 0, 820, 3},
    {2, 428, 1, 813, 3},
    {3, 429, 2, 821, 3},
    {8, 173, 3, 758, 3},
    {512, 430, 4, 810, 11},
    {520, 431, 5, 811, 11},
    {536, 432, 6, 818, 11},
    {4, 436, -1, 822, 2},
    {8, 173, 0, 758, 3},
    {8, 437, -1, 823, 2},
    {8, 439, -1, 824, 2},
    {4, 440, 0, 825, 3},
    {8, 173, 1, 758, 3},
    {2, 442, 0, 826, 3},
    {6, 377, 1, 827, 3},
    {12, 443, 2, 828, 3},
    {4, 444, -1, 829, 2},
    {8, 350, 0, 830, 3},
    {216, 173, 1, 758, 3},
    {2, 445, 0, 831, 3},
    {8, 173, 1, 758, 3},
    {512, 446, 2, 832, 11},
    {8, 367, -1, 833, 2},
    {8, 448, -1, 834, 2},
    {8, 173, 0, 758, 3},
    {8, 173, 0, 758, 3},
    {8, 173, 0, 758, 3},
    {512, 449, 1, 835, 11},
    {513, 450, 2, 836, 11},
    {8, 173, 0, 758, 3},
    {8, 173, 0, 758, 3},
    {512, 451, 1, 837, 11},
    {8, 173, 0, 758, 3},
    {8, 173, 0, 758, 3},
    {8, 173, 0, 758, 3},
    {8, 173, 0, 758, 3},
    {8, 173, 0, 758, 3},
    {8, 173, 0, 758, 3},
    {8, 173, 0, 758, 3},
    {8, 173, 0, 758, 3},
    {8, 173, 0, 758, 3},
    {512, 453, 1, 838, 11},
    {8, 173, 0, 758, 3},
    {512, 454, 1, 839, 11},
    {513, 455, 2, 840, 11},
    {8, 173, 0, 758, 3},
    {8, 173, 0, 758, 3},
    {8, 173, 0, 758, 3},
    {8, 173, 0, 758, 3},
    {8, 173, 0, 758, 3},
    {8, 173, 0, 758, 3},
    {8, 173, 0, 758, 3},
    {8, 173, 0, 758, 3},
    {8, 173, 0, 758, 3},
    {8, 173, 0, 758, 3},
    {8, 173, 0, 758, 3},
    {512, 456, 1, 841, 11},
    {8, 173, 0, 758, 3},
    {8, 173, 0, 758, 3},
    {8, 173, 0, 758, 3},
    {8, 173, 0, 758, 3},
    {8, 173, 0, 758, 3},
    {4, 458, 0, 842, 3},
    {8, 459, 1, 758, 3},
    {4, 461, 0, 843, 3},
    {8, 462, 1, 758, 3},
    {8, 173, 0, 758, 3},
    {8, 173, 0, 758, 3},
    {8, 173, 0, 758, 3},
    {4, 478, -1, 769, 2},
    {16, 479, 0, 844, 3},
    {536, 480, 1, 845, 3},
    {540, 481, -1, 846, 2},
    {544, 482, 2, 847, 3},
    {546, 483, 3, 848, 3},
    {548, 484, -1, 849, 2},
    {560, 485, 4, 850, 3},
    {572, 486, 5, 851, 3},
    {576, 487, 6, 852, 3},
    {592, 488, 7, 853, 3},
    {1312, 489, 8, 854, 3},
    {1832, 490, 9, 855, 3},
    {1840, 491, 10, 758, 3},
    {2344, 492, 11, 856, 11},
    {2348, 493, 12, 857, 11},
    {2350, 494, 13, 858, 11},
    {2352, 495, 14, 859, 11},
    {3072, 496, 15, 860, 11},
    {3076, 497, 16, 861, 11},
    {3078, 498, 17, 862, 11},
    {3082, 499, 18, 863, 11},
    {3083, 500, 19, 864, 11},
    {3084, 501, 20, 865, 11},
    {3085, 502, 21, 866, 11},
    {3086, 503, 22, 867, 11},
    {3096, 504, 23, 868, 11},
    {3816, 505, 24, 869, 11},
    {3818, 506, 25, 870, 11},
    {3820, 507, 26, 871, 11},
    {4, 687, 0, 768, 3},
    {16, 582, 1, 872, 3},
    {27592, 688, 2, 844, 3},
    {28112, 689, 3, 873, 3},
    {28120, 690, 4, 874, 3},
    {70456, 691, 5, 875, 3},
    {70578, 692, 6, 827, 3},
    {70588, 693, 7, 876, 3},
    {70590, 694, 8, 877, 3},
    {70608, 695, 9, 758, 3},
    {71112, 696, 10, 878, 11},
    {71624, 697, 11, 879, 11},
    {72136, 698, 12, 769, 11},
    {72148, 699, 13, 880, 11},
    {72152, 700, 14, 881, 11},
    {72154, 701, 15, 882, 11},
    {72156, 702, 16, 883, 11},
    {72160, 703, 17, 884, 11},
    {72744, 704, 18, 885, 11},
    {72866, 705, 19, 886, 11},
    {72876, 706, 20, 887, 11},
    {72880, 707, 21, 888, 11},
    {72884, 708, 22, 889, 11},
    {72888, 709, 23, 890, 11},
    {4, 710, -1, 768, 2},
    {14, 711, -1, 891, 2},
    {26, 712, 0, 769, 3},
    {38, 713, 1, 770, 3},
    {48, 714, 2, 890, 3},
    {768, 715, 3, 853, 3},
    {1488, 716, 4, 855, 3},
    {1490, 717, 5, 892, 3},
    {1502, 718, 6, 850, 3},
    {1512, 719, 7, 847, 3},
    {1520, 720, 8, 758, 3},
    {2024, 721, 9, 856, 11},
    {2028, 722, 10, 857, 11},
    {2030, 723, 11, 893, 11},
    {2032, 724, 12, 859, 11},
    {2752, 725, 13, 894, 11},
    {2753, 726, 14, 861, 11},
    {2754, 727, 15, 863, 11},
    {2755, 728, 16, 864, 11},
    {2756, 729, 17, 895, 11},
    {2, 161, -1, 896, 2},
    {16, 173, 0, 758, 3},
    {520, 456, 1, 889, 11},
    {2, 737, 0, 850, 3},
    {12, 738, 1, 852, 3},
    {24, 739, 2, 897, 3},
    {600, 740, 3, 768, 3},
    {616, 741, 4, 844, 3},
    {1136, 742, 5, 898, 3},
    {7024, 743, 6, 758, 3},
    {7528, 744, 7, 839, 3},
    {7530, 745, 8, 769, 3},
    {7544, 746, 9, 899, 3},
    {8192, 747, 10, 900, 3},
    {8200, 748, 11, 901, 11},
    {14176, 749, 12, 902, 11},
    {21544, 750, 13, 867, 11},
    {8, 173, 0, 758, 3},
    {2, 752, 0, 768, 3},
    {12, 753, 1, 770, 3},
    {20, 754, 2, 903, 3},
    {24, 755, 3, 758, 3},
    {4, 757, 0, 904, 3},
    {8, 758, 1, 758, 3},
    {2, 768, -1, 768, 2},
    {16, 769, 0, 905, 3},
    {528, 770, 1, 906, 3},
    {1048, 771, 2, 758, 3},
    {8, 772, 0, 758, 3},
    {2, 779, -1, 768, 2},
    {16, 780, -1, 907, 2},
    {736, 781, -1, 908, 2},
    {782, 782, -1, 909, 2},
    {794, 783, 0, 910, 3},
    {796, 784, 1, 856, 3},
    {800, 785, 2, 758, 3},
    {4, 787, -1, 911, 2},
    {8, 788, 0, 758, 3},
    {2, 789, -1, 768, 2},
    {16, 790, 0, 758, 3},
    {2, 792, 0, 881, 3},
    {4, 793, 1, 912, 3},
    {8, 794, 2, 913, 3},
    {16, 795, 3, 758, 3},
    {2, 796, -1, 768, 2},
    {16, 797, 0, 758, 3},
    {8, 173, 0, 758, 3},
    {2, 161, -1, 914, 2},
    {16, 173, 0, 758, 3},
    {8, 173, 0, 758, 3},
    {2, 385, -1, 826, 2},
    {6, 377, 0, 827, 3},
    {12, 799, 1, 915, 3},
    {34, 800, 2, 916, 3},
    {58, 801, 3, 917, 3},
    {60, 802, 4, 918, 11},
    {62, 803, 5, 919, 11},
    {64, 804, 6, 863, 11},
    {4, 841, -1, 828, 2},
    {4, 842, -1, 920, 2},
    {4, 843, -1, 921, 2},
    {4, 844, -1, 922, 2},
    {2, 208, -1, 923, 2},
    {6, 845, -1, 924, 2},
    {168, 357, 0, 856, 11},
    {172, 846, 1, 769, 11},
    {0, 208, -1, 923, 2},
    {4, 845, -1, 924, 2},
    {2, 850, -1, 768, 2},
    {12, 851, -1, 769, 2},
    {24, 852, -1, 925, 2},
    {28, 853, 0, 926, 3},
    {80, 854, 1, 758, 3},
    {584, 855, 2, 927, 11},
    {596, 856, 3, 928, 11},
    {8, 173, 0, 758, 3},
    {2, 864, -1, 826, 2},
    {8, 865, 0, 929, 3},
    {2, 866, 0, 908, 3},
    {2, 867, -1, 826, 2},
    {6, 868, 0, 930, 3},
    {2, 869, -1, 826, 2},
    {6, 870, 0, 828, 3},
    {2, 873, -1, 769, 2},
    {14, 874, -1, 931, 2},
    {16, 875, -1, 932, 2},
    {40, 876, 0, 758, 3},
    {544, 877, 1, 933, 11},
    {546, 878, 2, 934, 11},
    {548, 879, 3, 935, 11},
    {2, 162, -1, 768, 2},
    {16, 884, -1, 936, 2},
    {560, 885, 0, 758, 3},
    {2, 890, -1, 937, 2},
    {26, 894, -1, 938, 2},
    {50, 350, -1, 819, 2},
    {256, 173, 0, 758, 3},
    {760, 162, 1, 768, 11},
    {2, 350, 0, 819, 3},
    {208, 173, 1, 758, 3},
    {2, 890, -1, 937, 2},
    {26, 894, -1, 938, 2},
    {50, 350, -1, 819, 2},
    {252, 456, 0, 939, 3},
    {256, 173, 1, 758, 3},
    {2, 350, 0, 819, 3},
    {208, 173, 1, 758, 3},
    {2, 161, -1, 769, 2},
    {14, 206, -1, 932, 2},
    {36, 895, -1, 940, 2},
    {40, 896, 0, 831, 3},
    {48, 897, 1, 758, 3},
    {552, 898, 2, 933, 11},
    {553, 899, 3, 941, 11},
    {556, 900, 4, 942, 11},
    {560, 901, 5, 832, 11},
    {2, 161, 0, 943, 3},
    {16, 173, 1, 758, 3},
    {0, 161, -1, 769, 2},
    {12, 206, -1, 932, 2},
    {2, 161, 0, 943, 3},
    {14, 902, 1, 944, 3},
    {16, 173, 2, 758, 3},
    {520, 445, 3, 831, 11},
    {522, 903, 4, 832, 11},
    {2, 905, -1, 768, 2},
    {12, 904, -1, 945, 2},
    {16, 456, 0, 946, 3},
    {24, 173, 1, 758, 3},
    {8, 173, 0, 758, 3},
    {2, 360, -1, 800, 2},
    {12, 894, -1, 938, 2},
    {36, 350, -1, 819, 2},
    {240, 173, 0, 758, 3},
    {2, 907, 0, 819, 3},
    {204, 908, 1, 947, 3},
    {266, 456, 2, 948, 3},
    {272, 909, 3, 758, 3},
    {2, 946, 0, 768, 3},
    {12, 947, -1, 949, 2},
    {16, 948, -1, 950, 2},
    {18, 949, 1, 951, 3},
    {40, 950, 2, 758, 3},
    {544, 951, 3, 952, 11},
    {552, 952, 4, 953, 11},
    {580, 953, 5, 954, 11},
    {582, 954, 6, 955, 11},
    {594, 955, 7, 956, 11},
    {8, 957, 0, 758, 3},
    {512, 958, 1, 957, 11},
    {2, 959, 0, 768, 3},
    {12, 960, -1, 949, 2},
    {16, 961, 1, 758, 3},
    {520, 962, 2, 952, 11},
    {8, 963, 0, 758, 3},
    {2, 162, -1, 768, 2},
    {12, 981, -1, 891, 2},
    {24, 161, -1, 958, 2},
    {36, 982, 0, 770, 3},
    {48, 173, 1, 758, 3},
    {552, 983, 2, 959, 11},
    {1096, 984, 3, 960, 11},
    {1097, 985, 4, 961, 11},
    {1098, 986, 5, 760, 11},
    {1118, 987, 6, 962, 11},
    {2, 161, -1, 963, 2},
    {16, 173, 0, 758, 3},
    {520, 456, 1, 964, 11},
    {2, 359, -1, 965, 2},
    {20, 988, 0, 966, 3},
    {24, 173, 1, 758, 3},
    {8, 173, 0, 758, 3},
    {2, 162, -1, 768, 2},
    {12, 989, 0, 958, 3},
    {24, 990, 1, 967, 3},
    {40, 173, 2, 758, 3},
    {1, 991, 0, 968, 3},
    {2, 992, 1, 969, 3},
    {8, 173, 2, 758, 3},
    {2, 361, -1, 798, 2},
    {8, 993, 0, 970, 3},
    {10, 456, 1, 971, 3},
    {16, 173, 2, 758, 3},
    {520, 161, 3, 891, 11},
    {532, 995, 4, 972, 11},
    {540, 996, 5, 973, 11},
    {2, 162, 0, 768, 3},
    {12, 1009, 1, 974, 3},
    {466, 1017, 2, 975, 3},
    {512, 1018, 3, 758, 3},
    {2, 162, -1, 768, 2},
    {12, 1020, -1, 976, 2},
    {16, 173, 0, 758, 3},
    {520, 1022, 1, 977, 11},
    {524, 1021, 2, 978, 11},
    {528, 997, 3, 979, 11},
    {546, 1023, 4, 958, 11},
    {558, 1024, 5, 967, 11},
    {8, 173, 0, 758, 3},
    {2, 162, -1, 768, 2},
    {12, 161, -1, 967, 2},
    {24, 189, -1, 980, 2},
    {48, 173, 0, 758, 3},
    {552, 1034, 1, 981, 11},
    {1088, 1035, 2, 960, 11},
    {1089, 1036, 3, 982, 11},
    {1090, 1037, 4, 760, 11},
    {1110, 1038, 5, 962, 11},
    {2, 161, -1, 963, 2},
    {16, 173, 0, 758, 3},
    {520, 456, 1, 964, 11},
    {8, 356, -1, 983, 2},
    {3088, 1072, 0, 984, 3},
    {3190, 1073, 1, 985, 3},
    {3292, 1074, 2, 986, 3},
    {3296, 1075, 3, 987, 3},
    {3304, 1076, 4, 988, 3},
    {3840, 1077, 5, 989, 3},
    {3856, 1078, 6, 758, 3},
    {4360, 1079, 7, 990, 11},
    {4488, 1080, 8, 991, 11},
    {4492, 1081, 9, 992, 11},
    {4496, 1082, 10, 993, 11},
    {4540, 1083, 11, 994, 11},
    {4552, 1084, 12, 995, 11},
    {6184, 1085, 13, 996, 11},
    {6186, 1086, 14, 997, 11},
    {6192, 1087, 15, 998, 11},
    {6208, 1088, 16, 952, 11},
    {6214, 1089, 17, 999, 11},
    {4, 1097, 0, 1000, 3},
    {14, 456, 1, 1001, 3},
    {16, 1098, 2, 1002, 3},
    {32, 1099, 3, 983, 3},
    {3112, 1100, 4, 1003, 3},
    {3114, 1101, 5, 768, 3},
    {3124, 1102, 6, 984, 3},
    {3226, 1103, 7, 985, 3},
    {3328, 1104, 8, 989, 3},
    {3344, 1105, 9, 987, 3},
    {3352, 1106, 10, 988, 3},
    {3888, 1107, 11, 990, 3},
    {4016, 1108, 12, 758, 3},
    {4520, 1109, 13, 1004, 11},
    {4522, 1110, 14, 991, 11},
    {4526, 1111, 15, 992, 11},
    {4530, 1112, 16, 993, 11},
    {4574, 1113, 17, 800, 11},
    {4584, 1114, 18, 1005, 11},
    {4674, 1115, 19, 1006, 11},
    {4680, 1116, 20, 995, 11},
    {6312, 1117, 21, 996, 11},
    {6320, 1118, 22, 1007, 11},
    {6360, 1119, 23, 1008, 11},
    {6370, 1120, 24, 998, 11},
    {6386, 1121, 25, 952, 11},
    {6392, 1122, 26, 999, 11},
    {2, 1137, 0, 1009, 3},
    {14, 1138, 1, 1010, 3},
    {120, 1139, 2, 983, 3},
    {3200, 1140, 3, 1011, 3},
    {3202, 456, 4, 1012, 3},
    {3208, 1141, 5, 1013, 3},
    {3728, 1142, 6, 1014, 3},
    {3744, 1143, 7, 758, 3},
    {4248, 1144, 8, 997, 11},
    {4256, 1145, 9, 1015, 11},
    {2, 1146, 0, 1000, 3},
    {12, 1147, -1, 1016, 2},
    {24, 1148, 1, 1002, 3},
    {40, 1149, 2, 983, 3},
    {3120, 1150, 3, 1017, 3},
    {3128, 1151, 4, 758, 3},
    {3632, 1152, 5, 1005, 11},
    {3722, 1153, 6, 996, 11},
    {8, 356, -1, 983, 2},
    {3088, 1154, 0, 758, 3},
    {8, 356, -1, 983, 2},
    {3088, 1156, 0, 1013, 3},
    {3608, 1157, 1, 1018, 3},
    {3612, 1158, 2, 1014, 3},
    {3622, 1159, 3, 1017, 3},
    {3624, 1160, 4, 758, 3},
    {4128, 1161, 5, 1019, 11},
    {4136, 1162, 6, 1015, 11},
    {8, 356, -1, 983, 2},
    {3088, 1163, 0, 758, 3},
    {8, 1164, 0, 758, 3},
    {2, 1168, -1, 768, 2},
    {12, 993, -1, 970, 2},
    {14, 456, 0, 971, 3},
    {15, 1169, 1, 1020, 3},
    {16, 1165, 2, 1021, 3},
    {56, 1170, 3, 758, 3},
    {560, 1171, 4, 1022, 11},
    {564, 1172, 5, 1023, 11},
    {2, 1009, 0, 974, 3},
    {456, 173, 1, 758, 3},
    {2, 229, -1, 771, 2},
    {12, 1173, -1, 1024, 2},
    {16, 173, 0, 758, 3},
    {4, 1174, 0, 1025, 3},
    {8, 1096, 1, 1026, 3},
    {48, 1175, 2, 758, 3},
    {4, 1366, 0, 768, 3},
    {14, 1367, 1, 769, 3},
    {26, 1368, 2, 1027, 3},
    {32, 1369, 3, 1028, 3},
    {36, 1370, 4, 1029, 3},
    {438, 1371, 5, 1030, 3},
    {600, 1372, 6, 1031, 3},
    {777968, 1373, 7, 1032, 3},
    {778488, 1374, 8, 1033, 3},
    {778490, 1375, 9, 1034, 3},
    {778536, 1376, 10, 1035, 3},
    {804544, 1377, 11, 1036, 3},
    {831752, 1378, 12, 1037, 3},
    {872016, 1379, 13, 758, 3},
    {872520, 1380, 14, 878, 11},
    {873032, 1381, 15, 1038, 11},
    {905152, 1382, 16, 1039, 11},
    {905156, 1383, 17, 1040, 11},
    {905160, 1384, 18, 1041, 11},
    {916080, 1385, 19, 1042, 11},
    {916088, 1386, 20, 1043, 11},
    {1388264, 1387, 21, 881, 11},
    {1388266, 1388, 22, 1044, 11},
    {1388280, 1389, 23, 1045, 11},
    {1388808, 1390, 24, 1046, 11},
    {1388816, 1391, 25, 1047, 11},
    {1407920, 1392, 26, 1048, 11},
    {1407924, 1393, 27, 1049, 11},
    {1407925, 1394, 28, 1050, 11},
    {1407928, 1443, 29, 1051, 11},
    {4612000, 1447, 30, 1052, 11},
    {4638808, 1448, 31, 1053, 11},
    {2, 1450, 0, 1030, 3},
    {164, 1451, 1, 1029, 3},
    {566, 1452, 2, 875, 3},
    {688, 1453, 3, 1054, 3},
    {692, 1454, 4, 1055, 3},
    {696, 1455, 5, 1056, 3},
    {704, 1456, 6, 758, 3},
    {1208, 1457, 7, 1057, 11},
    {2, 1464, -1, 768, 2},
    {12, 1465, 0, 1058, 3},
    {714, 1466, 1, 875, 3},
    {836, 1467, 2, 1033, 3},
    {838, 1468, 3, 1059, 3},
    {842, 1469, 4, 1060, 3},
    {843, 1470, 5, 1061, 3},
    {844, 1471, 6, 1062, 3},
    {848, 1472, 7, 758, 3},
    {1352, 1473, 8, 1063, 11},
    {1456, 1474, 9, 1064, 11},
    {1458, 1475, 10, 1065, 11},
    {1582, 1476, 11, 1066, 11},
    {1583, 1477, 12, 912, 11},
    {1584, 1478, 13, 1067, 11},
    {1588, 1479, 14, 1068, 11},
    {4, 1480, 0, 1055, 3},
    {8, 173, 1, 758, 3},
    {2, 1482, -1, 768, 2},
    {12, 1483, 0, 1069, 3},
    {32, 1484, -1, 1070, 2},
    {48, 1485, 1, 758, 3},
    {2, 1486, -1, 980, 2},
    {22, 1487, 0, 1069, 3},
    {42, 1488, 1, 1071, 3},
    {48, 1489, 2, 758, 3},
    {2, 1490, -1, 768, 2},
    {12, 1491, -1, 1070, 2},
    {24, 1492, 0, 1069, 3},
    {48, 1493, 1, 758, 3},
    {2, 1494, 0, 1069, 3},
    {24, 1495, 1, 758, 3},
    {2, 1496, -1, 768, 2},
    {12, 1497, -1, 980, 2},
    {32, 1498, 0, 1069, 3},
    {56, 1499, 1, 758, 3},
    {8, 1500, 0, 758, 3},
    {2, 161, -1, 963, 2},
    {14, 365, 0, 1072, 3},
    {2, 162, -1, 768, 2},
    {12, 177, 0, 770, 3},
    {24, 173, 1, 758, 3},
    {528, 1501, 2, 959, 11},
    {2, 161, -1, 963, 2},
    {14, 456, 0, 1073, 3},
    {16, 173, 1, 758, 3},
    {2, 1512, -1, 768, 2},
    {12, 1513, 0, 770, 3},
    {24, 1514, -1, 1074, 2},
    {552, 1515, 1, 758, 3},
    {8, 678, -1, 874, 2},
    {42344, 173, 0, 758, 3},
    {2, 1516, -1, 1075, 2},
    {16, 1517, -1, 1074, 2},
    {544, 1518, -1, 1076, 2},
    {560, 1519, 0, 758, 3},
    {8, 678, -1, 874, 2},
    {42344, 173, 0, 758, 3},
    {2, 1530, -1, 1075, 2},
    {16, 1531, -1, 1077, 2},
    {560, 1532, -1, 1076, 2},
    {576, 1533, 0, 758, 3},
    {1080, 1534, 1, 863, 3},
    {8, 1564, 0, 1078, 3},
    {19736, 1565, 1, 1079, 3},
    {37168, 1566, 2, 1080, 3},
    {38208, 1567, 3, 1081, 3},
    {117648, 1568, 4, 1082, 3},
    {117650, 1569, 5, 1083, 3},
    {117656, 1570, 6, 758, 3},
    {118160, 1571, 7, 1084, 11},
    {118162, 1572, 8, 1085, 11},
    {118168, 1580, 9, 1086, 11},
    {2, 1609, -1, 1075, 2},
    {16, 1610, -1, 1076, 2},
    {32, 1611, 0, 1087, 3},
    {616, 1612, 1, 1088, 3},
    {1160, 1613, 2, 1089, 3},
    {1688, 1614, 3, 758, 3},
    {2192, 1615, 4, 863, 3},
    {2200, 1616, 5, 1090, 11},
    {8, 1632, 0, 1091, 3},
    {19744, 1633, 1, 1081, 3},
    {99184, 1634, 2, 758, 3},
    {99688, 1635, 3, 1080, 11},
    {2, 162, -1, 768, 2},
    {12, 161, -1, 769, 2},
    {24, 1636, 0, 1092, 3},
    {19752, 1637, 1, 1093, 3},
    {37184, 1638, 2, 1080, 3},
    {38224, 1639, 3, 1081, 3},
    {117664, 1640, 4, 900, 3},
    {117672, 173, 5, 758, 3},
    {8, 173, 0, 758, 3},
    {4, 517, -1, 1094, 2},
    {8, 1641, -1, 1095, 2},
    {12, 1642, -1, 768, 2},
    {22, 1643, -1, 769, 2},
    {40, 1644, 0, 1096, 3},
    {632, 1645, 1, 1097, 3},
    {640, 1646, 2, 758, 3},
    {1144, 1647, 3, 1098, 11},
    {1728, 1648, 4, 1099, 11},
    {8, 173, 0, 758, 3},
    {2, 163, -1, 768, 2},
    {2, 164, -1, 769, 2},
    {8, 166, -1, 1100, 18},
    {16, 167, 0, 1101, 3},
    {8, 171, 0, 1102, 3},
    {496, 172, 1, 1103, 3},
    {2, 178, -1, 891, 2},
    {2, 179, -1, 967, 2},
    {2, 161, -1, 1104, 2},
    {14, 182, 0, 770, 3},
    {24, 183, 1, 758, 3},
    {528, 184, 2, 1105, 11},
    {530, 185, 3, 1106, 11},
    {544, 186, 4, 1107, 11},
    {546, 187, 5, 1108, 11},
    {4, 199, -1, 1109, 2},
    {8, 200, 0, 1110, 11},
    {2, 203, 0, 1111, 3},
    {16, 204, 1, 758, 3},
    {2, 211, -1, 1112, 2},
    {6, 212, -1, 1113, 2},
    {72, 213, 0, 1114, 11},
    {2, 217, -1, 1112, 2},
    {6, 218, -1, 1115, 2},
    {72, 219, 0, 1114, 11},
    {4, 221, -1, 1116, 2},
    {8, 222, 0, 1117, 3},
    {528, 223, 1, 1118, 3},
    {552, 224, 2, 1119, 3},
    {556, 225, 3, 1120, 3},
    {632, 226, 4, 1121, 11},
    {700, 227, 5, 1122, 11},
    {0, 233, -1, 1123, 2},
    {2, 235, 0, 1124, 3},
    {6, 236, 1, 1125, 3},
    {8, 237, 2, 1126, 3},
    {12, 238, 3, 1127, 3},
    {16, 239, 4, 758, 3},
    {520, 240, 5, 1128, 11},
    {0, 246, -1, 1112, 2},
    {4, 247, -1, 1129, 2},
    {4, 250, -1, 1130, 2},
    {8, 251, 0, 1131, 3},
    {0, 255, -1, 1132, 2},
    {4, 256, -1, 1133, 2},
    {0, 259, -1, 1134, 2},
    {4, 263, -1, 1135, 2},
    {168, 264, 0, 1136, 3},
    {172, 265, 1, 1137, 3},
    {2, 290, -1, 1138, 2},
    {2, 291, -1, 1139, 2},
    {1, 306, 0, 1140, 11},
    {8, 308, 0, 1102, 3},
    {496, 309, 1, 1141, 3},
    {2, 198, -1, 1110, 2},
    {4, 312, 0, 1142, 3},
    {8, 313, 1, 759, 3},
    {8, 337, -1, 1143, 2},
    {8, 0, -1, 1144, 2},
    {8, 340, -1, 1145, 2},
    {8, 341, -1, 1146, 2},
    {8, 342, -1, 1147, 2},
    {2, 336, -1, 1148, 2},
    {8, 343, -1, 1149, 2},
    {32, 344, 0, 1150, 3},
    {4, 349, -1, 1151, 2},
    {8, 350, -1, 1152, 2},
    {216, 173, 0, 758, 3},
    {4, 352, -1, 1153, 2},
    {8, 350, -1, 1152, 2},
    {216, 173, 0, 758, 3},
    {4, 354, -1, 1154, 2},
    {8, 355, -1, 1152, 2},
    {2576, 173, 0, 758, 3},
    {0, 162, -1, 768, 2},
    {10, 177, -1, 770, 2},
    {2, 162, -1, 768, 2},
    {2, 358, -1, 1155, 2},
    {2, 370, -1, 1156, 2},
    {8, 371, 0, 758, 3},
    {2, 375, -1, 1157, 2},
    {2, 376, -1, 799, 2},
    {2, 380, -1, 1158, 2},
    {2, 381, -1, 1159, 2},
    {2, 383, -1, 1160, 2},
    {4, 383, -1, 918, 2},
    {8, 173, 0, 758, 3},
    {2, 389, -1, 826, 2},
    {6, 390, -1, 828, 2},
    {14, 391, -1, 1161, 2},
    {16, 392, -1, 919, 2},
    {24, 393, 0, 758, 3},
    {1, 412, 0, 1162, 3},
    {2, 413, 1, 1163, 3},
    {3, 414, 2, 1164, 3},
    {4, 415, 3, 1165, 3},
    {2, 433, 0, 1166, 3},
    {8, 0, -1, 1167, 2},
    {16, 434, -1, 1168, 66},
    {4, 437, 0, 823, 3},
    {8, 173, 1, 758, 3},
    {512, 438, 2, 1169, 11},
    {4, 367, 0, 833, 3},
    {8, 173, 1, 758, 3},
    {512, 447, 2, 1170, 11},
    {2, 463, -1, 1171, 2},
    {8, 456, 0, 1172, 3},
    {16, 173, 1, 758, 3},
    {2, 470, -1, 1056, 2},
    {4, 456, 0, 1173, 3},
    {8, 173, 1, 758, 3},
    {512, 472, 2, 1057, 11},
    {2, 509, 0, 915, 3},
    {14, 510, 1, 916, 3},
    {38, 511, 2, 1174, 3},
    {48, 512, 3, 758, 3},
    {552, 513, 4, 1175, 11},
    {8, 161, -1, 896, 2},
    {8, 514, -1, 897, 2},
    {4, 516, -1, 1176, 2},
    {8, 517, -1, 1094, 2},
    {12, 519, -1, 1076, 2},
    {24, 520, -1, 1177, 2},
    {32, 521, 0, 758, 3},
    {8, 523, -1, 1178, 2},
    {5376, 173, 0, 758, 3},
    {5880, 525, 1, 1179, 11},
    {5882, 526, 2, 1180, 11},
    {5883, 527, 3, 1181, 11},
    {4, 529, -1, 1182, 2},
    {8, 517, -1, 1094, 2},
    {12, 530, -1, 1076, 2},
    {24, 531, -1, 1177, 2},
    {32, 532, 0, 758, 3},
    {8, 534, -1, 1183, 2},
    {5376, 173, 0, 758, 3},
    {5880, 535, 1, 1179, 11},
    {5882, 536, 2, 1180, 11},
    {5883, 537, 3, 1184, 11},
    {4, 543, -1, 1185, 2},
    {8, 544, 0, 1186, 3},
    {130, 545, 1, 1187, 3},
    {4, 529, -1, 1182, 2},
    {8, 551, 0, 1188, 3},
    {148, 552, 1, 1189, 3},
    {200, 553, 2, 1190, 3},
    {204, 554, 3, 1191, 11},
    {232, 555, 4, 758, 11},
    {4, 516, -1, 1192, 2},
    {8, 559, 0, 1189, 3},
    {60, 560, 1, 1193, 3},
    {2, 161, -1, 1194, 2},
    {16, 517, -1, 1094, 2},
    {20, 161, -1, 1076, 2},
    {32, 518, -1, 1177, 2},
    {40, 173, 0, 758, 3},
    {8, 565, 0, 1195, 3},
    {5456, 566, 1, 1179, 3},
    {5464, 567, 2, 758, 3},
    {5968, 568, 3, 1180, 3},
    {5969, 569, 4, 1181, 3},
    {8, 571, 0, 1196, 3},
    {5896, 572, 1, 898, 3},
    {11784, 573, 2, 758, 3},
    {12288, 574, 3, 1197, 11},
    {19656, 575, 4, 1198, 11},
    {20504, 576, 5, 901, 11},
    {8, 514, 0, 897, 3},
    {584, 578, -1, 1199, 2},
    {27064, 579, 1, 758, 3},
    {8, 515, -1, 1200, 2},
    {8, 581, -1, 1201, 2},
    {2, 284, 0, 1202, 3},
    {4, 587, 1, 1203, 3},
    {14, 588, 2, 1204, 3},
    {26, 589, 3, 1205, 3},
    {38, 590, 4, 1206, 3},
    {56, 591, 5, 758, 3},
    {560, 592, 6, 1207, 11},
    {566, 593, 7, 891, 11},
    {578, 594, 8, 1208, 11},
    {590, 595, 9, 1209, 11},
    {591, 596, 10, 787, 11},
    {4, 599, -1, 1210, 2},
    {4, 600, -1, 1211, 2},
    {4, 598, -1, 1212, 2},
    {4, 601, -1, 1213, 2},
    {2, 604, 0, 1206, 3},
    {14, 605, 1, 1214, 3},
    {22, 606, 2, 1203, 3},
    {32, 607, 3, 967, 3},
    {44, 608, 4, 1215, 3},
    {56, 609, 5, 758, 3},
    {560, 610, 6, 787, 11},
    {562, 611, 7, 1208, 11},
    {574, 612, 8, 1209, 11},
    {576, 613, 9, 1202, 11},
    {4, 625, -1, 1216, 2},
    {6, 626, 0, 1217, 3},
    {8, 627, -1, 1218, 2},
    {12, 628, 1, 1219, 3},
    {30, 629, 2, 1220, 3},
    {96, 630, 3, 1221, 3},
    {162, 631, 4, 1222, 3},
    {164, 632, 5, 1223, 3},
    {168, 633, 6, 1224, 3},
    {174, 634, 7, 1225, 3},
    {180, 635, 8, 1069, 3},
    {200, 636, 9, 1226, 3},
    {212, 637, 10, 1227, 3},
    {224, 638, 11, 1228, 3},
    {236, 639, 12, 1229, 3},
    {242, 640, 13, 1048, 3},
    {246, 641, 14, 1230, 3},
    {272, 642, 15, 758, 3},
    {776, 643, 16, 1231, 11},
    {782, 644, 17, 1232, 11},
    {788, 645, 18, 1233, 11},
    {8, 648, -1, 1234, 2},
    {8, 649, -1, 1235, 2},
    {8, 650, -1, 1236, 2},
    {8, 651, -1, 1237, 2},
    {8, 652, -1, 1238, 2},
    {8, 653, -1, 1239, 2},
    {8, 598, -1, 1212, 2},
    {2, 658, -1, 1240, 2},
    {12, 659, 0, 1241, 3},
    {2, 663, 0, 1242, 3},
    {10, 664, 1, 768, 3},
    {20, 665, 2, 769, 3},
    {32, 666, 3, 880, 3},
    {40, 667, 4, 758, 3},
    {8, 669, 0, 1096, 3},
    {600, 670, 1, 1243, 3},
    {608, 671, 2, 758, 3},
    {1112, 672, 3, 1098, 11},
    {1696, 673, 4, 1244, 11},
    {41712, 674, 5, 771, 11},
    {41722, 675, 6, 1245, 11},
    {41728, 676, 7, 1246, 11},
    {41792, 677, 8, 1247, 11},
    {1, 680, 0, 839, 3},
    {2, 681, 1, 1248, 3},
    {8, 682, 2, 758, 3},
    {2, 732, 0, 1249, 3},
    {6, 733, 1, 1250, 3},
    {140, 734, 2, 1251, 3},
    {144, 735, 3, 758, 3},
    {4, 759, 0, 904, 3},
    {8, 760, 1, 758, 3},
    {4, 764, 0, 1252, 3},
    {8, 765, 1, 1253, 3},
    {16, 766, 2, 758, 3},
    {2, 774, 0, 930, 3},
    {4, 775, 1, 927, 3},
    {16, 776, 2, 1254, 3},
    {40, 777, 3, 852, 3},
    {2, 377, 0, 827, 3},
    {8, 805, 1, 828, 3},
    {12, 806, 2, 915, 3},
    {24, 807, 3, 916, 3},
    {48, 808, 4, 1174, 3},
    {52, 809, 5, 917, 3},
    {54, 810, 6, 1175, 11},
    {2, 385, 0, 826, 3},
    {6, 812, -1, 921, 2},
    {2, 377, 0, 827, 3},
    {8, 814, 1, 828, 3},
    {2, 385, 0, 826, 3},
    {6, 816, -1, 1255, 2},
    {4, 820, -1, 1256, 2},
    {4, 821, -1, 1257, 2},
    {2, 385, 0, 826, 3},
    {6, 824, 1, 828, 3},
    {12, 822, 2, 1258, 3},
    {20, 823, 3, 920, 3},
    {100, 383, 4, 918, 11},
    {102, 825, 5, 919, 11},
    {4, 827, -1, 1259, 2},
    {4, 828, -1, 1260, 2},
    {4, 829, -1, 1261, 2},
    {2, 385, -1, 826, 2},
    {6, 377, 0, 827, 3},
    {12, 831, 1, 863, 11},
    {2, 441, -1, 828, 2},
    {8, 818, 0, 1256, 3},
    {12, 834, 1, 1262, 11},
    {14, 835, 2, 918, 11},
    {16, 836, 3, 1263, 11},
    {248, 837, 4, 1161, 11},
    {250, 838, 5, 919, 11},
    {252, 839, 6, 1264, 11},
    {2, 858, -1, 908, 2},
    {48, 859, -1, 909, 2},
    {60, 860, 0, 1265, 3},
    {64, 861, -1, 907, 2},
    {784, 862, -1, 853, 2},
    {2, 880, -1, 1104, 2},
    {14, 177, 0, 770, 3},
    {24, 173, 1, 758, 3},
    {528, 881, 2, 1105, 11},
    {530, 882, 3, 1106, 11},
    {2, 886, -1, 768, 2},
    {2, 887, -1, 770, 2},
    {2, 888, -1, 1266, 2},
    {2, 889, -1, 1267, 2},
    {2, 891, -1, 769, 2},
    {2, 892, -1, 1268, 2},
    {2, 893, -1, 1269, 2},
    {4, 914, 0, 1270, 3},
    {8, 915, 1, 1271, 3},
    {12, 916, 2, 1272, 3},
    {16, 917, 3, 1273, 3},
    {20, 918, 4, 1274, 3},
    {24, 919, 5, 1275, 3},
    {2, 928, 0, 1276, 3},
    {4, 929, 1, 1277, 3},
    {6, 930, 2, 1278, 3},
    {8, 931, 3, 1279, 3},
    {9, 932, 4, 1280, 3},
    {10, 933, 5, 1281, 3},
    {2, 940, 0, 1276, 3},
    {4, 941, 1, 1277, 3},
    {6, 942, 2, 1278, 3},
    {8, 943, 3, 1279, 3},
    {9, 944, 4, 1281, 3},
    {2, 965, -1, 1282, 2},
    {2, 966, -1, 1283, 2},
    {2, 968, 0, 1056, 3},
    {8, 173, 1, 758, 3},
    {512, 969, 2, 1284, 11},
    {516, 970, 3, 860, 11},
    {520, 971, 4, 1285, 11},
    {530, 972, 5, 863, 11},
    {532, 973, 6, 1107, 11},
    {534, 974, 7, 1057, 11},
    {536, 975, 8, 1286, 11},
    {537, 976, 9, 1287, 11},
    {2, 978, -1, 1008, 2},
    {12, 979, 0, 1288, 3},
    {0, 997, -1, 979, 2},
    {18, 998, -1, 1289, 2},
    {24, 398, -1, 1290, 2},
    {0, 997, -1, 979, 2},
    {18, 1001, -1, 1291, 2},
    {36, 1002, -1, 1292, 2},
    {54, 1003, -1, 1293, 2},
    {72, 1004, -1, 1294, 2},
    {2, 1007, -1, 1295, 2},
    {2, 1008, -1, 1296, 2},
    {0, 398, -1, 1290, 2},
    {10, 1010, -1, 1297, 2},
    {0, 1002, -1, 1292, 2},
    {18, 1003, -1, 1293, 2},
    {36, 1012, -1, 1298, 2},
    {2, 1014, -1, 1299, 2},
    {2, 1015, -1, 1300, 2},
    {2, 456, 0, 1284, 3},
    {8, 1025, 1, 758, 3},
    {512, 1026, 2, 1285, 11},
    {522, 1027, 3, 1301, 11},
    {524, 1028, 4, 1056, 11},
    {526, 1029, 5, 1107, 11},
    {528, 1030, 6, 1057, 11},
    {530, 1031, 7, 1302, 11},
    {531, 1032, 8, 1286, 11},
    {2, 1045, 0, 1303, 3},
    {14, 1046, 1, 1304, 3},
    {32, 1047, 2, 758, 3},
    {0, 1049, -1, 989, 2},
    {16, 1050, -1, 1004, 2},
    {0, 1053, -1, 991, 2},
    {4, 1050, -1, 1004, 2},
    {2, 1058, -1, 1305, 2},
    {8, 1059, 0, 1306, 3},
    {14, 1060, 1, 1307, 3},
    {20, 1061, 2, 1308, 3},
    {26, 1062, 3, 1309, 3},
    {32, 1063, 4, 1310, 3},
    {38, 1064, 5, 1311, 3},
    {44, 1065, 6, 1312, 3},
    {56, 1066, 7, 758, 3},
    {8, 1068, 0, 1313, 3},
    {568, 1069, 1, 1314, 3},
    {1128, 1070, 2, 758, 3},
    {8, 1094, 0, 1315, 3},
    {24, 1095, 1, 1316, 3},
    {0, 161, -1, 1009, 2},
    {12, 1050, -1, 1004, 2},
    {2, 1128, 0, 1317, 3},
    {6, 1129, 1, 1318, 3},
    {16, 1130, 2, 758, 3},
    {2, 1134, 0, 1319, 3},
    {6, 1135, 1, 1320, 3},
    {0, 997, -1, 979, 2},
    {18, 1019, -1, 1321, 2},
    {2, 382, 0, 827, 3},
    {12, 1182, -1, 828, 2},
    {20, 1183, 1, 915, 3},
    {32, 1184, 2, 916, 3},
    {56, 1185, 3, 1174, 3},
    {64, 1186, 4, 917, 3},
    {72, 1187, 5, 758, 3},
    {576, 1188, 6, 1175, 11},
    {2, 385, -1, 826, 2},
    {8, 1190, -1, 921, 2},
    {19216, 1191, 0, 758, 3},
    {2, 382, 0, 827, 3},
    {12, 1193, -1, 828, 2},
    {24, 173, 1, 758, 3},
    {2, 385, -1, 826, 2},
    {8, 1195, -1, 1255, 2},
    {16912, 173, 0, 758, 3},
    {2, 1197, -1, 1322, 2},
    {4, 463, -1, 1171, 2},
    {12, 1198, -1, 1323, 2},
    {16, 1199, 0, 920, 3},
    {344, 1200, 1, 758, 3},
    {2, 382, 0, 827, 3},
    {12, 1197, 1, 1324, 3},
    {14, 1203, -1, 1325, 2},
    {24, 173, 2, 758, 3},
    {8, 1202, -1, 1326, 2},
    {8496, 1205, 0, 1327, 3},
    {25400, 1206, 1, 758, 3},
    {2, 385, -1, 826, 2},
    {6, 1208, -1, 828, 2},
    {16, 822, 0, 1258, 3},
    {24, 1199, 1, 920, 3},
    {352, 1209, 2, 758, 3},
    {8, 1211, -1, 1259, 2},
    {8, 1212, -1, 1260, 2},
    {8, 1213, -1, 1328, 2},
    {8, 1214, -1, 1261, 2},
    {8, 1215, -1, 1329, 2},
    {4, 1218, -1, 1054, 2},
    {8, 1219, 0, 1330, 3},
    {16, 173, 1, 758, 3},
    {2, 1223, -1, 1331, 2},
    {8, 456, 0, 1332, 3},
    {16, 173, 1, 758, 3},
    {2, 1223, -1, 1333, 2},
    {8, 173, 0, 758, 3},
    {512, 1226, 1, 1334, 11},
    {520, 1228, 2, 811, 11},
    {536, 1229, 3, 1335, 11},
    {2, 1232, -1, 1336, 2},
    {44, 161, -1, 1076, 2},
    {56, 1233, 0, 758, 3},
    {8, 1234, -1, 1337, 2},
    {568, 173, 0, 758, 3},
    {1072, 1235, 1, 1180, 11},
    {1073, 1236, 2, 1181, 11},
    {2, 1239, -1, 1338, 2},
    {44, 517, -1, 1094, 2},
    {48, 1240, -1, 1076, 2},
    {64, 1241, 0, 758, 3},
    {568, 1242, 1, 1180, 3},
    {569, 1243, 2, 1181, 3},
    {4, 1247, -1, 1339, 2},
    {8, 1248, -1, 1094, 2},
    {12, 1249, -1, 1076, 2},
    {24, 1250, -1, 1340, 2},
    {32, 1251, 0, 758, 3},
    {8, 1254, 0, 1341, 3},
    {5376, 1255, 1, 1179, 3},
    {5384, 1256, 2, 758, 3},
    {5888, 1257, 3, 1180, 3},
    {5889, 1258, 4, 1181, 3},
    {4, 1245, -1, 1339, 2},
    {8, 1262, 0, 1342, 3},
    {8, 1265, 0, 898, 3},
    {5896, 1266, 1, 758, 3},
    {6400, 1267, 2, 1343, 11},
    {7480, 1268, 3, 1197, 11},
    {14848, 1269, 4, 1344, 11},
    {14856, 1270, 5, 1345, 11},
    {15432, 1271, 6, 1346, 11},
    {21328, 1272, 7, 1347, 11},
    {27216, 1273, 8, 1198, 11},
    {28064, 1274, 9, 1348, 11},
    {34040, 1275, 10, 1349, 11},
    {39936, 1276, 11, 1350, 11},
    {2, 615, -1, 1351, 2},
    {4, 1279, -1, 1218, 2},
    {8, 1280, 0, 1219, 3},
    {26, 1281, -1, 1226, 2},
    {32, 1282, 1, 1352, 3},
    {34, 1283, -1, 1353, 2},
    {104, 1284, 2, 758, 3},
    {608, 1285, 3, 1354, 11},
    {620, 1286, 4, 1355, 11},
    {624, 1287, 5, 1356, 11},
    {1, 456, 0, 1357, 3},
    {8, 1290, -1, 1358, 2},
    {31616, 1291, 1, 758, 3},
    {2, 1296, -1, 1359, 2},
    {8, 1297, -1, 1360, 2},
    {12, 1298, 0, 1361, 3},
    {16, 1299, 1, 758, 3},
    {1, 456, 0, 1357, 3},
    {4, 1302, 1, 1362, 3},
    {8, 1303, 2, 1363, 3},
    {10416, 1304, 3, 758, 3},
    {8, 205, -1, 1364, 2},
    {528, 1309, 0, 1365, 3},
    {532, 1310, 1, 1366, 3},
    {536, 1311, 2, 758, 3},
    {2, 244, -1, 1367, 2},
    {4, 1316, 0, 1365, 3},
    {8, 1317, 1, 1366, 3},
    {16, 1318, 2, 758, 3},
    {2, 385, -1, 826, 2},
    {6, 386, -1, 828, 2},
    {16, 1321, 0, 1366, 3},
    {24, 1322, 1, 1368, 3},
    {5232, 1323, 2, 1369, 3},
    {5256, 1324, 3, 758, 3},
    {5760, 1325, 4, 1370, 11},
    {42168, 1326, 5, 1371, 11},
    {2, 385, -1, 826, 2},
    {6, 386, -1, 828, 2},
    {16, 1329, 0, 758, 3},
    {2, 1332, 0, 1372, 3},
    {64, 1333, 1, 1373, 3},
    {235336, 1334, 2, 1374, 3},
    {236904, 1335, 3, 1375, 11},
    {4, 1340, -1, 1376, 2},
    {8, 1341, -1, 1094, 2},
    {12, 1342, -1, 1076, 2},
    {24, 1343, -1, 1377, 2},
    {32, 1344, 0, 758, 3},
    {8, 1347, 0, 1378, 3},
    {5376, 1348, 1, 1179, 3},
    {5384, 1349, 2, 758, 3},
    {5888, 1350, 3, 1180, 3},
    {5889, 1351, 4, 1181, 3},
    {2, 1239, -1, 1338, 2},
    {44, 517, -1, 1094, 2},
    {48, 1353, -1, 1076, 2},
    {64, 1354, 0, 758, 3},
    {568, 1355, 1, 1180, 3},
    {569, 1356, 2, 1181, 3},
    {8, 1358, 0, 1379, 3},
    {5904, 1359, 1, 1346, 3},
    {11800, 1360, 2, 758, 3},
    {12304, 1361, 3, 1349, 11},
    {18200, 1362, 4, 1350, 11},
    {18528, 1363, 5, 1380, 11},
    {4, 1397, -1, 1381, 2},
    {8, 1398, -1, 1382, 2},
    {16, 1399, 0, 758, 3},
    {4, 1407, -1, 1383, 2},
    {8, 1408, 0, 1384, 3},
    {9, 1409, 1, 1385, 3},
    {16, 1410, 2, 758, 3},
    {2, 1406, -1, 1386, 2},
    {8, 1411, -1, 1387, 2},
    {528, 1412, 0, 758, 3},
    {2, 1414, 0, 1388, 3},
    {20, 1415, 1, 1389, 3},
    {38, 1416, 2, 1390, 3},
    {144, 1417, 3, 758, 3},
    {4, 1422, -1, 1381, 2},
    {8, 1423, -1, 1382, 2},
    {16, 1424, 0, 758, 3},
    {2, 1427, 0, 1388, 3},
    {20, 1428, 1, 1389, 3},
    {38, 1429, 2, 1390, 3},
    {144, 1430, 3, 758, 3},
    {2, 1426, -1, 1353, 2},
    {72, 1431, -1, 1391, 2},
    {720, 1432, 0, 758, 3},
    {2, 1402, -1, 1392, 2},
    {4, 1403, -1, 1393, 2},
    {8, 1404, 0, 1394, 3},
    {26, 1405, -1, 1353, 2},
    {96, 1413, -1, 1395, 2},
    {1128, 1418, 1, 1391, 3},
    {1776, 1419, 2, 1396, 3},
    {1780, 1420, 3, 1352, 3},
    {1782, 1421, 4, 1048, 3},
    {1792, 1425, 5, 1397, 3},
    {2312, 1434, 6, 1398, 3},
    {63520, 1435, 7, 758, 3},
    {64024, 1436, 8, 1399, 3},
    {2, 1401, -1, 1400, 2},
    {4, 456, 0, 1357, 3},
    {8, 1438, -1, 1401, 2},
    {3202416, 1439, 1, 758, 3},
    {2, 1395, 0, 1402, 3},
    {104, 1396, 1, 1403, 3},
    {112, 1400, 2, 1397, 3},
    {632, 1440, 3, 1404, 3},
    {3203552, 1441, 4, 1405, 3},
    {3203568, 1442, 5, 758, 3},
    {8, 1444, -1, 1406, 2},
    {24, 1445, 0, 1407, 3},
    {32, 173, 1, 758, 3},
    {2, 456, -1, 1408, 2},
    {2, 1459, -1, 1409, 2},
    {2, 456, -1, 1410, 2},
    {2, 1461, -1, 1411, 2},
    {1, 1503, 0, 1096, 3},
    {2, 1504, 1, 1243, 3},
    {8, 1505, 2, 758, 3},
    {512, 1506, 3, 1412, 11},
    {516, 1507, 4, 1413, 11},
    {520, 1508, 5, 771, 11},
    {521, 1509, 6, 1414, 11},
    {522, 1510, 7, 1415, 11},
    {2, 1522, 0, 1416, 3},
    {16, 1523, 1, 1417, 3},
    {20, 1524, 2, 1418, 3},
    {24, 1525, 3, 1082, 3},
    {25, 1526, 4, 1083, 3},
    {32, 1527, 5, 758, 3},
    {536, 1528, 6, 1419, 11},
    {8, 1190, -1, 921, 2},
    {19216, 456, 0, 1180, 3},
    {19224, 1535, 1, 758, 3},
    {8, 1195, -1, 1255, 2},
    {16912, 847, 0, 1420, 3},
    {16918, 1537, 1, 1421, 3},
    {16920, 456, 2, 1180, 3},
    {16928, 173, 3, 758, 3},
    {8, 1220, -1, 1032, 2},
    {528, 456, 0, 1180, 3},
    {536, 173, 1, 758, 3},
    {8, 1540, 0, 898, 3},
    {5896, 1541, 1, 1197, 3},
    {13264, 1542, 2, 1348, 3},
    {19240, 1543, 3, 1196, 3},
    {25128, 1544, 4, 1198, 3},
    {25976, 1545, 5, 1347, 3},
    {31864, 1546, 6, 1422, 3},
    {32708, 1547, 7, 1344, 3},
    {32709, 1548, 8, 1423, 3},
    {32712, 1549, 9, 1379, 3},
    {38608, 1550, 10, 1346, 3},
    {44504, 1551, 11, 1343, 3},
    {45584, 1552, 12, 1345, 3},
    {46160, 1553, 13, 758, 3},
    {46664, 1554, 14, 1424, 11},
    {46672, 1555, 15, 1349, 11},
    {52568, 1556, 16, 1350, 11},
    {52896, 1557, 17, 1380, 11},
    {53472, 1558, 18, 1425, 11},
    {59360, 1559, 19, 1426, 11},
    {66728, 1560, 20, 1427, 11},
    {72704, 1561, 21, 1428, 11},
    {78592, 1562, 22, 1429, 11},
    {2, 1574, -1, 1158, 2},
    {2, 1575, -1, 1159, 2},
    {2, 1573, -1, 769, 2},
    {14, 1577, 0, 1058, 3},
    {720, 1578, 1, 758, 3},
    {2, 1582, -1, 826, 2},
    {6, 1583, 0, 827, 3},
    {16, 1584, 1, 828, 3},
    {24, 1585, 2, 915, 3},
    {46, 1586, 3, 916, 3},
    {70, 1587, 4, 917, 3},
    {72, 1588, 5, 1430, 3},
    {80, 1589, 6, 758, 3},
    {2, 1591, -1, 826, 2},
    {6, 1592, 0, 827, 3},
    {16, 1593, 1, 828, 3},
    {24, 1594, 2, 1420, 3},
    {30, 1595, 3, 1421, 3},
    {32, 1596, 4, 1430, 3},
    {40, 1597, 5, 758, 3},
    {4, 1599, -1, 1431, 2},
    {8, 1600, 0, 1430, 3},
    {12, 1601, 1, 1432, 3},
    {16, 1602, 2, 758, 3},
    {520, 1603, 3, 1419, 11},
    {8, 1605, 0, 1433, 3},
    {528, 1606, 1, 1430, 3},
    {536, 1607, 2, 758, 3},
    {2, 1617, -1, 826, 2},
    {8, 1618, -1, 921, 2},
    {19216, 1619, 0, 1180, 3},
    {19224, 1620, 1, 758, 3},
    {2, 1622, -1, 826, 2},
    {8, 1623, -1, 1255, 2},
    {16912, 1624, 0, 1420, 3},
    {16918, 1625, 1, 1421, 3},
    {16920, 1626, 2, 1180, 3},
    {16928, 1627, 3, 758, 3},
    {8, 1629, -1, 1092, 2},
    {8, 1630, -1, 1093, 2}
};

#ifdef OSS_SPARTAN_AWARE
#if ((OSS_SPARTAN_AWARE + 0) > 12)
typedef struct ExtParms {
    int           versId;
    const void    *xparm[7];
} ExtParms;
static ExtParms const extParms = {
    25,
    {NULL, NULL, NULL, NULL, (void *)0, (void *)0, (void *)8}
};
#endif /* OSS_SPARTAN_AWARE  > 12 */
#endif /* OSS_SPARTAN_AWARE */

static void * const _enamearray[] = {
    (void *)0,
    (void *)0x3, (void *)_v106,
    (void *)"undetermined", (void *)"invalidFormat", (void *)"newPasswordsMismatch",
    (void *)0x3, (void *)_v106,
    (void *)"enterPW", (void *)"enterNewPW", (void *)"enterNewPW-Again",
    (void *)0x10004, (void *)_v118,
    (void *)"lcsCapabilitySet1", (void *)"lcsCapabilitySet2", (void *)"lcsCapabilitySet3", (void *)"lcsCapabilitySet4",
    (void *)0x3, (void *)_v106,
    (void *)"currentLocation", (void *)"currentOrLastKnownLocation", (void *)"initialLocation",
    (void *)0x3, (void *)_v4, (void *)"activateDeferredLocation", (void *)"cancelDeferredLocation",
    (void *)"oss-unknown-enumerator",
    (void *)0x10004, (void *)_v118,
    (void *)"msAvailable", (void *)"enteringIntoArea", (void *)"leavingFromArea", (void *)"beingInsideArea",
    (void *)0x4, (void *)_v106,
    (void *)"emergencyServices", (void *)"valueAddedServices", (void *)"plmnOperatorServices", (void *)"lawfulInterceptServices",
    (void *)0x1, (void *)_v146, (void *)"oss-unknown-enumerator",
    (void *)0x5, (void *)_v106,
    (void *)"broadcastService", (void *)"o-andM-HPLMN", (void *)"o-andM-VPLMN", (void *)"anonymousLocation", (void *)"targetMSsubscribedService",
    (void *)0x1, (void *)_v146,
    (void *)"oss-unknown-enumerator",
    (void *)0x5, (void *)_v106,
    (void *)"logicalName", (void *)"e-mailAddress", (void *)"msisdn", (void *)"url", (void *)"sipUrl",
    (void *)0x1, (void *)_v146,
    (void *)"oss-unknown-enumerator",
    (void *)0x2, (void *)_v106,
    (void *)"lowdelay", (void *)"delaytolerant",
    (void *)0x1, (void *)_v146, (void *)"oss-unknown-enumerator",
    (void *)0x10007, (void *)_v51,
    (void *)"ellipsoidPoint", (void *)"ellipsoidPointWithUncertaintyCircle", (void *)"ellipsoidPointWithUncertaintyEllipse", (void *)"polygon", (void *)"ellipsoidPointWithAltitude",
    (void *)"ellipsoidPointWithAltitudeAndUncertaintyElipsoid", (void *)"ellipsoidArc",
    (void *)0x5, (void *)_v106,
    (void *)"allowedWithoutNotification", (void *)"allowedWithNotification", (void *)"allowedIfNoResponse", (void *)"restrictedIfNoResponse", (void *)"notAllowed",
    (void *)0x1, (void *)_v146,
    (void *)"oss-unknown-enumerator",
    (void *)0x5, (void *)_v106,
    (void *)"countryCode", (void *)"plmnId", (void *)"locationAreaId", (void *)"routingAreaId", (void *)"cellGlobalId",
    (void *)0x2, (void *)_v18,
    (void *)"utranCellId", (void *)"oss-unknown-enumerator",
    (void *)0x2, (void *)_v106,
    (void *)"oneTimeEvent", (void *)"multipleTimeEvent",
    (void *)0x1, (void *)_v146, (void *)"oss-unknown-enumerator",
    (void *)0x2, (void *)_v106,
    (void *)"requestedAccuracyFulfilled", (void *)"requestedAccuracyNotFulfilled",
    (void *)0x1, (void *)_v146, (void *)"oss-unknown-enumerator",
    (void *)0x3, (void *)_v106,
    (void *)"emergencyCallOrigination", (void *)"emergencyCallRelease", (void *)"mo-lr",
    (void *)0x2, (void *)_v130, (void *)"deferredmt-lrResponse", (void *)"oss-unknown-enumerator",
    (void *)0x6, (void *)_v106,
    (void *)"normal", (void *)"errorundefined", (void *)"internalTimeout", (void *)"congestion", (void *)"mt-lrRestart",
    (void *)"privacyViolation",
    (void *)0x2, (void *)_v26, (void *)"shapeOfLocationEstimateNotSupported", (void *)"oss-unknown-enumerator",
    (void *)0x4, (void *)_v67,
    (void *)"gsm-0408", (void *)"gsm-0806", (void *)"gsm-BSSMAP", (void *)"ets-300102-1",
    (void *)0x1, (void *)_v67,
    (void *)"ets-300356",
    (void *)0x1, (void *)_v146, (void *)"oss-unknown-enumerator",
    (void *)0x2, (void *)_v67,
    (void *)"ts3G-48006", (void *)"ts3G-25413",
    (void *)0x1, (void *)_v146, (void *)"oss-unknown-enumerator",
    (void *)0x8, (void *)_v106,
    (void *)"plmn", (void *)"hlr", (void *)"vlr", (void *)"pvlr", (void *)"controllingMSC",
    (void *)"vmsc", (void *)"eir", (void *)"rss",
    (void *)0x6, (void *)_v106,
    (void *)"sgsn", (void *)"ggsn", (void *)"gmlc", (void *)"gsmSCF", (void *)"nplr",
    (void *)"auc",
    (void *)0x1, (void *)_v146, (void *)"oss-unknown-enumerator",
    (void *)0x3, (void *)_v106,
    (void *)"normal", (void *)"privileged", (void *)"emergency",
    (void *)0x2, (void *)_v36,
    (void *)"plmnRoamingNotAllowed", (void *)"operatorDeterminedBarring",
    (void *)0x2, (void *)_v106,
    (void *)"barringServiceActive", (void *)"operatorBarring",
    (void *)0x4, (void *)_v38,
    (void *)"incomingCallsBarredWithinCUG", (void *)"subscriberNotMemberOfCUG", (void *)"requestedBasicServiceViolatesCUG-Constraints", (void *)"calledPartySS-InteractionViolation",
    (void *)0x7, (void *)_v106,
    (void *)"memoryCapacityExceeded", (void *)"equipmentProtocolError", (void *)"equipmentNotSM-Equipped", (void *)"unknownServiceCentre", (void *)"sc-Congestion",
    (void *)"invalidSME-Address", (void *)"subscriberNotSC-Subscriber",
    (void *)0x2, (void *)_v106,
    (void *)"imsiUnknown", (void *)"gprsSubscriptionUnknown",
    (void *)0x2, (void *)_v121, (void *)"npdbMismatch", (void *)"oss-unknown-enumerator",
    (void *)0x3, (void *)_v106,
    (void *)"imsiDetach", (void *)"restrictedArea", (void *)"noPageResponse",
    (void *)0x2, (void *)_v130, (void *)"purgedMS", (void *)"oss-unknown-enumerator",
    (void *)0x5, (void *)_v106,
    (void *)"noAdditionalInformation", (void *)"clientNotInMSPrivacyExceptionList", (void *)"callToClientNotSetup", (void *)"privacyOverrideNotApplicable", (void *)"disallowedByLocalRegulatoryRequirements",
    (void *)0x4, (void *)_v45,
    (void *)"unauthorizedPrivacyClass", (void *)"unauthorizedCallSessionUnrelatedExternalClient", (void *)"unauthorizedCallSessionRelatedExternalClient", (void *)"oss-unknown-enumerator",
    (void *)0x9, (void *)_v106,
    (void *)"congestion", (void *)"insufficientResources", (void *)"insufficientMeasurementData", (void *)"inconsistentMeasurementData", (void *)"locationProcedureNotCompleted",
    (void *)"locationProcedureNotSupportedByTargetMS", (void *)"qoSNotAttainable", (void *)"positionMethodNotAvailableInNetwork", (void *)"positionMethodNotAvailableInLocationArea",
    (void *)0x1, (void *)_v146, (void *)"oss-unknown-enumerator",
    (void *)0x2, (void *)_v106,
    (void *)"basicCall", (void *)"forwarding",
    (void *)0x3, (void *)_v106,
    (void *)"notReachable", (void *)"busy", (void *)"noReply",
    (void *)0x10004, (void *)_v118,
    (void *)"phase1", (void *)"phase2", (void *)"phase3", (void *)"phase4",
    (void *)0x10007, (void *)_v51,
    (void *)"o-csi", (void *)"d-csi", (void *)"vt-csi", (void *)"t-csi", (void *)"mt-sms-csi",
    (void *)"mg-csi", (void *)"psi-enhancements",
    (void *)0x2, (void *)_v106,
    (void *)"basicISTSupported", (void *)"istCommandSupported",
    (void *)0x1, (void *)_v146, (void *)"oss-unknown-enumerator",
    (void *)0x10002, (void *)_v137,
    (void *)"suppressCUG", (void *)"suppressCCBS",
    (void *)0x1, (void *)_v55,
    (void *)"termAttemptAuthorized",
    (void *)0x3, (void *)_v56, (void *)"tBusy", (void *)"tNoAnswer", (void *)"oss-unknown-enumerator",
    (void *)0x2, (void *)_v106,
    (void *)"continueCall", (void *)"releaseCall",
    (void *)0x1, (void *)_v146, (void *)"oss-unknown-enumerator",
    (void *)0x1, (void *)_v121,
    (void *)"collectedInfo",
    (void *)0x2, (void *)_v60, (void *)"routeSelectFailure", (void *)"oss-unknown-enumerator",
    (void *)0x2, (void *)_v106,
    (void *)"inhibiting", (void *)"enabling",
    (void *)0x2, (void *)_v106,
    (void *)"forwarded", (void *)"notForwarded",
    (void *)0x4, (void *)_v106,
    (void *)"msPurged", (void *)"imsiDetached", (void *)"restrictedArea", (void *)"notRegistered",
    (void *)0x3, (void *)_v106,
    (void *)"notKnownToBePorted", (void *)"ownNumberPortedOut", (void *)"foreignNumberPortedToForeignNetwork",
    (void *)0x3, (void *)_v65, (void *)"ownNumberNotPortedOut", (void *)"foreignNumberPortedIn",
    (void *)"oss-unknown-enumerator",
    (void *)0x10002, (void *)_v137,
    (void *)"firstServiceAllowed", (void *)"secondServiceAllowed",
    (void *)0x6, (void *)_v67,
    (void *)"bearerServiceNotProvisioned", (void *)"teleserviceNotProvisioned", (void *)"absentSubscriber", (void *)"busySubscriber", (void *)"callBarred",
    (void *)"cug-Reject",
    (void *)0x1, (void *)_v146, (void *)"oss-unknown-enumerator",
    (void *)0x2, (void *)_v106,
    (void *)"stopMonitoring", (void *)"startMonitoring",
    (void *)0x1, (void *)_v146, (void *)"oss-unknown-enumerator",
    (void *)0x3, (void *)_v106,
    (void *)"ccbsNotIdle", (void *)"ccbsIdle", (void *)"ccbsNotReachable",
    (void *)0x1, (void *)_v146, (void *)"oss-unknown-enumerator",
    (void *)0x2, (void *)_v106,
    (void *)"a-side", (void *)"b-side",
    (void *)0x1, (void *)_v146, (void *)"oss-unknown-enumerator",
    (void *)0x3, (void *)_v106,
    (void *)"success", (void *)"failure", (void *)"busy",
    (void *)0x1, (void *)_v146, (void *)"oss-unknown-enumerator",
    (void *)0x6, (void *)_v106,
    (void *)"accepted", (void *)"rejected", (void *)"noResponseFromFreeMS", (void *)"noResponseFromBusyMS", (void *)"udubFromFreeMS",
    (void *)"udubFromBusyMS",
    (void *)0x1, (void *)_v146, (void *)"oss-unknown-enumerator",
    (void *)0x2, (void *)_v106,
    (void *)"terminateCallActivityReferred", (void *)"terminateAllCallActivities",
    (void *)0x1, (void *)_v146, (void *)"oss-unknown-enumerator",
    (void *)0x3, (void *)_v106,
    (void *)"permanent", (void *)"temporaryDefaultRestricted", (void *)"temporaryDefaultAllowed",
    (void *)0x2, (void *)_v106,
    (void *)"overrideEnabled", (void *)"overrideDisabled",
    (void *)0x7, (void *)_v106,
    (void *)"request", (void *)"recall", (void *)"active", (void *)"completed", (void *)"suspended",
    (void *)"frozen", (void *)"deleted",
    (void *)0x10002, (void *)_v137,
    (void *)"clir-invoked", (void *)"camel-invoked",
    (void *)0x3, (void *)_v106,
    (void *)"memoryCapacityExceeded", (void *)"absentSubscriber", (void *)"successfulTransfer",
    (void *)0x10004, (void *)_v118,
    (void *)"sc-AddressNotIncluded", (void *)"mnrf-Set", (void *)"mcef-Set", (void *)"mnrg-Set",
    (void *)0x2, (void *)_v106,
    (void *)"ms-Present", (void *)"memoryAvailable",
    (void *)0x3, (void *)_v106,
    (void *)"minimum", (void *)"medium", (void *)"maximum",
    (void *)0x1, (void *)_v146, (void *)"oss-unknown-enumerator",
    (void *)0x10006, (void *)_v90,
    (void *)"msc-s", (void *)"mgw", (void *)"sgsn", (void *)"ggsn", (void *)"rnc",
    (void *)"bm-sc",
    (void *)0x2000a, (void *)_v91,
    (void *)"a", (void *)"iu", (void *)"mc", (void *)"map-g", (void *)"map-b",
    (void *)"map-e", (void *)"map-f", (void *)"cap", (void *)"map-d", (void *)"map-c",
    (void *)0x10003, (void *)_v119,
    (void *)"mc", (void *)"nb-up", (void *)"iu-up",
    (void *)0x10008, (void *)_v117,
    (void *)"gb", (void *)"iu", (void *)"gn", (void *)"map-gr", (void *)"map-gd",
    (void *)"map-gf", (void *)"gs", (void *)"ge",
    (void *)0x10003, (void *)_v119,
    (void *)"gn", (void *)"gi", (void *)"gmb",
    (void *)0x10004, (void *)_v118,
    (void *)"iu", (void *)"iur", (void *)"iub", (void *)"uu",
    (void *)0x10001, (void *)_v101,
    (void *)"gmb",
    (void *)0x10005, (void *)_v97,
    (void *)"mo-mtCall", (void *)"mo-mt-sms", (void *)"lu-imsiAttach-imsiDetach", (void *)"handovers", (void *)"ss",
    (void *)0x10001, (void *)_v101,
    (void *)"context",
    (void *)0x10004, (void *)_v118,
    (void *)"pdpContext", (void *)"mo-mt-sms", (void *)"rau-gprsAttach-gprsDetach", (void *)"mbmsContext",
    (void *)0x10002, (void *)_v137,
    (void *)"pdpContext", (void *)"mbmsContext",
    (void *)0x10001, (void *)_v101,
    (void *)"mbmsMulticastServiceActivation",
    (void *)0x10002, (void *)_v137,
    (void *)"utran", (void *)"geran",
    (void *)0x2, (void *)_v106,
    (void *)"updateProcedure", (void *)"subscriptionWithdraw",
    (void *)0x1, (void *)_v146, (void *)"oss-unknown-enumerator",
    (void *)0x2, (void *)_v106,
    (void *)"wrongUserResponse", (void *)"wrongNetworkSignature",
    (void *)0xa, (void *)_v106,
    (void *)"call", (void *)"emergencyCall", (void *)"locationUpdating", (void *)"supplementaryService", (void *)"shortMessage",
    (void *)"gprsAttach", (void *)"routingAreaUpdating", (void *)"serviceRequest", (void *)"pdpContextActivation", (void *)"pdpContextDeactivation",
    (void *)0x2, (void *)_v107,
    (void *)"gprsDetach", (void *)"oss-unknown-enumerator",
    (void *)0x2, (void *)_v106,
    (void *)"old", (void *)"new",
    (void *)0x1, (void *)_v146, (void *)"oss-unknown-enumerator",
    (void *)0x2, (void *)_v106,
    (void *)"vlr", (void *)"sgsn",
    (void *)0x1, (void *)_v146, (void *)"oss-unknown-enumerator",
    (void *)0x10002, (void *)_v137,
    (void *)"equipmentStatus", (void *)"bmuef",
    (void *)0x3, (void *)_v106,
    (void *)"whiteListed", (void *)"blackListed", (void *)"greyListed",
    (void *)0x2, (void *)_v106,
    (void *)"serviceGranted", (void *)"operatorDeterminedBarring",
    (void *)0x3, (void *)_v106,
    (void *)"noCUG-Restrictions", (void *)"cugIC-CallBarred", (void *)"cugOG-CallBarred",
    (void *)0x4001d, (void *)_v117,
    (void *)"allOG-CallsBarred", (void *)"internationalOGCallsBarred", (void *)"internationalOGCallsNotToHPLMN-CountryBarred", (void *)"premiumRateInformationOGCallsBarred", (void *)"premiumRateEntertainementOGCallsBarred",
    (void *)"ss-AccessBarred", (void *)"interzonalOGCallsBarred", (void *)"interzonalOGCallsNotToHPLMN-CountryBarred", (void *)"interzonalOGCallsAndInternationalOGCallsNotToHPLMN-CountryBarred", (void *)"allECT-Barred",
    (void *)"chargeableECT-Barred", (void *)"internationalECT-Barred", (void *)"interzonalECT-Barred", (void *)"doublyChargeableECT-Barred", (void *)"multipleECT-Barred",
    (void *)"allPacketOrientedServicesBarred", (void *)"roamerAccessToHPLMN-AP-Barred", (void *)"roamerAccessToVPLMN-AP-Barred", (void *)"roamingOutsidePLMNOG-CallsBarred", (void *)"allIC-CallsBarred",
    (void *)"roamingOutsidePLMNIC-CallsBarred", (void *)"roamingOutsidePLMNICountryIC-CallsBarred", (void *)"roamingOutsidePLMN-Barred", (void *)"roamingOutsidePLMN-CountryBarred", (void *)"registrationAllCF-Barred",
    (void *)"registrationCFNotToHPLMN-Barred", (void *)"registrationInterzonalCF-Barred", (void *)"registrationInterzonalCFNotToHPLMN-Barred", (void *)"registrationInternationalCF-Barred",
    (void *)0x10004, (void *)_v118,
    (void *)"plmn-SpecificBarringType1", (void *)"plmn-SpecificBarringType2", (void *)"plmn-SpecificBarringType3", (void *)"plmn-SpecificBarringType4",
    (void *)0x10003, (void *)_v119,
    (void *)"privilegedUplinkRequest", (void *)"emergencyUplinkRequest", (void *)"emergencyReset",
    (void *)0x1, (void *)_v67,
    (void *)"sms-CollectedInfo",
    (void *)0x2, (void *)_v121, (void *)"sms-DeliveryRequest", (void *)"oss-unknown-enumerator",
    (void *)0x2, (void *)_v106,
    (void *)"continueTransaction", (void *)"releaseTransaction",
    (void *)0x1, (void *)_v146, (void *)"oss-unknown-enumerator",
    (void *)0x3, (void *)_v106,
    (void *)"sms-DELIVER", (void *)"sms-SUBMIT-REPORT", (void *)"sms-STATUS-REPORT",
    (void *)0x1, (void *)_v146, (void *)"oss-unknown-enumerator",
    (void *)0x3, (void *)_v106,
    (void *)"bothMSCAndSGSN", (void *)"onlyMSC", (void *)"onlySGSN",
    (void *)0x1, (void *)_v146, (void *)"oss-unknown-enumerator",
    (void *)0x2, (void *)_v106,
    (void *)"accessOutsideLSAsAllowed", (void *)"accessOutsideLSAsRestricted",
    (void *)0x3, (void *)_v106,
    (void *)"notifyLocationAllowed", (void *)"notifyAndVerify-LocationAllowedIfNoResponse", (void *)"notifyAndVerify-LocationNotAllowedIfNoResponse",
    (void *)0x2, (void *)_v130, (void *)"locationNotAllowed", (void *)"oss-unknown-enumerator",
    (void *)0x2, (void *)_v106,
    (void *)"gmlc-List", (void *)"home-Country",
    (void *)0x1, (void *)_v146, (void *)"oss-unknown-enumerator",
    (void *)0x5, (void *)_v133,
    (void *)"attach", (void *)"attachChangeOfPosition", (void *)"pdp-ContextEstablishment", (void *)"pdp-ContextEstablishmentAcknowledgement", (void *)"pdp-ContextChangeOfPosition",
    (void *)0x1, (void *)_v146,
    (void *)"oss-unknown-enumerator",
    (void *)0x10002, (void *)_v137,
    (void *)"utranNotAllowed", (void *)"geranNotAllowed",
    (void *)0x2, (void *)_v106,
    (void *)"static", (void *)"dynamic",
    (void *)0x4, (void *)_v106,
    (void *)"networkNode-AreaRestricted", (void *)"tooManyZoneCodes", (void *)"zoneCodesConflict", (void *)"regionalSubscNotSupported",
    (void *)0x2000e, (void *)_v140,
    (void *)"o-csi", (void *)"ss-csi", (void *)"tif-csi", (void *)"d-csi", (void *)"vt-csi",
    (void *)"mo-sms-csi", (void *)"m-csi", (void *)"gprs-csi", (void *)"t-csi", (void *)"mt-sms-csi",
    (void *)"mg-csi", (void *)"o-IM-CSI", (void *)"d-IM-CSI", (void *)"vt-IM-CSI",
    (void *)0x30014, (void *)_v141,
    (void *)"initiateCallAttempt", (void *)"splitLeg", (void *)"moveLeg", (void *)"disconnectLeg", (void *)"entityReleased",
    (void *)"dfc-WithArgument", (void *)"playTone", (void *)"dtmf-MidCall", (void *)"chargingIndicator", (void *)"alertingDP",
    (void *)"locationAtAlerting", (void *)"changeOfPositionDP", (void *)"or-Interactions", (void *)"warningToneEnhancements", (void *)"cf-Enhancements",
    (void *)"subscribedEnhancedDialledServices", (void *)"servingNetworkEnhancedDialledServices", (void *)"criteriaForChangeOfPositionDP", (void *)"serviceChangeDP", (void *)"collectInformation",
    (void *)0x2, (void *)_v106,
    (void *)"cs-Domain", (void *)"ps-Domain",
    (void *)0x1, (void *)_v146, (void *)"oss-unknown-enumerator",
    (void *)0x9, (void *)_v106,
    (void *)"o-CSI", (void *)"t-CSI", (void *)"vt-CSI", (void *)"tif-CSI", (void *)"gprs-CSI",
    (void *)"mo-sms-CSI", (void *)"ss-CSI", (void *)"m-CSI", (void *)"d-csi",
    (void *)0x5, (void *)_v106,
    (void *)"mt-sms-CSI", (void *)"mg-csi", (void *)"o-IM-CSI", (void *)"d-IM-CSI", (void *)"vt-IM-CSI",
    (void *)0x1, (void *)_v146,
    (void *)"oss-unknown-enumerator",
    (void *)0x2, (void *)_v106,
    (void *)"deactivate", (void *)"activate",
    (void *)"mlcNumber",
    (void *)"targetMS",
    (void *)"extensionContainer",
    (void *)"lcsLocationInfo",
    (void *)"v-gmlc-Address",
    (void *)"h-gmlc-Address",
    (void *)"ppr-Address",
    (void *)"additional-v-gmlc-Address",
    (void *)"locationType",
    (void *)"mlc-Number",
    (void *)"lcs-ClientID",
    (void *)"privacyOverride",
    (void *)"imsi",
    (void *)"msisdn",
    (void *)"lmsi",
    (void *)"imei",
    (void *)"lcs-Priority",
    (void *)"lcs-QoS",
    (void *)"supportedGADShapes",
    (void *)"lcs-ReferenceNumber",
    (void *)"lcsServiceTypeID",
    (void *)"lcsCodeword",
    (void *)"lcs-PrivacyCheck",
    (void *)"areaEventInfo",
    (void *)"locationEstimate",
    (void *)"ageOfLocationEstimate",
    (void *)"add-LocationEstimate",
    (void *)"deferredmt-lrResponseIndicator",
    (void *)"geranPositioningData",
    (void *)"utranPositioningData",
    (void *)"cellIdOrSai",
    (void *)"sai-Present",
    (void *)"accuracyFulfilmentIndicator",
    (void *)"velocityEstimate",
    (void *)"lcs-Event",
    (void *)"na-ESRD",
    (void *)"na-ESRK",
    (void *)"slr-ArgExtensionContainer",
    (void *)"deferredmt-lrData",
    (void *)"pseudonymIndicator",
    (void *)"securityHeader",
    (void *)"protectedPayload",
    (void *)"tmsi",
    (void *)"teleservice",
    (void *)"asciCallReference",
    (void *)"codec-Info",
    (void *)"cipheringAlgorithm",
    (void *)"groupKeyNumber-Vk-Id",
    (void *)"groupKey",
    (void *)"priority",
    (void *)"uplinkFree",
    (void *)"vstk",
    (void *)"vstk-rand",
    (void *)"groupCallNumber",
    (void *)"talkerPriority",
    (void *)"additionalInfo",
    (void *)"uplinkRequestAck",
    (void *)"uplinkReleaseIndication",
    (void *)"uplinkRejectCommand",
    (void *)"uplinkSeizedCommand",
    (void *)"uplinkReleaseCommand",
    (void *)"stateAttributes",
    (void *)"emergencyModeResetCommandFlag",
    (void *)"sm-RP-UI",
    (void *)"uplinkRequest",
    (void *)"releaseGroupCall",
    (void *)"roamingNotAllowedCause",
    (void *)"callBarringCause",
    (void *)"extensibleCallBarredParam",
    (void *)"cug-RejectCause",
    (void *)"ss-Code",
    (void *)"basicService",
    (void *)"ss-Status",
    (void *)"sm-EnumeratedDeliveryFailureCause",
    (void *)"diagnosticInfo",
    (void *)"absentSubscriberDiagnosticSM",
    (void *)"additionalAbsentSubscriberDiagnosticSM",
    (void *)"networkResource",
    (void *)"extensibleSystemFailureParam",
    (void *)"shapeOfLocationEstimateNotSupported",
    (void *)"neededLcsCapabilityNotSupportedInServingNode",
    (void *)"unknownSubscriberDiagnostic",
    (void *)"absentSubscriberReason",
    (void *)"ccbs-Possible",
    (void *)"ccbs-Busy",
    (void *)"gprsConnectionSuspended",
    (void *)"unauthorizedLCSClient-Diagnostic",
    (void *)"positionMethodFailure-Diagnostic",
    (void *)"cug-CheckInfo",
    (void *)"numberOfForwarding",
    (void *)"interrogationType",
    (void *)"or-Interrogation",
    (void *)"or-Capability",
    (void *)"gmsc-OrGsmSCF-Address",
    (void *)"callReferenceNumber",
    (void *)"forwardingReason",
    (void *)"basicServiceGroup",
    (void *)"networkSignalInfo",
    (void *)"camelInfo",
    (void *)"suppressionOfAnnouncement",
    (void *)"alertingPattern",
    (void *)"ccbs-Call",
    (void *)"supportedCCBS-Phase",
    (void *)"additionalSignalInfo",
    (void *)"istSupportIndicator",
    (void *)"pre-pagingSupported",
    (void *)"callDiversionTreatmentIndicator",
    (void *)"longFTN-Supported",
    (void *)"suppress-VT-CSI",
    (void *)"suppressIncomingCallBarring",
    (void *)"gsmSCF-InitiatedCall",
    (void *)"basicServiceGroup2",
    (void *)"networkSignalInfo2",
    (void *)"suppressMTSS",
    (void *)"mtRoamingRetrySupported",
    (void *)"callPriority",
    (void *)"extendedRoutingInfo",
    (void *)"cugSubscriptionFlag",
    (void *)"subscriberInfo",
    (void *)"ss-List",
    (void *)"forwardingInterrogationRequired",
    (void *)"vmsc-Address",
    (void *)"naea-PreferredCI",
    (void *)"ccbs-Indicators",
    (void *)"numberPortabilityStatus",
    (void *)"istAlertTimer",
    (void *)"supportedCamelPhasesInVMSC",
    (void *)"offeredCamel4CSIsInVMSC",
    (void *)"routingInfo2",
    (void *)"ss-List2",
    (void *)"basicService2",
    (void *)"allowedServices",
    (void *)"unavailabilityCause",
    (void *)"releaseResourcesSupported",
    (void *)"gsm-BearerCapability",
    (void *)"msc-Number",
    (void *)"gmsc-Address",
    (void *)"supportedCamelPhasesInInterrogatingNode",
    (void *)"orNotSupportedInGMSC",
    (void *)"offeredCamel4CSIsInInterrogatingNode",
    (void *)"roamingNumber",
    (void *)"forwardingData",
    (void *)"o-CSI",
    (void *)"uu-Data",
    (void *)"allInformationSent",
    (void *)"d-csi",
    (void *)"o-BcsmCamelTDPCriteriaList",
    (void *)"ccbs-Monitoring",
    (void *)"ccbs-SubscriberStatus",
    (void *)"eventReportData",
    (void *)"callReportdata",
    (void *)"callInfo",
    (void *)"ccbs-Feature",
    (void *)"translatedB-Number",
    (void *)"replaceB-Number",
    (void *)"ruf-Outcome",
    (void *)"istInformationWithdraw",
    (void *)"callTerminationIndicator",
    (void *)"msrn",
    (void *)"forwardedToNumber",
    (void *)"forwardedToSubaddress",
    (void *)"noReplyConditionTime",
    (void *)"defaultPriority",
    (void *)"nbrUser",
    (void *)"basicServiceGroupList",
    (void *)"forwardingFeatureList",
    (void *)"genericServiceInfo",
    (void *)"ussd-DataCodingScheme",
    (void *)"ussd-String",
    (void *)"ss-Event",
    (void *)"ss-EventSpecification",
    (void *)"b-subscriberNumber",
    (void *)"ccbs-RequestState",
    (void *)"ccbs-Data",
    (void *)"ccbs-Index",
    (void *)"sm-RP-PRI",
    (void *)"serviceCentreAddress",
    (void *)"gprsSupportIndicator",
    (void *)"sm-RP-MTI",
    (void *)"sm-RP-SMEA",
    (void *)"locationInfoWithLMSI",
    (void *)"sm-RP-DA",
    (void *)"sm-RP-OA",
    (void *)"moreMessagesToSend",
    (void *)"sm-DeliveryOutcome",
    (void *)"deliveryOutcomeIndicator",
    (void *)"additionalSM-DeliveryOutcome",
    (void *)"storedMSISDN",
    (void *)"mw-Status",
    (void *)"alertReason",
    (void *)"alertReasonIndicator",
    (void *)"dispatcherList",
    (void *)"ongoingCall",
    (void *)"traceReference",
    (void *)"traceType",
    (void *)"omc-Id",
    (void *)"traceReference2",
    (void *)"traceDepthList",
    (void *)"traceNE-TypeList",
    (void *)"traceInterfaceList",
    (void *)"traceEventList",
    (void *)"traceSupportIndicator",
    (void *)"vlr-Number",
    (void *)"vlr-Capability",
    (void *)"informPreviousNetworkEntity",
    (void *)"cs-LCS-NotSupportedByUE",
    (void *)"add-info",
    (void *)"hlr-Number",
    (void *)"add-Capability",
    (void *)"identity",
    (void *)"cancellationType",
    (void *)"sgsn-Number",
    (void *)"freezeTMSI",
    (void *)"freezeP-TMSI",
    (void *)"numberOfRequestedVectors",
    (void *)"segmentationProhibited",
    (void *)"previous-LAI",
    (void *)"hopCounter",
    (void *)"authenticationSetList",
    (void *)"currentSecurityContext",
    (void *)"failureCause",
    (void *)"re-attempt",
    (void *)"accessType",
    (void *)"rand",
    (void *)"sgsn-Address",
    (void *)"sgsn-Capability",
    (void *)"ps-LCS-NotSupportedByUE",
    (void *)"an-APDU",
    (void *)"integrityProtectionInfo",
    (void *)"encryptionInfo",
    (void *)"keyStatus",
    (void *)"allowedGSM-Algorithms",
    (void *)"allowedUMTS-Algorithms",
    (void *)"radioResourceInformation",
    (void *)"radioResourceList",
    (void *)"bssmap-ServiceHandover",
    (void *)"ranap-ServiceHandover",
    (void *)"bssmap-ServiceHandoverList",
    (void *)"currentlyUsedCodec",
    (void *)"iuSupportedCodecsList",
    (void *)"rab-ConfigurationIndicator",
    (void *)"iuSelectedCodec",
    (void *)"alternativeChannelType",
    (void *)"tracePropagationParameters",
    (void *)"targetCellId",
    (void *)"ho-NumberNotRequired",
    (void *)"targetRNCId",
    (void *)"multipleBearerRequested",
    (void *)"rab-Id",
    (void *)"geran-classmark",
    (void *)"iuCurrentlyUsedCodec",
    (void *)"uesbi-Iu",
    (void *)"imeisv",
    (void *)"handoverNumber",
    (void *)"relocationNumberList",
    (void *)"multicallBearerInfo",
    (void *)"multipleBearerNotSupported",
    (void *)"selectedUMTS-Algorithms",
    (void *)"chosenRadioResourceInformation",
    (void *)"iuAvailableCodecsList",
    (void *)"targetMSC-Number",
    (void *)"selectedRab-Id",
    (void *)"selectedGSM-Algorithm",
    (void *)"iUSelectedCodec",
    (void *)"immediateResponsePreferred",
    (void *)"re-synchronisationInfo",
    (void *)"requestingNodeType",
    (void *)"requestingPLMN-Id",
    (void *)"requestedEquipmentInfo",
    (void *)"equipmentStatus",
    (void *)"bmuef",
    (void *)"category",
    (void *)"subscriberStatus",
    (void *)"bearerServiceList",
    (void *)"teleserviceList",
    (void *)"provisionedSS",
    (void *)"odb-Data",
    (void *)"roamingRestrictionDueToUnsupportedFeature",
    (void *)"regionalSubscriptionData",
    (void *)"vbsSubscriptionData",
    (void *)"vgcsSubscriptionData",
    (void *)"vlrCamelSubscriptionInfo",
    (void *)"gprsSubscriptionData",
    (void *)"roamingRestrictedInSgsnDueToUnsupportedFeature",
    (void *)"networkAccessMode",
    (void *)"lsaInformation",
    (void *)"lmu-Indicator",
    (void *)"lcsInformation",
    (void *)"superChargerSupportedInHLR",
    (void *)"mc-SS-Info",
    (void *)"cs-AllocationRetentionPriority",
    (void *)"sgsn-CAMEL-SubscriptionInfo",
    (void *)"chargingCharacteristics",
    (void *)"accessRestrictionData",
    (void *)"ics-Indicator",
    (void *)"eps-SubscriptionData",
    (void *)"csg-SubscriptionDataList",
    (void *)"ue-ReachabilityRequestIndicator",
    (void *)"odb-GeneralData",
    (void *)"regionalSubscriptionResponse",
    (void *)"supportedCamelPhases",
    (void *)"offeredCamel4CSIs",
    (void *)"basicServiceList",
    (void *)"regionalSubscriptionIdentifier",
    (void *)"vbsGroupIndication",
    (void *)"vgcsGroupIndication",
    (void *)"camelSubscriptionInfoWithdraw",
    (void *)"gprsSubscriptionDataWithdraw",
    (void *)"roamingRestrictedInSgsnDueToUnsuppportedFeature",
    (void *)"lsaInformationWithdraw",
    (void *)"gmlc-ListWithdraw",
    (void *)"specificCSI-Withdraw",
    (void *)"chargingCharacteristicsWithdraw",
    (void *)"ggsn-Address",
    (void *)"ggsn-Number",
    (void *)"mobileNotReachableReason",
    (void *)"hlr-List",
    (void *)"msNotReachable",
    (void *)"requestedInfo",
    (void *)"subscriberIdentity",
    (void *)"gsmSCF-Address",
    (void *)"requestedSubscriptionInfo",
    (void *)"callForwardingData",
    (void *)"callBarringData",
    (void *)"odb-Info",
    (void *)"camel-SubscriptionInfo",
    (void *)"supportedVLR-CAMEL-Phases",
    (void *)"supportedSGSN-CAMEL-Phases",
    (void *)"offeredCamel4CSIsInVLR",
    (void *)"offeredCamel4CSIsInSGSN",
    (void *)"msisdn-BS-List",
    (void *)"modificationRequestFor-CF-Info",
    (void *)"modificationRequestFor-CB-Info",
    (void *)"modificationRequestFor-CSI",
    (void *)"modificationRequestFor-ODB-data",
    (void *)"ss-InfoFor-CSE",
    (void *)"forwardingInfoFor-CSE",
    (void *)"callBarringInfoFor-CSE",
    (void *)"serviceKey",
    (void *)"eventMet",
    (void *)"locationInformation",
    (void *)"supportedCAMELPhases",
    (void *)"locationInformationGPRS",
    (void *)"offeredCamel4Functionalities",
    (void *)"extId",
    (void *)"extType",
    (void *)"privateExtensionList",
    (void *)"pcs-Extensions",
    (void *)"networkNode-Number",
    (void *)"gprsNodeIndicator",
    (void *)"additional-Number",
    (void *)"supportedLCS-CapabilitySets",
    (void *)"additional-LCS-CapabilitySets",
    (void *)"locationEstimateType",
    (void *)"deferredLocationEventType",
    (void *)"externalAddress",
    (void *)"dataCodingScheme",
    (void *)"nameString",
    (void *)"lcs-FormatIndicator",
    (void *)"requestorIDString",
    (void *)"lcsClientType",
    (void *)"lcsClientExternalID",
    (void *)"lcsClientDialedByMS",
    (void *)"lcsClientInternalID",
    (void *)"lcsClientName",
    (void *)"lcsAPN",
    (void *)"lcsRequestorID",
    (void *)"responseTimeCategory",
    (void *)"horizontal-accuracy",
    (void *)"verticalCoordinateRequest",
    (void *)"vertical-accuracy",
    (void *)"responseTime",
    (void *)"velocityRequest",
    (void *)"lcsCodewordString",
    (void *)"callSessionUnrelated",
    (void *)"callSessionRelated",
    (void *)"areaType",
    (void *)"areaIdentification",
    (void *)"areaList",
    (void *)"areaDefinition",
    (void *)"occurrenceInfo",
    (void *)"intervalTime",
    (void *)"cellGlobalIdOrServiceAreaIdFixedLength",
    (void *)"laiFixedLength",
    (void *)"na-ESRK-Request",
    (void *)"slr-Arg-PCS-Extensions",
    (void *)"terminationCause",
    (void *)"localValue",
    (void *)"globalValue",
    (void *)"operationCode",
    (void *)"errorCode",
    (void *)"userInfo",
    (void *)"securityParametersIndex",
    (void *)"originalComponentIdentifier",
    (void *)"initialisationVector",
    (void *)"protocolId",
    (void *)"signalInfo",
    (void *)"ext-ProtocolId",
    (void *)"accessNetworkProtocolId",
    (void *)"imsi-WithLMSI",
    (void *)"naea-PreferredCIC",
    (void *)"bearerService",
    (void *)"ext-BearerService",
    (void *)"ext-Teleservice",
    (void *)"maximumentitledPriority",
    (void *)"nbrSB",
    (void *)"downlinkAttached",
    (void *)"uplinkAttached",
    (void *)"dualCommunication",
    (void *)"callOriginator",
    (void *)"ExtensionType",
    (void *)"extensionId",
    (void *)"_oss_unique_index",
    (void *)"unauthorisedMessageOriginator",
    (void *)"additionalNetworkResource",
    (void *)"cug-Interlock",
    (void *)"cug-OutgoingAccess",
    (void *)"suppress-T-CSI",
    (void *)"forwardingOptions",
    (void *)"longForwardedToNumber",
    (void *)"t-BcsmTriggerDetectionPoint",
    (void *)"defaultCallHandling",
    (void *)"t-BcsmCamelTDPDataList",
    (void *)"camelCapabilityHandling",
    (void *)"notificationToCSE",
    (void *)"csi-Active",
    (void *)"o-BcsmTriggerDetectionPoint",
    (void *)"o-BcsmCamelTDPDataList",
    (void *)"csiActive",
    (void *)"matchType",
    (void *)"destinationNumberList",
    (void *)"destinationNumberLengthList",
    (void *)"destinationNumberCriteria",
    (void *)"basicServiceCriteria",
    (void *)"callTypeCriteria",
    (void *)"o-CauseValueCriteria",
    (void *)"t-BCSM-TriggerDetectionPoint",
    (void *)"t-CauseValueCriteria",
    (void *)"dialledNumber",
    (void *)"dp-AnalysedInfoCriteriaList",
    (void *)"t-CSI",
    (void *)"o-BcsmCamelTDP-CriteriaList",
    (void *)"t-BCSM-CAMEL-TDP-CriteriaList",
    (void *)"gmscCamelSubscriptionInfo",
    (void *)"routingInfo",
    (void *)"camelRoutingInfo",
    (void *)"ageOfLocationInformation",
    (void *)"geographicalInformation",
    (void *)"vlr-number",
    (void *)"locationNumber",
    (void *)"cellGlobalIdOrServiceAreaIdOrLAI",
    (void *)"selectedLSA-Id",
    (void *)"geodeticInformation",
    (void *)"currentLocationRetrieved",
    (void *)"assumedIdle",
    (void *)"camelBusy",
    (void *)"netDetNotReachable",
    (void *)"notProvidedFromVLR",
    (void *)"routeingAreaIdentity",
    (void *)"selectedLSAIdentity",
    (void *)"pdp-ContextIdentifier",
    (void *)"pdp-ContextActive",
    (void *)"pdp-Type",
    (void *)"pdp-Address",
    (void *)"apn-Subscribed",
    (void *)"apn-InUse",
    (void *)"nsapi",
    (void *)"transactionId",
    (void *)"teid-ForGnAndGp",
    (void *)"teid-ForIu",
    (void *)"qos-Subscribed",
    (void *)"qos-Requested",
    (void *)"qos-Negotiated",
    (void *)"chargingId",
    (void *)"rnc-Address",
    (void *)"qos2-Subscribed",
    (void *)"qos2-Requested",
    (void *)"qos2-Negotiated",
    (void *)"notProvidedFromSGSN",
    (void *)"ps-Detached",
    (void *)"ps-AttachedNotReachableForPaging",
    (void *)"ps-AttachedReachableForPaging",
    (void *)"ps-PDP-ActiveNotReachableForPaging",
    (void *)"ps-PDP-ActiveReachableForPaging",
    (void *)"mSNetworkCapability",
    (void *)"mSRadioAccessCapability",
    (void *)"routeingNumber",
    (void *)"subscriberState",
    (void *)"ps-SubscriberState",
    (void *)"ms-Classmark2",
    (void *)"gprs-MS-Class",
    (void *)"mnpInfoRes",
    (void *)"keepCCBS-CallIndicator",
    (void *)"uuIndicator",
    (void *)"uui",
    (void *)"uusCFInteraction",
    (void *)"monitoringMode",
    (void *)"callOutcome",
    (void *)"b-subscriberSubaddress",
    (void *)"callBarringFeatureList",
    (void *)"cliRestrictionOption",
    (void *)"overrideCategory",
    (void *)"ss-SubscriptionOption",
    (void *)"forwardingInfo",
    (void *)"callBarringInfo",
    (void *)"ss-Data",
    (void *)"maximumEntitledPriority",
    (void *)"ccbs-FeatureList",
    (void *)"nbrSN",
    (void *)"serviceIndicator",
    (void *)"serviceCentreAddressDA",
    (void *)"noSM-RP-DA",
    (void *)"serviceCentreAddressOA",
    (void *)"noSM-RP-OA",
    (void *)"msc-s-TraceDepth",
    (void *)"mgw-TraceDepth",
    (void *)"sgsn-TraceDepth",
    (void *)"ggsn-TraceDepth",
    (void *)"rnc-TraceDepth",
    (void *)"bmsc-TraceDepth",
    (void *)"msc-s-List",
    (void *)"mgw-List",
    (void *)"sgsn-List",
    (void *)"ggsn-List",
    (void *)"rnc-List",
    (void *)"bmsc-List",
    (void *)"sendSubscriberData",
    (void *)"subscriberDataStored",
    (void *)"solsaSupportIndicator",
    (void *)"superChargerSupportedInServingNetworkEntity",
    (void *)"supportedRAT-TypesIndicator",
    (void *)"longGroupID-Supported",
    (void *)"skipSubscriberDataUpdate",
    (void *)"sres",
    (void *)"kc",
    (void *)"xres",
    (void *)"ck",
    (void *)"ik",
    (void *)"autn",
    (void *)"tripletList",
    (void *)"quintupletList",
    (void *)"cksn",
    (void *)"ksi",
    (void *)"gsm-SecurityContextData",
    (void *)"umts-SecurityContextData",
    (void *)"gprsEnhancementsSupportIndicator",
    (void *)"smsCallBarringSupportIndicator",
    (void *)"integrityProtectionAlgorithms",
    (void *)"encryptionAlgorithms",
    (void *)"codec1",
    (void *)"codec2",
    (void *)"codec3",
    (void *)"codec4",
    (void *)"codec5",
    (void *)"codec6",
    (void *)"codec7",
    (void *)"codec8",
    (void *)"utranCodecList",
    (void *)"geranCodecList",
    (void *)"uesbi-IuA",
    (void *)"uesbi-IuB",
    (void *)"integrityProtectionAlgorithm",
    (void *)"encryptionAlgorithm",
    (void *)"chosenChannelInfo",
    (void *)"chosenSpeechVersion",
    (void *)"auts",
    (void *)"cug-Index",
    (void *)"intraCUG-Options",
    (void *)"preferentialCUG-Indicator",
    (void *)"interCUG-Restrictions",
    (void *)"cug-SubscriptionList",
    (void *)"cug-FeatureList",
    (void *)"cug-Info",
    (void *)"emlpp-Info",
    (void *)"odb-HPLMN-Data",
    (void *)"groupid",
    (void *)"broadcastInitEntitlement",
    (void *)"groupId",
    (void *)"additionalSubscriptions",
    (void *)"longGroupId",
    (void *)"ss-EventList",
    (void *)"ss-CamelData",
    (void *)"mobilityTriggers",
    (void *)"sms-TriggerDetectionPoint",
    (void *)"defaultSMS-Handling",
    (void *)"sms-CAMEL-TDP-DataList",
    (void *)"tpdu-TypeCriterion",
    (void *)"ss-CSI",
    (void *)"tif-CSI",
    (void *)"m-CSI",
    (void *)"mo-sms-CSI",
    (void *)"vt-CSI",
    (void *)"d-CSI",
    (void *)"mt-sms-CSI",
    (void *)"mt-smsCAMELTDP-CriteriaList",
    (void *)"pdp-ContextId",
    (void *)"vplmnAddressAllowed",
    (void *)"apn",
    (void *)"ext-QoS-Subscribed",
    (void *)"pdp-ChargingCharacteristics",
    (void *)"ext2-QoS-Subscribed",
    (void *)"completeDataListIncluded",
    (void *)"gprsDataList",
    (void *)"lsaIdentity",
    (void *)"lsaAttributes",
    (void *)"lsaActiveModeIndicator",
    (void *)"lsaOnlyAccessIndicator",
    (void *)"lsaDataList",
    (void *)"clientIdentity",
    (void *)"gmlc-Restriction",
    (void *)"notificationToMSUser",
    (void *)"serviceTypeIdentity",
    (void *)"externalClientList",
    (void *)"plmnClientList",
    (void *)"ext-externalClientList",
    (void *)"serviceTypeList",
    (void *)"gmlc-List",
    (void *)"lcs-PrivacyExceptionList",
    (void *)"molr-List",
    (void *)"add-lcs-PrivacyExceptionList",
    (void *)"gprs-TriggerDetectionPoint",
    (void *)"defaultSessionHandling",
    (void *)"gprs-CamelTDPDataList",
    (void *)"gprs-CSI",
    (void *)"mg-csi",
    (void *)"max-RequestedBandwidth-UL",
    (void *)"max-RequestedBandwidth-DL",
    (void *)"priority-level",
    (void *)"pre-emption-capability",
    (void *)"pre-emption-vulnerability",
    (void *)"qos-Class-Identifier",
    (void *)"allocation-Retention-Priority",
    (void *)"pdn-gw-ipv4-Address",
    (void *)"pdn-gw-ipv6-Address",
    (void *)"pdn-gw-name",
    (void *)"pdn-gw-Identity",
    (void *)"contextId",
    (void *)"pdn-Type",
    (void *)"servedPartyIP-IPv4-Address",
    (void *)"eps-qos-Subscribed",
    (void *)"pdn-gw-AllocationType",
    (void *)"ambr",
    (void *)"specificAPNInfoList",
    (void *)"servedPartyIP-IPv6-Address",
    (void *)"defaultContext",
    (void *)"epsDataList",
    (void *)"apn-oi-Replacement",
    (void *)"rfsp-id",
    (void *)"apn-ConfigurationProfile",
    (void *)"stn-sr",
    (void *)"csg-Id",
    (void *)"expirationDate",
    (void *)"allGPRSData",
    (void *)"contextIdList",
    (void *)"allLSAData",
    (void *)"lsaIdentityList",
    (void *)"currentLocation",
    (void *)"requestedDomain",
    (void *)"ms-classmark",
    (void *)"mnpRequestedInfo",
    (void *)"requestedSS-Info",
    (void *)"odb",
    (void *)"requestedCAMEL-SubscriptionInfo",
    (void *)"additionalRequestedCAMEL-SubscriptionInfo",
    (void *)"password",
    (void *)"wrongPasswordAttemptsCounter",
    (void *)"vt-BCSM-CAMEL-TDP-CriteriaList",
    (void *)"tif-CSI-NotificationToCSE",
    (void *)"specificCSIDeletedList",
    (void *)"o-IM-CSI",
    (void *)"o-IM-BcsmCamelTDP-CriteriaList",
    (void *)"d-IM-CSI",
    (void *)"vt-IM-CSI",
    (void *)"vt-IM-BCSM-CAMEL-TDP-CriteriaList",
    (void *)"modifyNotificationToCSE",
    (void *)"requestedCamel-SubscriptionInfo",
    (void *)"modifyCSI-State",
    (void *)"odb-data"
};

static const Etag _tagarray[] = {
    1, 0x0006, 1, 0x0010, 7, 10, 13, 1, 0x8000, 1,
    1, 0x8001, 2, 1, 0x8002, 3, 23, 26, 29, 40,
    49, 56, 61, 1, 0x8000, 1, 1, 0x8001, 2, 5,
    0x8002, 3, 0x8003, 4, 0x8004, 5, 0x8005, 6, 0x8006, 7,
    4, 0x8003, 4, 0x8004, 5, 0x8005, 6, 0x8006, 7, 3,
    0x8004, 5, 0x8005, 6, 0x8006, 7, 2, 0x8005, 6, 0x8006,
    7, 1, 0x8006, 7, 82, 85, 88, 121, 152, 181,
    208, 233, 256, 277, 296, 313, 328, 341, 352, 361,
    368, 373, 1, 0x0010, 1, 1, 0x0004, 2, 16, 0x8000,
    3, 0x8001, 4, 0x8002, 5, 0x8003, 6, 0x8004, 7, 0x8005,
    8, 0x8006, 9, 0x8007, 10, 0x8008, 11, 0x8009, 12, 0x800a,
    13, 0x800b, 14, 0x800c, 15, 0x800d, 16, 0x800e, 17, 0x800f,
    18, 15, 0x8001, 4, 0x8002, 5, 0x8003, 6, 0x8004, 7,
    0x8005, 8, 0x8006, 9, 0x8007, 10, 0x8008, 11, 0x8009, 12,
    0x800a, 13, 0x800b, 14, 0x800c, 15, 0x800d, 16, 0x800e, 17,
    0x800f, 18, 14, 0x8002, 5, 0x8003, 6, 0x8004, 7, 0x8005,
    8, 0x8006, 9, 0x8007, 10, 0x8008, 11, 0x8009, 12, 0x800a,
    13, 0x800b, 14, 0x800c, 15, 0x800d, 16, 0x800e, 17, 0x800f,
    18, 13, 0x8003, 6, 0x8004, 7, 0x8005, 8, 0x8006, 9,
    0x8007, 10, 0x8008, 11, 0x8009, 12, 0x800a, 13, 0x800b, 14,
    0x800c, 15, 0x800d, 16, 0x800e, 17, 0x800f, 18, 12, 0x8004,
    7, 0x8005, 8, 0x8006, 9, 0x8007, 10, 0x8008, 11, 0x8009,
    12, 0x800a, 13, 0x800b, 14, 0x800c, 15, 0x800d, 16, 0x800e,
    17, 0x800f, 18, 11, 0x8005, 8, 0x8006, 9, 0x8007, 10,
    0x8008, 11, 0x8009, 12, 0x800a, 13, 0x800b, 14, 0x800c, 15,
    0x800d, 16, 0x800e, 17, 0x800f, 18, 10, 0x8006, 9, 0x8007,
    10, 0x8008, 11, 0x8009, 12, 0x800a, 13, 0x800b, 14, 0x800c,
    15, 0x800d, 16, 0x800e, 17, 0x800f, 18, 9, 0x8007, 10,
    0x8008, 11, 0x8009, 12, 0x800a, 13, 0x800b, 14, 0x800c, 15,
    0x800d, 16, 0x800e, 17, 0x800f, 18, 8, 0x8008, 11, 0x8009,
    12, 0x800a, 13, 0x800b, 14, 0x800c, 15, 0x800d, 16, 0x800e,
    17, 0x800f, 18, 7, 0x8009, 12, 0x800a, 13, 0x800b, 14,
    0x800c, 15, 0x800d, 16, 0x800e, 17, 0x800f, 18, 6, 0x800a,
    13, 0x800b, 14, 0x800c, 15, 0x800d, 16, 0x800e, 17, 0x800f,
    18, 5, 0x800b, 14, 0x800c, 15, 0x800d, 16, 0x800e, 17,
    0x800f, 18, 4, 0x800c, 15, 0x800d, 16, 0x800e, 17, 0x800f,
    18, 3, 0x800d, 16, 0x800e, 17, 0x800f, 18, 2, 0x800e,
    17, 0x800f, 18, 1, 0x800f, 18, 387, 390, 411, 430,
    447, 462, 475, 486, 495, 502, 507, 1, 0x0004, 1,
    10, 0x8000, 2, 0x8001, 3, 0x8002, 4, 0x8003, 5, 0x8004,
    6, 0x8005, 7, 0x8006, 8, 0x8007, 9, 0x8008, 10, 0x8009,
    11, 9, 0x8001, 3, 0x8002, 4, 0x8003, 5, 0x8004, 6,
    0x8005, 7, 0x8006, 8, 0x8007, 9, 0x8008, 10, 0x8009, 11,
    8, 0x8002, 4, 0x8003, 5, 0x8004, 6, 0x8005, 7, 0x8006,
    8, 0x8007, 9, 0x8008, 10, 0x8009, 11, 7, 0x8003, 5,
    0x8004, 6, 0x8005, 7, 0x8006, 8, 0x8007, 9, 0x8008, 10,
    0x8009, 11, 6, 0x8004, 6, 0x8005, 7, 0x8006, 8, 0x8007,
    9, 0x8008, 10, 0x8009, 11, 5, 0x8005, 7, 0x8006, 8,
    0x8007, 9, 0x8008, 10, 0x8009, 11, 4, 0x8006, 8, 0x8007,
    9, 0x8008, 10, 0x8009, 11, 3, 0x8007, 9, 0x8008, 10,
    0x8009, 11, 2, 0x8008, 10, 0x8009, 11, 1, 0x8009, 11,
    532, 535, 538, 541, 580, 617, 652, 685, 716, 745,
    772, 797, 820, 841, 860, 877, 892, 905, 916, 925,
    932, 937, 1, 0x000a, 1, 1, 0x0010, 2, 1, 0x0010,
    3, 19, 0x8000, 4, 0x8001, 5, 0x8002, 6, 0x8003, 7,
    0x8004, 8, 0x8005, 9, 0x8006, 10, 0x8007, 11, 0x8008, 12,
    0x8009, 13, 0x800a, 14, 0x800b, 15, 0x800c, 16, 0x800d, 17,
    0x800e, 18, 0x800f, 19, 0x8011, 20, 0x8012, 21, 0x8013, 22,
    18, 0x8001, 5, 0x8002, 6, 0x8003, 7, 0x8004, 8, 0x8005,
    9, 0x8006, 10, 0x8007, 11, 0x8008, 12, 0x8009, 13, 0x800a,
    14, 0x800b, 15, 0x800c, 16, 0x800d, 17, 0x800e, 18, 0x800f,
    19, 0x8011, 20, 0x8012, 21, 0x8013, 22, 17, 0x8002, 6,
    0x8003, 7, 0x8004, 8, 0x8005, 9, 0x8006, 10, 0x8007, 11,
    0x8008, 12, 0x8009, 13, 0x800a, 14, 0x800b, 15, 0x800c, 16,
    0x800d, 17, 0x800e, 18, 0x800f, 19, 0x8011, 20, 0x8012, 21,
    0x8013, 22, 16, 0x8003, 7, 0x8004, 8, 0x8005, 9, 0x8006,
    10, 0x8007, 11, 0x8008, 12, 0x8009, 13, 0x800a, 14, 0x800b,
    15, 0x800c, 16, 0x800d, 17, 0x800e, 18, 0x800f, 19, 0x8011,
    20, 0x8012, 21, 0x8013, 22, 15, 0x8004, 8, 0x8005, 9,
    0x8006, 10, 0x8007, 11, 0x8008, 12, 0x8009, 13, 0x800a, 14,
    0x800b, 15, 0x800c, 16, 0x800d, 17, 0x800e, 18, 0x800f, 19,
    0x8011, 20, 0x8012, 21, 0x8013, 22, 14, 0x8005, 9, 0x8006,
    10, 0x8007, 11, 0x8008, 12, 0x8009, 13, 0x800a, 14, 0x800b,
    15, 0x800c, 16, 0x800d, 17, 0x800e, 18, 0x800f, 19, 0x8011,
    20, 0x8012, 21, 0x8013, 22, 13, 0x8006, 10, 0x8007, 11,
    0x8008, 12, 0x8009, 13, 0x800a, 14, 0x800b, 15, 0x800c, 16,
    0x800d, 17, 0x800e, 18, 0x800f, 19, 0x8011, 20, 0x8012, 21,
    0x8013, 22, 12, 0x8007, 11, 0x8008, 12, 0x8009, 13, 0x800a,
    14, 0x800b, 15, 0x800c, 16, 0x800d, 17, 0x800e, 18, 0x800f,
    19, 0x8011, 20, 0x8012, 21, 0x8013, 22, 11, 0x8008, 12,
    0x8009, 13, 0x800a, 14, 0x800b, 15, 0x800c, 16, 0x800d, 17,
    0x800e, 18, 0x800f, 19, 0x8011, 20, 0x8012, 21, 0x8013, 22,
    10, 0x8009, 13, 0x800a, 14, 0x800b, 15, 0x800c, 16, 0x800d,
    17, 0x800e, 18, 0x800f, 19, 0x8011, 20, 0x8012, 21, 0x8013,
    22, 9, 0x800a, 14, 0x800b, 15, 0x800c, 16, 0x800d, 17,
    0x800e, 18, 0x800f, 19, 0x8011, 20, 0x8012, 21, 0x8013, 22,
    8, 0x800b, 15, 0x800c, 16, 0x800d, 17, 0x800e, 18, 0x800f,
    19, 0x8011, 20, 0x8012, 21, 0x8013, 22, 7, 0x800c, 16,
    0x800d, 17, 0x800e, 18, 0x800f, 19, 0x8011, 20, 0x8012, 21,
    0x8013, 22, 6, 0x800d, 17, 0x800e, 18, 0x800f, 19, 0x8011,
    20, 0x8012, 21, 0x8013, 22, 5, 0x800e, 18, 0x800f, 19,
    0x8011, 20, 0x8012, 21, 0x8013, 22, 4, 0x800f, 19, 0x8011,
    20, 0x8012, 21, 0x8013, 22, 3, 0x8011, 20, 0x8012, 21,
    0x8013, 22, 2, 0x8012, 21, 0x8013, 22, 1, 0x8013, 22,
    943, 950, 955, 3, 0x0010, 1, 0x8000, 2, 0x8001, 3,
    2, 0x8000, 2, 0x8001, 3, 1, 0x8001, 3, 960, 963,
    1, 0x0010, 1, 1, 0x0004, 2, 0, 2, 0x8000, 1,
    0x8001, 2, 983, 986, 989, 992, 995, 1010, 1023, 1034,
    1043, 1050, 1055, 1, 0x0004, 1, 1, 0x0004, 2, 1,
    0x0004, 3, 1, 0x0004, 4, 7, 0x8000, 5, 0x8001, 6,
    0x8002, 7, 0x8003, 8, 0x8004, 9, 0x8005, 10, 0x8006, 11,
    6, 0x8001, 6, 0x8002, 7, 0x8003, 8, 0x8004, 9, 0x8005,
    10, 0x8006, 11, 5, 0x8002, 7, 0x8003, 8, 0x8004, 9,
    0x8005, 10, 0x8006, 11, 4, 0x8003, 8, 0x8004, 9, 0x8005,
    10, 0x8006, 11, 3, 0x8004, 9, 0x8005, 10, 0x8006, 11,
    2, 0x8005, 10, 0x8006, 11, 1, 0x8006, 11, 1060, 1063,
    1, 0x0004, 1, 1, 0x0010, 2, 1070, 1079, 1086, 1091,
    4, 0x0004, 1, 0x0010, 2, 0x8000, 3, 0x8001, 4, 3,
    0x0010, 2, 0x8000, 3, 0x8001, 4, 2, 0x8000, 3, 0x8001,
    4, 1, 0x8001, 4, 1095, 1, 0x0010, 1, 1110, 1135,
    1158, 1179, 1198, 1215, 1230, 1243, 1254, 1263, 1270, 1275,
    12, 0x0004, 1, 0x0010, 7, 0x8000, 2, 0x8001, 3, 0x8002,
    4, 0x8003, 5, 0x8004, 6, 0x8005, 8, 0x8006, 9, 0x8007,
    10, 0x8008, 11, 0x8009, 12, 11, 0x0010, 7, 0x8000, 2,
    0x8001, 3, 0x8002, 4, 0x8003, 5, 0x8004, 6, 0x8005, 8,
    0x8006, 9, 0x8007, 10, 0x8008, 11, 0x8009, 12, 10, 0x0010,
    7, 0x8001, 3, 0x8002, 4, 0x8003, 5, 0x8004, 6, 0x8005,
    8, 0x8006, 9, 0x8007, 10, 0x8008, 11, 0x8009, 12, 9,
    0x0010, 7, 0x8002, 4, 0x8003, 5, 0x8004, 6, 0x8005, 8,
    0x8006, 9, 0x8007, 10, 0x8008, 11, 0x8009, 12, 8, 0x0010,
    7, 0x8003, 5, 0x8004, 6, 0x8005, 8, 0x8006, 9, 0x8007,
    10, 0x8008, 11, 0x8009, 12, 7, 0x0010, 7, 0x8004, 6,
    0x8005, 8, 0x8006, 9, 0x8007, 10, 0x8008, 11, 0x8009, 12,
    6, 0x0010, 7, 0x8005, 8, 0x8006, 9, 0x8007, 10, 0x8008,
    11, 0x8009, 12, 5, 0x8005, 8, 0x8006, 9, 0x8007, 10,
    0x8008, 11, 0x8009, 12, 4, 0x8006, 9, 0x8007, 10, 0x8008,
    11, 0x8009, 12, 3, 0x8007, 10, 0x8008, 11, 0x8009, 12,
    2, 0x8008, 11, 0x8009, 12, 1, 0x8009, 12, 1285, 1300,
    1313, 1324, 1333, 1340, 1345, 7, 0x0010, 4, 0x8000, 1,
    0x8001, 2, 0x8002, 3, 0x8003, 5, 0x8004, 6, 0x8005, 7,
    6, 0x0010, 4, 0x8001, 2, 0x8002, 3, 0x8003, 5, 0x8004,
    6, 0x8005, 7, 5, 0x0010, 4, 0x8002, 3, 0x8003, 5,
    0x8004, 6, 0x8005, 7, 4, 0x0010, 4, 0x8003, 5, 0x8004,
    6, 0x8005, 7, 3, 0x8003, 5, 0x8004, 6, 0x8005, 7,
    2, 0x8004, 6, 0x8005, 7, 1, 0x8005, 7, 1, 0x0004,
    1352, 1355, 1, 0x000a, 1, 1, 0x0010, 2, 2, 0x000a,
    1, 0x0010, 2, 1365, 1370, 2, 0x000a, 1, 0x0010, 2,
    1, 0x0010, 2, 1376, 1385, 1392, 4, 0x8001, 1, 0x8002,
    2, 0x8003, 2, 0x8004, 3, 3, 0x8002, 2, 0x8003, 2,
    0x8004, 3, 1, 0x8004, 3, 1, 0x000a, 1400, 1403, 1408,
    1, 0x000a, 1, 2, 0x0004, 2, 0x0010, 3, 1, 0x0010,
    3, 1414, 1421, 1426, 3, 0x0002, 1, 0x0010, 2, 0x8000,
    3, 2, 0x0010, 2, 0x8000, 3, 1, 0x8000, 3, 1431,
    1436, 2, 0x000a, 2, 0x0010, 1, 1, 0x000a, 2, 1441,
    1446, 2, 0x0010, 1, 0x8000, 2, 1, 0x8000, 2, 1451,
    1456, 2, 0x0005, 2, 0x0010, 1, 1, 0x0005, 2, 1461,
    1466, 2, 0x8000, 1, 0x8001, 2, 1, 0x8001, 2, 1499,
    1502, 1509, 1514, 1517, 1524, 1529, 1532, 1579, 1624, 1667,
    1708, 1747, 1784, 1819, 1852, 1883, 1912, 1939, 1964, 1987,
    2008, 2027, 2044, 2059, 2072, 2083, 2092, 2099, 2104, 1,
    0x8000, 1, 3, 0x8001, 2, 0x8002, 3, 0x8003, 4, 2,
    0x8002, 3, 0x8003, 4, 1, 0x8003, 4, 3, 0x8004, 5,
    0x8005, 6, 0x8006, 7, 2, 0x8005, 6, 0x8006, 7, 1,
    0x8006, 7, 23, 0x8007, 8, 0x8008, 9, 0x8009, 10, 0x800a,
    11, 0x800b, 12, 0x800c, 13, 0x800d, 14, 0x800e, 15, 0x800f,
    16, 0x8010, 17, 0x8011, 18, 0x8012, 19, 0x8013, 20, 0x8014,
    21, 0x8015, 22, 0x8016, 23, 0x8017, 24, 0x8018, 25, 0x8019,
    26, 0x801a, 27, 0x801b, 28, 0x801c, 29, 0x801d, 30, 22,
    0x8008, 9, 0x8009, 10, 0x800a, 11, 0x800b, 12, 0x800c, 13,
    0x800d, 14, 0x800e, 15, 0x800f, 16, 0x8010, 17, 0x8011, 18,
    0x8012, 19, 0x8013, 20, 0x8014, 21, 0x8015, 22, 0x8016, 23,
    0x8017, 24, 0x8018, 25, 0x8019, 26, 0x801a, 27, 0x801b, 28,
    0x801c, 29, 0x801d, 30, 21, 0x8009, 10, 0x800a, 11, 0x800b,
    12, 0x800c, 13, 0x800d, 14, 0x800e, 15, 0x800f, 16, 0x8010,
    17, 0x8011, 18, 0x8012, 19, 0x8013, 20, 0x8014, 21, 0x8015,
    22, 0x8016, 23, 0x8017, 24, 0x8018, 25, 0x8019, 26, 0x801a,
    27, 0x801b, 28, 0x801c, 29, 0x801d, 30, 20, 0x800a, 11,
    0x800b, 12, 0x800c, 13, 0x800d, 14, 0x800e, 15, 0x800f, 16,
    0x8010, 17, 0x8011, 18, 0x8012, 19, 0x8013, 20, 0x8014, 21,
    0x8015, 22, 0x8016, 23, 0x8017, 24, 0x8018, 25, 0x8019, 26,
    0x801a, 27, 0x801b, 28, 0x801c, 29, 0x801d, 30, 19, 0x800b,
    12, 0x800c, 13, 0x800d, 14, 0x800e, 15, 0x800f, 16, 0x8010,
    17, 0x8011, 18, 0x8012, 19, 0x8013, 20, 0x8014, 21, 0x8015,
    22, 0x8016, 23, 0x8017, 24, 0x8018, 25, 0x8019, 26, 0x801a,
    27, 0x801b, 28, 0x801c, 29, 0x801d, 30, 18, 0x800c, 13,
    0x800d, 14, 0x800e, 15, 0x800f, 16, 0x8010, 17, 0x8011, 18,
    0x8012, 19, 0x8013, 20, 0x8014, 21, 0x8015, 22, 0x8016, 23,
    0x8017, 24, 0x8018, 25, 0x8019, 26, 0x801a, 27, 0x801b, 28,
    0x801c, 29, 0x801d, 30, 17, 0x800d, 14, 0x800e, 15, 0x800f,
    16, 0x8010, 17, 0x8011, 18, 0x8012, 19, 0x8013, 20, 0x8014,
    21, 0x8015, 22, 0x8016, 23, 0x8017, 24, 0x8018, 25, 0x8019,
    26, 0x801a, 27, 0x801b, 28, 0x801c, 29, 0x801d, 30, 16,
    0x800e, 15, 0x800f, 16, 0x8010, 17, 0x8011, 18, 0x8012, 19,
    0x8013, 20, 0x8014, 21, 0x8015, 22, 0x8016, 23, 0x8017, 24,
    0x8018, 25, 0x8019, 26, 0x801a, 27, 0x801b, 28, 0x801c, 29,
    0x801d, 30, 15, 0x800f, 16, 0x8010, 17, 0x8011, 18, 0x8012,
    19, 0x8013, 20, 0x8014, 21, 0x8015, 22, 0x8016, 23, 0x8017,
    24, 0x8018, 25, 0x8019, 26, 0x801a, 27, 0x801b, 28, 0x801c,
    29, 0x801d, 30, 14, 0x8010, 17, 0x8011, 18, 0x8012, 19,
    0x8013, 20, 0x8014, 21, 0x8015, 22, 0x8016, 23, 0x8017, 24,
    0x8018, 25, 0x8019, 26, 0x801a, 27, 0x801b, 28, 0x801c, 29,
    0x801d, 30, 13, 0x8011, 18, 0x8012, 19, 0x8013, 20, 0x8014,
    21, 0x8015, 22, 0x8016, 23, 0x8017, 24, 0x8018, 25, 0x8019,
    26, 0x801a, 27, 0x801b, 28, 0x801c, 29, 0x801d, 30, 12,
    0x8012, 19, 0x8013, 20, 0x8014, 21, 0x8015, 22, 0x8016, 23,
    0x8017, 24, 0x8018, 25, 0x8019, 26, 0x801a, 27, 0x801b, 28,
    0x801c, 29, 0x801d, 30, 11, 0x8013, 20, 0x8014, 21, 0x8015,
    22, 0x8016, 23, 0x8017, 24, 0x8018, 25, 0x8019, 26, 0x801a,
    27, 0x801b, 28, 0x801c, 29, 0x801d, 30, 10, 0x8014, 21,
    0x8015, 22, 0x8016, 23, 0x8017, 24, 0x8018, 25, 0x8019, 26,
    0x801a, 27, 0x801b, 28, 0x801c, 29, 0x801d, 30, 9, 0x8015,
    22, 0x8016, 23, 0x8017, 24, 0x8018, 25, 0x8019, 26, 0x801a,
    27, 0x801b, 28, 0x801c, 29, 0x801d, 30, 8, 0x8016, 23,
    0x8017, 24, 0x8018, 25, 0x8019, 26, 0x801a, 27, 0x801b, 28,
    0x801c, 29, 0x801d, 30, 7, 0x8017, 24, 0x8018, 25, 0x8019,
    26, 0x801a, 27, 0x801b, 28, 0x801c, 29, 0x801d, 30, 6,
    0x8018, 25, 0x8019, 26, 0x801a, 27, 0x801b, 28, 0x801c, 29,
    0x801d, 30, 5, 0x8019, 26, 0x801a, 27, 0x801b, 28, 0x801c,
    29, 0x801d, 30, 4, 0x801a, 27, 0x801b, 28, 0x801c, 29,
    0x801d, 30, 3, 0x801b, 28, 0x801c, 29, 0x801d, 30, 2,
    0x801c, 29, 0x801d, 30, 1, 0x801d, 30, 1, 0x8003, 2133,
    2186, 2237, 2282, 2325, 2366, 2405, 2442, 2477, 2510, 2541,
    2570, 2597, 2622, 2645, 2666, 2685, 2702, 2717, 2730, 2741,
    2750, 2757, 2762, 26, 0x0004, 2, 0x0010, 2, 0x8000, 10,
    0x8001, 6, 0x8002, 9, 0x8003, 3, 0x8004, 8, 0x8005, 7,
    0x8006, 4, 0x8007, 5, 0x8008, 2, 0x8009, 1, 0x800a, 11,
    0x800b, 12, 0x800c, 13, 0x800d, 14, 0x800e, 15, 0x800f, 16,
    0x8010, 17, 0x8011, 18, 0x8012, 19, 0x8013, 20, 0x8014, 21,
    0x8015, 22, 0x8016, 23, 0x8017, 24, 25, 0x0004, 2, 0x0010,
    2, 0x8000, 10, 0x8001, 6, 0x8002, 9, 0x8003, 3, 0x8004,
    8, 0x8005, 7, 0x8006, 4, 0x8007, 5, 0x8008, 2, 0x800a,
    11, 0x800b, 12, 0x800c, 13, 0x800d, 14, 0x800e, 15, 0x800f,
    16, 0x8010, 17, 0x8011, 18, 0x8012, 19, 0x8013, 20, 0x8014,
    21, 0x8015, 22, 0x8016, 23, 0x8017, 24, 22, 0x8000, 10,
    0x8001, 6, 0x8002, 9, 0x8003, 3, 0x8004, 8, 0x8005, 7,
    0x8006, 4, 0x8007, 5, 0x800a, 11, 0x800b, 12, 0x800c, 13,
    0x800d, 14, 0x800e, 15, 0x800f, 16, 0x8010, 17, 0x8011, 18,
    0x8012, 19, 0x8013, 20, 0x8014, 21, 0x8015, 22, 0x8016, 23,
    0x8017, 24, 21, 0x8000, 10, 0x8001, 6, 0x8002, 9, 0x8004,
    8, 0x8005, 7, 0x8006, 4, 0x8007, 5, 0x800a, 11, 0x800b,
    12, 0x800c, 13, 0x800d, 14, 0x800e, 15, 0x800f, 16, 0x8010,
    17, 0x8011, 18, 0x8012, 19, 0x8013, 20, 0x8014, 21, 0x8015,
    22, 0x8016, 23, 0x8017, 24, 20, 0x8000, 10, 0x8001, 6,
    0x8002, 9, 0x8004, 8, 0x8005, 7, 0x8007, 5, 0x800a, 11,
    0x800b, 12, 0x800c, 13, 0x800d, 14, 0x800e, 15, 0x800f, 16,
    0x8010, 17, 0x8011, 18, 0x8012, 19, 0x8013, 20, 0x8014, 21,
    0x8015, 22, 0x8016, 23, 0x8017, 24, 19, 0x8000, 10, 0x8001,
    6, 0x8002, 9, 0x8004, 8, 0x8005, 7, 0x800a, 11, 0x800b,
    12, 0x800c, 13, 0x800d, 14, 0x800e, 15, 0x800f, 16, 0x8010,
    17, 0x8011, 18, 0x8012, 19, 0x8013, 20, 0x8014, 21, 0x8015,
    22, 0x8016, 23, 0x8017, 24, 18, 0x8000, 10, 0x8002, 9,
    0x8004, 8, 0x8005, 7, 0x800a, 11, 0x800b, 12, 0x800c, 13,
    0x800d, 14, 0x800e, 15, 0x800f, 16, 0x8010, 17, 0x8011, 18,
    0x8012, 19, 0x8013, 20, 0x8014, 21, 0x8015, 22, 0x8016, 23,
    0x8017, 24, 17, 0x8000, 10, 0x8002, 9, 0x8004, 8, 0x800a,
    11, 0x800b, 12, 0x800c, 13, 0x800d, 14, 0x800e, 15, 0x800f,
    16, 0x8010, 17, 0x8011, 18, 0x8012, 19, 0x8013, 20, 0x8014,
    21, 0x8015, 22, 0x8016, 23, 0x8017, 24, 16, 0x8000, 10,
    0x8002, 9, 0x800a, 11, 0x800b, 12, 0x800c, 13, 0x800d, 14,
    0x800e, 15, 0x800f, 16, 0x8010, 17, 0x8011, 18, 0x8012, 19,
    0x8013, 20, 0x8014, 21, 0x8015, 22, 0x8016, 23, 0x8017, 24,
    15, 0x8000, 10, 0x800a, 11, 0x800b, 12, 0x800c, 13, 0x800d,
    14, 0x800e, 15, 0x800f, 16, 0x8010, 17, 0x8011, 18, 0x8012,
    19, 0x8013, 20, 0x8014, 21, 0x8015, 22, 0x8016, 23, 0x8017,
    24, 14, 0x800a, 11, 0x800b, 12, 0x800c, 13, 0x800d, 14,
    0x800e, 15, 0x800f, 16, 0x8010, 17, 0x8011, 18, 0x8012, 19,
    0x8013, 20, 0x8014, 21, 0x8015, 22, 0x8016, 23, 0x8017, 24,
    13, 0x800b, 12, 0x800c, 13, 0x800d, 14, 0x800e, 15, 0x800f,
    16, 0x8010, 17, 0x8011, 18, 0x8012, 19, 0x8013, 20, 0x8014,
    21, 0x8015, 22, 0x8016, 23, 0x8017, 24, 12, 0x800c, 13,
    0x800d, 14, 0x800e, 15, 0x800f, 16, 0x8010, 17, 0x8011, 18,
    0x8012, 19, 0x8013, 20, 0x8014, 21, 0x8015, 22, 0x8016, 23,
    0x8017, 24, 11, 0x800d, 14, 0x800e, 15, 0x800f, 16, 0x8010,
    17, 0x8011, 18, 0x8012, 19, 0x8013, 20, 0x8014, 21, 0x8015,
    22, 0x8016, 23, 0x8017, 24, 10, 0x800e, 15, 0x800f, 16,
    0x8010, 17, 0x8011, 18, 0x8012, 19, 0x8013, 20, 0x8014, 21,
    0x8015, 22, 0x8016, 23, 0x8017, 24, 9, 0x800f, 16, 0x8010,
    17, 0x8011, 18, 0x8012, 19, 0x8013, 20, 0x8014, 21, 0x8015,
    22, 0x8016, 23, 0x8017, 24, 8, 0x8010, 17, 0x8011, 18,
    0x8012, 19, 0x8013, 20, 0x8014, 21, 0x8015, 22, 0x8016, 23,
    0x8017, 24, 7, 0x8011, 18, 0x8012, 19, 0x8013, 20, 0x8014,
    21, 0x8015, 22, 0x8016, 23, 0x8017, 24, 6, 0x8012, 19,
    0x8013, 20, 0x8014, 21, 0x8015, 22, 0x8016, 23, 0x8017, 24,
    5, 0x8013, 20, 0x8014, 21, 0x8015, 22, 0x8016, 23, 0x8017,
    24, 4, 0x8014, 21, 0x8015, 22, 0x8016, 23, 0x8017, 24,
    3, 0x8015, 22, 0x8016, 23, 0x8017, 24, 2, 0x8016, 23,
    0x8017, 24, 1, 0x8017, 24, 2785, 2788, 2791, 2828, 2863,
    2896, 2927, 2956, 2983, 3008, 3031, 3052, 3071, 3088, 3103,
    3116, 3127, 3136, 3143, 3148, 1, 0x8000, 1, 1, 0x8001,
    2, 18, 0x8002, 3, 0x8004, 4, 0x8005, 5, 0x8006, 6,
    0x8007, 7, 0x8008, 8, 0x8009, 9, 0x800a, 10, 0x800b, 11,
    0x800c, 12, 0x800d, 13, 0x800e, 15, 0x800f, 14, 0x8010, 16,
    0x8011, 17, 0x8012, 18, 0x8013, 19, 0x8014, 20, 17, 0x8004,
    4, 0x8005, 5, 0x8006, 6, 0x8007, 7, 0x8008, 8, 0x8009,
    9, 0x800a, 10, 0x800b, 11, 0x800c, 12, 0x800d, 13, 0x800e,
    15, 0x800f, 14, 0x8010, 16, 0x8011, 17, 0x8012, 18, 0x8013,
    19, 0x8014, 20, 16, 0x8005, 5, 0x8006, 6, 0x8007, 7,
    0x8008, 8, 0x8009, 9, 0x800a, 10, 0x800b, 11, 0x800c, 12,
    0x800d, 13, 0x800e, 15, 0x800f, 14, 0x8010, 16, 0x8011, 17,
    0x8012, 18, 0x8013, 19, 0x8014, 20, 15, 0x8006, 6, 0x8007,
    7, 0x8008, 8, 0x8009, 9, 0x800a, 10, 0x800b, 11, 0x800c,
    12, 0x800d, 13, 0x800e, 15, 0x800f, 14, 0x8010, 16, 0x8011,
    17, 0x8012, 18, 0x8013, 19, 0x8014, 20, 14, 0x8007, 7,
    0x8008, 8, 0x8009, 9, 0x800a, 10, 0x800b, 11, 0x800c, 12,
    0x800d, 13, 0x800e, 15, 0x800f, 14, 0x8010, 16, 0x8011, 17,
    0x8012, 18, 0x8013, 19, 0x8014, 20, 13, 0x8008, 8, 0x8009,
    9, 0x800a, 10, 0x800b, 11, 0x800c, 12, 0x800d, 13, 0x800e,
    15, 0x800f, 14, 0x8010, 16, 0x8011, 17, 0x8012, 18, 0x8013,
    19, 0x8014, 20, 12, 0x8009, 9, 0x800a, 10, 0x800b, 11,
    0x800c, 12, 0x800d, 13, 0x800e, 15, 0x800f, 14, 0x8010, 16,
    0x8011, 17, 0x8012, 18, 0x8013, 19, 0x8014, 20, 11, 0x800a,
    10, 0x800b, 11, 0x800c, 12, 0x800d, 13, 0x800e, 15, 0x800f,
    14, 0x8010, 16, 0x8011, 17, 0x8012, 18, 0x8013, 19, 0x8014,
    20, 10, 0x800b, 11, 0x800c, 12, 0x800d, 13, 0x800e, 15,
    0x800f, 14, 0x8010, 16, 0x8011, 17, 0x8012, 18, 0x8013, 19,
    0x8014, 20, 9, 0x800c, 12, 0x800d, 13, 0x800e, 15, 0x800f,
    14, 0x8010, 16, 0x8011, 17, 0x8012, 18, 0x8013, 19, 0x8014,
    20, 8, 0x800d, 13, 0x800e, 15, 0x800f, 14, 0x8010, 16,
    0x8011, 17, 0x8012, 18, 0x8013, 19, 0x8014, 20, 7, 0x800e,
    15, 0x800f, 14, 0x8010, 16, 0x8011, 17, 0x8012, 18, 0x8013,
    19, 0x8014, 20, 6, 0x800e, 15, 0x8010, 16, 0x8011, 17,
    0x8012, 18, 0x8013, 19, 0x8014, 20, 5, 0x8010, 16, 0x8011,
    17, 0x8012, 18, 0x8013, 19, 0x8014, 20, 4, 0x8011, 17,
    0x8012, 18, 0x8013, 19, 0x8014, 20, 3, 0x8012, 18, 0x8013,
    19, 0x8014, 20, 2, 0x8013, 19, 0x8014, 20, 1, 0x8014,
    20, 3154, 3157, 3162, 1, 0x0004, 1, 2, 0x0005, 3,
    0x0010, 2, 1, 0x0005, 3, 3179, 3208, 3235, 3260, 3283,
    3304, 3323, 3340, 3355, 3368, 3379, 3388, 3395, 3400, 14,
    0x8000, 1, 0x8001, 2, 0x8002, 3, 0x8003, 4, 0x8004, 5,
    0x8005, 6, 0x8007, 7, 0x8008, 8, 0x8009, 9, 0x800a, 10,
    0x800b, 11, 0x800c, 12, 0x800d, 13, 0x800e, 14, 13, 0x8001,
    2, 0x8002, 3, 0x8003, 4, 0x8004, 5, 0x8005, 6, 0x8007,
    7, 0x8008, 8, 0x8009, 9, 0x800a, 10, 0x800b, 11, 0x800c,
    12, 0x800d, 13, 0x800e, 14, 12, 0x8002, 3, 0x8003, 4,
    0x8004, 5, 0x8005, 6, 0x8007, 7, 0x8008, 8, 0x8009, 9,
    0x800a, 10, 0x800b, 11, 0x800c, 12, 0x800d, 13, 0x800e, 14,
    11, 0x8003, 4, 0x8004, 5, 0x8005, 6, 0x8007, 7, 0x8008,
    8, 0x8009, 9, 0x800a, 10, 0x800b, 11, 0x800c, 12, 0x800d,
    13, 0x800e, 14, 10, 0x8004, 5, 0x8005, 6, 0x8007, 7,
    0x8008, 8, 0x8009, 9, 0x800a, 10, 0x800b, 11, 0x800c, 12,
    0x800d, 13, 0x800e, 14, 9, 0x8005, 6, 0x8007, 7, 0x8008,
    8, 0x8009, 9, 0x800a, 10, 0x800b, 11, 0x800c, 12, 0x800d,
    13, 0x800e, 14, 8, 0x8007, 7, 0x8008, 8, 0x8009, 9,
    0x800a, 10, 0x800b, 11, 0x800c, 12, 0x800d, 13, 0x800e, 14,
    7, 0x8008, 8, 0x8009, 9, 0x800a, 10, 0x800b, 11, 0x800c,
    12, 0x800d, 13, 0x800e, 14, 6, 0x8009, 9, 0x800a, 10,
    0x800b, 11, 0x800c, 12, 0x800d, 13, 0x800e, 14, 5, 0x800a,
    10, 0x800b, 11, 0x800c, 12, 0x800d, 13, 0x800e, 14, 4,
    0x800b, 11, 0x800c, 12, 0x800d, 13, 0x800e, 14, 3, 0x800c,
    12, 0x800d, 13, 0x800e, 14, 2, 0x800d, 13, 0x800e, 14,
    1, 0x800e, 14, 3407, 3416, 3423, 3428, 4, 0x8000, 1,
    0x8001, 2, 0x8002, 3, 0x8003, 4, 3, 0x8001, 2, 0x8002,
    3, 0x8003, 4, 2, 0x8002, 3, 0x8003, 4, 1, 0x8003,
    4, 3435, 3438, 3445, 3450, 1, 0x8000, 1, 3, 0x8001,
    2, 0x8002, 3, 0x8003, 4, 2, 0x8002, 3, 0x8003, 4,
    1, 0x8003, 4, 3454, 1, 0x8000, 1, 3464, 3467, 3470,
    3473, 3476, 3483, 3488, 1, 0x8000, 1, 1, 0x8001, 2,
    1, 0x8002, 3, 1, 0x8003, 4, 3, 0x8004, 5, 0x8005,
    6, 0x8006, 7, 2, 0x8005, 6, 0x8006, 7, 1, 0x8006,
    7, 3493, 3496, 1, 0x8000, 1, 1, 0x8001, 2, 3507,
    3510, 3527, 3540, 3551, 3560, 3567, 3572, 1, 0x0004, 1,
    8, 0x8002, 2, 0x8003, 2, 0x8004, 3, 0x8005, 5, 0x8006,
    4, 0x8007, 6, 0x8008, 7, 0x8009, 8, 6, 0x8004, 3,
    0x8005, 5, 0x8006, 4, 0x8007, 6, 0x8008, 7, 0x8009, 8,
    5, 0x8005, 5, 0x8006, 4, 0x8007, 6, 0x8008, 7, 0x8009,
    8, 4, 0x8005, 5, 0x8007, 6, 0x8008, 7, 0x8009, 8,
    3, 0x8007, 6, 0x8008, 7, 0x8009, 8, 2, 0x8008, 7,
    0x8009, 8, 1, 0x8009, 8, 4, 0x8000, 1, 0x8002, 2,
    0x8003, 3, 0x8004, 4, 3588, 3591, 3594, 3599, 1, 0x0004,
    1, 1, 0x0004, 2, 2, 0x0004, 3, 0x8000, 4, 1,
    0x8000, 4, 3604, 3607, 1, 0x0004, 1, 1, 0x0004, 2,
    3617, 3620, 3623, 3626, 3635, 3642, 3647, 1, 0x8000, 1,
    1, 0x8001, 2, 1, 0x8002, 3, 4, 0x8003, 4, 0x8004,
    5, 0x8005, 6, 0x8006, 7, 3, 0x8004, 5, 0x8005, 6,
    0x8006, 7, 2, 0x8005, 6, 0x8006, 7, 1, 0x8006, 7,
    3657, 3660, 3663, 3666, 3675, 3682, 3687, 1, 0x8000, 1,
    1, 0x8001, 2, 1, 0x8002, 3, 4, 0x8006, 4, 0x8007,
    5, 0x8008, 6, 0x8009, 7, 3, 0x8007, 5, 0x8008, 6,
    0x8009, 7, 2, 0x8008, 6, 0x8009, 7, 1, 0x8009, 7,
    3693, 3696, 3699, 1, 0x0004, 1, 1, 0x8000, 2, 1,
    0x8004, 3, 3707, 3716, 3723, 3726, 3731, 4, 0x8000, 1,
    0x8001, 1, 0x8004, 1, 0x8005, 1, 3, 0x8002, 2, 0x8004,
    2, 0x8005, 2, 1, 0x0004, 3, 2, 0x0004, 5, 0x0010,
    4, 1, 0x0004, 5, 3736, 3741, 2, 0x0004, 1, 0x0010,
    2, 1, 0x0010, 2, 3749, 3758, 3765, 3768, 3773, 4,
    0x8000, 1, 0x8001, 1, 0x8004, 1, 0x8005, 1, 3, 0x8002,
    2, 0x8004, 2, 0x8005, 2, 1, 0x0004, 3, 2, 0x0005,
    4, 0x0010, 5, 1, 0x0010, 5, 3785, 3788, 3791, 3794,
    3807, 3818, 3827, 3834, 3839, 1, 0x0004, 1, 1, 0x0004,
    2, 1, 0x000a, 3, 6, 0x8000, 4, 0x8001, 5, 0x8002,
    6, 0x8003, 7, 0x8004, 8, 0x8005, 9, 5, 0x8001, 5,
    0x8002, 6, 0x8003, 7, 0x8004, 8, 0x8005, 9, 4, 0x8002,
    6, 0x8003, 7, 0x8004, 8, 0x8005, 9, 3, 0x8003, 7,
    0x8004, 8, 0x8005, 9, 2, 0x8004, 8, 0x8005, 9, 1,
    0x8005, 9, 3847, 3858, 3867, 3874, 3879, 5, 0x0002, 4,
    0x0003, 2, 0x0004, 1, 0x0010, 3, 0x8000, 5, 4, 0x0002,
    4, 0x0003, 2, 0x0010, 3, 0x8000, 5, 3, 0x0002, 4,
    0x0010, 3, 0x8000, 5, 2, 0x0002, 4, 0x8000, 5, 1,
    0x8000, 5, 3886, 3889, 3892, 3897, 1, 0x8000, 1, 1,
    0x000a, 2, 2, 0x0005, 3, 0x0010, 4, 1, 0x0010, 4,
    3904, 3907, 3914, 3917, 1, 0x0004, 1, 3, 0x8002, 2,
    0x8004, 2, 0x8005, 2, 1, 0x0004, 3, 1, 0x0010, 4,
    3924, 3933, 3940, 3945, 4, 0x0005, 3, 0x8000, 1, 0x8001,
    2, 0x8002, 4, 3, 0x0005, 3, 0x8001, 2, 0x8002, 4,
    2, 0x0005, 3, 0x8002, 4, 1, 0x8002, 4, 3958, 3963,
    3966, 3969, 3984, 3997, 4008, 4017, 4024, 4029, 2, 0x8000,
    1, 0x8001, 2, 1, 0x8001, 2, 1, 0x8002, 3, 7,
    0x8003, 4, 0x8004, 5, 0x8005, 6, 0x8006, 7, 0x8007, 8,
    0x8008, 9, 0x8009, 10, 6, 0x8004, 5, 0x8005, 6, 0x8006,
    7, 0x8007, 8, 0x8008, 9, 0x8009, 10, 5, 0x8005, 6,
    0x8006, 7, 0x8007, 8, 0x8008, 9, 0x8009, 10, 4, 0x8006,
    7, 0x8007, 8, 0x8008, 9, 0x8009, 10, 3, 0x8007, 8,
    0x8008, 9, 0x8009, 10, 2, 0x8008, 9, 0x8009, 10, 1,
    0x8009, 10, 4036, 4041, 4044, 4049, 2, 0x8000, 1, 0x8001,
    2, 1, 0x8001, 2, 2, 0x8002, 3, 0x8003, 4, 1,
    0x8003, 4, 4062, 4065, 4068, 4071, 4086, 4099, 4110, 4119,
    4126, 4131, 1, 0x0004, 1, 1, 0x8001, 2, 1, 0x0004,
    3, 7, 0x0010, 5, 0x8002, 9, 0x8006, 6, 0x800a, 4,
    0x800b, 7, 0x800c, 8, 0x800d, 10, 6, 0x0010, 5, 0x8002,
    9, 0x8006, 6, 0x800b, 7, 0x800c, 8, 0x800d, 10, 5,
    0x8002, 9, 0x8006, 6, 0x800b, 7, 0x800c, 8, 0x800d, 10,
    4, 0x8002, 9, 0x800b, 7, 0x800c, 8, 0x800d, 10, 3,
    0x8002, 9, 0x800c, 8, 0x800d, 10, 2, 0x8002, 9, 0x800d,
    10, 1, 0x800d, 10, 4137, 4142, 4147, 2, 0x0004, 1,
    0x0010, 1, 2, 0x000a, 2, 0x0010, 3, 1, 0x0010, 3,
    4154, 4157, 4164, 4169, 1, 0x0004, 1, 3, 0x0010, 4,
    0x8000, 2, 0x8001, 3, 2, 0x0010, 4, 0x8001, 3, 1,
    0x0010, 4, 4175, 4182, 4187, 3, 0x0010, 3, 0x8000, 1,
    0x8001, 2, 2, 0x0010, 3, 0x8001, 2, 1, 0x0010, 3,
    4197, 4200, 4213, 4224, 4233, 4240, 4245, 1, 0x0004, 1,
    6, 0x0002, 2, 0x0004, 5, 0x0005, 3, 0x0010, 4, 0x8000,
    6, 0x8001, 7, 5, 0x0004, 5, 0x0005, 3, 0x0010, 4,
    0x8000, 6, 0x8001, 7, 4, 0x0004, 5, 0x0010, 4, 0x8000,
    6, 0x8001, 7, 3, 0x0004, 5, 0x8000, 6, 0x8001, 7,
    2, 0x8000, 6, 0x8001, 7, 1, 0x8001, 7, 4252, 4263,
    4272, 4277, 5, 0x0004, 1, 0x8000, 2, 0x8001, 2, 0x8002,
    3, 0x8003, 4, 4, 0x8000, 2, 0x8001, 2, 0x8002, 3,
    0x8003, 4, 2, 0x8002, 3, 0x8003, 4, 1, 0x8003, 4,
    4288, 4291, 4294, 4307, 4318, 4327, 4334, 4339, 1, 0x0004,
    1, 1, 0x000a, 2, 6, 0x0001, 4, 0x0004, 6, 0x000a,
    5, 0x0010, 3, 0x8000, 7, 0x8001, 8, 5, 0x0001, 4,
    0x0004, 6, 0x000a, 5, 0x8000, 7, 0x8001, 8, 4, 0x0004,
    6, 0x000a, 5, 0x8000, 7, 0x8001, 8, 3, 0x0004, 6,
    0x8000, 7, 0x8001, 8, 2, 0x8000, 7, 0x8001, 8, 1,
    0x8001, 8, 4351, 4354, 4357, 4360, 4373, 4384, 4393, 4400,
    4405, 1, 0x0004, 1, 1, 0x0004, 2, 1, 0x0004, 3,
    6, 0x0010, 4, 0x8000, 5, 0x8001, 6, 0x8002, 7, 0x8003,
    8, 0x8004, 9, 5, 0x8000, 5, 0x8001, 6, 0x8002, 7,
    0x8003, 8, 0x8004, 9, 4, 0x8001, 6, 0x8002, 7, 0x8003,
    8, 0x8004, 9, 3, 0x8002, 7, 0x8003, 8, 0x8004, 9,
    2, 0x8003, 8, 0x8004, 9, 1, 0x8004, 9, 4427, 4430,
    4467, 4502, 4535, 4566, 4595, 4622, 4647, 4670, 4691, 4710,
    4727, 4742, 4755, 4766, 4775, 4782, 4787, 1, 0x0010, 1,
    18, 0x8000, 2, 0x8001, 3, 0x8002, 4, 0x8003, 8, 0x8004,
    5, 0x8005, 6, 0x8006, 7, 0x8007, 9, 0x8008, 11, 0x8009,
    10, 0x800a, 12, 0x800b, 13, 0x800c, 14, 0x800d, 15, 0x800e,
    16, 0x800f, 17, 0x8010, 18, 0x8011, 19, 17, 0x8001, 3,
    0x8002, 4, 0x8003, 8, 0x8004, 5, 0x8005, 6, 0x8006, 7,
    0x8007, 9, 0x8008, 11, 0x8009, 10, 0x800a, 12, 0x800b, 13,
    0x800c, 14, 0x800d, 15, 0x800e, 16, 0x800f, 17, 0x8010, 18,
    0x8011, 19, 16, 0x8002, 4, 0x8003, 8, 0x8004, 5, 0x8005,
    6, 0x8006, 7, 0x8007, 9, 0x8008, 11, 0x8009, 10, 0x800a,
    12, 0x800b, 13, 0x800c, 14, 0x800d, 15, 0x800e, 16, 0x800f,
    17, 0x8010, 18, 0x8011, 19, 15, 0x8003, 8, 0x8004, 5,
    0x8005, 6, 0x8006, 7, 0x8007, 9, 0x8008, 11, 0x8009, 10,
    0x800a, 12, 0x800b, 13, 0x800c, 14, 0x800d, 15, 0x800e, 16,
    0x800f, 17, 0x8010, 18, 0x8011, 19, 14, 0x8003, 8, 0x8005,
    6, 0x8006, 7, 0x8007, 9, 0x8008, 11, 0x8009, 10, 0x800a,
    12, 0x800b, 13, 0x800c, 14, 0x800d, 15, 0x800e, 16, 0x800f,
    17, 0x8010, 18, 0x8011, 19, 13, 0x8003, 8, 0x8006, 7,
    0x8007, 9, 0x8008, 11, 0x8009, 10, 0x800a, 12, 0x800b, 13,
    0x800c, 14, 0x800d, 15, 0x800e, 16, 0x800f, 17, 0x8010, 18,
    0x8011, 19, 12, 0x8003, 8, 0x8007, 9, 0x8008, 11, 0x8009,
    10, 0x800a, 12, 0x800b, 13, 0x800c, 14, 0x800d, 15, 0x800e,
    16, 0x800f, 17, 0x8010, 18, 0x8011, 19, 11, 0x8007, 9,
    0x8008, 11, 0x8009, 10, 0x800a, 12, 0x800b, 13, 0x800c, 14,
    0x800d, 15, 0x800e, 16, 0x800f, 17, 0x8010, 18, 0x8011, 19,
    10, 0x8008, 11, 0x8009, 10, 0x800a, 12, 0x800b, 13, 0x800c,
    14, 0x800d, 15, 0x800e, 16, 0x800f, 17, 0x8010, 18, 0x8011,
    19, 9, 0x8008, 11, 0x800a, 12, 0x800b, 13, 0x800c, 14,
    0x800d, 15, 0x800e, 16, 0x800f, 17, 0x8010, 18, 0x8011, 19,
    8, 0x800a, 12, 0x800b, 13, 0x800c, 14, 0x800d, 15, 0x800e,
    16, 0x800f, 17, 0x8010, 18, 0x8011, 19, 7, 0x800b, 13,
    0x800c, 14, 0x800d, 15, 0x800e, 16, 0x800f, 17, 0x8010, 18,
    0x8011, 19, 6, 0x800c, 14, 0x800d, 15, 0x800e, 16, 0x800f,
    17, 0x8010, 18, 0x8011, 19, 5, 0x800d, 15, 0x800e, 16,
    0x800f, 17, 0x8010, 18, 0x8011, 19, 4, 0x800e, 16, 0x800f,
    17, 0x8010, 18, 0x8011, 19, 3, 0x800f, 17, 0x8010, 18,
    0x8011, 19, 2, 0x8010, 18, 0x8011, 19, 1, 0x8011, 19,
    4817, 4872, 4925, 4976, 5025, 5072, 5117, 5160, 5201, 5240,
    5277, 5312, 5345, 5376, 5405, 5432, 5457, 5480, 5501, 5520,
    5537, 5552, 5565, 5576, 5585, 5592, 5597, 27, 0x0005, 2,
    0x8000, 1, 0x8001, 3, 0x8002, 4, 0x8003, 5, 0x8004, 6,
    0x8005, 7, 0x8006, 8, 0x8007, 9, 0x8008, 13, 0x8009, 10,
    0x800a, 11, 0x800b, 12, 0x800c, 14, 0x800d, 15, 0x800e, 16,
    0x800f, 17, 0x8010, 19, 0x8011, 20, 0x8012, 21, 0x8013, 22,
    0x8014, 18, 0x8015, 23, 0x8016, 24, 0x8017, 25, 0x8018, 26,
    0x8019, 27, 26, 0x0005, 2, 0x8001, 3, 0x8002, 4, 0x8003,
    5, 0x8004, 6, 0x8005, 7, 0x8006, 8, 0x8007, 9, 0x8008,
    13, 0x8009, 10, 0x800a, 11, 0x800b, 12, 0x800c, 14, 0x800d,
    15, 0x800e, 16, 0x800f, 17, 0x8010, 19, 0x8011, 20, 0x8012,
    21, 0x8013, 22, 0x8014, 18, 0x8015, 23, 0x8016, 24, 0x8017,
    25, 0x8018, 26, 0x8019, 27, 25, 0x8001, 3, 0x8002, 4,
    0x8003, 5, 0x8004, 6, 0x8005, 7, 0x8006, 8, 0x8007, 9,
    0x8008, 13, 0x8009, 10, 0x800a, 11, 0x800b, 12, 0x800c, 14,
    0x800d, 15, 0x800e, 16, 0x800f, 17, 0x8010, 19, 0x8011, 20,
    0x8012, 21, 0x8013, 22, 0x8014, 18, 0x8015, 23, 0x8016, 24,
    0x8017, 25, 0x8018, 26, 0x8019, 27, 24, 0x8002, 4, 0x8003,
    5, 0x8004, 6, 0x8005, 7, 0x8006, 8, 0x8007, 9, 0x8008,
    13, 0x8009, 10, 0x800a, 11, 0x800b, 12, 0x800c, 14, 0x800d,
    15, 0x800e, 16, 0x800f, 17, 0x8010, 19, 0x8011, 20, 0x8012,
    21, 0x8013, 22, 0x8014, 18, 0x8015, 23, 0x8016, 24, 0x8017,
    25, 0x8018, 26, 0x8019, 27, 23, 0x8003, 5, 0x8004, 6,
    0x8005, 7, 0x8006, 8, 0x8007, 9, 0x8008, 13, 0x8009, 10,
    0x800a, 11, 0x800b, 12, 0x800c, 14, 0x800d, 15, 0x800e, 16,
    0x800f, 17, 0x8010, 19, 0x8011, 20, 0x8012, 21, 0x8013, 22,
    0x8014, 18, 0x8015, 23, 0x8016, 24, 0x8017, 25, 0x8018, 26,
    0x8019, 27, 22, 0x8004, 6, 0x8005, 7, 0x8006, 8, 0x8007,
    9, 0x8008, 13, 0x8009, 10, 0x800a, 11, 0x800b, 12, 0x800c,
    14, 0x800d, 15, 0x800e, 16, 0x800f, 17, 0x8010, 19, 0x8011,
    20, 0x8012, 21, 0x8013, 22, 0x8014, 18, 0x8015, 23, 0x8016,
    24, 0x8017, 25, 0x8018, 26, 0x8019, 27, 21, 0x8005, 7,
    0x8006, 8, 0x8007, 9, 0x8008, 13, 0x8009, 10, 0x800a, 11,
    0x800b, 12, 0x800c, 14, 0x800d, 15, 0x800e, 16, 0x800f, 17,
    0x8010, 19, 0x8011, 20, 0x8012, 21, 0x8013, 22, 0x8014, 18,
    0x8015, 23, 0x8016, 24, 0x8017, 25, 0x8018, 26, 0x8019, 27,
    20, 0x8006, 8, 0x8007, 9, 0x8008, 13, 0x8009, 10, 0x800a,
    11, 0x800b, 12, 0x800c, 14, 0x800d, 15, 0x800e, 16, 0x800f,
    17, 0x8010, 19, 0x8011, 20, 0x8012, 21, 0x8013, 22, 0x8014,
    18, 0x8015, 23, 0x8016, 24, 0x8017, 25, 0x8018, 26, 0x8019,
    27, 19, 0x8007, 9, 0x8008, 13, 0x8009, 10, 0x800a, 11,
    0x800b, 12, 0x800c, 14, 0x800d, 15, 0x800e, 16, 0x800f, 17,
    0x8010, 19, 0x8011, 20, 0x8012, 21, 0x8013, 22, 0x8014, 18,
    0x8015, 23, 0x8016, 24, 0x8017, 25, 0x8018, 26, 0x8019, 27,
    18, 0x8008, 13, 0x8009, 10, 0x800a, 11, 0x800b, 12, 0x800c,
    14, 0x800d, 15, 0x800e, 16, 0x800f, 17, 0x8010, 19, 0x8011,
    20, 0x8012, 21, 0x8013, 22, 0x8014, 18, 0x8015, 23, 0x8016,
    24, 0x8017, 25, 0x8018, 26, 0x8019, 27, 17, 0x8008, 13,
    0x800a, 11, 0x800b, 12, 0x800c, 14, 0x800d, 15, 0x800e, 16,
    0x800f, 17, 0x8010, 19, 0x8011, 20, 0x8012, 21, 0x8013, 22,
    0x8014, 18, 0x8015, 23, 0x8016, 24, 0x8017, 25, 0x8018, 26,
    0x8019, 27, 16, 0x8008, 13, 0x800b, 12, 0x800c, 14, 0x800d,
    15, 0x800e, 16, 0x800f, 17, 0x8010, 19, 0x8011, 20, 0x8012,
    21, 0x8013, 22, 0x8014, 18, 0x8015, 23, 0x8016, 24, 0x8017,
    25, 0x8018, 26, 0x8019, 27, 15, 0x8008, 13, 0x800c, 14,
    0x800d, 15, 0x800e, 16, 0x800f, 17, 0x8010, 19, 0x8011, 20,
    0x8012, 21, 0x8013, 22, 0x8014, 18, 0x8015, 23, 0x8016, 24,
    0x8017, 25, 0x8018, 26, 0x8019, 27, 14, 0x800c, 14, 0x800d,
    15, 0x800e, 16, 0x800f, 17, 0x8010, 19, 0x8011, 20, 0x8012,
    21, 0x8013, 22, 0x8014, 18, 0x8015, 23, 0x8016, 24, 0x8017,
    25, 0x8018, 26, 0x8019, 27, 13, 0x800d, 15, 0x800e, 16,
    0x800f, 17, 0x8010, 19, 0x8011, 20, 0x8012, 21, 0x8013, 22,
    0x8014, 18, 0x8015, 23, 0x8016, 24, 0x8017, 25, 0x8018, 26,
    0x8019, 27, 12, 0x800e, 16, 0x800f, 17, 0x8010, 19, 0x8011,
    20, 0x8012, 21, 0x8013, 22, 0x8014, 18, 0x8015, 23, 0x8016,
    24, 0x8017, 25, 0x8018, 26, 0x8019, 27, 11, 0x800f, 17,
    0x8010, 19, 0x8011, 20, 0x8012, 21, 0x8013, 22, 0x8014, 18,
    0x8015, 23, 0x8016, 24, 0x8017, 25, 0x8018, 26, 0x8019, 27,
    10, 0x8010, 19, 0x8011, 20, 0x8012, 21, 0x8013, 22, 0x8014,
    18, 0x8015, 23, 0x8016, 24, 0x8017, 25, 0x8018, 26, 0x8019,
    27, 9, 0x8010, 19, 0x8011, 20, 0x8012, 21, 0x8013, 22,
    0x8015, 23, 0x8016, 24, 0x8017, 25, 0x8018, 26, 0x8019, 27,
    8, 0x8011, 20, 0x8012, 21, 0x8013, 22, 0x8015, 23, 0x8016,
    24, 0x8017, 25, 0x8018, 26, 0x8019, 27, 7, 0x8012, 21,
    0x8013, 22, 0x8015, 23, 0x8016, 24, 0x8017, 25, 0x8018, 26,
    0x8019, 27, 6, 0x8013, 22, 0x8015, 23, 0x8016, 24, 0x8017,
    25, 0x8018, 26, 0x8019, 27, 5, 0x8015, 23, 0x8016, 24,
    0x8017, 25, 0x8018, 26, 0x8019, 27, 4, 0x8016, 24, 0x8017,
    25, 0x8018, 26, 0x8019, 27, 3, 0x8017, 25, 0x8018, 26,
    0x8019, 27, 2, 0x8018, 26, 0x8019, 27, 1, 0x8019, 27,
    5610, 5631, 5650, 5667, 5682, 5695, 5706, 5715, 5722, 5727,
    10, 0x0005, 5, 0x8000, 1, 0x8001, 2, 0x8002, 3, 0x8003,
    4, 0x8004, 8, 0x8005, 6, 0x8006, 7, 0x8007, 9, 0x8008,
    10, 9, 0x0005, 5, 0x8001, 2, 0x8002, 3, 0x8003, 4,
    0x8004, 8, 0x8005, 6, 0x8006, 7, 0x8007, 9, 0x8008, 10,
    8, 0x0005, 5, 0x8002, 3, 0x8003, 4, 0x8004, 8, 0x8005,
    6, 0x8006, 7, 0x8007, 9, 0x8008, 10, 7, 0x0005, 5,
    0x8003, 4, 0x8004, 8, 0x8005, 6, 0x8006, 7, 0x8007, 9,
    0x8008, 10, 6, 0x0005, 5, 0x8004, 8, 0x8005, 6, 0x8006,
    7, 0x8007, 9, 0x8008, 10, 5, 0x8004, 8, 0x8005, 6,
    0x8006, 7, 0x8007, 9, 0x8008, 10, 4, 0x8004, 8, 0x8006,
    7, 0x8007, 9, 0x8008, 10, 3, 0x8004, 8, 0x8007, 9,
    0x8008, 10, 2, 0x8007, 9, 0x8008, 10, 1, 0x8008, 10,
    5738, 5743, 5746, 5759, 5770, 5779, 5786, 5791, 2, 0x8000,
    1, 0x8001, 2, 1, 0x8001, 2, 6, 0x8002, 3, 0x8003,
    4, 0x8004, 5, 0x8005, 6, 0x8006, 7, 0x8007, 8, 5,
    0x8003, 4, 0x8004, 5, 0x8005, 6, 0x8006, 7, 0x8007, 8,
    4, 0x8004, 5, 0x8005, 6, 0x8006, 7, 0x8007, 8, 3,
    0x8005, 6, 0x8006, 7, 0x8007, 8, 2, 0x8006, 7, 0x8007,
    8, 1, 0x8007, 8, 5796, 5799, 1, 0x0010, 1, 1,
    0x8000, 2, 5810, 5813, 5828, 5841, 5852, 5861, 5868, 5873,
    1, 0x0010, 1, 7, 0x8000, 6, 0x8001, 2, 0x8002, 3,
    0x8003, 4, 0x8004, 5, 0x8005, 7, 0x8006, 8, 6, 0x8000,
    6, 0x8002, 3, 0x8003, 4, 0x8004, 5, 0x8005, 7, 0x8006,
    8, 5, 0x8000, 6, 0x8003, 4, 0x8004, 5, 0x8005, 7,
    0x8006, 8, 4, 0x8000, 6, 0x8004, 5, 0x8005, 7, 0x8006,
    8, 3, 0x8000, 6, 0x8005, 7, 0x8006, 8, 2, 0x8005,
    7, 0x8006, 8, 1, 0x8006, 8, 5884, 5887, 5890, 5903,
    5914, 5923, 5930, 5935, 1, 0x8000, 1, 1, 0x0002, 2,
    6, 0x0005, 3, 0x0010, 5, 0x8001, 4, 0x8002, 6, 0x8003,
    7, 0x8004, 8, 5, 0x0010, 5, 0x8001, 4, 0x8002, 6,
    0x8003, 7, 0x8004, 8, 4, 0x0010, 5, 0x8002, 6, 0x8003,
    7, 0x8004, 8, 3, 0x8002, 6, 0x8003, 7, 0x8004, 8,
    2, 0x8003, 7, 0x8004, 8, 1, 0x8004, 8, 5940, 5947,
    3, 0x0010, 2, 0x8000, 1, 0x8001, 1, 1, 0x0010, 2,
    5953, 5956, 5959, 1, 0x0004, 1, 1, 0x0003, 2, 1,
    0x0010, 3, 5965, 5972, 5977, 3, 0x000a, 1, 0x0010, 2,
    0x8000, 3, 2, 0x0010, 2, 0x8000, 3, 1, 0x8000, 3,
    6012, 6077, 6140, 6201, 6260, 6317, 6372, 6425, 6476, 6525,
    6572, 6617, 6660, 6701, 6740, 6777, 6812, 6845, 6876, 6905,
    6932, 6957, 6980, 7001, 7020, 7037, 7052, 7065, 7076, 7085,
    7092, 7097, 32, 0x8000, 1, 0x8001, 2, 0x8002, 3, 0x8003,
    4, 0x8004, 5, 0x8006, 6, 0x8007, 7, 0x8008, 8, 0x8009,
    9, 0x800a, 10, 0x800b, 11, 0x800c, 12, 0x800d, 13, 0x800e,
    14, 0x800f, 15, 0x8010, 16, 0x8011, 26, 0x8012, 27, 0x8013,
    28, 0x8014, 29, 0x8015, 20, 0x8016, 21, 0x8017, 17, 0x8018,
    18, 0x8019, 19, 0x801a, 22, 0x801b, 23, 0x801c, 24, 0x801d,
    25, 0x801f, 30, 0x8020, 31, 0x8021, 32, 31, 0x8001, 2,
    0x8002, 3, 0x8003, 4, 0x8004, 5, 0x8006, 6, 0x8007, 7,
    0x8008, 8, 0x8009, 9, 0x800a, 10, 0x800b, 11, 0x800c, 12,
    0x800d, 13, 0x800e, 14, 0x800f, 15, 0x8010, 16, 0x8011, 26,
    0x8012, 27, 0x8013, 28, 0x8014, 29, 0x8015, 20, 0x8016, 21,
    0x8017, 17, 0x8018, 18, 0x8019, 19, 0x801a, 22, 0x801b, 23,
    0x801c, 24, 0x801d, 25, 0x801f, 30, 0x8020, 31, 0x8021, 32,
    30, 0x8002, 3, 0x8003, 4, 0x8004, 5, 0x8006, 6, 0x8007,
    7, 0x8008, 8, 0x8009, 9, 0x800a, 10, 0x800b, 11, 0x800c,
    12, 0x800d, 13, 0x800e, 14, 0x800f, 15, 0x8010, 16, 0x8011,
    26, 0x8012, 27, 0x8013, 28, 0x8014, 29, 0x8015, 20, 0x8016,
    21, 0x8017, 17, 0x8018, 18, 0x8019, 19, 0x801a, 22, 0x801b,
    23, 0x801c, 24, 0x801d, 25, 0x801f, 30, 0x8020, 31, 0x8021,
    32, 29, 0x8003, 4, 0x8004, 5, 0x8006, 6, 0x8007, 7,
    0x8008, 8, 0x8009, 9, 0x800a, 10, 0x800b, 11, 0x800c, 12,
    0x800d, 13, 0x800e, 14, 0x800f, 15, 0x8010, 16, 0x8011, 26,
    0x8012, 27, 0x8013, 28, 0x8014, 29, 0x8015, 20, 0x8016, 21,
    0x8017, 17, 0x8018, 18, 0x8019, 19, 0x801a, 22, 0x801b, 23,
    0x801c, 24, 0x801d, 25, 0x801f, 30, 0x8020, 31, 0x8021, 32,
    28, 0x8004, 5, 0x8006, 6, 0x8007, 7, 0x8008, 8, 0x8009,
    9, 0x800a, 10, 0x800b, 11, 0x800c, 12, 0x800d, 13, 0x800e,
    14, 0x800f, 15, 0x8010, 16, 0x8011, 26, 0x8012, 27, 0x8013,
    28, 0x8014, 29, 0x8015, 20, 0x8016, 21, 0x8017, 17, 0x8018,
    18, 0x8019, 19, 0x801a, 22, 0x801b, 23, 0x801c, 24, 0x801d,
    25, 0x801f, 30, 0x8020, 31, 0x8021, 32, 27, 0x8006, 6,
    0x8007, 7, 0x8008, 8, 0x8009, 9, 0x800a, 10, 0x800b, 11,
    0x800c, 12, 0x800d, 13, 0x800e, 14, 0x800f, 15, 0x8010, 16,
    0x8011, 26, 0x8012, 27, 0x8013, 28, 0x8014, 29, 0x8015, 20,
    0x8016, 21, 0x8017, 17, 0x8018, 18, 0x8019, 19, 0x801a, 22,
    0x801b, 23, 0x801c, 24, 0x801d, 25, 0x801f, 30, 0x8020, 31,
    0x8021, 32, 26, 0x8007, 7, 0x8008, 8, 0x8009, 9, 0x800a,
    10, 0x800b, 11, 0x800c, 12, 0x800d, 13, 0x800e, 14, 0x800f,
    15, 0x8010, 16, 0x8011, 26, 0x8012, 27, 0x8013, 28, 0x8014,
    29, 0x8015, 20, 0x8016, 21, 0x8017, 17, 0x8018, 18, 0x8019,
    19, 0x801a, 22, 0x801b, 23, 0x801c, 24, 0x801d, 25, 0x801f,
    30, 0x8020, 31, 0x8021, 32, 25, 0x8008, 8, 0x8009, 9,
    0x800a, 10, 0x800b, 11, 0x800c, 12, 0x800d, 13, 0x800e, 14,
    0x800f, 15, 0x8010, 16, 0x8011, 26, 0x8012, 27, 0x8013, 28,
    0x8014, 29, 0x8015, 20, 0x8016, 21, 0x8017, 17, 0x8018, 18,
    0x8019, 19, 0x801a, 22, 0x801b, 23, 0x801c, 24, 0x801d, 25,
    0x801f, 30, 0x8020, 31, 0x8021, 32, 24, 0x8009, 9, 0x800a,
    10, 0x800b, 11, 0x800c, 12, 0x800d, 13, 0x800e, 14, 0x800f,
    15, 0x8010, 16, 0x8011, 26, 0x8012, 27, 0x8013, 28, 0x8014,
    29, 0x8015, 20, 0x8016, 21, 0x8017, 17, 0x8018, 18, 0x8019,
    19, 0x801a, 22, 0x801b, 23, 0x801c, 24, 0x801d, 25, 0x801f,
    30, 0x8020, 31, 0x8021, 32, 23, 0x800a, 10, 0x800b, 11,
    0x800c, 12, 0x800d, 13, 0x800e, 14, 0x800f, 15, 0x8010, 16,
    0x8011, 26, 0x8012, 27, 0x8013, 28, 0x8014, 29, 0x8015, 20,
    0x8016, 21, 0x8017, 17, 0x8018, 18, 0x8019, 19, 0x801a, 22,
    0x801b, 23, 0x801c, 24, 0x801d, 25, 0x801f, 30, 0x8020, 31,
    0x8021, 32, 22, 0x800b, 11, 0x800c, 12, 0x800d, 13, 0x800e,
    14, 0x800f, 15, 0x8010, 16, 0x8011, 26, 0x8012, 27, 0x8013,
    28, 0x8014, 29, 0x8015, 20, 0x8016, 21, 0x8017, 17, 0x8018,
    18, 0x8019, 19, 0x801a, 22, 0x801b, 23, 0x801c, 24, 0x801d,
    25, 0x801f, 30, 0x8020, 31, 0x8021, 32, 21, 0x800c, 12,
    0x800d, 13, 0x800e, 14, 0x800f, 15, 0x8010, 16, 0x8011, 26,
    0x8012, 27, 0x8013, 28, 0x8014, 29, 0x8015, 20, 0x8016, 21,
    0x8017, 17, 0x8018, 18, 0x8019, 19, 0x801a, 22, 0x801b, 23,
    0x801c, 24, 0x801d, 25, 0x801f, 30, 0x8020, 31, 0x8021, 32,
    20, 0x800d, 13, 0x800e, 14, 0x800f, 15, 0x8010, 16, 0x8011,
    26, 0x8012, 27, 0x8013, 28, 0x8014, 29, 0x8015, 20, 0x8016,
    21, 0x8017, 17, 0x8018, 18, 0x8019, 19, 0x801a, 22, 0x801b,
    23, 0x801c, 24, 0x801d, 25, 0x801f, 30, 0x8020, 31, 0x8021,
    32, 19, 0x800e, 14, 0x800f, 15, 0x8010, 16, 0x8011, 26,
    0x8012, 27, 0x8013, 28, 0x8014, 29, 0x8015, 20, 0x8016, 21,
    0x8017, 17, 0x8018, 18, 0x8019, 19, 0x801a, 22, 0x801b, 23,
    0x801c, 24, 0x801d, 25, 0x801f, 30, 0x8020, 31, 0x8021, 32,
    18, 0x800f, 15, 0x8010, 16, 0x8011, 26, 0x8012, 27, 0x8013,
    28, 0x8014, 29, 0x8015, 20, 0x8016, 21, 0x8017, 17, 0x8018,
    18, 0x8019, 19, 0x801a, 22, 0x801b, 23, 0x801c, 24, 0x801d,
    25, 0x801f, 30, 0x8020, 31, 0x8021, 32, 17, 0x8010, 16,
    0x8011, 26, 0x8012, 27, 0x8013, 28, 0x8014, 29, 0x8015, 20,
    0x8016, 21, 0x8017, 17, 0x8018, 18, 0x8019, 19, 0x801a, 22,
    0x801b, 23, 0x801c, 24, 0x801d, 25, 0x801f, 30, 0x8020, 31,
    0x8021, 32, 16, 0x8011, 26, 0x8012, 27, 0x8013, 28, 0x8014,
    29, 0x8015, 20, 0x8016, 21, 0x8017, 17, 0x8018, 18, 0x8019,
    19, 0x801a, 22, 0x801b, 23, 0x801c, 24, 0x801d, 25, 0x801f,
    30, 0x8020, 31, 0x8021, 32, 15, 0x8011, 26, 0x8012, 27,
    0x8013, 28, 0x8014, 29, 0x8015, 20, 0x8016, 21, 0x8018, 18,
    0x8019, 19, 0x801a, 22, 0x801b, 23, 0x801c, 24, 0x801d, 25,
    0x801f, 30, 0x8020, 31, 0x8021, 32, 14, 0x8011, 26, 0x8012,
    27, 0x8013, 28, 0x8014, 29, 0x8015, 20, 0x8016, 21, 0x8019,
    19, 0x801a, 22, 0x801b, 23, 0x801c, 24, 0x801d, 25, 0x801f,
    30, 0x8020, 31, 0x8021, 32, 13, 0x8011, 26, 0x8012, 27,
    0x8013, 28, 0x8014, 29, 0x8015, 20, 0x8016, 21, 0x801a, 22,
    0x801b, 23, 0x801c, 24, 0x801d, 25, 0x801f, 30, 0x8020, 31,
    0x8021, 32, 12, 0x8011, 26, 0x8012, 27, 0x8013, 28, 0x8014,
    29, 0x8016, 21, 0x801a, 22, 0x801b, 23, 0x801c, 24, 0x801d,
    25, 0x801f, 30, 0x8020, 31, 0x8021, 32, 11, 0x8011, 26,
    0x8012, 27, 0x8013, 28, 0x8014, 29, 0x801a, 22, 0x801b, 23,
    0x801c, 24, 0x801d, 25, 0x801f, 30, 0x8020, 31, 0x8021, 32,
    10, 0x8011, 26, 0x8012, 27, 0x8013, 28, 0x8014, 29, 0x801b,
    23, 0x801c, 24, 0x801d, 25, 0x801f, 30, 0x8020, 31, 0x8021,
    32, 9, 0x8011, 26, 0x8012, 27, 0x8013, 28, 0x8014, 29,
    0x801c, 24, 0x801d, 25, 0x801f, 30, 0x8020, 31, 0x8021, 32,
    8, 0x8011, 26, 0x8012, 27, 0x8013, 28, 0x8014, 29, 0x801d,
    25, 0x801f, 30, 0x8020, 31, 0x8021, 32, 7, 0x8011, 26,
    0x8012, 27, 0x8013, 28, 0x8014, 29, 0x801f, 30, 0x8020, 31,
    0x8021, 32, 6, 0x8012, 27, 0x8013, 28, 0x8014, 29, 0x801f,
    30, 0x8020, 31, 0x8021, 32, 5, 0x8013, 28, 0x8014, 29,
    0x801f, 30, 0x8020, 31, 0x8021, 32, 4, 0x8014, 29, 0x801f,
    30, 0x8020, 31, 0x8021, 32, 3, 0x801f, 30, 0x8020, 31,
    0x8021, 32, 2, 0x8020, 31, 0x8021, 32, 1, 0x8021, 32,
    7108, 7125, 7140, 7153, 7164, 7173, 7180, 7185, 8, 0x8001,
    1, 0x8002, 2, 0x8003, 3, 0x8004, 4, 0x8005, 5, 0x8006,
    6, 0x8007, 7, 0x8008, 8, 7, 0x8002, 2, 0x8003, 3,
    0x8004, 4, 0x8005, 5, 0x8006, 6, 0x8007, 7, 0x8008, 8,
    6, 0x8003, 3, 0x8004, 4, 0x8005, 5, 0x8006, 6, 0x8007,
    7, 0x8008, 8, 5, 0x8004, 4, 0x8005, 5, 0x8006, 6,
    0x8007, 7, 0x8008, 8, 4, 0x8005, 5, 0x8006, 6, 0x8007,
    7, 0x8008, 8, 3, 0x8006, 6, 0x8007, 7, 0x8008, 8,
    2, 0x8007, 7, 0x8008, 8, 1, 0x8008, 8, 7204, 7207,
    7238, 7267, 7294, 7319, 7342, 7363, 7382, 7399, 7414, 7427,
    7438, 7447, 7454, 7459, 1, 0x8000, 1, 15, 0x8001, 2,
    0x8002, 3, 0x8004, 4, 0x8005, 5, 0x8006, 9, 0x8007, 6,
    0x8008, 7, 0x8009, 8, 0x800a, 10, 0x800b, 11, 0x800c, 12,
    0x800d, 13, 0x800e, 14, 0x800f, 15, 0x8010, 16, 14, 0x8002,
    3, 0x8004, 4, 0x8005, 5, 0x8006, 9, 0x8007, 6, 0x8008,
    7, 0x8009, 8, 0x800a, 10, 0x800b, 11, 0x800c, 12, 0x800d,
    13, 0x800e, 14, 0x800f, 15, 0x8010, 16, 13, 0x8004, 4,
    0x8005, 5, 0x8006, 9, 0x8007, 6, 0x8008, 7, 0x8009, 8,
    0x800a, 10, 0x800b, 11, 0x800c, 12, 0x800d, 13, 0x800e, 14,
    0x800f, 15, 0x8010, 16, 12, 0x8005, 5, 0x8006, 9, 0x8007,
    6, 0x8008, 7, 0x8009, 8, 0x800a, 10, 0x800b, 11, 0x800c,
    12, 0x800d, 13, 0x800e, 14, 0x800f, 15, 0x8010, 16, 11,
    0x8006, 9, 0x8007, 6, 0x8008, 7, 0x8009, 8, 0x800a, 10,
    0x800b, 11, 0x800c, 12, 0x800d, 13, 0x800e, 14, 0x800f, 15,
    0x8010, 16, 10, 0x8006, 9, 0x8008, 7, 0x8009, 8, 0x800a,
    10, 0x800b, 11, 0x800c, 12, 0x800d, 13, 0x800e, 14, 0x800f,
    15, 0x8010, 16, 9, 0x8006, 9, 0x8009, 8, 0x800a, 10,
    0x800b, 11, 0x800c, 12, 0x800d, 13, 0x800e, 14, 0x800f, 15,
    0x8010, 16, 8, 0x8006, 9, 0x800a, 10, 0x800b, 11, 0x800c,
    12, 0x800d, 13, 0x800e, 14, 0x800f, 15, 0x8010, 16, 7,
    0x800a, 10, 0x800b, 11, 0x800c, 12, 0x800d, 13, 0x800e, 14,
    0x800f, 15, 0x8010, 16, 6, 0x800b, 11, 0x800c, 12, 0x800d,
    13, 0x800e, 14, 0x800f, 15, 0x8010, 16, 5, 0x800c, 12,
    0x800d, 13, 0x800e, 14, 0x800f, 15, 0x8010, 16, 4, 0x800d,
    13, 0x800e, 14, 0x800f, 15, 0x8010, 16, 3, 0x800e, 14,
    0x800f, 15, 0x8010, 16, 2, 0x800f, 15, 0x8010, 16, 1,
    0x8010, 16, 7464, 7469, 2, 0x0010, 2, 0x8000, 1, 1,
    0x0010, 2, 7476, 7479, 7484, 7487, 1, 0x8000, 1, 2,
    0x8001, 2, 0x8002, 3, 1, 0x8002, 3, 1, 0x8003, 4,
    7494, 7497, 7500, 7505, 1, 0x8000, 1, 1, 0x8001, 2,
    2, 0x8002, 3, 0x8003, 4, 1, 0x8003, 4, 7512, 7515,
    7522, 7527, 1, 0x0004, 1, 3, 0x0004, 2, 0x0010, 3,
    0x8006, 4, 2, 0x0010, 3, 0x8006, 4, 1, 0x8006, 4,
    7533, 7536, 7541, 1, 0x0004, 1, 2, 0x0005, 2, 0x0010,
    3, 1, 0x0010, 3, 7546, 7549, 1, 0x0010, 1, 1,
    0x0010, 2, 7556, 7559, 7562, 7565, 1, 0x8000, 1, 1,
    0x8001, 2, 1, 0x8003, 3, 1, 0x8002, 4, 7573, 7576,
    7579, 7582, 7587, 1, 0x8000, 1, 1, 0x8001, 2, 1,
    0x8002, 3, 2, 0x8003, 4, 0x8004, 5, 1, 0x8004, 5,
    7600, 7621, 7640, 7657, 7672, 7685, 7696, 7705, 7712, 7717,
    10, 0x8001, 1, 0x8002, 2, 0x8003, 3, 0x8004, 4, 0x8005,
    5, 0x8006, 6, 0x8007, 7, 0x8008, 8, 0x8009, 9, 0x800a,
    10, 9, 0x8002, 2, 0x8003, 3, 0x8004, 4, 0x8005, 5,
    0x8006, 6, 0x8007, 7, 0x8008, 8, 0x8009, 9, 0x800a, 10,
    8, 0x8003, 3, 0x8004, 4, 0x8005, 5, 0x8006, 6, 0x8007,
    7, 0x8008, 8, 0x8009, 9, 0x800a, 10, 7, 0x8004, 4,
    0x8005, 5, 0x8006, 6, 0x8007, 7, 0x8008, 8, 0x8009, 9,
    0x800a, 10, 6, 0x8005, 5, 0x8006, 6, 0x8007, 7, 0x8008,
    8, 0x8009, 9, 0x800a, 10, 5, 0x8006, 6, 0x8007, 7,
    0x8008, 8, 0x8009, 9, 0x800a, 10, 4, 0x8007, 7, 0x8008,
    8, 0x8009, 9, 0x800a, 10, 3, 0x8008, 8, 0x8009, 9,
    0x800a, 10, 2, 0x8009, 9, 0x800a, 10, 1, 0x800a, 10,
    7728, 7731, 7734, 7747, 7758, 7767, 7774, 7779, 1, 0x8000,
    1, 1, 0x8001, 2, 6, 0x8002, 3, 0x8003, 4, 0x8004,
    5, 0x8005, 6, 0x8006, 7, 0x8007, 8, 5, 0x8003, 4,
    0x8004, 5, 0x8005, 6, 0x8006, 7, 0x8007, 8, 4, 0x8004,
    5, 0x8005, 6, 0x8006, 7, 0x8007, 8, 3, 0x8005, 6,
    0x8006, 7, 0x8007, 8, 2, 0x8006, 7, 0x8007, 8, 1,
    0x8007, 8, 7790, 7793, 7796, 7809, 7820, 7829, 7836, 7841,
    1, 0x0004, 1, 1, 0x0004, 2, 6, 0x0010, 8, 0x8000,
    3, 0x8001, 4, 0x8002, 5, 0x8003, 6, 0x8004, 7, 5,
    0x0010, 8, 0x8001, 4, 0x8002, 5, 0x8003, 6, 0x8004, 7,
    4, 0x0010, 8, 0x8002, 5, 0x8003, 6, 0x8004, 7, 3,
    0x0010, 8, 0x8003, 6, 0x8004, 7, 2, 0x0010, 8, 0x8004,
    7, 1, 0x0010, 8, 7853, 7856, 7859, 7862, 7865, 7876,
    7885, 7892, 7897, 1, 0x0002, 1, 1, 0x8000, 2, 1,
    0x8001, 3, 1, 0x8002, 4, 5, 0x8003, 5, 0x8005, 6,
    0x8006, 7, 0x8007, 8, 0x8008, 9, 4, 0x8005, 6, 0x8006,
    7, 0x8007, 8, 0x8008, 9, 3, 0x8006, 7, 0x8007, 8,
    0x8008, 9, 2, 0x8007, 8, 0x8008, 9, 1, 0x8008, 9,
    1, 0x8000, 1, 0x8001, 7906, 7909, 1, 0x0006, 1, 0,
    1, 0x8002, 1, 0x0003, 1, 0x8004, 1, 0x8005, 7925, 7928,
    7941, 7952, 7961, 7968, 7973, 1, 0x0004, 1, 6, 0x8000,
    2, 0x8001, 3, 0x8002, 4, 0x8003, 5, 0x8004, 6, 0x8005,
    7, 5, 0x8001, 3, 0x8002, 4, 0x8003, 5, 0x8004, 6,
    0x8005, 7, 4, 0x8002, 4, 0x8003, 5, 0x8004, 6, 0x8005,
    7, 3, 0x8003, 5, 0x8004, 6, 0x8005, 7, 2, 0x8004,
    6, 0x8005, 7, 1, 0x8005, 7, 1, 0x8006, 7981, 7984,
    7987, 1, 0x8000, 1, 1, 0x8002, 2, 1, 0x8003, 3,
    7997, 8000, 8013, 8024, 8033, 8040, 8045, 1, 0x8000, 1,
    6, 0x8001, 2, 0x8002, 3, 0x8003, 4, 0x8004, 5, 0x8005,
    6, 0x8006, 7, 5, 0x8002, 3, 0x8003, 4, 0x8004, 5,
    0x8005, 6, 0x8006, 7, 4, 0x8003, 4, 0x8004, 5, 0x8005,
    6, 0x8006, 7, 3, 0x8004, 5, 0x8005, 6, 0x8006, 7,
    2, 0x8005, 6, 0x8006, 7, 1, 0x8006, 7, 8049, 1,
    0x000a, 1, 8058, 8071, 8082, 8091, 8098, 8103, 6, 0x8000,
    1, 0x8001, 2, 0x8002, 3, 0x8003, 4, 0x8004, 5, 0x8005,
    6, 5, 0x8001, 2, 0x8002, 3, 0x8003, 4, 0x8004, 5,
    0x8005, 6, 4, 0x8002, 3, 0x8003, 4, 0x8004, 5, 0x8005,
    6, 3, 0x8003, 4, 0x8004, 5, 0x8005, 6, 2, 0x8004,
    5, 0x8005, 6, 1, 0x8005, 6, 1, 0x0002, 8111, 8114,
    8119, 1, 0x8000, 1, 2, 0x8001, 2, 0x8002, 3, 1,
    0x8002, 3, 1, 0x8007, 1, 0x8008, 1, 0x8009, 1, 0x800a,
    1, 0x800b, 1, 0x800c, 1, 0x800d, 1, 0x800e, 1, 0x800f,
    8143, 8146, 8151, 1, 0x0003, 1, 2, 0x8000, 2, 0x8001,
    3, 1, 0x8001, 3, 1, 0x8011, 1, 0x8012, 1, 0x8013,
    2, 0x0002, 1, 0x0006, 2, 3, 0x8000, 1, 0x8001, 2,
    0x8002, 3, 8175, 8178, 8185, 1, 0x0004, 1, 3, 0x8000,
    2, 0x8001, 2, 0x8002, 2, 1, 0x0004, 3, 8191, 8194,
    8197, 1, 0x000a, 1, 1, 0x0004, 2, 1, 0x0010, 3,
    2, 0x0004, 1, 0x0010, 2, 2, 0x8002, 1, 0x8003, 2,
    8213, 8216, 8219, 1, 0x0002, 1, 1, 0x0002, 2, 1,
    0x0010, 3, 8227, 8230, 8233, 8236, 8239, 1, 0x8000, 1,
    1, 0x8001, 2, 1, 0x8002, 3, 1, 0x8003, 4, 1,
    0x8004, 5, 8246, 8255, 8262, 8267, 4, 0x8005, 1, 0x8006,
    2, 0x8007, 3, 0x8008, 4, 3, 0x8006, 2, 0x8007, 3,
    0x8008, 4, 2, 0x8007, 3, 0x8008, 4, 1, 0x8008, 4,
    8273, 8280, 8285, 3, 0x000a, 1, 0x0010, 2, 0x8001, 3,
    2, 0x0010, 2, 0x8001, 3, 1, 0x8001, 3, 1, 0x0005,
    8294, 8297, 8304, 8309, 1, 0x0003, 1, 3, 0x0005, 2,
    0x0010, 3, 0x8000, 4, 2, 0x0010, 3, 0x8000, 4, 1,
    0x8000, 4, 1, 0x8010, 1, 0x8014, 1, 0x8015, 1, 0x8016,
    1, 0x8017, 1, 0x8018, 1, 0x8019, 1, 0x801a, 1, 0x801b,
    1, 0x801c, 1, 0x801d, 8339, 8350, 8359, 8366, 8371, 5,
    0x8004, 2, 0x8005, 1, 0x8006, 3, 0x8007, 4, 0x8008, 5,
    4, 0x8004, 2, 0x8006, 3, 0x8007, 4, 0x8008, 5, 3,
    0x8006, 3, 0x8007, 4, 0x8008, 5, 2, 0x8007, 4, 0x8008,
    5, 1, 0x8008, 5, 8379, 8382, 8385, 8388, 8391, 1,
    0x000a, 1, 1, 0x0002, 2, 1, 0x8000, 3, 1, 0x8001,
    4, 1, 0x8002, 5, 8399, 8402, 8411, 8418, 8423, 1,
    0x0010, 1, 4, 0x0010, 2, 0x8000, 3, 0x8001, 4, 0x8002,
    5, 3, 0x8000, 3, 0x8001, 4, 0x8002, 5, 2, 0x8001,
    4, 0x8002, 5, 1, 0x8002, 5, 8432, 8435, 8446, 8455,
    8462, 8467, 1, 0x000a, 1, 5, 0x8000, 2, 0x8001, 3,
    0x8002, 4, 0x8003, 5, 0x8004, 6, 4, 0x8001, 3, 0x8002,
    4, 0x8003, 5, 0x8004, 6, 3, 0x8002, 4, 0x8003, 5,
    0x8004, 6, 2, 0x8003, 5, 0x8004, 6, 1, 0x8004, 6,
    8473, 8476, 8481, 1, 0x000a, 1, 2, 0x8000, 2, 0x8001,
    3, 1, 0x8001, 3, 8489, 8492, 8495, 8498, 8501, 1,
    0x0004, 1, 1, 0x0002, 2, 1, 0x0004, 3, 1, 0x000a,
    4, 1, 0x0010, 5, 8509, 8520, 8529, 8536, 8541, 5,
    0x8000, 1, 0x8001, 2, 0x8002, 3, 0x8003, 4, 0x8004, 5,
    4, 0x8001, 2, 0x8002, 3, 0x8003, 4, 0x8004, 5, 3,
    0x8002, 3, 0x8003, 4, 0x8004, 5, 2, 0x8003, 4, 0x8004,
    5, 1, 0x8004, 5, 8547, 8552, 8555, 2, 0x0010, 1,
    0x8000, 2, 1, 0x8000, 2, 1, 0x8001, 3, 3, 0x0004,
    1, 0x0010, 1, 0x8008, 2, 8576, 8599, 8620, 8639, 8656,
    8671, 8684, 8695, 8704, 8711, 8716, 11, 0x0002, 1, 0x8000,
    2, 0x8001, 3, 0x8002, 4, 0x8003, 5, 0x8004, 6, 0x8005,
    7, 0x8006, 8, 0x8007, 9, 0x8008, 10, 0x8009, 11, 10,
    0x8000, 2, 0x8001, 3, 0x8002, 4, 0x8003, 5, 0x8004, 6,
    0x8005, 7, 0x8006, 8, 0x8007, 9, 0x8008, 10, 0x8009, 11,
    9, 0x8001, 3, 0x8002, 4, 0x8003, 5, 0x8004, 6, 0x8005,
    7, 0x8006, 8, 0x8007, 9, 0x8008, 10, 0x8009, 11, 8,
    0x8002, 4, 0x8003, 5, 0x8004, 6, 0x8005, 7, 0x8006, 8,
    0x8007, 9, 0x8008, 10, 0x8009, 11, 7, 0x8003, 5, 0x8004,
    6, 0x8005, 7, 0x8006, 8, 0x8007, 9, 0x8008, 10, 0x8009,
    11, 6, 0x8004, 6, 0x8005, 7, 0x8006, 8, 0x8007, 9,
    0x8008, 10, 0x8009, 11, 5, 0x8005, 7, 0x8006, 8, 0x8007,
    9, 0x8008, 10, 0x8009, 11, 4, 0x8006, 8, 0x8007, 9,
    0x8008, 10, 0x8009, 11, 3, 0x8007, 9, 0x8008, 10, 0x8009,
    11, 2, 0x8008, 10, 0x8009, 11, 1, 0x8009, 11, 4,
    0x000a, 3, 0x8000, 1, 0x8001, 2, 0x8002, 4, 8738, 8759,
    8778, 8795, 8810, 8823, 8834, 8843, 8850, 8855, 10, 0x8000,
    1, 0x8001, 2, 0x8002, 3, 0x8003, 4, 0x8004, 5, 0x8005,
    6, 0x8006, 7, 0x8007, 8, 0x8008, 9, 0x8009, 10, 9,
    0x8001, 2, 0x8002, 3, 0x8003, 4, 0x8004, 5, 0x8005, 6,
    0x8006, 7, 0x8007, 8, 0x8008, 9, 0x8009, 10, 8, 0x8002,
    3, 0x8003, 4, 0x8004, 5, 0x8005, 6, 0x8006, 7, 0x8007,
    8, 0x8008, 9, 0x8009, 10, 7, 0x8003, 4, 0x8004, 5,
    0x8005, 6, 0x8006, 7, 0x8007, 8, 0x8008, 9, 0x8009, 10,
    6, 0x8004, 5, 0x8005, 6, 0x8006, 7, 0x8007, 8, 0x8008,
    9, 0x8009, 10, 5, 0x8005, 6, 0x8006, 7, 0x8007, 8,
    0x8008, 9, 0x8009, 10, 4, 0x8006, 7, 0x8007, 8, 0x8008,
    9, 0x8009, 10, 3, 0x8007, 8, 0x8008, 9, 0x8009, 10,
    2, 0x8008, 9, 0x8009, 10, 1, 0x8009, 10, 8879, 8882,
    8887, 8890, 8927, 8962, 8995, 9026, 9055, 9082, 9107, 9130,
    9151, 9170, 9187, 9202, 9215, 9226, 9235, 9242, 9247, 1,
    0x8000, 1, 2, 0x8001, 2, 0x8002, 3, 1, 0x8002, 3,
    18, 0x8003, 4, 0x8004, 5, 0x8005, 6, 0x8006, 7, 0x8007,
    8, 0x8008, 9, 0x8009, 10, 0x800a, 11, 0x800b, 12, 0x800c,
    13, 0x800d, 14, 0x800e, 15, 0x800f, 16, 0x8010, 17, 0x8011,
    18, 0x8012, 19, 0x8013, 20, 0x8014, 21, 17, 0x8004, 5,
    0x8005, 6, 0x8006, 7, 0x8007, 8, 0x8008, 9, 0x8009, 10,
    0x800a, 11, 0x800b, 12, 0x800c, 13, 0x800d, 14, 0x800e, 15,
    0x800f, 16, 0x8010, 17, 0x8011, 18, 0x8012, 19, 0x8013, 20,
    0x8014, 21, 16, 0x8005, 6, 0x8006, 7, 0x8007, 8, 0x8008,
    9, 0x8009, 10, 0x800a, 11, 0x800b, 12, 0x800c, 13, 0x800d,
    14, 0x800e, 15, 0x800f, 16, 0x8010, 17, 0x8011, 18, 0x8012,
    19, 0x8013, 20, 0x8014, 21, 15, 0x8006, 7, 0x8007, 8,
    0x8008, 9, 0x8009, 10, 0x800a, 11, 0x800b, 12, 0x800c, 13,
    0x800d, 14, 0x800e, 15, 0x800f, 16, 0x8010, 17, 0x8011, 18,
    0x8012, 19, 0x8013, 20, 0x8014, 21, 14, 0x8007, 8, 0x8008,
    9, 0x8009, 10, 0x800a, 11, 0x800b, 12, 0x800c, 13, 0x800d,
    14, 0x800e, 15, 0x800f, 16, 0x8010, 17, 0x8011, 18, 0x8012,
    19, 0x8013, 20, 0x8014, 21, 13, 0x8008, 9, 0x8009, 10,
    0x800a, 11, 0x800b, 12, 0x800c, 13, 0x800d, 14, 0x800e, 15,
    0x800f, 16, 0x8010, 17, 0x8011, 18, 0x8012, 19, 0x8013, 20,
    0x8014, 21, 12, 0x8009, 10, 0x800a, 11, 0x800b, 12, 0x800c,
    13, 0x800d, 14, 0x800e, 15, 0x800f, 16, 0x8010, 17, 0x8011,
    18, 0x8012, 19, 0x8013, 20, 0x8014, 21, 11, 0x800a, 11,
    0x800b, 12, 0x800c, 13, 0x800d, 14, 0x800e, 15, 0x800f, 16,
    0x8010, 17, 0x8011, 18, 0x8012, 19, 0x8013, 20, 0x8014, 21,
    10, 0x800b, 12, 0x800c, 13, 0x800d, 14, 0x800e, 15, 0x800f,
    16, 0x8010, 17, 0x8011, 18, 0x8012, 19, 0x8013, 20, 0x8014,
    21, 9, 0x800c, 13, 0x800d, 14, 0x800e, 15, 0x800f, 16,
    0x8010, 17, 0x8011, 18, 0x8012, 19, 0x8013, 20, 0x8014, 21,
    8, 0x800d, 14, 0x800e, 15, 0x800f, 16, 0x8010, 17, 0x8011,
    18, 0x8012, 19, 0x8013, 20, 0x8014, 21, 7, 0x800e, 15,
    0x800f, 16, 0x8010, 17, 0x8011, 18, 0x8012, 19, 0x8013, 20,
    0x8014, 21, 6, 0x800f, 16, 0x8010, 17, 0x8011, 18, 0x8012,
    19, 0x8013, 20, 0x8014, 21, 5, 0x8010, 17, 0x8011, 18,
    0x8012, 19, 0x8013, 20, 0x8014, 21, 4, 0x8011, 18, 0x8012,
    19, 0x8013, 20, 0x8014, 21, 3, 0x8012, 19, 0x8013, 20,
    0x8014, 21, 2, 0x8013, 20, 0x8014, 21, 1, 0x8014, 21,
    7, 0x000a, 7, 0x8000, 1, 0x8001, 2, 0x8002, 3, 0x8003,
    4, 0x8004, 5, 0x8005, 6, 9274, 9293, 9310, 9325, 9338,
    9349, 9358, 9365, 9370, 9, 0x8000, 1, 0x8001, 2, 0x8002,
    3, 0x8003, 4, 0x8004, 5, 0x8005, 6, 0x8006, 7, 0x8007,
    8, 0x8008, 9, 8, 0x8001, 2, 0x8002, 3, 0x8003, 4,
    0x8004, 5, 0x8005, 6, 0x8006, 7, 0x8007, 8, 0x8008, 9,
    7, 0x8002, 3, 0x8003, 4, 0x8004, 5, 0x8005, 6, 0x8006,
    7, 0x8007, 8, 0x8008, 9, 6, 0x8003, 4, 0x8004, 5,
    0x8005, 6, 0x8006, 7, 0x8007, 8, 0x8008, 9, 5, 0x8004,
    5, 0x8005, 6, 0x8006, 7, 0x8007, 8, 0x8008, 9, 4,
    0x8005, 6, 0x8006, 7, 0x8007, 8, 0x8008, 9, 3, 0x8006,
    7, 0x8007, 8, 0x8008, 9, 2, 0x8007, 8, 0x8008, 9,
    1, 0x8008, 9, 9376, 9383, 9388, 3, 0x8000, 1, 0x8001,
    2, 0x8002, 3, 2, 0x8001, 2, 0x8002, 3, 1, 0x8002,
    3, 9398, 9415, 9428, 9439, 9448, 9455, 9460, 8, 0x8002,
    1, 0x8003, 1, 0x8004, 2, 0x8005, 3, 0x8006, 5, 0x8007,
    6, 0x8008, 4, 0x8009, 7, 6, 0x8004, 2, 0x8005, 3,
    0x8006, 5, 0x8007, 6, 0x8008, 4, 0x8009, 7, 5, 0x8005,
    3, 0x8006, 5, 0x8007, 6, 0x8008, 4, 0x8009, 7, 4,
    0x8006, 5, 0x8007, 6, 0x8008, 4, 0x8009, 7, 3, 0x8006,
    5, 0x8007, 6, 0x8009, 7, 2, 0x8007, 6, 0x8009, 7,
    1, 0x8009, 7, 9465, 9472, 3, 0x8002, 1, 0x8003, 1,
    0x8004, 2, 1, 0x8004, 2, 2, 0x8001, 2, 0x8002, 1,
    9486, 9501, 9514, 9525, 9532, 9537, 7, 0x0002, 5, 0x0004,
    1, 0x0010, 4, 0x8001, 3, 0x8002, 3, 0x8004, 2, 0x8005,
    6, 6, 0x0002, 5, 0x0010, 4, 0x8001, 3, 0x8002, 3,
    0x8004, 2, 0x8005, 6, 5, 0x0002, 5, 0x0010, 4, 0x8001,
    3, 0x8002, 3, 0x8005, 6, 3, 0x0002, 5, 0x0010, 4,
    0x8005, 6, 2, 0x0002, 5, 0x8005, 6, 1, 0x8005, 6,
    3, 0x8000, 1, 0x8001, 2, 0x8003, 3, 9550, 9553, 9560,
    1, 0x0004, 1, 3, 0x8002, 2, 0x8003, 2, 0x8004, 3,
    1, 0x8004, 3, 9571, 9574, 9589, 9602, 9613, 9622, 9629,
    9634, 1, 0x0004, 1, 7, 0x000a, 2, 0x8000, 3, 0x8001,
    4, 0x8002, 5, 0x8003, 6, 0x8004, 7, 0x8005, 8, 6,
    0x8000, 3, 0x8001, 4, 0x8002, 5, 0x8003, 6, 0x8004, 7,
    0x8005, 8, 5, 0x8001, 4, 0x8002, 5, 0x8003, 6, 0x8004,
    7, 0x8005, 8, 4, 0x8002, 5, 0x8003, 6, 0x8004, 7,
    0x8005, 8, 3, 0x8003, 6, 0x8004, 7, 0x8005, 8, 2,
    0x8004, 7, 0x8005, 8, 1, 0x8005, 8, 1, 0x0012, 9644,
    9647, 9650, 9655, 9658, 1, 0x8000, 1, 1, 0x8001, 2,
    2, 0x8002, 3, 0x8003, 4, 1, 0x8003, 4, 1, 0x8004,
    5, 9666, 9669, 9678, 9685, 9690, 1, 0x8001, 1, 4,
    0x0004, 2, 0x0010, 3, 0x8005, 4, 0x8006, 5, 3, 0x0010,
    3, 0x8005, 4, 0x8006, 5, 2, 0x8005, 4, 0x8006, 5,
    1, 0x8006, 5, 4, 0x8000, 1, 0x8001, 2, 0x8004, 3,
    0x8005, 4, 3, 0x8002, 1, 0x8004, 2, 0x8005, 3, 9719,
    9740, 9759, 9776, 9791, 9804, 9815, 9824, 9831, 9836, 10,
    0x0010, 2, 0x8000, 1, 0x8001, 4, 0x8002, 3, 0x8003, 5,
    0x8004, 6, 0x8005, 7, 0x8006, 8, 0x8007, 9, 0x8008, 10,
    9, 0x0010, 2, 0x8001, 4, 0x8002, 3, 0x8003, 5, 0x8004,
    6, 0x8005, 7, 0x8006, 8, 0x8007, 9, 0x8008, 10, 8,
    0x8001, 4, 0x8002, 3, 0x8003, 5, 0x8004, 6, 0x8005, 7,
    0x8006, 8, 0x8007, 9, 0x8008, 10, 7, 0x8001, 4, 0x8003,
    5, 0x8004, 6, 0x8005, 7, 0x8006, 8, 0x8007, 9, 0x8008,
    10, 6, 0x8003, 5, 0x8004, 6, 0x8005, 7, 0x8006, 8,
    0x8007, 9, 0x8008, 10, 5, 0x8004, 6, 0x8005, 7, 0x8006,
    8, 0x8007, 9, 0x8008, 10, 4, 0x8005, 7, 0x8006, 8,
    0x8007, 9, 0x8008, 10, 3, 0x8006, 8, 0x8007, 9, 0x8008,
    10, 2, 0x8007, 9, 0x8008, 10, 1, 0x8008, 10, 9842,
    9845, 9848, 1, 0x0004, 1, 1, 0x0004, 2, 1, 0x0004,
    3, 9856, 9859, 9862, 9865, 9868, 1, 0x0004, 1, 1,
    0x0004, 2, 1, 0x0004, 3, 1, 0x0004, 4, 1, 0x0004,
    5, 1, 0x0001, 9882, 9901, 9918, 9933, 9946, 9957, 9966,
    9973, 9978, 9, 0x0005, 1, 0x8001, 2, 0x8002, 3, 0x8003,
    4, 0x8004, 5, 0x8005, 6, 0x8006, 7, 0x8007, 8, 0x8008,
    9, 8, 0x8001, 2, 0x8002, 3, 0x8003, 4, 0x8004, 5,
    0x8005, 6, 0x8006, 7, 0x8007, 8, 0x8008, 9, 7, 0x8002,
    3, 0x8003, 4, 0x8004, 5, 0x8005, 6, 0x8006, 7, 0x8007,
    8, 0x8008, 9, 6, 0x8003, 4, 0x8004, 5, 0x8005, 6,
    0x8006, 7, 0x8007, 8, 0x8008, 9, 5, 0x8004, 5, 0x8005,
    6, 0x8006, 7, 0x8007, 8, 0x8008, 9, 4, 0x8005, 6,
    0x8006, 7, 0x8007, 8, 0x8008, 9, 3, 0x8006, 7, 0x8007,
    8, 0x8008, 9, 2, 0x8007, 8, 0x8008, 9, 1, 0x8008,
    9, 9983, 9986, 1, 0x0004, 1, 1, 0x0002, 2, 9998,
    10001, 10018, 10033, 10046, 10057, 10066, 10073, 10078, 1, 0x8001,
    1, 8, 0x8002, 2, 0x8003, 3, 0x8004, 4, 0x8005, 5,
    0x8006, 6, 0x8007, 7, 0x8008, 8, 0x8009, 9, 7, 0x8003,
    3, 0x8004, 4, 0x8005, 5, 0x8006, 6, 0x8007, 7, 0x8008,
    8, 0x8009, 9, 6, 0x8004, 4, 0x8005, 5, 0x8006, 6,
    0x8007, 7, 0x8008, 8, 0x8009, 9, 5, 0x8005, 5, 0x8006,
    6, 0x8007, 7, 0x8008, 8, 0x8009, 9, 4, 0x8006, 6,
    0x8007, 7, 0x8008, 8, 0x8009, 9, 3, 0x8007, 7, 0x8008,
    8, 0x8009, 9, 2, 0x8008, 8, 0x8009, 9, 1, 0x8009,
    9, 10089, 10096, 10099, 10112, 10123, 10132, 10139, 10144, 3,
    0x8002, 1, 0x8003, 1, 0x8004, 2, 1, 0x8004, 2, 6,
    0x8005, 3, 0x8006, 5, 0x8007, 6, 0x8008, 4, 0x8009, 7,
    0x800a, 8, 5, 0x8006, 5, 0x8007, 6, 0x8008, 4, 0x8009,
    7, 0x800a, 8, 4, 0x8006, 5, 0x8007, 6, 0x8009, 7,
    0x800a, 8, 3, 0x8007, 6, 0x8009, 7, 0x800a, 8, 2,
    0x8009, 7, 0x800a, 8, 1, 0x800a, 8, 10150, 10153, 10156,
    1, 0x0004, 1, 1, 0x0010, 2, 1, 0x8000, 3, 10162,
    10169, 10172, 3, 0x8002, 1, 0x8003, 1, 0x8004, 2, 1,
    0x8004, 2, 1, 0x0010, 3, 10178, 10181, 10184, 1, 0x0004,
    1, 1, 0x0010, 2, 1, 0x0010, 3, 10192, 10195, 10198,
    10201, 10206, 1, 0x0002, 1, 1, 0x0004, 2, 1, 0x000a,
    3, 2, 0x0010, 4, 0x8000, 5, 1, 0x8000, 5, 10213,
    10222, 10227, 10230, 4, 0x0002, 2, 0x0004, 3, 0x8002, 1,
    0x8003, 1, 2, 0x0002, 2, 0x0004, 3, 1, 0x0004, 3,
    1, 0x0010, 4, 10236, 10239, 10244, 1, 0x0010, 1, 2,
    0x0010, 2, 0x8000, 3, 1, 0x8000, 3, 10252, 10255, 10258,
    10267, 10272, 1, 0x0004, 1, 1, 0x8004, 2, 4, 0x0010,
    4, 0x8001, 3, 0x8002, 3, 0x8005, 5, 2, 0x0010, 4,
    0x8005, 5, 1, 0x8005, 5, 5, 0x8000, 1, 0x8001, 2,
    0x8002, 3, 0x8003, 4, 0x8004, 5, 10289, 10292, 10297, 1,
    0x0003, 1, 2, 0x0003, 2, 0x0010, 3, 1, 0x0010, 3,
    10305, 10308, 10317, 10324, 10329, 1, 0x0004, 1, 4, 0x0003,
    3, 0x0010, 2, 0x8000, 4, 0x8001, 5, 3, 0x0003, 3,
    0x8000, 4, 0x8001, 5, 2, 0x8000, 4, 0x8001, 5, 1,
    0x8001, 5, 10335, 10338, 10341, 1, 0x0010, 1, 1, 0x0004,
    2, 1, 0x8000, 3, 10348, 10351, 10358, 10363, 1, 0x0010,
    1, 3, 0x0010, 2, 0x8000, 3, 0x8001, 4, 2, 0x8000,
    3, 0x8001, 4, 1, 0x8001, 4, 10372, 10375, 10378, 10381,
    10388, 10393, 1, 0x0010, 1, 1, 0x0002, 2, 1, 0x8000,
    3, 3, 0x8001, 4, 0x8002, 5, 0x8003, 6, 2, 0x8002,
    5, 0x8003, 6, 1, 0x8003, 6, 10398, 10401, 1, 0x000a,
    1, 1, 0x8000, 2, 10416, 10441, 10464, 10485, 10504, 10521,
    10536, 10549, 10560, 10569, 10576, 10581, 12, 0x8000, 1, 0x8001,
    2, 0x8002, 3, 0x8003, 5, 0x8004, 4, 0x8005, 6, 0x8006,
    7, 0x8007, 8, 0x8008, 9, 0x8009, 10, 0x800a, 11, 0x800b,
    12, 11, 0x8001, 2, 0x8002, 3, 0x8003, 5, 0x8004, 4,
    0x8005, 6, 0x8006, 7, 0x8007, 8, 0x8008, 9, 0x8009, 10,
    0x800a, 11, 0x800b, 12, 10, 0x8002, 3, 0x8003, 5, 0x8004,
    4, 0x8005, 6, 0x8006, 7, 0x8007, 8, 0x8008, 9, 0x8009,
    10, 0x800a, 11, 0x800b, 12, 9, 0x8003, 5, 0x8004, 4,
    0x8005, 6, 0x8006, 7, 0x8007, 8, 0x8008, 9, 0x8009, 10,
    0x800a, 11, 0x800b, 12, 8, 0x8003, 5, 0x8005, 6, 0x8006,
    7, 0x8007, 8, 0x8008, 9, 0x8009, 10, 0x800a, 11, 0x800b,
    12, 7, 0x8005, 6, 0x8006, 7, 0x8007, 8, 0x8008, 9,
    0x8009, 10, 0x800a, 11, 0x800b, 12, 6, 0x8006, 7, 0x8007,
    8, 0x8008, 9, 0x8009, 10, 0x800a, 11, 0x800b, 12, 5,
    0x8007, 8, 0x8008, 9, 0x8009, 10, 0x800a, 11, 0x800b, 12,
    4, 0x8008, 9, 0x8009, 10, 0x800a, 11, 0x800b, 12, 3,
    0x8009, 10, 0x800a, 11, 0x800b, 12, 2, 0x800a, 11, 0x800b,
    12, 1, 0x800b, 12, 10594, 10597, 10600, 10605, 10608, 10613,
    10616, 10625, 10632, 10637, 1, 0x0002, 1, 1, 0x8010, 2,
    2, 0x8011, 3, 0x8012, 4, 1, 0x8012, 4, 2, 0x8013,
    5, 0x8014, 6, 1, 0x8014, 6, 4, 0x8000, 8, 0x8001,
    9, 0x8002, 10, 0x8015, 7, 3, 0x8000, 8, 0x8001, 9,
    0x8002, 10, 2, 0x8001, 9, 0x8002, 10, 1, 0x8002, 10,
    10643, 10648, 10651, 2, 0x0005, 1, 0x8001, 2, 1, 0x8001,
    2, 1, 0x8002, 3, 10658, 10667, 10674, 10679, 4, 0x0005,
    1, 0x8001, 2, 0x8002, 3, 0x8003, 4, 3, 0x8001, 2,
    0x8002, 3, 0x8003, 4, 2, 0x8002, 3, 0x8003, 4, 1,
    0x8003, 4, 10686, 10689, 10696, 10701, 1, 0x0010, 1, 3,
    0x8000, 2, 0x8001, 3, 0x8002, 4, 2, 0x8001, 3, 0x8002,
    4, 1, 0x8002, 4, 10708, 10711, 10718, 10723, 1, 0x0002,
    1, 3, 0x8000, 2, 0x8001, 3, 0x8002, 4, 2, 0x8001,
    3, 0x8002, 4, 1, 0x8002, 4, 10734, 10737, 10740, 10753,
    10764, 10773, 10780, 10785, 1, 0x0004, 1, 1, 0x0004, 2,
    6, 0x8000, 3, 0x8001, 4, 0x8002, 5, 0x8003, 6, 0x8004,
    7, 0x8005, 8, 5, 0x8001, 4, 0x8002, 5, 0x8003, 6,
    0x8004, 7, 0x8005, 8, 4, 0x8002, 5, 0x8003, 6, 0x8004,
    7, 0x8005, 8, 3, 0x8003, 6, 0x8004, 7, 0x8005, 8,
    2, 0x8004, 7, 0x8005, 8, 1, 0x8005, 8, 10791, 10794,
    10797, 1, 0x0004, 1, 1, 0x0004, 2, 1, 0x8000, 3,
    10813, 10816, 10819, 10824, 10827, 10830, 10847, 10862, 10875, 10886,
    10895, 10902, 10907, 1, 0x8000, 1, 1, 0x8001, 2, 2,
    0x8002, 3, 0x8003, 4, 1, 0x8003, 4, 1, 0x8004, 5,
    8, 0x8005, 6, 0x8006, 7, 0x8007, 8, 0x8008, 9, 0x8009,
    10, 0x800a, 11, 0x800b, 12, 0x800c, 13, 7, 0x8006, 7,
    0x8007, 8, 0x8008, 9, 0x8009, 10, 0x800a, 11, 0x800b, 12,
    0x800c, 13, 6, 0x8007, 8, 0x8008, 9, 0x8009, 10, 0x800a,
    11, 0x800b, 12, 0x800c, 13, 5, 0x8008, 9, 0x8009, 10,
    0x800a, 11, 0x800b, 12, 0x800c, 13, 4, 0x8009, 10, 0x800a,
    11, 0x800b, 12, 0x800c, 13, 3, 0x800a, 11, 0x800b, 12,
    0x800c, 13, 2, 0x800b, 12, 0x800c, 13, 1, 0x800c, 13,
    10914, 10917, 10922, 10925, 1, 0x0002, 1, 2, 0x0005, 2,
    0x8001, 3, 1, 0x8001, 3, 1, 0x8002, 4, 1, 0x801f,
    10936, 10949, 10960, 10969, 10976, 10981, 6, 0x8000, 1, 0x8002,
    2, 0x8003, 3, 0x8004, 4, 0x8005, 6, 0x8006, 5, 5,
    0x8002, 2, 0x8003, 3, 0x8004, 4, 0x8005, 6, 0x8006, 5,
    4, 0x8003, 3, 0x8004, 4, 0x8005, 6, 0x8006, 5, 3,
    0x8004, 4, 0x8005, 6, 0x8006, 5, 2, 0x8005, 6, 0x8006,
    5, 1, 0x8005, 6, 10987, 10990, 10995, 1, 0x0003, 1,
    2, 0x0004, 2, 0x0010, 3, 1, 0x0010, 3, 1, 0x8020,
    1, 0x8021, 2, 0x0005, 1, 0x0010, 2, 11015, 11032, 11047,
    11060, 11071, 11080, 11087, 11092, 8, 0x8000, 1, 0x8001, 2,
    0x8002, 3, 0x8003, 4, 0x8004, 5, 0x8005, 7, 0x8006, 6,
    0x8007, 8, 7, 0x8001, 2, 0x8002, 3, 0x8003, 4, 0x8004,
    5, 0x8005, 7, 0x8006, 6, 0x8007, 8, 6, 0x8002, 3,
    0x8003, 4, 0x8004, 5, 0x8005, 7, 0x8006, 6, 0x8007, 8,
    5, 0x8003, 4, 0x8004, 5, 0x8005, 7, 0x8006, 6, 0x8007,
    8, 4, 0x8004, 5, 0x8005, 7, 0x8006, 6, 0x8007, 8,
    3, 0x8005, 7, 0x8006, 6, 0x8007, 8, 2, 0x8005, 7,
    0x8007, 8, 1, 0x8007, 8, 11102, 11117, 11130, 11141, 11150,
    11157, 11162, 7, 0x8001, 1, 0x8002, 2, 0x8003, 3, 0x8004,
    4, 0x8005, 5, 0x8006, 6, 0x8007, 7, 6, 0x8002, 2,
    0x8003, 3, 0x8004, 4, 0x8005, 5, 0x8006, 6, 0x8007, 7,
    5, 0x8003, 3, 0x8004, 4, 0x8005, 5, 0x8006, 6, 0x8007,
    7, 4, 0x8004, 4, 0x8005, 5, 0x8006, 6, 0x8007, 7,
    3, 0x8005, 5, 0x8006, 6, 0x8007, 7, 2, 0x8006, 6,
    0x8007, 7, 1, 0x8007, 7, 11168, 11171, 11176, 1, 0x0010,
    1, 2, 0x0005, 2, 0x8000, 3, 1, 0x8000, 3, 11184,
    11187, 11196, 11203, 11208, 1, 0x0010, 1, 4, 0x0002, 3,
    0x0005, 4, 0x0010, 5, 0x0012, 2, 3, 0x0002, 3, 0x0005,
    4, 0x0010, 5, 2, 0x0005, 4, 0x0010, 5, 1, 0x0010,
    5, 11214, 11217, 11222, 1, 0x0010, 1, 2, 0x0005, 2,
    0x0010, 3, 1, 0x0010, 3, 11248, 11295, 11340, 11383, 11424,
    11463, 11500, 11535, 11568, 11599, 11628, 11655, 11680, 11703, 11724,
    11743, 11760, 11775, 11788, 11799, 11808, 11815, 11820, 23, 0x8000,
    1, 0x8001, 2, 0x8002, 3, 0x8003, 4, 0x8004, 5, 0x8005,
    6, 0x8006, 7, 0x8007, 8, 0x8008, 9, 0x8009, 10, 0x800a,
    11, 0x800b, 12, 0x800c, 13, 0x800d, 14, 0x800e, 15, 0x800f,
    16, 0x8010, 17, 0x8011, 18, 0x8012, 19, 0x8013, 20, 0x8014,
    21, 0x8015, 22, 0x8016, 23, 22, 0x8001, 2, 0x8002, 3,
    0x8003, 4, 0x8004, 5, 0x8005, 6, 0x8006, 7, 0x8007, 8,
    0x8008, 9, 0x8009, 10, 0x800a, 11, 0x800b, 12, 0x800c, 13,
    0x800d, 14, 0x800e, 15, 0x800f, 16, 0x8010, 17, 0x8011, 18,
    0x8012, 19, 0x8013, 20, 0x8014, 21, 0x8015, 22, 0x8016, 23,
    21, 0x8002, 3, 0x8003, 4, 0x8004, 5, 0x8005, 6, 0x8006,
    7, 0x8007, 8, 0x8008, 9, 0x8009, 10, 0x800a, 11, 0x800b,
    12, 0x800c, 13, 0x800d, 14, 0x800e, 15, 0x800f, 16, 0x8010,
    17, 0x8011, 18, 0x8012, 19, 0x8013, 20, 0x8014, 21, 0x8015,
    22, 0x8016, 23, 20, 0x8003, 4, 0x8004, 5, 0x8005, 6,
    0x8006, 7, 0x8007, 8, 0x8008, 9, 0x8009, 10, 0x800a, 11,
    0x800b, 12, 0x800c, 13, 0x800d, 14, 0x800e, 15, 0x800f, 16,
    0x8010, 17, 0x8011, 18, 0x8012, 19, 0x8013, 20, 0x8014, 21,
    0x8015, 22, 0x8016, 23, 19, 0x8004, 5, 0x8005, 6, 0x8006,
    7, 0x8007, 8, 0x8008, 9, 0x8009, 10, 0x800a, 11, 0x800b,
    12, 0x800c, 13, 0x800d, 14, 0x800e, 15, 0x800f, 16, 0x8010,
    17, 0x8011, 18, 0x8012, 19, 0x8013, 20, 0x8014, 21, 0x8015,
    22, 0x8016, 23, 18, 0x8005, 6, 0x8006, 7, 0x8007, 8,
    0x8008, 9, 0x8009, 10, 0x800a, 11, 0x800b, 12, 0x800c, 13,
    0x800d, 14, 0x800e, 15, 0x800f, 16, 0x8010, 17, 0x8011, 18,
    0x8012, 19, 0x8013, 20, 0x8014, 21, 0x8015, 22, 0x8016, 23,
    17, 0x8006, 7, 0x8007, 8, 0x8008, 9, 0x8009, 10, 0x800a,
    11, 0x800b, 12, 0x800c, 13, 0x800d, 14, 0x800e, 15, 0x800f,
    16, 0x8010, 17, 0x8011, 18, 0x8012, 19, 0x8013, 20, 0x8014,
    21, 0x8015, 22, 0x8016, 23, 16, 0x8007, 8, 0x8008, 9,
    0x8009, 10, 0x800a, 11, 0x800b, 12, 0x800c, 13, 0x800d, 14,
    0x800e, 15, 0x800f, 16, 0x8010, 17, 0x8011, 18, 0x8012, 19,
    0x8013, 20, 0x8014, 21, 0x8015, 22, 0x8016, 23, 15, 0x8008,
    9, 0x8009, 10, 0x800a, 11, 0x800b, 12, 0x800c, 13, 0x800d,
    14, 0x800e, 15, 0x800f, 16, 0x8010, 17, 0x8011, 18, 0x8012,
    19, 0x8013, 20, 0x8014, 21, 0x8015, 22, 0x8016, 23, 14,
    0x8009, 10, 0x800a, 11, 0x800b, 12, 0x800c, 13, 0x800d, 14,
    0x800e, 15, 0x800f, 16, 0x8010, 17, 0x8011, 18, 0x8012, 19,
    0x8013, 20, 0x8014, 21, 0x8015, 22, 0x8016, 23, 13, 0x800a,
    11, 0x800b, 12, 0x800c, 13, 0x800d, 14, 0x800e, 15, 0x800f,
    16, 0x8010, 17, 0x8011, 18, 0x8012, 19, 0x8013, 20, 0x8014,
    21, 0x8015, 22, 0x8016, 23, 12, 0x800b, 12, 0x800c, 13,
    0x800d, 14, 0x800e, 15, 0x800f, 16, 0x8010, 17, 0x8011, 18,
    0x8012, 19, 0x8013, 20, 0x8014, 21, 0x8015, 22, 0x8016, 23,
    11, 0x800c, 13, 0x800d, 14, 0x800e, 15, 0x800f, 16, 0x8010,
    17, 0x8011, 18, 0x8012, 19, 0x8013, 20, 0x8014, 21, 0x8015,
    22, 0x8016, 23, 10, 0x800d, 14, 0x800e, 15, 0x800f, 16,
    0x8010, 17, 0x8011, 18, 0x8012, 19, 0x8013, 20, 0x8014, 21,
    0x8015, 22, 0x8016, 23, 9, 0x800e, 15, 0x800f, 16, 0x8010,
    17, 0x8011, 18, 0x8012, 19, 0x8013, 20, 0x8014, 21, 0x8015,
    22, 0x8016, 23, 8, 0x800f, 16, 0x8010, 17, 0x8011, 18,
    0x8012, 19, 0x8013, 20, 0x8014, 21, 0x8015, 22, 0x8016, 23,
    7, 0x8010, 17, 0x8011, 18, 0x8012, 19, 0x8013, 20, 0x8014,
    21, 0x8015, 22, 0x8016, 23, 6, 0x8011, 18, 0x8012, 19,
    0x8013, 20, 0x8014, 21, 0x8015, 22, 0x8016, 23, 5, 0x8012,
    19, 0x8013, 20, 0x8014, 21, 0x8015, 22, 0x8016, 23, 4,
    0x8013, 20, 0x8014, 21, 0x8015, 22, 0x8016, 23, 3, 0x8014,
    21, 0x8015, 22, 0x8016, 23, 2, 0x8015, 22, 0x8016, 23,
    1, 0x8016, 23, 11826, 11829, 11834, 1, 0x0004, 1, 2,
    0x8000, 2, 0x8001, 3, 1, 0x8001, 3, 11845, 11848, 11863,
    11876, 11887, 11896, 11903, 11908, 1, 0x8000, 1, 7, 0x8001,
    2, 0x8002, 3, 0x8003, 4, 0x8004, 5, 0x8005, 6, 0x8006,
    7, 0x8007, 8, 6, 0x8002, 3, 0x8003, 4, 0x8004, 5,
    0x8005, 6, 0x8006, 7, 0x8007, 8, 5, 0x8003, 4, 0x8004,
    5, 0x8005, 6, 0x8006, 7, 0x8007, 8, 4, 0x8004, 5,
    0x8005, 6, 0x8006, 7, 0x8007, 8, 3, 0x8005, 6, 0x8006,
    7, 0x8007, 8, 2, 0x8006, 7, 0x8007, 8, 1, 0x8007,
    8, 11916, 11919, 11928, 11935, 11940, 1, 0x8000, 1, 4,
    0x8001, 2, 0x8002, 3, 0x8003, 4, 0x8004, 5, 3, 0x8002,
    3, 0x8003, 4, 0x8004, 5, 2, 0x8003, 4, 0x8004, 5,
    1, 0x8004, 5, 11949, 11952, 11955, 11964, 11971, 11976, 1,
    0x8000, 1, 1, 0x8001, 2, 4, 0x8002, 3, 0x8003, 4,
    0x8004, 5, 0x8005, 6, 3, 0x8003, 4, 0x8004, 5, 0x8005,
    6, 2, 0x8004, 5, 0x8005, 6, 1, 0x8005, 6
};

#if !defined(OSS_SPARTAN_AWARE) || ((OSS_SPARTAN_AWARE + 0) <= 5)
typedef struct OSetTableEntry {
    void *a;
    unsigned short b;
    void *c;
    unsigned short d;
} OSetTableEntry;
#endif /* OSS_SPARTAN_AWARE  <= 5 */

static struct OSetTableEntry const _objectsettable[] = {
#if defined(OSS_SPARTAN_AWARE) && ((OSS_SPARTAN_AWARE + 0) > 12)
    {(void *)MAP3_ExtensionSet, 435, NULL, 0, NULL, -1, -1}
#else
    {(void *)MAP3_ExtensionSet, 435, NULL, 0}
#endif /* OSS_SPARTAN_AWARE  > 12 */
};


#ifdef OSS_SPARTAN_AWARE
#if ((OSS_SPARTAN_AWARE + 0) >= 3)
static void _oss_post_init(struct ossGlobal *world) {
    static const unsigned char _oss_typeinfo[] = {
        0x00, 0x85, 0x33, 0xd0, 0xc4, 0x72, 0x55, 0x06, 0x9d, 0x29,
        0x37, 0x1e, 0x9d, 0x14, 0x37, 0x6d, 0x15, 0x5f, 0x20, 0x29,
        0x4f, 0x38, 0xdc, 0xdf, 0xda, 0x8a, 0x89, 0x8a, 0x51, 0x3c,
        0x21, 0xbf, 0xe2, 0x86, 0xd8, 0x34, 0xd1, 0xcc, 0xfc, 0xbe,
        0xd9, 0xa1, 0x1c, 0x4b, 0x2c, 0x28, 0x11, 0x40, 0x97, 0x42,
        0xb6, 0x7e, 0x1a, 0xb2, 0xf4, 0xc5, 0xe5, 0x73, 0x52, 0xf4,
        0x97, 0x9f, 0x7e, 0x80, 0x81, 0xbe, 0x18, 0x15, 0x7a, 0x7b,
        0x70, 0x80, 0x16, 0x8a, 0xdf, 0x57, 0xec, 0x74, 0x51, 0xf2,
        0xbc, 0xd1, 0x95, 0xc8, 0x97, 0x8d, 0x55, 0x32, 0xde, 0x95,
        0xb9, 0x92, 0xb8, 0x19, 0x37, 0x01, 0xb0, 0x05, 0x66, 0xd7,
        0xfe, 0x2c, 0x6a, 0x63, 0x95, 0xf9, 0x17, 0xe6, 0x16, 0xaf,
        0xf1, 0x7c, 0xd3, 0x87, 0xa4, 0xb8, 0xb9, 0x8a, 0xe7, 0x7c,
        0x0b, 0xc3, 0x06, 0x46, 0x72, 0x2d, 0x20, 0xdc, 0xb9, 0xe7,
        0x8a, 0xd8, 0xd9, 0xde, 0x0f
    };
    ossInitRootContext(world, (unsigned char *)_oss_typeinfo);
#ifdef OSS_SPARTAN_AWARE
#if ((OSS_SPARTAN_AWARE + 0) > 12)
    ossSetExtParms(world, (void *)&extParms);
#endif /* OSS_SPARTAN_AWARE  > 12 */
#endif /* OSS_SPARTAN_AWARE */
}
#endif /* OSS_SPARTAN_AWARE >= 3 */
#endif /* OSS_SPARTAN_AWARE */

static const struct eheader _head = {_ossinit_MAP3, -1, 15, 2821, 160, 1649,
    (unsigned short *)_pduarray, (struct etype *)_etypearray,
    (struct efield *)_efieldarray, (void **)_enamearray, (Etag *)_tagarray,
    NULL, NULL, NULL, 0, (void *)_objectsettable, 1};

#ifdef _OSSGETHEADER
void *DLL_ENTRY_FDEF ossGetHeader()
{
    return (void *)&_head;
}
#endif /* _OSSGETHEADER */

void *MAP3 = (void *)&_head;
#ifdef __cplusplus
}	/* extern "C" */
#endif /* __cplusplus */
