#
#
# $Header:INAPCS2 Makefile
#
# $Source: 
# $Revision: 1.1 $
# $Locker:  $
# 

#!/usr/bin/ksh

CXX      =/usr/sfw/bin/gcc
CXXFLAGS = -DNULL=0
OSSCXXFLAGS = -DNULL=0
PATH=$PATH:/usr/sfw/bin:/usr/ccs/bin

INCPATH= -I./inc -I/usr/local/ossasn1/solaris7-64bit/8.4.0/include/

LINK = gcc
LFLAGS = -Wl -ansi -DRELAXED_MODE -shared

TARGET	= libMAP3.so

all: $(TARGET)

OBJECTS = IMAP3.o \
	  OMAP3.o

####### Implicit rules

IMAP3.o:
	$(CXX) -m64 -c -fPIC $(OSSCXXFLAGS) $(INCPATH) -c src/IMAP3.cpp

OMAP3.o:
	$(CXX) -m64 -c -fPIC $(CXXFLAGS) $(INCPATH) -c src/OMAP3.cpp

####### Build rules

libMAP3.so: $(OBJECTS)    
	$(LINK) -m64 $(LFLAGS) -o lib/$@ $(OBJECTS)

clean:
	-rm -f $(OBJECTS) $(MIBOBJECTS) $(TARGET)
	-rm -f *~ core
