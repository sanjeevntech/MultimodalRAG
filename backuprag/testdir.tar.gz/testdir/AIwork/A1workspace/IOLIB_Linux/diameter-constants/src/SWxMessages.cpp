#include <iostream>
#include <its++.h>
#include <its_timers.h>
#include <diameter/Command.h>
#include <diameter/base/BaseAVP.h>
#include <map>
#include <list>
#include <DiameterConstants.h>
#include <diameter/base/ReAuth.h>
#include <diameter/base/AbortSession.h>
#include <diameter/base/SessionTermination.h>
#include <diameter/base/Accounting.h>
#include <diameter/base/CapabilitiesExchange.h>
#include <diameter/base/DeviceWatchdog.h>
#include <diameter/base/DisconnectPeer.h>
#include <diameter/base/BaseGenericCommand.h>
#include <diameter/base/NONPROXYABLEERROR.h>
#include <diameter/base/PROXYABLEERROR.h>
#include <diameter/Exceptions.h>
//#include <Types.h>
#include <diameter/swx_rel_18/SWx_rel_18AVP.h>
#include <diameter/swx_rel_18/SWxMessages.h>
//#include <diameter/cx_rel_10/UserAuthorization.h>
//#include <diameter/cx_rel_10/ServerAssignment.h>
//#include <diameter/cx_rel_10/RegistrationTermination.h>
//#include <diameter/cx_rel_10/PushProfile.h>
//#include <diameter/cx_rel_10/MultimediaAuth.h>
//#include <diameter/cx_rel_10/LocationInfo.h>

using namespace diameter;
using namespace diameter::base;
using namespace diameter::SWx_rel_18;


bool DiameterConstants::printSwxCommands(char p_type, int p_commandCode, const void *p_impl, char *p_charBuffer, int p_maxLength, bool p_outputFlag,int p_appId)
{
   std::ostringstream out;
   const diameter::CommandImpl *impl = (const diameter::CommandImpl *)p_impl;
   try
   {
      if('R' == p_type)
      {
         if(DIAM_COMM_CODE_CX_DX_SAR_SAA == p_commandCode)
         {
            SWx_rel_18::ServerAssignmentRequest aiReq(*impl);
            if(true == p_outputFlag)
               out << aiReq;
         }
         else if(DIAM_COMM_CODE_CX_DX_MAR_MAA == p_commandCode)
         {
            SWx_rel_18::MultiMediaAuthRequest aiReq(*impl);
            if(true == p_outputFlag)
               out << aiReq;
         }
         else if(DIAM_COMM_CODE_CX_DX_RTR_RTA == p_commandCode)
         {
            SWx_rel_18::RegistrationTerminationRequest aiReq(*impl);
            if(true == p_outputFlag)
               out << aiReq;
         }
         else if(DIAM_COMM_CODE_CX_DX_PPR_PPA == p_commandCode)
         {
            SWx_rel_18::PushProfileRequest aiReq(*impl);
            if(true == p_outputFlag)
               out << aiReq;
         }
      }
      else if('A' == p_type)
      {
         if(DIAM_COMM_CODE_CX_DX_SAR_SAA == p_commandCode)
         {
            SWx_rel_18::ServerAssignmentRequest aiReq(*impl);
            if(true == p_outputFlag)
               out << aiReq;
         }
         else if(DIAM_COMM_CODE_CX_DX_MAR_MAA == p_commandCode)
         {
            SWx_rel_18::MutiMediaAuthAnswer aiReq(*impl);
            if(true == p_outputFlag)
               out << aiReq;
         }
         else if(DIAM_COMM_CODE_CX_DX_RTR_RTA == p_commandCode)
         {
            SWx_rel_18::RegistrationTerminationAnswer aiReq(*impl);
            if(true == p_outputFlag)
               out << aiReq;
         }
         else if(DIAM_COMM_CODE_CX_DX_PPR_PPA == p_commandCode)
         {
            SWx_rel_18::PushProfileAnswer aiReq(*impl);
            if(true == p_outputFlag)
               out << aiReq;
         }
      }
      if(true == p_outputFlag)
         snprintf(p_charBuffer, p_maxLength, "%s", (char*)out.str().c_str());
   }
   catch(...)
   {
      return false;
   }
   return true;
}
