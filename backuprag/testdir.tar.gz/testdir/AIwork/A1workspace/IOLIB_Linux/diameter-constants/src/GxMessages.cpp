#include <iostream>
#include <its++.h>
#include <its_timers.h>
#include <diameter/Command.h>
#include <diameter/base/BaseAVP.h>
#include <map>
#include <list>
#include <DiameterConstants.h>
#include <diameter/gx_r10/CC.h>
#include <diameter/gx_r10/RA.h>
//#include <diameter/gx_r10/Gx_r10AVP.h>


using namespace diameter;
using namespace diameter::base;
using namespace diameter::gx_r10;


bool DiameterConstants::printGxCommands(char p_type, int p_commandCode, const void *p_impl, char *p_charBuffer, int p_maxLength, bool p_outputFlag,int p_appId)
{
   std::ostringstream out;
   const diameter::CommandImpl *impl = (const diameter::CommandImpl *)p_impl;
   try
   {
      if('R' == p_type)
      {
         if(DIAM_COMM_CODE_GX_CCR_CCA == p_commandCode)
         {
            CCRequest ccReq(*impl);
            if(true == p_outputFlag)
               out << ccReq;
         }
         else if(DIAM_COMM_CODE_GX_RX_RAR_RAA == p_commandCode)
         {
            RARequest reauthReq(*impl);
            if(true == p_outputFlag)
               out << reauthReq;
         }
      }
      else if('A' == p_type)
      {
         if(DIAM_COMM_CODE_GX_CCR_CCA == p_commandCode)
         {
            CCAnswer ccAns(*impl);
            if(true == p_outputFlag)
               out << ccAns;
         }
         else if(DIAM_COMM_CODE_GX_RX_RAR_RAA == p_commandCode)
         {
            RAAnswer reauthAns(*impl);
            if(true == p_outputFlag)
               out << reauthAns;
         }
      }
      if(true == p_outputFlag)
         snprintf(p_charBuffer, p_maxLength, "%s", (char*)out.str().c_str());
   }
   catch(...)
   {
      return false;
   }
   return true;
}
