#include <iostream>
#include <its++.h>
#include <its_timers.h>
#include <diameter/Command.h>
#include <diameter/base/BaseAVP.h>
#include <map>
#include <list>
#include <DiameterConstants.h>
#include <diameter/base/ReAuth.h>
#include <diameter/base/AbortSession.h>
#include <diameter/base/SessionTermination.h>
#include <diameter/base/Accounting.h>
#include <diameter/base/CapabilitiesExchange.h>
#include <diameter/base/DeviceWatchdog.h>
#include <diameter/base/DisconnectPeer.h>
#include <diameter/base/BaseGenericCommand.h>
#include <diameter/base/NONPROXYABLEERROR.h>
#include <diameter/base/PROXYABLEERROR.h>
#include <diameter/Exceptions.h>
//#include <Types.h>
#include <diameter/s6a_r10/UpdateLocation.h>
#include <diameter/s6a_r10/AuthenticationInformation.h>
#include <diameter/s6a_r10/CancelLocation.h>
#include <diameter/s6a_r10/PurgeUE.h>
#include <diameter/s6a_r10/DeleteSubscriberData.h>
#include <diameter/s6a_r10/InsertSubscriberData.h>
#include <diameter/s6a_r10/Notify.h>
#include <diameter/s6a_r10/Reset.h>
#include <diameter/slh_rel_10/LcsRoutingInfo.h>

using namespace diameter;
using namespace diameter::base;
using namespace diameter::s6a_r10;
using namespace diameter::slh_rel_10;


bool DiameterConstants::printS6aCommands(char p_type, int p_commandCode, const void *p_impl, char *p_charBuffer, int p_maxLength, bool p_outputFlag,int p_appId)
{
   std::ostringstream out;
   const diameter::CommandImpl *impl = (const diameter::CommandImpl *)p_impl;
   try
   {
      if('R' == p_type)
      {
         if(DIAM_COMM_CODE_S6A_S6D_AIR_AIA == p_commandCode)
         {
            AuthenticationInformationRequest aiReq(*impl);
            if(true == p_outputFlag)
               out << aiReq;
         }
         else if(DIAM_COMM_CODE_S6A_S6D_ULR_ULA == p_commandCode)
         {
            UpdateLocationRequest udReq(*impl);
            if(true == p_outputFlag)
               out << udReq;
         }
         else if(DIAM_COMM_CODE_S6A_S6D_CLR_CLA == p_commandCode)
         {
            CancelLocationRequest clReq(*impl);
            if(true == p_outputFlag)
               out << clReq;
         }
         else if(DIAM_COMM_CODE_S6A_S6D_S7A_S7D_IDR_IDA == p_commandCode)
         {
            InsertSubscriberDataRequest udReq(*impl);
            if(true == p_outputFlag)
               out << udReq;
         }
         else if(DIAM_COMM_CODE_S6A_S6D_S7A_S7D_DSR_DSA == p_commandCode)
         {
            DeleteSubscriberDataRequest udReq(*impl);
            if(true == p_outputFlag)
               out << udReq;
         }
         else if(DIAM_COMM_CODE_S6A_S6D_PUR_PUA == p_commandCode)
         {
            PurgeUERequest udReq(*impl);
            if(true == p_outputFlag)
               out << udReq;
         }
         else if(DIAM_COMM_CODE_S6A_S6D_S7A_S7D_RSR_RSA == p_commandCode)
         {
            ResetRequest udReq(*impl);
            if(true == p_outputFlag)
               out << udReq;
         }
         else if(DIAM_COMM_CODE_S6A_S6D_NOR_NOA == p_commandCode)
         {
            NotifyRequest udReq(*impl);
            if(true == p_outputFlag)
               out << udReq;
         }
         else if(DIAM_COMM_CODE_SLH_RIR_RIA == p_commandCode)
         {
            LCSRoutingInfoRequest udReq(*impl);  //SLH
            if(true == p_outputFlag)
               out << udReq;
         }
      }
      else if('A' == p_type)
      {
         if(DIAM_COMM_CODE_S6A_S6D_AIR_AIA == p_commandCode)
         {
            AuthenticationInformationAnswer aiReq(*impl);
            if(true == p_outputFlag)
               out << aiReq;
         }
         else if(DIAM_COMM_CODE_S6A_S6D_ULR_ULA == p_commandCode)
         {
            UpdateLocationAnswer udReq(*impl);
            if(true == p_outputFlag)
               out << udReq;
         }
         else if(DIAM_COMM_CODE_S6A_S6D_CLR_CLA == p_commandCode)
         {
            CancelLocationAnswer clReq(*impl);
            if(true == p_outputFlag)
               out << clReq;
         }
         else if(DIAM_COMM_CODE_S6A_S6D_S7A_S7D_IDR_IDA == p_commandCode)
         {
            InsertSubscriberDataAnswer udReq(*impl);
            if(true == p_outputFlag)
               out << udReq;
         }
         else if(DIAM_COMM_CODE_S6A_S6D_S7A_S7D_DSR_DSA == p_commandCode)
         {
            DeleteSubscriberDataAnswer udReq(*impl);
            if(true == p_outputFlag)
               out << udReq;
         }
         else if(DIAM_COMM_CODE_S6A_S6D_PUR_PUA == p_commandCode)
         {
            PurgeUEAnswer udReq(*impl);
            if(true == p_outputFlag)
               out << udReq;
         }
         else if(DIAM_COMM_CODE_S6A_S6D_S7A_S7D_RSR_RSA == p_commandCode)
         {
            ResetAnswer udReq(*impl);
            if(true == p_outputFlag)
               out << udReq;
         }
         else if(DIAM_COMM_CODE_S6A_S6D_NOR_NOA == p_commandCode)
         {
            NotifyAnswer udReq(*impl);
            if(true == p_outputFlag)
               out << udReq;
         }
         else if(DIAM_COMM_CODE_SLH_RIR_RIA == p_commandCode)
         {
            LCSRoutingInfoAnswer udReq(*impl);  //SLH
            if(true == p_outputFlag)
               out << udReq;
         }
      }
      if(true == p_outputFlag)
         snprintf(p_charBuffer, p_maxLength, "%s", (char*)out.str().c_str());
   }
   catch(...)
   {
      return false;
   }
   return true;
}



