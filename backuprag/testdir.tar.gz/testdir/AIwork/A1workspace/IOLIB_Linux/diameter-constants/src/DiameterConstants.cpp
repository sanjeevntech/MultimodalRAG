/***********************************************************************************************************

Note: 
1. Please use only spaces (never use tabs) in this file, and PLEASE KEEP THE ALREADY SPACING IN THE FILE INTACT
2. If you are using vim to edit this file, do use "se nowrap" for convenience 


 ***********************************************************************************************************/


#include <DiameterConstants.h>
#include <stdio.h>

//Start of Static Data
map<int,string> DiameterConstants::m_commandCodeCharMap;
map<int,string> DiameterConstants::m_resultCodeCharMap;
map<int,string> DiameterConstants::m_experimentalResultCodeCharMap;
map<int,string> DiameterConstants::m_appExperimentalResultCodeCharMapSh;
map<int,string> DiameterConstants::m_appExperimentalResultCodeCharMapCx;
map<int,string> DiameterConstants::m_appExperimentalResultCodeCharMapGx;
map<int,string> DiameterConstants::m_appExperimentalResultCodeCharMapRx;
map<int,string> DiameterConstants::m_appExperimentalResultCodeCharMapSWx;
map<int,string> DiameterConstants::m_appIdCharMap;
//End of Static Data


char *DiameterConstants::getDiameterCommandCodeChar(int p_commandCode)
{
   map<int,string>::iterator l_iter = m_commandCodeCharMap.find(p_commandCode);
   if(l_iter != m_commandCodeCharMap.end())
   {
      return (char*)(m_commandCodeCharMap[p_commandCode].c_str());
   }
   else
   {
      return "DiamCcUnknown";
   }
}

char *DiameterConstants::getDiameterApplicationIdentifierChar(int p_ApplCode)
{
   map<int,string>::iterator l_iter = m_appIdCharMap.find(p_ApplCode);
   if(l_iter != m_appIdCharMap.end())
   {
      return (char*)(l_iter->second.c_str());
   }
   else
   {
      return "DiamAppIdUnknown";
   }
}

char *DiameterConstants::getDiameterResultCodeChar(int p_resultCode,int p_opCode)
{
   map<int,string>::iterator l_iter = m_resultCodeCharMap.find(p_resultCode);
   if(l_iter != m_resultCodeCharMap.end())
   {
      return (char*)(l_iter->second.c_str());
   }
   else
   {
      return "DiamResultCodeUnknown";
   }
}


char *DiameterConstants::getDiameterExperimentalResultCodeChar(int p_resultCode,int p_opCode)
{
   map<int,string>::iterator l_iter_app;

   if(p_opCode >= DIAM_COMM_CODE_S6A_S6D_ULR_ULA)
   { 
      l_iter_app = m_experimentalResultCodeCharMap.find(p_resultCode);
      if(l_iter_app != m_experimentalResultCodeCharMap.end())
      {
         return (char*)(l_iter_app->second.c_str());
      }
      else
      {
         return "DiamExpResultCodeUnknown";
      }
   }
   else if((p_opCode >= DIAM_COMM_CODE_SH_UDR_UDA) && (p_opCode <= DIAM_COMM_CODE_SH_PNR_PNA))
   {
        l_iter_app = m_appExperimentalResultCodeCharMapSh.find(p_resultCode);
        if(l_iter_app != m_appExperimentalResultCodeCharMapSh.end())
        {
          return (char*)(l_iter_app->second.c_str());
        }
   }
   else if((p_opCode >= DIAM_COMM_CODE_CX_DX_UAR_UAA) && (p_opCode <= DIAM_COMM_CODE_CX_DX_PPR_PPA))
   {
        l_iter_app = m_appExperimentalResultCodeCharMapCx.find(p_resultCode);
        if(l_iter_app != m_appExperimentalResultCodeCharMapCx.end())
        {
          return (char*)(l_iter_app->second.c_str());
        }
   }
   else if((p_opCode >= DIAM_COMM_CODE_GX_RX_RAR_RAA) && (p_opCode <= DIAM_COMM_CODE_RX_STR_STA))
   {
        l_iter_app = m_appExperimentalResultCodeCharMapRx.find(p_resultCode);
        if(l_iter_app != m_appExperimentalResultCodeCharMapRx.end())
        {
          return (char*)(l_iter_app->second.c_str());
        }
        l_iter_app = m_appExperimentalResultCodeCharMapGx.find(p_resultCode);
        if(l_iter_app != m_appExperimentalResultCodeCharMapGx.end())
        {
          return (char*)(l_iter_app->second.c_str());
        }
   }
      l_iter_app = m_experimentalResultCodeCharMap.find(p_resultCode);
      if(l_iter_app != m_experimentalResultCodeCharMap.end())
      {
         return (char*)(l_iter_app->second.c_str());
      }
      else
      {
         return "DiamExpResultCodeUnknown";
      }
}


bool DiameterConstants::initialize()
{
   //////////////////////////////////////////////////Application Identifiers Initializationi/////////////////////////////////////////////////////////// 
   /* 16777251 - S6a/S6d application*/               m_appIdCharMap[DIAM_APP_ID_S6A_S6D]                          = "S6a/S6d";
   /* 16777252 - S13/S13' application*/              m_appIdCharMap[DIAM_APP_ID_S13_S13P]                         = "S13/S13P";
   /* 167777308- S7a/S7d application*/               m_appIdCharMap[DIAM_APP_ID_S7A_S7D]                          = "S7a/S7d";
   /* 16777217 - Sh application*/                    m_appIdCharMap[DIAM_APP_ID_SH]                               = "Sh";
   /* 16777236 - Rx application*/                    m_appIdCharMap[DIAM_APP_ID_RX]                               = "Rx";
   /* 16777216 - Cx application */                   m_appIdCharMap[DIAM_APP_ID_CX_DX]                            = "Cx/Dx";
   /* 16777238 - Gx application*/                    m_appIdCharMap[DIAM_APP_ID_GX]                               = "Gx";
   /* 16777265 - Swx application*/                   m_appIdCharMap[DIAM_APP_ID_SWX]                              = "SWx";


   //////////////////////////////////////////////////Command Codes////////////////////////////////////////////////////////////////////////////////////
   /* CX Interface */
   /* 300-User-Authorisation-Request/Answer*/        m_commandCodeCharMap[DIAM_COMM_CODE_CX_DX_UAR_UAA]           = "User-Authorization-Request";
   /* 301-Server-Assignment-Request/Answer*/         m_commandCodeCharMap[DIAM_COMM_CODE_CX_DX_SAR_SAA]           = "Server-Assignment-Request";
   /* 302-Location-Info-Request/Answer*/             m_commandCodeCharMap[DIAM_COMM_CODE_CX_DX_LIR_LIA]           = "Location-Info-Request";
   /* 303-Multimedia-Auth-Request/Answer*/           m_commandCodeCharMap[DIAM_COMM_CODE_CX_DX_MAR_MAA]           = "Multimedia-Auth-Request";
   /* 304-Registration-Termination-Request/Answer*/  m_commandCodeCharMap[DIAM_COMM_CODE_CX_DX_RTR_RTA]           = "Registration-Termination-Request";
   /* 305-Push-Profile-Request/Answer*/              m_commandCodeCharMap[DIAM_COMM_CODE_CX_DX_PPR_PPA]           = "Push-Profile-Request";

   /* RX Interface */
   /* 258 - Re-Auth-Request/Answer*/                 m_commandCodeCharMap[DIAM_COMM_CODE_GX_RX_RAR_RAA]           = "Re-Auth-Request";
   /* 265 - AA-Request/Answer*/                      m_commandCodeCharMap[DIAM_COMM_CODE_RX_AAR_AAA]              = "AA-Request";
   /* 274 - Abort-Termination-Request/Answer*/       m_commandCodeCharMap[DIAM_COMM_CODE_RX_ASR_ASA]              = "Abort-Termination-Request";
   /* 275 - Session-Termination-Request/Answer*/     m_commandCodeCharMap[DIAM_COMM_CODE_RX_STR_STA]              = "Session-Termination-Request";

   /* Sh Interface */
   /* 306-User-Data--Request/Answer*/                m_commandCodeCharMap[DIAM_COMM_CODE_SH_UDR_UDA]              = "User-Data-Request";
   /* 307-Profile-Update-Request/Answer */           m_commandCodeCharMap[DIAM_COMM_CODE_SH_PUR_PUA]              = "Profile-Update-Request"; 
   /* 308-Subscribe-Notifications-Request/Answer*/   m_commandCodeCharMap[DIAM_COMM_CODE_SH_SNR_SNA]              = "Subscribe-Notifications-Request";
   /* 309-Push-Notification-Request/Answer*/         m_commandCodeCharMap[DIAM_COMM_CODE_SH_PNR_PNA]              = "Push-Notification-Request";

   /* 316-Update-Location-Request/Answer*/           m_commandCodeCharMap[DIAM_COMM_CODE_S6A_S6D_ULR_ULA]         = "Update-Location-Request";
   /* 317-Cancel-Location-Request/Answer*/           m_commandCodeCharMap[DIAM_COMM_CODE_S6A_S6D_CLR_CLA]         = "Cancel-Location-Request";
   /* 318-Authentication-Information-Request/Answer*/m_commandCodeCharMap[DIAM_COMM_CODE_S6A_S6D_AIR_AIA]         = "Authentication-Information-Request";
   /* 319-Insert-Subscriber-Data-Request/Answer*/    m_commandCodeCharMap[DIAM_COMM_CODE_S6A_S6D_S7A_S7D_IDR_IDA] = "Insert-Subscriber-Data-Request";
   /* 320-Delete-Subscriber-Data-Request/Answer*/    m_commandCodeCharMap[DIAM_COMM_CODE_S6A_S6D_S7A_S7D_DSR_DSA] = "Delete-Subscriber-Data-Request";
   /* 321-Purge-UE-Request/Answer*/                  m_commandCodeCharMap[DIAM_COMM_CODE_S6A_S6D_PUR_PUA]         = "Purge-UE-Request";
   /* 322-Reset-Request/Answer*/                     m_commandCodeCharMap[DIAM_COMM_CODE_S6A_S6D_S7A_S7D_RSR_RSA] = "Reset-Request";
   /* 323-Notify-Request/Answer*/                    m_commandCodeCharMap[DIAM_COMM_CODE_S6A_S6D_NOR_NOA]         = "Notify-Request";

   /* 324-ME-Identity-Check-Request/Answer*/         m_commandCodeCharMap[DIAM_COMM_CODE_S13_MICR_MICA]           = "ME-Identity-Check-Request";

   /* 8388638-Update-VCSG-Location-Request/Answer*/  m_commandCodeCharMap[DIAM_COMM_CODE_S7A_S7D_UVLR_UVLA]       = "Update-VCSG-Location-Request";
   /* 8388642-Cancel-VCSG-Location-Request/Answer*/  m_commandCodeCharMap[DIAM_COMM_CODE_S7A_S7D_CVLR_CVLA]       = "Cancel-VCSG-Location-Request";

   /*LCS-Routing-Info-Request/LCS-Routing-Info-Ans*/
   /* 8388622 - SLh Command Codes*/                  m_commandCodeCharMap[DIAM_COMM_CODE_SLH_RIR_RIA]             = "SlhRoutingInfo-Request";

   /* GX Interface */
   /* 258 - Re-Auth-Request/Answer*/                 m_commandCodeCharMap[DIAM_COMM_CODE_GX_RX_RAR_RAA]           = "Re-Auth-Request";
   /* 272 - Credit-Control-Request/Answer*/          m_commandCodeCharMap[DIAM_COMM_CODE_GX_CCR_CCA]              = "Credit-Control-Request";

#if 0
   /* SWX Interface */
   /* 301-Server-Assignment-Request/Answer*/         m_commandCodeCharMap[DIAM_COMM_CODE_SWX_SAR_SAA]             = "Server-Assignment-Request-SWx";
   /* 303-Multimedia-Auth-Request/Answer*/           m_commandCodeCharMap[DIAM_COMM_CODE_SWX_MAR_MAA]             = "Multimedia-Auth-Request-SWx";
   /* 304-Registration-Termination-Request/Answer*/  m_commandCodeCharMap[DIAM_COMM_CODE_SWX_RTR_RTA]             = "Registration-Termination-Request-SWx";
   /* 305-Push-Profile-Request/Answer*/              m_commandCodeCharMap[DIAM_COMM_CODE_SWX_PPR_PPA]             = "Push-Profile-Request-SWx";
#endif 



   //////////////////////////////////////////////////Result Codes/////////////////////////////////////////////////////////////////////////////////////
   m_resultCodeCharMap[DIAM_RESULT_CODE_MULTI_ROUND_AUTH]                                                         = "RC:MultiRoundAuth";
   m_resultCodeCharMap[DIAM_RESULT_CODE_INVALID_EVENT]                                                            = "RC:InvalidEvent";
   m_resultCodeCharMap[DIAM_RESULT_CODE_SUCCESS]                                                                  = "RC:Success";  
   m_resultCodeCharMap[DIAM_RESULT_CODE_LIMITED_SUCCESS]                                                          = "RC:LimitedSuccess";  
   m_resultCodeCharMap[DIAM_RESULT_CODE_SUCCESS_MIN_RANGE]                                                        = "RC:SuccessMinRange";   
   m_resultCodeCharMap[DIAM_RESULT_CODE_SUCCESS_MAX_RANGE]                                                        = "RC:SuccessMaxRange";  
   m_resultCodeCharMap[DIAM_RESULT_CODE_PROT_ERR_MIN_RANGE]                                                       = "RC:ProtErrMinRange";  
   m_resultCodeCharMap[DIAM_RESULT_CODE_CMD_UNSUPPORTED]                                                          = "RC:CmdUnsupported";  
   m_resultCodeCharMap[DIAM_RESULT_CODE_UNABLE_TO_DELIVER]                                                        = "RC:UnableToDeliver"; 
   m_resultCodeCharMap[DIAM_RESULT_CODE_REALM_NOT_SERVED]                                                         = "RC:RealmNotServed"; 
   m_resultCodeCharMap[DIAM_RESULT_CODE_TOO_BUSY]                                                                 = "RC:TooBusy"; 
   m_resultCodeCharMap[DIAM_RESULT_CODE_LOOP_DETECTED]                                                            = "RC:LoopDetected"; 
   m_resultCodeCharMap[DIAM_RESULT_CODE_REDIRECT_INDICATION]                                                      = "RC:RedirectIndication"; 
   m_resultCodeCharMap[DIAM_RESULT_CODE_APP_UNSUPPORTED]                                                          = "RC:AppUnsupported"; 
   m_resultCodeCharMap[DIAM_RESULT_CODE_INVALID_HDR_BITS]                                                         = "RC:InvalidHdrBits"; 
   m_resultCodeCharMap[DIAM_RESULT_CODE_INVALID_AVP_BITS]                                                         = "RC:InvalidAvpBits"; 
   m_resultCodeCharMap[DIAM_RESULT_CODE_UNKNOWN_PEER]                                                             = "RC:UnknownPeer"; 
   m_resultCodeCharMap[DIAM_RESULT_CODE_PROT_ERR_MAX_RANGE]                                                       = "RC:ProtErrMaxRange"; 
   m_resultCodeCharMap[DIAM_RESULT_CODE_AUTH_REJECTED]                                                            = "RC:AuthRejected"; 
   m_resultCodeCharMap[DIAM_RESULT_CODE_OUT_OF_SPACE]                                                             = "RC:OutOfSpace"; 
   m_resultCodeCharMap[DIAM_RESULT_CODE_ELECTION_LOST]                                                            = "RC:ElectionLost"; 
   m_resultCodeCharMap[DIAM_RESULT_CODE_AVP_UNSUPPORTED]                                                          = "RC:AvpUnsupported"; 
   m_resultCodeCharMap[DIAM_RESULT_CODE_UNKNOWN_SESSION_ID]                                                       = "RC:UnknownSessionId"; 
   m_resultCodeCharMap[DIAM_RESULT_CODE_AUTHORIZATION_REJECT]                                                     = "RC:AuthorizationReject"; 
   m_resultCodeCharMap[DIAM_RESULT_CODE_INVALID_AVP_VALUE]                                                        = "RC:InvalidAvpValue"; 
   m_resultCodeCharMap[DIAM_RESULT_CODE_MISSING_AVP]                                                              = "RC:MissingAvp"; 
   m_resultCodeCharMap[DIAM_RESULT_CODE_RESOURCES_EXCEEDED]                                                       = "RC:ResourcesExceeded"; 
   m_resultCodeCharMap[DIAM_RESULT_CODE_CONTRADICTING_AVPS]                                                       = "RC:ContradictingAvps"; 
   m_resultCodeCharMap[DIAM_RESULT_CODE_AVP_NOT_ALLOWED]                                                          = "RC:AvpNotAllowed"; 
   m_resultCodeCharMap[DIAM_RESULT_CODE_AVP_MULTI_OCCUR]                                                          = "RC:AvpMultiOccur"; 
   m_resultCodeCharMap[DIAM_RESULT_CODE_NO_COMMON_APP]                                                            = "RC:NoCommonApp"; 
   m_resultCodeCharMap[DIAM_RESULT_CODE_UNSUPPORTED_VERSION]                                                      = "RC:UnsupportedVersion"; 
   m_resultCodeCharMap[DIAM_RESULT_CODE_UNABLE_TO_COMPLY]                                                         = "RC:UnableToComply"; 
   m_resultCodeCharMap[DIAM_RESULT_CODE_INVALID_BIT_IN_HDR]                                                       = "RC:InvalidBitInHdr"; 
   m_resultCodeCharMap[DIAM_RESULT_CODE_INVALID_AVP_LENGTH]                                                       = "RC:InvalidAvpLength"; 
   m_resultCodeCharMap[DIAM_RESULT_CODE_INVALID_MSG_LENGTH]                                                       = "RC:InvalidMsgLength"; 
   m_resultCodeCharMap[DIAM_RESULT_CODE_INVALID_AVP_BIT_COMBO]                                                    = "RC:InvalidAvpBitCombo"; 
   m_resultCodeCharMap[DIAM_RESULT_CODE_NO_COMMON_SECURITY]                                                       = "RC:NoCommonSecurity"; 

   //////////////////////////////////////////////////Experimental Result Codes///////////////////////////////////////////////////////////////////////
   m_experimentalResultCodeCharMap[DIAM_EXP_RESULT_CODE_SUCCESS]                                                  = "ERC:ExpResultSuccess";
   m_experimentalResultCodeCharMap[DIAM_EXP_RESULT_CODE_AUTHENTICATION_DATA_UNAVAILABLE]                          = "ERC:AuthenticationDataUnavailable";
   m_experimentalResultCodeCharMap[DIAM_EXP_RESULT_CODE_ABSENT_USER]                                              = "ERC:AbsentUser";
   m_experimentalResultCodeCharMap[DIAM_EXP_RESULT_CODE_ERROR_USER_UNKNOWN]                                       = "ERC:UserUnknown";
   m_experimentalResultCodeCharMap[DIAM_EXP_RESULT_CODE_ERROR_ROAMING_NOT_ALLOWED]                                = "ERC:RoamingNotAllowed";
   m_experimentalResultCodeCharMap[DIAM_EXP_RESULT_CODE_ERROR_UNKNOWN_EPS_SUBSCRIPTION]                           = "ERC:UnknownEpsSubscription";
   m_experimentalResultCodeCharMap[DIAM_EXP_RESULT_CODE_ERROR_RAT_NOT_ALLOWED]                                    = "ERC:RatNotAllowed";
   m_experimentalResultCodeCharMap[DIAM_EXP_RESULT_CODE_ERROR_EQUIPMENT_UNKNOWN]                                  = "ERC:EquipmentUnknown";
   m_experimentalResultCodeCharMap[DIAM_EXP_RESULT_CODE_ERROR_UNKOWN_SERVING_NODE]                                = "ERC:UnknownServingNode";
   m_experimentalResultCodeCharMap[DIAM_EXP_RESULT_CODE_ERROR_UNAUTHORIZED_REQUESTING_NETWORK]                    = "ERC:UnauthorizedRequestingNetwork";

   //////////////////////////////////////////////////App Experimental Result Codes///////////////////////////////////////////////////////////////////////

   //Sh Interface
   m_appExperimentalResultCodeCharMapSh[DIAM_APP_SH_EXP_RESULT_CODE_USER_DATA_NOT_AVAILABLE]                        = "ERC:UserDataNotAvailable";
   m_appExperimentalResultCodeCharMapSh[DIAM_APP_SH_EXP_RESULT_CODE_ERROR_IDENTITIES_DONT_MATCH]                    = "ERC:IdentitiesDontMatch";
   m_appExperimentalResultCodeCharMapSh[DIAM_APP_SH_EXP_RESULT_CODE_ERROR_TOO_MUCH_DATA]                            = "ERC:TooMuchData";
   m_appExperimentalResultCodeCharMapSh[DIAM_APP_SH_EXP_RESULT_CODE_ERROR_USER_DATA_NOT_RECOGNIZED]                 = "ERC:UserDataNotRecognized";
   m_appExperimentalResultCodeCharMapSh[DIAM_APP_SH_EXP_RESULT_CODE_ERROR_OPERATION_NOT_ALLOWED]                    = "ERC:OperationNotAllowed";
   m_appExperimentalResultCodeCharMapSh[DIAM_APP_SH_EXP_RESULT_CODE_ERROR_USER_DATA_CANNOT_BE_READ]                 = "ERC:UserDataCannotBeRead";
   m_appExperimentalResultCodeCharMapSh[DIAM_APP_SH_EXP_RESULT_CODE_ERROR_USER_DATA_CANNOT_BE_MODIFIED]             = "ERC:UserDataCannotBeModified";
   m_appExperimentalResultCodeCharMapSh[DIAM_APP_SH_EXP_RESULT_CODE_ERROR_USER_DATA_CANNOT_BE_NOTIFIED]             = "ERC:UserDataCannotBeNotified";
   m_appExperimentalResultCodeCharMapSh[DIAM_APP_SH_EXP_RESULT_CODE_ERROR_TRANSPARENT_DATA_OUT_OF_SYNC]             = "ERC:TransparentDataOutOfSync";
   m_appExperimentalResultCodeCharMapSh[DIAM_APP_SH_EXP_RESULT_CODE_ERROR_SUBS_DATA_ABSENT]                         = "ERC:SubsDataAbsent";
   m_appExperimentalResultCodeCharMapSh[DIAM_APP_SH_EXP_RESULT_CODE_ERROR_ERROR_NO_SUBSCRIPTION_TO_DATA]            = "ERC:NoSubscriptionToData";

   //RX Interface
   m_appExperimentalResultCodeCharMapRx[DIAM_APP_RX_EXP_RESULT_CODE_ERROR_REQUESTED_SERVICE_TEMPORARILY_NOT_AUTHORIZED]= "ERC:RequestedServiceTemporarilyNotAuthorized";
   m_appExperimentalResultCodeCharMapRx[DIAM_APP_RX_EXP_RESULT_CODE_ERROR_INVALID_SERVICE_INFORMATION]                 = "ERC:InvalidServiceInformation";
   m_appExperimentalResultCodeCharMapRx[DIAM_APP_RX_EXP_RESULT_CODE_ERROR_FILTER_RESTRICTIONS]                         = "ERC:FilterRestrictions";
   m_appExperimentalResultCodeCharMapRx[DIAM_APP_RX_EXP_RESULT_CODE_ERROR_REQUESTED_SERVICE_NOT_AUTHORIZED]            = "ERC:RequestedServiceNotAuthorized";
   m_appExperimentalResultCodeCharMapRx[DIAM_APP_RX_EXP_RESULT_CODE_ERROR_DUPLICATED_AF_SESSION]                       = "ERC:DuplicationAFSession";
   m_appExperimentalResultCodeCharMapRx[DIAM_APP_RX_EXP_RESULT_CODE_ERROR_IP_CAN_SESSION_NOT_AVAILABLE]                = "ERC:IPCANSessionNotAvailable";
   m_appExperimentalResultCodeCharMapRx[DIAM_APP_RX_EXP_RESULT_CODE_ERROR_UNAUTHORIZED_NON_EMERGENCY_SESSION]          = "ERC:UnauthorizedNonEmergencySession";
   m_appExperimentalResultCodeCharMapRx[DIAM_APP_RX_EXP_RESULT_CODE_ERROR_UNAUTHORIZED_SPONSORED_DATA_CONNECTIVITY]    = "ERC:UnauthorizedSponsoredDataConnectivity";
   m_appExperimentalResultCodeCharMapRx[DIAM_APP_RX_EXP_RESULT_CODE_ERROR_TEMPORARY_NETWORK_FAILURE]                   = "ERC:TemporaryNetworkFailure";
   m_appExperimentalResultCodeCharMapRx[DIAM_APP_RX_EXP_RESULT_CODE_ERROR_UNAUTHORIZED_NON_RLOS_SESSION]               = "ERC:UnauthorizedNonRlosSession";

   /* CX Interface */
   m_appExperimentalResultCodeCharMapCx[DIAM_APP_CX_DX_EXP_RESULT_CODE_FIRST_REGISTRATION]                                   = "ERC:FirstRegistration";
   m_appExperimentalResultCodeCharMapCx[DIAM_APP_CX_DX_EXP_RESULT_CODE_SUBSEQUENT_REGISTRATION]                               = "ERC:SubsequentRegistration";
   m_appExperimentalResultCodeCharMapCx[DIAM_APP_CX_DX_EXP_RESULT_CODE_UNREGISTERED_SERVICE]                                  = "ERC:UnregisterService";
   m_appExperimentalResultCodeCharMapCx[DIAM_APP_CX_DX_EXP_RESULT_CODE_SUCCESS_SERVER_NAME_NOT_STORED]                        = "ERC:SuccessServerNameNotStored";
   m_appExperimentalResultCodeCharMapCx[DIAM_APP_CX_DX_EXP_RESULT_CODE_ERROR_USER_UNKNOWN]                                    = "ERC:UserUnknown";
   m_appExperimentalResultCodeCharMapCx[DIAM_APP_CX_DX_EXP_RESULT_CODE_ERROR_IDENTITIES_DONT_MATCH]                           = "ERC:IdentitiesDontMatch";
   m_appExperimentalResultCodeCharMapCx[DIAM_APP_CX_DX_EXP_RESULT_CODE_ERROR_IDENTITY_NOT_REGISTERED]                         = "ERC:IdentityNotRegistered";
   m_appExperimentalResultCodeCharMapCx[DIAM_APP_CX_DX_EXP_RESULT_CODE_ERROR_ROAMING_NOT_ALLOWED]                             = "ERC:RoamingNotAllowed";
   m_appExperimentalResultCodeCharMapCx[DIAM_APP_CX_DX_EXP_RESULT_CODE_ERROR_IDENTITY_ALREADY_REGISTERED]                     = "ERC:IdentityAlreadyRegistered";
   m_appExperimentalResultCodeCharMapCx[DIAM_APP_CX_DX_EXP_RESULT_CODE_ERROR_AUTH_SCHEME_NOT_SUPPORTED]                       = "ERC:AuthSchemeNotSupported";
   m_appExperimentalResultCodeCharMapCx[DIAM_APP_CX_DX_EXP_RESULT_CODE_ERROR_IN_ASSIGNMENT_TYPE]                              = "ERC:ErrorInAssignmentType";
   m_appExperimentalResultCodeCharMapCx[DIAM_APP_CX_DX_EXP_RESULT_CODE_ERROR_TOO_MUCH_DATA]                                   = "ERC:TooMuchData";
   m_appExperimentalResultCodeCharMapCx[DIAM_APP_CX_DX_EXP_RESULT_CODE_ERROR_NOT_SUPPORTED_USER_DATA]                         = "ERC:NotSupportedUserData";
   m_appExperimentalResultCodeCharMapCx[DIAM_APP_CX_DX_EXP_RESULT_CODE_ERROR_FEATURE_UNSUPPORTED]                             = "ERC:FeatureUnsupported";

   /* GX Interface*/
   m_appExperimentalResultCodeCharMapGx[DIAM_APP_GX_EXP_RESULT_CODE_ERROR_INITIAL_PARAMETERS]                                 = "ERC:InitialParameters";
   m_appExperimentalResultCodeCharMapGx[DIAM_APP_GX_EXP_RESULT_CODE_ERROR_TRIGGER_EVENT]                                      = "ERC:TriggerEvent";
   m_appExperimentalResultCodeCharMapGx[DIAM_APP_GX_EXP_RESULT_CODE_ERROR_PCC_RULE_EVENT]                                     = "ERC:PCCRuleEvent";
   m_appExperimentalResultCodeCharMapGx[DIAM_APP_GX_EXP_RESULT_CODE_ERROR_BEARER_NOT_AUTHORIZED]                              = "ERC:BearerNotAuthorized";
   m_appExperimentalResultCodeCharMapGx[DIAM_APP_GX_EXP_RESULT_CODE_PCC_BEARER_EVENT]                                         = "ERC:PCCBearerEvent";
   m_appExperimentalResultCodeCharMapGx[DIAM_APP_GX_EXP_RESULT_CODE_BEARER_EVENT]                                             = "ERC:BearerEvent";

   /*SWx Interface */
   m_appExperimentalResultCodeCharMapSWx[DIAM_APP_EXP_SWX_RESULT_CODE_ERROR_USER_NO_NON_3GPP_SUBSCRIPTION]                    = "ERC:UserNoNon3GPPSub";
   m_appExperimentalResultCodeCharMapSWx[DIAM_APP_EXP_SWX_RESULT_CODE_ERROR_USER_NO_APN_SUBSCRIPTION]                         = "ERC:UserNoApnSub";
   m_appExperimentalResultCodeCharMapSWx[DIAM_APP_EXP_SWX_RESULT_CODE_ERROR_RAT_TYPE_NOT_ALLOWED]                             = "ERC:RatTypeNotAllowed";
   m_appExperimentalResultCodeCharMapSWx[DIAM_APP_EXP_SWX_RESULT_CODE_ERROR_LATE_OVERLAPPING_REQUEST]                         = "ERC:LateOverlappingReq";
   m_appExperimentalResultCodeCharMapSWx[DIAM_APP_EXP_SWX_RESULT_CODE_ERROR_TIMED_OUT_REQUEST]                                = "ERC:TimedOutReq";
   m_appExperimentalResultCodeCharMapSWx[DIAM_APP_EXP_SWX_RESULT_CODE_ERROR_ILLEGAL_EQUIPMENT]                                = "ERC:IllegalEquipment";

   return true;
}



bool DiameterConstants::isApplIdCommandCodeCombValid(int p_applId, int p_commandCode)
{
   //printf("\nDiameterConstants::isApplIdCommandCodeCombValid AppId:%d, CommCode:%d\n", p_applId, p_commandCode);
   if(DIAM_APP_ID_S6A_S6D == p_applId || DIAM_APP_ID_SLH == p_applId )
   {
      switch(p_commandCode)
      {
         case DIAM_COMM_CODE_S6A_S6D_ULR_ULA:
         case DIAM_COMM_CODE_S6A_S6D_CLR_CLA:
         case DIAM_COMM_CODE_S6A_S6D_AIR_AIA:
         case DIAM_COMM_CODE_S6A_S6D_S7A_S7D_IDR_IDA:
         case DIAM_COMM_CODE_S6A_S6D_S7A_S7D_DSR_DSA:
         case DIAM_COMM_CODE_S6A_S6D_PUR_PUA:
         case DIAM_COMM_CODE_S6A_S6D_S7A_S7D_RSR_RSA:
         case DIAM_COMM_CODE_S6A_S6D_NOR_NOA:
         case DIAM_COMM_CODE_SLH_RIR_RIA:
            //printf("\nDiameterConstants::isApplIdCommandCodeCombValid VALID\n");
            return true;
            break;

         default:
            printf("\nisApplIdCommandCodeCombValid failed. ApplId:%d, CommandCode:%d\n", p_applId, p_commandCode);
            return false;
            break;
      }
   }
   else if(DIAM_APP_ID_SH == p_applId )
   {
      switch(p_commandCode)
      {
         case DIAM_COMM_CODE_SH_UDR_UDA:
         case DIAM_COMM_CODE_SH_PUR_PUA:
         case DIAM_COMM_CODE_SH_SNR_SNA:
         case DIAM_COMM_CODE_SH_PNR_PNA:
            //printf("\nDiameterConstants::isApplIdCommandCodeCombValid VALID\n");
            return true;
            break;

         default:
            printf("\nisApplIdCommandCodeCombValid failed. ApplId:%d, CommandCode:%d\n", p_applId, p_commandCode);
            return false;
            break;
      }
   }
   else if (DIAM_APP_ID_RX == p_applId)    /* RX Interface */
   {
      switch(p_commandCode)
      {
         case DIAM_COMM_CODE_RX_AAR_AAA:
         case DIAM_COMM_CODE_GX_RX_RAR_RAA:
         case DIAM_COMM_CODE_RX_STR_STA:
         case DIAM_COMM_CODE_RX_ASR_ASA:
            //printf("\nDiameterConstants::isApplIdCommandCodeCombValid VALID\n");
            return true;
            break;

         default:
            printf("\nisApplIdCommandCodeCombValid failed. ApplId:%d, CommandCode:%d\n", p_applId, p_commandCode);
            return false;
            break;
      }

   }
   else if (DIAM_APP_ID_CX_DX == p_applId)
   {
      switch(p_commandCode)
      {
         /* CX Interface */
         case DIAM_COMM_CODE_CX_DX_UAR_UAA:
         case DIAM_COMM_CODE_CX_DX_SAR_SAA:
         case DIAM_COMM_CODE_CX_DX_LIR_LIA:
         case DIAM_COMM_CODE_CX_DX_MAR_MAA:
         case DIAM_COMM_CODE_CX_DX_RTR_RTA:
         case DIAM_COMM_CODE_CX_DX_PPR_PPA:
            //printf("\nDiameterConstants::isApplIdCommandCodeCombValid VALID\n");
            return true;
            break;

         default:
            printf("\nisApplIdCommandCodeCombValid failed. ApplId:%d, CommandCode:%d\n", p_applId, p_commandCode);
            return false;
            break;
      }
   }
   else if (DIAM_APP_ID_GX == p_applId)
   {
      switch(p_commandCode)
      {
         /* GX Interface */
         case DIAM_COMM_CODE_GX_RX_RAR_RAA:
         case DIAM_COMM_CODE_GX_CCR_CCA:
            //printf("\nDiameterConstants::isApplIdCommandCodeCombValid VALID\n");
            return true;
            break;

         default:
            printf("\nisApplIdCommandCodeCombValid failed. ApplId:%d, CommandCode:%d\n", p_applId, p_commandCode);
            return false;
            break;
      }
   }
   else if (DIAM_APP_ID_SWX == p_applId)
   {
      switch(p_commandCode)
      {
         /* SWX Interface */
         case DIAM_COMM_CODE_CX_DX_SAR_SAA:
         case DIAM_COMM_CODE_CX_DX_MAR_MAA:
         case DIAM_COMM_CODE_CX_DX_RTR_RTA:
         case DIAM_COMM_CODE_CX_DX_PPR_PPA:
            //printf("\nDiameterConstants::isApplIdCommandCodeCombValid VALID\n");
            return true;
            break;

         default:
            printf("\nisApplIdCommandCodeCombValid failed. ApplId:%d, CommandCode:%d\n", p_applId, p_commandCode);
            return false;
            break;
      }
   }
   printf("\nisApplIdCommandCodeCombValid No ApplicationId is defined. ApplId:%d\n", p_applId);
   return false;
}

bool DiameterConstants::printCommands(char p_type, int p_commandCode, const void *p_impl, char *p_charBuffer, int p_maxLength, bool p_outputFlag,int p_appId)
{
   bool val = false;
   switch(p_commandCode)
   {
      /*S6A Interface */
      case DIAM_COMM_CODE_S6A_S6D_AIR_AIA:
      case DIAM_COMM_CODE_S6A_S6D_ULR_ULA:
      case DIAM_COMM_CODE_S6A_S6D_CLR_CLA:
      case DIAM_COMM_CODE_S6A_S6D_S7A_S7D_IDR_IDA:
      case DIAM_COMM_CODE_S6A_S6D_S7A_S7D_DSR_DSA:
      case DIAM_COMM_CODE_S6A_S6D_PUR_PUA:
      case DIAM_COMM_CODE_S6A_S6D_S7A_S7D_RSR_RSA:
      case DIAM_COMM_CODE_S6A_S6D_NOR_NOA:
      case DIAM_COMM_CODE_SLH_RIR_RIA:
         val = printS6aCommands(p_type, p_commandCode, p_impl, p_charBuffer, p_maxLength, p_outputFlag,p_appId);
         break;
         /*SH Interface*/
      case DIAM_COMM_CODE_SH_UDR_UDA:
      case DIAM_COMM_CODE_SH_PUR_PUA:
      case DIAM_COMM_CODE_SH_SNR_SNA:
      case DIAM_COMM_CODE_SH_PNR_PNA:
         val = printShCommands(p_type, p_commandCode, p_impl, p_charBuffer, p_maxLength, p_outputFlag,p_appId);
         break;
         /*RX Interface */
      case DIAM_COMM_CODE_RX_AAR_AAA:
      case DIAM_COMM_CODE_GX_RX_RAR_RAA:
      case DIAM_COMM_CODE_RX_STR_STA:
      case DIAM_COMM_CODE_RX_ASR_ASA:
         val = printRxCommands(p_type, p_commandCode, p_impl, p_charBuffer, p_maxLength, p_outputFlag,p_appId);
         break;
         /* CX Interface*/
      case DIAM_COMM_CODE_CX_DX_UAR_UAA:
      case DIAM_COMM_CODE_CX_DX_LIR_LIA:
         val = printCxCommands(p_type, p_commandCode, p_impl, p_charBuffer, p_maxLength, p_outputFlag,p_appId);
         break;
         /* GX Interface */
      case DIAM_COMM_CODE_GX_CCR_CCA:
         val = printGxCommands(p_type, p_commandCode, p_impl, p_charBuffer, p_maxLength, p_outputFlag,p_appId);
         break;

         /*SWX Interface */
      case DIAM_COMM_CODE_CX_DX_SAR_SAA:
      case DIAM_COMM_CODE_CX_DX_MAR_MAA:
      case DIAM_COMM_CODE_CX_DX_RTR_RTA:
      case DIAM_COMM_CODE_CX_DX_PPR_PPA:
         {
            //if(DIAM_APP_ID_CX_DX == (((diameter::CommandImpl *)p_impl)->getApplicationId()))
            if(DIAM_APP_ID_CX_DX == p_appId) 
            {

               val = printCxCommands(p_type, p_commandCode, p_impl, p_charBuffer, p_maxLength, p_outputFlag, p_appId);
            }
            else
            {
               val = printSwxCommands(p_type, p_commandCode, p_impl, p_charBuffer, p_maxLength, p_outputFlag, p_appId);
            }
         }
         break;

      default:
         printf("\nprintCommands(): command code not found. CommandCode:%d\n", p_commandCode);
         break;
   }
   return val;
}
