#include <iostream>
#include <its++.h>
#include <its_timers.h>
#include <diameter/Command.h>
#include <diameter/base/BaseAVP.h>
#include <map>
#include <list>
#include <DiameterConstants.h>
/*
#include <diameter/base/ReAuth.h>
#include <diameter/base/AbortSession.h>
#include <diameter/base/SessionTermination.h>
#include <diameter/base/Accounting.h>
#include <diameter/base/CapabilitiesExchange.h>
#include <diameter/base/DeviceWatchdog.h>
#include <diameter/base/DisconnectPeer.h>
#include <diameter/base/BaseGenericCommand.h>
#include <diameter/base/NONPROXYABLEERROR.h>
#include <diameter/base/PROXYABLEERROR.h>
#include <diameter/Exceptions.h>
#include <Types.h> */

#include <diameter/sh_r16/UserData.h>

using namespace diameter;
using namespace diameter::base;
using namespace diameter::sh_r16;


bool DiameterConstants::printShCommands(char p_type, int p_commandCode, const void *p_impl, char *p_charBuffer, int p_maxLength, bool p_outputFlag,int p_appId)
{
   std::ostringstream out;
   const diameter::CommandImpl *impl = (const diameter::CommandImpl *)p_impl;
   try
   {
      if('R' == p_type)
      {
         if(DIAM_COMM_CODE_SH_UDR_UDA == p_commandCode)
         {
            UserDataRequest UDRReq(*impl);
            if(true == p_outputFlag)
               out << UDRReq;
         }
      }
      else if('A' == p_type)
      {
         if(DIAM_COMM_CODE_SH_UDR_UDA == p_commandCode)
         {
            UserDataAnswer UDAReq(*impl);
            if(true == p_outputFlag)
               out << UDAReq;
         }
      }
      if('R' == p_type)
      {
         if(DIAM_COMM_CODE_SH_SNR_SNA == p_commandCode)
         {
            SubscribeNotificationsRequest SNRReq(*impl);
            if(true == p_outputFlag)
               out << SNRReq;
         }
      }
      else if('A' == p_type)
      {
         if(DIAM_COMM_CODE_SH_SNR_SNA == p_commandCode)
         {
            SubscribeNotificationsAnswer SNAReq(*impl);
            if(true == p_outputFlag)
               out << SNAReq;
         }
      }
      if('R' == p_type)
      {
         if(DIAM_COMM_CODE_SH_PNR_PNA == p_commandCode)
         {
            PushNotificationRequest PNRReq(*impl);
            if(true == p_outputFlag)
               out << PNRReq;
         }
      }
      else if('A' == p_type)
      {
         if(DIAM_COMM_CODE_SH_PNR_PNA == p_commandCode)
         {
            PushNotificationsAnswer PNAReq(*impl);
            if(true == p_outputFlag)
               out << PNAReq;
         }
      }
      if('R' == p_type)
      {
         if(DIAM_COMM_CODE_SH_PUR_PUA == p_commandCode)
         {
            ProfileUpdateRequest PURReq(*impl);
            if(true == p_outputFlag)
               out << PURReq;
         }
      }
      else if('A' == p_type)
      {
         if(DIAM_COMM_CODE_SH_PUR_PUA == p_commandCode)
         {
            ProfileUpdateAnswer PUARes(*impl);
            if(true == p_outputFlag)
               out << PUARes;
         }
      }
      if(true == p_outputFlag)
         snprintf(p_charBuffer, p_maxLength, "%s", (char*)out.str().c_str());
   }
   catch(...)
   {
      return false;
   }
   return true;
}
