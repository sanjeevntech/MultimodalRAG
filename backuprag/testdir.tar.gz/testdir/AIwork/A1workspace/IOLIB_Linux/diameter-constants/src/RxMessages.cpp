#include <iostream>
#include <its++.h>
#include <its_timers.h>
#include <diameter/Command.h>
#include <diameter/base/BaseAVP.h>
#include <map>
#include <list>
#include <DiameterConstants.h>
#include <diameter/rx_r16/Rx_Interface.h>

using namespace diameter;
using namespace diameter::base;
using namespace diameter::rx_r8;


bool DiameterConstants::printRxCommands(char p_type, int p_commandCode, const void *p_impl, char *p_charBuffer, int p_maxLength, bool p_outputFlag,int p_appId)
{
   std::ostringstream out;
   const diameter::CommandImpl *impl = (const diameter::CommandImpl *)p_impl;
   try
   {
      if('R' == p_type)
      {
         if(DIAM_COMM_CODE_RX_AAR_AAA == p_commandCode)
         {
            AARequest aaReq(*impl);
            if(true == p_outputFlag)
               out << aaReq;
         }
         else if(DIAM_COMM_CODE_GX_RX_RAR_RAA == p_commandCode)
         {
            ReAuthRequest reauthReq(*impl);
            if(true == p_outputFlag)
               out << reauthReq;
         }
         else if(DIAM_COMM_CODE_RX_STR_STA == p_commandCode)
         {
            SessionTerminationRequests sessionterminationReq(*impl);
            if(true == p_outputFlag)
               out <<  sessionterminationReq;
         }
         else if(DIAM_COMM_CODE_RX_ASR_ASA == p_commandCode)
         {
            AbortSessionRequest abortsessionReq(*impl);
            if(true == p_outputFlag)
               out << abortsessionReq;
         }
      }
      else if('A' == p_type)
      {
         if(DIAM_COMM_CODE_RX_AAR_AAA == p_commandCode)
         {
            AAAnswer aaReq(*impl);
            if(true == p_outputFlag)
               out << aaReq;
         }
         else if(DIAM_COMM_CODE_GX_RX_RAR_RAA == p_commandCode)
         {
            ReAuthAnswer reauthReq(*impl);
            if(true == p_outputFlag)
               out << reauthReq;
         }
         else if(DIAM_COMM_CODE_RX_STR_STA == p_commandCode)
         {
            SessionTerminationAnswer  sessionterminationReq(*impl);
            if(true == p_outputFlag)
               out <<  sessionterminationReq;
         }
         else if(DIAM_COMM_CODE_RX_ASR_ASA == p_commandCode)
         {
            AbortSessionAnswer abortsessionReq(*impl);
            if(true == p_outputFlag)
               out << abortsessionReq;
         }
      }
      if(true == p_outputFlag)
         snprintf(p_charBuffer, p_maxLength, "%s", (char*)out.str().c_str());
   }
   catch(...)
   {
      return false;
   }
   return true;
}



