#ifndef __DIAMETER_CONSTANTS_H
#define __DIAMETER_CONSTANTS_H

#include <map>
#include <string>
using namespace std;


enum EDiameterApplicationIdentifier
{
   DIAM_APP_ID_UNKNOWN      = 0,
   DIAM_APP_ID_S6A_S6D      = 16777251,
   DIAM_APP_ID_S13_S13P     = 16777252,
   DIAM_APP_ID_S7A_S7D      = 167777308,
   DIAM_APP_ID_SLH          = 16777291,
   DIAM_APP_ID_SH           = 16777217,
   DIAM_APP_ID_RX           = 16777236,
   DIAM_APP_ID_CX_DX        = 16777216,
   DIAM_APP_ID_GX           = 16777238, 
   DIAM_APP_ID_SWX          = 16777265 

};


enum EDiameterCommandCode
{
   /* 0   */            DIAM_COMM_CODE_UNKNOWN = 0,

   //Rx and Gx Command Code
   /* 258 */            DIAM_COMM_CODE_GX_RX_RAR_RAA = 258,             /*Re-Auth-Request/Re-Auth-Answer*/
   /* 265 */            DIAM_COMM_CODE_RX_AAR_AAA = 265,                /*AA-Request/AA-Answer*/
   /* 272 */            DIAM_COMM_CODE_GX_CCR_CCA = 272,                /*Credit-Control-Request/Credit-Control-Answer*/
   /* 274 */            DIAM_COMM_CODE_RX_ASR_ASA = 274,                /*Abort-Session-Request/Abort-Session-Answer*/
   /* 275 */            DIAM_COMM_CODE_RX_STR_STA = 275,                /*Session-Termination-Request/Session-Termination-Answer*/

   /** Cx Command Codes */
   /* 300 */            DIAM_COMM_CODE_CX_DX_UAR_UAA = 300,             /*User-Authorization-Request/User-Authorization-Answer*/
   /* 301 */            DIAM_COMM_CODE_CX_DX_SAR_SAA,                   /*Server-Assignment-Request/Server-Assignment-Answer*/
   /* 302 */            DIAM_COMM_CODE_CX_DX_LIR_LIA,                   /*Location-Info-Request/Location-Info-Answer*/
   /* 303 */            DIAM_COMM_CODE_CX_DX_MAR_MAA,                   /*Multimedia-Auth-Request/Multimedia-Auth-Answer*/
   /* 304 */            DIAM_COMM_CODE_CX_DX_RTR_RTA,                   /*Registration-Termination-Request/Registration-Termination-Answer*/
   /* 305 */            DIAM_COMM_CODE_CX_DX_PPR_PPA,                   /*Push-Profile-Request/Push-Profile-Answer*/

   /* Sh Interface command code values */
   /*306 */            DIAM_COMM_CODE_SH_UDR_UDA = 306,                /*User-Data-Request/User-Data-Answer */
   /*307 */            DIAM_COMM_CODE_SH_PUR_PUA = 307,                 /*Profile-Update-Request/Profile-Update-Answe */
   /*308 */            DIAM_COMM_CODE_SH_SNR_SNA = 308,                /*Subscribe-Notifications-Request/Subscribe-Notifications-Answer */
   /*309 */            DIAM_COMM_CODE_SH_PNR_PNA = 309,                /*Push-Notification-Request/Push-Notification-Answer */

   // S6A/S6D Command Codes
   /* 316 */            DIAM_COMM_CODE_S6A_S6D_ULR_ULA = 316,           /*Update-Location-Request/Update-Location-Answer*/
   /* 317 */            DIAM_COMM_CODE_S6A_S6D_CLR_CLA,                 /*Cancel-Location-Request/Cancel-Location-Answer*/
   /* 318 */            DIAM_COMM_CODE_S6A_S6D_AIR_AIA,                 /*Authentication-Information-Request/Authentication-Information-Answer*/
   /* 319 */            DIAM_COMM_CODE_S6A_S6D_S7A_S7D_IDR_IDA,         /*Insert-Subscriber-Data-Request/Insert-Subscriber-Data-Answer*/
   /* 320 */            DIAM_COMM_CODE_S6A_S6D_S7A_S7D_DSR_DSA,         /*Delete-Subscriber-Data-Request/Delete-Subscriber-Data-Answer*/
   /* 321 */            DIAM_COMM_CODE_S6A_S6D_PUR_PUA,                 /*Purge-UE-Request/Purge-UE-Answer*/
   /* 322 */            DIAM_COMM_CODE_S6A_S6D_S7A_S7D_RSR_RSA,         /*Reset-Request/Reset-Answer*/
   /* 323 */            DIAM_COMM_CODE_S6A_S6D_NOR_NOA,                 /*Notify-Request/Notify-Answer*/

   // S13/S13P Command Codes
   /* 324 */            DIAM_COMM_CODE_S13_MICR_MICA = 324,             /*ME-Identity-Check-Request/ME-Identity-Check-Answer*/
   
#if 0
   //SWX Command Codes
   /* 301 */            DIAM_COMM_CODE_SWX_SAR_SAA = 391,                   /*Server-Assignment-Request/Server-Assignment-Answer*/
   /* 303 */            DIAM_COMM_CODE_SWX_MAR_MAA = 393,                   /*Multimedia-Auth-Request/Multimedia-Auth-Answer*/
   /* 304 */            DIAM_COMM_CODE_SWX_RTR_RTA = 394,                   /*Registration-Termination-Request/Registration-Termination-Answer*/
   /* 305 */            DIAM_COMM_CODE_SWX_PPR_PPA = 395,                   /*Push-Profile-Request/Push-Profile-Answer*/
#endif

   // SLh Command Codes
   /* 8388622 */        DIAM_COMM_CODE_SLH_RIR_RIA = 8388622,           /*LCS-Routing-Info-Request/LCS-Routing-Info-Ans*/

   // S7A/S7D Command Codes
   /* 8388638 */        DIAM_COMM_CODE_S7A_S7D_UVLR_UVLA = 8388638,     /*Update-VCSG-Location-Request/Update-VCSG-Location-Answer*/
   /* 8388642 */        DIAM_COMM_CODE_S7A_S7D_CVLR_CVLA = 8388642      /*Cancel-VCSG-Location-Request/Cancel-VCSG-Location-Answer*/

};


enum EDiameterResultCode
{
   DIAM_RESULT_CODE_UNKNOWN                 = 0,

   //Informational Errors
   DIAM_RESULT_CODE_MULTI_ROUND_AUTH        = 1001,
   DIAM_RESULT_CODE_INVALID_EVENT           = 1100,

   //Success
   DIAM_RESULT_CODE_SUCCESS                 = 2001,
   DIAM_RESULT_CODE_LIMITED_SUCCESS         = 2002,
   DIAM_RESULT_CODE_SUCCESS_MIN_RANGE       = 2000,
   DIAM_RESULT_CODE_SUCCESS_MAX_RANGE       = 2999,

   //Protocol Errors
   DIAM_RESULT_CODE_PROT_ERR_MIN_RANGE      = 3000,
   DIAM_RESULT_CODE_CMD_UNSUPPORTED         = 3001,
   DIAM_RESULT_CODE_UNABLE_TO_DELIVER       = 3002,
   DIAM_RESULT_CODE_REALM_NOT_SERVED        = 3003,
   DIAM_RESULT_CODE_TOO_BUSY                = 3004,
   DIAM_RESULT_CODE_LOOP_DETECTED           = 3005,
   DIAM_RESULT_CODE_REDIRECT_INDICATION     = 3006,
   DIAM_RESULT_CODE_APP_UNSUPPORTED         = 3007,
   DIAM_RESULT_CODE_INVALID_HDR_BITS        = 3008,
   DIAM_RESULT_CODE_INVALID_AVP_BITS        = 3009,
   DIAM_RESULT_CODE_UNKNOWN_PEER            = 3010,
   DIAM_RESULT_CODE_PROT_ERR_MAX_RANGE      = 3999,

   //Transient Failures
   DIAM_RESULT_CODE_AUTH_REJECTED           = 4001,
   DIAM_RESULT_CODE_OUT_OF_SPACE            = 4002,
   DIAM_RESULT_CODE_ELECTION_LOST           = 4003,

   //Permanent Failures
   DIAM_RESULT_CODE_AVP_UNSUPPORTED         = 5001,
   DIAM_RESULT_CODE_UNKNOWN_SESSION_ID      = 5002,
   DIAM_RESULT_CODE_AUTHORIZATION_REJECT    = 5003,
   DIAM_RESULT_CODE_INVALID_AVP_VALUE       = 5004,
   DIAM_RESULT_CODE_MISSING_AVP             = 5005,
   DIAM_RESULT_CODE_RESOURCES_EXCEEDED      = 5006,
   DIAM_RESULT_CODE_CONTRADICTING_AVPS      = 5007,
   DIAM_RESULT_CODE_AVP_NOT_ALLOWED         = 5008,
   DIAM_RESULT_CODE_AVP_MULTI_OCCUR         = 5009,
   DIAM_RESULT_CODE_NO_COMMON_APP           = 5010,
   DIAM_RESULT_CODE_UNSUPPORTED_VERSION     = 5011,
   DIAM_RESULT_CODE_UNABLE_TO_COMPLY        = 5012,
   DIAM_RESULT_CODE_INVALID_BIT_IN_HDR      = 5013,
   DIAM_RESULT_CODE_INVALID_AVP_LENGTH      = 5014,
   DIAM_RESULT_CODE_INVALID_MSG_LENGTH      = 5015,
   DIAM_RESULT_CODE_INVALID_AVP_BIT_COMBO   = 5016,
   DIAM_RESULT_CODE_NO_COMMON_SECURITY      = 5017
};


enum EDiameterExperimentalResultCode
{
   DIAM_EXP_RESULT_CODE_UNKNOWN                               = 0,
   //General

   DIAM_EXP_RESULT_CODE_SUCCESS                               = 2001,

   //Transient Failures
   DIAM_EXP_RESULT_CODE_AUTHENTICATION_DATA_UNAVAILABLE       = 4181,
   DIAM_EXP_RESULT_CODE_ABSENT_USER                           = 4201,   //SLh interface

   //Permanent Failures
   DIAM_EXP_RESULT_CODE_ERROR_USER_UNKNOWN                    = 5001,
   DIAM_EXP_RESULT_CODE_AUTHORIZATION_REJECTED                = 5003,
   DIAM_EXP_RESULT_CODE_ERROR_ROAMING_NOT_ALLOWED             = 5004,
   DIAM_EXP_RESULT_CODE_ERROR_UNKNOWN_EPS_SUBSCRIPTION        = 5420,
   DIAM_EXP_RESULT_CODE_ERROR_RAT_NOT_ALLOWED                 = 5421,
   DIAM_EXP_RESULT_CODE_ERROR_EQUIPMENT_UNKNOWN               = 5422,
   DIAM_EXP_RESULT_CODE_ERROR_UNKOWN_SERVING_NODE             = 5423,
   DIAM_EXP_RESULT_CODE_ERROR_UNAUTHORIZED_REQUESTING_NETWORK = 5490   //SLh interface

};

enum EDiameterAppExperimentalResultCode
{

   DIAM_CX_DX_EXP_RESULT_CODE_UNKNOWN                                             = 0,

   /* SH Interface - Refer 3gpp 29.329 & 29.328 for all sh related things */
   DIAM_APP_SH_EXP_RESULT_CODE_USER_DATA_NOT_AVAILABLE                            = 4100, 
   DIAM_APP_SH_EXP_RESULT_CODE_ERROR_IDENTITIES_DONT_MATCH                        = 5002, /* This error code used by both SH and CX */
   DIAM_APP_SH_EXP_RESULT_CODE_ERROR_TOO_MUCH_DATA                                = 5008, //Added in 62000  for PUR 
   DIAM_APP_SH_EXP_RESULT_CODE_ERROR_USER_DATA_NOT_RECOGNIZED                     = 5100, //Added in 62000  for PUR
   DIAM_APP_SH_EXP_RESULT_CODE_ERROR_OPERATION_NOT_ALLOWED                        = 5101, 
   DIAM_APP_SH_EXP_RESULT_CODE_ERROR_USER_DATA_CANNOT_BE_READ                     = 5102, 
   DIAM_APP_SH_EXP_RESULT_CODE_ERROR_USER_DATA_CANNOT_BE_MODIFIED                 = 5103, //Added in 62000  for PUR
   DIAM_APP_SH_EXP_RESULT_CODE_ERROR_USER_DATA_CANNOT_BE_NOTIFIED                 = 5104, //Added in 6100R2 for SNR
   DIAM_APP_SH_EXP_RESULT_CODE_ERROR_TRANSPARENT_DATA_OUT_OF_SYNC                 = 5105, //Added in 62000  for PUR 
   DIAM_APP_SH_EXP_RESULT_CODE_ERROR_SUBS_DATA_ABSENT                             = 5106, //Added in 6100R2 for SNR
   DIAM_APP_SH_EXP_RESULT_CODE_ERROR_ERROR_NO_SUBSCRIPTION_TO_DATA               = 5107, //Added in 6100R2 for SNR


   //RxInterface
   DIAM_APP_RX_EXP_RESULT_CODE_ERROR_REQUESTED_SERVICE_TEMPORARILY_NOT_AUTHORIZED = 4261,
   DIAM_APP_RX_EXP_RESULT_CODE_ERROR_INVALID_SERVICE_INFORMATION                  = 5061,
   DIAM_APP_RX_EXP_RESULT_CODE_ERROR_FILTER_RESTRICTIONS                          = 5062,
   DIAM_APP_RX_EXP_RESULT_CODE_ERROR_REQUESTED_SERVICE_NOT_AUTHORIZED             = 5063,
   DIAM_APP_RX_EXP_RESULT_CODE_ERROR_DUPLICATED_AF_SESSION                        = 5064,
   DIAM_APP_RX_EXP_RESULT_CODE_ERROR_IP_CAN_SESSION_NOT_AVAILABLE                 = 5065,
   DIAM_APP_RX_EXP_RESULT_CODE_ERROR_UNAUTHORIZED_NON_EMERGENCY_SESSION           = 5066,
   DIAM_APP_RX_EXP_RESULT_CODE_ERROR_UNAUTHORIZED_SPONSORED_DATA_CONNECTIVITY     = 5067,
   DIAM_APP_RX_EXP_RESULT_CODE_ERROR_TEMPORARY_NETWORK_FAILURE                    = 5068,
   DIAM_APP_RX_EXP_RESULT_CODE_ERROR_UNAUTHORIZED_NON_RLOS_SESSION                = 5069,

   /** Cx Interface Success Codes */
   DIAM_APP_CX_DX_EXP_RESULT_CODE_FIRST_REGISTRATION                              = 2001,
   DIAM_APP_CX_DX_EXP_RESULT_CODE_SUBSEQUENT_REGISTRATION                         = 2002,
   DIAM_APP_CX_DX_EXP_RESULT_CODE_UNREGISTERED_SERVICE                            = 2003,
   DIAM_APP_CX_DX_EXP_RESULT_CODE_SUCCESS_SERVER_NAME_NOT_STORED                  = 2004,

   //Cx Interface Permanent Failures
   DIAM_APP_CX_DX_EXP_RESULT_CODE_ERROR_USER_UNKNOWN                              = 5001, /* This error code used by both SH and CX */
   DIAM_APP_CX_DX_EXP_RESULT_CODE_ERROR_IDENTITIES_DONT_MATCH                     = 5002,
   DIAM_APP_CX_DX_EXP_RESULT_CODE_ERROR_IDENTITY_NOT_REGISTERED                   = 5003,
   DIAM_APP_CX_DX_EXP_RESULT_CODE_ERROR_ROAMING_NOT_ALLOWED                       = 5004,
   DIAM_APP_CX_DX_EXP_RESULT_CODE_ERROR_IDENTITY_ALREADY_REGISTERED               = 5005,
   DIAM_APP_CX_DX_EXP_RESULT_CODE_ERROR_AUTH_SCHEME_NOT_SUPPORTED                 = 5006,
   DIAM_APP_CX_DX_EXP_RESULT_CODE_ERROR_IN_ASSIGNMENT_TYPE                        = 5007,
   DIAM_APP_CX_DX_EXP_RESULT_CODE_ERROR_TOO_MUCH_DATA                             = 5008,
   DIAM_APP_CX_DX_EXP_RESULT_CODE_ERROR_NOT_SUPPORTED_USER_DATA                   = 5009,
   DIAM_APP_CX_DX_EXP_RESULT_CODE_ERROR_FEATURE_UNSUPPORTED                       = 5011,

   //Gx Interace Permanent Failures
   DIAM_APP_GX_EXP_RESULT_CODE_ERROR_INITIAL_PARAMETERS                           = 5140,
   DIAM_APP_GX_EXP_RESULT_CODE_ERROR_TRIGGER_EVENT                                = 5141,
   DIAM_APP_GX_EXP_RESULT_CODE_ERROR_PCC_RULE_EVENT                               = 5142,
   DIAM_APP_GX_EXP_RESULT_CODE_ERROR_BEARER_NOT_AUTHORIZED                        = 5143,
   //Gx Transient Failures 
   DIAM_APP_GX_EXP_RESULT_CODE_PCC_BEARER_EVENT                                   = 4141,
   DIAM_APP_GX_EXP_RESULT_CODE_BEARER_EVENT                                       = 4142,
   //SWx Transient Failures
   DIAM_APP_EXP_SWX_RESULT_CODE_ERROR_USER_NO_NON_3GPP_SUBSCRIPTION               = 5450,
   DIAM_APP_EXP_SWX_RESULT_CODE_ERROR_USER_NO_APN_SUBSCRIPTION                    = 5451,
   DIAM_APP_EXP_SWX_RESULT_CODE_ERROR_RAT_TYPE_NOT_ALLOWED                        = 5452,
   DIAM_APP_EXP_SWX_RESULT_CODE_ERROR_LATE_OVERLAPPING_REQUEST                    = 5453,
   DIAM_APP_EXP_SWX_RESULT_CODE_ERROR_TIMED_OUT_REQUEST                           = 5454,
   DIAM_APP_EXP_SWX_RESULT_CODE_ERROR_ILLEGAL_EQUIPMENT                           = 5554

};

class DiameterConstants
{
   public:
      DiameterConstants(){}
      static map<int,string> m_commandCodeCharMap;
      static map<int,string> m_resultCodeCharMap;
      static map<int,string> m_experimentalResultCodeCharMap;
      static map<int,string> m_appExperimentalResultCodeCharMapSh;
      static map<int,string> m_appExperimentalResultCodeCharMapCx;
      static map<int,string> m_appExperimentalResultCodeCharMapGx;
      static map<int,string> m_appExperimentalResultCodeCharMapRx;
      static map<int,string> m_appExperimentalResultCodeCharMapSWx;
      static map<int,string> m_appIdCharMap;

   public:
      static bool initialize();

      static char *getDiameterApplicationIdentifierChar(int p_appId);
      static char *getDiameterCommandCodeChar(int p_commandCode);
      static char *getDiameterResultCodeChar(int p_resultCode, int p_opCode=0);
      static char *getDiameterExperimentalResultCodeChar(int p_resultCode, int p_opCode=0);
      static bool isApplIdCommandCodeCombValid(int p_applId, int p_commandCode);
      static bool printCommands(char p_type, int p_commandCode, const void *impl, char *p_charBuffer, int p_maxLength, bool p_outputFlag, int p_appId);

      /* Interface specific printcommand function */
      static bool printS6aCommands(char p_type, int p_commandCode, const void *impl, char *p_charBuffer, int p_maxLength, bool p_outputFlag, int p_appId);
      static bool printShCommands(char p_type, int p_commandCode, const void *impl, char *p_charBuffer, int p_maxLength, bool p_outputFlag, int p_appId);
      static bool printRxCommands(char p_type, int p_commandCode, const void *impl, char *p_charBuffer, int p_maxLength, bool p_outputFlag, int p_appId);
      static bool printCxCommands(char p_type, int p_commandCode, const void *impl, char *p_charBuffer, int p_maxLength, bool p_outputFlag, int p_appId);
      static bool printGxCommands(char p_type, int p_commandCode, const void *impl, char *p_charBuffer, int p_maxLength, bool p_outputFlag, int p_appId);
      static bool printSwxCommands(char p_type, int p_commandCode, const void *impl, char *p_charBuffer, int p_maxLength, bool p_outputFlag, int p_appId);

};


#endif
