#DIAMETER_STACK_HOME=$ITS_DIAMETER_HOME
#ITS_DIAMETER_HOME=$DIAMETER_STACK_HOME/inc/
#ITS_S6A_HOME=../../../dependent_application_repos/diastack_devel/diastack_SunOS_sparc/inc/
ITS_S6A_HOME=$ITS_DIAMETER_HOME/inc/
ITS_SH_HOME=$ITS_DIAMETER_HOME/inc/
ITS_RX_HOME=$ITS_DIAMETER_HOME/inc/
ITS_CX_HOME=$ITS_DIAMETER_HOME/inc/
#ITS_CX_HOME=$ITS_DIAMETER_HOME/diameter/cx_rel_16/
ITS_GX_HOME=/opt/product/prav2774/GIT/NGF_BASE/ngf_src/diameter-constants/src
ITS_SWX_HOME=$ITS_DIAMETER_HOME/inc/
GCC_BIN=/usr/bin/gcc


echo $ITS_DIAMETER_HOME
echo "Compiling DiameterConstants..."
#$GCC_BIN -c ../src/DiameterConstants.cpp -fPIC -I../inc/ -D_REENTRANT -DC7_Q -g -m64 -w -DUNIX_PORT -m64 -D_REENTRANT -DC7_Q -Wall -g  -DMULTITHREAD -DAAA -Wno-deprecated
$GCC_BIN -m64  -g -m64 -DUNIX_PORT -DMULTITHREAD -D_REENTRANT -DSS_64BIT_SERVER -DBIT64 -DMACHINE64 -DSLMXMX_ENABLE -DSLTS_ENABLE -D_SVID_GETTOD -D_REENTRANT -DPLATFORM=solaris64 -Dsolaris64 -DUSE_HEAP -DHAVE_NAMESPACES -DHAVE_STD_NAMESPACE -DHAVE_THROW_SPECS -D_MIT_POSIX_THREADS -DHAVE_STL  -DDEBUG -I$ITS_DIAMETER_HOME/val/c++/include  -I$ITS_DIAMETER_HOME/AcceleroCore/common/include  -I$ITS_DIAMETER_HOME/include  -I$ITS_DIAMETER_HOME/AcceleroCore/include  -I$ITS_DIAMETER_HOME/api/c++/include  -I$ITS_DIAMETER_HOME/api/include   -I$ITS_DIAMETER_HOME/common/include  -I$ITS_DIAMETER_HOME/dframe/include  -I$ITS_DIAMETER_HOME/vendors/IntelliNet/include  -I$ITS_S6A_HOME/api/include/diameter/s6a_r10//  -I$ITS_S6A_HOME/api/include  -I/74bkp/rgopal/work/HSS_GCC_2.0.0.0//map-ng/application/inc/ -I..//inc/ -I/74bkp/rgopal/work/HSS_GCC_2.0.0.0//IOLIB/MAP1//inc/ -I/74bkp/rgopal/work/HSS_GCC_2.0.0.0//IOLIB/MAP2//inc/ -I/74bkp/rgopal/work/HSS_GCC_2.0.0.0//IOLIB/MAP3//inc/ -I/usr/local/ossasn1/solaris7-64bit/8.3.1//include/  -I/ora10gclnt/product/10.2.0/client//precomp/public/ -I/74bkp/rgopal/work/HSS_GCC_2.0.0.0//IOLIB/map-constants//inc/ -I/usr/sfw/include/openssl/ -I/export/home/sachi/work/CodeBase/GENERIC_UTIL_1.1.0.0/gen-util//inc/  -I/opt/product/sanjeev/HSS_2.0.0.0/subs_profiles_2.0.0.0//application/inc/  -I/74bkp/rgopal/work/HSS_GCC_2.0.0.0//IOLIB/diameter-constants//inc/  -I/usr/sfw/include/ -fPIC -c ../src/DiameterConstants.cpp -fpermissive

echo "Compiling S6AMessages..."
echo $ITS_S6A_HOME
$GCC_BIN -m64 -g -m64 -DUNIX_PORT -DMULTITHREAD -D_REENTRANT -DSS_64BIT_SERVER -DBIT64 -DMACHINE64 -DSLMXMX_ENABLE -DSLTS_ENABLE -D_SVID_GETTOD -D_REENTRANT -DPLATFORM=solaris64 -Dsolaris64 -DUSE_HEAP -DHAVE_NAMESPACES -DHAVE_STD_NAMESPACE -DHAVE_THROW_SPECS -D_MIT_POSIX_THREADS -DHAVE_STL  -DDEBUG -I$ITS_DIAMETER_HOME/inc/ -I..//inc/  -I/usr/sfw/include/ -fPIC -c ../src/S6aMessages.cpp -fpermissive


echo "Compiling SHMessages..."
echo $ITS_SH_HOME
$GCC_BIN -m64 -g -m64 -DUNIX_PORT -DMULTITHREAD -D_REENTRANT -DSS_64BIT_SERVER -DBIT64 -DMACHINE64 -DSLMXMX_ENABLE -DSLTS_ENABLE -D_SVID_GETTOD -D_REENTRANT -DPLATFORM=solaris64 -Dsolaris64 -DUSE_HEAP -DHAVE_NAMESPACES -DHAVE_STD_NAMESPACE -DHAVE_THROW_SPECS -D_MIT_POSIX_THREADS -DHAVE_STL  -DDEBUG -I$ITS_DIAMETER_HOME/inc/ -I..//inc/  -I/usr/sfw/include/ -fPIC -c ../src/ShMessages.cpp -fpermissive

echo "Compiling RXMessages..."
echo $ITS_RX_HOME
$GCC_BIN -m64 -g -m64 -DUNIX_PORT -DMULTITHREAD -D_REENTRANT -DSS_64BIT_SERVER -DBIT64 -DMACHINE64 -DSLMXMX_ENABLE -DSLTS_ENABLE -D_SVID_GETTOD -D_REENTRANT -DPLATFORM=solaris64 -Dsolaris64 -DUSE_HEAP -DHAVE_NAMESPACES -DHAVE_STD_NAMESPACE -DHAVE_THROW_SPECS -D_MIT_POSIX_THREADS -DHAVE_STL  -DDEBUG -I$ITS_DIAMETER_HOME/inc/ -I..//inc/  -I/usr/sfw/include/ -fPIC -c ../src/RxMessages.cpp -fpermissive

echo "Compiling CXMessages..."
echo $ITS_CX_HOME
$GCC_BIN -m64 -g -m64 -DUNIX_PORT -DMULTITHREAD -D_REENTRANT -DSS_64BIT_SERVER -DBIT64 -DMACHINE64 -DSLMXMX_ENABLE -DSLTS_ENABLE -D_SVID_GETTOD -D_REENTRANT -DPLATFORM=solaris64 -Dsolaris64 -DUSE_HEAP -DHAVE_NAMESPACES -DHAVE_STD_NAMESPACE -DHAVE_THROW_SPECS -D_MIT_POSIX_THREADS -DHAVE_STL  -DDEBUG -I$ITS_DIAMETER_HOME/inc/ -I..//inc/  -I/usr/sfw/include/ -fPIC -c ../src/CxMessages.cpp -fpermissive

echo "Compiling GXMessages..."
echo $ITS_GX_HOME
$GCC_BIN -m64 -g -m64 -DUNIX_PORT -DMULTITHREAD -D_REENTRANT -DSS_64BIT_SERVER -DBIT64 -DMACHINE64 -DSLMXMX_ENABLE -DSLTS_ENABLE -D_SVID_GETTOD -D_REENTRANT -DPLATFORM=solaris64 -Dsolaris64 -DUSE_HEAP -DHAVE_NAMESPACES -DHAVE_STD_NAMESPACE -DHAVE_THROW_SPECS -D_MIT_POSIX_THREADS -DHAVE_STL  -DDEBUG -I$ITS_DIAMETER_HOME/inc/ -I..//inc/  -I/usr/sfw/include/ -fPIC -c ../src/GxMessages.cpp -fpermissive

echo "Compiling SWXMessages..."
echo $ITS_SWX_HOME
$GCC_BIN -m64 -g -m64 -DUNIX_PORT -DMULTITHREAD -D_REENTRANT -DSS_64BIT_SERVER -DBIT64 -DMACHINE64 -DSLMXMX_ENABLE -DSLTS_ENABLE -D_SVID_GETTOD -D_REENTRANT -DPLATFORM=solaris64 -Dsolaris64 -DUSE_HEAP -DHAVE_NAMESPACES -DHAVE_STD_NAMESPACE -DHAVE_THROW_SPECS -D_MIT_POSIX_THREADS -DHAVE_STL  -DDEBUG -I$ITS_DIAMETER_HOME/inc/ -I..//inc/  -I/usr/sfw/include/ -fPIC -c ../src/SWxMessages.cpp -fpermissive

echo "Generating libdiameter-constants.so..."
#$GCC_BIN -m64 -o libdiameter-constants.so -shared  DiameterConstants.o S6aMessages.o  -g 
$GCC_BIN -m64 -o libdiameter-constants.so -shared  DiameterConstants.o S6aMessages.o ShMessages.o RxMessages.o CxMessages.o GxMessages.o SWxMessages.o -g 

mv libdiameter-constants.so ../lib/
