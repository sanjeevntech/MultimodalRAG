/**************************************************************************

MODULE
        c7sum.h - Interface definitions for "sum" TCAP demo (ITU-T)

REVISION
        $Revision:/main/6 $

DATE
        $Date:24-Dec-2002 12:49:55 $

SYSTEM
        Signalware

SUBSYSTEM
        TCAP

PROCESS
	TCAP Sum example applications

AUTHORS
	This module is provided by Ulticom, Inc.

RESTRICTIONS

        These functions are designed to execute under the Foundation
        Toolkit parent process (POP).  It assumes the facilities of the
        Ft Library for its operation.

NOTICES
       			Ulticom, Inc.
		    Copyright 1996-2001
		    All Rights Reserved.

        These computer program listings and specifications, herein, are
        the property of Ulticom, Inc.  and shall not be reproduced or
	copied or used in whole or in part as the basis for manufacture
	or sale of items without written permission.

DISCLAIMER
 
SOURCE CODE EXAMPLES PROVIDED BY ULTICOM ARE ONLY INTENDED TO ASSIST IN THE DEVELOPMENT OF A
WORKING SOFTWARE PROGRAM.  THE SOURCE CODE PROVIDED IS NOT WRITTEN AS AN EXAMPLE OF A RELEASED,
PRODUCTION LEVEL APPLICATION, IT IS INTENDED ONLY TO DEMONSTRATE USAGE OF THE API FUNCTIONS USED
HEREIN.
 
ULTICOM, INC. PROVIDES THE SOURCE CODE EXAMPLES, BOTH INDIVIDUALLY AND AS ONE OR MORE GROUPS, "AS
IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE ENTIRE RISK AS TO
THE QUALITY AND PERFORMANCE OF THE SOURCE CODE EXAMPLES, BOTH INDIVIDUALLY AND AS ONE OR MORE
GROUPS, IS WITH YOU. SHOULD ANY PART OF THE SOURCE CODE EXAMPLES PROVE DEFECTIVE, YOU (AND NOT
ULTICOM) ASSUME THE ENTIRE COST OF ALL NECESSARY SERVICING, REPAIR OR CORRECTION. IN NO EVENT SHALL
ULTICOM BE LIABLE FOR DAMAGES OF ANY KIND, INCLUDING DIRECT, INDIRECT, INCIDENTAL, CONSEQUENTIAL,
SPECIAL, EXEMPLARY OR PUNITIVE, EVEN IF IT HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
ULTICOM DOES NOT WARRANT THAT THE CONTENTS OF THE SOURCE CODE EXAMPLES, WHETHER  INDIVIDUALLY OR AS
ONE OR MORE GROUPS, WILL MEET YOUR REQUIREMENTS OR THAT THE SOURCE CODE EXAMPLES ARE ERROR FREE.
 
Ulticom shall have sole and exclusive ownership of all right, title, and interest in and to the
Software, and all intellectual property rights associated therewith, including without limitation,
rights to copyrights, trade secrets or know-how. This disclaimer agreement shall be governed and
construed in accordance with the laws of the State of New Jersey.
 
Ulticom may make improvements and/or changes in source code examples at any time without notice.
Ulticom has no continuing obligation to provide additional source code examples or revisions of
previously provided examples.
 
Changes may be made periodically to the information in the source code examples; these changes may
be reported, for the sample code included herein, in new editions of the product.

MEND
**************************************************************************/

/*EJECT */

#define OC_NUMBER_TO_ADD 1      /* opcodes for the application */
#define OC_SUM 2
#define SUM_DATA_TAG 4          /* universal OCTETSTRING */
//PKS #define SUM_DATA_SIZE 10
#define SUM_DATA_SIZE 256

/* user data for invoke component containing "number to add" */
typedef struct
{
    U8 opcode_tag;              /* always CP_OC_LOCAL           */
    U8 opcode_len;              /* always 1                     */
    U8 opcode_val;              /* always OC_NUMBER_TO_ADD      */
    U8 parm_tag;                /* always SUM_DATA_TAG          */
    U8 parm_len;                /* length of data in parm_val[] */
    S32 PKS;
    U8 parm_val[SUM_DATA_SIZE]; /* data to add, all-numeric ASCII string */
}
sum_invoke_component_t;

/* user data for return-result component containing "sum" */
typedef struct
{
    U8 seq_tag;                 /* always CP_SEQ                    */
    U8 seq_len;                 /* length of data in parm_val[] + 5 */
    U8 opcode_tag;              /* always CP_OC_LOCAL               */
    U8 opcode_len;              /* always 1                         */
    U8 opcode_val;              /* always OC_SUM                    */
    U8 parm_tag;                /* always SUM_DATA_TAG              */
    U8 parm_len;                /* length of data in parm_val[]     */
    S32 PKS;
    U8 parm_val[SUM_DATA_SIZE]; /* sum so far, all-numeric ASCII string */
}
sum_return_result_component_t;

/* called and calling addresses in BEGIN dialog handling primitive,
   according to CCITT Q.713 sec 3.4.  This form assumes address contains
   point code and subsystem number but not global title. */

typedef struct
{
    U8 len;                     /* set to ADDR_IND_PC_AND_SSN_LEN */
#define ADDR_IND_PC_AND_SSN_LEN 4

    U8 addr_indication;         /* set to ADDR_IND_ROUTING_IND +
                                   ADDR_IND_SSN + ADDR_IND_PC */
#define ADDR_IND_ROUTING_IND 0x40
#define ADDR_IND_SSN 2
#define ADDR_IND_PC 1

    U8 pc_lo;                   /* point code, lo 8 bits */
    U8 pc_hi;                   /* point code, hi 8 bits */
    U8 ssn;                     /* subsystem number */
}
addr_pc_and_ssn_t;
