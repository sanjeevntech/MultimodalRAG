static char *RCS = "\0@(#)$RCSfile:c7sumClient.c $ $Revision:/main/sw9/13 $ $Date:28-Mar-2007 13:59:43 $";
static char *Copyright = "\0@(#)Copyright (c) 2002 Ulticom, Inc.";
/**************************************************************************

MODULE
        c7sumClient.c - client program for "sum" TCAP application (ITU-T)

REVISION
        $Revision:/main/sw9/13 $

DATE
        $Date:28-Mar-2007 13:59:43 $

SYSTEM
        Signalware

SUBSYSTEM
        TCAP

PROCESS
	TCAP Sum example applications

AUTHORS
	This module is provided by Ulticom, Inc.

RESTRICTIONS

        These functions are designed to execute under the Foundation
        Toolkit parent process (POP).  It assumes the facilities of the
        Ft Library for its operation.

NOTICES
       			Ulticom, Inc.
		    Copyright 1996-2002
		    All Rights Reserved.

        These computer program listings and specifications, herein, are
        the property of Ulticom, Inc.  and shall not be reproduced or
	copied or used in whole or in part as the basis for manufacture
	or sale of items without written permission.

DISCLAIMER

SOURCE CODE EXAMPLES PROVIDED BY ULTICOM ARE ONLY INTENDED TO ASSIST IN THE
DEVELOPMENT OF A WORKING SOFTWARE PROGRAM.  THE SOURCE CODE PROVIDED IS NOT
WRITTEN AS AN EXAMPLE OF A RELEASED, PRODUCTION LEVEL APPLICATION, IT IS
INTENDED ONLY TO DEMONSTRATE USAGE OF THE API FUNCTIONS USED HEREIN.

ULTICOM, INC. PROVIDES THE SOURCE CODE EXAMPLES, BOTH INDIVIDUALLY AND AS ONE
OR MORE GROUPS, "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR
IMPLIED, INCLUDING, BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE ENTIRE RISK AS TO
THE QUALITY AND PERFORMANCE OF THE SOURCE CODE EXAMPLES, BOTH INDIVIDUALLY AND
AS ONE OR MORE GROUPS, IS WITH YOU. SHOULD ANY PART OF THE SOURCE CODE
EXAMPLES PROVE DEFECTIVE, YOU (AND NOT ULTICOM) ASSUME THE ENTIRE COST OF ALL
NECESSARY SERVICING, REPAIR OR CORRECTION. IN NO EVENT SHALL ULTICOM BE LIABLE
FOR DAMAGES OF ANY KIND, INCLUDING DIRECT, INDIRECT, INCIDENTAL, CONSEQUENTIAL,
SPECIAL, EXEMPLARY OR PUNITIVE, EVEN IF IT HAS BEEN ADVISED OF THE POSSIBILITY
OF SUCH DAMAGE.  ULTICOM DOES NOT WARRANT THAT THE CONTENTS OF THE SOURCE CODE
EXAMPLES, WHETHER  INDIVIDUALLY OR AS ONE OR MORE GROUPS, WILL MEET YOUR
REQUIREMENTS OR THAT THE SOURCE CODE EXAMPLES ARE ERROR FREE.

Ulticom shall have sole and exclusive ownership of all right, title, and
interest in and to the Software, and all intellectual property rights
associated therewith, including without limitation, rights to copyrights,
trade secrets or know-how. This disclaimer agreement shall be governed and
construed in accordance with the laws of the State of New Jersey.

Ulticom may make improvements and/or changes in source code examples at any
time without notice.  Ulticom has no continuing obligation to provide
additional source code examples or revisions of previously provided examples.

Changes may be made periodically to the information in the source code
examples; these changes may be reported, for the sample code included herein,
in new editions of the product.

MEND
**************************************************************************/

/*EJECT */

#include <apiinc.h>
#include <tcap.h>
#include <tcerror.h>
#include <c7sum.h>

#include <MAP2.h>
#include <MAP2Code.h>

#define CLIENT_QOS CL_SVC_CLASS_1
#define CLIENT_INVOKE_TIMER  3
#define CLIENT_IPC_RETRY 5
#define TCAP_ALRM_INT 1         /* interval for SIGALRM signals */

#define MY_NAME (pSHM->cpt[OwnClientTableEntry].ClientLogicalName)
#define clientExit(x) FtTerminate(NOrestart, (x))

#define STATE_IDLE              1
#define STATE_BEGIN_SENT        2
#define STATE_CONTINUE_RECD     3
#define STATE_RESULT_RECD       4
#define STATE_CONTINUE_SENT     5
#define STATE_MIN STATE_IDLE
#define STATE_MAX STATE_CONTINUE_SENT

/* event codes are values of TC_xxx from ctcap.h, plus... */
#define EVENT_NEW_NUMBER (TC_CHA_PC_MAX + 1)
#define EVENT_END_DIALOG (TC_CHA_PC_MAX + 2)
#define EVENT_U_ABORT    (TC_CHA_PC_MAX + 3)
#define PROTOCOL_VERSION_1 1

/* function prototypes */
int getIPCevent (ctblock_t **);
int getTblockEvent (ctblock_t **);
int getKeyboardEvent (char **);
int stateErr (int, char *, ctblock_t *);
int stateIdle (int, char *, ctblock_t *);
int stateBeginSent (int, char *, ctblock_t *);
int stateContinueRecd (int, char *, ctblock_t *);
int stateResultRecd (int, char *, ctblock_t *);
int stateContinueSent (int, char *, ctblock_t *);
void sigalrmHandler (void);
void sigintHandler (void);
int sendDHP (U8, U16, U16, S16, U8);
void formatAddresses (ctblock_t *);
int sendInvoke (U16, U16, S16, char *);
void clientHandleIPC (Header_t *);
void controlOnly (void);


/* global data */
BOOL tickTimerCalled;
BOOL terminate = FALSE;			/* time to terminate? */
BOOL finished_initialization = FALSE;	/* Are we in the main loop yet? */

U32 remotePC = 0xffffffff;
U8 remoteSSN = 0;
int localPC;
U8 localSSN = 0;
char nodeName[MAXnodeNAME + 1];

U16 applicationID;
U16 dialogID;
S16 invokeID;

#define DP_MAX_BUFF_SIZE 2048
static BOOL dpHi = FALSE; /* Use High Level API for Dialogue */
                          /* Portion Encoding */
static BOOL dpLo = FALSE; /* Use Low level API for Dialogue */
                          /* Portion Encoding */
static BOOL validateDP = TRUE; /* By default library will parse and   */
                               /* decode dialogue portion in incoming */
                               /* message. This option can be reversed */
                               /* through command line                 */ 
static BOOL ac_mode_set = FALSE; /* application context name in dialogue portion */

/* table of state handlers, indexed by state */
int (*handleEvent[]) (int, char *, ctblock_t *) =
{
    NULL, stateIdle, stateBeginSent, stateContinueRecd,
        stateResultRecd, stateContinueSent
};

/* FUNCTION main() - main function of c7sumClient program */
/**************************************************************************

FUNCTION
        int main(int argc, char *argv[])

DESCRIPTION
        Main function of c7sumClient program of "sum" TCAP demo application.

INPUTS
        Args:   argc, argv, as in C standard.

        Others: messages via IPC, signals.


OUTPUTS
        Return: none

        Args:   none

        Others: messages via IPC.

FEND
**************************************************************************/
int
main (int argc, char *argv[])
{
    int i, result;

    char myLogicalName[MAXlogicalNAME + 1];
    int nodeIndex;
    SYSlogicalNodeAttributes_t *pattr;

    int distOpt;                /* value of distributionOption
                                   for TCAP bind */

    extern U16 tcap_dbg_mask;
    BOOL savDebugIndicator;	/* save value from -debug */

    /* state-event data */
    int state, event=0;

    /* get command line arguments */
    nodeName[0] = 0;
    distOpt = TCAP_CONTROL_DATA_PRIMITIVE;
    for (i = 1; i < argc; i++)
    {
        if (strcmp (argv[i], "-rpc") == 0)
        {
            remotePC = (U32) atoi (argv[++i]);
        }
        if (strcmp (argv[i], "-rssn") == 0)
        {
            remoteSSN = (U8) atoi (argv[++i]);
        }
        if (strcmp (argv[i], "-lssn") == 0)
        {
            localSSN = (U8) atoi (argv[++i]);
        }
        if (strcmp (argv[i], "-node") == 0)
        {
            strcpy (nodeName, argv[++i]);
        }
        /* Send a Dialogue Portion in TC_BEGIN using the high level API */
        if (strcmp (argv[i], "-dphi") == 0)
        {
           dpHi = TRUE;
           dpLo = FALSE;
        }
        /* Send a Dialogue Portion in TC_BEGIN using the low level API */
        if (strcmp (argv[i], "-dplo") == 0)
        {
           dpLo = TRUE;
           dpHi = FALSE;
        }
        /* Tell library not to decode Dialogue Portion in incoming
         * messages.
         */
        if (strcmp (argv[i], "-nodpcheck") == 0)
        {
           validateDP = FALSE;
        }
        if (strcmp (argv[i], "-mask") == 0)
        {
            sscanf (argv[++i], "%hx", &tcap_dbg_mask);
        }
        if (strcmp (argv[i], "-control") == 0)
        {
            distOpt = TCAP_CONTROL_PRIMITIVE;
        }
        if (strcmp (argv[i], "-data") == 0)
        {
            distOpt = TCAP_DATA_PRIMITIVE;
        }
    }

    if (distOpt != TCAP_CONTROL_PRIMITIVE)
    {
        if (remotePC == 0xffffffff || remoteSSN == 0 || localSSN == 0 ||
            nodeName[0] == 0)
        {
            printf ("usage: %s -rpc <remote pc> -rssn <remote ssn> "
                    "-lssn <local ssn> -node <node>\n",
                    argv[0]);
            exit (1);
        }
    }
    else
    {
        if (localSSN == 0 || nodeName[0] == 0)
        {
            printf ("usage: %s -lssn <local ssn> -node <node>\n",
                    argv[0]);
            exit (1);
        }
    }


    /* attach to Foundation Toolkit */
    FtUniqueName ("C", myLogicalName);
    if (FtAttachEx (myLogicalName, argv[0], " ", 0, 0, 0, 0, 5, FALSE)
        == RETURNerror)
    {
	printf ("%s: fatal error, FtAttachEx() failed, errno=%d, %s\n",
		argv[0], errno, LastErrorReport);
        exit (1);
    }

    /* register with Foundation Toolkit */
    result = FtRegisterEx (argc, /* Cmd Ln Token Count        */
                         argv,  /* Cmd Ln Tokens              */
                         FALSE, /* Debug                      */
                         FALSE, /* Monitor                    */
                         TRUE,  /* Queue Required             */
                         FALSE, /* Flush Queue                */
                         TRUE,  /* Enqueue always             */
                         TRUE,  /* Catches SIGINT             */
                         NOrestart, /* Restart type           */
                         0,     /* Class declaration          */
                         0,     /* State declaration          */
                         0,     /* Event filter               */
                         10,    /* Retry count                */
                         FALSE); /* Alertable                 */
    if (result == RETURNerror)
    {
	printf ("%s: FtRegisterEx() failed, errno=%d %s\n", argv[0], errno,
		LastErrorReport);
        exit (1);
    }
    if (DebugIndicator)
        printf ("%s: FtAttachEx() and FtRegisterEx() successful.\n", MY_NAME);

    if (FtAssignHandler (SIGINT, sigintHandler) == RETURNerror)
    {
        printf ("%s: FtAssignHandler(SIGINT) failed, errno=%d\n", MY_NAME,
		errno);
        clientExit (1);
    }

    /* attach and bind to logical node */
    savDebugIndicator = DebugIndicator;
    DebugIndicator = FALSE;	/* off during SYSattach() */
    nodeIndex = SYSattach (nodeName, FALSE);
    if (nodeIndex == RETURNerror)
    {
	printf ("%s: SYSattach() failed, check -node value, errno=%d\n",
		MY_NAME, errno);
        clientExit (1);
    }
    DebugIndicator = savDebugIndicator;

    if (distOpt == TCAP_DATA_PRIMITIVE)
    {
#ifdef AC7_T
        distOpt |= TCAP_PROTO_A7;
#endif
#ifdef ACH7_T
        distOpt |= TCAP_PROTO_A7;
#endif
#ifdef AJ7_T
        distOpt |= TCAP_PROTO_A7;
#endif
#ifdef CA7_Q
        distOpt |= TCAP_PROTO_C7;
#endif
    }

    result = SYSbind (nodeIndex, FALSE, MTP_SCCP_TCAP_USER, localSSN,
                      distOpt);
    if (result == RETURNerror)
    {
        printf ("%s: SYSbind() failed, errno=%d\n", MY_NAME, errno);
        clientExit (1);
    }
    if (DebugIndicator)
        printf ("%s: SYSattach() and SYSbind() successful.\n", MY_NAME);

    /* Send user-in-service from all processes.  Data-only processes
       send UIS because stopping the last remaining data
       process generates an automatic user-out-of-service.  */
    if (CscUIS (nodeIndex, localSSN) == RETURNerror)
    {
        printf ("%s: CscUIS() (send user-in-service) failed, ssn=%d,"
		" errno=%d\n", MY_NAME, localSSN, errno);
        clientExit (1);
    }
    if (DebugIndicator)
        printf ("%s: CscUIS() (send user-in-service) successful, ssn=%d.\n",
		MY_NAME, localSSN);

    if (distOpt == TCAP_CONTROL_PRIMITIVE)
        /* do control-only main loop forever */
        controlOnly ();

    /* Setup the SIGALRM signal handler */
    tickTimerCalled = FALSE;
    if (FtAssignHandler (SIGALRM, sigalrmHandler) == RETURNerror)
    {
        printf ("%s: FtAssignHandler(SIGALRM) failed, errno=%d\n", MY_NAME,
		errno);
        clientExit (1);
    }
    if (FtStartTimer (TCAP_ALRM_INT, 0, FALSE) == RETURNerror)
    {
        printf ("%s: FtStartTimer() failed, errno=%d\n", MY_NAME, errno);
        clientExit (1);
    }

    pattr = SYSgetAttributes (nodeName);
    if (pattr == NULL)
    {
	printf ("%s: SYSgetAttributes() failed, check -node value, errno=%d\n",
		MY_NAME, errno);
        clientExit (1);
    }
    localPC = pattr->pointCode;
    if (DebugIndicator)
        printf ("%s: local point code is %d\n", MY_NAME, localPC);

    /* initialize TCAP and get a single dialog ID */
    applicationID = cTCAPInitialize (1, 20, 20, 10, 5, 5, 0, 0,
                      CTCAP_NO_RECOVERY, "OOSVR", nodeName, localSSN);
    if (applicationID == 0)
    {
        printf ("%s: cTCAPInitialize() failed, error %d, %s\n",
                MY_NAME, ctcap_errno, cTCAPerrorReport);
        clientExit (1);
    }
    /* This API call will disable decoding of dialogue portion
     * in inbound messages. Only high level parsing of dialog
     * portion is performed. There is no validation of ASN1 syntax
     * and the dialogue portion is passed to application as a byte
     * array via the pdata pointer in a tblock.
     */
    if (validateDP == FALSE)
    {
       (void)cTCAPdisableDPcheck();
    }
    dialogID = cTCAPGetDialogId ();
    if (DebugIndicator)
        printf ("%s: applicationID=%d dialogID=%d\n", MY_NAME,
                applicationID, dialogID);

    invokeID = 0;
    state = STATE_IDLE;

    finished_initialization = TRUE;     /* SIGINT will set terminate */
    /* main loop of c7sumClient program - get and handle events */
    FOREVER
    {
        char *pnum;
        ctblock_t *ptblock;

        pnum = NULL;
        ptblock = NULL;

        /* get the next event */
        switch (state)
        {
        case STATE_IDLE:
        case STATE_RESULT_RECD:
            event = getKeyboardEvent (&pnum);
            break;
        case STATE_BEGIN_SENT:
        case STATE_CONTINUE_SENT:
            event = getIPCevent (&ptblock);
            break;
        case STATE_CONTINUE_RECD:
            event = getTblockEvent (&ptblock);
            break;
        }

        /* now handle the event */
        if (state < STATE_MIN || state > STATE_MAX)
        {
            printf ("%s: Fatal state/event error, state=%d\n",
                    MY_NAME, state);
            clientExit (1);
        }
        if (DebugIndicator)
            printf ("%s: about to handle event %d in state %d\n",
                    MY_NAME, event, state);
        state = handleEvent[state] (event, pnum, ptblock);
    }   /* end main loop */
    return (EXIT_FAILURE);      /* Prevent compiler warning */
}

/* event getter functions */

/* FUNCTION getIPCevent() - get event from new IPC message */
/**************************************************************************

FUNCTION
        int getIPCevent(ctblock_t **pptb)

DESCRIPTION
        This function blocks until a new TCAP user primitive is found
        based on IPC message input or timer ticks.  Non-state-event
        related IPC messages are handled in the meantime.

INPUTS
        Args:   pptb - tells function where to leave a pointer to new
                        tblock found.

        Others: global tickTimerCalled, set by ALRM signal handler.
                IPC messages found via FtGetIpcEx().


OUTPUTS
        Return: Returns an event code equal to a TC_xxx primitive code
                as found in new tblock.

        Args:   Leaves a pointer to tblock for new TCAP primitive in
                pptb.

        Others: Calls to clientHandleIPC().

FEND
**************************************************************************/
int
getIPCevent (ctblock_t ** pptb)
{
    static ctblock_t tb;
    static cblock_t cblockIn;
    sblock_t sblockIn;

    FOREVER
    {
        BOOL checkTCAP, checkIPC;
        int nCblocksIn;

        checkTCAP = FALSE;
        checkIPC = FALSE;

	if (terminate)
	    clientExit (0);

        if (tickTimerCalled)
        {
            tickTimerCalled = FALSE;
            checkTCAP = TRUE;
        }
        else
        {
            if (FtGetIpcEx (&cblockIn.hdr, 0, sizeof cblockIn,
                          TRUE, TRUE, TRUE) == RETURNerror)
            {
                if (errno == EINTR)
                    continue;

		printf ("%s: FtGetIpcEx() failed, errno=%d, %s\n",
			MY_NAME, errno, LastErrorReport);
                clientExit (1);
            }

            /* here we have a new IPC message */
            if (DebugIndicator)
                printf ("%s: received message. messageType=%d\n",
                        MY_NAME, cblockIn.hdr.messageType);
            if (cblockIn.hdr.messageType == N_UNITDATA_IND ||
                cblockIn.hdr.messageType == N_NOTICE_IND)
            {
                if (cFormatSCCPsblock (&sblockIn,
                                       &cblockIn, 1, &nCblocksIn)
                    == RETURNerror)
                {
                    extern char APIErr[];

                    printf ("%s: cFormatSCCPsblock() failed, %s\n",
                            MY_NAME, APIErr);
                    clientExit (1);
                }
                if (cTCAPTakeMsg (&sblockIn)
                    == RETURNerror)
                {
                    printf ("%s: cTCAPTakeMsg() failed, error %d, %s\n",
                            MY_NAME, ctcap_errno, cTCAPerrorReport);
                    continue;   /* Assume stray message.
                                   Keep listening. */
                }
                checkTCAP = TRUE;
            }
            else
                checkIPC = TRUE;
        }
        if (checkTCAP)
        {
            if (cTCAPGetTblock (&tb) == RETURNerror)
            {
                if (ctcap_errno == TCAP_NO_TBLOCK_PRESENT)
                    /* keep looking */
                    continue;
                else
                {
                    printf ("%s: cTCAPGetTblock() failed, error %d, %s\n",
                            MY_NAME, ctcap_errno,
                            cTCAPerrorReport);
                    clientExit (1);
                }
            }

            /* here we have a tblock */
            *pptb = &tb;        /* store a pointer to the tblock */
            return tb.prim_code;        /* return primitive as event */
        }
        if (checkIPC)
            clientHandleIPC (&cblockIn.hdr);
    }
}

/* FUNCTION getTblockEvent() - get event queued by TCAP library */
/**************************************************************************

FUNCTION
        int getTblockEvent(ctblock_t **pptb)

DESCRIPTION
        This function gets a new TCAP user primitive from the TCAP
        library.  It is only called when a previous dialog handling
        primitive indicates that there is at least one component
        handling primitive queued by the library.

INPUTS
        Args:   pptb - tells function where to leave a pointer to new
                        tblock found.

        Others: none


OUTPUTS
        Return: Returns an event code equal to a TC_xxx primitive code
                as found in new tblock.

        Args:   Leaves a pointer to tblock for new TCAP primitive in
                pptb.

        Others: none

FEND
**************************************************************************/
int
getTblockEvent (ctblock_t ** pptb)
{
    static ctblock_t tb;

    if (cTCAPGetTblock (&tb) == RETURNerror)
    {
        printf ("%s: (component expected) cTCAPGetTblock() error %d, %s\n",
                MY_NAME, ctcap_errno, cTCAPerrorReport);
        clientExit (1);
    }
    *pptb = &tb;                /* store a pointer to the tblock */
    return tb.prim_code;        /* return primitive as event */
}

/* FUNCTION getKeyboardEvent() - get event from the keyboard */
/**************************************************************************

FUNCTION
        int getKeyboardEvent(char **pnum)

DESCRIPTION
        This function blocks until either a number or a blank line is
        entered at the keyboard.  TCAP timer ticks are processed by the
        TCAP libaray in the meantime.

INPUTS
        Args:   pnum - tells function where to leave a pointer to
                        numeric character data.

        Others: keyboard input via fgets(), clearerr(), ferror().


OUTPUTS
        Return: Returns event code EVENT_NEW_NUMBER or EVENT_END_DIALOG.

        Args:   If returning EVENT_NEW_NUMBER, returns a pointer to
                character data via pnum argument.

        Others: none

FEND
**************************************************************************/
int
getKeyboardEvent (char **pnum)
{
    int a;
    #define MAX_IN 100
    static char txtIn[MAX_IN];

    printf ("%s: Enter a number (RETURN to end this dialog): ", MY_NAME);
    do
    {
        clearerr (stdin);
	fgets(txtIn, MAX_IN, stdin);

	if (terminate)
	    clientExit (0);
    }
    while (ferror (stdin) && (errno == EINTR));

    if ((txtIn[0] == 'a') || (txtIn[0] == 'A'))
    {
	/* User has asked for an abort */
	return EVENT_U_ABORT;
    }

    a = strspn (txtIn, "0123456789");
    txtIn[a] = 0;               /* terminate on 1st non-numeric */
    if (a == 0)
        /* blank line ends the dialog */
        return EVENT_END_DIALOG;
    else
    {
        *pnum = txtIn;
        return EVENT_NEW_NUMBER;
    }
}

/* state/event handlers */

/* FUNCTION stateIdle() - State/event handler for IDLE state */
/**************************************************************************

FUNCTION
        int stateIdle(int event, char *pnum, ctblock_t *ptb)

DESCRIPTION
        This function handles one new event (from the keyboard) while
        the client is in the IDLE state.  If a new number was typed, a
        BEGIN(Invoke) is sent to the server.

INPUTS
        Args:   event - event code of new event to be handled.
                pnum - pointer to numeric data, if event was
                        NEW_NUMBER.
                ptb - not used.

        Others: globals applicationID, dialogID


OUTPUTS
        Return: returns new state.

        Args:   none

        Others: new value for global invokeID.
                tblocks sent to TCAP via sendInvoke(), sendDHP().

FEND
**************************************************************************/
int
stateIdle (int event, char *pnum, ctblock_t * ptb)
{
    switch (event)
    {
    case EVENT_END_DIALOG:		/* FALLTHROUGH */
    case EVENT_U_ABORT:
        /* no dialog active, stay in idle */
        return STATE_IDLE;
    case EVENT_NEW_NUMBER:
        invokeID = 1;
        if (sendInvoke (applicationID, dialogID, invokeID, pnum)
            == RETURNerror)
        {
            printf ("%s: cTCAPPutTblock() failed sending INVOKE, "
                    "error %d, %s\n",
                    MY_NAME, ctcap_errno, cTCAPerrorReport);
            clientExit (1);
        }
        if (sendDHP (TC_BEGIN, applicationID, dialogID,
                     CLIENT_QOS | RETURN_ERROR, 0)
            == RETURNerror)
        {
            printf ("%s: cTCAPPutTblock() failed sending BEGIN, "
                    "error %d, %s\n",
                    MY_NAME, ctcap_errno, cTCAPerrorReport);
            clientExit (1);
        }
        return STATE_BEGIN_SENT;
    default:
        printf ("%s: Ignoring event %d in IDLE state.\n",
                MY_NAME, event);
        return STATE_IDLE;
    }
}
/* FUNCTION stateBeginSent() - State/event handler for BEGIN_SENT state */
/**************************************************************************

FUNCTION
        int stateBeginSent(int event, char *pnum, ctblock_t *ptb)

DESCRIPTION
        This function handles one new event (a primitive from the TCAP
        library) while the client is in the BEGIN_SENT state.  The
        normal path is to receive a CONTINUE in this state and go to the
        CONTINUE_RECD state to get a RESULT_L primitive.

INPUTS
        Args:   event - event code of new event to be handled.
                pnum - not used.
                ptb - pointer to tblock for new primitive.

        Others: globals applicationID, dialogID.


OUTPUTS
        Return: returns new state.

        Args:   none

        Others: none

FEND
**************************************************************************/
int
stateBeginSent (int event, char *pnum, ctblock_t * ptb)
{
    switch (event)
    {
    case TC_CONTINUE:
        if (ptb->dialog_id != dialogID ||
            ptb->appl_id != applicationID)
        {
            printf ("%s: Ignoring CONTINUE with appl %xH dialog %xH.\n",
                    MY_NAME, ptb->dialog_id, ptb->appl_id);
            /* stay in same state */
            return STATE_BEGIN_SENT;
        }
        if (!ptb->tcu.dhp.comp_present_ind)
        {
            printf ("%s: Received CONTINUE with no components.\n",
                    MY_NAME);
            /* get next typed number */
            return STATE_RESULT_RECD;
        }
        if (ac_mode_set) /* We sent a dialogue portion in TC_BEGIN */
        {
           ac_mode_set = FALSE;
           if (validateDP == TRUE)
           {
              /* Dialogue Portion must have been fully validated by the
               * library for correct structure and syntax. The 'dp_present_ind'
               * field in dhp is set to TRUE and application context name
               * and user information, if present, will be passed via pdp 
               */
              if (ptb->tcu.dhp.dp_present_ind == TRUE)
              {
                 printf ("%s: Received CONTINUE with Dialogue Portion\n",  
                         MY_NAME);
              }
              else
              {
                 /* Shouldn't happen. Library should have validated this */
                 printf ("%s: Received CONTINUE with no Dialogue Portion.\n",
                         MY_NAME);
                 /* Do something here */
              }

           } /* validateDP == TRUE */
           else
           {
              /* validateDP id FALSE, which means the dialogue portion is 
               * passed as a byte array via pdata. Check data_len in tblock
               * to see if a dialogue portion has been included
               */
              if (ptb->data_len != 0)
              {
                 printf ("%s: Received CONTINUE with Dialogue Portion\n",  
                         MY_NAME);
              }
              else
              {
                 /* Shouldn't happen. Library should have validated this */
                 printf ("%s: Received CONTINUE with no Dialogue Portion.\n",
                         MY_NAME);
                 /* Do something here */

              }
           } /* validateDP == FALSE */
        }
        
        /* now try to get RESULT_L from TCAP */
        return STATE_CONTINUE_RECD;
    case TC_L_CANCEL:
        /* local cancel without ack of BEGIN, must kill dialog */
        printf ("%s: L_CANCEL received. Canceling dialog\n", MY_NAME);
        if (sendDHP (TC_END, applicationID, dialogID, CLIENT_QOS,
                     PRE_ARRANGED_TERMINATE) == RETURNerror)
        {
            printf ("%s: cTCAPPutTblock() failed sending END,"
                    " error %d, %s\n",
                    MY_NAME, ctcap_errno, cTCAPerrorReport);
            clientExit (1);
        }
        return STATE_IDLE;
    case TC_NOTICE:
        /* dialog is dead */
        printf ("%s: NOTICE received.  Dialog canceled\n", MY_NAME);
        return STATE_IDLE;
    case TC_U_ABORT:
        /* dialog is dead */
        printf ("%s: User ABORT received.  Dialog canceled\n", MY_NAME);
        return STATE_IDLE;
    case TC_P_ABORT:
        /* dialog is dead */
        printf ("%s: Peer ABORT received.  Dialog canceled\n", MY_NAME);
        return STATE_IDLE;
    default:
        printf ("%s: Ignoring event %d in BEGIN_SENT state.\n",
                MY_NAME, event);
        return STATE_BEGIN_SENT;
    }
}

/* FUNCTION stateContinueRecd() - handler for CONTINUE_RECD state */
/**************************************************************************

FUNCTION
        int stateContinueRecd(int event, char *pnum, ctblock_t *ptb)

DESCRIPTION
        This function handles one new event (a primitive from the TCAP
        library) while the client is in the CONTINUE_RECD state.  The
        normal path is to get a RESULT_L primitive, display the new sum
        from the user data received, and go to the RESULT_RECD state.

INPUTS
        Args:   event - event code of new event to be handled.
                pnum - not used.
                ptb - pointer to tblock for new primitive.

        Others: global invokeID.


OUTPUTS
        Return: returns new state.

        Args:   none

        Others: Displays new sum received to stdout.

FEND
**************************************************************************/
int
stateContinueRecd (int event, char *pnum, ctblock_t * ptb)
{
    sum_return_result_component_t *prr =
    (sum_return_result_component_t *) ptb->pdata;

    switch (event)
    {
    case TC_RESULT_L:
        if (ptb->tcu.chp.invoke_id != invokeID ||
            prr->seq_tag != CP_SEQ ||
            prr->opcode_tag != CP_OC_LOCAL ||
            prr->opcode_len != 1 ||
            prr->opcode_val != OC_SUM ||
            prr->parm_tag != SUM_DATA_TAG)
            printf ("%s: Unexpected RETURN-RESULT-LAST contents\n",
                    MY_NAME);
        else
            printf ("%s: Sum, so far, is %*.*s\n", MY_NAME,
                    prr->parm_len, prr->parm_len, prr->parm_val);
        /* get next number from keyboard */
        return STATE_RESULT_RECD;
    default:
        printf ("%s: Unexpected component type %d received. "
                "type=%xH code=%xH\n",
                MY_NAME, ptb->prim_code, ptb->tcu.chp.problem_type,
                ptb->tcu.chp.problem_code);
        return STATE_RESULT_RECD;
    }
}

/* FUNCTION stateResultRecd() - State/event handler for RESULT_RECD state */
/**************************************************************************

FUNCTION
        int stateResultRecd(int event, char *pnum, ctblock_t *ptb)

DESCRIPTION
        This function handles one new event (from the keyboard) while
        the client is in the RESULT_RECD state (with a dialog already
        active).  If a new number was typed, a CONTINUE(Invoke) is sent
        to the server.  If a blank line was typed, an END is sent to the
        server.

INPUTS
        Args:   event - event code of new event to be handled.
                pnum - pointer to numeric data, if event was
                        NEW_NUMBER.
                ptb - not used.

        Others: globals applicationID, dialogID


OUTPUTS
        Return: returns new state.

        Args:   none

        Others: new value for global invokeID.
                tblocks sent to TCAP library via sendInvoke(), sendDHP().

FEND
**************************************************************************/
int
stateResultRecd (int event, char *pnum, ctblock_t * ptb)
{
    switch (event)
    {
    case EVENT_END_DIALOG:
        /* send an END */
        if (sendDHP (TC_END, applicationID, dialogID, CLIENT_QOS,
                     BASIC_TERMINATE) == RETURNerror)
        {
            printf ("%s: cTCAPPutTblock() failed sending END, "
                    "error %d, %s\n",
                    MY_NAME, ctcap_errno, cTCAPerrorReport);
            clientExit (1);
        }
        return STATE_IDLE;
    case EVENT_U_ABORT:
        /* send an END */
        if (sendDHP (TC_U_ABORT, applicationID, dialogID, CLIENT_QOS,
                     0) == RETURNerror)
        {
            printf ("%s: cTCAPPutTblock() failed sending U_ABORT, "
                    "error %d, %s\n",
                    MY_NAME, ctcap_errno, cTCAPerrorReport);
            clientExit (1);
        }
        return STATE_IDLE;
    case EVENT_NEW_NUMBER:
        /* send a CONTINUE (INVOKE) */
        invokeID++;
        if (sendInvoke (applicationID, dialogID, invokeID, pnum)
            == RETURNerror)
        {
            printf ("%s: cTCAPPutTblock() failed sending INVOKE, "
                    "error %d, %s\n",
                    MY_NAME, ctcap_errno, cTCAPerrorReport);
            clientExit (1);
        }
        if (sendDHP (TC_CONTINUE, applicationID, dialogID,
                     CLIENT_QOS | RETURN_ERROR, 0)
            == RETURNerror)
        {
            printf ("%s: cTCAPPutTblock() failed sending CONTINUE, "
                    "error %d, %s\n",
                    MY_NAME, ctcap_errno, cTCAPerrorReport);
            clientExit (1);
        }
        return STATE_CONTINUE_SENT;
    default:
        printf ("%s: Ignoring event %d in RESULT_RECD state.\n",
                MY_NAME, event);
        return STATE_RESULT_RECD;
    }
}

/* FUNCTION stateContinueSent() - State/event handler for CONTINUE_SENT state */
/**************************************************************************

FUNCTION
        int stateContinueSent(int event, char *pnum, ctblock_t *ptb)

DESCRIPTION
        This function handles one new event (a primitive from the TCAP
        library) while the client is in the CONTINUE_SENT state.  The
        normal path is to receive a CONTINUE in this state and go to the
        CONTINUE_RECD state to get a RESULT_L primitive.

INPUTS
        Args:   event - event code of new event to be handled.
                pnum - not used.
                ptb - pointer to tblock for new primitive.

        Others: globals applicationID, dialogID.


OUTPUTS
        Return: returns new state.

        Args:   none

        Others: none

FEND
**************************************************************************/
int
stateContinueSent (int event, char *pnum, ctblock_t * ptb)
{
    switch (event)
    {
    case TC_CONTINUE:
        if (ptb->dialog_id != dialogID ||
            ptb->appl_id != applicationID)
        {
            printf ("%s: Ignoring CONTINUE with appl %xH dialog %xH.\n",
                    MY_NAME, ptb->dialog_id, ptb->appl_id);
            /* stay in same state */
            return STATE_CONTINUE_SENT;
        }
        if (!ptb->tcu.dhp.comp_present_ind)
        {
            printf ("%s: Received CONTINUE with no components.\n",
                    MY_NAME);
            /* get next typed number */
            return STATE_RESULT_RECD;
        }
        /* now try to get RESULT_L from TCAP */
        return STATE_CONTINUE_RECD;
    case TC_L_CANCEL:
        printf ("%s: Last INVOKE cancelled locally\n", MY_NAME);
        /* get another number from the keyboard */
        return STATE_RESULT_RECD;
    case TC_NOTICE:
        /* dialog is dead */
        printf ("%s: NOTICE received.  Dialog canceled\n", MY_NAME);
        return STATE_IDLE;
    case TC_U_ABORT:
        /* dialog is dead */
        printf ("%s: User ABORT received.  Dialog canceled\n", MY_NAME);
        return STATE_IDLE;
    case TC_P_ABORT:
        /* dialog is dead */
        printf ("%s: Peer ABORT received.  Dialog canceled\n", MY_NAME);
        return STATE_IDLE;
    default:
        printf ("%s: Ignoring event %d in CONTINUE_SENT state.\n",
                MY_NAME, event);
        return STATE_CONTINUE_SENT;
    }
}

/* FUNCTION sigalrmHandler() - handler for ALRM signal from Unix */
/**************************************************************************

FUNCTION
        void sigalrmHandler(void)

DESCRIPTION
        This function is the signal handler for the Unix ALRM signal.

INPUTS
        Args:   none

        Others: none


OUTPUTS
        Return: none

        Args:   none

        Others: call to cTCAPTickTimer().
                global flag tickTimerCalled set.

FEND
**************************************************************************/
void
sigalrmHandler (void)
{
    cTCAPTickTimer ();
    tickTimerCalled = TRUE;
}

/* FUNCTION sigintHandler() - handler for INT signal from Unix */
/**************************************************************************

FUNCTION
        void sigintHandler(void)

DESCRIPTION
        This function is the signal handler for the Unix INT signal.  It
        causes the program to terminate.

INPUTS
        Args:   none

        Others: none


OUTPUTS
        Return: none

        Args:   none

        Others: Sets terminate.

FEND
**************************************************************************/
void
sigintHandler (void)
{
    if (finished_initialization)
	/*  Do NOT send or receive IPC messages in signal handlers;
	 *  The Ft library IPC functions are NOT Async-Safe.  Instead,
	 *  we set a variable which will be checked in the main
	 *  process loop.
	 */
	terminate = TRUE;
    else
	exit(0);	/* not in main loop yet */
}

/* FUNCTION sendDHP() - send dialog handling primitive to TCAP library */
/**************************************************************************

FUNCTION
        int sendDHP(U8 primCode, U16 applicationID, U16 dialogID,
                S16 qos, U8 termType)

DESCRIPTION
        This function sends a dialog handling primitive (BEGIN, CONTINUE
        or END) to the TCAP libary via cTCAPPutTblock(), building its
        own tblock as necessary.  BEGINs and CONTINUEs are assumed to
        have been preceded by component handling primitives; ENDs are
        assumed not to.

INPUTS
        Args:   primCode - value for prim_code in tblock.  Must be
                        TC_BEGIN, TC_CONTINUE or TC_END.
                applicationID - value for appl_id in tblock.
                dialogID - value for dialog_id in tblock.
                qos - value for qlty_of_svc in tblock.
                termType - value for dialog_term_type (termination type),
                        only if primCode is TC_END.

        Others: none


OUTPUTS
        Return: none

        Args:   none

        Others: calls to cTCAPPutTblock().

FEND
**************************************************************************/
int
sendDHP (U8 primCode, U16 applicationID, U16 dialogID,
         S16 qos, U8 termType )
{
    ctblock_t tb;
    ctcap_dialogue_portion_t low_dp ; /* low level API 'c' structure */
    U8  dp_buf[DP_MAX_BUFF_SIZE]; /* Buffer for encoded dialogue portion */
    U32 dp_buf_size = DP_MAX_BUFF_SIZE;
    ctcap_dialogue_portion_t *pdp = &low_dp; 
    ctcap_dp_t     hi_dp; /* High level API 'c' structure */
    ctcap_error_report_t      error_report;
    int return_code;


    memset (&tb, 0, sizeof tb);
    tb.prim_code = primCode;
    tb.dialog_id = dialogID;
    tb.appl_id = applicationID;
    tb.tcu.dhp.qlty_of_svc = qos;
    tb.tcu.dhp.pdp = &hi_dp; /* Assign high level Dialogue pointer */
    switch (primCode)
    {
    case TC_BEGIN:
        if (DebugIndicator)
            printf ("%s: Sending BEGIN\n", MY_NAME);
        formatAddresses (&tb);
        tb.tcu.dhp.comp_present_ind = TRUE;
        if (dpHi)
        {
           /* Must populate the fields inside atcap_dp_t if we want to use
            * the high level API for sending a dialogue portion within
            * TC_BEGIN. Library will do the encoding.
            */

           if (DebugIndicator)
              printf ("%s: Sending an AARQ using High level API\n", MY_NAME);
           tb.tcu.dhp.dp_present_ind = TRUE;
           tb.tcu.dhp.pdp->application_context_name.length = 4;
           tb.tcu.dhp.pdp->application_context_name.value[0] = 0;
           tb.tcu.dhp.pdp->application_context_name.value[1] = 1;
           tb.tcu.dhp.pdp->application_context_name.value[2] = 0;
           tb.tcu.dhp.pdp->application_context_name.value[3] = 1;
           tb.tcu.dhp.pdp->user_information_length = 1;
           tb.tcu.dhp.pdp->user_information[0].bit_mask = 
                                    ASN1_INDIRECT_REFERENCE_PRESENT;
           tb.tcu.dhp.pdp->user_information[0].indirect_reference = 1024;
           tb.tcu.dhp.pdp->user_information[0].encoding_scheme = 
                                            ASN1_ANY_ENCODING_SCHEME;
           tb.tcu.dhp.pdp->user_information[0].\
                                 encoding.single_asn1_type.length = 4;
           tb.tcu.dhp.pdp->user_information[0]. \
                                 encoding.single_asn1_type.value[0] = 0x80;
           tb.tcu.dhp.pdp->user_information[0]. \
                                 encoding.single_asn1_type.value[1] = 0x02;
           tb.tcu.dhp.pdp->user_information[0]. \
                                 encoding.single_asn1_type.value[2] = 0xAA;
           tb.tcu.dhp.pdp->user_information[0]. \
                                 encoding.single_asn1_type.value[3] = 0xBB;
           ac_mode_set = TRUE;
        } /* High Level API for Dialogue Portion */
        else 
          if (dpLo)
          {
             /* We want to bypass the library's encoding method for dialogue
              * portion. Which means we should either encode the dialogue
              * portion ourselves and pass it via pdata in the tblock, or
              * we can use the low level API provided by the library.
              * This is an example of how to use the low level API
              */
             if (DebugIndicator)
                printf ("%s: Sending an AARQ using Low level API\n", MY_NAME);
             memset((char *)pdp, 0, sizeof(ctcap_dialogue_portion_t));
             pdp->dialogue_type = CTCAP_DP_AARQ;
             pdp->ctcap_dialogue_apdu.aarq.protocol_version = PROTOCOL_VERSION_1;
             pdp->ctcap_dialogue_apdu.aarq.application_context_name.length = 4;
             pdp->ctcap_dialogue_apdu.aarq.application_context_name.value[0] = 0;
             pdp->ctcap_dialogue_apdu.aarq.application_context_name.value[1] = 1;
             pdp->ctcap_dialogue_apdu.aarq.application_context_name.value[2] = 0;
             pdp->ctcap_dialogue_apdu.aarq.application_context_name.value[3] = 1;
             /* user information encoding example shown in the previous case */
            /* Call the low-level encoding function */
            return_code = cTCAPEncodeDialoguePortion(pdp, dp_buf, &dp_buf_size, &error_report);

            if (return_code != RETURNok) {
                fprintf(stderr,"Encoding error <%s> occurred for AARQ encoding\n",
                error_report.error_msg);
            } 
            else {
               /* Encoding was successful. Now assign pdata pointer to the
                * encoded dialogue portion buffer
                */
               tb.pdata = &dp_buf[0];
               tb.data_len = dp_buf_size;
               ac_mode_set = TRUE;
            }
        } /* Low Level API for Dialogue Portion */
        break;
    case TC_CONTINUE:
        if (DebugIndicator)
            printf ("%s: Sending CONTINUE\n", MY_NAME);
        tb.tcu.dhp.comp_present_ind = TRUE;
        break;
    case TC_END:
        if (DebugIndicator)
            printf ("%s: Sending END\n", MY_NAME);
        tb.tcu.dhp.dialog_term_type = termType;
        break;
    case TC_U_ABORT:
        if (DebugIndicator)
            printf ("%s: Sending U_ABORT\n", MY_NAME);
        break;
    default:
	break;
    }
    return cTCAPPutTblock (&tb);
}

/* FUNCTION formatAddresses() - format called and calling addresses */
/**************************************************************************

FUNCTION
        void formatAddresses(ctblock_t *pt)

DESCRIPTION
        This function fills in the local_address[] and remote_address[]
        fields of a tblock being used for a dialog handling primitive,
        prior to sending the tblock to TCAP.  The only addressing option
        supported is point code and subsystem number, without global
        title.

INPUTS
        Args:   pt - pointer to tblock to fill in.

        Others: addressing info will be taken from globals remotePC,
                remoteSSN, localPC and localSSN.


OUTPUTS
        Return: none

        Args:   tblock at pt will get fields local_address[] and
                remote_address[] filled in.

        Others: none

FEND
**************************************************************************/
void
formatAddresses (ctblock_t * pt)
{
    addr_pc_and_ssn_t *pa;

    pa = (addr_pc_and_ssn_t *) pt->tcu.dhp.remote_address;
    pa->len = ADDR_IND_PC_AND_SSN_LEN;
    pa->addr_indication = ADDR_IND_ROUTING_IND +
        ADDR_IND_SSN + ADDR_IND_PC;
    pa->pc_lo = (U8) (remotePC & 0xff);
    pa->pc_hi = (U8) ((remotePC >> 8) & 0xff);
    pa->ssn = remoteSSN;

    pa = (addr_pc_and_ssn_t *) pt->tcu.dhp.local_address;
    pa->len = ADDR_IND_PC_AND_SSN_LEN;
    pa->addr_indication = ADDR_IND_ROUTING_IND +
        ADDR_IND_SSN + ADDR_IND_PC;
    pa->pc_lo = localPC & 0xff;
    pa->pc_hi = (localPC >> 8) & 0xff;
    pa->ssn = localSSN;
}

/* FUNCTION sendInvoke() - send an INVOKE component to TCAP */
/**************************************************************************

FUNCTION
        int sendInvoke(int applicationID, int dialogID, int invokeID,
                char *pnum);

DESCRIPTION
        This function formats and sends an INVOKE component to TCAP,
        containing "number to add" data as defined for the "sum" TCAP
        demo application.  See sum_invoke_component_t in sum.h.

INPUTS
        Args:   applicationID, dialogID, invokeID - appl_id, dialog_id
                        and invoke_id data to be put in tblock.
                pnum - pointer to null-terminated ASCII data to be
                        used as "number to add".

        Others: none


OUTPUTS
        Return: none

        Args:   none

        Others: primitive sent to TCAP via cTCAPPutTblock().

FEND
**************************************************************************/
int
sendInvoke (U16 applicationID, U16 dialogID, S16 invokeID, char *pnum)
{
    ctblock_t tb;

    memset (&tb, 0, sizeof tb);
   int encLen = 0;
   MAP2_MO_ForwardSM_Arg moForwardSM;
   MAP2_MO_ForwardSM_Arg *decMsg = NULL;

   moForwardSM.bit_mask = 0;
   moForwardSM.sm_RP_DA.choice = MAP2_serviceCentreAddressDA_chosen;
   moForwardSM.sm_RP_DA.u.serviceCentreAddressDA.length = 7;
   moForwardSM.sm_RP_DA.u.serviceCentreAddressDA.value[0] = 0x91;
   moForwardSM.sm_RP_DA.u.serviceCentreAddressDA.value[1] = 0x19;
   moForwardSM.sm_RP_DA.u.serviceCentreAddressDA.value[2] = 0x79;
   moForwardSM.sm_RP_DA.u.serviceCentreAddressDA.value[3] = 0x98;
   moForwardSM.sm_RP_DA.u.serviceCentreAddressDA.value[4] = 0x79;
   moForwardSM.sm_RP_DA.u.serviceCentreAddressDA.value[5] = 0x17;
   moForwardSM.sm_RP_DA.u.serviceCentreAddressDA.value[6] = 0x05;

   moForwardSM.sm_RP_OA.choice = MAP2_SM_RP_OA_msisdn_chosen;
   moForwardSM.sm_RP_OA.u.msisdn.length = 8;
   moForwardSM.sm_RP_OA.u.msisdn.value[0] = 0x91;
   moForwardSM.sm_RP_OA.u.msisdn.value[1] = 0x44;
   moForwardSM.sm_RP_OA.u.msisdn.value[2] = 0x57;
   moForwardSM.sm_RP_OA.u.msisdn.value[3] = 0x92;
   moForwardSM.sm_RP_OA.u.msisdn.value[4] = 0x63;
   moForwardSM.sm_RP_OA.u.msisdn.value[5] = 0x35;
   moForwardSM.sm_RP_OA.u.msisdn.value[6] = 0x58;
   moForwardSM.sm_RP_OA.u.msisdn.value[7] = 0xf2;

   moForwardSM.sm_RP_UI.length = 0x17;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x19;
   moForwardSM.sm_RP_UI.value[encLen++] = 0xb1;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x0c;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x91;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x19;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x79;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x98;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x79;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x12;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x34;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x00;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x00;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x08;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x10;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x04;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x18;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x22;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x00;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x22;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x03;
   moForwardSM.sm_RP_UI.value[encLen++] = 0xe2;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x30;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x1b;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x04;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x08;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x24;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x34;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x44;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x55;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x66;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x77;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x88;
   moForwardSM.sm_RP_UI.value[encLen++] = 0xf9;

   unsigned char* L_encodedBuffer = NULL;
   int L_bufferLen=0;
   if(0 == MAP2_encode(&moForwardSM, MAP2_MO_ForwardSM_Arg_PDU, &L_encodedBuffer, &L_bufferLen))
   {
      printf("Encoded successfully\n");
   }
   else
      printf("Encoding failed.\n");

    /* build the tblock */
    tb.prim_code = TC_INVOKE;
    tb.appl_id = applicationID;
    tb.dialog_id = dialogID;
    tb.data_len = L_bufferLen;
    tb.pdata = L_encodedBuffer;
    tb.tcu.chp.linked_id = -1;
    tb.tcu.chp.invoke_id = invokeID;
    tb.tcu.chp.timer_value = CLIENT_INVOKE_TIMER;
    tb.tcu.chp.class_of_oper = CLASS_1;
    tb.tcu.chp.last_comp_ind = TRUE;

    /* send the tblock to TCAP library */
    return cTCAPPutTblock (&tb);
}

/* FUNCTION clientHandleIPC() - handle non-TCAP IPC messages */
/**************************************************************************

FUNCTION
        void clientHandleIPC(Header_t *ph)

DESCRIPTION
        This function handles all IPC messages that are not passed to
        the TCAP library.  N_STATE_IND and N_PC_STATE messages result in
        messages to stdout containing relevant data.  (If multiple
        copies of the client program are started, only the single copy
        with the "control" task will receive such messages).

INPUTS
        Args:   pointer to Ft header of received IPC message.

        Others: none


OUTPUTS
        Return: none

        Args:   none

        Others: formatted messages to stdout only.

FEND
**************************************************************************/
void
clientHandleIPC (Header_t * ph)
{
    iblock_t *pi = (iblock_t *) ph;

    switch (ph->messageType)
    {
    case N_STATE_IND:
        printf ("%s: N_STATE_IND received, pc=%d ssn=%d status=%d\n",
                MY_NAME,
                pi->primitives.nstate.NS_affect_pc,
                pi->primitives.nstate.NS_affect_ssn,
                pi->primitives.nstate.NS_user_status);
        if (pi->primitives.nstate.NS_affect_pc == remotePC &&
            pi->primitives.nstate.NS_affect_ssn == remoteSSN &&
            pi->primitives.nstate.NS_user_status == SCMG_UOS)
        {
            printf ("%s: Server program is out of service\n", MY_NAME);
        }
        break;
    case N_PCSTATE_IND:
        printf ("%s: N_PCSTATE_IND received, pc=%d status=%d "
                "congestion=%d\n",
                MY_NAME,
                pi->primitives.pcstate.pc_pc,
                pi->primitives.pcstate.pc_status,
                pi->primitives.pcstate.pc_congestion_lvl);
        if (pi->primitives.pcstate.pc_pc == remotePC &&
            pi->primitives.pcstate.pc_status ==
            SCMG_INACCESSIBLE)
        {
            printf ("%s: Server program at pc %d is inaccessible\n",
                    MY_NAME, pi->primitives.pcstate.pc_pc);
        }
        break;
    default:
        printf ("%s: Unexpected message type %d received\n",
                MY_NAME, ph->messageType);
        break;
    }
}



/* callback functions called from TCAP library */

/* FUNCTION cUSERReleaseBuffer() - release user data buffer */
/**************************************************************************

FUNCTION
        void cUSERReleaseBuffer ( void *ptr )

DESCRIPTION
        This function is provided to resolve references from the TCAP
        library.  It is never called.

INPUTS
        Args:   never called

        Others: none


OUTPUTS
        Return: never called

        Args:   none

        Others: none

FEND
**************************************************************************/
void
cUSERReleaseBuffer (void *ptr)
{
    /* not used */
}

/* FUNCTION SYSLogEvent() - print log information for TCAP library */
/**************************************************************************

FUNCTION
        void SYSLogEvent(int entity, int mask, char *ptr)

DESCRIPTION
        This function is called by the TCAP library to send debug
        information to the outside world.  It will only be called as
        enabled by bits in the global variable tcap_dbg_mask.  The
        function sends the data to stdout.

INPUTS
        Args:   entity - ignored
                mask - ignored
                ptr - character string data

        Others: process logical name in CPT.


OUTPUTS
        Return: none

        Args:   none

        Others: Characters to stdout via printf().

FEND
**************************************************************************/
void
SYSLogEvent (int entity, int mask, char *ptr)
{
    printf ("%s: TCAPLIB %s", MY_NAME, ptr);
}

/* FUNCTION cUSERTakeMsg() - Called by the TCAP to convert sblk->cblk */
/*************************************************************************

FUNCTION
        cUSERTakeMsg()

DESCRIPTION
        This function is called by the TCAP library when it is done
        building all TCAP components and wants to send the MSU to the
        driver. This function will format the sblock to the cblock and
        then it will send the cblock to the driver.

INPUTS
        Arg:    psb - pointer to the sblock.

        Others: global nodeName.


OUTPUTS
        Return: RETURNok - good status
                RETURNerror - error condition

        Args:   none

        Others: Calls to cFormatSCCPcblock() and FtSendIpcEx().

FEND
************************************************************************/
int
cUSERTakeMsg (sblock_t * psb)
{

    int CblkRet;
    int ret_status;
    cblock_t cb;

    ret_status = cFormatSCCPcblock (psb         /* sblock from TCAP */
                                    ,&cb        /* cblock to be filled in */
                                    ,1  /* how many cblocks to fill */
                                    ,&CblkRet); /* total number cblks filled*/
    if (ret_status == RETURNerror)
    {
        (void) printf ("%s: Error in converting sblock->cblock\n",
                       MY_NAME);
        (void) printf ("%s: %s\n", MY_NAME, APIErr);
        return (RETURNerror);
    }

    /* Setup and send the Cblock to the streams driver.     */
    cb.hdr.messageType = N_UNITDATA_REQ;
    (void) sprintf (cb.hdr.destination, "%s.%s", nodeName, SCCPlogicalNAME);
    ret_status = FtSendIpcEx (&cb.hdr, sizeof cb, CLIENT_IPC_RETRY, FALSE);
    if (ret_status != RETURNok)
    {
        (void) printf ("%s: Unable to send Ipc Msg to streams, errno=%d\n",
                       MY_NAME, errno);
        return (RETURNerror);
    }
    return (RETURNok);
}

/* FUNCTION controlOnly() - main loop for control-only option */
/**************************************************************************

FUNCTION
        void controlOnly(void)

DESCRIPTION
        This function provides a main loop for the c7sumClient process
        when called with the -control option to act as a control process
        on behalf of multiple data processes.

INPUTS
        Args:   none

        Others: IPC input via FtGetIpcEx().


OUTPUTS
        Return: never returns

        Args:   none

        Others: calls to clientHandleIPC().

FEND
**************************************************************************/
void
controlOnly (void)
{
    iblock_t iblockIn;

    if (DebugIndicator)
        printf ("%s: client starting main loop, control only\n",
                MY_NAME);

    FOREVER
    {
        if (FtGetIpcEx (&iblockIn.hdr, 0, sizeof iblockIn,
                      TRUE, TRUE, TRUE) == RETURNerror)
        {
            if (errno == EINTR)
                continue;
            printf ("%s: FtGetIpcEx() failed, errno=%d\n",
                    MY_NAME, errno);
            clientExit (1);
        }
        /* here we have a new IPC message */
        if (DebugIndicator)
            printf ("%s: received message. messageType=%d\n",
                    MY_NAME, iblockIn.hdr.messageType);
        clientHandleIPC (&iblockIn.hdr);
    }
}
