/*************************************************************/
/* Copyright (C) 2008 OSS Nokalva, Inc.  All rights reserved.*/
/*************************************************************/

/* THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC.
 * AND MAY BE USED ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC.
 * THIS FILE MAY NOT BE DISTRIBUTED. */

/* Generated for: Lyca Technologies Solutions Pvt. Ltd., Chennai, India - License 60124 for Solaris 64-bit */
/* Abstract syntax: MAP_DialogueInformation */
/* Created: Fri Jul  4 19:45:15 2008 */
/* ASN.1 compiler version: 8.3.1 */
/* Code generated for runtime version 8.3.1 or later */
/* Compiler operating system: Solaris 7 with 64-bit support */
/* Compiler machine type: SPARC */
/* Target operating system: Solaris 7 with 64-bit support */
/* Target machine type: SPARC */
/* C compiler options required: -xarch=v9 */
/* ASN.1 compiler options and file names specified:
 * -prefix MAP2_ -c++ -relaxedMode -ber -root ../../asn1dflt.solaris7-64bit
 * TCAP.asn MAP-ExtensionDataTypes.asn MAP-ShortMessageServiceOperations.asn
 * MAP-BS-Code.asn MAP-GR-DataTypes.asn MAP-SM-DataTypes.asn
 * MAP-CallHandlingOperations.asn MAP-Group-Call-Operations.asn
 * MAP-SS-Code.asn MAP-CH-DataTypes.asn MAP-MobileServiceOperations.asn
 * MAP-SS-DataTypes.asn MAP-CommonDataTypes.asn MAP-MS-DataTypes.asn
 * MAP-SupplementaryServiceOperations.asn MAP-ER-DataTypes.asn
 * MAP-OM-DataTypes.asn MAP-TS-Code.asn MAP-Errors.asn
 * MAP-OperationAndMaintenanceOperations.asn MAP2.asn
 * MAP-DialogueInformation.asn
 */

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */
#define    OSS_SOED_BER
#include   "osstype.h"
#include   "MAP-DialogueInformation.h"

#ifndef _OSSNOVALUES

const int MAP2_maxNumOfPrivateExtensions = 10;

MAP2_BearerServiceCode MAP2_allBearerServices = {
    1,
    {
        0x00
    }
};

MAP2_BearerServiceCode MAP2_allDataCDA_Services = {
    1,
    {
        0x10
    }
};

MAP2_BearerServiceCode MAP2_dataCDA_300bps = {
    1,
    {
        0x11
    }
};

MAP2_BearerServiceCode MAP2_dataCDA_1200bps = {
    1,
    {
        0x12
    }
};

MAP2_BearerServiceCode MAP2_dataCDA_1200_75bps = {
    1,
    {
        0x13
    }
};

MAP2_BearerServiceCode MAP2_dataCDA_2400bps = {
    1,
    {
        0x14
    }
};

MAP2_BearerServiceCode MAP2_dataCDA_4800bps = {
    1,
    {
        0x15
    }
};

MAP2_BearerServiceCode MAP2_dataCDA_9600bps = {
    1,
    {
        0x16
    }
};

MAP2_BearerServiceCode MAP2_general_dataCDA = {
    1,
    {
        0x17
    }
};

MAP2_BearerServiceCode MAP2_allDataCDS_Services = {
    1,
    {
        0x18
    }
};

MAP2_BearerServiceCode MAP2_dataCDS_1200bps = {
    1,
    {
        0x1A
    }
};

MAP2_BearerServiceCode MAP2_dataCDS_2400bps = {
    1,
    {
        0x1C
    }
};

MAP2_BearerServiceCode MAP2_dataCDS_4800bps = {
    1,
    {
        0x1D
    }
};

MAP2_BearerServiceCode MAP2_dataCDS_9600bps = {
    1,
    {
        0x1E
    }
};

MAP2_BearerServiceCode MAP2_general_dataCDS = {
    1,
    {
        0x1F
    }
};

MAP2_BearerServiceCode MAP2_allPadAccessCA_Services = {
    1,
    {
        0x20
    }
};

MAP2_BearerServiceCode MAP2_padAccessCA_300bps = {
    1,
    {
        0x21
    }
};

MAP2_BearerServiceCode MAP2_padAccessCA_1200bps = {
    1,
    {
        0x22
    }
};

MAP2_BearerServiceCode MAP2_padAccessCA_1200_75bps = {
    1,
    {
        0x23
    }
};

MAP2_BearerServiceCode MAP2_padAccessCA_2400bps = {
    1,
    {
        0x24
    }
};

MAP2_BearerServiceCode MAP2_padAccessCA_4800bps = {
    1,
    {
        0x25
    }
};

MAP2_BearerServiceCode MAP2_padAccessCA_9600bps = {
    1,
    {
        0x26
    }
};

MAP2_BearerServiceCode MAP2_general_padAccessCA = {
    1,
    {
        0x27
    }
};

MAP2_BearerServiceCode MAP2_allDataPDS_Services = {
    1,
    {
        0x28
    }
};

MAP2_BearerServiceCode MAP2_dataPDS_2400bps = {
    1,
    {
        0x2C
    }
};

MAP2_BearerServiceCode MAP2_dataPDS_4800bps = {
    1,
    {
        0x2D
    }
};

MAP2_BearerServiceCode MAP2_dataPDS_9600bps = {
    1,
    {
        0x2E
    }
};

MAP2_BearerServiceCode MAP2_general_dataPDS = {
    1,
    {
        0x2F
    }
};

MAP2_BearerServiceCode MAP2_allAlternateSpeech_DataCDA = {
    1,
    {
        0x30
    }
};

MAP2_BearerServiceCode MAP2_allAlternateSpeech_DataCDS = {
    1,
    {
        0x38
    }
};

MAP2_BearerServiceCode MAP2_allSpeechFollowedByDataCDA = {
    1,
    {
        0x40
    }
};

MAP2_BearerServiceCode MAP2_allSpeechFollowedByDataCDS = {
    1,
    {
        0x48
    }
};

MAP2_BearerServiceCode MAP2_allDataCircuitAsynchronous = {
    1,
    {
        0x50
    }
};

MAP2_BearerServiceCode MAP2_allAsynchronousServices = {
    1,
    {
        0x60
    }
};

MAP2_BearerServiceCode MAP2_allDataCircuitSynchronous = {
    1,
    {
        0x58
    }
};

MAP2_BearerServiceCode MAP2_allSynchronousServices = {
    1,
    {
        0x68
    }
};

MAP2_BearerServiceCode MAP2_allPLMN_specificBS = {
    1,
    {
        0xD0
    }
};

MAP2_BearerServiceCode MAP2_plmn_specificBS_1 = {
    1,
    {
        0xD1
    }
};

MAP2_BearerServiceCode MAP2_plmn_specificBS_2 = {
    1,
    {
        0xD2
    }
};

MAP2_BearerServiceCode MAP2_plmn_specificBS_3 = {
    1,
    {
        0xD3
    }
};

MAP2_BearerServiceCode MAP2_plmn_specificBS_4 = {
    1,
    {
        0xD4
    }
};

MAP2_BearerServiceCode MAP2_plmn_specificBS_5 = {
    1,
    {
        0xD5
    }
};

MAP2_BearerServiceCode MAP2_plmn_specificBS_6 = {
    1,
    {
        0xD6
    }
};

MAP2_BearerServiceCode MAP2_plmn_specificBS_7 = {
    1,
    {
        0xD7
    }
};

MAP2_BearerServiceCode MAP2_plmn_specificBS_8 = {
    1,
    {
        0xD8
    }
};

MAP2_BearerServiceCode MAP2_plmn_specificBS_9 = {
    1,
    {
        0xD9
    }
};

MAP2_BearerServiceCode MAP2_plmn_specificBS_A = {
    1,
    {
        0xDA
    }
};

MAP2_BearerServiceCode MAP2_plmn_specificBS_B = {
    1,
    {
        0xDB
    }
};

MAP2_BearerServiceCode MAP2_plmn_specificBS_C = {
    1,
    {
        0xDC
    }
};

MAP2_BearerServiceCode MAP2_plmn_specificBS_D = {
    1,
    {
        0xDD
    }
};

MAP2_BearerServiceCode MAP2_plmn_specificBS_E = {
    1,
    {
        0xDE
    }
};

MAP2_BearerServiceCode MAP2_plmn_specificBS_F = {
    1,
    {
        0xDF
    }
};

MAP2_SS_Code MAP2_allSS = {
    1,
    {
        0x00
    }
};

MAP2_SS_Code MAP2_allLineIdentificationSS = {
    1,
    {
        0x10
    }
};

MAP2_SS_Code MAP2_clip = {
    1,
    {
        0x11
    }
};

MAP2_SS_Code MAP2_clir = {
    1,
    {
        0x12
    }
};

MAP2_SS_Code MAP2_colp = {
    1,
    {
        0x13
    }
};

MAP2_SS_Code MAP2_colr = {
    1,
    {
        0x14
    }
};

MAP2_SS_Code MAP2_mci = {
    1,
    {
        0x15
    }
};

MAP2_SS_Code MAP2_allNameIdentificationSS = {
    1,
    {
        0x18
    }
};

MAP2_SS_Code MAP2_cnap = {
    1,
    {
        0x19
    }
};

MAP2_SS_Code MAP2_allForwardingSS = {
    1,
    {
        0x20
    }
};

MAP2_SS_Code MAP2_cfu = {
    1,
    {
        0x21
    }
};

MAP2_SS_Code MAP2_allCondForwardingSS = {
    1,
    {
        0x28
    }
};

MAP2_SS_Code MAP2_cfb = {
    1,
    {
        0x29
    }
};

MAP2_SS_Code MAP2_cfnry = {
    1,
    {
        0x2A
    }
};

MAP2_SS_Code MAP2_cfnrc = {
    1,
    {
        0x2B
    }
};

MAP2_SS_Code MAP2_cd = {
    1,
    {
        0x24
    }
};

MAP2_SS_Code MAP2_allCallOfferingSS = {
    1,
    {
        0x30
    }
};

MAP2_SS_Code MAP2_ect = {
    1,
    {
        0x31
    }
};

MAP2_SS_Code MAP2_mah = {
    1,
    {
        0x32
    }
};

MAP2_SS_Code MAP2_allCallCompletionSS = {
    1,
    {
        0x40
    }
};

MAP2_SS_Code MAP2_cw = {
    1,
    {
        0x41
    }
};

MAP2_SS_Code MAP2_hold = {
    1,
    {
        0x42
    }
};

MAP2_SS_Code MAP2_ccbs_A = {
    1,
    {
        0x43
    }
};

MAP2_SS_Code MAP2_ccbs_B = {
    1,
    {
        0x44
    }
};

MAP2_SS_Code MAP2_allMultiPartySS = {
    1,
    {
        0x50
    }
};

MAP2_SS_Code MAP2_multiPTY = {
    1,
    {
        0x51
    }
};

MAP2_SS_Code MAP2_allCommunityOfInterest_SS = {
    1,
    {
        0x60
    }
};

MAP2_SS_Code MAP2_cug = {
    1,
    {
        0x61
    }
};

MAP2_SS_Code MAP2_allChargingSS = {
    1,
    {
        0x70
    }
};

MAP2_SS_Code MAP2_aoci = {
    1,
    {
        0x71
    }
};

MAP2_SS_Code MAP2_aocc = {
    1,
    {
        0x72
    }
};

MAP2_SS_Code MAP2_allAdditionalInfoTransferSS = {
    1,
    {
        0x80
    }
};

MAP2_SS_Code MAP2_uus = {
    1,
    {
        0x81
    }
};

MAP2_SS_Code MAP2_allBarringSS = {
    1,
    {
        0x90
    }
};

MAP2_SS_Code MAP2_barringOfOutgoingCalls = {
    1,
    {
        0x91
    }
};

MAP2_SS_Code MAP2_baoc = {
    1,
    {
        0x92
    }
};

MAP2_SS_Code MAP2_boic = {
    1,
    {
        0x93
    }
};

MAP2_SS_Code MAP2_boicExHC = {
    1,
    {
        0x94
    }
};

MAP2_SS_Code MAP2_barringOfIncomingCalls = {
    1,
    {
        0x99
    }
};

MAP2_SS_Code MAP2_baic = {
    1,
    {
        0x9A
    }
};

MAP2_SS_Code MAP2_bicRoam = {
    1,
    {
        0x9B
    }
};

MAP2_SS_Code MAP2_allPLMN_specificSS = {
    1,
    {
        0xF0
    }
};

MAP2_SS_Code MAP2_plmn_specificSS_1 = {
    1,
    {
        0xF1
    }
};

MAP2_SS_Code MAP2_plmn_specificSS_2 = {
    1,
    {
        0xF2
    }
};

MAP2_SS_Code MAP2_plmn_specificSS_3 = {
    1,
    {
        0xF3
    }
};

MAP2_SS_Code MAP2_plmn_specificSS_4 = {
    1,
    {
        0xF4
    }
};

MAP2_SS_Code MAP2_plmn_specificSS_5 = {
    1,
    {
        0xF5
    }
};

MAP2_SS_Code MAP2_plmn_specificSS_6 = {
    1,
    {
        0xF6
    }
};

MAP2_SS_Code MAP2_plmn_specificSS_7 = {
    1,
    {
        0xF7
    }
};

MAP2_SS_Code MAP2_plmn_specificSS_8 = {
    1,
    {
        0xF8
    }
};

MAP2_SS_Code MAP2_plmn_specificSS_9 = {
    1,
    {
        0xF9
    }
};

MAP2_SS_Code MAP2_plmn_specificSS_A = {
    1,
    {
        0xFA
    }
};

MAP2_SS_Code MAP2_plmn_specificSS_B = {
    1,
    {
        0xFB
    }
};

MAP2_SS_Code MAP2_plmn_specificSS_C = {
    1,
    {
        0xFC
    }
};

MAP2_SS_Code MAP2_plmn_specificSS_D = {
    1,
    {
        0xFD
    }
};

MAP2_SS_Code MAP2_plmn_specificSS_E = {
    1,
    {
        0xFE
    }
};

MAP2_SS_Code MAP2_plmn_specificSS_F = {
    1,
    {
        0xFF
    }
};

MAP2_SS_Code MAP2_allCallPrioritySS = {
    1,
    {
        0xA0
    }
};

MAP2_SS_Code MAP2_emlpp = {
    1,
    {
        0xA1
    }
};

const int MAP2_maxNumOfCCBS_Requests = 5;

const int MAP2_maxUSSD_StringLength = 160;

const int MAP2_maxNumOfSS = 30;

const int MAP2_maxNumOfBasicServiceGroups = 13;

const int MAP2_maxEventSpecification = 2;

const int MAP2_maxAddressLength = 20;

const int MAP2_maxISDN_AddressLength = 9;

const int MAP2_maxISDN_SubaddressLength = 21;

const int MAP2_maxSignalInfoLength = 200;

MAP2_AlertingPattern MAP2_alertingLevel_0 = {
    1,
    {
        0x00
    }
};

MAP2_AlertingPattern MAP2_alertingLevel_1 = {
    1,
    {
        0x01
    }
};

MAP2_AlertingPattern MAP2_alertingLevel_2 = {
    1,
    {
        0x02
    }
};

MAP2_AlertingPattern MAP2_alertingCategory_1 = {
    1,
    {
        0x04
    }
};

MAP2_AlertingPattern MAP2_alertingCategory_2 = {
    1,
    {
        0x05
    }
};

MAP2_AlertingPattern MAP2_alertingCategory_3 = {
    1,
    {
        0x06
    }
};

MAP2_AlertingPattern MAP2_alertingCategory_4 = {
    1,
    {
        0x07
    }
};

MAP2_AlertingPattern MAP2_alertingCategory_5 = {
    1,
    {
        0x08
    }
};

const int MAP2_maxNumOfHLR_Id = 50;

const MAP2_EMLPP_Priority MAP2_priorityLevelA = 6;

const MAP2_EMLPP_Priority MAP2_priorityLevelB = 5;

const MAP2_EMLPP_Priority MAP2_priorityLevel0 = 0;

const MAP2_EMLPP_Priority MAP2_priorityLevel1 = 1;

const MAP2_EMLPP_Priority MAP2_priorityLevel2 = 2;

const MAP2_EMLPP_Priority MAP2_priorityLevel3 = 3;

const MAP2_EMLPP_Priority MAP2_priorityLevel4 = 4;

const int MAP2_maxNumOfPDP_Contexts = 50;

const int MAP2_maxNumOfBearerServices = 50;

const int MAP2_maxNumOfTeleservices = 20;

const int MAP2_maxNumOfCUG = 10;

const int MAP2_maxNumOfExt_BasicServiceGroups = 32;

const int MAP2_maxNumOfZoneCodes = 10;

const int MAP2_maxNumOfBasicServices = 70;

const int MAP2_maxNumOfCamelSSEvents = 10;

const int MAP2_maxNumOfCamelTDPData = 10;

const int MAP2_maxNumOfCamelDestinationNumbers = 10;

const int MAP2_maxNumOfCamelDestinationNumberLengths = 3;

const int MAP2_maxNumOfCamelBasicServiceCriteria = 5;

const int MAP2_maxNumOfVBSGroupIds = 50;

const int MAP2_maxNumOfVGCSGroupIds = 50;

MAP2_TeleserviceCode MAP2_allTeleservices = {
    1,
    {
        0x00
    }
};

MAP2_TeleserviceCode MAP2_allSpeechTransmissionServices = {
    1,
    {
        0x10
    }
};

MAP2_TeleserviceCode MAP2_telephony = {
    1,
    {
        0x11
    }
};

MAP2_TeleserviceCode MAP2_emergencyCalls = {
    1,
    {
        0x12
    }
};

MAP2_TeleserviceCode MAP2_allShortMessageServices = {
    1,
    {
        0x20
    }
};

MAP2_TeleserviceCode MAP2_shortMessageMT_PP = {
    1,
    {
        0x21
    }
};

MAP2_TeleserviceCode MAP2_shortMessageMO_PP = {
    1,
    {
        0x22
    }
};

MAP2_TeleserviceCode MAP2_allFacsimileTransmissionServices = {
    1,
    {
        0x60
    }
};

MAP2_TeleserviceCode MAP2_facsimileGroup3AndAlterSpeech = {
    1,
    {
        0x61
    }
};

MAP2_TeleserviceCode MAP2_automaticFacsimileGroup3 = {
    1,
    {
        0x62
    }
};

MAP2_TeleserviceCode MAP2_facsimileGroup4 = {
    1,
    {
        0x63
    }
};

MAP2_TeleserviceCode MAP2_allDataTeleservices = {
    1,
    {
        0x70
    }
};

MAP2_TeleserviceCode MAP2_allTeleservices_ExeptSMS = {
    1,
    {
        0x80
    }
};

MAP2_TeleserviceCode MAP2_allVoiceGroupCallServices = {
    1,
    {
        0x90
    }
};

MAP2_TeleserviceCode MAP2_voiceGroupCall = {
    1,
    {
        0x91
    }
};

MAP2_TeleserviceCode MAP2_voiceBroadcastCall = {
    1,
    {
        0x92
    }
};

MAP2_TeleserviceCode MAP2_allPLMN_specificTS = {
    1,
    {
        0xD0
    }
};

MAP2_TeleserviceCode MAP2_plmn_specificTS_1 = {
    1,
    {
        0xD1
    }
};

MAP2_TeleserviceCode MAP2_plmn_specificTS_2 = {
    1,
    {
        0xD2
    }
};

MAP2_TeleserviceCode MAP2_plmn_specificTS_3 = {
    1,
    {
        0xD3
    }
};

MAP2_TeleserviceCode MAP2_plmn_specificTS_4 = {
    1,
    {
        0xD4
    }
};

MAP2_TeleserviceCode MAP2_plmn_specificTS_5 = {
    1,
    {
        0xD5
    }
};

MAP2_TeleserviceCode MAP2_plmn_specificTS_6 = {
    1,
    {
        0xD6
    }
};

MAP2_TeleserviceCode MAP2_plmn_specificTS_7 = {
    1,
    {
        0xD7
    }
};

MAP2_TeleserviceCode MAP2_plmn_specificTS_8 = {
    1,
    {
        0xD8
    }
};

MAP2_TeleserviceCode MAP2_plmn_specificTS_9 = {
    1,
    {
        0xD9
    }
};

MAP2_TeleserviceCode MAP2_plmn_specificTS_A = {
    1,
    {
        0xDA
    }
};

MAP2_TeleserviceCode MAP2_plmn_specificTS_B = {
    1,
    {
        0xDB
    }
};

MAP2_TeleserviceCode MAP2_plmn_specificTS_C = {
    1,
    {
        0xDC
    }
};

MAP2_TeleserviceCode MAP2_plmn_specificTS_D = {
    1,
    {
        0xDD
    }
};

MAP2_TeleserviceCode MAP2_plmn_specificTS_E = {
    1,
    {
        0xDE
    }
};

MAP2_TeleserviceCode MAP2_plmn_specificTS_F = {
    1,
    {
        0xDF
    }
};

MAP2_UpdateLocation MAP2_updateLocation = {
    MAP2_localValue_chosen
};

MAP2_CancelLocation MAP2_cancelLocation = {
    MAP2_localValue_chosen
};

MAP2_PurgeMS MAP2_purgeMS = {
    MAP2_localValue_chosen
};

MAP2_SendIdentification MAP2_sendIdentification = {
    MAP2_localValue_chosen
};

MAP2_PrepareHandover MAP2_prepareHandover = {
    MAP2_localValue_chosen
};

MAP2_SendEndSignal MAP2_sendEndSignal = {
    MAP2_localValue_chosen
};

MAP2_ProcessAccessSignalling MAP2_processAccessSignalling = {
    MAP2_localValue_chosen
};

MAP2_ForwardAccessSignalling MAP2_forwardAccessSignalling = {
    MAP2_localValue_chosen
};

MAP2_PrepareSubsequentHandover MAP2_prepareSubsequentHandover = {
    MAP2_localValue_chosen
};

MAP2_SendAuthenticationInfo MAP2_sendAuthenticationInfo = {
    MAP2_localValue_chosen
};

MAP2_CheckIMEI MAP2_checkIMEI = {
    MAP2_localValue_chosen
};

MAP2_InsertSubscriberData MAP2_insertSubscriberData = {
    MAP2_localValue_chosen
};

MAP2_DeleteSubscriberData MAP2_deleteSubscriberData = {
    MAP2_localValue_chosen
};

MAP2_Reset MAP2_reset = {
    MAP2_localValue_chosen
};

MAP2_ForwardCheckSS_Indication MAP2_forwardCheckSS_Indication = {
    MAP2_localValue_chosen
};

MAP2_RestoreData MAP2_restoreData = {
    MAP2_localValue_chosen
};

MAP2_ActivateTraceMode MAP2_activateTraceMode = {
    MAP2_localValue_chosen
};

MAP2_DeactivateTraceMode MAP2_deactivateTraceMode = {
    MAP2_localValue_chosen
};

MAP2_SendIMSI MAP2_sendIMSI = {
    MAP2_localValue_chosen
};

MAP2_SendRoutingInfo MAP2_sendRoutingInfo = {
    MAP2_localValue_chosen
};

MAP2_ProvideRoamingNumber MAP2_provideRoamingNumber = {
    MAP2_localValue_chosen
};

MAP2_ResumeCallHandling MAP2_resumeCallHandling = {
    MAP2_localValue_chosen
};

MAP2_ProvideSIWFSNumber MAP2_provideSIWFSNumber = {
    MAP2_localValue_chosen
};

MAP2_SIWFSSignallingModify MAP2_sIWFSSignallingModify = {
    MAP2_localValue_chosen
};

MAP2_SetReportingState MAP2_setReportingState = {
    MAP2_localValue_chosen
};

MAP2_StatusReport MAP2_statusReport = {
    MAP2_localValue_chosen
};

MAP2_RemoteUserFree MAP2_remoteUserFree = {
    MAP2_localValue_chosen
};

MAP2_RegisterSS MAP2_registerSS = {
    MAP2_localValue_chosen
};

MAP2_EraseSS MAP2_eraseSS = {
    MAP2_localValue_chosen
};

MAP2_ActivateSS MAP2_activateSS = {
    MAP2_localValue_chosen
};

MAP2_DeactivateSS MAP2_deactivateSS = {
    MAP2_localValue_chosen
};

MAP2_InterrogateSS MAP2_interrogateSS = {
    MAP2_localValue_chosen
};

MAP2_ProcessUnstructuredSS_Request MAP2_processUnstructuredSS_Request = {
    MAP2_localValue_chosen
};

MAP2_UnstructuredSS_Request MAP2_unstructuredSS_Request = {
    MAP2_localValue_chosen
};

MAP2_UnstructuredSS_Notify MAP2_unstructuredSS_Notify = {
    MAP2_localValue_chosen
};

MAP2_RegisterPassword MAP2_registerPassword = {
    MAP2_localValue_chosen
};

MAP2_GetPassword MAP2_getPassword = {
    MAP2_localValue_chosen
};

MAP2_RegisterCC_Entry MAP2_registerCC_Entry = {
    MAP2_localValue_chosen
};

MAP2_EraseCC_Entry MAP2_eraseCC_Entry = {
    MAP2_localValue_chosen
};

MAP2_SendRoutingInfoForSM MAP2_sendRoutingInfoForSM = {
    MAP2_localValue_chosen
};

MAP2_MO_ForwardSM MAP2_mo_forwardSM = {
    MAP2_localValue_chosen
};

MAP2_MT_ForwardSM MAP2_mt_forwardSM = {
    MAP2_localValue_chosen
};

MAP2_ReportSM_DeliveryStatus MAP2_reportSM_DeliveryStatus = {
    MAP2_localValue_chosen
};

MAP2_InformServiceCentre MAP2_informServiceCentre = {
    MAP2_localValue_chosen
};

MAP2_AlertServiceCentre MAP2_alertServiceCentre = {
    MAP2_localValue_chosen
};

MAP2_ReadyForSM MAP2_readyForSM = {
    MAP2_localValue_chosen
};

MAP2_ProvideSubscriberInfo MAP2_provideSubscriberInfo = {
    MAP2_localValue_chosen
};

MAP2_AnyTimeInterrogation MAP2_anyTimeInterrogation = {
    MAP2_localValue_chosen
};

MAP2_SS_InvocationNotification MAP2_ss_InvocationNotification = {
    MAP2_localValue_chosen
};

MAP2_PrepareGroupCall MAP2_prepareGroupCall = {
    MAP2_localValue_chosen
};

MAP2_SendGroupCallEndSignal MAP2_sendGroupCallEndSignal = {
    MAP2_localValue_chosen
};

MAP2_ProcessGroupCallSignalling MAP2_processGroupCallSignalling = {
    MAP2_localValue_chosen
};

MAP2_ForwardGroupCallSignalling MAP2_forwardGroupCallSignalling = {
    MAP2_localValue_chosen
};

MAP2_UpdateGprsLocation MAP2_updateGprsLocation = {
    MAP2_localValue_chosen
};

MAP2_SendRoutingInfoForGprs MAP2_sendRoutingInfoForGprs = {
    MAP2_localValue_chosen
};

MAP2_FailureReport MAP2_failureReport = {
    MAP2_localValue_chosen
};

MAP2_NoteMsPresentForGprs MAP2_noteMsPresentForGprs = {
    MAP2_localValue_chosen
};

MAP2_SystemFailure MAP2_systemFailure = {
    MAP2_localValue_chosen
};

MAP2_DataMissing MAP2_dataMissing = {
    MAP2_localValue_chosen
};

MAP2_UnexpectedDataValue MAP2_unexpectedDataValue = {
    MAP2_localValue_chosen
};

MAP2_FacilityNotSupported MAP2_facilityNotSupported = {
    MAP2_localValue_chosen
};

MAP2_IncompatibleTerminal MAP2_incompatibleTerminal = {
    MAP2_localValue_chosen
};

MAP2_ResourceLimitation MAP2_resourceLimitation = {
    MAP2_localValue_chosen
};

MAP2_UnknownSubscriber MAP2_unknownSubscriber = {
    MAP2_localValue_chosen
};

MAP2_NumberChanged MAP2_numberChanged = {
    MAP2_localValue_chosen
};

MAP2_UnknownMSC MAP2_unknownMSC = {
    MAP2_localValue_chosen
};

MAP2_UnidentifiedSubscriber MAP2_unidentifiedSubscriber = {
    MAP2_localValue_chosen
};

MAP2_UnknownEquipment MAP2_unknownEquipment = {
    MAP2_localValue_chosen
};

MAP2_RoamingNotAllowed MAP2_roamingNotAllowed = {
    MAP2_localValue_chosen
};

MAP2_IllegalSubscriber MAP2_illegalSubscriber = {
    MAP2_localValue_chosen
};

MAP2_IllegalEquipment MAP2_illegalEquipment = {
    MAP2_localValue_chosen
};

MAP2_BearerServiceNotProvisioned MAP2_bearerServiceNotProvisioned = {
    MAP2_localValue_chosen
};

MAP2_TeleserviceNotProvisioned MAP2_teleserviceNotProvisioned = {
    MAP2_localValue_chosen
};

MAP2_NoHandoverNumberAvailable MAP2_noHandoverNumberAvailable = {
    MAP2_localValue_chosen
};

MAP2_SubsequentHandoverFailure MAP2_subsequentHandoverFailure = {
    MAP2_localValue_chosen
};

MAP2_TracingBufferFull MAP2_tracingBufferFull = {
    MAP2_localValue_chosen
};

MAP2_NoRoamingNumberAvailable MAP2_noRoamingNumberAvailable = {
    MAP2_localValue_chosen
};

MAP2_AbsentSubscriber MAP2_absentSubscriber = {
    MAP2_localValue_chosen
};

MAP2_BusySubscriber MAP2_busySubscriber = {
    MAP2_localValue_chosen
};

MAP2_NoSubscriberReply MAP2_noSubscriberReply = {
    MAP2_localValue_chosen
};

MAP2_CallBarred MAP2_callBarred = {
    MAP2_localValue_chosen
};

MAP2_ForwardingFailed MAP2_forwardingFailed = {
    MAP2_localValue_chosen
};

MAP2_OR_NotAllowed MAP2_or_NotAllowed = {
    MAP2_localValue_chosen
};

MAP2_ForwardingViolation MAP2_forwardingViolation = {
    MAP2_localValue_chosen
};

MAP2_CUG_Reject MAP2_cug_Reject = {
    MAP2_localValue_chosen
};

MAP2_ATI_NotAllowed MAP2_ati_NotAllowed = {
    MAP2_localValue_chosen
};

MAP2_NoGroupCallNumberAvailable MAP2_noGroupCallNumberAvailable = {
    MAP2_localValue_chosen
};

MAP2_IllegalSS_Operation MAP2_illegalSS_Operation = {
    MAP2_localValue_chosen
};

MAP2_SS_ErrorStatus MAP2_ss_ErrorStatus = {
    MAP2_localValue_chosen
};

MAP2_SS_NotAvailable MAP2_ss_NotAvailable = {
    MAP2_localValue_chosen
};

MAP2_SS_SubscriptionViolation MAP2_ss_SubscriptionViolation = {
    MAP2_localValue_chosen
};

MAP2_SS_Incompatibility MAP2_ss_Incompatibility = {
    MAP2_localValue_chosen
};

MAP2_UnknownAlphabet MAP2_unknownAlphabet = {
    MAP2_localValue_chosen
};

MAP2_USSD_Busy MAP2_ussd_Busy = {
    MAP2_localValue_chosen
};

MAP2_PW_RegistrationFailure MAP2_pw_RegistrationFailure = {
    MAP2_localValue_chosen
};

MAP2_NegativePW_Check MAP2_negativePW_Check = {
    MAP2_localValue_chosen
};

MAP2_NumberOfPW_AttemptsViolation MAP2_numberOfPW_AttemptsViolation = {
    MAP2_localValue_chosen
};

MAP2_ShortTermDenial MAP2_shortTermDenial = {
    MAP2_localValue_chosen
};

MAP2_LongTermDenial MAP2_longTermDenial = {
    MAP2_localValue_chosen
};

MAP2_SubscriberBusyForMT_SMS MAP2_subscriberBusyForMT_SMS = {
    MAP2_localValue_chosen
};

MAP2_SM_DeliveryFailure MAP2_sm_DeliveryFailure = {
    MAP2_localValue_chosen
};

MAP2_MessageWaitingListFull MAP2_messageWaitingListFull = {
    MAP2_localValue_chosen
};

MAP2_AbsentSubscriberSM MAP2_absentsubscriberSM = {
    MAP2_localValue_chosen
};

static unsigned char _v0[] = { 0x04, 0x00, 0x00, 0x01, 0x01, 0x01, 0x01 };
MAP2__ObjectID MAP2_map_DialogueAS = {
    7,
    _v0
};


#if !defined(OSS_SPARTAN_AWARE) || ((OSS_SPARTAN_AWARE + 0) < 2)
static ObjectSetEntry const MAP2_ExtensionSet[] = {
{0}};

#else /* OSS_SPARTAN_AWARE >= 2 */

#if ((OSS_SPARTAN_AWARE + 0) > 12)
static ObjectSetEntry const MAP2_ExtensionSet[] = {
{0}};
#else /* OSS_SPARTAN_AWARE <= 12 */
static ObjectSetEntry const MAP2_ExtensionSet[] = {
{0}};
#endif /* (OSS_SPARTAN_AWARE + 0) > 12 */

static unsigned short const _oss_OSet_info[] =  {
    4
};
#endif /* !OSS_SPARTAN_AWARE || OSS_SPARTAN_AWARE < 2 */

#endif  /* #ifndef _OSSNOVALUES */

#ifdef OSS_SPARTAN_AWARE
#if ((OSS_SPARTAN_AWARE + 0) >= 3)
extern void _oss_run_SOED_on_SPARC_SOLARIS_7_64BIT(void);
static void _oss_post_init(struct ossGlobal *world);
#endif /* OSS_SPARTAN_AWARE >= 3 */
#endif /* OSS_SPARTAN_AWARE */

#ifdef OSS_SPARTAN_AWARE
#if ((OSS_SPARTAN_AWARE + 0) >= 12)
static unsigned char _privateFlags[] = {0x01,0x00};
#endif /* OSS_SPARTAN_AWARE >= 12 */
#endif /* OSS_SPARTAN_AWARE */

static void _ossinit_MAP_DialogueInformation(struct ossGlobal *world) {
#ifndef _OSSNOVALUES

    MAP2_updateLocation.u.localValue = 2;
    MAP2_cancelLocation.u.localValue = 3;
    MAP2_purgeMS.u.localValue = 67;
    MAP2_sendIdentification.u.localValue = 55;
    MAP2_prepareHandover.u.localValue = 68;
    MAP2_sendEndSignal.u.localValue = 29;
    MAP2_processAccessSignalling.u.localValue = 33;
    MAP2_forwardAccessSignalling.u.localValue = 34;
    MAP2_prepareSubsequentHandover.u.localValue = 69;
    MAP2_sendAuthenticationInfo.u.localValue = 56;
    MAP2_checkIMEI.u.localValue = 43;
    MAP2_insertSubscriberData.u.localValue = 7;
    MAP2_deleteSubscriberData.u.localValue = 8;
    MAP2_reset.u.localValue = 37;
    MAP2_forwardCheckSS_Indication.u.localValue = 38;
    MAP2_restoreData.u.localValue = 57;
    MAP2_activateTraceMode.u.localValue = 50;
    MAP2_deactivateTraceMode.u.localValue = 51;
    MAP2_sendIMSI.u.localValue = 58;
    MAP2_sendRoutingInfo.u.localValue = 22;
    MAP2_provideRoamingNumber.u.localValue = 4;
    MAP2_resumeCallHandling.u.localValue = 6;
    MAP2_provideSIWFSNumber.u.localValue = 31;
    MAP2_sIWFSSignallingModify.u.localValue = 32;
    MAP2_setReportingState.u.localValue = 73;
    MAP2_statusReport.u.localValue = 74;
    MAP2_remoteUserFree.u.localValue = 75;
    MAP2_registerSS.u.localValue = 10;
    MAP2_eraseSS.u.localValue = 11;
    MAP2_activateSS.u.localValue = 12;
    MAP2_deactivateSS.u.localValue = 13;
    MAP2_interrogateSS.u.localValue = 14;
    MAP2_processUnstructuredSS_Request.u.localValue = 59;
    MAP2_unstructuredSS_Request.u.localValue = 60;
    MAP2_unstructuredSS_Notify.u.localValue = 61;
    MAP2_registerPassword.u.localValue = 17;
    MAP2_getPassword.u.localValue = 18;
    MAP2_registerCC_Entry.u.localValue = 76;
    MAP2_eraseCC_Entry.u.localValue = 77;
    MAP2_sendRoutingInfoForSM.u.localValue = 45;
    MAP2_mo_forwardSM.u.localValue = 46;
    MAP2_mt_forwardSM.u.localValue = 44;
    MAP2_reportSM_DeliveryStatus.u.localValue = 47;
    MAP2_informServiceCentre.u.localValue = 63;
    MAP2_alertServiceCentre.u.localValue = 64;
    MAP2_readyForSM.u.localValue = 66;
    MAP2_provideSubscriberInfo.u.localValue = 70;
    MAP2_anyTimeInterrogation.u.localValue = 71;
    MAP2_ss_InvocationNotification.u.localValue = 72;
    MAP2_prepareGroupCall.u.localValue = 39;
    MAP2_sendGroupCallEndSignal.u.localValue = 40;
    MAP2_processGroupCallSignalling.u.localValue = 41;
    MAP2_forwardGroupCallSignalling.u.localValue = 42;
    MAP2_updateGprsLocation.u.localValue = 23;
    MAP2_sendRoutingInfoForGprs.u.localValue = 24;
    MAP2_failureReport.u.localValue = 25;
    MAP2_noteMsPresentForGprs.u.localValue = 26;
    MAP2_systemFailure.u.localValue = 34;
    MAP2_dataMissing.u.localValue = 35;
    MAP2_unexpectedDataValue.u.localValue = 36;
    MAP2_facilityNotSupported.u.localValue = 21;
    MAP2_incompatibleTerminal.u.localValue = 28;
    MAP2_resourceLimitation.u.localValue = 51;
    MAP2_unknownSubscriber.u.localValue = 1;
    MAP2_numberChanged.u.localValue = 44;
    MAP2_unknownMSC.u.localValue = 3;
    MAP2_unidentifiedSubscriber.u.localValue = 5;
    MAP2_unknownEquipment.u.localValue = 7;
    MAP2_roamingNotAllowed.u.localValue = 8;
    MAP2_illegalSubscriber.u.localValue = 9;
    MAP2_illegalEquipment.u.localValue = 12;
    MAP2_bearerServiceNotProvisioned.u.localValue = 10;
    MAP2_teleserviceNotProvisioned.u.localValue = 11;
    MAP2_noHandoverNumberAvailable.u.localValue = 25;
    MAP2_subsequentHandoverFailure.u.localValue = 26;
    MAP2_tracingBufferFull.u.localValue = 40;
    MAP2_noRoamingNumberAvailable.u.localValue = 39;
    MAP2_absentSubscriber.u.localValue = 27;
    MAP2_busySubscriber.u.localValue = 45;
    MAP2_noSubscriberReply.u.localValue = 46;
    MAP2_callBarred.u.localValue = 13;
    MAP2_forwardingFailed.u.localValue = 47;
    MAP2_or_NotAllowed.u.localValue = 48;
    MAP2_forwardingViolation.u.localValue = 14;
    MAP2_cug_Reject.u.localValue = 15;
    MAP2_ati_NotAllowed.u.localValue = 49;
    MAP2_noGroupCallNumberAvailable.u.localValue = 50;
    MAP2_illegalSS_Operation.u.localValue = 16;
    MAP2_ss_ErrorStatus.u.localValue = 17;
    MAP2_ss_NotAvailable.u.localValue = 18;
    MAP2_ss_SubscriptionViolation.u.localValue = 19;
    MAP2_ss_Incompatibility.u.localValue = 20;
    MAP2_unknownAlphabet.u.localValue = 71;
    MAP2_ussd_Busy.u.localValue = 72;
    MAP2_pw_RegistrationFailure.u.localValue = 37;
    MAP2_negativePW_Check.u.localValue = 38;
    MAP2_numberOfPW_AttemptsViolation.u.localValue = 43;
    MAP2_shortTermDenial.u.localValue = 29;
    MAP2_longTermDenial.u.localValue = 30;
    MAP2_subscriberBusyForMT_SMS.u.localValue = 31;
    MAP2_sm_DeliveryFailure.u.localValue = 32;
    MAP2_messageWaitingListFull.u.localValue = 33;
    MAP2_absentsubscriberSM.u.localValue = 6;
#endif  /* #ifdef _OSSNOVALUES */

#ifdef OSS_SPARTAN_AWARE
#if ((OSS_SPARTAN_AWARE + 0) >= 3)
    _oss_run_SOED_on_SPARC_SOLARIS_7_64BIT();
#endif /* OSS_SPARTAN_AWARE >= 3 */
#endif /* OSS_SPARTAN_AWARE */
#ifdef OSS_SPARTAN_AWARE
#if ((OSS_SPARTAN_AWARE + 0) >= 12)
    ossPrivateSetMoreFlags(world, 12, _privateFlags);
#endif /* OSS_SPARTAN_AWARE >= 12 */
#endif /* OSS_SPARTAN_AWARE */
    ossLinkBer(world);
#ifdef OSS_SPARTAN_AWARE
#if ((OSS_SPARTAN_AWARE + 0) >= 2)
    ossInitObjectSetInfo(world, (unsigned short *)_oss_OSet_info);
#endif /* OSS_SPARTAN_AWARE >= 2 */
#endif /* OSS_SPARTAN_AWARE */

#ifdef OSS_SPARTAN_AWARE
#if ((OSS_SPARTAN_AWARE + 0) >= 3)
    _oss_post_init(world);
#endif /* OSS_SPARTAN_AWARE >= 3 */
#endif /* OSS_SPARTAN_AWARE */
}

static int const _v41[8] = {
  0, 1, 2, 3, 4, 5, 6, 7
};
static int const _v53[4] = {
  0, 1, 5, 7
};
static int const _v21[4] = {
  1, 2, 3, 4
};
static int const _v51[2] = {0, 3};
static unsigned char const _v43[2] = {0x0, 0x1};
static int const _v58[1] = {INT_MAX};
static int const _v47[1] = {2};
static unsigned char const _v44[1] = {0xf};
static unsigned char const _v40[1] = {0x3f};
static int const _v24[1] = {12};

static const unsigned short _pduarray[] = {
    1, 2, 3, 4, 5, 6, 7, 8, 9, 10,
    11, 12, 13, 14, 15, 16, 17, 18, 19, 20,
    21, 22, 23, 24, 25, 26, 27, 28, 29, 30,
    31, 32, 33, 34, 35, 36, 37, 38, 39, 40,
    41, 42, 43, 44, 45, 46, 47, 48, 49, 50,
    51, 52, 53, 54, 55, 56, 57, 58, 59, 60,
    61, 62, 63, 64, 65, 66, 67, 68, 69, 70,
    71, 72, 73, 74, 75, 76, 77, 78, 79, 80,
    81, 82, 83, 84, 85, 86, 87, 88, 89, 90,
    91, 92, 93, 94, 95, 96, 97, 98, 99, 100,
    101, 102, 103, 104, 105, 106, 107, 108, 109, 110,
    111, 112, 113, 114, 115, 116, 117, 118, 119, 120,
    121, 122, 123, 124, 125, 126, 127, 128, 129, 130,
    131, 132, 133, 134, 135, 136, 137, 138, 139, 140,
    141, 142, 143, 144, 145, 146, 147, 148, 149, 150,
    151, 152, 153, 154, 155, 156, 157, 158, 159, 160,
    161, 162, 163, 164, 165, 166, 167, 168, 169, 170,
    171, 172, 173, 174, 175, 176, 177, 178, 179, 180,
    181, 182, 183, 184, 185, 186, 187, 188, 189, 190,
    191, 192, 193, 194, 195, 196, 197, 198, 199, 200,
    201, 202, 203, 204, 205, 206, 207, 208, 209, 210,
    211, 212, 213, 214, 215, 216, 217, 218, 219, 220,
    221, 222, 223, 224, 225, 226, 227, 228, 229, 230,
    231, 232, 233, 234, 235, 236, 237, 238, 239, 240,
    241, 242, 243, 244, 245, 246, 247, 248, 249, 250,
    251, 252, 253, 254, 255, 256, 257, 258, 0
};

static const struct etype _etypearray[] = {
    {-1, 0, 0, (char *)"_ObjectID", 16, 2, 2, 8, 40, 0, 63, 0},
    {-1, 2, 3, (char *)"MessageType", 112, 5, 2, 8, 8, 0, 13, 0},
    {-1, 2, 14, (char *)"SendRoutingInfoForSM", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"MO-ForwardSM", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"MT-ForwardSM", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"ReportSM-DeliveryStatus", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"AlertServiceCentre", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"InformServiceCentre", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"ReadyForSM", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 19, 21, (char *)"PrepareGroupCallArg", 80, 9, 1, 0, 12, 7, 12, 0},
    {-1, 19, 77, (char *)"PrepareGroupCallRes", 40, 2, 1, 0, 12, 16, 12, 0},
    {-1, 19, 85, (char *)"SendGroupCallEndSignalArg", 40, 2, 1, 0, 12, 18, 12, 0},
    {-1, 19, 95, (char *)"SendGroupCallEndSignalRes", 32, 1, 1, 0, 12, 20, 12, 0},
    {-1, 19, 99, (char *)"ForwardGroupCallSignallingArg", 48, 7, 1, 0, 12, 21, 12, 0},
    {-1, 19, 169, (char *)"ProcessGroupCallSignallingArg", 32, 4, 1, 0, 12, 28, 12, 0},
    {3, 19, 197, (char *)"RoutingInfoForSM-Arg", 88, 7, 1, 0, 2076, 32, 12, 0},
    {-1, 19, 237, (char *)"RoutingInfoForSM-Res", 104, 3, 1, 0, 12, 39, 12, 0},
    {-1, 19, 249, (char *)"MO-ForwardSM-Arg", 280, 4, 1, 0, 12, 42, 12, 0},
    {-1, 19, 77, (char *)"MO-ForwardSM-Res", 232, 2, 1, 0, 12, 46, 12, 0},
    {-1, 19, 275, (char *)"MT-ForwardSM-Arg", 280, 5, 1, 0, 12, 48, 12, 0},
    {-1, 19, 85, (char *)"MT-ForwardSM-Res", 232, 2, 1, 0, 12, 53, 12, 0},
    {4, 19, 307, (char *)"ReportSM-DeliveryStatusArg", 88, 9, 1, 0, 2076, 55, 12, 0},
    {-1, 19, 85, (char *)"ReportSM-DeliveryStatusRes", 40, 2, 1, 0, 12, 64, 12, 0},
    {-1, 19, 373, (char *)"AlertServiceCentreArg", 34, 2, 0, 0, 12, 66, 12, 0},
    {-1, 19, 381, (char *)"InformServiceCentreArg", 56, 3, 1, 0, 12, 68, 12, 0},
    {-1, 19, 399, (char *)"ReadyForSM-Arg", 48, 4, 1, 0, 12, 71, 12, 0},
    {-1, 19, 95, (char *)"ReadyForSM-Res", 32, 1, 1, 0, 12, 75, 12, 0},
    {-1, 2, 14, (char *)"SendRoutingInfo", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"ProvideRoamingNumber", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"ResumeCallHandling", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"ProvideSIWFSNumber", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"SIWFSSignallingModify", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"SetReportingState", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"StatusReport", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"RemoteUserFree", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"PrepareGroupCall", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"SendGroupCallEndSignal", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"ProcessGroupCallSignalling", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"ForwardGroupCallSignalling", 24, 2, 2, 8, 8, 5, 13, 0},
    {3, 19, 417, (char *)"SendRoutingInfoArg", 448, 17, 2, 0, 2076, 76, 12, 0},
    {2, 587, 589, (char *)"SendRoutingInfoRes", 544, 12, 2, 0, 2076, 93, 12, 0},
    {2, 19, 777, (char *)"ProvideRoamingNumberArg", 592, 13, 2, 0, 2076, 105, 12, 0},
    {-1, 19, 77, (char *)"ProvideRoamingNumberRes", 40, 2, 1, 0, 12, 118, 12, 0},
    {1, 19, 939, (char *)"ResumeCallHandlingArg", 232, 8, 1, 0, 2076, 120, 12, 0},
    {-1, 19, 95, (char *)"ResumeCallHandlingRes", 32, 1, 1, 0, 12, 128, 12, 0},
    {-1, 19, 983, (char *)"ProvideSIWFSNumberArg", 1248, 8, 1, 0, 12, 129, 12, 0},
    {-1, 19, 1021, (char *)"ProvideSIWFSNumberRes", 40, 2, 1, 0, 12, 137, 12, 0},
    {-1, 19, 1029, (char *)"SIWFSSignallingModifyArg", 512, 3, 1, 0, 12, 139, 12, 0},
    {-1, 19, 1047, (char *)"SIWFSSignallingModifyRes", 272, 2, 1, 0, 12, 142, 12, 0},
    {-1, 19, 1057, (char *)"SetReportingStateArg", 48, 4, 1, 0, 12, 144, 12, 0},
    {-1, 19, 1047, (char *)"SetReportingStateRes", 32, 2, 1, 0, 12, 148, 12, 0},
    {-1, 19, 1085, (char *)"StatusReportArg", 112, 4, 1, 0, 12, 150, 12, 0},
    {-1, 19, 1107, (char *)"StatusReportRes", 32, 1, 1, 0, 12, 154, 12, 0},
    {-1, 19, 1111, (char *)"RemoteUserFreeArg", 344, 7, 1, 0, 12, 155, 12, 0},
    {-1, 19, 1021, (char *)"RemoteUserFreeRes", 32, 2, 1, 0, 12, 162, 12, 0},
    {-1, 2, 14, (char *)"UpdateLocation", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"CancelLocation", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"PurgeMS", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"SendIdentification", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"UpdateGprsLocation", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"ProvideSubscriberInfo", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"AnyTimeInterrogation", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"PrepareHandover", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"SendEndSignal", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"ProcessAccessSignalling", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"ForwardAccessSignalling", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"PrepareSubsequentHandover", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"SendAuthenticationInfo", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"CheckIMEI", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"InsertSubscriberData", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"DeleteSubscriberData", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"Reset", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"ForwardCheckSS-Indication", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"RestoreData", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"SendRoutingInfoForGprs", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"FailureReport", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"NoteMsPresentForGprs", 24, 2, 2, 8, 8, 5, 13, 0},
    {1, 1145, 0, (char *)"RegisterPasswordArg", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 19, 1147, (char *)"RegisterSS-Arg", 62, 6, 1, 0, 2076, 164, 12, 0},
    {1, 19, 1147, (char *)"RegisterSSArg", 62, 6, 1, 0, 2076, 170, 12, 0},
    {-1, 2, 1193, (char *)"DeactivateSSRes", 88, 3, 2, 8, 8, 176, 13, 0},
    {-1, 2, 1193, (char *)"ActivateSSRes", 88, 3, 2, 8, 8, 179, 13, 0},
    {-1, 2, 1193, (char *)"EraseSSRes", 88, 3, 2, 8, 8, 182, 13, 0},
    {-1, 2, 1193, (char *)"RegisterSSRes", 88, 3, 2, 8, 8, 185, 13, 0},
    {-1, 19, 1200, (char *)"SS-ForBS-Code", 12, 2, 1, 0, 12, 188, 12, 0},
    {-1, 19, 1200, (char *)"InterrogateSSArg", 12, 2, 1, 0, 12, 190, 12, 0},
    {-1, 19, 1200, (char *)"DeactivateSSArg", 12, 2, 1, 0, 12, 192, 12, 0},
    {-1, 19, 1200, (char *)"ActivateSSArg", 12, 2, 1, 0, 12, 194, 12, 0},
    {-1, 19, 1200, (char *)"EraseSSArg", 12, 2, 1, 0, 12, 196, 12, 0},
    {-1, 2, 1210, (char *)"InterrogateSS-Res", 32, 4, 2, 8, 8, 198, 13, 0},
    {-1, 2, 1210, (char *)"InterrogateSSRes", 32, 4, 2, 8, 8, 202, 13, 0},
    {1, 19, 1219, (char *)"USSD-Arg", 172, 3, 1, 0, 2076, 206, 12, 0},
    {1, 19, 1219, (char *)"UnstructuredSS-NotifyArg", 172, 3, 1, 0, 2076, 209, 12, 0},
    {1, 19, 1219, (char *)"UnstructuredSS-RequestArg", 172, 3, 1, 0, 2076, 212, 12, 0},
    {1, 19, 1219, (char *)"ProcessUnstructuredSS-RequestArg", 172, 3, 1, 0, 2076, 215, 12, 0},
    {-1, 19, 373, (char *)"USSD-Res", 166, 2, 0, 0, 12, 218, 12, 0},
    {-1, 19, 373, (char *)"UnstructuredSS-RequestRes", 166, 2, 0, 0, 12, 218, 12, 0},
    {-1, 19, 373, (char *)"ProcessUnstructuredSS-RequestRes", 166, 2, 0, 0, 12, 218, 12, 0},
    {5, 1231, 18, (char *)"Password", 1, 0, 2, 0, 16408, 0, 24, 0},
    {5, 1231, 18, (char *)"GetPasswordRes", 1, 0, 2, 0, 16408, 0, 24, 0},
    {5, 1231, 18, (char *)"RegisterPasswordRes", 1, 0, 2, 0, 16408, 0, 24, 0},
    {2, 1233, 0, (char *)"GuidanceInfo", 4, 0, 4, 0, 24, 1, 58, 0},
    {2, 1233, 0, (char *)"GetPasswordArg", 4, 0, 4, 0, 24, 1, 58, 0},
    {30, 19, 0, (char *)"SS-InfoList", 8, 88, 2, 8, 24, 597, 18, 0},
    {-1, 19, 1235, (char *)"SS-InvocationNotificationArg", 64, 5, 1, 0, 12, 220, 12, 0},
    {-1, 19, 95, (char *)"SS-InvocationNotificationRes", 32, 1, 1, 0, 12, 225, 12, 0},
    {-1, 19, 1021, (char *)"RegisterCC-EntryArg", 568, 2, 1, 0, 12, 226, 12, 0},
    {-1, 19, 1107, (char *)"RegisterCC-EntryRes", 48, 1, 1, 0, 12, 228, 12, 0},
    {-1, 19, 1021, (char *)"EraseCC-EntryArg", 8, 2, 1, 0, 12, 229, 12, 0},
    {-1, 19, 1021, (char *)"EraseCC-EntryRes", 10, 2, 1, 0, 12, 231, 12, 0},
    {-1, 2, 1257, (char *)"SubscriberId", 12, 2, 2, 2, 8, 233, 13, 0},
    {8, 1145, 0, (char *)"IMEI", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 19, 1262, (char *)"UpdateLocationArg", 120, 6, 1, 0, 2076, 235, 12, 0},
    {-1, 19, 77, (char *)"UpdateLocationRes", 40, 2, 1, 0, 12, 241, 12, 0},
    {8, 1145, 0, (char *)"CancelLocationArg", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2, 1292, (char *)"Indentity", 18, 2, 2, 2, 8, 243, 13, 0},
    {INT_MAX, 1233, 0, (char *)"CancellationType", 4, 0, 4, 0, 2076, 6, 58, 0},
    {-1, 19, 95, (char *)"CancelLocationRes", 32, 1, 1, 0, 12, 245, 12, 0},
    {-1, 19, 373, (char *)"PurgeMS-Arg", 22, 2, 0, 0, 12, 246, 12, 0},
    {-1, 19, 1297, (char *)"PurgeMS-Res", 32, 3, 1, 0, 12, 248, 12, 0},
    {-1, 19, 77, (char *)"SendIdentificationRes", 24, 2, 1, 0, 12, 251, 12, 0},
    {-1, 19, 1315, (char *)"UpdateGprsLocationArg", 72, 4, 1, 0, 12, 253, 12, 0},
    {-1, 19, 77, (char *)"UpdateGprsLocationRes", 40, 2, 1, 0, 12, 257, 12, 0},
    {-1, 19, 1331, (char *)"PrepareHO-Arg", 256, 3, 1, 0, 12, 259, 12, 0},
    {-1, 19, 85, (char *)"PrepareHO-Res", 256, 2, 1, 0, 12, 262, 12, 0},
    {-1, 19, 1349, (char *)"PrepareSubsequentHO-Arg", 264, 3, 0, 0, 12, 264, 12, 0},
    {8, 1145, 0, (char *)"SendAuthenticationInfoArg", 2, 0, 2, 2, 24, 0, 21, 0},
    {5, 19, 0, (char *)"SendAuthenticationInfoRes", 8, 40, 2, 8, 24, 675, 18, 0},
    {2, 1233, 0, (char *)"EquipmentStatus", 4, 0, 4, 0, 24, 13, 58, 0},
    {3, 19, 1361, (char *)"InsertSubscriberDataArg", 432, 17, 4, 0, 2076, 267, 12, 0},
    {-1, 19, 1701, (char *)"InsertSubscriberDataRes", 96, 7, 1, 0, 12, 284, 12, 0},
    {1, 19, 1771, (char *)"DeleteSubscriberDataArg", 80, 10, 2, 0, 2076, 291, 12, 0},
    {50, 19, 0, (char *)"ContextIdList", 8, 8, 2, 8, 24, 710, 18, 0},
    {-1, 19, 1883, (char *)"DeleteSubscriberDataRes", 32, 2, 1, 0, 12, 301, 12, 0},
    {-1, 19, 1893, (char *)"SendRoutingInfoForGprsArg", 56, 3, 1, 0, 12, 303, 12, 0},
    {-1, 19, 1085, (char *)"SendRoutingInfoForGprsRes", 64, 4, 1, 0, 12, 306, 12, 0},
    {-1, 19, 1085, (char *)"FailureReportArg", 72, 4, 1, 0, 12, 310, 12, 0},
    {-1, 19, 1107, (char *)"FailureReportRes", 32, 1, 1, 0, 12, 314, 12, 0},
    {-1, 19, 1085, (char *)"NoteMsPresentForGprsArg", 72, 4, 1, 0, 12, 315, 12, 0},
    {-1, 19, 1107, (char *)"NoteMsPresentForGprsRes", 32, 1, 1, 0, 12, 319, 12, 0},
    {-1, 19, 77, (char *)"ResetArg", 24, 2, 1, 0, 12, 320, 12, 0},
    {1, 19, 1907, (char *)"RestoreDataArg", 96, 4, 1, 0, 2076, 322, 12, 0},
    {-1, 19, 1929, (char *)"RestoreDataRes", 40, 3, 1, 0, 12, 326, 12, 0},
    {-1, 19, 1943, (char *)"ProvideSubscriberInfoArg", 80, 4, 1, 0, 12, 329, 12, 0},
    {-1, 19, 1961, (char *)"ProvideSubscriberInfoRes", 152, 2, 1, 0, 12, 333, 12, 0},
    {-1, 19, 1969, (char *)"AnyTimeInterrogationArg", 88, 4, 1, 0, 12, 335, 12, 0},
    {-1, 19, 1961, (char *)"AnyTimeInterrogationRes", 152, 2, 1, 0, 12, 339, 12, 0},
    {-1, 2, 14, (char *)"RegisterSS", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"EraseSS", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"ActivateSS", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"DeactivateSS", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"InterrogateSS", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"ProcessUnstructuredSS-Request", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"UnstructuredSS-Request", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"UnstructuredSS-Notify", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"RegisterPassword", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"GetPassword", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"SS-InvocationNotification", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"RegisterCC-Entry", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"EraseCC-Entry", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 19, 1985, (char *)"RoamingNotAllowedParam", 32, 2, 1, 0, 12, 341, 12, 0},
    {-1, 2, 1993, (char *)"CallBarredParam", 48, 2, 2, 8, 8, 343, 13, 0},
    {-1, 19, 1998, (char *)"CUG-RejectParam", 32, 2, 1, 0, 12, 345, 12, 0},
    {-1, 19, 2008, (char *)"SS-IncompatibilityCause", 16, 3, 1, 0, 12, 347, 12, 0},
    {2, 1233, 0, (char *)"PW-RegistrationFailureCause", 4, 0, 4, 0, 24, 18, 58, 0},
    {-1, 19, 2030, (char *)"SM-DeliveryFailureCause", 240, 3, 1, 0, 12, 350, 12, 0},
    {1, 19, 2044, (char *)"AbsentSubscriberSM-Param", 40, 3, 1, 0, 2076, 353, 12, 0},
    {-1, 2, 1993, (char *)"SystemFailureParam", 40, 2, 2, 8, 8, 356, 13, 0},
    {-1, 19, 95, (char *)"DataMissingParam", 32, 1, 1, 0, 12, 358, 12, 0},
    {-1, 19, 95, (char *)"UnexpectedDataParam", 32, 1, 1, 0, 12, 359, 12, 0},
    {-1, 19, 95, (char *)"FacilityNotSupParam", 32, 1, 1, 0, 12, 360, 12, 0},
    {-1, 19, 95, (char *)"OR-NotAllowedParam", 32, 1, 1, 0, 12, 361, 12, 0},
    {1, 19, 2062, (char *)"UnknownSubscriberParam", 40, 2, 1, 0, 2076, 362, 12, 0},
    {-1, 19, 95, (char *)"NumberChangedParam", 32, 1, 1, 0, 12, 364, 12, 0},
    {-1, 19, 95, (char *)"UnidentifiedSubParam", 32, 1, 1, 0, 12, 365, 12, 0},
    {-1, 19, 95, (char *)"IllegalSubscriberParam", 32, 1, 1, 0, 12, 366, 12, 0},
    {-1, 19, 95, (char *)"IllegalEquipmentParam", 32, 1, 1, 0, 12, 367, 12, 0},
    {-1, 19, 95, (char *)"BearerServNotProvParam", 32, 1, 1, 0, 12, 368, 12, 0},
    {-1, 19, 95, (char *)"TeleservNotProvParam", 32, 1, 1, 0, 12, 369, 12, 0},
    {-1, 19, 95, (char *)"TracingBufferFullParam", 32, 1, 1, 0, 12, 370, 12, 0},
    {-1, 19, 95, (char *)"NoRoamingNbParam", 32, 1, 1, 0, 12, 371, 12, 0},
    {1, 19, 2072, (char *)"AbsentSubscriberParam", 40, 2, 1, 0, 2076, 372, 12, 0},
    {2, 19, 2082, (char *)"BusySubscriberParam", 40, 3, 1, 0, 2076, 374, 12, 0},
    {-1, 19, 95, (char *)"NoSubscriberReplyParam", 32, 1, 1, 0, 12, 377, 12, 0},
    {-1, 19, 95, (char *)"ForwardingViolationParam", 32, 1, 1, 0, 12, 378, 12, 0},
    {-1, 19, 95, (char *)"ForwardingFailedParam", 32, 1, 1, 0, 12, 379, 12, 0},
    {-1, 19, 95, (char *)"ATI-NotAllowedParam", 32, 1, 1, 0, 12, 380, 12, 0},
    {1, 19, 2100, (char *)"SubBusyForMT-SMS-Param", 40, 2, 1, 0, 2076, 381, 12, 0},
    {-1, 19, 95, (char *)"MessageWaitListFullParam", 32, 1, 1, 0, 12, 383, 12, 0},
    {-1, 19, 95, (char *)"ResourceLimitationParam", 32, 1, 1, 0, 12, 384, 12, 0},
    {-1, 19, 95, (char *)"NoGroupCallNbParam", 32, 1, 1, 0, 12, 385, 12, 0},
    {-1, 19, 95, (char *)"IncompatibleTerminalParam", 32, 1, 1, 0, 12, 386, 12, 0},
    {-1, 19, 0, (char *)"ShortTermDenialParam", 1, 0, 0, 0, 12, 387, 12, 0},
    {-1, 19, 0, (char *)"LongTermDenialParam", 1, 0, 0, 0, 12, 387, 12, 0},
    {-1, 19, 2110, (char *)"ActivateTraceModeArg", 64, 5, 1, 0, 12, 387, 12, 0},
    {-1, 19, 1107, (char *)"ActivateTraceModeRes", 32, 1, 1, 0, 12, 392, 12, 0},
    {-1, 19, 2134, (char *)"DeactivateTraceModeArg", 40, 3, 1, 0, 12, 393, 12, 0},
    {-1, 19, 1107, (char *)"DeactivateTraceModeRes", 32, 1, 1, 0, 12, 396, 12, 0},
    {-1, 2, 14, (char *)"SystemFailure", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"DataMissing", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"UnexpectedDataValue", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"FacilityNotSupported", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"IncompatibleTerminal", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"ResourceLimitation", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"UnknownSubscriber", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"NumberChanged", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"UnknownMSC", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"UnidentifiedSubscriber", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"UnknownEquipment", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"RoamingNotAllowed", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"IllegalSubscriber", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"IllegalEquipment", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"BearerServiceNotProvisioned", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"TeleserviceNotProvisioned", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"NoHandoverNumberAvailable", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"SubsequentHandoverFailure", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"TracingBufferFull", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"NoRoamingNumberAvailable", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"AbsentSubscriber", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"BusySubscriber", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"NoSubscriberReply", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"CallBarred", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"ForwardingViolation", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"ForwardingFailed", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"CUG-Reject", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"OR-NotAllowed", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"ATI-NotAllowed", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"IllegalSS-Operation", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"SS-ErrorStatus", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"SS-NotAvailable", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"SS-SubscriptionViolation", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"SS-Incompatibility", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"UnknownAlphabet", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"USSD-Busy", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"PW-RegistrationFailure", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"NegativePW-Check", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"NumberOfPW-AttemptsViolation", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"ShortTermDenial", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"LongTermDenial", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"SubscriberBusyForMT-SMS", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"SM-DeliveryFailure", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"MessageWaitingListFull", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"AbsentSubscriberSM", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"NoGroupCallNumberAvailable", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"ActivateTraceMode", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"DeactivateTraceMode", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"SendIMSI", 24, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 2148, (char *)"MAP-DialoguePDU", 52, 6, 2, 4, 8, 397, 13, 0},
    {-1, 19, 1047, (char *)"MAP-OpenInfo", 46, 2, 1, 0, 12, 403, 12, 0},
    {-1, 19, 0, (char *)"MAP-AcceptInfo", 1, 0, 0, 0, 12, 387, 12, 0},
    {-1, 19, 0, (char *)"MAP-CloseInfo", 1, 0, 0, 0, 12, 387, 12, 0},
    {-1, 19, 2161, (char *)"MAP-RefuseInfo", 4, 1, 0, 0, 12, 405, 12, 0},
    {2, 1233, 0, (char *)"Reason", 4, 0, 4, 0, 24, 23, 58, 0},
    {-1, 19, 2165, (char *)"MAP-UserAbortInfo", 8, 1, 0, 0, 12, 406, 12, 0},
    {-1, 2, 2175, (char *)"MAP-UserAbortChoice", 8, 4, 2, 4, 8, 407, 13, 0},
    {1, 1233, 0, (char *)"ResourceUnavailableReason", 4, 0, 4, 0, 24, 28, 58, 0},
    {6, 1233, 0, (char *)"ProcedureCancellationReason", 4, 0, 4, 0, 24, 32, 58, 0},
    {-1, 19, 2161, (char *)"MAP-ProviderAbortInfo", 4, 1, 0, 0, 12, 411, 12, 0},
    {1, 1233, 0, (char *)"MAP-ProviderAbortReason", 4, 0, 4, 0, 24, 41, 58, 0},
    {-1, 2, 0, (char *)"_Any", 16, 0, 8, 8, 40, 0, 10, 0},
    {-1, 0, 0, (char *)"_ObjectID", 16, 2, 2, 8, 40, 0, 63, 0},
    {-1, 2184, 0, NULL, 4, 0, 4, 0, 8, 0, 0, 0},
    {0, 2186, 7, NULL, 1, 0, 8, 0, 9, 0, 24, 0},
    {-1, 2188, 0, NULL, 32, 0, 0, 0, 8, 0, 51, 0},
    {-1, 2190, 0, (char *)"External_octet_aligned", 16, 0, 4, 8, 40, 0, 20, 0},
    {-1, 2192, 0, (char *)"External_arbitrary", 16, 0, 4, 8, 40, 0, 3, 0},
    {-1, 2, 2194, (char *)"_choice1", 40, 3, 2, 8, 40, 412, 13, 0},
    {-1, 2201, 2203, (char *)"_External", 80, 4, 1, 0, 40, 415, 12, 0},
    {-1, 2247, 2203, (char *)"DialoguePortion", 80, 4, 1, 0, 8, 415, 12, 0},
    {-1, 19, 2250, (char *)"Unidirectional", 96, 2, 1, 0, 8, 419, 12, 0},
    {4, 2260, 0, (char *)"OrigTransactionID", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 19, 2262, (char *)"Begin", 96, 3, 1, 0, 8, 421, 12, 0},
    {4, 2276, 0, (char *)"DestTransactionID", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 19, 2278, (char *)"End", 96, 3, 1, 0, 8, 424, 12, 0},
    {-1, 19, 2292, (char *)"Continue", 104, 4, 1, 0, 8, 427, 12, 0},
    {-1, 2310, 0, (char *)"P-AbortCause", 4, 0, 4, 0, 8, 45, 0, 0},
    {-1, 2, 2312, (char *)"_choice2", 88, 2, 2, 8, 40, 431, 13, 0},
    {-1, 19, 2317, (char *)"Abort", 96, 2, 1, 0, 8, 433, 12, 0},
    {-1, 2327, 2250, (char *)"Unidirectional", 96, 2, 1, 0, 8, 419, 12, 0},
    {-1, 2329, 2262, (char *)"Begin", 96, 3, 1, 0, 8, 421, 12, 0},
    {-1, 2331, 2278, (char *)"End", 96, 3, 1, 0, 8, 424, 12, 0},
    {-1, 2333, 2292, (char *)"Continue", 104, 4, 1, 0, 8, 427, 12, 0},
    {-1, 2335, 2317, (char *)"Abort", 96, 2, 1, 0, 8, 433, 12, 0},
    {-1, 2184, 0, (char *)"InvokeIdType", 2, 0, 2, 0, 8, 0, 0, 0},
    {-1, 2188, 0, (char *)"InvokeIdType", 2, 0, 2, 0, 8, 0, 0, 0},
    {-1, 2184, 0, NULL, 4, 0, 4, 0, 8, 0, 0, 0},
    {-1, 2, 14, (char *)"_choice3", 24, 2, 2, 8, 40, 5, 13, 0},
    {-1, 2, 0, (char *)"_Any", 16, 0, 8, 8, 40, 0, 10, 0},
    {-1, 19, 2337, (char *)"Invoke", 48, 4, 1, 0, 8, 435, 12, 0},
    {-1, 19, 2357, (char *)"_seq1", 40, 2, 0, 0, 40, 439, 12, 0},
    {-1, 19, 2365, (char *)"ReturnResult", 48, 2, 1, 0, 8, 441, 12, 0},
    {-1, 2, 0, (char *)"_Any", 16, 0, 8, 8, 40, 0, 10, 0},
    {-1, 19, 2373, (char *)"ReturnError", 48, 3, 1, 0, 8, 443, 12, 0},
    {-1, 2184, 0, (char *)"GeneralProblem", 4, 0, 4, 0, 8, 52, 0, 0},
    {-1, 2184, 0, (char *)"InvokeProblem", 4, 0, 4, 0, 8, 57, 0, 0},
    {-1, 2184, 0, (char *)"ReturnResultProblem", 4, 0, 4, 0, 8, 67, 0, 0},
    {-1, 2184, 0, (char *)"ReturnErrorProblem", 4, 0, 4, 0, 8, 72, 0, 0},
    {-1, 2385, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2, 2387, (char *)"_choice4", 4, 2, 2, 2, 40, 446, 13, 0},
    {-1, 2188, 0, (char *)"GeneralProblem", 4, 0, 4, 0, 8, 52, 0, 0},
    {-1, 2190, 0, (char *)"InvokeProblem", 4, 0, 4, 0, 8, 57, 0, 0},
    {-1, 2192, 0, (char *)"ReturnResultProblem", 4, 0, 4, 0, 8, 67, 0, 0},
    {-1, 587, 0, (char *)"ReturnErrorProblem", 4, 0, 4, 0, 8, 72, 0, 0},
    {-1, 2, 2175, (char *)"_choice5", 8, 4, 2, 4, 40, 448, 13, 0},
    {-1, 19, 2392, (char *)"Reject", 12, 2, 0, 0, 8, 452, 12, 0},
    {-1, 2190, 2337, (char *)"Invoke", 48, 4, 1, 0, 8, 435, 12, 0},
    {-1, 2192, 2365, (char *)"ReturnResult", 48, 2, 1, 0, 8, 441, 12, 0},
    {-1, 587, 2373, (char *)"ReturnError", 48, 3, 1, 0, 8, 443, 12, 0},
    {-1, 2408, 2392, (char *)"Reject", 12, 2, 0, 0, 8, 452, 12, 0},
    {-1, 2410, 2365, (char *)"ReturnResult", 48, 2, 1, 0, 8, 441, 12, 0},
    {-1, 2, 2412, (char *)"Component", 56, 5, 2, 8, 8, 454, 13, 0},
    {-1, 2423, 0, (char *)"ComponentPortion", 8, 56, 4, 8, 8, 310, 18, 0},
    {-1, 2, 0, NULL, 2, 0, 0, 0, 8, 0, 50, 0},
    {-1, 2184, 0, NULL, 8, 0, 8, 0, 8, 0, 0, 0},
    {-1, 2, 0, (char *)"MAP-EXTENSION", 32, 3, 1, 0, 8, 459, 49, 0},
    {-1, 19, 0, (char *)"PCS-Extensions", 1, 0, 0, 0, 12, 387, 12, 0},
    {10, 2188, 0, (char *)"PrivateExtensionList", 8, 56, 2, 8, 24, 321, 18, 0},
    {-1, 2190, 0, (char *)"PCS-Extensions", 1, 0, 0, 0, 12, 387, 12, 0},
    {-1, 19, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {-1, 0, 0, (char *)"_ObjectID", 16, 2, 2, 8, 40, 0, 63, 0},
    {-1, 2, 0, NULL, 32, 0, 0, 0, 8, 0, 51, 0},
    {-1, 19, 2425, (char *)"PrivateExtension", 56, 2, 1, 0, 264, 464, 12, 0},
    {10, 19, 0, (char *)"PrivateExtensionList", 8, 56, 2, 8, 24, 321, 18, 0},
    {1, 1145, 0, (char *)"BearerServiceCode", 2, 0, 2, 2, 24, 0, 21, 0},
    {5, 1145, 0, (char *)"Ext-BearerServiceCode", 2, 0, 2, 2, 24, 0, 21, 0},
    {5, 1145, 0, (char *)"Ext-TeleserviceCode", 2, 0, 2, 2, 24, 0, 21, 0},
    {8, 1145, 0, (char *)"ASCI-CallReference", 2, 0, 2, 2, 24, 0, 21, 0},
    {10, 1145, 0, (char *)"CODEC-Info", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 1145, 0, (char *)"CipheringAlgorithm", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2184, 0, (char *)"GroupKeyNumber", 2, 0, 2, 0, 8, 0, 55, 0},
    {8, 1145, 0, (char *)"Kc", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2184, 0, (char *)"EMLPP-Priority", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 2188, 0, (char *)"GroupKeyNumber", 2, 0, 2, 0, 8, 0, 55, 0},
    {8, 2190, 0, (char *)"Kc", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2192, 0, (char *)"EMLPP-Priority", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 587, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2408, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {9, 1145, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {8, 1145, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2188, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2190, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2192, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 587, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2408, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2188, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2190, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2192, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {20, 1145, 0, (char *)"AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2184, 0, (char *)"SM-RP-MTI", 2, 0, 2, 0, 8, 0, 55, 0},
    {12, 1145, 0, (char *)"SM-RP-SMEA", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 2188, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2190, 0, NULL, 1, 0, 0, 0, 8, 0, 8, 0},
    {20, 2192, 0, (char *)"AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2431, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {-1, 2410, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2433, 0, (char *)"SM-RP-MTI", 2, 0, 2, 0, 8, 0, 55, 0},
    {12, 2435, 0, (char *)"SM-RP-SMEA", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 1145, 0, (char *)"LMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 2188, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 2190, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2, 1257, (char *)"Additional-Number", 14, 2, 2, 2, 8, 466, 13, 0},
    {9, 2190, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2437, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2431, 1257, (char *)"Additional-Number", 14, 2, 2, 2, 8, 466, 13, 0},
    {2, 19, 2439, (char *)"LocationInfoWithLMSI", 64, 5, 1, 0, 2076, 468, 12, 0},
    {2, 2188, 2439, (char *)"LocationInfoWithLMSI", 64, 5, 1, 0, 2076, 468, 12, 0},
    {-1, 2408, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {8, 2188, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 2190, 0, (char *)"LMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {20, 2408, 0, (char *)"AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2437, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2, 2471, (char *)"SM-RP-DA", 24, 4, 2, 2, 8, 473, 13, 0},
    {9, 2192, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {20, 2408, 0, (char *)"AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2437, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2, 2480, (char *)"SM-RP-OA", 24, 3, 2, 2, 8, 477, 13, 0},
    {200, 1145, 0, (char *)"SignalInfo", 2, 0, 2, 2, 24, 0, 21, 0},
    {2, 1233, 0, (char *)"SM-DeliveryOutcome", 4, 0, 4, 0, 24, 79, 58, 0},
    {-1, 2184, 0, (char *)"AbsentSubscriberDiagnosticSM", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 2188, 0, (char *)"AbsentSubscriberDiagnosticSM", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 2190, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {-1, 2192, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 587, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {2, 2408, 0, (char *)"SM-DeliveryOutcome", 4, 0, 4, 0, 24, 79, 58, 0},
    {-1, 2437, 0, (char *)"AbsentSubscriberDiagnosticSM", 2, 0, 2, 0, 8, 0, 55, 0},
    {16, 2487, 0, (char *)"MW-Status", 16, 0, 2, 8, 24, 84, 3, 0},
    {1, 1233, 0, (char *)"AlertReason", 4, 0, 4, 0, 24, 90, 58, 0},
    {8, 2188, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 1145, 0, (char *)"SS-Code", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 1145, 0, (char *)"CUG-Interlock", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 19, 1929, (char *)"CUG-CheckInfo", 40, 3, 1, 0, 12, 480, 12, 0},
    {-1, 2184, 0, (char *)"NumberOfForwarding", 2, 0, 2, 0, 8, 0, 55, 0},
    {1, 1233, 0, (char *)"InterrogationType", 4, 0, 4, 0, 24, 94, 58, 0},
    {-1, 2184, 0, (char *)"OR-Phase", 2, 0, 2, 0, 8, 0, 55, 0},
    {8, 1145, 0, (char *)"CallReferenceNumber", 2, 0, 2, 2, 24, 0, 21, 0},
    {2, 1233, 0, (char *)"ForwardingReason", 4, 0, 4, 0, 24, 98, 58, 0},
    {5, 2192, 0, (char *)"Ext-BearerServiceCode", 2, 0, 2, 2, 24, 0, 21, 0},
    {5, 587, 0, (char *)"Ext-TeleserviceCode", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2, 2489, (char *)"Ext-BasicServiceCode", 10, 2, 2, 2, 8, 483, 13, 0},
    {4, 1233, 0, (char *)"ProtocolId", 4, 0, 4, 0, 24, 103, 58, 0},
    {-1, 19, 2494, (char *)"ExternalSignalInfo", 240, 3, 1, 0, 12, 485, 12, 0},
    {16, 2487, 0, (char *)"SupportedCamelPhases", 16, 0, 2, 8, 24, 109, 3, 0},
    {-1, 19, 2506, (char *)"CamelInfo", 56, 3, 1, 0, 12, 488, 12, 0},
    {-1, 2385, 0, (char *)"SuppressionOfAnnouncement", 1, 0, 0, 0, 8, 0, 5, 0},
    {1, 1145, 0, (char *)"AlertingPattern", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2184, 0, (char *)"SupportedCCBS-Phase", 2, 0, 2, 0, 8, 0, 55, 0},
    {9, 2188, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2190, 1929, (char *)"CUG-CheckInfo", 40, 3, 1, 0, 12, 480, 12, 0},
    {-1, 2192, 0, (char *)"NumberOfForwarding", 2, 0, 2, 0, 8, 0, 55, 0},
    {1, 587, 0, (char *)"InterrogationType", 4, 0, 4, 0, 24, 94, 58, 0},
    {-1, 2408, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2437, 0, (char *)"OR-Phase", 2, 0, 2, 0, 8, 0, 55, 0},
    {9, 2431, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {8, 2410, 0, (char *)"CallReferenceNumber", 2, 0, 2, 2, 24, 0, 21, 0},
    {2, 2433, 0, (char *)"ForwardingReason", 4, 0, 4, 0, 24, 98, 58, 0},
    {-1, 2435, 2489, (char *)"Ext-BasicServiceCode", 10, 2, 2, 2, 8, 483, 13, 0},
    {-1, 2520, 2494, (char *)"ExternalSignalInfo", 240, 3, 1, 0, 12, 485, 12, 0},
    {-1, 2522, 2506, (char *)"CamelInfo", 56, 3, 1, 0, 12, 488, 12, 0},
    {-1, 2524, 0, (char *)"SuppressionOfAnnouncement", 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2526, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {1, 2528, 0, (char *)"AlertingPattern", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2530, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2532, 0, (char *)"SupportedCCBS-Phase", 2, 0, 2, 0, 8, 0, 55, 0},
    {21, 1145, 0, (char *)"ISDN-SubaddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 1145, 0, (char *)"ForwardingOptions", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 2437, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {21, 2408, 0, (char *)"ISDN-SubaddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 2431, 0, (char *)"ForwardingOptions", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2410, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {-1, 19, 2534, (char *)"ForwardingData", 72, 4, 1, 0, 12, 491, 12, 0},
    {-1, 2, 1292, (char *)"RoutingInfo", 80, 2, 2, 8, 8, 495, 13, 0},
    {-1, 2184, 0, (char *)"CamelCapabilityHandling", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 2188, 0, (char *)"CamelCapabilityHandling", 2, 0, 2, 0, 8, 0, 55, 0},
    {1, 19, 2562, (char *)"T-CSI", 48, 3, 1, 0, 2076, 497, 12, 0},
    {-1, 2188, 0, (char *)"CamelCapabilityHandling", 2, 0, 2, 0, 8, 0, 55, 0},
    {1, 19, 2562, (char *)"O-CSI", 48, 3, 1, 0, 2076, 500, 12, 0},
    {1, 2188, 2562, (char *)"T-CSI", 48, 3, 1, 0, 2076, 497, 12, 0},
    {1, 2190, 2562, (char *)"O-CSI", 48, 3, 1, 0, 2076, 500, 12, 0},
    {-1, 2192, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {-1, 19, 1029, (char *)"GmscCamelSubscriptionInfo", 128, 3, 1, 0, 12, 503, 12, 0},
    {-1, 2188, 1029, (char *)"GmscCamelSubscriptionInfo", 128, 3, 1, 0, 12, 503, 12, 0},
    {-1, 2190, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {-1, 19, 2576, (char *)"CamelRoutingInfo", 232, 3, 1, 0, 12, 506, 12, 0},
    {-1, 2433, 2576, (char *)"CamelRoutingInfo", 232, 3, 1, 0, 12, 506, 12, 0},
    {-1, 2, 2590, (char *)"ExtendedRoutingInfo", 240, 2, 2, 8, 8, 509, 13, 0},
    {-1, 2184, 0, (char *)"AgeOfLocationInformation", 2, 0, 2, 0, 8, 0, 55, 0},
    {8, 1145, 0, (char *)"GeographicalInformation", 2, 0, 2, 2, 24, 0, 21, 0},
    {10, 1145, 0, (char *)"LocationNumber", 2, 0, 2, 2, 24, 0, 21, 0},
    {7, 1145, 0, (char *)"CellIdFixedLength", 2, 0, 2, 2, 24, 0, 21, 0},
    {5, 1145, 0, (char *)"LAIFixedLength", 2, 0, 2, 2, 24, 0, 21, 0},
    {7, 2188, 0, (char *)"CellIdFixedLength", 2, 0, 2, 2, 24, 0, 21, 0},
    {5, 2190, 0, (char *)"LAIFixedLength", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2, 1257, (char *)"CellIdOrLAI", 12, 2, 2, 2, 8, 511, 13, 0},
    {8, 2188, 0, (char *)"GeographicalInformation", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 2190, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {10, 2192, 0, (char *)"LocationNumber", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 587, 1257, (char *)"CellIdOrLAI", 12, 2, 2, 2, 8, 511, 13, 0},
    {-1, 2408, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {-1, 19, 2597, (char *)"LocationInformation", 80, 6, 1, 0, 12, 513, 12, 0},
    {3, 1233, 0, (char *)"NotReachableReason", 4, 0, 4, 0, 24, 113, 58, 0},
    {-1, 2188, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2190, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2192, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2, 2651, (char *)"SubscriberState", 8, 4, 2, 4, 8, 519, 13, 0},
    {-1, 2188, 2597, (char *)"LocationInformation", 80, 6, 1, 0, 12, 513, 12, 0},
    {-1, 2190, 2651, (char *)"SubscriberState", 8, 4, 2, 4, 8, 519, 13, 0},
    {-1, 2192, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {-1, 19, 1029, (char *)"SubscriberInfo", 120, 3, 1, 0, 12, 523, 12, 0},
    {3, 1145, 0, (char *)"NAEA-CIC", 2, 0, 2, 2, 24, 0, 21, 0},
    {3, 2188, 0, (char *)"NAEA-CIC", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2190, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {-1, 19, 1021, (char *)"NAEA-PreferredCI", 32, 2, 1, 0, 12, 526, 12, 0},
    {-1, 2188, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2190, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2192, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {-1, 19, 1029, (char *)"CCBS-Indicators", 32, 3, 1, 0, 12, 528, 12, 0},
    {8, 2435, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 587, 1929, (char *)"CUG-CheckInfo", 40, 3, 1, 0, 12, 480, 12, 0},
    {-1, 2431, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2410, 1029, (char *)"SubscriberInfo", 120, 3, 1, 0, 12, 523, 12, 0},
    {30, 2190, 0, (char *)"SS-List", 8, 8, 2, 8, 24, 388, 18, 0},
    {-1, 2437, 2489, (char *)"Ext-BasicServiceCode", 10, 2, 2, 2, 8, 483, 13, 0},
    {-1, 2408, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {9, 2192, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2188, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {-1, 2520, 1021, (char *)"NAEA-PreferredCI", 32, 2, 1, 0, 12, 526, 12, 0},
    {-1, 2522, 1029, (char *)"CCBS-Indicators", 32, 3, 1, 0, 12, 528, 12, 0},
    {8, 2188, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 2190, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 2192, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 2408, 0, (char *)"LMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2437, 2494, (char *)"ExternalSignalInfo", 240, 3, 1, 0, 12, 485, 12, 0},
    {-1, 2431, 2494, (char *)"ExternalSignalInfo", 240, 3, 1, 0, 12, 485, 12, 0},
    {-1, 2410, 0, (char *)"SuppressionOfAnnouncement", 1, 0, 0, 0, 8, 0, 5, 0},
    {9, 2433, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {8, 2435, 0, (char *)"CallReferenceNumber", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2520, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2522, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {1, 2524, 0, (char *)"AlertingPattern", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2526, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {8, 2188, 0, (char *)"CallReferenceNumber", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2190, 2489, (char *)"Ext-BasicServiceCode", 10, 2, 2, 2, 8, 483, 13, 0},
    {-1, 2192, 2534, (char *)"ForwardingData", 72, 4, 1, 0, 12, 491, 12, 0},
    {8, 587, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2408, 1929, (char *)"CUG-CheckInfo", 40, 3, 1, 0, 12, 480, 12, 0},
    {1, 2437, 2562, (char *)"O-CSI", 48, 3, 1, 0, 2076, 500, 12, 0},
    {-1, 2410, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {-1, 2433, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {INT_MAX, 1233, 0, (char *)"T-BcsmTriggerDetectionPoint", 4, 0, 4, 0, 2076, 119, 58, 0},
    {-1, 2184, 0, (char *)"ServiceKey", 4, 0, 4, 0, 8, 0, 55, 0},
    {INT_MAX, 1233, 0, (char *)"DefaultCallHandling", 4, 0, 4, 0, 2076, 125, 58, 0},
    {9, 2188, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {INT_MAX, 2190, 0, (char *)"DefaultCallHandling", 4, 0, 4, 0, 2076, 125, 58, 0},
    {-1, 2192, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {-1, 19, 2660, (char *)"T-BcsmCamelTDPData", 56, 5, 1, 0, 12, 531, 12, 0},
    {10, 19, 0, (char *)"T-BcsmCamelTDPDataList", 8, 56, 2, 8, 24, 514, 18, 0},
    {1, 1145, 0, (char *)"CallDirection", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2188, 2494, (char *)"ExternalSignalInfo", 240, 3, 1, 0, 12, 485, 12, 0},
    {-1, 2190, 2494, (char *)"ExternalSignalInfo", 240, 3, 1, 0, 12, 485, 12, 0},
    {1, 2192, 0, (char *)"CallDirection", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 587, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2408, 2494, (char *)"ExternalSignalInfo", 240, 3, 1, 0, 12, 485, 12, 0},
    {-1, 2437, 2494, (char *)"ExternalSignalInfo", 240, 3, 1, 0, 12, 485, 12, 0},
    {-1, 2431, 2494, (char *)"ExternalSignalInfo", 240, 3, 1, 0, 12, 485, 12, 0},
    {-1, 2410, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {9, 2188, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2190, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {-1, 2188, 2494, (char *)"ExternalSignalInfo", 240, 3, 1, 0, 12, 485, 12, 0},
    {-1, 2190, 2494, (char *)"ExternalSignalInfo", 240, 3, 1, 0, 12, 485, 12, 0},
    {-1, 2192, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {-1, 2188, 2494, (char *)"ExternalSignalInfo", 240, 3, 1, 0, 12, 485, 12, 0},
    {-1, 2190, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {INT_MAX, 1233, 0, (char *)"ReportingState", 4, 0, 4, 0, 2076, 132, 58, 0},
    {8, 2188, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 2190, 0, (char *)"LMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {INT_MAX, 2192, 0, (char *)"ReportingState", 4, 0, 4, 0, 2076, 132, 58, 0},
    {-1, 587, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {INT_MAX, 1233, 0, (char *)"CCBS-SubscriberStatus", 4, 0, 4, 0, 2076, 139, 58, 0},
    {INT_MAX, 2188, 0, (char *)"CCBS-SubscriberStatus", 4, 0, 4, 0, 2076, 139, 58, 0},
    {-1, 2190, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {INT_MAX, 2188, 0, (char *)"CCBS-SubscriberStatus", 4, 0, 4, 0, 2076, 139, 58, 0},
    {-1, 2190, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {-1, 19, 1047, (char *)"EventReportData", 32, 2, 1, 0, 12, 536, 12, 0},
    {INT_MAX, 1233, 0, (char *)"MonitoringMode", 4, 0, 4, 0, 2076, 147, 58, 0},
    {INT_MAX, 1233, 0, (char *)"CallOutcome", 4, 0, 4, 0, 2076, 154, 58, 0},
    {INT_MAX, 2188, 0, (char *)"MonitoringMode", 4, 0, 4, 0, 2076, 147, 58, 0},
    {INT_MAX, 2190, 0, (char *)"CallOutcome", 4, 0, 4, 0, 2076, 154, 58, 0},
    {-1, 2192, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {-1, 19, 1029, (char *)"CallReportData", 40, 3, 1, 0, 12, 538, 12, 0},
    {8, 2188, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2190, 1047, (char *)"EventReportData", 32, 2, 1, 0, 12, 536, 12, 0},
    {-1, 2192, 1029, (char *)"CallReportData", 40, 3, 1, 0, 12, 538, 12, 0},
    {-1, 587, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {-1, 2188, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {-1, 2184, 0, (char *)"CCBS-Index", 2, 0, 2, 0, 8, 0, 55, 0},
    {1, 1145, 0, (char *)"TeleserviceCode", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 2192, 0, (char *)"BearerServiceCode", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 587, 0, (char *)"TeleserviceCode", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2, 2489, (char *)"BasicServiceCode", 6, 2, 2, 2, 8, 541, 13, 0},
    {-1, 2188, 0, (char *)"CCBS-Index", 2, 0, 2, 0, 8, 0, 55, 0},
    {9, 2190, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {21, 2192, 0, (char *)"ISDN-SubaddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 587, 2489, (char *)"BasicServiceCode", 6, 2, 2, 2, 8, 541, 13, 0},
    {-1, 19, 1057, (char *)"CCBS-Feature", 46, 4, 1, 0, 12, 543, 12, 0},
    {8, 2188, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2190, 2494, (char *)"ExternalSignalInfo", 240, 3, 1, 0, 12, 485, 12, 0},
    {-1, 2192, 1057, (char *)"CCBS-Feature", 46, 4, 1, 0, 12, 543, 12, 0},
    {9, 587, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2408, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {1, 2437, 0, (char *)"AlertingPattern", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2431, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {INT_MAX, 1233, 0, (char *)"RUF-Outcome", 4, 0, 4, 0, 2076, 162, 58, 0},
    {INT_MAX, 2188, 0, (char *)"RUF-Outcome", 4, 0, 4, 0, 2076, 162, 58, 0},
    {-1, 2190, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {-1, 2184, 0, (char *)"NoReplyConditionTime", 2, 0, 2, 0, 8, 0, 55, 0},
    {20, 2408, 0, (char *)"AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {21, 2431, 0, (char *)"ISDN-SubaddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2437, 0, (char *)"NoReplyConditionTime", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 2410, 0, (char *)"EMLPP-Priority", 2, 0, 2, 0, 8, 0, 55, 0},
    {20, 2408, 0, (char *)"AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {21, 2431, 0, (char *)"ISDN-SubaddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2437, 0, (char *)"NoReplyConditionTime", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 2410, 0, (char *)"EMLPP-Priority", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 19, 85, (char *)"ForwardingInfo", 16, 2, 1, 0, 12, 547, 12, 0},
    {-1, 19, 85, (char *)"CallBarringInfo", 16, 2, 1, 0, 12, 549, 12, 0},
    {1, 1145, 0, (char *)"SS-Status", 2, 0, 2, 2, 24, 0, 21, 0},
    {2, 1233, 0, (char *)"CliRestrictionOption", 4, 0, 4, 0, 24, 173, 58, 0},
    {1, 1233, 0, (char *)"OverrideCategory", 4, 0, 4, 0, 24, 178, 58, 0},
    {2, 2192, 0, (char *)"CliRestrictionOption", 4, 0, 4, 0, 24, 173, 58, 0},
    {1, 2190, 0, (char *)"OverrideCategory", 4, 0, 4, 0, 24, 178, 58, 0},
    {-1, 2, 2680, (char *)"SS-SubscriptionOption", 8, 2, 2, 4, 8, 551, 13, 0},
    {1, 2408, 0, (char *)"SS-Status", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2437, 1057, (char *)"CCBS-Feature", 46, 4, 1, 0, 12, 543, 12, 0},
    {2, 19, 2685, (char *)"SS-Data", 80, 6, 1, 0, 2076, 553, 12, 0},
    {-1, 2188, 85, (char *)"ForwardingInfo", 16, 2, 1, 0, 12, 547, 12, 0},
    {-1, 2190, 85, (char *)"CallBarringInfo", 16, 2, 1, 0, 12, 549, 12, 0},
    {2, 587, 2685, (char *)"SS-Data", 80, 6, 1, 0, 2076, 553, 12, 0},
    {-1, 2, 1193, (char *)"SS-Info", 88, 3, 2, 8, 8, 559, 13, 0},
    {-1, 2188, 85, (char *)"ForwardingInfo", 16, 2, 1, 0, 12, 547, 12, 0},
    {-1, 2190, 85, (char *)"CallBarringInfo", 16, 2, 1, 0, 12, 549, 12, 0},
    {2, 587, 2685, (char *)"SS-Data", 80, 6, 1, 0, 2076, 553, 12, 0},
    {-1, 2188, 85, (char *)"ForwardingInfo", 16, 2, 1, 0, 12, 547, 12, 0},
    {-1, 2190, 85, (char *)"CallBarringInfo", 16, 2, 1, 0, 12, 549, 12, 0},
    {2, 587, 2685, (char *)"SS-Data", 80, 6, 1, 0, 2076, 553, 12, 0},
    {-1, 2188, 85, (char *)"ForwardingInfo", 16, 2, 1, 0, 12, 547, 12, 0},
    {-1, 2190, 85, (char *)"CallBarringInfo", 16, 2, 1, 0, 12, 549, 12, 0},
    {2, 587, 2685, (char *)"SS-Data", 80, 6, 1, 0, 2076, 553, 12, 0},
    {-1, 2188, 85, (char *)"ForwardingInfo", 16, 2, 1, 0, 12, 547, 12, 0},
    {-1, 2190, 85, (char *)"CallBarringInfo", 16, 2, 1, 0, 12, 549, 12, 0},
    {2, 587, 2685, (char *)"SS-Data", 80, 6, 1, 0, 2076, 553, 12, 0},
    {1, 2408, 0, (char *)"SS-Status", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 2437, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {21, 2433, 0, (char *)"ISDN-SubaddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 2431, 0, (char *)"ForwardingOptions", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2410, 0, (char *)"NoReplyConditionTime", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 19, 2745, (char *)"ForwardingFeature", 54, 6, 1, 0, 12, 562, 12, 0},
    {13, 19, 0, (char *)"ForwardingFeatureList", 8, 56, 2, 8, 24, 615, 18, 0},
    {1, 2408, 0, (char *)"SS-Status", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 19, 2801, (char *)"CallBarringFeature", 12, 2, 1, 0, 12, 568, 12, 0},
    {13, 19, 0, (char *)"CallBarringFeatureList", 8, 16, 2, 8, 24, 618, 18, 0},
    {-1, 2188, 0, (char *)"EMLPP-Priority", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 2190, 0, (char *)"EMLPP-Priority", 2, 0, 2, 0, 8, 0, 55, 0},
    {5, 2192, 0, (char *)"CCBS-FeatureList", 8, 48, 2, 8, 24, 563, 18, 0},
    {3, 19, 2813, (char *)"GenericServiceInfo", 24, 5, 1, 0, 2076, 570, 12, 0},
    {5, 19, 0, (char *)"CCBS-FeatureList", 8, 48, 2, 8, 24, 563, 18, 0},
    {1, 2188, 0, (char *)"SS-Status", 2, 0, 2, 2, 24, 0, 21, 0},
    {13, 2192, 0, (char *)"BasicServiceGroupList", 8, 8, 2, 8, 24, 558, 18, 0},
    {13, 587, 0, (char *)"ForwardingFeatureList", 8, 56, 2, 8, 24, 615, 18, 0},
    {3, 2408, 2813, (char *)"GenericServiceInfo", 24, 5, 1, 0, 2076, 570, 12, 0},
    {1, 2188, 0, (char *)"SS-Status", 2, 0, 2, 2, 24, 0, 21, 0},
    {13, 2192, 0, (char *)"BasicServiceGroupList", 8, 8, 2, 8, 24, 558, 18, 0},
    {13, 587, 0, (char *)"ForwardingFeatureList", 8, 56, 2, 8, 24, 615, 18, 0},
    {3, 2408, 2813, (char *)"GenericServiceInfo", 24, 5, 1, 0, 2076, 570, 12, 0},
    {1, 1145, 0, (char *)"USSD-DataCodingScheme", 2, 0, 2, 2, 24, 0, 21, 0},
    {160, 1145, 0, (char *)"USSD-String", 2, 0, 2, 2, 24, 0, 21, 0},
    {30, 19, 0, (char *)"SS-List", 8, 8, 2, 8, 24, 388, 18, 0},
    {13, 19, 0, (char *)"BasicServiceGroupList", 8, 8, 2, 8, 24, 558, 18, 0},
    {8, 2188, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 2190, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 2192, 0, (char *)"SS-Code", 2, 0, 2, 2, 24, 0, 21, 0},
    {2, 587, 0, (char *)"SS-EventSpecification", 8, 24, 2, 8, 24, 347, 18, 0},
    {-1, 2408, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {2, 19, 0, (char *)"SS-EventSpecification", 8, 24, 2, 8, 24, 347, 18, 0},
    {32, 2487, 0, (char *)"ServiceIndicator", 16, 0, 2, 8, 24, 182, 3, 0},
    {-1, 2188, 1057, (char *)"CCBS-Feature", 46, 4, 1, 0, 12, 543, 12, 0},
    {9, 2190, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {32, 2192, 0, (char *)"ServiceIndicator", 16, 0, 2, 8, 24, 182, 3, 0},
    {-1, 587, 2494, (char *)"ExternalSignalInfo", 240, 3, 1, 0, 12, 485, 12, 0},
    {-1, 2408, 2494, (char *)"ExternalSignalInfo", 240, 3, 1, 0, 12, 485, 12, 0},
    {-1, 19, 2845, (char *)"CCBS-Data", 560, 5, 1, 0, 12, 575, 12, 0},
    {1, 2188, 0, (char *)"SS-Code", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2190, 2845, (char *)"CCBS-Data", 560, 5, 1, 0, 12, 575, 12, 0},
    {-1, 2188, 1057, (char *)"CCBS-Feature", 46, 4, 1, 0, 12, 543, 12, 0},
    {1, 2188, 0, (char *)"SS-Code", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2190, 0, (char *)"CCBS-Index", 2, 0, 2, 0, 8, 0, 55, 0},
    {1, 2188, 0, (char *)"SS-Code", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 2190, 0, (char *)"SS-Status", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 1145, 0, (char *)"TMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {8, 2188, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 2190, 0, (char *)"TMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {8, 1145, 0, (char *)"HLR-Id", 2, 0, 2, 2, 24, 0, 21, 0},
    {50, 19, 0, (char *)"HLR-List", 8, 16, 2, 8, 24, 660, 18, 0},
    {7, 1145, 0, (char *)"GlobalCellId", 2, 0, 2, 2, 24, 0, 21, 0},
    {7, 1233, 0, (char *)"NetworkResource", 4, 0, 4, 0, 24, 186, 58, 0},
    {-1, 19, 2867, (char *)"EMLPP-Info", 32, 3, 1, 0, 12, 580, 12, 0},
    {16, 2188, 0, (char *)"SupportedCamelPhases", 16, 0, 2, 8, 24, 109, 3, 0},
    {-1, 19, 1883, (char *)"VLR-Capability", 48, 2, 1, 0, 12, 583, 12, 0},
    {9, 2190, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 2520, 0, (char *)"LMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2431, 1883, (char *)"VLR-Capability", 48, 2, 1, 0, 12, 583, 12, 0},
    {-1, 19, 373, (char *)"IMSI-WithLMSI", 16, 2, 0, 0, 12, 585, 12, 0},
    {-1, 2188, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2190, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {16, 1145, 0, (char *)"RAND", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 1145, 0, (char *)"SRES", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 19, 1219, (char *)"AuthenticationSet", 34, 3, 0, 0, 12, 587, 12, 0},
    {5, 19, 0, (char *)"AuthenticationSetList", 8, 40, 2, 8, 24, 675, 18, 0},
    {16, 1145, 0, (char *)"GSN-Address", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 1145, 0, (char *)"Category", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 1233, 0, (char *)"SubscriberStatus", 4, 0, 4, 0, 24, 196, 58, 0},
    {32, 2487, 0, (char *)"ODB-GeneralData", 16, 0, 2, 8, 24, 200, 3, 0},
    {32, 2487, 0, (char *)"ODB-HPLMN-Data", 16, 0, 2, 8, 24, 217, 3, 0},
    {-1, 19, 2879, (char *)"ODB-Data", 64, 3, 1, 0, 12, 590, 12, 0},
    {-1, 2188, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {-1, 19, 2893, (char *)"SS-CamelData", 56, 3, 1, 0, 12, 593, 12, 0},
    {-1, 19, 1961, (char *)"SS-CSI", 88, 2, 1, 0, 12, 596, 12, 0},
    {1, 2188, 2562, (char *)"O-CSI", 48, 3, 1, 0, 2076, 500, 12, 0},
    {-1, 2190, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {-1, 2192, 1961, (char *)"SS-CSI", 88, 2, 1, 0, 12, 596, 12, 0},
    {1, 19, 1029, (char *)"VlrCamelSubscriptionInfo", 168, 3, 1, 0, 2076, 598, 12, 0},
    {50, 2190, 0, (char *)"GPRSDataList", 8, 128, 2, 8, 24, 721, 18, 0},
    {-1, 2192, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {-1, 19, 2905, (char *)"GPRSSubscriptionData", 40, 3, 1, 0, 12, 601, 12, 0},
    {8, 2188, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 2190, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 2192, 0, (char *)"Category", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 587, 0, (char *)"SubscriberStatus", 4, 0, 4, 0, 24, 196, 58, 0},
    {50, 2408, 0, (char *)"BearerServiceList", 8, 8, 2, 8, 24, 324, 18, 0},
    {20, 2431, 0, (char *)"TeleserviceList", 8, 8, 2, 8, 24, 325, 18, 0},
    {30, 2410, 0, (char *)"Ext-SS-InfoList", 8, 64, 2, 8, 24, 739, 18, 0},
    {-1, 2433, 2879, (char *)"ODB-Data", 64, 3, 1, 0, 12, 590, 12, 0},
    {-1, 2435, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {10, 2520, 0, (char *)"ZoneCodeList", 8, 8, 2, 8, 24, 763, 18, 0},
    {50, 2522, 0, (char *)"VBSDataList", 8, 40, 2, 8, 24, 826, 18, 0},
    {50, 2524, 0, (char *)"VGCSDataList", 8, 32, 2, 8, 24, 828, 18, 0},
    {1, 2526, 1029, (char *)"VlrCamelSubscriptionInfo", 168, 3, 1, 0, 2076, 598, 12, 0},
    {-1, 2528, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {-1, 2530, 1021, (char *)"NAEA-PreferredCI", 32, 2, 1, 0, 12, 526, 12, 0},
    {-1, 2532, 2905, (char *)"GPRSSubscriptionData", 40, 3, 1, 0, 12, 601, 12, 0},
    {-1, 2919, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2184, 0, (char *)"ContextId", 2, 0, 2, 0, 8, 0, 55, 0},
    {2, 1145, 0, (char *)"PDP-Type", 2, 0, 2, 2, 24, 0, 21, 0},
    {16, 1145, 0, (char *)"PDP-Address", 2, 0, 2, 2, 24, 0, 21, 0},
    {3, 1145, 0, (char *)"QoS-Subscribed", 2, 0, 2, 2, 24, 0, 21, 0},
    {64, 2921, 22, (char *)"APN", 1, 0, 2, 0, 24, 0, 24, 0},
    {2, 2532, 0, (char *)"PDP-Type", 2, 0, 2, 2, 24, 0, 21, 0},
    {16, 2923, 0, (char *)"PDP-Address", 2, 0, 2, 2, 24, 0, 21, 0},
    {3, 2925, 0, (char *)"QoS-Subscribed", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2927, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {64, 2929, 22, (char *)"APN", 1, 0, 2, 0, 24, 0, 24, 0},
    {-1, 2931, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {-1, 19, 2933, (char *)"PDP-Context", 128, 7, 1, 0, 12, 604, 12, 0},
    {50, 19, 0, (char *)"GPRSDataList", 8, 128, 2, 8, 24, 721, 18, 0},
    {50, 19, 0, (char *)"BearerServiceList", 8, 8, 2, 8, 24, 324, 18, 0},
    {20, 19, 0, (char *)"TeleserviceList", 8, 8, 2, 8, 24, 325, 18, 0},
    {-1, 2188, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {-1, 19, 2965, (char *)"Ext-ForwInfo", 40, 3, 1, 0, 12, 611, 12, 0},
    {-1, 19, 2977, (char *)"Ext-CallBarInfo", 40, 3, 1, 0, 12, 614, 12, 0},
    {-1, 2188, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {-1, 19, 2562, (char *)"CUG-Info", 48, 3, 1, 0, 12, 617, 12, 0},
    {5, 1145, 0, (char *)"Ext-SS-Status", 2, 0, 2, 2, 24, 0, 21, 0},
    {5, 2408, 0, (char *)"Ext-SS-Status", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2437, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {-1, 19, 2989, (char *)"Ext-SS-Data", 56, 5, 1, 0, 12, 620, 12, 0},
    {-1, 2188, 2965, (char *)"Ext-ForwInfo", 40, 3, 1, 0, 12, 611, 12, 0},
    {-1, 2190, 2977, (char *)"Ext-CallBarInfo", 40, 3, 1, 0, 12, 614, 12, 0},
    {-1, 2192, 2562, (char *)"CUG-Info", 48, 3, 1, 0, 12, 617, 12, 0},
    {-1, 587, 2989, (char *)"Ext-SS-Data", 56, 5, 1, 0, 12, 620, 12, 0},
    {-1, 2408, 2867, (char *)"EMLPP-Info", 32, 3, 1, 0, 12, 580, 12, 0},
    {-1, 2, 3017, (char *)"Ext-SS-Info", 64, 5, 2, 8, 8, 625, 13, 0},
    {30, 19, 0, (char *)"Ext-SS-InfoList", 8, 64, 2, 8, 24, 739, 18, 0},
    {5, 1145, 0, (char *)"Ext-ForwOptions", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2184, 0, (char *)"Ext-NoRepCondTime", 2, 0, 2, 0, 8, 0, 55, 0},
    {5, 2408, 0, (char *)"Ext-SS-Status", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 2437, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {21, 2433, 0, (char *)"ISDN-SubaddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {5, 2431, 0, (char *)"Ext-ForwOptions", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2410, 0, (char *)"Ext-NoRepCondTime", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 2435, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {-1, 19, 3028, (char *)"Ext-ForwFeature", 96, 7, 1, 0, 12, 630, 12, 0},
    {32, 19, 0, (char *)"Ext-ForwFeatureList", 8, 96, 2, 8, 24, 749, 18, 0},
    {5, 2408, 0, (char *)"Ext-SS-Status", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 19, 3080, (char *)"Ext-CallBarringFeature", 48, 3, 1, 0, 12, 637, 12, 0},
    {32, 19, 0, (char *)"Ext-CallBarFeatureList", 8, 48, 2, 8, 24, 752, 18, 0},
    {-1, 2184, 0, (char *)"CUG-Index", 2, 0, 2, 0, 8, 0, 55, 0},
    {2, 1233, 0, (char *)"IntraCUG-Options", 4, 0, 4, 0, 24, 223, 58, 0},
    {-1, 2188, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {-1, 19, 3096, (char *)"CUG-Subscription", 48, 5, 1, 0, 12, 640, 12, 0},
    {10, 19, 0, (char *)"CUG-SubscriptionList", 8, 48, 2, 8, 24, 757, 18, 0},
    {1, 1145, 0, (char *)"InterCUG-Restrictions", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 19, 3118, (char *)"CUG-Feature", 48, 4, 1, 0, 12, 645, 12, 0},
    {32, 19, 0, (char *)"CUG-FeatureList", 8, 48, 2, 8, 24, 760, 18, 0},
    {32, 19, 0, (char *)"Ext-BasicServiceGroupList", 8, 16, 2, 8, 24, 398, 18, 0},
    {2, 1145, 0, (char *)"ZoneCode", 2, 0, 2, 2, 24, 0, 21, 0},
    {10, 19, 0, (char *)"ZoneCodeList", 8, 8, 2, 8, 24, 763, 18, 0},
    {3, 1233, 0, (char *)"RegionalSubscriptionResponse", 4, 0, 4, 0, 24, 228, 58, 0},
    {20, 2190, 0, (char *)"TeleserviceList", 8, 8, 2, 8, 24, 325, 18, 0},
    {50, 2192, 0, (char *)"BearerServiceList", 8, 8, 2, 8, 24, 324, 18, 0},
    {30, 587, 0, (char *)"SS-List", 8, 8, 2, 8, 24, 388, 18, 0},
    {32, 2408, 0, (char *)"ODB-GeneralData", 16, 0, 2, 8, 24, 200, 3, 0},
    {3, 2437, 0, (char *)"RegionalSubscriptionResponse", 4, 0, 4, 0, 24, 228, 58, 0},
    {16, 2431, 0, (char *)"SupportedCamelPhases", 16, 0, 2, 8, 24, 109, 3, 0},
    {-1, 2410, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {8, 2188, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {70, 2190, 0, (char *)"BasicServiceList", 8, 16, 2, 8, 24, 398, 18, 0},
    {30, 2192, 0, (char *)"SS-List", 8, 8, 2, 8, 24, 388, 18, 0},
    {-1, 2408, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {2, 2437, 0, (char *)"ZoneCode", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2410, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2433, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2435, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2431, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {-1, 2522, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {70, 19, 0, (char *)"BasicServiceList", 8, 16, 2, 8, 24, 398, 18, 0},
    {3, 2188, 0, (char *)"RegionalSubscriptionResponse", 4, 0, 4, 0, 24, 228, 58, 0},
    {10, 19, 0, (char *)"SS-EventList", 8, 8, 2, 8, 24, 388, 18, 0},
    {INT_MAX, 1233, 0, (char *)"O-BcsmTriggerDetectionPoint", 4, 0, 4, 0, 2076, 234, 58, 0},
    {1, 1233, 0, (char *)"MatchType", 4, 0, 4, 0, 24, 240, 58, 0},
    {1, 2188, 0, (char *)"MatchType", 4, 0, 4, 0, 24, 240, 58, 0},
    {10, 2190, 0, (char *)"DestinationNumberList", 8, 16, 2, 8, 24, 337, 18, 0},
    {3, 2192, 0, (char *)"DestinationNumberLengthList", 8, 8, 2, 8, 24, 804, 18, 0},
    {-1, 19, 1893, (char *)"DestinationNumberCriteria", 24, 3, 1, 0, 12, 649, 12, 0},
    {1, 1233, 0, (char *)"CallTypeCriteria", 4, 0, 4, 0, 24, 244, 58, 0},
    {-1, 2188, 1893, (char *)"DestinationNumberCriteria", 24, 3, 1, 0, 12, 649, 12, 0},
    {5, 2190, 0, (char *)"BasicServiceCriteria", 8, 16, 2, 8, 24, 398, 18, 0},
    {1, 2192, 0, (char *)"CallTypeCriteria", 4, 0, 4, 0, 24, 244, 58, 0},
    {-1, 19, 1029, (char *)"O-BcsmCamelTDP-Criteria", 48, 3, 1, 0, 12, 652, 12, 0},
    {9, 2188, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {INT_MAX, 2190, 0, (char *)"DefaultCallHandling", 4, 0, 4, 0, 2076, 125, 58, 0},
    {-1, 2192, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {-1, 587, 1029, (char *)"O-BcsmCamelTDP-Criteria", 48, 3, 1, 0, 12, 652, 12, 0},
    {1, 19, 3142, (char *)"O-BcsmCamelTDPData", 104, 6, 1, 0, 2076, 655, 12, 0},
    {10, 19, 0, (char *)"O-BcsmCamelTDPDataList", 8, 104, 2, 8, 24, 801, 18, 0},
    {10, 19, 0, (char *)"DestinationNumberList", 8, 16, 2, 8, 24, 337, 18, 0},
    {-1, 2184, 0, NULL, 2, 0, 2, 0, 8, 0, 55, 0},
    {3, 19, 0, (char *)"DestinationNumberLengthList", 8, 8, 2, 8, 24, 804, 18, 0},
    {5, 19, 0, (char *)"BasicServiceCriteria", 8, 16, 2, 8, 24, 398, 18, 0},
    {8, 2188, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {16, 2190, 0, (char *)"GSN-Address", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2192, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {16, 2188, 0, (char *)"GSN-Address", 2, 0, 2, 2, 24, 0, 21, 0},
    {16, 2190, 0, (char *)"GSN-Address", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2192, 0, (char *)"AbsentSubscriberDiagnosticSM", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 587, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {8, 2188, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 2190, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {16, 2192, 0, (char *)"GSN-Address", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 587, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {-1, 2188, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {8, 2188, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {16, 2190, 0, (char *)"GSN-Address", 2, 0, 2, 2, 24, 0, 21, 0},
    {16, 2192, 0, (char *)"GSN-Address", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 587, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {-1, 2188, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {-1, 2431, 1883, (char *)"VLR-Capability", 48, 2, 1, 0, 12, 583, 12, 0},
    {3, 1145, 0, (char *)"GroupId", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 19, 1929, (char *)"VoiceBroadcastData", 40, 3, 1, 0, 12, 661, 12, 0},
    {50, 19, 0, (char *)"VBSDataList", 8, 40, 2, 8, 24, 826, 18, 0},
    {-1, 19, 77, (char *)"VoiceGroupCallData", 32, 2, 1, 0, 12, 664, 12, 0},
    {50, 19, 0, (char *)"VGCSDataList", 8, 32, 2, 8, 24, 828, 18, 0},
    {-1, 2188, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2190, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2192, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {-1, 19, 1029, (char *)"RequestedInfo", 32, 3, 1, 0, 12, 666, 12, 0},
    {8, 2188, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 2190, 0, (char *)"LMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2192, 1029, (char *)"RequestedInfo", 32, 3, 1, 0, 12, 666, 12, 0},
    {-1, 587, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {8, 2188, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 2190, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2, 1257, (char *)"SubscriberIdentity", 14, 2, 2, 2, 8, 669, 13, 0},
    {-1, 2188, 1257, (char *)"SubscriberIdentity", 14, 2, 2, 2, 8, 669, 13, 0},
    {-1, 2190, 1029, (char *)"RequestedInfo", 32, 3, 1, 0, 12, 666, 12, 0},
    {9, 587, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2192, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {3, 1233, 0, (char *)"RoamingNotAllowedCause", 4, 0, 4, 0, 24, 248, 58, 0},
    {1, 1233, 0, (char *)"CallBarringCause", 4, 0, 4, 0, 24, 252, 58, 0},
    {-1, 2190, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {1, 19, 3168, (char *)"ExtensibleCallBarredParam", 40, 3, 1, 0, 2076, 671, 12, 0},
    {7, 1233, 0, (char *)"CUG-RejectCause", 4, 0, 4, 0, 24, 256, 58, 0},
    {1, 2190, 0, (char *)"SS-Code", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 2408, 0, (char *)"SS-Status", 2, 0, 2, 2, 24, 0, 21, 0},
    {6, 1233, 0, (char *)"SM-EnumeratedDeliveryFailureCause", 4, 0, 4, 0, 24, 262, 58, 0},
    {-1, 2188, 0, (char *)"AbsentSubscriberDiagnosticSM", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 19, 1998, (char *)"ExtensibleSystemFailureParam", 32, 2, 1, 0, 12, 674, 12, 0},
    {INT_MAX, 1233, 0, (char *)"UnknownSubscriberDiagnostic", 4, 0, 4, 0, 2076, 271, 58, 0},
    {INT_MAX, 1233, 0, (char *)"AbsentSubscriberReason", 4, 0, 4, 0, 2076, 278, 58, 0},
    {INT_MAX, 2188, 0, (char *)"AbsentSubscriberReason", 4, 0, 4, 0, 2076, 278, 58, 0},
    {-1, 2188, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2190, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {2, 1145, 0, (char *)"TraceReference", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2184, 0, (char *)"TraceType", 2, 0, 2, 0, 8, 0, 55, 0},
    {8, 2188, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {2, 2190, 0, (char *)"TraceReference", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2192, 0, (char *)"TraceType", 2, 0, 2, 0, 8, 0, 55, 0},
    {20, 587, 0, (char *)"AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2408, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {-1, 2188, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {8, 2188, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {2, 2190, 0, (char *)"TraceReference", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2192, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {-1, 2188, 1047, (char *)"ExtensionContainer", 24, 2, 1, 0, 12, 462, 12, 0},
    {20, 2188, 0, (char *)"_octet1", 2, 0, 2, 2, 56, 0, 21, 0},
    {20, 2190, 0, (char *)"", 2, 0, 2, 2, 56, 0, 21, 0},
    {-1, 2188, 1047, (char *)"_seq2", 46, 2, 1, 0, 44, 676, 12, 0},
    {-1, 2190, 0, (char *)"_seq3", 1, 0, 0, 0, 44, 387, 12, 0},
    {-1, 2192, 0, (char *)"", 1, 0, 0, 0, 44, 387, 12, 0},
    {2, 1233, 0, (char *)"_enum1", 4, 0, 4, 0, 56, 23, 58, 0},
    {-1, 587, 2161, (char *)"_seq4", 4, 1, 0, 0, 44, 678, 12, 0},
    {-1, 2188, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2190, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {1, 2192, 0, (char *)"_enum2", 4, 0, 4, 0, 56, 28, 58, 0},
    {6, 587, 0, (char *)"_enum3", 4, 0, 4, 0, 56, 32, 58, 0},
    {-1, 2, 2175, (char *)"_choice6", 8, 4, 2, 4, 40, 679, 13, 0},
    {-1, 2408, 2165, (char *)"_seq5", 8, 1, 0, 0, 44, 683, 12, 0},
    {1, 1233, 0, (char *)"_enum4", 4, 0, 4, 0, 56, 41, 58, 0},
    {-1, 2437, 2161, (char *)"_seq6", 4, 1, 0, 0, 44, 684, 12, 0},
    {20, 2188, 0, (char *)"", 2, 0, 2, 2, 56, 0, 21, 0},
    {20, 2190, 0, (char *)"", 2, 0, 2, 2, 56, 0, 21, 0},
    {2, 1233, 0, (char *)"", 4, 0, 4, 0, 56, 23, 58, 0},
    {-1, 2188, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2190, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {1, 2192, 0, (char *)"", 4, 0, 4, 0, 56, 28, 58, 0},
    {6, 587, 0, (char *)"", 4, 0, 4, 0, 56, 32, 58, 0},
    {-1, 2, 2175, (char *)"", 8, 4, 2, 4, 40, 685, 13, 0},
    {-1, 2188, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2190, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {1, 2192, 0, (char *)"", 4, 0, 4, 0, 56, 28, 58, 0},
    {6, 587, 0, (char *)"", 4, 0, 4, 0, 56, 32, 58, 0},
    {1, 1233, 0, (char *)"", 4, 0, 4, 0, 56, 41, 58, 0}
};

static const struct efield _efieldarray[] = {
    {8, 278, -1, 286, 2},
    {8, 279, -1, 287, 2},
    {8, 280, -1, 288, 2},
    {8, 281, -1, 289, 2},
    {8, 282, -1, 290, 2},
    {8, 285, -1, 291, 2},
    {8, 0, -1, 292, 2},
    {2, 325, -1, 293, 2},
    {10, 326, -1, 294, 2},
    {20, 327, -1, 295, 2},
    {32, 328, -1, 296, 2},
    {36, 332, 0, 297, 3},
    {38, 333, 1, 298, 3},
    {48, 334, 2, 299, 3},
    {50, 335, 3, 300, 3},
    {56, 336, 4, 301, 3},
    {2, 337, -1, 302, 2},
    {16, 318, 0, 301, 3},
    {2, 338, 0, 303, 3},
    {16, 318, 1, 301, 3},
    {8, 318, 0, 301, 3},
    {2, 338, 0, 303, 3},
    {12, 339, 1, 304, 3},
    {13, 340, 2, 305, 3},
    {14, 341, 3, 306, 3},
    {15, 342, 4, 307, 3},
    {16, 343, 5, 308, 3},
    {24, 318, 6, 301, 3},
    {1, 344, 0, 309, 3},
    {2, 345, 1, 305, 3},
    {3, 346, 2, 310, 3},
    {8, 318, 3, 301, 3},
    {2, 350, -1, 311, 2},
    {14, 351, -1, 312, 2},
    {16, 352, -1, 313, 2},
    {40, 353, 0, 301, 3},
    {64, 354, 1, 314, 11},
    {66, 355, 2, 315, 11},
    {68, 356, 3, 316, 11},
    {2, 338, -1, 303, 2},
    {16, 365, -1, 317, 2},
    {80, 366, 0, 301, 3},
    {2, 371, -1, 318, 2},
    {26, 375, -1, 319, 2},
    {50, 376, -1, 320, 2},
    {256, 318, 0, 301, 3},
    {2, 376, -1, 320, 2},
    {208, 318, 0, 301, 3},
    {2, 371, -1, 318, 2},
    {26, 375, -1, 319, 2},
    {50, 376, -1, 320, 2},
    {252, 297, 0, 321, 3},
    {256, 318, 1, 301, 3},
    {2, 376, 0, 320, 3},
    {208, 318, 1, 301, 3},
    {2, 337, -1, 311, 2},
    {14, 347, -1, 313, 2},
    {36, 377, -1, 322, 2},
    {40, 379, 0, 323, 3},
    {48, 380, 1, 301, 3},
    {72, 381, 2, 314, 11},
    {73, 382, 3, 324, 11},
    {76, 383, 4, 325, 11},
    {80, 384, 5, 326, 11},
    {2, 337, 0, 327, 3},
    {16, 318, 1, 301, 3},
    {0, 337, -1, 311, 2},
    {12, 347, -1, 313, 2},
    {2, 337, 0, 327, 3},
    {16, 385, 1, 328, 3},
    {32, 318, 2, 301, 3},
    {2, 387, -1, 303, 2},
    {12, 386, -1, 329, 2},
    {16, 297, 0, 330, 3},
    {24, 318, 1, 301, 3},
    {8, 318, 0, 301, 3},
    {2, 406, -1, 311, 2},
    {16, 407, 0, 331, 3},
    {56, 408, 1, 332, 3},
    {60, 409, -1, 333, 2},
    {64, 410, 2, 334, 3},
    {66, 411, 3, 335, 3},
    {68, 412, -1, 336, 2},
    {80, 413, 4, 337, 3},
    {92, 414, 5, 338, 3},
    {96, 415, 6, 339, 3},
    {112, 416, 7, 340, 3},
    {352, 417, 8, 341, 3},
    {408, 418, 9, 342, 3},
    {416, 419, 10, 301, 3},
    {440, 420, 11, 343, 11},
    {444, 421, 12, 344, 11},
    {446, 422, 13, 345, 11},
    {2, 476, 0, 303, 3},
    {16, 444, 1, 346, 3},
    {256, 477, 2, 331, 3},
    {296, 478, 3, 347, 3},
    {304, 479, 4, 348, 3},
    {424, 480, 5, 349, 3},
    {432, 481, 6, 350, 3},
    {442, 482, 7, 351, 3},
    {444, 483, 8, 352, 3},
    {456, 484, 9, 301, 3},
    {480, 485, 10, 353, 11},
    {512, 486, 11, 354, 11},
    {2, 487, -1, 303, 2},
    {12, 488, -1, 355, 2},
    {24, 489, 0, 311, 3},
    {36, 490, 1, 356, 3},
    {48, 491, 2, 357, 3},
    {288, 492, 3, 340, 3},
    {528, 493, 4, 342, 3},
    {530, 494, 5, 336, 3},
    {542, 495, 6, 337, 3},
    {552, 496, 7, 334, 3},
    {560, 497, 8, 301, 3},
    {584, 498, 9, 343, 11},
    {588, 499, 10, 344, 11},
    {2, 337, -1, 358, 2},
    {16, 318, 0, 301, 3},
    {2, 500, -1, 337, 2},
    {12, 501, -1, 339, 2},
    {24, 502, -1, 359, 2},
    {96, 503, -1, 303, 2},
    {112, 504, 0, 331, 3},
    {152, 505, 1, 360, 3},
    {200, 506, 2, 301, 3},
    {224, 507, 3, 361, 11},
    {8, 318, 0, 301, 3},
    {8, 517, -1, 357, 2},
    {248, 518, -1, 362, 2},
    {488, 519, -1, 363, 2},
    {492, 520, -1, 364, 2},
    {504, 521, -1, 365, 2},
    {744, 522, 0, 366, 3},
    {984, 523, 1, 367, 3},
    {1224, 524, 2, 301, 3},
    {2, 525, -1, 368, 2},
    {16, 526, 0, 301, 3},
    {8, 527, 0, 369, 3},
    {248, 528, 1, 365, 3},
    {488, 529, 2, 301, 3},
    {8, 530, 0, 365, 3},
    {248, 531, 1, 301, 3},
    {2, 533, 0, 303, 3},
    {12, 534, 1, 356, 3},
    {20, 535, 2, 370, 3},
    {24, 536, 3, 301, 3},
    {4, 538, 0, 371, 3},
    {8, 539, 1, 301, 3},
    {2, 549, -1, 303, 2},
    {16, 550, 0, 372, 3},
    {48, 551, 1, 373, 3},
    {88, 552, 2, 301, 3},
    {8, 553, 0, 301, 3},
    {2, 564, -1, 303, 2},
    {16, 565, -1, 374, 2},
    {256, 566, -1, 375, 2},
    {302, 567, -1, 376, 2},
    {314, 568, 0, 377, 3},
    {316, 569, 1, 343, 3},
    {320, 570, 2, 301, 3},
    {4, 572, -1, 378, 2},
    {8, 573, 0, 301, 3},
    {2, 388, -1, 379, 2},
    {6, 558, 0, 350, 3},
    {12, 575, 1, 380, 3},
    {34, 576, 2, 381, 3},
    {58, 577, 3, 382, 3},
    {60, 578, 4, 383, 11},
    {2, 388, -1, 379, 2},
    {6, 558, 0, 350, 3},
    {12, 579, 1, 380, 3},
    {34, 580, 2, 381, 3},
    {58, 581, 3, 382, 3},
    {60, 582, 4, 383, 11},
    {8, 598, -1, 384, 2},
    {8, 599, -1, 385, 2},
    {8, 600, -1, 386, 2},
    {8, 601, -1, 384, 2},
    {8, 602, -1, 385, 2},
    {8, 603, -1, 386, 2},
    {8, 604, -1, 384, 2},
    {8, 605, -1, 385, 2},
    {8, 606, -1, 386, 2},
    {8, 607, -1, 384, 2},
    {8, 608, -1, 385, 2},
    {8, 609, -1, 386, 2},
    {2, 388, -1, 379, 2},
    {6, 558, 0, 350, 3},
    {2, 388, -1, 379, 2},
    {6, 558, 0, 350, 3},
    {2, 388, -1, 379, 2},
    {6, 558, 0, 350, 3},
    {2, 388, -1, 379, 2},
    {6, 558, 0, 350, 3},
    {2, 388, -1, 379, 2},
    {6, 558, 0, 350, 3},
    {8, 625, -1, 387, 2},
    {8, 626, -1, 388, 2},
    {8, 627, -1, 389, 2},
    {8, 628, -1, 390, 2},
    {8, 629, -1, 387, 2},
    {8, 630, -1, 388, 2},
    {8, 631, -1, 389, 2},
    {8, 632, -1, 390, 2},
    {2, 633, -1, 391, 2},
    {6, 634, -1, 392, 2},
    {168, 404, 0, 343, 11},
    {2, 633, -1, 391, 2},
    {6, 634, -1, 392, 2},
    {168, 404, 0, 343, 11},
    {2, 633, -1, 391, 2},
    {6, 634, -1, 392, 2},
    {168, 404, 0, 343, 11},
    {2, 633, -1, 391, 2},
    {6, 634, -1, 392, 2},
    {168, 404, 0, 343, 11},
    {0, 633, -1, 391, 2},
    {4, 634, -1, 392, 2},
    {2, 637, -1, 303, 2},
    {12, 638, -1, 311, 2},
    {24, 639, -1, 393, 2},
    {32, 640, 0, 394, 3},
    {40, 641, 1, 301, 3},
    {8, 318, 0, 301, 3},
    {2, 650, -1, 379, 2},
    {8, 651, 0, 395, 3},
    {2, 652, 0, 375, 3},
    {2, 653, -1, 379, 2},
    {6, 654, 0, 396, 3},
    {2, 655, -1, 379, 2},
    {6, 656, 0, 387, 3},
    {2, 658, -1, 303, 2},
    {2, 659, -1, 397, 2},
    {2, 338, -1, 303, 2},
    {12, 667, -1, 355, 2},
    {24, 337, -1, 398, 2},
    {36, 668, 0, 356, 3},
    {48, 318, 1, 301, 3},
    {72, 669, 2, 399, 11},
    {2, 337, -1, 400, 2},
    {16, 318, 0, 301, 3},
    {2, 338, -1, 303, 2},
    {2, 670, -1, 401, 2},
    {8, 318, 0, 301, 3},
    {0, 338, -1, 303, 2},
    {10, 337, -1, 398, 2},
    {1, 671, 0, 402, 3},
    {2, 672, 1, 403, 3},
    {8, 318, 2, 301, 3},
    {2, 338, -1, 303, 2},
    {16, 676, 0, 404, 3},
    {2, 338, -1, 303, 2},
    {12, 337, -1, 405, 2},
    {24, 677, -1, 406, 2},
    {48, 318, 0, 301, 3},
    {2, 337, -1, 400, 2},
    {16, 318, 0, 301, 3},
    {2, 662, 0, 407, 3},
    {12, 297, 1, 408, 3},
    {16, 400, 2, 409, 3},
    {2, 337, 0, 410, 3},
    {16, 400, 1, 409, 3},
    {0, 662, -1, 407, 2},
    {10, 337, -1, 411, 2},
    {24, 400, -1, 409, 2},
    {4, 693, 0, 303, 3},
    {14, 694, 1, 311, 3},
    {26, 695, 2, 412, 3},
    {32, 696, 3, 413, 3},
    {40, 697, 4, 414, 3},
    {48, 698, 5, 415, 3},
    {56, 699, 6, 416, 3},
    {64, 700, 7, 417, 3},
    {128, 701, 8, 418, 3},
    {136, 702, 9, 419, 3},
    {144, 703, 10, 420, 3},
    {152, 704, 11, 421, 3},
    {160, 705, 12, 422, 3},
    {328, 706, 13, 301, 3},
    {352, 707, 14, 353, 11},
    {384, 708, 15, 423, 11},
    {424, 709, 16, 424, 11},
    {8, 766, 0, 415, 3},
    {16, 767, 1, 414, 3},
    {24, 768, 2, 349, 3},
    {32, 769, 3, 425, 3},
    {48, 770, 4, 426, 3},
    {56, 771, 5, 427, 3},
    {72, 772, 6, 301, 3},
    {2, 773, -1, 303, 2},
    {16, 774, 0, 428, 3},
    {24, 775, 1, 349, 3},
    {32, 776, 2, 418, 3},
    {34, 777, 3, 429, 3},
    {38, 778, 4, 430, 3},
    {39, 779, 5, 431, 3},
    {40, 780, 6, 432, 3},
    {48, 781, 7, 301, 3},
    {72, 782, 8, 433, 11},
    {4, 784, 0, 426, 3},
    {8, 318, 1, 301, 3},
    {2, 807, -1, 303, 2},
    {12, 808, 0, 434, 3},
    {32, 809, 1, 301, 3},
    {2, 810, -1, 406, 2},
    {20, 811, 0, 434, 3},
    {38, 812, 1, 435, 3},
    {40, 813, 2, 301, 3},
    {2, 814, -1, 303, 2},
    {12, 815, 0, 436, 3},
    {24, 816, 1, 434, 3},
    {48, 817, 2, 301, 3},
    {8, 818, 0, 301, 3},
    {2, 819, -1, 303, 2},
    {12, 820, 0, 406, 3},
    {30, 821, 1, 434, 3},
    {48, 822, 2, 301, 3},
    {8, 823, 0, 301, 3},
    {2, 337, -1, 400, 2},
    {16, 661, 0, 437, 3},
    {2, 338, -1, 303, 2},
    {12, 357, 0, 356, 3},
    {24, 318, 1, 301, 3},
    {48, 824, 2, 399, 11},
    {2, 337, -1, 400, 2},
    {14, 297, 0, 438, 3},
    {16, 318, 1, 301, 3},
    {2, 834, -1, 303, 2},
    {12, 835, 0, 356, 3},
    {24, 836, -1, 439, 2},
    {56, 837, 1, 301, 3},
    {8, 467, -1, 348, 2},
    {128, 318, 0, 301, 3},
    {2, 841, -1, 440, 2},
    {16, 842, -1, 439, 2},
    {48, 843, -1, 441, 2},
    {64, 844, 0, 301, 3},
    {8, 467, -1, 348, 2},
    {128, 318, 0, 301, 3},
    {4, 845, -1, 442, 2},
    {8, 318, 0, 301, 3},
    {8, 846, -1, 443, 2},
    {8, 848, -1, 444, 2},
    {4, 849, 0, 445, 3},
    {8, 318, 1, 301, 3},
    {2, 850, 0, 379, 3},
    {6, 558, 1, 350, 3},
    {12, 851, 2, 387, 3},
    {4, 852, -1, 446, 2},
    {8, 376, 0, 447, 3},
    {216, 318, 1, 301, 3},
    {2, 378, 0, 323, 3},
    {8, 318, 1, 301, 3},
    {32, 853, 2, 326, 11},
    {8, 663, -1, 448, 2},
    {8, 854, -1, 449, 2},
    {8, 318, 0, 301, 3},
    {8, 318, 0, 301, 3},
    {8, 318, 0, 301, 3},
    {8, 318, 0, 301, 3},
    {8, 318, 0, 301, 3},
    {32, 855, 1, 450, 11},
    {8, 318, 0, 301, 3},
    {8, 318, 0, 301, 3},
    {8, 318, 0, 301, 3},
    {8, 318, 0, 301, 3},
    {8, 318, 0, 301, 3},
    {8, 318, 0, 301, 3},
    {8, 318, 0, 301, 3},
    {8, 318, 0, 301, 3},
    {8, 318, 0, 301, 3},
    {32, 857, 1, 451, 11},
    {8, 318, 0, 301, 3},
    {32, 858, 1, 361, 11},
    {33, 859, 2, 452, 11},
    {8, 318, 0, 301, 3},
    {8, 318, 0, 301, 3},
    {8, 318, 0, 301, 3},
    {8, 318, 0, 301, 3},
    {8, 318, 0, 301, 3},
    {32, 297, 1, 453, 11},
    {8, 318, 0, 301, 3},
    {8, 318, 0, 301, 3},
    {8, 318, 0, 301, 3},
    {8, 318, 0, 301, 3},
    {2, 862, 0, 303, 3},
    {12, 863, -1, 454, 2},
    {16, 864, -1, 455, 2},
    {18, 865, 1, 456, 3},
    {40, 866, 2, 301, 3},
    {8, 867, 0, 301, 3},
    {2, 868, 0, 303, 3},
    {12, 869, -1, 454, 2},
    {16, 870, 1, 301, 3},
    {8, 871, 0, 301, 3},
    {4, 874, -1, 457, 2},
    {4, 875, -1, 458, 2},
    {4, 876, -1, 459, 2},
    {4, 878, -1, 460, 2},
    {4, 884, -1, 461, 2},
    {4, 886, -1, 462, 2},
    {2, 887, 0, 463, 3},
    {24, 888, 1, 464, 3},
    {0, 889, -1, 465, 2},
    {0, 894, -1, 466, 2},
    {4, 895, -1, 467, 2},
    {4, 896, -1, 468, 2},
    {4, 897, -1, 469, 2},
    {4, 898, -1, 470, 2},
    {0, 899, -1, 471, 2},
    {8, 263, -1, 472, 2},
    {8, 264, -1, 473, 2},
    {8, 265, -1, 474, 2},
    {8, 260, 0, 475, 3},
    {24, 261, 1, 476, 3},
    {32, 262, -1, 477, 3},
    {40, 266, -1, 478, 2},
    {8, 268, 0, 479, 3},
    {88, 311, -1, 480, 2},
    {2, 270, -1, 481, 2},
    {8, 268, 0, 479, 3},
    {88, 311, 1, 480, 3},
    {2, 272, -1, 482, 2},
    {8, 268, 0, 479, 3},
    {88, 311, 1, 480, 3},
    {2, 270, -1, 481, 2},
    {8, 272, -1, 482, 2},
    {16, 268, 0, 479, 3},
    {96, 311, 1, 480, 3},
    {8, 275, -1, 483, 2},
    {8, 268, -1, 484, 2},
    {2, 272, -1, 482, 2},
    {8, 276, 0, 465, 3},
    {2, 283, -1, 485, 2},
    {4, 284, 0, 486, 3},
    {8, 286, -1, 487, 2},
    {32, 287, 1, 488, 3},
    {0, 286, -1, 487, 2},
    {24, 287, -1, 488, 2},
    {2, 283, -1, 485, 2},
    {8, 289, 0, 489, 3},
    {2, 283, -1, 485, 2},
    {8, 286, -1, 490, 2},
    {32, 291, 0, 488, 3},
    {2, 283, -1, 491, 2},
    {2, 297, -1, 492, 2},
    {4, 299, -1, 493, 2},
    {4, 300, -1, 494, 2},
    {4, 301, -1, 495, 2},
    {4, 302, -1, 496, 2},
    {0, 298, -1, 485, 2},
    {4, 303, -1, 497, 2},
    {8, 305, -1, 498, 2},
    {8, 306, -1, 499, 2},
    {8, 307, -1, 500, 2},
    {8, 308, -1, 501, 2},
    {8, 309, -1, 502, 2},
    {2, 312, 0, 503, 3},
    {8, 0, -1, 504, 2},
    {24, 313, -1, 505, 66},
    {8, 316, 0, 506, 3},
    {16, 317, 1, 507, 3},
    {8, 319, -1, 508, 18},
    {24, 320, 0, 509, 3},
    {2, 358, -1, 355, 2},
    {2, 359, -1, 405, 2},
    {2, 361, -1, 510, 2},
    {14, 357, 0, 356, 3},
    {24, 318, 1, 301, 3},
    {48, 362, 2, 511, 11},
    {50, 363, 3, 512, 11},
    {2, 367, -1, 303, 2},
    {2, 368, -1, 356, 2},
    {2, 369, -1, 513, 2},
    {2, 370, -1, 514, 2},
    {2, 372, -1, 311, 2},
    {2, 373, -1, 515, 2},
    {2, 374, -1, 516, 2},
    {2, 389, -1, 517, 2},
    {8, 297, 0, 518, 3},
    {16, 318, 1, 301, 3},
    {2, 396, -1, 519, 2},
    {2, 397, -1, 520, 2},
    {4, 399, -1, 521, 2},
    {8, 376, -1, 522, 2},
    {216, 318, 0, 301, 3},
    {8, 401, -1, 427, 2},
    {24, 297, 0, 523, 3},
    {32, 318, 1, 301, 3},
    {2, 425, 0, 380, 3},
    {14, 426, 1, 381, 3},
    {38, 427, 2, 524, 3},
    {48, 428, 3, 301, 3},
    {8, 337, -1, 358, 2},
    {8, 429, -1, 359, 2},
    {8, 515, -1, 525, 2},
    {16, 318, 0, 301, 3},
    {40, 432, 1, 526, 11},
    {8, 802, -1, 527, 2},
    {16, 318, 0, 301, 3},
    {40, 434, 1, 526, 11},
    {8, 436, 0, 528, 3},
    {56, 437, 1, 360, 3},
    {104, 438, 2, 301, 3},
    {8, 429, 0, 359, 3},
    {80, 440, -1, 529, 2},
    {208, 441, 1, 301, 3},
    {8, 430, -1, 530, 2},
    {8, 443, -1, 531, 2},
    {2, 450, -1, 532, 2},
    {2, 451, -1, 533, 2},
    {2, 445, 0, 534, 3},
    {4, 453, 1, 535, 3},
    {14, 454, 2, 536, 3},
    {26, 455, 3, 537, 3},
    {38, 456, 4, 538, 3},
    {56, 457, 5, 301, 3},
    {4, 460, -1, 539, 2},
    {4, 461, -1, 540, 2},
    {4, 459, -1, 541, 2},
    {4, 462, -1, 542, 2},
    {8, 464, 0, 543, 3},
    {88, 465, 1, 544, 3},
    {96, 466, 2, 301, 3},
    {2, 469, -1, 545, 2},
    {8, 470, 0, 301, 3},
    {1, 472, 0, 361, 3},
    {2, 473, 1, 546, 3},
    {8, 474, 2, 301, 3},
    {4, 508, -1, 547, 2},
    {8, 509, -1, 548, 2},
    {12, 511, -1, 441, 2},
    {24, 512, -1, 549, 2},
    {32, 513, 0, 301, 3},
    {4, 540, 0, 371, 3},
    {8, 541, 1, 301, 3},
    {4, 545, 0, 550, 3},
    {8, 546, 1, 551, 3},
    {16, 547, 2, 301, 3},
    {2, 556, -1, 552, 2},
    {2, 557, -1, 293, 2},
    {2, 559, 0, 396, 3},
    {4, 560, 1, 553, 3},
    {16, 561, 2, 554, 3},
    {40, 562, 3, 339, 3},
    {2, 388, 0, 379, 3},
    {8, 616, -1, 389, 2},
    {2, 388, 0, 379, 3},
    {8, 619, -1, 555, 2},
    {4, 588, -1, 556, 2},
    {4, 589, -1, 557, 2},
    {2, 388, 0, 379, 3},
    {6, 591, 1, 387, 3},
    {12, 590, 2, 558, 3},
    {24, 636, 3, 388, 3},
    {32, 331, 4, 383, 11},
    {34, 592, 5, 375, 11},
    {8, 594, -1, 384, 2},
    {8, 595, -1, 385, 2},
    {8, 596, -1, 386, 2},
    {2, 558, 0, 350, 3},
    {8, 610, 1, 387, 3},
    {12, 611, 2, 380, 3},
    {24, 612, 3, 381, 3},
    {48, 613, 4, 524, 3},
    {52, 614, 5, 382, 3},
    {2, 558, 0, 350, 3},
    {8, 617, 1, 387, 3},
    {2, 585, -1, 387, 2},
    {8, 586, 0, 556, 3},
    {12, 620, 1, 559, 11},
    {14, 621, 2, 383, 11},
    {16, 622, 3, 560, 11},
    {2, 644, -1, 375, 2},
    {48, 645, -1, 376, 2},
    {64, 646, 0, 561, 3},
    {80, 647, -1, 374, 2},
    {320, 648, -1, 340, 2},
    {2, 331, -1, 562, 2},
    {4, 331, -1, 383, 2},
    {8, 318, 0, 301, 3},
    {8, 665, 0, 427, 3},
    {24, 318, 1, 301, 3},
    {0, 338, -1, 303, 2},
    {10, 357, -1, 356, 2},
    {0, 673, -1, 563, 2},
    {18, 674, -1, 564, 2},
    {24, 330, -1, 565, 2},
    {8, 680, -1, 425, 2},
    {24, 681, 0, 566, 3},
    {40, 318, 1, 301, 3},
    {8, 785, -1, 567, 2},
    {16, 337, -1, 441, 2},
    {32, 683, 0, 301, 3},
    {8, 684, -1, 568, 2},
    {64, 318, 0, 301, 3},
    {8, 686, 0, 360, 3},
    {56, 687, 1, 301, 3},
    {80, 688, 2, 569, 11},
    {1, 297, 0, 570, 3},
    {8, 690, -1, 571, 2},
    {16, 691, 1, 301, 3},
    {2, 710, -1, 572, 2},
    {4, 715, -1, 573, 2},
    {8, 716, 0, 574, 3},
    {26, 717, -1, 575, 2},
    {32, 718, 1, 576, 3},
    {33, 719, -1, 577, 2},
    {104, 720, 2, 301, 3},
    {2, 388, -1, 379, 2},
    {8, 750, -1, 389, 2},
    {16, 725, 0, 301, 3},
    {2, 388, -1, 379, 2},
    {8, 753, -1, 555, 2},
    {16, 318, 0, 301, 3},
    {8, 758, -1, 578, 2},
    {16, 761, 0, 579, 3},
    {24, 728, 1, 301, 3},
    {2, 388, -1, 379, 2},
    {6, 731, -1, 387, 2},
    {16, 590, 0, 558, 3},
    {24, 762, 1, 388, 3},
    {32, 732, 2, 301, 3},
    {8, 734, -1, 384, 2},
    {8, 735, -1, 385, 2},
    {8, 736, -1, 580, 2},
    {8, 737, -1, 386, 2},
    {8, 738, -1, 581, 2},
    {2, 398, 0, 350, 3},
    {12, 743, -1, 387, 2},
    {20, 744, 1, 380, 3},
    {32, 745, 2, 381, 3},
    {56, 746, 3, 524, 3},
    {64, 747, 4, 382, 3},
    {72, 748, 5, 301, 3},
    {2, 398, 0, 350, 3},
    {12, 751, -1, 387, 2},
    {24, 318, 1, 301, 3},
    {2, 754, -1, 582, 2},
    {4, 389, -1, 517, 2},
    {12, 755, -1, 583, 2},
    {16, 762, 0, 388, 3},
    {24, 756, 1, 301, 3},
    {2, 398, 0, 350, 3},
    {12, 754, 1, 584, 3},
    {14, 759, -1, 585, 2},
    {24, 318, 2, 301, 3},
    {4, 788, -1, 586, 2},
    {8, 789, 0, 587, 3},
    {16, 790, 1, 588, 3},
    {8, 793, 0, 589, 3},
    {32, 794, 1, 590, 3},
    {40, 795, 2, 591, 3},
    {4, 786, -1, 592, 2},
    {8, 509, -1, 548, 2},
    {12, 797, -1, 441, 2},
    {24, 798, -1, 549, 2},
    {32, 799, 0, 301, 3},
    {56, 800, 1, 593, 11},
    {2, 825, -1, 594, 2},
    {8, 297, 0, 595, 3},
    {16, 318, 1, 301, 3},
    {2, 825, -1, 596, 2},
    {8, 318, 0, 301, 3},
    {1, 830, 0, 543, 3},
    {2, 831, 1, 544, 3},
    {8, 832, 2, 301, 3},
    {2, 838, -1, 303, 2},
    {2, 839, -1, 311, 2},
    {4, 846, 0, 443, 3},
    {8, 318, 1, 301, 3},
    {32, 847, 2, 597, 11},
    {4, 663, 0, 448, 3},
    {8, 318, 1, 301, 3},
    {2, 872, 0, 463, 3},
    {24, 873, 1, 464, 3},
    {0, 877, -1, 465, 2},
    {4, 879, -1, 467, 2},
    {4, 880, -1, 468, 2},
    {4, 881, -1, 469, 2},
    {4, 882, -1, 470, 2},
    {0, 883, -1, 466, 2},
    {0, 885, -1, 471, 2},
    {4, 890, -1, 467, 2},
    {4, 891, -1, 468, 2},
    {4, 892, -1, 469, 2},
    {4, 893, -1, 470, 2}
};

#ifdef OSS_SPARTAN_AWARE
#if ((OSS_SPARTAN_AWARE + 0) > 12)
typedef struct ExtParms {
    int           versId;
    const void    *xparm[7];
} ExtParms;
static ExtParms const extParms = {
    24,
    {NULL, NULL, NULL, NULL, (void *)0, (void *)0, (void *)8}
};
#endif /* OSS_SPARTAN_AWARE  > 12 */
#endif /* OSS_SPARTAN_AWARE */

static void * const _enamearray[] = {
    (void *)0,
    (void *)0x3, (void *)_v41,
    (void *)"enterPW", (void *)"enterNewPW", (void *)"enterNewPW-Again",
    (void *)0x2, (void *)_v41,
    (void *)"updateProcedure", (void *)"subscriptionWithdraw",
    (void *)0x1, (void *)_v58, (void *)"oss-unknown-enumerator",
    (void *)0x3, (void *)_v41,
    (void *)"whiteListed", (void *)"blackListed", (void *)"greyListed",
    (void *)0x3, (void *)_v41,
    (void *)"undetermined", (void *)"invalidFormat", (void *)"newPasswordsMismatch",
    (void *)0x3, (void *)_v41,
    (void *)"noReasonGiven", (void *)"invalidDestinationReference", (void *)"invalidOriginatingReference",
    (void *)0x2, (void *)_v41,
    (void *)"shortTermResourceLimitation", (void *)"longTermResourceLimitation",
    (void *)0x7, (void *)_v41,
    (void *)"handoverCancellation", (void *)"radioChannelRelease", (void *)"networkPathRelease", (void *)"callRelease", (void *)"associatedProcedureFailure",
    (void *)"tandemDialogueRelease", (void *)"remoteOperationsFailure",
    (void *)0x2, (void *)_v41,
    (void *)"abnormalDialogue", (void *)"invalidPDU",
    (void *)0x5, (void *)_v41,
    (void *)"unrecognizedMessageType", (void *)"unrecognizedTransactionID", (void *)"badlyFormattedTransactionPortion", (void *)"incorrectTransactionPortion", (void *)"resourceLimitation",
    (void *)0x3, (void *)_v41,
    (void *)"unrecognizedComponent", (void *)"mistypedComponent", (void *)"badlyStructuredComponent",
    (void *)0x8, (void *)_v41,
    (void *)"duplicateInvokeID", (void *)"unrecognizedOperation", (void *)"mistypedParameter", (void *)"resourceLimitation", (void *)"initiatingRelease",
    (void *)"unrecognizedLinkedID", (void *)"linkedResponseUnexpected", (void *)"unexpectedLinkedOperation",
    (void *)0x3, (void *)_v41,
    (void *)"unrecognizedInvokeID", (void *)"returnResultUnexpected", (void *)"mistypedParameter",
    (void *)0x5, (void *)_v41,
    (void *)"unrecognizedInvokeID", (void *)"returnErrorUnexpected", (void *)"unrecognizedError", (void *)"unexpectedError", (void *)"mistypedParameter",
    (void *)0x3, (void *)_v41,
    (void *)"memoryCapacityExceeded", (void *)"absentSubscriber", (void *)"successfulTransfer",
    (void *)0x10004, (void *)_v44,
    (void *)"sc-AddressNotIncluded", (void *)"mnrf-Set", (void *)"mcef-Set", (void *)"mnrg-Set",
    (void *)0x2, (void *)_v41,
    (void *)"ms-Present", (void *)"memoryAvailable",
    (void *)0x2, (void *)_v41,
    (void *)"basicCall", (void *)"forwarding",
    (void *)0x3, (void *)_v41,
    (void *)"notReachable", (void *)"busy", (void *)"noReply",
    (void *)0x4, (void *)_v21,
    (void *)"gsm-0408", (void *)"gsm-0806", (void *)"gsm-BSSMAP", (void *)"ets-300102-1",
    (void *)0x10002, (void *)_v40,
    (void *)"phase1", (void *)"phase2",
    (void *)0x4, (void *)_v41,
    (void *)"msPurged", (void *)"imsiDetached", (void *)"restrictedArea", (void *)"notRegistered",
    (void *)0x1, (void *)_v24,
    (void *)"termAttemptAuthorized",
    (void *)0x1, (void *)_v58, (void *)"oss-unknown-enumerator",
    (void *)0x2, (void *)_v41,
    (void *)"continueCall", (void *)"releaseCall",
    (void *)0x1, (void *)_v58, (void *)"oss-unknown-enumerator",
    (void *)0x2, (void *)_v41,
    (void *)"stopMonitoring", (void *)"startMonitoring",
    (void *)0x1, (void *)_v58, (void *)"oss-unknown-enumerator",
    (void *)0x3, (void *)_v41,
    (void *)"ccbsNotIdle", (void *)"ccbsIdle", (void *)"ccbsNotReachable",
    (void *)0x1, (void *)_v58, (void *)"oss-unknown-enumerator",
    (void *)0x2, (void *)_v41,
    (void *)"a-side", (void *)"b-side",
    (void *)0x1, (void *)_v58, (void *)"oss-unknown-enumerator",
    (void *)0x3, (void *)_v41,
    (void *)"success", (void *)"failure", (void *)"busy",
    (void *)0x1, (void *)_v58, (void *)"oss-unknown-enumerator",
    (void *)0x6, (void *)_v41,
    (void *)"accepted", (void *)"rejected", (void *)"noResponseFromFreeMS", (void *)"noResponseFromBusyMS", (void *)"udubFromFreeMS",
    (void *)"udubFromBusyMS",
    (void *)0x1, (void *)_v58, (void *)"oss-unknown-enumerator",
    (void *)0x3, (void *)_v41,
    (void *)"permanent", (void *)"temporaryDefaultRestricted", (void *)"temporaryDefaultAllowed",
    (void *)0x2, (void *)_v41,
    (void *)"overrideEnabled", (void *)"overrideDisabled",
    (void *)0x10002, (void *)_v40,
    (void *)"clir-invoked", (void *)"camel-invoked",
    (void *)0x8, (void *)_v41,
    (void *)"plmn", (void *)"hlr", (void *)"vlr", (void *)"pvlr", (void *)"controllingMSC",
    (void *)"vmsc", (void *)"eir", (void *)"rss",
    (void *)0x2, (void *)_v41,
    (void *)"serviceGranted", (void *)"operatorDeterminedBarring",
    (void *)0x2000f, (void *)_v43,
    (void *)"allOG-CallsBarred", (void *)"internationalOGCallsBarred", (void *)"internationalOGCallsNotToHPLMN-CountryBarred", (void *)"premiumRateInformationOGCallsBarred", (void *)"premiumRateEntertainementOGCallsBarred",
    (void *)"ss-AccessBarred", (void *)"interzonalOGCallsBarred", (void *)"interzonalOGCallsNotToHPLMN-CountryBarred", (void *)"interzonalOGCallsAndInternationalOGCallsNotToHPLMN-CountryBarred", (void *)"allECT-Barred",
    (void *)"chargeableECT-Barred", (void *)"internationalECT-Barred", (void *)"interzonalECT-Barred", (void *)"doublyChargeableECT-Barred", (void *)"multipleECT-Barred",
    (void *)0x10004, (void *)_v44,
    (void *)"plmn-SpecificBarringType1", (void *)"plmn-SpecificBarringType2", (void *)"plmn-SpecificBarringType3", (void *)"plmn-SpecificBarringType4",
    (void *)0x3, (void *)_v41,
    (void *)"noCUG-Restrictions", (void *)"cugIC-CallBarred", (void *)"cugOG-CallBarred",
    (void *)0x4, (void *)_v41,
    (void *)"networkNode-AreaRestricted", (void *)"tooManyZoneCodes", (void *)"zoneCodesConflict", (void *)"regionalSubscNotSupported",
    (void *)0x1, (void *)_v47,
    (void *)"collectedInfo",
    (void *)0x1, (void *)_v58, (void *)"oss-unknown-enumerator",
    (void *)0x2, (void *)_v41,
    (void *)"inhibiting", (void *)"enabling",
    (void *)0x2, (void *)_v41,
    (void *)"forwarded", (void *)"notForwarded",
    (void *)0x2, (void *)_v51,
    (void *)"plmnRoamingNotAllowed", (void *)"operatorDeterminedBarring",
    (void *)0x2, (void *)_v41,
    (void *)"barringServiceActive", (void *)"operatorBarring",
    (void *)0x4, (void *)_v53,
    (void *)"incomingCallsBarredWithinCUG", (void *)"subscriberNotMemberOfCUG", (void *)"requestedBasicServiceViolatesCUG-Constraints", (void *)"calledPartySS-InteractionViolation",
    (void *)0x7, (void *)_v41,
    (void *)"memoryCapacityExceeded", (void *)"equipmentProtocolError", (void *)"equipmentNotSM-Equipped", (void *)"unknownServiceCentre", (void *)"sc-Congestion",
    (void *)"invalidSME-Address", (void *)"subscriberNotSC-Subscriber",
    (void *)0x2, (void *)_v41,
    (void *)"imsiUnknown", (void *)"gprsSubscriptionUnknown",
    (void *)0x1, (void *)_v58, (void *)"oss-unknown-enumerator",
    (void *)0x3, (void *)_v41,
    (void *)"imsiDetach", (void *)"restrictedArea", (void *)"noPageResponse",
    (void *)0x1, (void *)_v58, (void *)"oss-unknown-enumerator",
    (void *)"unidirectional",
    (void *)"begin",
    (void *)"end",
    (void *)"continue",
    (void *)"abort",
    (void *)"localValue",
    (void *)"globalValue",
    (void *)"teleservice",
    (void *)"asciCallReference",
    (void *)"codec-Info",
    (void *)"cipheringAlgorithm",
    (void *)"groupKeyNumber",
    (void *)"groupKey",
    (void *)"priority",
    (void *)"uplinkFree",
    (void *)"extensionContainer",
    (void *)"groupCallNumber",
    (void *)"imsi",
    (void *)"uplinkRequestAck",
    (void *)"uplinkReleaseIndication",
    (void *)"uplinkRejectCommand",
    (void *)"uplinkSeizedCommand",
    (void *)"uplinkReleaseCommand",
    (void *)"uplinkRequest",
    (void *)"releaseGroupCall",
    (void *)"msisdn",
    (void *)"sm-RP-PRI",
    (void *)"serviceCentreAddress",
    (void *)"gprsSupportIndicator",
    (void *)"sm-RP-MTI",
    (void *)"sm-RP-SMEA",
    (void *)"locationInfoWithLMSI",
    (void *)"sm-RP-DA",
    (void *)"sm-RP-OA",
    (void *)"sm-RP-UI",
    (void *)"moreMessagesToSend",
    (void *)"sm-DeliveryOutcome",
    (void *)"absentSubscriberDiagnosticSM",
    (void *)"deliveryOutcomeIndicator",
    (void *)"additionalSM-DeliveryOutcome",
    (void *)"additionalAbsentSubscriberDiagnosticSM",
    (void *)"storedMSISDN",
    (void *)"mw-Status",
    (void *)"alertReason",
    (void *)"alertReasonIndicator",
    (void *)"cug-CheckInfo",
    (void *)"numberOfForwarding",
    (void *)"interrogationType",
    (void *)"or-Interrogation",
    (void *)"or-Capability",
    (void *)"gmsc-Address",
    (void *)"callReferenceNumber",
    (void *)"forwardingReason",
    (void *)"basicServiceGroup",
    (void *)"networkSignalInfo",
    (void *)"camelInfo",
    (void *)"suppressionOfAnnouncement",
    (void *)"alertingPattern",
    (void *)"ccbs-Call",
    (void *)"supportedCCBS-Phase",
    (void *)"extendedRoutingInfo",
    (void *)"cugSubscriptionFlag",
    (void *)"subscriberInfo",
    (void *)"ss-List",
    (void *)"basicService",
    (void *)"forwardingInterrogationRequired",
    (void *)"vmsc-Address",
    (void *)"naea-PreferredCI",
    (void *)"ccbs-Indicators",
    (void *)"msc-Number",
    (void *)"lmsi",
    (void *)"gsm-BearerCapability",
    (void *)"roamingNumber",
    (void *)"forwardingData",
    (void *)"o-CSI",
    (void *)"ccbs-Possible",
    (void *)"isdn-BearerCapability",
    (void *)"call-Direction",
    (void *)"b-Subscriber-Address",
    (void *)"chosenChannel",
    (void *)"lowerLayerCompatibility",
    (void *)"highLayerCompatibility",
    (void *)"sIWFSNumber",
    (void *)"channelType",
    (void *)"ccbs-Monitoring",
    (void *)"ccbs-SubscriberStatus",
    (void *)"eventReportData",
    (void *)"callReportdata",
    (void *)"callInfo",
    (void *)"ccbs-Feature",
    (void *)"translatedB-Number",
    (void *)"replaceB-Number",
    (void *)"ruf-Outcome",
    (void *)"ss-Code",
    (void *)"forwardedToNumber",
    (void *)"forwardedToSubaddress",
    (void *)"noReplyConditionTime",
    (void *)"defaultPriority",
    (void *)"forwardingInfo",
    (void *)"callBarringInfo",
    (void *)"ss-Data",
    (void *)"ss-Status",
    (void *)"basicServiceGroupList",
    (void *)"forwardingFeatureList",
    (void *)"genericServiceInfo",
    (void *)"ussd-DataCodingScheme",
    (void *)"ussd-String",
    (void *)"ss-Event",
    (void *)"ss-EventSpecification",
    (void *)"ccbs-Data",
    (void *)"ccbs-Index",
    (void *)"tmsi",
    (void *)"vlr-Number",
    (void *)"vlr-Capability",
    (void *)"hlr-Number",
    (void *)"imsi-WithLMSI",
    (void *)"freezeTMSI",
    (void *)"freezeP-TMSI",
    (void *)"authenticationSetList",
    (void *)"sgsn-Number",
    (void *)"sgsn-Address",
    (void *)"targetCellId",
    (void *)"ho-NumberNotRequired",
    (void *)"bss-APDU",
    (void *)"handoverNumber",
    (void *)"targetMSC-Number",
    (void *)"category",
    (void *)"subscriberStatus",
    (void *)"bearerServiceList",
    (void *)"teleserviceList",
    (void *)"provisionedSS",
    (void *)"odb-Data",
    (void *)"roamingRestrictionDueToUnsupportedFeature",
    (void *)"regionalSubscriptionData",
    (void *)"vbsSubscriptionData",
    (void *)"vgcsSubscriptionData",
    (void *)"vlrCamelSubscriptionInfo",
    (void *)"gprsSubscriptionData",
    (void *)"roamingRestrictedInSgsnDueToUnsupportedFeature",
    (void *)"odb-GeneralData",
    (void *)"regionalSubscriptionResponse",
    (void *)"supportedCamelPhases",
    (void *)"basicServiceList",
    (void *)"regionalSubscriptionIdentifier",
    (void *)"vbsGroupIndication",
    (void *)"vgcsGroupIndication",
    (void *)"camelSubscriptionInfoWithdraw",
    (void *)"roamingRestrictedInSgsnDueToUnsuppportedFeature",
    (void *)"ggsn-Address",
    (void *)"mobileNotReachableReason",
    (void *)"ggsn-Number",
    (void *)"hlr-List",
    (void *)"msNotReachable",
    (void *)"requestedInfo",
    (void *)"subscriberIdentity",
    (void *)"gsmSCF-Address",
    (void *)"roamingNotAllowedCause",
    (void *)"callBarringCause",
    (void *)"extensibleCallBarredParam",
    (void *)"cug-RejectCause",
    (void *)"sm-EnumeratedDeliveryFailureCause",
    (void *)"diagnosticInfo",
    (void *)"networkResource",
    (void *)"extensibleSystemFailureParam",
    (void *)"unknownSubscriberDiagnostic",
    (void *)"absentSubscriberReason",
    (void *)"ccbs-Busy",
    (void *)"gprsConnectionSuspended",
    (void *)"traceReference",
    (void *)"traceType",
    (void *)"omc-Id",
    (void *)"map-open",
    (void *)"map-accept",
    (void *)"map-close",
    (void *)"map-refuse",
    (void *)"map-userAbort",
    (void *)"map-providerAbort",
    (void *)"destinationReference",
    (void *)"originationReference",
    (void *)"reason",
    (void *)"map-UserAbortChoice",
    (void *)"userSpecificReason",
    (void *)"userResourceLimitation",
    (void *)"resourceUnavailable",
    (void *)"applicationProcedureCancellation",
    (void *)"map-ProviderAbortReason",
    (void *)"single-ASN1-type",
    (void *)"octet-aligned",
    (void *)"arbitrary",
    (void *)"direct-reference",
    (void *)"indirect-reference",
    (void *)"data-value-descriptor",
    (void *)"encoding",
    (void *)"dialoguePortion",
    (void *)"components",
    (void *)"otid",
    (void *)"dtid",
    (void *)"p-abortCause",
    (void *)"u-abortCause",
    (void *)"invokeID",
    (void *)"linkedID",
    (void *)"operationCode",
    (void *)"parameter",
    (void *)"result",
    (void *)"errorCode",
    (void *)"derivable",
    (void *)"not-derivable",
    (void *)"generalProblem",
    (void *)"invokeProblem",
    (void *)"returnResultProblem",
    (void *)"returnErrorProblem",
    (void *)"problem",
    (void *)"invoke",
    (void *)"returnResultLast",
    (void *)"returnError",
    (void *)"reject",
    (void *)"returnResultNotLast",
    (void *)"ExtensionType",
    (void *)"extensionId",
    (void *)"_oss_unique_index",
    (void *)"privateExtensionList",
    (void *)"pcs-Extensions",
    (void *)"extId",
    (void *)"extType",
    (void *)"networkNode-Number",
    (void *)"gprsNodeIndicator",
    (void *)"additional-Number",
    (void *)"serviceCentreAddressDA",
    (void *)"noSM-RP-DA",
    (void *)"serviceCentreAddressOA",
    (void *)"noSM-RP-OA",
    (void *)"cug-Interlock",
    (void *)"cug-OutgoingAccess",
    (void *)"ext-BearerService",
    (void *)"ext-Teleservice",
    (void *)"protocolId",
    (void *)"signalInfo",
    (void *)"suppress-T-CSI",
    (void *)"forwardingOptions",
    (void *)"t-BcsmCamelTDPDataList",
    (void *)"camelCapabilityHandling",
    (void *)"o-BcsmCamelTDPDataList",
    (void *)"t-CSI",
    (void *)"gmscCamelSubscriptionInfo",
    (void *)"routingInfo",
    (void *)"camelRoutingInfo",
    (void *)"cellIdFixedLength",
    (void *)"laiFixedLength",
    (void *)"ageOfLocationInformation",
    (void *)"geographicalInformation",
    (void *)"vlr-number",
    (void *)"locationNumber",
    (void *)"cellIdOrLAI",
    (void *)"assumedIdle",
    (void *)"camelBusy",
    (void *)"netDetNotReachable",
    (void *)"notProvidedFromVLR",
    (void *)"locationInformation",
    (void *)"subscriberState",
    (void *)"naea-PreferredCIC",
    (void *)"keepCCBS-CallIndicator",
    (void *)"t-BcsmTriggerDetectionPoint",
    (void *)"serviceKey",
    (void *)"defaultCallHandling",
    (void *)"monitoringMode",
    (void *)"callOutcome",
    (void *)"bearerService",
    (void *)"b-subscriberNumber",
    (void *)"b-subscriberSubaddress",
    (void *)"callBarringFeatureList",
    (void *)"cliRestrictionOption",
    (void *)"overrideCategory",
    (void *)"ss-SubscriptionOption",
    (void *)"maximumEntitledPriority",
    (void *)"ccbs-FeatureList",
    (void *)"serviceIndicator",
    (void *)"maximumentitledPriority",
    (void *)"rand",
    (void *)"sres",
    (void *)"kc",
    (void *)"odb-HPLMN-Data",
    (void *)"ss-EventList",
    (void *)"ss-CamelData",
    (void *)"ss-CSI",
    (void *)"completeDataListIncluded",
    (void *)"gprsDataList",
    (void *)"pdp-ContextId",
    (void *)"pdp-Type",
    (void *)"pdp-Address",
    (void *)"qos-Subscribed",
    (void *)"vplmnAddressAllowed",
    (void *)"apn",
    (void *)"cug-SubscriptionList",
    (void *)"cug-FeatureList",
    (void *)"cug-Info",
    (void *)"emlpp-Info",
    (void *)"cug-Index",
    (void *)"intraCUG-Options",
    (void *)"preferentialCUG-Indicator",
    (void *)"interCUG-Restrictions",
    (void *)"matchType",
    (void *)"destinationNumberList",
    (void *)"destinationNumberLengthList",
    (void *)"destinationNumberCriteria",
    (void *)"basicServiceCriteria",
    (void *)"callTypeCriteria",
    (void *)"o-BcsmTriggerDetectionPoint",
    (void *)"o-BcsmCamelTDP-Criteria",
    (void *)"groupid",
    (void *)"broadcastInitEntitlement",
    (void *)"groupId",
    (void *)"unauthorisedMessageOriginator"
};

static const Etag _tagarray[] = {
    1, 0x0006, 0, 5, 0x4001, 1, 0x4002, 2, 0x4004, 3,
    0x4005, 4, 0x4007, 5, 2, 0x0002, 1, 0x0006, 2, 1,
    0x0010, 30, 33, 36, 39, 42, 53, 62, 69, 74,
    1, 0x0004, 1, 1, 0x0004, 2, 1, 0x0004, 3, 1,
    0x0004, 4, 5, 0x8000, 5, 0x8001, 6, 0x8002, 7, 0x8003,
    8, 0x8004, 9, 4, 0x8001, 6, 0x8002, 7, 0x8003, 8,
    0x8004, 9, 3, 0x8002, 7, 0x8003, 8, 0x8004, 9, 2,
    0x8003, 8, 0x8004, 9, 1, 0x8004, 9, 79, 82, 1,
    0x0004, 1, 1, 0x0010, 2, 87, 92, 2, 0x0004, 1,
    0x0010, 2, 1, 0x0010, 2, 96, 1, 0x0010, 1, 106,
    121, 134, 145, 154, 161, 166, 7, 0x0004, 1, 0x0010,
    7, 0x8000, 2, 0x8001, 3, 0x8002, 4, 0x8003, 5, 0x8004,
    6, 6, 0x0010, 7, 0x8000, 2, 0x8001, 3, 0x8002, 4,
    0x8003, 5, 0x8004, 6, 5, 0x0010, 7, 0x8001, 3, 0x8002,
    4, 0x8003, 5, 0x8004, 6, 4, 0x0010, 7, 0x8002, 4,
    0x8003, 5, 0x8004, 6, 3, 0x0010, 7, 0x8003, 5, 0x8004,
    6, 2, 0x0010, 7, 0x8004, 6, 1, 0x0010, 7, 173,
    182, 189, 194, 4, 0x0010, 4, 0x8000, 1, 0x8001, 2,
    0x8002, 3, 3, 0x0010, 4, 0x8001, 2, 0x8002, 3, 2,
    0x0010, 4, 0x8002, 3, 1, 0x0010, 4, 204, 207, 210,
    213, 222, 229, 234, 1, 0x8000, 1, 1, 0x8001, 2,
    1, 0x8002, 3, 4, 0x8006, 4, 0x8007, 5, 0x8008, 6,
    0x8009, 7, 3, 0x8007, 5, 0x8008, 6, 0x8009, 7, 2,
    0x8008, 6, 0x8009, 7, 1, 0x8009, 7, 240, 243, 246,
    1, 0x0004, 1, 1, 0x8000, 2, 1, 0x8004, 3, 253,
    262, 269, 272, 4, 0x8000, 1, 0x8001, 1, 0x8004, 1,
    0x8005, 1, 3, 0x8002, 2, 0x8004, 2, 0x8005, 2, 1,
    0x0004, 3, 1, 0x0010, 4, 280, 289, 296, 299, 304,
    4, 0x8000, 1, 0x8001, 1, 0x8004, 1, 0x8005, 1, 3,
    0x8002, 2, 0x8004, 2, 0x8005, 2, 1, 0x0004, 3, 2,
    0x0005, 4, 0x0010, 5, 1, 0x0010, 5, 316, 319, 322,
    325, 338, 349, 358, 365, 370, 1, 0x0004, 1, 1,
    0x0004, 2, 1, 0x000a, 3, 6, 0x8000, 4, 0x8001, 5,
    0x8002, 6, 0x8003, 7, 0x8004, 8, 0x8005, 9, 5, 0x8001,
    5, 0x8002, 6, 0x8003, 7, 0x8004, 8, 0x8005, 9, 4,
    0x8002, 6, 0x8003, 7, 0x8004, 8, 0x8005, 9, 3, 0x8003,
    7, 0x8004, 8, 0x8005, 9, 2, 0x8004, 8, 0x8005, 9,
    1, 0x8005, 9, 375, 378, 1, 0x0004, 1, 1, 0x0004,
    2, 384, 391, 396, 3, 0x0003, 2, 0x0004, 1, 0x0010,
    3, 2, 0x0003, 2, 0x0010, 3, 1, 0x0010, 3, 403,
    406, 409, 414, 1, 0x8000, 1, 1, 0x000a, 2, 2,
    0x0005, 3, 0x0010, 4, 1, 0x0010, 4, 434, 437, 444,
    449, 452, 459, 464, 467, 488, 507, 524, 539, 552,
    563, 572, 579, 584, 1, 0x8000, 1, 3, 0x8001, 2,
    0x8002, 3, 0x8003, 4, 2, 0x8002, 3, 0x8003, 4, 1,
    0x8003, 4, 3, 0x8004, 5, 0x8005, 6, 0x8006, 7, 2,
    0x8005, 6, 0x8006, 7, 1, 0x8006, 7, 10, 0x8007, 8,
    0x8008, 9, 0x8009, 10, 0x800a, 11, 0x800b, 12, 0x800c, 13,
    0x800d, 14, 0x800e, 15, 0x800f, 16, 0x8010, 17, 9, 0x8008,
    9, 0x8009, 10, 0x800a, 11, 0x800b, 12, 0x800c, 13, 0x800d,
    14, 0x800e, 15, 0x800f, 16, 0x8010, 17, 8, 0x8009, 10,
    0x800a, 11, 0x800b, 12, 0x800c, 13, 0x800d, 14, 0x800e, 15,
    0x800f, 16, 0x8010, 17, 7, 0x800a, 11, 0x800b, 12, 0x800c,
    13, 0x800d, 14, 0x800e, 15, 0x800f, 16, 0x8010, 17, 6,
    0x800b, 12, 0x800c, 13, 0x800d, 14, 0x800e, 15, 0x800f, 16,
    0x8010, 17, 5, 0x800c, 13, 0x800d, 14, 0x800e, 15, 0x800f,
    16, 0x8010, 17, 4, 0x800d, 14, 0x800e, 15, 0x800f, 16,
    0x8010, 17, 3, 0x800e, 15, 0x800f, 16, 0x8010, 17, 2,
    0x800f, 16, 0x8010, 17, 1, 0x8010, 17, 1, 0x8003, 601,
    630, 657, 678, 697, 714, 729, 742, 753, 762, 769,
    774, 14, 0x0004, 2, 0x0010, 2, 0x8000, 10, 0x8001, 6,
    0x8002, 9, 0x8003, 3, 0x8004, 8, 0x8005, 7, 0x8006, 4,
    0x8007, 5, 0x8008, 2, 0x8009, 1, 0x800a, 11, 0x800b, 12,
    13, 0x0004, 2, 0x0010, 2, 0x8000, 10, 0x8001, 6, 0x8002,
    9, 0x8003, 3, 0x8004, 8, 0x8005, 7, 0x8006, 4, 0x8007,
    5, 0x8008, 2, 0x800a, 11, 0x800b, 12, 10, 0x8000, 10,
    0x8001, 6, 0x8002, 9, 0x8003, 3, 0x8004, 8, 0x8005, 7,
    0x8006, 4, 0x8007, 5, 0x800a, 11, 0x800b, 12, 9, 0x8000,
    10, 0x8001, 6, 0x8002, 9, 0x8004, 8, 0x8005, 7, 0x8006,
    4, 0x8007, 5, 0x800a, 11, 0x800b, 12, 8, 0x8000, 10,
    0x8001, 6, 0x8002, 9, 0x8004, 8, 0x8005, 7, 0x8007, 5,
    0x800a, 11, 0x800b, 12, 7, 0x8000, 10, 0x8001, 6, 0x8002,
    9, 0x8004, 8, 0x8005, 7, 0x800a, 11, 0x800b, 12, 6,
    0x8000, 10, 0x8002, 9, 0x8004, 8, 0x8005, 7, 0x800a, 11,
    0x800b, 12, 5, 0x8000, 10, 0x8002, 9, 0x8004, 8, 0x800a,
    11, 0x800b, 12, 4, 0x8000, 10, 0x8002, 9, 0x800a, 11,
    0x800b, 12, 3, 0x8000, 10, 0x800a, 11, 0x800b, 12, 2,
    0x800a, 11, 0x800b, 12, 1, 0x800b, 12, 790, 793, 796,
    819, 840, 859, 876, 891, 904, 915, 924, 931, 936,
    1, 0x8000, 1, 1, 0x8001, 2, 11, 0x8002, 3, 0x8004,
    4, 0x8005, 5, 0x8006, 6, 0x8007, 7, 0x8008, 8, 0x8009,
    9, 0x800a, 10, 0x800b, 11, 0x800c, 12, 0x800d, 13, 10,
    0x8004, 4, 0x8005, 5, 0x8006, 6, 0x8007, 7, 0x8008, 8,
    0x8009, 9, 0x800a, 10, 0x800b, 11, 0x800c, 12, 0x800d, 13,
    9, 0x8005, 5, 0x8006, 6, 0x8007, 7, 0x8008, 8, 0x8009,
    9, 0x800a, 10, 0x800b, 11, 0x800c, 12, 0x800d, 13, 8,
    0x8006, 6, 0x8007, 7, 0x8008, 8, 0x8009, 9, 0x800a, 10,
    0x800b, 11, 0x800c, 12, 0x800d, 13, 7, 0x8007, 7, 0x8008,
    8, 0x8009, 9, 0x800a, 10, 0x800b, 11, 0x800c, 12, 0x800d,
    13, 6, 0x8008, 8, 0x8009, 9, 0x800a, 10, 0x800b, 11,
    0x800c, 12, 0x800d, 13, 5, 0x8009, 9, 0x800a, 10, 0x800b,
    11, 0x800c, 12, 0x800d, 13, 4, 0x800a, 10, 0x800b, 11,
    0x800c, 12, 0x800d, 13, 3, 0x800b, 11, 0x800c, 12, 0x800d,
    13, 2, 0x800c, 12, 0x800d, 13, 1, 0x800d, 13, 947,
    950, 953, 956, 959, 968, 975, 980, 1, 0x8000, 1,
    1, 0x8001, 2, 1, 0x8002, 3, 1, 0x8003, 4, 4,
    0x8004, 5, 0x8005, 6, 0x8007, 7, 0x8008, 8, 3, 0x8005,
    6, 0x8007, 7, 0x8008, 8, 2, 0x8007, 7, 0x8008, 8,
    1, 0x8008, 8, 991, 994, 997, 1000, 1003, 1006, 1013,
    1018, 1, 0x8000, 1, 1, 0x8001, 2, 1, 0x8002, 3,
    1, 0x8003, 4, 1, 0x8004, 5, 3, 0x8005, 6, 0x8006,
    7, 0x8007, 8, 2, 0x8006, 7, 0x8007, 8, 1, 0x8007,
    8, 1023, 1026, 1, 0x8000, 1, 1, 0x8001, 2, 1032,
    1039, 1044, 3, 0x8000, 1, 0x8001, 2, 0x8002, 3, 2,
    0x8001, 2, 0x8002, 3, 1, 0x8002, 3, 1049, 1054, 2,
    0x8000, 1, 0x8001, 2, 1, 0x8001, 2, 1061, 1070, 1077,
    1082, 4, 0x8000, 1, 0x8001, 2, 0x8002, 3, 0x8003, 4,
    3, 0x8001, 2, 0x8002, 3, 0x8003, 4, 2, 0x8002, 3,
    0x8003, 4, 1, 0x8003, 4, 1089, 1092, 1099, 1104, 1,
    0x8000, 1, 3, 0x8001, 2, 0x8002, 3, 0x8003, 4, 2,
    0x8002, 3, 0x8003, 4, 1, 0x8003, 4, 1108, 1, 0x8000,
    1, 1118, 1121, 1124, 1127, 1130, 1137, 1142, 1, 0x8000,
    1, 1, 0x8001, 2, 1, 0x8002, 3, 1, 0x8003, 4,
    3, 0x8004, 5, 0x8005, 6, 0x8006, 7, 2, 0x8005, 6,
    0x8006, 7, 1, 0x8006, 7, 1, 0x0004, 1153, 1156, 1169,
    1178, 1185, 1190, 1, 0x0004, 1, 6, 0x8002, 2, 0x8003,
    2, 0x8004, 3, 0x8005, 5, 0x8006, 4, 0x8007, 6, 4,
    0x8004, 3, 0x8005, 5, 0x8006, 4, 0x8007, 6, 3, 0x8005,
    5, 0x8006, 4, 0x8007, 6, 2, 0x8005, 5, 0x8007, 6,
    1, 0x8007, 6, 3, 0x8000, 1, 0x8001, 2, 0x8003, 3,
    1202, 1205, 1, 0x0004, 1, 2, 0x8002, 2, 0x8003, 2,
    4, 0x8000, 1, 0x8002, 2, 0x8003, 3, 0x8004, 4, 1222,
    1225, 1228, 1, 0x0004, 1, 1, 0x0004, 2, 1, 0x0004,
    3, 1, 0x0012, 1, 0x000a, 1240, 1243, 1246, 1249, 1254,
    1, 0x8000, 1, 1, 0x8001, 2, 1, 0x8002, 3, 2,
    0x8003, 4, 0x8004, 5, 1, 0x8004, 5, 2, 0x8000, 1,
    0x8001, 2, 1268, 1271, 1274, 1277, 1284, 1289, 1, 0x0004,
    1, 1, 0x8001, 2, 1, 0x0004, 3, 3, 0x0010, 5,
    0x8006, 6, 0x800a, 4, 2, 0x0010, 5, 0x8006, 6, 1,
    0x8006, 6, 2, 0x0004, 1, 0x0010, 2, 1300, 1307, 1312,
    3, 0x0010, 3, 0x8000, 1, 0x8001, 2, 2, 0x0010, 3,
    0x8001, 2, 1, 0x0010, 3, 1319, 1322, 1325, 1328, 1,
    0x0004, 1, 1, 0x0004, 2, 1, 0x0004, 3, 1, 0x0010,
    4, 1334, 1341, 1346, 3, 0x0004, 1, 0x0005, 2, 0x0010,
    3, 2, 0x0005, 2, 0x0010, 3, 1, 0x0010, 3, 1352,
    1355, 1358, 1, 0x0004, 1, 1, 0x0004, 2, 1, 0x0010,
    3, 1378, 1413, 1446, 1477, 1506, 1533, 1558, 1581, 1602,
    1621, 1638, 1653, 1666, 1677, 1686, 1693, 1698, 17, 0x8000,
    1, 0x8001, 2, 0x8002, 3, 0x8003, 4, 0x8004, 5, 0x8006,
    6, 0x8007, 7, 0x8008, 8, 0x8009, 9, 0x800a, 10, 0x800b,
    11, 0x800c, 12, 0x800d, 13, 0x800e, 14, 0x800f, 15, 0x8010,
    16, 0x8017, 17, 16, 0x8001, 2, 0x8002, 3, 0x8003, 4,
    0x8004, 5, 0x8006, 6, 0x8007, 7, 0x8008, 8, 0x8009, 9,
    0x800a, 10, 0x800b, 11, 0x800c, 12, 0x800d, 13, 0x800e, 14,
    0x800f, 15, 0x8010, 16, 0x8017, 17, 15, 0x8002, 3, 0x8003,
    4, 0x8004, 5, 0x8006, 6, 0x8007, 7, 0x8008, 8, 0x8009,
    9, 0x800a, 10, 0x800b, 11, 0x800c, 12, 0x800d, 13, 0x800e,
    14, 0x800f, 15, 0x8010, 16, 0x8017, 17, 14, 0x8003, 4,
    0x8004, 5, 0x8006, 6, 0x8007, 7, 0x8008, 8, 0x8009, 9,
    0x800a, 10, 0x800b, 11, 0x800c, 12, 0x800d, 13, 0x800e, 14,
    0x800f, 15, 0x8010, 16, 0x8017, 17, 13, 0x8004, 5, 0x8006,
    6, 0x8007, 7, 0x8008, 8, 0x8009, 9, 0x800a, 10, 0x800b,
    11, 0x800c, 12, 0x800d, 13, 0x800e, 14, 0x800f, 15, 0x8010,
    16, 0x8017, 17, 12, 0x8006, 6, 0x8007, 7, 0x8008, 8,
    0x8009, 9, 0x800a, 10, 0x800b, 11, 0x800c, 12, 0x800d, 13,
    0x800e, 14, 0x800f, 15, 0x8010, 16, 0x8017, 17, 11, 0x8007,
    7, 0x8008, 8, 0x8009, 9, 0x800a, 10, 0x800b, 11, 0x800c,
    12, 0x800d, 13, 0x800e, 14, 0x800f, 15, 0x8010, 16, 0x8017,
    17, 10, 0x8008, 8, 0x8009, 9, 0x800a, 10, 0x800b, 11,
    0x800c, 12, 0x800d, 13, 0x800e, 14, 0x800f, 15, 0x8010, 16,
    0x8017, 17, 9, 0x8009, 9, 0x800a, 10, 0x800b, 11, 0x800c,
    12, 0x800d, 13, 0x800e, 14, 0x800f, 15, 0x8010, 16, 0x8017,
    17, 8, 0x800a, 10, 0x800b, 11, 0x800c, 12, 0x800d, 13,
    0x800e, 14, 0x800f, 15, 0x8010, 16, 0x8017, 17, 7, 0x800b,
    11, 0x800c, 12, 0x800d, 13, 0x800e, 14, 0x800f, 15, 0x8010,
    16, 0x8017, 17, 6, 0x800c, 12, 0x800d, 13, 0x800e, 14,
    0x800f, 15, 0x8010, 16, 0x8017, 17, 5, 0x800d, 13, 0x800e,
    14, 0x800f, 15, 0x8010, 16, 0x8017, 17, 4, 0x800e, 14,
    0x800f, 15, 0x8010, 16, 0x8017, 17, 3, 0x800f, 15, 0x8010,
    16, 0x8017, 17, 2, 0x8010, 16, 0x8017, 17, 1, 0x8017,
    17, 1708, 1723, 1736, 1747, 1756, 1763, 1768, 7, 0x8001,
    1, 0x8002, 2, 0x8003, 3, 0x8004, 4, 0x8005, 5, 0x8006,
    6, 0x8007, 7, 6, 0x8002, 2, 0x8003, 3, 0x8004, 4,
    0x8005, 5, 0x8006, 6, 0x8007, 7, 5, 0x8003, 3, 0x8004,
    4, 0x8005, 5, 0x8006, 6, 0x8007, 7, 4, 0x8004, 4,
    0x8005, 5, 0x8006, 6, 0x8007, 7, 3, 0x8005, 5, 0x8006,
    6, 0x8007, 7, 2, 0x8006, 6, 0x8007, 7, 1, 0x8007,
    7, 1781, 1784, 1803, 1820, 1835, 1848, 1859, 1868, 1875,
    1880, 1, 0x8000, 1, 9, 0x8001, 2, 0x8002, 3, 0x8004,
    4, 0x8005, 5, 0x8006, 9, 0x8007, 6, 0x8008, 7, 0x8009,
    8, 0x800b, 10, 8, 0x8002, 3, 0x8004, 4, 0x8005, 5,
    0x8006, 9, 0x8007, 6, 0x8008, 7, 0x8009, 8, 0x800b, 10,
    7, 0x8004, 4, 0x8005, 5, 0x8006, 9, 0x8007, 6, 0x8008,
    7, 0x8009, 8, 0x800b, 10, 6, 0x8005, 5, 0x8006, 9,
    0x8007, 6, 0x8008, 7, 0x8009, 8, 0x800b, 10, 5, 0x8006,
    9, 0x8007, 6, 0x8008, 7, 0x8009, 8, 0x800b, 10, 4,
    0x8006, 9, 0x8008, 7, 0x8009, 8, 0x800b, 10, 3, 0x8006,
    9, 0x8009, 8, 0x800b, 10, 2, 0x8006, 9, 0x800b, 10,
    1, 0x800b, 10, 1885, 1890, 2, 0x0010, 2, 0x8000, 1,
    1, 0x0010, 2, 1896, 1899, 1904, 1, 0x8000, 1, 2,
    0x8001, 2, 0x8002, 3, 1, 0x8002, 3, 1911, 1914, 1921,
    1926, 1, 0x0004, 1, 3, 0x0004, 2, 0x0010, 3, 0x8006,
    4, 2, 0x0010, 3, 0x8006, 4, 1, 0x8006, 4, 1932,
    1935, 1940, 1, 0x0004, 1, 2, 0x0005, 2, 0x0010, 3,
    1, 0x0010, 3, 1947, 1950, 1955, 1958, 1, 0x8000, 1,
    2, 0x8001, 2, 0x8002, 3, 1, 0x8002, 3, 1, 0x8003,
    4, 1963, 1966, 1, 0x0010, 1, 1, 0x0010, 2, 1973,
    1976, 1979, 1982, 1, 0x8000, 1, 1, 0x8001, 2, 1,
    0x8003, 3, 1, 0x8002, 4, 1987, 1990, 1, 0x000a, 1,
    1, 0x0010, 2, 2, 0x000a, 1, 0x0010, 2, 2000, 2005,
    2, 0x000a, 1, 0x0010, 2, 1, 0x0010, 2, 2011, 2020,
    2027, 4, 0x8001, 1, 0x8002, 2, 0x8003, 2, 0x8004, 3,
    3, 0x8002, 2, 0x8003, 2, 0x8004, 3, 1, 0x8004, 3,
    2033, 2036, 2041, 1, 0x000a, 1, 2, 0x0004, 2, 0x0010,
    3, 1, 0x0010, 3, 2047, 2054, 2059, 3, 0x0002, 1,
    0x0010, 2, 0x8000, 3, 2, 0x0010, 2, 0x8000, 3, 1,
    0x8000, 3, 2064, 2069, 2, 0x000a, 2, 0x0010, 1, 1,
    0x000a, 2, 2074, 2079, 2, 0x0010, 1, 0x8000, 2, 1,
    0x8000, 2, 2085, 2092, 2097, 3, 0x0010, 1, 0x8000, 2,
    0x8001, 3, 2, 0x8000, 2, 0x8001, 3, 1, 0x8001, 3,
    2102, 2107, 2, 0x0005, 2, 0x0010, 1, 1, 0x0005, 2,
    2115, 2120, 2123, 2126, 2131, 2, 0x8000, 1, 0x8001, 2,
    1, 0x8001, 2, 1, 0x8002, 3, 2, 0x8003, 4, 0x8004,
    5, 1, 0x8004, 5, 2137, 2142, 2145, 2, 0x8000, 1,
    0x8001, 2, 1, 0x8001, 2, 1, 0x8002, 3, 6, 0x8000,
    1, 0x8001, 2, 0x8002, 3, 0x8003, 4, 0x8004, 5, 0x8005,
    6, 2162, 1, 0x000a, 1, 2166, 4, 0x8000, 1, 0x8001,
    1, 0x8002, 1, 0x8003, 1, 4, 0x8000, 1, 0x8001, 2,
    0x8002, 3, 0x8003, 4, 1, 0x0002, 1, 0x0007, 1, 0x8000,
    1, 0x8001, 1, 0x8002, 3, 0x8000, 1, 0x8001, 2, 0x8002,
    3, 1, 0x0008, 2207, 2220, 2231, 2240, 6, 0x0002, 2,
    0x0006, 1, 0x0007, 3, 0x8000, 4, 0x8001, 4, 0x8002, 4,
    5, 0x0002, 2, 0x0007, 3, 0x8000, 4, 0x8001, 4, 0x8002,
    4, 4, 0x0007, 3, 0x8000, 4, 0x8001, 4, 0x8002, 4,
    3, 0x8000, 4, 0x8001, 4, 0x8002, 4, 2, 0x400b, 0x0008,
    2252, 2257, 2, 0x400b, 1, 0x400c, 2, 1, 0x400c, 2,
    1, 0x4008, 2265, 2268, 2273, 1, 0x4008, 1, 2, 0x400b,
    2, 0x400c, 3, 1, 0x400c, 3, 1, 0x4009, 2281, 2284,
    2289, 1, 0x4009, 1, 2, 0x400b, 2, 0x400c, 3, 1,
    0x400c, 3, 2296, 2299, 2302, 2307, 1, 0x4008, 1, 1,
    0x4009, 2, 2, 0x400b, 3, 0x400c, 4, 1, 0x400c, 4,
    1, 0x400a, 2, 0x400a, 1, 0x400b, 2, 2319, 2322, 1,
    0x4009, 1, 2, 0x400a, 2, 0x400b, 2, 1, 0x4001, 1,
    0x4002, 1, 0x4004, 1, 0x4005, 1, 0x4007, 2341, 2344, 2351,
    2356, 1, 0x0002, 1, 3, 0x0002, 3, 0x0006, 3, 0x8000,
    2, 2, 0x0002, 3, 0x0006, 3, 0, 2359, 2364, 2,
    0x0002, 1, 0x0006, 1, 0, 2367, 2370, 1, 0x0002, 1,
    1, 0x0010, 2, 2376, 2379, 2384, 1, 0x0002, 1, 2,
    0x0002, 2, 0x0006, 2, 0, 1, 0x0005, 2, 0x0002, 1,
    0x0005, 2, 2394, 2399, 2, 0x0002, 1, 0x0005, 1, 4,
    0x8000, 2, 0x8001, 2, 0x8002, 2, 0x8003, 2, 1, 0x8004,
    1, 0x8007, 5, 0x8001, 1, 0x8002, 2, 0x8003, 3, 0x8004,
    4, 0x8007, 5, 1, 0x400c, 2427, 2430, 1, 0x0006, 1,
    0, 1, 0x8006, 1, 0x8008, 1, 0x8009, 1, 0x8005, 2444,
    2447, 2456, 2463, 2468, 1, 0x8001, 1, 4, 0x0004, 2,
    0x0010, 3, 0x8005, 4, 0x8006, 5, 3, 0x0010, 3, 0x8005,
    4, 0x8006, 5, 2, 0x8005, 4, 0x8006, 5, 1, 0x8006,
    5, 4, 0x8000, 1, 0x8001, 2, 0x8004, 3, 0x8005, 4,
    3, 0x8002, 1, 0x8004, 2, 0x8005, 3, 1, 0x0003, 2,
    0x8002, 1, 0x8003, 2, 2497, 2500, 2503, 1, 0x000a, 1,
    1, 0x0004, 2, 1, 0x0010, 3, 2509, 2512, 2517, 1,
    0x0003, 1, 2, 0x0005, 2, 0x0010, 3, 1, 0x0010, 3,
    1, 0x800a, 1, 0x800b, 1, 0x800c, 1, 0x800d, 1, 0x800e,
    1, 0x800f, 1, 0x8010, 2538, 2547, 2554, 2559, 4, 0x8004,
    2, 0x8005, 1, 0x8006, 3, 0x8007, 4, 3, 0x8004, 2,
    0x8006, 3, 0x8007, 4, 2, 0x8006, 3, 0x8007, 4, 1,
    0x8007, 4, 2565, 2568, 2573, 1, 0x0010, 1, 2, 0x0010,
    2, 0x8000, 3, 1, 0x8000, 3, 2579, 2584, 2587, 2,
    0x0010, 1, 0x8000, 2, 1, 0x8000, 2, 1, 0x8001, 3,
    3, 0x0004, 1, 0x0010, 1, 0x8008, 2, 2603, 2616, 2627,
    2636, 2643, 2648, 6, 0x0002, 1, 0x8000, 2, 0x8001, 3,
    0x8002, 4, 0x8003, 5, 0x8004, 6, 5, 0x8000, 2, 0x8001,
    3, 0x8002, 4, 0x8003, 5, 0x8004, 6, 4, 0x8001, 3,
    0x8002, 4, 0x8003, 5, 0x8004, 6, 3, 0x8002, 4, 0x8003,
    5, 0x8004, 6, 2, 0x8003, 5, 0x8004, 6, 1, 0x8004,
    6, 4, 0x000a, 3, 0x8000, 1, 0x8001, 2, 0x8002, 4,
    2665, 2668, 2671, 2674, 2677, 1, 0x000a, 1, 1, 0x0002,
    2, 1, 0x8000, 3, 1, 0x8001, 4, 1, 0x8002, 5,
    2, 0x8001, 2, 0x8002, 1, 2691, 2706, 2719, 2730, 2737,
    2742, 7, 0x0002, 5, 0x0004, 1, 0x0010, 4, 0x8001, 3,
    0x8002, 3, 0x8004, 2, 0x8005, 6, 6, 0x0002, 5, 0x0010,
    4, 0x8001, 3, 0x8002, 3, 0x8004, 2, 0x8005, 6, 5,
    0x0002, 5, 0x0010, 4, 0x8001, 3, 0x8002, 3, 0x8005, 6,
    3, 0x0002, 5, 0x0010, 4, 0x8005, 6, 2, 0x0002, 5,
    0x8005, 6, 1, 0x8005, 6, 2751, 2766, 2777, 2786, 2793,
    2798, 7, 0x8002, 1, 0x8003, 1, 0x8004, 2, 0x8005, 3,
    0x8006, 5, 0x8007, 6, 0x8008, 4, 5, 0x8004, 2, 0x8005,
    3, 0x8006, 5, 0x8007, 6, 0x8008, 4, 4, 0x8005, 3,
    0x8006, 5, 0x8007, 6, 0x8008, 4, 3, 0x8006, 5, 0x8007,
    6, 0x8008, 4, 2, 0x8006, 5, 0x8007, 6, 1, 0x8007,
    6, 2803, 2810, 3, 0x8002, 1, 0x8003, 1, 0x8004, 2,
    1, 0x8004, 2, 2818, 2821, 2830, 2837, 2842, 1, 0x0004,
    1, 4, 0x000a, 2, 0x8000, 3, 0x8001, 4, 0x8002, 5,
    3, 0x8000, 3, 0x8001, 4, 0x8002, 5, 2, 0x8001, 4,
    0x8002, 5, 1, 0x8002, 5, 2850, 2853, 2856, 2861, 2864,
    1, 0x8000, 1, 1, 0x8001, 2, 2, 0x8002, 3, 0x8003,
    4, 1, 0x8003, 4, 1, 0x8004, 5, 2870, 2873, 2876,
    1, 0x0002, 1, 1, 0x0002, 2, 1, 0x0010, 3, 2882,
    2885, 2890, 1, 0x0003, 1, 2, 0x0003, 2, 0x0010, 3,
    1, 0x0010, 3, 2896, 2899, 2902, 1, 0x0010, 1, 1,
    0x0004, 2, 1, 0x8000, 3, 2908, 2913, 2916, 2, 0x0005,
    1, 0x8001, 2, 1, 0x8001, 2, 1, 0x8002, 3, 1,
    0x8017, 1, 0x0016, 1, 0x8011, 1, 0x8012, 1, 0x8013, 1,
    0x8014, 1, 0x8015, 2940, 2943, 2946, 2951, 2954, 2959, 2962,
    1, 0x0002, 1, 1, 0x8010, 2, 2, 0x8011, 3, 0x8012,
    4, 1, 0x8012, 4, 2, 0x8013, 5, 0x8014, 6, 1,
    0x8014, 6, 1, 0x8015, 7, 2968, 2971, 2974, 1, 0x0004,
    1, 1, 0x0010, 2, 1, 0x8000, 3, 2980, 2983, 2986,
    1, 0x0004, 1, 1, 0x0010, 2, 1, 0x0010, 3, 2994,
    2997, 3000, 3009, 3014, 1, 0x0004, 1, 1, 0x8004, 2,
    4, 0x0010, 4, 0x8001, 3, 0x8002, 3, 0x8005, 5, 2,
    0x0010, 4, 0x8005, 5, 1, 0x8005, 5, 5, 0x8000, 1,
    0x8001, 2, 0x8002, 3, 0x8003, 4, 0x8004, 5, 3035, 3042,
    3045, 3056, 3065, 3072, 3077, 3, 0x8002, 1, 0x8003, 1,
    0x8004, 2, 1, 0x8004, 2, 5, 0x8005, 3, 0x8006, 5,
    0x8007, 6, 0x8008, 4, 0x8009, 7, 4, 0x8006, 5, 0x8007,
    6, 0x8008, 4, 0x8009, 7, 3, 0x8006, 5, 0x8007, 6,
    0x8009, 7, 2, 0x8007, 6, 0x8009, 7, 1, 0x8009, 7,
    3083, 3090, 3093, 3, 0x8002, 1, 0x8003, 1, 0x8004, 2,
    1, 0x8004, 2, 1, 0x0010, 3, 3101, 3104, 3107, 3110,
    3115, 1, 0x0002, 1, 1, 0x0004, 2, 1, 0x000a, 3,
    2, 0x0010, 4, 0x8000, 5, 1, 0x8000, 5, 3122, 3131,
    3136, 3139, 4, 0x0002, 2, 0x0004, 3, 0x8002, 1, 0x8003,
    1, 2, 0x0002, 2, 0x0004, 3, 1, 0x0004, 3, 1,
    0x0010, 4, 3148, 3151, 3154, 3157, 3160, 3165, 1, 0x000a,
    1, 1, 0x0002, 2, 1, 0x8000, 3, 1, 0x8001, 4,
    2, 0x8002, 5, 0x8003, 6, 1, 0x8003, 6, 3171, 3178,
    3183, 3, 0x000a, 1, 0x0010, 2, 0x8001, 3, 2, 0x0010,
    2, 0x8001, 3, 1, 0x8001, 3
};

#if !defined(OSS_SPARTAN_AWARE) || ((OSS_SPARTAN_AWARE + 0) <= 5)
typedef struct OSetTableEntry {
    void *a;
    unsigned short b;
    void *c;
    unsigned short d;
} OSetTableEntry;
#endif /* OSS_SPARTAN_AWARE  <= 5 */

static struct OSetTableEntry const _objectsettable[] = {
#if defined(OSS_SPARTAN_AWARE) && ((OSS_SPARTAN_AWARE + 0) > 12)
    {(void *)MAP2_ExtensionSet, 314, NULL, 0, NULL, -1, -1}
#else
    {(void *)MAP2_ExtensionSet, 314, NULL, 0}
#endif /* OSS_SPARTAN_AWARE  > 12 */
};


#ifdef OSS_SPARTAN_AWARE
#if ((OSS_SPARTAN_AWARE + 0) >= 3)
static void _oss_post_init(struct ossGlobal *world) {
    static const unsigned char _oss_typeinfo[] = {
        0x00, 0x85, 0x33, 0x93, 0x03, 0x94, 0xdd, 0x39, 0x4a, 0x3a,
        0xa2, 0x21, 0x4a, 0x07, 0xa2, 0x6d, 0x8b, 0x18, 0x49, 0x46,
        0x1b, 0xa8, 0x4f, 0x5e, 0x5b, 0x41, 0xf6, 0x50, 0xab, 0x37,
        0x8c, 0x9b, 0xff, 0xeb, 0x76, 0x0b, 0x1f, 0x6f, 0x69, 0x22,
        0x15, 0x33, 0xb7, 0x7d, 0x99, 0x81, 0x7b, 0x27, 0xab, 0x74,
        0xf3, 0x01, 0x3a, 0xa1, 0xb9, 0xf0, 0xd2, 0x81, 0xd6, 0x5d,
        0x00, 0x08, 0x22, 0x43, 0x5c, 0x1d, 0xeb, 0x0b, 0xd7, 0x1c,
        0xf1, 0xcc, 0xe7, 0x16, 0x9c, 0x27, 0xf3, 0xe0, 0x99, 0xa7,
        0x00, 0xc8, 0xd8, 0x1a, 0xbc, 0xcb, 0x61, 0x9b, 0xa7, 0xc5,
        0x46, 0x5f, 0xfe, 0x0e, 0x11, 0xef, 0x10, 0xb5, 0xad, 0xda,
        0x85, 0xf1, 0x74, 0x2a, 0xdd, 0x41, 0xdc, 0xbd, 0xce, 0xf4,
        0x6b, 0x16, 0x02, 0x89, 0xfb, 0x45, 0xc7, 0xe4, 0xdd, 0xe3,
        0x0b, 0x21, 0x51, 0x2f, 0xe8, 0x64, 0xb0, 0x4f, 0x38, 0x66,
        0x41, 0xe6, 0xa4, 0x0a, 0x8f
    };
    ossInitRootContext(world, (unsigned char *)_oss_typeinfo);
#ifdef OSS_SPARTAN_AWARE
#if ((OSS_SPARTAN_AWARE + 0) > 12)
    ossSetExtParms(world, (void *)&extParms);
#endif /* OSS_SPARTAN_AWARE  > 12 */
#endif /* OSS_SPARTAN_AWARE */
}
#endif /* OSS_SPARTAN_AWARE >= 3 */
#endif /* OSS_SPARTAN_AWARE */

static const struct eheader _head = {_ossinit_MAP_DialogueInformation, -1, 15, 2853, 258, 900,
    (unsigned short *)_pduarray, (struct etype *)_etypearray,
    (struct efield *)_efieldarray, (void **)_enamearray, (Etag *)_tagarray,
    NULL, NULL, NULL, 0, (void *)_objectsettable, 1};

#ifdef _OSSGETHEADER
void *DLL_ENTRY_FDEF ossGetHeader()
{
    return (void *)&_head;
}
#endif /* _OSSGETHEADER */

void *MAP_DialogueInformation = (void *)&_head;
#ifdef __cplusplus
}	/* extern "C" */
#endif /* __cplusplus */
