#include <iostream.h>

#include <MAP2Code.h>
#include <MAP2.h>

int main()
{
   int encLen = 0;
   MAP2_MO_ForwardSM_Arg moForwardSM;
   MAP2_MO_ForwardSM_Arg *decMsg = NULL;

   moForwardSM.bit_mask = 0;
   moForwardSM.sm_RP_DA.choice = MAP2_serviceCentreAddressDA_chosen;
   moForwardSM.sm_RP_DA.u.serviceCentreAddressDA.length = 7;
   moForwardSM.sm_RP_DA.u.serviceCentreAddressDA.value[0] = 0x91;
   moForwardSM.sm_RP_DA.u.serviceCentreAddressDA.value[1] = 0x19;
   moForwardSM.sm_RP_DA.u.serviceCentreAddressDA.value[2] = 0x79;
   moForwardSM.sm_RP_DA.u.serviceCentreAddressDA.value[3] = 0x98;
   moForwardSM.sm_RP_DA.u.serviceCentreAddressDA.value[4] = 0x79;
   moForwardSM.sm_RP_DA.u.serviceCentreAddressDA.value[5] = 0x17;
   moForwardSM.sm_RP_DA.u.serviceCentreAddressDA.value[6] = 0x05;

   moForwardSM.sm_RP_OA.choice = MAP2_SM_RP_OA_msisdn_chosen;
   moForwardSM.sm_RP_OA.u.msisdn.length = 8;
   moForwardSM.sm_RP_OA.u.msisdn.value[0] = 0x91;
   moForwardSM.sm_RP_OA.u.msisdn.value[1] = 0x44;
   moForwardSM.sm_RP_OA.u.msisdn.value[2] = 0x57;
   moForwardSM.sm_RP_OA.u.msisdn.value[3] = 0x92;
   moForwardSM.sm_RP_OA.u.msisdn.value[4] = 0x63;
   moForwardSM.sm_RP_OA.u.msisdn.value[5] = 0x35;
   moForwardSM.sm_RP_OA.u.msisdn.value[6] = 0x58;
   moForwardSM.sm_RP_OA.u.msisdn.value[7] = 0xf2;

   moForwardSM.sm_RP_UI.length = 0x17;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x19;
   moForwardSM.sm_RP_UI.value[encLen++] = 0xb1;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x0c;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x91;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x19;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x79;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x98;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x79;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x12;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x34;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x00;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x00;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x08;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x10;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x04;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x18;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x22;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x00;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x22;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x03;
   moForwardSM.sm_RP_UI.value[encLen++] = 0xe2;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x30;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x1b;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x04;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x08;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x24;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x34;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x44;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x55;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x66;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x77;
   moForwardSM.sm_RP_UI.value[encLen++] = 0x88;
   moForwardSM.sm_RP_UI.value[encLen++] = 0xf9;

   unsigned char* L_encodedBuffer = NULL;
   int L_bufferLen=0;
   if(0 == MAP2_encode(&moForwardSM, MAP2_MO_ForwardSM_Arg_PDU, &L_encodedBuffer, &L_bufferLen))
   {
      cout << "Encoded successfully" <<endl;
   }
   else
      cout << "Encoding failed" << MAP2_getErrMsg() << endl;;

   if (MAP2_decode(&L_encodedBuffer, L_bufferLen, MAP2_MO_ForwardSM_Arg_PDU, (void**)&decMsg) == 0 )
   {
      MAP2_printPDU(MAP2_MO_ForwardSM_Arg_PDU, decMsg);
      MAP2_freePDU(MAP2_MO_ForwardSM_Arg_PDU, decMsg);
   }
   else
      cout << "Failed to Decode: " << MAP2_getErrMsg() << endl;
   return 0;
}
