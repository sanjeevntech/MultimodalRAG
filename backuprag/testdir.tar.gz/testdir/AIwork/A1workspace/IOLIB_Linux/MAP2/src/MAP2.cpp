/*************************************************************/
/* Copyright (C) 2010 OSS Nokalva, Inc.  All rights reserved.*/
/*************************************************************/

/* THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC.
 * AND MAY BE USED ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC.
 * THIS FILE MAY NOT BE DISTRIBUTED. */

/* Generated for: Lyca Technologies Solutions Pvt. Ltd., Chennai, India - License 60124 for Solaris 64-bit */
/* Abstract syntax: MAP2 */
/* Created: Fri Jun 11 12:00:09 2010 */
/* ASN.1 compiler version: 8.4 */
/* Code generated for runtime version 8.4 or later */
/* Compiler operating system: Solaris 7 with 64-bit support */
/* Compiler machine type: SPARC */
/* Target operating system: Solaris 7 with 64-bit support */
/* Target machine type: SPARC */
/* C compiler options required: -xarch=v9 */
/* ASN.1 compiler options and file names specified:
 * -prefix MAP2_ -c++ -relaxedMode -ber -root -compat v4.2defaults
 * -compat v4.2octetstringdefault -compat paddedfornamedbits
 * ../../asn1dflt.solaris7-64bit TCAP.asn MAP-ExtensionDataTypes.asn
 * MAP-ShortMessageServiceOperations.asn MAP-BS-Code.asn MAP-GR-DataTypes.asn
 * MAP-SM-DataTypes.asn MAP-CallHandlingOperations.asn
 * MAP-Group-Call-Operations.asn MAP-SS-Code.asn MAP-CH-DataTypes.asn
 * MAP-MobileServiceOperations.asn MAP-SS-DataTypes.asn
 * MAP-CommonDataTypes.asn MAP-MS-DataTypes.asn
 * MAP-SupplementaryServiceOperations.asn MAP-ER-DataTypes.asn
 * MAP-OM-DataTypes.asn MAP-TS-Code.asn MAP-Errors.asn
 * MAP-OperationAndMaintenanceOperations.asn MAP-DialogueInformation.asn
 * MAP2.asn
 */

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */
#define    OSS_SOED_BER
#include   "osstype.h"
#include   "MAP2.h"

#ifndef _OSSNOVALUES

const int MAP2_maxNumOfPrivateExtensions = 10;

MAP2_BearerServiceCode MAP2_allBearerServices = {
    1,
    {
        0x00
    }
};

MAP2_BearerServiceCode MAP2_allDataCDA_Services = {
    1,
    {
        0x10
    }
};

MAP2_BearerServiceCode MAP2_dataCDA_300bps = {
    1,
    {
        0x11
    }
};

MAP2_BearerServiceCode MAP2_dataCDA_1200bps = {
    1,
    {
        0x12
    }
};

MAP2_BearerServiceCode MAP2_dataCDA_1200_75bps = {
    1,
    {
        0x13
    }
};

MAP2_BearerServiceCode MAP2_dataCDA_2400bps = {
    1,
    {
        0x14
    }
};

MAP2_BearerServiceCode MAP2_dataCDA_4800bps = {
    1,
    {
        0x15
    }
};

MAP2_BearerServiceCode MAP2_dataCDA_9600bps = {
    1,
    {
        0x16
    }
};

MAP2_BearerServiceCode MAP2_general_dataCDA = {
    1,
    {
        0x17
    }
};

MAP2_BearerServiceCode MAP2_allDataCDS_Services = {
    1,
    {
        0x18
    }
};

MAP2_BearerServiceCode MAP2_dataCDS_1200bps = {
    1,
    {
        0x1A
    }
};

MAP2_BearerServiceCode MAP2_dataCDS_2400bps = {
    1,
    {
        0x1C
    }
};

MAP2_BearerServiceCode MAP2_dataCDS_4800bps = {
    1,
    {
        0x1D
    }
};

MAP2_BearerServiceCode MAP2_dataCDS_9600bps = {
    1,
    {
        0x1E
    }
};

MAP2_BearerServiceCode MAP2_general_dataCDS = {
    1,
    {
        0x1F
    }
};

MAP2_BearerServiceCode MAP2_allPadAccessCA_Services = {
    1,
    {
        0x20
    }
};

MAP2_BearerServiceCode MAP2_padAccessCA_300bps = {
    1,
    {
        0x21
    }
};

MAP2_BearerServiceCode MAP2_padAccessCA_1200bps = {
    1,
    {
        0x22
    }
};

MAP2_BearerServiceCode MAP2_padAccessCA_1200_75bps = {
    1,
    {
        0x23
    }
};

MAP2_BearerServiceCode MAP2_padAccessCA_2400bps = {
    1,
    {
        0x24
    }
};

MAP2_BearerServiceCode MAP2_padAccessCA_4800bps = {
    1,
    {
        0x25
    }
};

MAP2_BearerServiceCode MAP2_padAccessCA_9600bps = {
    1,
    {
        0x26
    }
};

MAP2_BearerServiceCode MAP2_general_padAccessCA = {
    1,
    {
        0x27
    }
};

MAP2_BearerServiceCode MAP2_allDataPDS_Services = {
    1,
    {
        0x28
    }
};

MAP2_BearerServiceCode MAP2_dataPDS_2400bps = {
    1,
    {
        0x2C
    }
};

MAP2_BearerServiceCode MAP2_dataPDS_4800bps = {
    1,
    {
        0x2D
    }
};

MAP2_BearerServiceCode MAP2_dataPDS_9600bps = {
    1,
    {
        0x2E
    }
};

MAP2_BearerServiceCode MAP2_general_dataPDS = {
    1,
    {
        0x2F
    }
};

MAP2_BearerServiceCode MAP2_allAlternateSpeech_DataCDA = {
    1,
    {
        0x30
    }
};

MAP2_BearerServiceCode MAP2_allAlternateSpeech_DataCDS = {
    1,
    {
        0x38
    }
};

MAP2_BearerServiceCode MAP2_allSpeechFollowedByDataCDA = {
    1,
    {
        0x40
    }
};

MAP2_BearerServiceCode MAP2_allSpeechFollowedByDataCDS = {
    1,
    {
        0x48
    }
};

MAP2_BearerServiceCode MAP2_allDataCircuitAsynchronous = {
    1,
    {
        0x50
    }
};

MAP2_BearerServiceCode MAP2_allAsynchronousServices = {
    1,
    {
        0x60
    }
};

MAP2_BearerServiceCode MAP2_allDataCircuitSynchronous = {
    1,
    {
        0x58
    }
};

MAP2_BearerServiceCode MAP2_allSynchronousServices = {
    1,
    {
        0x68
    }
};

MAP2_BearerServiceCode MAP2_allPLMN_specificBS = {
    1,
    {
        0xD0
    }
};

MAP2_BearerServiceCode MAP2_plmn_specificBS_1 = {
    1,
    {
        0xD1
    }
};

MAP2_BearerServiceCode MAP2_plmn_specificBS_2 = {
    1,
    {
        0xD2
    }
};

MAP2_BearerServiceCode MAP2_plmn_specificBS_3 = {
    1,
    {
        0xD3
    }
};

MAP2_BearerServiceCode MAP2_plmn_specificBS_4 = {
    1,
    {
        0xD4
    }
};

MAP2_BearerServiceCode MAP2_plmn_specificBS_5 = {
    1,
    {
        0xD5
    }
};

MAP2_BearerServiceCode MAP2_plmn_specificBS_6 = {
    1,
    {
        0xD6
    }
};

MAP2_BearerServiceCode MAP2_plmn_specificBS_7 = {
    1,
    {
        0xD7
    }
};

MAP2_BearerServiceCode MAP2_plmn_specificBS_8 = {
    1,
    {
        0xD8
    }
};

MAP2_BearerServiceCode MAP2_plmn_specificBS_9 = {
    1,
    {
        0xD9
    }
};

MAP2_BearerServiceCode MAP2_plmn_specificBS_A = {
    1,
    {
        0xDA
    }
};

MAP2_BearerServiceCode MAP2_plmn_specificBS_B = {
    1,
    {
        0xDB
    }
};

MAP2_BearerServiceCode MAP2_plmn_specificBS_C = {
    1,
    {
        0xDC
    }
};

MAP2_BearerServiceCode MAP2_plmn_specificBS_D = {
    1,
    {
        0xDD
    }
};

MAP2_BearerServiceCode MAP2_plmn_specificBS_E = {
    1,
    {
        0xDE
    }
};

MAP2_BearerServiceCode MAP2_plmn_specificBS_F = {
    1,
    {
        0xDF
    }
};

MAP2_SS_Code MAP2_allSS = {
    1,
    {
        0x00
    }
};

MAP2_SS_Code MAP2_allLineIdentificationSS = {
    1,
    {
        0x10
    }
};

MAP2_SS_Code MAP2_clip = {
    1,
    {
        0x11
    }
};

MAP2_SS_Code MAP2_clir = {
    1,
    {
        0x12
    }
};

MAP2_SS_Code MAP2_colp = {
    1,
    {
        0x13
    }
};

MAP2_SS_Code MAP2_colr = {
    1,
    {
        0x14
    }
};

MAP2_SS_Code MAP2_mci = {
    1,
    {
        0x15
    }
};

MAP2_SS_Code MAP2_allNameIdentificationSS = {
    1,
    {
        0x18
    }
};

MAP2_SS_Code MAP2_cnap = {
    1,
    {
        0x19
    }
};

MAP2_SS_Code MAP2_allForwardingSS = {
    1,
    {
        0x20
    }
};

MAP2_SS_Code MAP2_cfu = {
    1,
    {
        0x21
    }
};

MAP2_SS_Code MAP2_allCondForwardingSS = {
    1,
    {
        0x28
    }
};

MAP2_SS_Code MAP2_cfb = {
    1,
    {
        0x29
    }
};

MAP2_SS_Code MAP2_cfnry = {
    1,
    {
        0x2A
    }
};

MAP2_SS_Code MAP2_cfnrc = {
    1,
    {
        0x2B
    }
};

MAP2_SS_Code MAP2_cd = {
    1,
    {
        0x24
    }
};

MAP2_SS_Code MAP2_allCallOfferingSS = {
    1,
    {
        0x30
    }
};

MAP2_SS_Code MAP2_ect = {
    1,
    {
        0x31
    }
};

MAP2_SS_Code MAP2_mah = {
    1,
    {
        0x32
    }
};

MAP2_SS_Code MAP2_allCallCompletionSS = {
    1,
    {
        0x40
    }
};

MAP2_SS_Code MAP2_cw = {
    1,
    {
        0x41
    }
};

MAP2_SS_Code MAP2_hold = {
    1,
    {
        0x42
    }
};

MAP2_SS_Code MAP2_ccbs_A = {
    1,
    {
        0x43
    }
};

MAP2_SS_Code MAP2_ccbs_B = {
    1,
    {
        0x44
    }
};

MAP2_SS_Code MAP2_allMultiPartySS = {
    1,
    {
        0x50
    }
};

MAP2_SS_Code MAP2_multiPTY = {
    1,
    {
        0x51
    }
};

MAP2_SS_Code MAP2_allCommunityOfInterest_SS = {
    1,
    {
        0x60
    }
};

MAP2_SS_Code MAP2_cug = {
    1,
    {
        0x61
    }
};

MAP2_SS_Code MAP2_allChargingSS = {
    1,
    {
        0x70
    }
};

MAP2_SS_Code MAP2_aoci = {
    1,
    {
        0x71
    }
};

MAP2_SS_Code MAP2_aocc = {
    1,
    {
        0x72
    }
};

MAP2_SS_Code MAP2_allAdditionalInfoTransferSS = {
    1,
    {
        0x80
    }
};

MAP2_SS_Code MAP2_uus = {
    1,
    {
        0x81
    }
};

MAP2_SS_Code MAP2_allBarringSS = {
    1,
    {
        0x90
    }
};

MAP2_SS_Code MAP2_barringOfOutgoingCalls = {
    1,
    {
        0x91
    }
};

MAP2_SS_Code MAP2_baoc = {
    1,
    {
        0x92
    }
};

MAP2_SS_Code MAP2_boic = {
    1,
    {
        0x93
    }
};

MAP2_SS_Code MAP2_boicExHC = {
    1,
    {
        0x94
    }
};

MAP2_SS_Code MAP2_barringOfIncomingCalls = {
    1,
    {
        0x99
    }
};

MAP2_SS_Code MAP2_baic = {
    1,
    {
        0x9A
    }
};

MAP2_SS_Code MAP2_bicRoam = {
    1,
    {
        0x9B
    }
};

MAP2_SS_Code MAP2_allPLMN_specificSS = {
    1,
    {
        0xF0
    }
};

MAP2_SS_Code MAP2_plmn_specificSS_1 = {
    1,
    {
        0xF1
    }
};

MAP2_SS_Code MAP2_plmn_specificSS_2 = {
    1,
    {
        0xF2
    }
};

MAP2_SS_Code MAP2_plmn_specificSS_3 = {
    1,
    {
        0xF3
    }
};

MAP2_SS_Code MAP2_plmn_specificSS_4 = {
    1,
    {
        0xF4
    }
};

MAP2_SS_Code MAP2_plmn_specificSS_5 = {
    1,
    {
        0xF5
    }
};

MAP2_SS_Code MAP2_plmn_specificSS_6 = {
    1,
    {
        0xF6
    }
};

MAP2_SS_Code MAP2_plmn_specificSS_7 = {
    1,
    {
        0xF7
    }
};

MAP2_SS_Code MAP2_plmn_specificSS_8 = {
    1,
    {
        0xF8
    }
};

MAP2_SS_Code MAP2_plmn_specificSS_9 = {
    1,
    {
        0xF9
    }
};

MAP2_SS_Code MAP2_plmn_specificSS_A = {
    1,
    {
        0xFA
    }
};

MAP2_SS_Code MAP2_plmn_specificSS_B = {
    1,
    {
        0xFB
    }
};

MAP2_SS_Code MAP2_plmn_specificSS_C = {
    1,
    {
        0xFC
    }
};

MAP2_SS_Code MAP2_plmn_specificSS_D = {
    1,
    {
        0xFD
    }
};

MAP2_SS_Code MAP2_plmn_specificSS_E = {
    1,
    {
        0xFE
    }
};

MAP2_SS_Code MAP2_plmn_specificSS_F = {
    1,
    {
        0xFF
    }
};

MAP2_SS_Code MAP2_allCallPrioritySS = {
    1,
    {
        0xA0
    }
};

MAP2_SS_Code MAP2_emlpp = {
    1,
    {
        0xA1
    }
};

const int MAP2_SS_DataTypes_maxNumOfCUG = 10;

const int MAP2_maxNumOfCCBS_Requests = 5;

const int MAP2_maxUSSD_StringLength = 160;

const int MAP2_maxNumOfSS = 30;

const int MAP2_maxNumOfBasicServiceGroups = 13;

const int MAP2_maxEventSpecification = 2;

const int MAP2_maxAddressLength = 20;

const int MAP2_maxISDN_AddressLength = 9;

const int MAP2_maxFTN_AddressLength = 15;

const int MAP2_maxISDN_SubaddressLength = 21;

const int MAP2_maxSignalInfoLength = 200;

MAP2_AlertingPattern MAP2_alertingLevel_0 = {
    1,
    {
        0x00
    }
};

MAP2_AlertingPattern MAP2_alertingLevel_1 = {
    1,
    {
        0x01
    }
};

MAP2_AlertingPattern MAP2_alertingLevel_2 = {
    1,
    {
        0x02
    }
};

MAP2_AlertingPattern MAP2_alertingCategory_1 = {
    1,
    {
        0x04
    }
};

MAP2_AlertingPattern MAP2_alertingCategory_2 = {
    1,
    {
        0x05
    }
};

MAP2_AlertingPattern MAP2_alertingCategory_3 = {
    1,
    {
        0x06
    }
};

MAP2_AlertingPattern MAP2_alertingCategory_4 = {
    1,
    {
        0x07
    }
};

MAP2_AlertingPattern MAP2_alertingCategory_5 = {
    1,
    {
        0x08
    }
};

const int MAP2_maxNumOfHLR_Id = 50;

const int MAP2_maxNumOfMC_Bearers = 7;

const MAP2_EMLPP_Priority MAP2_priorityLevelA = 6;

const MAP2_EMLPP_Priority MAP2_priorityLevelB = 5;

const MAP2_EMLPP_Priority MAP2_priorityLevel0 = 0;

const MAP2_EMLPP_Priority MAP2_priorityLevel1 = 1;

const MAP2_EMLPP_Priority MAP2_priorityLevel2 = 2;

const MAP2_EMLPP_Priority MAP2_priorityLevel3 = 3;

const MAP2_EMLPP_Priority MAP2_priorityLevel4 = 4;

const int MAP2_maxNumOfBearerServices = 50;

const int MAP2_maxNumOfTeleservices = 20;

const int MAP2_MS_DataTypes_maxNumOfCUG = 10;

const int MAP2_maxNumOfExt_BasicServiceGroups = 32;

const int MAP2_maxNumOfZoneCodes = 10;

const int MAP2_maxNumOfBasicServices = 70;

const int MAP2_maxNumOfVBSGroupIds = 50;

const int MAP2_maxNumOfVGCSGroupIds = 50;

MAP2_TeleserviceCode MAP2_allTeleservices = {
    1,
    {
        0x00
    }
};

MAP2_TeleserviceCode MAP2_allSpeechTransmissionServices = {
    1,
    {
        0x10
    }
};

MAP2_TeleserviceCode MAP2_telephony = {
    1,
    {
        0x11
    }
};

MAP2_TeleserviceCode MAP2_emergencyCalls = {
    1,
    {
        0x12
    }
};

MAP2_TeleserviceCode MAP2_allShortMessageServices = {
    1,
    {
        0x20
    }
};

MAP2_TeleserviceCode MAP2_shortMessageMT_PP = {
    1,
    {
        0x21
    }
};

MAP2_TeleserviceCode MAP2_shortMessageMO_PP = {
    1,
    {
        0x22
    }
};

MAP2_TeleserviceCode MAP2_allFacsimileTransmissionServices = {
    1,
    {
        0x60
    }
};

MAP2_TeleserviceCode MAP2_facsimileGroup3AndAlterSpeech = {
    1,
    {
        0x61
    }
};

MAP2_TeleserviceCode MAP2_automaticFacsimileGroup3 = {
    1,
    {
        0x62
    }
};

MAP2_TeleserviceCode MAP2_facsimileGroup4 = {
    1,
    {
        0x63
    }
};

MAP2_TeleserviceCode MAP2_allDataTeleservices = {
    1,
    {
        0x70
    }
};

MAP2_TeleserviceCode MAP2_allTeleservices_ExeptSMS = {
    1,
    {
        0x80
    }
};

MAP2_TeleserviceCode MAP2_allVoiceGroupCallServices = {
    1,
    {
        0x90
    }
};

MAP2_TeleserviceCode MAP2_voiceGroupCall = {
    1,
    {
        0x91
    }
};

MAP2_TeleserviceCode MAP2_voiceBroadcastCall = {
    1,
    {
        0x92
    }
};

MAP2_TeleserviceCode MAP2_allPLMN_specificTS = {
    1,
    {
        0xD0
    }
};

MAP2_TeleserviceCode MAP2_plmn_specificTS_1 = {
    1,
    {
        0xD1
    }
};

MAP2_TeleserviceCode MAP2_plmn_specificTS_2 = {
    1,
    {
        0xD2
    }
};

MAP2_TeleserviceCode MAP2_plmn_specificTS_3 = {
    1,
    {
        0xD3
    }
};

MAP2_TeleserviceCode MAP2_plmn_specificTS_4 = {
    1,
    {
        0xD4
    }
};

MAP2_TeleserviceCode MAP2_plmn_specificTS_5 = {
    1,
    {
        0xD5
    }
};

MAP2_TeleserviceCode MAP2_plmn_specificTS_6 = {
    1,
    {
        0xD6
    }
};

MAP2_TeleserviceCode MAP2_plmn_specificTS_7 = {
    1,
    {
        0xD7
    }
};

MAP2_TeleserviceCode MAP2_plmn_specificTS_8 = {
    1,
    {
        0xD8
    }
};

MAP2_TeleserviceCode MAP2_plmn_specificTS_9 = {
    1,
    {
        0xD9
    }
};

MAP2_TeleserviceCode MAP2_plmn_specificTS_A = {
    1,
    {
        0xDA
    }
};

MAP2_TeleserviceCode MAP2_plmn_specificTS_B = {
    1,
    {
        0xDB
    }
};

MAP2_TeleserviceCode MAP2_plmn_specificTS_C = {
    1,
    {
        0xDC
    }
};

MAP2_TeleserviceCode MAP2_plmn_specificTS_D = {
    1,
    {
        0xDD
    }
};

MAP2_TeleserviceCode MAP2_plmn_specificTS_E = {
    1,
    {
        0xDE
    }
};

MAP2_TeleserviceCode MAP2_plmn_specificTS_F = {
    1,
    {
        0xDF
    }
};

static struct MAP2__ObjectID_ _v0[] = {
    {&_v0[1], 0},
    {&_v0[2], 4},
    {&_v0[3], 0},
    {&_v0[4], 0},
    {&_v0[5], 1},
    {&_v0[6], 1},
    {&_v0[7], 1},
    {NULL, 1}
};
MAP2__ObjectID MAP2_map_DialogueAS = _v0;

MAP2_UpdateLocation MAP2_updateLocation = {
    MAP2_localValue_chosen
};

MAP2_CancelLocation MAP2_cancelLocation = {
    MAP2_localValue_chosen
};

MAP2_PurgeMS MAP2_purgeMS = {
    MAP2_localValue_chosen
};

MAP2_SendIdentification MAP2_sendIdentification = {
    MAP2_localValue_chosen
};

MAP2_PrepareHandover MAP2_prepareHandover = {
    MAP2_localValue_chosen
};

MAP2_SendEndSignal MAP2_sendEndSignal = {
    MAP2_localValue_chosen
};

MAP2_ProcessAccessSignalling MAP2_processAccessSignalling = {
    MAP2_localValue_chosen
};

MAP2_ForwardAccessSignalling MAP2_forwardAccessSignalling = {
    MAP2_localValue_chosen
};

MAP2_PrepareSubsequentHandover MAP2_prepareSubsequentHandover = {
    MAP2_localValue_chosen
};

MAP2_SendAuthenticationInfo MAP2_sendAuthenticationInfo = {
    MAP2_localValue_chosen
};

MAP2_CheckIMEI MAP2_checkIMEI = {
    MAP2_localValue_chosen
};

MAP2_InsertSubscriberData MAP2_insertSubscriberData = {
    MAP2_localValue_chosen
};

MAP2_DeleteSubscriberData MAP2_deleteSubscriberData = {
    MAP2_localValue_chosen
};

MAP2_Reset MAP2_reset = {
    MAP2_localValue_chosen
};

MAP2_RestoreData MAP2_restoreData = {
    MAP2_localValue_chosen
};

MAP2_ActivateTraceMode MAP2_activateTraceMode = {
    MAP2_localValue_chosen
};

MAP2_DeactivateTraceMode MAP2_deactivateTraceMode = {
    MAP2_localValue_chosen
};

MAP2_SendIMSI MAP2_sendIMSI = {
    MAP2_localValue_chosen
};

MAP2_SendRoutingInfo MAP2_sendRoutingInfo = {
    MAP2_localValue_chosen
};

MAP2_ProvideRoamingNumber MAP2_provideRoamingNumber = {
    MAP2_localValue_chosen
};

MAP2_ResumeCallHandling MAP2_resumeCallHandling = {
    MAP2_localValue_chosen
};

MAP2_ProvideSIWFSNumber MAP2_provideSIWFSNumber = {
    MAP2_localValue_chosen
};

MAP2_SIWFSSignallingModify MAP2_sIWFSSignallingModify = {
    MAP2_localValue_chosen
};

MAP2_RegisterSS MAP2_registerSS = {
    MAP2_localValue_chosen
};

MAP2_EraseSS MAP2_eraseSS = {
    MAP2_localValue_chosen
};

MAP2_ActivateSS MAP2_activateSS = {
    MAP2_localValue_chosen
};

MAP2_DeactivateSS MAP2_deactivateSS = {
    MAP2_localValue_chosen
};

MAP2_InterrogateSS MAP2_interrogateSS = {
    MAP2_localValue_chosen
};

MAP2_ProcessUnstructuredSS_Request MAP2_processUnstructuredSS_Request = {
    MAP2_localValue_chosen
};

MAP2_UnstructuredSS_Request MAP2_unstructuredSS_Request = {
    MAP2_localValue_chosen
};

MAP2_UnstructuredSS_Notify MAP2_unstructuredSS_Notify = {
    MAP2_localValue_chosen
};

MAP2_RegisterPassword MAP2_registerPassword = {
    MAP2_localValue_chosen
};

MAP2_GetPassword MAP2_getPassword = {
    MAP2_localValue_chosen
};

MAP2_SendRoutingInfoForSM MAP2_sendRoutingInfoForSM = {
    MAP2_localValue_chosen
};

MAP2_MO_ForwardSM MAP2_mo_forwardSM = {
    MAP2_localValue_chosen
};

MAP2_MT_ForwardSM MAP2_mt_forwardSM = {
    MAP2_localValue_chosen
};

MAP2_ReportSM_DeliveryStatus MAP2_reportSM_DeliveryStatus = {
    MAP2_localValue_chosen
};

MAP2_InformServiceCentre MAP2_informServiceCentre = {
    MAP2_localValue_chosen
};

MAP2_AlertServiceCentre MAP2_alertServiceCentre = {
    MAP2_localValue_chosen
};

MAP2_ReadyForSM MAP2_readyForSM = {
    MAP2_localValue_chosen
};

MAP2_PrepareGroupCall MAP2_prepareGroupCall = {
    MAP2_localValue_chosen
};

MAP2_SendGroupCallEndSignal MAP2_sendGroupCallEndSignal = {
    MAP2_localValue_chosen
};

MAP2_ProcessGroupCallSignalling MAP2_processGroupCallSignalling = {
    MAP2_localValue_chosen
};

MAP2_ForwardGroupCallSignalling MAP2_forwardGroupCallSignalling = {
    MAP2_localValue_chosen
};

MAP2_SystemFailure MAP2_systemFailure = {
    MAP2_localValue_chosen
};

MAP2_DataMissing MAP2_dataMissing = {
    MAP2_localValue_chosen
};

MAP2_UnexpectedDataValue MAP2_unexpectedDataValue = {
    MAP2_localValue_chosen
};

MAP2_FacilityNotSupported MAP2_facilityNotSupported = {
    MAP2_localValue_chosen
};

MAP2_IncompatibleTerminal MAP2_incompatibleTerminal = {
    MAP2_localValue_chosen
};

MAP2_ResourceLimitation MAP2_resourceLimitation = {
    MAP2_localValue_chosen
};

MAP2_UnknownSubscriber MAP2_unknownSubscriber = {
    MAP2_localValue_chosen
};

MAP2_NumberChanged MAP2_numberChanged = {
    MAP2_localValue_chosen
};

MAP2_UnknownMSC MAP2_unknownMSC = {
    MAP2_localValue_chosen
};

MAP2_UnidentifiedSubscriber MAP2_unidentifiedSubscriber = {
    MAP2_localValue_chosen
};

MAP2_UnknownEquipment MAP2_unknownEquipment = {
    MAP2_localValue_chosen
};

MAP2_RoamingNotAllowed MAP2_roamingNotAllowed = {
    MAP2_localValue_chosen
};

MAP2_IllegalSubscriber MAP2_illegalSubscriber = {
    MAP2_localValue_chosen
};

MAP2_IllegalEquipment MAP2_illegalEquipment = {
    MAP2_localValue_chosen
};

MAP2_BearerServiceNotProvisioned MAP2_bearerServiceNotProvisioned = {
    MAP2_localValue_chosen
};

MAP2_TeleserviceNotProvisioned MAP2_teleserviceNotProvisioned = {
    MAP2_localValue_chosen
};

MAP2_NoHandoverNumberAvailable MAP2_noHandoverNumberAvailable = {
    MAP2_localValue_chosen
};

MAP2_SubsequentHandoverFailure MAP2_subsequentHandoverFailure = {
    MAP2_localValue_chosen
};

MAP2_TracingBufferFull MAP2_tracingBufferFull = {
    MAP2_localValue_chosen
};

MAP2_NoRoamingNumberAvailable MAP2_noRoamingNumberAvailable = {
    MAP2_localValue_chosen
};

MAP2_AbsentSubscriber MAP2_absentSubscriber = {
    MAP2_localValue_chosen
};

MAP2_BusySubscriber MAP2_busySubscriber = {
    MAP2_localValue_chosen
};

MAP2_NoSubscriberReply MAP2_noSubscriberReply = {
    MAP2_localValue_chosen
};

MAP2_CallBarred MAP2_callBarred = {
    MAP2_localValue_chosen
};

MAP2_ForwardingFailed MAP2_forwardingFailed = {
    MAP2_localValue_chosen
};

MAP2_OR_NotAllowed MAP2_or_NotAllowed = {
    MAP2_localValue_chosen
};

MAP2_ForwardingViolation MAP2_forwardingViolation = {
    MAP2_localValue_chosen
};

MAP2_CUG_Reject MAP2_cug_Reject = {
    MAP2_localValue_chosen
};

MAP2_ATI_NotAllowed MAP2_ati_NotAllowed = {
    MAP2_localValue_chosen
};

MAP2_NoGroupCallNumberAvailable MAP2_noGroupCallNumberAvailable = {
    MAP2_localValue_chosen
};

MAP2_IllegalSS_Operation MAP2_illegalSS_Operation = {
    MAP2_localValue_chosen
};

MAP2_SS_ErrorStatus MAP2_ss_ErrorStatus = {
    MAP2_localValue_chosen
};

MAP2_SS_NotAvailable MAP2_ss_NotAvailable = {
    MAP2_localValue_chosen
};

MAP2_SS_SubscriptionViolation MAP2_ss_SubscriptionViolation = {
    MAP2_localValue_chosen
};

MAP2_SS_Incompatibility MAP2_ss_Incompatibility = {
    MAP2_localValue_chosen
};

MAP2_UnknownAlphabet MAP2_unknownAlphabet = {
    MAP2_localValue_chosen
};

MAP2_USSD_Busy MAP2_ussd_Busy = {
    MAP2_localValue_chosen
};

MAP2_PW_RegistrationFailure MAP2_pw_RegistrationFailure = {
    MAP2_localValue_chosen
};

MAP2_NegativePW_Check MAP2_negativePW_Check = {
    MAP2_localValue_chosen
};

MAP2_NumberOfPW_AttemptsViolation MAP2_numberOfPW_AttemptsViolation = {
    MAP2_localValue_chosen
};

MAP2_ShortTermDenial MAP2_shortTermDenial = {
    MAP2_localValue_chosen
};

MAP2_LongTermDenial MAP2_longTermDenial = {
    MAP2_localValue_chosen
};

MAP2_SubscriberBusyForMT_SMS MAP2_subscriberBusyForMT_SMS = {
    MAP2_localValue_chosen
};

MAP2_SM_DeliveryFailure MAP2_sm_DeliveryFailure = {
    MAP2_localValue_chosen
};

MAP2_MessageWaitingListFull MAP2_messageWaitingListFull = {
    MAP2_localValue_chosen
};

MAP2_AbsentSubscriberSM MAP2_absentsubscriberSM = {
    MAP2_localValue_chosen
};


#if !defined(OSS_SPARTAN_AWARE) || ((OSS_SPARTAN_AWARE + 0) < 2)
static ObjectSetEntry const MAP2_ExtensionSet[] = {
{0}};

#else /* OSS_SPARTAN_AWARE >= 2 */

#if ((OSS_SPARTAN_AWARE + 0) > 12)
static ObjectSetEntry const MAP2_ExtensionSet[] = {
{0}};
#else /* OSS_SPARTAN_AWARE <= 12 */
static ObjectSetEntry const MAP2_ExtensionSet[] = {
{0}};
#endif /* (OSS_SPARTAN_AWARE + 0) > 12 */

static unsigned short const _oss_OSet_info[] =  {
    4
};
#endif /* !OSS_SPARTAN_AWARE || OSS_SPARTAN_AWARE < 2 */

#endif  /* #ifndef _OSSNOVALUES */

#ifdef OSS_SPARTAN_AWARE
#if ((OSS_SPARTAN_AWARE + 0) >= 3)
extern void _oss_run_SOED_on_SPARC_SOLARIS_7_64BIT(void);
static void _oss_post_init(struct ossGlobal *world);
#endif /* OSS_SPARTAN_AWARE >= 3 */
#endif /* OSS_SPARTAN_AWARE */

#ifdef OSS_SPARTAN_AWARE
#if ((OSS_SPARTAN_AWARE + 0) >= 12)
static unsigned char _privateFlags[] = {0x01,0x00};
#endif /* OSS_SPARTAN_AWARE >= 12 */
#endif /* OSS_SPARTAN_AWARE */

static void _ossinit_MAP2(struct ossGlobal *world) {
#ifndef _OSSNOVALUES

    MAP2_updateLocation.u.localValue = 2;
    MAP2_cancelLocation.u.localValue = 3;
    MAP2_purgeMS.u.localValue = 67;
    MAP2_sendIdentification.u.localValue = 55;
    MAP2_prepareHandover.u.localValue = 68;
    MAP2_sendEndSignal.u.localValue = 29;
    MAP2_processAccessSignalling.u.localValue = 33;
    MAP2_forwardAccessSignalling.u.localValue = 34;
    MAP2_prepareSubsequentHandover.u.localValue = 69;
    MAP2_sendAuthenticationInfo.u.localValue = 56;
    MAP2_checkIMEI.u.localValue = 43;
    MAP2_insertSubscriberData.u.localValue = 7;
    MAP2_deleteSubscriberData.u.localValue = 8;
    MAP2_reset.u.localValue = 37;
    MAP2_restoreData.u.localValue = 57;
    MAP2_activateTraceMode.u.localValue = 50;
    MAP2_deactivateTraceMode.u.localValue = 51;
    MAP2_sendIMSI.u.localValue = 58;
    MAP2_sendRoutingInfo.u.localValue = 22;
    MAP2_provideRoamingNumber.u.localValue = 4;
    MAP2_resumeCallHandling.u.localValue = 6;
    MAP2_provideSIWFSNumber.u.localValue = 31;
    MAP2_sIWFSSignallingModify.u.localValue = 32;
    MAP2_registerSS.u.localValue = 10;
    MAP2_eraseSS.u.localValue = 11;
    MAP2_activateSS.u.localValue = 12;
    MAP2_deactivateSS.u.localValue = 13;
    MAP2_interrogateSS.u.localValue = 14;
    MAP2_processUnstructuredSS_Request.u.localValue = 59;
    MAP2_unstructuredSS_Request.u.localValue = 60;
    MAP2_unstructuredSS_Notify.u.localValue = 61;
    MAP2_registerPassword.u.localValue = 17;
    MAP2_getPassword.u.localValue = 18;
    MAP2_sendRoutingInfoForSM.u.localValue = 45;
    MAP2_mo_forwardSM.u.localValue = 46;
    MAP2_mt_forwardSM.u.localValue = 44;
    MAP2_reportSM_DeliveryStatus.u.localValue = 47;
    MAP2_informServiceCentre.u.localValue = 63;
    MAP2_alertServiceCentre.u.localValue = 64;
    MAP2_readyForSM.u.localValue = 66;
    MAP2_prepareGroupCall.u.localValue = 39;
    MAP2_sendGroupCallEndSignal.u.localValue = 40;
    MAP2_processGroupCallSignalling.u.localValue = 41;
    MAP2_forwardGroupCallSignalling.u.localValue = 42;
    MAP2_systemFailure.u.localValue = 34;
    MAP2_dataMissing.u.localValue = 35;
    MAP2_unexpectedDataValue.u.localValue = 36;
    MAP2_facilityNotSupported.u.localValue = 21;
    MAP2_incompatibleTerminal.u.localValue = 28;
    MAP2_resourceLimitation.u.localValue = 51;
    MAP2_unknownSubscriber.u.localValue = 1;
    MAP2_numberChanged.u.localValue = 44;
    MAP2_unknownMSC.u.localValue = 3;
    MAP2_unidentifiedSubscriber.u.localValue = 5;
    MAP2_unknownEquipment.u.localValue = 7;
    MAP2_roamingNotAllowed.u.localValue = 8;
    MAP2_illegalSubscriber.u.localValue = 9;
    MAP2_illegalEquipment.u.localValue = 12;
    MAP2_bearerServiceNotProvisioned.u.localValue = 10;
    MAP2_teleserviceNotProvisioned.u.localValue = 11;
    MAP2_noHandoverNumberAvailable.u.localValue = 25;
    MAP2_subsequentHandoverFailure.u.localValue = 26;
    MAP2_tracingBufferFull.u.localValue = 40;
    MAP2_noRoamingNumberAvailable.u.localValue = 39;
    MAP2_absentSubscriber.u.localValue = 27;
    MAP2_busySubscriber.u.localValue = 45;
    MAP2_noSubscriberReply.u.localValue = 46;
    MAP2_callBarred.u.localValue = 13;
    MAP2_forwardingFailed.u.localValue = 47;
    MAP2_or_NotAllowed.u.localValue = 48;
    MAP2_forwardingViolation.u.localValue = 14;
    MAP2_cug_Reject.u.localValue = 15;
    MAP2_ati_NotAllowed.u.localValue = 49;
    MAP2_noGroupCallNumberAvailable.u.localValue = 50;
    MAP2_illegalSS_Operation.u.localValue = 16;
    MAP2_ss_ErrorStatus.u.localValue = 17;
    MAP2_ss_NotAvailable.u.localValue = 18;
    MAP2_ss_SubscriptionViolation.u.localValue = 19;
    MAP2_ss_Incompatibility.u.localValue = 20;
    MAP2_unknownAlphabet.u.localValue = 71;
    MAP2_ussd_Busy.u.localValue = 72;
    MAP2_pw_RegistrationFailure.u.localValue = 37;
    MAP2_negativePW_Check.u.localValue = 38;
    MAP2_numberOfPW_AttemptsViolation.u.localValue = 43;
    MAP2_shortTermDenial.u.localValue = 29;
    MAP2_longTermDenial.u.localValue = 30;
    MAP2_subscriberBusyForMT_SMS.u.localValue = 31;
    MAP2_sm_DeliveryFailure.u.localValue = 32;
    MAP2_messageWaitingListFull.u.localValue = 33;
    MAP2_absentsubscriberSM.u.localValue = 6;
#endif  /* #ifdef _OSSNOVALUES */

#ifdef OSS_SPARTAN_AWARE
#if ((OSS_SPARTAN_AWARE + 0) >= 3)
    _oss_run_SOED_on_SPARC_SOLARIS_7_64BIT();
#endif /* OSS_SPARTAN_AWARE >= 3 */
#endif /* OSS_SPARTAN_AWARE */
#ifdef OSS_SPARTAN_AWARE
#if ((OSS_SPARTAN_AWARE + 0) >= 12)
    ossPrivateSetMoreFlags(world, 12, _privateFlags);
#endif /* OSS_SPARTAN_AWARE >= 12 */
#endif /* OSS_SPARTAN_AWARE */
    ossLinkBer(world);
#ifdef OSS_SPARTAN_AWARE
    ossLinkCmpValue(world);
#if ((OSS_SPARTAN_AWARE + 0) >= 2)
    ossInitObjectSetInfo(world, (unsigned short *)_oss_OSet_info);
#endif /* OSS_SPARTAN_AWARE >= 2 */
#endif /* OSS_SPARTAN_AWARE */

#ifdef OSS_SPARTAN_AWARE
#if ((OSS_SPARTAN_AWARE + 0) >= 3)
    _oss_post_init(world);
#endif /* OSS_SPARTAN_AWARE >= 3 */
#endif /* OSS_SPARTAN_AWARE */
}

static int const _v35[8] = {
  0, 1, 2, 3, 4, 5, 6, 7
};
static int const _v45[4] = {
  0, 1, 5, 7
};
static int const _v24[4] = {
  1, 2, 3, 4
};
static int const _v43[2] = {0, 3};
static int const _v50[1] = {INT_MAX};
static unsigned char const _v38[1] = {0xf};
static unsigned char const _v37[1] = {0x3};
static unsigned char const _v34[1] = {0x3f};
static unsigned char const _v22[1] = {0x1f};

static const unsigned short _pduarray[] = {
    1, 2, 3, 4, 5, 6, 7, 8, 9, 10,
    11, 12, 13, 14, 15, 16, 17, 18, 19, 20,
    21, 22, 23, 24, 25, 26, 27, 28, 29, 30,
    31, 32, 33, 34, 35, 36, 37, 38, 39, 40,
    41, 42, 43, 44, 45, 46, 47, 48, 49, 50,
    51, 52, 53, 54, 55, 56, 57, 58, 59, 60,
    61, 62, 63, 64, 65, 66, 67, 68, 69, 70,
    71, 72, 73, 74, 75, 76, 77, 78, 79, 80,
    81, 82, 83, 84, 85, 86, 87, 88, 89, 90,
    91, 92, 93, 94, 95, 96, 97, 98, 99, 100,
    101, 102, 103, 104, 105, 106, 107, 108, 109, 110,
    111, 112, 113, 114, 115, 116, 117, 118, 119, 120,
    121, 122, 123, 124, 125, 126, 127, 128, 129, 130,
    131, 132, 133, 134, 135, 136, 137, 138, 139, 140,
    141, 142, 143, 144, 145, 146, 147, 148, 149, 150,
    151, 152, 153, 154, 155, 156, 157, 158, 159, 160,
    161, 162, 163, 164, 165, 166, 167, 168, 169, 170,
    171, 172, 173, 174, 175, 176, 177, 178, 179, 180,
    181, 182, 183, 184, 185, 186, 187, 188, 189, 190,
    191, 192, 193, 194, 195, 196, 197, 198, 199, 200,
    201, 202, 203, 204, 205, 206, 207, 208, 209, 210,
    211, 212, 213, 214, 215, 216, 217, 218, 219, 220,
    221, 222, 223, 224, 225, 226, 227, 228, 229, 230,
    231, 232, 233, 234, 235, 236, 0
};

static const struct etype _etypearray[] = {
    {-1, 0, 0, (char *)"_ObjectID", 8, 8, 2, 8, 40, 0, 27, 0},
    {-1, 2, 3, (char *)"MessageType", 104, 5, 2, 8, 8, 0, 13, 0},
    {-1, 2, 14, (char *)"SendRoutingInfoForSM", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"MO-ForwardSM", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"MT-ForwardSM", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"ReportSM-DeliveryStatus", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"AlertServiceCentre", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"InformServiceCentre", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"ReadyForSM", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 19, 21, (char *)"PrepareGroupCallArg", 560, 9, 1, 0, 12, 7, 12, 0},
    {-1, 19, 77, (char *)"PrepareGroupCallRes", 520, 2, 1, 0, 12, 16, 12, 0},
    {-1, 19, 85, (char *)"SendGroupCallEndSignalArg", 520, 2, 1, 0, 12, 18, 12, 0},
    {-1, 19, 95, (char *)"SendGroupCallEndSignalRes", 512, 1, 1, 0, 12, 20, 12, 0},
    {-1, 19, 99, (char *)"ForwardGroupCallSignallingArg", 528, 7, 1, 0, 12, 21, 12, 0},
    {-1, 19, 169, (char *)"ProcessGroupCallSignallingArg", 512, 4, 1, 0, 12, 28, 12, 0},
    {-1, 19, 197, (char *)"RoutingInfoForSM-Arg", 36, 3, 0, 0, 12, 32, 12, 0},
    {-1, 209, 0, (char *)"SM-RP-MTI", 2, 0, 2, 0, 8, 0, 55, 0},
    {12, 211, 0, (char *)"SM-RP-SMEA", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 19, 213, (char *)"RoutingInfoForSM-Res", 544, 3, 1, 0, 12, 35, 12, 0},
    {-1, 2, 225, (char *)"Additional-Number", 14, 2, 2, 2, 8, 38, 13, 0},
    {-1, 19, 230, (char *)"MO-ForwardSM-Arg", 760, 4, 1, 0, 12, 40, 12, 0},
    {-1, 19, 77, (char *)"MO-ForwardSM-Res", 712, 2, 1, 0, 12, 44, 12, 0},
    {-1, 19, 256, (char *)"MT-ForwardSM-Arg", 760, 5, 1, 0, 12, 46, 12, 0},
    {-1, 19, 85, (char *)"MT-ForwardSM-Res", 712, 2, 1, 0, 12, 51, 12, 0},
    {-1, 19, 288, (char *)"ReportSM-DeliveryStatusArg", 40, 3, 0, 0, 12, 53, 12, 0},
    {-1, 19, 85, (char *)"ReportSM-DeliveryStatusRes", 520, 2, 1, 0, 12, 56, 12, 0},
    {-1, 19, 300, (char *)"AlertServiceCentreArg", 34, 2, 0, 0, 12, 58, 12, 0},
    {-1, 19, 308, (char *)"InformServiceCentreArg", 520, 3, 1, 0, 12, 60, 12, 0},
    {-1, 19, 326, (char *)"ReadyForSM-Arg", 16, 2, 0, 0, 12, 63, 12, 0},
    {-1, 19, 95, (char *)"ReadyForSM-Res", 512, 1, 1, 0, 12, 65, 12, 0},
    {-1, 2, 14, (char *)"SendRoutingInfo", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"ProvideRoamingNumber", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"ResumeCallHandling", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"ProvideSIWFSNumber", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"SIWFSSignallingModify", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"PrepareGroupCall", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"SendGroupCallEndSignal", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"ProcessGroupCallSignalling", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"ForwardGroupCallSignalling", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 19, 334, (char *)"SendRoutingInfoArg", 1264, 4, 1, 0, 12, 66, 12, 0},
    {-1, 356, 0, (char *)"SuppressionOfAnnouncement", 1, 0, 0, 0, 8, 0, 5, 0},
    {1, 358, 0, (char *)"InterrogationType", 4, 0, 4, 0, 24, 1, 58, 0},
    {-1, 209, 0, (char *)"OR-Phase", 2, 0, 2, 0, 8, 0, 55, 0},
    {2, 358, 0, (char *)"ForwardingReason", 4, 0, 4, 0, 24, 5, 58, 0},
    {-1, 209, 0, (char *)"SupportedCCBS-Phase", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 19, 360, (char *)"SendRoutingInfoRes", 1096, 3, 1, 0, 12, 70, 12, 0},
    {-1, 19, 374, (char *)"CCBS-Indicators", 512, 3, 1, 0, 12, 73, 12, 0},
    {-1, 19, 392, (char *)"ProvideRoamingNumberArg", 1496, 7, 1, 0, 12, 76, 12, 0},
    {-1, 19, 77, (char *)"ProvideRoamingNumberRes", 520, 2, 1, 0, 12, 83, 12, 0},
    {-1, 19, 95, (char *)"ResumeCallHandlingRes", 512, 1, 1, 0, 12, 85, 12, 0},
    {-1, 19, 440, (char *)"ProvideSIWFSNumberArg", 4128, 8, 1, 0, 12, 86, 12, 0},
    {-1, 19, 478, (char *)"ProvideSIWFSNumberRes", 520, 2, 1, 0, 12, 94, 12, 0},
    {-1, 19, 374, (char *)"SIWFSSignallingModifyArg", 1952, 3, 1, 0, 12, 96, 12, 0},
    {-1, 19, 486, (char *)"SIWFSSignallingModifyRes", 1232, 2, 1, 0, 12, 99, 12, 0},
    {-1, 19, 496, (char *)"StatusReportArg", 1552, 4, 1, 0, 12, 101, 12, 0},
    {-1, 19, 518, (char *)"StatusReportRes", 512, 1, 1, 0, 12, 105, 12, 0},
    {-1, 2, 14, (char *)"UpdateLocation", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"CancelLocation", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"PurgeMS", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"SendIdentification", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"PrepareHandover", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"SendEndSignal", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"ProcessAccessSignalling", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"ForwardAccessSignalling", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"PrepareSubsequentHandover", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"SendAuthenticationInfo", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"CheckIMEI", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"InsertSubscriberData", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"DeleteSubscriberData", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"Reset", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"RestoreData", 16, 2, 2, 8, 8, 5, 13, 0},
    {1, 211, 0, (char *)"RegisterPasswordArg", 2, 0, 2, 2, 24, 0, 21, 0},
    {3, 19, 522, (char *)"RegisterSSArg", 66, 8, 1, 0, 2076, 106, 12, 0},
    {-1, 2, 598, (char *)"DeactivateSSRes", 1156, 4, 2, 4, 8, 114, 13, 0},
    {-1, 2, 598, (char *)"ActivateSSRes", 1156, 4, 2, 4, 8, 114, 13, 0},
    {-1, 2, 598, (char *)"EraseSSRes", 1156, 4, 2, 4, 8, 114, 13, 0},
    {-1, 2, 598, (char *)"RegisterSSRes", 1156, 4, 2, 4, 8, 114, 13, 0},
    {-1, 19, 607, (char *)"SS-ForBS-Code", 12, 2, 1, 0, 12, 118, 12, 0},
    {-1, 19, 607, (char *)"InterrogateSSArg", 12, 2, 1, 0, 12, 120, 12, 0},
    {-1, 19, 607, (char *)"DeactivateSSArg", 12, 2, 1, 0, 12, 122, 12, 0},
    {-1, 19, 607, (char *)"ActivateSSArg", 12, 2, 1, 0, 12, 124, 12, 0},
    {-1, 19, 607, (char *)"EraseSSArg", 12, 2, 1, 0, 12, 126, 12, 0},
    {-1, 2, 617, (char *)"InterrogateSSRes", 944, 4, 2, 4, 8, 128, 13, 0},
    {1, 19, 626, (char *)"USSD-Arg", 172, 3, 1, 0, 2076, 132, 12, 0},
    {1, 19, 626, (char *)"UnstructuredSS-NotifyArg", 172, 3, 1, 0, 2076, 132, 12, 0},
    {1, 19, 626, (char *)"UnstructuredSS-RequestArg", 172, 3, 1, 0, 2076, 132, 12, 0},
    {1, 19, 626, (char *)"ProcessUnstructuredSS-RequestArg", 172, 3, 1, 0, 2076, 132, 12, 0},
    {-1, 19, 300, (char *)"USSD-Res", 166, 2, 0, 0, 12, 135, 12, 0},
    {-1, 19, 300, (char *)"UnstructuredSS-RequestRes", 166, 2, 0, 0, 12, 135, 12, 0},
    {-1, 19, 300, (char *)"ProcessUnstructuredSS-RequestRes", 166, 2, 0, 0, 12, 135, 12, 0},
    {5, 638, 18, (char *)"Password", 1, 0, 2, 0, 16408, 0, 24, 0},
    {5, 638, 18, (char *)"GetPasswordRes", 1, 0, 2, 0, 16408, 0, 24, 0},
    {5, 638, 18, (char *)"RegisterPasswordRes", 1, 0, 2, 0, 16408, 0, 24, 0},
    {2, 358, 0, (char *)"GuidanceInfo", 4, 0, 4, 0, 24, 10, 58, 0},
    {2, 358, 0, (char *)"GetPasswordArg", 4, 0, 4, 0, 24, 10, 58, 0},
    {2, 19, 0, (char *)"SS-EventSpecification", 2, 22, 2, 2, 24, 325, 17, 0},
    {-1, 19, 640, (char *)"CCBS-Data", 1504, 5, 1, 0, 12, 137, 12, 0},
    {-1, 2, 225, (char *)"SubscriberId", 12, 2, 2, 2, 8, 142, 13, 0},
    {8, 211, 0, (char *)"IMEI", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 19, 478, (char *)"NAEA-PreferredCI", 512, 2, 1, 0, 12, 144, 12, 0},
    {-1, 19, 662, (char *)"UpdateLocationArg", 552, 5, 1, 0, 12, 146, 12, 0},
    {-1, 2, 684, (char *)"UpdateLocationRes", 14, 2, 2, 2, 8, 151, 13, 0},
    {-1, 2, 684, (char *)"CancelLocationArg", 18, 2, 2, 2, 8, 153, 13, 0},
    {-1, 2, 684, (char *)"Indentity", 18, 2, 2, 2, 8, 155, 13, 0},
    {INT_MAX, 358, 0, (char *)"CancellationType", 4, 0, 4, 0, 2076, 15, 58, 0},
    {-1, 19, 95, (char *)"CancelLocationRes", 512, 1, 1, 0, 12, 157, 12, 0},
    {-1, 19, 300, (char *)"PurgeMS-Arg", 22, 2, 0, 0, 12, 158, 12, 0},
    {-1, 19, 689, (char *)"PurgeMS-Res", 512, 3, 1, 0, 12, 160, 12, 0},
    {-1, 19, 77, (char *)"SendIdentificationRes", 184, 2, 1, 0, 12, 163, 12, 0},
    {-1, 19, 707, (char *)"PrepareHO-Arg", 736, 3, 1, 0, 12, 165, 12, 0},
    {-1, 19, 85, (char *)"PrepareHO-Res", 736, 2, 1, 0, 12, 168, 12, 0},
    {-1, 19, 725, (char *)"PrepareSubsequentHO-Arg", 744, 3, 0, 0, 12, 170, 12, 0},
    {8, 211, 0, (char *)"SendAuthenticationInfoArg", 2, 0, 2, 2, 24, 0, 21, 0},
    {5, 19, 0, (char *)"SendAuthenticationInfoRes", 2, 34, 2, 2, 24, 515, 17, 0},
    {2, 358, 0, (char *)"EquipmentStatus", 4, 0, 4, 0, 24, 22, 58, 0},
    {-1, 19, 737, (char *)"InsertSubscriberDataArg", 35560, 10, 2, 0, 12, 173, 12, 0},
    {3, 211, 0, (char *)"QoS-Subscribed", 2, 0, 2, 2, 24, 0, 21, 0},
    {30, 19, 0, (char *)"Ext-SS-InfoList", 2, 25912, 2, 8, 24, 572, 17, 0},
    {-1, 19, 867, (char *)"InsertSubscriberDataRes", 416, 5, 1, 0, 12, 183, 12, 0},
    {-1, 19, 907, (char *)"DeleteSubscriberDataArg", 562, 5, 1, 0, 12, 188, 12, 0},
    {-1, 19, 939, (char *)"DeleteSubscriberDataRes", 512, 2, 1, 0, 12, 193, 12, 0},
    {1, 358, 0, (char *)"CallTypeCriteria", 4, 0, 4, 0, 24, 27, 58, 0},
    {INT_MAX, 358, 0, (char *)"DefaultCallHandling", 4, 0, 4, 0, 2076, 31, 58, 0},
    {-1, 19, 77, (char *)"ResetArg", 516, 2, 1, 0, 12, 195, 12, 0},
    {-1, 19, 949, (char *)"RestoreDataArg", 528, 3, 1, 0, 12, 197, 12, 0},
    {-1, 19, 963, (char *)"RestoreDataRes", 520, 3, 1, 0, 12, 200, 12, 0},
    {50, 19, 0, (char *)"VBSDataList", 2, 520, 2, 8, 24, 588, 17, 0},
    {50, 19, 0, (char *)"VGCSDataList", 2, 512, 2, 8, 24, 589, 17, 0},
    {-1, 2, 14, (char *)"RegisterSS", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"EraseSS", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"ActivateSS", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"DeactivateSS", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"InterrogateSS", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"ProcessUnstructuredSS-Request", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"UnstructuredSS-Request", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"UnstructuredSS-Notify", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"RegisterPassword", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"GetPassword", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 19, 977, (char *)"RoamingNotAllowedParam", 512, 2, 1, 0, 12, 203, 12, 0},
    {-1, 2, 985, (char *)"CallBarredParam", 528, 2, 2, 8, 8, 205, 13, 0},
    {-1, 19, 990, (char *)"CUG-RejectParam", 512, 2, 1, 0, 12, 207, 12, 0},
    {-1, 19, 1000, (char *)"SS-IncompatibilityCause", 16, 3, 1, 0, 12, 209, 12, 0},
    {2, 358, 0, (char *)"PW-RegistrationFailureCause", 4, 0, 4, 0, 24, 38, 58, 0},
    {-1, 19, 1022, (char *)"SM-DeliveryFailureCause", 720, 3, 1, 0, 12, 212, 12, 0},
    {1, 19, 1036, (char *)"AbsentSubscriberSM-Param", 520, 3, 1, 0, 2076, 215, 12, 0},
    {-1, 2, 985, (char *)"SystemFailureParam", 520, 2, 2, 8, 8, 218, 13, 0},
    {-1, 19, 95, (char *)"DataMissingParam", 512, 1, 1, 0, 12, 220, 12, 0},
    {-1, 19, 95, (char *)"UnexpectedDataParam", 512, 1, 1, 0, 12, 221, 12, 0},
    {-1, 19, 95, (char *)"FacilityNotSupParam", 512, 1, 1, 0, 12, 222, 12, 0},
    {-1, 19, 95, (char *)"OR-NotAllowedParam", 512, 1, 1, 0, 12, 223, 12, 0},
    {1, 19, 1054, (char *)"UnknownSubscriberParam", 520, 2, 1, 0, 2076, 224, 12, 0},
    {-1, 19, 95, (char *)"NumberChangedParam", 512, 1, 1, 0, 12, 226, 12, 0},
    {-1, 19, 95, (char *)"UnidentifiedSubParam", 512, 1, 1, 0, 12, 227, 12, 0},
    {-1, 19, 95, (char *)"IllegalSubscriberParam", 512, 1, 1, 0, 12, 228, 12, 0},
    {-1, 19, 95, (char *)"IllegalEquipmentParam", 512, 1, 1, 0, 12, 229, 12, 0},
    {-1, 19, 95, (char *)"BearerServNotProvParam", 512, 1, 1, 0, 12, 230, 12, 0},
    {-1, 19, 95, (char *)"TeleservNotProvParam", 512, 1, 1, 0, 12, 231, 12, 0},
    {-1, 19, 95, (char *)"TracingBufferFullParam", 512, 1, 1, 0, 12, 232, 12, 0},
    {-1, 19, 95, (char *)"NoRoamingNbParam", 512, 1, 1, 0, 12, 233, 12, 0},
    {1, 19, 1064, (char *)"AbsentSubscriberParam", 520, 2, 1, 0, 2076, 234, 12, 0},
    {2, 19, 1074, (char *)"BusySubscriberParam", 520, 3, 1, 0, 2076, 236, 12, 0},
    {-1, 19, 95, (char *)"NoSubscriberReplyParam", 512, 1, 1, 0, 12, 239, 12, 0},
    {-1, 19, 95, (char *)"ForwardingViolationParam", 512, 1, 1, 0, 12, 240, 12, 0},
    {-1, 19, 95, (char *)"ForwardingFailedParam", 512, 1, 1, 0, 12, 241, 12, 0},
    {-1, 19, 95, (char *)"ATI-NotAllowedParam", 512, 1, 1, 0, 12, 242, 12, 0},
    {1, 19, 1092, (char *)"SubBusyForMT-SMS-Param", 520, 2, 1, 0, 2076, 243, 12, 0},
    {-1, 19, 95, (char *)"MessageWaitListFullParam", 512, 1, 1, 0, 12, 245, 12, 0},
    {-1, 19, 95, (char *)"ResourceLimitationParam", 512, 1, 1, 0, 12, 246, 12, 0},
    {-1, 19, 95, (char *)"NoGroupCallNbParam", 512, 1, 1, 0, 12, 247, 12, 0},
    {-1, 19, 95, (char *)"IncompatibleTerminalParam", 512, 1, 1, 0, 12, 248, 12, 0},
    {-1, 19, 0, (char *)"ShortTermDenialParam", 1, 0, 0, 0, 12, 249, 12, 0},
    {-1, 19, 0, (char *)"LongTermDenialParam", 1, 0, 0, 0, 12, 249, 12, 0},
    {-1, 19, 1102, (char *)"ActivateTraceModeArg", 544, 5, 1, 0, 12, 249, 12, 0},
    {-1, 19, 518, (char *)"ActivateTraceModeRes", 512, 1, 1, 0, 12, 254, 12, 0},
    {-1, 19, 1126, (char *)"DeactivateTraceModeArg", 520, 3, 1, 0, 12, 255, 12, 0},
    {-1, 19, 518, (char *)"DeactivateTraceModeRes", 512, 1, 1, 0, 12, 258, 12, 0},
    {-1, 2, 14, (char *)"SystemFailure", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"DataMissing", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"UnexpectedDataValue", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"FacilityNotSupported", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"IncompatibleTerminal", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"ResourceLimitation", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"UnknownSubscriber", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"NumberChanged", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"UnknownMSC", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"UnidentifiedSubscriber", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"UnknownEquipment", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"RoamingNotAllowed", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"IllegalSubscriber", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"IllegalEquipment", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"BearerServiceNotProvisioned", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"TeleserviceNotProvisioned", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"NoHandoverNumberAvailable", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"SubsequentHandoverFailure", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"TracingBufferFull", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"NoRoamingNumberAvailable", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"AbsentSubscriber", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"BusySubscriber", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"NoSubscriberReply", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"CallBarred", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"ForwardingViolation", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"ForwardingFailed", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"CUG-Reject", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"OR-NotAllowed", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"ATI-NotAllowed", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"IllegalSS-Operation", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"SS-ErrorStatus", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"SS-NotAvailable", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"SS-SubscriptionViolation", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"SS-Incompatibility", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"UnknownAlphabet", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"USSD-Busy", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"PW-RegistrationFailure", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"NegativePW-Check", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"NumberOfPW-AttemptsViolation", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"ShortTermDenial", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"LongTermDenial", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"SubscriberBusyForMT-SMS", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"SM-DeliveryFailure", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"MessageWaitingListFull", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"AbsentSubscriberSM", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"NoGroupCallNumberAvailable", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"ActivateTraceMode", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"DeactivateTraceMode", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 14, (char *)"SendIMSI", 16, 2, 2, 8, 8, 5, 13, 0},
    {-1, 2, 1140, (char *)"DialoguePDU", 52, 6, 2, 4, 8, 259, 13, 0},
    {-1, 19, 486, (char *)"OpenInfo", 46, 2, 1, 0, 12, 265, 12, 0},
    {-1, 19, 0, (char *)"AcceptInfo", 1, 0, 0, 0, 12, 249, 12, 0},
    {-1, 19, 0, (char *)"CloseInfo", 1, 0, 0, 0, 12, 249, 12, 0},
    {-1, 19, 1153, (char *)"RefuseInfo", 4, 1, 0, 0, 12, 267, 12, 0},
    {2, 358, 0, (char *)"Reason", 4, 0, 4, 0, 24, 43, 58, 0},
    {-1, 19, 1157, (char *)"UserAbortInfo", 8, 1, 0, 0, 12, 268, 12, 0},
    {-1, 2, 598, (char *)"UserAbortChoice", 8, 4, 2, 4, 8, 269, 13, 0},
    {1, 358, 0, (char *)"ResourceUnavailableReason", 4, 0, 4, 0, 24, 48, 58, 0},
    {6, 358, 0, (char *)"ProcedureCancellationReason", 4, 0, 4, 0, 24, 52, 58, 0},
    {-1, 19, 1153, (char *)"ProviderAbortInfo", 4, 1, 0, 0, 12, 273, 12, 0},
    {1, 358, 0, (char *)"ProviderAbortReason", 4, 0, 4, 0, 24, 61, 58, 0},
    {-1, 2, 0, (char *)"_Any", 16, 0, 8, 8, 40, 0, 10, 0},
    {-1, 0, 0, (char *)"_ObjectID", 8, 8, 2, 8, 40, 0, 27, 0},
    {-1, 209, 0, NULL, 4, 0, 4, 0, 8, 0, 0, 0},
    {0, 1167, 7, NULL, 1, 0, 8, 0, 9, 0, 24, 0},
    {-1, 1169, 0, NULL, 32, 0, 0, 0, 8, 0, 51, 0},
    {-1, 1171, 0, (char *)"External_octet_aligned", 16, 0, 4, 8, 40, 0, 20, 0},
    {-1, 1173, 0, (char *)"External_arbitrary", 16, 0, 4, 8, 40, 0, 3, 0},
    {-1, 2, 1175, (char *)"_choice1", 40, 3, 2, 8, 40, 274, 13, 0},
    {-1, 1182, 1184, (char *)"_External", 72, 4, 1, 0, 40, 277, 12, 0},
    {-1, 1228, 1184, (char *)"DialoguePortion", 72, 4, 1, 0, 8, 277, 12, 0},
    {-1, 19, 1231, (char *)"Unidirectional", 88, 2, 1, 0, 8, 281, 12, 0},
    {4, 1241, 0, (char *)"OrigTransactionID", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 19, 1243, (char *)"Begin", 88, 3, 1, 0, 8, 283, 12, 0},
    {4, 1257, 0, (char *)"DestTransactionID", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 19, 1259, (char *)"End", 88, 3, 1, 0, 8, 286, 12, 0},
    {-1, 19, 1273, (char *)"Continue", 96, 4, 1, 0, 8, 289, 12, 0},
    {-1, 1291, 0, (char *)"P-AbortCause", 4, 0, 4, 0, 8, 65, 0, 0},
    {-1, 2, 1293, (char *)"_choice2", 80, 2, 2, 8, 40, 293, 13, 0},
    {-1, 19, 1298, (char *)"Abort", 88, 2, 1, 0, 8, 295, 12, 0},
    {-1, 1308, 1231, (char *)"Unidirectional", 88, 2, 1, 0, 8, 281, 12, 0},
    {-1, 1310, 1243, (char *)"Begin", 88, 3, 1, 0, 8, 283, 12, 0},
    {-1, 1312, 1259, (char *)"End", 88, 3, 1, 0, 8, 286, 12, 0},
    {-1, 1314, 1273, (char *)"Continue", 96, 4, 1, 0, 8, 289, 12, 0},
    {-1, 1316, 1298, (char *)"Abort", 88, 2, 1, 0, 8, 295, 12, 0},
    {-1, 209, 0, (char *)"InvokeIdType", 2, 0, 2, 0, 8, 0, 0, 0},
    {-1, 1169, 0, (char *)"InvokeIdType", 2, 0, 2, 0, 8, 0, 0, 0},
    {-1, 209, 0, NULL, 4, 0, 4, 0, 8, 0, 0, 0},
    {-1, 2, 14, (char *)"_choice3", 16, 2, 2, 8, 40, 5, 13, 0},
    {-1, 2, 0, (char *)"_Any", 16, 0, 8, 8, 40, 0, 10, 0},
    {-1, 19, 1318, (char *)"Invoke", 40, 4, 1, 0, 8, 297, 12, 0},
    {-1, 19, 1338, (char *)"_seq1", 32, 2, 0, 0, 40, 301, 12, 0},
    {-1, 19, 1346, (char *)"ReturnResult", 40, 2, 1, 0, 8, 303, 12, 0},
    {-1, 2, 0, (char *)"_Any", 16, 0, 8, 8, 40, 0, 10, 0},
    {-1, 19, 1354, (char *)"ReturnError", 40, 3, 1, 0, 8, 305, 12, 0},
    {-1, 209, 0, (char *)"GeneralProblem", 4, 0, 4, 0, 8, 72, 0, 0},
    {-1, 209, 0, (char *)"InvokeProblem", 4, 0, 4, 0, 8, 77, 0, 0},
    {-1, 209, 0, (char *)"ReturnResultProblem", 4, 0, 4, 0, 8, 87, 0, 0},
    {-1, 209, 0, (char *)"ReturnErrorProblem", 4, 0, 4, 0, 8, 92, 0, 0},
    {-1, 356, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2, 1366, (char *)"_choice4", 4, 2, 2, 2, 40, 308, 13, 0},
    {-1, 1169, 0, (char *)"GeneralProblem", 4, 0, 4, 0, 8, 72, 0, 0},
    {-1, 1171, 0, (char *)"InvokeProblem", 4, 0, 4, 0, 8, 77, 0, 0},
    {-1, 1173, 0, (char *)"ReturnResultProblem", 4, 0, 4, 0, 8, 87, 0, 0},
    {-1, 1371, 0, (char *)"ReturnErrorProblem", 4, 0, 4, 0, 8, 92, 0, 0},
    {-1, 2, 598, (char *)"_choice5", 8, 4, 2, 4, 40, 310, 13, 0},
    {-1, 19, 1373, (char *)"Reject", 12, 2, 0, 0, 8, 314, 12, 0},
    {-1, 1171, 1318, (char *)"Invoke", 40, 4, 1, 0, 8, 297, 12, 0},
    {-1, 1173, 1346, (char *)"ReturnResult", 40, 2, 1, 0, 8, 303, 12, 0},
    {-1, 1371, 1354, (char *)"ReturnError", 40, 3, 1, 0, 8, 305, 12, 0},
    {-1, 1389, 1373, (char *)"Reject", 12, 2, 0, 0, 8, 314, 12, 0},
    {-1, 1391, 1346, (char *)"ReturnResult", 40, 2, 1, 0, 8, 303, 12, 0},
    {-1, 2, 1393, (char *)"Component", 48, 5, 2, 8, 8, 316, 13, 0},
    {-1, 1404, 0, (char *)"ComponentPortion", 8, 48, 4, 8, 8, 288, 18, 0},
    {-1, 2, 0, NULL, 2, 0, 0, 0, 8, 0, 50, 0},
    {-1, 209, 0, NULL, 8, 0, 8, 0, 8, 0, 0, 0},
    {-1, 2, 0, (char *)"EXTENSION", 24, 3, 1, 0, 8, 321, 49, 0},
    {-1, 0, 0, (char *)"_ObjectID", 8, 8, 2, 8, 40, 0, 27, 0},
    {-1, 2, 0, NULL, 32, 0, 0, 0, 8, 0, 51, 0},
    {-1, 19, 1406, (char *)"PrivateExtension", 48, 2, 1, 0, 264, 324, 12, 0},
    {10, 19, 0, (char *)"PrivateExtensionList", 2, 48, 2, 8, 24, 295, 17, 0},
    {-1, 19, 0, (char *)"PCS-Extensions", 1, 0, 0, 0, 12, 249, 12, 0},
    {10, 1169, 0, (char *)"PrivateExtensionList", 2, 48, 2, 8, 24, 295, 17, 0},
    {-1, 1171, 0, (char *)"PCS-Extensions", 1, 0, 0, 0, 12, 249, 12, 0},
    {-1, 19, 486, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 326, 12, 0},
    {1, 211, 0, (char *)"BearerServiceCode", 2, 0, 2, 2, 24, 0, 21, 0},
    {5, 211, 0, (char *)"Ext-BearerServiceCode", 2, 0, 2, 2, 24, 0, 21, 0},
    {5, 211, 0, (char *)"Ext-TeleserviceCode", 2, 0, 2, 2, 24, 0, 21, 0},
    {8, 211, 0, (char *)"ASCI-CallReference", 2, 0, 2, 2, 24, 0, 21, 0},
    {10, 211, 0, (char *)"CODEC-Info", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 211, 0, (char *)"CipheringAlgorithm", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 209, 0, (char *)"GroupKeyNumber", 2, 0, 2, 0, 8, 0, 55, 0},
    {8, 211, 0, (char *)"Kc", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 209, 0, (char *)"EMLPP-Priority", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 1169, 0, (char *)"GroupKeyNumber", 2, 0, 2, 0, 8, 0, 55, 0},
    {8, 1171, 0, (char *)"Kc", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 1173, 0, (char *)"EMLPP-Priority", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 1371, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 1389, 486, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 326, 12, 0},
    {9, 211, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {8, 211, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 1169, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 1171, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 1173, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 1371, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 1389, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 1169, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 1171, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 1173, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {20, 211, 0, (char *)"AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 1169, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 1171, 0, NULL, 1, 0, 0, 0, 8, 0, 8, 0},
    {20, 1173, 0, (char *)"AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 1169, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 1171, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2, 225, (char *)"LocationInfo", 14, 2, 2, 2, 8, 328, 13, 0},
    {4, 211, 0, (char *)"LMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 19, 1412, (char *)"LocationInfoWithLMSI", 22, 2, 1, 0, 12, 330, 12, 0},
    {-1, 1169, 1412, (char *)"LocationInfoWithLMSI", 22, 2, 1, 0, 12, 330, 12, 0},
    {-1, 1389, 486, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 326, 12, 0},
    {9, 1169, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 1171, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {8, 1169, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 1171, 0, (char *)"LMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {20, 1389, 0, (char *)"AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 1422, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2, 1424, (char *)"SM-RP-DA", 24, 4, 2, 2, 8, 332, 13, 0},
    {9, 1173, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {20, 1389, 0, (char *)"AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 1422, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2, 1433, (char *)"SM-RP-OA", 24, 3, 2, 2, 8, 336, 13, 0},
    {200, 211, 0, (char *)"SignalInfo", 2, 0, 2, 2, 24, 0, 21, 0},
    {2, 358, 0, (char *)"SM-DeliveryOutcome", 4, 0, 4, 0, 24, 99, 58, 0},
    {6, 1440, 0, (char *)"MW-Status", 1, 0, 2, 0, 24, 104, 1, 0},
    {1, 358, 0, (char *)"AlertReason", 4, 0, 4, 0, 24, 109, 58, 0},
    {8, 1169, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 211, 0, (char *)"SS-Code", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 211, 0, (char *)"CUG-Interlock", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 19, 963, (char *)"CUG-CheckInfo", 520, 3, 1, 0, 12, 339, 12, 0},
    {-1, 209, 0, (char *)"NumberOfForwarding", 2, 0, 2, 0, 8, 0, 55, 0},
    {4, 358, 0, (char *)"ProtocolId", 4, 0, 4, 0, 24, 113, 58, 0},
    {-1, 19, 1442, (char *)"ExternalSignalInfo", 720, 3, 1, 0, 12, 342, 12, 0},
    {9, 1169, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 1171, 963, (char *)"CUG-CheckInfo", 520, 3, 1, 0, 12, 339, 12, 0},
    {-1, 1173, 0, (char *)"NumberOfForwarding", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 1454, 1442, (char *)"ExternalSignalInfo", 720, 3, 1, 0, 12, 342, 12, 0},
    {8, 211, 0, (char *)"CallReferenceNumber", 2, 0, 2, 2, 24, 0, 21, 0},
    {21, 211, 0, (char *)"ISDN-SubaddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 211, 0, (char *)"ForwardingOptions", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 1422, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {21, 1389, 0, (char *)"ISDN-SubaddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 1456, 0, (char *)"ForwardingOptions", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 1391, 486, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 326, 12, 0},
    {-1, 19, 1458, (char *)"ForwardingData", 552, 4, 1, 0, 12, 345, 12, 0},
    {-1, 2, 684, (char *)"RoutingInfo", 560, 2, 2, 8, 8, 349, 13, 0},
    {-1, 1169, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 1171, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 1173, 486, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 326, 12, 0},
    {8, 1169, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 1171, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 1173, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 1371, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 1389, 0, (char *)"LMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 1422, 1442, (char *)"ExternalSignalInfo", 720, 3, 1, 0, 12, 342, 12, 0},
    {-1, 1456, 1442, (char *)"ExternalSignalInfo", 720, 3, 1, 0, 12, 342, 12, 0},
    {1, 211, 0, (char *)"CallDirection", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 1169, 1442, (char *)"ExternalSignalInfo", 720, 3, 1, 0, 12, 342, 12, 0},
    {-1, 1171, 1442, (char *)"ExternalSignalInfo", 720, 3, 1, 0, 12, 342, 12, 0},
    {1, 1173, 0, (char *)"CallDirection", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 1371, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 1389, 1442, (char *)"ExternalSignalInfo", 720, 3, 1, 0, 12, 342, 12, 0},
    {-1, 1422, 1442, (char *)"ExternalSignalInfo", 720, 3, 1, 0, 12, 342, 12, 0},
    {-1, 1456, 1442, (char *)"ExternalSignalInfo", 720, 3, 1, 0, 12, 342, 12, 0},
    {-1, 1391, 486, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 326, 12, 0},
    {9, 1169, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 1171, 486, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 326, 12, 0},
    {-1, 1169, 1442, (char *)"ExternalSignalInfo", 720, 3, 1, 0, 12, 342, 12, 0},
    {-1, 1171, 1442, (char *)"ExternalSignalInfo", 720, 3, 1, 0, 12, 342, 12, 0},
    {-1, 1173, 486, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 326, 12, 0},
    {-1, 1169, 1442, (char *)"ExternalSignalInfo", 720, 3, 1, 0, 12, 342, 12, 0},
    {-1, 1171, 486, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 326, 12, 0},
    {INT_MAX, 358, 0, (char *)"CCBS-SubscriberStatus", 4, 0, 4, 0, 2076, 119, 58, 0},
    {INT_MAX, 1169, 0, (char *)"CCBS-SubscriberStatus", 4, 0, 4, 0, 2076, 119, 58, 0},
    {-1, 1171, 486, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 326, 12, 0},
    {-1, 19, 486, (char *)"EventReportData", 512, 2, 1, 0, 12, 351, 12, 0},
    {INT_MAX, 358, 0, (char *)"MonitoringMode", 4, 0, 4, 0, 2076, 127, 58, 0},
    {INT_MAX, 358, 0, (char *)"CallOutcome", 4, 0, 4, 0, 2076, 134, 58, 0},
    {INT_MAX, 1169, 0, (char *)"MonitoringMode", 4, 0, 4, 0, 2076, 127, 58, 0},
    {INT_MAX, 1171, 0, (char *)"CallOutcome", 4, 0, 4, 0, 2076, 134, 58, 0},
    {-1, 1173, 486, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 326, 12, 0},
    {-1, 19, 374, (char *)"CallReportData", 520, 3, 1, 0, 12, 353, 12, 0},
    {8, 1169, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 1171, 486, (char *)"EventReportData", 512, 2, 1, 0, 12, 351, 12, 0},
    {-1, 1173, 374, (char *)"CallReportData", 520, 3, 1, 0, 12, 353, 12, 0},
    {-1, 1371, 486, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 326, 12, 0},
    {-1, 1169, 486, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 326, 12, 0},
    {1, 211, 0, (char *)"TeleserviceCode", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 1173, 0, (char *)"BearerServiceCode", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 1371, 0, (char *)"TeleserviceCode", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2, 1486, (char *)"BasicServiceCode", 6, 2, 2, 2, 8, 356, 13, 0},
    {-1, 209, 0, (char *)"NoReplyConditionTime", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 209, 0, (char *)"MC-Bearers", 2, 0, 2, 0, 8, 0, 55, 0},
    {20, 1389, 0, (char *)"AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {21, 1456, 0, (char *)"ISDN-SubaddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 1422, 0, (char *)"NoReplyConditionTime", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 1391, 0, (char *)"EMLPP-Priority", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 1491, 0, (char *)"MC-Bearers", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 1493, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 209, 0, (char *)"CUG-Index", 2, 0, 2, 0, 8, 0, 55, 0},
    {4, 211, 0, (char *)"CUG-Interlock", 2, 0, 2, 2, 24, 0, 21, 0},
    {2, 358, 0, (char *)"IntraCUG-Options", 4, 0, 4, 0, 24, 142, 58, 0},
    {13, 19, 0, (char *)"BasicServiceGroupList", 2, 6, 2, 2, 24, 415, 17, 0},
    {-1, 19, 1495, (char *)"CUG-Subscription", 96, 4, 1, 0, 12, 358, 12, 0},
    {10, 19, 0, (char *)"CUG-SubscriptionList", 2, 96, 2, 4, 24, 428, 17, 0},
    {1, 211, 0, (char *)"InterCUG-Restrictions", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 19, 1511, (char *)"CUG-Feature", 14, 3, 1, 0, 12, 362, 12, 0},
    {13, 19, 0, (char *)"CUG-FeatureList", 2, 14, 2, 2, 24, 431, 17, 0},
    {-1, 19, 1531, (char *)"CUG-Info", 1152, 2, 1, 0, 12, 365, 12, 0},
    {1, 211, 0, (char *)"SS-Status", 2, 0, 2, 2, 24, 0, 21, 0},
    {15, 211, 0, (char *)"FTN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 1389, 0, (char *)"SS-Status", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 1422, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {21, 1491, 0, (char *)"ISDN-SubaddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 1456, 0, (char *)"ForwardingOptions", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 1391, 0, (char *)"NoReplyConditionTime", 2, 0, 2, 0, 8, 0, 55, 0},
    {15, 1493, 0, (char *)"FTN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 19, 1539, (char *)"ForwardingFeature", 72, 7, 1, 0, 2076, 367, 12, 0},
    {13, 19, 0, (char *)"ForwardingFeatureList", 2, 72, 2, 2, 24, 442, 17, 0},
    {-1, 19, 85, (char *)"ForwardingInfo", 944, 2, 1, 0, 12, 374, 12, 0},
    {1, 1389, 0, (char *)"SS-Status", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 19, 1611, (char *)"CallBarringFeature", 12, 2, 1, 0, 12, 376, 12, 0},
    {13, 19, 0, (char *)"CallBarringFeatureList", 2, 12, 2, 2, 24, 446, 17, 0},
    {-1, 19, 85, (char *)"CallBarringInfo", 164, 2, 1, 0, 12, 378, 12, 0},
    {2, 358, 0, (char *)"CliRestrictionOption", 4, 0, 4, 0, 24, 147, 58, 0},
    {1, 358, 0, (char *)"OverrideCategory", 4, 0, 4, 0, 24, 152, 58, 0},
    {2, 1173, 0, (char *)"CliRestrictionOption", 4, 0, 4, 0, 24, 147, 58, 0},
    {1, 1171, 0, (char *)"OverrideCategory", 4, 0, 4, 0, 24, 152, 58, 0},
    {-1, 2, 1623, (char *)"SS-SubscriptionOption", 8, 2, 2, 4, 8, 380, 13, 0},
    {-1, 209, 0, (char *)"CCBS-Index", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 1169, 0, (char *)"CCBS-Index", 2, 0, 2, 0, 8, 0, 55, 0},
    {9, 1171, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {21, 1173, 0, (char *)"ISDN-SubaddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 1371, 1486, (char *)"BasicServiceCode", 6, 2, 2, 2, 8, 356, 13, 0},
    {-1, 19, 1628, (char *)"CCBS-Feature", 46, 4, 1, 0, 12, 382, 12, 0},
    {1, 1389, 0, (char *)"SS-Status", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 1422, 1628, (char *)"CCBS-Feature", 46, 4, 1, 0, 12, 382, 12, 0},
    {-1, 1456, 0, (char *)"MC-Bearers", 2, 0, 2, 0, 8, 0, 55, 0},
    {3, 19, 1656, (char *)"SS-Data", 152, 7, 1, 0, 2076, 386, 12, 0},
    {-1, 1169, 85, (char *)"ForwardingInfo", 944, 2, 1, 0, 12, 374, 12, 0},
    {-1, 1171, 85, (char *)"CallBarringInfo", 164, 2, 1, 0, 12, 378, 12, 0},
    {-1, 1173, 1531, (char *)"CUG-Info", 1152, 2, 1, 0, 12, 365, 12, 0},
    {3, 1371, 1656, (char *)"SS-Data", 152, 7, 1, 0, 2076, 386, 12, 0},
    {-1, 2, 598, (char *)"SS-Info", 1156, 4, 2, 4, 8, 114, 13, 0},
    {5, 19, 0, (char *)"CCBS-FeatureList", 2, 46, 2, 2, 24, 459, 17, 0},
    {-1, 209, 0, (char *)"MaxMC-Bearers", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 1169, 0, (char *)"EMLPP-Priority", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 1171, 0, (char *)"EMLPP-Priority", 2, 0, 2, 0, 8, 0, 55, 0},
    {5, 1173, 0, (char *)"CCBS-FeatureList", 2, 46, 2, 2, 24, 459, 17, 0},
    {-1, 1371, 0, (char *)"MaxMC-Bearers", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 1389, 0, (char *)"MC-Bearers", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 1422, 0, (char *)"MC-Bearers", 2, 0, 2, 0, 8, 0, 55, 0},
    {6, 19, 1732, (char *)"GenericServiceInfo", 256, 8, 1, 0, 2076, 393, 12, 0},
    {1, 1169, 0, (char *)"SS-Status", 2, 0, 2, 2, 24, 0, 21, 0},
    {13, 1173, 0, (char *)"BasicServiceGroupList", 2, 6, 2, 2, 24, 415, 17, 0},
    {13, 1371, 0, (char *)"ForwardingFeatureList", 2, 72, 2, 2, 24, 442, 17, 0},
    {6, 1389, 1732, (char *)"GenericServiceInfo", 256, 8, 1, 0, 2076, 393, 12, 0},
    {1, 211, 0, (char *)"USSD-DataCodingScheme", 2, 0, 2, 2, 24, 0, 21, 0},
    {160, 211, 0, (char *)"USSD-String", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 211, 0, (char *)"AlertingPattern", 2, 0, 2, 2, 24, 0, 21, 0},
    {30, 19, 0, (char *)"SS-List", 2, 4, 2, 2, 24, 352, 17, 0},
    {30, 19, 0, (char *)"SS-InfoList", 2, 1156, 2, 4, 24, 468, 17, 0},
    {32, 1440, 0, (char *)"ServiceIndicator", 4, 0, 2, 0, 24, 156, 1, 0},
    {-1, 1169, 1628, (char *)"CCBS-Feature", 46, 4, 1, 0, 12, 382, 12, 0},
    {9, 1171, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {32, 1173, 0, (char *)"ServiceIndicator", 4, 0, 2, 0, 24, 156, 1, 0},
    {-1, 1371, 1442, (char *)"ExternalSignalInfo", 720, 3, 1, 0, 12, 342, 12, 0},
    {-1, 1389, 1442, (char *)"ExternalSignalInfo", 720, 3, 1, 0, 12, 342, 12, 0},
    {4, 211, 0, (char *)"TMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {8, 1169, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 1171, 0, (char *)"TMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {8, 211, 0, (char *)"HLR-Id", 2, 0, 2, 2, 24, 0, 21, 0},
    {50, 19, 0, (char *)"HLR-List", 2, 10, 2, 2, 24, 496, 17, 0},
    {7, 211, 0, (char *)"GlobalCellId", 2, 0, 2, 2, 24, 0, 21, 0},
    {7, 358, 0, (char *)"NetworkResource", 4, 0, 4, 0, 24, 160, 58, 0},
    {3, 211, 0, (char *)"NAEA-CIC", 2, 0, 2, 2, 24, 0, 21, 0},
    {3, 1169, 0, (char *)"NAEA-CIC", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 1171, 486, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 326, 12, 0},
    {5, 1173, 0, (char *)"Ext-BearerServiceCode", 2, 0, 2, 2, 24, 0, 21, 0},
    {5, 1371, 0, (char *)"Ext-TeleserviceCode", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 2, 1486, (char *)"Ext-BasicServiceCode", 10, 2, 2, 2, 8, 401, 13, 0},
    {-1, 19, 1806, (char *)"EMLPP-Info", 512, 3, 1, 0, 12, 403, 12, 0},
    {9, 1171, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 1454, 0, (char *)"LMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 19, 1818, (char *)"ExtensibleUpdateLocationRes", 12, 1, 0, 0, 12, 406, 12, 0},
    {-1, 19, 300, (char *)"IMSI-WithLMSI", 16, 2, 0, 0, 12, 407, 12, 0},
    {-1, 1169, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 1171, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {16, 211, 0, (char *)"RAND", 2, 0, 2, 2, 24, 0, 21, 0},
    {4, 211, 0, (char *)"SRES", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 19, 626, (char *)"AuthenticationSet", 34, 3, 0, 0, 12, 409, 12, 0},
    {5, 19, 0, (char *)"AuthenticationSetList", 2, 34, 2, 2, 24, 515, 17, 0},
    {1, 211, 0, (char *)"Category", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 358, 0, (char *)"SubscriberStatus", 4, 0, 4, 0, 24, 170, 58, 0},
    {50, 19, 0, (char *)"BearerServiceList", 2, 4, 2, 2, 24, 301, 17, 0},
    {20, 19, 0, (char *)"TeleserviceList", 2, 4, 2, 2, 24, 412, 17, 0},
    {6, 1440, 0, (char *)"ODB-GeneralData", 1, 0, 2, 0, 24, 174, 1, 0},
    {4, 1440, 0, (char *)"ODB-HPLMN-Data", 1, 0, 2, 0, 24, 182, 1, 0},
    {-1, 19, 1822, (char *)"ODB-Data", 512, 3, 1, 0, 12, 412, 12, 0},
    {2, 211, 0, (char *)"ZoneCode", 2, 0, 2, 2, 24, 0, 21, 0},
    {10, 19, 0, (char *)"ZoneCodeList", 2, 4, 2, 2, 24, 524, 17, 0},
    {8, 1169, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 1171, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 1173, 0, (char *)"Category", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 1371, 0, (char *)"SubscriberStatus", 4, 0, 4, 0, 24, 170, 58, 0},
    {50, 1389, 0, (char *)"BearerServiceList", 2, 4, 2, 2, 24, 301, 17, 0},
    {20, 1456, 0, (char *)"TeleserviceList", 2, 4, 2, 2, 24, 412, 17, 0},
    {30, 1391, 0, (char *)"SS-InfoList", 2, 1156, 2, 4, 24, 468, 17, 0},
    {-1, 1491, 1822, (char *)"ODB-Data", 512, 3, 1, 0, 12, 412, 12, 0},
    {-1, 1493, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {10, 1454, 0, (char *)"ZoneCodeList", 2, 4, 2, 2, 24, 524, 17, 0},
    {5, 211, 0, (char *)"Ext-SS-Status", 2, 0, 2, 2, 24, 0, 21, 0},
    {5, 211, 0, (char *)"Ext-ForwOptions", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 209, 0, (char *)"Ext-NoRepCondTime", 2, 0, 2, 0, 8, 0, 55, 0},
    {5, 1389, 0, (char *)"Ext-SS-Status", 2, 0, 2, 2, 24, 0, 21, 0},
    {9, 1422, 0, (char *)"ISDN-AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {21, 1491, 0, (char *)"ISDN-SubaddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {5, 1456, 0, (char *)"Ext-ForwOptions", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 1391, 0, (char *)"Ext-NoRepCondTime", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 1493, 486, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 326, 12, 0},
    {-1, 19, 1836, (char *)"Ext-ForwFeature", 576, 7, 1, 0, 12, 415, 12, 0},
    {32, 19, 0, (char *)"Ext-ForwFeatureList", 2, 576, 2, 8, 24, 545, 17, 0},
    {-1, 1169, 486, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 326, 12, 0},
    {-1, 19, 1888, (char *)"Ext-ForwInfo", 18952, 3, 1, 0, 12, 422, 12, 0},
    {5, 1389, 0, (char *)"Ext-SS-Status", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 19, 1900, (char *)"Ext-CallBarringFeature", 528, 3, 1, 0, 12, 425, 12, 0},
    {32, 19, 0, (char *)"Ext-CallBarFeatureList", 2, 528, 2, 8, 24, 550, 17, 0},
    {-1, 19, 1916, (char *)"Ext-CallBarInfo", 17416, 3, 1, 0, 12, 428, 12, 0},
    {-1, 209, 0, (char *)"CUG-Index", 2, 0, 2, 0, 8, 0, 55, 0},
    {2, 358, 0, (char *)"IntraCUG-Options", 4, 0, 4, 0, 24, 142, 58, 0},
    {32, 19, 0, (char *)"Ext-BasicServiceGroupList", 2, 10, 2, 2, 24, 505, 17, 0},
    {-1, 1169, 486, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 326, 12, 0},
    {-1, 19, 1928, (char *)"CUG-Subscription", 848, 5, 1, 0, 12, 431, 12, 0},
    {10, 19, 0, (char *)"CUG-SubscriptionList", 2, 848, 2, 8, 24, 557, 17, 0},
    {1, 211, 0, (char *)"InterCUG-Restrictions", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 19, 1950, (char *)"CUG-Feature", 528, 4, 1, 0, 12, 436, 12, 0},
    {32, 19, 0, (char *)"CUG-FeatureList", 2, 528, 2, 8, 24, 560, 17, 0},
    {-1, 1169, 486, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 326, 12, 0},
    {-1, 19, 1974, (char *)"CUG-Info", 25904, 3, 1, 0, 12, 440, 12, 0},
    {5, 1389, 0, (char *)"Ext-SS-Status", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 1422, 486, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 326, 12, 0},
    {-1, 19, 1988, (char *)"Ext-SS-Data", 856, 5, 1, 0, 12, 443, 12, 0},
    {-1, 1169, 1888, (char *)"Ext-ForwInfo", 18952, 3, 1, 0, 12, 422, 12, 0},
    {-1, 1171, 1916, (char *)"Ext-CallBarInfo", 17416, 3, 1, 0, 12, 428, 12, 0},
    {-1, 1173, 1974, (char *)"CUG-Info", 25904, 3, 1, 0, 12, 440, 12, 0},
    {-1, 1371, 1988, (char *)"Ext-SS-Data", 856, 5, 1, 0, 12, 443, 12, 0},
    {-1, 1389, 1806, (char *)"EMLPP-Info", 512, 3, 1, 0, 12, 403, 12, 0},
    {-1, 2, 2016, (char *)"Ext-SS-Info", 25912, 5, 2, 8, 8, 448, 13, 0},
    {3, 358, 0, (char *)"RegionalSubscriptionResponse", 4, 0, 4, 0, 24, 188, 58, 0},
    {20, 1171, 0, (char *)"TeleserviceList", 2, 4, 2, 2, 24, 412, 17, 0},
    {50, 1173, 0, (char *)"BearerServiceList", 2, 4, 2, 2, 24, 301, 17, 0},
    {30, 1371, 0, (char *)"SS-List", 2, 4, 2, 2, 24, 352, 17, 0},
    {6, 1389, 0, (char *)"ODB-GeneralData", 1, 0, 2, 0, 24, 174, 1, 0},
    {3, 1422, 0, (char *)"RegionalSubscriptionResponse", 4, 0, 4, 0, 24, 188, 58, 0},
    {70, 19, 0, (char *)"BasicServiceList", 2, 6, 2, 2, 24, 415, 17, 0},
    {8, 1169, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {70, 1171, 0, (char *)"BasicServiceList", 2, 6, 2, 2, 24, 415, 17, 0},
    {30, 1173, 0, (char *)"SS-List", 2, 4, 2, 2, 24, 352, 17, 0},
    {-1, 1389, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {2, 1422, 0, (char *)"ZoneCode", 2, 0, 2, 2, 24, 0, 21, 0},
    {3, 1169, 0, (char *)"RegionalSubscriptionResponse", 4, 0, 4, 0, 24, 188, 58, 0},
    {1, 358, 0, (char *)"MatchType", 4, 0, 4, 0, 24, 194, 58, 0},
    {3, 211, 0, (char *)"GroupId", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 19, 963, (char *)"VoiceBroadcastData", 520, 3, 1, 0, 12, 453, 12, 0},
    {-1, 19, 77, (char *)"VoiceGroupCallData", 512, 2, 1, 0, 12, 456, 12, 0},
    {-1, 209, 0, (char *)"AgeOfLocationInformation", 2, 0, 2, 0, 8, 0, 55, 0},
    {8, 211, 0, (char *)"GeographicalInformation", 2, 0, 2, 2, 24, 0, 21, 0},
    {10, 211, 0, (char *)"LocationNumber", 2, 0, 2, 2, 24, 0, 21, 0},
    {3, 358, 0, (char *)"NotReachableReason", 4, 0, 4, 0, 24, 198, 58, 0},
    {-1, 1169, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 1171, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 1173, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 2, 2027, (char *)"SubscriberState", 8, 4, 2, 4, 8, 458, 13, 0},
    {3, 358, 0, (char *)"RoamingNotAllowedCause", 4, 0, 4, 0, 24, 204, 58, 0},
    {1, 358, 0, (char *)"CallBarringCause", 4, 0, 4, 0, 24, 208, 58, 0},
    {-1, 1171, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {1, 19, 2036, (char *)"ExtensibleCallBarredParam", 520, 3, 1, 0, 2076, 462, 12, 0},
    {7, 358, 0, (char *)"CUG-RejectCause", 4, 0, 4, 0, 24, 212, 58, 0},
    {1, 1171, 0, (char *)"SS-Code", 2, 0, 2, 2, 24, 0, 21, 0},
    {1, 1389, 0, (char *)"SS-Status", 2, 0, 2, 2, 24, 0, 21, 0},
    {6, 358, 0, (char *)"SM-EnumeratedDeliveryFailureCause", 4, 0, 4, 0, 24, 218, 58, 0},
    {-1, 209, 0, (char *)"AbsentSubscriberDiagnosticSM", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 1169, 0, (char *)"AbsentSubscriberDiagnosticSM", 2, 0, 2, 0, 8, 0, 55, 0},
    {-1, 19, 990, (char *)"ExtensibleSystemFailureParam", 512, 2, 1, 0, 12, 465, 12, 0},
    {INT_MAX, 358, 0, (char *)"UnknownSubscriberDiagnostic", 4, 0, 4, 0, 2076, 227, 58, 0},
    {INT_MAX, 358, 0, (char *)"AbsentSubscriberReason", 4, 0, 4, 0, 2076, 234, 58, 0},
    {INT_MAX, 1169, 0, (char *)"AbsentSubscriberReason", 4, 0, 4, 0, 2076, 234, 58, 0},
    {-1, 1169, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 1171, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {2, 211, 0, (char *)"TraceReference", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 209, 0, (char *)"TraceType", 2, 0, 2, 0, 8, 0, 55, 0},
    {8, 1169, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {2, 1171, 0, (char *)"TraceReference", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 1173, 0, (char *)"TraceType", 2, 0, 2, 0, 8, 0, 55, 0},
    {20, 1371, 0, (char *)"AddressString", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 1389, 486, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 326, 12, 0},
    {-1, 1169, 486, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 326, 12, 0},
    {8, 1169, 0, (char *)"IMSI", 2, 0, 2, 2, 24, 0, 21, 0},
    {2, 1171, 0, (char *)"TraceReference", 2, 0, 2, 2, 24, 0, 21, 0},
    {-1, 1173, 486, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 326, 12, 0},
    {-1, 1169, 486, (char *)"ExtensionContainer", 504, 2, 1, 0, 12, 326, 12, 0},
    {20, 1169, 0, (char *)"_octet1", 2, 0, 2, 2, 56, 0, 21, 0},
    {20, 1171, 0, (char *)"", 2, 0, 2, 2, 56, 0, 21, 0},
    {-1, 1169, 486, (char *)"_seq2", 46, 2, 1, 0, 44, 467, 12, 0},
    {-1, 1171, 0, (char *)"_seq3", 1, 0, 0, 0, 44, 249, 12, 0},
    {-1, 1173, 0, (char *)"", 1, 0, 0, 0, 44, 249, 12, 0},
    {2, 358, 0, (char *)"_enum1", 4, 0, 4, 0, 56, 43, 58, 0},
    {-1, 1371, 1153, (char *)"_seq4", 4, 1, 0, 0, 44, 469, 12, 0},
    {-1, 1169, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 1171, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {1, 1173, 0, (char *)"_enum2", 4, 0, 4, 0, 56, 48, 58, 0},
    {6, 1371, 0, (char *)"_enum3", 4, 0, 4, 0, 56, 52, 58, 0},
    {-1, 2, 598, (char *)"_choice6", 8, 4, 2, 4, 40, 470, 13, 0},
    {-1, 1389, 1157, (char *)"_seq5", 8, 1, 0, 0, 44, 474, 12, 0},
    {1, 358, 0, (char *)"_enum4", 4, 0, 4, 0, 56, 61, 58, 0},
    {-1, 1422, 1153, (char *)"_seq6", 4, 1, 0, 0, 44, 475, 12, 0},
    {20, 1169, 0, (char *)"", 2, 0, 2, 2, 56, 0, 21, 0},
    {20, 1171, 0, (char *)"", 2, 0, 2, 2, 56, 0, 21, 0},
    {2, 358, 0, (char *)"", 4, 0, 4, 0, 56, 43, 58, 0},
    {-1, 1169, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 1171, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {1, 1173, 0, (char *)"", 4, 0, 4, 0, 56, 48, 58, 0},
    {6, 1371, 0, (char *)"", 4, 0, 4, 0, 56, 52, 58, 0},
    {-1, 2, 598, (char *)"", 8, 4, 2, 4, 40, 476, 13, 0},
    {-1, 1169, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {-1, 1171, 0, NULL, 1, 0, 0, 0, 8, 0, 5, 0},
    {1, 1173, 0, (char *)"", 4, 0, 4, 0, 56, 48, 58, 0},
    {6, 1371, 0, (char *)"", 4, 0, 4, 0, 56, 52, 58, 0},
    {1, 358, 0, (char *)"", 4, 0, 4, 0, 56, 61, 58, 0}
};

static const struct efield _efieldarray[] = {
    {8, 256, -1, 242, 2},
    {8, 257, -1, 243, 2},
    {8, 258, -1, 244, 2},
    {8, 259, -1, 245, 2},
    {8, 260, -1, 246, 2},
    {8, 263, -1, 247, 2},
    {8, 0, -1, 248, 2},
    {2, 303, -1, 249, 2},
    {10, 304, -1, 250, 2},
    {20, 305, -1, 251, 2},
    {32, 306, -1, 252, 2},
    {36, 310, 0, 253, 3},
    {38, 311, 1, 254, 3},
    {48, 312, 2, 255, 3},
    {50, 313, 3, 256, 3},
    {56, 314, 4, 257, 3},
    {2, 315, -1, 258, 2},
    {16, 300, 0, 257, 3},
    {2, 316, 0, 259, 3},
    {16, 300, 1, 257, 3},
    {8, 300, 0, 257, 3},
    {2, 316, 0, 259, 3},
    {12, 317, 1, 260, 3},
    {13, 318, 2, 261, 3},
    {14, 319, 3, 262, 3},
    {15, 320, 4, 263, 3},
    {16, 321, 5, 264, 3},
    {24, 300, 6, 257, 3},
    {1, 322, 0, 265, 3},
    {2, 323, 1, 261, 3},
    {3, 324, 2, 266, 3},
    {8, 300, 3, 257, 3},
    {0, 326, -1, 267, 2},
    {12, 327, -1, 268, 2},
    {14, 328, -1, 269, 2},
    {2, 316, -1, 259, 2},
    {12, 334, -1, 270, 2},
    {40, 335, 0, 257, 3},
    {2, 336, -1, 271, 2},
    {2, 337, -1, 272, 2},
    {2, 342, -1, 273, 2},
    {26, 346, -1, 274, 2},
    {50, 347, -1, 275, 2},
    {256, 300, 0, 257, 3},
    {2, 347, -1, 275, 2},
    {208, 300, 0, 257, 3},
    {2, 342, -1, 273, 2},
    {26, 346, -1, 274, 2},
    {50, 347, -1, 275, 2},
    {252, 275, 0, 276, 3},
    {256, 300, 1, 257, 3},
    {2, 347, 0, 275, 3},
    {208, 300, 1, 257, 3},
    {0, 315, -1, 267, 2},
    {12, 325, -1, 269, 2},
    {36, 348, -1, 277, 2},
    {2, 315, 0, 278, 3},
    {16, 300, 1, 257, 3},
    {0, 315, -1, 267, 2},
    {12, 325, -1, 269, 2},
    {2, 315, 0, 278, 3},
    {14, 349, 1, 279, 3},
    {16, 300, 2, 257, 3},
    {0, 351, -1, 259, 2},
    {12, 350, -1, 280, 2},
    {8, 300, 0, 257, 3},
    {2, 358, -1, 267, 2},
    {16, 359, 0, 281, 3},
    {536, 360, 1, 282, 3},
    {544, 361, 2, 283, 3},
    {2, 316, -1, 259, 2},
    {16, 370, -1, 284, 2},
    {576, 354, 0, 281, 3},
    {1, 371, 0, 285, 3},
    {2, 372, 1, 286, 3},
    {8, 373, 2, 257, 3},
    {2, 374, -1, 259, 2},
    {12, 375, -1, 271, 2},
    {24, 376, 0, 267, 3},
    {36, 377, 1, 287, 3},
    {48, 378, 2, 288, 3},
    {56, 379, 3, 289, 3},
    {776, 380, 4, 283, 3},
    {2, 315, -1, 290, 2},
    {16, 300, 0, 257, 3},
    {8, 300, 0, 257, 3},
    {8, 382, -1, 289, 2},
    {728, 383, -1, 291, 2},
    {1448, 384, -1, 292, 2},
    {1452, 385, -1, 293, 2},
    {1464, 386, -1, 294, 2},
    {2184, 387, 0, 295, 3},
    {2904, 388, 1, 296, 3},
    {3624, 389, 2, 257, 3},
    {2, 390, -1, 297, 2},
    {16, 391, 0, 257, 3},
    {8, 392, 0, 298, 3},
    {728, 393, 1, 294, 3},
    {1448, 394, 2, 257, 3},
    {8, 395, 0, 294, 3},
    {728, 396, 1, 257, 3},
    {2, 407, -1, 259, 2},
    {16, 408, 0, 299, 3},
    {528, 409, 1, 300, 3},
    {1048, 410, 2, 257, 3},
    {8, 411, 0, 257, 3},
    {2, 352, -1, 301, 2},
    {6, 415, 0, 302, 3},
    {12, 418, 1, 303, 3},
    {34, 419, 2, 304, 3},
    {58, 420, 3, 305, 3},
    {60, 421, 4, 306, 11},
    {62, 422, 5, 307, 11},
    {64, 423, 6, 308, 11},
    {4, 464, -1, 309, 2},
    {4, 465, -1, 310, 2},
    {4, 466, -1, 311, 2},
    {4, 467, -1, 312, 2},
    {2, 352, -1, 301, 2},
    {6, 415, 0, 302, 3},
    {2, 352, -1, 301, 2},
    {6, 415, 0, 302, 3},
    {2, 352, -1, 301, 2},
    {6, 415, 0, 302, 3},
    {2, 352, -1, 301, 2},
    {6, 415, 0, 302, 3},
    {2, 352, -1, 301, 2},
    {6, 415, 0, 302, 3},
    {4, 478, -1, 313, 2},
    {4, 479, -1, 314, 2},
    {4, 480, -1, 315, 2},
    {4, 481, -1, 316, 2},
    {2, 482, -1, 317, 2},
    {6, 483, -1, 318, 2},
    {168, 484, 0, 319, 11},
    {0, 482, -1, 317, 2},
    {4, 483, -1, 318, 2},
    {2, 488, -1, 320, 2},
    {48, 489, -1, 321, 2},
    {60, 490, 0, 322, 3},
    {64, 491, -1, 323, 2},
    {784, 492, -1, 283, 2},
    {2, 494, -1, 259, 2},
    {2, 495, -1, 324, 2},
    {2, 501, -1, 325, 2},
    {8, 502, 0, 257, 3},
    {2, 316, -1, 259, 2},
    {12, 507, -1, 271, 2},
    {24, 315, -1, 326, 2},
    {36, 508, 0, 288, 3},
    {48, 300, 1, 257, 3},
    {2, 315, -1, 327, 2},
    {2, 509, -1, 328, 2},
    {2, 316, -1, 259, 2},
    {2, 510, -1, 329, 2},
    {2, 316, -1, 259, 2},
    {2, 510, -1, 329, 2},
    {8, 300, 0, 257, 3},
    {0, 316, -1, 259, 2},
    {10, 315, -1, 326, 2},
    {1, 511, 0, 330, 3},
    {2, 512, 1, 331, 3},
    {8, 300, 2, 257, 3},
    {2, 316, -1, 259, 2},
    {12, 516, 0, 332, 3},
    {2, 498, 0, 333, 3},
    {12, 275, 1, 334, 3},
    {16, 357, 2, 335, 3},
    {2, 315, 0, 336, 3},
    {16, 357, 1, 335, 3},
    {0, 498, -1, 333, 2},
    {10, 315, -1, 337, 2},
    {24, 357, -1, 335, 2},
    {2, 526, 0, 259, 3},
    {12, 527, 1, 267, 3},
    {24, 528, 2, 338, 3},
    {28, 529, 3, 339, 3},
    {32, 530, 4, 340, 3},
    {234, 531, 5, 341, 3},
    {316, 532, 6, 342, 3},
    {35000, 533, 7, 343, 3},
    {35512, 534, 8, 344, 3},
    {35514, 535, 9, 345, 3},
    {2, 574, 0, 341, 3},
    {84, 575, 1, 340, 3},
    {286, 576, 2, 346, 3},
    {408, 577, 3, 347, 3},
    {412, 578, 4, 348, 3},
    {2, 580, -1, 259, 2},
    {12, 581, 0, 349, 3},
    {434, 582, 1, 346, 3},
    {556, 583, 2, 344, 3},
    {558, 584, 3, 350, 3},
    {4, 585, 0, 348, 3},
    {8, 300, 1, 257, 3},
    {2, 315, -1, 327, 2},
    {14, 497, 0, 351, 3},
    {2, 316, -1, 259, 2},
    {12, 332, 0, 288, 3},
    {24, 300, 1, 257, 3},
    {2, 315, -1, 327, 2},
    {14, 275, 0, 352, 3},
    {16, 300, 1, 257, 3},
    {4, 598, -1, 353, 2},
    {8, 300, 0, 257, 3},
    {8, 599, -1, 354, 2},
    {8, 601, -1, 355, 2},
    {4, 602, 0, 356, 3},
    {8, 300, 1, 257, 3},
    {2, 603, 0, 301, 3},
    {6, 415, 1, 302, 3},
    {12, 604, 2, 313, 3},
    {4, 605, -1, 357, 2},
    {8, 347, 0, 358, 3},
    {216, 300, 1, 257, 3},
    {2, 606, 0, 359, 3},
    {8, 300, 1, 257, 3},
    {512, 607, 2, 360, 11},
    {8, 499, -1, 361, 2},
    {8, 608, -1, 362, 2},
    {8, 300, 0, 257, 3},
    {8, 300, 0, 257, 3},
    {8, 300, 0, 257, 3},
    {8, 300, 0, 257, 3},
    {8, 300, 0, 257, 3},
    {512, 609, 1, 363, 11},
    {8, 300, 0, 257, 3},
    {8, 300, 0, 257, 3},
    {8, 300, 0, 257, 3},
    {8, 300, 0, 257, 3},
    {8, 300, 0, 257, 3},
    {8, 300, 0, 257, 3},
    {8, 300, 0, 257, 3},
    {8, 300, 0, 257, 3},
    {8, 300, 0, 257, 3},
    {512, 611, 1, 364, 11},
    {8, 300, 0, 257, 3},
    {512, 612, 1, 285, 11},
    {513, 613, 2, 365, 11},
    {8, 300, 0, 257, 3},
    {8, 300, 0, 257, 3},
    {8, 300, 0, 257, 3},
    {8, 300, 0, 257, 3},
    {8, 300, 0, 257, 3},
    {512, 275, 1, 366, 11},
    {8, 300, 0, 257, 3},
    {8, 300, 0, 257, 3},
    {8, 300, 0, 257, 3},
    {8, 300, 0, 257, 3},
    {2, 616, 0, 259, 3},
    {12, 617, -1, 367, 2},
    {16, 618, -1, 368, 2},
    {18, 619, 1, 369, 3},
    {40, 620, 2, 257, 3},
    {8, 621, 0, 257, 3},
    {2, 622, 0, 259, 3},
    {12, 623, -1, 367, 2},
    {16, 624, 1, 257, 3},
    {8, 625, 0, 257, 3},
    {4, 628, -1, 370, 2},
    {4, 629, -1, 371, 2},
    {4, 630, -1, 372, 2},
    {4, 632, -1, 373, 2},
    {4, 638, -1, 374, 2},
    {4, 640, -1, 375, 2},
    {2, 641, 0, 376, 3},
    {24, 642, 1, 377, 3},
    {0, 643, -1, 378, 2},
    {0, 648, -1, 379, 2},
    {4, 649, -1, 380, 2},
    {4, 650, -1, 381, 2},
    {4, 651, -1, 382, 2},
    {4, 652, -1, 383, 2},
    {0, 653, -1, 384, 2},
    {8, 241, -1, 385, 2},
    {8, 242, -1, 386, 2},
    {8, 243, -1, 387, 2},
    {8, 238, 0, 388, 3},
    {16, 239, 1, 389, 3},
    {24, 240, -1, 390, 3},
    {32, 244, -1, 391, 2},
    {8, 246, 0, 392, 3},
    {80, 289, -1, 393, 2},
    {2, 248, -1, 394, 2},
    {8, 246, 0, 392, 3},
    {80, 289, 1, 393, 3},
    {2, 250, -1, 395, 2},
    {8, 246, 0, 392, 3},
    {80, 289, 1, 393, 3},
    {2, 248, -1, 394, 2},
    {8, 250, -1, 395, 2},
    {16, 246, 0, 392, 3},
    {88, 289, 1, 393, 3},
    {8, 253, -1, 396, 2},
    {8, 246, -1, 397, 2},
    {2, 250, -1, 395, 2},
    {8, 254, 0, 378, 3},
    {2, 261, -1, 398, 2},
    {4, 262, 0, 399, 3},
    {8, 264, -1, 400, 2},
    {24, 265, 1, 401, 3},
    {0, 264, -1, 400, 2},
    {16, 265, -1, 401, 2},
    {2, 261, -1, 398, 2},
    {8, 267, 0, 402, 3},
    {2, 261, -1, 398, 2},
    {8, 264, -1, 403, 2},
    {24, 269, 0, 401, 3},
    {2, 261, -1, 404, 2},
    {2, 275, -1, 405, 2},
    {4, 277, -1, 406, 2},
    {4, 278, -1, 407, 2},
    {4, 279, -1, 408, 2},
    {4, 280, -1, 409, 2},
    {0, 276, -1, 398, 2},
    {4, 281, -1, 410, 2},
    {8, 283, -1, 411, 2},
    {8, 284, -1, 412, 2},
    {8, 285, -1, 413, 2},
    {8, 286, -1, 414, 2},
    {8, 287, -1, 415, 2},
    {2, 290, 0, 416, 3},
    {8, 0, -1, 417, 2},
    {16, 291, -1, 418, 66},
    {8, 293, -1, 419, 18},
    {16, 294, 0, 420, 3},
    {8, 298, 0, 421, 3},
    {496, 299, 1, 422, 3},
    {2, 329, -1, 290, 2},
    {2, 330, -1, 271, 2},
    {2, 331, -1, 423, 2},
    {16, 332, 0, 288, 3},
    {2, 338, -1, 259, 2},
    {2, 339, -1, 288, 2},
    {2, 340, -1, 424, 2},
    {2, 341, -1, 425, 2},
    {2, 343, -1, 267, 2},
    {2, 344, -1, 426, 2},
    {2, 345, -1, 427, 2},
    {2, 353, -1, 428, 2},
    {8, 275, 0, 429, 3},
    {16, 300, 1, 257, 3},
    {4, 356, -1, 430, 2},
    {8, 347, -1, 431, 2},
    {216, 300, 0, 257, 3},
    {2, 365, 0, 303, 3},
    {14, 366, 1, 304, 3},
    {38, 367, 2, 432, 3},
    {48, 368, 3, 257, 3},
    {8, 315, -1, 290, 2},
    {8, 369, -1, 433, 2},
    {4, 398, 0, 434, 3},
    {8, 399, 1, 257, 3},
    {4, 403, 0, 435, 3},
    {8, 404, 1, 436, 3},
    {16, 405, 2, 257, 3},
    {2, 413, -1, 437, 2},
    {2, 414, -1, 249, 2},
    {2, 424, -1, 438, 2},
    {4, 425, -1, 428, 2},
    {12, 426, -1, 439, 2},
    {16, 427, 0, 314, 3},
    {2, 415, 0, 302, 3},
    {8, 424, 1, 440, 3},
    {10, 430, -1, 441, 2},
    {4, 429, -1, 442, 2},
    {968, 432, 0, 443, 3},
    {2, 415, 0, 302, 3},
    {8, 436, 1, 313, 3},
    {12, 437, 2, 303, 3},
    {24, 438, 3, 304, 3},
    {48, 439, 4, 432, 3},
    {52, 440, 5, 305, 3},
    {54, 441, 6, 444, 11},
    {2, 352, 0, 301, 3},
    {6, 443, -1, 315, 2},
    {2, 415, 0, 302, 3},
    {8, 445, 1, 313, 3},
    {2, 352, 0, 301, 3},
    {6, 447, -1, 445, 2},
    {4, 451, -1, 446, 2},
    {4, 452, -1, 447, 2},
    {2, 455, 0, 448, 3},
    {4, 456, 1, 449, 3},
    {16, 457, 2, 450, 3},
    {40, 458, 3, 451, 3},
    {2, 352, 0, 301, 3},
    {6, 460, 1, 313, 3},
    {12, 453, 2, 452, 3},
    {20, 427, 3, 314, 3},
    {100, 309, 4, 306, 11},
    {102, 461, 5, 320, 11},
    {148, 462, 6, 307, 11},
    {2, 434, -1, 313, 2},
    {8, 449, 0, 446, 3},
    {12, 471, 1, 453, 11},
    {14, 472, 2, 306, 11},
    {16, 473, 3, 454, 11},
    {248, 474, 4, 455, 11},
    {250, 475, 5, 307, 11},
    {252, 476, 6, 456, 11},
    {2, 503, -1, 457, 2},
    {2, 504, -1, 458, 2},
    {2, 309, -1, 459, 2},
    {4, 309, -1, 306, 2},
    {8, 300, 0, 257, 3},
    {0, 315, -1, 327, 2},
    {0, 316, -1, 259, 2},
    {10, 332, -1, 288, 2},
    {0, 513, -1, 460, 2},
    {18, 514, -1, 461, 2},
    {24, 308, -1, 462, 2},
    {1, 521, -1, 347, 2},
    {2, 522, 0, 463, 3},
    {8, 300, 1, 257, 3},
    {2, 505, 0, 302, 3},
    {12, 539, -1, 313, 2},
    {20, 540, 1, 303, 3},
    {32, 541, 2, 304, 3},
    {56, 542, 3, 432, 3},
    {64, 543, 4, 305, 3},
    {72, 544, 5, 257, 3},
    {2, 352, -1, 301, 2},
    {8, 546, -1, 315, 2},
    {18448, 547, 0, 257, 3},
    {2, 505, 0, 302, 3},
    {12, 549, -1, 313, 2},
    {24, 300, 1, 257, 3},
    {2, 352, -1, 301, 2},
    {8, 551, -1, 445, 2},
    {16912, 300, 0, 257, 3},
    {2, 553, -1, 438, 2},
    {4, 353, -1, 428, 2},
    {12, 554, -1, 439, 2},
    {16, 555, 0, 314, 3},
    {344, 556, 1, 257, 3},
    {2, 505, 0, 302, 3},
    {12, 553, 1, 440, 3},
    {14, 559, -1, 441, 2},
    {24, 300, 2, 257, 3},
    {8, 558, -1, 442, 2},
    {8496, 561, 0, 443, 3},
    {25400, 562, 1, 257, 3},
    {2, 352, -1, 301, 2},
    {6, 564, -1, 313, 2},
    {16, 453, 0, 452, 3},
    {24, 555, 1, 314, 3},
    {352, 565, 2, 257, 3},
    {8, 567, -1, 309, 2},
    {8, 568, -1, 310, 2},
    {8, 569, -1, 311, 2},
    {8, 570, -1, 312, 2},
    {8, 571, -1, 464, 2},
    {2, 587, -1, 465, 2},
    {8, 275, 0, 466, 3},
    {16, 300, 1, 257, 3},
    {2, 587, -1, 467, 2},
    {8, 300, 0, 257, 3},
    {4, 594, -1, 468, 2},
    {4, 595, -1, 469, 2},
    {4, 593, -1, 470, 2},
    {4, 596, -1, 471, 2},
    {4, 599, 0, 354, 3},
    {8, 300, 1, 257, 3},
    {512, 600, 2, 472, 11},
    {4, 499, 0, 361, 3},
    {8, 300, 1, 257, 3},
    {2, 626, 0, 376, 3},
    {24, 627, 1, 377, 3},
    {0, 631, -1, 378, 2},
    {4, 633, -1, 380, 2},
    {4, 634, -1, 381, 2},
    {4, 635, -1, 382, 2},
    {4, 636, -1, 383, 2},
    {0, 637, -1, 379, 2},
    {0, 639, -1, 384, 2},
    {4, 644, -1, 380, 2},
    {4, 645, -1, 381, 2},
    {4, 646, -1, 382, 2},
    {4, 647, -1, 383, 2}
};

#ifdef OSS_SPARTAN_AWARE
#if ((OSS_SPARTAN_AWARE + 0) > 12)
typedef struct ExtParms {
    int           versId;
    const void    *xparm[7];
} ExtParms;
static ExtParms const extParms = {
    25,
    {NULL, NULL, NULL, NULL, (void *)0, (void *)0, (void *)8}
};
#endif /* OSS_SPARTAN_AWARE  > 12 */
#endif /* OSS_SPARTAN_AWARE */

static void * const _enamearray[] = {
    (void *)0,
    (void *)0x2, (void *)_v35,
    (void *)"basicCall", (void *)"forwarding",
    (void *)0x3, (void *)_v35,
    (void *)"notReachable", (void *)"busy", (void *)"noReply",
    (void *)0x3, (void *)_v35,
    (void *)"enterPW", (void *)"enterNewPW", (void *)"enterNewPW-Again",
    (void *)0x2, (void *)_v35,
    (void *)"updateProcedure", (void *)"subscriptionWithdraw",
    (void *)0x1, (void *)_v50, (void *)"oss-unknown-enumerator",
    (void *)0x3, (void *)_v35,
    (void *)"whiteListed", (void *)"blackListed", (void *)"greyListed",
    (void *)0x2, (void *)_v35,
    (void *)"forwarded", (void *)"notForwarded",
    (void *)0x2, (void *)_v35,
    (void *)"continueCall", (void *)"releaseCall",
    (void *)0x1, (void *)_v50, (void *)"oss-unknown-enumerator",
    (void *)0x3, (void *)_v35,
    (void *)"undetermined", (void *)"invalidFormat", (void *)"newPasswordsMismatch",
    (void *)0x3, (void *)_v35,
    (void *)"noReasonGiven", (void *)"invalidDestinationReference", (void *)"invalidOriginatingReference",
    (void *)0x2, (void *)_v35,
    (void *)"shortTermResourceLimitation", (void *)"longTermResourceLimitation",
    (void *)0x7, (void *)_v35,
    (void *)"handoverCancellation", (void *)"radioChannelRelease", (void *)"networkPathRelease", (void *)"callRelease", (void *)"associatedProcedureFailure",
    (void *)"tandemDialogueRelease", (void *)"remoteOperationsFailure",
    (void *)0x2, (void *)_v35,
    (void *)"abnormalDialogue", (void *)"invalidPDU",
    (void *)0x5, (void *)_v35,
    (void *)"unrecognizedMessageType", (void *)"unrecognizedTransactionID", (void *)"badlyFormattedTransactionPortion", (void *)"incorrectTransactionPortion", (void *)"resourceLimitation",
    (void *)0x3, (void *)_v35,
    (void *)"unrecognizedComponent", (void *)"mistypedComponent", (void *)"badlyStructuredComponent",
    (void *)0x8, (void *)_v35,
    (void *)"duplicateInvokeID", (void *)"unrecognizedOperation", (void *)"mistypedParameter", (void *)"resourceLimitation", (void *)"initiatingRelease",
    (void *)"unrecognizedLinkedID", (void *)"linkedResponseUnexpected", (void *)"unexpectedLinkedOperation",
    (void *)0x3, (void *)_v35,
    (void *)"unrecognizedInvokeID", (void *)"returnResultUnexpected", (void *)"mistypedParameter",
    (void *)0x5, (void *)_v35,
    (void *)"unrecognizedInvokeID", (void *)"returnErrorUnexpected", (void *)"unrecognizedError", (void *)"unexpectedError", (void *)"mistypedParameter",
    (void *)0x3, (void *)_v35,
    (void *)"memoryCapacityExceeded", (void *)"absentSubscriber", (void *)"successfulTransfer",
    (void *)0x10003, (void *)_v22,
    (void *)"sc-AddressNotIncluded", (void *)"mnrf-Set", (void *)"mcef-Set",
    (void *)0x2, (void *)_v35,
    (void *)"ms-Present", (void *)"memoryAvailable",
    (void *)0x4, (void *)_v24,
    (void *)"gsm-0408", (void *)"gsm-0806", (void *)"gsm-BSSMAP", (void *)"ets-300102-1",
    (void *)0x3, (void *)_v35,
    (void *)"ccbsNotIdle", (void *)"ccbsIdle", (void *)"ccbsNotReachable",
    (void *)0x1, (void *)_v50, (void *)"oss-unknown-enumerator",
    (void *)0x2, (void *)_v35,
    (void *)"a-side", (void *)"b-side",
    (void *)0x1, (void *)_v50, (void *)"oss-unknown-enumerator",
    (void *)0x3, (void *)_v35,
    (void *)"success", (void *)"failure", (void *)"busy",
    (void *)0x1, (void *)_v50, (void *)"oss-unknown-enumerator",
    (void *)0x3, (void *)_v35,
    (void *)"noCUG-Restrictions", (void *)"cugIC-CallBarred", (void *)"cugOG-CallBarred",
    (void *)0x3, (void *)_v35,
    (void *)"permanent", (void *)"temporaryDefaultRestricted", (void *)"temporaryDefaultAllowed",
    (void *)0x2, (void *)_v35,
    (void *)"overrideEnabled", (void *)"overrideDisabled",
    (void *)0x10002, (void *)_v34,
    (void *)"clir-invoked", (void *)"camel-invoked",
    (void *)0x8, (void *)_v35,
    (void *)"plmn", (void *)"hlr", (void *)"vlr", (void *)"pvlr", (void *)"controllingMSC",
    (void *)"vmsc", (void *)"eir", (void *)"rss",
    (void *)0x2, (void *)_v35,
    (void *)"serviceGranted", (void *)"operatorDeterminedBarring",
    (void *)0x10006, (void *)_v37,
    (void *)"allOG-CallsBarred", (void *)"internationalOGCallsBarred", (void *)"internationalOGCallsNotToHPLMN-CountryBarred", (void *)"premiumRateInformationOGCallsBarred", (void *)"premiumRateEntertainementOGCallsBarred",
    (void *)"ss-AccessBarred",
    (void *)0x10004, (void *)_v38,
    (void *)"plmn-SpecificBarringType1", (void *)"plmn-SpecificBarringType2", (void *)"plmn-SpecificBarringType3", (void *)"plmn-SpecificBarringType4",
    (void *)0x4, (void *)_v35,
    (void *)"networkNode-AreaRestricted", (void *)"tooManyZoneCodes", (void *)"zoneCodesConflict", (void *)"regionalSubscNotSupported",
    (void *)0x2, (void *)_v35,
    (void *)"inhibiting", (void *)"enabling",
    (void *)0x4, (void *)_v35,
    (void *)"msPurged", (void *)"imsiDetached", (void *)"restrictedArea", (void *)"notRegistered",
    (void *)0x2, (void *)_v43,
    (void *)"plmnRoamingNotAllowed", (void *)"operatorDeterminedBarring",
    (void *)0x2, (void *)_v35,
    (void *)"barringServiceActive", (void *)"operatorBarring",
    (void *)0x4, (void *)_v45,
    (void *)"incomingCallsBarredWithinCUG", (void *)"subscriberNotMemberOfCUG", (void *)"requestedBasicServiceViolatesCUG-Constraints", (void *)"calledPartySS-InteractionViolation",
    (void *)0x7, (void *)_v35,
    (void *)"memoryCapacityExceeded", (void *)"equipmentProtocolError", (void *)"equipmentNotSM-Equipped", (void *)"unknownServiceCentre", (void *)"sc-Congestion",
    (void *)"invalidSME-Address", (void *)"subscriberNotSC-Subscriber",
    (void *)0x2, (void *)_v35,
    (void *)"imsiUnknown", (void *)"gprsSubscriptionUnknown",
    (void *)0x1, (void *)_v50, (void *)"oss-unknown-enumerator",
    (void *)0x3, (void *)_v35,
    (void *)"imsiDetach", (void *)"restrictedArea", (void *)"noPageResponse",
    (void *)0x1, (void *)_v50, (void *)"oss-unknown-enumerator",
    (void *)"unidirectional",
    (void *)"begin",
    (void *)"end",
    (void *)"continue",
    (void *)"abort",
    (void *)"localValue",
    (void *)"globalValue",
    (void *)"teleservice",
    (void *)"asciCallReference",
    (void *)"codec-Info",
    (void *)"cipheringAlgorithm",
    (void *)"groupKeyNumber",
    (void *)"groupKey",
    (void *)"priority",
    (void *)"uplinkFree",
    (void *)"extensionContainer",
    (void *)"groupCallNumber",
    (void *)"imsi",
    (void *)"uplinkRequestAck",
    (void *)"uplinkReleaseIndication",
    (void *)"uplinkRejectCommand",
    (void *)"uplinkSeizedCommand",
    (void *)"uplinkReleaseCommand",
    (void *)"uplinkRequest",
    (void *)"releaseGroupCall",
    (void *)"msisdn",
    (void *)"sm-RP-PRI",
    (void *)"serviceCentreAddress",
    (void *)"locationInfoWithLMSI",
    (void *)"msc-Number",
    (void *)"sgsn-Number",
    (void *)"sm-RP-DA",
    (void *)"sm-RP-OA",
    (void *)"sm-RP-UI",
    (void *)"moreMessagesToSend",
    (void *)"sm-DeliveryOutcome",
    (void *)"storedMSISDN",
    (void *)"mw-Status",
    (void *)"alertReason",
    (void *)"cug-CheckInfo",
    (void *)"numberOfForwarding",
    (void *)"networkSignalInfo",
    (void *)"routingInfo",
    (void *)"ccbs-Possible",
    (void *)"keepCCBS-CallIndicator",
    (void *)"previousRoamingNumber",
    (void *)"lmsi",
    (void *)"gsm-BearerCapability",
    (void *)"roamingNumber",
    (void *)"isdn-BearerCapability",
    (void *)"call-Direction",
    (void *)"b-Subscriber-Address",
    (void *)"chosenChannel",
    (void *)"lowerLayerCompatibility",
    (void *)"highLayerCompatibility",
    (void *)"sIWFSNumber",
    (void *)"channelType",
    (void *)"eventReportData",
    (void *)"callReportdata",
    (void *)"ss-Code",
    (void *)"basicService",
    (void *)"forwardedToNumber",
    (void *)"forwardedToSubaddress",
    (void *)"noReplyConditionTime",
    (void *)"defaultPriority",
    (void *)"nbrUser",
    (void *)"longFTN-Supported",
    (void *)"forwardingInfo",
    (void *)"callBarringInfo",
    (void *)"cug-Info",
    (void *)"ss-Data",
    (void *)"ss-Status",
    (void *)"basicServiceGroupList",
    (void *)"forwardingFeatureList",
    (void *)"genericServiceInfo",
    (void *)"ussd-DataCodingScheme",
    (void *)"ussd-String",
    (void *)"alertingPattern",
    (void *)"ccbs-Feature",
    (void *)"translatedB-Number",
    (void *)"serviceIndicator",
    (void *)"callInfo",
    (void *)"tmsi",
    (void *)"naea-PreferredCIC",
    (void *)"vlr-Number",
    (void *)"hlr-Number",
    (void *)"extensibleUpdateLocationRes",
    (void *)"imsi-WithLMSI",
    (void *)"freezeTMSI",
    (void *)"freezeP-TMSI",
    (void *)"authenticationSetList",
    (void *)"targetCellId",
    (void *)"ho-NumberNotRequired",
    (void *)"bss-APDU",
    (void *)"handoverNumber",
    (void *)"targetMSC-Number",
    (void *)"category",
    (void *)"subscriberStatus",
    (void *)"bearerServiceList",
    (void *)"teleserviceList",
    (void *)"provisionedSS",
    (void *)"odb-Data",
    (void *)"roamingRestrictionDueToUnsupportedFeature",
    (void *)"regionalSubscriptionData",
    (void *)"ss-List",
    (void *)"odb-GeneralData",
    (void *)"regionalSubscriptionResponse",
    (void *)"basicServiceList",
    (void *)"regionalSubscriptionIdentifier",
    (void *)"hlr-List",
    (void *)"msNotReachable",
    (void *)"roamingNotAllowedCause",
    (void *)"callBarringCause",
    (void *)"extensibleCallBarredParam",
    (void *)"cug-RejectCause",
    (void *)"sm-EnumeratedDeliveryFailureCause",
    (void *)"diagnosticInfo",
    (void *)"absentSubscriberDiagnosticSM",
    (void *)"additionalAbsentSubscriberDiagnosticSM",
    (void *)"networkResource",
    (void *)"extensibleSystemFailureParam",
    (void *)"unknownSubscriberDiagnostic",
    (void *)"absentSubscriberReason",
    (void *)"ccbs-Busy",
    (void *)"gprsConnectionSuspended",
    (void *)"traceReference",
    (void *)"traceType",
    (void *)"omc-Id",
    (void *)"map-open",
    (void *)"map-accept",
    (void *)"map-close",
    (void *)"map-refuse",
    (void *)"map-userAbort",
    (void *)"map-providerAbort",
    (void *)"destinationReference",
    (void *)"originationReference",
    (void *)"reason",
    (void *)"map-UserAbortChoice",
    (void *)"userSpecificReason",
    (void *)"userResourceLimitation",
    (void *)"resourceUnavailable",
    (void *)"applicationProcedureCancellation",
    (void *)"map-ProviderAbortReason",
    (void *)"single-ASN1-type",
    (void *)"octet-aligned",
    (void *)"arbitrary",
    (void *)"direct-reference",
    (void *)"indirect-reference",
    (void *)"data-value-descriptor",
    (void *)"encoding",
    (void *)"dialoguePortion",
    (void *)"components",
    (void *)"otid",
    (void *)"dtid",
    (void *)"p-abortCause",
    (void *)"u-abortCause",
    (void *)"invokeID",
    (void *)"linkedID",
    (void *)"operationCode",
    (void *)"parameter",
    (void *)"result",
    (void *)"errorCode",
    (void *)"derivable",
    (void *)"not-derivable",
    (void *)"generalProblem",
    (void *)"invokeProblem",
    (void *)"returnResultProblem",
    (void *)"returnErrorProblem",
    (void *)"problem",
    (void *)"invoke",
    (void *)"returnResultLast",
    (void *)"returnError",
    (void *)"reject",
    (void *)"returnResultNotLast",
    (void *)"ExtensionType",
    (void *)"extensionId",
    (void *)"_oss_unique_index",
    (void *)"extId",
    (void *)"extType",
    (void *)"privateExtensionList",
    (void *)"pcs-Extensions",
    (void *)"locationInfo",
    (void *)"serviceCentreAddressDA",
    (void *)"noSM-RP-DA",
    (void *)"serviceCentreAddressOA",
    (void *)"noSM-RP-OA",
    (void *)"cug-Interlock",
    (void *)"cug-OutgoingAccess",
    (void *)"protocolId",
    (void *)"signalInfo",
    (void *)"forwardingOptions",
    (void *)"forwardingData",
    (void *)"ccbs-SubscriberStatus",
    (void *)"monitoringMode",
    (void *)"callOutcome",
    (void *)"bearerService",
    (void *)"cug-Index",
    (void *)"intraCUG-Options",
    (void *)"preferentialCUG-Indicator",
    (void *)"interCUG-Restrictions",
    (void *)"cug-SubscriptionList",
    (void *)"cug-FeatureList",
    (void *)"longForwardedToNumber",
    (void *)"callBarringFeatureList",
    (void *)"cliRestrictionOption",
    (void *)"overrideCategory",
    (void *)"ccbs-Index",
    (void *)"b-subscriberNumber",
    (void *)"b-subscriberSubaddress",
    (void *)"basicServiceGroup",
    (void *)"ss-SubscriptionOption",
    (void *)"maximumEntitledPriority",
    (void *)"ccbs-FeatureList",
    (void *)"nbrSB",
    (void *)"nbrSN",
    (void *)"ext-BearerService",
    (void *)"ext-Teleservice",
    (void *)"maximumentitledPriority",
    (void *)"rand",
    (void *)"sres",
    (void *)"kc",
    (void *)"odb-HPLMN-Data",
    (void *)"emlpp-Info",
    (void *)"groupid",
    (void *)"broadcastInitEntitlement",
    (void *)"groupId",
    (void *)"assumedIdle",
    (void *)"camelBusy",
    (void *)"netDetNotReachable",
    (void *)"notProvidedFromVLR",
    (void *)"unauthorisedMessageOriginator"
};

static const Etag _tagarray[] = {
    1, 0x0006, 0, 5, 0x4001, 1, 0x4002, 2, 0x4004, 3,
    0x4005, 4, 0x4007, 5, 2, 0x0002, 1, 0x0006, 2, 1,
    0x0010, 30, 33, 36, 39, 42, 53, 62, 69, 74,
    1, 0x0004, 1, 1, 0x0004, 2, 1, 0x0004, 3, 1,
    0x0004, 4, 5, 0x8000, 5, 0x8001, 6, 0x8002, 7, 0x8003,
    8, 0x8004, 9, 4, 0x8001, 6, 0x8002, 7, 0x8003, 8,
    0x8004, 9, 3, 0x8002, 7, 0x8003, 8, 0x8004, 9, 2,
    0x8003, 8, 0x8004, 9, 1, 0x8004, 9, 79, 82, 1,
    0x0004, 1, 1, 0x0010, 2, 87, 92, 2, 0x0004, 1,
    0x0010, 2, 1, 0x0010, 2, 96, 1, 0x0010, 1, 106,
    121, 134, 145, 154, 161, 166, 7, 0x0004, 1, 0x0010,
    7, 0x8000, 2, 0x8001, 3, 0x8002, 4, 0x8003, 5, 0x8004,
    6, 6, 0x0010, 7, 0x8000, 2, 0x8001, 3, 0x8002, 4,
    0x8003, 5, 0x8004, 6, 5, 0x0010, 7, 0x8001, 3, 0x8002,
    4, 0x8003, 5, 0x8004, 6, 4, 0x0010, 7, 0x8002, 4,
    0x8003, 5, 0x8004, 6, 3, 0x0010, 7, 0x8003, 5, 0x8004,
    6, 2, 0x0010, 7, 0x8004, 6, 1, 0x0010, 7, 173,
    182, 189, 194, 4, 0x0010, 4, 0x8000, 1, 0x8001, 2,
    0x8002, 3, 3, 0x0010, 4, 0x8001, 2, 0x8002, 3, 2,
    0x0010, 4, 0x8002, 3, 1, 0x0010, 4, 200, 203, 206,
    1, 0x8000, 1, 1, 0x8001, 2, 1, 0x8002, 3, 1,
    0x0002, 1, 0x0004, 216, 219, 222, 1, 0x0004, 1, 1,
    0x8000, 2, 1, 0x8004, 3, 2, 0x8000, 1, 0x8001, 2,
    234, 243, 250, 253, 4, 0x8000, 1, 0x8001, 1, 0x8004,
    1, 0x8005, 1, 3, 0x8002, 2, 0x8004, 2, 0x8005, 2,
    1, 0x0004, 3, 1, 0x0010, 4, 261, 270, 277, 280,
    285, 4, 0x8000, 1, 0x8001, 1, 0x8004, 1, 0x8005, 1,
    3, 0x8002, 2, 0x8004, 2, 0x8005, 2, 1, 0x0004, 3,
    2, 0x0005, 4, 0x0010, 5, 1, 0x0010, 5, 291, 294,
    297, 1, 0x0004, 1, 1, 0x0004, 2, 1, 0x000a, 3,
    302, 305, 1, 0x0004, 1, 1, 0x0004, 2, 311, 318,
    323, 3, 0x0003, 2, 0x0004, 1, 0x0010, 3, 2, 0x0003,
    2, 0x0010, 3, 1, 0x0010, 3, 328, 331, 1, 0x8000,
    1, 1, 0x000a, 2, 338, 341, 348, 353, 1, 0x8000,
    1, 3, 0x8001, 2, 0x8002, 3, 0x800a, 4, 2, 0x8002,
    3, 0x800a, 4, 1, 0x800a, 4, 1, 0x0005, 1, 0x000a,
    363, 366, 371, 1, 0x0004, 1, 2, 0x0004, 2, 0x0010,
    2, 1, 0x0010, 3, 377, 384, 389, 3, 0x8000, 1,
    0x8001, 2, 0x8002, 3, 2, 0x8001, 2, 0x8002, 3, 1,
    0x8002, 3, 399, 402, 405, 416, 425, 432, 437, 1,
    0x8000, 1, 1, 0x8001, 2, 5, 0x8002, 3, 0x8003, 4,
    0x8004, 5, 0x8005, 6, 0x8006, 7, 4, 0x8003, 4, 0x8004,
    5, 0x8005, 6, 0x8006, 7, 3, 0x8004, 5, 0x8005, 6,
    0x8006, 7, 2, 0x8005, 6, 0x8006, 7, 1, 0x8006, 7,
    448, 451, 454, 457, 460, 463, 470, 475, 1, 0x8000,
    1, 1, 0x8001, 2, 1, 0x8002, 3, 1, 0x8003, 4,
    1, 0x8004, 5, 3, 0x8005, 6, 0x8006, 7, 0x8007, 8,
    2, 0x8006, 7, 0x8007, 8, 1, 0x8007, 8, 480, 483,
    1, 0x8000, 1, 1, 0x8001, 2, 488, 493, 2, 0x8000,
    1, 0x8001, 2, 1, 0x8001, 2, 500, 503, 510, 515,
    1, 0x8000, 1, 3, 0x8001, 2, 0x8002, 3, 0x8003, 4,
    2, 0x8002, 3, 0x8003, 4, 1, 0x8003, 4, 519, 1,
    0x8000, 1, 530, 533, 550, 563, 574, 583, 590, 595,
    1, 0x0004, 1, 8, 0x8002, 2, 0x8003, 2, 0x8004, 3,
    0x8005, 5, 0x8006, 4, 0x8007, 6, 0x8008, 7, 0x8009, 8,
    6, 0x8004, 3, 0x8005, 5, 0x8006, 4, 0x8007, 6, 0x8008,
    7, 0x8009, 8, 5, 0x8005, 5, 0x8006, 4, 0x8007, 6,
    0x8008, 7, 0x8009, 8, 4, 0x8005, 5, 0x8007, 6, 0x8008,
    7, 0x8009, 8, 3, 0x8007, 6, 0x8008, 7, 0x8009, 8,
    2, 0x8008, 7, 0x8009, 8, 1, 0x8009, 8, 4, 0x8000,
    1, 0x8001, 2, 0x8002, 3, 0x8003, 4, 609, 612, 1,
    0x0004, 1, 2, 0x8002, 2, 0x8003, 2, 4, 0x8000, 1,
    0x8002, 2, 0x8003, 3, 0x8004, 4, 629, 632, 635, 1,
    0x0004, 1, 1, 0x0004, 2, 1, 0x0004, 3, 1, 0x0012,
    645, 648, 651, 656, 659, 1, 0x8000, 1, 1, 0x8001,
    2, 2, 0x8002, 3, 0x8003, 4, 1, 0x8003, 4, 1,
    0x8004, 5, 667, 670, 673, 676, 681, 1, 0x0004, 1,
    1, 0x8001, 2, 1, 0x0004, 3, 2, 0x0010, 5, 0x800a,
    4, 1, 0x0010, 5, 2, 0x0004, 1, 0x0010, 2, 692,
    699, 704, 3, 0x0010, 3, 0x8000, 1, 0x8001, 2, 2,
    0x0010, 3, 0x8001, 2, 1, 0x0010, 3, 710, 717, 722,
    3, 0x0004, 1, 0x0005, 2, 0x0010, 3, 2, 0x0005, 2,
    0x0010, 3, 1, 0x0010, 3, 728, 731, 734, 1, 0x0004,
    1, 1, 0x0004, 2, 1, 0x0010, 3, 747, 768, 787,
    804, 819, 832, 843, 852, 859, 864, 10, 0x8000, 1,
    0x8001, 2, 0x8002, 3, 0x8003, 4, 0x8004, 5, 0x8006, 6,
    0x8007, 7, 0x8008, 8, 0x8009, 9, 0x800a, 10, 9, 0x8001,
    2, 0x8002, 3, 0x8003, 4, 0x8004, 5, 0x8006, 6, 0x8007,
    7, 0x8008, 8, 0x8009, 9, 0x800a, 10, 8, 0x8002, 3,
    0x8003, 4, 0x8004, 5, 0x8006, 6, 0x8007, 7, 0x8008, 8,
    0x8009, 9, 0x800a, 10, 7, 0x8003, 4, 0x8004, 5, 0x8006,
    6, 0x8007, 7, 0x8008, 8, 0x8009, 9, 0x800a, 10, 6,
    0x8004, 5, 0x8006, 6, 0x8007, 7, 0x8008, 8, 0x8009, 9,
    0x800a, 10, 5, 0x8006, 6, 0x8007, 7, 0x8008, 8, 0x8009,
    9, 0x800a, 10, 4, 0x8007, 7, 0x8008, 8, 0x8009, 9,
    0x800a, 10, 3, 0x8008, 8, 0x8009, 9, 0x800a, 10, 2,
    0x8009, 9, 0x800a, 10, 1, 0x800a, 10, 872, 883, 892,
    899, 904, 5, 0x8001, 1, 0x8002, 2, 0x8003, 3, 0x8004,
    4, 0x8005, 5, 4, 0x8002, 2, 0x8003, 3, 0x8004, 4,
    0x8005, 5, 3, 0x8003, 3, 0x8004, 4, 0x8005, 5, 2,
    0x8004, 4, 0x8005, 5, 1, 0x8005, 5, 912, 915, 924,
    931, 936, 1, 0x8000, 1, 4, 0x8001, 2, 0x8002, 3,
    0x8004, 4, 0x8005, 5, 3, 0x8002, 3, 0x8004, 4, 0x8005,
    5, 2, 0x8004, 4, 0x8005, 5, 1, 0x8005, 5, 941,
    946, 2, 0x0010, 2, 0x8000, 1, 1, 0x0010, 2, 952,
    955, 960, 1, 0x0004, 1, 2, 0x0004, 2, 0x0010, 3,
    1, 0x0010, 3, 966, 969, 974, 1, 0x0004, 1, 2,
    0x0005, 2, 0x0010, 3, 1, 0x0010, 3, 979, 982, 1,
    0x000a, 1, 1, 0x0010, 2, 2, 0x000a, 1, 0x0010, 2,
    992, 997, 2, 0x000a, 1, 0x0010, 2, 1, 0x0010, 2,
    1003, 1012, 1019, 4, 0x8001, 1, 0x8002, 2, 0x8003, 2,
    0x8004, 3, 3, 0x8002, 2, 0x8003, 2, 0x8004, 3, 1,
    0x8004, 3, 1025, 1028, 1033, 1, 0x000a, 1, 2, 0x0004,
    2, 0x0010, 3, 1, 0x0010, 3, 1039, 1046, 1051, 3,
    0x0002, 1, 0x0010, 2, 0x8000, 3, 2, 0x0010, 2, 0x8000,
    3, 1, 0x8000, 3, 1056, 1061, 2, 0x000a, 2, 0x0010,
    1, 1, 0x000a, 2, 1066, 1071, 2, 0x0010, 1, 0x8000,
    2, 1, 0x8000, 2, 1077, 1084, 1089, 3, 0x0010, 1,
    0x8000, 2, 0x8001, 3, 2, 0x8000, 2, 0x8001, 3, 1,
    0x8001, 3, 1094, 1099, 2, 0x0005, 2, 0x0010, 1, 1,
    0x0005, 2, 1107, 1112, 1115, 1118, 1123, 2, 0x8000, 1,
    0x8001, 2, 1, 0x8001, 2, 1, 0x8002, 3, 2, 0x8003,
    4, 0x8004, 5, 1, 0x8004, 5, 1129, 1134, 1137, 2,
    0x8000, 1, 0x8001, 2, 1, 0x8001, 2, 1, 0x8002, 3,
    6, 0x8000, 1, 0x8001, 2, 0x8002, 3, 0x8003, 4, 0x8004,
    5, 0x8005, 6, 1154, 1, 0x000a, 1, 1158, 4, 0x8000,
    1, 0x8001, 1, 0x8002, 1, 0x8003, 1, 1, 0x0007, 1,
    0x8000, 1, 0x8001, 1, 0x8002, 3, 0x8000, 1, 0x8001, 2,
    0x8002, 3, 1, 0x0008, 1188, 1201, 1212, 1221, 6, 0x0002,
    2, 0x0006, 1, 0x0007, 3, 0x8000, 4, 0x8001, 4, 0x8002,
    4, 5, 0x0002, 2, 0x0007, 3, 0x8000, 4, 0x8001, 4,
    0x8002, 4, 4, 0x0007, 3, 0x8000, 4, 0x8001, 4, 0x8002,
    4, 3, 0x8000, 4, 0x8001, 4, 0x8002, 4, 2, 0x400b,
    0x0008, 1233, 1238, 2, 0x400b, 1, 0x400c, 2, 1, 0x400c,
    2, 1, 0x4008, 1246, 1249, 1254, 1, 0x4008, 1, 2,
    0x400b, 2, 0x400c, 3, 1, 0x400c, 3, 1, 0x4009, 1262,
    1265, 1270, 1, 0x4009, 1, 2, 0x400b, 2, 0x400c, 3,
    1, 0x400c, 3, 1277, 1280, 1283, 1288, 1, 0x4008, 1,
    1, 0x4009, 2, 2, 0x400b, 3, 0x400c, 4, 1, 0x400c,
    4, 1, 0x400a, 2, 0x400a, 1, 0x400b, 2, 1300, 1303,
    1, 0x4009, 1, 2, 0x400a, 2, 0x400b, 2, 1, 0x4001,
    1, 0x4002, 1, 0x4004, 1, 0x4005, 1, 0x4007, 1322, 1325,
    1332, 1337, 1, 0x0002, 1, 3, 0x0002, 3, 0x0006, 3,
    0x8000, 2, 2, 0x0002, 3, 0x0006, 3, 0, 1340, 1345,
    2, 0x0002, 1, 0x0006, 1, 0, 1348, 1351, 1, 0x0002,
    1, 1, 0x0010, 2, 1357, 1360, 1365, 1, 0x0002, 1,
    2, 0x0002, 2, 0x0006, 2, 0, 2, 0x0002, 1, 0x0005,
    2, 1, 0x8003, 1375, 1380, 2, 0x0002, 1, 0x0005, 1,
    4, 0x8000, 2, 0x8001, 2, 0x8002, 2, 0x8003, 2, 1,
    0x8004, 1, 0x8007, 5, 0x8001, 1, 0x8002, 2, 0x8003, 3,
    0x8004, 4, 0x8007, 5, 1, 0x400c, 1408, 1411, 1, 0x0006,
    1, 0, 1414, 1419, 2, 0x8000, 1, 0x8001, 1, 1,
    0x0004, 2, 1, 0x8005, 4, 0x8000, 1, 0x8001, 2, 0x8004,
    3, 0x8005, 4, 3, 0x8002, 1, 0x8004, 2, 0x8005, 3,
    1, 0x0003, 1445, 1448, 1451, 1, 0x000a, 1, 1, 0x0004,
    2, 1, 0x0010, 3, 1, 0x800a, 1, 0x8006, 1462, 1471,
    1478, 1483, 4, 0x8004, 2, 0x8005, 1, 0x8006, 3, 0x8007,
    4, 3, 0x8004, 2, 0x8006, 3, 0x8007, 4, 2, 0x8006,
    3, 0x8007, 4, 1, 0x8007, 4, 2, 0x8002, 1, 0x8003,
    2, 1, 0x8008, 1, 0x8009, 1499, 1502, 1505, 1508, 1,
    0x0002, 1, 1, 0x0004, 2, 1, 0x000a, 3, 1, 0x0010,
    4, 1514, 1523, 1528, 4, 0x0002, 2, 0x0004, 3, 0x8002,
    1, 0x8003, 1, 2, 0x0002, 2, 0x0004, 3, 1, 0x0004,
    3, 1533, 1536, 1, 0x0010, 1, 1, 0x0010, 2, 1546,
    1563, 1576, 1587, 1596, 1603, 1608, 8, 0x8002, 1, 0x8003,
    1, 0x8004, 2, 0x8005, 3, 0x8006, 5, 0x8007, 6, 0x8008,
    4, 0x8009, 7, 6, 0x8004, 2, 0x8005, 3, 0x8006, 5,
    0x8007, 6, 0x8008, 4, 0x8009, 7, 5, 0x8005, 3, 0x8006,
    5, 0x8007, 6, 0x8008, 4, 0x8009, 7, 4, 0x8006, 5,
    0x8007, 6, 0x8008, 4, 0x8009, 7, 3, 0x8006, 5, 0x8007,
    6, 0x8009, 7, 2, 0x8007, 6, 0x8009, 7, 1, 0x8009,
    7, 1613, 1620, 3, 0x8002, 1, 0x8003, 1, 0x8004, 2,
    1, 0x8004, 2, 2, 0x8001, 2, 0x8002, 1, 1632, 1641,
    1648, 1653, 4, 0x8000, 1, 0x8001, 2, 0x8002, 3, 0x8003,
    4, 3, 0x8001, 2, 0x8002, 3, 0x8003, 4, 2, 0x8002,
    3, 0x8003, 4, 1, 0x8003, 4, 1663, 1680, 1695, 1708,
    1717, 1724, 1729, 8, 0x0002, 5, 0x0004, 1, 0x0010, 4,
    0x8001, 3, 0x8002, 3, 0x8004, 2, 0x8005, 6, 0x8006, 7,
    7, 0x0002, 5, 0x0010, 4, 0x8001, 3, 0x8002, 3, 0x8004,
    2, 0x8005, 6, 0x8006, 7, 6, 0x0002, 5, 0x0010, 4,
    0x8001, 3, 0x8002, 3, 0x8005, 6, 0x8006, 7, 4, 0x0002,
    5, 0x0010, 4, 0x8005, 6, 0x8006, 7, 3, 0x0002, 5,
    0x8005, 6, 0x8006, 7, 2, 0x8005, 6, 0x8006, 7, 1,
    0x8006, 7, 1740, 1743, 1758, 1771, 1782, 1791, 1798, 1803,
    1, 0x0004, 1, 7, 0x000a, 2, 0x8000, 3, 0x8001, 4,
    0x8002, 5, 0x8003, 6, 0x8004, 7, 0x8005, 8, 6, 0x8000,
    3, 0x8001, 4, 0x8002, 5, 0x8003, 6, 0x8004, 7, 0x8005,
    8, 5, 0x8001, 4, 0x8002, 5, 0x8003, 6, 0x8004, 7,
    0x8005, 8, 4, 0x8002, 5, 0x8003, 6, 0x8004, 7, 0x8005,
    8, 3, 0x8003, 6, 0x8004, 7, 0x8005, 8, 2, 0x8004,
    7, 0x8005, 8, 1, 0x8005, 8, 1809, 1812, 1815, 1,
    0x0002, 1, 1, 0x0002, 2, 1, 0x0010, 3, 1819, 1,
    0x0004, 1, 1825, 1828, 1833, 1, 0x0003, 1, 2, 0x0003,
    2, 0x0010, 3, 1, 0x0010, 3, 1843, 1850, 1853, 1864,
    1873, 1880, 1885, 3, 0x8002, 1, 0x8003, 1, 0x8004, 2,
    1, 0x8004, 2, 5, 0x8005, 3, 0x8006, 5, 0x8007, 6,
    0x8008, 4, 0x8009, 7, 4, 0x8006, 5, 0x8007, 6, 0x8008,
    4, 0x8009, 7, 3, 0x8006, 5, 0x8007, 6, 0x8009, 7,
    2, 0x8007, 6, 0x8009, 7, 1, 0x8009, 7, 1891, 1894,
    1897, 1, 0x0004, 1, 1, 0x0010, 2, 1, 0x8000, 3,
    1903, 1910, 1913, 3, 0x8002, 1, 0x8003, 1, 0x8004, 2,
    1, 0x8004, 2, 1, 0x0010, 3, 1919, 1922, 1925, 1,
    0x0004, 1, 1, 0x0010, 2, 1, 0x0010, 3, 1933, 1936,
    1939, 1942, 1947, 1, 0x0002, 1, 1, 0x0004, 2, 1,
    0x000a, 3, 2, 0x0010, 4, 0x8000, 5, 1, 0x8000, 5,
    1954, 1963, 1968, 1971, 4, 0x0002, 2, 0x0004, 3, 0x8002,
    1, 0x8003, 1, 2, 0x0002, 2, 0x0004, 3, 1, 0x0004,
    3, 1, 0x0010, 4, 1977, 1980, 1985, 1, 0x0010, 1,
    2, 0x0010, 2, 0x8000, 3, 1, 0x8000, 3, 1993, 1996,
    1999, 2008, 2013, 1, 0x0004, 1, 1, 0x8004, 2, 4,
    0x0010, 4, 0x8001, 3, 0x8002, 3, 0x8005, 5, 2, 0x0010,
    4, 0x8005, 5, 1, 0x8005, 5, 5, 0x8000, 1, 0x8001,
    2, 0x8002, 3, 0x8003, 4, 0x8004, 5, 4, 0x000a, 3,
    0x8000, 1, 0x8001, 2, 0x8002, 4, 2039, 2046, 2051, 3,
    0x000a, 1, 0x0010, 2, 0x8001, 3, 2, 0x0010, 2, 0x8001,
    3, 1, 0x8001, 3
};

#if !defined(OSS_SPARTAN_AWARE) || ((OSS_SPARTAN_AWARE + 0) <= 5)
typedef struct OSetTableEntry {
    void *a;
    unsigned short b;
    void *c;
    unsigned short d;
} OSetTableEntry;
#endif /* OSS_SPARTAN_AWARE  <= 5 */

static struct OSetTableEntry const _objectsettable[] = {
#if defined(OSS_SPARTAN_AWARE) && ((OSS_SPARTAN_AWARE + 0) > 12)
    {(void *)MAP2_ExtensionSet, 292, NULL, 0, NULL, -1, -1}
#else
    {(void *)MAP2_ExtensionSet, 292, NULL, 0}
#endif /* OSS_SPARTAN_AWARE  > 12 */
};


#ifdef OSS_SPARTAN_AWARE
#if ((OSS_SPARTAN_AWARE + 0) >= 3)
static void _oss_post_init(struct ossGlobal *world) {
    static const unsigned char _oss_typeinfo[] = {
        0x00, 0x91, 0x33, 0x9d, 0xc5, 0xbe, 0x3f, 0xf7, 0xe3, 0x86,
        0xe6, 0xef, 0xe3, 0xbb, 0xe6, 0x5c, 0x4a, 0xdc, 0x78, 0x0d,
        0x52, 0x10, 0xa6, 0x31, 0x04, 0xe3, 0x68, 0x8a, 0x68, 0x05,
        0x26, 0x35, 0x14, 0x47, 0xbb, 0x43, 0x16, 0x01, 0xdf, 0x3b,
        0xcc, 0xab, 0xfa, 0x09, 0xf0, 0x71, 0x9d, 0xd1, 0xc2, 0xe7,
        0xf7, 0xc1, 0x1e, 0xdd, 0x4a, 0x86, 0x4a, 0x82, 0x29, 0x15,
        0x90, 0x86, 0xff, 0xd3, 0x38, 0x38, 0x81, 0xb2, 0x8d, 0x74,
        0x23, 0x5a, 0x6d, 0xfe, 0x8d, 0x0b, 0x75, 0xf9, 0x9e, 0x11,
        0x46, 0x45, 0xa8, 0x86, 0x16, 0xaa, 0x51, 0x9e, 0xd7, 0xbe,
        0xa7, 0xb3, 0x3e, 0xdf, 0xeb, 0xb6, 0x5e, 0xa4, 0xd7, 0x5a,
        0x09, 0xfa, 0xd6, 0x96, 0x62, 0x72, 0x7d, 0x2b, 0x06, 0x68,
        0x3a, 0xdc, 0xef, 0x24, 0x3a, 0x8e, 0x96, 0x66, 0xa7, 0xf4,
        0x92, 0xa4, 0xbe, 0xe4, 0x8b, 0x8e, 0x15, 0x12, 0x05, 0x19,
        0x85, 0xac, 0x3a, 0x20, 0xfa, 0x1e, 0x35, 0x8b, 0x08, 0xa6,
        0x57, 0x39, 0xe3, 0x14, 0x23, 0xb0, 0xd9
    };
    ossInitRootContext(world, (unsigned char *)_oss_typeinfo);
#ifdef OSS_SPARTAN_AWARE
#if ((OSS_SPARTAN_AWARE + 0) > 12)
    ossSetExtParms(world, (void *)&extParms);
#endif /* OSS_SPARTAN_AWARE  > 12 */
#endif /* OSS_SPARTAN_AWARE */
}
#endif /* OSS_SPARTAN_AWARE >= 3 */
#endif /* OSS_SPARTAN_AWARE */

static const struct eheader _head = {_ossinit_MAP2, -1, 15, 2853, 236, 654,
    (unsigned short *)_pduarray, (struct etype *)_etypearray,
    (struct efield *)_efieldarray, (void **)_enamearray, (Etag *)_tagarray,
    NULL, NULL, NULL, 0, (void *)_objectsettable, 1};

#ifdef _OSSGETHEADER
void *DLL_ENTRY_FDEF ossGetHeader()
{
    return (void *)&_head;
}
#endif /* _OSSGETHEADER */

void *MAP2 = (void *)&_head;
#ifdef __cplusplus
}	/* extern "C" */
#endif /* __cplusplus */
