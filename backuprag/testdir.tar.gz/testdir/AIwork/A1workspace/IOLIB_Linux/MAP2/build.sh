PATH=$PATH:/usr/ccs/bin:/usr/local/ossasn1/linux-x86-64/10.5.0/bin/

cp MAP2.asn IMAP2.asn
asn1 -c++ -root -ber -noWarning -ignoreIncompleteItems  -prefix IMAP2_ /usr/local/ossasn1/linux-x86-64/10.5.0//asn1dflt.linux-amd64 TCAP.asn MAP-ExtensionDataTypes.asn MAP-ShortMessageServiceOperations.asn MAP-BS-Code.asn MAP-GR-DataTypes.asn MAP-SM-DataTypes.asn MAP-CallHandlingOperations.asn  MAP-Group-Call-Operations.asn MAP-SS-Code.asn MAP-CH-DataTypes.asn MAP-MobileServiceOperations.asn MAP-SS-DataTypes.asn MAP-CommonDataTypes.asn MAP-MS-DataTypes.asn MAP-SupplementaryServiceOperations.asn MAP-ER-DataTypes.asn MAP-OM-DataTypes.asn MAP-TS-Code.asn MAP-Errors.asn MAP-OperationAndMaintenanceOperations.asn MAP-DialogueInformation.asn IMAP2.asn  

mv IMAP2.asn OMAP2.asn
asn1 -c++ -compat v4.2octetStringDefault -compat v4.2defaults -compat v6.1.3varyingbitstring -root -ber  -noWarning -ignoreIncompleteItems  -prefix OMAP2_ /usr/local/ossasn1/linux-x86-64/10.5.0//asn1dflt.linux-amd64 TCAP.asn MAP-ExtensionDataTypes.asn MAP-ShortMessageServiceOperations.asn MAP-BS-Code.asn MAP-GR-DataTypes.asn MAP-SM-DataTypes.asn MAP-CallHandlingOperations.asn  MAP-Group-Call-Operations.asn MAP-SS-Code.asn MAP-CH-DataTypes.asn MAP-MobileServiceOperations.asn MAP-SS-DataTypes.asn MAP-CommonDataTypes.asn MAP-MS-DataTypes.asn MAP-SupplementaryServiceOperations.asn MAP-ER-DataTypes.asn MAP-OM-DataTypes.asn MAP-TS-Code.asn MAP-Errors.asn MAP-OperationAndMaintenanceOperations.asn MAP-DialogueInformation.asn OMAP2.asn  

mv *.cpp src/

mv *.h inc/

make all

rm *.o
rm OMAP2.asn
