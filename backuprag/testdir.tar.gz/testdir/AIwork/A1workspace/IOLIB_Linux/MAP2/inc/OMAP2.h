/*************************************************************/
/* Copyright (C) 2017 OSS Nokalva, Inc.  All rights reserved.*/
/*************************************************************/

/* THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC.
 * AND MAY BE USED ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC.
 * THIS FILE MAY NOT BE DISTRIBUTED.
 * THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED. */

/* Generated for: Plintron Global Technology Solutions Pvt. Ltd. - Site-based, License 75139 75139,
 * at GKS Tech Park, DLT IT SEZ, Chennai 600089, India. */
/* Abstract syntax: OMAP2 */
/* Created: Fri Oct  6 15:47:24 2017 */
/* ASN.1 compiler version: 10.5 */
/* Code generated for runtime version 10.5 or later */
/* Compiler operating system: Linux with 64-bit support */
/* Compiler machine type: AMD64 */
/* Target operating system: Linux with 64-bit support */
/* Target machine type: AMD64 */
/* C compiler options required: -m64 */
/* ASN.1 compiler options and file names specified:
 * -prefix OMAP2_ -c++ -nowarningmessages -ber -root -ignoreIncompleteItems
 * -compat v4.2defaults -compat v4.2octetstringdefault
 * -compat v6.1.3varyingbitstring
 * /usr/local/ossasn1/linux-x86-64/10.5.0//asn1dflt.linux-amd64 TCAP.asn
 * MAP-ExtensionDataTypes.asn MAP-ShortMessageServiceOperations.asn
 * MAP-BS-Code.asn MAP-GR-DataTypes.asn MAP-SM-DataTypes.asn
 * MAP-CallHandlingOperations.asn MAP-Group-Call-Operations.asn
 * MAP-SS-Code.asn MAP-CH-DataTypes.asn MAP-MobileServiceOperations.asn
 * MAP-SS-DataTypes.asn MAP-CommonDataTypes.asn MAP-MS-DataTypes.asn
 * MAP-SupplementaryServiceOperations.asn MAP-ER-DataTypes.asn
 * MAP-OM-DataTypes.asn MAP-TS-Code.asn MAP-Errors.asn
 * MAP-OperationAndMaintenanceOperations.asn MAP-DialogueInformation.asn
 * OMAP2.asn
 */

#ifndef OSS_OMAP2
#define OSS_OMAP2

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include "ossasn1.h"

#define          OMAP2_MessageType_PDU 1
#define          OMAP2_SendRoutingInfoForSM_PDU 2
#define          OMAP2_MO_ForwardSM_PDU 3
#define          OMAP2_MT_ForwardSM_PDU 4
#define          OMAP2_ReportSM_DeliveryStatus_PDU 5
#define          OMAP2_AlertServiceCentre_PDU 6
#define          OMAP2_InformServiceCentre_PDU 7
#define          OMAP2_ReadyForSM_PDU 8
#define          OMAP2_PrepareGroupCallArg_PDU 9
#define          OMAP2_PrepareGroupCallRes_PDU 10
#define          OMAP2_SendGroupCallEndSignalArg_PDU 11
#define          OMAP2_SendGroupCallEndSignalRes_PDU 12
#define          OMAP2_ForwardGroupCallSignallingArg_PDU 13
#define          OMAP2_ProcessGroupCallSignallingArg_PDU 14
#define          OMAP2_RoutingInfoForSM_Arg_PDU 15
#define          OMAP2_RoutingInfoForSM_Res_PDU 16
#define          OMAP2_Additional_Number_PDU 17
#define          OMAP2_MO_ForwardSM_Arg_PDU 18
#define          OMAP2_MO_ForwardSM_Res_PDU 19
#define          OMAP2_MT_ForwardSM_Arg_PDU 20
#define          OMAP2_MT_ForwardSM_Res_PDU 21
#define          OMAP2_ReportSM_DeliveryStatusArg_PDU 22
#define          OMAP2_ReportSM_DeliveryStatusRes_PDU 23
#define          OMAP2_AlertServiceCentreArg_PDU 24
#define          OMAP2_InformServiceCentreArg_PDU 25
#define          OMAP2_ReadyForSM_Arg_PDU 26
#define          OMAP2_ReadyForSM_Res_PDU 27
#define          OMAP2_SendRoutingInfo_PDU 28
#define          OMAP2_ProvideRoamingNumber_PDU 29
#define          OMAP2_ResumeCallHandling_PDU 30
#define          OMAP2_ProvideSIWFSNumber_PDU 31
#define          OMAP2_SIWFSSignallingModify_PDU 32
#define          OMAP2_PrepareGroupCall_PDU 33
#define          OMAP2_SendGroupCallEndSignal_PDU 34
#define          OMAP2_ProcessGroupCallSignalling_PDU 35
#define          OMAP2_ForwardGroupCallSignalling_PDU 36
#define          OMAP2_SendRoutingInfoArg_PDU 37
#define          OMAP2_SuppressionOfAnnouncement_PDU 38
#define          OMAP2_InterrogationType_PDU 39
#define          OMAP2_OR_Phase_PDU 40
#define          OMAP2_ForwardingReason_PDU 41
#define          OMAP2_SupportedCCBS_Phase_PDU 42
#define          OMAP2_SendRoutingInfoRes_PDU 43
#define          OMAP2_CCBS_Indicators_PDU 44
#define          OMAP2_ProvideRoamingNumberArg_PDU 45
#define          OMAP2_ProvideRoamingNumberRes_PDU 46
#define          OMAP2_ResumeCallHandlingRes_PDU 47
#define          OMAP2_ProvideSIWFSNumberArg_PDU 48
#define          OMAP2_ProvideSIWFSNumberRes_PDU 49
#define          OMAP2_SIWFSSignallingModifyArg_PDU 50
#define          OMAP2_SIWFSSignallingModifyRes_PDU 51
#define          OMAP2_StatusReportArg_PDU 52
#define          OMAP2_StatusReportRes_PDU 53
#define          OMAP2_UpdateLocation_PDU 54
#define          OMAP2_CancelLocation_PDU 55
#define          OMAP2_PurgeMS_PDU 56
#define          OMAP2_SendIdentification_PDU 57
#define          OMAP2_PrepareHandover_PDU 58
#define          OMAP2_SendEndSignal_PDU 59
#define          OMAP2_ProcessAccessSignalling_PDU 60
#define          OMAP2_ForwardAccessSignalling_PDU 61
#define          OMAP2_PrepareSubsequentHandover_PDU 62
#define          OMAP2_SendAuthenticationInfo_PDU 63
#define          OMAP2_CheckIMEI_PDU 64
#define          OMAP2_InsertSubscriberData_PDU 65
#define          OMAP2_DeleteSubscriberData_PDU 66
#define          OMAP2_Reset_PDU 67
#define          OMAP2_RestoreData_PDU 68
#define          OMAP2_RegisterPasswordArg_PDU 69
#define          OMAP2_RegisterSSArg_PDU 70
#define          OMAP2_DeactivateSSRes_PDU 71
#define          OMAP2_ActivateSSRes_PDU 72
#define          OMAP2_EraseSSRes_PDU 73
#define          OMAP2_RegisterSSRes_PDU 74
#define          OMAP2_SS_ForBS_Code_PDU 75
#define          OMAP2_InterrogateSSArg_PDU 76
#define          OMAP2_DeactivateSSArg_PDU 77
#define          OMAP2_ActivateSSArg_PDU 78
#define          OMAP2_EraseSSArg_PDU 79
#define          OMAP2_InterrogateSSRes_PDU 80
#define          OMAP2_USSD_Arg_PDU 81
#define          OMAP2_UnstructuredSS_NotifyArg_PDU 82
#define          OMAP2_UnstructuredSS_RequestArg_PDU 83
#define          OMAP2_ProcessUnstructuredSS_RequestArg_PDU 84
#define          OMAP2_USSD_Res_PDU 85
#define          OMAP2_UnstructuredSS_RequestRes_PDU 86
#define          OMAP2_ProcessUnstructuredSS_RequestRes_PDU 87
#define          OMAP2_Password_PDU 88
#define          OMAP2_GetPasswordRes_PDU 89
#define          OMAP2_RegisterPasswordRes_PDU 90
#define          OMAP2_GuidanceInfo_PDU 91
#define          OMAP2_GetPasswordArg_PDU 92
#define          OMAP2_SS_EventSpecification_PDU 93
#define          OMAP2_CCBS_Data_PDU 94
#define          OMAP2_SubscriberId_PDU 95
#define          OMAP2_IMEI_PDU 96
#define          OMAP2_NAEA_PreferredCI_PDU 97
#define          OMAP2_UpdateLocationArg_PDU 98
#define          OMAP2_UpdateLocationRes_PDU 99
#define          OMAP2_CancelLocationArg_PDU 100
#define          OMAP2_Indentity_PDU 101
#define          OMAP2_CancellationType_PDU 102
#define          OMAP2_CancelLocationRes_PDU 103
#define          OMAP2_PurgeMS_Arg_PDU 104
#define          OMAP2_PurgeMS_Res_PDU 105
#define          OMAP2_SendIdentificationRes_PDU 106
#define          OMAP2_PrepareHO_Arg_PDU 107
#define          OMAP2_PrepareHO_Res_PDU 108
#define          OMAP2_PrepareSubsequentHO_Arg_PDU 109
#define          OMAP2_SendAuthenticationInfoArg_PDU 110
#define          OMAP2_SendAuthenticationInfoRes_PDU 111
#define          OMAP2_EquipmentStatus_PDU 112
#define          OMAP2_InsertSubscriberDataArg_PDU 113
#define          OMAP2_QoS_Subscribed_PDU 114
#define          OMAP2_Ext_SS_InfoList_PDU 115
#define          OMAP2_InsertSubscriberDataRes_PDU 116
#define          OMAP2_DeleteSubscriberDataArg_PDU 117
#define          OMAP2_DeleteSubscriberDataRes_PDU 118
#define          OMAP2_CallTypeCriteria_PDU 119
#define          OMAP2_DefaultCallHandling_PDU 120
#define          OMAP2_ResetArg_PDU 121
#define          OMAP2_RestoreDataArg_PDU 122
#define          OMAP2_RestoreDataRes_PDU 123
#define          OMAP2_VBSDataList_PDU 124
#define          OMAP2_VGCSDataList_PDU 125
#define          OMAP2_RegisterSS_PDU 126
#define          OMAP2_EraseSS_PDU 127
#define          OMAP2_ActivateSS_PDU 128
#define          OMAP2_DeactivateSS_PDU 129
#define          OMAP2_InterrogateSS_PDU 130
#define          OMAP2_ProcessUnstructuredSS_Request_PDU 131
#define          OMAP2_UnstructuredSS_Request_PDU 132
#define          OMAP2_UnstructuredSS_Notify_PDU 133
#define          OMAP2_RegisterPassword_PDU 134
#define          OMAP2_GetPassword_PDU 135
#define          OMAP2_RoamingNotAllowedParam_PDU 136
#define          OMAP2_CallBarredParam_PDU 137
#define          OMAP2_CUG_RejectParam_PDU 138
#define          OMAP2_SS_IncompatibilityCause_PDU 139
#define          OMAP2_PW_RegistrationFailureCause_PDU 140
#define          OMAP2_SM_DeliveryFailureCause_PDU 141
#define          OMAP2_AbsentSubscriberSM_Param_PDU 142
#define          OMAP2_SystemFailureParam_PDU 143
#define          OMAP2_DataMissingParam_PDU 144
#define          OMAP2_UnexpectedDataParam_PDU 145
#define          OMAP2_FacilityNotSupParam_PDU 146
#define          OMAP2_OR_NotAllowedParam_PDU 147
#define          OMAP2_UnknownSubscriberParam_PDU 148
#define          OMAP2_NumberChangedParam_PDU 149
#define          OMAP2_UnidentifiedSubParam_PDU 150
#define          OMAP2_IllegalSubscriberParam_PDU 151
#define          OMAP2_IllegalEquipmentParam_PDU 152
#define          OMAP2_BearerServNotProvParam_PDU 153
#define          OMAP2_TeleservNotProvParam_PDU 154
#define          OMAP2_TracingBufferFullParam_PDU 155
#define          OMAP2_NoRoamingNbParam_PDU 156
#define          OMAP2_AbsentSubscriberParam_PDU 157
#define          OMAP2_BusySubscriberParam_PDU 158
#define          OMAP2_NoSubscriberReplyParam_PDU 159
#define          OMAP2_ForwardingViolationParam_PDU 160
#define          OMAP2_ForwardingFailedParam_PDU 161
#define          OMAP2_ATI_NotAllowedParam_PDU 162
#define          OMAP2_SubBusyForMT_SMS_Param_PDU 163
#define          OMAP2_MessageWaitListFullParam_PDU 164
#define          OMAP2_ResourceLimitationParam_PDU 165
#define          OMAP2_NoGroupCallNbParam_PDU 166
#define          OMAP2_IncompatibleTerminalParam_PDU 167
#define          OMAP2_ShortTermDenialParam_PDU 168
#define          OMAP2_LongTermDenialParam_PDU 169
#define          OMAP2_ActivateTraceModeArg_PDU 170
#define          OMAP2_ActivateTraceModeRes_PDU 171
#define          OMAP2_DeactivateTraceModeArg_PDU 172
#define          OMAP2_DeactivateTraceModeRes_PDU 173
#define          OMAP2_SendIMSIArg_PDU 174
#define          OMAP2_SendIMSIRes_PDU 175
#define          OMAP2_SystemFailure_PDU 176
#define          OMAP2_DataMissing_PDU 177
#define          OMAP2_UnexpectedDataValue_PDU 178
#define          OMAP2_FacilityNotSupported_PDU 179
#define          OMAP2_IncompatibleTerminal_PDU 180
#define          OMAP2_ResourceLimitation_PDU 181
#define          OMAP2_UnknownSubscriber_PDU 182
#define          OMAP2_NumberChanged_PDU 183
#define          OMAP2_UnknownMSC_PDU 184
#define          OMAP2_UnidentifiedSubscriber_PDU 185
#define          OMAP2_UnknownEquipment_PDU 186
#define          OMAP2_RoamingNotAllowed_PDU 187
#define          OMAP2_IllegalSubscriber_PDU 188
#define          OMAP2_IllegalEquipment_PDU 189
#define          OMAP2_BearerServiceNotProvisioned_PDU 190
#define          OMAP2_TeleserviceNotProvisioned_PDU 191
#define          OMAP2_NoHandoverNumberAvailable_PDU 192
#define          OMAP2_SubsequentHandoverFailure_PDU 193
#define          OMAP2_TracingBufferFull_PDU 194
#define          OMAP2_NoRoamingNumberAvailable_PDU 195
#define          OMAP2_AbsentSubscriber_PDU 196
#define          OMAP2_BusySubscriber_PDU 197
#define          OMAP2_NoSubscriberReply_PDU 198
#define          OMAP2_CallBarred_PDU 199
#define          OMAP2_ForwardingViolation_PDU 200
#define          OMAP2_ForwardingFailed_PDU 201
#define          OMAP2_CUG_Reject_PDU 202
#define          OMAP2_OR_NotAllowed_PDU 203
#define          OMAP2_ATI_NotAllowed_PDU 204
#define          OMAP2_IllegalSS_Operation_PDU 205
#define          OMAP2_SS_ErrorStatus_PDU 206
#define          OMAP2_SS_NotAvailable_PDU 207
#define          OMAP2_SS_SubscriptionViolation_PDU 208
#define          OMAP2_SS_Incompatibility_PDU 209
#define          OMAP2_UnknownAlphabet_PDU 210
#define          OMAP2_USSD_Busy_PDU 211
#define          OMAP2_PW_RegistrationFailure_PDU 212
#define          OMAP2_NegativePW_Check_PDU 213
#define          OMAP2_NumberOfPW_AttemptsViolation_PDU 214
#define          OMAP2_ShortTermDenial_PDU 215
#define          OMAP2_LongTermDenial_PDU 216
#define          OMAP2_SubscriberBusyForMT_SMS_PDU 217
#define          OMAP2_SM_DeliveryFailure_PDU 218
#define          OMAP2_MessageWaitingListFull_PDU 219
#define          OMAP2_AbsentSubscriberSM_PDU 220
#define          OMAP2_NoGroupCallNumberAvailable_PDU 221
#define          OMAP2_ActivateTraceMode_PDU 222
#define          OMAP2_DeactivateTraceMode_PDU 223
#define          OMAP2_SendIMSI_PDU 224
#define          OMAP2_DialoguePDU_PDU 225
#define          OMAP2_OpenInfo_PDU 226
#define          OMAP2_AcceptInfo_PDU 227
#define          OMAP2_CloseInfo_PDU 228
#define          OMAP2_RefuseInfo_PDU 229
#define          OMAP2_Reason_PDU 230
#define          OMAP2_UserAbortInfo_PDU 231
#define          OMAP2_UserAbortChoice_PDU 232
#define          OMAP2_ResourceUnavailableReason_PDU 233
#define          OMAP2_ProcedureCancellationReason_PDU 234
#define          OMAP2_ProviderAbortInfo_PDU 235
#define          OMAP2_ProviderAbortReason_PDU 236

typedef struct OMAP2__ObjectID_ {
    struct OMAP2__ObjectID_ *next;
    unsigned short  value;
} *OMAP2__ObjectID;

typedef struct OMAP2__Any {
    unsigned long   length;
    unsigned char   *value;
} OMAP2__Any;

typedef struct OMAP2__choice1 {
    unsigned short  choice;
#       define      OMAP2_single_ASN1_type_chosen 1
#       define      OMAP2_octet_aligned_chosen 2
#       define      OMAP2_arbitrary_chosen 3
    union _union {
        OpenType        single_ASN1_type;  /* to choose, set choice to
                                            * OMAP2_single_ASN1_type_chosen */
        struct OMAP2_External_octet_aligned {
            unsigned int    length;
            unsigned char   *value;
        } octet_aligned;  /* to choose, set choice to
                           * OMAP2_octet_aligned_chosen */
        struct OMAP2_External_arbitrary {
            unsigned int    length;  /* number of significant bits */
            unsigned char   *value;
        } arbitrary;  /* to choose, set choice to OMAP2_arbitrary_chosen */
    } u;
} OMAP2__choice1;

typedef struct OMAP2__External {
    unsigned char   bit_mask;
#       define      OMAP2_direct_reference_present 0x80
#       define      OMAP2_indirect_reference_present 0x40
    struct OMAP2__ObjectID_ *direct_reference;  /* optional; set in bit_mask
                                            * OMAP2_direct_reference_present if
                                            * present */
    int             indirect_reference;  /* optional; set in bit_mask
                                          * OMAP2_indirect_reference_present if
                                          * present */
    char            *data_value_descriptor;  /* NULL for not present */
    OMAP2__choice1  encoding;
} OMAP2__External;

// NOTE � When the Abort Message is generated by the Transaction sublayer, a p-Abort Cause must be
// present.The u-abortCause may be generated by the component sublayer in which case it is an ABRT
// APDU, or by the TC-User in which case it could be either an ABRT APDU or data in some user-defined
// abstract syntax.
typedef OMAP2__External OMAP2_DialoguePortion;

typedef struct OMAP2_Unidirectional {
    unsigned char   bit_mask;
#       define      OMAP2_Unidirectional_dialoguePortion_present 0x80
    OMAP2_DialoguePortion dialoguePortion;  /* optional; set in bit_mask
                              * OMAP2_Unidirectional_dialoguePortion_present if
                              * present */
    struct OMAP2_ComponentPortion_ *components;
} OMAP2_Unidirectional;

// The dialogue portion carries the dialogue control PDUs as value of the external data type.
// The direct reference should be set to { ccitt recommendation q 773 as (1) dialogue-as (1) version (1) }
// if structured dialogue is used and to { ccitt recommendation q 773 as (1) unidialogue-as (2) version (1) }
// if unstructured dialogue is used or any user defined abstract syntax name when only user information
// is carried (e.g. when user information is sent in a 1988 Abort message).
typedef struct OMAP2_OrigTransactionID {
    unsigned short  length;
    unsigned char   value[4];
} OMAP2_OrigTransactionID;

typedef struct OMAP2_Begin {
    unsigned char   bit_mask;
#       define      OMAP2_Begin_dialoguePortion_present 0x80
#       define      OMAP2_Begin_components_present 0x40
    OMAP2_OrigTransactionID otid;
    OMAP2_DialoguePortion dialoguePortion;  /* optional; set in bit_mask
                                       * OMAP2_Begin_dialoguePortion_present if
                                       * present */
    struct OMAP2_ComponentPortion_ *components;  /* optional; set in bit_mask
                                            * OMAP2_Begin_components_present if
                                            * present */
} OMAP2_Begin;

typedef struct OMAP2_DestTransactionID {
    unsigned short  length;
    unsigned char   value[4];
} OMAP2_DestTransactionID;

typedef struct OMAP2_End {
    unsigned char   bit_mask;
#       define      OMAP2_End_dialoguePortion_present 0x80
#       define      OMAP2_End_components_present 0x40
    OMAP2_DestTransactionID dtid;
    OMAP2_DialoguePortion dialoguePortion;  /* optional; set in bit_mask
                                             * OMAP2_End_dialoguePortion_present
                                             * if present */
    struct OMAP2_ComponentPortion_ *components;  /* optional; set in bit_mask
                                                  * OMAP2_End_components_present
                                                  * if present */
} OMAP2_End;

typedef struct OMAP2_Continue {
    unsigned char   bit_mask;
#       define      OMAP2_Continue_dialoguePortion_present 0x80
#       define      OMAP2_Continue_components_present 0x40
    OMAP2_OrigTransactionID otid;
    OMAP2_DestTransactionID dtid;
    OMAP2_DialoguePortion dialoguePortion;  /* optional; set in bit_mask
                                    * OMAP2_Continue_dialoguePortion_present if
                                    * present */
    struct OMAP2_ComponentPortion_ *components;  /* optional; set in bit_mask
                                         * OMAP2_Continue_components_present if
                                         * present */
} OMAP2_Continue;

typedef int             OMAP2_P_AbortCause;
#define                     OMAP2_unrecognizedMessageType 0
#define                     OMAP2_unrecognizedTransactionID 1
#define                     OMAP2_badlyFormattedTransactionPortion 2
#define                     OMAP2_incorrectTransactionPortion 3
#define                     OMAP2_P_AbortCause_resourceLimitation 4

typedef struct OMAP2__choice2 {
    unsigned short  choice;
#       define      OMAP2_p_abortCause_chosen 1
#       define      OMAP2_u_abortCause_chosen 2
    union _union {
        OMAP2_P_AbortCause p_abortCause;  /* to choose, set choice to
                                           * OMAP2_p_abortCause_chosen */
        OMAP2_DialoguePortion u_abortCause;  /* to choose, set choice to
                                              * OMAP2_u_abortCause_chosen */
    } u;
} OMAP2__choice2;

typedef struct OMAP2_Abort {
    unsigned char   bit_mask;
#       define      OMAP2_reason_present 0x80
    OMAP2_DestTransactionID dtid;
    OMAP2__choice2  reason;  /* optional; set in bit_mask OMAP2_reason_present
                              * if present */
} OMAP2_Abort;

// Transaction Portion fields
typedef struct OMAP2_MessageType {
    unsigned short  choice;
#       define      OMAP2_unidirectional_chosen 1
#       define      OMAP2_begin_chosen 2
#       define      OMAP2_end_chosen 3
#       define      OMAP2_continue_chosen 4
#       define      OMAP2_abort_chosen 5
    union _union {
        OMAP2_Unidirectional unidirectional;  /* to choose, set choice to
                                               * OMAP2_unidirectional_chosen */
        OMAP2_Begin     begin;  /* to choose, set choice to
                                 * OMAP2_begin_chosen */
        OMAP2_End       end;  /* to choose, set choice to OMAP2_end_chosen */
        OMAP2_Continue  MessageType_continue;  /* to choose, set choice to
                                                * OMAP2_continue_chosen */
        OMAP2_Abort     abort;  /* to choose, set choice to
                                 * OMAP2_abort_chosen */
    } u;
} OMAP2_MessageType;

typedef short           OMAP2_InvokeIdType;

typedef struct OMAP2__choice3 {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2__choice3;

// The Components are sequences of data elements.
typedef struct OMAP2_Invoke {
    unsigned char   bit_mask;
#       define      OMAP2_linkedID_present 0x80
#       define      OMAP2_Invoke_parameter_present 0x40
    OMAP2_InvokeIdType invokeID;
    OMAP2_InvokeIdType linkedID;  /* optional; set in bit_mask
                                   * OMAP2_linkedID_present if present */
    OMAP2__choice3  operationCode;
    OMAP2__Any      parameter;  /* optional; set in bit_mask
                                 * OMAP2_Invoke_parameter_present if present */
} OMAP2_Invoke;

// ANY is filled by the single ASN.1 data type following the keyword PARAMETER or the keyword ARGUMENT
// in the type definition of a particular operation.
typedef struct OMAP2_ReturnResult {
    unsigned char   bit_mask;
#       define      OMAP2_result_present 0x80
    OMAP2_InvokeIdType invokeID;
    struct OMAP2__seq1 {
        OMAP2__choice3  operationCode;
        OMAP2__Any      parameter;
    } result;  /* optional; set in bit_mask OMAP2_result_present if present */
} OMAP2_ReturnResult;

// ANY is filled by the single ASN.1 data type following the keyword RESULT in the type definition
// of a particular operation.
typedef struct OMAP2_ReturnError {
    unsigned char   bit_mask;
#       define      OMAP2_ReturnError_parameter_present 0x80
    OMAP2_InvokeIdType invokeID;
    OMAP2__choice3  errorCode;
    OMAP2__Any      parameter;  /* optional; set in bit_mask
                                 * OMAP2_ReturnError_parameter_present if
                                 * present */
} OMAP2_ReturnError;

// PROBLEMS
typedef int             OMAP2_GeneralProblem;
#define                     OMAP2_unrecognizedComponent 0
#define                     OMAP2_mistypedComponent 1
#define                     OMAP2_badlyStructuredComponent 2

typedef int             OMAP2_InvokeProblem;
#define                     OMAP2_duplicateInvokeID 0
#define                     OMAP2_unrecognizedOperation 1
#define                     OMAP2_InvokeProblem_mistypedParameter 2
#define                     OMAP2_InvokeProblem_resourceLimitation 3
#define                     OMAP2_initiatingRelease 4
#define                     OMAP2_unrecognizedLinkedID 5
#define                     OMAP2_linkedResponseUnexpected 6
#define                     OMAP2_unexpectedLinkedOperation 7

typedef int             OMAP2_ReturnResultProblem;
#define                     OMAP2_ReturnResultProblem_unrecognizedInvokeID 0
#define                     OMAP2_returnResultUnexpected 1
#define                     OMAP2_ReturnResultProblem_mistypedParameter 2

typedef int             OMAP2_ReturnErrorProblem;
#define                     OMAP2_ReturnErrorProblem_unrecognizedInvokeID 0
#define                     OMAP2_returnErrorUnexpected 1
#define                     OMAP2_unrecognizedError 2
#define                     OMAP2_unexpectedError 3
#define                     OMAP2_ReturnErrorProblem_mistypedParameter 4

typedef struct OMAP2__choice4 {
    unsigned short  choice;
#       define      OMAP2_derivable_chosen 1
#       define      OMAP2_not_derivable_chosen 2
    union _union {
        OMAP2_InvokeIdType derivable;  /* to choose, set choice to
                                        * OMAP2_derivable_chosen */
        Nulltype        not_derivable;  /* to choose, set choice to
                                         * OMAP2_not_derivable_chosen */
    } u;
} OMAP2__choice4;

typedef struct OMAP2__choice5 {
    unsigned short  choice;
#       define      OMAP2_generalProblem_chosen 1
#       define      OMAP2_invokeProblem_chosen 2
#       define      OMAP2_returnResultProblem_chosen 3
#       define      OMAP2_returnErrorProblem_chosen 4
    union _union {
        OMAP2_GeneralProblem generalProblem;  /* to choose, set choice to
                                               * OMAP2_generalProblem_chosen */
        OMAP2_InvokeProblem invokeProblem;  /* to choose, set choice to
                                             * OMAP2_invokeProblem_chosen */
        OMAP2_ReturnResultProblem returnResultProblem;  /* to choose, set choice
                                       * to OMAP2_returnResultProblem_chosen */
        OMAP2_ReturnErrorProblem returnErrorProblem;  /* to choose, set choice
                                        * to OMAP2_returnErrorProblem_chosen */
    } u;
} OMAP2__choice5;

// ANY is filled by the single ASN.1 data type following the keyword PARAMETER in the type definition
// of a particular error.
typedef struct OMAP2_Reject {
    OMAP2__choice4  invokeID;
    OMAP2__choice5  problem;
} OMAP2_Reject;

// Component Portion fields
// COMPONENT TYPE. Recommendation X.229 defines four Application Protocol Data Units (APDUs).
// TCAP adds returnResultNotLast to allow for the segmentation of a result.
typedef struct OMAP2_Component {
    unsigned short  choice;
#       define      OMAP2_invoke_chosen 1
#       define      OMAP2_returnResultLast_chosen 2
#       define      OMAP2_returnError_chosen 3
#       define      OMAP2_reject_chosen 4
#       define      OMAP2_returnResultNotLast_chosen 5
    union _union {
        OMAP2_Invoke    invoke;  /* to choose, set choice to
                                  * OMAP2_invoke_chosen */
        OMAP2_ReturnResult returnResultLast;  /* to choose, set choice to
                                             * OMAP2_returnResultLast_chosen */
        OMAP2_ReturnError returnError;  /* to choose, set choice to
                                         * OMAP2_returnError_chosen */
        OMAP2_Reject    reject;  /* to choose, set choice to
                                  * OMAP2_reject_chosen */
        OMAP2_ReturnResult returnResultNotLast;  /* to choose, set choice to
                                          * OMAP2_returnResultNotLast_chosen */
    } u;
} OMAP2_Component;

// COMPONENT PORTION. The last field in the transaction portion of the TCAP message is the Component Portion.
// The Component Portion may be absent.
typedef struct OMAP2_ComponentPortion_ {
    struct OMAP2_ComponentPortion_ *next;
    OMAP2_Component value;
} *OMAP2_ComponentPortion;

// IOC for private MAP extensions
typedef struct OMAP2_EXTENSION {
    unsigned char   bit_mask;
#       define      OMAP2_ExtensionType_present 0x80
    unsigned short  ExtensionType;  /* optional; set in bit_mask
                                     * OMAP2_ExtensionType_present if present */
    struct OMAP2__ObjectID_ *extensionId;
    long            _oss_unique_index;
} OMAP2_EXTENSION;

typedef Nulltype        OMAP2_SuppressionOfAnnouncement;

typedef enum OMAP2_InterrogationType {
    OMAP2_basicCall = 0,
    OMAP2_forwarding = 1
} OMAP2_InterrogationType;

typedef unsigned short  OMAP2_OR_Phase;

typedef enum OMAP2_ForwardingReason {
    OMAP2_notReachable = 0,
    OMAP2_ForwardingReason_busy = 1,
    OMAP2_noReply = 2
} OMAP2_ForwardingReason;

typedef unsigned short  OMAP2_SupportedCCBS_Phase;

typedef char            OMAP2_Password[5];

typedef char            OMAP2_GetPasswordRes[5];

typedef char            OMAP2_RegisterPasswordRes[5];

typedef enum OMAP2_GuidanceInfo {
    OMAP2_GuidanceInfo_enterPW = 0,
    OMAP2_GuidanceInfo_enterNewPW = 1,
    OMAP2_GuidanceInfo_enterNewPW_Again = 2
} OMAP2_GuidanceInfo;

	// How this information is really delivered to the subscriber
	// (display, announcement, ...) is not part of this
	// specification.
typedef enum OMAP2_GetPasswordArg {
    OMAP2_GetPasswordArg_enterPW = 0,
    OMAP2_GetPasswordArg_enterNewPW = 1,
    OMAP2_GetPasswordArg_enterNewPW_Again = 2
} OMAP2_GetPasswordArg;

typedef enum OMAP2_CancellationType {
    OMAP2_updateProcedure = 0,
    OMAP2_subscriptionWithdraw = 1
} OMAP2_CancellationType;

// security management types
typedef enum OMAP2_EquipmentStatus {
    OMAP2_whiteListed = 0,
    OMAP2_blackListed = 1,
    OMAP2_greyListed = 2
} OMAP2_EquipmentStatus;

typedef enum OMAP2_CallTypeCriteria {
    OMAP2_forwarded = 0,
    OMAP2_notForwarded = 1
} OMAP2_CallTypeCriteria;

typedef enum OMAP2_DefaultCallHandling {
    OMAP2_continueCall = 0,
    OMAP2_releaseCall = 1
} OMAP2_DefaultCallHandling;

typedef enum OMAP2_PW_RegistrationFailureCause {
    OMAP2_undetermined = 0,
    OMAP2_invalidFormat = 1,
    OMAP2_newPasswordsMismatch = 2
} OMAP2_PW_RegistrationFailureCause;

typedef enum OMAP2_Reason {
    OMAP2_Reason_noReasonGiven = 0,
    OMAP2_Reason_invalidDestinationReference = 1,
    OMAP2_Reason_invalidOriginatingReference = 2
} OMAP2_Reason;

typedef enum OMAP2_ResourceUnavailableReason {
    OMAP2_ResourceUnavailableReason_shortTermResourceLimitation = 0,
    OMAP2_ResourceUnavailableReason_longTermResourceLimitation = 1
} OMAP2_ResourceUnavailableReason;

typedef enum OMAP2_ProcedureCancellationReason {
    OMAP2_ProcedureCancellationReason_handoverCancellation = 0,
    OMAP2_ProcedureCancellationReason_radioChannelRelease = 1,
    OMAP2_ProcedureCancellationReason_networkPathRelease = 2,
    OMAP2_ProcedureCancellationReason_callRelease = 3,
    OMAP2_ProcedureCancellationReason_associatedProcedureFailure = 4,
    OMAP2_ProcedureCancellationReason_tandemDialogueRelease = 5,
    OMAP2_ProcedureCancellationReason_remoteOperationsFailure = 6
} OMAP2_ProcedureCancellationReason;

typedef enum OMAP2_ProviderAbortReason {
    OMAP2_ProviderAbortReason_abnormalDialogue = 0,
    OMAP2_ProviderAbortReason_invalidPDU = 1
} OMAP2_ProviderAbortReason;

union OMAP2_All_PDU_Types_union {
    OMAP2_MessageType *pdu_MessageType;  /* OMAP2_MessageType_PDU */
    struct OMAP2_SendRoutingInfoForSM *pdu_SendRoutingInfoForSM;  
                                           /* OMAP2_SendRoutingInfoForSM_PDU */
    struct OMAP2_MO_ForwardSM *pdu_MO_ForwardSM;  /* OMAP2_MO_ForwardSM_PDU */
    struct OMAP2_MT_ForwardSM *pdu_MT_ForwardSM;  /* OMAP2_MT_ForwardSM_PDU */
    struct OMAP2_ReportSM_DeliveryStatus *pdu_ReportSM_DeliveryStatus;  
                                        /* OMAP2_ReportSM_DeliveryStatus_PDU */
    struct OMAP2_AlertServiceCentre *pdu_AlertServiceCentre;  
                                             /* OMAP2_AlertServiceCentre_PDU */
    struct OMAP2_InformServiceCentre *pdu_InformServiceCentre;  
                                            /* OMAP2_InformServiceCentre_PDU */
    struct OMAP2_ReadyForSM *pdu_ReadyForSM;  /* OMAP2_ReadyForSM_PDU */
    struct OMAP2_PrepareGroupCallArg *pdu_PrepareGroupCallArg;  
                                            /* OMAP2_PrepareGroupCallArg_PDU */
    struct OMAP2_PrepareGroupCallRes *pdu_PrepareGroupCallRes;  
                                            /* OMAP2_PrepareGroupCallRes_PDU */
    struct OMAP2_SendGroupCallEndSignalArg *pdu_SendGroupCallEndSignalArg;  
                                        /* OMAP2_SendGroupCallEndSignalArg_PDU */
    struct OMAP2_SendGroupCallEndSignalRes *pdu_SendGroupCallEndSignalRes;  
                                        /* OMAP2_SendGroupCallEndSignalRes_PDU */
    struct OMAP2_ForwardGroupCallSignallingArg *pdu_ForwardGroupCallSignallingArg;                                      /* OMAP2_ForwardGroupCallSignallingArg_PDU */
    struct OMAP2_ProcessGroupCallSignallingArg *pdu_ProcessGroupCallSignallingArg;                                      /* OMAP2_ProcessGroupCallSignallingArg_PDU */
    struct OMAP2_RoutingInfoForSM_Arg *pdu_RoutingInfoForSM_Arg;  
                                           /* OMAP2_RoutingInfoForSM_Arg_PDU */
    struct OMAP2_RoutingInfoForSM_Res *pdu_RoutingInfoForSM_Res;  
                                           /* OMAP2_RoutingInfoForSM_Res_PDU */
    struct OMAP2_Additional_Number *pdu_Additional_Number;  
                                              /* OMAP2_Additional_Number_PDU */
    struct OMAP2_MO_ForwardSM_Arg *pdu_MO_ForwardSM_Arg;  
                                               /* OMAP2_MO_ForwardSM_Arg_PDU */
    struct OMAP2_MO_ForwardSM_Res *pdu_MO_ForwardSM_Res;  
                                               /* OMAP2_MO_ForwardSM_Res_PDU */
    struct OMAP2_MT_ForwardSM_Arg *pdu_MT_ForwardSM_Arg;  
                                               /* OMAP2_MT_ForwardSM_Arg_PDU */
    struct OMAP2_MT_ForwardSM_Res *pdu_MT_ForwardSM_Res;  
                                               /* OMAP2_MT_ForwardSM_Res_PDU */
    struct OMAP2_ReportSM_DeliveryStatusArg *pdu_ReportSM_DeliveryStatusArg;  
                                        /* OMAP2_ReportSM_DeliveryStatusArg_PDU */
    struct OMAP2_ReportSM_DeliveryStatusRes *pdu_ReportSM_DeliveryStatusRes;  
                                        /* OMAP2_ReportSM_DeliveryStatusRes_PDU */
    struct OMAP2_AlertServiceCentreArg *pdu_AlertServiceCentreArg;  
                                          /* OMAP2_AlertServiceCentreArg_PDU */
    struct OMAP2_InformServiceCentreArg *pdu_InformServiceCentreArg;  
                                         /* OMAP2_InformServiceCentreArg_PDU */
    struct OMAP2_ReadyForSM_Arg *pdu_ReadyForSM_Arg;  
                                                 /* OMAP2_ReadyForSM_Arg_PDU */
    struct OMAP2_ReadyForSM_Res *pdu_ReadyForSM_Res;  
                                                 /* OMAP2_ReadyForSM_Res_PDU */
    struct OMAP2_SendRoutingInfo *pdu_SendRoutingInfo;  
                                                /* OMAP2_SendRoutingInfo_PDU */
    struct OMAP2_ProvideRoamingNumber *pdu_ProvideRoamingNumber;  
                                           /* OMAP2_ProvideRoamingNumber_PDU */
    struct OMAP2_ResumeCallHandling *pdu_ResumeCallHandling;  
                                             /* OMAP2_ResumeCallHandling_PDU */
    struct OMAP2_ProvideSIWFSNumber *pdu_ProvideSIWFSNumber;  
                                             /* OMAP2_ProvideSIWFSNumber_PDU */
    struct OMAP2_SIWFSSignallingModify *pdu_SIWFSSignallingModify;  
                                          /* OMAP2_SIWFSSignallingModify_PDU */
    struct OMAP2_PrepareGroupCall *pdu_PrepareGroupCall;  
                                               /* OMAP2_PrepareGroupCall_PDU */
    struct OMAP2_SendGroupCallEndSignal *pdu_SendGroupCallEndSignal;  
                                         /* OMAP2_SendGroupCallEndSignal_PDU */
    struct OMAP2_ProcessGroupCallSignalling *pdu_ProcessGroupCallSignalling;  
                                        /* OMAP2_ProcessGroupCallSignalling_PDU */
    struct OMAP2_ForwardGroupCallSignalling *pdu_ForwardGroupCallSignalling;  
                                        /* OMAP2_ForwardGroupCallSignalling_PDU */
    struct OMAP2_SendRoutingInfoArg *pdu_SendRoutingInfoArg;  
                                             /* OMAP2_SendRoutingInfoArg_PDU */
    OMAP2_SuppressionOfAnnouncement *pdu_SuppressionOfAnnouncement;  
                                      /* OMAP2_SuppressionOfAnnouncement_PDU */
    OMAP2_InterrogationType *pdu_InterrogationType;  
                                              /* OMAP2_InterrogationType_PDU */
    OMAP2_OR_Phase  *pdu_OR_Phase;  /* OMAP2_OR_Phase_PDU */
    OMAP2_ForwardingReason *pdu_ForwardingReason;  
                                               /* OMAP2_ForwardingReason_PDU */
    OMAP2_SupportedCCBS_Phase *pdu_SupportedCCBS_Phase;  
                                            /* OMAP2_SupportedCCBS_Phase_PDU */
    struct OMAP2_SendRoutingInfoRes *pdu_SendRoutingInfoRes;  
                                             /* OMAP2_SendRoutingInfoRes_PDU */
    struct OMAP2_CCBS_Indicators *pdu_CCBS_Indicators;  
                                                /* OMAP2_CCBS_Indicators_PDU */
    struct OMAP2_ProvideRoamingNumberArg *pdu_ProvideRoamingNumberArg;  
                                        /* OMAP2_ProvideRoamingNumberArg_PDU */
    struct OMAP2_ProvideRoamingNumberRes *pdu_ProvideRoamingNumberRes;  
                                        /* OMAP2_ProvideRoamingNumberRes_PDU */
    struct OMAP2_ResumeCallHandlingRes *pdu_ResumeCallHandlingRes;  
                                          /* OMAP2_ResumeCallHandlingRes_PDU */
    struct OMAP2_ProvideSIWFSNumberArg *pdu_ProvideSIWFSNumberArg;  
                                          /* OMAP2_ProvideSIWFSNumberArg_PDU */
    struct OMAP2_ProvideSIWFSNumberRes *pdu_ProvideSIWFSNumberRes;  
                                          /* OMAP2_ProvideSIWFSNumberRes_PDU */
    struct OMAP2_SIWFSSignallingModifyArg *pdu_SIWFSSignallingModifyArg;  
                                        /* OMAP2_SIWFSSignallingModifyArg_PDU */
    struct OMAP2_SIWFSSignallingModifyRes *pdu_SIWFSSignallingModifyRes;  
                                        /* OMAP2_SIWFSSignallingModifyRes_PDU */
    struct OMAP2_StatusReportArg *pdu_StatusReportArg;  
                                                /* OMAP2_StatusReportArg_PDU */
    struct OMAP2_StatusReportRes *pdu_StatusReportRes;  
                                                /* OMAP2_StatusReportRes_PDU */
    struct OMAP2_UpdateLocation *pdu_UpdateLocation;  
                                                 /* OMAP2_UpdateLocation_PDU */
    struct OMAP2_CancelLocation *pdu_CancelLocation;  
                                                 /* OMAP2_CancelLocation_PDU */
    struct OMAP2_PurgeMS *pdu_PurgeMS;  /* OMAP2_PurgeMS_PDU */
    struct OMAP2_SendIdentification *pdu_SendIdentification;  
                                             /* OMAP2_SendIdentification_PDU */
    struct OMAP2_PrepareHandover *pdu_PrepareHandover;  
                                                /* OMAP2_PrepareHandover_PDU */
    struct OMAP2_SendEndSignal *pdu_SendEndSignal;  
                                                  /* OMAP2_SendEndSignal_PDU */
    struct OMAP2_ProcessAccessSignalling *pdu_ProcessAccessSignalling;  
                                        /* OMAP2_ProcessAccessSignalling_PDU */
    struct OMAP2_ForwardAccessSignalling *pdu_ForwardAccessSignalling;  
                                        /* OMAP2_ForwardAccessSignalling_PDU */
    struct OMAP2_PrepareSubsequentHandover *pdu_PrepareSubsequentHandover;  
                                        /* OMAP2_PrepareSubsequentHandover_PDU */
    struct OMAP2_SendAuthenticationInfo *pdu_SendAuthenticationInfo;  
                                         /* OMAP2_SendAuthenticationInfo_PDU */
    struct OMAP2_CheckIMEI *pdu_CheckIMEI;  /* OMAP2_CheckIMEI_PDU */
    struct OMAP2_InsertSubscriberData *pdu_InsertSubscriberData;  
                                           /* OMAP2_InsertSubscriberData_PDU */
    struct OMAP2_DeleteSubscriberData *pdu_DeleteSubscriberData;  
                                           /* OMAP2_DeleteSubscriberData_PDU */
    struct OMAP2_Reset *pdu_Reset;  /* OMAP2_Reset_PDU */
    struct OMAP2_RestoreData *pdu_RestoreData;  /* OMAP2_RestoreData_PDU */
    struct OMAP2_RegisterPasswordArg *pdu_RegisterPasswordArg;  
                                            /* OMAP2_RegisterPasswordArg_PDU */
    struct OMAP2_RegisterSSArg *pdu_RegisterSSArg;  
                                                  /* OMAP2_RegisterSSArg_PDU */
    struct OMAP2_SS_Info *pdu_DeactivateSSRes;  /* OMAP2_DeactivateSSRes_PDU */
    struct OMAP2_SS_Info *pdu_ActivateSSRes;  /* OMAP2_ActivateSSRes_PDU */
    struct OMAP2_SS_Info *pdu_EraseSSRes;  /* OMAP2_EraseSSRes_PDU */
    struct OMAP2_SS_Info *pdu_RegisterSSRes;  /* OMAP2_RegisterSSRes_PDU */
    struct OMAP2_SS_ForBS_Code *pdu_SS_ForBS_Code;  
                                                  /* OMAP2_SS_ForBS_Code_PDU */
    struct OMAP2_InterrogateSSArg *pdu_InterrogateSSArg;  
                                               /* OMAP2_InterrogateSSArg_PDU */
    struct OMAP2_DeactivateSSArg *pdu_DeactivateSSArg;  
                                                /* OMAP2_DeactivateSSArg_PDU */
    struct OMAP2_ActivateSSArg *pdu_ActivateSSArg;  
                                                  /* OMAP2_ActivateSSArg_PDU */
    struct OMAP2_EraseSSArg *pdu_EraseSSArg;  /* OMAP2_EraseSSArg_PDU */
    struct OMAP2_InterrogateSSRes *pdu_InterrogateSSRes;  
                                               /* OMAP2_InterrogateSSRes_PDU */
    struct OMAP2_USSD_Arg *pdu_USSD_Arg;  /* OMAP2_USSD_Arg_PDU */
    struct OMAP2_UnstructuredSS_NotifyArg *pdu_UnstructuredSS_NotifyArg;  
                                        /* OMAP2_UnstructuredSS_NotifyArg_PDU */
    struct OMAP2_UnstructuredSS_RequestArg *pdu_UnstructuredSS_RequestArg;  
                                        /* OMAP2_UnstructuredSS_RequestArg_PDU */
    struct OMAP2_ProcessUnstructuredSS_RequestArg *pdu_ProcessUnstructuredSS_RequestArg;                                /* OMAP2_ProcessUnstructuredSS_RequestArg_PDU */
    struct OMAP2_USSD_Res *pdu_USSD_Res;  /* OMAP2_USSD_Res_PDU */
    struct OMAP2_UnstructuredSS_RequestRes *pdu_UnstructuredSS_RequestRes;  
                                        /* OMAP2_UnstructuredSS_RequestRes_PDU */
    struct OMAP2_ProcessUnstructuredSS_RequestRes *pdu_ProcessUnstructuredSS_RequestRes;                                /* OMAP2_ProcessUnstructuredSS_RequestRes_PDU */
    OMAP2_Password  *pdu_Password;  /* OMAP2_Password_PDU */
    OMAP2_GetPasswordRes *pdu_GetPasswordRes;  /* OMAP2_GetPasswordRes_PDU */
    OMAP2_RegisterPasswordRes *pdu_RegisterPasswordRes;  
                                            /* OMAP2_RegisterPasswordRes_PDU */
    OMAP2_GuidanceInfo *pdu_GuidanceInfo;  /* OMAP2_GuidanceInfo_PDU */
    OMAP2_GetPasswordArg *pdu_GetPasswordArg;  /* OMAP2_GetPasswordArg_PDU */
    struct OMAP2_SS_EventSpecification *pdu_SS_EventSpecification;  
                                          /* OMAP2_SS_EventSpecification_PDU */
    struct OMAP2_CCBS_Data *pdu_CCBS_Data;  /* OMAP2_CCBS_Data_PDU */
    struct OMAP2_SubscriberId *pdu_SubscriberId;  /* OMAP2_SubscriberId_PDU */
    struct OMAP2_IMEI *pdu_IMEI;  /* OMAP2_IMEI_PDU */
    struct OMAP2_NAEA_PreferredCI *pdu_NAEA_PreferredCI;  
                                               /* OMAP2_NAEA_PreferredCI_PDU */
    struct OMAP2_UpdateLocationArg *pdu_UpdateLocationArg;  
                                              /* OMAP2_UpdateLocationArg_PDU */
    struct OMAP2_UpdateLocationRes *pdu_UpdateLocationRes;  
                                              /* OMAP2_UpdateLocationRes_PDU */
    struct OMAP2_CancelLocationArg *pdu_CancelLocationArg;  
                                              /* OMAP2_CancelLocationArg_PDU */
    struct OMAP2_Indentity *pdu_Indentity;  /* OMAP2_Indentity_PDU */
    OMAP2_CancellationType *pdu_CancellationType;  
                                               /* OMAP2_CancellationType_PDU */
    struct OMAP2_CancelLocationRes *pdu_CancelLocationRes;  
                                              /* OMAP2_CancelLocationRes_PDU */
    struct OMAP2_PurgeMS_Arg *pdu_PurgeMS_Arg;  /* OMAP2_PurgeMS_Arg_PDU */
    struct OMAP2_PurgeMS_Res *pdu_PurgeMS_Res;  /* OMAP2_PurgeMS_Res_PDU */
    struct OMAP2_SendIdentificationRes *pdu_SendIdentificationRes;  
                                          /* OMAP2_SendIdentificationRes_PDU */
    struct OMAP2_PrepareHO_Arg *pdu_PrepareHO_Arg;  
                                                  /* OMAP2_PrepareHO_Arg_PDU */
    struct OMAP2_PrepareHO_Res *pdu_PrepareHO_Res;  
                                                  /* OMAP2_PrepareHO_Res_PDU */
    struct OMAP2_PrepareSubsequentHO_Arg *pdu_PrepareSubsequentHO_Arg;  
                                        /* OMAP2_PrepareSubsequentHO_Arg_PDU */
    struct OMAP2_IMSI *pdu_SendAuthenticationInfoArg;  
                                      /* OMAP2_SendAuthenticationInfoArg_PDU */
    struct OMAP2_AuthenticationSetList *pdu_SendAuthenticationInfoRes;  
                                      /* OMAP2_SendAuthenticationInfoRes_PDU */
    OMAP2_EquipmentStatus *pdu_EquipmentStatus;  
                                                /* OMAP2_EquipmentStatus_PDU */
    struct OMAP2_InsertSubscriberDataArg *pdu_InsertSubscriberDataArg;  
                                        /* OMAP2_InsertSubscriberDataArg_PDU */
    struct OMAP2_QoS_Subscribed *pdu_QoS_Subscribed;  
                                                 /* OMAP2_QoS_Subscribed_PDU */
    struct OMAP2_Ext_SS_InfoList *pdu_Ext_SS_InfoList;  
                                                /* OMAP2_Ext_SS_InfoList_PDU */
    struct OMAP2_InsertSubscriberDataRes *pdu_InsertSubscriberDataRes;  
                                        /* OMAP2_InsertSubscriberDataRes_PDU */
    struct OMAP2_DeleteSubscriberDataArg *pdu_DeleteSubscriberDataArg;  
                                        /* OMAP2_DeleteSubscriberDataArg_PDU */
    struct OMAP2_DeleteSubscriberDataRes *pdu_DeleteSubscriberDataRes;  
                                        /* OMAP2_DeleteSubscriberDataRes_PDU */
    OMAP2_CallTypeCriteria *pdu_CallTypeCriteria;  
                                               /* OMAP2_CallTypeCriteria_PDU */
    OMAP2_DefaultCallHandling *pdu_DefaultCallHandling;  
                                            /* OMAP2_DefaultCallHandling_PDU */
    struct OMAP2_ResetArg *pdu_ResetArg;  /* OMAP2_ResetArg_PDU */
    struct OMAP2_RestoreDataArg *pdu_RestoreDataArg;  
                                                 /* OMAP2_RestoreDataArg_PDU */
    struct OMAP2_RestoreDataRes *pdu_RestoreDataRes;  
                                                 /* OMAP2_RestoreDataRes_PDU */
    struct OMAP2_VBSDataList *pdu_VBSDataList;  /* OMAP2_VBSDataList_PDU */
    struct OMAP2_VGCSDataList *pdu_VGCSDataList;  /* OMAP2_VGCSDataList_PDU */
    struct OMAP2_RegisterSS *pdu_RegisterSS;  /* OMAP2_RegisterSS_PDU */
    struct OMAP2_EraseSS *pdu_EraseSS;  /* OMAP2_EraseSS_PDU */
    struct OMAP2_ActivateSS *pdu_ActivateSS;  /* OMAP2_ActivateSS_PDU */
    struct OMAP2_DeactivateSS *pdu_DeactivateSS;  /* OMAP2_DeactivateSS_PDU */
    struct OMAP2_InterrogateSS *pdu_InterrogateSS;  
                                                  /* OMAP2_InterrogateSS_PDU */
    struct OMAP2_ProcessUnstructuredSS_Request *pdu_ProcessUnstructuredSS_Request;                                      /* OMAP2_ProcessUnstructuredSS_Request_PDU */
    struct OMAP2_UnstructuredSS_Request *pdu_UnstructuredSS_Request;  
                                         /* OMAP2_UnstructuredSS_Request_PDU */
    struct OMAP2_UnstructuredSS_Notify *pdu_UnstructuredSS_Notify;  
                                          /* OMAP2_UnstructuredSS_Notify_PDU */
    struct OMAP2_RegisterPassword *pdu_RegisterPassword;  
                                               /* OMAP2_RegisterPassword_PDU */
    struct OMAP2_GetPassword *pdu_GetPassword;  /* OMAP2_GetPassword_PDU */
    struct OMAP2_RoamingNotAllowedParam *pdu_RoamingNotAllowedParam;  
                                         /* OMAP2_RoamingNotAllowedParam_PDU */
    struct OMAP2_CallBarredParam *pdu_CallBarredParam;  
                                                /* OMAP2_CallBarredParam_PDU */
    struct OMAP2_CUG_RejectParam *pdu_CUG_RejectParam;  
                                                /* OMAP2_CUG_RejectParam_PDU */
    struct OMAP2_SS_IncompatibilityCause *pdu_SS_IncompatibilityCause;  
                                        /* OMAP2_SS_IncompatibilityCause_PDU */
    OMAP2_PW_RegistrationFailureCause *pdu_PW_RegistrationFailureCause;  
                                    /* OMAP2_PW_RegistrationFailureCause_PDU */
    struct OMAP2_SM_DeliveryFailureCause *pdu_SM_DeliveryFailureCause;  
                                        /* OMAP2_SM_DeliveryFailureCause_PDU */
    struct OMAP2_AbsentSubscriberSM_Param *pdu_AbsentSubscriberSM_Param;  
                                        /* OMAP2_AbsentSubscriberSM_Param_PDU */
    struct OMAP2_SystemFailureParam *pdu_SystemFailureParam;  
                                             /* OMAP2_SystemFailureParam_PDU */
    struct OMAP2_DataMissingParam *pdu_DataMissingParam;  
                                               /* OMAP2_DataMissingParam_PDU */
    struct OMAP2_UnexpectedDataParam *pdu_UnexpectedDataParam;  
                                            /* OMAP2_UnexpectedDataParam_PDU */
    struct OMAP2_FacilityNotSupParam *pdu_FacilityNotSupParam;  
                                            /* OMAP2_FacilityNotSupParam_PDU */
    struct OMAP2_OR_NotAllowedParam *pdu_OR_NotAllowedParam;  
                                             /* OMAP2_OR_NotAllowedParam_PDU */
    struct OMAP2_UnknownSubscriberParam *pdu_UnknownSubscriberParam;  
                                         /* OMAP2_UnknownSubscriberParam_PDU */
    struct OMAP2_NumberChangedParam *pdu_NumberChangedParam;  
                                             /* OMAP2_NumberChangedParam_PDU */
    struct OMAP2_UnidentifiedSubParam *pdu_UnidentifiedSubParam;  
                                           /* OMAP2_UnidentifiedSubParam_PDU */
    struct OMAP2_IllegalSubscriberParam *pdu_IllegalSubscriberParam;  
                                         /* OMAP2_IllegalSubscriberParam_PDU */
    struct OMAP2_IllegalEquipmentParam *pdu_IllegalEquipmentParam;  
                                          /* OMAP2_IllegalEquipmentParam_PDU */
    struct OMAP2_BearerServNotProvParam *pdu_BearerServNotProvParam;  
                                         /* OMAP2_BearerServNotProvParam_PDU */
    struct OMAP2_TeleservNotProvParam *pdu_TeleservNotProvParam;  
                                           /* OMAP2_TeleservNotProvParam_PDU */
    struct OMAP2_TracingBufferFullParam *pdu_TracingBufferFullParam;  
                                         /* OMAP2_TracingBufferFullParam_PDU */
    struct OMAP2_NoRoamingNbParam *pdu_NoRoamingNbParam;  
                                               /* OMAP2_NoRoamingNbParam_PDU */
    struct OMAP2_AbsentSubscriberParam *pdu_AbsentSubscriberParam;  
                                          /* OMAP2_AbsentSubscriberParam_PDU */
    struct OMAP2_BusySubscriberParam *pdu_BusySubscriberParam;  
                                            /* OMAP2_BusySubscriberParam_PDU */
    struct OMAP2_NoSubscriberReplyParam *pdu_NoSubscriberReplyParam;  
                                         /* OMAP2_NoSubscriberReplyParam_PDU */
    struct OMAP2_ForwardingViolationParam *pdu_ForwardingViolationParam;  
                                        /* OMAP2_ForwardingViolationParam_PDU */
    struct OMAP2_ForwardingFailedParam *pdu_ForwardingFailedParam;  
                                          /* OMAP2_ForwardingFailedParam_PDU */
    struct OMAP2_ATI_NotAllowedParam *pdu_ATI_NotAllowedParam;  
                                            /* OMAP2_ATI_NotAllowedParam_PDU */
    struct OMAP2_SubBusyForMT_SMS_Param *pdu_SubBusyForMT_SMS_Param;  
                                         /* OMAP2_SubBusyForMT_SMS_Param_PDU */
    struct OMAP2_MessageWaitListFullParam *pdu_MessageWaitListFullParam;  
                                        /* OMAP2_MessageWaitListFullParam_PDU */
    struct OMAP2_ResourceLimitationParam *pdu_ResourceLimitationParam;  
                                        /* OMAP2_ResourceLimitationParam_PDU */
    struct OMAP2_NoGroupCallNbParam *pdu_NoGroupCallNbParam;  
                                             /* OMAP2_NoGroupCallNbParam_PDU */
    struct OMAP2_IncompatibleTerminalParam *pdu_IncompatibleTerminalParam;  
                                        /* OMAP2_IncompatibleTerminalParam_PDU */
    struct OMAP2_ShortTermDenialParam *pdu_ShortTermDenialParam;  
                                           /* OMAP2_ShortTermDenialParam_PDU */
    struct OMAP2_LongTermDenialParam *pdu_LongTermDenialParam;  
                                            /* OMAP2_LongTermDenialParam_PDU */
    struct OMAP2_ActivateTraceModeArg *pdu_ActivateTraceModeArg;  
                                           /* OMAP2_ActivateTraceModeArg_PDU */
    struct OMAP2_ActivateTraceModeRes *pdu_ActivateTraceModeRes;  
                                           /* OMAP2_ActivateTraceModeRes_PDU */
    struct OMAP2_DeactivateTraceModeArg *pdu_DeactivateTraceModeArg;  
                                         /* OMAP2_DeactivateTraceModeArg_PDU */
    struct OMAP2_DeactivateTraceModeRes *pdu_DeactivateTraceModeRes;  
                                         /* OMAP2_DeactivateTraceModeRes_PDU */
    struct OMAP2_ISDN_AddressString *pdu_SendIMSIArg;  
                                                    /* OMAP2_SendIMSIArg_PDU */
    struct OMAP2_IMSI *pdu_SendIMSIRes;  /* OMAP2_SendIMSIRes_PDU */
    struct OMAP2_SystemFailure *pdu_SystemFailure;  
                                                  /* OMAP2_SystemFailure_PDU */
    struct OMAP2_DataMissing *pdu_DataMissing;  /* OMAP2_DataMissing_PDU */
    struct OMAP2_UnexpectedDataValue *pdu_UnexpectedDataValue;  
                                            /* OMAP2_UnexpectedDataValue_PDU */
    struct OMAP2_FacilityNotSupported *pdu_FacilityNotSupported;  
                                           /* OMAP2_FacilityNotSupported_PDU */
    struct OMAP2_IncompatibleTerminal *pdu_IncompatibleTerminal;  
                                           /* OMAP2_IncompatibleTerminal_PDU */
    struct OMAP2_ResourceLimitation *pdu_ResourceLimitation;  
                                             /* OMAP2_ResourceLimitation_PDU */
    struct OMAP2_UnknownSubscriber *pdu_UnknownSubscriber;  
                                              /* OMAP2_UnknownSubscriber_PDU */
    struct OMAP2_NumberChanged *pdu_NumberChanged;  
                                                  /* OMAP2_NumberChanged_PDU */
    struct OMAP2_UnknownMSC *pdu_UnknownMSC;  /* OMAP2_UnknownMSC_PDU */
    struct OMAP2_UnidentifiedSubscriber *pdu_UnidentifiedSubscriber;  
                                         /* OMAP2_UnidentifiedSubscriber_PDU */
    struct OMAP2_UnknownEquipment *pdu_UnknownEquipment;  
                                               /* OMAP2_UnknownEquipment_PDU */
    struct OMAP2_RoamingNotAllowed *pdu_RoamingNotAllowed;  
                                              /* OMAP2_RoamingNotAllowed_PDU */
    struct OMAP2_IllegalSubscriber *pdu_IllegalSubscriber;  
                                              /* OMAP2_IllegalSubscriber_PDU */
    struct OMAP2_IllegalEquipment *pdu_IllegalEquipment;  
                                               /* OMAP2_IllegalEquipment_PDU */
    struct OMAP2_BearerServiceNotProvisioned *pdu_BearerServiceNotProvisioned;                                          /* OMAP2_BearerServiceNotProvisioned_PDU */
    struct OMAP2_TeleserviceNotProvisioned *pdu_TeleserviceNotProvisioned;  
                                        /* OMAP2_TeleserviceNotProvisioned_PDU */
    struct OMAP2_NoHandoverNumberAvailable *pdu_NoHandoverNumberAvailable;  
                                        /* OMAP2_NoHandoverNumberAvailable_PDU */
    struct OMAP2_SubsequentHandoverFailure *pdu_SubsequentHandoverFailure;  
                                        /* OMAP2_SubsequentHandoverFailure_PDU */
    struct OMAP2_TracingBufferFull *pdu_TracingBufferFull;  
                                              /* OMAP2_TracingBufferFull_PDU */
    struct OMAP2_NoRoamingNumberAvailable *pdu_NoRoamingNumberAvailable;  
                                        /* OMAP2_NoRoamingNumberAvailable_PDU */
    struct OMAP2_AbsentSubscriber *pdu_AbsentSubscriber;  
                                               /* OMAP2_AbsentSubscriber_PDU */
    struct OMAP2_BusySubscriber *pdu_BusySubscriber;  
                                                 /* OMAP2_BusySubscriber_PDU */
    struct OMAP2_NoSubscriberReply *pdu_NoSubscriberReply;  
                                              /* OMAP2_NoSubscriberReply_PDU */
    struct OMAP2_CallBarred *pdu_CallBarred;  /* OMAP2_CallBarred_PDU */
    struct OMAP2_ForwardingViolation *pdu_ForwardingViolation;  
                                            /* OMAP2_ForwardingViolation_PDU */
    struct OMAP2_ForwardingFailed *pdu_ForwardingFailed;  
                                               /* OMAP2_ForwardingFailed_PDU */
    struct OMAP2_CUG_Reject *pdu_CUG_Reject;  /* OMAP2_CUG_Reject_PDU */
    struct OMAP2_OR_NotAllowed *pdu_OR_NotAllowed;  
                                                  /* OMAP2_OR_NotAllowed_PDU */
    struct OMAP2_ATI_NotAllowed *pdu_ATI_NotAllowed;  
                                                 /* OMAP2_ATI_NotAllowed_PDU */
    struct OMAP2_IllegalSS_Operation *pdu_IllegalSS_Operation;  
                                            /* OMAP2_IllegalSS_Operation_PDU */
    struct OMAP2_SS_ErrorStatus *pdu_SS_ErrorStatus;  
                                                 /* OMAP2_SS_ErrorStatus_PDU */
    struct OMAP2_SS_NotAvailable *pdu_SS_NotAvailable;  
                                                /* OMAP2_SS_NotAvailable_PDU */
    struct OMAP2_SS_SubscriptionViolation *pdu_SS_SubscriptionViolation;  
                                        /* OMAP2_SS_SubscriptionViolation_PDU */
    struct OMAP2_SS_Incompatibility *pdu_SS_Incompatibility;  
                                             /* OMAP2_SS_Incompatibility_PDU */
    struct OMAP2_UnknownAlphabet *pdu_UnknownAlphabet;  
                                                /* OMAP2_UnknownAlphabet_PDU */
    struct OMAP2_USSD_Busy *pdu_USSD_Busy;  /* OMAP2_USSD_Busy_PDU */
    struct OMAP2_PW_RegistrationFailure *pdu_PW_RegistrationFailure;  
                                         /* OMAP2_PW_RegistrationFailure_PDU */
    struct OMAP2_NegativePW_Check *pdu_NegativePW_Check;  
                                               /* OMAP2_NegativePW_Check_PDU */
    struct OMAP2_NumberOfPW_AttemptsViolation *pdu_NumberOfPW_AttemptsViolation;                                        /* OMAP2_NumberOfPW_AttemptsViolation_PDU */
    struct OMAP2_ShortTermDenial *pdu_ShortTermDenial;  
                                                /* OMAP2_ShortTermDenial_PDU */
    struct OMAP2_LongTermDenial *pdu_LongTermDenial;  
                                                 /* OMAP2_LongTermDenial_PDU */
    struct OMAP2_SubscriberBusyForMT_SMS *pdu_SubscriberBusyForMT_SMS;  
                                        /* OMAP2_SubscriberBusyForMT_SMS_PDU */
    struct OMAP2_SM_DeliveryFailure *pdu_SM_DeliveryFailure;  
                                             /* OMAP2_SM_DeliveryFailure_PDU */
    struct OMAP2_MessageWaitingListFull *pdu_MessageWaitingListFull;  
                                         /* OMAP2_MessageWaitingListFull_PDU */
    struct OMAP2_AbsentSubscriberSM *pdu_AbsentSubscriberSM;  
                                             /* OMAP2_AbsentSubscriberSM_PDU */
    struct OMAP2_NoGroupCallNumberAvailable *pdu_NoGroupCallNumberAvailable;  
                                        /* OMAP2_NoGroupCallNumberAvailable_PDU */
    struct OMAP2_ActivateTraceMode *pdu_ActivateTraceMode;  
                                              /* OMAP2_ActivateTraceMode_PDU */
    struct OMAP2_DeactivateTraceMode *pdu_DeactivateTraceMode;  
                                            /* OMAP2_DeactivateTraceMode_PDU */
    struct OMAP2_SendIMSI *pdu_SendIMSI;  /* OMAP2_SendIMSI_PDU */
    struct OMAP2_DialoguePDU *pdu_DialoguePDU;  /* OMAP2_DialoguePDU_PDU */
    struct OMAP2_OpenInfo *pdu_OpenInfo;  /* OMAP2_OpenInfo_PDU */
    struct OMAP2_AcceptInfo *pdu_AcceptInfo;  /* OMAP2_AcceptInfo_PDU */
    struct OMAP2_CloseInfo *pdu_CloseInfo;  /* OMAP2_CloseInfo_PDU */
    struct OMAP2_RefuseInfo *pdu_RefuseInfo;  /* OMAP2_RefuseInfo_PDU */
    OMAP2_Reason    *pdu_Reason;  /* OMAP2_Reason_PDU */
    struct OMAP2_UserAbortInfo *pdu_UserAbortInfo;  
                                                  /* OMAP2_UserAbortInfo_PDU */
    struct OMAP2_UserAbortChoice *pdu_UserAbortChoice;  
                                                /* OMAP2_UserAbortChoice_PDU */
    OMAP2_ResourceUnavailableReason *pdu_ResourceUnavailableReason;  
                                      /* OMAP2_ResourceUnavailableReason_PDU */
    OMAP2_ProcedureCancellationReason *pdu_ProcedureCancellationReason;  
                                    /* OMAP2_ProcedureCancellationReason_PDU */
    struct OMAP2_ProviderAbortInfo *pdu_ProviderAbortInfo;  
                                              /* OMAP2_ProviderAbortInfo_PDU */
    OMAP2_ProviderAbortReason *pdu_ProviderAbortReason;  
                                            /* OMAP2_ProviderAbortReason_PDU */
};

enum OMAP2_ExtensionSet_ExtensionType_PDUs {
    OMAP2_PDU_ExtensionSet_ExtensionType_UNKNOWN = 0,
    OMAP2_PDU_ExtensionSet_ExtensionType_MAX = INT_MAX
};

union OMAP2_ExtensionSet_ExtensionType_union {
    OMAP2_All_PDU_Types_union other;  /* for known extensions */
};

typedef struct OMAP2_ExtensionSet_ExtensionType {
    OMAP2_ExtensionSet_ExtensionType_PDUs pduNum;
    OssBuf          encoded;
    OMAP2_ExtensionSet_ExtensionType_union decoded;
} OMAP2_ExtensionSet_ExtensionType;

typedef struct OMAP2_PrivateExtension {
    unsigned char   bit_mask;
#       define      OMAP2_extType_present 0x80
    struct OMAP2__ObjectID_ *extId;
    OMAP2_ExtensionSet_ExtensionType extType;  /* optional; set in bit_mask
                                                * OMAP2_extType_present if
                                                * present */
} OMAP2_PrivateExtension;

typedef struct OMAP2_PrivateExtensionList {
    unsigned short  count;
    OMAP2_PrivateExtension value[10];
} OMAP2_PrivateExtensionList;

	// Unsupported private extensions shall be discarded if received.
typedef struct OMAP2_PCS_Extensions {
    char            placeholder;
} OMAP2_PCS_Extensions;

	// The length of the Object Identifier shall not exceed 16 octets and the
	// number of components of the Object Identifier shall not exceed 16
// data types
typedef struct OMAP2_ExtensionContainer {
    unsigned char   bit_mask;
#       define      OMAP2_privateExtensionList_present 0x80
#       define      OMAP2_pcs_Extensions_present 0x40
    OMAP2_PrivateExtensionList privateExtensionList;  /* optional; set in
                                   * bit_mask OMAP2_privateExtensionList_present
                                   * if present */
    OMAP2_PCS_Extensions pcs_Extensions;  /* optional; set in bit_mask
                                           * OMAP2_pcs_Extensions_present if
                                           * present */
} OMAP2_ExtensionContainer;

typedef struct OMAP2_SendRoutingInfoForSM {                              /*Timer m*/
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_SendRoutingInfoForSM;

typedef struct OMAP2_MO_ForwardSM {                              /*Timer ml*/
			// optional
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_MO_ForwardSM;

typedef struct OMAP2_MT_ForwardSM {                              /*Timer ml*/
			// optional
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_MT_ForwardSM;

typedef struct OMAP2_ReportSM_DeliveryStatus {                   /*Timer s*/
		// optional
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_ReportSM_DeliveryStatus;

typedef struct OMAP2_AlertServiceCentre {                                /*Timer s*/
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_AlertServiceCentre;

typedef struct OMAP2_InformServiceCentre {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_InformServiceCentre;                               /*Timer s*/

typedef struct OMAP2_ReadyForSM {                                /*Timer m*/
			// optional
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_ReadyForSM;

typedef struct OMAP2_BearerServiceCode {
    unsigned short  length;
    unsigned char   value[1];
} OMAP2_BearerServiceCode;

	// This type is used to represent the code identifying a single
	// bearer service, a group of bearer services, or all bearer
	// services. The services are defined in TS GSM 02.02.
	// The internal structure is defined as follows:
	//
	// plmn-specific bearer services:
	// bits 87654321: defined by the HPLMN operator

	// rest of bearer services:
	// bit 8: 0 (unused)
	// bits 7654321: group (bits 7654), and rate, if applicable
	// (bits 321)
typedef struct OMAP2_Ext_BearerServiceCode {
    unsigned short  length;
    unsigned char   value[5];
} OMAP2_Ext_BearerServiceCode;

	// This type is used to represent the code identifying a single
	// teleservice, a group of teleservices, or all teleservices. The
	// services are defined in TS GSM 02.03.
	// The internal structure is defined as follows:

	// bits 87654321: group (bits 8765) and specific service
	// (bits 4321)
typedef struct OMAP2_Ext_TeleserviceCode {
    unsigned short  length;
    unsigned char   value[5];
} OMAP2_Ext_TeleserviceCode;

	// digits of MCC, MNC, MSIN are concatenated in this order.
typedef struct OMAP2_ASCI_CallReference {
    unsigned short  length;
    unsigned char   value[8];
} OMAP2_ASCI_CallReference;

typedef struct OMAP2_CODEC_Info {
    unsigned short  length;
    unsigned char   value[10];
} OMAP2_CODEC_Info;

	// Refers to channel type
	// coded according to GSM 08.08	
typedef struct OMAP2_CipheringAlgorithm {
    unsigned short  length;
    unsigned char   value[1];
} OMAP2_CipheringAlgorithm;
	// Refers to 'permitted algorithms' in 'encryption information'
	// coded according to GSM 08.08:

	// Bits 8-1 
	// 8765 4321
	// 0000 0001	No encryption
	// 0000 0010	GSM A5/1
	// 0000 0100	GSM A5/2
	// 0000 1000	GSM A5/3
	// 0001 0000	GSM A5/4
	// 0010 0000	GSM A5/5
	// 0100 0000	GSM A5/6
	// 1000 0000	GSM A5/7

typedef unsigned short  OMAP2_GroupKeyNumber;

typedef struct OMAP2_Kc {
    unsigned short  length;
    unsigned char   value[8];
} OMAP2_Kc;

typedef unsigned short  OMAP2_EMLPP_Priority;

typedef struct OMAP2_PrepareGroupCallArg {
    unsigned char   bit_mask;
#       define      OMAP2_groupKeyNumber_present 0x80
#       define      OMAP2_groupKey_present 0x40
#       define      OMAP2_priority_present 0x20
#       define      OMAP2_uplinkFree_present 0x10
#       define      OMAP2_PrepareGroupCallArg_extensionContainer_present 0x08
    OMAP2_Ext_TeleserviceCode teleservice;
    OMAP2_ASCI_CallReference asciCallReference;
    OMAP2_CODEC_Info codec_Info;
    OMAP2_CipheringAlgorithm cipheringAlgorithm;
    OMAP2_GroupKeyNumber groupKeyNumber;  /* optional; set in bit_mask
                                           * OMAP2_groupKeyNumber_present if
                                           * present */
    OMAP2_Kc        groupKey;  /* optional; set in bit_mask
                                * OMAP2_groupKey_present if present */
    OMAP2_EMLPP_Priority priority;  /* optional; set in bit_mask
                                     * OMAP2_priority_present if present */
    Nulltype        uplinkFree;  /* optional; set in bit_mask
                                  * OMAP2_uplinkFree_present if present */
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                      * OMAP2_PrepareGroupCallArg_extensionContainer_present if
                      * present */
} OMAP2_PrepareGroupCallArg;

typedef struct OMAP2_ISDN_AddressString {
    unsigned short  length;
    unsigned char   value[9];
} OMAP2_ISDN_AddressString;

typedef struct OMAP2_PrepareGroupCallRes {
    unsigned char   bit_mask;
#       define      OMAP2_PrepareGroupCallRes_extensionContainer_present 0x80
    OMAP2_ISDN_AddressString groupCallNumber;
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                      * OMAP2_PrepareGroupCallRes_extensionContainer_present if
                      * present */
} OMAP2_PrepareGroupCallRes;

	// all other values of Alerting Category are reserved
	// Alerting categories are defined in GSM 02.07

// data types for numbering and identification
typedef struct OMAP2_IMSI {
    unsigned short  length;
    unsigned char   value[8];
} OMAP2_IMSI;

typedef struct OMAP2_SendGroupCallEndSignalArg {
    unsigned char   bit_mask;
#       define      OMAP2_SendGroupCallEndSignalArg_imsi_present 0x80
#       define      OMAP2_SendGroupCallEndSignalArg_extensionContainer_present 0x40
    OMAP2_IMSI      imsi;  /* optional; set in bit_mask
                            * OMAP2_SendGroupCallEndSignalArg_imsi_present if
                            * present */
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                * OMAP2_SendGroupCallEndSignalArg_extensionContainer_present if
                * present */
} OMAP2_SendGroupCallEndSignalArg;

typedef struct OMAP2_SendGroupCallEndSignalRes {
    unsigned char   bit_mask;
#       define      OMAP2_SendGroupCallEndSignalRes_extensionContainer_present 0x80
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                * OMAP2_SendGroupCallEndSignalRes_extensionContainer_present if
                * present */
} OMAP2_SendGroupCallEndSignalRes;

typedef struct OMAP2_ForwardGroupCallSignallingArg {
    unsigned char   bit_mask;
#       define      OMAP2_ForwardGroupCallSignallingArg_imsi_present 0x80
#       define      OMAP2_uplinkRequestAck_present 0x40
#       define      OMAP2_ForwardGroupCallSignallingArg_uplinkReleaseIndication_present 0x20
#       define      OMAP2_uplinkRejectCommand_present 0x10
#       define      OMAP2_uplinkSeizedCommand_present 0x08
#       define      OMAP2_uplinkReleaseCommand_present 0x04
#       define      OMAP2_ForwardGroupCallSignallingArg_extensionContainer_present 0x02
    OMAP2_IMSI      imsi;  /* optional; set in bit_mask
                            * OMAP2_ForwardGroupCallSignallingArg_imsi_present
                            * if present */
    Nulltype        uplinkRequestAck;  /* optional; set in bit_mask
                                        * OMAP2_uplinkRequestAck_present if
                                        * present */
    Nulltype        uplinkReleaseIndication;  /* optional; set in bit_mask
       * OMAP2_ForwardGroupCallSignallingArg_uplinkReleaseIndication_present if
       * present */
    Nulltype        uplinkRejectCommand;  /* optional; set in bit_mask
                                           * OMAP2_uplinkRejectCommand_present
                                           * if present */
    Nulltype        uplinkSeizedCommand;  /* optional; set in bit_mask
                                           * OMAP2_uplinkSeizedCommand_present
                                           * if present */
    Nulltype        uplinkReleaseCommand;  /* optional; set in bit_mask
                                            * OMAP2_uplinkReleaseCommand_present
                                            * if present */
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
            * OMAP2_ForwardGroupCallSignallingArg_extensionContainer_present if
            * present */
} OMAP2_ForwardGroupCallSignallingArg;

typedef struct OMAP2_ProcessGroupCallSignallingArg {
    unsigned char   bit_mask;
#       define      OMAP2_uplinkRequest_present 0x80
#       define      OMAP2_ProcessGroupCallSignallingArg_uplinkReleaseIndication_present 0x40
#       define      OMAP2_releaseGroupCall_present 0x20
#       define      OMAP2_ProcessGroupCallSignallingArg_extensionContainer_present 0x10
    Nulltype        uplinkRequest;  /* optional; set in bit_mask
                                     * OMAP2_uplinkRequest_present if present */
    Nulltype        uplinkReleaseIndication;  /* optional; set in bit_mask
       * OMAP2_ProcessGroupCallSignallingArg_uplinkReleaseIndication_present if
       * present */
    Nulltype        releaseGroupCall;  /* optional; set in bit_mask
                                        * OMAP2_releaseGroupCall_present if
                                        * present */
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
            * OMAP2_ProcessGroupCallSignallingArg_extensionContainer_present if
            * present */
} OMAP2_ProcessGroupCallSignallingArg;

	// This type (Telephony Binary Coded Decimal String) is used to
	// represent several digits from 0 through 9, *, #, a, b, c, two
	// digits per octet, each digit encoded 0000 to 1001 (0 to 9),
	// 1010 (*), 1011 (#), 1100 (a), 1101 (b) or 1110 (c); 1111 used
	// as filler when there is an odd number of digits.

	// bits 8765 of octet n encoding digit 2n
	// bits 4321 of octet n encoding digit 2(n-1) +1
typedef struct OMAP2_AddressString {
    unsigned short  length;
    unsigned char   value[20];
} OMAP2_AddressString;

typedef unsigned short  OMAP2_SM_RP_MTI;

	// 0 SMS Deliver 
	// 1 SMS Status Report
	// other values are reserved for future use and shall be discarded if
	// received
typedef struct OMAP2_SM_RP_SMEA {
    unsigned short  length;
    unsigned char   value[12];
} OMAP2_SM_RP_SMEA;

typedef struct OMAP2_RoutingInfoForSM_Arg {
    unsigned char   bit_mask;
#       define      OMAP2_RoutingInfoForSM_Arg_extensionContainer_present 0x80
#       define      OMAP2_gprsSupportIndicator_present 0x40
#       define      OMAP2_sm_RP_MTI_present 0x20
#       define      OMAP2_sm_RP_SMEA_present 0x10
    OMAP2_ISDN_AddressString msisdn;
    ossBoolean      sm_RP_PRI;
    OMAP2_AddressString serviceCentreAddress;
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                     * OMAP2_RoutingInfoForSM_Arg_extensionContainer_present if
                     * present */
    Nulltype        gprsSupportIndicator;  /* extension #1; optional; set in
                                   * bit_mask OMAP2_gprsSupportIndicator_present
                                   * if present */
   // gprsSupportIndicator is set only if the SMS-GMSC supports
   // receiving of two numbers from the HLR
    OMAP2_SM_RP_MTI sm_RP_MTI;  /* extension #2; optional; set in bit_mask
                                 * OMAP2_sm_RP_MTI_present if present */
    OMAP2_SM_RP_SMEA sm_RP_SMEA;  /* extension #3; optional; set in bit_mask
                                   * OMAP2_sm_RP_SMEA_present if present */
} OMAP2_RoutingInfoForSM_Arg;

	// this parameter contains an address field which is encoded 
	// as defined in GSM 03.40. An address field contains 3 elements :
	// 		address-length
	// 		type-of-address
	// 		address-value
typedef struct OMAP2_LocationInfo {
    unsigned short  choice;
#       define      OMAP2_LocationInfo_roamingNumber_chosen 1
#       define      OMAP2_LocationInfo_msc_Number_chosen 2
    union _union {
        OMAP2_ISDN_AddressString roamingNumber;  /* to choose, set choice to
                                   * OMAP2_LocationInfo_roamingNumber_chosen */
   // NU>1 roamingNumber must not be used in version greater 1
        OMAP2_ISDN_AddressString msc_Number;  /* to choose, set choice to
                                      * OMAP2_LocationInfo_msc_Number_chosen */
    } u;
} OMAP2_LocationInfo;

typedef struct OMAP2_LMSI {
    unsigned short  length;
    unsigned char   value[4];
} OMAP2_LMSI;

typedef struct OMAP2_LocationInfoWithLMSI {
    unsigned char   bit_mask;
#       define      OMAP2_LocationInfoWithLMSI_lmsi_present 0x80
    OMAP2_LocationInfo locationInfo;
    OMAP2_LMSI      lmsi;  /* optional; set in bit_mask
                            * OMAP2_LocationInfoWithLMSI_lmsi_present if
                            * present */
} OMAP2_LocationInfoWithLMSI;

typedef struct OMAP2_RoutingInfoForSM_Res {
    unsigned char   bit_mask;
#       define      OMAP2_RoutingInfoForSM_Res_extensionContainer_present 0x80
    OMAP2_IMSI      imsi;
    OMAP2_LocationInfoWithLMSI locationInfoWithLMSI;
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                     * OMAP2_RoutingInfoForSM_Res_extensionContainer_present if
                     * present */
} OMAP2_RoutingInfoForSM_Res;

typedef struct OMAP2_Additional_Number {
    unsigned short  choice;
#       define      OMAP2_Additional_Number_msc_Number_chosen 1
#       define      OMAP2_sgsn_Number_chosen 2
    union _union {
        OMAP2_ISDN_AddressString msc_Number;  /* to choose, set choice to
                                 * OMAP2_Additional_Number_msc_Number_chosen */
        OMAP2_ISDN_AddressString sgsn_Number;  /* to choose, set choice to
                                                * OMAP2_sgsn_Number_chosen */
    } u;
} OMAP2_Additional_Number;

typedef struct OMAP2_SM_RP_DA {
    unsigned short  choice;
#       define      OMAP2_SM_RP_DA_imsi_chosen 1
#       define      OMAP2_lmsi_chosen 2
#       define      OMAP2_serviceCentreAddressDA_chosen 3
#       define      OMAP2_noSM_RP_DA_chosen 4
    union _union {
        OMAP2_IMSI      imsi;  /* to choose, set choice to
                                * OMAP2_SM_RP_DA_imsi_chosen */
        OMAP2_LMSI      lmsi;  /* to choose, set choice to OMAP2_lmsi_chosen */
        OMAP2_AddressString serviceCentreAddressDA;  /* to choose, set choice to
                                       * OMAP2_serviceCentreAddressDA_chosen */
        Nulltype        noSM_RP_DA;  /* to choose, set choice to
                                      * OMAP2_noSM_RP_DA_chosen */
    } u;
} OMAP2_SM_RP_DA;

typedef struct OMAP2_SM_RP_OA {
    unsigned short  choice;
#       define      OMAP2_msisdn_chosen 1
#       define      OMAP2_serviceCentreAddressOA_chosen 2
#       define      OMAP2_noSM_RP_OA_chosen 3
    union _union {
        OMAP2_ISDN_AddressString msisdn;  /* to choose, set choice to
                                           * OMAP2_msisdn_chosen */
        OMAP2_AddressString serviceCentreAddressOA;  /* to choose, set choice to
                                       * OMAP2_serviceCentreAddressOA_chosen */
        Nulltype        noSM_RP_OA;  /* to choose, set choice to
                                      * OMAP2_noSM_RP_OA_chosen */
    } u;
} OMAP2_SM_RP_OA;

typedef struct OMAP2_SignalInfo {
    unsigned short  length;
    unsigned char   value[200];
} OMAP2_SignalInfo;

	// additional-number can be either msc-number or sgsn-number
	// if received networkNode-number is msc-number then the 	
	// additional number is sgsn-number 
	// if received networkNode-number is sgsn-number then the 
	// additional number is msc-number 
typedef struct OMAP2_MO_ForwardSM_Arg {
    unsigned char   bit_mask;
#       define      OMAP2_MO_ForwardSM_Arg_extensionContainer_present 0x80
    OMAP2_SM_RP_DA  sm_RP_DA;
    OMAP2_SM_RP_OA  sm_RP_OA;
    OMAP2_SignalInfo sm_RP_UI;
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                         * OMAP2_MO_ForwardSM_Arg_extensionContainer_present if
                         * present */
} OMAP2_MO_ForwardSM_Arg;

typedef struct OMAP2_MO_ForwardSM_Res {
    unsigned char   bit_mask;
#       define      OMAP2_MO_ForwardSM_Res_extensionContainer_present 0x80
    OMAP2_SignalInfo sm_RP_UI;
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                         * OMAP2_MO_ForwardSM_Res_extensionContainer_present if
                         * present */
} OMAP2_MO_ForwardSM_Res;

typedef struct OMAP2_MT_ForwardSM_Arg {
    unsigned char   bit_mask;
#       define      OMAP2_moreMessagesToSend_present 0x80
#       define      OMAP2_MT_ForwardSM_Arg_extensionContainer_present 0x40
    OMAP2_SM_RP_DA  sm_RP_DA;
    OMAP2_SM_RP_OA  sm_RP_OA;
    OMAP2_SignalInfo sm_RP_UI;
    Nulltype        moreMessagesToSend;  /* optional; set in bit_mask
                                          * OMAP2_moreMessagesToSend_present if
                                          * present */
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                         * OMAP2_MT_ForwardSM_Arg_extensionContainer_present if
                         * present */
} OMAP2_MT_ForwardSM_Arg;

typedef struct OMAP2_MT_ForwardSM_Res {
    unsigned char   bit_mask;
#       define      OMAP2_sm_RP_UI_present 0x80
#       define      OMAP2_MT_ForwardSM_Res_extensionContainer_present 0x40
    OMAP2_SignalInfo sm_RP_UI;  /* optional; set in bit_mask
                                 * OMAP2_sm_RP_UI_present if present */
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                         * OMAP2_MT_ForwardSM_Res_extensionContainer_present if
                         * present */
} OMAP2_MT_ForwardSM_Res;

typedef enum OMAP2_SM_DeliveryOutcome {
    OMAP2_SM_DeliveryOutcome_memoryCapacityExceeded = 0,
    OMAP2_SM_DeliveryOutcome_absentSubscriber = 1,
    OMAP2_successfulTransfer = 2
} OMAP2_SM_DeliveryOutcome;

typedef struct OMAP2_ReportSM_DeliveryStatusArg {
    OMAP2_ISDN_AddressString msisdn;
    OMAP2_AddressString serviceCentreAddress;
    OMAP2_SM_DeliveryOutcome sm_DeliveryOutcome;
} OMAP2_ReportSM_DeliveryStatusArg;

typedef struct OMAP2_ReportSM_DeliveryStatusRes {
    unsigned char   bit_mask;
#       define      OMAP2_ReportSM_DeliveryStatusRes_storedMSISDN_present 0x80
#       define      OMAP2_ReportSM_DeliveryStatusRes_extensionContainer_present 0x40
    OMAP2_ISDN_AddressString storedMSISDN;  /* optional; set in bit_mask
                     * OMAP2_ReportSM_DeliveryStatusRes_storedMSISDN_present if
                     * present */
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
               * OMAP2_ReportSM_DeliveryStatusRes_extensionContainer_present if
               * present */
} OMAP2_ReportSM_DeliveryStatusRes;

typedef struct OMAP2_AlertServiceCentreArg {
    OMAP2_ISDN_AddressString msisdn;
    OMAP2_AddressString serviceCentreAddress;
} OMAP2_AlertServiceCentreArg;

typedef struct OMAP2_MW_Status {
    unsigned short  length;  /* number of significant bits */
    unsigned char   value[1];
} OMAP2_MW_Status;
#define                     OMAP2_sc_AddressNotIncluded 0x80
#define                     OMAP2_sc_AddressNotIncluded_byte 0
#define                     OMAP2_mnrf_Set 0x40
#define                     OMAP2_mnrf_Set_byte 0
#define                     OMAP2_mcef_Set 0x20
#define                     OMAP2_mcef_Set_byte 0

typedef struct OMAP2_InformServiceCentreArg {
    unsigned char   bit_mask;
#       define      OMAP2_InformServiceCentreArg_storedMSISDN_present 0x80
#       define      OMAP2_mw_Status_present 0x40
#       define      OMAP2_InformServiceCentreArg_extensionContainer_present 0x20
    OMAP2_ISDN_AddressString storedMSISDN;  /* optional; set in bit_mask
                         * OMAP2_InformServiceCentreArg_storedMSISDN_present if
                         * present */
    OMAP2_MW_Status mw_Status;  /* optional; set in bit_mask
                                 * OMAP2_mw_Status_present if present */
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                   * OMAP2_InformServiceCentreArg_extensionContainer_present if
                   * present */
} OMAP2_InformServiceCentreArg;

typedef enum OMAP2_AlertReason {
    OMAP2_ms_Present = 0,
    OMAP2_memoryAvailable = 1
} OMAP2_AlertReason;

typedef struct OMAP2_ReadyForSM_Arg {
    OMAP2_IMSI      imsi;
    OMAP2_AlertReason alertReason;
} OMAP2_ReadyForSM_Arg;

typedef struct OMAP2_ReadyForSM_Res {
    unsigned char   bit_mask;
#       define      OMAP2_ReadyForSM_Res_extensionContainer_present 0x80
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                           * OMAP2_ReadyForSM_Res_extensionContainer_present if
                           * present */
} OMAP2_ReadyForSM_Res;

typedef struct OMAP2_SendRoutingInfo {                           /*Timer m*/
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_SendRoutingInfo;

typedef struct OMAP2_ProvideRoamingNumber {                              /*Timer m*/
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_ProvideRoamingNumber;

typedef struct OMAP2_ResumeCallHandling {                                /*Timer m*/
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_ResumeCallHandling;

typedef struct OMAP2_ProvideSIWFSNumber {                                /*Timer m*/
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_ProvideSIWFSNumber;

typedef struct OMAP2_SIWFSSignallingModify {                             /*Timer m*/
		// optional
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_SIWFSSignallingModify;

typedef struct OMAP2_PrepareGroupCall {                          /*Timer m*/
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_PrepareGroupCall;

typedef struct OMAP2_SendGroupCallEndSignal {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_SendGroupCallEndSignal;                            /*Timer l*/

typedef struct OMAP2_ProcessGroupCallSignalling {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_ProcessGroupCallSignalling;                        /*Timer s*/

typedef struct OMAP2_ForwardGroupCallSignalling {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_ForwardGroupCallSignalling;                        /*Timer s*/

typedef struct OMAP2_SS_Code {
    unsigned short  length;
    unsigned char   value[1];
} OMAP2_SS_Code;

	// The internal structure is defined in ETS 300 138.
typedef struct OMAP2_MS_DataTypes_CUG_Interlock {
    unsigned short  length;
    unsigned char   value[4];
} OMAP2_MS_DataTypes_CUG_Interlock;

typedef struct OMAP2_CUG_CheckInfo {
    unsigned char   bit_mask;
#       define      OMAP2_cug_OutgoingAccess_present 0x80
#       define      OMAP2_CUG_CheckInfo_extensionContainer_present 0x40
    OMAP2_MS_DataTypes_CUG_Interlock cug_Interlock;
    Nulltype        cug_OutgoingAccess;  /* optional; set in bit_mask
                                          * OMAP2_cug_OutgoingAccess_present if
                                          * present */
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                            * OMAP2_CUG_CheckInfo_extensionContainer_present if
                            * present */
} OMAP2_CUG_CheckInfo;

typedef unsigned short  OMAP2_NumberOfForwarding;

	// This NamedValue represents the theoretical maximum number of
	// octets which are available to carry a single data type,
	// without requiring segmentation to cope with the network layer
	// service. However, the actual maximum size available for a data
	// type may be lower, especially when other information elements
	// have to be included in the same component.
typedef enum OMAP2_ProtocolId {
    OMAP2_gsm_0408 = 1,
    OMAP2_gsm_0806 = 2,
    OMAP2_gsm_BSSMAP = 3,
	// Value 3 is reserved and must not be used
    OMAP2_ets_300102_1 = 4
} OMAP2_ProtocolId;

typedef struct OMAP2_ExternalSignalInfo {
    unsigned char   bit_mask;
#       define      OMAP2_ExternalSignalInfo_extensionContainer_present 0x80
    OMAP2_ProtocolId protocolId;
    OMAP2_SignalInfo signalInfo;
	// Information about the internal structure is given in
	// subclause 7.6.9.
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                       * OMAP2_ExternalSignalInfo_extensionContainer_present if
                       * present */
	// extensionContainer must not be used in version 2
} OMAP2_ExternalSignalInfo;

typedef struct OMAP2_SendRoutingInfoArg {
    unsigned char   bit_mask;
#       define      OMAP2_SendRoutingInfoArg_cug_CheckInfo_present 0x80
#       define      OMAP2_numberOfForwarding_present 0x40
#       define      OMAP2_SendRoutingInfoArg_networkSignalInfo_present 0x20
    OMAP2_ISDN_AddressString msisdn;
    OMAP2_CUG_CheckInfo cug_CheckInfo;  /* optional; set in bit_mask
                            * OMAP2_SendRoutingInfoArg_cug_CheckInfo_present if
                            * present */
    OMAP2_NumberOfForwarding numberOfForwarding;  /* optional; set in bit_mask
                                          * OMAP2_numberOfForwarding_present if
                                          * present */
    OMAP2_ExternalSignalInfo networkSignalInfo;  /* optional; set in bit_mask
                        * OMAP2_SendRoutingInfoArg_networkSignalInfo_present if
                        * present */
} OMAP2_SendRoutingInfoArg;

typedef struct OMAP2_CallReferenceNumber {
    unsigned short  length;
    unsigned char   value[8];
} OMAP2_CallReferenceNumber;

typedef struct OMAP2_ISDN_SubaddressString {
    unsigned short  length;
    unsigned char   value[21];
} OMAP2_ISDN_SubaddressString;

	// bits 8765: 0000 (unused)
	// bits 4321: Used to convey the "P bit","R bit","A bit" and "Q bit",
	//		    representing supplementary service state information
	//		    as defined in TS GSM 03.11

	// bit 4: "Q bit"

	// bit 3: "P bit"

	// bit 2: "R bit"

	// bit 1: "A bit"
typedef struct OMAP2_ForwardingOptions {
    unsigned short  length;
    unsigned char   value[1];
} OMAP2_ForwardingOptions;

typedef struct OMAP2_ForwardingData {
    unsigned char   bit_mask;
#       define      OMAP2_ForwardingData_forwardedToNumber_present 0x80
#       define      OMAP2_ForwardingData_forwardedToSubaddress_present 0x40
#       define      OMAP2_ForwardingData_forwardingOptions_present 0x20
#       define      OMAP2_ForwardingData_extensionContainer_present 0x10
    OMAP2_ISDN_AddressString forwardedToNumber;  /* optional; set in bit_mask
                            * OMAP2_ForwardingData_forwardedToNumber_present if
                            * present */
	// When this datatype is sent from an HLR which supports CAMEL Phase 2
	// to a GMSC which supports CAMEL Phase 2 the GMSC shall not check the
	// format of the number
    OMAP2_ISDN_SubaddressString forwardedToSubaddress;  /* optional; set in
                                   * bit_mask
                        * OMAP2_ForwardingData_forwardedToSubaddress_present if
                        * present */
    OMAP2_ForwardingOptions forwardingOptions;  /* optional; set in bit_mask
                            * OMAP2_ForwardingData_forwardingOptions_present if
                            * present */
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                           * OMAP2_ForwardingData_extensionContainer_present if
                           * present */
} OMAP2_ForwardingData;

typedef struct OMAP2_RoutingInfo {
    unsigned short  choice;
#       define      OMAP2_RoutingInfo_roamingNumber_chosen 1
#       define      OMAP2_forwardingData_chosen 2
    union _union {
        OMAP2_ISDN_AddressString roamingNumber;  /* to choose, set choice to
                                    * OMAP2_RoutingInfo_roamingNumber_chosen */
        OMAP2_ForwardingData forwardingData;  /* to choose, set choice to
                                               * OMAP2_forwardingData_chosen */
    } u;
} OMAP2_RoutingInfo;

// exception handling:
// Only value 1 is used.
// Values in the ranges 2-127 are reserved for future use.
// If received values 2-127 shall be mapped on to value 1.
typedef struct OMAP2_SendRoutingInfoRes {
    unsigned char   bit_mask;
#       define      OMAP2_SendRoutingInfoRes_cug_CheckInfo_present 0x80
    OMAP2_IMSI      imsi;
    OMAP2_RoutingInfo routingInfo;
    OMAP2_CUG_CheckInfo cug_CheckInfo;  /* optional; set in bit_mask
                            * OMAP2_SendRoutingInfoRes_cug_CheckInfo_present if
                            * present */
   // OA1 cug-CheckInfo must be absent in version 1
} OMAP2_SendRoutingInfoRes;

typedef struct OMAP2_CCBS_Indicators {
    unsigned char   bit_mask;
#       define      OMAP2_CCBS_Indicators_ccbs_Possible_present 0x80
#       define      OMAP2_keepCCBS_CallIndicator_present 0x40
#       define      OMAP2_CCBS_Indicators_extensionContainer_present 0x20
    Nulltype        ccbs_Possible;  /* optional; set in bit_mask
                               * OMAP2_CCBS_Indicators_ccbs_Possible_present if
                               * present */
    Nulltype        keepCCBS_CallIndicator;  /* optional; set in bit_mask
                                      * OMAP2_keepCCBS_CallIndicator_present if
                                      * present */
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                          * OMAP2_CCBS_Indicators_extensionContainer_present if
                          * present */
} OMAP2_CCBS_Indicators;

typedef struct OMAP2_ProvideRoamingNumberArg {
    unsigned char   bit_mask;
#       define      OMAP2_ProvideRoamingNumberArg_msisdn_present 0x80
#       define      OMAP2_previousRoamingNumber_present 0x40
#       define      OMAP2_ProvideRoamingNumberArg_lmsi_present 0x20
#       define      OMAP2_gsm_BearerCapability_present 0x10
#       define      OMAP2_ProvideRoamingNumberArg_networkSignalInfo_present 0x08
    OMAP2_IMSI      imsi;
    OMAP2_ISDN_AddressString msc_Number;
    OMAP2_ISDN_AddressString msisdn;  /* optional; set in bit_mask
                              * OMAP2_ProvideRoamingNumberArg_msisdn_present if
                              * present */
    OMAP2_ISDN_AddressString previousRoamingNumber;  /* optional; set in
                                   * bit_mask
                                   * OMAP2_previousRoamingNumber_present if
                                   * present */
    OMAP2_LMSI      lmsi;  /* optional; set in bit_mask
                            * OMAP2_ProvideRoamingNumberArg_lmsi_present if
                            * present */
    OMAP2_ExternalSignalInfo gsm_BearerCapability;  /* optional; set in bit_mask
                                        * OMAP2_gsm_BearerCapability_present if
                                        * present */
    OMAP2_ExternalSignalInfo networkSignalInfo;  /* optional; set in bit_mask
                   * OMAP2_ProvideRoamingNumberArg_networkSignalInfo_present if
                   * present */
} OMAP2_ProvideRoamingNumberArg;

typedef struct OMAP2_ProvideRoamingNumberRes {
    unsigned char   bit_mask;
#       define      OMAP2_ProvideRoamingNumberRes_extensionContainer_present 0x80
    OMAP2_ISDN_AddressString roamingNumber;
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                  * OMAP2_ProvideRoamingNumberRes_extensionContainer_present if
                  * present */
} OMAP2_ProvideRoamingNumberRes;

typedef struct OMAP2_ResumeCallHandlingRes {
    unsigned char   bit_mask;
#       define      OMAP2_ResumeCallHandlingRes_extensionContainer_present 0x80
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                    * OMAP2_ResumeCallHandlingRes_extensionContainer_present if
                    * present */
} OMAP2_ResumeCallHandlingRes;

typedef struct OMAP2_CallDirection {
    unsigned short  length;
    unsigned char   value[1];
} OMAP2_CallDirection;

typedef struct OMAP2_ProvideSIWFSNumberArg {
    unsigned char   bit_mask;
#       define      OMAP2_lowerLayerCompatibility_present 0x80
#       define      OMAP2_highLayerCompatibility_present 0x40
#       define      OMAP2_ProvideSIWFSNumberArg_extensionContainer_present 0x20
    OMAP2_ExternalSignalInfo gsm_BearerCapability;
    OMAP2_ExternalSignalInfo isdn_BearerCapability;
    OMAP2_CallDirection call_Direction;
    OMAP2_ISDN_AddressString b_Subscriber_Address;
    OMAP2_ExternalSignalInfo chosenChannel;
    OMAP2_ExternalSignalInfo lowerLayerCompatibility;  /* optional; set in
                                   * bit_mask
                                   * OMAP2_lowerLayerCompatibility_present if
                                   * present */
    OMAP2_ExternalSignalInfo highLayerCompatibility;  /* optional; set in
                                   * bit_mask
                                   * OMAP2_highLayerCompatibility_present if
                                   * present */
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                    * OMAP2_ProvideSIWFSNumberArg_extensionContainer_present if
                    * present */
} OMAP2_ProvideSIWFSNumberArg;

     // OCTET 1

     // bit 1 (direction of call)
     // 0  Mobile Originated Call (MOC)
     // 1  Mobile Terminated Call (MTC)
typedef struct OMAP2_ProvideSIWFSNumberRes {
    unsigned char   bit_mask;
#       define      OMAP2_ProvideSIWFSNumberRes_extensionContainer_present 0x80
    OMAP2_ISDN_AddressString sIWFSNumber;
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                    * OMAP2_ProvideSIWFSNumberRes_extensionContainer_present if
                    * present */
} OMAP2_ProvideSIWFSNumberRes;

typedef struct OMAP2_SIWFSSignallingModifyArg {
    unsigned char   bit_mask;
#       define      OMAP2_channelType_present 0x80
#       define      OMAP2_SIWFSSignallingModifyArg_chosenChannel_present 0x40
#       define      OMAP2_SIWFSSignallingModifyArg_extensionContainer_present 0x20
    OMAP2_ExternalSignalInfo channelType;  /* optional; set in bit_mask
                                            * OMAP2_channelType_present if
                                            * present */
    OMAP2_ExternalSignalInfo chosenChannel;  /* optional; set in bit_mask
                      * OMAP2_SIWFSSignallingModifyArg_chosenChannel_present if
                      * present */
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                 * OMAP2_SIWFSSignallingModifyArg_extensionContainer_present if
                 * present */
} OMAP2_SIWFSSignallingModifyArg;

typedef struct OMAP2_SIWFSSignallingModifyRes {
    unsigned char   bit_mask;
#       define      OMAP2_SIWFSSignallingModifyRes_chosenChannel_present 0x80
#       define      OMAP2_SIWFSSignallingModifyRes_extensionContainer_present 0x40
    OMAP2_ExternalSignalInfo chosenChannel;  /* optional; set in bit_mask
                      * OMAP2_SIWFSSignallingModifyRes_chosenChannel_present if
                      * present */
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                 * OMAP2_SIWFSSignallingModifyRes_extensionContainer_present if
                 * present */
} OMAP2_SIWFSSignallingModifyRes;

typedef enum OMAP2_CCBS_SubscriberStatus {
    OMAP2_ccbsNotIdle = 0,
    OMAP2_ccbsIdle = 1,
    OMAP2_ccbsNotReachable = 2
} OMAP2_CCBS_SubscriberStatus;

typedef struct OMAP2_EventReportData {
    unsigned char   bit_mask;
#       define      OMAP2_ccbs_SubscriberStatus_present 0x80
#       define      OMAP2_EventReportData_extensionContainer_present 0x40
    OMAP2_CCBS_SubscriberStatus ccbs_SubscriberStatus;  /* optional; set in
                                   * bit_mask
                                   * OMAP2_ccbs_SubscriberStatus_present if
                                   * present */
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                          * OMAP2_EventReportData_extensionContainer_present if
                          * present */
} OMAP2_EventReportData;

typedef enum OMAP2_MonitoringMode {
    OMAP2_a_side = 0,
    OMAP2_b_side = 1
} OMAP2_MonitoringMode;

//	exception handling: 
//  reception of values 2-10 shall be mapped 'a-side'
//  reception of values > 10 shall be mapped to 'b-side'
typedef enum OMAP2_CallOutcome {
    OMAP2_success = 0,
    OMAP2_failure = 1,
    OMAP2_CallOutcome_busy = 2
} OMAP2_CallOutcome;

typedef struct OMAP2_CallReportData {
    unsigned char   bit_mask;
#       define      OMAP2_monitoringMode_present 0x80
#       define      OMAP2_callOutcome_present 0x40
#       define      OMAP2_CallReportData_extensionContainer_present 0x20
    OMAP2_MonitoringMode monitoringMode;  /* optional; set in bit_mask
                                           * OMAP2_monitoringMode_present if
                                           * present */
    OMAP2_CallOutcome callOutcome;  /* optional; set in bit_mask
                                     * OMAP2_callOutcome_present if present */
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                           * OMAP2_CallReportData_extensionContainer_present if
                           * present */
} OMAP2_CallReportData;

//  exception handling: 
//  reception of values 3-10 shall be mapped to 'ccbsNotIdle'
//  reception of values 11-20 shall be mapped to 'ccbsIdle'
//  reception of values > 20 shall be mapped to 'ccbsNotReachable' 
typedef struct OMAP2_StatusReportArg {
    unsigned char   bit_mask;
#       define      OMAP2_eventReportData_present 0x80
#       define      OMAP2_callReportdata_present 0x40
#       define      OMAP2_StatusReportArg_extensionContainer_present 0x20
    OMAP2_IMSI      imsi;
    OMAP2_EventReportData eventReportData;  /* optional; set in bit_mask
                                             * OMAP2_eventReportData_present if
                                             * present */
    OMAP2_CallReportData callReportdata;  /* optional; set in bit_mask
                                           * OMAP2_callReportdata_present if
                                           * present */
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                          * OMAP2_StatusReportArg_extensionContainer_present if
                          * present */
} OMAP2_StatusReportArg;

//	exception handling: 
//  reception of values 3-10 shall be mapped to 'success'
//  reception of values 11-20 shall be mapped to 'failure'
//  reception of values > 20 shall be mapped to 'busy'
typedef struct OMAP2_StatusReportRes {
    unsigned char   bit_mask;
#       define      OMAP2_StatusReportRes_extensionContainer_present 0x80
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                          * OMAP2_StatusReportRes_extensionContainer_present if
                          * present */
} OMAP2_StatusReportRes;
// exception handling:
// reception of values 6-20 shall be mapped to 'accepted'
// reception of values 21-30 shall be mapped to 'rejected'
// reception of values 31-40 shall be mapped to 'noResponseFromFreeMS'
// reception of values 41-50 shall be mapped to 'noResponseFromBusyMS'
// reception of values 51-60 shall be mapped to 'udubFromFreeMS'
// reception of values > 60 shall be mapped to 'udubFromBusyMS'

	// location registration operations
	// handover operations
	// authentication management operations
	// IMEI management operations
	// subscriber management operations
	// fault recovery operations
// location registration operations
typedef struct OMAP2_UpdateLocation {                            /*Timer m*/
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_UpdateLocation;

typedef struct OMAP2_CancelLocation {                            /*Timer m*/
			// optional
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_CancelLocation;

typedef struct OMAP2_PurgeMS {                           /*Timer m*/
			// optional
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_PurgeMS;

typedef struct OMAP2_SendIdentification {                         /*Timer s*/
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_SendIdentification;

// handover operations
typedef struct OMAP2_PrepareHandover {                           /*Timer m*/
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_PrepareHandover;

typedef struct OMAP2_SendEndSignal {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_SendEndSignal;                             /*Timer l*/

//	RESULT
typedef struct OMAP2_ProcessAccessSignalling {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_ProcessAccessSignalling;                   /*Timer s*/

typedef struct OMAP2_ForwardAccessSignalling {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_ForwardAccessSignalling;                   /*Timer s*/

typedef struct OMAP2_PrepareSubsequentHandover {                 /*Timer m*/
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_PrepareSubsequentHandover;

// authentication management operations
typedef struct OMAP2_SendAuthenticationInfo {                    /*Timer m*/
		// optional
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_SendAuthenticationInfo;

// IMEI management operations
typedef struct OMAP2_CheckIMEI {                         /*Timer m*/
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_CheckIMEI;

// subscriber management operations
typedef struct OMAP2_InsertSubscriberData {                              /*Timer m*/
		// optional
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_InsertSubscriberData;

typedef struct OMAP2_DeleteSubscriberData {                              /*Timer m*/
		// optional
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_DeleteSubscriberData;

// fault recovery operations
typedef struct OMAP2_Reset {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_Reset;                             /*Timer m*/

typedef struct OMAP2_RestoreData {                               /*Timer m*/
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_RestoreData;

typedef struct OMAP2_RegisterPasswordArg {
    unsigned short  length;
    unsigned char   value[1];
} OMAP2_RegisterPasswordArg;

typedef struct OMAP2_TeleserviceCode {
    unsigned short  length;
    unsigned char   value[1];
} OMAP2_TeleserviceCode;

	// The internal structure is defined by the Carrier Identification
	// parameter in ANSI T1.113.3. Carrier codes between "000" and "999" may
	// be encoded as 3 digits using "000" to "999" or as 4 digits using 
	// "0000" to "0999". Carrier codes between "1000" and "9999" are encoded
	// using 4 digits.

// data types for subscriber management
typedef struct OMAP2_BasicServiceCode {
    unsigned short  choice;
#       define      OMAP2_bearerService_chosen 1
#       define      OMAP2_teleservice_chosen 2
    union _union {
        OMAP2_BearerServiceCode bearerService;  /* to choose, set choice to
                                                * OMAP2_bearerService_chosen */
        OMAP2_TeleserviceCode teleservice;  /* to choose, set choice to
                                             * OMAP2_teleservice_chosen */
    } u;
} OMAP2_BasicServiceCode;

typedef unsigned short  OMAP2_NoReplyConditionTime;

typedef unsigned short  OMAP2_MC_Bearers;

typedef struct OMAP2_RegisterSSArg {
    unsigned char   bit_mask;
#       define      OMAP2_RegisterSSArg_basicService_present 0x80
#       define      OMAP2_RegisterSSArg_forwardedToNumber_present 0x40
#       define      OMAP2_RegisterSSArg_forwardedToSubaddress_present 0x20
#       define      OMAP2_RegisterSSArg_noReplyConditionTime_present 0x10
#       define      OMAP2_RegisterSSArg_defaultPriority_present 0x08
#       define      OMAP2_RegisterSSArg_nbrUser_present 0x04
#       define      OMAP2_RegisterSSArg_longFTN_Supported_present 0x02
    OMAP2_SS_Code   ss_Code;
    OMAP2_BasicServiceCode basicService;  /* optional; set in bit_mask
                                  * OMAP2_RegisterSSArg_basicService_present if
                                  * present */
    OMAP2_AddressString forwardedToNumber;  /* optional; set in bit_mask
                             * OMAP2_RegisterSSArg_forwardedToNumber_present if
                             * present */
    OMAP2_ISDN_SubaddressString forwardedToSubaddress;  /* optional; set in
                                   * bit_mask
                         * OMAP2_RegisterSSArg_forwardedToSubaddress_present if
                         * present */
   // OA1 forwardedToSubaddress must be absent in version 1
    OMAP2_NoReplyConditionTime noReplyConditionTime;  /* optional; set in
                                   * bit_mask
                          * OMAP2_RegisterSSArg_noReplyConditionTime_present if
                          * present */
    OMAP2_EMLPP_Priority defaultPriority;  /* extension #1; optional; set in
                                   * bit_mask
                                   * OMAP2_RegisterSSArg_defaultPriority_present
                                   * if present */
    OMAP2_MC_Bearers nbrUser;  /* extension #2; optional; set in bit_mask
                                * OMAP2_RegisterSSArg_nbrUser_present if
                                * present */
    Nulltype        longFTN_Supported;  /* extension #3; optional; set in
                                   * bit_mask
                             * OMAP2_RegisterSSArg_longFTN_Supported_present if
                             * present */
} OMAP2_RegisterSSArg;

typedef unsigned short  OMAP2_SS_DataTypes_CUG_Index;

   // The internal structure is defined in ETS 300 138.
typedef struct OMAP2_SS_DataTypes_CUG_Interlock {
    unsigned short  length;
    unsigned char   value[4];
} OMAP2_SS_DataTypes_CUG_Interlock;

typedef enum OMAP2_SS_DataTypes_IntraCUG_Options {
    OMAP2_SS_DataTypes_IntraCUG_Options_noCUG_Restrictions = 0,
    OMAP2_SS_DataTypes_IntraCUG_Options_cugIC_CallBarred = 1,
    OMAP2_SS_DataTypes_IntraCUG_Options_cugOG_CallBarred = 2
} OMAP2_SS_DataTypes_IntraCUG_Options;

typedef struct OMAP2_BasicServiceGroupList {
    unsigned short  count;
    OMAP2_BasicServiceCode value[13];
} OMAP2_BasicServiceGroupList;

typedef struct OMAP2_SS_DataTypes_CUG_Subscription {
    unsigned char   bit_mask;
#       define      OMAP2_SS_DataTypes_CUG_Subscription_basicServiceGroupList_present 0x80
    OMAP2_SS_DataTypes_CUG_Index cug_Index;
    OMAP2_SS_DataTypes_CUG_Interlock cug_Interlock;
    OMAP2_SS_DataTypes_IntraCUG_Options intraCUG_Options;
    OMAP2_BasicServiceGroupList basicServiceGroupList;  /* optional; set in
                                   * bit_mask
         * OMAP2_SS_DataTypes_CUG_Subscription_basicServiceGroupList_present if
         * present */
} OMAP2_SS_DataTypes_CUG_Subscription;

typedef struct OMAP2_SS_DataTypes_CUG_SubscriptionList {
    unsigned short  count;
    OMAP2_SS_DataTypes_CUG_Subscription value[10];
} OMAP2_SS_DataTypes_CUG_SubscriptionList;

typedef struct OMAP2_SS_DataTypes_InterCUG_Restrictions {
    unsigned short  length;
    unsigned char   value[1];
} OMAP2_SS_DataTypes_InterCUG_Restrictions;

typedef struct OMAP2_SS_DataTypes_CUG_Feature {
    unsigned char   bit_mask;
#       define      OMAP2_SS_DataTypes_CUG_Feature_basicService_present 0x80
#       define      OMAP2_SS_DataTypes_CUG_Feature_preferentialCUG_Indicator_present 0x40
    OMAP2_BasicServiceCode basicService;  /* optional; set in bit_mask
                       * OMAP2_SS_DataTypes_CUG_Feature_basicService_present if
                       * present */
    OMAP2_SS_DataTypes_CUG_Index preferentialCUG_Indicator;  /* optional; set in
                                   * bit_mask
          * OMAP2_SS_DataTypes_CUG_Feature_preferentialCUG_Indicator_present if
          * present */
    OMAP2_SS_DataTypes_InterCUG_Restrictions interCUG_Restrictions;
} OMAP2_SS_DataTypes_CUG_Feature;

typedef struct OMAP2_SS_DataTypes_CUG_FeatureList {
    unsigned short  count;
    OMAP2_SS_DataTypes_CUG_Feature value[13];
} OMAP2_SS_DataTypes_CUG_FeatureList;

typedef struct OMAP2_SS_DataTypes_CUG_Info {
    unsigned char   bit_mask;
#       define      OMAP2_SS_DataTypes_CUG_Info_cug_FeatureList_present 0x80
    OMAP2_SS_DataTypes_CUG_SubscriptionList cug_SubscriptionList;
    OMAP2_SS_DataTypes_CUG_FeatureList cug_FeatureList;  /* optional; set in
                                   * bit_mask
                       * OMAP2_SS_DataTypes_CUG_Info_cug_FeatureList_present if
                       * present */
} OMAP2_SS_DataTypes_CUG_Info;

typedef struct OMAP2_SS_Status {
    unsigned short  length;
    unsigned char   value[1];
} OMAP2_SS_Status;

typedef struct OMAP2_FTN_AddressString {
    unsigned short  length;
    unsigned char   value[15];
} OMAP2_FTN_AddressString;

typedef struct OMAP2_ForwardingFeature {
    unsigned char   bit_mask;
#       define      OMAP2_ForwardingFeature_basicService_present 0x80
#       define      OMAP2_ForwardingFeature_ss_Status_present 0x40
#       define      OMAP2_ForwardingFeature_forwardedToNumber_present 0x20
#       define      OMAP2_ForwardingFeature_forwardedToSubaddress_present 0x10
#       define      OMAP2_ForwardingFeature_forwardingOptions_present 0x08
#       define      OMAP2_ForwardingFeature_noReplyConditionTime_present 0x04
#       define      OMAP2_longForwardedToNumber_present 0x02
    OMAP2_BasicServiceCode basicService;  /* optional; set in bit_mask
                              * OMAP2_ForwardingFeature_basicService_present if
                              * present */
    OMAP2_SS_Status ss_Status;  /* optional; set in bit_mask
                                 * OMAP2_ForwardingFeature_ss_Status_present if
                                 * present */
    OMAP2_ISDN_AddressString forwardedToNumber;  /* optional; set in bit_mask
                         * OMAP2_ForwardingFeature_forwardedToNumber_present if
                         * present */
    OMAP2_ISDN_SubaddressString forwardedToSubaddress;  /* optional; set in
                                   * bit_mask
                     * OMAP2_ForwardingFeature_forwardedToSubaddress_present if
                     * present */
    OMAP2_ForwardingOptions forwardingOptions;  /* optional; set in bit_mask
                         * OMAP2_ForwardingFeature_forwardingOptions_present if
                         * present */
    OMAP2_NoReplyConditionTime noReplyConditionTime;  /* optional; set in
                                   * bit_mask
                      * OMAP2_ForwardingFeature_noReplyConditionTime_present if
                      * present */
    OMAP2_FTN_AddressString longForwardedToNumber;  /* extension #1; optional;
                                   * set in bit_mask
                                   * OMAP2_longForwardedToNumber_present if
                                   * present */
} OMAP2_ForwardingFeature;

typedef struct OMAP2_ForwardingFeatureList {
    unsigned short  count;
    OMAP2_ForwardingFeature value[13];
} OMAP2_ForwardingFeatureList;

typedef struct OMAP2_ForwardingInfo {
    unsigned char   bit_mask;
#       define      OMAP2_ForwardingInfo_ss_Code_present 0x80
    OMAP2_SS_Code   ss_Code;  /* optional; set in bit_mask
                               * OMAP2_ForwardingInfo_ss_Code_present if
                               * present */
    OMAP2_ForwardingFeatureList forwardingFeatureList;
} OMAP2_ForwardingInfo;

typedef struct OMAP2_CallBarringFeature {
    unsigned char   bit_mask;
#       define      OMAP2_CallBarringFeature_basicService_present 0x80
#       define      OMAP2_CallBarringFeature_ss_Status_present 0x40
    OMAP2_BasicServiceCode basicService;  /* optional; set in bit_mask
                             * OMAP2_CallBarringFeature_basicService_present if
                             * present */
    OMAP2_SS_Status ss_Status;  /* optional; set in bit_mask
                                 * OMAP2_CallBarringFeature_ss_Status_present if
                                 * present */
} OMAP2_CallBarringFeature;

typedef struct OMAP2_CallBarringFeatureList {
    unsigned short  count;
    OMAP2_CallBarringFeature value[13];
} OMAP2_CallBarringFeatureList;

	// bit 8: notification to forwarding party
	//	0  no notification
	//	1  notification

	// bit 7: 0 (unused)

	// bit 6: notification to calling party
	//	0  no notification
	//	1  notification

	// bit 5: 0 (unused)

	// bits 43: forwarding reason
	//	00  ms not reachable
	//	01  ms busy
	//	10  no reply
	//	11  unconditional
	// bits 21: 00 (unused)
typedef struct OMAP2_CallBarringInfo {
    unsigned char   bit_mask;
#       define      OMAP2_CallBarringInfo_ss_Code_present 0x80
    OMAP2_SS_Code   ss_Code;  /* optional; set in bit_mask
                               * OMAP2_CallBarringInfo_ss_Code_present if
                               * present */
    OMAP2_CallBarringFeatureList callBarringFeatureList;
} OMAP2_CallBarringInfo;

typedef enum OMAP2_CliRestrictionOption {
    OMAP2_permanent = 0,
    OMAP2_temporaryDefaultRestricted = 1,
    OMAP2_temporaryDefaultAllowed = 2
} OMAP2_CliRestrictionOption;

typedef enum OMAP2_OverrideCategory {
    OMAP2_overrideEnabled = 0,
    OMAP2_overrideDisabled = 1
} OMAP2_OverrideCategory;

typedef struct OMAP2_SS_SubscriptionOption {
    unsigned short  choice;
#       define      OMAP2_cliRestrictionOption_chosen 1
#       define      OMAP2_overrideCategory_chosen 2
    union _union {
        OMAP2_CliRestrictionOption cliRestrictionOption;  /* to choose, set
                                   * choice to
                                   * OMAP2_cliRestrictionOption_chosen */
        OMAP2_OverrideCategory overrideCategory;  /* to choose, set choice to
                                             * OMAP2_overrideCategory_chosen */
    } u;
} OMAP2_SS_SubscriptionOption;

typedef unsigned short  OMAP2_CCBS_Index;

typedef struct OMAP2_CCBS_Feature {
    unsigned char   bit_mask;
#       define      OMAP2_ccbs_Index_present 0x80
#       define      OMAP2_b_subscriberNumber_present 0x40
#       define      OMAP2_b_subscriberSubaddress_present 0x20
#       define      OMAP2_basicServiceGroup_present 0x10
    OMAP2_CCBS_Index ccbs_Index;  /* optional; set in bit_mask
                                   * OMAP2_ccbs_Index_present if present */
    OMAP2_ISDN_AddressString b_subscriberNumber;  /* optional; set in bit_mask
                                          * OMAP2_b_subscriberNumber_present if
                                          * present */
    OMAP2_ISDN_SubaddressString b_subscriberSubaddress;  /* optional; set in
                                   * bit_mask
                                   * OMAP2_b_subscriberSubaddress_present if
                                   * present */
    OMAP2_BasicServiceCode basicServiceGroup;  /* optional; set in bit_mask
                                           * OMAP2_basicServiceGroup_present if
                                           * present */
} OMAP2_CCBS_Feature;

typedef struct OMAP2_SS_Data {
    unsigned char   bit_mask;
#       define      OMAP2_SS_Data_ss_Code_present 0x80
#       define      OMAP2_SS_Data_ss_Status_present 0x40
#       define      OMAP2_SS_Data_ss_SubscriptionOption_present 0x20
#       define      OMAP2_SS_Data_basicServiceGroupList_present 0x10
#       define      OMAP2_SS_Data_defaultPriority_present 0x08
#       define      OMAP2_ccbs_Feature_present 0x04
#       define      OMAP2_SS_Data_nbrUser_present 0x02
    OMAP2_SS_Code   ss_Code;  /* optional; set in bit_mask
                               * OMAP2_SS_Data_ss_Code_present if present */
    OMAP2_SS_Status ss_Status;  /* optional; set in bit_mask
                                 * OMAP2_SS_Data_ss_Status_present if present */
    OMAP2_SS_SubscriptionOption ss_SubscriptionOption;  /* optional; set in
                                   * bit_mask
                                   * OMAP2_SS_Data_ss_SubscriptionOption_present
                                   * if present */
    OMAP2_BasicServiceGroupList basicServiceGroupList;  /* optional; set in
                                   * bit_mask
                                   * OMAP2_SS_Data_basicServiceGroupList_present
                                   * if present */
    OMAP2_EMLPP_Priority defaultPriority;  /* extension #1; optional; set in
                                   * bit_mask
                                   * OMAP2_SS_Data_defaultPriority_present if
                                   * present */
    OMAP2_CCBS_Feature ccbs_Feature;  /* extension #2; optional; set in bit_mask
                                       * OMAP2_ccbs_Feature_present if
                                       * present */
    OMAP2_MC_Bearers nbrUser;  /* extension #3; optional; set in bit_mask
                                * OMAP2_SS_Data_nbrUser_present if present */
} OMAP2_SS_Data;

   // bits 876543: 000000 (unused)

   // bits 21
   // 00  CUG only facilities
   // 01  CUG with outgoing access
   // 10  CUG with incoming access
   // 11  CUG with both outgoing and incoming access
typedef struct OMAP2_SS_Info {
    unsigned short  choice;
#       define      OMAP2_SS_Info_forwardingInfo_chosen 1
#       define      OMAP2_SS_Info_callBarringInfo_chosen 2
#       define      OMAP2_SS_Info_cug_Info_chosen 3
#       define      OMAP2_SS_Info_ss_Data_chosen 4
    union _union {
        OMAP2_ForwardingInfo forwardingInfo;  /* to choose, set choice to
                                       * OMAP2_SS_Info_forwardingInfo_chosen */
        OMAP2_CallBarringInfo callBarringInfo;  /* to choose, set choice to
                                      * OMAP2_SS_Info_callBarringInfo_chosen */
        OMAP2_SS_DataTypes_CUG_Info cug_Info;  /* to choose, set choice to
                                             * OMAP2_SS_Info_cug_Info_chosen */
   // NU1 cug-info must not be used in version 1
        OMAP2_SS_Data   ss_Data;  /* to choose, set choice to
                                   * OMAP2_SS_Info_ss_Data_chosen */
    } u;
} OMAP2_SS_Info;

typedef OMAP2_SS_Info   OMAP2_DeactivateSSRes;

typedef OMAP2_SS_Info   OMAP2_ActivateSSRes;

typedef OMAP2_SS_Info   OMAP2_EraseSSRes;

typedef OMAP2_SS_Info   OMAP2_RegisterSSRes;

typedef struct OMAP2_SS_ForBS_Code {
    unsigned char   bit_mask;
#       define      OMAP2_SS_ForBS_Code_basicService_present 0x80
    OMAP2_SS_Code   ss_Code;
    OMAP2_BasicServiceCode basicService;  /* optional; set in bit_mask
                                  * OMAP2_SS_ForBS_Code_basicService_present if
                                  * present */
} OMAP2_SS_ForBS_Code;

typedef struct OMAP2_InterrogateSSArg {
    unsigned char   bit_mask;
#       define      OMAP2_InterrogateSSArg_basicService_present 0x80
#       define      OMAP2_InterrogateSSArg_longFTN_Supported_present 0x40
    OMAP2_SS_Code   ss_Code;
    OMAP2_BasicServiceCode basicService;  /* optional; set in bit_mask
                               * OMAP2_InterrogateSSArg_basicService_present if
                               * present */
    Nulltype        longFTN_Supported;  /* extension #1; optional; set in
                                   * bit_mask
                          * OMAP2_InterrogateSSArg_longFTN_Supported_present if
                          * present */
} OMAP2_InterrogateSSArg; // added longFTN-Supported on 28-jan-2015

typedef struct OMAP2_DeactivateSSArg {
    unsigned char   bit_mask;
#       define      OMAP2_DeactivateSSArg_basicService_present 0x80
#       define      OMAP2_DeactivateSSArg_longFTN_Supported_present 0x40
    OMAP2_SS_Code   ss_Code;
    OMAP2_BasicServiceCode basicService;  /* optional; set in bit_mask
                                * OMAP2_DeactivateSSArg_basicService_present if
                                * present */
    Nulltype        longFTN_Supported;  /* extension #1; optional; set in
                                   * bit_mask
                           * OMAP2_DeactivateSSArg_longFTN_Supported_present if
                           * present */
} OMAP2_DeactivateSSArg; // added longFTN-Supported on 28-jan-2015

typedef struct OMAP2_ActivateSSArg {
    unsigned char   bit_mask;
#       define      OMAP2_ActivateSSArg_basicService_present 0x80
#       define      OMAP2_ActivateSSArg_longFTN_Supported_present 0x40
    OMAP2_SS_Code   ss_Code;
    OMAP2_BasicServiceCode basicService;  /* optional; set in bit_mask
                                  * OMAP2_ActivateSSArg_basicService_present if
                                  * present */
    Nulltype        longFTN_Supported;  /* extension #1; optional; set in
                                   * bit_mask
                             * OMAP2_ActivateSSArg_longFTN_Supported_present if
                             * present */
} OMAP2_ActivateSSArg; // added longFTN-Supported on 28-jan-2015

typedef struct OMAP2_EraseSSArg {
    unsigned char   bit_mask;
#       define      OMAP2_EraseSSArg_basicService_present 0x80
#       define      OMAP2_EraseSSArg_longFTN_Supported_present 0x40
    OMAP2_SS_Code   ss_Code;
    OMAP2_BasicServiceCode basicService;  /* optional; set in bit_mask
                                     * OMAP2_EraseSSArg_basicService_present if
                                     * present */
    Nulltype        longFTN_Supported;  /* extension #1; optional; set in
                                   * bit_mask
                                   * OMAP2_EraseSSArg_longFTN_Supported_present
                                   * if present */
} OMAP2_EraseSSArg; // added longFTN-Supported on 28-jan-2015

typedef struct OMAP2_CCBS_FeatureList {
    unsigned short  count;
    OMAP2_CCBS_Feature value[5];
} OMAP2_CCBS_FeatureList;

	// The mapping from the values A,B,0,1,2,3,4 to the integer-value is
	// specified as follows where A is the highest and 4 is the lowest
	// priority level
	// the integer values 7-15 are spare and shall be mapped to value 4
typedef unsigned short  OMAP2_MaxMC_Bearers;

typedef struct OMAP2_GenericServiceInfo {
    unsigned char   bit_mask;
#       define      OMAP2_cliRestrictionOption_present 0x80
#       define      OMAP2_maximumEntitledPriority_present 0x40
#       define      OMAP2_GenericServiceInfo_defaultPriority_present 0x20
#       define      OMAP2_ccbs_FeatureList_present 0x10
#       define      OMAP2_nbrSB_present 0x08
#       define      OMAP2_GenericServiceInfo_nbrUser_present 0x04
#       define      OMAP2_nbrSN_present 0x02
    OMAP2_SS_Status ss_Status;
    OMAP2_CliRestrictionOption cliRestrictionOption;  /* optional; set in
                                   * bit_mask OMAP2_cliRestrictionOption_present
                                   * if present */
    OMAP2_EMLPP_Priority maximumEntitledPriority;  /* extension #1; optional;
                                   * set in bit_mask
                                   * OMAP2_maximumEntitledPriority_present if
                                   * present */
    OMAP2_EMLPP_Priority defaultPriority;  /* extension #2; optional; set in
                                   * bit_mask
                          * OMAP2_GenericServiceInfo_defaultPriority_present if
                          * present */
    OMAP2_CCBS_FeatureList ccbs_FeatureList;  /* extension #3; optional; set in
                                   * bit_mask OMAP2_ccbs_FeatureList_present if
                                   * present */
    OMAP2_MaxMC_Bearers nbrSB;  /* extension #4; optional; set in bit_mask
                                 * OMAP2_nbrSB_present if present */
    OMAP2_MC_Bearers nbrUser;  /* extension #5; optional; set in bit_mask
                                * OMAP2_GenericServiceInfo_nbrUser_present if
                                * present */
    OMAP2_MC_Bearers nbrSN;  /* extension #6; optional; set in bit_mask
                              * OMAP2_nbrSN_present if present */
} OMAP2_GenericServiceInfo;

typedef struct OMAP2_InterrogateSSRes {
    unsigned short  choice;
#       define      OMAP2_ss_Status_chosen 1
#       define      OMAP2_basicServiceGroupList_chosen 2
#       define      OMAP2_forwardingFeatureList_chosen 3
#       define      OMAP2_genericServiceInfo_chosen 4
    union _union {
        OMAP2_SS_Status ss_Status;  /* to choose, set choice to
                                     * OMAP2_ss_Status_chosen */
        OMAP2_BasicServiceGroupList basicServiceGroupList;  /* to choose, set
                                   * choice to
                                   * OMAP2_basicServiceGroupList_chosen */
        OMAP2_ForwardingFeatureList forwardingFeatureList;  /* to choose, set
                                   * choice to
                                   * OMAP2_forwardingFeatureList_chosen */
        OMAP2_GenericServiceInfo genericServiceInfo;  /* to choose, set choice
                                        * to OMAP2_genericServiceInfo_chosen */
    } u;
} OMAP2_InterrogateSSRes;

typedef struct OMAP2_USSD_DataCodingScheme {
    unsigned short  length;
    unsigned char   value[1];
} OMAP2_USSD_DataCodingScheme;

	// The structure of the USSD-DataCodingScheme is defined by
	// the Cell Broadcast Data Coding Scheme as described in
	// TS GSM 03.38
typedef struct OMAP2_USSD_String {
    unsigned short  length;
    unsigned char   value[160];
} OMAP2_USSD_String;

typedef struct OMAP2_AlertingPattern {
    unsigned short  length;
    unsigned char   value[1];
} OMAP2_AlertingPattern;

typedef struct OMAP2_USSD_Arg {
    unsigned char   bit_mask;
#       define      OMAP2_USSD_Arg_alertingPattern_present 0x80
    OMAP2_USSD_DataCodingScheme ussd_DataCodingScheme;
    OMAP2_USSD_String ussd_String;
    OMAP2_AlertingPattern alertingPattern;  /* extension #1; optional; set in
                                   * bit_mask
                                   * OMAP2_USSD_Arg_alertingPattern_present if
                                   * present */
} OMAP2_USSD_Arg;

typedef struct OMAP2_UnstructuredSS_NotifyArg {
    unsigned char   bit_mask;
#       define      OMAP2_UnstructuredSS_NotifyArg_alertingPattern_present 0x80
#       define      OMAP2_UnstructuredSS_NotifyArg_msisdn_present 0x40
    OMAP2_USSD_DataCodingScheme ussd_DataCodingScheme;
    OMAP2_USSD_String ussd_String;
    OMAP2_AlertingPattern alertingPattern;  /* extension #1; optional; set in
                                   * bit_mask
                    * OMAP2_UnstructuredSS_NotifyArg_alertingPattern_present if
                    * present */
    OMAP2_ISDN_AddressString msisdn;  /* extension #2; optional; set in bit_mask
                             * OMAP2_UnstructuredSS_NotifyArg_msisdn_present if
                             * present */
} OMAP2_UnstructuredSS_NotifyArg; // added msisdn for an issue on 28-jan-2015

typedef struct OMAP2_UnstructuredSS_RequestArg {
    unsigned char   bit_mask;
#       define      OMAP2_UnstructuredSS_RequestArg_alertingPattern_present 0x80
#       define      OMAP2_UnstructuredSS_RequestArg_msisdn_present 0x40
    OMAP2_USSD_DataCodingScheme ussd_DataCodingScheme;
    OMAP2_USSD_String ussd_String;
    OMAP2_AlertingPattern alertingPattern;  /* extension #1; optional; set in
                                   * bit_mask
                   * OMAP2_UnstructuredSS_RequestArg_alertingPattern_present if
                   * present */
    OMAP2_ISDN_AddressString msisdn;  /* extension #2; optional; set in bit_mask
                            * OMAP2_UnstructuredSS_RequestArg_msisdn_present if
                            * present */
} OMAP2_UnstructuredSS_RequestArg; // added msisdn for an issue on 28-jan-2015

typedef struct OMAP2_ProcessUnstructuredSS_RequestArg {
    unsigned char   bit_mask;
#       define      OMAP2_ProcessUnstructuredSS_RequestArg_alertingPattern_present 0x80
#       define      OMAP2_ProcessUnstructuredSS_RequestArg_msisdn_present 0x40
    OMAP2_USSD_DataCodingScheme ussd_DataCodingScheme;
    OMAP2_USSD_String ussd_String;
    OMAP2_AlertingPattern alertingPattern;  /* extension #1; optional; set in
                                   * bit_mask
            * OMAP2_ProcessUnstructuredSS_RequestArg_alertingPattern_present if
            * present */
    OMAP2_ISDN_AddressString msisdn;  /* extension #2; optional; set in bit_mask
                     * OMAP2_ProcessUnstructuredSS_RequestArg_msisdn_present if
                     * present */
} OMAP2_ProcessUnstructuredSS_RequestArg; // added msisdn for an issue on 23-jan-2015

typedef struct OMAP2_USSD_Res {
    OMAP2_USSD_DataCodingScheme ussd_DataCodingScheme;
    OMAP2_USSD_String ussd_String;
} OMAP2_USSD_Res;

typedef struct OMAP2_UnstructuredSS_RequestRes {
    OMAP2_USSD_DataCodingScheme ussd_DataCodingScheme;
    OMAP2_USSD_String ussd_String;
} OMAP2_UnstructuredSS_RequestRes;

typedef struct OMAP2_ProcessUnstructuredSS_RequestRes {
    OMAP2_USSD_DataCodingScheme ussd_DataCodingScheme;
    OMAP2_USSD_String ussd_String;
} OMAP2_ProcessUnstructuredSS_RequestRes;

typedef struct OMAP2_SS_List {
    unsigned short  count;
    OMAP2_SS_Code   value[30];
} OMAP2_SS_List;

typedef struct OMAP2_SS_InfoList {
    unsigned short  count;
    OMAP2_SS_Info   value[30];
} OMAP2_SS_InfoList;

typedef struct OMAP2_SS_EventSpecification {
    unsigned short  count;
    OMAP2_AddressString value[2];
} OMAP2_SS_EventSpecification;

typedef struct OMAP2_ServiceIndicator {
    unsigned short  length;  /* number of significant bits */
    unsigned char   value[4];
} OMAP2_ServiceIndicator;
// exception handling:
// bits 2 to 31 shall be ignored if received and not understood
#define                     OMAP2_clir_invoked 0x80
#define                     OMAP2_clir_invoked_byte 0
#define                     OMAP2_camel_invoked 0x40
#define                     OMAP2_camel_invoked_byte 0

typedef struct OMAP2_CCBS_Data {
    unsigned char   bit_mask;
#       define      OMAP2_serviceIndicator_present 0x80
    OMAP2_CCBS_Feature ccbs_Feature;
    OMAP2_ISDN_AddressString translatedB_Number;
    OMAP2_ServiceIndicator serviceIndicator;  /* optional; set in bit_mask
                                               * OMAP2_serviceIndicator_present
                                               * if present */
    OMAP2_ExternalSignalInfo callInfo;
    OMAP2_ExternalSignalInfo networkSignalInfo;
} OMAP2_CCBS_Data;

	// digits of VGCS/VBC-area,Group-ID are concatenated in this order.
typedef struct OMAP2_TMSI {
    unsigned short  length;
    unsigned char   value[4];
} OMAP2_TMSI;

typedef struct OMAP2_SubscriberId {
    unsigned short  choice;
#       define      OMAP2_SubscriberId_imsi_chosen 1
#       define      OMAP2_tmsi_chosen 2
    union _union {
        OMAP2_IMSI      imsi;  /* to choose, set choice to
                                * OMAP2_SubscriberId_imsi_chosen */
        OMAP2_TMSI      tmsi;  /* to choose, set choice to OMAP2_tmsi_chosen */
    } u;
} OMAP2_SubscriberId;

typedef struct OMAP2_IMEI {
    unsigned short  length;
    unsigned char   value[8];
} OMAP2_IMEI;

	//	Refers to International Mobile Station Equipment Identity
	//	and Software Version Number (SVN) defined in TS GSM 03.03.
	//	If the SVN is not present the last octet shall contain the
	//	digit 0 and a filler.
	//	If present the SVN shall be included in the last octet.
typedef OMAP2_IMSI      OMAP2_HLR_Id;

	// leading digits of IMSI, i.e. (MCC, MNC, leading digits of
	// MSIN) forming HLR Id defined in TS GSM 03.03.
typedef struct OMAP2_HLR_List {
    unsigned short  count;
    OMAP2_HLR_Id    value[50];
} OMAP2_HLR_List;

typedef struct OMAP2_GlobalCellId {
    unsigned short  length;
    unsigned char   value[7];
} OMAP2_GlobalCellId;

	// Refers to Cell Global Identification defined in TS GSM 03.03.
	// Octets are coded according to TS GSM 04.08.
	// The internal structure is defined as follows:
	//	Mobile Country Code:	3 digits according to CCITT Rec E.212
	//			1 digit filler (1111)
	//	Mobile Network Code:	2 digits according to CCITT Rec E.212
	//	Location Area Code:	2 octets according to TS GSM 04.08
	//	Cell Identity:	2 octets (CI) according to TS GSM 04.08
typedef enum OMAP2_NetworkResource {
    OMAP2_plmn = 0,
    OMAP2_hlr = 1,
    OMAP2_vlr = 2,
    OMAP2_pvlr = 3,
    OMAP2_controllingMSC = 4,
    OMAP2_vmsc = 5,
    OMAP2_eir = 6,
    OMAP2_rss = 7
} OMAP2_NetworkResource;

typedef struct OMAP2_NAEA_CIC {
    unsigned short  length;
    unsigned char   value[3];
} OMAP2_NAEA_CIC;

typedef struct OMAP2_NAEA_PreferredCI {
    unsigned char   bit_mask;
#       define      OMAP2_NAEA_PreferredCI_extensionContainer_present 0x80
    OMAP2_NAEA_CIC  naea_PreferredCIC;
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                         * OMAP2_NAEA_PreferredCI_extensionContainer_present if
                         * present */
} OMAP2_NAEA_PreferredCI;

typedef struct OMAP2_Ext_BasicServiceCode {
    unsigned short  choice;
#       define      OMAP2_ext_BearerService_chosen 1
#       define      OMAP2_ext_Teleservice_chosen 2
    union _union {
        OMAP2_Ext_BearerServiceCode ext_BearerService;  /* to choose, set choice
                                         * to OMAP2_ext_BearerService_chosen */
        OMAP2_Ext_TeleserviceCode ext_Teleservice;  /* to choose, set choice to
                                              * OMAP2_ext_Teleservice_chosen */
    } u;
} OMAP2_Ext_BasicServiceCode;

typedef struct OMAP2_EMLPP_Info {
    unsigned char   bit_mask;
#       define      OMAP2_EMLPP_Info_extensionContainer_present 0x80
    OMAP2_EMLPP_Priority maximumentitledPriority;
    OMAP2_EMLPP_Priority defaultPriority;
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                               * OMAP2_EMLPP_Info_extensionContainer_present if
                               * present */
} OMAP2_EMLPP_Info;

	// location registration types
	// handover types
	// authentication management types
	// security management types
	// subscriber management types
	// fault recovery types
	// subscriber information enquiry types
typedef struct OMAP2_UpdateLocationArg {
    unsigned char   bit_mask;
#       define      OMAP2_UpdateLocationArg_lmsi_present 0x80
#       define      OMAP2_UpdateLocationArg_extensionContainer_present 0x40
    OMAP2_IMSI      imsi;
    OMAP2_ISDN_AddressString msc_Number;
    OMAP2_ISDN_AddressString vlr_Number;
    OMAP2_LMSI      lmsi;  /* optional; set in bit_mask
                            * OMAP2_UpdateLocationArg_lmsi_present if present */
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                        * OMAP2_UpdateLocationArg_extensionContainer_present if
                        * present */
} OMAP2_UpdateLocationArg;

//UpdateLocationRes ::= SEQUENCE {
//	hlr-Number	ISDN-AddressString,
//	extensionContainer	ExtensionContainer	OPTIONAL,
//	...}
typedef struct OMAP2_ExtensibleUpdateLocationRes {
    OMAP2_ISDN_AddressString hlr_Number;
} OMAP2_ExtensibleUpdateLocationRes;

typedef struct OMAP2_UpdateLocationRes {
    unsigned short  choice;
#       define      OMAP2_hlr_Number_chosen 1
#       define      OMAP2_extensibleUpdateLocationRes_chosen 2
    union _union {
        OMAP2_ISDN_AddressString hlr_Number;  /* to choose, set choice to
                                               * OMAP2_hlr_Number_chosen */
                                              // NU1 hlr-Number must not be used in version greater 1
        OMAP2_ExtensibleUpdateLocationRes extensibleUpdateLocationRes;  /* to
                                   * choose, set choice to
                                  * OMAP2_extensibleUpdateLocationRes_chosen */
                                                                        // NU1 extensibleUpdateLocationRes must not be used in version 1
    } u;
} OMAP2_UpdateLocationRes;

typedef struct OMAP2_IMSI_WithLMSI {
    OMAP2_IMSI      imsi;
    OMAP2_LMSI      lmsi;
	// a special value 00000000 indicates that the LMSI is not in use
} OMAP2_IMSI_WithLMSI;

typedef struct OMAP2_CancelLocationArg {
    unsigned short  choice;
#       define      OMAP2_CancelLocationArg_imsi_chosen 1
#       define      OMAP2_CancelLocationArg_imsi_WithLMSI_chosen 2
    union _union {
        OMAP2_IMSI      imsi;  /* to choose, set choice to
                                * OMAP2_CancelLocationArg_imsi_chosen */
        OMAP2_IMSI_WithLMSI imsi_WithLMSI;  /* to choose, set choice to
                              * OMAP2_CancelLocationArg_imsi_WithLMSI_chosen */
    } u;
} OMAP2_CancelLocationArg;

typedef struct OMAP2_Indentity {
    unsigned short  choice;
#       define      OMAP2_Indentity_imsi_chosen 1
#       define      OMAP2_Indentity_imsi_WithLMSI_chosen 2
    union _union {
        OMAP2_IMSI      imsi;  /* to choose, set choice to
                                * OMAP2_Indentity_imsi_chosen */
        OMAP2_IMSI_WithLMSI imsi_WithLMSI;  /* to choose, set choice to
                                      * OMAP2_Indentity_imsi_WithLMSI_chosen */
    } u;
} OMAP2_Indentity;

typedef struct OMAP2_CancelLocationRes {
    unsigned char   bit_mask;
#       define      OMAP2_CancelLocationRes_extensionContainer_present 0x80
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                        * OMAP2_CancelLocationRes_extensionContainer_present if
                        * present */
} OMAP2_CancelLocationRes;

//PurgeMS-Arg ::= [3] SEQUENCE {
typedef struct OMAP2_PurgeMS_Arg {
    OMAP2_IMSI      imsi;
    OMAP2_ISDN_AddressString vlr_Number;
} OMAP2_PurgeMS_Arg;

typedef struct OMAP2_PurgeMS_Res {
    unsigned char   bit_mask;
#       define      OMAP2_freezeTMSI_present 0x80
#       define      OMAP2_freezeP_TMSI_present 0x40
#       define      OMAP2_PurgeMS_Res_extensionContainer_present 0x20
    Nulltype        freezeTMSI;  /* optional; set in bit_mask
                                  * OMAP2_freezeTMSI_present if present */
    Nulltype        freezeP_TMSI;  /* optional; set in bit_mask
                                    * OMAP2_freezeP_TMSI_present if present */
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                              * OMAP2_PurgeMS_Res_extensionContainer_present if
                              * present */
} OMAP2_PurgeMS_Res;

typedef struct OMAP2_RAND {
    unsigned short  length;
    unsigned char   value[16];
} OMAP2_RAND;

typedef struct OMAP2_SRES {
    unsigned short  length;
    unsigned char   value[4];
} OMAP2_SRES;

typedef struct OMAP2_AuthenticationSet {
    OMAP2_RAND      rand;
    OMAP2_SRES      sres;
    OMAP2_Kc        kc;
} OMAP2_AuthenticationSet;

typedef struct OMAP2_AuthenticationSetList {
    unsigned short  count;
    OMAP2_AuthenticationSet value[5];
} OMAP2_AuthenticationSetList;

typedef struct OMAP2_SendIdentificationRes {
    unsigned char   bit_mask;
#       define      OMAP2_authenticationSetList_present 0x80
    OMAP2_IMSI      imsi;
    OMAP2_AuthenticationSetList authenticationSetList;  /* optional; set in
                                   * bit_mask
                                   * OMAP2_authenticationSetList_present if
                                   * present */
} OMAP2_SendIdentificationRes;

// handover types
typedef struct OMAP2_PrepareHO_Arg {
    unsigned char   bit_mask;
#       define      OMAP2_targetCellId_present 0x80
#       define      OMAP2_ho_NumberNotRequired_present 0x40
#       define      OMAP2_PrepareHO_Arg_bss_APDU_present 0x20
    OMAP2_GlobalCellId targetCellId;  /* optional; set in bit_mask
                                       * OMAP2_targetCellId_present if
                                       * present */
    Nulltype        ho_NumberNotRequired;  /* optional; set in bit_mask
                                            * OMAP2_ho_NumberNotRequired_present
                                            * if present */
    OMAP2_ExternalSignalInfo bss_APDU;  /* optional; set in bit_mask
                                         * OMAP2_PrepareHO_Arg_bss_APDU_present
                                         * if present */
} OMAP2_PrepareHO_Arg;

typedef struct OMAP2_PrepareHO_Res {
    unsigned char   bit_mask;
#       define      OMAP2_handoverNumber_present 0x80
#       define      OMAP2_PrepareHO_Res_bss_APDU_present 0x40
    OMAP2_ISDN_AddressString handoverNumber;  /* optional; set in bit_mask
                                               * OMAP2_handoverNumber_present if
                                               * present */
    OMAP2_ExternalSignalInfo bss_APDU;  /* optional; set in bit_mask
                                         * OMAP2_PrepareHO_Res_bss_APDU_present
                                         * if present */
} OMAP2_PrepareHO_Res;

typedef struct OMAP2_PrepareSubsequentHO_Arg {
    OMAP2_GlobalCellId targetCellId;
    OMAP2_ISDN_AddressString targetMSC_Number;
    OMAP2_ExternalSignalInfo bss_APDU;
} OMAP2_PrepareSubsequentHO_Arg;

// authentication management types
typedef OMAP2_IMSI      OMAP2_SendAuthenticationInfoArg;

typedef OMAP2_AuthenticationSetList OMAP2_SendAuthenticationInfoRes;

typedef struct OMAP2_Category {
    unsigned short  length;
    unsigned char   value[1];
} OMAP2_Category;

	// The internal structure is defined in CCITT Rec Q.763.
typedef enum OMAP2_SubscriberStatus {
    OMAP2_serviceGranted = 0,
    OMAP2_SubscriberStatus_operatorDeterminedBarring = 1
} OMAP2_SubscriberStatus;

typedef struct OMAP2_BearerServiceList {
    unsigned short  count;
    OMAP2_BearerServiceCode value[50];
} OMAP2_BearerServiceList;

typedef struct OMAP2_TeleserviceList {
    unsigned short  count;
    OMAP2_TeleserviceCode value[20];
} OMAP2_TeleserviceList;

typedef struct OMAP2_ODB_GeneralData {
    unsigned short  length;  /* number of significant bits */
    unsigned char   value[1];
} OMAP2_ODB_GeneralData;
#define                     OMAP2_allOG_CallsBarred 0x80
#define                     OMAP2_allOG_CallsBarred_byte 0
#define                     OMAP2_internationalOGCallsBarred 0x40
#define                     OMAP2_internationalOGCallsBarred_byte 0
#define                     OMAP2_internationalOGCallsNotToHPLMN_CountryBarred 0x20
#define                     OMAP2_internationalOGCallsNotToHPLMN_CountryBarred_byte 0
#define                     OMAP2_premiumRateInformationOGCallsBarred 0x10
#define                     OMAP2_premiumRateInformationOGCallsBarred_byte 0
#define                     OMAP2_premiumRateEntertainementOGCallsBarred 0x08
#define                     OMAP2_premiumRateEntertainementOGCallsBarred_byte 0
#define                     OMAP2_ss_AccessBarred 0x04
#define                     OMAP2_ss_AccessBarred_byte 0

typedef struct OMAP2_ODB_HPLMN_Data {
    unsigned short  length;  /* number of significant bits */
    unsigned char   value[1];
} OMAP2_ODB_HPLMN_Data;
#define                     OMAP2_plmn_SpecificBarringType1 0x80
#define                     OMAP2_plmn_SpecificBarringType1_byte 0
#define                     OMAP2_plmn_SpecificBarringType2 0x40
#define                     OMAP2_plmn_SpecificBarringType2_byte 0
#define                     OMAP2_plmn_SpecificBarringType3 0x20
#define                     OMAP2_plmn_SpecificBarringType3_byte 0
#define                     OMAP2_plmn_SpecificBarringType4 0x10
#define                     OMAP2_plmn_SpecificBarringType4_byte 0

typedef struct OMAP2_ODB_Data {
    unsigned char   bit_mask;
#       define      OMAP2_odb_HPLMN_Data_present 0x80
#       define      OMAP2_ODB_Data_extensionContainer_present 0x40
    OMAP2_ODB_GeneralData odb_GeneralData;
    OMAP2_ODB_HPLMN_Data odb_HPLMN_Data;  /* optional; set in bit_mask
                                           * OMAP2_odb_HPLMN_Data_present if
                                           * present */
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                                 * OMAP2_ODB_Data_extensionContainer_present if
                                 * present */
} OMAP2_ODB_Data;

typedef struct OMAP2_ZoneCode {
    unsigned short  length;
    unsigned char   value[2];
} OMAP2_ZoneCode;

typedef struct OMAP2_ZoneCodeList {
    unsigned short  count;
    OMAP2_ZoneCode  value[10];
} OMAP2_ZoneCodeList;

// subscriber management types
typedef struct OMAP2_InsertSubscriberDataArg {
    unsigned short  bit_mask;
#       define      OMAP2_InsertSubscriberDataArg_imsi_present 0x8000
#       define      OMAP2_InsertSubscriberDataArg_msisdn_present 0x4000
#       define      OMAP2_category_present 0x2000
#       define      OMAP2_subscriberStatus_present 0x1000
#       define      OMAP2_InsertSubscriberDataArg_bearerServiceList_present 0x0800
#       define      OMAP2_InsertSubscriberDataArg_teleserviceList_present 0x0400
#       define      OMAP2_provisionedSS_present 0x0200
#       define      OMAP2_odb_Data_present 0x0100
#       define      OMAP2_InsertSubscriberDataArg_roamingRestrictionDueToUnsupportedFeature_present 0x0080
#       define      OMAP2_regionalSubscriptionData_present 0x0040
    OMAP2_IMSI      imsi;  /* optional; set in bit_mask
                            * OMAP2_InsertSubscriberDataArg_imsi_present if
                            * present */
    OMAP2_ISDN_AddressString msisdn;  /* optional; set in bit_mask
                              * OMAP2_InsertSubscriberDataArg_msisdn_present if
                              * present */
    OMAP2_Category  category;  /* optional; set in bit_mask
                                * OMAP2_category_present if present */
    OMAP2_SubscriberStatus subscriberStatus;  /* optional; set in bit_mask
                                               * OMAP2_subscriberStatus_present
                                               * if present */
    OMAP2_BearerServiceList bearerServiceList;  /* optional; set in bit_mask
                   * OMAP2_InsertSubscriberDataArg_bearerServiceList_present if
                   * present */
	// The exception handling for reception of unsupported / not allocated
	// bearerServiceCodes is defined in section 6.8.1
    OMAP2_TeleserviceList teleserviceList;  /* optional; set in bit_mask
                     * OMAP2_InsertSubscriberDataArg_teleserviceList_present if
                     * present */
	// The exception handling for reception of unsupported / not allocated
	// teleserviceCodes is defined in section 6.8.1
    OMAP2_SS_InfoList provisionedSS;  /* optional; set in bit_mask
                                       * OMAP2_provisionedSS_present if
                                       * present */
    OMAP2_ODB_Data  odb_Data;  /* optional; set in bit_mask
                                * OMAP2_odb_Data_present if present */
    Nulltype        roamingRestrictionDueToUnsupportedFeature;  /* optional; set
                                   * in bit_mask
       * OMAP2_InsertSubscriberDataArg_roamingRestrictionDueToUnsupportedFeature_present if
       * present */
    OMAP2_ZoneCodeList regionalSubscriptionData;  /* optional; set in bit_mask
                                    * OMAP2_regionalSubscriptionData_present if
                                    * present */
} OMAP2_InsertSubscriberDataArg;

typedef struct OMAP2_QoS_Subscribed {
    unsigned short  length;
    unsigned char   value[3];
} OMAP2_QoS_Subscribed;

typedef struct OMAP2_Ext_SS_Status {
    unsigned short  length;
    unsigned char   value[5];
} OMAP2_Ext_SS_Status;

	// OCTET 1:
	//
	// bits 8765: 0000 (unused)
	// bits 4321: Used to convey the "P bit","R bit","A bit" and "Q bit",
	//		    representing supplementary service state information
	//		    as defined in TS GSM 03.11

	// bit 4: "Q bit"

	// bit 3: "P bit"

	// bit 2: "R bit"

	// bit 1: "A bit"

	// OCTETS 2-5: reserved for future use. They shall be discarded if
	// received and not understood.
typedef struct OMAP2_Ext_ForwOptions {
    unsigned short  length;
    unsigned char   value[5];
} OMAP2_Ext_ForwOptions;

	// OCTET 1:

	//  bit 8: notification to forwarding party
	//	0  no notification
	//	1  notification

	//  bit 7: 0 (unused)

	//  bit 6: notification to calling party
	//	0  no notification
	//	1  notification

	//  bit 5: 0 (unused)

	//  bits 43: forwarding reason
	//	00  ms not reachable
	//	01  ms busy
	//	10  no reply
	//	11  unconditional

	// bits 21: 00 (unused)

	// OCTETS 2-5: reserved for future use. They shall be discarded if
	// received and not understood.
typedef unsigned short  OMAP2_Ext_NoRepCondTime;

typedef struct OMAP2_Ext_ForwFeature {
    unsigned char   bit_mask;
#       define      OMAP2_Ext_ForwFeature_basicService_present 0x80
#       define      OMAP2_Ext_ForwFeature_forwardedToNumber_present 0x40
#       define      OMAP2_Ext_ForwFeature_forwardedToSubaddress_present 0x20
#       define      OMAP2_Ext_ForwFeature_forwardingOptions_present 0x10
#       define      OMAP2_Ext_ForwFeature_noReplyConditionTime_present 0x08
#       define      OMAP2_Ext_ForwFeature_extensionContainer_present 0x04
    OMAP2_Ext_BasicServiceCode basicService;  /* optional; set in bit_mask
                                * OMAP2_Ext_ForwFeature_basicService_present if
                                * present */
    OMAP2_Ext_SS_Status ss_Status;
    OMAP2_ISDN_AddressString forwardedToNumber;  /* optional; set in bit_mask
                           * OMAP2_Ext_ForwFeature_forwardedToNumber_present if
                           * present */
    OMAP2_ISDN_SubaddressString forwardedToSubaddress;  /* optional; set in
                                   * bit_mask
                       * OMAP2_Ext_ForwFeature_forwardedToSubaddress_present if
                       * present */
    OMAP2_Ext_ForwOptions forwardingOptions;  /* optional; set in bit_mask
                           * OMAP2_Ext_ForwFeature_forwardingOptions_present if
                           * present */
    OMAP2_Ext_NoRepCondTime noReplyConditionTime;  /* optional; set in bit_mask
                        * OMAP2_Ext_ForwFeature_noReplyConditionTime_present if
                        * present */
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                          * OMAP2_Ext_ForwFeature_extensionContainer_present if
                          * present */
} OMAP2_Ext_ForwFeature;

typedef struct OMAP2_Ext_ForwFeatureList {
    unsigned short  count;
    OMAP2_Ext_ForwFeature value[32];
} OMAP2_Ext_ForwFeatureList;

typedef struct OMAP2_Ext_ForwInfo {
    unsigned char   bit_mask;
#       define      OMAP2_Ext_ForwInfo_extensionContainer_present 0x80
    OMAP2_SS_Code   ss_Code;
    OMAP2_Ext_ForwFeatureList forwardingFeatureList;
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                             * OMAP2_Ext_ForwInfo_extensionContainer_present if
                             * present */
} OMAP2_Ext_ForwInfo;

typedef struct OMAP2_Ext_CallBarringFeature {
    unsigned char   bit_mask;
#       define      OMAP2_Ext_CallBarringFeature_basicService_present 0x80
#       define      OMAP2_Ext_CallBarringFeature_extensionContainer_present 0x40
    OMAP2_Ext_BasicServiceCode basicService;  /* optional; set in bit_mask
                         * OMAP2_Ext_CallBarringFeature_basicService_present if
                         * present */
    OMAP2_Ext_SS_Status ss_Status;
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                   * OMAP2_Ext_CallBarringFeature_extensionContainer_present if
                   * present */
} OMAP2_Ext_CallBarringFeature;

typedef struct OMAP2_Ext_CallBarFeatureList {
    unsigned short  count;
    OMAP2_Ext_CallBarringFeature value[32];
} OMAP2_Ext_CallBarFeatureList;

	// Only values 5-30 are used.
	// Values in the ranges 1-4 and 31-100 are reserved for future use
	// If received:
	//		values 1-4 shall be mapped on to value 5
	//		values 31-100 shall be mapped on to value 30
typedef struct OMAP2_Ext_CallBarInfo {
    unsigned char   bit_mask;
#       define      OMAP2_Ext_CallBarInfo_extensionContainer_present 0x80
    OMAP2_SS_Code   ss_Code;
    OMAP2_Ext_CallBarFeatureList callBarringFeatureList;
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                          * OMAP2_Ext_CallBarInfo_extensionContainer_present if
                          * present */
} OMAP2_Ext_CallBarInfo;

typedef unsigned short  OMAP2_MS_DataTypes_CUG_Index;

typedef enum OMAP2_MS_DataTypes_IntraCUG_Options {
    OMAP2_MS_DataTypes_IntraCUG_Options_noCUG_Restrictions = 0,
    OMAP2_MS_DataTypes_IntraCUG_Options_cugIC_CallBarred = 1,
    OMAP2_MS_DataTypes_IntraCUG_Options_cugOG_CallBarred = 2
} OMAP2_MS_DataTypes_IntraCUG_Options;

typedef struct OMAP2_Ext_BasicServiceGroupList {
    unsigned short  count;
    OMAP2_Ext_BasicServiceCode value[32];
} OMAP2_Ext_BasicServiceGroupList;

typedef struct OMAP2_MS_DataTypes_CUG_Subscription {
    unsigned char   bit_mask;
#       define      OMAP2_MS_DataTypes_CUG_Subscription_basicServiceGroupList_present 0x80
#       define      OMAP2_CUG_Subscription_extensionContainer_present 0x40
    OMAP2_MS_DataTypes_CUG_Index cug_Index;
    OMAP2_MS_DataTypes_CUG_Interlock cug_Interlock;
    OMAP2_MS_DataTypes_IntraCUG_Options intraCUG_Options;
    OMAP2_Ext_BasicServiceGroupList basicServiceGroupList;  /* optional; set in
                                   * bit_mask
         * OMAP2_MS_DataTypes_CUG_Subscription_basicServiceGroupList_present if
         * present */
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                         * OMAP2_CUG_Subscription_extensionContainer_present if
                         * present */
} OMAP2_MS_DataTypes_CUG_Subscription;

typedef struct OMAP2_MS_DataTypes_CUG_SubscriptionList {
    unsigned short  count;
    OMAP2_MS_DataTypes_CUG_Subscription value[10];
} OMAP2_MS_DataTypes_CUG_SubscriptionList;

typedef struct OMAP2_MS_DataTypes_InterCUG_Restrictions {
    unsigned short  length;
    unsigned char   value[1];
} OMAP2_MS_DataTypes_InterCUG_Restrictions;

typedef struct OMAP2_MS_DataTypes_CUG_Feature {
    unsigned char   bit_mask;
#       define      OMAP2_MS_DataTypes_CUG_Feature_basicService_present 0x80
#       define      OMAP2_MS_DataTypes_CUG_Feature_preferentialCUG_Indicator_present 0x40
#       define      OMAP2_CUG_Feature_extensionContainer_present 0x20
    OMAP2_Ext_BasicServiceCode basicService;  /* optional; set in bit_mask
                       * OMAP2_MS_DataTypes_CUG_Feature_basicService_present if
                       * present */
    OMAP2_MS_DataTypes_CUG_Index preferentialCUG_Indicator;  /* optional; set in
                                   * bit_mask
          * OMAP2_MS_DataTypes_CUG_Feature_preferentialCUG_Indicator_present if
          * present */
    OMAP2_MS_DataTypes_InterCUG_Restrictions interCUG_Restrictions;
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                              * OMAP2_CUG_Feature_extensionContainer_present if
                              * present */
} OMAP2_MS_DataTypes_CUG_Feature;

typedef struct OMAP2_MS_DataTypes_CUG_FeatureList {
    unsigned short  count;
    OMAP2_MS_DataTypes_CUG_Feature value[32];
} OMAP2_MS_DataTypes_CUG_FeatureList;

typedef struct OMAP2_MS_DataTypes_CUG_Info {
    unsigned char   bit_mask;
#       define      OMAP2_MS_DataTypes_CUG_Info_cug_FeatureList_present 0x80
#       define      OMAP2_CUG_Info_extensionContainer_present 0x40
    OMAP2_MS_DataTypes_CUG_SubscriptionList cug_SubscriptionList;
    OMAP2_MS_DataTypes_CUG_FeatureList cug_FeatureList;  /* optional; set in
                                   * bit_mask
                       * OMAP2_MS_DataTypes_CUG_Info_cug_FeatureList_present if
                       * present */
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                                 * OMAP2_CUG_Info_extensionContainer_present if
                                 * present */
} OMAP2_MS_DataTypes_CUG_Info;

	// bits 876543: 000000 (unused)
	// Exception handling:
	// bits 876543 shall be ignored if received and not understood

	// bits 21
	//	00  CUG only facilities
	//	01  CUG with outgoing access
	//	10  CUG with incoming access
	//	11  CUG with both outgoing and incoming access
typedef struct OMAP2_Ext_SS_Data {
    unsigned char   bit_mask;
#       define      OMAP2_Ext_SS_Data_ss_SubscriptionOption_present 0x80
#       define      OMAP2_Ext_SS_Data_basicServiceGroupList_present 0x40
#       define      OMAP2_Ext_SS_Data_extensionContainer_present 0x20
    OMAP2_SS_Code   ss_Code;
    OMAP2_Ext_SS_Status ss_Status;
    OMAP2_SS_SubscriptionOption ss_SubscriptionOption;  /* optional; set in
                                   * bit_mask
                           * OMAP2_Ext_SS_Data_ss_SubscriptionOption_present if
                           * present */
    OMAP2_Ext_BasicServiceGroupList basicServiceGroupList;  /* optional; set in
                                   * bit_mask
                           * OMAP2_Ext_SS_Data_basicServiceGroupList_present if
                           * present */
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                              * OMAP2_Ext_SS_Data_extensionContainer_present if
                              * present */
} OMAP2_Ext_SS_Data;

typedef struct OMAP2_Ext_SS_Info {
    unsigned short  choice;
#       define      OMAP2_Ext_SS_Info_forwardingInfo_chosen 1
#       define      OMAP2_Ext_SS_Info_callBarringInfo_chosen 2
#       define      OMAP2_Ext_SS_Info_cug_Info_chosen 3
#       define      OMAP2_Ext_SS_Info_ss_Data_chosen 4
#       define      OMAP2_emlpp_Info_chosen 5
    union _union {
        OMAP2_Ext_ForwInfo forwardingInfo;  /* to choose, set choice to
                                   * OMAP2_Ext_SS_Info_forwardingInfo_chosen */
        OMAP2_Ext_CallBarInfo callBarringInfo;  /* to choose, set choice to
                                  * OMAP2_Ext_SS_Info_callBarringInfo_chosen */
        OMAP2_MS_DataTypes_CUG_Info cug_Info;  /* to choose, set choice to
                                         * OMAP2_Ext_SS_Info_cug_Info_chosen */
        OMAP2_Ext_SS_Data ss_Data;  /* to choose, set choice to
                                     * OMAP2_Ext_SS_Info_ss_Data_chosen */
        OMAP2_EMLPP_Info emlpp_Info;  /* to choose, set choice to
                                       * OMAP2_emlpp_Info_chosen */
    } u;
} OMAP2_Ext_SS_Info;

typedef struct OMAP2_Ext_SS_InfoList {
    unsigned short  count;
    OMAP2_Ext_SS_Info value[30];
} OMAP2_Ext_SS_InfoList;

typedef enum OMAP2_RegionalSubscriptionResponse {
    OMAP2_networkNode_AreaRestricted = 0,
    OMAP2_tooManyZoneCodes = 1,
    OMAP2_zoneCodesConflict = 2,
    OMAP2_regionalSubscNotSupported = 3
} OMAP2_RegionalSubscriptionResponse;

typedef struct OMAP2_InsertSubscriberDataRes {
    unsigned char   bit_mask;
#       define      OMAP2_InsertSubscriberDataRes_teleserviceList_present 0x80
#       define      OMAP2_InsertSubscriberDataRes_bearerServiceList_present 0x40
#       define      OMAP2_InsertSubscriberDataRes_ss_List_present 0x20
#       define      OMAP2_odb_GeneralData_present 0x10
#       define      OMAP2_InsertSubscriberDataRes_regionalSubscriptionResponse_present 0x08
    OMAP2_TeleserviceList teleserviceList;  /* optional; set in bit_mask
                     * OMAP2_InsertSubscriberDataRes_teleserviceList_present if
                     * present */
    OMAP2_BearerServiceList bearerServiceList;  /* optional; set in bit_mask
                   * OMAP2_InsertSubscriberDataRes_bearerServiceList_present if
                   * present */
    OMAP2_SS_List   ss_List;  /* optional; set in bit_mask
                               * OMAP2_InsertSubscriberDataRes_ss_List_present
                               * if present */
    OMAP2_ODB_GeneralData odb_GeneralData;  /* optional; set in bit_mask
                                             * OMAP2_odb_GeneralData_present if
                                             * present */
    OMAP2_RegionalSubscriptionResponse regionalSubscriptionResponse;  
                                  /* optional; set in bit_mask
        * OMAP2_InsertSubscriberDataRes_regionalSubscriptionResponse_present if
        * present */
} OMAP2_InsertSubscriberDataRes;

typedef struct OMAP2_BasicServiceList {
    unsigned short  count;
    OMAP2_BasicServiceCode value[70];
} OMAP2_BasicServiceList;

typedef struct OMAP2_DeleteSubscriberDataArg {
    unsigned char   bit_mask;
#       define      OMAP2_basicServiceList_present 0x80
#       define      OMAP2_DeleteSubscriberDataArg_ss_List_present 0x40
#       define      OMAP2_DeleteSubscriberDataArg_roamingRestrictionDueToUnsupportedFeature_present 0x20
#       define      OMAP2_regionalSubscriptionIdentifier_present 0x10
    OMAP2_IMSI      imsi;
    OMAP2_BasicServiceList basicServiceList;  /* optional; set in bit_mask
                                               * OMAP2_basicServiceList_present
                                               * if present */
	// The exception handling for reception of unsupported/not allocated
	// basicServiceCodes is defined in section 6.8.2
    OMAP2_SS_List   ss_List;  /* optional; set in bit_mask
                               * OMAP2_DeleteSubscriberDataArg_ss_List_present
                               * if present */
    Nulltype        roamingRestrictionDueToUnsupportedFeature;  /* optional; set
                                   * in bit_mask
       * OMAP2_DeleteSubscriberDataArg_roamingRestrictionDueToUnsupportedFeature_present if
       * present */
    OMAP2_ZoneCode  regionalSubscriptionIdentifier;  /* optional; set in
                                   * bit_mask
                              * OMAP2_regionalSubscriptionIdentifier_present if
                              * present */
} OMAP2_DeleteSubscriberDataArg;

typedef struct OMAP2_DeleteSubscriberDataRes {
    unsigned char   bit_mask;
#       define      OMAP2_DeleteSubscriberDataRes_regionalSubscriptionResponse_present 0x80
#       define      OMAP2_DeleteSubscriberDataRes_extensionContainer_present 0x40
    OMAP2_RegionalSubscriptionResponse regionalSubscriptionResponse;  
                                  /* optional; set in bit_mask
        * OMAP2_DeleteSubscriberDataRes_regionalSubscriptionResponse_present if
        * present */
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                  * OMAP2_DeleteSubscriberDataRes_extensionContainer_present if
                  * present */
} OMAP2_DeleteSubscriberDataRes;

typedef enum OMAP2_MatchType {
    OMAP2_inhibiting = 0,
    OMAP2_enabling = 1
} OMAP2_MatchType;

// exception handling:
// reception of values in range 2-31 shall be treated as "continueCall"
// reception of values greater than 31 shall be treated as "releaseCall"
// fault recovery types
typedef struct OMAP2_ResetArg {
    unsigned char   bit_mask;
#       define      OMAP2_hlr_List_present 0x80
    OMAP2_ISDN_AddressString hlr_Number;
    OMAP2_HLR_List  hlr_List;  /* optional; set in bit_mask
                                * OMAP2_hlr_List_present if present */
} OMAP2_ResetArg;

typedef struct OMAP2_RestoreDataArg {
    unsigned char   bit_mask;
#       define      OMAP2_RestoreDataArg_lmsi_present 0x80
#       define      OMAP2_RestoreDataArg_extensionContainer_present 0x40
    OMAP2_IMSI      imsi;
    OMAP2_LMSI      lmsi;  /* optional; set in bit_mask
                            * OMAP2_RestoreDataArg_lmsi_present if present */
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                           * OMAP2_RestoreDataArg_extensionContainer_present if
                           * present */
} OMAP2_RestoreDataArg;

typedef struct OMAP2_RestoreDataRes {
    unsigned char   bit_mask;
#       define      OMAP2_msNotReachable_present 0x80
#       define      OMAP2_RestoreDataRes_extensionContainer_present 0x40
    OMAP2_ISDN_AddressString hlr_Number;
    Nulltype        msNotReachable;  /* optional; set in bit_mask
                                      * OMAP2_msNotReachable_present if
                                      * present */
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                           * OMAP2_RestoreDataRes_extensionContainer_present if
                           * present */
} OMAP2_RestoreDataRes;

typedef struct OMAP2_GroupId {
    unsigned short  length;
    unsigned char   value[3];
} OMAP2_GroupId;

typedef struct OMAP2_VoiceBroadcastData {
    unsigned char   bit_mask;
#       define      OMAP2_broadcastInitEntitlement_present 0x80
#       define      OMAP2_VoiceBroadcastData_extensionContainer_present 0x40
    OMAP2_GroupId   groupid;
    Nulltype        broadcastInitEntitlement;  /* optional; set in bit_mask
                                    * OMAP2_broadcastInitEntitlement_present if
                                    * present */
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                       * OMAP2_VoiceBroadcastData_extensionContainer_present if
                       * present */
} OMAP2_VoiceBroadcastData;

// VBS/VGCS types
typedef struct OMAP2_VBSDataList {
    unsigned short  count;
    OMAP2_VoiceBroadcastData value[50];
} OMAP2_VBSDataList;

typedef struct OMAP2_VoiceGroupCallData {
    unsigned char   bit_mask;
#       define      OMAP2_VoiceGroupCallData_extensionContainer_present 0x80
    OMAP2_GroupId   groupId;
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                       * OMAP2_VoiceGroupCallData_extensionContainer_present if
                       * present */
} OMAP2_VoiceGroupCallData;

typedef struct OMAP2_VGCSDataList {
    unsigned short  count;
    OMAP2_VoiceGroupCallData value[50];
} OMAP2_VGCSDataList;

typedef unsigned short  OMAP2_AgeOfLocationInformation;

// the value represents the elapsed time in minutes since the last
// network contact of the mobile station (i.e. the actuality of the
// location information).
// value "0" indicates that the MS is currently in contact with the
//           network
// value "32767" indicates that the location information is at least
//               32767 minutes old
typedef struct OMAP2_GeographicalInformation {
    unsigned short  length;
    unsigned char   value[8];
} OMAP2_GeographicalInformation;

// Refers to geographical Information defined in GSM 03.32.
// Only the description of an ellipsoid point with uncertainty circle
//as specified in GSM 03.32 is allowed to be used
// The internal structure according to GSM 03.32 is as follows:
//		Type of shape (ellipsoid point with uncertainty circle)	1 octet
//		Degrees of Latitude				3 octets
//		Degrees of Longitude				3 octets
//		Uncertainty code				1 octet
typedef struct OMAP2_LocationNumber {
    unsigned short  length;
    unsigned char   value[10];
} OMAP2_LocationNumber;

typedef enum OMAP2_NotReachableReason {
    OMAP2_msPurged = 0,
    OMAP2_imsiDetached = 1,
    OMAP2_NotReachableReason_restrictedArea = 2,
    OMAP2_notRegistered = 3
} OMAP2_NotReachableReason;

	// the internal structure is defined in CCITT Rec Q.763
typedef struct OMAP2_SubscriberState {
    unsigned short  choice;
#       define      OMAP2_assumedIdle_chosen 1
#       define      OMAP2_camelBusy_chosen 2
#       define      OMAP2_netDetNotReachable_chosen 3
#       define      OMAP2_notProvidedFromVLR_chosen 4
    union _union {
        Nulltype        assumedIdle;  /* to choose, set choice to
                                       * OMAP2_assumedIdle_chosen */
        Nulltype        camelBusy;  /* to choose, set choice to
                                     * OMAP2_camelBusy_chosen */
        OMAP2_NotReachableReason netDetNotReachable;  /* to choose, set choice
                                        * to OMAP2_netDetNotReachable_chosen */
        Nulltype        notProvidedFromVLR;  /* to choose, set choice to
                                           * OMAP2_notProvidedFromVLR_chosen */
    } u;
} OMAP2_SubscriberState;

// supplementary service handling operations
typedef struct OMAP2_RegisterSS {                                /*Timer m*/
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_RegisterSS;

typedef struct OMAP2_EraseSS {                           /*Timer m*/
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_EraseSS;

typedef struct OMAP2_ActivateSS {                                /*Timer m*/
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_ActivateSS;

typedef struct OMAP2_DeactivateSS {                              /*Timer m*/
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_DeactivateSS;

typedef struct OMAP2_InterrogateSS {                             /*Timer m*/
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_InterrogateSS;

typedef struct OMAP2_ProcessUnstructuredSS_Request {                /*Timer 10 minutes*/
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_ProcessUnstructuredSS_Request;

typedef struct OMAP2_UnstructuredSS_Request {                    /*Timer ml*/
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_UnstructuredSS_Request;

typedef struct OMAP2_UnstructuredSS_Notify {                             /*Timer ml*/
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_UnstructuredSS_Notify;

typedef struct OMAP2_RegisterPassword {                          /*Timer ml*/
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_RegisterPassword;

typedef struct OMAP2_GetPassword {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_GetPassword;                               /*Timer m*/

typedef enum OMAP2_RoamingNotAllowedCause {
    OMAP2_plmnRoamingNotAllowed = 0,
    OMAP2_RoamingNotAllowedCause_operatorDeterminedBarring = 3
} OMAP2_RoamingNotAllowedCause;

typedef struct OMAP2_RoamingNotAllowedParam {
    unsigned char   bit_mask;
#       define      OMAP2_RoamingNotAllowedParam_extensionContainer_present 0x80
    OMAP2_RoamingNotAllowedCause roamingNotAllowedCause;
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                   * OMAP2_RoamingNotAllowedParam_extensionContainer_present if
                   * present */
} OMAP2_RoamingNotAllowedParam;

typedef enum OMAP2_CallBarringCause {
    OMAP2_barringServiceActive = 0,
    OMAP2_operatorBarring = 1
} OMAP2_CallBarringCause;

typedef struct OMAP2_ExtensibleCallBarredParam {
    unsigned char   bit_mask;
#       define      OMAP2_callBarringCause_present 0x80
#       define      OMAP2_ExtensibleCallBarredParam_extensionContainer_present 0x40
#       define      OMAP2_unauthorisedMessageOriginator_present 0x20
    OMAP2_CallBarringCause callBarringCause;  /* optional; set in bit_mask
                                               * OMAP2_callBarringCause_present
                                               * if present */
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                * OMAP2_ExtensibleCallBarredParam_extensionContainer_present if
                * present */
    Nulltype        unauthorisedMessageOriginator;  /* extension #1; optional;
                                   * set in bit_mask
                                   * OMAP2_unauthorisedMessageOriginator_present
                                   * if present */
} OMAP2_ExtensibleCallBarredParam;

typedef struct OMAP2_CallBarredParam {
    unsigned short  choice;
#       define      OMAP2_callBarringCause_chosen 1
#       define      OMAP2_extensibleCallBarredParam_chosen 2
    union _union {
        OMAP2_CallBarringCause callBarringCause;  /* to choose, set choice to
                                             * OMAP2_callBarringCause_chosen */
	// call BarringCause must not be used in version 3
        OMAP2_ExtensibleCallBarredParam extensibleCallBarredParam;  /* to
                                   * choose, set choice to
                                   * OMAP2_extensibleCallBarredParam_chosen */
	// extensibleCallBarredParam must not be used in version <3
    } u;
} OMAP2_CallBarredParam;

typedef enum OMAP2_CUG_RejectCause {
    OMAP2_incomingCallsBarredWithinCUG = 0,
    OMAP2_subscriberNotMemberOfCUG = 1,
    OMAP2_requestedBasicServiceViolatesCUG_Constraints = 5,
    OMAP2_calledPartySS_InteractionViolation = 7
} OMAP2_CUG_RejectCause;

typedef struct OMAP2_CUG_RejectParam {
    unsigned char   bit_mask;
#       define      OMAP2_cug_RejectCause_present 0x80
#       define      OMAP2_CUG_RejectParam_extensionContainer_present 0x40
    OMAP2_CUG_RejectCause cug_RejectCause;  /* optional; set in bit_mask
                                             * OMAP2_cug_RejectCause_present if
                                             * present */
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                          * OMAP2_CUG_RejectParam_extensionContainer_present if
                          * present */
} OMAP2_CUG_RejectParam;

typedef struct OMAP2_SS_IncompatibilityCause {
    unsigned char   bit_mask;
#       define      OMAP2_SS_IncompatibilityCause_ss_Code_present 0x80
#       define      OMAP2_SS_IncompatibilityCause_basicService_present 0x40
#       define      OMAP2_SS_IncompatibilityCause_ss_Status_present 0x20
    OMAP2_SS_Code   ss_Code;  /* optional; set in bit_mask
                               * OMAP2_SS_IncompatibilityCause_ss_Code_present
                               * if present */
    OMAP2_BasicServiceCode basicService;  /* optional; set in bit_mask
                        * OMAP2_SS_IncompatibilityCause_basicService_present if
                        * present */
    OMAP2_SS_Status ss_Status;  /* optional; set in bit_mask
                           * OMAP2_SS_IncompatibilityCause_ss_Status_present if
                           * present */
} OMAP2_SS_IncompatibilityCause;

typedef enum OMAP2_SM_EnumeratedDeliveryFailureCause {
    OMAP2_SM_EnumeratedDeliveryFailureCause_memoryCapacityExceeded = 0,
    OMAP2_equipmentProtocolError = 1,
    OMAP2_equipmentNotSM_Equipped = 2,
    OMAP2_unknownServiceCentre = 3,
    OMAP2_sc_Congestion = 4,
    OMAP2_invalidSME_Address = 5,
    OMAP2_subscriberNotSC_Subscriber = 6
} OMAP2_SM_EnumeratedDeliveryFailureCause;

typedef struct OMAP2_SM_DeliveryFailureCause {
    unsigned char   bit_mask;
#       define      OMAP2_diagnosticInfo_present 0x80
#       define      OMAP2_SM_DeliveryFailureCause_extensionContainer_present 0x40
    OMAP2_SM_EnumeratedDeliveryFailureCause sm_EnumeratedDeliveryFailureCause;
    OMAP2_SignalInfo diagnosticInfo;  /* optional; set in bit_mask
                                       * OMAP2_diagnosticInfo_present if
                                       * present */
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                  * OMAP2_SM_DeliveryFailureCause_extensionContainer_present if
                  * present */
} OMAP2_SM_DeliveryFailureCause;

	// if received, additionalAbsentSubscriberDiagnosticSM 
	// is for GPRS and absentSubscriberDiagnosticSM is 
	// for non-GPRS
typedef unsigned short  OMAP2_AbsentSubscriberDiagnosticSM;

typedef struct OMAP2_AbsentSubscriberSM_Param {
    unsigned char   bit_mask;
#       define      OMAP2_absentSubscriberDiagnosticSM_present 0x80
#       define      OMAP2_AbsentSubscriberSM_Param_extensionContainer_present 0x40
#       define      OMAP2_additionalAbsentSubscriberDiagnosticSM_present 0x20
    OMAP2_AbsentSubscriberDiagnosticSM absentSubscriberDiagnosticSM;  
                                  /* optional; set in bit_mask
                                   * OMAP2_absentSubscriberDiagnosticSM_present
                                   * if present */
	// AbsentSubscriberDiagnosticSM can be either for non-GPRS 
	// or for GPRS
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                 * OMAP2_AbsentSubscriberSM_Param_extensionContainer_present if
                 * present */
    OMAP2_AbsentSubscriberDiagnosticSM additionalAbsentSubscriberDiagnosticSM;                                          /* extension #1; optional; set in
                                   * bit_mask
                      * OMAP2_additionalAbsentSubscriberDiagnosticSM_present if
                      * present */
} OMAP2_AbsentSubscriberSM_Param;

typedef struct OMAP2_ExtensibleSystemFailureParam {
    unsigned char   bit_mask;
#       define      OMAP2_networkResource_present 0x80
#       define      OMAP2_ExtensibleSystemFailureParam_extensionContainer_present 0x40
    OMAP2_NetworkResource networkResource;  /* optional; set in bit_mask
                                             * OMAP2_networkResource_present if
                                             * present */
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
             * OMAP2_ExtensibleSystemFailureParam_extensionContainer_present if
             * present */
} OMAP2_ExtensibleSystemFailureParam;

	// AbsentSubscriberDiagnosticSM values are defined in ETS 300 536 (GSM 03.40)
typedef struct OMAP2_SystemFailureParam {
    unsigned short  choice;
#       define      OMAP2_networkResource_chosen 1
#       define      OMAP2_extensibleSystemFailureParam_chosen 2
    union _union {
        OMAP2_NetworkResource networkResource;  /* to choose, set choice to
                                              * OMAP2_networkResource_chosen */
	// networkResource must not be used in version 3
        OMAP2_ExtensibleSystemFailureParam extensibleSystemFailureParam;  
                                        /* to choose, set choice to
                                 * OMAP2_extensibleSystemFailureParam_chosen */
	// extensibleSystemFailureParam must not be used in version <3
    } u;
} OMAP2_SystemFailureParam;

typedef struct OMAP2_DataMissingParam {
    unsigned char   bit_mask;
#       define      OMAP2_DataMissingParam_extensionContainer_present 0x80
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                         * OMAP2_DataMissingParam_extensionContainer_present if
                         * present */
} OMAP2_DataMissingParam;

typedef struct OMAP2_UnexpectedDataParam {
    unsigned char   bit_mask;
#       define      OMAP2_UnexpectedDataParam_extensionContainer_present 0x80
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                      * OMAP2_UnexpectedDataParam_extensionContainer_present if
                      * present */
} OMAP2_UnexpectedDataParam;

typedef struct OMAP2_FacilityNotSupParam {
    unsigned char   bit_mask;
#       define      OMAP2_FacilityNotSupParam_extensionContainer_present 0x80
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                      * OMAP2_FacilityNotSupParam_extensionContainer_present if
                      * present */
} OMAP2_FacilityNotSupParam;

typedef struct OMAP2_OR_NotAllowedParam {
    unsigned char   bit_mask;
#       define      OMAP2_OR_NotAllowedParam_extensionContainer_present 0x80
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                       * OMAP2_OR_NotAllowedParam_extensionContainer_present if
                       * present */
} OMAP2_OR_NotAllowedParam;

typedef enum OMAP2_UnknownSubscriberDiagnostic {
    OMAP2_imsiUnknown = 0,
    OMAP2_gprsSubscriptionUnknown = 1
} OMAP2_UnknownSubscriberDiagnostic;

typedef struct OMAP2_UnknownSubscriberParam {
    unsigned char   bit_mask;
#       define      OMAP2_UnknownSubscriberParam_extensionContainer_present 0x80
#       define      OMAP2_unknownSubscriberDiagnostic_present 0x40
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                   * OMAP2_UnknownSubscriberParam_extensionContainer_present if
                   * present */
    OMAP2_UnknownSubscriberDiagnostic unknownSubscriberDiagnostic;  
                                  /* extension #1; optional; set in bit_mask
                                   * OMAP2_unknownSubscriberDiagnostic_present
                                   * if present */
} OMAP2_UnknownSubscriberParam;

	// if unknown values are received in 	
	// unknownSubscriberDiagnostic they shall be discarded
typedef struct OMAP2_NumberChangedParam {
    unsigned char   bit_mask;
#       define      OMAP2_NumberChangedParam_extensionContainer_present 0x80
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                       * OMAP2_NumberChangedParam_extensionContainer_present if
                       * present */
} OMAP2_NumberChangedParam;

typedef struct OMAP2_UnidentifiedSubParam {
    unsigned char   bit_mask;
#       define      OMAP2_UnidentifiedSubParam_extensionContainer_present 0x80
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                     * OMAP2_UnidentifiedSubParam_extensionContainer_present if
                     * present */
} OMAP2_UnidentifiedSubParam;

typedef struct OMAP2_IllegalSubscriberParam {
    unsigned char   bit_mask;
#       define      OMAP2_IllegalSubscriberParam_extensionContainer_present 0x80
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                   * OMAP2_IllegalSubscriberParam_extensionContainer_present if
                   * present */
} OMAP2_IllegalSubscriberParam;

typedef struct OMAP2_IllegalEquipmentParam {
    unsigned char   bit_mask;
#       define      OMAP2_IllegalEquipmentParam_extensionContainer_present 0x80
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                    * OMAP2_IllegalEquipmentParam_extensionContainer_present if
                    * present */
} OMAP2_IllegalEquipmentParam;

typedef struct OMAP2_BearerServNotProvParam {
    unsigned char   bit_mask;
#       define      OMAP2_BearerServNotProvParam_extensionContainer_present 0x80
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                   * OMAP2_BearerServNotProvParam_extensionContainer_present if
                   * present */
} OMAP2_BearerServNotProvParam;

typedef struct OMAP2_TeleservNotProvParam {
    unsigned char   bit_mask;
#       define      OMAP2_TeleservNotProvParam_extensionContainer_present 0x80
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                     * OMAP2_TeleservNotProvParam_extensionContainer_present if
                     * present */
} OMAP2_TeleservNotProvParam;

typedef struct OMAP2_TracingBufferFullParam {
    unsigned char   bit_mask;
#       define      OMAP2_TracingBufferFullParam_extensionContainer_present 0x80
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                   * OMAP2_TracingBufferFullParam_extensionContainer_present if
                   * present */
} OMAP2_TracingBufferFullParam;

typedef struct OMAP2_NoRoamingNbParam {
    unsigned char   bit_mask;
#       define      OMAP2_NoRoamingNbParam_extensionContainer_present 0x80
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                         * OMAP2_NoRoamingNbParam_extensionContainer_present if
                         * present */
} OMAP2_NoRoamingNbParam;

typedef enum OMAP2_AbsentSubscriberReason {
    OMAP2_imsiDetach = 0,
    OMAP2_AbsentSubscriberReason_restrictedArea = 1,
    OMAP2_noPageResponse = 2
} OMAP2_AbsentSubscriberReason;

typedef struct OMAP2_AbsentSubscriberParam {
    unsigned char   bit_mask;
#       define      OMAP2_AbsentSubscriberParam_extensionContainer_present 0x80
#       define      OMAP2_absentSubscriberReason_present 0x40
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                    * OMAP2_AbsentSubscriberParam_extensionContainer_present if
                    * present */
    OMAP2_AbsentSubscriberReason absentSubscriberReason;  /* extension #1;
                                   * optional; set in bit_mask
                                   * OMAP2_absentSubscriberReason_present if
                                   * present */
} OMAP2_AbsentSubscriberParam;

// exception handling: at reception of other values than the ones listed the 
// AbsentSubscriberReason shall be ignored.
typedef struct OMAP2_BusySubscriberParam {
    unsigned char   bit_mask;
#       define      OMAP2_BusySubscriberParam_extensionContainer_present 0x80
#       define      OMAP2_BusySubscriberParam_ccbs_Possible_present 0x40
#       define      OMAP2_ccbs_Busy_present 0x20
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                      * OMAP2_BusySubscriberParam_extensionContainer_present if
                      * present */
    Nulltype        ccbs_Possible;  /* extension #1; optional; set in bit_mask
                           * OMAP2_BusySubscriberParam_ccbs_Possible_present if
                           * present */
    Nulltype        ccbs_Busy;  /* extension #2; optional; set in bit_mask
                                 * OMAP2_ccbs_Busy_present if present */
} OMAP2_BusySubscriberParam;

typedef struct OMAP2_NoSubscriberReplyParam {
    unsigned char   bit_mask;
#       define      OMAP2_NoSubscriberReplyParam_extensionContainer_present 0x80
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                   * OMAP2_NoSubscriberReplyParam_extensionContainer_present if
                   * present */
} OMAP2_NoSubscriberReplyParam;

typedef struct OMAP2_ForwardingViolationParam {
    unsigned char   bit_mask;
#       define      OMAP2_ForwardingViolationParam_extensionContainer_present 0x80
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                 * OMAP2_ForwardingViolationParam_extensionContainer_present if
                 * present */
} OMAP2_ForwardingViolationParam;

typedef struct OMAP2_ForwardingFailedParam {
    unsigned char   bit_mask;
#       define      OMAP2_ForwardingFailedParam_extensionContainer_present 0x80
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                    * OMAP2_ForwardingFailedParam_extensionContainer_present if
                    * present */
} OMAP2_ForwardingFailedParam;

typedef struct OMAP2_ATI_NotAllowedParam {
    unsigned char   bit_mask;
#       define      OMAP2_ATI_NotAllowedParam_extensionContainer_present 0x80
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                      * OMAP2_ATI_NotAllowedParam_extensionContainer_present if
                      * present */
} OMAP2_ATI_NotAllowedParam;

typedef struct OMAP2_SubBusyForMT_SMS_Param {
    unsigned char   bit_mask;
#       define      OMAP2_SubBusyForMT_SMS_Param_extensionContainer_present 0x80
#       define      OMAP2_gprsConnectionSuspended_present 0x40
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                   * OMAP2_SubBusyForMT_SMS_Param_extensionContainer_present if
                   * present */
    Nulltype        gprsConnectionSuspended;  /* extension #1; optional; set in
                                   * bit_mask
                                   * OMAP2_gprsConnectionSuspended_present if
                                   * present */
} OMAP2_SubBusyForMT_SMS_Param;

	// If GprsConnectionSuspended is not understood it shall 
	// be discarded
typedef struct OMAP2_MessageWaitListFullParam {
    unsigned char   bit_mask;
#       define      OMAP2_MessageWaitListFullParam_extensionContainer_present 0x80
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                 * OMAP2_MessageWaitListFullParam_extensionContainer_present if
                 * present */
} OMAP2_MessageWaitListFullParam;

typedef struct OMAP2_ResourceLimitationParam {
    unsigned char   bit_mask;
#       define      OMAP2_ResourceLimitationParam_extensionContainer_present 0x80
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                  * OMAP2_ResourceLimitationParam_extensionContainer_present if
                  * present */
} OMAP2_ResourceLimitationParam;

typedef struct OMAP2_NoGroupCallNbParam {
    unsigned char   bit_mask;
#       define      OMAP2_NoGroupCallNbParam_extensionContainer_present 0x80
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                       * OMAP2_NoGroupCallNbParam_extensionContainer_present if
                       * present */
} OMAP2_NoGroupCallNbParam;

typedef struct OMAP2_IncompatibleTerminalParam {
    unsigned char   bit_mask;
#       define      OMAP2_IncompatibleTerminalParam_extensionContainer_present 0x80
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                * OMAP2_IncompatibleTerminalParam_extensionContainer_present if
                * present */
} OMAP2_IncompatibleTerminalParam;

typedef struct OMAP2_ShortTermDenialParam {
    char            placeholder;
} OMAP2_ShortTermDenialParam;

typedef struct OMAP2_LongTermDenialParam {
    char            placeholder;
} OMAP2_LongTermDenialParam;

typedef struct OMAP2_TraceReference {
    unsigned short  length;
    unsigned char   value[2];
} OMAP2_TraceReference;

typedef unsigned short  OMAP2_TraceType;

typedef struct OMAP2_ActivateTraceModeArg {
    unsigned char   bit_mask;
#       define      OMAP2_ActivateTraceModeArg_imsi_present 0x80
#       define      OMAP2_omc_Id_present 0x40
#       define      OMAP2_ActivateTraceModeArg_extensionContainer_present 0x20
    OMAP2_IMSI      imsi;  /* optional; set in bit_mask
                            * OMAP2_ActivateTraceModeArg_imsi_present if
                            * present */
    OMAP2_TraceReference traceReference;
    OMAP2_TraceType traceType;
    OMAP2_AddressString omc_Id;  /* optional; set in bit_mask
                                  * OMAP2_omc_Id_present if present */
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                     * OMAP2_ActivateTraceModeArg_extensionContainer_present if
                     * present */
} OMAP2_ActivateTraceModeArg;

	// Trace types are fully defined in TS GSM 12.08.
typedef struct OMAP2_ActivateTraceModeRes {
    unsigned char   bit_mask;
#       define      OMAP2_ActivateTraceModeRes_extensionContainer_present 0x80
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                     * OMAP2_ActivateTraceModeRes_extensionContainer_present if
                     * present */
} OMAP2_ActivateTraceModeRes;

typedef struct OMAP2_DeactivateTraceModeArg {
    unsigned char   bit_mask;
#       define      OMAP2_DeactivateTraceModeArg_imsi_present 0x80
#       define      OMAP2_DeactivateTraceModeArg_extensionContainer_present 0x40
    OMAP2_IMSI      imsi;  /* optional; set in bit_mask
                            * OMAP2_DeactivateTraceModeArg_imsi_present if
                            * present */
    OMAP2_TraceReference traceReference;
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                   * OMAP2_DeactivateTraceModeArg_extensionContainer_present if
                   * present */
} OMAP2_DeactivateTraceModeArg;

typedef struct OMAP2_DeactivateTraceModeRes {
    unsigned char   bit_mask;
#       define      OMAP2_DeactivateTraceModeRes_extensionContainer_present 0x80
    OMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                   * OMAP2_DeactivateTraceModeRes_extensionContainer_present if
                   * present */
} OMAP2_DeactivateTraceModeRes;

typedef OMAP2_ISDN_AddressString OMAP2_SendIMSIArg;

typedef OMAP2_IMSI      OMAP2_SendIMSIRes;

	// generic errors
	// identification and numbering errors
	// subscription errors
	// handover errors
	// operation and maintenance errors
	// call handling errors
	// any time interrogation errors
	// supplementary service errors
	// short message service errors
	// Group Call errors
// generic errors
typedef struct OMAP2_SystemFailure {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_SystemFailure;

		// optional
typedef struct OMAP2_DataMissing {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_DataMissing;

		// optional
		// dataMissingParam must not be used in version <3
typedef struct OMAP2_UnexpectedDataValue {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_UnexpectedDataValue;

		// optional
		// unexpectedDataParam must not be used in version <3
typedef struct OMAP2_FacilityNotSupported {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_FacilityNotSupported;

		// optional
		// facilityNotSupParam must not be used in version <3
typedef struct OMAP2_IncompatibleTerminal {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_IncompatibleTerminal;

		// optional
typedef struct OMAP2_ResourceLimitation {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_ResourceLimitation;

		// optional

// identification and numbering errors
typedef struct OMAP2_UnknownSubscriber {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_UnknownSubscriber;

		// optional
		// unknownSubscriberParam must not be used in version <3
typedef struct OMAP2_NumberChanged {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_NumberChanged;

		// optional
typedef struct OMAP2_UnknownMSC {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_UnknownMSC;

typedef struct OMAP2_UnidentifiedSubscriber {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_UnidentifiedSubscriber;

		// optional
		// unidentifiedSubParam must not be used in version <3
typedef struct OMAP2_UnknownEquipment {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_UnknownEquipment;

// subscription errors
typedef struct OMAP2_RoamingNotAllowed {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_RoamingNotAllowed;

typedef struct OMAP2_IllegalSubscriber {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_IllegalSubscriber;

		// optional
		// illegalSubscriberParam must not be used in version <3
typedef struct OMAP2_IllegalEquipment {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_IllegalEquipment;

		// optional
		// illegalEquipmentParam must not be used in version <3
typedef struct OMAP2_BearerServiceNotProvisioned {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_BearerServiceNotProvisioned;

		// optional
		// bearerServNotProvParam must not be used in version <3
typedef struct OMAP2_TeleserviceNotProvisioned {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_TeleserviceNotProvisioned;

		// optional
		// teleservNotProvParam must not be used in version <3

// handover errors
typedef struct OMAP2_NoHandoverNumberAvailable {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_NoHandoverNumberAvailable;

typedef struct OMAP2_SubsequentHandoverFailure {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_SubsequentHandoverFailure;

// operation and maintenance errors
typedef struct OMAP2_TracingBufferFull {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_TracingBufferFull;

		// optional

// call handling errors
typedef struct OMAP2_NoRoamingNumberAvailable {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_NoRoamingNumberAvailable;

		// optional
typedef struct OMAP2_AbsentSubscriber {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_AbsentSubscriber;

		// optional

		// absentSubscriberParam must not be used in version <3
typedef struct OMAP2_BusySubscriber {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_BusySubscriber;

		// optional
typedef struct OMAP2_NoSubscriberReply {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_NoSubscriberReply;

		// optional
typedef struct OMAP2_CallBarred {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_CallBarred;

		// optional
typedef struct OMAP2_ForwardingViolation {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_ForwardingViolation;

		// optional
typedef struct OMAP2_ForwardingFailed {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_ForwardingFailed;

		// optional
typedef struct OMAP2_CUG_Reject {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_CUG_Reject;

		// optional
typedef struct OMAP2_OR_NotAllowed {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_OR_NotAllowed;

		// optional

// any time interrogation errors
typedef struct OMAP2_ATI_NotAllowed {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_ATI_NotAllowed;

		// optional

// supplementary service errors
typedef struct OMAP2_IllegalSS_Operation {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_IllegalSS_Operation;

typedef struct OMAP2_SS_ErrorStatus {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_SS_ErrorStatus;

		// optional
typedef struct OMAP2_SS_NotAvailable {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_SS_NotAvailable;

typedef struct OMAP2_SS_SubscriptionViolation {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_SS_SubscriptionViolation;

typedef struct OMAP2_SS_Incompatibility {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_SS_Incompatibility;

		// optional
typedef struct OMAP2_UnknownAlphabet {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_UnknownAlphabet;

typedef struct OMAP2_USSD_Busy {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_USSD_Busy;

typedef struct OMAP2_PW_RegistrationFailure {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_PW_RegistrationFailure;

typedef struct OMAP2_NegativePW_Check {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_NegativePW_Check;

typedef struct OMAP2_NumberOfPW_AttemptsViolation {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_NumberOfPW_AttemptsViolation;

typedef struct OMAP2_ShortTermDenial {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_ShortTermDenial;

		// optional
typedef struct OMAP2_LongTermDenial {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_LongTermDenial;

		// optional

// short message service errors
typedef struct OMAP2_SubscriberBusyForMT_SMS {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_SubscriberBusyForMT_SMS;

		// optional
typedef struct OMAP2_SM_DeliveryFailure {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_SM_DeliveryFailure;

typedef struct OMAP2_MessageWaitingListFull {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_MessageWaitingListFull;

		// optional
typedef struct OMAP2_AbsentSubscriberSM {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_AbsentSubscriberSM;

		// optional

// Group Call errors
typedef struct OMAP2_NoGroupCallNumberAvailable {
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_NoGroupCallNumberAvailable;
		// optional

typedef struct OMAP2_ActivateTraceMode {                         /*Timer m*/
		// optional
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_ActivateTraceMode;

typedef struct OMAP2_DeactivateTraceMode {                               /*Timer m*/
		// optional
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_DeactivateTraceMode;

typedef struct OMAP2_SendIMSI {                          /*Timer m*/
    unsigned short  choice;
#       define      OMAP2_localValue_chosen 1
#       define      OMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * OMAP2_localValue_chosen */
        struct OMAP2__ObjectID_ *globalValue;  /* to choose, set choice to
                                                * OMAP2_globalValue_chosen */
    } u;
} OMAP2_SendIMSI;

typedef struct OMAP2__octet1 {
    unsigned short  length;
    unsigned char   value[20];
} OMAP2__octet1;

typedef struct OMAP2__seq3 {
    char            placeholder;
} OMAP2__seq3;

typedef enum OMAP2__enum1 {
    OMAP2_reason_noReasonGiven = 0,
    OMAP2_reason_invalidDestinationReference = 1,
    OMAP2_reason_invalidOriginatingReference = 2
} OMAP2__enum1;

typedef enum OMAP2__enum2 {
    OMAP2_resourceUnavailable_shortTermResourceLimitation = 0,
    OMAP2_resourceUnavailable_longTermResourceLimitation = 1
} OMAP2__enum2;

typedef enum OMAP2__enum3 {
    OMAP2_applicationProcedureCancellation_handoverCancellation = 0,
    OMAP2_applicationProcedureCancellation_radioChannelRelease = 1,
    OMAP2_applicationProcedureCancellation_networkPathRelease = 2,
    OMAP2_applicationProcedureCancellation_callRelease = 3,
    OMAP2_applicationProcedureCancellation_associatedProcedureFailure = 4,
    OMAP2_applicationProcedureCancellation_tandemDialogueRelease = 5,
    OMAP2_applicationProcedureCancellation_remoteOperationsFailure = 6
} OMAP2__enum3;

typedef struct OMAP2__choice6 {
    unsigned short  choice;
#       define      OMAP2_map_UserAbortChoice_userSpecificReason_chosen 1
#       define      OMAP2_map_UserAbortChoice_userResourceLimitation_chosen 2
#       define      OMAP2_map_UserAbortChoice_resourceUnavailable_chosen 3
#       define      OMAP2_map_UserAbortChoice_applicationProcedureCancellation_chosen 4
    union _union {
        Nulltype        userSpecificReason;  /* to choose, set choice to
                       * OMAP2_map_UserAbortChoice_userSpecificReason_chosen */
        Nulltype        userResourceLimitation;  /* to choose, set choice to
                   * OMAP2_map_UserAbortChoice_userResourceLimitation_chosen */
        OMAP2__enum2    resourceUnavailable;  /* to choose, set choice to
                      * OMAP2_map_UserAbortChoice_resourceUnavailable_chosen */
        OMAP2__enum3    applicationProcedureCancellation;  /* to choose, set
                                   * choice to
         * OMAP2_map_UserAbortChoice_applicationProcedureCancellation_chosen */
    } u;
} OMAP2__choice6;

typedef enum OMAP2__enum4 {
    OMAP2_map_ProviderAbortReason_abnormalDialogue = 0,
    OMAP2_map_ProviderAbortReason_invalidPDU = 1
} OMAP2__enum4;

typedef struct OMAP2_DialoguePDU {
    unsigned short  choice;
#       define      OMAP2_map_open_chosen 1
#       define      OMAP2_map_accept_chosen 2
#       define      OMAP2_map_close_chosen 3
#       define      OMAP2_map_refuse_chosen 4
#       define      OMAP2_map_userAbort_chosen 5
#       define      OMAP2_map_providerAbort_chosen 6
    union _union {
        struct OMAP2__seq2 {
            unsigned char   bit_mask;
#               define      OMAP2_map_open_destinationReference_present 0x80
#               define      OMAP2_map_open_originationReference_present 0x40
            OMAP2__octet1   destinationReference;  /* optional; set in bit_mask
                               * OMAP2_map_open_destinationReference_present if
                               * present */
            OMAP2__octet1   originationReference;  /* optional; set in bit_mask
                               * OMAP2_map_open_originationReference_present if
                               * present */
        } map_open;  /* to choose, set choice to OMAP2_map_open_chosen */
        OMAP2__seq3     map_accept;  /* to choose, set choice to
                                      * OMAP2_map_accept_chosen */
        OMAP2__seq3     map_close;  /* to choose, set choice to
                                     * OMAP2_map_close_chosen */
        struct OMAP2__seq4 {
            OMAP2__enum1    reason;
        } map_refuse;  /* to choose, set choice to OMAP2_map_refuse_chosen */
        struct OMAP2__seq5 {
            OMAP2__choice6  map_UserAbortChoice;
        } map_userAbort;  /* to choose, set choice to
                           * OMAP2_map_userAbort_chosen */
        struct OMAP2__seq6 {
            OMAP2__enum4    map_ProviderAbortReason;
        } map_providerAbort;  /* to choose, set choice to
                               * OMAP2_map_providerAbort_chosen */
    } u;
} OMAP2_DialoguePDU;

typedef struct OMAP2_OpenInfo {
    unsigned char   bit_mask;
#       define      OMAP2_OpenInfo_destinationReference_present 0x80
#       define      OMAP2_OpenInfo_originationReference_present 0x40
    OMAP2__octet1   destinationReference;  /* optional; set in bit_mask
                               * OMAP2_OpenInfo_destinationReference_present if
                               * present */
    OMAP2__octet1   originationReference;  /* optional; set in bit_mask
                               * OMAP2_OpenInfo_originationReference_present if
                               * present */
} OMAP2_OpenInfo;

typedef struct OMAP2_AcceptInfo {
    char            placeholder;
} OMAP2_AcceptInfo;

typedef struct OMAP2_CloseInfo {
    char            placeholder;
} OMAP2_CloseInfo;

typedef struct OMAP2_RefuseInfo {
    OMAP2__enum1    reason;
} OMAP2_RefuseInfo;

typedef struct OMAP2_UserAbortInfo {
    OMAP2__choice6  map_UserAbortChoice;
} OMAP2_UserAbortInfo;

typedef struct OMAP2_UserAbortChoice {
    unsigned short  choice;
#       define      OMAP2_UserAbortChoice_userSpecificReason_chosen 1
#       define      OMAP2_UserAbortChoice_userResourceLimitation_chosen 2
#       define      OMAP2_UserAbortChoice_resourceUnavailable_chosen 3
#       define      OMAP2_UserAbortChoice_applicationProcedureCancellation_chosen 4
    union _union {
        Nulltype        userSpecificReason;  /* to choose, set choice to
                           * OMAP2_UserAbortChoice_userSpecificReason_chosen */
        Nulltype        userResourceLimitation;  /* to choose, set choice to
                       * OMAP2_UserAbortChoice_userResourceLimitation_chosen */
        OMAP2__enum2    resourceUnavailable;  /* to choose, set choice to
                          * OMAP2_UserAbortChoice_resourceUnavailable_chosen */
        OMAP2__enum3    applicationProcedureCancellation;  /* to choose, set
                                   * choice to
             * OMAP2_UserAbortChoice_applicationProcedureCancellation_chosen */
    } u;
} OMAP2_UserAbortChoice;

typedef struct OMAP2_ProviderAbortInfo {
    OMAP2__enum4    map_ProviderAbortReason;
} OMAP2_ProviderAbortInfo;

#ifndef _OSSNOVALUES

extern const int OMAP2_maxNumOfPrivateExtensions;

	// This type is used to represent the code identifying a single
	// bearer service, a group of bearer services, or all bearer
	// services. The services are defined in TS GSM 02.02.
	// The internal structure is defined as follows:
	//
	// OCTET 1:
	// plmn-specific bearer services:
	// bits 87654321: defined by the HPLMN operator
	//
	// rest of bearer services:
	// bit 8: 0 (unused)
	// bits 7654321: group (bits 7654), and rate, if applicable
	// (bits 321)

	// OCTETS 2-5: reserved for future use. If received the
    // Ext-TeleserviceCode shall be
	// treated according to the exception handling defined for the
	// operation that uses this type. 

	// Ext-BearerServiceCode includes all values defined for BearerServiceCode.
extern OMAP2_BearerServiceCode OMAP2_allBearerServices;

extern OMAP2_BearerServiceCode OMAP2_allDataCDA_Services;

extern OMAP2_BearerServiceCode OMAP2_dataCDA_300bps;

extern OMAP2_BearerServiceCode OMAP2_dataCDA_1200bps;

extern OMAP2_BearerServiceCode OMAP2_dataCDA_1200_75bps;

extern OMAP2_BearerServiceCode OMAP2_dataCDA_2400bps;

extern OMAP2_BearerServiceCode OMAP2_dataCDA_4800bps;

extern OMAP2_BearerServiceCode OMAP2_dataCDA_9600bps;

extern OMAP2_BearerServiceCode OMAP2_general_dataCDA;

extern OMAP2_BearerServiceCode OMAP2_allDataCDS_Services;

extern OMAP2_BearerServiceCode OMAP2_dataCDS_1200bps;

extern OMAP2_BearerServiceCode OMAP2_dataCDS_2400bps;

extern OMAP2_BearerServiceCode OMAP2_dataCDS_4800bps;

extern OMAP2_BearerServiceCode OMAP2_dataCDS_9600bps;

extern OMAP2_BearerServiceCode OMAP2_general_dataCDS;

extern OMAP2_BearerServiceCode OMAP2_allPadAccessCA_Services;

extern OMAP2_BearerServiceCode OMAP2_padAccessCA_300bps;

extern OMAP2_BearerServiceCode OMAP2_padAccessCA_1200bps;

extern OMAP2_BearerServiceCode OMAP2_padAccessCA_1200_75bps;

extern OMAP2_BearerServiceCode OMAP2_padAccessCA_2400bps;

extern OMAP2_BearerServiceCode OMAP2_padAccessCA_4800bps;

extern OMAP2_BearerServiceCode OMAP2_padAccessCA_9600bps;

extern OMAP2_BearerServiceCode OMAP2_general_padAccessCA;

extern OMAP2_BearerServiceCode OMAP2_allDataPDS_Services;

extern OMAP2_BearerServiceCode OMAP2_dataPDS_2400bps;

extern OMAP2_BearerServiceCode OMAP2_dataPDS_4800bps;

extern OMAP2_BearerServiceCode OMAP2_dataPDS_9600bps;

extern OMAP2_BearerServiceCode OMAP2_general_dataPDS;

extern OMAP2_BearerServiceCode OMAP2_allAlternateSpeech_DataCDA;

extern OMAP2_BearerServiceCode OMAP2_allAlternateSpeech_DataCDS;

extern OMAP2_BearerServiceCode OMAP2_allSpeechFollowedByDataCDA;

extern OMAP2_BearerServiceCode OMAP2_allSpeechFollowedByDataCDS;

// The following non-hierarchical Compound Bearer Service
// Groups are defined in TS GSM 02.30:
extern OMAP2_BearerServiceCode OMAP2_allDataCircuitAsynchronous;

	// covers "allDataCDA-Services", "allAlternateSpeech-DataCDA" and
	// "allSpeechFollowedByDataCDA"
extern OMAP2_BearerServiceCode OMAP2_allAsynchronousServices;

	// covers "allDataCDA-Services", "allAlternateSpeech-DataCDA",
	// "allSpeechFollowedByDataCDA" and "allPadAccessCDA-Services"
extern OMAP2_BearerServiceCode OMAP2_allDataCircuitSynchronous;

	// covers "allDataCDS-Services", "allAlternateSpeech-DataCDS" and
	// "allSpeechFollowedByDataCDS"
extern OMAP2_BearerServiceCode OMAP2_allSynchronousServices;

	// covers "allDataCDS-Services", "allAlternateSpeech-DataCDS",
	// "allSpeechFollowedByDataCDS" and "allDataPDS-Services"
//
extern OMAP2_BearerServiceCode OMAP2_allPLMN_specificBS;

extern OMAP2_BearerServiceCode OMAP2_plmn_specificBS_1;

extern OMAP2_BearerServiceCode OMAP2_plmn_specificBS_2;

extern OMAP2_BearerServiceCode OMAP2_plmn_specificBS_3;

extern OMAP2_BearerServiceCode OMAP2_plmn_specificBS_4;

extern OMAP2_BearerServiceCode OMAP2_plmn_specificBS_5;

extern OMAP2_BearerServiceCode OMAP2_plmn_specificBS_6;

extern OMAP2_BearerServiceCode OMAP2_plmn_specificBS_7;

extern OMAP2_BearerServiceCode OMAP2_plmn_specificBS_8;

extern OMAP2_BearerServiceCode OMAP2_plmn_specificBS_9;

extern OMAP2_BearerServiceCode OMAP2_plmn_specificBS_A;

extern OMAP2_BearerServiceCode OMAP2_plmn_specificBS_B;

extern OMAP2_BearerServiceCode OMAP2_plmn_specificBS_C;

extern OMAP2_BearerServiceCode OMAP2_plmn_specificBS_D;

extern OMAP2_BearerServiceCode OMAP2_plmn_specificBS_E;

extern OMAP2_BearerServiceCode OMAP2_plmn_specificBS_F;

	// This type is used to represent the code identifying a single
	// supplementary service, a group of supplementary services, or
	// all supplementary services. The services and abbreviations
	// used are defined in TS GSM 02.04. The internal structure is
	// defined as follows:
	//
	// bits 87654321: group (bits 8765), and specific service
	// (bits 4321)
extern OMAP2_SS_Code OMAP2_allSS;

	// reserved for possible future use
	// all SS
extern OMAP2_SS_Code OMAP2_allLineIdentificationSS;

	// reserved for possible future use
	// all line identification SS
extern OMAP2_SS_Code OMAP2_clip;

	// calling line identification presentation
extern OMAP2_SS_Code OMAP2_clir;

	// calling line identification restriction
extern OMAP2_SS_Code OMAP2_colp;

	// connected line identification presentation
extern OMAP2_SS_Code OMAP2_colr;

	// connected line identification restriction
extern OMAP2_SS_Code OMAP2_mci;

	// reserved for possible future use
	// malicious call identification
extern OMAP2_SS_Code OMAP2_allNameIdentificationSS;

	// all name identification SS
extern OMAP2_SS_Code OMAP2_cnap;

	// calling name presentation

	// SS-Codes '00011010'B to '00011111'B are reserved for future 
	// NameIdentification Supplementary Service use.
extern OMAP2_SS_Code OMAP2_allForwardingSS;

	// all forwarding SS
extern OMAP2_SS_Code OMAP2_cfu;

	// call forwarding unconditional
extern OMAP2_SS_Code OMAP2_allCondForwardingSS;

	// all conditional forwarding SS
extern OMAP2_SS_Code OMAP2_cfb;

	// call forwarding on mobile subscriber busy
extern OMAP2_SS_Code OMAP2_cfnry;

	// call forwarding on no reply
extern OMAP2_SS_Code OMAP2_cfnrc;

	// call forwarding on mobile subscriber not reachable 
extern OMAP2_SS_Code OMAP2_cd;

	// call deflection
extern OMAP2_SS_Code OMAP2_allCallOfferingSS;

	// reserved for possible future use
	// all call offering SS includes also all forwarding SS
extern OMAP2_SS_Code OMAP2_ect;

		// explicit call transfer
extern OMAP2_SS_Code OMAP2_mah;

	// reserved for possible future use
	// mobile access hunting
extern OMAP2_SS_Code OMAP2_allCallCompletionSS;

	// reserved for possible future use
	// all Call completion SS
extern OMAP2_SS_Code OMAP2_cw;

	// call waiting
extern OMAP2_SS_Code OMAP2_hold;

	// call hold
extern OMAP2_SS_Code OMAP2_ccbs_A;

	// completion of call to busy subscribers, originating side
extern OMAP2_SS_Code OMAP2_ccbs_B;

	// completion of call to busy subscribers, destination side
	// this SS-Code is used only in InsertSubscriberData
extern OMAP2_SS_Code OMAP2_allMultiPartySS;

	// reserved for possible future use
	// all multiparty SS
extern OMAP2_SS_Code OMAP2_multiPTY;

	// multiparty
extern OMAP2_SS_Code OMAP2_allCommunityOfInterest_SS;

	// reserved for possible future use
	// all community of interest SS
extern OMAP2_SS_Code OMAP2_cug;

	// closed user group
extern OMAP2_SS_Code OMAP2_allChargingSS;

	// reserved for possible future use
	// all charging SS
extern OMAP2_SS_Code OMAP2_aoci;

	// advice of charge information
extern OMAP2_SS_Code OMAP2_aocc;

	// advice of charge charging
extern OMAP2_SS_Code OMAP2_allAdditionalInfoTransferSS;

	// reserved for possible future use
	// all additional information transfer SS
extern OMAP2_SS_Code OMAP2_uus;

	// reserved for possible future use
	// UUS user-to-user signalling
extern OMAP2_SS_Code OMAP2_allBarringSS;

	// all barring SS
extern OMAP2_SS_Code OMAP2_barringOfOutgoingCalls;

	// barring of outgoing calls
extern OMAP2_SS_Code OMAP2_baoc;

	// barring of all outgoing calls
extern OMAP2_SS_Code OMAP2_boic;

	// barring of outgoing international calls
extern OMAP2_SS_Code OMAP2_boicExHC;

	// barring of outgoing international calls except those directed
	// to the home PLMN
extern OMAP2_SS_Code OMAP2_barringOfIncomingCalls;

	// barring of incoming calls
extern OMAP2_SS_Code OMAP2_baic;

	// barring of all incoming calls
extern OMAP2_SS_Code OMAP2_bicRoam;

	// barring of incoming calls when roaming outside home PLMN
	// Country
extern OMAP2_SS_Code OMAP2_allPLMN_specificSS;

extern OMAP2_SS_Code OMAP2_plmn_specificSS_1;

extern OMAP2_SS_Code OMAP2_plmn_specificSS_2;

extern OMAP2_SS_Code OMAP2_plmn_specificSS_3;

extern OMAP2_SS_Code OMAP2_plmn_specificSS_4;

extern OMAP2_SS_Code OMAP2_plmn_specificSS_5;

extern OMAP2_SS_Code OMAP2_plmn_specificSS_6;

extern OMAP2_SS_Code OMAP2_plmn_specificSS_7;

extern OMAP2_SS_Code OMAP2_plmn_specificSS_8;

extern OMAP2_SS_Code OMAP2_plmn_specificSS_9;

extern OMAP2_SS_Code OMAP2_plmn_specificSS_A;

extern OMAP2_SS_Code OMAP2_plmn_specificSS_B;

extern OMAP2_SS_Code OMAP2_plmn_specificSS_C;

extern OMAP2_SS_Code OMAP2_plmn_specificSS_D;

extern OMAP2_SS_Code OMAP2_plmn_specificSS_E;

extern OMAP2_SS_Code OMAP2_plmn_specificSS_F;

extern OMAP2_SS_Code OMAP2_allCallPrioritySS;

	// reserved for possible future use
	// all call priority SS
extern OMAP2_SS_Code OMAP2_emlpp;
	// enhanced Multilevel Precedence Pre-emption (EMLPP) service

extern const int OMAP2_SS_DataTypes_maxNumOfCUG;

extern const int OMAP2_maxNumOfCCBS_Requests;

	// The structure of the contents of the USSD-String is dependent
	// on the USSD-DataCodingScheme as described in TS GSM 03.38.
extern const int OMAP2_maxUSSD_StringLength;

extern const int OMAP2_maxNumOfSS;

extern const int OMAP2_maxNumOfBasicServiceGroups;

extern const int OMAP2_maxEventSpecification;

	// This type is used to represent a number for addressing
	// purposes. It is composed of
	//	a)	one octet for nature of address, and numbering plan
	//		indicator.
	//	b)	digits of an address encoded as TBCD-String.

	// a)	The first octet includes a one bit extension indicator, a
	//		3 bits nature of address indicator and a 4 bits numbering
	//		plan indicator, encoded as follows:

	// bit 8: 1  (no extension)

	// bits 765: nature of address indicator
	//	000  unknown
	//	001  international number
	//	010  national significant number
	//	011  network specific number
	//	100  subscriber number
	//	101  reserved
	//	110  abbreviated number
	//	111  reserved for extension

	// bits 4321: numbering plan indicator
	//	0000  unknown
	//	0001  ISDN/Telephony Numbering Plan (Rec CCITT E.164)
	//	0010  spare
	//	0011  data numbering plan (CCITT Rec X.121)
	//	0100  telex numbering plan (CCITT Rec F.69)
	//	0101  spare
	//	0110  land mobile numbering plan (CCITT Rec E.212)
	//	0111  spare
	//	1000  national numbering plan
	//	1001  private numbering plan
	//	1111  reserved for extension

	//	all other values are reserved.

	// b)	The following octets representing digits of an address
	//		encoded as a TBCD-STRING.
extern const int OMAP2_maxAddressLength;

	// This type is used to represent ISDN numbers.
extern const int OMAP2_maxISDN_AddressLength;

      // This type is used to represent forwarded-to numbers.
      // For long forwarded-to numbers (longer than 15 digits) NPI shall be unknown;
      // if NAI = international the first digits represent the country code (CC)
      // and the network destination code (NDC) as for E.164.
extern const int OMAP2_maxFTN_AddressLength;

	// This type is used to represent ISDN subaddresses.
	// It is composed of
	//	a)	one octet for type of subaddress and odd/even indicator.
	//	b)	20 octets for subaddress information.

	//	a)	The first octet includes a one bit extension indicator, a
	//		3 bits type of subaddress and a one bit odd/even indicator,
	//		encoded as follows:

	//	bit 8: 1  (no extension)

	//	bits 765: type of subaddress
	//		000  NSAP (X.213/ISO 8348 AD2)
	//		010  User Specified
	//		All other values are reserved

	//	bit 4: odd/even indicator
	//		0  even number of address signals
	//		1  odd number of address signals
	//		The odd/even indicator is used when the type of subaddress
	//		is "user specified" and the coding is BCD.

	//	bits 321: 000 (unused)

	//	b) Subaddress information.
	//	The NSAP X.213/ISO8348AD2 address shall be formatted as specified
	//	by octet 4 which contains the Authority and Format Identifier
	//	(AFI). The encoding is made according to the "preferred binary
	//	encoding" as defined in X.213/ISO834AD2. For the definition
	//	of this type of subaddress, see CCITT Rec I.334.

	//	For User-specific subaddress, this field is encoded according
	//	to the user specification, subject to a maximum length of 20
	//	octets. When interworking with X.25 networks BCD coding should
	//	be applied.
extern const int OMAP2_maxISDN_SubaddressLength;

extern const int OMAP2_maxSignalInfoLength;

	// This type is used to represent Alerting Pattern

	//	bits 8765 : 0000 (unused)

	//	bits 43 : type of Pattern
	//		00 level
	//		01 category
	//		10 category
	//		all other values are reserved.

	//	bits 21 : type of alerting
extern OMAP2_AlertingPattern OMAP2_alertingLevel_0;

extern OMAP2_AlertingPattern OMAP2_alertingLevel_1;

extern OMAP2_AlertingPattern OMAP2_alertingLevel_2;

	// all other values of Alerting level are reserved
	// Alerting Levels are defined in GSM 02.07
extern OMAP2_AlertingPattern OMAP2_alertingCategory_1;

extern OMAP2_AlertingPattern OMAP2_alertingCategory_2;

extern OMAP2_AlertingPattern OMAP2_alertingCategory_3;

extern OMAP2_AlertingPattern OMAP2_alertingCategory_4;

extern OMAP2_AlertingPattern OMAP2_alertingCategory_5;

extern const int OMAP2_maxNumOfHLR_Id;

extern const int OMAP2_maxNumOfMC_Bearers;

extern const OMAP2_EMLPP_Priority OMAP2_priorityLevelA;

extern const OMAP2_EMLPP_Priority OMAP2_priorityLevelB;

extern const OMAP2_EMLPP_Priority OMAP2_priorityLevel0;

extern const OMAP2_EMLPP_Priority OMAP2_priorityLevel1;

extern const OMAP2_EMLPP_Priority OMAP2_priorityLevel2;

extern const OMAP2_EMLPP_Priority OMAP2_priorityLevel3;

extern const OMAP2_EMLPP_Priority OMAP2_priorityLevel4;

extern const int OMAP2_maxNumOfBearerServices;

extern const int OMAP2_maxNumOfTeleservices;

extern const int OMAP2_MS_DataTypes_maxNumOfCUG;

extern const int OMAP2_maxNumOfExt_BasicServiceGroups;

	// internal structure is defined in TS GSM 03.03
extern const int OMAP2_maxNumOfZoneCodes;

extern const int OMAP2_maxNumOfBasicServices;

extern const int OMAP2_maxNumOfVBSGroupIds;

extern const int OMAP2_maxNumOfVGCSGroupIds;

	// This type is used to represent the code identifying a single
	// teleservice, a group of teleservices, or all teleservices. The
	// services are defined in TS GSM 02.03.
	// The internal structure is defined as follows:

	// OCTET 1:
	// bits 87654321: group (bits 8765) and specific service
	// (bits 4321)

	// OCTETS 2-5: reserved for future use. If received the
    // Ext-TeleserviceCode shall be
 	// treated according to the exception handling defined for the
	// operation that uses this type.

	// Ext-TeleserviceCode includes all values defined for TeleserviceCode.
extern OMAP2_TeleserviceCode OMAP2_allTeleservices;

extern OMAP2_TeleserviceCode OMAP2_allSpeechTransmissionServices;

extern OMAP2_TeleserviceCode OMAP2_telephony;

extern OMAP2_TeleserviceCode OMAP2_emergencyCalls;

extern OMAP2_TeleserviceCode OMAP2_allShortMessageServices;

extern OMAP2_TeleserviceCode OMAP2_shortMessageMT_PP;

extern OMAP2_TeleserviceCode OMAP2_shortMessageMO_PP;

extern OMAP2_TeleserviceCode OMAP2_allFacsimileTransmissionServices;

extern OMAP2_TeleserviceCode OMAP2_facsimileGroup3AndAlterSpeech;

extern OMAP2_TeleserviceCode OMAP2_automaticFacsimileGroup3;

extern OMAP2_TeleserviceCode OMAP2_facsimileGroup4;

// The following non-hierarchical Compound Teleservice Groups
// are defined in TS GSM 02.30:
extern OMAP2_TeleserviceCode OMAP2_allDataTeleservices;

	// covers Teleservice Groups 'allFacsimileTransmissionServices'
	// and 'allShortMessageServices'
extern OMAP2_TeleserviceCode OMAP2_allTeleservices_ExeptSMS;

	// covers Teleservice Groups 'allSpeechTransmissionServices' and
	// 'allFacsimileTransmissionServices'
//
// Compound Teleservice Group Codes are only used in call
// independent supplementary service operations, i.e. they
// are not used in InsertSubscriberData or in
// DeleteSubscriberData messages.
extern OMAP2_TeleserviceCode OMAP2_allVoiceGroupCallServices;

extern OMAP2_TeleserviceCode OMAP2_voiceGroupCall;

extern OMAP2_TeleserviceCode OMAP2_voiceBroadcastCall;

extern OMAP2_TeleserviceCode OMAP2_allPLMN_specificTS;

extern OMAP2_TeleserviceCode OMAP2_plmn_specificTS_1;

extern OMAP2_TeleserviceCode OMAP2_plmn_specificTS_2;

extern OMAP2_TeleserviceCode OMAP2_plmn_specificTS_3;

extern OMAP2_TeleserviceCode OMAP2_plmn_specificTS_4;

extern OMAP2_TeleserviceCode OMAP2_plmn_specificTS_5;

extern OMAP2_TeleserviceCode OMAP2_plmn_specificTS_6;

extern OMAP2_TeleserviceCode OMAP2_plmn_specificTS_7;

extern OMAP2_TeleserviceCode OMAP2_plmn_specificTS_8;

extern OMAP2_TeleserviceCode OMAP2_plmn_specificTS_9;

extern OMAP2_TeleserviceCode OMAP2_plmn_specificTS_A;

extern OMAP2_TeleserviceCode OMAP2_plmn_specificTS_B;

extern OMAP2_TeleserviceCode OMAP2_plmn_specificTS_C;

extern OMAP2_TeleserviceCode OMAP2_plmn_specificTS_D;

extern OMAP2_TeleserviceCode OMAP2_plmn_specificTS_E;

extern OMAP2_TeleserviceCode OMAP2_plmn_specificTS_F;

extern OMAP2__ObjectID OMAP2_map_DialogueAS;

// location registration operation codes
extern OMAP2_UpdateLocation OMAP2_updateLocation;

extern OMAP2_CancelLocation OMAP2_cancelLocation;

extern OMAP2_PurgeMS OMAP2_purgeMS;

extern OMAP2_SendIdentification OMAP2_sendIdentification;

// handover operation codes
extern OMAP2_PrepareHandover OMAP2_prepareHandover;

extern OMAP2_SendEndSignal OMAP2_sendEndSignal;

extern OMAP2_ProcessAccessSignalling OMAP2_processAccessSignalling;

extern OMAP2_ForwardAccessSignalling OMAP2_forwardAccessSignalling;

extern OMAP2_PrepareSubsequentHandover OMAP2_prepareSubsequentHandover;

// authentication operation codes
extern OMAP2_SendAuthenticationInfo OMAP2_sendAuthenticationInfo;

// IMEI MANAGEMENT operation codes
extern OMAP2_CheckIMEI OMAP2_checkIMEI;

// subscriber management operation codes
extern OMAP2_InsertSubscriberData OMAP2_insertSubscriberData;

extern OMAP2_DeleteSubscriberData OMAP2_deleteSubscriberData;

extern OMAP2_Reset OMAP2_reset;

extern OMAP2_RestoreData OMAP2_restoreData;

// operation and maintenance operation codes
extern OMAP2_ActivateTraceMode OMAP2_activateTraceMode;

extern OMAP2_DeactivateTraceMode OMAP2_deactivateTraceMode;

extern OMAP2_SendIMSI OMAP2_sendIMSI;

// call handling operation codes
extern OMAP2_SendRoutingInfo OMAP2_sendRoutingInfo;

extern OMAP2_ProvideRoamingNumber OMAP2_provideRoamingNumber;

extern OMAP2_ResumeCallHandling OMAP2_resumeCallHandling;

extern OMAP2_ProvideSIWFSNumber OMAP2_provideSIWFSNumber;

extern OMAP2_SIWFSSignallingModify OMAP2_sIWFSSignallingModify;

// supplementary service handling operation codes
extern OMAP2_RegisterSS OMAP2_registerSS;

extern OMAP2_EraseSS OMAP2_eraseSS;

extern OMAP2_ActivateSS OMAP2_activateSS;

extern OMAP2_DeactivateSS OMAP2_deactivateSS;

extern OMAP2_InterrogateSS OMAP2_interrogateSS;

extern OMAP2_ProcessUnstructuredSS_Request OMAP2_processUnstructuredSS_Request;

extern OMAP2_UnstructuredSS_Request OMAP2_unstructuredSS_Request;

extern OMAP2_UnstructuredSS_Notify OMAP2_unstructuredSS_Notify;

extern OMAP2_RegisterPassword OMAP2_registerPassword;

extern OMAP2_GetPassword OMAP2_getPassword;

// short message service operation codes
extern OMAP2_SendRoutingInfoForSM OMAP2_sendRoutingInfoForSM;

extern OMAP2_MO_ForwardSM OMAP2_mo_forwardSM;

extern OMAP2_MT_ForwardSM OMAP2_mt_forwardSM;

extern OMAP2_ReportSM_DeliveryStatus OMAP2_reportSM_DeliveryStatus;

extern OMAP2_InformServiceCentre OMAP2_informServiceCentre;

extern OMAP2_AlertServiceCentre OMAP2_alertServiceCentre;

extern OMAP2_ReadyForSM OMAP2_readyForSM;

//Group Call operation codes
extern OMAP2_PrepareGroupCall OMAP2_prepareGroupCall;

extern OMAP2_SendGroupCallEndSignal OMAP2_sendGroupCallEndSignal;

extern OMAP2_ProcessGroupCallSignalling OMAP2_processGroupCallSignalling;

extern OMAP2_ForwardGroupCallSignalling OMAP2_forwardGroupCallSignalling;

// generic error codes
extern OMAP2_SystemFailure OMAP2_systemFailure;

extern OMAP2_DataMissing OMAP2_dataMissing;

extern OMAP2_UnexpectedDataValue OMAP2_unexpectedDataValue;

extern OMAP2_FacilityNotSupported OMAP2_facilityNotSupported;

extern OMAP2_IncompatibleTerminal OMAP2_incompatibleTerminal;

extern OMAP2_ResourceLimitation OMAP2_resourceLimitation;

// identification and numbering error codes
extern OMAP2_UnknownSubscriber OMAP2_unknownSubscriber;

extern OMAP2_NumberChanged OMAP2_numberChanged;

extern OMAP2_UnknownMSC OMAP2_unknownMSC;

extern OMAP2_UnidentifiedSubscriber OMAP2_unidentifiedSubscriber;

extern OMAP2_UnknownEquipment OMAP2_unknownEquipment;

// subscription error codes
extern OMAP2_RoamingNotAllowed OMAP2_roamingNotAllowed;

extern OMAP2_IllegalSubscriber OMAP2_illegalSubscriber;

extern OMAP2_IllegalEquipment OMAP2_illegalEquipment;

extern OMAP2_BearerServiceNotProvisioned OMAP2_bearerServiceNotProvisioned;

extern OMAP2_TeleserviceNotProvisioned OMAP2_teleserviceNotProvisioned;

// handover error codes
extern OMAP2_NoHandoverNumberAvailable OMAP2_noHandoverNumberAvailable;

extern OMAP2_SubsequentHandoverFailure OMAP2_subsequentHandoverFailure;

// operation and maintenance error codes
extern OMAP2_TracingBufferFull OMAP2_tracingBufferFull;

// call handling error codes
extern OMAP2_NoRoamingNumberAvailable OMAP2_noRoamingNumberAvailable;

extern OMAP2_AbsentSubscriber OMAP2_absentSubscriber;

extern OMAP2_BusySubscriber OMAP2_busySubscriber;

extern OMAP2_NoSubscriberReply OMAP2_noSubscriberReply;

extern OMAP2_CallBarred OMAP2_callBarred;

extern OMAP2_ForwardingFailed OMAP2_forwardingFailed;

extern OMAP2_OR_NotAllowed OMAP2_or_NotAllowed;

extern OMAP2_ForwardingViolation OMAP2_forwardingViolation;

extern OMAP2_CUG_Reject OMAP2_cug_Reject;

// any time interrogation error codes
extern OMAP2_ATI_NotAllowed OMAP2_ati_NotAllowed;

// Group Call error codes
extern OMAP2_NoGroupCallNumberAvailable OMAP2_noGroupCallNumberAvailable;

// supplementary service error codes
extern OMAP2_IllegalSS_Operation OMAP2_illegalSS_Operation;

extern OMAP2_SS_ErrorStatus OMAP2_ss_ErrorStatus;

extern OMAP2_SS_NotAvailable OMAP2_ss_NotAvailable;

extern OMAP2_SS_SubscriptionViolation OMAP2_ss_SubscriptionViolation;

extern OMAP2_SS_Incompatibility OMAP2_ss_Incompatibility;

extern OMAP2_UnknownAlphabet OMAP2_unknownAlphabet;

extern OMAP2_USSD_Busy OMAP2_ussd_Busy;

extern OMAP2_PW_RegistrationFailure OMAP2_pw_RegistrationFailure;

extern OMAP2_NegativePW_Check OMAP2_negativePW_Check;

extern OMAP2_NumberOfPW_AttemptsViolation OMAP2_numberOfPW_AttemptsViolation;

extern OMAP2_ShortTermDenial OMAP2_shortTermDenial;

extern OMAP2_LongTermDenial OMAP2_longTermDenial;

// short message service error codes
extern OMAP2_SubscriberBusyForMT_SMS OMAP2_subscriberBusyForMT_SMS;

extern OMAP2_SM_DeliveryFailure OMAP2_sm_DeliveryFailure;

extern OMAP2_MessageWaitingListFull OMAP2_messageWaitingListFull;

extern OMAP2_AbsentSubscriberSM OMAP2_absentsubscriberSM;
// The following operation codes are reserved for operations
// existing in previous versions of the protocol

// Operation Name	AC used	Oper. Code
// 
// sendParameters	map-ac infoRetrieval (14) version1 (1)	localValue 9
// processUnstructuredSS-Data	map-ac networkFunctionalSs (18) version1 (1)	localValue 19
// performHandover	map-ac handoverControl (11) version1 (1)	localValue 28
// performSubsequentHandover	map-ac handoverControl (11) version1 (1)	localValue 30
// noteInternalHandover	map-ac handoverControl (11) version1 (1)	localValue 35
// alertServiceCentreWithoutResult	map-ac shortMsgAlert (23) version1 (1)	localValue 49
// traceSubscriberActivity	map-ac handoverControl (11) version1 (1)	localValue 52
// beginSubscriberActivity	map-ac networkFunctionalSs (18) version1 (1)	localValue 54

// The following error codes are reserved for errors
// existing in previous versions of the protocol

// Error Name	AC used	Error Code
// 
// unknownBaseStation	map-ac handoverControl (11) version1 (1)	localValue 2
// invalidTargetBaseStation	map-ac handoverControl (11) version1 (1)	localValue 23
// noRadioResourceAvailable	map-ac handoverControl (11) version1 (1)	localValue 24

#endif  /* #ifndef _OSSNOVALUES */


extern void *OMAP2;    /* encoder-decoder control table */
#ifdef __cplusplus
}	/* extern "C" */
#endif /* __cplusplus */
#endif /* OSS_OMAP2 */
