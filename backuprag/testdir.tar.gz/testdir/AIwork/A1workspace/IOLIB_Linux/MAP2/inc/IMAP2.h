/*************************************************************/
/* Copyright (C) 2017 OSS Nokalva, Inc.  All rights reserved.*/
/*************************************************************/

/* THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC.
 * AND MAY BE USED ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC.
 * THIS FILE MAY NOT BE DISTRIBUTED.
 * THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED. */

/* Generated for: Plintron Global Technology Solutions Pvt. Ltd. - Site-based, License 75139 75139,
 * at GKS Tech Park, DLT IT SEZ, Chennai 600089, India. */
/* Abstract syntax: IMAP2 */
/* Created: Fri Oct  6 15:47:24 2017 */
/* ASN.1 compiler version: 10.5 */
/* Code generated for runtime version 10.5 or later */
/* Compiler operating system: Linux with 64-bit support */
/* Compiler machine type: AMD64 */
/* Target operating system: Linux with 64-bit support */
/* Target machine type: AMD64 */
/* C compiler options required: -m64 */
/* ASN.1 compiler options and file names specified:
 * -prefix IMAP2_ -c++ -nowarningmessages -ber -root -ignoreIncompleteItems
 * /usr/local/ossasn1/linux-x86-64/10.5.0//asn1dflt.linux-amd64 TCAP.asn
 * MAP-ExtensionDataTypes.asn MAP-ShortMessageServiceOperations.asn
 * MAP-BS-Code.asn MAP-GR-DataTypes.asn MAP-SM-DataTypes.asn
 * MAP-CallHandlingOperations.asn MAP-Group-Call-Operations.asn
 * MAP-SS-Code.asn MAP-CH-DataTypes.asn MAP-MobileServiceOperations.asn
 * MAP-SS-DataTypes.asn MAP-CommonDataTypes.asn MAP-MS-DataTypes.asn
 * MAP-SupplementaryServiceOperations.asn MAP-ER-DataTypes.asn
 * MAP-OM-DataTypes.asn MAP-TS-Code.asn MAP-Errors.asn
 * MAP-OperationAndMaintenanceOperations.asn MAP-DialogueInformation.asn
 * IMAP2.asn
 */

#ifndef OSS_IMAP2
#define OSS_IMAP2

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include "ossasn1.h"

#define          IMAP2_MessageType_PDU 1
#define          IMAP2_SendRoutingInfoForSM_PDU 2
#define          IMAP2_MO_ForwardSM_PDU 3
#define          IMAP2_MT_ForwardSM_PDU 4
#define          IMAP2_ReportSM_DeliveryStatus_PDU 5
#define          IMAP2_AlertServiceCentre_PDU 6
#define          IMAP2_InformServiceCentre_PDU 7
#define          IMAP2_ReadyForSM_PDU 8
#define          IMAP2_PrepareGroupCallArg_PDU 9
#define          IMAP2_PrepareGroupCallRes_PDU 10
#define          IMAP2_SendGroupCallEndSignalArg_PDU 11
#define          IMAP2_SendGroupCallEndSignalRes_PDU 12
#define          IMAP2_ForwardGroupCallSignallingArg_PDU 13
#define          IMAP2_ProcessGroupCallSignallingArg_PDU 14
#define          IMAP2_RoutingInfoForSM_Arg_PDU 15
#define          IMAP2_RoutingInfoForSM_Res_PDU 16
#define          IMAP2_Additional_Number_PDU 17
#define          IMAP2_MO_ForwardSM_Arg_PDU 18
#define          IMAP2_MO_ForwardSM_Res_PDU 19
#define          IMAP2_MT_ForwardSM_Arg_PDU 20
#define          IMAP2_MT_ForwardSM_Res_PDU 21
#define          IMAP2_ReportSM_DeliveryStatusArg_PDU 22
#define          IMAP2_ReportSM_DeliveryStatusRes_PDU 23
#define          IMAP2_AlertServiceCentreArg_PDU 24
#define          IMAP2_InformServiceCentreArg_PDU 25
#define          IMAP2_ReadyForSM_Arg_PDU 26
#define          IMAP2_ReadyForSM_Res_PDU 27
#define          IMAP2_SendRoutingInfo_PDU 28
#define          IMAP2_ProvideRoamingNumber_PDU 29
#define          IMAP2_ResumeCallHandling_PDU 30
#define          IMAP2_ProvideSIWFSNumber_PDU 31
#define          IMAP2_SIWFSSignallingModify_PDU 32
#define          IMAP2_PrepareGroupCall_PDU 33
#define          IMAP2_SendGroupCallEndSignal_PDU 34
#define          IMAP2_ProcessGroupCallSignalling_PDU 35
#define          IMAP2_ForwardGroupCallSignalling_PDU 36
#define          IMAP2_SendRoutingInfoArg_PDU 37
#define          IMAP2_SuppressionOfAnnouncement_PDU 38
#define          IMAP2_InterrogationType_PDU 39
#define          IMAP2_OR_Phase_PDU 40
#define          IMAP2_ForwardingReason_PDU 41
#define          IMAP2_SupportedCCBS_Phase_PDU 42
#define          IMAP2_SendRoutingInfoRes_PDU 43
#define          IMAP2_CCBS_Indicators_PDU 44
#define          IMAP2_ProvideRoamingNumberArg_PDU 45
#define          IMAP2_ProvideRoamingNumberRes_PDU 46
#define          IMAP2_ResumeCallHandlingRes_PDU 47
#define          IMAP2_ProvideSIWFSNumberArg_PDU 48
#define          IMAP2_ProvideSIWFSNumberRes_PDU 49
#define          IMAP2_SIWFSSignallingModifyArg_PDU 50
#define          IMAP2_SIWFSSignallingModifyRes_PDU 51
#define          IMAP2_StatusReportArg_PDU 52
#define          IMAP2_StatusReportRes_PDU 53
#define          IMAP2_UpdateLocation_PDU 54
#define          IMAP2_CancelLocation_PDU 55
#define          IMAP2_PurgeMS_PDU 56
#define          IMAP2_SendIdentification_PDU 57
#define          IMAP2_PrepareHandover_PDU 58
#define          IMAP2_SendEndSignal_PDU 59
#define          IMAP2_ProcessAccessSignalling_PDU 60
#define          IMAP2_ForwardAccessSignalling_PDU 61
#define          IMAP2_PrepareSubsequentHandover_PDU 62
#define          IMAP2_SendAuthenticationInfo_PDU 63
#define          IMAP2_CheckIMEI_PDU 64
#define          IMAP2_InsertSubscriberData_PDU 65
#define          IMAP2_DeleteSubscriberData_PDU 66
#define          IMAP2_Reset_PDU 67
#define          IMAP2_RestoreData_PDU 68
#define          IMAP2_RegisterPasswordArg_PDU 69
#define          IMAP2_RegisterSSArg_PDU 70
#define          IMAP2_DeactivateSSRes_PDU 71
#define          IMAP2_ActivateSSRes_PDU 72
#define          IMAP2_EraseSSRes_PDU 73
#define          IMAP2_RegisterSSRes_PDU 74
#define          IMAP2_SS_ForBS_Code_PDU 75
#define          IMAP2_InterrogateSSArg_PDU 76
#define          IMAP2_DeactivateSSArg_PDU 77
#define          IMAP2_ActivateSSArg_PDU 78
#define          IMAP2_EraseSSArg_PDU 79
#define          IMAP2_InterrogateSSRes_PDU 80
#define          IMAP2_USSD_Arg_PDU 81
#define          IMAP2_UnstructuredSS_NotifyArg_PDU 82
#define          IMAP2_UnstructuredSS_RequestArg_PDU 83
#define          IMAP2_ProcessUnstructuredSS_RequestArg_PDU 84
#define          IMAP2_USSD_Res_PDU 85
#define          IMAP2_UnstructuredSS_RequestRes_PDU 86
#define          IMAP2_ProcessUnstructuredSS_RequestRes_PDU 87
#define          IMAP2_Password_PDU 88
#define          IMAP2_GetPasswordRes_PDU 89
#define          IMAP2_RegisterPasswordRes_PDU 90
#define          IMAP2_GuidanceInfo_PDU 91
#define          IMAP2_GetPasswordArg_PDU 92
#define          IMAP2_SS_EventSpecification_PDU 93
#define          IMAP2_CCBS_Data_PDU 94
#define          IMAP2_SubscriberId_PDU 95
#define          IMAP2_IMEI_PDU 96
#define          IMAP2_NAEA_PreferredCI_PDU 97
#define          IMAP2_UpdateLocationArg_PDU 98
#define          IMAP2_UpdateLocationRes_PDU 99
#define          IMAP2_CancelLocationArg_PDU 100
#define          IMAP2_Indentity_PDU 101
#define          IMAP2_CancellationType_PDU 102
#define          IMAP2_CancelLocationRes_PDU 103
#define          IMAP2_PurgeMS_Arg_PDU 104
#define          IMAP2_PurgeMS_Res_PDU 105
#define          IMAP2_SendIdentificationRes_PDU 106
#define          IMAP2_PrepareHO_Arg_PDU 107
#define          IMAP2_PrepareHO_Res_PDU 108
#define          IMAP2_PrepareSubsequentHO_Arg_PDU 109
#define          IMAP2_SendAuthenticationInfoArg_PDU 110
#define          IMAP2_SendAuthenticationInfoRes_PDU 111
#define          IMAP2_EquipmentStatus_PDU 112
#define          IMAP2_InsertSubscriberDataArg_PDU 113
#define          IMAP2_QoS_Subscribed_PDU 114
#define          IMAP2_Ext_SS_InfoList_PDU 115
#define          IMAP2_InsertSubscriberDataRes_PDU 116
#define          IMAP2_DeleteSubscriberDataArg_PDU 117
#define          IMAP2_DeleteSubscriberDataRes_PDU 118
#define          IMAP2_CallTypeCriteria_PDU 119
#define          IMAP2_DefaultCallHandling_PDU 120
#define          IMAP2_ResetArg_PDU 121
#define          IMAP2_RestoreDataArg_PDU 122
#define          IMAP2_RestoreDataRes_PDU 123
#define          IMAP2_VBSDataList_PDU 124
#define          IMAP2_VGCSDataList_PDU 125
#define          IMAP2_RegisterSS_PDU 126
#define          IMAP2_EraseSS_PDU 127
#define          IMAP2_ActivateSS_PDU 128
#define          IMAP2_DeactivateSS_PDU 129
#define          IMAP2_InterrogateSS_PDU 130
#define          IMAP2_ProcessUnstructuredSS_Request_PDU 131
#define          IMAP2_UnstructuredSS_Request_PDU 132
#define          IMAP2_UnstructuredSS_Notify_PDU 133
#define          IMAP2_RegisterPassword_PDU 134
#define          IMAP2_GetPassword_PDU 135
#define          IMAP2_RoamingNotAllowedParam_PDU 136
#define          IMAP2_CallBarredParam_PDU 137
#define          IMAP2_CUG_RejectParam_PDU 138
#define          IMAP2_SS_IncompatibilityCause_PDU 139
#define          IMAP2_PW_RegistrationFailureCause_PDU 140
#define          IMAP2_SM_DeliveryFailureCause_PDU 141
#define          IMAP2_AbsentSubscriberSM_Param_PDU 142
#define          IMAP2_SystemFailureParam_PDU 143
#define          IMAP2_DataMissingParam_PDU 144
#define          IMAP2_UnexpectedDataParam_PDU 145
#define          IMAP2_FacilityNotSupParam_PDU 146
#define          IMAP2_OR_NotAllowedParam_PDU 147
#define          IMAP2_UnknownSubscriberParam_PDU 148
#define          IMAP2_NumberChangedParam_PDU 149
#define          IMAP2_UnidentifiedSubParam_PDU 150
#define          IMAP2_IllegalSubscriberParam_PDU 151
#define          IMAP2_IllegalEquipmentParam_PDU 152
#define          IMAP2_BearerServNotProvParam_PDU 153
#define          IMAP2_TeleservNotProvParam_PDU 154
#define          IMAP2_TracingBufferFullParam_PDU 155
#define          IMAP2_NoRoamingNbParam_PDU 156
#define          IMAP2_AbsentSubscriberParam_PDU 157
#define          IMAP2_BusySubscriberParam_PDU 158
#define          IMAP2_NoSubscriberReplyParam_PDU 159
#define          IMAP2_ForwardingViolationParam_PDU 160
#define          IMAP2_ForwardingFailedParam_PDU 161
#define          IMAP2_ATI_NotAllowedParam_PDU 162
#define          IMAP2_SubBusyForMT_SMS_Param_PDU 163
#define          IMAP2_MessageWaitListFullParam_PDU 164
#define          IMAP2_ResourceLimitationParam_PDU 165
#define          IMAP2_NoGroupCallNbParam_PDU 166
#define          IMAP2_IncompatibleTerminalParam_PDU 167
#define          IMAP2_ShortTermDenialParam_PDU 168
#define          IMAP2_LongTermDenialParam_PDU 169
#define          IMAP2_ActivateTraceModeArg_PDU 170
#define          IMAP2_ActivateTraceModeRes_PDU 171
#define          IMAP2_DeactivateTraceModeArg_PDU 172
#define          IMAP2_DeactivateTraceModeRes_PDU 173
#define          IMAP2_SendIMSIArg_PDU 174
#define          IMAP2_SendIMSIRes_PDU 175
#define          IMAP2_SystemFailure_PDU 176
#define          IMAP2_DataMissing_PDU 177
#define          IMAP2_UnexpectedDataValue_PDU 178
#define          IMAP2_FacilityNotSupported_PDU 179
#define          IMAP2_IncompatibleTerminal_PDU 180
#define          IMAP2_ResourceLimitation_PDU 181
#define          IMAP2_UnknownSubscriber_PDU 182
#define          IMAP2_NumberChanged_PDU 183
#define          IMAP2_UnknownMSC_PDU 184
#define          IMAP2_UnidentifiedSubscriber_PDU 185
#define          IMAP2_UnknownEquipment_PDU 186
#define          IMAP2_RoamingNotAllowed_PDU 187
#define          IMAP2_IllegalSubscriber_PDU 188
#define          IMAP2_IllegalEquipment_PDU 189
#define          IMAP2_BearerServiceNotProvisioned_PDU 190
#define          IMAP2_TeleserviceNotProvisioned_PDU 191
#define          IMAP2_NoHandoverNumberAvailable_PDU 192
#define          IMAP2_SubsequentHandoverFailure_PDU 193
#define          IMAP2_TracingBufferFull_PDU 194
#define          IMAP2_NoRoamingNumberAvailable_PDU 195
#define          IMAP2_AbsentSubscriber_PDU 196
#define          IMAP2_BusySubscriber_PDU 197
#define          IMAP2_NoSubscriberReply_PDU 198
#define          IMAP2_CallBarred_PDU 199
#define          IMAP2_ForwardingViolation_PDU 200
#define          IMAP2_ForwardingFailed_PDU 201
#define          IMAP2_CUG_Reject_PDU 202
#define          IMAP2_OR_NotAllowed_PDU 203
#define          IMAP2_ATI_NotAllowed_PDU 204
#define          IMAP2_IllegalSS_Operation_PDU 205
#define          IMAP2_SS_ErrorStatus_PDU 206
#define          IMAP2_SS_NotAvailable_PDU 207
#define          IMAP2_SS_SubscriptionViolation_PDU 208
#define          IMAP2_SS_Incompatibility_PDU 209
#define          IMAP2_UnknownAlphabet_PDU 210
#define          IMAP2_USSD_Busy_PDU 211
#define          IMAP2_PW_RegistrationFailure_PDU 212
#define          IMAP2_NegativePW_Check_PDU 213
#define          IMAP2_NumberOfPW_AttemptsViolation_PDU 214
#define          IMAP2_ShortTermDenial_PDU 215
#define          IMAP2_LongTermDenial_PDU 216
#define          IMAP2_SubscriberBusyForMT_SMS_PDU 217
#define          IMAP2_SM_DeliveryFailure_PDU 218
#define          IMAP2_MessageWaitingListFull_PDU 219
#define          IMAP2_AbsentSubscriberSM_PDU 220
#define          IMAP2_NoGroupCallNumberAvailable_PDU 221
#define          IMAP2_ActivateTraceMode_PDU 222
#define          IMAP2_DeactivateTraceMode_PDU 223
#define          IMAP2_SendIMSI_PDU 224
#define          IMAP2_DialoguePDU_PDU 225
#define          IMAP2_OpenInfo_PDU 226
#define          IMAP2_AcceptInfo_PDU 227
#define          IMAP2_CloseInfo_PDU 228
#define          IMAP2_RefuseInfo_PDU 229
#define          IMAP2_Reason_PDU 230
#define          IMAP2_UserAbortInfo_PDU 231
#define          IMAP2_UserAbortChoice_PDU 232
#define          IMAP2_ResourceUnavailableReason_PDU 233
#define          IMAP2_ProcedureCancellationReason_PDU 234
#define          IMAP2_ProviderAbortInfo_PDU 235
#define          IMAP2_ProviderAbortReason_PDU 236

typedef struct IMAP2__ObjectID {
    unsigned short  length;
    unsigned char   *value;
} IMAP2__ObjectID;

typedef struct IMAP2__Any {
    unsigned long   length;
    unsigned char   *value;
} IMAP2__Any;

typedef struct IMAP2__choice1 {
    unsigned short  choice;
#       define      IMAP2_single_ASN1_type_chosen 1
#       define      IMAP2_octet_aligned_chosen 2
#       define      IMAP2_arbitrary_chosen 3
    union _union {
        OpenType        single_ASN1_type;  /* to choose, set choice to
                                            * IMAP2_single_ASN1_type_chosen */
        struct IMAP2_External_octet_aligned {
            unsigned int    length;
            unsigned char   *value;
        } octet_aligned;  /* to choose, set choice to
                           * IMAP2_octet_aligned_chosen */
        struct IMAP2_External_arbitrary {
            unsigned int    length;  /* number of significant bits */
            unsigned char   *value;
        } arbitrary;  /* to choose, set choice to IMAP2_arbitrary_chosen */
    } u;
} IMAP2__choice1;

typedef struct IMAP2__External {
    unsigned char   bit_mask;
#       define      IMAP2_direct_reference_present 0x80
#       define      IMAP2_indirect_reference_present 0x40
    IMAP2__ObjectID direct_reference;  /* optional; set in bit_mask
                                        * IMAP2_direct_reference_present if
                                        * present */
    int             indirect_reference;  /* optional; set in bit_mask
                                          * IMAP2_indirect_reference_present if
                                          * present */
    char            *data_value_descriptor;  /* NULL for not present */
    IMAP2__choice1  encoding;
} IMAP2__External;

// NOTE � When the Abort Message is generated by the Transaction sublayer, a p-Abort Cause must be
// present.The u-abortCause may be generated by the component sublayer in which case it is an ABRT
// APDU, or by the TC-User in which case it could be either an ABRT APDU or data in some user-defined
// abstract syntax.
typedef IMAP2__External IMAP2_DialoguePortion;

typedef struct IMAP2_Unidirectional {
    unsigned char   bit_mask;
#       define      IMAP2_Unidirectional_dialoguePortion_present 0x80
    IMAP2_DialoguePortion dialoguePortion;  /* optional; set in bit_mask
                              * IMAP2_Unidirectional_dialoguePortion_present if
                              * present */
    struct IMAP2_ComponentPortion_ *components;
} IMAP2_Unidirectional;

// The dialogue portion carries the dialogue control PDUs as value of the external data type.
// The direct reference should be set to { ccitt recommendation q 773 as (1) dialogue-as (1) version (1) }
// if structured dialogue is used and to { ccitt recommendation q 773 as (1) unidialogue-as (2) version (1) }
// if unstructured dialogue is used or any user defined abstract syntax name when only user information
// is carried (e.g. when user information is sent in a 1988 Abort message).
typedef struct IMAP2_OrigTransactionID {
    unsigned short  length;
    unsigned char   value[4];
} IMAP2_OrigTransactionID;

typedef struct IMAP2_Begin {
    unsigned char   bit_mask;
#       define      IMAP2_Begin_dialoguePortion_present 0x80
#       define      IMAP2_Begin_components_present 0x40
    IMAP2_OrigTransactionID otid;
    IMAP2_DialoguePortion dialoguePortion;  /* optional; set in bit_mask
                                       * IMAP2_Begin_dialoguePortion_present if
                                       * present */
    struct IMAP2_ComponentPortion_ *components;  /* optional; set in bit_mask
                                            * IMAP2_Begin_components_present if
                                            * present */
} IMAP2_Begin;

typedef struct IMAP2_DestTransactionID {
    unsigned short  length;
    unsigned char   value[4];
} IMAP2_DestTransactionID;

typedef struct IMAP2_End {
    unsigned char   bit_mask;
#       define      IMAP2_End_dialoguePortion_present 0x80
#       define      IMAP2_End_components_present 0x40
    IMAP2_DestTransactionID dtid;
    IMAP2_DialoguePortion dialoguePortion;  /* optional; set in bit_mask
                                             * IMAP2_End_dialoguePortion_present
                                             * if present */
    struct IMAP2_ComponentPortion_ *components;  /* optional; set in bit_mask
                                                  * IMAP2_End_components_present
                                                  * if present */
} IMAP2_End;

typedef struct IMAP2_Continue {
    unsigned char   bit_mask;
#       define      IMAP2_Continue_dialoguePortion_present 0x80
#       define      IMAP2_Continue_components_present 0x40
    IMAP2_OrigTransactionID otid;
    IMAP2_DestTransactionID dtid;
    IMAP2_DialoguePortion dialoguePortion;  /* optional; set in bit_mask
                                    * IMAP2_Continue_dialoguePortion_present if
                                    * present */
    struct IMAP2_ComponentPortion_ *components;  /* optional; set in bit_mask
                                         * IMAP2_Continue_components_present if
                                         * present */
} IMAP2_Continue;

typedef int             IMAP2_P_AbortCause;
#define                     IMAP2_unrecognizedMessageType 0
#define                     IMAP2_unrecognizedTransactionID 1
#define                     IMAP2_badlyFormattedTransactionPortion 2
#define                     IMAP2_incorrectTransactionPortion 3
#define                     IMAP2_P_AbortCause_resourceLimitation 4

typedef struct IMAP2__choice2 {
    unsigned short  choice;
#       define      IMAP2_p_abortCause_chosen 1
#       define      IMAP2_u_abortCause_chosen 2
    union _union {
        IMAP2_P_AbortCause p_abortCause;  /* to choose, set choice to
                                           * IMAP2_p_abortCause_chosen */
        IMAP2_DialoguePortion u_abortCause;  /* to choose, set choice to
                                              * IMAP2_u_abortCause_chosen */
    } u;
} IMAP2__choice2;

typedef struct IMAP2_Abort {
    unsigned char   bit_mask;
#       define      IMAP2_reason_present 0x80
    IMAP2_DestTransactionID dtid;
    IMAP2__choice2  reason;  /* optional; set in bit_mask IMAP2_reason_present
                              * if present */
} IMAP2_Abort;

// Transaction Portion fields
typedef struct IMAP2_MessageType {
    unsigned short  choice;
#       define      IMAP2_unidirectional_chosen 1
#       define      IMAP2_begin_chosen 2
#       define      IMAP2_end_chosen 3
#       define      IMAP2_continue_chosen 4
#       define      IMAP2_abort_chosen 5
    union _union {
        IMAP2_Unidirectional unidirectional;  /* to choose, set choice to
                                               * IMAP2_unidirectional_chosen */
        IMAP2_Begin     begin;  /* to choose, set choice to
                                 * IMAP2_begin_chosen */
        IMAP2_End       end;  /* to choose, set choice to IMAP2_end_chosen */
        IMAP2_Continue  MessageType_continue;  /* to choose, set choice to
                                                * IMAP2_continue_chosen */
        IMAP2_Abort     abort;  /* to choose, set choice to
                                 * IMAP2_abort_chosen */
    } u;
} IMAP2_MessageType;

typedef short           IMAP2_InvokeIdType;

typedef struct IMAP2__choice3 {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2__choice3;

// The Components are sequences of data elements.
typedef struct IMAP2_Invoke {
    unsigned char   bit_mask;
#       define      IMAP2_linkedID_present 0x80
#       define      IMAP2_Invoke_parameter_present 0x40
    IMAP2_InvokeIdType invokeID;
    IMAP2_InvokeIdType linkedID;  /* optional; set in bit_mask
                                   * IMAP2_linkedID_present if present */
    IMAP2__choice3  operationCode;
    IMAP2__Any      parameter;  /* optional; set in bit_mask
                                 * IMAP2_Invoke_parameter_present if present */
} IMAP2_Invoke;

// ANY is filled by the single ASN.1 data type following the keyword PARAMETER or the keyword ARGUMENT
// in the type definition of a particular operation.
typedef struct IMAP2_ReturnResult {
    unsigned char   bit_mask;
#       define      IMAP2_result_present 0x80
    IMAP2_InvokeIdType invokeID;
    struct IMAP2__seq1 {
        IMAP2__choice3  operationCode;
        IMAP2__Any      parameter;
    } result;  /* optional; set in bit_mask IMAP2_result_present if present */
} IMAP2_ReturnResult;

// ANY is filled by the single ASN.1 data type following the keyword RESULT in the type definition
// of a particular operation.
typedef struct IMAP2_ReturnError {
    unsigned char   bit_mask;
#       define      IMAP2_ReturnError_parameter_present 0x80
    IMAP2_InvokeIdType invokeID;
    IMAP2__choice3  errorCode;
    IMAP2__Any      parameter;  /* optional; set in bit_mask
                                 * IMAP2_ReturnError_parameter_present if
                                 * present */
} IMAP2_ReturnError;

// PROBLEMS
typedef int             IMAP2_GeneralProblem;
#define                     IMAP2_unrecognizedComponent 0
#define                     IMAP2_mistypedComponent 1
#define                     IMAP2_badlyStructuredComponent 2

typedef int             IMAP2_InvokeProblem;
#define                     IMAP2_duplicateInvokeID 0
#define                     IMAP2_unrecognizedOperation 1
#define                     IMAP2_InvokeProblem_mistypedParameter 2
#define                     IMAP2_InvokeProblem_resourceLimitation 3
#define                     IMAP2_initiatingRelease 4
#define                     IMAP2_unrecognizedLinkedID 5
#define                     IMAP2_linkedResponseUnexpected 6
#define                     IMAP2_unexpectedLinkedOperation 7

typedef int             IMAP2_ReturnResultProblem;
#define                     IMAP2_ReturnResultProblem_unrecognizedInvokeID 0
#define                     IMAP2_returnResultUnexpected 1
#define                     IMAP2_ReturnResultProblem_mistypedParameter 2

typedef int             IMAP2_ReturnErrorProblem;
#define                     IMAP2_ReturnErrorProblem_unrecognizedInvokeID 0
#define                     IMAP2_returnErrorUnexpected 1
#define                     IMAP2_unrecognizedError 2
#define                     IMAP2_unexpectedError 3
#define                     IMAP2_ReturnErrorProblem_mistypedParameter 4

typedef struct IMAP2__choice4 {
    unsigned short  choice;
#       define      IMAP2_derivable_chosen 1
#       define      IMAP2_not_derivable_chosen 2
    union _union {
        IMAP2_InvokeIdType derivable;  /* to choose, set choice to
                                        * IMAP2_derivable_chosen */
        Nulltype        not_derivable;  /* to choose, set choice to
                                         * IMAP2_not_derivable_chosen */
    } u;
} IMAP2__choice4;

typedef struct IMAP2__choice5 {
    unsigned short  choice;
#       define      IMAP2_generalProblem_chosen 1
#       define      IMAP2_invokeProblem_chosen 2
#       define      IMAP2_returnResultProblem_chosen 3
#       define      IMAP2_returnErrorProblem_chosen 4
    union _union {
        IMAP2_GeneralProblem generalProblem;  /* to choose, set choice to
                                               * IMAP2_generalProblem_chosen */
        IMAP2_InvokeProblem invokeProblem;  /* to choose, set choice to
                                             * IMAP2_invokeProblem_chosen */
        IMAP2_ReturnResultProblem returnResultProblem;  /* to choose, set choice
                                       * to IMAP2_returnResultProblem_chosen */
        IMAP2_ReturnErrorProblem returnErrorProblem;  /* to choose, set choice
                                        * to IMAP2_returnErrorProblem_chosen */
    } u;
} IMAP2__choice5;

// ANY is filled by the single ASN.1 data type following the keyword PARAMETER in the type definition
// of a particular error.
typedef struct IMAP2_Reject {
    IMAP2__choice4  invokeID;
    IMAP2__choice5  problem;
} IMAP2_Reject;

// Component Portion fields
// COMPONENT TYPE. Recommendation X.229 defines four Application Protocol Data Units (APDUs).
// TCAP adds returnResultNotLast to allow for the segmentation of a result.
typedef struct IMAP2_Component {
    unsigned short  choice;
#       define      IMAP2_invoke_chosen 1
#       define      IMAP2_returnResultLast_chosen 2
#       define      IMAP2_returnError_chosen 3
#       define      IMAP2_reject_chosen 4
#       define      IMAP2_returnResultNotLast_chosen 5
    union _union {
        IMAP2_Invoke    invoke;  /* to choose, set choice to
                                  * IMAP2_invoke_chosen */
        IMAP2_ReturnResult returnResultLast;  /* to choose, set choice to
                                             * IMAP2_returnResultLast_chosen */
        IMAP2_ReturnError returnError;  /* to choose, set choice to
                                         * IMAP2_returnError_chosen */
        IMAP2_Reject    reject;  /* to choose, set choice to
                                  * IMAP2_reject_chosen */
        IMAP2_ReturnResult returnResultNotLast;  /* to choose, set choice to
                                          * IMAP2_returnResultNotLast_chosen */
    } u;
} IMAP2_Component;

// COMPONENT PORTION. The last field in the transaction portion of the TCAP message is the Component Portion.
// The Component Portion may be absent.
typedef struct IMAP2_ComponentPortion_ {
    struct IMAP2_ComponentPortion_ *next;
    IMAP2_Component value;
} *IMAP2_ComponentPortion;

// IOC for private MAP extensions
typedef struct IMAP2_EXTENSION {
    unsigned char   bit_mask;
#       define      IMAP2_ExtensionType_present 0x80
    unsigned short  ExtensionType;  /* optional; set in bit_mask
                                     * IMAP2_ExtensionType_present if present */
    IMAP2__ObjectID extensionId;
    long            _oss_unique_index;
} IMAP2_EXTENSION;

	// Unsupported private extensions shall be discarded if received.
typedef struct IMAP2_PCS_Extensions {
    char            placeholder;
} IMAP2_PCS_Extensions;

	// The length of the Object Identifier shall not exceed 16 octets and the
	// number of components of the Object Identifier shall not exceed 16
// data types
typedef struct IMAP2_ExtensionContainer {
    unsigned char   bit_mask;
#       define      IMAP2_privateExtensionList_present 0x80
#       define      IMAP2_pcs_Extensions_present 0x40
    struct IMAP2_PrivateExtensionList_ *privateExtensionList;  /* optional; set
                                   * in bit_mask
                                   * IMAP2_privateExtensionList_present if
                                   * present */
    IMAP2_PCS_Extensions pcs_Extensions;  /* optional; set in bit_mask
                                           * IMAP2_pcs_Extensions_present if
                                           * present */
} IMAP2_ExtensionContainer;

typedef Nulltype        IMAP2_SuppressionOfAnnouncement;

typedef enum IMAP2_InterrogationType {
    IMAP2_basicCall = 0,
    IMAP2_forwarding = 1
} IMAP2_InterrogationType;

typedef unsigned short  IMAP2_OR_Phase;

typedef enum IMAP2_ForwardingReason {
    IMAP2_notReachable = 0,
    IMAP2_ForwardingReason_busy = 1,
    IMAP2_noReply = 2
} IMAP2_ForwardingReason;

typedef unsigned short  IMAP2_SupportedCCBS_Phase;

typedef char            IMAP2_Password[5];

typedef char            IMAP2_GetPasswordRes[5];

typedef char            IMAP2_RegisterPasswordRes[5];

typedef enum IMAP2_GuidanceInfo {
    IMAP2_GuidanceInfo_enterPW = 0,
    IMAP2_GuidanceInfo_enterNewPW = 1,
    IMAP2_GuidanceInfo_enterNewPW_Again = 2
} IMAP2_GuidanceInfo;

	// How this information is really delivered to the subscriber
	// (display, announcement, ...) is not part of this
	// specification.
typedef enum IMAP2_GetPasswordArg {
    IMAP2_GetPasswordArg_enterPW = 0,
    IMAP2_GetPasswordArg_enterNewPW = 1,
    IMAP2_GetPasswordArg_enterNewPW_Again = 2
} IMAP2_GetPasswordArg;

typedef enum IMAP2_CancellationType {
    IMAP2_updateProcedure = 0,
    IMAP2_subscriptionWithdraw = 1
} IMAP2_CancellationType;

// security management types
typedef enum IMAP2_EquipmentStatus {
    IMAP2_whiteListed = 0,
    IMAP2_blackListed = 1,
    IMAP2_greyListed = 2
} IMAP2_EquipmentStatus;

typedef enum IMAP2_CallTypeCriteria {
    IMAP2_forwarded = 0,
    IMAP2_notForwarded = 1
} IMAP2_CallTypeCriteria;

typedef enum IMAP2_DefaultCallHandling {
    IMAP2_continueCall = 0,
    IMAP2_releaseCall = 1
} IMAP2_DefaultCallHandling;

typedef enum IMAP2_PW_RegistrationFailureCause {
    IMAP2_undetermined = 0,
    IMAP2_invalidFormat = 1,
    IMAP2_newPasswordsMismatch = 2
} IMAP2_PW_RegistrationFailureCause;

typedef enum IMAP2_Reason {
    IMAP2_Reason_noReasonGiven = 0,
    IMAP2_Reason_invalidDestinationReference = 1,
    IMAP2_Reason_invalidOriginatingReference = 2
} IMAP2_Reason;

typedef enum IMAP2_ResourceUnavailableReason {
    IMAP2_ResourceUnavailableReason_shortTermResourceLimitation = 0,
    IMAP2_ResourceUnavailableReason_longTermResourceLimitation = 1
} IMAP2_ResourceUnavailableReason;

typedef enum IMAP2_ProcedureCancellationReason {
    IMAP2_ProcedureCancellationReason_handoverCancellation = 0,
    IMAP2_ProcedureCancellationReason_radioChannelRelease = 1,
    IMAP2_ProcedureCancellationReason_networkPathRelease = 2,
    IMAP2_ProcedureCancellationReason_callRelease = 3,
    IMAP2_ProcedureCancellationReason_associatedProcedureFailure = 4,
    IMAP2_ProcedureCancellationReason_tandemDialogueRelease = 5,
    IMAP2_ProcedureCancellationReason_remoteOperationsFailure = 6
} IMAP2_ProcedureCancellationReason;

typedef enum IMAP2_ProviderAbortReason {
    IMAP2_ProviderAbortReason_abnormalDialogue = 0,
    IMAP2_ProviderAbortReason_invalidPDU = 1
} IMAP2_ProviderAbortReason;

union IMAP2_All_PDU_Types_union {
    IMAP2_MessageType *pdu_MessageType;  /* IMAP2_MessageType_PDU */
    struct IMAP2_SendRoutingInfoForSM *pdu_SendRoutingInfoForSM;  
                                           /* IMAP2_SendRoutingInfoForSM_PDU */
    struct IMAP2_MO_ForwardSM *pdu_MO_ForwardSM;  /* IMAP2_MO_ForwardSM_PDU */
    struct IMAP2_MT_ForwardSM *pdu_MT_ForwardSM;  /* IMAP2_MT_ForwardSM_PDU */
    struct IMAP2_ReportSM_DeliveryStatus *pdu_ReportSM_DeliveryStatus;  
                                        /* IMAP2_ReportSM_DeliveryStatus_PDU */
    struct IMAP2_AlertServiceCentre *pdu_AlertServiceCentre;  
                                             /* IMAP2_AlertServiceCentre_PDU */
    struct IMAP2_InformServiceCentre *pdu_InformServiceCentre;  
                                            /* IMAP2_InformServiceCentre_PDU */
    struct IMAP2_ReadyForSM *pdu_ReadyForSM;  /* IMAP2_ReadyForSM_PDU */
    struct IMAP2_PrepareGroupCallArg *pdu_PrepareGroupCallArg;  
                                            /* IMAP2_PrepareGroupCallArg_PDU */
    struct IMAP2_PrepareGroupCallRes *pdu_PrepareGroupCallRes;  
                                            /* IMAP2_PrepareGroupCallRes_PDU */
    struct IMAP2_SendGroupCallEndSignalArg *pdu_SendGroupCallEndSignalArg;  
                                        /* IMAP2_SendGroupCallEndSignalArg_PDU */
    struct IMAP2_SendGroupCallEndSignalRes *pdu_SendGroupCallEndSignalRes;  
                                        /* IMAP2_SendGroupCallEndSignalRes_PDU */
    struct IMAP2_ForwardGroupCallSignallingArg *pdu_ForwardGroupCallSignallingArg;                                      /* IMAP2_ForwardGroupCallSignallingArg_PDU */
    struct IMAP2_ProcessGroupCallSignallingArg *pdu_ProcessGroupCallSignallingArg;                                      /* IMAP2_ProcessGroupCallSignallingArg_PDU */
    struct IMAP2_RoutingInfoForSM_Arg *pdu_RoutingInfoForSM_Arg;  
                                           /* IMAP2_RoutingInfoForSM_Arg_PDU */
    struct IMAP2_RoutingInfoForSM_Res *pdu_RoutingInfoForSM_Res;  
                                           /* IMAP2_RoutingInfoForSM_Res_PDU */
    struct IMAP2_Additional_Number *pdu_Additional_Number;  
                                              /* IMAP2_Additional_Number_PDU */
    struct IMAP2_MO_ForwardSM_Arg *pdu_MO_ForwardSM_Arg;  
                                               /* IMAP2_MO_ForwardSM_Arg_PDU */
    struct IMAP2_MO_ForwardSM_Res *pdu_MO_ForwardSM_Res;  
                                               /* IMAP2_MO_ForwardSM_Res_PDU */
    struct IMAP2_MT_ForwardSM_Arg *pdu_MT_ForwardSM_Arg;  
                                               /* IMAP2_MT_ForwardSM_Arg_PDU */
    struct IMAP2_MT_ForwardSM_Res *pdu_MT_ForwardSM_Res;  
                                               /* IMAP2_MT_ForwardSM_Res_PDU */
    struct IMAP2_ReportSM_DeliveryStatusArg *pdu_ReportSM_DeliveryStatusArg;  
                                        /* IMAP2_ReportSM_DeliveryStatusArg_PDU */
    struct IMAP2_ReportSM_DeliveryStatusRes *pdu_ReportSM_DeliveryStatusRes;  
                                        /* IMAP2_ReportSM_DeliveryStatusRes_PDU */
    struct IMAP2_AlertServiceCentreArg *pdu_AlertServiceCentreArg;  
                                          /* IMAP2_AlertServiceCentreArg_PDU */
    struct IMAP2_InformServiceCentreArg *pdu_InformServiceCentreArg;  
                                         /* IMAP2_InformServiceCentreArg_PDU */
    struct IMAP2_ReadyForSM_Arg *pdu_ReadyForSM_Arg;  
                                                 /* IMAP2_ReadyForSM_Arg_PDU */
    struct IMAP2_ReadyForSM_Res *pdu_ReadyForSM_Res;  
                                                 /* IMAP2_ReadyForSM_Res_PDU */
    struct IMAP2_SendRoutingInfo *pdu_SendRoutingInfo;  
                                                /* IMAP2_SendRoutingInfo_PDU */
    struct IMAP2_ProvideRoamingNumber *pdu_ProvideRoamingNumber;  
                                           /* IMAP2_ProvideRoamingNumber_PDU */
    struct IMAP2_ResumeCallHandling *pdu_ResumeCallHandling;  
                                             /* IMAP2_ResumeCallHandling_PDU */
    struct IMAP2_ProvideSIWFSNumber *pdu_ProvideSIWFSNumber;  
                                             /* IMAP2_ProvideSIWFSNumber_PDU */
    struct IMAP2_SIWFSSignallingModify *pdu_SIWFSSignallingModify;  
                                          /* IMAP2_SIWFSSignallingModify_PDU */
    struct IMAP2_PrepareGroupCall *pdu_PrepareGroupCall;  
                                               /* IMAP2_PrepareGroupCall_PDU */
    struct IMAP2_SendGroupCallEndSignal *pdu_SendGroupCallEndSignal;  
                                         /* IMAP2_SendGroupCallEndSignal_PDU */
    struct IMAP2_ProcessGroupCallSignalling *pdu_ProcessGroupCallSignalling;  
                                        /* IMAP2_ProcessGroupCallSignalling_PDU */
    struct IMAP2_ForwardGroupCallSignalling *pdu_ForwardGroupCallSignalling;  
                                        /* IMAP2_ForwardGroupCallSignalling_PDU */
    struct IMAP2_SendRoutingInfoArg *pdu_SendRoutingInfoArg;  
                                             /* IMAP2_SendRoutingInfoArg_PDU */
    IMAP2_SuppressionOfAnnouncement *pdu_SuppressionOfAnnouncement;  
                                      /* IMAP2_SuppressionOfAnnouncement_PDU */
    IMAP2_InterrogationType *pdu_InterrogationType;  
                                              /* IMAP2_InterrogationType_PDU */
    IMAP2_OR_Phase  *pdu_OR_Phase;  /* IMAP2_OR_Phase_PDU */
    IMAP2_ForwardingReason *pdu_ForwardingReason;  
                                               /* IMAP2_ForwardingReason_PDU */
    IMAP2_SupportedCCBS_Phase *pdu_SupportedCCBS_Phase;  
                                            /* IMAP2_SupportedCCBS_Phase_PDU */
    struct IMAP2_SendRoutingInfoRes *pdu_SendRoutingInfoRes;  
                                             /* IMAP2_SendRoutingInfoRes_PDU */
    struct IMAP2_CCBS_Indicators *pdu_CCBS_Indicators;  
                                                /* IMAP2_CCBS_Indicators_PDU */
    struct IMAP2_ProvideRoamingNumberArg *pdu_ProvideRoamingNumberArg;  
                                        /* IMAP2_ProvideRoamingNumberArg_PDU */
    struct IMAP2_ProvideRoamingNumberRes *pdu_ProvideRoamingNumberRes;  
                                        /* IMAP2_ProvideRoamingNumberRes_PDU */
    struct IMAP2_ResumeCallHandlingRes *pdu_ResumeCallHandlingRes;  
                                          /* IMAP2_ResumeCallHandlingRes_PDU */
    struct IMAP2_ProvideSIWFSNumberArg *pdu_ProvideSIWFSNumberArg;  
                                          /* IMAP2_ProvideSIWFSNumberArg_PDU */
    struct IMAP2_ProvideSIWFSNumberRes *pdu_ProvideSIWFSNumberRes;  
                                          /* IMAP2_ProvideSIWFSNumberRes_PDU */
    struct IMAP2_SIWFSSignallingModifyArg *pdu_SIWFSSignallingModifyArg;  
                                        /* IMAP2_SIWFSSignallingModifyArg_PDU */
    struct IMAP2_SIWFSSignallingModifyRes *pdu_SIWFSSignallingModifyRes;  
                                        /* IMAP2_SIWFSSignallingModifyRes_PDU */
    struct IMAP2_StatusReportArg *pdu_StatusReportArg;  
                                                /* IMAP2_StatusReportArg_PDU */
    struct IMAP2_StatusReportRes *pdu_StatusReportRes;  
                                                /* IMAP2_StatusReportRes_PDU */
    struct IMAP2_UpdateLocation *pdu_UpdateLocation;  
                                                 /* IMAP2_UpdateLocation_PDU */
    struct IMAP2_CancelLocation *pdu_CancelLocation;  
                                                 /* IMAP2_CancelLocation_PDU */
    struct IMAP2_PurgeMS *pdu_PurgeMS;  /* IMAP2_PurgeMS_PDU */
    struct IMAP2_SendIdentification *pdu_SendIdentification;  
                                             /* IMAP2_SendIdentification_PDU */
    struct IMAP2_PrepareHandover *pdu_PrepareHandover;  
                                                /* IMAP2_PrepareHandover_PDU */
    struct IMAP2_SendEndSignal *pdu_SendEndSignal;  
                                                  /* IMAP2_SendEndSignal_PDU */
    struct IMAP2_ProcessAccessSignalling *pdu_ProcessAccessSignalling;  
                                        /* IMAP2_ProcessAccessSignalling_PDU */
    struct IMAP2_ForwardAccessSignalling *pdu_ForwardAccessSignalling;  
                                        /* IMAP2_ForwardAccessSignalling_PDU */
    struct IMAP2_PrepareSubsequentHandover *pdu_PrepareSubsequentHandover;  
                                        /* IMAP2_PrepareSubsequentHandover_PDU */
    struct IMAP2_SendAuthenticationInfo *pdu_SendAuthenticationInfo;  
                                         /* IMAP2_SendAuthenticationInfo_PDU */
    struct IMAP2_CheckIMEI *pdu_CheckIMEI;  /* IMAP2_CheckIMEI_PDU */
    struct IMAP2_InsertSubscriberData *pdu_InsertSubscriberData;  
                                           /* IMAP2_InsertSubscriberData_PDU */
    struct IMAP2_DeleteSubscriberData *pdu_DeleteSubscriberData;  
                                           /* IMAP2_DeleteSubscriberData_PDU */
    struct IMAP2_Reset *pdu_Reset;  /* IMAP2_Reset_PDU */
    struct IMAP2_RestoreData *pdu_RestoreData;  /* IMAP2_RestoreData_PDU */
    struct IMAP2_RegisterPasswordArg *pdu_RegisterPasswordArg;  
                                            /* IMAP2_RegisterPasswordArg_PDU */
    struct IMAP2_RegisterSSArg *pdu_RegisterSSArg;  
                                                  /* IMAP2_RegisterSSArg_PDU */
    struct IMAP2_SS_Info *pdu_DeactivateSSRes;  /* IMAP2_DeactivateSSRes_PDU */
    struct IMAP2_SS_Info *pdu_ActivateSSRes;  /* IMAP2_ActivateSSRes_PDU */
    struct IMAP2_SS_Info *pdu_EraseSSRes;  /* IMAP2_EraseSSRes_PDU */
    struct IMAP2_SS_Info *pdu_RegisterSSRes;  /* IMAP2_RegisterSSRes_PDU */
    struct IMAP2_SS_ForBS_Code *pdu_SS_ForBS_Code;  
                                                  /* IMAP2_SS_ForBS_Code_PDU */
    struct IMAP2_InterrogateSSArg *pdu_InterrogateSSArg;  
                                               /* IMAP2_InterrogateSSArg_PDU */
    struct IMAP2_DeactivateSSArg *pdu_DeactivateSSArg;  
                                                /* IMAP2_DeactivateSSArg_PDU */
    struct IMAP2_ActivateSSArg *pdu_ActivateSSArg;  
                                                  /* IMAP2_ActivateSSArg_PDU */
    struct IMAP2_EraseSSArg *pdu_EraseSSArg;  /* IMAP2_EraseSSArg_PDU */
    struct IMAP2_InterrogateSSRes *pdu_InterrogateSSRes;  
                                               /* IMAP2_InterrogateSSRes_PDU */
    struct IMAP2_USSD_Arg *pdu_USSD_Arg;  /* IMAP2_USSD_Arg_PDU */
    struct IMAP2_UnstructuredSS_NotifyArg *pdu_UnstructuredSS_NotifyArg;  
                                        /* IMAP2_UnstructuredSS_NotifyArg_PDU */
    struct IMAP2_UnstructuredSS_RequestArg *pdu_UnstructuredSS_RequestArg;  
                                        /* IMAP2_UnstructuredSS_RequestArg_PDU */
    struct IMAP2_ProcessUnstructuredSS_RequestArg *pdu_ProcessUnstructuredSS_RequestArg;                                /* IMAP2_ProcessUnstructuredSS_RequestArg_PDU */
    struct IMAP2_USSD_Res *pdu_USSD_Res;  /* IMAP2_USSD_Res_PDU */
    struct IMAP2_UnstructuredSS_RequestRes *pdu_UnstructuredSS_RequestRes;  
                                        /* IMAP2_UnstructuredSS_RequestRes_PDU */
    struct IMAP2_ProcessUnstructuredSS_RequestRes *pdu_ProcessUnstructuredSS_RequestRes;                                /* IMAP2_ProcessUnstructuredSS_RequestRes_PDU */
    IMAP2_Password  *pdu_Password;  /* IMAP2_Password_PDU */
    IMAP2_GetPasswordRes *pdu_GetPasswordRes;  /* IMAP2_GetPasswordRes_PDU */
    IMAP2_RegisterPasswordRes *pdu_RegisterPasswordRes;  
                                            /* IMAP2_RegisterPasswordRes_PDU */
    IMAP2_GuidanceInfo *pdu_GuidanceInfo;  /* IMAP2_GuidanceInfo_PDU */
    IMAP2_GetPasswordArg *pdu_GetPasswordArg;  /* IMAP2_GetPasswordArg_PDU */
    struct IMAP2_SS_EventSpecification_ **pdu_SS_EventSpecification;  
                                          /* IMAP2_SS_EventSpecification_PDU */
    struct IMAP2_CCBS_Data *pdu_CCBS_Data;  /* IMAP2_CCBS_Data_PDU */
    struct IMAP2_SubscriberId *pdu_SubscriberId;  /* IMAP2_SubscriberId_PDU */
    struct IMAP2_IMEI *pdu_IMEI;  /* IMAP2_IMEI_PDU */
    struct IMAP2_NAEA_PreferredCI *pdu_NAEA_PreferredCI;  
                                               /* IMAP2_NAEA_PreferredCI_PDU */
    struct IMAP2_UpdateLocationArg *pdu_UpdateLocationArg;  
                                              /* IMAP2_UpdateLocationArg_PDU */
    struct IMAP2_UpdateLocationRes *pdu_UpdateLocationRes;  
                                              /* IMAP2_UpdateLocationRes_PDU */
    struct IMAP2_CancelLocationArg *pdu_CancelLocationArg;  
                                              /* IMAP2_CancelLocationArg_PDU */
    struct IMAP2_Indentity *pdu_Indentity;  /* IMAP2_Indentity_PDU */
    IMAP2_CancellationType *pdu_CancellationType;  
                                               /* IMAP2_CancellationType_PDU */
    struct IMAP2_CancelLocationRes *pdu_CancelLocationRes;  
                                              /* IMAP2_CancelLocationRes_PDU */
    struct IMAP2_PurgeMS_Arg *pdu_PurgeMS_Arg;  /* IMAP2_PurgeMS_Arg_PDU */
    struct IMAP2_PurgeMS_Res *pdu_PurgeMS_Res;  /* IMAP2_PurgeMS_Res_PDU */
    struct IMAP2_SendIdentificationRes *pdu_SendIdentificationRes;  
                                          /* IMAP2_SendIdentificationRes_PDU */
    struct IMAP2_PrepareHO_Arg *pdu_PrepareHO_Arg;  
                                                  /* IMAP2_PrepareHO_Arg_PDU */
    struct IMAP2_PrepareHO_Res *pdu_PrepareHO_Res;  
                                                  /* IMAP2_PrepareHO_Res_PDU */
    struct IMAP2_PrepareSubsequentHO_Arg *pdu_PrepareSubsequentHO_Arg;  
                                        /* IMAP2_PrepareSubsequentHO_Arg_PDU */
    struct IMAP2_IMSI *pdu_SendAuthenticationInfoArg;  
                                      /* IMAP2_SendAuthenticationInfoArg_PDU */
    struct IMAP2_AuthenticationSetList_ **pdu_SendAuthenticationInfoRes;  
                                        /* IMAP2_SendAuthenticationInfoRes_PDU */
    IMAP2_EquipmentStatus *pdu_EquipmentStatus;  
                                                /* IMAP2_EquipmentStatus_PDU */
    struct IMAP2_InsertSubscriberDataArg *pdu_InsertSubscriberDataArg;  
                                        /* IMAP2_InsertSubscriberDataArg_PDU */
    struct IMAP2_QoS_Subscribed *pdu_QoS_Subscribed;  
                                                 /* IMAP2_QoS_Subscribed_PDU */
    struct IMAP2_Ext_SS_InfoList_ **pdu_Ext_SS_InfoList;  
                                                /* IMAP2_Ext_SS_InfoList_PDU */
    struct IMAP2_InsertSubscriberDataRes *pdu_InsertSubscriberDataRes;  
                                        /* IMAP2_InsertSubscriberDataRes_PDU */
    struct IMAP2_DeleteSubscriberDataArg *pdu_DeleteSubscriberDataArg;  
                                        /* IMAP2_DeleteSubscriberDataArg_PDU */
    struct IMAP2_DeleteSubscriberDataRes *pdu_DeleteSubscriberDataRes;  
                                        /* IMAP2_DeleteSubscriberDataRes_PDU */
    IMAP2_CallTypeCriteria *pdu_CallTypeCriteria;  
                                               /* IMAP2_CallTypeCriteria_PDU */
    IMAP2_DefaultCallHandling *pdu_DefaultCallHandling;  
                                            /* IMAP2_DefaultCallHandling_PDU */
    struct IMAP2_ResetArg *pdu_ResetArg;  /* IMAP2_ResetArg_PDU */
    struct IMAP2_RestoreDataArg *pdu_RestoreDataArg;  
                                                 /* IMAP2_RestoreDataArg_PDU */
    struct IMAP2_RestoreDataRes *pdu_RestoreDataRes;  
                                                 /* IMAP2_RestoreDataRes_PDU */
    struct IMAP2_VBSDataList_ **pdu_VBSDataList;  /* IMAP2_VBSDataList_PDU */
    struct IMAP2_VGCSDataList_ **pdu_VGCSDataList;  
                                                   /* IMAP2_VGCSDataList_PDU */
    struct IMAP2_RegisterSS *pdu_RegisterSS;  /* IMAP2_RegisterSS_PDU */
    struct IMAP2_EraseSS *pdu_EraseSS;  /* IMAP2_EraseSS_PDU */
    struct IMAP2_ActivateSS *pdu_ActivateSS;  /* IMAP2_ActivateSS_PDU */
    struct IMAP2_DeactivateSS *pdu_DeactivateSS;  /* IMAP2_DeactivateSS_PDU */
    struct IMAP2_InterrogateSS *pdu_InterrogateSS;  
                                                  /* IMAP2_InterrogateSS_PDU */
    struct IMAP2_ProcessUnstructuredSS_Request *pdu_ProcessUnstructuredSS_Request;                                      /* IMAP2_ProcessUnstructuredSS_Request_PDU */
    struct IMAP2_UnstructuredSS_Request *pdu_UnstructuredSS_Request;  
                                         /* IMAP2_UnstructuredSS_Request_PDU */
    struct IMAP2_UnstructuredSS_Notify *pdu_UnstructuredSS_Notify;  
                                          /* IMAP2_UnstructuredSS_Notify_PDU */
    struct IMAP2_RegisterPassword *pdu_RegisterPassword;  
                                               /* IMAP2_RegisterPassword_PDU */
    struct IMAP2_GetPassword *pdu_GetPassword;  /* IMAP2_GetPassword_PDU */
    struct IMAP2_RoamingNotAllowedParam *pdu_RoamingNotAllowedParam;  
                                         /* IMAP2_RoamingNotAllowedParam_PDU */
    struct IMAP2_CallBarredParam *pdu_CallBarredParam;  
                                                /* IMAP2_CallBarredParam_PDU */
    struct IMAP2_CUG_RejectParam *pdu_CUG_RejectParam;  
                                                /* IMAP2_CUG_RejectParam_PDU */
    struct IMAP2_SS_IncompatibilityCause *pdu_SS_IncompatibilityCause;  
                                        /* IMAP2_SS_IncompatibilityCause_PDU */
    IMAP2_PW_RegistrationFailureCause *pdu_PW_RegistrationFailureCause;  
                                    /* IMAP2_PW_RegistrationFailureCause_PDU */
    struct IMAP2_SM_DeliveryFailureCause *pdu_SM_DeliveryFailureCause;  
                                        /* IMAP2_SM_DeliveryFailureCause_PDU */
    struct IMAP2_AbsentSubscriberSM_Param *pdu_AbsentSubscriberSM_Param;  
                                        /* IMAP2_AbsentSubscriberSM_Param_PDU */
    struct IMAP2_SystemFailureParam *pdu_SystemFailureParam;  
                                             /* IMAP2_SystemFailureParam_PDU */
    struct IMAP2_DataMissingParam *pdu_DataMissingParam;  
                                               /* IMAP2_DataMissingParam_PDU */
    struct IMAP2_UnexpectedDataParam *pdu_UnexpectedDataParam;  
                                            /* IMAP2_UnexpectedDataParam_PDU */
    struct IMAP2_FacilityNotSupParam *pdu_FacilityNotSupParam;  
                                            /* IMAP2_FacilityNotSupParam_PDU */
    struct IMAP2_OR_NotAllowedParam *pdu_OR_NotAllowedParam;  
                                             /* IMAP2_OR_NotAllowedParam_PDU */
    struct IMAP2_UnknownSubscriberParam *pdu_UnknownSubscriberParam;  
                                         /* IMAP2_UnknownSubscriberParam_PDU */
    struct IMAP2_NumberChangedParam *pdu_NumberChangedParam;  
                                             /* IMAP2_NumberChangedParam_PDU */
    struct IMAP2_UnidentifiedSubParam *pdu_UnidentifiedSubParam;  
                                           /* IMAP2_UnidentifiedSubParam_PDU */
    struct IMAP2_IllegalSubscriberParam *pdu_IllegalSubscriberParam;  
                                         /* IMAP2_IllegalSubscriberParam_PDU */
    struct IMAP2_IllegalEquipmentParam *pdu_IllegalEquipmentParam;  
                                          /* IMAP2_IllegalEquipmentParam_PDU */
    struct IMAP2_BearerServNotProvParam *pdu_BearerServNotProvParam;  
                                         /* IMAP2_BearerServNotProvParam_PDU */
    struct IMAP2_TeleservNotProvParam *pdu_TeleservNotProvParam;  
                                           /* IMAP2_TeleservNotProvParam_PDU */
    struct IMAP2_TracingBufferFullParam *pdu_TracingBufferFullParam;  
                                         /* IMAP2_TracingBufferFullParam_PDU */
    struct IMAP2_NoRoamingNbParam *pdu_NoRoamingNbParam;  
                                               /* IMAP2_NoRoamingNbParam_PDU */
    struct IMAP2_AbsentSubscriberParam *pdu_AbsentSubscriberParam;  
                                          /* IMAP2_AbsentSubscriberParam_PDU */
    struct IMAP2_BusySubscriberParam *pdu_BusySubscriberParam;  
                                            /* IMAP2_BusySubscriberParam_PDU */
    struct IMAP2_NoSubscriberReplyParam *pdu_NoSubscriberReplyParam;  
                                         /* IMAP2_NoSubscriberReplyParam_PDU */
    struct IMAP2_ForwardingViolationParam *pdu_ForwardingViolationParam;  
                                        /* IMAP2_ForwardingViolationParam_PDU */
    struct IMAP2_ForwardingFailedParam *pdu_ForwardingFailedParam;  
                                          /* IMAP2_ForwardingFailedParam_PDU */
    struct IMAP2_ATI_NotAllowedParam *pdu_ATI_NotAllowedParam;  
                                            /* IMAP2_ATI_NotAllowedParam_PDU */
    struct IMAP2_SubBusyForMT_SMS_Param *pdu_SubBusyForMT_SMS_Param;  
                                         /* IMAP2_SubBusyForMT_SMS_Param_PDU */
    struct IMAP2_MessageWaitListFullParam *pdu_MessageWaitListFullParam;  
                                        /* IMAP2_MessageWaitListFullParam_PDU */
    struct IMAP2_ResourceLimitationParam *pdu_ResourceLimitationParam;  
                                        /* IMAP2_ResourceLimitationParam_PDU */
    struct IMAP2_NoGroupCallNbParam *pdu_NoGroupCallNbParam;  
                                             /* IMAP2_NoGroupCallNbParam_PDU */
    struct IMAP2_IncompatibleTerminalParam *pdu_IncompatibleTerminalParam;  
                                        /* IMAP2_IncompatibleTerminalParam_PDU */
    struct IMAP2_ShortTermDenialParam *pdu_ShortTermDenialParam;  
                                           /* IMAP2_ShortTermDenialParam_PDU */
    struct IMAP2_LongTermDenialParam *pdu_LongTermDenialParam;  
                                            /* IMAP2_LongTermDenialParam_PDU */
    struct IMAP2_ActivateTraceModeArg *pdu_ActivateTraceModeArg;  
                                           /* IMAP2_ActivateTraceModeArg_PDU */
    struct IMAP2_ActivateTraceModeRes *pdu_ActivateTraceModeRes;  
                                           /* IMAP2_ActivateTraceModeRes_PDU */
    struct IMAP2_DeactivateTraceModeArg *pdu_DeactivateTraceModeArg;  
                                         /* IMAP2_DeactivateTraceModeArg_PDU */
    struct IMAP2_DeactivateTraceModeRes *pdu_DeactivateTraceModeRes;  
                                         /* IMAP2_DeactivateTraceModeRes_PDU */
    struct IMAP2_ISDN_AddressString *pdu_SendIMSIArg;  
                                                    /* IMAP2_SendIMSIArg_PDU */
    struct IMAP2_IMSI *pdu_SendIMSIRes;  /* IMAP2_SendIMSIRes_PDU */
    struct IMAP2_SystemFailure *pdu_SystemFailure;  
                                                  /* IMAP2_SystemFailure_PDU */
    struct IMAP2_DataMissing *pdu_DataMissing;  /* IMAP2_DataMissing_PDU */
    struct IMAP2_UnexpectedDataValue *pdu_UnexpectedDataValue;  
                                            /* IMAP2_UnexpectedDataValue_PDU */
    struct IMAP2_FacilityNotSupported *pdu_FacilityNotSupported;  
                                           /* IMAP2_FacilityNotSupported_PDU */
    struct IMAP2_IncompatibleTerminal *pdu_IncompatibleTerminal;  
                                           /* IMAP2_IncompatibleTerminal_PDU */
    struct IMAP2_ResourceLimitation *pdu_ResourceLimitation;  
                                             /* IMAP2_ResourceLimitation_PDU */
    struct IMAP2_UnknownSubscriber *pdu_UnknownSubscriber;  
                                              /* IMAP2_UnknownSubscriber_PDU */
    struct IMAP2_NumberChanged *pdu_NumberChanged;  
                                                  /* IMAP2_NumberChanged_PDU */
    struct IMAP2_UnknownMSC *pdu_UnknownMSC;  /* IMAP2_UnknownMSC_PDU */
    struct IMAP2_UnidentifiedSubscriber *pdu_UnidentifiedSubscriber;  
                                         /* IMAP2_UnidentifiedSubscriber_PDU */
    struct IMAP2_UnknownEquipment *pdu_UnknownEquipment;  
                                               /* IMAP2_UnknownEquipment_PDU */
    struct IMAP2_RoamingNotAllowed *pdu_RoamingNotAllowed;  
                                              /* IMAP2_RoamingNotAllowed_PDU */
    struct IMAP2_IllegalSubscriber *pdu_IllegalSubscriber;  
                                              /* IMAP2_IllegalSubscriber_PDU */
    struct IMAP2_IllegalEquipment *pdu_IllegalEquipment;  
                                               /* IMAP2_IllegalEquipment_PDU */
    struct IMAP2_BearerServiceNotProvisioned *pdu_BearerServiceNotProvisioned;                                          /* IMAP2_BearerServiceNotProvisioned_PDU */
    struct IMAP2_TeleserviceNotProvisioned *pdu_TeleserviceNotProvisioned;  
                                        /* IMAP2_TeleserviceNotProvisioned_PDU */
    struct IMAP2_NoHandoverNumberAvailable *pdu_NoHandoverNumberAvailable;  
                                        /* IMAP2_NoHandoverNumberAvailable_PDU */
    struct IMAP2_SubsequentHandoverFailure *pdu_SubsequentHandoverFailure;  
                                        /* IMAP2_SubsequentHandoverFailure_PDU */
    struct IMAP2_TracingBufferFull *pdu_TracingBufferFull;  
                                              /* IMAP2_TracingBufferFull_PDU */
    struct IMAP2_NoRoamingNumberAvailable *pdu_NoRoamingNumberAvailable;  
                                        /* IMAP2_NoRoamingNumberAvailable_PDU */
    struct IMAP2_AbsentSubscriber *pdu_AbsentSubscriber;  
                                               /* IMAP2_AbsentSubscriber_PDU */
    struct IMAP2_BusySubscriber *pdu_BusySubscriber;  
                                                 /* IMAP2_BusySubscriber_PDU */
    struct IMAP2_NoSubscriberReply *pdu_NoSubscriberReply;  
                                              /* IMAP2_NoSubscriberReply_PDU */
    struct IMAP2_CallBarred *pdu_CallBarred;  /* IMAP2_CallBarred_PDU */
    struct IMAP2_ForwardingViolation *pdu_ForwardingViolation;  
                                            /* IMAP2_ForwardingViolation_PDU */
    struct IMAP2_ForwardingFailed *pdu_ForwardingFailed;  
                                               /* IMAP2_ForwardingFailed_PDU */
    struct IMAP2_CUG_Reject *pdu_CUG_Reject;  /* IMAP2_CUG_Reject_PDU */
    struct IMAP2_OR_NotAllowed *pdu_OR_NotAllowed;  
                                                  /* IMAP2_OR_NotAllowed_PDU */
    struct IMAP2_ATI_NotAllowed *pdu_ATI_NotAllowed;  
                                                 /* IMAP2_ATI_NotAllowed_PDU */
    struct IMAP2_IllegalSS_Operation *pdu_IllegalSS_Operation;  
                                            /* IMAP2_IllegalSS_Operation_PDU */
    struct IMAP2_SS_ErrorStatus *pdu_SS_ErrorStatus;  
                                                 /* IMAP2_SS_ErrorStatus_PDU */
    struct IMAP2_SS_NotAvailable *pdu_SS_NotAvailable;  
                                                /* IMAP2_SS_NotAvailable_PDU */
    struct IMAP2_SS_SubscriptionViolation *pdu_SS_SubscriptionViolation;  
                                        /* IMAP2_SS_SubscriptionViolation_PDU */
    struct IMAP2_SS_Incompatibility *pdu_SS_Incompatibility;  
                                             /* IMAP2_SS_Incompatibility_PDU */
    struct IMAP2_UnknownAlphabet *pdu_UnknownAlphabet;  
                                                /* IMAP2_UnknownAlphabet_PDU */
    struct IMAP2_USSD_Busy *pdu_USSD_Busy;  /* IMAP2_USSD_Busy_PDU */
    struct IMAP2_PW_RegistrationFailure *pdu_PW_RegistrationFailure;  
                                         /* IMAP2_PW_RegistrationFailure_PDU */
    struct IMAP2_NegativePW_Check *pdu_NegativePW_Check;  
                                               /* IMAP2_NegativePW_Check_PDU */
    struct IMAP2_NumberOfPW_AttemptsViolation *pdu_NumberOfPW_AttemptsViolation;                                        /* IMAP2_NumberOfPW_AttemptsViolation_PDU */
    struct IMAP2_ShortTermDenial *pdu_ShortTermDenial;  
                                                /* IMAP2_ShortTermDenial_PDU */
    struct IMAP2_LongTermDenial *pdu_LongTermDenial;  
                                                 /* IMAP2_LongTermDenial_PDU */
    struct IMAP2_SubscriberBusyForMT_SMS *pdu_SubscriberBusyForMT_SMS;  
                                        /* IMAP2_SubscriberBusyForMT_SMS_PDU */
    struct IMAP2_SM_DeliveryFailure *pdu_SM_DeliveryFailure;  
                                             /* IMAP2_SM_DeliveryFailure_PDU */
    struct IMAP2_MessageWaitingListFull *pdu_MessageWaitingListFull;  
                                         /* IMAP2_MessageWaitingListFull_PDU */
    struct IMAP2_AbsentSubscriberSM *pdu_AbsentSubscriberSM;  
                                             /* IMAP2_AbsentSubscriberSM_PDU */
    struct IMAP2_NoGroupCallNumberAvailable *pdu_NoGroupCallNumberAvailable;  
                                        /* IMAP2_NoGroupCallNumberAvailable_PDU */
    struct IMAP2_ActivateTraceMode *pdu_ActivateTraceMode;  
                                              /* IMAP2_ActivateTraceMode_PDU */
    struct IMAP2_DeactivateTraceMode *pdu_DeactivateTraceMode;  
                                            /* IMAP2_DeactivateTraceMode_PDU */
    struct IMAP2_SendIMSI *pdu_SendIMSI;  /* IMAP2_SendIMSI_PDU */
    struct IMAP2_DialoguePDU *pdu_DialoguePDU;  /* IMAP2_DialoguePDU_PDU */
    struct IMAP2_OpenInfo *pdu_OpenInfo;  /* IMAP2_OpenInfo_PDU */
    struct IMAP2_AcceptInfo *pdu_AcceptInfo;  /* IMAP2_AcceptInfo_PDU */
    struct IMAP2_CloseInfo *pdu_CloseInfo;  /* IMAP2_CloseInfo_PDU */
    struct IMAP2_RefuseInfo *pdu_RefuseInfo;  /* IMAP2_RefuseInfo_PDU */
    IMAP2_Reason    *pdu_Reason;  /* IMAP2_Reason_PDU */
    struct IMAP2_UserAbortInfo *pdu_UserAbortInfo;  
                                                  /* IMAP2_UserAbortInfo_PDU */
    struct IMAP2_UserAbortChoice *pdu_UserAbortChoice;  
                                                /* IMAP2_UserAbortChoice_PDU */
    IMAP2_ResourceUnavailableReason *pdu_ResourceUnavailableReason;  
                                      /* IMAP2_ResourceUnavailableReason_PDU */
    IMAP2_ProcedureCancellationReason *pdu_ProcedureCancellationReason;  
                                    /* IMAP2_ProcedureCancellationReason_PDU */
    struct IMAP2_ProviderAbortInfo *pdu_ProviderAbortInfo;  
                                              /* IMAP2_ProviderAbortInfo_PDU */
    IMAP2_ProviderAbortReason *pdu_ProviderAbortReason;  
                                            /* IMAP2_ProviderAbortReason_PDU */
};

enum IMAP2_ExtensionSet_ExtensionType_PDUs {
    IMAP2_PDU_ExtensionSet_ExtensionType_UNKNOWN = 0,
    IMAP2_PDU_ExtensionSet_ExtensionType_MAX = INT_MAX
};

union IMAP2_ExtensionSet_ExtensionType_union {
    IMAP2_All_PDU_Types_union other;  /* for known extensions */
};

typedef struct IMAP2_ExtensionSet_ExtensionType {
    IMAP2_ExtensionSet_ExtensionType_PDUs pduNum;
    OssBuf          encoded;
    IMAP2_ExtensionSet_ExtensionType_union decoded;
} IMAP2_ExtensionSet_ExtensionType;

typedef struct IMAP2_PrivateExtension {
    unsigned char   bit_mask;
#       define      IMAP2_extType_present 0x80
    IMAP2__ObjectID extId;
    IMAP2_ExtensionSet_ExtensionType extType;  /* optional; set in bit_mask
                                                * IMAP2_extType_present if
                                                * present */
} IMAP2_PrivateExtension;

typedef struct IMAP2_PrivateExtensionList_ {
    struct IMAP2_PrivateExtensionList_ *next;
    IMAP2_PrivateExtension value;
} *IMAP2_PrivateExtensionList;

typedef struct IMAP2_SendRoutingInfoForSM {                              /*Timer m*/
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_SendRoutingInfoForSM;

typedef struct IMAP2_MO_ForwardSM {                              /*Timer ml*/
			// optional
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_MO_ForwardSM;

typedef struct IMAP2_MT_ForwardSM {                              /*Timer ml*/
			// optional
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_MT_ForwardSM;

typedef struct IMAP2_ReportSM_DeliveryStatus {                   /*Timer s*/
		// optional
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_ReportSM_DeliveryStatus;

typedef struct IMAP2_AlertServiceCentre {                                /*Timer s*/
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_AlertServiceCentre;

typedef struct IMAP2_InformServiceCentre {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_InformServiceCentre;                               /*Timer s*/

typedef struct IMAP2_ReadyForSM {                                /*Timer m*/
			// optional
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_ReadyForSM;

typedef struct IMAP2_BearerServiceCode {
    unsigned short  length;
    unsigned char   value[1];
} IMAP2_BearerServiceCode;

	// This type is used to represent the code identifying a single
	// bearer service, a group of bearer services, or all bearer
	// services. The services are defined in TS GSM 02.02.
	// The internal structure is defined as follows:
	//
	// plmn-specific bearer services:
	// bits 87654321: defined by the HPLMN operator

	// rest of bearer services:
	// bit 8: 0 (unused)
	// bits 7654321: group (bits 7654), and rate, if applicable
	// (bits 321)
typedef struct IMAP2_Ext_BearerServiceCode {
    unsigned short  length;
    unsigned char   value[5];
} IMAP2_Ext_BearerServiceCode;

	// This type is used to represent the code identifying a single
	// teleservice, a group of teleservices, or all teleservices. The
	// services are defined in TS GSM 02.03.
	// The internal structure is defined as follows:

	// bits 87654321: group (bits 8765) and specific service
	// (bits 4321)
typedef struct IMAP2_Ext_TeleserviceCode {
    unsigned short  length;
    unsigned char   value[5];
} IMAP2_Ext_TeleserviceCode;

	// digits of MCC, MNC, MSIN are concatenated in this order.
typedef struct IMAP2_ASCI_CallReference {
    unsigned short  length;
    unsigned char   value[8];
} IMAP2_ASCI_CallReference;

typedef struct IMAP2_CODEC_Info {
    unsigned short  length;
    unsigned char   value[10];
} IMAP2_CODEC_Info;

	// Refers to channel type
	// coded according to GSM 08.08	
typedef struct IMAP2_CipheringAlgorithm {
    unsigned short  length;
    unsigned char   value[1];
} IMAP2_CipheringAlgorithm;
	// Refers to 'permitted algorithms' in 'encryption information'
	// coded according to GSM 08.08:

	// Bits 8-1 
	// 8765 4321
	// 0000 0001	No encryption
	// 0000 0010	GSM A5/1
	// 0000 0100	GSM A5/2
	// 0000 1000	GSM A5/3
	// 0001 0000	GSM A5/4
	// 0010 0000	GSM A5/5
	// 0100 0000	GSM A5/6
	// 1000 0000	GSM A5/7

typedef unsigned short  IMAP2_GroupKeyNumber;

typedef struct IMAP2_Kc {
    unsigned short  length;
    unsigned char   value[8];
} IMAP2_Kc;

typedef unsigned short  IMAP2_EMLPP_Priority;

typedef struct IMAP2_PrepareGroupCallArg {
    unsigned char   bit_mask;
#       define      IMAP2_groupKeyNumber_present 0x80
#       define      IMAP2_groupKey_present 0x40
#       define      IMAP2_priority_present 0x20
#       define      IMAP2_uplinkFree_present 0x10
#       define      IMAP2_PrepareGroupCallArg_extensionContainer_present 0x08
    IMAP2_Ext_TeleserviceCode teleservice;
    IMAP2_ASCI_CallReference asciCallReference;
    IMAP2_CODEC_Info codec_Info;
    IMAP2_CipheringAlgorithm cipheringAlgorithm;
    IMAP2_GroupKeyNumber groupKeyNumber;  /* optional; set in bit_mask
                                           * IMAP2_groupKeyNumber_present if
                                           * present */
    IMAP2_Kc        groupKey;  /* optional; set in bit_mask
                                * IMAP2_groupKey_present if present */
    IMAP2_EMLPP_Priority priority;  /* optional; set in bit_mask
                                     * IMAP2_priority_present if present */
    Nulltype        uplinkFree;  /* optional; set in bit_mask
                                  * IMAP2_uplinkFree_present if present */
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                      * IMAP2_PrepareGroupCallArg_extensionContainer_present if
                      * present */
} IMAP2_PrepareGroupCallArg;

typedef struct IMAP2_ISDN_AddressString {
    unsigned short  length;
    unsigned char   value[9];
} IMAP2_ISDN_AddressString;

typedef struct IMAP2_PrepareGroupCallRes {
    unsigned char   bit_mask;
#       define      IMAP2_PrepareGroupCallRes_extensionContainer_present 0x80
    IMAP2_ISDN_AddressString groupCallNumber;
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                      * IMAP2_PrepareGroupCallRes_extensionContainer_present if
                      * present */
} IMAP2_PrepareGroupCallRes;

	// all other values of Alerting Category are reserved
	// Alerting categories are defined in GSM 02.07

// data types for numbering and identification
typedef struct IMAP2_IMSI {
    unsigned short  length;
    unsigned char   value[8];
} IMAP2_IMSI;

typedef struct IMAP2_SendGroupCallEndSignalArg {
    unsigned char   bit_mask;
#       define      IMAP2_SendGroupCallEndSignalArg_imsi_present 0x80
#       define      IMAP2_SendGroupCallEndSignalArg_extensionContainer_present 0x40
    IMAP2_IMSI      imsi;  /* optional; set in bit_mask
                            * IMAP2_SendGroupCallEndSignalArg_imsi_present if
                            * present */
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                * IMAP2_SendGroupCallEndSignalArg_extensionContainer_present if
                * present */
} IMAP2_SendGroupCallEndSignalArg;

typedef struct IMAP2_SendGroupCallEndSignalRes {
    unsigned char   bit_mask;
#       define      IMAP2_SendGroupCallEndSignalRes_extensionContainer_present 0x80
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                * IMAP2_SendGroupCallEndSignalRes_extensionContainer_present if
                * present */
} IMAP2_SendGroupCallEndSignalRes;

typedef struct IMAP2_ForwardGroupCallSignallingArg {
    unsigned char   bit_mask;
#       define      IMAP2_ForwardGroupCallSignallingArg_imsi_present 0x80
#       define      IMAP2_uplinkRequestAck_present 0x40
#       define      IMAP2_ForwardGroupCallSignallingArg_uplinkReleaseIndication_present 0x20
#       define      IMAP2_uplinkRejectCommand_present 0x10
#       define      IMAP2_uplinkSeizedCommand_present 0x08
#       define      IMAP2_uplinkReleaseCommand_present 0x04
#       define      IMAP2_ForwardGroupCallSignallingArg_extensionContainer_present 0x02
    IMAP2_IMSI      imsi;  /* optional; set in bit_mask
                            * IMAP2_ForwardGroupCallSignallingArg_imsi_present
                            * if present */
    Nulltype        uplinkRequestAck;  /* optional; set in bit_mask
                                        * IMAP2_uplinkRequestAck_present if
                                        * present */
    Nulltype        uplinkReleaseIndication;  /* optional; set in bit_mask
       * IMAP2_ForwardGroupCallSignallingArg_uplinkReleaseIndication_present if
       * present */
    Nulltype        uplinkRejectCommand;  /* optional; set in bit_mask
                                           * IMAP2_uplinkRejectCommand_present
                                           * if present */
    Nulltype        uplinkSeizedCommand;  /* optional; set in bit_mask
                                           * IMAP2_uplinkSeizedCommand_present
                                           * if present */
    Nulltype        uplinkReleaseCommand;  /* optional; set in bit_mask
                                            * IMAP2_uplinkReleaseCommand_present
                                            * if present */
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
            * IMAP2_ForwardGroupCallSignallingArg_extensionContainer_present if
            * present */
} IMAP2_ForwardGroupCallSignallingArg;

typedef struct IMAP2_ProcessGroupCallSignallingArg {
    unsigned char   bit_mask;
#       define      IMAP2_uplinkRequest_present 0x80
#       define      IMAP2_ProcessGroupCallSignallingArg_uplinkReleaseIndication_present 0x40
#       define      IMAP2_releaseGroupCall_present 0x20
#       define      IMAP2_ProcessGroupCallSignallingArg_extensionContainer_present 0x10
    Nulltype        uplinkRequest;  /* optional; set in bit_mask
                                     * IMAP2_uplinkRequest_present if present */
    Nulltype        uplinkReleaseIndication;  /* optional; set in bit_mask
       * IMAP2_ProcessGroupCallSignallingArg_uplinkReleaseIndication_present if
       * present */
    Nulltype        releaseGroupCall;  /* optional; set in bit_mask
                                        * IMAP2_releaseGroupCall_present if
                                        * present */
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
            * IMAP2_ProcessGroupCallSignallingArg_extensionContainer_present if
            * present */
} IMAP2_ProcessGroupCallSignallingArg;

	// This type (Telephony Binary Coded Decimal String) is used to
	// represent several digits from 0 through 9, *, #, a, b, c, two
	// digits per octet, each digit encoded 0000 to 1001 (0 to 9),
	// 1010 (*), 1011 (#), 1100 (a), 1101 (b) or 1110 (c); 1111 used
	// as filler when there is an odd number of digits.

	// bits 8765 of octet n encoding digit 2n
	// bits 4321 of octet n encoding digit 2(n-1) +1
typedef struct IMAP2_AddressString {
    unsigned short  length;
    unsigned char   value[20];
} IMAP2_AddressString;

typedef unsigned short  IMAP2_SM_RP_MTI;

	// 0 SMS Deliver 
	// 1 SMS Status Report
	// other values are reserved for future use and shall be discarded if
	// received
typedef struct IMAP2_SM_RP_SMEA {
    unsigned short  length;
    unsigned char   value[12];
} IMAP2_SM_RP_SMEA;

typedef struct IMAP2_RoutingInfoForSM_Arg {
    unsigned char   bit_mask;
#       define      IMAP2_RoutingInfoForSM_Arg_extensionContainer_present 0x80
#       define      IMAP2_gprsSupportIndicator_present 0x40
#       define      IMAP2_sm_RP_MTI_present 0x20
#       define      IMAP2_sm_RP_SMEA_present 0x10
    IMAP2_ISDN_AddressString msisdn;
    ossBoolean      sm_RP_PRI;
    IMAP2_AddressString serviceCentreAddress;
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                     * IMAP2_RoutingInfoForSM_Arg_extensionContainer_present if
                     * present */
    Nulltype        gprsSupportIndicator;  /* extension #1; optional; set in
                                   * bit_mask IMAP2_gprsSupportIndicator_present
                                   * if present */
   // gprsSupportIndicator is set only if the SMS-GMSC supports
   // receiving of two numbers from the HLR
    IMAP2_SM_RP_MTI sm_RP_MTI;  /* extension #2; optional; set in bit_mask
                                 * IMAP2_sm_RP_MTI_present if present */
    IMAP2_SM_RP_SMEA sm_RP_SMEA;  /* extension #3; optional; set in bit_mask
                                   * IMAP2_sm_RP_SMEA_present if present */
} IMAP2_RoutingInfoForSM_Arg;

	// this parameter contains an address field which is encoded 
	// as defined in GSM 03.40. An address field contains 3 elements :
	// 		address-length
	// 		type-of-address
	// 		address-value
typedef struct IMAP2_LocationInfo {
    unsigned short  choice;
#       define      IMAP2_LocationInfo_roamingNumber_chosen 1
#       define      IMAP2_LocationInfo_msc_Number_chosen 2
    union _union {
        IMAP2_ISDN_AddressString roamingNumber;  /* to choose, set choice to
                                   * IMAP2_LocationInfo_roamingNumber_chosen */
   // NU>1 roamingNumber must not be used in version greater 1
        IMAP2_ISDN_AddressString msc_Number;  /* to choose, set choice to
                                      * IMAP2_LocationInfo_msc_Number_chosen */
    } u;
} IMAP2_LocationInfo;

typedef struct IMAP2_LMSI {
    unsigned short  length;
    unsigned char   value[4];
} IMAP2_LMSI;

typedef struct IMAP2_LocationInfoWithLMSI {
    unsigned char   bit_mask;
#       define      IMAP2_LocationInfoWithLMSI_lmsi_present 0x80
    IMAP2_LocationInfo locationInfo;
    IMAP2_LMSI      lmsi;  /* optional; set in bit_mask
                            * IMAP2_LocationInfoWithLMSI_lmsi_present if
                            * present */
} IMAP2_LocationInfoWithLMSI;

typedef struct IMAP2_RoutingInfoForSM_Res {
    unsigned char   bit_mask;
#       define      IMAP2_RoutingInfoForSM_Res_extensionContainer_present 0x80
    IMAP2_IMSI      imsi;
    IMAP2_LocationInfoWithLMSI locationInfoWithLMSI;
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                     * IMAP2_RoutingInfoForSM_Res_extensionContainer_present if
                     * present */
} IMAP2_RoutingInfoForSM_Res;

typedef struct IMAP2_Additional_Number {
    unsigned short  choice;
#       define      IMAP2_Additional_Number_msc_Number_chosen 1
#       define      IMAP2_sgsn_Number_chosen 2
    union _union {
        IMAP2_ISDN_AddressString msc_Number;  /* to choose, set choice to
                                 * IMAP2_Additional_Number_msc_Number_chosen */
        IMAP2_ISDN_AddressString sgsn_Number;  /* to choose, set choice to
                                                * IMAP2_sgsn_Number_chosen */
    } u;
} IMAP2_Additional_Number;

typedef struct IMAP2_SM_RP_DA {
    unsigned short  choice;
#       define      IMAP2_SM_RP_DA_imsi_chosen 1
#       define      IMAP2_lmsi_chosen 2
#       define      IMAP2_serviceCentreAddressDA_chosen 3
#       define      IMAP2_noSM_RP_DA_chosen 4
    union _union {
        IMAP2_IMSI      imsi;  /* to choose, set choice to
                                * IMAP2_SM_RP_DA_imsi_chosen */
        IMAP2_LMSI      lmsi;  /* to choose, set choice to IMAP2_lmsi_chosen */
        IMAP2_AddressString serviceCentreAddressDA;  /* to choose, set choice to
                                       * IMAP2_serviceCentreAddressDA_chosen */
        Nulltype        noSM_RP_DA;  /* to choose, set choice to
                                      * IMAP2_noSM_RP_DA_chosen */
    } u;
} IMAP2_SM_RP_DA;

typedef struct IMAP2_SM_RP_OA {
    unsigned short  choice;
#       define      IMAP2_msisdn_chosen 1
#       define      IMAP2_serviceCentreAddressOA_chosen 2
#       define      IMAP2_noSM_RP_OA_chosen 3
    union _union {
        IMAP2_ISDN_AddressString msisdn;  /* to choose, set choice to
                                           * IMAP2_msisdn_chosen */
        IMAP2_AddressString serviceCentreAddressOA;  /* to choose, set choice to
                                       * IMAP2_serviceCentreAddressOA_chosen */
        Nulltype        noSM_RP_OA;  /* to choose, set choice to
                                      * IMAP2_noSM_RP_OA_chosen */
    } u;
} IMAP2_SM_RP_OA;

typedef struct IMAP2_SignalInfo {
    unsigned short  length;
    unsigned char   value[200];
} IMAP2_SignalInfo;

	// additional-number can be either msc-number or sgsn-number
	// if received networkNode-number is msc-number then the 	
	// additional number is sgsn-number 
	// if received networkNode-number is sgsn-number then the 
	// additional number is msc-number 
typedef struct IMAP2_MO_ForwardSM_Arg {
    unsigned char   bit_mask;
#       define      IMAP2_MO_ForwardSM_Arg_extensionContainer_present 0x80
    IMAP2_SM_RP_DA  sm_RP_DA;
    IMAP2_SM_RP_OA  sm_RP_OA;
    IMAP2_SignalInfo sm_RP_UI;
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                         * IMAP2_MO_ForwardSM_Arg_extensionContainer_present if
                         * present */
} IMAP2_MO_ForwardSM_Arg;

typedef struct IMAP2_MO_ForwardSM_Res {
    unsigned char   bit_mask;
#       define      IMAP2_MO_ForwardSM_Res_extensionContainer_present 0x80
    IMAP2_SignalInfo sm_RP_UI;
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                         * IMAP2_MO_ForwardSM_Res_extensionContainer_present if
                         * present */
} IMAP2_MO_ForwardSM_Res;

typedef struct IMAP2_MT_ForwardSM_Arg {
    unsigned char   bit_mask;
#       define      IMAP2_moreMessagesToSend_present 0x80
#       define      IMAP2_MT_ForwardSM_Arg_extensionContainer_present 0x40
    IMAP2_SM_RP_DA  sm_RP_DA;
    IMAP2_SM_RP_OA  sm_RP_OA;
    IMAP2_SignalInfo sm_RP_UI;
    Nulltype        moreMessagesToSend;  /* optional; set in bit_mask
                                          * IMAP2_moreMessagesToSend_present if
                                          * present */
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                         * IMAP2_MT_ForwardSM_Arg_extensionContainer_present if
                         * present */
} IMAP2_MT_ForwardSM_Arg;

typedef struct IMAP2_MT_ForwardSM_Res {
    unsigned char   bit_mask;
#       define      IMAP2_sm_RP_UI_present 0x80
#       define      IMAP2_MT_ForwardSM_Res_extensionContainer_present 0x40
    IMAP2_SignalInfo sm_RP_UI;  /* optional; set in bit_mask
                                 * IMAP2_sm_RP_UI_present if present */
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                         * IMAP2_MT_ForwardSM_Res_extensionContainer_present if
                         * present */
} IMAP2_MT_ForwardSM_Res;

typedef enum IMAP2_SM_DeliveryOutcome {
    IMAP2_SM_DeliveryOutcome_memoryCapacityExceeded = 0,
    IMAP2_SM_DeliveryOutcome_absentSubscriber = 1,
    IMAP2_successfulTransfer = 2
} IMAP2_SM_DeliveryOutcome;

typedef struct IMAP2_ReportSM_DeliveryStatusArg {
    IMAP2_ISDN_AddressString msisdn;
    IMAP2_AddressString serviceCentreAddress;
    IMAP2_SM_DeliveryOutcome sm_DeliveryOutcome;
} IMAP2_ReportSM_DeliveryStatusArg;

typedef struct IMAP2_ReportSM_DeliveryStatusRes {
    unsigned char   bit_mask;
#       define      IMAP2_ReportSM_DeliveryStatusRes_storedMSISDN_present 0x80
#       define      IMAP2_ReportSM_DeliveryStatusRes_extensionContainer_present 0x40
    IMAP2_ISDN_AddressString storedMSISDN;  /* optional; set in bit_mask
                     * IMAP2_ReportSM_DeliveryStatusRes_storedMSISDN_present if
                     * present */
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
               * IMAP2_ReportSM_DeliveryStatusRes_extensionContainer_present if
               * present */
} IMAP2_ReportSM_DeliveryStatusRes;

typedef struct IMAP2_AlertServiceCentreArg {
    IMAP2_ISDN_AddressString msisdn;
    IMAP2_AddressString serviceCentreAddress;
} IMAP2_AlertServiceCentreArg;

typedef struct IMAP2_MW_Status {
    unsigned short  length;  /* number of significant bits */
    unsigned char   value[1];
} IMAP2_MW_Status;
#define                     IMAP2_sc_AddressNotIncluded 0x80
#define                     IMAP2_sc_AddressNotIncluded_byte 0
#define                     IMAP2_mnrf_Set 0x40
#define                     IMAP2_mnrf_Set_byte 0
#define                     IMAP2_mcef_Set 0x20
#define                     IMAP2_mcef_Set_byte 0

typedef struct IMAP2_InformServiceCentreArg {
    unsigned char   bit_mask;
#       define      IMAP2_InformServiceCentreArg_storedMSISDN_present 0x80
#       define      IMAP2_mw_Status_present 0x40
#       define      IMAP2_InformServiceCentreArg_extensionContainer_present 0x20
    IMAP2_ISDN_AddressString storedMSISDN;  /* optional; set in bit_mask
                         * IMAP2_InformServiceCentreArg_storedMSISDN_present if
                         * present */
    IMAP2_MW_Status mw_Status;  /* optional; set in bit_mask
                                 * IMAP2_mw_Status_present if present */
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                   * IMAP2_InformServiceCentreArg_extensionContainer_present if
                   * present */
} IMAP2_InformServiceCentreArg;

typedef enum IMAP2_AlertReason {
    IMAP2_ms_Present = 0,
    IMAP2_memoryAvailable = 1
} IMAP2_AlertReason;

typedef struct IMAP2_ReadyForSM_Arg {
    IMAP2_IMSI      imsi;
    IMAP2_AlertReason alertReason;
} IMAP2_ReadyForSM_Arg;

typedef struct IMAP2_ReadyForSM_Res {
    unsigned char   bit_mask;
#       define      IMAP2_ReadyForSM_Res_extensionContainer_present 0x80
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                           * IMAP2_ReadyForSM_Res_extensionContainer_present if
                           * present */
} IMAP2_ReadyForSM_Res;

typedef struct IMAP2_SendRoutingInfo {                           /*Timer m*/
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_SendRoutingInfo;

typedef struct IMAP2_ProvideRoamingNumber {                              /*Timer m*/
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_ProvideRoamingNumber;

typedef struct IMAP2_ResumeCallHandling {                                /*Timer m*/
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_ResumeCallHandling;

typedef struct IMAP2_ProvideSIWFSNumber {                                /*Timer m*/
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_ProvideSIWFSNumber;

typedef struct IMAP2_SIWFSSignallingModify {                             /*Timer m*/
		// optional
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_SIWFSSignallingModify;

typedef struct IMAP2_PrepareGroupCall {                          /*Timer m*/
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_PrepareGroupCall;

typedef struct IMAP2_SendGroupCallEndSignal {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_SendGroupCallEndSignal;                            /*Timer l*/

typedef struct IMAP2_ProcessGroupCallSignalling {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_ProcessGroupCallSignalling;                        /*Timer s*/

typedef struct IMAP2_ForwardGroupCallSignalling {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_ForwardGroupCallSignalling;                        /*Timer s*/

typedef struct IMAP2_SS_Code {
    unsigned short  length;
    unsigned char   value[1];
} IMAP2_SS_Code;

	// The internal structure is defined in ETS 300 138.
typedef struct IMAP2_MS_DataTypes_CUG_Interlock {
    unsigned short  length;
    unsigned char   value[4];
} IMAP2_MS_DataTypes_CUG_Interlock;

typedef struct IMAP2_CUG_CheckInfo {
    unsigned char   bit_mask;
#       define      IMAP2_cug_OutgoingAccess_present 0x80
#       define      IMAP2_CUG_CheckInfo_extensionContainer_present 0x40
    IMAP2_MS_DataTypes_CUG_Interlock cug_Interlock;
    Nulltype        cug_OutgoingAccess;  /* optional; set in bit_mask
                                          * IMAP2_cug_OutgoingAccess_present if
                                          * present */
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                            * IMAP2_CUG_CheckInfo_extensionContainer_present if
                            * present */
} IMAP2_CUG_CheckInfo;

typedef unsigned short  IMAP2_NumberOfForwarding;

	// This NamedValue represents the theoretical maximum number of
	// octets which are available to carry a single data type,
	// without requiring segmentation to cope with the network layer
	// service. However, the actual maximum size available for a data
	// type may be lower, especially when other information elements
	// have to be included in the same component.
typedef enum IMAP2_ProtocolId {
    IMAP2_gsm_0408 = 1,
    IMAP2_gsm_0806 = 2,
    IMAP2_gsm_BSSMAP = 3,
	// Value 3 is reserved and must not be used
    IMAP2_ets_300102_1 = 4
} IMAP2_ProtocolId;

typedef struct IMAP2_ExternalSignalInfo {
    unsigned char   bit_mask;
#       define      IMAP2_ExternalSignalInfo_extensionContainer_present 0x80
    IMAP2_ProtocolId protocolId;
    IMAP2_SignalInfo signalInfo;
	// Information about the internal structure is given in
	// subclause 7.6.9.
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                       * IMAP2_ExternalSignalInfo_extensionContainer_present if
                       * present */
	// extensionContainer must not be used in version 2
} IMAP2_ExternalSignalInfo;

typedef struct IMAP2_SendRoutingInfoArg {
    unsigned char   bit_mask;
#       define      IMAP2_SendRoutingInfoArg_cug_CheckInfo_present 0x80
#       define      IMAP2_numberOfForwarding_present 0x40
#       define      IMAP2_SendRoutingInfoArg_networkSignalInfo_present 0x20
    IMAP2_ISDN_AddressString msisdn;
    IMAP2_CUG_CheckInfo cug_CheckInfo;  /* optional; set in bit_mask
                            * IMAP2_SendRoutingInfoArg_cug_CheckInfo_present if
                            * present */
    IMAP2_NumberOfForwarding numberOfForwarding;  /* optional; set in bit_mask
                                          * IMAP2_numberOfForwarding_present if
                                          * present */
    IMAP2_ExternalSignalInfo networkSignalInfo;  /* optional; set in bit_mask
                        * IMAP2_SendRoutingInfoArg_networkSignalInfo_present if
                        * present */
} IMAP2_SendRoutingInfoArg;

typedef struct IMAP2_CallReferenceNumber {
    unsigned short  length;
    unsigned char   value[8];
} IMAP2_CallReferenceNumber;

typedef struct IMAP2_ISDN_SubaddressString {
    unsigned short  length;
    unsigned char   value[21];
} IMAP2_ISDN_SubaddressString;

	// bits 8765: 0000 (unused)
	// bits 4321: Used to convey the "P bit","R bit","A bit" and "Q bit",
	//		    representing supplementary service state information
	//		    as defined in TS GSM 03.11

	// bit 4: "Q bit"

	// bit 3: "P bit"

	// bit 2: "R bit"

	// bit 1: "A bit"
typedef struct IMAP2_ForwardingOptions {
    unsigned short  length;
    unsigned char   value[1];
} IMAP2_ForwardingOptions;

typedef struct IMAP2_ForwardingData {
    unsigned char   bit_mask;
#       define      IMAP2_ForwardingData_forwardedToNumber_present 0x80
#       define      IMAP2_ForwardingData_forwardedToSubaddress_present 0x40
#       define      IMAP2_ForwardingData_forwardingOptions_present 0x20
#       define      IMAP2_ForwardingData_extensionContainer_present 0x10
    IMAP2_ISDN_AddressString forwardedToNumber;  /* optional; set in bit_mask
                            * IMAP2_ForwardingData_forwardedToNumber_present if
                            * present */
	// When this datatype is sent from an HLR which supports CAMEL Phase 2
	// to a GMSC which supports CAMEL Phase 2 the GMSC shall not check the
	// format of the number
    IMAP2_ISDN_SubaddressString forwardedToSubaddress;  /* optional; set in
                                   * bit_mask
                        * IMAP2_ForwardingData_forwardedToSubaddress_present if
                        * present */
    IMAP2_ForwardingOptions forwardingOptions;  /* optional; set in bit_mask
                            * IMAP2_ForwardingData_forwardingOptions_present if
                            * present */
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                           * IMAP2_ForwardingData_extensionContainer_present if
                           * present */
} IMAP2_ForwardingData;

typedef struct IMAP2_RoutingInfo {
    unsigned short  choice;
#       define      IMAP2_RoutingInfo_roamingNumber_chosen 1
#       define      IMAP2_forwardingData_chosen 2
    union _union {
        IMAP2_ISDN_AddressString roamingNumber;  /* to choose, set choice to
                                    * IMAP2_RoutingInfo_roamingNumber_chosen */
        IMAP2_ForwardingData forwardingData;  /* to choose, set choice to
                                               * IMAP2_forwardingData_chosen */
    } u;
} IMAP2_RoutingInfo;

// exception handling:
// Only value 1 is used.
// Values in the ranges 2-127 are reserved for future use.
// If received values 2-127 shall be mapped on to value 1.
typedef struct IMAP2_SendRoutingInfoRes {
    unsigned char   bit_mask;
#       define      IMAP2_SendRoutingInfoRes_cug_CheckInfo_present 0x80
    IMAP2_IMSI      imsi;
    IMAP2_RoutingInfo routingInfo;
    IMAP2_CUG_CheckInfo cug_CheckInfo;  /* optional; set in bit_mask
                            * IMAP2_SendRoutingInfoRes_cug_CheckInfo_present if
                            * present */
   // OA1 cug-CheckInfo must be absent in version 1
} IMAP2_SendRoutingInfoRes;

typedef struct IMAP2_CCBS_Indicators {
    unsigned char   bit_mask;
#       define      IMAP2_CCBS_Indicators_ccbs_Possible_present 0x80
#       define      IMAP2_keepCCBS_CallIndicator_present 0x40
#       define      IMAP2_CCBS_Indicators_extensionContainer_present 0x20
    Nulltype        ccbs_Possible;  /* optional; set in bit_mask
                               * IMAP2_CCBS_Indicators_ccbs_Possible_present if
                               * present */
    Nulltype        keepCCBS_CallIndicator;  /* optional; set in bit_mask
                                      * IMAP2_keepCCBS_CallIndicator_present if
                                      * present */
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                          * IMAP2_CCBS_Indicators_extensionContainer_present if
                          * present */
} IMAP2_CCBS_Indicators;

typedef struct IMAP2_ProvideRoamingNumberArg {
    unsigned char   bit_mask;
#       define      IMAP2_ProvideRoamingNumberArg_msisdn_present 0x80
#       define      IMAP2_previousRoamingNumber_present 0x40
#       define      IMAP2_ProvideRoamingNumberArg_lmsi_present 0x20
#       define      IMAP2_gsm_BearerCapability_present 0x10
#       define      IMAP2_ProvideRoamingNumberArg_networkSignalInfo_present 0x08
    IMAP2_IMSI      imsi;
    IMAP2_ISDN_AddressString msc_Number;
    IMAP2_ISDN_AddressString msisdn;  /* optional; set in bit_mask
                              * IMAP2_ProvideRoamingNumberArg_msisdn_present if
                              * present */
    IMAP2_ISDN_AddressString previousRoamingNumber;  /* optional; set in
                                   * bit_mask
                                   * IMAP2_previousRoamingNumber_present if
                                   * present */
    IMAP2_LMSI      lmsi;  /* optional; set in bit_mask
                            * IMAP2_ProvideRoamingNumberArg_lmsi_present if
                            * present */
    IMAP2_ExternalSignalInfo gsm_BearerCapability;  /* optional; set in bit_mask
                                        * IMAP2_gsm_BearerCapability_present if
                                        * present */
    IMAP2_ExternalSignalInfo networkSignalInfo;  /* optional; set in bit_mask
                   * IMAP2_ProvideRoamingNumberArg_networkSignalInfo_present if
                   * present */
} IMAP2_ProvideRoamingNumberArg;

typedef struct IMAP2_ProvideRoamingNumberRes {
    unsigned char   bit_mask;
#       define      IMAP2_ProvideRoamingNumberRes_extensionContainer_present 0x80
    IMAP2_ISDN_AddressString roamingNumber;
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                  * IMAP2_ProvideRoamingNumberRes_extensionContainer_present if
                  * present */
} IMAP2_ProvideRoamingNumberRes;

typedef struct IMAP2_ResumeCallHandlingRes {
    unsigned char   bit_mask;
#       define      IMAP2_ResumeCallHandlingRes_extensionContainer_present 0x80
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                    * IMAP2_ResumeCallHandlingRes_extensionContainer_present if
                    * present */
} IMAP2_ResumeCallHandlingRes;

typedef struct IMAP2_CallDirection {
    unsigned short  length;
    unsigned char   value[1];
} IMAP2_CallDirection;

typedef struct IMAP2_ProvideSIWFSNumberArg {
    unsigned char   bit_mask;
#       define      IMAP2_lowerLayerCompatibility_present 0x80
#       define      IMAP2_highLayerCompatibility_present 0x40
#       define      IMAP2_ProvideSIWFSNumberArg_extensionContainer_present 0x20
    IMAP2_ExternalSignalInfo gsm_BearerCapability;
    IMAP2_ExternalSignalInfo isdn_BearerCapability;
    IMAP2_CallDirection call_Direction;
    IMAP2_ISDN_AddressString b_Subscriber_Address;
    IMAP2_ExternalSignalInfo chosenChannel;
    IMAP2_ExternalSignalInfo lowerLayerCompatibility;  /* optional; set in
                                   * bit_mask
                                   * IMAP2_lowerLayerCompatibility_present if
                                   * present */
    IMAP2_ExternalSignalInfo highLayerCompatibility;  /* optional; set in
                                   * bit_mask
                                   * IMAP2_highLayerCompatibility_present if
                                   * present */
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                    * IMAP2_ProvideSIWFSNumberArg_extensionContainer_present if
                    * present */
} IMAP2_ProvideSIWFSNumberArg;

     // OCTET 1

     // bit 1 (direction of call)
     // 0  Mobile Originated Call (MOC)
     // 1  Mobile Terminated Call (MTC)
typedef struct IMAP2_ProvideSIWFSNumberRes {
    unsigned char   bit_mask;
#       define      IMAP2_ProvideSIWFSNumberRes_extensionContainer_present 0x80
    IMAP2_ISDN_AddressString sIWFSNumber;
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                    * IMAP2_ProvideSIWFSNumberRes_extensionContainer_present if
                    * present */
} IMAP2_ProvideSIWFSNumberRes;

typedef struct IMAP2_SIWFSSignallingModifyArg {
    unsigned char   bit_mask;
#       define      IMAP2_channelType_present 0x80
#       define      IMAP2_SIWFSSignallingModifyArg_chosenChannel_present 0x40
#       define      IMAP2_SIWFSSignallingModifyArg_extensionContainer_present 0x20
    IMAP2_ExternalSignalInfo channelType;  /* optional; set in bit_mask
                                            * IMAP2_channelType_present if
                                            * present */
    IMAP2_ExternalSignalInfo chosenChannel;  /* optional; set in bit_mask
                      * IMAP2_SIWFSSignallingModifyArg_chosenChannel_present if
                      * present */
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                 * IMAP2_SIWFSSignallingModifyArg_extensionContainer_present if
                 * present */
} IMAP2_SIWFSSignallingModifyArg;

typedef struct IMAP2_SIWFSSignallingModifyRes {
    unsigned char   bit_mask;
#       define      IMAP2_SIWFSSignallingModifyRes_chosenChannel_present 0x80
#       define      IMAP2_SIWFSSignallingModifyRes_extensionContainer_present 0x40
    IMAP2_ExternalSignalInfo chosenChannel;  /* optional; set in bit_mask
                      * IMAP2_SIWFSSignallingModifyRes_chosenChannel_present if
                      * present */
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                 * IMAP2_SIWFSSignallingModifyRes_extensionContainer_present if
                 * present */
} IMAP2_SIWFSSignallingModifyRes;

typedef enum IMAP2_CCBS_SubscriberStatus {
    IMAP2_ccbsNotIdle = 0,
    IMAP2_ccbsIdle = 1,
    IMAP2_ccbsNotReachable = 2
} IMAP2_CCBS_SubscriberStatus;

typedef struct IMAP2_EventReportData {
    unsigned char   bit_mask;
#       define      IMAP2_ccbs_SubscriberStatus_present 0x80
#       define      IMAP2_EventReportData_extensionContainer_present 0x40
    IMAP2_CCBS_SubscriberStatus ccbs_SubscriberStatus;  /* optional; set in
                                   * bit_mask
                                   * IMAP2_ccbs_SubscriberStatus_present if
                                   * present */
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                          * IMAP2_EventReportData_extensionContainer_present if
                          * present */
} IMAP2_EventReportData;

typedef enum IMAP2_MonitoringMode {
    IMAP2_a_side = 0,
    IMAP2_b_side = 1
} IMAP2_MonitoringMode;

//	exception handling: 
//  reception of values 2-10 shall be mapped 'a-side'
//  reception of values > 10 shall be mapped to 'b-side'
typedef enum IMAP2_CallOutcome {
    IMAP2_success = 0,
    IMAP2_failure = 1,
    IMAP2_CallOutcome_busy = 2
} IMAP2_CallOutcome;

typedef struct IMAP2_CallReportData {
    unsigned char   bit_mask;
#       define      IMAP2_monitoringMode_present 0x80
#       define      IMAP2_callOutcome_present 0x40
#       define      IMAP2_CallReportData_extensionContainer_present 0x20
    IMAP2_MonitoringMode monitoringMode;  /* optional; set in bit_mask
                                           * IMAP2_monitoringMode_present if
                                           * present */
    IMAP2_CallOutcome callOutcome;  /* optional; set in bit_mask
                                     * IMAP2_callOutcome_present if present */
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                           * IMAP2_CallReportData_extensionContainer_present if
                           * present */
} IMAP2_CallReportData;

//  exception handling: 
//  reception of values 3-10 shall be mapped to 'ccbsNotIdle'
//  reception of values 11-20 shall be mapped to 'ccbsIdle'
//  reception of values > 20 shall be mapped to 'ccbsNotReachable' 
typedef struct IMAP2_StatusReportArg {
    unsigned char   bit_mask;
#       define      IMAP2_eventReportData_present 0x80
#       define      IMAP2_callReportdata_present 0x40
#       define      IMAP2_StatusReportArg_extensionContainer_present 0x20
    IMAP2_IMSI      imsi;
    IMAP2_EventReportData eventReportData;  /* optional; set in bit_mask
                                             * IMAP2_eventReportData_present if
                                             * present */
    IMAP2_CallReportData callReportdata;  /* optional; set in bit_mask
                                           * IMAP2_callReportdata_present if
                                           * present */
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                          * IMAP2_StatusReportArg_extensionContainer_present if
                          * present */
} IMAP2_StatusReportArg;

//	exception handling: 
//  reception of values 3-10 shall be mapped to 'success'
//  reception of values 11-20 shall be mapped to 'failure'
//  reception of values > 20 shall be mapped to 'busy'
typedef struct IMAP2_StatusReportRes {
    unsigned char   bit_mask;
#       define      IMAP2_StatusReportRes_extensionContainer_present 0x80
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                          * IMAP2_StatusReportRes_extensionContainer_present if
                          * present */
} IMAP2_StatusReportRes;
// exception handling:
// reception of values 6-20 shall be mapped to 'accepted'
// reception of values 21-30 shall be mapped to 'rejected'
// reception of values 31-40 shall be mapped to 'noResponseFromFreeMS'
// reception of values 41-50 shall be mapped to 'noResponseFromBusyMS'
// reception of values 51-60 shall be mapped to 'udubFromFreeMS'
// reception of values > 60 shall be mapped to 'udubFromBusyMS'

	// location registration operations
	// handover operations
	// authentication management operations
	// IMEI management operations
	// subscriber management operations
	// fault recovery operations
// location registration operations
typedef struct IMAP2_UpdateLocation {                            /*Timer m*/
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_UpdateLocation;

typedef struct IMAP2_CancelLocation {                            /*Timer m*/
			// optional
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_CancelLocation;

typedef struct IMAP2_PurgeMS {                           /*Timer m*/
			// optional
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_PurgeMS;

typedef struct IMAP2_SendIdentification {                         /*Timer s*/
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_SendIdentification;

// handover operations
typedef struct IMAP2_PrepareHandover {                           /*Timer m*/
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_PrepareHandover;

typedef struct IMAP2_SendEndSignal {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_SendEndSignal;                             /*Timer l*/

//	RESULT
typedef struct IMAP2_ProcessAccessSignalling {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_ProcessAccessSignalling;                   /*Timer s*/

typedef struct IMAP2_ForwardAccessSignalling {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_ForwardAccessSignalling;                   /*Timer s*/

typedef struct IMAP2_PrepareSubsequentHandover {                 /*Timer m*/
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_PrepareSubsequentHandover;

// authentication management operations
typedef struct IMAP2_SendAuthenticationInfo {                    /*Timer m*/
		// optional
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_SendAuthenticationInfo;

// IMEI management operations
typedef struct IMAP2_CheckIMEI {                         /*Timer m*/
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_CheckIMEI;

// subscriber management operations
typedef struct IMAP2_InsertSubscriberData {                              /*Timer m*/
		// optional
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_InsertSubscriberData;

typedef struct IMAP2_DeleteSubscriberData {                              /*Timer m*/
		// optional
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_DeleteSubscriberData;

// fault recovery operations
typedef struct IMAP2_Reset {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_Reset;                             /*Timer m*/

typedef struct IMAP2_RestoreData {                               /*Timer m*/
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_RestoreData;

typedef struct IMAP2_RegisterPasswordArg {
    unsigned short  length;
    unsigned char   value[1];
} IMAP2_RegisterPasswordArg;

typedef struct IMAP2_TeleserviceCode {
    unsigned short  length;
    unsigned char   value[1];
} IMAP2_TeleserviceCode;

	// The internal structure is defined by the Carrier Identification
	// parameter in ANSI T1.113.3. Carrier codes between "000" and "999" may
	// be encoded as 3 digits using "000" to "999" or as 4 digits using 
	// "0000" to "0999". Carrier codes between "1000" and "9999" are encoded
	// using 4 digits.

// data types for subscriber management
typedef struct IMAP2_BasicServiceCode {
    unsigned short  choice;
#       define      IMAP2_bearerService_chosen 1
#       define      IMAP2_teleservice_chosen 2
    union _union {
        IMAP2_BearerServiceCode bearerService;  /* to choose, set choice to
                                                * IMAP2_bearerService_chosen */
        IMAP2_TeleserviceCode teleservice;  /* to choose, set choice to
                                             * IMAP2_teleservice_chosen */
    } u;
} IMAP2_BasicServiceCode;

typedef unsigned short  IMAP2_NoReplyConditionTime;

typedef unsigned short  IMAP2_MC_Bearers;

typedef struct IMAP2_RegisterSSArg {
    unsigned char   bit_mask;
#       define      IMAP2_RegisterSSArg_basicService_present 0x80
#       define      IMAP2_RegisterSSArg_forwardedToNumber_present 0x40
#       define      IMAP2_RegisterSSArg_forwardedToSubaddress_present 0x20
#       define      IMAP2_RegisterSSArg_noReplyConditionTime_present 0x10
#       define      IMAP2_RegisterSSArg_defaultPriority_present 0x08
#       define      IMAP2_RegisterSSArg_nbrUser_present 0x04
#       define      IMAP2_RegisterSSArg_longFTN_Supported_present 0x02
    IMAP2_SS_Code   ss_Code;
    IMAP2_BasicServiceCode basicService;  /* optional; set in bit_mask
                                  * IMAP2_RegisterSSArg_basicService_present if
                                  * present */
    IMAP2_AddressString forwardedToNumber;  /* optional; set in bit_mask
                             * IMAP2_RegisterSSArg_forwardedToNumber_present if
                             * present */
    IMAP2_ISDN_SubaddressString forwardedToSubaddress;  /* optional; set in
                                   * bit_mask
                         * IMAP2_RegisterSSArg_forwardedToSubaddress_present if
                         * present */
   // OA1 forwardedToSubaddress must be absent in version 1
    IMAP2_NoReplyConditionTime noReplyConditionTime;  /* optional; set in
                                   * bit_mask
                          * IMAP2_RegisterSSArg_noReplyConditionTime_present if
                          * present */
    IMAP2_EMLPP_Priority defaultPriority;  /* extension #1; optional; set in
                                   * bit_mask
                                   * IMAP2_RegisterSSArg_defaultPriority_present
                                   * if present */
    IMAP2_MC_Bearers nbrUser;  /* extension #2; optional; set in bit_mask
                                * IMAP2_RegisterSSArg_nbrUser_present if
                                * present */
    Nulltype        longFTN_Supported;  /* extension #3; optional; set in
                                   * bit_mask
                             * IMAP2_RegisterSSArg_longFTN_Supported_present if
                             * present */
} IMAP2_RegisterSSArg;

typedef struct IMAP2_SS_DataTypes_CUG_Info {
    unsigned char   bit_mask;
#       define      IMAP2_SS_DataTypes_CUG_Info_cug_FeatureList_present 0x80
    struct IMAP2_SS_DataTypes_CUG_SubscriptionList_ *cug_SubscriptionList;
    struct IMAP2_SS_DataTypes_CUG_FeatureList_ *cug_FeatureList;  /* optional;
                                   * set in bit_mask
                       * IMAP2_SS_DataTypes_CUG_Info_cug_FeatureList_present if
                       * present */
} IMAP2_SS_DataTypes_CUG_Info;

typedef unsigned short  IMAP2_SS_DataTypes_CUG_Index;

   // The internal structure is defined in ETS 300 138.
typedef struct IMAP2_SS_DataTypes_CUG_Interlock {
    unsigned short  length;
    unsigned char   value[4];
} IMAP2_SS_DataTypes_CUG_Interlock;

typedef enum IMAP2_SS_DataTypes_IntraCUG_Options {
    IMAP2_SS_DataTypes_IntraCUG_Options_noCUG_Restrictions = 0,
    IMAP2_SS_DataTypes_IntraCUG_Options_cugIC_CallBarred = 1,
    IMAP2_SS_DataTypes_IntraCUG_Options_cugOG_CallBarred = 2
} IMAP2_SS_DataTypes_IntraCUG_Options;

typedef struct IMAP2_SS_DataTypes_CUG_Subscription {
    unsigned char   bit_mask;
#       define      IMAP2_SS_DataTypes_CUG_Subscription_basicServiceGroupList_present 0x80
    IMAP2_SS_DataTypes_CUG_Index cug_Index;
    IMAP2_SS_DataTypes_CUG_Interlock cug_Interlock;
    IMAP2_SS_DataTypes_IntraCUG_Options intraCUG_Options;
    struct IMAP2_BasicServiceGroupList_ *basicServiceGroupList;  /* optional;
                                   * set in bit_mask
         * IMAP2_SS_DataTypes_CUG_Subscription_basicServiceGroupList_present if
         * present */
} IMAP2_SS_DataTypes_CUG_Subscription;

typedef struct IMAP2_SS_DataTypes_CUG_SubscriptionList_ {
    struct IMAP2_SS_DataTypes_CUG_SubscriptionList_ *next;
    IMAP2_SS_DataTypes_CUG_Subscription value;
} *IMAP2_SS_DataTypes_CUG_SubscriptionList;

typedef struct IMAP2_SS_DataTypes_InterCUG_Restrictions {
    unsigned short  length;
    unsigned char   value[1];
} IMAP2_SS_DataTypes_InterCUG_Restrictions;

typedef struct IMAP2_SS_DataTypes_CUG_Feature {
    unsigned char   bit_mask;
#       define      IMAP2_SS_DataTypes_CUG_Feature_basicService_present 0x80
#       define      IMAP2_SS_DataTypes_CUG_Feature_preferentialCUG_Indicator_present 0x40
    IMAP2_BasicServiceCode basicService;  /* optional; set in bit_mask
                       * IMAP2_SS_DataTypes_CUG_Feature_basicService_present if
                       * present */
    IMAP2_SS_DataTypes_CUG_Index preferentialCUG_Indicator;  /* optional; set in
                                   * bit_mask
          * IMAP2_SS_DataTypes_CUG_Feature_preferentialCUG_Indicator_present if
          * present */
    IMAP2_SS_DataTypes_InterCUG_Restrictions interCUG_Restrictions;
} IMAP2_SS_DataTypes_CUG_Feature;

typedef struct IMAP2_SS_DataTypes_CUG_FeatureList_ {
    struct IMAP2_SS_DataTypes_CUG_FeatureList_ *next;
    IMAP2_SS_DataTypes_CUG_Feature value;
} *IMAP2_SS_DataTypes_CUG_FeatureList;

typedef struct IMAP2_ForwardingInfo {
    unsigned char   bit_mask;
#       define      IMAP2_ForwardingInfo_ss_Code_present 0x80
    IMAP2_SS_Code   ss_Code;  /* optional; set in bit_mask
                               * IMAP2_ForwardingInfo_ss_Code_present if
                               * present */
    struct IMAP2_ForwardingFeatureList_ *forwardingFeatureList;
} IMAP2_ForwardingInfo;

	// bit 8: notification to forwarding party
	//	0  no notification
	//	1  notification

	// bit 7: 0 (unused)

	// bit 6: notification to calling party
	//	0  no notification
	//	1  notification

	// bit 5: 0 (unused)

	// bits 43: forwarding reason
	//	00  ms not reachable
	//	01  ms busy
	//	10  no reply
	//	11  unconditional
	// bits 21: 00 (unused)
typedef struct IMAP2_CallBarringInfo {
    unsigned char   bit_mask;
#       define      IMAP2_CallBarringInfo_ss_Code_present 0x80
    IMAP2_SS_Code   ss_Code;  /* optional; set in bit_mask
                               * IMAP2_CallBarringInfo_ss_Code_present if
                               * present */
    struct IMAP2_CallBarringFeatureList_ *callBarringFeatureList;
} IMAP2_CallBarringInfo;

typedef struct IMAP2_SS_Status {
    unsigned short  length;
    unsigned char   value[1];
} IMAP2_SS_Status;

typedef enum IMAP2_CliRestrictionOption {
    IMAP2_permanent = 0,
    IMAP2_temporaryDefaultRestricted = 1,
    IMAP2_temporaryDefaultAllowed = 2
} IMAP2_CliRestrictionOption;

typedef enum IMAP2_OverrideCategory {
    IMAP2_overrideEnabled = 0,
    IMAP2_overrideDisabled = 1
} IMAP2_OverrideCategory;

typedef struct IMAP2_SS_SubscriptionOption {
    unsigned short  choice;
#       define      IMAP2_cliRestrictionOption_chosen 1
#       define      IMAP2_overrideCategory_chosen 2
    union _union {
        IMAP2_CliRestrictionOption cliRestrictionOption;  /* to choose, set
                                   * choice to
                                   * IMAP2_cliRestrictionOption_chosen */
        IMAP2_OverrideCategory overrideCategory;  /* to choose, set choice to
                                             * IMAP2_overrideCategory_chosen */
    } u;
} IMAP2_SS_SubscriptionOption;

typedef unsigned short  IMAP2_CCBS_Index;

typedef struct IMAP2_CCBS_Feature {
    unsigned char   bit_mask;
#       define      IMAP2_ccbs_Index_present 0x80
#       define      IMAP2_b_subscriberNumber_present 0x40
#       define      IMAP2_b_subscriberSubaddress_present 0x20
#       define      IMAP2_basicServiceGroup_present 0x10
    IMAP2_CCBS_Index ccbs_Index;  /* optional; set in bit_mask
                                   * IMAP2_ccbs_Index_present if present */
    IMAP2_ISDN_AddressString b_subscriberNumber;  /* optional; set in bit_mask
                                          * IMAP2_b_subscriberNumber_present if
                                          * present */
    IMAP2_ISDN_SubaddressString b_subscriberSubaddress;  /* optional; set in
                                   * bit_mask
                                   * IMAP2_b_subscriberSubaddress_present if
                                   * present */
    IMAP2_BasicServiceCode basicServiceGroup;  /* optional; set in bit_mask
                                           * IMAP2_basicServiceGroup_present if
                                           * present */
} IMAP2_CCBS_Feature;

typedef struct IMAP2_SS_Data {
    unsigned char   bit_mask;
#       define      IMAP2_SS_Data_ss_Code_present 0x80
#       define      IMAP2_SS_Data_ss_Status_present 0x40
#       define      IMAP2_SS_Data_ss_SubscriptionOption_present 0x20
#       define      IMAP2_SS_Data_basicServiceGroupList_present 0x10
#       define      IMAP2_SS_Data_defaultPriority_present 0x08
#       define      IMAP2_ccbs_Feature_present 0x04
#       define      IMAP2_SS_Data_nbrUser_present 0x02
    IMAP2_SS_Code   ss_Code;  /* optional; set in bit_mask
                               * IMAP2_SS_Data_ss_Code_present if present */
    IMAP2_SS_Status ss_Status;  /* optional; set in bit_mask
                                 * IMAP2_SS_Data_ss_Status_present if present */
    IMAP2_SS_SubscriptionOption ss_SubscriptionOption;  /* optional; set in
                                   * bit_mask
                                   * IMAP2_SS_Data_ss_SubscriptionOption_present
                                   * if present */
    struct IMAP2_BasicServiceGroupList_ *basicServiceGroupList;  /* optional;
                                   * set in bit_mask
                                   * IMAP2_SS_Data_basicServiceGroupList_present
                                   * if present */
    IMAP2_EMLPP_Priority defaultPriority;  /* extension #1; optional; set in
                                   * bit_mask
                                   * IMAP2_SS_Data_defaultPriority_present if
                                   * present */
    IMAP2_CCBS_Feature ccbs_Feature;  /* extension #2; optional; set in bit_mask
                                       * IMAP2_ccbs_Feature_present if
                                       * present */
    IMAP2_MC_Bearers nbrUser;  /* extension #3; optional; set in bit_mask
                                * IMAP2_SS_Data_nbrUser_present if present */
} IMAP2_SS_Data;

   // bits 876543: 000000 (unused)

   // bits 21
   // 00  CUG only facilities
   // 01  CUG with outgoing access
   // 10  CUG with incoming access
   // 11  CUG with both outgoing and incoming access
typedef struct IMAP2_SS_Info {
    unsigned short  choice;
#       define      IMAP2_SS_Info_forwardingInfo_chosen 1
#       define      IMAP2_SS_Info_callBarringInfo_chosen 2
#       define      IMAP2_SS_Info_cug_Info_chosen 3
#       define      IMAP2_SS_Info_ss_Data_chosen 4
    union _union {
        IMAP2_ForwardingInfo forwardingInfo;  /* to choose, set choice to
                                       * IMAP2_SS_Info_forwardingInfo_chosen */
        IMAP2_CallBarringInfo callBarringInfo;  /* to choose, set choice to
                                      * IMAP2_SS_Info_callBarringInfo_chosen */
        IMAP2_SS_DataTypes_CUG_Info cug_Info;  /* to choose, set choice to
                                             * IMAP2_SS_Info_cug_Info_chosen */
   // NU1 cug-info must not be used in version 1
        IMAP2_SS_Data   ss_Data;  /* to choose, set choice to
                                   * IMAP2_SS_Info_ss_Data_chosen */
    } u;
} IMAP2_SS_Info;

typedef IMAP2_SS_Info   IMAP2_DeactivateSSRes;

typedef IMAP2_SS_Info   IMAP2_ActivateSSRes;

typedef IMAP2_SS_Info   IMAP2_EraseSSRes;

typedef IMAP2_SS_Info   IMAP2_RegisterSSRes;

typedef struct IMAP2_FTN_AddressString {
    unsigned short  length;
    unsigned char   value[15];
} IMAP2_FTN_AddressString;

typedef struct IMAP2_ForwardingFeature {
    unsigned char   bit_mask;
#       define      IMAP2_ForwardingFeature_basicService_present 0x80
#       define      IMAP2_ForwardingFeature_ss_Status_present 0x40
#       define      IMAP2_ForwardingFeature_forwardedToNumber_present 0x20
#       define      IMAP2_ForwardingFeature_forwardedToSubaddress_present 0x10
#       define      IMAP2_ForwardingFeature_forwardingOptions_present 0x08
#       define      IMAP2_ForwardingFeature_noReplyConditionTime_present 0x04
#       define      IMAP2_longForwardedToNumber_present 0x02
    IMAP2_BasicServiceCode basicService;  /* optional; set in bit_mask
                              * IMAP2_ForwardingFeature_basicService_present if
                              * present */
    IMAP2_SS_Status ss_Status;  /* optional; set in bit_mask
                                 * IMAP2_ForwardingFeature_ss_Status_present if
                                 * present */
    IMAP2_ISDN_AddressString forwardedToNumber;  /* optional; set in bit_mask
                         * IMAP2_ForwardingFeature_forwardedToNumber_present if
                         * present */
    IMAP2_ISDN_SubaddressString forwardedToSubaddress;  /* optional; set in
                                   * bit_mask
                     * IMAP2_ForwardingFeature_forwardedToSubaddress_present if
                     * present */
    IMAP2_ForwardingOptions forwardingOptions;  /* optional; set in bit_mask
                         * IMAP2_ForwardingFeature_forwardingOptions_present if
                         * present */
    IMAP2_NoReplyConditionTime noReplyConditionTime;  /* optional; set in
                                   * bit_mask
                      * IMAP2_ForwardingFeature_noReplyConditionTime_present if
                      * present */
    IMAP2_FTN_AddressString longForwardedToNumber;  /* extension #1; optional;
                                   * set in bit_mask
                                   * IMAP2_longForwardedToNumber_present if
                                   * present */
} IMAP2_ForwardingFeature;

typedef struct IMAP2_ForwardingFeatureList_ {
    struct IMAP2_ForwardingFeatureList_ *next;
    IMAP2_ForwardingFeature value;
} *IMAP2_ForwardingFeatureList;

typedef struct IMAP2_CallBarringFeature {
    unsigned char   bit_mask;
#       define      IMAP2_CallBarringFeature_basicService_present 0x80
#       define      IMAP2_CallBarringFeature_ss_Status_present 0x40
    IMAP2_BasicServiceCode basicService;  /* optional; set in bit_mask
                             * IMAP2_CallBarringFeature_basicService_present if
                             * present */
    IMAP2_SS_Status ss_Status;  /* optional; set in bit_mask
                                 * IMAP2_CallBarringFeature_ss_Status_present if
                                 * present */
} IMAP2_CallBarringFeature;

typedef struct IMAP2_CallBarringFeatureList_ {
    struct IMAP2_CallBarringFeatureList_ *next;
    IMAP2_CallBarringFeature value;
} *IMAP2_CallBarringFeatureList;

typedef struct IMAP2_SS_ForBS_Code {
    unsigned char   bit_mask;
#       define      IMAP2_SS_ForBS_Code_basicService_present 0x80
    IMAP2_SS_Code   ss_Code;
    IMAP2_BasicServiceCode basicService;  /* optional; set in bit_mask
                                  * IMAP2_SS_ForBS_Code_basicService_present if
                                  * present */
} IMAP2_SS_ForBS_Code;

typedef struct IMAP2_InterrogateSSArg {
    unsigned char   bit_mask;
#       define      IMAP2_InterrogateSSArg_basicService_present 0x80
#       define      IMAP2_InterrogateSSArg_longFTN_Supported_present 0x40
    IMAP2_SS_Code   ss_Code;
    IMAP2_BasicServiceCode basicService;  /* optional; set in bit_mask
                               * IMAP2_InterrogateSSArg_basicService_present if
                               * present */
    Nulltype        longFTN_Supported;  /* extension #1; optional; set in
                                   * bit_mask
                          * IMAP2_InterrogateSSArg_longFTN_Supported_present if
                          * present */
} IMAP2_InterrogateSSArg; // added longFTN-Supported on 28-jan-2015

typedef struct IMAP2_DeactivateSSArg {
    unsigned char   bit_mask;
#       define      IMAP2_DeactivateSSArg_basicService_present 0x80
#       define      IMAP2_DeactivateSSArg_longFTN_Supported_present 0x40
    IMAP2_SS_Code   ss_Code;
    IMAP2_BasicServiceCode basicService;  /* optional; set in bit_mask
                                * IMAP2_DeactivateSSArg_basicService_present if
                                * present */
    Nulltype        longFTN_Supported;  /* extension #1; optional; set in
                                   * bit_mask
                           * IMAP2_DeactivateSSArg_longFTN_Supported_present if
                           * present */
} IMAP2_DeactivateSSArg; // added longFTN-Supported on 28-jan-2015

typedef struct IMAP2_ActivateSSArg {
    unsigned char   bit_mask;
#       define      IMAP2_ActivateSSArg_basicService_present 0x80
#       define      IMAP2_ActivateSSArg_longFTN_Supported_present 0x40
    IMAP2_SS_Code   ss_Code;
    IMAP2_BasicServiceCode basicService;  /* optional; set in bit_mask
                                  * IMAP2_ActivateSSArg_basicService_present if
                                  * present */
    Nulltype        longFTN_Supported;  /* extension #1; optional; set in
                                   * bit_mask
                             * IMAP2_ActivateSSArg_longFTN_Supported_present if
                             * present */
} IMAP2_ActivateSSArg; // added longFTN-Supported on 28-jan-2015

typedef struct IMAP2_EraseSSArg {
    unsigned char   bit_mask;
#       define      IMAP2_EraseSSArg_basicService_present 0x80
#       define      IMAP2_EraseSSArg_longFTN_Supported_present 0x40
    IMAP2_SS_Code   ss_Code;
    IMAP2_BasicServiceCode basicService;  /* optional; set in bit_mask
                                     * IMAP2_EraseSSArg_basicService_present if
                                     * present */
    Nulltype        longFTN_Supported;  /* extension #1; optional; set in
                                   * bit_mask
                                   * IMAP2_EraseSSArg_longFTN_Supported_present
                                   * if present */
} IMAP2_EraseSSArg; // added longFTN-Supported on 28-jan-2015

	// The mapping from the values A,B,0,1,2,3,4 to the integer-value is
	// specified as follows where A is the highest and 4 is the lowest
	// priority level
	// the integer values 7-15 are spare and shall be mapped to value 4
typedef unsigned short  IMAP2_MaxMC_Bearers;

typedef struct IMAP2_GenericServiceInfo {
    unsigned char   bit_mask;
#       define      IMAP2_cliRestrictionOption_present 0x80
#       define      IMAP2_maximumEntitledPriority_present 0x40
#       define      IMAP2_GenericServiceInfo_defaultPriority_present 0x20
#       define      IMAP2_ccbs_FeatureList_present 0x10
#       define      IMAP2_nbrSB_present 0x08
#       define      IMAP2_GenericServiceInfo_nbrUser_present 0x04
#       define      IMAP2_nbrSN_present 0x02
    IMAP2_SS_Status ss_Status;
    IMAP2_CliRestrictionOption cliRestrictionOption;  /* optional; set in
                                   * bit_mask IMAP2_cliRestrictionOption_present
                                   * if present */
    IMAP2_EMLPP_Priority maximumEntitledPriority;  /* extension #1; optional;
                                   * set in bit_mask
                                   * IMAP2_maximumEntitledPriority_present if
                                   * present */
    IMAP2_EMLPP_Priority defaultPriority;  /* extension #2; optional; set in
                                   * bit_mask
                          * IMAP2_GenericServiceInfo_defaultPriority_present if
                          * present */
    struct IMAP2_CCBS_FeatureList_ *ccbs_FeatureList;  /* extension #3;
                                   * optional; set in bit_mask
                                   * IMAP2_ccbs_FeatureList_present if
                                   * present */
    IMAP2_MaxMC_Bearers nbrSB;  /* extension #4; optional; set in bit_mask
                                 * IMAP2_nbrSB_present if present */
    IMAP2_MC_Bearers nbrUser;  /* extension #5; optional; set in bit_mask
                                * IMAP2_GenericServiceInfo_nbrUser_present if
                                * present */
    IMAP2_MC_Bearers nbrSN;  /* extension #6; optional; set in bit_mask
                              * IMAP2_nbrSN_present if present */
} IMAP2_GenericServiceInfo;

typedef struct IMAP2_CCBS_FeatureList_ {
    struct IMAP2_CCBS_FeatureList_ *next;
    IMAP2_CCBS_Feature value;
} *IMAP2_CCBS_FeatureList;

typedef struct IMAP2_InterrogateSSRes {
    unsigned short  choice;
#       define      IMAP2_ss_Status_chosen 1
#       define      IMAP2_basicServiceGroupList_chosen 2
#       define      IMAP2_forwardingFeatureList_chosen 3
#       define      IMAP2_genericServiceInfo_chosen 4
    union _union {
        IMAP2_SS_Status ss_Status;  /* to choose, set choice to
                                     * IMAP2_ss_Status_chosen */
        struct IMAP2_BasicServiceGroupList_ *basicServiceGroupList;  /* to
                                   * choose, set choice to
                                   * IMAP2_basicServiceGroupList_chosen */
        struct IMAP2_ForwardingFeatureList_ *forwardingFeatureList;  /* to
                                   * choose, set choice to
                                   * IMAP2_forwardingFeatureList_chosen */
        IMAP2_GenericServiceInfo genericServiceInfo;  /* to choose, set choice
                                        * to IMAP2_genericServiceInfo_chosen */
    } u;
} IMAP2_InterrogateSSRes;

typedef struct IMAP2_USSD_DataCodingScheme {
    unsigned short  length;
    unsigned char   value[1];
} IMAP2_USSD_DataCodingScheme;

	// The structure of the USSD-DataCodingScheme is defined by
	// the Cell Broadcast Data Coding Scheme as described in
	// TS GSM 03.38
typedef struct IMAP2_USSD_String {
    unsigned short  length;
    unsigned char   value[160];
} IMAP2_USSD_String;

typedef struct IMAP2_AlertingPattern {
    unsigned short  length;
    unsigned char   value[1];
} IMAP2_AlertingPattern;

typedef struct IMAP2_USSD_Arg {
    unsigned char   bit_mask;
#       define      IMAP2_USSD_Arg_alertingPattern_present 0x80
    IMAP2_USSD_DataCodingScheme ussd_DataCodingScheme;
    IMAP2_USSD_String ussd_String;
    IMAP2_AlertingPattern alertingPattern;  /* extension #1; optional; set in
                                   * bit_mask
                                   * IMAP2_USSD_Arg_alertingPattern_present if
                                   * present */
} IMAP2_USSD_Arg;

typedef struct IMAP2_UnstructuredSS_NotifyArg {
    unsigned char   bit_mask;
#       define      IMAP2_UnstructuredSS_NotifyArg_alertingPattern_present 0x80
#       define      IMAP2_UnstructuredSS_NotifyArg_msisdn_present 0x40
    IMAP2_USSD_DataCodingScheme ussd_DataCodingScheme;
    IMAP2_USSD_String ussd_String;
    IMAP2_AlertingPattern alertingPattern;  /* extension #1; optional; set in
                                   * bit_mask
                    * IMAP2_UnstructuredSS_NotifyArg_alertingPattern_present if
                    * present */
    IMAP2_ISDN_AddressString msisdn;  /* extension #2; optional; set in bit_mask
                             * IMAP2_UnstructuredSS_NotifyArg_msisdn_present if
                             * present */
} IMAP2_UnstructuredSS_NotifyArg; // added msisdn for an issue on 28-jan-2015

typedef struct IMAP2_UnstructuredSS_RequestArg {
    unsigned char   bit_mask;
#       define      IMAP2_UnstructuredSS_RequestArg_alertingPattern_present 0x80
#       define      IMAP2_UnstructuredSS_RequestArg_msisdn_present 0x40
    IMAP2_USSD_DataCodingScheme ussd_DataCodingScheme;
    IMAP2_USSD_String ussd_String;
    IMAP2_AlertingPattern alertingPattern;  /* extension #1; optional; set in
                                   * bit_mask
                   * IMAP2_UnstructuredSS_RequestArg_alertingPattern_present if
                   * present */
    IMAP2_ISDN_AddressString msisdn;  /* extension #2; optional; set in bit_mask
                            * IMAP2_UnstructuredSS_RequestArg_msisdn_present if
                            * present */
} IMAP2_UnstructuredSS_RequestArg; // added msisdn for an issue on 28-jan-2015

typedef struct IMAP2_ProcessUnstructuredSS_RequestArg {
    unsigned char   bit_mask;
#       define      IMAP2_ProcessUnstructuredSS_RequestArg_alertingPattern_present 0x80
#       define      IMAP2_ProcessUnstructuredSS_RequestArg_msisdn_present 0x40
    IMAP2_USSD_DataCodingScheme ussd_DataCodingScheme;
    IMAP2_USSD_String ussd_String;
    IMAP2_AlertingPattern alertingPattern;  /* extension #1; optional; set in
                                   * bit_mask
            * IMAP2_ProcessUnstructuredSS_RequestArg_alertingPattern_present if
            * present */
    IMAP2_ISDN_AddressString msisdn;  /* extension #2; optional; set in bit_mask
                     * IMAP2_ProcessUnstructuredSS_RequestArg_msisdn_present if
                     * present */
} IMAP2_ProcessUnstructuredSS_RequestArg; // added msisdn for an issue on 23-jan-2015

typedef struct IMAP2_USSD_Res {
    IMAP2_USSD_DataCodingScheme ussd_DataCodingScheme;
    IMAP2_USSD_String ussd_String;
} IMAP2_USSD_Res;

typedef struct IMAP2_UnstructuredSS_RequestRes {
    IMAP2_USSD_DataCodingScheme ussd_DataCodingScheme;
    IMAP2_USSD_String ussd_String;
} IMAP2_UnstructuredSS_RequestRes;

typedef struct IMAP2_ProcessUnstructuredSS_RequestRes {
    IMAP2_USSD_DataCodingScheme ussd_DataCodingScheme;
    IMAP2_USSD_String ussd_String;
} IMAP2_ProcessUnstructuredSS_RequestRes;

typedef struct IMAP2_SS_List_ {
    struct IMAP2_SS_List_ *next;
    IMAP2_SS_Code   value;
} *IMAP2_SS_List;

typedef struct IMAP2_SS_InfoList_ {
    struct IMAP2_SS_InfoList_ *next;
    IMAP2_SS_Info   value;
} *IMAP2_SS_InfoList;

typedef struct IMAP2_BasicServiceGroupList_ {
    struct IMAP2_BasicServiceGroupList_ *next;
    IMAP2_BasicServiceCode value;
} *IMAP2_BasicServiceGroupList;

typedef struct IMAP2_SS_EventSpecification_ {
    struct IMAP2_SS_EventSpecification_ *next;
    IMAP2_AddressString value;
} *IMAP2_SS_EventSpecification;

typedef struct IMAP2_ServiceIndicator {
    unsigned short  length;  /* number of significant bits */
    unsigned char   value[4];
} IMAP2_ServiceIndicator;
// exception handling:
// bits 2 to 31 shall be ignored if received and not understood
#define                     IMAP2_clir_invoked 0x80
#define                     IMAP2_clir_invoked_byte 0
#define                     IMAP2_camel_invoked 0x40
#define                     IMAP2_camel_invoked_byte 0

typedef struct IMAP2_CCBS_Data {
    unsigned char   bit_mask;
#       define      IMAP2_serviceIndicator_present 0x80
    IMAP2_CCBS_Feature ccbs_Feature;
    IMAP2_ISDN_AddressString translatedB_Number;
    IMAP2_ServiceIndicator serviceIndicator;  /* optional; set in bit_mask
                                               * IMAP2_serviceIndicator_present
                                               * if present */
    IMAP2_ExternalSignalInfo callInfo;
    IMAP2_ExternalSignalInfo networkSignalInfo;
} IMAP2_CCBS_Data;

	// digits of VGCS/VBC-area,Group-ID are concatenated in this order.
typedef struct IMAP2_TMSI {
    unsigned short  length;
    unsigned char   value[4];
} IMAP2_TMSI;

typedef struct IMAP2_SubscriberId {
    unsigned short  choice;
#       define      IMAP2_SubscriberId_imsi_chosen 1
#       define      IMAP2_tmsi_chosen 2
    union _union {
        IMAP2_IMSI      imsi;  /* to choose, set choice to
                                * IMAP2_SubscriberId_imsi_chosen */
        IMAP2_TMSI      tmsi;  /* to choose, set choice to IMAP2_tmsi_chosen */
    } u;
} IMAP2_SubscriberId;

typedef struct IMAP2_IMEI {
    unsigned short  length;
    unsigned char   value[8];
} IMAP2_IMEI;

	//	Refers to International Mobile Station Equipment Identity
	//	and Software Version Number (SVN) defined in TS GSM 03.03.
	//	If the SVN is not present the last octet shall contain the
	//	digit 0 and a filler.
	//	If present the SVN shall be included in the last octet.
typedef IMAP2_IMSI      IMAP2_HLR_Id;

	// leading digits of IMSI, i.e. (MCC, MNC, leading digits of
	// MSIN) forming HLR Id defined in TS GSM 03.03.
typedef struct IMAP2_HLR_List_ {
    struct IMAP2_HLR_List_ *next;
    IMAP2_HLR_Id    value;
} *IMAP2_HLR_List;

typedef struct IMAP2_GlobalCellId {
    unsigned short  length;
    unsigned char   value[7];
} IMAP2_GlobalCellId;

	// Refers to Cell Global Identification defined in TS GSM 03.03.
	// Octets are coded according to TS GSM 04.08.
	// The internal structure is defined as follows:
	//	Mobile Country Code:	3 digits according to CCITT Rec E.212
	//			1 digit filler (1111)
	//	Mobile Network Code:	2 digits according to CCITT Rec E.212
	//	Location Area Code:	2 octets according to TS GSM 04.08
	//	Cell Identity:	2 octets (CI) according to TS GSM 04.08
typedef enum IMAP2_NetworkResource {
    IMAP2_plmn = 0,
    IMAP2_hlr = 1,
    IMAP2_vlr = 2,
    IMAP2_pvlr = 3,
    IMAP2_controllingMSC = 4,
    IMAP2_vmsc = 5,
    IMAP2_eir = 6,
    IMAP2_rss = 7
} IMAP2_NetworkResource;

typedef struct IMAP2_NAEA_CIC {
    unsigned short  length;
    unsigned char   value[3];
} IMAP2_NAEA_CIC;

typedef struct IMAP2_NAEA_PreferredCI {
    unsigned char   bit_mask;
#       define      IMAP2_NAEA_PreferredCI_extensionContainer_present 0x80
    IMAP2_NAEA_CIC  naea_PreferredCIC;
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                         * IMAP2_NAEA_PreferredCI_extensionContainer_present if
                         * present */
} IMAP2_NAEA_PreferredCI;

typedef struct IMAP2_Ext_BasicServiceCode {
    unsigned short  choice;
#       define      IMAP2_ext_BearerService_chosen 1
#       define      IMAP2_ext_Teleservice_chosen 2
    union _union {
        IMAP2_Ext_BearerServiceCode ext_BearerService;  /* to choose, set choice
                                         * to IMAP2_ext_BearerService_chosen */
        IMAP2_Ext_TeleserviceCode ext_Teleservice;  /* to choose, set choice to
                                              * IMAP2_ext_Teleservice_chosen */
    } u;
} IMAP2_Ext_BasicServiceCode;

typedef struct IMAP2_EMLPP_Info {
    unsigned char   bit_mask;
#       define      IMAP2_EMLPP_Info_extensionContainer_present 0x80
    IMAP2_EMLPP_Priority maximumentitledPriority;
    IMAP2_EMLPP_Priority defaultPriority;
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                               * IMAP2_EMLPP_Info_extensionContainer_present if
                               * present */
} IMAP2_EMLPP_Info;

	// location registration types
	// handover types
	// authentication management types
	// security management types
	// subscriber management types
	// fault recovery types
	// subscriber information enquiry types
typedef struct IMAP2_UpdateLocationArg {
    unsigned char   bit_mask;
#       define      IMAP2_UpdateLocationArg_lmsi_present 0x80
#       define      IMAP2_UpdateLocationArg_extensionContainer_present 0x40
    IMAP2_IMSI      imsi;
    IMAP2_ISDN_AddressString msc_Number;
    IMAP2_ISDN_AddressString vlr_Number;
    IMAP2_LMSI      lmsi;  /* optional; set in bit_mask
                            * IMAP2_UpdateLocationArg_lmsi_present if present */
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                        * IMAP2_UpdateLocationArg_extensionContainer_present if
                        * present */
} IMAP2_UpdateLocationArg;

//UpdateLocationRes ::= SEQUENCE {
//	hlr-Number	ISDN-AddressString,
//	extensionContainer	ExtensionContainer	OPTIONAL,
//	...}
typedef struct IMAP2_ExtensibleUpdateLocationRes {
    IMAP2_ISDN_AddressString hlr_Number;
} IMAP2_ExtensibleUpdateLocationRes;

typedef struct IMAP2_UpdateLocationRes {
    unsigned short  choice;
#       define      IMAP2_hlr_Number_chosen 1
#       define      IMAP2_extensibleUpdateLocationRes_chosen 2
    union _union {
        IMAP2_ISDN_AddressString hlr_Number;  /* to choose, set choice to
                                               * IMAP2_hlr_Number_chosen */
                                              // NU1 hlr-Number must not be used in version greater 1
        IMAP2_ExtensibleUpdateLocationRes extensibleUpdateLocationRes;  /* to
                                   * choose, set choice to
                                  * IMAP2_extensibleUpdateLocationRes_chosen */
                                                                        // NU1 extensibleUpdateLocationRes must not be used in version 1
    } u;
} IMAP2_UpdateLocationRes;

typedef struct IMAP2_IMSI_WithLMSI {
    IMAP2_IMSI      imsi;
    IMAP2_LMSI      lmsi;
	// a special value 00000000 indicates that the LMSI is not in use
} IMAP2_IMSI_WithLMSI;

typedef struct IMAP2_CancelLocationArg {
    unsigned short  choice;
#       define      IMAP2_CancelLocationArg_imsi_chosen 1
#       define      IMAP2_CancelLocationArg_imsi_WithLMSI_chosen 2
    union _union {
        IMAP2_IMSI      imsi;  /* to choose, set choice to
                                * IMAP2_CancelLocationArg_imsi_chosen */
        IMAP2_IMSI_WithLMSI imsi_WithLMSI;  /* to choose, set choice to
                              * IMAP2_CancelLocationArg_imsi_WithLMSI_chosen */
    } u;
} IMAP2_CancelLocationArg;

typedef struct IMAP2_Indentity {
    unsigned short  choice;
#       define      IMAP2_Indentity_imsi_chosen 1
#       define      IMAP2_Indentity_imsi_WithLMSI_chosen 2
    union _union {
        IMAP2_IMSI      imsi;  /* to choose, set choice to
                                * IMAP2_Indentity_imsi_chosen */
        IMAP2_IMSI_WithLMSI imsi_WithLMSI;  /* to choose, set choice to
                                      * IMAP2_Indentity_imsi_WithLMSI_chosen */
    } u;
} IMAP2_Indentity;

typedef struct IMAP2_CancelLocationRes {
    unsigned char   bit_mask;
#       define      IMAP2_CancelLocationRes_extensionContainer_present 0x80
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                        * IMAP2_CancelLocationRes_extensionContainer_present if
                        * present */
} IMAP2_CancelLocationRes;

//PurgeMS-Arg ::= [3] SEQUENCE {
typedef struct IMAP2_PurgeMS_Arg {
    IMAP2_IMSI      imsi;
    IMAP2_ISDN_AddressString vlr_Number;
} IMAP2_PurgeMS_Arg;

typedef struct IMAP2_PurgeMS_Res {
    unsigned char   bit_mask;
#       define      IMAP2_freezeTMSI_present 0x80
#       define      IMAP2_freezeP_TMSI_present 0x40
#       define      IMAP2_PurgeMS_Res_extensionContainer_present 0x20
    Nulltype        freezeTMSI;  /* optional; set in bit_mask
                                  * IMAP2_freezeTMSI_present if present */
    Nulltype        freezeP_TMSI;  /* optional; set in bit_mask
                                    * IMAP2_freezeP_TMSI_present if present */
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                              * IMAP2_PurgeMS_Res_extensionContainer_present if
                              * present */
} IMAP2_PurgeMS_Res;

typedef struct IMAP2_SendIdentificationRes {
    unsigned char   bit_mask;
#       define      IMAP2_authenticationSetList_present 0x80
    IMAP2_IMSI      imsi;
    struct IMAP2_AuthenticationSetList_ *authenticationSetList;  /* optional;
                                   * set in bit_mask
                                   * IMAP2_authenticationSetList_present if
                                   * present */
} IMAP2_SendIdentificationRes;

typedef struct IMAP2_RAND {
    unsigned short  length;
    unsigned char   value[16];
} IMAP2_RAND;

typedef struct IMAP2_SRES {
    unsigned short  length;
    unsigned char   value[4];
} IMAP2_SRES;

typedef struct IMAP2_AuthenticationSet {
    IMAP2_RAND      rand;
    IMAP2_SRES      sres;
    IMAP2_Kc        kc;
} IMAP2_AuthenticationSet;

typedef struct IMAP2_AuthenticationSetList_ {
    struct IMAP2_AuthenticationSetList_ *next;
    IMAP2_AuthenticationSet value;
} *IMAP2_AuthenticationSetList;

// handover types
typedef struct IMAP2_PrepareHO_Arg {
    unsigned char   bit_mask;
#       define      IMAP2_targetCellId_present 0x80
#       define      IMAP2_ho_NumberNotRequired_present 0x40
#       define      IMAP2_PrepareHO_Arg_bss_APDU_present 0x20
    IMAP2_GlobalCellId targetCellId;  /* optional; set in bit_mask
                                       * IMAP2_targetCellId_present if
                                       * present */
    Nulltype        ho_NumberNotRequired;  /* optional; set in bit_mask
                                            * IMAP2_ho_NumberNotRequired_present
                                            * if present */
    IMAP2_ExternalSignalInfo bss_APDU;  /* optional; set in bit_mask
                                         * IMAP2_PrepareHO_Arg_bss_APDU_present
                                         * if present */
} IMAP2_PrepareHO_Arg;

typedef struct IMAP2_PrepareHO_Res {
    unsigned char   bit_mask;
#       define      IMAP2_handoverNumber_present 0x80
#       define      IMAP2_PrepareHO_Res_bss_APDU_present 0x40
    IMAP2_ISDN_AddressString handoverNumber;  /* optional; set in bit_mask
                                               * IMAP2_handoverNumber_present if
                                               * present */
    IMAP2_ExternalSignalInfo bss_APDU;  /* optional; set in bit_mask
                                         * IMAP2_PrepareHO_Res_bss_APDU_present
                                         * if present */
} IMAP2_PrepareHO_Res;

typedef struct IMAP2_PrepareSubsequentHO_Arg {
    IMAP2_GlobalCellId targetCellId;
    IMAP2_ISDN_AddressString targetMSC_Number;
    IMAP2_ExternalSignalInfo bss_APDU;
} IMAP2_PrepareSubsequentHO_Arg;

// authentication management types
typedef IMAP2_IMSI      IMAP2_SendAuthenticationInfoArg;

typedef struct IMAP2_AuthenticationSetList_ *IMAP2_SendAuthenticationInfoRes;

typedef struct IMAP2_Category {
    unsigned short  length;
    unsigned char   value[1];
} IMAP2_Category;

	// The internal structure is defined in CCITT Rec Q.763.
typedef enum IMAP2_SubscriberStatus {
    IMAP2_serviceGranted = 0,
    IMAP2_SubscriberStatus_operatorDeterminedBarring = 1
} IMAP2_SubscriberStatus;

typedef struct IMAP2_ODB_GeneralData {
    unsigned short  length;  /* number of significant bits */
    unsigned char   value[1];
} IMAP2_ODB_GeneralData;
#define                     IMAP2_allOG_CallsBarred 0x80
#define                     IMAP2_allOG_CallsBarred_byte 0
#define                     IMAP2_internationalOGCallsBarred 0x40
#define                     IMAP2_internationalOGCallsBarred_byte 0
#define                     IMAP2_internationalOGCallsNotToHPLMN_CountryBarred 0x20
#define                     IMAP2_internationalOGCallsNotToHPLMN_CountryBarred_byte 0
#define                     IMAP2_premiumRateInformationOGCallsBarred 0x10
#define                     IMAP2_premiumRateInformationOGCallsBarred_byte 0
#define                     IMAP2_premiumRateEntertainementOGCallsBarred 0x08
#define                     IMAP2_premiumRateEntertainementOGCallsBarred_byte 0
#define                     IMAP2_ss_AccessBarred 0x04
#define                     IMAP2_ss_AccessBarred_byte 0

typedef struct IMAP2_ODB_HPLMN_Data {
    unsigned short  length;  /* number of significant bits */
    unsigned char   value[1];
} IMAP2_ODB_HPLMN_Data;
#define                     IMAP2_plmn_SpecificBarringType1 0x80
#define                     IMAP2_plmn_SpecificBarringType1_byte 0
#define                     IMAP2_plmn_SpecificBarringType2 0x40
#define                     IMAP2_plmn_SpecificBarringType2_byte 0
#define                     IMAP2_plmn_SpecificBarringType3 0x20
#define                     IMAP2_plmn_SpecificBarringType3_byte 0
#define                     IMAP2_plmn_SpecificBarringType4 0x10
#define                     IMAP2_plmn_SpecificBarringType4_byte 0

typedef struct IMAP2_ODB_Data {
    unsigned char   bit_mask;
#       define      IMAP2_odb_HPLMN_Data_present 0x80
#       define      IMAP2_ODB_Data_extensionContainer_present 0x40
    IMAP2_ODB_GeneralData odb_GeneralData;
    IMAP2_ODB_HPLMN_Data odb_HPLMN_Data;  /* optional; set in bit_mask
                                           * IMAP2_odb_HPLMN_Data_present if
                                           * present */
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                                 * IMAP2_ODB_Data_extensionContainer_present if
                                 * present */
} IMAP2_ODB_Data;

// subscriber management types
typedef struct IMAP2_InsertSubscriberDataArg {
    unsigned short  bit_mask;
#       define      IMAP2_InsertSubscriberDataArg_imsi_present 0x8000
#       define      IMAP2_InsertSubscriberDataArg_msisdn_present 0x4000
#       define      IMAP2_category_present 0x2000
#       define      IMAP2_subscriberStatus_present 0x1000
#       define      IMAP2_InsertSubscriberDataArg_bearerServiceList_present 0x0800
#       define      IMAP2_InsertSubscriberDataArg_teleserviceList_present 0x0400
#       define      IMAP2_provisionedSS_present 0x0200
#       define      IMAP2_odb_Data_present 0x0100
#       define      IMAP2_InsertSubscriberDataArg_roamingRestrictionDueToUnsupportedFeature_present 0x0080
#       define      IMAP2_regionalSubscriptionData_present 0x0040
    IMAP2_IMSI      imsi;  /* optional; set in bit_mask
                            * IMAP2_InsertSubscriberDataArg_imsi_present if
                            * present */
    IMAP2_ISDN_AddressString msisdn;  /* optional; set in bit_mask
                              * IMAP2_InsertSubscriberDataArg_msisdn_present if
                              * present */
    IMAP2_Category  category;  /* optional; set in bit_mask
                                * IMAP2_category_present if present */
    IMAP2_SubscriberStatus subscriberStatus;  /* optional; set in bit_mask
                                               * IMAP2_subscriberStatus_present
                                               * if present */
    struct IMAP2_BearerServiceList_ *bearerServiceList;  /* optional; set in
                                   * bit_mask
                   * IMAP2_InsertSubscriberDataArg_bearerServiceList_present if
                   * present */
	// The exception handling for reception of unsupported / not allocated
	// bearerServiceCodes is defined in section 6.8.1
    struct IMAP2_TeleserviceList_ *teleserviceList;  /* optional; set in
                                   * bit_mask
                     * IMAP2_InsertSubscriberDataArg_teleserviceList_present if
                     * present */
	// The exception handling for reception of unsupported / not allocated
	// teleserviceCodes is defined in section 6.8.1
    struct IMAP2_SS_InfoList_ *provisionedSS;  /* optional; set in bit_mask
                                                * IMAP2_provisionedSS_present if
                                                * present */
    IMAP2_ODB_Data  odb_Data;  /* optional; set in bit_mask
                                * IMAP2_odb_Data_present if present */
    Nulltype        roamingRestrictionDueToUnsupportedFeature;  /* optional; set
                                   * in bit_mask
       * IMAP2_InsertSubscriberDataArg_roamingRestrictionDueToUnsupportedFeature_present if
       * present */
    struct IMAP2_ZoneCodeList_ *regionalSubscriptionData;  /* optional; set in
                                   * bit_mask
                                   * IMAP2_regionalSubscriptionData_present if
                                   * present */
} IMAP2_InsertSubscriberDataArg;

typedef struct IMAP2_QoS_Subscribed {
    unsigned short  length;
    unsigned char   value[3];
} IMAP2_QoS_Subscribed;

typedef struct IMAP2_BearerServiceList_ {
    struct IMAP2_BearerServiceList_ *next;
    IMAP2_BearerServiceCode value;
} *IMAP2_BearerServiceList;

typedef struct IMAP2_TeleserviceList_ {
    struct IMAP2_TeleserviceList_ *next;
    IMAP2_TeleserviceCode value;
} *IMAP2_TeleserviceList;

typedef struct IMAP2_Ext_ForwInfo {
    unsigned char   bit_mask;
#       define      IMAP2_Ext_ForwInfo_extensionContainer_present 0x80
    IMAP2_SS_Code   ss_Code;
    struct IMAP2_Ext_ForwFeatureList_ *forwardingFeatureList;
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                             * IMAP2_Ext_ForwInfo_extensionContainer_present if
                             * present */
} IMAP2_Ext_ForwInfo;

	// Only values 5-30 are used.
	// Values in the ranges 1-4 and 31-100 are reserved for future use
	// If received:
	//		values 1-4 shall be mapped on to value 5
	//		values 31-100 shall be mapped on to value 30
typedef struct IMAP2_Ext_CallBarInfo {
    unsigned char   bit_mask;
#       define      IMAP2_Ext_CallBarInfo_extensionContainer_present 0x80
    IMAP2_SS_Code   ss_Code;
    struct IMAP2_Ext_CallBarFeatureList_ *callBarringFeatureList;
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                          * IMAP2_Ext_CallBarInfo_extensionContainer_present if
                          * present */
} IMAP2_Ext_CallBarInfo;

typedef struct IMAP2_MS_DataTypes_CUG_Info {
    unsigned char   bit_mask;
#       define      IMAP2_MS_DataTypes_CUG_Info_cug_FeatureList_present 0x80
#       define      IMAP2_CUG_Info_extensionContainer_present 0x40
    struct IMAP2_MS_DataTypes_CUG_SubscriptionList_ *cug_SubscriptionList;
    struct IMAP2_MS_DataTypes_CUG_FeatureList_ *cug_FeatureList;  /* optional;
                                   * set in bit_mask
                       * IMAP2_MS_DataTypes_CUG_Info_cug_FeatureList_present if
                       * present */
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                                 * IMAP2_CUG_Info_extensionContainer_present if
                                 * present */
} IMAP2_MS_DataTypes_CUG_Info;

typedef struct IMAP2_Ext_SS_Status {
    unsigned short  length;
    unsigned char   value[5];
} IMAP2_Ext_SS_Status;

	// bits 876543: 000000 (unused)
	// Exception handling:
	// bits 876543 shall be ignored if received and not understood

	// bits 21
	//	00  CUG only facilities
	//	01  CUG with outgoing access
	//	10  CUG with incoming access
	//	11  CUG with both outgoing and incoming access
typedef struct IMAP2_Ext_SS_Data {
    unsigned char   bit_mask;
#       define      IMAP2_Ext_SS_Data_ss_SubscriptionOption_present 0x80
#       define      IMAP2_Ext_SS_Data_basicServiceGroupList_present 0x40
#       define      IMAP2_Ext_SS_Data_extensionContainer_present 0x20
    IMAP2_SS_Code   ss_Code;
    IMAP2_Ext_SS_Status ss_Status;
    IMAP2_SS_SubscriptionOption ss_SubscriptionOption;  /* optional; set in
                                   * bit_mask
                           * IMAP2_Ext_SS_Data_ss_SubscriptionOption_present if
                           * present */
    struct IMAP2_Ext_BasicServiceGroupList_ *basicServiceGroupList;  
                                  /* optional; set in bit_mask
                           * IMAP2_Ext_SS_Data_basicServiceGroupList_present if
                           * present */
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                              * IMAP2_Ext_SS_Data_extensionContainer_present if
                              * present */
} IMAP2_Ext_SS_Data;

typedef struct IMAP2_Ext_SS_Info {
    unsigned short  choice;
#       define      IMAP2_Ext_SS_Info_forwardingInfo_chosen 1
#       define      IMAP2_Ext_SS_Info_callBarringInfo_chosen 2
#       define      IMAP2_Ext_SS_Info_cug_Info_chosen 3
#       define      IMAP2_Ext_SS_Info_ss_Data_chosen 4
#       define      IMAP2_emlpp_Info_chosen 5
    union _union {
        IMAP2_Ext_ForwInfo forwardingInfo;  /* to choose, set choice to
                                   * IMAP2_Ext_SS_Info_forwardingInfo_chosen */
        IMAP2_Ext_CallBarInfo callBarringInfo;  /* to choose, set choice to
                                  * IMAP2_Ext_SS_Info_callBarringInfo_chosen */
        IMAP2_MS_DataTypes_CUG_Info cug_Info;  /* to choose, set choice to
                                         * IMAP2_Ext_SS_Info_cug_Info_chosen */
        IMAP2_Ext_SS_Data ss_Data;  /* to choose, set choice to
                                     * IMAP2_Ext_SS_Info_ss_Data_chosen */
        IMAP2_EMLPP_Info emlpp_Info;  /* to choose, set choice to
                                       * IMAP2_emlpp_Info_chosen */
    } u;
} IMAP2_Ext_SS_Info;

typedef struct IMAP2_Ext_SS_InfoList_ {
    struct IMAP2_Ext_SS_InfoList_ *next;
    IMAP2_Ext_SS_Info value;
} *IMAP2_Ext_SS_InfoList;

	// OCTET 1:
	//
	// bits 8765: 0000 (unused)
	// bits 4321: Used to convey the "P bit","R bit","A bit" and "Q bit",
	//		    representing supplementary service state information
	//		    as defined in TS GSM 03.11

	// bit 4: "Q bit"

	// bit 3: "P bit"

	// bit 2: "R bit"

	// bit 1: "A bit"

	// OCTETS 2-5: reserved for future use. They shall be discarded if
	// received and not understood.
typedef struct IMAP2_Ext_ForwOptions {
    unsigned short  length;
    unsigned char   value[5];
} IMAP2_Ext_ForwOptions;

	// OCTET 1:

	//  bit 8: notification to forwarding party
	//	0  no notification
	//	1  notification

	//  bit 7: 0 (unused)

	//  bit 6: notification to calling party
	//	0  no notification
	//	1  notification

	//  bit 5: 0 (unused)

	//  bits 43: forwarding reason
	//	00  ms not reachable
	//	01  ms busy
	//	10  no reply
	//	11  unconditional

	// bits 21: 00 (unused)

	// OCTETS 2-5: reserved for future use. They shall be discarded if
	// received and not understood.
typedef unsigned short  IMAP2_Ext_NoRepCondTime;

typedef struct IMAP2_Ext_ForwFeature {
    unsigned char   bit_mask;
#       define      IMAP2_Ext_ForwFeature_basicService_present 0x80
#       define      IMAP2_Ext_ForwFeature_forwardedToNumber_present 0x40
#       define      IMAP2_Ext_ForwFeature_forwardedToSubaddress_present 0x20
#       define      IMAP2_Ext_ForwFeature_forwardingOptions_present 0x10
#       define      IMAP2_Ext_ForwFeature_noReplyConditionTime_present 0x08
#       define      IMAP2_Ext_ForwFeature_extensionContainer_present 0x04
    IMAP2_Ext_BasicServiceCode basicService;  /* optional; set in bit_mask
                                * IMAP2_Ext_ForwFeature_basicService_present if
                                * present */
    IMAP2_Ext_SS_Status ss_Status;
    IMAP2_ISDN_AddressString forwardedToNumber;  /* optional; set in bit_mask
                           * IMAP2_Ext_ForwFeature_forwardedToNumber_present if
                           * present */
    IMAP2_ISDN_SubaddressString forwardedToSubaddress;  /* optional; set in
                                   * bit_mask
                       * IMAP2_Ext_ForwFeature_forwardedToSubaddress_present if
                       * present */
    IMAP2_Ext_ForwOptions forwardingOptions;  /* optional; set in bit_mask
                           * IMAP2_Ext_ForwFeature_forwardingOptions_present if
                           * present */
    IMAP2_Ext_NoRepCondTime noReplyConditionTime;  /* optional; set in bit_mask
                        * IMAP2_Ext_ForwFeature_noReplyConditionTime_present if
                        * present */
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                          * IMAP2_Ext_ForwFeature_extensionContainer_present if
                          * present */
} IMAP2_Ext_ForwFeature;

typedef struct IMAP2_Ext_ForwFeatureList_ {
    struct IMAP2_Ext_ForwFeatureList_ *next;
    IMAP2_Ext_ForwFeature value;
} *IMAP2_Ext_ForwFeatureList;

typedef struct IMAP2_Ext_CallBarringFeature {
    unsigned char   bit_mask;
#       define      IMAP2_Ext_CallBarringFeature_basicService_present 0x80
#       define      IMAP2_Ext_CallBarringFeature_extensionContainer_present 0x40
    IMAP2_Ext_BasicServiceCode basicService;  /* optional; set in bit_mask
                         * IMAP2_Ext_CallBarringFeature_basicService_present if
                         * present */
    IMAP2_Ext_SS_Status ss_Status;
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                   * IMAP2_Ext_CallBarringFeature_extensionContainer_present if
                   * present */
} IMAP2_Ext_CallBarringFeature;

typedef struct IMAP2_Ext_CallBarFeatureList_ {
    struct IMAP2_Ext_CallBarFeatureList_ *next;
    IMAP2_Ext_CallBarringFeature value;
} *IMAP2_Ext_CallBarFeatureList;

typedef unsigned short  IMAP2_MS_DataTypes_CUG_Index;

typedef enum IMAP2_MS_DataTypes_IntraCUG_Options {
    IMAP2_MS_DataTypes_IntraCUG_Options_noCUG_Restrictions = 0,
    IMAP2_MS_DataTypes_IntraCUG_Options_cugIC_CallBarred = 1,
    IMAP2_MS_DataTypes_IntraCUG_Options_cugOG_CallBarred = 2
} IMAP2_MS_DataTypes_IntraCUG_Options;

typedef struct IMAP2_MS_DataTypes_CUG_Subscription {
    unsigned char   bit_mask;
#       define      IMAP2_MS_DataTypes_CUG_Subscription_basicServiceGroupList_present 0x80
#       define      IMAP2_CUG_Subscription_extensionContainer_present 0x40
    IMAP2_MS_DataTypes_CUG_Index cug_Index;
    IMAP2_MS_DataTypes_CUG_Interlock cug_Interlock;
    IMAP2_MS_DataTypes_IntraCUG_Options intraCUG_Options;
    struct IMAP2_Ext_BasicServiceGroupList_ *basicServiceGroupList;  
                                  /* optional; set in bit_mask
         * IMAP2_MS_DataTypes_CUG_Subscription_basicServiceGroupList_present if
         * present */
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                         * IMAP2_CUG_Subscription_extensionContainer_present if
                         * present */
} IMAP2_MS_DataTypes_CUG_Subscription;

typedef struct IMAP2_MS_DataTypes_CUG_SubscriptionList_ {
    struct IMAP2_MS_DataTypes_CUG_SubscriptionList_ *next;
    IMAP2_MS_DataTypes_CUG_Subscription value;
} *IMAP2_MS_DataTypes_CUG_SubscriptionList;

typedef struct IMAP2_MS_DataTypes_InterCUG_Restrictions {
    unsigned short  length;
    unsigned char   value[1];
} IMAP2_MS_DataTypes_InterCUG_Restrictions;

typedef struct IMAP2_MS_DataTypes_CUG_Feature {
    unsigned char   bit_mask;
#       define      IMAP2_MS_DataTypes_CUG_Feature_basicService_present 0x80
#       define      IMAP2_MS_DataTypes_CUG_Feature_preferentialCUG_Indicator_present 0x40
#       define      IMAP2_CUG_Feature_extensionContainer_present 0x20
    IMAP2_Ext_BasicServiceCode basicService;  /* optional; set in bit_mask
                       * IMAP2_MS_DataTypes_CUG_Feature_basicService_present if
                       * present */
    IMAP2_MS_DataTypes_CUG_Index preferentialCUG_Indicator;  /* optional; set in
                                   * bit_mask
          * IMAP2_MS_DataTypes_CUG_Feature_preferentialCUG_Indicator_present if
          * present */
    IMAP2_MS_DataTypes_InterCUG_Restrictions interCUG_Restrictions;
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                              * IMAP2_CUG_Feature_extensionContainer_present if
                              * present */
} IMAP2_MS_DataTypes_CUG_Feature;

typedef struct IMAP2_MS_DataTypes_CUG_FeatureList_ {
    struct IMAP2_MS_DataTypes_CUG_FeatureList_ *next;
    IMAP2_MS_DataTypes_CUG_Feature value;
} *IMAP2_MS_DataTypes_CUG_FeatureList;

typedef struct IMAP2_Ext_BasicServiceGroupList_ {
    struct IMAP2_Ext_BasicServiceGroupList_ *next;
    IMAP2_Ext_BasicServiceCode value;
} *IMAP2_Ext_BasicServiceGroupList;

typedef struct IMAP2_ZoneCode {
    unsigned short  length;
    unsigned char   value[2];
} IMAP2_ZoneCode;

typedef struct IMAP2_ZoneCodeList_ {
    struct IMAP2_ZoneCodeList_ *next;
    IMAP2_ZoneCode  value;
} *IMAP2_ZoneCodeList;

typedef enum IMAP2_RegionalSubscriptionResponse {
    IMAP2_networkNode_AreaRestricted = 0,
    IMAP2_tooManyZoneCodes = 1,
    IMAP2_zoneCodesConflict = 2,
    IMAP2_regionalSubscNotSupported = 3
} IMAP2_RegionalSubscriptionResponse;

typedef struct IMAP2_InsertSubscriberDataRes {
    unsigned char   bit_mask;
#       define      IMAP2_InsertSubscriberDataRes_teleserviceList_present 0x80
#       define      IMAP2_InsertSubscriberDataRes_bearerServiceList_present 0x40
#       define      IMAP2_InsertSubscriberDataRes_ss_List_present 0x20
#       define      IMAP2_odb_GeneralData_present 0x10
#       define      IMAP2_InsertSubscriberDataRes_regionalSubscriptionResponse_present 0x08
    struct IMAP2_TeleserviceList_ *teleserviceList;  /* optional; set in
                                   * bit_mask
                     * IMAP2_InsertSubscriberDataRes_teleserviceList_present if
                     * present */
    struct IMAP2_BearerServiceList_ *bearerServiceList;  /* optional; set in
                                   * bit_mask
                   * IMAP2_InsertSubscriberDataRes_bearerServiceList_present if
                   * present */
    struct IMAP2_SS_List_ *ss_List;  /* optional; set in bit_mask
                             * IMAP2_InsertSubscriberDataRes_ss_List_present if
                             * present */
    IMAP2_ODB_GeneralData odb_GeneralData;  /* optional; set in bit_mask
                                             * IMAP2_odb_GeneralData_present if
                                             * present */
    IMAP2_RegionalSubscriptionResponse regionalSubscriptionResponse;  
                                  /* optional; set in bit_mask
        * IMAP2_InsertSubscriberDataRes_regionalSubscriptionResponse_present if
        * present */
} IMAP2_InsertSubscriberDataRes;

typedef struct IMAP2_DeleteSubscriberDataArg {
    unsigned char   bit_mask;
#       define      IMAP2_basicServiceList_present 0x80
#       define      IMAP2_DeleteSubscriberDataArg_ss_List_present 0x40
#       define      IMAP2_DeleteSubscriberDataArg_roamingRestrictionDueToUnsupportedFeature_present 0x20
#       define      IMAP2_regionalSubscriptionIdentifier_present 0x10
    IMAP2_IMSI      imsi;
    struct IMAP2_BasicServiceList_ *basicServiceList;  /* optional; set in
                                   * bit_mask IMAP2_basicServiceList_present if
                                   * present */
	// The exception handling for reception of unsupported/not allocated
	// basicServiceCodes is defined in section 6.8.2
    struct IMAP2_SS_List_ *ss_List;  /* optional; set in bit_mask
                             * IMAP2_DeleteSubscriberDataArg_ss_List_present if
                             * present */
    Nulltype        roamingRestrictionDueToUnsupportedFeature;  /* optional; set
                                   * in bit_mask
       * IMAP2_DeleteSubscriberDataArg_roamingRestrictionDueToUnsupportedFeature_present if
       * present */
    IMAP2_ZoneCode  regionalSubscriptionIdentifier;  /* optional; set in
                                   * bit_mask
                              * IMAP2_regionalSubscriptionIdentifier_present if
                              * present */
} IMAP2_DeleteSubscriberDataArg;

typedef struct IMAP2_BasicServiceList_ {
    struct IMAP2_BasicServiceList_ *next;
    IMAP2_BasicServiceCode value;
} *IMAP2_BasicServiceList;

typedef struct IMAP2_DeleteSubscriberDataRes {
    unsigned char   bit_mask;
#       define      IMAP2_DeleteSubscriberDataRes_regionalSubscriptionResponse_present 0x80
#       define      IMAP2_DeleteSubscriberDataRes_extensionContainer_present 0x40
    IMAP2_RegionalSubscriptionResponse regionalSubscriptionResponse;  
                                  /* optional; set in bit_mask
        * IMAP2_DeleteSubscriberDataRes_regionalSubscriptionResponse_present if
        * present */
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                  * IMAP2_DeleteSubscriberDataRes_extensionContainer_present if
                  * present */
} IMAP2_DeleteSubscriberDataRes;

typedef enum IMAP2_MatchType {
    IMAP2_inhibiting = 0,
    IMAP2_enabling = 1
} IMAP2_MatchType;

// exception handling:
// reception of values in range 2-31 shall be treated as "continueCall"
// reception of values greater than 31 shall be treated as "releaseCall"
// fault recovery types
typedef struct IMAP2_ResetArg {
    unsigned char   bit_mask;
#       define      IMAP2_hlr_List_present 0x80
    IMAP2_ISDN_AddressString hlr_Number;
    struct IMAP2_HLR_List_ *hlr_List;  /* optional; set in bit_mask
                                        * IMAP2_hlr_List_present if present */
} IMAP2_ResetArg;

typedef struct IMAP2_RestoreDataArg {
    unsigned char   bit_mask;
#       define      IMAP2_RestoreDataArg_lmsi_present 0x80
#       define      IMAP2_RestoreDataArg_extensionContainer_present 0x40
    IMAP2_IMSI      imsi;
    IMAP2_LMSI      lmsi;  /* optional; set in bit_mask
                            * IMAP2_RestoreDataArg_lmsi_present if present */
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                           * IMAP2_RestoreDataArg_extensionContainer_present if
                           * present */
} IMAP2_RestoreDataArg;

typedef struct IMAP2_RestoreDataRes {
    unsigned char   bit_mask;
#       define      IMAP2_msNotReachable_present 0x80
#       define      IMAP2_RestoreDataRes_extensionContainer_present 0x40
    IMAP2_ISDN_AddressString hlr_Number;
    Nulltype        msNotReachable;  /* optional; set in bit_mask
                                      * IMAP2_msNotReachable_present if
                                      * present */
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                           * IMAP2_RestoreDataRes_extensionContainer_present if
                           * present */
} IMAP2_RestoreDataRes;

typedef struct IMAP2_GroupId {
    unsigned short  length;
    unsigned char   value[3];
} IMAP2_GroupId;

typedef struct IMAP2_VoiceBroadcastData {
    unsigned char   bit_mask;
#       define      IMAP2_broadcastInitEntitlement_present 0x80
#       define      IMAP2_VoiceBroadcastData_extensionContainer_present 0x40
    IMAP2_GroupId   groupid;
    Nulltype        broadcastInitEntitlement;  /* optional; set in bit_mask
                                    * IMAP2_broadcastInitEntitlement_present if
                                    * present */
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                       * IMAP2_VoiceBroadcastData_extensionContainer_present if
                       * present */
} IMAP2_VoiceBroadcastData;

// VBS/VGCS types
typedef struct IMAP2_VBSDataList_ {
    struct IMAP2_VBSDataList_ *next;
    IMAP2_VoiceBroadcastData value;
} *IMAP2_VBSDataList;

typedef struct IMAP2_VoiceGroupCallData {
    unsigned char   bit_mask;
#       define      IMAP2_VoiceGroupCallData_extensionContainer_present 0x80
    IMAP2_GroupId   groupId;
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                       * IMAP2_VoiceGroupCallData_extensionContainer_present if
                       * present */
} IMAP2_VoiceGroupCallData;

typedef struct IMAP2_VGCSDataList_ {
    struct IMAP2_VGCSDataList_ *next;
    IMAP2_VoiceGroupCallData value;
} *IMAP2_VGCSDataList;

typedef unsigned short  IMAP2_AgeOfLocationInformation;

// the value represents the elapsed time in minutes since the last
// network contact of the mobile station (i.e. the actuality of the
// location information).
// value "0" indicates that the MS is currently in contact with the
//           network
// value "32767" indicates that the location information is at least
//               32767 minutes old
typedef struct IMAP2_GeographicalInformation {
    unsigned short  length;
    unsigned char   value[8];
} IMAP2_GeographicalInformation;

// Refers to geographical Information defined in GSM 03.32.
// Only the description of an ellipsoid point with uncertainty circle
//as specified in GSM 03.32 is allowed to be used
// The internal structure according to GSM 03.32 is as follows:
//		Type of shape (ellipsoid point with uncertainty circle)	1 octet
//		Degrees of Latitude				3 octets
//		Degrees of Longitude				3 octets
//		Uncertainty code				1 octet
typedef struct IMAP2_LocationNumber {
    unsigned short  length;
    unsigned char   value[10];
} IMAP2_LocationNumber;

typedef enum IMAP2_NotReachableReason {
    IMAP2_msPurged = 0,
    IMAP2_imsiDetached = 1,
    IMAP2_NotReachableReason_restrictedArea = 2,
    IMAP2_notRegistered = 3
} IMAP2_NotReachableReason;

	// the internal structure is defined in CCITT Rec Q.763
typedef struct IMAP2_SubscriberState {
    unsigned short  choice;
#       define      IMAP2_assumedIdle_chosen 1
#       define      IMAP2_camelBusy_chosen 2
#       define      IMAP2_netDetNotReachable_chosen 3
#       define      IMAP2_notProvidedFromVLR_chosen 4
    union _union {
        Nulltype        assumedIdle;  /* to choose, set choice to
                                       * IMAP2_assumedIdle_chosen */
        Nulltype        camelBusy;  /* to choose, set choice to
                                     * IMAP2_camelBusy_chosen */
        IMAP2_NotReachableReason netDetNotReachable;  /* to choose, set choice
                                        * to IMAP2_netDetNotReachable_chosen */
        Nulltype        notProvidedFromVLR;  /* to choose, set choice to
                                           * IMAP2_notProvidedFromVLR_chosen */
    } u;
} IMAP2_SubscriberState;

// supplementary service handling operations
typedef struct IMAP2_RegisterSS {                                /*Timer m*/
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_RegisterSS;

typedef struct IMAP2_EraseSS {                           /*Timer m*/
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_EraseSS;

typedef struct IMAP2_ActivateSS {                                /*Timer m*/
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_ActivateSS;

typedef struct IMAP2_DeactivateSS {                              /*Timer m*/
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_DeactivateSS;

typedef struct IMAP2_InterrogateSS {                             /*Timer m*/
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_InterrogateSS;

typedef struct IMAP2_ProcessUnstructuredSS_Request {                /*Timer 10 minutes*/
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_ProcessUnstructuredSS_Request;

typedef struct IMAP2_UnstructuredSS_Request {                    /*Timer ml*/
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_UnstructuredSS_Request;

typedef struct IMAP2_UnstructuredSS_Notify {                             /*Timer ml*/
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_UnstructuredSS_Notify;

typedef struct IMAP2_RegisterPassword {                          /*Timer ml*/
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_RegisterPassword;

typedef struct IMAP2_GetPassword {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_GetPassword;                               /*Timer m*/

typedef enum IMAP2_RoamingNotAllowedCause {
    IMAP2_plmnRoamingNotAllowed = 0,
    IMAP2_RoamingNotAllowedCause_operatorDeterminedBarring = 3
} IMAP2_RoamingNotAllowedCause;

typedef struct IMAP2_RoamingNotAllowedParam {
    unsigned char   bit_mask;
#       define      IMAP2_RoamingNotAllowedParam_extensionContainer_present 0x80
    IMAP2_RoamingNotAllowedCause roamingNotAllowedCause;
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                   * IMAP2_RoamingNotAllowedParam_extensionContainer_present if
                   * present */
} IMAP2_RoamingNotAllowedParam;

typedef enum IMAP2_CallBarringCause {
    IMAP2_barringServiceActive = 0,
    IMAP2_operatorBarring = 1
} IMAP2_CallBarringCause;

typedef struct IMAP2_ExtensibleCallBarredParam {
    unsigned char   bit_mask;
#       define      IMAP2_callBarringCause_present 0x80
#       define      IMAP2_ExtensibleCallBarredParam_extensionContainer_present 0x40
#       define      IMAP2_unauthorisedMessageOriginator_present 0x20
    IMAP2_CallBarringCause callBarringCause;  /* optional; set in bit_mask
                                               * IMAP2_callBarringCause_present
                                               * if present */
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                * IMAP2_ExtensibleCallBarredParam_extensionContainer_present if
                * present */
    Nulltype        unauthorisedMessageOriginator;  /* extension #1; optional;
                                   * set in bit_mask
                                   * IMAP2_unauthorisedMessageOriginator_present
                                   * if present */
} IMAP2_ExtensibleCallBarredParam;

typedef struct IMAP2_CallBarredParam {
    unsigned short  choice;
#       define      IMAP2_callBarringCause_chosen 1
#       define      IMAP2_extensibleCallBarredParam_chosen 2
    union _union {
        IMAP2_CallBarringCause callBarringCause;  /* to choose, set choice to
                                             * IMAP2_callBarringCause_chosen */
	// call BarringCause must not be used in version 3
        IMAP2_ExtensibleCallBarredParam extensibleCallBarredParam;  /* to
                                   * choose, set choice to
                                   * IMAP2_extensibleCallBarredParam_chosen */
	// extensibleCallBarredParam must not be used in version <3
    } u;
} IMAP2_CallBarredParam;

typedef enum IMAP2_CUG_RejectCause {
    IMAP2_incomingCallsBarredWithinCUG = 0,
    IMAP2_subscriberNotMemberOfCUG = 1,
    IMAP2_requestedBasicServiceViolatesCUG_Constraints = 5,
    IMAP2_calledPartySS_InteractionViolation = 7
} IMAP2_CUG_RejectCause;

typedef struct IMAP2_CUG_RejectParam {
    unsigned char   bit_mask;
#       define      IMAP2_cug_RejectCause_present 0x80
#       define      IMAP2_CUG_RejectParam_extensionContainer_present 0x40
    IMAP2_CUG_RejectCause cug_RejectCause;  /* optional; set in bit_mask
                                             * IMAP2_cug_RejectCause_present if
                                             * present */
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                          * IMAP2_CUG_RejectParam_extensionContainer_present if
                          * present */
} IMAP2_CUG_RejectParam;

typedef struct IMAP2_SS_IncompatibilityCause {
    unsigned char   bit_mask;
#       define      IMAP2_SS_IncompatibilityCause_ss_Code_present 0x80
#       define      IMAP2_SS_IncompatibilityCause_basicService_present 0x40
#       define      IMAP2_SS_IncompatibilityCause_ss_Status_present 0x20
    IMAP2_SS_Code   ss_Code;  /* optional; set in bit_mask
                               * IMAP2_SS_IncompatibilityCause_ss_Code_present
                               * if present */
    IMAP2_BasicServiceCode basicService;  /* optional; set in bit_mask
                        * IMAP2_SS_IncompatibilityCause_basicService_present if
                        * present */
    IMAP2_SS_Status ss_Status;  /* optional; set in bit_mask
                           * IMAP2_SS_IncompatibilityCause_ss_Status_present if
                           * present */
} IMAP2_SS_IncompatibilityCause;

typedef enum IMAP2_SM_EnumeratedDeliveryFailureCause {
    IMAP2_SM_EnumeratedDeliveryFailureCause_memoryCapacityExceeded = 0,
    IMAP2_equipmentProtocolError = 1,
    IMAP2_equipmentNotSM_Equipped = 2,
    IMAP2_unknownServiceCentre = 3,
    IMAP2_sc_Congestion = 4,
    IMAP2_invalidSME_Address = 5,
    IMAP2_subscriberNotSC_Subscriber = 6
} IMAP2_SM_EnumeratedDeliveryFailureCause;

typedef struct IMAP2_SM_DeliveryFailureCause {
    unsigned char   bit_mask;
#       define      IMAP2_diagnosticInfo_present 0x80
#       define      IMAP2_SM_DeliveryFailureCause_extensionContainer_present 0x40
    IMAP2_SM_EnumeratedDeliveryFailureCause sm_EnumeratedDeliveryFailureCause;
    IMAP2_SignalInfo diagnosticInfo;  /* optional; set in bit_mask
                                       * IMAP2_diagnosticInfo_present if
                                       * present */
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                  * IMAP2_SM_DeliveryFailureCause_extensionContainer_present if
                  * present */
} IMAP2_SM_DeliveryFailureCause;

	// if received, additionalAbsentSubscriberDiagnosticSM 
	// is for GPRS and absentSubscriberDiagnosticSM is 
	// for non-GPRS
typedef unsigned short  IMAP2_AbsentSubscriberDiagnosticSM;

typedef struct IMAP2_AbsentSubscriberSM_Param {
    unsigned char   bit_mask;
#       define      IMAP2_absentSubscriberDiagnosticSM_present 0x80
#       define      IMAP2_AbsentSubscriberSM_Param_extensionContainer_present 0x40
#       define      IMAP2_additionalAbsentSubscriberDiagnosticSM_present 0x20
    IMAP2_AbsentSubscriberDiagnosticSM absentSubscriberDiagnosticSM;  
                                  /* optional; set in bit_mask
                                   * IMAP2_absentSubscriberDiagnosticSM_present
                                   * if present */
	// AbsentSubscriberDiagnosticSM can be either for non-GPRS 
	// or for GPRS
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                 * IMAP2_AbsentSubscriberSM_Param_extensionContainer_present if
                 * present */
    IMAP2_AbsentSubscriberDiagnosticSM additionalAbsentSubscriberDiagnosticSM;                                          /* extension #1; optional; set in
                                   * bit_mask
                      * IMAP2_additionalAbsentSubscriberDiagnosticSM_present if
                      * present */
} IMAP2_AbsentSubscriberSM_Param;

typedef struct IMAP2_ExtensibleSystemFailureParam {
    unsigned char   bit_mask;
#       define      IMAP2_networkResource_present 0x80
#       define      IMAP2_ExtensibleSystemFailureParam_extensionContainer_present 0x40
    IMAP2_NetworkResource networkResource;  /* optional; set in bit_mask
                                             * IMAP2_networkResource_present if
                                             * present */
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
             * IMAP2_ExtensibleSystemFailureParam_extensionContainer_present if
             * present */
} IMAP2_ExtensibleSystemFailureParam;

	// AbsentSubscriberDiagnosticSM values are defined in ETS 300 536 (GSM 03.40)
typedef struct IMAP2_SystemFailureParam {
    unsigned short  choice;
#       define      IMAP2_networkResource_chosen 1
#       define      IMAP2_extensibleSystemFailureParam_chosen 2
    union _union {
        IMAP2_NetworkResource networkResource;  /* to choose, set choice to
                                              * IMAP2_networkResource_chosen */
	// networkResource must not be used in version 3
        IMAP2_ExtensibleSystemFailureParam extensibleSystemFailureParam;  
                                        /* to choose, set choice to
                                 * IMAP2_extensibleSystemFailureParam_chosen */
	// extensibleSystemFailureParam must not be used in version <3
    } u;
} IMAP2_SystemFailureParam;

typedef struct IMAP2_DataMissingParam {
    unsigned char   bit_mask;
#       define      IMAP2_DataMissingParam_extensionContainer_present 0x80
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                         * IMAP2_DataMissingParam_extensionContainer_present if
                         * present */
} IMAP2_DataMissingParam;

typedef struct IMAP2_UnexpectedDataParam {
    unsigned char   bit_mask;
#       define      IMAP2_UnexpectedDataParam_extensionContainer_present 0x80
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                      * IMAP2_UnexpectedDataParam_extensionContainer_present if
                      * present */
} IMAP2_UnexpectedDataParam;

typedef struct IMAP2_FacilityNotSupParam {
    unsigned char   bit_mask;
#       define      IMAP2_FacilityNotSupParam_extensionContainer_present 0x80
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                      * IMAP2_FacilityNotSupParam_extensionContainer_present if
                      * present */
} IMAP2_FacilityNotSupParam;

typedef struct IMAP2_OR_NotAllowedParam {
    unsigned char   bit_mask;
#       define      IMAP2_OR_NotAllowedParam_extensionContainer_present 0x80
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                       * IMAP2_OR_NotAllowedParam_extensionContainer_present if
                       * present */
} IMAP2_OR_NotAllowedParam;

typedef enum IMAP2_UnknownSubscriberDiagnostic {
    IMAP2_imsiUnknown = 0,
    IMAP2_gprsSubscriptionUnknown = 1
} IMAP2_UnknownSubscriberDiagnostic;

typedef struct IMAP2_UnknownSubscriberParam {
    unsigned char   bit_mask;
#       define      IMAP2_UnknownSubscriberParam_extensionContainer_present 0x80
#       define      IMAP2_unknownSubscriberDiagnostic_present 0x40
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                   * IMAP2_UnknownSubscriberParam_extensionContainer_present if
                   * present */
    IMAP2_UnknownSubscriberDiagnostic unknownSubscriberDiagnostic;  
                                  /* extension #1; optional; set in bit_mask
                                   * IMAP2_unknownSubscriberDiagnostic_present
                                   * if present */
} IMAP2_UnknownSubscriberParam;

	// if unknown values are received in 	
	// unknownSubscriberDiagnostic they shall be discarded
typedef struct IMAP2_NumberChangedParam {
    unsigned char   bit_mask;
#       define      IMAP2_NumberChangedParam_extensionContainer_present 0x80
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                       * IMAP2_NumberChangedParam_extensionContainer_present if
                       * present */
} IMAP2_NumberChangedParam;

typedef struct IMAP2_UnidentifiedSubParam {
    unsigned char   bit_mask;
#       define      IMAP2_UnidentifiedSubParam_extensionContainer_present 0x80
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                     * IMAP2_UnidentifiedSubParam_extensionContainer_present if
                     * present */
} IMAP2_UnidentifiedSubParam;

typedef struct IMAP2_IllegalSubscriberParam {
    unsigned char   bit_mask;
#       define      IMAP2_IllegalSubscriberParam_extensionContainer_present 0x80
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                   * IMAP2_IllegalSubscriberParam_extensionContainer_present if
                   * present */
} IMAP2_IllegalSubscriberParam;

typedef struct IMAP2_IllegalEquipmentParam {
    unsigned char   bit_mask;
#       define      IMAP2_IllegalEquipmentParam_extensionContainer_present 0x80
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                    * IMAP2_IllegalEquipmentParam_extensionContainer_present if
                    * present */
} IMAP2_IllegalEquipmentParam;

typedef struct IMAP2_BearerServNotProvParam {
    unsigned char   bit_mask;
#       define      IMAP2_BearerServNotProvParam_extensionContainer_present 0x80
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                   * IMAP2_BearerServNotProvParam_extensionContainer_present if
                   * present */
} IMAP2_BearerServNotProvParam;

typedef struct IMAP2_TeleservNotProvParam {
    unsigned char   bit_mask;
#       define      IMAP2_TeleservNotProvParam_extensionContainer_present 0x80
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                     * IMAP2_TeleservNotProvParam_extensionContainer_present if
                     * present */
} IMAP2_TeleservNotProvParam;

typedef struct IMAP2_TracingBufferFullParam {
    unsigned char   bit_mask;
#       define      IMAP2_TracingBufferFullParam_extensionContainer_present 0x80
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                   * IMAP2_TracingBufferFullParam_extensionContainer_present if
                   * present */
} IMAP2_TracingBufferFullParam;

typedef struct IMAP2_NoRoamingNbParam {
    unsigned char   bit_mask;
#       define      IMAP2_NoRoamingNbParam_extensionContainer_present 0x80
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                         * IMAP2_NoRoamingNbParam_extensionContainer_present if
                         * present */
} IMAP2_NoRoamingNbParam;

typedef enum IMAP2_AbsentSubscriberReason {
    IMAP2_imsiDetach = 0,
    IMAP2_AbsentSubscriberReason_restrictedArea = 1,
    IMAP2_noPageResponse = 2
} IMAP2_AbsentSubscriberReason;

typedef struct IMAP2_AbsentSubscriberParam {
    unsigned char   bit_mask;
#       define      IMAP2_AbsentSubscriberParam_extensionContainer_present 0x80
#       define      IMAP2_absentSubscriberReason_present 0x40
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                    * IMAP2_AbsentSubscriberParam_extensionContainer_present if
                    * present */
    IMAP2_AbsentSubscriberReason absentSubscriberReason;  /* extension #1;
                                   * optional; set in bit_mask
                                   * IMAP2_absentSubscriberReason_present if
                                   * present */
} IMAP2_AbsentSubscriberParam;

// exception handling: at reception of other values than the ones listed the 
// AbsentSubscriberReason shall be ignored.
typedef struct IMAP2_BusySubscriberParam {
    unsigned char   bit_mask;
#       define      IMAP2_BusySubscriberParam_extensionContainer_present 0x80
#       define      IMAP2_BusySubscriberParam_ccbs_Possible_present 0x40
#       define      IMAP2_ccbs_Busy_present 0x20
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                      * IMAP2_BusySubscriberParam_extensionContainer_present if
                      * present */
    Nulltype        ccbs_Possible;  /* extension #1; optional; set in bit_mask
                           * IMAP2_BusySubscriberParam_ccbs_Possible_present if
                           * present */
    Nulltype        ccbs_Busy;  /* extension #2; optional; set in bit_mask
                                 * IMAP2_ccbs_Busy_present if present */
} IMAP2_BusySubscriberParam;

typedef struct IMAP2_NoSubscriberReplyParam {
    unsigned char   bit_mask;
#       define      IMAP2_NoSubscriberReplyParam_extensionContainer_present 0x80
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                   * IMAP2_NoSubscriberReplyParam_extensionContainer_present if
                   * present */
} IMAP2_NoSubscriberReplyParam;

typedef struct IMAP2_ForwardingViolationParam {
    unsigned char   bit_mask;
#       define      IMAP2_ForwardingViolationParam_extensionContainer_present 0x80
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                 * IMAP2_ForwardingViolationParam_extensionContainer_present if
                 * present */
} IMAP2_ForwardingViolationParam;

typedef struct IMAP2_ForwardingFailedParam {
    unsigned char   bit_mask;
#       define      IMAP2_ForwardingFailedParam_extensionContainer_present 0x80
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                    * IMAP2_ForwardingFailedParam_extensionContainer_present if
                    * present */
} IMAP2_ForwardingFailedParam;

typedef struct IMAP2_ATI_NotAllowedParam {
    unsigned char   bit_mask;
#       define      IMAP2_ATI_NotAllowedParam_extensionContainer_present 0x80
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                      * IMAP2_ATI_NotAllowedParam_extensionContainer_present if
                      * present */
} IMAP2_ATI_NotAllowedParam;

typedef struct IMAP2_SubBusyForMT_SMS_Param {
    unsigned char   bit_mask;
#       define      IMAP2_SubBusyForMT_SMS_Param_extensionContainer_present 0x80
#       define      IMAP2_gprsConnectionSuspended_present 0x40
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                   * IMAP2_SubBusyForMT_SMS_Param_extensionContainer_present if
                   * present */
    Nulltype        gprsConnectionSuspended;  /* extension #1; optional; set in
                                   * bit_mask
                                   * IMAP2_gprsConnectionSuspended_present if
                                   * present */
} IMAP2_SubBusyForMT_SMS_Param;

	// If GprsConnectionSuspended is not understood it shall 
	// be discarded
typedef struct IMAP2_MessageWaitListFullParam {
    unsigned char   bit_mask;
#       define      IMAP2_MessageWaitListFullParam_extensionContainer_present 0x80
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                 * IMAP2_MessageWaitListFullParam_extensionContainer_present if
                 * present */
} IMAP2_MessageWaitListFullParam;

typedef struct IMAP2_ResourceLimitationParam {
    unsigned char   bit_mask;
#       define      IMAP2_ResourceLimitationParam_extensionContainer_present 0x80
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                  * IMAP2_ResourceLimitationParam_extensionContainer_present if
                  * present */
} IMAP2_ResourceLimitationParam;

typedef struct IMAP2_NoGroupCallNbParam {
    unsigned char   bit_mask;
#       define      IMAP2_NoGroupCallNbParam_extensionContainer_present 0x80
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                       * IMAP2_NoGroupCallNbParam_extensionContainer_present if
                       * present */
} IMAP2_NoGroupCallNbParam;

typedef struct IMAP2_IncompatibleTerminalParam {
    unsigned char   bit_mask;
#       define      IMAP2_IncompatibleTerminalParam_extensionContainer_present 0x80
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                * IMAP2_IncompatibleTerminalParam_extensionContainer_present if
                * present */
} IMAP2_IncompatibleTerminalParam;

typedef struct IMAP2_ShortTermDenialParam {
    char            placeholder;
} IMAP2_ShortTermDenialParam;

typedef struct IMAP2_LongTermDenialParam {
    char            placeholder;
} IMAP2_LongTermDenialParam;

typedef struct IMAP2_TraceReference {
    unsigned short  length;
    unsigned char   value[2];
} IMAP2_TraceReference;

typedef unsigned short  IMAP2_TraceType;

typedef struct IMAP2_ActivateTraceModeArg {
    unsigned char   bit_mask;
#       define      IMAP2_ActivateTraceModeArg_imsi_present 0x80
#       define      IMAP2_omc_Id_present 0x40
#       define      IMAP2_ActivateTraceModeArg_extensionContainer_present 0x20
    IMAP2_IMSI      imsi;  /* optional; set in bit_mask
                            * IMAP2_ActivateTraceModeArg_imsi_present if
                            * present */
    IMAP2_TraceReference traceReference;
    IMAP2_TraceType traceType;
    IMAP2_AddressString omc_Id;  /* optional; set in bit_mask
                                  * IMAP2_omc_Id_present if present */
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                     * IMAP2_ActivateTraceModeArg_extensionContainer_present if
                     * present */
} IMAP2_ActivateTraceModeArg;

	// Trace types are fully defined in TS GSM 12.08.
typedef struct IMAP2_ActivateTraceModeRes {
    unsigned char   bit_mask;
#       define      IMAP2_ActivateTraceModeRes_extensionContainer_present 0x80
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                     * IMAP2_ActivateTraceModeRes_extensionContainer_present if
                     * present */
} IMAP2_ActivateTraceModeRes;

typedef struct IMAP2_DeactivateTraceModeArg {
    unsigned char   bit_mask;
#       define      IMAP2_DeactivateTraceModeArg_imsi_present 0x80
#       define      IMAP2_DeactivateTraceModeArg_extensionContainer_present 0x40
    IMAP2_IMSI      imsi;  /* optional; set in bit_mask
                            * IMAP2_DeactivateTraceModeArg_imsi_present if
                            * present */
    IMAP2_TraceReference traceReference;
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                   * IMAP2_DeactivateTraceModeArg_extensionContainer_present if
                   * present */
} IMAP2_DeactivateTraceModeArg;

typedef struct IMAP2_DeactivateTraceModeRes {
    unsigned char   bit_mask;
#       define      IMAP2_DeactivateTraceModeRes_extensionContainer_present 0x80
    IMAP2_ExtensionContainer extensionContainer;  /* optional; set in bit_mask
                   * IMAP2_DeactivateTraceModeRes_extensionContainer_present if
                   * present */
} IMAP2_DeactivateTraceModeRes;

typedef IMAP2_ISDN_AddressString IMAP2_SendIMSIArg;

typedef IMAP2_IMSI      IMAP2_SendIMSIRes;

	// generic errors
	// identification and numbering errors
	// subscription errors
	// handover errors
	// operation and maintenance errors
	// call handling errors
	// any time interrogation errors
	// supplementary service errors
	// short message service errors
	// Group Call errors
// generic errors
typedef struct IMAP2_SystemFailure {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_SystemFailure;

		// optional
typedef struct IMAP2_DataMissing {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_DataMissing;

		// optional
		// dataMissingParam must not be used in version <3
typedef struct IMAP2_UnexpectedDataValue {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_UnexpectedDataValue;

		// optional
		// unexpectedDataParam must not be used in version <3
typedef struct IMAP2_FacilityNotSupported {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_FacilityNotSupported;

		// optional
		// facilityNotSupParam must not be used in version <3
typedef struct IMAP2_IncompatibleTerminal {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_IncompatibleTerminal;

		// optional
typedef struct IMAP2_ResourceLimitation {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_ResourceLimitation;

		// optional

// identification and numbering errors
typedef struct IMAP2_UnknownSubscriber {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_UnknownSubscriber;

		// optional
		// unknownSubscriberParam must not be used in version <3
typedef struct IMAP2_NumberChanged {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_NumberChanged;

		// optional
typedef struct IMAP2_UnknownMSC {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_UnknownMSC;

typedef struct IMAP2_UnidentifiedSubscriber {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_UnidentifiedSubscriber;

		// optional
		// unidentifiedSubParam must not be used in version <3
typedef struct IMAP2_UnknownEquipment {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_UnknownEquipment;

// subscription errors
typedef struct IMAP2_RoamingNotAllowed {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_RoamingNotAllowed;

typedef struct IMAP2_IllegalSubscriber {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_IllegalSubscriber;

		// optional
		// illegalSubscriberParam must not be used in version <3
typedef struct IMAP2_IllegalEquipment {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_IllegalEquipment;

		// optional
		// illegalEquipmentParam must not be used in version <3
typedef struct IMAP2_BearerServiceNotProvisioned {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_BearerServiceNotProvisioned;

		// optional
		// bearerServNotProvParam must not be used in version <3
typedef struct IMAP2_TeleserviceNotProvisioned {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_TeleserviceNotProvisioned;

		// optional
		// teleservNotProvParam must not be used in version <3

// handover errors
typedef struct IMAP2_NoHandoverNumberAvailable {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_NoHandoverNumberAvailable;

typedef struct IMAP2_SubsequentHandoverFailure {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_SubsequentHandoverFailure;

// operation and maintenance errors
typedef struct IMAP2_TracingBufferFull {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_TracingBufferFull;

		// optional

// call handling errors
typedef struct IMAP2_NoRoamingNumberAvailable {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_NoRoamingNumberAvailable;

		// optional
typedef struct IMAP2_AbsentSubscriber {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_AbsentSubscriber;

		// optional

		// absentSubscriberParam must not be used in version <3
typedef struct IMAP2_BusySubscriber {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_BusySubscriber;

		// optional
typedef struct IMAP2_NoSubscriberReply {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_NoSubscriberReply;

		// optional
typedef struct IMAP2_CallBarred {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_CallBarred;

		// optional
typedef struct IMAP2_ForwardingViolation {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_ForwardingViolation;

		// optional
typedef struct IMAP2_ForwardingFailed {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_ForwardingFailed;

		// optional
typedef struct IMAP2_CUG_Reject {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_CUG_Reject;

		// optional
typedef struct IMAP2_OR_NotAllowed {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_OR_NotAllowed;

		// optional

// any time interrogation errors
typedef struct IMAP2_ATI_NotAllowed {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_ATI_NotAllowed;

		// optional

// supplementary service errors
typedef struct IMAP2_IllegalSS_Operation {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_IllegalSS_Operation;

typedef struct IMAP2_SS_ErrorStatus {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_SS_ErrorStatus;

		// optional
typedef struct IMAP2_SS_NotAvailable {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_SS_NotAvailable;

typedef struct IMAP2_SS_SubscriptionViolation {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_SS_SubscriptionViolation;

typedef struct IMAP2_SS_Incompatibility {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_SS_Incompatibility;

		// optional
typedef struct IMAP2_UnknownAlphabet {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_UnknownAlphabet;

typedef struct IMAP2_USSD_Busy {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_USSD_Busy;

typedef struct IMAP2_PW_RegistrationFailure {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_PW_RegistrationFailure;

typedef struct IMAP2_NegativePW_Check {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_NegativePW_Check;

typedef struct IMAP2_NumberOfPW_AttemptsViolation {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_NumberOfPW_AttemptsViolation;

typedef struct IMAP2_ShortTermDenial {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_ShortTermDenial;

		// optional
typedef struct IMAP2_LongTermDenial {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_LongTermDenial;

		// optional

// short message service errors
typedef struct IMAP2_SubscriberBusyForMT_SMS {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_SubscriberBusyForMT_SMS;

		// optional
typedef struct IMAP2_SM_DeliveryFailure {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_SM_DeliveryFailure;

typedef struct IMAP2_MessageWaitingListFull {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_MessageWaitingListFull;

		// optional
typedef struct IMAP2_AbsentSubscriberSM {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_AbsentSubscriberSM;

		// optional

// Group Call errors
typedef struct IMAP2_NoGroupCallNumberAvailable {
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_NoGroupCallNumberAvailable;
		// optional

typedef struct IMAP2_ActivateTraceMode {                         /*Timer m*/
		// optional
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_ActivateTraceMode;

typedef struct IMAP2_DeactivateTraceMode {                               /*Timer m*/
		// optional
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_DeactivateTraceMode;

typedef struct IMAP2_SendIMSI {                          /*Timer m*/
    unsigned short  choice;
#       define      IMAP2_localValue_chosen 1
#       define      IMAP2_globalValue_chosen 2
    union _union {
        int             localValue;  /* to choose, set choice to
                                      * IMAP2_localValue_chosen */
        IMAP2__ObjectID globalValue;  /* to choose, set choice to
                                       * IMAP2_globalValue_chosen */
    } u;
} IMAP2_SendIMSI;

typedef struct IMAP2__octet1 {
    unsigned short  length;
    unsigned char   value[20];
} IMAP2__octet1;

typedef struct IMAP2__seq3 {
    char            placeholder;
} IMAP2__seq3;

typedef enum IMAP2__enum1 {
    IMAP2_reason_noReasonGiven = 0,
    IMAP2_reason_invalidDestinationReference = 1,
    IMAP2_reason_invalidOriginatingReference = 2
} IMAP2__enum1;

typedef enum IMAP2__enum2 {
    IMAP2_resourceUnavailable_shortTermResourceLimitation = 0,
    IMAP2_resourceUnavailable_longTermResourceLimitation = 1
} IMAP2__enum2;

typedef enum IMAP2__enum3 {
    IMAP2_applicationProcedureCancellation_handoverCancellation = 0,
    IMAP2_applicationProcedureCancellation_radioChannelRelease = 1,
    IMAP2_applicationProcedureCancellation_networkPathRelease = 2,
    IMAP2_applicationProcedureCancellation_callRelease = 3,
    IMAP2_applicationProcedureCancellation_associatedProcedureFailure = 4,
    IMAP2_applicationProcedureCancellation_tandemDialogueRelease = 5,
    IMAP2_applicationProcedureCancellation_remoteOperationsFailure = 6
} IMAP2__enum3;

typedef struct IMAP2__choice6 {
    unsigned short  choice;
#       define      IMAP2_map_UserAbortChoice_userSpecificReason_chosen 1
#       define      IMAP2_map_UserAbortChoice_userResourceLimitation_chosen 2
#       define      IMAP2_map_UserAbortChoice_resourceUnavailable_chosen 3
#       define      IMAP2_map_UserAbortChoice_applicationProcedureCancellation_chosen 4
    union _union {
        Nulltype        userSpecificReason;  /* to choose, set choice to
                       * IMAP2_map_UserAbortChoice_userSpecificReason_chosen */
        Nulltype        userResourceLimitation;  /* to choose, set choice to
                   * IMAP2_map_UserAbortChoice_userResourceLimitation_chosen */
        IMAP2__enum2    resourceUnavailable;  /* to choose, set choice to
                      * IMAP2_map_UserAbortChoice_resourceUnavailable_chosen */
        IMAP2__enum3    applicationProcedureCancellation;  /* to choose, set
                                   * choice to
         * IMAP2_map_UserAbortChoice_applicationProcedureCancellation_chosen */
    } u;
} IMAP2__choice6;

typedef enum IMAP2__enum4 {
    IMAP2_map_ProviderAbortReason_abnormalDialogue = 0,
    IMAP2_map_ProviderAbortReason_invalidPDU = 1
} IMAP2__enum4;

typedef struct IMAP2_DialoguePDU {
    unsigned short  choice;
#       define      IMAP2_map_open_chosen 1
#       define      IMAP2_map_accept_chosen 2
#       define      IMAP2_map_close_chosen 3
#       define      IMAP2_map_refuse_chosen 4
#       define      IMAP2_map_userAbort_chosen 5
#       define      IMAP2_map_providerAbort_chosen 6
    union _union {
        struct IMAP2__seq2 {
            unsigned char   bit_mask;
#               define      IMAP2_map_open_destinationReference_present 0x80
#               define      IMAP2_map_open_originationReference_present 0x40
            IMAP2__octet1   destinationReference;  /* optional; set in bit_mask
                               * IMAP2_map_open_destinationReference_present if
                               * present */
            IMAP2__octet1   originationReference;  /* optional; set in bit_mask
                               * IMAP2_map_open_originationReference_present if
                               * present */
        } map_open;  /* to choose, set choice to IMAP2_map_open_chosen */
        IMAP2__seq3     map_accept;  /* to choose, set choice to
                                      * IMAP2_map_accept_chosen */
        IMAP2__seq3     map_close;  /* to choose, set choice to
                                     * IMAP2_map_close_chosen */
        struct IMAP2__seq4 {
            IMAP2__enum1    reason;
        } map_refuse;  /* to choose, set choice to IMAP2_map_refuse_chosen */
        struct IMAP2__seq5 {
            IMAP2__choice6  map_UserAbortChoice;
        } map_userAbort;  /* to choose, set choice to
                           * IMAP2_map_userAbort_chosen */
        struct IMAP2__seq6 {
            IMAP2__enum4    map_ProviderAbortReason;
        } map_providerAbort;  /* to choose, set choice to
                               * IMAP2_map_providerAbort_chosen */
    } u;
} IMAP2_DialoguePDU;

typedef struct IMAP2_OpenInfo {
    unsigned char   bit_mask;
#       define      IMAP2_OpenInfo_destinationReference_present 0x80
#       define      IMAP2_OpenInfo_originationReference_present 0x40
    IMAP2__octet1   destinationReference;  /* optional; set in bit_mask
                               * IMAP2_OpenInfo_destinationReference_present if
                               * present */
    IMAP2__octet1   originationReference;  /* optional; set in bit_mask
                               * IMAP2_OpenInfo_originationReference_present if
                               * present */
} IMAP2_OpenInfo;

typedef struct IMAP2_AcceptInfo {
    char            placeholder;
} IMAP2_AcceptInfo;

typedef struct IMAP2_CloseInfo {
    char            placeholder;
} IMAP2_CloseInfo;

typedef struct IMAP2_RefuseInfo {
    IMAP2__enum1    reason;
} IMAP2_RefuseInfo;

typedef struct IMAP2_UserAbortInfo {
    IMAP2__choice6  map_UserAbortChoice;
} IMAP2_UserAbortInfo;

typedef struct IMAP2_UserAbortChoice {
    unsigned short  choice;
#       define      IMAP2_UserAbortChoice_userSpecificReason_chosen 1
#       define      IMAP2_UserAbortChoice_userResourceLimitation_chosen 2
#       define      IMAP2_UserAbortChoice_resourceUnavailable_chosen 3
#       define      IMAP2_UserAbortChoice_applicationProcedureCancellation_chosen 4
    union _union {
        Nulltype        userSpecificReason;  /* to choose, set choice to
                           * IMAP2_UserAbortChoice_userSpecificReason_chosen */
        Nulltype        userResourceLimitation;  /* to choose, set choice to
                       * IMAP2_UserAbortChoice_userResourceLimitation_chosen */
        IMAP2__enum2    resourceUnavailable;  /* to choose, set choice to
                          * IMAP2_UserAbortChoice_resourceUnavailable_chosen */
        IMAP2__enum3    applicationProcedureCancellation;  /* to choose, set
                                   * choice to
             * IMAP2_UserAbortChoice_applicationProcedureCancellation_chosen */
    } u;
} IMAP2_UserAbortChoice;

typedef struct IMAP2_ProviderAbortInfo {
    IMAP2__enum4    map_ProviderAbortReason;
} IMAP2_ProviderAbortInfo;

#ifndef _OSSNOVALUES

extern const int IMAP2_maxNumOfPrivateExtensions;

	// This type is used to represent the code identifying a single
	// bearer service, a group of bearer services, or all bearer
	// services. The services are defined in TS GSM 02.02.
	// The internal structure is defined as follows:
	//
	// OCTET 1:
	// plmn-specific bearer services:
	// bits 87654321: defined by the HPLMN operator
	//
	// rest of bearer services:
	// bit 8: 0 (unused)
	// bits 7654321: group (bits 7654), and rate, if applicable
	// (bits 321)

	// OCTETS 2-5: reserved for future use. If received the
    // Ext-TeleserviceCode shall be
	// treated according to the exception handling defined for the
	// operation that uses this type. 

	// Ext-BearerServiceCode includes all values defined for BearerServiceCode.
extern IMAP2_BearerServiceCode IMAP2_allBearerServices;

extern IMAP2_BearerServiceCode IMAP2_allDataCDA_Services;

extern IMAP2_BearerServiceCode IMAP2_dataCDA_300bps;

extern IMAP2_BearerServiceCode IMAP2_dataCDA_1200bps;

extern IMAP2_BearerServiceCode IMAP2_dataCDA_1200_75bps;

extern IMAP2_BearerServiceCode IMAP2_dataCDA_2400bps;

extern IMAP2_BearerServiceCode IMAP2_dataCDA_4800bps;

extern IMAP2_BearerServiceCode IMAP2_dataCDA_9600bps;

extern IMAP2_BearerServiceCode IMAP2_general_dataCDA;

extern IMAP2_BearerServiceCode IMAP2_allDataCDS_Services;

extern IMAP2_BearerServiceCode IMAP2_dataCDS_1200bps;

extern IMAP2_BearerServiceCode IMAP2_dataCDS_2400bps;

extern IMAP2_BearerServiceCode IMAP2_dataCDS_4800bps;

extern IMAP2_BearerServiceCode IMAP2_dataCDS_9600bps;

extern IMAP2_BearerServiceCode IMAP2_general_dataCDS;

extern IMAP2_BearerServiceCode IMAP2_allPadAccessCA_Services;

extern IMAP2_BearerServiceCode IMAP2_padAccessCA_300bps;

extern IMAP2_BearerServiceCode IMAP2_padAccessCA_1200bps;

extern IMAP2_BearerServiceCode IMAP2_padAccessCA_1200_75bps;

extern IMAP2_BearerServiceCode IMAP2_padAccessCA_2400bps;

extern IMAP2_BearerServiceCode IMAP2_padAccessCA_4800bps;

extern IMAP2_BearerServiceCode IMAP2_padAccessCA_9600bps;

extern IMAP2_BearerServiceCode IMAP2_general_padAccessCA;

extern IMAP2_BearerServiceCode IMAP2_allDataPDS_Services;

extern IMAP2_BearerServiceCode IMAP2_dataPDS_2400bps;

extern IMAP2_BearerServiceCode IMAP2_dataPDS_4800bps;

extern IMAP2_BearerServiceCode IMAP2_dataPDS_9600bps;

extern IMAP2_BearerServiceCode IMAP2_general_dataPDS;

extern IMAP2_BearerServiceCode IMAP2_allAlternateSpeech_DataCDA;

extern IMAP2_BearerServiceCode IMAP2_allAlternateSpeech_DataCDS;

extern IMAP2_BearerServiceCode IMAP2_allSpeechFollowedByDataCDA;

extern IMAP2_BearerServiceCode IMAP2_allSpeechFollowedByDataCDS;

// The following non-hierarchical Compound Bearer Service
// Groups are defined in TS GSM 02.30:
extern IMAP2_BearerServiceCode IMAP2_allDataCircuitAsynchronous;

	// covers "allDataCDA-Services", "allAlternateSpeech-DataCDA" and
	// "allSpeechFollowedByDataCDA"
extern IMAP2_BearerServiceCode IMAP2_allAsynchronousServices;

	// covers "allDataCDA-Services", "allAlternateSpeech-DataCDA",
	// "allSpeechFollowedByDataCDA" and "allPadAccessCDA-Services"
extern IMAP2_BearerServiceCode IMAP2_allDataCircuitSynchronous;

	// covers "allDataCDS-Services", "allAlternateSpeech-DataCDS" and
	// "allSpeechFollowedByDataCDS"
extern IMAP2_BearerServiceCode IMAP2_allSynchronousServices;

	// covers "allDataCDS-Services", "allAlternateSpeech-DataCDS",
	// "allSpeechFollowedByDataCDS" and "allDataPDS-Services"
//
extern IMAP2_BearerServiceCode IMAP2_allPLMN_specificBS;

extern IMAP2_BearerServiceCode IMAP2_plmn_specificBS_1;

extern IMAP2_BearerServiceCode IMAP2_plmn_specificBS_2;

extern IMAP2_BearerServiceCode IMAP2_plmn_specificBS_3;

extern IMAP2_BearerServiceCode IMAP2_plmn_specificBS_4;

extern IMAP2_BearerServiceCode IMAP2_plmn_specificBS_5;

extern IMAP2_BearerServiceCode IMAP2_plmn_specificBS_6;

extern IMAP2_BearerServiceCode IMAP2_plmn_specificBS_7;

extern IMAP2_BearerServiceCode IMAP2_plmn_specificBS_8;

extern IMAP2_BearerServiceCode IMAP2_plmn_specificBS_9;

extern IMAP2_BearerServiceCode IMAP2_plmn_specificBS_A;

extern IMAP2_BearerServiceCode IMAP2_plmn_specificBS_B;

extern IMAP2_BearerServiceCode IMAP2_plmn_specificBS_C;

extern IMAP2_BearerServiceCode IMAP2_plmn_specificBS_D;

extern IMAP2_BearerServiceCode IMAP2_plmn_specificBS_E;

extern IMAP2_BearerServiceCode IMAP2_plmn_specificBS_F;

	// This type is used to represent the code identifying a single
	// supplementary service, a group of supplementary services, or
	// all supplementary services. The services and abbreviations
	// used are defined in TS GSM 02.04. The internal structure is
	// defined as follows:
	//
	// bits 87654321: group (bits 8765), and specific service
	// (bits 4321)
extern IMAP2_SS_Code IMAP2_allSS;

	// reserved for possible future use
	// all SS
extern IMAP2_SS_Code IMAP2_allLineIdentificationSS;

	// reserved for possible future use
	// all line identification SS
extern IMAP2_SS_Code IMAP2_clip;

	// calling line identification presentation
extern IMAP2_SS_Code IMAP2_clir;

	// calling line identification restriction
extern IMAP2_SS_Code IMAP2_colp;

	// connected line identification presentation
extern IMAP2_SS_Code IMAP2_colr;

	// connected line identification restriction
extern IMAP2_SS_Code IMAP2_mci;

	// reserved for possible future use
	// malicious call identification
extern IMAP2_SS_Code IMAP2_allNameIdentificationSS;

	// all name identification SS
extern IMAP2_SS_Code IMAP2_cnap;

	// calling name presentation

	// SS-Codes '00011010'B to '00011111'B are reserved for future 
	// NameIdentification Supplementary Service use.
extern IMAP2_SS_Code IMAP2_allForwardingSS;

	// all forwarding SS
extern IMAP2_SS_Code IMAP2_cfu;

	// call forwarding unconditional
extern IMAP2_SS_Code IMAP2_allCondForwardingSS;

	// all conditional forwarding SS
extern IMAP2_SS_Code IMAP2_cfb;

	// call forwarding on mobile subscriber busy
extern IMAP2_SS_Code IMAP2_cfnry;

	// call forwarding on no reply
extern IMAP2_SS_Code IMAP2_cfnrc;

	// call forwarding on mobile subscriber not reachable 
extern IMAP2_SS_Code IMAP2_cd;

	// call deflection
extern IMAP2_SS_Code IMAP2_allCallOfferingSS;

	// reserved for possible future use
	// all call offering SS includes also all forwarding SS
extern IMAP2_SS_Code IMAP2_ect;

		// explicit call transfer
extern IMAP2_SS_Code IMAP2_mah;

	// reserved for possible future use
	// mobile access hunting
extern IMAP2_SS_Code IMAP2_allCallCompletionSS;

	// reserved for possible future use
	// all Call completion SS
extern IMAP2_SS_Code IMAP2_cw;

	// call waiting
extern IMAP2_SS_Code IMAP2_hold;

	// call hold
extern IMAP2_SS_Code IMAP2_ccbs_A;

	// completion of call to busy subscribers, originating side
extern IMAP2_SS_Code IMAP2_ccbs_B;

	// completion of call to busy subscribers, destination side
	// this SS-Code is used only in InsertSubscriberData
extern IMAP2_SS_Code IMAP2_allMultiPartySS;

	// reserved for possible future use
	// all multiparty SS
extern IMAP2_SS_Code IMAP2_multiPTY;

	// multiparty
extern IMAP2_SS_Code IMAP2_allCommunityOfInterest_SS;

	// reserved for possible future use
	// all community of interest SS
extern IMAP2_SS_Code IMAP2_cug;

	// closed user group
extern IMAP2_SS_Code IMAP2_allChargingSS;

	// reserved for possible future use
	// all charging SS
extern IMAP2_SS_Code IMAP2_aoci;

	// advice of charge information
extern IMAP2_SS_Code IMAP2_aocc;

	// advice of charge charging
extern IMAP2_SS_Code IMAP2_allAdditionalInfoTransferSS;

	// reserved for possible future use
	// all additional information transfer SS
extern IMAP2_SS_Code IMAP2_uus;

	// reserved for possible future use
	// UUS user-to-user signalling
extern IMAP2_SS_Code IMAP2_allBarringSS;

	// all barring SS
extern IMAP2_SS_Code IMAP2_barringOfOutgoingCalls;

	// barring of outgoing calls
extern IMAP2_SS_Code IMAP2_baoc;

	// barring of all outgoing calls
extern IMAP2_SS_Code IMAP2_boic;

	// barring of outgoing international calls
extern IMAP2_SS_Code IMAP2_boicExHC;

	// barring of outgoing international calls except those directed
	// to the home PLMN
extern IMAP2_SS_Code IMAP2_barringOfIncomingCalls;

	// barring of incoming calls
extern IMAP2_SS_Code IMAP2_baic;

	// barring of all incoming calls
extern IMAP2_SS_Code IMAP2_bicRoam;

	// barring of incoming calls when roaming outside home PLMN
	// Country
extern IMAP2_SS_Code IMAP2_allPLMN_specificSS;

extern IMAP2_SS_Code IMAP2_plmn_specificSS_1;

extern IMAP2_SS_Code IMAP2_plmn_specificSS_2;

extern IMAP2_SS_Code IMAP2_plmn_specificSS_3;

extern IMAP2_SS_Code IMAP2_plmn_specificSS_4;

extern IMAP2_SS_Code IMAP2_plmn_specificSS_5;

extern IMAP2_SS_Code IMAP2_plmn_specificSS_6;

extern IMAP2_SS_Code IMAP2_plmn_specificSS_7;

extern IMAP2_SS_Code IMAP2_plmn_specificSS_8;

extern IMAP2_SS_Code IMAP2_plmn_specificSS_9;

extern IMAP2_SS_Code IMAP2_plmn_specificSS_A;

extern IMAP2_SS_Code IMAP2_plmn_specificSS_B;

extern IMAP2_SS_Code IMAP2_plmn_specificSS_C;

extern IMAP2_SS_Code IMAP2_plmn_specificSS_D;

extern IMAP2_SS_Code IMAP2_plmn_specificSS_E;

extern IMAP2_SS_Code IMAP2_plmn_specificSS_F;

extern IMAP2_SS_Code IMAP2_allCallPrioritySS;

	// reserved for possible future use
	// all call priority SS
extern IMAP2_SS_Code IMAP2_emlpp;
	// enhanced Multilevel Precedence Pre-emption (EMLPP) service

extern const int IMAP2_SS_DataTypes_maxNumOfCUG;

extern const int IMAP2_maxNumOfCCBS_Requests;

	// The structure of the contents of the USSD-String is dependent
	// on the USSD-DataCodingScheme as described in TS GSM 03.38.
extern const int IMAP2_maxUSSD_StringLength;

extern const int IMAP2_maxNumOfSS;

extern const int IMAP2_maxNumOfBasicServiceGroups;

extern const int IMAP2_maxEventSpecification;

	// This type is used to represent a number for addressing
	// purposes. It is composed of
	//	a)	one octet for nature of address, and numbering plan
	//		indicator.
	//	b)	digits of an address encoded as TBCD-String.

	// a)	The first octet includes a one bit extension indicator, a
	//		3 bits nature of address indicator and a 4 bits numbering
	//		plan indicator, encoded as follows:

	// bit 8: 1  (no extension)

	// bits 765: nature of address indicator
	//	000  unknown
	//	001  international number
	//	010  national significant number
	//	011  network specific number
	//	100  subscriber number
	//	101  reserved
	//	110  abbreviated number
	//	111  reserved for extension

	// bits 4321: numbering plan indicator
	//	0000  unknown
	//	0001  ISDN/Telephony Numbering Plan (Rec CCITT E.164)
	//	0010  spare
	//	0011  data numbering plan (CCITT Rec X.121)
	//	0100  telex numbering plan (CCITT Rec F.69)
	//	0101  spare
	//	0110  land mobile numbering plan (CCITT Rec E.212)
	//	0111  spare
	//	1000  national numbering plan
	//	1001  private numbering plan
	//	1111  reserved for extension

	//	all other values are reserved.

	// b)	The following octets representing digits of an address
	//		encoded as a TBCD-STRING.
extern const int IMAP2_maxAddressLength;

	// This type is used to represent ISDN numbers.
extern const int IMAP2_maxISDN_AddressLength;

      // This type is used to represent forwarded-to numbers.
      // For long forwarded-to numbers (longer than 15 digits) NPI shall be unknown;
      // if NAI = international the first digits represent the country code (CC)
      // and the network destination code (NDC) as for E.164.
extern const int IMAP2_maxFTN_AddressLength;

	// This type is used to represent ISDN subaddresses.
	// It is composed of
	//	a)	one octet for type of subaddress and odd/even indicator.
	//	b)	20 octets for subaddress information.

	//	a)	The first octet includes a one bit extension indicator, a
	//		3 bits type of subaddress and a one bit odd/even indicator,
	//		encoded as follows:

	//	bit 8: 1  (no extension)

	//	bits 765: type of subaddress
	//		000  NSAP (X.213/ISO 8348 AD2)
	//		010  User Specified
	//		All other values are reserved

	//	bit 4: odd/even indicator
	//		0  even number of address signals
	//		1  odd number of address signals
	//		The odd/even indicator is used when the type of subaddress
	//		is "user specified" and the coding is BCD.

	//	bits 321: 000 (unused)

	//	b) Subaddress information.
	//	The NSAP X.213/ISO8348AD2 address shall be formatted as specified
	//	by octet 4 which contains the Authority and Format Identifier
	//	(AFI). The encoding is made according to the "preferred binary
	//	encoding" as defined in X.213/ISO834AD2. For the definition
	//	of this type of subaddress, see CCITT Rec I.334.

	//	For User-specific subaddress, this field is encoded according
	//	to the user specification, subject to a maximum length of 20
	//	octets. When interworking with X.25 networks BCD coding should
	//	be applied.
extern const int IMAP2_maxISDN_SubaddressLength;

extern const int IMAP2_maxSignalInfoLength;

	// This type is used to represent Alerting Pattern

	//	bits 8765 : 0000 (unused)

	//	bits 43 : type of Pattern
	//		00 level
	//		01 category
	//		10 category
	//		all other values are reserved.

	//	bits 21 : type of alerting
extern IMAP2_AlertingPattern IMAP2_alertingLevel_0;

extern IMAP2_AlertingPattern IMAP2_alertingLevel_1;

extern IMAP2_AlertingPattern IMAP2_alertingLevel_2;

	// all other values of Alerting level are reserved
	// Alerting Levels are defined in GSM 02.07
extern IMAP2_AlertingPattern IMAP2_alertingCategory_1;

extern IMAP2_AlertingPattern IMAP2_alertingCategory_2;

extern IMAP2_AlertingPattern IMAP2_alertingCategory_3;

extern IMAP2_AlertingPattern IMAP2_alertingCategory_4;

extern IMAP2_AlertingPattern IMAP2_alertingCategory_5;

extern const int IMAP2_maxNumOfHLR_Id;

extern const int IMAP2_maxNumOfMC_Bearers;

extern const IMAP2_EMLPP_Priority IMAP2_priorityLevelA;

extern const IMAP2_EMLPP_Priority IMAP2_priorityLevelB;

extern const IMAP2_EMLPP_Priority IMAP2_priorityLevel0;

extern const IMAP2_EMLPP_Priority IMAP2_priorityLevel1;

extern const IMAP2_EMLPP_Priority IMAP2_priorityLevel2;

extern const IMAP2_EMLPP_Priority IMAP2_priorityLevel3;

extern const IMAP2_EMLPP_Priority IMAP2_priorityLevel4;

extern const int IMAP2_maxNumOfBearerServices;

extern const int IMAP2_maxNumOfTeleservices;

extern const int IMAP2_MS_DataTypes_maxNumOfCUG;

extern const int IMAP2_maxNumOfExt_BasicServiceGroups;

	// internal structure is defined in TS GSM 03.03
extern const int IMAP2_maxNumOfZoneCodes;

extern const int IMAP2_maxNumOfBasicServices;

extern const int IMAP2_maxNumOfVBSGroupIds;

extern const int IMAP2_maxNumOfVGCSGroupIds;

	// This type is used to represent the code identifying a single
	// teleservice, a group of teleservices, or all teleservices. The
	// services are defined in TS GSM 02.03.
	// The internal structure is defined as follows:

	// OCTET 1:
	// bits 87654321: group (bits 8765) and specific service
	// (bits 4321)

	// OCTETS 2-5: reserved for future use. If received the
    // Ext-TeleserviceCode shall be
 	// treated according to the exception handling defined for the
	// operation that uses this type.

	// Ext-TeleserviceCode includes all values defined for TeleserviceCode.
extern IMAP2_TeleserviceCode IMAP2_allTeleservices;

extern IMAP2_TeleserviceCode IMAP2_allSpeechTransmissionServices;

extern IMAP2_TeleserviceCode IMAP2_telephony;

extern IMAP2_TeleserviceCode IMAP2_emergencyCalls;

extern IMAP2_TeleserviceCode IMAP2_allShortMessageServices;

extern IMAP2_TeleserviceCode IMAP2_shortMessageMT_PP;

extern IMAP2_TeleserviceCode IMAP2_shortMessageMO_PP;

extern IMAP2_TeleserviceCode IMAP2_allFacsimileTransmissionServices;

extern IMAP2_TeleserviceCode IMAP2_facsimileGroup3AndAlterSpeech;

extern IMAP2_TeleserviceCode IMAP2_automaticFacsimileGroup3;

extern IMAP2_TeleserviceCode IMAP2_facsimileGroup4;

// The following non-hierarchical Compound Teleservice Groups
// are defined in TS GSM 02.30:
extern IMAP2_TeleserviceCode IMAP2_allDataTeleservices;

	// covers Teleservice Groups 'allFacsimileTransmissionServices'
	// and 'allShortMessageServices'
extern IMAP2_TeleserviceCode IMAP2_allTeleservices_ExeptSMS;

	// covers Teleservice Groups 'allSpeechTransmissionServices' and
	// 'allFacsimileTransmissionServices'
//
// Compound Teleservice Group Codes are only used in call
// independent supplementary service operations, i.e. they
// are not used in InsertSubscriberData or in
// DeleteSubscriberData messages.
extern IMAP2_TeleserviceCode IMAP2_allVoiceGroupCallServices;

extern IMAP2_TeleserviceCode IMAP2_voiceGroupCall;

extern IMAP2_TeleserviceCode IMAP2_voiceBroadcastCall;

extern IMAP2_TeleserviceCode IMAP2_allPLMN_specificTS;

extern IMAP2_TeleserviceCode IMAP2_plmn_specificTS_1;

extern IMAP2_TeleserviceCode IMAP2_plmn_specificTS_2;

extern IMAP2_TeleserviceCode IMAP2_plmn_specificTS_3;

extern IMAP2_TeleserviceCode IMAP2_plmn_specificTS_4;

extern IMAP2_TeleserviceCode IMAP2_plmn_specificTS_5;

extern IMAP2_TeleserviceCode IMAP2_plmn_specificTS_6;

extern IMAP2_TeleserviceCode IMAP2_plmn_specificTS_7;

extern IMAP2_TeleserviceCode IMAP2_plmn_specificTS_8;

extern IMAP2_TeleserviceCode IMAP2_plmn_specificTS_9;

extern IMAP2_TeleserviceCode IMAP2_plmn_specificTS_A;

extern IMAP2_TeleserviceCode IMAP2_plmn_specificTS_B;

extern IMAP2_TeleserviceCode IMAP2_plmn_specificTS_C;

extern IMAP2_TeleserviceCode IMAP2_plmn_specificTS_D;

extern IMAP2_TeleserviceCode IMAP2_plmn_specificTS_E;

extern IMAP2_TeleserviceCode IMAP2_plmn_specificTS_F;

extern IMAP2__ObjectID IMAP2_map_DialogueAS;

// location registration operation codes
extern IMAP2_UpdateLocation IMAP2_updateLocation;

extern IMAP2_CancelLocation IMAP2_cancelLocation;

extern IMAP2_PurgeMS IMAP2_purgeMS;

extern IMAP2_SendIdentification IMAP2_sendIdentification;

// handover operation codes
extern IMAP2_PrepareHandover IMAP2_prepareHandover;

extern IMAP2_SendEndSignal IMAP2_sendEndSignal;

extern IMAP2_ProcessAccessSignalling IMAP2_processAccessSignalling;

extern IMAP2_ForwardAccessSignalling IMAP2_forwardAccessSignalling;

extern IMAP2_PrepareSubsequentHandover IMAP2_prepareSubsequentHandover;

// authentication operation codes
extern IMAP2_SendAuthenticationInfo IMAP2_sendAuthenticationInfo;

// IMEI MANAGEMENT operation codes
extern IMAP2_CheckIMEI IMAP2_checkIMEI;

// subscriber management operation codes
extern IMAP2_InsertSubscriberData IMAP2_insertSubscriberData;

extern IMAP2_DeleteSubscriberData IMAP2_deleteSubscriberData;

extern IMAP2_Reset IMAP2_reset;

extern IMAP2_RestoreData IMAP2_restoreData;

// operation and maintenance operation codes
extern IMAP2_ActivateTraceMode IMAP2_activateTraceMode;

extern IMAP2_DeactivateTraceMode IMAP2_deactivateTraceMode;

extern IMAP2_SendIMSI IMAP2_sendIMSI;

// call handling operation codes
extern IMAP2_SendRoutingInfo IMAP2_sendRoutingInfo;

extern IMAP2_ProvideRoamingNumber IMAP2_provideRoamingNumber;

extern IMAP2_ResumeCallHandling IMAP2_resumeCallHandling;

extern IMAP2_ProvideSIWFSNumber IMAP2_provideSIWFSNumber;

extern IMAP2_SIWFSSignallingModify IMAP2_sIWFSSignallingModify;

// supplementary service handling operation codes
extern IMAP2_RegisterSS IMAP2_registerSS;

extern IMAP2_EraseSS IMAP2_eraseSS;

extern IMAP2_ActivateSS IMAP2_activateSS;

extern IMAP2_DeactivateSS IMAP2_deactivateSS;

extern IMAP2_InterrogateSS IMAP2_interrogateSS;

extern IMAP2_ProcessUnstructuredSS_Request IMAP2_processUnstructuredSS_Request;

extern IMAP2_UnstructuredSS_Request IMAP2_unstructuredSS_Request;

extern IMAP2_UnstructuredSS_Notify IMAP2_unstructuredSS_Notify;

extern IMAP2_RegisterPassword IMAP2_registerPassword;

extern IMAP2_GetPassword IMAP2_getPassword;

// short message service operation codes
extern IMAP2_SendRoutingInfoForSM IMAP2_sendRoutingInfoForSM;

extern IMAP2_MO_ForwardSM IMAP2_mo_forwardSM;

extern IMAP2_MT_ForwardSM IMAP2_mt_forwardSM;

extern IMAP2_ReportSM_DeliveryStatus IMAP2_reportSM_DeliveryStatus;

extern IMAP2_InformServiceCentre IMAP2_informServiceCentre;

extern IMAP2_AlertServiceCentre IMAP2_alertServiceCentre;

extern IMAP2_ReadyForSM IMAP2_readyForSM;

//Group Call operation codes
extern IMAP2_PrepareGroupCall IMAP2_prepareGroupCall;

extern IMAP2_SendGroupCallEndSignal IMAP2_sendGroupCallEndSignal;

extern IMAP2_ProcessGroupCallSignalling IMAP2_processGroupCallSignalling;

extern IMAP2_ForwardGroupCallSignalling IMAP2_forwardGroupCallSignalling;

// generic error codes
extern IMAP2_SystemFailure IMAP2_systemFailure;

extern IMAP2_DataMissing IMAP2_dataMissing;

extern IMAP2_UnexpectedDataValue IMAP2_unexpectedDataValue;

extern IMAP2_FacilityNotSupported IMAP2_facilityNotSupported;

extern IMAP2_IncompatibleTerminal IMAP2_incompatibleTerminal;

extern IMAP2_ResourceLimitation IMAP2_resourceLimitation;

// identification and numbering error codes
extern IMAP2_UnknownSubscriber IMAP2_unknownSubscriber;

extern IMAP2_NumberChanged IMAP2_numberChanged;

extern IMAP2_UnknownMSC IMAP2_unknownMSC;

extern IMAP2_UnidentifiedSubscriber IMAP2_unidentifiedSubscriber;

extern IMAP2_UnknownEquipment IMAP2_unknownEquipment;

// subscription error codes
extern IMAP2_RoamingNotAllowed IMAP2_roamingNotAllowed;

extern IMAP2_IllegalSubscriber IMAP2_illegalSubscriber;

extern IMAP2_IllegalEquipment IMAP2_illegalEquipment;

extern IMAP2_BearerServiceNotProvisioned IMAP2_bearerServiceNotProvisioned;

extern IMAP2_TeleserviceNotProvisioned IMAP2_teleserviceNotProvisioned;

// handover error codes
extern IMAP2_NoHandoverNumberAvailable IMAP2_noHandoverNumberAvailable;

extern IMAP2_SubsequentHandoverFailure IMAP2_subsequentHandoverFailure;

// operation and maintenance error codes
extern IMAP2_TracingBufferFull IMAP2_tracingBufferFull;

// call handling error codes
extern IMAP2_NoRoamingNumberAvailable IMAP2_noRoamingNumberAvailable;

extern IMAP2_AbsentSubscriber IMAP2_absentSubscriber;

extern IMAP2_BusySubscriber IMAP2_busySubscriber;

extern IMAP2_NoSubscriberReply IMAP2_noSubscriberReply;

extern IMAP2_CallBarred IMAP2_callBarred;

extern IMAP2_ForwardingFailed IMAP2_forwardingFailed;

extern IMAP2_OR_NotAllowed IMAP2_or_NotAllowed;

extern IMAP2_ForwardingViolation IMAP2_forwardingViolation;

extern IMAP2_CUG_Reject IMAP2_cug_Reject;

// any time interrogation error codes
extern IMAP2_ATI_NotAllowed IMAP2_ati_NotAllowed;

// Group Call error codes
extern IMAP2_NoGroupCallNumberAvailable IMAP2_noGroupCallNumberAvailable;

// supplementary service error codes
extern IMAP2_IllegalSS_Operation IMAP2_illegalSS_Operation;

extern IMAP2_SS_ErrorStatus IMAP2_ss_ErrorStatus;

extern IMAP2_SS_NotAvailable IMAP2_ss_NotAvailable;

extern IMAP2_SS_SubscriptionViolation IMAP2_ss_SubscriptionViolation;

extern IMAP2_SS_Incompatibility IMAP2_ss_Incompatibility;

extern IMAP2_UnknownAlphabet IMAP2_unknownAlphabet;

extern IMAP2_USSD_Busy IMAP2_ussd_Busy;

extern IMAP2_PW_RegistrationFailure IMAP2_pw_RegistrationFailure;

extern IMAP2_NegativePW_Check IMAP2_negativePW_Check;

extern IMAP2_NumberOfPW_AttemptsViolation IMAP2_numberOfPW_AttemptsViolation;

extern IMAP2_ShortTermDenial IMAP2_shortTermDenial;

extern IMAP2_LongTermDenial IMAP2_longTermDenial;

// short message service error codes
extern IMAP2_SubscriberBusyForMT_SMS IMAP2_subscriberBusyForMT_SMS;

extern IMAP2_SM_DeliveryFailure IMAP2_sm_DeliveryFailure;

extern IMAP2_MessageWaitingListFull IMAP2_messageWaitingListFull;

extern IMAP2_AbsentSubscriberSM IMAP2_absentsubscriberSM;
// The following operation codes are reserved for operations
// existing in previous versions of the protocol

// Operation Name	AC used	Oper. Code
// 
// sendParameters	map-ac infoRetrieval (14) version1 (1)	localValue 9
// processUnstructuredSS-Data	map-ac networkFunctionalSs (18) version1 (1)	localValue 19
// performHandover	map-ac handoverControl (11) version1 (1)	localValue 28
// performSubsequentHandover	map-ac handoverControl (11) version1 (1)	localValue 30
// noteInternalHandover	map-ac handoverControl (11) version1 (1)	localValue 35
// alertServiceCentreWithoutResult	map-ac shortMsgAlert (23) version1 (1)	localValue 49
// traceSubscriberActivity	map-ac handoverControl (11) version1 (1)	localValue 52
// beginSubscriberActivity	map-ac networkFunctionalSs (18) version1 (1)	localValue 54

// The following error codes are reserved for errors
// existing in previous versions of the protocol

// Error Name	AC used	Error Code
// 
// unknownBaseStation	map-ac handoverControl (11) version1 (1)	localValue 2
// invalidTargetBaseStation	map-ac handoverControl (11) version1 (1)	localValue 23
// noRadioResourceAvailable	map-ac handoverControl (11) version1 (1)	localValue 24

#endif  /* #ifndef _OSSNOVALUES */


extern void *IMAP2;    /* encoder-decoder control table */
#ifdef __cplusplus
}	/* extern "C" */
#endif /* __cplusplus */
#endif /* OSS_IMAP2 */
