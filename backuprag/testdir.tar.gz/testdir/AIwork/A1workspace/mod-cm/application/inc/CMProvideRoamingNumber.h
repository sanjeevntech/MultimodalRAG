#ifndef __CONTEXT_PROVIDE_ROAMING_NUMBER_H
#define __CONTEXT_PROVIDE_ROAMING_NUMBER_H

#include <ContextBase.h>
#include <Msg.h>
#include <ServiceCoordinator.h>


class CtxtProvideRoamingNumber : public ContextBase
{
   private:
      bool sendv3Prn();
      bool sendv2Prn();
      bool sendv1Prn();

   public:
      CtxtProvideRoamingNumber();
      ~CtxtProvideRoamingNumber();

      bool updateDb(char, char *);
      bool updatePrnMnrfDb();

      bool processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag);
      bool startProcessing(InterModuleData *p_imd, bool& p_DeleteFlag);
      char m_Imsi[20+1];

      char m_TransId[20+1];
      string m_DataString;
      int m_UserDlgId;
      EMapVersion m_sentPrnVer;
};



#endif
