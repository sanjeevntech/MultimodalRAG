#ifndef _CtxtVlrPSIRes_H_
#define  _CtxtVlrPSIRes_H__

#include <ContextBase.h>
#include <Msg.h>
#include <IMAP3.h>
#include <OMAP3.h>
#include <MapConstants.h>


class CtxtVlrPSIRes : public ContextBase
{ 
   private:
      int m_PsiDlgId;

   public:
      CtxtVlrPSIRes();
      bool processMessage(Msg *p_MsgPtr,bool& p_DeleteFlag);
      bool sendPSIRes();
      bool sendMapUserError(int p_dlgId,EMapErrorCode p_ErrCode,EMapVersion p_ver);
      virtual ~CtxtVlrPSIRes();
};

#endif //_CtxtVlrPSIRes_H__
