#ifndef _CtxtSimSendRoutingInfo_H_
#define _CtxtSimSendRoutingInfo_H_
  
#include <ContextBase.h>
#include <Msg.h>
#include <MapConstants.h>
#include <CMSimConfigReader.h>
  
  
  class CtxtSimSendRoutingInfo: public ContextBase
  {
     private:
        int m_psiPrnFlag;
 
     public:
        CtxtSimSendRoutingInfo();
        bool processMessage(Msg *p_MsgPtr,bool& p_DeleteFlag);
        bool startProcessing();
        bool sendSRIReq();
        bool sendPRNRes();
        virtual ~CtxtSimSendRoutingInfo();
  };
 
  #endif //_CtxtSimSendRoutingInfo_H__

