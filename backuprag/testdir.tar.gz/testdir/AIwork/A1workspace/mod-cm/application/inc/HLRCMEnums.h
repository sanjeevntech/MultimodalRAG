#ifndef _HLRCMENUMS_H_
#define _HLRCMENUMS_H_

typedef enum 
{
   CM_FAIL=0,
   CM_CONTINUE,
   CM_ERROR
}EResult;


typedef enum 
{
   CM_BasicISTSupported = 0,
   CM_IstCommandSupported = 1
}ESupportIndicator;

typedef enum 
{
   CM_NONE = 0,
   CM_O_CSI,
   CM_T_CSI,
   CM_VT_CSI,
   CM_SMS_CSI,
   CM_GPRS_CSI,
   CM_D_CSI
}ECsiType ;


typedef enum
{
   CM_NOT_ROAMING = 0,
   CM_ROAMING_OUTOFHPLMN,
   CM_ROAMING_INTERNATIIONAL
}ERoamingStatus;


// SS Codes
typedef enum
{
   CM_SS_ALL                     = 0x00,	//0

   CM_SS_ALL_LINE_ID             = 0x10,	//16
   CM_SS_CLIP                    = 0x11,	//17
   CM_SS_CLIR                    = 0x12,	//18
   CM_SS_COLP                    = 0x13,	//19
   CM_SS_COLR                    = 0x14,	//20
   CM_SS_MCI                     = 0x15,	//21

   CM_SS_ALL_NAME_ID             = 0x18,	//24
   CM_SS_CNAP                    = 0x19,	//25

   CM_SS_ALL_FORWARDING          = 0x20,	//32
   CM_SS_CFU                     = 0x21,	//33
   CM_SS_ALL_COND_FORWARDING     = 0x28,	//40
   CM_SS_CFB                     = 0x29,	//41
   CM_SS_CFNRY                   = 0x2A,	//42
   CM_SS_CFNRC                   = 0x2B,	//43

   CM_SS_CD                      = 0x24,	//36

   CM_SS_ALL_CALL_OFFERING       = 0x30,	//48
   CM_SS_ECT                     = 0x31,	//49
   CM_SS_MAH                     = 0x32,	//50

   CM_SS_ALL_CALL_COMPLETION     = 0x40,	//64
   CM_SS_CW                      = 0x41,	//65
   CM_SS_HOLD                    = 0x42,	//66
   CM_SS_CCBS_A                  = 0x43,	//67
   CM_SS_CCBS_B                  = 0x44,	//68
   CM_SS_MC                      = 0x45,	//69

   CM_SS_ALL_MULTI_PARTY         = 0x50,	//80
   CM_SS_MPTY                    = 0x51,	//81

   CM_SS_ALL_COMMUNITY_INTERST   = 0x60,	//96
   CM_SS_CUG                     = 0x61,	//97	

   CM_SS_ALL_CHARGING            = 0x70,	//112
   CM_SS_AOCI                    = 0x71,	//113
   CM_SS_AOCC                    = 0x72,	//114

   CM_SS_ALL_INFO_TRANSFER       = 0x80,	//128
   CM_SS_UUS1                    = 0x81,	//129
   CM_SS_UUS2                    = 0x82,	//130	
   CM_SS_UUS3                    = 0x83,	//131

   CM_SS_ALL_BARRING             = 0x90,	//144
   CM_SS_BARRING_OUTGOING_CALL   = 0x91,	//145
   CM_SS_BAOC                    = 0x92,	//146
   CM_SS_BOIC                    = 0x93,	//147
   CM_SS_BOIC_EXHC               = 0x94,	//148
   CM_SS_BARRING_INCOMING_CALL   = 0x99,	//153
   CM_SS_BAIC                    = 0x9A,	//154
   CM_SS_BIC_ROAM                = 0x9B,	//155

   CM_SS_ALL_CALL_PRIORITY       = 0xA0,	//160
   CM_SS_EMLPP                   = 0xA1,	//161

   CM_SS_ALL_LCS_PRIVACY_EX      = 0xB0,	//176
   CM_SS_UNIVERSAL               = 0xB1,	//177
   CM_SS_CALL_RELATED            = 0xB2,	//178
   CM_SS_CALL_UNRELATED          = 0xB3,	//179
   CM_SS_PLMN_OPERATOR           = 0xB4,	//180

   CM_SS_ALL_MOLR                = 0xC0,	//192
   CM_SS_BASIC_SELF_LOCATION     = 0xC1,	//193
   CM_SS_AUTO_SELF_LOCATION      = 0xC2,	//194
   CM_SS_TRANSFER_TO_3RD_PTY     = 0xC3	//195
}ESSCodes;

typedef enum
{
   CM_BSG_ALL                    = 0x0,
   CM_BSG_SPEECH                 = 0x1,
   CM_BSG_SMS                    = 0x2,
   CM_BSG_FAX                    = 0x6,
   CM_BSG_DATA_ASYNCH            = 0x7,
   CM_BSG_DATA_SYNCH             = 0x8,
   CM_BSG_VOICE_GROUP            = 0xC,
   CM_BSG_GPRS                   = 0xD,
   CM_BSGS_FAX_AND_SMS           = 0x65,
   CM_BSGS_SPEECH_AND_FAX        = 0x66,
   CM_BSGS_ALL_TELESRV           = 0x67,
   CM_BSGS_ALL_BEARER_SRV        = 0x68

}EBasicServiceGroupCodes;

typedef enum
{
   CM_BEARER_SERVICE_TYPE        = 1,
   CM_TELESERVICE_TYPE           = 2
} EBasicServiceType;

typedef enum
{
   CM_TS_ALL                     = 0x00,

   CM_TS_ALL_SPEECH              = 0x10,
   CM_TS_TELEPHONY               = 0x11,
   CM_TS_EMERGENCY               = 0x12,

   CM_TS_ALL_SMS                 = 0x20,
   CM_TS_SMS_MT                  = 0x21,
   CM_TS_SMS_MO                  = 0x22,

   CM_TS_ALL_FAX                 = 0x60,
   CM_TS_FAX3_AND_ALTER_SPEECH   = 0x61,
   CM_TS_AUTO_FAX3               = 0x62,
   CM_TS_FAX4                    = 0x63,

   CM_TS_ALL_DATA_TS             = 0x70,//COMPOUND TELESERVICE GROUPS	
   CM_TS_ALL_EXEPT_SMS           = 0x80,//COMPOUND TELESERVICE GROUPS

   CM_TS_ALL_VOICE_GROUP         = 0x90,
   CM_TS_VOICE_GROUP             = 0x91,
   CM_TS_VOICE_BROADCAST         = 0x92,

   CM_TS_ALL_PLMN_SPECIFIC       = 0xD0
} ETeleServiceCode;

typedef enum
{
   CM_BS_ALL                     = 0x00,

   CM_BS_ALL_DATA_CDA            = 0x10,
   CM_BS_DATA_CDA_300            = 0x11,
   CM_BS_DATA_CDA_1200           = 0x12,
   CM_BS_DATA_CDA_1200_75        = 0x13,
   CM_BS_DATA_CDA_2400           = 0x14,
   CM_BS_DATA_CDA_4800           = 0x15,
   CM_BS_DATA_CDA_9600           = 0x16,
   CM_BS_GENERAL_DATA_CDA        = 0x17,

   CM_BS_ALL_DATA_CDS            = 0x18,
   CM_BS_DATA_CDS_1200           = 0x1A,
   CM_BS_DATA_CDS_2400           = 0x1C,
   CM_BS_DATA_CDS_4800           = 0x1D,
   CM_BS_DATA_CDS_9600           = 0x1E,
   CM_BS_GENERAL_DATA_CDS        = 0x1F,

   CM_BS_ALL_PAD_ACCESS_CA       = 0x20,
   CM_BS_PAD_ACCESS_CA_300       = 0x21,
   CM_BS_PAD_ACCESS_CA_1200      = 0x22,
   CM_BS_PAD_ACCESS_CA_1200_75   = 0x23,
   CM_BS_PAD_ACCESS_CA_2400      = 0x24,
   CM_BS_PAD_ACCESS_CA_4800      = 0x25,
   CM_BS_PAD_ACCESS_CA_9600      = 0x26,
   CM_BS_GENERAL_PAD_ACCESS_CA   = 0x27,

   CM_BS_ALL_DATA_PDS            = 0x28,
   CM_BS_DATA_PDS_2400           = 0x2C,
   CM_BS_DATA_PDS_4800           = 0x2D,
   CM_BS_DATA_PDS_9600           = 0x2E,
   CM_BS_GENERAL_DATA_PDS        = 0x2F,

   CM_BS_ALL_ALT_SPEECH_CDA      = 0x30,
   CM_BS_ALL_ALT_SPEECH_CDS      = 0x38,
   CM_BS_ALL_SPEECH_FB_CDA       = 0x40,
   CM_BS_ALL_SPEECH_FB_CDS       = 0x48,

   CM_BS_ALL_DATA_CIRCUIT_ASYN   = 0x50,
   CM_BS_ALL_ASYN                = 0x60,
   CM_BS_ALL_DATA_CIRCUIT_SYN    = 0x58,
   CM_BS_ALL_SYN                 = 0x68,

   CM_BS_ALL_PLMN_SPECIFIC       = 0xD0
} EBearerServiceCode;

////////////// SS-ENUMS END /////////////

#endif  //_HLRCMENUMS_H_
