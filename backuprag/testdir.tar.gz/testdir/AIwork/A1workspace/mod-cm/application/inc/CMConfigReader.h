#ifndef _CM_CONFIG_READER_H_
#define _CM_CONFIG_READER_H_

#include "CMEnums.h"
#include <UniTypes.h>
#include <ConfigReader.h>

class CMConfigReader: public ConfigReader
{
   private:

   public:
      CMConfigReader();
      ~CMConfigReader();

      int m_VlrSSN;
      int m_no_fwd;
      int m_mnrfFlag;
      int m_standalonePrnMnrfFlag;
      int m_prnTimer;
      int m_psiTimer;
      int m_partnerScf;
      int m_callRefNumFlag;
      int m_passSriSGInfoNotFound;
      int m_disableLcsCapb;
      int m_roamingRetrySupportFlag;

      bool readData();
      void printConfigData(char *p_output);
};

extern CMConfigReader *g_CMConfigReaderObj;
extern bool resetStruct(int p_version, int p_pdu, void *p_struct);

#endif //_CM_CONFIG_READER_H_
