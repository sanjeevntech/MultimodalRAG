#ifndef _CMCONSTANTS_H_
#define _CMCONSTANTS_H_

#define CM_CAMELPHASE1                    0x80
#define CM_CAMELPHASE2                    0x40
#define CM_CAMELPHASE3                    0x20
#define CM_CAMELPHASE4                    0x10

#define CM_IMSILEN			               20
#define CM_LMSILEN			               10
#define CM_BCLEN			                  200
#define CM_MSISDNLEN		                  20
#define CM_MSCNUMLEN		                  20
#define CM_VLRNUMLEN		                  20
#define CM_CALLREFNUMLEN                  10
#define CM_GMSCGSMSCFADDRLEN              20

#define CM_COLLECTEDINFO                  2
#define CM_ANALYSEDINFO                   3
#define CM_ROUTESELECTFAILURE             4
#define CM_TERMATTEMPTAUTHORIZED          12
#define CM_TBUSY                          13
#define CM_TNOANSWER                      14

// SUBSCRIBER STATE VALUES
#define CM_ASSUMEDIDLE                    1
#define CM_CAMELBUSY                      2
#define CM_NETDETNOTREACHABLE             3
#define CM_NOTPROVIDEDFROMVLR             4

//GLOBALORSERVICEAREAORLAIID
#define CM_GLOABALORSERVICEIDFIXEDLENGTH  1
#define CM_LAIFIXEDLENGTH                 2

#define CM_FTN_LEN                        21
#define CM_DEF_FTN_LEN                    31
#define CM_FWDSUBADD_LEN                  24 

#define CM_DB_NO_FORWARD                  0
#define CM_DB_FORWARD_UNCONDITIONAL       1
#define CM_DB_FORWARD_NOTREACHABLE        2

#define CM_MAXCCLEN                       5
#define CM_DESTGTLEN                      21

// LCS
#define CM_GMLCLEN                        20
#define CM_SGSNLEN                        20
#define CM_IPADDRLEN                      20

#endif //_CMCONSTANTS_H_
