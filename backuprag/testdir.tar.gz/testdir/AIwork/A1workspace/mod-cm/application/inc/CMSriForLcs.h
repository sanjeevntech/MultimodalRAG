#ifndef _CMSENDROUTINGINFOFORLCS_H_
#define _CMSENDROUTINGINFOFORLCS_H_

#include <Msg.h>
#include <IMAP3.h>
#include <OMAP3.h>
#include "CMUtility.h"
#include "CMDbQueries.h"
#include <ContextBase.h>
#include <MapConstants.h>
#include <HlrTdrFiller.h>
#include "CMConfigReader.h"
#include <SubsProfileData.h>

class CtxtSriForLCS : public ContextBase
{ 
   private:

      u8 m_MlcNumber[CM_GMLCLEN]; 
      u16 m_MlcNumLen;
      u8 m_TargetMS[CM_MSISDNLEN]; 
      u16 m_TargetMSlen;
      u16 m_targetMStype;
      u32 m_InitDlgId;
      EMapVersion m_MapVer;	
      EMapErrorCode m_ErrCode; 

      CMUtility m_Utility;

      SriLCSdata *mp_sriLcs;

   public:

      CtxtSriForLCS();

      EResult checkSriForLCS(void *aSriForLCSReq);
      bool handleError();
      bool handleDbQuery();
      bool sendSriForLCSResp();
      bool processMessage(Msg *aMsgPtr,bool& aDeleteFlag);
      bool handleSriForLCS(Msg *aMsgPtr, u32 aDlgId, EMapVersion aMapVer);
      bool ValidateIpv4(s8* aIpAddr);
      void convertIPV4toHex(s8* aIpV4Addr, u8* aIpAddrInHex);

      virtual ~CtxtSriForLCS();
};

#endif //_CMSENDROUTINGINFOFORLCS_H_
