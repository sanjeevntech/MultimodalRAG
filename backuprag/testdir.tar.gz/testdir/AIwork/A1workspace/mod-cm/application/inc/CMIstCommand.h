#ifndef __CONTEXT_IMMEDIATE_SERVICE_TERMINATION_H
#define __CONTEXT_IMMEDIATE_SERVICE_TERMINATION_H

#include <ContextBase.h>
#include <Msg.h>
#include <ServiceCoordinator.h>


class CtxtIstCommand : public ContextBase
{
   private:
      bool sendv3Ist();

   public:
      CtxtIstCommand();
      ~CtxtIstCommand();

      bool updateDb(char, char *);


      bool processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag);
      bool startProcessing(InterModuleData *p_imd, bool& p_DeleteFlag);

      char m_TransId[20+1];
      string m_DataString;
      int m_UserDlgId;
};



#endif
