#ifndef __CM_SIM_CONFIG_READER_H
#define __CM_SIM_CONFIG_READER_H

#include <ConfigReader.h>
  
   class CMSimConfigReader: public ConfigReader
   {
      private:
  
    public:
        CMSimConfigReader();
        ~CMSimConfigReader();
 
        bool readData();
        void printConfigData(char *p_output);
 
        int m_psiPrn;
        int m_mapVer;
        char m_msisdn[20];
        char m_gmscAdd[20];
        int m_cph;
        int m_nkSigInfo;
        int m_cdiVal;
        int m_MapError;
        int m_TargetMsType;
        char m_TargetMs[20];
        char m_gmlc[20];

  };
  extern CMSimConfigReader *g_CMSimConfigReaderObj;
  extern bool resetStruct(int p_version, int p_pdu, void *p_struct);
  #endif //CM_SIM_CONFIG_READER_H

