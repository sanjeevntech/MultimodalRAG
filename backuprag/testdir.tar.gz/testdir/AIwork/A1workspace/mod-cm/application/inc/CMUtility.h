#ifndef _CMUTILITY_
#define _CMUTILITY_

#include <OMAP3.h>
#include "CMEnums.h"
#include <UniTypes.h>
#include "CMConstants.h"
#include <ContextBase.h>
#include <MapMessages.h>
#include "CMDbQueries.h"

class CMUtility
{
   private:

   public:

      CMUtility();

      s8 m_partnerGsmScfAdd[20];
      u8 getBSGroup(u8 aBSCode, EBasicServiceType aBSType);
      static u16 BCDToChar(u8 *aChar, u8 *aBcd, u16 aBcdLen);
      static u16 CharToBCD(u8 *aBcd,u8 *aChar, u16 aCharLen);
      bool DPSupportedInCamelPhase(u16 aDP, u16 aCamelPhase);
      u16 PrintHex(const s8* str, const s8* buf, const u16 len);
      bool getPartnerGsmScfAddr(s8* aGsmScfAddr, u16 aNkId, u16 aPnkId);
      bool getSuppCamelPhsVmsc(OMAP3_SendRoutingInfoRes *aSRIRes,CMSRIDBdata *aDBdata);
      bool sendSRIRESULTLAST(ContextBase *aCB,u32 aInitDlgId,EMapOpCode aOpCode,EMapVersion aVer,void* aSRIRes);
      bool sendMapUserError(ContextBase *aCB,EMapErrorCode aUserError,u32 aDlgId,EMapVersion aMapVer,void *aErrBuf);
      bool sendSRIRESULTNOTLAST(ContextBase *aCB,u32 aInitDlgId,EMapOpCode aOpCode,EMapVersion aVer,OMAP3_SendRoutingInfoRes* aSRIRes);

      ~CMUtility();
};
#endif //_CMUTILITY_
