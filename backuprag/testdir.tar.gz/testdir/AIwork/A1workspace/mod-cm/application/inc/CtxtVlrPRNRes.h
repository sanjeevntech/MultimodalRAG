#ifndef _CtxtVlrPRNRes_H_
#define  _CtxtVlrPRNRes_H__

#include <ContextBase.h>
#include <Msg.h>
#include <IMAP3.h>
#include <OMAP3.h>
#include <MapConstants.h>

class CtxtVlrPRNRes : public ContextBase
{ 
   private:
      int m_PrnDlgId;

   public:
      CtxtVlrPRNRes();
      bool processMessage(Msg *p_MsgPtr,bool& p_DeleteFlag);
      bool sendPRNRes();
      bool sendMapUserError(int p_dlgId,EMapErrorCode p_ErrCode,EMapVersion p_ver);
      virtual ~CtxtVlrPRNRes();
};

#endif //_CtxtVlrPRNRes_H__
