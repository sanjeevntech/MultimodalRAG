#ifndef _CMSRIDBDATA_H_
#define _CMSRIDBDATA_H_

#include "Logger.h"
#include "CMEnums.h"
#include <UniTypes.h>
#include <DbQueryMsg.h>
#include "CMConstants.h"

typedef struct _CF_BSG
{
   bool m_LongFtnSupported;

   u8 m_Ftn[CM_FTN_LEN];
   u8 m_DefFtn[CM_DEF_FTN_LEN];
   u8 m_fwdToSubAddr[CM_FWDSUBADD_LEN]; 

   u16 m_FtnLen;
   u16 m_DefFtnLen;
   u16 m_fwdOptions;
   u16 m_fwdToSubAddrLen;

}CF_BSG;

class CMSRIDBdata : public DbQueryMsg
{
   private:

      u16   m_MsgType;

   public:

      CMSRIDBdata();


      u8 m_OfferedCamel4CsiVmsc;
      u8 m_SupportedCamelPhaseVmsc;

      u8 m_TeleSrvcCodeArr[32 + 1];
      u8 m_BearSrvcCodeArr[52 + 1];
      u8 m_Lmsi[CM_LMSILEN];
      u8 m_Msisdn[CM_MSISDNLEN];
      u8 m_VlrNum[CM_VLRNUMLEN];
      u8 m_MscNum[CM_MSCNUMLEN];
      u8 m_ActiveImsi[CM_IMSILEN];
      u8 m_PrimaryImsi[CM_IMSILEN];
      u8 m_ActiveMsisdn[CM_MSISDNLEN];
      u8 m_IsrHlrAddr[CM_MSISDNLEN]; // ISR GT for SRI-Res
      u8 m_prnPsiHlrAddr[CM_MSISDNLEN]; // ActiveHlrAddress for prn and psi 
      u8 m_GmscAddress[CM_GMSCGSMSCFADDRLEN];
      u8 m_TdrRestrictedData[100 + 1];
      u8 m_SriLocalImsi[CM_IMSILEN];

      u8 m_SignalInfo[CM_BCLEN];
      u16 m_SignalInfoLen;
      u16 m_bsrvcType;
      u16 m_bsrvcCode;
      u16 m_bcFlag;
      u8 m_bearerCap[CM_BCLEN];
      u16 m_bearerCapLen;
      u16 m_crbtStatus;
      u8 m_VlrUnsupTeleSrvcArr[32 + 1];
      u8 m_VlrUnsupBearSrvcArr[52 + 1];

      char m_collectCallValue[5];


      u16 m_Mnrf;
      u16 m_BSCODE;
      u16 m_roamInd;
      u16 m_profType;
      u16 m_LmsiLen;
      u16 m_networkId;
      u16 m_ServiceType;
      u16 m_partnerType;
      u16 m_sriImsiType;
      u16 m_ForwardType;
      u16 m_PartnerNetId;
      u16 m_TcsiProfileId;
      u16 m_OcsiProfileId;
      u16 m_DcsiProfileId;
      int m_portOutModel;
      int m_decodeExtContFlag;
      int m_ocsiSuppressFlag;
      s16 m_dbErrCode;
      char m_migrationHelperTdr[100+1];

      EDbResult m_EdbResult;
      EMapErrorCode m_errCode;

      CF_BSG m_fwdInfo;

      int m_IMSTcsiIndicator;

      char m_IMSTcsiInfo[200+1];

      bool executeQuery(void*)=0;
      bool parseVLRInfo(s8 *aBuff);
      bool parseForwardInfo(s8 *aBuff);

      virtual u16 getMsgType();
      virtual void setMsgType(u16 aMsgType);
      virtual EMapErrorCode getErrCode(int errCode);

      virtual ~CMSRIDBdata();
};

class CMPRNPSIDBdata : public CMSRIDBdata
{
   private:

   public:   

      CMPRNPSIDBdata();

      void setMsgType(u16 aMsgType)
      {
         CMSRIDBdata :: setMsgType(aMsgType);
      }

      u16 getMsgType()
      {
         return CMSRIDBdata :: getMsgType();
      }

      bool executeQuery(void*);

      ~CMPRNPSIDBdata();
};

class CMUpdateMNRF : public DbQueryMsg
{
   public:
      CMUpdateMNRF();
      ~CMUpdateMNRF();

      bool executeQuery(void*);

      // Inputs
      u8 m_Msisdn[CM_MSISDNLEN];
      u16 m_Mnrf; 

      s16 m_dbErrCode;
      EDbResult m_EdbResult;
      EMapErrorCode m_errCode;

      EMapErrorCode getErrCode(int errCode);
};

class CMPrnUpdateMNRF : public DbQueryMsg
{
   public:
      CMPrnUpdateMNRF();
      ~CMPrnUpdateMNRF();

      bool executeQuery(void*);

      // Inputs
      u8 m_Imsi[CM_IMSILEN];
      u16 m_Mnrf; 
      
      // Output
      u8 m_freeFormatData[500 + 1];

      s16 m_dbErrCode;
      EDbResult m_EdbResult;
      EMapErrorCode m_errCode;

      EMapErrorCode getErrCode(int errCode);
};

class CMIstCommandData : public DbQueryMsg
{
   public:
      CMIstCommandData();
      ~CMIstCommandData();

      bool executeQuery(void*);

      // Inputs
      char m_TransId[20+1];
      char m_Status;
      char m_ErrorCause[100+1];


      int  m_actTracingFlag;
      char m_type[10+1];
      char m_imsi[15+1];
      int  m_errorCodeToBeUpdated;
};

class SriLCSdata : public DbQueryMsg
{
   public:
      SriLCSdata();
      ~SriLCSdata();

      bool executeQuery(void*);

      // Inputs
      u16 m_targetMStype;
      s8 m_mlcNum[CM_GMLCLEN + 1];
      s8 m_targetMS[CM_MSISDNLEN + 1];

      // Outputs
      s8  m_Lmsi[CM_LMSILEN + 1];
      s8  m_CS_VgmlcAddr[CM_IPADDRLEN + 1];
      s8  m_HgmlcAddr[CM_IPADDRLEN + 1];
      s8  m_HlrAddr[CM_MSISDNLEN + 1];
      s8  m_SgsnNumber[CM_SGSNLEN + 1];
      s8  m_PprAddr[CM_IPADDRLEN + 1];
      s8  m_PrimaryImsi[CM_IMSILEN + 1];
      s8  m_ActiveImsi[CM_IMSILEN + 1];
      s8  m_VlrNumber[CM_VLRNUMLEN + 1];
      s8  m_MscNumber[CM_MSCNUMLEN + 1];
      s8  m_PS_VgmlcAddr[CM_IPADDRLEN + 1];
      s8  m_ActiveMsisdn[CM_MSISDNLEN + 1];
      s8  m_PrimaryMsisdn[CM_MSISDNLEN + 1];

      u16 m_LmsiLen;
      u16 m_networkId;
      u16 m_partnerType;
      u16 m_PartnerNetId;
      u16 m_suppLCScapSets;
      u16 m_suppPSLCScapSets;
      u16 m_mnrf;

      s16 m_dbErrCode;
      EDbResult m_EdbResult;
      EMapErrorCode m_errCode;

      EMapErrorCode getErrCode(int errCode);
};

#endif //_CMSRIDBDATA_H_
