#ifndef _CMSENDROUTINGINFO_H_
#define _CMSENDROUTINGINFO_H_

#include <Msg.h>
#include <IMAP3.h>
#include <OMAP3.h>
#include "CMUtility.h"
#include "CMDbQueries.h"
#include <ContextBase.h>
#include <MapConstants.h>
#include <HlrTdrFiller.h>
#include "CMConfigReader.h"
#include <SubsProfileData.h>

class CtxtSendRoutingInfo : public ContextBase
{ 
   private:

      bool m_tcsiSet;
      bool m_ocsiSet;
      bool m_dcsiSet;
      bool m_GsmSCFCall; 
      bool m_SuppressICB; 
      bool m_nonTelephony;
      bool m_SuppressTCSI; 
      bool m_callDiversion;
      bool m_networkSigInfo;
      bool m_additionalSigInfo;
      bool m_OfferedCamelPhase;
      bool m_suppOfAnnouncementFlag; 
      bool m_RoamingRetrySupportFlag;
      bool m_longFtnSupportFlag;
      bool m_collect_call_enabled;
      bool m_DirectPSI;

      u8 m_ServiceCode; 
      u8 m_AlertPatternValue;	
      u8 m_suppOfAnnouncement; 
      u8 m_suppGmscCamelPhase; 
      u8 m_OfferedCamelPhaseVal; 
      u8 m_Msisdn[CM_MSISDNLEN]; 
      u8 m_CallRefNum[CM_CALLREFNUMLEN]; 
      u8 m_GmscOrGsmScfVal[CM_GMSCGSMSCFADDRLEN]; 

      s8 m_CC[CM_MAXCCLEN];
      s8 m_destAddr[CM_DESTGTLEN];

      u16 m_Mnrf;
      u16 m_MsisdnLen;
      u16 m_sentPrnVer;
      u16 m_ForwardType;
      u16 m_TcsiProfileId;
      u16 m_OcsiProfileId;
      u16 m_DcsiProfileId;
      u16 m_CallRefNumLen;
      u16 m_highestCphGmsc;
      u16 m_manipulatedDcsiCCH;
      u16 m_manipulatedTcsiCCH;
      u16 m_manipulatedOcsiCCH;
      u16 m_AlertPatternLen;
      u16 m_GmscOrGsmScfLen;
      u16 m_psiInitFlag;
      u16 m_psiFailAction;

      u32 m_PRNdlgID; 
      u32 m_PSIdlgID; 
      u32 m_InitDlgId;  

      EMapVersion m_MapVer;	
      EMapErrorCode m_ErrCode; 
      EBasicServiceType m_ServiceType; 

      OMAP3_ProtocolId protocolId;
      OMAP3_SignalInfo signalInfo;
      OMAP3_SignalInfo signalInfo2;
      OMAP3_Ext_ProtocolId ext_ProtocolId;

      CMUtility m_Utility;

      CMSRIDBdata *mp_sriSubData;

      char m_SriImsi[CM_IMSILEN];
      
      unsigned char m_gmscNaiNpi[1+1];

      bool m_extensionDataPresent;
      unsigned char m_asiginfo[200+1];
      unsigned char m_ExtnCntrData[200+1];
   public:

      CtxtSendRoutingInfo();

      bool getCC();
      bool sendPSI();
      bool sendPRN();
      bool sendV1PRN();
      bool sendV2PRN();
      bool handleError();
      bool getPsiStatus();
      bool handleDbQuery();
      EResult getTcsiStatus();
      bool sendSRIResFTNCSI();
      bool sendSRIResOnlyFTN();
      bool sendSRIResPSINack();
      bool updateDb(u16 aMnrf);
      EResult checkSRI(void *aSRI);
      EResult checkHLRSubscription();
      EResult checkVLRSubscription();
      bool sendSRIResPRN(Msg *aMsgPtr);
      EResult checkTCSI(u16 aTcsiProfileId);
      EResult checkOCSI(u16 aOcsiProfileId);
      EResult checkDCSI(u16 aDcsiProfileId);
      EResult checkNonTelephonyHLRProvisioning();
      EResult checkNonTelephonyVLRProvisioning();
      EResult handleFirstForwarding(u16 aForwardType);
      bool processMessage(Msg *aMsgPtr,bool& aDeleteFlag);
      void fillPSINackSRIRes(OMAP3_SendRoutingInfoRes *aSRIRes);
      bool handleSRI(Msg *aMsgPtr, u32 aDlgId, EMapVersion aMapVer);
      bool sendSRIResPSIAck(IMAP3_ProvideSubscriberInfoRes *aPSIRes);
      bool sendSRIUDRResPSIAck(IMAP3_ProvideSubscriberInfoRes *aPSIRes);
      EResult createSRIResFTN(CF_BSG *aCfBsg,void *aSRIRes,bool aCamelFtn);
      void fillCauseValues(OMAP3_GmscCamelSubscriptionInfo *aGmscCamelInfo);
      bool fillTCSI(u16 aTcsiProfileId,OMAP3_GmscCamelSubscriptionInfo *aGmscCamelInfo);
      bool fillOCSI(u16 aOcsiProfileId,OMAP3_GmscCamelSubscriptionInfo *aGmscCamelInfo);
      bool fillDCSI(u16 aDcsiProfileId,OMAP3_GmscCamelSubscriptionInfo *aGmscCamelInfo);
      void fillPSIinSRIRes(OMAP3_SendRoutingInfoRes *aSRIRes,IMAP3_ProvideSubscriberInfoRes *aPSIRes);

      bool sendSRIResMsrnFtn();
      bool sendSRIResSSList();
      virtual ~CtxtSendRoutingInfo();
};

#endif //_CMSENDROUTINGINFO_H_
