#ifndef _CtxtGmlcSriForLcsReq_H_
#define _CtxtGmlcSriForLcsReq_H_
#include <ContextBase.h>
#include <Msg.h>
#include <MapConstants.h>
//#include "GmlcConfig.h"


class CtxtGmlcSriForLcsReq : public ContextBase
{ 
   private:

   public:
      CtxtGmlcSriForLcsReq();
      bool processMessage(Msg *p_MsgPtr,bool& p_DeleteFlag);
      bool startProcessing();
      bool sendSriForLcsReq();
      virtual ~CtxtGmlcSriForLcsReq();
};

#endif 
