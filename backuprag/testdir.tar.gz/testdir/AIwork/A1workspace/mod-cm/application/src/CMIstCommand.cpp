#include <MapMessages.h>
#include <ServiceCoordinator.h>
#include <Logger.h>
#include <OMAP1.h>
#include <OMAP2.h>
#include <OMAP3.h>
#include <DbActiveObject.h>
#include <ConfigReader.h>
#include <Utilities.h>
#include <DataUnion.h>
#include <HlrTdrFiller.h>
#include "CMDbQueries.h"
#include "CMIstCommand.h"

extern bool resetStruct(int p_version, int p_pdu, void *p_struct);


CtxtIstCommand::CtxtIstCommand()
{
   DLOG(0,0,"CtxtIstCommand::CtxtIstCommand()");
   memset(m_TransId, '\0', sizeof(m_TransId));
   m_UserDlgId=0;
}

CtxtIstCommand::~CtxtIstCommand()
{
   DLOG(0,0,"CtxtIstCommand::~CtxtIstCommand()");
}


bool CtxtIstCommand::sendv3Ist()
{
   string l_imsi = ConfigReader::readValue(m_DataString, "IMSI");
   if (0 == l_imsi.length())
   {
      CLOG(0,0,"Unknown IMSI");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }


   string l_type = ConfigReader::readValue(m_DataString, "TYPE");
   if (0 == l_type.length())
   {
      CLOG(0,0,"Unknown TYPE");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }

   if ( (l_type.compare("GSM") != 0) &&
        ((l_type.compare("GPRS") != 0)))
   {
      CLOG(0,1,"Invalid TYPE %s", (char*)l_type.c_str());
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }

   string l_destAddress;
   l_destAddress = ConfigReader::readValue(m_DataString, "DEST_ADDRESS");
   if(0 == l_destAddress.length())
   {
      CLOG(0,0,"Unknown DEST_ADDRESS");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }

   string l_origAddress;
   l_origAddress = ConfigReader::readValue(m_DataString, "ORIG_ADDRESS");
   if(0 == l_origAddress.length())
   {
      CLOG(0,0,"Unknown ORIG_ADDRESS");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }


   m_UserDlgId = g_sc.getNewDialogue();
   if(m_UserDlgId < 1)
   {
      ELOG(0,0,"Couldnt get a new dialogue");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }
   DLOG(0,0,"Sending MapOpenReq v3 ...");
   MapOpenReq l_mapOpenReq(m_UserDlgId, MAP_V3);
   l_mapOpenReq.m_ApplCntxt = MAP_AC_CODE_ServiceTermination;
   configureSccpAddress(&l_mapOpenReq.m_OrigAddr, L_ROUTE_ON_GT, 0, g_ConfigData->i_NgConfigData.m_LocalSSN, (char*)l_origAddress.c_str());
   m_tdr.setMapVersion(3);
   m_tdr.setString(TDR_INDEX_LOCAL_ADDRESS, (char*)l_origAddress.c_str());

   if(0 == l_type.compare("GSM"))
   {
      m_tdr.setRemoteAddrSsn(7);
      configureSccpAddress(&l_mapOpenReq.m_DestAddr, L_ROUTE_ON_GT, 0, 7, (char*)l_destAddress.c_str());
   }
   else
   {
      m_tdr.setRemoteAddrSsn(149);
      configureSccpAddress(&l_mapOpenReq.m_DestAddr, L_ROUTE_ON_GT, 0, 149, (char*)l_destAddress.c_str());
   }
   m_tdr.setRemoteAddr((char*)l_destAddress.c_str());

   g_sc.sendMsg(this, &l_mapOpenReq);

   DLOG(0,0,"Sending MapSpecificRequest v3...");
   MapSpecificRequest l_request(m_UserDlgId, MAP_OP_CODE_istCommand, MAP_V3);

   DECLARE(OMAP3_IST_CommandArg, l_ist, 3, "OMAP3_IST_CommandArg", resetStruct);

   l_ist->imsi.length = (strlen((char*)l_imsi.c_str())+1)/2;

   numToBCD((u8*)l_imsi.c_str(), (u8*)(l_ist->imsi.value), strlen(l_imsi.c_str()));

   m_tdr.setChar(TDR_INDEX_REQUEST_TYPE,'I');
   m_tdr.setString(TDR_INDEX_REQUEST_IMSI,(char*)l_imsi.c_str());

   LLOG(0,0,"IMSI sent in ISTCommand [%s]", l_imsi.c_str());
   l_request.m_structBuffer = (void*)l_ist;
   g_sc.sendMsg(this, &l_request);

   DLOG(0,0,"Sending MapDelimiterReq Req ...");
   MapDelimiterReq l_del(m_UserDlgId);
   g_sc.sendMsg(this, &l_del);
   return true;
}


bool CtxtIstCommand::startProcessing(InterModuleData *p_imd, bool& p_DeleteFlag)
{
   DLOG(0,0,"CtxtIstCommand::startProcessing data [%s] [%d]",(NULL == p_imd->m_Parameters)?"":p_imd->m_Parameters, p_DeleteFlag);

   if(NULL == p_imd->m_Parameters)
   {
      CLOG(0,0,"p_imd->m_Parameters NULL returning");
      return false;
   }
   char *l_check = NULL;
   l_check = strchr(p_imd->m_Parameters, ':');
   if(l_check == NULL)
   {
      CLOG(0,0,"Transaction ID not present");
      return false;
   }

   strncpy(m_TransId, p_imd->m_Parameters, strlen(p_imd->m_Parameters)-strlen(l_check)); 

   LLOG(0,0,"Transaction ID :%s", m_TransId);
   m_tdr.setString(TDR_INDEX_OAM_TRANSACTION_ID, m_TransId);

   m_DataString.assign(l_check+1);

   sendv3Ist();
   return true;
}


bool CtxtIstCommand::updateDb(char p_status, char *p_error)
{
   CMIstCommandData *l_ist = new CMIstCommandData;
   l_ist->m_cb = this;
   l_ist->m_Status = p_status;
   strcpy(l_ist->m_TransId, m_TransId);
   strcpy(l_ist->m_ErrorCause, p_error);
   g_act.execute(l_ist);
   return true;
}

bool CtxtIstCommand::processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag)
{
   DLOG(0,0,"Start of CtxtIstCommand::processMsg function");
   MapSpecificMsg *l_specMsg = NULL;

   switch (p_MsgPtr->m_MsgType)
   {
      case MSG_TYPE_MAP:
         switch (((MapMsg*)p_MsgPtr)->m_MapMsgType)
         {
            case MAP_MSG_TYPE_COMMON:
               switch (((MapCommonMsg*)p_MsgPtr)->m_MapCommonMsgType)
               {
                  case MAP_CMN_OPEN_IND:
                     DLOG(0,0,"MAP_CMN_OPEN_IND received with DlgId [%d], Version [%d]", getInitialRespondingDlgId(),
                           getInitialRespondingVersion());
                     break;

                  case MAP_CMN_OPEN_CNF:
                     {
                        LLOG(0,0,"MAP_CMN_OPEN_CNF received with Version [%d]", ((MapOpenCnf*)p_MsgPtr)->m_Version);
                        m_tdr.setInteger(TDR_INDEX_OPEN_CNF_VERSION,(int)(((MapOpenCnf*)p_MsgPtr)->m_Version));
                     }
                     break;

                  case MAP_CMN_DELIMITER_IND:
                     {
                        LLOG(0,0,"MAP_CMN_DELIMITER_IND received ");
                     }
                     break;

                  case MAP_CMN_CLOSE_IND:
                     {
                        DLOG(0,0,"MAP_CMN_CLOSE_IND received");
                     }

                     break;

                  case MAP_CMN_U_ABORT_IND:
                     {
                        WLOG(0,0,"MAP_CMN_U_ABORT_IND received");
                        m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_U_ABORT_RCVD); 
                        updateDb('F', "Received U-Abort");
                     }
                     break;

                  case MAP_CMN_P_ABORT_IND:
                     {
                        WLOG(0,0,"MAP_CMN_P_ABORT_IND received");
                        m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_P_ABORT_RCVD); 
                        updateDb('F', "Received P-Abort");
                     }
                     break;

                  case MAP_CMN_NOTICE_IND:
                     {
                        LLOG(0,0,"MAP_CMN_NOTICE_IND received");
                        m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_NOTICE_RCVD); 
                        MapCloseReq l_closeReq(m_UserDlgId);
                        l_closeReq.m_CloseType = MAP_CLOSE_TYPE_PRE_ARRANGED_END;
                        g_sc.sendMsg(this, &l_closeReq);

                        updateDb('F', "Received Notice");
                     }
                     break;

                  default:
                     ELOG(0,0,"Unknown Msg received [%d]", ((MapCommonMsg*)p_MsgPtr)->m_MapCommonMsgType);
                     break;
               }
               break;

            case MAP_MSG_TYPE_SPECIFIC:
               DLOG(0,0,"MAP_MSG_TYPE_SPECIFIC received [%d]", getInitialRespondingDlgId());
               l_specMsg = (MapSpecificMsg*)p_MsgPtr;

               switch (((MapSpecificMsg*)p_MsgPtr)->m_MapSpecificEventType)
               {
                  case MAP_SPEC_EVENT_CONFIRMATION:
                     {
                        DLOG(0,0,"MAP_SPEC_EVENT_CONFIRMATION received");
                        updateDb('S', "");
                     }
                     break;

                  case MAP_SPEC_EVENT_USER_ERROR:
                     {
                        DLOG(0,0,"MAP_SPEC_EVENT_USER_ERROR received");
                        m_tdr.setInteger(TDR_INDEX_ERR_CODE, ((MapUserError*)p_MsgPtr)->m_ErrorCode); 
                        updateDb('F', "Received USER ERROR");
                     }
                     break;

                  case MAP_SPEC_EVENT_PROV_ERROR:
                     {
                        DLOG(0,0,"MAP_SPEC_EVENT_PROV_ERROR received");
                        m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_PROVIDER_ERROR_RCVD); 
                        DLOG(0,0,"Closing the Dialogue");
                        updateDb('F', "Some Error");
                     }
                     break;
                  default:
                     m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_GENERAL_ERROR); 
                     ELOG(0,0,"ERROR!! Default received");
                     break;
               }
               break;

            default:
               break;
         }
         break;

      case MSG_TYPE_DB:
         DLOG(0,0,"DB message received");
         break;

      default:
         ELOG(0,0,"Unknown message received");
         break;

   }
   return true;
}

