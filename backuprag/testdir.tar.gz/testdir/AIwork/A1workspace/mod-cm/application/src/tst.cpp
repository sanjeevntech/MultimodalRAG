bool CtxtSendRoutingInfo :: sendSRIResMsrnFtn(Msg *aMsgPtr)
{
   IMAP3_ISDN_AddressString *aPRNRes = NULL;
   if(3 == m_sentPrnVer)
      aPRNRes = &(((IMAP3_ProvideRoamingNumberRes*)(((MapSpecificMsg*)aMsgPtr)->m_structBuffer))->roamingNumber);
   else if(2 == m_sentPrnVer)
      aPRNRes = (IMAP3_ISDN_AddressString*)&((((IMAP2_ProvideRoamingNumberRes*)(((MapSpecificMsg*)aMsgPtr)->m_structBuffer))->roamingNumber));
   else
      aPRNRes = (IMAP3_ISDN_AddressString*)&((((IMAP1_ProvideRoamingNumberRes*)(((MapSpecificMsg*)aMsgPtr)->m_structBuffer))->roamingNumber));

   switch(m_MapVer)
   {
      case MAP_V3:
         {
            DLOG(0,0,"In sendSRIResMsrnFtn-V3");

            DECLARE(OMAP3_SendRoutingInfoRes,l_tempSriResMsrnFtn,3,"OMAP3_SendRoutingInfoRes",resetStruct);

            if(aPRNRes->length > 0 ) // u get RoamingNum in BCD sending as it is in SRIRes ( no conversions )
            {		 
               TLOG_HEX(0,0,"SriResMsrnFtn: Msrn", (s8*)aPRNRes->value,aPRNRes->length);
               m_tdr.setHex(TDR_INDEX_CM_SRI_MSRN,(s8*)aPRNRes->value,aPRNRes->length);

               l_tempSriResMsrnFtn->bit_mask |= OMAP3_SendRoutingInfoRes_imsi_present;

               TLOG(0,0,"SriResMsrnFtn: imsi + roamingnumber + suppCphVmsc - SRIImsi:|%s|",m_SriImsi); 
               l_tempSriResMsrnFtn->imsi.length = StringToBCD(l_tempSriResMsrnFtn->imsi.value,(u8*)m_SriImsi,(s32)strlen((char*)m_SriImsi));

               l_tempSriResMsrnFtn->bit_mask |= OMAP3_extendedRoutingInfo_present;
               l_tempSriResMsrnFtn->extendedRoutingInfo.choice = OMAP3_routingInfo_chosen;
               l_tempSriResMsrnFtn->extendedRoutingInfo.u.routingInfo.choice = OMAP3_roamingNumber_chosen;

               l_tempSriResMsrnFtn->extendedRoutingInfo.u.routingInfo.u.roamingNumber.length = aPRNRes->length;
               memcpy(l_tempSriResMsrnFtn->extendedRoutingInfo.u.routingInfo.u.roamingNumber.value,aPRNRes->value,aPRNRes->length);
               m_Utility.getSuppCamelPhsVmsc(l_tempSriResMsrnFtn,mp_sriSubData);
            }
            else
            {
               CLOG(0,0,"SriResMsrnFtn: roamingnumber length is less than zero so closing the sri dialogue");
               MapCloseReq l_closeReq(m_InitDlgId);
               g_sc.sendMsg(this, &l_closeReq);
               return true;
            }
            return m_Utility.sendSRIRESULTLAST(this,m_InitDlgId,MAP_OP_CODE_sendRoutingInfo,MAP_V3,l_tempSriResMsrnFtn);
         }
         break;
      case MAP_V2:
         {
            DLOG(0,0,"In SendSriResMsrnFtn-V2");

            DECLARE(OMAP2_SendRoutingInfoRes,l_tempSriResMsrnFtn,2,"OMAP2_SendRoutingInfoRes",resetStruct);

            if(aPRNRes->length > 0 ) // u get RoamingNum in BCD sending as it is in SRIRes ( no conversions )
            {		 
               LLOG_HEX(0,0,"V2:SriResMsrnFtn: Msrn", (s8*)aPRNRes->value,aPRNRes->length);
               m_tdr.setHex(TDR_INDEX_CM_SRI_MSRN,(s8*)aPRNRes->value,aPRNRes->length);

               TLOG(0,0,"V2:SriResMsrnFtn: imsi + roamingnumber + suppCphVmsc - SRIImsi:|%s|",m_SriImsi); 
               l_tempSriResMsrnFtn->imsi.length = StringToBCD(l_tempSriResMsrnFtn->imsi.value,(u8*)m_SriImsi,(s32)strlen((char*)m_SriImsi));

               l_tempSriResMsrnFtn->routingInfo.choice = OMAP2_RoutingInfo_roamingNumber_chosen;

               l_tempSriResMsrnFtn->routingInfo.u.roamingNumber.length = aPRNRes->length;
               memcpy(l_tempSriResMsrnFtn->routingInfo.u.roamingNumber.value,aPRNRes->value,aPRNRes->length);
            }
            else
            {
               CLOG(0,0,"SriResMsrnFtn: roamingnumber length is less than zero so closing the sri dialogue");
               MapCloseReq l_closeReq(m_InitDlgId);
               g_sc.sendMsg(this, &l_closeReq);
               return true;
            }
            return m_Utility.sendSRIRESULTLAST(this,m_InitDlgId,MAP_OP_CODE_sendRoutingInfo,MAP_V2,l_tempSriResMsrnFtn);
         }
         break;
      case MAP_V1:
         {
            DLOG(0,0,"In SendSriResMsrnFtn-V1");

            DECLARE(OMAP1_SendRoutingInformationRes,l_tempSriResMsrnFtn,1,"OMAP1_SendRoutingInformationRes",resetStruct);

            if(aPRNRes->length > 0 ) // u get RoamingNum in BCD sending as it is in SRIRes ( no conversions )
            {		 
               LLOG_HEX(0,0,"V1:SriResMsrnFtn: Msrn", (s8*)aPRNRes->value,aPRNRes->length);
               m_tdr.setHex(TDR_INDEX_CM_SRI_MSRN,(s8*)aPRNRes->value,aPRNRes->length);

               TLOG(0,0,"V1:SriResMsrnFtn: imsi + roamingnumber + suppCphVmsc - SRIImsi:|%s|",m_SriImsi); 
               l_tempSriResMsrnFtn->imsi.length = StringToBCD(l_tempSriResMsrnFtn->imsi.value,(u8*)m_SriImsi,(s32)strlen((char*)m_SriImsi));

               l_tempSriResMsrnFtn->routingInfo.choice = OMAP1_routingInfo_roamingNumber_chosen;

               l_tempSriResMsrnFtn->routingInfo.u.roamingNumber.length = aPRNRes->length;
               memcpy(l_tempSriResMsrnFtn->routingInfo.u.roamingNumber.value,aPRNRes->value,aPRNRes->length);
            }
            else
            {
               CLOG(0,0,"V1:SriResMsrnFtn: roaming number length is less than zero so closing the sri dialogue");
               MapCloseReq l_closeReq(m_InitDlgId);
               g_sc.sendMsg(this, &l_closeReq);
            }
            return m_Utility.sendSRIRESULTLAST(this,m_InitDlgId,MAP_OP_CODE_sendRoutingInfo,MAP_V1,l_tempSriResMsrnFtn);
         }
         break;
      default:
         {
            LLOG(0,0,"Unknown MapVersion received");
         }
         break;
   }
   return true;
}
