#include <OMAP1.h>
#include <OMAP2.h>
#include "Logger.h"
#include "CMUtility.h"
#include <Utilities.h>
#include <ServiceCoordinator.h>
#include "CMSendRoutingInfo.h"

CMUtility :: CMUtility()
{
   memset(m_partnerGsmScfAdd,'\0',20);
}

CMUtility :: ~CMUtility()
{
}

bool CMUtility :: DPSupportedInCamelPhase(u16 aDP, u16 aCamelPhase) // Not used 
{
   //Note: We are checking only for 6 DPs
   DLOG(0,0,"DPSupportedInCamelPhase check");

   if((aCamelPhase & CM_CAMELPHASE3)||(aCamelPhase & CM_CAMELPHASE4)) // Phase3,Phase4 
   {	
      switch(aDP)
      {
         case CM_COLLECTEDINFO:
         case CM_ANALYSEDINFO:
         case CM_ROUTESELECTFAILURE:
         case CM_TERMATTEMPTAUTHORIZED:
         case CM_TBUSY:
         case CM_TNOANSWER:
            DLOG(0,0," DP |%d| is SUPPORTED in CAMELPHASE 3 returning TRUE ",aDP);
            return true;
         default:
            DLOG(0,0," DP |%d| is NOT SUPPORTED in CAMELPHASE 3 returning FALSE ",aDP);
            return false;
      }
   }
   if(aCamelPhase & CM_CAMELPHASE2) // Phase2
   {
      switch(aDP)
      {
         case CM_COLLECTEDINFO:
         case CM_TERMATTEMPTAUTHORIZED:
         case CM_TBUSY:
         case CM_TNOANSWER:
            DLOG(0,0," DP |%d| is SUPPORTED in CAMELPHASE 2 returning TRUE ",aDP);
            return true;
         default:
            DLOG(0,0," DP |%d| is NOT SUPPORTED in CAMELPHASE 2 returning FALSE ",aDP);
            return false;
      }
   }
   if(aCamelPhase & CM_CAMELPHASE1) // Phase1
   {
      switch(aDP)
      {
         case CM_COLLECTEDINFO:
         case CM_TERMATTEMPTAUTHORIZED:
            DLOG(0,0," DP |%d| is SUPPORTED in CAMELPHASE 1 returning TRUE ",aDP);
            return true;
         default:
            DLOG(0,0," DP |%d| is NOT SUPPORTED in CAMELPHASE 1 returning FALSE ",aDP);
            return false;
      }
   }
   DLOG(0,0," UNKNOWN DP |%d| FOR THE CAMEELPHASE |%d| returning FALSE",aDP,aCamelPhase);
   return false;
}

bool CMUtility :: sendMapUserError(ContextBase *aCB,EMapErrorCode aUserError,u32 aDlgId,EMapVersion aMapVer,void *aErrBuf)
{
   MapUserError l_userError(aDlgId, aUserError, aMapVer,aErrBuf);
   g_sc.sendMsg(aCB, &l_userError);

   DLOG(0,0,"Closing the Dialogue |%d|",aDlgId);
   MapCloseReq l_CloseReq(aDlgId);
   g_sc.sendMsg(aCB,&l_CloseReq);
   return true;
}

bool CMUtility :: sendSRIRESULTLAST(ContextBase *aCB,u32 aInitDlgId,EMapOpCode aOpCode,EMapVersion aVer,void* aSRIRes)
{
   switch(aVer)
   {
      case MAP_V3:
         {
            OMAP3_SendRoutingInfoRes* pSRIRes = (OMAP3_SendRoutingInfoRes*)aSRIRes;
            MapSpecificResult l_resultL(aInitDlgId,aOpCode,aVer);
            l_resultL.m_structBuffer = (void*)pSRIRes;
            g_sc.sendMsg(aCB, &l_resultL);

            DLOG(0,0,"Closing the SRIRes dialogue");
            MapCloseReq l_closeReq(aInitDlgId);
            g_sc.sendMsg(aCB, &l_closeReq);
         }
         break;
      case MAP_V2:
         {
            OMAP2_SendRoutingInfoRes* pSRIRes = (OMAP2_SendRoutingInfoRes*)aSRIRes;
            MapSpecificResult l_resultL(aInitDlgId,aOpCode,aVer);
            l_resultL.m_structBuffer = (void*)pSRIRes;
            g_sc.sendMsg(aCB, &l_resultL);

            DLOG(0,0,"Closing the SRIRes dialogue");
            MapCloseReq l_closeReq(aInitDlgId);
            g_sc.sendMsg(aCB, &l_closeReq);
         }
         break;
      case MAP_V1:
         {
            OMAP1_SendRoutingInformationRes* pSRIRes = (OMAP1_SendRoutingInformationRes*)aSRIRes;
            MapSpecificResult l_resultL(aInitDlgId,aOpCode,aVer);
            l_resultL.m_structBuffer = (void*)pSRIRes;
            g_sc.sendMsg(aCB, &l_resultL);

            DLOG(0,0,"Closing the SRIRes dialogue");
            MapCloseReq l_closeReq(aInitDlgId);
            g_sc.sendMsg(aCB, &l_closeReq);
         }
         break;
      default:
         {
            CLOG(0,0,"Unknown MapVersion received");
         }
         break;
   }
   return true;
}

bool CMUtility :: sendSRIRESULTNOTLAST(ContextBase *aCB,u32 aInitDlgId,EMapOpCode aOpCode,EMapVersion aVer,OMAP3_SendRoutingInfoRes* aSRIRes)
{
   MapSpecificResult l_resultNL(aInitDlgId,aOpCode,aVer);
   l_resultNL.m_structBuffer = (void*)aSRIRes;
   l_resultNL.m_LastFlag = false; // TC_RESULT_NL
   g_sc.sendMsg(aCB, &l_resultNL);

   DLOG(aInitDlgId,0,"Continuing the SRIRes Dialogue");
   MapDelimiterReq l_delReq(aInitDlgId);
   g_sc.sendMsg(aCB, &l_delReq);

   aSRIRes->bit_mask &= (~OMAP3_SendRoutingInfoRes_imsi_present);// disabling IMSI as it is sent in first chunk
   return true;
}

bool CMUtility :: getSuppCamelPhsVmsc(OMAP3_SendRoutingInfoRes *aSRIRes, CMSRIDBdata *aDBdata)
{
   u8 l_suppCphsVmsc = 0x00;
   l_suppCphsVmsc = aDBdata->m_SupportedCamelPhaseVmsc;
   DLOG(0,0,"SRIRes: supported camel phases in vmsc |%x| ",l_suppCphsVmsc);
   if((l_suppCphsVmsc & 0x0f) != 0)
   {
      aSRIRes->bit_mask |= OMAP3_supportedCamelPhasesInVMSC_present;
      if(l_suppCphsVmsc & 0x01)
         aSRIRes->supportedCamelPhasesInVMSC.value[0] |= 0x80; // PHASE1
      if(l_suppCphsVmsc & 0x02)
         aSRIRes->supportedCamelPhasesInVMSC.value[0] |= 0x40; // PHASE2
      if(l_suppCphsVmsc & 0x04)
         aSRIRes->supportedCamelPhasesInVMSC.value[0] |= 0x20; // PHASE3
      if(l_suppCphsVmsc & 0x08)
         aSRIRes->supportedCamelPhasesInVMSC.value[0] |= 0x10; // PHASE4
      aSRIRes->supportedCamelPhasesInVMSC.length = getNumberOfSignificantBitsForAByte(aSRIRes->supportedCamelPhasesInVMSC.value[0]);
      return true;
   }
   return false;
}

//// ROAMPARTNER - //////
bool CMUtility :: getPartnerGsmScfAddr(s8* aGsmScfAddr, u16 aNkId, u16 aPnkId)
{
   char l_tempArr[100];
   memset(l_tempArr,'\0',sizeof(l_tempArr));
   aNkId += 100;
   sprintf(l_tempArr,"%d%04d%s",aNkId,aPnkId,aGsmScfAddr);

   DLOG(0,0,"NKID:PNKID:GSMSCFADDR |%s| KEY USED TO SEARCH PARTNERGSMSCFADDRESS",l_tempArr); 

   long double key = strtold(l_tempArr,NULL);
   map<long double,s8*> :: iterator rpiter = g_spdPtr->m_RPMap.find(key);
   if(rpiter != g_spdPtr->m_RPMap.end())
   {
      DLOG(0,0,"PARTNER GSMSCFADDR MATCH FOUND");
      strncpy(m_partnerGsmScfAdd,(s8*)(rpiter->second),strlen((s8*)(rpiter->second)));
      return true;
   }
   else
   {
      DLOG(0,0," PARTNER GSMSCFADDR MATCH NOT FOUND");
      return false;
   }
}

u8 CMUtility :: getBSGroup(u8 aBSCode, EBasicServiceType aBSType)
{
   DLOG(0,0," Inside GETBSGROUP ");
   u8 bsgCode = 0x00;
   switch(aBSType)
   {
      case CM_BEARER_SERVICE_TYPE:
         bsgCode = aBSCode & 0x78; // 7654 bits indicate group
         return bsgCode;
         break;

      case CM_TELESERVICE_TYPE:
         bsgCode = aBSCode & 0xF0; // 8765 bits indicate group
         return bsgCode;
         break;

      default:
         ELOG(0,0,"Invalid BSType: |%d|",aBSType);
         return 0;
   }
   return 0;
}

/////////////////////////

u16 CMUtility :: BCDToChar(u8 *aChar, u8 *aBcd, u16 aBcdLen)
{
   u16 l_charLen = 0;
   u16 count,j;
   for(count=0, j=0; count<aBcdLen; count++, j+=2)
   {
      aChar[j] = ((aBcd[count])&(0x0F)) + '0';
      aChar[j+1] = ((aBcd[count]&0xF0)>>4) + '0';

      if(((count == (aBcdLen-1)) && (aBcd[count]&0xF0) == 0xF0))
      {
         aChar[j+1] = '\0';
         l_charLen = j+1;
      }
      else if(count == (aBcdLen-1))
      {
         aChar[j+2] = '\0';
         l_charLen = j+2;
      }
   }
   return l_charLen;
}


u16 CMUtility :: CharToBCD(u8 *aBcd,u8 *aChar, u16 aCharLen)
{
   u16 i, j;
   for(i = 0, j = 0; j < aCharLen; i++)
   {
      aBcd[i]= aChar[j]-'0';

      if((aCharLen == (j+1)) && aCharLen%2)
         aBcd[i] |= 0xF0;
      else
         aBcd[i] |= ((aChar[j+1]-'0')<<4);
      j += 2;
   }
   return ((aCharLen/2) + (aCharLen%2));
}

u16 CMUtility :: PrintHex(const s8* str, const s8* buf, const u16 len) // Not used
{
   s8 tmpStr[1000], lTemp[5];
   if(len > 300)
   {
      ELOG(0,0,"Length is more than 300. [len:%d]",len);
      return false;
   }

   memset(tmpStr, 0, sizeof(tmpStr));
   for(u16 j=0; j<len; j++)
   {
      snprintf(lTemp, 4, "%02x ", buf[j]&0x00ff);
      strncat(tmpStr,lTemp,4);
   }

   LLOG(0,0, "%s [len:%d, buf:%s]",str, len, tmpStr);

   return true;
}

