#include <stdio.h>
#include <MapMessages.h>
#include <ServiceCoordinator.h>
#include <Logger.h>
#include "ConfigReader.h"
#include "CtxtVlrPRNRes.h"
#include "HLRCMEnums.h"
#include "HLRCMConstants.h"
#include <DbActiveObject.h>
#include <DataUnion.h>
#include <Utilities.h>
#include <CMSimConfigReader.h>


/**************************************************************************************************
  Function Name      : CtxtVlrPRNRes
Author               :
InParams             : void 
OutParam /return val : void
Description          : Constructor
 ****************************************************************************************************/


CtxtVlrPRNRes :: CtxtVlrPRNRes()
{
   m_PrnDlgId = 0;
}


/**************************************************************************************************
  Function Name      : CtxtVlrPRNRes
Author               :
InParams             : void 
OutParam /return val : void
Description          : Destructor
 ****************************************************************************************************/


CtxtVlrPRNRes :: ~CtxtVlrPRNRes()
{

}

bool CtxtVlrPRNRes :: sendMapUserError(int p_dlgId,EMapErrorCode p_ErrCode,EMapVersion p_ver)
{
   ELOG(p_dlgId,0,"###CtxVLRPRNRes### SENDING MAPUSERERROR AND CLOSING THE DIALOGUE");
   MapUserError l_userError(p_dlgId, p_ErrCode, p_ver, NULL);
   g_sc.sendMsg(this, &l_userError);

   MapCloseReq l_closeReq(p_dlgId);
   g_sc.sendMsg(this, &l_closeReq);
   return true;
}

bool CtxtVlrPRNRes::sendPRNRes()
{
   if(g_CMSimConfigReaderObj->m_mapVer == MAP_V3)
   {
   DECLARE(OMAP3_ProvideRoamingNumberRes,l_tempPRNRes,3,"OMAP3_ProvideRoamingNumberRes",resetStruct);
   int l_UserDlgId = m_PrnDlgId;
   DLOG(l_UserDlgId,0,"V3: Start of CtxtVlrPRNRes::sendPRNRes function");

   if(!g_CMSimConfigReaderObj->m_MapError) 
   {
      //printf("\n #### bfore RoamingNum #### \n");
      l_tempPRNRes->roamingNumber.length = 0x06;
      StringToBCD(l_tempPRNRes->roamingNumber.value, (unsigned char *)"919849447216", strlen((char*)"919849447216"));
      //printf("\n #### after RoamingNum #### \n");

      l_tempPRNRes->bit_mask |= OMAP3_ProvideRoamingNumberRes_releaseResourcesSupported_present;
      l_tempPRNRes->releaseResourcesSupported = 3;

      MapSpecificResult l_result(l_UserDlgId, MAP_OP_CODE_provideRoamingNumber, MAP_V3);
      l_result.m_structBuffer = (void*)l_tempPRNRes;
      g_sc.sendMsg(this, &l_result);

      DLOG(0,0,"V3: Closing the PRN Dialogue");
      MapCloseReq l_closeReq(l_UserDlgId);
      g_sc.sendMsg(this, &l_closeReq);
   }
   else
   {
      sendMapUserError(l_UserDlgId,(EMapErrorCode)g_CMSimConfigReaderObj->m_MapError,MAP_V3);
   }
   }
   else if(g_CMSimConfigReaderObj->m_mapVer == MAP_V2)
   {
   DECLARE(OMAP2_ProvideRoamingNumberRes,l_tempPRNRes,2,"OMAP2_ProvideRoamingNumberRes",resetStruct);
   int l_UserDlgId = m_PrnDlgId;
   DLOG(0,0,"V2: Start of CtxtVlrPRNRes::sendPRNRes function");

   if(!g_CMSimConfigReaderObj->m_MapError) 
   {
      l_tempPRNRes->roamingNumber.length = 0x06;
      StringToBCD(l_tempPRNRes->roamingNumber.value, (unsigned char *)"919849442222", strlen("919849442222"));

      MapSpecificResult l_result(l_UserDlgId, MAP_OP_CODE_provideRoamingNumber, MAP_V2);
      l_result.m_structBuffer = (void*)l_tempPRNRes;
      g_sc.sendMsg(this, &l_result);

      DLOG(0,0,"V2: Closing the PRN Dialogue");
      MapCloseReq l_closeReq(l_UserDlgId);
      g_sc.sendMsg(this, &l_closeReq);
   }
   else
   {
      sendMapUserError(l_UserDlgId,(EMapErrorCode)g_CMSimConfigReaderObj->m_MapError,MAP_V2);
   }
   }
   else if(g_CMSimConfigReaderObj->m_mapVer == MAP_V1)
   {
   DECLARE(OMAP1_ProvideRoamingNumberRes,l_tempPRNRes,1,"OMAP1_ProvideRoamingNumberRes",resetStruct);
   int l_UserDlgId = m_PrnDlgId;
   DLOG(0,0,"V1: Start of CtxtVlrPRNRes::sendPRNRes function");

   if(!g_CMSimConfigReaderObj->m_MapError) 
   {
   #ifdef Linux
      l_tempPRNRes->length = 0x06;
      StringToBCD(l_tempPRNRes->value, (unsigned char *)"919849441111", strlen("919849441111"));
   #else
      l_tempPRNRes->roamingNumber.length = 0x06;
      StringToBCD(l_tempPRNRes->roamingNumber.value, (unsigned char *)"919849441111", strlen("919849441111"));
   #endif
      MapSpecificResult l_result(l_UserDlgId, MAP_OP_CODE_provideRoamingNumber, MAP_V1);
      l_result.m_structBuffer = (void*)l_tempPRNRes;
      g_sc.sendMsg(this, &l_result);

      DLOG(0,0,"V1: Closing the PRN Dialogue");
      MapCloseReq l_closeReq(l_UserDlgId);
      g_sc.sendMsg(this, &l_closeReq);
   }
   else
   {
      sendMapUserError(l_UserDlgId,(EMapErrorCode)g_CMSimConfigReaderObj->m_MapError,MAP_V1);
   }
   }
   return true;
}


bool CtxtVlrPRNRes::processMessage(Msg *p_MsgPtr,bool& p_DeleteFlag)
{
   DLOG(0,0,"###CtxVLRPRNRes### Start of CtxtVlrPRNRes::processMsg function");
   MapSpecificMsg *l_specMsg = NULL;
   int l_UserDlgId;

   switch (p_MsgPtr->m_MsgType)
   {
      case MSG_TYPE_MAP:
         switch (((MapMsg*)p_MsgPtr)->m_MapMsgType)
         {
            case MAP_MSG_TYPE_COMMON:
               switch (((MapCommonMsg*)p_MsgPtr)->m_MapCommonMsgType)
               {
                  case MAP_CMN_OPEN_IND:
                     DLOG(0,0,"###CtxVLRPRNRes### MAP_CMN_OPEN_IND received");
                     break;

                  case MAP_CMN_DELIMITER_IND:
                     DLOG(0,0,"###CtxVLRPRNRes### MAP_CMN_DELIMITER_IND received");
                     break;

                  case MAP_CMN_CLOSE_IND:
                     DLOG(0,0,"###CtxVLRPRNRes### MAP_CMN_CLOSE_IND received");
                     return true;
                     break;

                  case MAP_CMN_U_ABORT_IND:
                     TLOG(0,0,"###CtxVLRPRNRes### MAP_CMN_U_ABORT_IND received");
                     break;

                  case MAP_CMN_P_ABORT_IND:
                     TLOG(0,0,"###CtxVLRPRNRes### MAP_CMN_P_ABORT_IND received");
                     break;

                  case MAP_CMN_NOTICE_IND:
                     {
                        TLOG(0,0,"###CtxVLRPRNRes### MAP_CMN_NOTICE_IND received");
                     }
                     break;

                  default:
                     DLOG(0,0,"###CtxVLRPRNRes### Unknown Msg received [%d]", ((MapCommonMsg*)p_MsgPtr)->m_MapCommonMsgType);
                     break;
               }
               break;

            case MAP_MSG_TYPE_SPECIFIC:
               DLOG(0,0,"###CtxVLRPRNRes### MAP_MSG_TYPE_SPECIFIC received");
               l_specMsg = (MapSpecificMsg*)p_MsgPtr;
               l_UserDlgId = l_specMsg->m_UserDlgId;
              TLOG(0,0,"###CtxVLRPRNRes### MAP_MSG_TYPE_SPECIFIC received UserDlgId[%d]",
                     l_UserDlgId);

               switch (((MapSpecificMsg*)p_MsgPtr)->m_MapSpecificEventType)
               {
                  case MAP_SPEC_EVENT_INDICATION:
                     {
                        DLOG(l_UserDlgId,0,"###CtxVLRPRNRes### MAP_SPEC_EVENT_INDICATION received");
                        //l_UserDlgId = p_MsgPtr->m_UserDlgId; not required as u get DlgId above
                        
                        DLOG(l_UserDlgId,0," OPCODE RECVD %d",((MapSpecificMsg*)p_MsgPtr)->m_OpCode);
                        switch (((MapSpecificMsg*)p_MsgPtr)->m_OpCode)
                        {
                           case MAP_OP_CODE_provideRoamingNumber:
                              {
                                 m_PrnDlgId = l_UserDlgId;

                                 sendPRNRes();
                              }
                              break;

                           default:
                              DLOG(l_UserDlgId,0,"###CtxVLRPRNRes### Received Unknown Specific Message");
                              break;

                        }
                     }

                     break;

                  case MAP_SPEC_EVENT_RESULT:
                     {
                        DLOG(l_UserDlgId,0,"###CtxVLRPRNRes### MAP_SPEC_EVENT_RESULT received");
                     }
                     break;

                  case MAP_SPEC_EVENT_CONFIRMATION:
                     {
                        DLOG(0,0,"###CtxVLRPRNRes### MAP_SPEC_EVENT_CONFIRMATION received ");
                        switch (((MapSpecificMsg*)p_MsgPtr)->m_OpCode)
                        {
                           case MAP_OP_CODE_provideRoamingNumber:
                              {
                                 DLOG(l_UserDlgId,0,"###CtxVLRPRNRes### MAP_SPEC_EVENT_CONFIRMATION received for MAP_OP_CODE_provideRoamingNumber");
                              }
                           case MAP_OP_CODE_sendRoutingInfo:
                              {
                                 DLOG(l_UserDlgId,0,"###CtxVLRPRNRes### MAP_SPEC_EVENT_CONFIRMATION received for MAP_OP_CODE_sendRoutingInfo");
                              }
                              break;
                           default:
                              break;

                        }
                     }
                     break;

                  case MAP_SPEC_EVENT_USER_ERROR:
                     {
                        TLOG(l_UserDlgId,0,"###CtxVLRPRNRes### MAP_SPEC_EVENT_USER_ERROR received");
                     }
                     break;

                  case MAP_SPEC_EVENT_PROV_ERROR:
                     {
                        TLOG(l_UserDlgId,0,"###CtxVLRPRNRes### MAP_SPEC_EVENT_PROV_ERROR received");
                        DLOG(l_UserDlgId,0,"###CtxVLRPRNRes### Closing the Dialogue");
                        MapCloseReq l_closeReq(((MapSpecificMsg*)p_MsgPtr)->m_UserDlgId);
                        g_sc.sendMsg(this, &l_closeReq);
                     }
                     break;
                  default:
                     ELOG(l_UserDlgId,0,"###CtxVLRPRNRes### ERROR!! Default received processMessage");
                     break;

               }


               break;

            default:
               break;
         }
         break;

      case MSG_TYPE_DB:
         {
         }
         break;

      default:
         DLOG(0,0,"###CtxVLRPRNRes### Unknown message received");
         break;

   }
   return true;

}






