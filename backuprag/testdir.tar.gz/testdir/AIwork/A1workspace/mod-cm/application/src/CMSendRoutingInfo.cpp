#include <IMAP1.h>
#include <IMAP2.h>
#include <OMAP1.h>
#include <OMAP2.h>
#include <stdio.h>
#include <Logger.h>
#include <DataUnion.h>
#include <Utilities.h>
#include <MapMessages.h>
#include <DbActiveObject.h>
#include "CMSendRoutingInfo.h"
#include <ServiceCoordinator.h>
#include <SnmpInterface.h>

/**************************************************************************************************
  Function Name      : CtxtSendRoutingInfo
Author               :
InParams             : void 
OutParam /return val : void
Description          : Constructor
 ****************************************************************************************************/

extern int g_CMsignalInfoNotFoundTrap;
extern int g_CMtcsiDetailsNotFoundTrap;
extern int g_CMEntityAuthFailTrap;

CtxtSendRoutingInfo :: CtxtSendRoutingInfo()
{
   DLOG(0,0,"CtxtSendRoutingInfo :cons:");

   m_tcsiSet = false;
   m_ocsiSet = false;
   m_dcsiSet = false;
   m_GsmSCFCall = false;
   m_SuppressICB = false;
   m_SuppressTCSI = false;
   m_callDiversion = true; // default CallDiversion allowed
   m_networkSigInfo = false;
   m_additionalSigInfo = false;
   m_OfferedCamelPhase = false;
   m_suppOfAnnouncementFlag = false;
   m_nonTelephony = false; // 1.0.3.0
   m_RoamingRetrySupportFlag = false;

   m_collect_call_enabled =  false;

   m_ServiceCode = 0x11;
   m_ServiceType =  CM_TELESERVICE_TYPE;

   m_psiInitFlag = 0; // 1.0.3.0
   m_psiFailAction = 0; // 1.0.3.0
   m_Mnrf = 0;
   m_PRNdlgID = 0;
   m_PSIdlgID = 0;
   m_InitDlgId = 0;
   m_MsisdnLen = 0;
   m_sentPrnVer = 0;
   m_ForwardType = 0;
   m_TcsiProfileId = 0;
   m_OcsiProfileId = 0;
   m_DcsiProfileId = 0;
   m_CallRefNumLen = 0;
   m_highestCphGmsc = 0;
   m_manipulatedDcsiCCH = 0;
   m_manipulatedTcsiCCH = 0;
   m_manipulatedOcsiCCH = 0;
   m_AlertPatternLen = 0;
   m_GmscOrGsmScfLen = 0;
   m_AlertPatternValue = 0;
   m_suppGmscCamelPhase = 0;
   m_suppOfAnnouncement = 0;
   m_OfferedCamelPhaseVal = 0;
   m_ErrCode = (EMapErrorCode)0;

   memset(m_CC,'\0',CM_MAXCCLEN);
   memset(m_Msisdn,'\0',CM_MSISDNLEN);
   memset(m_destAddr,'\0',CM_DESTGTLEN);
   memset(m_CallRefNum,'\0',CM_CALLREFNUMLEN);
   memset(m_GmscOrGsmScfVal,'\0',CM_GMSCGSMSCFADDRLEN);

   mp_sriSubData = NULL;

   memset(&signalInfo,'\0',sizeof(OMAP3_SignalInfo));
   memset(&signalInfo2,'\0',sizeof(OMAP3_SignalInfo));

   memset(m_SriImsi,'\0',sizeof(m_SriImsi));
   m_longFtnSupportFlag = false; // 2.0.7.0

   memset(m_gmscNaiNpi,'\0',sizeof(m_gmscNaiNpi));
   m_extensionDataPresent = false;
   memset(m_asiginfo,'\0',sizeof(m_asiginfo));
   memset(m_ExtnCntrData,'\0',sizeof(m_ExtnCntrData));
   m_DirectPSI = false;
}   



/**************************************************************************************************
  Function Name      : CtxtSendRoutingInfo
Author               :
InParams             : void 
OutParam /return val : void
Description          : Destructor
 ****************************************************************************************************/


CtxtSendRoutingInfo :: ~CtxtSendRoutingInfo()
{
   DLOG(0,0,"CtxtSendRoutingInfo :des:");
   if( NULL != mp_sriSubData )
   {
      delete mp_sriSubData;
      mp_sriSubData = NULL;
   }
}

bool CtxtSendRoutingInfo::updateDb(u16 aMnrf)
{
   if(1 == g_CMConfigReaderObj->m_mnrfFlag)
   {
      if(aMnrf == m_Mnrf)
      {
         return false;
      }
      CMUpdateMNRF *l_mnrf = new CMUpdateMNRF;
      if(l_mnrf != NULL)
      {
         strcpy((s8*)l_mnrf->m_Msisdn,(s8*)m_Msisdn);
         l_mnrf->m_Mnrf = aMnrf;
         LLOG(0,0,"DBIN-MNRF: Msisdn-|%s| MnrfFlag-|%d|",m_Msisdn,aMnrf);
         l_mnrf->m_DbQueryType=2;
         l_mnrf->m_cb = this;
         g_act.execute(l_mnrf);
         return true;
      }
      else
      {
         CLOG(0,0,"Newing UpdateMnrfClass Failed");
         return false;
      }
   }
   else
   {
      return true;
   }
}

EResult CtxtSendRoutingInfo :: getTcsiStatus() // 1.0.3.0
{
   TCSI *lpTcsi = g_spdPtr->m_TCSIMap[m_TcsiProfileId];
   bool l_found=false;
   if(m_nonTelephony) // Non-Telephony Calls like Fax Video
   {
      if(0 != mp_sriSubData->m_bsrvcType)
      {
         for(u16 k = 0; k < 5; k++)
         {
            if((lpTcsi->m_bsTcsi[k].m_bsType == mp_sriSubData->m_bsrvcType) && (lpTcsi->m_bsTcsi[k].m_bsCode == mp_sriSubData->m_bsrvcCode))
            {
               l_found=true;
               if(true == m_collect_call_enabled) 
               {
                  if( (0 == lpTcsi->m_bsTcsi[k].m_status) || (1 == lpTcsi->m_bsTcsi[k].m_status) ) 
                  {
                     LLOG(0,0,"T-CSI not Applicable - CsiState should be 2 or 3 for Collect Call");
                     m_ErrCode = MAP_ERROR_systemFailure;
                     return CM_ERROR;
                  }
                  else // 2 or 3 tcsi status
                  {
                     LLOG(0,0,"NonTelephony Call T-CSI status ACTIVE for Collect Call");
                     m_tdr.setInteger(TDR_INDEX_CM_SRI_TCSI_STATUS,(int)CM_TCSI_ACTIVE_FOR_BS); 
                     return CM_CONTINUE;
                  }
               }
               else if( (1 == lpTcsi->m_bsTcsi[k].m_status) || (3 == lpTcsi->m_bsTcsi[k].m_status) )
               {
                  LLOG(0,0,"NonTelephony Call T-CSI status ACTIVE");
                  m_tdr.setInteger(TDR_INDEX_CM_SRI_TCSI_STATUS,(int)CM_TCSI_ACTIVE_FOR_BS); 
                  return CM_CONTINUE;
               }
            }
         }
      }
   }
   else // Normal Telephony Calls
   {
      for(u16 k = 0; k < 5; k++)
      {
         if(lpTcsi->m_bsTcsi[k].m_bsType == 2) 
         {
            if((lpTcsi->m_bsTcsi[k].m_bsCode == 16) || (lpTcsi->m_bsTcsi[k].m_bsCode == 17))
            {
               l_found=true;
               if(true == m_collect_call_enabled)
               {
                  if( (0 == lpTcsi->m_bsTcsi[k].m_status) || (1 == lpTcsi->m_bsTcsi[k].m_status) ) 
                  {
                     LLOG(0,0,"T-CSI not Applicable - CsiState should be 2 or 3 for Collect Call");
                     m_ErrCode = MAP_ERROR_systemFailure;
                     return CM_ERROR;
                  }
                  else // 2 or 3 tcsi status
                  {
                     LLOG(0,0,"Telephony Call T-CSI status ACTIVE for Collect Call");
                     m_tdr.setInteger(TDR_INDEX_CM_SRI_TCSI_STATUS,(int)CM_TCSI_ACTIVE_FOR_BS); 
                     return CM_CONTINUE;
                  }
               }
               else if( (1 == lpTcsi->m_bsTcsi[k].m_status) || (3 == lpTcsi->m_bsTcsi[k].m_status) )
               {
                  LLOG(0,0,"Telephony Call T-CSI status ACTIVE");
                  m_tdr.setInteger(TDR_INDEX_CM_SRI_TCSI_STATUS,(int)CM_TCSI_ACTIVE_FOR_BS); 
                  return CM_CONTINUE;
               }
            }
         }
      }
   }
   if(false == l_found)
   {
      if(1 == mp_sriSubData->m_crbtStatus)
      {
         LLOG(0,0,"CRBT-STATUS is Active and TCSI-DETAILS not found");
         m_tdr.setInteger(TDR_INDEX_CM_SRI_TCSI_STATUS,(int)CM_CRBT_ENABLED_TCSI_NOT_FOUND); 
      }
      else
      {
         LLOG(0,0,"TCSI-DETAILS not found");
         m_tdr.setInteger(TDR_INDEX_CM_SRI_TCSI_STATUS,(int)CM_TCSI_NOT_FOUND_FOR_BS); 
      }

      if(1 == g_CMConfigReaderObj->m_passSriSGInfoNotFound)
      {
         if(0 == mp_sriSubData->m_profType)
         {
            LLOG(0,0,"SIGNAL-INFO not found in BC-Translation Table but Still passing SRI because configured - RoamingInd-0 so prn");
            return CM_FAIL;
         }
         else
         {
            LLOG(0,0,"SIGNAL-INFO not found in BC-Translation Table but Still passing SRI because configured - RoamingInd-1 so psi");
            return CM_CONTINUE;
         }
      }
      else
      {
         g_si.sendSnmpTrap(g_CMtcsiDetailsNotFoundTrap, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL);
         return CM_ERROR;
      }
   }
   else
   {
      if(1 == mp_sriSubData->m_crbtStatus)
      {
         LLOG(0,0,"CRBT-STATUS is Active so continuing from getTcsiStatus");
         m_tdr.setInteger(TDR_INDEX_CM_SRI_TCSI_STATUS,(int)CM_CRBT_ENABLED_TCSI_ACTIVE); 
         return CM_CONTINUE;
      }
      else
      {
         LLOG(0,0,"TCSI-Status is INACTIVE in TCSI-DETAILS");
         m_tdr.setInteger(TDR_INDEX_CM_SRI_TCSI_STATUS,(int)CM_TCSI_INACTIVE_FOR_BS); 
         return CM_FAIL;
      }
   }
}

bool CtxtSendRoutingInfo :: getPsiStatus() // 1.0.3.0
{
  
   if(1 == mp_sriSubData->m_ocsiSuppressFlag) //6430
   {
      LLOG(0,0, "Suppress OCSI flag enabled .. not sending PSI/Location info");
      m_psiInitFlag = 0;
      return false;
   }
   TCSI *lpTcsi = g_spdPtr->m_TCSIMap[m_TcsiProfileId];
   if(m_nonTelephony) // Non-Telephony Calls like Fax Video
   {
      if(0 != mp_sriSubData->m_bsrvcType)
      {
         for(u16 k = 0; k < 5; k++)
         {
            if((lpTcsi->m_bsTcsi[k].m_bsType == mp_sriSubData->m_bsrvcType) && (lpTcsi->m_bsTcsi[k].m_bsCode == mp_sriSubData->m_bsrvcCode))
            {
               m_psiInitFlag = lpTcsi->m_bsTcsi[k].m_psiInitFlag;
               m_psiFailAction = lpTcsi->m_bsTcsi[k].m_psiFailAction;
               LLOG(0,0,"NonTelephony Call PSI status[%d] and failAction[%d]",m_psiInitFlag,m_psiFailAction);
               return true;
            }
         }
      }
   }
   else // Normal Telephony Calls
   {
      for(u16 k = 0; k < 5; k++)
      {
         if(lpTcsi->m_bsTcsi[k].m_bsType == 2) 
         {
            if((lpTcsi->m_bsTcsi[k].m_bsCode == 16) || (lpTcsi->m_bsTcsi[k].m_bsCode == 17))
            {
               m_psiInitFlag = lpTcsi->m_bsTcsi[k].m_psiInitFlag;
               m_psiFailAction = lpTcsi->m_bsTcsi[k].m_psiFailAction;
               LLOG(0,0,"Telephony Call PSI status[%d] and failAction[%d]",m_psiInitFlag,m_psiFailAction);
               return true;
            }
         }
      }
   }
   return false;
}

bool CtxtSendRoutingInfo :: getCC()
{
   DLOG(0,0,"for loop count=%d",g_spdPtr->m_CCRowCount);
   for(u16 k=0; k < g_spdPtr->m_CCRowCount; k++)
   {
      memset(m_CC,'\0',sizeof(m_CC));
      strcpy((s8*)m_CC,(s8*)g_spdPtr->m_CCList[k]); 
      DLOG(0,0,"value of CC |%s| destAddress |%s|",m_CC,m_destAddr);
      if(0 == memcmp(m_destAddr,m_CC,strlen(m_CC)))
      {
         DLOG(0,0,"country code found in destination address:|%s| ",m_CC);
         return true;
      }
   }
   CLOG(0,0,"country code not found in destination address geting CC from first row of HLR_NETWORKS table |%s|",g_spdPtr->m_CCList[0]);
   strcpy((s8*)m_CC,(s8*)g_spdPtr->m_CCList[0]); 
   return true;
}


bool CtxtSendRoutingInfo::handleSRI(Msg *aMsgPtr, u32 aDlgId, EMapVersion aMapVer)
{
   m_InitDlgId = aDlgId;
   m_MapVer = aMapVer;

   DLOG(0,0,"Initiating dialogueId-|%d| mapversion-|%d|",m_InitDlgId,m_MapVer);

   switch(m_MapVer)
   {
      case MAP_V3:
         {
            IMAP3_SendRoutingInfoArg *l_temp = (IMAP3_SendRoutingInfoArg*)(((MapSpecificMsg*)aMsgPtr)->m_structBuffer);
            if(CM_ERROR == checkSRI((void*)l_temp))
            {
               ELOG(0,0,"checksri:V3 failed sending maperror");
               return handleError(); // DataMissing, UnexpectedDataValue
            }
            handleDbQuery();
         }
         break;
      case MAP_V2:
         {
            IMAP2_SendRoutingInfoArg *l_temp = (IMAP2_SendRoutingInfoArg*)(((MapSpecificMsg*)aMsgPtr)->m_structBuffer);
            if(CM_ERROR == checkSRI((void*)l_temp))
            {
               ELOG(0,0,"checksri:V2 failed sending maperror");
               return handleError(); // DataMissing, UnexpectedDataValue
            }
            handleDbQuery();
         }
         break;
      case MAP_V1:
         {
            IMAP1_SendRoutingInformationArg *l_temp = (IMAP1_SendRoutingInformationArg*)(((MapSpecificMsg*)aMsgPtr)->m_structBuffer);
            if(CM_ERROR == checkSRI((void*)l_temp))
            {
               ELOG(0,0,"checksri:V1 failed sending maperror");
               return handleError(); // DataMissing, UnexpectedDataValue
            }
            handleDbQuery();
         }
         break;
      default:
         {
            ELOG(0,0,"invalid mapversion");
            m_ErrCode = MAP_ERROR_systemFailure;
            return handleError();
         }
   }
   return true;
}

bool CtxtSendRoutingInfo :: handleError()
{
   DLOG(0,0,"In HandleError");
   switch(m_ErrCode)
   {
      case MAP_ERROR_systemFailure:
         {
            CLOG(0,0,"sending mapusererror MAP_ERROR_systemFailure on dlgId |%d|",m_InitDlgId);
            m_Utility.sendMapUserError(this,m_ErrCode,m_InitDlgId,m_MapVer,NULL);
         }
         break;
      case MAP_ERROR_unexpectedData:
         {
            CLOG(0,0,"sending mapusererror MAP_ERROR_unexpectedData on dlgId |%d|",m_InitDlgId);
            m_Utility.sendMapUserError(this,m_ErrCode,m_InitDlgId,m_MapVer,NULL);
         }
         break;
      case MAP_ERROR_dataMissing:
         {
            CLOG(0,0,"sending mapusererror MAP_ERROR_dataMissing on dlgId |%d|",m_InitDlgId);
            m_Utility.sendMapUserError(this,m_ErrCode,m_InitDlgId,m_MapVer,NULL);
         }
         break;
      case MAP_ERROR_unknownSubscriber:
         {
            CLOG(0,0,"sending mapusererror MAP_ERROR_unknownSubscriber on dlgId |%d|",m_InitDlgId);
            m_Utility.sendMapUserError(this,m_ErrCode,m_InitDlgId,m_MapVer,NULL);
         }
         break;
      case MAP_ERROR_forwardingViolation:
         {
            CLOG(0,0,"sending mapusererror MAP_ERROR_forwardingViolation on dlgId |%d|",m_InitDlgId);
            m_Utility.sendMapUserError(this,m_ErrCode,m_InitDlgId,m_MapVer,NULL);
         }
         break;
      case MAP_ERROR_facilityNotSup:
         {
            CLOG(0,0,"sending mapusererror MAP_ERROR_facilityNotSup on dlgId |%d|",m_InitDlgId);
            m_Utility.sendMapUserError(this,m_ErrCode,m_InitDlgId,m_MapVer,NULL);
         }
         break;
      case MAP_ERROR_orNotAllowed:
         {
            CLOG(0,0,"sending mapusererror MAP_ERROR_orNotAllowed on dlgId |%d|",m_InitDlgId);
            m_Utility.sendMapUserError(this,m_ErrCode,m_InitDlgId,m_MapVer,NULL);
         }
         break;
      case MAP_ERROR_callBarred:
         {
            s16 l_dbErrCode = mp_sriSubData->m_dbErrCode;
            switch(m_MapVer)
            {
               case MAP_V3:
                  {
                     OMAP3_CallBarredParam l_CallBarred;
                     memset(&l_CallBarred,'\0',sizeof(OMAP3_CallBarredParam));
                     if((l_dbErrCode == -3) || (l_dbErrCode == -4) || (l_dbErrCode == -5))
                     {
                        CLOG(0,0,"sending mapusererror OPERATOR_CALL_BARRED on dlgId |%d|",m_InitDlgId);
                        l_CallBarred.choice = OMAP3_extensibleCallBarredParam_chosen;
                        l_CallBarred.u.extensibleCallBarredParam.bit_mask |= OMAP3_callBarringCause_present;
                        l_CallBarred.u.extensibleCallBarredParam.callBarringCause  = OMAP3_operatorBarring;
                        m_Utility.sendMapUserError(this,m_ErrCode,m_InitDlgId,m_MapVer,&l_CallBarred);
                     }
                     else if((l_dbErrCode == -6) || (l_dbErrCode == -7) || (l_dbErrCode == -8))
                     {
                        CLOG(0,0,"sending mapusererror SS_CALL_BARRED on dlgId |%d|",m_InitDlgId);
                        l_CallBarred.choice = OMAP3_extensibleCallBarredParam_chosen;
                        l_CallBarred.u.extensibleCallBarredParam.bit_mask |= OMAP3_callBarringCause_present;
                        l_CallBarred.u.extensibleCallBarredParam.callBarringCause  = OMAP3_barringServiceActive;
                        m_Utility.sendMapUserError(this,m_ErrCode,m_InitDlgId,m_MapVer,&l_CallBarred);
                     }
                     else
                     {
                        CLOG(0,0,"sending mapusererror MAP_ERROR_callBarred on dlgId |%d|",m_InitDlgId);
                        m_Utility.sendMapUserError(this,m_ErrCode,m_InitDlgId,m_MapVer,NULL);
                     }
                  }
                  break;
               case MAP_V2:
                  {
                     OMAP2_CallBarredParam l_CallBarred;
                     memset(&l_CallBarred,'\0',sizeof(OMAP2_CallBarredParam));
                     if((l_dbErrCode == -3) || (l_dbErrCode == -4) || (l_dbErrCode == -5))
                     {
                        CLOG(0,0,"V2:sending mapusererror OPERATOR_CALL_BARRED on dlgId |%d|",m_InitDlgId);
                        l_CallBarred.choice = OMAP2_callBarringCause_chosen;
                        l_CallBarred.u.callBarringCause  = OMAP2_operatorBarring;
                        m_Utility.sendMapUserError(this,m_ErrCode,m_InitDlgId,m_MapVer,&l_CallBarred);
                     }
                     else if((l_dbErrCode == -6) || (l_dbErrCode == -7) || (l_dbErrCode == -8))
                     {
                        CLOG(0,0,"V2:sending mapusererror SS_CALL_BARRED on dlgId |%d|",m_InitDlgId);
                        l_CallBarred.choice = OMAP2_callBarringCause_chosen;
                        l_CallBarred.u.callBarringCause  = OMAP2_barringServiceActive;
                        m_Utility.sendMapUserError(this,m_ErrCode,m_InitDlgId,m_MapVer,&l_CallBarred);
                     }
                     else
                     {
                        CLOG(0,0,"V2:sending mapusererror MAP_ERROR_callBarred on dlgId |%d|",m_InitDlgId);
                        m_Utility.sendMapUserError(this,m_ErrCode,m_InitDlgId,m_MapVer,NULL);
                     }
                  }
                  break;
               case MAP_V1:
                  {
                     CLOG(0,0,"V1:sending mapusererror MAP_ERROR_callBarred on dlgId |%d|",m_InitDlgId);
                     m_Utility.sendMapUserError(this,m_ErrCode,m_InitDlgId,m_MapVer,NULL);
                  }
                  break;
               default:
                  {
                     CLOG(0,0,"V1:Unknown MapVersion received on dlgId |%d|",m_InitDlgId);
                  }
                  break;
            }
         }
         break;
      case MAP_ERROR_teleservNotProv:
         {
            CLOG(0,0,"sending mapusererror MAP_ERROR_teleservNotProv on dlgId |%d|",m_InitDlgId);
            m_Utility.sendMapUserError(this,m_ErrCode,m_InitDlgId,m_MapVer,NULL);
         }
         break;
      case MAP_ERROR_bearerServNotProv:
         {
            CLOG(0,0,"sending mapusererror MAP_ERROR_bearerServNotProv on dlgId |%d|",m_InitDlgId);
            m_Utility.sendMapUserError(this,m_ErrCode,m_InitDlgId,m_MapVer,NULL);
         }
         break;
      case MAP_ERROR_absentSubscriber:
         {
            CLOG(0,0,"sending mapusererror MAP_ERROR_absentSubscriber on dlgId |%d|",m_InitDlgId);
            m_Utility.sendMapUserError(this,m_ErrCode,m_InitDlgId,m_MapVer,NULL);
         }
         break;
      case MAP_ERROR_CUG_Reject:
         {
            CLOG(0,0,"sending mapusererror MAP_ERROR_CUG_Reject on dlgId |%d|",m_InitDlgId);
            m_Utility.sendMapUserError(this,m_ErrCode,m_InitDlgId,m_MapVer,NULL);
         }
         break;
      default:
         {
            CLOG(0,0,"Default Case of HandleError: sending mapusererror MAP_ERROR_systemFailure on dlgId |%d|",m_InitDlgId);
            m_ErrCode = MAP_ERROR_systemFailure;
            m_Utility.sendMapUserError(this,m_ErrCode,m_InitDlgId,m_MapVer,NULL);
         }
         break;
   }
   m_tdr.setInteger(TDR_INDEX_ERR_CODE,m_ErrCode); 
   return true;
}

void CtxtSendRoutingInfo :: fillCauseValues(OMAP3_GmscCamelSubscriptionInfo *aGmscCamelInfo)
{
   DLOG(0,0," Filling cause values ");
   aGmscCamelInfo->o_BcsmCamelTDP_CriteriaList.count = 1; 
   aGmscCamelInfo->o_BcsmCamelTDP_CriteriaList.value[0].bit_mask |= OMAP3_o_CauseValueCriteria_present;
   aGmscCamelInfo->o_BcsmCamelTDP_CriteriaList.value[0].o_BcsmTriggerDetectionPoint = OMAP3_routeSelectFailure;
   u16 l_cvCount = aGmscCamelInfo->o_BcsmCamelTDP_CriteriaList.value[0].o_CauseValueCriteria.count = aGmscCamelInfo->o_BcsmCamelTDP_CriteriaList.value[1].o_CauseValueCriteria.count;
   for(u16 j=0; j < l_cvCount; ++j)
   {
      aGmscCamelInfo->o_BcsmCamelTDP_CriteriaList.value[0].o_CauseValueCriteria.value[j].length = 1;
      aGmscCamelInfo->o_BcsmCamelTDP_CriteriaList.value[0].o_CauseValueCriteria.value[j].value[0] = aGmscCamelInfo->o_BcsmCamelTDP_CriteriaList.value[1].o_CauseValueCriteria.value[j].value[0];
   }
}

bool CtxtSendRoutingInfo :: sendPSI()
{
   DLOG(0,0,"In SendPsi");
   DECLARE(OMAP3_ProvideSubscriberInfoArg,l_tempPsi,3,"OMAP3_ProvideSubscriberInfoArg",resetStruct);

   u32 l_LocalDlg = g_sc.getNewDialogue();

   if(l_LocalDlg <= 0)
   {
      ELOG(0,0,"GetNewDialouge failed for sendpsi");
      m_ErrCode = MAP_ERROR_systemFailure;
      return handleError();
   }

   MapOpenReq l_mapOpenReq(l_LocalDlg, MAP_V3);
   m_PSIdlgID=l_LocalDlg;
   TLOG(0,0,"created psi dlgid-|%d| and sending psi",m_PSIdlgID);

   configureSccpAddress(&l_mapOpenReq.m_OrigAddr,L_ROUTE_ON_GT,0,g_ConfigData->i_NgConfigData.m_selfAddress.ssn,(s8*)mp_sriSubData->m_prnPsiHlrAddr); 
   configureSccpAddress(&l_mapOpenReq.m_DestAddr,L_ROUTE_ON_GT,0,g_CMConfigReaderObj->m_VlrSSN,(s8*)mp_sriSubData->m_VlrNum); 

   m_tdr.setString(TDR_INDEX_VLR_ADDRESS,(s8*)mp_sriSubData->m_VlrNum); // 1.0.0.4

   l_mapOpenReq.m_ApplCntxt = MAP_AC_CODE_subscriberInfoEnquiry;
   g_sc.sendMsg(this, &l_mapOpenReq);

   DLOG(0,0,"sending psi MapSpecificRequest");
   MapSpecificRequest l_request(l_LocalDlg, MAP_OP_CODE_provideSubscriberInfo, MAP_V3);


   // IMSI MANDATORY PARAM		
   l_tempPsi->imsi.length = StringToBCD(l_tempPsi->imsi.value,mp_sriSubData->m_ActiveImsi,(s32)strlen((s8*)mp_sriSubData->m_ActiveImsi));
   TLOG(0,0,"sendPsi: requesting subscriber state and location info :active imsi-|%s|",mp_sriSubData->m_ActiveImsi);

   // CIRCUIT-SWITCH DOMAIN ... whats the trigger ??	
   l_tempPsi->requestedInfo.bit_mask |= OMAP3_requestedDomain_present; 
   l_tempPsi->requestedInfo.requestedDomain = OMAP3_cs_Domain;

   l_tempPsi->requestedInfo.bit_mask |= OMAP3_RequestedInfo_subscriberState_present; 
   l_tempPsi->requestedInfo.subscriberState = true;

   l_tempPsi->requestedInfo.bit_mask |= OMAP3_RequestedInfo_locationInformation_present; 
   l_tempPsi->requestedInfo.locationInformation = true; 

   if(mp_sriSubData->m_LmsiLen > 0)
   {
      if(mp_sriSubData->m_LmsiLen != 4)
      {
         //ERROR, length is 8 only (in asn structre)
         CLOG(0,0,"LMSI is not 8 characters, so not sending in Psi");
      }
      else
      {
         TLOG_HEX(0,0,"sendPsi: lmsi", (s8*)mp_sriSubData->m_Lmsi,mp_sriSubData->m_LmsiLen);
         l_tempPsi->bit_mask |= OMAP3_ProvideSubscriberInfoArg_lmsi_present;
         l_tempPsi->lmsi.length = 4;
         memcpy(l_tempPsi->lmsi.value,mp_sriSubData->m_Lmsi,4);
         m_tdr.setHex(TDR_INDEX_LMSI,(s8*)mp_sriSubData->m_Lmsi,4);
      }
   }

   l_request.m_structBuffer = (void*)l_tempPsi;
   l_request.m_TimerValue = g_CMConfigReaderObj->m_psiTimer;
   g_sc.sendMsg(this, &l_request);

   DLOG(0,0,"sending PSI Delimiter Req - End of send psi");
   MapDelimiterReq l_del(l_LocalDlg);
   g_sc.sendMsg(this, &l_del);
   return true;
}

bool CtxtSendRoutingInfo :: sendV1PRN()
{
   DLOG(0,0,"In sendPrn:V1");
   DECLARE(OMAP1_ProvideRoamingNumberArg,l_tempPrn,1,"OMAP1_ProvideRoamingNumberArg",resetStruct); // 66

   u32 l_LocalDlg = g_sc.getNewDialogue();

   if(l_LocalDlg <= 0)
   {
      ELOG(0,0,"V1:GetNewDialouge failed for sendprn-V1");
      m_ErrCode = MAP_ERROR_systemFailure;
      return handleError();
   }

   m_PRNdlgID=l_LocalDlg;
   TLOG(0,0,"V1:created prn dlgid-|%d| and sending prn",m_PRNdlgID);

   MapOpenReq l_mapOpenReq(l_LocalDlg, MAP_V1);
   configureSccpAddress(&l_mapOpenReq.m_OrigAddr,L_ROUTE_ON_GT,0,g_ConfigData->i_NgConfigData.m_selfAddress.ssn,(s8*)mp_sriSubData->m_prnPsiHlrAddr); //actual test
   configureSccpAddress(&l_mapOpenReq.m_DestAddr,L_ROUTE_ON_GT,0,g_CMConfigReaderObj->m_VlrSSN,(s8*)mp_sriSubData->m_VlrNum); //actual test

   m_tdr.setString(TDR_INDEX_VLR_ADDRESS,(s8*)mp_sriSubData->m_VlrNum); // 1.0.0.4

   l_mapOpenReq.m_ApplCntxt = MAP_AC_CODE_roamingNbEnquiry;
   g_sc.sendMsg(this, &l_mapOpenReq);

   DLOG(0,0,"V1:sending prn MapSpecificRequest ");
   MapSpecificRequest l_request(l_LocalDlg, MAP_OP_CODE_provideRoamingNumber, MAP_V1);

   // IMSI MANDATORY PARAM		
   l_tempPrn->imsi.length = StringToBCD(l_tempPrn->imsi.value,(u8*)mp_sriSubData->m_ActiveImsi,strlen((s8*)mp_sriSubData->m_ActiveImsi));

   // MSC NUMBER MANDATORY PARAM
   l_tempPrn->mscNumber.value[0] = 0x91; // noa =1, npi =1
   l_tempPrn->mscNumber.length = StringToBCD(&l_tempPrn->mscNumber.value[1],(u8*)mp_sriSubData->m_MscNum,strlen((s8*)mp_sriSubData->m_MscNum));
   l_tempPrn->mscNumber.length++;
   TLOG(0,0,"V1:sendPrn: active imsi-|%s| mscnumber-|%s|",mp_sriSubData->m_ActiveImsi,mp_sriSubData->m_MscNum);

   if(strlen((s8*)mp_sriSubData->m_ActiveMsisdn) > 1)
   {
      TLOG(0,0,"V1:sendPrn: active msisdn-|%s|",mp_sriSubData->m_ActiveMsisdn);
      l_tempPrn->bit_mask |= OMAP1_ProvideRoamingNumberArg_msIsdn_present;
      // (0x80 | (((noa << 4) & 0x70) | (npi & 0x0f)))
      l_tempPrn->msIsdn.value[0] = 0x91; // noa =1 , npi =1
      l_tempPrn->msIsdn.length = StringToBCD(&l_tempPrn->msIsdn.value[1],(u8*)mp_sriSubData->m_ActiveMsisdn,strlen((s8*)mp_sriSubData->m_ActiveMsisdn));
      l_tempPrn->msIsdn.length++;
   }

   if(mp_sriSubData->m_LmsiLen > 0)
   {
      if(mp_sriSubData->m_LmsiLen != 4)
      {
         //ERROR, length is 8 only (in asn structre)
         CLOG(0,0,"V1:LMSI is not 8 characters, so not sending in Prn");
      }
      else
      {
         TLOG_HEX(0,0,"sendPrn: lmsi", (s8*)mp_sriSubData->m_Lmsi,mp_sriSubData->m_LmsiLen);
         l_tempPrn->bit_mask |= OMAP1_ProvideRoamingNumberArg_lmsi_present;
         l_tempPrn->lmsi.length = 4;
         memcpy(l_tempPrn->lmsi.value,mp_sriSubData->m_Lmsi,4);
         m_tdr.setHex(TDR_INDEX_LMSI,(s8*)mp_sriSubData->m_Lmsi,4);
      }
   }

   if(m_networkSigInfo) // NETWORK SIGNAL INFO
   {
      if((1 == mp_sriSubData->m_bcFlag)  && (mp_sriSubData->m_bearerCapLen > 1))
      {
         LLOG_HEX(0,0,"V1:sendPrn: BearerCapability Data", (s8*)mp_sriSubData->m_bearerCap,mp_sriSubData->m_bearerCapLen);
         l_tempPrn->bit_mask |= OMAP1_ProvideRoamingNumberArg_gSM_BearerCapability_present;
         l_tempPrn->gSM_BearerCapability.protocolId = OMAP1_gsm_0408;
         memcpy(l_tempPrn->gSM_BearerCapability.signalInfo.value,mp_sriSubData->m_bearerCap,mp_sriSubData->m_bearerCapLen);
         l_tempPrn->gSM_BearerCapability.signalInfo.length = mp_sriSubData->m_bearerCapLen;
      }
      else
      {
         TLOG_HEX(0,0,"V1:sendPrn: NetworkSignalInfo", (s8*)signalInfo.value, signalInfo.length);
         l_tempPrn->bit_mask |= OMAP1_ProvideRoamingNumberArg_networkSignalInfo_present;
         l_tempPrn->networkSignalInfo.protocolId =  (OMAP1_ProtocolId)protocolId;
         memcpy(l_tempPrn->networkSignalInfo.signalInfo.value,signalInfo.value,signalInfo.length);
         l_tempPrn->networkSignalInfo.signalInfo.length = signalInfo.length;
      }
   }

   l_request.m_structBuffer = (void*)l_tempPrn;
   l_request.m_TimerValue = g_CMConfigReaderObj->m_prnTimer;
   g_sc.sendMsg(this, &l_request);

   DLOG(0,0,"V1:sending prn Delimiter Req  End Of send prn");
   MapDelimiterReq l_del(l_LocalDlg);
   g_sc.sendMsg(this, &l_del);
   return true;
}

bool CtxtSendRoutingInfo :: sendV2PRN()
{
   DLOG(0,0,"In sendPrn-V2");
   DECLARE(OMAP2_ProvideRoamingNumberArg,l_tempPrn,2,"OMAP2_ProvideRoamingNumberArg",resetStruct); // 66

   u32 l_LocalDlg = g_sc.getNewDialogue();

   if(l_LocalDlg <= 0)
   {
      ELOG(0,0,"V2:GetNewDialouge failed for sendprn-V2");
      m_ErrCode = MAP_ERROR_systemFailure;
      return handleError();
   }

   m_PRNdlgID=l_LocalDlg;
   TLOG(0,0,"V2:created prn dlgid-|%d| and sending prn",m_PRNdlgID);

   MapOpenReq l_mapOpenReq(l_LocalDlg, MAP_V2);
   configureSccpAddress(&l_mapOpenReq.m_OrigAddr,L_ROUTE_ON_GT,0,g_ConfigData->i_NgConfigData.m_selfAddress.ssn,(s8*)mp_sriSubData->m_prnPsiHlrAddr); //actual test
   configureSccpAddress(&l_mapOpenReq.m_DestAddr,L_ROUTE_ON_GT,0,g_CMConfigReaderObj->m_VlrSSN,(s8*)mp_sriSubData->m_VlrNum); //actual test

   m_tdr.setString(TDR_INDEX_VLR_ADDRESS,(s8*)mp_sriSubData->m_VlrNum); // 1.0.0.4

   //l_mapOpenReq.m_DestAddr  = g_ConfigData->i_NgConfigData.m_remoteAddress1;// only for simulator test
   l_mapOpenReq.m_ApplCntxt = MAP_AC_CODE_roamingNbEnquiry;
   g_sc.sendMsg(this, &l_mapOpenReq);

   DLOG(0,0,"V2:sending prn MapSpecificRequest ");
   MapSpecificRequest l_request(l_LocalDlg, MAP_OP_CODE_provideRoamingNumber, MAP_V2);


   // IMSI MANDATORY PARAM		
   l_tempPrn->imsi.length = StringToBCD(l_tempPrn->imsi.value,(u8*)mp_sriSubData->m_ActiveImsi,strlen((s8*)mp_sriSubData->m_ActiveImsi));

   // MSC NUMBER MANDATORY PARAM
   // (0x80 | (((noa << 4) & 0x70) | (npi & 0x0f)))
   l_tempPrn->msc_Number.value[0] = 0x91; // noa =1, npi =1
   l_tempPrn->msc_Number.length = StringToBCD(&l_tempPrn->msc_Number.value[1],(u8*)mp_sriSubData->m_MscNum,strlen((s8*)mp_sriSubData->m_MscNum));
   l_tempPrn->msc_Number.length++;
   TLOG(0,0,"V2:sendPrn: active imsi-|%s| mscnumber-|%s|",mp_sriSubData->m_ActiveImsi,mp_sriSubData->m_MscNum);

   if(strlen((s8*)mp_sriSubData->m_ActiveMsisdn) > 1)
   {
      TLOG(0,0,"V2:sendPrn: active msisdn-|%s|",mp_sriSubData->m_ActiveMsisdn);
      l_tempPrn->bit_mask |= OMAP2_ProvideRoamingNumberArg_msisdn_present;
      // (0x80 | (((noa << 4) & 0x70) | (npi & 0x0f)))
      l_tempPrn->msisdn.value[0] = 0x91; // noa =1 , npi =1
      l_tempPrn->msisdn.length = StringToBCD(&l_tempPrn->msisdn.value[1],(u8*)mp_sriSubData->m_ActiveMsisdn,strlen((s8*)mp_sriSubData->m_ActiveMsisdn));
      l_tempPrn->msisdn.length++;
   }

   if(mp_sriSubData->m_LmsiLen > 0)
   {
      if(mp_sriSubData->m_LmsiLen != 4)
      {
         //ERROR, length is 8 only (in asn structre)
         CLOG(0,0,"V2:LMSI is not 8 characters, so not sending in Prn");
      }
      else
      {
         TLOG_HEX(0,0,"sendPrn: lmsi", (s8*)mp_sriSubData->m_Lmsi,mp_sriSubData->m_LmsiLen);
         l_tempPrn->bit_mask |= OMAP2_ProvideRoamingNumberArg_lmsi_present;
         l_tempPrn->lmsi.length = 4;
         memcpy(l_tempPrn->lmsi.value,mp_sriSubData->m_Lmsi,4);
         m_tdr.setHex(TDR_INDEX_LMSI,(s8*)mp_sriSubData->m_Lmsi,4);
      }
   }

   if(m_networkSigInfo) // NETWORK SIGNAL INFO
   {
      if((1 == mp_sriSubData->m_bcFlag)  && (mp_sriSubData->m_bearerCapLen > 1))
      {
         LLOG_HEX(0,0,"V2:sendPrn: BearerCapability Data", (s8*)mp_sriSubData->m_bearerCap,mp_sriSubData->m_bearerCapLen);
         l_tempPrn->bit_mask |= OMAP2_gsm_BearerCapability_present;
         l_tempPrn->gsm_BearerCapability.protocolId = OMAP2_gsm_0408;
         memcpy(l_tempPrn->gsm_BearerCapability.signalInfo.value,mp_sriSubData->m_bearerCap,mp_sriSubData->m_bearerCapLen);
         l_tempPrn->gsm_BearerCapability.signalInfo.length = mp_sriSubData->m_bearerCapLen;
      }
      else
      {
         TLOG_HEX(0,0,"V2:sendPrn: NetworkSignalInfo", (s8*)signalInfo.value, signalInfo.length);
         l_tempPrn->bit_mask |= OMAP2_ProvideRoamingNumberArg_networkSignalInfo_present;
         l_tempPrn->networkSignalInfo.protocolId =  (OMAP2_ProtocolId)protocolId;
         memcpy(l_tempPrn->networkSignalInfo.signalInfo.value,signalInfo.value,signalInfo.length);
         l_tempPrn->networkSignalInfo.signalInfo.length = signalInfo.length;
      }
   }

   l_request.m_structBuffer = (void*)l_tempPrn;
   l_request.m_TimerValue = g_CMConfigReaderObj->m_prnTimer;
   g_sc.sendMsg(this, &l_request);

   DLOG(0,0,"V2:sending prn Delimiter Req  End Of send prn");
   MapDelimiterReq l_del(l_LocalDlg);
   g_sc.sendMsg(this, &l_del);
   return true;
}

bool CtxtSendRoutingInfo :: sendPRN()
{
   DLOG(0,0,"In sendPrn");
   DECLARE(OMAP3_ProvideRoamingNumberArg,l_tempPrn,3,"OMAP3_ProvideRoamingNumberArg",resetStruct); // 66

   u32 l_LocalDlg = g_sc.getNewDialogue();

   if(l_LocalDlg <= 0)
   {
      ELOG(0,0,"GetNewDialouge failed for sendprn");
      m_ErrCode = MAP_ERROR_systemFailure;
      return handleError();
   }

   m_PRNdlgID=l_LocalDlg;
   TLOG(0,0,"created prn dlgid-|%d| and sending prn",m_PRNdlgID);

   MapOpenReq l_mapOpenReq(l_LocalDlg, MAP_V3);
   configureSccpAddress(&l_mapOpenReq.m_OrigAddr,L_ROUTE_ON_GT,0,g_ConfigData->i_NgConfigData.m_selfAddress.ssn,(s8*)mp_sriSubData->m_prnPsiHlrAddr); //actual test
   configureSccpAddress(&l_mapOpenReq.m_DestAddr,L_ROUTE_ON_GT,0,g_CMConfigReaderObj->m_VlrSSN,(s8*)mp_sriSubData->m_VlrNum); //actual test

   m_tdr.setString(TDR_INDEX_VLR_ADDRESS,(s8*)mp_sriSubData->m_VlrNum); // 1.0.0.4

   //l_mapOpenReq.m_DestAddr  = g_ConfigData->i_NgConfigData.m_remoteAddress1;// only for simulator test
   l_mapOpenReq.m_ApplCntxt = MAP_AC_CODE_roamingNbEnquiry;
   g_sc.sendMsg(this, &l_mapOpenReq);

   DLOG(0,0,"sending prn MapSpecificRequest ");
   MapSpecificRequest l_request(l_LocalDlg, MAP_OP_CODE_provideRoamingNumber, MAP_V3);


   // IMSI MANDATORY PARAM		
   l_tempPrn->imsi.length = StringToBCD(l_tempPrn->imsi.value,(u8*)mp_sriSubData->m_ActiveImsi,strlen((s8*)mp_sriSubData->m_ActiveImsi));

   // MSC NUMBER MANDATORY PARAM
   // (0x80 | (((noa << 4) & 0x70) | (npi & 0x0f)))
   l_tempPrn->msc_Number.value[0] = 0x91; // noa =1, npi =1
   l_tempPrn->msc_Number.length = StringToBCD(&l_tempPrn->msc_Number.value[1],(u8*)mp_sriSubData->m_MscNum,strlen((s8*)mp_sriSubData->m_MscNum));
   l_tempPrn->msc_Number.length++;
   TLOG(0,0,"sendPrn: active imsi-|%s| mscnumber-|%s|",mp_sriSubData->m_ActiveImsi,mp_sriSubData->m_MscNum);

   if(strlen((s8*)mp_sriSubData->m_ActiveMsisdn) > 1)
   {
      TLOG(0,0,"sendPrn: active msisdn-|%s|",mp_sriSubData->m_ActiveMsisdn);
      l_tempPrn->bit_mask |= OMAP3_ProvideRoamingNumberArg_msisdn_present;
      // (0x80 | (((noa << 4) & 0x70) | (npi & 0x0f)))
      l_tempPrn->msisdn.value[0] = 0x91; // noa =1 , npi =1
      l_tempPrn->msisdn.length = StringToBCD(&l_tempPrn->msisdn.value[1],(u8*)mp_sriSubData->m_ActiveMsisdn,strlen((s8*)mp_sriSubData->m_ActiveMsisdn));
      l_tempPrn->msisdn.length++;
   }

   if(m_CallRefNumLen > 0)  // CALL_REFERENCE_NUMBER  
   {
      TLOG_HEX(0,0,"sendPrn: CallReferenceNumber",(s8*)m_CallRefNum,m_CallRefNumLen);
      l_tempPrn->bit_mask |= OMAP3_ProvideRoamingNumberArg_callReferenceNumber_present;
      l_tempPrn->callReferenceNumber.length = m_CallRefNumLen;
      memcpy(l_tempPrn->callReferenceNumber.value,m_CallRefNum,m_CallRefNumLen);
   }

   if(m_AlertPatternLen > 0)  // ALERTING PATTERN
   {
      TLOG(0,0,"sendPrn: alertpattern-|%d|",m_AlertPatternValue);
      l_tempPrn->bit_mask |= OMAP3_ProvideRoamingNumberArg_alertingPattern_present;
      l_tempPrn->alertingPattern.value[0] = m_AlertPatternValue;
      l_tempPrn->alertingPattern.length = m_AlertPatternLen; // should be 1
   }

   if(mp_sriSubData->m_LmsiLen > 0)
   {
      if(mp_sriSubData->m_LmsiLen != 4)
      {
         //ERROR, length is 8 only (in asn structre)
         CLOG(0,0,"LMSI is not 8 characters, so not sending in Prn");
      }
      else
      {
         TLOG_HEX(0,0,"sendPrn: lmsi", (s8*)mp_sriSubData->m_Lmsi,mp_sriSubData->m_LmsiLen);
         l_tempPrn->bit_mask |= OMAP3_ProvideRoamingNumberArg_lmsi_present;
         l_tempPrn->lmsi.length = 4;
         memcpy(l_tempPrn->lmsi.value,mp_sriSubData->m_Lmsi,4);
         m_tdr.setHex(TDR_INDEX_LMSI,(s8*)mp_sriSubData->m_Lmsi,4);
      }
   }

   if(m_GmscOrGsmScfLen > 0) // GMSC ADDRESS
   {
      TLOG(0,0,"sendPrn: gmscaddress-|%s|",m_GmscOrGsmScfVal);
      l_tempPrn->bit_mask |= OMAP3_gmsc_Address_present;
      // (0x80 | (((noa << 4) & 0x70) | (npi & 0x0f)))
      //l_tempPrn->gmsc_Address.value[0] = 0x91; // noa =1, npi =1
      memcpy(l_tempPrn->gmsc_Address.value,m_gmscNaiNpi,1);
      l_tempPrn->gmsc_Address.length = StringToBCD(&l_tempPrn->gmsc_Address.value[1],(u8*)m_GmscOrGsmScfVal,m_GmscOrGsmScfLen);
      l_tempPrn->gmsc_Address.length++;
   }

   if(m_suppOfAnnouncementFlag) // SUPPRESSION OF ANNOUNCEMENT
   {
      TLOG(0,0,"sendPrn: suppression of announcement flag-|%d|",m_suppOfAnnouncement);
      l_tempPrn->bit_mask |= OMAP3_ProvideRoamingNumberArg_suppressionOfAnnouncement_present;
      l_tempPrn->suppressionOfAnnouncement = m_suppOfAnnouncement;
   }

   /// test BearerCapability ///
#if 0
   if(1/*m_networkSigInfo*/)
   {
      l_tempPrn->bit_mask |= OMAP3_ProvideRoamingNumberArg_gsm_BearerCapability_present;
      l_tempPrn->gsm_BearerCapability.protocolId = OMAP3_gsm_0408;
      l_tempPrn->gsm_BearerCapability.signalInfo.length = 3;
      l_tempPrn->gsm_BearerCapability.signalInfo.value[0] = 0x04;
      l_tempPrn->gsm_BearerCapability.signalInfo.value[1] = 0x01;
      l_tempPrn->gsm_BearerCapability.signalInfo.value[2] = 0xA0;
   }
#endif
   /////////////////////////////

   if(m_networkSigInfo) // NETWORK SIGNAL INFO
   {
      if((1 == mp_sriSubData->m_bcFlag)  && (mp_sriSubData->m_bearerCapLen > 1))
      {
         LLOG_HEX(0,0,"sendPrn: BearerCapability Data", (s8*)mp_sriSubData->m_bearerCap,mp_sriSubData->m_bearerCapLen);
         l_tempPrn->bit_mask |= OMAP3_ProvideRoamingNumberArg_gsm_BearerCapability_present;
         l_tempPrn->gsm_BearerCapability.protocolId = OMAP3_gsm_0408;
         memcpy(l_tempPrn->gsm_BearerCapability.signalInfo.value,mp_sriSubData->m_bearerCap,mp_sriSubData->m_bearerCapLen);
         l_tempPrn->gsm_BearerCapability.signalInfo.length = mp_sriSubData->m_bearerCapLen;
      }
      else
      {
         TLOG_HEX(0,0,"sendPrn: NetworkSignalInfo", (s8*)signalInfo.value, signalInfo.length);
         l_tempPrn->bit_mask |= OMAP3_ProvideRoamingNumberArg_networkSignalInfo_present;
         l_tempPrn->networkSignalInfo.protocolId =  protocolId;
         memcpy(l_tempPrn->networkSignalInfo.signalInfo.value,signalInfo.value,signalInfo.length);
         l_tempPrn->networkSignalInfo.signalInfo.length = signalInfo.length;
      }
   }


   TLOG(0,0,"sendPrn: supported camel phases in gmsc-|%x|",m_suppGmscCamelPhase);
   l_tempPrn->bit_mask |= OMAP3_supportedCamelPhasesInInterrogatingNode_present;
   l_tempPrn->supportedCamelPhasesInInterrogatingNode.length = getNumberOfSignificantBitsForAByte(m_suppGmscCamelPhase);
   l_tempPrn->supportedCamelPhasesInInterrogatingNode.value[0] = m_suppGmscCamelPhase;

   if(m_OfferedCamelPhase) // OFFEREDCAMEL4CSIs 
   {
      TLOG(0,0,"sendPrn: offered camel phases-|%x|",m_OfferedCamelPhaseVal);
      l_tempPrn->bit_mask |= OMAP3_offeredCamel4CSIsInInterrogatingNode_present;
      l_tempPrn->offeredCamel4CSIsInInterrogatingNode.length = getNumberOfSignificantBitsForAByte(m_suppGmscCamelPhase);
      l_tempPrn->offeredCamel4CSIsInInterrogatingNode.value[0] = m_OfferedCamelPhaseVal; 
   }

   /// OR NOT SUPPORTED IN GMSC  ( if supported facility not supported USER ERRROR would have gone in checkSRI )
   l_tempPrn->bit_mask |= OMAP3_orNotSupportedInGMSC_present;
   l_tempPrn->orNotSupportedInGMSC = true;
   DLOG(0,0,"sending Or-Not-Supported in prn");
   ////////////////////////////////////////////////////////////////////////////////////////////////////////////

   if(m_RoamingRetrySupportFlag) //ROAMINGRETRYSUPPORT
   {
      if(1 == g_CMConfigReaderObj->m_roamingRetrySupportFlag)
      {
         l_tempPrn->bit_mask |= OMAP3_ProvideRoamingNumberArg_mtRoamingRetrySupported_present;
         l_tempPrn->mtRoamingRetrySupported = true;
         LLOG(0,0,"sendPrn: RoamingRetrySupport");
      }
      else
      {
         LLOG(0,0,"sendPrn: RoamingRetrySupport present but not sending as not configured");
      }
   }

   /*if(m_longFtnSupportFlag) //LONG FTN SUPPORT  // 2.0.7.0
     {
     l_tempPrn->bit_mask |= OMAP3_ProvideRoamingNumberArg_longFTN_Supported_present;
     l_tempPrn->longFTN_Supported = true;
     LLOG(0,0,"sendPrn: LongFTNSupport");
     }*/

   if(1 == mp_sriSubData->m_decodeExtContFlag)
   {
      if(true == m_extensionDataPresent)
      {
         LLOG(0,0,"sending calling party number in additional signalinfo of PRN");
         l_tempPrn->bit_mask |= OMAP3_ProvideRoamingNumberArg_additionalSignalInfo_present;
         l_tempPrn->additionalSignalInfo.ext_ProtocolId = OMAP3_ets_300356;
         memcpy(l_tempPrn->additionalSignalInfo.signalInfo.value,m_asiginfo,m_asiginfo[1]+2);
         l_tempPrn->additionalSignalInfo.signalInfo.length = m_asiginfo[1]+2;

         m_additionalSigInfo = false; // not to send below relay of addsiginfo as we are overriding it
      }
      else
      {
         TLOG(0,0,"sendPrn: Clip Over Map flag set for GMSC but extenstionData not present");
      }
   }
   else
   {
      TLOG(0,0,"sendPrn: Clip Over Map flag not set for the GMSC");
   }

   if(m_additionalSigInfo) // ADDITIONAL SIGNAL INFO
   {
      TLOG_HEX(0,0,"sendPrn: AdditionalSignalInfo", (s8*)signalInfo2.value, signalInfo2.length);
      l_tempPrn->bit_mask |= OMAP3_ProvideRoamingNumberArg_additionalSignalInfo_present;
      l_tempPrn->additionalSignalInfo.ext_ProtocolId =  ext_ProtocolId;
      //strncpy((s8*)l_tempPrn->additionalSignalInfo.signalInfo.value,(s8*)signalInfo2.value,signalInfo2.length);
      memcpy(l_tempPrn->additionalSignalInfo.signalInfo.value,signalInfo2.value,signalInfo2.length);
      l_tempPrn->additionalSignalInfo.signalInfo.length = signalInfo2.length;
   }

   l_request.m_structBuffer = (void*)l_tempPrn;
   l_request.m_TimerValue = g_CMConfigReaderObj->m_prnTimer;
   g_sc.sendMsg(this, &l_request);

   DLOG(0,0,"sending prn Delimiter Req  End Of send prn");
   MapDelimiterReq l_del(l_LocalDlg);
   g_sc.sendMsg(this, &l_del);
   return true;
}

bool CtxtSendRoutingInfo :: sendSRIResPRN(Msg *aMsgPtr)
{
   IMAP3_ISDN_AddressString *aPRNRes = NULL;
   if(3 == m_sentPrnVer)
      aPRNRes = &(((IMAP3_ProvideRoamingNumberRes*)(((MapSpecificMsg*)aMsgPtr)->m_structBuffer))->roamingNumber);
   else if(2 == m_sentPrnVer)
      aPRNRes = (IMAP3_ISDN_AddressString*)&((((IMAP2_ProvideRoamingNumberRes*)(((MapSpecificMsg*)aMsgPtr)->m_structBuffer))->roamingNumber));
   else
#ifdef SunOS
      aPRNRes = (IMAP3_ISDN_AddressString*)&((((IMAP1_ProvideRoamingNumberRes*)(((MapSpecificMsg*)aMsgPtr)->m_structBuffer))->roamingNumber));
#else
   aPRNRes = (IMAP3_ISDN_AddressString*)(((MapSpecificMsg*)aMsgPtr)->m_structBuffer);
#endif

   switch(m_MapVer)
   {
      case MAP_V3:
         {
            DLOG(0,0,"In SendSriResPrn-V3");

            DECLARE(OMAP3_SendRoutingInfoRes,l_tempSRIResPRN,3,"OMAP3_SendRoutingInfoRes",resetStruct);

            if(aPRNRes->length > 0 ) // u get RoamingNum in BCD sending as it is in SRIRes ( no conversions )
            {		 
               TLOG_HEX(0,0,"SriResPrn: Msrn", (s8*)aPRNRes->value,aPRNRes->length);
               m_tdr.setHex(TDR_INDEX_CM_SRI_MSRN,(s8*)aPRNRes->value,aPRNRes->length);

               l_tempSRIResPRN->bit_mask |= OMAP3_SendRoutingInfoRes_imsi_present;

               TLOG(0,0,"SriResPrn: imsi + roamingnumber + suppCphVmsc - SRIImsi:|%s|",m_SriImsi); 
               l_tempSRIResPRN->imsi.length = StringToBCD(l_tempSRIResPRN->imsi.value,(u8*)m_SriImsi,(s32)strlen((char*)m_SriImsi));

               l_tempSRIResPRN->bit_mask |= OMAP3_extendedRoutingInfo_present;
               l_tempSRIResPRN->extendedRoutingInfo.choice = OMAP3_routingInfo_chosen;
               l_tempSRIResPRN->extendedRoutingInfo.u.routingInfo.choice = OMAP3_roamingNumber_chosen;

               l_tempSRIResPRN->extendedRoutingInfo.u.routingInfo.u.roamingNumber.length = aPRNRes->length;
               memcpy(l_tempSRIResPRN->extendedRoutingInfo.u.routingInfo.u.roamingNumber.value,aPRNRes->value,aPRNRes->length);
               m_Utility.getSuppCamelPhsVmsc(l_tempSRIResPRN,mp_sriSubData);
            }
            else
            {
               CLOG(0,0,"SriResPrn: roamingnumber length is less than zero so closing the sri dialogue");
               MapCloseReq l_closeReq(m_InitDlgId);
               g_sc.sendMsg(this, &l_closeReq);
               return true;
            }
            return m_Utility.sendSRIRESULTLAST(this,m_InitDlgId,MAP_OP_CODE_sendRoutingInfo,MAP_V3,l_tempSRIResPRN);
         }
         break;
      case MAP_V2:
         {
            DLOG(0,0,"In SendSriResPrn-V2");

            DECLARE(OMAP2_SendRoutingInfoRes,l_tempSRIResPRN,2,"OMAP2_SendRoutingInfoRes",resetStruct);

            if(aPRNRes->length > 0 ) // u get RoamingNum in BCD sending as it is in SRIRes ( no conversions )
            {		 
               LLOG_HEX(0,0,"V2:SriResPrn: Msrn", (s8*)aPRNRes->value,aPRNRes->length);
               m_tdr.setHex(TDR_INDEX_CM_SRI_MSRN,(s8*)aPRNRes->value,aPRNRes->length);

               TLOG(0,0,"V2:SriResPrn: imsi + roamingnumber + suppCphVmsc - SRIImsi:|%s|",m_SriImsi); 
               l_tempSRIResPRN->imsi.length = StringToBCD(l_tempSRIResPRN->imsi.value,(u8*)m_SriImsi,(s32)strlen((char*)m_SriImsi));

               l_tempSRIResPRN->routingInfo.choice = OMAP2_RoutingInfo_roamingNumber_chosen;

               l_tempSRIResPRN->routingInfo.u.roamingNumber.length = aPRNRes->length;
               memcpy(l_tempSRIResPRN->routingInfo.u.roamingNumber.value,aPRNRes->value,aPRNRes->length);
            }
            else
            {
               CLOG(0,0,"SriResPrn: roamingnumber length is less than zero so closing the sri dialogue");
               MapCloseReq l_closeReq(m_InitDlgId);
               g_sc.sendMsg(this, &l_closeReq);
               return true;
            }
            return m_Utility.sendSRIRESULTLAST(this,m_InitDlgId,MAP_OP_CODE_sendRoutingInfo,MAP_V2,l_tempSRIResPRN);
         }
         break;
      case MAP_V1:
         {
            DLOG(0,0,"In SendSriResPrn-V1");

            DECLARE(OMAP1_SendRoutingInformationRes,l_tempSRIResPRN,1,"OMAP1_SendRoutingInformationRes",resetStruct);

            if(aPRNRes->length > 0 ) // u get RoamingNum in BCD sending as it is in SRIRes ( no conversions )
            {		 
               LLOG_HEX(0,0,"V1:SriResPrn: Msrn", (s8*)aPRNRes->value,aPRNRes->length);
               m_tdr.setHex(TDR_INDEX_CM_SRI_MSRN,(s8*)aPRNRes->value,aPRNRes->length);

               TLOG(0,0,"V1:SriResPrn: imsi + roamingnumber + suppCphVmsc - SRIImsi:|%s|",m_SriImsi); 
               l_tempSRIResPRN->imsi.length = StringToBCD(l_tempSRIResPRN->imsi.value,(u8*)m_SriImsi,(s32)strlen((char*)m_SriImsi));

               l_tempSRIResPRN->routingInfo.choice = OMAP1_routingInfo_roamingNumber_chosen;

               l_tempSRIResPRN->routingInfo.u.roamingNumber.length = aPRNRes->length;
               memcpy(l_tempSRIResPRN->routingInfo.u.roamingNumber.value,aPRNRes->value,aPRNRes->length);
            }
            else
            {
               CLOG(0,0,"V1:SriResPrn: roaming number length is less than zero so closing the sri dialogue");
               MapCloseReq l_closeReq(m_InitDlgId);
               g_sc.sendMsg(this, &l_closeReq);
            }
            return m_Utility.sendSRIRESULTLAST(this,m_InitDlgId,MAP_OP_CODE_sendRoutingInfo,MAP_V1,l_tempSRIResPRN);
         }
         break;
      default:
         {
            LLOG(0,0,"Unknown MapVersion received");
         }
         break;
   }
   return true;
}

bool CtxtSendRoutingInfo :: sendSRIResOnlyFTN()
{
   switch(m_MapVer)
   {
      case MAP_V3:
         {
            DLOG(0,0,"In SendSriResOnlyFtn");
            DECLARE(OMAP3_SendRoutingInfoRes,l_tempSRIResOnlyFTN,3,"OMAP3_SendRoutingInfoRes",resetStruct);
            l_tempSRIResOnlyFTN->bit_mask |= OMAP3_SendRoutingInfoRes_imsi_present;

            LLOG(0,0,"SriResOnlyFtn: imsi + ftn - SriImsi:|%s|",m_SriImsi); 
            l_tempSRIResOnlyFTN->imsi.length = StringToBCD(l_tempSRIResOnlyFTN->imsi.value,(u8*)m_SriImsi,(s32)strlen((char*)m_SriImsi));
            createSRIResFTN(&mp_sriSubData->m_fwdInfo,l_tempSRIResOnlyFTN,false);

            m_Utility.getSuppCamelPhsVmsc(l_tempSRIResOnlyFTN,mp_sriSubData);
            return m_Utility.sendSRIRESULTLAST(this,m_InitDlgId,MAP_OP_CODE_sendRoutingInfo,MAP_V3,l_tempSRIResOnlyFTN);
         }
         break;
      case MAP_V2:
         {
            DLOG(0,0,"In SendSriResOnlyFtn-V2");
            DECLARE(OMAP2_SendRoutingInfoRes,l_tempSRIResOnlyFTN,2,"OMAP2_SendRoutingInfoRes",resetStruct);

            LLOG(0,0,"V2:SriResOnlyFtn: imsi + ftn - SriImsi:|%s|",m_SriImsi); 
            l_tempSRIResOnlyFTN->imsi.length = StringToBCD(l_tempSRIResOnlyFTN->imsi.value,(u8*)m_SriImsi,(s32)strlen((char*)m_SriImsi));
            createSRIResFTN(&mp_sriSubData->m_fwdInfo,l_tempSRIResOnlyFTN,false);
            return m_Utility.sendSRIRESULTLAST(this,m_InitDlgId,MAP_OP_CODE_sendRoutingInfo,MAP_V2,l_tempSRIResOnlyFTN);
         }
         break;
      case MAP_V1:
         {
            DLOG(0,0,"In SendSriResOnlyFtn-V1");
            DECLARE(OMAP1_SendRoutingInformationRes,l_tempSRIResOnlyFTN,1,"OMAP1_SendRoutingInformationRes",resetStruct);

            LLOG(0,0,"V1:SriResOnlyFtn: imsi + ftn - SriImsi:|%s|",m_SriImsi); 
            l_tempSRIResOnlyFTN->imsi.length = StringToBCD(l_tempSRIResOnlyFTN->imsi.value,(u8*)m_SriImsi,(s32)strlen((char*)m_SriImsi));

            createSRIResFTN(&mp_sriSubData->m_fwdInfo,l_tempSRIResOnlyFTN,false);
            return m_Utility.sendSRIRESULTLAST(this,m_InitDlgId,MAP_OP_CODE_sendRoutingInfo,MAP_V1,l_tempSRIResOnlyFTN);
         }
         break;
      default:
         {
            LLOG(0,0,"Unknown MapVersion received");
         }
         break;
   }
   return true;
}

bool CtxtSendRoutingInfo :: sendSRIResFTNCSI()
{
   DLOG(0,0,"In SendSriResFtnCsi");
   DECLARE(OMAP3_SendRoutingInfoRes,l_tempSRIResFTNCSI,3,"OMAP3_SendRoutingInfoRes",resetStruct);

   OMAP3_GmscCamelSubscriptionInfo *l_gmscCamelInfo = &l_tempSRIResFTNCSI->extendedRoutingInfo.u.camelRoutingInfo.gmscCamelSubscriptionInfo;

   bool l_oCriteria = false;

   l_oCriteria = fillOCSI(m_OcsiProfileId,l_gmscCamelInfo);

   l_tempSRIResFTNCSI->bit_mask |= OMAP3_SendRoutingInfoRes_imsi_present;

   LLOG(0,0,"SriResFtnCsi: ftn and ocsi SRIImsi:|%s|",m_SriImsi);
   l_tempSRIResFTNCSI->imsi.length = StringToBCD(l_tempSRIResFTNCSI->imsi.value,(u8*)m_SriImsi,(s32)strlen((s8*)m_SriImsi));
   l_tempSRIResFTNCSI->bit_mask |= OMAP3_extendedRoutingInfo_present;
   l_tempSRIResFTNCSI->extendedRoutingInfo.choice =  OMAP3_camelRoutingInfo_chosen;

   createSRIResFTN(&mp_sriSubData->m_fwdInfo,l_tempSRIResFTNCSI,true); // true indicates FTN is filled in CamelRoutingInfo

   if(l_oCriteria)
   {
      bool l_dncEnabled = false;
      bool l_cvEnabled = false;

      if(l_gmscCamelInfo->o_BcsmCamelTDP_CriteriaList.value[1].bit_mask & OMAP3_o_CauseValueCriteria_present)
      {
         l_gmscCamelInfo->o_BcsmCamelTDP_CriteriaList.count = 1; // test
         //l_gmscCamelInfo->o_BcsmCamelTDP_CriteriaList.value[1].bit_mask &= (~OMAP3_o_CauseValueCriteria_present);
         l_cvEnabled = true;
         DLOG(0,0,"SriResFtnCsi: cause value criteria present");
      } 
      if(l_gmscCamelInfo->o_BcsmCamelTDP_CriteriaList.value[0].bit_mask & OMAP3_destinationNumberCriteria_present)
      {
         l_gmscCamelInfo->o_BcsmCamelTDP_CriteriaList.value[0].bit_mask &= (~OMAP3_destinationNumberCriteria_present);
         l_dncEnabled = true;
         DLOG(0,0,"SriResFtnCsi: destination number criteria present");
      }
      if(l_dncEnabled)
      {
         LLOG(0,0,"SriResFtnCsi: imsi + ftn + ocsi + ocriteria(BS + CallType if present) in first chunk");
         m_Utility.sendSRIRESULTNOTLAST(this,m_InitDlgId,MAP_OP_CODE_sendRoutingInfo,MAP_V3,l_tempSRIResFTNCSI);
         l_gmscCamelInfo->bit_mask &= (~OMAP3_GmscCamelSubscriptionInfo_o_CSI_present);
         l_tempSRIResFTNCSI->extendedRoutingInfo.u.camelRoutingInfo.bit_mask &= (~OMAP3_CamelRoutingInfo_forwardingData_present);

         l_gmscCamelInfo->o_BcsmCamelTDP_CriteriaList.value[0].bit_mask |= OMAP3_destinationNumberCriteria_present;

         l_gmscCamelInfo->o_BcsmCamelTDP_CriteriaList.value[0].bit_mask &= (~OMAP3_O_BcsmCamelTDP_Criteria_basicServiceCriteria_present);

         l_gmscCamelInfo->o_BcsmCamelTDP_CriteriaList.value[0].bit_mask &= (~OMAP3_callTypeCriteria_present);


         if(m_dcsiSet)
         {
            LLOG(0,0,"SriResFtnCsi: destination number criteria in second chunk");
            m_Utility.sendSRIRESULTNOTLAST(this,m_InitDlgId,MAP_OP_CODE_sendRoutingInfo,MAP_V3,l_tempSRIResFTNCSI);
            l_gmscCamelInfo->o_BcsmCamelTDP_CriteriaList.value[0].bit_mask &= (~OMAP3_destinationNumberCriteria_present);
            if(l_cvEnabled)
            {
               fillCauseValues(l_gmscCamelInfo);
            }
            else
            {
               l_gmscCamelInfo->bit_mask &= (~OMAP3_GmscCamelSubscriptionInfo_o_BcsmCamelTDP_CriteriaList_present);
            }
            fillDCSI(m_DcsiProfileId,l_gmscCamelInfo); 
            m_Utility.getSuppCamelPhsVmsc(l_tempSRIResFTNCSI,mp_sriSubData);
            LLOG(0,0,"SriResFtnCsi: dcsi and cause value criteria-if present in third and last chunk");
            return m_Utility.sendSRIRESULTLAST(this,m_InitDlgId,MAP_OP_CODE_sendRoutingInfo,MAP_V3,l_tempSRIResFTNCSI);
         }
         else
         {
            if(l_cvEnabled)
            {
               LLOG(0,0,"SriResFtnCsi: destination number criteria in second chunk");
               m_Utility.sendSRIRESULTNOTLAST(this,m_InitDlgId,MAP_OP_CODE_sendRoutingInfo,MAP_V3,l_tempSRIResFTNCSI);
               l_gmscCamelInfo->o_BcsmCamelTDP_CriteriaList.value[0].bit_mask &= (~OMAP3_destinationNumberCriteria_present);
               fillCauseValues(l_gmscCamelInfo);

               LLOG(0,0,"SriResFtnCsi: cause value criteria in third and last chunk");
            }
            else
            {
               LLOG(0,0,"SriResFtnCsi: destination number criteria in second and last chunk");
            }
            m_Utility.getSuppCamelPhsVmsc(l_tempSRIResFTNCSI,mp_sriSubData);
            return m_Utility.sendSRIRESULTLAST(this,m_InitDlgId,MAP_OP_CODE_sendRoutingInfo,MAP_V3,l_tempSRIResFTNCSI);
         }
      }
      else if(l_cvEnabled)
      {
         LLOG(0,0,"SriResFtnCsi: imsi + ftn + ocsi + ocriteria(BS + CallType if present) in first chunk");
         m_Utility.sendSRIRESULTNOTLAST(this,m_InitDlgId,MAP_OP_CODE_sendRoutingInfo,MAP_V3,l_tempSRIResFTNCSI);
         l_gmscCamelInfo->bit_mask &= (~OMAP3_GmscCamelSubscriptionInfo_o_CSI_present);
         l_tempSRIResFTNCSI->extendedRoutingInfo.u.camelRoutingInfo.bit_mask &= (~OMAP3_CamelRoutingInfo_forwardingData_present);

         l_gmscCamelInfo->o_BcsmCamelTDP_CriteriaList.value[0].bit_mask &= (~OMAP3_O_BcsmCamelTDP_Criteria_basicServiceCriteria_present);

         l_gmscCamelInfo->o_BcsmCamelTDP_CriteriaList.value[0].bit_mask &= (~OMAP3_callTypeCriteria_present);
         fillCauseValues(l_gmscCamelInfo);

         if(m_dcsiSet)
         {
            fillDCSI(m_DcsiProfileId,l_gmscCamelInfo); 
            LLOG(0,0,"SriResFtnCsi: dcsi and cause value criteria in second and last chunk");
         }
         else
         {
            fillCauseValues(l_gmscCamelInfo);
            LLOG(0,0,"SriResFtnCsi: cause value criteria in second and last chunk");
         }
         m_Utility.getSuppCamelPhsVmsc(l_tempSRIResFTNCSI,mp_sriSubData);
         return m_Utility.sendSRIRESULTLAST(this,m_InitDlgId,MAP_OP_CODE_sendRoutingInfo,MAP_V3,l_tempSRIResFTNCSI);
      }
      else
      {
         if(m_dcsiSet)
         {
            LLOG(0,0,"SriResFtnCsi: imsi + ftn + ocsi(BS + CallType if present) in first chunk");
            m_Utility.sendSRIRESULTNOTLAST(this,m_InitDlgId,MAP_OP_CODE_sendRoutingInfo,MAP_V3,l_tempSRIResFTNCSI);
            l_gmscCamelInfo->bit_mask &= (~OMAP3_GmscCamelSubscriptionInfo_o_CSI_present);
            l_tempSRIResFTNCSI->extendedRoutingInfo.u.camelRoutingInfo.bit_mask &= (~OMAP3_CamelRoutingInfo_forwardingData_present);
            l_gmscCamelInfo->bit_mask &= (~OMAP3_GmscCamelSubscriptionInfo_o_BcsmCamelTDP_CriteriaList_present);
            fillDCSI(m_DcsiProfileId,l_gmscCamelInfo); 
            LLOG(0,0,"SriResFtnCsi: dcsi in second and last chunk");
         }
         else
         {
            LLOG(0,0,"SriResFtnCsi: imsi + ftn + ocsi(BS + CallType if present) in first and last chunk");
         }
         m_Utility.getSuppCamelPhsVmsc(l_tempSRIResFTNCSI,mp_sriSubData);
         return m_Utility.sendSRIRESULTLAST(this,m_InitDlgId,MAP_OP_CODE_sendRoutingInfo,MAP_V3,l_tempSRIResFTNCSI);
      }
   }

   else
   {
      if(m_dcsiSet)
      {
         LLOG(0,0,"SriResFtnCsi: imsi + ftn + ocsi in first chunk");
         m_Utility.sendSRIRESULTNOTLAST(this,m_InitDlgId,MAP_OP_CODE_sendRoutingInfo,MAP_V3,l_tempSRIResFTNCSI);
         l_gmscCamelInfo->bit_mask &= (~OMAP3_GmscCamelSubscriptionInfo_o_CSI_present);
         l_tempSRIResFTNCSI->extendedRoutingInfo.u.camelRoutingInfo.bit_mask &= (~OMAP3_CamelRoutingInfo_forwardingData_present);
         fillDCSI(m_DcsiProfileId,l_gmscCamelInfo); 
         LLOG(0,0,"SriResFtnCsi: dcsi in second and last chunk");
      }
      else
      {
         LLOG(0,0,"SriResFtnCsi: imsi + ftn + ocsi in first and last chunk");
      }
      m_Utility.getSuppCamelPhsVmsc(l_tempSRIResFTNCSI,mp_sriSubData);
      return m_Utility.sendSRIRESULTLAST(this,m_InitDlgId,MAP_OP_CODE_sendRoutingInfo,MAP_V3,l_tempSRIResFTNCSI);
   }
}

bool CtxtSendRoutingInfo :: sendSRIResPSINack()
{
   DLOG(0,0,"In SendSriResPsiNack");
   DECLARE(OMAP3_SendRoutingInfoRes,l_tempSRIResPSINAck,3,"OMAP3_SendRoutingInfoRes",resetStruct);
   OMAP3_GmscCamelSubscriptionInfo *l_gmscCamelInfo = &l_tempSRIResPSINAck->extendedRoutingInfo.u.camelRoutingInfo.gmscCamelSubscriptionInfo;

   l_tempSRIResPSINAck->bit_mask |= OMAP3_extendedRoutingInfo_present;
   l_tempSRIResPSINAck->extendedRoutingInfo.choice =  OMAP3_camelRoutingInfo_chosen;

   if( (0 == m_ForwardType)  && ( 1 == mp_sriSubData->m_ocsiSuppressFlag ) ) //6430
   {
    LLOG(0,0,"Normal call and suppress ocsi is enabled");
    m_ocsiSet = false;;
   }

   bool l_oCriteria = false;
   l_oCriteria = fillOCSI(m_OcsiProfileId,l_gmscCamelInfo);
   fillTCSI(m_TcsiProfileId,l_gmscCamelInfo);

   l_tempSRIResPSINAck->bit_mask |= OMAP3_SendRoutingInfoRes_imsi_present;

   TLOG(0,0,"SriResPsiNack: SRIImsi:|%s|",m_SriImsi); 
   l_tempSRIResPSINAck->imsi.length = StringToBCD(l_tempSRIResPSINAck->imsi.value,(u8*)m_SriImsi,(s32)strlen((s8*)m_SriImsi));

   if(m_ForwardType)
   {
      DLOG(0,0,"SriResPsiNack: forward type:|%d| - 1:unconditional  2:notreachable",m_ForwardType);
      createSRIResFTN(&mp_sriSubData->m_fwdInfo,l_tempSRIResPSINAck,true);
   }

   if(m_ocsiSet)
   {
      l_gmscCamelInfo->bit_mask &= (~OMAP3_GmscCamelSubscriptionInfo_o_CSI_present);
      if(l_oCriteria)
         l_gmscCamelInfo->bit_mask &= (~OMAP3_GmscCamelSubscriptionInfo_o_BcsmCamelTDP_CriteriaList_present);
   }

   LLOG(0,0,"SriResPsiNack: imsi + tcsi + ftn if present in first chunk");
   m_Utility.sendSRIRESULTNOTLAST(this,m_InitDlgId,MAP_OP_CODE_sendRoutingInfo,MAP_V3,l_tempSRIResPSINAck);

   if(m_ForwardType)
      l_tempSRIResPSINAck->extendedRoutingInfo.u.camelRoutingInfo.bit_mask &= (~OMAP3_CamelRoutingInfo_forwardingData_present);

   l_gmscCamelInfo->bit_mask &= (~OMAP3_GmscCamelSubscriptionInfo_t_CSI_present);

   if(m_ocsiSet)
   {
      l_gmscCamelInfo->bit_mask |= OMAP3_GmscCamelSubscriptionInfo_o_CSI_present;
      if(l_oCriteria)
      {
         bool l_dncDisabled = false;
         bool l_cvEnabled = false;

         l_gmscCamelInfo->bit_mask |= OMAP3_GmscCamelSubscriptionInfo_o_BcsmCamelTDP_CriteriaList_present;

         if(l_gmscCamelInfo->o_BcsmCamelTDP_CriteriaList.value[1].bit_mask & OMAP3_o_CauseValueCriteria_present)
         {
            l_gmscCamelInfo->o_BcsmCamelTDP_CriteriaList.count = 1; 
            //l_gmscCamelInfo->o_BcsmCamelTDP_CriteriaList.value[1].bit_mask &= (~OMAP3_o_CauseValueCriteria_present);
            l_cvEnabled = true;
            DLOG(0,0,"SriResPsiNack: cause value criteria present");
         } 

         if(l_gmscCamelInfo->o_BcsmCamelTDP_CriteriaList.value[0].bit_mask & OMAP3_destinationNumberCriteria_present)
         {
            l_gmscCamelInfo->o_BcsmCamelTDP_CriteriaList.value[0].bit_mask &= (~OMAP3_destinationNumberCriteria_present);
            l_dncDisabled = true;
         }
         if(l_dncDisabled)
         {
            LLOG(0,0,"SriResPsiNack: ocsi + ocriteria(BS + CallType if present) in second chunk");
            m_Utility.sendSRIRESULTNOTLAST(this,m_InitDlgId,MAP_OP_CODE_sendRoutingInfo,MAP_V3,l_tempSRIResPSINAck);
            l_gmscCamelInfo->bit_mask &= (~OMAP3_GmscCamelSubscriptionInfo_o_CSI_present);
            l_gmscCamelInfo->o_BcsmCamelTDP_CriteriaList.value[0].bit_mask |= OMAP3_destinationNumberCriteria_present;

            l_gmscCamelInfo->o_BcsmCamelTDP_CriteriaList.value[0].bit_mask &= (~OMAP3_O_BcsmCamelTDP_Criteria_basicServiceCriteria_present);

            l_gmscCamelInfo->o_BcsmCamelTDP_CriteriaList.value[0].bit_mask &= (~OMAP3_callTypeCriteria_present);

            LLOG(0,0,"SriResPsiNack: only ocsi number criteria in third chunk");
            m_Utility.sendSRIRESULTNOTLAST(this,m_InitDlgId,MAP_OP_CODE_sendRoutingInfo,MAP_V3,l_tempSRIResPSINAck);
            l_gmscCamelInfo->o_BcsmCamelTDP_CriteriaList.value[0].bit_mask &= (~OMAP3_destinationNumberCriteria_present);

            if(m_dcsiSet)
            {
               if(l_cvEnabled)
               {
                  fillCauseValues(l_gmscCamelInfo);
               }
               else
               {
                  l_gmscCamelInfo->bit_mask &= (~OMAP3_GmscCamelSubscriptionInfo_o_BcsmCamelTDP_CriteriaList_present);
               }
               fillDCSI(m_DcsiProfileId,l_gmscCamelInfo); 

               fillPSINackSRIRes(l_tempSRIResPSINAck);

               m_Utility.getSuppCamelPhsVmsc(l_tempSRIResPSINAck,mp_sriSubData);
               LLOG(0,0,"SriResPsiNack: psinack + suppCamelPhVmsc + dcsi + cause value-if present in fourth and last chunk");
               return m_Utility.sendSRIRESULTLAST(this,m_InitDlgId,MAP_OP_CODE_sendRoutingInfo,MAP_V3,l_tempSRIResPSINAck);
            }
            else
            {
               if(l_cvEnabled)
               {
                  fillCauseValues(l_gmscCamelInfo);
               }
               else
               {
                  l_tempSRIResPSINAck->bit_mask &= (~OMAP3_extendedRoutingInfo_present);
                  //l_gmscCamelInfo->bit_mask &= (~OMAP3_GmscCamelSubscriptionInfo_o_BcsmCamelTDP_CriteriaList_present);
               }
               fillPSINackSRIRes(l_tempSRIResPSINAck);
               m_Utility.getSuppCamelPhsVmsc(l_tempSRIResPSINAck,mp_sriSubData);
               LLOG(0,0,"SriResPsiNack: psinack + suppCamelPhVmsc + cause value-if present in fourth and last chunk");
               return m_Utility.sendSRIRESULTLAST(this,m_InitDlgId,MAP_OP_CODE_sendRoutingInfo,MAP_V3,l_tempSRIResPSINAck);
            }
         }
         else if(l_cvEnabled)
         {
            LLOG(0,0,"SriResPsiNack: ocsi + ocriteria(BS + CallType if present) in second chunk");
            m_Utility.sendSRIRESULTNOTLAST(this,m_InitDlgId,MAP_OP_CODE_sendRoutingInfo,MAP_V3,l_tempSRIResPSINAck);
            l_gmscCamelInfo->bit_mask &= (~OMAP3_GmscCamelSubscriptionInfo_o_CSI_present);

            l_gmscCamelInfo->o_BcsmCamelTDP_CriteriaList.value[0].bit_mask &= (~OMAP3_O_BcsmCamelTDP_Criteria_basicServiceCriteria_present);
            l_gmscCamelInfo->o_BcsmCamelTDP_CriteriaList.value[0].bit_mask &= (~OMAP3_callTypeCriteria_present);

            fillCauseValues(l_gmscCamelInfo);
            fillPSINackSRIRes(l_tempSRIResPSINAck);
            m_Utility.getSuppCamelPhsVmsc(l_tempSRIResPSINAck,mp_sriSubData);

            if(m_dcsiSet)
            {
               fillDCSI(m_DcsiProfileId,l_gmscCamelInfo); 
               LLOG(0,0,"SriResPsiNack: psinack + suppCamelPhVmsc + dcsi + cause value-if present in fourth and last chunk ");
            }
            else
            {
               LLOG(0,0,"SriResPsiNack: psinack + suppCamelPhVmsc + cause value-if present in fourth and last chunk");
            }
            return m_Utility.sendSRIRESULTLAST(this,m_InitDlgId,MAP_OP_CODE_sendRoutingInfo,MAP_V3,l_tempSRIResPSINAck);
         }
         else
         {
            LLOG(0,0,"SriResPsiNack: ocsi + ocriteria(BS + CallType) in second chunk");
            m_Utility.sendSRIRESULTNOTLAST(this,m_InitDlgId,MAP_OP_CODE_sendRoutingInfo,MAP_V3,l_tempSRIResPSINAck);
            l_gmscCamelInfo->bit_mask &= (~OMAP3_GmscCamelSubscriptionInfo_o_CSI_present);
            l_gmscCamelInfo->bit_mask &= (~OMAP3_GmscCamelSubscriptionInfo_o_BcsmCamelTDP_CriteriaList_present);
            if(m_dcsiSet)
               fillDCSI(m_DcsiProfileId,l_gmscCamelInfo); 
            else
               l_tempSRIResPSINAck->bit_mask &= (~OMAP3_extendedRoutingInfo_present);
            fillPSINackSRIRes(l_tempSRIResPSINAck);
            m_Utility.getSuppCamelPhsVmsc(l_tempSRIResPSINAck,mp_sriSubData);
            LLOG(0,0,"SriResPsiNack: psinack + suppCamelPhVmsc + dcsi if present in third and last chunk");
            return m_Utility.sendSRIRESULTLAST(this,m_InitDlgId,MAP_OP_CODE_sendRoutingInfo,MAP_V3,l_tempSRIResPSINAck);
         }
      }
      else
      {
         fillPSINackSRIRes(l_tempSRIResPSINAck);
         m_Utility.getSuppCamelPhsVmsc(l_tempSRIResPSINAck,mp_sriSubData);
         if(m_dcsiSet)
         {
            LLOG(0,0,"SriResPsiNack: ocsi + psinack + suppCamelPhVmsc in second chunk");
            m_Utility.sendSRIRESULTNOTLAST(this,m_InitDlgId,MAP_OP_CODE_sendRoutingInfo,MAP_V3,l_tempSRIResPSINAck);
            l_gmscCamelInfo->bit_mask &= (~OMAP3_GmscCamelSubscriptionInfo_o_CSI_present);
            l_tempSRIResPSINAck->bit_mask &= (~OMAP3_subscriberInfo_present);
            l_tempSRIResPSINAck->bit_mask &= (~OMAP3_supportedCamelPhasesInVMSC_present);
            fillDCSI(m_DcsiProfileId,l_gmscCamelInfo); 
            LLOG(0,0,"SriResPsiNack: dcsi in third and last chunk");
         }
         else
         {
            LLOG(0,0,"SriResPsiNack:  ocsi + psinack + suppCamelPhVmsc in second and last chunk");
         }
         return m_Utility.sendSRIRESULTLAST(this,m_InitDlgId,MAP_OP_CODE_sendRoutingInfo,MAP_V3,l_tempSRIResPSINAck);
      }
   }
   else
   {
      LLOG(0,0,"SriResPsiNack: psinack + suppCamelPhVmsc + dcsi if present in second and last chunk");
      if(m_dcsiSet)
         fillDCSI(m_DcsiProfileId,l_gmscCamelInfo); 
      else
         l_tempSRIResPSINAck->bit_mask &= (~OMAP3_extendedRoutingInfo_present);

      fillPSINackSRIRes(l_tempSRIResPSINAck);
      m_Utility.getSuppCamelPhsVmsc(l_tempSRIResPSINAck,mp_sriSubData);
      return m_Utility.sendSRIRESULTLAST(this,m_InitDlgId,MAP_OP_CODE_sendRoutingInfo,MAP_V3,l_tempSRIResPSINAck);
   }
}

bool CtxtSendRoutingInfo :: sendSRIResPSIAck(IMAP3_ProvideSubscriberInfoRes *aPSIRes)
{
   DLOG(0,0,"In SendSriResPsiAck");
   DECLARE(OMAP3_SendRoutingInfoRes,l_tempSRIResPSIAck,3,"OMAP3_SendRoutingInfoRes",resetStruct);


   OMAP3_GmscCamelSubscriptionInfo *l_gmscCamelInfo = &l_tempSRIResPSIAck->extendedRoutingInfo.u.camelRoutingInfo.gmscCamelSubscriptionInfo;

   l_tempSRIResPSIAck->bit_mask |= OMAP3_extendedRoutingInfo_present;
   l_tempSRIResPSIAck->extendedRoutingInfo.choice =  OMAP3_camelRoutingInfo_chosen;

   if( (0 == m_ForwardType)  && ( 1 == mp_sriSubData->m_ocsiSuppressFlag ) ) //6430
   {
    LLOG(0,0,"Normal call and suppress ocsi is enabled");
    m_ocsiSet = false;;
   }
   bool l_oCriteria = false;
   l_oCriteria = fillOCSI(m_OcsiProfileId,l_gmscCamelInfo);
   fillTCSI(m_TcsiProfileId,l_gmscCamelInfo);

   l_tempSRIResPSIAck->bit_mask |= OMAP3_SendRoutingInfoRes_imsi_present;

   TLOG(0,0,"SriResPsiNack: SRIImsi:|%s|",m_SriImsi); 
   l_tempSRIResPSIAck->imsi.length = StringToBCD(l_tempSRIResPSIAck->imsi.value,(u8*)m_SriImsi,(s32)strlen((s8*)m_SriImsi));

   if(m_ForwardType)
   {
      DLOG(0,0,"SriResPsiAck: forward type-|%d| - 1:unconditional  2:notreachable",m_ForwardType);
      createSRIResFTN(&mp_sriSubData->m_fwdInfo,l_tempSRIResPSIAck,true);
   }

   if(m_ocsiSet)
   {
      l_gmscCamelInfo->bit_mask &= (~OMAP3_GmscCamelSubscriptionInfo_o_CSI_present);
      if(l_oCriteria)
         l_gmscCamelInfo->bit_mask &= (~OMAP3_GmscCamelSubscriptionInfo_o_BcsmCamelTDP_CriteriaList_present);
   }

   LLOG(0,0,"SriResPsiAck: imsi + tcsi + ftn if present in first chunk");
   m_Utility.sendSRIRESULTNOTLAST(this,m_InitDlgId,MAP_OP_CODE_sendRoutingInfo,MAP_V3,l_tempSRIResPSIAck);

   if(m_ForwardType)
      l_tempSRIResPSIAck->extendedRoutingInfo.u.camelRoutingInfo.bit_mask &= (~OMAP3_CamelRoutingInfo_forwardingData_present);

   l_gmscCamelInfo->bit_mask &= (~OMAP3_GmscCamelSubscriptionInfo_t_CSI_present);

   if(m_ocsiSet)
   {
      l_gmscCamelInfo->bit_mask |= OMAP3_GmscCamelSubscriptionInfo_o_CSI_present;
      if(l_oCriteria)
      {
         bool l_dncEnabled = false;
         bool l_cvEnabled = false;

         l_gmscCamelInfo->bit_mask |= OMAP3_GmscCamelSubscriptionInfo_o_BcsmCamelTDP_CriteriaList_present;

         if(l_gmscCamelInfo->o_BcsmCamelTDP_CriteriaList.value[1].bit_mask & OMAP3_o_CauseValueCriteria_present)
         {
            l_gmscCamelInfo->o_BcsmCamelTDP_CriteriaList.count = 1; 
            //l_gmscCamelInfo->o_BcsmCamelTDP_CriteriaList.value[1].bit_mask &= (~OMAP3_o_CauseValueCriteria_present);
            l_cvEnabled = true;
            DLOG(0,0,"SriResPsiAck: cause value criteria present");
         } 
         if(l_gmscCamelInfo->o_BcsmCamelTDP_CriteriaList.value[0].bit_mask & OMAP3_destinationNumberCriteria_present)
         {
            l_gmscCamelInfo->o_BcsmCamelTDP_CriteriaList.value[0].bit_mask &= (~OMAP3_destinationNumberCriteria_present);
            l_dncEnabled = true;
         }
         if(l_dncEnabled)
         {
            LLOG(0,0,"SriResPsiAck: ocsi + ocriteria(BS + CallType) in second chunk");
            m_Utility.sendSRIRESULTNOTLAST(this,m_InitDlgId,MAP_OP_CODE_sendRoutingInfo,MAP_V3,l_tempSRIResPSIAck);
            l_gmscCamelInfo->bit_mask &= (~OMAP3_GmscCamelSubscriptionInfo_o_CSI_present);
            l_gmscCamelInfo->o_BcsmCamelTDP_CriteriaList.value[0].bit_mask |= OMAP3_destinationNumberCriteria_present;

            l_gmscCamelInfo->o_BcsmCamelTDP_CriteriaList.value[0].bit_mask &= (~OMAP3_O_BcsmCamelTDP_Criteria_basicServiceCriteria_present);

            l_gmscCamelInfo->o_BcsmCamelTDP_CriteriaList.value[0].bit_mask &= (~OMAP3_callTypeCriteria_present);

            LLOG(0,0,"SriResPsiAck: only ocsi number criteria in third chunk");
            m_Utility.sendSRIRESULTNOTLAST(this,m_InitDlgId,MAP_OP_CODE_sendRoutingInfo,MAP_V3,l_tempSRIResPSIAck);
            l_gmscCamelInfo->o_BcsmCamelTDP_CriteriaList.value[0].bit_mask &= (~OMAP3_destinationNumberCriteria_present);

            if(m_dcsiSet)
            {
               if(l_cvEnabled)
               {
                  fillCauseValues(l_gmscCamelInfo);
               }
               else
               {
                  l_gmscCamelInfo->bit_mask &= (~OMAP3_GmscCamelSubscriptionInfo_o_BcsmCamelTDP_CriteriaList_present);
               }
               fillDCSI(m_DcsiProfileId,l_gmscCamelInfo); 
               fillPSIinSRIRes(l_tempSRIResPSIAck,aPSIRes);
               m_Utility.getSuppCamelPhsVmsc(l_tempSRIResPSIAck,mp_sriSubData);
               LLOG(0,0,"SriResPsiAck: psiack + suppCamelPhVmsc + dcsi + cause value-if present in fourth and last chunk ");
               return m_Utility.sendSRIRESULTLAST(this,m_InitDlgId,MAP_OP_CODE_sendRoutingInfo,MAP_V3,l_tempSRIResPSIAck);
            }
            else
            {
               if(l_cvEnabled)
               {
                  fillCauseValues(l_gmscCamelInfo);
               }
               else
               {
                  l_tempSRIResPSIAck->bit_mask &= (~OMAP3_extendedRoutingInfo_present);
                  //l_gmscCamelInfo->bit_mask &= (~OMAP3_GmscCamelSubscriptionInfo_o_BcsmCamelTDP_CriteriaList_present);
               }
               fillPSIinSRIRes(l_tempSRIResPSIAck,aPSIRes);
               m_Utility.getSuppCamelPhsVmsc(l_tempSRIResPSIAck,mp_sriSubData);
               LLOG(0,0,"SriResPsiAck: psiack + suppCamelPhVmsc + cause value-if present in fourth and last chunk");
               return m_Utility.sendSRIRESULTLAST(this,m_InitDlgId,MAP_OP_CODE_sendRoutingInfo,MAP_V3,l_tempSRIResPSIAck);
            }
         }
         else if(l_cvEnabled)
         {
            LLOG(0,0,"SriResPsiAck: ocsi + ocriteria(BS + CallType if present) in second chunk");
            m_Utility.sendSRIRESULTNOTLAST(this,m_InitDlgId,MAP_OP_CODE_sendRoutingInfo,MAP_V3,l_tempSRIResPSIAck);
            l_gmscCamelInfo->bit_mask &= (~OMAP3_GmscCamelSubscriptionInfo_o_CSI_present);

            l_gmscCamelInfo->o_BcsmCamelTDP_CriteriaList.value[0].bit_mask &= (~OMAP3_O_BcsmCamelTDP_Criteria_basicServiceCriteria_present);
            l_gmscCamelInfo->o_BcsmCamelTDP_CriteriaList.value[0].bit_mask &= (~OMAP3_callTypeCriteria_present);
            fillCauseValues(l_gmscCamelInfo);
            fillPSIinSRIRes(l_tempSRIResPSIAck,aPSIRes);
            m_Utility.getSuppCamelPhsVmsc(l_tempSRIResPSIAck,mp_sriSubData);

            if(m_dcsiSet)
            {
               fillDCSI(m_DcsiProfileId,l_gmscCamelInfo); 
               LLOG(0,0,"SriResPsiAck: psiack + suppCamelPhVmsc + dcsi + cause value-if present in fourth and last chunk ");
            }
            else
            {
               LLOG(0,0,"SriResPsiAck: psiack + suppCamelPhVmsc + cause value-if present in fourth and last chunk");
            }
            return m_Utility.sendSRIRESULTLAST(this,m_InitDlgId,MAP_OP_CODE_sendRoutingInfo,MAP_V3,l_tempSRIResPSIAck);
         }
         else
         {
            LLOG(0,0,"SriResPsiAck: ocsi + ocriteria(BS + CallType if present) in second chunk");
            m_Utility.sendSRIRESULTNOTLAST(this,m_InitDlgId,MAP_OP_CODE_sendRoutingInfo,MAP_V3,l_tempSRIResPSIAck);
            l_gmscCamelInfo->bit_mask &= (~OMAP3_GmscCamelSubscriptionInfo_o_CSI_present);
            l_gmscCamelInfo->bit_mask &= (~OMAP3_GmscCamelSubscriptionInfo_o_BcsmCamelTDP_CriteriaList_present);
            if(m_dcsiSet)
               fillDCSI(m_DcsiProfileId,l_gmscCamelInfo); 
            else
               l_tempSRIResPSIAck->bit_mask &= (~OMAP3_extendedRoutingInfo_present);
            fillPSIinSRIRes(l_tempSRIResPSIAck,aPSIRes);
            m_Utility.getSuppCamelPhsVmsc(l_tempSRIResPSIAck,mp_sriSubData);
            LLOG(0,0,"SriResPsiAck: psiack + suppCamelPhVmsc + dcsi-if present in third and last chunk");
            return m_Utility.sendSRIRESULTLAST(this,m_InitDlgId,MAP_OP_CODE_sendRoutingInfo,MAP_V3,l_tempSRIResPSIAck);
         }
      }
      else
      {
         fillPSIinSRIRes(l_tempSRIResPSIAck,aPSIRes);
         m_Utility.getSuppCamelPhsVmsc(l_tempSRIResPSIAck,mp_sriSubData);
         if(m_dcsiSet)
         {
            LLOG(0,0,"SriResPsiAck: ocsi + psiack + suppCamelPhVmsc in second chunk");
            m_Utility.sendSRIRESULTNOTLAST(this,m_InitDlgId,MAP_OP_CODE_sendRoutingInfo,MAP_V3,l_tempSRIResPSIAck);

            l_gmscCamelInfo->bit_mask &= (~OMAP3_GmscCamelSubscriptionInfo_o_CSI_present);
            l_tempSRIResPSIAck->bit_mask &= (~OMAP3_subscriberInfo_present);
            l_tempSRIResPSIAck->bit_mask &= (~OMAP3_supportedCamelPhasesInVMSC_present);
            fillDCSI(m_DcsiProfileId,l_gmscCamelInfo); 
            LLOG(0,0,"SriResPsiAck: dcsi in third and last chunk");
         }
         else
         {
            LLOG(0,0,"SriResPsiAck: ocsi + psiack + suppCamelPhVmsc in second and last chunk");
         }
         return m_Utility.sendSRIRESULTLAST(this,m_InitDlgId,MAP_OP_CODE_sendRoutingInfo,MAP_V3,l_tempSRIResPSIAck);
      }
   }
   else
   {
      LLOG(0,0,"SriResPsiAck: psiack + suppCamelPhVmsc + dcsi if present in second and last chunk");
      if(m_dcsiSet)
         fillDCSI(m_DcsiProfileId,l_gmscCamelInfo); 
      else
         l_tempSRIResPSIAck->bit_mask &= (~OMAP3_extendedRoutingInfo_present);

      fillPSIinSRIRes(l_tempSRIResPSIAck,aPSIRes);
      m_Utility.getSuppCamelPhsVmsc(l_tempSRIResPSIAck,mp_sriSubData);
      return m_Utility.sendSRIRESULTLAST(this,m_InitDlgId,MAP_OP_CODE_sendRoutingInfo,MAP_V3,l_tempSRIResPSIAck);
   }
}


EResult CtxtSendRoutingInfo :: createSRIResFTN(CF_BSG *aCfBsg,void *aSRIRes,bool aCamelFtn)
{
   switch(m_MapVer)
   {
      case MAP_V3:
         {
            // forwarding options max value can be 110111 - 55 so using u8
            DLOG(0,0,"In CreateSRIResFTN");
            OMAP3_SendRoutingInfoRes *pSRIRes = (OMAP3_SendRoutingInfoRes*)aSRIRes;
            u8 l_fwdOptions = 0x00;
            bool l_fwdOptionsPresent = false;
            bool l_setFwdData = false;

            if(CM_DB_FORWARD_UNCONDITIONAL == m_ForwardType)
               m_tdr.setString(TDR_INDEX_CM_SRI_FORWARD_TYPE,"cfu");
            else
               m_tdr.setString(TDR_INDEX_CM_SRI_FORWARD_TYPE,"cfnrc");

            //if(aCfBsg->m_fwdOptions != 0)
            {
               l_fwdOptions = (aCfBsg->m_fwdOptions & 0xff);
               if(CM_DB_FORWARD_UNCONDITIONAL == m_ForwardType)
               {
                  l_fwdOptions |= 0x0c;
               }
               l_fwdOptionsPresent = true;
            }

#if 0
            // Notifcation to forwarding party  1 0 0 0  0 0 0 0
            // Redirecting presentation 	      0 1 0 0  0 0 0 0    
            // Notifcation to calling party     0 0 1 0  0 0 0 0
            // FwdReason                        0 0 0 0  1 1 0 0     
            // 00 . ms not reachable 01 . ms busy 10 . no reply 11 . unconditional
#endif

            OMAP3_ExtendedRoutingInfo *lp_extRoutInfo = &pSRIRes->extendedRoutingInfo;

            if(aCamelFtn)
            {
               DLOG(0,0,"Filling Ftn in CamelRoutingInfo");

               if(aCfBsg->m_FtnLen > 1)
               {
                  LLOG(0,0,"fillFtn: camelroutinginfo ftn present-|%s|",aCfBsg->m_Ftn);
                  lp_extRoutInfo->u.camelRoutingInfo.forwardingData.bit_mask |= OMAP3_ForwardingData_forwardedToNumber_present;
                  lp_extRoutInfo->u.camelRoutingInfo.forwardingData.forwardedToNumber.length = StringToBCD(lp_extRoutInfo->u.camelRoutingInfo.forwardingData.forwardedToNumber.value,(u8*)aCfBsg->m_Ftn,aCfBsg->m_FtnLen);
                  l_setFwdData = true;
                  m_tdr.setString(TDR_INDEX_CM_SRI_FTN,(s8*)&aCfBsg->m_Ftn[2]);
               }
               else if(aCfBsg->m_DefFtnLen > 1)
               {
                  if( (aCfBsg->m_DefFtnLen > 15) && (true == m_longFtnSupportFlag) )  // 2.0.7.0
                  {
                     LLOG(0,0,"fillFtn: camelroutinginfo LongFtn default-ftn present-|%s|",aCfBsg->m_DefFtn);
                     lp_extRoutInfo->u.camelRoutingInfo.forwardingData.bit_mask |= OMAP3_ForwardingData_longForwardedToNumber_present;
                     lp_extRoutInfo->u.camelRoutingInfo.forwardingData.longForwardedToNumber.length = StringToBCD(lp_extRoutInfo->u.camelRoutingInfo.forwardingData.longForwardedToNumber.value,(u8*)aCfBsg->m_DefFtn,aCfBsg->m_DefFtnLen);
                  }
                  else
                  {
                     LLOG(0,0,"fillFtn: camelroutinginfo default-ftn present-|%s|",aCfBsg->m_DefFtn);
                     lp_extRoutInfo->u.camelRoutingInfo.forwardingData.bit_mask |= OMAP3_ForwardingData_forwardedToNumber_present;
                     lp_extRoutInfo->u.camelRoutingInfo.forwardingData.forwardedToNumber.length = StringToBCD(lp_extRoutInfo->u.camelRoutingInfo.forwardingData.forwardedToNumber.value,(u8*)aCfBsg->m_DefFtn,aCfBsg->m_DefFtnLen);
                  }
                  l_setFwdData = true;
                  m_tdr.setString(TDR_INDEX_CM_SRI_FTN,(s8*)&aCfBsg->m_DefFtn[2]);
               }
               else
               {
                  CLOG(0,0,"fillFtn: camelroutinginfo forwarding data not present");
                  return CM_ERROR;
               }
               if(l_setFwdData == true)
               {
                  if(l_fwdOptionsPresent)
                  {
                     LLOG(0,0,"fillFtn: camelroutinginfo forwardingoptions present-|%x|",l_fwdOptions);
                     lp_extRoutInfo->u.camelRoutingInfo.forwardingData.bit_mask |= OMAP3_ForwardingData_forwardingOptions_present;
                     lp_extRoutInfo->u.camelRoutingInfo.forwardingData.forwardingOptions.length = 1;
                     lp_extRoutInfo->u.camelRoutingInfo.forwardingData.forwardingOptions.value[0] = l_fwdOptions;
                  }
                  if((aCfBsg->m_fwdToSubAddrLen > 1)) 
                  {
                     LLOG(0,0,"fillFtn: camelroutinginfo forwardtosubaddress present-|%s|",aCfBsg->m_fwdToSubAddr);
                     lp_extRoutInfo->u.camelRoutingInfo.forwardingData.bit_mask |= OMAP3_ForwardingData_forwardedToSubaddress_present;
                     lp_extRoutInfo->u.camelRoutingInfo.forwardingData.forwardedToSubaddress.length = StringToBCD(lp_extRoutInfo->u.camelRoutingInfo.forwardingData.forwardedToSubaddress.value,(u8*)aCfBsg->m_fwdToSubAddr,aCfBsg->m_fwdToSubAddrLen);
                  }
                  lp_extRoutInfo->u.camelRoutingInfo.bit_mask |= OMAP3_CamelRoutingInfo_forwardingData_present;
                  DLOG(0,0,"fillFtn: OMAP3_CamelRoutingInfo_forwardingData_present ");
                  pSRIRes->bit_mask |= OMAP3_extendedRoutingInfo_present;
                  lp_extRoutInfo->choice =  OMAP3_camelRoutingInfo_chosen;
               }
            }
            else 
            {
               DLOG(0,0,"Filling Ftn in RoutingInfo");

               if(aCfBsg->m_FtnLen > 1)
               {
                  LLOG(0,0,"fillFtn: routinginfo ftn present-|%s|",aCfBsg->m_Ftn);
                  lp_extRoutInfo->u.routingInfo.u.forwardingData.bit_mask |= OMAP3_ForwardingData_forwardedToNumber_present;
                  lp_extRoutInfo->u.routingInfo.u.forwardingData.forwardedToNumber.length = StringToBCD(lp_extRoutInfo->u.routingInfo.u.forwardingData.forwardedToNumber.value,(u8*)aCfBsg->m_Ftn,aCfBsg->m_FtnLen);
                  l_setFwdData = true;
                  m_tdr.setString(TDR_INDEX_CM_SRI_FTN,(s8*)&aCfBsg->m_Ftn[2]);
               }
               else if(aCfBsg->m_DefFtnLen > 1)
               {
                  if( (aCfBsg->m_DefFtnLen > 15) && (true == m_longFtnSupportFlag) ) // 2.0.7.0
                  {
                     LLOG(0,0,"fillFtn: routinginfo LongFtn defaultftn present-|%s|",aCfBsg->m_DefFtn);
                     lp_extRoutInfo->u.routingInfo.u.forwardingData.bit_mask |= OMAP3_ForwardingData_longForwardedToNumber_present;
                     lp_extRoutInfo->u.routingInfo.u.forwardingData.longForwardedToNumber.length = StringToBCD(lp_extRoutInfo->u.routingInfo.u.forwardingData.longForwardedToNumber.value,(u8*)aCfBsg->m_DefFtn,aCfBsg->m_DefFtnLen);
                  }
                  else
                  {
                     LLOG(0,0,"fillFtn: routinginfo defaultftn present-|%s|",aCfBsg->m_DefFtn);
                     lp_extRoutInfo->u.routingInfo.u.forwardingData.bit_mask |= OMAP3_ForwardingData_forwardedToNumber_present;
                     lp_extRoutInfo->u.routingInfo.u.forwardingData.forwardedToNumber.length = StringToBCD(lp_extRoutInfo->u.routingInfo.u.forwardingData.forwardedToNumber.value,(u8*)aCfBsg->m_DefFtn,aCfBsg->m_DefFtnLen);
                  }
                  l_setFwdData = true;
                  m_tdr.setString(TDR_INDEX_CM_SRI_FTN,(s8*)&aCfBsg->m_DefFtn[2]);
               }
               else
               {
                  CLOG(0,0,"fillFtn: routinginfo forwarding data not present");
                  return CM_ERROR;
               }

               if(l_setFwdData)
               {
                  if(l_fwdOptionsPresent)
                  {
                     LLOG(0,0,"fillFtn: routinginfo forwardoptions present - |%x|",l_fwdOptions);
                     lp_extRoutInfo->u.routingInfo.u.forwardingData.bit_mask |= OMAP3_ForwardingData_forwardingOptions_present;
                     lp_extRoutInfo->u.routingInfo.u.forwardingData.forwardingOptions.length = 1;
                     lp_extRoutInfo->u.routingInfo.u.forwardingData.forwardingOptions.value[0] = l_fwdOptions;
                  }
                  if(aCfBsg->m_fwdToSubAddrLen > 1)
                  {
                     LLOG(0,0,"fillFtn: routinginfo forwardtosubaddress present - |%s|",aCfBsg->m_fwdToSubAddr);
                     lp_extRoutInfo->u.routingInfo.u.forwardingData.bit_mask |= OMAP3_ForwardingData_forwardedToSubaddress_present;
                     lp_extRoutInfo->u.routingInfo.u.forwardingData.forwardedToSubaddress.length = StringToBCD(lp_extRoutInfo->u.routingInfo.u.forwardingData.forwardedToSubaddress.value,(u8*)aCfBsg->m_fwdToSubAddr,aCfBsg->m_fwdToSubAddrLen);
                  }
                  pSRIRes->bit_mask |= OMAP3_extendedRoutingInfo_present;
                  lp_extRoutInfo->choice = OMAP3_routingInfo_chosen; 
                  lp_extRoutInfo->u.routingInfo.choice = OMAP3_forwardingData_chosen;
                  DLOG(0,0,"fillFtn: OMAP3_routingInfo_chosen");
               }
            }
         }
         break;
      case MAP_V2:
         {
            // forwarding options max value can be 110111 - 55 so using u8
            DLOG(0,0,"In CreateSRIResFTN-V2");
            OMAP2_SendRoutingInfoRes *pSRIRes = (OMAP2_SendRoutingInfoRes*)aSRIRes;
            u8 l_fwdOptions = 0x00;
            bool l_fwdOptionsPresent = false;
            bool l_setFwdData = false;

            if(CM_DB_FORWARD_UNCONDITIONAL == m_ForwardType)
               m_tdr.setString(TDR_INDEX_CM_SRI_FORWARD_TYPE,"cfu");
            else
               m_tdr.setString(TDR_INDEX_CM_SRI_FORWARD_TYPE,"cfnrc");

            //if(aCfBsg->m_fwdOptions != 0)
            {
               l_fwdOptions = (aCfBsg->m_fwdOptions & 0xff);
               if(CM_DB_FORWARD_UNCONDITIONAL == m_ForwardType)
               {
                  l_fwdOptions |= 0x0c;
               }
               l_fwdOptionsPresent = true;
            }

            OMAP2_RoutingInfo *lp_extRoutInfo = &pSRIRes->routingInfo;

            if(aCfBsg->m_FtnLen > 1)
            {
               LLOG(0,0,"V2:fillFtn: routinginfo ftn present - |%s|",aCfBsg->m_Ftn);
               lp_extRoutInfo->u.forwardingData.bit_mask |= OMAP2_ForwardingData_forwardedToNumber_present;
               lp_extRoutInfo->u.forwardingData.forwardedToNumber.length = StringToBCD(lp_extRoutInfo->u.forwardingData.forwardedToNumber.value,(u8*)aCfBsg->m_Ftn,aCfBsg->m_FtnLen);
               l_setFwdData = true;
               m_tdr.setString(TDR_INDEX_CM_SRI_FTN,(s8*)&aCfBsg->m_Ftn[2]);
            }
            else if(aCfBsg->m_DefFtnLen > 1)
            {
               LLOG(0,0,"V2:fillFtn: routinginfo defaultftn present - |%s|",aCfBsg->m_DefFtn);
               lp_extRoutInfo->u.forwardingData.bit_mask |= OMAP2_ForwardingData_forwardedToNumber_present;
               lp_extRoutInfo->u.forwardingData.forwardedToNumber.length = StringToBCD(lp_extRoutInfo->u.forwardingData.forwardedToNumber.value,(u8*)aCfBsg->m_DefFtn,aCfBsg->m_DefFtnLen);
               l_setFwdData = true;
               m_tdr.setString(TDR_INDEX_CM_SRI_FTN,(s8*)&aCfBsg->m_DefFtn[2]);
            }
            else
            {
               CLOG(0,0,"V2:fillFtn: routinginfo forwarding data not present");
               return CM_ERROR;
            }

            if(l_setFwdData)
            {
               if(l_fwdOptionsPresent)
               {
                  LLOG(0,0,"V2:fillFtn:  routinginfo forwardoptions present - |%x|",l_fwdOptions);
                  lp_extRoutInfo->u.forwardingData.bit_mask |= OMAP2_ForwardingData_forwardingOptions_present;
                  lp_extRoutInfo->u.forwardingData.forwardingOptions.length = 1;
                  lp_extRoutInfo->u.forwardingData.forwardingOptions.value[0] = l_fwdOptions;
               }
               if(aCfBsg->m_fwdToSubAddrLen > 1)
               {
                  LLOG(0,0,"V2:fillFtn: routinginfo forwardtosubaddress present - |%s|",aCfBsg->m_fwdToSubAddr);
                  lp_extRoutInfo->u.forwardingData.bit_mask |= OMAP2_ForwardingData_forwardedToSubaddress_present;
                  lp_extRoutInfo->u.forwardingData.forwardedToSubaddress.length = StringToBCD(lp_extRoutInfo->u.forwardingData.forwardedToSubaddress.value,(u8*)aCfBsg->m_fwdToSubAddr,aCfBsg->m_fwdToSubAddrLen);
               }
               lp_extRoutInfo->choice = OMAP2_forwardingData_chosen;
               DLOG(0,0,"V2:fillFtn: OMAP2_forwardingData_chosen");
            }
         }
         break;
      case MAP_V1:
         {
            // forwarding options max value can be 110111 - 55 so using u8
            DLOG(0,0,"In CreateSRIResFTN-V1");
            OMAP1_SendRoutingInformationRes *pSRIRes = (OMAP1_SendRoutingInformationRes*)aSRIRes;
            u8 l_fwdOptions = 0x00;
            bool l_fwdOptionsPresent = false;
            bool l_setFwdData = false;

            if(CM_DB_FORWARD_UNCONDITIONAL == m_ForwardType)
               m_tdr.setString(TDR_INDEX_CM_SRI_FORWARD_TYPE,"cfu");
            else
               m_tdr.setString(TDR_INDEX_CM_SRI_FORWARD_TYPE,"cfnrc");

            //if(aCfBsg->m_fwdOptions != 0)
            {
               l_fwdOptions = (aCfBsg->m_fwdOptions & 0xff);
               if(CM_DB_FORWARD_UNCONDITIONAL == m_ForwardType)
               {
                  l_fwdOptions |= 0x0c;
               }
               l_fwdOptionsPresent = true;
            }

            OMAP1__choice9 *lp_extRoutInfo = &pSRIRes->routingInfo;

            if(aCfBsg->m_FtnLen > 1)
            {
               LLOG(0,0,"V1:fillFtn: ftn present - |%s|",aCfBsg->m_Ftn);
               lp_extRoutInfo->u.forwardingData.forwardedToNumber.length = StringToBCD(lp_extRoutInfo->u.forwardingData.forwardedToNumber.value,(u8*)aCfBsg->m_Ftn,aCfBsg->m_FtnLen);
               l_setFwdData = true;
               m_tdr.setString(TDR_INDEX_CM_SRI_FTN,(s8*)&aCfBsg->m_Ftn[2]);
            }
            else if(aCfBsg->m_DefFtnLen > 1)
            {
               LLOG(0,0,"V1:fillFtn: defaultftn present - |%s|",aCfBsg->m_DefFtn);
               lp_extRoutInfo->u.forwardingData.forwardedToNumber.length = StringToBCD(lp_extRoutInfo->u.forwardingData.forwardedToNumber.value,(u8*)aCfBsg->m_DefFtn,aCfBsg->m_DefFtnLen);
               l_setFwdData = true;
               m_tdr.setString(TDR_INDEX_CM_SRI_FTN,(s8*)&aCfBsg->m_DefFtn[2]); //Fix for 1.0.5.4
            }
            else
            {
               CLOG(0,0,"V1:fillFtn: forwarding data not present");
               return CM_ERROR;
            }

            if(l_setFwdData)
            {
               if(l_fwdOptionsPresent)
               {
                  LLOG(0,0,"V1:fillFtn: forwardoptions present - |%x|",l_fwdOptions);
                  lp_extRoutInfo->u.forwardingData.bit_mask |= OMAP1_ForwardingData_forwardingOptions_present;
                  lp_extRoutInfo->u.forwardingData.forwardingOptions.length = 1;
                  lp_extRoutInfo->u.forwardingData.forwardingOptions.value[0] = l_fwdOptions;
               }
               lp_extRoutInfo->choice = OMAP1_routingInfo_forwardingData_chosen;
               DLOG(0,0,"V1:fillFtn: OMAP1_routingInfo_forwardingData_chosen");
            }
         }
         break;
      default:
         {
            CLOG(0,0,"Unknown MapVersion Received");
         }
         break;
   }
   return CM_FORWARD;
}

EResult CtxtSendRoutingInfo :: handleFirstForwarding(u16 aForwardType)
{
   DLOG(0,0,"In hndleFirstForwarding");
   /*    the return type of hndleFirstForwarding is Fail,Continue,Forward and in all three cases u should
         check CheckTCSI,checkOCSI,checkDCSI */
   if(CM_DB_NO_FORWARD == aForwardType) 
   {
      DLOG(0,0,"handlefirstforwarding: not forward case continue with Csi check");
      return CM_CONTINUE;
   }

   if(CM_DB_FORWARD_UNCONDITIONAL == aForwardType)
   {
      if(m_callDiversion)
      {
         LLOG(0,0,"checkCFU success");
         return CM_FORWARD;
      }
      else
      {
         LLOG(0,0,"checkCFU success but Calldiversion not allowed so processing as normal call");
         return CM_CONTINUE;
      }
   }

   if(CM_DB_FORWARD_NOTREACHABLE == aForwardType)
   {
      if(m_callDiversion)
      {
         LLOG(0,0,"checkCFNRc Success");
         return CM_FORWARD;
      }
      else
      {
         LLOG(0,0,"checkCFNRc success but Calldiversion not allowed so sending AbsentSubscriber as per MAF010 23.082");
         m_ErrCode = MAP_ERROR_absentSubscriber;
         return CM_ERROR;
      }
   }
   return CM_CONTINUE;
}

EResult CtxtSendRoutingInfo :: checkTCSI(u16 aTcsiProfileId)
{
   DLOG(m_InitDlgId,0,"In chekTCSI");

   if(0 == aTcsiProfileId)
   {
      LLOG(0,0,"T-CSI not Applicable ProfileID is 0");
      if(true == m_collect_call_enabled) //shud be AT/AS as NS/DT/DS would have been rejected in DBRES
      {
         LLOG(0,0,"Collect call .. TCSI not configured [profile id 0] .. sending system failure");
         m_ErrCode = MAP_ERROR_systemFailure;
         return CM_ERROR; 
      }
      return CM_FAIL;
   }

   map<u16,TCSI*>::iterator l_tcsiItr;
   l_tcsiItr = g_spdPtr->m_TCSIMap.find(aTcsiProfileId);
   if(l_tcsiItr == g_spdPtr->m_TCSIMap.end())
   {
      CLOG(0,0,"TCSI profileID |%d| not found in map.. ",aTcsiProfileId);
      m_ErrCode = MAP_ERROR_systemFailure;
      return CM_ERROR; // send system failure
   }

   TCSI *lpTcsi = l_tcsiItr->second;

   if(lpTcsi == NULL)
   {
      ELOG(0,0,"Null values in TcsiMap for profileID |%d| .. ",aTcsiProfileId);
      m_ErrCode = MAP_ERROR_systemFailure;
      return CM_ERROR; // send system failure
   }

   if(0 == lpTcsi->m_csiState) // if TCSI is not there or not active
   {
      LLOG(0,0,"T-CSI not Applicable - CsiState is 0");
      if(true == m_collect_call_enabled)
      {
         LLOG(0,0,"Collect call .. TCSI not configured [CsiState is 0] .. sending system failure");
         m_ErrCode = MAP_ERROR_systemFailure;
         return CM_ERROR; 
      }
      return CM_FAIL;
   }

   if(true == m_SuppressTCSI)
   {
      LLOG(0,0,"SuppressTcsi true returning false");
      return CM_FAIL;
   }

   if(m_highestCphGmsc >= lpTcsi->m_camelCapability) 
   {
      m_manipulatedTcsiCCH = lpTcsi->m_camelCapability; // CCH not manipulated
   }
   else
   {
      m_manipulatedTcsiCCH = m_highestCphGmsc; // CCH manipulated
   }  

   TLOG(0,1,"HighestCPHGmsc:[%d] TcsiCCH:[%d] ManipulatedTcsiCCH:[%d]",m_highestCphGmsc,lpTcsi->m_camelCapability,m_manipulatedTcsiCCH);

   EResult l_tcsiResult = getTcsiStatus();

   if(CM_FAIL == l_tcsiResult) // 1.0.3.0
   {
      return CM_FAIL;
   }
   else if(CM_ERROR == l_tcsiResult)
   {
      m_ErrCode = MAP_ERROR_systemFailure;
      return CM_ERROR; // send system failure
   }

   TLOG(0,0,"T-CSI  Applicable");
   m_tcsiSet = true;
   return CM_CONTINUE;
}

bool CtxtSendRoutingInfo :: fillTCSI(u16 aTcsiProfileId,OMAP3_GmscCamelSubscriptionInfo *aGmscCamelInfo)
{
   DLOG(0,0,"In fillTCSI");

   if(m_tcsiSet == false)
   {
      DLOG(0,0,"tcsiSet false"); 
      return false;
   }

   TCSI *lpTcsi = g_spdPtr->m_TCSIMap[aTcsiProfileId]; 

   OMAP3_T_CSI *l_tCsi = &aGmscCamelInfo->t_CSI;

   aGmscCamelInfo->bit_mask |= OMAP3_GmscCamelSubscriptionInfo_t_CSI_present;

   l_tCsi->camelCapabilityHandling = m_manipulatedTcsiCCH;

   if(m_manipulatedTcsiCCH >= 2)
      aGmscCamelInfo->t_CSI.bit_mask |= OMAP3_T_CSI_camelCapabilityHandling_present;

   l_tCsi->t_BcsmCamelTDPDataList.count = 0;

   bool l_TdpDataPresent = false; 
   u32 l_serviceKey = 0;
   u32 l_networkSkey = 0; 
   u16 l_maxTcsiDps = 0;

   ServiceKey *p_ServiceKey = NULL;
   u16  trueTcsiCount = 0;

   if(m_manipulatedTcsiCCH >= 3)
      l_maxTcsiDps  = 3;
   else
      l_maxTcsiDps = 1;


   for(u16 i=0; i < l_maxTcsiDps; ++i)
   {
      l_serviceKey = lpTcsi->m_serviceKey[i];
      p_ServiceKey = g_spdPtr->getCallServiceKeyPtr(mp_sriSubData->m_networkId,l_serviceKey);
      l_networkSkey = g_spdPtr->getNetworkServiceKey(mp_sriSubData->m_networkId,l_serviceKey); // 1.0.3.0

      if(NULL == p_ServiceKey)
      {
         LLOG(0,0,"CallServiceKeyPtr null");
         return false;
      }

      DLOG(0,0,"Inside tdpListCount loop |%d|",i);

      if(l_serviceKey != 0)
      {
         l_tCsi->t_BcsmCamelTDPDataList.value[trueTcsiCount].t_BcsmTriggerDetectionPoint = (OMAP3_T_BcsmTriggerDetectionPoint)p_ServiceKey->m_bcsmTDP;
         DLOG(0,0,"Tcsi-Tdp |%d|",l_tCsi->t_BcsmCamelTDPDataList.value[trueTcsiCount].t_BcsmTriggerDetectionPoint);
         if(l_serviceKey == l_networkSkey) // 1.0.3.0
         {
            l_tCsi->t_BcsmCamelTDPDataList.value[trueTcsiCount].serviceKey = l_serviceKey;
            TLOG(0,0,"Tcsi-SK Sending ServiceKey |%d|",l_serviceKey);
         }
         else
         {
            l_tCsi->t_BcsmCamelTDPDataList.value[trueTcsiCount].serviceKey = l_networkSkey;
            LLOG(0,0,"Tcsi-SK: Sending NetworkServiceKey:|%d| but Configured ServiceKey:|%d|",l_networkSkey,l_serviceKey);
         }
         l_tCsi->t_BcsmCamelTDPDataList.value[trueTcsiCount].defaultCallHandling = (OMAP3_DefaultCallHandling)p_ServiceKey->m_defCallHandle;
         // (0x80 | (((noa << 4) & 0x70) | (npi & 0x0f)))
         DLOG(0,0,"Tcsi-defCH |%d|",l_tCsi->t_BcsmCamelTDPDataList.value[trueTcsiCount].defaultCallHandling);
         l_tCsi->t_BcsmCamelTDPDataList.value[trueTcsiCount].gsmSCF_Address.value[0] = 0x91; // noa =1, npi =1

         /// RoamPartner ///
         if( g_CMConfigReaderObj->m_partnerScf > 0)
         {
            if(1 == (mp_sriSubData->m_partnerType)) // PartnerType Internal
            {
               if(true == m_Utility.getPartnerGsmScfAddr(p_ServiceKey->m_gsmScfAddr,mp_sriSubData->m_networkId,mp_sriSubData->m_PartnerNetId))
               {
                  LLOG(0,0,"FILLING PARTNER GSMSCFADDRESS IN TCSI AS PARTNERTYPE IS INTERNAL");
                  l_tCsi->t_BcsmCamelTDPDataList.value[trueTcsiCount].gsmSCF_Address.length = StringToBCD(&l_tCsi->t_BcsmCamelTDPDataList.value[trueTcsiCount].gsmSCF_Address.value[1],(u8*)m_Utility.m_partnerGsmScfAdd,strlen(m_Utility.m_partnerGsmScfAdd));
               }
               else
               {
                  LLOG(0,0,"SHOULD NOT COME IN THIS CASE FILLING ORIGINGAL GSMSCFADDRESS OF HOME NETWORK IN TCSI");
                  l_tCsi->t_BcsmCamelTDPDataList.value[trueTcsiCount].gsmSCF_Address.length = StringToBCD(&l_tCsi->t_BcsmCamelTDPDataList.value[trueTcsiCount].gsmSCF_Address.value[1],(u8*)p_ServiceKey->m_gsmScfAddr,strlen(p_ServiceKey->m_gsmScfAddr));
               }
            }
            else
            {
               l_tCsi->t_BcsmCamelTDPDataList.value[trueTcsiCount].gsmSCF_Address.length = StringToBCD(&l_tCsi->t_BcsmCamelTDPDataList.value[trueTcsiCount].gsmSCF_Address.value[1],(u8*)p_ServiceKey->m_gsmScfAddr,strlen(p_ServiceKey->m_gsmScfAddr));
            }
         }
         ///////////////////
         else
         {
            l_tCsi->t_BcsmCamelTDPDataList.value[trueTcsiCount].gsmSCF_Address.length = StringToBCD(&l_tCsi->t_BcsmCamelTDPDataList.value[trueTcsiCount].gsmSCF_Address.value[1],(u8*)p_ServiceKey->m_gsmScfAddr,strlen(p_ServiceKey->m_gsmScfAddr));
         }

         l_tCsi->t_BcsmCamelTDPDataList.value[trueTcsiCount].gsmSCF_Address.length++;
         l_TdpDataPresent = true;
         l_tCsi->t_BcsmCamelTDPDataList.count++;
         trueTcsiCount++;
      } 
   }
   return true;
}

EResult CtxtSendRoutingInfo :: checkOCSI(u16 aOcsiProfileId)
{
   DLOG(0,0,"In  chekOcsi");
   if(0 == aOcsiProfileId)
   {
      LLOG(0,0,"Ocsi not applicable ProfileID is 0");
      return CM_FAIL;
   }

   map<u16,OCSI*>::iterator l_ocsiItr;
   l_ocsiItr = g_spdPtr->m_OCSIMap.find(aOcsiProfileId);
   if(l_ocsiItr == g_spdPtr->m_OCSIMap.end())
   {
      CLOG(0,0,"OCSI profileID |%d| not found in map.. ",aOcsiProfileId);
      m_ErrCode = MAP_ERROR_systemFailure;
      return CM_ERROR; // send system failure
   }

   OCSI *lpOcsi = l_ocsiItr->second;

   if(lpOcsi == NULL)
   {
      ELOG(0,0,"Null values in OcsiMap for profileID |%d| .. ",aOcsiProfileId);
      m_ErrCode = MAP_ERROR_systemFailure;
      return CM_ERROR; // send system failure
   }

   if(0 == lpOcsi->m_csiState) // if OCSI is not there or not active
   {
      LLOG(0,0,"Ocsi not applicable - Csi state 0");
      return CM_FAIL;
   }

   if(m_highestCphGmsc >= lpOcsi->m_camelCapability) 
   {
      m_manipulatedOcsiCCH = lpOcsi->m_camelCapability; // CCH not manipulated
   }
   else
   {
      m_manipulatedOcsiCCH = m_highestCphGmsc; // CCH manipulated
   }  

   TLOG(0,1,"HighestCPHGmsc:[%d] OcsiCCH:[%d] ManipulatedOcsiCCH:[%d]",m_highestCphGmsc,lpOcsi->m_camelCapability,m_manipulatedOcsiCCH);

   TLOG(0,0,"O-CSI  Applicable");
   m_ocsiSet = true;
   return CM_CONTINUE;
}

bool CtxtSendRoutingInfo :: fillOCSI(u16 aOcsiProfileId,OMAP3_GmscCamelSubscriptionInfo *aGmscCamelInfo)
{
   DLOG(0,0,"In fillOCSI");

   if(m_ocsiSet == false)
   {
      DLOG(0,0,"Ocsi not set");
      return false;
   }

   OCSI *lpOcsi = g_spdPtr->m_OCSIMap[aOcsiProfileId];

   OMAP3_O_CSI *l_oCsi = &aGmscCamelInfo->o_CSI;

   aGmscCamelInfo->bit_mask |= OMAP3_GmscCamelSubscriptionInfo_o_CSI_present;

   l_oCsi->camelCapabilityHandling = m_manipulatedOcsiCCH;

   if(m_manipulatedOcsiCCH >= 2)
      aGmscCamelInfo->o_CSI.bit_mask |= OMAP3_O_CSI_camelCapabilityHandling_present;

   l_oCsi->o_BcsmCamelTDPDataList.count = 0;

   bool l_TdpDataPresent = false; 
   u32 l_ocsiServiceKeys[2];
   l_ocsiServiceKeys[0]= 0; // avoiding memset
   l_ocsiServiceKeys[1]= 0;

   u32 l_networkSkey = 0;

   u16 l_maxOcsiDps = 0;

   ServiceKey *p_ServiceKey = NULL;

   if(m_manipulatedOcsiCCH >= 3)
      l_maxOcsiDps  = 2;
   else
      l_maxOcsiDps = 1;

   u16 trueOcsiCount = 0;

   for(u16 i=0; i < l_maxOcsiDps; ++i)
   {
      l_ocsiServiceKeys[i] = lpOcsi->m_serviceKey[i];
      if(l_ocsiServiceKeys[i] != 0) 
      {
         p_ServiceKey = g_spdPtr->getCallServiceKeyPtr(mp_sriSubData->m_networkId,l_ocsiServiceKeys[i]);
         l_networkSkey = g_spdPtr->getNetworkServiceKey(mp_sriSubData->m_networkId,l_ocsiServiceKeys[i]); // 1.0.3.0

         if(NULL == p_ServiceKey)
         {
            LLOG(0,0,"CallServiceKeyPtr null");
            return false;
         }

         l_oCsi->o_BcsmCamelTDPDataList.value[trueOcsiCount].o_BcsmTriggerDetectionPoint = (OMAP3_O_BcsmTriggerDetectionPoint)p_ServiceKey->m_bcsmTDP;
         if(l_ocsiServiceKeys[i] == l_networkSkey) // 1.0.3.0
         {
            TLOG(0,0,"Ocsi-SK: Sending ServiceKey |%d|",l_ocsiServiceKeys[i]);
            l_oCsi->o_BcsmCamelTDPDataList.value[trueOcsiCount].serviceKey = l_ocsiServiceKeys[i];
         }
         else
         {
            LLOG(0,0,"Ocsi-SK: Sending NetworkServiceKey:|%d| but Configured ServiceKey:|%d|",l_networkSkey,l_ocsiServiceKeys[i]);
            l_oCsi->o_BcsmCamelTDPDataList.value[trueOcsiCount].serviceKey = l_networkSkey;
         }
         l_oCsi->o_BcsmCamelTDPDataList.value[trueOcsiCount].defaultCallHandling = (OMAP3_DefaultCallHandling)p_ServiceKey->m_defCallHandle;
         // (0x80 | (((noa << 4) & 0x70) | (npi & 0x0f)))
         l_oCsi->o_BcsmCamelTDPDataList.value[trueOcsiCount].gsmSCF_Address.value[0] = 0x91; // noa =1, npi =1

         /// RoamPartner ///
         if( g_CMConfigReaderObj->m_partnerScf > 0)
         {
            if(1 == (mp_sriSubData->m_partnerType)) // PartnerType Internal
            {
               if(true == m_Utility.getPartnerGsmScfAddr(p_ServiceKey->m_gsmScfAddr,mp_sriSubData->m_networkId,mp_sriSubData->m_PartnerNetId))
               {
                  LLOG(0,0,"FILLING PARTNER GSMSCFADDRESS IN OCSI AS PARTNERTYPE IS INTERNAL");
                  l_oCsi->o_BcsmCamelTDPDataList.value[trueOcsiCount].gsmSCF_Address.length = StringToBCD(&l_oCsi->o_BcsmCamelTDPDataList.value[trueOcsiCount].gsmSCF_Address.value[1],(u8*)m_Utility.m_partnerGsmScfAdd,strlen(m_Utility.m_partnerGsmScfAdd));
               }
               else
               {
                  LLOG(0,0,"SHOULD NOT COME IN THIS CASE FILLING ORIGINGAL GSMSCFADDRESS OF HOME NETWORK IN OCSI");
                  l_oCsi->o_BcsmCamelTDPDataList.value[trueOcsiCount].gsmSCF_Address.length = StringToBCD(&l_oCsi->o_BcsmCamelTDPDataList.value[trueOcsiCount].gsmSCF_Address.value[1],(u8*)p_ServiceKey->m_gsmScfAddr,strlen(p_ServiceKey->m_gsmScfAddr));
               }
            }
            else
            {
               l_oCsi->o_BcsmCamelTDPDataList.value[trueOcsiCount].gsmSCF_Address.length = StringToBCD(&l_oCsi->o_BcsmCamelTDPDataList.value[trueOcsiCount].gsmSCF_Address.value[1],(u8*)p_ServiceKey->m_gsmScfAddr,strlen(p_ServiceKey->m_gsmScfAddr));
            }
         }
         ///////////////////
         else
         {
            l_oCsi->o_BcsmCamelTDPDataList.value[trueOcsiCount].gsmSCF_Address.length = StringToBCD(&l_oCsi->o_BcsmCamelTDPDataList.value[trueOcsiCount].gsmSCF_Address.value[1],(u8*)p_ServiceKey->m_gsmScfAddr,strlen(p_ServiceKey->m_gsmScfAddr));
         }

         l_oCsi->o_BcsmCamelTDPDataList.value[trueOcsiCount].gsmSCF_Address.length++;
         l_TdpDataPresent = true;
         l_oCsi->o_BcsmCamelTDPDataList.count++;
         trueOcsiCount++;
      }
      else
      {
         DLOG(0,0,"Service Key Zero Ocsi index Pos |%d|",i);
      }
   }
   //////////////////////////////////////////////////////////

   bool l_oCritPresent = false;

   if(m_manipulatedOcsiCCH == 1) // No criteria for Phase1
      return l_oCritPresent;

   OMAP3_O_BcsmCamelTDPCriteriaList *l_oBcsmTdpCritList = &aGmscCamelInfo->o_BcsmCamelTDP_CriteriaList;
   l_oBcsmTdpCritList->count = 0;
   u16 l_criteriaVal[2];
   l_criteriaVal[0]=0;
   l_criteriaVal[1]=0;

   for(u16 l_critCount = 0; l_critCount < l_maxOcsiDps; l_critCount++)  
   {
      if(l_ocsiServiceKeys[l_critCount] != 0)
      {
         p_ServiceKey = g_spdPtr->getCallServiceKeyPtr(mp_sriSubData->m_networkId,l_ocsiServiceKeys[l_critCount]);
         l_criteriaVal[l_critCount] = p_ServiceKey->m_criteriaVal;
         if(l_criteriaVal[l_critCount] != 0)
         {
            l_oBcsmTdpCritList->count++;
         }
      }
   }

   DLOG(0,0,"Obcsm CriteriaList  Count |%d|",l_oBcsmTdpCritList->count);

   for(u16 i=0; i < l_oBcsmTdpCritList->count; ++i)
   {
      if(l_ocsiServiceKeys[i] != 0)
      {
         p_ServiceKey = g_spdPtr->getCallServiceKeyPtr(mp_sriSubData->m_networkId,l_ocsiServiceKeys[i]);

         l_oBcsmTdpCritList->value[i].o_BcsmTriggerDetectionPoint = (OMAP3_O_BcsmTriggerDetectionPoint)p_ServiceKey->m_bcsmTDP;

         DLOG(0,0,"CriteriaValue |%d|",l_criteriaVal[i]);
         bool numCriteria = false;
         bool bsCriteria = false;
         bool callTypeCriteria = false;
         bool causeValCriteria = false;
         switch(l_criteriaVal[i])
         {
            case 1:
               {
                  numCriteria = true;
                  DLOG(0,0,"NumbCriteria present");
               }
               break;
            case 2:
               {
                  bsCriteria = true;
                  DLOG(0,0,"BSCriteria present");
               }
               break;
            case 3:
               {
                  numCriteria =true;
                  bsCriteria =true;
                  DLOG(0,0,"NumCriteria + bsCriteria present");
               }
               break;
            case 4:
               {
                  callTypeCriteria = true;
                  DLOG(0,0,"callTypeCriteria present");
               }
               break;
            case 5:
               {
                  numCriteria =true;
                  callTypeCriteria = true;
                  DLOG(0,0,"numCriteria + callTypeCriteria present");
               }
               break;
            case 6:
               {
                  bsCriteria =true;
                  callTypeCriteria = true;
                  DLOG(0,0,"bsCriteria + callTypeCriteria present");
               }
               break;
            case 7:
               {
                  numCriteria =true;
                  bsCriteria =true;
                  callTypeCriteria = true;
                  DLOG(0,0,"numCriteria + bsCriteria + callTypeCriteriaeria present");
               }
               break;
            case 8:
               {
                  causeValCriteria = true;
                  DLOG(0,0,"causeValCriteria present");
               }
               break;
            default:
               {
                  DLOG(0,0,"No criteria present");
               }
         }
         if(true == bsCriteria)
         {
            u16 l_bsCount = p_ServiceKey->m_bsCriteria.m_bsCount;

            if(l_bsCount > 0)
            {
               l_oCritPresent = true;
               DLOG(0,0,"NumOfBasicServiceCriteria present");
               l_oBcsmTdpCritList->value[i].bit_mask |= OMAP3_O_BcsmCamelTDP_Criteria_basicServiceCriteria_present;

               l_oBcsmTdpCritList->value[i].basicServiceCriteria.count = l_bsCount; 

               DLOG(0,0," checkOCSI: value of basicServiceCriteriaCount |%d|",l_bsCount);

               for(u16 bs=0; bs < l_bsCount; bs++)
               {
                  if(p_ServiceKey->m_bsCriteria.m_bsTypeCode[bs].m_bsType == 1)
                  {
                     l_oBcsmTdpCritList->value[i].basicServiceCriteria.value[bs].choice = OMAP3_Ext_BasicServiceCode_ext_BearerService_chosen;
                     l_oBcsmTdpCritList->value[i].basicServiceCriteria.value[bs].u.ext_BearerService.length = 1;
                     l_oBcsmTdpCritList->value[i].basicServiceCriteria.value[bs].u.ext_BearerService.value[0]= p_ServiceKey->m_bsCriteria.m_bsTypeCode[bs].m_bscode;
                  }
                  if(p_ServiceKey->m_bsCriteria.m_bsTypeCode[bs].m_bsType == 2)
                  {
                     l_oBcsmTdpCritList->value[i].basicServiceCriteria.value[bs].choice = OMAP3_Ext_BasicServiceCode_ext_Teleservice_chosen;
                     l_oBcsmTdpCritList->value[i].basicServiceCriteria.value[bs].u.ext_Teleservice.length = 1;
                     l_oBcsmTdpCritList->value[i].basicServiceCriteria.value[bs].u.ext_Teleservice.value[0]=p_ServiceKey->m_bsCriteria.m_bsTypeCode[bs].m_bscode;
                  }
               }
            }
         }

         if(true == causeValCriteria)
         {
            if(m_manipulatedOcsiCCH >= 3)
            {
               u16 l_cvCount = p_ServiceKey->m_cvCriteria.m_cvCount;
               if(l_cvCount > 0)
               {
                  l_oCritPresent = true;
                  l_oBcsmTdpCritList->value[i].bit_mask |= OMAP3_o_CauseValueCriteria_present;
                  l_oBcsmTdpCritList->value[i].o_CauseValueCriteria.count = l_cvCount;

                  for(u16 j=0; j < l_cvCount; ++j)
                  {
                     DLOG(0,0,"CauseValueCriteria present - value |%d|",p_ServiceKey->m_cvCriteria.m_cv[j]);
                     l_oBcsmTdpCritList->value[i].o_CauseValueCriteria.value[j].length = 1; 
                     l_oBcsmTdpCritList->value[i].o_CauseValueCriteria.value[j].value[0]= p_ServiceKey->m_cvCriteria.m_cv[j];
                  }
               }
            }
         }
         if(true == callTypeCriteria)
         {
            l_oCritPresent = true;
            l_oBcsmTdpCritList->value[i].bit_mask |= OMAP3_callTypeCriteria_present;
            l_oBcsmTdpCritList->value[i].callTypeCriteria = (OMAP3_CallTypeCriteria)p_ServiceKey->m_callTypeCriteria;
            DLOG(0,0,"CalltypeCriteria value |%d|",p_ServiceKey->m_callTypeCriteria);
         }
         if(true == numCriteria)
         {
            l_oCritPresent = true;

            u16 l_matchType = (u16)p_ServiceKey->m_destCriteria.m_matchType;

            l_oBcsmTdpCritList->value[i].bit_mask |= OMAP3_destinationNumberCriteria_present;
            l_oBcsmTdpCritList->value[i].destinationNumberCriteria.matchType = (OMAP3_MatchType)l_matchType;
            DLOG(0,0,"Match Type value - |%d|",l_matchType);

            u16 l_destNumLenListCount = l_oBcsmTdpCritList->value[i].destinationNumberCriteria.destinationNumberLengthList.count = p_ServiceKey->m_destCriteria.m_destNumCritLenListCount;

            DLOG(0,0,"DestNumLenList count |%d|",l_destNumLenListCount);

            for(u16 k=0; k < l_destNumLenListCount; k++)
            {
               l_oBcsmTdpCritList->value[i].destinationNumberCriteria.bit_mask |= OMAP3_destinationNumberLengthList_present;
               l_oBcsmTdpCritList->value[i].destinationNumberCriteria.destinationNumberLengthList.value[k] = p_ServiceKey->m_destCriteria.m_destNumLenList[k]; 
               DLOG(0,0,"DestNumLenList value |%d|",p_ServiceKey->m_destCriteria.m_destNumLenList[k]);
            }

            u16 l_destNumListCount = l_oBcsmTdpCritList->value[i].destinationNumberCriteria.destinationNumberList.count =  p_ServiceKey->m_destCriteria.m_destNumCritListCount;

            DLOG(0,0,"DestNumListCount  |%d|",l_destNumListCount);

            for(u16 j=0; j<l_destNumListCount; j++)
            {
               l_oBcsmTdpCritList->value[i].destinationNumberCriteria.bit_mask |= OMAP3_destinationNumberList_present;
               switch(j)
               {
                  case 0:
                     {
                        l_oBcsmTdpCritList->value[i].destinationNumberCriteria.destinationNumberList.value[j].value[0] = 0x91;
                        l_oBcsmTdpCritList->value[i].destinationNumberCriteria.destinationNumberList.value[j].length = StringToBCD(&l_oBcsmTdpCritList->value[i].destinationNumberCriteria.destinationNumberList.value[j].value[1],(u8*)p_ServiceKey->m_destCriteria.m_destNumList1,strlen(p_ServiceKey->m_destCriteria.m_destNumList1));
                        l_oBcsmTdpCritList->value[i].destinationNumberCriteria.destinationNumberList.value[j].length++;
                     }
                     break;
                  case 1:
                     {
                        l_oBcsmTdpCritList->value[i].destinationNumberCriteria.destinationNumberList.value[j].value[0] = 0x91;
                        l_oBcsmTdpCritList->value[i].destinationNumberCriteria.destinationNumberList.value[j].length = StringToBCD(&l_oBcsmTdpCritList->value[i].destinationNumberCriteria.destinationNumberList.value[j].value[1],(u8*)p_ServiceKey->m_destCriteria.m_destNumList2,strlen(p_ServiceKey->m_destCriteria.m_destNumList2));
                        l_oBcsmTdpCritList->value[i].destinationNumberCriteria.destinationNumberList.value[j].length++;
                     }
                     break;
                  case 2:
                     {
                        l_oBcsmTdpCritList->value[i].destinationNumberCriteria.destinationNumberList.value[j].value[0] = 0x91;
                        l_oBcsmTdpCritList->value[i].destinationNumberCriteria.destinationNumberList.value[j].length = StringToBCD(&l_oBcsmTdpCritList->value[i].destinationNumberCriteria.destinationNumberList.value[j].value[1],(u8*)p_ServiceKey->m_destCriteria.m_destNumList3,strlen(p_ServiceKey->m_destCriteria.m_destNumList3));
                        l_oBcsmTdpCritList->value[i].destinationNumberCriteria.destinationNumberList.value[j].length++;
                     }
                     break;
                  case 3:
                     {
                        l_oBcsmTdpCritList->value[i].destinationNumberCriteria.destinationNumberList.value[j].value[0] = 0x91;
                        l_oBcsmTdpCritList->value[i].destinationNumberCriteria.destinationNumberList.value[j].length = StringToBCD(&l_oBcsmTdpCritList->value[i].destinationNumberCriteria.destinationNumberList.value[j].value[1],(u8*)p_ServiceKey->m_destCriteria.m_destNumList4,strlen(p_ServiceKey->m_destCriteria.m_destNumList4));
                        l_oBcsmTdpCritList->value[i].destinationNumberCriteria.destinationNumberList.value[j].length++;
                     }
                     break;
                  case 4:
                     {
                        l_oBcsmTdpCritList->value[i].destinationNumberCriteria.destinationNumberList.value[j].value[0] = 0x91;
                        l_oBcsmTdpCritList->value[i].destinationNumberCriteria.destinationNumberList.value[j].length = StringToBCD(&l_oBcsmTdpCritList->value[i].destinationNumberCriteria.destinationNumberList.value[j].value[1],(u8*)p_ServiceKey->m_destCriteria.m_destNumList5,strlen(p_ServiceKey->m_destCriteria.m_destNumList5));
                        l_oBcsmTdpCritList->value[i].destinationNumberCriteria.destinationNumberList.value[j].length++;
                     }
                     break;
                  case 5:
                     {
                        l_oBcsmTdpCritList->value[i].destinationNumberCriteria.destinationNumberList.value[j].value[0] = 0x91;
                        l_oBcsmTdpCritList->value[i].destinationNumberCriteria.destinationNumberList.value[j].length = StringToBCD(&l_oBcsmTdpCritList->value[i].destinationNumberCriteria.destinationNumberList.value[j].value[1],(u8*)p_ServiceKey->m_destCriteria.m_destNumList6,strlen(p_ServiceKey->m_destCriteria.m_destNumList6));
                        l_oBcsmTdpCritList->value[i].destinationNumberCriteria.destinationNumberList.value[j].length++;
                     }
                     break;
                  case 6:
                     {
                        l_oBcsmTdpCritList->value[i].destinationNumberCriteria.destinationNumberList.value[j].value[0] = 0x91;
                        l_oBcsmTdpCritList->value[i].destinationNumberCriteria.destinationNumberList.value[j].length = StringToBCD(&l_oBcsmTdpCritList->value[i].destinationNumberCriteria.destinationNumberList.value[j].value[1],(u8*)p_ServiceKey->m_destCriteria.m_destNumList7,strlen(p_ServiceKey->m_destCriteria.m_destNumList7));
                        l_oBcsmTdpCritList->value[i].destinationNumberCriteria.destinationNumberList.value[j].length++;
                     }
                     break;
                  case 7:
                     {
                        l_oBcsmTdpCritList->value[i].destinationNumberCriteria.destinationNumberList.value[j].value[0] = 0x91;
                        l_oBcsmTdpCritList->value[i].destinationNumberCriteria.destinationNumberList.value[j].length = StringToBCD(&l_oBcsmTdpCritList->value[i].destinationNumberCriteria.destinationNumberList.value[j].value[1],(u8*)p_ServiceKey->m_destCriteria.m_destNumList8,strlen(p_ServiceKey->m_destCriteria.m_destNumList8));
                        l_oBcsmTdpCritList->value[i].destinationNumberCriteria.destinationNumberList.value[j].length++;
                     }
                     break;
                  case 8:
                     {
                        l_oBcsmTdpCritList->value[i].destinationNumberCriteria.destinationNumberList.value[j].value[0] = 0x91;
                        l_oBcsmTdpCritList->value[i].destinationNumberCriteria.destinationNumberList.value[j].length = StringToBCD(&l_oBcsmTdpCritList->value[i].destinationNumberCriteria.destinationNumberList.value[j].value[1],(u8*)p_ServiceKey->m_destCriteria.m_destNumList9,strlen(p_ServiceKey->m_destCriteria.m_destNumList9));
                        l_oBcsmTdpCritList->value[i].destinationNumberCriteria.destinationNumberList.value[j].length++;
                     }
                     break;
                  case 9:
                     {
                        l_oBcsmTdpCritList->value[i].destinationNumberCriteria.destinationNumberList.value[j].value[0] = 0x91;
                        l_oBcsmTdpCritList->value[i].destinationNumberCriteria.destinationNumberList.value[j].length = StringToBCD(&l_oBcsmTdpCritList->value[i].destinationNumberCriteria.destinationNumberList.value[j].value[1],(u8*)p_ServiceKey->m_destCriteria.m_destNumList10,strlen(p_ServiceKey->m_destCriteria.m_destNumList10));
                        l_oBcsmTdpCritList->value[i].destinationNumberCriteria.destinationNumberList.value[j].length++;
                     }
                     break;
                  default:
                     {
                        DLOG(0,0,"Default case DestNumList");
                     }
                     break;
               }
            }
         }
         if(true == l_oCritPresent)
         {
            aGmscCamelInfo->bit_mask |= OMAP3_GmscCamelSubscriptionInfo_o_BcsmCamelTDP_CriteriaList_present;
            DLOG(0,0,"O-CSI Criteria present");
         }
      }
   }
   ///////////////////////////////////////////////////////
   m_ocsiSet = true;
   return l_oCritPresent;
}

EResult CtxtSendRoutingInfo :: checkDCSI(u16 aDcsiProfileId)
{
   DLOG(0,0,"In chekDcsi");

   if(m_highestCphGmsc <= 2)
   {
      TLOG(0,0,"maxSuppCphGmsc[%d] checkDcsi not applicable",m_highestCphGmsc);
      return CM_FAIL;
   }

   if(0 == aDcsiProfileId)
   {
      LLOG(0,0,"Dcsi not applicable ProfileID is 0");
      return CM_FAIL;
   }

   map<u16,DCSI*>::iterator l_dcsiItr;
   l_dcsiItr = g_spdPtr->m_DCSIMap.find(aDcsiProfileId);
   if(l_dcsiItr == g_spdPtr->m_DCSIMap.end())
   {
      CLOG(0,0,"DCSI profileID |%d| not found in map.. ",aDcsiProfileId);
      m_ErrCode = MAP_ERROR_systemFailure;
      return CM_ERROR; // send system failure
   }

   DCSI *lpDcsi = l_dcsiItr->second; 

   if(lpDcsi == NULL)
   {
      ELOG(0,0,"Null values in DcsiMap for profileID |%d| .. ",aDcsiProfileId);
      m_ErrCode = MAP_ERROR_systemFailure;
      return CM_ERROR; // send system failure
   }

   if(0 == lpDcsi->m_csiState) // if DCSI is not there or not active
   {
      LLOG(0,0,"Dcsi not applicable CSIstate is 0");
      return CM_FAIL;
   }

   if(lpDcsi->m_camelCapability < 3)
   {
      LLOG(0,0,"Dcsi CCH is less than phase3 returning false");
      return CM_FAIL;
   }

   if(m_highestCphGmsc >= lpDcsi->m_camelCapability) 
   {
      m_manipulatedDcsiCCH = lpDcsi->m_camelCapability; // CCH not manipulated
   }
   else
   {
      m_manipulatedDcsiCCH = m_highestCphGmsc; // CCH manipulated
   }  
   TLOG(0,1,"HighestCPHGmsc:[%d] DcsiCCH:[%d] ManipulatedDcsiCCH:[%d]",m_highestCphGmsc,lpDcsi->m_camelCapability,m_manipulatedDcsiCCH);

   LLOG(0,0,"Dcsi  Applicable");
   m_dcsiSet = true;
   return CM_CONTINUE;
}

bool CtxtSendRoutingInfo :: fillDCSI(u16 aDcsiProfileId,OMAP3_GmscCamelSubscriptionInfo *aGmscCamelInfo)
{
   DLOG(0,0,"IN fillDCSI");

   if(m_dcsiSet == false)
   {
      DLOG(0,0,"Dcsi not Set");
      return false;
   }

   DCSI *lpDcsi = g_spdPtr->m_DCSIMap[aDcsiProfileId]; 

   aGmscCamelInfo->bit_mask |= OMAP3_GmscCamelSubscriptionInfo_d_csi_present;

   OMAP3_D_CSI *l_dCsi = &aGmscCamelInfo->d_csi;

   aGmscCamelInfo->d_csi.bit_mask |= OMAP3_D_CSI_camelCapabilityHandling_present;
   l_dCsi->camelCapabilityHandling = m_manipulatedDcsiCCH;

   u32 l_serviceKey = 0;
   u32 l_networkSkey = 0;

   ServiceKey *p_ServiceKey = NULL;

   l_serviceKey = lpDcsi->m_serviceKey3;
   l_networkSkey = g_spdPtr->getNetworkServiceKey(mp_sriSubData->m_networkId,l_serviceKey); // 1.0.3.0


   DLOG(0,0,"servickey value in DCSI |%d|",l_serviceKey);
   bool l_dCriteria = false;

   if(l_serviceKey != 0)
   {
      p_ServiceKey = g_spdPtr->getCallServiceKeyPtr(mp_sriSubData->m_networkId,l_serviceKey);// only one DP possible but no option of sending in res ?
      if(NULL == p_ServiceKey)
      {
         LLOG(0,0,"CallServiceKeyPtr null");
         return false;
      }
      l_dCriteria = true;
      l_dCsi->bit_mask |= OMAP3_dp_AnalysedInfoCriteriaList_present;
      l_dCsi->dp_AnalysedInfoCriteriaList.count = 1;

      if(l_serviceKey == l_networkSkey) // 1.0.3.0
      {
         LLOG(0,0,"Dcsi-SK: Sending ServiceKey |%d|",l_serviceKey);
         l_dCsi->dp_AnalysedInfoCriteriaList.value[0].serviceKey = p_ServiceKey->m_serviceKey;
      }
      else
      {
         LLOG(0,0,"Dcsi-SK: Sending NetworkServiceKey:|%d| but Configured ServiceKey:|%d|",l_networkSkey,l_serviceKey);
         l_dCsi->dp_AnalysedInfoCriteriaList.value[0].serviceKey = l_networkSkey;
      }
      l_dCsi->dp_AnalysedInfoCriteriaList.value[0].defaultCallHandling = (OMAP3_DefaultCallHandling)p_ServiceKey->m_defCallHandle;

      // (0x80 | (((noa << 4) & 0x70) | (npi & 0x0f)))
      l_dCsi->dp_AnalysedInfoCriteriaList.value[0].gsmSCF_Address.value[0] = 0x91; // noa =1, npi =1


      /// RoamPartner ///
      if( g_CMConfigReaderObj->m_partnerScf > 0)
      {
         if(1 == (mp_sriSubData->m_partnerType)) // PartnerType Internal
         {
            if(true == m_Utility.getPartnerGsmScfAddr(p_ServiceKey->m_gsmScfAddr,mp_sriSubData->m_networkId,mp_sriSubData->m_PartnerNetId))
            {
               LLOG(0,0,"FILLING PARTNER GSMSCFADDRESS IN DCSI AS PARTNERTYPE IS INTERNAL");
               l_dCsi->dp_AnalysedInfoCriteriaList.value[0].gsmSCF_Address.length = StringToBCD(&l_dCsi->dp_AnalysedInfoCriteriaList.value[0].gsmSCF_Address.value[1],(u8*)m_Utility.m_partnerGsmScfAdd,strlen(m_Utility.m_partnerGsmScfAdd));
            }
            else
            {
               LLOG(0,0,"SHOULD NOT COME IN THIS CASE FILLING ORIGINGAL GSMSCFADDRESS OF HOME NETWORK IN DCSI");
               l_dCsi->dp_AnalysedInfoCriteriaList.value[0].gsmSCF_Address.length = StringToBCD(&l_dCsi->dp_AnalysedInfoCriteriaList.value[0].gsmSCF_Address.value[1],(u8*)p_ServiceKey->m_gsmScfAddr,strlen(p_ServiceKey->m_gsmScfAddr));
            }
         }
         else
         {
            l_dCsi->dp_AnalysedInfoCriteriaList.value[0].gsmSCF_Address.length = StringToBCD(&l_dCsi->dp_AnalysedInfoCriteriaList.value[0].gsmSCF_Address.value[1],(u8*)p_ServiceKey->m_gsmScfAddr,strlen(p_ServiceKey->m_gsmScfAddr));
         }
      }
      ///////////////////
      else
      {
         l_dCsi->dp_AnalysedInfoCriteriaList.value[0].gsmSCF_Address.length = StringToBCD(&l_dCsi->dp_AnalysedInfoCriteriaList.value[0].gsmSCF_Address.value[1],(u8*)p_ServiceKey->m_gsmScfAddr,strlen(p_ServiceKey->m_gsmScfAddr));
      }

      l_dCsi->dp_AnalysedInfoCriteriaList.value[0].gsmSCF_Address.length++;

      // (0x80 | (((noa << 4) & 0x70) | (npi & 0x0f)))
      l_dCsi->dp_AnalysedInfoCriteriaList.value[0].dialledNumber.value[0] = 0x91; // noa =1, npi =1
      l_dCsi->dp_AnalysedInfoCriteriaList.value[0].dialledNumber.length = StringToBCD(&l_dCsi->dp_AnalysedInfoCriteriaList.value[0].dialledNumber.value[1],(u8*)p_ServiceKey->m_dialledNum,strlen(p_ServiceKey->m_dialledNum));
      l_dCsi->dp_AnalysedInfoCriteriaList.value[0].dialledNumber.length++;
   } 
   else
   {
      DLOG(0,0,"Service Key Zero Dcsi");
   }

   m_dcsiSet = true;
   return l_dCriteria;
}

EResult CtxtSendRoutingInfo :: checkNonTelephonyHLRProvisioning() // 1.0.3.0
{
   DLOG(0,0,"In checkNonTelephonyHLRProvisioning");
   u16 l_BsrvcType = mp_sriSubData->m_bsrvcType;
   u16 l_BsrvcCode = mp_sriSubData->m_bsrvcCode;
   switch(l_BsrvcType)
   {
      case 2: //CM_TELESERVICE_TYPE
         {
            if(mp_sriSubData->m_TeleSrvcCodeArr[0] == '1')
            {
               DLOG(0,0,"All TelseServices Provisioned");
               return CM_CONTINUE;
            }

            u16 l_teleIndex = g_spdPtr->m_TeleToDB[l_BsrvcCode];   
            u16 l_bsGroup =  m_Utility.getBSGroup(l_BsrvcCode,(EBasicServiceType)l_BsrvcType);
            u16 l_groupIndex = g_spdPtr->m_TeleToDB[l_bsGroup];
            DLOG(0,0,"TeleGroupIndex |%d| TeleIndex |%d|",l_groupIndex,l_teleIndex);
            if((mp_sriSubData->m_TeleSrvcCodeArr[l_groupIndex] == '1') || (mp_sriSubData->m_TeleSrvcCodeArr[l_teleIndex] == '1'))
            {
               DLOG(0,0,"Either TeleGroup or TeleService provisioned");
               return CM_CONTINUE;
            }
            else
            {
               CLOG(0,0,"Error TeleService Not Provisioned");
               m_ErrCode = MAP_ERROR_teleservNotProv;
               return CM_ERROR;
            }
         }
         break;
      case 1: //CM_BEARER_SERVICE_TYPE
         {
            if(mp_sriSubData->m_BearSrvcCodeArr[0] == '1')
            {
               DLOG(0,0," All BearerServices Provisioned");
               return CM_CONTINUE;
            }

            u16 l_bearIndex = g_spdPtr->m_BearerToDB[l_BsrvcCode];   
            u16 l_bsGroup =  m_Utility.getBSGroup(l_BsrvcCode,(EBasicServiceType)l_BsrvcType);
            u16 l_groupIndex = g_spdPtr->m_BearerToDB[l_bsGroup];

            DLOG(0,0,"BearerGroupIndex |%d| BearerIndex |%d|",l_groupIndex,l_bearIndex);
            if((mp_sriSubData->m_BearSrvcCodeArr[l_groupIndex] == '1') || (mp_sriSubData->m_BearSrvcCodeArr[l_bearIndex] == '1'))
            {
               DLOG(0,0,"Either BearerGroup or BearerService provisioned");
               return CM_CONTINUE;
            }
            else
            {
               CLOG(0,0,"Error BearerService Not Provisioned");
               m_ErrCode = MAP_ERROR_bearerServNotProv;
               return CM_ERROR;
            }
         }
         break;
      default:
         break;
   }

   if(1 == g_CMConfigReaderObj->m_passSriSGInfoNotFound)
   {
      LLOG(0,0,"SIGNAL-INFO not found in BC-Translation Table but Still passing SRI because configured");
      return CM_CONTINUE;
   }

   g_si.sendSnmpTrap(g_CMsignalInfoNotFoundTrap, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL);
   return CM_ERROR;
}

EResult CtxtSendRoutingInfo :: checkNonTelephonyVLRProvisioning() // 1.0.3.0
{
   DLOG(0,0,"In checkNonTelephonyVLRProvisioning");
   u16 l_BsrvcType = mp_sriSubData->m_bsrvcType;
   u16 l_BsrvcCode = mp_sriSubData->m_bsrvcCode;
   switch(l_BsrvcType)
   {
      case 2: //CM_TELESERVICE_TYPE
         {
            u16 l_teleIndex = g_spdPtr->m_TeleToDB[l_BsrvcCode];   
            u16 l_bsGroup =  m_Utility.getBSGroup(l_BsrvcCode,(EBasicServiceType)l_BsrvcType);
            u16 l_groupIndex = g_spdPtr->m_TeleToDB[l_bsGroup];
            DLOG(0,0,"TeleGroupIndex |%d| TeleIndex |%d|",l_groupIndex,l_teleIndex);
            if((mp_sriSubData->m_VlrUnsupTeleSrvcArr[l_groupIndex] != '1') && (mp_sriSubData->m_VlrUnsupTeleSrvcArr[l_teleIndex] != '1'))
            {
               DLOG(0,0,"Either TeleGroup or TeleService code supported in VLR");
               return CM_CONTINUE;
            }
            else
            {
               CLOG(0,0,"TeleService Code Not Supported in VLR sending FacilityNotSupported Error");
               m_ErrCode = MAP_ERROR_facilityNotSup;
               return CM_ERROR;
            }
         }
         break;
      case 1: //CM_BEARER_SERVICE_TYPE
         {
            u16 l_bearIndex = g_spdPtr->m_BearerToDB[l_BsrvcCode];   
            u16 l_bsGroup =  m_Utility.getBSGroup(l_BsrvcCode,(EBasicServiceType)l_BsrvcType);
            u16 l_groupIndex = g_spdPtr->m_BearerToDB[l_bsGroup];

            DLOG(0,0,"BearerGroupIndex |%d| BearerIndex |%d|",l_groupIndex,l_bearIndex);
            if((mp_sriSubData->m_VlrUnsupBearSrvcArr[l_groupIndex] != '1') && (mp_sriSubData->m_VlrUnsupBearSrvcArr[l_bearIndex] != '1'))
            {
               DLOG(0,0,"Either BearerGroup or BearerService code supported in VLR");
               return CM_CONTINUE;
            }
            else
            {
               CLOG(0,0,"BearerService Code Not Supported in VLR sending FacilityNotSupported Error");
               m_ErrCode = MAP_ERROR_facilityNotSup;
               return CM_ERROR;
            }
         }
         break;
      default:
         break;
   }

   if(1 == g_CMConfigReaderObj->m_passSriSGInfoNotFound)
   {
      LLOG(0,0,"SIGNAL-INFO not found in BC-Translation Table but Still passing SRI because configured");
      return CM_CONTINUE;
   }

   g_si.sendSnmpTrap(g_CMsignalInfoNotFoundTrap, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL);
   return CM_ERROR;
}
EResult CtxtSendRoutingInfo :: checkHLRSubscription()
{
   DLOG(0,0,"In checkHLRSubscription");
   switch(m_ServiceType)
   {
      case CM_TELESERVICE_TYPE:
         {
            if(mp_sriSubData->m_TeleSrvcCodeArr[0] == '1')
            {
               DLOG(0,0,"All TelseServices Provisioned");
               return CM_CONTINUE;
            }

            u16 l_teleIndex = g_spdPtr->m_TeleToDB[m_ServiceCode];   
            u16 l_bsGroup =  m_Utility.getBSGroup(m_ServiceCode,m_ServiceType);
            u16 l_groupIndex = g_spdPtr->m_TeleToDB[l_bsGroup];
            DLOG(0,0,"TeleGroupIndex |%d| TeleIndex |%d|",l_groupIndex,l_teleIndex);
            if((mp_sriSubData->m_TeleSrvcCodeArr[l_groupIndex] == '1') || (mp_sriSubData->m_TeleSrvcCodeArr[l_teleIndex] == '1'))
            {
               DLOG(0,0,"Either TeleGroup or TeleService provisioned");
               return CM_CONTINUE;
            }
            else
            {
               CLOG(0,0,"Error TeleService Not Provisioned");
               m_ErrCode = MAP_ERROR_teleservNotProv;
               return CM_ERROR;
            }
         }
         break;
      case CM_BEARER_SERVICE_TYPE:
         {
            if(mp_sriSubData->m_BearSrvcCodeArr[0] == '1')
            {
               DLOG(0,0," All BearerServices Provisioned");
               return CM_CONTINUE;
            }

            u16 l_bearIndex = g_spdPtr->m_BearerToDB[m_ServiceCode];   
            u16 l_bsGroup =  m_Utility.getBSGroup(m_ServiceCode,m_ServiceType);
            u16 l_groupIndex = g_spdPtr->m_BearerToDB[l_bsGroup];

            DLOG(0,0,"BearerGroupIndex |%d| BearerIndex |%d|",l_groupIndex,l_bearIndex);
            if((mp_sriSubData->m_BearSrvcCodeArr[l_groupIndex] == '1') || (mp_sriSubData->m_BearSrvcCodeArr[l_bearIndex] == '1'))
            {
               DLOG(0,0,"Either BearerGroup or BearerService provisioned");
               return CM_CONTINUE;
            }
            else
            {
               CLOG(0,0,"Error BearerService Not Provisioned");
               m_ErrCode = MAP_ERROR_bearerServNotProv;
               return CM_ERROR;
            }
         }
         break;
      default:
         return CM_ERROR;
         break;
   }
   return CM_ERROR;
}

EResult CtxtSendRoutingInfo :: checkVLRSubscription()
{
   DLOG(0,0,"In checkVLRSubscription");
   switch(m_ServiceType)
   {
      case CM_TELESERVICE_TYPE:
         {
            u16 l_teleIndex = g_spdPtr->m_TeleToDB[m_ServiceCode];   
            u16 l_bsGroup =  m_Utility.getBSGroup(m_ServiceCode,m_ServiceType);
            u16 l_groupIndex = g_spdPtr->m_TeleToDB[l_bsGroup];
            DLOG(0,0,"TeleGroupIndex |%d| TeleIndex |%d|",l_groupIndex,l_teleIndex);
            if((mp_sriSubData->m_VlrUnsupTeleSrvcArr[l_groupIndex] != '1') && (mp_sriSubData->m_VlrUnsupTeleSrvcArr[l_teleIndex] != '1'))
            {
               DLOG(0,0,"Either TeleGroup or TeleService code supported in VLR");
               return CM_CONTINUE;
            }
            else
            {
               CLOG(0,0,"TeleService Code Not Supported in VLR sending FacilityNotSupported Error");
               m_ErrCode = MAP_ERROR_facilityNotSup;
               return CM_ERROR;
            }
         }
         break;
      case CM_BEARER_SERVICE_TYPE:
         {
            u16 l_bearIndex = g_spdPtr->m_BearerToDB[m_ServiceCode];   
            u16 l_bsGroup =  m_Utility.getBSGroup(m_ServiceCode,m_ServiceType);
            u16 l_groupIndex = g_spdPtr->m_BearerToDB[l_bsGroup];

            DLOG(0,0,"BearerGroupIndex |%d| BearerIndex |%d|",l_groupIndex,l_bearIndex);
            if((mp_sriSubData->m_VlrUnsupBearSrvcArr[l_groupIndex] != '1') && (mp_sriSubData->m_VlrUnsupBearSrvcArr[l_bearIndex] != '1'))
            {
               DLOG(0,0,"Either BearerGroup or BearerService code supported in VLR");
               return CM_CONTINUE;
            }
            else
            {
               CLOG(0,0,"BearerService Code Not Supported in VLR sending FacilityNotSupported Error");
               m_ErrCode = MAP_ERROR_facilityNotSup;
               return CM_ERROR;
            }
         }
         break;
      default:
         return CM_ERROR;
         break;
   }
   return CM_ERROR;
}
EResult CtxtSendRoutingInfo :: checkSRI(void *aSRI)
{
   switch(m_MapVer)
   {
      case MAP_V3:
         {
            DLOG(0,0,"In checkSRI-V3");
            IMAP3_SendRoutingInfoArg *p_SRIv3 = (IMAP3_SendRoutingInfoArg*)aSRI; 
            if(p_SRIv3->msisdn.length <= 0)
            {
               CLOG(0,0,"Mandatory Param Msisdn missing or corrupt");
               m_ErrCode = MAP_ERROR_dataMissing;
               return CM_ERROR;
            }
            else
            {
               // assuming we get p_SRIv3->msisdn.value[0]=0x91 so extracting msisdn from index[1]
               s8 tempMsisdn[CM_MSISDNLEN]; 
               memset(tempMsisdn,'\0',sizeof(tempMsisdn));
               s8 destNum[30];
               memset(destNum,'\0',sizeof(destNum));

               BCDToString((u8*)tempMsisdn,&p_SRIv3->msisdn.value[1],p_SRIv3->msisdn.length-1);
               TLOG(0,0,"Msisdn present - value |%s|",tempMsisdn);

               if(p_SRIv3->msisdn.value[0] != 0x91)
               {
                  LLOG(0,0,"Dialing pattern not international - Nai-Npi:[%x]",p_SRIv3->msisdn.value[0]);
                  getCC();

                  if(m_CC == NULL)
                  {
                     CLOG(0,0,"CC not found Sending System failure");
                     m_ErrCode = MAP_ERROR_systemFailure;
                     return CM_ERROR;
                  }

                  // SRI CC handling Begin //
                  // msisdn with "00"    
                  if(0 == memcmp(tempMsisdn, "00", 2)) // "00" means it has CC 
                  {
                     strcpy((s8*)m_Msisdn, &tempMsisdn[2]);
                     LLOG(0,0,"Msisdn starts with 00 and implies CC present Removing 00 Msisdn|%s|",m_Msisdn);
                  }
                  // msisdn with "0"
                  else if(0 == memcmp(tempMsisdn, "0", 1)) // only "0" means it does not have CC so appending CC
                  {
                     sprintf(destNum,"%s%s", m_CC, &tempMsisdn[1]);
                     strcpy((s8*)m_Msisdn, destNum);
                     LLOG(0,0,"Msisdn starts with 0 implies CC not present Removing 0 and Appending CC |%s|",m_Msisdn);
                  }
                  // msisdn without "0" and "00"; CC not present Appending CC 
                  else if(0 != memcmp(tempMsisdn,m_CC,strlen(m_CC)))
                  {
                     sprintf(destNum, "%s%s", m_CC,tempMsisdn);
                     strcpy((s8*)m_Msisdn, destNum);
                     LLOG(0,0,"Msisdn starts without 0 and 00 : CC not present Appending CC Msisdn|%s|",m_Msisdn);
                  }
                  // absolute msisdn starting digits match with cc eg: 9191....
                  /*else if((0 == memcmp(tempMsisdn, m_CC, strlen(m_CC))) && (tempMsisdnLen==(strlen(tempMsisdn))))
                    {
                    sprintf(destNum, "%s%s", m_CC, tempMsisdn);
                    strcpy((s8*)m_Msisdn, destNum); 
                    DLOG(0,0,"Msisdn starting digits match with CC Appending CC Msisdn|%s|",m_Msisdn);
                    }*/ 
                  else
                  {
                     // Normal Case 
                     strcpy((s8*)m_Msisdn,tempMsisdn); 
                     DLOG(0,0,"Normal Msisdn staring with CC - value |%s|",m_Msisdn);
                     m_MsisdnLen = strlen((s8*)m_Msisdn);
                     setTraceMsisdn((s8*)m_Msisdn);
                  }
               }
               else
               {
                  // Normal Case International format
                  TLOG(0,0,"Dialing pattern International - Nai-Npi:[%x]",p_SRIv3->msisdn.value[0]);
                  s8* l_msisdn = NULL;
                  l_msisdn = g_spdPtr->getMsisdnValue(tempMsisdn);
                  strcpy((s8*)m_Msisdn,l_msisdn);
                  DLOG(0,0,"Normal Msisdn staring with CC - value |%s|",m_Msisdn);
                  m_MsisdnLen = strlen((s8*)m_Msisdn);
                  setTraceMsisdn((s8*)m_Msisdn);
               }

               m_tdr.setChar(TDR_INDEX_REQUEST_TYPE,'M'); // 1-msisdn 2-imsi 3-both
               m_tdr.setString(TDR_INDEX_REQUEST_MSISDN,(s8*)m_Msisdn);

            }

            /////////// END ///////////

            //if((p_SRIv3->bit_mask & OMAP3_SendRoutingInfoArg_or_Interrogation_present)||(p_SRIv3->bit_mask & OMAP3_or_Capability_present))
            if(p_SRIv3->bit_mask & OMAP3_SendRoutingInfoArg_or_Interrogation_present) //1040A
            {
               LLOG(0,0,"SRI received with OR-parameters - OR not allowed");
               m_ErrCode = MAP_ERROR_orNotAllowed;
               return CM_ERROR;
            }

            if(p_SRIv3->bit_mask & IMAP3_SendRoutingInfoArg_cug_CheckInfo_present)
            {
               if(!(p_SRIv3->cug_CheckInfo.bit_mask & IMAP3_cug_OutgoingAccess_present))
               {
                  CLOG(0,0,"CUG reject as OutgoingAccess is not present in CugCheckInfo");
                  m_ErrCode = MAP_ERROR_CUG_Reject;
                  return CM_ERROR;
               }
               // Note: Even though HLR does not support CUG if correct CugInfo comes in SRI request call is allowed
            }
            if(p_SRIv3->bit_mask & IMAP3_numberOfForwarding_present)
            {
               LLOG(0,0,"numberOfForwarding present - value |%d|",p_SRIv3->numberOfForwarding);
               if(p_SRIv3->numberOfForwarding > g_CMConfigReaderObj->m_no_fwd) 
               {
                  ELOG(0,0,"Forwarding violation.. Number of Forwarding exceeds configured value");
                  m_ErrCode = MAP_ERROR_forwardingViolation;
                  return CM_ERROR;
               }
            }
            if(p_SRIv3->gmsc_OrGsmSCF_Address.length > 1)
            {
               DLOG(0,0,"gmsc_OrGsmSCF_Address present");
               if(p_SRIv3->bit_mask & IMAP3_gsmSCF_InitiatedCall_present)
               {
                  LLOG(0,0,"gsmSCF INITIATED CALL");
                  m_GsmSCFCall = true;
               }
               // assuming we get p_SRIv3->gmsc_OrGsmSCF_Address.value[0] = 0x91 and hence extracting only from index[1]
               memcpy(m_gmscNaiNpi,p_SRIv3->gmsc_OrGsmSCF_Address.value,1);
               m_GmscOrGsmScfLen = BCDToString((u8*)m_GmscOrGsmScfVal,&p_SRIv3->gmsc_OrGsmSCF_Address.value[1],p_SRIv3->gmsc_OrGsmSCF_Address.length-1);
               m_tdr.setString(TDR_INDEX_CM_SRI_GMSC_ADDRESS,(s8*)m_GmscOrGsmScfVal);
            }
            else
            {
               if(p_SRIv3->gmsc_OrGsmSCF_Address.length <= 0)
               {
                  CLOG(0,0,"Mandatory param Gmsc or gsmSCF Address missing or corrupt");
                  m_ErrCode = MAP_ERROR_dataMissing; 
                  return CM_ERROR;
               }
               else
               {
                  CLOG(0,0,"Unexpected Gmsc or gsmSCF Address");
                  m_ErrCode = MAP_ERROR_unexpectedData; 
                  return CM_ERROR;
               }
            }

            if(IMAP3_basicCall == p_SRIv3->interrogationType) // basic call
            {
               DLOG(0,0,"interrogationType is Basic call");
               if(!(p_SRIv3->bit_mask & IMAP3_SendRoutingInfoArg_callReferenceNumber_present))
               {
                  LLOG(0,0,"Call reference number not present for basic call");
                  if(1 == g_CMConfigReaderObj->m_callRefNumFlag)
                  {
                     CLOG(0,0,"CallRefNumFlag Set but call reference number not present sending dataMissing error");
                     m_ErrCode = MAP_ERROR_dataMissing;
                     return CM_ERROR;
                  }
               }
               else
               {
                  m_CallRefNumLen = p_SRIv3->callReferenceNumber.length;
                  memcpy(m_CallRefNum,p_SRIv3->callReferenceNumber.value,p_SRIv3->callReferenceNumber.length);
                  m_tdr.setHex(TDR_INDEX_CM_SRI_CALL_REF_NUM,(s8*)m_CallRefNum,m_CallRefNumLen);
               }
            }
            else if(IMAP3_forwarding == p_SRIv3->interrogationType) // forwarding call
            {
               LLOG(0,0,"Interrogation Type is forwarding - facility not supported");
               m_ErrCode = MAP_ERROR_facilityNotSup;
               return CM_ERROR;
            }
            else
            {
               if(IMAP3_unknown == p_SRIv3->interrogationType) // assuming Collect Call
               {
                  LLOG(0,0,"Interrogation Type is 2 assuming Collect call");
                  m_collect_call_enabled = true;
               }
               else
               {
                  CLOG(0,0,"Mandatory param InterrogationType missing or corrupt");
                  m_ErrCode = MAP_ERROR_dataMissing;
                  return CM_ERROR;
               }
            }

            if(p_SRIv3->bit_mask & IMAP3_camelInfo_present)
            {
               DLOG(0,0,"In camelInfo_present");
               m_suppGmscCamelPhase = p_SRIv3->camelInfo.supportedCamelPhases.value[0];

               LLOG(0,0,"Supported Camel Phases in Gmsc |%x|",m_suppGmscCamelPhase);

               if((m_suppGmscCamelPhase & 0x0f) != 0 )
               {
                  CLOG(0,0,"Unexpected Camel phase value");
                  m_ErrCode =  MAP_ERROR_unexpectedData;
                  return CM_ERROR;
               }
               if(p_SRIv3->camelInfo.bit_mask & IMAP3_suppress_T_CSI_present)
               {
                  DLOG(0,0,"Received Suppress Tcsi");
                  m_SuppressTCSI = true;
                  m_collect_call_enabled = false;
                  LLOG(0,0,"Interrogation Type is 2 but assuming NO Collect call since Suppress TCSI is enabled");
                  m_tdr.setInteger(TDR_INDEX_CM_SRI_SUPPRESS_TCSI,1);
               }
               if(p_SRIv3->camelInfo.bit_mask & IMAP3_CamelInfo_offeredCamel4CSIs_present)
               {
                  if(m_suppGmscCamelPhase & 0x10)
                  {
                     DLOG(0,0,"OfferedCamel4CSIs present");
                     m_OfferedCamelPhase = true;
                     m_OfferedCamelPhaseVal = p_SRIv3->camelInfo.offeredCamel4CSIs.value[0] & 0xff;
                     LLOG(0,0,"Offered camel phases - |%x|",m_OfferedCamelPhaseVal);
                  }
                  else
                  {
                     CLOG(0,0,"Unexpected Data: OfferedCamel4Csi present but suppCPHGmsc is not PH-4");
                     m_ErrCode =  MAP_ERROR_unexpectedData;
                     return CM_ERROR;
                  }
               }
            }
            else
            {
               LLOG(0,0,"CamelInfo not present in SRI-V3 making default suppCamelPhGmsc as Phase-1");
               m_suppGmscCamelPhase = 0x80; // Ph-1
               m_highestCphGmsc = 1; // Ph-1
            }

            if(p_SRIv3->bit_mask & IMAP3_SendRoutingInfoArg_networkSignalInfo_present)
            {
               m_networkSigInfo = true; 
               IMAP3_ProtocolId l_pId = p_SRIv3->networkSignalInfo.protocolId;

               if(!((l_pId == IMAP3_gsm_0408)||(l_pId == IMAP3_gsm_0806)||(l_pId == IMAP3_gsm_BSSMAP)||(l_pId == IMAP3_ets_300102_1)))
               {
                  ELOG(0,0,"Unexpected protcolId values in network signal info");
                  m_ErrCode =  MAP_ERROR_unexpectedData;
                  return CM_ERROR;
               }
               protocolId = (OMAP3_ProtocolId)p_SRIv3->networkSignalInfo.protocolId;
               memcpy(signalInfo.value,p_SRIv3->networkSignalInfo.signalInfo.value,p_SRIv3->networkSignalInfo.signalInfo.length);
               signalInfo.length = p_SRIv3->networkSignalInfo.signalInfo.length;

               char l_ITCspeech[5] = {0x04, 0x03, 0x80, 0x90, 0xA3}; // ITC = Speech
               char l_ITCAudio3point1kHz[5] = {0x04, 0x03, 0x90, 0x90, 0xA3}; // ITC = Audio 3.1kHz 
               char l_ITCAudio3point1kHzAndHLCFax[9] = {0x04, 0x03, 0x90, 0x90, 0xA3, 0x7D, 0x02, 0x91, 0x84}; // ITC = Audio 3.1kHz + HLC..fax
               bool l_FaxCall = false;

               if(8 < signalInfo.length)
               {
                  if(!memcmp(&signalInfo.value[5],&l_ITCAudio3point1kHzAndHLCFax[5],1)) // HLC Tag 7D
                  {
                     if(signalInfo.value[8] & 0x04) // 1/0 0 0 0 0 1 0 0 Facsimile Group 2/3 ETS-300102-1 pg79 
                     {
                        LLOG(0,0,"Audio3.1kHz and HLC Fax present in SignalInfo");
                        l_FaxCall = true;
                        m_nonTelephony = true;
                     }
                  }
               }
               if(false == l_FaxCall)
               {
                  if((memcmp(signalInfo.value, l_ITCspeech, 3)) && (memcmp(signalInfo.value, l_ITCAudio3point1kHz, 3)))
                  {
                     LLOG(0,0,"Non-Telephony Call");
                     m_nonTelephony = true;
                  }
               }
               LLOG_HEX(0,0,"NetworkSignalInfo", (s8*)signalInfo.value, signalInfo.length);
            }

            if(p_SRIv3->bit_mask & IMAP3_SendRoutingInfoArg_additionalSignalInfo_present)
            {
               m_additionalSigInfo = true;
               IMAP3_Ext_ProtocolId l_extPid = p_SRIv3->additionalSignalInfo.ext_ProtocolId;

               if(!(l_extPid == IMAP3_ets_300356))
               {
                  ELOG(0,0,"Unexpected protocolId values in additional signal info");
                  m_ErrCode =  MAP_ERROR_unexpectedData;
                  return CM_ERROR;
               }
               ext_ProtocolId = (OMAP3_Ext_ProtocolId)p_SRIv3->additionalSignalInfo.ext_ProtocolId;
               memcpy(signalInfo2.value,p_SRIv3->additionalSignalInfo.signalInfo.value,p_SRIv3->additionalSignalInfo.signalInfo.length);
               signalInfo2.length = p_SRIv3->additionalSignalInfo.signalInfo.length;
               LLOG_HEX(0,0,"AdditionalSignalInfo", (s8*)signalInfo2.value, signalInfo2.length);
            }	

            if(p_SRIv3->bit_mask & IMAP3_suppressIncomingCallBarring_present)
            {
               LLOG(0,0,"Suppress incoming callBarring set");
               m_SuppressICB = true;
            }

            if(p_SRIv3->bit_mask & IMAP3_SendRoutingInfoArg_alertingPattern_present)
            {
               m_AlertPatternValue = p_SRIv3->alertingPattern.value[0] & 0xff;
               m_AlertPatternLen = p_SRIv3->alertingPattern.length; //  aletPatternLen is 1
               LLOG(0,0,"Alerting pattern set - Value|%d|",m_AlertPatternValue);
            }

            if(p_SRIv3->bit_mask & IMAP3_SendRoutingInfoArg_suppressionOfAnnouncement_present)
            {
               m_suppOfAnnouncement = p_SRIv3->suppressionOfAnnouncement;
               m_suppOfAnnouncementFlag = true;
               LLOG(0,0,"Suppression of announcement set - Value|%d|",m_suppOfAnnouncement);
            }

            if((!(p_SRIv3->bit_mask & OMAP3_callDiversionTreatmentIndicator_present)) || (0x01 == p_SRIv3->callDiversionTreatmentIndicator.value[0]))
            {
               m_callDiversion = true; // CallDiversion allowed
            }
            else
            {
               m_callDiversion = false; // CallDiversion not allowed i.e., CFU,CFNRc even though active will be treated as normal call
               LLOG(0,0,"Call Diversion Treatment Indicator[%d] present CFU CFNRc even though active will be treated as normal call",p_SRIv3->callDiversionTreatmentIndicator.value[0]);
            }
            if(p_SRIv3->bit_mask & OMAP3_SendRoutingInfoArg_mtRoamingRetrySupported_present)
            {
               m_RoamingRetrySupportFlag = true; // Roaming Retry Support
               LLOG(0,0,"RoamingRetrySupportFlag present");
            }
            if(p_SRIv3->bit_mask & OMAP3_SendRoutingInfoArg_longFTN_Supported_present) // 2.0.7.0
            {
               m_longFtnSupportFlag = true; // Long FTN Support
               LLOG(0,0,"Long FTN support indicator present");
            }
            if(p_SRIv3->bit_mask & IMAP3_SendRoutingInfoArg_extensionContainer_present) 
            {
               LLOG(0,0,"extension container present in SRI request");
               if(strlen((char*)m_ExtnCntrData) > 1)
               {
                  TLOG(0,0,"Decoded extensionContainer data [%s]",m_ExtnCntrData);
                  string l_ExtrData = "";
                  l_ExtrData.append((char*)m_ExtnCntrData);
                  string l_ExtType = CMConfigReader::readValue(l_ExtrData,"CALLING_PARTY_NUMBER");
                  if(l_ExtType.size() > 0)
                  {
                     DLOG(0,0,"Parsed Data [%s]",l_ExtType.c_str());
                     unsigned char l_ExtData[10];
                     memset(l_ExtData,'\0',sizeof(l_ExtData));
                     atohx((char *)l_ExtData,(char *)l_ExtType.c_str());
                     LLOG(0,0,"Calling Party Number from Extension Container [%s]",(char*)l_ExtType.c_str());
                     m_tdr.setString(TDR_INDEX_HLR_RESRV5,(char*)l_ExtType.c_str()+ 4);

                     m_extensionDataPresent = true;

                     //unsigned char l_addsiginfo[] = {0x0a,0x09,0x84,0x13};
                     m_asiginfo[0] = 0x0a;
                     m_asiginfo[1] = l_ExtType.size()/2;
                     memcpy(m_asiginfo+2,l_ExtData,l_ExtType.size()/2);
                  }
                  else
                  {
                     TLOG(0,0,"Calling Party Number is null");
                  }
               }
               else
               {
                  LLOG(0,0,"Extension Container Data present, but not decoded, Ignoring it");
               }
            }
            if(p_SRIv3->bit_mask & IMAP3_SendRoutingInfoArg_suppress_VT_CSI_present)
            {
               DLOG(0,0,"MAP3: Suppress VT CSI was found so initiating PSI directly");
               m_DirectPSI = true;
            }
         }
         break;
      case MAP_V2:
         {
            DLOG(0,0,"In checkSRI-V2");
            IMAP2_SendRoutingInfoArg *p_SRIv2 = (IMAP2_SendRoutingInfoArg*)aSRI; 
            if(p_SRIv2->msisdn.length <= 0)
            {
               CLOG(0,0,"V2:Mandatory Param Msisdn missing or corrupt");
               m_ErrCode = MAP_ERROR_dataMissing;
               return CM_ERROR;
            }
            else
            {
               // assuming we get p_SRIv3->msisdn.value[0]=0x91 so extracting msisdn from index[1]
               s8 tempMsisdn[CM_MSISDNLEN]; 
               memset(tempMsisdn,'\0',sizeof(tempMsisdn));
               s8 destNum[30];
               memset(destNum,'\0',sizeof(destNum));

               BCDToString((u8*)tempMsisdn,&p_SRIv2->msisdn.value[1],p_SRIv2->msisdn.length-1);
               TLOG(0,0,"Msisdn present - value |%s|",tempMsisdn);

               if(p_SRIv2->msisdn.value[0] != 0x91)
               {
                  LLOG(0,0,"Dialing pattern not international - Nai-Npi:[%x]",p_SRIv2->msisdn.value[0]);

                  getCC();

                  if(m_CC == NULL)
                  {
                     CLOG(0,0,"CC not found Sending System failure");
                     m_ErrCode = MAP_ERROR_systemFailure;
                     return CM_ERROR;
                  }

                  // SRI CC handling Begin //
                  // msisdn with "00"    
                  if(0 == memcmp(tempMsisdn, "00", 2)) // "00" means it has CC 
                  {
                     strcpy((s8*)m_Msisdn, &tempMsisdn[2]);
                     LLOG(0,0,"Msisdn starts with 00 and implies CC present Removing 00 Msisdn|%s|",m_Msisdn);
                  }
                  // msisdn with "0"
                  else if(0 == memcmp(tempMsisdn, "0", 1)) // only "0" means it does not have CC so appending CC
                  {
                     sprintf(destNum,"%s%s", m_CC, &tempMsisdn[1]);
                     strcpy((s8*)m_Msisdn, destNum);
                     LLOG(0,0,"Msisdn starts with 0 implies CC not present Removing 0 and Appending CC |%s|",m_Msisdn);
                  }
                  // msisdn without "0" and "00"; CC not presetn Appending CC 
                  else if(0 != memcmp(tempMsisdn,m_CC,strlen(m_CC)))
                  {
                     sprintf(destNum, "%s%s", m_CC,tempMsisdn);
                     strcpy((s8*)m_Msisdn, destNum);
                     DLOG(0,0,"Msisdn starts without 0 and 00 : CC not present Appending CC Msisdn|%s|",m_Msisdn);
                  }
                  // absolute msisdn starting digits match with cc eg: 9191....
                  /*else if((0 == memcmp(tempMsisdn, m_CC, strlen(m_CC))) && (tempMsisdnLen==(strlen(tempMsisdn))))
                    {
                    sprintf(destNum, "%s%s", m_CC, tempMsisdn);
                    strcpy((s8*)m_Msisdn, destNum); 
                    DLOG(0,0,"Msisdn starting digits match with CC Appending CC Msisdn|%s|",m_Msisdn);
                    }*/ 
                  else
                  {
                     // Normal Case 
                     strcpy((s8*)m_Msisdn,tempMsisdn); 
                     DLOG(0,0,"Normal Msisdn staring with CC - value |%s|",m_Msisdn);
                     m_MsisdnLen = strlen((s8*)m_Msisdn);
                     setTraceMsisdn((s8*)m_Msisdn);
                  }
               }
               else
               {
                  // Normal Case Internatoinal Format
                  TLOG(0,0,"Dialing pattern International - Nai-Npi:[%x]",p_SRIv2->msisdn.value[0]);
                  s8* l_msisdn = NULL;
                  l_msisdn = g_spdPtr->getMsisdnValue(tempMsisdn);
                  strcpy((s8*)m_Msisdn,l_msisdn);
                  DLOG(0,0,"Normal Msisdn staring with CC - value |%s|",m_Msisdn);
                  m_MsisdnLen = strlen((s8*)m_Msisdn);
                  setTraceMsisdn((s8*)m_Msisdn);
               }
               m_tdr.setChar(TDR_INDEX_REQUEST_TYPE,'M'); // 1-msisdn 2-imsi 3-both
               m_tdr.setString(TDR_INDEX_REQUEST_MSISDN,(s8*)m_Msisdn);
            } 

            if(p_SRIv2->bit_mask & IMAP2_SendRoutingInfoArg_cug_CheckInfo_present)
            {
               if(!(p_SRIv2->cug_CheckInfo.bit_mask & IMAP2_cug_OutgoingAccess_present))
               {
                  CLOG(0,0,"V2:CUG reject as OutgoingAccess is not present in CugCheckInfo");
                  m_ErrCode = MAP_ERROR_CUG_Reject;
                  return CM_ERROR;
               }
               // Note: Even though HLR does not support CUG if correct CugInfo comes in SRI request call is allowed
            }
            if(p_SRIv2->bit_mask & IMAP2_numberOfForwarding_present)
            {
               LLOG(0,0,"V2:numberOfForwarding present - value |%d|",p_SRIv2->numberOfForwarding);
               if(p_SRIv2->numberOfForwarding > g_CMConfigReaderObj->m_no_fwd) 
               {
                  ELOG(0,0,"V2:Forwarding violation.. Number of Forwarding exceeds configured value");
                  m_ErrCode = MAP_ERROR_forwardingViolation;
                  return CM_ERROR;
               }
            }

            if(p_SRIv2->bit_mask & IMAP2_SendRoutingInfoArg_networkSignalInfo_present)
            {
               DLOG(0,0,"V2:networkSignalInfo_present");
               m_networkSigInfo = true; 
               IMAP2_ProtocolId l_pId = p_SRIv2->networkSignalInfo.protocolId;

               if(!((l_pId == IMAP2_gsm_0408)||(l_pId == IMAP2_gsm_0806)||(l_pId == IMAP2_gsm_BSSMAP)||(l_pId == IMAP2_ets_300102_1)))
               {
                  ELOG(0,0,"V2:Unexpected protcolId values in network signal info");
                  m_ErrCode =  MAP_ERROR_unexpectedData;
                  return CM_ERROR;
               }
               protocolId = (OMAP3_ProtocolId)p_SRIv2->networkSignalInfo.protocolId;
               memcpy(signalInfo.value,p_SRIv2->networkSignalInfo.signalInfo.value,p_SRIv2->networkSignalInfo.signalInfo.length);
               signalInfo.length = p_SRIv2->networkSignalInfo.signalInfo.length;

               char l_ITCspeech[5] = {0x04, 0x03, 0x80, 0x90, 0xA3}; // ITC = Speech
               char l_ITCAudio3point1kHz[5] = {0x04, 0x03, 0x90, 0x90, 0xA3}; // ITC = Audio 3.1kHz 
               char l_ITCAudio3point1kHzAndHLCFax[9] = {0x04, 0x03, 0x90, 0x90, 0xA3, 0x7D, 0x02, 0x91, 0x84}; // ITC = Audio 3.1kHz + HLC..fax
               bool l_FaxCall = false;

               if(8 < signalInfo.length)
               {
                  if(!memcmp(&signalInfo.value[5],&l_ITCAudio3point1kHzAndHLCFax[5],1)) // HLC Tag 7D
                  {
                     if(signalInfo.value[8] & 0x04) // 1/0 0 0 0 0 1 0 0 Facsimile Group 2/3 ETS-300102-1 pg79 
                     {
                        LLOG(0,0,"Audio3.1kHz and HLC Fax present in SignalInfo");
                        l_FaxCall = true;
                        m_nonTelephony = true;
                     }
                  }
               }
               if(false == l_FaxCall)
               {
                  if((memcmp(signalInfo.value, l_ITCspeech, 3)) && (memcmp(signalInfo.value, l_ITCAudio3point1kHz, 3)))
                  {
                     LLOG(0,0,"Non-Telephony Call");
                     m_nonTelephony = true;
                  }
               }
               LLOG_HEX(0,0,"V2:NetworkSignalInfo", (s8*)signalInfo.value, signalInfo.length);
            }
         }
         break;
      case MAP_V1:
         {
            DLOG(0,0,"In checkSRI-V1");
            IMAP1_SendRoutingInformationArg *p_SRIv1 = (IMAP1_SendRoutingInformationArg*)aSRI; 
            if(p_SRIv1->msIsdn.length <= 0)
            {
               CLOG(0,0,"V1:Mandatory Param Msisdn missing or corrupt");
               m_ErrCode = MAP_ERROR_dataMissing;
               return CM_ERROR;
            }
            else
            {
               // assuming we get p_SRIv3->msisdn.value[0]=0x91 so extracting msisdn from index[1]
               s8 tempMsisdn[CM_MSISDNLEN]; 
               memset(tempMsisdn,'\0',sizeof(tempMsisdn));
               s8 destNum[30];
               memset(destNum,'\0',sizeof(destNum));

               BCDToString((u8*)tempMsisdn,&p_SRIv1->msIsdn.value[1],p_SRIv1->msIsdn.length-1);
               TLOG(0,0,"Msisdn present - value |%s|",tempMsisdn);

               if(p_SRIv1->msIsdn.value[0] != 0x91)
               {
                  LLOG(0,0,"Dialing pattern not international - Nai-Npi :[%x]",p_SRIv1->msIsdn.value[0]);

                  getCC();

                  if(m_CC == NULL)
                  {
                     CLOG(0,0,"CC not found Sending System failure");
                     m_ErrCode = MAP_ERROR_systemFailure;
                     return CM_ERROR;
                  }

                  // SRI CC handling Begin //
                  // msisdn with "00"    
                  if(0 == memcmp(tempMsisdn, "00", 2)) // "00" means it has CC 
                  {
                     strcpy((s8*)m_Msisdn, &tempMsisdn[2]);
                     DLOG(0,0,"Msisdn starts with 00 and implies CC present Removing 00 Msisdn|%s|",m_Msisdn);
                  }
                  // msisdn with "0"
                  else if(0 == memcmp(tempMsisdn, "0", 1)) // only "0" means it does not have CC so appending CC
                  {
                     sprintf(destNum,"%s%s", m_CC, &tempMsisdn[1]);
                     strcpy((s8*)m_Msisdn, destNum);
                     DLOG(0,0,"Msisdn starts with 0 implies CC not present Removing 0 and Appending CC |%s|",m_Msisdn);
                  }
                  // msisdn without "0" and "00"; CC not presetn Appending CC 
                  else if(0 != memcmp(tempMsisdn,m_CC,strlen(m_CC)))
                  {
                     sprintf(destNum, "%s%s", m_CC,tempMsisdn);
                     strcpy((s8*)m_Msisdn, destNum);
                     DLOG(0,0,"Msisdn starts without 0 and 00 : CC not present Appending CC Msisdn|%s|",m_Msisdn);
                  }
                  // absolute msisdn starting digits match with cc eg: 9191....
                  /*else if((0 == memcmp(tempMsisdn, m_CC, strlen(m_CC))) && (tempMsisdnLen==(strlen(tempMsisdn))))
                    {
                    sprintf(destNum, "%s%s", m_CC, tempMsisdn);
                    strcpy((s8*)m_Msisdn, destNum); 
                    DLOG(0,0,"Msisdn starting digits match with CC Appending CC Msisdn|%s|",m_Msisdn);
                    }*/ 
                  else
                  {
                     // Normal Case 
                     strcpy((s8*)m_Msisdn,tempMsisdn); 
                     DLOG(0,0,"Normal Msisdn staring with CC - value |%s|",m_Msisdn);
                     m_MsisdnLen = strlen((s8*)m_Msisdn);
                     setTraceMsisdn((s8*)m_Msisdn);
                  }
               }
               else
               {
                  // Normal Case international format
                  TLOG(0,0,"Dialing pattern International - Nai-Npi:[%x]",p_SRIv1->msIsdn.value[0]);
                  s8* l_msisdn = NULL;
                  l_msisdn = g_spdPtr->getMsisdnValue(tempMsisdn);
                  strcpy((s8*)m_Msisdn,l_msisdn);
                  DLOG(0,0,"Normal Msisdn staring with CC - value |%s|",m_Msisdn);
                  m_MsisdnLen = strlen((s8*)m_Msisdn);
                  setTraceMsisdn((s8*)m_Msisdn);
               }

               m_tdr.setChar(TDR_INDEX_REQUEST_TYPE,'M'); // 1-msisdn 2-imsi 3-both
               m_tdr.setString(TDR_INDEX_REQUEST_MSISDN,(s8*)m_Msisdn);

            }

            if(p_SRIv1->bit_mask & IMAP1_SendRoutingInformationArg_numberOfForwarding_present)
            {
               LLOG(0,0,"V1:numberOfForwarding present - value |%d|",p_SRIv1->numberOfForwarding);
               if(p_SRIv1->numberOfForwarding > g_CMConfigReaderObj->m_no_fwd) 
               {
                  ELOG(0,0,"V1:Forwarding violation.. Number of Forwarding exceeds configured value");
                  m_ErrCode = MAP_ERROR_forwardingViolation;
                  return CM_ERROR;
               }
            }

            if(p_SRIv1->bit_mask & IMAP1_SendRoutingInformationArg_networkSignalInfo_present)
            {
               DLOG(0,0,"V1:networkSignalInfo_present");
               m_networkSigInfo = true; 
               IMAP1_ProtocolId l_pId = p_SRIv1->networkSignalInfo.protocolId;

               if(!((l_pId == IMAP1_gsm_0408)||(l_pId == IMAP1_gsm_0806)||(l_pId == IMAP1_gsm_0808_bssmap)||(l_pId == IMAP1_ets300102_1)))
               {
                  ELOG(0,0,"V1:Unexpected protcolId values in network signal info");
                  m_ErrCode =  MAP_ERROR_unexpectedData;
                  return CM_ERROR;
               }
               protocolId = (OMAP3_ProtocolId)p_SRIv1->networkSignalInfo.protocolId;
               memcpy(signalInfo.value,p_SRIv1->networkSignalInfo.signalInfo.value,p_SRIv1->networkSignalInfo.signalInfo.length);
               signalInfo.length = p_SRIv1->networkSignalInfo.signalInfo.length;

               char l_ITCspeech[5] = {0x04, 0x03, 0x80, 0x90, 0xA3}; // ITC = Speech
               char l_ITCAudio3point1kHz[5] = {0x04, 0x03, 0x90, 0x90, 0xA3}; // ITC = Audio 3.1kHz 
               char l_ITCAudio3point1kHzAndHLCFax[9] = {0x04, 0x03, 0x90, 0x90, 0xA3, 0x7D, 0x02, 0x91, 0x84}; // ITC = Audio 3.1kHz + HLC..fax
               bool l_FaxCall = false;

               if(8 < signalInfo.length)
               {
                  if(!memcmp(&signalInfo.value[5],&l_ITCAudio3point1kHzAndHLCFax[5],1)) // HLC Tag 7D
                  {
                     if(signalInfo.value[8] & 0x04) // 1/0 0 0 0 0 1 0 0 Facsimile Group 2/3 ETS-300102-1 pg79 
                     {
                        LLOG(0,0,"Audio3.1kHz and HLC Fax present in SignalInfo");
                        l_FaxCall = true;
                        m_nonTelephony = true;
                     }
                  }
               }
               if(false == l_FaxCall)
               {
                  if((memcmp(signalInfo.value, l_ITCspeech, 3)) && (memcmp(signalInfo.value, l_ITCAudio3point1kHz, 3)))
                  {
                     LLOG(0,0,"Non-Telephony Call");
                     m_nonTelephony = true;
                  }
               }
               LLOG_HEX(0,0,"V1:NetworkSignalInfo", (s8*)signalInfo.value, signalInfo.length);
            }
         }
         break;
      default:
         {
            CLOG(0,0,"Unknown MapVersion Received");
         }
         break;
   }
   return CM_CONTINUE;
}

bool CtxtSendRoutingInfo:: handleDbQuery()
{
   CMSRIDBdata *l_SubsData = NULL;
   switch(m_MapVer)
   {
      case MAP_V3:
         {
            DLOG(0,0,"In handleDbQuery-V3");
            if(true == m_SuppressTCSI)
            { 
               TLOG(0,0,"Suppress-Tcsi Recvd Calling PRN-DB Request");
               l_SubsData = new CMPRNPSIDBdata();
               if(l_SubsData != NULL)
               {
                  l_SubsData->setMsgType(MAP_OP_CODE_provideRoamingNumber); 
                  // PASSING INPUT PARAMS MSISDN BSTYPE BSGROUP
                  strcpy((s8*)l_SubsData->m_Msisdn,(s8*)m_Msisdn);
                  l_SubsData->m_ServiceType = (u16)m_ServiceType;
                  l_SubsData->m_BSCODE = m_Utility.getBSGroup(m_ServiceCode,m_ServiceType); 
                  strcpy((s8*)l_SubsData->m_GmscAddress,(s8*)m_GmscOrGsmScfVal);
                  memcpy(l_SubsData->m_SignalInfo,signalInfo.value,signalInfo.length);
                  l_SubsData->m_SignalInfoLen = signalInfo.length;
                  LLOG(0,0,"DBIN-PRN-SUPPRESSTCSI: BScode-|%d| BStype-|%d| Msisdn-|%s| OdbIndicator-|1| GmscAddr|%s| SignalInfo",l_SubsData->m_BSCODE,m_ServiceType,m_Msisdn,m_GmscOrGsmScfVal);
               }
               else
               {
                  CLOG(0,0,"Newing Prn Subs Data Failed");
               }
            }
            else
            {
               TLOG(0,0,"Calling PSI-DB Request as Suppress-Tcsi not set");
               l_SubsData = new CMPRNPSIDBdata();
               if(l_SubsData != NULL)
               {
                  l_SubsData->setMsgType(MAP_OP_CODE_provideSubscriberInfo); 
                  // PASSING INPUT PARAMS MSISDN BSTYPE BSGROUP
                  strcpy((s8*)l_SubsData->m_Msisdn,(s8*)m_Msisdn);
                  l_SubsData->m_ServiceType = (u16)m_ServiceType;
                  l_SubsData->m_BSCODE = m_Utility.getBSGroup(m_ServiceCode,m_ServiceType); 
                  strcpy((s8*)l_SubsData->m_GmscAddress,(s8*)m_GmscOrGsmScfVal);
                  memcpy(l_SubsData->m_SignalInfo,signalInfo.value,signalInfo.length);
                  l_SubsData->m_SignalInfoLen = signalInfo.length;
                  LLOG(0,0,"DBIN-PSI: BScode-|%d| BStype-|%d| Msisdn-|%s| GmscAddr|%s| SignalInfo",l_SubsData->m_BSCODE,m_ServiceType,m_Msisdn,m_GmscOrGsmScfVal);
               }
               else
               {
                  CLOG(0,0,"Newing Psi Subs Data Failed");
               }
            }
         }
         break;
      case MAP_V2:
         {
            DLOG(0,0,"In handleDbQuery-V2");
            l_SubsData = new CMPRNPSIDBdata();
            if(l_SubsData != NULL)
            {
               l_SubsData->setMsgType(MAP_OP_CODE_provideRoamingNumber); 
               // PASSING INPUT PARAMS MSISDN BSTYPE BSGROUP
               strcpy((s8*)l_SubsData->m_Msisdn,(s8*)m_Msisdn);
               l_SubsData->m_ServiceType = (u16)m_ServiceType;
               l_SubsData->m_BSCODE = m_Utility.getBSGroup(m_ServiceCode,m_ServiceType); 
               strcpy((s8*)l_SubsData->m_GmscAddress,(s8*)m_destAddr);//sending SCCP-CallingGT as GmscAddr is not there in V2-SRI
               LLOG(0,0,"V2:DBIN-PRN: BScode-|%d| BStype-|%d| Msisdn-|%s| OdbIndicator-|1| GmscAddr-SccpClngGt|%s|",l_SubsData->m_BSCODE,m_ServiceType,m_Msisdn,m_destAddr);
            }
            else
            {
               CLOG(0,0,"V2:Newing Prn Subs Data Failed");
            }
         }
         break;
      case MAP_V1:
         {
            DLOG(0,0,"In handleDbQuery-V1");
            l_SubsData = new CMPRNPSIDBdata();
            if(l_SubsData != NULL)
            {
               l_SubsData->setMsgType(MAP_OP_CODE_provideRoamingNumber); 
               // PASSING INPUT PARAMS MSISDN BSTYPE BSGROUP
               strcpy((s8*)l_SubsData->m_Msisdn,(s8*)m_Msisdn);
               l_SubsData->m_ServiceType = (u16)m_ServiceType;
               l_SubsData->m_BSCODE = m_Utility.getBSGroup(m_ServiceCode,m_ServiceType); 
               strcpy((s8*)l_SubsData->m_GmscAddress,(s8*)m_destAddr);//sending SCCP-CallingGT as GmscAddr is not there in V2-SRI
               LLOG(0,0,"V1:DBIN-PRN: BScode-|%d| BStype-|%d| Msisdn-|%s| OdbIndicator-|1| GmscAddr-SccpClngGt|%s|",l_SubsData->m_BSCODE,m_ServiceType,m_Msisdn,m_destAddr);
            }
            else
            {
               CLOG(0,0,"V1:Newing Prn Subs Data Failed");
            }
         }
         break;
      default:
         {
            CLOG(0,0,"Unknown MapVersion Received");
         }
         break;
   }
   TLOG(0,0,"Pushing data to DB");
   l_SubsData->m_cb = this;
   l_SubsData->m_DbQueryType = 1;
   g_act.execute(l_SubsData);
   return true; 
}

//////////////////////////////////////////////////////////////////////////////////////////////////

void CtxtSendRoutingInfo :: fillPSINackSRIRes(OMAP3_SendRoutingInfoRes *aSRIRes)
{
    if( (1 == mp_sriSubData->m_ocsiSuppressFlag) && (1 == mp_sriSubData->m_IMSTcsiIndicator) && (0 != mp_sriSubData->m_TcsiProfileId) )// 6430
    {
	LLOG(0,0, "Suppress OCSI flag and ims tcsi enabled and ims tcsi profileId not Configured .. not filling PSI/Location info");
	return;
    }
   if((strlen((s8*)mp_sriSubData->m_VlrNum) <= 1) || (CM_DB_FORWARD_NOTREACHABLE == m_ForwardType)) // 2nd OR condition not required
   {
      DLOG(0,0,"In fillPSINackNRC");
      aSRIRes->bit_mask |= OMAP3_subscriberInfo_present;
      aSRIRes->subscriberInfo.bit_mask |= OMAP3_SubscriberInfo_subscriberState_present;
      aSRIRes->subscriberInfo.subscriberState.choice = OMAP3_SubscriberState_netDetNotReachable_chosen; 
      aSRIRes->subscriberInfo.subscriberState.u.netDetNotReachable = OMAP3_notRegistered;
      LLOG(0,0,"Psi Negative Response setting NetworkDetNotReachable as VLRNUM=0");
   }
   else
   {
      DLOG(0,0,"In fillPSINackSRIRes");
      bool locInfo = false;
      aSRIRes->bit_mask |= OMAP3_subscriberInfo_present;

      if(1 == mp_sriSubData->m_IMSTcsiIndicator) // 6430
      {
	      LLOG(0,0,"IMS Tcsi indicator set sending subscriber state psi status");
	      //aSRIRes->subscriberInfo.subscriberState.choice = OMAP3_assumedIdle_chosen;
	      //aSRIRes->subscriberInfo.subscriberState.u.assumedIdle = true;
      }
      else
      {
	      aSRIRes->subscriberInfo.bit_mask |= OMAP3_SubscriberInfo_subscriberState_present;
	      aSRIRes->subscriberInfo.subscriberState.choice = OMAP3_notProvidedFromVLR_chosen;
	      aSRIRes->subscriberInfo.subscriberState.u.notProvidedFromVLR = true;
      }

      if(strlen((s8*)mp_sriSubData->m_MscNum) > 1)
      {
	      aSRIRes->subscriberInfo.locationInformation.bit_mask |= OMAP3_LocationInformation_msc_Number_present;
	      aSRIRes->subscriberInfo.locationInformation.msc_Number.value[0] = 0x91; // noa =1, npi =1
	      aSRIRes->subscriberInfo.locationInformation.msc_Number.length = StringToBCD(&aSRIRes->subscriberInfo.locationInformation.msc_Number.value[1],(u8*)mp_sriSubData->m_MscNum,strlen((s8*)mp_sriSubData->m_MscNum));
	      aSRIRes->subscriberInfo.locationInformation.msc_Number.length++;
	      LLOG(0,0,"Psi Negative Response : MscNumber|%s|",mp_sriSubData->m_MscNum);
	      locInfo = true;
      }

      if(strlen((s8*)mp_sriSubData->m_VlrNum) > 1)
      {
	      aSRIRes->subscriberInfo.locationInformation.bit_mask |= OMAP3_vlr_number_present;
	      aSRIRes->subscriberInfo.locationInformation.vlr_number.value[0] = 0x91; // noa =1, npi =1
	      aSRIRes->subscriberInfo.locationInformation.vlr_number.length = StringToBCD(&aSRIRes->subscriberInfo.locationInformation.vlr_number.value[1],(u8*)mp_sriSubData->m_VlrNum,strlen((s8*)mp_sriSubData->m_VlrNum));
	      aSRIRes->subscriberInfo.locationInformation.vlr_number.length++;
	      LLOG(0,0,"Psi Negative Response : VlrNumber|%s|",mp_sriSubData->m_VlrNum);
	      locInfo = true;
      }

      if(locInfo)
	      aSRIRes->subscriberInfo.bit_mask |= OMAP3_SubscriberInfo_locationInformation_present;
   }
}

void CtxtSendRoutingInfo :: fillPSIinSRIRes(OMAP3_SendRoutingInfoRes *aSRIRes,IMAP3_ProvideSubscriberInfoRes *aPSIRes)
{
    if( (1 == mp_sriSubData->m_ocsiSuppressFlag) && (1 == mp_sriSubData->m_IMSTcsiIndicator) && (0 != mp_sriSubData->m_TcsiProfileId))// 6430
    {
	LLOG(0,0, "Suppress OCSI flag and ims tcsi enabled and ims tcsi profileId not configured.. not filling PSI/Location info");
	return;
    }
   DLOG(0,0,"In fillPSIinSRIRes");
   bool l_subsInfoPresent = false;
   if(aPSIRes->subscriberInfo.bit_mask & IMAP3_SubscriberInfo_subscriberState_present)
   {
      l_subsInfoPresent = true;
      aSRIRes->subscriberInfo.bit_mask |= OMAP3_SubscriberInfo_subscriberState_present;
      DLOG(0,0,"SubsState set in PsiRes"); 
      u16 sState = aPSIRes->subscriberInfo.subscriberState.choice;
      aSRIRes->subscriberInfo.subscriberState.choice=sState;     
      TLOG(0,0,"Subscriber state in PsiRes |%d|",sState); 
      switch(sState)
      {

         case CM_ASSUMEDIDLE: //MAP3_assumedIdle_chosen
            {
               LLOG(0,0,"Subscriber state AssumedIdle from PsiRes"); 
               aSRIRes->subscriberInfo.subscriberState.u.assumedIdle=aPSIRes->subscriberInfo.subscriberState.u.assumedIdle;
               // if mnrf true make it false
               updateDb(0);
            }
            break;
         case CM_CAMELBUSY: //MAP3_camelBusy_chosen
            {
               LLOG(0,0,"Subscriber state CamelBusy from PsiRes"); 
               aSRIRes->subscriberInfo.subscriberState.u.camelBusy=aPSIRes->subscriberInfo.subscriberState.u.camelBusy;
            }
            break;
         case CM_NETDETNOTREACHABLE: //MAP3_SubscriberState_netDetNotReachable_chosen
            {
               LLOG(0,0,"Subscriber state NetworkDeterminedNotReachable from PsiRes"); 
               aSRIRes->subscriberInfo.subscriberState.u.netDetNotReachable=(OMAP3_NotReachableReason)aPSIRes->subscriberInfo.subscriberState.u.netDetNotReachable;
               // if mnrf false make it true
               updateDb(1);
            }
            break;
         case CM_NOTPROVIDEDFROMVLR: //MAP3_notProvidedFromVLR_chosen
            {
               LLOG(0,0,"Subscriber state not provided from Vlr from PsiRes"); 
               aSRIRes->subscriberInfo.subscriberState.u.notProvidedFromVLR=aPSIRes->subscriberInfo.subscriberState.u.notProvidedFromVLR;
            }
            break;
         default:
            {
               DLOG(0,0,"Default case of subscriber state");
            }
            break;
      }
   }

   IMAP3_LocationInformation *l_IlocInfo = &aPSIRes->subscriberInfo.locationInformation;
   OMAP3_LocationInformation *l_OlocInfo = &aSRIRes->subscriberInfo.locationInformation;

   if(aPSIRes->subscriberInfo.bit_mask & IMAP3_SubscriberInfo_locationInformation_present)
   {
      l_subsInfoPresent = true;
      aSRIRes->bit_mask |= OMAP3_subscriberInfo_present;
      aSRIRes->subscriberInfo.bit_mask |= OMAP3_SubscriberInfo_locationInformation_present;
      DLOG(0,0,"LocInfo set in PsiRes"); 
      if(l_IlocInfo->bit_mask &  IMAP3_LocationInformation_ageOfLocationInformation_present) 
      {
         l_OlocInfo->bit_mask |= OMAP3_LocationInformation_ageOfLocationInformation_present;

         l_OlocInfo->ageOfLocationInformation = l_IlocInfo->ageOfLocationInformation;
         DLOG(0,0,"LocInfo: AgeOfLocInformation from PsiRes"); 
      }
      if(l_IlocInfo->bit_mask & IMAP3_LocationInformation_geographicalInformation_present)
      {
         l_OlocInfo->bit_mask |= OMAP3_LocationInformation_geographicalInformation_present;
         l_OlocInfo->geographicalInformation.length = l_IlocInfo->geographicalInformation.length;
         memcpy(l_OlocInfo->geographicalInformation.value,l_IlocInfo->geographicalInformation.value,l_IlocInfo->geographicalInformation.length);
         DLOG(0,0,"LocInfo: GeographicalInformation from PsiRes"); 
      }

      if(l_IlocInfo->bit_mask & IMAP3_vlr_number_present)
      {
         l_OlocInfo->bit_mask |= OMAP3_vlr_number_present;
         l_OlocInfo->vlr_number.length = l_IlocInfo->vlr_number.length;
         memcpy(l_OlocInfo->vlr_number.value,l_IlocInfo->vlr_number.value,l_IlocInfo->vlr_number.length);
         DLOG(0,0,"LocInfo: VlrNumber from PsiRes"); 

      }
      if(l_IlocInfo->bit_mask & IMAP3_LocationInformation_msc_Number_present)
      {
         l_OlocInfo->bit_mask |= OMAP3_LocationInformation_msc_Number_present;
         l_OlocInfo->msc_Number.length = l_IlocInfo->msc_Number.length;
         memcpy(l_OlocInfo->msc_Number.value,l_IlocInfo->msc_Number.value,l_IlocInfo->msc_Number.length);
         DLOG(0,0,"LocInfo: MscNumber from PsiRes"); 
      }
      if(l_IlocInfo->bit_mask & IMAP3_locationNumber_present)
      {
         l_OlocInfo->bit_mask |= OMAP3_locationNumber_present;
         l_OlocInfo->locationNumber.length = l_IlocInfo->locationNumber.length;
         memcpy(l_OlocInfo->locationNumber.value,l_IlocInfo->locationNumber.value,l_IlocInfo->locationNumber.length);
         DLOG(0,0,"LocInfo: LocationNumber from PsiRes"); 
      }
      if(l_IlocInfo->bit_mask & IMAP3_LocationInformation_geodeticInformation_present)
      {
         l_OlocInfo->bit_mask |= OMAP3_LocationInformation_geodeticInformation_present;
         l_OlocInfo->geodeticInformation.length = l_IlocInfo->geodeticInformation.length;
         memcpy(l_OlocInfo->geodeticInformation.value,l_IlocInfo->geodeticInformation.value,l_IlocInfo->geodeticInformation.length);
         DLOG(0,0,"LocInfo: GeodeticInformation from PsiRes"); 
      }
      if(l_IlocInfo->bit_mask & IMAP3_LocationInformation_cellGlobalIdOrServiceAreaIdOrLAI_present)
      {
         l_OlocInfo->bit_mask |= OMAP3_LocationInformation_cellGlobalIdOrServiceAreaIdOrLAI_present;
         u16 globOrsrvcOrLaiID = l_IlocInfo->cellGlobalIdOrServiceAreaIdOrLAI.choice;  
         switch(globOrsrvcOrLaiID)
         {
            case CM_GLOABALORSERVICEIDFIXEDLENGTH:
               {

                  DLOG(0,0,"LocInfo: GlobalOrServiceID from PsiRes"); 
                  l_OlocInfo->cellGlobalIdOrServiceAreaIdOrLAI.choice = OMAP3_cellGlobalIdOrServiceAreaIdFixedLength_chosen;
                  l_OlocInfo->cellGlobalIdOrServiceAreaIdOrLAI.u.cellGlobalIdOrServiceAreaIdFixedLength.length = l_IlocInfo->cellGlobalIdOrServiceAreaIdOrLAI.u.cellGlobalIdOrServiceAreaIdFixedLength.length;
                  memcpy(l_OlocInfo->cellGlobalIdOrServiceAreaIdOrLAI.u.cellGlobalIdOrServiceAreaIdFixedLength.value,l_IlocInfo->cellGlobalIdOrServiceAreaIdOrLAI.u.cellGlobalIdOrServiceAreaIdFixedLength.value,l_IlocInfo->cellGlobalIdOrServiceAreaIdOrLAI.u.cellGlobalIdOrServiceAreaIdFixedLength.length);
               }
               break;
            case CM_LAIFIXEDLENGTH:
               {
                  DLOG(0,0,"LocInfo: LAI from PsiRes"); 
                  l_OlocInfo->cellGlobalIdOrServiceAreaIdOrLAI.choice = OMAP3_laiFixedLength_chosen;
                  l_OlocInfo->cellGlobalIdOrServiceAreaIdOrLAI.u.laiFixedLength.length = l_IlocInfo->cellGlobalIdOrServiceAreaIdOrLAI.u.laiFixedLength.length;
                  memcpy(l_OlocInfo->cellGlobalIdOrServiceAreaIdOrLAI.u.laiFixedLength.value,l_IlocInfo->cellGlobalIdOrServiceAreaIdOrLAI.u.laiFixedLength.value,l_IlocInfo->cellGlobalIdOrServiceAreaIdOrLAI.u.laiFixedLength.length);
               }
               break;
            default:
               {
                  DLOG(0,0,"Default case of globalOrSrvcOrLaiId");
               }
               break;
         }
      }
      if(l_IlocInfo->bit_mask & IMAP3_selectedLSA_Id_present)
      {
         l_OlocInfo->bit_mask |= OMAP3_selectedLSA_Id_present;
         l_OlocInfo->selectedLSA_Id.length = l_IlocInfo->selectedLSA_Id.length;
         memcpy(l_OlocInfo->selectedLSA_Id.value,l_IlocInfo->selectedLSA_Id.value,l_IlocInfo->selectedLSA_Id.length);
         DLOG(0,0,"LocInfo: SelectedLsaid from PsiRes"); 
      }
      if(l_IlocInfo->bit_mask & IMAP3_LocationInformation_currentLocationRetrieved_present)
      {
         l_OlocInfo->bit_mask |= OMAP3_LocationInformation_currentLocationRetrieved_present;
         l_OlocInfo->currentLocationRetrieved = l_IlocInfo->currentLocationRetrieved;
         DLOG(0,0,"LocInfo: CurrentLocRetreived from PsiRes"); 
      }
      if(l_IlocInfo->bit_mask & IMAP3_LocationInformation_sai_Present_present)
      {
         l_OlocInfo->bit_mask |= OMAP3_LocationInformation_sai_Present_present;
         l_OlocInfo->sai_Present = l_IlocInfo->sai_Present;
         DLOG(0,0,"LocInfo: SaiPresent from PsiRes"); 
      }

   }
   if(aPSIRes->subscriberInfo.bit_mask & IMAP3_SubscriberInfo_imei_present)
   {
      l_subsInfoPresent = true;
      aSRIRes->bit_mask |= OMAP3_subscriberInfo_present;
      aSRIRes->subscriberInfo.bit_mask |= OMAP3_SubscriberInfo_imei_present;
      aSRIRes->subscriberInfo.imei.length = aPSIRes->subscriberInfo.imei.length;
      memcpy(aSRIRes->subscriberInfo.imei.value,aPSIRes->subscriberInfo.imei.value,aSRIRes->subscriberInfo.imei.length);
      DLOG(0,0,"LocInfo: Imei from PsiRes"); 
   }
   if(true == l_subsInfoPresent)
   {
      DLOG(0,0,"Subscriber Info present in Psi Res");
      aSRIRes->bit_mask |= OMAP3_subscriberInfo_present;
   }
   else
   {
      LLOG(0,0,"SubscriberInfo not present in Psi Respnose"); 
   }
}
/////////////////////////////////////////////////////////////////////////////////////////
bool CtxtSendRoutingInfo::processMessage(Msg *aMsgPtr,bool& aDeleteFlag)
{
   DLOG(0,0,"Start of ProcessMsg function");
   MapSpecificMsg *l_specMsg = NULL;
   u32 l_UserDlgId = 0;

   switch (aMsgPtr->m_MsgType)
   {
      case MSG_TYPE_MAP:
         switch (((MapMsg*)aMsgPtr)->m_MapMsgType)
         {
            case MAP_MSG_TYPE_COMMON:
               switch (((MapCommonMsg*)aMsgPtr)->m_MapCommonMsgType)
               {
                  case MAP_CMN_OPEN_IND:
                     {
                        DLOG(0,0,"MAP_CMN_OPEN_IND received OriginationGt |%s| DestinationGt |%s|",((MapOpenInd*)aMsgPtr)->m_OrigAddr.globalTitle.addressInformation,((MapOpenInd*)aMsgPtr)->m_DestAddr.globalTitle.addressInformation);
                        strncpy(m_destAddr,((MapOpenInd*)aMsgPtr)->m_OrigAddr.globalTitle.addressInformation,sizeof(m_destAddr));
                        DLOG(0,0,"m_destAddr |%s|",m_destAddr);
                     }
                     break;

                  case MAP_CMN_DELIMITER_IND:
                     DLOG(0,0,"MAP_CMN_DELIMITER_IND received");
                     break;

                  case MAP_CMN_CLOSE_IND:
                     DLOG(0,0,"MAP_CMN_CLOSE_IND received");
                     return true;
                     break;

                  case MAP_CMN_OPEN_CNF:
                     {
                        CLOG(0,0,"MAP_CMN_OPEN_CNF received.. The sent MapVersion/AC is not supported by VLR");
                        u32 l_abrtDlgId = ((MapMsg*)aMsgPtr)->m_UserDlgId;
                        EMapVersion l_MapVersion = ((MapOpenCnf*)aMsgPtr)->m_Version;
                        m_tdr.setInteger(TDR_INDEX_OPEN_CNF_VERSION,(int)l_MapVersion); 
                        if(l_abrtDlgId == m_PSIdlgID)
                        {
                           CLOG(0,0,"MAP_CMN_OPEN_CNF Received on Psi DlgId |%d| so closing SRI dialogue as Psi cannot be sent again in V2 or V1",l_abrtDlgId);
                           m_ErrCode = MAP_ERROR_systemFailure;
                           return handleError();
                        }
                        else if(l_abrtDlgId == m_PRNdlgID) 
                        {
                           if(REFUSE_REASON_APPL_CNTXT_NOT_SUPPORTED == ((MapOpenCnf*)aMsgPtr)->m_RefuseReasonParam)
                           {
                              CLOG(0,0,"MAP_CMN_OPEN_CNF Received on Prn DlgId-|%d| Sending Prn on Ver-|%d|",l_abrtDlgId,l_MapVersion);
                              switch(l_MapVersion)
                              {
                                 case MAP_V3:
                                    {
                                       m_sentPrnVer = 3;
                                       m_tdr.setString(TDR_INDEX_CM_SRI_PSI_OR_PRN_FLAG,"prn"); 
                                       sendPRN();
                                    }
                                    break;
                                 case MAP_V2:
                                    {
                                       m_sentPrnVer = 2;
                                       m_tdr.setString(TDR_INDEX_CM_SRI_PSI_OR_PRN_FLAG,"prn"); 
                                       sendV2PRN();
                                    }
                                    break;
                                 case MAP_V1:
                                    {
                                       m_sentPrnVer = 1;
                                       m_tdr.setString(TDR_INDEX_CM_SRI_PSI_OR_PRN_FLAG,"prn"); 
                                       sendV1PRN();
                                    }
                                    break;
                                 default:
                                    {
                                       CLOG(0,0,"Unknown MapVersion received");
                                    }
                                    break;
                              }
                           }
                           else 
                           {
                              CLOG(0,0,"MAP_CMN_OPEN_CNF received with other reason[%d] on PRN DlgId |%d| so closing SRI dialogue",((MapOpenCnf*)aMsgPtr)->m_RefuseReasonParam,l_abrtDlgId);
                              m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_NOTICE_RCVD); // need not be NoticeRecvd
                              m_ErrCode = MAP_ERROR_systemFailure;
                              return handleError();
                           }
                        }
                        else 
                        {
                           CLOG(0,0,"MAP_CMN_OPEN_CNF Received on SRI DlgId |%d| just returning",l_abrtDlgId);
                           return true;
                        }
                     }
                     break;

                  case MAP_CMN_U_ABORT_IND:
                     {
                        u32 l_abrtDlgId = ((MapMsg*)aMsgPtr)->m_UserDlgId;
                        if(l_abrtDlgId == m_PSIdlgID)
                        {
                           CLOG(0,0,"MAP_CMN_U_ABORT_IND received for PSIdlg");
                           m_tdr.setInteger(TDR_INDEX_CM_SRI_PSI_OR_PRN_ERR,TDR_ERROR_U_ABORT_RCVD); 
                           if(0 == m_psiFailAction) // 1.0.3.0
                           {
                              LLOG(0,0,"PSI-FAIL Action is 0 so sending positvieSriResPsiNack");
                              return sendSRIResPSINack();
                           }
                           else
                           {
                              LLOG(0,0,"PSI-FAIL Action is 1 so sending negativeSriRes");
                              m_ErrCode = MAP_ERROR_systemFailure;
                              return handleError();
                           }
                        }
                        else if(l_abrtDlgId == m_PRNdlgID)
                        {
                           CLOG(0,0,"MAP_CMN_U_ABORT_IND Received on PRN DlgId |%d| so closing SRI dialogue",l_abrtDlgId);
                           m_tdr.setInteger(TDR_INDEX_CM_SRI_PSI_OR_PRN_ERR,TDR_ERROR_U_ABORT_RCVD); 
                           m_ErrCode = MAP_ERROR_systemFailure;
                           return handleError();
                        }
                        else 
                        {
                           CLOG(0,0,"MAP_CMN_U_ABORT_IND Received on SRI DlgId |%d| just returning",l_abrtDlgId);
                           m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_U_ABORT_RCVD); 
                           return true;
                        }
                     }
                     break;

                  case MAP_CMN_P_ABORT_IND:
                     {
                        u32 l_abrtDlgId = ((MapMsg*)aMsgPtr)->m_UserDlgId;
                        if(l_abrtDlgId == m_PSIdlgID)
                        {
                           CLOG(0,0,"MAP_CMN_P_ABORT_IND received for PSIdlg");
                           m_tdr.setInteger(TDR_INDEX_CM_SRI_PSI_OR_PRN_ERR,TDR_ERROR_P_ABORT_RCVD); 
                           if(0 == m_psiFailAction) // 1.0.3.0
                           {
                              LLOG(0,0,"PSI-FAIL Action is 0 so sending positvieSriResPsiNack");
                              return sendSRIResPSINack();
                           }
                           else
                           {
                              LLOG(0,0,"PSI-FAIL Action is 1 so sending negativeSriRes");
                              m_ErrCode = MAP_ERROR_systemFailure;
                              return handleError();
                           }
                        }
                        else if(l_abrtDlgId == m_PRNdlgID)
                        {
                           CLOG(0,0,"MAP_CMN_P_ABORT_IND Received on PRN DlgId |%d|  so closing SRI dialogue ",l_abrtDlgId);
                           m_tdr.setInteger(TDR_INDEX_CM_SRI_PSI_OR_PRN_ERR,TDR_ERROR_P_ABORT_RCVD); 
                           m_ErrCode = MAP_ERROR_systemFailure;
                           return handleError();
                        }
                        else 
                        {
                           CLOG(0,0,"MAP_CMN_P_ABORT_IND Received on SRI DlgId |%d| just returning",l_abrtDlgId);
                           m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_P_ABORT_RCVD); 
                           return true;
                        }
                     }
                     break;

                  case MAP_CMN_NOTICE_IND:
                     {
                        u32 l_noticeDlg = ((MapMsg*)aMsgPtr)->m_UserDlgId;
                        m_tdr.setInteger(TDR_INDEX_CM_SRI_PSI_OR_PRN_ERR,TDR_ERROR_NOTICE_RCVD); 
                        if(l_noticeDlg == m_PSIdlgID)
                        {
                           CLOG(0,0,"Notice Received on Psi DlgId |%d| Closing Psi DlgId",l_noticeDlg);
                           MapCloseReq l_closeReq(l_noticeDlg);
                           l_closeReq.m_CloseType = MAP_CLOSE_TYPE_PRE_ARRANGED_END;
                           g_sc.sendMsg(this, &l_closeReq);
                           if(0 == m_psiFailAction) // 1.0.3.0
                           {
                              LLOG(0,0,"PSI-FAIL Action is 0 so sending positvieSriResPsiNack");
                              return sendSRIResPSINack();
                           }
                           else
                           {
                              LLOG(0,0,"PSI-FAIL Action is 1 so sending negativeSriRes");
                              m_ErrCode = MAP_ERROR_systemFailure;
                              return handleError();
                           }
                        }
                        else if(l_noticeDlg == m_PRNdlgID)
                        {
                           CLOG(0,0,"Notice Received on Prn DlgId |%d| Closing Prn DlgId",l_noticeDlg);
                           MapCloseReq l_closeReq(l_noticeDlg);
                           l_closeReq.m_CloseType = MAP_CLOSE_TYPE_PRE_ARRANGED_END;
                           g_sc.sendMsg(this, &l_closeReq);
                           CLOG(0,0,"Closing Sri DlgId and sending SystemFailureError |%d|",getInitialRespondingDlgId());
                           m_ErrCode = MAP_ERROR_systemFailure;
                           return handleError();
                        }
                     }
                     break;

                  default:
                     CLOG(0,0,"Unknown Msg received [%d]", ((MapCommonMsg*)aMsgPtr)->m_MapCommonMsgType);
                     break;
               }
               break;

            case MAP_MSG_TYPE_SPECIFIC:
               {
                  l_specMsg = (MapSpecificMsg*)aMsgPtr;
                  l_UserDlgId = l_specMsg->m_UserDlgId; 
                  EMapVersion l_MapVersion = ((MapMsg*)aMsgPtr)->m_Version;

                  switch (((MapSpecificMsg*)aMsgPtr)->m_MapSpecificEventType)
                  {
                     case MAP_SPEC_EVENT_INDICATION:
                        {
                           DLOG(0,0,"MAP_SPEC_EVENT_INDICATION received MapVersion-|%d| DlgId-|%d|",l_MapVersion,l_UserDlgId);
                           switch (((MapSpecificMsg*)aMsgPtr)->m_OpCode)
                           {
                              case MAP_OP_CODE_sendRoutingInfo:
                                 {
                                    DLOG(0,0,"Received SendRoutingInformation");

                                    if (false == ((MapSpecificMsg*)aMsgPtr)->m_allocatedFlag)
                                    {
                                       CLOG(0,0,"SRI-DECODE Failed - Sending User Error Unexpected Data");
                                       m_ErrCode = MAP_ERROR_unexpectedData;
                                       m_InitDlgId = l_UserDlgId;
                                       m_MapVer = l_MapVersion;
                                       return handleError();
                                    }
                                    else if(NULL == g_spdPtr)
                                    {
                                       CLOG(0,0,"g_spdPTR is NULL .. profile Loading Failed returning SystemFailure");
                                       printf("\n ##### g_spdPTR is NULL profile Loading Failed .. sending system failure #####\n");
                                       m_ErrCode = MAP_ERROR_systemFailure; 
                                       m_InitDlgId = l_UserDlgId;
                                       m_MapVer = l_MapVersion;
                                       return handleError(); 
                                    }

                                    strcpy((char*)m_ExtnCntrData,((MapSpecificMsg*)aMsgPtr)->m_extensionContainerBuffer);
                                    DLOG(0,0,"Extension Container Buffer[%s] .copied[%s]",((MapSpecificMsg*)aMsgPtr)->m_extensionContainerBuffer,m_ExtnCntrData);

                                    handleSRI(aMsgPtr,l_UserDlgId,l_MapVersion);
                                 }
                                 break;

                              default:
                                 {
                                    CLOG(0,0,"Received Unknown Specific Message");
                                    MapUAbortReq l_req(l_UserDlgId);
                                    g_sc.sendMsg(this, &l_req);
                                 }
                                 break;
                           }
                        }
                        break;

                     case MAP_SPEC_EVENT_RESULT:
                        {
                           DLOG(0,0,"MAP_SPEC_EVENT_RESULT received");
                        }
                        break;

                     case MAP_SPEC_EVENT_CONFIRMATION:
                        {
                           DLOG(0,0,"MAP_SPEC_EVENT_CONFIRMATION received MapVersion-|%d| DlgId-|%d|",l_MapVersion,l_UserDlgId);
                           switch (((MapSpecificMsg*)aMsgPtr)->m_OpCode)
                           {
                              case MAP_OP_CODE_provideRoamingNumber: 
                                 {
                                    if (false == ((MapSpecificMsg*)aMsgPtr)->m_allocatedFlag)
                                    {
                                       CLOG(0,0,"PRN received is NULL. Sending User Error (Unexpected Data)...");
                                       m_ErrCode = MAP_ERROR_unexpectedData;
                                       return handleError();
                                    }
                                    DLOG(0,0,"Sending SRI response for PRNres..."); 
                                    //if mnrf=true make it false
                                    updateDb(0); 
                                    DLOG(0,0,"Prn Received on Map Version |%d|",l_MapVersion);
                                    sendSRIResPRN(aMsgPtr); 
                                 }
                                 break;

                              case MAP_OP_CODE_provideSubscriberInfo:
                                 {
                                    if (false == ((MapSpecificMsg*)aMsgPtr)->m_allocatedFlag)
                                    {
                                       CLOG(0,0,"PSI received is NULL. Sending User Error (Unexpected Data)...");
                                       m_ErrCode = MAP_ERROR_unexpectedData;
                                       return handleError();
                                    }
                                    DLOG(0,0," Sending SRI response for PSIres..."); 

                                    IMAP3_ProvideSubscriberInfoRes *l_psiRes = (IMAP3_ProvideSubscriberInfoRes*)(((MapSpecificMsg*)aMsgPtr)->m_structBuffer);
                                    if(true == m_DirectPSI)
                                    {
                                       LLOG(0,0,"SRI ... PSI is getting initiated for UDR LocationInfo");
                                       sendSRIUDRResPSIAck(l_psiRes);
                                    }
                                    else
                                    {
                                       LLOG(0,0,"Calling Normal SRI response PSI ACK ... sendSRIResPSIAck");
                                       sendSRIResPSIAck(l_psiRes);
                                    }
                                 }
                                 break;

                              default:
                                 break;
                           }
                        }
                        break;

                     case MAP_SPEC_EVENT_USER_ERROR:
                        {
                           DLOG(0,0,"MAP_SPEC_EVENT_USER_ERROR received");

                           EMapErrorCode l_errCode = ((MapUserError*)aMsgPtr)->m_ErrorCode;

                           if(l_UserDlgId == m_PRNdlgID)
                           {
                              switch(l_errCode)
                              {
                                 case MAP_ERROR_facilityNotSup:
                                    {
                                       CLOG(0,0,"Prn Error Case:  MAP_ERROR_facilityNotSup Sending MapError on SRIDlgId");
                                       m_ErrCode = MAP_ERROR_facilityNotSup;
                                    }
                                    break;

                                 case MAP_ERROR_orNotAllowed:
                                    {
                                       CLOG(0,0,"Prn Error Case:  MAP_ERROR_orNotAllowed Sending MapError on SRIDlgId");
                                       m_ErrCode = MAP_ERROR_orNotAllowed;
                                    }
                                    break;

                                 case MAP_ERROR_absentSubscriber:
                                 case MAP_ERROR_noRoamingNb:			
                                    {
                                       if((mp_sriSubData->m_fwdInfo.m_FtnLen > 1) || (mp_sriSubData->m_fwdInfo.m_DefFtnLen > 1))
                                       {
                                          CLOG(0,0,"Prn Error Case:  ABSENTSUBS/NOROAMINGNUMB MNRF NOT SET BUT FTN PRESENT sending FTN");
                                          if(l_errCode == MAP_ERROR_absentSubscriber)
                                          {
                                             updateDb(1);
                                          }
                                          m_ForwardType = 2;
                                          if(m_MapVer == MAP_V3)
                                          {
                                             if(m_ocsiSet)
                                                return sendSRIResFTNCSI(); 
                                             else
                                                return sendSRIResOnlyFTN();
                                          }
                                          else
                                          {
                                             if(m_ocsiSet)
                                             {
                                                LLOG(0,0,"O-CSI is set in v1/v2. So sending callbarred");
                                                m_ErrCode = MAP_ERROR_callBarred;
                                                return handleError();
                                             }
                                             else
                                             {
                                                return sendSRIResOnlyFTN();
                                             }
                                          }
                                       }
                                       if(l_errCode == MAP_ERROR_absentSubscriber)
                                       {
                                          CLOG(0,0,"Prn Error Case:  ABSENTSUBS MNRF NOT SET and FTN NOT PRESENT Sending MAP_ERROR_absentSubscriber");
                                          updateDb(1);
                                          m_ErrCode = MAP_ERROR_absentSubscriber;    
                                       }
                                       else
                                       {
                                          /*CLOG(0,0,"Prn Error Case:  NOROAMINGNUMB MNRF NOT SET and FTN NOT PRESENT Sending MAP_ERROR_systemFailure");
                                            m_ErrCode = MAP_ERROR_systemFailure;*/ // commented in 2.0.0.0 Rev1

                                          MapCloseReq l_closeReq(getInitialRespondingDlgId()); // Added 2.0.0.0 Rev1
                                          l_closeReq.m_CloseType = MAP_CLOSE_TYPE_PRE_ARRANGED_END;
                                          g_sc.sendMsg(this, &l_closeReq);
                                          m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_GENERAL_ERROR); 
                                          m_tdr.setInteger(TDR_INDEX_CM_SRI_PSI_OR_PRN_ERR,TDR_ERROR_GENERAL_ERROR); 
                                          return true;
                                       }
                                    }
                                    break;
                                 default:
                                    {
                                       CLOG(0,0,"unknown MAP_ERROR recvd with ErrorCode [%d] for PRNDlgId ",l_errCode);
                                       m_ErrCode = MAP_ERROR_systemFailure;
                                    }
                              }
                              m_tdr.setInteger(TDR_INDEX_CM_SRI_PSI_OR_PRN_ERR,m_ErrCode); 
                              return handleError();
                           }
                           else if(l_UserDlgId == m_PSIdlgID)
                           {
                              CLOG(0,0,"Got Psi Negative Response with ErrorCode[%d]",l_errCode);
                              m_tdr.setInteger(TDR_INDEX_CM_SRI_PSI_OR_PRN_ERR,TDR_ERROR_GENERAL_ERROR); 
                              if(0 == m_psiFailAction) // 1.0.3.0_Rev1
                              {
                                 LLOG(0,0,"PSI-FAIL Action is 0 so sending positvieSriResPsiNack");
                                 return sendSRIResPSINack();
                              }
                              else
                              {
                                 LLOG(0,0,"PSI-FAIL Action is 1 so sending negativeSriRes");
                                 m_ErrCode = MAP_ERROR_systemFailure;
                                 return handleError();
                              }
                           }
                        }
                        break;

                     case MAP_SPEC_EVENT_PROV_ERROR:
                        {
                           m_tdr.setInteger(TDR_INDEX_CM_SRI_PSI_OR_PRN_ERR,TDR_ERROR_PROVIDER_ERROR_RCVD); 
                           if(l_UserDlgId == m_PSIdlgID)
                           {
                              CLOG(0,0,"MAP_SPEC_EVENT_PROV_ERROR received for PSIdlg");
                              if(0 == m_psiFailAction) // 1.0.3.0_Rev1
                              {
                                 LLOG(0,0,"PSI-FAIL Action is 0 so sending positvieSriResPsiNack");
                                 return sendSRIResPSINack();
                              }
                              else
                              {
                                 LLOG(0,0,"PSI-FAIL Action is 1 so sending negativeSriRes");
                                 m_ErrCode = MAP_ERROR_systemFailure;
                                 return handleError();
                              }
                           }
                           else
                           {
                              CLOG(0,0,"MAP_SPEC_EVENT_PROV_ERROR received - Closing the SRI Dialgoue with SystemFailure");
                              m_ErrCode = MAP_ERROR_systemFailure;
                              m_tdr.setInteger(TDR_INDEX_CM_SRI_PSI_OR_PRN_ERR,m_ErrCode); 
                              return handleError();
                           }
                        }
                        break;
                     default:
                        ELOG(0,0,"ERROR!! Default SPECIFIC MSG received");
                        break;
                  }
               }
               break;

            default:
               break;
         }
         break;

      case MSG_TYPE_DB:
         {
            if(1 ==  ((DbQueryMsg*)aMsgPtr)->m_DbQueryType)
            {
               aDeleteFlag = false;
               CMSRIDBdata *l_Msg = (CMSRIDBdata *)aMsgPtr;

               DLOG(0,0,"DBRES: m_EdbResult |%d|",l_Msg->m_EdbResult);

               TLOG(0,0,"NetworkId is |%d|", l_Msg->m_networkId);
               m_tdr.setInteger(TDR_INDEX_MM_NETWORK_ID, l_Msg->m_networkId);

               mp_sriSubData = l_Msg;
               m_Mnrf = mp_sriSubData->m_Mnrf;

               LLOG(0,0,"DBRES: SRIRES-HLR-GT:|%s|",mp_sriSubData->m_IsrHlrAddr);
               if(strlen((s8*)mp_sriSubData->m_IsrHlrAddr) > 1) 
               {
                  sendMapOpenResponse(m_InitDlgId,(s8*)mp_sriSubData->m_IsrHlrAddr,g_ConfigData->i_NgConfigData.m_selfAddress.ssn);
                  m_tdr.setString(TDR_INDEX_LOCAL_ADDRESS,(s8*)mp_sriSubData->m_IsrHlrAddr); 
               }
               else
               {
                  LLOG(0,0,"DBRES: SRI-HLR-GT not present in DBRes picking from NgConfig");
               }

               if(CM_DB_SUCCESS == l_Msg->m_EdbResult)
               {
                  u16 msgType = l_Msg->getMsgType();
                  LLOG(0,0,"DBRES: Collect Call Value [%s]",mp_sriSubData->m_collectCallValue);// 4050 HLR
                  m_tdr.setString(TDR_INDEX_HLR_RESRV3,mp_sriSubData->m_collectCallValue); //99th index new tdr value

                  LLOG(0,0,"DBRES: PRN-PSI-ACTIVE-HLR-GT:|%s| RoamProfile:|%d| PartnerType:|%d| SriImsiType:|%d|",mp_sriSubData->m_prnPsiHlrAddr,mp_sriSubData->m_profType,mp_sriSubData->m_partnerType,mp_sriSubData->m_sriImsiType);

                  m_tdr.setInteger(TDR_INDEX_PARTNER_TYPE,mp_sriSubData->m_partnerType); // 1.0.0.4

                  // PrimaryImsi is retreived for future use just in case if ActiveImsi=0 while sending in SriRes use PrimaryImsi
                  LLOG(0,0,"DBRES: ActImsi:|%s| ActMsisdn:|%s| PrimImsi:|%s| Vlr:|%s| Msc:|%s| LocalImsi:|%s|",mp_sriSubData->m_ActiveImsi,mp_sriSubData->m_ActiveMsisdn,mp_sriSubData->m_PrimaryImsi, mp_sriSubData->m_VlrNum,mp_sriSubData->m_MscNum,mp_sriSubData->m_SriLocalImsi);

                  TLOG(0,0,"DBRES: TeleSrvcCodeArray:|%s|",mp_sriSubData->m_TeleSrvcCodeArr);
                  TLOG(0,0,"DBRES: BearerSrvcCodeArray:|%s|",mp_sriSubData->m_BearSrvcCodeArr);
                  LLOG(0,0,"DBRES: NwId:|%d| PNwId:|%d| Mnrf:|%d| SuppCphVmsc:|%d| Crbt:|%d| ImsTcsi|%d| PortOutModel:|%d|",mp_sriSubData->m_networkId,mp_sriSubData->m_PartnerNetId,m_Mnrf,mp_sriSubData->m_SupportedCamelPhaseVmsc,mp_sriSubData->m_crbtStatus,mp_sriSubData->m_IMSTcsiIndicator,mp_sriSubData->m_portOutModel);
                  LLOG(0,0,"DBRES: BCTranslation: BSType:|%d| BSCode:|%d| BCflag:|%d| TdrRestrData[%s]",mp_sriSubData->m_bsrvcType,mp_sriSubData->m_bsrvcCode,mp_sriSubData->m_bcFlag,mp_sriSubData->m_TdrRestrictedData);
                  TLOG(0,0,"DBRES: VlrUnsuppTeleCodes:|%s| VlrUnsuppBearerCodes:|%s|",mp_sriSubData->m_VlrUnsupTeleSrvcArr,mp_sriSubData->m_VlrUnsupBearSrvcArr);
                  m_tdr.setString(TDR_INDEX_HLR_RESRV1,(s8*)mp_sriSubData->m_TdrRestrictedData); 
                  m_tdr.setInteger(TDR_INDEX_HLR_RESRV2,mp_sriSubData->m_portOutModel);
                  m_tdr.setString(TDR_INDEX_IMEI,(s8*)mp_sriSubData->m_ActiveImsi); 

                  LLOG(0,0,"DBRES: IMSTCSI Indicator|%d| m_IMSTcsiInfo|%s|",mp_sriSubData->m_IMSTcsiIndicator,mp_sriSubData->m_IMSTcsiInfo);
                  m_tdr.setInteger(TDR_INDEX_HLR_RESRV4,mp_sriSubData->m_IMSTcsiIndicator); 
                  m_tdr.setString(TDR_INDEX_SSM_SS_CODE,(s8*)mp_sriSubData->m_IMSTcsiInfo);

                  LLOG(0,0,"DBRES: Migration Helper TDR [%s]",mp_sriSubData->m_migrationHelperTdr);
                  m_tdr.setString(TDR_INDEX_HLR_RESRV9,(char*)mp_sriSubData->m_migrationHelperTdr);

                  if(1 == mp_sriSubData->m_bcFlag)
                  {
                     LLOG_HEX(0,0,"BearerCapability Data", (s8*)mp_sriSubData->m_bearerCap,mp_sriSubData->m_bearerCapLen);
                  }
                  m_OcsiProfileId = mp_sriSubData->m_OcsiProfileId;
                  m_DcsiProfileId = mp_sriSubData->m_DcsiProfileId;
                  m_ForwardType = mp_sriSubData->m_ForwardType;

                  if((1 == mp_sriSubData->m_IMSTcsiIndicator) && (0 != mp_sriSubData->m_TcsiProfileId))
                  {
                     DLOG(0,0,"IMSTCSI Indicator[%d] and TCSI Profile Id[%d], checking ForwardType",mp_sriSubData->m_IMSTcsiIndicator,mp_sriSubData->m_TcsiProfileId);
                     if((CM_DB_FORWARD_UNCONDITIONAL == m_ForwardType) || (CM_DB_FORWARD_NOTREACHABLE == m_ForwardType))
                     {
                        LLOG(0,0,"IMSTCSI[%d] present and ForwardType[%d] is UNCONDITIONAL or NOTREACHABLE, not sending TCSI",mp_sriSubData->m_TcsiProfileId,m_ForwardType);
                        m_TcsiProfileId = 0;
                     }
                     else
                     {
                        TLOG(0,0,"IMSTCSI[%d] present and ForwardType[%d] is not UNCONDITIONAL or NOTREACHABLE, enabling TCSI",mp_sriSubData->m_TcsiProfileId,m_ForwardType);
                        m_TcsiProfileId = mp_sriSubData->m_TcsiProfileId;
                     }
                  }
                  else
                  {
                     m_TcsiProfileId = mp_sriSubData->m_TcsiProfileId;
                     TLOG(0,0,"Not an IMS-TCSI");
                  }


                  LLOG(0,0,"DBRES: Tcsi:|%d| Ocsi:|%d| Dcsi:|%d| FwdType:|%d| 1:uncon 2:nrch",m_TcsiProfileId,m_OcsiProfileId,m_DcsiProfileId,m_ForwardType);


                  if(CM_DB_FORWARD_UNCONDITIONAL == m_ForwardType) // 2.0.7.0
                  {
                     if(mp_sriSubData->m_fwdInfo.m_FtnLen < 2)
                     {
                        if( (MAP_V3 != m_MapVer) && (mp_sriSubData->m_fwdInfo.m_DefFtnLen > 15) ) 
                        {
                           LLOG(0,0,"LongFtn defaultftn present-|%s| but not MapV3 .. sending unexpected data",mp_sriSubData->m_fwdInfo.m_DefFtn);
                           m_ErrCode = MAP_ERROR_unexpectedData;
                           return handleError();
                        }

                        if( (false == m_longFtnSupportFlag) && (mp_sriSubData->m_fwdInfo.m_DefFtnLen > 15) )
                        {
                           LLOG(0,0,"LongFtn not supported by Gmsc but default FTN is more than 15 digits|%s| .. sending unexpected data",mp_sriSubData->m_fwdInfo.m_DefFtn);
                           m_ErrCode = MAP_ERROR_unexpectedData;
                           return handleError();
                        }
                     }
                  }

                  if(1 == mp_sriSubData->m_sriImsiType) //primary
                  {
                     TLOG(0,0,"SriImsiType[1] sending PrimaryImsi");
                     snprintf(m_SriImsi,sizeof(m_SriImsi),"%s",mp_sriSubData->m_PrimaryImsi);
                  }
                  else if( (2 == mp_sriSubData->m_sriImsiType) && (1 == mp_sriSubData->m_partnerType) )//local
                  {
                     TLOG(0,0,"SriImsiType[2] PartnerType[1] sending LocalImsi if present else ActiveImsi if present else PrimaryImsi");
                     snprintf(m_SriImsi,sizeof(m_SriImsi),"%s",( (strlen((char*)mp_sriSubData->m_SriLocalImsi)>1) ? (mp_sriSubData->m_SriLocalImsi) : ( (strlen((char*)mp_sriSubData->m_ActiveImsi)>1) ? (mp_sriSubData->m_ActiveImsi) : (mp_sriSubData->m_PrimaryImsi)) ) );
                  }
                  else //active
                  {
                     TLOG(0,0,"SriImsiType[%d] sending ActiveImsi if present else PrimaryImsi",mp_sriSubData->m_sriImsiType);
                     snprintf(m_SriImsi,sizeof(m_SriImsi),"%s",( (strlen((char*)mp_sriSubData->m_ActiveImsi)>1) ? (mp_sriSubData->m_ActiveImsi) : (mp_sriSubData->m_PrimaryImsi) ) );
                  }

                  setTraceImsi((s8*)mp_sriSubData->m_ActiveImsi);

                  if(true == m_collect_call_enabled)
                  {
                     if(0 == strcmp(mp_sriSubData->m_collectCallValue,"NS"))
                     {
                        LLOG(0,0,"Interrogation Type is 2 and collect call not supported in HLR rejecting as facilitynotSupported");
                        m_ErrCode = MAP_ERROR_facilityNotSup;
                        return handleError();
                     }

                     else if( (0 == strcmp(mp_sriSubData->m_collectCallValue,"DT")) || (0 == strcmp(mp_sriSubData->m_collectCallValue,"DS")) )
                     {
                        LLOG(0,0,"Collect Call Blocked for the subscriber sending SRI response with SScode 249");
                        return sendSRIResSSList();
                     }
                  }

                  EResult l_chkHLRSubs = checkHLRSubscription();
                  if(CM_CONTINUE == l_chkHLRSubs)
                  {
                     EResult l_chkVLRSubs = checkVLRSubscription();
                     if(CM_CONTINUE == l_chkVLRSubs)
                     {
                        if(m_nonTelephony) // 1.0.3.0
                        {
                           m_tdr.setInteger(TDR_INDEX_SSM_BS_TYPE,mp_sriSubData->m_bsrvcType); 
                           m_tdr.setInteger(TDR_INDEX_SSM_BS_CODE,mp_sriSubData->m_bsrvcCode); 
                           EResult l_nonTelephonyHLRprovCheck = checkNonTelephonyHLRProvisioning();
                           if(CM_ERROR == l_nonTelephonyHLRprovCheck)
                           {
                              LLOG(0,0,"CheckNonTelephonyHLRProvisioning Fail - sending MapUserError on DlgId |%d|",m_InitDlgId);
                              return handleError(); 
                           }
                           else
                           {
                              TLOG(0,0,"CheckNonTelephonyHLRProvisioning Success ");
                              EResult l_nonTelephonyVLRprovCheck = checkNonTelephonyVLRProvisioning();
                              if(CM_ERROR == l_nonTelephonyVLRprovCheck)
                              {
                                 LLOG(0,0,"CheckNonTelephonyVLRProvisioning Fail - sending FaciltiyNotSupported on DlgId |%d|",m_InitDlgId);
                                 return handleError(); 
                              }
                              else
                              {
                                 TLOG(0,0,"CheckNonTelephonyVLRProvisioning Success ");
                              }
                           }
                        }

                        if( (m_suppGmscCamelPhase >> 4) & 0x01)
                           m_highestCphGmsc = 4;
                        else if( (m_suppGmscCamelPhase >> 5) & 0x01)
                           m_highestCphGmsc = 3;
                        else if( (m_suppGmscCamelPhase >> 6) & 0x01)
                           m_highestCphGmsc = 2;
                        else
                           m_highestCphGmsc = 1;
                        TLOG(0,0,"Highest Supported Camel Phase of Gmsc |%d|",m_highestCphGmsc);


                        if(MAP_OP_CODE_provideSubscriberInfo == msgType)
                        {
                           if(true == m_DirectPSI)
                           {
                              DLOG(0,0,"Suppress VT CSI is found so directly calling sendPSI and returning...");
                              sendPSI();
                              return false;
                           }

                           EResult l_tcsiCheck = checkTCSI(m_TcsiProfileId);
                           if(l_tcsiCheck == CM_ERROR)
                           {
                              LLOG(0,0,"checkTcsi Error sending System Failure");
                              return handleError();
                           }
                           else
                           {
                              map<int, HlrNetworks* > :: iterator l_HlrNetworksDetailsIter;
                              l_HlrNetworksDetailsIter = g_spdPtr->m_HlrNetworks.find(mp_sriSubData->m_networkId);
                              if(l_HlrNetworksDetailsIter != g_spdPtr->m_HlrNetworks.end())
                              {
                                 TLOG(0,0,"NetworkId[%d] present in HlrNetworks Map, checking for DisableFwdInfoInIsdSri Value",mp_sriSubData->m_networkId);
                                 if(1 ==(l_HlrNetworksDetailsIter->second)->m_DisableFwdInfoInIsdSri)
                                 {
                                    LLOG(0,0,"#### TCSI set and DisableFwdInfoInIsdSri|%d| is enabled, unsetting ocsi/psi/fwdinfo",(l_HlrNetworksDetailsIter->second)->m_DisableFwdInfoInIsdSri);
                                    m_OcsiProfileId = 0;
                                    m_DcsiProfileId = 0;
                                    m_psiInitFlag = 0;
                                    m_ForwardType = 0;
                                 }
                                 else
                                 {
                                    LLOG(0,0,"### TCSI set and DisableFwdInfoInIsdSri|%d| is Disabled, Sending the ocsi/psi/fwdinfo",(l_HlrNetworksDetailsIter->second)->m_DisableFwdInfoInIsdSri);
                                 }
                              }
                              else
                              {
                                 TLOG(0,0,"TCSI set, NetworkId[%d]not present in HlrNetworks Map, Not checking DisableFwdInfoInIsdSri Value, Sending ocsi/psi/fwdinfo",mp_sriSubData->m_networkId);
                              }
                           }
                           
                           EResult l_ocsiCheck = checkOCSI(m_OcsiProfileId);
                           if(l_ocsiCheck == CM_ERROR)
                           {
                              LLOG(0,0,"checkOcsi Error sending System Failure");
                              return handleError();
                           }

                           EResult l_dcsiCheck = checkDCSI(m_DcsiProfileId);
                           if(l_dcsiCheck == CM_ERROR)
                           {
                              LLOG(0,0,"checkDcsi Error sending System Failure");
                              return handleError();
                           }

                           EResult l_handleFirstFwd = handleFirstForwarding(m_ForwardType);
                           switch(l_handleFirstFwd)
                           {
                              case CM_CONTINUE: // Normal flow of hndleFirstFwding
                                 {
                                    if(1 == mp_sriSubData->m_IMSTcsiIndicator)
                                    {
                                       LLOG(0,0,"IMSTCSI indicator[%d] present sending sendSRIResPSINack",mp_sriSubData->m_IMSTcsiIndicator);
                                       return sendSRIResPSINack();
                                    }
                                    if((strlen((s8*)mp_sriSubData->m_prnPsiHlrAddr) > 1) && (strlen((s8*)mp_sriSubData->m_VlrNum) > 1)) 
                                    {
                                       if(m_tcsiSet)
                                       {
                                          getPsiStatus(); // 1.0.3.0  // This function call fills the PsiInitFlag and PsiFailAction
                                          if(1 == m_psiInitFlag) 
                                          {
                                             LLOG(0,0,"NormalCase-Handle1stFrwd:  CheckTcsi=true checking Ocsi-Dcsi and sending Psi");
                                             m_tdr.setString(TDR_INDEX_CM_SRI_PSI_OR_PRN_FLAG,"psi"); 
                                             sendPSI();
                                          }
                                          else
                                          {
                                             LLOG(0,0,"NormalCase-Handle1stFrwd: Psi-Init Flag NOT ENABLED so sending sriResPsiNack");
                                             return sendSRIResPSINack();
                                          }
                                       }
                                       else
                                       {
                                          LLOG(0,0,"NormalCase-Handle1stFrwd:  CheckTcsi=false sending Prn");
                                          m_sentPrnVer = 3;
                                          m_tdr.setString(TDR_INDEX_CM_SRI_PSI_OR_PRN_FLAG,"prn"); 
                                          sendPRN(); 
                                       }
                                    }
                                    else
                                    {
                                       LLOG(0,0,"NormalCase-Handle1stFrwd: CalDverTrtmt Ind maybe present and records purged");
                                       m_ErrCode = MAP_ERROR_absentSubscriber;
                                       return handleError();
                                    }
                                 }
                                 break;

                              case CM_FORWARD: // Forwarded leg from hndleFirstFwding
                                 {
                                    // if mnrf is set do not go for sending psi
                                    if(CM_DB_FORWARD_UNCONDITIONAL == m_ForwardType)

                                    {
                                       if(1 == mp_sriSubData->m_portOutModel)
                                       {
                                          return sendSRIResMsrnFtn();
                                       }
                                       if(m_tcsiSet)
                                       {
                                          // check valid data in subs_data - record may be purged in case of LU failure
                                          if((strlen((s8*)mp_sriSubData->m_prnPsiHlrAddr) > 1) && (strlen((s8*)mp_sriSubData->m_VlrNum) > 1)) 
                                          {
                                             getPsiStatus(); // 1.0.3.0  // This function call fills the PsiInitFlag and PsiFailAction
                                             if(1 == m_psiInitFlag) 
                                             {
                                                LLOG(0,0,"ForwardCase-CFU:  Tcsi Set - Sending Psi");
                                                m_tdr.setString(TDR_INDEX_CM_SRI_PSI_OR_PRN_FLAG,"psi"); 
                                                sendPSI();
                                             }
                                             else
                                             {
                                                LLOG(0,0,"ForwardCase-CFU: Tcsi Set Psi-Init Flag Not Enabled so sending sriResPsiNack");
                                                return sendSRIResPSINack();
                                             }
                                          }
                                          else
                                          {
                                             LLOG(0,0,"ForwardCase-CFU:  Tcsi Set but not sending PSI as the subs_data records are empty/purged .. sending SRIres with Ftn/csi");
                                             return sendSRIResPSINack();
                                          }
                                       }
                                       else
                                       {
                                          LLOG(0,0,"ForwardCase-CFU:  Tcsi not set - checking for Ocsi and sending SRIRes with FTN");
                                          if(m_ocsiSet)
                                             sendSRIResFTNCSI(); 
                                          else
                                             sendSRIResOnlyFTN();
                                       }
                                    }
                                    else if(CM_DB_FORWARD_NOTREACHABLE == m_ForwardType)
                                    {
                                       if(m_tcsiSet)
                                       {
                                          LLOG(0,0,"ForwardCase-CFNRc: TCSI set sending SRIResPSINack");
                                          sendSRIResPSINack(); 
                                       }


                                       else
                                       {
                                          LLOG(0,0,"ForwardCase-CFNRc:  TCSI not set  checking for Ocsi and sending SRIRes with FTN");
                                          if(m_ocsiSet)       
                                             sendSRIResFTNCSI();
                                          else
                                             sendSRIResOnlyFTN();
                                       }
                                    }
                                 }
                                 break;
                              case CM_ERROR:
                                 {
                                    LLOG(0,0,"HandleFirstFrwd-Error Case");
                                    return handleError();
                                 }
                                 break;
                              default:
                                 break;
                           }
                        }
                        else if(MAP_OP_CODE_provideRoamingNumber == msgType)
                        {
                           switch(m_MapVer)
                           {
                              case MAP_V3:
                                 {
                                    EResult l_ocsiCheck = checkOCSI(m_OcsiProfileId);
                                    if(l_ocsiCheck == CM_ERROR)
                                    {
                                       LLOG(0,0,"checkOcsi Error sending System Failure");
                                       return handleError();
                                    }

                                    EResult l_dcsiCheck = checkDCSI(m_DcsiProfileId);
                                    if(l_dcsiCheck == CM_ERROR)
                                    {
                                       LLOG(0,0,"checkDcsi Error sending System Failure");
                                       return handleError();
                                    }

                                    EResult l_handleFirstFwd = handleFirstForwarding(m_ForwardType);
                                    switch(l_handleFirstFwd)
                                    {
                                       case CM_CONTINUE: // Normal flow of hndleFirstFwding
                                          {
                                             if((strlen((s8*)mp_sriSubData->m_prnPsiHlrAddr) > 1) && (strlen((s8*)mp_sriSubData->m_VlrNum) > 1)) 
                                             {
                                                LLOG(0,0,"NormalCase-Handle1stFrwd:  Sending Prn");
                                                m_sentPrnVer = 3;
                                                m_tdr.setString(TDR_INDEX_CM_SRI_PSI_OR_PRN_FLAG,"prn"); 
                                                sendPRN();
                                             }
                                             else
                                             {
                                                LLOG(0,0,"NormalCase-Handle1stFrwd: CalDverTrtmt Ind maybe present and records purged");
                                                m_ErrCode = MAP_ERROR_absentSubscriber;
                                                return handleError();
                                             }
                                          }
                                          break;

                                       case CM_FORWARD: // Forwarded leg from hndleFirstFwding
                                          {
                                             if( (1 == mp_sriSubData->m_portOutModel) && (CM_DB_FORWARD_UNCONDITIONAL == m_ForwardType) )
                                             {
                                                return sendSRIResMsrnFtn();
                                             }
                                             LLOG(0,0,"ForwardCase-Handle1stFrwd:  checking for Ocsi and sending SRIRes with Ftn");
                                             if(m_ocsiSet)
                                                sendSRIResFTNCSI(); 
                                             else
                                                sendSRIResOnlyFTN();
                                          }
                                          break;
                                       case CM_ERROR:
                                          {
                                             LLOG(0,0,"HandleFirstFrwd-Error Case");
                                             return handleError();
                                          }
                                       default:
                                          break;

                                    }
                                 }
                                 break;
                              case MAP_V2:
                                 {
                                    EResult l_tcsiCheck = checkTCSI(m_TcsiProfileId);
                                    if(l_tcsiCheck == CM_ERROR)
                                    {
                                       LLOG(0,0,"V2:checkTcsi Error sending System Failure");
                                       return handleError();
                                    }
                                    if(m_tcsiSet)
                                    {
                                       LLOG(0,0,"V2-SRI: T-CSI set for subscriber sending CallBarred error");
                                       m_ErrCode = MAP_ERROR_callBarred;
                                       return handleError();
                                    }
                                    EResult l_ocsiCheck = checkOCSI(m_OcsiProfileId);
                                    if(l_ocsiCheck == CM_ERROR)
                                    {
                                       LLOG(0,0,"V2:checkOcsi Error sending System Failure");
                                       return handleError();
                                    }

                                    EResult l_handleFirstFwd = handleFirstForwarding(m_ForwardType);
                                    switch(l_handleFirstFwd)
                                    {
                                       case CM_CONTINUE: // Normal flow of hndleFirstFwding
                                          {
                                             LLOG(0,0,"V2:NormalCase-Handle1stFrwd:  Sending Prn");
                                             m_sentPrnVer = 2;
                                             sendV2PRN();
                                          }
                                          break;

                                       case CM_FORWARD: // Forwarded leg from hndleFirstFwding
                                          {
                                             if( (1 == mp_sriSubData->m_portOutModel) && (CM_DB_FORWARD_UNCONDITIONAL == m_ForwardType) )
                                             {
                                                return sendSRIResMsrnFtn();
                                             }
                                             if(m_ocsiSet)
                                             {
                                                LLOG(0,0,"V2-SRI: O-CSI set for subscriber sending CallBarred error");
                                                m_ErrCode = MAP_ERROR_callBarred;
                                                return handleError();
                                             }
                                             else
                                             {
                                                LLOG(0,0,"V2:ForwardCase-Handle1stFrwd:  sending SRIRes with Ftn");
                                                sendSRIResOnlyFTN();
                                             }
                                          }
                                          break;
                                       default:
                                          break;
                                    }
                                 }
                                 break;
                              case MAP_V1:
                                 {
                                    EResult l_tcsiCheck = checkTCSI(m_TcsiProfileId);
                                    if(l_tcsiCheck == CM_ERROR)
                                    {
                                       LLOG(0,0,"V1:checkTcsi Error sending System Failure");
                                       return handleError();
                                    }
                                    if(m_tcsiSet)
                                    {
                                       LLOG(0,0,"V1-SRI: T-CSI set for subscriber sending CallBarred error");
                                       m_ErrCode = MAP_ERROR_callBarred;
                                       return handleError();
                                    }
                                    EResult l_ocsiCheck = checkOCSI(m_OcsiProfileId);
                                    if(l_ocsiCheck == CM_ERROR)
                                    {
                                       LLOG(0,0,"V1:checkOcsi Error sending System Failure");
                                       return handleError();
                                    }

                                    EResult l_handleFirstFwd = handleFirstForwarding(m_ForwardType);
                                    switch(l_handleFirstFwd)
                                    {
                                       case CM_CONTINUE: // Normal flow of hndleFirstFwding
                                          {
                                             LLOG(0,0,"V1:NormalCase-Handle1stFrwd:  Sending Prn");
                                             m_sentPrnVer = 1;
                                             m_tdr.setString(TDR_INDEX_CM_SRI_PSI_OR_PRN_FLAG,"prn"); 
                                             sendV1PRN();
                                          }
                                          break;

                                       case CM_FORWARD: // Forwarded leg from hndleFirstFwding
                                          {
                                             if( (1 == mp_sriSubData->m_portOutModel) && (CM_DB_FORWARD_UNCONDITIONAL == m_ForwardType) )
                                             {
                                                return sendSRIResMsrnFtn();
                                             }
                                             if(m_ocsiSet)
                                             {
                                                LLOG(0,0,"V1-SRI: O-CSI set for subscriber sending CallBarred error");
                                                m_ErrCode = MAP_ERROR_callBarred;
                                                return handleError();
                                             }
                                             else
                                             {
                                                LLOG(0,0,"V1:ForwardCase-Handle1stFrwd:  sending SRIRes with Ftn");
                                                sendSRIResOnlyFTN();
                                             }
                                          }
                                          break;
                                       default:
                                          break;
                                    }
                                 }
                                 break;

                              default:
                                 {
                                    CLOG(0,0,"Unknown MapVersion Received");
                                 }
                                 break;
                           }
                        }
                     }
                     else
                     {
                        CLOG(0,0,"Result of checkVLRSubscription is not Continue - sending FacilityNotSupported on DlgId |%d|",m_InitDlgId);
                        return handleError(); // FacilityNotSupported
                     }
                  }
                  else
                  {
                     CLOG(0,0,"Result of checkHLRSubscription is not Continue - sending MapUserError on DlgId |%d|",m_InitDlgId);
                     return handleError(); // Bearer/TeleService Not Provisioned
                  }
               }
               else
               {
                  if(MAP_ERROR_unauthorizedRequestingNetwork == l_Msg->m_errCode)
                  {
                     CLOG(0,0,"DB Failure .. ErrCode:[%d] UnAuthorized requesting entity sending FacilityNotSupp",l_Msg->m_errCode);
                     m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_ENTITY_AUTH_FAILED); 
                     m_tdr.setInteger(TDR_INDEX_DB_ERR_CODE, (abs)(((DbQueryMsg*)aMsgPtr)->m_procErrorCode));
                     m_tdr.setString(TDR_INDEX_DB_ERR_DESC, ((DbQueryMsg*)aMsgPtr)->m_procErrorMessage);
                     g_si.sendSnmpTrap(g_CMEntityAuthFailTrap, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL);
                     //MapCloseReq l_closeReq(m_InitDlgId);
                     //l_closeReq.m_CloseType = MAP_CLOSE_TYPE_PRE_ARRANGED_END;
                     //g_sc.sendMsg(this, &l_closeReq);
                     m_ErrCode = MAP_ERROR_facilityNotSup; 
                     return handleError();
                  }
                  else
                  {
                     m_ErrCode = (EMapErrorCode)l_Msg->m_errCode;
                     CLOG(0,0,"DB Failure .. Error Code Value |%d|",l_Msg->m_errCode);
                     m_tdr.setInteger(TDR_INDEX_DB_ERR_CODE, (abs)(((DbQueryMsg*)aMsgPtr)->m_procErrorCode));
                     m_tdr.setString(TDR_INDEX_DB_ERR_DESC, ((DbQueryMsg*)aMsgPtr)->m_procErrorMessage);
                     return handleError(); 
                  }
               }
            }
            else if(2 ==  ((DbQueryMsg*)aMsgPtr)->m_DbQueryType)
            {
               CMUpdateMNRF *l_Msg = (CMUpdateMNRF *)aMsgPtr;
               if(CM_DB_SUCCESS == l_Msg->m_EdbResult)
               {
                  LLOG(0,0,"DBRES: MNRF positive DB Response received");
               }
               else
               {
                  m_ErrCode = (EMapErrorCode)l_Msg->m_errCode;
                  CLOG(0,0,"DB Failure .. Error Code Value |%d|",l_Msg->m_errCode);
                  return handleError(); 
               }
            }
            else
            {
               ELOG(0,0,"Unknown DB message");
            }
         }
         break;

      default:
         CLOG(0,0,"Unknown message received");
         break;
   }
   return true;
}

bool CtxtSendRoutingInfo :: sendSRIResMsrnFtn()
{
   switch(m_MapVer)
   {
      case MAP_V3:
         {
            DLOG(0,0,"In sendSRIResMsrnFtn-V3");

            DECLARE(OMAP3_SendRoutingInfoRes,l_tempSriResMsrnFtn,3,"OMAP3_SendRoutingInfoRes",resetStruct);

            char l_msrnFtn[21];
            memset(l_msrnFtn,'\0',sizeof(l_msrnFtn));
            if(mp_sriSubData->m_fwdInfo.m_FtnLen > 1)
            {
               snprintf(l_msrnFtn,sizeof(l_msrnFtn),"%s",mp_sriSubData->m_fwdInfo.m_Ftn);
            }
            else if(mp_sriSubData->m_fwdInfo.m_DefFtnLen > 1)
            {
               snprintf(l_msrnFtn,sizeof(l_msrnFtn),"%s",mp_sriSubData->m_fwdInfo.m_DefFtn);
            }
            else
            {
               CLOG(0,0,"SriResMsrnFtn: roamingnumber(ftn) length is less than zero so closing the sri dialogue");
               MapCloseReq l_closeReq(m_InitDlgId);
               g_sc.sendMsg(this, &l_closeReq);
               return true;
            }
            TLOG(0,0,"MsrnFtn:%s",l_msrnFtn);
            m_tdr.setString(TDR_INDEX_CM_SRI_MSRN,(s8*)l_msrnFtn);

            l_tempSriResMsrnFtn->bit_mask |= OMAP3_SendRoutingInfoRes_imsi_present;

            TLOG(0,0,"SriResMsrnFtn: imsi + roamingnumber + suppCphVmsc - SRIImsi:|%s|",m_SriImsi); 
            l_tempSriResMsrnFtn->imsi.length = StringToBCD(l_tempSriResMsrnFtn->imsi.value,(u8*)m_SriImsi,(s32)strlen((char*)m_SriImsi));

            l_tempSriResMsrnFtn->bit_mask |= OMAP3_extendedRoutingInfo_present;
            l_tempSriResMsrnFtn->extendedRoutingInfo.choice = OMAP3_routingInfo_chosen;
            l_tempSriResMsrnFtn->extendedRoutingInfo.u.routingInfo.choice = OMAP3_roamingNumber_chosen;

            l_tempSriResMsrnFtn->extendedRoutingInfo.u.routingInfo.u.roamingNumber.value[0] = 0xa1;
            l_tempSriResMsrnFtn->extendedRoutingInfo.u.routingInfo.u.roamingNumber.length = StringToBCD(&l_tempSriResMsrnFtn->extendedRoutingInfo.u.routingInfo.u.roamingNumber.value[1],(u8*)&l_msrnFtn[2],strlen(l_msrnFtn+2));
            l_tempSriResMsrnFtn->extendedRoutingInfo.u.routingInfo.u.roamingNumber.length++;
            m_Utility.getSuppCamelPhsVmsc(l_tempSriResMsrnFtn,mp_sriSubData);

            l_tempSriResMsrnFtn->bit_mask |= OMAP3_SendRoutingInfoRes_numberPortabilityStatus_present;
            l_tempSriResMsrnFtn->numberPortabilityStatus = OMAP3_ownNumberPortedOut;
            return m_Utility.sendSRIRESULTLAST(this,m_InitDlgId,MAP_OP_CODE_sendRoutingInfo,MAP_V3,l_tempSriResMsrnFtn);
         }
         break;
      case MAP_V2:
         {
            DLOG(0,0,"In SendSriResMsrnFtn-V2");

            DECLARE(OMAP2_SendRoutingInfoRes,l_tempSriResMsrnFtn,2,"OMAP2_SendRoutingInfoRes",resetStruct);

            char l_msrnFtn[21];
            memset(l_msrnFtn,'\0',sizeof(l_msrnFtn));
            if(mp_sriSubData->m_fwdInfo.m_FtnLen > 1)
            {
               snprintf(l_msrnFtn,sizeof(l_msrnFtn),"%s",mp_sriSubData->m_fwdInfo.m_Ftn);
            }
            else if(mp_sriSubData->m_fwdInfo.m_DefFtnLen > 1)
            {
               snprintf(l_msrnFtn,sizeof(l_msrnFtn),"%s",mp_sriSubData->m_fwdInfo.m_DefFtn);
            }
            else
            {
               CLOG(0,0,"SriResMsrnFtn: roamingnumber(ftn) length is less than zero so closing the sri dialogue");
               MapCloseReq l_closeReq(m_InitDlgId);
               g_sc.sendMsg(this, &l_closeReq);
               return true;
            }
            TLOG(0,0,"MsrnFtn:%s",l_msrnFtn);
            m_tdr.setString(TDR_INDEX_CM_SRI_MSRN,(s8*)l_msrnFtn);

            TLOG(0,0,"V2:SriResMsrnFtn: imsi + roamingnumber + suppCphVmsc - SRIImsi:|%s|",m_SriImsi); 
            l_tempSriResMsrnFtn->imsi.length = StringToBCD(l_tempSriResMsrnFtn->imsi.value,(u8*)m_SriImsi,(s32)strlen((char*)m_SriImsi));

            l_tempSriResMsrnFtn->routingInfo.choice = OMAP2_RoutingInfo_roamingNumber_chosen;

            l_tempSriResMsrnFtn->routingInfo.u.roamingNumber.value[0] = 0xa1;
            l_tempSriResMsrnFtn->routingInfo.u.roamingNumber.length = StringToBCD(&l_tempSriResMsrnFtn->routingInfo.u.roamingNumber.value[1],(u8*)&l_msrnFtn[2],strlen(l_msrnFtn+2));
            l_tempSriResMsrnFtn->routingInfo.u.roamingNumber.length++;
            return m_Utility.sendSRIRESULTLAST(this,m_InitDlgId,MAP_OP_CODE_sendRoutingInfo,MAP_V2,l_tempSriResMsrnFtn);
         }
         break;
      case MAP_V1:
         {
            DLOG(0,0,"In SendSriResMsrnFtn-V1");

            DECLARE(OMAP1_SendRoutingInformationRes,l_tempSriResMsrnFtn,1,"OMAP1_SendRoutingInformationRes",resetStruct);

            char l_msrnFtn[21];
            memset(l_msrnFtn,'\0',sizeof(l_msrnFtn));
            if(mp_sriSubData->m_fwdInfo.m_FtnLen > 1)
            {
               snprintf(l_msrnFtn,sizeof(l_msrnFtn),"%s",mp_sriSubData->m_fwdInfo.m_Ftn);
            }
            else if(mp_sriSubData->m_fwdInfo.m_DefFtnLen > 1)
            {
               snprintf(l_msrnFtn,sizeof(l_msrnFtn),"%s",mp_sriSubData->m_fwdInfo.m_DefFtn);
            }
            else
            {
               CLOG(0,0,"SriResMsrnFtn: roamingnumber(ftn) length is less than zero so closing the sri dialogue");
               MapCloseReq l_closeReq(m_InitDlgId);
               g_sc.sendMsg(this, &l_closeReq);
               return true;
            }
            TLOG(0,0,"MsrnFtn:%s",l_msrnFtn);
            m_tdr.setString(TDR_INDEX_CM_SRI_MSRN,(s8*)l_msrnFtn);

            TLOG(0,0,"V1:SriResMsrnFtn: imsi + roamingnumber + suppCphVmsc - SRIImsi:|%s|",m_SriImsi); 
            l_tempSriResMsrnFtn->imsi.length = StringToBCD(l_tempSriResMsrnFtn->imsi.value,(u8*)m_SriImsi,(s32)strlen((char*)m_SriImsi));

            l_tempSriResMsrnFtn->routingInfo.choice = OMAP1_routingInfo_roamingNumber_chosen;

            l_tempSriResMsrnFtn->routingInfo.u.roamingNumber.value[0] = 0xa1;
            l_tempSriResMsrnFtn->routingInfo.u.roamingNumber.length = StringToBCD(&l_tempSriResMsrnFtn->routingInfo.u.roamingNumber.value[1],(u8*)&l_msrnFtn[2],strlen(l_msrnFtn+2));
            l_tempSriResMsrnFtn->routingInfo.u.roamingNumber.length++;
            return m_Utility.sendSRIRESULTLAST(this,m_InitDlgId,MAP_OP_CODE_sendRoutingInfo,MAP_V1,l_tempSriResMsrnFtn);
         }
         break;
      default:
         {
            LLOG(0,0,"Unknown MapVersion received");
         }
         break;
   }
   return true;
}

bool CtxtSendRoutingInfo :: sendSRIResSSList()
{
   DLOG(0,0,"In sendSRIResSSList");
   DECLARE(OMAP3_SendRoutingInfoRes,l_tempSRIResSSList,3,"OMAP3_SendRoutingInfoRes",resetStruct);
   l_tempSRIResSSList->bit_mask |= OMAP3_SendRoutingInfoRes_imsi_present;

   LLOG(0,0," Collect Call Blocked for subscriber sending 249 SS Code IN SRI RES ");
   LLOG(0,0,"sendSRIResSSList: imsi + SSList - SriImsi:|%s|",m_SriImsi); 
   l_tempSRIResSSList->imsi.length = StringToBCD(l_tempSRIResSSList->imsi.value,(u8*)m_SriImsi,(s32)strlen((char*)m_SriImsi));
   l_tempSRIResSSList->bit_mask |= OMAP3_SendRoutingInfoRes_ss_List_present;
   l_tempSRIResSSList->ss_List.count=1;
   l_tempSRIResSSList->ss_List.value[0].length=1;
   l_tempSRIResSSList->ss_List.value[0].value[0]=249;

   m_Utility.getSuppCamelPhsVmsc(l_tempSRIResSSList,mp_sriSubData);
   return m_Utility.sendSRIRESULTLAST(this,m_InitDlgId,MAP_OP_CODE_sendRoutingInfo,MAP_V3,l_tempSRIResSSList);
}

bool CtxtSendRoutingInfo :: sendSRIUDRResPSIAck(IMAP3_ProvideSubscriberInfoRes *aPSIRes)
{
   DLOG(0,0,"In sendSRIUDRResPSIAck");
   DECLARE(OMAP3_SendRoutingInfoRes,l_tempSRIResPSIAck,3,"OMAP3_SendRoutingInfoRes",resetStruct);

   l_tempSRIResPSIAck->bit_mask |= OMAP3_SendRoutingInfoRes_imsi_present;

   TLOG(0,0,"SriResPsiNack: SRIImsi:|%s|",m_SriImsi); 
   l_tempSRIResPSIAck->imsi.length = StringToBCD(l_tempSRIResPSIAck->imsi.value,(u8*)m_SriImsi,(s32)strlen((s8*)m_SriImsi));

   fillPSIinSRIRes(l_tempSRIResPSIAck,aPSIRes);
   return m_Utility.sendSRIRESULTLAST(this,m_InitDlgId,MAP_OP_CODE_sendRoutingInfo,MAP_V3,l_tempSRIResPSIAck);
}
