#include <IMAP1.h>
#include <IMAP2.h>
#include <OMAP1.h>
#include <OMAP2.h>
#include <stdio.h>
#include <Logger.h>
#include <DataUnion.h>
#include <Utilities.h>
#include <MapMessages.h>
#include <DbActiveObject.h>
#include "CMSriForLcs.h"
#include <ServiceCoordinator.h>
#include <SnmpInterface.h>

/**************************************************************************************************
  Function Name      : CtxtSriForLCS
Author               :
InParams             : void 
OutParam /return val : void
Description          : Constructor
 ****************************************************************************************************/

extern int g_CMEntityAuthFailTrap;

CtxtSriForLCS :: CtxtSriForLCS()
{
   DLOG(0,0,"CtxtSriForLCS :cons:");

   m_ErrCode = (EMapErrorCode)0;
   m_InitDlgId = 0;

   memset(m_MlcNumber,'\0',CM_GMLCLEN);
   m_MlcNumLen = 0;
   m_targetMStype = 0;
   memset(m_TargetMS,'\0',CM_MSISDNLEN);
   m_TargetMSlen = 0;
   mp_sriLcs = NULL;
}   



/**************************************************************************************************
  Function Name      : CtxtSriForLCS
Author               :
InParams             : void 
OutParam /return val : void
Description          : Destructor
 ****************************************************************************************************/


CtxtSriForLCS :: ~CtxtSriForLCS()
{
   DLOG(0,0,"CtxtSriForLCS :des:");
   if( NULL != mp_sriLcs )
   {
      delete mp_sriLcs;
      mp_sriLcs = NULL;
   }
}

bool CtxtSriForLCS :: handleSriForLCS(Msg *aMsgPtr, u32 aDlgId, EMapVersion aMapVer)
{
   m_InitDlgId = aDlgId;
   m_MapVer = aMapVer;

   DLOG(0,0,"Initiating dialogueId-|%d| mapversion-|%d|",m_InitDlgId,m_MapVer);

   switch(m_MapVer)
   {
      case MAP_V3:
         {
            IMAP3_RoutingInfoForLCS_Arg *l_temp = (IMAP3_RoutingInfoForLCS_Arg*)(((MapSpecificMsg*)aMsgPtr)->m_structBuffer);
            if(CM_ERROR == checkSriForLCS((void*)l_temp))
            {
               ELOG(0,0,"checkSriForLCS: failed sending maperror");
               return handleError(); 
            }
            handleDbQuery();
         }
         break;
      default:
         {
            ELOG(0,0,"invalid mapversion");
            m_ErrCode = MAP_ERROR_systemFailure;
            return handleError();
         }
   }
   return true;
}

bool CtxtSriForLCS :: handleError()
{
   DLOG(0,0,"In HandleError");
   switch(m_ErrCode)
   {
      case MAP_ERROR_systemFailure:
         {
            CLOG(0,0,"sending mapusererror MAP_ERROR_systemFailure on dlgId |%d|",m_InitDlgId);
            m_Utility.sendMapUserError(this,m_ErrCode,m_InitDlgId,m_MapVer,NULL);
         }
         break;
      case MAP_ERROR_unexpectedData:
         {
            CLOG(0,0,"sending mapusererror MAP_ERROR_unexpectedData on dlgId |%d|",m_InitDlgId);
            m_Utility.sendMapUserError(this,m_ErrCode,m_InitDlgId,m_MapVer,NULL);
         }
         break;
      case MAP_ERROR_dataMissing:
         {
            CLOG(0,0,"sending mapusererror MAP_ERROR_dataMissing on dlgId |%d|",m_InitDlgId);
            m_Utility.sendMapUserError(this,m_ErrCode,m_InitDlgId,m_MapVer,NULL);
         }
         break;
      case MAP_ERROR_unknownSubscriber:
         {
            CLOG(0,0,"sending mapusererror MAP_ERROR_unknownSubscriber on dlgId |%d|",m_InitDlgId);
            m_Utility.sendMapUserError(this,m_ErrCode,m_InitDlgId,m_MapVer,NULL);
         }
         break;
      case MAP_ERROR_facilityNotSup:
         {
            CLOG(0,0,"sending mapusererror MAP_ERROR_facilityNotSup on dlgId |%d|",m_InitDlgId);
            m_Utility.sendMapUserError(this,m_ErrCode,m_InitDlgId,m_MapVer,NULL);
         }
         break;
      case MAP_ERROR_absentSubscriber:
         {
            CLOG(0,0,"sending mapusererror MAP_ERROR_absentSubscriber on dlgId |%d|",m_InitDlgId);
            m_Utility.sendMapUserError(this,m_ErrCode,m_InitDlgId,m_MapVer,NULL);
         }
         break;

      case MAP_ERROR_unauthorizedRequestingNetwork:
         {
            CLOG(0,0,"sending mapusererror MAP_ERROR_unauthorizedRequestingNetwork on dlgId |%d|",m_InitDlgId);
            m_Utility.sendMapUserError(this,m_ErrCode,m_InitDlgId,m_MapVer,NULL);
         }
         break;
      default:
         {
            CLOG(0,0,"Default Case of HandleError: sending mapusererror MAP_ERROR_systemFailure on dlgId |%d|",m_InitDlgId);
            m_ErrCode = MAP_ERROR_systemFailure;
            m_Utility.sendMapUserError(this,m_ErrCode,m_InitDlgId,m_MapVer,NULL);
         }
         break;
   }
   m_tdr.setInteger(TDR_INDEX_ERR_CODE,m_ErrCode); 
   return true;
}

bool CtxtSriForLCS :: sendSriForLCSResp()
{
   DECLARE(OMAP3_RoutingInfoForLCS_Res,l_tempSriLcsRes,3,"OMAP3_RoutingInfoForLCS_Res",resetStruct);

   DLOG(0,0,"Sending SRIforLCSresponse");
   if(1 == m_targetMStype) // LcsReq has TargetMS IMSI so send MSISDN in LcsRes
   {
      l_tempSriLcsRes->targetMS.choice = OMAP3_SubscriberIdentity_msisdn_chosen;
      l_tempSriLcsRes->targetMS.u.msisdn.value[0] = 0x91; 
      l_tempSriLcsRes->targetMS.u.msisdn.length = StringToBCD(&l_tempSriLcsRes->targetMS.u.msisdn.value[1],(u8*)mp_sriLcs->m_ActiveMsisdn,strlen((s8*)mp_sriLcs->m_ActiveMsisdn));
      l_tempSriLcsRes->targetMS.u.msisdn.length++;
      LLOG(0,0,"SRILCSRES: TargetMS MSISDN:|%s|",mp_sriLcs->m_ActiveMsisdn);
   }
   else // LcsReq has TargetMS MSISDN so send IMSI in LcsRes
   {
      l_tempSriLcsRes->targetMS.choice = OMAP3_SubscriberIdentity_imsi_chosen;
      l_tempSriLcsRes->targetMS.u.imsi.length = StringToBCD(l_tempSriLcsRes->targetMS.u.imsi.value,(u8*)mp_sriLcs->m_ActiveImsi,strlen((s8*)mp_sriLcs->m_ActiveImsi));
      LLOG(0,0,"SRILCSRES: TargetMS IMSI:|%s|",mp_sriLcs->m_ActiveImsi);
   }

   if(strlen(mp_sriLcs->m_HgmlcAddr) > 1)
   {
      if(ValidateIpv4(mp_sriLcs->m_HgmlcAddr))
      {
         l_tempSriLcsRes->bit_mask |= OMAP3_RoutingInfoForLCS_Res_h_gmlc_Address_present;
         l_tempSriLcsRes->h_gmlc_Address.length=5;
         l_tempSriLcsRes->h_gmlc_Address.value[0]=0x04;
         convertIPV4toHex(mp_sriLcs->m_HgmlcAddr,&l_tempSriLcsRes->h_gmlc_Address.value[1]);
         LLOG(0,0,"SRILCSRES: HGMLCADDR:|%s|",mp_sriLcs->m_HgmlcAddr);
      }
      else
      {
         LLOG(0,0,"SRILCSRES: ValidateIPv4 Failed for HGMLCADDR sending SystemFailure");
         m_ErrCode = MAP_ERROR_systemFailure;
         return handleError();
      }
   }

   if(strlen(mp_sriLcs->m_PprAddr) > 1)
   {
      if(ValidateIpv4(mp_sriLcs->m_PprAddr))
      {
         l_tempSriLcsRes->bit_mask |= OMAP3_ppr_Address_present;
         l_tempSriLcsRes->ppr_Address.length=5;
         l_tempSriLcsRes->ppr_Address.value[0]=0x04;
         convertIPV4toHex(mp_sriLcs->m_PprAddr,&l_tempSriLcsRes->ppr_Address.value[1]);
         LLOG(0,0,"SRILCSRES: PPR-ADDR:|%s|",mp_sriLcs->m_PprAddr);
      }
      else
      {
         LLOG(0,0,"SRILCSRES: ValidateIPv4 Failed for PPR-ADDR");
      }
   }

   if(mp_sriLcs->m_LmsiLen > 0)
   {
      if(mp_sriLcs->m_LmsiLen != 4)
      {
         //ERROR, length is 8 only (in asn structre)
         CLOG(0,0,"LMSI is not 8 characters");
      }
      else
      {
         l_tempSriLcsRes->lcsLocationInfo.bit_mask |= OMAP3_LCSLocationInfo_lmsi_present;
         l_tempSriLcsRes->lcsLocationInfo.lmsi.length = 4;
         memcpy(l_tempSriLcsRes->lcsLocationInfo.lmsi.value,mp_sriLcs->m_Lmsi,4);
         LLOG_HEX(0,0,"SRILCSRES: LMSI", (s8*)mp_sriLcs->m_Lmsi,mp_sriLcs->m_LmsiLen);
      }
   }

   if((strlen(mp_sriLcs->m_SgsnNumber) > 1) && (strlen(mp_sriLcs->m_MscNumber) > 1)) // Both Gsm-Gprs
   {
      l_tempSriLcsRes->lcsLocationInfo.networkNode_Number.value[0] = 0x91; 
      l_tempSriLcsRes->lcsLocationInfo.networkNode_Number.length = StringToBCD(&l_tempSriLcsRes->lcsLocationInfo.networkNode_Number.value[1],(u8*)mp_sriLcs->m_MscNumber,strlen((s8*)mp_sriLcs->m_MscNumber));
      l_tempSriLcsRes->lcsLocationInfo.networkNode_Number.length++;


      l_tempSriLcsRes->lcsLocationInfo.bit_mask |= OMAP3_LCSLocationInfo_additional_Number_present;
      l_tempSriLcsRes->lcsLocationInfo.additional_Number.choice = OMAP3_sgsn_Number_chosen;
      l_tempSriLcsRes->lcsLocationInfo.additional_Number.u.sgsn_Number.value[0] = 0x91; 
      l_tempSriLcsRes->lcsLocationInfo.additional_Number.u.sgsn_Number.length = StringToBCD(&l_tempSriLcsRes->lcsLocationInfo.additional_Number.u.sgsn_Number.value[1],(u8*)mp_sriLcs->m_SgsnNumber,strlen((s8*)mp_sriLcs->m_SgsnNumber));
      l_tempSriLcsRes->lcsLocationInfo.additional_Number.u.sgsn_Number.length++;

      LLOG(0,0,"SRILCSRES: Both Gsm-Gprs subscriber MscNum is NetworkNodeNum:|%s| SgsnNum is AdditionalNum:|%s|",mp_sriLcs->m_MscNumber,mp_sriLcs->m_SgsnNumber);

      if(strlen(mp_sriLcs->m_CS_VgmlcAddr) > 1)
      {
         if(ValidateIpv4(mp_sriLcs->m_CS_VgmlcAddr))
         {
            l_tempSriLcsRes->bit_mask |= OMAP3_RoutingInfoForLCS_Res_v_gmlc_Address_present;
            l_tempSriLcsRes->v_gmlc_Address.length=5;
            l_tempSriLcsRes->v_gmlc_Address.value[0]=0x04;
            convertIPV4toHex(mp_sriLcs->m_CS_VgmlcAddr,&l_tempSriLcsRes->v_gmlc_Address.value[1]);
            LLOG(0,0,"SRILCSRES: CS-VGMLCADDR:|%s|",mp_sriLcs->m_CS_VgmlcAddr);
         }
         else
         {
            LLOG(0,0,"SRILCSRES: ValidateIPv4 Failed for CS-VGMLCADDR sending SystemFailure");
            m_ErrCode = MAP_ERROR_systemFailure;
            return handleError();
         }
      }

      if(strlen(mp_sriLcs->m_PS_VgmlcAddr) > 1)
      {
         if(ValidateIpv4(mp_sriLcs->m_PS_VgmlcAddr))
         {
            l_tempSriLcsRes->bit_mask |= OMAP3_additional_v_gmlc_Address_present;
            l_tempSriLcsRes->additional_v_gmlc_Address.length=5;
            l_tempSriLcsRes->additional_v_gmlc_Address.value[0]=0x04;
            convertIPV4toHex(mp_sriLcs->m_PS_VgmlcAddr,&l_tempSriLcsRes->additional_v_gmlc_Address.value[1]);
            LLOG(0,0,"SRILCSRES: ADD-VGMLCADDR:|%s|",mp_sriLcs->m_PS_VgmlcAddr);
         }
         else
         {
            LLOG(0,0,"SRILCSRES: ValidateIPv4 Failed for ADD-VGMLCADDR sending SystemFailure");
            m_ErrCode = MAP_ERROR_systemFailure;
            return handleError();
         }
      }
      u8 l_CS_LCScs = 0x00;
      l_CS_LCScs = mp_sriLcs->m_suppLCScapSets;
      DLOG(0,0,"SriForLCSres:  Supported LCS capabilty sets |%x|",l_CS_LCScs);
      if((l_CS_LCScs & 0x0f) != 0)
      {
         if(0 == g_CMConfigReaderObj->m_disableLcsCapb)
         {
            l_tempSriLcsRes->lcsLocationInfo.bit_mask |= OMAP3_LCSLocationInfo_supportedLCS_CapabilitySets_present;
         }
         if(l_CS_LCScs & 0x01)
            l_tempSriLcsRes->lcsLocationInfo.supportedLCS_CapabilitySets.value[0] |= 0x80; 
         if(l_CS_LCScs & 0x02)
            l_tempSriLcsRes->lcsLocationInfo.supportedLCS_CapabilitySets.value[0] |= 0x40; 
         if(l_CS_LCScs & 0x04)
            l_tempSriLcsRes->lcsLocationInfo.supportedLCS_CapabilitySets.value[0] |= 0x20;
         if(l_CS_LCScs & 0x08)
            l_tempSriLcsRes->lcsLocationInfo.supportedLCS_CapabilitySets.value[0] |= 0x10;
         l_tempSriLcsRes->lcsLocationInfo.supportedLCS_CapabilitySets.length = getNumberOfSignificantBitsForAByte(l_tempSriLcsRes->lcsLocationInfo.supportedLCS_CapabilitySets.value[0]);
      }
      u8 l_PS_AddLCScs = 0x00;
      l_PS_AddLCScs = mp_sriLcs->m_suppPSLCScapSets;
      DLOG(0,0,"SriForLCSres:  Supported Additional LCS capabilty sets |%x|",l_PS_AddLCScs);
      if((l_PS_AddLCScs & 0x0f) != 0)
      {
         if(0 == g_CMConfigReaderObj->m_disableLcsCapb)
         {
            l_tempSriLcsRes->lcsLocationInfo.bit_mask |= OMAP3_additional_LCS_CapabilitySets_present;
         }
         if(l_PS_AddLCScs & 0x01)
            l_tempSriLcsRes->lcsLocationInfo.additional_LCS_CapabilitySets.value[0] |= 0x80; 
         if(l_PS_AddLCScs & 0x02)
            l_tempSriLcsRes->lcsLocationInfo.additional_LCS_CapabilitySets.value[0] |= 0x40; 
         if(l_PS_AddLCScs & 0x04)
            l_tempSriLcsRes->lcsLocationInfo.additional_LCS_CapabilitySets.value[0] |= 0x20;
         if(l_PS_AddLCScs & 0x08)
            l_tempSriLcsRes->lcsLocationInfo.additional_LCS_CapabilitySets.value[0] |= 0x10;
         l_tempSriLcsRes->lcsLocationInfo.additional_LCS_CapabilitySets.length = getNumberOfSignificantBitsForAByte(l_tempSriLcsRes->lcsLocationInfo.additional_LCS_CapabilitySets.value[0]);
      }
   }
   else if(strlen(mp_sriLcs->m_SgsnNumber) > 1) // Only Gprs
   {
      l_tempSriLcsRes->lcsLocationInfo.bit_mask |= OMAP3_LCSLocationInfo_gprsNodeIndicator_present;
      l_tempSriLcsRes->lcsLocationInfo.gprsNodeIndicator = true;
      l_tempSriLcsRes->lcsLocationInfo.networkNode_Number.value[0] = 0x91; 
      l_tempSriLcsRes->lcsLocationInfo.networkNode_Number.length = StringToBCD(&l_tempSriLcsRes->lcsLocationInfo.networkNode_Number.value[1],(u8*)mp_sriLcs->m_SgsnNumber,strlen((s8*)mp_sriLcs->m_SgsnNumber));
      l_tempSriLcsRes->lcsLocationInfo.networkNode_Number.length++;
      LLOG(0,0,"SRILCSRES: Only Gprs subscriber SgsnNum is NetworkNodeNum:|%s|",mp_sriLcs->m_SgsnNumber);

      if(strlen(mp_sriLcs->m_PS_VgmlcAddr) > 1)
      {
         if(ValidateIpv4(mp_sriLcs->m_PS_VgmlcAddr))
         {
            l_tempSriLcsRes->bit_mask |= OMAP3_RoutingInfoForLCS_Res_v_gmlc_Address_present;
            l_tempSriLcsRes->v_gmlc_Address.length=5;
            l_tempSriLcsRes->v_gmlc_Address.value[0]=0x04;
            convertIPV4toHex(mp_sriLcs->m_PS_VgmlcAddr,&l_tempSriLcsRes->v_gmlc_Address.value[1]);
            LLOG(0,0,"SRILCSRES: PS-VGMLCADDR:|%s|",mp_sriLcs->m_PS_VgmlcAddr);
         }
         else
         {
            LLOG(0,0,"SRILCSRES: ValidateIPv4 Failed for PS-VGMLCADDR sending SystemFailure");
            m_ErrCode = MAP_ERROR_systemFailure;
            return handleError();
         }
      }
      u8 l_CS_LCScs = 0x00;
      l_CS_LCScs = mp_sriLcs->m_suppPSLCScapSets;
      DLOG(0,0,"SriForLCSres:  Supported PS-LCS capabilty sets |%x|",l_CS_LCScs);
      if((l_CS_LCScs & 0x0f) != 0)
      {
         if(0 == g_CMConfigReaderObj->m_disableLcsCapb)
         {
            l_tempSriLcsRes->lcsLocationInfo.bit_mask |= OMAP3_LCSLocationInfo_supportedLCS_CapabilitySets_present;
         }
         if(l_CS_LCScs & 0x01)
            l_tempSriLcsRes->lcsLocationInfo.supportedLCS_CapabilitySets.value[0] |= 0x80; 
         if(l_CS_LCScs & 0x02)
            l_tempSriLcsRes->lcsLocationInfo.supportedLCS_CapabilitySets.value[0] |= 0x40; 
         if(l_CS_LCScs & 0x04)
            l_tempSriLcsRes->lcsLocationInfo.supportedLCS_CapabilitySets.value[0] |= 0x20;
         if(l_CS_LCScs & 0x08)
            l_tempSriLcsRes->lcsLocationInfo.supportedLCS_CapabilitySets.value[0] |= 0x10;
         l_tempSriLcsRes->lcsLocationInfo.supportedLCS_CapabilitySets.length = getNumberOfSignificantBitsForAByte(l_tempSriLcsRes->lcsLocationInfo.supportedLCS_CapabilitySets.value[0]);
      }
   }
   else // Only Gsm
   {
      l_tempSriLcsRes->lcsLocationInfo.networkNode_Number.value[0] = 0x91; 
      l_tempSriLcsRes->lcsLocationInfo.networkNode_Number.length = StringToBCD(&l_tempSriLcsRes->lcsLocationInfo.networkNode_Number.value[1],(u8*)mp_sriLcs->m_MscNumber,strlen((s8*)mp_sriLcs->m_MscNumber));
      l_tempSriLcsRes->lcsLocationInfo.networkNode_Number.length++;
      LLOG(0,0,"SRILCSRES: Only Gsm subscriber MscNum is NetworkNodeNum:|%s|",mp_sriLcs->m_MscNumber);

      if(strlen(mp_sriLcs->m_CS_VgmlcAddr) > 1)
      {
         if(ValidateIpv4(mp_sriLcs->m_CS_VgmlcAddr))
         {
            l_tempSriLcsRes->bit_mask |= OMAP3_RoutingInfoForLCS_Res_v_gmlc_Address_present;
            l_tempSriLcsRes->v_gmlc_Address.length=5;
            l_tempSriLcsRes->v_gmlc_Address.value[0]=0x04;
            convertIPV4toHex(mp_sriLcs->m_CS_VgmlcAddr,&l_tempSriLcsRes->v_gmlc_Address.value[1]);
            LLOG(0,0,"SRILCSRES: VGMLCADDR:|%s|",mp_sriLcs->m_CS_VgmlcAddr);
         }
         else
         {
            LLOG(0,0,"SRILCSRES: ValidateIPv4 Failed for VGMLCADDR sending SystemFailure");
            m_ErrCode = MAP_ERROR_systemFailure;
            return handleError();
         }
      }
      u8 l_CS_LCScs = 0x00;
      l_CS_LCScs = mp_sriLcs->m_suppLCScapSets;
      DLOG(0,0,"SriForLCSres:  Supported LCS capabilty sets |%x|",l_CS_LCScs);
      if((l_CS_LCScs & 0x0f) != 0)
      {
         if(0 == g_CMConfigReaderObj->m_disableLcsCapb)
         {
            l_tempSriLcsRes->lcsLocationInfo.bit_mask |= OMAP3_LCSLocationInfo_supportedLCS_CapabilitySets_present;
         }
         if(l_CS_LCScs & 0x01)
            l_tempSriLcsRes->lcsLocationInfo.supportedLCS_CapabilitySets.value[0] |= 0x80; 
         if(l_CS_LCScs & 0x02)
            l_tempSriLcsRes->lcsLocationInfo.supportedLCS_CapabilitySets.value[0] |= 0x40; 
         if(l_CS_LCScs & 0x04)
            l_tempSriLcsRes->lcsLocationInfo.supportedLCS_CapabilitySets.value[0] |= 0x20;
         if(l_CS_LCScs & 0x08)
            l_tempSriLcsRes->lcsLocationInfo.supportedLCS_CapabilitySets.value[0] |= 0x10;
         l_tempSriLcsRes->lcsLocationInfo.supportedLCS_CapabilitySets.length = getNumberOfSignificantBitsForAByte(l_tempSriLcsRes->lcsLocationInfo.supportedLCS_CapabilitySets.value[0]);
      }
   }

   MapSpecificResult l_resultL(m_InitDlgId,MAP_OP_CODE_sendRoutingInfoForLCS,m_MapVer);
   l_resultL.m_structBuffer = (void*)l_tempSriLcsRes;
   g_sc.sendMsg(this, &l_resultL);

   DLOG(0,0,"Closing the SriForLcsRes dialogue");
   MapCloseReq l_closeReq(m_InitDlgId);
   g_sc.sendMsg(this, &l_closeReq);
   return true;
}

EResult CtxtSriForLCS :: checkSriForLCS(void *aSriForLCSReq)
{
   DLOG(0,0,"In checkSriForLCS");
   IMAP3_RoutingInfoForLCS_Arg *p_SriForLcs = (IMAP3_RoutingInfoForLCS_Arg*)aSriForLCSReq; 
   if(p_SriForLcs->mlcNumber.length <= 1)
   {
      CLOG(0,0,"Mandatory Param MLC number missing or corrupt");
      m_ErrCode = MAP_ERROR_dataMissing;
      return CM_ERROR;
   }
   else
   {
      // assuming we get p_SriForLcs->m_MlcNumber.value[0]=0x91 so extracting m_MlcNumber from index[1]

      BCDToString((u8*)m_MlcNumber,&p_SriForLcs->mlcNumber.value[1],p_SriForLcs->mlcNumber.length-1);
      LLOG(0,0,"MLC Number present - value |%s|",m_MlcNumber);

      m_MlcNumLen = strlen((s8*)m_MlcNumber);

   }

   s8 tempMsisdn[CM_MSISDNLEN];   //5053
   memset(tempMsisdn,'\0',sizeof(tempMsisdn));

   if(OMAP3_SubscriberIdentity_imsi_chosen == p_SriForLcs->targetMS.choice) 
   {
      BCDToString((u8*)m_TargetMS,p_SriForLcs->targetMS.u.imsi.value,p_SriForLcs->targetMS.u.imsi.length);
      LLOG(0,0,"TargetMS IMSI present - value |%s|",m_TargetMS);
      m_TargetMSlen =  strlen((s8*)m_TargetMS);
      m_tdr.setChar(TDR_INDEX_REQUEST_TYPE,'I'); 
      m_tdr.setString(TDR_INDEX_REQUEST_IMSI,(s8*)m_TargetMS);
      setTraceImsi((s8*)m_TargetMS);
      m_targetMStype = 1; // Imsi
   }
   else if(OMAP3_SubscriberIdentity_msisdn_chosen == p_SriForLcs->targetMS.choice)
   {
      BCDToString((u8*)tempMsisdn,&p_SriForLcs->targetMS.u.msisdn.value[1],p_SriForLcs->targetMS.u.msisdn.length-1);
      LLOG(0,0,"TargetMS MSISDN present - value |%s|",tempMsisdn);
      if(p_SriForLcs->targetMS.u.msisdn.value[0] == 0x91)
      {
         TLOG(0,0,"Dialing pattern international SRILCS - Nai-Npi:[%x]",p_SriForLcs->targetMS.u.msisdn.value[0]);
         s8* l_msisdn = NULL;
         l_msisdn = g_spdPtr->getMsisdnValue(tempMsisdn);
         strcpy((s8*)m_TargetMS,l_msisdn);
         m_TargetMSlen =  strlen((s8*)m_TargetMS);
        
      }
      else
      {
         TLOG(0,0,"Dialing pattern not international SRILCS - Nai-Npi:[%x]",p_SriForLcs->targetMS.u.msisdn.value[0]);
         strcpy((s8*)m_TargetMS,tempMsisdn);
         DLOG(0,0,"TargetMS is %s", (s8*)m_TargetMS);
      }
      setTraceMsisdn((s8*)m_TargetMS);
      m_tdr.setChar(TDR_INDEX_REQUEST_TYPE,'M'); 
      m_tdr.setString(TDR_INDEX_REQUEST_MSISDN,(s8*)m_TargetMS);
      m_targetMStype = 2; // Msisdn
   }
   else
   {
      CLOG(0,0,"Mandatory Param TargeMS missing or corrupt");
      m_ErrCode = MAP_ERROR_dataMissing;
      return CM_ERROR;
   }

   return CM_CONTINUE;
}

bool CtxtSriForLCS :: handleDbQuery()
{
   SriLCSdata *l_Lcs = NULL;
   DLOG(0,0,"In handleDbQuery");
   l_Lcs = new SriLCSdata();
   if(l_Lcs != NULL)
   {
      // PASSING INPUT PARAMS TARGETMSTYPE TARGETMS MLCNUMBER 
      l_Lcs->m_targetMStype = m_targetMStype;
      strcpy((s8*)l_Lcs->m_targetMS,(s8*)m_TargetMS);
      strcpy((s8*)l_Lcs->m_mlcNum,(s8*)m_MlcNumber);
      LLOG(0,0,"DBIN-SRI-LCS: TargetMStype-|%d| TargetMS-|%s| MlcNumber-|%s|",l_Lcs->m_targetMStype,l_Lcs->m_targetMS,l_Lcs->m_mlcNum);
   }
   else
   {
      CLOG(0,0,"Newing SriLCSdata Failed");
   }
   TLOG(0,0,"Pushing data to DB");
   l_Lcs->m_cb = this;
   l_Lcs->m_DbQueryType = 1;
   g_act.execute(l_Lcs);
   return true; 
}

/////////////////////////////////////////////////////////////////////////////////////////
bool CtxtSriForLCS :: processMessage(Msg *aMsgPtr,bool& aDeleteFlag)
{
   DLOG(0,0,"Start of ProcessMsg function");
   MapSpecificMsg *l_specMsg = NULL;
   u32 l_UserDlgId = 0;

   switch (aMsgPtr->m_MsgType)
   {
      case MSG_TYPE_MAP:
         switch (((MapMsg*)aMsgPtr)->m_MapMsgType)
         {
            case MAP_MSG_TYPE_COMMON:
               switch (((MapCommonMsg*)aMsgPtr)->m_MapCommonMsgType)
               {
                  case MAP_CMN_OPEN_IND:
                     {
                        DLOG(0,0,"MAP_CMN_OPEN_IND received OriginationGt |%s| DestinationGt |%s|",((MapOpenInd*)aMsgPtr)->m_OrigAddr.globalTitle.addressInformation,((MapOpenInd*)aMsgPtr)->m_DestAddr.globalTitle.addressInformation);
                     }
                     break;

                  case MAP_CMN_DELIMITER_IND:
                     DLOG(0,0,"MAP_CMN_DELIMITER_IND received");
                     break;

                  case MAP_CMN_CLOSE_IND:
                     DLOG(0,0,"MAP_CMN_CLOSE_IND received");
                     return true;
                     break;

                  case MAP_CMN_OPEN_CNF:
                     {
                        u32 l_abrtDlgId = ((MapMsg*)aMsgPtr)->m_UserDlgId;
                        EMapVersion l_MapVersion = ((MapOpenCnf*)aMsgPtr)->m_Version;
                        m_tdr.setInteger(TDR_INDEX_OPEN_CNF_VERSION,(int)l_MapVersion); 
                        CLOG(0,0,"MAP_CMN_OPEN_CNF Received on SriForLCS DlgId |%d| just returning",l_abrtDlgId);
                        return true;
                     }
                     break;

                  case MAP_CMN_U_ABORT_IND:
                     {
                        u32 l_abrtDlgId = ((MapMsg*)aMsgPtr)->m_UserDlgId;
                        CLOG(0,0,"MAP_CMN_U_ABORT_IND Received on SriForLCS DlgId |%d| just returning",l_abrtDlgId);
                        m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_U_ABORT_RCVD); 
                        return true;
                     }
                     break;

                  case MAP_CMN_P_ABORT_IND:
                     {
                        u32 l_abrtDlgId = ((MapMsg*)aMsgPtr)->m_UserDlgId;
                        CLOG(0,0,"MAP_CMN_P_ABORT_IND Received on SriForLCS DlgId |%d| just returning",l_abrtDlgId);
                        m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_P_ABORT_RCVD); 
                        return true;
                     }
                     break;

                  case MAP_CMN_NOTICE_IND:
                     {
                     }
                     break;

                  default:
                     CLOG(0,0,"Unknown Msg received [%d]", ((MapCommonMsg*)aMsgPtr)->m_MapCommonMsgType);
                     break;
               }
               break;

            case MAP_MSG_TYPE_SPECIFIC:
               {
                  l_specMsg = (MapSpecificMsg*)aMsgPtr;
                  l_UserDlgId = l_specMsg->m_UserDlgId; 
                  EMapVersion l_MapVersion = ((MapMsg*)aMsgPtr)->m_Version;

                  switch (((MapSpecificMsg*)aMsgPtr)->m_MapSpecificEventType)
                  {
                     case MAP_SPEC_EVENT_INDICATION:
                        {
                           DLOG(0,0,"MAP_SPEC_EVENT_INDICATION received MapVersion-|%d| DlgId-|%d|",l_MapVersion,l_UserDlgId);
                           switch (((MapSpecificMsg*)aMsgPtr)->m_OpCode)
                           {
                              case MAP_OP_CODE_sendRoutingInfoForLCS:
                                 {
                                    DLOG(0,0,"Received SriForLCS");

                                    if (false == ((MapSpecificMsg*)aMsgPtr)->m_allocatedFlag)
                                    {
                                       CLOG(0,0,"SriForLCS Decode Failed - Sending User Error Unexpected Data");
                                       m_ErrCode = MAP_ERROR_unexpectedData;
                                       m_InitDlgId = l_UserDlgId;
                                       m_MapVer = l_MapVersion;
                                       return handleError();
                                    }
                                    else if(NULL == g_spdPtr)
                                    {
                                       CLOG(0,0,"g_spdPTR is NULL .. profile Loading Failed returning SystemFailure");
                                       printf("\n ##### PROFILE LOADING FAILED .. sending system failure #####\n");
                                       m_ErrCode = MAP_ERROR_systemFailure; 
                                       m_InitDlgId = l_UserDlgId;
                                       m_MapVer = l_MapVersion;
                                       return handleError(); 
                                    }
                                    handleSriForLCS(aMsgPtr,l_UserDlgId,l_MapVersion);
                                 }
                                 break;

                              default:
                                 {
                                    CLOG(0,0,"Received Unknown Specific Message");
                                    MapUAbortReq l_req(l_UserDlgId);
                                    g_sc.sendMsg(this, &l_req);
                                 }
                                 break;
                           }
                        }
                        break;

                     case MAP_SPEC_EVENT_RESULT:
                        {
                           DLOG(0,0,"MAP_SPEC_EVENT_RESULT received");
                        }
                        break;

                     case MAP_SPEC_EVENT_CONFIRMATION:
                        {
                           DLOG(0,0,"MAP_SPEC_EVENT_CONFIRMATION received MapVersion-|%d| DlgId-|%d|",l_MapVersion,l_UserDlgId);
                        }
                        break;

                     case MAP_SPEC_EVENT_USER_ERROR:
                        {
                           DLOG(0,0,"MAP_SPEC_EVENT_USER_ERROR received");
                        }
                        break;

                     case MAP_SPEC_EVENT_PROV_ERROR:
                        {
                           DLOG(0,0,"MAP_SPEC_EVENT_PROV_ERROR received");
                        }
                        break;
                     default:
                        ELOG(0,0,"ERROR!! Default SPECIFIC MSG received");
                        break;
                  }
               }
               break;

            default:
               break;
         }
         break;

      case MSG_TYPE_DB:
         {
            if(1 ==  ((DbQueryMsg*)aMsgPtr)->m_DbQueryType)
            {
               aDeleteFlag = false;
               SriLCSdata *l_Msg = (SriLCSdata *)aMsgPtr;

               DLOG(0,0,"DBRES: m_EdbResult |%d|",l_Msg->m_EdbResult);

               mp_sriLcs = l_Msg;

               LLOG(0,0,"DBRES: SriForLCSRes-HLR-GT:|%s|",mp_sriLcs->m_HlrAddr);
               if(strlen((s8*)mp_sriLcs->m_HlrAddr) > 1) 
               {
                  sendMapOpenResponse(m_InitDlgId,(s8*)mp_sriLcs->m_HlrAddr,g_ConfigData->i_NgConfigData.m_selfAddress.ssn);
                  m_tdr.setString(TDR_INDEX_LOCAL_ADDRESS,(s8*)mp_sriLcs->m_HlrAddr); 
               }
               else
               {
                  LLOG(0,0,"DBRES: SriForLCS GT not present in SubsData picking from NgConfig");
               }

               if(CM_DB_SUCCESS == l_Msg->m_EdbResult)
               {
                  LLOG(0,0,"DBRES: MscNumber:|%s| VlrNumber:|%s| SgsnNumber:|%s|",mp_sriLcs->m_MscNumber,mp_sriLcs->m_VlrNumber,mp_sriLcs->m_SgsnNumber);
                  LLOG(0,0,"DBRES: V-GmlcAddr:|%s| H-GmlcAddr:|%s| PPR-Addr:|%s| Add-V-GmlcAddr-|%s|",mp_sriLcs->m_CS_VgmlcAddr,mp_sriLcs->m_HgmlcAddr,mp_sriLcs->m_PprAddr,mp_sriLcs->m_PS_VgmlcAddr);

                  m_tdr.setInteger(TDR_INDEX_PARTNER_TYPE,mp_sriLcs->m_partnerType); 

                  LLOG(0,0,"DBRES: NwId:|%d| PNwId:|%d| TargetMS:|%s|",mp_sriLcs->m_networkId,mp_sriLcs->m_PartnerNetId,mp_sriLcs->m_targetMS);
                  LLOG(0,0,"DBRES: SuppLCSCapSets:|%d| SuppAddLCSCapSets:|%d| ",mp_sriLcs->m_suppLCScapSets,mp_sriLcs->m_suppPSLCScapSets);
                  LLOG(0,0,"DBRES: PrimaryIMSI:|%s| PrimaryMSISDN:|%s|",mp_sriLcs->m_PrimaryImsi,mp_sriLcs->m_PrimaryMsisdn);
                  LLOG_HEX(0,0,"DBRES: LMSI", (s8*)mp_sriLcs->m_Lmsi,mp_sriLcs->m_LmsiLen);

                  //sendSriLcsResponse
                  sendSriForLCSResp();
               }
               else
               {
                  if(MAP_ERROR_unauthorizedRequestingNetwork == l_Msg->m_errCode)
                  {
                     g_si.sendSnmpTrap(g_CMEntityAuthFailTrap, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL);
                  }
                  m_ErrCode = (EMapErrorCode)l_Msg->m_errCode;
                  CLOG(0,0,"DB Failure .. Error Code Value |%d|",l_Msg->m_errCode);
                  m_tdr.setInteger(TDR_INDEX_DB_ERR_CODE, (abs)(((DbQueryMsg*)aMsgPtr)->m_procErrorCode));
                  m_tdr.setString(TDR_INDEX_DB_ERR_DESC, ((DbQueryMsg*)aMsgPtr)->m_procErrorMessage);
                  return handleError(); 
               }
            }
            else
            {
               ELOG(0,0,"Unknown DB message");
            }
         }
         break;

      default:
         CLOG(0,0,"Unknown message received");
         break;
   }
   return true;
}

bool CtxtSriForLCS :: ValidateIpv4(s8* aIpAddr)
{
   unsigned b1, b2, b3, b4;
   u8 c;
   if (sscanf(aIpAddr, "%3u.%3u.%3u.%3u%c", &b1, &b2, &b3, &b4, &c) != 4)
   {
      DLOG(0,0,"ValidatIPv4 Failed");
      return false;
   }
   if ((b1 | b2 | b3 | b4) > 255) return  false;

   if (strspn(aIpAddr, "0123456789.") < strlen(aIpAddr)) return 0;
   DLOG(0,0,"Validated IPv4");
   return true;
}

void CtxtSriForLCS :: convertIPV4toHex(s8* aIpV4Addr, u8* aIpAddrInHex)
{
   s8 *pch=NULL;
   pch=strtok(aIpV4Addr,".");
   aIpAddrInHex[0]=atoi(pch);

   pch= strtok (NULL, ".");
   aIpAddrInHex[1]=atoi(pch);

   pch= strtok (NULL, ".");
   aIpAddrInHex[2]=atoi(pch);

   aIpAddrInHex[3]=atoi((pch+strlen(pch)+1));
}
