#include <stdio.h>
#include <MapMessages.h>
#include <ServiceCoordinator.h>
#include <Logger.h>
#include "ConfigReader.h"
#include "CtxtSimSriForLcsReq.h"
#include "HLRCMEnums.h"
#include "HLRCMConstants.h"
#include <DbActiveObject.h>
#include <DataUnion.h>
#include <IMAP3.h>
#include <IMAP2.h>
#include <IMAP1.h>
#include <OMAP3.h>
#include <OMAP2.h>
#include <OMAP1.h>
#include <Utilities.h>
#include <CMSimConfigReader.h>
/**************************************************************************************************
  Function Name      : CtxtGmlcSriForLcsReq
Author               :
InParams             : void 
OutParam /return val : void
Description          : Constructor
 ****************************************************************************************************/


CtxtGmlcSriForLcsReq :: CtxtGmlcSriForLcsReq()
{
}


/**************************************************************************************************
  Function Name      : CtxtGmlcSriForLcsReq
Author               :
InParams             : void 
OutParam /return val : void
Description          : Destructor
 ****************************************************************************************************/


CtxtGmlcSriForLcsReq :: ~CtxtGmlcSriForLcsReq()
{

}

bool CtxtGmlcSriForLcsReq::startProcessing()
{
   sendSriForLcsReq();
   return true;
}

bool CtxtGmlcSriForLcsReq::sendSriForLcsReq()
{
   DECLARE(OMAP3_RoutingInfoForLCS_Arg,l_tempSriForLcs,3,"OMAP3_RoutingInfoForLCS_Arg",resetStruct);
   int l_UserDlgId = g_sc.getNewDialogue();
   DLOG(l_UserDlgId,0,"###CtxGmlcSriForLcsReq### Start of CtxtGmlcSriForLcsReq::sendSRIReq function");
   //printf("\n CtxtGmlcSriForLcsReq::sendSRI ######### SRI Request #############\n");

   DLOG(l_UserDlgId,0,"###CtxGmlcSriForLcsReq### Sending MapOpenReq ...");
   MapOpenReq l_mapOpenReq(l_UserDlgId, MAP_V3);

   l_mapOpenReq.m_ApplCntxt = MAP_AC_CODE_locationSvcGateway;
   l_mapOpenReq.m_DestAddr  = g_ConfigData->i_NgConfigData.m_remoteAddress1;

   g_sc.sendMsg(this, &l_mapOpenReq);

   DLOG(l_UserDlgId,0,"###CtxGmlcSriForLcsReq### CtxtGmlcSriForLcsReq::sendSRI Sending MapSpecificRequest ...");
   MapSpecificRequest l_request(l_UserDlgId, MAP_OP_CODE_sendRoutingInfoForLCS, MAP_V3);


   if(1 == g_CMSimConfigReaderObj->m_TargetMsType) // 1==Msisdn 
   {
      DLOG(0,0,"TEST 1");
      l_tempSriForLcs->targetMS.choice =  OMAP3_SubscriberIdentity_msisdn_chosen;
      l_tempSriForLcs->targetMS.u.msisdn.length = (strlen(g_CMSimConfigReaderObj->m_TargetMs)+1)/2 + 1;
      //l_tempSriForLcs->targetMS.u.msisdn.length = (strlen(g_CMSimConfigReaderObj->m_TargetMs));
      l_tempSriForLcs->targetMS.u.msisdn.value[0] = 0x91;
      StringToBCD(&l_tempSriForLcs->targetMS.u.msisdn.value[1], (unsigned char *)g_CMSimConfigReaderObj->m_TargetMs, strlen(g_CMSimConfigReaderObj->m_TargetMs));
      LLOG(0,0,"TargetMSISDN Req Length is %d Req TargetMSISDN Value is %s",l_tempSriForLcs->targetMS.u.msisdn.length, l_tempSriForLcs->targetMS.u.msisdn.value);
   }
   else if(2 == g_CMSimConfigReaderObj->m_TargetMsType) // 2==Imsi 
   {
      DLOG(0,0,"TEST 2");
      l_tempSriForLcs->targetMS.choice =  OMAP3_SubscriberIdentity_imsi_chosen;
      l_tempSriForLcs->targetMS.u.imsi.length = (strlen(g_CMSimConfigReaderObj->m_TargetMs)+1)/2;
      //l_tempSriForLcs->targetMS.u.imsi.length = (strlen(g_CMSimConfigReaderObj->m_TargetMs));
      StringToBCD(l_tempSriForLcs->targetMS.u.msisdn.value, (unsigned char *)g_CMSimConfigReaderObj->m_TargetMs, strlen(g_CMSimConfigReaderObj->m_TargetMs));
      LLOG(0,0,"TargetMSISDN Req Length is %d Req TargetMSISDN Value is %s",l_tempSriForLcs->targetMS.u.msisdn.length, l_tempSriForLcs->targetMS.u.msisdn.value);
   }

   l_tempSriForLcs->mlcNumber.length = (strlen(g_CMSimConfigReaderObj->m_gmlc)+1)/2 + 1;
   l_tempSriForLcs->mlcNumber.value[0] = 0x91;
   StringToBCD(&l_tempSriForLcs->mlcNumber.value[1], (unsigned char *)g_CMSimConfigReaderObj->m_gmlc, strlen(g_CMSimConfigReaderObj->m_gmlc));

   l_request.m_structBuffer = (void*)l_tempSriForLcs;

   g_sc.sendMsg(this, &l_request);

   DLOG(0,0,"###CtxGmlcSriForLcsReq### Sending MapDelimiterReq Req ...");
   MapDelimiterReq l_del(l_UserDlgId);
   g_sc.sendMsg(this, &l_del);

   return true;
}

bool CtxtGmlcSriForLcsReq::processMessage(Msg *p_MsgPtr,bool& p_DeleteFlag)
{
   DLOG(0,0,"###CtxGmlcSriForLcsReq### Start of CtxtGmlcSriForLcsReq::processMsg function");
   MapSpecificMsg *l_specMsg = NULL;
   int l_UserDlgId;

   switch (p_MsgPtr->m_MsgType)
   {
      case MSG_TYPE_MAP:
         switch (((MapMsg*)p_MsgPtr)->m_MapMsgType)
         {
            case MAP_MSG_TYPE_COMMON:
               switch (((MapCommonMsg*)p_MsgPtr)->m_MapCommonMsgType)
               {
                  case MAP_CMN_OPEN_IND:
                     DLOG(0,0,"###CtxGmlcSriForLcsReq### MAP_CMN_OPEN_IND received");
                     break;

                  case MAP_CMN_DELIMITER_IND:
                     DLOG(0,0,"###CtxGmlcSriForLcsReq### MAP_CMN_DELIMITER_IND received");
                     break;

                  case MAP_CMN_CLOSE_IND:
                     DLOG(0,0,"###CtxGmlcSriForLcsReq### MAP_CMN_CLOSE_IND received");
                     return true;
                     break;

                  case MAP_CMN_U_ABORT_IND:
                     TLOG(0,0,"###CtxGmlcSriForLcsReq### MAP_CMN_U_ABORT_IND received");
                     break;

                  case MAP_CMN_P_ABORT_IND:
                     TLOG(0,0,"###CtxGmlcSriForLcsReq### MAP_CMN_P_ABORT_IND received");
                     break;

                  case MAP_CMN_NOTICE_IND:
                     {
                        TLOG(0,0,"###CtxGmlcSriForLcsReq### MAP_CMN_NOTICE_IND received");
                     }
                     break;

                  default:
                     TLOG(0,0,"###CtxGmlcSriForLcsReq### Unknown Msg received [%d]", ((MapCommonMsg*)p_MsgPtr)->m_MapCommonMsgType);
                     break;
               }
               break;

            case MAP_MSG_TYPE_SPECIFIC:
               DLOG(0,0,"###CtxGmlcSriForLcsReq### MAP_MSG_TYPE_SPECIFIC received");
               l_specMsg = (MapSpecificMsg*)p_MsgPtr;
               l_UserDlgId = l_specMsg->m_UserDlgId;
               TLOG(0,0,"CtxGmlcSriForLcsReq MAP_MSG_TYPE_SPECIFIC received UserDlgId[%d]",
                     l_UserDlgId);

               switch (((MapSpecificMsg*)p_MsgPtr)->m_MapSpecificEventType)
               {
                  case MAP_SPEC_EVENT_INDICATION:
                     {
                        DLOG(l_UserDlgId,0,"###CtxGmlcSriForLcsReq### MAP_SPEC_EVENT_INDICATION received");

                        switch (((MapSpecificMsg*)p_MsgPtr)->m_OpCode)
                        {
                           case MAP_OP_CODE_sendRoutingInfo:
                              {
                                 DLOG(l_UserDlgId,0,"###CtxGmlcSriForLcsReq### Received SendRoutingInformation");
                              }
                              break;

                           default:
                              DLOG(l_UserDlgId,0,"###CtxGmlcSriForLcsReq### Received Unknown Specific Message");
                              break;

                        }

                     }

                     break;

                  case MAP_SPEC_EVENT_RESULT:
                     {
                        DLOG(l_UserDlgId,0,"###CtxGmlcSriForLcsReq### MAP_SPEC_EVENT_RESULT received");
                     }
                     break;

                  case MAP_SPEC_EVENT_CONFIRMATION:
                     {
                        DLOG(l_UserDlgId,0,"CtxGmlcSriForLcsReq MAP_SPEC_EVENT_CONFIRMATION received");
                        switch (((MapSpecificMsg*)p_MsgPtr)->m_OpCode)
                        {
                           case MAP_OP_CODE_sendRoutingInfo:
                              { 

                              }
                              break;

                           default:
                              break;

                        }
                     }
                     break;

                  case MAP_SPEC_EVENT_USER_ERROR:
                     {
                        TLOG(l_UserDlgId,0,"###CtxGmlcSriForLcsReq### MAP_SPEC_EVENT_USER_ERROR received");
                     }
                     break;

                  case MAP_SPEC_EVENT_PROV_ERROR:
                     {
                        TLOG(l_UserDlgId,0,"###CtxGmlcSriForLcsReq### MAP_SPEC_EVENT_PROV_ERROR received");
                        DLOG(l_UserDlgId,0,"###CtxGmlcSriForLcsReq### Closing the Dialogue");
                        MapCloseReq l_closeReq(((MapSpecificMsg*)p_MsgPtr)->m_UserDlgId);
                        g_sc.sendMsg(this, &l_closeReq);
                     }
                     break;
                  default:
                     ELOG(l_UserDlgId,0,"###CtxGmlcSriForLcsReq### ERROR!! Default received");
                     break;

               }


               break;

            default:
               break;
         }
         break;

      case MSG_TYPE_DB:
         {
         }
         break;

      default:
         DLOG(0,0,"###CtxGmlcSriForLcsReq### Unknown message received");
         break;

   }
   return true;

}






