#include <Logger.h>
#include <CMConfigReader.h>

CMConfigReader *g_CMConfigReaderObj=NULL;

CMConfigReader::CMConfigReader()
{
   m_VlrSSN = 0;
   m_no_fwd = 0;
   m_mnrfFlag = 0;
   m_standalonePrnMnrfFlag = 0;
   m_prnTimer = 0;
   m_psiTimer = 0;
   m_partnerScf = 0;
   m_callRefNumFlag = 0;
   m_passSriSGInfoNotFound = 0;
   m_disableLcsCapb = 0;
   m_roamingRetrySupportFlag = 0;
}

CMConfigReader::~CMConfigReader()
{
}

bool CMConfigReader::readData()
{
   //string l_cm = readValue(m_DataString,"CM");
   string l_cm = m_DataString;

   if(false == readInteger(l_cm, "VLRSSN", m_VlrSSN, 1, 255))
   {
      ELOG(0,0,"VLRSSN should be between 1 and 255");
      return false;
   }

   if(false == readInteger(l_cm, "MAX_NUM_FWD", m_no_fwd, 1, 5))
   {
      ELOG(0,0,"MAX_NUM_FWD should be between 1 and 5");
      return false;
   }

   if(false == readInteger(l_cm, "UPDATE_MNRF", m_mnrfFlag, 0, 1))
   {
      ELOG(0,0,"UPDATE_MNRF should be 0 or 1");
      return false;
   }

   if(false == readInteger(l_cm, "PRN_UPDATE", m_standalonePrnMnrfFlag, 0, 1))
   {
      ELOG(0,0,"PRN_UPDATE should be 0 or 1");
      return false;
   }

   if(false == readInteger(l_cm, "PRN_TIMER", m_prnTimer, 15, 30))
   {
      ELOG(0,0,"PRN Invoke Timer Value should be between 15 and 30");
      return false;
   }

   if(false == readInteger(l_cm, "PSI_TIMER", m_psiTimer, 15, 30))
   {
      ELOG(0,0,"PSI Invoke Timer Value should be between 15 and 30");
      return false;
   }

   if(false == readInteger(l_cm, "PARTNER_SCF", m_partnerScf, 0, 1))
   {
      ELOG(0,0,"PARTNER_SCF Value should be 0 or 1");
      return false;
   }

   if(false == readInteger(l_cm, "CALLREF_NUM", m_callRefNumFlag, 0, 1))
   {
      ELOG(0,0,"CALLREF_NUM Value should be 0 or 1");
      return false;
   }

   if(false == readInteger(l_cm, "PASS_SRI_SGINFO_NOT_FOUND", m_passSriSGInfoNotFound, 0, 1))
   {
      ELOG(0,0,"PASS_SRI_SGINFO_NOT_FOUND Value should be 0 or 1");
      return false;
   }

   if(false == readInteger(l_cm, "DISABLE_LCS_CAPB_IN_SRIFORLCS", m_disableLcsCapb, 0, 1))
   {
      ELOG(0,0,"DISABLE_LCS_CAPB_IN_SRIFORLCS Value should be 0 or 1");
      return false;
   }

   if(false == readInteger(l_cm, "ROAMING_RETRY_SUPPORT_FLAG", m_roamingRetrySupportFlag, 0, 1))
   {
      ELOG(0,0,"ROAMING_RETRY_SUPPORT_FLAG should be 0 or 1");
      return false;
   }

   m_derivedObjectInitializedFlag=true;
   return true;
}

void CMConfigReader::printConfigData(char *p_output)
{
   LLOG(0,1,"CMConfigReader::printConfigData called.");

   sprintf(p_output, "%s:%d\t%s:%d\t%s:%d\t%s:%d\t%s:%d\t%s:%d\n\t%s:%d\t%s:%d\t%s:%d\t%s:%d\t%s:%d",
         "VlrSSN", m_VlrSSN,
         "NumOfForwarding", m_no_fwd,
         "UpdateMnrf", m_mnrfFlag,
         "PrnTimerVal", m_prnTimer,
         "PsiTimerVal", m_psiTimer,
         "PartnerScf", m_partnerScf,
         "CallRefNum", m_callRefNumFlag,
         "PassSriSGinfoNotFound", m_passSriSGInfoNotFound,
         "DisableLcsCapabilitiesInSriForLcs", m_disableLcsCapb,
         "PrnMnrfUpdate", m_standalonePrnMnrfFlag,
         "RoamingRetrySupportFlag", m_roamingRetrySupportFlag
         );
}
