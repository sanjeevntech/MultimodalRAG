#include <stdio.h>
#include <MapMessages.h>
#include <ServiceCoordinator.h>
#include <Logger.h>
#include "ConfigReader.h"
#include "CtxtVlrPSIRes.h"
#include "HLRCMEnums.h"
#include "HLRCMConstants.h"
#include <DbActiveObject.h>
#include <DataUnion.h>
#include <Utilities.h>
#include <CMSimConfigReader.h>

/**************************************************************************************************
  Function Name      : CtxtVlrPSIRes
Author               :
InParams             : void 
OutParam /return val : void
Description          : Constructor
 ****************************************************************************************************/


CtxtVlrPSIRes :: CtxtVlrPSIRes()
{
   m_PsiDlgId = 0;
}


/**************************************************************************************************
  Function Name      : CtxtVlrPSIRes
Author               :
InParams             : void 
OutParam /return val : void
Description          : Destructor
 ****************************************************************************************************/


CtxtVlrPSIRes :: ~CtxtVlrPSIRes()
{



}

bool CtxtVlrPSIRes :: sendMapUserError(int p_dlgId,EMapErrorCode p_ErrCode,EMapVersion p_ver)
{
   ELOG(p_dlgId,0,"###CtxVLRPSIRes### SENDING MAPUSERERROR AND CLOSING THE DIALOGUE");
   MapUserError l_userError(p_dlgId, p_ErrCode, p_ver, NULL);
   g_sc.sendMsg(this, &l_userError);

   MapCloseReq l_closeReq(p_dlgId);
   g_sc.sendMsg(this, &l_closeReq);
   return true;
}

bool CtxtVlrPSIRes::sendPSIRes()
{
   DECLARE(OMAP3_ProvideSubscriberInfoRes,l_tempPSIRes,3,"OMAP3_ProvideSubscriberInfoRes",resetStruct);
   int l_UserDlgId = m_PsiDlgId;
   //printf("\n\n####### DlgID for PSIRes = %d ###########\n\n",l_UserDlgId);
   DLOG(l_UserDlgId,0,"###CtxVLRPSIRes### Start of CtxtVlrPSIRes::sendPSIRes function");


   if(!g_CMSimConfigReaderObj->m_MapError) 
   {
      l_tempPSIRes->subscriberInfo.bit_mask |= OMAP3_SubscriberInfo_locationInformation_present;

      l_tempPSIRes->subscriberInfo.locationInformation.bit_mask |= OMAP3_LocationInformation_ageOfLocationInformation_present;
      l_tempPSIRes->subscriberInfo.locationInformation.ageOfLocationInformation = 12;

      l_tempPSIRes->subscriberInfo.locationInformation.bit_mask |= OMAP3_LocationInformation_geographicalInformation_present;
      l_tempPSIRes->subscriberInfo.locationInformation.geographicalInformation.length = StringToBCD(l_tempPSIRes->subscriberInfo.locationInformation.geographicalInformation.value,(unsigned char *)"9197899711111111",strlen("9197899711111111"));
      //00000404000800

      l_tempPSIRes->subscriberInfo.locationInformation.bit_mask |= OMAP3_vlr_number_present;
      l_tempPSIRes->subscriberInfo.locationInformation.vlr_number.length = StringToBCD(l_tempPSIRes->subscriberInfo.locationInformation.vlr_number.value,(unsigned char *)"9123456778",strlen("9123456778"));

      l_tempPSIRes->subscriberInfo.locationInformation.bit_mask |= OMAP3_locationNumber_present;
      l_tempPSIRes->subscriberInfo.locationInformation.locationNumber.length = StringToBCD(l_tempPSIRes->subscriberInfo.locationInformation.locationNumber.value,(unsigned char *)"918823456778",strlen("918823456778"));

      l_tempPSIRes->subscriberInfo.locationInformation.bit_mask |= OMAP3_LocationInformation_msc_Number_present;
      l_tempPSIRes->subscriberInfo.locationInformation.msc_Number.length = StringToBCD(l_tempPSIRes->subscriberInfo.locationInformation.msc_Number.value,(unsigned char *)"917723456778",strlen("917723456778"));

      l_tempPSIRes->subscriberInfo.locationInformation.bit_mask |= OMAP3_LocationInformation_currentLocationRetrieved_present;   
      l_tempPSIRes->subscriberInfo.locationInformation.currentLocationRetrieved=1;

      l_tempPSIRes->subscriberInfo.locationInformation.bit_mask |= OMAP3_LocationInformation_sai_Present_present;   
      l_tempPSIRes->subscriberInfo.locationInformation.sai_Present=1;

      l_tempPSIRes->subscriberInfo.locationInformation.bit_mask |= OMAP3_LocationInformation_geodeticInformation_present;
      l_tempPSIRes->subscriberInfo.locationInformation.geodeticInformation.length = StringToBCD(l_tempPSIRes->subscriberInfo.locationInformation.geodeticInformation.value,(unsigned char *)"91662345677811111111", strlen("91662345677811111111"));

      l_tempPSIRes->subscriberInfo.locationInformation.bit_mask |= OMAP3_selectedLSA_Id_present;
      l_tempPSIRes->subscriberInfo.locationInformation.selectedLSA_Id.length = StringToBCD(l_tempPSIRes->subscriberInfo.locationInformation.selectedLSA_Id.value,(unsigned char *)"912311",strlen("912311"));
      //l_tempPSIRes->subscriberInfo.locationInformation.selectedLSA_Id.length = StringToBCD(l_tempPSIRes->subscriberInfo.locationInformation.selectedLSA_Id.value,(unsigned char *)"91231122",strlen("91231122"));
      /*****/
      l_tempPSIRes->subscriberInfo.locationInformation.bit_mask |= OMAP3_LocationInformation_cellGlobalIdOrServiceAreaIdOrLAI_present;
      l_tempPSIRes->subscriberInfo.locationInformation.cellGlobalIdOrServiceAreaIdOrLAI.choice = 1;
      l_tempPSIRes->subscriberInfo.locationInformation.cellGlobalIdOrServiceAreaIdOrLAI.u.cellGlobalIdOrServiceAreaIdFixedLength.length = StringToBCD(l_tempPSIRes->subscriberInfo.locationInformation.cellGlobalIdOrServiceAreaIdOrLAI.u.cellGlobalIdOrServiceAreaIdFixedLength.value,(unsigned char *)"52f530c15db015",strlen("52f530c15db015"));
      /******/
      l_tempPSIRes->subscriberInfo.bit_mask |= OMAP3_SubscriberInfo_subscriberState_present;
      l_tempPSIRes->subscriberInfo.subscriberState.choice = OMAP3_camelBusy_chosen;
      l_tempPSIRes->subscriberInfo.subscriberState.u.camelBusy = 1;


      //l_temp->subscriberInfo.bit_mask |= MAP3_SubscriberInfo_imei_present;
      //l_temp->subscriberInfo.imei.length = StringToBCD(l_temp->subscriberInfo.imei.value, (unsigned char *)"9123111111111111", strlen("9123111111111111"));


      MapSpecificResult l_result(l_UserDlgId, MAP_OP_CODE_provideSubscriberInfo, MAP_V3);
      l_result.m_structBuffer = (void*)l_tempPSIRes;
      g_sc.sendMsg(this, &l_result);

      DLOG(l_UserDlgId,0,"###CtxVLRPSIRes### Closing the PSI Dialogue");
      MapCloseReq l_closeReq(l_UserDlgId);
      g_sc.sendMsg(this, &l_closeReq);
   }
   else
   {
      sendMapUserError(l_UserDlgId,(EMapErrorCode)g_CMSimConfigReaderObj->m_MapError,MAP_V3);
   }

   return true;

}


bool CtxtVlrPSIRes::processMessage(Msg *p_MsgPtr,bool& p_DeleteFlag)
{
   DLOG(0,0,"###CtxVLRPSIRes### Start of CtxtVlrPSIRes::processMsg function");
   MapSpecificMsg *l_specMsg = NULL;
   int l_UserDlgId;

   switch (p_MsgPtr->m_MsgType)
   {
      case MSG_TYPE_MAP:
         switch (((MapMsg*)p_MsgPtr)->m_MapMsgType)
         {
            case MAP_MSG_TYPE_COMMON:
               switch (((MapCommonMsg*)p_MsgPtr)->m_MapCommonMsgType)
               {
                  case MAP_CMN_OPEN_IND:
                     {
                        DLOG(0,0,"###CtxVLRPSIRes### MAP_CMN_OPEN_IND received");
                        MapOpenInd *l_test = (MapOpenInd*)p_MsgPtr;
                        if (l_test->m_OpenInfo.bit_mask | MAP_DP_OpenInfo_destinationReference_present)
                        {
                           DLOG(0,0,"###CtxVLRPSIRes### Dest Ref length [%d] value [%02x %02x]", 
                                 l_test->m_OpenInfo.destinationReference.length,
                                 l_test->m_OpenInfo.destinationReference.value[0],
                                 l_test->m_OpenInfo.destinationReference.value[1]);
                        }

                        if (l_test->m_OpenInfo.bit_mask | MAP_DP_OpenInfo_originationReference_present)
                        {
                           DLOG(0,0,"###CtxVLRPSIRes### Orig Ref length [%d] value [%02x %02x]", 
                                 l_test->m_OpenInfo.originationReference.length,
                                 l_test->m_OpenInfo.originationReference.value[0],
                                 l_test->m_OpenInfo.originationReference.value[1]);
                        }
                     }
                     break;

                  case MAP_CMN_DELIMITER_IND:
                     DLOG(0,0,"###CtxVLRPSIRes### MAP_CMN_DELIMITER_IND received");
                     break;

                  case MAP_CMN_CLOSE_IND:
                     DLOG(0,0,"###CtxVLRPSIRes### MAP_CMN_CLOSE_IND received");
                     return true;
                     break;

                  case MAP_CMN_U_ABORT_IND:
                     DLOG(0,0,"###CtxVLRPSIRes### MAP_CMN_U_ABORT_IND received");
                     break;

                  case MAP_CMN_P_ABORT_IND:
                     DLOG(0,0,"###CtxVLRPSIRes### MAP_CMN_P_ABORT_IND received");
                     break;

                  case MAP_CMN_NOTICE_IND:
                     {
                        DLOG(0,0,"###CtxVLRPSIRes### MAP_CMN_NOTICE_IND received");
                     }
                     break;

                  default:
                     DLOG(0,0,"###CtxVLRPSIRes### Unknown Msg received [%d]", ((MapCommonMsg*)p_MsgPtr)->m_MapCommonMsgType);
                     break;
               }
               break;

            case MAP_MSG_TYPE_SPECIFIC:
               DLOG(0,0,"###CtxVLRPSIRes### MAP_MSG_TYPE_SPECIFIC received");
               l_specMsg = (MapSpecificMsg*)p_MsgPtr;
               l_UserDlgId = l_specMsg->m_UserDlgId;
               DLOG(0,0,"###CtxVLRPSIRes### MAP_MSG_TYPE_SPECIFIC received UserDlgId[%d]",
                     l_UserDlgId);

               switch (((MapSpecificMsg*)p_MsgPtr)->m_MapSpecificEventType)
               {
                  case MAP_SPEC_EVENT_INDICATION:
                     {
                        DLOG(l_UserDlgId,0,"###CtxVLRPSIRes### MAP_SPEC_EVENT_INDICATION received");
                        //l_UserDlgId = p_MsgPtr->m_UserDlgId; not required as u get DlgId above

                        switch (((MapSpecificMsg*)p_MsgPtr)->m_OpCode)
                        {
                           case MAP_OP_CODE_provideRoamingNumber:
                              {
                              }
                              break;
                           case MAP_OP_CODE_provideSubscriberInfo:
                              {
                                 ///printf("\n ######## SENDING PSI RES ######## \n");
                                 m_PsiDlgId = l_UserDlgId;
                                 sendPSIRes();
                              }
                              break;

                           default:
                              DLOG(l_UserDlgId,0,"###CtxVLRPSIRes### Received Unknown Specific Message");
                              break;

                        }

                     }

                     break;

                  case MAP_SPEC_EVENT_RESULT:
                     {
                        DLOG(l_UserDlgId,0,"###CtxVLRPSIRes### MAP_SPEC_EVENT_RESULT received");
                     }
                     break;

                  case MAP_SPEC_EVENT_CONFIRMATION:
                     {
                        DLOG(0,0,"###CtxVLRPSIRes### MAP_SPEC_EVENT_CONFIRMATION received ");
                        switch (((MapSpecificMsg*)p_MsgPtr)->m_OpCode)
                        {
                           case MAP_OP_CODE_provideRoamingNumber:
                              {
                                 DLOG(l_UserDlgId,0,"###CtxVLRPSIRes### MAP_SPEC_EVENT_CONFIRMATION received for MAP_OP_CODE_provideRoamingNumber");
                              }
                           case MAP_OP_CODE_sendRoutingInfo:
                              {
                                 DLOG(l_UserDlgId,0,"###CtxVLRPSIRes### MAP_SPEC_EVENT_CONFIRMATION received for MAP_OP_CODE_sendRoutingInfo");
                              }
                              break;
                           default:
                              break;

                        }
                     }
                     break;

                  case MAP_SPEC_EVENT_USER_ERROR:
                     {
                        DLOG(l_UserDlgId,0,"###CtxVLRPSIRes### MAP_SPEC_EVENT_USER_ERROR received");
                     }
                     break;

                  case MAP_SPEC_EVENT_PROV_ERROR:
                     {
                        DLOG(l_UserDlgId,0,"###CtxVLRPSIRes### MAP_SPEC_EVENT_PROV_ERROR received");
                        DLOG(l_UserDlgId,0,"###CtxVLRPSIRes### Closing the Dialogue");
                        MapCloseReq l_closeReq(((MapSpecificMsg*)p_MsgPtr)->m_UserDlgId);
                        g_sc.sendMsg(this, &l_closeReq);
                     }
                     break;
                  default:
                     ELOG(l_UserDlgId,0,"###CtxVLRPSIRes### ERROR!! Default received processMessage");
                     break;

               }


               break;

            default:
               break;
         }
         break;

      case MSG_TYPE_DB:
         {
         }
         break;

      default:
         DLOG(0,0,"###CtxVLRPSIRes### Unknown message received");
         break;

   }
   return true;

}






