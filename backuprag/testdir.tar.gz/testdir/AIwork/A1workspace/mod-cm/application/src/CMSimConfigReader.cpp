#include <CMSimConfigReader.h>
#include <Logger.h>
  
  CMSimConfigReader *g_CMSimConfigReaderObj = NULL;
  CMSimConfigReader::CMSimConfigReader()
  {
     m_psiPrn=0;
     m_mapVer=0;
     memset(m_msisdn,'\0',sizeof(m_msisdn));
     memset(m_gmscAdd,'\0',sizeof(m_gmscAdd));
     m_cph=0;
     m_nkSigInfo = 0;
     m_cdiVal = 0;
     m_MapError=0;
     m_TargetMsType=0;
     memset(m_TargetMs,'\0',sizeof(m_TargetMs));
     memset(m_gmlc,'\0',sizeof(m_gmlc));
  }
 
  CMSimConfigReader::~CMSimConfigReader()
  {
  }
 
  bool CMSimConfigReader::readData()
  {
     string l_cm = readValue(m_DataString,"GMSCSIM");
 
     string l_psiPrn = readValue(l_cm,"PSIORPRN");
     printf("\n Value of PSIORPRN  = [%d]\n",atoi(l_psiPrn.c_str()));
     g_CMSimConfigReaderObj->m_psiPrn = atoi(l_psiPrn.c_str());
 
     string l_cdiVal = readValue(l_cm,"CDIVAL");
     printf("\n Value of CDIVAL  = [%d]\n",atoi(l_cdiVal.c_str()));
     g_CMSimConfigReaderObj->m_cdiVal = atoi(l_cdiVal.c_str());
 
     string l_cph = readValue(l_cm,"REQCAMELPH");
     printf("\n Value of RequestedCphGmsc  = [%d]\n",atoi(l_cph.c_str()));
     g_CMSimConfigReaderObj->m_cph = atoi(l_cph.c_str());
 
     string l_mapVer = readValue(l_cm,"MAPVER");
     g_CMSimConfigReaderObj->m_mapVer = atoi(l_mapVer.c_str());
     printf("\n Value of MapVer = [%d]\n",m_mapVer);
     if(m_mapVer < 1 || m_mapVer > 3)
     {
        printf("\n Wrong mapversion ");
        return false;
     }
     string l_msisdn = readValue(l_cm,"MSISDN");
     strncpy(g_CMSimConfigReaderObj->m_msisdn,(char*)l_msisdn.c_str(),strlen((char*)l_msisdn.c_str()));
     printf("\n Value of Msisdn = [%s]\n",m_msisdn);
 
     string l_gmscAdd = readValue(l_cm,"GMSCADD");
     strncpy(g_CMSimConfigReaderObj->m_gmscAdd,(char*)l_gmscAdd.c_str(),strlen((char*)l_gmscAdd.c_str()));
     printf("\n Value of GmscAdd = [%s]\n",m_gmscAdd);
 
     string l_nkSigInfo = readValue(l_cm,"NKSIGINFO");
     printf("\n Value of NKSIGINFO  = [%d]\n",atoi(l_nkSigInfo.c_str()));
     g_CMSimConfigReaderObj->m_nkSigInfo = atoi(l_nkSigInfo.c_str());
 
     string l_mapError = readValue(l_cm,"MAPERROR");
     printf("\n Value of MAPERROR  = [%d]\n",atoi(l_mapError.c_str()));
     g_CMSimConfigReaderObj->m_MapError = atoi(l_mapError.c_str());

     string l_msType = readValue(l_cm,"TARGETMSTYPE");
     printf("\n Value of TARGETMSTYPE  = [%d]\n",atoi(l_msType.c_str()));
     g_CMSimConfigReaderObj->m_TargetMsType = atoi(l_msType.c_str());

     string l_targetMS = readValue(l_cm,"TARGETMS");
     strncpy(g_CMSimConfigReaderObj->m_TargetMs,(char*)l_targetMS.c_str(),strlen((char*)l_targetMS.c_str()));
     printf("\n Value of TARGETMS = [%s]\n",m_TargetMs);

     string l_gmlc = readValue(l_cm,"GMLC");
     strncpy(g_CMSimConfigReaderObj->m_gmlc,(char*)l_gmlc.c_str(),strlen((char*)l_gmlc.c_str()));
     printf("\n Value of Gmlc = [%s]\n",m_gmlc);

     g_CurrSubsBase = 200000;
     return true;
  }
void CMSimConfigReader::printConfigData(char *p_output)
  {
     TLOG(0,1,"CMSimConfigReader::printConfigData called.");

     sprintf(p_output, "%s:%d\t%s:%d\t%s:%s\t%s:%d\t%s:%d\t%s:%d\t%s:%s\t%s:%s",
           "PsiOrPrnFlag", g_CMSimConfigReaderObj->m_psiPrn,
           "MapVersion", g_CMSimConfigReaderObj->m_mapVer,
           "Msisdn", g_CMSimConfigReaderObj->m_msisdn,
           "CdiVal",g_CMSimConfigReaderObj->m_cdiVal,
           "MapError",g_CMSimConfigReaderObj->m_MapError,
           "TargetMSType",g_CMSimConfigReaderObj->m_TargetMsType,
           "TargetMs",g_CMSimConfigReaderObj->m_TargetMs,
           "Gmlc",g_CMSimConfigReaderObj->m_gmlc
           );
}
