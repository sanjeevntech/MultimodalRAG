#include <MapMessages.h>
#include <ServiceCoordinator.h>
#include <Logger.h>
#include <OMAP1.h>
#include <OMAP2.h>
#include <OMAP3.h>
#include <DbActiveObject.h>
#include <ConfigReader.h>
#include <Utilities.h>
#include <DataUnion.h>
#include <HlrTdrFiller.h>
#include "CMDbQueries.h"
#include "CMProvideRoamingNumber.h"
#include "CMConfigReader.h"

extern bool resetStruct(int p_version, int p_pdu, void *p_struct);


CtxtProvideRoamingNumber::CtxtProvideRoamingNumber()
{
   DLOG(0,0,"CtxtProvideRoamingNumber::CtxtProvideRoamingNumber()");
   memset(m_TransId, '\0', sizeof(m_TransId));
   memset(m_Imsi, '\0', sizeof(m_Imsi));
   m_UserDlgId=0;
}

CtxtProvideRoamingNumber::~CtxtProvideRoamingNumber()
{
   DLOG(0,0,"CtxtProvideRoamingNumber::~CtxtProvideRoamingNumber()");
}

bool CtxtProvideRoamingNumber::updatePrnMnrfDb()
{
   if(1 == g_CMConfigReaderObj->m_standalonePrnMnrfFlag)
   {
      CMPrnUpdateMNRF *l_mnrf = new CMPrnUpdateMNRF;
      if(l_mnrf != NULL)
      {
         strcpy((s8*)l_mnrf->m_Imsi,(s8*)m_Imsi);
         l_mnrf->m_Mnrf = 0;
         LLOG(0,0,"DBIN-MNRF: IMSI-|%s| MnrfFlag-|0|",m_Imsi);
         l_mnrf->m_DbQueryType=1;
         l_mnrf->m_cb = this;
         g_act.execute(l_mnrf);
         return true;
      }
      else
      {
         CLOG(0,0,"Newing UpdatePrnMnrfClass Failed");
         return false;
      }
   }
   else
   {
      return true;
   }
}

bool CtxtProvideRoamingNumber::sendv3Prn()
{
   string l_imsi = ConfigReader::readValue(m_DataString, "IMSI");
   if (0 == l_imsi.length())
   {
      CLOG(0,0,"Unknown IMSI");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }
   strcpy(m_Imsi, (char*)l_imsi.c_str());

   string l_hlrAddress;
   l_hlrAddress = ConfigReader::readValue(m_DataString, "HLR_NUMBER");
   if(0 == l_hlrAddress.length())
   {
      CLOG(0,0,"Unknown HLR_NUMBER");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }

   string l_mscAddress;
   l_mscAddress = ConfigReader::readValue(m_DataString, "MSC_NUMBER");
   if(0 == l_mscAddress.length())
   {
      CLOG(0,0,"Unknown MSC_ADDRESS");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }


   m_UserDlgId = g_sc.getNewDialogue();
   if(m_UserDlgId < 1)
   {
      ELOG(0,0,"Couldnt get a new dialogue");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }
   DLOG(0,0,"Sending MapOpenReq v3 ...");
   MapOpenReq l_mapOpenReq(m_UserDlgId, MAP_V3);
   l_mapOpenReq.m_ApplCntxt = MAP_AC_CODE_roamingNbEnquiry;
   configureSccpAddress(&l_mapOpenReq.m_OrigAddr, L_ROUTE_ON_GT, 0, g_ConfigData->i_NgConfigData.m_LocalSSN, (char*)l_hlrAddress.c_str());
   m_tdr.setMapVersion(3);
   m_tdr.setString(TDR_INDEX_LOCAL_ADDRESS, (char*)l_hlrAddress.c_str());

   m_tdr.setRemoteAddrSsn(7);
   configureSccpAddress(&l_mapOpenReq.m_DestAddr, L_ROUTE_ON_GT, 0, 7, (char*)l_mscAddress.c_str());
   m_tdr.setRemoteAddr((char*)l_mscAddress.c_str());

   g_sc.sendMsg(this, &l_mapOpenReq);

   DLOG(0,0,"Sending MapSpecificRequest v3...");
   MapSpecificRequest l_request(m_UserDlgId, MAP_OP_CODE_provideRoamingNumber, MAP_V3);

   DECLARE(OMAP3_ProvideRoamingNumberArg, l_prn, 3, "OMAP3_ProvideRoamingNumberArg", resetStruct);

   l_prn->imsi.length = (strlen((char*)l_imsi.c_str())+1)/2;

   numToBCD((u8*)l_imsi.c_str(), (u8*)(l_prn->imsi.value), strlen(l_imsi.c_str()));

   m_tdr.setChar(TDR_INDEX_REQUEST_TYPE,'I');
   m_tdr.setString(TDR_INDEX_REQUEST_IMSI,(char*)l_imsi.c_str());

   LLOG(0,0,"IMSI sent in PRN [%s]", l_imsi.c_str());

   l_prn->msc_Number.value[0] = 0x91;
   l_prn->msc_Number.length = StringToBCD(&l_prn->msc_Number.value[1],(u8*)l_mscAddress.c_str(),strlen((char*)l_mscAddress.c_str()));
   l_prn->msc_Number.length++;
   LLOG(0,0,"sendPrn: mscnumber-|%s|",(char*)l_mscAddress.c_str());


   l_request.m_structBuffer = (void*)l_prn;
   g_sc.sendMsg(this, &l_request);

   DLOG(0,0,"Sending MapDelimiterReq Req ...");
   MapDelimiterReq l_del(m_UserDlgId);
   g_sc.sendMsg(this, &l_del);

   return true;
}

bool CtxtProvideRoamingNumber::sendv2Prn()
{
   string l_imsi = ConfigReader::readValue(m_DataString, "IMSI");
   if (0 == l_imsi.length())
   {
      CLOG(0,0,"V2:sendPrn:Unknown IMSI");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }

   string l_hlrAddress;
   l_hlrAddress = ConfigReader::readValue(m_DataString, "HLR_NUMBER");
   if(0 == l_hlrAddress.length())
   {
      CLOG(0,0,"V2:sendPrn:Unknown HLR_NUMBER");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }

   string l_mscAddress;
   l_mscAddress = ConfigReader::readValue(m_DataString, "MSC_NUMBER");
   if(0 == l_mscAddress.length())
   {
      CLOG(0,0,"V2:sendPrn:Unknown MSC_ADDRESS");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }


   m_UserDlgId = g_sc.getNewDialogue();
   if(m_UserDlgId < 1)
   {
      ELOG(0,0,"V2:sendPrn:Couldnt get a new dialogue");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }
   DLOG(0,0,"Sending MapOpenReq v2 ...");
   MapOpenReq l_mapOpenReq(m_UserDlgId, MAP_V2);
   l_mapOpenReq.m_ApplCntxt = MAP_AC_CODE_roamingNbEnquiry;
   configureSccpAddress(&l_mapOpenReq.m_OrigAddr, L_ROUTE_ON_GT, 0, g_ConfigData->i_NgConfigData.m_LocalSSN, (char*)l_hlrAddress.c_str());
   m_tdr.setMapVersion(2);
   m_tdr.setString(TDR_INDEX_LOCAL_ADDRESS, (char*)l_hlrAddress.c_str());

   m_tdr.setRemoteAddrSsn(7);
   configureSccpAddress(&l_mapOpenReq.m_DestAddr, L_ROUTE_ON_GT, 0, 7, (char*)l_mscAddress.c_str());
   m_tdr.setRemoteAddr((char*)l_mscAddress.c_str());

   g_sc.sendMsg(this, &l_mapOpenReq);

   DLOG(0,0,"Sending MapSpecificRequest v2...");
   MapSpecificRequest l_request(m_UserDlgId, MAP_OP_CODE_provideRoamingNumber, MAP_V2);

   DECLARE(OMAP2_ProvideRoamingNumberArg, l_prn, 2, "OMAP2_ProvideRoamingNumberArg", resetStruct);

   l_prn->imsi.length = (strlen((char*)l_imsi.c_str())+1)/2;

   numToBCD((u8*)l_imsi.c_str(), (u8*)(l_prn->imsi.value), strlen(l_imsi.c_str()));

   m_tdr.setChar(TDR_INDEX_REQUEST_TYPE,'I');
   m_tdr.setString(TDR_INDEX_REQUEST_IMSI,(char*)l_imsi.c_str());

   LLOG(0,0,"V2:sendPrn: IMSI[%s]", l_imsi.c_str());

   l_prn->msc_Number.value[0] = 0x91;
   l_prn->msc_Number.length = StringToBCD(&l_prn->msc_Number.value[1],(u8*)l_mscAddress.c_str(),strlen((char*)l_mscAddress.c_str()));
   l_prn->msc_Number.length++;
   LLOG(0,0,"V2:sendPrn: MscNumber[%s]",(char*)l_mscAddress.c_str());


   l_request.m_structBuffer = (void*)l_prn;
   g_sc.sendMsg(this, &l_request);

   DLOG(0,0,"Sending MapDelimiterReq Req ...");
   MapDelimiterReq l_del(m_UserDlgId);
   g_sc.sendMsg(this, &l_del);
   return true;
}

bool CtxtProvideRoamingNumber::sendv1Prn()
{
   string l_imsi = ConfigReader::readValue(m_DataString, "IMSI");
   if (0 == l_imsi.length())
   {
      CLOG(0,0,"V1:sendPrn:Unknown IMSI");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }

   string l_hlrAddress;
   l_hlrAddress = ConfigReader::readValue(m_DataString, "HLR_NUMBER");
   if(0 == l_hlrAddress.length())
   {
      CLOG(0,0,"V1:sendPrn:Unknown HLR_NUMBER");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }

   string l_mscAddress;
   l_mscAddress = ConfigReader::readValue(m_DataString, "MSC_NUMBER");
   if(0 == l_mscAddress.length())
   {
      CLOG(0,0,"V1:sendPrn:Unknown MSC_ADDRESS");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }


   m_UserDlgId = g_sc.getNewDialogue();
   if(m_UserDlgId < 1)
   {
      ELOG(0,0,"V1:sendPrn:Couldnt get a new dialogue");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE); 
      return false;
   }
   DLOG(0,0,"V1:sendPrn:Sending MapOpenReq v1 ...");
   MapOpenReq l_mapOpenReq(m_UserDlgId, MAP_V1);
   l_mapOpenReq.m_ApplCntxt = MAP_AC_CODE_roamingNbEnquiry;
   configureSccpAddress(&l_mapOpenReq.m_OrigAddr, L_ROUTE_ON_GT, 0, g_ConfigData->i_NgConfigData.m_LocalSSN, (char*)l_hlrAddress.c_str());
   m_tdr.setMapVersion(1);
   m_tdr.setString(TDR_INDEX_LOCAL_ADDRESS, (char*)l_hlrAddress.c_str());

   m_tdr.setRemoteAddrSsn(7);
   configureSccpAddress(&l_mapOpenReq.m_DestAddr, L_ROUTE_ON_GT, 0, 7, (char*)l_mscAddress.c_str());
   m_tdr.setRemoteAddr((char*)l_mscAddress.c_str());

   g_sc.sendMsg(this, &l_mapOpenReq);

   DLOG(0,0,"V1:sendPrn:Sending MapSpecificRequest v1...");
   MapSpecificRequest l_request(m_UserDlgId, MAP_OP_CODE_provideRoamingNumber, MAP_V1);

   DECLARE(OMAP1_ProvideRoamingNumberArg, l_prn, 1, "OMAP1_ProvideRoamingNumberArg", resetStruct);

   l_prn->imsi.length = (strlen((char*)l_imsi.c_str())+1)/2;

   numToBCD((u8*)l_imsi.c_str(), (u8*)(l_prn->imsi.value), strlen(l_imsi.c_str()));

   m_tdr.setChar(TDR_INDEX_REQUEST_TYPE,'I');
   m_tdr.setString(TDR_INDEX_REQUEST_IMSI,(char*)l_imsi.c_str());

   LLOG(0,0,"V1:sendPrn:IMSI[%s]", l_imsi.c_str());

   l_prn->mscNumber.value[0] = 0x91;
   l_prn->mscNumber.length = StringToBCD(&l_prn->mscNumber.value[1],(u8*)l_mscAddress.c_str(),strlen((char*)l_mscAddress.c_str()));
   l_prn->mscNumber.length++;
   LLOG(0,0,"V1:sendPrn: MscNumber[%s]",(char*)l_mscAddress.c_str());


   l_request.m_structBuffer = (void*)l_prn;
   g_sc.sendMsg(this, &l_request);

   DLOG(0,0,"V1:sendPrn: Sending MapDelimiterReq Req ...");
   MapDelimiterReq l_del(m_UserDlgId);
   g_sc.sendMsg(this, &l_del);
   return true;
}

bool CtxtProvideRoamingNumber::startProcessing(InterModuleData *p_imd, bool& p_DeleteFlag)
{
   DLOG(0,0,"CtxtProvideRoamingNumber::startProcessing data [%s] [%d]",(NULL == p_imd->m_Parameters)?"":p_imd->m_Parameters, p_DeleteFlag);

   if(NULL == p_imd->m_Parameters)
   {
      CLOG(0,0,"p_imd->m_Parameters NULL returning");
      return false;
   }

   char *l_check = NULL;
   l_check = strchr(p_imd->m_Parameters, ':');
   if(l_check == NULL)
   {
      TLOG(0,0,"Transaction ID not present");
      //return false;
   }
   else
   {
      strncpy(m_TransId, p_imd->m_Parameters, strlen(p_imd->m_Parameters)-strlen(l_check)); 
      LLOG(0,0,"Transaction ID :%s", m_TransId);
      m_tdr.setString(TDR_INDEX_OAM_TRANSACTION_ID, m_TransId);
   }

   m_DataString.assign(p_imd->m_Parameters);

   m_sentPrnVer = MAP_V3;
   sendv3Prn();
   return true;
}


bool CtxtProvideRoamingNumber::updateDb(char p_status, char *p_error)
{
   if(0 == strlen(m_TransId))
   {
      return false;
   }

   /*
   CMIstCommandData *l_ist = new CMIstCommandData;
   l_ist->m_DbQueryType=2;
   l_ist->m_cb = this;
   l_ist->m_Status = p_status;
   strcpy(l_ist->m_TransId, m_TransId);
   strcpy(l_ist->m_ErrorCause, p_error);
   g_act.execute(l_ist);
   */
   return true;
}

bool CtxtProvideRoamingNumber::processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag)
{
   DLOG(0,0,"Start of CtxtProvideRoamingNumber::processMsg function");
   MapSpecificMsg *l_specMsg = NULL;

   switch (p_MsgPtr->m_MsgType)
   {
      case MSG_TYPE_MAP:
         switch (((MapMsg*)p_MsgPtr)->m_MapMsgType)
         {
            case MAP_MSG_TYPE_COMMON:
               switch (((MapCommonMsg*)p_MsgPtr)->m_MapCommonMsgType)
               {
                  case MAP_CMN_OPEN_IND:
                     DLOG(0,0,"MAP_CMN_OPEN_IND received with DlgId [%d], Version [%d]", getInitialRespondingDlgId(),
                           getInitialRespondingVersion());
                     break;

                  case MAP_CMN_OPEN_CNF:
                     {
                        CLOG(0,0,"MAP_CMN_OPEN_CNF received version[%d].. The sent MapVersion/AC is not supported by VLR",((MapOpenCnf*)p_MsgPtr)->m_Version);
                        u32 l_abrtDlgId = ((MapMsg*)p_MsgPtr)->m_UserDlgId;
                        EMapVersion l_MapVersion = ((MapOpenCnf*)p_MsgPtr)->m_Version;
                        m_tdr.setInteger(TDR_INDEX_OPEN_CNF_VERSION,(int)l_MapVersion); 
                        if(REFUSE_REASON_APPL_CNTXT_NOT_SUPPORTED == ((MapOpenCnf*)p_MsgPtr)->m_RefuseReasonParam)
                        {
                           CLOG(0,0,"MAP_CMN_OPEN_CNF Received on Prn DlgId-|%d| Sending Prn on Ver-|%d|",l_abrtDlgId,l_MapVersion);
                           if(l_MapVersion != m_sentPrnVer)
                           {
                              switch(l_MapVersion)
                              {
                                 case MAP_V3:
                                    {
                                       m_sentPrnVer = MAP_V3;
                                       sendv3Prn();
                                    }
                                    break;
                                 case MAP_V2:
                                    {
                                       m_sentPrnVer = MAP_V2;
                                       sendv2Prn();
                                    }
                                    break;
                                 case MAP_V1:
                                    {
                                       m_sentPrnVer = MAP_V2;
                                       sendv1Prn();
                                    }
                                    break;
                                 default:
                                    {
                                       CLOG(0,0,"Unknown MapVersion received");
                                    }
                                    break;
                              }
                           }
                           else
                           {
                              CLOG(0,0,"Version initiated and open cnf version are same");
                           }
                        }
                        else
                        {
                           CLOG(0,0,"MAP_CMN_OPEN_CNF received with other reason[%d] on PRN DlgId |%d|",((MapOpenCnf*)p_MsgPtr)->m_RefuseReasonParam,l_abrtDlgId);
                        }
                     }
                     break;

                  case MAP_CMN_DELIMITER_IND:
                     {
                        LLOG(0,0,"MAP_CMN_DELIMITER_IND received ");
                     }
                     break;

                  case MAP_CMN_CLOSE_IND:
                     {
                        DLOG(0,0,"MAP_CMN_CLOSE_IND received");
                     }

                     break;

                  case MAP_CMN_U_ABORT_IND:
                     {
                        WLOG(0,0,"MAP_CMN_U_ABORT_IND received");
                        m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_U_ABORT_RCVD); 
                        updateDb('F', "Received U-Abort");
                     }
                     break;

                  case MAP_CMN_P_ABORT_IND:
                     {
                        WLOG(0,0,"MAP_CMN_P_ABORT_IND received");
                        m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_P_ABORT_RCVD); 
                        updateDb('F', "Received P-Abort");
                     }
                     break;

                  case MAP_CMN_NOTICE_IND:
                     {
                        LLOG(0,0,"MAP_CMN_NOTICE_IND received");
                        m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_NOTICE_RCVD); 
                        MapCloseReq l_closeReq(m_UserDlgId);
                        l_closeReq.m_CloseType = MAP_CLOSE_TYPE_PRE_ARRANGED_END;
                        g_sc.sendMsg(this, &l_closeReq);

                        updateDb('F', "Received Notice");
                     }
                     break;

                  default:
                     ELOG(0,0,"Unknown Msg received [%d]", ((MapCommonMsg*)p_MsgPtr)->m_MapCommonMsgType);
                     break;
               }
               break;

            case MAP_MSG_TYPE_SPECIFIC:
               DLOG(0,0,"MAP_MSG_TYPE_SPECIFIC received [%d]", getInitialRespondingDlgId());
               l_specMsg = (MapSpecificMsg*)p_MsgPtr;

               switch (((MapSpecificMsg*)p_MsgPtr)->m_MapSpecificEventType)
               {
                  case MAP_SPEC_EVENT_CONFIRMATION:
                     {
                        DLOG(0,0,"MAP_SPEC_EVENT_CONFIRMATION received");
                        updateDb('S', "");
                        updatePrnMnrfDb();
                     }
                     break;

                  case MAP_SPEC_EVENT_USER_ERROR:
                     {
                        DLOG(0,0,"MAP_SPEC_EVENT_USER_ERROR received");
                        m_tdr.setInteger(TDR_INDEX_ERR_CODE, ((MapUserError*)p_MsgPtr)->m_ErrorCode); 
                        updateDb('F', "Received USER ERROR");
                     }
                     break;

                  case MAP_SPEC_EVENT_PROV_ERROR:
                     {
                        DLOG(0,0,"MAP_SPEC_EVENT_PROV_ERROR received");
                        m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_PROVIDER_ERROR_RCVD); 
                        DLOG(0,0,"Closing the Dialogue");
                        updateDb('F', "Some Error");
                     }
                     break;
                  default:
                     m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_GENERAL_ERROR); 
                     ELOG(0,0,"ERROR!! Default received");
                     break;
               }
               break;

            default:
               break;
         }
         break;

      case MSG_TYPE_DB:
         {
            DLOG(0,0,"DB message received");
            if(1 ==  ((DbQueryMsg*)p_MsgPtr)->m_DbQueryType)
            {
               CMPrnUpdateMNRF *l_Msg = (CMPrnUpdateMNRF *)p_MsgPtr;
               if(CM_DB_SUCCESS == l_Msg->m_EdbResult)
               {
                  LLOG(0,0,"DBRES: Prn MNRF positive DB Response received");
                  m_tdr.setString(TDR_INDEX_OAM_FREE_FORMAT_DATA, (char*)l_Msg->m_freeFormatData);
               }
               else
               {
                  CLOG(0,0,"DB Failure .. Error Code Value |%d|",(EMapErrorCode)l_Msg->m_errCode);
               }
            }
            else
            {
               ELOG(0,0,"Unknown DB message");
            }
         }
         break;

      default:
         ELOG(0,0,"Unknown message received");
         break;

   }
   return true;
}

