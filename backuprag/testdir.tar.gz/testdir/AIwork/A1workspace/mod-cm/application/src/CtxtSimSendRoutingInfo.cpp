#include <stdio.h>
#include <MapMessages.h>
#include <ServiceCoordinator.h>
#include <Logger.h>
#include "ConfigReader.h"
#include <CMSimConfigReader.h>
#include <CtxtSimSendRoutingInfo.h>
#include <CMSendRoutingInfo.h>
#include <DbActiveObject.h>
#include <DataUnion.h>
#include <IMAP3.h>
#include <IMAP2.h>
#include <IMAP1.h>
#include <OMAP3.h>
#include <OMAP2.h>
#include <OMAP1.h>
#include <Utilities.h>
  /**************************************************************************************************
 19   Function Name      : CtxtGmscSRIReq
 20 Author               :
 21 InParams             : void
 22 OutParam /return val : void
 23 Description          : Constructor
 24  ****************************************************************************************************/
 
 
  CtxtSimSendRoutingInfo :: CtxtSimSendRoutingInfo()
  {
     m_psiPrnFlag = 0;
  }
 
 
  /**************************************************************************************************
 34   Function Name      : CtxtGmscSRIReq
 35 Author               :
 36 InParams             : void
 37 OutParam /return val : void
 38 Description          : Destructor
 39  ****************************************************************************************************/
 
 
  CtxtSimSendRoutingInfo :: ~CtxtSimSendRoutingInfo()
  {
 
  }
 
  //CMSimConfigReader*g_CMSimConfigReaderObj = NULL;

  bool CtxtSimSendRoutingInfo::startProcessing()
  {
     //printf("\n ######### SRI Request #############\n");
     m_psiPrnFlag = g_CMSimConfigReaderObj->m_psiPrn;
     sendSRIReq();
     return true;
  }
 
  bool CtxtSimSendRoutingInfo::sendSRIReq()
  {
     if(g_CMSimConfigReaderObj->m_mapVer == MAP_V3)
     {
        //printf("\n ##### value of nksiginfo %d ######\n",g_GmscSIMConfigObj->m_nkSigInfo);
        DECLARE(OMAP3_SendRoutingInfoArg,l_tempSri,3,"OMAP3_SendRoutingInfoArg",resetStruct);
        int l_UserDlgId = g_sc.getNewDialogue();
        DLOG(l_UserDlgId,0,"###CtxtSimSendRoutingInfo### Start of CtxtSimSendRoutingInfo::sendSRIReq function");
        //printf("\n CtxtGmscSRIReq::sendSRI ######### SRI Request #############\n");
 
        DLOG(l_UserDlgId,0,"###CtxGMSCSRIReq### Sending MapOpenReq ...");
        MapOpenReq l_mapOpenReq(l_UserDlgId, MAP_V3);
        l_mapOpenReq.m_ApplCntxt = MAP_AC_CODE_locInfoRetrieval;
        l_mapOpenReq.m_DestAddr  = g_ConfigData->i_NgConfigData.m_remoteAddress1;
        g_sc.sendMsg(this, &l_mapOpenReq);
 
       DLOG(l_UserDlgId,0,"###CtxtSimSendRoutingInfo### CtxtSimSendRoutingInfo::sendSRI Sending MapSpecificRequest ...");
        MapSpecificRequest l_request(l_UserDlgId, MAP_OP_CODE_sendRoutingInfo, MAP_V3);
 
        //l_tempSri->msisdn.length = 0x07;
        //StringToBCD(&l_tempSri->msisdn.value[0], (unsigned char *)"91919849648321", strlen("91919849648321"));
 
        l_tempSri->msisdn.length = (strlen(g_CMSimConfigReaderObj->m_msisdn)+1)/2 + 1;
        //l_tempSri->msisdn.length = (strlen(g_GmscSIMConfigObj->m_msisdn)+1)/2 ;
        l_tempSri->msisdn.value[0] = 0x91;
        //l_tempSri->msisdn.value[0] = 0x90;
        StringToBCD(&l_tempSri->msisdn.value[1], (unsigned char *)g_CMSimConfigReaderObj->m_msisdn, strlen(g_CMSimConfigReaderObj->m_msisdn));
 
        //StringToBCD(l_tempSri->msisdn.value, (unsigned char *)g_GmscSIMConfigObj->m_msisdn, strlen(g_GmscSIMConfigObj->m_msisdn));
 
  #if 0
 88       l_tempSri->gmsc_OrGsmSCF_Address.length= 0x06;
 89       StringToBCD(&l_tempSri->gmsc_OrGsmSCF_Address.value[0], (unsigned char *)"919789977007", strlen("919789977007"));
 90       l_tempSri->interrogationType = OMAP3_basicCall;
  #endif
        l_tempSri->gmsc_OrGsmSCF_Address.length = (strlen(g_CMSimConfigReaderObj->m_gmscAdd)+1)/2 + 1;
        l_tempSri->gmsc_OrGsmSCF_Address.value[0] = 0xA1;
        StringToBCD(&l_tempSri->gmsc_OrGsmSCF_Address.value[1], (unsigned char *)g_CMSimConfigReaderObj->m_gmscAdd, strlen(g_CMSimConfigReaderObj->m_gmscAdd));
        l_tempSri->interrogationType = OMAP3_basicCall;
        //l_tempSri->interrogationType = OMAP3_unknown;
 
 
        l_tempSri->bit_mask |= OMAP3_SendRoutingInfoArg_callReferenceNumber_present;
       l_tempSri->callReferenceNumber.length=0x05;
       l_tempSri->callReferenceNumber.value[0]=0x17;
       l_tempSri->callReferenceNumber.value[1]=0x0c;
       l_tempSri->callReferenceNumber.value[2]=0xd1;
       l_tempSri->callReferenceNumber.value[3]=0xd5;
       l_tempSri->callReferenceNumber.value[4]=0x15;

       l_tempSri->bit_mask |= OMAP3_SendRoutingInfoArg_longFTN_Supported_present;
       l_tempSri->longFTN_Supported = true;

       /*l_tempSri->bit_mask |= OMAP3_callDiversionTreatmentIndicator_present;
111         l_tempSri->callDiversionTreatmentIndicator.length = 1;
112         l_tempSri->callDiversionTreatmentIndicator.value[0] = g_GmscSIMConfigObj->m_cdiVal;*/

       //l_tempSri->camelInfo.supportedCamelPhases = 0x8000|0x2000;

       if(g_CMSimConfigReaderObj->m_cph == 4)
       {
          l_tempSri->bit_mask |= OMAP3_camelInfo_present;
          l_tempSri->camelInfo.supportedCamelPhases.length = 4;
          l_tempSri->camelInfo.supportedCamelPhases.value[0]=0x80|0x40|0x20|0x10;
       }
       else if(g_CMSimConfigReaderObj->m_cph == 3)
       {
          l_tempSri->bit_mask |= OMAP3_camelInfo_present;
          l_tempSri->camelInfo.supportedCamelPhases.length = 3;
          l_tempSri->camelInfo.supportedCamelPhases.value[0]=0x80|0x40|0x20;
       }
       else if(g_CMSimConfigReaderObj->m_cph == 2)
       {
          l_tempSri->bit_mask |= OMAP3_camelInfo_present;
          l_tempSri->camelInfo.supportedCamelPhases.length = 2;
          l_tempSri->camelInfo.supportedCamelPhases.value[0]=0x80|0x40;
       }
       else if(g_CMSimConfigReaderObj->m_cph == 1)
       {
          l_tempSri->bit_mask |= OMAP3_camelInfo_present;
          l_tempSri->camelInfo.supportedCamelPhases.length = 1;
          l_tempSri->camelInfo.supportedCamelPhases.value[0]=0x80;
       }
       else
       {
          printf("\n No Camel Phase in Request ");
       }

       //if(g_GmscSIMConfigObj->m_psiPrn == 1)
       if(m_psiPrnFlag == 1)
       {
          l_tempSri->camelInfo.bit_mask |= OMAP3_suppress_T_CSI_present;
          l_tempSri->camelInfo.suppress_T_CSI = true;
       }

       if(1 == g_CMSimConfigReaderObj->m_nkSigInfo)//Telephony
       {
          // 04 03 8090A3
             l_tempSri->bit_mask |= OMAP3_SendRoutingInfoArg_networkSignalInfo_present;
          l_tempSri->networkSignalInfo.protocolId = OMAP3_gsm_0408;
          l_tempSri->networkSignalInfo.signalInfo.length = 5;
          //l_tempSri->networkSignalInfo.signalInfo.length = 90;
          l_tempSri->networkSignalInfo.signalInfo.value[0] = 0x04;
          l_tempSri->networkSignalInfo.signalInfo.value[1] = 0x03;
          l_tempSri->networkSignalInfo.signalInfo.value[2] = 0x80;
          l_tempSri->networkSignalInfo.signalInfo.value[3] = 0x90;
          l_tempSri->networkSignalInfo.signalInfo.value[4] = 0xA3;
          /*for(int i=5; i<=89; i++)
165            {
166            l_tempSri->networkSignalInfo.signalInfo.value[i] = 0xA3;
167            }*/
       }
          else if(2 == g_CMSimConfigReaderObj->m_nkSigInfo)//Video
       {
          l_tempSri->bit_mask |= OMAP3_SendRoutingInfoArg_networkSignalInfo_present;
          l_tempSri->networkSignalInfo.protocolId = OMAP3_gsm_0408;
          l_tempSri->networkSignalInfo.signalInfo.length = 10;
          l_tempSri->networkSignalInfo.signalInfo.value[0] = 0x04;
          l_tempSri->networkSignalInfo.signalInfo.value[1] = 0x03;
          l_tempSri->networkSignalInfo.signalInfo.value[2] = 0x88;
          l_tempSri->networkSignalInfo.signalInfo.value[3] = 0x90;
          l_tempSri->networkSignalInfo.signalInfo.value[4] = 0xA6;

          l_tempSri->networkSignalInfo.signalInfo.value[5] = 0x7c;
          l_tempSri->networkSignalInfo.signalInfo.value[6] = 0x03;
          l_tempSri->networkSignalInfo.signalInfo.value[7] = 0x88;
          l_tempSri->networkSignalInfo.signalInfo.value[8] = 0x90;
          l_tempSri->networkSignalInfo.signalInfo.value[9] = 0xA6;
       }
       else if(3 == g_CMSimConfigReaderObj->m_nkSigInfo) //Fax
       {
          l_tempSri->bit_mask |= OMAP3_SendRoutingInfoArg_networkSignalInfo_present;
          l_tempSri->networkSignalInfo.protocolId = OMAP3_gsm_0408;
          //04039090A3 7D029184
          l_tempSri->networkSignalInfo.signalInfo.length = 9;
          l_tempSri->networkSignalInfo.signalInfo.value[0] = 0x04;
          l_tempSri->networkSignalInfo.signalInfo.value[1] = 0x03;
          l_tempSri->networkSignalInfo.signalInfo.value[2] = 0x90;
          l_tempSri->networkSignalInfo.signalInfo.value[3] = 0x90;
          l_tempSri->networkSignalInfo.signalInfo.value[4] = 0xA3;

          l_tempSri->networkSignalInfo.signalInfo.value[5] = 0x7D;
          l_tempSri->networkSignalInfo.signalInfo.value[6] = 0x02;
          l_tempSri->networkSignalInfo.signalInfo.value[7] = 0x91;
          l_tempSri->networkSignalInfo.signalInfo.value[8] = 0x84;
       }
       else if(4 == g_CMSimConfigReaderObj->m_nkSigInfo)//Telephony
       {
          // 04 03 8090A3
          l_tempSri->bit_mask |= OMAP3_SendRoutingInfoArg_networkSignalInfo_present;
          l_tempSri->networkSignalInfo.protocolId = OMAP3_gsm_0408;
          l_tempSri->networkSignalInfo.signalInfo.length = 5;
          l_tempSri->networkSignalInfo.signalInfo.value[0] = 0x04;
          l_tempSri->networkSignalInfo.signalInfo.value[1] = 0x03;
          l_tempSri->networkSignalInfo.signalInfo.value[2] = 0x90;
          l_tempSri->networkSignalInfo.signalInfo.value[3] = 0x90;
          l_tempSri->networkSignalInfo.signalInfo.value[4] = 0xA3;
       }

       else if(5 == g_CMSimConfigReaderObj->m_nkSigInfo)//Telephony
      {
          //7D 02 91 81
          l_tempSri->bit_mask |= OMAP3_SendRoutingInfoArg_networkSignalInfo_present;
          l_tempSri->networkSignalInfo.protocolId = OMAP3_gsm_0408;
          l_tempSri->networkSignalInfo.signalInfo.length = 4;
          l_tempSri->networkSignalInfo.signalInfo.value[0] = 0x7D;
          l_tempSri->networkSignalInfo.signalInfo.value[1] = 0x02;
          l_tempSri->networkSignalInfo.signalInfo.value[2] = 0x91;
          l_tempSri->networkSignalInfo.signalInfo.value[3] = 0x81;

       }

 #if 0
230       l_tempSri->bit_mask |= OMAP3_SendRoutingInfoArg_extensionContainer_present;
231       l_tempSri->extensionContainer.bit_mask |= OMAP3_ExtensionContainer_privateExtensionList_present;
232       l_tempSri->extensionContainer.privateExtensionList.count =  1;
#endif

       OMAP3__ObjectID_ l_extId1;
       OMAP3__ObjectID_ l_extId2;
       OMAP3__ObjectID_ l_extId3;
       OMAP3__ObjectID_ l_extId4;
       OMAP3__ObjectID_ l_extId5;
       OMAP3__ObjectID_ l_extId6;
       OMAP3__ObjectID_ l_extId7;
       OMAP3__ObjectID_ l_extId8;
       OMAP3__ObjectID_ l_extId9;

       l_extId1.value= 1;
       l_extId2.value= 2;
       l_extId3.value=826;
       l_extId4.value=0;
       l_extId5.value=1249;
       l_extId6.value=58;
       l_extId7.value=1;
       l_extId8.value=0;
       //l_extId9.value=0x00;

       l_extId1.next = &l_extId2;
       l_extId2.next = &l_extId3;
       l_extId3.next = &l_extId4;
       l_extId4.next = &l_extId5;
       l_extId5.next = &l_extId6;
       l_extId6.next = &l_extId7;
       l_extId7.next = &l_extId8;
       l_extId8.next = NULL;
 #if 0
264       l_extId9.next = NULL;
 #endif

       //l_tempSri->extensionContainer.privateExtensionList.value[0].extId = &l_extId1;
       //l_tempSri->extensionContainer.privateExtensionList.value[0].extId = new OMAP3__ObjectID_;
       //l_tempSri->extensionContainer.privateExtensionList.value[0].extId->next = NULL;
       //l_tempSri->extensionContainer.privateExtensionList.value[0].extId->value = 1;
       //l_tempSri->extensionContainer.privateExtensionList.value[0].extId->next = NULL;

 #if 1
       //l_tempSri->extensionContainer.privateExtensionList.value[0].bit_mask = OMAP3_extType_present;
       //l_tempSri->extensionContainer.privateExtensionList.value[0].extType.length = 55;
       //char l_extType[] = {0xa4,0x35,0x30,0x03,0x81,0x01,0x11,0x30,0x03,0x81,0x01,0x06,0x30,0x03,0x81,0x01,0x07,0x30,0x18,0x81,0x01,0x09,0xa2,0x13,0x02,0x01,0x01,0x04,0x0e,0x09,0x01,0x0a,0x0a,0x09,0x84,0x13,0x55,0x11,0x99,0x97,0x25,0x82,0x00,0x30,0x03,0x81,0x01,0x0a,0x30,0x05,0x81,0x01,0x0e,0x83,0x00};
       //l_tempSri->extensionContainer.privateExtensionList.value[0].extType.encoded = l_extType;
 #endif


       l_request.m_structBuffer = (void*)l_tempSri;

       g_sc.sendMsg(this, &l_request);

       DLOG(0,0,"###CtxGMSCSRIReq### Sending MapDelimiterReq Req ...");
       MapDelimiterReq l_del(l_UserDlgId);
       g_sc.sendMsg(this, &l_del);
    }

    else if(g_CMSimConfigReaderObj->m_mapVer == MAP_V2)
    {
       DECLARE(OMAP2_SendRoutingInfoArg,l_tempSri,2,"OMAP2_SendRoutingInfoArg",resetStruct);
       int l_UserDlgId = g_sc.getNewDialogue();
       //printf("\n V2:get new dlgId %d",l_UserDlgId);
       DLOG(l_UserDlgId,0,"V2: Start of CtxtSimSendRoutingInfo::sendSRIReq function");
       //printf("\n CtxtGmscSRIReq::sendSRI ######### SRI Request #############\n");

       DLOG(0,0,"V2: Sending MapOpenReq ...");
       MapOpenReq l_mapOpenReq(l_UserDlgId, MAP_V2);

       l_mapOpenReq.m_ApplCntxt = MAP_AC_CODE_locInfoRetrieval;
       l_mapOpenReq.m_DestAddr  = g_ConfigData->i_NgConfigData.m_remoteAddress1;

       g_sc.sendMsg(this, &l_mapOpenReq);

       DLOG(0,0,"v2: CtxtSimSendRoutingInfo::sendSRI Sending MapSpecificRequest ...");
       MapSpecificRequest l_request(l_UserDlgId, MAP_OP_CODE_sendRoutingInfo, MAP_V2);

       //l_tempSri->msisdn.length = 0x07;
       //StringToBCD(&l_tempSri->msisdn.value[0], (unsigned char *)"91919849648321", strlen("91919849648321"));

       l_tempSri->msisdn.length = (strlen(g_CMSimConfigReaderObj->m_msisdn)+1)/2 + 1;
       l_tempSri->msisdn.value[0] = 0x81;
       StringToBCD(&l_tempSri->msisdn.value[1], (unsigned char *)g_CMSimConfigReaderObj->m_msisdn, strlen(g_CMSimConfigReaderObj->m_msisdn));

       l_request.m_structBuffer = (void*)l_tempSri;

       g_sc.sendMsg(this, &l_request);

       DLOG(0,0,"V2: Sending MapDelimiterReq Req ...");
       MapDelimiterReq l_del(l_UserDlgId);
       g_sc.sendMsg(this, &l_del);
    }

    else if(g_CMSimConfigReaderObj->m_mapVer == MAP_V1)
    {
       DECLARE(OMAP1_SendRoutingInformationArg,l_tempSri,1,"OMAP1_SendRoutingInformationArg",resetStruct);
       int l_UserDlgId = g_sc.getNewDialogue();
       //printf("\n V1:get new dlgId %d",l_UserDlgId);
       DLOG(l_UserDlgId,0,"V1: Start of CtxtSimSendRoutingInfo::sendSRIReq function");
       //printf("\n CtxtGmscSRIReq::sendSRI ######### SRI Request #############\n");

       DLOG(0,0,"V1: Sending MapOpenReq ...");
       MapOpenReq l_mapOpenReq(l_UserDlgId, MAP_V1);

       l_mapOpenReq.m_ApplCntxt = MAP_AC_CODE_locInfoRetrieval;
       l_mapOpenReq.m_DestAddr  = g_ConfigData->i_NgConfigData.m_remoteAddress1;
       //configureSccpAddress(&l_mapOpenReq.m_OrigAddr,L_ROUTE_ON_GT,0,209/*gmsc_SSN*/,(char*)"9876543209");
       //configureSccpAddress(&l_mapOpenReq.m_DestAddr,L_ROUTE_ON_GT,0,208/*hlr_SSN*/,(char*)"9876543208");

       g_sc.sendMsg(this, &l_mapOpenReq);

       DLOG(0,0,"v1: CtxtSimSendRoutingInfo::sendSRI Sending MapSpecificRequest ...");
       MapSpecificRequest l_request(l_UserDlgId, MAP_OP_CODE_sendRoutingInfo, MAP_V1);

       l_tempSri->msIsdn.length = (strlen(g_CMSimConfigReaderObj->m_msisdn)+1)/2 + 1;
       //l_tempSri->msisdn.length = (strlen(g_GmscSIMConfigObj->m_msisdn)+1)/2 ;
       l_tempSri->msIsdn.value[0] = 0x91;
       StringToBCD(&l_tempSri->msIsdn.value[1], (unsigned char *)g_CMSimConfigReaderObj->m_msisdn, strlen(g_CMSimConfigReaderObj->m_msisdn));
       //l_tempSri->msIsdn.length = 0x07;
       //StringToBCD(&l_tempSri->msIsdn.value[0], (unsigned char *)"91919849648321", strlen("91919849648321"));

       l_request.m_structBuffer = (void*)l_tempSri;

       g_sc.sendMsg(this, &l_request);

       DLOG(0,0,"V1: Sending MapDelimiterReq Req ...");
       MapDelimiterReq l_del(l_UserDlgId);
       g_sc.sendMsg(this, &l_del);
    }
    return true;
 }

 bool CtxtSimSendRoutingInfo::processMessage(Msg *p_MsgPtr,bool& p_DeleteFlag)
 {
    DLOG(0,0,"###CtxtSimSendRoutingInfo### Start of CtxtSimSendRoutingInfo::processMsg function");
    MapSpecificMsg *l_specMsg = NULL;
    int l_UserDlgId;

    switch (p_MsgPtr->m_MsgType)
    {
       case MSG_TYPE_MAP:
          switch (((MapMsg*)p_MsgPtr)->m_MapMsgType)
          {
             case MAP_MSG_TYPE_COMMON:
                switch (((MapCommonMsg*)p_MsgPtr)->m_MapCommonMsgType)
                {
                   case MAP_CMN_OPEN_IND:
                      DLOG(0,0,"###CtxGMSCSRIReq### MAP_CMN_OPEN_IND received");
                      break;

                   case MAP_CMN_DELIMITER_IND:
                      DLOG(0,0,"###CtxGMSCSRIReq### MAP_CMN_DELIMITER_IND received");
                      break;

                   case MAP_CMN_CLOSE_IND:
                      DLOG(0,0,"###CtxGMSCSRIReq### MAP_CMN_CLOSE_IND received");
                      return true;
                      break;

                   case MAP_CMN_U_ABORT_IND:
                      TLOG(0,0,"###CtxGMSCSRIReq### MAP_CMN_U_ABORT_IND received");
                      break;

                   case MAP_CMN_P_ABORT_IND:
                      TLOG(0,0,"###CtxGMSCSRIReq### MAP_CMN_P_ABORT_IND received");
                      break;

                   case MAP_CMN_NOTICE_IND:
                      {
                         TLOG(0,0,"###CtxGMSCSRIReq### MAP_CMN_NOTICE_IND received");
                      }
                      break;

                   default:
                      TLOG(0,0,"###CtxGMSCSRIReq### Unknown Msg received [%d]", ((MapCommonMsg*)p_MsgPtr)->m_MapCommonMsgType);
                      break;
                }
                break;

             case MAP_MSG_TYPE_SPECIFIC:
                DLOG(0,0,"###CtxGMSCSRIReq### MAP_MSG_TYPE_SPECIFIC received");
                l_specMsg = (MapSpecificMsg*)p_MsgPtr;
                l_UserDlgId = l_specMsg->m_UserDlgId;
                TLOG(0,0,"CtxGMSCSRIReq MAP_MSG_TYPE_SPECIFIC received UserDlgId[%d]",
                      l_UserDlgId);

                switch (((MapSpecificMsg*)p_MsgPtr)->m_MapSpecificEventType)
                {
                   case MAP_SPEC_EVENT_INDICATION:
                      {
                         DLOG(l_UserDlgId,0,"###CtxGMSCSRIReq### MAP_SPEC_EVENT_INDICATION received");

                         switch (((MapSpecificMsg*)p_MsgPtr)->m_OpCode)
                         {
                            case MAP_OP_CODE_sendRoutingInfo:
                              {
                                  DLOG(l_UserDlgId,0,"###CtxGMSCSRIReq### Received SendRoutingInformation");
                               }
                               break;

                            default:
                               DLOG(l_UserDlgId,0,"###CtxGMSCSRIReq### Received Unknown Specific Message");
                               break;

                         }

                      }

                      break;

                   case MAP_SPEC_EVENT_RESULT:
                      {
                         DLOG(l_UserDlgId,0,"###CtxGMSCSRIReq### MAP_SPEC_EVENT_RESULT received");
                      }
                      break;

                   case MAP_SPEC_EVENT_CONFIRMATION:
                      {
                         DLOG(l_UserDlgId,0,"CtxGMSCSRIReq MAP_SPEC_EVENT_CONFIRMATION received");
                         switch (((MapSpecificMsg*)p_MsgPtr)->m_OpCode)
                         {
                            case MAP_OP_CODE_sendRoutingInfo:
                               {
                                  char imsi[21];
                                  char msrn[21];
                                  char msisdn[21];
                                  memset(imsi,'\0',sizeof(imsi));
                                  memset(msrn,'\0',sizeof(msrn));
                                  memset(msisdn,'\0',sizeof(msisdn));
                                  IMAP3_SendRoutingInfoRes *l_temp = (IMAP3_SendRoutingInfoRes*)(((MapSpecificMsg*)p_MsgPtr)->m_structBuffer);
                                  if(l_temp->bit_mask & IMAP3_SendRoutingInfoRes_imsi_present)
                                  {
                                     strncpy(imsi,(char*)l_temp->imsi.value,l_temp->imsi.length);
                                     DLOG(0,0," Recvd IMSI Value |%s| ",imsi);
                                  }
                                  if(l_temp->bit_mask & IMAP3_SendRoutingInfoRes_msisdn_present)
                                  {
                                     strncpy(msisdn,(char*)l_temp->msisdn.value,l_temp->msisdn.length);
                                     DLOG(0,0," Recvd MSISDN Value |%s| ",msisdn);
                                  }
                                  if(l_temp->extendedRoutingInfo.u.routingInfo.choice == IMAP3_roamingNumber_chosen)
                                  {
                                     DLOG_HEX(0,0,"MSRN Value in SRIRes", (char*)l_temp->extendedRoutingInfo.u.routingInfo.u.roamingNumber.value,
                                                 l_temp->extendedRoutingInfo.u.routingInfo.u.roamingNumber.length);
                                  }


                                  if(m_psiPrnFlag == 0)
                                  {
                                     m_psiPrnFlag = 1;
                                     // sendSRIReq();
                                  }

                               }
                             break;

                            default:
                               break;

                         }
                      }
                      break;

                   case MAP_SPEC_EVENT_USER_ERROR:
                      {
                         TLOG(l_UserDlgId,0,"###CtxGMSCSRIReq### MAP_SPEC_EVENT_USER_ERROR received");
                      }
                      break;

                   case MAP_SPEC_EVENT_PROV_ERROR:
                      {
                         TLOG(l_UserDlgId,0,"###CtxGMSCSRIReq### MAP_SPEC_EVENT_PROV_ERROR received");
                         DLOG(l_UserDlgId,0,"###CtxGMSCSRIReq### Closing the Dialogue");
                         MapCloseReq l_closeReq(((MapSpecificMsg*)p_MsgPtr)->m_UserDlgId);
                         g_sc.sendMsg(this, &l_closeReq);
                      }
                      break;
                   default:
                      ELOG(l_UserDlgId,0,"###CtxGMSCSRIReq### ERROR!! Default received");
                      break;

                }


                break;

             default:
                break;
          }
          break;

       case MSG_TYPE_DB:
          {
          }
          break;

       default:
          DLOG(0,0,"###CtxGMSCSRIReq### Unknown message received");
          break;

    }
    return true;

 }






                                                                  
