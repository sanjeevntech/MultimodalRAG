#include <Logger.h>
#include <ModuleBase.h>
#include <MapMessages.h>
#include <ContextBase.h>
#include <CMConfigReader.h>
#include "CMSendRoutingInfo.h"
#include "CMIstCommand.h"
#include "CMSriForLcs.h"
#include "CMProvideRoamingNumber.h"
#include <SnmpInterface.h>
#include <CMSimConfigReader.h>
#include <CtxtSimSendRoutingInfo.h>
#include "CtxtVlrPSIRes.h"
#include "CtxtVlrPRNRes.h"
#include "CtxtSimSriForLcsReq.h"

int g_CMsignalInfoNotFoundTrap = -1;
int g_CMtcsiDetailsNotFoundTrap = -1;
int g_CMEntityAuthFailTrap = -1;

extern bool g_loadFlag;
extern "C" {
   ModuleBase *getModuleObj();
}


class CmModule : public ModuleBase
{
   public:
      CmModule(){};
      bool initModule();
      ContextBase *getCtxtObj(EMapOpCode, MapSpecificMsg*);
      ContextBase *getCtxtObj(EDiameterCommandCode p_OpCode, DiameterMsg* p_msg);
      ContextBase *getCtxtObj(EMapOpCode, SccpMsg*);
      char *getVersion();
      ConfigReader *getConfigReaderObj();
      ConfigReader **retrieveConfigReaderPtr();
};

CmModule g_CmModule;

ModuleBase *getModuleObj()
{
   return &g_CmModule;
}
char *CmModule::getVersion()
{
   RETURN_VERSION(APP_VERSION);//2.0.20.0 2.0.18.0 //2.0.16.0_Rev2 //2.0.15.0 
}

bool CmModule::initModule()
{
   if(true == g_loadFlag)
   {
     m_modName="CMS";
   }
   else
   {
   m_modName="CM";
   LLOG(0,0,"CM APPVER-v:%s ci:%s cd:%s comp:%s %s", APP_VERSION, COMMIT_ID, COMMIT_DATE,__DATE__,__TIME__);
#if 0
   if (NULL == g_CMConfigReaderObj)
   {
      return false;
   }
   if (false == g_CMConfigReaderObj->m_derivedObjectInitializedFlag)
   {
      printf("\nERROR: CM specific configuration file reading is mandatory");
      return false;
   }
#endif 
   g_CMsignalInfoNotFoundTrap = g_si.registerSnmpTrap("BC_TRANS_NF", "SignalInfo not found in BC-Translation", CM_TRAP_SEQ_ID_ONE);
   g_CMtcsiDetailsNotFoundTrap = g_si.registerSnmpTrap("TCSI_DETAILS_NF", "TcsiDetails not found", CM_TRAP_SEQ_ID_TWO);
   g_CMEntityAuthFailTrap = g_si.registerSnmpTrap("ENTITY_AUTH_FAIL","Entity Authentication Failed", CM_TRAP_SEQ_ID_THREE);
   }
   return true;
}
ContextBase *CmModule::getCtxtObj(EMapOpCode p_OpCode, MapSpecificMsg* p_msg)
{
   switch (p_OpCode)
   {
      case MAP_OP_CODE_sendRoutingInfo:
         {
         if(false == g_loadFlag)
         {
            TLOG(0,0,"Newing CMSendRoutingInfo");
            return new CtxtSendRoutingInfo;
         }
         else
         {
            TLOG(0,0,"Newing CtxtSimSendRoutingInfo");
            return new CtxtSimSendRoutingInfo; 
         } 
         }
         break;
      case MAP_OP_CODE_istCommand:
         DLOG(0,0,"Newing CtxtImmediateServiceTermination");
         return new CtxtIstCommand;
         break;

      case MAP_OP_CODE_sendRoutingInfoForLCS:   //85
         {
            if(true == g_loadFlag)
            {
               DLOG(0,0,"Newing CtxtGmlcSriForLcsReq");
               return new CtxtGmlcSriForLcsReq;
            }
            else
            {   
               DLOG(0,0,"Newing CtxtSriForLCS");
               return new CtxtSriForLCS;
            }
         }
         break;
      case MAP_OP_CODE_provideRoamingNumber:
         {
            if(false == g_loadFlag)
            {
               TLOG(0,0,"Newing CMProvideRoamingNumber");
               return new CtxtProvideRoamingNumber;
            }
            else
            {
               TLOG(0,0,"Newing CtxtVlrPRNRes");
               return new CtxtVlrPRNRes; 
            } 
         }
         break;
     case MAP_OP_CODE_provideSubscriberInfo:
         {
            if(true == g_loadFlag)
            {
               TLOG(0,0,"Newing CtxtVlrPSIRes");
               return new CtxtVlrPSIRes;
            }
         }        
         break;
      default:
         DLOG(0,0,"getCmCtxtObj Unknown OpCode [%d]",p_OpCode);
         printf("\ngetCmCtxtObj Unknown OpCode [%d]",p_OpCode);
         return NULL;
         break;
   }
}

ContextBase *CmModule::getCtxtObj(EDiameterCommandCode p_OpCode, DiameterMsg* p_msg)
{
   ELOG(0,0,"Diameter Message not supported");
   return NULL;
}

ContextBase *CmModule::getCtxtObj(EMapOpCode p_OpCode, SccpMsg* p_msg)
{
   ELOG(0,0,"SCCP message not supported");
   return NULL;
}

ConfigReader *CmModule::getConfigReaderObj()
{
      if(true == g_loadFlag)
      {
         LLOG(0,0,"Returning g_CMSimConfigReaderObj");
         return (g_CMSimConfigReaderObj = new CMSimConfigReader);
      }
   LLOG(0,0,"ConfigReader *CmModule::getConfigReaderObj()");
   //return (g_CMConfigReaderObj = new CMConfigReader);
   return new CMConfigReader;
}

ConfigReader **CmModule::retrieveConfigReaderPtr()
{
      if(true == g_loadFlag)
      {
         LLOG(0,0,"ConfigReader Sim **CmModule::retrieveConfigReaderPtr() called");
         return (ConfigReader **)&g_CMSimConfigReaderObj;
      }

   LLOG(0,0,"ConfigReader **CmModule::retrieveConfigReaderPtr() called");
   return (ConfigReader **)&g_CMConfigReaderObj;
}

bool resetStruct(int p_version, int p_pdu, void *p_struct)
{
   if(p_struct == NULL) // just to satisfy compiler against warnings
   {
      ELOG(0,0, "resetStruct called for %d version, %d pdu with NULL structure", p_version, p_pdu);
   }
   return false;
}

