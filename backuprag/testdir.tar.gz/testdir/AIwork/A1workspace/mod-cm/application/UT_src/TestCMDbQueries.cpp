#define private public
#include<iostream>
#include"gtest.h"
#include<CMDbQueries.h>
#include "Logger.h"
#include "CMEnums.h"
#include <UniTypes.h>
#include <DbQueryMsg.h>
#include "CMConstants.h"

class UT_CMSRIDBdata: public testing::Test , public CMSRIDBdata
{public:
UT_CMSRIDBdata()
{
}
~UT_CMSRIDBdata()
{
}
};

class UT_CMPRNPSIDBdata: public testing::Test , public CMPRNPSIDBdata 
{public:
UT_CMPRNPSIDBdata()
{
}
~UT_CMPRNPSIDBdata()
{
}
};

class UT_CMUpdateMNRF: public testing::Test , public CMUpdateMNRF
{public:
UT_CMUpdateMNRF()
{
}
~UT_CMUpdateMNRF()
{
}
};

class UT_CMPrnUpdateMNRF: public testing::Test , public CMPrnUpdateMNRF
{public:
UT_CMPrnUpdateMNRF()
{
}
~UT_CMPrnUpdateMNRF()
{
}
};

class UT_CMIstCommandData: public testing::Test , public CMIstCommandData
{public:
UT_CMIstCommandData()
{
}
~UT_CMIstCommandData()
{
}
};

class UT_SriLCSdata: public testing::Test , public SriLCSdata
{public:
UT_SriLCSdata()
{
//int ErrorCode_DB;
}
~UT_SriLCSdata()
{
}
};
/*
TEST_F(UT_CMPRNPSIDBdata,executeQuery_Func) {
int p_conn[]={1,2,3,4,5,6,7,8,9,10};
EXPECT_FALSE(executeQuery(p_conn));
}
*/

TEST_F(UT_CMPRNPSIDBdata,parseVLRInfo_Func) {
//int p_conn[]={1,2,3,4,5,6,7,8,9,10};
char a='a';
EXPECT_FALSE(parseVLRInfo(&a));
}


TEST_F(UT_CMPRNPSIDBdata,setMsgType_Func) {
EXPECT_NO_THROW(setMsgType(11));
}

TEST_F(UT_CMPRNPSIDBdata,parseForwardInfo_Func) {
char a='a';
EXPECT_FALSE(parseForwardInfo(&a));
}

TEST_F(UT_CMPRNPSIDBdata,parseForwardInfo_Two_Func) {
char a='|';
EXPECT_FALSE(parseForwardInfo(&a));
}


TEST_F(UT_CMUpdateMNRF,executeQuery_Func) {
int a_conn[]={1,2,3,4,5,6,7,8,9,10};
EXPECT_FALSE(executeQuery(a_conn));
}

TEST_F(UT_SriLCSdata,executeQuery_Func) {
int a_conn[]={1,2,3,4,5,6,7,8,9,10};
EXPECT_FALSE(executeQuery(a_conn));
}

TEST_F(UT_CMPrnUpdateMNRF,executeQuery_Func) {
int a_conn[]={1,2,3,4,5,6,7,8,9,10};
EXPECT_FALSE(executeQuery(a_conn));
}

TEST_F(UT_CMIstCommandData,executeQuery_Func) {
int a_conn[]={1,2,3,4,5,6,7,8,9,10};
EXPECT_FALSE(executeQuery(a_conn));
}

/*
TEST_F(UT_SriLCSdata,executeQuery_Two_Func) {
int a_conn[]={1,2,3,4,5,6,7,8,9,10};
SriLCSdata::ErrorCode_DB=0;
EXPECT_TRUE(executeQuery(a_conn));
}
*/

/*
//seg fault
TEST_F(UT_CMPRNPSIDBdata,executeQuery_Func) {
int a_conn[]={1,2,3,4,5,6,7,8,9,10};
EXPECT_FALSE(executeQuery(a_conn));
}
*/



#undef private

