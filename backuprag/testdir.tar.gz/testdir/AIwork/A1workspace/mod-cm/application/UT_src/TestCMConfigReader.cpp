#define private public
#include<iostream>
#include"gtest.h"
#include <Logger.h>
#include <CMConfigReader.h>

extern CMConfigReader *g_CMConfigReaderObj;

class UT_CMConfigReader: public testing::Test , public CMConfigReader
{public:
UT_CMConfigReader()
{
}
~UT_CMConfigReader()
{
}
};

TEST_F(UT_CMConfigReader,readData_Func) {
EXPECT_FALSE(readData());
}

TEST_F(UT_CMConfigReader,printConfigData_Func) {
char a[2000];
EXPECT_NO_THROW(printConfigData(a));
}


#undef private

