#define private public
#include<iostream>
#include"gtest.h"
#include <IMAP1.h>
#include <IMAP2.h>
#include <OMAP1.h>
#include <OMAP2.h>
#include <stdio.h>
#include <Logger.h>
#include <DataUnion.h>
#include <Utilities.h>
#include <MapMessages.h>
#include <DbActiveObject.h>
#include "CMSriForLcs.h"
#include <ServiceCoordinator.h>
#include <SnmpInterface.h>
#include <Msg.h>
#include<MapMessages.h>
#include<DbQueryMsg.h>
#include<CMDbQueries.h>
#include<CMConfigReader.h>

extern int g_CMEntityAuthFailTrap;
//extern IMAP3_RoutingInfoForLCS_Arg *p_SriForLcs;

class UT_CtxtSriForLCS: public testing::Test , public CtxtSriForLCS
{public:
UT_CtxtSriForLCS()
{
}
~UT_CtxtSriForLCS()
{
}
};

class UT_Msg: public testing::Test
{public:
UT_Msg()
{
}
~UT_Msg()
{
}
};

class UT_SriLCSdata: public testing::Test
{public:
UT_SriLCSdata()
{
}
~UT_SriLCSdata()
{
}
};

class UT_CMConfigReader: public testing::Test
{public:
UT_CMConfigReader()
{
}
~UT_CMConfigReader()
{
}
};

class UT_MapCommonMsg: public testing::Test
{public:
UT_MapCommonMsg()
{
}
~UT_MapCommonMsg()
{
}
};

class UT_MapSpecificMsg: public testing::Test
{public:
UT_MapSpecificMsg()
{
}
~UT_MapSpecificMsg()
{
}
};

class UT_DbQueryMsg: public testing::Test
{public:
UT_DbQueryMsg()
{
}
~UT_DbQueryMsg()
{
}
};


TEST_F(UT_CtxtSriForLCS,handleSriForLCS_Func) {
Msg aMsgPtr;
//p_SriForLcs=new IMAP3_RoutingInfoForLCS_Arg;
EXPECT_TRUE(handleSriForLCS(&aMsgPtr,1,0));
}

TEST_F(UT_CtxtSriForLCS,handleError_MAP_ERROR_systemFailure_Func) {
m_ErrCode=34;
EXPECT_TRUE(handleError());
}

TEST_F(UT_CtxtSriForLCS,handleError_MAP_ERROR_unexpectedData_Func) {
m_ErrCode=36;
EXPECT_TRUE(handleError());
}

TEST_F(UT_CtxtSriForLCS,handleError_MAP_ERROR_dataMissing_Func) {
m_ErrCode=35;
EXPECT_TRUE(handleError());
}

TEST_F(UT_CtxtSriForLCS,handleError_MAP_ERROR_unknownSubscriber_Func) {
m_ErrCode=1;
EXPECT_TRUE(handleError());
}

TEST_F(UT_CtxtSriForLCS,handleError_MAP_ERROR_facilityNotSup_Func) {
m_ErrCode=21;
EXPECT_TRUE(handleError());
}

TEST_F(UT_CtxtSriForLCS,handleError_MAP_ERROR_absentSubscriber_Func) {
m_ErrCode=27;
EXPECT_TRUE(handleError());
}

TEST_F(UT_CtxtSriForLCS,handleError_MAP_ERROR_unauthorizedRequestingNetwork_Func) {
m_ErrCode=52;
EXPECT_TRUE(handleError());
}

TEST_F(UT_CtxtSriForLCS,handleError_default_Func) {
m_ErrCode=0;
EXPECT_TRUE(handleError());
}

TEST_F(UT_CtxtSriForLCS,sendSriForLCSResp_Func) {
m_targetMStype=1;
mp_sriLcs=new SriLCSdata;
strcpy(mp_sriLcs->m_HgmlcAddr,"aaaaaaaaaaa");
strcpy(mp_sriLcs->m_HgmlcAddr,"aaaaaaaaaaaaaaaaaa");
strcpy(mp_sriLcs->m_PprAddr,"aaaaaaaaa");
mp_sriLcs->m_LmsiLen=1;
strcpy(mp_sriLcs->m_SgsnNumber,"aaaaaaaaaaaa");
strcpy(mp_sriLcs->m_MscNumber,"aaaaaaaaaaaa");
strcpy(mp_sriLcs->m_CS_VgmlcAddr,"aaaaaaaaaaaaa");
strcpy(mp_sriLcs->m_PS_VgmlcAddr,"aaaaaaaaaaaaaaaa");
mp_sriLcs->m_suppLCScapSets=0x0f;
g_CMConfigReaderObj=new CMConfigReader;
g_CMConfigReaderObj->m_disableLcsCapb=0;
mp_sriLcs->m_suppPSLCScapSets=0x0f;
g_CMConfigReaderObj->m_disableLcsCapb=0;
EXPECT_TRUE(sendSriForLCSResp());
}

TEST_F(UT_CtxtSriForLCS,sendSriForLCSResp_Two_Func) {
m_targetMStype=0;
mp_sriLcs=new SriLCSdata;
strcpy(mp_sriLcs->m_HgmlcAddr,"125.12.0.1");
strcpy(mp_sriLcs->m_PprAddr,"125.12.0.1");
mp_sriLcs->m_LmsiLen=1;
strcpy(mp_sriLcs->m_SgsnNumber,"aaaaaaaaaaaa");
strcpy(mp_sriLcs->m_MscNumber,"aaaaaaaaaaaa");
strcpy(mp_sriLcs->m_CS_VgmlcAddr,"125.12.0.1");
strcpy(mp_sriLcs->m_PS_VgmlcAddr,"125.12.0.1");
mp_sriLcs->m_suppLCScapSets=0x0f;
g_CMConfigReaderObj=new CMConfigReader;
g_CMConfigReaderObj->m_disableLcsCapb=0;
mp_sriLcs->m_suppPSLCScapSets=0x0f;
g_CMConfigReaderObj->m_disableLcsCapb=0;
EXPECT_TRUE(sendSriForLCSResp());
}

TEST_F(UT_CtxtSriForLCS,sendSriForLCSResp_Three_Func) {
m_targetMStype=0;
mp_sriLcs=new SriLCSdata;
strcpy(mp_sriLcs->m_HgmlcAddr,"125.12.0.1");
strcpy(mp_sriLcs->m_PprAddr,"aaaaaa");
mp_sriLcs->m_LmsiLen=4;
strcpy(mp_sriLcs->m_SgsnNumber,"aaaaaaaaaaaa");
strcpy(mp_sriLcs->m_MscNumber,"aaaaaaaaaaaa");
strcpy(mp_sriLcs->m_CS_VgmlcAddr,"aaaaaaaaaaaa");
strcpy(mp_sriLcs->m_PS_VgmlcAddr,"aaaaaaaaaaaaa");
mp_sriLcs->m_suppLCScapSets=0x0f;
g_CMConfigReaderObj=new CMConfigReader;
g_CMConfigReaderObj->m_disableLcsCapb=0;
mp_sriLcs->m_suppPSLCScapSets=0x0f;
g_CMConfigReaderObj->m_disableLcsCapb=0;
EXPECT_TRUE(sendSriForLCSResp());
}

TEST_F(UT_CtxtSriForLCS,sendSriForLCSResp_else_if_Func) {
m_targetMStype=0;
mp_sriLcs=new SriLCSdata;
strcpy(mp_sriLcs->m_HgmlcAddr,"125.12.0.1");
strcpy(mp_sriLcs->m_PprAddr,"aaaaaa");
mp_sriLcs->m_LmsiLen=4;
strcpy(mp_sriLcs->m_CS_VgmlcAddr,"aaaaaaaaaaaa");
strcpy(mp_sriLcs->m_PS_VgmlcAddr,"125.12.0.1");
mp_sriLcs->m_suppLCScapSets=0x0f;
strcpy(mp_sriLcs->m_SgsnNumber,"aaaaaaaaaaaaaaaaaa");
g_CMConfigReaderObj=new CMConfigReader;
g_CMConfigReaderObj->m_disableLcsCapb=0;
mp_sriLcs->m_suppPSLCScapSets=0x0f;
g_CMConfigReaderObj->m_disableLcsCapb=0;
EXPECT_TRUE(sendSriForLCSResp());
}

TEST_F(UT_CtxtSriForLCS,checkSriForLCS_Func) {
IMAP3_RoutingInfoForLCS_Arg obj;
obj.bit_mask='a';
obj.mlcNumber.length=0;
EXPECT_NE(checkSriForLCS(&obj),1000001);
}

TEST_F(UT_CtxtSriForLCS,checkSriForLCS_Two_Func) {
IMAP3_RoutingInfoForLCS_Arg obj;
obj.bit_mask='a';
obj.mlcNumber.length=2;
strcpy(obj.mlcNumber.value,"aaaaaaaa");
obj.targetMS.choice=1;
strcpy(obj.targetMS.u.imsi.value,"aaaaaaa");
obj.targetMS.u.imsi.length=1;
EXPECT_NE(checkSriForLCS(&obj),1000001);
}
 
TEST_F(UT_CtxtSriForLCS,checkSriForLCS_Two_OMAP3_SubscriberIdentity_msisdn_chosen_Func) {
IMAP3_RoutingInfoForLCS_Arg obj;
obj.bit_mask='a';
obj.mlcNumber.length=2;
strcpy(obj.mlcNumber.value,"aaaaaaaa");
obj.targetMS.choice=2;
strcpy(obj.targetMS.u.imsi.value,"aaaaaaa");
obj.targetMS.u.imsi.length=1;
EXPECT_NE(checkSriForLCS(&obj),1000001);
}

TEST_F(UT_CtxtSriForLCS,checkSriForLCS_else_Func) {
IMAP3_RoutingInfoForLCS_Arg obj;
obj.bit_mask='a';
obj.mlcNumber.length=2;
strcpy(obj.mlcNumber.value,"aaaaaaaa");
obj.targetMS.choice=0;
strcpy(obj.targetMS.u.imsi.value,"aaaaaaa");
obj.targetMS.u.imsi.length=1;
EXPECT_NE(checkSriForLCS(&obj),1000001);
}

TEST_F(UT_CtxtSriForLCS,handleDbQuery_Func) {
EXPECT_TRUE(handleDbQuery());
}

TEST_F(UT_CtxtSriForLCS,processMessage_MAP_CMN_OPEN_IND_Func) {
MapCommonMsg aMsgPtr;
aMsgPtr.m_MsgType=1;
aMsgPtr.m_MapMsgType=1;
aMsgPtr.m_MapCommonMsgType=202;
bool aDeleteFlag=true;
EXPECT_TRUE(processMessage(&aMsgPtr,aDeleteFlag));
}

TEST_F(UT_CtxtSriForLCS,processMessage_MAP_CMN_DELIMITER_IND_Func) {
MapCommonMsg aMsgPtr;
aMsgPtr.m_MsgType=1;
aMsgPtr.m_MapMsgType=1;
aMsgPtr.m_MapCommonMsgType=208;
bool aDeleteFlag=true;
EXPECT_TRUE(processMessage(&aMsgPtr,aDeleteFlag));
}

TEST_F(UT_CtxtSriForLCS,processMessage_MAP_CMN_CLOSE_IND_Func) {
MapCommonMsg aMsgPtr;
aMsgPtr.m_MsgType=1;
aMsgPtr.m_MapMsgType=1;
aMsgPtr.m_MapCommonMsgType=206;
bool aDeleteFlag=true;
EXPECT_TRUE(processMessage(&aMsgPtr,aDeleteFlag));
}

TEST_F(UT_CtxtSriForLCS,processMessage_MAP_CMN_OPEN_CNF_Func) {
MapCommonMsg aMsgPtr;
aMsgPtr.m_MsgType=1;
aMsgPtr.m_MapMsgType=1;
aMsgPtr.m_MapCommonMsgType=204;
bool aDeleteFlag=true;
EXPECT_TRUE(processMessage(&aMsgPtr,aDeleteFlag));
}

TEST_F(UT_CtxtSriForLCS,processMessage_MAP_CMN_U_ABORT_IND_Func) {
MapCommonMsg aMsgPtr;
aMsgPtr.m_MsgType=1;
aMsgPtr.m_MapMsgType=1;
aMsgPtr.m_MapCommonMsgType=210;
bool aDeleteFlag=true;
EXPECT_TRUE(processMessage(&aMsgPtr,aDeleteFlag));
}

TEST_F(UT_CtxtSriForLCS,processMessage_MAP_CMN_P_ABORT_IND_Func) {
MapCommonMsg aMsgPtr;
aMsgPtr.m_MsgType=1;
aMsgPtr.m_MapMsgType=1;
aMsgPtr.m_MapCommonMsgType=212;
bool aDeleteFlag=true;
EXPECT_TRUE(processMessage(&aMsgPtr,aDeleteFlag));
}

TEST_F(UT_CtxtSriForLCS,processMessage_MAP_CMN_NOTICE_IND_Func) {
MapCommonMsg aMsgPtr;
aMsgPtr.m_MsgType=1;
aMsgPtr.m_MapMsgType=1;
aMsgPtr.m_MapCommonMsgType=213;
bool aDeleteFlag=true;
EXPECT_TRUE(processMessage(&aMsgPtr,aDeleteFlag));
}

TEST_F(UT_CtxtSriForLCS,processMessage_MapCommonMsg_default_Func) {
MapCommonMsg aMsgPtr;
aMsgPtr.m_MsgType=1;
aMsgPtr.m_MapMsgType=1;
aMsgPtr.m_MapCommonMsgType=0;
bool aDeleteFlag=true;
EXPECT_TRUE(processMessage(&aMsgPtr,aDeleteFlag));
}

TEST_F(UT_CtxtSriForLCS,processMessage_MAP_OP_CODE_sendRoutingInfoForLCS_Func) {
MapSpecificMsg aMsgPtr;
aMsgPtr.m_MsgType=1;
aMsgPtr.m_MapMsgType=2;
aMsgPtr.m_MapSpecificEventType=2;
aMsgPtr.m_OpCode=85;
aMsgPtr.m_allocatedFlag=false;
bool aDeleteFlag=true;
EXPECT_TRUE(processMessage(&aMsgPtr,aDeleteFlag));
}

TEST_F(UT_CtxtSriForLCS,processMessage_MAP_OP_CODE_sendRoutingInfoForLCS_else_Func) {
MapSpecificMsg aMsgPtr;
aMsgPtr.m_MsgType=1;
aMsgPtr.m_MapMsgType=2;
aMsgPtr.m_MapSpecificEventType=2;
aMsgPtr.m_OpCode=85;
aMsgPtr.m_allocatedFlag=true;
bool aDeleteFlag=true;
EXPECT_TRUE(processMessage(&aMsgPtr,aDeleteFlag));
}


TEST_F(UT_CtxtSriForLCS,processMessage_MAP_OP_CODE_sendRoutingInfoForLCS_default_Func) {
MapSpecificMsg aMsgPtr;
aMsgPtr.m_MsgType=1;
aMsgPtr.m_MapMsgType=2;
aMsgPtr.m_MapSpecificEventType=2;
aMsgPtr.m_OpCode=0;
aMsgPtr.m_allocatedFlag=true;
bool aDeleteFlag=true;
EXPECT_TRUE(processMessage(&aMsgPtr,aDeleteFlag));
}

TEST_F(UT_CtxtSriForLCS,processMessage_MAP_SPEC_EVENT_RESULT_Func) {
MapSpecificMsg aMsgPtr;
aMsgPtr.m_MsgType=1;
aMsgPtr.m_MapMsgType=2;
aMsgPtr.m_MapSpecificEventType=3;
bool aDeleteFlag=true;
EXPECT_TRUE(processMessage(&aMsgPtr,aDeleteFlag));
}

TEST_F(UT_CtxtSriForLCS,processMessage_MAP_SPEC_EVENT_CONFIRMATION_Func) {
MapSpecificMsg aMsgPtr;
aMsgPtr.m_MsgType=1;
aMsgPtr.m_MapMsgType=2;
aMsgPtr.m_MapSpecificEventType=4;
bool aDeleteFlag=true;
EXPECT_TRUE(processMessage(&aMsgPtr,aDeleteFlag));
}

TEST_F(UT_CtxtSriForLCS,processMessage_MAP_SPEC_EVENT_USER_ERROR_Func) {
MapSpecificMsg aMsgPtr;
aMsgPtr.m_MsgType=1;
aMsgPtr.m_MapMsgType=2;
aMsgPtr.m_MapSpecificEventType=5;
bool aDeleteFlag=true;
EXPECT_TRUE(processMessage(&aMsgPtr,aDeleteFlag));
}

TEST_F(UT_CtxtSriForLCS,processMessage_MAP_SPEC_EVENT_PROV_ERROR_Func) {
MapSpecificMsg aMsgPtr;
aMsgPtr.m_MsgType=1;
aMsgPtr.m_MapMsgType=2;
aMsgPtr.m_MapSpecificEventType=6;
bool aDeleteFlag=true;
EXPECT_TRUE(processMessage(&aMsgPtr,aDeleteFlag));
}

TEST_F(UT_CtxtSriForLCS,processMessage_MapSpecificMsg_default_Func) {
MapSpecificMsg aMsgPtr;
aMsgPtr.m_MsgType=1;
aMsgPtr.m_MapMsgType=2;
aMsgPtr.m_MapSpecificEventType=6;
bool aDeleteFlag=true;
EXPECT_TRUE(processMessage(&aMsgPtr,aDeleteFlag));
}

TEST_F(UT_CtxtSriForLCS,processMessage_MapMsg_default_Func) {
MapSpecificMsg aMsgPtr;
aMsgPtr.m_MsgType=1;
aMsgPtr.m_MapMsgType=0;
bool aDeleteFlag=true;
EXPECT_TRUE(processMessage(&aMsgPtr,aDeleteFlag));
}

TEST_F(UT_CtxtSriForLCS,processMessage_MSG_TYPE_DB_one_Func) {
SriLCSdata aMsgPtr;
aMsgPtr.m_MsgType=2;
strcpy(aMsgPtr.m_HlrAddr,"aaaaaaaaa");
aMsgPtr.m_EdbResult=0;
bool aDeleteFlag=true;
EXPECT_TRUE(processMessage(&aMsgPtr,aDeleteFlag));
}

TEST_F(UT_CtxtSriForLCS,sendSriForLCSResp_else_Four_Func) {
m_targetMStype=0;
mp_sriLcs=new SriLCSdata;
strcpy(mp_sriLcs->m_HgmlcAddr,"125.12.0.1");
strcpy(mp_sriLcs->m_PprAddr,"aaaaaa");
mp_sriLcs->m_LmsiLen=4;
strcpy(mp_sriLcs->m_CS_VgmlcAddr,"125.12.0.1");
strcpy(mp_sriLcs->m_PS_VgmlcAddr,"125.12.0.1");
mp_sriLcs->m_suppLCScapSets=0x0f;
g_CMConfigReaderObj=new CMConfigReader;
g_CMConfigReaderObj->m_disableLcsCapb=0;
mp_sriLcs->m_suppPSLCScapSets=0x0f;
g_CMConfigReaderObj->m_disableLcsCapb=0;
EXPECT_TRUE(sendSriForLCSResp());
}

TEST_F(UT_CtxtSriForLCS,sendSriForLCSResp_else_Five_Func) {
m_targetMStype=0;
mp_sriLcs=new SriLCSdata;
strcpy(mp_sriLcs->m_HgmlcAddr,"125.12.0.1");
strcpy(mp_sriLcs->m_PprAddr,"aaaaaa");
mp_sriLcs->m_LmsiLen=4;
strcpy(mp_sriLcs->m_CS_VgmlcAddr,"aaaaaaaaaa");
strcpy(mp_sriLcs->m_PS_VgmlcAddr,"125.12.0.1");
mp_sriLcs->m_suppLCScapSets=0x01;
g_CMConfigReaderObj=new CMConfigReader;
g_CMConfigReaderObj->m_disableLcsCapb=0;
mp_sriLcs->m_suppPSLCScapSets=0x0f;
g_CMConfigReaderObj->m_disableLcsCapb=0;
EXPECT_TRUE(sendSriForLCSResp());
}

/*
TEST_F(UT_CtxtSriForLCS,processMessage_MSG_TYPE_DB_Two_Func) {
SriLCSdata aMsgPtr;
aMsgPtr.m_MsgType=2;
aMsgPtr.m_DbQueryType=1;
mp_sriLcs=new SriLCSdata;
//strcpy(mp_sriLcs->m_HlrAddr,"aaaaaaaa");
//aMsgPtr.m_EdbResult=0;
//aMsgPtr.m_errCode=52;
//strcpy(aMsgPtr.m_HlrAddr,"aaaaaaaaa");
//aMsgPtr.m_EdbResult=0;
bool aDeleteFlag=true;
EXPECT_TRUE(processMessage(&aMsgPtr,aDeleteFlag));
}
*/

#undef private


