#define private public
#include<iostream>
#include"gtest.h"
#include <OMAP1.h>
#include <OMAP2.h>
#include "Logger.h"
#include "CMUtility.h"
#include <Utilities.h>
#include <ServiceCoordinator.h>
#include "CMSendRoutingInfo.h"
#include<ContextBase.h>
#include<CMSriForLcs.h>
#include<CMDbQueries.h>

class UT_CMUtility: public testing::Test , public CMUtility
{public:
UT_CMUtility()
{
}
~UT_CMUtility()
{
}
};

class UT_ContextBase: public testing::Test 
{public:
UT_ContextBase()
{
}
~UT_ContextBase()
{
}
};

class UT_CtxtSriForLCS: public testing::Test
{public:
UT_CtxtSriForLCS()
{
}
~UT_CtxtSriForLCS()
{
}
};

class UT_CMPRNPSIDBdata: public testing::Test
{public:
UT_CMPRNPSIDBdata()
{
}
~UT_CMPRNPSIDBdata()
{
}
};


TEST_F(UT_CMUtility,DPSupportedInCamelPhase_Func) {
EXPECT_TRUE(DPSupportedInCamelPhase(14,0x20));
}

TEST_F(UT_CMUtility,DPSupportedInCamelPhase_CM_TNOANSWER_Func) {
EXPECT_TRUE(DPSupportedInCamelPhase(14,0x40));
}

TEST_F(UT_CMUtility,DPSupportedInCamelPhase_CM_CAMELPHASE2_default_Func) {
EXPECT_FALSE(DPSupportedInCamelPhase(0,0x40));
}

TEST_F(UT_CMUtility,DPSupportedInCamelPhase_CM_TERMATTEMPTAUTHORIZED_Func) {
EXPECT_TRUE(DPSupportedInCamelPhase(12,0x80));
}

TEST_F(UT_CMUtility,DPSupportedInCamelPhase_CM_CAMELPHASE1_default_Func) {
EXPECT_FALSE(DPSupportedInCamelPhase(0,0x80));
}

TEST_F(UT_CMUtility,sendSRIRESULTLAST_MAP_V2_Func) {
CtxtSriForLCS obj;
OMAP2_SendRoutingInfoRes obj1;
EXPECT_TRUE(sendSRIRESULTLAST(&obj,1,1,2,&obj1));
}

TEST_F(UT_CMUtility,sendSRIRESULTLAST_MAP_V1_Func) {
CtxtSriForLCS obj;
OMAP2_SendRoutingInfoRes obj1;
EXPECT_TRUE(sendSRIRESULTLAST(&obj,1,1,1,&obj1));
}

TEST_F(UT_CMUtility,sendSRIRESULTNOTLAST_Func) {
CtxtSriForLCS obj;
OMAP3_SendRoutingInfoRes obj1;
EXPECT_TRUE(sendSRIRESULTNOTLAST(&obj,1,1,1,&obj1));
}

TEST_F(UT_CMUtility,getBSGroup_CM_BEARER_SERVICE_TYPE_Func) {
EXPECT_NE(getBSGroup(1,1),101010);
}

TEST_F(UT_CMUtility,getBSGroup_CM_TELESERVICE_TYPE_Func) {
EXPECT_NE(getBSGroup(1,2),101010);
}

TEST_F(UT_CMUtility,getBSGroup_default_Func) {
EXPECT_NE(getBSGroup(1,0),101010);
}

TEST_F(UT_CMUtility,BCDToChar_If_Func) {
U8 aChar[100];
U8 aBcd[10]={0xF0,0xF0,0xF0,0xF0,0xF0};
EXPECT_NE(BCDToChar(aChar,aBcd,1),10101);
}

TEST_F(UT_CMUtility,BCDToChar_else_Func) {
U8 aChar[100];
U8 aBcd[10]={0x00,0x00,0x00,0x00,0x00};
EXPECT_NE(BCDToChar(aChar,aBcd,1),10101);
}

TEST_F(UT_CMUtility,CharToBCD_Func) {
U8 aBcd[100];
U8 aChar[100]={1,2,3,4};
EXPECT_NE(CharToBCD(aBcd,aChar,4),10101);
}

TEST_F(UT_CMUtility,PrintHex_len_Func) {
EXPECT_FALSE(PrintHex("aaaa","aaaaa",301));
}

TEST_F(UT_CMUtility,PrintHex_for_Func) {
EXPECT_TRUE(PrintHex("aaaa","aaaaa",300));
}

TEST_F(UT_CMUtility,getSuppCamelPhsVmsc_0x01_Func) {
OMAP3_SendRoutingInfoRes obj;
CMPRNPSIDBdata aDBdata;
aDBdata.m_SupportedCamelPhaseVmsc=0xff;
EXPECT_TRUE(getSuppCamelPhsVmsc(&obj,&aDBdata));
}

#undef private

