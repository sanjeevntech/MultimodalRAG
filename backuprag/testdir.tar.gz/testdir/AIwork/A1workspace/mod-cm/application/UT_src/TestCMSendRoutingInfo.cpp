#define private public
#include<iostream>
#include"gtest.h"
#include <IMAP1.h>
#include <IMAP2.h>
#include <OMAP1.h>
#include <OMAP2.h>
#include <stdio.h>
#include <Logger.h>
#include <DataUnion.h>
#include <Utilities.h>
#include <MapMessages.h>
#include <DbActiveObject.h>
#include "CMSendRoutingInfo.h"
#include <ServiceCoordinator.h>
#include <SnmpInterface.h>
#include <CMDbQueries.h>
#include<CMSendRoutingInfo.h>
#include<CMConfigReader.h>
#include<SubsProfileData.h>
#include<MapConstants.h>
#include<OMAP3.h>
#include<Msg.h>
#include<IMAP3.h>

extern int g_CMsignalInfoNotFoundTrap;
extern int g_CMtcsiDetailsNotFoundTrap;
extern int g_CMEntityAuthFailTrap;

class UT_CtxtSendRoutingInfo: public testing::Test , public CtxtSendRoutingInfo
{public:
UT_CtxtSendRoutingInfo()
{
}
~UT_CtxtSendRoutingInfo()
{
}
};

class UT_CMSRIDBdata
{public:
UT_CMSRIDBdata()
{
}
~UT_CMSRIDBdata()
{
}
};

class UT_SubsProfileData
{public:
UT_SubsProfileData()
{
}
~UT_SubsProfileData()
{
}
};
class UT_CMConfigReader
{public:
UT_CMConfigReader()
{
}
~UT_CMConfigReader()
{
}
};

class UT_CMPRNPSIDBdata
{public:
UT_CMPRNPSIDBdata()
{
}
~UT_CMPRNPSIDBdata()
{
}
};


class UT_MapSpecificMsg
{public:
UT_MapSpecificMsg()
{
}
~UT_MapSpecificMsg()
{
}
};


TEST_F(UT_CtxtSendRoutingInfo,updateDb_Func) 
{	
CtxtSendRoutingInfo objCtxtSendRoutingInfo;
g_CMConfigReaderObj=new CMConfigReader;
g_CMConfigReaderObj->m_mnrfFlag=1;
EXPECT_TRUE(objCtxtSendRoutingInfo.updateDb(1));
}

TEST_F(UT_CtxtSendRoutingInfo,updateDb_Two_Func)
{
CtxtSendRoutingInfo objCtxtSendRoutingInfo;
g_CMConfigReaderObj=new CMConfigReader;
g_CMConfigReaderObj->m_mnrfFlag=0;
EXPECT_TRUE(objCtxtSendRoutingInfo.updateDb(1));
}


TEST_F(UT_CtxtSendRoutingInfo,sendSRIResSSList_Func) {
CMSRIDBdata *aDBdata;
mp_sriSubData=new CMPRNPSIDBdata;
aDBdata=new CMPRNPSIDBdata;
EXPECT_TRUE(sendSRIResSSList());
}

TEST_F(UT_CtxtSendRoutingInfo,sendSRIResMsrnFtn_MAP_V3_Func) {
m_MapVer=3;
mp_sriSubData=new CMPRNPSIDBdata;
EXPECT_TRUE(sendSRIResMsrnFtn());
}

TEST_F(UT_CtxtSendRoutingInfo,sendSRIResMsrnFtn_MAP_V2_Func) {
m_MapVer=2;
mp_sriSubData=new CMPRNPSIDBdata;
EXPECT_TRUE(sendSRIResMsrnFtn());
}

TEST_F(UT_CtxtSendRoutingInfo,sendSRIResMsrnFtn_MAP_V1_Func) {
m_MapVer=1;
mp_sriSubData=new CMPRNPSIDBdata;
EXPECT_TRUE(sendSRIResMsrnFtn());
}

TEST_F(UT_CtxtSendRoutingInfo,sendSRIResMsrnFtn_default_Func) {
m_MapVer=0;
mp_sriSubData=new CMPRNPSIDBdata;
EXPECT_TRUE(sendSRIResMsrnFtn());
}

TEST_F(UT_CtxtSendRoutingInfo,fillCauseValues_Func) {
OMAP3_GmscCamelSubscriptionInfo *ptr=new OMAP3_GmscCamelSubscriptionInfo ;
EXPECT_NO_THROW(fillCauseValues(ptr));
delete ptr;
}

TEST_F(UT_CtxtSendRoutingInfo,sendPSI_Func) {
mp_sriSubData=new CMPRNPSIDBdata;
EXPECT_TRUE(sendPSI());
}

TEST_F(UT_CtxtSendRoutingInfo,sendV1PRN_Func) {
mp_sriSubData=new CMPRNPSIDBdata;
CtxtSendRoutingInfo::m_networkSigInfo=true;
mp_sriSubData->m_bcFlag=1;
mp_sriSubData->m_bearerCapLen=10;
strcpy(mp_sriSubData->m_ActiveMsisdn,"aaaaaaaaaaaa");
mp_sriSubData->m_LmsiLen=1;
EXPECT_TRUE(sendV1PRN());
}

TEST_F(UT_CtxtSendRoutingInfo,sendV2PRN_Func) {
mp_sriSubData=new CMPRNPSIDBdata;
CtxtSendRoutingInfo::m_networkSigInfo=true;
//mp_sriSubData->m_bcFlag=1;
//mp_sriSubData->m_bearerCapLen=10;
//strcpy(mp_sriSubData->m_ActiveMsisdn,"aaaaaaaaaaaa");
//mp_sriSubData->m_LmsiLen=1;
EXPECT_TRUE(sendV2PRN());
}


TEST_F(UT_CtxtSendRoutingInfo,handleError_Func) {
CtxtSendRoutingInfo::m_ErrCode=36;
EXPECT_TRUE(handleError());
}

TEST_F(UT_CtxtSendRoutingInfo,handleError_MAP_ERROR_dataMissing_Func) {
CtxtSendRoutingInfo::m_ErrCode=35;
EXPECT_TRUE(handleError());
}

TEST_F(UT_CtxtSendRoutingInfo,handleError_MAP_ERROR_unknownSubscriber_Func) {
CtxtSendRoutingInfo::m_ErrCode=1;
EXPECT_TRUE(handleError());
}

TEST_F(UT_CtxtSendRoutingInfo,handleError_MAP_ERROR_forwardingViolation_Func) {
CtxtSendRoutingInfo::m_ErrCode=14;
EXPECT_TRUE(handleError());
}

TEST_F(UT_CtxtSendRoutingInfo,handleError_MAP_ERROR_facilityNotSup_Func) {
CtxtSendRoutingInfo::m_ErrCode=21;
EXPECT_TRUE(handleError());
}

TEST_F(UT_CtxtSendRoutingInfo,handleError_MAP_ERROR_orNotAllowed_Func) {
CtxtSendRoutingInfo::m_ErrCode=48;
EXPECT_TRUE(handleError());
}

TEST_F(UT_CtxtSendRoutingInfo,handleError_MAP_ERROR_callBarred_Func) {
CtxtSendRoutingInfo::m_ErrCode=13;
mp_sriSubData=new CMPRNPSIDBdata;
m_MapVer=3;
EXPECT_TRUE(handleError());
}

TEST_F(UT_CtxtSendRoutingInfo,handleError_MAP_ERROR_teleservNotProv_Func) {
CtxtSendRoutingInfo::m_ErrCode=11;
EXPECT_TRUE(handleError());
}

TEST_F(UT_CtxtSendRoutingInfo,handleError_MAP_ERROR_bearerServNotProv_Func) {
CtxtSendRoutingInfo::m_ErrCode=10;
EXPECT_TRUE(handleError());
}

TEST_F(UT_CtxtSendRoutingInfo,handleError_MAP_ERROR_absentSubscriber_Func) {
CtxtSendRoutingInfo::m_ErrCode=6;
EXPECT_TRUE(handleError());
}

TEST_F(UT_CtxtSendRoutingInfo,handleError_MAP_ERROR_CUG_Reject_Func) {
CtxtSendRoutingInfo::m_ErrCode=15;
EXPECT_TRUE(handleError());
}

TEST_F(UT_CtxtSendRoutingInfo,handleError_MAP_ERROR_callBarred_MAP_V3_Func) {
CtxtSendRoutingInfo::m_ErrCode=13;
mp_sriSubData=new CMPRNPSIDBdata;
m_MapVer=3;
mp_sriSubData->m_dbErrCode=-3;
EXPECT_TRUE(handleError());
}

TEST_F(UT_CtxtSendRoutingInfo,handleError_MAP_ERROR_callBarred_MAP_V3_else_if_Func) {
CtxtSendRoutingInfo::m_ErrCode=13;
mp_sriSubData=new CMPRNPSIDBdata;
m_MapVer=3;
mp_sriSubData->m_dbErrCode=-6;
EXPECT_TRUE(handleError());
}

TEST_F(UT_CtxtSendRoutingInfo,handleError_MAP_ERROR_callBarred_MAP_V2_if_Func) {
CtxtSendRoutingInfo::m_ErrCode=13;
mp_sriSubData=new CMPRNPSIDBdata;
m_MapVer=2;
mp_sriSubData->m_dbErrCode=-3;
EXPECT_TRUE(handleError());
}

TEST_F(UT_CtxtSendRoutingInfo,handleError_MAP_ERROR_callBarred_MAP_V2_else_if_Func) {
CtxtSendRoutingInfo::m_ErrCode=13;
mp_sriSubData=new CMPRNPSIDBdata;
m_MapVer=3;
mp_sriSubData->m_dbErrCode=-6;
EXPECT_TRUE(handleError());
}

TEST_F(UT_CtxtSendRoutingInfo,sendPRN_func) {
EXPECT_TRUE(sendPRN());
}

TEST_F(UT_CtxtSendRoutingInfo,sendSRIResOnlyFTN_Func) {
m_MapVer=3;
mp_sriSubData=new CMPRNPSIDBdata;
mp_sriSubData->m_fwdInfo.m_fwdOptions=0x01;;
EXPECT_TRUE(sendSRIResOnlyFTN());
}

TEST_F(UT_CtxtSendRoutingInfo,sendSRIResPRN_default_Func) {
Msg obj;
//aPRNRes=new IMAP3_ISDN_AddressString;
m_MapVer=0;
EXPECT_TRUE(sendSRIResPRN(&obj));
}

/*extern g_spdPtr ((SubsProfileData*)g_spd);
TEST_F(UT_CtxtSendRoutingInfo ,getCC_Func) {
//g_spdPtr=new SubsProfileData;
strcpy(g_spdPtr->m_CCRowCount,"aaaaaaa");
EXPECT_TRUE(getCC());
}*/

/*
TEST_F(UT_CtxtSendRoutingInfo,sendSRIResPRN_Func) {
Msg obj;
MapSpecificMsg *ptr=new MapSpecificMsg;
ptr->m_structBuffer=1;
m_MapVer=1;
EXPECT_TRUE(sendSRIResPRN(&obj));
delete ptr;
}
*/

/*
TEST(UT_CtxtSendRoutingInfo,getCC_Func) {
CtxtSendRoutingInfo objCtxtSendRoutingInfo;
g_spd=new GlobalData;
g_spdPtr->m_CCRowCount=1;
EXPECT_TRUE(objCtxtSendRoutingInfo.getCC());
}
*/
/*
//seg fault
TEST(UT_CtxtSendRoutingInfo,getTcsiStatus_Func)
{
CtxtSendRoutingInfo objCtxtSendRoutingInfo;
g_spd=new GlobalData;
objCtxtSendRoutingInfo.m_nonTelephony=true;
objCtxtSendRoutingInfo.mp_sriSubData=new CMPRNPSIDBdata;
objCtxtSendRoutingInfo.mp_sriSubData->m_bsrvcType=100;
EXPECT_NE(objCtxtSendRoutingInfo.getTcsiStatus(),1);
}
*/

/*TEST(UT_CtxtSendRoutingInfo,getPsiStatus_Func) {
g_spd=new GlobalData;
CtxtSendRoutingInfo::m_nonTelephony=true;
mp_sriSubData=new CMSRIDBdata;
mp_sriSubData->m_bsrvcType=true;
EXPECT_FALSE(getPsiStatus());
}*/

#undef private
