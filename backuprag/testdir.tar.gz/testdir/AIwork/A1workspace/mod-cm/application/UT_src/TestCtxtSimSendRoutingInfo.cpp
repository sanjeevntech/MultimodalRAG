#define private public
#include<iostream>
#include"gtest.h"
#include <IMAP1.h>
#include <IMAP2.h>
#include <OMAP1.h>
#include <OMAP2.h>
#include <stdio.h>
#include <Logger.h>
#include <DataUnion.h>
#include <Utilities.h>
#include <MapMessages.h>
#include <DbActiveObject.h>
#include <CMSendRoutingInfo.h>
#include <CtxtSimSendRoutingInfo.h>
#include <ServiceCoordinator.h>
#include <CMDbQueries.h>
#include <CMConfigReader.h>
#include <CMSimConfigReader.h>
#include <MapConstants.h>
#include <OMAP3.h>
#include <Msg.h>
#include <IMAP3.h>


class UT_CtxtSimSendRoutingInfo: public testing::Test , public CtxtSimSendRoutingInfo
{public:
UT_CtxtSimSendRoutingInfo()
{
}
~UT_CtxtSimSendRoutingInfo()
{
}
};


class UT_CMSimConfigReader
{public:
UT_CMSimConfigReader()
{
}
~UT_CMSimConfigReader()
{
}
};


class UT_MapSpecificMsg
{public:
UT_MapSpecificMsg()
{
}
~UT_MapSpecificMsg()
{
}
};



//-----------------------------------------------------------------------


TEST_F(UT_CtxtSimSendRoutingInfo,startProcessing_func) {
EXPECT_TRUE(startProcessing());
}

TEST_F(UT_CtxtSimSendRoutingInfo,sendSRIReq3_func) {
g_CMSimConfigReaderObj->m_mapVer=3;
g_CMSimConfigReaderObj->m_cph=4;
EXPECT_TRUE(sendSRIReq());
}

TEST_F(UT_CtxtSimSendRoutingInfo,sendSRIReq3_elseif1_func) {
g_CMSimConfigReaderObj->m_mapVer=3;
g_CMSimConfigReaderObj->m_cph=3;
EXPECT_TRUE(sendSRIReq());
}

TEST_F(UT_CtxtSimSendRoutingInfo,sendSRIReq3_elseif2_func) {
g_CMSimConfigReaderObj->m_mapVer=3;
g_CMSimConfigReaderObj->m_cph=2;
EXPECT_TRUE(sendSRIReq());
}

TEST_F(UT_CtxtSimSendRoutingInfo,sendSRIReq3_elseif3_func) {
g_CMSimConfigReaderObj->m_mapVer=3;
g_CMSimConfigReaderObj->m_cph=1;
EXPECT_TRUE(sendSRIReq());
}

TEST_F(UT_CtxtSimSendRoutingInfo,sendSRIReq3_else_func) {
g_CMSimConfigReaderObj->m_mapVer=3;
g_CMSimConfigReaderObj->m_cph=0;
EXPECT_TRUE(sendSRIReq());
}

TEST_F(UT_CtxtSimSendRoutingInfo,sendSRIReq3_if_func) {
g_CMSimConfigReaderObj->m_mapVer=3;
CtxtSimSendRoutingInfo::m_psiPrnFlag =1;
EXPECT_TRUE(sendSRIReq());
}

TEST_F(UT_CtxtSimSendRoutingInfo,sendSRIReq3_Telephony_func) {
g_CMSimConfigReaderObj->m_mapVer=3;
g_CMSimConfigReaderObj->m_nkSigInfo=1;
EXPECT_TRUE(sendSRIReq());
}

TEST_F(UT_CtxtSimSendRoutingInfo,sendSRIReq3_Video_func) {
g_CMSimConfigReaderObj->m_mapVer=3;
g_CMSimConfigReaderObj->m_nkSigInfo=2;
EXPECT_TRUE(sendSRIReq());
}

TEST_F(UT_CtxtSimSendRoutingInfo,sendSRIReq3_Fax_func) {
g_CMSimConfigReaderObj->m_mapVer=3;
g_CMSimConfigReaderObj->m_nkSigInfo=3;
EXPECT_TRUE(sendSRIReq());
}

TEST_F(UT_CtxtSimSendRoutingInfo,sendSRIReq3_Telephony2_func) {
g_CMSimConfigReaderObj->m_mapVer=3;
g_CMSimConfigReaderObj->m_nkSigInfo=4;
EXPECT_TRUE(sendSRIReq());
}

TEST_F(UT_CtxtSimSendRoutingInfo,sendSRIReq3_Telephony3_func) {
g_CMSimConfigReaderObj->m_mapVer=3;
g_CMSimConfigReaderObj->m_nkSigInfo=5;
EXPECT_TRUE(sendSRIReq());
}

TEST_F(UT_CtxtSimSendRoutingInfo,sendSRIReq2_func) {
g_CMSimConfigReaderObj->m_mapVer=2;
EXPECT_TRUE(sendSRIReq());
}

TEST_F(UT_CtxtSimSendRoutingInfo,sendSRIReq1_func) {
g_CMSimConfigReaderObj->m_mapVer=1;
EXPECT_TRUE(sendSRIReq());
}

TEST_F(UT_CtxtSimSendRoutingInfo,processMessage_MAP_CMN_OPEN_IND_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=202;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtSimSendRoutingInfo,processMessage_MAP_CMN_DELIMITER_IND_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=208;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtSimSendRoutingInfo,processMessage_MAP_CMN_CLOSE_IND_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=206;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}


TEST_F(UT_CtxtSimSendRoutingInfo,processMessage_MAP_CMN_U_ABORT_IND_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=210;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}


TEST_F(UT_CtxtSimSendRoutingInfo,processMessage_MAP_CMN_P_ABORT_IND_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=212;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}


TEST_F(UT_CtxtSimSendRoutingInfo,processMessage_MAP_CMN_NOTICE_IND_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=213;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}


TEST_F(UT_CtxtSimSendRoutingInfo,processMessage_MAP_CMN_MSG_Default_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=0;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}


TEST_F(UT_CtxtSimSendRoutingInfo,processMessage_MAP_SPEC_EVENT_INDICATION_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_Version=1;
p_MsgPtr.m_MapSpecificEventType=2;
int *ptr=new int;
*ptr=1;
p_MsgPtr.m_OpCode=2;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
delete ptr;
}

TEST_F(UT_CtxtSimSendRoutingInfo,processMessage_MAP_SPEC_EVENT_RESULT_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=3;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}


//------------------------------------------------------------------------------
TEST_F(UT_CtxtSimSendRoutingInfo,processMessage_MAP_SPEC_EVENT_Confirmation_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=4;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

//---------------------------------------------------------------------------------------

TEST_F(UT_CtxtSimSendRoutingInfo,processMessage_MAP_OP_CODE_sendRoutingInfo_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=2;
p_MsgPtr.m_OpCode=22 ;
p_MsgPtr.m_allocatedFlag=false;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtSimSendRoutingInfo,processMessage_MAP_SPEC_EVENT_USER_ERROR_Func) {
MapUserError p_MsgPtr(1, MAP_ERROR_callBarred, MAP_V3, NULL);
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=5;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}


TEST_F(UT_CtxtSimSendRoutingInfo,processMessage_MAP_SPEC_EVENT_PROV_ERROR_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=6;
p_MsgPtr.m_UserDlgId=1;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}


TEST_F(UT_CtxtSimSendRoutingInfo,processMessage_MAP_SPEC_Default_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=0;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}


TEST_F(UT_CtxtSimSendRoutingInfo,processMessage_MAP_MSG_Default_Func) {
MapMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=0;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtSimSendRoutingInfo,processMessage_MSG_TYPE_DB_Func) {
Msg p_MsgPtr;
p_MsgPtr.m_MsgType=2;
bool p_DeleteFlag=false;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}


TEST_F(UT_CtxtSimSendRoutingInfo,processMessage_MSG_TYPE_Default_Func) {
Msg p_MsgPtr;
p_MsgPtr.m_MsgType=0;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}


#undef private



