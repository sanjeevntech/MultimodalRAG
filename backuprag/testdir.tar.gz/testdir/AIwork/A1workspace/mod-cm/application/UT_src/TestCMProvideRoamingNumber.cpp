#define private public
#include<iostream>
#include"gtest.h"
#include<CMProvideRoamingNumber.h>
#include <ContextBase.h>
#include <Msg.h>
#include <ServiceCoordinator.h>
#include<CMConfigReader.h>
#include <Msg.h>
#include<MapMessages.h>
#include<DbQueryMsg.h>
#include<CMDbQueries.h>

class UT_CtxtProvideRoamingNumber: public testing::Test , public CtxtProvideRoamingNumber
{public:
UT_CtxtProvideRoamingNumber()
{
}
~UT_CtxtProvideRoamingNumber()
{
}
};

class UT_CMConfigReader: public testing::Test 
{public:
UT_CMConfigReader()
{
}
~UT_CMConfigReader()
{
}
};

class UT_Msg: public testing::Test
{public:
UT_Msg()
{
}
~UT_Msg()
{
}
};

class UT_MapSpecificMsg: public testing::Test
{public:
UT_MapSpecificMsg()
{
}
~UT_MapSpecificMsg()
{
}
};

class UT_MapCommonMsg: public testing::Test
{public:
UT_MapCommonMsg()
{
}
~UT_MapCommonMsg()
{
}
};

class UT_MapOpenCnf: public testing::Test
{public:
UT_MapOpenCnf()
{
}
~UT_MapOpenCnf()
{
}
};

class UT_DbQueryMsg: public testing::Test
{public:
UT_DbQueryMsg()
{
}
~UT_DbQueryMsg()
{
}
};

class UT_CMPrnUpdateMNRF: public testing::Test
{public:
UT_CMPrnUpdateMNRF()
{
}
~UT_CMPrnUpdateMNRF()
{
}
};


TEST_F(UT_CtxtProvideRoamingNumber,updatePrnMnrfDb_Func) {
g_CMConfigReaderObj=new CMConfigReader;
g_CMConfigReaderObj->m_standalonePrnMnrfFlag=1;
EXPECT_TRUE(updatePrnMnrfDb());
}

TEST_F(UT_CtxtProvideRoamingNumber,updatePrnMnrfDb_outer_else_Func) {
g_CMConfigReaderObj=new CMConfigReader;
g_CMConfigReaderObj->m_standalonePrnMnrfFlag=0;
EXPECT_TRUE(updatePrnMnrfDb());
}

TEST_F(UT_CtxtProvideRoamingNumber,sendv3Prn_Func) {
EXPECT_FALSE(sendv3Prn());
}

TEST_F(UT_CtxtProvideRoamingNumber,sendv2Prn_Func) {
EXPECT_FALSE(sendv2Prn());
}

TEST_F(UT_CtxtProvideRoamingNumber,sendv1Prn_Func) {
EXPECT_FALSE(sendv1Prn());
}

TEST_F(UT_CtxtProvideRoamingNumber,processMessage_MAP_CMN_OPEN_IND_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=202;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtProvideRoamingNumber,processMessage_MAP_CMN_OPEN_CNF_Func) {
MapOpenCnf p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=204;
p_MsgPtr.m_RefuseReasonParam=2;
p_MsgPtr.m_Version=3;
m_sentPrnVer=1;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtProvideRoamingNumber,processMessage_MAP_CMN_OPEN_CNF_MAP_V2_Func) {
MapOpenCnf p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=204;
p_MsgPtr.m_RefuseReasonParam=2;
p_MsgPtr.m_Version=2;
m_sentPrnVer=1;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtProvideRoamingNumber,processMessage_MAP_CMN_OPEN_CNF_MAP_V1_Func) {
MapOpenCnf p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=204;
p_MsgPtr.m_RefuseReasonParam=2;
p_MsgPtr.m_Version=1;
m_sentPrnVer=1;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtProvideRoamingNumber,processMessage_MAP_CMN_OPEN_CNF_default_Func) {
MapOpenCnf p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=204;
p_MsgPtr.m_RefuseReasonParam=2;
p_MsgPtr.m_Version=0;
m_sentPrnVer=1;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtProvideRoamingNumber,processMessage_MAP_CMN_OPEN_CNF_else_Func) {
MapOpenCnf p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=204;
p_MsgPtr.m_RefuseReasonParam=2;
p_MsgPtr.m_Version=1;
m_sentPrnVer=1;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtProvideRoamingNumber,processMessage_MAP_CMN_OPEN_CNF_else2_Func) {
MapOpenCnf p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=204;
p_MsgPtr.m_RefuseReasonParam=0;
p_MsgPtr.m_Version=1;
m_sentPrnVer=1;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtProvideRoamingNumber,processMessage_MAP_CMN_DELIMITER_IND_Func) {
MapOpenCnf p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=208;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtProvideRoamingNumber,processMessage_MAP_CMN_CLOSE_IND_Func) {
MapOpenCnf p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=206;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtProvideRoamingNumber,processMessage_MAP_CMN_U_ABORT_IND_Func) {
MapOpenCnf p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=210;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtProvideRoamingNumber,processMessage_MAP_CMN_P_ABORT_IND_Func) {
MapOpenCnf p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=212;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtProvideRoamingNumber,processMessage_MAP_CMN_NOTICE_IND_Func) {
MapOpenCnf p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=213;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtProvideRoamingNumber,processMessage_MAP_MSG_TYPE_COMMON_default_Func) {
MapOpenCnf p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=0;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtProvideRoamingNumber,processMessage_MAP_SPEC_EVENT_CONFIRMATION_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=4;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtProvideRoamingNumber,processMessage_MAP_SPEC_EVENT_USER_ERROR_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=5;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtProvideRoamingNumber,processMessage_MAP_SPEC_EVENT_PROV_ERROR_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=6;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}


TEST_F(UT_CtxtProvideRoamingNumber,processMessage_MapSpecificMsg_default_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=0;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtProvideRoamingNumber,processMessage_MSG_TYPE_DB_Func) {
CMPrnUpdateMNRF p_MsgPtr;
p_MsgPtr.m_MsgType=2;
p_MsgPtr.m_DbQueryType=1;
p_MsgPtr.m_EdbResult=0;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtProvideRoamingNumber,processMessage_MSG_TYPE_DB_inner_else_Func) {
CMPrnUpdateMNRF p_MsgPtr;
p_MsgPtr.m_MsgType=2;
p_MsgPtr.m_DbQueryType=1;
p_MsgPtr.m_EdbResult=1;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtProvideRoamingNumber,processMessage_MSG_TYPE_DB_Outer_else_Func) {
CMPrnUpdateMNRF p_MsgPtr;
p_MsgPtr.m_MsgType=2;
p_MsgPtr.m_DbQueryType=1000;
p_MsgPtr.m_EdbResult=1;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtProvideRoamingNumber,processMessage_default_Func) {
CMPrnUpdateMNRF p_MsgPtr;
p_MsgPtr.m_MsgType=0;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

#undef private

