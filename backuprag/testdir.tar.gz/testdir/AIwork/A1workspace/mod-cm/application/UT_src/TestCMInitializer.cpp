#define private public
#include<iostream>
#include"gtest.h"
#include <Logger.h>
#include <ModuleBase.h>
#include <MapMessages.h>
#include <ContextBase.h>
#include <CMConfigReader.h>
#include "CMSendRoutingInfo.h"
#include "CMIstCommand.h"
#include "CMSriForLcs.h"
#include "CMProvideRoamingNumber.h"
#include <SnmpInterface.h>
#include <CMSimConfigReader.h>
#include <CtxtSimSendRoutingInfo.h>
#include "CtxtVlrPSIRes.h"
#include "CtxtVlrPRNRes.h"
#include "CtxtSimSriForLcsReq.h"
#include<MapMessages.h>
#include<SccpMsg.h>

extern bool g_loadFlag;
extern "C" {
   ModuleBase *getModuleObj();
}

class CmModule:public ModuleBase
{
   public:
      CmModule(){};
      bool initModule();
      ContextBase *getCtxtObj(EMapOpCode, MapSpecificMsg*);
      ContextBase *getCtxtObj(EDiameterCommandCode p_OpCode, DiameterMsg* p_msg);
      ContextBase *getCtxtObj(EMapOpCode, SccpMsg*);
      char *getVersion();
      ConfigReader *getConfigReaderObj();
      ConfigReader **retrieveConfigReaderPtr();
};

class UT_CmModule: public testing::Test , public CmModule {
public:
UT_CmModule()
{
}
~UT_CmModule()
{
}
};

class UT_MapSpecificRequest{
public:
UT_MapSpecificRequest()
{
}
~UT_MapSpecificRequest()
{
}
};

class UT_SccpMsg{
public:
UT_SccpMsg()
{
}
~UT_SccpMsg()
{
}
};

TEST_F(UT_CmModule,getCtxtObj_Func) {
MapSpecificMsg obj;
EXPECT_NE(getCtxtObj(22,&obj),1111111111);
}

TEST_F(UT_CmModule,getCtxtObj_else_Func) {
MapSpecificMsg obj;
g_loadFlag=true;
EXPECT_NE(getCtxtObj(22,&obj),1111111111);
}


TEST_F(UT_CmModule,getCtxtObj_MAP_OP_CODE_istCommand_Func) {
MapSpecificMsg obj;
EXPECT_NE(getCtxtObj(88,&obj),1111111111);
}

TEST_F(UT_CmModule,getCtxtObj_MAP_OP_CODE_sendRoutingInfoForLCS_Func) {
MapSpecificMsg obj;
EXPECT_NE(getCtxtObj(85,&obj),1111111111);
}

TEST_F(UT_CmModule,getCtxtObj_MAP_OP_CODE_provideRoamingNumber_Func) {
MapSpecificMsg obj;
EXPECT_NE(getCtxtObj(4,&obj),1111111111);
}

TEST_F(UT_CmModule,getCtxtObj_MAP_OP_CODE_provideSubscriberInfo_Func) {
MapSpecificMsg obj;
EXPECT_NE(getCtxtObj(70,&obj),1111111111);
}

TEST_F(UT_CmModule,getCtxtObj_default_Func) {
MapSpecificMsg obj;
EXPECT_NE(getCtxtObj(0,&obj),1111111111);
}

TEST_F(UT_CmModule,getConfigReaderObj_Func) {
g_loadFlag=true;
EXPECT_NE(getConfigReaderObj(),1111111111);
}

TEST_F(UT_CmModule,retrieveConfigReaderPtr_Func) {
g_loadFlag=true;
EXPECT_NE(retrieveConfigReaderPtr(),1111111111);
}


/*
//seg fault
TEST_F(UT_CmModule,getCtxtObj_SccpMsg_Func) {
SccpMsg obj;
EXPECT_EQ(getCtxtObj(4,&obj),NULL);
}*/

#undef private
