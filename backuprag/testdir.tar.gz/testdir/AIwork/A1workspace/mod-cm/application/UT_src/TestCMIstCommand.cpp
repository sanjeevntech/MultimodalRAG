#define private public
#include<iostream>
#include"gtest.h"
#include<CMIstCommand.h>
#include <ContextBase.h>
#include <Msg.h>
#include <ServiceCoordinator.h>
#include<MapMessages.h>

class UT_CtxtIstCommand: public testing::Test , public CtxtIstCommand
{public:
UT_CtxtIstCommand()
{
}
~UT_CtxtIstCommand()
{
}
};

class UT_InterModuleData: public testing::Test 
{public:
UT_InterModuleData()
{
}
~UT_InterModuleData()
{
}
};

class UT_Msg: public testing::Test
{public:
UT_Msg()
{
}
~UT_Msg()
{
}
};

class UT_MapSpecificMsg: public testing::Test
{public:
UT_MapSpecificMsg()
{
}
~UT_MapSpecificMsg()
{
}
};

TEST_F(UT_CtxtIstCommand,sendv3Ist_Func) {
EXPECT_FALSE(sendv3Ist());
}

TEST_F(UT_CtxtIstCommand,startProcessing_Func) {
InterModuleData obj;
bool p_DeleteFlag=true;
EXPECT_FALSE(startProcessing(&obj,p_DeleteFlag));
}

TEST_F(UT_CtxtIstCommand,updateDb_Func) {
EXPECT_TRUE(updateDb('a',"aaaaaaaa"));
}

TEST_F(UT_CtxtIstCommand,processMessage_MAP_CMN_OPEN_IND_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=202;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtIstCommand,processMessage_MAP_CMN_OPEN_CNF_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=204;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtIstCommand,processMessage_MAP_CMN_DELIMITER_IND_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=208;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtIstCommand,processMessage_MAP_CMN_CLOSE_IND_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=206;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtIstCommand,processMessage_MAP_CMN_U_ABORT_IND_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=210;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtIstCommand,processMessage_MAP_CMN_P_ABORT_IND_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=212;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtIstCommand,processMessage_MAP_CMN_NOTICE_IND_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=213;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtIstCommand,processMessage_MapCommonMsg_default_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=0;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtIstCommand,processMessage_MAP_SPEC_EVENT_CONFIRMATION_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=4;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtIstCommand,processMessage_MAP_SPEC_EVENT_USER_ERROR_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=5;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtIstCommand,processMessage_MAP_SPEC_EVENT_PROV_ERROR_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=6;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtIstCommand,processMessage_MapSpecificMsg_default_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=0;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtIstCommand,processMessage_MSG_TYPE_DB_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=2;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtIstCommand,processMessage_default_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=0;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}


#undef private

