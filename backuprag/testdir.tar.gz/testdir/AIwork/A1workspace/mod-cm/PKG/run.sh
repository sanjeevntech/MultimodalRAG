HLR_FRAMEWORK_ROOT=/74bkp/rgopal/work/HSS_GCC_2.0.0.1/

OMNI_ROOT=/opt/ulcm/
MAP_HOME=$HLR_FRAMEWORK_ROOT/IOLIB/
export ORACLE_HOME=/ora10gclnt/product/10.2.0/client/
GEN_UTIL_HOME=/74bkp/rgopal/work/GENERIC_UTIL_1.4.0.0/gen-util/
LD_LIBRARY_PATH=/usr/sfw/lib/sparcv9/:$SNMP_CLIENT_HOME/lib/:$MAP_HOME/map-constants/lib/:$MAP_HOME/MAP1/lib:$MAP_HOME/MAP2/lib:$MAP_HOME/MAP3/lib:/usr/local/ossasn1/solaris7-64bit/8.3.1/lib:/opt/ulcm/library:$ORACLE_HOME/lib:$HLR_FRAMEWORK_ROOT/framework/objs/:.:$HLR_FRAMEWORK_ROOT/map-ng/oci-change-notification/:$GEN_UTIL_HOME/lib/:/opt/product/mohan/HLR/license/generator/pkg:/opt/product/sanjeev/HLR/HLR_2.0.2.0/subs_profiles_2.0.2.0/
echo $LD_LIBRARY_PATH

PATH=$PATH:$ORACLE_HOME/bin/
