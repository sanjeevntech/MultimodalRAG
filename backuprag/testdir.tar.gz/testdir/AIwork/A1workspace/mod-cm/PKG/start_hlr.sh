clear
. run.sh
rm -f core
SHM=100
#LD_PRELOAD=/opt/product/rgopal/learn/tool_memleak/libmemleak.so
LD_PRELOAD=
export LD_PRELOAD
MAX_TCAP_RECV_MESSAGES_AT_A_TIME=20
export MAX_TCAP_RECV_MESSAGES_AT_A_TIME
#$HLR_FRAMEWORK_ROOT/release/bin/pHSS-HLR -index $1 -config NGConfig.xml #-res
/74bkp/rgopal/work/HLR_2.0.6.0/map-ng/application/objs/mapNG -index $1 -config NGConfig.xml #-res
