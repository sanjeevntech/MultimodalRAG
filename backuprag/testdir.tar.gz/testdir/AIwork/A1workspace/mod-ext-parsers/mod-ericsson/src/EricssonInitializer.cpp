#include <MapMessages.h>
#include <ContextBase.h>
#include <ModuleBase.h>
#include <Logger.h>
#include <ExtContainerParser.h>
#include <EricssonExtensionParser.h>



extern "C" 
{
   ModuleBase *getModuleObj();
}


class EricssonParserModule : public ModuleBase
{
   public:
      EricssonParserModule(){};
      bool initModule();
      ContextBase *getCtxtObj(EMapOpCode, MapSpecificMsg*);
      ContextBase *getCtxtObj(EDiameterCommandCode p_OpCode, DiameterMsg* p_msg);
      ContextBase *getCtxtObj(EMapOpCode, SccpMsg*);
      char *getVersion();
      ConfigReader *getConfigReaderObj();
      ConfigReader **retrieveConfigReaderPtr();
};


EricssonParserModule g_EricssonParserModule;

ModuleBase *getModuleObj()
{
   return &g_EricssonParserModule;
}



bool EricssonParserModule::initModule()
{
   m_modName="ERI";
   LLOG(0,0,"ERI APPVER-v:%s ci:%s cd:%s comp:%s %s", APP_VERSION, COMMIT_ID, COMMIT_DATE,__DATE__,__TIME__);
   // This function is called by the framework after reading the respective Module's Configuration file (if any)
   unsigned char l_arr[] = {0x2a,0x86,0x3a,0x00,0x89,0x61,0x3a,0x01,0x00};
   LLOG(0,1,"Calling EricssonParserModule initModule");
   g_ecp.registerModule((unsigned char*)&l_arr, sizeof(l_arr), &g_EricssonParser);
   return true;
}

char *EricssonParserModule::getVersion()
{
   RETURN_VERSION(APP_VERSION); //2.0.20.0 "2.0.15.0" //2.0.0.0 //base is 1.0.7.0
}


ContextBase *EricssonParserModule::getCtxtObj(EDiameterCommandCode p_OpCode, DiameterMsg* p_msg)
{
   ELOG(0,0,"EricssonParserModule::getCtxtObj Diameter Message not supported");
   return NULL;
}


ContextBase *EricssonParserModule::getCtxtObj(EMapOpCode p_OpCode, MapSpecificMsg* p_msg)
{
   ELOG(0,0,"EricssonParserModule::getCtxtObj This should never get called");
   return NULL;
}

ContextBase *EricssonParserModule::getCtxtObj(EMapOpCode p_OpCode, SccpMsg* p_msg)
{
   ELOG(0,0,"SCCP message not supported");
   return NULL;
}

ConfigReader *EricssonParserModule::getConfigReaderObj()
{
   LLOG(0,0,"Returning NULL");
   return NULL;
}

ConfigReader **EricssonParserModule::retrieveConfigReaderPtr()
{
   LLOG(0,0,"Returning NULL");
   return NULL;
}

