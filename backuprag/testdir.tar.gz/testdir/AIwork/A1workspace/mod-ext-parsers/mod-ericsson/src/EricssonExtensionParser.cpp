#include <EricssonExtensionParser.h>
#include <Logger.h>
#include <string.h>
#include <stdio.h>


EricssonExtensionParser g_EricssonParser;

EricssonExtensionParser::EricssonExtensionParser()
{
}

EricssonExtensionParser::~EricssonExtensionParser()
{
}

bool EricssonExtensionParser::callRespectiveDecoder(EMapOpCode p_opCode, EMapVersion p_mapVersion, unsigned char *p_extTypeValue, int p_extTypeLength, char *p_buffer)
{
   DLOG(0,0,"callRespectiveDecoder called with opcode: %d, version: %d", p_opCode, p_mapVersion);
   DLOG_HEX(0,0,"Ext Type Value", (char*)p_extTypeValue, p_extTypeLength);
   switch(p_opCode)
   {
      case MAP_OP_CODE_updateLocation:
         {
            switch(p_mapVersion)
            {
               case MAP_V3:
                  {
                     LLOG(0,0,"callRespectiveDecoder decoding for opcode: %d, version: %d", p_opCode, p_mapVersion);
                     if(p_extTypeLength < 10)
                     {
                        WLOG(0,0,"callRespectiveDecoder ExtType Length is beyond the limits %d", p_extTypeLength);
                        return false;
                     }
                     else
                     {
                        char l_buffer[2000];
                        memset(l_buffer, '\0', sizeof(l_buffer));
                        sprintf(l_buffer, "<IMEI>");

                        int l_imeiFound=0;
                        for(int i=0; i<p_extTypeLength; i++)
                        {
                           if(0 == l_imeiFound)
                           {
                              //IMEI is starting from the 10th byte : A70F300D81010F83085358863094804010
                              if ( (p_extTypeValue[i] == 0x83) && (p_extTypeValue[i+1] == 0x08))
                              {
                                 LLOG(0,0,"found imei tag at %d", i);
                                 l_imeiFound=1;
                                 i++;
                              }
                           }
                           else
                           {
                              char l_temp[10];
                              memset(l_temp, '\0', sizeof(l_temp));
                              sprintf(l_temp, "%02x", p_extTypeValue[i]);
                              strcat(l_buffer, l_temp);
                           }
                        }
                        strcat(l_buffer, "</IMEI>");
                        DLOG(0,0,"Buffer [%s]",l_buffer);

                        strcpy(p_buffer, l_buffer);
                        return true;
                     }
                  }
                  break;

               default:
                  {
                     WLOG(0,0,"Unknown MAP version: %d", p_mapVersion);
                     return false;
                  }
                  break;
            }
         }
         break;

      case MAP_OP_CODE_sendRoutingInfo:
         {
            switch(p_mapVersion)
            {
               case MAP_V3:
                  {
                     LLOG(0,0,"callRespectiveDecoder decoding for opcode: %d, version: %d", p_opCode, p_mapVersion);
                     if(p_extTypeLength < 42)
                     {
                        WLOG(0,0,"callRespectiveDecoder ExtType Length is beyond the limits %d", p_extTypeLength);
                        return false;
                     }
                     else
                     {
                        char l_buffer[2000];
                        memset(l_buffer, '\0', sizeof(l_buffer));
                        int l_cpn_len = p_extTypeValue[33];
                        if((l_cpn_len > 2) && (l_cpn_len < 15))
                        {
                           sprintf(l_buffer, "<CALLING_PARTY_NUMBER>");

                           for(int l_i=0; l_i<l_cpn_len; l_i++)
                           {
                              char l_temp[2+1];
                              snprintf(l_temp, sizeof(l_temp), "%02x", p_extTypeValue[34+l_i]);
                              strcat(l_buffer, l_temp);
                           }
                           strcat(l_buffer, "</CALLING_PARTY_NUMBER>");
                        }
                        else
                        {
                           WLOG(0,0,"Invalid CPN length %d",l_cpn_len);
                        }

                        DLOG(0,0,"Buffer [%s]",l_buffer);

                        strcpy(p_buffer, l_buffer);
                        return true;
                     }
                  }
                  break;

               default:
                  {
                     WLOG(0,0,"Unknown MAP version: %d", p_mapVersion);
                     return false;
                  }
                  break;
            }
         }
         break;

      default:
         {
            WLOG(0,0,"Unknown OP Code : %d", p_opCode);
            return false;
         }
         break;
   }
   return true;
}

