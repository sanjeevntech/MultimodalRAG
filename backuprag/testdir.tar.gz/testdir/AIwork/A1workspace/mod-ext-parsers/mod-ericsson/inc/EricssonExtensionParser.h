#ifndef __ERICSSON_EXT_PARSER_H
#define __ERICSSON_EXT_PARSER_H

#include <ExtParserBase.h>

class EricssonExtensionParser : public ExtParserBase
{
   public:
      EricssonExtensionParser();
      ~EricssonExtensionParser();

      bool callRespectiveDecoder(EMapOpCode, EMapVersion, unsigned char *p_extTypeValue, int p_extTypeLength, char *p_buffer);
};


extern EricssonExtensionParser g_EricssonParser;

#endif
