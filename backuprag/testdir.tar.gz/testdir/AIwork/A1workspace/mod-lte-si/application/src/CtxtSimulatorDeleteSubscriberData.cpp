#include <its++.h>
#include <its_timers.h>
#include <diameter/Command.h>
#include <diameter/base/BaseAVP.h>
#include <CtxtSimulatorDeleteSubscriberData.h>
#include <stdio.h>
#include <MapMessages.h>
#include <ServiceCoordinator.h>
#include <ExtendedServiceCoordinator.h>
#include <ProvisioningMessages.h>
#include <Logger.h>
#include <DbActiveObject.h>
#include <Utilities.h>
#include <DataUnion.h>
#include <TimerManager.h>
#include <typeinfo>
#include <HlrTdrFiller.h>
#include <DiameterMessages.h>
#include <DiameterConstants.h>
#include <DiametriqInterface.h>

#include <TcpSocketServer.h>

using namespace std;
using namespace its;
using namespace diameter;
using namespace diameter::base;
using namespace diameter::s6a_r10;
//extern bool sendResponse(InterModuleData *p_imd, int p_errorCode, char *p_errorDesc, char *p_ResponseBody);

CtxtSimulatorDeleteSubscriberData::CtxtSimulatorDeleteSubscriberData()
{
   DLOG(0,0,"CtxtSimulatorDeleteSubscriberData :cons:");
}
CtxtSimulatorDeleteSubscriberData::~CtxtSimulatorDeleteSubscriberData()
{
   DLOG(0,0,"CtxtSimulatorDeleteSubscriberData :des:");
}

bool CtxtSimulatorDeleteSubscriberData::processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag)
{
   DLOG(0,0,"Start of CtxtSimulatorDeleteSubscriberData::processMsg function");

   p_DeleteFlag=p_DeleteFlag; // This is just to keep the compiler happy

   MapSpecificMsg *l_specMsg = NULL;

   switch (p_MsgPtr->m_MsgType)
   {
      case MSG_TYPE_MAP:
         {
            DLOG(0,0,"MAP message received");
         }
         break;

      case MSG_TYPE_DIAMETER:
         {
            LLOG(0,0,"DIAMETER message received");
            DiameterMsg *l_dm = (DiameterMsg*)p_MsgPtr;
            if( NULL != l_dm->m_cmd)
            {
               LLOG(0,0,"DIAMETER message received");
               //DiameterMsg l_answer ("test1", DIAM_EVENT_ANSWER,DIAM_COMM_CODE_S6A_S6D_S7A_S7D_DSR_DSA);
               //diameter::s6a_r10::DeleteSubscriberDataRequest *l_dsr = (diameter::s6a_r10::DeleteSubscriberDataRequest*)l_dm->m_cmd;
               diameter::s6a_r10::DeleteSubscriberDataRequest dsr(*(diameter::CommandImpl*)l_dm->m_cmd);
               diameter::s6a_r10::DeleteSubscriberDataRequest  *l_dsr = &dsr;
               diameter::base::SessionId sess= l_dsr->getSessionId();
               ITS_UINT l_idx = l_dsr->getSessionIndex();
               LLOG(0,0,"DSA Session Id : %d", l_idx);
               diameter::s6a_r10::DeleteSubscriberDataAnswer l_idsaData;
               //diameter::s6a_r10::DeleteSubscriberDataAnswer *l_dsa = new diameter::s6a_r10::DeleteSubscriberDataAnswer;
               diameter::s6a_r10::DeleteSubscriberDataAnswer *l_dsa = &l_idsaData;
               DiameterMsg l_answer ((char*)sess.value().c_str(), DIAM_EVENT_ANSWER,DIAM_COMM_CODE_S6A_S6D_S7A_S7D_DSR_DSA);
               l_answer.m_cmd = l_dsa;
               LLOG(0,0,"DSA Session Id : %d", l_idx);

               const SessionId &sid1 = l_dsr->getSessionId();
               const OriginHost &oh1 = l_dsr->getOriginHost();
               const OriginRealm &or1 = l_dsr->getOriginRealm();
               const AuthSessionState &authSessState = l_dsr->getAuthSessionState();
               l_dsa->setSessionId(sid1);
               l_dsa->setSessionIndex(l_dsr->getSessionIndex());
               l_dsa->setAuthSessionState(authSessState);
               ResultCode resultCode(2001);
               l_dsa->setResultCode(resultCode);
               ExperimentalResult experimentalResult;
               VendorId vendorId1(1);

               experimentalResult.setVendorId(vendorId1);
               ExperimentalResultCode experimentalResultCode(2001);
               experimentalResult.setExperimentalResultCode(experimentalResultCode);
               l_dsa->setExperimentalResult(experimentalResult);

               OriginHost originHost("MyHost");
               l_dsa->setOriginHost(originHost);

               OriginRealm originRealm("MyRealm");
               l_dsa->setOriginRealm(originRealm);
               DSAFlags ida(1);
               l_dsa->setDSAFlags(ida);
               g_esc.sendMsg(this, &l_answer);
            }
         }
         break;

      case MSG_TYPE_DB:
         {
            DLOG(0,0,"DB message received");
         }
         break;

      case MSG_TYPE_TIMEOUT:
         {
            LLOG(0,0,"Timeout received");      
         }
         break;
      default:
         DLOG(0,0,"Unknown message received %d", p_MsgPtr->m_MsgType);
         break;
   }
   return true;
}

