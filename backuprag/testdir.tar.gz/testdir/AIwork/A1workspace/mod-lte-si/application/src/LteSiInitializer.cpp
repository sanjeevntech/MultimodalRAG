#include <its++.h>
#include <its_timers.h>
#include <diameter/Command.h>
#include <diameter/base/BaseAVP.h>
#include <DiametriqInterface.h>
#include <ContextBase.h>
#include <ModuleBase.h>
#include <Logger.h>
#include <SnmpInterface.h>

#include <CtxtLteInsertSubscriberDataRequest.h>
#include <CtxtLteDeleteSubscriberDataRequest.h>

#include <DiameterMessages.h>
#include <DiameterConstants.h>
#include <CtxtSimulatorDeleteSubscriberData.h>
#include <CtxtSimulatorInsertSubscriberData.h>

#include <ExtendedServiceCoordinator.h>

extern bool g_loadFlag;

using namespace diameter::base;

int g_AfrTrap=-1;

extern "C" {
   ModuleBase *getModuleObj();
}


class LteSiModule : public ModuleBase
{
   public:
      LteSiModule(){}
      bool initModule();
      ContextBase *getCtxtObj(EMapOpCode, MapSpecificMsg*);
      ContextBase *getCtxtObj(EDiameterCommandCode, DiameterMsg*);
      ContextBase *getCtxtObj(EMapOpCode, SccpMsg*);
      char *getVersion();
      ConfigReader *getConfigReaderObj();
      ConfigReader **retrieveConfigReaderPtr();
};

LteSiModule g_LteSiModule;

ModuleBase *getModuleObj()
{
   return &g_LteSiModule;
}

bool LteSiModule::initModule()
{
   string m_modName="LSI";
   LLOG(0,0,"LSI APPVER-v:%s ci:%s cd:%s comp:%s %s", APP_VERSION, COMMIT_ID, COMMIT_DATE,__DATE__,__TIME__);
   return true;
}



char *LteSiModule::getVersion()
{
   RETURN_VERSION(APP_VERSION); // 2.0.15.0 base is "2.0.9.0"  //base is 2.0.6.2" 
}
ContextBase *LteSiModule::getCtxtObj(EMapOpCode p_OpCode, MapSpecificMsg *p_msg)
{
   LLOG(0,0,"ContextBase *LteSiModule::getCtxtObj()");
}

ContextBase *LteSiModule::getCtxtObj(EDiameterCommandCode p_ccCode, DiameterMsg *p_msg)
{
   switch (p_ccCode)
   {
      case DIAM_COMM_CODE_S6A_S6D_S7A_S7D_IDR_IDA:
         {
            if(false == g_loadFlag)
            {
               DLOG(0,0,"Rcvd DIAM_COMM_CODE_S6A_S6D_S7A_S7D_IDR_IDA Newing CtxtDiameterInsertSubscriberData");
               return new CtxtLteInsertSubscriberDataRequest;
            }
            else
            {
               DLOG(0,0,"Rcvd DIAM_COMM_CODE_S6A_S6D_S7A_S7D_IDR_IDA Newing CtxtSimulatorInsertSubscriberData");
               return new CtxtSimulatorInsertSubscriberData;
            }
         }
         break;
      case DIAM_COMM_CODE_S6A_S6D_S7A_S7D_DSR_DSA:
         {
            if( false == g_loadFlag)
            {
               DLOG(0,0,"Rcvd DIAM_COMM_CODE_S6A_S6D_S7A_S7D_DSR_DSA Newing CtxtDiameterDeleteSubscriberData");
               return new CtxtLteDeleteSubscriberDataRequest;
            }
            else
            {
               DLOG(0,0,"Rcvd DIAM_COMM_CODE_S6A_S6D_S7A_S7D_DSR_DSA Newing CtxtSimulatorDeleteSubscriberData");
               return new CtxtSimulatorDeleteSubscriberData;
            }
         }
         break;
      default:
         {
            DLOG(0,0,"getAucCtxtObj Unknown ccCode [%d]",p_ccCode);
            printf("\ngetAucCtxtObj Unknown ccCode [%d]",p_ccCode);
            return NULL;
         }
         break;
   }
}

ContextBase *LteSiModule::getCtxtObj(EMapOpCode p_OpCode, SccpMsg* p_msg)
{
   ELOG(0,0,"SCCP message not supported");
   return NULL;
}

ConfigReader *LteSiModule::getConfigReaderObj()
{
   LLOG(0,0,"ConfigReader *LteSiModule::getConfigReaderObj()");
}

ConfigReader **LteSiModule::retrieveConfigReaderPtr()
{
   LLOG(0,0,"ConfigReader **LteSiModule::retrieveConfigReaderPtr() called");
}

bool resetStruct(int p_version, int p_pdu, void *p_struct)
{
   if (NULL == p_struct)
   {
      ELOG(0,1,"p_struct is NULL");
      sleep(2);
      exit(1);
   }

   switch (p_version)
   {
      case 1:
         {
            switch(p_pdu)
            {
               default:
                  {
                     DLOG(0,0,"v1 In the default case");
                     return false;
                  }
                  break;
            }
         }
         break;

      case 2:
         {
            switch(p_pdu)
            {
               default:
                  {
                     DLOG(0,0,"v2 In the default case");
                     return false;
                  }
                  break;
            }
         }
         break;

      case 3:
         {
            switch(p_pdu)
            {
               default:
                  {
                     DLOG(0,0,"v3 In the default case");
                     return false;
                  }
                  break;
            }
         }
         break;

      default:
         {
            DLOG(0,0,"v-default In the default case");
         }
         break;
   }
   return false;
}

