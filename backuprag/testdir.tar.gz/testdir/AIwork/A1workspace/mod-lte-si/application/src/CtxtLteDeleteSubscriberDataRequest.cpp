#include <its++.h>
#include <its_timers.h>
#include <diameter/Command.h>
#include <diameter/base/BaseAVP.h>
#include <CtxtLteDeleteSubscriberDataRequest.h>
#include <stdio.h>
#include <MapMessages.h>
#include <ServiceCoordinator.h>
#include <ExtendedServiceCoordinator.h>
#include <ProvisioningMessages.h>
#include <Logger.h>
#include <DbActiveObject.h>
#include <Utilities.h>
#include <DataUnion.h>
#include <TimerManager.h>
#include <typeinfo>
#include <HlrTdrFiller.h>
#include <DiameterMessages.h>
#include <DiameterConstants.h>
#include <DiametriqInterface.h>

#include <TcpSocketServer.h>

using namespace std;
using namespace its;
using namespace diameter;
using namespace diameter::base;
using namespace diameter::s6a_r10;
//extern bool sendResponse(InterModuleData *p_imd, int p_errorCode, char *p_errorDesc, char *p_ResponseBody);

CtxtLteDeleteSubscriberDataRequest::CtxtLteDeleteSubscriberDataRequest()
{
   memset(m_transactionId, '\0', sizeof(m_transactionId));
   memset(m_origin_Host, '\0', sizeof(m_origin_Host));
   memset(m_origin_Realm, '\0', sizeof(m_origin_Realm));
   memset(m_destination_Host, '\0', sizeof(m_destination_Host));
   memset(m_destination_Realm, '\0', sizeof(m_destination_Realm));
   memset(m_imsi, '\0', sizeof(m_imsi));
   m_partner_Type = -1;
   DLOG(0,0,"CtxtLteDeleteSubscriberDataRequest :cons:");
}
string CtxtLteDeleteSubscriberDataRequest::sendCancelLocation()
{
   char l_partner_type[10];
   if( -1 != m_partner_Type)
      sprintf(l_partner_type, "%d", m_partner_Type);
   else
      memset(l_partner_type, 0, sizeof(l_partner_type));
   string l_calLoc = "<CANCEL_LOC><IMSI>" + string(m_imsi) + "</IMSI><NODE_TYPE>MME</NODE_TYPE><ORIGIN_HOST>" + string(m_origin_Host) + "</ORIGIN_HOST><ORIGIN_REALM>" + string(m_origin_Realm) + "</ORIGIN_REALM><DESTINATION_HOST>" + string(m_destination_Host) + "</DESTINATION_HOST><DESTINATION_REALM>" + string(m_destination_Realm) + "</DESTINATION_REALM><UPDATE_SUBS_DATA>1</UPDATE_SUBS_DATA><CL_TYPE>0</CL_TYPE><IMSI_TYPE>"+string(l_partner_type)+"</IMSI_TYPE><REQUEST_TYPE>IDR_FAILURE</REQUEST_TYPE></CANCEL_LOC>";
   DLOG(0,0,"IDR failed, sending CLR :%s:", l_calLoc.c_str());
   g_esc.initiateIndependentContext(this, DIAM_COMM_CODE_S6A_S6D_CLR_CLA, (char*)l_calLoc.c_str(), INITIATION_TYPE_IMMEDIATE);
   return l_calLoc;
}

CtxtLteDeleteSubscriberDataRequest::~CtxtLteDeleteSubscriberDataRequest()
{
   DLOG(0,0,"CtxtLteDeleteSubscriberDataRequest :des:");
}
#if 0
bool sendResponse(InterModuleData *p_imd, int p_errorCode, char *p_errorDesc, char *p_ResponseBody)
{
   ProvisioningReqMsg *l_prm = (ProvisioningReqMsg*)(p_imd->m_msgPtr);
   LLOG(0,0,"SendResponse called error code: %d", p_errorCode);
   ProvisioningResMsg *l_provRespMsg = new ProvisioningResMsg;
   l_provRespMsg->m_sockFd = l_prm->m_sockFd;
   l_provRespMsg->m_OrigEntityName = l_prm->m_OrigEntityName;
   l_provRespMsg->m_IpAddress = l_prm->m_IpAddress;
   l_provRespMsg->m_DeviceConnectionType = l_prm->m_DeviceConnectionType;


   string& l_temp=l_provRespMsg->m_data;
   l_temp.assign("<RESPONSE>");
   l_temp.append("<HEADER>");
   l_temp.append("<TRANSACTION_ID>");
   l_temp.append("TRANS");
   l_temp.append("</TRANSACTION_ID>");
   l_temp.append("<REQUEST_TYPE>");
   l_temp.append("OAM_DSR");
   l_temp.append("</REQUEST_TYPE>");
   l_temp.append("<ERROR_CODE>0");
   /*
      char l_errorCode[10];
      memset(l_errorCode, '\0', sizeof(l_errorCode));
      sprintf(l_errorCode, "%d", p_errorCode);
      l_temp.append(l_errorCode);
      */
   l_temp.append("</ERROR_CODE>");
   l_temp.append("<ERROR_DESC>");
   l_temp.append(p_errorDesc);
   l_temp.append("</ERROR_DESC>");
   l_temp.append("</HEADER>");

   if(NULL != p_ResponseBody) //strlen(p_ResponseBody) > 0)
   {
      LLOG(0,0,"Body is present");
      l_temp.append("<BODY>");
      l_temp.append(p_ResponseBody);
      if(p_errorCode != 0)
      {
         l_temp.append("<REMOTE_ERROR_CODE>");
         char l_errorCode[10];
         memset(l_errorCode, '\0', sizeof(l_errorCode));
         sprintf(l_errorCode, "%d", p_errorCode);
         l_temp.append(l_errorCode);
         l_temp.append("</REMOTE_ERROR_CODE>");
         l_temp.append("<REMOTE_ERROR_DESC>");
         l_temp.append(p_errorDesc);
         l_temp.append("</REMOTE_ERROR_DESC>");
      }
      else
      {
         l_temp.append("<REMOTE_ERROR_CODE>0</REMOTE_ERROR_CODE>");
         l_temp.append("<REMOTE_ERROR_DESC>Success</REMOTE_ERROR_DESC>");
         l_temp.append("</REMOTE_ENTITY_DATA>");
      }
      l_temp.append("</BODY>");
   }
   l_temp.append("</RESPONSE>");


   LLOG(1,1,"SendResponse end [%s]", (char*)l_temp.c_str());


   return g_tcpSocketQueue->push(l_provRespMsg);
}
#endif
bool CtxtLteDeleteSubscriberDataRequest::getTransactionId(char *p_Req)
{
   int l_len = 0;
   char l_transactionId [MAX_TRANSACTION_LEN + 1];
   memset(m_transactionId, '\0', sizeof(l_transactionId));
   char *l_ptr = strstr(p_Req, ":");
   if(NULL != l_ptr)
   {
      l_len = strlen(p_Req) - strlen(l_ptr);
      strncpy(m_transactionId, p_Req, l_len);
      return true;
   }
   return false;

}
bool CtxtLteDeleteSubscriberDataRequest::preDeleteSubscriberData(char *p_req)
{
   if( false == getTransactionId(p_req))
   {
      LLOG(0,1,"Delete Subscriber  Request Transaction Id not found]");
      return false;
   }
   LLOG(0,1,"DeleteSubscriber Request Transaction Id : [%s]", m_transactionId);
   m_response = ConfigReader::readValue(p_req, "DSR");
   if(m_response.size() == 0 )
   {
      CLOG(0,0,"Get Insert Subscriber Data tag not found");
      //sendResponse(m_imd, 101, "DSR tag not present",(char*)m_response.c_str());
      return false;
   }
   //l_dsr->m_commandCode = DIAM_COMM_CODE_S6A_S6D_S7A_S7D_DSR_DSA;

   //Prepare a DSR 
   diameter::s6a_r10::DeleteSubscriberDataRequest l_dsrData;
   try 
   {
      diameter::s6a_r10::DeleteSubscriberDataRequest *l_temp = &l_dsrData; 

      AuthSessionState authSessionState(AuthSessionState::NO_STATE_MAINTAINED);
      l_temp->setAuthSessionState(authSessionState);

      string l_origin = ConfigReader::readValue(p_req, "ORIGIN_HOST");

      if(l_origin.size() > 0)
      {
         DLOG(0,0,"DSR OriginHost : %s", l_origin.c_str());
         strcpy(m_origin_Host, l_origin.c_str());
         m_tdr.setString(TDR_INDEX_LOCAL_HOST, m_origin_Host);
         OriginHost originHost = diameter::base::OriginHost(l_origin.c_str());
         l_temp->setOriginHost(originHost);
      }

      string l_originrealm = ConfigReader::readValue(p_req, "ORIGIN_REALM");

      if(l_originrealm.size() > 0)
      {
         DLOG(0,0,"DSR OriginRealm : %s",l_originrealm.c_str());
         strcpy(m_origin_Realm, l_originrealm.c_str());
         m_tdr.setString(TDR_INDEX_LOCAL_REALM, m_origin_Realm);
         OriginRealm originRealm(l_originrealm.c_str());
         l_temp->setOriginRealm(originRealm);
      }

      string l_destinationhost = ConfigReader::readValue(p_req, "DESTINATION_HOST");

      if(l_destinationhost.size() > 0)
      {
         LLOG(0,0,"DSR DestinationHost : %s",l_destinationhost.c_str());
         strcpy(m_destination_Host, l_destinationhost.c_str());
         DestinationHost DestinationHost(l_destinationhost.c_str());
         l_temp->setDestinationHost(DestinationHost);
      }

      string l_destinationrealm = ConfigReader::readValue(p_req, "DESTINATION_REALM");

      if(l_destinationrealm.size())
      {
         LLOG(0,0,"DSR DestinationRealm : %s",l_destinationrealm.c_str());
         strcpy(m_destination_Realm, l_destinationrealm.c_str());
         m_tdr.setString(TDR_INDEX_REMOTE_REALM, m_destination_Realm);
         DestinationRealm destinationRealm(l_destinationrealm.c_str());
         l_temp->setDestinationRealm(destinationRealm);
      }

      string l_imsi = ConfigReader::readValue(p_req, "IMSI");
      if(l_imsi.size() > 0)
      {
         LLOG(0,0,"DSR IMSI : %s",l_imsi.c_str());
         strcpy(m_imsi, l_imsi.c_str());
         UserName userName((char*)l_imsi.c_str());
         l_temp->setUserName(userName);
         m_tdr.setChar(TDR_INDEX_REQUEST_TYPE, 'I');
         m_tdr.setString(TDR_INDEX_REQUEST_IMSI, (char*)l_imsi.c_str());
      }
      else
      {
         ELOG(0,1,"Unable get IMSI");
         //sendResponse(m_imd, 103, "DSR IMSI not present",(char*)m_response.c_str());
         return false;
      }
      string l_imsi_type = ConfigReader::readValue(p_req, "IMSI_TYPE");
      //m_partner_Type = atoi(l_imsi_type.c_str()); // test
      m_partner_Type = 0; 

      //sendResponse(m_imd, 0, "Success",(char*)m_response.c_str());
      string l_dsrflag = ConfigReader::readValue(p_req, "DSR_FLAG");
      LLOG(0,0,"DSR FLAG : %s",l_dsrflag.c_str());

      if(l_dsrflag.size())
      {
         DSRFlags dsr(atoi(l_dsrflag.c_str()));
         l_temp->setDSRFlags(dsr);
      }
      string l_tracereferece = ConfigReader::readValue(p_req, "TRACE_REFERENCE");
      if(l_tracereferece.size() > 0)
      {
         LLOG(0,0,"DSR TRACEREFERENCE : %s",l_tracereferece.c_str());
         TraceReference traceref(l_tracereferece.c_str());
         l_temp->setTraceReference(traceref);
      }
      string l_tscode = ConfigReader::readValue(p_req, "TS_CODE");
      if(l_tscode.size() > 0)
      {
         LLOG(0,0,"DSR TSCode : %s",l_tscode.c_str());
         TSCode tscode(l_tscode.c_str());
         l_temp->addTSCode(tscode);
      }

      string l_sscode = ConfigReader::readValue(p_req, "SS_CODE");
      if(l_sscode.size() > 0)
      {
         LLOG(0,0,"DSR SSCode : %s",l_sscode.c_str());
         SSCode sscode(l_sscode.c_str());
         l_temp->addSSCode(sscode);
      }
      string l_contextidentifier = ConfigReader::readValue(p_req, "CONTEXT_ID");
      if(l_contextidentifier.size())
      {
         char l_contexts[51][10];
         char l_fullContexts[2048+1];
         memset(l_contexts, '\0', sizeof(l_contexts));
         memset(l_fullContexts, '\0', sizeof(l_fullContexts));
         snprintf(l_fullContexts, sizeof(l_fullContexts), "|%s|", (char*)l_contextidentifier.c_str());
         tokenize2(l_fullContexts, (char*)l_contexts, 50, '|');
         LLOG(0,0,"DSR ContextIdentifier : %s",l_contextidentifier.c_str());
         for(int i =1 ; i < 51 ; i++)
         {
            if(0 != atoi(l_contexts[i]))
            {
               ContextIdentifier context(atoi(l_contexts[i]));
               l_temp->addContextIdentifier(context);
            }
         }
      }
      string l_supportfeature1 = ConfigReader::readValue(p_req, "SUPPORT_FEATURE_01");
      if(l_supportfeature1.size() > 0)
      {
         string l_featurelist = ConfigReader::readValue(l_supportfeature1, "FEATURE_LIST");
         if(l_featurelist.size() > 0)
         {
            LLOG(0,0,"DSR Supported Feature list 1 : %s",l_featurelist.c_str());
            SupportedFeatures supportedfeature;
            //diameter::base::VendorId;
            VendorId venderId(10415);
            supportedfeature.setVendorId(venderId);
            FeatureListID featurelistid(1);
            supportedfeature.setFeatureListID(featurelistid);
            m_tdr.setString(TDR_INDEX_LOCAL_SUPP_FEATURE_1, (char*)l_featurelist.c_str());
            FeatureList featurelist(atoi(l_featurelist.c_str()));
            supportedfeature.setFeatureList(featurelist);
            l_temp->addSupportedFeatures(supportedfeature);
         }
      }
      string l_supportfeature2 = ConfigReader::readValue(p_req, "SUPPORT_FEATURE_02");
      if(l_supportfeature2.size() > 0)
      {
         string l_featurelist = ConfigReader::readValue(l_supportfeature2, "FEATURE_LIST");
         if(l_featurelist.size() > 0)
         {
            LLOG(0,0,"DSR Supported Feature list 2 : %s",l_featurelist.c_str());
            SupportedFeatures supportedfeature;
            //diameter::base::VendorId;
            VendorId venderId(10415);
            supportedfeature.setVendorId(venderId);
            FeatureListID featurelistid(2);
            supportedfeature.setFeatureListID(featurelistid);
            FeatureList featurelist(atoi(l_featurelist.c_str()));
            m_tdr.setString(TDR_INDEX_LOCAL_SUPP_FEATURE_2, (char*)l_featurelist.c_str());
            supportedfeature.setFeatureList(featurelist);
            l_temp->addSupportedFeatures(supportedfeature);
         }
      }
   }
   catch (NoSuchAttributeException e)
   {
      ELOG(0,1,"ERROR!! Exception NoSuchAttributeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
   }
   catch (WrongCommandTypeException e)
   {
      ELOG(0,1,"ERROR!! Exception WrongCommandTypeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
   }
   catch (UnknownTypeException e)
   {
      ELOG(0,1,"ERROR!! Exception UnknownTypeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
   }
   catch (CodecException e)
   {
      ELOG(0,1,"ERROR!! Exception CodecException Caught: %s ,Error Cause: %s ",e.name(), e.what());
   }
   catch(...)
   {
      LLOG(0,0,"Filling IDR throwing Exceptions");
      CLOG(0,0,"Exception occurred while calling FillDSR");
      return false;
   }
   unsigned int sIdx;
   string sessIdString;
   if(false == g_esc.allocateSession(DIAM_APP_ID_S6A_S6D,
            sIdx,
            sessIdString))
   {
      ELOG(0,1,"Unable to allocate a session");
      //nn sendResponse(m_imd, 102, "DSR Unable Allocate DlgId",(char*)m_response.c_str());
      return false;
   }
   DiameterMsg l_dsr((char*)sessIdString.c_str(),DIAM_EVENT_REQUEST, DIAM_COMM_CODE_S6A_S6D_S7A_S7D_DSR_DSA);
   l_dsrData.setSessionId(diameter::base::SessionId(sessIdString));
   l_dsrData.setSessionIndex(sIdx);

   ITS_UINT l_idx = l_dsrData.getSessionIndex();
   LLOG(0,0,"DSR Session Id : %d", l_idx);

   l_dsr.m_cmd = &l_dsrData;
   g_esc.sendMsg(this, &l_dsr);

   return true;
}
bool CtxtLteDeleteSubscriberDataRequest::startProcessing(InterModuleData *p_imd, bool& p_DeleteFlag)
{
   char *l_check = NULL;
   if(NULL == p_imd->m_Parameters)
   {
      CLOG(0,0,"p_imd->m_Parameters NULL");
   }
   else
   {
      l_check = strchr(p_imd->m_Parameters, ':');
   }

   p_DeleteFlag=false; //So that the p_imd is not deleted
   m_imd = p_imd;
   string l_xml;

   if(l_check != NULL)
   {
      //l_xml = &p_imd->m_Parameters[0];
      l_xml = p_imd->m_Parameters;
      LLOG(0,1,"XML [%s]", (char*)l_xml.c_str());
      preDeleteSubscriberData((char*)l_xml.c_str());
   }
   else if(p_imd->m_msgPtr != NULL)
   {
      ProvisioningReqMsg *l_provReqMsg = (ProvisioningReqMsg*)p_imd->m_msgPtr;
      m_tdr.setOriginatingModule((char*)l_provReqMsg->m_OrigEntityName.c_str());
      m_tdr.setString(TDR_INDEX_OAM_REQUEST_TYPE,"INSERT_SUBSCRIBER_DATA");
      l_xml = l_provReqMsg->m_data;

   }
   return true;
}

bool CtxtLteDeleteSubscriberDataRequest::processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag)
{
   DLOG(0,0,"Start of CtxtLteDeleteSubscriberDataRequest::processMsg function");

   p_DeleteFlag=p_DeleteFlag; // This is just to keep the compiler happy

   MapSpecificMsg *l_specMsg = NULL;

   switch (p_MsgPtr->m_MsgType)
   {
      case MSG_TYPE_MAP:
         {
            DLOG(0,0,"MAP message received");
         }
         break;

      case MSG_TYPE_DIAMETER:
         {
            LLOG(0,0,"DIAMETER message received");
            DiameterMsg *l_dm = (DiameterMsg*)p_MsgPtr;
            switch(l_dm->m_det)
            {
               case DIAM_EVENT_ANSWER:
                  {
                     if(NULL != l_dm->m_cmd)
                     {
                        //p_DeleteFlag = false;
                        diameter::s6a_r10::DeleteSubscriberDataAnswer l_dsa(*(diameter::CommandImpl*)l_dm->m_cmd);
                        //diameter::s6a_r10::DeleteSubscriberDataAnswer *l_dsa = (diameter::s6a_r10::DeleteSubscriberDataAnswer*)l_dm->m_cmd;
                        //cout<<*l_air;
                        diameter::base::SessionId sess= l_dsa.getSessionId();
                        //  LLOG(0,1,"session id is [%s]", (char*)sess.c_str());
                        ITS_UINT l_idx = l_dsa.getSessionIndex();
                        LLOG(0,0,"DSA Session Id : %d", l_idx);
                        int l_errCode = -1;

                        const SessionId &sid1 = l_dsa.getSessionId();
                        const OriginHost &oh1 = l_dsa.getOriginHost();
                        const OriginRealm &or1 = l_dsa.getOriginRealm();
                        const AuthSessionState &authSessState = l_dsa.getAuthSessionState();
                        if( true == l_dsa.containsExperimentalResult())
                        {
                           const ExperimentalResult &l_experimentalrel = l_dsa.getExperimentalResult();
                           const ExperimentalResultCode &l_experimentalrelcode = l_experimentalrel.getExperimentalResultCode();
                           l_errCode = l_experimentalrelcode.value();
                           if(l_experimentalrelcode.value() > 0)
                           {
                              m_tdr.setInteger(TDR_INDEX_ERR_CODE, l_experimentalrelcode.value());
                              LLOG(0,0,"IDA Result Code : %u", l_experimentalrelcode.value());
                           }
                        }
                        else if(true == l_dsa.containsResultCode())
                        {
                           const ResultCode &l_rel = l_dsa.getResultCode();
                           l_errCode = l_rel.value();
                           if(l_rel.value() > 0)
                           {
                              m_tdr.setInteger(TDR_INDEX_ERR_CODE, l_rel.value());
                              LLOG(0,0,"IDA Result Code : %u", l_rel.value());
                           }
                        }
                        if((l_errCode == DIAM_RESULT_CODE_SUCCESS) || 
                              ( l_errCode == DIAM_RESULT_CODE_LIMITED_SUCCESS) || 
                              ( l_errCode == DIAM_RESULT_CODE_SUCCESS_MIN_RANGE) || 
                              ( l_errCode == DIAM_RESULT_CODE_SUCCESS_MAX_RANGE))
                        {
                           LLOG(0,0,"DSA Recv Success with Result Code : %u", l_errCode);
                        }
                        else
                        {
                           LLOG(0,0,"DSA Recv Failure with Result Code : %u", l_errCode);
                           string l_calLoc = sendCancelLocation();
                        }
                     }
                  }
                  break;
                  break;
               case DIAM_EVENT_TIME_OUT:
                  {
                     m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EVENT_TIME_OUT);
                     string l_calLoc = sendCancelLocation();
                     CLOG(0,1,"DIAM_EVENT_TIME_OUT received CancelLocation XML string[%s]", l_calLoc.c_str());
                  }
                  break;
               case DIAM_EVENT_ERROR:
                  {
                     m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EVENT_ERROR);
                     string l_calLoc = sendCancelLocation();
                     CLOG(0,1,"DIAM_EVENT_ERROR received CancelLocation XML string[%s]", l_calLoc.c_str());
                  }
                  break;
               case DIAM_EVENT_AUTH_LIFE_TIME_OUT:
                  {
                     m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EVENT_AUTH_LIFE_TIME_OUT);
                     string l_calLoc = sendCancelLocation();
                     CLOG(0,1,"DIAM_EVENT_AUTH_LIFE_TIME_OUT received CancelLocation XML string[%s]", l_calLoc.c_str());
                  }
                  break;
               case DIAM_EVENT_AUTH_GRACE_TIME_OUT:
                  {
                     m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EVENT_AUTH_GRACE_TIME_OUT);
                     string l_calLoc = sendCancelLocation();
                     CLOG(0,1,"DIAM_EVENT_AUTH_GRACE_TIME_OUT received CancelLocation XML string[%s]", l_calLoc.c_str());
                  }
                  break;
               case DIAM_EVENT_CORRUPTED_MSG:
                  {
                     m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EVENT_CORRUPTED_MSG);
                     string l_calLoc = sendCancelLocation();
                     CLOG(0,1,"DIAM_EVENT_CORRUPTED_MSG received CancelLocation XML string [%s]", l_calLoc.c_str());
                  }
                  break;
               case DIAM_EVENT_ACCT_INTERIM_TIME_OUT:
                  {
                     m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EVENT_ACCT_INTERIM_TIME_OUT);
                     string l_calLoc = sendCancelLocation();
                     CLOG(0,1,"DIAM_EVENT_ACCT_INTERIM_TIME_OUT received CancelLocation XML string[%s]", l_calLoc.c_str());
                  }
                  break;
               case DIAM_EVENT_ERROR_SOMETHING_WEIRD:
                  {
                     string l_calLoc = sendCancelLocation();
                     CLOG(0,0,"DIAM_EVENT_ERROR_SOMETHING_WEIRD received CancelLocation XML string[%s]", l_calLoc.c_str());
                  }
                  break;
               default:
                  LLOG(0,1,"UNKNOWN DIAMETER received");
                  return false;
                  break;
            }
         }

      case MSG_TYPE_DB:
         {
            DLOG(0,0,"DB message received");
         }
         break;

      case MSG_TYPE_TIMEOUT:
         {
            LLOG(0,0,"Timeout received");      
         }
         break;
      default:
         DLOG(0,0,"Unknown message received %d", p_MsgPtr->m_MsgType);
         break;
   }
   return true;
}

