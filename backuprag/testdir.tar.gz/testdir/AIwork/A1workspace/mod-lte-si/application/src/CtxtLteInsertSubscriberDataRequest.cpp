#include <its++.h>
#include <its_timers.h>
#include <diameter/Command.h>
#include <diameter/base/BaseAVP.h>
#include <CtxtLteInsertSubscriberDataRequest.h>
#include <stdio.h>
#include <MapMessages.h>
#include <ServiceCoordinator.h>
#include <ExtendedServiceCoordinator.h>
#include <ProvisioningMessages.h>
#include <Logger.h>
#include <DbActiveObject.h>
#include <Utilities.h>
#include <DataUnion.h>
#include <TimerManager.h>
#include <typeinfo>
#include <HlrTdrFiller.h>
#include <DiameterMessages.h>
#include <TcpSocketServer.h>
#define MAX_RESPONSE_BUFF_SIZE 20000

//#include <s6a_stats.h>
//#include <app.h>
#include <DiametriqInterface.h>
#include <DiameterConstants.h>
using namespace diameter::s6a_r10;

CtxtLteInsertSubscriberDataRequest::CtxtLteInsertSubscriberDataRequest()
{
   DLOG(0,0,"CtxtLteInsertSubscriberDataRequest :cons:");
   memset(m_transactionId, '\0', sizeof(m_transactionId));
   memset(m_origin_Host, '\0', sizeof(m_origin_Host));
   memset(m_origin_Realm, '\0', sizeof(m_origin_Realm));
   memset(m_destination_Host, '\0', sizeof(m_destination_Host));
   memset(m_destination_Realm, '\0', sizeof(m_destination_Realm));
   memset(m_imsi, '\0', sizeof(m_imsi));
   m_featureList1 = 0;
   m_featureList2 = 0;
   m_modifyOdb = 0;
   m_mmeFeatureList1 = 0;
   m_mmeFeatureList2 = 0;
   m_odbDataSend = false;
   m_partner_Type = -1;
   m_partner_nkId = 0;
   m_Nwk_Id = 0;
   m_5gSupportFlag = false;
   m_hlr_5gSupportFlag = false;
   m_ims_service_flag = 0;
   m_locinfo_ageof = -1;
   m_getsubsflag = false;
    memset(m_SarIpv4Address,'\0',sizeof(m_SarIpv4Address));
    memset(m_SarIpv6Address,'\0',sizeof(m_SarIpv6Address));
    memset(m_SarPgwHost,'\0',sizeof(m_SarPgwHost));
    memset(m_SarPgwRealm,'\0',sizeof(m_SarPgwRealm));
   m_imd = NULL;
}

int getPartnerIdrLteProfId(unsigned int p_LteProfId, int p_NkId, int p_PartnerNkId)
{
   char l_tempArr[100 + 1];
   memset(l_tempArr,'\0',sizeof(l_tempArr));
   DLOG(0,0,"Nw Id is %d PartNwId %d LteProfId %d",p_NkId,p_PartnerNkId,p_LteProfId);
   p_NkId +=100;
   snprintf(l_tempArr,sizeof(l_tempArr),"%d%04d%d",p_NkId,p_PartnerNkId,p_LteProfId);
   DLOG(0,0,"Map Size [%d] tempArr in getPartnerIdrLteProfId [%s]",(int )g_spdPtr->m_RPLteProfMap.size(),l_tempArr);

   map<string , int> :: iterator RPLtePartProfIter;
   RPLtePartProfIter = g_spdPtr->m_RPLteProfMap.find(l_tempArr);
   if(RPLtePartProfIter != g_spdPtr->m_RPLteProfMap.end())
   {
      TLOG(0,0,"PARTNER LTE PROFILE MATCH FOUND [%d]",RPLtePartProfIter->second);
      return RPLtePartProfIter->second;
   }
   return 0;
}

bool CtxtLteInsertSubscriberDataRequest::sendResponse(InterModuleData *p_imd, int p_errorCode, char *p_errorDesc, char *p_ResponseBody)
{
   ProvisioningReqMsg *l_prm = (ProvisioningReqMsg*)(p_imd->m_msgPtr);
   LLOG(0,0,"SendResponse called error code: %d", p_errorCode);
   ProvisioningResMsg *l_provRespMsg = new ProvisioningResMsg;
   if(l_prm != NULL)
   {
      DLOG(0,0,"l_prm->m_sockFd: [%d]",l_prm->m_sockFd);
   }
   else
   {
      DLOG(0,0,"l_prm is null");
   }

   l_provRespMsg->m_sockFd = l_prm->m_sockFd;
   l_provRespMsg->m_OrigEntityName = l_prm->m_OrigEntityName;
   l_provRespMsg->m_IpAddress = l_prm->m_IpAddress;
   l_provRespMsg->m_DeviceConnectionType = l_prm->m_DeviceConnectionType;


   string& l_temp=l_provRespMsg->m_data;
   l_temp.assign("<RESPONSE>");
   l_temp.append("<HEADER>");
   l_temp.append("<TRANSACTION_ID>");
   l_temp.append("TRANS");
   l_temp.append("</TRANSACTION_ID>");
   l_temp.append("<REQUEST_TYPE>");
   if(NULL != strstr(p_ResponseBody, "TEMPLATE_ID"))
   {
      if(NULL == strstr(p_ResponseBody, "<BASIC>"))
         l_temp.append("GET_SUBSCRIBER_INFO");
      else
         l_temp.append("GET_SUBSCRIBER_DATA");

   }
   else
   {
      if(NULL == strstr(p_ResponseBody, "<BASIC>"))
         l_temp.append("GET_LOCATION_INFO");
      else
         l_temp.append("GET_LOCATION_DATA");

   }
   l_temp.append("</REQUEST_TYPE>");
   l_temp.append("<ERROR_CODE>0");
   /*
      char l_errorCode[10];
      memset(l_errorCode, '\0', sizeof(l_errorCode));
      sprintf(l_errorCode, "%d", p_errorCode);
      l_temp.append(l_errorCode);
      */
   l_temp.append("</ERROR_CODE>");
   l_temp.append("<ERROR_DESC>");
   l_temp.append(p_errorDesc);
   l_temp.append("</ERROR_DESC>");
   l_temp.append("</HEADER>");

   if(NULL != p_ResponseBody) //strlen(p_ResponseBody) > 0)
   {
      LLOG(0,0,"Body is present");
      l_temp.append("<BODY>");
      l_temp.append(p_ResponseBody);
      if(p_errorCode != 0)
      {
         if(NULL != strstr(p_ResponseBody, "<BASIC>"))
         {
            l_temp.append("<EXTENDED>");
         }
         l_temp.append("<REMOTE_ENTITY_DATA>");
         l_temp.append("<REMOTE_ERROR_CODE>");
         char l_errorCode[10];
         memset(l_errorCode, '\0', sizeof(l_errorCode));
         sprintf(l_errorCode, "%d", p_errorCode);
         l_temp.append(l_errorCode);
         l_temp.append("</REMOTE_ERROR_CODE>");
         l_temp.append("<REMOTE_ERROR_DESC>");
         l_temp.append(p_errorDesc);
         l_temp.append("</REMOTE_ERROR_DESC>");
         l_temp.append("</REMOTE_ENTITY_DATA>");
         if(NULL != strstr(p_ResponseBody, "<BASIC>"))
         {
            l_temp.append("</EXTENDED>");
         }
      }
      else
      {
         l_temp.append("<REMOTE_ERROR_CODE>0</REMOTE_ERROR_CODE>");
         l_temp.append("<REMOTE_ERROR_DESC>Success</REMOTE_ERROR_DESC>");
         if(NULL != strstr(p_ResponseBody, "<BASIC>"))
         {
            l_temp.append("</REMOTE_ENTITY_DATA></EXTENDED>");
         }
         else
         {
            l_temp.append("</REMOTE_ENTITY_DATA>");
         }
      }
      l_temp.append("</BODY>");
   }
   l_temp.append("</RESPONSE>");


   LLOG(1,1,"XML: SendResponse end [%s]", (char*)l_temp.c_str());


   return g_tcpSocketQueue->push(l_provRespMsg);
}

bool CtxtLteInsertSubscriberDataRequest::getSubscriberLocInfoResp(Msg *p_MsgPtr)
{
   char l_respstring[MAX_RESPONSE_BUFF_SIZE+1];
   char l_tempstr[400];
   memset(l_tempstr,'\0',sizeof(l_tempstr));
   memset(l_respstring,'\0',sizeof(l_respstring));
   snprintf(l_respstring, MAX_RESPONSE_BUFF_SIZE, (char*)m_response.c_str());
   if(NULL != strstr(m_response.c_str(), "<BASIC>"))
   {
      strlcat(l_respstring, "<EXTENDED><REMOTE_ENTITY_DATA>", MAX_RESPONSE_BUFF_SIZE);
   }
   else
   {
      strlcat(l_respstring, "<REMOTE_ENTITY_DATA>", MAX_RESPONSE_BUFF_SIZE);
   }

   //unsigned l_cellid[50];
   //memset(l_cellid,'\0',sizeof(l_cellid));
   //HexToString((unsigned char*)l_cellid,l_temp->subscriberInfo.locationInformationGPRS.cellGlobalIdOrServiceAreaIdOrLAI.u.cellGlobalIdOrServiceAreaIdFixedLength.value,l_temp->subscriberInfo.locationInformationGPRS.cellGlobalIdOrServiceAreaIdOrLAI.u.cellGlobalIdOrServiceAreaIdFixedLength.length,false);
   LLOG(0,0,"Filling Location info from IDR"); 
   sprintf(l_tempstr,"<%s>%s</%s>","PS_LOCINFO_CELLID",m_locinfo_cellid.c_str(),"PS_LOCINFO_CELLID");
   strlcat(l_respstring,l_tempstr, MAX_RESPONSE_BUFF_SIZE);
   if(-1 == m_locinfo_ageof)
   {
      sprintf(l_tempstr,"<%s></%s>","PS_LOCINFO_AGEOF","PS_LOCINFO_AGEOF");
      strlcat(l_respstring,l_tempstr, MAX_RESPONSE_BUFF_SIZE);
   }
   else
   {
      sprintf(l_tempstr,"<%s>%d</%s>","PS_LOCINFO_AGEOF",m_locinfo_ageof,"PS_LOCINFO_AGEOF");
      strlcat(l_respstring,l_tempstr, MAX_RESPONSE_BUFF_SIZE);
   }
   sendResponse(m_imd, 0, "Success",l_respstring);
   return true;
}

string CtxtLteInsertSubscriberDataRequest::sendCancelLocation()
{
   char l_partner_type[10];
   string l_calLoc ;
#if 0
   if( -1 == m_partner_Type)
   {
      l_calLoc = "<CANCEL_LOC><IMSI>" + string(m_imsi) + "</IMSI><NODE_TYPE>MME</NODE_TYPE><ORIGIN_HOST>" + string(m_origin_Host) + "</ORIGIN_HOST><ORIGIN_REALM>" + string(m_origin_Realm) + "</ORIGIN_REALM><DESTINATION_HOST>" + string(m_destination_Host) + "</DESTINATION_HOST><DESTINATION_REALM>" + string(m_destination_Realm) + "</DESTINATION_REALM><UPDATE_SUBS_DATA>1</UPDATE_SUBS_DATA><CL_TYPE>0</CL_TYPE><REQUEST_TYPE>IDR_FAILURE</REQUEST_TYPE></CANCEL_LOC>";
      LLOG(0,0,"IDR failed, sending Cancel Location towards MME Host [%s] CLR :%s:", m_destination_Host , l_calLoc.c_str());
   }
   else
   {
#endif
      if( -1 != m_partner_Type)
         sprintf(l_partner_type, "%d", m_partner_Type);
      else
         memset(l_partner_type, 0, sizeof(l_partner_type));
      l_calLoc = "<CANCEL_LOC><IMSI>" + string(m_imsi) + "</IMSI><NODE_TYPE>MME</NODE_TYPE><ORIGIN_HOST>" + string(m_origin_Host) + "</ORIGIN_HOST><ORIGIN_REALM>" + string(m_origin_Realm) + "</ORIGIN_REALM><DESTINATION_HOST>" + string(m_destination_Host) + "</DESTINATION_HOST><DESTINATION_REALM>" + string(m_destination_Realm) + "</DESTINATION_REALM><UPDATE_SUBS_DATA>1</UPDATE_SUBS_DATA><CL_TYPE>0</CL_TYPE><IMSI_TYPE>"+string(l_partner_type)+"</IMSI_TYPE><REQUEST_TYPE>IDR_FAILURE</REQUEST_TYPE></CANCEL_LOC>";
      LLOG(0,0,"IDR failed, sending Cancel Location towards MME Host [%s] CLR :%s:", m_destination_Host , l_calLoc.c_str());
      //}
      g_esc.initiateIndependentContext(this, DIAM_COMM_CODE_S6A_S6D_CLR_CLA, (char*)l_calLoc.c_str(), INITIATION_TYPE_IMMEDIATE);
      return l_calLoc;
}
bool CtxtLteInsertSubscriberDataRequest::getTransactionId(char *p_Req)
{
   int l_len = 0;
   char l_transactionId [MAX_TRANSACTION_LEN + 1];
   memset(l_transactionId, '\0', sizeof(l_transactionId));
   char *l_ptr = strstr(p_Req, ":");
   if(NULL != l_ptr)
   {
      l_len = strlen(p_Req) - strlen(l_ptr);
      strncpy(m_transactionId, p_Req, l_len);
      return true;
   }
   return false;

}

CtxtLteInsertSubscriberDataRequest::~CtxtLteInsertSubscriberDataRequest()
{
   DLOG(0,0,"CtxtLteInsertSubscriberDataRequest :des:");
   if(NULL != m_imd)
   {
      delete m_imd;
      m_imd = NULL;
   }
}
bool CtxtLteInsertSubscriberDataRequest::preInsertSubscriberData(char *p_req)
{
   if(m_getsubsflag == true)
   {
      DLOG(0,0,"Inside preInsertSubscriberData: m_getsubsflag is set");
      diameter::s6a_r10::InsertSubscriberDataRequest l_idrData;
      diameter::s6a_r10::InsertSubscriberDataRequest *l_temp = &l_idrData;
      AuthSessionState l_tempauthSessionState(AuthSessionState::NO_STATE_MAINTAINED);
      l_temp->setAuthSessionState(l_tempauthSessionState);

      m_response = ConfigReader::readValue(p_req, "RESPONSE");

      string l_origin = ConfigReader::readValue(p_req, "ACTIVE_HSS_ORIGIN_HOST");
      if(l_origin.size() < 1)
      {
         CLOG(0,0,"GET_SUBSCRIBER_INFO: ACTIVE_HSS_ORIGIN_HOST is not found");
         m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE);
         return false;
      }
      else if(l_origin.size() > 0 )
      {
         DLOG(0,0,"GET_SUBSCRIBER_INFO: IDR OriginHost: %s", l_origin.c_str());
         strcpy(m_origin_Host, l_origin.c_str());
         m_tdr.setString(TDR_INDEX_LOCAL_HOST, m_origin_Host);
         OriginHost l_temporiginHost = diameter::base::OriginHost(l_origin.c_str());
         l_temp->setOriginHost(l_temporiginHost);
      }

      string l_originrealm = ConfigReader::readValue(p_req, "ACTIVE_HSS_ORIGIN_REALM");
      if(l_originrealm.size() < 1)
      {
         CLOG(0,0,"GET_SUBSCRIBER_INFO: ACTIVE_HSS_ORIGIN_REALM is not found");
         m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE);
         return false;
      }
      else if(l_originrealm.size() > 0)
      {
         DLOG(0,0,"GET_SUBSCRIBER_INFO: IDR OriginRealm: %s", l_originrealm.c_str());
         strcpy(m_origin_Realm, l_originrealm.c_str());
         m_tdr.setString(TDR_INDEX_LOCAL_REALM, m_origin_Realm);
         OriginRealm l_temporiginRealm(l_originrealm.c_str());
         l_temp->setOriginRealm(l_temporiginRealm);
      }

      string l_destinationhost = ConfigReader::readValue(p_req, "MME_HOST");
      if(l_destinationhost.size() < 1)
      {
         CLOG(0,0,"GET_SUBSCRIBER_INFO: MME_HOST is not found");
         m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE);
         return false;
      }
      else if(l_destinationhost.size() > 0)
      {
         DLOG(0,0,"GET_SUBSCRIBER_INFO: IDR DestinationHost: %s", l_destinationhost.c_str());
         strcpy(m_destination_Host, l_destinationhost.c_str());
         DestinationHost l_tempdestinationHost(l_destinationhost.c_str());
         l_temp->setDestinationHost(l_tempdestinationHost);
      }

      string l_destinationrealm = ConfigReader::readValue(p_req, "MME_REALM");
      if(l_destinationrealm.size() < 1)
      {
         CLOG(0,0,"GET_SUBSCRIBER_INFO: MME_HOST is not found");
         m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE);
         return false;
      }
      else if(l_destinationrealm.size() > 0 )
      {
         DLOG(0,0,"GET_SUBSCRIBER_INFO: IDR DestinationRealm: %s", l_destinationrealm.c_str());
         strcpy(m_destination_Realm, l_destinationrealm.c_str());
         m_tdr.setString(TDR_INDEX_REMOTE_REALM, m_destination_Realm);
         DestinationRealm l_tempdestinationRealm(l_destinationrealm.c_str());
         l_temp->setDestinationRealm(l_tempdestinationRealm);
      }
      LLOG(0,0,"GET_SUBSCRIBER_INFO: Sending IDR Request OriginHost: %s OriginRealm: %s DestinationHost: %s DestinationRealm: %s", m_origin_Host, m_origin_Realm, m_destination_Host, m_destination_Realm);

      string l_imsi = ConfigReader::readValue(p_req, "ACTIVE_IMSI");
      if(l_imsi.size() < 1)
      {
         CLOG(0,0,"GET_SUBSCRIBER_INFO: IMSI is not found");
         m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE);
         return false;
      }
      strcpy(m_imsi, l_imsi.c_str());
      UserName l_tempuserName((char*)l_imsi.c_str());
      LLOG(0,0,"GET_SUBSCRIBER_INFO: IDR IMSI: %s", l_imsi.c_str());
      l_temp->setUserName(l_tempuserName);
      m_tdr.setString(TDR_INDEX_REQUEST_IMSI,(char*)l_imsi.c_str());

      SubscriberStatus l_tempsubStatus(SubscriberStatus::SERVICEGRANTED);

      SubscriptionData  sub;
      l_temp->setSubscriptionData(0);

      string l_nwid = ConfigReader::readValue(p_req, "NW_ID");
      if(l_nwid.size() < 1)
      {
         LLOG(0,0,"Network ID tag not found setting IDR Flag as 24");
         IDRFlags l_tempidrFlag(24);
         l_temp->setIDRFlags(l_tempidrFlag);
         m_tdr.setInteger(TDR_INDEX_SSM_NO_REP_TIMER, 24);
      }
      else
      {
         int l_temp_nwid = atoi(l_nwid.c_str());
         map<int, HlrNetworks* > :: iterator l_HlrNetworksDetailsIter;
         l_HlrNetworksDetailsIter = g_spdPtr->m_HlrNetworks.find(l_temp_nwid);
         if(l_HlrNetworksDetailsIter == g_spdPtr->m_HlrNetworks.end())
         {
            LLOG(0,0,"Network ID not found setting IDR Flag as 24");
            IDRFlags l_tempidrFlag(24);
            l_temp->setIDRFlags(l_tempidrFlag);
            m_tdr.setInteger(TDR_INDEX_SSM_NO_REP_TIMER, 24);
         }
         else
         {
            int l_idrFlag = (l_HlrNetworksDetailsIter->second)->m_GetPsDataIdrFlag;
            LLOG(0,0,"IDR Flag for GetPsData is ... [%d]",l_idrFlag);
            m_tdr.setInteger(TDR_INDEX_SSM_NO_REP_TIMER, l_idrFlag);
            m_tdr.setInteger(TDR_INDEX_SSM_FTN_SUB_ADDR, (l_HlrNetworksDetailsIter->second)->m_GetPsDataPref);

            if(0 != l_idrFlag)
            {
               IDRFlags l_tempidrFlag(l_idrFlag);
               l_temp->setIDRFlags(l_tempidrFlag);
            }
            else
            {
               LLOG(0,0,"IDR Flag disabled for the network .. not sending");
            }
         }
      }
      unsigned int sIdx;
      string sessIdString;
      if(false == g_esc.allocateSession(DIAM_APP_ID_S6A_S6D,
               sIdx,
               sessIdString))
      {
         ELOG(0,1,"GET_SUBSCRIBER_INFO: Unable to allocate a session");
         m_tdr.setString(TDR_ERROR_UNABLE_TO_INITIATE, "Unable to allocate a session");
         return false;
      }
      DiameterMsg l_idr((char *)sessIdString.c_str(),DIAM_EVENT_REQUEST,DIAM_COMM_CODE_S6A_S6D_S7A_S7D_IDR_IDA);

      l_idrData.setSessionId(diameter::base::SessionId(sessIdString));
      l_idrData.setSessionIndex(sIdx);

      ITS_UINT l_idx = l_idrData.getSessionIndex();
      LLOG(0,0,"GET_SUBSCRIBER_INFO: IDR Session Id : %d", l_idx);

      l_idr.m_cmd = &l_idrData;
      g_esc.sendMsg(this, &l_idr);
      return true;
   }
   else
   {
      if( false == getTransactionId(p_req))
      {
         LLOG(0,0,"InsetSubscriber Request Transaction Id not found]");
         m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE);
         return false;
      }

      m_response = ConfigReader::readValue(p_req, "IDR");
      LLOG(0,0,"InsetSubscriber Request Transaction Id : [%s]",m_transactionId);
      if(m_response.size() < 1)
      {
         CLOG(0,0,"Get Insert Subscriber Data tag not found");
         m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE);
         return false;
      }
      string l_imsi = ConfigReader::readValue(p_req, "IMSI");
      if(l_imsi.size() < 1)
      {
         CLOG(0,0,"IMSI is not found");
         m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE);
         return false;
      }
      string l_partner_type = ConfigReader::readValue(p_req, "PARTNER_TYPE");
      if(l_partner_type.size() > 0)
      {
         m_partner_Type = atoi(l_partner_type.c_str()); 
         LLOG(0,0,"IDR Partner Type: %d", m_partner_Type);
      }
      strcpy(m_imsi, l_imsi.c_str());

      //4.0.5.1
      string l_partnerId = ConfigReader::readValue(p_req, "ACTIVE_PARTNER_NW_ID");
      if(l_partnerId.size() > 0)
      {
         m_partner_nkId = atoi(l_partnerId.c_str()); 
         LLOG(0,0,"IDR Partner NetworkID: %d", m_partner_nkId);
      }
      //5055
      string l_IPv4Addr = ConfigReader::readValue(p_req, "IPV4_ADDR");
      if(l_IPv4Addr.size() > 0)
      {
         m_IPv4Addr = l_IPv4Addr; 
         LLOG(0,0,"IDR IPV4_ADDR: %s", m_IPv4Addr.c_str());
      }

      string l_IPv6Addr = ConfigReader::readValue(p_req, "IPV6_ADDR");
      if(l_IPv6Addr.size() > 0)
      {
         m_IPv6Addr = l_IPv6Addr; 
         LLOG(0,0,"IDR IPV6_ADDR: %s", m_IPv6Addr.c_str());
      }

      string l_NwkId = ConfigReader::readValue(p_req, "NETWORK_ID");
      if(l_NwkId.size() > 0)
      {
         m_Nwk_Id = atoi(l_NwkId.c_str()); 
         LLOG(0,0,"IDR NETWORK_ID: %d", m_Nwk_Id);
      }

      //6.4.0.0 Start
      string l_PgwIp4 = ConfigReader::readValue(p_req, "PGW_IP4");
      if(l_PgwIp4.size() > 0)
      {
         snprintf((char*)m_SarIpv4Address,sizeof(m_SarIpv4Address),"%s",(char*)l_PgwIp4.c_str());
         LLOG(0,0,"IDR PGW_IP4: %s", m_SarIpv4Address);
         m_tdr.setString(TDR_INDEX_NOR_MIP6AI_HA_ADDR1,(char*)l_PgwIp4.c_str());
      }
      string l_PgwIp6 = ConfigReader::readValue(p_req, "PGW_IP6");
      if(l_PgwIp6.size() > 0)
      {
         snprintf((char*)m_SarIpv6Address,sizeof(m_SarIpv6Address),"%s",(char*)l_PgwIp6.c_str());
         LLOG(0,0,"IDR PGW_IP6: %s", m_SarIpv6Address);
         m_tdr.setString(TDR_INDEX_NOR_MIP6AI_HA_ADDR2,(char*)l_PgwIp6.c_str());
      }
      //6.4.0.0 End
      //5055
      string l_pgwHost = ConfigReader::readValue(p_req, "PGW_HOST");
      if(l_pgwHost.size() > 0)
      {
         snprintf((char*)m_SarPgwHost,sizeof(m_SarPgwHost),"%s",(char*)l_pgwHost.c_str());
         LLOG(0,0,"IDR PGW_IP4: %s", m_SarPgwHost);
         m_tdr.setString(TDR_INDEX_NOR_MIP6AI_HA_DEST_HOST,(char*)l_pgwHost.c_str());
      }
      string l_pgwRealm = ConfigReader::readValue(p_req, "PGW_REALM");
      if(l_pgwRealm.size() > 0)
      {
         snprintf((char*)m_SarPgwRealm,sizeof(m_SarPgwRealm),"%s",(char*)l_pgwRealm.c_str());
         LLOG(0,0,"IDR PGW_IP6: %s", m_SarPgwRealm);
         m_tdr.setString(TDR_INDEX_NOR_MIP6AI_HA_DEST_REALM,(char*)l_pgwRealm.c_str());
      }
      diameter::s6a_r10::InsertSubscriberDataRequest l_idrData;
      try
      {

         //Prepare a IDR 
         diameter::s6a_r10::InsertSubscriberDataRequest *l_temp = &l_idrData;
         AuthSessionState l_tempauthSessionState(AuthSessionState::NO_STATE_MAINTAINED);
         l_temp->setAuthSessionState(l_tempauthSessionState);

         string l_origin = ConfigReader::readValue(p_req, "ORIGIN_HOST");

         if(l_origin.size() > 0 )
         {
            DLOG(0,0,"IDR OriginHost: %s", l_origin.c_str());
            strcpy(m_origin_Host, l_origin.c_str());
            m_tdr.setString(TDR_INDEX_LOCAL_HOST, m_origin_Host);
            OriginHost l_temporiginHost = diameter::base::OriginHost(l_origin.c_str());
            l_temp->setOriginHost(l_temporiginHost);
         }

         string l_originrealm = ConfigReader::readValue(p_req, "ORIGIN_REALM");
         if(l_originrealm.size() > 0)
         {
            DLOG(0,0,"IDR OriginRealm: %s", l_originrealm.c_str());
            strcpy(m_origin_Realm, l_originrealm.c_str());
            m_tdr.setString(TDR_INDEX_LOCAL_REALM, m_origin_Realm);
            OriginRealm l_temporiginRealm(l_originrealm.c_str());
            l_temp->setOriginRealm(l_temporiginRealm);
         }

         string l_destinationhost = ConfigReader::readValue(p_req, "DESTINATION_HOST");

         if(l_destinationhost.size() > 0)
         {
            DLOG(0,0,"IDR DestinationHost: %s", l_destinationhost.c_str());
            strcpy(m_destination_Host, l_destinationhost.c_str());
            DestinationHost l_tempdestinationHost(l_destinationhost.c_str());
            l_temp->setDestinationHost(l_tempdestinationHost);
         }

         string l_destinationrealm = ConfigReader::readValue(p_req, "DESTINATION_REALM");

         if(l_destinationrealm.size() > 0 )
         {
            DLOG(0,0,"IDR DestinationRealm: %s", l_destinationrealm.c_str());
            strcpy(m_destination_Realm, l_destinationrealm.c_str());
            m_tdr.setString(TDR_INDEX_REMOTE_REALM, m_destination_Realm);
            DestinationRealm l_tempdestinationRealm(l_destinationrealm.c_str());
            l_temp->setDestinationRealm(l_tempdestinationRealm);
         }
         LLOG(0,0,"Sending IDR Request OriginHost: %s OriginRealm: %s DestinationHost: %s DestinationRealm: %s", m_origin_Host, m_origin_Realm, m_destination_Host, m_destination_Realm);

         UserName l_tempuserName((char*)l_imsi.c_str());
         LLOG(0,0,"IDR IMSI: %s", l_imsi.c_str());
         l_temp->setUserName(l_tempuserName);
         m_tdr.setChar(TDR_INDEX_REQUEST_TYPE,'I');
         m_tdr.setString(TDR_INDEX_REQUEST_IMSI,(char*)l_imsi.c_str());

         SubscriberStatus l_tempsubStatus(SubscriberStatus::SERVICEGRANTED);
         string l_idrflag = ConfigReader::readValue(p_req, "IDRFLAG");

         SubscriptionData  sub;
         if(l_idrflag.size() > 0)
         {
            LLOG(0,0,"IDR Flag: %s", l_idrflag.c_str());
            if(1 == atoi(l_idrflag.c_str()))
            {
               IDRFlags l_tempidrFlag(1);
               l_temp->setIDRFlags(l_tempidrFlag);
               //l_temp->setSubscriptionData(sub);
               string l_mmeFeatureList = ConfigReader::readValue(p_req, "MME_SUPP_FEATURE_1");
               LLOG(0,0,"MME Supported Feature List %s", l_mmeFeatureList.c_str());
               if(l_mmeFeatureList.size() > 0)
               {
                  m_mmeFeatureList1 = atoi(l_mmeFeatureList.c_str());
                  if(!(m_mmeFeatureList1 & F1_UEReachabilityNotification))
                  {
                     ELOG(0,1,"Subscriber [%s] IDR not Initiated,MME does not Support UE reachability bit",l_imsi.c_str());
                     m_tdr.setString(TDR_INDEX_OAM_FREE_FORMAT_DATA, "MME does not Support UE reachability bit");
                     m_tdr.setChar(TDR_INDEX_MSG_STATUS, 'F');
                     return false;
                  }
                  m_tdr.setUnsignedInteger(TDR_INDEX_REMOTE_SUPP_FEATURE_1, m_mmeFeatureList1);
               }
               else
               {
                  ELOG(0,1,"Subscriber [%s] IDR not Initiated,MME does not Support UE reachability bit",l_imsi.c_str());
                  return false;
               }
               LLOG(0,0,"Subscriber [%s] set as UE reachability",l_imsi.c_str());
            }
            else if( 64 == atoi(l_idrflag.c_str()))
            {
               LLOG(0,0,"Subscriber [%s] set as Remove SMS Registration",l_imsi.c_str());
               IDRFlags l_tempidrFlag(64);
               l_temp->setIDRFlags(l_tempidrFlag);
               //l_temp->setSubscriptionData(sub);

            }
            else 
            {
               LLOG(0,0,"Subscriber [%s] set as a [%s]",l_imsi.c_str(), l_idrflag.c_str());
               IDRFlags l_tempidrFlag(atoi(l_idrflag.c_str()));
               l_temp->setIDRFlags(l_tempidrFlag);
               // l_temp->setSubscriptionData(sub);
            }
         }
         else
         {
            string l_mmeFeature1 = ConfigReader::readValue(p_req, "MME_SUPP_FEATURE_1");
            if(l_mmeFeature1.size() > 0)
            {
               LLOG(0,0,"IDR MME FeatureList1 : %s", l_mmeFeature1.c_str());
            }
            string l_mmeFeature2 = ConfigReader::readValue(p_req, "MME_SUPP_FEATURE_2");
            if(l_mmeFeature2.size() > 0)
            {
               LLOG(0,0,"IDR MME FeatureList2 : %s", l_mmeFeature2.c_str());
               long l_mmeF2 = atol(l_mmeFeature2.c_str());
               m_mmeFeatureList2 = (unsigned int)l_mmeF2;
               // 5051A - 5gNSA
               if(m_mmeFeatureList2 & F2_NR_AS_SECONDARY_RAT)
               {
                  LLOG(0,0,"IDR MME Supported FeatureList2: NR_AS_SECONDARY_RAT");
                  m_5gSupportFlag = true;
               }
            }
         }

         string l_supportedfeature1= ConfigReader::readValue(p_req, "SUPP_FEATURE_1");
         if(l_supportedfeature1.size() > 0 )
         {
            LLOG(0,0,"IDR FeatureList : %s", l_supportedfeature1.c_str());
            SupportedFeatures l_tempsupportedfeature;
            //diameter::base::VendorId;
            VendorId l_tempvenderId(10415);
            l_tempsupportedfeature.setVendorId(l_tempvenderId);
            FeatureListID l_tempfeaturelistid(1);
            l_tempsupportedfeature.setFeatureListID(l_tempfeaturelistid);
            long l_supportfeatureList = atol(l_supportedfeature1.c_str());
            m_featureList1 = (unsigned int)l_supportfeatureList;
            m_featureList1 = m_featureList1 & ~F1_Partial_Purge;
            FeatureList l_tempfeaturelist(m_featureList1);
            m_tdr.setUnsignedInteger(TDR_INDEX_LOCAL_SUPP_FEATURE_1, l_supportfeatureList);
            LLOG(0,0,"IDR Sending FeatureList1 MME: %u", m_featureList1);
            l_tempsupportedfeature.setFeatureList(l_tempfeaturelist);
            l_temp->addSupportedFeatures(l_tempsupportedfeature);
         }
         string l_supportedfeature2= ConfigReader::readValue(p_req, "SUPP_FEATURE_2");
         string l_releaseVersion= ConfigReader::readValue(p_req, "S6A_RELEASE");
         LLOG(0,0,"IDR Supported Release Version : %s", l_releaseVersion.c_str());
         int l_tempreleaseVersion = atoi(l_releaseVersion.c_str());

         if((l_supportedfeature1.size() > 0 ) && ( l_tempreleaseVersion > 11))
         {
            SupportedFeatures l_tempsupportedfeature;
            //diameter::base::VendorId;
            VendorId l_tempvenderId(10415);
            l_tempsupportedfeature.setVendorId(l_tempvenderId);

            FeatureListID l_tempfeaturelistid(2);
            l_tempsupportedfeature.setFeatureListID(l_tempfeaturelistid);
            long l_supportfeatureList = atol(l_supportedfeature2.c_str());
            m_featureList2 = (unsigned int)l_supportfeatureList;
            m_featureList2 = m_featureList2 & ~F2_SMS_in_SGSN;
            if(m_featureList2 & F2_NR_AS_SECONDARY_RAT)
            {
               LLOG(0,0,"HLR supports NR_AS_SECONDARY_RAT and .. MME NR_AS_SECONDARY_RAT flag[%d]",m_5gSupportFlag);
               m_hlr_5gSupportFlag = true;
               if(false == m_5gSupportFlag)
               {
                  m_featureList2 = (m_featureList2 & (~F2_NR_AS_SECONDARY_RAT));
                  LLOG(0,0,"Not Sending NR_AS_SECONDARY_RAT in IDR as MME not supporting..Modified FeatureList2[%u]",m_featureList2);
               }
            }
            if(m_featureList2 > 0)
            {
               FeatureList l_tempfeaturelist(m_featureList2);
               m_tdr.setUnsignedInteger(TDR_INDEX_LOCAL_SUPP_FEATURE_2, l_supportfeatureList);
               LLOG(0,0,"IDR Sending FeatureList2 MME: %u", m_featureList2);
               l_tempsupportedfeature.setFeatureList(l_tempfeaturelist);
               l_temp->addSupportedFeatures(l_tempsupportedfeature);
            }
            else
            {
               LLOG(0,0,"IDR NOT sending Featurelist2 as modified value is zero");
            }
         }


         string l_msisdn = ConfigReader::readValue(p_req, "MSISDN");

         if(l_msisdn.size() > 0)
         {
            m_tdr.setChar(TDR_INDEX_REQUEST_TYPE, 'M');
            m_tdr.setString(TDR_INDEX_REQUEST_MSISDN, (char*)l_msisdn.c_str()); //HLR 2.0.25.2A
            unsigned char l_BcdStnSr[20 + 1];
            memset(l_BcdStnSr,'\0',sizeof(l_BcdStnSr));
            int l_bcdLen = StringToBCD(l_BcdStnSr, (u8*)(l_msisdn.c_str()), strlen(l_msisdn.c_str()));

            string l_msisdn1;
            l_msisdn1.assign((char*)l_BcdStnSr, l_bcdLen);
            MSISDN msisdn(l_msisdn1);
            sub.setMSISDN(msisdn);
            LLOG_HEX(0,0,"IDR: Msisdn", l_BcdStnSr, l_bcdLen); 
         }

         /*string l_stnsr = ConfigReader::readValue(p_req, "STN_SR");

           if(l_stnsr.size() > 0)
           {
           STNSR l_tempstnsr("STNSR");
           sub.setSTNSR(l_tempstnsr);
           }*/

         string l_ImsService = ConfigReader::readValue(p_req, "IMS_SERVICE");
         if(l_ImsService.size() > 0)
         {
            m_ims_service_flag = atoi(l_ImsService.c_str());
            LLOG(0,0,"IMS service flag[%d]",m_ims_service_flag);
            m_tdr.setInteger(TDR_INDEX_UAR_CAPABILITY_TEMPL_ID,m_ims_service_flag);
         } 

         if(1 == m_ims_service_flag)
         {
            string l_ImsProfId = ConfigReader::readValue(p_req, "IMS_PROF_ID");
            if(l_ImsProfId.size() > 0)
            {
               int l_imsProfId = atoi(l_ImsProfId.c_str());
               LLOG(0,0,"IMS Profile ID [%d]",l_imsProfId);
               m_tdr.setInteger(TDR_INDEX_IMS_PROFILE_ID,l_imsProfId);
               unsigned char l_SrvccStnSr[255 + 1];
               memset(l_SrvccStnSr,'\0',sizeof(l_SrvccStnSr));
               map<int,ImsProf> :: iterator l_ImsProfMapIter;
               l_ImsProfMapIter = g_spdPtr->m_imsProfMap.find(atoi(l_ImsProfId.c_str()));
               if(l_ImsProfMapIter != g_spdPtr->m_imsProfMap.end())
               {
                  TLOG(0,0,"IDR: SubscriptionData: ImsProfId[%d] found in ImsProf Map",atoi(l_ImsProfId.c_str()));
                  if(' ' != l_ImsProfMapIter->second.m_SrvccStnSr[0])
                  {
                     TLOG(0,0,"STN-SR[%s] not NULL for ImsProfileId[%d], filling STN-SR",l_ImsProfMapIter->second.m_SrvccStnSr,atoi(l_ImsProfId.c_str()));
                     int l_bcdLen = StringToBCD(l_SrvccStnSr, (u8*)l_ImsProfMapIter->second.m_SrvccStnSr, strlen(l_ImsProfMapIter->second.m_SrvccStnSr));
                     string l_stnsr;
                     l_stnsr.assign((char*)l_SrvccStnSr, l_bcdLen);
                     STNSR stnsr(l_stnsr);
                     sub.setSTNSR(stnsr);
                     LLOG_HEX(0,0,"IDR: SubscriptionData: StnSr From ImsProfile", l_SrvccStnSr, l_bcdLen);
                  }
                  else
                  {
                     LLOG(0,0,"STN-SR[%s] is NULL for ImsProfileId[%d, not sending STN-SR]",l_ImsProfMapIter->second.m_SrvccStnSr,atoi(l_ImsProfId.c_str()));
                  }
               }
               else
               {
                  TLOG(0,0,"IDR: SubscriptionData: ImsProfId[%d] Not found in ImsProf Map, not sending STN-SR",atoi(l_ImsProfId.c_str()));
               }
            }
            else
            {
               DLOG(0,0,"IMS_PROF_ID tag not found in IDR XML, not sending STN-SR");
            }
         }
         else
         {
            TLOG(0,0,"IMS service flag is 0, not sending STN-SR");
         }


         string l_odb = ConfigReader::readValue(p_req, "ODB");
         string l_hplmnodb = ConfigReader::readValue(p_req, "HPLMN_ODB");

         if((l_odb.size() > 0) || (l_hplmnodb.size() > 0))
         {
            if(l_odb.size() > 0)
            {
               m_odbDataSend = true;
               LLOG(0,0,"IDR ODB: %s", l_odb.c_str());
               m_modifyOdb = atoi(l_odb.c_str());
               OperatorDeterminedBarring l_tempopDet(atoi(l_odb.c_str()));
               sub.setOperatorDeterminedBarring(l_tempopDet);
            }

            if(l_hplmnodb.size() > 0)
            {
               LLOG(0,0,"IDR HPLMN: %s", l_hplmnodb.c_str());
               SubscriberStatus l_tempsubStatus(SubscriberStatus::OPERATORDETERMINEDBARRING);
               unsigned int hplm = atoi(l_hplmnodb.c_str());
               if( 15 == hplm)
               {
                  HPLMNODB _l_temphplmnodb(4);
                  sub.setHPLMNODB(_l_temphplmnodb);
               }
               else if( 7 == hplm)
               {
                  HPLMNODB _l_temphplmnodb(3);
                  sub.setHPLMNODB(_l_temphplmnodb);
               }
               else if( 3 == hplm)
               {
                  HPLMNODB _l_temphplmnodb(2);
                  sub.setHPLMNODB(_l_temphplmnodb);
               }
               else
               {
                  HPLMNODB _l_temphplmnodb(1);
                  sub.setHPLMNODB(_l_temphplmnodb);
               }
            }

            if((0 == atoi(l_odb.c_str())) && (0 == atoi(l_hplmnodb.c_str())))
            {
               m_odbDataSend = false;
               SubscriberStatus l_tempsubStatus(SubscriberStatus::SERVICEGRANTED);
               sub.setSubscriberStatus(l_tempsubStatus);
            }
            else
            {
               SubscriberStatus l_tempsubStatus(SubscriberStatus::OPERATORDETERMINEDBARRING);
               sub.setSubscriberStatus(l_tempsubStatus);
            }
         }

         string l_nam = ConfigReader::readValue(p_req, "NAM");

         if(l_nam.size() > 0)
         {
            LLOG(0,0,"IDR NAM: %s", l_nam.c_str());
            if( 0 == atoi(l_nam.c_str()))
            {
               NetworkAccessMode l_tempnetAccess(NetworkAccessMode::PACKET_AND_CIRCUIT);
               sub.setNetworkAccessMode(l_tempnetAccess);
            }
            else if ( 2 == atoi(l_nam.c_str()))
            {
               NetworkAccessMode l_tempnetAccess(NetworkAccessMode::ONLY_PACKET);
               sub.setNetworkAccessMode(l_tempnetAccess);
            }
         }
         string l_ard = ConfigReader::readValue(p_req, "ACCESS_RESTRICTION_DATA");
         if(l_ard.size() > 0)
         {
            LLOG(0,0,"IDR AccessRestictionData: %s", l_ard.c_str());
            AccessRestrictionData l_tempard(atoi(l_ard.c_str()));
            sub.setAccessRestrictionData(l_tempard);
         }

         string l_apnoir = ConfigReader::readValue(p_req,"APN_OI_REPLACEMENT");// Apnoi Replace ment
         if(l_apnoir.size() > 0)
         {
            LLOG(0,0,"IDR APNOIReplacement: %s", l_ard.c_str());
            APNOIReplacement l_tempapnreplace(l_apnoir.c_str());
            sub.setAPNOIReplacement(l_tempapnreplace);
         }


         string l_lcsinfo = ConfigReader::readValue(p_req,"LCS_INFO");

         if(l_lcsinfo.size() > 0)
         {
            LLOG(0,0,"IDR LCSINFO: %s", l_lcsinfo.c_str());
            string l_gmlc = ConfigReader::readValue(l_lcsinfo,"GMLC_NUMBER");
            LCSInfo l_templcsinfo;
            if(l_gmlc.size() > 0)
            {
               LLOG(0,0,"IDR GMLCNumber: %s", l_gmlc.c_str());
               GMLCNumber l_tempgmlc("GMLCNumber");
               l_templcsinfo.addGMLCNumber(l_tempgmlc);
            }
            string l_lcspexcption = ConfigReader::readValue(l_lcsinfo,"LCS_PRI_EXCEPTION");
            if(l_lcspexcption.size() > 0)
            {
               LLOG(0,0,"IDR LCSPrivacyException: %s", l_lcspexcption.c_str());
               LCSPrivacyException l_templcsprivacyexception;
               string l_sscode = ConfigReader::readValue(l_lcspexcption,"SS_CODE");
               SSCode l_tempsscode(l_sscode.c_str());
               l_templcsprivacyexception.setSSCode(l_tempsscode);
               string l_ssstatus = ConfigReader::readValue(l_lcspexcption,"SS_STATUS");
               SSStatus l_tempssstatus(l_ssstatus.c_str());
               l_templcsprivacyexception.setSSStatus(l_tempssstatus);
               string l_notifyuser = ConfigReader::readValue(l_lcspexcption,"NOTIFY_USER");
               if(0 == atoi(l_notifyuser.c_str()))
               {
                  NotificationToUEUser l_tempnotifyuser(NotificationToUEUser::NOTIFY_LOCATION_ALLOWED);
                  l_templcsprivacyexception.setNotificationToUEUser(l_tempnotifyuser);
               }
               else if(1 == atoi(l_notifyuser.c_str()))
               {
                  NotificationToUEUser l_tempnotifyuser(NotificationToUEUser::NOTIFYANDVERIFY_LOCATION_ALLOWED_IF_NO_RESPONSE);
                  l_templcsprivacyexception.setNotificationToUEUser(l_tempnotifyuser);
               }
               else if(2 == atoi(l_notifyuser.c_str()))
               {
                  NotificationToUEUser l_tempnotifyuser(NotificationToUEUser::NOTIFYANDVERIFY_LOCATION_NOT_ALLOWED_IF_NO_RESPONSE);
                  l_templcsprivacyexception.setNotificationToUEUser(l_tempnotifyuser);
               }
               else if(3 == atoi(l_notifyuser.c_str()))
               {
                  NotificationToUEUser l_tempnotifyuser(NotificationToUEUser::LOCATION_NOT_ALLOWED);
                  l_templcsprivacyexception.setNotificationToUEUser(l_tempnotifyuser);
               }
               l_templcsinfo.addLCSPrivacyException(l_templcsprivacyexception);
            }
            string l_molr = ConfigReader::readValue(l_lcsinfo,"MOLR");
            if(l_molr.size() > 0)
            {
               LLOG(0,0,"IDR MOLR: %s", l_molr.c_str());
               MOLR l_tempmolr;
               string l_sscode = ConfigReader::readValue(l_molr,"SS_CODE");
               LLOG(0,0,"IDR MOLR SScode: %s", l_sscode.c_str());
               SSCode l_tempsscode(l_sscode.c_str());
               l_tempmolr.setSSCode(l_tempsscode);
               string l_ssstatus = ConfigReader::readValue(l_molr,"SS_STATUS");
               LLOG(0,0,"IDR MOLR SSstatus: %s", l_ssstatus.c_str());
               SSStatus l_tempssstatus(l_ssstatus.c_str());
               l_tempmolr.setSSStatus(l_tempssstatus);
               l_templcsinfo.addMOLR(l_tempmolr);
            }
            sub.setLCSInfo(l_templcsinfo);
         }

         string l_telsrv = ConfigReader::readValue(p_req,"TELE_SRVC_LIST");
         if(l_telsrv.size() > 0 )
         {
            LLOG(0,0,"IDR TeleService List: %s", l_telsrv.c_str());
            char l_temp[50];
            memset(l_temp, '\0', sizeof(l_temp));
            for(int i = 1; i < 10 ; i++)
            {
               sprintf(l_temp,"CODE_%2d",i);
               string l_telcode = ConfigReader::readValue(l_telsrv, l_temp);
               if(l_telcode.size() > 0)
               {
                  LLOG(0,0,"IDR Set TeleService Code: %s", l_telcode.c_str());
                  TeleserviceList l_temptelService;
                  TSCode l_temptscode(l_telcode.c_str());
                  l_temptelService.addTSCode(l_temptscode);
                  sub.setTeleserviceList(l_temptelService);
               }
               else
               {
                  break;
               }
            }
         }
         string l_callbar = ConfigReader::readValue(p_req,"SS_CALL_BARRING_LIST");

         if(l_callbar.size() > 0)
         {
            LLOG(0,0,"IDR CallBarringInforList List: %s", l_callbar.c_str());
            char l_temp[50];
            memset(l_temp, '\0', sizeof(l_temp));
            for(int i ; i< 10; i++)
            {
               sprintf(l_temp,"Call-Barring-Info%2d",i);
               string l_callbar1 = ConfigReader::readValue(l_callbar, l_temp);
               if(l_callbar.size() > 0)
               {
                  string l_code = ConfigReader::readValue(l_callbar1,"SS_CODE");
                  if(l_code.size() > 0)
                  {
                     CallBarringInforList l_tempcallbarring;
                     SSCode l_tempsscode(l_code.c_str());
                     l_tempcallbarring.addSSCode(l_tempsscode);
                     sub.setCallBarringInforList(l_tempcallbarring);
                  }
               }
            }
         }
         string l_3gppcharging = ConfigReader::readValue(p_req,"3GPP_CHARGING_CHAR");

         if(l_3gppcharging.size() > 0)
         {
            LLOG(0,0,"IDR S6a3GPPChargingCharacteristics: %s", l_3gppcharging.c_str());
            S6a3GPPChargingCharacteristics l_temps6a3gppchar(l_3gppcharging.c_str());
            sub.setS6a3GPPChargingCharacteristics(l_temps6a3gppchar);
         }

         /*
            string l_ambr = ConfigReader::readValue(p_req, "AMBR");

            if(l_ambr.size() > 0)
            {
            AMBR l_tempamrb;
            string l_ambrul = ConfigReader::readValue(p_req, "AMBR_UL");
            MaxRequestedBandwidthUL l_tempmaxReqBwUL(atoi(l_ambrul.c_str()));
            l_tempamrb.setMaxRequestedBandwidthUL(l_tempmaxReqBwUL);
            string l_ambrdl = ConfigReader::readValue(p_req, "AMBR_DL");
            MaxRequestedBandwidthDL l_tempmaxReqBwDL(atoi(l_ambrdl.c_str()));
            LLOG(0,0,"IDR AMBR UL : %s AMBR DL : %s", l_ambrul.c_str(), l_ambrdl.c_str());
            l_tempamrb.setMaxRequestedBandwidthDL(l_tempmaxReqBwDL);
            sub.setAMBR(l_tempamrb);
            }
            */


         string l_lteconfipro = ConfigReader::readValue(p_req, "LTE_CONFIG_PROF_ID"); 
         if((l_lteconfipro.size() > 0) && (atoi(l_lteconfipro.c_str()) > 0))
         {
            LteConfigProf* l_lteProfDetails = NULL;
            if(NULL == g_spdPtr->m_hssProfile)
            {
               LLOG(0,0,"IDA: g_spdPtr->m_hssProfile is NULL can't Initiated IDR LTE_CONFIG_PROF_ID[%d]", l_lteconfipro.c_str());
               m_tdr.setString(TDR_INDEX_OAM_FREE_FORMAT_DATA, "Profile not loaded");
               m_tdr.setChar(TDR_INDEX_MSG_STATUS, 'F');
               return false;

            }
            if(0 == m_partner_nkId)
            {
               LLOG(0,0,"Partner Network Id is 0, not checking for mapped Partner LteProfileId");
            }
            else
            {
               TLOG(0,0,"Partner Network Id is not 0, checking for mapped partnerLteProfId");
               int l_tempPartLetProfId = getPartnerIdrLteProfId(atoi(l_lteconfipro.c_str()),m_Nwk_Id,m_partner_nkId);
               ostringstream l_str;
               l_str << l_tempPartLetProfId;
               if(0 != l_tempPartLetProfId)
               {
                  LLOG(0,0,"Partner LTE Profile found[%d]",l_tempPartLetProfId);
                  l_lteconfipro = l_str.str();
               }
               else
               {
                  WLOG(0,0,"Partner LTE Profile Not found, using [%d]",l_lteconfipro.c_str());
               }
            }

            int l_lteConfProf = atoi(l_lteconfipro.c_str());
            LLOG(0,0,"Lte Profile Id [%d]",l_lteConfProf);
            m_tdr.setInteger(TDR_INDEX_HLR_RESRV2,l_lteConfProf);

            l_lteProfDetails = g_spdPtr->m_hssProfile->getLteConfigProfDetailsPtr(atoi(l_lteconfipro.c_str())); 
            if(NULL != l_lteProfDetails)
            {
               if( (1 == l_lteProfDetails->m_LteConfigProfStruct.m_Override5gNsaFeature) && (0 < l_lteProfDetails->m_LteConfigProfStruct.m_AccessRestrictionValue) )
               {
                  LLOG(0,0,"IDR Access Restriction Value from lte Profile [%d]",l_lteProfDetails->m_LteConfigProfStruct.m_AccessRestrictionValue);
                  AccessRestrictionData l_tempard(l_lteProfDetails->m_LteConfigProfStruct.m_AccessRestrictionValue);
                  sub.setAccessRestrictionData(l_tempard);
               }
               else
               {
                  LLOG(0,0,"Either Override5gNsaFeature is not set or AccessRestrictionValue is not set in Lte profile");
               }

               AMBR l_ambr;
               MaxRequestedBandwidthUL l_subsDataMaxReqBwUL(l_lteProfDetails->m_LteConfigProfStruct.m_ambr_ul);
               MaxRequestedBandwidthDL l_subsDataMaxReqBwDL(l_lteProfDetails->m_LteConfigProfStruct.m_ambr_dl);
               LLOG(0,0,"IDA: SubscriptionData: MaxReqBwUL[%u] MaxReqBwDL[%u]", l_lteProfDetails->m_LteConfigProfStruct.m_ambr_ul, l_lteProfDetails->m_LteConfigProfStruct.m_ambr_dl);
               l_ambr.setMaxRequestedBandwidthUL(l_subsDataMaxReqBwUL);
               l_ambr.setMaxRequestedBandwidthDL(l_subsDataMaxReqBwDL);
               //5056
               if((4294967295 == l_lteProfDetails->m_LteConfigProfStruct.m_ambr_ul) && (true == m_5gSupportFlag) && (true == m_hlr_5gSupportFlag))
               {
                  DLOG(0,0,"Both MME and HLR 5gSupportFlag is true, checking for ExtendedAmbrUpLink");
                  LLOG(0,0,"IDA: SubscriptionData: ExtendedAmbrUpLink[%u]",l_lteProfDetails->m_LteConfigProfStruct.m_ext_ambr_ul);
                  if(l_lteProfDetails->m_LteConfigProfStruct.m_ext_ambr_ul > 0)
                  {
                     ExtendedMaxRequestedBWUL l_extendedUL(l_lteProfDetails->m_LteConfigProfStruct.m_ext_ambr_ul);
                     l_ambr.setExtendedMaxRequestedBWUL(l_extendedUL);
                  }
                  else
                  {
                     LLOG(0,0,"ExtendedAmbrUpLink not configured");
                  }
               }
               else
               {
                  LLOG(0,0,"ExtendedAmbrUpLink NOT sending as limit not set to max 4294967295, it is [%u]",l_lteProfDetails->m_LteConfigProfStruct.m_ambr_ul);
               }

               if((4294967295 == l_lteProfDetails->m_LteConfigProfStruct.m_ambr_dl) && (true == m_5gSupportFlag) && (true == m_hlr_5gSupportFlag))
               {
                  DLOG(0,0,"Both MME and HLR 5gSupportFlag is true, checking for ExtendedAmbrDownLink");
                  LLOG(0,0,"IDA: SubscriptionData: ExtendedAmbrDownLink[%u]",l_lteProfDetails->m_LteConfigProfStruct.m_ext_ambr_dl);
                  if(l_lteProfDetails->m_LteConfigProfStruct.m_ext_ambr_dl > 0)
                  {
                     ExtendedMaxRequestedBWDL l_extendedDL(l_lteProfDetails->m_LteConfigProfStruct.m_ext_ambr_dl);
                     l_ambr.setExtendedMaxRequestedBWDL(l_extendedDL);
                  }
                  else
                  {
                     LLOG(0,0,"ExtendedAmbrDownLink not configured");
                  }
               }
               else
               {
                  LLOG(0,0,"ExtendedAmbrDownLink NOT sending as limit not set to 4294967295, it is [%u]",l_lteProfDetails->m_LteConfigProfStruct.m_ambr_dl);
               }
               //5056
               sub.setAMBR(l_ambr);

               int l_5gNsa = 0; //Both MME and HLR does not support NRAsSecondaryRAT
               if( (true == m_hlr_5gSupportFlag) && (true == m_5gSupportFlag) )
               {
                  l_5gNsa = 1; //Both MME and HLR Supports NRAsSecondaryRAT
               }
               else if(true == m_5gSupportFlag)
               {
                  l_5gNsa = 2; //Only MME Supports NRAsSecondaryRAT
               }
               else if(true == m_hlr_5gSupportFlag)
               {
                  l_5gNsa = 3; //Only HLR Supports NRAsSecondaryRAT
               }

               m_tdr.setInteger(TDR_INDEX_AUC_NUM_VECTORS_SENT, l_5gNsa); // 50th index


               LLOG(0,0,"LTE profile details found Profile id [%s]", l_lteconfipro.c_str());
               APNConfigurationProfile  l_tempapnConProfile;
               fillingApnConfigurationProfile(l_lteProfDetails, &l_tempapnConProfile);
               sub.setAPNConfigurationProfile(l_tempapnConProfile);
            }
            else
            {
               LLOG(0,0,"APN profile details not found Profile ID[%s]", l_lteconfipro.c_str());
            }
         }

#if 0
         if(l_apnconfipro.size() > 0)
         {
            APNConfigurationProfile  apnConProfile;
            string l_contextid = ConfigReader::readValue(l_apnconfipro, "CONTEXT_ID");
            LLOG(0,0,"IDR APNConfigurationProfile ContextIdentifier : %s", l_contextid.c_str());
            ContextIdentifier contxId(atoi(l_contextid.c_str()));
            apnConProfile.setContextIdentifier(contxId);

            AllAPNConfigurationsIncludedIndicator  allAPNConfIncluInd(
                  AllAPNConfigurationsIncludedIndicator::MODIFIED_ADDED_APN_CONFIGURATIONS_INCLUDED);
            apnConProfile.setAllAPNConfigurationsIncludedIndicator(allAPNConfIncluInd);

            string l_apnconf = ConfigReader::readValue(l_apnconfipro, "APNCONFI");
            if(l_apnconf.size() > 0)
            {
               APNConfiguration apnConf;

               string l_context = ConfigReader::readValue(l_apnconf, "CONTEXTID");
               LLOG(0,0,"IDR APNConfiguration ContextIdentifier : %s", l_context.c_str());
               ContextIdentifier contextid(atoi(l_context.c_str()));
               apnConf.setContextIdentifier(contextid);
               string ip = ConfigReader::readValue(l_apnconf, "IP");
               if(2 == atoi(ip.c_str()))
               {
                  PDNType pdnType(PDNType::IPv4v6);
                  apnConf.setPDNType(pdnType);
               }
               else if( 1 == atoi(ip.c_str()))
               {
                  PDNType pdnType(PDNType::IPv6);
                  apnConf.setPDNType(pdnType);
               }
               else
               {
                  PDNType pdnType(PDNType::IPv4);
                  apnConf.setPDNType(pdnType);

               }
               LLOG(0,0,"IDR APNConfiguration ContextIdentifier : %s PDNType : %s", l_context.c_str(), ip.c_str());
               string l_serselection = ConfigReader::readValue(l_apnconf, "SERVICE_SELECTION");
               ServiceSelection serSelection(l_serselection.c_str());
               apnConf.setServiceSelection(serSelection);

               string servedparty = ConfigReader::readValue(l_apnconf, "SERVEDPARTY_ADDRESS");
               string ipaddress = ConfigReader::readValue(l_apnconf, "IPADDRESS");
               if(1 == atoi(ip.c_str()))
               {
                  Address l_address(Address::IPV4,ipaddress.c_str());
                  ServedPartyIPAddress servedpartyaddress(l_address);
                  apnConf.addServedPartyIPAddress(servedpartyaddress);
               }
               else if( 2 == atoi(ip.c_str()))
               {
                  Address l_address(Address::IPV6,ipaddress.c_str());
                  ServedPartyIPAddress servedpartyaddress(l_address);
                  apnConf.addServedPartyIPAddress(servedpartyaddress);
               }
               LLOG(0,0,"IDR APNConfiguration ServiceSelection : %s  ServedPartyIPAddress : %s", l_serselection.c_str(), servedparty.c_str());

               string l_epssubscriber = ConfigReader::readValue(l_apnconf, "EPSSUBSCRIBEDQOS");
               if(l_epssubscriber.size() > 0)
               {
                  EPSSubscribedQoSProfile epssubscriber;
                  string l_qosclassid = ConfigReader::readValue(l_epssubscriber, "QOSCLASSID");
                  LLOG(0,0,"IDR APNConfiguration QoSClassIdentifier : %s", l_qosclassid.c_str());
                  if(1 == atoi(l_qosclassid.c_str()))
                  {
                     QoSClassIdentifier qosclassid(QoSClassIdentifier::TRAFFIC_CLASS_A);
                     epssubscriber.setQoSClassIdentifier(qosclassid);
                  }
                  else if(2 == atoi(l_qosclassid.c_str()))
                  {
                     QoSClassIdentifier qosclassid(QoSClassIdentifier::TRAFFIC_CLASS_B);
                     epssubscriber.setQoSClassIdentifier(qosclassid);
                  }
                  else if(3 == atoi(l_qosclassid.c_str()))
                  {
                     QoSClassIdentifier qosclassid(QoSClassIdentifier::TRAFFIC_CLASS_C);
                     epssubscriber.setQoSClassIdentifier(qosclassid);
                  }
                  else if(4 == atoi(l_qosclassid.c_str()))
                  {
                     QoSClassIdentifier qosclassid(QoSClassIdentifier::TRAFFIC_CLASS_D);
                     epssubscriber.setQoSClassIdentifier(qosclassid);
                  }
                  else if(5 == atoi(l_qosclassid.c_str()))
                  {
                     QoSClassIdentifier qosclassid(QoSClassIdentifier::TRAFFIC_CLASS_E);
                     epssubscriber.setQoSClassIdentifier(qosclassid);
                  }
                  else if(6 == atoi(l_qosclassid.c_str()))
                  {
                     QoSClassIdentifier qosclassid(QoSClassIdentifier::TRAFFIC_CLASS_F);
                     epssubscriber.setQoSClassIdentifier(qosclassid);
                  }
                  else if(7 == atoi(l_qosclassid.c_str()))
                  {
                     QoSClassIdentifier qosclassid(QoSClassIdentifier::TRAFFIC_CLASS_G);
                     epssubscriber.setQoSClassIdentifier(qosclassid);
                  }
                  else if(8 == atoi(l_qosclassid.c_str()))
                  {
                     QoSClassIdentifier qosclassid(QoSClassIdentifier::TRAFFIC_CLASS_H);
                     epssubscriber.setQoSClassIdentifier(qosclassid);
                  }
                  else if(9 == atoi(l_qosclassid.c_str()))
                  {
                     QoSClassIdentifier qosclassid(QoSClassIdentifier::TRAFFIC_CLASS_I);
                     epssubscriber.setQoSClassIdentifier(qosclassid);
                  }
                  AllocationRetentionPriority allocationpriority;

                  string l_prioritylevel = ConfigReader::readValue(l_epssubscriber, "PRIORITY_LEVEL");
                  LLOG(0,0,"IDR APNConfiguration PriorityLevel : %s", l_prioritylevel.c_str());
                  PriorityLevel prioritylevel(atoi(l_prioritylevel.c_str()));
                  allocationpriority.setPriorityLevel(prioritylevel);
                  PreemptionCapability preemptionCap(PreemptionCapability::PRE_EMPTION_CAPABILITY_DISABLED);
                  allocationpriority.setPreemptionCapability(preemptionCap);
                  PreemptionVulnerability preemptionVul(PreemptionVulnerability::PRE_EMPTION_VULNERABILITY_ENABLED);
                  allocationpriority.setPreemptionVulnerability(preemptionVul);
                  epssubscriber.setAllocationRetentionPriority(allocationpriority);
                  apnConf.setEPSSubscribedQoSProfile(epssubscriber);
                  VPLMNDynamicAddressAllowed vplmn(VPLMNDynamicAddressAllowed::NOTALLOWED);
                  apnConf.setVPLMNDynamicAddressAllowed(vplmn);

                  MIP6AgentInfo mip6agent;
                  string l_mipagent = ConfigReader::readValue(l_epssubscriber, "MIPHOMEAGENT");
                  LLOG(0,0,"IDR APNConfiguration MIPHomeAgentAddress : %s", l_mipagent.c_str());
                  if(l_mipagent.size() > 0)
                  {
                     if(1 == atoi(ip.c_str()))
                     {
                        Address l_address(Address::IPV4,ipaddress.c_str());
                        MIPHomeAgentAddress miphomeagent(l_address);
                        mip6agent.addMIPHomeAgentAddress(miphomeagent);
                     }
                     else if(2 == atoi(ip.c_str()))
                     {
                        Address l_address(Address::IPV6,ipaddress.c_str());
                        MIPHomeAgentAddress miphomeagent(l_address);
                        mip6agent.addMIPHomeAgentAddress(miphomeagent);
                     }
                  }
                  string l_destinationreal = ConfigReader::readValue(l_epssubscriber, "DESTINATIONREALM");
                  LLOG(0,0,"IDR APNConfiguration DestinationRealm : %s", l_destinationreal.c_str());
                  if(l_destinationreal.size() > 0)
                  {
                     MIPHomeAgentHost miphomehost;
                     diameter::base::DestinationRealm destinationreal(l_destinationreal.c_str());
                     miphomehost.setDestinationRealm(destinationreal);
                     string l_destinationhost = ConfigReader::readValue(l_epssubscriber, "DESTINATIONHOST");
                     LLOG(0,0,"IDR APNConfiguration DestinationHost : %s", l_destinationhost.c_str());
                     diameter::base::DestinationHost destinationhost(l_destinationhost.c_str());
                     miphomehost.setDestinationHost(destinationhost);
                     mip6agent.setMIPHomeAgentHost(miphomehost);
                  }
                  string l_homelinkpre = ConfigReader::readValue(l_epssubscriber, "HOMELINKPRE");
                  LLOG(0,0,"IDR APNConfiguration MIP6HomeLinkPrefix : %s", l_homelinkpre.c_str());
                  MIP6HomeLinkPrefix mip6homelink(l_homelinkpre.c_str());
                  mip6agent.setMIP6HomeLinkPrefix(mip6homelink);

                  apnConf.setMIP6AgentInfo(mip6agent);

                  PDNGWAllocationType pdnallocation(PDNGWAllocationType::STATIC);
                  apnConf.setPDNGWAllocationType(pdnallocation);

                  string l_s6a3gpp = ConfigReader::readValue(l_epssubscriber, "S6A3GPPCHARGING");
                  LLOG(0,0,"IDR APNConfiguration S6a3GPPChargingCharacteristics : %s", l_s6a3gpp.c_str());
                  S6a3GPPChargingCharacteristics s6a3gpp(l_s6a3gpp.c_str());
                  apnConf.setS6a3GPPChargingCharacteristics(s6a3gpp);
                  SpecificAPNInfo specifiapninfo;//TODO

               }
               string l_ambr = ConfigReader::readValue(l_epssubscriber, "AMBR");
               if(l_ambr.size() > 0)
               {
                  AMBR ambr;
                  string l_ambrup = ConfigReader::readValue(l_ambr, "AMBR_UL");
                  MaxRequestedBandwidthUL maxReqBwUL(atoi(l_ambrup.c_str()));
                  ambr.setMaxRequestedBandwidthUL(maxReqBwUL);
                  string l_ambrdp = ConfigReader::readValue(l_ambr, "AMBR_DL");
                  MaxRequestedBandwidthDL maxReqBwDL(atoi(l_ambrdp.c_str()));
                  ambr.setMaxRequestedBandwidthDL(maxReqBwDL);
                  LLOG(0,0,"IDR APNConfiguration AMBR UL : %s AMBR DL : %s", l_ambrup.c_str(), l_ambrdp.c_str());
                  apnConf.setAMBR(ambr);
               }
               apnConProfile.addAPNConfiguration(apnConf);
            }

            sub.setAPNConfigurationProfile(apnConProfile);
         }

#endif
         string l_ratfreselId = ConfigReader::readValue(p_req, "RAT_FREQUENCY_SELECTION_PRIORITY_ID");
         if(l_ratfreselId.size())
         {
            RATFrequencySelectionPriorityID l_tempratfrequency(12);
            sub.setRATFrequencySelectionPriorityID(l_tempratfrequency);
         }

         string l_trace = ConfigReader::readValue(p_req, "TRACE");
         if(l_trace.size() > 0)
         {
            TraceData l_temptrace;
            string l_traceref = ConfigReader::readValue(l_trace, "TRACE_REFERENCE");
            LLOG(0,0,"IDR TraceData TraceReference : %s", l_traceref.c_str());
            TraceReference l_temptraceref(l_traceref.c_str());
            l_temptrace.setTraceReference(l_temptraceref);

            string l_tracedep = ConfigReader::readValue(l_trace, "TRACE_DEPTH");
            LLOG(0,0,"IDR TraceData TraceDepth : %s", l_tracedep.c_str());
            if(0 == atoi(l_tracedep.c_str()))
            {
               TraceDepth l_temptraceDep(TraceDepth::Minimum);
               l_temptrace.setTraceDepth(l_temptraceDep);
            }
            else if( 1 == atoi(l_tracedep.c_str()))
            {
               TraceDepth l_temptraceDep(TraceDepth::Medium);
               l_temptrace.setTraceDepth(l_temptraceDep);
            }
            else if( 2 == atoi(l_tracedep.c_str()))
            {
               TraceDepth l_temptraceDep(TraceDepth::Maximum);
               l_temptrace.setTraceDepth(l_temptraceDep);
            }
            else if( 3 == atoi(l_tracedep.c_str()))
            {
               TraceDepth l_temptraceDep(TraceDepth::MinimumWithoutVendorSpecificExtension);
               l_temptrace.setTraceDepth(l_temptraceDep);
            }
            else if( 4 == atoi(l_tracedep.c_str()))
            {
               TraceDepth l_temptraceDep(TraceDepth::MediumWithoutVendorSpecificExtension);
               l_temptrace.setTraceDepth(l_temptraceDep);
            }
            else if( 5 == atoi(l_tracedep.c_str()))
            {
               TraceDepth l_temptraceDep(TraceDepth::MaximumWithoutVendorSpecificExtension);
               l_temptrace.setTraceDepth(l_temptraceDep);
            }
            string l_tracenetype = ConfigReader::readValue(l_trace, "TRACE_NE_TYPE_LIST");
            LLOG(0,0,"IDR TraceData TraceNETypeList : %s", l_tracenetype.c_str());
            TraceNETypeList l_temptracenetypelist(l_tracenetype.c_str());
            l_temptrace.setTraceNETypeList(l_temptracenetypelist);

            string l_traceevent = ConfigReader::readValue(l_trace, "TRACE_NE_TYPE_LIST");
            LLOG(0,0,"IDR TraceData TraceEventList : %s", l_traceevent.c_str());
            TraceEventList l_temptraceevent(l_traceevent.c_str());
            l_temptrace.setTraceEventList(l_temptraceevent);

            string l_iptype = ConfigReader::readValue(l_trace, "IP_TYPE");
            string l_ipaddress = ConfigReader::readValue(l_trace, "IP_ADDRESS");
            LLOG(0,0,"IDR TraceData IP Type : %s, IP Address : %s", l_iptype.c_str(), l_ipaddress.c_str());
            if(1 == atoi(l_iptype.c_str()))
            {
               Address l_address(Address::IPV4,l_ipaddress.c_str());
               TraceCollectionEntity l_temptraceCollection(l_address);
               l_temptrace.setTraceCollectionEntity(l_temptraceCollection);
            }
            if(2 == atoi(l_iptype.c_str()))
            {
               Address l_address(Address::IPV6,l_ipaddress.c_str());
               TraceCollectionEntity l_temptraceCollection(l_address);
               l_temptrace.setTraceCollectionEntity(l_temptraceCollection);
            }

            string l_traceinterface = ConfigReader::readValue(l_trace, "TRACE_INTERFACE_LIST");
            LLOG(0,0,"IDR TraceData TraceInterfaceList : %s", l_traceinterface.c_str());
            TraceInterfaceList l_temptraceInter(l_traceinterface.c_str());
            l_temptrace.setTraceInterfaceList(l_temptraceInter);

            string l_omcid = ConfigReader::readValue(l_trace, "OMCID");
            LLOG(0,0,"IDR TraceData OMCId : %s", l_omcid.c_str());
            OMCId l_tempomcid(l_omcid.c_str());
            l_temptrace.setOMCId(l_tempomcid);
            sub.setTraceData(l_temptrace);
         }
         string l_gprssub = ConfigReader::readValue(p_req, "GPRS_PROFILE_ID");
         if(l_gprssub.size() > 0)
         {
            int l_profileId = atoi(l_gprssub.c_str());
            LLOG(0,0,"IDR GPRS Profile Id [%d] ", l_profileId);
            GPRSSubscriptionData l_tempgprssubscription;

            fillGPRSSubscriptionData(l_profileId, &l_tempgprssubscription);
            CompleteDataListIncludedIndicator l_CompleteDataListIncludedIndicator(CompleteDataListIncludedIndicator::MODIFIED_ADDED_PDP_CONTEXTS_INCLUDED);
            l_tempgprssubscription.setCompleteDataListIncludedIndicator(l_CompleteDataListIncludedIndicator);
            sub.setGPRSSubscriptionData(l_tempgprssubscription);
         }

         string l_csgsub= ConfigReader::readValue(p_req, "CSG_SUBCRIPTION");
         if(l_csgsub.size() > 0)
         {
            char l_temp[50];
            memset(l_temp, '\0', sizeof(l_temp));
            for(int i = 1; i< 10 ; i++)
            {
               sprintf(l_temp, "CSG_SUBCRIPTION_%02d",i);
               string l_csgsubscription= ConfigReader::readValue(l_csgsub, l_temp);
               if(l_csgsubscription.size() > 0)
               {
                  CSGSubscriptionData l_tempcsgssubscriptio;
                  string l_csgid= ConfigReader::readValue(l_csgsubscription, "CSG_ID");
                  LLOG(0,0,"IDR CSGSubscriptionData CSGId : %s", l_csgid.c_str());
                  CSGId l_tempcsgid(atoi(l_csgid.c_str()));
                  l_tempcsgssubscriptio.setCSGId(l_tempcsgid);
                  string l_expirationdate= ConfigReader::readValue(l_csgsubscription, "CSG_EXPIRATION_DATE");
                  LLOG(0,0,"IDR CSGSubscriptionData ExpirationDate : %s", l_expirationdate.c_str());
                  ExpirationDate l_tempexpirationdate(atoi(l_expirationdate.c_str()));
                  l_tempcsgssubscriptio.setExpirationDate(l_tempexpirationdate);
                  sub.addCSGSubscriptionData(l_tempcsgssubscriptio);

               }
               else
               {
                  break;
               }

            }
         }

         string l_roamingrest= ConfigReader::readValue(p_req, "ROAM_RESTRICTED_DUE_TO_UNSUPPORTED");
         if(l_roamingrest.size() > 0)
         {
            LLOG(0,0,"IDR RoamingRestrictedDueToUnsupportedFeature : %s", l_roamingrest.c_str());
            RoamingRestrictedDueToUnsupportedFeature l_temproaming(RoamingRestrictedDueToUnsupportedFeature::Roaming_Restricted_Due_To_Unsupported_Feature);
            sub.setRoamingRestrictedDueToUnsupportedFeature(l_temproaming);
         }


         l_temp->setSubscriptionData(sub);
      }
      catch (NoSuchAttributeException e)
      {
         ELOG(0,1,"ERROR!! Exception NoSuchAttributeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
         m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EXCEPTION_OCCURRED);
         return false;
      }
      catch (WrongCommandTypeException e)
      {
         ELOG(0,1,"ERROR!! Exception WrongCommandTypeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
         m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EXCEPTION_OCCURRED);
         return false;
      }
      catch (UnknownTypeException e)
      {
         ELOG(0,1,"ERROR!! Exception UnknownTypeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
         m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EXCEPTION_OCCURRED);
         return false;
      }
      catch (CodecException e)
      {
         ELOG(0,1,"ERROR!! Exception CodecException Caught: %s ,Error Cause: %s ",e.name(), e.what());
         m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EXCEPTION_OCCURRED);
         return false;
      }
      catch(...)
      {
         LLOG(0,0,"Filling IDR throwing Exceptions");
         CLOG(0,0,"Exception occurred while calling FillIDR");
         m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EXCEPTION_OCCURRED);
         return false;
      }
      unsigned int sIdx;
      string sessIdString;
      if(false == g_esc.allocateSession(DIAM_APP_ID_S6A_S6D,
               sIdx,
               sessIdString))
      {
         ELOG(0,1,"Unable to allocate a session");
         m_tdr.setString(TDR_ERROR_UNABLE_TO_INITIATE, "Unable to allocate a session");
         return false;
      }
      DiameterMsg l_idr((char *)sessIdString.c_str(),DIAM_EVENT_REQUEST,DIAM_COMM_CODE_S6A_S6D_S7A_S7D_IDR_IDA);

      l_idrData.setSessionId(diameter::base::SessionId(sessIdString));
      l_idrData.setSessionIndex(sIdx);

      ITS_UINT l_idx = l_idrData.getSessionIndex();
      LLOG(0,0,"IDR Session Id : %d", l_idx);

      l_idr.m_cmd = &l_idrData;
      g_esc.sendMsg(this, &l_idr);

      return true;
   }
}
bool CtxtLteInsertSubscriberDataRequest::fillGPRSSubscriptionData(int p_gprsProfileId, GPRSSubscriptionData* p_gprsSubscriptionData)
{
   map<u16,PDP*>::iterator l_pdpItr;
   l_pdpItr = g_spdPtr->m_PDPMap.find(p_gprsProfileId);
   int l_count = 0; 
   if(l_pdpItr != g_spdPtr->m_PDPMap.end())
   {
      PDP* l_pdp = l_pdpItr->second;
      l_count = l_pdp->m_pdpContextCount;
      if(l_count > 0)
      {
         for(int i = 0; i < l_count ; i++)
         {
            ContextList l_context;
            memset(&l_context, '\0', sizeof(l_context));
            memcpy(&l_context, &l_pdp->m_pdpContextListArr[i] , sizeof(ContextList));
            PDPContext l_temppdnContext;
            LLOG(0,0,"IDR GPRSSubscriptionData ContextIdentifier : %d", l_context.m_ContextId);
            ContextIdentifier l_tempcontextId(l_context.m_ContextId);
            l_temppdnContext.setContextIdentifier(l_tempcontextId);
            char l_temp[4] ;
            memset(l_temp, '\0', sizeof(l_temp));
            sprintf(l_temp,"%u%u%u", l_context.m_QosSusbcribed[0], l_context.m_QosSusbcribed[1], l_context.m_QosSusbcribed[2]);
            LLOG(0,0,"IDR GPRSSubscriptionData QoSSubscribed : %s", l_temp);
            QoSSubscribed l_tempqosSubscribed(l_temp);
            memset(l_temp, '\0', sizeof(l_temp));
            sprintf(l_temp, "%u", l_context.m_PDPType[1]);
            LLOG(0,0,"IDR GPRSSubscriptionData PDPType : %s", l_temp);
            PDPType l_temppdntype(l_temp);
            l_temppdnContext.setPDPType(l_temppdntype);
            l_temppdnContext.setQoSSubscribed(l_tempqosSubscribed);
            ServiceSelection l_tempserviceselection("315351");//TODO
            l_temppdnContext.setServiceSelection(l_tempserviceselection);//TODO
            LLOG(0,0,"IDR GPRSSubscriptionData PDPAddress : %s", l_context.m_PDPAddr);
            if(1 == l_context.m_PDPType[1])
            {
               Address l_address(Address::IPV4, l_context.m_PDPAddr);
               PDPAddress l_tempPDPAddress(l_address);
               l_temppdnContext.setPDPAddress(l_tempPDPAddress);
            }
            else if( 2 == l_context.m_PDPType[1])
            {
               Address l_address(Address::IPV6, l_context.m_PDPAddr);
               PDPAddress l_tempPDPAddress(l_address);
               l_temppdnContext.setPDPAddress(l_tempPDPAddress);
            }
            LLOG(0,0,"IDR GPRSSubscriptionData S6a3GPPChargingCharacteristics : %s", l_context.m_pdpChrgChar);
            S6a3GPPChargingCharacteristics l_temp6a3gppcharging((char*)l_context.m_pdpChrgChar);
            l_temppdnContext.setS6a3GPPChargingCharacteristics(l_temp6a3gppcharging);
            p_gprsSubscriptionData->addPDPContext(l_temppdnContext);
         }
      }
   }
   return true;
}
bool CtxtLteInsertSubscriberDataRequest :: fillingApnConfigurationProfile(LteConfigProf* aLteConfigProf,APNConfigurationProfile* aApnConfProf)
{
   if(aLteConfigProf->m_apnProfDetails.m_DefaultCtxdID > 0)
   {
      ContextIdentifier l_defaultCtxtId(aLteConfigProf->m_apnProfDetails.m_DefaultCtxdID);
      aApnConfProf->setContextIdentifier(l_defaultCtxtId);
      LLOG(0,0,"IDR: SubscriptionData: APN: Default CtxtIdentifier[%u]",aLteConfigProf->m_apnProfDetails.m_DefaultCtxdID);
   }
   else
   {
      CLOG(0,0,"IDR: SubscriptionData: APN: Exception: Default CtxtIdentifier Mandatory Param missing or wrong[%u]",aLteConfigProf->m_apnProfDetails.m_DefaultCtxdID);
      return false;
   }

   AllAPNConfigurationsIncludedIndicator l_allApnConfInclInd(AllAPNConfigurationsIncludedIndicator :: All_APN_CONFIGURATIONS_INCLUDED);
   aApnConfProf->setAllAPNConfigurationsIncludedIndicator(l_allApnConfInclInd);
   LLOG(0,0,"IDR: SubscriptionData: APN: All_APN_CONFIGURATIONS_INCLUDED");

   map<u32, CtxtIDdetails>::iterator l_ctxtIdIter;
   LLOG(0,0,"IDR: SubscriptionData: APN: CtxtDetails Map Size[%d]",aLteConfigProf->m_apnProfDetails.m_CtxtIdMap.size());
   int l_count = 1;
   string l_apnTdrData;
   l_apnTdrData += "APN-";
   for(l_ctxtIdIter = aLteConfigProf->m_apnProfDetails.m_CtxtIdMap.begin(); l_ctxtIdIter != aLteConfigProf->m_apnProfDetails.m_CtxtIdMap.end(); l_ctxtIdIter++)
   {
      APNConfiguration l_apnConfiguration;

      if(l_ctxtIdIter->first > 0)
      {
         ContextIdentifier l_ctxtIdentifier(l_ctxtIdIter->first);
         l_apnConfiguration.setContextIdentifier(l_ctxtIdentifier);
         LLOG(0,0,"IDR: SubscriptionData: APN-[%u]: CtxtIdentifier[%d]",l_count,l_ctxtIdIter->first);
      }
      else
      {
         CLOG(0,0,"IDR: SubscriptionData: APN: Exception: CtxtIdentifier Mandatory Param missing or wrong[%d]",l_ctxtIdIter->first);
         return false;
      }

      if(1 == l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_applicability_flag)
      {
         if(0 == m_partner_nkId)
         {
            TLOG(0,0,"Subscriber in Home and Applicability flag of CtxdId[%d] is 1 so ignoring", l_ctxtIdIter->first);
            continue;
         }
         else
         {
            if(l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_applicability_roam_parnter_id != m_partner_nkId)
            {
               LLOG(0,0,"Roam: CtxtId[%d] ApplicableRoamPartner[%d] not matching ActualRoamParnter[%d] so ignoring",l_ctxtIdIter->first, l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_applicability_roam_parnter_id, m_partner_nkId);
               continue;
            }
         }
      }

      // 0-IPv4 1-IPv6 2-IPv4v6 3-IPv4orv6
      if((l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_pdnType >= 0) && (l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_pdnType <= 3))  
      {
         PDNType l_pdnType((PDNType::Value)l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_pdnType);
         l_apnConfiguration.setPDNType(l_pdnType);
         LLOG(0,0,"IDR: SubscriptionData: APN-[%d]: PDNType[%d]",l_count,l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_pdnType);
      }
      else
      {
         CLOG(0,0,"IDR: SubscriptionData: APN: Exception: PDNType Mandatory Param missing or wrong[%d]",l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_pdnType);
         return false;
      }

      //if(strlen(l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_serviceSelection) > 0)
      if(0 != strcmp("0",l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_serviceSelection))
      {

         if(0 == strcasecmp("ims",l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_serviceSelection))
         {
            if(1 != m_ims_service_flag)
            {
               LLOG(0,0,"IDR: IMS service disabled for the subscriber, not sending IMS APN Context.. ignoring");
               continue;
            }
         }
         ServiceSelection l_serviceSelection(l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_serviceSelection);
         l_apnConfiguration.setServiceSelection(l_serviceSelection);
         l_apnTdrData += l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_serviceSelection;
         l_apnTdrData += "|";
         LLOG(0,0,"IDR: SubscriptionData: APN-[%d]: ServiceSelection[%s]",l_count,l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_serviceSelection);
      }
      else
      {
         CLOG(0,0,"IDR: SubscriptionData: APN: Exception: ServiceSelection Mandatory Param missing or wrong[%s]",l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_serviceSelection);
         return false;
      }


      //servedPartyFamily 0 = Reserved
      if( (m_IPv4Addr.length() > 1) && (m_IPv6Addr.length() > 1) )
      {
         TLOG(0,0,"Subscriber specific IPV4 Address [%s] and IPV6 Address [%s] present, Filling IPV4 Address as ServedPartyAddress1 and IPV6 Address as ServedPartyAddress2",(char *)m_IPv4Addr.c_str(), (char *)m_IPv6Addr.c_str());
         Address l_SPaddress1(Address::IPV4, (char *)m_IPv4Addr.c_str());
         ServedPartyIPAddress l_servedPartyAddress1(l_SPaddress1);
         l_apnConfiguration.addServedPartyIPAddress(l_servedPartyAddress1);
         Address l_SPaddress2(Address::IPV6, (char *)m_IPv6Addr.c_str());
         ServedPartyIPAddress l_servedPartyAddress2(l_SPaddress2);
         l_apnConfiguration.addServedPartyIPAddress(l_servedPartyAddress2);
      }
      else if((m_IPv4Addr.length() > 1) || (m_IPv6Addr.length() > 1))
      {
         if(m_IPv4Addr.length() > 1)
         {
            TLOG(0,0,"Subscriber specific IPV4 Address [%s] present, Filling IPV4 Address as ServedPartyAddress",(char *)m_IPv4Addr.c_str());
            Address l_SPaddress1(Address::IPV4, (char *)m_IPv4Addr.c_str());
            ServedPartyIPAddress l_servedPartyAddress1(l_SPaddress1);
            l_apnConfiguration.addServedPartyIPAddress(l_servedPartyAddress1);
         }
         else
         {
            TLOG(0,0,"Subscriber specific IPV6 Address [%s] present, Filling IPV6 Address as ServedPartyAddress",(char *)m_IPv6Addr.c_str());
            Address l_SPaddress1((Address::IPV6),(char *)m_IPv6Addr.c_str());
            ServedPartyIPAddress l_servedPartyAddress1(l_SPaddress1);
            l_apnConfiguration.addServedPartyIPAddress(l_servedPartyAddress1);
         }
      }
      else
      {
         if( (l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_servedPartyFamily1 > 0) && (l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_servedPartyFamily1 <= 24) && (strlen(l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_servedPartyAddress1) > 1) )
         {
            if(1 == l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_servedPartyFamily1)
            {
               Address l_SPaddress1(Address::IPV4, l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_servedPartyAddress1);
               ServedPartyIPAddress l_servedPartyAddress1(l_SPaddress1);
               l_apnConfiguration.addServedPartyIPAddress(l_servedPartyAddress1);
            }
            else if(2 == l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_servedPartyFamily1)
            {
               Address l_SPaddress1((Address::IPV6),l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_servedPartyAddress1);
               ServedPartyIPAddress l_servedPartyAddress1(l_SPaddress1);
               l_apnConfiguration.addServedPartyIPAddress(l_servedPartyAddress1);
            }
            else
            {
               Address l_SPaddress1;
               l_SPaddress1.family = (Address::Family)l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_servedPartyFamily1;
               l_SPaddress1.value = l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_servedPartyAddress1;
               ServedPartyIPAddress l_servedPartyAddress1(l_SPaddress1);
               l_apnConfiguration.addServedPartyIPAddress(l_servedPartyAddress1);
            }
            LLOG(0,0,"IDR: SubscriptionData: APN-[%d]: ServedPartyFamily1[%d] ServedPartyAddress1[%s]",l_count,l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_servedPartyFamily1,l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_servedPartyAddress1);
         }

         if( (l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_servedPartyFamily2 > 0) && (l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_servedPartyFamily2 <= 24) && (strlen(l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_servedPartyAddress2) > 1) )
         {
            if(1 == l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_servedPartyFamily2)
            {
               Address l_SPaddress2(Address::IPV4,l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_servedPartyAddress2);
               ServedPartyIPAddress l_servedPartyAddress2(l_SPaddress2);
               l_apnConfiguration.addServedPartyIPAddress(l_servedPartyAddress2);
            }
            else if(2 == l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_servedPartyFamily2)
            {
               Address l_SPaddress2((Address::IPV6),l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_servedPartyAddress2);
               ServedPartyIPAddress l_servedPartyAddress2(l_SPaddress2);
               l_apnConfiguration.addServedPartyIPAddress(l_servedPartyAddress2);
            }
            else
            {
               Address l_SPaddress2;
               l_SPaddress2.family = (Address::Family)l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_servedPartyFamily2;
               l_SPaddress2.value = l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_servedPartyAddress2;
               ServedPartyIPAddress l_servedPartyAddress2(l_SPaddress2);
               l_apnConfiguration.addServedPartyIPAddress(l_servedPartyAddress2);
            }
            LLOG(0,0,"IDR: SubscriptionData: APN-[%d]: ServedPartyFamily2[%d] ServedPartyAddress2[%s]",l_count,l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_servedPartyFamily2,l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_servedPartyAddress2);
         }
      }
      EPSSubscribedQoSProfile l_epsSubscribedQosProfile;

      // qos_class_identifier - 0 (Reserved)
      bool l_qos_class_indentifier = false;
      if( (l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_esqp_qos_class_identifier > 0) && (l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_esqp_qos_class_identifier <= 255) )
      {
         QoSClassIdentifier l_qosClassIdentifier((QoSClassIdentifier::Value)l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_esqp_qos_class_identifier);
         l_epsSubscribedQosProfile.setQoSClassIdentifier(l_qosClassIdentifier);
         LLOG(0,0,"IDR: SubscriptionData: APN-[%d]: QosClassIdentifier[%d]",l_count,l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_esqp_qos_class_identifier);
         l_qos_class_indentifier = true;
      }

      if( true == l_qos_class_indentifier )
      {
         AllocationRetentionPriority l_allocRetentPriority;
         if( (l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_esqp_app_priority_level >= 1) && (l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_esqp_app_priority_level <= 15) )
         {
            PriorityLevel l_priorityLevel(l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_esqp_app_priority_level);
            l_allocRetentPriority.setPriorityLevel(l_priorityLevel);
            LLOG(0,0,"IDR: SubscriptionData: APN-[%d]: PriorityLevel[%d]",l_count,l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_esqp_app_priority_level);
         }
         else
         {
            CLOG(0,0,"IDR: SubscriptionData: APN: Exception: QosClassIdentifier present and AllocationRetentionPriorityLevel[%d] not present or wrong",l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_esqp_app_priority_level);
            return false;
         }

         if( (l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_esqp_arp_pre_empt_cap == 0) || (l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_esqp_arp_pre_empt_cap == 1) )
         {
            PreemptionCapability l_premptCap((PreemptionCapability::Value)l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_esqp_arp_pre_empt_cap);
            l_allocRetentPriority.setPreemptionCapability(l_premptCap);
            LLOG(0,0,"IDR: SubscriptionData: APN-[%d]: PreEmptCap[%d]",l_count,l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_esqp_arp_pre_empt_cap);
         }

         if( (l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_esqp_arp_pre_vlner == 0) || (l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_esqp_arp_pre_vlner == 1) )
         {
            PreemptionVulnerability l_premptVuln((PreemptionVulnerability::Value)l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_esqp_arp_pre_vlner);
            l_allocRetentPriority.setPreemptionVulnerability(l_premptVuln);
            l_epsSubscribedQosProfile.setAllocationRetentionPriority(l_allocRetentPriority);
            LLOG(0,0,"IDR: SubscriptionData: APN-[%d]: PreEmptVuln[%d]",l_count,l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_esqp_arp_pre_vlner);
         }

         l_apnConfiguration.setEPSSubscribedQoSProfile(l_epsSubscribedQosProfile);
      }

      if( (l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_vplmn_dyn_addr_allowed == 0) || (l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_vplmn_dyn_addr_allowed == 1) )
      {
         VPLMNDynamicAddressAllowed l_vplmnDynamicAddrAllowed((VPLMNDynamicAddressAllowed::Value)l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_vplmn_dyn_addr_allowed);
         l_apnConfiguration.setVPLMNDynamicAddressAllowed(l_vplmnDynamicAddrAllowed);
         LLOG(0,0,"IDR: SubscriptionData: APN-[%d]: VPLMNDynamicAddrAllowed[%d]",l_count,l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_vplmn_dyn_addr_allowed);
      }

      MIP6AgentInfo l_mip6AgentInfo;
      bool l_apnMip6Set = false;
      bool l_imsSarIpFlag = false;
      bool l_imsSarFQDNFlag = false;

      //ha_family 0 = Reserved
      if( (l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_family1 > 0) && (l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_family1 <= 24) && (strlen(l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_addr_1) > 1) )
      {
         if(1 == l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_family1)
         {
            Address l_mipHA1(Address::IPV4,l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_addr_1);
            MIPHomeAgentAddress l_mipHomeAgentAddr1(l_mipHA1);
            l_mip6AgentInfo.addMIPHomeAgentAddress(l_mipHomeAgentAddr1);
            l_apnMip6Set = true;
         }
         else if(2 == l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_family1)
         {
            Address l_mipHA1((Address::IPV6),l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_addr_1);
            MIPHomeAgentAddress l_mipHomeAgentAddr1(l_mipHA1);
            l_mip6AgentInfo.addMIPHomeAgentAddress(l_mipHomeAgentAddr1);
            l_apnMip6Set = true;
         }
         else
         {
            Address l_mipHA1;
            l_mipHA1.family = (Address::Family)l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_family1;
            l_mipHA1.value = l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_addr_1;
            MIPHomeAgentAddress l_mipHomeAgentAddr1(l_mipHA1);
            l_mip6AgentInfo.addMIPHomeAgentAddress(l_mipHomeAgentAddr1);
            l_apnMip6Set = true;
         }
         LLOG(0,0,"IDR: SubscriptionData: APN-[%d]: Mip6Family1[%d] Mip6ai_ha_addr1[%s]",l_count,l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_family1,l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_addr_1);
      }

      if( (l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_family2 > 0) && (l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_family2 <= 24) && (strlen(l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_addr_2) > 1) )
      {
         if(1 == l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_family2)
         {
            Address l_mipHA2(Address::IPV4,l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_addr_2);
            MIPHomeAgentAddress l_mipHomeAgentAddr2(l_mipHA2);
            l_mip6AgentInfo.addMIPHomeAgentAddress(l_mipHomeAgentAddr2);
            l_apnMip6Set = true;
         }
         else if(2 == l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_family2)
         {
            Address l_mipHA2((Address::IPV6),l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_addr_2);
            MIPHomeAgentAddress l_mipHomeAgentAddr2(l_mipHA2);
            l_mip6AgentInfo.addMIPHomeAgentAddress(l_mipHomeAgentAddr2);
            l_apnMip6Set = true;
         }
         else
         {
            Address l_mipHA2;
            l_mipHA2.family = (Address::Family)l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_family2;
            l_mipHA2.value = l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_addr_2;
            MIPHomeAgentAddress l_mipHomeAgentAddr2(l_mipHA2);
            l_mip6AgentInfo.addMIPHomeAgentAddress(l_mipHomeAgentAddr2);
            l_apnMip6Set = true;
         }
         LLOG(0,0,"IDR: SubscriptionData: APN-[%d]: Mip6Family2[%d] Mip6ai_ha_addr2[%s]",l_count,l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_family2,l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_addr_2);
      }
      //6.4.0.0 Start
      if(1 == g_spdPtr->m_MsisdnPrefReplaceStruct.m_HandOverWifiToVolte)
      {
         DLOG(0,0,"HandOver Wifi to Volte Flag is enabled in system setting ... So taking MIPVHomeAgent from SAR");
         if((0 != strlen(m_SarIpv4Address)) && (0 == strncmp("ims",l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_serviceSelection,strlen(l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_serviceSelection))))
         {
            LLOG(0,0,"SAR Ipv4Address [%s]",m_SarIpv4Address);
            Address l_mipHA2 (Address::IPV4,m_SarIpv4Address);
            MIPHomeAgentAddress l_mipHomeAgentAddr2(l_mipHA2);
            l_mip6AgentInfo.addMIPHomeAgentAddress(l_mipHomeAgentAddr2);
            l_apnMip6Set = true;
            l_imsSarIpFlag = true;
         }

         if(((0 != strlen(m_SarPgwHost)) && (0 != strlen(m_SarPgwRealm))) && (0 == strncmp("ims",l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_serviceSelection,strlen(l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_serviceSelection)))) 
         {
            MIPHomeAgentHost l_mipHomeAgentHost;
            l_mipHomeAgentHost.setDestinationRealm(base::DestinationRealm(m_SarPgwRealm));
            l_mipHomeAgentHost.setDestinationHost(base::DestinationHost(m_SarPgwHost));
            l_mip6AgentInfo.setMIPHomeAgentHost(l_mipHomeAgentHost);
            // l_mip6AgentInfo.setMIP6HomeLinkPrefix(); not used in S6a/S6d
            l_apnMip6Set = true;
            l_imsSarFQDNFlag = true;
            LLOG(0,0,"ULA: SubscriptionData: APN-[%d]: Mip6PGWDestRealm[%s] Mip6PGWDestHost[%s]",l_count,m_SarPgwRealm,m_SarPgwHost);
         }
      }
      //6.4.0.0 End

      if( (strlen(l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_dest_host) > 1) && (strlen(l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_dest_realm) > 1) )
      {
         MIPHomeAgentHost l_mipHomeAgentHost;
         l_mipHomeAgentHost.setDestinationRealm(base::DestinationRealm(l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_dest_realm));
         l_mipHomeAgentHost.setDestinationHost(base::DestinationHost(l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_dest_host));
         l_mip6AgentInfo.setMIPHomeAgentHost(l_mipHomeAgentHost);
         // l_mip6AgentInfo.setMIP6HomeLinkPrefix(); not used in S6a/S6d
         l_apnMip6Set = true;
         LLOG(0,0,"IDR: SubscriptionData: APN-[%d]: Mip6DestRealm[%s] Mip6DestHost[%s]",l_count,l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_dest_realm,l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_dest_host);
      }

      if(true == l_apnMip6Set)
      {
         l_apnConfiguration.setMIP6AgentInfo(l_mip6AgentInfo);
      }

      if( (strlen(l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_visited_net_ident) > 1) )
      {
         VisitedNetworkIdentifier l_visitedNkId(l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_visited_net_ident);
         l_apnConfiguration.setVisitedNetworkIdentifier(l_visitedNkId);
         LLOG(0,0,"IDR: SubscriptionData: APN-[%d]: VisitedNetworkId[%s]",l_count,l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_visited_net_ident);
      }

      if( (strlen(l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_ctxt_apn_oi_replacement) > 1) )
      {
         APNOIReplacement l_apnOIReplacement(l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_ctxt_apn_oi_replacement); 
         l_apnConfiguration.setAPNOIReplacement(l_apnOIReplacement);
         LLOG(0,0,"IDR: SubscriptionData: APN-[%d]: APNOIReplacement[%s]",l_count,l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_ctxt_apn_oi_replacement);
      }

      if( (0 == l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_sipto_permission) || (1 == l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_sipto_permission) )
      {
         SIPTOPermission l_siptoPermission((SIPTOPermission::Value)l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_sipto_permission);
         l_apnConfiguration.setSIPTOPermission(l_siptoPermission);
         LLOG(0,0,"IDR: SubscriptionData: APN-[%d]: SIPTOPermission[%d]",l_count,l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_sipto_permission);
      }

      if( (0 == l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_lipa_permission) || (1 == l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_lipa_permission) || (2 == l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_lipa_permission))
      {
         LIPAPermission l_lipaPermission((LIPAPermission::Value)l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_lipa_permission);
         l_apnConfiguration.setLIPAPermission(l_lipaPermission);
         LLOG(0,0,"IDR: SubscriptionData: APN-[%d]: LIPAPermission[%d]",l_count,l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_lipa_permission);
      }

      if( (strlen(l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_dest_realm) > 1) || (strlen(l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_mip6ai_ha_dest_host) > 1) )     
      {
         if( (0 == l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_pdn_gw_allocation_type) || (1 == l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_pdn_gw_allocation_type) )
         {
            PDNGWAllocationType l_pdnGwAllocType((PDNGWAllocationType::Value)l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_pdn_gw_allocation_type);
            l_apnConfiguration.setPDNGWAllocationType(l_pdnGwAllocType);
            LLOG(0,0,"IDR: SubscriptionData: APN-[%d]: PDNGWAllocationType[%d]",l_count,l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_pdn_gw_allocation_type);
         }
      }

      if ((l_imsSarIpFlag == true) || (true == l_imsSarFQDNFlag))
      {
         PDNGWAllocationType l_pdnGwAllocType((PDNGWAllocationType::Value)1);
         l_apnConfiguration.setPDNGWAllocationType(l_pdnGwAllocType);
         LLOG(0,0,"ULR: SAR IP is set so PDNGWAllocationType  marked as STATIC");
      }

      if(HSS_3GPPCHARGINGCHAR_LEN == l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_3gpp_charg_char_len)
      {
         string l_3gppChrgChar;
         char l_3gppChrgChrString[5];
         snprintf(l_3gppChrgChrString,sizeof(l_3gppChrgChrString),"%02x%02x",(s8*)l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_3gpp_charg_char[0],(s8*)l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_3gpp_charg_char[1]);
         l_3gppChrgChar.assign(l_3gppChrgChrString,HSS_3GPPCHARGINGCHAR_LEN+2);
         S6a3GPPChargingCharacteristics l_s6a3gppChrgChar(l_3gppChrgChar);
         l_apnConfiguration.setS6a3GPPChargingCharacteristics(l_s6a3gppChrgChar);
         LLOG_HEX(0,0,"IDR: SubscriptionData: APN: 3gppChrgChar",l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_3gpp_charg_char,HSS_3GPPCHARGINGCHAR_LEN);
      }

      AMBR l_ambr;
      MaxRequestedBandwidthUL l_maxReqBwUL(l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_ambr_max_req_bandwidth_ul);
      MaxRequestedBandwidthDL l_maxReqBwDL(l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_ambr_max_req_bandwidth_dl);
      l_ambr.setMaxRequestedBandwidthUL(l_maxReqBwUL);
      l_ambr.setMaxRequestedBandwidthDL(l_maxReqBwDL);
      //5056
      if((4294967295 == l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_ambr_max_req_bandwidth_ul) && (true == m_5gSupportFlag) && (true == m_hlr_5gSupportFlag))
      {
         DLOG(0,0,"Both MME and HLR 5gSupportFlag is true, checking for ExtendedAmbrMaxReqUpLink");
         LLOG(0,0,"IDR: SubscriptionData: APN: ExtendedAmbrMaxReqUpLink[%u]", l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_ext_ambr_max_req_bandwidth_ul);
         if(l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_ext_ambr_max_req_bandwidth_ul > 0)
         {
            ExtendedMaxRequestedBWUL l_extendedUL(l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_ext_ambr_max_req_bandwidth_ul);
            l_ambr.setExtendedMaxRequestedBWUL(l_extendedUL);
         }
         else
         {
            TLOG(0,0,"ExtendedAmbrMaxReqUpLink Not configured");
         }
      }
      else
      {
         LLOG(0,0,"ExtendedAmbrMaxReqUpLink NOT sending as limit not set to 4294967295, it is [%u]",l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_ambr_max_req_bandwidth_ul);
      }

      if((4294967295 == l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_ambr_max_req_bandwidth_dl) && (true == m_5gSupportFlag) && (true == m_hlr_5gSupportFlag))
      {
         DLOG(0,0,"Both MME and HLR 5gSupportFlag is true, checking for ExtendedAmbrMaxReqDownLink");
         LLOG(0,0,"IDR: SubscriptionData: APN: ExtendedAmbrMaxReqDownLink[%u]", l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_ext_ambr_max_req_bandwidth_dl);
         if(l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_ext_ambr_max_req_bandwidth_dl > 0)
         {
            ExtendedMaxRequestedBWDL l_extendedDL(l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_ext_ambr_max_req_bandwidth_dl);
            l_ambr.setExtendedMaxRequestedBWDL(l_extendedDL);
         }
         else
         {
            TLOG(0,0,"ExtendedAmbrMaxReqDownLink Not configured");
         }
      }
      else
      {
         LLOG(0,0,"ExtendedAmbrMaxReqDownLink NOT sending as limit not set to 4294967295, it is [%u]",l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_ambr_max_req_bandwidth_dl);
      }
      //5056
      l_apnConfiguration.setAMBR(l_ambr);
      LLOG(0,0,"IDR: SubscriptionData: APN: MaxReqBwUL[%u] MaxReqBwDL[%u]",l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_ambr_max_req_bandwidth_ul, l_ctxtIdIter->second.m_ctxtIDdetailsStruct.m_ambr_max_req_bandwidth_dl);

      int l_SpecCount = 1;
      list<SpecificApnInfo>::iterator l_specificApnIter;
      for(l_specificApnIter = l_ctxtIdIter->second.m_SepcificApnsList.begin(); l_specificApnIter != l_ctxtIdIter->second.m_SepcificApnsList.end(); l_specificApnIter++)
      {
         SpecificAPNInfo l_specificApnInfo;
         bool l_specInfo = false;

         if(0 != strcmp("0",l_specificApnIter->m_serviceSelection))
         {
            if(0 == strcasecmp("ims",l_specificApnIter->m_serviceSelection))
            {
               if(1 != m_ims_service_flag)
               {
                  LLOG(0,0,"IDR: IMS service disabled for the subscriber, not sending IMS APN Specific Context.. ignoring");
                  continue;
               }
            }
            ServiceSelection l_specServiceSelection(l_specificApnIter->m_serviceSelection);
            l_specificApnInfo.setServiceSelection(l_specServiceSelection);
            LLOG(0,0,"IDR: SubscriptionData: SpecificAPN-[%d]: ServiceSelection[%s]",l_SpecCount,l_specificApnIter->m_serviceSelection);
            l_specInfo = true;
         }

         MIP6AgentInfo l_specMip6AgentInfo;
         bool l_specMip6info = false;

         if( (strlen(l_specificApnIter->m_visited_net_ident) > 1 ) )
         {
            VisitedNetworkIdentifier l_specVisitedNkId(l_specificApnIter->m_visited_net_ident);
            l_specificApnInfo.setVisitedNetworkIdentifier(l_specVisitedNkId);
            LLOG(0,0,"IDR: SubscriptionData: SpecificAPN-[%d]: VisitedNetworkId[%s]",l_SpecCount,l_specificApnIter->m_visited_net_ident);
            l_specInfo = true;
         }

         if( (l_specificApnIter->m_mip6ai_ha_family1 > 0) && (l_specificApnIter->m_mip6ai_ha_family1 <= 24) && (strlen(l_specificApnIter->m_mip6ai_ha_addr_1) > 1) )
         {
            if(1 == l_specificApnIter->m_mip6ai_ha_family1)
            {
               Address l_specMipHA1(Address::IPV4,l_specificApnIter->m_mip6ai_ha_addr_1);
               MIPHomeAgentAddress l_specMipHomeAgentAddr1(l_specMipHA1);
               l_specMip6AgentInfo.addMIPHomeAgentAddress(l_specMipHomeAgentAddr1);
            }
            else if(2 == l_specificApnIter->m_mip6ai_ha_family1)
            {
               Address l_specMipHA1((Address::IPV6),l_specificApnIter->m_mip6ai_ha_addr_1);
               MIPHomeAgentAddress l_specMipHomeAgentAddr1(l_specMipHA1);
               l_specMip6AgentInfo.addMIPHomeAgentAddress(l_specMipHomeAgentAddr1);
            }
            else
            {
               Address l_specMipHA1;
               l_specMipHA1.family = (Address::Family)l_specificApnIter->m_mip6ai_ha_family1;
               l_specMipHA1.value = l_specificApnIter->m_mip6ai_ha_addr_1;
               MIPHomeAgentAddress l_specMipHomeAgentAddr1(l_specMipHA1);
               l_specMip6AgentInfo.addMIPHomeAgentAddress(l_specMipHomeAgentAddr1);
            }
            LLOG(0,0,"IDR: SubscriptionData: SpecificAPN-[%d]: ServiceSelection[%s] Mip6Family1[%d] Mip6ai_ha_addr1[%s]",l_SpecCount,l_specificApnIter->m_serviceSelection, l_specificApnIter->m_mip6ai_ha_family1,l_specificApnIter->m_mip6ai_ha_addr_1);
            l_specMip6info = true;
         }

         if( (l_specificApnIter->m_mip6ai_ha_family2 > 0) && (l_specificApnIter->m_mip6ai_ha_family2 <= 24) && (strlen(l_specificApnIter->m_mip6ai_ha_addr_2) > 1) )
         {
            if(1 == l_specificApnIter->m_mip6ai_ha_family2)
            {
               Address l_specMipHA2(Address::IPV4,l_specificApnIter->m_mip6ai_ha_addr_2);
               MIPHomeAgentAddress l_specMipHomeAgentAddr2(l_specMipHA2);
               l_specMip6AgentInfo.addMIPHomeAgentAddress(l_specMipHomeAgentAddr2);
            }
            else if(2 == l_specificApnIter->m_mip6ai_ha_family2)
            {
               Address l_specMipHA2(Address::IPV6,l_specificApnIter->m_mip6ai_ha_addr_2);
               MIPHomeAgentAddress l_specMipHomeAgentAddr2(l_specMipHA2);
               l_specMip6AgentInfo.addMIPHomeAgentAddress(l_specMipHomeAgentAddr2);
            }
            else
            {
               Address l_specMipHA2;
               l_specMipHA2.family = (Address::Family)l_specificApnIter->m_mip6ai_ha_family2;
               l_specMipHA2.value = l_specificApnIter->m_mip6ai_ha_addr_2;
               MIPHomeAgentAddress l_specMipHomeAgentAddr2(l_specMipHA2);
               l_specMip6AgentInfo.addMIPHomeAgentAddress(l_specMipHomeAgentAddr2);
            }
            LLOG(0,0,"IDR: SubscriptionData: SpecificAPN-[%d]: Mip6Family2[%d] Mip6ai_ha_addr2[%s]",l_SpecCount,l_specificApnIter->m_mip6ai_ha_family2,l_specificApnIter->m_mip6ai_ha_addr_2);
            l_specMip6info = true;
         }

         if( (strlen(l_specificApnIter->m_mip6ai_ha_dest_realm) > 1) && (strlen(l_specificApnIter->m_mip6ai_ha_dest_host) > 1) )
         {
            MIPHomeAgentHost l_specMipHomeAgentHost;

            l_specMipHomeAgentHost.setDestinationRealm(base::DestinationRealm(l_specificApnIter->m_mip6ai_ha_dest_realm));
            l_specMipHomeAgentHost.setDestinationHost(base::DestinationHost(l_specificApnIter->m_mip6ai_ha_dest_host));
            l_specMip6AgentInfo.setMIPHomeAgentHost(l_specMipHomeAgentHost);
            LLOG(0,0,"IDR: SubscriptionData: SpecificAPN-[%d]: DestRealm[%s] DestHost[%s]",l_SpecCount,l_specificApnIter->m_mip6ai_ha_dest_realm,l_specificApnIter->m_mip6ai_ha_dest_host);
            l_specMip6info = true;
         }
         // l_mip6AgentInfo.setMIP6HomeLinkPrefix(); not used in S6a/S6d
         if(true == l_specMip6info)
         {
            l_specificApnInfo.setMIP6AgentInfo(l_specMip6AgentInfo);
         }

         if(true == l_specInfo)
         {
            l_apnConfiguration.addSpecificAPNInfo(l_specificApnInfo);
         }
         ++l_SpecCount;
      }

      aApnConfProf->addAPNConfiguration(l_apnConfiguration);
      ++l_count;
   }
   m_tdr.setString(TDR_INDEX_NOR_SERVICE_SELECTION,(char*)l_apnTdrData.c_str());
   return true;
}
bool CtxtLteInsertSubscriberDataRequest::startProcessing(InterModuleData *p_imd, bool& p_DeleteFlag)
{
   p_DeleteFlag=false;
   string l_xml;

   ProvisioningReqMsg *l_prm = (ProvisioningReqMsg*)(p_imd->m_msgPtr);
   m_imd = p_imd;

   //DLOG(0,0,"startProcessing: l_prm->m_sockFd: [%d]",l_prm->m_sockFd);

   if(p_imd->m_msgPtr != NULL)
   {
      DLOG(0,0,"Inside p_imd->m_msgPtr not null case");
      ProvisioningReqMsg *l_provReqMsg = (ProvisioningReqMsg*)p_imd->m_msgPtr;
      m_tdr.setOriginatingModule((char*)l_provReqMsg->m_OrigEntityName.c_str());
      l_xml = l_provReqMsg->m_data;
      string l_reqtype = ConfigReader::readValue(l_xml, "REQUEST_TYPE");
      DLOG(0,0,"*** l_reqtype: %s ***",l_reqtype.c_str());
      if((0 == strcmp(l_reqtype.c_str(),"GET_SUBSCRIBER_INFO")) || (0 == strcmp(l_reqtype.c_str(),"GET_SUBSCRIBER_DATA")))
      {
         DLOG(0,0,"inside GET_SUBSCRIBER_INFO || GET_SUBSCRIBER_DATA xml");
         //getSubscriberLocInfo((char*)l_xml.c_str(),l_respString);
         DLOG(0,0,"Setting m_getsubsflag as true");
         m_getsubsflag = true;
         DLOG(0,0,"*** l_xml :%s ****",l_xml.c_str());
         preInsertSubscriberData((char*)l_xml.c_str());
      }
      return true;
   }

   if(NULL == p_imd->m_Parameters)
   {
      CLOG(0,0,"p_imd->m_Parameters NULL returning");
      return false;
   }

   char *l_check = NULL;
   l_check = strchr(p_imd->m_Parameters, ':');
   if(l_check != NULL)
   {
      //l_xml = &p_imd->m_Parameters[0];
      l_xml = p_imd->m_Parameters;
      LLOG(1,1,"XML [%s]", (char*)l_xml.c_str());
      try
      {
         preInsertSubscriberData((char*)l_xml.c_str());
      }
      catch (NoSuchAttributeException e)
      {
         ELOG(0,1,"ERROR!! Exception NoSuchAttributeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
         m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EXCEPTION_OCCURRED);
      }
      catch (WrongCommandTypeException e)
      {
         ELOG(0,1,"ERROR!! Exception WrongCommandTypeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
         m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EXCEPTION_OCCURRED);
         return false;
      }
      catch (UnknownTypeException e)
      {
         ELOG(0,1,"ERROR!! Exception UnknownTypeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
         m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EXCEPTION_OCCURRED);
         return false;
      }
      catch (CodecException e)
      {
         ELOG(0,1,"ERROR!! Exception CodecException Caught: %s ,Error Cause: %s ",e.name(), e.what());
         m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EXCEPTION_OCCURRED);
         return false;
      }
      catch(...)
      {
         ELOG(0,1,"ERROR!! Very Unknown Exception");
         m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EXCEPTION_OCCURRED);
         return false;
      }

   }
   else
   {
      ELOG(0,0,"Couldn't find : in m_Parameters");
   }
   /*
      else if(p_imd->m_msgPtr != NULL)
      {
      ProvisioningReqMsg *l_provReqMsg = (ProvisioningReqMsg*)p_imd->m_msgPtr;
      m_tdr.setOriginatingModule((char*)l_provReqMsg->m_OrigEntityName.c_str());
      m_tdr.setString(TDR_INDEX_OAM_REQUEST_TYPE,"INSERT_SUBSCRIBER_DATA");
      l_xml = l_provReqMsg->m_data;

      }
      */
   return true;
}
bool CtxtLteInsertSubscriberDataRequest::requireSendCancelLoc(InsertSubscriberDataAnswer *p_answer)
{
   LLOG(0,0,"Checking for Cancel Location require to send");
   int l_countSupportedFeatures = 0;

   l_countSupportedFeatures = p_answer->countSupportedFeatures();
   if( 0 == l_countSupportedFeatures)
   {
      LLOG(0,0,"requireSendCancelLoc MME not supporting feature list of Operator Determined Barring");
      return true;
   }

   for(int l_count = 0 ; l_count < l_countSupportedFeatures; l_count++)
   {
      SupportedFeatures l_suppFeatures = p_answer->getSupportedFeatures(l_count);
      unsigned int l_respfeatureId = (l_suppFeatures.getFeatureListID()).value();
      unsigned int l_respfeatureList = (l_suppFeatures.getFeatureList()).value();
      unsigned int  l_venderId = (l_suppFeatures.getVendorId()).value();
      LLOG(0,0,"Feature Id[%u] Feature List [%u] Vender Id [%u]", l_respfeatureId, l_respfeatureList, l_venderId);
      if(VENDOR_FEATURE_ID != l_venderId)
      {
         WLOG(0,0,"MM is Sending MME fetaure list on Vender Id [%u]",l_venderId);
         continue;
      }
      if( 1 == l_respfeatureId)
      {
         if(m_modifyOdb & F1_ODB_ALL_APN)
         {
            if(!(l_respfeatureList & F1_ODB_ALL_APN))
            {
               LLOG(0,0,"requireSendCancelLoc MME not supporting feature of list F1_ODB_ALL_APN");
               return true;
            }
         }
         if( m_modifyOdb & F1_ODB_HPLMN_APN)
         {
            if(!(l_respfeatureList & F1_ODB_HPLMN_APN))
            {
               LLOG(0,0,"requireSendCancelLoc MME not supporting feature list of F1_ODB_HPLMN_APN");
               return true;
            }
         }
         if( m_modifyOdb & F1_ODB_VPLMN_APN)
         {
            if(!(l_respfeatureList & F1_ODB_VPLMN_APN))
            {
               LLOG(0,0,"requireSendCancelLoc MME not supporting feature list of F1_ODB_VPLMN_APN");
               return true;
            }
         }
         else if( m_modifyOdb & F1_ODB_ALL_OG)
         {
            if(!(l_respfeatureList & F1_ODB_ALL_OG))
            {
               LLOG(0,0,"requireSendCancelLoc MME not supporting feature list of F1_ODB_ALL_OG");
               return true;
            }
         }
         if( m_modifyOdb & F1_ODB_ALL_InternationalOG)
         {
            if(!(l_respfeatureList & F1_ODB_ALL_InternationalOG))
            {
               LLOG(0,0,"requireSendCancelLoc MME not supporting feature list of F1_ODB_ALL_InternationalOG");
               return true;
            }
         }
         if( m_modifyOdb & F1_ODB_ALL_InternationalOG_NotToHPLMNCountry)
         {
            if(!(l_respfeatureList & F1_ODB_ALL_InternationalOG_NotToHPLMNCountry))
            {
               LLOG(0,0,"requireSendCancelLoc MME not supporting feature list of F1_ODB_ALL_InternationalOG_NotToHPLMNCountry");
               return true;
            }
         }
         if( m_modifyOdb & F1_ODB_ALL_InterzonalOG)
         {
            if(!(l_respfeatureList & F1_ODB_ALL_InterzonalOG))
            {
               LLOG(0,0,"requireSendCancelLoc MME not supporting feature list of F1_ODB_ALL_InterzonalOG");
               return true;
            }
         }
         if( m_modifyOdb & F1_ODB_ALL_InterzonalOG_NotToHPLMNCountry)
         {
            if(!(l_respfeatureList & F1_ODB_ALL_InterzonalOG_NotToHPLMNCountry))
            {
               LLOG(0,0,"requireSendCancelLoc MME not supporting feature list of F1_ODB_ALL_InterzonalOG_NotToHPLMNCountry");
               return true;
            }
         }
         if( m_modifyOdb & F1_ODB_ALL_InterzonalOG_And_InternationalOG_NotToHPLMNCountry)
         {
            if(!(l_respfeatureList & F1_ODB_ALL_InterzonalOG_And_InternationalOG_NotToHPLMNCountry))
            {
               LLOG(0,0,"requireSendCancelLoc MME not supporting feature list of F1_ODB_ALL_InterzonalOG_And_InternationalOG_NotToHPLMNCountry");
               return true;
            }
         }
      }
      if(10415 != l_venderId)
         true;
   }
   return false;
}

void HexToString(unsigned char *str,unsigned char *bcd, int i,bool oddEven)
{
   int count, j;
   for(count=0,j=0;count<i;count++,j=j+2)
   {
      str[j+1] = ((bcd[count])&(0x0F));
      str[j] = ((bcd[count]&0xF0)>>4);

      ((0x0A <= str[j]) && (0x0F >= str[j]))?str[j] += 55:str[j] += 48;
      ((0x0A <= str[j+1]) && (0x0F >= str[j+1]))?str[j+1] += 55:str[j+1] += 48;

      if(((count == (i-1)) && (bcd[count]&0xF0) == 0xF0))
         str[j+1] = '\0';
      else if(count == (i-1))
         str[j+2] = '\0';
   }
   i *= 2;
   if(oddEven)
      i--;
   str[i] = '\0';
}

bool CtxtLteInsertSubscriberDataRequest::processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag)
{
   DLOG(0,0,"Start of CtxtLteInsertSubscriberDataRequest::processMsg function");

   p_DeleteFlag=p_DeleteFlag; // This is just to keep the compiler happy

   MapSpecificMsg *l_specMsg = NULL;

   switch (p_MsgPtr->m_MsgType)
   {
      case MSG_TYPE_MAP:
         {
            WLOG(0,0,"MAP message received");
         }
         break;

      case MSG_TYPE_DIAMETER:
         {
            LLOG(0,0,"DIAMETER message received");
            DiameterMsg *l_dm = (DiameterMsg*)p_MsgPtr;
            switch(l_dm->m_det)
            {
#if 1
               case DIAM_EVENT_ANSWER:
#else
               case DIAM_EVENT_ERROR: //to remove
               case DIAM_EVENT_ANSWER:
#endif
                  {
                     LLOG(0,0,"DIAM_EVENT_ANSWER received");

                     //if(NULL != l_dm->m_cmd) //to uncomment
                     {
#if 1
                        diameter::s6a_r10::InsertSubscriberDataAnswer l_ida(*(diameter::CommandImpl*)l_dm->m_cmd); //to uncomment
#else
                        diameter::s6a_r10::InsertSubscriberDataAnswer l_ida;
                        OriginHost l_temporiginHost = diameter::base::OriginHost("MMEHost");
                        l_ida.setOriginHost(l_temporiginHost);
                        OriginRealm l_temporiginRealm("MMERealm");
                        l_ida.setOriginRealm(l_temporiginRealm);
                        //DestinationHost l_tempdestinationHost("MMEDestO");
                        //l_ida.setDestinationHost(l_tempdestinationHost);
                        //DestinationRealm l_tempdestinationRealm("MMEDestR");
                        //l_ida.setDestinationRealm(l_tempdestinationRealm);
                        l_ida.setSessionId(diameter::base::SessionId("abcd"));
                        l_ida.setSessionIndex(123);
                        AuthSessionState l_tempauthSessionState(AuthSessionState::NO_STATE_MAINTAINED);
                        l_ida.setAuthSessionState(l_tempauthSessionState);
                        ResultCode l_tempresult(2000);
                        l_ida.setResultCode(l_tempresult);
                        string cgi;
                        unsigned char cgi_u [] = {0x52,0xf5,0x60,0x0c,0x5d,0xd5,0x17};
                        cgi.assign(cgi_u);
                        EUTRANCellGlobalIdentity l_cgi(cgi); 
                        unsigned int age = 2;
                        AgeOfLocationInformation l_age(age);
                        MMELocationInformation l_mli;
                        l_mli.setEUTRANCellGlobalIdentity(l_cgi);
                        l_mli.setAgeOfLocationInformation(l_age);
                        EPSLocationInformation l_eli;
                        l_eli.setMMELocationInformation(l_mli);
                        l_ida.setEPSLocationInformation(l_eli);

#endif                   

                        //diameter::s6a_r10::InsertSubscriberDataAnswer *l_ida = (diameter::s6a_r10::InsertSubscriberDataAnswer*)l_dm->m_cmd;
                        //cout<<*l_air;
                        diameter::base::SessionId sess= l_ida.getSessionId();
                        ITS_UINT l_idx = l_ida.getSessionIndex();
                        LLOG(0,0,"IDA Session Id : %d", l_idx);

                        int l_errCode = -1;

                        const SessionId &sid1 = l_ida.getSessionId();
                        const OriginHost &oh1 = l_ida.getOriginHost();

                        const OriginRealm &or1 = l_ida.getOriginRealm();
                        const AuthSessionState &authSessState = l_ida.getAuthSessionState();
                        if(true == l_ida.containsResultCode())
                        {
                           const ResultCode &l_rel = l_ida.getResultCode();
                           l_errCode = l_rel.value();
                           if(l_rel.value() > 0)
                           {
                              m_tdr.setInteger(TDR_INDEX_ERR_CODE, l_rel.value());
                              LLOG(0,0,"IDA Result Code : %u", l_rel.value());
                           }
                        }
                        if( true == l_ida.containsExperimentalResult())
                        {
                           const ExperimentalResult &l_experimentalrel = l_ida.getExperimentalResult();
                           const ExperimentalResultCode &l_experimentalrelcode = l_experimentalrel.getExperimentalResultCode();
                           l_errCode = l_experimentalrelcode.value();
                           if(l_experimentalrelcode.value() > 0)
                           {
                              m_tdr.setInteger(TDR_INDEX_ERR_CODE, l_experimentalrelcode.value());
                              LLOG(0,0,"IDA Result Code : %u", l_experimentalrelcode.value());
                           }
                        }
                        if((l_errCode == DIAM_RESULT_CODE_SUCCESS) || 
                              ( l_errCode == DIAM_RESULT_CODE_LIMITED_SUCCESS) || 
                              (( l_errCode >= DIAM_RESULT_CODE_SUCCESS_MIN_RANGE) || ( l_errCode <= DIAM_RESULT_CODE_SUCCESS_MAX_RANGE)))
                        {
                           LLOG(0,0,"IDA Recv Success with Result Code : %u", l_errCode);
                           if(true == m_odbDataSend) 
                           {
                              if( true == requireSendCancelLoc(&l_ida) )
                              {
                                 string l_calLoc = sendCancelLocation();
                                 LLOG(0,0,"IDA Recv MME does not ODB feature list sending Cancel Location [%s]", l_calLoc.c_str());
                              }
                           }
                        }
                        else
                        {
                           LLOG(0,0,"IDA Recv Failure Response with Result Code : %u", l_errCode);
                           string l_calLoc = sendCancelLocation();
                        }
                        if(true == l_ida.containsIDAFlags())
                        {
                           const IDAFlags &l_idaflags = l_ida.getIDAFlags();
                           l_errCode = l_idaflags.value();
                           LLOG(0,0,"IDA Flag  : %d", l_idaflags.value());
                        }

                        //string l_eutrancellglobalidentityvalue;
                        //string l_trackingareaidentityvale;
                        //unsigned int l_ageoflocationinformationvalue;
                        if(true == l_ida.containsEPSLocationInformation())
                        {
                           DLOG(0,0,"Inside containsEPSLocationInformation");
                           const EPSLocationInformation &l_epsLocinfo = l_ida.getEPSLocationInformation();
                           if(true == l_epsLocinfo.containsMMELocationInformation())
                           {
                              DLOG(0,0,"Inside containsMMELocationInformation");
                              const MMELocationInformation &l_mmeLocinfo = l_epsLocinfo.getMMELocationInformation();
                              if(true == l_mmeLocinfo.containsEUTRANCellGlobalIdentity())
                              {
                                 DLOG(0,0,"Inside containsEUTRANCellGlobalIdentity");
                                 const EUTRANCellGlobalIdentity &l_eutrancellglobalidentity = l_mmeLocinfo.getEUTRANCellGlobalIdentity();
                                 string l_temp = l_eutrancellglobalidentity.value();
                                 char l_tempChar[100+1];
                                 HexToString((unsigned char *)l_tempChar,(unsigned char *)l_temp.c_str(),l_temp.length(),false);
                                 m_locinfo_cellid  = l_tempChar;
                                 DLOG(0,0,"m_locinfo_cellid [%s]",m_locinfo_cellid.c_str());
                                 m_tdr.setString(TDR_INDEX_SSM_NBR_USR, l_tempChar);
                                 DLOG_HEX(0,0,"l_temp ",l_temp.c_str(),l_temp.length());
                                 //sprintf(l_eutrancellglobalidentityvalue.c_str(),"%s",l_eutrancellglobalidentity.value());
                              }
                              if(true == l_mmeLocinfo.containsTrackingAreaIdentity())
                              {
                                 DLOG(0,0,"Inside containsTrackingAreaIdentity");
                                 const TrackingAreaIdentity &l_trackingareaidentity = l_mmeLocinfo.getTrackingAreaIdentity();
                                 string l_temp = l_trackingareaidentity.value();
                                 char l_tempChar[100+1];
                                 HexToString((unsigned char *)l_tempChar,(unsigned char *)l_temp.c_str(),l_temp.length(),false);
                                 m_locinfo_routingarea = l_tempChar;
                                 DLOG(0,0,"m_locinfo_routingarea [%s]",m_locinfo_routingarea.c_str());
                                 DLOG_HEX(0,0,"l_temp ",l_temp.c_str(),l_temp.length());
                              }
                              if(true == l_mmeLocinfo.containsAgeOfLocationInformation())
                              {
                                 DLOG(0,0,"Inside containsAgeOfLocationInformation");
                                 const AgeOfLocationInformation &l_ageoflocinfo = l_mmeLocinfo.getAgeOfLocationInformation();
                                 m_locinfo_ageof = l_ageoflocinfo.value();
                                 DLOG(0,0,"m_locinfo_ageof [%d]",m_locinfo_ageof);
                                 m_tdr.setInteger(TDR_INDEX_SSM_DEF_PRIORITY, m_locinfo_ageof);
                              }
                           }
                        }
                     }
                     if(m_getsubsflag == true)
                     {
                        DLOG(0,0,"For GET_SUBSCRIBER_INFO request calling getSubscriberLocInfoResp since IDA is success");
                        getSubscriberLocInfoResp(p_MsgPtr);
                     }
                  }
                  break;
               case DIAM_EVENT_TIME_OUT:
                  {
                     m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EVENT_TIME_OUT);
                     string l_calLoc = sendCancelLocation();
                     LLOG(0,0,"DIAM_EVENT_TIME_OUT received Cancel Location [%s]",l_calLoc.c_str() );
                     if(m_getsubsflag == true)
                     {
                        sendResponse(m_imd, 501, "DIAM_EVENT_TIME_OUT",(char*)m_response.c_str());
                        LLOG(0,0,"DIAM_EVENT_TIME_OUT received sendResponse func called and executed");
                     }
                  }
                  break;
#if 1
               case DIAM_EVENT_ERROR:
                  {
                     m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EVENT_ERROR);
                     string l_calLoc = sendCancelLocation();
                     LLOG(0,0,"DIAM_EVENT_ERROR received Cancel Location [%s]", l_calLoc.c_str());
                     if(m_getsubsflag == true)
                     {
                        //getSubscriberLocInfoResp(p_MsgPtr);
                        sendResponse(m_imd, 520, "DIAM_EVENT_ERROR",(char*)m_response.c_str());
                        LLOG(0,0,"DIAM_EVENT_ERROR received sendResponse func called and executed");
                     }
                  }
                  break;
#endif
               case DIAM_EVENT_AUTH_LIFE_TIME_OUT:
                  m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EVENT_AUTH_LIFE_TIME_OUT);
                  LLOG(0,0,"DIAM_EVENT_AUTH_LIFE_TIME_OUT received");
                  if(m_getsubsflag == true)
                  {
                     sendResponse(m_imd, 521, "DIAM_EVENT_AUTH_LIFE_TIME_OUT",(char*)m_response.c_str());
                     LLOG(0,0,"DIAM_EVENT_AUTH_LIFE_TIME_OUT received sendResponse func called and executed");
                  }
                  break;
               case DIAM_EVENT_AUTH_GRACE_TIME_OUT:
                  m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EVENT_AUTH_GRACE_TIME_OUT);
                  LLOG(0,0,"DIAM_EVENT_AUTH_GRACE_TIME_OUT received");
                  if(m_getsubsflag == true)
                  {
                     sendResponse(m_imd, 522, "DIAM_EVENT_AUTH_GRACE_TIME_OUT",(char*)m_response.c_str());
                     LLOG(0,0,"DIAM_EVENT_AUTH_GRACE_TIME_OUT received sendResponse func called and executed");
                  }
                  break;
               case DIAM_EVENT_CORRUPTED_MSG:
                  {
                     m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EVENT_CORRUPTED_MSG);
                     string l_calLoc = sendCancelLocation();
                     LLOG(0,0,"DIAM_EVENT_CORRUPTED_MSG received Cancel Location [%s]", l_calLoc.c_str());
                     if(m_getsubsflag == true)
                     {
                        sendResponse(m_imd, 523, "DIAM_EVENT_CORRUPTED_MSG",(char*)m_response.c_str());
                        LLOG(0,0,"DIAM_EVENT_CORRUPTED_MSG received sendResponse func called and executed");
                     }
                  }
                  break;
               case DIAM_EVENT_ACCT_INTERIM_TIME_OUT:
                  m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EVENT_ACCT_INTERIM_TIME_OUT);
                  LLOG(0,0,"DIAM_EVENT_ACCT_INTERIM_TIME_OUT received");
                  if(m_getsubsflag == true)
                  {
                     sendResponse(m_imd, 524, "DIAM_EVENT_ACCT_INTERIM_TIME_OUT",(char*)m_response.c_str());
                     LLOG(0,0,"DIAM_EVENT_ACCT_INTERIM_TIME_OUT received sendResponse func called and executed");
                  }
                  break;
               case DIAM_EVENT_ERROR_SOMETHING_WEIRD:
                  LLOG(0,0,"DIAM_EVENT_ERROR_SOMETHING_WEIRD received");
                  if(m_getsubsflag == true)
                  {
                     sendResponse(m_imd, 525, "DIAM_EVENT_ERROR_SOMETHING_WEIRD",(char*)m_response.c_str());
                     LLOG(0,0,"DIAM_EVENT_ERROR_SOMETHING_WEIRD received sendResponse func called and executed");
                  }
                  break;
               default:
                  LLOG(0,0,"UNKNOWN DIAMETER received");
                  return false;
                  break;

            }

         }
         break;

      case MSG_TYPE_DB:
         {
            WLOG(0,0,"DB message received");
         }
         break;

      case MSG_TYPE_TIMEOUT:
         {
            WLOG(0,0,"Timeout received");      
         }
         break;
      default:
         WLOG(0,0,"Unknown message received %d", p_MsgPtr->m_MsgType);
         break;
   }
   return true;
}

