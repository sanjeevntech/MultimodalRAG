#include <its++.h>
#include <its_timers.h>
#include <diameter/Command.h>
#include <diameter/base/BaseAVP.h>
#include <CtxtSimulatorInsertSubscriberData.h>
#include <stdio.h>
#include <MapMessages.h>
#include <ServiceCoordinator.h>
#include <ExtendedServiceCoordinator.h>
#include <ProvisioningMessages.h>
#include <Logger.h>
#include <DbActiveObject.h>
#include <Utilities.h>
#include <DataUnion.h>
#include <TimerManager.h>
#include <typeinfo>
#include <HlrTdrFiller.h>
#include <DiameterMessages.h>

//#include <s6a_stats.h>
//#include <app.h>
#include <DiametriqInterface.h>
#include <DiameterConstants.h>

CtxtSimulatorInsertSubscriberData::CtxtSimulatorInsertSubscriberData()
{
}

CtxtSimulatorInsertSubscriberData::~CtxtSimulatorInsertSubscriberData()
{
   DLOG(0,0,"CtxtSimulatorInsertSubscriberData :des:");
}

bool CtxtSimulatorInsertSubscriberData::processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag)
{
   DLOG(0,0,"Start of CtxtSimulatorInsertSubscriberData::processMsg function");

   p_DeleteFlag=p_DeleteFlag; // This is just to keep the compiler happy

   MapSpecificMsg *l_specMsg = NULL;

   switch (p_MsgPtr->m_MsgType)
   {
      case MSG_TYPE_MAP:
         {
            DLOG(0,0,"MAP message received");
         }
         break;

      case MSG_TYPE_DIAMETER:
         {
            LLOG(0,0,"DIAMETER message received");
            DiameterMsg *l_dm = (DiameterMsg*)p_MsgPtr;
            if(NULL != l_dm->m_cmd)
            {
               LLOG(0,0,"DIAMETER message received");

               string cellId = "32F4030084C601";
               string track = "32122";
               string geographic = "28122";
               string geoDetic = "12332";

               char a[100+1];
               char b[100+1];
               char c[100+1];
               char d[100+1];
               
               memset(a,'\0',sizeof(a));
               memset(b,'\0',sizeof(b));
               memset(c,'\0',sizeof(c));
               memset(d,'\0',sizeof(d));

               atohx(a,cellId.c_str());
               atohx(b,track.c_str());
               atohx(c,geographic.c_str());
               atohx(d,geoDetic.c_str());

               cellId.empty();
               track.empty();
               geographic.empty();
               geoDetic.empty();

               cellId.assign(a);
               track.assign(b);
               geographic.assign(c);
               geoDetic.assign(d);

               diameter::s6a_r10::InsertSubscriberDataRequest idr(*(diameter::CommandImpl*)l_dm->m_cmd);
               diameter::s6a_r10::InsertSubscriberDataRequest *l_idr = &idr;
               diameter::base::SessionId sess= l_idr->getSessionId();
               unsigned int  l_idx = l_idr->getSessionIndex();
               LLOG(0,0,"IDA Session Id : %d", l_idx);
               diameter::s6a_r10::InsertSubscriberDataAnswer l_idaData;

               //diameter::s6a_r10::InsertSubscriberDataAnswer *l_ida = new diameter::s6a_r10::InsertSubscriberDataAnswer;
               diameter::s6a_r10::InsertSubscriberDataAnswer *l_ida = &l_idaData;
               DiameterMsg l_answer ((char*)sess.value().c_str(), DIAM_EVENT_ANSWER,DIAM_COMM_CODE_S6A_S6D_S7A_S7D_IDR_IDA);
               l_answer.m_cmd = l_ida;

               const SessionId &sid1 = l_idr->getSessionId();
               const OriginHost &oh1 = l_idr->getOriginHost();
               const OriginRealm &or1 = l_idr->getOriginRealm();
               const AuthSessionState &authSessState = l_idr->getAuthSessionState();
               l_ida->setSessionId(sid1);
               l_ida->setSessionIndex(l_idr->getSessionIndex());
               l_ida->setAuthSessionState(authSessState);
               unsigned int l_code = DIAM_RESULT_CODE_SUCCESS;
               ResultCode resultCode(l_code);
               l_ida->setResultCode(resultCode);

               ExperimentalResult experimentalResult;
               VendorId vendorId1(1);
               experimentalResult.setVendorId(vendorId1);

               ExperimentalResultCode experimentalResultCode(l_code);
               experimentalResult.setExperimentalResultCode(experimentalResultCode);
               l_ida->setExperimentalResult(experimentalResult);

               OriginHost originHost("MyHost");

               l_ida->setOriginHost(originHost);

               SupportedFeatures l_tempsupportedfeature;
               VendorId l_tempvenderId(10415);
               l_tempsupportedfeature.setVendorId(l_tempvenderId);
               FeatureListID l_tempfeaturelistid(1);
               l_tempsupportedfeature.setFeatureListID(l_tempfeaturelistid);
               FeatureList l_tempfeaturelist(4294967295);
               l_tempsupportedfeature.setFeatureList(l_tempfeaturelist);
               l_ida->addSupportedFeatures(l_tempsupportedfeature);

               OriginRealm originRealm("MyRealm");
               l_ida->setOriginRealm(originRealm);
               IDAFlags ida(1);

               l_ida->setIDAFlags(ida);

               EPSLocationInformation l_locInfo;
               MMELocationInformation l_mmeLocInfo;

               EUTRANCellGlobalIdentity l_cellId(a);
               l_mmeLocInfo.setEUTRANCellGlobalIdentity(l_cellId);

               TrackingAreaIdentity l_track(b);
               l_mmeLocInfo.setTrackingAreaIdentity(l_track);

               GeographicalInformation l_geoGraphic(c);
               l_mmeLocInfo.setGeographicalInformation(l_geoGraphic);

               GeodeticInformation l_geoDetic(d);
               l_mmeLocInfo.setGeodeticInformation(l_geoDetic);

               AgeOfLocationInformation l_ageOfLocation(12);
               l_mmeLocInfo.setAgeOfLocationInformation(l_ageOfLocation);

               CurrentLocationRetrieved l_currentLoc(CurrentLocationRetrieved::ACTIVE_LOCATION_RETRIEVAL);
               l_mmeLocInfo.setCurrentLocationRetrieved(l_currentLoc);

               l_locInfo.setMMELocationInformation(l_mmeLocInfo);
               l_ida->setEPSLocationInformation(l_locInfo); 

               EPSUserState l_epsUserState;
               MMEUserState l_mmeState;

               UserState l_userState(UserState::ATTACHED_NOT_REACHABLE_FOR_PAGING);
               l_mmeState.setUserState(l_userState);

               l_epsUserState.setMMEUserState(l_mmeState);
               l_ida->setEPSUserState(l_epsUserState);

               g_esc.sendMsg(this, &l_answer);
            }
         }
         break;

      case MSG_TYPE_DB:
         {
            DLOG(0,0,"DB message received");
         }
         break;

      case MSG_TYPE_TIMEOUT:
         {
            LLOG(0,0,"Timeout received");      
         }
         break;
      default:
         DLOG(0,0,"Unknown message received %d", p_MsgPtr->m_MsgType);
         break;
   }
   return true;
}

