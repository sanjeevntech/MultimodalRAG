#ifndef __CONTEXT_DIAM_SIM_DEL_SUB_DATA_REQUEST_H
#define __CONTEXT_DIAM_SIM_DEL_SUB_DATA_REQUEST_H

#include <ContextBase.h>
#include <Msg.h>
#include <DeleteSubscriberData.h>
#include <S6a_r10AVP.h>
#define MAX_HOST_LEN    100
#define MAX_REALM_LEN   100
#define MAX_IMSI_LEN    20
using namespace diameter::s6a_r10;
using namespace diameter::base;

class CtxtSimulatorDeleteSubscriberData : public ContextBase
{
   private:

   public:
      CtxtSimulatorDeleteSubscriberData();
      ~CtxtSimulatorDeleteSubscriberData();

      bool processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag);
};



#endif
