#ifndef __CONTEXT_DIAM_SIM_INS_SUB_DATA_REQUEST_H
#define __CONTEXT_DIAM_SIM_INS_SUB_DATA_REQUEST_H

#include <ContextBase.h>
#include <Msg.h>
#include <DiameterMessages.h>
#include <InsertSubscriberData.h>
#include <S6a_r10AVP.h>

#include <SubsProfileData.h>

#define MAX_HOST_LEN    100
#define MAX_REALM_LEN   100
#define MAX_IMSI_LEN    20
using namespace diameter::s6a_r10;
using namespace diameter::base;


class CtxtSimulatorInsertSubscriberData : public ContextBase
{
   private:
      char m_destination_Realm[MAX_REALM_LEN + 1];
      char m_imsi[MAX_IMSI_LEN + 1];

   public:
      CtxtSimulatorInsertSubscriberData();
      ~CtxtSimulatorInsertSubscriberData();

      bool processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag);
};



#endif
