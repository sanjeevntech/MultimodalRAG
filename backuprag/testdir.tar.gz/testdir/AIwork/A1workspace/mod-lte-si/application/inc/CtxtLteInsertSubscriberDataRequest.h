#ifndef __CONTEXT_DIAM_INS_SUB_DATA_REQUEST_H
#define __CONTEXT_DIAM_INS_SUB_DATA_REQUEST_H

#include <ContextBase.h>
#include <Msg.h>
#include <DiameterMessages.h>
#include <InsertSubscriberData.h>
#include <S6a_r10AVP.h>

#include <SubsProfileData.h>

#define MAX_HOST_LEN    100
#define MAX_REALM_LEN   100
#define MAX_IMSI_LEN    20
#define MAX_TRANSACTION_LEN 20
#define VENDOR_FEATURE_ID    10415

using namespace diameter::s6a_r10;
using namespace diameter::base;
#define F1_ODB_ALL_APN                                                  0x00000001
#define F1_ODB_HPLMN_APN                                                0x00000002
#define F1_ODB_VPLMN_APN                                                0x00000004
#define F1_ODB_ALL_OG                                                   0x00000008
#define F1_ODB_ALL_InternationalOG                                      0x00000010
#define F1_ODB_ALL_InternationalOG_NotToHPLMNCountry                    0x00000020
#define F1_ODB_ALL_InterzonalOG                                         0x00000040
#define F1_ODB_ALL_InterzonalOG_NotToHPLMNCountry                       0x00000080
#define F1_ODB_ALL_InterzonalOG_And_InternationalOG_NotToHPLMNCountry   0x00000100
#define F1_RegSub                                                       0x00000200
#define F1_Trace                                                        0x00000400
#define F1_LCS_ALL_PrivExcep                                            0x00000800
#define F1_LCS_Universal                                                0x00001000
#define F1_LCS_CALL_SessionRelated                                      0x00002000
#define F1_LCS_CALL_SessionUnrelated                                    0x00004000
#define F1_LCS_PLMNOperator                                             0x00008000
#define F1_LCS_ServiceType                                              0x00010000
#define F1_LCS_ALL_MOLRSS                                               0x00020000
#define F1_LCS_BasicSelfLocation                                        0x00040000
#define F1_LCS_AutonomousSelfLocation                                   0x00080000
#define F1_LCS_TransferToThirdParty                                     0x00100000
#define F1_SMMOPP                                                       0x00200000
#define F1_BarringOutgoingCalls                                         0x00400000
#define F1_BAOC                                                         0x00800000
#define F1_BOIC                                                         0x01000000
#define F1_BOICExHC                                                     0x02000000
#define F1_UEReachabilityNotification                                   0x04000000
#define F1_TADS_Data_Retrieval                                          0x08000000
#define F1_State_LocationInformationRetrieval                           0x10000000
#define F1_Partial_Purge                                                0x20000000
#define F1_Local_Time_Zone_Retrieval                                    0x40000000
#define F1_Additional_MSISDN                                            0x80000000


#define F2_SMS_in_MME                                                   0x00000001
#define F2_SMS_in_SGSN                                                  0x00000002
#define F2_DiaLCS_ALL_PrivExcep                                         0x00000004
#define F2_DiaLCS_Universal                                             0x00000008
#define F2_DiaLCS_CALL_SessionRelated                                   0x00000010
#define F2_DiaLCS_CALL_SessionUnrelated                                 0x00000020
#define F2_DiaLCS_PLMNOperator                                          0x00000040
#define F2_DiaLCS_ServiceType                                           0x00000080
#define F2_DiaLCS_ALL_MOLRSS                                            0x00000100
#define F2_DiaLCS_BasicSelfLocation                                     0x00000200
#define F2_DiaLCS_AutonomousSelfLocation                                0x00000400
#define F2_DiaLCS_TransferToThirdParty                                  0x00000800
#define F2_EXTENDED_FEATURES                                            0xFFFFF000

#define HSS_3GPPCHARGINGCHAR_LEN                 2

#define F2_NR_AS_SECONDARY_RAT                                          0x08000000  // 27th bit 5051A

class CtxtLteInsertSubscriberDataRequest : public ContextBase
{
   private:
      string m_response;
      char m_transactionId[MAX_TRANSACTION_LEN + 1];
      char m_origin_Host[MAX_HOST_LEN + 1];
      char m_origin_Realm[MAX_REALM_LEN + 1];
      char m_destination_Host[MAX_HOST_LEN + 1];
      char m_destination_Realm[MAX_REALM_LEN + 1];
      char m_imsi[MAX_IMSI_LEN + 1];
      short m_partner_Type;
      int m_partner_nkId;
      unsigned int m_modifyOdb;
      unsigned int m_featureList2;
      unsigned int m_featureList1;
      bool m_odbDataSend ;
      unsigned int m_mmeFeatureList1;
      unsigned int m_mmeFeatureList2;
      string m_IPv4Addr;    //5055
      string m_IPv6Addr;    //5055
      int m_Nwk_Id;
      bool m_5gSupportFlag;
      bool m_hlr_5gSupportFlag;
      int m_ims_service_flag;
      
      string m_locinfo_cellid;
      string m_locinfo_routingarea;
      unsigned int m_locinfo_ageof;
      bool m_getsubsflag;
      InterModuleData *m_imd;

      s8 m_SarIpv4Address[39 + 1]; //6.4.0.0
      s8 m_SarIpv6Address[39 + 1]; //6.4.0.0
      s8 m_SarPgwRealm[200 + 1]; //6.4.0.0
      s8 m_SarPgwHost[200 + 1]; //6.4.0.0

   public:
      bool getTransactionId(char *p_req);
      CtxtLteInsertSubscriberDataRequest();
      ~CtxtLteInsertSubscriberDataRequest();
      bool preInsertSubscriberData(char *preq);
      bool startProcessing(InterModuleData*, bool&);
      string sendCancelLocation();
      bool fillGPRSSubscriptionData(int p_gprsProfileId, GPRSSubscriptionData* p_gprsSubscriptionData);

      bool processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag);
      bool fillingApnConfigurationProfile(LteConfigProf* aLteConfigProf,APNConfigurationProfile* aApnConfProf);
      bool requireSendCancelLoc(InsertSubscriberDataAnswer *p_answer);
      bool sendResponse(InterModuleData *p_imd, int p_errorCode, char *p_errorDesc, char *p_ResponseBody);
      bool getSubscriberLocInfoResp(Msg *p_MsgPtr);

      //bool getSubscriberLocInfo(char *p_req , char *p_resp);
};



#endif
