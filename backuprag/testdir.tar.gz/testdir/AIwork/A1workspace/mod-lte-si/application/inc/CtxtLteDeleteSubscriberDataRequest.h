#ifndef __CONTEXT_DIAM_DEL_SUB_DATA_REQUEST_H
#define __CONTEXT_DIAM_DEL_SUB_DATA_REQUEST_H

#include <ContextBase.h>
#include <Msg.h>
#include <DeleteSubscriberData.h>
#include <S6a_r10AVP.h>
#define MAX_HOST_LEN    100
#define MAX_REALM_LEN   100
#define MAX_IMSI_LEN    20
#define MAX_TRANSACTION_LEN 20

using namespace diameter::s6a_r10;
using namespace diameter::base;

class CtxtLteDeleteSubscriberDataRequest : public ContextBase
{
   private:
      char m_transactionId[MAX_TRANSACTION_LEN +1 ];
      char m_origin_Host[MAX_HOST_LEN + 1];
      char m_origin_Realm[MAX_REALM_LEN + 1];
      char m_destination_Host[MAX_HOST_LEN + 1];
      char m_destination_Realm[MAX_REALM_LEN + 1];
      char m_imsi[MAX_IMSI_LEN + 1];
      short m_partner_Type;
      string m_response;
      InterModuleData *m_imd;

   public:
      CtxtLteDeleteSubscriberDataRequest();
      ~CtxtLteDeleteSubscriberDataRequest();

      bool getTransactionId(char *p_req);
      bool preDeleteSubscriberData(char *p_req);
      string sendCancelLocation();
      bool startProcessing(InterModuleData*, bool&);

      bool processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag);
};



#endif
