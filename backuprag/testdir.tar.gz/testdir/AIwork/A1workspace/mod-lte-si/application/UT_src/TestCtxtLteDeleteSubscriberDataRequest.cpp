#define private public
#include<iostream>
#include"gtest.h"
#include <its++.h>
#include <its_timers.h>
#include <diameter/Command.h>
#include <diameter/base/BaseAVP.h>
#include <CtxtLteDeleteSubscriberDataRequest.h>
#include <stdio.h>
#include <MapMessages.h>
#include <ServiceCoordinator.h>
#include <ExtendedServiceCoordinator.h>
#include <ProvisioningMessages.h>
#include <Logger.h>
#include <DbActiveObject.h>
#include <Utilities.h>
#include <DataUnion.h>
#include <TimerManager.h>
#include <typeinfo>
#include <HlrTdrFiller.h>
#include <DiameterMessages.h>
#include <DiametriqInterface.h>
#include <DiameterConstants.h>
#include<IMAP3.h>
#include<HssSubsProfileData.h>
#include<Msg.h>
#include<DiameterMessages.h>
#include <TcpSocketServer.h>
//using namespace std;
//using namespace its;
//using namespace diameter;
//using namespace diameter::base;
using namespace diameter::s6a_r10;

class UT_CtxtLteDeleteSubscriberDataRequest: public testing::Test , public CtxtLteDeleteSubscriberDataRequest
{public:
UT_CtxtLteDeleteSubscriberDataRequest()
{
}
~UT_CtxtLteDeleteSubscriberDataRequest()
{
}
};

class UT_InterModuleData
{public:
UT_InterModuleData()
{
}
~UT_InterModuleData()
{
}
};

class UT_Msg
{public:
UT_Msg()
{
}
~UT_Msg()
{
}
};

class UT_DiameterMsg
{public:
UT_DiameterMsg()
{
}
~UT_DiameterMsg()
{
}
};



TEST_F(UT_CtxtLteDeleteSubscriberDataRequest,sendCancelLocation_Func) {
EXPECT_NO_THROW(sendCancelLocation());
}

TEST_F(UT_CtxtLteDeleteSubscriberDataRequest,getTransactionId_Func) {
char p_Req[]="a:a:a:a";
EXPECT_TRUE(getTransactionId(p_Req));
}

TEST_F(UT_CtxtLteDeleteSubscriberDataRequest,preDeleteSubscriberData_Func) {
char p_Req[]="a:a:a:aaaaaaaaaaaaaaaaaaa;1233l";
EXPECT_FALSE(preDeleteSubscriberData(p_Req));
}

/*TEST_F(UT_CtxtLteDeleteSubscriberDataRequest,startProcessing_Func) {
InterModuleData obj;
strcpy(obj.m_Parameters,"::::::aaaaa:::::");
bool p_DeleteFlag=true;
EXPECT_TRUE(startProcessing(&obj,p_DeleteFlag));
}*/


TEST_F(UT_CtxtLteDeleteSubscriberDataRequest,processMessage_MSG_TYPE_MAP_Func) {
Msg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtLteDeleteSubscriberDataRequest,processMessage_MSG_TYPE_DIAMETER_Func) {
Msg p_MsgPtr;
p_MsgPtr.m_MsgType=7;
bool p_DeleteFlag=true;
EXPECT_FALSE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtLteDeleteSubscriberDataRequest,processMessage_MSG_TYPE_DB_Func) {
Msg p_MsgPtr;
p_MsgPtr.m_MsgType=2;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtLteDeleteSubscriberDataRequest,processMessage_MSG_TYPE_TIMEOUT_Func) {
Msg p_MsgPtr;
p_MsgPtr.m_MsgType=4;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtLteDeleteSubscriberDataRequest,processMessage_default_Func) {
Msg p_MsgPtr;
p_MsgPtr.m_MsgType=0;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

#undef private

















