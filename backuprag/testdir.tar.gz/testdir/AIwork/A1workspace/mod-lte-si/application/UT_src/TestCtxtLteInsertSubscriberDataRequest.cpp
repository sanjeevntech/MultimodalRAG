#define private public
#include<iostream>
#include"gtest.h"
#include <its++.h>
#include <its_timers.h>
#include <diameter/Command.h>
#include <diameter/base/BaseAVP.h>
#include <CtxtLteInsertSubscriberDataRequest.h>
#include <stdio.h>
#include <MapMessages.h>
#include <ServiceCoordinator.h>
#include <ExtendedServiceCoordinator.h>
#include <ProvisioningMessages.h>
#include <Logger.h>
#include <DbActiveObject.h>
#include <Utilities.h>
#include <DataUnion.h>
#include <TimerManager.h>
#include <typeinfo>
#include <HlrTdrFiller.h>
#include <DiameterMessages.h>
#include <DiametriqInterface.h>
#include <DiameterConstants.h>
#include<IMAP3.h>
#include<HssSubsProfileData.h>
#include<Msg.h>
#include<DiameterMessages.h>
using namespace diameter::s6a_r10;

extern int getPartnerIdrLteProfId(unsigned int p_LteProfId, int p_NkId, int p_PartnerNkId);

class UT_CtxtLteInsertSubscriberDataRequest: public testing::Test , public CtxtLteInsertSubscriberDataRequest
{public:
UT_CtxtLteInsertSubscriberDataRequest()
{
}
~UT_CtxtLteInsertSubscriberDataRequest()
{
}
};

class UT_GPRSSubscriptionData
{public:
UT_GPRSSubscriptionData()
{
}
~UT_GPRSSubscriptionData()
{
}
};

class UT_APNConfigurationProfile
{public:
UT_APNConfigurationProfile()
{
}
~UT_APNConfigurationProfile()
{
}
};

class UT_InterModuleData
{public:
UT_InterModuleData()
{
}
~UT_InterModuleData()
{
}
};

class UT_Msg
{public:
UT_Msg()
{
}
~UT_Msg()
{
}
};

class UT_DiameterMsg
{public:
UT_DiameterMsg()
{
}
~UT_DiameterMsg()
{
}
};
/*
//Not Working in mobaxterm
TEST(CtxtLteInsertSubscriberDataRequest_cpp_getPartnerIdrLteProfId_Func, Return_int) {
unsigned int p_LteProfId=1;
int p_NkId=1;
g_spd=new GlobalData;
int p_PartnerNkId=1;
EXPECT_NE(getPartnerIdrLteProfId(p_LteProfId,p_NkId,p_PartnerNkId),-1);
}
*/

/*TEST_F(UT_CtxtLteInsertSubscriberDataRequest,sendCancelLocation_Func) {
CtxtLteInsertSubscriberDataRequest::m_partner_Type=0;
EXPECT_STRNE(sendCancelLocation(),"aaa");
}*/

/*
TEST_F(UT_CtxtLteInsertSubscriberDataRequest,getTransactionId_Func) {
char p_Req[]="a:a:a:a";
EXPECT_TRUE(getTransactionId(p_Req));
}
*/

/*TEST_F(UT_CtxtLteInsertSubscriberDataRequest,getTransactionId_False_Func) {
char p_Req[]="aaaaaaa";
EXPECT_TRUE(getTransactionId(p_Req));
}*/

/*
TEST_F(UT_CtxtLteInsertSubscriberDataRequest,preInsertSubscriberData_Func) {
char p_Req[]="a:a:a:aaaaaaaaaaaaaaaaaaa;1233l";
EXPECT_FALSE(preInsertSubscriberData(p_Req));
}
*/

/*
TEST_F(UT_CtxtLteInsertSubscriberDataRequest,fillGPRSSubscriptionData_Func) {
GPRSSubscriptionData p_gprsSubscriptionData;
g_spd=new GlobalData;
EXPECT_TRUE(fillGPRSSubscriptionData(1,&p_gprsSubscriptionData));
}
*/
/*TEST_F(UT_CtxtLteInsertSubscriberDataRequest,fillGPRSSubscriptionData_Two_Func) {
GPRSSubscriptionData p_gprsSubscriptionData;
g_spd=new GlobalData;
EXPECT_TRUE(fillGPRSSubscriptionData(0.5,&p_gprsSubscriptionData));
}*/
/*
TEST_F(UT_CtxtLteInsertSubscriberDataRequest,fillingApnConfigurationProfile_Func) {
LteConfigProf *ptr=new LteConfigProf;
ptr->m_apnProfDetails.m_DefaultCtxdID=1;
APNConfigurationProfile *aApnConfProf=new APNConfigurationProfile;
EXPECT_TRUE(fillingApnConfigurationProfile(&ptr,&aApnConfProf));
delete ptr;
delete aApnConfProf;
}*/

/*TEST_F(UT_CtxtLteInsertSubscriberDataRequest,startProcessing_Func) {
InterModuleData obj;
strcpy(obj.m_Parameters,"::::::aaaaa:::::");
bool p_DeleteFlag=true;
EXPECT_TRUE(startProcessing(&obj,p_DeleteFlag));
}*/

/*TEST_F(UT_CtxtLteInsertSubscriberDataRequest,processMessage_MSG_TYPE_MAP_Func) {
Msg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtLteInsertSubscriberDataRequest,processMessage_MSG_TYPE_DIAMETER_Func) {
Msg p_MsgPtr;
p_MsgPtr.m_MsgType=7;
bool p_DeleteFlag=true;
EXPECT_FALSE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtLteInsertSubscriberDataRequest,processMessage_MSG_TYPE_DB_Func) {
Msg p_MsgPtr;
p_MsgPtr.m_MsgType=2;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtLteInsertSubscriberDataRequest,processMessage_MSG_TYPE_TIMEOUT_Func) {
Msg p_MsgPtr;
p_MsgPtr.m_MsgType=4;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}*/

/*
TEST_F(UT_CtxtLteInsertSubscriberDataRequest,processMessage_default_Func) {
Msg p_MsgPtr;
p_MsgPtr.m_MsgType=0;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}
*/
/*
TEST_F(UT_CtxtLteInsertSubscriberDataRequest,processMessage_MSG_TYPE_DIAMETER_DIAM_EVENT_ANSWER_Func) {
DiameterMsg p_MsgPtr("host26.realm26;1628358902;498433;1:2",DIAM_EVENT_ANSWER,318);;
p_MsgPtr.m_MsgType=7;
p_MsgPtr.m_det=2;
bool p_DeleteFlag=true;
p_MsgPtr.m_cmd!=NULL;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}
*/

#undef private

