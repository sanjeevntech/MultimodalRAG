export ORACLE_HOME=/ora10gclnt/product/10.2.0/client
PATH=$PATH:$ORACLE_HOME/bin/
LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$ORACLE_HOME/lib/:/74bkp1/rgopal/work/GIT/GUTIL/gen-util/lib/:/opt/sfp/64bit/openssl-0.9.8m/lib/:/usr/sfw/lib/64/
