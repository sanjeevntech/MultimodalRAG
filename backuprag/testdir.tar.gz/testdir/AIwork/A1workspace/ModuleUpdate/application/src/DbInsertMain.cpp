#include <iostream>
#include <stdlib.h>   
#include <string>
#include <strings.h>
#include <errno.h>
#include <netinet/in.h>
#include <netdb.h> 
#include "ConfigReader.h" 
#include "parser.h"  
#include "Logger.h" 
#include "CurrentTime.h"  
#include <map>
#include <time.h>   
#include <SnmpInterface.h>
#include <GenUtils.h>
#include <list>
using namespace std;

ConfigReader g_ConObj;

extern int DbUpdate();
extern char g_selfIpAddress;

Logger g_LoggerObj;


int main(int argc,char *argv[])
{
   if(false == g_ConObj.init("ConfigData.xml"))
   {
      printf("\nLogger Initialization Failed.");
      exit(0);
   }
   else
   {
      if(false == g_ConObj.readLoggerData())
      {
         printf("\nError in ReadDataLogger");
         exit(0);
      }
      else
      {
         bool l_status = g_LoggerObj.initialize(g_ConObj.m_LogLevel,g_ConObj.m_LogMedia, g_ConObj.m_LogfilePath, 
               g_ConObj.m_LogPrefix, 
               "log",
               g_ConObj.m_ArchivalPath, 
               g_ConObj.m_LogMaxsize,
               0,
               LOG_ROTATE_TYPE_FALSE ,
               g_ConObj.m_LogFileMaxFiles,
               MAX_DUMP_LOGGING_SIZE);
         if (false == l_status)
         {
            ELOG(0,0,"\nUnable to initialize Logger \n");
            exit(0);
         }
         else
         {
            ELOG(0,0,"\nLOGGER STARTED Successfully\n");
         }
      }
   }

if(g_ConObj.m_instanceType == 1 && argc == 1 ) 
{
   printf("\n ####### HLR CONFIGURATION VALUES BEING INSERTED ########\n");               
               g_ConObj.m_InstanceSp_DB = (string)"ALL";
               g_ConObj.m_IPAddress_DB = (string)"ALL";
               g_ConObj.m_IPPort_DB = (string)"ALL";
               g_ConObj.m_EntityName_DB = (string)"ALL"; 
 
   if(false == g_ConObj.init("ProfConfigData.xml"))       
   {
      ELOG(0,0,"\nProfConfigData.xml not Found");
      exit(0);                                    
   }                                              
   if(false == g_ConObj.read_SUBS_PROF_Data())               
   {                          
      ELOG(0,0,"\nError in reading ProfConfigData.xml");
      exit(0);                                    
   } 

   if(false == g_ConObj.init("MmConfigData.xml"))       
   {
      ELOG(0,0,"\nMmConfigData.xml not Found");
      exit(0);                                    
   }                                              
   if(false == g_ConObj.read_MM_Data())               
   {                          
      ELOG(0,0,"\nError in reading MmConfigData");
      exit(0);                                    
   }                                              

   if(false == g_ConObj.init("CmConfigData.xml"))       
   {
      ELOG(0,0,"\nCmConfigData.xml not Found");
      exit(0);                                    
   }                                              
   if(false == g_ConObj.read_CM_Data())               
   {                          
      ELOG(0,0,"\nError in reading CmConfigData.xml");
      exit(0);                                    
   }
   if(false == g_ConObj.init("AucConfigData.xml"))       
   {
      ELOG(0,0,"\nAucConfigData.xml not Found");
      exit(0);                                    
   }                                              

   if(false == g_ConObj.read_AUC_Data())               
   {                          
      ELOG(0,0,"\nError in reading AUCConfigData.xml");
      exit(0);                                    
   }
   if(false == g_ConObj.init("SiConfigData.xml"))       
   {
      ELOG(0,0,"\nSiConfigData.xml not Found");
      exit(0);                                    
   }                                              

   if(false == g_ConObj.read_SI_Data())               
   {                          
      ELOG(0,0,"\nError in reading SiConfigData.xml");
      exit(0);                                    
   }
   if(false == g_ConObj.init("OamConfigData.xml"))       
   {
      ELOG(0,0,"\nOamConfigData.xml not Found");
      exit(0);                                    
   }                                              

   if(false == g_ConObj.read_OAM_Data())               
   {                          
      ELOG(0,0,"\nError in reading OamConfigData.xml");
      exit(0);                                    
   }
   if(false == g_ConObj.init("GprsConfigData.xml"))       
   {
      ELOG(0,0,"\nGprsConfigData.xml not Found");
      exit(0);                                    
   }                                              

   if(false == g_ConObj.read_GPR_Data())               
   {                          
      ELOG(0,0,"\nError in reading GprsConfigData.xml");
      exit(0);                                    
   }
   if(false == g_ConObj.init("SsConfigData.xml"))       
   {
      ELOG(0,0,"\nSsConfigData.xml not Found");
      exit(0);                                    
   }                                              

   if(false == g_ConObj.read_SSM_Data())               
   {                          
      ELOG(0,0,"\nError in reading SsConfigData.xml");
      exit(0);                                    
   }
   if(false == g_ConObj.init("SmsmConfigData.xml"))       
   {
      ELOG(0,0,"\nSmsmConfigData.xml not Found");
      exit(0);                                    
   }                                              

   if(false == g_ConObj.read_SMSM_Data())               
   {                          
      ELOG(0,0,"\nError in reading SmsmConfigData.xml");
      exit(0);                                    
   }
   if(false == g_ConObj.init("LteMmConfigData.xml"))       
   {
      ELOG(0,0,"\nLteMmConfigData.xml not Found");
      exit(0);                                    
   }                                              

   if(false == g_ConObj.read_LMM_Data())               
   {                          
      ELOG(0,0,"\nError in reading LteMmConfigData.xml");
      exit(0);                                    
   }
   if(false == g_ConObj.init("Mm2ConfigData.xml"))       
   {
      ELOG(0,0,"\nMm2ConfigData.xml not Found");
      exit(0);                                    
   }                                              
   if(false == g_ConObj.read_LM2_Data())               
   {                          
      ELOG(0,0,"\nError in reading Mm2ConfigData.xml");
      exit(0);                                    
   }

}
else if(g_ConObj.m_instanceType == 1 && argc == 6)
{
printf("\n ####### HLR CONFIGURATION VALUES BEING INSERTED ########\n");
   g_ConObj.m_EntityName_DB = (string)argv[3];
   g_ConObj.m_IPAddress_DB = (string)argv[4];
   g_ConObj.m_IPPort_DB = (string)argv[5];
   g_ConObj.m_InstanceSp_DB = (string)argv[1];
//   strcpy(g_ConObj.m_RtpsConfigName,argv[2]);
   strcpy(g_ConObj.m_InstanceConfigName,argv[2]);
   if(false == g_ConObj.init("ProfConfigData.xml"))       
   {
      //ELOG(0,0,"\nProfConfigData.xml not Found");
      //exit(0);                                    
   }                                              
   if(false == g_ConObj.read_SUBS_PROF_Data())               
   {                          
      //ELOG(0,0,"\nError in reading ProfConfigData.xml");
      //exit(0);                                    
   } 

   if(false == g_ConObj.init("MmConfigData.xml"))       
   {
      //ELOG(0,0,"\nMmConfigData.xml not Found");
      //exit(0);                                    
   }                                              
   if(false == g_ConObj.read_MM_Data())               
   {                          
      //ELOG(0,0,"\nError in reading MmConfigData");
      //exit(0);                                    
   }                                              

   if(false == g_ConObj.init("CmConfigData.xml"))       
   {
      //ELOG(0,0,"\nCmConfigData.xml not Found");
      //exit(0);                                    
   }                                              
   if(false == g_ConObj.read_CM_Data())               
   {                          
      //ELOG(0,0,"\nError in reading CmConfigData.xml");
      //exit(0);                                    
   }
   if(false == g_ConObj.init("AucConfigData.xml"))       
   {
      //ELOG(0,0,"\nAucConfigData.xml not Found");
      //exit(0);                                    
   }                                              

   if(false == g_ConObj.read_AUC_Data())               
   {                          
      //ELOG(0,0,"\nError in reading AUCConfigData.xml");
      //exit(0);                                    
   }
   if(false == g_ConObj.init("SiConfigData.xml"))       
   {
      //ELOG(0,0,"\nSiConfigData.xml not Found");
      //exit(0);                                    
   }                                              

   if(false == g_ConObj.read_SI_Data())               
   {                          
      //ELOG(0,0,"\nError in reading SiConfigData.xml");
      //exit(0);                                    
   }
   if(false == g_ConObj.init("OamConfigData.xml"))       
   {
      //ELOG(0,0,"\nOamConfigData.xml not Found");
      //exit(0);                                    
   }                                              

   if(false == g_ConObj.read_OAM_Data())               
   {                          
      //ELOG(0,0,"\nError in reading OamConfigData.xml");
      //exit(0);                                    
   }
   if(false == g_ConObj.init("GprsConfigData.xml"))       
   {
      //ELOG(0,0,"\nGprsConfigData.xml not Found");
      //exit(0);                                    
   }                                              

   if(false == g_ConObj.read_GPR_Data())               
   {                          
      //ELOG(0,0,"\nError in reading GprsConfigData.xml");
      //exit(0);                                    
   }
   if(false == g_ConObj.init("SsConfigData.xml"))       
   {
      //ELOG(0,0,"\nSsConfigData.xml not Found");
      //exit(0);                                    
   }                                              

   if(false == g_ConObj.read_SSM_Data())               
   {                          
      //ELOG(0,0,"\nError in reading SsConfigData.xml");
      //exit(0);                                    
   }
   if(false == g_ConObj.init("SmsmConfigData.xml"))       
   {
      //ELOG(0,0,"\nSmsmConfigData.xml not Found");
      //exit(0);                                    
   }                                              

   if(false == g_ConObj.read_SMSM_Data())               
   {                          
      //ELOG(0,0,"\nError in reading SmsmConfigData.xml");
      //exit(0);                                    
   }
   if(false == g_ConObj.init("LteMmConfigData.xml"))       
   {
      //ELOG(0,0,"\nLteMmConfigData.xml not Found");
      //exit(0);                                    
   }                                              

   if(false == g_ConObj.read_LMM_Data())               
   {                          
      //ELOG(0,0,"\nError in reading LteMmConfigData.xml");
      //exit(0);                                    
   }
   if(false == g_ConObj.init("Mm2ConfigData.xml"))       
   {
      //ELOG(0,0,"\nMm2ConfigData.xml not Found");
      //exit(0);                                    
   }                                              
   if(false == g_ConObj.read_LM2_Data())               
   {                          
      //ELOG(0,0,"\nError in reading Mm2ConfigData.xml");
      //exit(0);                                    
   }

}
else if((g_ConObj.m_instanceType == 2) && (argc >= 3))
   { 
   printf("\n ####### RTPS CONFIGURATION VALUES BEING INSERTED ########\n");
      if((0 ==strcmp(argv[1],"ALL") )|| (0 == strcmp(argv[1], "INST")))
      {
         if(0 ==strcmp(argv[1],"ALL"))
         {
            if(argc == 3)
            {
               g_ConObj.m_InstanceSp_DB = (string)"ALL";
               g_ConObj.m_IPAddress_DB = (string)"ALL";
               g_ConObj.m_IPPort_DB = (string)"ALL";
               g_ConObj.m_EntityName_DB = (string)"ALL"; 
               strcpy(g_ConObj.m_RtpsConfigName,argv[2]);
               
               if(false == g_ConObj.init(g_ConObj.m_RtpsConfigName))  
               {
                  ELOG(0,0,"\n%s not Found",g_ConObj.m_RtpsConfigName);
                  exit(0);                                    
               }                                              
               if(false == g_ConObj.read_Rtps_Data())               
               {                          
                  ELOG(0,0,"\nError in reading RtpsSlConfigData.xml");
                  exit(0);                                    
               }
            }
            else
            {    
     printf("\n !!!!! Follow the Proper Steps  to Run !!!!!! \n");
     printf("\n 1.For All instance need 3 arguments  ---> ./DBINSERT ALL RtpsSlConfigData.xml\n");
     printf("\n 2.For INSTANCE specific need 7 arguments ---> ./DBINSERT INST RtpsSlConfigData.xml InstanceSpecSlConfigData.xml Entity_Name IP_Address Port_No\n");
               exit(0);
            }

         }

         if(0 == strcmp(argv[1], "INST"))
         {
            if(argc == 7)
            {
               g_ConObj.m_EntityName_DB = (string)argv[4];
               g_ConObj.m_IPAddress_DB = (string)argv[5];
               g_ConObj.m_IPPort_DB = (string)argv[6];
               g_ConObj.m_InstanceSp_DB = (string)argv[1];
               strcpy(g_ConObj.m_RtpsConfigName,argv[2]);
               strcpy(g_ConObj.m_InstanceConfigName,argv[3]);
               if(false == g_ConObj.init(g_ConObj.m_RtpsConfigName))  
               {
                  ELOG(0,0,"\n%s not Found",g_ConObj.m_RtpsConfigName);
                  exit(0);                                    
               }                                              
               if(false == g_ConObj.read_Rtps_Data1())               
               {                          
                  ELOG(0,0,"\nError in reading RtpsSlConfigData.xml");
                  exit(0);                                    
               }


            }
            else
           {
     printf("\n !!!!! Follow the Proper Steps  to Run !!!!!! \n");
     printf("\n 1.For All instance need 3 arguments  ---> ./DBINSERT ALL RtpsSlConfigData.xml\n");
     printf("\n 2.For INSTANCE specific need 7 arguments ---> ./DBINSERT INST RtpsSlConfigData.xml InstanceSpecSlConfigData.xml Entity_Name IP_Address Port_No\n");
                         exit(0);
            }
         }
      }
      else
      {
     printf("\n !!!!! Follow the Proper Steps  to Run !!!!!! \n");
     printf("\n 1.For All instance need 3 arguments  ---> ./DBINSERT ALL RtpsSlConfigData.xml\n");
     printf("\n 2.For INSTANCE specific need 7 arguments ---> ./DBINSERT INST RtpsSlConfigData.xml InstanceSpecSlConfigData.xml Entity_Name IP_Address Port_No\n");
         exit(0);
      }

         }
   else
   {
      if(g_ConObj.m_instanceType == 1)
      {
         printf("\n ####### HLR CONFIGURATION VALUES INSERTION FAILED ########\n");
         printf("\n !!!!! Follow the Proper Steps  to Run !!!!!! \n");
         printf("\n 1.For All instance need 1 arguments  ---> ./DBINSERT \n");
         printf("\n 2.For INSTANCE specific need 6 arguments ---> ./DBINSERT INST InstanceSpecificConfigurations.xml Entity_Name IP_Address Port_No\n");
      }
      else
      {
         printf("\n ####### RTPS CONFIGURATION VALUES INSERTION FAILED ########\n");
         printf("\n !!!!! Follow the Proper Steps  to Run !!!!!! \n");
         printf("\n 1.For All instance need 3 arguments  ---> ./DBINSERT ALL RtpsSlConfigData.xml\n");
         printf("\n 2.For INSTANCE specific need 7 arguments ---> ./DBINSERT INST RtpsSlConfigData.xml InstanceSpecSlConfigData.xml  Entity_Name IP_Address Port_No\n");
      }
      exit(0);
   }
   DbUpdate();
}

