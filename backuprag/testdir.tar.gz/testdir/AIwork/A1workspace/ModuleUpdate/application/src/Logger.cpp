#include <pthread.h>
#include "Logger.h"
#include "CurrentTime.h"
#include <sstream>
#include <string>
#include <iostream.h>

pthread_mutex_t      g_WriteLogMutex; //Only for CTDR Obj

bool g_NewFile=false;
char g_space[15+1];

 // definition for the global Logger object
Logger g_TraceObj; // definition for the global Trace object

#define MAX_FILENAME_LEN 1000

char g_title[2000];


void printLog(char *p_char)
{
   //printf("\n%s", p_char);
   DLOG(0,1,"%s", p_char);
}

Logger::Logger()
{
   m_LoggingThreshold	= 0;
   m_lrt=LOG_ROTATE_TYPE_FALSE;
}

Logger::~Logger()
{
}

void Logger::makeTimeStamp(char *p_DateTimeStamp)
{
   char * dateString=NULL;
   struct tm *tm_ptr=NULL;
   time_t l_tim =time(NULL);
   tm_ptr = localtime(&l_tim);
   dateString = asctime(tm_ptr);
   dateString[24] = 0;
   strcpy(p_DateTimeStamp, dateString);
   return;
}


int g_LogsExceededFlag=0;


void flushLog(Logger *p_log, char *p_data)
{
   printf("\nflushLog called\n");
   p_log->m_lw.writeLog(p_data, strlen(p_data));
   p_log->m_lw.writeLog("\n\n===Writing Buffer 0===\n\n", strlen("\n\n===Writing Buffer 0===\n\n"));
   p_log->m_lw.writeLog(p_log->m_lw.m_arr[0], p_log->m_lw.m_written_length[0]);
   p_log->m_lw.writeLog("\n\n===Writing Buffer 1===\n\n", strlen("\n\n===Writing Buffer 1===\n\n"));
   p_log->m_lw.writeLog(p_log->m_lw.m_arr[1], p_log->m_lw.m_written_length[1]);
}

void *logWriterFunc(void *p)
{
   LogWriter *l_lw = (LogWriter *)p;
   if (NULL == l_lw->m_arr[0])
   {
      printf("\nError in the array 0\n");
      exit(0);
   }

   if (NULL == l_lw->m_arr[1])
   {
      printf("\nError in the array 1\n");
      exit(0);
   }
   struct timeval l_tv;

   char start_message[50];
   memset(start_message, '\0', 50);
   strcpy(start_message, "");

   while (1)
   {
      //printf("\nT:%d calling select\n", pthread_self());
      if (g_LogsExceededFlag)
      {
         printf("\nT:%d log writer thread while\n", pthread_self());
      }
      l_tv.tv_sec = 1;
      l_tv.tv_usec = 0;
      select(0, (fd_set *)NULL, (fd_set *)NULL, (fd_set *)NULL, &l_tv);


      //if (false == g_core_signal_received) // This is the normal flow
      //
      {
         int l_ToBeLogged=-1;
         if (g_LogsExceededFlag)
         {
            printf("\nT:%d log writer trying to write log\n", pthread_self());
         }
         pthread_mutex_lock(&(l_lw->m_Mutex)); //lock
         l_ToBeLogged = l_lw->m_writing_index;
         l_lw->m_writing_index = (l_ToBeLogged+1)%2;
         if (NULL != l_lw->m_arr[l_lw->m_writing_index])
         {
            strcpy(l_lw->m_arr[l_lw->m_writing_index], start_message);
         }
         else
         {
            printf("\nSome error index[%d]\n", l_lw->m_writing_index);
         }

         l_lw->m_written_length[l_lw->m_writing_index] = strlen(start_message);
         pthread_mutex_unlock(&(l_lw->m_Mutex));	//unlock

         if (g_LogsExceededFlag)
         {
            printf("\nT:%d log writer written log %d \n", pthread_self(), l_lw->m_written_length[l_ToBeLogged]);
         }

         if (2 == l_lw->m_type)  //Added only for TDRs 
         {
            int l_length = l_lw->m_written_length[l_ToBeLogged];
            if (l_length > 0)  //Only if size greater than zero
            {
               /*if ( (3 == l_lw->m_LoggingMedia)  || (4 == l_lw->m_LoggingMedia))  //Both or Towards RTPS
               {
                  if (false == g_rtpsFullyDownFlag)
                  {
                     BufferData *l_bd = new BufferData;
                     l_bd->m_data = new unsigned char[l_length+1];
                     strncpy((char*)l_bd->m_data, l_lw->m_arr[l_ToBeLogged], l_length);
                     l_bd->m_data[l_length] = '\0';
                     l_bd->m_length = l_length+1;

                     //DLOG(0,1,"Pushing TDR data into queue");

                     l_lw->m_q->push((void*)l_bd);
                  }
                  else
                  {
                     TLOG(0,1,"Should dump directly into files Queue Size [%d]", l_lw->m_q->size());
                     if(l_lw->m_written_length[l_ToBeLogged] > strlen(start_message))
                     {
                        g_CriticalTdrObj.m_lw.writeLog(l_lw->m_arr[l_ToBeLogged], l_lw->m_written_length[l_ToBeLogged]);
                     }
                  }
               }
               else*/
               {
                  if(l_lw->m_written_length[l_ToBeLogged] > strlen(start_message))
                  {
                     l_lw->writeLog(l_lw->m_arr[l_ToBeLogged], l_lw->m_written_length[l_ToBeLogged]);
                  }
               }

            }
         }
         else //For logs or tracing push into files
         {
            if(l_lw->m_written_length[l_ToBeLogged] > strlen(start_message))
            {
               l_lw->writeLog(l_lw->m_arr[l_ToBeLogged], l_lw->m_written_length[l_ToBeLogged]);
            }
         }
      }
      /*else // Going to sleep so that logger thread will not log
      {
         pthread_mutex_unlock(&(l_lw->m_Mutex));	//unlock
         sleep(1000);
      }*/
   }
   return NULL;
}


int g=1;


bool Logger::initialize(unsigned long p_LoggingThreshold, unsigned long p_LoggingMedia, char * p_Path, char * mModuleName,
      char *p_FileSuffix, char * p_ArchivalDirPath, unsigned long mMaxFileSize, int p_type, ELogRotateType p_lrt, int p_maxFiles,
      int p_MaxLogDumpingSize)
{
   memset(g_title, '\0', sizeof(g_title));
   m_LoggingThreshold=p_LoggingThreshold;
   m_type = p_type;

   bool l_status = m_lw.initialize(p_LoggingMedia, p_Path, mModuleName, p_FileSuffix, p_ArchivalDirPath, mMaxFileSize, p_type,
         p_lrt, p_maxFiles, p_MaxLogDumpingSize);
   if (false == l_status)
   {
      printf("\nUnable to initialize the LogWriter\n");
      return false;
   }
   m_LoggingMedia=p_LoggingMedia;

   /*if(((2 != m_type) && ('B' == g_OtherConfigData->m_logFlag)) ||
         (2 == m_type))*/
   {
      pthread_t l_thread;
      pthread_create(&l_thread, NULL, logWriterFunc, &m_lw);
      sleep(1); //Just to ensure that the thread is created
   }
   m_initializedFlag=true;

   if(2 != m_type)
   {
      log2(LOG_LEVEL_CRITICAL, __FILE__, __FUNCTION__, __LINE__, 0,1, "Logging started");
   }
   else
   {
      char l_buff[2000];
      memset(l_buff, '\0', sizeof(l_buff));
      //g_tfb->prepareTitle(l_buff);
      log2(LOG_LEVEL_CRITICAL, __FILE__, __FUNCTION__, __LINE__, 1,1, l_buff);
      strcpy(g_title, l_buff);
   }

   sprintf(g_space, "%15s", " ");
   return true;
}


int countNewLines(char *p_buffer)
{
   int l_count=0;
   int l_buffer_len=strlen(p_buffer);
   for (int l_i=0; l_i<l_buffer_len; l_i++)
   {
      if ('\n' == p_buffer[l_i])
      {
         l_count++;
      }
   }
   return l_count;
}


char g_LogLevelChar[] = "UECWLTDU";

std::stringstream s;


int mysnprintf(char *p_dest, int p_max_size, char *p_format, ...)
{
   va_list args;
   args = 0;
   va_start(args, p_format);
   int l_return = vsnprintf(p_dest, p_max_size, p_format, args);
   va_end(args);
   return l_return;
}

bool Logger::log2(unsigned long p_LoggingLevel, const char *p_srcFileName, const char *p_funcName,
      int p_LineNumber, int p_LargeLogFlag, int p_NgOrApplFlag, char* p_LogMessage, ...)
{
   if (false == m_initializedFlag)
   {
      return false;
   }

   if (p_LoggingLevel>m_LoggingThreshold)
   {
      return false;
   }

   int l_currentThreadId = pthread_self();
   char l_dateString[25];  //memset not required since getCurrentTime is doing
   getCurrentTime(l_dateString);

   pthread_mutex_lock(&(m_lw.m_Mutex));

   int l_LOGGER_BUFFER_SIZE=1000;
   l_LOGGER_BUFFER_SIZE=LOGGER_BUFFER_SIZE;
   if(1 == p_LargeLogFlag)  
   {
      l_LOGGER_BUFFER_SIZE=LOGGER_BUFFER_SIZE;
   }


   if(NULL != p_srcFileName)
   {
      const char *l_StrIndex = strrchr(p_srcFileName, '/') ;
      if (NULL != l_StrIndex)
         p_srcFileName = ++l_StrIndex;
   }

   int l_logSize;// = strlen(m_LoggerBuffer);

   if(2 != m_type)  // apart from TDR object
   {
      char l_identityBuffer[25];
      ///-memset(l_identityBuffer, '\0', sizeof(l_identityBuffer));
      if (1 != l_currentThreadId)
      {
         strcpy(l_identityBuffer, g_space);
      }
      else
      {
         sprintf(l_identityBuffer, "%3s%3s:%08d", "mod-name", "msg-name", 1);
      }

      args = 0;
      va_start(args, p_LogMessage);
      vsnprintf(m_expandedLog, l_LOGGER_BUFFER_SIZE-200, p_LogMessage, args);
      va_end(args);


      l_logSize = snprintf(m_LoggerBuffer, l_LOGGER_BUFFER_SIZE, "%c|%s|%02d|%s|%s  |%s|%s|%d\n", 
            g_LogLevelChar[p_LoggingLevel], &l_dateString[4], l_currentThreadId, l_identityBuffer, m_expandedLog, 
            p_srcFileName, p_funcName, p_LineNumber);

      if ( (l_logSize > 1500) && (countNewLines(m_LoggerBuffer) < 10) )  // New lines are not present in the log
      {
         memset(m_tempLogChar, '\0', sizeof(m_tempLogChar));

         int l_i=0,l_j=0;
         for( ;l_i<l_logSize; l_i++,l_j++)
         {
            m_tempLogChar[l_j] = m_LoggerBuffer[l_i];
            if (0 == l_j%1000)
            {
               m_tempLogChar[++l_j] = '\n';
            }
         }
         m_tempLogChar[l_j] = '\n';

         strcpy(m_LoggerBuffer, m_tempLogChar);
         l_logSize= strlen(m_LoggerBuffer);
      }
   }
   else
   {
      args = 0;
      va_start(args, p_LogMessage);
      l_logSize = vsnprintf(m_LoggerBuffer, l_LOGGER_BUFFER_SIZE-200, p_LogMessage, args);
      va_end(args);
      m_LoggerBuffer[l_logSize] = '\n';
   }

   /*if(((2 != m_type) && ('B' == g_OtherConfigData->m_logFlag)) ||
         (2 == m_type))
   {
      if (MAX_DUMP_LOGGING_SIZE > (l_logSize+m_lw.m_written_length[m_lw.m_writing_index]))
      {
         strcpy(m_lw.m_arr[m_lw.m_writing_index]+m_lw.m_written_length[m_lw.m_writing_index], m_LoggerBuffer);
         m_lw.m_written_length[m_lw.m_writing_index]+= l_logSize;
      }
      else
      {
         printf("\nSevere Error!! Logs are lost\n\n ToBeWritten Size: %d", (l_logSize+m_lw.m_written_length[m_lw.m_writing_index]));
      }
   }
   else*/
   {
      //Immediate mode
      m_lw.writeLog(m_LoggerBuffer, l_logSize);
   }
   pthread_mutex_unlock(&(m_lw.m_Mutex));

   return true;
}

bool printHex(char *p_str, char *p_buf, int p_len, char *p_output)
{
   if(p_len > 300)
   {
      DLOG(0,0,"Length of the HEX_DATA is more than 300. [p_str:%s] [p_len:%d]",p_str, p_len);
      return false;
   }

   char lTemp[5];
   for(int j=0; j<p_len; j++)
   {
      snprintf(lTemp, 4, "%02x ", p_buf[j]&0x00ff);
      strcat(p_output,lTemp);
   }
   return true;
}

//////////////////////////////////////////////////////////////////

LogWriter::LogWriter()
{
   m_LoggingMedia		= 0;
   m_LoggerFileHandle	= 0;
   memset(m_ArchivalDirPath, '\0', sizeof(m_ArchivalDirPath));
   m_MaxFileSize		= 1000000;
   memset(m_FilePath, '\0', sizeof(m_FilePath));
   memset(m_ModuleName, '\0', sizeof(m_ModuleName));
   m_FileSize =0;
   memset(m_FileSuffix, '\0', sizeof(m_FileSuffix));
   m_lrt=LOG_ROTATE_TYPE_FALSE;
   m_currentFileCount=-1;
   m_arr[0]=NULL;
   m_arr[1]=NULL;
}

LogWriter::~LogWriter()
{
}

void LogWriter::makeFileName(char * mFileNameBuffer, char * p_Path, char * p_FilePrefix, char *p_FileSuffix)
{
   //printf("\nmakeFileName %d", m_lrt);
   if (LOG_ROTATE_TYPE_FALSE == m_lrt)
   {
      struct tm *tm_ptr=NULL;
      time_t l_tim =time(NULL);
      tm_ptr = localtime(&l_tim);
      m_currentFileCount=(++m_currentFileCount)%10000;
      sprintf(mFileNameBuffer, "%s/%s_%s%03d_%04u_%02u_%02u_%02u_%02u_%02u_%04d_P%05d.%s", 
            p_Path, p_FilePrefix, "entity", 1, 
            tm_ptr->tm_year+1900, tm_ptr->tm_mon+1, tm_ptr->tm_mday, tm_ptr->tm_hour, tm_ptr->tm_min, tm_ptr->tm_sec, m_currentFileCount, getpid(),
            p_FileSuffix);


      if((m_FilePath == NULL) ||(strcmp(p_Path, m_FilePath)==0))
      {
         strcpy(m_FileName,mFileNameBuffer);
      }
      return;
   }
   else
   {
      int l_currFile = 1 + (m_currentFileCount%m_maxFiles);
      m_currentFileCount = l_currFile;
      sprintf(mFileNameBuffer, "%s/%s_%s%03d_%06d.%s", p_Path, p_FilePrefix, "entity", 1, 
            m_currentFileCount, p_FileSuffix);
      if((m_FilePath == NULL) ||(strcmp(p_Path, m_FilePath)==0))
      {
         strcpy(m_FileName,mFileNameBuffer);
      }
      return;
   }
}

bool LogWriter::initialize(unsigned long p_LoggingMedia, char *p_Path, char *mModuleName, char *p_FileSuffix,
      char * p_ArchivalDirPath, unsigned long mMaxFileSize, int p_type, ELogRotateType p_lrt, int p_maxFiles,
      int p_MaxLogDumpingSize)
{
   if (p_MaxLogDumpingSize < 0)
   {
      printf("\nInvalid log dumping size: %d", p_MaxLogDumpingSize);
      return false;
   }

   m_arr[0] = NULL;
   m_arr[0] = new char[p_MaxLogDumpingSize+1];
   if (NULL == m_arr[0])
   {
      printf("\nUnable to allocate memory\n");
      return false;
   }

   m_arr[1] = new char[p_MaxLogDumpingSize+1];
   if (NULL == m_arr[1])
   {
      printf("\nUnable to allocate memory\n");
      return false;
   }

   m_maxFiles=p_maxFiles;
   m_currentFileCount=m_maxFiles;
   m_lrt = p_lrt;
   m_type = p_type;

   if (LOG_ROTATE_TYPE_FALSE == p_lrt)
   {
      m_currentFileCount=0;
   }


   strcpy(m_ArchivalDirPath, p_ArchivalDirPath);

   m_MaxFileSize = mMaxFileSize;
   strcpy(m_FilePath, p_Path);
   strcpy(m_ModuleName, mModuleName);
   strcpy(m_FileSuffix, p_FileSuffix);

   memset(m_arr[0], '\0', p_MaxLogDumpingSize);
   memset(m_arr[1], '\0', p_MaxLogDumpingSize);
   m_writing_index=0;

   pthread_mutex_init(&m_Mutex, NULL);
   if(0 == strcmp("ctdr", p_FileSuffix))
   {
      pthread_mutex_init(&g_WriteLogMutex, NULL);
   }

   char mFileNameBuffer[500];
   memset(mFileNameBuffer, '\0', 500);

   try
   {
      if((p_LoggingMedia < LOG_MEDIA_LOWER_LIMIT) || (p_LoggingMedia > LOG_MEDIA_UPPER_LIMIT) )
      {
         throw LOGGER_ERR_MODE;
      }
      else
         m_LoggingMedia = p_LoggingMedia;


      switch((int)m_LoggingMedia)
      {
         case LOG_MEDIA_FILE :	
            {
               if((!p_Path) || (!mModuleName) || (PATH_MAX_SIZE < (int)strlen(p_Path)) || (MODULE_NAME_MAX_SIZE < (int)strlen(mModuleName)) )
                  throw LOGGER_ERR_FILE;
               int retd;
               int iUmask = S_IWGRP | S_IWOTH;
               int iFileCreationMode = S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH; 
               int iFlags = O_WRONLY | O_CREAT | O_APPEND;
               int iOldUmask = umask(iUmask);
               retd = open(p_Path, O_RDONLY);
               if (retd == -1)			
               {
                  int iDirCreationMode = iFileCreationMode | S_IXUSR | S_IXGRP | S_IXOTH;
                  int p = mkdir(p_Path, iDirCreationMode);
                  if(p == -1) 
                  {
                     perror("Error in Creating Directory");
                     throw LOGGER_ERR_FILE;
                  }
               }

               if (LOG_ROTATE_TYPE_TRUE == p_lrt)
               {
                  char l_fileFormat[100];
                  memset(l_fileFormat, '\0', sizeof(l_fileFormat));
                  sprintf(l_fileFormat, "%s_%s%03d_*.log", m_ModuleName, "entity",1);


                  char l_lastFile[MAX_FILENAME_LEN+1];
                  memset(l_lastFile, '\0', sizeof(l_lastFile));
                  if (false == getLastFile(m_FilePath, l_fileFormat, l_lastFile))
                  {
                     printf("\nError in getting the last file in the directory [%s]\n", m_FilePath);
                     return false;
                  }

                  if (strlen(l_lastFile) > 2)
                  {
                     printf("\nLast File found is [%s]\n", l_lastFile);
                     char l_formatString[200];
                     memset(l_formatString, '\0', sizeof(l_formatString));
                     sprintf(l_formatString, "%s_%s%03d_%s.log", m_ModuleName, "entity",1, "%6s");

                     char l_countChar[6+1];
                     memset(l_countChar, '\0', sizeof(l_countChar));

                     int l_count=0;

                     sscanf(l_lastFile, l_formatString, l_countChar);

                     bool l_numeric=true;
                     for (int l_i=0; l_i<strlen(l_countChar); l_i++)
                     {
                        if ( (l_countChar[l_i] < '0') || (l_countChar[l_i] > '9'))
                        {
                           l_numeric=false;
                           break;
                        }
                     }

                     if (true == l_numeric)
                     {
                        l_count = atoi(l_countChar);
                        if (l_count < 1  || l_count > 999999)
                        {
                           printf("\nInvalid count char [%s]", l_countChar);
                        }
                        else
                        {
                           m_currentFileCount=l_count;
                           printf("\nLast Sequence Number is %d\n", l_count);
                        }
                     }
                     else
                     {
                        printf("\nCount is not numeric [%s]\n", l_countChar);
                     }
                  }
                  else
                  {
                     printf("\nNot retrieved a previous sequence number. Assuming first startup.\n");
                  }
               }

               makeFileName(&mFileNameBuffer[0], m_FilePath, m_ModuleName, p_FileSuffix);

               // The actual permission will be iFileCreationMode & ~iUmask
               m_LoggerFileHandle = open(mFileNameBuffer, iFlags, iFileCreationMode);

               // If unable to open the file than throw error
               if(m_LoggerFileHandle == -1)
               {
                  throw LOGGER_ERR_FILE;
               }

               // Restore the original umask value.
               umask(iOldUmask);
            }
            break;

         default:
            break;
      } // end switch


   }
   catch (int err_code) 
   {
      m_LoggingMedia	= 0;

      switch (err_code)
      {
         case LOGGER_ERR_FILE :			// File path is not correct
            printf("\nERROR!!! Exception occurred");
            m_LoggerFileHandle		= 0;
            break;
         case LOGGER_ERR_BUFFER :		// Insufficient memory
            break;
         default:		// ERROR
            break;
      } //end of switch 
   }

   /*m_q = new MessageQueue(QUEUE_TYPE_NON_BLOCKING, QUEUE_PERSISTENCE_TYPE_NON_PERSISTENT);
   bool l_status = m_q->initialize();
   if (false == l_status)
   {
      printf("\nUnable to initialize the Logger Queue");
      return false;
   }*/

   return true;
}



bool LogWriter::writeLog(char *p_message, int p_bytesToBeWritten)
{
   bool l_locked=false;
   if( 
         (2 == m_type) && 
         (0 == strcmp("ctdr", m_FileSuffix))
     )//Only TDR shall do writeLog from two different threads
   {
      //printf("\nLocking g_WriteLogMutex\n");
      pthread_mutex_lock(&g_WriteLogMutex); //lock
      l_locked=true;
   }
   //printf("\n writeLog :%d CurrentFileSize:%d\n", p_bytesToBeWritten, m_FileSize);
   switch (m_LoggingMedia)
   {
      case LOG_MEDIA_FILE :		
         {
            //printf("\n  %d %d ", m_FileSize, m_MaxFileSize);
            if(m_FileSize >= m_MaxFileSize)
            {
               char mFileNameBuffer[500];
               memset(mFileNameBuffer, '\0', sizeof(mFileNameBuffer));
               close(m_LoggerFileHandle);

               rename(m_FileName,mFileNameBuffer);
               makeFileName(&mFileNameBuffer[0],m_FilePath,m_ModuleName, m_FileSuffix);

               m_LoggerFileHandle = creat(mFileNameBuffer,O_CREAT|O_RDWR);
               chmod(m_FileName,0644);
               if(m_LoggerFileHandle == -1) 
               {
                  printf("\ncreat command failed\n");
                  if(true == l_locked)
                  {
                     printf("\nunlocking\n");
                     pthread_mutex_lock(&g_WriteLogMutex); //added upon suspicion that this might have caused the application hanged
                  }
                  return false;
               }
               else // Point to end of the file
               {
                  lseek(m_LoggerFileHandle,0,SEEK_END);
               }
               m_FileSize=0;

               if(2 == m_type) // For writing the TDR Header
               {
                  write(m_LoggerFileHandle, g_title, strlen(g_title));
               }

               g_NewFile=true;
            }

            int l_bytesWritten = write(m_LoggerFileHandle, p_message, p_bytesToBeWritten);

            if(l_bytesWritten == p_bytesToBeWritten)
            {
               m_FileSize+=l_bytesWritten;
               g_LogsExceededFlag=0;
            }
            else
            {
               if(-1 == l_bytesWritten)
               {
                  if(EINTR == errno)
                  {
                     printf("\nwrite call is interrupted while logging [%s]\n", p_message);
                  }
                  else
                  {
                     printf("\nCRITICAL!! Check the Disk Space !!! errno:%d, strerr:%s\n", errno, strerror(errno));
                     g_LogsExceededFlag=1;
                  }
               }
               else
               {
                  printf("\nCRITICAL!! Able to log only %d bytes out of %d bytes", l_bytesWritten, p_bytesToBeWritten);
                  g_LogsExceededFlag=1;
                  m_FileSize+=l_bytesWritten;
               }
            }
         }
         break;

      case LOG_MEDIA_CONSOLE :
         {
            printf("%s", p_message);
         }
         break;

      default:
         {
            printf("\nDefault case");
         }
         break;
   };


   if( 
         (2 == m_type) && 
         (0 == strcmp("ctdr", m_FileSuffix))
     )//Only TDR shall do writeLog from two different threads
   {
      pthread_mutex_unlock(&g_WriteLogMutex); //lock
   }

   return true;
}


bool LogWriter::getLastFile(char* p_DirName, char *p_fileFormat, char* p_LastFileName)
{
   char l_command[1000];
   memset(l_command, '\0', sizeof(l_command));

   sprintf(l_command, "cd %s; ls -tr %s | tail -1", p_DirName, p_fileFormat);
   printf("\nCommand [%s]\n", l_command);

   FILE *fp;
   fp = popen(l_command, "r");
   if (fp == NULL)
   {
      ELOG(0,1, "Failed to get last file name");
      return false;
   }

   fgets(p_LastFileName, MAX_FILENAME_LEN, fp);
   pclose(fp);
   return true;
}
