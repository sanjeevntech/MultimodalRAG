
/* Result Sets Interface */
#ifndef SQL_CRSR
#  define SQL_CRSR
  struct sql_cursor
  {
    unsigned int curocn;
    void *ptr1;
    void *ptr2;
    unsigned int magic;
  };
  typedef struct sql_cursor sql_cursor;
  typedef struct sql_cursor SQL_CURSOR;
#endif /* SQL_CRSR */

/* Thread Safety */
typedef void * sql_context;
typedef void * SQL_CONTEXT;

/* Object support */
struct sqltvn
{
  unsigned char *tvnvsn; 
  unsigned short tvnvsnl; 
  unsigned char *tvnnm;
  unsigned short tvnnml; 
  unsigned char *tvnsnm;
  unsigned short tvnsnml;
};
typedef struct sqltvn sqltvn;

struct sqladts
{
  unsigned int adtvsn; 
  unsigned short adtmode; 
  unsigned short adtnum;  
  sqltvn adttvn[1];       
};
typedef struct sqladts sqladts;

static struct sqladts sqladt = {
  1,1,0,
};

/* Binding to PL/SQL Records */
struct sqltdss
{
  unsigned int tdsvsn; 
  unsigned short tdsnum; 
  unsigned char *tdsval[1]; 
};
typedef struct sqltdss sqltdss;
static struct sqltdss sqltds =
{
  1,
  0,
};

/* File name & Package Name */
struct sqlcxp
{
  unsigned short fillen;
           char  filnam[16];
};
static const struct sqlcxp sqlfpn =
{
    15,
    "DbInsertProc.pc"
};


static unsigned int sqlctx = 2275555;


static struct sqlexd {
   unsigned long  sqlvsn;
   unsigned int   arrsiz;
   unsigned int   iters;
   unsigned int   offset;
   unsigned short selerr;
   unsigned short sqlety;
   unsigned int   occurs;
      const short *cud;
   unsigned char  *sqlest;
      const char  *stmt;
   sqladts *sqladtp;
   sqltdss *sqltdsp;
   unsigned char  **sqphsv;
   unsigned long  *sqphsl;
            int   *sqphss;
            short **sqpind;
            int   *sqpins;
   unsigned long  *sqparm;
   unsigned long  **sqparc;
   unsigned short  *sqpadto;
   unsigned short  *sqptdso;
   unsigned int   sqlcmax;
   unsigned int   sqlcmin;
   unsigned int   sqlcincr;
   unsigned int   sqlctimeout;
   unsigned int   sqlcnowait;
            int   sqfoff;
   unsigned int   sqcmod;
   unsigned int   sqfmod;
   unsigned char  *sqhstv[8];
   unsigned long  sqhstl[8];
            int   sqhsts[8];
            short *sqindv[8];
            int   sqinds[8];
   unsigned long  sqharm[8];
   unsigned long  *sqharc[8];
   unsigned short  sqadto[8];
   unsigned short  sqtdso[8];
} sqlstm = {12,8};

// Prototypes
extern "C" {
  void sqlcxt (void **, unsigned int *,
               struct sqlexd *, const struct sqlcxp *);
  void sqlcx2t(void **, unsigned int *,
               struct sqlexd *, const struct sqlcxp *);
  void sqlbuft(void **, char *);
  void sqlgs2t(void **, char *);
  void sqlorat(void **, unsigned int *, void *);
}

// Forms Interface
static const int IAPSUCC = 0;
static const int IAPFAIL = 1403;
static const int IAPFTL  = 535;
extern "C" { void sqliem(char *, int *); }

 static const char *sq0003 = 
"select PARAM_ID ,MODULE_ID ,PARAM_SHORT_NAME ,PARAM_TYPE  from HLR_CONFIG_PA\
RAMS where INSTANCE_TYPE=:b0           ";

 static const char *sq0012 = 
"select PARAM_ID ,MODULE_ID ,PARAM_SHORT_NAME ,PARAM_TYPE  from HLR_CONFIG_PA\
RAMS where INSTANCE_TYPE=:b0           ";

typedef struct { unsigned short len; unsigned char arr[1]; } VARCHAR;
typedef struct { unsigned short len; unsigned char arr[1]; } varchar;

/* cud (compilation unit data) array */
static const short sqlcud0[] =
{12,4130,1,0,0,
5,0,0,1,0,0,27,101,0,0,4,4,0,1,0,1,97,0,0,1,10,0,0,1,10,0,0,1,10,0,0,
36,0,0,2,73,0,4,106,0,0,2,1,0,1,0,2,3,0,0,1,3,0,0,
59,0,0,3,115,0,9,111,0,0,1,1,0,1,0,1,3,0,0,
78,0,0,4,72,0,4,144,0,0,2,1,0,1,0,2,3,0,0,1,97,0,0,
101,0,0,5,95,0,4,185,0,0,3,2,0,1,0,2,3,0,0,1,97,0,0,1,3,0,0,
128,0,0,6,123,0,2,187,0,0,4,4,0,1,0,1,97,0,0,1,97,0,0,1,3,0,0,1,3,0,0,
159,0,0,7,216,0,3,197,0,0,7,7,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,97,0,0,1,97,0,
0,1,9,0,0,1,3,0,0,
202,0,0,8,0,0,29,204,0,0,0,0,0,1,0,
217,0,0,9,72,0,4,240,0,0,2,1,0,1,0,2,3,0,0,1,97,0,0,
240,0,0,10,120,0,4,277,0,0,4,3,0,1,0,2,3,0,0,1,3,0,0,1,3,0,0,1,97,0,0,
271,0,0,11,73,0,4,341,0,0,2,1,0,1,0,2,3,0,0,1,3,0,0,
294,0,0,12,115,0,9,350,0,0,1,1,0,1,0,1,3,0,0,
313,0,0,12,0,0,13,362,0,0,4,0,0,1,0,2,3,0,0,2,3,0,0,2,9,0,0,2,9,0,0,
344,0,0,13,123,0,2,420,0,0,4,4,0,1,0,1,97,0,0,1,97,0,0,1,3,0,0,1,3,0,0,
375,0,0,14,216,0,3,424,0,0,7,7,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,97,0,0,1,97,0,
0,1,9,0,0,1,3,0,0,
418,0,0,15,0,0,29,432,0,0,0,0,0,1,0,
433,0,0,16,123,0,2,439,0,0,4,4,0,1,0,1,97,0,0,1,97,0,0,1,3,0,0,1,3,0,0,
464,0,0,17,135,0,2,442,0,0,4,4,0,1,0,1,97,0,0,1,97,0,0,1,3,0,0,1,3,0,0,
495,0,0,18,73,0,4,454,0,0,2,1,0,1,0,2,3,0,0,1,3,0,0,
518,0,0,19,55,0,2,459,0,0,1,1,0,1,0,1,3,0,0,
537,0,0,12,115,0,9,463,0,0,1,1,0,1,0,1,3,0,0,
556,0,0,12,0,0,13,475,0,0,4,0,0,1,0,2,3,0,0,2,3,0,0,2,9,0,0,2,9,0,0,
587,0,0,20,206,0,3,506,0,0,3,3,0,1,0,1,3,0,0,1,9,0,0,1,3,0,0,
614,0,0,21,216,0,3,516,0,0,7,7,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,97,0,0,1,97,0,
0,1,9,0,0,1,3,0,0,
657,0,0,22,0,0,29,525,0,0,0,0,0,1,0,
672,0,0,23,67,0,2,531,0,0,1,1,0,1,0,1,3,0,0,
691,0,0,24,73,0,4,557,0,0,2,1,0,1,0,2,3,0,0,1,3,0,0,
714,0,0,25,50,0,4,564,0,0,1,0,0,1,0,2,3,0,0,
733,0,0,26,259,0,3,687,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,0,
0,1,97,0,0,1,9,0,0,1,3,0,0,
780,0,0,27,200,0,3,696,0,0,6,6,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,97,0,0,1,9,0,
0,1,3,0,0,
819,0,0,28,0,0,29,699,0,0,0,0,0,1,0,
834,0,0,29,259,0,3,722,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,0,
0,1,97,0,0,1,9,0,0,1,3,0,0,
881,0,0,30,200,0,3,728,0,0,6,6,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,97,0,0,1,9,0,
0,1,3,0,0,
920,0,0,31,0,0,29,730,0,0,0,0,0,1,0,
935,0,0,32,259,0,3,802,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,0,
0,1,97,0,0,1,9,0,0,1,3,0,0,
982,0,0,33,259,0,3,806,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,0,
0,1,97,0,0,1,9,0,0,1,3,0,0,
1029,0,0,34,200,0,3,811,0,0,6,6,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,97,0,0,1,9,0,
0,1,3,0,0,
1068,0,0,35,0,0,29,813,0,0,0,0,0,1,0,
1083,0,0,36,243,0,3,825,0,0,7,7,0,1,0,1,97,0,0,1,3,0,0,1,3,0,0,1,97,0,0,1,97,0,
0,1,9,0,0,1,3,0,0,
1126,0,0,37,259,0,3,850,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,0,
0,1,97,0,0,1,9,0,0,1,3,0,0,
1173,0,0,38,200,0,3,856,0,0,6,6,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,97,0,0,1,9,0,
0,1,3,0,0,
1212,0,0,39,0,0,29,858,0,0,0,0,0,1,0,
1227,0,0,40,259,0,3,894,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,0,
0,1,97,0,0,1,9,0,0,1,3,0,0,
1274,0,0,41,259,0,3,897,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,0,
0,1,97,0,0,1,9,0,0,1,3,0,0,
1321,0,0,42,200,0,3,903,0,0,6,6,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,97,0,0,1,9,0,
0,1,3,0,0,
1360,0,0,43,0,0,29,906,0,0,0,0,0,1,0,
1375,0,0,44,243,0,3,918,0,0,7,7,0,1,0,1,97,0,0,1,3,0,0,1,3,0,0,1,97,0,0,1,97,0,
0,1,9,0,0,1,3,0,0,
1418,0,0,45,259,0,3,943,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,0,
0,1,97,0,0,1,9,0,0,1,3,0,0,
1465,0,0,46,200,0,3,949,0,0,6,6,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,97,0,0,1,9,0,
0,1,3,0,0,
1504,0,0,47,0,0,29,952,0,0,0,0,0,1,0,
1519,0,0,48,259,0,3,1019,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,
0,0,1,97,0,0,1,9,0,0,1,3,0,0,
1566,0,0,49,260,0,3,1025,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,
0,0,1,97,0,0,1,9,0,0,1,3,0,0,
1613,0,0,50,200,0,3,1034,0,0,6,6,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,97,0,0,1,9,
0,0,1,3,0,0,
1652,0,0,51,0,0,29,1037,0,0,0,0,0,1,0,
1667,0,0,52,244,0,3,1058,0,0,7,7,0,1,0,1,97,0,0,1,3,0,0,1,3,0,0,1,97,0,0,1,97,
0,0,1,9,0,0,1,3,0,0,
1710,0,0,53,260,0,3,1090,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,
0,0,1,97,0,0,1,9,0,0,1,3,0,0,
1757,0,0,54,200,0,3,1100,0,0,6,6,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,97,0,0,1,9,
0,0,1,3,0,0,
1796,0,0,55,0,0,29,1105,0,0,0,0,0,1,0,
1811,0,0,56,244,0,3,1126,0,0,7,7,0,1,0,1,97,0,0,1,3,0,0,1,3,0,0,1,97,0,0,1,97,
0,0,1,9,0,0,1,3,0,0,
1854,0,0,57,260,0,3,1157,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,
0,0,1,97,0,0,1,9,0,0,1,3,0,0,
1901,0,0,58,200,0,3,1167,0,0,6,6,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,97,0,0,1,9,
0,0,1,3,0,0,
1940,0,0,59,0,0,29,1169,0,0,0,0,0,1,0,
1955,0,0,60,260,0,3,1226,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,
0,0,1,97,0,0,1,9,0,0,1,3,0,0,
2002,0,0,61,260,0,3,1234,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,
0,0,1,97,0,0,1,9,0,0,1,3,0,0,
2049,0,0,62,200,0,3,1239,0,0,6,6,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,97,0,0,1,9,
0,0,1,3,0,0,
2088,0,0,63,0,0,29,1241,0,0,0,0,0,1,0,
2103,0,0,64,244,0,3,1253,0,0,7,7,0,1,0,1,97,0,0,1,3,0,0,1,3,0,0,1,97,0,0,1,97,
0,0,1,9,0,0,1,3,0,0,
2146,0,0,65,260,0,3,1279,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,
0,0,1,97,0,0,1,9,0,0,1,3,0,0,
2193,0,0,66,200,0,3,1285,0,0,6,6,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,97,0,0,1,9,
0,0,1,3,0,0,
2232,0,0,67,0,0,29,1288,0,0,0,0,0,1,0,
2247,0,0,68,260,0,3,1323,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,
0,0,1,97,0,0,1,9,0,0,1,3,0,0,
2294,0,0,69,260,0,3,1326,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,
0,0,1,97,0,0,1,9,0,0,1,3,0,0,
2341,0,0,70,200,0,3,1332,0,0,6,6,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,97,0,0,1,9,
0,0,1,3,0,0,
2380,0,0,71,0,0,29,1335,0,0,0,0,0,1,0,
2395,0,0,72,260,0,3,1409,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,
0,0,1,97,0,0,1,9,0,0,1,3,0,0,
2442,0,0,73,260,0,3,1411,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,
0,0,1,97,0,0,1,9,0,0,1,3,0,0,
2489,0,0,74,200,0,3,1418,0,0,6,6,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,97,0,0,1,9,
0,0,1,3,0,0,
2528,0,0,75,0,0,29,1421,0,0,0,0,0,1,0,
2543,0,0,76,260,0,3,1450,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,
0,0,1,97,0,0,1,9,0,0,1,3,0,0,
2590,0,0,77,260,0,3,1453,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,
0,0,1,97,0,0,1,9,0,0,1,3,0,0,
2637,0,0,78,200,0,3,1458,0,0,6,6,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,97,0,0,1,9,
0,0,1,3,0,0,
2676,0,0,79,0,0,29,1461,0,0,0,0,0,1,0,
2691,0,0,80,244,0,3,1473,0,0,7,7,0,1,0,1,97,0,0,1,3,0,0,1,3,0,0,1,97,0,0,1,97,
0,0,1,9,0,0,1,3,0,0,
2734,0,0,81,260,0,3,1499,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,
0,0,1,97,0,0,1,9,0,0,1,3,0,0,
2781,0,0,82,200,0,3,1505,0,0,6,6,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,97,0,0,1,9,
0,0,1,3,0,0,
2820,0,0,83,0,0,29,1508,0,0,0,0,0,1,0,
2835,0,0,84,260,0,3,1544,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,
0,0,1,97,0,0,1,9,0,0,1,3,0,0,
2882,0,0,85,260,0,3,1547,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,
0,0,1,97,0,0,1,9,0,0,1,3,0,0,
2929,0,0,86,200,0,3,1553,0,0,6,6,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,97,0,0,1,9,
0,0,1,3,0,0,
2968,0,0,87,0,0,29,1556,0,0,0,0,0,1,0,
2983,0,0,88,260,0,3,1624,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,
0,0,1,97,0,0,1,9,0,0,1,3,0,0,
3030,0,0,89,260,0,3,1626,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,
0,0,1,97,0,0,1,9,0,0,1,3,0,0,
3077,0,0,90,200,0,3,1633,0,0,6,6,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,97,0,0,1,9,
0,0,1,3,0,0,
3116,0,0,91,0,0,29,1636,0,0,0,0,0,1,0,
3131,0,0,92,244,0,3,1649,0,0,7,7,0,1,0,1,97,0,0,1,3,0,0,1,3,0,0,1,97,0,0,1,97,
0,0,1,9,0,0,1,3,0,0,
3174,0,0,93,260,0,3,1675,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,
0,0,1,97,0,0,1,9,0,0,1,3,0,0,
3221,0,0,94,200,0,3,1681,0,0,6,6,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,97,0,0,1,9,
0,0,1,3,0,0,
3260,0,0,95,0,0,29,1684,0,0,0,0,0,1,0,
3275,0,0,96,260,0,3,1756,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,
0,0,1,97,0,0,1,9,0,0,1,3,0,0,
3322,0,0,97,260,0,3,1761,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,
0,0,1,97,0,0,1,9,0,0,1,3,0,0,
3369,0,0,98,260,0,3,1767,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,
0,0,1,97,0,0,1,9,0,0,1,3,0,0,
3416,0,0,99,244,0,3,1769,0,0,7,7,0,1,0,1,97,0,0,1,3,0,0,1,3,0,0,1,97,0,0,1,97,
0,0,1,9,0,0,1,3,0,0,
3459,0,0,100,260,0,3,1774,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,
0,0,1,97,0,0,1,9,0,0,1,3,0,0,
3506,0,0,101,260,0,3,1777,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,
0,0,1,97,0,0,1,9,0,0,1,3,0,0,
3553,0,0,102,260,0,3,1780,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,
0,0,1,97,0,0,1,9,0,0,1,3,0,0,
3600,0,0,103,260,0,3,1783,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,
0,0,1,97,0,0,1,9,0,0,1,3,0,0,
3647,0,0,104,260,0,3,1786,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,
0,0,1,97,0,0,1,9,0,0,1,3,0,0,
3694,0,0,105,200,0,3,1791,0,0,6,6,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,97,0,0,1,9,
0,0,1,3,0,0,
3733,0,0,106,0,0,29,1794,0,0,0,0,0,1,0,
3748,0,0,107,244,0,3,1808,0,0,7,7,0,1,0,1,97,0,0,1,3,0,0,1,3,0,0,1,97,0,0,1,97,
0,0,1,9,0,0,1,3,0,0,
3791,0,0,108,260,0,3,1834,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,
0,0,1,97,0,0,1,9,0,0,1,3,0,0,
3838,0,0,109,200,0,3,1840,0,0,6,6,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,97,0,0,1,9,
0,0,1,3,0,0,
3877,0,0,110,0,0,29,1843,0,0,0,0,0,1,0,
3892,0,0,111,260,0,3,1879,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,
0,0,1,97,0,0,1,9,0,0,1,3,0,0,
3939,0,0,112,260,0,3,1882,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,
0,0,1,97,0,0,1,9,0,0,1,3,0,0,
3986,0,0,113,200,0,3,1888,0,0,6,6,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,97,0,0,1,9,
0,0,1,3,0,0,
4025,0,0,114,0,0,29,1891,0,0,0,0,0,1,0,
4040,0,0,115,244,0,3,1904,0,0,7,7,0,1,0,1,97,0,0,1,3,0,0,1,3,0,0,1,97,0,0,1,97,
0,0,1,9,0,0,1,3,0,0,
4083,0,0,116,260,0,3,1931,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,
0,0,1,97,0,0,1,9,0,0,1,3,0,0,
4130,0,0,117,200,0,3,1937,0,0,6,6,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,97,0,0,1,9,
0,0,1,3,0,0,
4169,0,0,118,0,0,29,1940,0,0,0,0,0,1,0,
4184,0,0,119,244,0,3,1953,0,0,7,7,0,1,0,1,97,0,0,1,3,0,0,1,3,0,0,1,97,0,0,1,97,
0,0,1,9,0,0,1,3,0,0,
4227,0,0,120,260,0,3,1968,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,
0,0,1,97,0,0,1,9,0,0,1,3,0,0,
4274,0,0,121,200,0,3,1974,0,0,6,6,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,97,0,0,1,9,
0,0,1,3,0,0,
4313,0,0,122,0,0,29,1977,0,0,0,0,0,1,0,
4328,0,0,123,244,0,3,1989,0,0,7,7,0,1,0,1,97,0,0,1,3,0,0,1,3,0,0,1,97,0,0,1,97,
0,0,1,9,0,0,1,3,0,0,
4371,0,0,124,260,0,3,2003,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,
0,0,1,97,0,0,1,9,0,0,1,3,0,0,
4418,0,0,125,200,0,3,2009,0,0,6,6,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,97,0,0,1,9,
0,0,1,3,0,0,
4457,0,0,126,0,0,29,2012,0,0,0,0,0,1,0,
4472,0,0,127,244,0,3,2024,0,0,7,7,0,1,0,1,97,0,0,1,3,0,0,1,3,0,0,1,97,0,0,1,97,
0,0,1,9,0,0,1,3,0,0,
4515,0,0,128,260,0,3,2038,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,
0,0,1,97,0,0,1,9,0,0,1,3,0,0,
4562,0,0,129,200,0,3,2044,0,0,6,6,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,97,0,0,1,9,
0,0,1,3,0,0,
4601,0,0,130,0,0,29,2047,0,0,0,0,0,1,0,
4616,0,0,131,244,0,3,2060,0,0,7,7,0,1,0,1,97,0,0,1,3,0,0,1,3,0,0,1,97,0,0,1,97,
0,0,1,9,0,0,1,3,0,0,
4659,0,0,132,260,0,3,2086,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,
0,0,1,97,0,0,1,9,0,0,1,3,0,0,
4706,0,0,133,200,0,3,2092,0,0,6,6,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,97,0,0,1,9,
0,0,1,3,0,0,
4745,0,0,134,0,0,29,2095,0,0,0,0,0,1,0,
4760,0,0,135,244,0,3,2108,0,0,7,7,0,1,0,1,97,0,0,1,3,0,0,1,3,0,0,1,97,0,0,1,97,
0,0,1,9,0,0,1,3,0,0,
4803,0,0,136,260,0,3,2134,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,
0,0,1,97,0,0,1,9,0,0,1,3,0,0,
4850,0,0,137,200,0,3,2141,0,0,6,6,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,97,0,0,1,9,
0,0,1,3,0,0,
4889,0,0,138,0,0,29,2144,0,0,0,0,0,1,0,
4904,0,0,139,244,0,3,2157,0,0,7,7,0,1,0,1,97,0,0,1,3,0,0,1,3,0,0,1,97,0,0,1,97,
0,0,1,9,0,0,1,3,0,0,
4947,0,0,140,260,0,3,2182,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,
0,0,1,97,0,0,1,9,0,0,1,3,0,0,
4994,0,0,141,200,0,3,2188,0,0,6,6,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,97,0,0,1,9,
0,0,1,3,0,0,
5033,0,0,142,0,0,29,2191,0,0,0,0,0,1,0,
5048,0,0,143,244,0,3,2204,0,0,7,7,0,1,0,1,97,0,0,1,3,0,0,1,3,0,0,1,97,0,0,1,97,
0,0,1,9,0,0,1,3,0,0,
5091,0,0,144,260,0,3,2229,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,
0,0,1,97,0,0,1,9,0,0,1,3,0,0,
5138,0,0,145,200,0,3,2235,0,0,6,6,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,97,0,0,1,9,
0,0,1,3,0,0,
5177,0,0,146,0,0,29,2238,0,0,0,0,0,1,0,
5192,0,0,147,244,0,3,2251,0,0,7,7,0,1,0,1,97,0,0,1,3,0,0,1,3,0,0,1,97,0,0,1,97,
0,0,1,9,0,0,1,3,0,0,
5235,0,0,148,260,0,3,2277,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,
0,0,1,97,0,0,1,9,0,0,1,3,0,0,
5282,0,0,149,200,0,3,2283,0,0,6,6,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,97,0,0,1,9,
0,0,1,3,0,0,
5321,0,0,150,0,0,29,2286,0,0,0,0,0,1,0,
5336,0,0,151,260,0,3,2312,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,
0,0,1,97,0,0,1,9,0,0,1,3,0,0,
5383,0,0,152,260,0,3,2324,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,
0,0,1,97,0,0,1,9,0,0,1,3,0,0,
5430,0,0,153,200,0,3,2330,0,0,6,6,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,97,0,0,1,9,
0,0,1,3,0,0,
5469,0,0,154,0,0,29,2333,0,0,0,0,0,1,0,
5484,0,0,155,244,0,3,2346,0,0,7,7,0,1,0,1,97,0,0,1,3,0,0,1,3,0,0,1,97,0,0,1,97,
0,0,1,9,0,0,1,3,0,0,
5527,0,0,156,260,0,3,2372,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,
0,0,1,97,0,0,1,9,0,0,1,3,0,0,
5574,0,0,157,200,0,3,2378,0,0,6,6,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,97,0,0,1,9,
0,0,1,3,0,0,
5613,0,0,158,0,0,29,2381,0,0,0,0,0,1,0,
5628,0,0,159,260,0,3,2450,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,
0,0,1,97,0,0,1,9,0,0,1,3,0,0,
5675,0,0,160,260,0,3,2455,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,
0,0,1,97,0,0,1,9,0,0,1,3,0,0,
5722,0,0,161,260,0,3,2465,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,
0,0,1,97,0,0,1,9,0,0,1,3,0,0,
5769,0,0,162,260,0,3,2475,0,0,8,8,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,
0,0,1,97,0,0,1,9,0,0,1,3,0,0,
5816,0,0,163,200,0,3,2483,0,0,6,6,0,1,0,1,97,0,0,1,3,0,0,1,97,0,0,1,97,0,0,1,9,
0,0,1,3,0,0,
5855,0,0,164,0,0,29,2486,0,0,0,0,0,1,0,
};


#include <stdio.h>
#include <string.h>
#include <iostream>
#include <time.h>
#include "ConfigReader.h"
#include "parser.h"
#include <stdlib.h>
#include <Logger.h>
#include <list>
#include <map>

using namespace std;

extern ConfigReader g_ConObj;
extern void PrintDbLog(int,string,string);
extern char g_dbAlias[];
int DbUpdate();
static int g_COUNT_VAL;
void DbComplexUpdate(int);
map<int,string>complexMap;
/* EXEC SQL INCLUDE SQLCA;
 */ 
/*
 * $Header: sqlca.h 24-apr-2003.12:50:58 mkandarp Exp $ sqlca.h 
 */

/* Copyright (c) 1985, 2003, Oracle Corporation.  All rights reserved.  */
 
/*
NAME
  SQLCA : SQL Communications Area.
FUNCTION
  Contains no code. Oracle fills in the SQLCA with status info
  during the execution of a SQL stmt.
NOTES
  **************************************************************
  ***                                                        ***
  *** This file is SOSD.  Porters must change the data types ***
  *** appropriately on their platform.  See notes/pcport.doc ***
  *** for more information.                                  ***
  ***                                                        ***
  **************************************************************

  If the symbol SQLCA_STORAGE_CLASS is defined, then the SQLCA
  will be defined to have this storage class. For example:
 
    #define SQLCA_STORAGE_CLASS extern
 
  will define the SQLCA as an extern.
 
  If the symbol SQLCA_INIT is defined, then the SQLCA will be
  statically initialized. Although this is not necessary in order
  to use the SQLCA, it is a good pgming practice not to have
  unitialized variables. However, some C compilers/OS's don't
  allow automatic variables to be init'd in this manner. Therefore,
  if you are INCLUDE'ing the SQLCA in a place where it would be
  an automatic AND your C compiler/OS doesn't allow this style
  of initialization, then SQLCA_INIT should be left undefined --
  all others can define SQLCA_INIT if they wish.

  If the symbol SQLCA_NONE is defined, then the SQLCA variable will
  not be defined at all.  The symbol SQLCA_NONE should not be defined
  in source modules that have embedded SQL.  However, source modules
  that have no embedded SQL, but need to manipulate a sqlca struct
  passed in as a parameter, can set the SQLCA_NONE symbol to avoid
  creation of an extraneous sqlca variable.
 
MODIFIED
    lvbcheng   07/31/98 -  long to int
    jbasu      12/12/94 -  Bug 217878: note this is an SOSD file
    losborne   08/11/92 -  No sqlca var if SQLCA_NONE macro set 
  Clare      12/06/84 - Ch SQLCA to not be an extern.
  Clare      10/21/85 - Add initialization.
  Bradbury   01/05/86 - Only initialize when SQLCA_INIT set
  Clare      06/12/86 - Add SQLCA_STORAGE_CLASS option.
*/
 
#ifndef SQLCA
#define SQLCA 1
 
struct   sqlca
         {
         /* ub1 */ char    sqlcaid[8];
         /* b4  */ int     sqlabc;
         /* b4  */ int     sqlcode;
         struct
           {
           /* ub2 */ unsigned short sqlerrml;
           /* ub1 */ char           sqlerrmc[70];
           } sqlerrm;
         /* ub1 */ char    sqlerrp[8];
         /* b4  */ int     sqlerrd[6];
         /* ub1 */ char    sqlwarn[8];
         /* ub1 */ char    sqlext[8];
         };

#ifndef SQLCA_NONE 
#ifdef   SQLCA_STORAGE_CLASS
SQLCA_STORAGE_CLASS struct sqlca sqlca
#else
         struct sqlca sqlca
#endif
 
#ifdef  SQLCA_INIT
         = {
         {'S', 'Q', 'L', 'C', 'A', ' ', ' ', ' '},
         sizeof(struct sqlca),
         0,
         { 0, {0}},
         {'N', 'O', 'T', ' ', 'S', 'E', 'T', ' '},
         {0, 0, 0, 0, 0, 0},
         {0, 0, 0, 0, 0, 0, 0, 0},
         {0, 0, 0, 0, 0, 0, 0, 0}
         }
#endif
         ;
#endif
 
#endif
 
/* end SQLCA */


/* EXEC SQL BEGIN DECLARE SECTION; */ 


/* VARCHAR CharTime[100]; */ 
struct { unsigned short len; unsigned char arr[100]; } CharTime;

char Value[100000];
int Param_ID;
int Module_ID;
char Param_Short_Name1[100];
/* VARCHAR Param_Short_Name[100]; */ 
struct { unsigned short len; unsigned char arr[100]; } Param_Short_Name;

/* VARCHAR Param_Type[100]; */ 
struct { unsigned short len; unsigned char arr[100]; } Param_Type;

int Count;
static int Count_Val;
char username[20];
char password[20];
char dbstring[20];
char full[200+1];
char IPaddress[20];
char ProvPort[10];
char InstanceSp[20];
char EntityName[20];
int  InstanceType;
char ModuleName[30];
int Param_Count;
int Sequence_ID;
int Sub_ID;

/* EXEC SQL END DECLARE SECTION; */ 





char l_ProvPort[10];
char l_CharTime[100];
time_t timer;
struct tm *timeStruct;
int l_Param_ID;
int l_Module_ID;
char l_Param_Short_Name[500];
char l_Param_Type[100];
int l_count;
int l_Count_Val;
int l_Param_Count;
int l_Param_Count1;

int DbUpdate()
{

   DLOG(0,0,"INSERTION STARTED"); 


   strcpy(full,g_dbAlias);

   time(&timer);
   timeStruct = localtime( &timer );
   memset(l_CharTime, '\0', sizeof(l_CharTime));
   memset(CharTime.arr,'\0',sizeof(CharTime.arr));
   strftime(l_CharTime, 25, "%m/%d/%Y %H:%M:%S",timeStruct );
   CharTime.len = strlen(l_CharTime);

   strcpy((char *)CharTime.arr,(char *)l_CharTime);

   strcpy(IPaddress,g_ConObj.m_IPAddress_DB.c_str());

   strcpy(ProvPort,g_ConObj.m_IPPort_DB.c_str());

   strcpy(InstanceSp,g_ConObj.m_InstanceSp_DB.c_str());

   strcpy(EntityName,g_ConObj.m_EntityName_DB.c_str()); 

   InstanceType = g_ConObj.m_instanceType; 

   Param_ID = 0;

   Module_ID = 0;

   /* EXEC SQL WHENEVER SQLERROR GOTO sqlerr; */ 

   try
   {

      /* EXEC SQL CONNECT :full; */ 

{
      struct sqlexd sqlstm;
      sqlstm.sqlvsn = 12;
      sqlstm.arrsiz = 4;
      sqlstm.sqladtp = &sqladt;
      sqlstm.sqltdsp = &sqltds;
      sqlstm.iters = (unsigned int  )10;
      sqlstm.offset = (unsigned int  )5;
      sqlstm.cud = sqlcud0;
      sqlstm.sqlest = (unsigned char  *)&sqlca;
      sqlstm.sqlety = (unsigned short)256;
      sqlstm.occurs = (unsigned int  )0;
      sqlstm.sqhstv[0] = (unsigned char  *)full;
      sqlstm.sqhstl[0] = (unsigned long )201;
      sqlstm.sqhsts[0] = (         int  )201;
      sqlstm.sqindv[0] = (         short *)0;
      sqlstm.sqinds[0] = (         int  )0;
      sqlstm.sqharm[0] = (unsigned long )0;
      sqlstm.sqadto[0] = (unsigned short )0;
      sqlstm.sqtdso[0] = (unsigned short )0;
      sqlstm.sqphsv = sqlstm.sqhstv;
      sqlstm.sqphsl = sqlstm.sqhstl;
      sqlstm.sqphss = sqlstm.sqhsts;
      sqlstm.sqpind = sqlstm.sqindv;
      sqlstm.sqpins = sqlstm.sqinds;
      sqlstm.sqparm = sqlstm.sqharm;
      sqlstm.sqparc = sqlstm.sqharc;
      sqlstm.sqpadto = sqlstm.sqadto;
      sqlstm.sqptdso = sqlstm.sqtdso;
      sqlstm.sqlcmax = (unsigned int )100;
      sqlstm.sqlcmin = (unsigned int )2;
      sqlstm.sqlcincr = (unsigned int )1;
      sqlstm.sqlctimeout = (unsigned int )0;
      sqlstm.sqlcnowait = (unsigned int )0;
      sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
      if (sqlca.sqlcode < 0) goto sqlerr;
}


      if((0 == strcmp(g_ConObj.m_InstanceSp_DB.c_str(),"INST")) && InstanceType == 1 )

      {
         Count = 0;
         /* EXEC SQL SELECT COUNT(*)INTO :Count FROM HLR_CONFIG_PARAMS WHERE INSTANCE_TYPE = :InstanceType ; */ 

{
         struct sqlexd sqlstm;
         sqlstm.sqlvsn = 12;
         sqlstm.arrsiz = 4;
         sqlstm.sqladtp = &sqladt;
         sqlstm.sqltdsp = &sqltds;
         sqlstm.stmt = "select count(*)  into :b0  from HLR_CONFIG_PARAMS wh\
ere INSTANCE_TYPE=:b1";
         sqlstm.iters = (unsigned int  )1;
         sqlstm.offset = (unsigned int  )36;
         sqlstm.selerr = (unsigned short)1;
         sqlstm.cud = sqlcud0;
         sqlstm.sqlest = (unsigned char  *)&sqlca;
         sqlstm.sqlety = (unsigned short)256;
         sqlstm.occurs = (unsigned int  )0;
         sqlstm.sqhstv[0] = (unsigned char  *)&Count;
         sqlstm.sqhstl[0] = (unsigned long )sizeof(int);
         sqlstm.sqhsts[0] = (         int  )0;
         sqlstm.sqindv[0] = (         short *)0;
         sqlstm.sqinds[0] = (         int  )0;
         sqlstm.sqharm[0] = (unsigned long )0;
         sqlstm.sqadto[0] = (unsigned short )0;
         sqlstm.sqtdso[0] = (unsigned short )0;
         sqlstm.sqhstv[1] = (unsigned char  *)&InstanceType;
         sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
         sqlstm.sqhsts[1] = (         int  )0;
         sqlstm.sqindv[1] = (         short *)0;
         sqlstm.sqinds[1] = (         int  )0;
         sqlstm.sqharm[1] = (unsigned long )0;
         sqlstm.sqadto[1] = (unsigned short )0;
         sqlstm.sqtdso[1] = (unsigned short )0;
         sqlstm.sqphsv = sqlstm.sqhstv;
         sqlstm.sqphsl = sqlstm.sqhstl;
         sqlstm.sqphss = sqlstm.sqhsts;
         sqlstm.sqpind = sqlstm.sqindv;
         sqlstm.sqpins = sqlstm.sqinds;
         sqlstm.sqparm = sqlstm.sqharm;
         sqlstm.sqparc = sqlstm.sqharc;
         sqlstm.sqpadto = sqlstm.sqadto;
         sqlstm.sqptdso = sqlstm.sqtdso;
         sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
         if (sqlca.sqlcode < 0) goto sqlerr;
}


         l_count=Count;

         /* EXEC SQL DECLARE Params_cursor1 CURSOR FOR  SELECT PARAM_ID,MODULE_ID,PARAM_SHORT_NAME,PARAM_TYPE FROM HLR_CONFIG_PARAMS WHERE INSTANCE_TYPE = :InstanceType ; */ 


         /* EXEC SQL OPEN Params_cursor1; */ 

{
         struct sqlexd sqlstm;
         sqlstm.sqlvsn = 12;
         sqlstm.arrsiz = 4;
         sqlstm.sqladtp = &sqladt;
         sqlstm.sqltdsp = &sqltds;
         sqlstm.stmt = sq0003;
         sqlstm.iters = (unsigned int  )1;
         sqlstm.offset = (unsigned int  )59;
         sqlstm.selerr = (unsigned short)1;
         sqlstm.cud = sqlcud0;
         sqlstm.sqlest = (unsigned char  *)&sqlca;
         sqlstm.sqlety = (unsigned short)256;
         sqlstm.occurs = (unsigned int  )0;
         sqlstm.sqcmod = (unsigned int )0;
         sqlstm.sqhstv[0] = (unsigned char  *)&InstanceType;
         sqlstm.sqhstl[0] = (unsigned long )sizeof(int);
         sqlstm.sqhsts[0] = (         int  )0;
         sqlstm.sqindv[0] = (         short *)0;
         sqlstm.sqinds[0] = (         int  )0;
         sqlstm.sqharm[0] = (unsigned long )0;
         sqlstm.sqadto[0] = (unsigned short )0;
         sqlstm.sqtdso[0] = (unsigned short )0;
         sqlstm.sqphsv = sqlstm.sqhstv;
         sqlstm.sqphsl = sqlstm.sqhstl;
         sqlstm.sqphss = sqlstm.sqhsts;
         sqlstm.sqpind = sqlstm.sqindv;
         sqlstm.sqpins = sqlstm.sqinds;
         sqlstm.sqparm = sqlstm.sqharm;
         sqlstm.sqparc = sqlstm.sqharc;
         sqlstm.sqpadto = sqlstm.sqadto;
         sqlstm.sqptdso = sqlstm.sqtdso;
         sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
         if (sqlca.sqlcode < 0) goto sqlerr;
}





         if(false == g_ConObj.init(g_ConObj.m_InstanceConfigName))       
         {
            ELOG(0,0,"\n%s not Found",g_ConObj.m_InstanceConfigName);
            exit(0);                                    
         } 

         list <string > l_InstanceList;

         l_InstanceList =  Parser::getAllValues(g_ConObj.m_DataString,"MODULE" );

         if( 0 == l_InstanceList.size() )
         {
            ELOG(0,0,"InstanceSpecificConfigurations.xml tag not properly Configured");
         }

         list <string> :: iterator l_ListIter;
         for( l_ListIter = l_InstanceList.begin(); l_ListIter !=  l_InstanceList.end(); l_ListIter++ )
         {

            string l_ModuleName = Parser::getValue( (*l_ListIter),"NAME");
            if(0 == l_ModuleName.size())
            {
               ELOG(0,0,"<NAME> TAG NOT FOUND in InstanceSpecificConfigurations.xml");
            }
            else
            {
               strcpy(ModuleName,l_ModuleName.c_str());


               /* EXEC SQL SELECT MODULE_ID INTO :Module_ID FROM HLR_CONFIG_MODULES WHERE MODULE_NAME = :ModuleName  ; */ 

{
               struct sqlexd sqlstm;
               sqlstm.sqlvsn = 12;
               sqlstm.arrsiz = 4;
               sqlstm.sqladtp = &sqladt;
               sqlstm.sqltdsp = &sqltds;
               sqlstm.stmt = "select MODULE_ID into :b0  from HLR_CONFIG_MOD\
ULES where MODULE_NAME=:b1";
               sqlstm.iters = (unsigned int  )1;
               sqlstm.offset = (unsigned int  )78;
               sqlstm.selerr = (unsigned short)1;
               sqlstm.cud = sqlcud0;
               sqlstm.sqlest = (unsigned char  *)&sqlca;
               sqlstm.sqlety = (unsigned short)256;
               sqlstm.occurs = (unsigned int  )0;
               sqlstm.sqhstv[0] = (unsigned char  *)&Module_ID;
               sqlstm.sqhstl[0] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[0] = (         int  )0;
               sqlstm.sqindv[0] = (         short *)0;
               sqlstm.sqinds[0] = (         int  )0;
               sqlstm.sqharm[0] = (unsigned long )0;
               sqlstm.sqadto[0] = (unsigned short )0;
               sqlstm.sqtdso[0] = (unsigned short )0;
               sqlstm.sqhstv[1] = (unsigned char  *)ModuleName;
               sqlstm.sqhstl[1] = (unsigned long )30;
               sqlstm.sqhsts[1] = (         int  )0;
               sqlstm.sqindv[1] = (         short *)0;
               sqlstm.sqinds[1] = (         int  )0;
               sqlstm.sqharm[1] = (unsigned long )0;
               sqlstm.sqadto[1] = (unsigned short )0;
               sqlstm.sqtdso[1] = (unsigned short )0;
               sqlstm.sqphsv = sqlstm.sqhstv;
               sqlstm.sqphsl = sqlstm.sqhstl;
               sqlstm.sqphss = sqlstm.sqhsts;
               sqlstm.sqpind = sqlstm.sqindv;
               sqlstm.sqpins = sqlstm.sqinds;
               sqlstm.sqparm = sqlstm.sqharm;
               sqlstm.sqparc = sqlstm.sqharc;
               sqlstm.sqpadto = sqlstm.sqadto;
               sqlstm.sqptdso = sqlstm.sqtdso;
               sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
               if (sqlca.sqlcode < 0) goto sqlerr;
}




               l_Module_ID = Module_ID;


               string ModuleXml  =  (string)g_ConObj.m_ModuleMap.find(l_Module_ID)->second;

               string l_Tags = Parser::getValue( (*l_ListIter),"TAGS");

               if(0 == l_Tags.size())
               {
                  ELOG(0,0,"<TAGS> NOT FOUND in InstanceSpecificConfigurations.xml");
               }
               else
               {
                  list <string>l_TagsList;

                  l_TagsList = Parser::getAllValues(l_Tags,"TAG");

                  if( 0 == l_TagsList.size() )
                  {
                     ELOG(0,0,"<TAG> tag not found in  Configure File");
                  }
                  list <string> :: iterator l_ListIter;
                  for( l_ListIter = l_TagsList.begin(); l_ListIter !=  l_TagsList.end(); l_ListIter++ )
                  {

                     strcpy(Param_Short_Name1,(*l_ListIter).c_str());

                     string l_Value_INST  = Parser::getValue(ModuleXml, (*l_ListIter));

                     if(0 == l_Value_INST.size())
                     {
                        ELOG(0,0,"Given <TAG> tag NOT FOUND in InstanceSpecificConfigurations.xml");
                        exit(0);
                     }
                     else
                     {
                        strcpy(Param_Short_Name1,(*l_ListIter).c_str());

                        /* EXEC SQL SELECT PARAM_ID INTO :Param_ID FROM HLR_CONFIG_PARAMS WHERE PARAM_SHORT_NAME = :Param_Short_Name1 AND  MODULE_ID = :Module_ID ; */ 

{
                        struct sqlexd sqlstm;
                        sqlstm.sqlvsn = 12;
                        sqlstm.arrsiz = 4;
                        sqlstm.sqladtp = &sqladt;
                        sqlstm.sqltdsp = &sqltds;
                        sqlstm.stmt = "select PARAM_ID into :b0  from HLR_CO\
NFIG_PARAMS where (PARAM_SHORT_NAME=:b1 and MODULE_ID=:b2)";
                        sqlstm.iters = (unsigned int  )1;
                        sqlstm.offset = (unsigned int  )101;
                        sqlstm.selerr = (unsigned short)1;
                        sqlstm.cud = sqlcud0;
                        sqlstm.sqlest = (unsigned char  *)&sqlca;
                        sqlstm.sqlety = (unsigned short)256;
                        sqlstm.occurs = (unsigned int  )0;
                        sqlstm.sqhstv[0] = (unsigned char  *)&Param_ID;
                        sqlstm.sqhstl[0] = (unsigned long )sizeof(int);
                        sqlstm.sqhsts[0] = (         int  )0;
                        sqlstm.sqindv[0] = (         short *)0;
                        sqlstm.sqinds[0] = (         int  )0;
                        sqlstm.sqharm[0] = (unsigned long )0;
                        sqlstm.sqadto[0] = (unsigned short )0;
                        sqlstm.sqtdso[0] = (unsigned short )0;
                        sqlstm.sqhstv[1] = (unsigned char  *)Param_Short_Name1;
                        sqlstm.sqhstl[1] = (unsigned long )100;
                        sqlstm.sqhsts[1] = (         int  )0;
                        sqlstm.sqindv[1] = (         short *)0;
                        sqlstm.sqinds[1] = (         int  )0;
                        sqlstm.sqharm[1] = (unsigned long )0;
                        sqlstm.sqadto[1] = (unsigned short )0;
                        sqlstm.sqtdso[1] = (unsigned short )0;
                        sqlstm.sqhstv[2] = (unsigned char  *)&Module_ID;
                        sqlstm.sqhstl[2] = (unsigned long )sizeof(int);
                        sqlstm.sqhsts[2] = (         int  )0;
                        sqlstm.sqindv[2] = (         short *)0;
                        sqlstm.sqinds[2] = (         int  )0;
                        sqlstm.sqharm[2] = (unsigned long )0;
                        sqlstm.sqadto[2] = (unsigned short )0;
                        sqlstm.sqtdso[2] = (unsigned short )0;
                        sqlstm.sqphsv = sqlstm.sqhstv;
                        sqlstm.sqphsl = sqlstm.sqhstl;
                        sqlstm.sqphss = sqlstm.sqhsts;
                        sqlstm.sqpind = sqlstm.sqindv;
                        sqlstm.sqpins = sqlstm.sqinds;
                        sqlstm.sqparm = sqlstm.sqharm;
                        sqlstm.sqparc = sqlstm.sqharc;
                        sqlstm.sqpadto = sqlstm.sqadto;
                        sqlstm.sqptdso = sqlstm.sqtdso;
                        sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
                        if (sqlca.sqlcode < 0) goto sqlerr;
}



                        /* EXEC SQL DELETE  FROM HLR_CONFIG_VALUES WHERE  IP_ADDRESS = :IPaddress AND PROVISIONING_PORT =:ProvPort AND INSTANCE_TYPE = :InstanceType AND PARAM_ID = :Param_ID ; */ 

{
                        struct sqlexd sqlstm;
                        sqlstm.sqlvsn = 12;
                        sqlstm.arrsiz = 4;
                        sqlstm.sqladtp = &sqladt;
                        sqlstm.sqltdsp = &sqltds;
                        sqlstm.stmt = "delete  from HLR_CONFIG_VALUES  where\
 (((IP_ADDRESS=:b0 and PROVISIONING_PORT=:b1) and INSTANCE_TYPE=:b2) and PARAM\
_ID=:b3)";
                        sqlstm.iters = (unsigned int  )1;
                        sqlstm.offset = (unsigned int  )128;
                        sqlstm.cud = sqlcud0;
                        sqlstm.sqlest = (unsigned char  *)&sqlca;
                        sqlstm.sqlety = (unsigned short)256;
                        sqlstm.occurs = (unsigned int  )0;
                        sqlstm.sqhstv[0] = (unsigned char  *)IPaddress;
                        sqlstm.sqhstl[0] = (unsigned long )20;
                        sqlstm.sqhsts[0] = (         int  )0;
                        sqlstm.sqindv[0] = (         short *)0;
                        sqlstm.sqinds[0] = (         int  )0;
                        sqlstm.sqharm[0] = (unsigned long )0;
                        sqlstm.sqadto[0] = (unsigned short )0;
                        sqlstm.sqtdso[0] = (unsigned short )0;
                        sqlstm.sqhstv[1] = (unsigned char  *)ProvPort;
                        sqlstm.sqhstl[1] = (unsigned long )10;
                        sqlstm.sqhsts[1] = (         int  )0;
                        sqlstm.sqindv[1] = (         short *)0;
                        sqlstm.sqinds[1] = (         int  )0;
                        sqlstm.sqharm[1] = (unsigned long )0;
                        sqlstm.sqadto[1] = (unsigned short )0;
                        sqlstm.sqtdso[1] = (unsigned short )0;
                        sqlstm.sqhstv[2] = (unsigned char  *)&InstanceType;
                        sqlstm.sqhstl[2] = (unsigned long )sizeof(int);
                        sqlstm.sqhsts[2] = (         int  )0;
                        sqlstm.sqindv[2] = (         short *)0;
                        sqlstm.sqinds[2] = (         int  )0;
                        sqlstm.sqharm[2] = (unsigned long )0;
                        sqlstm.sqadto[2] = (unsigned short )0;
                        sqlstm.sqtdso[2] = (unsigned short )0;
                        sqlstm.sqhstv[3] = (unsigned char  *)&Param_ID;
                        sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
                        sqlstm.sqhsts[3] = (         int  )0;
                        sqlstm.sqindv[3] = (         short *)0;
                        sqlstm.sqinds[3] = (         int  )0;
                        sqlstm.sqharm[3] = (unsigned long )0;
                        sqlstm.sqadto[3] = (unsigned short )0;
                        sqlstm.sqtdso[3] = (unsigned short )0;
                        sqlstm.sqphsv = sqlstm.sqhstv;
                        sqlstm.sqphsl = sqlstm.sqhstl;
                        sqlstm.sqphss = sqlstm.sqhsts;
                        sqlstm.sqpind = sqlstm.sqindv;
                        sqlstm.sqpins = sqlstm.sqinds;
                        sqlstm.sqparm = sqlstm.sqharm;
                        sqlstm.sqparc = sqlstm.sqharc;
                        sqlstm.sqpadto = sqlstm.sqadto;
                        sqlstm.sqptdso = sqlstm.sqtdso;
                        sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
                        if (sqlca.sqlcode < 0) goto sqlerr;
}

  

                        l_Param_ID = Param_ID;

                        strcpy(Value,l_Value_INST.c_str());  

               DLOG(0,0,"PARAM_ID - [%d] PARAM_NAME - [%s] PARAM_VALUE - [%s] INSTANCE [HLR] INSTANCE_NAME[%s]",l_Param_ID,Param_Short_Name1,l_Value_INST.c_str(),g_ConObj.m_EntityName_DB.c_str());
 

             //           DLOG(0,0,"PARAM_ID - %d,PARAM_VALUE - %s ",l_Param_ID,l_Value_INST.c_str());
                        /* EXEC SQL INSERT INTO HLR_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,PARAM_VALUE,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,:Value,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
                        struct sqlexd sqlstm;
                        sqlstm.sqlvsn = 12;
                        sqlstm.arrsiz = 7;
                        sqlstm.sqladtp = &sqladt;
                        sqlstm.sqltdsp = &sqltds;
                        sqlstm.stmt = "insert into HLR_CONFIG_VALUES (ENTITY\
_NAME,PARAM_ID,PARAM_VALUE,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_U\
PDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,:b2,:b3,:b4,'OS',to_date(:b5,'mm/dd\
/yyyy hh24:mi:ss'),:b6)";
                        sqlstm.iters = (unsigned int  )1;
                        sqlstm.offset = (unsigned int  )159;
                        sqlstm.cud = sqlcud0;
                        sqlstm.sqlest = (unsigned char  *)&sqlca;
                        sqlstm.sqlety = (unsigned short)256;
                        sqlstm.occurs = (unsigned int  )0;
                        sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
                        sqlstm.sqhstl[0] = (unsigned long )20;
                        sqlstm.sqhsts[0] = (         int  )0;
                        sqlstm.sqindv[0] = (         short *)0;
                        sqlstm.sqinds[0] = (         int  )0;
                        sqlstm.sqharm[0] = (unsigned long )0;
                        sqlstm.sqadto[0] = (unsigned short )0;
                        sqlstm.sqtdso[0] = (unsigned short )0;
                        sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
                        sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
                        sqlstm.sqhsts[1] = (         int  )0;
                        sqlstm.sqindv[1] = (         short *)0;
                        sqlstm.sqinds[1] = (         int  )0;
                        sqlstm.sqharm[1] = (unsigned long )0;
                        sqlstm.sqadto[1] = (unsigned short )0;
                        sqlstm.sqtdso[1] = (unsigned short )0;
                        sqlstm.sqhstv[2] = (unsigned char  *)Value;
                        sqlstm.sqhstl[2] = (unsigned long )100000;
                        sqlstm.sqhsts[2] = (         int  )0;
                        sqlstm.sqindv[2] = (         short *)0;
                        sqlstm.sqinds[2] = (         int  )0;
                        sqlstm.sqharm[2] = (unsigned long )0;
                        sqlstm.sqadto[2] = (unsigned short )0;
                        sqlstm.sqtdso[2] = (unsigned short )0;
                        sqlstm.sqhstv[3] = (unsigned char  *)IPaddress;
                        sqlstm.sqhstl[3] = (unsigned long )20;
                        sqlstm.sqhsts[3] = (         int  )0;
                        sqlstm.sqindv[3] = (         short *)0;
                        sqlstm.sqinds[3] = (         int  )0;
                        sqlstm.sqharm[3] = (unsigned long )0;
                        sqlstm.sqadto[3] = (unsigned short )0;
                        sqlstm.sqtdso[3] = (unsigned short )0;
                        sqlstm.sqhstv[4] = (unsigned char  *)ProvPort;
                        sqlstm.sqhstl[4] = (unsigned long )10;
                        sqlstm.sqhsts[4] = (         int  )0;
                        sqlstm.sqindv[4] = (         short *)0;
                        sqlstm.sqinds[4] = (         int  )0;
                        sqlstm.sqharm[4] = (unsigned long )0;
                        sqlstm.sqadto[4] = (unsigned short )0;
                        sqlstm.sqtdso[4] = (unsigned short )0;
                        sqlstm.sqhstv[5] = (unsigned char  *)&CharTime;
                        sqlstm.sqhstl[5] = (unsigned long )102;
                        sqlstm.sqhsts[5] = (         int  )0;
                        sqlstm.sqindv[5] = (         short *)0;
                        sqlstm.sqinds[5] = (         int  )0;
                        sqlstm.sqharm[5] = (unsigned long )0;
                        sqlstm.sqadto[5] = (unsigned short )0;
                        sqlstm.sqtdso[5] = (unsigned short )0;
                        sqlstm.sqhstv[6] = (unsigned char  *)&InstanceType;
                        sqlstm.sqhstl[6] = (unsigned long )sizeof(int);
                        sqlstm.sqhsts[6] = (         int  )0;
                        sqlstm.sqindv[6] = (         short *)0;
                        sqlstm.sqinds[6] = (         int  )0;
                        sqlstm.sqharm[6] = (unsigned long )0;
                        sqlstm.sqadto[6] = (unsigned short )0;
                        sqlstm.sqtdso[6] = (unsigned short )0;
                        sqlstm.sqphsv = sqlstm.sqhstv;
                        sqlstm.sqphsl = sqlstm.sqhstl;
                        sqlstm.sqphss = sqlstm.sqhsts;
                        sqlstm.sqpind = sqlstm.sqindv;
                        sqlstm.sqpins = sqlstm.sqinds;
                        sqlstm.sqparm = sqlstm.sqharm;
                        sqlstm.sqparc = sqlstm.sqharc;
                        sqlstm.sqpadto = sqlstm.sqadto;
                        sqlstm.sqptdso = sqlstm.sqtdso;
                        sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
                        if (sqlca.sqlcode < 0) goto sqlerr;
}


                     }

                  }                                       
               }
            }
         }
         /* EXEC SQL COMMIT; */ 

{
         struct sqlexd sqlstm;
         sqlstm.sqlvsn = 12;
         sqlstm.arrsiz = 7;
         sqlstm.sqladtp = &sqladt;
         sqlstm.sqltdsp = &sqltds;
         sqlstm.iters = (unsigned int  )1;
         sqlstm.offset = (unsigned int  )202;
         sqlstm.cud = sqlcud0;
         sqlstm.sqlest = (unsigned char  *)&sqlca;
         sqlstm.sqlety = (unsigned short)256;
         sqlstm.occurs = (unsigned int  )0;
         sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
         if (sqlca.sqlcode < 0) goto sqlerr;
}


      }

      else if( (0 == strcmp(g_ConObj.m_InstanceSp_DB.c_str(),"INST")) && InstanceType == 2)
      {

         if(false == g_ConObj.init(g_ConObj.m_InstanceConfigName))       
         {
            ELOG(0,0,"\n%s not Found",g_ConObj.m_InstanceConfigName);
            exit(0);                                    
         } 

         list <string > l_InstanceList;

         l_InstanceList =  Parser::getAllValues(g_ConObj.m_DataString,"MODULE" );

         if( 0 == l_InstanceList.size() )
         {
            ELOG(0,0,"InstanceSpecificConfigurations.xml tag not properly Configured");
         }
         list <string> :: iterator l_ListIter1;     
         string l_NewXml;
         for( l_ListIter1 = l_InstanceList.begin(); l_ListIter1 !=  l_InstanceList.end(); l_ListIter1++ )
         {

            string l_ModuleName = Parser::getValue( (*l_ListIter1),"NAME");

            if(0 == l_ModuleName.size())
            {
               ELOG(0,0,"<NAME> TAG NOT FOUND in InstanceSpecificConfigurations.xml");
            }
            else
            {

               strcpy(ModuleName,l_ModuleName.c_str());

               /* EXEC SQL SELECT MODULE_ID INTO :Module_ID FROM HLR_CONFIG_MODULES WHERE MODULE_NAME = :ModuleName  ; */ 

{
               struct sqlexd sqlstm;
               sqlstm.sqlvsn = 12;
               sqlstm.arrsiz = 7;
               sqlstm.sqladtp = &sqladt;
               sqlstm.sqltdsp = &sqltds;
               sqlstm.stmt = "select MODULE_ID into :b0  from HLR_CONFIG_MOD\
ULES where MODULE_NAME=:b1";
               sqlstm.iters = (unsigned int  )1;
               sqlstm.offset = (unsigned int  )217;
               sqlstm.selerr = (unsigned short)1;
               sqlstm.cud = sqlcud0;
               sqlstm.sqlest = (unsigned char  *)&sqlca;
               sqlstm.sqlety = (unsigned short)256;
               sqlstm.occurs = (unsigned int  )0;
               sqlstm.sqhstv[0] = (unsigned char  *)&Module_ID;
               sqlstm.sqhstl[0] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[0] = (         int  )0;
               sqlstm.sqindv[0] = (         short *)0;
               sqlstm.sqinds[0] = (         int  )0;
               sqlstm.sqharm[0] = (unsigned long )0;
               sqlstm.sqadto[0] = (unsigned short )0;
               sqlstm.sqtdso[0] = (unsigned short )0;
               sqlstm.sqhstv[1] = (unsigned char  *)ModuleName;
               sqlstm.sqhstl[1] = (unsigned long )30;
               sqlstm.sqhsts[1] = (         int  )0;
               sqlstm.sqindv[1] = (         short *)0;
               sqlstm.sqinds[1] = (         int  )0;
               sqlstm.sqharm[1] = (unsigned long )0;
               sqlstm.sqadto[1] = (unsigned short )0;
               sqlstm.sqtdso[1] = (unsigned short )0;
               sqlstm.sqphsv = sqlstm.sqhstv;
               sqlstm.sqphsl = sqlstm.sqhstl;
               sqlstm.sqphss = sqlstm.sqhsts;
               sqlstm.sqpind = sqlstm.sqindv;
               sqlstm.sqpins = sqlstm.sqinds;
               sqlstm.sqparm = sqlstm.sqharm;
               sqlstm.sqparc = sqlstm.sqharc;
               sqlstm.sqpadto = sqlstm.sqadto;
               sqlstm.sqptdso = sqlstm.sqtdso;
               sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
               if (sqlca.sqlcode < 0) goto sqlerr;
}



               l_Module_ID = Module_ID;

               string ModuleXml  =  (string)g_ConObj.m_ModuleMap.find(l_Module_ID)->second;

               string l_Tags = Parser::getValue( (*l_ListIter1),"TAGS");
               l_NewXml = l_NewXml  + "<" + l_ModuleName  + ">";
               if(0 == l_Tags.size())
               {
                  ELOG(0,0,"<TAGS> NOT FOUND in InstanceSpecificConfigurations.xml");
                  string l_Value_INST = ModuleXml;
                  l_NewXml = l_NewXml + l_Value_INST;

               }
               else
               {
                  list <string>l_TagsList;

                  l_TagsList = Parser::getAllValues(l_Tags,"TAG");

                  if( 0 == l_TagsList.size() )
                  {
                     ELOG(0,0,"<TAG> tag not found in  Configure File");
                  }

                  list <string> :: iterator l_ListIter;

                  //    l_NewXml = l_NewXml  + "<" + l_ModuleName  + ">";

                  for( l_ListIter = l_TagsList.begin(); l_ListIter !=  l_TagsList.end(); l_ListIter++ )
                  {  

                     Count = 0;
                     strcpy((char *)Param_Short_Name1,(*l_ListIter).c_str());

                     
                     /* EXEC SQL SELECT COUNT(*) INTO :Count FROM HLR_CONFIG_PARAMS WHERE INSTANCE_TYPE = :InstanceType AND MODULE_ID =  :Module_ID AND PARAM_SHORT_NAME = :Param_Short_Name1; */ 

{
                     struct sqlexd sqlstm;
                     sqlstm.sqlvsn = 12;
                     sqlstm.arrsiz = 7;
                     sqlstm.sqladtp = &sqladt;
                     sqlstm.sqltdsp = &sqltds;
                     sqlstm.stmt = "select count(*)  into :b0  from HLR_CONF\
IG_PARAMS where ((INSTANCE_TYPE=:b1 and MODULE_ID=:b2) and PARAM_SHORT_NAME=:b\
3)";
                     sqlstm.iters = (unsigned int  )1;
                     sqlstm.offset = (unsigned int  )240;
                     sqlstm.selerr = (unsigned short)1;
                     sqlstm.cud = sqlcud0;
                     sqlstm.sqlest = (unsigned char  *)&sqlca;
                     sqlstm.sqlety = (unsigned short)256;
                     sqlstm.occurs = (unsigned int  )0;
                     sqlstm.sqhstv[0] = (unsigned char  *)&Count;
                     sqlstm.sqhstl[0] = (unsigned long )sizeof(int);
                     sqlstm.sqhsts[0] = (         int  )0;
                     sqlstm.sqindv[0] = (         short *)0;
                     sqlstm.sqinds[0] = (         int  )0;
                     sqlstm.sqharm[0] = (unsigned long )0;
                     sqlstm.sqadto[0] = (unsigned short )0;
                     sqlstm.sqtdso[0] = (unsigned short )0;
                     sqlstm.sqhstv[1] = (unsigned char  *)&InstanceType;
                     sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
                     sqlstm.sqhsts[1] = (         int  )0;
                     sqlstm.sqindv[1] = (         short *)0;
                     sqlstm.sqinds[1] = (         int  )0;
                     sqlstm.sqharm[1] = (unsigned long )0;
                     sqlstm.sqadto[1] = (unsigned short )0;
                     sqlstm.sqtdso[1] = (unsigned short )0;
                     sqlstm.sqhstv[2] = (unsigned char  *)&Module_ID;
                     sqlstm.sqhstl[2] = (unsigned long )sizeof(int);
                     sqlstm.sqhsts[2] = (         int  )0;
                     sqlstm.sqindv[2] = (         short *)0;
                     sqlstm.sqinds[2] = (         int  )0;
                     sqlstm.sqharm[2] = (unsigned long )0;
                     sqlstm.sqadto[2] = (unsigned short )0;
                     sqlstm.sqtdso[2] = (unsigned short )0;
                     sqlstm.sqhstv[3] = (unsigned char  *)Param_Short_Name1;
                     sqlstm.sqhstl[3] = (unsigned long )100;
                     sqlstm.sqhsts[3] = (         int  )0;
                     sqlstm.sqindv[3] = (         short *)0;
                     sqlstm.sqinds[3] = (         int  )0;
                     sqlstm.sqharm[3] = (unsigned long )0;
                     sqlstm.sqadto[3] = (unsigned short )0;
                     sqlstm.sqtdso[3] = (unsigned short )0;
                     sqlstm.sqphsv = sqlstm.sqhstv;
                     sqlstm.sqphsl = sqlstm.sqhstl;
                     sqlstm.sqphss = sqlstm.sqhsts;
                     sqlstm.sqpind = sqlstm.sqindv;
                     sqlstm.sqpins = sqlstm.sqinds;
                     sqlstm.sqparm = sqlstm.sqharm;
                     sqlstm.sqparc = sqlstm.sqharc;
                     sqlstm.sqpadto = sqlstm.sqadto;
                     sqlstm.sqptdso = sqlstm.sqtdso;
                     sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
                     if (sqlca.sqlcode < 0) goto sqlerr;
}


                     
                                             
                     if((Count != 0) && (0 == strcmp((*l_ListIter).c_str(),"SYSTEM_THROTTLE_TPS"))) 
                     {
                         ELOG(0,0,"!!!!!!!!! Need To Give Proper Parent Tag For %s !!!!!!!!!!!!!",(*l_ListIter).c_str());
                          exit(0);
                     }
                     
            
                     if( Count == 0 &&(0 != strcmp((*l_ListIter).c_str(),"SERVICETYPE_TEMPLATE_LIST"))&& (0 != strcmp((*l_ListIter).c_str(),"PRIMARY"))&& (0 != strcmp((*l_ListIter).c_str(),"SECONDARY"))&& (0 != strcmp((*l_ListIter).c_str(),"SERVICETYPE_TEMPLATE_LIST"))&& (0 != strcmp((*l_ListIter).c_str(),"INTERFACE_THROTTLING")) && ( 3 != Module_ID) && ( 6 != Module_ID))
                     {
                        ELOG(0,0,"!!!!!!!!! Need To Give Proper Parent Tag For %s !!!!!!!!!!!!!",(*l_ListIter).c_str());
                        exit(0);
                     } 

                     string l_Value_INST;           
                     if(0 == strcmp((*l_ListIter).c_str(),"SERVICETYPE_TEMPLATE_LIST"))
                     {
                        l_Value_INST = ModuleXml;
                        int fir = l_Value_INST.find("<SERVICETYPE_TEMPLATE_LIST>");
                        int last =l_Value_INST.rfind("</SERVICETYPE_TEMPLATE_LIST>");//+strlen("/SERVICETYPE_TEMPLATE_LIST>"));
                        last = last+strlen("/SERVICETYPE_TEMPLATE_LIST>")+1;
                        l_Value_INST = l_Value_INST.substr(fir,last-fir);

                     }
                     else
                     {
                        l_Value_INST = Parser::getChildString(ModuleXml, (*l_ListIter)) ;
                     }

                     //string l_Value_INST = Parser::getChildString(ModuleXml, (*l_ListIter)) ;                      
                     l_NewXml = l_NewXml + l_Value_INST;

                  }
               }
               l_NewXml =  l_NewXml + "</" + l_ModuleName + ">";
            }
         }

         if(false == g_ConObj.init(g_ConObj.m_RtpsConfigName))  
         {
            ELOG(0,0,"\n%s not Found",g_ConObj.m_RtpsConfigName);
            exit(0);                                    
         }                                              

         string l_Value_INST = Parser::getChildString(g_ConObj.m_DataString,"HLR_NETWORKS") ;

         l_NewXml =      l_Value_INST+l_NewXml;

         l_NewXml = "<CONFIG>" + l_NewXml + "</CONFIG>";
         
         g_ConObj.m_DataString = l_NewXml ;    

         g_ConObj.m_ModuleMap.clear();

         if(false == g_ConObj.read_Rtps_Data())               
         {       

            ELOG(0,0,"\nError in reading RtpsSlConfigData.xml");
            exit(0);                                    
         }

         Count = 0;
         /* EXEC SQL SELECT COUNT(*)INTO :Count FROM HLR_CONFIG_PARAMS WHERE INSTANCE_TYPE = :InstanceType ; */ 

{
         struct sqlexd sqlstm;
         sqlstm.sqlvsn = 12;
         sqlstm.arrsiz = 7;
         sqlstm.sqladtp = &sqladt;
         sqlstm.sqltdsp = &sqltds;
         sqlstm.stmt = "select count(*)  into :b0  from HLR_CONFIG_PARAMS wh\
ere INSTANCE_TYPE=:b1";
         sqlstm.iters = (unsigned int  )1;
         sqlstm.offset = (unsigned int  )271;
         sqlstm.selerr = (unsigned short)1;
         sqlstm.cud = sqlcud0;
         sqlstm.sqlest = (unsigned char  *)&sqlca;
         sqlstm.sqlety = (unsigned short)256;
         sqlstm.occurs = (unsigned int  )0;
         sqlstm.sqhstv[0] = (unsigned char  *)&Count;
         sqlstm.sqhstl[0] = (unsigned long )sizeof(int);
         sqlstm.sqhsts[0] = (         int  )0;
         sqlstm.sqindv[0] = (         short *)0;
         sqlstm.sqinds[0] = (         int  )0;
         sqlstm.sqharm[0] = (unsigned long )0;
         sqlstm.sqadto[0] = (unsigned short )0;
         sqlstm.sqtdso[0] = (unsigned short )0;
         sqlstm.sqhstv[1] = (unsigned char  *)&InstanceType;
         sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
         sqlstm.sqhsts[1] = (         int  )0;
         sqlstm.sqindv[1] = (         short *)0;
         sqlstm.sqinds[1] = (         int  )0;
         sqlstm.sqharm[1] = (unsigned long )0;
         sqlstm.sqadto[1] = (unsigned short )0;
         sqlstm.sqtdso[1] = (unsigned short )0;
         sqlstm.sqphsv = sqlstm.sqhstv;
         sqlstm.sqphsl = sqlstm.sqhstl;
         sqlstm.sqphss = sqlstm.sqhsts;
         sqlstm.sqpind = sqlstm.sqindv;
         sqlstm.sqpins = sqlstm.sqinds;
         sqlstm.sqparm = sqlstm.sqharm;
         sqlstm.sqparc = sqlstm.sqharc;
         sqlstm.sqpadto = sqlstm.sqadto;
         sqlstm.sqptdso = sqlstm.sqtdso;
         sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
         if (sqlca.sqlcode < 0) goto sqlerr;
}


         l_count=Count;

         //EXEC SQL TRUNCATE TABLE HLR_CONFIG_VALUES;

         //EXEC SQL DELETE  FROM HLR_CONFIG_VALUES WHERE INSTANCE_TYPE = :InstanceType ;

         /* EXEC SQL DECLARE Params_cursor CURSOR FOR  SELECT PARAM_ID,MODULE_ID,PARAM_SHORT_NAME,PARAM_TYPE FROM HLR_CONFIG_PARAMS WHERE INSTANCE_TYPE = :InstanceType ; */ 


         /* EXEC SQL OPEN Params_cursor; */ 

{
         struct sqlexd sqlstm;
         sqlstm.sqlvsn = 12;
         sqlstm.arrsiz = 7;
         sqlstm.sqladtp = &sqladt;
         sqlstm.sqltdsp = &sqltds;
         sqlstm.stmt = sq0012;
         sqlstm.iters = (unsigned int  )1;
         sqlstm.offset = (unsigned int  )294;
         sqlstm.selerr = (unsigned short)1;
         sqlstm.cud = sqlcud0;
         sqlstm.sqlest = (unsigned char  *)&sqlca;
         sqlstm.sqlety = (unsigned short)256;
         sqlstm.occurs = (unsigned int  )0;
         sqlstm.sqcmod = (unsigned int )0;
         sqlstm.sqhstv[0] = (unsigned char  *)&InstanceType;
         sqlstm.sqhstl[0] = (unsigned long )sizeof(int);
         sqlstm.sqhsts[0] = (         int  )0;
         sqlstm.sqindv[0] = (         short *)0;
         sqlstm.sqinds[0] = (         int  )0;
         sqlstm.sqharm[0] = (unsigned long )0;
         sqlstm.sqadto[0] = (unsigned short )0;
         sqlstm.sqtdso[0] = (unsigned short )0;
         sqlstm.sqphsv = sqlstm.sqhstv;
         sqlstm.sqphsl = sqlstm.sqhstl;
         sqlstm.sqphss = sqlstm.sqhsts;
         sqlstm.sqpind = sqlstm.sqindv;
         sqlstm.sqpins = sqlstm.sqinds;
         sqlstm.sqparm = sqlstm.sqharm;
         sqlstm.sqparc = sqlstm.sqharc;
         sqlstm.sqpadto = sqlstm.sqadto;
         sqlstm.sqptdso = sqlstm.sqtdso;
         sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
         if (sqlca.sqlcode < 0) goto sqlerr;
}



         for(int  i = 0 ; i < l_count ; i++)
         {

            Param_ID = 0 ;
            Module_ID = 0;

            memset(Param_Short_Name.arr,'\0',sizeof((Param_Short_Name.arr)));

            memset(Param_Type.arr,'\0',sizeof(Param_Type.arr));

            /* EXEC SQL FETCH Params_cursor INTO :Param_ID,:Module_ID,:Param_Short_Name,:Param_Type; */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 7;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )313;
            sqlstm.selerr = (unsigned short)1;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqfoff = (         int )0;
            sqlstm.sqfmod = (unsigned int )2;
            sqlstm.sqhstv[0] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[0] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Module_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)&Param_Short_Name;
            sqlstm.sqhstl[2] = (unsigned long )102;
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)&Param_Type;
            sqlstm.sqhstl[3] = (unsigned long )102;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}



            l_Param_ID = Param_ID;

            l_Module_ID = Module_ID;



            strcpy(l_Param_Type,(char *)Param_Type.arr);     



            memset(l_Param_Short_Name,'\0',sizeof(l_Param_Short_Name));

            strcpy(l_Param_Short_Name,(char *)Param_Short_Name.arr);     


            string ModuleXml  =  (string)g_ConObj.m_ModuleMap.find(l_Module_ID)->second;        

            string l_Values = Parser::getValue( ModuleXml,(string)l_Param_Short_Name  );


            /*     for (std::map<int,string>::iterator it=g_ConObj.m_ModuleMap.begin(); it!=g_ConObj.m_ModuleMap.end(); ++it)
                   if( (it->first == l_Module_ID )&& l_Values.size()==0 && (it->first != 1))
                   {
                   ELOG(0,0,"NEED TO GIVEN PARANET TAG");
                   continue;
                   } */





            if(l_Values.size()==0 ) 
            {
              // ELOG(0,0,"ERROR!!!!!    %s Not Found in module-id [%d]  !!!!!!!!!!!! ",l_Param_Short_Name, l_Module_ID);
               continue;
               //  exit(0);
            }


            memset(Value,'\0',sizeof(Value));

            strcpy(Value,l_Values.c_str());


            Count_Val = 0;

            if(0 == strcmp(l_Param_Type,"COMPLEX"))
            { 

               //DLOG(0,0,"PARAM_ID - %d,PARAM_VALUE - %s ",l_Param_ID,l_Values.c_str());

               DLOG(0,0,"PARAM_ID - [%d] PARAM_NAME - [%s] PARAM_VALUE - [%s] INSTANCE [RTPS] INSTANCE_NAME[%s]",l_Param_ID,l_Param_Short_Name,l_Values.c_str(),g_ConObj.m_EntityName_DB.c_str());
               complexMap.insert(pair<int,string>(l_Param_ID,l_Values));
            }
            else
            {
               /* EXEC SQL DELETE  FROM HLR_CONFIG_VALUES WHERE  IP_ADDRESS = :IPaddress AND PROVISIONING_PORT =:ProvPort AND INSTANCE_TYPE = :InstanceType AND PARAM_ID = :Param_ID ; */ 

{
               struct sqlexd sqlstm;
               sqlstm.sqlvsn = 12;
               sqlstm.arrsiz = 7;
               sqlstm.sqladtp = &sqladt;
               sqlstm.sqltdsp = &sqltds;
               sqlstm.stmt = "delete  from HLR_CONFIG_VALUES  where (((IP_AD\
DRESS=:b0 and PROVISIONING_PORT=:b1) and INSTANCE_TYPE=:b2) and PARAM_ID=:b3)";
               sqlstm.iters = (unsigned int  )1;
               sqlstm.offset = (unsigned int  )344;
               sqlstm.cud = sqlcud0;
               sqlstm.sqlest = (unsigned char  *)&sqlca;
               sqlstm.sqlety = (unsigned short)256;
               sqlstm.occurs = (unsigned int  )0;
               sqlstm.sqhstv[0] = (unsigned char  *)IPaddress;
               sqlstm.sqhstl[0] = (unsigned long )20;
               sqlstm.sqhsts[0] = (         int  )0;
               sqlstm.sqindv[0] = (         short *)0;
               sqlstm.sqinds[0] = (         int  )0;
               sqlstm.sqharm[0] = (unsigned long )0;
               sqlstm.sqadto[0] = (unsigned short )0;
               sqlstm.sqtdso[0] = (unsigned short )0;
               sqlstm.sqhstv[1] = (unsigned char  *)ProvPort;
               sqlstm.sqhstl[1] = (unsigned long )10;
               sqlstm.sqhsts[1] = (         int  )0;
               sqlstm.sqindv[1] = (         short *)0;
               sqlstm.sqinds[1] = (         int  )0;
               sqlstm.sqharm[1] = (unsigned long )0;
               sqlstm.sqadto[1] = (unsigned short )0;
               sqlstm.sqtdso[1] = (unsigned short )0;
               sqlstm.sqhstv[2] = (unsigned char  *)&InstanceType;
               sqlstm.sqhstl[2] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[2] = (         int  )0;
               sqlstm.sqindv[2] = (         short *)0;
               sqlstm.sqinds[2] = (         int  )0;
               sqlstm.sqharm[2] = (unsigned long )0;
               sqlstm.sqadto[2] = (unsigned short )0;
               sqlstm.sqtdso[2] = (unsigned short )0;
               sqlstm.sqhstv[3] = (unsigned char  *)&Param_ID;
               sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[3] = (         int  )0;
               sqlstm.sqindv[3] = (         short *)0;
               sqlstm.sqinds[3] = (         int  )0;
               sqlstm.sqharm[3] = (unsigned long )0;
               sqlstm.sqadto[3] = (unsigned short )0;
               sqlstm.sqtdso[3] = (unsigned short )0;
               sqlstm.sqphsv = sqlstm.sqhstv;
               sqlstm.sqphsl = sqlstm.sqhstl;
               sqlstm.sqphss = sqlstm.sqhsts;
               sqlstm.sqpind = sqlstm.sqindv;
               sqlstm.sqpins = sqlstm.sqinds;
               sqlstm.sqparm = sqlstm.sqharm;
               sqlstm.sqparc = sqlstm.sqharc;
               sqlstm.sqpadto = sqlstm.sqadto;
               sqlstm.sqptdso = sqlstm.sqtdso;
               sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
               if (sqlca.sqlcode < 0) goto sqlerr;
}

  



               /* EXEC SQL INSERT INTO HLR_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,PARAM_VALUE,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,:Value,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
               struct sqlexd sqlstm;
               sqlstm.sqlvsn = 12;
               sqlstm.arrsiz = 7;
               sqlstm.sqladtp = &sqladt;
               sqlstm.sqltdsp = &sqltds;
               sqlstm.stmt = "insert into HLR_CONFIG_VALUES (ENTITY_NAME,PAR\
AM_ID,PARAM_VALUE,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DA\
TE,INSTANCE_TYPE) values (:b0,:b1,:b2,:b3,:b4,'OS',to_date(:b5,'mm/dd/yyyy hh2\
4:mi:ss'),:b6)";
               sqlstm.iters = (unsigned int  )1;
               sqlstm.offset = (unsigned int  )375;
               sqlstm.cud = sqlcud0;
               sqlstm.sqlest = (unsigned char  *)&sqlca;
               sqlstm.sqlety = (unsigned short)256;
               sqlstm.occurs = (unsigned int  )0;
               sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
               sqlstm.sqhstl[0] = (unsigned long )20;
               sqlstm.sqhsts[0] = (         int  )0;
               sqlstm.sqindv[0] = (         short *)0;
               sqlstm.sqinds[0] = (         int  )0;
               sqlstm.sqharm[0] = (unsigned long )0;
               sqlstm.sqadto[0] = (unsigned short )0;
               sqlstm.sqtdso[0] = (unsigned short )0;
               sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
               sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[1] = (         int  )0;
               sqlstm.sqindv[1] = (         short *)0;
               sqlstm.sqinds[1] = (         int  )0;
               sqlstm.sqharm[1] = (unsigned long )0;
               sqlstm.sqadto[1] = (unsigned short )0;
               sqlstm.sqtdso[1] = (unsigned short )0;
               sqlstm.sqhstv[2] = (unsigned char  *)Value;
               sqlstm.sqhstl[2] = (unsigned long )100000;
               sqlstm.sqhsts[2] = (         int  )0;
               sqlstm.sqindv[2] = (         short *)0;
               sqlstm.sqinds[2] = (         int  )0;
               sqlstm.sqharm[2] = (unsigned long )0;
               sqlstm.sqadto[2] = (unsigned short )0;
               sqlstm.sqtdso[2] = (unsigned short )0;
               sqlstm.sqhstv[3] = (unsigned char  *)IPaddress;
               sqlstm.sqhstl[3] = (unsigned long )20;
               sqlstm.sqhsts[3] = (         int  )0;
               sqlstm.sqindv[3] = (         short *)0;
               sqlstm.sqinds[3] = (         int  )0;
               sqlstm.sqharm[3] = (unsigned long )0;
               sqlstm.sqadto[3] = (unsigned short )0;
               sqlstm.sqtdso[3] = (unsigned short )0;
               sqlstm.sqhstv[4] = (unsigned char  *)ProvPort;
               sqlstm.sqhstl[4] = (unsigned long )10;
               sqlstm.sqhsts[4] = (         int  )0;
               sqlstm.sqindv[4] = (         short *)0;
               sqlstm.sqinds[4] = (         int  )0;
               sqlstm.sqharm[4] = (unsigned long )0;
               sqlstm.sqadto[4] = (unsigned short )0;
               sqlstm.sqtdso[4] = (unsigned short )0;
               sqlstm.sqhstv[5] = (unsigned char  *)&CharTime;
               sqlstm.sqhstl[5] = (unsigned long )102;
               sqlstm.sqhsts[5] = (         int  )0;
               sqlstm.sqindv[5] = (         short *)0;
               sqlstm.sqinds[5] = (         int  )0;
               sqlstm.sqharm[5] = (unsigned long )0;
               sqlstm.sqadto[5] = (unsigned short )0;
               sqlstm.sqtdso[5] = (unsigned short )0;
               sqlstm.sqhstv[6] = (unsigned char  *)&InstanceType;
               sqlstm.sqhstl[6] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[6] = (         int  )0;
               sqlstm.sqindv[6] = (         short *)0;
               sqlstm.sqinds[6] = (         int  )0;
               sqlstm.sqharm[6] = (unsigned long )0;
               sqlstm.sqadto[6] = (unsigned short )0;
               sqlstm.sqtdso[6] = (unsigned short )0;
               sqlstm.sqphsv = sqlstm.sqhstv;
               sqlstm.sqphsl = sqlstm.sqhstl;
               sqlstm.sqphss = sqlstm.sqhsts;
               sqlstm.sqpind = sqlstm.sqindv;
               sqlstm.sqpins = sqlstm.sqinds;
               sqlstm.sqparm = sqlstm.sqharm;
               sqlstm.sqparc = sqlstm.sqharc;
               sqlstm.sqpadto = sqlstm.sqadto;
               sqlstm.sqptdso = sqlstm.sqtdso;
               sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
               if (sqlca.sqlcode < 0) goto sqlerr;
}




               DLOG(0,0,"PARAM_ID - [%d] PARAM_NAME - [%s] PARAM_VALUE - [%s] INSTANCE [RTPS] INSTANCE_NAME[%s]",l_Param_ID,l_Param_Short_Name,l_Values.c_str(),g_ConObj.m_EntityName_DB.c_str());

               //DLOG(0,0,"PARAM_ID - %d,PARAM_VALUE - %s ",l_Param_ID,l_Values.c_str());
            }
         }
         /* EXEC SQL COMMIT; */ 

{
         struct sqlexd sqlstm;
         sqlstm.sqlvsn = 12;
         sqlstm.arrsiz = 7;
         sqlstm.sqladtp = &sqladt;
         sqlstm.sqltdsp = &sqltds;
         sqlstm.iters = (unsigned int  )1;
         sqlstm.offset = (unsigned int  )418;
         sqlstm.cud = sqlcud0;
         sqlstm.sqlest = (unsigned char  *)&sqlca;
         sqlstm.sqlety = (unsigned short)256;
         sqlstm.occurs = (unsigned int  )0;
         sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
         if (sqlca.sqlcode < 0) goto sqlerr;
}


         map <int,string>::iterator it;
         for (it=complexMap.begin(); it!=complexMap.end(); ++it)
         {

            Param_ID = it->first;

            /* EXEC SQL DELETE  FROM HLR_CONFIG_VALUES WHERE  IP_ADDRESS = :IPaddress AND PROVISIONING_PORT =:ProvPort AND INSTANCE_TYPE = :InstanceType AND PARAM_ID = :Param_ID ; */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 7;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "delete  from HLR_CONFIG_VALUES  where (((IP_ADDRE\
SS=:b0 and PROVISIONING_PORT=:b1) and INSTANCE_TYPE=:b2) and PARAM_ID=:b3)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )433;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[1] = (unsigned long )10;
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[2] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}

  


            /* EXEC SQL DELETE  FROM HLR_CMPLX_PARAM_CONFIG_VALUES WHERE  IP_ADDRESS = :IPaddress AND PROVISIONING_PORT =:ProvPort AND INSTANCE_TYPE = :InstanceType AND PARAM_ID = :Param_ID ; */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 7;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "delete  from HLR_CMPLX_PARAM_CONFIG_VALUES  where\
 (((IP_ADDRESS=:b0 and PROVISIONING_PORT=:b1) and INSTANCE_TYPE=:b2) and PARAM\
_ID=:b3)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )464;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[1] = (unsigned long )10;
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[2] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}

  


            Count_Val = 0;  
            DbComplexUpdate(Param_ID);
         }
      }


      else
      {
         Count = 0;
         /* EXEC SQL SELECT COUNT(*)INTO :Count FROM HLR_CONFIG_PARAMS WHERE INSTANCE_TYPE = :InstanceType ; */ 

{
         struct sqlexd sqlstm;
         sqlstm.sqlvsn = 12;
         sqlstm.arrsiz = 7;
         sqlstm.sqladtp = &sqladt;
         sqlstm.sqltdsp = &sqltds;
         sqlstm.stmt = "select count(*)  into :b0  from HLR_CONFIG_PARAMS wh\
ere INSTANCE_TYPE=:b1";
         sqlstm.iters = (unsigned int  )1;
         sqlstm.offset = (unsigned int  )495;
         sqlstm.selerr = (unsigned short)1;
         sqlstm.cud = sqlcud0;
         sqlstm.sqlest = (unsigned char  *)&sqlca;
         sqlstm.sqlety = (unsigned short)256;
         sqlstm.occurs = (unsigned int  )0;
         sqlstm.sqhstv[0] = (unsigned char  *)&Count;
         sqlstm.sqhstl[0] = (unsigned long )sizeof(int);
         sqlstm.sqhsts[0] = (         int  )0;
         sqlstm.sqindv[0] = (         short *)0;
         sqlstm.sqinds[0] = (         int  )0;
         sqlstm.sqharm[0] = (unsigned long )0;
         sqlstm.sqadto[0] = (unsigned short )0;
         sqlstm.sqtdso[0] = (unsigned short )0;
         sqlstm.sqhstv[1] = (unsigned char  *)&InstanceType;
         sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
         sqlstm.sqhsts[1] = (         int  )0;
         sqlstm.sqindv[1] = (         short *)0;
         sqlstm.sqinds[1] = (         int  )0;
         sqlstm.sqharm[1] = (unsigned long )0;
         sqlstm.sqadto[1] = (unsigned short )0;
         sqlstm.sqtdso[1] = (unsigned short )0;
         sqlstm.sqphsv = sqlstm.sqhstv;
         sqlstm.sqphsl = sqlstm.sqhstl;
         sqlstm.sqphss = sqlstm.sqhsts;
         sqlstm.sqpind = sqlstm.sqindv;
         sqlstm.sqpins = sqlstm.sqinds;
         sqlstm.sqparm = sqlstm.sqharm;
         sqlstm.sqparc = sqlstm.sqharc;
         sqlstm.sqpadto = sqlstm.sqadto;
         sqlstm.sqptdso = sqlstm.sqtdso;
         sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
         if (sqlca.sqlcode < 0) goto sqlerr;
}


         l_count=Count;

         //EXEC SQL TRUNCATE TABLE HLR_CONFIG_VALUES;

         /* EXEC SQL DELETE  FROM HLR_CONFIG_VALUES WHERE INSTANCE_TYPE = :InstanceType ; */ 

{
         struct sqlexd sqlstm;
         sqlstm.sqlvsn = 12;
         sqlstm.arrsiz = 7;
         sqlstm.sqladtp = &sqladt;
         sqlstm.sqltdsp = &sqltds;
         sqlstm.stmt = "delete  from HLR_CONFIG_VALUES  where INSTANCE_TYPE=\
:b0";
         sqlstm.iters = (unsigned int  )1;
         sqlstm.offset = (unsigned int  )518;
         sqlstm.cud = sqlcud0;
         sqlstm.sqlest = (unsigned char  *)&sqlca;
         sqlstm.sqlety = (unsigned short)256;
         sqlstm.occurs = (unsigned int  )0;
         sqlstm.sqhstv[0] = (unsigned char  *)&InstanceType;
         sqlstm.sqhstl[0] = (unsigned long )sizeof(int);
         sqlstm.sqhsts[0] = (         int  )0;
         sqlstm.sqindv[0] = (         short *)0;
         sqlstm.sqinds[0] = (         int  )0;
         sqlstm.sqharm[0] = (unsigned long )0;
         sqlstm.sqadto[0] = (unsigned short )0;
         sqlstm.sqtdso[0] = (unsigned short )0;
         sqlstm.sqphsv = sqlstm.sqhstv;
         sqlstm.sqphsl = sqlstm.sqhstl;
         sqlstm.sqphss = sqlstm.sqhsts;
         sqlstm.sqpind = sqlstm.sqindv;
         sqlstm.sqpins = sqlstm.sqinds;
         sqlstm.sqparm = sqlstm.sqharm;
         sqlstm.sqparc = sqlstm.sqharc;
         sqlstm.sqpadto = sqlstm.sqadto;
         sqlstm.sqptdso = sqlstm.sqtdso;
         sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
         if (sqlca.sqlcode < 0) goto sqlerr;
}



         /* EXEC SQL DECLARE Params_cursor CURSOR FOR  SELECT PARAM_ID,MODULE_ID,PARAM_SHORT_NAME,PARAM_TYPE FROM HLR_CONFIG_PARAMS WHERE INSTANCE_TYPE = :InstanceType ; */ 


         /* EXEC SQL OPEN Params_cursor; */ 

{
         struct sqlexd sqlstm;
         sqlstm.sqlvsn = 12;
         sqlstm.arrsiz = 7;
         sqlstm.sqladtp = &sqladt;
         sqlstm.sqltdsp = &sqltds;
         sqlstm.stmt = sq0012;
         sqlstm.iters = (unsigned int  )1;
         sqlstm.offset = (unsigned int  )537;
         sqlstm.selerr = (unsigned short)1;
         sqlstm.cud = sqlcud0;
         sqlstm.sqlest = (unsigned char  *)&sqlca;
         sqlstm.sqlety = (unsigned short)256;
         sqlstm.occurs = (unsigned int  )0;
         sqlstm.sqcmod = (unsigned int )0;
         sqlstm.sqhstv[0] = (unsigned char  *)&InstanceType;
         sqlstm.sqhstl[0] = (unsigned long )sizeof(int);
         sqlstm.sqhsts[0] = (         int  )0;
         sqlstm.sqindv[0] = (         short *)0;
         sqlstm.sqinds[0] = (         int  )0;
         sqlstm.sqharm[0] = (unsigned long )0;
         sqlstm.sqadto[0] = (unsigned short )0;
         sqlstm.sqtdso[0] = (unsigned short )0;
         sqlstm.sqphsv = sqlstm.sqhstv;
         sqlstm.sqphsl = sqlstm.sqhstl;
         sqlstm.sqphss = sqlstm.sqhsts;
         sqlstm.sqpind = sqlstm.sqindv;
         sqlstm.sqpins = sqlstm.sqinds;
         sqlstm.sqparm = sqlstm.sqharm;
         sqlstm.sqparc = sqlstm.sqharc;
         sqlstm.sqpadto = sqlstm.sqadto;
         sqlstm.sqptdso = sqlstm.sqtdso;
         sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
         if (sqlca.sqlcode < 0) goto sqlerr;
}



         for(int  i = 0 ; i < l_count ; i++)
         {

            Param_ID = 0 ;
            Module_ID = 0;

            memset(Param_Short_Name.arr,'\0',sizeof((Param_Short_Name.arr)));

            memset(Param_Type.arr,'\0',sizeof(Param_Type.arr));

            /* EXEC SQL FETCH Params_cursor INTO :Param_ID,:Module_ID,:Param_Short_Name,:Param_Type; */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 7;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )556;
            sqlstm.selerr = (unsigned short)1;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqfoff = (         int )0;
            sqlstm.sqfmod = (unsigned int )2;
            sqlstm.sqhstv[0] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[0] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Module_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)&Param_Short_Name;
            sqlstm.sqhstl[2] = (unsigned long )102;
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)&Param_Type;
            sqlstm.sqhstl[3] = (unsigned long )102;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}



            l_Param_ID = Param_ID;

            l_Module_ID = Module_ID;

            strcpy(l_Param_Type,(char *)Param_Type.arr);     

            memset(l_Param_Short_Name,'\0',sizeof(l_Param_Short_Name));

            strcpy(l_Param_Short_Name,(char *)Param_Short_Name.arr);     

            string ModuleXml  =  (string)g_ConObj.m_ModuleMap.find(l_Module_ID)->second;        

            string l_Values = Parser::getValue( ModuleXml,(string)l_Param_Short_Name  );

            if(l_Values.size()==0 ) 
            {
               ELOG(0,0,"ERROR!!!!!    %s Not Found in module-id [%d]  !!!!!!!!!!!! ",l_Param_Short_Name, l_Module_ID);
               continue;
               //  exit(0);
            }

            memset(Value,'\0',sizeof(Value));

            strcpy(Value,l_Values.c_str());

            Count_Val = 0;

            if(0 == strcmp(l_Param_Type,"COMPLEX"))
            { 
               /* EXEC SQL INSERT INTO HLR_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES('ALL',:Param_ID,'ALL','ALL','OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
               struct sqlexd sqlstm;
               sqlstm.sqlvsn = 12;
               sqlstm.arrsiz = 7;
               sqlstm.sqladtp = &sqladt;
               sqlstm.sqltdsp = &sqltds;
               sqlstm.stmt = "insert into HLR_CONFIG_VALUES (ENTITY_NAME,PAR\
AM_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_\
TYPE) values ('ALL',:b0,'ALL','ALL','OS',to_date(:b1,'mm/dd/yyyy hh24:mi:ss'),\
:b2)";
               sqlstm.iters = (unsigned int  )1;
               sqlstm.offset = (unsigned int  )587;
               sqlstm.cud = sqlcud0;
               sqlstm.sqlest = (unsigned char  *)&sqlca;
               sqlstm.sqlety = (unsigned short)256;
               sqlstm.occurs = (unsigned int  )0;
               sqlstm.sqhstv[0] = (unsigned char  *)&Param_ID;
               sqlstm.sqhstl[0] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[0] = (         int  )0;
               sqlstm.sqindv[0] = (         short *)0;
               sqlstm.sqinds[0] = (         int  )0;
               sqlstm.sqharm[0] = (unsigned long )0;
               sqlstm.sqadto[0] = (unsigned short )0;
               sqlstm.sqtdso[0] = (unsigned short )0;
               sqlstm.sqhstv[1] = (unsigned char  *)&CharTime;
               sqlstm.sqhstl[1] = (unsigned long )102;
               sqlstm.sqhsts[1] = (         int  )0;
               sqlstm.sqindv[1] = (         short *)0;
               sqlstm.sqinds[1] = (         int  )0;
               sqlstm.sqharm[1] = (unsigned long )0;
               sqlstm.sqadto[1] = (unsigned short )0;
               sqlstm.sqtdso[1] = (unsigned short )0;
               sqlstm.sqhstv[2] = (unsigned char  *)&InstanceType;
               sqlstm.sqhstl[2] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[2] = (         int  )0;
               sqlstm.sqindv[2] = (         short *)0;
               sqlstm.sqinds[2] = (         int  )0;
               sqlstm.sqharm[2] = (unsigned long )0;
               sqlstm.sqadto[2] = (unsigned short )0;
               sqlstm.sqtdso[2] = (unsigned short )0;
               sqlstm.sqphsv = sqlstm.sqhstv;
               sqlstm.sqphsl = sqlstm.sqhstl;
               sqlstm.sqphss = sqlstm.sqhsts;
               sqlstm.sqpind = sqlstm.sqindv;
               sqlstm.sqpins = sqlstm.sqinds;
               sqlstm.sqparm = sqlstm.sqharm;
               sqlstm.sqparc = sqlstm.sqharc;
               sqlstm.sqpadto = sqlstm.sqadto;
               sqlstm.sqptdso = sqlstm.sqtdso;
               sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
               if (sqlca.sqlcode < 0) goto sqlerr;
}




               DLOG(0,0,"PARAM_ID - [%d] PARAM_NAME - [%s] PARAM_VALUE - [%s] INSTANCE [%s] INSTANCE_NAME[%s]",l_Param_ID,l_Param_Short_Name,l_Values.c_str(),InstanceType == 1?"HLR":"RTPS","ALL");
               complexMap.insert(pair<int,string>(l_Param_ID,l_Values));
            }
            else
            {
        
               
                  /* EXEC SQL INSERT INTO HLR_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,PARAM_VALUE,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,:Value,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
                  struct sqlexd sqlstm;
                  sqlstm.sqlvsn = 12;
                  sqlstm.arrsiz = 7;
                  sqlstm.sqladtp = &sqladt;
                  sqlstm.sqltdsp = &sqltds;
                  sqlstm.stmt = "insert into HLR_CONFIG_VALUES (ENTITY_NAME,\
PARAM_ID,PARAM_VALUE,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED\
_DATE,INSTANCE_TYPE) values (:b0,:b1,:b2,:b3,:b4,'OS',to_date(:b5,'mm/dd/yyyy \
hh24:mi:ss'),:b6)";
                  sqlstm.iters = (unsigned int  )1;
                  sqlstm.offset = (unsigned int  )614;
                  sqlstm.cud = sqlcud0;
                  sqlstm.sqlest = (unsigned char  *)&sqlca;
                  sqlstm.sqlety = (unsigned short)256;
                  sqlstm.occurs = (unsigned int  )0;
                  sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
                  sqlstm.sqhstl[0] = (unsigned long )20;
                  sqlstm.sqhsts[0] = (         int  )0;
                  sqlstm.sqindv[0] = (         short *)0;
                  sqlstm.sqinds[0] = (         int  )0;
                  sqlstm.sqharm[0] = (unsigned long )0;
                  sqlstm.sqadto[0] = (unsigned short )0;
                  sqlstm.sqtdso[0] = (unsigned short )0;
                  sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
                  sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
                  sqlstm.sqhsts[1] = (         int  )0;
                  sqlstm.sqindv[1] = (         short *)0;
                  sqlstm.sqinds[1] = (         int  )0;
                  sqlstm.sqharm[1] = (unsigned long )0;
                  sqlstm.sqadto[1] = (unsigned short )0;
                  sqlstm.sqtdso[1] = (unsigned short )0;
                  sqlstm.sqhstv[2] = (unsigned char  *)Value;
                  sqlstm.sqhstl[2] = (unsigned long )100000;
                  sqlstm.sqhsts[2] = (         int  )0;
                  sqlstm.sqindv[2] = (         short *)0;
                  sqlstm.sqinds[2] = (         int  )0;
                  sqlstm.sqharm[2] = (unsigned long )0;
                  sqlstm.sqadto[2] = (unsigned short )0;
                  sqlstm.sqtdso[2] = (unsigned short )0;
                  sqlstm.sqhstv[3] = (unsigned char  *)IPaddress;
                  sqlstm.sqhstl[3] = (unsigned long )20;
                  sqlstm.sqhsts[3] = (         int  )0;
                  sqlstm.sqindv[3] = (         short *)0;
                  sqlstm.sqinds[3] = (         int  )0;
                  sqlstm.sqharm[3] = (unsigned long )0;
                  sqlstm.sqadto[3] = (unsigned short )0;
                  sqlstm.sqtdso[3] = (unsigned short )0;
                  sqlstm.sqhstv[4] = (unsigned char  *)ProvPort;
                  sqlstm.sqhstl[4] = (unsigned long )10;
                  sqlstm.sqhsts[4] = (         int  )0;
                  sqlstm.sqindv[4] = (         short *)0;
                  sqlstm.sqinds[4] = (         int  )0;
                  sqlstm.sqharm[4] = (unsigned long )0;
                  sqlstm.sqadto[4] = (unsigned short )0;
                  sqlstm.sqtdso[4] = (unsigned short )0;
                  sqlstm.sqhstv[5] = (unsigned char  *)&CharTime;
                  sqlstm.sqhstl[5] = (unsigned long )102;
                  sqlstm.sqhsts[5] = (         int  )0;
                  sqlstm.sqindv[5] = (         short *)0;
                  sqlstm.sqinds[5] = (         int  )0;
                  sqlstm.sqharm[5] = (unsigned long )0;
                  sqlstm.sqadto[5] = (unsigned short )0;
                  sqlstm.sqtdso[5] = (unsigned short )0;
                  sqlstm.sqhstv[6] = (unsigned char  *)&InstanceType;
                  sqlstm.sqhstl[6] = (unsigned long )sizeof(int);
                  sqlstm.sqhsts[6] = (         int  )0;
                  sqlstm.sqindv[6] = (         short *)0;
                  sqlstm.sqinds[6] = (         int  )0;
                  sqlstm.sqharm[6] = (unsigned long )0;
                  sqlstm.sqadto[6] = (unsigned short )0;
                  sqlstm.sqtdso[6] = (unsigned short )0;
                  sqlstm.sqphsv = sqlstm.sqhstv;
                  sqlstm.sqphsl = sqlstm.sqhstl;
                  sqlstm.sqphss = sqlstm.sqhsts;
                  sqlstm.sqpind = sqlstm.sqindv;
                  sqlstm.sqpins = sqlstm.sqinds;
                  sqlstm.sqparm = sqlstm.sqharm;
                  sqlstm.sqparc = sqlstm.sqharc;
                  sqlstm.sqpadto = sqlstm.sqadto;
                  sqlstm.sqptdso = sqlstm.sqtdso;
                  sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
                  if (sqlca.sqlcode < 0) goto sqlerr;
}


               
               //DLOG(0,0,"PARAM_NAME - %s PARAM_ID - %d,PARAM_VALUE - %s ",l_Param_ID,l_Values.c_str());
               DLOG(0,0,"PARAM_ID - [%d] PARAM_NAME - [%s] PARAM_VALUE - [%s] INSTANCE [%s] INSTANCE_NAME [%s]",l_Param_ID,l_Param_Short_Name,l_Values.c_str(),InstanceType == 1?"HLR":"RTPS","ALL");
            }


         }

         /* EXEC SQL COMMIT; */ 

{
         struct sqlexd sqlstm;
         sqlstm.sqlvsn = 12;
         sqlstm.arrsiz = 7;
         sqlstm.sqladtp = &sqladt;
         sqlstm.sqltdsp = &sqltds;
         sqlstm.iters = (unsigned int  )1;
         sqlstm.offset = (unsigned int  )657;
         sqlstm.cud = sqlcud0;
         sqlstm.sqlest = (unsigned char  *)&sqlca;
         sqlstm.sqlety = (unsigned short)256;
         sqlstm.occurs = (unsigned int  )0;
         sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
         if (sqlca.sqlcode < 0) goto sqlerr;
}





         map <int,string>::iterator it;

         /* EXEC SQL DELETE FROM  HLR_CMPLX_PARAM_CONFIG_VALUES WHERE INSTANCE_TYPE = :InstanceType ; */ 

{
         struct sqlexd sqlstm;
         sqlstm.sqlvsn = 12;
         sqlstm.arrsiz = 7;
         sqlstm.sqladtp = &sqladt;
         sqlstm.sqltdsp = &sqltds;
         sqlstm.stmt = "delete  from HLR_CMPLX_PARAM_CONFIG_VALUES  where IN\
STANCE_TYPE=:b0";
         sqlstm.iters = (unsigned int  )1;
         sqlstm.offset = (unsigned int  )672;
         sqlstm.cud = sqlcud0;
         sqlstm.sqlest = (unsigned char  *)&sqlca;
         sqlstm.sqlety = (unsigned short)256;
         sqlstm.occurs = (unsigned int  )0;
         sqlstm.sqhstv[0] = (unsigned char  *)&InstanceType;
         sqlstm.sqhstl[0] = (unsigned long )sizeof(int);
         sqlstm.sqhsts[0] = (         int  )0;
         sqlstm.sqindv[0] = (         short *)0;
         sqlstm.sqinds[0] = (         int  )0;
         sqlstm.sqharm[0] = (unsigned long )0;
         sqlstm.sqadto[0] = (unsigned short )0;
         sqlstm.sqtdso[0] = (unsigned short )0;
         sqlstm.sqphsv = sqlstm.sqhstv;
         sqlstm.sqphsl = sqlstm.sqhstl;
         sqlstm.sqphss = sqlstm.sqhsts;
         sqlstm.sqpind = sqlstm.sqindv;
         sqlstm.sqpins = sqlstm.sqinds;
         sqlstm.sqparm = sqlstm.sqharm;
         sqlstm.sqparc = sqlstm.sqharc;
         sqlstm.sqpadto = sqlstm.sqadto;
         sqlstm.sqptdso = sqlstm.sqtdso;
         sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
         if (sqlca.sqlcode < 0) goto sqlerr;
}



         for (it=complexMap.begin(); it!=complexMap.end(); ++it)
         {

            strcpy(EntityName,"ALL");
            Count_Val = 0;
            DbComplexUpdate(it->first);
         }
      }





      //     EXEC SQL CLOSE Params_cursor;






      l_count = 0;

      Count = 0;

      /* EXEC SQL SELECT COUNT(*)INTO :Count FROM HLR_CONFIG_VALUES WHERE INSTANCE_TYPE = :InstanceType; */ 

{
      struct sqlexd sqlstm;
      sqlstm.sqlvsn = 12;
      sqlstm.arrsiz = 7;
      sqlstm.sqladtp = &sqladt;
      sqlstm.sqltdsp = &sqltds;
      sqlstm.stmt = "select count(*)  into :b0  from HLR_CONFIG_VALUES where\
 INSTANCE_TYPE=:b1";
      sqlstm.iters = (unsigned int  )1;
      sqlstm.offset = (unsigned int  )691;
      sqlstm.selerr = (unsigned short)1;
      sqlstm.cud = sqlcud0;
      sqlstm.sqlest = (unsigned char  *)&sqlca;
      sqlstm.sqlety = (unsigned short)256;
      sqlstm.occurs = (unsigned int  )0;
      sqlstm.sqhstv[0] = (unsigned char  *)&Count;
      sqlstm.sqhstl[0] = (unsigned long )sizeof(int);
      sqlstm.sqhsts[0] = (         int  )0;
      sqlstm.sqindv[0] = (         short *)0;
      sqlstm.sqinds[0] = (         int  )0;
      sqlstm.sqharm[0] = (unsigned long )0;
      sqlstm.sqadto[0] = (unsigned short )0;
      sqlstm.sqtdso[0] = (unsigned short )0;
      sqlstm.sqhstv[1] = (unsigned char  *)&InstanceType;
      sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
      sqlstm.sqhsts[1] = (         int  )0;
      sqlstm.sqindv[1] = (         short *)0;
      sqlstm.sqinds[1] = (         int  )0;
      sqlstm.sqharm[1] = (unsigned long )0;
      sqlstm.sqadto[1] = (unsigned short )0;
      sqlstm.sqtdso[1] = (unsigned short )0;
      sqlstm.sqphsv = sqlstm.sqhstv;
      sqlstm.sqphsl = sqlstm.sqhstl;
      sqlstm.sqphss = sqlstm.sqhsts;
      sqlstm.sqpind = sqlstm.sqindv;
      sqlstm.sqpins = sqlstm.sqinds;
      sqlstm.sqparm = sqlstm.sqharm;
      sqlstm.sqparc = sqlstm.sqharc;
      sqlstm.sqpadto = sqlstm.sqadto;
      sqlstm.sqptdso = sqlstm.sqtdso;
      sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
      if (sqlca.sqlcode < 0) goto sqlerr;
}



      l_count=Count;

      DLOG(0,0,"INSERTION COMPLETED");


      /* EXEC SQL SELECT COUNT(*)INTO :Count FROM HLR_CONFIG_VALUES ; */ 

{
      struct sqlexd sqlstm;
      sqlstm.sqlvsn = 12;
      sqlstm.arrsiz = 7;
      sqlstm.sqladtp = &sqladt;
      sqlstm.sqltdsp = &sqltds;
      sqlstm.stmt = "select count(*)  into :b0  from HLR_CONFIG_VALUES ";
      sqlstm.iters = (unsigned int  )1;
      sqlstm.offset = (unsigned int  )714;
      sqlstm.selerr = (unsigned short)1;
      sqlstm.cud = sqlcud0;
      sqlstm.sqlest = (unsigned char  *)&sqlca;
      sqlstm.sqlety = (unsigned short)256;
      sqlstm.occurs = (unsigned int  )0;
      sqlstm.sqhstv[0] = (unsigned char  *)&Count;
      sqlstm.sqhstl[0] = (unsigned long )sizeof(int);
      sqlstm.sqhsts[0] = (         int  )0;
      sqlstm.sqindv[0] = (         short *)0;
      sqlstm.sqinds[0] = (         int  )0;
      sqlstm.sqharm[0] = (unsigned long )0;
      sqlstm.sqadto[0] = (unsigned short )0;
      sqlstm.sqtdso[0] = (unsigned short )0;
      sqlstm.sqphsv = sqlstm.sqhstv;
      sqlstm.sqphsl = sqlstm.sqhstl;
      sqlstm.sqphss = sqlstm.sqhsts;
      sqlstm.sqpind = sqlstm.sqindv;
      sqlstm.sqpins = sqlstm.sqinds;
      sqlstm.sqparm = sqlstm.sqharm;
      sqlstm.sqparc = sqlstm.sqharc;
      sqlstm.sqpadto = sqlstm.sqadto;
      sqlstm.sqptdso = sqlstm.sqtdso;
      sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
      if (sqlca.sqlcode < 0) goto sqlerr;
}



      l_count=Count;

//      DLOG(0,0,"Total Count of the HLR_CONFIG_VALUES is %d ",l_count);
      // EXEC SQL CLOSE Params_cursor;

   }
   catch(...)
   {
      ELOG(0,0,"Exception occurred in TagGroup Values");
      return 0;
   }
sqlerr:
   {
      if(sqlca.sqlcode != 0)
         ELOG(0,0,"SQL error received: %d", sqlca.sqlcode);

      if(sqlca.sqlcode == -1405)
      {
         ELOG(0,0,"One of the column values is NULL. Please Check the Configuration");
      }
   }

   return 0;
}



void DbComplexUpdate(int first)
{

   /*   EXEC SQL BEGIN DECLARE SECTION;

        VARCHAR CharTime[100];
        char Value[100000];
        int Param_ID;
        int Module_ID;
        char Param_Short_Name1[100];
        VARCHAR Param_Short_Name[100];
        VARCHAR Param_Type[100];
        int Count;
        int Count_Val;
        char username[20];
        char password[20];
        char dbstring[20];
        char full[200+1];
        char IPaddress[20];
        char ProvPort[10];
        char InstanceSp[20];
        char EntityName[20];
        int  InstanceType;
        char ModuleName[30];
        int Param_Count;
        int Sequence_ID;
        int Sub_ID;
        EXEC SQL END DECLARE SECTION;

        strcpy(full,g_dbAlias);

        char l_ProvPort[10];
        char l_CharTime[100];
        time_t timer;
        struct tm *timeStruct;
        int l_Param_ID;
        int l_Module_ID;
        char l_Param_Short_Name[500];
        char l_Param_Type[100];
        int l_count;
        int l_Count_Val;
        int l_Param_Count;
        int l_Param_Count1;*/



   strcpy((char *)CharTime.arr,(char *)l_CharTime);

   strcpy(IPaddress,g_ConObj.m_IPAddress_DB.c_str());

   strcpy(ProvPort,g_ConObj.m_IPPort_DB.c_str());

   strcpy(InstanceSp,g_ConObj.m_InstanceSp_DB.c_str());

   strcpy(EntityName,g_ConObj.m_EntityName_DB.c_str()); 

   InstanceType = g_ConObj.m_instanceType; 
   /* EXEC SQL WHENEVER SQLERROR GOTO sqlerr; */ 

   try
   {

      if(first == 92)
      {

         string temp =  complexMap.find(first)->second; 
         int found;
         string searchFora ("<PREFIX_");    
         found = temp.find( searchFora );
         if(found == -1)
         {
            ELOG(0,0,"!!!!!!!!!! PREFIX Tag not Found !!!!!!!!");
         }
         else
         {
            while(found != string::npos) 
            {  
               string replaceBya ("<PREFIX>");
               temp.replace( found, strlen("<PREFIX_00>"), replaceBya );
               searchFora = "</PREFIX_";    
               replaceBya = "</PREFIX>";
               found = temp.find( searchFora );
               temp.replace( found,strlen("</PREFIX_00>"), replaceBya );
               string searchFora ("<PREFIX_");    
               found = temp.find( searchFora );
            }
            found = temp.find("<PREFIX>");
            while(found != string::npos)
            {
               int fir = temp.find("<PREFIX>")+strlen("PREFIX>")+1;
               int last =temp.find("</PREFIX>");
               string value1 = temp.substr(fir,last-fir);
               Param_ID = first ;
               strcpy(Value,value1.c_str());
               Count_Val++;
               /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,1,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
               struct sqlexd sqlstm;
               sqlstm.sqlvsn = 12;
               sqlstm.arrsiz = 8;
               sqlstm.sqladtp = &sqladt;
               sqlstm.sqltdsp = &sqltds;
               sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENT\
ITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING\
_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,1,:b2,:\
b3,:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
               sqlstm.iters = (unsigned int  )1;
               sqlstm.offset = (unsigned int  )733;
               sqlstm.cud = sqlcud0;
               sqlstm.sqlest = (unsigned char  *)&sqlca;
               sqlstm.sqlety = (unsigned short)256;
               sqlstm.occurs = (unsigned int  )0;
               sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
               sqlstm.sqhstl[0] = (unsigned long )20;
               sqlstm.sqhsts[0] = (         int  )0;
               sqlstm.sqindv[0] = (         short *)0;
               sqlstm.sqinds[0] = (         int  )0;
               sqlstm.sqharm[0] = (unsigned long )0;
               sqlstm.sqadto[0] = (unsigned short )0;
               sqlstm.sqtdso[0] = (unsigned short )0;
               sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
               sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[1] = (         int  )0;
               sqlstm.sqindv[1] = (         short *)0;
               sqlstm.sqinds[1] = (         int  )0;
               sqlstm.sqharm[1] = (unsigned long )0;
               sqlstm.sqadto[1] = (unsigned short )0;
               sqlstm.sqtdso[1] = (unsigned short )0;
               sqlstm.sqhstv[2] = (unsigned char  *)Value;
               sqlstm.sqhstl[2] = (unsigned long )100000;
               sqlstm.sqhsts[2] = (         int  )0;
               sqlstm.sqindv[2] = (         short *)0;
               sqlstm.sqinds[2] = (         int  )0;
               sqlstm.sqharm[2] = (unsigned long )0;
               sqlstm.sqadto[2] = (unsigned short )0;
               sqlstm.sqtdso[2] = (unsigned short )0;
               sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
               sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[3] = (         int  )0;
               sqlstm.sqindv[3] = (         short *)0;
               sqlstm.sqinds[3] = (         int  )0;
               sqlstm.sqharm[3] = (unsigned long )0;
               sqlstm.sqadto[3] = (unsigned short )0;
               sqlstm.sqtdso[3] = (unsigned short )0;
               sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
               sqlstm.sqhstl[4] = (unsigned long )20;
               sqlstm.sqhsts[4] = (         int  )0;
               sqlstm.sqindv[4] = (         short *)0;
               sqlstm.sqinds[4] = (         int  )0;
               sqlstm.sqharm[4] = (unsigned long )0;
               sqlstm.sqadto[4] = (unsigned short )0;
               sqlstm.sqtdso[4] = (unsigned short )0;
               sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
               sqlstm.sqhstl[5] = (unsigned long )10;
               sqlstm.sqhsts[5] = (         int  )0;
               sqlstm.sqindv[5] = (         short *)0;
               sqlstm.sqinds[5] = (         int  )0;
               sqlstm.sqharm[5] = (unsigned long )0;
               sqlstm.sqadto[5] = (unsigned short )0;
               sqlstm.sqtdso[5] = (unsigned short )0;
               sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
               sqlstm.sqhstl[6] = (unsigned long )102;
               sqlstm.sqhsts[6] = (         int  )0;
               sqlstm.sqindv[6] = (         short *)0;
               sqlstm.sqinds[6] = (         int  )0;
               sqlstm.sqharm[6] = (unsigned long )0;
               sqlstm.sqadto[6] = (unsigned short )0;
               sqlstm.sqtdso[6] = (unsigned short )0;
               sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
               sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[7] = (         int  )0;
               sqlstm.sqindv[7] = (         short *)0;
               sqlstm.sqinds[7] = (         int  )0;
               sqlstm.sqharm[7] = (unsigned long )0;
               sqlstm.sqadto[7] = (unsigned short )0;
               sqlstm.sqtdso[7] = (unsigned short )0;
               sqlstm.sqphsv = sqlstm.sqhstv;
               sqlstm.sqphsl = sqlstm.sqhstl;
               sqlstm.sqphss = sqlstm.sqhsts;
               sqlstm.sqpind = sqlstm.sqindv;
               sqlstm.sqpins = sqlstm.sqinds;
               sqlstm.sqparm = sqlstm.sqharm;
               sqlstm.sqparc = sqlstm.sqharc;
               sqlstm.sqpadto = sqlstm.sqadto;
               sqlstm.sqptdso = sqlstm.sqtdso;
               sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
               if (sqlca.sqlcode < 0) goto sqlerr;
}



               temp.erase(temp.find("<PREFIX>"),temp.find("</PREFIX>")+strlen("/PREFIX>")- temp.find("<PREFIX>")+1);
               found = temp.find("<PREFIX>");

            }
         }

         if(0 == strcmp(g_ConObj.m_InstanceSp_DB.c_str(),"INST"))
            /* EXEC SQL INSERT INTO HLR_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CONFIG_VALUES (ENTITY_NAME,PARAM_\
ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYP\
E) values (:b0,:b1,:b2,:b3,'OS',to_date(:b4,'mm/dd/yyyy hh24:mi:ss'),:b5)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )780;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[2] = (unsigned long )20;
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[3] = (unsigned long )10;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[4] = (unsigned long )102;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[5] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}




         /* EXEC SQL COMMIT; */ 

{
         struct sqlexd sqlstm;
         sqlstm.sqlvsn = 12;
         sqlstm.arrsiz = 8;
         sqlstm.sqladtp = &sqladt;
         sqlstm.sqltdsp = &sqltds;
         sqlstm.iters = (unsigned int  )1;
         sqlstm.offset = (unsigned int  )819;
         sqlstm.cud = sqlcud0;
         sqlstm.sqlest = (unsigned char  *)&sqlca;
         sqlstm.sqlety = (unsigned short)256;
         sqlstm.occurs = (unsigned int  )0;
         sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
         if (sqlca.sqlcode < 0) goto sqlerr;
}


      }

      else if(first == 97)
      {
         Param_ID = first;
         int found;
         string temp =  complexMap.find(first)->second; 
         found = temp.find("<TDR_TYPE>"); 
         if(found == -1)
         {
            ELOG(0,0,"!!!!!!!!!!TDR_TYPE Tag not Found!!!!!!!!");
         }
         else
         {
            while(found != string::npos)
            {
               int fir = temp.find("<TDR_TYPE>")+strlen("TDR_TYPE>")+1;
               int last =temp.find("</TDR_TYPE>");
               string value1 = temp.substr(fir,last-fir);
               Param_ID = first ;
               strcpy(Value,value1.c_str());
               Count_Val++;
               /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,2,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
               struct sqlexd sqlstm;
               sqlstm.sqlvsn = 12;
               sqlstm.arrsiz = 8;
               sqlstm.sqladtp = &sqladt;
               sqlstm.sqltdsp = &sqltds;
               sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENT\
ITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING\
_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,2,:b2,:\
b3,:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
               sqlstm.iters = (unsigned int  )1;
               sqlstm.offset = (unsigned int  )834;
               sqlstm.cud = sqlcud0;
               sqlstm.sqlest = (unsigned char  *)&sqlca;
               sqlstm.sqlety = (unsigned short)256;
               sqlstm.occurs = (unsigned int  )0;
               sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
               sqlstm.sqhstl[0] = (unsigned long )20;
               sqlstm.sqhsts[0] = (         int  )0;
               sqlstm.sqindv[0] = (         short *)0;
               sqlstm.sqinds[0] = (         int  )0;
               sqlstm.sqharm[0] = (unsigned long )0;
               sqlstm.sqadto[0] = (unsigned short )0;
               sqlstm.sqtdso[0] = (unsigned short )0;
               sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
               sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[1] = (         int  )0;
               sqlstm.sqindv[1] = (         short *)0;
               sqlstm.sqinds[1] = (         int  )0;
               sqlstm.sqharm[1] = (unsigned long )0;
               sqlstm.sqadto[1] = (unsigned short )0;
               sqlstm.sqtdso[1] = (unsigned short )0;
               sqlstm.sqhstv[2] = (unsigned char  *)Value;
               sqlstm.sqhstl[2] = (unsigned long )100000;
               sqlstm.sqhsts[2] = (         int  )0;
               sqlstm.sqindv[2] = (         short *)0;
               sqlstm.sqinds[2] = (         int  )0;
               sqlstm.sqharm[2] = (unsigned long )0;
               sqlstm.sqadto[2] = (unsigned short )0;
               sqlstm.sqtdso[2] = (unsigned short )0;
               sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
               sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[3] = (         int  )0;
               sqlstm.sqindv[3] = (         short *)0;
               sqlstm.sqinds[3] = (         int  )0;
               sqlstm.sqharm[3] = (unsigned long )0;
               sqlstm.sqadto[3] = (unsigned short )0;
               sqlstm.sqtdso[3] = (unsigned short )0;
               sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
               sqlstm.sqhstl[4] = (unsigned long )20;
               sqlstm.sqhsts[4] = (         int  )0;
               sqlstm.sqindv[4] = (         short *)0;
               sqlstm.sqinds[4] = (         int  )0;
               sqlstm.sqharm[4] = (unsigned long )0;
               sqlstm.sqadto[4] = (unsigned short )0;
               sqlstm.sqtdso[4] = (unsigned short )0;
               sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
               sqlstm.sqhstl[5] = (unsigned long )10;
               sqlstm.sqhsts[5] = (         int  )0;
               sqlstm.sqindv[5] = (         short *)0;
               sqlstm.sqinds[5] = (         int  )0;
               sqlstm.sqharm[5] = (unsigned long )0;
               sqlstm.sqadto[5] = (unsigned short )0;
               sqlstm.sqtdso[5] = (unsigned short )0;
               sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
               sqlstm.sqhstl[6] = (unsigned long )102;
               sqlstm.sqhsts[6] = (         int  )0;
               sqlstm.sqindv[6] = (         short *)0;
               sqlstm.sqinds[6] = (         int  )0;
               sqlstm.sqharm[6] = (unsigned long )0;
               sqlstm.sqadto[6] = (unsigned short )0;
               sqlstm.sqtdso[6] = (unsigned short )0;
               sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
               sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[7] = (         int  )0;
               sqlstm.sqindv[7] = (         short *)0;
               sqlstm.sqinds[7] = (         int  )0;
               sqlstm.sqharm[7] = (unsigned long )0;
               sqlstm.sqadto[7] = (unsigned short )0;
               sqlstm.sqtdso[7] = (unsigned short )0;
               sqlstm.sqphsv = sqlstm.sqhstv;
               sqlstm.sqphsl = sqlstm.sqhstl;
               sqlstm.sqphss = sqlstm.sqhsts;
               sqlstm.sqpind = sqlstm.sqindv;
               sqlstm.sqpins = sqlstm.sqinds;
               sqlstm.sqparm = sqlstm.sqharm;
               sqlstm.sqparc = sqlstm.sqharc;
               sqlstm.sqpadto = sqlstm.sqadto;
               sqlstm.sqptdso = sqlstm.sqtdso;
               sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
               if (sqlca.sqlcode < 0) goto sqlerr;
}


               temp.erase(temp.find("<TDR_TYPE>"),temp.find("</TDR_TYPE>")+strlen("/TDR_TYPE>")- temp.find("<TDR_TYPE>")+1);
               found = temp.find("<TDR_TYPE>");
            }
         }
         if(0 == strcmp(g_ConObj.m_InstanceSp_DB.c_str(),"INST"))
            /* EXEC SQL INSERT INTO HLR_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CONFIG_VALUES (ENTITY_NAME,PARAM_\
ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYP\
E) values (:b0,:b1,:b2,:b3,'OS',to_date(:b4,'mm/dd/yyyy hh24:mi:ss'),:b5)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )881;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[2] = (unsigned long )20;
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[3] = (unsigned long )10;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[4] = (unsigned long )102;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[5] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}



         /* EXEC SQL COMMIT; */ 

{
         struct sqlexd sqlstm;
         sqlstm.sqlvsn = 12;
         sqlstm.arrsiz = 8;
         sqlstm.sqladtp = &sqladt;
         sqlstm.sqltdsp = &sqltds;
         sqlstm.iters = (unsigned int  )1;
         sqlstm.offset = (unsigned int  )920;
         sqlstm.cud = sqlcud0;
         sqlstm.sqlest = (unsigned char  *)&sqlca;
         sqlstm.sqlety = (unsigned short)256;
         sqlstm.occurs = (unsigned int  )0;
         sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
         if (sqlca.sqlcode < 0) goto sqlerr;
}


      }

      else if(first == 109)
      {
         Param_ID = first;
         int found;
         string HLR_NETWORK = (string)g_ConObj.m_ModuleMap.find(1)->second;

         string searchFora ("<NETWORK_");    

         found = HLR_NETWORK.find( searchFora );


         while(found != string::npos) 
         {  

            string replaceBya ("<NETWORK>");
            HLR_NETWORK.replace( found, strlen("<NETWORK_00>"), replaceBya );
            searchFora = "</NETWORK_";    
            replaceBya = "</NETWORK>";
            found = HLR_NETWORK.find( searchFora );

            HLR_NETWORK.replace( found,strlen("</NETWORK_00>"), replaceBya );
            string searchFora ("<NETWORK_");    
            found = HLR_NETWORK.find( searchFora );
         }


         string temp =  complexMap.find(first)->second; 
         searchFora = "<NETWORK_";    
         found = temp.find( searchFora );
         if(found == -1)
         {
            ELOG(0,0,"!!!!!!!!!! NETWORK Tag not Found in RN !!!!!!!!");
         }
         while(found != string::npos) 
         {  
            string replaceBya ("<NETWORK>");
            temp.replace( found, strlen("<NETWORK_00>"), replaceBya );
            searchFora = "</NETWORK_";    
            replaceBya = "</NETWORK>";
            found = temp.find( searchFora );
            temp.replace( found,strlen("</NETWORK_00>"), replaceBya );
            string searchFora ("<NETWORK_");    
            found = temp.find( searchFora );
         }

         found = HLR_NETWORK.find("<NETWORK>");
         while(found != string::npos)
         {
            int fir = HLR_NETWORK.find("<NETWORK>")+strlen("NETWORK>")+1;
            int last =HLR_NETWORK.find("</NETWORK>");
            string value1 = HLR_NETWORK.substr(fir,last-fir);
            HLR_NETWORK.erase(HLR_NETWORK.find("<NETWORK>"),HLR_NETWORK.find("</NETWORK>")+strlen("/NETWORK>")- HLR_NETWORK.find("<NETWORK>")+1);

            found = temp.find("<NETWORK>");


            fir = temp.find("<NETWORK>")+strlen("NETWORK>")+1;
            last =temp.find("</NETWORK>");
            string value2 = temp.substr(fir,last-fir);

            // value2 = value1+":"+value2;
            strcpy(Value,value1.c_str());




            Count_Val++;

            //      if(0 != strcmp(g_ConObj.m_InstanceSp_DB.c_str(),"INST"))
            /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,3,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENTITY\
_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PO\
RT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,3,:b2,:b3,\
:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )935;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)Value;
            sqlstm.sqhstl[2] = (unsigned long )100000;
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
            sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[4] = (unsigned long )20;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[5] = (unsigned long )10;
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[6] = (unsigned long )102;
            sqlstm.sqhsts[6] = (         int  )0;
            sqlstm.sqindv[6] = (         short *)0;
            sqlstm.sqinds[6] = (         int  )0;
            sqlstm.sqharm[6] = (unsigned long )0;
            sqlstm.sqadto[6] = (unsigned short )0;
            sqlstm.sqtdso[6] = (unsigned short )0;
            sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[7] = (         int  )0;
            sqlstm.sqindv[7] = (         short *)0;
            sqlstm.sqinds[7] = (         int  )0;
            sqlstm.sqharm[7] = (unsigned long )0;
            sqlstm.sqadto[7] = (unsigned short )0;
            sqlstm.sqtdso[7] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}



            strcpy(Value,value2.c_str());

            /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,4,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENTITY\
_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PO\
RT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,4,:b2,:b3,\
:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )982;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)Value;
            sqlstm.sqhstl[2] = (unsigned long )100000;
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
            sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[4] = (unsigned long )20;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[5] = (unsigned long )10;
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[6] = (unsigned long )102;
            sqlstm.sqhsts[6] = (         int  )0;
            sqlstm.sqindv[6] = (         short *)0;
            sqlstm.sqinds[6] = (         int  )0;
            sqlstm.sqharm[6] = (unsigned long )0;
            sqlstm.sqadto[6] = (unsigned short )0;
            sqlstm.sqtdso[6] = (unsigned short )0;
            sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[7] = (         int  )0;
            sqlstm.sqindv[7] = (         short *)0;
            sqlstm.sqinds[7] = (         int  )0;
            sqlstm.sqharm[7] = (unsigned long )0;
            sqlstm.sqadto[7] = (unsigned short )0;
            sqlstm.sqtdso[7] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}


            temp.erase(temp.find("<NETWORK>"),temp.find("</NETWORK>")+strlen("/NETWORK>")- temp.find("<NETWORK>")+1);
            found = temp.find("<NETWORK>");
         }
         if(0 == strcmp(g_ConObj.m_InstanceSp_DB.c_str(),"INST"))
            /* EXEC SQL INSERT INTO HLR_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CONFIG_VALUES (ENTITY_NAME,PARAM_\
ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYP\
E) values (:b0,:b1,:b2,:b3,'OS',to_date(:b4,'mm/dd/yyyy hh24:mi:ss'),:b5)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )1029;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[2] = (unsigned long )20;
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[3] = (unsigned long )10;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[4] = (unsigned long )102;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[5] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}



         /* EXEC SQL COMMIT; */ 

{
         struct sqlexd sqlstm;
         sqlstm.sqlvsn = 12;
         sqlstm.arrsiz = 8;
         sqlstm.sqladtp = &sqladt;
         sqlstm.sqltdsp = &sqltds;
         sqlstm.iters = (unsigned int  )1;
         sqlstm.offset = (unsigned int  )1068;
         sqlstm.cud = sqlcud0;
         sqlstm.sqlest = (unsigned char  *)&sqlca;
         sqlstm.sqlety = (unsigned short)256;
         sqlstm.occurs = (unsigned int  )0;
         sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
         if (sqlca.sqlcode < 0) goto sqlerr;
}


      }
      else if(first == 110)
      {
         Param_ID = first;
         int found;
         string temp =  complexMap.find(first)->second; 
         string searchFora ("<CODE_");    
         found = temp.find( searchFora );
         if(found == -1)
         {
            Count_Val++;
            /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,5,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENTITY\
_NAME,PARAM_ID,SUB_PARAM_ID,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDA\
TED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,5,:b2,:b3,:b4,'OS',to_\
date(:b5,'mm/dd/yyyy hh24:mi:ss'),:b6)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )1083;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)&Count_Val;
            sqlstm.sqhstl[2] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[3] = (unsigned long )20;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[4] = (unsigned long )10;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[5] = (unsigned long )102;
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqhstv[6] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[6] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[6] = (         int  )0;
            sqlstm.sqindv[6] = (         short *)0;
            sqlstm.sqinds[6] = (         int  )0;
            sqlstm.sqharm[6] = (unsigned long )0;
            sqlstm.sqadto[6] = (unsigned short )0;
            sqlstm.sqtdso[6] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}



         }
         else
         {
            while(found != string::npos) 
            {  
               string replaceBya ("<CODE>");
               temp.replace( found, strlen("<CODE_00>"), replaceBya );
               searchFora = "</CODE_";    
               replaceBya = "</CODE>";
               found = temp.find( searchFora );
               temp.replace( found,strlen("</CODE_00>"), replaceBya );
               string searchFora ("<CODE_");    
               found = temp.find( searchFora );
            }
            found = temp.find("<CODE>");
            while(found != string::npos)
            {
               int fir = temp.find("<CODE>")+strlen("CODE>")+1;
               int last =temp.find("</CODE>");
               string value1 = temp.substr(fir,last-fir);
               Param_ID = first ;
               strcpy(Value,value1.c_str());
               Count_Val++;
               /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,5,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
               struct sqlexd sqlstm;
               sqlstm.sqlvsn = 12;
               sqlstm.arrsiz = 8;
               sqlstm.sqladtp = &sqladt;
               sqlstm.sqltdsp = &sqltds;
               sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENT\
ITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING\
_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,5,:b2,:\
b3,:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
               sqlstm.iters = (unsigned int  )1;
               sqlstm.offset = (unsigned int  )1126;
               sqlstm.cud = sqlcud0;
               sqlstm.sqlest = (unsigned char  *)&sqlca;
               sqlstm.sqlety = (unsigned short)256;
               sqlstm.occurs = (unsigned int  )0;
               sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
               sqlstm.sqhstl[0] = (unsigned long )20;
               sqlstm.sqhsts[0] = (         int  )0;
               sqlstm.sqindv[0] = (         short *)0;
               sqlstm.sqinds[0] = (         int  )0;
               sqlstm.sqharm[0] = (unsigned long )0;
               sqlstm.sqadto[0] = (unsigned short )0;
               sqlstm.sqtdso[0] = (unsigned short )0;
               sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
               sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[1] = (         int  )0;
               sqlstm.sqindv[1] = (         short *)0;
               sqlstm.sqinds[1] = (         int  )0;
               sqlstm.sqharm[1] = (unsigned long )0;
               sqlstm.sqadto[1] = (unsigned short )0;
               sqlstm.sqtdso[1] = (unsigned short )0;
               sqlstm.sqhstv[2] = (unsigned char  *)Value;
               sqlstm.sqhstl[2] = (unsigned long )100000;
               sqlstm.sqhsts[2] = (         int  )0;
               sqlstm.sqindv[2] = (         short *)0;
               sqlstm.sqinds[2] = (         int  )0;
               sqlstm.sqharm[2] = (unsigned long )0;
               sqlstm.sqadto[2] = (unsigned short )0;
               sqlstm.sqtdso[2] = (unsigned short )0;
               sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
               sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[3] = (         int  )0;
               sqlstm.sqindv[3] = (         short *)0;
               sqlstm.sqinds[3] = (         int  )0;
               sqlstm.sqharm[3] = (unsigned long )0;
               sqlstm.sqadto[3] = (unsigned short )0;
               sqlstm.sqtdso[3] = (unsigned short )0;
               sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
               sqlstm.sqhstl[4] = (unsigned long )20;
               sqlstm.sqhsts[4] = (         int  )0;
               sqlstm.sqindv[4] = (         short *)0;
               sqlstm.sqinds[4] = (         int  )0;
               sqlstm.sqharm[4] = (unsigned long )0;
               sqlstm.sqadto[4] = (unsigned short )0;
               sqlstm.sqtdso[4] = (unsigned short )0;
               sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
               sqlstm.sqhstl[5] = (unsigned long )10;
               sqlstm.sqhsts[5] = (         int  )0;
               sqlstm.sqindv[5] = (         short *)0;
               sqlstm.sqinds[5] = (         int  )0;
               sqlstm.sqharm[5] = (unsigned long )0;
               sqlstm.sqadto[5] = (unsigned short )0;
               sqlstm.sqtdso[5] = (unsigned short )0;
               sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
               sqlstm.sqhstl[6] = (unsigned long )102;
               sqlstm.sqhsts[6] = (         int  )0;
               sqlstm.sqindv[6] = (         short *)0;
               sqlstm.sqinds[6] = (         int  )0;
               sqlstm.sqharm[6] = (unsigned long )0;
               sqlstm.sqadto[6] = (unsigned short )0;
               sqlstm.sqtdso[6] = (unsigned short )0;
               sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
               sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[7] = (         int  )0;
               sqlstm.sqindv[7] = (         short *)0;
               sqlstm.sqinds[7] = (         int  )0;
               sqlstm.sqharm[7] = (unsigned long )0;
               sqlstm.sqadto[7] = (unsigned short )0;
               sqlstm.sqtdso[7] = (unsigned short )0;
               sqlstm.sqphsv = sqlstm.sqhstv;
               sqlstm.sqphsl = sqlstm.sqhstl;
               sqlstm.sqphss = sqlstm.sqhsts;
               sqlstm.sqpind = sqlstm.sqindv;
               sqlstm.sqpins = sqlstm.sqinds;
               sqlstm.sqparm = sqlstm.sqharm;
               sqlstm.sqparc = sqlstm.sqharc;
               sqlstm.sqpadto = sqlstm.sqadto;
               sqlstm.sqptdso = sqlstm.sqtdso;
               sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
               if (sqlca.sqlcode < 0) goto sqlerr;
}


               temp.erase(temp.find("<CODE>"),temp.find("</CODE>")+strlen("/CODE>")- temp.find("<CODE>")+1);
               found = temp.find("<CODE>");
            }
         }
         if(0 == strcmp(g_ConObj.m_InstanceSp_DB.c_str(),"INST"))
            /* EXEC SQL INSERT INTO HLR_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CONFIG_VALUES (ENTITY_NAME,PARAM_\
ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYP\
E) values (:b0,:b1,:b2,:b3,'OS',to_date(:b4,'mm/dd/yyyy hh24:mi:ss'),:b5)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )1173;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[2] = (unsigned long )20;
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[3] = (unsigned long )10;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[4] = (unsigned long )102;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[5] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}



         /* EXEC SQL COMMIT; */ 

{
         struct sqlexd sqlstm;
         sqlstm.sqlvsn = 12;
         sqlstm.arrsiz = 8;
         sqlstm.sqladtp = &sqladt;
         sqlstm.sqltdsp = &sqltds;
         sqlstm.iters = (unsigned int  )1;
         sqlstm.offset = (unsigned int  )1212;
         sqlstm.cud = sqlcud0;
         sqlstm.sqlest = (unsigned char  *)&sqlca;
         sqlstm.sqlety = (unsigned short)256;
         sqlstm.occurs = (unsigned int  )0;
         sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
         if (sqlca.sqlcode < 0) goto sqlerr;
}


      }
      else if(first == 116)
      {

         Param_ID = first;
         int found;
         string temp =  complexMap.find(first)->second; 
         string searchFora = "<INSTANCE_";
         found  = temp.find(searchFora);
         if(found == -1)
         {
            ELOG(0,0,"!!!!!!!!!! INSTANCE Tag not Found in MAPR!!!!!!!!");
         }
         else
         {
            while(found != string::npos)
            {
               string replaceBya ("<INSTANCE>");
               temp.replace( found, strlen("<INSTANCE_00>"), replaceBya );
               searchFora = "</INSTANCE_";    
               replaceBya = "</INSTANCE>";
               found = temp.find( searchFora );
               temp.replace( found,strlen("</INSTANCE_00>"), replaceBya );
               string searchFora ("<INSTANCE_");    
               found = temp.find( searchFora );
            }
            found = temp.find("<INSTANCE>");
            while(found != string::npos)
            {
               int fir = temp.find("<INSTANCE>")+strlen("INSTANCE>")+1;
               int last =temp.find("</INSTANCE>");
               string value1 = temp.substr(fir,last-fir);
               string value2 = Parser::getValue(value1,"MAPR_IP");
               strcpy(Value,value2.c_str());
               Count_Val++;
               /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,6,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
               struct sqlexd sqlstm;
               sqlstm.sqlvsn = 12;
               sqlstm.arrsiz = 8;
               sqlstm.sqladtp = &sqladt;
               sqlstm.sqltdsp = &sqltds;
               sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENT\
ITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING\
_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,6,:b2,:\
b3,:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
               sqlstm.iters = (unsigned int  )1;
               sqlstm.offset = (unsigned int  )1227;
               sqlstm.cud = sqlcud0;
               sqlstm.sqlest = (unsigned char  *)&sqlca;
               sqlstm.sqlety = (unsigned short)256;
               sqlstm.occurs = (unsigned int  )0;
               sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
               sqlstm.sqhstl[0] = (unsigned long )20;
               sqlstm.sqhsts[0] = (         int  )0;
               sqlstm.sqindv[0] = (         short *)0;
               sqlstm.sqinds[0] = (         int  )0;
               sqlstm.sqharm[0] = (unsigned long )0;
               sqlstm.sqadto[0] = (unsigned short )0;
               sqlstm.sqtdso[0] = (unsigned short )0;
               sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
               sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[1] = (         int  )0;
               sqlstm.sqindv[1] = (         short *)0;
               sqlstm.sqinds[1] = (         int  )0;
               sqlstm.sqharm[1] = (unsigned long )0;
               sqlstm.sqadto[1] = (unsigned short )0;
               sqlstm.sqtdso[1] = (unsigned short )0;
               sqlstm.sqhstv[2] = (unsigned char  *)Value;
               sqlstm.sqhstl[2] = (unsigned long )100000;
               sqlstm.sqhsts[2] = (         int  )0;
               sqlstm.sqindv[2] = (         short *)0;
               sqlstm.sqinds[2] = (         int  )0;
               sqlstm.sqharm[2] = (unsigned long )0;
               sqlstm.sqadto[2] = (unsigned short )0;
               sqlstm.sqtdso[2] = (unsigned short )0;
               sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
               sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[3] = (         int  )0;
               sqlstm.sqindv[3] = (         short *)0;
               sqlstm.sqinds[3] = (         int  )0;
               sqlstm.sqharm[3] = (unsigned long )0;
               sqlstm.sqadto[3] = (unsigned short )0;
               sqlstm.sqtdso[3] = (unsigned short )0;
               sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
               sqlstm.sqhstl[4] = (unsigned long )20;
               sqlstm.sqhsts[4] = (         int  )0;
               sqlstm.sqindv[4] = (         short *)0;
               sqlstm.sqinds[4] = (         int  )0;
               sqlstm.sqharm[4] = (unsigned long )0;
               sqlstm.sqadto[4] = (unsigned short )0;
               sqlstm.sqtdso[4] = (unsigned short )0;
               sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
               sqlstm.sqhstl[5] = (unsigned long )10;
               sqlstm.sqhsts[5] = (         int  )0;
               sqlstm.sqindv[5] = (         short *)0;
               sqlstm.sqinds[5] = (         int  )0;
               sqlstm.sqharm[5] = (unsigned long )0;
               sqlstm.sqadto[5] = (unsigned short )0;
               sqlstm.sqtdso[5] = (unsigned short )0;
               sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
               sqlstm.sqhstl[6] = (unsigned long )102;
               sqlstm.sqhsts[6] = (         int  )0;
               sqlstm.sqindv[6] = (         short *)0;
               sqlstm.sqinds[6] = (         int  )0;
               sqlstm.sqharm[6] = (unsigned long )0;
               sqlstm.sqadto[6] = (unsigned short )0;
               sqlstm.sqtdso[6] = (unsigned short )0;
               sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
               sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[7] = (         int  )0;
               sqlstm.sqindv[7] = (         short *)0;
               sqlstm.sqinds[7] = (         int  )0;
               sqlstm.sqharm[7] = (unsigned long )0;
               sqlstm.sqadto[7] = (unsigned short )0;
               sqlstm.sqtdso[7] = (unsigned short )0;
               sqlstm.sqphsv = sqlstm.sqhstv;
               sqlstm.sqphsl = sqlstm.sqhstl;
               sqlstm.sqphss = sqlstm.sqhsts;
               sqlstm.sqpind = sqlstm.sqindv;
               sqlstm.sqpins = sqlstm.sqinds;
               sqlstm.sqparm = sqlstm.sqharm;
               sqlstm.sqparc = sqlstm.sqharc;
               sqlstm.sqpadto = sqlstm.sqadto;
               sqlstm.sqptdso = sqlstm.sqtdso;
               sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
               if (sqlca.sqlcode < 0) goto sqlerr;
}


               value2 = Parser::getValue(value1,"MAPR_PORT");
               strcpy(Value,value2.c_str());
               /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,7,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
               struct sqlexd sqlstm;
               sqlstm.sqlvsn = 12;
               sqlstm.arrsiz = 8;
               sqlstm.sqladtp = &sqladt;
               sqlstm.sqltdsp = &sqltds;
               sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENT\
ITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING\
_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,7,:b2,:\
b3,:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
               sqlstm.iters = (unsigned int  )1;
               sqlstm.offset = (unsigned int  )1274;
               sqlstm.cud = sqlcud0;
               sqlstm.sqlest = (unsigned char  *)&sqlca;
               sqlstm.sqlety = (unsigned short)256;
               sqlstm.occurs = (unsigned int  )0;
               sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
               sqlstm.sqhstl[0] = (unsigned long )20;
               sqlstm.sqhsts[0] = (         int  )0;
               sqlstm.sqindv[0] = (         short *)0;
               sqlstm.sqinds[0] = (         int  )0;
               sqlstm.sqharm[0] = (unsigned long )0;
               sqlstm.sqadto[0] = (unsigned short )0;
               sqlstm.sqtdso[0] = (unsigned short )0;
               sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
               sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[1] = (         int  )0;
               sqlstm.sqindv[1] = (         short *)0;
               sqlstm.sqinds[1] = (         int  )0;
               sqlstm.sqharm[1] = (unsigned long )0;
               sqlstm.sqadto[1] = (unsigned short )0;
               sqlstm.sqtdso[1] = (unsigned short )0;
               sqlstm.sqhstv[2] = (unsigned char  *)Value;
               sqlstm.sqhstl[2] = (unsigned long )100000;
               sqlstm.sqhsts[2] = (         int  )0;
               sqlstm.sqindv[2] = (         short *)0;
               sqlstm.sqinds[2] = (         int  )0;
               sqlstm.sqharm[2] = (unsigned long )0;
               sqlstm.sqadto[2] = (unsigned short )0;
               sqlstm.sqtdso[2] = (unsigned short )0;
               sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
               sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[3] = (         int  )0;
               sqlstm.sqindv[3] = (         short *)0;
               sqlstm.sqinds[3] = (         int  )0;
               sqlstm.sqharm[3] = (unsigned long )0;
               sqlstm.sqadto[3] = (unsigned short )0;
               sqlstm.sqtdso[3] = (unsigned short )0;
               sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
               sqlstm.sqhstl[4] = (unsigned long )20;
               sqlstm.sqhsts[4] = (         int  )0;
               sqlstm.sqindv[4] = (         short *)0;
               sqlstm.sqinds[4] = (         int  )0;
               sqlstm.sqharm[4] = (unsigned long )0;
               sqlstm.sqadto[4] = (unsigned short )0;
               sqlstm.sqtdso[4] = (unsigned short )0;
               sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
               sqlstm.sqhstl[5] = (unsigned long )10;
               sqlstm.sqhsts[5] = (         int  )0;
               sqlstm.sqindv[5] = (         short *)0;
               sqlstm.sqinds[5] = (         int  )0;
               sqlstm.sqharm[5] = (unsigned long )0;
               sqlstm.sqadto[5] = (unsigned short )0;
               sqlstm.sqtdso[5] = (unsigned short )0;
               sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
               sqlstm.sqhstl[6] = (unsigned long )102;
               sqlstm.sqhsts[6] = (         int  )0;
               sqlstm.sqindv[6] = (         short *)0;
               sqlstm.sqinds[6] = (         int  )0;
               sqlstm.sqharm[6] = (unsigned long )0;
               sqlstm.sqadto[6] = (unsigned short )0;
               sqlstm.sqtdso[6] = (unsigned short )0;
               sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
               sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[7] = (         int  )0;
               sqlstm.sqindv[7] = (         short *)0;
               sqlstm.sqinds[7] = (         int  )0;
               sqlstm.sqharm[7] = (unsigned long )0;
               sqlstm.sqadto[7] = (unsigned short )0;
               sqlstm.sqtdso[7] = (unsigned short )0;
               sqlstm.sqphsv = sqlstm.sqhstv;
               sqlstm.sqphsl = sqlstm.sqhstl;
               sqlstm.sqphss = sqlstm.sqhsts;
               sqlstm.sqpind = sqlstm.sqindv;
               sqlstm.sqpins = sqlstm.sqinds;
               sqlstm.sqparm = sqlstm.sqharm;
               sqlstm.sqparc = sqlstm.sqharc;
               sqlstm.sqpadto = sqlstm.sqadto;
               sqlstm.sqptdso = sqlstm.sqtdso;
               sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
               if (sqlca.sqlcode < 0) goto sqlerr;
}


               temp.erase(temp.find("<INSTANCE>"),temp.find("</INSTANCE>")+strlen("/INSTANCE>")- temp.find("<INSTANCE>")+1);
               found = temp.find("<INSTANCE>");
            }
         }
         if(0 == strcmp(g_ConObj.m_InstanceSp_DB.c_str(),"INST"))
            /* EXEC SQL INSERT INTO HLR_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CONFIG_VALUES (ENTITY_NAME,PARAM_\
ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYP\
E) values (:b0,:b1,:b2,:b3,'OS',to_date(:b4,'mm/dd/yyyy hh24:mi:ss'),:b5)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )1321;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[2] = (unsigned long )20;
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[3] = (unsigned long )10;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[4] = (unsigned long )102;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[5] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}




         /* EXEC SQL COMMIT; */ 

{
         struct sqlexd sqlstm;
         sqlstm.sqlvsn = 12;
         sqlstm.arrsiz = 8;
         sqlstm.sqladtp = &sqladt;
         sqlstm.sqltdsp = &sqltds;
         sqlstm.iters = (unsigned int  )1;
         sqlstm.offset = (unsigned int  )1360;
         sqlstm.cud = sqlcud0;
         sqlstm.sqlest = (unsigned char  *)&sqlca;
         sqlstm.sqlety = (unsigned short)256;
         sqlstm.occurs = (unsigned int  )0;
         sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
         if (sqlca.sqlcode < 0) goto sqlerr;
}


      }
      else if(first == 117)
      {
         Param_ID = first;
         int found;
         string temp =  complexMap.find(first)->second; 
         string searchFora ("<CODE_");    
         found = temp.find( searchFora );
         if(found == -1)
         {
            Count_Val++;
            /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,8,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENTITY\
_NAME,PARAM_ID,SUB_PARAM_ID,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDA\
TED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,8,:b2,:b3,:b4,'OS',to_\
date(:b5,'mm/dd/yyyy hh24:mi:ss'),:b6)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )1375;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)&Count_Val;
            sqlstm.sqhstl[2] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[3] = (unsigned long )20;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[4] = (unsigned long )10;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[5] = (unsigned long )102;
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqhstv[6] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[6] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[6] = (         int  )0;
            sqlstm.sqindv[6] = (         short *)0;
            sqlstm.sqinds[6] = (         int  )0;
            sqlstm.sqharm[6] = (unsigned long )0;
            sqlstm.sqadto[6] = (unsigned short )0;
            sqlstm.sqtdso[6] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}



         }
         else
         {
            while(found != string::npos) 
            {  
               string replaceBya ("<CODE>");
               temp.replace( found, strlen("<CODE_00>"), replaceBya );
               searchFora = "</CODE_";    
               replaceBya = "</CODE>";
               found = temp.find( searchFora );
               temp.replace( found,strlen("</CODE_00>"), replaceBya );
               string searchFora ("<CODE_");    
               found = temp.find( searchFora );
            }
            found = temp.find("<CODE>");
            while(found != string::npos)
            {
               int fir = temp.find("<CODE>")+strlen("CODE>")+1;
               int last =temp.find("</CODE>");
               string value1 = temp.substr(fir,last-fir);
               Param_ID = first ;
               strcpy(Value,value1.c_str());
               Count_Val++;
               /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,8,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
               struct sqlexd sqlstm;
               sqlstm.sqlvsn = 12;
               sqlstm.arrsiz = 8;
               sqlstm.sqladtp = &sqladt;
               sqlstm.sqltdsp = &sqltds;
               sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENT\
ITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING\
_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,8,:b2,:\
b3,:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
               sqlstm.iters = (unsigned int  )1;
               sqlstm.offset = (unsigned int  )1418;
               sqlstm.cud = sqlcud0;
               sqlstm.sqlest = (unsigned char  *)&sqlca;
               sqlstm.sqlety = (unsigned short)256;
               sqlstm.occurs = (unsigned int  )0;
               sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
               sqlstm.sqhstl[0] = (unsigned long )20;
               sqlstm.sqhsts[0] = (         int  )0;
               sqlstm.sqindv[0] = (         short *)0;
               sqlstm.sqinds[0] = (         int  )0;
               sqlstm.sqharm[0] = (unsigned long )0;
               sqlstm.sqadto[0] = (unsigned short )0;
               sqlstm.sqtdso[0] = (unsigned short )0;
               sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
               sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[1] = (         int  )0;
               sqlstm.sqindv[1] = (         short *)0;
               sqlstm.sqinds[1] = (         int  )0;
               sqlstm.sqharm[1] = (unsigned long )0;
               sqlstm.sqadto[1] = (unsigned short )0;
               sqlstm.sqtdso[1] = (unsigned short )0;
               sqlstm.sqhstv[2] = (unsigned char  *)Value;
               sqlstm.sqhstl[2] = (unsigned long )100000;
               sqlstm.sqhsts[2] = (         int  )0;
               sqlstm.sqindv[2] = (         short *)0;
               sqlstm.sqinds[2] = (         int  )0;
               sqlstm.sqharm[2] = (unsigned long )0;
               sqlstm.sqadto[2] = (unsigned short )0;
               sqlstm.sqtdso[2] = (unsigned short )0;
               sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
               sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[3] = (         int  )0;
               sqlstm.sqindv[3] = (         short *)0;
               sqlstm.sqinds[3] = (         int  )0;
               sqlstm.sqharm[3] = (unsigned long )0;
               sqlstm.sqadto[3] = (unsigned short )0;
               sqlstm.sqtdso[3] = (unsigned short )0;
               sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
               sqlstm.sqhstl[4] = (unsigned long )20;
               sqlstm.sqhsts[4] = (         int  )0;
               sqlstm.sqindv[4] = (         short *)0;
               sqlstm.sqinds[4] = (         int  )0;
               sqlstm.sqharm[4] = (unsigned long )0;
               sqlstm.sqadto[4] = (unsigned short )0;
               sqlstm.sqtdso[4] = (unsigned short )0;
               sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
               sqlstm.sqhstl[5] = (unsigned long )10;
               sqlstm.sqhsts[5] = (         int  )0;
               sqlstm.sqindv[5] = (         short *)0;
               sqlstm.sqinds[5] = (         int  )0;
               sqlstm.sqharm[5] = (unsigned long )0;
               sqlstm.sqadto[5] = (unsigned short )0;
               sqlstm.sqtdso[5] = (unsigned short )0;
               sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
               sqlstm.sqhstl[6] = (unsigned long )102;
               sqlstm.sqhsts[6] = (         int  )0;
               sqlstm.sqindv[6] = (         short *)0;
               sqlstm.sqinds[6] = (         int  )0;
               sqlstm.sqharm[6] = (unsigned long )0;
               sqlstm.sqadto[6] = (unsigned short )0;
               sqlstm.sqtdso[6] = (unsigned short )0;
               sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
               sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[7] = (         int  )0;
               sqlstm.sqindv[7] = (         short *)0;
               sqlstm.sqinds[7] = (         int  )0;
               sqlstm.sqharm[7] = (unsigned long )0;
               sqlstm.sqadto[7] = (unsigned short )0;
               sqlstm.sqtdso[7] = (unsigned short )0;
               sqlstm.sqphsv = sqlstm.sqhstv;
               sqlstm.sqphsl = sqlstm.sqhstl;
               sqlstm.sqphss = sqlstm.sqhsts;
               sqlstm.sqpind = sqlstm.sqindv;
               sqlstm.sqpins = sqlstm.sqinds;
               sqlstm.sqparm = sqlstm.sqharm;
               sqlstm.sqparc = sqlstm.sqharc;
               sqlstm.sqpadto = sqlstm.sqadto;
               sqlstm.sqptdso = sqlstm.sqtdso;
               sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
               if (sqlca.sqlcode < 0) goto sqlerr;
}


               temp.erase(temp.find("<CODE>"),temp.find("</CODE>")+strlen("/CODE>")- temp.find("<CODE>")+1);
               found = temp.find("<CODE>");
            }
         }
         if(0 == strcmp(g_ConObj.m_InstanceSp_DB.c_str(),"INST"))
            /* EXEC SQL INSERT INTO HLR_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CONFIG_VALUES (ENTITY_NAME,PARAM_\
ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYP\
E) values (:b0,:b1,:b2,:b3,'OS',to_date(:b4,'mm/dd/yyyy hh24:mi:ss'),:b5)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )1465;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[2] = (unsigned long )20;
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[3] = (unsigned long )10;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[4] = (unsigned long )102;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[5] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}




         /* EXEC SQL COMMIT; */ 

{
         struct sqlexd sqlstm;
         sqlstm.sqlvsn = 12;
         sqlstm.arrsiz = 8;
         sqlstm.sqladtp = &sqladt;
         sqlstm.sqltdsp = &sqltds;
         sqlstm.iters = (unsigned int  )1;
         sqlstm.offset = (unsigned int  )1504;
         sqlstm.cud = sqlcud0;
         sqlstm.sqlest = (unsigned char  *)&sqlca;
         sqlstm.sqlety = (unsigned short)256;
         sqlstm.occurs = (unsigned int  )0;
         sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
         if (sqlca.sqlcode < 0) goto sqlerr;
}


      }
      if(first == 126)
      {
         Param_ID = first;
         int found;

         string HLR_NETWORK = (string)g_ConObj.m_ModuleMap.find(1)->second;

         string searchFora ("<NETWORK_");    

         found = HLR_NETWORK.find( searchFora );


         while(found != string::npos) 
         {  

            string replaceBya ("<NETWORK>");
            HLR_NETWORK.replace( found, strlen("<NETWORK_00>"), replaceBya );
            searchFora = "</NETWORK_";    
            replaceBya = "</NETWORK>";
            found = HLR_NETWORK.find( searchFora );

            HLR_NETWORK.replace( found,strlen("</NETWORK_00>"), replaceBya );
            string searchFora ("<NETWORK_");    
            found = HLR_NETWORK.find( searchFora );
         }

         string temp =  complexMap.find(first)->second; 


         searchFora = "<NETWORK_";    

         found = temp.find( searchFora );

         while(found != string::npos) 
         {  
            string replaceBya ("<NETWORK>");
            temp.replace( found, strlen("<NETWORK_00>"), replaceBya );
            searchFora = "</NETWORK_";    
            replaceBya = "</NETWORK>";
            found = temp.find( searchFora );
            temp.replace( found,strlen("</NETWORK_00>"), replaceBya );
            string searchFora ("<NETWORK_");    
            found = temp.find( searchFora );
         }

         found = HLR_NETWORK.find("<NETWORK>");
         while(found != string::npos)
         {
            int fir = HLR_NETWORK.find("<NETWORK>")+strlen("NETWORK>")+1;
            int last =HLR_NETWORK.find("</NETWORK>");
            string value1 = HLR_NETWORK.substr(fir,last-fir);
            HLR_NETWORK.erase(HLR_NETWORK.find("<NETWORK>"),HLR_NETWORK.find("</NETWORK>")+strlen("/NETWORK>")- HLR_NETWORK.find("<NETWORK>")+1);

            found = temp.find("<NETWORK>");


            fir = temp.find("<NETWORK>")+strlen("NETWORK>")+1;
            last =temp.find("</NETWORK>");
            string value2 = temp.substr(fir,last-fir);

            //               value2 = value1+":"+value2;
            strcpy(Value,value1.c_str());
            Count_Val++;

            //if(0 != strcmp(g_ConObj.m_InstanceSp_DB.c_str(),"INST"))
            /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,9,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENTITY\
_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PO\
RT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,9,:b2,:b3,\
:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )1519;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)Value;
            sqlstm.sqhstl[2] = (unsigned long )100000;
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
            sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[4] = (unsigned long )20;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[5] = (unsigned long )10;
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[6] = (unsigned long )102;
            sqlstm.sqhsts[6] = (         int  )0;
            sqlstm.sqindv[6] = (         short *)0;
            sqlstm.sqinds[6] = (         int  )0;
            sqlstm.sqharm[6] = (unsigned long )0;
            sqlstm.sqadto[6] = (unsigned short )0;
            sqlstm.sqtdso[6] = (unsigned short )0;
            sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[7] = (         int  )0;
            sqlstm.sqindv[7] = (         short *)0;
            sqlstm.sqinds[7] = (         int  )0;
            sqlstm.sqharm[7] = (unsigned long )0;
            sqlstm.sqadto[7] = (unsigned short )0;
            sqlstm.sqtdso[7] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}





            strcpy(Value,value2.c_str());

            /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,10,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENTITY\
_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PO\
RT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,10,:b2,:b3\
,:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )1566;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)Value;
            sqlstm.sqhstl[2] = (unsigned long )100000;
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
            sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[4] = (unsigned long )20;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[5] = (unsigned long )10;
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[6] = (unsigned long )102;
            sqlstm.sqhsts[6] = (         int  )0;
            sqlstm.sqindv[6] = (         short *)0;
            sqlstm.sqinds[6] = (         int  )0;
            sqlstm.sqharm[6] = (unsigned long )0;
            sqlstm.sqadto[6] = (unsigned short )0;
            sqlstm.sqtdso[6] = (unsigned short )0;
            sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[7] = (         int  )0;
            sqlstm.sqindv[7] = (         short *)0;
            sqlstm.sqinds[7] = (         int  )0;
            sqlstm.sqharm[7] = (unsigned long )0;
            sqlstm.sqadto[7] = (unsigned short )0;
            sqlstm.sqtdso[7] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}





            temp.erase(temp.find("<NETWORK>"),temp.find("</NETWORK>")+strlen("/NETWORK>")- temp.find("<NETWORK>")+1);
            found = temp.find("<NETWORK>");

         }
         if(0 == strcmp(g_ConObj.m_InstanceSp_DB.c_str(),"INST"))
            /* EXEC SQL INSERT INTO HLR_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CONFIG_VALUES (ENTITY_NAME,PARAM_\
ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYP\
E) values (:b0,:b1,:b2,:b3,'OS',to_date(:b4,'mm/dd/yyyy hh24:mi:ss'),:b5)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )1613;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[2] = (unsigned long )20;
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[3] = (unsigned long )10;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[4] = (unsigned long )102;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[5] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}




         /* EXEC SQL COMMIT; */ 

{
         struct sqlexd sqlstm;
         sqlstm.sqlvsn = 12;
         sqlstm.arrsiz = 8;
         sqlstm.sqladtp = &sqladt;
         sqlstm.sqltdsp = &sqltds;
         sqlstm.iters = (unsigned int  )1;
         sqlstm.offset = (unsigned int  )1652;
         sqlstm.cud = sqlcud0;
         sqlstm.sqlest = (unsigned char  *)&sqlca;
         sqlstm.sqlety = (unsigned short)256;
         sqlstm.occurs = (unsigned int  )0;
         sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
         if (sqlca.sqlcode < 0) goto sqlerr;
}


      }

      else if(first == 139)
      {


         Param_ID = first;
         int found;

         string temp =  complexMap.find(first)->second; 


         string searchFora ("<CODE_");    

         found = temp.find( searchFora );

         if(found == -1)
         {

            Count_Val++;
            /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,11,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENTITY\
_NAME,PARAM_ID,SUB_PARAM_ID,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDA\
TED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,11,:b2,:b3,:b4,'OS',to\
_date(:b5,'mm/dd/yyyy hh24:mi:ss'),:b6)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )1667;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)&Count_Val;
            sqlstm.sqhstl[2] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[3] = (unsigned long )20;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[4] = (unsigned long )10;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[5] = (unsigned long )102;
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqhstv[6] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[6] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[6] = (         int  )0;
            sqlstm.sqindv[6] = (         short *)0;
            sqlstm.sqinds[6] = (         int  )0;
            sqlstm.sqharm[6] = (unsigned long )0;
            sqlstm.sqadto[6] = (unsigned short )0;
            sqlstm.sqtdso[6] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}




         }
         else
         {

            while(found != string::npos) 
            {  

               string replaceBya ("<CODE>");
               temp.replace( found, strlen("<CODE_00>"), replaceBya );
               searchFora = "</CODE_";    
               replaceBya = "</CODE>";
               found = temp.find( searchFora );
               temp.replace( found,strlen("</CODE_00>"), replaceBya );
               string searchFora ("<CODE_");    
               found = temp.find( searchFora );
            }


            found = temp.find("<CODE>");
            while(found != string::npos)
            {
               int fir = temp.find("<CODE>")+strlen("CODE>")+1;
               int last =temp.find("</CODE>");
               string value1 = temp.substr(fir,last-fir);


               Param_ID = first ;
               strcpy(Value,value1.c_str());
               Count_Val++;
               /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,11,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
               struct sqlexd sqlstm;
               sqlstm.sqlvsn = 12;
               sqlstm.arrsiz = 8;
               sqlstm.sqladtp = &sqladt;
               sqlstm.sqltdsp = &sqltds;
               sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENT\
ITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING\
_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,11,:b2,\
:b3,:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
               sqlstm.iters = (unsigned int  )1;
               sqlstm.offset = (unsigned int  )1710;
               sqlstm.cud = sqlcud0;
               sqlstm.sqlest = (unsigned char  *)&sqlca;
               sqlstm.sqlety = (unsigned short)256;
               sqlstm.occurs = (unsigned int  )0;
               sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
               sqlstm.sqhstl[0] = (unsigned long )20;
               sqlstm.sqhsts[0] = (         int  )0;
               sqlstm.sqindv[0] = (         short *)0;
               sqlstm.sqinds[0] = (         int  )0;
               sqlstm.sqharm[0] = (unsigned long )0;
               sqlstm.sqadto[0] = (unsigned short )0;
               sqlstm.sqtdso[0] = (unsigned short )0;
               sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
               sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[1] = (         int  )0;
               sqlstm.sqindv[1] = (         short *)0;
               sqlstm.sqinds[1] = (         int  )0;
               sqlstm.sqharm[1] = (unsigned long )0;
               sqlstm.sqadto[1] = (unsigned short )0;
               sqlstm.sqtdso[1] = (unsigned short )0;
               sqlstm.sqhstv[2] = (unsigned char  *)Value;
               sqlstm.sqhstl[2] = (unsigned long )100000;
               sqlstm.sqhsts[2] = (         int  )0;
               sqlstm.sqindv[2] = (         short *)0;
               sqlstm.sqinds[2] = (         int  )0;
               sqlstm.sqharm[2] = (unsigned long )0;
               sqlstm.sqadto[2] = (unsigned short )0;
               sqlstm.sqtdso[2] = (unsigned short )0;
               sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
               sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[3] = (         int  )0;
               sqlstm.sqindv[3] = (         short *)0;
               sqlstm.sqinds[3] = (         int  )0;
               sqlstm.sqharm[3] = (unsigned long )0;
               sqlstm.sqadto[3] = (unsigned short )0;
               sqlstm.sqtdso[3] = (unsigned short )0;
               sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
               sqlstm.sqhstl[4] = (unsigned long )20;
               sqlstm.sqhsts[4] = (         int  )0;
               sqlstm.sqindv[4] = (         short *)0;
               sqlstm.sqinds[4] = (         int  )0;
               sqlstm.sqharm[4] = (unsigned long )0;
               sqlstm.sqadto[4] = (unsigned short )0;
               sqlstm.sqtdso[4] = (unsigned short )0;
               sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
               sqlstm.sqhstl[5] = (unsigned long )10;
               sqlstm.sqhsts[5] = (         int  )0;
               sqlstm.sqindv[5] = (         short *)0;
               sqlstm.sqinds[5] = (         int  )0;
               sqlstm.sqharm[5] = (unsigned long )0;
               sqlstm.sqadto[5] = (unsigned short )0;
               sqlstm.sqtdso[5] = (unsigned short )0;
               sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
               sqlstm.sqhstl[6] = (unsigned long )102;
               sqlstm.sqhsts[6] = (         int  )0;
               sqlstm.sqindv[6] = (         short *)0;
               sqlstm.sqinds[6] = (         int  )0;
               sqlstm.sqharm[6] = (unsigned long )0;
               sqlstm.sqadto[6] = (unsigned short )0;
               sqlstm.sqtdso[6] = (unsigned short )0;
               sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
               sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[7] = (         int  )0;
               sqlstm.sqindv[7] = (         short *)0;
               sqlstm.sqinds[7] = (         int  )0;
               sqlstm.sqharm[7] = (unsigned long )0;
               sqlstm.sqadto[7] = (unsigned short )0;
               sqlstm.sqtdso[7] = (unsigned short )0;
               sqlstm.sqphsv = sqlstm.sqhstv;
               sqlstm.sqphsl = sqlstm.sqhstl;
               sqlstm.sqphss = sqlstm.sqhsts;
               sqlstm.sqpind = sqlstm.sqindv;
               sqlstm.sqpins = sqlstm.sqinds;
               sqlstm.sqparm = sqlstm.sqharm;
               sqlstm.sqparc = sqlstm.sqharc;
               sqlstm.sqpadto = sqlstm.sqadto;
               sqlstm.sqptdso = sqlstm.sqtdso;
               sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
               if (sqlca.sqlcode < 0) goto sqlerr;
}





               temp.erase(temp.find("<CODE>"),temp.find("</CODE>")+strlen("/CODE>")- temp.find("<CODE>")+1);
               found = temp.find("<CODE>");

            }
         }
         if(0 == strcmp(g_ConObj.m_InstanceSp_DB.c_str(),"INST"))
            /* EXEC SQL INSERT INTO HLR_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CONFIG_VALUES (ENTITY_NAME,PARAM_\
ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYP\
E) values (:b0,:b1,:b2,:b3,'OS',to_date(:b4,'mm/dd/yyyy hh24:mi:ss'),:b5)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )1757;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[2] = (unsigned long )20;
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[3] = (unsigned long )10;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[4] = (unsigned long )102;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[5] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}






         /* EXEC SQL COMMIT; */ 

{
         struct sqlexd sqlstm;
         sqlstm.sqlvsn = 12;
         sqlstm.arrsiz = 8;
         sqlstm.sqladtp = &sqladt;
         sqlstm.sqltdsp = &sqltds;
         sqlstm.iters = (unsigned int  )1;
         sqlstm.offset = (unsigned int  )1796;
         sqlstm.cud = sqlcud0;
         sqlstm.sqlest = (unsigned char  *)&sqlca;
         sqlstm.sqlety = (unsigned short)256;
         sqlstm.occurs = (unsigned int  )0;
         sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
         if (sqlca.sqlcode < 0) goto sqlerr;
}



      }
      else if(first == 140)
      {


         Param_ID = first;
         int found;

         string temp =  complexMap.find(first)->second; 


         string searchFora ("<CODE_");    

         found = temp.find( searchFora );

         if(found == -1)
         {

            Count_Val++;
            /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,12,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENTITY\
_NAME,PARAM_ID,SUB_PARAM_ID,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDA\
TED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,12,:b2,:b3,:b4,'OS',to\
_date(:b5,'mm/dd/yyyy hh24:mi:ss'),:b6)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )1811;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)&Count_Val;
            sqlstm.sqhstl[2] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[3] = (unsigned long )20;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[4] = (unsigned long )10;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[5] = (unsigned long )102;
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqhstv[6] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[6] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[6] = (         int  )0;
            sqlstm.sqindv[6] = (         short *)0;
            sqlstm.sqinds[6] = (         int  )0;
            sqlstm.sqharm[6] = (unsigned long )0;
            sqlstm.sqadto[6] = (unsigned short )0;
            sqlstm.sqtdso[6] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}



         }
         else
         {

            while(found != string::npos) 
            {  

               string replaceBya ("<CODE>");
               temp.replace( found, strlen("<CODE_00>"), replaceBya );
               searchFora = "</CODE_";    
               replaceBya = "</CODE>";
               found = temp.find( searchFora );
               temp.replace( found,strlen("</CODE_00>"), replaceBya );
               string searchFora ("<CODE_");    
               found = temp.find( searchFora );
            }


            found = temp.find("<CODE>");
            while(found != string::npos)
            {
               int fir = temp.find("<CODE>")+strlen("CODE>")+1;
               int last =temp.find("</CODE>");
               string value1 = temp.substr(fir,last-fir);


               Param_ID = first ;
               strcpy(Value,value1.c_str());
               Count_Val++;
               /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,12,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
               struct sqlexd sqlstm;
               sqlstm.sqlvsn = 12;
               sqlstm.arrsiz = 8;
               sqlstm.sqladtp = &sqladt;
               sqlstm.sqltdsp = &sqltds;
               sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENT\
ITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING\
_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,12,:b2,\
:b3,:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
               sqlstm.iters = (unsigned int  )1;
               sqlstm.offset = (unsigned int  )1854;
               sqlstm.cud = sqlcud0;
               sqlstm.sqlest = (unsigned char  *)&sqlca;
               sqlstm.sqlety = (unsigned short)256;
               sqlstm.occurs = (unsigned int  )0;
               sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
               sqlstm.sqhstl[0] = (unsigned long )20;
               sqlstm.sqhsts[0] = (         int  )0;
               sqlstm.sqindv[0] = (         short *)0;
               sqlstm.sqinds[0] = (         int  )0;
               sqlstm.sqharm[0] = (unsigned long )0;
               sqlstm.sqadto[0] = (unsigned short )0;
               sqlstm.sqtdso[0] = (unsigned short )0;
               sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
               sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[1] = (         int  )0;
               sqlstm.sqindv[1] = (         short *)0;
               sqlstm.sqinds[1] = (         int  )0;
               sqlstm.sqharm[1] = (unsigned long )0;
               sqlstm.sqadto[1] = (unsigned short )0;
               sqlstm.sqtdso[1] = (unsigned short )0;
               sqlstm.sqhstv[2] = (unsigned char  *)Value;
               sqlstm.sqhstl[2] = (unsigned long )100000;
               sqlstm.sqhsts[2] = (         int  )0;
               sqlstm.sqindv[2] = (         short *)0;
               sqlstm.sqinds[2] = (         int  )0;
               sqlstm.sqharm[2] = (unsigned long )0;
               sqlstm.sqadto[2] = (unsigned short )0;
               sqlstm.sqtdso[2] = (unsigned short )0;
               sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
               sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[3] = (         int  )0;
               sqlstm.sqindv[3] = (         short *)0;
               sqlstm.sqinds[3] = (         int  )0;
               sqlstm.sqharm[3] = (unsigned long )0;
               sqlstm.sqadto[3] = (unsigned short )0;
               sqlstm.sqtdso[3] = (unsigned short )0;
               sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
               sqlstm.sqhstl[4] = (unsigned long )20;
               sqlstm.sqhsts[4] = (         int  )0;
               sqlstm.sqindv[4] = (         short *)0;
               sqlstm.sqinds[4] = (         int  )0;
               sqlstm.sqharm[4] = (unsigned long )0;
               sqlstm.sqadto[4] = (unsigned short )0;
               sqlstm.sqtdso[4] = (unsigned short )0;
               sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
               sqlstm.sqhstl[5] = (unsigned long )10;
               sqlstm.sqhsts[5] = (         int  )0;
               sqlstm.sqindv[5] = (         short *)0;
               sqlstm.sqinds[5] = (         int  )0;
               sqlstm.sqharm[5] = (unsigned long )0;
               sqlstm.sqadto[5] = (unsigned short )0;
               sqlstm.sqtdso[5] = (unsigned short )0;
               sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
               sqlstm.sqhstl[6] = (unsigned long )102;
               sqlstm.sqhsts[6] = (         int  )0;
               sqlstm.sqindv[6] = (         short *)0;
               sqlstm.sqinds[6] = (         int  )0;
               sqlstm.sqharm[6] = (unsigned long )0;
               sqlstm.sqadto[6] = (unsigned short )0;
               sqlstm.sqtdso[6] = (unsigned short )0;
               sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
               sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[7] = (         int  )0;
               sqlstm.sqindv[7] = (         short *)0;
               sqlstm.sqinds[7] = (         int  )0;
               sqlstm.sqharm[7] = (unsigned long )0;
               sqlstm.sqadto[7] = (unsigned short )0;
               sqlstm.sqtdso[7] = (unsigned short )0;
               sqlstm.sqphsv = sqlstm.sqhstv;
               sqlstm.sqphsl = sqlstm.sqhstl;
               sqlstm.sqphss = sqlstm.sqhsts;
               sqlstm.sqpind = sqlstm.sqindv;
               sqlstm.sqpins = sqlstm.sqinds;
               sqlstm.sqparm = sqlstm.sqharm;
               sqlstm.sqparc = sqlstm.sqharc;
               sqlstm.sqpadto = sqlstm.sqadto;
               sqlstm.sqptdso = sqlstm.sqtdso;
               sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
               if (sqlca.sqlcode < 0) goto sqlerr;
}





               temp.erase(temp.find("<CODE>"),temp.find("</CODE>")+strlen("/CODE>")- temp.find("<CODE>")+1);
               found = temp.find("<CODE>");

            }
         }
         if(0 == strcmp(g_ConObj.m_InstanceSp_DB.c_str(),"INST"))
            /* EXEC SQL INSERT INTO HLR_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CONFIG_VALUES (ENTITY_NAME,PARAM_\
ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYP\
E) values (:b0,:b1,:b2,:b3,'OS',to_date(:b4,'mm/dd/yyyy hh24:mi:ss'),:b5)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )1901;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[2] = (unsigned long )20;
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[3] = (unsigned long )10;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[4] = (unsigned long )102;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[5] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}



         /* EXEC SQL COMMIT; */ 

{
         struct sqlexd sqlstm;
         sqlstm.sqlvsn = 12;
         sqlstm.arrsiz = 8;
         sqlstm.sqladtp = &sqladt;
         sqlstm.sqltdsp = &sqltds;
         sqlstm.iters = (unsigned int  )1;
         sqlstm.offset = (unsigned int  )1940;
         sqlstm.cud = sqlcud0;
         sqlstm.sqlest = (unsigned char  *)&sqlca;
         sqlstm.sqlety = (unsigned short)256;
         sqlstm.occurs = (unsigned int  )0;
         sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
         if (sqlca.sqlcode < 0) goto sqlerr;
}



      }
      if(first == 144)
      {
         Param_ID = first;
         int found;

         string HLR_NETWORK = (string)g_ConObj.m_ModuleMap.find(1)->second;

         string searchFora ("<NETWORK_");    

         found = HLR_NETWORK.find( searchFora );


         while(found != string::npos) 
         {  

            string replaceBya ("<NETWORK>");
            HLR_NETWORK.replace( found, strlen("<NETWORK_00>"), replaceBya );
            searchFora = "</NETWORK_";    
            replaceBya = "</NETWORK>";
            found = HLR_NETWORK.find( searchFora );

            HLR_NETWORK.replace( found,strlen("</NETWORK_00>"), replaceBya );
            string searchFora ("<NETWORK_");    
            found = HLR_NETWORK.find( searchFora );
         }

         string temp =  complexMap.find(first)->second; 


         searchFora = "<NETWORK_";    

         found = temp.find( searchFora );

         while(found != string::npos) 
         {  
            string replaceBya ("<NETWORK>");
            temp.replace( found, strlen("<NETWORK_00>"), replaceBya );
            searchFora = "</NETWORK_";    
            replaceBya = "</NETWORK>";
            found = temp.find( searchFora );
            temp.replace( found,strlen("</NETWORK_00>"), replaceBya );
            string searchFora ("<NETWORK_");    
            found = temp.find( searchFora );
         }

         found = HLR_NETWORK.find("<NETWORK>");
         while(found != string::npos)
         {
            int fir = HLR_NETWORK.find("<NETWORK>")+strlen("NETWORK>")+1;
            int last =HLR_NETWORK.find("</NETWORK>");
            string value1 = HLR_NETWORK.substr(fir,last-fir);
            strcpy(Value,value1.c_str());
            Count_Val++;

            /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,13,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENTITY\
_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PO\
RT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,13,:b2,:b3\
,:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )1955;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)Value;
            sqlstm.sqhstl[2] = (unsigned long )100000;
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
            sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[4] = (unsigned long )20;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[5] = (unsigned long )10;
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[6] = (unsigned long )102;
            sqlstm.sqhsts[6] = (         int  )0;
            sqlstm.sqindv[6] = (         short *)0;
            sqlstm.sqinds[6] = (         int  )0;
            sqlstm.sqharm[6] = (unsigned long )0;
            sqlstm.sqadto[6] = (unsigned short )0;
            sqlstm.sqtdso[6] = (unsigned short )0;
            sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[7] = (         int  )0;
            sqlstm.sqindv[7] = (         short *)0;
            sqlstm.sqinds[7] = (         int  )0;
            sqlstm.sqharm[7] = (unsigned long )0;
            sqlstm.sqadto[7] = (unsigned short )0;
            sqlstm.sqtdso[7] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}


            HLR_NETWORK.erase(HLR_NETWORK.find("<NETWORK>"),HLR_NETWORK.find("</NETWORK>")+strlen("/NETWORK>")- HLR_NETWORK.find("<NETWORK>")+1);
            found = temp.find("<NETWORK>");
            fir = temp.find("<NETWORK>")+strlen("NETWORK>")+1;
            last =temp.find("</NETWORK>");
            string value2 = temp.substr(fir,last-fir);
            string value3 = Parser::getValue(value2,"MBOS_URL");
            strcpy(Value,value3.c_str());
            /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,14,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENTITY\
_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PO\
RT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,14,:b2,:b3\
,:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )2002;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)Value;
            sqlstm.sqhstl[2] = (unsigned long )100000;
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
            sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[4] = (unsigned long )20;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[5] = (unsigned long )10;
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[6] = (unsigned long )102;
            sqlstm.sqhsts[6] = (         int  )0;
            sqlstm.sqindv[6] = (         short *)0;
            sqlstm.sqinds[6] = (         int  )0;
            sqlstm.sqharm[6] = (unsigned long )0;
            sqlstm.sqadto[6] = (unsigned short )0;
            sqlstm.sqtdso[6] = (unsigned short )0;
            sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[7] = (         int  )0;
            sqlstm.sqindv[7] = (         short *)0;
            sqlstm.sqinds[7] = (         int  )0;
            sqlstm.sqharm[7] = (unsigned long )0;
            sqlstm.sqadto[7] = (unsigned short )0;
            sqlstm.sqtdso[7] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}


            temp.erase(temp.find("<NETWORK>"),temp.find("</NETWORK>")+strlen("/NETWORK>")- temp.find("<NETWORK>")+1);
            found = temp.find("<NETWORK>");
         }
         if(0 == strcmp(g_ConObj.m_InstanceSp_DB.c_str(),"INST"))
            /* EXEC SQL INSERT INTO HLR_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CONFIG_VALUES (ENTITY_NAME,PARAM_\
ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYP\
E) values (:b0,:b1,:b2,:b3,'OS',to_date(:b4,'mm/dd/yyyy hh24:mi:ss'),:b5)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )2049;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[2] = (unsigned long )20;
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[3] = (unsigned long )10;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[4] = (unsigned long )102;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[5] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}



         /* EXEC SQL COMMIT; */ 

{
         struct sqlexd sqlstm;
         sqlstm.sqlvsn = 12;
         sqlstm.arrsiz = 8;
         sqlstm.sqladtp = &sqladt;
         sqlstm.sqltdsp = &sqltds;
         sqlstm.iters = (unsigned int  )1;
         sqlstm.offset = (unsigned int  )2088;
         sqlstm.cud = sqlcud0;
         sqlstm.sqlest = (unsigned char  *)&sqlca;
         sqlstm.sqlety = (unsigned short)256;
         sqlstm.occurs = (unsigned int  )0;
         sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
         if (sqlca.sqlcode < 0) goto sqlerr;
}


      }
      else if(first == 145)
      {
         Param_ID = first;
         int found;
         string temp =  complexMap.find(first)->second; 
         string searchFora ("<CODE_");    
         found = temp.find( searchFora );
         if(found == -1)
         {
            Count_Val++;
            /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,15,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENTITY\
_NAME,PARAM_ID,SUB_PARAM_ID,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDA\
TED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,15,:b2,:b3,:b4,'OS',to\
_date(:b5,'mm/dd/yyyy hh24:mi:ss'),:b6)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )2103;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)&Count_Val;
            sqlstm.sqhstl[2] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[3] = (unsigned long )20;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[4] = (unsigned long )10;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[5] = (unsigned long )102;
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqhstv[6] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[6] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[6] = (         int  )0;
            sqlstm.sqindv[6] = (         short *)0;
            sqlstm.sqinds[6] = (         int  )0;
            sqlstm.sqharm[6] = (unsigned long )0;
            sqlstm.sqadto[6] = (unsigned short )0;
            sqlstm.sqtdso[6] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}




         }
         else
         {
            while(found != string::npos) 
            {  
               string replaceBya ("<CODE>");
               temp.replace( found, strlen("<CODE_00>"), replaceBya );
               searchFora = "</CODE_";    
               replaceBya = "</CODE>";
               found = temp.find( searchFora );
               temp.replace( found,strlen("</CODE_00>"), replaceBya );
               string searchFora ("<CODE_");    
               found = temp.find( searchFora );
            }
            found = temp.find("<CODE>");
            while(found != string::npos)
            {
               int fir = temp.find("<CODE>")+strlen("CODE>")+1;
               int last =temp.find("</CODE>");
               string value1 = temp.substr(fir,last-fir);
               Param_ID = first ;
               strcpy(Value,value1.c_str());
               Count_Val++;
               /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,15,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
               struct sqlexd sqlstm;
               sqlstm.sqlvsn = 12;
               sqlstm.arrsiz = 8;
               sqlstm.sqladtp = &sqladt;
               sqlstm.sqltdsp = &sqltds;
               sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENT\
ITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING\
_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,15,:b2,\
:b3,:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
               sqlstm.iters = (unsigned int  )1;
               sqlstm.offset = (unsigned int  )2146;
               sqlstm.cud = sqlcud0;
               sqlstm.sqlest = (unsigned char  *)&sqlca;
               sqlstm.sqlety = (unsigned short)256;
               sqlstm.occurs = (unsigned int  )0;
               sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
               sqlstm.sqhstl[0] = (unsigned long )20;
               sqlstm.sqhsts[0] = (         int  )0;
               sqlstm.sqindv[0] = (         short *)0;
               sqlstm.sqinds[0] = (         int  )0;
               sqlstm.sqharm[0] = (unsigned long )0;
               sqlstm.sqadto[0] = (unsigned short )0;
               sqlstm.sqtdso[0] = (unsigned short )0;
               sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
               sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[1] = (         int  )0;
               sqlstm.sqindv[1] = (         short *)0;
               sqlstm.sqinds[1] = (         int  )0;
               sqlstm.sqharm[1] = (unsigned long )0;
               sqlstm.sqadto[1] = (unsigned short )0;
               sqlstm.sqtdso[1] = (unsigned short )0;
               sqlstm.sqhstv[2] = (unsigned char  *)Value;
               sqlstm.sqhstl[2] = (unsigned long )100000;
               sqlstm.sqhsts[2] = (         int  )0;
               sqlstm.sqindv[2] = (         short *)0;
               sqlstm.sqinds[2] = (         int  )0;
               sqlstm.sqharm[2] = (unsigned long )0;
               sqlstm.sqadto[2] = (unsigned short )0;
               sqlstm.sqtdso[2] = (unsigned short )0;
               sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
               sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[3] = (         int  )0;
               sqlstm.sqindv[3] = (         short *)0;
               sqlstm.sqinds[3] = (         int  )0;
               sqlstm.sqharm[3] = (unsigned long )0;
               sqlstm.sqadto[3] = (unsigned short )0;
               sqlstm.sqtdso[3] = (unsigned short )0;
               sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
               sqlstm.sqhstl[4] = (unsigned long )20;
               sqlstm.sqhsts[4] = (         int  )0;
               sqlstm.sqindv[4] = (         short *)0;
               sqlstm.sqinds[4] = (         int  )0;
               sqlstm.sqharm[4] = (unsigned long )0;
               sqlstm.sqadto[4] = (unsigned short )0;
               sqlstm.sqtdso[4] = (unsigned short )0;
               sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
               sqlstm.sqhstl[5] = (unsigned long )10;
               sqlstm.sqhsts[5] = (         int  )0;
               sqlstm.sqindv[5] = (         short *)0;
               sqlstm.sqinds[5] = (         int  )0;
               sqlstm.sqharm[5] = (unsigned long )0;
               sqlstm.sqadto[5] = (unsigned short )0;
               sqlstm.sqtdso[5] = (unsigned short )0;
               sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
               sqlstm.sqhstl[6] = (unsigned long )102;
               sqlstm.sqhsts[6] = (         int  )0;
               sqlstm.sqindv[6] = (         short *)0;
               sqlstm.sqinds[6] = (         int  )0;
               sqlstm.sqharm[6] = (unsigned long )0;
               sqlstm.sqadto[6] = (unsigned short )0;
               sqlstm.sqtdso[6] = (unsigned short )0;
               sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
               sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[7] = (         int  )0;
               sqlstm.sqindv[7] = (         short *)0;
               sqlstm.sqinds[7] = (         int  )0;
               sqlstm.sqharm[7] = (unsigned long )0;
               sqlstm.sqadto[7] = (unsigned short )0;
               sqlstm.sqtdso[7] = (unsigned short )0;
               sqlstm.sqphsv = sqlstm.sqhstv;
               sqlstm.sqphsl = sqlstm.sqhstl;
               sqlstm.sqphss = sqlstm.sqhsts;
               sqlstm.sqpind = sqlstm.sqindv;
               sqlstm.sqpins = sqlstm.sqinds;
               sqlstm.sqparm = sqlstm.sqharm;
               sqlstm.sqparc = sqlstm.sqharc;
               sqlstm.sqpadto = sqlstm.sqadto;
               sqlstm.sqptdso = sqlstm.sqtdso;
               sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
               if (sqlca.sqlcode < 0) goto sqlerr;
}


               temp.erase(temp.find("<CODE>"),temp.find("</CODE>")+strlen("/CODE>")- temp.find("<CODE>")+1);
               found = temp.find("<CODE>");
            }
         }
         if(0 == strcmp(g_ConObj.m_InstanceSp_DB.c_str(),"INST"))
            /* EXEC SQL INSERT INTO HLR_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CONFIG_VALUES (ENTITY_NAME,PARAM_\
ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYP\
E) values (:b0,:b1,:b2,:b3,'OS',to_date(:b4,'mm/dd/yyyy hh24:mi:ss'),:b5)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )2193;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[2] = (unsigned long )20;
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[3] = (unsigned long )10;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[4] = (unsigned long )102;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[5] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}




         /* EXEC SQL COMMIT; */ 

{
         struct sqlexd sqlstm;
         sqlstm.sqlvsn = 12;
         sqlstm.arrsiz = 8;
         sqlstm.sqladtp = &sqladt;
         sqlstm.sqltdsp = &sqltds;
         sqlstm.iters = (unsigned int  )1;
         sqlstm.offset = (unsigned int  )2232;
         sqlstm.cud = sqlcud0;
         sqlstm.sqlest = (unsigned char  *)&sqlca;
         sqlstm.sqlety = (unsigned short)256;
         sqlstm.occurs = (unsigned int  )0;
         sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
         if (sqlca.sqlcode < 0) goto sqlerr;
}


      }
      else if(first == 155)
      {
         Param_ID = first;
         int found;
         string temp =  complexMap.find(first)->second; 
         string searchFora = "<INST_";
         found  = temp.find(searchFora);
         if(found == -1)
         {
            ELOG(0,0,"!!!!!!!!!! INST Tag not Found in SOTA !!!!!!!!");
         }
         else
         {
            while(found != string::npos)
            {
               string replaceBya ("<INSTANCE>");
               temp.replace( found, strlen("<INST_00>"), replaceBya );
               searchFora = "</INST_";    
               replaceBya = "</INSTANCE>";
               found = temp.find( searchFora );
               temp.replace( found,strlen("</INSTE_00>"), replaceBya );
               string searchFora ("<INST_");    
               found = temp.find( searchFora );
            }
            found = temp.find("<INSTANCE>");
            while(found != string::npos)
            {
               int fir = temp.find("<INSTANCE>")+strlen("INSTANCE>")+1;
               int last =temp.find("</INSTANCE>");
               string value1 = temp.substr(fir,last-fir);
               string value2 = Parser::getValue(value1,"SOTA_IP");
               strcpy(Value,value2.c_str());
               Count_Val++;
               /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,16,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
               struct sqlexd sqlstm;
               sqlstm.sqlvsn = 12;
               sqlstm.arrsiz = 8;
               sqlstm.sqladtp = &sqladt;
               sqlstm.sqltdsp = &sqltds;
               sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENT\
ITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING\
_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,16,:b2,\
:b3,:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
               sqlstm.iters = (unsigned int  )1;
               sqlstm.offset = (unsigned int  )2247;
               sqlstm.cud = sqlcud0;
               sqlstm.sqlest = (unsigned char  *)&sqlca;
               sqlstm.sqlety = (unsigned short)256;
               sqlstm.occurs = (unsigned int  )0;
               sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
               sqlstm.sqhstl[0] = (unsigned long )20;
               sqlstm.sqhsts[0] = (         int  )0;
               sqlstm.sqindv[0] = (         short *)0;
               sqlstm.sqinds[0] = (         int  )0;
               sqlstm.sqharm[0] = (unsigned long )0;
               sqlstm.sqadto[0] = (unsigned short )0;
               sqlstm.sqtdso[0] = (unsigned short )0;
               sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
               sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[1] = (         int  )0;
               sqlstm.sqindv[1] = (         short *)0;
               sqlstm.sqinds[1] = (         int  )0;
               sqlstm.sqharm[1] = (unsigned long )0;
               sqlstm.sqadto[1] = (unsigned short )0;
               sqlstm.sqtdso[1] = (unsigned short )0;
               sqlstm.sqhstv[2] = (unsigned char  *)Value;
               sqlstm.sqhstl[2] = (unsigned long )100000;
               sqlstm.sqhsts[2] = (         int  )0;
               sqlstm.sqindv[2] = (         short *)0;
               sqlstm.sqinds[2] = (         int  )0;
               sqlstm.sqharm[2] = (unsigned long )0;
               sqlstm.sqadto[2] = (unsigned short )0;
               sqlstm.sqtdso[2] = (unsigned short )0;
               sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
               sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[3] = (         int  )0;
               sqlstm.sqindv[3] = (         short *)0;
               sqlstm.sqinds[3] = (         int  )0;
               sqlstm.sqharm[3] = (unsigned long )0;
               sqlstm.sqadto[3] = (unsigned short )0;
               sqlstm.sqtdso[3] = (unsigned short )0;
               sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
               sqlstm.sqhstl[4] = (unsigned long )20;
               sqlstm.sqhsts[4] = (         int  )0;
               sqlstm.sqindv[4] = (         short *)0;
               sqlstm.sqinds[4] = (         int  )0;
               sqlstm.sqharm[4] = (unsigned long )0;
               sqlstm.sqadto[4] = (unsigned short )0;
               sqlstm.sqtdso[4] = (unsigned short )0;
               sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
               sqlstm.sqhstl[5] = (unsigned long )10;
               sqlstm.sqhsts[5] = (         int  )0;
               sqlstm.sqindv[5] = (         short *)0;
               sqlstm.sqinds[5] = (         int  )0;
               sqlstm.sqharm[5] = (unsigned long )0;
               sqlstm.sqadto[5] = (unsigned short )0;
               sqlstm.sqtdso[5] = (unsigned short )0;
               sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
               sqlstm.sqhstl[6] = (unsigned long )102;
               sqlstm.sqhsts[6] = (         int  )0;
               sqlstm.sqindv[6] = (         short *)0;
               sqlstm.sqinds[6] = (         int  )0;
               sqlstm.sqharm[6] = (unsigned long )0;
               sqlstm.sqadto[6] = (unsigned short )0;
               sqlstm.sqtdso[6] = (unsigned short )0;
               sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
               sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[7] = (         int  )0;
               sqlstm.sqindv[7] = (         short *)0;
               sqlstm.sqinds[7] = (         int  )0;
               sqlstm.sqharm[7] = (unsigned long )0;
               sqlstm.sqadto[7] = (unsigned short )0;
               sqlstm.sqtdso[7] = (unsigned short )0;
               sqlstm.sqphsv = sqlstm.sqhstv;
               sqlstm.sqphsl = sqlstm.sqhstl;
               sqlstm.sqphss = sqlstm.sqhsts;
               sqlstm.sqpind = sqlstm.sqindv;
               sqlstm.sqpins = sqlstm.sqinds;
               sqlstm.sqparm = sqlstm.sqharm;
               sqlstm.sqparc = sqlstm.sqharc;
               sqlstm.sqpadto = sqlstm.sqadto;
               sqlstm.sqptdso = sqlstm.sqtdso;
               sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
               if (sqlca.sqlcode < 0) goto sqlerr;
}


               value2 = Parser::getValue(value1,"SOTA_PORT");
               strcpy(Value,value2.c_str());
               /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,17,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
               struct sqlexd sqlstm;
               sqlstm.sqlvsn = 12;
               sqlstm.arrsiz = 8;
               sqlstm.sqladtp = &sqladt;
               sqlstm.sqltdsp = &sqltds;
               sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENT\
ITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING\
_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,17,:b2,\
:b3,:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
               sqlstm.iters = (unsigned int  )1;
               sqlstm.offset = (unsigned int  )2294;
               sqlstm.cud = sqlcud0;
               sqlstm.sqlest = (unsigned char  *)&sqlca;
               sqlstm.sqlety = (unsigned short)256;
               sqlstm.occurs = (unsigned int  )0;
               sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
               sqlstm.sqhstl[0] = (unsigned long )20;
               sqlstm.sqhsts[0] = (         int  )0;
               sqlstm.sqindv[0] = (         short *)0;
               sqlstm.sqinds[0] = (         int  )0;
               sqlstm.sqharm[0] = (unsigned long )0;
               sqlstm.sqadto[0] = (unsigned short )0;
               sqlstm.sqtdso[0] = (unsigned short )0;
               sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
               sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[1] = (         int  )0;
               sqlstm.sqindv[1] = (         short *)0;
               sqlstm.sqinds[1] = (         int  )0;
               sqlstm.sqharm[1] = (unsigned long )0;
               sqlstm.sqadto[1] = (unsigned short )0;
               sqlstm.sqtdso[1] = (unsigned short )0;
               sqlstm.sqhstv[2] = (unsigned char  *)Value;
               sqlstm.sqhstl[2] = (unsigned long )100000;
               sqlstm.sqhsts[2] = (         int  )0;
               sqlstm.sqindv[2] = (         short *)0;
               sqlstm.sqinds[2] = (         int  )0;
               sqlstm.sqharm[2] = (unsigned long )0;
               sqlstm.sqadto[2] = (unsigned short )0;
               sqlstm.sqtdso[2] = (unsigned short )0;
               sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
               sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[3] = (         int  )0;
               sqlstm.sqindv[3] = (         short *)0;
               sqlstm.sqinds[3] = (         int  )0;
               sqlstm.sqharm[3] = (unsigned long )0;
               sqlstm.sqadto[3] = (unsigned short )0;
               sqlstm.sqtdso[3] = (unsigned short )0;
               sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
               sqlstm.sqhstl[4] = (unsigned long )20;
               sqlstm.sqhsts[4] = (         int  )0;
               sqlstm.sqindv[4] = (         short *)0;
               sqlstm.sqinds[4] = (         int  )0;
               sqlstm.sqharm[4] = (unsigned long )0;
               sqlstm.sqadto[4] = (unsigned short )0;
               sqlstm.sqtdso[4] = (unsigned short )0;
               sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
               sqlstm.sqhstl[5] = (unsigned long )10;
               sqlstm.sqhsts[5] = (         int  )0;
               sqlstm.sqindv[5] = (         short *)0;
               sqlstm.sqinds[5] = (         int  )0;
               sqlstm.sqharm[5] = (unsigned long )0;
               sqlstm.sqadto[5] = (unsigned short )0;
               sqlstm.sqtdso[5] = (unsigned short )0;
               sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
               sqlstm.sqhstl[6] = (unsigned long )102;
               sqlstm.sqhsts[6] = (         int  )0;
               sqlstm.sqindv[6] = (         short *)0;
               sqlstm.sqinds[6] = (         int  )0;
               sqlstm.sqharm[6] = (unsigned long )0;
               sqlstm.sqadto[6] = (unsigned short )0;
               sqlstm.sqtdso[6] = (unsigned short )0;
               sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
               sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[7] = (         int  )0;
               sqlstm.sqindv[7] = (         short *)0;
               sqlstm.sqinds[7] = (         int  )0;
               sqlstm.sqharm[7] = (unsigned long )0;
               sqlstm.sqadto[7] = (unsigned short )0;
               sqlstm.sqtdso[7] = (unsigned short )0;
               sqlstm.sqphsv = sqlstm.sqhstv;
               sqlstm.sqphsl = sqlstm.sqhstl;
               sqlstm.sqphss = sqlstm.sqhsts;
               sqlstm.sqpind = sqlstm.sqindv;
               sqlstm.sqpins = sqlstm.sqinds;
               sqlstm.sqparm = sqlstm.sqharm;
               sqlstm.sqparc = sqlstm.sqharc;
               sqlstm.sqpadto = sqlstm.sqadto;
               sqlstm.sqptdso = sqlstm.sqtdso;
               sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
               if (sqlca.sqlcode < 0) goto sqlerr;
}


               temp.erase(temp.find("<INSTANCE>"),temp.find("</INSTANCE>")+strlen("/INSTANCE>")- temp.find("<INSTANCE>")+1);
               found = temp.find("<INSTANCE>");
            }
         }
         if(0 == strcmp(g_ConObj.m_InstanceSp_DB.c_str(),"INST"))
            /* EXEC SQL INSERT INTO HLR_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CONFIG_VALUES (ENTITY_NAME,PARAM_\
ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYP\
E) values (:b0,:b1,:b2,:b3,'OS',to_date(:b4,'mm/dd/yyyy hh24:mi:ss'),:b5)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )2341;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[2] = (unsigned long )20;
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[3] = (unsigned long )10;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[4] = (unsigned long )102;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[5] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}




         /* EXEC SQL COMMIT; */ 

{
         struct sqlexd sqlstm;
         sqlstm.sqlvsn = 12;
         sqlstm.arrsiz = 8;
         sqlstm.sqladtp = &sqladt;
         sqlstm.sqltdsp = &sqltds;
         sqlstm.iters = (unsigned int  )1;
         sqlstm.offset = (unsigned int  )2380;
         sqlstm.cud = sqlcud0;
         sqlstm.sqlest = (unsigned char  *)&sqlca;
         sqlstm.sqlety = (unsigned short)256;
         sqlstm.occurs = (unsigned int  )0;
         sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
         if (sqlca.sqlcode < 0) goto sqlerr;
}


      }
      else if(first == 159)
      {
         Param_ID = first;
         int found;
         string HLR_NETWORK = (string)g_ConObj.m_ModuleMap.find(1)->second;

         string searchFora ("<NETWORK_");    

         found = HLR_NETWORK.find( searchFora );


         while(found != string::npos) 
         {  

            string replaceBya ("<NETWORK>");
            HLR_NETWORK.replace( found, strlen("<NETWORK_00>"), replaceBya );
            searchFora = "</NETWORK_";    
            replaceBya = "</NETWORK>";
            found = HLR_NETWORK.find( searchFora );

            HLR_NETWORK.replace( found,strlen("</NETWORK_00>"), replaceBya );
            string searchFora ("<NETWORK_");    
            found = HLR_NETWORK.find( searchFora );
         }





         string temp =  complexMap.find(first)->second; 
         searchFora = "<NETWORK_";    
         found = temp.find( searchFora );
         if(found == -1)
         {
            ELOG(0,0,"!!!!!!!!!!NETWORK Tag not Found SOTA!!!!!!!!");

         }
         else
         {
            while(found != string::npos) 
            {  
               string replaceBya ("<NETWORK>");
               temp.replace( found, strlen("<NETWORK_00>"), replaceBya );
               searchFora = "</NETWORK_";    
               replaceBya = "</NETWORK>";
               found = temp.find( searchFora );
               temp.replace( found,strlen("</NETWORK_00>"), replaceBya );
               string searchFora ("<NETWORK_");    
               found = temp.find( searchFora );
            }


            found = HLR_NETWORK.find("<NETWORK>");
            while(found != string::npos)
            {
               int fir = HLR_NETWORK.find("<NETWORK>")+strlen("NETWORK>")+1;
               int last =HLR_NETWORK.find("</NETWORK>");
               string value1 = HLR_NETWORK.substr(fir,last-fir);
               HLR_NETWORK.erase(HLR_NETWORK.find("<NETWORK>"),HLR_NETWORK.find("</NETWORK>")+strlen("/NETWORK>")- HLR_NETWORK.find("<NETWORK>")+1);

               found = temp.find("<NETWORK>");


               fir = temp.find("<NETWORK>")+strlen("NETWORK>")+1;
               last =temp.find("</NETWORK>");
               string value2 = temp.substr(fir,last-fir);

               //   value2 = value1+":"+value2;
               strcpy(Value,value1.c_str());

               Count_Val++;
               //         if(0 != strcmp(g_ConObj.m_InstanceSp_DB.c_str(),"INST"))
               /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,18,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
               struct sqlexd sqlstm;
               sqlstm.sqlvsn = 12;
               sqlstm.arrsiz = 8;
               sqlstm.sqladtp = &sqladt;
               sqlstm.sqltdsp = &sqltds;
               sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENT\
ITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING\
_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,18,:b2,\
:b3,:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
               sqlstm.iters = (unsigned int  )1;
               sqlstm.offset = (unsigned int  )2395;
               sqlstm.cud = sqlcud0;
               sqlstm.sqlest = (unsigned char  *)&sqlca;
               sqlstm.sqlety = (unsigned short)256;
               sqlstm.occurs = (unsigned int  )0;
               sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
               sqlstm.sqhstl[0] = (unsigned long )20;
               sqlstm.sqhsts[0] = (         int  )0;
               sqlstm.sqindv[0] = (         short *)0;
               sqlstm.sqinds[0] = (         int  )0;
               sqlstm.sqharm[0] = (unsigned long )0;
               sqlstm.sqadto[0] = (unsigned short )0;
               sqlstm.sqtdso[0] = (unsigned short )0;
               sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
               sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[1] = (         int  )0;
               sqlstm.sqindv[1] = (         short *)0;
               sqlstm.sqinds[1] = (         int  )0;
               sqlstm.sqharm[1] = (unsigned long )0;
               sqlstm.sqadto[1] = (unsigned short )0;
               sqlstm.sqtdso[1] = (unsigned short )0;
               sqlstm.sqhstv[2] = (unsigned char  *)Value;
               sqlstm.sqhstl[2] = (unsigned long )100000;
               sqlstm.sqhsts[2] = (         int  )0;
               sqlstm.sqindv[2] = (         short *)0;
               sqlstm.sqinds[2] = (         int  )0;
               sqlstm.sqharm[2] = (unsigned long )0;
               sqlstm.sqadto[2] = (unsigned short )0;
               sqlstm.sqtdso[2] = (unsigned short )0;
               sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
               sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[3] = (         int  )0;
               sqlstm.sqindv[3] = (         short *)0;
               sqlstm.sqinds[3] = (         int  )0;
               sqlstm.sqharm[3] = (unsigned long )0;
               sqlstm.sqadto[3] = (unsigned short )0;
               sqlstm.sqtdso[3] = (unsigned short )0;
               sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
               sqlstm.sqhstl[4] = (unsigned long )20;
               sqlstm.sqhsts[4] = (         int  )0;
               sqlstm.sqindv[4] = (         short *)0;
               sqlstm.sqinds[4] = (         int  )0;
               sqlstm.sqharm[4] = (unsigned long )0;
               sqlstm.sqadto[4] = (unsigned short )0;
               sqlstm.sqtdso[4] = (unsigned short )0;
               sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
               sqlstm.sqhstl[5] = (unsigned long )10;
               sqlstm.sqhsts[5] = (         int  )0;
               sqlstm.sqindv[5] = (         short *)0;
               sqlstm.sqinds[5] = (         int  )0;
               sqlstm.sqharm[5] = (unsigned long )0;
               sqlstm.sqadto[5] = (unsigned short )0;
               sqlstm.sqtdso[5] = (unsigned short )0;
               sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
               sqlstm.sqhstl[6] = (unsigned long )102;
               sqlstm.sqhsts[6] = (         int  )0;
               sqlstm.sqindv[6] = (         short *)0;
               sqlstm.sqinds[6] = (         int  )0;
               sqlstm.sqharm[6] = (unsigned long )0;
               sqlstm.sqadto[6] = (unsigned short )0;
               sqlstm.sqtdso[6] = (unsigned short )0;
               sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
               sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[7] = (         int  )0;
               sqlstm.sqindv[7] = (         short *)0;
               sqlstm.sqinds[7] = (         int  )0;
               sqlstm.sqharm[7] = (unsigned long )0;
               sqlstm.sqadto[7] = (unsigned short )0;
               sqlstm.sqtdso[7] = (unsigned short )0;
               sqlstm.sqphsv = sqlstm.sqhstv;
               sqlstm.sqphsl = sqlstm.sqhstl;
               sqlstm.sqphss = sqlstm.sqhsts;
               sqlstm.sqpind = sqlstm.sqindv;
               sqlstm.sqpins = sqlstm.sqinds;
               sqlstm.sqparm = sqlstm.sqharm;
               sqlstm.sqparc = sqlstm.sqharc;
               sqlstm.sqpadto = sqlstm.sqadto;
               sqlstm.sqptdso = sqlstm.sqtdso;
               sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
               if (sqlca.sqlcode < 0) goto sqlerr;
}


               strcpy(Value,value2.c_str());
               /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,19,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
               struct sqlexd sqlstm;
               sqlstm.sqlvsn = 12;
               sqlstm.arrsiz = 8;
               sqlstm.sqladtp = &sqladt;
               sqlstm.sqltdsp = &sqltds;
               sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENT\
ITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING\
_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,19,:b2,\
:b3,:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
               sqlstm.iters = (unsigned int  )1;
               sqlstm.offset = (unsigned int  )2442;
               sqlstm.cud = sqlcud0;
               sqlstm.sqlest = (unsigned char  *)&sqlca;
               sqlstm.sqlety = (unsigned short)256;
               sqlstm.occurs = (unsigned int  )0;
               sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
               sqlstm.sqhstl[0] = (unsigned long )20;
               sqlstm.sqhsts[0] = (         int  )0;
               sqlstm.sqindv[0] = (         short *)0;
               sqlstm.sqinds[0] = (         int  )0;
               sqlstm.sqharm[0] = (unsigned long )0;
               sqlstm.sqadto[0] = (unsigned short )0;
               sqlstm.sqtdso[0] = (unsigned short )0;
               sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
               sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[1] = (         int  )0;
               sqlstm.sqindv[1] = (         short *)0;
               sqlstm.sqinds[1] = (         int  )0;
               sqlstm.sqharm[1] = (unsigned long )0;
               sqlstm.sqadto[1] = (unsigned short )0;
               sqlstm.sqtdso[1] = (unsigned short )0;
               sqlstm.sqhstv[2] = (unsigned char  *)Value;
               sqlstm.sqhstl[2] = (unsigned long )100000;
               sqlstm.sqhsts[2] = (         int  )0;
               sqlstm.sqindv[2] = (         short *)0;
               sqlstm.sqinds[2] = (         int  )0;
               sqlstm.sqharm[2] = (unsigned long )0;
               sqlstm.sqadto[2] = (unsigned short )0;
               sqlstm.sqtdso[2] = (unsigned short )0;
               sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
               sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[3] = (         int  )0;
               sqlstm.sqindv[3] = (         short *)0;
               sqlstm.sqinds[3] = (         int  )0;
               sqlstm.sqharm[3] = (unsigned long )0;
               sqlstm.sqadto[3] = (unsigned short )0;
               sqlstm.sqtdso[3] = (unsigned short )0;
               sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
               sqlstm.sqhstl[4] = (unsigned long )20;
               sqlstm.sqhsts[4] = (         int  )0;
               sqlstm.sqindv[4] = (         short *)0;
               sqlstm.sqinds[4] = (         int  )0;
               sqlstm.sqharm[4] = (unsigned long )0;
               sqlstm.sqadto[4] = (unsigned short )0;
               sqlstm.sqtdso[4] = (unsigned short )0;
               sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
               sqlstm.sqhstl[5] = (unsigned long )10;
               sqlstm.sqhsts[5] = (         int  )0;
               sqlstm.sqindv[5] = (         short *)0;
               sqlstm.sqinds[5] = (         int  )0;
               sqlstm.sqharm[5] = (unsigned long )0;
               sqlstm.sqadto[5] = (unsigned short )0;
               sqlstm.sqtdso[5] = (unsigned short )0;
               sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
               sqlstm.sqhstl[6] = (unsigned long )102;
               sqlstm.sqhsts[6] = (         int  )0;
               sqlstm.sqindv[6] = (         short *)0;
               sqlstm.sqinds[6] = (         int  )0;
               sqlstm.sqharm[6] = (unsigned long )0;
               sqlstm.sqadto[6] = (unsigned short )0;
               sqlstm.sqtdso[6] = (unsigned short )0;
               sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
               sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[7] = (         int  )0;
               sqlstm.sqindv[7] = (         short *)0;
               sqlstm.sqinds[7] = (         int  )0;
               sqlstm.sqharm[7] = (unsigned long )0;
               sqlstm.sqadto[7] = (unsigned short )0;
               sqlstm.sqtdso[7] = (unsigned short )0;
               sqlstm.sqphsv = sqlstm.sqhstv;
               sqlstm.sqphsl = sqlstm.sqhstl;
               sqlstm.sqphss = sqlstm.sqhsts;
               sqlstm.sqpind = sqlstm.sqindv;
               sqlstm.sqpins = sqlstm.sqinds;
               sqlstm.sqparm = sqlstm.sqharm;
               sqlstm.sqparc = sqlstm.sqharc;
               sqlstm.sqpadto = sqlstm.sqadto;
               sqlstm.sqptdso = sqlstm.sqtdso;
               sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
               if (sqlca.sqlcode < 0) goto sqlerr;
}



               temp.erase(temp.find("<NETWORK>"),temp.find("</NETWORK>")+strlen("/NETWORK>")- temp.find("<NETWORK>")+1);
               found = temp.find("<NETWORK>");
            }
         }
         if(0 == strcmp(g_ConObj.m_InstanceSp_DB.c_str(),"INST"))
            /* EXEC SQL INSERT INTO HLR_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CONFIG_VALUES (ENTITY_NAME,PARAM_\
ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYP\
E) values (:b0,:b1,:b2,:b3,'OS',to_date(:b4,'mm/dd/yyyy hh24:mi:ss'),:b5)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )2489;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[2] = (unsigned long )20;
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[3] = (unsigned long )10;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[4] = (unsigned long )102;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[5] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}




         /* EXEC SQL COMMIT; */ 

{
         struct sqlexd sqlstm;
         sqlstm.sqlvsn = 12;
         sqlstm.arrsiz = 8;
         sqlstm.sqladtp = &sqladt;
         sqlstm.sqltdsp = &sqltds;
         sqlstm.iters = (unsigned int  )1;
         sqlstm.offset = (unsigned int  )2528;
         sqlstm.cud = sqlcud0;
         sqlstm.sqlest = (unsigned char  *)&sqlca;
         sqlstm.sqlety = (unsigned short)256;
         sqlstm.occurs = (unsigned int  )0;
         sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
         if (sqlca.sqlcode < 0) goto sqlerr;
}


      }
      else if(first == 162)
      {
         Param_ID = first;
         int found;
         string temp =  complexMap.find(first)->second; 
         string searchFora = "<RANGE_";
         found  = temp.find(searchFora);
         while(found != string::npos)
         {
            string replaceBya ("<RANGE>");
            temp.replace( found, strlen("<RANGE_000>"), replaceBya );
            searchFora = "</RANGE_";    
            replaceBya = "</RANGE>";
            found = temp.find( searchFora );
            temp.replace( found,strlen("</RANGE_000>"), replaceBya );
            string searchFora ("<RANGE_");    
            found = temp.find( searchFora );
         }
         found = temp.find("<RANGE>");
         while(found != string::npos)
         {
            int fir = temp.find("<RANGE>")+strlen("RANGE>")+1;
            int last =temp.find("</RANGE>");
            string value1 = temp.substr(fir,last-fir);
            string value2 = Parser::getValue(value1,"START");
            strcpy(Value,value2.c_str());
            Count_Val++;
            /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,21,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENTITY\
_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PO\
RT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,21,:b2,:b3\
,:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )2543;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)Value;
            sqlstm.sqhstl[2] = (unsigned long )100000;
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
            sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[4] = (unsigned long )20;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[5] = (unsigned long )10;
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[6] = (unsigned long )102;
            sqlstm.sqhsts[6] = (         int  )0;
            sqlstm.sqindv[6] = (         short *)0;
            sqlstm.sqinds[6] = (         int  )0;
            sqlstm.sqharm[6] = (unsigned long )0;
            sqlstm.sqadto[6] = (unsigned short )0;
            sqlstm.sqtdso[6] = (unsigned short )0;
            sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[7] = (         int  )0;
            sqlstm.sqindv[7] = (         short *)0;
            sqlstm.sqinds[7] = (         int  )0;
            sqlstm.sqharm[7] = (unsigned long )0;
            sqlstm.sqadto[7] = (unsigned short )0;
            sqlstm.sqtdso[7] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}


            value2 = Parser::getValue(value1,"END");
            strcpy(Value,value2.c_str());
            /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,22,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENTITY\
_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PO\
RT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,22,:b2,:b3\
,:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )2590;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)Value;
            sqlstm.sqhstl[2] = (unsigned long )100000;
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
            sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[4] = (unsigned long )20;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[5] = (unsigned long )10;
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[6] = (unsigned long )102;
            sqlstm.sqhsts[6] = (         int  )0;
            sqlstm.sqindv[6] = (         short *)0;
            sqlstm.sqinds[6] = (         int  )0;
            sqlstm.sqharm[6] = (unsigned long )0;
            sqlstm.sqadto[6] = (unsigned short )0;
            sqlstm.sqtdso[6] = (unsigned short )0;
            sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[7] = (         int  )0;
            sqlstm.sqindv[7] = (         short *)0;
            sqlstm.sqinds[7] = (         int  )0;
            sqlstm.sqharm[7] = (unsigned long )0;
            sqlstm.sqadto[7] = (unsigned short )0;
            sqlstm.sqtdso[7] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}


            temp.erase(temp.find("<RANGE>"),temp.find("</RANGE>")+strlen("/RANGE>")- temp.find("<RANGE>")+1);
            found = temp.find("<RANGE>");
         }
         if(0 == strcmp(g_ConObj.m_InstanceSp_DB.c_str(),"INST"))
            /* EXEC SQL INSERT INTO HLR_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CONFIG_VALUES (ENTITY_NAME,PARAM_\
ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYP\
E) values (:b0,:b1,:b2,:b3,'OS',to_date(:b4,'mm/dd/yyyy hh24:mi:ss'),:b5)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )2637;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[2] = (unsigned long )20;
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[3] = (unsigned long )10;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[4] = (unsigned long )102;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[5] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}




         /* EXEC SQL COMMIT; */ 

{
         struct sqlexd sqlstm;
         sqlstm.sqlvsn = 12;
         sqlstm.arrsiz = 8;
         sqlstm.sqladtp = &sqladt;
         sqlstm.sqltdsp = &sqltds;
         sqlstm.iters = (unsigned int  )1;
         sqlstm.offset = (unsigned int  )2676;
         sqlstm.cud = sqlcud0;
         sqlstm.sqlest = (unsigned char  *)&sqlca;
         sqlstm.sqlety = (unsigned short)256;
         sqlstm.occurs = (unsigned int  )0;
         sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
         if (sqlca.sqlcode < 0) goto sqlerr;
}


      }
      else if(first == 160)
      {
         Param_ID = first;
         int found;
         string temp =  complexMap.find(first)->second; 
         string searchFora ("<CODE_");    
         found = temp.find( searchFora );
         if(found == -1)
         {
            Count_Val++;
            /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,20,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENTITY\
_NAME,PARAM_ID,SUB_PARAM_ID,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDA\
TED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,20,:b2,:b3,:b4,'OS',to\
_date(:b5,'mm/dd/yyyy hh24:mi:ss'),:b6)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )2691;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)&Count_Val;
            sqlstm.sqhstl[2] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[3] = (unsigned long )20;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[4] = (unsigned long )10;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[5] = (unsigned long )102;
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqhstv[6] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[6] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[6] = (         int  )0;
            sqlstm.sqindv[6] = (         short *)0;
            sqlstm.sqinds[6] = (         int  )0;
            sqlstm.sqharm[6] = (unsigned long )0;
            sqlstm.sqadto[6] = (unsigned short )0;
            sqlstm.sqtdso[6] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}




         }
         else
         {
            while(found != string::npos) 
            {  
               string replaceBya ("<CODE>");
               temp.replace( found, strlen("<CODE_00>"), replaceBya );
               searchFora = "</CODE_";    
               replaceBya = "</CODE>";
               found = temp.find( searchFora );
               temp.replace( found,strlen("</CODE_00>"), replaceBya );
               string searchFora ("<CODE_");    
               found = temp.find( searchFora );
            }
            found = temp.find("<CODE>");
            while(found != string::npos)
            {
               int fir = temp.find("<CODE>")+strlen("CODE>")+1;
               int last =temp.find("</CODE>");
               string value1 = temp.substr(fir,last-fir);
               Param_ID = first ;
               strcpy(Value,value1.c_str());
               Count_Val++;
               /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,20,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
               struct sqlexd sqlstm;
               sqlstm.sqlvsn = 12;
               sqlstm.arrsiz = 8;
               sqlstm.sqladtp = &sqladt;
               sqlstm.sqltdsp = &sqltds;
               sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENT\
ITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING\
_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,20,:b2,\
:b3,:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
               sqlstm.iters = (unsigned int  )1;
               sqlstm.offset = (unsigned int  )2734;
               sqlstm.cud = sqlcud0;
               sqlstm.sqlest = (unsigned char  *)&sqlca;
               sqlstm.sqlety = (unsigned short)256;
               sqlstm.occurs = (unsigned int  )0;
               sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
               sqlstm.sqhstl[0] = (unsigned long )20;
               sqlstm.sqhsts[0] = (         int  )0;
               sqlstm.sqindv[0] = (         short *)0;
               sqlstm.sqinds[0] = (         int  )0;
               sqlstm.sqharm[0] = (unsigned long )0;
               sqlstm.sqadto[0] = (unsigned short )0;
               sqlstm.sqtdso[0] = (unsigned short )0;
               sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
               sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[1] = (         int  )0;
               sqlstm.sqindv[1] = (         short *)0;
               sqlstm.sqinds[1] = (         int  )0;
               sqlstm.sqharm[1] = (unsigned long )0;
               sqlstm.sqadto[1] = (unsigned short )0;
               sqlstm.sqtdso[1] = (unsigned short )0;
               sqlstm.sqhstv[2] = (unsigned char  *)Value;
               sqlstm.sqhstl[2] = (unsigned long )100000;
               sqlstm.sqhsts[2] = (         int  )0;
               sqlstm.sqindv[2] = (         short *)0;
               sqlstm.sqinds[2] = (         int  )0;
               sqlstm.sqharm[2] = (unsigned long )0;
               sqlstm.sqadto[2] = (unsigned short )0;
               sqlstm.sqtdso[2] = (unsigned short )0;
               sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
               sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[3] = (         int  )0;
               sqlstm.sqindv[3] = (         short *)0;
               sqlstm.sqinds[3] = (         int  )0;
               sqlstm.sqharm[3] = (unsigned long )0;
               sqlstm.sqadto[3] = (unsigned short )0;
               sqlstm.sqtdso[3] = (unsigned short )0;
               sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
               sqlstm.sqhstl[4] = (unsigned long )20;
               sqlstm.sqhsts[4] = (         int  )0;
               sqlstm.sqindv[4] = (         short *)0;
               sqlstm.sqinds[4] = (         int  )0;
               sqlstm.sqharm[4] = (unsigned long )0;
               sqlstm.sqadto[4] = (unsigned short )0;
               sqlstm.sqtdso[4] = (unsigned short )0;
               sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
               sqlstm.sqhstl[5] = (unsigned long )10;
               sqlstm.sqhsts[5] = (         int  )0;
               sqlstm.sqindv[5] = (         short *)0;
               sqlstm.sqinds[5] = (         int  )0;
               sqlstm.sqharm[5] = (unsigned long )0;
               sqlstm.sqadto[5] = (unsigned short )0;
               sqlstm.sqtdso[5] = (unsigned short )0;
               sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
               sqlstm.sqhstl[6] = (unsigned long )102;
               sqlstm.sqhsts[6] = (         int  )0;
               sqlstm.sqindv[6] = (         short *)0;
               sqlstm.sqinds[6] = (         int  )0;
               sqlstm.sqharm[6] = (unsigned long )0;
               sqlstm.sqadto[6] = (unsigned short )0;
               sqlstm.sqtdso[6] = (unsigned short )0;
               sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
               sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[7] = (         int  )0;
               sqlstm.sqindv[7] = (         short *)0;
               sqlstm.sqinds[7] = (         int  )0;
               sqlstm.sqharm[7] = (unsigned long )0;
               sqlstm.sqadto[7] = (unsigned short )0;
               sqlstm.sqtdso[7] = (unsigned short )0;
               sqlstm.sqphsv = sqlstm.sqhstv;
               sqlstm.sqphsl = sqlstm.sqhstl;
               sqlstm.sqphss = sqlstm.sqhsts;
               sqlstm.sqpind = sqlstm.sqindv;
               sqlstm.sqpins = sqlstm.sqinds;
               sqlstm.sqparm = sqlstm.sqharm;
               sqlstm.sqparc = sqlstm.sqharc;
               sqlstm.sqpadto = sqlstm.sqadto;
               sqlstm.sqptdso = sqlstm.sqtdso;
               sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
               if (sqlca.sqlcode < 0) goto sqlerr;
}


               temp.erase(temp.find("<CODE>"),temp.find("</CODE>")+strlen("/CODE>")- temp.find("<CODE>")+1);
               found = temp.find("<CODE>");
            }
         }
         if(0 == strcmp(g_ConObj.m_InstanceSp_DB.c_str(),"INST"))
            /* EXEC SQL INSERT INTO HLR_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CONFIG_VALUES (ENTITY_NAME,PARAM_\
ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYP\
E) values (:b0,:b1,:b2,:b3,'OS',to_date(:b4,'mm/dd/yyyy hh24:mi:ss'),:b5)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )2781;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[2] = (unsigned long )20;
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[3] = (unsigned long )10;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[4] = (unsigned long )102;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[5] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}




         /* EXEC SQL COMMIT; */ 

{
         struct sqlexd sqlstm;
         sqlstm.sqlvsn = 12;
         sqlstm.arrsiz = 8;
         sqlstm.sqladtp = &sqladt;
         sqlstm.sqltdsp = &sqltds;
         sqlstm.iters = (unsigned int  )1;
         sqlstm.offset = (unsigned int  )2820;
         sqlstm.cud = sqlcud0;
         sqlstm.sqlest = (unsigned char  *)&sqlca;
         sqlstm.sqlety = (unsigned short)256;
         sqlstm.occurs = (unsigned int  )0;
         sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
         if (sqlca.sqlcode < 0) goto sqlerr;
}


      }
      else if(first == 172)
      {
         Param_ID = first;
         int found;
         string temp =  complexMap.find(first)->second; 
         string searchFora = "<INST_";
         found  = temp.find(searchFora);
         if(found == -1)
         {
            ELOG(0,0,"!!!!!!!!!! DOTA_INSTANCE Tag not Found !!!!!!!!");
         }
         else
         {
            while(found != string::npos)
            {
               string replaceBya ("<INSTANCE>");
               temp.replace( found, strlen("<INST_00>"), replaceBya );
               searchFora = "</INST_";    
               replaceBya = "</INSTANCE>";
               found = temp.find( searchFora );
               temp.replace( found,strlen("</INSTE_00>"), replaceBya );
               string searchFora ("<INST_");    
               found = temp.find( searchFora );
            }

            found = temp.find("<INSTANCE>");
            while(found != string::npos)
            {
               int fir = temp.find("<INSTANCE>")+strlen("INSTANCE>")+1;
               int last =temp.find("</INSTANCE>");
               string value1 = temp.substr(fir,last-fir);
               string value2 = Parser::getValue(value1,"DOTA_IP");
               strcpy(Value,value2.c_str());
               Count_Val++;
               /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,23,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
               struct sqlexd sqlstm;
               sqlstm.sqlvsn = 12;
               sqlstm.arrsiz = 8;
               sqlstm.sqladtp = &sqladt;
               sqlstm.sqltdsp = &sqltds;
               sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENT\
ITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING\
_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,23,:b2,\
:b3,:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
               sqlstm.iters = (unsigned int  )1;
               sqlstm.offset = (unsigned int  )2835;
               sqlstm.cud = sqlcud0;
               sqlstm.sqlest = (unsigned char  *)&sqlca;
               sqlstm.sqlety = (unsigned short)256;
               sqlstm.occurs = (unsigned int  )0;
               sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
               sqlstm.sqhstl[0] = (unsigned long )20;
               sqlstm.sqhsts[0] = (         int  )0;
               sqlstm.sqindv[0] = (         short *)0;
               sqlstm.sqinds[0] = (         int  )0;
               sqlstm.sqharm[0] = (unsigned long )0;
               sqlstm.sqadto[0] = (unsigned short )0;
               sqlstm.sqtdso[0] = (unsigned short )0;
               sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
               sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[1] = (         int  )0;
               sqlstm.sqindv[1] = (         short *)0;
               sqlstm.sqinds[1] = (         int  )0;
               sqlstm.sqharm[1] = (unsigned long )0;
               sqlstm.sqadto[1] = (unsigned short )0;
               sqlstm.sqtdso[1] = (unsigned short )0;
               sqlstm.sqhstv[2] = (unsigned char  *)Value;
               sqlstm.sqhstl[2] = (unsigned long )100000;
               sqlstm.sqhsts[2] = (         int  )0;
               sqlstm.sqindv[2] = (         short *)0;
               sqlstm.sqinds[2] = (         int  )0;
               sqlstm.sqharm[2] = (unsigned long )0;
               sqlstm.sqadto[2] = (unsigned short )0;
               sqlstm.sqtdso[2] = (unsigned short )0;
               sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
               sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[3] = (         int  )0;
               sqlstm.sqindv[3] = (         short *)0;
               sqlstm.sqinds[3] = (         int  )0;
               sqlstm.sqharm[3] = (unsigned long )0;
               sqlstm.sqadto[3] = (unsigned short )0;
               sqlstm.sqtdso[3] = (unsigned short )0;
               sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
               sqlstm.sqhstl[4] = (unsigned long )20;
               sqlstm.sqhsts[4] = (         int  )0;
               sqlstm.sqindv[4] = (         short *)0;
               sqlstm.sqinds[4] = (         int  )0;
               sqlstm.sqharm[4] = (unsigned long )0;
               sqlstm.sqadto[4] = (unsigned short )0;
               sqlstm.sqtdso[4] = (unsigned short )0;
               sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
               sqlstm.sqhstl[5] = (unsigned long )10;
               sqlstm.sqhsts[5] = (         int  )0;
               sqlstm.sqindv[5] = (         short *)0;
               sqlstm.sqinds[5] = (         int  )0;
               sqlstm.sqharm[5] = (unsigned long )0;
               sqlstm.sqadto[5] = (unsigned short )0;
               sqlstm.sqtdso[5] = (unsigned short )0;
               sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
               sqlstm.sqhstl[6] = (unsigned long )102;
               sqlstm.sqhsts[6] = (         int  )0;
               sqlstm.sqindv[6] = (         short *)0;
               sqlstm.sqinds[6] = (         int  )0;
               sqlstm.sqharm[6] = (unsigned long )0;
               sqlstm.sqadto[6] = (unsigned short )0;
               sqlstm.sqtdso[6] = (unsigned short )0;
               sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
               sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[7] = (         int  )0;
               sqlstm.sqindv[7] = (         short *)0;
               sqlstm.sqinds[7] = (         int  )0;
               sqlstm.sqharm[7] = (unsigned long )0;
               sqlstm.sqadto[7] = (unsigned short )0;
               sqlstm.sqtdso[7] = (unsigned short )0;
               sqlstm.sqphsv = sqlstm.sqhstv;
               sqlstm.sqphsl = sqlstm.sqhstl;
               sqlstm.sqphss = sqlstm.sqhsts;
               sqlstm.sqpind = sqlstm.sqindv;
               sqlstm.sqpins = sqlstm.sqinds;
               sqlstm.sqparm = sqlstm.sqharm;
               sqlstm.sqparc = sqlstm.sqharc;
               sqlstm.sqpadto = sqlstm.sqadto;
               sqlstm.sqptdso = sqlstm.sqtdso;
               sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
               if (sqlca.sqlcode < 0) goto sqlerr;
}


               value2 = Parser::getValue(value1,"DOTA_PORT");
               strcpy(Value,value2.c_str());
               /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,24,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
               struct sqlexd sqlstm;
               sqlstm.sqlvsn = 12;
               sqlstm.arrsiz = 8;
               sqlstm.sqladtp = &sqladt;
               sqlstm.sqltdsp = &sqltds;
               sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENT\
ITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING\
_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,24,:b2,\
:b3,:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
               sqlstm.iters = (unsigned int  )1;
               sqlstm.offset = (unsigned int  )2882;
               sqlstm.cud = sqlcud0;
               sqlstm.sqlest = (unsigned char  *)&sqlca;
               sqlstm.sqlety = (unsigned short)256;
               sqlstm.occurs = (unsigned int  )0;
               sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
               sqlstm.sqhstl[0] = (unsigned long )20;
               sqlstm.sqhsts[0] = (         int  )0;
               sqlstm.sqindv[0] = (         short *)0;
               sqlstm.sqinds[0] = (         int  )0;
               sqlstm.sqharm[0] = (unsigned long )0;
               sqlstm.sqadto[0] = (unsigned short )0;
               sqlstm.sqtdso[0] = (unsigned short )0;
               sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
               sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[1] = (         int  )0;
               sqlstm.sqindv[1] = (         short *)0;
               sqlstm.sqinds[1] = (         int  )0;
               sqlstm.sqharm[1] = (unsigned long )0;
               sqlstm.sqadto[1] = (unsigned short )0;
               sqlstm.sqtdso[1] = (unsigned short )0;
               sqlstm.sqhstv[2] = (unsigned char  *)Value;
               sqlstm.sqhstl[2] = (unsigned long )100000;
               sqlstm.sqhsts[2] = (         int  )0;
               sqlstm.sqindv[2] = (         short *)0;
               sqlstm.sqinds[2] = (         int  )0;
               sqlstm.sqharm[2] = (unsigned long )0;
               sqlstm.sqadto[2] = (unsigned short )0;
               sqlstm.sqtdso[2] = (unsigned short )0;
               sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
               sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[3] = (         int  )0;
               sqlstm.sqindv[3] = (         short *)0;
               sqlstm.sqinds[3] = (         int  )0;
               sqlstm.sqharm[3] = (unsigned long )0;
               sqlstm.sqadto[3] = (unsigned short )0;
               sqlstm.sqtdso[3] = (unsigned short )0;
               sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
               sqlstm.sqhstl[4] = (unsigned long )20;
               sqlstm.sqhsts[4] = (         int  )0;
               sqlstm.sqindv[4] = (         short *)0;
               sqlstm.sqinds[4] = (         int  )0;
               sqlstm.sqharm[4] = (unsigned long )0;
               sqlstm.sqadto[4] = (unsigned short )0;
               sqlstm.sqtdso[4] = (unsigned short )0;
               sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
               sqlstm.sqhstl[5] = (unsigned long )10;
               sqlstm.sqhsts[5] = (         int  )0;
               sqlstm.sqindv[5] = (         short *)0;
               sqlstm.sqinds[5] = (         int  )0;
               sqlstm.sqharm[5] = (unsigned long )0;
               sqlstm.sqadto[5] = (unsigned short )0;
               sqlstm.sqtdso[5] = (unsigned short )0;
               sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
               sqlstm.sqhstl[6] = (unsigned long )102;
               sqlstm.sqhsts[6] = (         int  )0;
               sqlstm.sqindv[6] = (         short *)0;
               sqlstm.sqinds[6] = (         int  )0;
               sqlstm.sqharm[6] = (unsigned long )0;
               sqlstm.sqadto[6] = (unsigned short )0;
               sqlstm.sqtdso[6] = (unsigned short )0;
               sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
               sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[7] = (         int  )0;
               sqlstm.sqindv[7] = (         short *)0;
               sqlstm.sqinds[7] = (         int  )0;
               sqlstm.sqharm[7] = (unsigned long )0;
               sqlstm.sqadto[7] = (unsigned short )0;
               sqlstm.sqtdso[7] = (unsigned short )0;
               sqlstm.sqphsv = sqlstm.sqhstv;
               sqlstm.sqphsl = sqlstm.sqhstl;
               sqlstm.sqphss = sqlstm.sqhsts;
               sqlstm.sqpind = sqlstm.sqindv;
               sqlstm.sqpins = sqlstm.sqinds;
               sqlstm.sqparm = sqlstm.sqharm;
               sqlstm.sqparc = sqlstm.sqharc;
               sqlstm.sqpadto = sqlstm.sqadto;
               sqlstm.sqptdso = sqlstm.sqtdso;
               sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
               if (sqlca.sqlcode < 0) goto sqlerr;
}


               temp.erase(temp.find("<INSTANCE>"),temp.find("</INSTANCE>")+strlen("/INSTANCE>")- temp.find("<INSTANCE>")+1);
               found = temp.find("<INSTANCE>");
            }
         }
         if(0 == strcmp(g_ConObj.m_InstanceSp_DB.c_str(),"INST"))
            /* EXEC SQL INSERT INTO HLR_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CONFIG_VALUES (ENTITY_NAME,PARAM_\
ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYP\
E) values (:b0,:b1,:b2,:b3,'OS',to_date(:b4,'mm/dd/yyyy hh24:mi:ss'),:b5)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )2929;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[2] = (unsigned long )20;
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[3] = (unsigned long )10;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[4] = (unsigned long )102;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[5] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}




         /* EXEC SQL COMMIT; */ 

{
         struct sqlexd sqlstm;
         sqlstm.sqlvsn = 12;
         sqlstm.arrsiz = 8;
         sqlstm.sqladtp = &sqladt;
         sqlstm.sqltdsp = &sqltds;
         sqlstm.iters = (unsigned int  )1;
         sqlstm.offset = (unsigned int  )2968;
         sqlstm.cud = sqlcud0;
         sqlstm.sqlest = (unsigned char  *)&sqlca;
         sqlstm.sqlety = (unsigned short)256;
         sqlstm.occurs = (unsigned int  )0;
         sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
         if (sqlca.sqlcode < 0) goto sqlerr;
}


      }
      else if(first == 180)
      {
         Param_ID = first;
         int found;
         string HLR_NETWORK = (string)g_ConObj.m_ModuleMap.find(1)->second;

         string searchFora ("<NETWORK_");    

         found = HLR_NETWORK.find( searchFora );


         while(found != string::npos) 
         {  

            string replaceBya ("<NETWORK>");
            HLR_NETWORK.replace( found, strlen("<NETWORK_00>"), replaceBya );
            searchFora = "</NETWORK_";    
            replaceBya = "</NETWORK>";
            found = HLR_NETWORK.find( searchFora );

            HLR_NETWORK.replace( found,strlen("</NETWORK_00>"), replaceBya );
            string searchFora ("<NETWORK_");    
            found = HLR_NETWORK.find( searchFora );
         }

         string temp =  complexMap.find(first)->second; 
         searchFora ="<NETWORK_";    
         found = temp.find( searchFora );
         if(found == -1)
         {
            ELOG(0,0,"!!!!!!!!!!NETWORK_ENABLE_FLAG Tag not Found in DOTA!!!!!!!!");
         }
         else
         {
            while(found != string::npos) 
            {  
               string replaceBya ("<NETWORK>");
               temp.replace( found, strlen("<NETWORK_00>"), replaceBya );
               searchFora = "</NETWORK_";    
               replaceBya = "</NETWORK>";
               found = temp.find( searchFora );
               temp.replace( found,strlen("</NETWORK_00>"), replaceBya );
               string searchFora ("<NETWORK_");    
               found = temp.find( searchFora );
            }
            found = HLR_NETWORK.find("<NETWORK>");
            while(found != string::npos)
            {
               int fir = HLR_NETWORK.find("<NETWORK>")+strlen("NETWORK>")+1;
               int last =HLR_NETWORK.find("</NETWORK>");
               string value1 = HLR_NETWORK.substr(fir,last-fir);
               HLR_NETWORK.erase(HLR_NETWORK.find("<NETWORK>"),HLR_NETWORK.find("</NETWORK>")+strlen("/NETWORK>")- HLR_NETWORK.find("<NETWORK>")+1);

               found = temp.find("<NETWORK>");


               fir = temp.find("<NETWORK>")+strlen("NETWORK>")+1;
               last =temp.find("</NETWORK>");
               string value2 = temp.substr(fir,last-fir);

               //   value2 = value1+":"+value2;
               strcpy(Value,value1.c_str());


               Count_Val++;
               //  if(0 != strcmp(g_ConObj.m_InstanceSp_DB.c_str(),"INST"))
               /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,25,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
               struct sqlexd sqlstm;
               sqlstm.sqlvsn = 12;
               sqlstm.arrsiz = 8;
               sqlstm.sqladtp = &sqladt;
               sqlstm.sqltdsp = &sqltds;
               sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENT\
ITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING\
_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,25,:b2,\
:b3,:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
               sqlstm.iters = (unsigned int  )1;
               sqlstm.offset = (unsigned int  )2983;
               sqlstm.cud = sqlcud0;
               sqlstm.sqlest = (unsigned char  *)&sqlca;
               sqlstm.sqlety = (unsigned short)256;
               sqlstm.occurs = (unsigned int  )0;
               sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
               sqlstm.sqhstl[0] = (unsigned long )20;
               sqlstm.sqhsts[0] = (         int  )0;
               sqlstm.sqindv[0] = (         short *)0;
               sqlstm.sqinds[0] = (         int  )0;
               sqlstm.sqharm[0] = (unsigned long )0;
               sqlstm.sqadto[0] = (unsigned short )0;
               sqlstm.sqtdso[0] = (unsigned short )0;
               sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
               sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[1] = (         int  )0;
               sqlstm.sqindv[1] = (         short *)0;
               sqlstm.sqinds[1] = (         int  )0;
               sqlstm.sqharm[1] = (unsigned long )0;
               sqlstm.sqadto[1] = (unsigned short )0;
               sqlstm.sqtdso[1] = (unsigned short )0;
               sqlstm.sqhstv[2] = (unsigned char  *)Value;
               sqlstm.sqhstl[2] = (unsigned long )100000;
               sqlstm.sqhsts[2] = (         int  )0;
               sqlstm.sqindv[2] = (         short *)0;
               sqlstm.sqinds[2] = (         int  )0;
               sqlstm.sqharm[2] = (unsigned long )0;
               sqlstm.sqadto[2] = (unsigned short )0;
               sqlstm.sqtdso[2] = (unsigned short )0;
               sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
               sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[3] = (         int  )0;
               sqlstm.sqindv[3] = (         short *)0;
               sqlstm.sqinds[3] = (         int  )0;
               sqlstm.sqharm[3] = (unsigned long )0;
               sqlstm.sqadto[3] = (unsigned short )0;
               sqlstm.sqtdso[3] = (unsigned short )0;
               sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
               sqlstm.sqhstl[4] = (unsigned long )20;
               sqlstm.sqhsts[4] = (         int  )0;
               sqlstm.sqindv[4] = (         short *)0;
               sqlstm.sqinds[4] = (         int  )0;
               sqlstm.sqharm[4] = (unsigned long )0;
               sqlstm.sqadto[4] = (unsigned short )0;
               sqlstm.sqtdso[4] = (unsigned short )0;
               sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
               sqlstm.sqhstl[5] = (unsigned long )10;
               sqlstm.sqhsts[5] = (         int  )0;
               sqlstm.sqindv[5] = (         short *)0;
               sqlstm.sqinds[5] = (         int  )0;
               sqlstm.sqharm[5] = (unsigned long )0;
               sqlstm.sqadto[5] = (unsigned short )0;
               sqlstm.sqtdso[5] = (unsigned short )0;
               sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
               sqlstm.sqhstl[6] = (unsigned long )102;
               sqlstm.sqhsts[6] = (         int  )0;
               sqlstm.sqindv[6] = (         short *)0;
               sqlstm.sqinds[6] = (         int  )0;
               sqlstm.sqharm[6] = (unsigned long )0;
               sqlstm.sqadto[6] = (unsigned short )0;
               sqlstm.sqtdso[6] = (unsigned short )0;
               sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
               sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[7] = (         int  )0;
               sqlstm.sqindv[7] = (         short *)0;
               sqlstm.sqinds[7] = (         int  )0;
               sqlstm.sqharm[7] = (unsigned long )0;
               sqlstm.sqadto[7] = (unsigned short )0;
               sqlstm.sqtdso[7] = (unsigned short )0;
               sqlstm.sqphsv = sqlstm.sqhstv;
               sqlstm.sqphsl = sqlstm.sqhstl;
               sqlstm.sqphss = sqlstm.sqhsts;
               sqlstm.sqpind = sqlstm.sqindv;
               sqlstm.sqpins = sqlstm.sqinds;
               sqlstm.sqparm = sqlstm.sqharm;
               sqlstm.sqparc = sqlstm.sqharc;
               sqlstm.sqpadto = sqlstm.sqadto;
               sqlstm.sqptdso = sqlstm.sqtdso;
               sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
               if (sqlca.sqlcode < 0) goto sqlerr;
}


               strcpy(Value,value2.c_str());
               /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,26,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
               struct sqlexd sqlstm;
               sqlstm.sqlvsn = 12;
               sqlstm.arrsiz = 8;
               sqlstm.sqladtp = &sqladt;
               sqlstm.sqltdsp = &sqltds;
               sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENT\
ITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING\
_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,26,:b2,\
:b3,:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
               sqlstm.iters = (unsigned int  )1;
               sqlstm.offset = (unsigned int  )3030;
               sqlstm.cud = sqlcud0;
               sqlstm.sqlest = (unsigned char  *)&sqlca;
               sqlstm.sqlety = (unsigned short)256;
               sqlstm.occurs = (unsigned int  )0;
               sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
               sqlstm.sqhstl[0] = (unsigned long )20;
               sqlstm.sqhsts[0] = (         int  )0;
               sqlstm.sqindv[0] = (         short *)0;
               sqlstm.sqinds[0] = (         int  )0;
               sqlstm.sqharm[0] = (unsigned long )0;
               sqlstm.sqadto[0] = (unsigned short )0;
               sqlstm.sqtdso[0] = (unsigned short )0;
               sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
               sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[1] = (         int  )0;
               sqlstm.sqindv[1] = (         short *)0;
               sqlstm.sqinds[1] = (         int  )0;
               sqlstm.sqharm[1] = (unsigned long )0;
               sqlstm.sqadto[1] = (unsigned short )0;
               sqlstm.sqtdso[1] = (unsigned short )0;
               sqlstm.sqhstv[2] = (unsigned char  *)Value;
               sqlstm.sqhstl[2] = (unsigned long )100000;
               sqlstm.sqhsts[2] = (         int  )0;
               sqlstm.sqindv[2] = (         short *)0;
               sqlstm.sqinds[2] = (         int  )0;
               sqlstm.sqharm[2] = (unsigned long )0;
               sqlstm.sqadto[2] = (unsigned short )0;
               sqlstm.sqtdso[2] = (unsigned short )0;
               sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
               sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[3] = (         int  )0;
               sqlstm.sqindv[3] = (         short *)0;
               sqlstm.sqinds[3] = (         int  )0;
               sqlstm.sqharm[3] = (unsigned long )0;
               sqlstm.sqadto[3] = (unsigned short )0;
               sqlstm.sqtdso[3] = (unsigned short )0;
               sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
               sqlstm.sqhstl[4] = (unsigned long )20;
               sqlstm.sqhsts[4] = (         int  )0;
               sqlstm.sqindv[4] = (         short *)0;
               sqlstm.sqinds[4] = (         int  )0;
               sqlstm.sqharm[4] = (unsigned long )0;
               sqlstm.sqadto[4] = (unsigned short )0;
               sqlstm.sqtdso[4] = (unsigned short )0;
               sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
               sqlstm.sqhstl[5] = (unsigned long )10;
               sqlstm.sqhsts[5] = (         int  )0;
               sqlstm.sqindv[5] = (         short *)0;
               sqlstm.sqinds[5] = (         int  )0;
               sqlstm.sqharm[5] = (unsigned long )0;
               sqlstm.sqadto[5] = (unsigned short )0;
               sqlstm.sqtdso[5] = (unsigned short )0;
               sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
               sqlstm.sqhstl[6] = (unsigned long )102;
               sqlstm.sqhsts[6] = (         int  )0;
               sqlstm.sqindv[6] = (         short *)0;
               sqlstm.sqinds[6] = (         int  )0;
               sqlstm.sqharm[6] = (unsigned long )0;
               sqlstm.sqadto[6] = (unsigned short )0;
               sqlstm.sqtdso[6] = (unsigned short )0;
               sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
               sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[7] = (         int  )0;
               sqlstm.sqindv[7] = (         short *)0;
               sqlstm.sqinds[7] = (         int  )0;
               sqlstm.sqharm[7] = (unsigned long )0;
               sqlstm.sqadto[7] = (unsigned short )0;
               sqlstm.sqtdso[7] = (unsigned short )0;
               sqlstm.sqphsv = sqlstm.sqhstv;
               sqlstm.sqphsl = sqlstm.sqhstl;
               sqlstm.sqphss = sqlstm.sqhsts;
               sqlstm.sqpind = sqlstm.sqindv;
               sqlstm.sqpins = sqlstm.sqinds;
               sqlstm.sqparm = sqlstm.sqharm;
               sqlstm.sqparc = sqlstm.sqharc;
               sqlstm.sqpadto = sqlstm.sqadto;
               sqlstm.sqptdso = sqlstm.sqtdso;
               sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
               if (sqlca.sqlcode < 0) goto sqlerr;
}



               temp.erase(temp.find("<NETWORK>"),temp.find("</NETWORK>")+strlen("/NETWORK>")- temp.find("<NETWORK>")+1);
               found = temp.find("<NETWORK>");
            }
         }
         if(0 == strcmp(g_ConObj.m_InstanceSp_DB.c_str(),"INST"))
            /* EXEC SQL INSERT INTO HLR_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CONFIG_VALUES (ENTITY_NAME,PARAM_\
ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYP\
E) values (:b0,:b1,:b2,:b3,'OS',to_date(:b4,'mm/dd/yyyy hh24:mi:ss'),:b5)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )3077;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[2] = (unsigned long )20;
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[3] = (unsigned long )10;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[4] = (unsigned long )102;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[5] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}




         /* EXEC SQL COMMIT; */ 

{
         struct sqlexd sqlstm;
         sqlstm.sqlvsn = 12;
         sqlstm.arrsiz = 8;
         sqlstm.sqladtp = &sqladt;
         sqlstm.sqltdsp = &sqltds;
         sqlstm.iters = (unsigned int  )1;
         sqlstm.offset = (unsigned int  )3116;
         sqlstm.cud = sqlcud0;
         sqlstm.sqlest = (unsigned char  *)&sqlca;
         sqlstm.sqlety = (unsigned short)256;
         sqlstm.occurs = (unsigned int  )0;
         sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
         if (sqlca.sqlcode < 0) goto sqlerr;
}


      }
      else if(first == 181)
      {
         Param_ID = first;
         int found;
         string temp =  complexMap.find(first)->second; 
         string searchFora ("<CODE_");    
         found = temp.find( searchFora );
         if(found == -1)
         {
            Count_Val++;

            /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,27,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENTITY\
_NAME,PARAM_ID,SUB_PARAM_ID,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDA\
TED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,27,:b2,:b3,:b4,'OS',to\
_date(:b5,'mm/dd/yyyy hh24:mi:ss'),:b6)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )3131;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)&Count_Val;
            sqlstm.sqhstl[2] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[3] = (unsigned long )20;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[4] = (unsigned long )10;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[5] = (unsigned long )102;
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqhstv[6] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[6] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[6] = (         int  )0;
            sqlstm.sqindv[6] = (         short *)0;
            sqlstm.sqinds[6] = (         int  )0;
            sqlstm.sqharm[6] = (unsigned long )0;
            sqlstm.sqadto[6] = (unsigned short )0;
            sqlstm.sqtdso[6] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}




         }
         else
         {
            while(found != string::npos) 
            {  
               string replaceBya ("<CODE>");
               temp.replace( found, strlen("<CODE_00>"), replaceBya );
               searchFora = "</CODE_";    
               replaceBya = "</CODE>";
               found = temp.find( searchFora );
               temp.replace( found,strlen("</CODE_00>"), replaceBya );
               string searchFora ("<CODE_");    
               found = temp.find( searchFora );
            }
            found = temp.find("<CODE>");
            while(found != string::npos)
            {
               int fir = temp.find("<CODE>")+strlen("CODE>")+1;
               int last =temp.find("</CODE>");
               string value1 = temp.substr(fir,last-fir);
               Param_ID = first ;
               strcpy(Value,value1.c_str());
               Count_Val++;
               /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,27,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
               struct sqlexd sqlstm;
               sqlstm.sqlvsn = 12;
               sqlstm.arrsiz = 8;
               sqlstm.sqladtp = &sqladt;
               sqlstm.sqltdsp = &sqltds;
               sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENT\
ITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING\
_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,27,:b2,\
:b3,:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
               sqlstm.iters = (unsigned int  )1;
               sqlstm.offset = (unsigned int  )3174;
               sqlstm.cud = sqlcud0;
               sqlstm.sqlest = (unsigned char  *)&sqlca;
               sqlstm.sqlety = (unsigned short)256;
               sqlstm.occurs = (unsigned int  )0;
               sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
               sqlstm.sqhstl[0] = (unsigned long )20;
               sqlstm.sqhsts[0] = (         int  )0;
               sqlstm.sqindv[0] = (         short *)0;
               sqlstm.sqinds[0] = (         int  )0;
               sqlstm.sqharm[0] = (unsigned long )0;
               sqlstm.sqadto[0] = (unsigned short )0;
               sqlstm.sqtdso[0] = (unsigned short )0;
               sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
               sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[1] = (         int  )0;
               sqlstm.sqindv[1] = (         short *)0;
               sqlstm.sqinds[1] = (         int  )0;
               sqlstm.sqharm[1] = (unsigned long )0;
               sqlstm.sqadto[1] = (unsigned short )0;
               sqlstm.sqtdso[1] = (unsigned short )0;
               sqlstm.sqhstv[2] = (unsigned char  *)Value;
               sqlstm.sqhstl[2] = (unsigned long )100000;
               sqlstm.sqhsts[2] = (         int  )0;
               sqlstm.sqindv[2] = (         short *)0;
               sqlstm.sqinds[2] = (         int  )0;
               sqlstm.sqharm[2] = (unsigned long )0;
               sqlstm.sqadto[2] = (unsigned short )0;
               sqlstm.sqtdso[2] = (unsigned short )0;
               sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
               sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[3] = (         int  )0;
               sqlstm.sqindv[3] = (         short *)0;
               sqlstm.sqinds[3] = (         int  )0;
               sqlstm.sqharm[3] = (unsigned long )0;
               sqlstm.sqadto[3] = (unsigned short )0;
               sqlstm.sqtdso[3] = (unsigned short )0;
               sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
               sqlstm.sqhstl[4] = (unsigned long )20;
               sqlstm.sqhsts[4] = (         int  )0;
               sqlstm.sqindv[4] = (         short *)0;
               sqlstm.sqinds[4] = (         int  )0;
               sqlstm.sqharm[4] = (unsigned long )0;
               sqlstm.sqadto[4] = (unsigned short )0;
               sqlstm.sqtdso[4] = (unsigned short )0;
               sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
               sqlstm.sqhstl[5] = (unsigned long )10;
               sqlstm.sqhsts[5] = (         int  )0;
               sqlstm.sqindv[5] = (         short *)0;
               sqlstm.sqinds[5] = (         int  )0;
               sqlstm.sqharm[5] = (unsigned long )0;
               sqlstm.sqadto[5] = (unsigned short )0;
               sqlstm.sqtdso[5] = (unsigned short )0;
               sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
               sqlstm.sqhstl[6] = (unsigned long )102;
               sqlstm.sqhsts[6] = (         int  )0;
               sqlstm.sqindv[6] = (         short *)0;
               sqlstm.sqinds[6] = (         int  )0;
               sqlstm.sqharm[6] = (unsigned long )0;
               sqlstm.sqadto[6] = (unsigned short )0;
               sqlstm.sqtdso[6] = (unsigned short )0;
               sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
               sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[7] = (         int  )0;
               sqlstm.sqindv[7] = (         short *)0;
               sqlstm.sqinds[7] = (         int  )0;
               sqlstm.sqharm[7] = (unsigned long )0;
               sqlstm.sqadto[7] = (unsigned short )0;
               sqlstm.sqtdso[7] = (unsigned short )0;
               sqlstm.sqphsv = sqlstm.sqhstv;
               sqlstm.sqphsl = sqlstm.sqhstl;
               sqlstm.sqphss = sqlstm.sqhsts;
               sqlstm.sqpind = sqlstm.sqindv;
               sqlstm.sqpins = sqlstm.sqinds;
               sqlstm.sqparm = sqlstm.sqharm;
               sqlstm.sqparc = sqlstm.sqharc;
               sqlstm.sqpadto = sqlstm.sqadto;
               sqlstm.sqptdso = sqlstm.sqtdso;
               sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
               if (sqlca.sqlcode < 0) goto sqlerr;
}


               temp.erase(temp.find("<CODE>"),temp.find("</CODE>")+strlen("/CODE>")- temp.find("<CODE>")+1);
               found = temp.find("<CODE>");
            }
         }
         if(0 == strcmp(g_ConObj.m_InstanceSp_DB.c_str(),"INST"))
            /* EXEC SQL INSERT INTO HLR_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CONFIG_VALUES (ENTITY_NAME,PARAM_\
ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYP\
E) values (:b0,:b1,:b2,:b3,'OS',to_date(:b4,'mm/dd/yyyy hh24:mi:ss'),:b5)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )3221;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[2] = (unsigned long )20;
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[3] = (unsigned long )10;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[4] = (unsigned long )102;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[5] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}




         /* EXEC SQL COMMIT; */ 

{
         struct sqlexd sqlstm;
         sqlstm.sqlvsn = 12;
         sqlstm.arrsiz = 8;
         sqlstm.sqladtp = &sqladt;
         sqlstm.sqltdsp = &sqltds;
         sqlstm.iters = (unsigned int  )1;
         sqlstm.offset = (unsigned int  )3260;
         sqlstm.cud = sqlcud0;
         sqlstm.sqlest = (unsigned char  *)&sqlca;
         sqlstm.sqlety = (unsigned short)256;
         sqlstm.occurs = (unsigned int  )0;
         sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
         if (sqlca.sqlcode < 0) goto sqlerr;
}


      }

      else if(first == 185)
      {
         Param_ID = first;
         int found;

         string HLR_NETWORK = (string)g_ConObj.m_ModuleMap.find(1)->second;

         string searchFora ("<NETWORK_");    

         found = HLR_NETWORK.find( searchFora );


         while(found != string::npos) 
         {  

            string replaceBya ("<NETWORK>");
            HLR_NETWORK.replace( found, strlen("<NETWORK_00>"), replaceBya );
            searchFora = "</NETWORK_";    
            replaceBya = "</NETWORK>";
            found = HLR_NETWORK.find( searchFora );

            HLR_NETWORK.replace( found,strlen("</NETWORK_00>"), replaceBya );
            searchFora = "<NETWORK_";    
            found = HLR_NETWORK.find( searchFora );
         }

         string temp =  complexMap.find(first)->second;

         searchFora = "<NETWORK_";   
         found = temp.find( searchFora );

         if(found == -1)
         {
            ELOG(0,0,"!!!!!!!!!!! NETWORK Tag Not Found in ESME !!!!!!!!!!!!!!");
         }

         while(found != string::npos) 
         {  
            string replaceBya ("<NETWORK>");
            temp.replace( found, strlen("<NETWORK_00>"), replaceBya );
            searchFora = "</NETWORK_";    
            replaceBya = "</NETWORK>";
            found = temp.find( searchFora );
            temp.replace( found,strlen("</NETWORK_00>"), replaceBya );
            string searchFora ("<NETWORK_");    
            found = temp.find( searchFora );
         }



         found = HLR_NETWORK.find("<NETWORK>");
         while(found != string::npos)
         {
            int fir = HLR_NETWORK.find("<NETWORK>")+strlen("NETWORK>")+1;
            int last =HLR_NETWORK.find("</NETWORK>");
            string value1 = HLR_NETWORK.substr(fir,last-fir);
            HLR_NETWORK.erase(HLR_NETWORK.find("<NETWORK>"),HLR_NETWORK.find("</NETWORK>")+strlen("/NETWORK>")- HLR_NETWORK.find("<NETWORK>")+1);




            fir = temp.find("<NETWORK>")+strlen("NETWORK>")+1;
            last =temp.find("</NETWORK>");
            string value2 = temp.substr(fir,last-fir); 
            string temp1 = Parser::getValue(temp,"FLAG");
            strcpy(Value,value1.c_str());

            Count_Val++;
            //   if(0 != strcmp(g_ConObj.m_InstanceSp_DB.c_str(),"INST"))
            /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,28,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENTITY\
_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PO\
RT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,28,:b2,:b3\
,:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )3275;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)Value;
            sqlstm.sqhstl[2] = (unsigned long )100000;
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
            sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[4] = (unsigned long )20;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[5] = (unsigned long )10;
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[6] = (unsigned long )102;
            sqlstm.sqhsts[6] = (         int  )0;
            sqlstm.sqindv[6] = (         short *)0;
            sqlstm.sqinds[6] = (         int  )0;
            sqlstm.sqharm[6] = (unsigned long )0;
            sqlstm.sqadto[6] = (unsigned short )0;
            sqlstm.sqtdso[6] = (unsigned short )0;
            sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[7] = (         int  )0;
            sqlstm.sqindv[7] = (         short *)0;
            sqlstm.sqinds[7] = (         int  )0;
            sqlstm.sqharm[7] = (unsigned long )0;
            sqlstm.sqadto[7] = (unsigned short )0;
            sqlstm.sqtdso[7] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}



            strcpy(Value,temp1.c_str());


            /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,29,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENTITY\
_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PO\
RT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,29,:b2,:b3\
,:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )3322;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)Value;
            sqlstm.sqhstl[2] = (unsigned long )100000;
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
            sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[4] = (unsigned long )20;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[5] = (unsigned long )10;
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[6] = (unsigned long )102;
            sqlstm.sqhsts[6] = (         int  )0;
            sqlstm.sqindv[6] = (         short *)0;
            sqlstm.sqinds[6] = (         int  )0;
            sqlstm.sqharm[6] = (unsigned long )0;
            sqlstm.sqadto[6] = (unsigned short )0;
            sqlstm.sqtdso[6] = (unsigned short )0;
            sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[7] = (         int  )0;
            sqlstm.sqindv[7] = (         short *)0;
            sqlstm.sqinds[7] = (         int  )0;
            sqlstm.sqharm[7] = (unsigned long )0;
            sqlstm.sqadto[7] = (unsigned short )0;
            sqlstm.sqtdso[7] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}



            temp1 = Parser::getValue(temp,"ESME_FIRST_ACT_INFORM_TYPE");

            strcpy(Value,temp1.c_str());
            if( 0 != temp1.size() )
               /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,30,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
               struct sqlexd sqlstm;
               sqlstm.sqlvsn = 12;
               sqlstm.arrsiz = 8;
               sqlstm.sqladtp = &sqladt;
               sqlstm.sqltdsp = &sqltds;
               sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENT\
ITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING\
_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,30,:b2,\
:b3,:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
               sqlstm.iters = (unsigned int  )1;
               sqlstm.offset = (unsigned int  )3369;
               sqlstm.cud = sqlcud0;
               sqlstm.sqlest = (unsigned char  *)&sqlca;
               sqlstm.sqlety = (unsigned short)256;
               sqlstm.occurs = (unsigned int  )0;
               sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
               sqlstm.sqhstl[0] = (unsigned long )20;
               sqlstm.sqhsts[0] = (         int  )0;
               sqlstm.sqindv[0] = (         short *)0;
               sqlstm.sqinds[0] = (         int  )0;
               sqlstm.sqharm[0] = (unsigned long )0;
               sqlstm.sqadto[0] = (unsigned short )0;
               sqlstm.sqtdso[0] = (unsigned short )0;
               sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
               sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[1] = (         int  )0;
               sqlstm.sqindv[1] = (         short *)0;
               sqlstm.sqinds[1] = (         int  )0;
               sqlstm.sqharm[1] = (unsigned long )0;
               sqlstm.sqadto[1] = (unsigned short )0;
               sqlstm.sqtdso[1] = (unsigned short )0;
               sqlstm.sqhstv[2] = (unsigned char  *)Value;
               sqlstm.sqhstl[2] = (unsigned long )100000;
               sqlstm.sqhsts[2] = (         int  )0;
               sqlstm.sqindv[2] = (         short *)0;
               sqlstm.sqinds[2] = (         int  )0;
               sqlstm.sqharm[2] = (unsigned long )0;
               sqlstm.sqadto[2] = (unsigned short )0;
               sqlstm.sqtdso[2] = (unsigned short )0;
               sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
               sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[3] = (         int  )0;
               sqlstm.sqindv[3] = (         short *)0;
               sqlstm.sqinds[3] = (         int  )0;
               sqlstm.sqharm[3] = (unsigned long )0;
               sqlstm.sqadto[3] = (unsigned short )0;
               sqlstm.sqtdso[3] = (unsigned short )0;
               sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
               sqlstm.sqhstl[4] = (unsigned long )20;
               sqlstm.sqhsts[4] = (         int  )0;
               sqlstm.sqindv[4] = (         short *)0;
               sqlstm.sqinds[4] = (         int  )0;
               sqlstm.sqharm[4] = (unsigned long )0;
               sqlstm.sqadto[4] = (unsigned short )0;
               sqlstm.sqtdso[4] = (unsigned short )0;
               sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
               sqlstm.sqhstl[5] = (unsigned long )10;
               sqlstm.sqhsts[5] = (         int  )0;
               sqlstm.sqindv[5] = (         short *)0;
               sqlstm.sqinds[5] = (         int  )0;
               sqlstm.sqharm[5] = (unsigned long )0;
               sqlstm.sqadto[5] = (unsigned short )0;
               sqlstm.sqtdso[5] = (unsigned short )0;
               sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
               sqlstm.sqhstl[6] = (unsigned long )102;
               sqlstm.sqhsts[6] = (         int  )0;
               sqlstm.sqindv[6] = (         short *)0;
               sqlstm.sqinds[6] = (         int  )0;
               sqlstm.sqharm[6] = (unsigned long )0;
               sqlstm.sqadto[6] = (unsigned short )0;
               sqlstm.sqtdso[6] = (unsigned short )0;
               sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
               sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[7] = (         int  )0;
               sqlstm.sqindv[7] = (         short *)0;
               sqlstm.sqinds[7] = (         int  )0;
               sqlstm.sqharm[7] = (unsigned long )0;
               sqlstm.sqadto[7] = (unsigned short )0;
               sqlstm.sqtdso[7] = (unsigned short )0;
               sqlstm.sqphsv = sqlstm.sqhstv;
               sqlstm.sqphsl = sqlstm.sqhstl;
               sqlstm.sqphss = sqlstm.sqhsts;
               sqlstm.sqpind = sqlstm.sqindv;
               sqlstm.sqpins = sqlstm.sqinds;
               sqlstm.sqparm = sqlstm.sqharm;
               sqlstm.sqparc = sqlstm.sqharc;
               sqlstm.sqpadto = sqlstm.sqadto;
               sqlstm.sqptdso = sqlstm.sqtdso;
               sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
               if (sqlca.sqlcode < 0) goto sqlerr;
}


            else
               /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,30,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
               struct sqlexd sqlstm;
               sqlstm.sqlvsn = 12;
               sqlstm.arrsiz = 8;
               sqlstm.sqladtp = &sqladt;
               sqlstm.sqltdsp = &sqltds;
               sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENT\
ITY_NAME,PARAM_ID,SUB_PARAM_ID,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_U\
PDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,30,:b2,:b3,:b4,'OS'\
,to_date(:b5,'mm/dd/yyyy hh24:mi:ss'),:b6)";
               sqlstm.iters = (unsigned int  )1;
               sqlstm.offset = (unsigned int  )3416;
               sqlstm.cud = sqlcud0;
               sqlstm.sqlest = (unsigned char  *)&sqlca;
               sqlstm.sqlety = (unsigned short)256;
               sqlstm.occurs = (unsigned int  )0;
               sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
               sqlstm.sqhstl[0] = (unsigned long )20;
               sqlstm.sqhsts[0] = (         int  )0;
               sqlstm.sqindv[0] = (         short *)0;
               sqlstm.sqinds[0] = (         int  )0;
               sqlstm.sqharm[0] = (unsigned long )0;
               sqlstm.sqadto[0] = (unsigned short )0;
               sqlstm.sqtdso[0] = (unsigned short )0;
               sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
               sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[1] = (         int  )0;
               sqlstm.sqindv[1] = (         short *)0;
               sqlstm.sqinds[1] = (         int  )0;
               sqlstm.sqharm[1] = (unsigned long )0;
               sqlstm.sqadto[1] = (unsigned short )0;
               sqlstm.sqtdso[1] = (unsigned short )0;
               sqlstm.sqhstv[2] = (unsigned char  *)&Count_Val;
               sqlstm.sqhstl[2] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[2] = (         int  )0;
               sqlstm.sqindv[2] = (         short *)0;
               sqlstm.sqinds[2] = (         int  )0;
               sqlstm.sqharm[2] = (unsigned long )0;
               sqlstm.sqadto[2] = (unsigned short )0;
               sqlstm.sqtdso[2] = (unsigned short )0;
               sqlstm.sqhstv[3] = (unsigned char  *)IPaddress;
               sqlstm.sqhstl[3] = (unsigned long )20;
               sqlstm.sqhsts[3] = (         int  )0;
               sqlstm.sqindv[3] = (         short *)0;
               sqlstm.sqinds[3] = (         int  )0;
               sqlstm.sqharm[3] = (unsigned long )0;
               sqlstm.sqadto[3] = (unsigned short )0;
               sqlstm.sqtdso[3] = (unsigned short )0;
               sqlstm.sqhstv[4] = (unsigned char  *)ProvPort;
               sqlstm.sqhstl[4] = (unsigned long )10;
               sqlstm.sqhsts[4] = (         int  )0;
               sqlstm.sqindv[4] = (         short *)0;
               sqlstm.sqinds[4] = (         int  )0;
               sqlstm.sqharm[4] = (unsigned long )0;
               sqlstm.sqadto[4] = (unsigned short )0;
               sqlstm.sqtdso[4] = (unsigned short )0;
               sqlstm.sqhstv[5] = (unsigned char  *)&CharTime;
               sqlstm.sqhstl[5] = (unsigned long )102;
               sqlstm.sqhsts[5] = (         int  )0;
               sqlstm.sqindv[5] = (         short *)0;
               sqlstm.sqinds[5] = (         int  )0;
               sqlstm.sqharm[5] = (unsigned long )0;
               sqlstm.sqadto[5] = (unsigned short )0;
               sqlstm.sqtdso[5] = (unsigned short )0;
               sqlstm.sqhstv[6] = (unsigned char  *)&InstanceType;
               sqlstm.sqhstl[6] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[6] = (         int  )0;
               sqlstm.sqindv[6] = (         short *)0;
               sqlstm.sqinds[6] = (         int  )0;
               sqlstm.sqharm[6] = (unsigned long )0;
               sqlstm.sqadto[6] = (unsigned short )0;
               sqlstm.sqtdso[6] = (unsigned short )0;
               sqlstm.sqphsv = sqlstm.sqhstv;
               sqlstm.sqphsl = sqlstm.sqhstl;
               sqlstm.sqphss = sqlstm.sqhsts;
               sqlstm.sqpind = sqlstm.sqindv;
               sqlstm.sqpins = sqlstm.sqinds;
               sqlstm.sqparm = sqlstm.sqharm;
               sqlstm.sqparc = sqlstm.sqharc;
               sqlstm.sqpadto = sqlstm.sqadto;
               sqlstm.sqptdso = sqlstm.sqtdso;
               sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
               if (sqlca.sqlcode < 0) goto sqlerr;
}




            temp1 = Parser::getValue(temp,"SUBS_SENDER_ID");
            strcpy(Value,temp1.c_str());
            /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,31,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENTITY\
_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PO\
RT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,31,:b2,:b3\
,:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )3459;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)Value;
            sqlstm.sqhstl[2] = (unsigned long )100000;
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
            sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[4] = (unsigned long )20;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[5] = (unsigned long )10;
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[6] = (unsigned long )102;
            sqlstm.sqhsts[6] = (         int  )0;
            sqlstm.sqindv[6] = (         short *)0;
            sqlstm.sqinds[6] = (         int  )0;
            sqlstm.sqharm[6] = (unsigned long )0;
            sqlstm.sqadto[6] = (unsigned short )0;
            sqlstm.sqtdso[6] = (unsigned short )0;
            sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[7] = (         int  )0;
            sqlstm.sqindv[7] = (         short *)0;
            sqlstm.sqinds[7] = (         int  )0;
            sqlstm.sqharm[7] = (unsigned long )0;
            sqlstm.sqadto[7] = (unsigned short )0;
            sqlstm.sqtdso[7] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}


            temp1 = Parser::getValue(temp,"SMS_TEXT_TO_SUBSCRIBER");
            strcpy(Value,temp1.c_str());
            /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,32,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENTITY\
_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PO\
RT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,32,:b2,:b3\
,:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )3506;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)Value;
            sqlstm.sqhstl[2] = (unsigned long )100000;
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
            sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[4] = (unsigned long )20;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[5] = (unsigned long )10;
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[6] = (unsigned long )102;
            sqlstm.sqhsts[6] = (         int  )0;
            sqlstm.sqindv[6] = (         short *)0;
            sqlstm.sqinds[6] = (         int  )0;
            sqlstm.sqharm[6] = (unsigned long )0;
            sqlstm.sqadto[6] = (unsigned short )0;
            sqlstm.sqtdso[6] = (unsigned short )0;
            sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[7] = (         int  )0;
            sqlstm.sqindv[7] = (         short *)0;
            sqlstm.sqinds[7] = (         int  )0;
            sqlstm.sqharm[7] = (unsigned long )0;
            sqlstm.sqadto[7] = (unsigned short )0;
            sqlstm.sqtdso[7] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}


            temp1 = Parser::getValue(temp,"RC_SENDER_ID");
            strcpy(Value,temp1.c_str());
            /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,33,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENTITY\
_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PO\
RT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,33,:b2,:b3\
,:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )3553;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)Value;
            sqlstm.sqhstl[2] = (unsigned long )100000;
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
            sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[4] = (unsigned long )20;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[5] = (unsigned long )10;
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[6] = (unsigned long )102;
            sqlstm.sqhsts[6] = (         int  )0;
            sqlstm.sqindv[6] = (         short *)0;
            sqlstm.sqinds[6] = (         int  )0;
            sqlstm.sqharm[6] = (unsigned long )0;
            sqlstm.sqadto[6] = (unsigned short )0;
            sqlstm.sqtdso[6] = (unsigned short )0;
            sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[7] = (         int  )0;
            sqlstm.sqindv[7] = (         short *)0;
            sqlstm.sqinds[7] = (         int  )0;
            sqlstm.sqharm[7] = (unsigned long )0;
            sqlstm.sqadto[7] = (unsigned short )0;
            sqlstm.sqtdso[7] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}


            temp1 = Parser::getValue(temp,"SMS_TEXT_TO_RC_USER");
            strcpy(Value,temp1.c_str());
            /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,34,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENTITY\
_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PO\
RT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,34,:b2,:b3\
,:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )3600;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)Value;
            sqlstm.sqhstl[2] = (unsigned long )100000;
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
            sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[4] = (unsigned long )20;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[5] = (unsigned long )10;
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[6] = (unsigned long )102;
            sqlstm.sqhsts[6] = (         int  )0;
            sqlstm.sqindv[6] = (         short *)0;
            sqlstm.sqinds[6] = (         int  )0;
            sqlstm.sqharm[6] = (unsigned long )0;
            sqlstm.sqadto[6] = (unsigned short )0;
            sqlstm.sqtdso[6] = (unsigned short )0;
            sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[7] = (         int  )0;
            sqlstm.sqindv[7] = (         short *)0;
            sqlstm.sqinds[7] = (         int  )0;
            sqlstm.sqharm[7] = (unsigned long )0;
            sqlstm.sqadto[7] = (unsigned short )0;
            sqlstm.sqtdso[7] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}


            temp1 = Parser::getValue(temp,"DEST_ADDR_LIST");
            strcpy(Value,temp1.c_str());
            /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,35,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENTITY\
_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PO\
RT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,35,:b2,:b3\
,:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )3647;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)Value;
            sqlstm.sqhstl[2] = (unsigned long )100000;
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
            sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[4] = (unsigned long )20;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[5] = (unsigned long )10;
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[6] = (unsigned long )102;
            sqlstm.sqhsts[6] = (         int  )0;
            sqlstm.sqindv[6] = (         short *)0;
            sqlstm.sqinds[6] = (         int  )0;
            sqlstm.sqharm[6] = (unsigned long )0;
            sqlstm.sqadto[6] = (unsigned short )0;
            sqlstm.sqtdso[6] = (unsigned short )0;
            sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[7] = (         int  )0;
            sqlstm.sqindv[7] = (         short *)0;
            sqlstm.sqinds[7] = (         int  )0;
            sqlstm.sqharm[7] = (unsigned long )0;
            sqlstm.sqadto[7] = (unsigned short )0;
            sqlstm.sqtdso[7] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}


            temp.erase(temp.find("<NETWORK>"),temp.find("</NETWORK>")+strlen("/NETWORK>")- temp.find("<NETWORK>")+1);
            found = temp.find("<NETWORK>");
         }
         if(0 == strcmp(g_ConObj.m_InstanceSp_DB.c_str(),"INST"))
            /* EXEC SQL INSERT INTO HLR_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CONFIG_VALUES (ENTITY_NAME,PARAM_\
ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYP\
E) values (:b0,:b1,:b2,:b3,'OS',to_date(:b4,'mm/dd/yyyy hh24:mi:ss'),:b5)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )3694;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[2] = (unsigned long )20;
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[3] = (unsigned long )10;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[4] = (unsigned long )102;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[5] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}




         /* EXEC SQL COMMIT; */ 

{
         struct sqlexd sqlstm;
         sqlstm.sqlvsn = 12;
         sqlstm.arrsiz = 8;
         sqlstm.sqladtp = &sqladt;
         sqlstm.sqltdsp = &sqltds;
         sqlstm.iters = (unsigned int  )1;
         sqlstm.offset = (unsigned int  )3733;
         sqlstm.cud = sqlcud0;
         sqlstm.sqlest = (unsigned char  *)&sqlca;
         sqlstm.sqlety = (unsigned short)256;
         sqlstm.occurs = (unsigned int  )0;
         sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
         if (sqlca.sqlcode < 0) goto sqlerr;
}


      }

      else if(first == 191)
      {
         Param_ID = first;
         int found;
         string temp =  complexMap.find(first)->second; 
         string searchFora ("<CODE_");    
         found = temp.find( searchFora );
         if(found == -1)
         {
            Count_Val++;

            /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,36,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENTITY\
_NAME,PARAM_ID,SUB_PARAM_ID,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDA\
TED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,36,:b2,:b3,:b4,'OS',to\
_date(:b5,'mm/dd/yyyy hh24:mi:ss'),:b6)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )3748;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)&Count_Val;
            sqlstm.sqhstl[2] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[3] = (unsigned long )20;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[4] = (unsigned long )10;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[5] = (unsigned long )102;
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqhstv[6] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[6] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[6] = (         int  )0;
            sqlstm.sqindv[6] = (         short *)0;
            sqlstm.sqinds[6] = (         int  )0;
            sqlstm.sqharm[6] = (unsigned long )0;
            sqlstm.sqadto[6] = (unsigned short )0;
            sqlstm.sqtdso[6] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}




         }
         else
         {
            while(found != string::npos) 
            {  
               string replaceBya ("<CODE>");
               temp.replace( found, strlen("<CODE_00>"), replaceBya );
               searchFora = "</CODE_";    
               replaceBya = "</CODE>";
               found = temp.find( searchFora );
               temp.replace( found,strlen("</CODE_00>"), replaceBya );
               string searchFora ("<CODE_");    
               found = temp.find( searchFora );
            }
            found = temp.find("<CODE>");
            while(found != string::npos)
            {
               int fir = temp.find("<CODE>")+strlen("CODE>")+1;
               int last =temp.find("</CODE>");
               string value1 = temp.substr(fir,last-fir);
               Param_ID = first ;
               strcpy(Value,value1.c_str());
               Count_Val++;
               /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,36,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
               struct sqlexd sqlstm;
               sqlstm.sqlvsn = 12;
               sqlstm.arrsiz = 8;
               sqlstm.sqladtp = &sqladt;
               sqlstm.sqltdsp = &sqltds;
               sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENT\
ITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING\
_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,36,:b2,\
:b3,:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
               sqlstm.iters = (unsigned int  )1;
               sqlstm.offset = (unsigned int  )3791;
               sqlstm.cud = sqlcud0;
               sqlstm.sqlest = (unsigned char  *)&sqlca;
               sqlstm.sqlety = (unsigned short)256;
               sqlstm.occurs = (unsigned int  )0;
               sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
               sqlstm.sqhstl[0] = (unsigned long )20;
               sqlstm.sqhsts[0] = (         int  )0;
               sqlstm.sqindv[0] = (         short *)0;
               sqlstm.sqinds[0] = (         int  )0;
               sqlstm.sqharm[0] = (unsigned long )0;
               sqlstm.sqadto[0] = (unsigned short )0;
               sqlstm.sqtdso[0] = (unsigned short )0;
               sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
               sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[1] = (         int  )0;
               sqlstm.sqindv[1] = (         short *)0;
               sqlstm.sqinds[1] = (         int  )0;
               sqlstm.sqharm[1] = (unsigned long )0;
               sqlstm.sqadto[1] = (unsigned short )0;
               sqlstm.sqtdso[1] = (unsigned short )0;
               sqlstm.sqhstv[2] = (unsigned char  *)Value;
               sqlstm.sqhstl[2] = (unsigned long )100000;
               sqlstm.sqhsts[2] = (         int  )0;
               sqlstm.sqindv[2] = (         short *)0;
               sqlstm.sqinds[2] = (         int  )0;
               sqlstm.sqharm[2] = (unsigned long )0;
               sqlstm.sqadto[2] = (unsigned short )0;
               sqlstm.sqtdso[2] = (unsigned short )0;
               sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
               sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[3] = (         int  )0;
               sqlstm.sqindv[3] = (         short *)0;
               sqlstm.sqinds[3] = (         int  )0;
               sqlstm.sqharm[3] = (unsigned long )0;
               sqlstm.sqadto[3] = (unsigned short )0;
               sqlstm.sqtdso[3] = (unsigned short )0;
               sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
               sqlstm.sqhstl[4] = (unsigned long )20;
               sqlstm.sqhsts[4] = (         int  )0;
               sqlstm.sqindv[4] = (         short *)0;
               sqlstm.sqinds[4] = (         int  )0;
               sqlstm.sqharm[4] = (unsigned long )0;
               sqlstm.sqadto[4] = (unsigned short )0;
               sqlstm.sqtdso[4] = (unsigned short )0;
               sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
               sqlstm.sqhstl[5] = (unsigned long )10;
               sqlstm.sqhsts[5] = (         int  )0;
               sqlstm.sqindv[5] = (         short *)0;
               sqlstm.sqinds[5] = (         int  )0;
               sqlstm.sqharm[5] = (unsigned long )0;
               sqlstm.sqadto[5] = (unsigned short )0;
               sqlstm.sqtdso[5] = (unsigned short )0;
               sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
               sqlstm.sqhstl[6] = (unsigned long )102;
               sqlstm.sqhsts[6] = (         int  )0;
               sqlstm.sqindv[6] = (         short *)0;
               sqlstm.sqinds[6] = (         int  )0;
               sqlstm.sqharm[6] = (unsigned long )0;
               sqlstm.sqadto[6] = (unsigned short )0;
               sqlstm.sqtdso[6] = (unsigned short )0;
               sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
               sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[7] = (         int  )0;
               sqlstm.sqindv[7] = (         short *)0;
               sqlstm.sqinds[7] = (         int  )0;
               sqlstm.sqharm[7] = (unsigned long )0;
               sqlstm.sqadto[7] = (unsigned short )0;
               sqlstm.sqtdso[7] = (unsigned short )0;
               sqlstm.sqphsv = sqlstm.sqhstv;
               sqlstm.sqphsl = sqlstm.sqhstl;
               sqlstm.sqphss = sqlstm.sqhsts;
               sqlstm.sqpind = sqlstm.sqindv;
               sqlstm.sqpins = sqlstm.sqinds;
               sqlstm.sqparm = sqlstm.sqharm;
               sqlstm.sqparc = sqlstm.sqharc;
               sqlstm.sqpadto = sqlstm.sqadto;
               sqlstm.sqptdso = sqlstm.sqtdso;
               sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
               if (sqlca.sqlcode < 0) goto sqlerr;
}


               temp.erase(temp.find("<CODE>"),temp.find("</CODE>")+strlen("/CODE>")- temp.find("<CODE>")+1);
               found = temp.find("<CODE>");
            }
         }
         if(0 == strcmp(g_ConObj.m_InstanceSp_DB.c_str(),"INST"))
            /* EXEC SQL INSERT INTO HLR_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CONFIG_VALUES (ENTITY_NAME,PARAM_\
ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYP\
E) values (:b0,:b1,:b2,:b3,'OS',to_date(:b4,'mm/dd/yyyy hh24:mi:ss'),:b5)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )3838;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[2] = (unsigned long )20;
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[3] = (unsigned long )10;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[4] = (unsigned long )102;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[5] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}




         /* EXEC SQL COMMIT; */ 

{
         struct sqlexd sqlstm;
         sqlstm.sqlvsn = 12;
         sqlstm.arrsiz = 8;
         sqlstm.sqladtp = &sqladt;
         sqlstm.sqltdsp = &sqltds;
         sqlstm.iters = (unsigned int  )1;
         sqlstm.offset = (unsigned int  )3877;
         sqlstm.cud = sqlcud0;
         sqlstm.sqlest = (unsigned char  *)&sqlca;
         sqlstm.sqlety = (unsigned short)256;
         sqlstm.occurs = (unsigned int  )0;
         sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
         if (sqlca.sqlcode < 0) goto sqlerr;
}


      }
      else if(first == 201)
      {
         Param_ID = first;
         int found;
         string temp =  complexMap.find(first)->second; 
         string searchFora = "<RANGE_";
         found  = temp.find(searchFora);
         if(found == -1)
         {
            ELOG(0,0,"RANGE Tag not Found in SPA");
         }
         else
         {
            while(found != string::npos)
            {
               string replaceBya ("<RANGE>");
               temp.replace( found, strlen("<RANGE_000>"), replaceBya );
               searchFora = "</RANGE_";    
               replaceBya = "</RANGE>";
               found = temp.find( searchFora );
               temp.replace( found,strlen("</RANGE_000>"), replaceBya );
               string searchFora ("<RANGE_");    
               found = temp.find( searchFora );

            }
            found = temp.find("<RANGE>");
            while(found != string::npos)
            {
               int fir = temp.find("<RANGE>")+strlen("RANGE>")+1;
               int last =temp.find("</RANGE>");
               string value1 = temp.substr(fir,last-fir);
               string value2 = Parser::getValue(value1,"START");
               strcpy(Value,value2.c_str());
               Count_Val++;
               /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,38,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
               struct sqlexd sqlstm;
               sqlstm.sqlvsn = 12;
               sqlstm.arrsiz = 8;
               sqlstm.sqladtp = &sqladt;
               sqlstm.sqltdsp = &sqltds;
               sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENT\
ITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING\
_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,38,:b2,\
:b3,:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
               sqlstm.iters = (unsigned int  )1;
               sqlstm.offset = (unsigned int  )3892;
               sqlstm.cud = sqlcud0;
               sqlstm.sqlest = (unsigned char  *)&sqlca;
               sqlstm.sqlety = (unsigned short)256;
               sqlstm.occurs = (unsigned int  )0;
               sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
               sqlstm.sqhstl[0] = (unsigned long )20;
               sqlstm.sqhsts[0] = (         int  )0;
               sqlstm.sqindv[0] = (         short *)0;
               sqlstm.sqinds[0] = (         int  )0;
               sqlstm.sqharm[0] = (unsigned long )0;
               sqlstm.sqadto[0] = (unsigned short )0;
               sqlstm.sqtdso[0] = (unsigned short )0;
               sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
               sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[1] = (         int  )0;
               sqlstm.sqindv[1] = (         short *)0;
               sqlstm.sqinds[1] = (         int  )0;
               sqlstm.sqharm[1] = (unsigned long )0;
               sqlstm.sqadto[1] = (unsigned short )0;
               sqlstm.sqtdso[1] = (unsigned short )0;
               sqlstm.sqhstv[2] = (unsigned char  *)Value;
               sqlstm.sqhstl[2] = (unsigned long )100000;
               sqlstm.sqhsts[2] = (         int  )0;
               sqlstm.sqindv[2] = (         short *)0;
               sqlstm.sqinds[2] = (         int  )0;
               sqlstm.sqharm[2] = (unsigned long )0;
               sqlstm.sqadto[2] = (unsigned short )0;
               sqlstm.sqtdso[2] = (unsigned short )0;
               sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
               sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[3] = (         int  )0;
               sqlstm.sqindv[3] = (         short *)0;
               sqlstm.sqinds[3] = (         int  )0;
               sqlstm.sqharm[3] = (unsigned long )0;
               sqlstm.sqadto[3] = (unsigned short )0;
               sqlstm.sqtdso[3] = (unsigned short )0;
               sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
               sqlstm.sqhstl[4] = (unsigned long )20;
               sqlstm.sqhsts[4] = (         int  )0;
               sqlstm.sqindv[4] = (         short *)0;
               sqlstm.sqinds[4] = (         int  )0;
               sqlstm.sqharm[4] = (unsigned long )0;
               sqlstm.sqadto[4] = (unsigned short )0;
               sqlstm.sqtdso[4] = (unsigned short )0;
               sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
               sqlstm.sqhstl[5] = (unsigned long )10;
               sqlstm.sqhsts[5] = (         int  )0;
               sqlstm.sqindv[5] = (         short *)0;
               sqlstm.sqinds[5] = (         int  )0;
               sqlstm.sqharm[5] = (unsigned long )0;
               sqlstm.sqadto[5] = (unsigned short )0;
               sqlstm.sqtdso[5] = (unsigned short )0;
               sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
               sqlstm.sqhstl[6] = (unsigned long )102;
               sqlstm.sqhsts[6] = (         int  )0;
               sqlstm.sqindv[6] = (         short *)0;
               sqlstm.sqinds[6] = (         int  )0;
               sqlstm.sqharm[6] = (unsigned long )0;
               sqlstm.sqadto[6] = (unsigned short )0;
               sqlstm.sqtdso[6] = (unsigned short )0;
               sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
               sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[7] = (         int  )0;
               sqlstm.sqindv[7] = (         short *)0;
               sqlstm.sqinds[7] = (         int  )0;
               sqlstm.sqharm[7] = (unsigned long )0;
               sqlstm.sqadto[7] = (unsigned short )0;
               sqlstm.sqtdso[7] = (unsigned short )0;
               sqlstm.sqphsv = sqlstm.sqhstv;
               sqlstm.sqphsl = sqlstm.sqhstl;
               sqlstm.sqphss = sqlstm.sqhsts;
               sqlstm.sqpind = sqlstm.sqindv;
               sqlstm.sqpins = sqlstm.sqinds;
               sqlstm.sqparm = sqlstm.sqharm;
               sqlstm.sqparc = sqlstm.sqharc;
               sqlstm.sqpadto = sqlstm.sqadto;
               sqlstm.sqptdso = sqlstm.sqtdso;
               sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
               if (sqlca.sqlcode < 0) goto sqlerr;
}


               value2 = Parser::getValue(value1,"END");
               strcpy(Value,value2.c_str());
               /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,39,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
               struct sqlexd sqlstm;
               sqlstm.sqlvsn = 12;
               sqlstm.arrsiz = 8;
               sqlstm.sqladtp = &sqladt;
               sqlstm.sqltdsp = &sqltds;
               sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENT\
ITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING\
_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,39,:b2,\
:b3,:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
               sqlstm.iters = (unsigned int  )1;
               sqlstm.offset = (unsigned int  )3939;
               sqlstm.cud = sqlcud0;
               sqlstm.sqlest = (unsigned char  *)&sqlca;
               sqlstm.sqlety = (unsigned short)256;
               sqlstm.occurs = (unsigned int  )0;
               sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
               sqlstm.sqhstl[0] = (unsigned long )20;
               sqlstm.sqhsts[0] = (         int  )0;
               sqlstm.sqindv[0] = (         short *)0;
               sqlstm.sqinds[0] = (         int  )0;
               sqlstm.sqharm[0] = (unsigned long )0;
               sqlstm.sqadto[0] = (unsigned short )0;
               sqlstm.sqtdso[0] = (unsigned short )0;
               sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
               sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[1] = (         int  )0;
               sqlstm.sqindv[1] = (         short *)0;
               sqlstm.sqinds[1] = (         int  )0;
               sqlstm.sqharm[1] = (unsigned long )0;
               sqlstm.sqadto[1] = (unsigned short )0;
               sqlstm.sqtdso[1] = (unsigned short )0;
               sqlstm.sqhstv[2] = (unsigned char  *)Value;
               sqlstm.sqhstl[2] = (unsigned long )100000;
               sqlstm.sqhsts[2] = (         int  )0;
               sqlstm.sqindv[2] = (         short *)0;
               sqlstm.sqinds[2] = (         int  )0;
               sqlstm.sqharm[2] = (unsigned long )0;
               sqlstm.sqadto[2] = (unsigned short )0;
               sqlstm.sqtdso[2] = (unsigned short )0;
               sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
               sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[3] = (         int  )0;
               sqlstm.sqindv[3] = (         short *)0;
               sqlstm.sqinds[3] = (         int  )0;
               sqlstm.sqharm[3] = (unsigned long )0;
               sqlstm.sqadto[3] = (unsigned short )0;
               sqlstm.sqtdso[3] = (unsigned short )0;
               sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
               sqlstm.sqhstl[4] = (unsigned long )20;
               sqlstm.sqhsts[4] = (         int  )0;
               sqlstm.sqindv[4] = (         short *)0;
               sqlstm.sqinds[4] = (         int  )0;
               sqlstm.sqharm[4] = (unsigned long )0;
               sqlstm.sqadto[4] = (unsigned short )0;
               sqlstm.sqtdso[4] = (unsigned short )0;
               sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
               sqlstm.sqhstl[5] = (unsigned long )10;
               sqlstm.sqhsts[5] = (         int  )0;
               sqlstm.sqindv[5] = (         short *)0;
               sqlstm.sqinds[5] = (         int  )0;
               sqlstm.sqharm[5] = (unsigned long )0;
               sqlstm.sqadto[5] = (unsigned short )0;
               sqlstm.sqtdso[5] = (unsigned short )0;
               sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
               sqlstm.sqhstl[6] = (unsigned long )102;
               sqlstm.sqhsts[6] = (         int  )0;
               sqlstm.sqindv[6] = (         short *)0;
               sqlstm.sqinds[6] = (         int  )0;
               sqlstm.sqharm[6] = (unsigned long )0;
               sqlstm.sqadto[6] = (unsigned short )0;
               sqlstm.sqtdso[6] = (unsigned short )0;
               sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
               sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[7] = (         int  )0;
               sqlstm.sqindv[7] = (         short *)0;
               sqlstm.sqinds[7] = (         int  )0;
               sqlstm.sqharm[7] = (unsigned long )0;
               sqlstm.sqadto[7] = (unsigned short )0;
               sqlstm.sqtdso[7] = (unsigned short )0;
               sqlstm.sqphsv = sqlstm.sqhstv;
               sqlstm.sqphsl = sqlstm.sqhstl;
               sqlstm.sqphss = sqlstm.sqhsts;
               sqlstm.sqpind = sqlstm.sqindv;
               sqlstm.sqpins = sqlstm.sqinds;
               sqlstm.sqparm = sqlstm.sqharm;
               sqlstm.sqparc = sqlstm.sqharc;
               sqlstm.sqpadto = sqlstm.sqadto;
               sqlstm.sqptdso = sqlstm.sqtdso;
               sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
               if (sqlca.sqlcode < 0) goto sqlerr;
}


               temp.erase(temp.find("<RANGE>"),temp.find("</RANGE>")+strlen("/RANGE>")- temp.find("<RANGE>")+1);
               found = temp.find("<RANGE>");
            }
         }
         if(0 == strcmp(g_ConObj.m_InstanceSp_DB.c_str(),"INST"))
            /* EXEC SQL INSERT INTO HLR_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CONFIG_VALUES (ENTITY_NAME,PARAM_\
ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYP\
E) values (:b0,:b1,:b2,:b3,'OS',to_date(:b4,'mm/dd/yyyy hh24:mi:ss'),:b5)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )3986;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[2] = (unsigned long )20;
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[3] = (unsigned long )10;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[4] = (unsigned long )102;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[5] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}




         /* EXEC SQL COMMIT; */ 

{
         struct sqlexd sqlstm;
         sqlstm.sqlvsn = 12;
         sqlstm.arrsiz = 8;
         sqlstm.sqladtp = &sqladt;
         sqlstm.sqltdsp = &sqltds;
         sqlstm.iters = (unsigned int  )1;
         sqlstm.offset = (unsigned int  )4025;
         sqlstm.cud = sqlcud0;
         sqlstm.sqlest = (unsigned char  *)&sqlca;
         sqlstm.sqlety = (unsigned short)256;
         sqlstm.occurs = (unsigned int  )0;
         sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
         if (sqlca.sqlcode < 0) goto sqlerr;
}


      }
      else if(first == 197)
      {
         Param_ID = first;
         int found;
         string temp =  complexMap.find(first)->second; 
         string searchFora ("<CODE_");    
         found = temp.find( searchFora );
         if(found == -1)
         {
           Count_Val++;

            /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,37,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENTITY\
_NAME,PARAM_ID,SUB_PARAM_ID,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDA\
TED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,37,:b2,:b3,:b4,'OS',to\
_date(:b5,'mm/dd/yyyy hh24:mi:ss'),:b6)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )4040;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)&Count_Val;
            sqlstm.sqhstl[2] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[3] = (unsigned long )20;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[4] = (unsigned long )10;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[5] = (unsigned long )102;
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqhstv[6] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[6] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[6] = (         int  )0;
            sqlstm.sqindv[6] = (         short *)0;
            sqlstm.sqinds[6] = (         int  )0;
            sqlstm.sqharm[6] = (unsigned long )0;
            sqlstm.sqadto[6] = (unsigned short )0;
            sqlstm.sqtdso[6] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}



// ELOG(0,0,"!!!!!!!!!!!!! In SPA_SUCCESS_RESP_CODES code tag not Found !!!!!!!!!");
         }
         else
         {
            while(found != string::npos) 
            {  

               string replaceBya ("<CODE>");
               temp.replace( found, strlen("<CODE_00>"), replaceBya );
               searchFora = "</CODE_";    
               replaceBya = "</CODE>";
               found = temp.find( searchFora );
               temp.replace( found,strlen("</CODE_00>"), replaceBya );
               string searchFora ("<CODE_");    
               found = temp.find( searchFora );
            }
            found = temp.find("<CODE>");
            while(found != string::npos)
            {
               int fir = temp.find("<CODE>")+strlen("CODE>")+1;
               int last =temp.find("</CODE>");
               string value1 = temp.substr(fir,last-fir);
               Param_ID = first ;
               strcpy(Value,value1.c_str());
               Count_Val++;
               /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,37,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
               struct sqlexd sqlstm;
               sqlstm.sqlvsn = 12;
               sqlstm.arrsiz = 8;
               sqlstm.sqladtp = &sqladt;
               sqlstm.sqltdsp = &sqltds;
               sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENT\
ITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING\
_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,37,:b2,\
:b3,:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
               sqlstm.iters = (unsigned int  )1;
               sqlstm.offset = (unsigned int  )4083;
               sqlstm.cud = sqlcud0;
               sqlstm.sqlest = (unsigned char  *)&sqlca;
               sqlstm.sqlety = (unsigned short)256;
               sqlstm.occurs = (unsigned int  )0;
               sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
               sqlstm.sqhstl[0] = (unsigned long )20;
               sqlstm.sqhsts[0] = (         int  )0;
               sqlstm.sqindv[0] = (         short *)0;
               sqlstm.sqinds[0] = (         int  )0;
               sqlstm.sqharm[0] = (unsigned long )0;
               sqlstm.sqadto[0] = (unsigned short )0;
               sqlstm.sqtdso[0] = (unsigned short )0;
               sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
               sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[1] = (         int  )0;
               sqlstm.sqindv[1] = (         short *)0;
               sqlstm.sqinds[1] = (         int  )0;
               sqlstm.sqharm[1] = (unsigned long )0;
               sqlstm.sqadto[1] = (unsigned short )0;
               sqlstm.sqtdso[1] = (unsigned short )0;
               sqlstm.sqhstv[2] = (unsigned char  *)Value;
               sqlstm.sqhstl[2] = (unsigned long )100000;
               sqlstm.sqhsts[2] = (         int  )0;
               sqlstm.sqindv[2] = (         short *)0;
               sqlstm.sqinds[2] = (         int  )0;
               sqlstm.sqharm[2] = (unsigned long )0;
               sqlstm.sqadto[2] = (unsigned short )0;
               sqlstm.sqtdso[2] = (unsigned short )0;
               sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
               sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[3] = (         int  )0;
               sqlstm.sqindv[3] = (         short *)0;
               sqlstm.sqinds[3] = (         int  )0;
               sqlstm.sqharm[3] = (unsigned long )0;
               sqlstm.sqadto[3] = (unsigned short )0;
               sqlstm.sqtdso[3] = (unsigned short )0;
               sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
               sqlstm.sqhstl[4] = (unsigned long )20;
               sqlstm.sqhsts[4] = (         int  )0;
               sqlstm.sqindv[4] = (         short *)0;
               sqlstm.sqinds[4] = (         int  )0;
               sqlstm.sqharm[4] = (unsigned long )0;
               sqlstm.sqadto[4] = (unsigned short )0;
               sqlstm.sqtdso[4] = (unsigned short )0;
               sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
               sqlstm.sqhstl[5] = (unsigned long )10;
               sqlstm.sqhsts[5] = (         int  )0;
               sqlstm.sqindv[5] = (         short *)0;
               sqlstm.sqinds[5] = (         int  )0;
               sqlstm.sqharm[5] = (unsigned long )0;
               sqlstm.sqadto[5] = (unsigned short )0;
               sqlstm.sqtdso[5] = (unsigned short )0;
               sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
               sqlstm.sqhstl[6] = (unsigned long )102;
               sqlstm.sqhsts[6] = (         int  )0;
               sqlstm.sqindv[6] = (         short *)0;
               sqlstm.sqinds[6] = (         int  )0;
               sqlstm.sqharm[6] = (unsigned long )0;
               sqlstm.sqadto[6] = (unsigned short )0;
               sqlstm.sqtdso[6] = (unsigned short )0;
               sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
               sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[7] = (         int  )0;
               sqlstm.sqindv[7] = (         short *)0;
               sqlstm.sqinds[7] = (         int  )0;
               sqlstm.sqharm[7] = (unsigned long )0;
               sqlstm.sqadto[7] = (unsigned short )0;
               sqlstm.sqtdso[7] = (unsigned short )0;
               sqlstm.sqphsv = sqlstm.sqhstv;
               sqlstm.sqphsl = sqlstm.sqhstl;
               sqlstm.sqphss = sqlstm.sqhsts;
               sqlstm.sqpind = sqlstm.sqindv;
               sqlstm.sqpins = sqlstm.sqinds;
               sqlstm.sqparm = sqlstm.sqharm;
               sqlstm.sqparc = sqlstm.sqharc;
               sqlstm.sqpadto = sqlstm.sqadto;
               sqlstm.sqptdso = sqlstm.sqtdso;
               sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
               if (sqlca.sqlcode < 0) goto sqlerr;
}


               temp.erase(temp.find("<CODE>"),temp.find("</CODE>")+strlen("/CODE>")- temp.find("<CODE>")+1);
               found = temp.find("<CODE>");
            }
         }
         if(0 == strcmp(g_ConObj.m_InstanceSp_DB.c_str(),"INST"))
            /* EXEC SQL INSERT INTO HLR_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CONFIG_VALUES (ENTITY_NAME,PARAM_\
ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYP\
E) values (:b0,:b1,:b2,:b3,'OS',to_date(:b4,'mm/dd/yyyy hh24:mi:ss'),:b5)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )4130;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[2] = (unsigned long )20;
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[3] = (unsigned long )10;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[4] = (unsigned long )102;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[5] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}




         /* EXEC SQL COMMIT; */ 

{
         struct sqlexd sqlstm;
         sqlstm.sqlvsn = 12;
         sqlstm.arrsiz = 8;
         sqlstm.sqladtp = &sqladt;
         sqlstm.sqltdsp = &sqltds;
         sqlstm.iters = (unsigned int  )1;
         sqlstm.offset = (unsigned int  )4169;
         sqlstm.cud = sqlcud0;
         sqlstm.sqlest = (unsigned char  *)&sqlca;
         sqlstm.sqlety = (unsigned short)256;
         sqlstm.occurs = (unsigned int  )0;
         sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
         if (sqlca.sqlcode < 0) goto sqlerr;
}


      }
      else if(first == 209)
      {
         Param_ID = first;
         int found;
         string temp =  complexMap.find(first)->second; 
         found = temp.find("<MAIL>");
         if(found == -1)
         {
            
            Count_Val++;

            /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,40,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENTITY\
_NAME,PARAM_ID,SUB_PARAM_ID,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDA\
TED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,40,:b2,:b3,:b4,'OS',to\
_date(:b5,'mm/dd/yyyy hh24:mi:ss'),:b6)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )4184;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)&Count_Val;
            sqlstm.sqhstl[2] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[3] = (unsigned long )20;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[4] = (unsigned long )10;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[5] = (unsigned long )102;
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqhstv[6] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[6] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[6] = (         int  )0;
            sqlstm.sqindv[6] = (         short *)0;
            sqlstm.sqinds[6] = (         int  )0;
            sqlstm.sqharm[6] = (unsigned long )0;
            sqlstm.sqadto[6] = (unsigned short )0;
            sqlstm.sqtdso[6] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}




         }
         else
         {
            while(found != string::npos)
            {
               int fir = temp.find("<MAIL>")+strlen("MAIL>")+1;
               int last =temp.find("</MAIL>");
               string value1 = temp.substr(fir,last-fir);
               Param_ID = first ;
               strcpy(Value,value1.c_str());
               
               Count_Val++;
               /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,40,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
               struct sqlexd sqlstm;
               sqlstm.sqlvsn = 12;
               sqlstm.arrsiz = 8;
               sqlstm.sqladtp = &sqladt;
               sqlstm.sqltdsp = &sqltds;
               sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENT\
ITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING\
_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,40,:b2,\
:b3,:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
               sqlstm.iters = (unsigned int  )1;
               sqlstm.offset = (unsigned int  )4227;
               sqlstm.cud = sqlcud0;
               sqlstm.sqlest = (unsigned char  *)&sqlca;
               sqlstm.sqlety = (unsigned short)256;
               sqlstm.occurs = (unsigned int  )0;
               sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
               sqlstm.sqhstl[0] = (unsigned long )20;
               sqlstm.sqhsts[0] = (         int  )0;
               sqlstm.sqindv[0] = (         short *)0;
               sqlstm.sqinds[0] = (         int  )0;
               sqlstm.sqharm[0] = (unsigned long )0;
               sqlstm.sqadto[0] = (unsigned short )0;
               sqlstm.sqtdso[0] = (unsigned short )0;
               sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
               sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[1] = (         int  )0;
               sqlstm.sqindv[1] = (         short *)0;
               sqlstm.sqinds[1] = (         int  )0;
               sqlstm.sqharm[1] = (unsigned long )0;
               sqlstm.sqadto[1] = (unsigned short )0;
               sqlstm.sqtdso[1] = (unsigned short )0;
               sqlstm.sqhstv[2] = (unsigned char  *)Value;
               sqlstm.sqhstl[2] = (unsigned long )100000;
               sqlstm.sqhsts[2] = (         int  )0;
               sqlstm.sqindv[2] = (         short *)0;
               sqlstm.sqinds[2] = (         int  )0;
               sqlstm.sqharm[2] = (unsigned long )0;
               sqlstm.sqadto[2] = (unsigned short )0;
               sqlstm.sqtdso[2] = (unsigned short )0;
               sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
               sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[3] = (         int  )0;
               sqlstm.sqindv[3] = (         short *)0;
               sqlstm.sqinds[3] = (         int  )0;
               sqlstm.sqharm[3] = (unsigned long )0;
               sqlstm.sqadto[3] = (unsigned short )0;
               sqlstm.sqtdso[3] = (unsigned short )0;
               sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
               sqlstm.sqhstl[4] = (unsigned long )20;
               sqlstm.sqhsts[4] = (         int  )0;
               sqlstm.sqindv[4] = (         short *)0;
               sqlstm.sqinds[4] = (         int  )0;
               sqlstm.sqharm[4] = (unsigned long )0;
               sqlstm.sqadto[4] = (unsigned short )0;
               sqlstm.sqtdso[4] = (unsigned short )0;
               sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
               sqlstm.sqhstl[5] = (unsigned long )10;
               sqlstm.sqhsts[5] = (         int  )0;
               sqlstm.sqindv[5] = (         short *)0;
               sqlstm.sqinds[5] = (         int  )0;
               sqlstm.sqharm[5] = (unsigned long )0;
               sqlstm.sqadto[5] = (unsigned short )0;
               sqlstm.sqtdso[5] = (unsigned short )0;
               sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
               sqlstm.sqhstl[6] = (unsigned long )102;
               sqlstm.sqhsts[6] = (         int  )0;
               sqlstm.sqindv[6] = (         short *)0;
               sqlstm.sqinds[6] = (         int  )0;
               sqlstm.sqharm[6] = (unsigned long )0;
               sqlstm.sqadto[6] = (unsigned short )0;
               sqlstm.sqtdso[6] = (unsigned short )0;
               sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
               sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[7] = (         int  )0;
               sqlstm.sqindv[7] = (         short *)0;
               sqlstm.sqinds[7] = (         int  )0;
               sqlstm.sqharm[7] = (unsigned long )0;
               sqlstm.sqadto[7] = (unsigned short )0;
               sqlstm.sqtdso[7] = (unsigned short )0;
               sqlstm.sqphsv = sqlstm.sqhstv;
               sqlstm.sqphsl = sqlstm.sqhstl;
               sqlstm.sqphss = sqlstm.sqhsts;
               sqlstm.sqpind = sqlstm.sqindv;
               sqlstm.sqpins = sqlstm.sqinds;
               sqlstm.sqparm = sqlstm.sqharm;
               sqlstm.sqparc = sqlstm.sqharc;
               sqlstm.sqpadto = sqlstm.sqadto;
               sqlstm.sqptdso = sqlstm.sqtdso;
               sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
               if (sqlca.sqlcode < 0) goto sqlerr;
}


               temp.erase(temp.find("<MAIL>"),temp.find("</MAIL>")+strlen("/MAIL>")- temp.find("<MAIL>")+1);
               found = temp.find("<MAIL>");
            }
         }
         if(0 == strcmp(g_ConObj.m_InstanceSp_DB.c_str(),"INST"))
            /* EXEC SQL INSERT INTO HLR_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CONFIG_VALUES (ENTITY_NAME,PARAM_\
ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYP\
E) values (:b0,:b1,:b2,:b3,'OS',to_date(:b4,'mm/dd/yyyy hh24:mi:ss'),:b5)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )4274;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[2] = (unsigned long )20;
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[3] = (unsigned long )10;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[4] = (unsigned long )102;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[5] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}




         /* EXEC SQL COMMIT; */ 

{
         struct sqlexd sqlstm;
         sqlstm.sqlvsn = 12;
         sqlstm.arrsiz = 8;
         sqlstm.sqladtp = &sqladt;
         sqlstm.sqltdsp = &sqltds;
         sqlstm.iters = (unsigned int  )1;
         sqlstm.offset = (unsigned int  )4313;
         sqlstm.cud = sqlcud0;
         sqlstm.sqlest = (unsigned char  *)&sqlca;
         sqlstm.sqlety = (unsigned short)256;
         sqlstm.occurs = (unsigned int  )0;
         sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
         if (sqlca.sqlcode < 0) goto sqlerr;
}


      }
      else if(first == 210)
      {
         Param_ID = first;
         int found;
         string temp =  complexMap.find(first)->second; 
         found = temp.find("<MAIL>");
         if(found == -1)
         {
            Count_Val++;

            /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,41,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENTITY\
_NAME,PARAM_ID,SUB_PARAM_ID,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDA\
TED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,41,:b2,:b3,:b4,'OS',to\
_date(:b5,'mm/dd/yyyy hh24:mi:ss'),:b6)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )4328;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)&Count_Val;
            sqlstm.sqhstl[2] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[3] = (unsigned long )20;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[4] = (unsigned long )10;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[5] = (unsigned long )102;
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqhstv[6] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[6] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[6] = (         int  )0;
            sqlstm.sqindv[6] = (         short *)0;
            sqlstm.sqinds[6] = (         int  )0;
            sqlstm.sqharm[6] = (unsigned long )0;
            sqlstm.sqadto[6] = (unsigned short )0;
            sqlstm.sqtdso[6] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}




         }
         else
         {
            while(found != string::npos)
            {
               int fir = temp.find("<MAIL>")+strlen("MAIL>")+1;
               int last =temp.find("</MAIL>");
               string value1 = temp.substr(fir,last-fir);
               Param_ID = first ;
               strcpy(Value,value1.c_str());
               Count_Val++;
               /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,41,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
               struct sqlexd sqlstm;
               sqlstm.sqlvsn = 12;
               sqlstm.arrsiz = 8;
               sqlstm.sqladtp = &sqladt;
               sqlstm.sqltdsp = &sqltds;
               sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENT\
ITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING\
_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,41,:b2,\
:b3,:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
               sqlstm.iters = (unsigned int  )1;
               sqlstm.offset = (unsigned int  )4371;
               sqlstm.cud = sqlcud0;
               sqlstm.sqlest = (unsigned char  *)&sqlca;
               sqlstm.sqlety = (unsigned short)256;
               sqlstm.occurs = (unsigned int  )0;
               sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
               sqlstm.sqhstl[0] = (unsigned long )20;
               sqlstm.sqhsts[0] = (         int  )0;
               sqlstm.sqindv[0] = (         short *)0;
               sqlstm.sqinds[0] = (         int  )0;
               sqlstm.sqharm[0] = (unsigned long )0;
               sqlstm.sqadto[0] = (unsigned short )0;
               sqlstm.sqtdso[0] = (unsigned short )0;
               sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
               sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[1] = (         int  )0;
               sqlstm.sqindv[1] = (         short *)0;
               sqlstm.sqinds[1] = (         int  )0;
               sqlstm.sqharm[1] = (unsigned long )0;
               sqlstm.sqadto[1] = (unsigned short )0;
               sqlstm.sqtdso[1] = (unsigned short )0;
               sqlstm.sqhstv[2] = (unsigned char  *)Value;
               sqlstm.sqhstl[2] = (unsigned long )100000;
               sqlstm.sqhsts[2] = (         int  )0;
               sqlstm.sqindv[2] = (         short *)0;
               sqlstm.sqinds[2] = (         int  )0;
               sqlstm.sqharm[2] = (unsigned long )0;
               sqlstm.sqadto[2] = (unsigned short )0;
               sqlstm.sqtdso[2] = (unsigned short )0;
               sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
               sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[3] = (         int  )0;
               sqlstm.sqindv[3] = (         short *)0;
               sqlstm.sqinds[3] = (         int  )0;
               sqlstm.sqharm[3] = (unsigned long )0;
               sqlstm.sqadto[3] = (unsigned short )0;
               sqlstm.sqtdso[3] = (unsigned short )0;
               sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
               sqlstm.sqhstl[4] = (unsigned long )20;
               sqlstm.sqhsts[4] = (         int  )0;
               sqlstm.sqindv[4] = (         short *)0;
               sqlstm.sqinds[4] = (         int  )0;
               sqlstm.sqharm[4] = (unsigned long )0;
               sqlstm.sqadto[4] = (unsigned short )0;
               sqlstm.sqtdso[4] = (unsigned short )0;
               sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
               sqlstm.sqhstl[5] = (unsigned long )10;
               sqlstm.sqhsts[5] = (         int  )0;
               sqlstm.sqindv[5] = (         short *)0;
               sqlstm.sqinds[5] = (         int  )0;
               sqlstm.sqharm[5] = (unsigned long )0;
               sqlstm.sqadto[5] = (unsigned short )0;
               sqlstm.sqtdso[5] = (unsigned short )0;
               sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
               sqlstm.sqhstl[6] = (unsigned long )102;
               sqlstm.sqhsts[6] = (         int  )0;
               sqlstm.sqindv[6] = (         short *)0;
               sqlstm.sqinds[6] = (         int  )0;
               sqlstm.sqharm[6] = (unsigned long )0;
               sqlstm.sqadto[6] = (unsigned short )0;
               sqlstm.sqtdso[6] = (unsigned short )0;
               sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
               sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[7] = (         int  )0;
               sqlstm.sqindv[7] = (         short *)0;
               sqlstm.sqinds[7] = (         int  )0;
               sqlstm.sqharm[7] = (unsigned long )0;
               sqlstm.sqadto[7] = (unsigned short )0;
               sqlstm.sqtdso[7] = (unsigned short )0;
               sqlstm.sqphsv = sqlstm.sqhstv;
               sqlstm.sqphsl = sqlstm.sqhstl;
               sqlstm.sqphss = sqlstm.sqhsts;
               sqlstm.sqpind = sqlstm.sqindv;
               sqlstm.sqpins = sqlstm.sqinds;
               sqlstm.sqparm = sqlstm.sqharm;
               sqlstm.sqparc = sqlstm.sqharc;
               sqlstm.sqpadto = sqlstm.sqadto;
               sqlstm.sqptdso = sqlstm.sqtdso;
               sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
               if (sqlca.sqlcode < 0) goto sqlerr;
}


               temp.erase(temp.find("<MAIL>"),temp.find("</MAIL>")+strlen("/MAIL>")- temp.find("<MAIL>")+1);
               found = temp.find("<MAIL>");
            }
         }
         if(0 == strcmp(g_ConObj.m_InstanceSp_DB.c_str(),"INST"))
            /* EXEC SQL INSERT INTO HLR_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CONFIG_VALUES (ENTITY_NAME,PARAM_\
ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYP\
E) values (:b0,:b1,:b2,:b3,'OS',to_date(:b4,'mm/dd/yyyy hh24:mi:ss'),:b5)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )4418;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[2] = (unsigned long )20;
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[3] = (unsigned long )10;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[4] = (unsigned long )102;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[5] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}




         /* EXEC SQL COMMIT; */ 

{
         struct sqlexd sqlstm;
         sqlstm.sqlvsn = 12;
         sqlstm.arrsiz = 8;
         sqlstm.sqladtp = &sqladt;
         sqlstm.sqltdsp = &sqltds;
         sqlstm.iters = (unsigned int  )1;
         sqlstm.offset = (unsigned int  )4457;
         sqlstm.cud = sqlcud0;
         sqlstm.sqlest = (unsigned char  *)&sqlca;
         sqlstm.sqlety = (unsigned short)256;
         sqlstm.occurs = (unsigned int  )0;
         sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
         if (sqlca.sqlcode < 0) goto sqlerr;
}


      }
      else if(first == 211)
      {
         Param_ID = first;
         int found;
         string temp =  complexMap.find(first)->second; 
         found = temp.find("<MAIL>");
         if(found == -1)
         {
            Count_Val++;

            /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,42,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENTITY\
_NAME,PARAM_ID,SUB_PARAM_ID,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDA\
TED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,42,:b2,:b3,:b4,'OS',to\
_date(:b5,'mm/dd/yyyy hh24:mi:ss'),:b6)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )4472;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)&Count_Val;
            sqlstm.sqhstl[2] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[3] = (unsigned long )20;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[4] = (unsigned long )10;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[5] = (unsigned long )102;
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqhstv[6] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[6] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[6] = (         int  )0;
            sqlstm.sqindv[6] = (         short *)0;
            sqlstm.sqinds[6] = (         int  )0;
            sqlstm.sqharm[6] = (unsigned long )0;
            sqlstm.sqadto[6] = (unsigned short )0;
            sqlstm.sqtdso[6] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}




         }
         else
         {
            while(found != string::npos)
            {
               int fir = temp.find("<MAIL>")+strlen("MAIL>")+1;
               int last =temp.find("</MAIL>");
               string value1 = temp.substr(fir,last-fir);
               Param_ID = first ;
               strcpy(Value,value1.c_str());
               Count_Val++;
               /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,42,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
               struct sqlexd sqlstm;
               sqlstm.sqlvsn = 12;
               sqlstm.arrsiz = 8;
               sqlstm.sqladtp = &sqladt;
               sqlstm.sqltdsp = &sqltds;
               sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENT\
ITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING\
_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,42,:b2,\
:b3,:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
               sqlstm.iters = (unsigned int  )1;
               sqlstm.offset = (unsigned int  )4515;
               sqlstm.cud = sqlcud0;
               sqlstm.sqlest = (unsigned char  *)&sqlca;
               sqlstm.sqlety = (unsigned short)256;
               sqlstm.occurs = (unsigned int  )0;
               sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
               sqlstm.sqhstl[0] = (unsigned long )20;
               sqlstm.sqhsts[0] = (         int  )0;
               sqlstm.sqindv[0] = (         short *)0;
               sqlstm.sqinds[0] = (         int  )0;
               sqlstm.sqharm[0] = (unsigned long )0;
               sqlstm.sqadto[0] = (unsigned short )0;
               sqlstm.sqtdso[0] = (unsigned short )0;
               sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
               sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[1] = (         int  )0;
               sqlstm.sqindv[1] = (         short *)0;
               sqlstm.sqinds[1] = (         int  )0;
               sqlstm.sqharm[1] = (unsigned long )0;
               sqlstm.sqadto[1] = (unsigned short )0;
               sqlstm.sqtdso[1] = (unsigned short )0;
               sqlstm.sqhstv[2] = (unsigned char  *)Value;
               sqlstm.sqhstl[2] = (unsigned long )100000;
               sqlstm.sqhsts[2] = (         int  )0;
               sqlstm.sqindv[2] = (         short *)0;
               sqlstm.sqinds[2] = (         int  )0;
               sqlstm.sqharm[2] = (unsigned long )0;
               sqlstm.sqadto[2] = (unsigned short )0;
               sqlstm.sqtdso[2] = (unsigned short )0;
               sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
               sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[3] = (         int  )0;
               sqlstm.sqindv[3] = (         short *)0;
               sqlstm.sqinds[3] = (         int  )0;
               sqlstm.sqharm[3] = (unsigned long )0;
               sqlstm.sqadto[3] = (unsigned short )0;
               sqlstm.sqtdso[3] = (unsigned short )0;
               sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
               sqlstm.sqhstl[4] = (unsigned long )20;
               sqlstm.sqhsts[4] = (         int  )0;
               sqlstm.sqindv[4] = (         short *)0;
               sqlstm.sqinds[4] = (         int  )0;
               sqlstm.sqharm[4] = (unsigned long )0;
               sqlstm.sqadto[4] = (unsigned short )0;
               sqlstm.sqtdso[4] = (unsigned short )0;
               sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
               sqlstm.sqhstl[5] = (unsigned long )10;
               sqlstm.sqhsts[5] = (         int  )0;
               sqlstm.sqindv[5] = (         short *)0;
               sqlstm.sqinds[5] = (         int  )0;
               sqlstm.sqharm[5] = (unsigned long )0;
               sqlstm.sqadto[5] = (unsigned short )0;
               sqlstm.sqtdso[5] = (unsigned short )0;
               sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
               sqlstm.sqhstl[6] = (unsigned long )102;
               sqlstm.sqhsts[6] = (         int  )0;
               sqlstm.sqindv[6] = (         short *)0;
               sqlstm.sqinds[6] = (         int  )0;
               sqlstm.sqharm[6] = (unsigned long )0;
               sqlstm.sqadto[6] = (unsigned short )0;
               sqlstm.sqtdso[6] = (unsigned short )0;
               sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
               sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[7] = (         int  )0;
               sqlstm.sqindv[7] = (         short *)0;
               sqlstm.sqinds[7] = (         int  )0;
               sqlstm.sqharm[7] = (unsigned long )0;
               sqlstm.sqadto[7] = (unsigned short )0;
               sqlstm.sqtdso[7] = (unsigned short )0;
               sqlstm.sqphsv = sqlstm.sqhstv;
               sqlstm.sqphsl = sqlstm.sqhstl;
               sqlstm.sqphss = sqlstm.sqhsts;
               sqlstm.sqpind = sqlstm.sqindv;
               sqlstm.sqpins = sqlstm.sqinds;
               sqlstm.sqparm = sqlstm.sqharm;
               sqlstm.sqparc = sqlstm.sqharc;
               sqlstm.sqpadto = sqlstm.sqadto;
               sqlstm.sqptdso = sqlstm.sqtdso;
               sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
               if (sqlca.sqlcode < 0) goto sqlerr;
}


               temp.erase(temp.find("<MAIL>"),temp.find("</MAIL>")+strlen("/MAIL>")- temp.find("<MAIL>")+1);
               found = temp.find("<MAIL>");
            }
         }
         if(0 == strcmp(g_ConObj.m_InstanceSp_DB.c_str(),"INST"))
            /* EXEC SQL INSERT INTO HLR_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CONFIG_VALUES (ENTITY_NAME,PARAM_\
ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYP\
E) values (:b0,:b1,:b2,:b3,'OS',to_date(:b4,'mm/dd/yyyy hh24:mi:ss'),:b5)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )4562;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[2] = (unsigned long )20;
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[3] = (unsigned long )10;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[4] = (unsigned long )102;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[5] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}




         /* EXEC SQL COMMIT; */ 

{
         struct sqlexd sqlstm;
         sqlstm.sqlvsn = 12;
         sqlstm.arrsiz = 8;
         sqlstm.sqladtp = &sqladt;
         sqlstm.sqltdsp = &sqltds;
         sqlstm.iters = (unsigned int  )1;
         sqlstm.offset = (unsigned int  )4601;
         sqlstm.cud = sqlcud0;
         sqlstm.sqlest = (unsigned char  *)&sqlca;
         sqlstm.sqlety = (unsigned short)256;
         sqlstm.occurs = (unsigned int  )0;
         sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
         if (sqlca.sqlcode < 0) goto sqlerr;
}


      }
      else if(first == 212)
      {
         Param_ID = first;
         int found;
         string temp =  complexMap.find(first)->second; 
         string searchFora ("<CODE_");    
         found = temp.find( searchFora );
         if(found == -1)
         {
            Count_Val++;

            /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,43,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENTITY\
_NAME,PARAM_ID,SUB_PARAM_ID,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDA\
TED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,43,:b2,:b3,:b4,'OS',to\
_date(:b5,'mm/dd/yyyy hh24:mi:ss'),:b6)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )4616;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)&Count_Val;
            sqlstm.sqhstl[2] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[3] = (unsigned long )20;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[4] = (unsigned long )10;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[5] = (unsigned long )102;
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqhstv[6] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[6] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[6] = (         int  )0;
            sqlstm.sqindv[6] = (         short *)0;
            sqlstm.sqinds[6] = (         int  )0;
            sqlstm.sqharm[6] = (unsigned long )0;
            sqlstm.sqadto[6] = (unsigned short )0;
            sqlstm.sqtdso[6] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}




         }
         else
         {
            while(found != string::npos) 
            {  
               string replaceBya ("<CODE>");
               temp.replace( found, strlen("<CODE_00>"), replaceBya );
               searchFora = "</CODE_";    
               replaceBya = "</CODE>";
               found = temp.find( searchFora );
               temp.replace( found,strlen("</CODE_00>"), replaceBya );
               string searchFora ("<CODE_");    
               found = temp.find( searchFora );
            }
            found = temp.find("<CODE>");
            while(found != string::npos)
            {
               int fir = temp.find("<CODE>")+strlen("CODE>")+1;
               int last =temp.find("</CODE>");
               string value1 = temp.substr(fir,last-fir);
               Param_ID = first ;
               strcpy(Value,value1.c_str());
               Count_Val++;
               /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,43,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
               struct sqlexd sqlstm;
               sqlstm.sqlvsn = 12;
               sqlstm.arrsiz = 8;
               sqlstm.sqladtp = &sqladt;
               sqlstm.sqltdsp = &sqltds;
               sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENT\
ITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING\
_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,43,:b2,\
:b3,:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
               sqlstm.iters = (unsigned int  )1;
               sqlstm.offset = (unsigned int  )4659;
               sqlstm.cud = sqlcud0;
               sqlstm.sqlest = (unsigned char  *)&sqlca;
               sqlstm.sqlety = (unsigned short)256;
               sqlstm.occurs = (unsigned int  )0;
               sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
               sqlstm.sqhstl[0] = (unsigned long )20;
               sqlstm.sqhsts[0] = (         int  )0;
               sqlstm.sqindv[0] = (         short *)0;
               sqlstm.sqinds[0] = (         int  )0;
               sqlstm.sqharm[0] = (unsigned long )0;
               sqlstm.sqadto[0] = (unsigned short )0;
               sqlstm.sqtdso[0] = (unsigned short )0;
               sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
               sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[1] = (         int  )0;
               sqlstm.sqindv[1] = (         short *)0;
               sqlstm.sqinds[1] = (         int  )0;
               sqlstm.sqharm[1] = (unsigned long )0;
               sqlstm.sqadto[1] = (unsigned short )0;
               sqlstm.sqtdso[1] = (unsigned short )0;
               sqlstm.sqhstv[2] = (unsigned char  *)Value;
               sqlstm.sqhstl[2] = (unsigned long )100000;
               sqlstm.sqhsts[2] = (         int  )0;
               sqlstm.sqindv[2] = (         short *)0;
               sqlstm.sqinds[2] = (         int  )0;
               sqlstm.sqharm[2] = (unsigned long )0;
               sqlstm.sqadto[2] = (unsigned short )0;
               sqlstm.sqtdso[2] = (unsigned short )0;
               sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
               sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[3] = (         int  )0;
               sqlstm.sqindv[3] = (         short *)0;
               sqlstm.sqinds[3] = (         int  )0;
               sqlstm.sqharm[3] = (unsigned long )0;
               sqlstm.sqadto[3] = (unsigned short )0;
               sqlstm.sqtdso[3] = (unsigned short )0;
               sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
               sqlstm.sqhstl[4] = (unsigned long )20;
               sqlstm.sqhsts[4] = (         int  )0;
               sqlstm.sqindv[4] = (         short *)0;
               sqlstm.sqinds[4] = (         int  )0;
               sqlstm.sqharm[4] = (unsigned long )0;
               sqlstm.sqadto[4] = (unsigned short )0;
               sqlstm.sqtdso[4] = (unsigned short )0;
               sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
               sqlstm.sqhstl[5] = (unsigned long )10;
               sqlstm.sqhsts[5] = (         int  )0;
               sqlstm.sqindv[5] = (         short *)0;
               sqlstm.sqinds[5] = (         int  )0;
               sqlstm.sqharm[5] = (unsigned long )0;
               sqlstm.sqadto[5] = (unsigned short )0;
               sqlstm.sqtdso[5] = (unsigned short )0;
               sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
               sqlstm.sqhstl[6] = (unsigned long )102;
               sqlstm.sqhsts[6] = (         int  )0;
               sqlstm.sqindv[6] = (         short *)0;
               sqlstm.sqinds[6] = (         int  )0;
               sqlstm.sqharm[6] = (unsigned long )0;
               sqlstm.sqadto[6] = (unsigned short )0;
               sqlstm.sqtdso[6] = (unsigned short )0;
               sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
               sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[7] = (         int  )0;
               sqlstm.sqindv[7] = (         short *)0;
               sqlstm.sqinds[7] = (         int  )0;
               sqlstm.sqharm[7] = (unsigned long )0;
               sqlstm.sqadto[7] = (unsigned short )0;
               sqlstm.sqtdso[7] = (unsigned short )0;
               sqlstm.sqphsv = sqlstm.sqhstv;
               sqlstm.sqphsl = sqlstm.sqhstl;
               sqlstm.sqphss = sqlstm.sqhsts;
               sqlstm.sqpind = sqlstm.sqindv;
               sqlstm.sqpins = sqlstm.sqinds;
               sqlstm.sqparm = sqlstm.sqharm;
               sqlstm.sqparc = sqlstm.sqharc;
               sqlstm.sqpadto = sqlstm.sqadto;
               sqlstm.sqptdso = sqlstm.sqtdso;
               sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
               if (sqlca.sqlcode < 0) goto sqlerr;
}


               temp.erase(temp.find("<CODE>"),temp.find("</CODE>")+strlen("/CODE>")- temp.find("<CODE>")+1);
               found = temp.find("<CODE>");
            }
         }
         if(0 == strcmp(g_ConObj.m_InstanceSp_DB.c_str(),"INST"))
            /* EXEC SQL INSERT INTO HLR_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CONFIG_VALUES (ENTITY_NAME,PARAM_\
ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYP\
E) values (:b0,:b1,:b2,:b3,'OS',to_date(:b4,'mm/dd/yyyy hh24:mi:ss'),:b5)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )4706;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[2] = (unsigned long )20;
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[3] = (unsigned long )10;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[4] = (unsigned long )102;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[5] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}




         /* EXEC SQL COMMIT; */ 

{
         struct sqlexd sqlstm;
         sqlstm.sqlvsn = 12;
         sqlstm.arrsiz = 8;
         sqlstm.sqladtp = &sqladt;
         sqlstm.sqltdsp = &sqltds;
         sqlstm.iters = (unsigned int  )1;
         sqlstm.offset = (unsigned int  )4745;
         sqlstm.cud = sqlcud0;
         sqlstm.sqlest = (unsigned char  *)&sqlca;
         sqlstm.sqlety = (unsigned short)256;
         sqlstm.occurs = (unsigned int  )0;
         sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
         if (sqlca.sqlcode < 0) goto sqlerr;
}


      }
      else if(first == 222)
      {
         Param_ID = first;
         int found;
         string temp =  complexMap.find(first)->second; 
         string searchFora ("<CODE_");    
         found = temp.find( searchFora );
         if(found == -1)
         {
            Count_Val++;

            /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,44,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENTITY\
_NAME,PARAM_ID,SUB_PARAM_ID,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDA\
TED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,44,:b2,:b3,:b4,'OS',to\
_date(:b5,'mm/dd/yyyy hh24:mi:ss'),:b6)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )4760;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)&Count_Val;
            sqlstm.sqhstl[2] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[3] = (unsigned long )20;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[4] = (unsigned long )10;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[5] = (unsigned long )102;
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqhstv[6] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[6] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[6] = (         int  )0;
            sqlstm.sqindv[6] = (         short *)0;
            sqlstm.sqinds[6] = (         int  )0;
            sqlstm.sqharm[6] = (unsigned long )0;
            sqlstm.sqadto[6] = (unsigned short )0;
            sqlstm.sqtdso[6] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}




         }
         else
         {
            while(found != string::npos) 
            {  
               string replaceBya ("<CODE>");
               temp.replace( found, strlen("<CODE_00>"), replaceBya );
               searchFora = "</CODE_";    
               replaceBya = "</CODE>";
               found = temp.find( searchFora );
               temp.replace( found,strlen("</CODE_00>"), replaceBya );
               string searchFora ("<CODE_");    
               found = temp.find( searchFora );
            }
            found = temp.find("<CODE>");
            while(found != string::npos)
            {
               int fir = temp.find("<CODE>")+strlen("CODE>")+1;
               int last =temp.find("</CODE>");
               string value1 = temp.substr(fir,last-fir);
               Param_ID = first ;
               strcpy(Value,value1.c_str());
               Count_Val++;
               /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,44,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
               struct sqlexd sqlstm;
               sqlstm.sqlvsn = 12;
               sqlstm.arrsiz = 8;
               sqlstm.sqladtp = &sqladt;
               sqlstm.sqltdsp = &sqltds;
               sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENT\
ITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING\
_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,44,:b2,\
:b3,:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
               sqlstm.iters = (unsigned int  )1;
               sqlstm.offset = (unsigned int  )4803;
               sqlstm.cud = sqlcud0;
               sqlstm.sqlest = (unsigned char  *)&sqlca;
               sqlstm.sqlety = (unsigned short)256;
               sqlstm.occurs = (unsigned int  )0;
               sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
               sqlstm.sqhstl[0] = (unsigned long )20;
               sqlstm.sqhsts[0] = (         int  )0;
               sqlstm.sqindv[0] = (         short *)0;
               sqlstm.sqinds[0] = (         int  )0;
               sqlstm.sqharm[0] = (unsigned long )0;
               sqlstm.sqadto[0] = (unsigned short )0;
               sqlstm.sqtdso[0] = (unsigned short )0;
               sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
               sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[1] = (         int  )0;
               sqlstm.sqindv[1] = (         short *)0;
               sqlstm.sqinds[1] = (         int  )0;
               sqlstm.sqharm[1] = (unsigned long )0;
               sqlstm.sqadto[1] = (unsigned short )0;
               sqlstm.sqtdso[1] = (unsigned short )0;
               sqlstm.sqhstv[2] = (unsigned char  *)Value;
               sqlstm.sqhstl[2] = (unsigned long )100000;
               sqlstm.sqhsts[2] = (         int  )0;
               sqlstm.sqindv[2] = (         short *)0;
               sqlstm.sqinds[2] = (         int  )0;
               sqlstm.sqharm[2] = (unsigned long )0;
               sqlstm.sqadto[2] = (unsigned short )0;
               sqlstm.sqtdso[2] = (unsigned short )0;
               sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
               sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[3] = (         int  )0;
               sqlstm.sqindv[3] = (         short *)0;
               sqlstm.sqinds[3] = (         int  )0;
               sqlstm.sqharm[3] = (unsigned long )0;
               sqlstm.sqadto[3] = (unsigned short )0;
               sqlstm.sqtdso[3] = (unsigned short )0;
               sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
               sqlstm.sqhstl[4] = (unsigned long )20;
               sqlstm.sqhsts[4] = (         int  )0;
               sqlstm.sqindv[4] = (         short *)0;
               sqlstm.sqinds[4] = (         int  )0;
               sqlstm.sqharm[4] = (unsigned long )0;
               sqlstm.sqadto[4] = (unsigned short )0;
               sqlstm.sqtdso[4] = (unsigned short )0;
               sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
               sqlstm.sqhstl[5] = (unsigned long )10;
               sqlstm.sqhsts[5] = (         int  )0;
               sqlstm.sqindv[5] = (         short *)0;
               sqlstm.sqinds[5] = (         int  )0;
               sqlstm.sqharm[5] = (unsigned long )0;
               sqlstm.sqadto[5] = (unsigned short )0;
               sqlstm.sqtdso[5] = (unsigned short )0;
               sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
               sqlstm.sqhstl[6] = (unsigned long )102;
               sqlstm.sqhsts[6] = (         int  )0;
               sqlstm.sqindv[6] = (         short *)0;
               sqlstm.sqinds[6] = (         int  )0;
               sqlstm.sqharm[6] = (unsigned long )0;
               sqlstm.sqadto[6] = (unsigned short )0;
               sqlstm.sqtdso[6] = (unsigned short )0;
               sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
               sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[7] = (         int  )0;
               sqlstm.sqindv[7] = (         short *)0;
               sqlstm.sqinds[7] = (         int  )0;
               sqlstm.sqharm[7] = (unsigned long )0;
               sqlstm.sqadto[7] = (unsigned short )0;
               sqlstm.sqtdso[7] = (unsigned short )0;
               sqlstm.sqphsv = sqlstm.sqhstv;
               sqlstm.sqphsl = sqlstm.sqhstl;
               sqlstm.sqphss = sqlstm.sqhsts;
               sqlstm.sqpind = sqlstm.sqindv;
               sqlstm.sqpins = sqlstm.sqinds;
               sqlstm.sqparm = sqlstm.sqharm;
               sqlstm.sqparc = sqlstm.sqharc;
               sqlstm.sqpadto = sqlstm.sqadto;
               sqlstm.sqptdso = sqlstm.sqtdso;
               sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
               if (sqlca.sqlcode < 0) goto sqlerr;
}


               temp.erase(temp.find("<CODE>"),temp.find("</CODE>")+strlen("/CODE>")- temp.find("<CODE>")+1);
               found = temp.find("<CODE>");

            }
         }
         if(0 == strcmp(g_ConObj.m_InstanceSp_DB.c_str(),"INST"))
            /* EXEC SQL INSERT INTO HLR_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CONFIG_VALUES (ENTITY_NAME,PARAM_\
ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYP\
E) values (:b0,:b1,:b2,:b3,'OS',to_date(:b4,'mm/dd/yyyy hh24:mi:ss'),:b5)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )4850;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[2] = (unsigned long )20;
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[3] = (unsigned long )10;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[4] = (unsigned long )102;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[5] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}




         /* EXEC SQL COMMIT; */ 

{
         struct sqlexd sqlstm;
         sqlstm.sqlvsn = 12;
         sqlstm.arrsiz = 8;
         sqlstm.sqladtp = &sqladt;
         sqlstm.sqltdsp = &sqltds;
         sqlstm.iters = (unsigned int  )1;
         sqlstm.offset = (unsigned int  )4889;
         sqlstm.cud = sqlcud0;
         sqlstm.sqlest = (unsigned char  *)&sqlca;
         sqlstm.sqlety = (unsigned short)256;
         sqlstm.occurs = (unsigned int  )0;
         sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
         if (sqlca.sqlcode < 0) goto sqlerr;
}


      }
      else if(first == 231)
      {
         Param_ID = first;
         int found;
         string temp =  complexMap.find(first)->second; 
         string searchFora ("<CODE_");    
         found = temp.find( searchFora );
         if(found == -1)
         {
            Count_Val++;

            /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,45,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENTITY\
_NAME,PARAM_ID,SUB_PARAM_ID,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDA\
TED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,45,:b2,:b3,:b4,'OS',to\
_date(:b5,'mm/dd/yyyy hh24:mi:ss'),:b6)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )4904;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)&Count_Val;
            sqlstm.sqhstl[2] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[3] = (unsigned long )20;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[4] = (unsigned long )10;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[5] = (unsigned long )102;
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqhstv[6] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[6] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[6] = (         int  )0;
            sqlstm.sqindv[6] = (         short *)0;
            sqlstm.sqinds[6] = (         int  )0;
            sqlstm.sqharm[6] = (unsigned long )0;
            sqlstm.sqadto[6] = (unsigned short )0;
            sqlstm.sqtdso[6] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}



         }
         else
         {
            while(found != string::npos) 
            {  
               string replaceBya ("<CODE>");
               temp.replace( found, strlen("<CODE_00>"), replaceBya );
               searchFora = "</CODE_";    
               replaceBya = "</CODE>";
               found = temp.find( searchFora );
               temp.replace( found,strlen("</CODE_00>"), replaceBya );
               string searchFora ("<CODE_");    
               found = temp.find( searchFora );
            }
            found = temp.find("<CODE>");
            while(found != string::npos)
            {
               int fir = temp.find("<CODE>")+strlen("CODE>")+1;
               int last =temp.find("</CODE>");
               string value1 = temp.substr(fir,last-fir);
               Param_ID = first ;
               strcpy(Value,value1.c_str());
               Count_Val++;
               /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,45,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
               struct sqlexd sqlstm;
               sqlstm.sqlvsn = 12;
               sqlstm.arrsiz = 8;
               sqlstm.sqladtp = &sqladt;
               sqlstm.sqltdsp = &sqltds;
               sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENT\
ITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING\
_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,45,:b2,\
:b3,:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
               sqlstm.iters = (unsigned int  )1;
               sqlstm.offset = (unsigned int  )4947;
               sqlstm.cud = sqlcud0;
               sqlstm.sqlest = (unsigned char  *)&sqlca;
               sqlstm.sqlety = (unsigned short)256;
               sqlstm.occurs = (unsigned int  )0;
               sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
               sqlstm.sqhstl[0] = (unsigned long )20;
               sqlstm.sqhsts[0] = (         int  )0;
               sqlstm.sqindv[0] = (         short *)0;
               sqlstm.sqinds[0] = (         int  )0;
               sqlstm.sqharm[0] = (unsigned long )0;
               sqlstm.sqadto[0] = (unsigned short )0;
               sqlstm.sqtdso[0] = (unsigned short )0;
               sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
               sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[1] = (         int  )0;
               sqlstm.sqindv[1] = (         short *)0;
               sqlstm.sqinds[1] = (         int  )0;
               sqlstm.sqharm[1] = (unsigned long )0;
               sqlstm.sqadto[1] = (unsigned short )0;
               sqlstm.sqtdso[1] = (unsigned short )0;
               sqlstm.sqhstv[2] = (unsigned char  *)Value;
               sqlstm.sqhstl[2] = (unsigned long )100000;
               sqlstm.sqhsts[2] = (         int  )0;
               sqlstm.sqindv[2] = (         short *)0;
               sqlstm.sqinds[2] = (         int  )0;
               sqlstm.sqharm[2] = (unsigned long )0;
               sqlstm.sqadto[2] = (unsigned short )0;
               sqlstm.sqtdso[2] = (unsigned short )0;
               sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
               sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[3] = (         int  )0;
               sqlstm.sqindv[3] = (         short *)0;
               sqlstm.sqinds[3] = (         int  )0;
               sqlstm.sqharm[3] = (unsigned long )0;
               sqlstm.sqadto[3] = (unsigned short )0;
               sqlstm.sqtdso[3] = (unsigned short )0;
               sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
               sqlstm.sqhstl[4] = (unsigned long )20;
               sqlstm.sqhsts[4] = (         int  )0;
               sqlstm.sqindv[4] = (         short *)0;
               sqlstm.sqinds[4] = (         int  )0;
               sqlstm.sqharm[4] = (unsigned long )0;
               sqlstm.sqadto[4] = (unsigned short )0;
               sqlstm.sqtdso[4] = (unsigned short )0;
               sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
               sqlstm.sqhstl[5] = (unsigned long )10;
               sqlstm.sqhsts[5] = (         int  )0;
               sqlstm.sqindv[5] = (         short *)0;
               sqlstm.sqinds[5] = (         int  )0;
               sqlstm.sqharm[5] = (unsigned long )0;
               sqlstm.sqadto[5] = (unsigned short )0;
               sqlstm.sqtdso[5] = (unsigned short )0;
               sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
               sqlstm.sqhstl[6] = (unsigned long )102;
               sqlstm.sqhsts[6] = (         int  )0;
               sqlstm.sqindv[6] = (         short *)0;
               sqlstm.sqinds[6] = (         int  )0;
               sqlstm.sqharm[6] = (unsigned long )0;
               sqlstm.sqadto[6] = (unsigned short )0;
               sqlstm.sqtdso[6] = (unsigned short )0;
               sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
               sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[7] = (         int  )0;
               sqlstm.sqindv[7] = (         short *)0;
               sqlstm.sqinds[7] = (         int  )0;
               sqlstm.sqharm[7] = (unsigned long )0;
               sqlstm.sqadto[7] = (unsigned short )0;
               sqlstm.sqtdso[7] = (unsigned short )0;
               sqlstm.sqphsv = sqlstm.sqhstv;
               sqlstm.sqphsl = sqlstm.sqhstl;
               sqlstm.sqphss = sqlstm.sqhsts;
               sqlstm.sqpind = sqlstm.sqindv;
               sqlstm.sqpins = sqlstm.sqinds;
               sqlstm.sqparm = sqlstm.sqharm;
               sqlstm.sqparc = sqlstm.sqharc;
               sqlstm.sqpadto = sqlstm.sqadto;
               sqlstm.sqptdso = sqlstm.sqtdso;
               sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
               if (sqlca.sqlcode < 0) goto sqlerr;
}


               temp.erase(temp.find("<CODE>"),temp.find("</CODE>")+strlen("/CODE>")- temp.find("<CODE>")+1);
               found = temp.find("<CODE>");
            }
         }
         if(0 == strcmp(g_ConObj.m_InstanceSp_DB.c_str(),"INST"))
            /* EXEC SQL INSERT INTO HLR_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CONFIG_VALUES (ENTITY_NAME,PARAM_\
ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYP\
E) values (:b0,:b1,:b2,:b3,'OS',to_date(:b4,'mm/dd/yyyy hh24:mi:ss'),:b5)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )4994;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[2] = (unsigned long )20;
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[3] = (unsigned long )10;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[4] = (unsigned long )102;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[5] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}




         /* EXEC SQL COMMIT; */ 

{
         struct sqlexd sqlstm;
         sqlstm.sqlvsn = 12;
         sqlstm.arrsiz = 8;
         sqlstm.sqladtp = &sqladt;
         sqlstm.sqltdsp = &sqltds;
         sqlstm.iters = (unsigned int  )1;
         sqlstm.offset = (unsigned int  )5033;
         sqlstm.cud = sqlcud0;
         sqlstm.sqlest = (unsigned char  *)&sqlca;
         sqlstm.sqlety = (unsigned short)256;
         sqlstm.occurs = (unsigned int  )0;
         sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
         if (sqlca.sqlcode < 0) goto sqlerr;
}


      }
      else if(first == 240)
      {
         Param_ID = first;
         int found;
         string temp =  complexMap.find(first)->second; 
         string searchFora ("<CODE_");    
         found = temp.find( searchFora );
         if(found == -1)
         {
            Count_Val++;

            /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,46,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENTITY\
_NAME,PARAM_ID,SUB_PARAM_ID,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDA\
TED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,46,:b2,:b3,:b4,'OS',to\
_date(:b5,'mm/dd/yyyy hh24:mi:ss'),:b6)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )5048;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)&Count_Val;
            sqlstm.sqhstl[2] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[3] = (unsigned long )20;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[4] = (unsigned long )10;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[5] = (unsigned long )102;
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqhstv[6] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[6] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[6] = (         int  )0;
            sqlstm.sqindv[6] = (         short *)0;
            sqlstm.sqinds[6] = (         int  )0;
            sqlstm.sqharm[6] = (unsigned long )0;
            sqlstm.sqadto[6] = (unsigned short )0;
            sqlstm.sqtdso[6] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}



         }
         else
         {
            while(found != string::npos) 
            {  
               string replaceBya ("<CODE>");
               temp.replace( found, strlen("<CODE_00>"), replaceBya );
               searchFora = "</CODE_";    
               replaceBya = "</CODE>";
               found = temp.find( searchFora );
               temp.replace( found,strlen("</CODE_00>"), replaceBya );
               string searchFora ("<CODE_");    
               found = temp.find( searchFora );
            }
            found = temp.find("<CODE>");
            while(found != string::npos)
            {
               int fir = temp.find("<CODE>")+strlen("CODE>")+1;
               int last =temp.find("</CODE>");
               string value1 = temp.substr(fir,last-fir);
               Param_ID = first ;
               strcpy(Value,value1.c_str());
               Count_Val++;
               /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,46,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
               struct sqlexd sqlstm;
               sqlstm.sqlvsn = 12;
               sqlstm.arrsiz = 8;
               sqlstm.sqladtp = &sqladt;
               sqlstm.sqltdsp = &sqltds;
               sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENT\
ITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING\
_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,46,:b2,\
:b3,:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
               sqlstm.iters = (unsigned int  )1;
               sqlstm.offset = (unsigned int  )5091;
               sqlstm.cud = sqlcud0;
               sqlstm.sqlest = (unsigned char  *)&sqlca;
               sqlstm.sqlety = (unsigned short)256;
               sqlstm.occurs = (unsigned int  )0;
               sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
               sqlstm.sqhstl[0] = (unsigned long )20;
               sqlstm.sqhsts[0] = (         int  )0;
               sqlstm.sqindv[0] = (         short *)0;
               sqlstm.sqinds[0] = (         int  )0;
               sqlstm.sqharm[0] = (unsigned long )0;
               sqlstm.sqadto[0] = (unsigned short )0;
               sqlstm.sqtdso[0] = (unsigned short )0;
               sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
               sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[1] = (         int  )0;
               sqlstm.sqindv[1] = (         short *)0;
               sqlstm.sqinds[1] = (         int  )0;
               sqlstm.sqharm[1] = (unsigned long )0;
               sqlstm.sqadto[1] = (unsigned short )0;
               sqlstm.sqtdso[1] = (unsigned short )0;
               sqlstm.sqhstv[2] = (unsigned char  *)Value;
               sqlstm.sqhstl[2] = (unsigned long )100000;
               sqlstm.sqhsts[2] = (         int  )0;
               sqlstm.sqindv[2] = (         short *)0;
               sqlstm.sqinds[2] = (         int  )0;
               sqlstm.sqharm[2] = (unsigned long )0;
               sqlstm.sqadto[2] = (unsigned short )0;
               sqlstm.sqtdso[2] = (unsigned short )0;
               sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
               sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[3] = (         int  )0;
               sqlstm.sqindv[3] = (         short *)0;
               sqlstm.sqinds[3] = (         int  )0;
               sqlstm.sqharm[3] = (unsigned long )0;
               sqlstm.sqadto[3] = (unsigned short )0;
               sqlstm.sqtdso[3] = (unsigned short )0;
               sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
               sqlstm.sqhstl[4] = (unsigned long )20;
               sqlstm.sqhsts[4] = (         int  )0;
               sqlstm.sqindv[4] = (         short *)0;
               sqlstm.sqinds[4] = (         int  )0;
               sqlstm.sqharm[4] = (unsigned long )0;
               sqlstm.sqadto[4] = (unsigned short )0;
               sqlstm.sqtdso[4] = (unsigned short )0;
               sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
               sqlstm.sqhstl[5] = (unsigned long )10;
               sqlstm.sqhsts[5] = (         int  )0;
               sqlstm.sqindv[5] = (         short *)0;
               sqlstm.sqinds[5] = (         int  )0;
               sqlstm.sqharm[5] = (unsigned long )0;
               sqlstm.sqadto[5] = (unsigned short )0;
               sqlstm.sqtdso[5] = (unsigned short )0;
               sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
               sqlstm.sqhstl[6] = (unsigned long )102;
               sqlstm.sqhsts[6] = (         int  )0;
               sqlstm.sqindv[6] = (         short *)0;
               sqlstm.sqinds[6] = (         int  )0;
               sqlstm.sqharm[6] = (unsigned long )0;
               sqlstm.sqadto[6] = (unsigned short )0;
               sqlstm.sqtdso[6] = (unsigned short )0;
               sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
               sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[7] = (         int  )0;
               sqlstm.sqindv[7] = (         short *)0;
               sqlstm.sqinds[7] = (         int  )0;
               sqlstm.sqharm[7] = (unsigned long )0;
               sqlstm.sqadto[7] = (unsigned short )0;
               sqlstm.sqtdso[7] = (unsigned short )0;
               sqlstm.sqphsv = sqlstm.sqhstv;
               sqlstm.sqphsl = sqlstm.sqhstl;
               sqlstm.sqphss = sqlstm.sqhsts;
               sqlstm.sqpind = sqlstm.sqindv;
               sqlstm.sqpins = sqlstm.sqinds;
               sqlstm.sqparm = sqlstm.sqharm;
               sqlstm.sqparc = sqlstm.sqharc;
               sqlstm.sqpadto = sqlstm.sqadto;
               sqlstm.sqptdso = sqlstm.sqtdso;
               sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
               if (sqlca.sqlcode < 0) goto sqlerr;
}


               temp.erase(temp.find("<CODE>"),temp.find("</CODE>")+strlen("/CODE>")- temp.find("<CODE>")+1);
               found = temp.find("<CODE>");
            }
         }
         if(0 == strcmp(g_ConObj.m_InstanceSp_DB.c_str(),"INST"))
            /* EXEC SQL INSERT INTO HLR_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CONFIG_VALUES (ENTITY_NAME,PARAM_\
ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYP\
E) values (:b0,:b1,:b2,:b3,'OS',to_date(:b4,'mm/dd/yyyy hh24:mi:ss'),:b5)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )5138;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[2] = (unsigned long )20;
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[3] = (unsigned long )10;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[4] = (unsigned long )102;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[5] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}




         /* EXEC SQL COMMIT; */ 

{
         struct sqlexd sqlstm;
         sqlstm.sqlvsn = 12;
         sqlstm.arrsiz = 8;
         sqlstm.sqladtp = &sqladt;
         sqlstm.sqltdsp = &sqltds;
         sqlstm.iters = (unsigned int  )1;
         sqlstm.offset = (unsigned int  )5177;
         sqlstm.cud = sqlcud0;
         sqlstm.sqlest = (unsigned char  *)&sqlca;
         sqlstm.sqlety = (unsigned short)256;
         sqlstm.occurs = (unsigned int  )0;
         sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
         if (sqlca.sqlcode < 0) goto sqlerr;
}


      }
      else if(first == 248)
      {
         Param_ID = first;
         int found;
         string temp =  complexMap.find(first)->second; 
         string searchFora ("<CODE_");    
         found = temp.find( searchFora );
         if(found == -1)
         {
            Count_Val++;

            /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,47,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENTITY\
_NAME,PARAM_ID,SUB_PARAM_ID,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDA\
TED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,47,:b2,:b3,:b4,'OS',to\
_date(:b5,'mm/dd/yyyy hh24:mi:ss'),:b6)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )5192;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)&Count_Val;
            sqlstm.sqhstl[2] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[3] = (unsigned long )20;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[4] = (unsigned long )10;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[5] = (unsigned long )102;
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqhstv[6] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[6] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[6] = (         int  )0;
            sqlstm.sqindv[6] = (         short *)0;
            sqlstm.sqinds[6] = (         int  )0;
            sqlstm.sqharm[6] = (unsigned long )0;
            sqlstm.sqadto[6] = (unsigned short )0;
            sqlstm.sqtdso[6] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}




         }
         else
         {
            while(found != string::npos) 
            {  
               string replaceBya ("<CODE>");
               temp.replace( found, strlen("<CODE_00>"), replaceBya );
               searchFora = "</CODE_";    
               replaceBya = "</CODE>";
               found = temp.find( searchFora );
               temp.replace( found,strlen("</CODE_00>"), replaceBya );
               string searchFora ("<CODE_");    
               found = temp.find( searchFora );
            }
            found = temp.find("<CODE>");
            while(found != string::npos)
            {
               int fir = temp.find("<CODE>")+strlen("CODE>")+1;
               int last =temp.find("</CODE>");
               string value1 = temp.substr(fir,last-fir);
               Param_ID = first ;
               strcpy(Value,value1.c_str());
               Count_Val++;
               /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,47,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
               struct sqlexd sqlstm;
               sqlstm.sqlvsn = 12;
               sqlstm.arrsiz = 8;
               sqlstm.sqladtp = &sqladt;
               sqlstm.sqltdsp = &sqltds;
               sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENT\
ITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING\
_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,47,:b2,\
:b3,:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
               sqlstm.iters = (unsigned int  )1;
               sqlstm.offset = (unsigned int  )5235;
               sqlstm.cud = sqlcud0;
               sqlstm.sqlest = (unsigned char  *)&sqlca;
               sqlstm.sqlety = (unsigned short)256;
               sqlstm.occurs = (unsigned int  )0;
               sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
               sqlstm.sqhstl[0] = (unsigned long )20;
               sqlstm.sqhsts[0] = (         int  )0;
               sqlstm.sqindv[0] = (         short *)0;
               sqlstm.sqinds[0] = (         int  )0;
               sqlstm.sqharm[0] = (unsigned long )0;
               sqlstm.sqadto[0] = (unsigned short )0;
               sqlstm.sqtdso[0] = (unsigned short )0;
               sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
               sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[1] = (         int  )0;
               sqlstm.sqindv[1] = (         short *)0;
               sqlstm.sqinds[1] = (         int  )0;
               sqlstm.sqharm[1] = (unsigned long )0;
               sqlstm.sqadto[1] = (unsigned short )0;
               sqlstm.sqtdso[1] = (unsigned short )0;
               sqlstm.sqhstv[2] = (unsigned char  *)Value;
               sqlstm.sqhstl[2] = (unsigned long )100000;
               sqlstm.sqhsts[2] = (         int  )0;
               sqlstm.sqindv[2] = (         short *)0;
               sqlstm.sqinds[2] = (         int  )0;
               sqlstm.sqharm[2] = (unsigned long )0;
               sqlstm.sqadto[2] = (unsigned short )0;
               sqlstm.sqtdso[2] = (unsigned short )0;
               sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
               sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[3] = (         int  )0;
               sqlstm.sqindv[3] = (         short *)0;
               sqlstm.sqinds[3] = (         int  )0;
               sqlstm.sqharm[3] = (unsigned long )0;
               sqlstm.sqadto[3] = (unsigned short )0;
               sqlstm.sqtdso[3] = (unsigned short )0;
               sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
               sqlstm.sqhstl[4] = (unsigned long )20;
               sqlstm.sqhsts[4] = (         int  )0;
               sqlstm.sqindv[4] = (         short *)0;
               sqlstm.sqinds[4] = (         int  )0;
               sqlstm.sqharm[4] = (unsigned long )0;
               sqlstm.sqadto[4] = (unsigned short )0;
               sqlstm.sqtdso[4] = (unsigned short )0;
               sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
               sqlstm.sqhstl[5] = (unsigned long )10;
               sqlstm.sqhsts[5] = (         int  )0;
               sqlstm.sqindv[5] = (         short *)0;
               sqlstm.sqinds[5] = (         int  )0;
               sqlstm.sqharm[5] = (unsigned long )0;
               sqlstm.sqadto[5] = (unsigned short )0;
               sqlstm.sqtdso[5] = (unsigned short )0;
               sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
               sqlstm.sqhstl[6] = (unsigned long )102;
               sqlstm.sqhsts[6] = (         int  )0;
               sqlstm.sqindv[6] = (         short *)0;
               sqlstm.sqinds[6] = (         int  )0;
               sqlstm.sqharm[6] = (unsigned long )0;
               sqlstm.sqadto[6] = (unsigned short )0;
               sqlstm.sqtdso[6] = (unsigned short )0;
               sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
               sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[7] = (         int  )0;
               sqlstm.sqindv[7] = (         short *)0;
               sqlstm.sqinds[7] = (         int  )0;
               sqlstm.sqharm[7] = (unsigned long )0;
               sqlstm.sqadto[7] = (unsigned short )0;
               sqlstm.sqtdso[7] = (unsigned short )0;
               sqlstm.sqphsv = sqlstm.sqhstv;
               sqlstm.sqphsl = sqlstm.sqhstl;
               sqlstm.sqphss = sqlstm.sqhsts;
               sqlstm.sqpind = sqlstm.sqindv;
               sqlstm.sqpins = sqlstm.sqinds;
               sqlstm.sqparm = sqlstm.sqharm;
               sqlstm.sqparc = sqlstm.sqharc;
               sqlstm.sqpadto = sqlstm.sqadto;
               sqlstm.sqptdso = sqlstm.sqtdso;
               sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
               if (sqlca.sqlcode < 0) goto sqlerr;
}


               temp.erase(temp.find("<CODE>"),temp.find("</CODE>")+strlen("/CODE>")- temp.find("<CODE>")+1);
               found = temp.find("<CODE>");
            }
         }
         if(0 == strcmp(g_ConObj.m_InstanceSp_DB.c_str(),"INST"))
            /* EXEC SQL INSERT INTO HLR_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CONFIG_VALUES (ENTITY_NAME,PARAM_\
ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYP\
E) values (:b0,:b1,:b2,:b3,'OS',to_date(:b4,'mm/dd/yyyy hh24:mi:ss'),:b5)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )5282;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[2] = (unsigned long )20;
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[3] = (unsigned long )10;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[4] = (unsigned long )102;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[5] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}




         /* EXEC SQL COMMIT; */ 

{
         struct sqlexd sqlstm;
         sqlstm.sqlvsn = 12;
         sqlstm.arrsiz = 8;
         sqlstm.sqladtp = &sqladt;
         sqlstm.sqltdsp = &sqltds;
         sqlstm.iters = (unsigned int  )1;
         sqlstm.offset = (unsigned int  )5321;
         sqlstm.cud = sqlcud0;
         sqlstm.sqlest = (unsigned char  *)&sqlca;
         sqlstm.sqlety = (unsigned short)256;
         sqlstm.occurs = (unsigned int  )0;
         sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
         if (sqlca.sqlcode < 0) goto sqlerr;
}


      }
      else if(first == 256)
      {
         Param_ID = first;
         int found;
         string temp =  complexMap.find(first)->second; 
         found = temp.find("<SERVICETYPE_TEMPLATE_LIST>");    
         if(found == -1)
         {
            ELOG(0,0,"!!!!!!!!!! SERVICETYPE_TEMPLATE_LIST Tag not Found ITG !!!!!!!!");
         }
         while(found != string::npos)
         {
            int fir = temp.find("<>")+strlen(">")+1;
            int last =temp.find("</SERVICETYPE_TEMPLATE_LIST>");
            string value1 = temp.substr(fir,last-fir);
            string value2 = Parser::getValue(value1,"SERVICE_TYPE");
            if( 0 == value2.size())
            {
               ELOG(0,0,"SERVICE_TYPE not Found in ITG SERVICETYPE_TEMPLATE_LIST");
            }
            else
            {
               strcpy(Value,value2.c_str());
               Count_Val++;
               /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,48,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
               struct sqlexd sqlstm;
               sqlstm.sqlvsn = 12;
               sqlstm.arrsiz = 8;
               sqlstm.sqladtp = &sqladt;
               sqlstm.sqltdsp = &sqltds;
               sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENT\
ITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING\
_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,48,:b2,\
:b3,:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
               sqlstm.iters = (unsigned int  )1;
               sqlstm.offset = (unsigned int  )5336;
               sqlstm.cud = sqlcud0;
               sqlstm.sqlest = (unsigned char  *)&sqlca;
               sqlstm.sqlety = (unsigned short)256;
               sqlstm.occurs = (unsigned int  )0;
               sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
               sqlstm.sqhstl[0] = (unsigned long )20;
               sqlstm.sqhsts[0] = (         int  )0;
               sqlstm.sqindv[0] = (         short *)0;
               sqlstm.sqinds[0] = (         int  )0;
               sqlstm.sqharm[0] = (unsigned long )0;
               sqlstm.sqadto[0] = (unsigned short )0;
               sqlstm.sqtdso[0] = (unsigned short )0;
               sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
               sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[1] = (         int  )0;
               sqlstm.sqindv[1] = (         short *)0;
               sqlstm.sqinds[1] = (         int  )0;
               sqlstm.sqharm[1] = (unsigned long )0;
               sqlstm.sqadto[1] = (unsigned short )0;
               sqlstm.sqtdso[1] = (unsigned short )0;
               sqlstm.sqhstv[2] = (unsigned char  *)Value;
               sqlstm.sqhstl[2] = (unsigned long )100000;
               sqlstm.sqhsts[2] = (         int  )0;
               sqlstm.sqindv[2] = (         short *)0;
               sqlstm.sqinds[2] = (         int  )0;
               sqlstm.sqharm[2] = (unsigned long )0;
               sqlstm.sqadto[2] = (unsigned short )0;
               sqlstm.sqtdso[2] = (unsigned short )0;
               sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
               sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[3] = (         int  )0;
               sqlstm.sqindv[3] = (         short *)0;
               sqlstm.sqinds[3] = (         int  )0;
               sqlstm.sqharm[3] = (unsigned long )0;
               sqlstm.sqadto[3] = (unsigned short )0;
               sqlstm.sqtdso[3] = (unsigned short )0;
               sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
               sqlstm.sqhstl[4] = (unsigned long )20;
               sqlstm.sqhsts[4] = (         int  )0;
               sqlstm.sqindv[4] = (         short *)0;
               sqlstm.sqinds[4] = (         int  )0;
               sqlstm.sqharm[4] = (unsigned long )0;
               sqlstm.sqadto[4] = (unsigned short )0;
               sqlstm.sqtdso[4] = (unsigned short )0;
               sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
               sqlstm.sqhstl[5] = (unsigned long )10;
               sqlstm.sqhsts[5] = (         int  )0;
               sqlstm.sqindv[5] = (         short *)0;
               sqlstm.sqinds[5] = (         int  )0;
               sqlstm.sqharm[5] = (unsigned long )0;
               sqlstm.sqadto[5] = (unsigned short )0;
               sqlstm.sqtdso[5] = (unsigned short )0;
               sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
               sqlstm.sqhstl[6] = (unsigned long )102;
               sqlstm.sqhsts[6] = (         int  )0;
               sqlstm.sqindv[6] = (         short *)0;
               sqlstm.sqinds[6] = (         int  )0;
               sqlstm.sqharm[6] = (unsigned long )0;
               sqlstm.sqadto[6] = (unsigned short )0;
               sqlstm.sqtdso[6] = (unsigned short )0;
               sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
               sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[7] = (         int  )0;
               sqlstm.sqindv[7] = (         short *)0;
               sqlstm.sqinds[7] = (         int  )0;
               sqlstm.sqharm[7] = (unsigned long )0;
               sqlstm.sqadto[7] = (unsigned short )0;
               sqlstm.sqtdso[7] = (unsigned short )0;
               sqlstm.sqphsv = sqlstm.sqhstv;
               sqlstm.sqphsl = sqlstm.sqhstl;
               sqlstm.sqphss = sqlstm.sqhsts;
               sqlstm.sqpind = sqlstm.sqindv;
               sqlstm.sqpins = sqlstm.sqinds;
               sqlstm.sqparm = sqlstm.sqharm;
               sqlstm.sqparc = sqlstm.sqharc;
               sqlstm.sqpadto = sqlstm.sqadto;
               sqlstm.sqptdso = sqlstm.sqtdso;
               sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
               if (sqlca.sqlcode < 0) goto sqlerr;
}



            }
            value2 = Parser::getValue(value1,"TEMPLATE_ID");

            if( 0 == value2.size())
            {
               ELOG(0,0,"TEMPLATE_ID not Found in ITG SERVICETYPE_TEMPLATE_LIST");
            }
            else
            {
               strcpy(Value,value2.c_str());
               /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,49,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
               struct sqlexd sqlstm;
               sqlstm.sqlvsn = 12;
               sqlstm.arrsiz = 8;
               sqlstm.sqladtp = &sqladt;
               sqlstm.sqltdsp = &sqltds;
               sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENT\
ITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING\
_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,49,:b2,\
:b3,:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
               sqlstm.iters = (unsigned int  )1;
               sqlstm.offset = (unsigned int  )5383;
               sqlstm.cud = sqlcud0;
               sqlstm.sqlest = (unsigned char  *)&sqlca;
               sqlstm.sqlety = (unsigned short)256;
               sqlstm.occurs = (unsigned int  )0;
               sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
               sqlstm.sqhstl[0] = (unsigned long )20;
               sqlstm.sqhsts[0] = (         int  )0;
               sqlstm.sqindv[0] = (         short *)0;
               sqlstm.sqinds[0] = (         int  )0;
               sqlstm.sqharm[0] = (unsigned long )0;
               sqlstm.sqadto[0] = (unsigned short )0;
               sqlstm.sqtdso[0] = (unsigned short )0;
               sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
               sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[1] = (         int  )0;
               sqlstm.sqindv[1] = (         short *)0;
               sqlstm.sqinds[1] = (         int  )0;
               sqlstm.sqharm[1] = (unsigned long )0;
               sqlstm.sqadto[1] = (unsigned short )0;
               sqlstm.sqtdso[1] = (unsigned short )0;
               sqlstm.sqhstv[2] = (unsigned char  *)Value;
               sqlstm.sqhstl[2] = (unsigned long )100000;
               sqlstm.sqhsts[2] = (         int  )0;
               sqlstm.sqindv[2] = (         short *)0;
               sqlstm.sqinds[2] = (         int  )0;
               sqlstm.sqharm[2] = (unsigned long )0;
               sqlstm.sqadto[2] = (unsigned short )0;
               sqlstm.sqtdso[2] = (unsigned short )0;
               sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
               sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[3] = (         int  )0;
               sqlstm.sqindv[3] = (         short *)0;
               sqlstm.sqinds[3] = (         int  )0;
               sqlstm.sqharm[3] = (unsigned long )0;
               sqlstm.sqadto[3] = (unsigned short )0;
               sqlstm.sqtdso[3] = (unsigned short )0;
               sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
               sqlstm.sqhstl[4] = (unsigned long )20;
               sqlstm.sqhsts[4] = (         int  )0;
               sqlstm.sqindv[4] = (         short *)0;
               sqlstm.sqinds[4] = (         int  )0;
               sqlstm.sqharm[4] = (unsigned long )0;
               sqlstm.sqadto[4] = (unsigned short )0;
               sqlstm.sqtdso[4] = (unsigned short )0;
               sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
               sqlstm.sqhstl[5] = (unsigned long )10;
               sqlstm.sqhsts[5] = (         int  )0;
               sqlstm.sqindv[5] = (         short *)0;
               sqlstm.sqinds[5] = (         int  )0;
               sqlstm.sqharm[5] = (unsigned long )0;
               sqlstm.sqadto[5] = (unsigned short )0;
               sqlstm.sqtdso[5] = (unsigned short )0;
               sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
               sqlstm.sqhstl[6] = (unsigned long )102;
               sqlstm.sqhsts[6] = (         int  )0;
               sqlstm.sqindv[6] = (         short *)0;
               sqlstm.sqinds[6] = (         int  )0;
               sqlstm.sqharm[6] = (unsigned long )0;
               sqlstm.sqadto[6] = (unsigned short )0;
               sqlstm.sqtdso[6] = (unsigned short )0;
               sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
               sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[7] = (         int  )0;
               sqlstm.sqindv[7] = (         short *)0;
               sqlstm.sqinds[7] = (         int  )0;
               sqlstm.sqharm[7] = (unsigned long )0;
               sqlstm.sqadto[7] = (unsigned short )0;
               sqlstm.sqtdso[7] = (unsigned short )0;
               sqlstm.sqphsv = sqlstm.sqhstv;
               sqlstm.sqphsl = sqlstm.sqhstl;
               sqlstm.sqphss = sqlstm.sqhsts;
               sqlstm.sqpind = sqlstm.sqindv;
               sqlstm.sqpins = sqlstm.sqinds;
               sqlstm.sqparm = sqlstm.sqharm;
               sqlstm.sqparc = sqlstm.sqharc;
               sqlstm.sqpadto = sqlstm.sqadto;
               sqlstm.sqptdso = sqlstm.sqtdso;
               sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
               if (sqlca.sqlcode < 0) goto sqlerr;
}


            }
            temp.erase(temp.find("<SERVICETYPE_TEMPLATE_LIST>"),temp.find("</SERVICETYPE_TEMPLATE_LIST>")+strlen("/SERVICETYPE_TEMPLATE_LIST>")- temp.find("<SERVICETYPE_TEMPLATE_LIST>")+1);
            found = temp.find("<SERVICETYPE_TEMPLATE_LIST>");
         }
         if(0 == strcmp(g_ConObj.m_InstanceSp_DB.c_str(),"INST"))
            /* EXEC SQL INSERT INTO HLR_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CONFIG_VALUES (ENTITY_NAME,PARAM_\
ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYP\
E) values (:b0,:b1,:b2,:b3,'OS',to_date(:b4,'mm/dd/yyyy hh24:mi:ss'),:b5)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )5430;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[2] = (unsigned long )20;
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[3] = (unsigned long )10;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[4] = (unsigned long )102;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[5] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}




         /* EXEC SQL COMMIT; */ 

{
         struct sqlexd sqlstm;
         sqlstm.sqlvsn = 12;
         sqlstm.arrsiz = 8;
         sqlstm.sqladtp = &sqladt;
         sqlstm.sqltdsp = &sqltds;
         sqlstm.iters = (unsigned int  )1;
         sqlstm.offset = (unsigned int  )5469;
         sqlstm.cud = sqlcud0;
         sqlstm.sqlest = (unsigned char  *)&sqlca;
         sqlstm.sqlety = (unsigned short)256;
         sqlstm.occurs = (unsigned int  )0;
         sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
         if (sqlca.sqlcode < 0) goto sqlerr;
}


      }
      else if(first == 258)
      {
         Param_ID = first;
         int found;
         string temp =  complexMap.find(first)->second; 
         string searchFora ("<CODE_");    
         found = temp.find( searchFora );
         if(found == -1)
         {
          Count_Val++;

            /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,54,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENTITY\
_NAME,PARAM_ID,SUB_PARAM_ID,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDA\
TED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,54,:b2,:b3,:b4,'OS',to\
_date(:b5,'mm/dd/yyyy hh24:mi:ss'),:b6)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )5484;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)&Count_Val;
            sqlstm.sqhstl[2] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[3] = (unsigned long )20;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[4] = (unsigned long )10;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[5] = (unsigned long )102;
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqhstv[6] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[6] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[6] = (         int  )0;
            sqlstm.sqindv[6] = (         short *)0;
            sqlstm.sqinds[6] = (         int  )0;
            sqlstm.sqharm[6] = (unsigned long )0;
            sqlstm.sqadto[6] = (unsigned short )0;
            sqlstm.sqtdso[6] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}



        //   ELOG(0,0,"!!!!!!!!!!!!! In ITG_SUCCESS_RESP_CODES  code tag not Found !!!!!!!!!");
         }
         else
         {
            while(found != string::npos) 
            {  
               string replaceBya ("<CODE>");
               temp.replace( found, strlen("<CODE_00>"), replaceBya );
               searchFora = "</CODE_";    
               replaceBya = "</CODE>";
               found = temp.find( searchFora );
               temp.replace( found,strlen("</CODE_00>"), replaceBya );
               string searchFora ("<CODE_");    
               found = temp.find( searchFora );
            }
            found = temp.find("<CODE>");
            while(found != string::npos)
            {
               int fir = temp.find("<CODE>")+strlen("CODE>")+1;
               int last =temp.find("</CODE>");
               string value1 = temp.substr(fir,last-fir);
               Param_ID = first ;
               strcpy(Value,value1.c_str());
               Count_Val++;
               /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,54,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
               struct sqlexd sqlstm;
               sqlstm.sqlvsn = 12;
               sqlstm.arrsiz = 8;
               sqlstm.sqladtp = &sqladt;
               sqlstm.sqltdsp = &sqltds;
               sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENT\
ITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING\
_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,54,:b2,\
:b3,:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
               sqlstm.iters = (unsigned int  )1;
               sqlstm.offset = (unsigned int  )5527;
               sqlstm.cud = sqlcud0;
               sqlstm.sqlest = (unsigned char  *)&sqlca;
               sqlstm.sqlety = (unsigned short)256;
               sqlstm.occurs = (unsigned int  )0;
               sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
               sqlstm.sqhstl[0] = (unsigned long )20;
               sqlstm.sqhsts[0] = (         int  )0;
               sqlstm.sqindv[0] = (         short *)0;
               sqlstm.sqinds[0] = (         int  )0;
               sqlstm.sqharm[0] = (unsigned long )0;
               sqlstm.sqadto[0] = (unsigned short )0;
               sqlstm.sqtdso[0] = (unsigned short )0;
               sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
               sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[1] = (         int  )0;
               sqlstm.sqindv[1] = (         short *)0;
               sqlstm.sqinds[1] = (         int  )0;
               sqlstm.sqharm[1] = (unsigned long )0;
               sqlstm.sqadto[1] = (unsigned short )0;
               sqlstm.sqtdso[1] = (unsigned short )0;
               sqlstm.sqhstv[2] = (unsigned char  *)Value;
               sqlstm.sqhstl[2] = (unsigned long )100000;
               sqlstm.sqhsts[2] = (         int  )0;
               sqlstm.sqindv[2] = (         short *)0;
               sqlstm.sqinds[2] = (         int  )0;
               sqlstm.sqharm[2] = (unsigned long )0;
               sqlstm.sqadto[2] = (unsigned short )0;
               sqlstm.sqtdso[2] = (unsigned short )0;
               sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
               sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[3] = (         int  )0;
               sqlstm.sqindv[3] = (         short *)0;
               sqlstm.sqinds[3] = (         int  )0;
               sqlstm.sqharm[3] = (unsigned long )0;
               sqlstm.sqadto[3] = (unsigned short )0;
               sqlstm.sqtdso[3] = (unsigned short )0;
               sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
               sqlstm.sqhstl[4] = (unsigned long )20;
               sqlstm.sqhsts[4] = (         int  )0;
               sqlstm.sqindv[4] = (         short *)0;
               sqlstm.sqinds[4] = (         int  )0;
               sqlstm.sqharm[4] = (unsigned long )0;
               sqlstm.sqadto[4] = (unsigned short )0;
               sqlstm.sqtdso[4] = (unsigned short )0;
               sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
               sqlstm.sqhstl[5] = (unsigned long )10;
               sqlstm.sqhsts[5] = (         int  )0;
               sqlstm.sqindv[5] = (         short *)0;
               sqlstm.sqinds[5] = (         int  )0;
               sqlstm.sqharm[5] = (unsigned long )0;
               sqlstm.sqadto[5] = (unsigned short )0;
               sqlstm.sqtdso[5] = (unsigned short )0;
               sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
               sqlstm.sqhstl[6] = (unsigned long )102;
               sqlstm.sqhsts[6] = (         int  )0;
               sqlstm.sqindv[6] = (         short *)0;
               sqlstm.sqinds[6] = (         int  )0;
               sqlstm.sqharm[6] = (unsigned long )0;
               sqlstm.sqadto[6] = (unsigned short )0;
               sqlstm.sqtdso[6] = (unsigned short )0;
               sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
               sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[7] = (         int  )0;
               sqlstm.sqindv[7] = (         short *)0;
               sqlstm.sqinds[7] = (         int  )0;
               sqlstm.sqharm[7] = (unsigned long )0;
               sqlstm.sqadto[7] = (unsigned short )0;
               sqlstm.sqtdso[7] = (unsigned short )0;
               sqlstm.sqphsv = sqlstm.sqhstv;
               sqlstm.sqphsl = sqlstm.sqhstl;
               sqlstm.sqphss = sqlstm.sqhsts;
               sqlstm.sqpind = sqlstm.sqindv;
               sqlstm.sqpins = sqlstm.sqinds;
               sqlstm.sqparm = sqlstm.sqharm;
               sqlstm.sqparc = sqlstm.sqharc;
               sqlstm.sqpadto = sqlstm.sqadto;
               sqlstm.sqptdso = sqlstm.sqtdso;
               sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
               if (sqlca.sqlcode < 0) goto sqlerr;
}


               temp.erase(temp.find("<CODE>"),temp.find("</CODE>")+strlen("/CODE>")- temp.find("<CODE>")+1);
               found = temp.find("<CODE>");
            }
         }
         if(0 == strcmp(g_ConObj.m_InstanceSp_DB.c_str(),"INST"))
            /* EXEC SQL INSERT INTO HLR_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CONFIG_VALUES (ENTITY_NAME,PARAM_\
ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYP\
E) values (:b0,:b1,:b2,:b3,'OS',to_date(:b4,'mm/dd/yyyy hh24:mi:ss'),:b5)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )5574;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[2] = (unsigned long )20;
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[3] = (unsigned long )10;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[4] = (unsigned long )102;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[5] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}




         /* EXEC SQL COMMIT; */ 

{
         struct sqlexd sqlstm;
         sqlstm.sqlvsn = 12;
         sqlstm.arrsiz = 8;
         sqlstm.sqladtp = &sqladt;
         sqlstm.sqltdsp = &sqltds;
         sqlstm.iters = (unsigned int  )1;
         sqlstm.offset = (unsigned int  )5613;
         sqlstm.cud = sqlcud0;
         sqlstm.sqlest = (unsigned char  *)&sqlca;
         sqlstm.sqlety = (unsigned short)256;
         sqlstm.occurs = (unsigned int  )0;
         sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
         if (sqlca.sqlcode < 0) goto sqlerr;
}


      }
      else if(first == 257)
      {
         Param_ID = first;
         int found; 

         string HLR_NETWORK = (string)g_ConObj.m_ModuleMap.find(1)->second;

         string searchFora ("<NETWORK_");    

         found = HLR_NETWORK.find( searchFora );


         while(found != string::npos) 
         {  

            string replaceBya ("<NETWORK>");
            HLR_NETWORK.replace( found, strlen("<NETWORK_00>"), replaceBya );
            searchFora = "</NETWORK_";    
            replaceBya = "</NETWORK>";
            found = HLR_NETWORK.find( searchFora );

            HLR_NETWORK.replace( found,strlen("</NETWORK_00>"), replaceBya );
            string searchFora ("<NETWORK_");    
            found = HLR_NETWORK.find( searchFora );
         }


         string temp =  complexMap.find(first)->second; 
         searchFora = "<NETWORK_";    
         found = temp.find( searchFora );
         if(found == -1)
         {
            ELOG(0,0,"!!!!!!!!!!!!! NETWORK tag not Found in ITG_NETWORK_MAPPING_LIST !!!!!!!!!"); 
         }
         while(found != string::npos) 
         {  
            string replaceBya ("<NETWORK>");
            temp.replace( found, strlen("<NETWORK_00>"), replaceBya );
            searchFora = "</NETWORK_";    
            replaceBya = "</NETWORK>";
            found = temp.find( searchFora );
            temp.replace( found,strlen("</NETWORK_00>"), replaceBya );
            string searchFora ("<NETWORK_");    
            found = temp.find( searchFora );
         }



         found = HLR_NETWORK.find("<NETWORK>");
         while(found != string::npos)
         {
            int fir = HLR_NETWORK.find("<NETWORK>")+strlen("NETWORK>")+1;
            int last =HLR_NETWORK.find("</NETWORK>");
            string value1 = HLR_NETWORK.substr(fir,last-fir);
            HLR_NETWORK.erase(HLR_NETWORK.find("<NETWORK>"),HLR_NETWORK.find("</NETWORK>")+strlen("/NETWORK>")- HLR_NETWORK.find("<NETWORK>")+1);


            found = temp.find("<NETWORK>");

            fir = temp.find("<NETWORK>")+strlen("NETWORK>")+1;
            last =temp.find("</NETWORK>");
            string value2 = temp.substr(fir,last-fir);
            string temp1 = Parser::getValue(temp,"FLAG");
            Count_Val++;

            strcpy(Value,value1.c_str());
            //               if(0 != strcmp(g_ConObj.m_InstanceSp_DB.c_str(),"INST"))
            /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,50,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENTITY\
_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PO\
RT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,50,:b2,:b3\
,:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )5628;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)Value;
            sqlstm.sqhstl[2] = (unsigned long )100000;
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
            sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[4] = (unsigned long )20;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[5] = (unsigned long )10;
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[6] = (unsigned long )102;
            sqlstm.sqhsts[6] = (         int  )0;
            sqlstm.sqindv[6] = (         short *)0;
            sqlstm.sqinds[6] = (         int  )0;
            sqlstm.sqharm[6] = (unsigned long )0;
            sqlstm.sqadto[6] = (unsigned short )0;
            sqlstm.sqtdso[6] = (unsigned short )0;
            sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[7] = (         int  )0;
            sqlstm.sqindv[7] = (         short *)0;
            sqlstm.sqinds[7] = (         int  )0;
            sqlstm.sqharm[7] = (unsigned long )0;
            sqlstm.sqadto[7] = (unsigned short )0;
            sqlstm.sqtdso[7] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}




            strcpy(Value,temp1.c_str());

            /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,51,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENTITY\
_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PO\
RT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,51,:b2,:b3\
,:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )5675;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)Value;
            sqlstm.sqhstl[2] = (unsigned long )100000;
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
            sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[4] = (unsigned long )20;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[5] = (unsigned long )10;
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[6] = (unsigned long )102;
            sqlstm.sqhsts[6] = (         int  )0;
            sqlstm.sqindv[6] = (         short *)0;
            sqlstm.sqinds[6] = (         int  )0;
            sqlstm.sqharm[6] = (unsigned long )0;
            sqlstm.sqadto[6] = (unsigned short )0;
            sqlstm.sqtdso[6] = (unsigned short )0;
            sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[7] = (         int  )0;
            sqlstm.sqindv[7] = (         short *)0;
            sqlstm.sqinds[7] = (         int  )0;
            sqlstm.sqharm[7] = (unsigned long )0;
            sqlstm.sqadto[7] = (unsigned short )0;
            sqlstm.sqtdso[7] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}



            temp1 = Parser::getValue(temp,"ENTITY_NAME");
            if(0 == temp1.size())
            {
               ELOG(0,0,"ENTITY_NAME Tag not found in ITG_NETWORK_MAPPING_LIST");
            }
            else
            {
               strcpy(Value,temp1.c_str());
               /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,52,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
               struct sqlexd sqlstm;
               sqlstm.sqlvsn = 12;
               sqlstm.arrsiz = 8;
               sqlstm.sqladtp = &sqladt;
               sqlstm.sqltdsp = &sqltds;
               sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENT\
ITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING\
_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,52,:b2,\
:b3,:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
               sqlstm.iters = (unsigned int  )1;
               sqlstm.offset = (unsigned int  )5722;
               sqlstm.cud = sqlcud0;
               sqlstm.sqlest = (unsigned char  *)&sqlca;
               sqlstm.sqlety = (unsigned short)256;
               sqlstm.occurs = (unsigned int  )0;
               sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
               sqlstm.sqhstl[0] = (unsigned long )20;
               sqlstm.sqhsts[0] = (         int  )0;
               sqlstm.sqindv[0] = (         short *)0;
               sqlstm.sqinds[0] = (         int  )0;
               sqlstm.sqharm[0] = (unsigned long )0;
               sqlstm.sqadto[0] = (unsigned short )0;
               sqlstm.sqtdso[0] = (unsigned short )0;
               sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
               sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[1] = (         int  )0;
               sqlstm.sqindv[1] = (         short *)0;
               sqlstm.sqinds[1] = (         int  )0;
               sqlstm.sqharm[1] = (unsigned long )0;
               sqlstm.sqadto[1] = (unsigned short )0;
               sqlstm.sqtdso[1] = (unsigned short )0;
               sqlstm.sqhstv[2] = (unsigned char  *)Value;
               sqlstm.sqhstl[2] = (unsigned long )100000;
               sqlstm.sqhsts[2] = (         int  )0;
               sqlstm.sqindv[2] = (         short *)0;
               sqlstm.sqinds[2] = (         int  )0;
               sqlstm.sqharm[2] = (unsigned long )0;
               sqlstm.sqadto[2] = (unsigned short )0;
               sqlstm.sqtdso[2] = (unsigned short )0;
               sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
               sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[3] = (         int  )0;
               sqlstm.sqindv[3] = (         short *)0;
               sqlstm.sqinds[3] = (         int  )0;
               sqlstm.sqharm[3] = (unsigned long )0;
               sqlstm.sqadto[3] = (unsigned short )0;
               sqlstm.sqtdso[3] = (unsigned short )0;
               sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
               sqlstm.sqhstl[4] = (unsigned long )20;
               sqlstm.sqhsts[4] = (         int  )0;
               sqlstm.sqindv[4] = (         short *)0;
               sqlstm.sqinds[4] = (         int  )0;
               sqlstm.sqharm[4] = (unsigned long )0;
               sqlstm.sqadto[4] = (unsigned short )0;
               sqlstm.sqtdso[4] = (unsigned short )0;
               sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
               sqlstm.sqhstl[5] = (unsigned long )10;
               sqlstm.sqhsts[5] = (         int  )0;
               sqlstm.sqindv[5] = (         short *)0;
               sqlstm.sqinds[5] = (         int  )0;
               sqlstm.sqharm[5] = (unsigned long )0;
               sqlstm.sqadto[5] = (unsigned short )0;
               sqlstm.sqtdso[5] = (unsigned short )0;
               sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
               sqlstm.sqhstl[6] = (unsigned long )102;
               sqlstm.sqhsts[6] = (         int  )0;
               sqlstm.sqindv[6] = (         short *)0;
               sqlstm.sqinds[6] = (         int  )0;
               sqlstm.sqharm[6] = (unsigned long )0;
               sqlstm.sqadto[6] = (unsigned short )0;
               sqlstm.sqtdso[6] = (unsigned short )0;
               sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
               sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[7] = (         int  )0;
               sqlstm.sqindv[7] = (         short *)0;
               sqlstm.sqinds[7] = (         int  )0;
               sqlstm.sqharm[7] = (unsigned long )0;
               sqlstm.sqadto[7] = (unsigned short )0;
               sqlstm.sqtdso[7] = (unsigned short )0;
               sqlstm.sqphsv = sqlstm.sqhstv;
               sqlstm.sqphsl = sqlstm.sqhstl;
               sqlstm.sqphss = sqlstm.sqhsts;
               sqlstm.sqpind = sqlstm.sqindv;
               sqlstm.sqpins = sqlstm.sqinds;
               sqlstm.sqparm = sqlstm.sqharm;
               sqlstm.sqparc = sqlstm.sqharc;
               sqlstm.sqpadto = sqlstm.sqadto;
               sqlstm.sqptdso = sqlstm.sqtdso;
               sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
               if (sqlca.sqlcode < 0) goto sqlerr;
}


            }
            temp1 = Parser::getValue(temp,"PROV_ACTIONS_TYPE");
            if (0 == temp1.size())
            {
               ELOG(0,0,"PROV_ACTIONS_TYPE Tag not found in ITG_NETWORK_MAPPING_LIST");
            }
            else
            {
               strcpy(Value,temp1.c_str());
               /* EXEC SQL INSERT INTO HLR_CMPLX_PARAM_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,53,:Value,:Count_Val,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
               struct sqlexd sqlstm;
               sqlstm.sqlvsn = 12;
               sqlstm.arrsiz = 8;
               sqlstm.sqladtp = &sqladt;
               sqlstm.sqltdsp = &sqltds;
               sqlstm.stmt = "insert into HLR_CMPLX_PARAM_CONFIG_VALUES (ENT\
ITY_NAME,PARAM_ID,SUB_PARAM_ID,PARAM_VALUE,SEQUENCE_ID,IP_ADDRESS,PROVISIONING\
_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE) values (:b0,:b1,53,:b2,\
:b3,:b4,:b5,'OS',to_date(:b6,'mm/dd/yyyy hh24:mi:ss'),:b7)";
               sqlstm.iters = (unsigned int  )1;
               sqlstm.offset = (unsigned int  )5769;
               sqlstm.cud = sqlcud0;
               sqlstm.sqlest = (unsigned char  *)&sqlca;
               sqlstm.sqlety = (unsigned short)256;
               sqlstm.occurs = (unsigned int  )0;
               sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
               sqlstm.sqhstl[0] = (unsigned long )20;
               sqlstm.sqhsts[0] = (         int  )0;
               sqlstm.sqindv[0] = (         short *)0;
               sqlstm.sqinds[0] = (         int  )0;
               sqlstm.sqharm[0] = (unsigned long )0;
               sqlstm.sqadto[0] = (unsigned short )0;
               sqlstm.sqtdso[0] = (unsigned short )0;
               sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
               sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[1] = (         int  )0;
               sqlstm.sqindv[1] = (         short *)0;
               sqlstm.sqinds[1] = (         int  )0;
               sqlstm.sqharm[1] = (unsigned long )0;
               sqlstm.sqadto[1] = (unsigned short )0;
               sqlstm.sqtdso[1] = (unsigned short )0;
               sqlstm.sqhstv[2] = (unsigned char  *)Value;
               sqlstm.sqhstl[2] = (unsigned long )100000;
               sqlstm.sqhsts[2] = (         int  )0;
               sqlstm.sqindv[2] = (         short *)0;
               sqlstm.sqinds[2] = (         int  )0;
               sqlstm.sqharm[2] = (unsigned long )0;
               sqlstm.sqadto[2] = (unsigned short )0;
               sqlstm.sqtdso[2] = (unsigned short )0;
               sqlstm.sqhstv[3] = (unsigned char  *)&Count_Val;
               sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[3] = (         int  )0;
               sqlstm.sqindv[3] = (         short *)0;
               sqlstm.sqinds[3] = (         int  )0;
               sqlstm.sqharm[3] = (unsigned long )0;
               sqlstm.sqadto[3] = (unsigned short )0;
               sqlstm.sqtdso[3] = (unsigned short )0;
               sqlstm.sqhstv[4] = (unsigned char  *)IPaddress;
               sqlstm.sqhstl[4] = (unsigned long )20;
               sqlstm.sqhsts[4] = (         int  )0;
               sqlstm.sqindv[4] = (         short *)0;
               sqlstm.sqinds[4] = (         int  )0;
               sqlstm.sqharm[4] = (unsigned long )0;
               sqlstm.sqadto[4] = (unsigned short )0;
               sqlstm.sqtdso[4] = (unsigned short )0;
               sqlstm.sqhstv[5] = (unsigned char  *)ProvPort;
               sqlstm.sqhstl[5] = (unsigned long )10;
               sqlstm.sqhsts[5] = (         int  )0;
               sqlstm.sqindv[5] = (         short *)0;
               sqlstm.sqinds[5] = (         int  )0;
               sqlstm.sqharm[5] = (unsigned long )0;
               sqlstm.sqadto[5] = (unsigned short )0;
               sqlstm.sqtdso[5] = (unsigned short )0;
               sqlstm.sqhstv[6] = (unsigned char  *)&CharTime;
               sqlstm.sqhstl[6] = (unsigned long )102;
               sqlstm.sqhsts[6] = (         int  )0;
               sqlstm.sqindv[6] = (         short *)0;
               sqlstm.sqinds[6] = (         int  )0;
               sqlstm.sqharm[6] = (unsigned long )0;
               sqlstm.sqadto[6] = (unsigned short )0;
               sqlstm.sqtdso[6] = (unsigned short )0;
               sqlstm.sqhstv[7] = (unsigned char  *)&InstanceType;
               sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
               sqlstm.sqhsts[7] = (         int  )0;
               sqlstm.sqindv[7] = (         short *)0;
               sqlstm.sqinds[7] = (         int  )0;
               sqlstm.sqharm[7] = (unsigned long )0;
               sqlstm.sqadto[7] = (unsigned short )0;
               sqlstm.sqtdso[7] = (unsigned short )0;
               sqlstm.sqphsv = sqlstm.sqhstv;
               sqlstm.sqphsl = sqlstm.sqhstl;
               sqlstm.sqphss = sqlstm.sqhsts;
               sqlstm.sqpind = sqlstm.sqindv;
               sqlstm.sqpins = sqlstm.sqinds;
               sqlstm.sqparm = sqlstm.sqharm;
               sqlstm.sqparc = sqlstm.sqharc;
               sqlstm.sqpadto = sqlstm.sqadto;
               sqlstm.sqptdso = sqlstm.sqtdso;
               sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
               if (sqlca.sqlcode < 0) goto sqlerr;
}


            }

            temp.erase(temp.find("<NETWORK>"),temp.find("</NETWORK>")+strlen("/NETWORK>")- temp.find("<NETWORK>")+1);
            found = temp.find("<NETWORK>");

         }
         if(0 == strcmp(g_ConObj.m_InstanceSp_DB.c_str(),"INST"))
            /* EXEC SQL INSERT INTO HLR_CONFIG_VALUES(ENTITY_NAME,PARAM_ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYPE)VALUES(:EntityName,:Param_ID,:IPaddress,:ProvPort,'OS', to_date(:CharTime, 'mm/dd/yyyy hh24:mi:ss'),:InstanceType); */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 8;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.stmt = "insert into HLR_CONFIG_VALUES (ENTITY_NAME,PARAM_\
ID,IP_ADDRESS,PROVISIONING_PORT,LAST_UPDATED_BY,LAST_UPDATED_DATE,INSTANCE_TYP\
E) values (:b0,:b1,:b2,:b3,'OS',to_date(:b4,'mm/dd/yyyy hh24:mi:ss'),:b5)";
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )5816;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlstm.sqhstv[0] = (unsigned char  *)EntityName;
            sqlstm.sqhstl[0] = (unsigned long )20;
            sqlstm.sqhsts[0] = (         int  )0;
            sqlstm.sqindv[0] = (         short *)0;
            sqlstm.sqinds[0] = (         int  )0;
            sqlstm.sqharm[0] = (unsigned long )0;
            sqlstm.sqadto[0] = (unsigned short )0;
            sqlstm.sqtdso[0] = (unsigned short )0;
            sqlstm.sqhstv[1] = (unsigned char  *)&Param_ID;
            sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[1] = (         int  )0;
            sqlstm.sqindv[1] = (         short *)0;
            sqlstm.sqinds[1] = (         int  )0;
            sqlstm.sqharm[1] = (unsigned long )0;
            sqlstm.sqadto[1] = (unsigned short )0;
            sqlstm.sqtdso[1] = (unsigned short )0;
            sqlstm.sqhstv[2] = (unsigned char  *)IPaddress;
            sqlstm.sqhstl[2] = (unsigned long )20;
            sqlstm.sqhsts[2] = (         int  )0;
            sqlstm.sqindv[2] = (         short *)0;
            sqlstm.sqinds[2] = (         int  )0;
            sqlstm.sqharm[2] = (unsigned long )0;
            sqlstm.sqadto[2] = (unsigned short )0;
            sqlstm.sqtdso[2] = (unsigned short )0;
            sqlstm.sqhstv[3] = (unsigned char  *)ProvPort;
            sqlstm.sqhstl[3] = (unsigned long )10;
            sqlstm.sqhsts[3] = (         int  )0;
            sqlstm.sqindv[3] = (         short *)0;
            sqlstm.sqinds[3] = (         int  )0;
            sqlstm.sqharm[3] = (unsigned long )0;
            sqlstm.sqadto[3] = (unsigned short )0;
            sqlstm.sqtdso[3] = (unsigned short )0;
            sqlstm.sqhstv[4] = (unsigned char  *)&CharTime;
            sqlstm.sqhstl[4] = (unsigned long )102;
            sqlstm.sqhsts[4] = (         int  )0;
            sqlstm.sqindv[4] = (         short *)0;
            sqlstm.sqinds[4] = (         int  )0;
            sqlstm.sqharm[4] = (unsigned long )0;
            sqlstm.sqadto[4] = (unsigned short )0;
            sqlstm.sqtdso[4] = (unsigned short )0;
            sqlstm.sqhstv[5] = (unsigned char  *)&InstanceType;
            sqlstm.sqhstl[5] = (unsigned long )sizeof(int);
            sqlstm.sqhsts[5] = (         int  )0;
            sqlstm.sqindv[5] = (         short *)0;
            sqlstm.sqinds[5] = (         int  )0;
            sqlstm.sqharm[5] = (unsigned long )0;
            sqlstm.sqadto[5] = (unsigned short )0;
            sqlstm.sqtdso[5] = (unsigned short )0;
            sqlstm.sqphsv = sqlstm.sqhstv;
            sqlstm.sqphsl = sqlstm.sqhstl;
            sqlstm.sqphss = sqlstm.sqhsts;
            sqlstm.sqpind = sqlstm.sqindv;
            sqlstm.sqpins = sqlstm.sqinds;
            sqlstm.sqparm = sqlstm.sqharm;
            sqlstm.sqparc = sqlstm.sqharc;
            sqlstm.sqpadto = sqlstm.sqadto;
            sqlstm.sqptdso = sqlstm.sqtdso;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) goto sqlerr;
}




         /* EXEC SQL COMMIT; */ 

{
         struct sqlexd sqlstm;
         sqlstm.sqlvsn = 12;
         sqlstm.arrsiz = 8;
         sqlstm.sqladtp = &sqladt;
         sqlstm.sqltdsp = &sqltds;
         sqlstm.iters = (unsigned int  )1;
         sqlstm.offset = (unsigned int  )5855;
         sqlstm.cud = sqlcud0;
         sqlstm.sqlest = (unsigned char  *)&sqlca;
         sqlstm.sqlety = (unsigned short)256;
         sqlstm.occurs = (unsigned int  )0;
         sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
         if (sqlca.sqlcode < 0) goto sqlerr;
}


      }            
      //       EXEC SQL CLOSE Params_cursor1;

   } 
   catch(...)
   {
      ELOG(0,0,"Exception occurred in TagGroup Values");

   }
sqlerr:
   {
      if(sqlca.sqlcode != 0)
         ELOG(0,0,"SQL error received: %d", sqlca.sqlcode);

      if(sqlca.sqlcode == -1405)
      {
         ELOG(0,0,"One of the column values is NULL. Please Check the Configuration");
      }
   }

}

