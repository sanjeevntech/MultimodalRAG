#include "CurrentTime.h"
#include <time.h>
#include <string.h>
#include <pthread.h>

char g_dateString[30];
pthread_mutex_t g_dateStringMutex;
bool g_CurrentTimeObjectInitializedFlag=false;
struct tm *g_timeStruct=NULL;
int    g_dateEpoch=0;

bool initializeCurrentTime()
{
   g_CurrentTimeObjectInitializedFlag=true;
   pthread_mutex_init(&g_dateStringMutex, NULL);
   setCurrentTime();
   return true;
}

void makeTimeStamp(char *p_DateTimeStamp)
{
   char * dateString=NULL;
   struct tm *tm_ptr=NULL;
   time_t l_tim =time(NULL);
   g_dateEpoch = l_tim;
   g_timeStruct = tm_ptr = localtime(&l_tim);
   dateString = asctime(tm_ptr);
   dateString[24] = 0;
   strcpy(p_DateTimeStamp, dateString);
   return;
}

void setCurrentTime()
{
   char l_timestamp[30];
   pthread_mutex_lock(&g_dateStringMutex);
   makeTimeStamp(l_timestamp);
   strcpy(g_dateString, l_timestamp);
   pthread_mutex_unlock(&g_dateStringMutex);
   return;
}

void getCurrentTime(char *p_DateTimeStamp)
{
   if (false == g_CurrentTimeObjectInitializedFlag)
   {
      makeTimeStamp(p_DateTimeStamp);
   }
   else
   {
      pthread_mutex_lock(&g_dateStringMutex);
      strcpy(p_DateTimeStamp, g_dateString);
      pthread_mutex_unlock(&g_dateStringMutex);
   }
   return;
}

