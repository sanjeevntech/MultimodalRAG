#include "ConfigReader.h"
#include "parser.h"
#include <stdio.h>
#include <string.h>
#include "Logger.h"
#include <map>
#include <netdb.h>
#include <DecDbConnStr.h>
extern ConfigReader g_ConObj;
DecDbConnStr g_DecDbConnStr;
using namespace std;
int g_InitialLogMedia = 0;
enum g_RTPS_Module{COMMON=1,RN,MAPR,USSD,RRBS,MBOS,SOTA,DOTA,ESME,SPA,SMTP,DM,HSS,HLR,SMSC,ITG};

enum g_HLR_Module{NG=1,SUBS_PROF,MM,CM,AUC,SI,OAM,GPR,SSM,SMSM,LMM,LM2,LSI,LSM};


char g_selfIpAddress[15 + 1];

char g_dbAlias[200+1];


class NgLogOverride : public LogOverride
{
   public:
      bool override(char p_logLevel, char *p_data);
};

bool NgLogOverride::override(char p_logLevel, char *p_data)
{
   if('\n' == p_data[ strlen(p_data) -1])
   {
      p_data[strlen(p_data) -1] = '\0';
   }
   if(strstr(p_data, "Unable connect to SNMP Agent"))
   {
      return true;
   }
   switch(p_logLevel)
   {
      case 'D':
         printf("\nlog [%s]\n", p_data);
         break;
      case 'E':
         printf("\nlog [%s]\n", p_data);
         break;
      case 'L':
         printf("\nlog [%s]\n", p_data);
         break;
      case 'T':
         printf("\nlog [%s]\n", p_data);
         break;
      case 'W':
         printf("\nlog [%s]\n", p_data);
         break;
      case 'C':
         printf("\nlog [%s]\n", p_data);
         break;
      default:
         printf("\nunable to log: %s", p_data);
         break;
   }
   return true;
}

NgLogOverride *g_nlo;


bool ConfigReader::init(char *p_FilePath)
{
   string xmlFile;
   try
   {
      char l_filepath[200];
      strcpy(l_filepath, p_FilePath);
      if(!strcmp(l_filepath, ""))
      {
         ELOG(0,0,"\nCONFIGURATION FILE NOT FOUND\n");
         return false;
      }

      xmlFile = Parser::readXMLFile(l_filepath);
      if (0 == xmlFile.size())
      {
         ELOG(0,0,"\nNo Configuration File found\n");
         return false;
      }
      memset((char *)m_DataString.c_str(),'\0',m_DataString.length());  
      m_DataString = xmlFile;
      return true;

   }
   catch(...)
   {
      cout<<"[ERROR]: Failed to read from configuration file."<<endl;
      return false;
   }
}

void getIpAddress(char *p_ipAddress)
{
   int x, ip_len = 16;
   char * str = NULL, * ip = NULL;
   struct hostent * hent = NULL;
   char l_name[51];
   memset(l_name, '\0', 51);
   size_t l_nameLength=0;
   gethostname(l_name, 50);
   hent = gethostbyname(l_name);
   str = hent -> h_addr_list[0];
   x = (*str < 0) ? (256 + *str) : *str;
   sprintf(p_ipAddress, "%d",x); str++;
   x = (*str < 0) ? (256 + *str) : *str;
   sprintf(p_ipAddress, "%s.%d",p_ipAddress, x); str++;
   x = (*str < 0) ? (256 + *str) : *str;
   sprintf(p_ipAddress, "%s.%d",p_ipAddress, x); str++;
   x = (*str < 0) ? (256 + *str) : *str;
   sprintf(p_ipAddress, "%s.%d%c",p_ipAddress, x, 0x00);
   return;
}

bool ConfigReader::configureTag(char *p_instr,char* p_outstr)
{
   char l_temp[50+1];
   char l_temp1[50+1];
   memset(l_temp,'\0',sizeof(l_temp));
   memset(l_temp1,'\0',sizeof(l_temp1));
   int l_count=0;
   char *l_ptr=NULL;
   while(l_count < (int)strlen(p_instr))
   {
      if(p_instr[l_count] == '>')
      {
         sprintf(l_temp1,"</%s>",l_temp);
         l_ptr =strstr(p_instr,l_temp1);
         if(NULL !=l_ptr)
         {
            strcpy(p_outstr,l_temp);
            return true;
         }
         else
            return false;
      }
      else
      {
         strncpy(l_temp,p_instr+1,l_count);
         l_count =l_count+1;
      }
   }
   return true;
}

bool ConfigReader::readInteger(string parent,string child,int &ConfigValue,int min,int max)
{
   string temp = readValue (parent, child);

   if (0 == temp.size())
   {
      char l_tag[50+1];
      memset(l_tag, '\0', sizeof(l_tag));
      configureTag((char*)parent.c_str(), l_tag);
      printf("\nConfiguration Value %s is not found in %s tag\n", child.c_str(), l_tag);
      return false;
   }
   char *l_tempChar = (char*)(temp.c_str());
   for (unsigned int l_i=0; l_i<temp.size(); l_i++)
   {
      if ( (l_tempChar[l_i] < '0')  || (l_tempChar[l_i] > '9') )
      {
         if(l_tempChar[0] != '-')
         {
            printf("\nConfiguration Value %s is not found numeric  [%c]\n", child.c_str(), l_tempChar[l_i]);
            return false;
         }
      }
   }
   ConfigValue  = atoi(temp.c_str());
   if (min > ConfigValue  || max < ConfigValue)
   {
      printf("\nConfiguration Value from (%s) %s should be between %d and %d ", parent.c_str(), child.c_str(), min, max);
      return false;
   }
   return true;
}

bool ConfigReader::readString(string  p_parent, string p_child,  char  *p_ConfigValue ,unsigned int p_min, unsigned int p_max)
{
   string temp = readValue (p_parent, p_child);
   if(p_min > temp.size()|| p_max < temp.size())
   {
      printf("\nInvalid %s value length. Should be between %d and %d ", p_child.c_str(), p_min, p_max);
      return false;
   }
   strcpy((char *)p_ConfigValue , temp.c_str());
   return true;
}

bool ConfigReader::readString(string  p_parent, string p_child,  string& p_ConfigValue ,unsigned int p_min, unsigned int p_max)
{
   p_ConfigValue = readValue (p_parent, p_child);
   if(p_min > p_ConfigValue.size()|| p_max < p_ConfigValue.size())
   {
      printf("\nInvalid %s value length. Should be between %d and %d ", p_child.c_str(), p_min, p_max);
      return false;
   }
   return true;
}



bool ConfigReader::readLoggerData()
{
   string logger=Parser::getChildString(m_DataString,"LOGGER");
   if (0 == logger.size())
   {
      printf("\nLOGGER tag is not found\n");
      return false;
   }
   string temp = readValue(logger, "LOG_LEVEL");
   if (1 == temp.size())
   {
      char tempChar = temp[0];
      switch (tempChar)
      {
         case 'D':
         case 'd':
            m_LogLevel = LOG_LEVEL_DEBUG;
            break;

         case 'T':
         case 't':
            m_LogLevel = LOG_LEVEL_TRACE;
            break;

         case 'L':
         case 'l':
            m_LogLevel = LOG_LEVEL_LOAD;
            break;

         case 'W':
         case 'w':
            m_LogLevel = LOG_LEVEL_WARNING;
            break;

         case 'C':
         case 'c':
            m_LogLevel = LOG_LEVEL_CRITICAL;
            break;

         case 'E':
         case 'e':
            m_LogLevel = LOG_LEVEL_ERROR;
            break;

         default:
            printf("\nInvalid Log Level Type: It should be either of D, T, W, C or E");
            return false;
            break;
      }
   }
   else
   {
      printf("\nInvalid Log Level: %s", temp.c_str());
      return false;
   }

   temp = readValue(logger, "LOG_MEDIA");
   if (1 == temp.size())
   {
      char tempChar = temp[0];
      switch (tempChar)
      {
         case 'C':
         case 'c':
            m_LogMedia = LOG_MEDIA_CONSOLE;
            break;

         case 'F':
         case 'f':
            {
               m_LogMedia = LOG_MEDIA_FILE;

               string l_LOG_WRITING_MECHANISM;
               l_LOG_WRITING_MECHANISM =  readValue(logger, "LOG_FILE_WRITING_MODE");

               if (1 == l_LOG_WRITING_MECHANISM.size())
               {
                  char l_tempchar  = l_LOG_WRITING_MECHANISM[0];
                  switch (l_tempchar)
                  {
                     case 'N':
                        {
                           m_LogFileRotatingType = (ELogRotateType)LOG_ROTATE_TYPE_FALSE;
                           if( false == readInteger(logger, "LOG_ROTATE_MAX_FILES", 
                                    m_LogFileMaxFiles, 10, 999999))
                           {
                              printf("\nLog Rotate Max files is not configured");
                           }
                        }
                        break;

                     case 'R':
                        {
                           m_LogFileRotatingType =(ELogRotateType) LOG_ROTATE_TYPE_TRUE;
                           if( false == readInteger(logger, "LOG_ROTATE_MAX_FILES", 
                                    m_LogFileMaxFiles, 10, 999999))
                           {
                              printf("\nLog Rotate Max files should be between 10 and 999999");
                              return false;
                           }
                        }
                        break;

                     default:
                        {
                           printf("\nLOG_FILE_WRITING_MODE should be either N or R");
                           return false;
                        }
                        break;
                  }
               }
               else
               {
                  printf("\nLOG_FILE_WRITING_MODE is not present");
                  return false;
               }
            }
            break;

         default:
            printf("\nInvalid Log Media Type: It should be either of F or C");
            return false;
            break;
      }

   }
   else
   {
      printf("\nInvalid Log Media: %s", temp.c_str());
      return false;
   }
   //   g_InitialLogMedia=m_LogMedia;

   if (false == readString(logger, "FILE_PATH", m_LogfilePath,1,100))
   {
      printf("\nInvalid FILE_PATH in LOGGER");
      return false;
   }

   if (false == readString(logger, "FILE_PREFIX", m_LogPrefix,1,20))
   {
      printf("\nInvalid FILE_PREFIX in LOGGER");
      return false;
   }

   int l_LogMaxSize=0;
   if( false == readInteger(logger, "MAX_FILE_SIZE", l_LogMaxSize, 10000, 100*1024*1024))
   {
      ELOG(0,1,"Log File Size should be between 10000 bytes and 100 MB");
      return false;
   }

   m_LogMaxsize=l_LogMaxSize;

   if(LOG_MEDIA_FILE == m_LogMedia)
   {
      temp = readValue(logger, "FILE_WRITING_MECHANISM");
      if(1 != temp.size())
      {
         printf("\nFILE_WRITING_MECHANISM should be either 'I'mmediate or 'B'uffered");
         return false;
      }

      if( (temp[0] != 'B') && (temp[0] != 'I'))
      {
         printf("\nFILE_WRITING_MECHANISM [%c] should be either 'I'mmediate or 'B'uffered", temp[0]);
         return false;
      }
      m_logFlag = temp[0];
   }

   if (false == readString(m_DataString, "DATABASE_ALIAS", m_dbAlias,1,200))
   {
      printf("\nInvalid DATABASE_ALIAS in Configuration");
      return false;
   }
   printf("\nDATABASE_ALIAS [%s]\n", m_dbAlias);

   g_nlo = new NgLogOverride;

   char l_actualDbString[200+1];
   bool l_db_status = g_DecDbConnStr.getActualDbString(m_dbAlias,g_dbAlias,g_nlo);
   if(false == l_db_status)
   {
      printf("\n[%s] alias not found in password.dat\n", m_dbAlias);
      return false;
   }
   m_dbAliasString = (string)g_dbAlias; 

   printf("\nDB string is [%s]\n",  m_dbAliasString.c_str());


  /* if( false == readInteger(m_DataString, "INSTANCE_TYPE", m_instanceType, 1, 2))
   {
      ELOG(0,1,"FLAG Tag Value Should be either 1 or 2");
      return false;
   }*/
   m_instanceType = 2; //RTPS hardcoded



   return true;
}

bool ConfigReader::read_SUBS_PROF_Data()
{


   string l_subs_prof = readValue(m_DataString, "PROF");
   if(l_subs_prof.size() == 0)
   {
      ELOG(0,0,"PROF Tag not found");
      return false; 

   }
   else
   {
      m_ModuleMap.insert(pair<int,string>(SUBS_PROF,l_subs_prof));   
   }

   return true;
}

bool ConfigReader::read_MM_Data()
{
   string l_mm = readValue(m_DataString, "MM");
   if(l_mm.size() == 0)
   {
      ELOG(0,0,"MM Tag not found");
      return false;
   }
   else
   {
      m_ModuleMap.insert(pair<int,string>(MM,l_mm));   
   }
   return true;
}

bool ConfigReader::read_CM_Data()
{
   string l_cm = readValue(m_DataString, "CM");
   if(l_cm.size() == 0)
   {
      ELOG(0,0,"CM Tag not found");
      return false;
   }
   else
   {
      m_ModuleMap.insert(pair<int,string>(CM,l_cm));   
   }
   return true;
}


bool ConfigReader::read_AUC_Data()
{
   string l_auc = readValue(m_DataString, "AUC");
   if(l_auc.size() == 0)
   {
      ELOG(0,0,"AUC Tag not found");
      return false;
   }
   else
   {
      m_ModuleMap.insert(pair<int,string>(AUC,l_auc));   
   }
   return true;
}

bool ConfigReader::read_SI_Data()
{
   string l_si = readValue(m_DataString, "SI");
   if(l_si.size() == 0)
   {
      ELOG(0,0,"SI Tag not found");
      return false;
   }
   else
   {
      m_ModuleMap.insert(pair<int,string>(SI,l_si));   
   }
   return true;
}

bool ConfigReader::read_OAM_Data()
{
   string l_oam = readValue(m_DataString, "OAM");
   if(l_oam.size() == 0)
   {
      ELOG(0,0,"OAM Tag not found");
      return false;
   }
   else
   {
      m_ModuleMap.insert(pair<int,string>(OAM,l_oam));   
   }
   return true;
}

bool ConfigReader::read_GPR_Data()
{
   string l_gpr = readValue(m_DataString, "GPRS");
   if(l_gpr.size() == 0)
   {
      ELOG(0,0,"GPRS Tag not found");
      return false;
   }
   else
   {
      m_ModuleMap.insert(pair<int,string>(GPR,l_gpr));   
   }
   return true;
}

bool ConfigReader::read_SSM_Data()
{
   string l_ssm = readValue(m_DataString, "SSM");
   if(l_ssm.size() == 0)
   {
      ELOG(0,0,"SSM Tag not found");
      return false;
   }
   else
   {
      m_ModuleMap.insert(pair<int,string>(SSM,l_ssm));   
   }
   return true;
}

bool ConfigReader::read_SMSM_Data()
{
   string l_smsm = readValue(m_DataString, "Smsm");
   if(l_smsm.size() == 0)
   {
      ELOG(0,0,"Smsm Tag not found");
      return false;
   }
   else
   {
      m_ModuleMap.insert(pair<int,string>(SMSM,l_smsm));   
   }
   return true;
}

bool ConfigReader::read_LMM_Data()
{
   string l_lmm = readValue(m_DataString, "HSSMM");
   if(l_lmm.size() == 0)
   {
      ELOG(0,0,"HSSMM Tag not found");
      return false;
   }
   else
   {
      m_ModuleMap.insert(pair<int,string>(LMM,l_lmm));   
   }
   return true;
}

bool ConfigReader::read_LM2_Data()
{
   string l_lm2 = readValue(m_DataString, "MM2");
   if(l_lm2.size() == 0)
   {
      ELOG(0,0,"MM2 Tag not found");
      return false;
   }
   else
   {
      m_ModuleMap.insert(pair<int,string>(LM2,l_lm2));   
   }
   return true;
}

bool ConfigReader::read_Rtps_Data1()
{


   string l_COMMON = readValue(m_DataString, "CONFIG");
   if(l_COMMON.size() == 0)
   {
      if(0 != strcmp((g_ConObj.m_InstanceSp_DB).c_str(),"INST"))
      {
         ELOG(0,0,"CONFIG Tag not found");
         return false;
      }
   }
   else
   {
      m_ModuleMap.insert(pair<int,string>(COMMON,l_COMMON));
   }




   string l_RN = readValue(m_DataString, "RN");
   if(l_RN.size() == 0)
   { 
      if(0 != strcmp((g_ConObj.m_InstanceSp_DB).c_str(),"INST"))
      {
         ELOG(0,0,"RN Tag not found");
         return false;
      }
   }
   else
   {
      m_ModuleMap.insert(pair<int,string>(RN,l_RN));   
   }

   string l_MAPR = readValue(m_DataString, "MAPR");
   if(l_MAPR.size() == 0)
   { 
      if(0 != strcmp((g_ConObj.m_InstanceSp_DB).c_str(),"INST"))
      {
         ELOG(0,0,"MAPR Tag not found");
         return false;
      }
   }
   else
   {

      m_ModuleMap.insert(pair<int,string>(MAPR,l_MAPR));   
   }

   string l_USSD = readValue(m_DataString, "USSD");
   if(l_USSD.size() == 0)
   { 
      if(0 != strcmp((g_ConObj.m_InstanceSp_DB).c_str(),"INST"))
      {
         ELOG(0,0,"USSD Tag not found");
         return false;
      }
   }
   else
   {
      m_ModuleMap.insert(pair<int,string>(USSD,l_USSD));   
   }


   string l_RRBS = readValue(m_DataString, "RRBS");
   if(l_RRBS.size() == 0)
   { if(0 != strcmp((g_ConObj.m_InstanceSp_DB).c_str(),"INST"))
      {
         ELOG(0,0,"RRBS Tag not found");
         return false;
      }
   }
   else
   {
      m_ModuleMap.insert(pair<int,string>(RRBS,l_RRBS));   
   }








   string l_MBOS = readValue(m_DataString, "MBOS");
   if(l_MBOS.size() == 0)
   { if(0 != strcmp((g_ConObj.m_InstanceSp_DB).c_str(),"INST"))
      {
         ELOG(0,0,"MBOS Tag not found");
         return false;
      }
   }
   else
   {
      m_ModuleMap.insert(pair<int,string>(MBOS,l_MBOS));   

   }





   string l_SOTA = readValue(m_DataString, "SOTA");
   if(l_SOTA.size() == 0)
   {
      if(0 != strcmp((g_ConObj.m_InstanceSp_DB).c_str(),"INST"))
      {
         ELOG(0,0,"SOTA Tag not found");
         return false;
      }
   }
   else
   {

      m_ModuleMap.insert(pair<int,string>(SOTA,l_SOTA));   
   }



   string l_DOTA = readValue(m_DataString, "DOTA");
   if(l_DOTA.size() == 0)
   { 
      if(0 != strcmp((g_ConObj.m_InstanceSp_DB).c_str(),"INST"))
      {
         ELOG(0,0,"DOTA Tag not found");
         return false;
      }
   }

   else
   {
      m_ModuleMap.insert(pair<int,string>(DOTA,l_DOTA));   
   }


   string l_ESME = readValue(m_DataString, "ESME");
   if(l_ESME.size() == 0)
   { if(0 != strcmp((g_ConObj.m_InstanceSp_DB).c_str(),"INST"))
      {
         ELOG(0,0,"ESME Tag not found");
         return false;
      }
   }
   else
   {
      m_ModuleMap.insert(pair<int,string>(ESME,l_ESME));   
   }

   string l_SPA = readValue(m_DataString, "SPA");
   if(l_SPA.size() == 0)
   { 
      if(0 != strcmp((g_ConObj.m_InstanceSp_DB).c_str(),"INST"))
      {
         ELOG(0,0,"SPA Tag not found");
         return false;
      }
   }
   else
   {
      m_ModuleMap.insert(pair<int,string>(SPA,l_SPA));   
   }


   string l_SMTP = readValue(m_DataString, "SMTP");
   if(l_SMTP.size() == 0)
   { 
      if(0 != strcmp((g_ConObj.m_InstanceSp_DB).c_str(),"INST"))
      {
         ELOG(0,0,"SMTP Tag not found");
         return false;
      }
   }
   else
   {
      m_ModuleMap.insert(pair<int,string>(SMTP,l_SMTP));   
   }

   string l_DM = readValue(m_DataString, "DM");
   if(l_DM.size() == 0)
   { 
      if(0 != strcmp((g_ConObj.m_InstanceSp_DB).c_str(),"INST"))
      {
         ELOG(0,0,"DM Tag not found");
         return false;
      }
   }
   else
   {
      m_ModuleMap.insert(pair<int,string>(DM,l_DM));   
   }

   string l_HSS = readValue(m_DataString, "HSS");
   if(l_HSS.size() == 0)
   {
      if(0 != strcmp((g_ConObj.m_InstanceSp_DB).c_str(),"INST"))
      {
         ELOG(0,0,"HSS Tag not found");
         return false;
      }
   }
   else
   {
      m_ModuleMap.insert(pair<int,string>(HSS,l_HSS));   
   }

   string l_SMSC = readValue(m_DataString, "SMSC");
   if(l_SMSC.size() == 0)
   {
      if(0 != strcmp((g_ConObj.m_InstanceSp_DB).c_str(),"INST"))
      {
         ELOG(0,0,"SMSC Tag not found");
         return false;
      }
   }
   else
   {
      m_ModuleMap.insert(pair<int,string>(SMSC,l_SMSC));   
   }



   string l_HLR = readValue(m_DataString, "HLR");
   if(l_HLR.size() == 0)
   {
      if(0 != strcmp((g_ConObj.m_InstanceSp_DB).c_str(),"INST"))
      {
         ELOG(0,0,"HLR Tag not found");
         return false;
      }
   }
   else
   {
      m_ModuleMap.insert(pair<int,string>(HLR,l_HLR));   
   }

   string l_ITG = readValue(m_DataString, "ITG");
   if(l_ITG.size() == 0)
   {
      if(0 != strcmp((g_ConObj.m_InstanceSp_DB).c_str(),"INST"))
      {
         ELOG(0,0,"ITG Tag not found");
         return false;
      }
   }
   else
   {

      m_ModuleMap.insert(pair<int,string>(ITG,l_ITG));   

   }
   return true;
}





bool ConfigReader::read_Rtps_Data()
{

   
  string l_COMMON = readValue(m_DataString, "CONFIG");
   if(l_COMMON.size() == 0)
   {
      if(0 != strcmp((g_ConObj.m_InstanceSp_DB).c_str(),"INST"))
      {
         ELOG(0,0,"CONFIG Tag not found");
         return false;
      }
   }
   else
   {

      int pst,pend,sst,send;
      string interfaceTHROT = readValue(l_COMMON,"INTERFACE_THROTTLING");

      if(0 != interfaceTHROT.size())
      {
      pst = l_COMMON.find("<INTERFACE_THROTTLING>");
      pend  = l_COMMON.rfind("INTERFACE_THROTTLING>");
      l_COMMON.erase(pst,pend-pst+strlen("INTERFACE_THROTTLING>"));

     


      string newinterfaceTHROT  = "<INTERFACE_THROTTLING_FLAG>"+readValue(interfaceTHROT,"FLAG")+"</INTERFACE_THROTTLING_FLAG>";
      newinterfaceTHROT = newinterfaceTHROT+"<SYSTEM_THROTTLE_TPS>"+readValue(interfaceTHROT,"SYSTEM_THROTTLE_TPS")+"</SYSTEM_THROTTLE_TPS>";
      l_COMMON = l_COMMON + newinterfaceTHROT ;
      }   
   
      m_ModuleMap.insert(pair<int,string>(COMMON,l_COMMON));
   }

  
   
   
   string l_RN = readValue(m_DataString, "RN");
   if(l_RN.size() == 0)
   { 
      if(0 != strcmp((g_ConObj.m_InstanceSp_DB).c_str(),"INST"))
      {
         ELOG(0,0,"RN Tag not found");
         return false;
      }
   }
   else
   {

      m_ModuleMap.insert(pair<int,string>(RN,l_RN));   
   }

   string l_MAPR = readValue(m_DataString, "MAPR");
   if(l_MAPR.size() == 0)
   { 
      if(0 != strcmp((g_ConObj.m_InstanceSp_DB).c_str(),"INST"))
      {
         ELOG(0,0,"MAPR Tag not found");
         return false;
      }
   }
   else
   {
      int l_firstPos = l_MAPR.find("<INSTANCE_");
      if(l_firstPos != string::npos)
      {
      l_MAPR.replace(l_firstPos,0,"<INSTANCES>");
      int l_last_pos = l_MAPR.rfind("</INSTANCE_");
      l_last_pos = l_last_pos + strlen("</INSTANCE_01>");
      l_MAPR.replace(l_last_pos,0,"</INSTANCES>");
      }
    
      m_ModuleMap.insert(pair<int,string>(MAPR,l_MAPR));   
   }

   string l_USSD = readValue(m_DataString, "USSD");
   if(l_USSD.size() == 0)
   { 
      if(0 != strcmp((g_ConObj.m_InstanceSp_DB).c_str(),"INST"))
      {
         ELOG(0,0,"USSD Tag not found");
         return false;
      }
   }
   else
   {
      
      m_ModuleMap.insert(pair<int,string>(USSD,l_USSD));   
   }


   string l_RRBS = readValue(m_DataString, "RRBS");
   if(l_RRBS.size() == 0)
   { if(0 != strcmp((g_ConObj.m_InstanceSp_DB).c_str(),"INST"))
      {
         ELOG(0,0,"RRBS Tag not found");
         return false;
      }
   }
   else
   {
      int pst,pend,sst,send;
      string primary = readValue(l_RRBS,"PRIMARY");
      string secondary = readValue(l_RRBS,"SECONDARY");
      string newprimary,newsecondary;
      if(primary.size() != 0 )
      {
      pst = l_RRBS.find("<PRIMARY>");
      pend  = l_RRBS.rfind("PRIMARY>");
      l_RRBS.erase(pst,pend-pst+strlen("PRIMARY>"));
      newprimary  = "<RRBS_PRIMARY_IP>"+readValue(primary,"RRBS_IP")+"</RRBS_PRIMARY_IP>";
      newprimary = newprimary+"<RRBS_PRIMARY_PORT>"+readValue(primary,"RRBS_PORT")+"</RRBS_PRIMARY_PORT>";
      newprimary = newprimary+"<RRBS_PRIMARY_USERNAME>"+readValue(primary,"RRBS_USER_NAME")+"</RRBS_PRIMARY_USERNAME>";
      newprimary = newprimary+"<RRBS_PRIMARY_PASSWORD>"+readValue(primary,"RRBS_PASSWORD")+"</RRBS_PRIMARY_PASSWORD>";
      
      }
      if(secondary.size() != 0 )
      {
      sst = l_RRBS.find("<SECONDARY>");
      send = l_RRBS.rfind("SECONDARY>");
      l_RRBS.erase(sst,send-sst+strlen("SECONDARY>"));
      newsecondary =  "<RRBS_SECONDARY_IP>"+readValue(secondary,"RRBS_IP")+"</RRBS_SECONDARY_IP>";
      newsecondary =  newsecondary+"<RRBS_SECONDARY_PORT>"+readValue(secondary,"RRBS_PORT")+"</RRBS_SECONDARY_PORT>";
      newsecondary = newsecondary+"<RRBS_SECONDARY_USERNAME>"+readValue(secondary,"RRBS_USER_NAME")+"</RRBS_SECONDARY_USERNAME>";
      newsecondary = newsecondary+"<RRBS_SECONDARY_PASSWORD>"+readValue(secondary,"RRBS_PASSWORD")+"</RRBS_SECONDARY_PASSWORD>";
 
      }
           l_RRBS = l_RRBS + newprimary + newsecondary ;

      m_ModuleMap.insert(pair<int,string>(RRBS,l_RRBS));   
   }








   string l_MBOS = readValue(m_DataString, "MBOS");
   if(l_MBOS.size() == 0)
   { if(0 != strcmp((g_ConObj.m_InstanceSp_DB).c_str(),"INST"))
      {
         ELOG(0,0,"MBOS Tag not found");
         return false;
      }
   }
   else
   {
      int l_firstPos = l_MBOS.find("<NETWORK_");
      if(l_firstPos != string::npos)
      {
      l_MBOS.replace(l_firstPos,0,"<NETWORKS>");
      int l_last_pos = l_MBOS.rfind("</NETWORK_");
      l_last_pos = l_last_pos + strlen("</NETWORK_01>");
      l_MBOS.replace(l_last_pos,0,"</NETWORKS>");
      } 
      m_ModuleMap.insert(pair<int,string>(MBOS,l_MBOS));   

   }





   string l_SOTA = readValue(m_DataString, "SOTA");
   if(l_SOTA.size() == 0)
   {
      if(0 != strcmp((g_ConObj.m_InstanceSp_DB).c_str(),"INST"))
      {
         ELOG(0,0,"SOTA Tag not found");
         return false;
      }
   }
   else
   {

      int sst,send; 
      string  sotaRange = readValue(l_SOTA,"SOTA_IMSI_RANGE");
      if(sotaRange.size() !=  0)
      {
      sst = l_SOTA.find("<FLAG>");  
      send = l_SOTA.rfind("FLAG>");
      l_SOTA.erase(sst,send-sst+strlen("FLAG>"));
      string newSOTA = "<SOTA_IMSI_RANGE_FLAG>"+readValue(sotaRange,"FLAG")+"</SOTA_IMSI_RANGE_FLAG>";
      int pos = l_SOTA.find("SOTA_IMSI_RANGE");
      l_SOTA.replace(pos-1,0,newSOTA);
      }
      m_ModuleMap.insert(pair<int,string>(SOTA,l_SOTA));   
   }

   
   
   string l_DOTA = readValue(m_DataString, "DOTA");
   if(l_DOTA.size() == 0)
   { 
      if(0 != strcmp((g_ConObj.m_InstanceSp_DB).c_str(),"INST"))
      {
         ELOG(0,0,"DOTA Tag not found");
         return false;
      }
   }

   else
   {
      m_ModuleMap.insert(pair<int,string>(DOTA,l_DOTA));   
   }


   string l_ESME = readValue(m_DataString, "ESME");
   if(l_ESME.size() == 0)
   { if(0 != strcmp((g_ConObj.m_InstanceSp_DB).c_str(),"INST"))
      {
         ELOG(0,0,"ESME Tag not found");
         return false;
      }
   }
   else
   {
      m_ModuleMap.insert(pair<int,string>(ESME,l_ESME));   
   }

   string l_SPA = readValue(m_DataString, "SPA");
   if(l_SPA.size() == 0)
   { 
      if(0 != strcmp((g_ConObj.m_InstanceSp_DB).c_str(),"INST"))
      {
         ELOG(0,0,"SPA Tag not found");
         return false;
      }
   }
   else
   {
      int sst,send; 
      string  spaRange = readValue(l_SPA,"SPA_IMSI_RANGE");
      if(spaRange.size() != 0)
      {
      sst = l_SPA.find("<FLAG>");  
      send = l_SPA.rfind("FLAG>");
      l_SPA.erase(sst,send-sst+strlen("FLAG>"));
      string newSPA = "<SPA_IMSI_RANGE_FLAG>"+readValue(spaRange,"FLAG")+"</SPA_IMSI_RANGE_FLAG>";
      int pos = l_SPA.find("SPA_IMSI_RANGE");
      l_SPA.replace(pos-1,0,newSPA);
      }
      m_ModuleMap.insert(pair<int,string>(SPA,l_SPA));   
   }


   string l_SMTP = readValue(m_DataString, "SMTP");
   if(l_SMTP.size() == 0)
   { 
      if(0 != strcmp((g_ConObj.m_InstanceSp_DB).c_str(),"INST"))
      {
         ELOG(0,0,"SMTP Tag not found");
         return false;
      }
   }
   else
   {
      m_ModuleMap.insert(pair<int,string>(SMTP,l_SMTP));   
   }

   string l_DM = readValue(m_DataString, "DM");
   if(l_DM.size() == 0)
   { 
      if(0 != strcmp((g_ConObj.m_InstanceSp_DB).c_str(),"INST"))
      {
         ELOG(0,0,"DM Tag not found");
         return false;
      }
   }
   else
   {
      m_ModuleMap.insert(pair<int,string>(DM,l_DM));   
   }

   string l_HSS = readValue(m_DataString, "HSS");
   if(l_HSS.size() == 0)
   {
      if(0 != strcmp((g_ConObj.m_InstanceSp_DB).c_str(),"INST"))
      {
         ELOG(0,0,"HSS Tag not found");
         return false;
      }
   }
   else
   {
      m_ModuleMap.insert(pair<int,string>(HSS,l_HSS));   
   }

   string l_SMSC = readValue(m_DataString, "SMSC");
   if(l_SMSC.size() == 0)
   {
      if(0 != strcmp((g_ConObj.m_InstanceSp_DB).c_str(),"INST"))
      {
         ELOG(0,0,"SMSC Tag not found");
         return false;
      }
   }
   else
   {
      int pst,pend,sst,send;
      string primary = readValue(l_SMSC,"PRIMARY");
      string secondary = readValue(l_SMSC,"SECONDARY");
      string newprimary,newsecondary;
      if(primary.size() != 0 )
      {
      pst = l_SMSC.find("<PRIMARY>");
      pend  = l_SMSC.rfind("PRIMARY>");
      l_SMSC.erase(pst,pend-pst+strlen("PRIMARY>"));
      newprimary  = "<SMSC_PRIMARY_IP>"+readValue(primary,"SMSC_IP")+"</SMSC_PRIMARY_IP>";
      newprimary = newprimary+"<SMSC_PRIMARY_PORT>"+readValue(primary,"SMSC_PORT")+"</SMSC_PRIMARY_PORT>";
     
      }

      if(secondary.size() != 0 )
      {
      sst = l_SMSC.find("<SECONDARY>");
      send = l_SMSC.rfind("SECONDARY>");
      l_SMSC.erase(sst,send-sst+strlen("SECONDARY>"));
      newsecondary =  "<SMSC_SECONDARY_IP>"+readValue(secondary,"SMSC_IP")+"</SMSC_SECONDARY_IP>";
      newsecondary =  newsecondary+"<SMSC_SECONDARY_PORT>"+readValue(secondary,"SMSC_PORT")+"</SMSC_SECONDARY_PORT>";
      }
      l_SMSC = l_SMSC + newprimary + newsecondary ;

      m_ModuleMap.insert(pair<int,string>(SMSC,l_SMSC));   
   }



   string l_HLR = readValue(m_DataString, "HLR");
   if(l_HLR.size() == 0)
   {
      if(0 != strcmp((g_ConObj.m_InstanceSp_DB).c_str(),"INST"))
      {
         ELOG(0,0,"HLR Tag not found");
         return false;
      }
   }
   else
   {
      m_ModuleMap.insert(pair<int,string>(HLR,l_HLR));   
   }






   string l_ITG = readValue(m_DataString, "ITG");
   if(l_ITG.size() == 0)
   {
      if(0 != strcmp((g_ConObj.m_InstanceSp_DB).c_str(),"INST"))
      {
         ELOG(0,0,"ITG Tag not found");
         return false;
      }
   }
   else
   {


      int l_firstPos = l_ITG.find("<SERVICETYPE_TEMPLATE_LIST>");
      if( l_firstPos != string::npos)
      {
      l_ITG.replace(l_firstPos,0,"<SERVICETYPE_TEMPLATE_LISTS>");
      int l_last_pos = l_ITG.rfind("</SERVICETYPE_TEMPLATE_LIST");
      l_last_pos = l_last_pos + strlen("</SERVICETYPE_TEMPLATE_LIST>");
      l_ITG.replace(l_last_pos,0,"</SERVICETYPE_TEMPLATE_LISTS>");
      }  
      
      
      
      
      int pst,pend,sst,send;
      string primary = readValue(l_ITG,"PRIMARY");
      string secondary = readValue(l_ITG,"SECONDARY");
      string newprimary,newsecondary;
      if(primary.size() != 0 )
      {
      pst = l_ITG.find("<PRIMARY>");
      pend  = l_ITG.rfind("PRIMARY>");
      l_ITG.erase(pst,pend-pst+strlen("PRIMARY>"));
      newprimary  = "<ITG_PRIMARY_IP>"+readValue(primary,"ITG_IP")+"</ITG_PRIMARY_IP>";
      newprimary = newprimary+"<ITG_PRIMARY_PORT>"+readValue(primary,"ITG_PORT")+"</ITG_PRIMARY_PORT>";
      
      }
      if(secondary.size() != 0 )
      {
      sst = l_ITG.find("<SECONDARY>");
      send = l_ITG.rfind("SECONDARY>");
      l_ITG.erase(sst,send-sst+strlen("SECONDARY>"));
      newsecondary =  "<ITG_SECONDARY_IP>"+readValue(secondary,"ITG_IP")+"</ITG_SECONDARY_IP>";
      newsecondary =  newsecondary+"<ITG_SECONDARY_PORT>"+readValue(secondary,"ITG_PORT")+"</ITG_SECONDARY_PORT>";
     
      }
      l_ITG = l_ITG + newprimary + newsecondary ;
      m_ModuleMap.insert(pair<int,string>(ITG,l_ITG));   

   }
   return true;
}




ConfigReader::ConfigReader()
{
}

ConfigReader::~ConfigReader()
{
}
extern ConfigReader g_ConObj;
string ConfigReader::readValue (string parent, string child)
{
   getIpAddress(g_ConObj.g_selfIpAddress);
   string n = Parser::getChildString (parent, child);
   string v = Parser::getValue (n, child);
   bool l_splitParameter=false;
   int l_lengthOfString = v.size();
   if (l_lengthOfString >= 2)
   {
      if ( (v.at(0) == '(') && (v.at(l_lengthOfString-1) != ')'))
      {
         printf("\nno matching end brace\n");
         v="";
         return false;
      }
      if ( (v.at(0) != '(') && (v.at(l_lengthOfString-1) == ')'))
      {
         printf("\nno matching start brace\n");
         v="";
         return false;
      }
      if ( (v.at(0) == '(') && (v.at(l_lengthOfString-1) == ')'))
      {
         printf("\n Splitting into tokens [%s]", (char*)v.c_str());
         string l_toBeTokenized = ";" + v.substr(1, (l_lengthOfString-2)) + ";" ;
         printf("\n Data : [%s]", (char*)l_toBeTokenized.c_str());

         char *ptr1, *ptr2;
         ptr1=ptr2=NULL;
         ptr1 = ptr2 = (char*)l_toBeTokenized.c_str();
         ptr2++;
         int l_totalRequests=0;
         while(*ptr2 != '\0')
         {
            if(';' == *ptr2)
            {
               if(ptr2-ptr1 == 1)
               {
                  printf("\n Breaking from the loop");
                  break;
               }
               else
               {
                  printf("\n finalizing a token");
                  l_totalRequests++;
                  char l_rowidChar[200+1];
                  memset(l_rowidChar, '\0', sizeof(l_rowidChar));
                  strncpy(l_rowidChar,ptr1+1,ptr2-ptr1-1);
                  printf("\n Got a token [%s]", l_rowidChar);

                  ptr1=ptr2;
               }
            }
            ptr2++;
         }

         if (false == l_splitParameter)
         {
            v="";
         }

         else
         {
            //printf("\n Not matching the braces");
         }
      }
   }
   return v;
}

