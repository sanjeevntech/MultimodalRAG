//unsigned  long mMaxFileSize;
//int p_type;
/***************************************************************
File:			Logger.h
***************************************************************/
#ifndef __NG_LOGGER_H
#define __NG_LOGGER_H

#include <stdio.h>
#include <time.h>
#include <string.h>
#include <stdlib.h>
#include <pthread.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdarg.h>
#include <dirent.h>
#include <iostream>
//#include "MessageQueue.h"
using namespace std;


// Logging Mode Constants
#define  LOG_MEDIA_LOWER_LIMIT	1// Define valid lower range for Logging Media
#define  LOG_MEDIA_FILE		      1// File Mode Logging
#define	LOG_MEDIA_CONSOLE	      2// Console Mode Logging
#define	LOG_MEDIA_RTPS  	      3// Forward To RTPS
#define  LOG_MEDIA_UPPER_LIMIT	3// Define valid upper range for Logging Mode


// Logging Level Constants
#define LOG_LEVEL_LOWER_LIMIT	  1// Define valid lower range for Logging Level
#define LOG_LEVEL_ERROR	        1// Only Software Errors to be logged here
#define LOG_LEVEL_CRITICAL	     2// Highest Priority (useful for delivered code) 
#define LOG_LEVEL_WARNING	     3// Unexpected events like aborts
#define LOG_LEVEL_LOAD	        4// Load level (for production)
#define LOG_LEVEL_TRACE	        5// Trace an event
#define LOG_LEVEL_DEBUG		     6// Lowest Priority (useful for debugging purposes)
#define LOG_LEVEL_UPPER_LIMIT	  6// Define valid upper range for Logging Level

// Error Code Defined for initialization routine
#define LOGGER_ERR_LEVEL	      1
#define LOGGER_ERR_MODE		      2
#define LOGGER_ERR_FILE		      3
#define LOGGER_ERR_NEW_CONSOLE	4
#define LOGGER_ERR_SEMAPHORE	   5
#define LOGGER_ERR_BUFFER	      6

// Internal Buffer size 
#define	LOGGER_BUFFER_SIZE	  1048576 // 1M

// Date string len used in log method
#define DATE_STRING_LEN		    27

// mPath maximum string size
#define PATH_MAX_SIZE		      260

// mModuleName maximum string size
#define MODULE_NAME_MAX_SIZE	50

// mModuleName maximum string size
#define LOG_MESSAGE_MAX_SIZE	LOGGER_BUFFER_SIZE - 200	// 2900


//#define MAX_DUMP_LOGGING_SIZE       20971520   // 20MB which is more than (200 lines * 300 per sec * 200 bytes)
#define MAX_DUMP_LOGGING_SIZE         31457280   // 30MB which is more than (500 lines * 300 per sec * 200 bytes)

#define MAX_TRACING_DUMPING_SIZE      2097152   // 2MB 
#define MAX_TDR_DUMPING_SIZE          1048576   // 1MB 

enum ELogRotateType
{
   LOG_ROTATE_TYPE_FALSE,
   LOG_ROTATE_TYPE_TRUE
};

extern pthread_mutex_t      g_WriteLogMutex; //Only for CTDR Obj


class LogWriter
{
   public:
      int                  m_LoggerFileHandle;
      char                 m_LoggerBuffer[LOGGER_BUFFER_SIZE+1];
      unsigned long        m_LoggingMedia;
      char                 m_FileName[200];
      unsigned long        m_MaxFileSize;
      char                 m_ArchivalDirPath[200];
      char                 m_FilePath[200];
      char                 m_ModuleName[200];
      char                 m_FileSuffix[10];
      int                  m_type;
      //MessageQueue         *m_q;
      unsigned long        m_FileSize;
      pthread_mutex_t      m_Mutex;
      int                  m_maxLogDumpingSize;


      //char                 m_arr[2][MAX_DUMP_LOGGING_SIZE+1];
      char                 *m_arr[2];
      short                m_writing_index;
      long                 m_written_length[2];
      ELogRotateType       m_lrt;
      int                  m_maxFiles;
      int                  m_currentFileCount;

      bool getLastFile(char* p_DirName, char *p_fileFormat, char* p_LastFileName);


      void makeFileName(char * mFileNameBuffer, char * mPath, char * mFilePrefix, char *mFileSuffix);

   public:	
      LogWriter();	
      ~LogWriter();	

      bool initialize(unsigned long mLoggingMedia, char * mPath, 
            char * mModuleName,char *pFileSuffix, char * mArchivalDirPath,unsigned long mMaxFileSize, int p_type,
            ELogRotateType p_lrt, int p_maxFiles, int p_MaxLogDumpingSize); 
      bool writeLog(char *p_data, int);
};



class Logger
{
   public:
      unsigned long     m_LoggingThreshold;
      unsigned long     m_LoggingMedia;    
      int               m_type;
      bool              m_initializedFlag;
      LogWriter         m_lw;

      void makeTimeStamp(char *);
      ELogRotateType    m_lrt;
      int               m_maxFiles;

      char              m_LoggerBuffer[LOGGER_BUFFER_SIZE+1];
      char              m_tempLogChar[LOGGER_BUFFER_SIZE+1];
      char              m_expandedLog[LOGGER_BUFFER_SIZE+1];

      va_list           args;

   public:	
      Logger();	
      ~Logger();	

      void setLogLevel(int p_level)
      {
         m_LoggingThreshold=p_level;
      }
      void setLogMedia(int p_media)
      {
         m_lw.m_LoggingMedia=p_media;
      }
      void setLogRotateType(ELogRotateType p_type)
      {
         m_lw.m_lrt=p_type;
      }

      bool initialize(unsigned long mLoggingThreshold, unsigned long mLoggingMedia, char * mPath, 
            char * mModuleName,char *pFileSuffix, char * mArchivalDirPath,unsigned long mMaxFileSize, int p_type,
            ELogRotateType p_lrt, int p_maxFiles, int p_MaxLogDumpingSize); 
      bool log2(unsigned long mLoggingLevel, const char *p_srcFileName, const char *p_funcName,
            int p_LineNumber, int p_UserId, int p_ProviderId, char * mLogMessage, ...);
};

extern void flushLog(Logger *p_log, char *p_data);

// Declare the global Logger class object
extern Logger g_LoggerObj;
extern Logger g_TraceObj; 
//extern bool printHex(char *p_str, char *p_buf, int p_len, char *p_output);
extern bool g_NewFile;
extern char g_title[];
//extern bool g_TracingPresentAtAll;

extern bool g_connectStatus;
extern void exitFunc(int);

#define DLOG(UID, PID, ...)  if(LOG_LEVEL_DEBUG   <= g_LoggerObj.m_LoggingThreshold) { g_LoggerObj.log2(LOG_LEVEL_DEBUG,    __FILE__, __FUNCTION__, __LINE__, UID, PID, __VA_ARGS__);  }  
#define TLOG(UID, PID, ...)  if(LOG_LEVEL_TRACE   <= g_LoggerObj.m_LoggingThreshold) { g_LoggerObj.log2(LOG_LEVEL_TRACE,    __FILE__, __FUNCTION__, __LINE__, UID, PID, __VA_ARGS__);  }  
#define LLOG(UID, PID, ...)  if(LOG_LEVEL_LOAD    <= g_LoggerObj.m_LoggingThreshold) { g_LoggerObj.log2(LOG_LEVEL_LOAD,     __FILE__, __FUNCTION__, __LINE__, UID, PID, __VA_ARGS__);  }  
#define WLOG(UID, PID, ...)  if(LOG_LEVEL_WARNING <= g_LoggerObj.m_LoggingThreshold) { g_LoggerObj.log2(LOG_LEVEL_WARNING,  __FILE__, __FUNCTION__, __LINE__, UID, PID, __VA_ARGS__);  }  
#define CLOG(UID, PID, ...)  if(LOG_LEVEL_CRITICAL<= g_LoggerObj.m_LoggingThreshold) { g_LoggerObj.log2(LOG_LEVEL_CRITICAL, __FILE__, __FUNCTION__, __LINE__, UID, PID, __VA_ARGS__);  }  
#define ELOG(UID, PID, ...)  if(LOG_LEVEL_ERROR   <= g_LoggerObj.m_LoggingThreshold) { printf(__VA_ARGS__); printf("\n"); g_LoggerObj.log2(LOG_LEVEL_ERROR,    __FILE__, __FUNCTION__, __LINE__, UID, PID, __VA_ARGS__); }  
#define MLOG(UID, PID, ...)  {}

#define DLOG_HEX(UID, PID, STRING, HEX_DATA, HEX_LEN)  if(LOG_LEVEL_DEBUG <= g_LoggerObj.m_LoggingThreshold)    { char l_tmpStr[1000+1];  hexToString((unsigned char *)l_tmpStr, 1000, (unsigned char *)(HEX_DATA), HEX_LEN);  char l_full[1200+1]; sprintf(l_full, "%s: %s", STRING, l_tmpStr); g_LoggerObj.log2(LOG_LEVEL_DEBUG, __FILE__, __FUNCTION__, __LINE__, UID, PID, l_full);  }
#define TLOG_HEX(UID, PID, STRING, HEX_DATA, HEX_LEN)  if(LOG_LEVEL_TRACE <= g_LoggerObj.m_LoggingThreshold)    { char l_tmpStr[1000+1];  hexToString((unsigned char *)l_tmpStr, 1000, (unsigned char *)(HEX_DATA), HEX_LEN);  char l_full[1200+1]; sprintf(l_full, "%s: %s", STRING, l_tmpStr); g_LoggerObj.log2(LOG_LEVEL_TRACE, __FILE__, __FUNCTION__, __LINE__, UID, PID, l_full);  } 
#define LLOG_HEX(UID, PID, STRING, HEX_DATA, HEX_LEN)  if(LOG_LEVEL_LOAD <= g_LoggerObj.m_LoggingThreshold)     { char l_tmpStr[1000+1];  hexToString((unsigned char *)l_tmpStr, 1000, (unsigned char *)(HEX_DATA), HEX_LEN);  char l_full[1200+1]; sprintf(l_full, "%s: %s", STRING, l_tmpStr); g_LoggerObj.log2(LOG_LEVEL_TRACE, __FILE__, __FUNCTION__, __LINE__, UID, PID, l_full);  } 
#define WLOG_HEX(UID, PID, STRING, HEX_DATA, HEX_LEN)  if(LOG_LEVEL_WARNING <= g_LoggerObj.m_LoggingThreshold)  { char l_tmpStr[1000+1];  hexToString((unsigned char *)l_tmpStr, 1000, (unsigned char *)(HEX_DATA), HEX_LEN);  char l_full[1200+1]; sprintf(l_full, "%s: %s", STRING, l_tmpStr); g_LoggerObj.log2(LOG_LEVEL_WARNING, __FILE__, __FUNCTION__, __LINE__, UID, PID, l_full);  }
#define CLOG_HEX(UID, PID, STRING, HEX_DATA, HEX_LEN)  if(LOG_LEVEL_CRITICAL <= g_LoggerObj.m_LoggingThreshold) { char l_tmpStr[1000+1];  hexToString((unsigned char *)l_tmpStr, 1000, (unsigned char *)(HEX_DATA), HEX_LEN);  char l_full[1200+1]; sprintf(l_full, "%s: %s", STRING, l_tmpStr); g_LoggerObj.log2(LOG_LEVEL_CRITICAL, __FILE__, __FUNCTION__, __LINE__, UID, PID, l_full);  }
#define ELOG_HEX(UID, PID, STRING, HEX_DATA, HEX_LEN)  if(LOG_LEVEL_ERROR <= g_LoggerObj.m_LoggingThreshold)    { char l_tmpStr[1000+1];  hexToString((unsigned char *)l_tmpStr, 1000, (unsigned char *)(HEX_DATA), HEX_LEN);  char l_full[1200+1]; sprintf(l_full, "%s: %s", STRING, l_tmpStr); g_LoggerObj.log2(LOG_LEVEL_ERROR, __FILE__, __FUNCTION__, __LINE__, UID, PID, l_full);  }


#define TTLOG(UID, PID, ...)  if ( (g_SlCurrentContext != 0) && (0 == PID) && (' ' !=  g_SlCurrentCtxtTraceEnabledFlag)) { g_TraceObj.log2(LOG_LEVEL_TRACE,    __FILE__, __FUNCTION__, __LINE__, UID, PID, __VA_ARGS__); }

#endif	/* __NG_LOGGER_H */
