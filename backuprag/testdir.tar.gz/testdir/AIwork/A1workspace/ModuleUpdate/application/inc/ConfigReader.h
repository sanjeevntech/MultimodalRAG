#ifndef __CONFIG_READER_H
#define __CONFIG_READER_H
#include <iostream>
#include <iostream>
#include <map>
#include <list>
#include <vector>
using namespace std;
class ConfigReader
{
   public:
      ConfigReader();
      virtual ~ConfigReader();

      bool readData(); 
      bool init(char *p_FilePath);
      static bool IsString(char *st);
      static string readValue (string parent, string child);
      static bool configureTag(char *p_instr,char* p_outstr);
      static bool readInteger(string parent,string child,int &ConfigValue,int min,int max);
      static bool readString(string  parent, string child,  char  *ConfigValue ,unsigned int min, unsigned int max);
      static bool readString(string  p_parent, string p_child,  string& p_ConfigValue ,unsigned int p_min, unsigned int p_max);

      
      
      //void getIpAddress(char *p_ipAddress);   
          
      bool readLoggerData();


      bool read_Rtps_Data();
      bool read_Rtps_Data1();

      bool read_SUBS_PROF_Data();
      bool read_MM_Data();
      bool read_CM_Data();
      bool read_AUC_Data();
      bool read_SI_Data();
      bool read_OAM_Data(); 
      bool read_GPR_Data();
      bool read_SSM_Data();
      bool read_SMSM_Data();
      bool read_LMM_Data();
      bool read_LM2_Data();   


      string m_DataString;

      string m_ProvPort;
      int m_LogLevel;
      int m_LogMedia;
      int m_MaxFileSize;
      char  m_LogfilePath[101];
      char  m_LogPrefix[21];
      long  m_LogMaxsize;
      char  m_ArchivalPath[50];
      int   m_LogFileRotatingType;
      int   m_LogFileMaxFiles;
      char  m_logFlag;

      int  m_instanceType;

      string m_IPAddress_DB;
      string m_IPPort_DB;
      string m_EntityName_DB;
      string m_InstanceSp_DB;
      char m_RtpsConfigName[100];
      char m_InstanceConfigName[100];
      


      map<int,string> m_ModuleMap; 
         

string MAPR_INSTANCES,ITG_SERV_TYPE,MBOS_NETWORKS;


      char g_selfIpAddress[15+1];
      int  g_selfIpPort; 


      int m_IsdLen;
      int m_Version;
      int m_CL_Version;
      int m_CL_Invoke_Timer;
      int m_ISD_Invoke_Timer;
      int m_Cancel_Location_Timer;
      int m_Cancel_Location_Retry;
      int m_multiimsierr;
      int m_send_cl;
      int m_send_asc_grps; 
      string m_home_cap_version;
      string m_roam_cap_version;
      int m_MinFreeMsisdnThreshold;
      int m_MsisdnAllocErr;
      int m_GT_Trans;
      int m_Dealloc_Msisdn_On_Fail;
      int m_send_cl_on_isd_failure;
      int m_scpSSN;
      char m_dbAlias[200+1];
      string m_dbAliasString;    

};


#endif 

