#ifndef __CURRENT_TIME_H
#define __CURRENT_TIME_H

extern bool initializeCurrentTime();
extern void makeTimeStamp(char *p_DateTimeStamp);
extern void setCurrentTime();
extern void getCurrentTime(char *p_DateTimeStamp);

extern struct tm *g_timeStruct;
extern int g_dateEpoch;

#endif
