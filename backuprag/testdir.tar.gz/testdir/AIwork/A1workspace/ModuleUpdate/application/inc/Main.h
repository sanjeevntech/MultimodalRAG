#ifndef __MAIN_H 
#define __MAIN_H 


#include <iostream>
#include <map>     
#include <list>    
using namespace std;

map < string,string> g_ErrorMap;          

class Main
{
   public:

      Main();
      virtual ~Main();
};
#endif
