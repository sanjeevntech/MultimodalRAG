#!/usr/bin/bash
PATH=$PATH:/ora10gclnt/product/10.2.0/client/bin
export ORACLE_HOME=/ora10gclnt/product/10.2.0/client
LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/ora10gclnt/product/10.2.0/client/lib
