#include <MySimulator.h>
#include <Logger.h>

#include <DiameterMessages.h>
#include <DiameterConstants.h>

#include <ExtendedServiceCoordinator.h>
#include <ServiceCoordinator.h>

#include <app.h>
#include <diameter/AVP.h>
#include <diameter/s6a_r10/PurgeUE.h>
#include <diameter/s6a_r10/Reset.h>
#include <diameter/base/BaseAVP.h>
//#include <diameter/s6a_r10/S6aAVP.h>

using namespace diameter::base;
using namespace diameter::s6a_r10;


MySimulator::MySimulator()
{

}

MySimulator::~MySimulator()
{

}

bool MySimulator::getMessage(int p_opCode, Msg **p_msgPtr, Msg *p_ReqMsgPtr)
{
   switch(p_opCode)
   {
      case DIAM_COMM_CODE_S6A_S6D_PUR_PUA:
         {
            LLOG(0,0,"selfSimulate: PURGEREQ");

            unsigned int sIdx;
            string sessIdString;
            if(false == g_esc.allocateSession(DIAM_APP_ID_S6A_S6D,
                     sIdx,
                     sessIdString))
            {
               ELOG(0,1,"Unable to allocate a session");
               return false;
            }

            *p_msgPtr = new DiameterMsg((char *)sessIdString.c_str(), DIAM_EVENT_REQUEST, DIAM_COMM_CODE_S6A_S6D_PUR_PUA);
            DiameterMsg *l_test = (DiameterMsg*)(*p_msgPtr);
            l_test->m_commandCode = DIAM_COMM_CODE_S6A_S6D_PUR_PUA;

            //prepare a PUR request
            diameter::s6a_r10::PurgeUERequest *l_purr = new diameter::s6a_r10::PurgeUERequest;
            l_purr->setSessionId(diameter::base::SessionId(diameter::base::SessionId(sessIdString)));
            l_purr->setSessionIndex(sIdx);

            VendorSpecificApplicationId vendorSpecAppId;
            VendorId vendorId(10415);
            vendorSpecAppId.addVendorId(vendorId);
            l_purr->setVendorSpecificApplicationId(vendorSpecAppId);

            AuthSessionState authSessionState(AuthSessionState::NO_STATE_MAINTAINED);
            l_purr->setAuthSessionState(authSessionState);

            OriginHost originHost = diameter::base::OriginHost("originhost");
            l_purr->setOriginHost(originHost);

            OriginRealm originRealm("OriginRealmPurgeReq");
            l_purr->setOriginRealm(originRealm);

            DestinationRealm destinationRealm("DestinationRealmPurgeReq");
            l_purr->setDestinationRealm(destinationRealm);

            DestinationHost destinationHost("DestinationHostPurgeReq");
            l_purr->setDestinationHost(destinationHost);

            //UserName username("100447404002792");
            //UserName username("100447404999999");
            UserName username("11");
            l_purr->setUserName(username);

            SupportedFeatures suppFeatures;
            VendorId vendorIdSup(88888);
            suppFeatures.setVendorId(vendorIdSup);
            FeatureListID featureListId(999);
            suppFeatures.setFeatureListID(featureListId);
            FeatureList featurList(888);
            suppFeatures.setFeatureList(featurList);
            l_purr->addSupportedFeatures(suppFeatures);

            //Route-Record
            RouteRecord m_routerecord("record");
            l_purr->addRouteRecord(m_routerecord);

            //Proxy-Info
            //ProxyInfo m_proxyInfo("xyz");
            //l_purr->addProxyInfo(m_proxyInfo);

            //AVP


            l_test->m_cmd = l_purr;
            l_test->m_allocatedFlag = true;

            diameter::s6a_r10::PurgeUERequest *l_tmp_purr = (diameter::s6a_r10::PurgeUERequest*)(l_test->m_cmd);
            if(NULL != l_tmp_purr)
            {
               ITS_UINT l_idx = l_tmp_purr->getSessionIndex();
               LLOG(0,0,"PURR Session Id: %d", l_idx);
            }
            else
            {
               LLOG(0,0,"NULL");
            }

         }
         break;
#if 1
      case DIAM_COMM_CODE_S6A_S6D_S7A_S7D_RSR_RSA:
         {
            LLOG(0,0,"selfSimulate: RESETANSWER");
            DiameterMsg *l_dm = (DiameterMsg*)p_ReqMsgPtr;
            if( NULL != l_dm->m_cmd)
            {
               LLOG(0,0,"DIAMETER message received");
               diameter::s6a_r10::ResetRequest *l_resetr = (diameter::s6a_r10::ResetRequest*)l_dm->m_cmd;
               diameter::base::SessionId sess= l_resetr->getSessionId();
               ITS_UINT l_idx = l_resetr->getSessionIndex();
               LLOG(0,0,"RESETANSWER Session Id : %d", l_idx);

               *p_msgPtr = new DiameterMsg((char *)l_idx, DIAM_EVENT_ANSWER, DIAM_COMM_CODE_S6A_S6D_S7A_S7D_RSR_RSA);
               DiameterMsg *l_answer = (DiameterMsg*)(*p_msgPtr);

               /*diameter::base::SessionId sess= l_resetr->getSessionId();
               ITS_UINT l_idx = l_resetr->getSessionIndex();
               LLOG(0,0,"RESETANSWER Session Id : %d", l_idx);*/

               diameter::s6a_r10::ResetAnswer *l_reseta = new diameter::s6a_r10::ResetAnswer;
               l_answer->m_cmd = l_reseta;

               const SessionId &sid1 = l_resetr->getSessionId();
               const OriginHost &oh1 = l_resetr->getOriginHost();
               const OriginRealm &or1 = l_resetr->getOriginRealm();
               const AuthSessionState &authSessState = l_resetr->getAuthSessionState();

               l_reseta->setSessionId(sid1);
               l_reseta->setSessionIndex(l_resetr->getSessionIndex());
               l_reseta->setAuthSessionState(authSessState);
               //ResultCode resultCode(ITS_DIA_UNKNOWN_SESSION_ID);
               ResultCode resultCode(2001);
               l_reseta->setResultCode(resultCode);

               ExperimentalResult experimentalResult;
               VendorId vendorId1(10415);
               experimentalResult.setVendorId(vendorId1);

               //opt/product/rgopal/learn/diametriq/IMSDIA-GA-5.1.0/include/dia_defines.h
               //ITS_DIA_SUCCESS -- success -- 2xxx
               //ITS_DIA_AVP_UNSUPPORTED -- Permanent Failures -- 5xxx
               //ITS_DIA_AUTH_REJECTED -- Transient Failures -- 4xxx
               //ITS_DIA_CMD_UNSUPPORTED -- Protocol Errors -- 3xxx
               
               //ExperimentalResultCode experimentalResultCode(ITS_DIA_AVP_UNSUPPORTED);
               ExperimentalResultCode experimentalResultCode(2001);
               experimentalResult.setExperimentalResultCode(experimentalResultCode);
               l_reseta->setExperimentalResult(experimentalResult);

               OriginHost originHost("MyHost");
               l_reseta->setOriginHost(originHost);

               OriginRealm originRealm("MyRealm");
               l_reseta->setOriginRealm(originRealm);
               
               diameter::s6a_r10::ResetRequest *l_tmp_purr = (diameter::s6a_r10::ResetRequest*)(l_answer->m_cmd);
               if(NULL != l_tmp_purr)
               {
                  ITS_UINT l_idx = l_tmp_purr->getSessionIndex();
                  LLOG(0,0,"RESETANSWER Session Id: %d", l_idx);
               }
               else
               {
                  LLOG(0,0,"NULL");
               }


            }
            else
            {
               LLOG(0,0,"NULL *********** ");

            }
         }
         break;
#endif
      default :
         {
            LLOG(0,0,"selfSimulate: Default");
         }
         break;
   }
   return true;
}
