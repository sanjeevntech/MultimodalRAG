#include <CtxtSimulatorResetRequest.h>
#include <stdio.h>
#include <MapMessages.h>
#include <ServiceCoordinator.h>
#include <ExtendedServiceCoordinator.h>
#include <ProvisioningMessages.h>
#include <stdio.h>
#include <Logger.h>
#include <MapMessages.h>
#include <ServiceCoordinator.h>
#include <DbActiveObject.h>
#include <Utilities.h>
#include <ExtendedServiceCoordinator.h>
#include <HlrTdrFiller.h>
#include <TdrData.h>
#include <DiameterConstants.h>
#include <diameter/s6a_r10/Reset.h>
//#include <diameter/s6a_r10/S6aAVP.h>
#include <diameter/base/BaseAVP.h>
#include <DiametriqInterface.h>

using namespace diameter::s6a_r10;

CtxtSimulatorResetRequest::CtxtSimulatorResetRequest()
{
}

CtxtSimulatorResetRequest::~CtxtSimulatorResetRequest()
{
   DLOG(0,0,"CtxtSimulatorResetRequest: dest ");

}

bool CtxtSimulatorResetRequest::startProcessing()
{
   DLOG(0,0,"CtxtSimulatorResetRequest:startProcessing ");

   return true;
}

bool CtxtSimulatorResetRequest::processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag)
{
   DLOG(0,0,"CtxtSimulatorResetRequest:processMessage:Diameter Mssg received ");

   printf("CtxtSimulatorResetRequest:Diameter Mssg received \n ... ");

   MapSpecificMsg *l_specMsg = NULL;

   switch (p_MsgPtr->m_MsgType)
   {
      case MSG_TYPE_MAP:
         {

         }
         break;
      case MSG_TYPE_DIAMETER:
         {
            DiameterMsg *l_dm = (DiameterMsg*)p_MsgPtr;


            if(NULL != l_dm->m_cmd)
            {
               diameter::s6a_r10::ResetRequest resetreq(*(diameter::CommandImpl*)l_dm->m_cmd);
               diameter::s6a_r10::ResetRequest *l_resetreq = &resetreq;
               diameter::base::SessionId sess = l_resetreq->getSessionId();
               unsigned int l_idx = l_resetreq->getSessionIndex();
               LLOG(0,0,"SessionId |%d| ", l_idx);
               diameter::s6a_r10::ResetAnswer *l_resetans  = new diameter::s6a_r10::ResetAnswer;
               DiameterMsg l_answer((char*)sess.value().c_str(), DIAM_EVENT_ANSWER, DIAM_COMM_CODE_S6A_S6D_S7A_S7D_RSR_RSA);
               l_answer.m_cmd = l_resetans;

               const SessionId &sid = l_resetreq->getSessionId();
               const OriginHost &oh = l_resetreq->getOriginHost();
               const OriginRealm &orr = l_resetreq->getOriginRealm();
               const AuthSessionState &authsessstate = l_resetreq->getAuthSessionState();

               l_resetans->setSessionId(sid);
               l_resetans->setSessionIndex(l_resetreq->getSessionIndex());
               l_resetans->setAuthSessionState(authsessstate);

               VendorSpecificApplicationId vendorSpecAppId;
               VendorId vendorId(10415);
               vendorSpecAppId.addVendorId(vendorId);
               l_resetans->setVendorSpecificApplicationId(vendorSpecAppId);

               ResultCode resultCode(2001);
               l_resetans->setResultCode(resultCode);

               ExperimentalResult experimentalResult;
               VendorId vendorId1(10415);
               experimentalResult.setVendorId(vendorId1);

               ExperimentalResultCode experimentalResultCode(2001);
               experimentalResult.setExperimentalResultCode(experimentalResultCode);
               l_resetans->setExperimentalResult(experimentalResult);

               OriginHost originhost("S6AServer");
               l_resetans->setOriginHost(originhost);

               OriginRealm originRealm("MME");
               l_resetans->setOriginRealm(originRealm);


               printf("Before sendMessage ... \n");
               g_esc.sendMsg(this, &l_answer);
            }
            else
            {
               DLOG(0,0,"RECEIVED PTR NULL ");
            }
         }
         break;
      case MSG_TYPE_DB:
         {

         }
         break;
      case MSG_TYPE_TIMEOUT:
         {

         }
         break;
      default:
         DLOG(0,0,"Unknown message received %d", p_MsgPtr->m_MsgType);
         break;
   }
   return true;
}
