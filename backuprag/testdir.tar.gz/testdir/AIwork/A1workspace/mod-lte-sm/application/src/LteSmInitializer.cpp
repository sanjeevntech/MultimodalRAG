#include <MapMessages.h>
#include <ContextBase.h>
#include <ModuleBase.h>
#include <Logger.h>
#include <DiameterMessages.h>
#include <DiameterConstants.h>
#include <MySimulator.h>

#include <CtxtLtePurgeUERequest.h>
#include <CtxtLteResetRequest.h>
#include <CtxtSimulatorPurgeUERequest.h>
#include <CtxtSimulatorResetRequest.h>


extern bool g_loadFlag;

extern "C" {
   ModuleBase *getModuleObj();
}

class LteSmModule : public ModuleBase
{
   public:
      LteSmModule(){};
      ~LteSmModule(){};
      bool initModule();
      ContextBase *getCtxtObj(EMapOpCode,MapSpecificMsg*);
      ContextBase *getCtxtObj(EDiameterCommandCode, DiameterMsg*);
      ContextBase *getCtxtObj(EMapOpCode, SccpMsg*);
      char *getVersion();
      ConfigReader *getConfigReaderObj();
      ConfigReader **retrieveConfigReaderPtr();
};

LteSmModule g_LteSmModule;

ModuleBase *getModuleObj()
{
   return &g_LteSmModule;
}

char * LteSmModule::getVersion()
{
   RETURN_VERSION(APP_VERSION); //2.0.15.0 //base is "2.0.9.0" base is "2.0.6.2" 
}

bool LteSmModule::initModule() //added for ng_0.11
{
   string  m_modName="LSM";
   LLOG(0,0,"LSM APPVER-v:%s ci:%s cd:%s comp:%s %s", APP_VERSION, COMMIT_ID, COMMIT_DATE,__DATE__,__TIME__);
   //g_selfSimObj = new MySimulator;
   return true;
}   

ContextBase *LteSmModule::getCtxtObj(EMapOpCode aMapOpCode,MapSpecificMsg *p_msg)
{
   WLOG(0,0,"MAP Messages not implemented");
   return NULL;
}

ContextBase *LteSmModule::getCtxtObj(EDiameterCommandCode p_ccCode, DiameterMsg *p_msg)
{
   switch (p_ccCode)
   {
      case DIAM_COMM_CODE_S6A_S6D_PUR_PUA:
         {
            if(false == g_loadFlag)
            {
               DLOG(0,0,"Rcvd DIAM_COMM_CODE_S6A_S6D_PUR_PUA Newing CtxtLtePurgeUERequest");
               return new CtxtLtePurgeUERequest;
            }
            else
            {
               DLOG(0,0,"Rcvd DIAM_COMM_CODE_S6A_S6D_PUR_PUA Newing CtxtSimulatorPurgeUERequest");
               return new CtxtSimulatorPurgeUERequest;
            }
         }
         break;
      case DIAM_COMM_CODE_S6A_S6D_S7A_S7D_RSR_RSA:
         {
            if(false == g_loadFlag)
            {
               DLOG(0,0,"Rcvd DIAM_COMM_CODE_S6A_S6D_S7A_S7D_RSR_RSA Newing CtxtLteResetRequest");
               return new CtxtLteResetRequest;
            }
            else
            {
               DLOG(0,0,"Rcvd DIAM_COMM_CODE_S6A_S6D_S7A_S7D_RSR_RSA Newing CtxtSimulatorResetRequest");
               return new CtxtSimulatorResetRequest;
            }
         }
         break;
      default:
         {
            ELOG(0,0,"getCtxtObj Unknown ccCode [%d]",p_ccCode);
            return NULL;
         }
         break;
   }
}

ContextBase *LteSmModule::getCtxtObj(EMapOpCode p_OpCode, SccpMsg* p_msg)
{
   ELOG(0,0,"SCCP message not supported");
   return NULL;
}

ConfigReader *LteSmModule::getConfigReaderObj()
{
   WLOG(0,0,"LteSmModule getConfigReaderObj returning NULL");
   return NULL;
}

ConfigReader **LteSmModule::retrieveConfigReaderPtr()
{
   WLOG(0,0,"ConfigReader **LteSmModule::retrieveConfigReaderPtr() called. returning NULL");
   return NULL;
}

bool resetStruct(int p_version, int p_pdu, void *p_struct)
{
   return false;
}


