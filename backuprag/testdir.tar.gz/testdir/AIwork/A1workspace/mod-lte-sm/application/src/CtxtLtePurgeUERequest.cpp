#include <CtxtLtePurgeUERequest.h>
#include <stdio.h>
#include <Logger.h>
#include <MapMessages.h>
#include <ServiceCoordinator.h>
#include <DbActiveObject.h>
#include <Utilities.h>
#include <ExtendedServiceCoordinator.h>
#include <HlrTdrFiller.h>
#include <TdrData.h>
#include <DiameterConstants.h>
#include <diameter/s6a_r10/PurgeUE.h>
#include <diameter/base/BaseAVP.h>
#include <DiametriqInterface.h>

//CommandCode for PurgeUERequest/Answer 321

using namespace diameter::s6a_r10;

CtxtLtePurgeUERequest::CtxtLtePurgeUERequest()
{
   DLOG(0,0,"CtxtLtePurgeUERequest :cons:");
   m_actfeatlist1 =0;
   m_actfeatlist2 =0;
   m_s6arelease =0;
   m_PURFlag = 0;
   memset(m_imsi,'\0',sizeof(m_imsi));
   memset(m_hss_originhost, '\0', sizeof(m_hss_originhost));
   memset(m_hss_originrealm, '\0', sizeof(m_hss_originrealm));
   memset(m_mmehost, '\0', sizeof(m_mmehost));
   memset(m_mmerealm, '\0', sizeof(m_mmerealm));

   m_msgPtr = NULL;
}


CtxtLtePurgeUERequest::~CtxtLtePurgeUERequest()
{
   DLOG(0,0,"CtxtLtePurgeUERequest :des:");
   if(NULL != m_msgPtr)
   {
      delete(m_msgPtr);
      m_msgPtr=NULL;
   }
}

bool CtxtLtePurgeUERequest::SendPurgeUEAnswer(bool MMEHostFlag)
{
   DLOG(0,0,"PurgeUEAnswer Framing ");

   DiameterMsg l_answer(((DiameterMsg*)m_msgPtr)->m_sessionId, DIAM_EVENT_ANSWER, DIAM_COMM_CODE_S6A_S6D_PUR_PUA);
   PurgeUEAnswer l_purresp;
   l_answer.m_cmd = &l_purresp;

   try
   {
      SessionId sess(((DiameterMsg*)m_msgPtr)->m_sessionId); //added on 8feb14
      l_purresp.setSessionId(sess);
      l_purresp.setSessionIndex(((DiameterMsg*)m_msgPtr)->m_sessionIndex);

      LLOG(0,0,"PUA: SessionIndex[%d] Session[%s] SessionState[NO_STATE_MAINTAINED]",((DiameterMsg*)m_msgPtr)->m_sessionIndex,(char*)((DiameterMsg*)m_msgPtr)->m_sessionId);

      AuthSessionState authSessionState(AuthSessionState::NO_STATE_MAINTAINED);
      l_purresp.setAuthSessionState(authSessionState);

      //m_originhost take from db HLR_NETWORKS table HSS_ORIGIN_HOST param
      OriginHost originHost(m_hss_originhost);
      l_purresp.setOriginHost(originHost);

      //m_originrealm take from db HLR_NETWORKS table HSS_ORIGIN_RELAM param
      OriginRealm originRealm(m_hss_originrealm);
      l_purresp.setOriginRealm(originRealm);

      if(m_s6arelease >= 8) 
      {
         if(m_actfeatlist1 != 0)
         {
            LLOG(0,0,"S6AVersion |%d| setting FeatureListID1 |%d| ", m_s6arelease, m_actfeatlist1);
            m_tdr.setUnsignedInteger(TDR_INDEX_LOCAL_SUPP_FEATURE_1, m_actfeatlist1);
            VendorSpecificApplicationId vendorSpecAppId;
            VendorId vendorId(10415);
            vendorSpecAppId.addVendorId(vendorId);
            l_purresp.setVendorSpecificApplicationId(vendorSpecAppId);

            diameter::s6a_r10::SupportedFeatures suppFeatures;
            VendorId vendorIdSup(10415); //received one vendorIdSUp value should be here.
            suppFeatures.setVendorId(vendorIdSup);
            diameter::s6a_r10::FeatureListID featureListId(1);
            suppFeatures.setFeatureListID(featureListId);
            diameter::s6a_r10::FeatureList featureList(m_actfeatlist1);
            suppFeatures.setFeatureList(featureList);
            l_purresp.addSupportedFeatures(suppFeatures);
         }
         else
         {
            TLOG(0,0,"PUA: FeatureList1 not sending as FeatureListID1 is 0 ");
         }
      }

      if(12 == m_s6arelease)
      {
         LLOG(0,0,"S6AVersion |%d| setting FeatureListID1 |%d| and FeatureListID2 |%d| ", m_s6arelease, m_actfeatlist1, m_actfeatlist2);

         if(m_actfeatlist2 != 0)
         {
            VendorSpecificApplicationId vendorSpecAppId;
            VendorId vendorId(10415);
            vendorSpecAppId.addVendorId(vendorId);
            l_purresp.setVendorSpecificApplicationId(vendorSpecAppId);

            diameter::s6a_r10::SupportedFeatures suppFeatures;
            VendorId vendorIdSup(10415); //received one vendorIdSUp value should be here.
            suppFeatures.setVendorId(vendorIdSup);
            diameter::s6a_r10::FeatureListID featureListId2(2);
            suppFeatures.setFeatureListID(featureListId2);
            diameter::s6a_r10::FeatureList featurList(m_actfeatlist2);
            suppFeatures.setFeatureList(featurList);
            l_purresp.addSupportedFeatures(suppFeatures);
            LLOG(0,0, "RSR SuppFeature_2: |%d| ", m_actfeatlist2);
            m_tdr.setUnsignedInteger(TDR_INDEX_LOCAL_SUPP_FEATURE_2, m_actfeatlist2);
         }
         else
         {
            TLOG(0,0,"PUA: FeatureList1 not sending as FeatureListID1 is 0 ");
         }
      }

      ResultCode l_resultCode(DIAM_RESULT_CODE_SUCCESS);
      l_purresp.setResultCode(l_resultCode);

      //0000000000000000000000000000001
      if(true == MMEHostFlag) //added in rev1 start setting this flag as true only in case of MME-Identity mismatch with stored one.
      {
         int l_test  =0;
         s6a_r10::PUAFlags m_tmsiflag(l_test); //clear or freeze M-TMSI
         l_purresp.setPUAFlags(m_tmsiflag);
      } //end
      else
      {
         //int l_test  =1;
         s6a_r10::PUAFlags m_tmsiflag(1); //setting M-TMSI , clear P-TMSI
         l_purresp.setPUAFlags(m_tmsiflag);
      }

      LLOG(0,0,"DBRESPCODE 0 SUCCESS case");
      //m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_RESULT_CODE_SUCCESS);
   }
   catch(NoSuchAttributeException e)
   {
      ELOG(0,1,"ERROR!! Exception NoSuchAttributeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_RESULT_CODE_UNABLE_TO_COMPLY);
      return handleError(10415,DIAM_RESULT_CODE_UNABLE_TO_COMPLY, ERROR_DIAGNOSTIC_NOT_REQUIRED);
   }
   catch(WrongCommandTypeException e)
   {
      ELOG(0,1,"ERROR!! Exception WrongCommandTypeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_RESULT_CODE_UNABLE_TO_COMPLY);
      return handleError(10415,DIAM_RESULT_CODE_UNABLE_TO_COMPLY, ERROR_DIAGNOSTIC_NOT_REQUIRED);
   }
   catch (UnknownTypeException e)
   {
      ELOG(0,1,"ERROR!! Exception UnknownTypeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_RESULT_CODE_UNABLE_TO_COMPLY);
      return handleError(10415,DIAM_RESULT_CODE_UNABLE_TO_COMPLY, ERROR_DIAGNOSTIC_NOT_REQUIRED);
   }
   catch (CodecException e)
   {
      ELOG(0,1,"ERROR!! Exception CodecException Caught: %s ,Error Cause: %s ",e.name(), e.what());
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_RESULT_CODE_UNABLE_TO_COMPLY);
      return handleError(10415,DIAM_RESULT_CODE_UNABLE_TO_COMPLY, ERROR_DIAGNOSTIC_NOT_REQUIRED);
   }
   catch(...)
   {
      CLOG(0,0,"Exception occurred while calling SendPUA");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_RESULT_CODE_UNABLE_TO_COMPLY);
      return handleError(10415,DIAM_RESULT_CODE_UNABLE_TO_COMPLY, ERROR_DIAGNOSTIC_NOT_REQUIRED);
   }
   g_esc.sendMsg(this, &l_answer); 
   return true;
}


bool CtxtLtePurgeUERequest::processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag)
{
   DLOG(0,0,"Start of CtxtLtePurgeUERequest::processMsg function");

   p_DeleteFlag = p_DeleteFlag;

   MapSpecificMsg *l_specMsg = NULL;

   switch(p_MsgPtr->m_MsgType)
   {
      case MSG_TYPE_MAP:
         {
            DLOG(0,0,"MAP message received");
         }
         break;

      case MSG_TYPE_DIAMETER:
         {
            LLOG(0,0,"DIAMETER message received");

            m_msgPtr = p_MsgPtr;
            p_DeleteFlag = false;
            DiameterMsg *l_dm = (DiameterMsg*)p_MsgPtr;

            switch(l_dm->m_det)
            {
               case DIAM_EVENT_REQUEST:
                  {
                     if(NULL != l_dm->m_cmd)
                     {
                        if(false == l_dm->m_allocatedFlag)
                        {
                           CLOG(0,0,"S6A PURR received is NULL. Sending Unexpected Data...");
                           handleError(10415, DIAM_RESULT_CODE_UNABLE_TO_COMPLY, ERROR_DIAGNOSTIC_NOT_REQUIRED); 
                           m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_RESULT_CODE_UNABLE_TO_COMPLY);
                           return false;
                        }
                        else
                        {
                           DLOG(0,0,"AllocatedFlag is true ");
                        }

                        diameter::s6a_r10::PurgeUERequest l_Purgereq(*(diameter::CommandImpl *)((DiameterMsg*)m_msgPtr)->m_cmd);

                        diameter::base::SessionId sess= l_Purgereq.getSessionId();
                        ITS_UINT l_idx = l_Purgereq.getSessionIndex();

                        const AuthSessionState &authSessState = l_Purgereq.getAuthSessionState();
                        const OriginHost &oh1 = l_Purgereq.getOriginHost();
                        if(oh1.value().size() > MMEHOST_SIZE)
                        {
                           WLOG(0,0,"Origin Host size %d is greater than the acceptable size %d", oh1.value().size(), MMEHOST_SIZE);
                           return false;
                        }
                        snprintf(m_mmehost, sizeof(m_mmehost), (char *)oh1.value().c_str());

                        const OriginRealm &or1 = l_Purgereq.getOriginRealm();
                        if(or1.value().size() > MMEREALM_SIZE)
                        {
                           WLOG(0,0,"Origin Realm size %d is greater than the acceptable size %d", or1.value().size(), MMEREALM_SIZE);
                           return false;
                        }
                        snprintf(m_mmerealm, sizeof(m_mmerealm), (char*)or1.value().c_str());

                        const diameter::base::UserName &l_username = l_Purgereq.getUserName();
                        if(15 != l_username.value().size())
                        {
                           WLOG(0,0,"IMSI length not 15");
                           m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_RESULT_CODE_UNABLE_TO_COMPLY);
                           handleError(10415, DIAM_RESULT_CODE_UNABLE_TO_COMPLY, ERROR_DIAGNOSTIC_NOT_REQUIRED);
                           return false;
                        }
                        strcpy(m_imsi,l_username.value().c_str());
                        LLOG(0,0,"DIAMETER message received from MME IMSI |%s|", m_imsi);

                        if(true == l_Purgereq.containsVendorSpecificApplicationId())
                        {
                           const VendorSpecificApplicationId &vendorspecificappId = l_Purgereq.getVendorSpecificApplicationId();
                           LLOG(0,0,"PurgeUERequest contains VendorSpecificApplicationId ");
                        }
                        else
                        {
                           LLOG(0,0,"PurgeUERequest does not contain any VendorSpecificApplicationId ");
                        }

                        if(true == l_Purgereq.containsDestinationHost())
                        {
                           const DestinationHost &destinationhost = l_Purgereq.getDestinationHost();
                           LLOG(0,0,"PurgeUERequest contains DestinationHost: %s", destinationhost.value().c_str());
                        }
                        else
                        {
                           LLOG(0,0,"PurgeUERequest does not contain any DestinationHost ");
                        }

                        int l_NumSuppFeat = l_Purgereq.countSupportedFeatures();

                        if(0 != l_NumSuppFeat)
                        {
                           for(int i=0; i<l_NumSuppFeat; i++)
                           {
                              LLOG(0,0,"SupportedFeature%d: VendorId: %d", i+1, l_Purgereq.getSupportedFeatures(i).getVendorId().value());
                              LLOG(0,0,"SupportedFeature%d: FeatureListID: %d", i+1, l_Purgereq.getSupportedFeatures(i).getFeatureListID().value());
                              LLOG(0,0,"SupportedFeature%d: FeatureList: %d", i+1, l_Purgereq.getSupportedFeatures(i).getFeatureList().value());
                           }
                        }
                        else
                        {
                           LLOG(0,0,"PuregeUERequest Does not contain any SupportedFeatures ");
                           //In this case fill SupportedFeatures which are configure for the subscriber while sending PurgeUEAnswer
                        }

                        int l_NumExtra = l_Purgereq.countExtra();
                        int l_NumProxyInfo = l_Purgereq.countProxyInfo();
                        int l_NumRoutRecord = l_Purgereq.countRouteRecord();

                        if(true == l_Purgereq.containsPURFlags())
                        {
                           m_PURFlag = l_Purgereq.getPURFlags().value();
                           LLOG(0,0,"PurgeUERequest contains PUR-Flags |%d|", l_Purgereq.getPURFlags().value());
                        }
                        else
                        {
                           LLOG(0,0,"PurgeUERequest Does not contain PUR-Flags ");
                        }

                        LLOG(0,0," received UserName:|%s| OriginHost Recvd:|%s| PurgeUE OriginRealm|%s| Extra|%d| ProxyInfo|%d| RouteRecord|%d| ", m_imsi, m_mmehost, m_mmerealm, l_NumExtra, l_NumProxyInfo, l_NumRoutRecord);

                        m_tdr.setString(TDR_INDEX_REQUEST_IMSI, m_imsi);


                        SendDBRequest(); 
                        return true;
                     }
                     else
                     {
                        LLOG(0,0,"No PurgeUERequest message found");
                     }
                  }
                  break;
               case DIAM_EVENT_TIME_OUT:
                  WLOG(0,0,"DIAM_EVENT_TIME_OUT received");
                  m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EVENT_TIME_OUT); //added in rev1
                  break;
               case DIAM_EVENT_ERROR:
                  WLOG(0,0,"DIAM_EVENT_ERROR received");
                  m_tdr.setInteger(TDR_ERROR_DIAM_EVENT_ERROR, DIAM_EVENT_ERROR);
                  break;
               case DIAM_EVENT_AUTH_LIFE_TIME_OUT:
                  WLOG(0,0,"DIAM_EVENT_AUTH_LIFE_TIME_OUT received");
                  m_tdr.setInteger(TDR_ERROR_DIAM_EVENT_ERROR, TDR_ERROR_DIAM_EVENT_AUTH_LIFE_TIME_OUT);
                  break;
               case DIAM_EVENT_AUTH_GRACE_TIME_OUT:
                  WLOG(0,0,"DIAM_EVENT_AUTH_GRACE_TIME_OUT received");
                  m_tdr.setInteger(TDR_ERROR_DIAM_EVENT_ERROR, TDR_ERROR_DIAM_EVENT_AUTH_GRACE_TIME_OUT);
                  break;
               case DIAM_EVENT_CORRUPTED_MSG:
                  WLOG(0,0,"DIAM_EVENT_CORRUPTED_MSG received");
                  m_tdr.setInteger(TDR_ERROR_DIAM_EVENT_ERROR, TDR_ERROR_DIAM_EVENT_ERROR);
                  break;
               case DIAM_EVENT_ACCT_INTERIM_TIME_OUT:
                  WLOG(0,0,"DIAM_EVENT_ACCT_INTERIM_TIME_OUT received");
                  m_tdr.setInteger(TDR_ERROR_DIAM_EVENT_ERROR, TDR_ERROR_DIAM_EVENT_ACCT_INTERIM_TIME_OUT);
                  break;
               case DIAM_EVENT_ERROR_SOMETHING_WEIRD:
                  WLOG(0,0,"DIAM_EVENT_ERROR_SOMETHING_WEIRD received");
                  break;
               default :
                  WLOG(0,0,"UNKNOWN DIAMETER received ");
                  return false;
                  break;
            }
         }
         break;

      case MSG_TYPE_DB:
         {
            DLOG(0,0,"DB message received");
            DbQueryMsg* l_dbQueryMsgPtr = ((DbQueryMsg*)p_MsgPtr);

            //DB_QUERY_RES_UNKNOWN=0,DB_QUERY_RES_SUCCESS,DB_QUERY_RES_ROWS_NOT_FOUND,DB_QUERY_RES_CODE_EXCEPTION
            m_tdr.setInteger(TDR_INDEX_MM_NETWORK_ID, mp_purgeuereq->m_nwid);

            if(DB_QUERY_RES_SUCCESS == l_dbQueryMsgPtr->m_DbQueryRes)
            {
               m_actpartnernetId = mp_purgeuereq->m_activepartnernetId;
               m_actfeatlist1 = mp_purgeuereq->m_activefeatlist_1;
               m_actfeatlist2 = mp_purgeuereq->m_activefeatlist_2;
               snprintf(m_hss_originhost, sizeof(m_hss_originhost), mp_purgeuereq->m_HSS_OriginHost);
               snprintf(m_hss_originrealm, sizeof(m_hss_originrealm), mp_purgeuereq->m_HSS_OriginRealm);
               m_s6arelease = mp_purgeuereq->m_s6arelease;

               LLOG(0,0,"ACTPARTNTERNWID:|%d| ACTFEATLIST1:|%d| ACTFEATLIST2:|%d| HSSORIGINHOST:|%s| HSSORIGINREALM:|%s| S6ARELEASE:|%d| ", m_actpartnernetId, m_actfeatlist1, m_actfeatlist2, m_hss_originhost, m_hss_originrealm, m_s6arelease);

               //added in rev1 start for MME-Identity mismatch case send +ve resp by freeze M-TMSI flag in answer mssg
               if(4 == mp_purgeuereq->m_ErrCode)
               {
                  DLOG(0,0," MME not matched case ");
                  SendPurgeUEAnswer(true);
                  return true;
               } //end
               else
               {
                  //call PurgeUEAnswer mssg
                  DLOG(0,0," MME matched case ");
                  SendPurgeUEAnswer(false);
                  return true;
               }
            }
            else
            {
               if(DB_QUERY_RES_ROWS_NOT_FOUND == l_dbQueryMsgPtr->m_DbQueryRes)
               {
                  ELOG(0,0, "IMSI not found case sending -ve resp");
                  handleError(10415,DIAM_EXP_RESULT_CODE_ERROR_USER_UNKNOWN,ERROR_DIAGNOSTIC_NOT_REQUIRED);
                  return true;
               }
               else if(DB_QUERY_RES_CODE_EXCEPTION == l_dbQueryMsgPtr->m_DbQueryRes)
               {
                  snprintf(m_hss_originhost, sizeof(m_hss_originhost), mp_purgeuereq->m_HSS_OriginHost);
                  snprintf(m_hss_originrealm, sizeof(m_hss_originrealm), mp_purgeuereq->m_HSS_OriginRealm);
                  printf("DB_QUERY_RES_CODE_EXCEPTION going to send -ve resp \n");
                  handleError(10415,DIAM_RESULT_CODE_UNABLE_TO_COMPLY,ERROR_DIAGNOSTIC_NOT_REQUIRED);
                  return true;
               }
               else
               {
                  snprintf(m_hss_originhost, sizeof(m_hss_originhost), mp_purgeuereq->m_HSS_OriginHost);
                  snprintf(m_hss_originrealm, sizeof(m_hss_originrealm), mp_purgeuereq->m_HSS_OriginRealm);
                  printf("DB returned other error sending DIAM_RESULT_CODE_UNABLE_TO_COMPLY result code \n");
                  handleError(10415,DIAM_RESULT_CODE_UNABLE_TO_COMPLY,ERROR_DIAGNOSTIC_NOT_REQUIRED);
                  return true;
               }
            }
         }
         break;

      case MSG_TYPE_TIMEOUT:
         {
            WLOG(0,0,"Timeout received");
         }
         break;

      default :
         WLOG(0,0,"Unknown message received %d", p_MsgPtr->m_MsgType);
         break;

   }
   return true;
}

void CtxtLtePurgeUERequest::SendDBRequest()
{
   mp_purgeuereq  = new PurgeDbData;
   strcpy(mp_purgeuereq->m_IMSI, m_imsi);
   strcpy(mp_purgeuereq->m_recvdOriginHost, m_mmehost);

   LLOG(0,0, "SendDBRequest IMSI: |%s| recevdoriginhost |%s| ", mp_purgeuereq->m_IMSI, mp_purgeuereq->m_recvdOriginHost);
   mp_purgeuereq->m_DbQueryType = 1;
   mp_purgeuereq->m_cb = this;
   g_act.execute(mp_purgeuereq);
   return;
}

bool CtxtLtePurgeUERequest::handleError(unsigned int aVendorId, unsigned int aErrCode, EErrorDiagnostic p_ed)
{
   DiameterMsg l_answer(((DiameterMsg*)m_msgPtr)->m_sessionId, DIAM_EVENT_ANSWER, DIAM_COMM_CODE_S6A_S6D_PUR_PUA);
   PurgeUEAnswer l_pura;
   l_answer.m_cmd = &l_pura;

   try
   {
      SessionId sess(((DiameterMsg*)m_msgPtr)->m_sessionId);
      l_pura.setSessionId(sess);
      l_pura.setSessionIndex(((DiameterMsg*)m_msgPtr)->m_sessionIndex);

      AuthSessionState authSessionState(AuthSessionState::NO_STATE_MAINTAINED);
      l_pura.setAuthSessionState(authSessionState);

      OriginHost originHost(m_hss_originhost);
      l_pura.setOriginHost(originHost);

      OriginRealm originRealm(m_hss_originrealm);
      l_pura.setOriginRealm(originRealm);

      VendorSpecificApplicationId vendorSpecAppId;
      VendorId vendorId(10415);
      vendorSpecAppId.addVendorId(vendorId);
      l_pura.setVendorSpecificApplicationId(vendorSpecAppId);

      if(DIAM_EXP_RESULT_CODE_ERROR_USER_UNKNOWN == aErrCode)
      {
         //DB_QUERY_RES_ROWS_NOT_FOUND INVALID IMSI CASE
         ExperimentalResult l_experimentalResult;
         VendorId l_vendorId(aVendorId);
         l_experimentalResult.setVendorId(l_vendorId);
         ExperimentalResultCode l_experimentalResultCode(DIAM_EXP_RESULT_CODE_ERROR_USER_UNKNOWN);
         DLOG(0,0, "DBRESPCODE 1 Inavlid Imsi case sending -ve response ");
         m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_EXP_RESULT_CODE_ERROR_USER_UNKNOWN);
         l_experimentalResult.setExperimentalResultCode(l_experimentalResultCode);
         l_pura.setExperimentalResult(l_experimentalResult);
      }
      else if(DIAM_RESULT_CODE_UNABLE_TO_COMPLY == aErrCode)
      {
         LLOG(0,1,"Setting Result Code %d", aErrCode);
         ResultCode l_rc(aErrCode);
         l_pura.setResultCode(l_rc);
      }

      LLOG(0,0," HandleError:received UserName:|%s| OriginHost Reced:|%s| PurgeUE OriginRealm|%s| ", m_imsi, m_mmehost, m_mmerealm);
   }
   catch (NoSuchAttributeException e)
   {
      ELOG(0,1,"ERROR!! Exception NoSuchAttributeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EXCEPTION_OCCURRED);
      return false;
   }
   catch (WrongCommandTypeException e)
   {
      ELOG(0,1,"ERROR!! Exception WrongCommandTypeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EXCEPTION_OCCURRED);
      return false;
   }
   catch (UnknownTypeException e)
   {
      ELOG(0,1,"ERROR!! Exception UnknownTypeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EXCEPTION_OCCURRED);
      return false;
   }
   catch (CodecException e)
   {
      ELOG(0,1,"ERROR!! Exception CodecException Caught: %s ,Error Cause: %s ",e.name(), e.what());
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EXCEPTION_OCCURRED);
      return false;
   }
   catch (...)
   {
      CLOG(0,0,"Exception occurred while Sending Error");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EXCEPTION_OCCURRED);
      return false;
   }

   g_esc.sendMsg(this, &l_answer);
   m_tdr.setInteger(TDR_INDEX_ERR_CODE, aErrCode);
   return true;
}
