#include <CtxtLteResetRequest.h>
#include <stdio.h>
#include <Logger.h>
#include <MapMessages.h>
#include <ServiceCoordinator.h>
#include <DbActiveObject.h>
#include <Utilities.h>
#include <ExtendedServiceCoordinator.h>
#include <HlrTdrFiller.h>
#include <ProvisioningMessages.h>
#include <DiameterConstants.h>
#include <DiameterMessages.h>
#include <diameter/s6a_r10/Reset.h>
#include <diameter/base/BaseAVP.h>
#include <DiametriqInterface.h>

using namespace diameter::s6a_r10;

CtxtLteResetRequest::CtxtLteResetRequest()
{
   DLOG(0,0,"CtxtLteResetRequest :cons:");
   memset(m_TransId,'\0',sizeof(m_TransId));
   memset(m_originhost, '\0', sizeof(m_originhost));
   memset(m_originrealm, '\0', sizeof(m_originrealm));
   memset(m_desthost, '\0', sizeof(m_desthost));
   memset(m_destrealm, '\0', sizeof(m_destrealm));
   memset(m_type, '\0', sizeof(m_type));
   m_suppFeature1=0;
   m_suppFeature2=0;
   m_imsiCount = 0;
   m_s6arelease =0;

}

CtxtLteResetRequest::~CtxtLteResetRequest()
{
   DLOG(0,0,"CtxtLteResetRequest :des:");
}

bool CtxtLteResetRequest::preResetMsg(char *p_req)
{
   TLOG(0,0,"Going to frame RESETREQUEST  ");
   string m_response = ConfigReader::readValue(p_req, "RSR");
   if(m_response.size() < 1)
   {
      CLOG(0,0,"Get Reset Request tag not found");
      return false;
   }
   unsigned int sIdx;
   string sessIdString;
   if(false == g_esc.allocateSession(DIAM_APP_ID_S6A_S6D,
            sIdx,
            sessIdString))
   {
      ELOG(0,1,"Unable to allocate a session");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE);
      return false;
   }

   DiameterMsg l_rsr((char *)sessIdString.c_str(),DIAM_EVENT_REQUEST,DIAM_COMM_CODE_S6A_S6D_S7A_S7D_RSR_RSA);
   diameter::s6a_r10::ResetRequest l_resetreq;

   l_resetreq.setSessionId(diameter::base::SessionId(sessIdString));
   l_resetreq.setSessionIndex(sIdx);

   ITS_UINT l_idx = l_resetreq.getSessionIndex();
   LLOG(0,0,"ResetReq Session Id : %d", l_idx);

   AuthSessionState authSessionState(AuthSessionState::NO_STATE_MAINTAINED);
   l_resetreq.setAuthSessionState(authSessionState);

   string l_type = ConfigReader::readValue(p_req, "TYPE");
   if(l_type.size() > 0)
   {
      LLOG(0,0, "TYPE: %s", l_type.c_str());
      strcpy(m_type, l_type.c_str());
      m_tdr.setString(TDR_INDEX_REQUEST_TYPE, m_type);
   }
   else
   {
      ELOG(0,0,"Type not present ");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE);
      return false;
   }

   string l_originhost = ConfigReader::readValue(p_req, "ORIGIN_HOST");
   if(l_originhost.size() > 0)
   {
      LLOG(0,0, "RSR OriginHost : %s", l_originhost.c_str());
      strcpy(m_originhost, l_originhost.c_str());
      m_tdr.setString(TDR_INDEX_LOCAL_HOST, m_originhost);
      OriginHost originHost = diameter::base::OriginHost(l_originhost.c_str());
      l_resetreq.setOriginHost(originHost);
   }
   else
   {
      ELOG(0,0,"RSR-- OriginHost not present");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE);
      return false;
   }

   string l_originrealm = ConfigReader::readValue(p_req, "ORIGIN_REALM");
   if(l_originrealm.size() > 0)
   {
      LLOG(0,0, "RSR OriginRealm : %s", l_originrealm.c_str());
      strcpy(m_originrealm, l_originrealm.c_str());
      OriginRealm originRealm = diameter::base::OriginRealm(l_originrealm.c_str());
      l_resetreq.setOriginRealm(originRealm);
   }
   else
   {
      ELOG(0,0,"RSR-- ORIGIN_REALM not present");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE);
      return false;
   }

   string l_desthost = ConfigReader::readValue(p_req, "DESTINATION_HOST");
   if(l_desthost.size() > 0)
   {
      LLOG(0,0, "RSR DestinationHost : %s", l_desthost.c_str());
      strcpy(m_desthost, l_desthost.c_str());
      DestinationHost destHost = diameter::base::DestinationHost(l_desthost.c_str());
      l_resetreq.setDestinationHost(destHost);
   }
   else
   {
      ELOG(0,0,"RSR-- DESTINATION_HOST not present");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE);
      return false;
   }

   string l_destrealm = ConfigReader::readValue(p_req, "DESTINATION_REALM");
   if(l_destrealm.size() > 0)
   {
      LLOG(0,0, "RSR DestinationRealm : %s", l_destrealm.c_str());
      strcpy(m_destrealm, l_destrealm.c_str());
      DestinationRealm destrealm = diameter::base::DestinationRealm(l_destrealm.c_str());
      l_resetreq.setDestinationRealm(destrealm);
   }
   else
   {
      ELOG(0,0,"RSR-- DESTINATION_REALM not present");
      m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE);
      return false;
   }

   string l_S6arelease = ConfigReader::readValue(p_req, "S6A_RELEASE");
   m_s6arelease = atoi(l_S6arelease.c_str());

   //release 8,9,10,11 having only FeatureList_ID1 and release 12 we are having two FeatureListID's 1&2

   if(m_s6arelease >= 8)
   {
      LLOG(0,0,"S6A_Release : %s  %d ", l_S6arelease.c_str(), m_s6arelease);

      string l_suppFeature1 = ConfigReader::readValue(p_req, "SUPPORTED_FEATURES_1");
      m_suppFeature1 = atoi(l_suppFeature1.c_str());

      HssFeatureList* l_hssFeaturelist1 = NULL;
      l_hssFeaturelist1 = g_spdPtr->m_hssProfile->getHssFeatureListPtr(m_suppFeature1);

      if(l_hssFeaturelist1 != NULL)
      {
            diameter::s6a_r10::SupportedFeatures suppFeatures;
            VendorSpecificApplicationId l_vendorSpecAppId;
            VendorId l_vendorId(10415);
            suppFeatures.setVendorId(l_vendorId);

            diameter::s6a_r10::FeatureListID featureListId1(1);
            suppFeatures.setFeatureListID(featureListId1);
            diameter::s6a_r10::FeatureList featurList(l_hssFeaturelist1->m_featureListValue);
            suppFeatures.setFeatureList(featurList);
            l_resetreq.addSupportedFeatures(suppFeatures);
            LLOG(0,0, "RSR SuppFeature_1 SeqID and value : |%d| |%d|", m_suppFeature1, l_hssFeaturelist1->m_featureListValue);
            m_tdr.setUnsignedInteger(TDR_INDEX_LOCAL_SUPP_FEATURE_1, l_hssFeaturelist1->m_featureListValue);
      }
      else
      {
         LLOG(0,0,"RSR-- SUPPORTEDFEATURES_1 not present in XML and not filling while sending RSR ");
         //m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE);
         //return false;
      }
   }

   if(12 == m_s6arelease)
   {
      LLOG(0,0,"S6A_Release : %s ", l_S6arelease.c_str());

      string l_suppFeature2 = ConfigReader::readValue(p_req, "SUPPORTED_FEATURES_2");
      m_suppFeature2 = atoi(l_suppFeature2.c_str()); 

      HssFeatureList* l_hssFeaturelist2 = NULL;
      l_hssFeaturelist2 = g_spdPtr->m_hssProfile->getHssFeatureListPtr(m_suppFeature2);

      if(l_hssFeaturelist2 != NULL)
      {
         diameter::s6a_r10::SupportedFeatures suppFeatures;
         VendorId vendorIdSup(10415);
         suppFeatures.setVendorId(vendorIdSup);

         diameter::s6a_r10::FeatureListID featureListId2(2);
         suppFeatures.setFeatureListID(featureListId2);
         diameter::s6a_r10::FeatureList featurList(l_hssFeaturelist2->m_featureListValue);
         suppFeatures.setFeatureList(featurList);
         l_resetreq.addSupportedFeatures(suppFeatures);
         LLOG(0,0, "RSR SuppFeature_2 SeqID and Value : |%d| |%d| ", m_suppFeature2, l_hssFeaturelist2->m_featureListValue);
         m_tdr.setUnsignedInteger(TDR_INDEX_LOCAL_SUPP_FEATURE_2, l_hssFeaturelist2->m_featureListValue);
      }
      else
      {
         CLOG(0,0,"RSR-- SUPPORTEDFEATURES_2 not present in XML and not filling while sending RSR ");
         //m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_UNABLE_TO_INITIATE);
         //return false;
      }
   }

   //for IMSI PREFIXES
   string l_imsi_prefix = ConfigReader::readValue(p_req, "IMSI_PREFIXES");

   //char l_imsi_prefixes_char[1000+1];
   //memset(l_imsi_prefixes_char, '\0', sizeof(l_imsi_prefixes_char));
   //strcpy(l_imsi_prefixes_char, ":");

   if(l_imsi_prefix.length() > 4)
   {
      LLOG(0,0,"IMSI_PREFIXES present ");
      char l_imsichar[10];
      for (int l_i=1;;l_i++)
      {
         memset(l_imsichar, '\0', sizeof(l_imsichar));
         sprintf(l_imsichar, "VAL_%02d", l_i);

         m_imsi[l_i] = ConfigReader::readValue(l_imsi_prefix, l_imsichar); 
         if (m_imsi[l_i].size() > 0)                                       
         {                                                                 
            if (m_imsi[l_i].size() < 5)                                    
            {                                                              
               ELOG(0,0,"Invalid IMSI prefix. should be minimum 5 digits");
               return false;                                               
            }                                                              

            //strcat(l_imsi_prefixes_char, (char*)(m_imsi[l_i].c_str()));
            //strcat(l_imsi_prefixes_char, ":");

            diameter::s6a_r10::UserId m_userid((char *)m_imsi[l_i].c_str());
            l_resetreq.addUserId(m_userid);
            m_imsiCount++;                                                 
         }                                                                 
         else                                                              
         {                                                                 
            LLOG(0,0,"Found %d IMSI Prefixes", m_imsiCount);
            break;                                                         
         }                                                                 
      }
   }

   m_tdr.setInteger(TDR_INDEX_OAM_NUM_OF_IMSI_PREFIXES, m_imsiCount);
   //m_tdr.setString(TDR_INDEX_OAM_IMSI_PREFIXES, l_imsi_prefixes_char);

   //USER 
   string l_user = ConfigReader::readValue(p_req, "USER");

   if(l_user.size() > 0)
   {
      LLOG(0,0, "RSR USER: %s", l_user.c_str());
   }
   else
   {
      LLOG(0,0,"RSR-- USER not present in XML and not filling while sending RSR ");
   }

   LLOG(0,1,"Sending reset with TYPE:%s ORIGIN_HOST:%s ORIGIN_REALM:%s DESTINATION_HOST:%s DESTINATION_REALM:%s IMSI_PREFIX:%s", l_type.c_str(), l_originhost.c_str(), l_originrealm.c_str(), l_desthost.c_str(), l_destrealm.c_str(), l_imsi_prefix.c_str());

   l_rsr.m_cmd = &l_resetreq;
   //m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_RESULT_CODE_SUCCESS);
   g_esc.sendMsg(this, &l_rsr);
   return true;
}

bool CtxtLteResetRequest::startProcessing(InterModuleData *p_imd, bool& p_DeleteFlag)
{
   string l_xml;

   char *l_check = NULL;
   int transIdlen;

   if(NULL == p_imd->m_Parameters)
   {
      CLOG(0,0,"p_imd->m_Parameters NULL");
   }
   else
   {
      l_check = strchr(p_imd->m_Parameters, ':');
   }

   if(NULL != l_check )
   {
      //l_xml = &p_imd->m_Parameters[0];
      l_xml = p_imd->m_Parameters;
      LLOG(0,1,"XML [%s]", (char*)l_xml.c_str());

      transIdlen = strlen(l_xml.c_str()) - strlen(l_check);
      strncpy(m_TransId, l_xml.c_str(), transIdlen);
      LLOG(0,0,"Transaction ID :%s received from OAM", m_TransId);

      preResetMsg((char*)l_xml.c_str());
   }
   else
   {
      ProvisioningReqMsg *l_provReqMsg = (ProvisioningReqMsg*)p_imd->m_msgPtr;
      m_tdr.setOriginatingModule((char*)l_provReqMsg->m_OrigEntityName.c_str());
      m_tdr.setString(TDR_INDEX_OAM_REQUEST_TYPE,"RESETREQUEST");
      l_xml = l_provReqMsg->m_data;
   }
   return true;

}

bool CtxtLteResetRequest::processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag)
{
   DLOG(0,0,"Start of CtxtLteResetRequest::processMsg function");
   p_DeleteFlag = p_DeleteFlag;
   MapSpecificMsg *l_specMsg = NULL;

   switch(p_MsgPtr->m_MsgType)
   {
      case MSG_TYPE_MAP:
         {
            DLOG(0,0,"MAP message received");
         }
         break;

      case MSG_TYPE_DIAMETER:
         {
            LLOG(0,0,"DIAMETER message received ");
            DiameterMsg *l_dm = (DiameterMsg*)p_MsgPtr;
            switch(l_dm->m_det)
            {
               case DIAM_EVENT_ANSWER:
                  {

                     //added in rev1 start
                     if((NULL == l_dm->m_cmd) || (false == l_dm->m_allocatedFlag))
                     {
                        CLOG(0,0,"Diameter Message received is NULL.");
                        break;
                     }
                     //end

                     if(NULL != l_dm->m_cmd)
                     {
                        diameter::s6a_r10::ResetAnswer l_ResetAnswer(*(diameter::CommandImpl *)l_dm->m_cmd);

                        diameter::base::SessionId sess = l_ResetAnswer.getSessionId();
                        ITS_UINT l_idx = l_ResetAnswer.getSessionIndex();
                        LLOG(0,0,"RESETANSWER Session Id : %d", l_idx);

                        const SessionId &sid1 = l_ResetAnswer.getSessionId();
                        const OriginHost &oh1 = l_ResetAnswer.getOriginHost();
                        const OriginRealm &or1 = l_ResetAnswer.getOriginRealm();
                        const AuthSessionState &authSessState = l_ResetAnswer.getAuthSessionState();

                        if(true == l_ResetAnswer.containsResultCode())
                        {
                           const ResultCode &resultcode = l_ResetAnswer.getResultCode();

                           unsigned int resultCode = resultcode.value();

                           if(resultcode.value() > 0)
                           {   
                              m_tdr.setInteger(TDR_INDEX_ERR_CODE, resultcode.value());
                              LLOG(0,0,"ResetAnswer Result Code Success: %u", resultcode.value());
                           }
                        }

                        if(true == l_ResetAnswer.containsExperimentalResult())
                        {
                           const ExperimentalResult &experimentalrel = l_ResetAnswer.getExperimentalResult();
                           const ExperimentalResultCode &experimentalrelcode = experimentalrel.getExperimentalResultCode();

                           if(experimentalrelcode.value() > 0)
                           {
                              m_tdr.setInteger(TDR_INDEX_ERR_CODE, experimentalrelcode.value());
                              LLOG(0,0,"ResetAnswer Experimental-Result Code : %u", experimentalrelcode.value());
                           }
                        }

                        if(true == l_ResetAnswer.containsVendorSpecificApplicationId())
                        {
                           const VendorSpecificApplicationId &vendorispecificappid = l_ResetAnswer.getVendorSpecificApplicationId();
                           const VendorId &vendorid = vendorispecificappid.getVendorId();

                           if(vendorid.value() > 0)
                           {
                              //rev1 setInteger removed copying vendorid in TDR_INDEX_ERR_CODE
                              LLOG(0,0,"ResetAnswer Vendor-Id: %u", vendorid.value());
                           }
                        }
                     }
                  }
                  break;
               case DIAM_EVENT_TIME_OUT:
                  LLOG(0,1,"DIAM_EVENT_TIME_OUT received");
                  m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EVENT_TIME_OUT); //added in rev1
                  break;
               case DIAM_EVENT_ERROR:
                  LLOG(0,1,"DIAM_EVENT_ERROR received");
                  m_tdr.setInteger(TDR_ERROR_DIAM_EVENT_ERROR, DIAM_EVENT_ERROR);
                  break;
               case DIAM_EVENT_AUTH_LIFE_TIME_OUT:
                  LLOG(0,1,"DIAM_EVENT_AUTH_LIFE_TIME_OUT received");
                  m_tdr.setInteger(TDR_ERROR_DIAM_EVENT_ERROR, TDR_ERROR_DIAM_EVENT_AUTH_LIFE_TIME_OUT);
                  break;
               case DIAM_EVENT_AUTH_GRACE_TIME_OUT:
                  LLOG(0,1,"DIAM_EVENT_AUTH_GRACE_TIME_OUT received");
                  m_tdr.setInteger(TDR_ERROR_DIAM_EVENT_ERROR, TDR_ERROR_DIAM_EVENT_AUTH_GRACE_TIME_OUT);
                  break;
               case DIAM_EVENT_CORRUPTED_MSG:
                  LLOG(0,1,"DIAM_EVENT_CORRUPTED_MSG received");
                  m_tdr.setInteger(TDR_ERROR_DIAM_EVENT_ERROR, TDR_ERROR_DIAM_EVENT_CORRUPTED_MSG);
                  break;
               case DIAM_EVENT_ACCT_INTERIM_TIME_OUT:
                  LLOG(0,1,"DIAM_EVENT_ACCT_INTERIM_TIME_OUT received");
                  m_tdr.setInteger(TDR_ERROR_DIAM_EVENT_ERROR, TDR_ERROR_DIAM_EVENT_ACCT_INTERIM_TIME_OUT);
                  break;
               case DIAM_EVENT_ERROR_SOMETHING_WEIRD:
                  LLOG(0,1,"DIAM_EVENT_ERROR_SOMETHING_WEIRD received");
                  break;
               default :
                  LLOG(0,1,"UNKNOWN DIAMETER received ");
                  return false;
                  break;
            }
         }
         break;

      case MSG_TYPE_DB:
         {
            DLOG(0,0,"DB message received");
         }
         break;

      case MSG_TYPE_TIMEOUT:
         {
            LLOG(0,0,"Timeout received");
         }
         break;
      default :
         DLOG(0,0,"Unknown message received %d", p_MsgPtr->m_MsgType);
         break;
   }
   return true;
}
