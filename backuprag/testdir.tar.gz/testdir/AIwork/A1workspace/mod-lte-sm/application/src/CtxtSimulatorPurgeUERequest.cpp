#include <CtxtSimulatorPurgeUERequest.h>
#include <stdio.h>
#include <Logger.h>
#include <MapMessages.h>
#include <ServiceCoordinator.h>
#include <DbActiveObject.h>
#include <Utilities.h>
#include <ExtendedServiceCoordinator.h>
#include <HlrTdrFiller.h>
#include <TdrData.h>
#include <DiameterConstants.h>
//#include <s6a_stats.h>
#include <diameter/s6a_r10/PurgeUE.h>
//#include <diameter/s6a_r10/S6aAVP.h>
#include <diameter/base/BaseAVP.h>
#include <DiametriqInterface.h>

//CommandCode for PurgeUERequest/Answer 321

using namespace diameter::s6a_r10;

CtxtSimulatorPurgeUERequest::CtxtSimulatorPurgeUERequest()
{
}


CtxtSimulatorPurgeUERequest::~CtxtSimulatorPurgeUERequest()
{

}

bool CtxtSimulatorPurgeUERequest::startProcessing()
{
   unsigned int sIdx;
   string sessIdString;
   if(false == g_esc.allocateSession(DIAM_APP_ID_S6A_S6D, sIdx, sessIdString))
   {
      ELOG(0,1,"Unable to allocate a session");
      return false;
   }

   LLOG(0,0,"STARTPROCESSING PUR Session Id : %s", (char*)sessIdString.c_str());

   DiameterMsg l_test((char*)sessIdString.c_str(), DIAM_EVENT_REQUEST, DIAM_COMM_CODE_S6A_S6D_PUR_PUA);
   l_test.m_commandCode = DIAM_COMM_CODE_S6A_S6D_PUR_PUA;

   //prepare a PUR request
   diameter::s6a_r10::PurgeUERequest *l_purr = new diameter::s6a_r10::PurgeUERequest;
   l_purr->setSessionId(diameter::base::SessionId(diameter::base::SessionId(sessIdString)));
   l_purr->setSessionIndex(sIdx);

   VendorSpecificApplicationId vendorSpecAppId;
   VendorId vendorId(10415);
   vendorSpecAppId.addVendorId(vendorId);
   l_purr->setVendorSpecificApplicationId(vendorSpecAppId);

   AuthSessionState authSessionState(AuthSessionState::NO_STATE_MAINTAINED);
   l_purr->setAuthSessionState(authSessionState);

   OriginHost originHost = diameter::base::OriginHost("S6AServer"); //valid one
   //OriginHost originHost = diameter::base::OriginHost("S6Server");
   l_purr->setOriginHost(originHost);

   OriginRealm originRealm("MME");
   l_purr->setOriginRealm(originRealm);

   DestinationRealm destinationRealm("HSS");
   l_purr->setDestinationRealm(destinationRealm);

   DestinationHost destinationHost("HSSServer");
   l_purr->setDestinationHost(destinationHost);

   //UserName username("999998888888888");
   //UserName username("10");
   //UserName username("1004");
   //UserName username("090909090909090");
   
   //UserName username("100447404002792"); //
   //UserName username("800447404000");
   UserName username("700447404000088"); //valid imsi
   l_purr->setUserName(username);

   SupportedFeatures suppFeatures;
   VendorId vendorIdSup(10415);
   suppFeatures.setVendorId(vendorIdSup);
   FeatureListID featureListId(1);
   suppFeatures.setFeatureListID(featureListId);
   FeatureList featurList(67110415);
   suppFeatures.setFeatureList(featurList);
   l_purr->addSupportedFeatures(suppFeatures);

   //Route-Record
   //RouteRecord m_routerecord("record");
   //l_purr->addRouteRecord(m_routerecord);


   //PURFlags purflags(1);
   //l_purr->setPURFlags(purflags);

   //Proxy-Info
   //ProxyInfo m_proxyInfo("xyz");
   //l_purr->addProxyInfo(m_proxyInfo);

   //AVP

   l_test.m_cmd = l_purr;
   l_test.m_allocatedFlag = true;

   LLOG(0,0,"STARTPROCESSING PUR before send ");
   g_esc.sendMsg(this, &l_test);

   return true;
}


bool CtxtSimulatorPurgeUERequest::processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag)
{
   DLOG(0,0,"Start of CtxtSimulatorPurgeUERequest::processMsg function");

   p_DeleteFlag = p_DeleteFlag;

   MapSpecificMsg *l_specMsg = NULL;

   switch(p_MsgPtr->m_MsgType)
   {
      case MSG_TYPE_MAP:
         {
            DLOG(0,0,"MAP message received");
         }
         break;

      case MSG_TYPE_DIAMETER:
         {
            LLOG(0,0,"DIAMETER message received");

            DiameterMsg *l_dm = (DiameterMsg*)p_MsgPtr;

            if(NULL != l_dm->m_cmd)
            {
               if(false == l_dm->m_allocatedFlag)
               {
                  CLOG(0,0,"S6A PURR received is NULL. Sending Unexpected Data...");
                  //handleError(12,DIAM_EXP_RESULT_CODE_UNABLE_TO_COMPLY);
                  //m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_EXP_RESULT_CODE_UNABLE_TO_COMPLY);
               }
               else
               {
                  DLOG(0,0,"AllocatedFlag is true ");
               }
            }
            else
            {
               LLOG(0,0,"No PurgeUERequest message found");
            }
         }
         break;

      case MSG_TYPE_DB:
         {
            DLOG(0,0,"DB message received");
         }
         break;

      case MSG_TYPE_TIMEOUT:
         {
            LLOG(0,0,"Timeout received");
         }
         break;

      default :
         DLOG(0,0,"Unknown message received %d", p_MsgPtr->m_MsgType);
         break;

   }
   return true;
}

