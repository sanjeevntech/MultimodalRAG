#ifndef __CONTEXT_DIAM_PURGE_UE_REQUEST_H
#define __CONTEXT_DIAM_PURGE_UE_REQUEST_H

#include <ContextBase.h>
#include <Msg.h>
#include <LteSmDbQueries.h>
#include <DiameterMessages.h>

enum NodeTypeIndicator
{
   MME = 0,
   SGSN = 1,
   MMESGSN = 2,
   UNKNOWN
};

enum EErrorDiagnostic
{
   ERROR_DIAGNOSTIC_NOT_REQUIRED=-1,
   ERROR_DIAGNOSTIC_GPRS_DATA_SUBSCRIBED=0,
   ERROR_DIAGNOSTIC_NO_GPRS_DATA_SUBSCRIBED,
   ERROR_DIAGNOSTIC_ODB_ALL_APN,
   ERROR_DIAGNOSTIC_ODB_HPLMN_APN,
   ERROR_DIAGNOSTIC_ODB_VPLMN_APN
};

class CtxtLtePurgeUERequest : public ContextBase
{
   private:
      PurgeDbData *mp_purgeuereq;
      Msg *m_msgPtr;

   public:
      CtxtLtePurgeUERequest();
      ~CtxtLtePurgeUERequest();

      char m_imsi[16+1];
      char m_hss_originhost[100+1];
      char m_hss_originrealm[100+1];
      char m_mmehost[MMEHOST_SIZE+1];
      char m_mmerealm[MMEREALM_SIZE+1];
      int  m_actpartnernetId;
      int  m_actfeatlist1;
      int  m_actfeatlist2;
      int  m_s6arelease;
      unsigned int m_PURFlag;
      //1- matched with both SGSN,MME so set both PUA Flags M-TMSI and P-TMSI
      //2- matched with MME but not with SGSN so set PUA Flag M-TMSI and clear P-TMSI
      //3- matched with SGSN but not with MME so set PUA Flag P-TMSI and clear M-TMSI
      //4- not matched with SGSN and MME so clear PUA Flags P-TMSI and M-TMSI

      bool processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag);
      bool handleError(unsigned int aVendorId, unsigned int aErrCode, EErrorDiagnostic p_ed);
      bool SendPurgeUEAnswer(bool MMEHostFlag); //added in rev1 for MME-Identity mismatch case send +ve resp
      bool handlePurgeDbData();

      //reqtoperform == true -> reading //reqtoperform == false -> update
      void SendDBRequest();

};

#endif
