#ifndef __MY_SIMULATOR_H
#define __MY_SIMULATOR_H

#include <SelfSimulator.h>

class MySimulator : public SelfSimulator
{
   public:
      MySimulator();
      ~MySimulator();

   bool getMessage(int p_opCode, Msg **p_msgPtr, Msg *p_ReqMsgPtr);
};


#endif
