#ifndef __CONTEXT_DIAM_RESET_REQUEST_H
#define __CONTEXT_DIAM_RESET_REQUEST_H

#include <ContextBase.h>
#include <Msg.h>
#include <LteSmDbQueries.h>
#include <SubsProfileData.h>

enum EErrDiagnostic
{
   ERR_DIAGNOSTIC_NOT_REQUIRED=-1,
   ERR_DIAGNOSTIC_GPRS_DATA_SUBSCRIBED=0,
   ERR_DIAGNOSTIC_NO_GPRS_DATA_SUBSCRIBED,
   ERR_DIAGNOSTIC_ODB_ALL_APN,
   ERR_DIAGNOSTIC_ODB_HPLMN_APN,
   ERR_DIAGNOSTIC_ODB_VPLMN_APN
};

class CtxtLteResetRequest : public ContextBase
{
   private:

   public:

      CtxtLteResetRequest();
      ~CtxtLteResetRequest();

      char m_TransId[21+1];
      int  m_imsiCount;
      string m_imsi[50+1];
      char m_type[50+1];
      char m_originhost[100+1];
      char m_originrealm[100+1];
      char m_desthost[100+1];
      char m_destrealm[100+1];
      int m_suppFeature1;
      int m_suppFeature2;
      int m_s6arelease;
      bool preResetMsg(char *p_req);
      bool startProcessing(InterModuleData *p_imd, bool& p_DeleteFlag);
      bool processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag);
};

#endif
