#ifndef __CONTEXT_SIMULATOR_PURGE_UE_REQUEST_H
#define __CONTEXT_SIMULATOR_PURGE_UE_REQUEST_H

/*#ifndef _PurgeUE_H_
#define _PurgeUE_H_ */

#include <ContextBase.h>
#include <Msg.h>
#include <LteSmDbQueries.h>
#include <DiameterMessages.h>

/*enum NodeTypeIndicator
{
   MME = 0,
   SGSN = 1,
   MMESGSN = 2,
   UNKNOWN
};*/

class CtxtSimulatorPurgeUERequest : public ContextBase
{
   private:

   public:

      CtxtSimulatorPurgeUERequest();
      ~CtxtSimulatorPurgeUERequest();

      bool startProcessing();
      bool processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag);

};

#endif
