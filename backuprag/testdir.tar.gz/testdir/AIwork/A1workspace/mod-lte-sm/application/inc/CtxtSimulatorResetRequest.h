#ifndef __CONTEXT_SIMULATOR_RESET_REQUEST_H
#define __CONTEXT_SIMULATOR_RESET_REQUEST_H


#include <ContextBase.h>
#include <Msg.h>
#include <LteSmDbQueries.h>
#include <DiameterMessages.h>

class CtxtSimulatorResetRequest : public ContextBase
{
   private:

   public:

      CtxtSimulatorResetRequest();
      ~CtxtSimulatorResetRequest();

      bool startProcessing();
      bool processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag);

};

#endif
