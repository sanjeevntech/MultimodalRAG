#ifndef __LTE_SM_DB_QUERIES_H
#define __LTE_SM_DB_QUERIES_H

#include <DbQueryMsg.h>

#define IMSILEN              15
#define MAX_ERR_LEN          200
#define MMEHOST_SIZE         100
#define MMEREALM_SIZE        100


class PurgeDbData : public DbQueryMsg
{
   public:
      PurgeDbData();
      ~PurgeDbData();

      
      //Inputs
      char m_IMSI[IMSILEN+1];
      char m_recvdOriginHost[100+1];


      //Outputs
      char m_acthlrAdd[20+1];
      int  m_activepartnernetId;
      int  m_setFlag;
      char m_MMEHost[100+1];
      char m_MMErealm[100+1];
      int  m_activefeatlist_1;
      int  m_activefeatlist_2;
      char m_HSS_OriginHost[100+1];
      char m_HSS_OriginRealm[100+1];
      int  m_s6arelease;
      int  m_ErrCode;
      char m_ErrorMsg[MAX_ERR_LEN+1];
      int m_nwid;


      bool executeQuery(void*);
};

#endif
