#ifndef __NOTIFY_QUERY_H
#define __NOTIFY_QUERY_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>

using namespace std;

#define MAXSTRLENGTH 1024
#define MAX_NUMBER_OF_QUERIES 3
#define MAX_SIZE_OF_QUERY  1200


class NotifyQuery
{
    protected:
        char m_sqlquery[MAX_SIZE_OF_QUERY];

    public:
        NotifyQuery();
        virtual void  callbackinitialize(char *p_table,char *p_rowid, char p_type)=0;
        void setDbQuery(char* l_str);
        char* getDbQuery();
};


#endif

