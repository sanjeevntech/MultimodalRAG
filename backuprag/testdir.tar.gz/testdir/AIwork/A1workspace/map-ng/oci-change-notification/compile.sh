ORACLE_HOME=/ora10gclnt/product/10.2.0/client/
LD_LIBRARY_PATH=$ORACLE_HOME/lib/
/usr/sfw/bin/gcc -fPIC -c -I$ORACLE_HOME/rdbms/demo -I$ORACLE_HOME/rdbms/public -I$ORACLE_HOME/plsql/public -I$ORACLE_HOME/network/public -I. -D_REENTRANT -DSS_64BIT_SERVER -DBIT64 -DMACHINE64  -DSLMXMX_ENABLE -DSLTS_ENABLE -D_SVID_GETTOD -D_REENTRANT -L$ORACLE_HOME/lib -lclntsh  -m64 OciCallBack.c

/usr/sfw/bin/gcc -fPIC -c -I. -I$ORACLE_HOME/rdbms/demo -I$ORACLE_HOME/rdbms/public -I$ORACLE_HOME/plsql/public -I$ORACLE_HOME/network/public -I. -D_REENTRANT -DSS_64BIT_SERVER -DBIT64 -DMACHINE64  -DSLMXMX_ENABLE -DSLTS_ENABLE -D_SVID_GETTOD -D_REENTRANT -L$ORACLE_HOME/lib -lclntsh  -m64 NotifyQuery.cpp

/usr/sfw/bin/gcc -fPIC -c -I. -I$ORACLE_HOME/rdbms/demo -I$ORACLE_HOME/rdbms/public -I$ORACLE_HOME/plsql/public -I$ORACLE_HOME/network/public -I. -D_REENTRANT -DSS_64BIT_SERVER -DBIT64 -DMACHINE64  -DSLMXMX_ENABLE -DSLTS_ENABLE -D_SVID_GETTOD -D_REENTRANT -L$ORACLE_HOME/lib -lclntsh  -m64 DbChangeNotification.cpp

/usr/sfw/bin/gcc  -o liboci-cn.so -shared -I$ORACLE_HOME/rdbms/demo -I$ORACLE_HOME/rdbms/public -I$ORACLE_HOME/db_1/plsql/public -I$ORACLE_HOME/network/public -I. -D_REENTRANT -DSS_64BIT_SERVER -DBIT64 -DMACHINE64  -DSLMXMX_ENABLE -DSLTS_ENABLE -D_SVID_GETTOD -D_REENTRANT -L$ORACLE_HOME/lib -lclntsh  -m64 OciCallBack.o NotifyQuery.o DbChangeNotification.o
