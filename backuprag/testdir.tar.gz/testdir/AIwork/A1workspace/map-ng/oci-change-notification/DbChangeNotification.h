#ifndef __DB_CHANGE_NOTIFICATION_H
#define __DB_CHANGE_NOTIFICATION_H

#include <NotifyQuery.h>

#define MAX_CONNECTION_STRING 50

 




class DbChangeNotification
{
    private:
        char m_serverName[MAX_CONNECTION_STRING];
        char m_userName[MAX_CONNECTION_STRING];
        char m_userPassword[MAX_CONNECTION_STRING];

    public:
        DbChangeNotification();
        ~DbChangeNotification();

        NotifyQuery *m_NotifyQuery[MAX_NUMBER_OF_QUERIES];
        int  m_queryCount;
        void setConnectionString(char* l_serverName,char* l_userName,char* l_userPassword);
        char* getServerName();
        char* getUserName();
        char* getPassword();
        bool initialize();
        bool addDbQuery(NotifyQuery *l_NotifyQuery);
};

extern DbChangeNotification g_DbChangeNotification;

#endif
