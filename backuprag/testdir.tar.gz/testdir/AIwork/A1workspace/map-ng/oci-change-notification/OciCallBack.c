#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <oci.h>
 
#define MAXSTRLENGTH 1024

extern void test(char *table_name,char* table_rowid);
extern char* reurnServerName();
extern char* returnUserName();
extern char* returnPassword();

	
 
void checkerr(OCIError *errhp, sword status)
{
    text errbuf[512];
    sb4 errcode = 0;
    int retval = 1;

    switch (status)
    {
        case OCI_SUCCESS:
            retval = 0;
            break;
        case OCI_SUCCESS_WITH_INFO:
            (void) printf("Error - OCI_SUCCESS_WITH_INFO\n");
            break;
        case OCI_NEED_DATA:
            (void) printf("Error - OCI_NEED_DATA\n");
            break;
        case OCI_NO_DATA:
            //(void) printf("Error - OCI_NODATA\n");
            break;
        case OCI_ERROR:
            (void) OCIErrorGet((dvoid *)errhp, (ub4) 1, (text *) NULL, &errcode,
            errbuf, (ub4) sizeof(errbuf), OCI_HTYPE_ERROR);
            (void) printf("Error - %.*s\n", 512, errbuf);
            break;
        case OCI_INVALID_HANDLE:
            (void) printf("Error - OCI_INVALID_HANDLE\n");
            break;
        case OCI_STILL_EXECUTING:
            (void) printf("Error - OCI_STILL_EXECUTE\n");
            break;
        case OCI_CONTINUE:
            (void) printf("Error - OCI_CONTINUE\n");
            break;
        default:
            break;
    }
}


void ociCallback(dvoid *ctx, OCISubscription *subscrhp, dvoid *payload, ub4 *payl, dvoid *descriptor, ub4 mode)
{
    printf("\nmy_notification_callback called\n\n");
    dvoid *change_descriptor =  descriptor;
    ub4   notify_type;
    OCIEnv *envhp;
    OCIError *errhp;
    OCIServer *srvhp;
    OCISvcCtx *svchp;
    OCISession *usrhp;
    OCIStmt *stmthp;
    dvoid *tmp;

    dvoid *elemind = (dvoid *)0;
    OCIColl *table_changes = (OCIColl  *)0 ;  
    /* Collection of pointers to table chg descriptors */
    dvoid **table_descp;          /* Pointer to Table Change Descriptor */
    dvoid *table_desc;              /*  Table Change Descriptor */
    ub4 num_rows = 0;
    ub4 table_op;
    ub4 num_tables = 0;
    ub2 i, j;
    boolean exist;
    text *table_name;

    printf("Received Notification\n");



    /* Initialize environment and allocate Error Handle. 
    Note that the environment has to be initialized in object mode
    since we might be operating on collections.
    */
    OCIEnvCreate( (OCIEnv **) &envhp, OCI_OBJECT, (dvoid *)0,
                    (dvoid * (*)(dvoid *, size_t)) 0,
                    (dvoid * (*)(dvoid *, dvoid *, size_t))0,
                    (void (*)(dvoid *, dvoid *)) 0,
                    (size_t) 0, (dvoid **) 0 );

    OCIHandleAlloc( (dvoid *) envhp, (dvoid **) &errhp, OCI_HTYPE_ERROR,
                    (size_t) 0, (dvoid **) 0);

    /* Get the Notification Type */
    checkerr(errhp,
        OCIAttrGet( change_descriptor, OCI_DTYPE_CHDES, &notify_type, NULL, 
        OCI_ATTR_CHDES_NFYTYPE, errhp));

    if (notify_type == OCI_EVENT_SHUTDOWN)
        printf("Shutdown Notification\n");
    else if (notify_type == OCI_EVENT_DEREG)
        printf("Registration Removed\n");

    if (notify_type != OCI_EVENT_OBJCHANGE)
    {
        OCIHandleFree((dvoid *)envhp, OCI_HTYPE_ENV);
        OCIHandleFree((dvoid *)errhp, OCI_HTYPE_ERROR);
        return;
    }

    /* The below code is only executed if the notification is of type
    OCI_EVENT_OBJCHANGE
    */
    /* server contexts */
    OCIHandleAlloc( (dvoid *) envhp, (dvoid **) &srvhp, 
        OCI_HTYPE_SERVER,
        (size_t) 0, (dvoid **) 0);
    OCIHandleAlloc( (dvoid *) envhp, (dvoid **) &svchp, 
        OCI_HTYPE_SVCCTX,
        (size_t) 0, (dvoid **) 0);

    /* Allocate a statement handle */
    OCIHandleAlloc( (dvoid *) envhp, (dvoid **) &stmthp,
         (ub4) OCI_HTYPE_STMT, 52, (dvoid **) &tmp);

    /* set attribute server context in the service context */
    OCIAttrSet( (dvoid *) svchp, (ub4) OCI_HTYPE_SVCCTX, (dvoid *)srvhp,
             (ub4) 0, (ub4) OCI_ATTR_SERVER, (OCIError *) errhp);

    checkerr(errhp, OCIServerAttach( srvhp, errhp, (text *)reurnServerName(), (sb4)strlen((char*)reurnServerName()), 
              (ub4) OCI_DEFAULT));

    /* allocate a SESSION  handle */
    OCIHandleAlloc((dvoid *)envhp, (dvoid **)&usrhp, (ub4) OCI_HTYPE_SESSION,
             (size_t) 0, (dvoid **) 0);

    OCIAttrSet((dvoid *)usrhp, (ub4)OCI_HTYPE_SESSION, 
                (dvoid *)((text *)returnUserName()),
                (ub4)strlen((char *)returnUserName()),  OCI_ATTR_USERNAME, errhp);

    OCIAttrSet((dvoid *)usrhp, (ub4)OCI_HTYPE_SESSION,
                (dvoid *)((text *)returnPassword()), (ub4)strlen((char *)returnPassword()),
                OCI_ATTR_PASSWORD, errhp);

    checkerr(errhp,OCISessionBegin (svchp, errhp, usrhp, OCI_CRED_RDBMS,
                OCI_DEFAULT));
                OCIAttrSet((dvoid *)svchp, (ub4)OCI_HTYPE_SVCCTX,
                (dvoid *)usrhp, (ub4)0, OCI_ATTR_SESSION, errhp);

    /* Obtain the collection of table change descriptors */
    checkerr(errhp,OCIAttrGet(change_descriptor, OCI_DTYPE_CHDES, &table_changes, 
            NULL, OCI_ATTR_CHDES_TABLE_CHANGES, errhp));

    /* Obtain the size of the collection (i.e number of tables modified) */
    if (table_changes)
        checkerr(errhp,OCICollSize(envhp, errhp, (CONST OCIColl *) table_changes,
        &num_tables));
    else
        num_tables =0;


    printf("number of table changes %d \n",num_tables);

    /* For each element of the collection, extract the table name of the modified
    table */
    for (i=0; i < num_tables; i++)
    {
        OCIColl *row_changes = (OCIColl  *)0;
        /* Collection of pointers to row chg. Descriptors */
        dvoid **row_descp;            /*  Pointer to Row Change Descriptor */
        dvoid   *row_desc;               /*   Row Change Descriptor */
        text *row_id;
        ub4 rowid_size;
        text *ocistmt;
        OCIDefine *defnp1 = (OCIDefine *)0;
        char *outstr;

        checkerr(errhp,OCICollGetElem(envhp, errhp, (OCIColl *) table_changes, i, 
                &exist, &table_descp, &elemind));

        table_desc = *table_descp;
        checkerr(errhp,OCIAttrGet(table_desc, OCI_DTYPE_TABLE_CHDES, &table_name, 
                    NULL,
                    OCI_ATTR_CHDES_TABLE_NAME, errhp));

        printf("table name %s\n",table_name);
        // if (strcmp(table_name, "test_oci.EMPLOYEES") == 0)
        // printf("EMPLOYEE table modified \n");
        //else if (strcmp(table_name, "test_oci.DEPARTMENTS") == 0)
        // printf("DEPARTMENTS table modified \n");

        checkerr(errhp,OCIAttrGet (table_desc, OCI_DTYPE_TABLE_CHDES, 
                    (dvoid *)&table_op, NULL,
                    OCI_ATTR_CHDES_TABLE_OPFLAGS, errhp));

        /* If the ROWID granularity of info not available, move-on. Rowids
        can be rolled up into a full table notification if too many rows
        were updated on a single table or insufficient shared memory on
        the server side to hold rowids
        */
        if (table_op & OCI_OPCODE_ALLROWS)
        {
            printf("Full Table Invalidation\n");
            continue;   
        }

        if(table_op & OCI_OPCODE_INSERT)
        {
            printf("Row  inserted into table\n");

            checkerr(errhp,OCIAttrGet (table_desc, OCI_DTYPE_TABLE_CHDES, &row_changes,
            NULL, OCI_ATTR_CHDES_TABLE_ROW_CHANGES, errhp));

            if (row_changes)
                checkerr(errhp,OCICollSize(envhp, errhp, row_changes, &num_rows));
            else
                num_rows =0;

            printf ("Number of rows modified is %d\n", num_rows);
            fflush(stdout);
            for (j=0; j<num_rows; j++)
            {
                OCICollGetElem(envhp, errhp, (OCIColl *) row_changes,
                j, &exist, &row_descp, &elemind);
                row_desc = *row_descp;

                OCIAttrGet (row_desc, OCI_DTYPE_ROW_CHDES, (dvoid *)&row_id,
                &rowid_size, OCI_ATTR_CHDES_ROW_ROWID, errhp);
                printf ("%s table has been modified in row %s \n", table_name, row_id);

                registeredTable(table_name,row_id, 'I');

                fflush(stdout);
                ocistmt = (text *)malloc(MAXSTRLENGTH*sizeof(char));
                /*

                // QUERY FROM DATABASE TO VIEW CONTENTS OF CHANGED ROW 
                sprintf (ocistmt, "select * from %s where rowid='%s'", table_name, row_id);
                printf("Executing stmt %s\n", ocistmt);

                // prepare query statement
                checkerr(errhp,OCIStmtPrepare(stmthp, errhp, ocistmt, 
                (ub4)strlen((char *)ocistmt),
                (ub4)OCI_NTV_SYNTAX, (ub4)OCI_DEFAULT));
                outstr = (char *)malloc(MAXSTRLENGTH*sizeof(char));

                checkerr(errhp,OCIDefineByPos(stmthp, &defnp1, errhp, 1, (dvoid *)outstr, 
                MAXSTRLENGTH * sizeof(char),
                SQLT_STR, (dvoid *)0, (ub2 *)0, (ub2 *)0, 
                OCI_DEFAULT)); 

                // execute the statement 
                checkerr(errhp,OCIStmtExecute(svchp, stmthp, errhp, (ub4)1, (ub4) 0, 
                (CONST OCISnapshot *) NULL, 
                (OCISnapshot *) NULL, OCI_DEFAULT));

                printf("First column of modified row is %s\n", outstr);
                */
            }  /* Loop for j in 1..numrows */
        }
        else  if(table_op & OCI_OPCODE_DELETE)
        {
            printf("Row deleted from table\n");


            checkerr(errhp,OCIAttrGet (table_desc, OCI_DTYPE_TABLE_CHDES, &row_changes,
            NULL, OCI_ATTR_CHDES_TABLE_ROW_CHANGES, errhp));

            if (row_changes)
                checkerr(errhp,OCICollSize(envhp, errhp, row_changes, &num_rows));
            else
                num_rows =0;

            printf ("Number of rows modified is %d\n", num_rows);
            fflush(stdout);
            for (j=0; j<num_rows; j++)
            {
                OCICollGetElem(envhp, errhp, (OCIColl *) row_changes,
                j, &exist, &row_descp, &elemind);
                row_desc = *row_descp;

                OCIAttrGet (row_desc, OCI_DTYPE_ROW_CHDES, (dvoid *)&row_id,
                &rowid_size, OCI_ATTR_CHDES_ROW_ROWID, errhp);
                printf ("%s table has been modified in row %s \n", table_name, row_id);

                registeredTable(table_name,row_id, 'D');

                /*
                fflush(stdout);
                ocistmt = (text *)malloc(MAXSTRLENGTH*sizeof(char));

                // QUERY FROM DATABASE TO VIEW CONTENTS OF CHANGED ROW 
                sprintf (ocistmt, "select * from %s where rowid='%s'", table_name, row_id);
                printf("Executing stmt %s\n", ocistmt);

                // prepare query statement
                checkerr(errhp,OCIStmtPrepare(stmthp, errhp, ocistmt, 
                (ub4)strlen((char *)ocistmt),
                (ub4)OCI_NTV_SYNTAX, (ub4)OCI_DEFAULT));
                outstr = (char *)malloc(MAXSTRLENGTH*sizeof(char));

                checkerr(errhp,OCIDefineByPos(stmthp, &defnp1, errhp, 1, (dvoid *)outstr, 
                MAXSTRLENGTH * sizeof(char),
                SQLT_STR, (dvoid *)0, (ub2 *)0, (ub2 *)0, 
                OCI_DEFAULT)); 

                // execute the statement 
                checkerr(errhp,OCIStmtExecute(svchp, stmthp, errhp, (ub4)1, (ub4) 0, 
                (CONST OCISnapshot *) NULL, 
                (OCISnapshot *) NULL, OCI_DEFAULT));

                printf("First column of modified row is %s\n", outstr);
                */
            }  
        }
        else if(table_op & OCI_OPCODE_UPDATE)
        {
            printf("row updated in Table\n");

            checkerr(errhp,OCIAttrGet (table_desc, OCI_DTYPE_TABLE_CHDES, &row_changes,
            NULL, OCI_ATTR_CHDES_TABLE_ROW_CHANGES, errhp));

            if (row_changes)
                checkerr(errhp,OCICollSize(envhp, errhp, row_changes, &num_rows));
            else
                num_rows =0;

            printf ("Number of rows modified is %d\n", num_rows);
            fflush(stdout);
            for (j=0; j<num_rows; j++)
            {
                OCICollGetElem(envhp, errhp, (OCIColl *) row_changes,
                j, &exist, &row_descp, &elemind);
                row_desc = *row_descp;

                OCIAttrGet (row_desc, OCI_DTYPE_ROW_CHDES, (dvoid *)&row_id,
                &rowid_size, OCI_ATTR_CHDES_ROW_ROWID, errhp);
                printf ("%s table has been modified in row %s \n", table_name, row_id);


                registeredTable(table_name,row_id, 'U');
                /*

                fflush(stdout);
                ocistmt = (text *)malloc(MAXSTRLENGTH*sizeof(char));

                // QUERY FROM DATABASE TO VIEW CONTENTS OF CHANGED ROW 
                sprintf (ocistmt, "select * from %s where rowid='%s'", table_name, row_id);
                printf("Executing stmt %s\n", ocistmt);

                // prepare query statement
                checkerr(errhp,OCIStmtPrepare(stmthp, errhp, ocistmt, 
                (ub4)strlen((char *)ocistmt),
                (ub4)OCI_NTV_SYNTAX, (ub4)OCI_DEFAULT));
                outstr = (char *)malloc(MAXSTRLENGTH*sizeof(char));

                checkerr(errhp,OCIDefineByPos(stmthp, &defnp1, errhp, 1, (dvoid *)outstr, 
                MAXSTRLENGTH * sizeof(char),
                SQLT_STR, (dvoid *)0, (ub2 *)0, (ub2 *)0, 
                OCI_DEFAULT)); 

                // execute the statement 
                checkerr(errhp,OCIStmtExecute(svchp, stmthp, errhp, (ub4)1, (ub4) 0, 
                (CONST OCISnapshot *) NULL, 
                (OCISnapshot *) NULL, OCI_DEFAULT));

                printf("First column of modified row is %s\n", outstr);
                */
            }
        }
        else
        {
        printf("no change to table\n");
        }
    }


    /* End session and detach from server */
    checkerr(errhp, OCISessionEnd(svchp, errhp, usrhp, OCI_DEFAULT));
    checkerr(errhp, OCIServerDetach(srvhp, errhp, OCI_DEFAULT));
    if (stmthp)
        OCIHandleFree((dvoid *)stmthp, OCI_HTYPE_STMT);
    if (errhp)
        OCIHandleFree((dvoid *)errhp, OCI_HTYPE_ERROR);
    if (srvhp)
        OCIHandleFree((dvoid *)srvhp, OCI_HTYPE_SERVER);
    if (svchp)
        OCIHandleFree((dvoid *)svchp, OCI_HTYPE_SVCCTX);
    if (usrhp)
        OCIHandleFree((dvoid *)usrhp, OCI_HTYPE_SESSION);
    if (envhp)
        OCIHandleFree((dvoid *)envhp, OCI_HTYPE_ENV);

}




