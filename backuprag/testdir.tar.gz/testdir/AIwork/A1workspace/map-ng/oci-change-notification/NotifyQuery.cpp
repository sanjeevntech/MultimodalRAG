#include <NotifyQuery.h>
#include <oci.h>

NotifyQuery::NotifyQuery()
{  
    memset(m_sqlquery, '\0', MAX_SIZE_OF_QUERY);
}

void NotifyQuery::setDbQuery(char* l_str)
{
    memcpy(m_sqlquery,l_str,strlen(l_str));
}

char* NotifyQuery::getDbQuery()
{
    return m_sqlquery;
}
