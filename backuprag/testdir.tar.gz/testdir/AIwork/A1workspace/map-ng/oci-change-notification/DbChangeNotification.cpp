#include <DbChangeNotification.h>
#include <oci.h>


extern "C"
{
   extern void registeredTable(char *table_name,char* table_rowid, char type);
   extern char* reurnServerName();
   extern char* returnUserName();
   extern char* returnPassword();
   void checkerr(OCIError *errhp,sword status);
   void ociCallback(dvoid *ctx,OCISubscription *subscrhp,dvoid *payload,ub4 * payl,dvoid *descriptor,ub4  mode);
}

DbChangeNotification g_DbChangeNotification;

char* reurnServerName()
{
   g_DbChangeNotification.getServerName();
}

char* returnUserName()
{
   g_DbChangeNotification.getUserName();
}

char* returnPassword()
{
   g_DbChangeNotification.getPassword();
}



void registeredTable(char *p_table_name,char* table_rowid, char p_type)
{
   printf("\n Table Name and Rowid  [%s]  [%s]", p_table_name, table_rowid);
   int temp_count=0;

   char *l_temp=NULL;
   l_temp = strchr(p_table_name, '.');
   int l_removeLength=0;
   if(l_temp != NULL)
   {
      l_removeLength = strlen(p_table_name) - strlen(l_temp) + 1;
   }

   char table_name[50];
   memset(table_name, '\0', 50);
   strncpy(table_name, p_table_name+l_removeLength, strlen(p_table_name) - l_removeLength);

   for(temp_count=0;temp_count<g_DbChangeNotification.m_queryCount;temp_count++)
   {
      char* ch;
      ch=strstr(g_DbChangeNotification.m_NotifyQuery[temp_count]->getDbQuery(),table_name);
      if(ch!=NULL)
      {
         if ('I' == p_type)
         {
            g_DbChangeNotification.m_NotifyQuery[temp_count]->callbackinitialize(table_name, table_rowid, p_type);
            printf("\ntable name is.......... %s\n",ch);
            printf("\nprint table name.......%s\n",ch);
         }
         else
         {
            printf("\nIgnoring Notification %c", p_type);
         }
         return;
      }
      else
      {
         continue;
         printf("table_name is not assigned for notification\n");
      }
   }
}

char* DbChangeNotification::getServerName()
{
   return m_serverName;
}

char* DbChangeNotification::getUserName()
{
   return m_userName;
}

char* DbChangeNotification::getPassword()
{
   return m_userPassword;
}

DbChangeNotification::DbChangeNotification()
{
   m_queryCount=0;
   memset(m_serverName, '\0', MAX_CONNECTION_STRING+1);
   memset(m_userName, '\0', MAX_CONNECTION_STRING+1);
   memset(m_userPassword, '\0', MAX_CONNECTION_STRING+1);
}

DbChangeNotification::~DbChangeNotification()
{
}

void DbChangeNotification::setConnectionString(char* l_serverName,char* l_userName,char* l_userPassword)
{
   memcpy(m_serverName,l_serverName,strlen(l_serverName));
   memcpy(m_userName,l_userName,strlen(l_userName));
   memcpy(m_userPassword,l_userPassword,strlen(l_userPassword));
}



bool DbChangeNotification::addDbQuery(NotifyQuery *l_NotifyQuery)
{
   if (m_queryCount < MAX_NUMBER_OF_QUERIES)
   {
      this->m_NotifyQuery[m_queryCount]=l_NotifyQuery;
      m_queryCount++;
      //printf("No of querry %d\n",m_queryCount);
   }
   else
   {
      printf("\nERROR!! Unable to add the Db query into the query list");
      return false;
   }
   return true;
}



bool DbChangeNotification::initialize()
{
   if (m_queryCount<1)
   {
      printf("\nERROR!! No Queries to be registered. Please use the addDbQuery function to add query registrations");
      return false;
   }
   //printf("\nDbChangeNotification::initialize\n");

   OCISvcCtx *svchp;
   OCIError *errhp;
   OCISession *usrhp;
   OCIStmt *stmthp;
   OCIEnv *envhp;
   OCIServer *srvhp;
   text *username;
   OCISubscription *subscrhp;
   ub4 namespace1 = OCI_SUBSCR_NAMESPACE_DBCHANGE;
   ub4 timeout = 18000;
   text dname[MAXSTRLENGTH];
   OCIDefine *defnp1 = (OCIDefine *)0;
   OCIDefine *defnp2 = (OCIDefine *)0;
   OCIDefine *defnp3 = (OCIDefine *)0;
   OCIDefine *defnp4 = (OCIDefine *)0;
   OCIDefine *defnp5 = (OCIDefine *)0;
   int mgr_id =0;
   int dept_id =0;
   dvoid *tmp;
   boolean rowids_needed = TRUE;
   sword l_status;

   /* Initialize the environment. The environment has to be initialized
      with OCI_EVENTS and OCI_OBJECTS to create a change notification
      registration and receive notifications.
      */

   OCIEnvCreate( (OCIEnv **) &envhp, OCI_EVENTS|OCI_OBJECT, (dvoid *)0,
         (dvoid * (*)(dvoid *, size_t)) 0,
         (dvoid * (*)(dvoid *, dvoid *, size_t))0,
         (void (*)(dvoid *, dvoid *)) 0,
         (size_t) 0, (dvoid **) 0 );



   OCIHandleAlloc( (dvoid *) envhp, (dvoid **) &errhp, OCI_HTYPE_ERROR,
         (size_t) 0, (dvoid **) 0);

   /* server contexts */

   OCIHandleAlloc((dvoid *) envhp, (dvoid **) &srvhp, OCI_HTYPE_SERVER, 
         (size_t) 0,
         (dvoid **) 0);


   OCIHandleAlloc( (dvoid *) envhp, (dvoid **) &svchp, OCI_HTYPE_SVCCTX,
         (size_t) 0, (dvoid **) 0);



   checkerr(errhp,OCIServerAttach( srvhp, errhp, (text *)m_serverName ,(sb4) strlen((char *)m_serverName),(ub4) OCI_DEFAULT));


   OCIHandleAlloc( (dvoid *) envhp, (dvoid **) &svchp, (ub4) OCI_HTYPE_SVCCTX,52,(dvoid **)0);


   /* set attribute server context in the service context */

   OCIAttrSet( (dvoid *) svchp, (ub4) OCI_HTYPE_SVCCTX, (dvoid *)srvhp,(ub4) 0, (ub4) OCI_ATTR_SERVER, (OCIError *) errhp);


   //printf("\nDbChangeNotification::initialize 1\n");
   /* allocate a user context handle */

   OCIHandleAlloc((dvoid *)envhp, (dvoid **)&usrhp, (ub4) OCI_HTYPE_SESSION,(size_t) 0, (dvoid **) 0);

   OCIAttrSet((dvoid *)usrhp, (ub4)OCI_HTYPE_SESSION,
         (dvoid *)((text *)m_userName), (ub4)strlen((char *)m_userName),OCI_ATTR_USERNAME, errhp);

   OCIAttrSet((dvoid *)usrhp, (ub4)OCI_HTYPE_SESSION,
         (dvoid *)((text *)m_userPassword), (ub4)strlen((char *)m_userPassword),OCI_ATTR_PASSWORD, errhp);

   //printf("\nDbChangeNotification::initialize 2\n");
   l_status = OCISessionBegin (svchp, errhp, usrhp, OCI_CRED_RDBMS,OCI_DEFAULT);
   checkerr(errhp, l_status);
   if(l_status != OCI_SUCCESS)
   {
      printf("\nInitialization failed\n");
      return false;
   }

   /* Allocate a statement handle */

   OCIHandleAlloc( (dvoid *) envhp, (dvoid **) &stmthp,(ub4) OCI_HTYPE_STMT, 52, (dvoid **) &tmp);

   OCIAttrSet((dvoid *)svchp, (ub4)OCI_HTYPE_SVCCTX, (dvoid *)usrhp, (ub4)0,OCI_ATTR_SESSION, errhp);

   /* allocate subscription handle */

   OCIHandleAlloc ((dvoid *) envhp, (dvoid **) &subscrhp, OCI_HTYPE_SUBSCRIPTION,
         (size_t) 0,
         (dvoid **) 0);
   //printf("Allocated handles\n");

   //printf("\nDbChangeNotification::initialize 3\n");

   /* set the namespace to DBCHANGE */
   OCIAttrSet(subscrhp, OCI_HTYPE_SUBSCRIPTION,(dvoid *)&namespace1,sizeof(ub4),OCI_ATTR_SUBSCR_NAMESPACE, errhp);
   /* Associate a notification callback */
   OCIAttrSet (subscrhp, OCI_HTYPE_SUBSCRIPTION,(void *)ociCallback,  0, OCI_ATTR_SUBSCR_CALLBACK, errhp);



   /* Allow extraction of rowid information */
   checkerr(errhp, OCIAttrSet (subscrhp, OCI_HTYPE_SUBSCRIPTION,
            (dvoid *)&rowids_needed, sizeof(ub4), 
            OCI_ATTR_CHNF_ROWIDS, errhp));

   /* Set a timeout value of half an hour */
   OCIAttrSet(subscrhp, OCI_HTYPE_SUBSCRIPTION, (dvoid *)&timeout, 0, OCI_ATTR_SUBSCR_TIMEOUT, errhp);

   //printf("\nDbChangeNotification::initialize 4\n");
   //Adding for filtering the insert
   OCIAttrSet(subscrhp, OCI_ATTR_CHNF_OPERATIONS, (dvoid *)0, 0, OCI_OPCODE_INSERT, errhp);
   //End of addition

   //printf("\nDbChangeNotification::initialize 5\n");
   /* Create a new registration in the  DBCHANGE namespace */
   l_status = OCISubscriptionRegister(svchp, &subscrhp, 1, errhp, OCI_DEFAULT);
   checkerr(errhp, l_status);
   if(l_status != OCI_SUCCESS)
   {
      printf("\nUnable to register\n");
      return false;
   }
   //printf("\nDbChangeNotification::initialize 6\n");

   //printf("Created Registration\n");
   int n_no_of_quries=0;
   for(n_no_of_quries=0;n_no_of_quries<m_queryCount;n_no_of_quries++)
   {
      ub4 stmlen=strlen(m_NotifyQuery[n_no_of_quries]->getDbQuery());
      checkerr(errhp,OCIStmtPrepare (stmthp, errhp,(const OraText*) m_NotifyQuery[n_no_of_quries]->getDbQuery(),
               stmlen,OCI_V7_SYNTAX, OCI_DEFAULT));
      checkerr(errhp,OCIDefineByPos(stmthp, &defnp1, errhp, 2, (dvoid *)&mgr_id, 
               sizeof(mgr_id), SQLT_INT, (dvoid *)0, 
               (ub2 *)0, (ub2 *)0, OCI_DEFAULT));
      /* Associate the statement with the subscription handle */
      checkerr(errhp,OCIAttrSet (stmthp, OCI_HTYPE_STMT, subscrhp, 0, OCI_ATTR_CHNF_REGHANDLE, errhp));
      printf("\n\t           . Initializing query...", m_NotifyQuery[n_no_of_quries]->getDbQuery());

      /* Execute the statement The execution of the statement  performs the object
         registration */
      checkerr(errhp,OCIStmtExecute (svchp, stmthp, errhp, (ub4) 1, (ub4) 0,
               (CONST OCISnapshot *) NULL, (OCISnapshot *) NULL ,
               OCI_DEFAULT));

      printf("\n\t           . Registering Query %s", m_NotifyQuery[n_no_of_quries]->getDbQuery());
   }

   //printf("\nDbChangeNotification::initialize 8\n");
#if 0

   /* Unregister the subscription */

   checkerr(errhp,OCISubscriptionUnRegister(svchp,subscrhp, errhp, OCI_DEFAULT));

   /* End the session and detach from the server */
   checkerr(errhp, OCISessionEnd(svchp, errhp, usrhp, (ub4) 0));
   checkerr(errhp, OCIServerDetach(srvhp, errhp, (ub4) OCI_DEFAULT));

   /* Free all the handles */
   OCIHandleFree((dvoid *)subscrhp, OCI_HTYPE_SUBSCRIPTION);
   OCIHandleFree((dvoid *)stmthp, OCI_HTYPE_STMT);
   OCIHandleFree((dvoid *) srvhp, (ub4) OCI_HTYPE_SERVER);
   OCIHandleFree((dvoid *) svchp, (ub4) OCI_HTYPE_SVCCTX);
   OCIHandleFree((dvoid *) usrhp, (ub4) OCI_HTYPE_SESSION);
   OCIHandleFree((dvoid *) errhp, (ub4) OCI_HTYPE_ERROR);
   OCIHandleFree((dvoid *) envhp, (ub4) OCI_HTYPE_ENV);
#endif 

   return true;
}






