#ifndef __MAP_MESSAGES_H
#define __MAP_MESSAGES_H

#include <iostream>
#include <vector>
#include <string>
#include <Msg.h>
#ifdef ULCM_SP5
#include <PlintronSccpAddr.h>
#elif ULCM_SP6
#include <PlintronSccpAddr_SP6.h>
#else
#error "ULCM version undefined"
#endif
#include <MapConstants.h>


#define MAX_EXT_CONTAINTER_BUFFER_SIZE  200

class MplManager;
class ServiceCoordinator;


// Start of Messsages from MAP1.h

typedef struct MAP_IsdnAddressString {
    unsigned short  length;
    unsigned char   value[9];
} MAP_IsdnAddressString;

typedef struct MAP_IMSI {
    unsigned short  length;
    unsigned char   value[8];
} MAP_IMSI;

typedef struct MAP_BeginSubscriberActivityArg {
    MAP_IMSI      imsi;
    MAP_IsdnAddressString originatingEntityNumber;
} MAP_BeginSubscriberActivityArg;

// End of Messages from MAP1.h

// Start of Messages from MAP2.h
// These messages are brought for holding the User Information in the MAP Messages from the TCAP Dialogue Portion
// 

typedef struct MAP_DP__octet1 {
   unsigned short  length;
   unsigned char   value[20];
} MAP_DP__octet1;

typedef struct MAP_DP_OpenInfo {
   unsigned char   bit_mask;
#       define      MAP_DP_OpenInfo_destinationReference_present 0x80
#       define      MAP_DP_OpenInfo_originationReference_present 0x40
   MAP_DP__octet1    destinationReference;  /* optional; set in bit_mask
                                             * MAP_DP_OpenInfo_destinationReference_present if
                                             * present */
   MAP_DP__octet1    originationReference;  /* optional; set in bit_mask
                                             * MAP_DP_OpenInfo_originationReference_present if
                                             * present */
} MAP_DP_OpenInfo;

typedef struct MAP_DP_AcceptInfo {
   char            placeholder;
} MAP_DP_AcceptInfo;

typedef struct MAP_DP_CloseInfo {
   char            placeholder;
} MAP_DP_CloseInfo;

typedef enum MAP_DP_Reason {
   MAP_DP_Reason_noReasonGiven = 0,
   MAP_DP_Reason_invalidDestinationReference = 1,
   MAP_DP_Reason_invalidOriginatingReference = 2
} MAP_DP_Reason;

typedef struct MAP_DP_RefuseInfo {
   MAP_DP_Reason     reason;
} MAP_DP_RefuseInfo;

typedef enum MAP_DP_ResourceUnavailableReason {
   MAP_DP_ResourceUnavailableReason_shortTermResourceLimitation = 0,
   MAP_DP_ResourceUnavailableReason_longTermResourceLimitation = 1
} MAP_DP_ResourceUnavailableReason;

typedef enum MAP_DP_ProcedureCancellationReason {
   MAP_DP_ProcedureCancellationReason_handoverCancellation = 0,
   MAP_DP_ProcedureCancellationReason_radioChannelRelease = 1,
   MAP_DP_ProcedureCancellationReason_networkPathRelease = 2,
   MAP_DP_ProcedureCancellationReason_callRelease = 3,
   MAP_DP_ProcedureCancellationReason_associatedProcedureFailure = 4,
   MAP_DP_ProcedureCancellationReason_tandemDialogueRelease = 5,
   MAP_DP_ProcedureCancellationReason_remoteOperationsFailure = 6
} MAP_DP_ProcedureCancellationReason;

typedef struct MAP_DP_UserAbortChoice {
   unsigned short  choice;
#       define      MAP_DP_UserAbortChoice_userSpecificReason_chosen 1
#       define      MAP_DP_UserAbortChoice_userResourceLimitation_chosen 2
#       define      MAP_DP_UserAbortChoice_resourceUnavailable_chosen 3
#       define      MAP_DP_UserAbortChoice_applicationProcedureCancellation_chosen 4
   union _union {
      char        userSpecificReason;  /* to choose, set choice to
                                        * MAP_DP_UserAbortChoice_userSpecificReason_chosen */
      char        userResourceLimitation;  /* to choose, set choice to
                                            * MAP_DP_UserAbortChoice_userResourceLimitation_chosen */
      MAP_DP_ResourceUnavailableReason     resourceUnavailable;  /* to choose, set choice to
                                                                  * MAP_DP_UserAbortChoice_resourceUnavailable_chosen */
      MAP_DP_ProcedureCancellationReason     applicationProcedureCancellation;  /* to choose, set
                                                                                 * choice to
                                                                                 * MAP_DP_UserAbortChoice_applicationProcedureCancellation_chosen */
   } u;
} MAP_DP_UserAbortChoice;


typedef struct MAP_DP_UserAbortInfo {
   MAP_DP_UserAbortChoice   map_UserAbortChoice;
} MAP_DP_UserAbortInfo;


typedef enum MAP_DP_ProviderAbortReason {
   MAP_DP_ProviderAbortReason_abnormalDialogue = 0,
   MAP_DP_ProviderAbortReason_invalidPDU = 1
} MAP_DP_ProviderAbortReason;


typedef struct MAP_DP_ProviderAbortInfo {
   MAP_DP_ProviderAbortReason     map_ProviderAbortReason;
} MAP_DP_ProviderAbortInfo;


typedef struct MAP_DP_DialoguePDU {
   unsigned short  choice;
#       define      MAP_DP_map_open_chosen 1
#       define      MAP_DP_map_accept_chosen 2
#       define      MAP_DP_map_close_chosen 3
#       define      MAP_DP_map_refuse_chosen 4
#       define      MAP_DP_map_userAbort_chosen 5
#       define      MAP_DP_map_providerAbort_chosen 6
   union _union {
      MAP_DP_OpenInfo map_open;
      MAP_DP_AcceptInfo map_accept;
      MAP_DP_CloseInfo map_close;
      MAP_DP_RefuseInfo map_refuse;
      MAP_DP_UserAbortInfo map_userAbort;
      MAP_DP_ProviderAbortInfo map_providerAbort;
   } u;
} MAP_DP_DialoguePDU;



// End of Messages from MAP2.h


#define MAX_COMP_BUFFER_SIZE  200

enum EMapCloseType
{
   MAP_CLOSE_TYPE_UNKNOWN = 0,
   MAP_CLOSE_TYPE_PRE_ARRANGED_END,
   MAP_CLOSE_TYPE_BASIC
};

enum EMapClosePreArrangedReason
{
   MAP_CLOSE_PRE_ARRANGED_REASON_FAILURE = 0,
   MAP_CLOSE_PRE_ARRANGED_REASON_SUCCESS
};

enum EMapMsgType
{
   MAP_MSG_TYPE_UNKNOWN = 0,
   MAP_MSG_TYPE_COMMON,
   MAP_MSG_TYPE_SPECIFIC
};


enum EMapCommonMsgType
{
   MAP_CMN_UNKNOWN = 200,
   MAP_CMN_OPEN_REQ,
   MAP_CMN_OPEN_IND,
   MAP_CMN_OPEN_RSP,
   MAP_CMN_OPEN_CNF,
   MAP_CMN_CLOSE_REQ,
   MAP_CMN_CLOSE_IND,
   MAP_CMN_DELIMITER_REQ,
   MAP_CMN_DELIMITER_IND,
   MAP_CMN_U_ABORT_REQ,
   MAP_CMN_U_ABORT_IND,
   MAP_CMN_P_ABORT_REQ,
   MAP_CMN_P_ABORT_IND,
   MAP_CMN_NOTICE_IND
};



enum EMapSpecificEventType
{
   MAP_SPEC_EVENT_UNKNOWN = 0,
   MAP_SPEC_EVENT_REQUEST,
   MAP_SPEC_EVENT_INDICATION,
   MAP_SPEC_EVENT_RESULT,
   MAP_SPEC_EVENT_CONFIRMATION,
   MAP_SPEC_EVENT_USER_ERROR,
   MAP_SPEC_EVENT_PROV_ERROR
};


enum EMapLastComponentIndicator
{
   MAP_SPEC_LAST_COMPONENT_IND_UNKNOWN = 0,
   MAP_SPEC_LAST_COMPONENT_IND_NOT_LAST,
   MAP_SPEC_LAST_COMPONENT_IND_LAST
};


enum EMapProvErrorRejectType
{
   MAP_PROV_ERROR_REJECT_TYPE_UNKNOWN = 0,
   MAP_PROV_ERROR_REJECT_TYPE_U_CANCEL,
   MAP_PROV_ERROR_REJECT_TYPE_L_REJECT,
   MAP_PROV_ERROR_REJECT_TYPE_R_REJECT,
   MAP_PROV_ERROR_REJECT_TYPE_U_REJECT
};

enum EMapProvError
{
   MAP_PROV_ERROR_UNKNOWN=0,
   MAP_PROV_ERROR_DUPLICATED_INVOKE_ID,
   MAP_PROV_ERROR_NOT_SUPPORTED_SERVICE,
   MAP_PROV_ERROR_MISTYPED_PARAMETER,
   MAP_PROV_ERROR_RESOURCE_LIMITATION,
   MAP_PROV_ERROR_INITIATING_RELEASE, 
   MAP_PROV_ERROR_UNEXPECTED_RESPONSE_FROM_THE_PEER,
   MAP_PROV_ERROR_SERVICE_COMPLETION_FAILURE,
   MAP_PROV_ERROR_NO_RESPONSE_FROM_THE_PEER,
   MAP_PROV_ERROR_INVALID_RESPONSE_RECEIVED 
};   


enum ERefuseReason
{
   REFUSE_REASON_UNKNOWN,
   REFUSE_REASON_OTHER,
   REFUSE_REASON_APPL_CNTXT_NOT_SUPPORTED,
   REFUSE_REASON_REMOTE_NODE_NOT_REACHABLE,
   REFUSE_REASON_POTENTIAL_VERSION_INCOMPAT
};

enum ENoticeProblem
{
   NOTICE_PROBLEM_UNKNOWN,
   NOTICE_PROBLEM_ABNORMAL_EVENT_DETECTED_BY_THE_PEER,
   NOTICE_PROBLEM_RESPONSE_REJECTED_BY_THE_PEER,
   NOTICE_PROBLEM_ABNORMAL_EVENT_RECEIVED_FROM_THE_PEER,
   NOTICE_PROBLEM_MESSAGE_CANNOT_BE_DELIVERED_TO_THE_PEER
};



class MapMsg : public Msg
{
   public:
      MapMsg();
      MapMsg(EMapMsgType, EMapVersion);
      virtual ~MapMsg();

      char *getMsgTypeName();

      EMapMsgType m_MapMsgType;
      EMapVersion m_Version;
};


class MapCommonMsg : public MapMsg
{
   public:
      MapCommonMsg();
      MapCommonMsg(EMapCommonMsgType);

      EMapCommonMsgType           m_MapCommonMsgType; // This would be OPEN_REQ, OPEN_IND, CLOSE etc
      char *getMapCommonMsgTypeName();
      virtual ~MapCommonMsg();
};



class MapOpenRequests : public MapCommonMsg
{
   public:
      MapOpenRequests(EMapCommonMsgType);
      virtual ~MapOpenRequests();

      EMapApplicationContext  m_ApplCntxt;
      MAP_DP_OpenInfo         m_OpenInfo;

      L_SccpAddress m_OrigAddr;
      L_SccpAddress m_DestAddr;
};


class MapOpenReq : public MapOpenRequests 
{
   public:
      MapOpenReq(int, EMapVersion);
      ~MapOpenReq();
};

class MapOpenInd : public MapOpenRequests
{
   public:
      MapOpenInd();
      ~MapOpenInd();

      bool m_componentsPresentFlag;
};


class MapOpenResponses : public MapCommonMsg
{
   public:
      MapOpenResponses(EMapCommonMsgType);
      virtual ~MapOpenResponses();

      bool m_ResponseChoiceFlag; // True for Accept, False otherwise

      ERefuseReason           m_RefuseReasonParam;
      EMapApplicationContext  m_ApplCntxt;

      L_SccpAddress m_OrigAddr;
      L_SccpAddress m_DestAddr;

};

class MapOpenRsp : public MapOpenResponses
{
   public:
      MapOpenRsp();
      ~MapOpenRsp();
};

class MapOpenCnf : public MapOpenResponses
{
   public:
      MapOpenCnf();
      ~MapOpenCnf();
};

class MapClose : public MapCommonMsg
{
   public:
      MapClose(EMapCommonMsgType);
      virtual ~MapClose();
};

class MapCloseReq : public MapClose
{
   public:
      MapCloseReq(int);
      ~MapCloseReq();

      EMapCloseType m_CloseType;
      EMapClosePreArrangedReason    m_PreArrangedReason; //To write better stats
};

class MapCloseInd : public MapClose
{
   public:
      MapCloseInd();
      ~MapCloseInd();
};

class MapDelimiterReq : public MapCommonMsg
{
   public:
      MapDelimiterReq(int);
      ~MapDelimiterReq();
};

class MapDelimiterInd : public MapCommonMsg
{
   public:
      MapDelimiterInd();
      ~MapDelimiterInd();

};

class MapNoticeInd : public MapCommonMsg
{
   public:
      MapNoticeInd();
      ~MapNoticeInd();

      ENoticeProblem m_NoticeProblem;
};


class MapUAbort : public MapCommonMsg
{
   public:
      unsigned char m_AbortCause;
      unsigned char m_AbortReason;
      MapUAbort(EMapCommonMsgType);
      virtual ~MapUAbort();
};

class MapUAbortReq : public MapUAbort
{
   public:
      MapUAbortReq(int);
      ~MapUAbortReq();
      int m_versionRejected;
};

class MapUAbortInd : public MapUAbort
{
   public:
      MapUAbortInd();
      ~MapUAbortInd();
};


class MapPAbort : public MapCommonMsg
{
   public:
      MapPAbort(EMapCommonMsgType);
      virtual ~MapPAbort();
};


class MapPAbortReq : public MapPAbort
{
   public:
      MapPAbortReq();
      ~MapPAbortReq();
};

class MapPAbortInd : public MapPAbort
{
   public:
      MapPAbortInd();
      ~MapPAbortInd();
};

class MapSpecificMsg : public MapMsg
{
   public:
      MapSpecificMsg();
      MapSpecificMsg(EMapSpecificEventType, EMapVersion);
      virtual ~MapSpecificMsg();

      char *getMapSpecifigEventTypeName();

      int m_InvokeId;
      EMapOpCode                  m_OpCode;                // OP Code of the Message
      EMapSpecificEventType       m_MapSpecificEventType;  

      int           m_bufLen;
      unsigned char m_buffer[MAX_COMP_BUFFER_SIZE];

      bool          m_allocatedFlag;
      char          m_ioflag; //Added to understand whether 'I' or 'O'
      void         *m_structBuffer;

      char          m_extensionContainerBuffer[MAX_EXT_CONTAINTER_BUFFER_SIZE];

      friend class MplManager;
      friend class ServiceCoordinator;

};


class MapSpecificRequest : public MapSpecificMsg
{
   public:
      MapSpecificRequest(int, EMapOpCode, EMapVersion);
      virtual ~MapSpecificRequest();

      int m_LinkedId;
      int m_TimerValue;
};

class MapSpecificIndication : public MapSpecificMsg
{
   public:
      MapSpecificIndication(EMapOpCode);
      virtual ~MapSpecificIndication();

      EMapLastComponentIndicator m_lci;
};

class MapSpecificResult : public MapSpecificMsg
{
   public:
      MapSpecificResult(int, EMapOpCode, EMapVersion);
      virtual ~MapSpecificResult();
      bool m_LastFlag;
};

class MapSpecificConfirmation : public MapSpecificMsg
{
   public:
      MapSpecificConfirmation(EMapOpCode);
      virtual ~MapSpecificConfirmation();
      bool m_LastFlag;
      EMapLastComponentIndicator m_lci; //Indicates whether this is the Last Component in the TCAP packet
};


class MapProviderErrorMsg : public MapSpecificMsg
{
   public:
      MapProviderErrorMsg();
      ~MapProviderErrorMsg();

      EMapProvError m_MapProvErrorCode;
      EMapProvErrorRejectType m_rejectType;
      int           m_problemType; 
      int           m_problemCode; 
};

class MapUserError : public MapSpecificMsg
{
   public:
      MapUserError(int, EMapErrorCode, EMapVersion, void *p_structBuffer);
      ~MapUserError();

      EMapErrorCode m_ErrorCode;
      EMapLastComponentIndicator m_lci;
};



extern bool initializeAsnCodecs();
extern int g_MapAsnRes[100][3];
extern int g_MapAsnReq[100][3];
extern bool configureSccpAddress(L_SccpAddress *p_addr, int p_RoutingType, int p_pc, int p_ssn, char *p_gt, L_SccpNumberingPlan p_snp=L_NP_ISDN);

#endif
