#ifndef __MSG_H
#define __MSG_H

#define MAX_PROTOCOL_TYPES 10

enum EMsgType
{
   MSG_TYPE_UNKNOWN = 0,
   MSG_TYPE_MAP,
   MSG_TYPE_DB,
   MSG_TYPE_CNTXT,
   MSG_TYPE_TIMEOUT,
   MSG_TYPE_PROV,
   MSG_TYPE_SMPP,
   MSG_TYPE_DIAMETER,
   MSG_TYPE_MEMCACHED,
   MSG_TYPE_SCCP
};

class Msg
{
   public:
      Msg();
      Msg(EMsgType p_MsgType);
      virtual ~Msg();

      int         m_DlgId;  ///to be removed later
      int         m_UserDlgId;

      EMsgType m_MsgType;
};

#endif
