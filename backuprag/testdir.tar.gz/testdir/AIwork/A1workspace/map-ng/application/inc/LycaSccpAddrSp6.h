/*
  Revision:  $Revision:/main/sw9/5 $ $Date:17-Sep-2008 16:41:48 $
*/
/*******************************************************************************
 *                                 					       *
 *                       Ulticom, Inc.                                         *
 *               Copyright 2001 All Rights Reserved.                           *
 *                                                                             *
 *       These computer program listings and specifications, herein,           *
 *       are the property of Ulticom, Inc. and shall not be                    *
 *       reproduced or copied or used in whole or in part as the basis         *
 *       for manufacture or sale of items without written permission.          *
 *                                                                             *
 *                                                                             *
 * File:      sccp_addr.h                                                      *
 * Author:    Xavier Fabre                                                     *
 * Created:   $Revision:/main/sw9/5 $ $Date:17-Sep-2008 16:41:48 $
 * Description:                                                                *
 *                                                                             *
 *******************************************************************************/

#ifndef SCCP_ADDR_H
#define SCCP_ADDR_H
/*#include <QSource.h>
#ifndef _KERNEL
#include <sys/types.h>
#include <netinet/in.h>
#endif

#if defined(LINUX) && defined(__KERNEL__)
#include <sys/stream.h>
#include <netinet/in.h>
#endif

#if defined(sun) && defined(_KERNEL)
#include <netinet/in.h>
#endif*/

typedef int L_BOOL;
typedef unsigned char L_U8;
typedef unsigned short int L_U16;

/* This is the maximum size of the erro message formated if a failure occurs
   during encoding or decodin an sccp address */
#define L_SCCP_ADDR_ERROR_MSG_SIZE   256

/* This is the maximum number of digits that compose an address information */
#define L_MAX_GTI_LENGTH             256

/* This is the maximum length of an sccp address encoded in a byte array */
#define L_SCCP_ADDR_MAX_SIZE   255

/*
 * Constant: _MAXSCCPADR
 *  Purpose:  Define the max SCCP address size
 */
#define L__MAXSCCPADR 60
/*
 * Constant: 
 *  Purpose:  Define max size of buffer  handling string address*/

        /* cr16694 - this value is equivalent to               */
	/*         '#define SCCP_ADDR_BUFFER_LENGTH' statement */
	/*          of the 'sccpaddrdump.c' file               */

#define L__MAXSCCPBUF 1024


/*
  This interface implements Sccp address encode/decode capability
  as specified in following documents:

  C7: Q.713 - chapter 3.4
  A7: ANSI T1.112-1996
  J7: J7/Q.713 - chapter 3.4
*/


/* 
   GT_0000:
    There is no global title included

   GT_0001:
    - Translation Type for A7  
    - Numbering Plan for A7  
    - Encoding Scheme for A7  
    - Nature of Address Indicator for C7/CH7/J7 
   
    The nature of address indicator for GT0001, only uses bits 1 to 7 for its coding, 
    therefore bit 8 of the octet contains the even/odd indicator which is coded as 0 
    for even or 1 for odd number of address_signals/digits/numbers. 
    
   GT_0010:
    - Translation Type for A7/C7/CH7/J7

   GT_0011:
    This value of GT is not assigned for A7
    - Translation Type for C7/CH7/J7  
    - Numbering Plan for C7/CH7/J7  
    - Encoding Scheme for C7/CH7/J7  
    
   GT_0100:
    This value of GT is not assigned for A7
    - Translation Type for C7/CH7/J7  
    - Numbering Plan for C7/CH7/J7  
    - Encoding Scheme for C7/CH7/J7  
    - Nature of Address Indicator for C7/CH7/J7 

   Other GT indicator values are spare.
   For those values the global title is considered to contain only address information
   with a encoding scheme unknown. The number of digit must be even otherwise it is not
   possible to know if a 0000 quartet is the digit 0 or a filler. 
*/
typedef enum {
  L_GT_0000        = 0x0,
  L_GT_0001        = 0x1,
  L_GT_0010        = 0x2,
  L_GT_0011        = 0x3,
  L_GT_0100        = 0x4,
  L_GT_SPARE_INT_5 = 0x5,
  L_GT_SPARE_INT_6 = 0x6,
  L_GT_SPARE_INT_7 = 0x7,
  L_GT_SPARE_NAT_8 = 0x8,
  L_GT_SPARE_NAT_9 = 0x9,
  L_GT_SPARE_NAT_A = 0xA,
  L_GT_SPARE_NAT_B = 0xB,
  L_GT_SPARE_NAT_C = 0xC,
  L_GT_SPARE_NAT_D = 0xD,
  L_GT_SPARE_NAT_E = 0xE,
  L_GT_RESERVED    = 0xF
} L_SccpGlobalTitleIndicator;



/* BEGIN CR17273 */
/**
typedef enum {
  ROUTE_ON_GT     = 0x00,
  ROUTE_ON_PC_SSN = 0x40
} SccpRoutingIndicator;
Above conflict with the same defines for ROUTE_ON_GT and 
ROUTE_ON_PC_SSN in file sccp-int.h.
**/
#ifndef L_ROUTE_ON_GT
#define L_ROUTE_ON_GT	0x00
#endif

#ifndef L_ROUTE_ON_PC_SSN
#define L_ROUTE_ON_PC_SSN 0x40
#endif
#define L_ROUTE_ON_IP_SSN 0x80
#define L_ROUTE_ON_HOSTNAME_SSN 0x100

typedef int L_SccpRoutingIndicator;

/* END CR17273 */



typedef enum {
  L_NP_UNKNOWN      = 0x0,
  L_NP_ISDN         = 0x1,
  L_NP_GENERIC      = 0x2,
  L_NP_DATA         = 0x3,
  L_NP_TELEX        = 0x4,
  L_NP_MRTM_MOBILE  = 0x5,
  L_NP_LAND_MOBILE  = 0x6,
  L_NP_ISDN_MOBILE  = 0x7,
  L_NP_SPARE_8      = 0x8,
  L_NP_SPARE_9      = 0x9,
  L_NP_SPARE_A      = 0xA,
  L_NP_SPARE_B      = 0xB,
  L_NP_SPARE_C      = 0xC,
  L_NP_SPARE_D      = 0xD,
  L_NP_PRIVATE      = 0xE,
  L_NP_RESERVED     = 0xF
} L_SccpNumberingPlan;


typedef enum {
  L_ES_UNKNOWN      = 0x0,
  L_ES_BCD_ODD      = 0x1,
  L_ES_BCD_EVEN     = 0x2,
  L_ES_NAT_SPECIFIC = 0x3,
  L_ES_SPARE_4      = 0x4,
  L_ES_SPARE_5      = 0x5,
  L_ES_SPARE_6      = 0x6,
  L_ES_SPARE_7      = 0x7,
  L_ES_SPARE_8      = 0x8,
  L_ES_SPARE_9      = 0x9,
  L_ES_SPARE_A      = 0xA,
  L_ES_SPARE_B      = 0xB,
  L_ES_SPARE_C      = 0xC,
  L_ES_SPARE_D      = 0xD,
  L_ES_SPARE_E      = 0xE,
  L_ES_RESERVED     = 0xF
} L_SccpEncodingScheme;


/* 
   This reprensents the header octet of an Sccp address.
  
   C7/J7

    8     7     6     5     4     3    2     1    
   RNA    RI  --------- GTI --------- SSNI   PI    

   A7/CH7

    8     7     6     5     4     3    2     1    
   RNA    RI  --------- GTI ---------  PI   SSNI    

  Following abbrevations are used in the above diagrams:
  
   RNA:  Reserved for Natinal Use
   RI:   Routing Indicator
   GTI:  Global Title Indicator
   SSNI: Sub-System Number Indicator
   PI:   Point Code Indicator

*/

typedef struct {
  L_BOOL                       pointCodeIndicator;
  L_BOOL                       ssnIndicator;
  L_BOOL                       hostNameIndicator;
  L_BOOL                       ipAddressIndicator;
  L_SccpGlobalTitleIndicator   globalTitleIndicator;
  L_SccpRoutingIndicator       routingIndicator;
  L_BOOL                       nationalIndicator;
} L_SccpAddressIndicator;



/*
  Some nature of address indicator helper values 
*/
#define L_NA_UNKNOWN                     0x0
#define L_NA_SUSCRIBER_NUM               0x1
#define L_NA_RESERVED_FOR_NATIONAL_USE   0x2
#define L_NA_NATIONAL_SIGNIFANT_NUM      0x3
#define L_NA_INTERNATIONAL_NUM           0x4

/*
  The presence of SccpGlobalTitle fields is conditioned by the Global
  Title Indicator as it is explained above in SccpGlobalTitleIndicator
  comment.

  addressInformation string contains address signals or "digits" ranging from 0 to F.
  In this string 0 to 9 stands for digit 0 to digit 9.
  A is spare
  B is code 11
  C is code 12
  D is spare
  E is spare
  F is ST.
*/
typedef struct {
  L_U8                    natureOfAddressIndicator;
  L_U8                    translationType;
  L_SccpNumberingPlan     numberingPlan;
  L_SccpEncodingScheme    encodingScheme;
  L_U8                    addressInformationLength;
  char                  addressInformation[L_MAX_GTI_LENGTH];
} L_SccpGlobalTitle;


/*
  Point code definition for each protocol
*/

typedef struct {    /* displayed as network-cluster-member, but
			stored internally anyway we wish...      */
  U8 member;
  U8 cluster;
  U8 network;
} L_A7pointCode;

typedef struct {
  U16 value;       /* must be less than 16384 (14-bit value) */
} L_C7pointCode;

typedef struct {
  U16 value;       /* must be less than 65536 (16-bit value) */
} L_J7pointCode;

typedef struct {    /* displayed as network-cluster-member, but
                        stored internally anyway we wish...      */

  L_U8 member;
  L_U8 cluster;
  L_U8 network;
} L_CH7pointCode;





/*
  Some ssn helper values
*/
#define L_SSN_UNKNOWN            0x0
#define L_SSN_SCCP_MANAGMENT     0x1
#define L_SSN_ITU_T_ALLOC        0x2
#define L_SSN_ISDN_UP            0x3
#define L_SSN_OMAP               0x4
#define L_SSN_MAP                0x5
#define L_SSN_HLR                0x6
#define L_SSN_VLR                0x7
#define L_SSN_MSC                0x8
#define L_SSN_EIC                0x9
#define L_SSN_AUC                0xA
#define L_SSN_ISDN_SS            0xB
#define L_SSN_BROAD_ISDN         0xD
#define L_SSN_TEST_RESP          0xE

/* FR 1009 TTC SSN values */
#define L_SSN_SMLC_MAP           0x90
#define L_SSN_GMLC_MAP           0x91
#define L_SSN_CAP                0x92
#define L_SSN_GSM_SCF_MAP        0x93
#define L_SSN_SIWF_MAP           0x94
#define L_SSN_SGSN_MAP           0x95
#define L_SSN_GCSN_MAP           0x96
#define L_SSN_SMS                0xBD
#define L_SSN_RES_SIG_HANDL_APP  0xBE
#define L_SSN_DOM_INAP           0xBF

/*
  The structure hosting an sccp address
  ssn is optional. It exists only if ssnIndicator is positioned in addressIndicator.
  As a default ssn is set to SSN_UNKNOWN

  protocol has to be set by the library user application in the SccpAddress passed
  into sccpEncode, sccpDecode, sccpDumpBufferAddress because its value can not be 
  infered and the address processing highly depends on it.
*/
typedef struct {
  L_SccpAddressIndicator     addressIndicator;
    /* 
       Use A7_PROTOCOL
       or  C7_PROTOCOL
       or  J7_PROTOCOL
       or  CH7_PROTOCOL
    */
    L_U8                       protocol;
  union {
    L_A7pointCode            a7pointCode;
    L_C7pointCode            c7pointCode;
    L_J7pointCode            j7pointCode;
    L_CH7pointCode           ch7pointCode;
  } pointCode;
  L_U8                       ssn;
  L_SccpGlobalTitle          globalTitle;
  char                       dummy[100];
} L_SccpAddress;



#endif /* SCCP_ADDR_H */
