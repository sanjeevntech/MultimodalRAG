#ifndef __DB_QUERY_MSG_H
#define __DB_QUERY_MSG_H

#include <Msg.h>
#include <ContextBase.h>
#include <MemCachedQueryMsg.h>

typedef enum 
{
   DB_QUERY_RES_UNKNOWN=0,
   DB_QUERY_RES_SUCCESS,
   DB_QUERY_RES_ROWS_NOT_FOUND,
   DB_QUERY_RES_CODE_EXCEPTION
}EDbQueryRes;

typedef enum 
{
   DB_QUERY_CACHED_TYPE_NOT_CACHED,
   DB_QUERY_CACHED_TYPE_CACHED,
   DB_QUERY_CACHED_TYPE_ONLY_MEMCACHED_NO_DB
}EDbQueryCachedType;

typedef enum 
{
   DB_QUERY_TPS_COUNTABLE,
   DB_QUERY_TPS_NON_COUNTABLE
}EDbQueryTpsCountable;

typedef enum 
{
   DB_QUERY_QUEUE_TYPE_INITIAL,
   DB_QUERY_QUEUE_TYPE_LATER
}EDbQueryQueueType;

class DbQueryMsg: public MemCachedQueryMsg
{
   public:
      DbQueryMsg();
      virtual ~DbQueryMsg();
      virtual bool executeQuery(void*)=0;
      virtual void executeMemcQuery();
      virtual void serializeMemc();
      virtual bool deSerializeMemc();
      //virtual bool validateMemcachedContinuity();

      ContextBase *m_cb;
      EDbQueryRes m_DbQueryRes;
      EDbQueryCachedType m_DbQueryCachedType;
      EDbQueryTpsCountable m_DbQueryTpsCountable;
      EDbQueryQueueType m_DbQueryQueueType;
      char m_LoggingMsg[20+1];
      int m_DbQueryType;
      int m_sqlcode;
      int m_procErrorCode;
      char m_procErrorMessage[1000];
};

extern char g_entityName[10+1];

#endif
