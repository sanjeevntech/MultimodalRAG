/* ====e================================================================================
*        Filename:  ASNTags.h
*     Description:  
*         Version:  1.0.0
*         Created:  04/20/2008 11:25:11 AM IST
*         Author :   *         
*         Company:  Plintron Tech. Pvt. Ltd.
*         History:        
* ======================================================================================*/

#ifndef ASNTAGS_H
#define ASNTAGS_H

// TC Types Tags

#define TC_BEGIN_TAG    0x62
#define TC_END_TAG      0x64
#define TC_CONT_TAG     0x65
#define TC_ABRT_TAG     0x67

// Message Section Tags
#define OTID_TAG        0x48
#define DTID_TAG        0x49
#define DLG_PRTN_TAG    0x6B
#define COMP_PRTN_TAG   0x6C

#define MSISDN_TAG      0x80
#define MSISDN_TAG1     0x04
#define MSISDN_TAG2     0x81

#define SRI_SM_MSG    45

#endif // ASNTAGS_H
