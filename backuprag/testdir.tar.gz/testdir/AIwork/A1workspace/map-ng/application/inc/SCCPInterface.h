/*********************************************************************

 **********************************************************************

 ** FILE NAME    : SCCPInterface.h

 ** DEFINITION   : Class for interface with SS7 stack.


 *********************************************************************/



#ifndef SCCPINTERFACE_H
#define SCCPINTERFACE_H



#include <apiinc.h>
#include <tcap.h>
#include <tcerror.h>
#include <ObjectServer.h>
#include <ccapiproto.h>
#include <UniTypes.h>
#include "ASNTags.h"
using namespace std;

/***************************************************************************/

/*EJECT */

#define OC_NUMBER_TO_ADD 1      /* opcodes for the application */
#define OC_SUM 2
#define SUM_DATA_TAG 4          /* universal OCTETSTRING */
#define FIRSTMAP 1
#define SECONDMAP 2

/* called and calling addresses in BEGIN dialog handling primitive,
   according to CCITT Q.713 sec 3.4.  This form assumes address contains
   point code and subsystem number but not global title. */


class SCCPInterface
{
   SCCPInterface(){};

   public:
   //MsgDeQueue            *mp_MsgQueue;

   static SCCPInterface& getInstance();

   virtual ~SCCPInterface(){};    // destructor
   bool openConn(int, char**); // A wrapper for SS7_xifcreate
   int getInvoke(ctblock_t &prim);
   void serverHandleTCAP(void);
   int sendRecvMsgs();
   void handleError(u16 uid);
};

#endif // SCCPINTERFACE_H_
