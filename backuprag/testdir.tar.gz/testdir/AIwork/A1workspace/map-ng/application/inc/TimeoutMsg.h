#ifndef __TIMEOUT_MSG_H
#define __TIMEOUT_MSG_H

#include <Msg.h>
#include <ContextBase.h>

class TimeoutMsg : public Msg
{
   public:
      TimeoutMsg();
      ~TimeoutMsg();

      unsigned int m_dialogId;
      int          m_epoch;
      ContextBase  *m_cb;
      int          m_interval;
};

#endif

