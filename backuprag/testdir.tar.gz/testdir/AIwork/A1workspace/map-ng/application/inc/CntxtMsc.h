#ifndef __CNTXT_MSC_H
#define __CNTXT_MSC_H

#include <MapMessages.h>
#include <StatesMsc.h>
#include <ContextBase.h>
#include <ConcreteStateMsc.h>
#include <ContextManager.h>

/*enum EDialogueType
{
    DIALOGUE_INITIATOR=0,
    DIALOGUE_RESPONDER
};*/

class CntxtMsc
{
    public:
        MapMsg          *m_MapOpenIndPtr;
        MapMsg          *m_MapSpecificMsgIndPtr;
        EDialogueType   m_DialogueType;

        StatesMsc		*m_pState;
		ContextBase    *m_pRsc;

        bool            m_CanBeDeletedFlag;

    public:
        int              m_Provid;
        int              m_UserDlgId;
        ///-int              m_DlgId;
		bool			 m_otherPresent;

        void             setDeleteFlag(bool p_flag);

        CntxtMsc(EDialogueType p_DialogueType, MapMsg *p_MapOpenIndPtr, ContextBase *p_ContextBaseRscPtr);
        ~CntxtMsc();
		bool deleteRsc(); //Added after purify

        EDialogueType getDialogueType();

		bool ProcMsg(Msg *p_MapMsgPtr);

        void setSpecificMsgPtr(MapMsg *p_MapSpecMsgPtr);
		void setOpenIndPtr(MapMsg *p_MapSpecMsgPtr);

        MapMsg* getSpecificMsgPtr();

        MapMsg* getOpenIndPtr();

		EMapApplicationContext m_applCtxt;


	friend class WaitForSvcPrimitiveMsc;
	friend class RelayInfoMsc;
};

#endif
