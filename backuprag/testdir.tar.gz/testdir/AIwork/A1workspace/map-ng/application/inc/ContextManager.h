#ifndef __CONTEXT_MANAGER_H
#define __CONTEXT_MANAGER_H

#include <stdio.h>
#include <map>
#include <DialoguePool.h>

using namespace std;

enum EDialogueType
{
    DIALOGUE_INITIATOR=0,
    DIALOGUE_RESPONDER
};

class ContextManager
{
    private:
        // The MAPs and Dialogue Pools
        map <int, void*>    m_map;
        map <int, int>      m_rareHitMapResp;
        DialoguePool        m_dialoguePool;

		  EDialogueType      m_DialogueType; 

    public:
        // Constructor
        ContextManager();

        // Destructor
        ~ContextManager();

        // The Initializer
        bool initialize(int p_startDialogue, int p_MaxDialogues);

        // This is for the Dialogue Initiator
        int getNewDialogue();

        // This is for the Dialogue Responder
        int getNewDialogueR();

        // Context Storage and Retrieval functions
        bool storeContext (int p_UserId, void *p_CntxtMscPtr, EDialogueType p_DialogueType);
        bool getContext   (int p_UserId, void **p_CntxtMscPtr);
        bool removeContext(int p_UserId, EDialogueType p_DialogueType);

        void print();

        void getStats(char *p_output);

        int getSize();

        bool terminate();
};

extern ContextManager  g_ContextMangerObject;

#endif

