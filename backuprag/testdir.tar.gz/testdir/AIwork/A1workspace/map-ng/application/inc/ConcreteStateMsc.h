#ifndef __CONCRETE_STATE_MSC_H
#define __CONCRETE_STATE_MSC_H

#include <StatesMsc.h>
#include <CntxtMsc.h>

class WaitForSvcPrimitiveMsc : public StatesMsc
{
    public:
        WaitForSvcPrimitiveMsc();
        ~WaitForSvcPrimitiveMsc();

        StatesMsc* handle(CntxtMsc *p_CntxtMscPtr, Msg *);
};

class RelayInfoMsc :public StatesMsc
{
    public:
        RelayInfoMsc();
        ~RelayInfoMsc();

        StatesMsc* handle(CntxtMsc *p_CntxtMscPtr, Msg *);

};

extern MapOpenInd *g_currentOpenIndPtr;

#endif
