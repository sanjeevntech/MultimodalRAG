#ifndef __SMPP_MSG_H
#define __SMPP_MSG_H

#include <Msg.h>
#include <ContextBase.h>

class SmppMsg : public Msg
{
   public:
      SmppMsg();
      ~SmppMsg();
};

#endif

