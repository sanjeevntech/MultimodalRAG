#ifndef __STATES_MSC_H
#define __STATES_MSC_H

#include <MapMessages.h>

class CntxtMsc;

class StatesMsc
{
	protected:
		static StatesMsc* m_pStWaitForSvcPrimitiveMsc;
		static StatesMsc* m_pStRelayInfoMsc;

    public:
        StatesMsc();
        virtual ~StatesMsc();
        virtual StatesMsc* handle(CntxtMsc *p_CntxtMscPtr, Msg *p_MsgPtr);

        static  StatesMsc* setWaitForSvcPrimitiveState() 
        {
            return m_pStWaitForSvcPrimitiveMsc;
        } 

        static  StatesMsc* setRelayInfoMscState() 
        {
            return m_pStRelayInfoMsc;
        } 
};

#endif

