#ifndef __TCAP_STACK_H
#define __TCAP_STACK_H


extern int initializeUlticomTcapStack (int argc, char *argv[]);


#endif

