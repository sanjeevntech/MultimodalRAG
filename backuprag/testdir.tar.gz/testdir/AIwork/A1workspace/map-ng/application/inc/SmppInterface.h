#ifndef INCL_ESME_CLIENT_H
#define INCL_ESME_CLIENT_H

#include <iostream>
#include <stdio.h>
#include <string>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <map>
#include <EsmeConstDef.h>
#include <MessageQueue.h>
#include <pthread.h>

enum MsgStatus {
   MSG_SCHEDULED     = 0, 
   MSG_ENROUTE       = 1,
   MSG_DELIVERED     = 2, 
   MSG_EXPIRED       = 3, 
   MSG_DELETED       = 4, 
   MSG_UNDELIVERABLE = 5, 
   MSG_ACCEPTED      = 6, 
   MSG_UNKNOWN       = 7, 
   MSG_REJECTED      = 8, 
   MSG_SKIPPED       = 9
};


class SmppInterface
{
   bool     m_IsInitialized; // To identify weather ESMEClient is Initialized or not.
   static   SmppInterface *gSMPPClientObj; //Pointer to the singleton object of its own class.

   INT32                m_PortNum;

   struct sigaction     m_sa;
   struct sockaddr_in   serv_addr, client_addr;
   struct hostent       *server;
   pthread_mutex_t      m_send_mutex;

   public:

   SmppInterface();

   BOOLEAN   initSMPPClientObj();
   BOOLEAN   Initialize();
   BOOLEAN   Connect();
   BOOLEAN   CloseConnection();

   void      lockSend();
   void      unlockSend();

   MessageQueue *m_recvQ;

   static SmppInterface *getInstance();
};


class ESMEClient
{
   public:
      struct Esme_Data     m_ESMEData, *m_RespMsg;
      struct EsmePDU       m_EsmePdu;

      static INT32 m_ClientSocket;

      ESMEClient();
      ~ESMEClient();

      BOOLEAN   ReadMessage();
      BOOLEAN   SendMessage();
      int RecvAll(INT32 &s, TEXT *buf, UINT32 len);
      int SendAll(INT32 &s, char *buf, UINT32 &len);
      BOOLEAN   PrintPdu();

      BOOLEAN   EncodeCString(TEXT *lString);
      BOOLEAN   EncodeString(TEXT *lString);
      BOOLEAN   EncodeTLVString(UINT32 lTag, INT32, TEXT* lValue);
      BOOLEAN   EncodeInteger(UINT32 lValue, INT32 lBytes);
      BOOLEAN   EncodeHeader();
      UINT32    DecodeInteger(INT32 len);
      BOOLEAN   DecodeCString(TEXT *field);
      BOOLEAN   DecodeString(INT32 len, TEXT *field);
      BOOLEAN   DecodeHeader();

      TEXT *    ConvertESMEOperationToString(enum ESME_OPERATION l_Operation);

      BOOLEAN   Encode();
      BOOLEAN   EncodeSubmitSm();
      BOOLEAN   EncodeReplaceSm();
      BOOLEAN   EncodeQuerySm();
      BOOLEAN   EncodeCancelSm();
      BOOLEAN   EncodeEnquireLink();
      BOOLEAN   ProcessBindTransceiver();
      BOOLEAN   ProcessUnBind();  

      BOOLEAN   DecodeBindTransceiverResp();  
      BOOLEAN   DecodeSubmitSmResp();
      BOOLEAN   DecodeReplaceSmResp();
      BOOLEAN   DecodeQuerySmResp();
      BOOLEAN   DecodeCancelSmResp();
      BOOLEAN   DecodeEnquireLinkResp();

      BOOLEAN   DecodeDeliverSm();
      BOOLEAN   SendDeliverSmResp(INT16 l_CmdStatus=0);
      BOOLEAN   SendEnquireLinkResp();
};
int ConvertAscii2Gsm(int ascii);
void SignalsHandler(int lValue);

extern ESMEClient g_ec;
extern BOOLEAN    g_SmppConnection;

#endif
