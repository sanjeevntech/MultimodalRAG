#ifndef __SCCP_MSG_H
#define __SCCP_MSG_H

#include <Msg.h>
#include <ContextBase.h>


class SccpMsg : public Msg
{
   public:
      SccpMsg();
      ~SccpMsg();


     void *m_sblockIn;
     char m_callingParty[20+1];
     char m_calledParty[20+1];
     char m_Msisdn[20+1];
     bool m_allocatedFlag;
};

#endif

