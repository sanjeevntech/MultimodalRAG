#ifndef __TCP_SOCKET_CLIENT_H
#define __TCP_SOCKET_CLIENT_H

#define RETRY_CONNECTION_TIMER   5


class TcpSocketClient
{
   private:
      pthread_mutex_t m_mutex;

   public:
      char m_selfEntityName[10+1];
      int  m_AgentPort;
      char m_AgentIp[20+1];

      TcpSocketClient();
      ~TcpSocketClient();
      bool initialize(char *p_selfEntityName, char *p_snmpAgentIp, int p_snmpAgentPort);
      bool sendDataToNetwork(int p_sockFd, unsigned char *p_data, int p_length, int p_timeout);
      int  recvAll(int p_sockFd, char *p_buf, int p_len, int p_timeoutInSecs);
      int recvAllWithLength(int p_sockFd, char *p_buf, int p_len, int p_timeoutInSecs);
      bool connectToApp(int *p_sock, char *p_AppRegResp, char *p_ErrMsg);
};

extern bool available(int p_sockFd, int p_timeout);
extern bool dataAvailable(int p_sockFd, int p_timeout);

#endif

