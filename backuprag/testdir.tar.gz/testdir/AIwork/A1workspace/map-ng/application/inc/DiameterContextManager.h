#ifndef __DIAMETER_CONTEXT_MANAGER_H
#define __DIAMETER_CONTEXT_MANAGER_H

#include <stdio.h>
#include <ContextManager.h>
#include <map>

using namespace std;

class DiameterContextManager
{
    private:
        // The MAPs and Dialogue Pools
        map <string, void*>    m_map;

    public:
        // Constructor
        DiameterContextManager();

        // Destructor
        ~DiameterContextManager();

        // The Initializer
        bool initialize();

        // Context Storage and Retrieval functions
        bool storeContext (string p_sessionId, void *p_msgPtr, EDialogueType p_DialogueType);
        bool getContext   (string p_sessionId, void **p_msgPtr);
        bool removeContext(string p_sessionId, EDialogueType p_DialogueType);

        void print();

        void getStats(char *p_output);

        int getSize();

        bool terminate();
};

extern DiameterContextManager  g_DiameterContextMangerObject;

#endif

