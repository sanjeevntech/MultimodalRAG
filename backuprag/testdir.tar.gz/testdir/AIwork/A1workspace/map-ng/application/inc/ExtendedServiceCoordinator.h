#ifndef _EXTENDED_SERVICE_COORDINATOR_H
#define _EXTENDED_SERVICE_COORDINATOR_H

#include <stdio.h>
#include <MapMessages.h>
#include <DbQueryMsg.h>
#include <TimeoutMsg.h>
#include <SmppMsg.h>
#include <ConfigReader.h>
#include <MessageQueue.h>
#include <ContextBase.h>
#include <map>
#include <string>
#include <ServiceCoordinator.h>
#include <DiameterMessages.h>
#include <DiameterConstants.h>
using namespace std;


enum EExtInterModType
{
   EXT_INTER_MOD_TYPE_UNKNOWN,
   EXT_INTER_MOD_TYPE_LIKE_NG
};

class ExtendedInterModuleData : public InterModuleData
{
   public:
      ExtendedInterModuleData();
      ~ExtendedInterModuleData();

      EExtInterModType m_eimt;
};

class ExtendedServiceCoordinator
{
   public:
      // Constructor
      ExtendedServiceCoordinator();

      // Destructor
      ~ExtendedServiceCoordinator();

      // The Initializer
      bool initialize(int p_MaxSessions);

      // Handles Incoming DIAMETER Message
      bool recvMsg(DiameterMsg *p_DiameterMsg);

      // Handles Outgoing DIAMETER Message    
      bool sendMsg(ContextBase *p_ContextBasePtr, DiameterMsg *p_DiameterMsgPtr);

      // This is used to initiate an Independent Context with Character Data as Input
      bool initiateIndependentContext(ContextBase *p_presentContext, EDiameterCommandCode, char *, EInitiationType p_it=INITIATION_TYPE_IMMEDIATE);

      // This is used to initiate an Independent Context with Msg Data as Input
      bool initiateIndependentContext(ContextBase *p_presentContext, EDiameterCommandCode p_ccCode, Msg *p_msgPtr);

      // This is used to initiate an Independent Context with Msg Data as Input as if NG has received it
      bool initiateIndependentContextLikeNg(ContextBase *p_presentContext, EDiameterCommandCode p_ccCode, Msg *p_msgPtr);

      // This is used to allocate a new DIAMETER session
      bool allocateSession(EDiameterApplicationIdentifier p_dai, unsigned int& p_sessIndex, string& p_sessionId);
};

extern ExtendedServiceCoordinator g_esc;
extern MessageQueue *g_InterModuleQueue2;

#endif

