#ifndef __DIAMETER_SESSION_H
#define __DIAMETER_SESSION_H

#include <TdrData.h>
#include <string>
#include <map>

enum EDiamSessionType
{
   DIAM_SESS_TYPE_UNKNOWN = 0,
   DIAM_SESS_TYPE_NETWORK_INITIATED = 1,
   DIAM_SESS_TYPE_APPLICATION_INITIATED = 2
};

enum EDiamSessionState
{
   DIAM_SESS_STATE_IDLE =0,
   DIAM_SESS_STATE_INITIATED
};


class DiameterSession
{
   public:
      DiameterSession();
      ~DiameterSession();

      void reset();

      EDiamSessionType    m_diamSessType;
      EDiamSessionState   m_diamSessState;

      unsigned int        m_sessionIndex;

      string              m_remoteHost;
      string              m_remoteRealm;

      bool                m_ErrorExchangedFlag;
      int                 m_ErrorCodeExchanged;

      TdrData             *m_tdr;
      bool                m_crossedNg;
};

extern map<string,DiameterSession *> *g_DiameterSessionsList;


#endif

