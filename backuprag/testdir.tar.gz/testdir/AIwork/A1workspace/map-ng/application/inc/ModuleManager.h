#ifndef __MODULE_MANAGER_H
#define __MODULE_MANAGER_H

#include <ContextBase.h>
#include <ConfigReader.h>
#include <MapMessages.h>
#include <ModuleBase.h>

#define MAX_OP_CODES 400
#define MAX_MODULES  20

typedef ModuleBase * (*fptr_mod)(void);

enum EDllResult
{
   DLL_RESULT_UNKNOWN,
   DLL_RESULT_DLL_NOT_FOUND,
   DLL_RESULT_FUNC_NOT_FOUND,
   DLL_RESULT_SUCCESS
};

class OpCodeMapping
{
   public:
      OpCodeMapping();
      ~OpCodeMapping();
      int         m_OpCode;
      char        m_LibName[40+1];
      char        m_FuncName[30+1];
      ContextBase *m_ContextPtr;
      bool        m_Map1Flag;
      bool        m_Map2Flag;
      bool        m_Map3Flag;
      char m_ModName[3+1];
      char m_MessageName[3+1];
      fptr_mod    m_func;
      int         m_tdrRequiredFlag;
      time_t      m_loadedTime;
};


class ModuleMapping
{
   public:
      ModuleMapping();
      ~ModuleMapping();
      fptr_mod      m_func;
      char          m_ModName[3+1];
      char          m_LibName[40+1];
      time_t        m_loadedTime;

      bool          m_configPresent;
      ConfigReader *m_cr;
      char          m_file[500];
      time_t        m_configLoadedTime;
      string        m_moduleOverridedName;
};

class ModuleManager
{
   public:
      OpCodeMapping m_mapping[MAX_PROTOCOL_TYPES+1][MAX_OP_CODES];
      ModuleMapping m_modules[MAX_MODULES];
      int           m_mappingCount;
      bool readModulesConfig();
      bool resolveSymbols();
      fptr_mod     getContextFptr_mod    (const char* p_libName, const char* p_funcName, EDllResult *p_result, char *p_error);

      ModuleManager(){}
      ~ModuleManager(){}
      ContextBase *getRespectiveContext2(int p_OpCode, Msg*);
      bool isPresent(EMsgType p_mt, int p_OpCode);
};


extern ModuleManager g_mm;

#endif

