#ifndef __MODULE_BASE_H
#define __MODULE_BASE_H

#include <MapMessages.h>
#include <DiameterMessages.h>
#include <ContextBase.h>
#include <ConfigReader.h>

#include <SccpMsg.h>

class ModuleBase
{
   private:

   public:
      string m_modName;

      ModuleBase();
      virtual ~ModuleBase();

      virtual bool initModule()=0;
      virtual ContextBase *getCtxtObj(EMapOpCode, MapSpecificMsg*)=0;
      virtual char *getVersion()=0;
      virtual ConfigReader *getConfigReaderObj()=0;
      virtual ConfigReader **retrieveConfigReaderPtr()=0;
      virtual ContextBase *getCtxtObj(EDiameterCommandCode, DiameterMsg*)=0;
      virtual ContextBase *getCtxtObj(EMapOpCode, SccpMsg*)=0;
      virtual ContextBase *getCtxtObj(EDiameterCommandCode, InterModuleData*);
};

#define RETURN_VERSION(VERSION) { char *l_temp= new char[200]; memset(l_temp, '\0', 200); sprintf(l_temp, " %s %s   %s", __DATE__, __TIME__, VERSION); return l_temp;}

#endif

