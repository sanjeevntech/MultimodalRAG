#ifndef __DIAMETER_MESSAGES_H
#define __DIAMETER_MESSAGES_H

#include <Msg.h>
#include <DiameterConstants.h>



class ServiceCoordinator;

#define   MAX_SESSION_ID_SIZE     4096     //This is because ITS_OCTET data[4096]; is present in IDS_DIAMETER structure

enum EDiameterEventType
{
   DIAM_EVENT_UNKNOWN = 0,
   DIAM_EVENT_REQUEST,
   DIAM_EVENT_ANSWER,
   DIAM_EVENT_ERROR,                //Error bit is set to true
   DIAM_EVENT_ERROR_SOMETHING_WEIRD,//Command Code is 0. Error Bit is not set.
   DIAM_EVENT_TIME_OUT,             //TIME_OUT_IND_FROM_STACK
   DIAM_EVENT_AUTH_LIFE_TIME_OUT,   //AUTH_LIFE_TIME_OUT_IND_FROM_STACK
   DIAM_EVENT_AUTH_GRACE_TIME_OUT,  //AUTH_GRACE_TIME_OUT_IND_FROM_STACK
   DIAM_EVENT_CORRUPTED_MSG,        //CORRUPTED_MSG_IND_FROM_STACK
   DIAM_EVENT_ACCT_INTERIM_TIME_OUT,//ACCT_INTERIM_TIME_OUT_IND_FROM_STACK
   DIAM_EVENT_MAXIMUM
};



class DiameterMsg : public Msg
{
   private:
      DiameterMsg();           //Intent is not to use the default constructor

   public:
      //Member Variables
      bool                     m_allocatedFlag;
      EDiameterEventType       m_det;
      EDiameterCommandCode     m_commandCode;
      int                      m_applicationId;


      //Start of ITS specific
      void *m_cmd;
      char  m_sessionId[MAX_SESSION_ID_SIZE+1];
      unsigned int m_sessionIndex;
      //End of ITS specific

      //Member Functions
      DiameterMsg(char*, EDiameterEventType, EDiameterCommandCode);
      DiameterMsg(char*, EDiameterEventType);
      virtual ~DiameterMsg();

      char *getMsgTypeName();
      struct timeval m_oldTv2;
      struct timeval m_pTv2;
      struct timeval m_rTv2;
};


#endif

