#ifndef _UNI_TYPES_H
#define _UNI_TYPES_H

#include <iostream>
#include <string>

using namespace std;

typedef char            s8;   /* Exactly one byte (7 bits) */
typedef unsigned char   u8;   /* Exactly one byte (8 bits) */
typedef short           s16;  /* Exactly 2 bytes (15 bits) */
typedef unsigned short  u16;  /* Exactly 2 bytes (16 bits) */
typedef int             s32;  /* Exactly 4 byte (31 bits) */
typedef unsigned int    u32;  /* Exactly 4 byte (32 bits) */
typedef bool            Boolean;
typedef string          String;

#define U8 u8
#define S8 s8
#define S16 s16
#define U16 u16
#define U32 u32
#define S32 s32

typedef int SOCKET;

#define MAX_BCD_STR_LEN 10  /* Maximum length of address string */
#define MAX_NUM_STR_LEN 20  /* (2*MAX_BCD_STR_LEN) */

#endif
