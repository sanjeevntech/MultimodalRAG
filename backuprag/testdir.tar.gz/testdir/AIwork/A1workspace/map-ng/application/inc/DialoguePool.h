#ifndef __DIALOGUE_POOL_
#define __DIALOGUE_POOL_

#include <queue>
#include <pthread.h>
#include <stdio.h>
#include <Logger.h>

class DialoguePool
{
   private:
      // The Queue which holds the available Session IDs
      std::queue<int> m_q;

      // The mutex required for synchronization while pushing and popping from the Queue
      pthread_mutex_t m_q_mutex;

      // Lock a Queue
      void lock();

      // Unlock a Queue
      void unlock();

      int  m_maxSessionIDs;

   public:

      DialoguePool();
      ~DialoguePool();

      // The initialization function would create the queue with all the session IDs 
      bool initialize(int p_startDialogue, int p_maxDialogues);

      // Pops a Session ID from the Queue (handles locking internally)
      int getNewDialogueId();

      // Pushes the Session ID to the Queue (handles locking internally)
      bool releaseDialogueId(int p_dialogueId);

      void getStats(char *p_output);

      int getSize();
};


#endif


