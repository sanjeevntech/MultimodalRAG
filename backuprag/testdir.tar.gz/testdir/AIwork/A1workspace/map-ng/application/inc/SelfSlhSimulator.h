#ifndef __SELF_SLH_SIMULATOR_H
#define __SELF_SLH_SIMULATOR_H

#include <SelfSimulator.h>

class SelfSlhSimulator : public SelfSimulator
{
   public:
      SelfSlhSimulator();
      ~SelfSlhSimulator();

      bool getMessage(int p_opCode, Msg **p_msgPtr, Msg *p_ReqMsgPtr);
};


#endif
