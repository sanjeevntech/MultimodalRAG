#ifndef __TDR_DATA_H
#define __TDR_DATA_H

#include <iostream>
#include <UniTypes.h>
#include <string>
using namespace std;


#define TDR_COMMON_MAX_PARAMS        10
#define TDR_APPLICATION_MAX_PARAMS   200

class TdrData
{
   public:
      string m_HDR[TDR_COMMON_MAX_PARAMS];
      string m_CDR[TDR_APPLICATION_MAX_PARAMS]; 
      TdrData();
      ~TdrData();

      void setChar(int , s8 );
      void setInteger(int , s32 );
      void setUnsignedInteger(int , u32 );
      void setString(int , s8* );
      void setHex(int , s8* , u16 );

      //The functions below shall set the Header Data
      void setOpCode(u16 );
      void setMapVersion(u16 );
      void setRemoteAddr(s8* );
      void setTdrId();
      void setRemoteAddrSsn(int );
      void setOriginatingModule(char *);
      void setContextId(char *);
};

#endif //__TDR_DATA_H

