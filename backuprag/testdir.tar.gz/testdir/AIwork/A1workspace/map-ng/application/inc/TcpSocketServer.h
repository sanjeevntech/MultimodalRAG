#ifndef __TCP_SOCKET_SERVER_H
#define __TCP_SOCKET_SERVER_H

#include <MessageQueue.h>
#include <map>
#include <string>

using namespace std;


typedef enum
{
   DEVICE_STATE_NOT_REGISTERED,
   DEVICE_STATE_REGISTERED
}EDeviceState;

typedef enum
{
   DEVICE_CONN_TYPE_NON_DEDICATED,
   DEVICE_CONN_TYPE_DEDICATED
}EDeviceConnectionType;

class FdInfo
{
   public:
      FdInfo();
      EDeviceState state;
      string device_name;
      string device_on_off;
      string ip_address;
      int port;
      EDeviceConnectionType m_DeviceConnectionType;
      int m_lastActiveTime;
};


class TcpSocketServer
{
   public:
      TcpSocketServer();
      ~TcpSocketServer();

      bool initialize(int p_port);
      void getStats(char *p_output);
};

extern TcpSocketServer g_tss;
extern MessageQueue *g_tcpSocketQueue;

#endif

