#ifndef INCL_TYPES_H
#define INCL_TYPES_H

typedef bool               BOOLEAN;

typedef char               TEXT;
typedef char               INT8;
typedef unsigned char      UINT8;

typedef short              INT16;
typedef unsigned short     UINT16;

typedef int                INT;   // int size is machine dependent
typedef unsigned int       UINT;  // unsigned int size is machine dependent

typedef long               INT32;
typedef unsigned long      UINT32;

typedef long               LONG;
typedef unsigned long      ULONG;

typedef long long          INT64;
typedef unsigned long long UINT64;

typedef float              FLOAT;

typedef double             DOUBLE;

#define NULLPTR  0

#endif 
