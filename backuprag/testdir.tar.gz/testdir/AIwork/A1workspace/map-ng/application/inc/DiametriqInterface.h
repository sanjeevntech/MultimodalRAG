#ifndef __DIAMETRIQ_INTERFACE_H
#define __DIAMETRIQ_INTERFACE_H

#include <iostream>
#include <its++.h>
#include <its_timers.h>
#include <diameter/Command.h>
#include <diameter/base/BaseAVP.h>
#include <MessageQueue.h>
#include <DiameterConstants.h>
using namespace diameter;
using namespace diameter::base;

#define BASE_CE_MSG_CMD_CODE      257
#define BASE_DW_MSG_CMD_CODE      280
#define BASE_DP_MSG_CMD_CODE      282

#define MAX_DIAM_STATS_CODES      30

struct SuccessFailure
{
   int m_TotalCount;
   int m_SuccessCount;
};

struct DiamStatsIndices
{
   SuccessFailure m_RespondingCommands[MAX_DIAM_STATS_CODES];
   SuccessFailure m_InitiatingCommands[MAX_DIAM_STATS_CODES];
   int m_CER;
   int m_CEA;
   int m_DWR;
   int m_DWA;
   int m_DPR;
   int m_DPA;
   int m_DISC;
   int m_TIME_OUT;
   int m_AUTH_LIFE_TIME_OUT;
   int m_AUTH_GRACE_TIME_OUT;
   int m_CORRUPTED_MSG;
   int m_ACCT_INTERIM_TIME_OUT;
   int m_FAILOVER;
   int m_FAILBACK;
   int m_DIAM_REGISTRATION_FAILED;
   int m_DIAM_REGISTRATION_SUCCESS;
   int m_DEREGISTER_ACK_MSG;
   int m_DIASERVER_NOTIFY_MSG;
   int m_GLOBAL_UNIQ_ADDR_ACK_MSG;
};


extern int g_diamSuspendIndex;
extern int g_diamResumeIndex;

class DiametriqInterface
{
   public:
      DiametriqInterface();
      ~DiametriqInterface();

      bool initialize(int);
      int  processDiameterMessages();

      //Variables
      bool            m_initializedFlag;
      unsigned int    m_regAppId;
      bool            m_diameterStackRegisteredFlag;
      MessageQueue    *m_diameterMessagesQueue;
      struct DiamStatsIndices m_dsi;
      unsigned int    m_recvAppId;

      bool            sendErrorResponse(const diameter::CommandImpl *impl, unsigned int sIdx, EDiameterResultCode p_drc);
      int             handleErrorResponse(const diameter::CommandImpl *impl, unsigned int sIdx);
      int             handleBaseMessages(const diameter::CommandImpl *impl, unsigned int &sIdxBase);
      int             handleDiaAppMsg(const diameter::CommandImpl *impl, unsigned int &sIdx,struct timeval p_timeval, struct timeval p_pTv, struct timeval p_rTv);
      //int             handleDiaAppMsg(const diameter::CommandImpl *impl, unsigned int &sIdx);
      int             sendDiaAppMsg(diameter::Command& impl, ITS_UINT sesIdx=0);
      int             allocateSession(ITS_UINT appId, ITS_UINT &sessIdx, std::string &sessString);
      void            releaseSession(std::string &sessString, ITS_UINT sessIdx=0);
      bool            isDccaEnabled();
      string          getSessionId(const diameter::CommandImpl *p_commandImpl);
      void            getStats(char *p_text);
      bool            terminate();
};

extern DiametriqInterface g_di;

#endif
