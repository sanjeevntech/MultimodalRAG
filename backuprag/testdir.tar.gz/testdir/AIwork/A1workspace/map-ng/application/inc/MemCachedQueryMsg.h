#ifndef __MEMC_QUERY_MSG_H
#define __MEMC_QUERY_MSG_H

#include <Msg.h>
#include <ContextBase.h>

typedef enum 
{
   MEMC_QUERY_RES_UNKNOWN=0,
   MEMC_QUERY_RES_SUCCESS,
   MEMC_QUERY_RES_FAILURE
}EMemCachedQueryRes;

typedef enum 
{
   MEMC_QUERY_TYPE_GET=0,
   MEMC_QUERY_TYPE_UPDATE,
   MEMC_QUERY_TYPE_DELETE,
   MEMC_QUERY_TYPE_UNKNOWN
}EMemCachedQueryType;

class MemCachedQueryMsg: public Msg
{
   public:
      MemCachedQueryMsg();
      virtual ~MemCachedQueryMsg();
      virtual void executeMemcQuery()=0;
      virtual void serializeMemc()=0;
      virtual bool deSerializeMemc()=0;
      virtual bool validateMemcachedContinuity();

      EMemCachedQueryType m_MemcQueryType;
      EMemCachedQueryRes m_MemcQueryRes;
      string m_MemcKey;
      string m_MemcValue;
      char m_PriImsi4Distribution[15+1];
      string m_MemcIP;
      int  m_MemcPort;

      int m_MemcErrorCode;
      string m_MemcErrorMessage;

      void *m_memcActivePtr;
      ContextBase *m_Mcb;
};

#endif
