#ifndef __RTPS_INTERFACE_H
#define __RTPS_INTERFACE_H

extern int  g_rtpsFd;
extern int  g_rtpsLastFailureDate;
extern int  g_rtpsFullyDownFlag;
extern bool g_connectStatus;


#endif
