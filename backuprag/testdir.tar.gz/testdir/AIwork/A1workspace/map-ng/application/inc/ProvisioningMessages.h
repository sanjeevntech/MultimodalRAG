#ifndef __PROVISIONING_MESSAGES_H
#define __PROVISIONING_MESSAGES_H

#include <Msg.h>
#include <ContextBase.h>
#include <string>
using namespace std;

enum EProvMsgType
{
    PROV_MSG_TYPE_UNKNOWN = 0,
    PROV_MSG_TYPE_REQUEST,
    PROV_MSG_TYPE_RESPONSE
};

class ProvisioningMsg: public Msg
{
    public:
      ProvisioningMsg();
      ProvisioningMsg(EProvMsgType);
      virtual ~ProvisioningMsg();
      
      EProvMsgType m_provMsgType;

      string m_transId;
      string m_transType;
      string m_OrigEntityName;
      string m_IpAddress;
      int    m_DeviceConnectionType;

      int m_sockFd;
      string m_data;
};

class ProvisioningReqMsg: public ProvisioningMsg
{
    public:
      ProvisioningReqMsg();
      ~ProvisioningReqMsg();
};

class ProvisioningResMsg: public ProvisioningMsg
{
    public:
      ProvisioningResMsg();
      ~ProvisioningResMsg();
};

#endif
