#ifndef INCL_ESME_CONST_DEF_H
#define INCL_ESME_CONST_DEF_H

#include "Types.h"

#define ESME_MAX_THREADS                        100

//#define MAX_SCP_REQ_LEN                         1000
#define MAX_SCP_REQ_LEN                         1024

#define MAX_ESME_COMMAND_LENGTH_LEN             4
#define MAX_ESME_COMMAND_ID_LEN                 4
#define MAX_ESME_COMMAND_STATUS_LEN             4
#define MAX_ESME_SEQUENCE_NUMBER_LEN            4
#define MAX_ESME_HEADER_LEN                     16

#define SNMP_AGENT_IP_MIN      8
#define SNMP_AGENT_IP_MAX      16
#define SNMP_AGENT_PORT_MIN    0
#define SNMP_AGENT_PORT_MAX    30000
#define SNMP_APPL_IP_MIN      8
#define SNMP_APPL_IP_MAX      16
#define SNMP_APPL_PORT_MIN      0
#define SNMP_APPL_PORT_MAX      30000
#define SNMP_NUM_TIMES_MIN    1
#define SNMP_NUM_TIMES_MAX    10

#define MIN_SYSTEM_ID_LEN                       0
#define MAX_SYSTEM_ID_LEN                       16
#define MIN_PASSWORD_LEN                        0
#define MAX_PASSWORD_LEN                        9
#define MIN_SYSTEM_TYPE_LEN                     0
#define MAX_SYSTEM_TYPE_LEN                     13
#define MIN_ADDRESS_RANGE_LEN                   0
#define MAX_ADDRESS_RANGE_LEN                   41
#define MIN_SERVICE_TYPE_LEN                    0
#define MAX_SERVICE_TYPE_LEN                    6
#define MIN_SME_LEN                             0
#define MAX_SME_LEN                             65
#define MIN_SCHEDULE_DELIVERY_TIME_LEN          1
#define MAX_SCHEDULE_DELIVERY_TIME_LEN          17
#define MIN_VALIDITY_PERIOD_LEN                 1
#define MAX_VALIDITY_PERIOD_LEN                 17
#define MIN_SMS_LEN                             0
#define MAX_SMS_LEN                             255
#define MIN_MESSAGE_ID_LEN                      0
#define MAX_MESSAGE_ID_LEN                      65
#define MIN_TON_LEN                             0
#define MAX_TON_LEN                             6
#define MIN_NPI_LEN                             0
#define MAX_NPI_LEN                             18
#define MIN_ADDRESS_LEN                         3
#define MAX_ADDRESS_LEN                         16
#define MAX_DATE_TIME_LEN                       17

#define MAX_OPTIONAL_TAG_LEN                    2
#define SMPP_MSG_PAYLOAD_LEN_MIN                0
#define SMPP_MSG_PAYLOAD_LEN_MAX                320 
#define SMPP_REPLACE_IF_PRESENT_FLAG_MIN        0
#define SMPP_REPLACE_IF_PRESENT_FLAG_MAX        1
#define SMPP_NUMBER_OF_MESSAGES_MIN             0
#define SMPP_NUMBER_OF_MESSAGES_MAX             99
#define SMPP_MSG_PRIORITY_FLAG_MIN              0
#define SMPP_MSG_PRIORITY_FLAG_MAX              4
#define SMPP_ADDR_SUBUNIT_MIN                   0
#define SMPP_ADDR_SUBUNIT_MAX                   4
#define SMPP_ESMCLASS_MIN                       0
#define SMPP_ESMCLASS_MAX                       255
#define SMPP_RDELIVERY_MIN               0 
#define SMPP_RDELIVERY_MAX               255
#define SMPP_VALID_TIME_LEN               16
#define SMPP_ABYY_MIN                     0
#define SMPP_ABYY_MAX                     99
#define SMPP_ABMT_MIN                     0
#define SMPP_ABMT_MAX                     12
#define SMPP_ABDD_MIN                     0
#define SMPP_ABDD_MAX                     31
#define SMPP_ABHH_MIN                     0
#define SMPP_ABHH_MAX                     23
#define SMPP_ABMM_MIN                     0
#define SMPP_ABMM_MAX                     59
#define SMPP_ABSS_MIN                     0 
#define SMPP_ABSS_MAX                     59
#define SMPP_ABT_MIN                      0
#define SMPP_ABT_MAX                      9
#define SMPP_ABNN_MIN                     0
#define SMPP_ABNN_MAX                     48 
#define SMPP_REYY_MIN                    0
#define SMPP_REYY_MAX                    99
#define SMPP_REMT_MIN                    0
#define SMPP_REMT_MAX                    12
#define SMPP_REDD_MIN                    0
#define SMPP_REDD_MAX                    31
#define SMPP_REHH_MIN                    0
#define SMPP_REHH_MAX                    23
#define SMPP_REMM_MIN                    0
#define SMPP_REMM_MAX                    59
#define SMPP_RESS_MIN                    0
#define SMPP_RESS_MAX                    59


#define MAX_OPTIONAL_TAG_LENGTH_LEN             2

#define MAX_FILE_PATH_LEN                       200
#define MAX_LOG_PREFIX_LEN                      25
#define ESME_PORT_MIN                           1
#define ESME_PORT_MAX                           32767
#define ESME_IPADDRESS_MIN                      7
#define ESME_IPADDRESS_MAX                      128
#define ESME_BACKLOG_MIN                        1
#define ESME_BACKLOG_MAX                        10
#define ESME_NUM_OF_THREADS_MIN                 1
#define ESME_NUM_OF_THREADS_MAX                 100
#define ESME_SELECTTIMEOUT_MIN                  1
#define ESME_SELECTTIMEOUT_MAX                  86400

#define SMPP_PORT_MIN                           1
#define SMPP_PORT_MAX                           32767
#define SMPP_IPADDRESS_MIN                      7
#define SMPP_IPADDRESS_MAX                      128

#define SCP_PORT_MIN                            1
#define SCP_PORT_MAX                            32767
#define SCP_IPADDRESS_MIN                       7
#define SCP_IPADDRESS_MAX                       128

#define MIN_TOPUP_CODE_LEN                      1
#define MAX_TOPUP_CODE_LEN                      255
#define MIN_BAL_ENQ_CODE_LEN                    1
#define MAX_BAL_ENQ_CODE_LEN                    20
#define MIN_OWN_NUM_CODE_LEN                    1
#define MAX_OWN_NUM_CODE_LEN                    20

#define MAX_VMS_LEN                            1024 
#define VMS_PORT_MIN                           1
#define VMS_PORT_MAX                           32767
#define VMS_IPADDRESS_MIN                      7
#define VMS_IPADDRESS_MAX                      128
#define VMS_CALLERID_MIN                       0
#define VMS_CALLERID_MAX                       10 

/* CONFIGURATION */
#define ESME_LOGLEVEL_MIN                 1
#define ESME_LOGLEVEL_MAX                 5
#define ESME_LOGMEDIA_MIN                 1
#define ESME_LOGMEDIA_MAX                 4

/* LOGGER */
#define ESME_MAXFILESIZE_MIN              1000
#define ESME_MAXFILESIZE_MAX              1000000000
#define ESME_FILEPATH_MIN                 2
#define ESME_FILEPATH_MAX                 255
#define ESME_PREFIX_MIN                   2
#define ESME_PREFIX_MAX                   20
#define ESME_ARCHIVALPATH_MIN             2
#define ESME_ARCHIVALPATH_MAX             255

#define MIN_ESME_PDU_LEN    (4*4)
#define MAX_ESME_PDU_LEN    (65536)

#define NOTDELIVERED                      1
#define SMPP_MESSAGE_STATE_LEN            1
#define SMPP_ERROR_CODE_LEN               1

enum ESME_OPERATION
{
   BIND_TRANSCEIVER            = 0x00000009,
   BIND_TRANSCEIVER_RESP       = 0x80000009,
   SUBMIT_SM                   = 0x00000004,
   SUBMIT_SM_RESP              = 0x80000004,
   QUERY_SM                    = 0x00000003,
   QUERY_SM_RESP               = 0x80000003,
   CANCEL_SM                   = 0x00000008,
   CANCEL_SM_RESP              = 0x80000008,
   REPLACE_SM                  = 0x00000007,
   REPLACE_SM_RESP             = 0x80000007,
   ENQUIRE_LINK                = 0x00000015,
   ENQUIRE_LINK_RESP           = 0x80000015,
   UNBIND                      = 0x00000006,
   UNBIND_RESP                 = 0x80000006,
   DELIVER_SM                  = 0x00000005,
   DELIVER_SM_RESP             = 0x80000005
};

enum SMPP_ERROR_MESSAGES
{
   SMPP_ESME_ROK                     = 0x00000000,
   SMPP_ESME_RINVMSGLEN              = 0x00000001,
   SMPP_ESME_RINVCMDLEN              = 0x00000002,
   SMPP_ESME_RINVCMDID               = 0x00000003,
   SMPP_ESME_RINVBNDSTS              = 0x00000004,
   SMPP_ESME_RALYNBD                 = 0x00000005,
   SMPP_ESME_RINVPRTFLG              = 0x00000006,
   SMPP_ESME_RINVREGDLVFLG           = 0x00000007,
   SMPP_ESME_RSYSERR                 = 0x00000008,
   SMPP_ESME_RINVSRCADR              = 0x0000000A,
   SMPP_ESME_RINVDSTADR              = 0x0000000B,
   SMPP_ESME_RINVMSGID               = 0x0000000C,
   SMPP_ESME_RBINDFAIL               = 0x0000000D,
   SMPP_ESME_RINVPASWD               = 0x0000000E,
   SMPP_ESME_RINVSYSID               = 0x0000000F,
   SMPP_ESME_RCANCELFAIL             = 0x00000011,
   SMPP_ESME_RREPLACEFAIL            = 0x00000013,
   SMPP_ESME_RMSGQFUL                = 0x00000014,
   SMPP_ESME_RINVSERTYP              = 0x00000015,
   SMPP_ESME_RINVNUMDESTS            = 0x00000033,
   SMPP_ESME_RINVDLNAME              = 0x00000034,
   SMPP_ESME_RINVDESTFLAG            = 0x00000040,
   SMPP_ESME_RINVSUBREP              = 0x00000042,
   SMPP_ESME_RINVESMCLASS            = 0x00000043,
   SMPP_ESME_RCNTSUBDL               = 0x00000044,
   SMPP_ESME_RSUBMITFAIL             = 0x00000045,
   SMPP_ESME_RINVSRCTON              = 0x00000048,
   SMPP_ESME_RINVSRCNPI              = 0x00000049,
   SMPP_ESME_RINVDSTTON              = 0x00000050,
   SMPP_ESME_RINVDSTNPI              = 0x00000051,
   SMPP_ESME_RINVSYSTYP              = 0x00000053,
   SMPP_ESME_RINVREPFLAG             = 0x00000054,
   SMPP_ESME_RINVNUMMSGS             = 0x00000055,
   SMPP_ESME_RTHROTTLED              = 0x00000058,
   SMPP_ESME_RINVSCHED               = 0x00000061,
   SMPP_ESME_RINVEXPIRY              = 0x00000062,
   SMPP_ESME_RINVDFTMSGID            = 0x00000063,
   SMPP_ESME_RX_T_APPN               = 0x00000064,
   SMPP_ESME_RX_P_APPN               = 0x00000065,
   SMPP_ESME_RX_R_APPN               = 0x00000066,
   SMPP_ESME_RQUERYFAIL              = 0x00000067,
   SMPP_ESME_RINVTLVSTREAM           = 0x000000C0,
   SMPP_ESME_ROPTPARNOTALLWD         = 0x000000C1,
   SMPP_ESME_RINVTLVLEN              = 0x000000C2,
   SMPP_ESME_RMISSINGTLV             = 0x000000C3,
   SMPP_ESME_RINVTLVVAL              = 0x000000C4,
   SMPP_ESME_RDELIVERYFAILURE        = 0x000000FE,
   SMPP_ESME_RUNKNOWNERROR           = 0x000000FF,

   //SMPP V 5.0 ERROR MESSAGES
   SMPP_ESME_RSERTYPUNAUTH           = 0x00000100,
   SMPP_ESME_RPROHIBITED             = 0x00000101,
   SMPP_ESME_RSERTYPUNAVAIL          = 0x00000102,
   SMPP_ESME_RSERTYPDENIED           = 0x00000103,
   SMPP_ESME_RINVDCS                 = 0x00000104,
   SMPP_ESME_RINVSRCADDRSUBUNIT      = 0x00000105,
   SMPP_ESME_RINVDSTADDRSUBUNIT      = 0x00000106,
   SMPP_ESME_RINVBCASTFREQINT        = 0x00000107,
   SMPP_ESME_RINVBCASTALIAS_NAME     = 0x00000108,
   SMPP_ESME_RINVBCASTAREAFMT        = 0x00000109,
   SMPP_ESME_RINVNUMBCAST_AREAS      = 0x0000010A,
   SMPP_ESME_RINVBCASTCNTTYPE        = 0x0000010B,
   SMPP_ESME_RINVBCASTMSGCLASS       = 0x0000010C,
   SMPP_ESME_RBCASTFAIL              = 0x0000010D,
   SMPP_ESME_RBCASTQUERYFAIL         = 0x0000010E,
   SMPP_ESME_RBCASTCANCELFAIL        = 0x0000010F,
   SMPP_ESME_RINVBCAST_REP           = 0x00000110,
   SMPP_ESME_RINVBCASTSRVGRP         = 0x00000111,
   SMPP_ESME_RINVBCASTCHANIND        = 0x00000112

};

// SMPP Optional parameters

#define  SMPP_DEST_ADDR_SUBUNIT           0x0005 
#define  SMPP_DEST_NETWORK_TYPE           0x0006 
#define  SMPP_DEST_BEARER_TYPE            0x0007 
#define  SMPP_DEST_TELEMATICS_ID          0x0008 
#define  SMPP_SOURCE_ADDR_SUBUNIT         0x000D 
#define  SMPP_SOURCE_NETWORK_TYPE         0x000E 
#define  SMPP_SOURCE_BEARER_TYPE          0x000F 
#define  SMPP_SOURCE_TELEMATICS_ID        0x0010 
#define  SMPP_QOS_TIME_TO_LIVE            0x0017 
#define  SMPP_PAYLOAD_TYPE                0x0019 
#define  SMPP_ADDITIONAL_STATUS_INFO_TEXT 0x001D 
#define  SMPP_RECEIPTED_MESSAGE_ID        0x001E 
#define  SMPP_MS_MSG_WAIT_FACILITIES      0x0030 
#define  SMPP_PRIVACY_INDICATOR           0x0201 
#define  SMPP_SOURCE_SUBADDRESS           0x0202 
#define  SMPP_DEST_SUBADDRESS             0x0203 
#define  SMPP_USER_MESSAGE_REFERENCE      0x0204 
#define  SMPP_USER_RESPONSE_CODE          0x0205 
#define  SMPP_SOURCE_PORT                 0x020A 
#define  SMPP_DEST_PORT                   0x020B 
#define  SMPP_SAR_MSG_REF_NUM             0x020C 
#define  SMPP_LANGUAGE_INDICATOR          0x020D 
#define  SMPP_SAR_TOTAL_SEGMENTS          0x020E 
#define  SMPP_SAR_SEGMENT_SEQNUM          0x020F 
#define  SMPP_SC_INTERFACE_VERSION        0x0210 
#define  SMPP_CALLBACK_NUM_PRES_IND       0x0302 
#define  SMPP_CALLBACK_NUM_ATAG           0x0303 
#define  SMPP_NUMBER_OF_MESSAGES          0x0304 
#define  SMPP_CALLBACK_NUM                0x0381 
#define  SMPP_DPF_RESULT                  0x0420 
#define  SMPP_SET_DPF                     0x0421 
#define  SMPP_MS_AVAILABILITY_STATUS      0x0422 
#define  SMPP_NETWORK_ERROR_CODE          0x0423 
#define  SMPP_MESSAGE_PAYLOAD             0x0424 
#define  SMPP_DELIVERY_FAILURE_REASON     0x0425 
#define  SMPP_MORE_MESSAGES_TO_SEND       0x0426 
#define  SMPP_MESSAGE_STATE               0x0427 
#define  SMPP_USSD_SERVICE_OP             0x0501 
#define  SMPP_DISPLAY_TIME                0x1201 
#define  SMPP_SMS_SIGNAL                  0x1203 
#define  SMPP_MS_VALIDITY                 0x1204 
#define  SMPP_ALERT_ON_MESSAGE_DELIVERY   0x130C 
#define  SMPP_ITS_REPLY_TYPE              0x1380 
#define  SMPP_ITS_SESSION_INFO            0x1383 


enum EsmeServerType_Enum
{
   VMS_SERVER = 0,
   BILLING_SERVER = 1,
   ETOPUP_SERVER = 2,
   PORTING_SERVER
};

enum EsmeMessageType_Enum
{
   MES_SUBMIT_SM = 1,
   MES_REPLACE_SM = 2,
   MES_CANCEL_SM = 3,
   MES_SUB_DLV_RPT = 4,
   MES_REP_DLV_RPT = 5,
   MES_SUBMIT_MULTI
};


struct bind_transceiver
{
   char system_id[MAX_SYSTEM_ID_LEN + 1];
   char password[MAX_PASSWORD_LEN + 1];
   char system_type[MAX_SYSTEM_TYPE_LEN + 1];
   char interface_version;
   char addr_ton;
   char addr_npi;
   char address_range[MAX_ADDRESS_RANGE_LEN + 1];
};

struct bind_transceiver_resp
{
   char system_id[MAX_SYSTEM_ID_LEN + 1];

   ///// Optional TLV Parameters /////
   char sc_interface_version;
};

struct submit_sm
{
   char service_type[MAX_SERVICE_TYPE_LEN + 1];
   char source_addr_ton;
   char source_addr_npi;
   char source_addr[MAX_SME_LEN + 1];
   char dest_addr_ton;
   char dest_addr_npi;
   char destination_addr[MAX_SME_LEN + 1];
   unsigned char esm_class;
   char protocol_id;
   char priority_flag;
   char schedule_delivery_time[MAX_SCHEDULE_DELIVERY_TIME_LEN + 1];
   char validity_period[MAX_VALIDITY_PERIOD_LEN + 1];
   char registered_delivery;
   char replace_if_present_flag;
   unsigned char data_coding;
   char sm_default_msg_id;
   unsigned char sm_length;
   
   ///// Optional TLV Parameters /////
   char message_payload[320];
   int  payload_length;
   int  sar_msg_ref_num;
   int  sar_segment_seqnum;
   int  sar_total_segments;
};

struct submit_sm_resp
{
   char message_id[MAX_MESSAGE_ID_LEN + 1];
};

struct replace_sm
{
   char service_type[MAX_SERVICE_TYPE_LEN + 1];
   char message_id[MAX_MESSAGE_ID_LEN + 1];
   char source_addr_ton;
   char source_addr_npi;
   char source_addr[MAX_SME_LEN + 1];
   char schedule_delivery_time[17 + 1];
   char validity_period[MAX_VALIDITY_PERIOD_LEN + 1];
   char registered_delivery;
   char sm_default_msg_id;
   unsigned char sm_length;
   char message_payload[MAX_SMS_LEN];
};

struct replace_sm_resp
{
   // NULL BODY
};

struct cancel_sm
{
   char service_type[MAX_SERVICE_TYPE_LEN + 1];
   char message_id[MAX_MESSAGE_ID_LEN + 1];
   char source_addr_ton;
   char source_addr_npi;
   char source_addr[MAX_SME_LEN + 1];
   char dest_addr_ton;
   char dest_addr_npi;
   char destination_addr[MAX_SME_LEN + 1];
};

struct cancel_sm_resp
{
   // NULL BODY
};

struct query_sm
{
   char message_id[MAX_MESSAGE_ID_LEN + 1];
   char source_addr_ton;
   char source_addr_npi;
   char source_addr[MAX_SME_LEN + 1];
};

struct query_sm_resp
{
   char message_id[MAX_MESSAGE_ID_LEN + 1];
   char final_date[17 + 1];
   char message_state;
   char error_code;
};

struct enquire_link
{
   // NULL BODY
};

struct enquire_link_resp
{
   // NULL BODY
};

struct deliver_sm
{
   long bitmask;

   char service_type[MAX_SERVICE_TYPE_LEN + 1];
   char source_addr_ton;
   char source_addr_npi;
   char source_addr[MAX_SME_LEN + 1];
   char dest_addr_ton;
   char dest_addr_npi;
   char destination_addr[MAX_SME_LEN + 1];
   unsigned char esm_class;
   char protocol_id;
   char priority_flag;
   char schedule_delivery_time[MAX_SCHEDULE_DELIVERY_TIME_LEN + 1];
   char validity_period[MAX_VALIDITY_PERIOD_LEN + 1];
   char registered_delivery;
   char replace_if_present_flag;
   unsigned char data_coding;
   char sm_default_msg_id;
   unsigned char sm_length;
   char message_payload[MAX_SMS_LEN];

   ///// Optional TLV Parameters /////
   int  dpf_result;
   //char message_payload[65536];
   int  language_indicator;
   char message_state;
   char network_error_code[3];
   int  payload_type;
   int  privacy_indicator;
   char receipted_message_id[65];
   int  sar_msg_ref_num;
   int  sar_segment_seqnum;
   int  sar_total_segments;
   int  ussd_service_op;
};

struct deliver_sm_resp
{
   long bitmask;

   char message_id[MAX_MESSAGE_ID_LEN + 1];

   ///// Optional TLV Parameters /////
   char delivery_failure_reason;
   char network_error_code[3];
   char additional_status_info_text[256];
   char dpf_result; 
};


union Esme_msg
{
   struct bind_transceiver          BindTransceiver;
   struct bind_transceiver_resp     BindTransceiverResp;
   struct submit_sm                 SubmitSm;
   struct submit_sm_resp            SubmitSmResp;
   struct cancel_sm                 CancelSm;
   struct cancel_sm_resp            CancelSmResp;
   struct replace_sm                ReplaceSm;
   struct replace_sm_resp           ReplaceSmResp;
   struct query_sm                  QuerySm;
   struct query_sm_resp             QuerySmResp;
   struct enquire_link              EnquireLink;
   struct enquire_link_resp         EnquireLinkResp;
   struct deliver_sm                DeliverSm;
   struct deliver_sm_resp           DeliverSmResp;
};

struct Esme_Data
{
   UINT32            command_length;
   UINT32            command_id;
   UINT32            command_status;
   UINT32            sequence_number;
   ESME_OPERATION    message_type;
   union Esme_msg    msg;
};

struct EsmePDU
{
   TEXT    data[MAX_ESME_PDU_LEN];
   UINT32  len;
   UINT32  pos;
};

struct UserRequest
{
   TEXT  data[MAX_SMS_LEN];
   TEXT  destination_addr[MAX_SME_LEN + 1];
};

#endif
