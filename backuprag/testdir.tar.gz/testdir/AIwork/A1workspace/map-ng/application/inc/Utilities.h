#ifndef __UTILITIES_H
#define __UTILITIES_H

#include <UniTypes.h>

//4.0.2.0 for IMEI encryption

extern int     getNumberOfSignificantBitsForAByte(unsigned char p_char);
extern int     getNumberOfSignificantBitsForAnArray(unsigned char *p_char, int length);
extern bool    checkValidBCDDigit(u8 c);
extern int     numToBCD(u8 *m_numStr, u8 *m_bcdStr, u8 m_numStrLength);
extern int     BCDToWholeNum(u8 m_bcdStr, u8 *m_numStr);
extern int     WholeNumToBCD( u8 m_numStr, u8 *m_bcdStr);
extern int     BCDToNum(u8 *m_bcdStr, u8 *m_numStr, u16 m_bcdStrLength);
extern int     BCDToString(u8 *str, u8 *bcd, int i);
extern void    BCDToString(u8 *str, u8 *bcd, s32 i, bool oddEven);
extern int     StringToBCD(u8 *dest,u8 *src, int length);
extern bool    ConvertInto8Bit(unsigned char *source, unsigned char *dest, int len);
extern unsigned int parseHex(const char * str);
extern char    *atohx(char *p_dst, const char *p_src);
extern void hxtoa(unsigned char *str, unsigned char *hex, int p_hexSize);
extern void printHexDump(char *p_text, u8 *p_buffer, int p_length);
extern bool  ValidateIpv4(char *p_ipadd);
extern void convertIPV4toHex(char * apIPv4Addr,unsigned char *apAddrInHex);
extern void tokenize(char *p_input, char *p_str, int p_size);
extern int  tokenize2(char *p_input, char *p_str, int p_size, char p_seperator);
extern void printSignalSet(char *p_log);
extern void upper(char *p_src, char *p_dest, int);
extern void printTimeToConsole(struct timeval &currTv, struct timeval &prevTv, char *str);
extern void getTime(struct timeval &currTv, struct timeval &prevTv, char *str, struct timeval *p_timeval=NULL);
extern void getTime2(struct timeval &currTv, struct timeval &prevTv, char *str, struct timeval *p_timeval=NULL);
extern void hexToString(unsigned char *str, int p_maxStrSize, unsigned char *hex, int p_hexSize);
extern void convertHextoIPV4(string& p_addrInHex, char *p_IPv4Addr);
extern u8 reverseByte(u8 x);
extern bool getOpCodeName(int p_opCode, char* p_opCodeName);

//4.0.2.0 for IMEI encryption
extern bool DES_Encryption(unsigned char *original, unsigned char *encrypted, unsigned char *key, int type);
extern bool Copy_encryptedIMEI(char *Orig_IMEI, char* Encrypt_IMEI);
extern void hexToStringWithoutSpace(unsigned char *str, int p_maxStrSize, unsigned char *hex, int p_hexSize);
extern bool Copy_Decrypt_IMEI(char *p_imei);
#ifdef Linux
void strlcat(char* p_desc, char*p_src, int p_size);
#endif

#endif /* __UTILITIES_H */
