#ifndef __CONTEXT_BASE_H
#define __CONTEXT_BASE_H

#include <Msg.h>
#include <MapConstants.h>
#include <TdrData.h>
#include <string>
#include <map>
using namespace std;

class CntxtMsc;
class InterModuleData;
class MapOpenInd;


enum ERscType
{
   RSC_TYPE_UNKNOWN=0
};

class ContextInfo
{
   public:
      int m_count;
      long m_totalReceivedCount;
      int m_failureCount;
      map<int,int> m_activeContextList; 
};


class ContextBase : public Msg
{
   protected:
      bool sendMapOpenResponse(int p_UserDlgId, char *p_origGt, int p_origSsn);

   public:
      ContextBase();
      virtual ~ContextBase();
      virtual bool processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag)=0;
      virtual bool startProcessing(); // This is for simulators
      virtual bool startProcessing(InterModuleData *p_data, bool& p_DeleteFlag); //This is for initiating new conversations in existing conversations

      bool setTraceImsi(char *p_imsi);
      bool setTraceMsisdn(char *p_msisdn);


      void setGlobalContextId(int p_Id);
      int  getGlobalContextId();
      bool CallProcMsg(Msg *p_MsgPtr);
      bool m_flaggedToDelete;
      ERscType  m_RscType;
      int m_ReferenceCount;
      int getInitialRespondingDlgId(); // Added this for usage in Ctxt classes
      EMapVersion getInitialRespondingVersion(); // Added this for usage in Ctxt classes
      char m_ModName[3+1];
      char m_MessageName[3+1];
      int m_GlobalContextId;

      string m_className;
      void setClassName(char *p_name);

      TdrData m_tdr;
      struct timeval m_oldTv;
      struct timeval m_pTv;
      struct timeval m_rTv;

   private:
      int m_InitialRespondingDlgId;
      EMapVersion m_InitialRespondingVersion;

      char m_TraceImsi[20+1];
      char m_TraceMsisdn[20+1];
      char m_TraceEnabledFlag;

      friend class CntxtMsc;
      friend class ServiceCoordinator;
      friend class WaitForSvcPrimitiveMsc;
};

extern MapOpenInd *g_currentOpenIndPtr;


#endif

