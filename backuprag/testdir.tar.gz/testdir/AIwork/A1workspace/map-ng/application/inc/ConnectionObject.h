#ifndef __CONNECTION_OBJECT_H
#define __CONNECTION_OBJECT_H

#include <sqlda.h>

#include <string>
#include <Logger.h>
#include <ConfigReader.h>

#define CONNECTION_ATTEMPTS 5
#define MEMBER_STATE_GOOD	0
#define MEMBER_STATE_BAD	1

extern struct oraca oraca;

#ifndef SQLCA
#define SQLCA 1
struct   sqlca
{
   /* ub1 */ char    sqlcaid[8];
   /* b4  */ int     sqlabc;
   /* b4  */ int     sqlcode;
   struct
   {
      /* ub2 */ unsigned short sqlerrml;
      /* ub1 */ char           sqlerrmc[70];
   } sqlerrm;
   /* ub1 */ char    sqlerrp[8];
   /* b4  */ int     sqlerrd[6];
   /* ub1 */ char    sqlwarn[8];
   /* ub1 */ char    sqlext[8];
};
#endif

#include <sqlca.h>

extern struct sqlca sqlca;
extern struct oraca oraca;

class ConnectionObject
{

   public:
      // This variable indicates the state of the runtime context
      int	iState ;				
      EXEC SQL BEGIN DECLARE SECTION;		
      varchar	iCntStr[200];
      EXEC SQL END DECLARE SECTION;
   public:

      EXEC SQL BEGIN DECLARE SECTION;
      sql_context iCtx;
      EXEC SQL END DECLARE SECTION;

      // Default Context Object
      ConnectionObject(string mCntStr) ;

      ~ConnectionObject();
};


#endif


