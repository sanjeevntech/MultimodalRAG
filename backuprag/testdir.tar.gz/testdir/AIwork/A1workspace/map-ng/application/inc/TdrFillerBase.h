#ifndef __TDR_FILLER_BASE_H
#define __TDR_FILLER_BASE_H

#include <iostream>
#include <UniTypes.h>
#include <string>

using namespace std;


enum EOtherTdrParams
{
   TDR_APP_UNKNOWN,
   TDR_APP_DIAM_BEGIN,
   TDR_APP_REMOTE_HOST,
   TDR_APP_REMOTE_REALM,
   TDR_APP_LOCAL_HOST,
   TDR_APP_LOCAL_REALM,
   TDR_APP_ORIGINATING_HLR_GT
};

enum ETdrHdrIndex
{
   TDR_HDR_TDR_ID_INDEX,
   TDR_HDR_OP_CODE_INDEX,
   TDR_HDR_CONTEXT_ID_INDEX,
   TDR_HDR_RECEIVED_TIMESTAMP,
   TDR_HDR_MAP_VERSION_INDEX,
   TDR_HDR_REMOTE_PARTY_ADDR_INDEX,
   TDR_HDR_REMOTE_PARTY_SSN_INDEX,
   TDR_HDR_ORIGINATING_MODULE
};


class TdrFillerBase
{
   public:
      TdrFillerBase();
      virtual ~TdrFillerBase();

      char m_LastDateString[20+1];
      int  m_LastSeqNo;

      char *getHeaderString();
      int   getHeaderCount();

      virtual int  getTdrIndex(EOtherTdrParams p_data);
      virtual bool prepareTDR(TdrData *p_scd, char *a_cdrBuff, int p_currentTdr);
      virtual bool prepareTitle(char *a_cdrBuff);

};

extern TdrFillerBase *g_tfb;

#endif //__TDR_FILLER_BASE_H

