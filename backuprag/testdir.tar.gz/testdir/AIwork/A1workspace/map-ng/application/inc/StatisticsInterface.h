#ifndef __STATISTICS_INTERFACE_H_
#define __STATISTICS_INTERFACE_H_

#include <StatisticsGenerator.h>
#include <StatisticsInitializationHelper.h>

class StatisticsInterface
{
    public:
        static void logRespondingApplCtxtTotal         (int p_applCtxt, int p_version);
        static void logRespondingApplCtxtSuccess       (int p_applCtxt, int p_version);
        static void logRespondingOpCodeTotal           (int p_opCode, int p_version);
        static void logRespondingOpCodeSuccess         (int p_opCode, int p_version);
        static void logRespondingConversationTotal     (int p_convCode, int p_version);
        static void logRespondingConversationSuccess   (int p_convCode, int p_version);

        static void logInitiatingApplCtxtTotal         (int p_applCtxt, int p_version);
        static void logInitiatingApplCtxtSuccess       (int p_applCtxt, int p_version);
        static void logInitiatingOpCodeTotal           (int p_opCode, int p_version);
        static void logInitiatingOpCodeSuccess         (int p_opCode, int p_version);
        static void logInitiatingConversationTotal     (int p_convCode, int p_version);
        static void logInitiatingConversationSuccess   (int p_convCode, int p_version);

        static void logOpCodeErrorCount                (int p_opCode, int p_errorCode);
        static void logOpCodeOtherErrorCount           (int p_opCode, int p_errorCode);

        static void logRespondingTcapPrimCount         (int p_tcapPrim);
        static void logInitiatingTcapPrimCount         (int p_tcapPrim);
        static void logDiffTimeStatistics              (char *p_dbQuery, struct timeval* p_diffTime, int p_dbIndex);
        static void logMemCacheDiffTimeStatistics      (struct timeval* p_diffTime, int p_memcIndex);
        static void DiffTimeStatisticsForDiamMsg      (struct timeval* p_diffTime);
        static void DiffTimeStatisticsForMapMsg      (struct timeval* p_diffTime);
};

extern bool genLogStatistics(int);

class HLRStatisticsInitializer : public StatisticsInitializationHelper
{
   public:

      bool applicationInitializationCallback(StatisticsGenerator *p_sg);
      static HLRStatisticsInitializer *instance();

   private:
      static HLRStatisticsInitializer* m_ds;
      HLRStatisticsInitializer();
      ~HLRStatisticsInitializer();
};


#endif



