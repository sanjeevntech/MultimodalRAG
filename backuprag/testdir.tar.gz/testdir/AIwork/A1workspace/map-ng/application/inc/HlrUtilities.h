#ifndef _HLR_UTILITIES_H
#define _HLR_UTILITIES_H

#include <iostream>
typedef unsigned char   u8;
bool FormClXml(char *p_XmlReq,int p_NodeType,u8 *p_imsi,u8 *p_lmsi,u8 *p_ActHLRAddr,u8 *p_vlrno,int p_updateSubsdata);

#endif //_HLR_UTILITIES_H
