#ifndef __DB_ACTIVE_OBJECT_H
#define __DB_ACTIVE_OBJECT_H

#include <MessageQueue.h>
#include <ConfigReader.h>
#include <DbQueryMsg.h>

struct queues
{
   MessageQueue *m_req;
   MessageQueue *m_LaterQueryReq;
   MessageQueue *m_res;

};


struct diffTimeStatices
{
   int m_diffTime_gr_or_equal_20s;
   int m_diffTime_gr_or_equal_10s_and_lt_20s;
   int m_diffTime_gr_or_equal_7s_and_lt_10s;
   int m_diffTime_gr_or_equal_5s_and_lt_7s;
   int m_diffTime_gr_or_equal_2s_and_lt_5s;
   int m_diffTime_gr_or_equal_1s_and_lt_2s;
   int m_diffTime_gr_or_equal_0d7s_and_lt_1s;
   int m_diffTime_gr_or_equal_0d5s_and_lt_0d7s;
   int m_diffTime_gr_or_equal_0d2s_and_lt_0d5s;
   int m_diffTime_gr_or_equal_0d1s_and_lt_0d2s;
   int m_diffTime_gr_or_equal_0d07s_and_lt_0d1s;
   int m_diffTime_gr_or_equal_0d05s_and_lt_0d07s;
   int m_diffTime_gr_or_equal_0d02s_and_lt_0d05s;
   int m_diffTime_gr_or_equal_0d01s_and_lt_0d02s;
   int m_diffTime_gr_or_equal_0d007s_and_lt_0d01s;
   int m_diffTime_gr_or_equal_0d005s_and_lt_0d007s;
   int m_diffTime_gr_or_equal_0d002s_and_lt_0d005s;
   int m_diffTime_gr_or_equal_0d001s_and_lt_0d002s;
   int m_diffTime_gr_or_equal_0d0007s_and_lt_0d001s;
   int m_diffTime_gr_or_equal_0d0005s_and_lt_0d0007s;
   int m_diffTime_gr_or_equal_0d0002s_and_lt_0d0005s;
   int m_diffTime_gr_or_equal_0d0001s_and_lt_0d0002s;
   int m_diffTime_lt_0d00001s;
};

class DbActiveObject
{
   private:
      bool m_initializationFlag;
      bool m_laterQueryInitFlag;
      int  m_numOfThreads;

   public:
      bool m_explicitMonitoringFlag;
      int  m_activeThreads[MAX_DB_NODES];
      int  m_queryCount[MAX_DB_NODES];
      pthread_mutex_t m_activeMutex;
      pthread_mutex_t m_activeMutex1;
      struct diffTimeStatices m_dts[MAX_DB_NODES];

      DbActiveObject();
      ~DbActiveObject();

      bool initialize(int p_numOfThreads, bool p_explicitMonitoringFlag);
      bool execute(void *p_request);
      queues m_queues;

      void getStats(char *p_output);
      int getRequestQueueSize();
      int getLaterRequestQueueSize();
};

extern DbActiveObject g_act;
extern DbQueryMsg *g_HeartBeatMsgPtr;
#endif

