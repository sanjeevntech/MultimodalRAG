#ifndef __MEMC_ACTIVE_OBJECT_H
#define __MEMC_ACTIVE_OBJECT_H

#include <MessageQueue.h>
#include <ConfigReader.h>
#include <MemCachedQueryMsg.h>

#define MAX_MEMC_REQ_QUEUE 50

struct MemcQueues
{
   MessageQueue *memc_reqQ[MAX_MEMC_REQ_QUEUE];
   MessageQueue *memc_resQ;
};

struct memCacheDiffTimeStatistics
{
   int m_diffTime_gr_or_equal_20s;
   int m_diffTime_gr_or_equal_10s_and_lt_20s;
   int m_diffTime_gr_or_equal_7s_and_lt_10s;
   int m_diffTime_gr_or_equal_5s_and_lt_7s;
   int m_diffTime_gr_or_equal_2s_and_lt_5s;
   int m_diffTime_gr_or_equal_1s_and_lt_2s;
   int m_diffTime_gr_or_equal_0d7s_and_lt_1s;
   int m_diffTime_gr_or_equal_0d5s_and_lt_0d7s;
   int m_diffTime_gr_or_equal_0d2s_and_lt_0d5s;
   int m_diffTime_gr_or_equal_0d1s_and_lt_0d2s;
   int m_diffTime_gr_or_equal_0d07s_and_lt_0d1s;
   int m_diffTime_gr_or_equal_0d05s_and_lt_0d07s;
   int m_diffTime_gr_or_equal_0d02s_and_lt_0d05s;
   int m_diffTime_gr_or_equal_0d01s_and_lt_0d02s;
   int m_diffTime_gr_or_equal_0d007s_and_lt_0d01s;
   int m_diffTime_gr_or_equal_0d005s_and_lt_0d007s;
   int m_diffTime_gr_or_equal_0d002s_and_lt_0d005s;
   int m_diffTime_gr_or_equal_0d001s_and_lt_0d002s;
   int m_diffTime_gr_or_equal_0d0007s_and_lt_0d001s;
   int m_diffTime_gr_or_equal_0d0005s_and_lt_0d0007s;
   int m_diffTime_gr_or_equal_0d0002s_and_lt_0d0005s;
   int m_diffTime_gr_or_equal_0d0001s_and_lt_0d0002s;
   int m_diffTime_lt_0d00001s;
};

class MemCachedActiveObject
{
   private:
      bool m_initializationFlag;

   public:
      struct memCacheDiffTimeStatistics m_dts[50];

      MemCachedActiveObject();
      ~MemCachedActiveObject();

      bool initialize();
      bool execute(void *p_request);
      MemcQueues m_MemcQueues;

      //bool pushToMemCached(void *p_memc,char *p_Ip, int p_Port); 

      void getMemcQueueStats(char *p_output);
      int getMemcRequestQueueSize();
};

extern MemCachedActiveObject g_MemcActObj;
extern MemCachedQueryMsg *g_MemcHeartBeatMsgPtr;
#endif

