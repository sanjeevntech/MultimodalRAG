#ifndef _UPDATE_INSTANCE_STATUS_H_
#define _UPDATE_INSTANCE_STATUS_H_

#include <DbQueryMsg.h>
#include <ConfigReader.h>


class UpdateInstanceStatus : public DbQueryMsg
{
   public:
      UpdateInstanceStatus();
      ~UpdateInstanceStatus();

      bool executeQuery(void*);
};



















#endif
