#ifndef __MESSAGE_QUEUE_H
#define __MESSAGE_QUEUE_H

#include <deque>
#include <semaphore.h>
#include <pthread.h>
#include <string>

using namespace std;

enum EQueueType
{
   QUEUE_TYPE_BLOCKING=0,
   QUEUE_TYPE_NON_BLOCKING,
   QUEUE_TYPE_BLOCKING_TIMED_WAIT
};

enum EQueueConsumingModel
{
   QUEUE_CONSUMING_MODEL_AS_IT_COMES=0,
   QUEUE_CONSUMING_MODEL_BASED_ON_TPS
};

enum EQueuePersistenceType
{
   QUEUE_PERSISTENCE_TYPE_NON_PERSISTENT=0,
   QUEUE_PERSISTENCE_TYPE_PERSISTENT
};

enum EThbFlag
{
   THB_DISABLED=0,
   THB_ENABLED
};

#define MAX_QUEUE_DATA_SIZE  2000
#define MSG_TYPE             1

struct  mymsg {
   long  m_type;     /* message type */
   char  m_text[MAX_QUEUE_DATA_SIZE+1];  /* message text */
};

class MessageQueue
{
   public:
      MessageQueue(EQueueType p_QueueType, EQueuePersistenceType p_QueuePersistenceType);
      ~MessageQueue();

      bool initialize();
      bool push(void *p_qm, int p_length=0);
      //bool pop(void **p_qm);
      bool pop(void **p_qm, EThbFlag p_thbFlag = THB_DISABLED, string p_threadName = "");
      bool m_thbRegisterFlag;
      int size();

      bool pop_without_lock(void **p_qm); // Can be used for popping multiple messages by locking and unlocking explicitly
      void lock();
      void unlock();
      int getSemCount();
      EQueueConsumingModel m_qcm;
      int   m_tps;
      int m_heartBeatInterval;
      bool (*m_callback)();
      int m_currentTrans;
      time_t m_lastSecond;
      deque<void*> m_q;
      pthread_mutex_t m_q_mutex;


   private:
      pthread_mutex_t m_tps_mutex;
      sem_t m_semaphore;

      EQueueType m_QueueType;
      EQueuePersistenceType m_QueuePersistenceType;
      int m_persMsgId;
      int m_persKey;

};

#endif

