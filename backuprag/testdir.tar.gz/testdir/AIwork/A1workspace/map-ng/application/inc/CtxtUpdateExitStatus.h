#ifndef __CONTEXT_UPDATE_EXIT_STATUS_H
#define __CONTEXT_UPDATE_EXIT_STATUS_H

#include <ContextBase.h>
#include <Msg.h>
#include <ServiceCoordinator.h>
#include <string>

class CtxtUpdateExitStatus : public ContextBase
{
   public:
      CtxtUpdateExitStatus();
      ~CtxtUpdateExitStatus();

      bool processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag);
      bool startProcessing();
};

#endif
