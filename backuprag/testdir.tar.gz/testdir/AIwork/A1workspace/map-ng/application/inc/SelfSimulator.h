#ifndef __SELF_SIMULATOR_H
#define __SELF_SIMULATOR_H

#include <Msg.h>

class SelfSimulator 
{
   public:
      SelfSimulator();
      virtual ~SelfSimulator();

      virtual bool getMessage(int p_opCode, Msg **p_msgPtr, Msg *p_ReqMsgPtr)=0;
};

extern SelfSimulator *g_selfSimObj;

#endif

