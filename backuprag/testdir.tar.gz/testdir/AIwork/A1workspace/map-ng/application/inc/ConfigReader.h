#ifndef __CONFIG_READER_H
#define __CONFIG_READER_H

#include <iostream>
#include <map>
#include <list>
#include <vector>
#ifdef ULCM_SP5
#include <PlintronSccpAddr.h>
#elif ULCM_SP6
#include <PlintronSccpAddr_SP6.h>
#else
#error "ULCM version undefined"
#endif
#include <TdrData.h>
#include <TdrFillerBase.h>
#include <Types.h>
#include <GlobalData.h>
#include <Msg.h>
#include <StatisticsInitializationHelper.h>
#include <GUtilThreadHeartBeat.h>
using namespace std;

#define MAX_DB_NODES 100
#define STANDARD_SERVER_REGISTER_ME_TIMEOUT       120
#define MAX_STATS_BASED_OP_CODES                  90

extern int g_simulateThbHungInterval;
extern time_t g_currTimeForTHB;


typedef struct _HeavyTransaction
{
   int m_count;
   time_t m_time;
}HeavyTransaction;
typedef enum
{
   SNMP_TRAP_ID_UNKNOWN=0,
   SNMP_TRAP_ID_PORT_OUT_FILE,
   SNMP_TRAP_ID_TCAP_STACK,
   SNMP_TRAP_ID_MULTI_IMSI_FILE,
   SNMP_TRAP_ID_ROUTER_CONN,
   SNMP_TRAP_ID_IMSI_RANGE_FILE,
   SNMP_TRAP_ID_MAX_TPS
}MaprSnmpTrapId;

typedef map<int,string> mymap;


enum EExitAppType
{
   EXIT_APPLICATION_TYPE_UNKNOWN = 500,
   EXIT_APPLICATION_TYPE_CTRL_SIGNAL_RCVD,
   EXIT_APPLICATION_TYPE_CONFIG_INIT_FAILED,
   EXIT_APPLICATION_TYPE_MAP_CONSTANTS_INIT_FAILED,
   EXIT_APPLICATION_TYPE_DIAMETER_CONSTANTS_INIT_FAILED,
   EXIT_APPLICATION_TYPE_CONFIG_DATA_READING_FAILED,
   EXIT_APPLICATION_TYPE_GUTIL_SNMP_SI_INIT_FAILED,
   EXIT_APPLICATION_TYPE_TRACE_LOGGER_INIT_FAILED,
   EXIT_APPLICATION_TYPE_LICENCE_INIT_FAILED,
   EXIT_APPLICATION_TYPE_MAP_SERV_COORD_INIT_FAILED,
   EXIT_APPLICATION_TYPE_DB_CHANGE_NOT_INIT_FAILED,
   EXIT_APPLICATION_TYPE_MML_TOOL_INIT_FAILED,
   EXIT_APPLICATION_TYPE_SMPP_INIT_FAILED,
   EXIT_APPLICATION_TYPE_ASN_CODECS_INIT_FAILED,
   EXIT_APPLICATION_TYPE_INTER_MODULE_QUEUE_INIT_FAILED,
   EXIT_APPLICATION_TYPE_INTER_MODULE2_QUEUE_INIT_FAILED,
   EXIT_APPLICATION_TYPE_OAM_TRANS_LIST_INIT_FAILED,
   EXIT_APPLICATION_TYPE_DIAM_STACK_INIT_FAILED,
   EXIT_APPLICATION_TYPE_DIAM_STACK_REG_RESPONSE_TIMEOUT,
   EXIT_APPLICATION_TYPE_ULTI_STACK_INIT_FAILED,
   EXIT_APPLICATION_TYPE_LOADING_MODULES_CONFIGURATIONS_FAILED,
   EXIT_APPLICATION_TYPE_TDR_INIT_FAILED,
   EXIT_APPLICATION_TYPE_CRITICAL_TDR_INIT_FAILED,
   EXIT_APPLICATION_TYPE_TIMER_MANAGER_INIT_FAILED,
   EXIT_APPLICATION_TYPE_PROV_INTERFACE_INIT_FAILED,
   EXIT_APPLICATION_TYPE_LOGGERS_INIT_FAILED,
   EXIT_APPLICATION_TYPE_UNABLE_TO_GET_DB_CONNECTION,
   EXIT_APPLICATION_TYPE_LOGGER_ARRAY0_IS_NULL,
   EXIT_APPLICATION_TYPE_LOGGER_ARRAY1_IS_NULL,
   EXIT_APPLICATION_TYPE_APPLICATION_IS_GOING_DOWN,
   EXIT_APPLICATION_TYPE_RTPS_TSC_INIT_FAILED,
   EXIT_APPLICATION_TYPE_SMPP_CONNECT_FAILED,
   EXIT_APPLICATION_TYPE_TSS_INVALID_SOCKET,
   EXIT_APPLICATION_TYPE_TOOL_INIT_SERVER_FAILED,
   EXIT_APPLICATION_TYPE_TOOL_RECEIVED_SHUTDOWN_COMMAND,
   EXIT_APPLICATION_TYPE_DIAMETRIQ_CLIENT_ALREADY_REGISTERED_ERROR,
   EXIT_APPLICATION_TYPE_UNABLE_TO_INITIALIZE_STATISTICS_GENERATOR,
   EXIT_APPLICATION_TYPE_THB_INITIALIZATION_FAILED,
   EXIT_APPLICATION_TYPE_THB_I_AM_ALIVE_FAILED,
   EXIT_APPLICATION_TYPE_MODULES_PROF_LOADING_FAILED,
   EXIT_APPLICATION_TYPE_SUBS_PROFILES_LOADING_TIMEOUT,
   EXIT_APPLICATION_TYPE_SMP_RECEIVED_SHUTDOWN_COMMAND,
   EXIT_APPLICATION_TYPE_SCCP_INIT_FAILED,
   EXIT_APPLICATION_TYPE_MAXIMUM
};

struct StatsBasedOpCodes
{
   int m_TotalCountGTMat[3];
   int m_TotalCountGTNotMat[3];
   int m_SuccessCountGTMat[3];
   int m_SuccessCountGTNotMat[3];
};

typedef struct reportData
{
   string m_reportName;
   string m_opCodes;
   string m_GTs;
   struct StatsBasedOpCodes m_RespondingOpCodesIndices [MAX_STATS_BASED_OP_CODES];
   struct StatsBasedOpCodes m_InitiatingOpCodesIndices [MAX_STATS_BASED_OP_CODES];
};

class ConfigReader
{
   public:
      bool readSccpAddress(string& p_ngString, char *p_tag, L_SccpAddress *p_sccpAddr);
      ConfigReader();
      virtual ~ConfigReader();
      bool init();
      void setConfigName(char *p_config);
      static string readValue (string parent, string child);
      static bool readString(string  parent, string child,  char  *ConfigValue ,unsigned int min, unsigned int max);
      string m_ConfigFileName;
      string m_DataString;
      virtual bool readData()=0; // This has to be overloaded by respective modules
      virtual void printConfigData(char *p_output);
      char *getConfigPrint(int p_page);
      bool m_derivedObjectInitializedFlag;
      static bool readInteger(string parent,string child,int &ConfigValue,int min,int max);
      static bool readUnsignedInteger(string parent,string child,unsigned long int &ConfigValue,unsigned int min,unsigned int max);
      static bool readString(string  p_parent, string p_child,  string& p_ConfigValue ,unsigned int p_min, unsigned int p_max);
      static bool IsString(char *st);
      void getModulesPrint(char **p_data);
      time_t m_lastUpdateDate;

      static char m_errorDesc[1000];
};



class NgConfigReader: public ConfigReader
{
   public:
      NgConfigReader();
      ~NgConfigReader();
      bool readModules();
      bool readData();
      virtual void printConfigData(char *p_output);
};

extern NgConfigReader *g_cr;

struct EsmeConfigData
{
   bool     m_Required;
   INT32    m_Port;
   INT32    m_NumofThreads;
   INT32    m_BackLog;
   TEXT     m_SMPP_IPAddress[20];
   INT32    m_SMPP_Port;
   TEXT     m_VmsIPAddress[20];
   INT32    m_VmsPort;
   TEXT     m_System_Id[20];
   TEXT     m_Password[20];
   TEXT     m_System_Type[20];
   INT32    m_BindTON;
   INT32    m_BindNPI;
   TEXT     m_ServiceType[20];
   INT32    m_ReplaceFlag;
   INT32    m_SubmitTON;
   INT32    m_DataCoding;
   TEXT     m_EsmeId[65];
   TEXT     m_ShortMessage[255];
   INT32    m_EsmeSelectTimeout;
   INT32    m_Retry;
   INT32    m_RoundRobin;
   INT32    m_MsgPerSecond;
   TEXT     m_FreeCallText[255];
   TEXT     m_FreeBalText[255];
   TEXT     m_sourceAddr[20];
   TEXT     m_serviceType[20];
   bool     m_PrintPdu;
};


class DbConfigData
{
   public:
      /*DATABASE Related*/

      int m_DbRequired;
      int m_ReceiveNotificationsFlag;
      int m_DbLogLevel;
      int m_DbLogMedia;
      int m_DbMaxFileSize;

      char m_DbLogfilePath[101];
      char m_DbLogPrefix[21];
      long  m_DbLogMaxsize;
      char  m_DbArchivalPath[50];

      int m_PoolSizeRequired;
      int m_MinAcceptpoolsize;
      char m_DbConnetionString[40];
      int m_PercentageThreshold;
      int m_MoniterThreadReq;

      int m_NoOfNodes;
      int m_diffTime;
      char m_Node2DbConnetionString[40];
      char  m_OraErrorCodes[1000];

      DbConfigData();
      ~DbConfigData();
};

struct HexData
{
   public:
      HexData();
      ~HexData();
      int m_length;
      unsigned char m_value[200];
};

class NgConfigData
{
   public:
      NgConfigData();
      ~NgConfigData();

      int m_RemotePC;
      int m_RemoteSSN;
      int m_LocalSSN;
      char m_StackName[30+1];

      L_SccpAddress m_selfAddress;

      L_SccpAddress m_remoteAddress1;
      L_SccpAddress m_remoteAddress2;

      HexData m_HexData1;
      HexData m_HexData2;
      HexData m_HexData3;

      map<int, bool> m_ApplSupportedMap;
      map<int, int> m_ApplSupportedMaxVersion;
      map<int, int> m_ApplSupportedMinVersion;

      int m_MaxDialogs;


};

typedef class MemCacheAddress_
{
   public:
      string  MCServerIp;
      int  MCServerPort;
}MemCacheAddress;


class ConfigData
{
   public:
      ConfigData();
      ~ConfigData();

      DbConfigData i_DbConfigData;
      EsmeConfigData m_EsmeConfigData;
      NgConfigData i_NgConfigData;
      vector<MemCacheAddress> m_MemCacheAddrVector;

      char m_LogModel;
      int m_LogLevel;
      int m_LogMedia;
      int m_MaxFileSize;

      char  m_LogfilePath[101];
      char  m_LogPrefix[21];
      long  m_LogMaxsize;
      char  m_ArchivalPath[50];

      int   m_ToolEnabledFlag;
      int   m_ToolPort;

      int   m_StatisticsEnabledFlag;
      int   m_SlotsInADay;
      char  m_StatisticsPath[101];

      int   m_TracingEnabledFlag;
      int   m_TracingLogLevel;
      int   m_TracingLogMedia;
      int   m_TracingMaxFileSize;
      char  m_TracingLogfilePath[101];
      char  m_TracingLogPrefix[21];
      long  m_TracingLogMaxsize;
      char  m_TracingArchivalPath[50];


      int   m_TdrEnabledFlag;
      int   m_TdrLogLevel;
      int   m_TdrLogMedia;
      int   m_TdrMaxFileSize;
      char  m_TdrLogfilePath[101];
      char  m_TdrLogPrefix[21];
      long  m_TdrLogMaxsize;
      char  m_TdrArchivalPath[50];


      int   m_ConsoleMapPduPrintFlag;
      int   m_ConsoleTcapPduPrintFlag;

      char  m_EntityName[20];
      char  m_StackEntityName[50];
      int   m_InstanceId;

      int   m_SnmpInterfaceEnabledFlag;
      int   m_SnmpAgentPort;
      char  m_SnmpAgentIp[20+1];

      int   m_ProvInterfaceEnabledFlag;
      int   m_ProvListenPort;
      int   m_ServerKeepAliveFlag;   //6461

      int   m_LogTcapPduPrintFlag;
      int   m_LogMapPduPrintFlag;

      int   m_TdrTitleFlag;

      //Memcached Related
      int   m_MemcEnableFlag;
      int   m_MemcPrimaryPort;
      char  m_MemcPrimaryIP[20+1];
      int   m_MemcDiffTimeTrapInterval;    
      int   m_MemcMaxReqQsize;

////////////////////////


        //Error Code and SubError code
  s32 m_ErrCodeGsmUL;
  s32 m_SubErrCodeGsmUL;
  s32 m_ErrCodeGprsUL;
  s32 m_SubErrCodeGprsUL;
  s32 m_ErrCodeGsmSAI;
  s32 m_SubErrCodeGsmSAI;
  s32 m_ErrCodeGprsSAI;
  s32 m_SubErrCodeGprsSAI;
  s32 m_GsmULEnabled;
  s32 m_GprsULEnabled;
  s32 m_GsmSAIEnabled;
  s32 m_GprsSAIEnabled;	

};

class DiameterConfigData
{
   public:
      DiameterConfigData();
      ~DiameterConfigData();
      int      m_diameterNgRequired;
      char     m_diamPrimaryIpAddress[15+1];
      int      m_diamPrimaryIpPort;
      char     m_diamBackupIpAddress[15+1];
      int      m_diamBackupIpPort;
      int      m_clientId;
      int      m_applicationId;
      int      m_additionalAppIdcount;
      int      m_additionalAppId[10];
      char     m_connectionType;
      char     m_diamterPduPrintType;

      char     m_originHost[100+1];
      char     m_originRealm[100+1];
      char     m_destinationHost[100+1];
      char     m_destinationRealm[100+1];
      char     m_priority;

      int      m_DiastackLoggingFlag; //6.3.8.0C
      char     m_LogsForDebugging[60+1]; //6.3.8.0C
      string   m_logLevel; //6.3.8.0C
};

class OtherConfigData
{
   public:
      OtherConfigData();
      ~OtherConfigData();
      int m_MaxProvInitiatingTransactions;
      int m_PrintTimerInLog;
      int m_BackLogQueueType;
      int m_ThresholdDialogsForInitiatingTransactions;
      int m_PreserveSccpClass;
      int m_OpcodeTagRej;
      int m_SendThreadHealthCheckTrap;
      char m_DbActualConnectionString[40];
      char m_Node2DbActualConnetionString[40];

      int m_GtTranslationRequiredFlag;
      map<char*, char*> m_GtTranslationMap;

      int m_SeparateStatsBasedGTFlag;
      int m_AllowedTTListValidation;
      string m_AllowedTTList;
      vector<int> m_allowedTTs;
      list<reportData> m_reportDataList;
      int m_sccpMsgHandlerParam; //6.4.6.1

      int m_LogFileRotatingType;
      int m_LogFileMaxFiles;
      char m_DbFailedConnectionRetryType;
      char m_TdrRtpsIp[15+1];
      int  m_TdrRtpsPort;
      int  m_MaxRtpsDowntime;

      int m_ExtTranslationRequiredFlag;
      map<char*, char*> m_ExtTranslationMap;
      char m_SccpType;
      char m_AnsiNationalIndicator;

      char  m_DbAliasStringArr[MAX_DB_NODES][40];
      char  m_DbActualStringArr[MAX_DB_NODES][40];
      int   m_TT;
      DiameterConfigData m_dcd;
      int   m_THBEnabled;

      int   m_TCAPStackFlag;
      char  m_logFlag;

      int   m_DiameterMaxQueueSize;
      int   m_DiameterMinQueueSize;
      int   m_DiameterMessageRejectionType;
      int   m_DiamSuspendResumeFeature; //6.4.4.0
      char  m_DiameterInterfaceType[20+1]; //6.4.4.0 
      int   m_DbHeartBeatRequiredFlag;
      int   m_DbHeartBeatInterval;    
      int   m_DbThresholdTps;

      int m_LaterQueryPoolSizeRequired;
      int m_LaterQueryDbTps;

      int   m_ProfilesFailureDuration;

      int m_HssHostTranslationFlag;
      map<string, string> m_HssHostTranslationMap;

      // HLR 4055 hotfix
      int m_clientIdleTimeout;
      char m_clientIdleTimeoutExceptionList[1000];
      int m_conn_fd_thresh_percentage;
      int m_MaxActiveConnections;
      /////////////////////////////// 
    /* General */
  int  m_SCCPStackFlag;
  s8  m_StackName[21];
  int  m_localSSN;
  char m_Sccp_Type[2];
  char m_VirIpSmGwSRISMAdd[20];
  int  m_TTCalledParty;
  int m_DebugLogLevel;
  char m_RoutingHlrAddress[20];  //6.4.6.0
  s8 m_CountryCode[10];
  s8 m_DestAddr[21];
  u32 m_PortNo;
  u32 m_LoopCounterFlag;
  u32 m_RetainTrnxPeriod;
  u32 m_heavyRequestIdentificationFlag;
  u32 m_heavyRequestDetectionPeriod;
  u32 m_heavyRequestDetectionCount;
  u32 m_MaxTPS;
  s16 m_TT_1;
  u32 m_NumberPlan;
  s32 m_NatureADDInd;
  char m_PortedOutPath[256];
  char m_MultiImsiPath[256];
  char m_DeltedNumPath[256];
  char m_ImsiRangePath[256];
  /* Log related */
  s8 m_FilePath[101];
  s8 m_Prefix[21];
  /* SNMP related */
  int m_SNMPEnabled;
  s8 m_SnmpAppIp[16];
  int m_SnmpAppPort;
  int m_ccmsisdnlen;
  int m_sccp_msisdn_check_lcs;
  int m_sccp_msisdn_check_ati;

  s32 m_StatsFlag;
};


extern unsigned char g_protocol;
extern unsigned char g_globalTitleIndicator;
//typedef int * (*fptr_sccpcblock)(void* psb, void *cb, int size, int *CblkRet);
//typedef int * (*fptr_sccpsblock)(void* psb, void *cb, int size, int *CblkRet);
//fptr_sccpcblock g_sccpcblock_fptr;
//fptr_sccpsblock g_sccpsblock_fptr;


struct CongestionControl
{
   CongestionControl();
   ~CongestionControl();
   char m_controlType[2];
   int  m_maxActiveIncomingDialogues;
   int  m_maxActiveLaterQueueSize;
   int  m_maxIncomingTransactionsPerSec;
   int  m_priorityHandling;
   int  m_priorityPercentages[11];
   int  m_priorityMaxActiveIncomingDialogues[11];
   int  m_priorityIncomingTransactionsPerSec[11];
   char m_overloadTransactionsRejectType[2];
   int  m_priorityFlags[11];
   int  m_trapInterval;
};

extern map<int, int> g_ApplContextPriority;
extern CongestionControl g_cc;


extern OtherConfigData *g_OtherConfigData;
extern ConfigData *g_ConfigData;
extern GlobalData *g_spd;
extern CommonDataBase *g_prov;
extern int g_DbConnectionTrap; 
extern int g_DbConnectionTrap1; 
extern int g_DbConnectionTrap2; 
extern int g_TcapStackConnectionTrap;
extern int g_DiskFullTrap;
extern int g_GracefullShutdownTrap;
extern int g_SmscConnectionTrap;
extern int g_RtpsConnectionTrap;
extern int g_DbThreadHangTrap;
extern int g_ThreadHanged;
extern int g_DbCongestion;
extern int g_TransPerSecTrap;
extern int g_TranslationTrap;
extern int g_DialoguePoolTRAP;
extern int g_OpCodeApplMismatchTrap;
extern int g_outOfDialgsTrap;
extern int g_provRegRequestNotRcvdTrap;
extern int g_provDeviceUnauthorizedTrap;
extern int g_DiameterStackConnectionTrap;
extern bool reloadConfigurations(char *p_module, char *p_responseToBeSent);
extern bool reloadModule(char *p_module, char *p_file, char *p_responseToBeSent);
extern void modifyNgConfigValues(char *p_log_key, char *p_log_value, char *p_responseToBeSent);
extern int  g_CurrSubsBase;
extern bool GetNetworkHlrAddr(u8* p_NetworkHlrAddr, u8 *p_OriginalHlrAddr);
extern bool GetTranslatedHostAddr(u8* p_TranslatedHostAddr, u8 *p_OriginalHostAddr);
extern void exitFunc(EExitAppType p_exit);
extern char *getExitApplTypeChar(EExitAppType p_eat);
extern bool whetherToProcess(int p_opCode, EMsgType *p_msgType);

extern int g_IMEI_EncrFlag;

extern int g_CloseNotRecvTrap; // HLR 4055
extern int g_PeerDoesnotCloseConnectionTrap;
extern int g_AcceptNewConnErrTrap;
extern int g_MaxthresholdLimitTrap;
extern int g_MaxThreshPercentTrap;

extern int g_MemcInitializeFailTrap; 
extern int g_MemcServerPushFailureTrap; 
extern int g_MemcSetConnectionFailTrap; 
extern int g_MemcGetConnectionFailTrap; 
extern int g_MemcServerDiffTimeTrap;
extern int g_MemcqueueThresholdTrap;
extern int g_InitialDBTpsReachedTrap;
extern int g_LaterDBTpsReachedTrap;

enum EModuleStatsType
{
   MODULE_STATS_TYPE_NORMAL = 0,
   MODULE_STATS_TYPE_TOTAL_SUCCESS
};

enum EModuleStatsEventStatus
{
   MODULE_STATS_EVENT_STATUS_UNKNOWN = 0,
   MODULE_STATS_EVENT_STATUS_TOTAL,
   MODULE_STATS_EVENT_STATUS_SUCCESS
};

extern map<string,EModuleStatsType> g_appStatsList;
extern bool moduleLevelAddHeader(char *p_header, EModuleStatsType p_type); //p_type=0 - Normal, 1-Total/Succcess
extern void moduleLevelLogStats(char *p_header, EModuleStatsEventStatus p_totorsuccess=MODULE_STATS_EVENT_STATUS_UNKNOWN);


#endif 

