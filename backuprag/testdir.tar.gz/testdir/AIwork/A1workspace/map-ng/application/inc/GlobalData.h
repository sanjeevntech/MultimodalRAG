#ifndef __GLOBAL_DATA_H
#define __GLOBAL_DATA_H

#include <time.h>
#include <Logger.h>
#include <map>
#include <StatisticsInitializationHelper.h>

extern char g_selfIpAddress[];
extern char g_selfEntityNameString[];
extern int  g_selfIpPort;
extern map<string,int> g_globalMap;


class TagValue
{
   public:
      map<string,string> m_data;
};

class TagValuePair
{
   public:
      map<string,TagValue*> m_moduleData;
      time_t               m_lastUpdatedDate;
};


class GlobalData
{
   public:
      GlobalData();
      virtual ~GlobalData();

      virtual void getStats(char *p_output);

      time_t m_lastUpdatedDate;

};



class CommonDataBase
{
   public:
      time_t m_lastUpdatedDate;

      CommonDataBase();
      virtual ~CommonDataBase();

      virtual void getStats(char *p_output);
      virtual bool isValidEntity(char *p_ip, char *p_name);
      virtual bool statisticsCallback(StatisticsGenerator *p_sg);
};

extern TagValuePair *g_tvp;
extern bool validateConfigurationData(TagValuePair *p_tvp, int p_flag, char *p_errorDesc, int p_maxErrorDescLength, char *p_module=NULL);
extern bool assignNewConfigurations();

#endif //__GLOBAL_DATA_H

