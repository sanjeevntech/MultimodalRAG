#ifndef __TIMEOUT_MANAGER_H
#define __TIMEOUT_MANAGER_H

#include <MessageQueue.h>
#include <map>
#include <TimeoutMsg.h>

using namespace std;


class TimerManager
{
   public:
      unsigned int m_currentTimerId;
      bool         m_initializedFlag;

      map<unsigned int, TimeoutMsg*> *m_data;

      MessageQueue *m_setTimerQueue;
      MessageQueue *m_resetQueue;
      MessageQueue *m_timeoutQueue;

      MessageQueue *m_hbRequestQueue;
      MessageQueue *m_hbResponseQueue;

   public:
      TimerManager();
      ~TimerManager();

      MessageQueue *getTimerQueue();
      MessageQueue *getResetQueue();
      MessageQueue *getTimeoutQueue();

      bool initialize();
      unsigned int startTimer(ContextBase *p_cb, int p_interval); //This should push into Input Queue and shall be used to push into m_data
      bool resetTimer(ContextBase *p_cb, unsigned int p_uniqueReferenceId); //This should push into Input Queue and shall be used to remove from m_data
      int  checkExpiredEvents();//This should return positive for any expired events, else -1
      void getStats(char *p_output);
};

extern TimerManager g_tm;

#endif

