#ifndef _SERVICE_COORDINATOR_H
#define _SERVICE_COORDINATOR_H

#include <stdio.h>
#include <MapMessages.h>
#include <DbQueryMsg.h>
#include <TimeoutMsg.h>
#include <SmppMsg.h>
#include <ConfigReader.h>
#include <MessageQueue.h>
#include <ContextBase.h>
#include <map>
using namespace std;

#define MAX_PARAM_STRING_SIZE      65535
#define MAX_ORIG_MODULE_NAME_SIZE  30

enum EInitiationType
{
   INITIATION_TYPE_UNKNOWN,
   INITIATION_TYPE_IMMEDIATE,
   INITIATION_TYPE_TARDILY
};

class InterModuleData:public Msg
{
   public:
      InterModuleData();
      ~InterModuleData();

      int   m_OpCode;
      char  m_OriginatorModule[MAX_ORIG_MODULE_NAME_SIZE+1];
      //char  m_Parameters[MAX_INTER_MODULE_DATA_SIZE+1];
      char *m_Parameters;
      Msg   *m_msgPtr;
};

class ServiceCoordinator
{
   public:
      // Constructor
      ServiceCoordinator();

      // Destructor
      ~ServiceCoordinator();

      // The Initializer
      bool initialize(int p_MaxDialogues);

      // Handles Incoming MAP Message
      bool recvMsg(MapMsg *p_MapMsg);

      // Handles DB Responses
      bool recvMsg(DbQueryMsg *p_DbQueryPtr);

      // Handles Memcached Responses
      bool recvMsg(MemCachedQueryMsg *p_MemcQueryPtr);

      // Handles Timeout Msg
      bool recvMsg(TimeoutMsg *p_tm);

      // Handles Smpp Msg
      bool recvMsg(SmppMsg *p_smpp);

      // This is for the Dialogue Initiator
      int getNewDialogue();

      // Handles Outgoing MAP Message    
      bool sendMsg(ContextBase *p_ContextBasePtr, MapMsg *p_MapMsgPtr);

      // Decodes the Hex Data
      bool decodeData(MapSpecificMsg* p_MapMsg, HexData *p_hexData);

      // This is used to initiate an Independent Context with Character Data as Input
      bool initiateIndependentContext(ContextBase *p_presentContext, EMapOpCode, char *, EInitiationType p_it=INITIATION_TYPE_IMMEDIATE);

      // This is used to initiate an Independent Context with Msg Data as Input
      bool initiateIndependentContext(ContextBase *p_presentContext, EMapOpCode p_opCode, Msg *p_msgPtr);

      bool sendSmppSubmit(char *p_destMsisdn, unsigned char *p_sms, int p_smsLen, int *p_SeqNumber, int p_dataCoding);

};

extern ServiceCoordinator g_sc;
extern MessageQueue *g_InterModuleQueue;
extern bool freeMemory(MapSpecificMsg *p_MapMsg);
extern bool logOSSPDU(MapSpecificMsg *p_MapMsg);

#endif

