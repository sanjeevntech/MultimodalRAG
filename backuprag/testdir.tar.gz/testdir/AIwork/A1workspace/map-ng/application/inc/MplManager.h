#ifndef __MPL_MANAGER_H
#define __MPL_MANAGER_H

#include <apiinc.h>
#include <tcap.h>
#include <tcerror.h>
#include <MapMessages.h>
#include <map>

using namespace std;

struct DbRequest;

#define MAX_NO_OF_COMPONENTS 10
#define STATS_MAX_APPL_CTXTS      50
#define STATS_MAX_OP_CODES        90
#define STATS_MAX_CONVERSATIONS   30
#define STATS_MAX_ERROR_CODES     75
#define STATS_MAX_OTHER_ERROR_CODES     20
#define STATS_MAX_TCAP_PRIMITIVES 20

enum EOtherErrorCodeType
{      
   OTHER_ERROR_CODE_RCVD_PRIMITIVE_VERSION_U_ABORT=0,
   OTHER_ERROR_CODE_RCVD_PRIMITIVE_GENERAL_U_ABORT,
   OTHER_ERROR_CODE_RCVD_PRIMITIVE_P_ABORT,
   OTHER_ERROR_CODE_RCVD_PRIMITIVE_TC_NOTICE,
   OTHER_ERROR_CODE_RCVD_PRIMITIVE_TC_L_CANCEL,
   OTHER_ERROR_CODE_RCVD_COMPONENT_TC_L_CANCEL,
   OTHER_ERROR_CODE_RCVD_COMPONENT_TC_U_CANCEL,
   OTHER_ERROR_CODE_RCVD_COMPONENT_TC_R_REJECT,
   OTHER_ERROR_CODE_RCVD_COMPONENT_TC_L_REJECT,
   OTHER_ERROR_CODE_RCVD_COMPONENT_TC_U_REJECT,
   OTHER_ERROR_CODE_SENT_PRIMITIVE_VERSION_U_ABORT,
   OTHER_ERROR_CODE_SENT_PRIMITIVE_GENERAL_U_ABORT,
   OTHER_ERROR_CODE_SENT_PRE_ARRANGED_END,  //added in HLR 2.0.21.0
   OTHER_ERROR_CODE_MAXIMUM
};

enum EDialogueAcceptanceType
{      /////////////////////////////////// IMPORTANT::  Don't change the sequence until 312. Code uses the sequencing.
/* 300 */      DLG_ACCEPT=300,
/* 301 */      DLG_REJECT_PEAK_LOAD_PER_SEC,
/* 302 */      DLG_REJECT_PEAK_LOAD_PER_SEC1,
/* 303 */      DLG_REJECT_PEAK_LOAD_PER_SEC2,
/* 304 */      DLG_REJECT_PEAK_LOAD_PER_SEC3,
/* 305 */      DLG_REJECT_PEAK_LOAD_PER_SEC4,
/* 306 */      DLG_REJECT_PEAK_LOAD_PER_SEC5,
/* 307 */      DLG_REJECT_PEAK_LOAD_MAX_DLGS,
/* 308 */      DLG_REJECT_PEAK_LOAD_MAX_DLGS1,
/* 309 */      DLG_REJECT_PEAK_LOAD_MAX_DLGS2,
/* 310 */      DLG_REJECT_PEAK_LOAD_MAX_DLGS3,
/* 311 */      DLG_REJECT_PEAK_LOAD_MAX_DLGS4,
/* 312 */      DLG_REJECT_PEAK_LOAD_MAX_DLGS5,
/* 313 */      DLG_UNABLE_TO_DEDUCE_APPL_PRIORITY,
/* 314 */      DLG_UNKNOWN_APPL_VERSION,
/* 315 */      DLG_APPL_CTXT_NOT_SUPPORTED_DOWNGRADE,
/* 316 */      DLG_APPL_CTXT_NOT_SUPPORTED_AT_ALL,
/* 317 */      DLG_APPL_ABSENT_IN_DLG_PORTION,
/* 318 */      DLG_DLG_PORTION_AND_COMPONENTS_ABSENT,
/* 319 */      DLG_NO_COMPONENTS_APART_FROM_BSG_IN_V1,
/* 320 */      DLG_APPL_REJECTION,
/* 321 */      DLG_INVALID_COMPONENT,
/* 322 */      DLG_REJECT_LATER_PEAK_LOAD_MAX_DLGS,
/* 323 */      DLG_REJECT_LATER_PEAK_LOAD_MAX_DLGS1,
/* 324 */      DLG_REJECT_LATER_PEAK_LOAD_MAX_DLGS2,
/* 325 */      DLG_REJECT_LATER_PEAK_LOAD_MAX_DLGS3,
/* 326 */      DLG_REJECT_LATER_PEAK_LOAD_MAX_DLGS4,
/* 327 */      DLG_REJECT_LATER_PEAK_LOAD_MAX_DLGS5,
/* 328 */      DLG_INVALID_TT,
/* 329 */      DLG_MAXIMUM
};

class TcapMsg
{
	public:
		TcapMsg();
		~TcapMsg();

		ctblock_t m_dlg;
		ctblock_t m_comp;
};

struct ApplCtxt
{
    int  m_TotalCount[3];
    int  m_SuccessCount[3];
};

struct OpCode
{
    int m_TotalCount[3];
    int m_SuccessCount[3];
};

struct Conversation
{
    int m_TotalCount[3];
    int m_SuccessCount[3];
};


struct StatsIndices
{
    ApplCtxt           m_Respondingappls         [STATS_MAX_APPL_CTXTS];
    OpCode             m_Respondingops           [STATS_MAX_OP_CODES];
    Conversation       m_Respondingcons          [STATS_MAX_CONVERSATIONS];

    ApplCtxt           m_Initiatingappls         [STATS_MAX_APPL_CTXTS];
    OpCode             m_Initiatingops           [STATS_MAX_OP_CODES];
    Conversation       m_Initiatingcons          [STATS_MAX_CONVERSATIONS];

    //int             m_OpCodeErrorCodeCounts [STATS_MAX_OP_CODES][STATS_MAX_ERROR_CODES];
    int             m_OpCodeOtherErrorCodeCnts [STATS_MAX_OP_CODES][STATS_MAX_OTHER_ERROR_CODES];
    map<string,int> m_opCodeErrorCodeCountsMap;
    int             m_OpCodeErrorCodeCnt [STATS_MAX_OP_CODES];

    int             m_RespondingTcapPrimCount [STATS_MAX_TCAP_PRIMITIVES];
    int             m_InitiatingTcapPrimCount [STATS_MAX_TCAP_PRIMITIVES];
};



class MplManager
{
   private:
      bool sendAbort(int p_dialogueId, U8, U8, int );
      bool simpleSendAbort(int p_dialogueId, U8 p_AbortCause, U8 p_AbortReason, int p_supportedVersion);
      bool sendToTcapStack(ctblock_t *p_tcapBlock);
      bool prepareDlgPortion(int p_dialogueId, ctblock_t *p_tcapMsg, ctcap_dp_t *l_dp);
      bool prepareReject(int p_dialogId, int p_invokeId, ctblock_t *p_request, U8 p_problemType, U8 p_problemId);
      bool logSuccessDialogue(int p_dialog);
      bool logOtherErrorCodeStats(int p_dialog, int p_errorCode);
      bool sendError(int p_dialogueId, EMapErrorCode p_errorCode);

   public:
      MplManager();
      ~MplManager();

      struct StatsIndices m_si;
      bool initialize(int p_dialogs);
      bool processTcapMessage(ctblock_t *p_tcapMsg);
      bool processTcapDlgMessage(ctblock_t *p_tcapMsg, ctblock_t *p_tcapCompMsg,ctblock_t *p_tcapCompMsg2);
      bool processTcapComponents(ctblock_t *p_tcapMsg);
      bool recvMapMsg(MapMsg *p_MapMsgPtr);
      bool overload(EMsgType p_msgType, int p_dialogid, int p_applCtxt);
};

extern MplManager g_MplManager;
extern void printTcapBlock(char *p_string, ctblock_t *p_tcap, int);


#endif
