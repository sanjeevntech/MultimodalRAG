#ifndef __DLG_CONTEXT_H
#define __DLG_CONTEXT_H

#include <apiinc.h>
#include <tcap.h>
#include <tcerror.h>
#include <MapMessages.h>
#include <sccp-addr.h>
#include <TdrData.h>

enum EDialogueType
{
   DLG_TYPE_UNKNOWN = 0,
   DLG_TYPE_NETWORK_INITIATED = 1,
   DLG_TYPE_APPLICATION_INITIATED = 2
};

enum EDialogueState
{
   DLG_STATE_IDLE =0,
   DLG_STATE_WAIT_FOR_LOAD_CHECK_RESULT_1,
   DLG_STATE_DIALOGUE_PENDING,
   DLG_STATE_ACCEPTED,
   DLG_STATE_ESTABLISHED,
   DLG_STATE_WAIT_FOR_USER_REQUESTS,
   DLG_STATE_DLG_INITIATED,
   DLG_STATE_GOT_L_CANCEL,
   DLG_STATE_WAIT_FOR_INIT_DATA
};


class Csm
{
   public:
      Csm();
      ~Csm();

      int m_InvokeId;
      EMapOpCode m_OpCode;
};


class DlgContext
{
   public:
      DlgContext();
      ~DlgContext();

      void reset();

      EDialogueType    m_DlgType;
      EDialogueState   m_DlgState;

      U16	m_appl_id;

      int        m_dp_present_ind;
      ctcap_dp_t m_dp;

      int m_UserDlgId;

      Csm m_psm;
      Csm m_rsm;

      int m_lastRequestedInvokeId;
      int getNextInvokeId();


      bool m_firstContinuePassed;

      unsigned char m_UserInfoToBeSent[50];
      int m_UserInfoLength;

      EMapApplicationContext m_InitiatingApplCntxt;
      EMapOpCode             m_InitiatingOpCode;
      EMapVersion            m_InitiatingMapVersion;

      EMapApplicationContext m_IncomingApplCntxt;
      EMapOpCode             m_IncomingOpCode;
      EMapVersion            m_IncomingMapVersion;

      SccpAddress m_DestAddr;

      L_SccpAddress m_CustomizedSelfAddress;

      U8      m_tmp_remote_address[MAX_ADDR_LEN];
      U8      m_tmp_local_address[MAX_ADDR_LEN];

      bool            m_ErrorExchangedFlag;
      EMapErrorCode   m_ErrorCodeExchanged;


      int     m_IncomingSccpClass;
      bool    m_NotLastCompExchanged;

      TdrData  *m_tdr;
      bool     m_crossedNg;

      char m_remoteGT[20 + 1];
};

extern DlgContext *g_DlgContexts;


#endif

