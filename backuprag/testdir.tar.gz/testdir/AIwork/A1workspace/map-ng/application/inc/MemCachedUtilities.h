#ifndef __MEMC_UTILITIES_H
#define __MEMC_UTILITIES_H

#include<string>
using namespace std;

extern bool RetrieveMemCached(void *p, string pKey, string &pValue, int &pErrCode, string &pErrDesc, bool pHomeImsi, string pMemcIp, int pMemcPort);

extern bool UpdateMemCached(void *p, string pKey, string &pValue, int &pErrCode, string &pErrDesc, bool pHomeImsi, string pMemcIp, int pMemcPort);

extern bool DeleteMemCached(void *p, string pKey, int &pErrCode, string &pErrDesc);

extern bool SoftDeleteMemCached(void *p, string pKey, string &pValue, int &pErrCode, string &pErrDesc);

extern int g_HomeImsiGetMemcQueryTotal;
extern int g_HomeImsiSetMemcQueryTotal;
extern int g_OtherImsiGetMemcQueryTotal;
extern int g_OtherImsiSetMemcQueryTotal;

extern int g_HomeImsiGetMemcQuerySuccess;
extern int g_HomeImsiSetMemcQuerySuccess;
extern int g_OtherImsiGetMemcQuerySuccess;
extern int g_OtherImsiSetMemcQuerySuccess;

extern int g_HomeImsiGetMemcQueryMissesNoData;
extern int g_OtherImsiGetMemcQueryMissesNoData;

extern int g_HomeImsiGetMemcQueryMissesCommuniError;
extern int g_HomeImsiSetMemcQueryMissesCommuniError;
extern int g_OtherImsiGetMemcQueryMissesCommuniError;
extern int g_OtherImsiSetMemcQueryMissesCommuniError;

extern int g_deleteMemcQueryTotal;
extern int g_deleteMemcQuerySuccess;
extern int g_deleteMemcQueryFailure;

extern int g_ULRHomeImsiGetMemcQueryTotal;
extern int g_ULRHomeImsiSetMemcQueryTotal;

extern int g_ULRHomeImsiGetMemcQuerySuccess;
extern int g_ULRHomeImsiSetMemcQuerySuccess;

extern int g_ULRHomeImsiGetMemcQueryMissesNoData;

extern int g_ULRHomeImsiGetMemcQueryMissesCommuniError;
extern int g_ULRHomeImsiSetMemcQueryMissesCommuniError;

extern int g_ULRdeleteMemcQueryTotal;
extern int g_ULRdeleteMemcQuerySuccess;
extern int g_ULRdeleteMemcQueryFailure;

#endif /* __MEMC_UTILITIES_H */
