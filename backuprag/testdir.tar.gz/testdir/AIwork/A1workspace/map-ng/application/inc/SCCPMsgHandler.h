#ifndef _SCCPMSGHANDLER_H_
#define _SCCPMSGHANDLER_H_
#include <string>

#include <apiinc.h>
#include <tcap.h>
#include <tcerror.h>
#include <ObjectServer.h>
#include <ccapiproto.h>
#include <UniTypes.h>


#define SERVER_QOS CL_SVC_CLASS_1
#define MY_NAME (pSHM->cpt[OwnClientTableEntry].ClientLogicalName)
#define SERVER_OOS_NAME (FT_ACTIVE_PREFIX ObjectSVRLogicalNAME)


class SCCPMsgHandler
{
   public:
      s16 decodeLongDefLen(u8 *msg);
      s32 decodeTCAPMsg(sblock_t &sblockIn, u32 &);
      bool processSCCPMsg(sblock_t *sblockIn, int& paddedBytes, char* pSriMSISDN);

      void processMAPMsg(sblock_t *sblockIn, int opCode, SccpAddress *calledParty, u8 *tc_msg, u8 *pTcLen, u8 *pCompLen, u8 *pMsgLen, int &paddedBytes, u8 *oTxId, char *callingParty, char* pMSISDN);
}; 

#endif 
