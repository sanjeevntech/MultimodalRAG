#ifndef __GET_DB_CONN_H
#define __GET_DB_CONN_H

extern void *getConnObject(char *p_connStr, char *p_alias);
extern void *getConnCtx(void *p_connObject);
extern void destructConnObject(void *p_connObject);
extern void rollback(void *p_connObject);

#endif


