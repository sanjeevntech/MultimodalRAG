#ifndef __CTXT_SUBS_PROFILES_H
#define __CTXT_SUBS_PROFILES_H

class CtxtSubsProfiles : public ContextBase
{
	public:
		CtxtSubsProfiles();
		~CtxtSubsProfiles();

		bool processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag);
};



#endif
