/*********************************************************************
 ** FILE NAME    : NetworkInterface.h
 ** AUTHOR       : 
 ** DEFINITION   : Class for interface with SS7 stack.
 *********************************************************************/

#ifndef __NETWORK_INTERFACE_H
#define __NETWORK_INTERFACE_H

#include <apiinc.h>
#include <tcap.h>
#include <tcerror.h>
#include <ObjectServer.h>
#include <ccapiproto.h>

using namespace std;

/***************************************************************************/
#define OC_NUMBER_TO_ADD 1      /* opcodes for the application */
#define OC_SUM 2
#define SUM_DATA_TAG 4          /* universal OCTETSTRING */

class NetworkInterface  // A singleton class
{
   NetworkInterface() {};

   int getPCfromAddress (U8 *);
   int getSSNfromAddress (U8 *);
   int m_nodeIndex;

   public:

   static NetworkInterface& getInstance();

   virtual ~NetworkInterface() {};    // destructor
   bool openConn(int, char**); // A wrapper for SS7_xifcreate
   void handleTcapMsg(void);
   int sendRecvMsgs();
   int terminate();
};

#endif /* __NETWORK_INTERFACE_H */
