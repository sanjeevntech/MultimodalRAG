#include <SelfSlhSimulator.h>
#include <LcsRoutingInfo.h>
#include <Slh_rel_10AVP.h>
#include <Logger.h>

#include <DiameterMessages.h>
#include <ExtendedServiceCoordinator.h>
#include <DiameterConstants.h>

#include <ExtendedServiceCoordinator.h>

using namespace diameter::base;
using namespace diameter::slh_rel_10;




SelfSlhSimulator::SelfSlhSimulator()
{
}

SelfSlhSimulator::~SelfSlhSimulator()
{
}

bool SelfSlhSimulator::getMessage(int p_opCode, Msg **p_msgPtr, Msg *p_ReqMsgPtr)
{
   switch(p_opCode)
   {
      case DIAM_COMM_CODE_SLH_RIR_RIA:
         {
            LLOG(0,0,"selfSimulate: RIR");
            unsigned int sIdx;
            string sessIdString;
            if(false == g_esc.allocateSession(DIAM_APP_ID_SLH, 
                     sIdx, 
                     sessIdString))
            {
               ELOG(0,1,"Unable to allocate a session");
               return false;
            }
            *p_msgPtr = new DiameterMsg((char*)sessIdString.c_str(), DIAM_EVENT_REQUEST, DIAM_COMM_CODE_SLH_RIR_RIA);
            DiameterMsg *l_test = (DiameterMsg*)(*p_msgPtr);

            //Prepare a AIR Message
            diameter::slh_rel_10::LCSRoutingInfoRequest *l_air = new diameter::slh_rel_10::LCSRoutingInfoRequest;
            //l_air->setSessionId(diameter::base::SessionId(sessIdString));
            l_air->setSessionIndex(sIdx);


            AuthSessionState authSessionState(AuthSessionState::NO_STATE_MAINTAINED);
            l_air->setAuthSessionState(authSessionState);

            OriginHost originHost = diameter::base::OriginHost("origin.mme");
            l_air->setOriginHost(originHost);

            OriginRealm originRealm("OriginRealm");
            l_air->setOriginRealm(originRealm);

            DestinationRealm destinationRealm("DestinationRealm");
            l_air->setDestinationRealm(destinationRealm);

            UserName userName("110000000000009");
            l_air->setUserName(userName);

            GMLCNumber gmlcNumber("TestGmlc");
            l_air->setGMLCNumber(gmlcNumber);

#if 0
            RequestedEUTRANAuthenticationInfo REAInfo; 
            NumberOfRequestedVectors nofreqvect1(10);
            REAInfo.setNumberOfRequestedVectors(nofreqvect1);
            ImmediateResponsePreferred	imrespref1(2);
            REAInfo.setImmediateResponsePreferred(imrespref1);

            ReSynchronizationInfo rsinfo1("987654321098765432109876543210");
            REAInfo.setReSynchronizationInfo(rsinfo1);

            l_air->setRequestedEUTRANAuthenticationInfo(REAInfo);

            RequestedUTRANGERANAuthenticationInfo RUGAInfo;
            NumberOfRequestedVectors nofreqvect2(11);
            RUGAInfo.setNumberOfRequestedVectors(nofreqvect2);
            ImmediateResponsePreferred  imrespref2(3);
            //RUGAInfo.setImmediateResponsePreferred(imrespref2);

            ReSynchronizationInfo rsinfo2("123456789012345678901234567890");
            //RUGAInfo.setReSynchronizationInfo(rsinfo2);

            //l_air->setRequestedUTRANGERANAuthenticationInfo(RUGAInfo);
            VisitedPLMNId  visPLMNid("visitedPLMNID123");
            l_air->setVisitedPLMNId(visPLMNid);
#endif

            l_test->m_cmd = l_air;
            l_test->m_allocatedFlag = true;
         }
         break;
      default:
         {
            LLOG(0,0,"selfSimulate: Default");
         }
         break;
   }
   return true;
}
