#include <ModuleBase.h>
#include <Logger.h>
#include <ServiceCoordinator.h>


ModuleBase::ModuleBase()
{
}

ModuleBase::~ModuleBase()
{
}

ContextBase* ModuleBase::getCtxtObj(EDiameterCommandCode p_OpCode,InterModuleData *p_msg)
{   
   LLOG(0,0,"should not call ModuleBase::getCtxtObj")
   return NULL;
}

