#include <DbActiveObject.h>
#include <pthread.h>
#include <stdio.h>
#include <MessageQueue.h>
#include <DbQueryMsg.h>
#include <GetDbConnection.h>
#include <ConfigReader.h>
#include <SnmpInterface.h>
#include <Logger.h>
#include <Utilities.h>
#include <DataUnion.h>
#include <StatisticsInterface.h>
#include <StatisticsGenerator.h>
#include <map>
#include <typeinfo>
#include <MemCachedActiveObject.h>
#include <GutilDAFInterface.h>
#include <GUtilThreadHeartBeat.h>

using namespace std;

extern GenericUtilitiesFrameworkInterface *g_daf;     //to get DAF TPS for DB - added in HLR 5.1.0.0
pthread_key_t g_key;
pthread_key_t g_key1;
extern void *getCtx(void *co);
DbActiveObject g_act;
pthread_mutex_t g_connLock;
bool g_trapSent=false;

extern pthread_mutex_t    g_dbMapMutex;

extern bool checkConnection();
extern void enableThreads();

DbQueryMsg *g_HeartBeatMsgPtr;

extern int g_maxInitialDbTpsIndex;
extern int g_maxLaterDbTpsIndex;


DbActiveObject::DbActiveObject()
{
   m_initializationFlag = false;
   memset(&m_activeThreads, '\0', sizeof(m_activeThreads));
   m_explicitMonitoringFlag=false;
   m_laterQueryInitFlag = false;
}

DbActiveObject::~DbActiveObject()
{

}

void *callGetConnObject(char *p_connStr, char *p_alias)
{
   void *l_result=NULL;
   l_result = getConnObject(p_connStr, p_alias);
   return l_result;
}

void releaseConnObject(void *p_conn)
{
   destructConnObject(p_conn);
}



void *reconnect(int p_connIndex, int p_thrMonRetIndex)
{
   void *l_ConnectionObject = NULL;
   //void *l_ociSvc = NULL;
   //void *l_ociErr = NULL;

   if (1 == g_ConfigData->i_DbConfigData.m_NoOfNodes)
   {
      if ('R' == g_OtherConfigData->m_DbFailedConnectionRetryType)  //1-nodes. Retry
      {
         int l_retryCount=0;
         while (1)
         {
            if(0 != l_retryCount)
            {
               sleep(60);
            }
            l_retryCount++;
            LLOG(0,1,"Retrying DB01:[%s] the %d time", g_OtherConfigData->m_DbAliasStringArr[p_connIndex], l_retryCount);
            l_ConnectionObject = NULL;
            l_ConnectionObject = callGetConnObject(g_OtherConfigData->m_DbActualStringArr[p_connIndex],
                  g_OtherConfigData->m_DbAliasStringArr[p_connIndex]);
            if (NULL == l_ConnectionObject)
            {
               releaseConnObject(l_ConnectionObject);
               CLOG(0,1,"Unable to connect to DB01:[%s]", g_OtherConfigData->m_DbAliasStringArr[p_connIndex]);
               continue;
            }
            else
            {
               CLOG(0,1,"Connected to DB01:[%s]", g_OtherConfigData->m_DbAliasStringArr[p_connIndex]);
               break;
            }
         }
      }
      else if('N' == g_OtherConfigData->m_DbFailedConnectionRetryType)
      {
         CLOG(0,1,"No retry configured");
         l_ConnectionObject = NULL;
         l_ConnectionObject = callGetConnObject(g_OtherConfigData->m_DbActualStringArr[p_connIndex],
               g_OtherConfigData->m_DbAliasStringArr[p_connIndex]);
         if (NULL == l_ConnectionObject)
         {
            releaseConnObject(l_ConnectionObject);
            CLOG(0,1,"Unable to connect to DB01:[%s]", g_OtherConfigData->m_DbAliasStringArr[p_connIndex]);
         }
         else
         {
            CLOG(0,1,"Connected to DB01:[%s]", g_OtherConfigData->m_DbAliasStringArr[p_connIndex]);
         }
      }
      else
      {
         ELOG(0,1,"Invalid mode %c for node count 1", g_OtherConfigData->m_DbFailedConnectionRetryType);
      }
   }
   else 
   {
      if ('S' == g_OtherConfigData->m_DbFailedConnectionRetryType)  //2-nodes. Switchover
      {
         if (0 == p_connIndex )
         {
            l_ConnectionObject = callGetConnObject(g_OtherConfigData->m_DbActualStringArr[0],
                  g_OtherConfigData->m_DbAliasStringArr[0]);
            if (NULL == l_ConnectionObject)
            {
               g_si.sendSnmpTrap(g_DbConnectionTrap1, TRAP_TYPE_FAIL, TRAP_SEVERITY_CRITICAL);
               l_ConnectionObject = callGetConnObject(g_OtherConfigData->m_DbActualStringArr[1],
                     g_OtherConfigData->m_DbAliasStringArr[1]);
               if (NULL == l_ConnectionObject)
               {
                  CLOG(0,1,"Unable to connect to DB02: %s", g_OtherConfigData->m_DbAliasStringArr[1]);
               }
            }
         }
         else
         {
            l_ConnectionObject = callGetConnObject(g_OtherConfigData->m_DbActualStringArr[1],
                  g_OtherConfigData->m_DbAliasStringArr[1]);
            if (NULL == l_ConnectionObject)
            {
               g_si.sendSnmpTrap(g_DbConnectionTrap2, TRAP_TYPE_FAIL, TRAP_SEVERITY_CRITICAL);
               l_ConnectionObject = callGetConnObject(g_OtherConfigData->m_DbActualStringArr[0],
                     g_OtherConfigData->m_DbAliasStringArr[0]);
               if (NULL == l_ConnectionObject)
               {
                  CLOG(0,1,"Unable to connect to DB01: %s", g_OtherConfigData->m_DbAliasStringArr[0]);
               }
            }
         }
      }
      else if('R' == g_OtherConfigData->m_DbFailedConnectionRetryType)// Retry for ever
      {
         int l_retryCount=0;
         while (1)
         {
            if(0 != l_retryCount)
            {
               sleep(60);
            }
            l_retryCount++;

            LLOG(0,1,"Retrying DB%02d:[%s] the %d time", 1+p_connIndex, g_OtherConfigData->m_DbAliasStringArr[p_connIndex], l_retryCount);
            l_ConnectionObject = NULL;
            l_ConnectionObject = callGetConnObject(g_OtherConfigData->m_DbActualStringArr[p_connIndex],
                  g_OtherConfigData->m_DbAliasStringArr[p_connIndex]);
            if (NULL == l_ConnectionObject)
            {
               releaseConnObject(l_ConnectionObject);
               CLOG(0,1,"Unable to connect to DB%02d:[%s]", 1+p_connIndex, g_OtherConfigData->m_DbAliasStringArr[p_connIndex]);
               continue;
            }
            else
            {
               CLOG(0,1,"Connected to DB%02d:[%s]", 1+p_connIndex, g_OtherConfigData->m_DbAliasStringArr[p_connIndex]);
               break;
            }
         }
      }
      else
      {
         CLOG(0,1,"No retry or switchover configured");
      }
   }

   if (NULL == l_ConnectionObject)
   {
      pthread_mutex_lock(&g_connLock);
      g_si.sendSnmpTrap(g_DbConnectionTrap, TRAP_TYPE_FAIL, TRAP_SEVERITY_CRITICAL);
      CLOG(0,1,"Unable to get the db connection\n\n");
      exitFunc(EXIT_APPLICATION_TYPE_UNABLE_TO_GET_DB_CONNECTION);
   }
   else 
   {
      if (false == g_trapSent)
      {
         g_si.sendSnmpTrap(g_DbConnectionTrap, TRAP_TYPE_PASS, TRAP_SEVERITY_MINOR);
         g_trapSent=true;
      }
   }

   return l_ConnectionObject;
}

int getCurrentDstFlag()
{
   time_t l_tim =time(NULL);
   struct tm *l_tm_ptr=NULL;
   l_tm_ptr = localtime(&l_tim);
   return l_tm_ptr->tm_isdst;
}

void *dbActiveThreadFunc(void *p)
{
   if (NULL == p)
   {
      WLOG(0,1,"Invalid parameters to the thread");
      return NULL;
   }

   int l_dbConnectionIndex = *((int*)p);
   LLOG(0,1,"dbActiveThreadFunc called with connection index:%d", l_dbConnectionIndex);

   //char dummyarr[4000];
   printSignalSet("db thread signals");

   int l_ret;
   l_ret = pthread_key_create(&g_key, NULL);
   if (l_ret != 0)
   {
      perror("Unable to create a key ");
      CLOG(0,1,"Unable to create a key ");
   }

   char *l_test = new char[20+1];
   memset(l_test, '\0', 20+1);
   strcpy(l_test, "dummy");

   l_ret = pthread_setspecific(g_key, l_test);
   if (l_ret != 0)
   {
      perror("Unable to set a value");
      CLOG(0,1,"Unable to set a value");
   }

   int l_retIndex=0;

   void *l_ConnectionObject = NULL;
   l_ConnectionObject = reconnect(l_dbConnectionIndex, l_retIndex);
   int l_dstFlag = getCurrentDstFlag();
   LLOG(0,0,"DST value:%d initially", l_dstFlag);

   MessageQueue *l_mq = g_act.m_queues.m_req;

   /*THB RegisterMe*/
   if(0 != g_OtherConfigData->m_THBEnabled)
   {
      int l_ThbInterval = 0;
      if(g_OtherConfigData->m_DbHeartBeatInterval > 0)
      {
         l_ThbInterval = g_OtherConfigData->m_DbHeartBeatInterval+60;
      }
      else
      {
         l_ThbInterval = 60;
      }

      if(false == g_thb.registerMe(l_ThbInterval, "dbActiveThreadFunc"))
      {
         CLOG(0,0,"RegisterMe failed on dbActiveThreadFunc Thread");
         exit(1);
      }
   }

   /*THB RegisterMe*/


   while (1)
   {
      void *l_request = NULL;
      DLOG(0,1,"Waiting for DB Request");

      /*THB IAMALIVE*/
      if((0 != g_OtherConfigData->m_THBEnabled) && ((g_simulateThbHungInterval == 0 ) || (time(NULL) >= g_currTimeForTHB + g_simulateThbHungInterval)))
      {
         //ELOG(0,0,"THB Testing 1... Exiting...");
         if(false == g_thb.iAmAlive())
         {
            ELOG(0,0,"THB iAmAlive failed. Exiting...");
            exitFunc(EXIT_APPLICATION_TYPE_THB_I_AM_ALIVE_FAILED);
         }
      }
      /*THB IAMALIVE*/
 
      bool l_status = l_mq->pop(&l_request);
      DbQueryMsg *l_dqm = NULL;
      if (true == l_status)
      {
         l_dqm = (DbQueryMsg *)l_request;
      }
      else
      {
         if(1 == g_OtherConfigData->m_DbHeartBeatRequiredFlag)                                   
         {
            DLOG(0,1,"HA is enabled");
            if(NULL != g_HeartBeatMsgPtr)
            {
               CLOG(0,1,"InitialDBQuery HeartBeat: Pushing the g_HeartBeatMsgPtr into the queue");
               l_dqm = g_HeartBeatMsgPtr;
            }
            else
            {
               ELOG(0,1,"g_HeartBeatMsgPtr is NULL. Unable to initiate DB Heart Beat Msg");
            }
         }
         else
         {
            DLOG(0,1,"ERROR!! In getting a message from the queue. This is probably due to a signal");
         }
      }
      if(NULL != l_dqm)
      {
         int l_currentDstFlag = getCurrentDstFlag();
         if( l_currentDstFlag != l_dstFlag)
         {
            CLOG(0,0,"DST changed (Old:%d, New:%d) doing a reconnect ...", l_dstFlag, l_currentDstFlag);
            releaseConnObject(l_ConnectionObject);
            l_ConnectionObject = reconnect(l_dbConnectionIndex, l_retIndex);
            l_dstFlag = l_currentDstFlag;
         }
         struct timeval l_currTv, l_prevTv;
         getTime(l_currTv, l_prevTv, NULL, NULL);


         pthread_mutex_lock(&g_act.m_activeMutex);
         ++g_act.m_activeThreads[l_dbConnectionIndex];
         ++g_act.m_queryCount[l_dbConnectionIndex];
         pthread_mutex_unlock(&g_act.m_activeMutex);

         DLOG(0,1,"Calling execute query of %s", typeid(*l_dqm).name());

         char l_identityBuffer[25];
         memset(l_identityBuffer, '\0', sizeof(l_identityBuffer));
         if(NULL != l_dqm->m_cb)
         {
            sprintf(l_identityBuffer, "%3s%3s:%08d", l_dqm->m_cb->m_ModName, l_dqm->m_cb->m_MessageName, l_dqm->m_cb->m_GlobalContextId);
         }
         else
         {
            sprintf(l_identityBuffer, "HEART-BEAT");
         }
         TLOG(0,1,"Query for context [%s]", l_identityBuffer);

         l_dqm->executeQuery(getConnCtx(l_ConnectionObject));
         if(  (0 != l_dqm->m_sqlcode) &&  (-1405 != l_dqm->m_sqlcode) )
         {
            if(NULL != l_dqm->m_cb)
            {
               CLOG(0,1,"Execute query of %s code:%d", typeid(*l_dqm).name(), l_dqm->m_sqlcode);
            }
         }

         bool l_ociPingStatus = true;
         if (-1013 == l_dqm->m_sqlcode)
         {
            l_ociPingStatus = checkConnection();
            if (false == l_ociPingStatus)
            {
               WLOG(0,1,"OCIPing failed");
            }
         }

         pthread_mutex_lock(&g_act.m_activeMutex);
         --g_act.m_activeThreads[l_dbConnectionIndex];
         pthread_mutex_unlock(&g_act.m_activeMutex);

         char l_name[100];
         memset(l_name, '\0', 100);
         sprintf(l_name, "DB Query Execution (%s) RAC:%02d", typeid(*l_dqm).name(), 1+l_dbConnectionIndex);
         struct timeval l_diffTv;
         getTime(l_currTv, l_prevTv, l_name, &l_diffTv);
         TLOG(0,1,"Time diff: %d %06d", l_diffTv.tv_sec, l_diffTv.tv_usec);
         StatisticsInterface::logDiffTimeStatistics((char*)typeid(*l_dqm).name(), &l_diffTv, l_dbConnectionIndex);

         char l_sqlcodeChar[20];
         memset(l_sqlcodeChar, '\0', 20);
         sprintf(l_sqlcodeChar, ":%d:", l_dqm->m_sqlcode);

         if (-1 == l_dqm->m_sqlcode)
         {
            CLOG(0,1,"ERROR!! sqlcode is not set for the db query");
         }
         if( (strstr(g_ConfigData->i_DbConfigData.m_OraErrorCodes, l_sqlcodeChar)) || (false == l_ociPingStatus))
         {
            CLOG(0,1,"Doing a reconnect ...");
            releaseConnObject(l_ConnectionObject);
            l_ConnectionObject = reconnect(l_dbConnectionIndex, l_retIndex);
            l_dstFlag = getCurrentDstFlag();
            LLOG(0,0,"DST value:%d during reconnection", l_dstFlag);
         }

         if(NULL != l_dqm->m_cb)
         {
            DLOG(0,1,"Pushing the DB Response into the queue");
            g_act.m_queues.m_res->push(l_dqm);
            DLOG(0,1,"Pushed the DB Response into the queue");
         }
      }
      else
      {
         WLOG(0,1,"l_dqm is NULL"); //changing ELOG to WLOG due to QUEUE_TYPE_BLOCKING_TIMED_WAIT
      }
   }

   ELOG(0,1,"ERROR!!! Thread func exit");
}

void *LaterQueryThreadFunc(void *p)
{
   if (NULL == p)
   {
      WLOG(0,1,"Invalid parameters to the thread");
      return NULL;
   }

   int l_dbConnectionIndex = *((int*)p);
   LLOG(0,1,"LaterQueryThreadFunc called with connection index:%d", l_dbConnectionIndex);

   //char dummyarr[4000];
   printSignalSet("db thread signals");

   int l_ret;
   l_ret = pthread_key_create(&g_key1, NULL);
   if (l_ret != 0)
   {
      perror("Unable to create a key ");
      CLOG(0,1,"Unable to create a key ");
   }

   char *l_test = new char[20+1];
   memset(l_test, '\0', 20+1);
   strcpy(l_test, "dummy");

   l_ret = pthread_setspecific(g_key1, l_test);
   if (l_ret != 0)
   {
      perror("Unable to set a value");
      CLOG(0,1,"Unable to set a value");
   }

   int l_retIndex=0;

   void *l_ConnectionObject = NULL;
   l_ConnectionObject = reconnect(l_dbConnectionIndex, l_retIndex);
   int l_dstFlag = getCurrentDstFlag();
   LLOG(0,0,"DST value:%d initially", l_dstFlag);

   MessageQueue *l_mq = g_act.m_queues.m_LaterQueryReq;

   
   /*THB RegisterMe*/
   if(0 != g_OtherConfigData->m_THBEnabled)
   {
      int l_ThbInterval = 0;
      if(g_OtherConfigData->m_DbHeartBeatInterval > 0)
      {
         l_ThbInterval = g_OtherConfigData->m_DbHeartBeatInterval+60;
      }
      else
      {
         l_ThbInterval = 60;
      }

      if(false == g_thb.registerMe(l_ThbInterval, "LaterQueryThreadFunc"))
      {
         CLOG(0,0,"RegisterMe failed on LaterQueryThreadFunc Thread");
         exit(1);
      }
   }

   /*THB RegisterMe*/


   while (1)
   {
      void *l_request = NULL;
      DLOG(0,1,"Waiting for DB Request");

      /*THB IAMALIVE*/
      if((0 != g_OtherConfigData->m_THBEnabled) && ((g_simulateThbHungInterval == 0 ) || (time(NULL) >= g_currTimeForTHB + g_simulateThbHungInterval)))
      {
         if(false == g_thb.iAmAlive())
         {
            ELOG(0,0,"THB iAmAlive failed. Exiting...");
            exitFunc(EXIT_APPLICATION_TYPE_THB_I_AM_ALIVE_FAILED);
         }
      }
      /*THB IAMALIVE*/


      DLOG(0,0,"Calling pop in LaterQueryThread");    //for Debug later needs to remove
      bool l_status = l_mq->pop(&l_request);
      DLOG(0,0,"Called pop in LaterQueryThread, status is %d",l_status);    //for Debug later needs to remove
      DbQueryMsg *l_dqm = NULL;
      if (true == l_status)
      {
         l_dqm = (DbQueryMsg *)l_request;
      }
      else
      {
         if(1 == g_OtherConfigData->m_DbHeartBeatRequiredFlag)                                   
         {
            DLOG(0,1,"HA is enabled");
            if(NULL != g_HeartBeatMsgPtr)
            {
               CLOG(0,1,"LaterDBQuery HeartBeat: Pushing the g_HeartBeatMsgPtr into the queue");
               l_dqm = g_HeartBeatMsgPtr;
            }
            else
            {
               ELOG(0,1,"g_HeartBeatMsgPtr is NULL. Unable to initiate DB Heart Beat Msg");
            }
         }
         else
         {
            DLOG(0,1,"ERROR!! In getting a message from the queue. This is probably due to a signal");
         }
      }
      if(NULL != l_dqm)
      {
         int l_currentDstFlag = getCurrentDstFlag();
         if( l_currentDstFlag != l_dstFlag)
         {
            CLOG(0,0,"DST changed (Old:%d, New:%d) doing a reconnect ...", l_dstFlag, l_currentDstFlag);
            releaseConnObject(l_ConnectionObject);
            l_ConnectionObject = reconnect(l_dbConnectionIndex, l_retIndex);
            l_dstFlag = l_currentDstFlag;
         }
         struct timeval l_currTv, l_prevTv;
         getTime(l_currTv, l_prevTv, NULL, NULL);


         pthread_mutex_lock(&g_act.m_activeMutex);
         ++g_act.m_activeThreads[l_dbConnectionIndex];
         ++g_act.m_queryCount[l_dbConnectionIndex];
         pthread_mutex_unlock(&g_act.m_activeMutex);

         DLOG(0,1,"Calling execute query of %s", typeid(*l_dqm).name());

         char l_identityBuffer[25];
         memset(l_identityBuffer, '\0', sizeof(l_identityBuffer));
         if(NULL != l_dqm->m_cb)
         {
            sprintf(l_identityBuffer, "%3s%3s:%08d", l_dqm->m_cb->m_ModName, l_dqm->m_cb->m_MessageName, l_dqm->m_cb->m_GlobalContextId);
         }
         TLOG(0,1,"Query for context [%s]", l_identityBuffer);

         l_dqm->executeQuery(getConnCtx(l_ConnectionObject));
         if(  (0 != l_dqm->m_sqlcode) &&  (-1405 != l_dqm->m_sqlcode) )
         {
            if(NULL != l_dqm->m_cb)
            {
               CLOG(0,1,"Execute query of %s code:%d", typeid(*l_dqm).name(), l_dqm->m_sqlcode);
            }
         }

         bool l_ociPingStatus = true;
         if (-1013 == l_dqm->m_sqlcode)
         {
            l_ociPingStatus = checkConnection();
            if (false == l_ociPingStatus)
            {
               WLOG(0,1,"OCIPing failed");
            }
         }

         pthread_mutex_lock(&g_act.m_activeMutex);
         --g_act.m_activeThreads[l_dbConnectionIndex];
         pthread_mutex_unlock(&g_act.m_activeMutex);

         char l_name[100];
         memset(l_name, '\0', 100);
         sprintf(l_name, "LaterQueryThreadFunc: DB Query Execution (%s) RAC:%02d", typeid(*l_dqm).name(), 1+l_dbConnectionIndex);
         struct timeval l_diffTv;
         getTime(l_currTv, l_prevTv, l_name, &l_diffTv);
         TLOG(0,1,"Time diff: %d %06d", l_diffTv.tv_sec, l_diffTv.tv_usec);
         //StatisticsInterface::logDiffTimeStatistics((char*)typeid(*l_dqm).name(), &l_diffTv, l_dbConnectionIndex);

         char l_sqlcodeChar[20];
         memset(l_sqlcodeChar, '\0', 20);
         sprintf(l_sqlcodeChar, ":%d:", l_dqm->m_sqlcode);

         if (-1 == l_dqm->m_sqlcode)
         {
            CLOG(0,1,"ERROR!! sqlcode is not set for the db query");
         }
         if( (strstr(g_ConfigData->i_DbConfigData.m_OraErrorCodes, l_sqlcodeChar)) || (false == l_ociPingStatus))
         {
            CLOG(0,1,"Doing a reconnect ...");
            releaseConnObject(l_ConnectionObject);
            l_ConnectionObject = reconnect(l_dbConnectionIndex, l_retIndex);
            l_dstFlag = getCurrentDstFlag();
            LLOG(0,0,"DST value:%d during reconnection", l_dstFlag);
         }

         if(NULL != l_dqm->m_cb)
         {
            DLOG(0,1,"Pushing the DB Response into the queue");
            g_act.m_queues.m_res->push(l_dqm);
            DLOG(0,1,"Pushed the DB Response into the queue");
         }
      }
      else
      {
         WLOG(0,1,"l_dqm is NULL");  //changing ELOG to WLOG due to QUEUE_TYPE_BLOCKING_TIMED_WAIT
      }
   }

   ELOG(0,1,"ERROR!!! Thread func exit");
}

char *getHeader(char *p_text, int p_racIndex)
{
   char *l_text = new char[1000+1];
   snprintf(l_text, 1000, "%s", p_text);
   return l_text;
}


bool initializeDbActiveObjectStatistics(StatisticsGenerator *p_sg)
{
   //Initialize Statistics
   for(int l_ind=0; l_ind<g_ConfigData->i_DbConfigData.m_NoOfNodes; l_ind++)
   {
      char l_node[10+1];
      snprintf(l_node, sizeof(l_node), "RAC %02d", 1+l_ind);

      g_act.m_dts[l_ind].m_diffTime_gr_or_equal_20s                       = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, getHeader("diffTime >=20s                   ", l_ind), l_node, 'D');
      g_act.m_dts[l_ind].m_diffTime_gr_or_equal_10s_and_lt_20s            = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, getHeader("diffTime >=10s     and < 20s     ", l_ind), l_node, 'D');
      g_act.m_dts[l_ind].m_diffTime_gr_or_equal_7s_and_lt_10s             = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, getHeader("diffTime >=7s      and < 10s     ", l_ind), l_node, 'D');
      g_act.m_dts[l_ind].m_diffTime_gr_or_equal_5s_and_lt_7s              = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, getHeader("diffTime >=5s      and < 7s      ", l_ind), l_node, 'D');
      g_act.m_dts[l_ind].m_diffTime_gr_or_equal_2s_and_lt_5s              = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, getHeader("diffTime >=2s      and < 5s      ", l_ind), l_node, 'D');
      g_act.m_dts[l_ind].m_diffTime_gr_or_equal_1s_and_lt_2s              = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, getHeader("diffTime >=1s      and < 2s      ", l_ind), l_node, 'D');
      g_act.m_dts[l_ind].m_diffTime_gr_or_equal_0d7s_and_lt_1s            = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, getHeader("diffTime >=0.7s    and < 1s      ", l_ind), l_node, 'D');
      g_act.m_dts[l_ind].m_diffTime_gr_or_equal_0d5s_and_lt_0d7s          = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, getHeader("diffTime >=0.5s    and < 0.7s    ", l_ind), l_node, 'D');
      g_act.m_dts[l_ind].m_diffTime_gr_or_equal_0d2s_and_lt_0d5s          = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, getHeader("diffTime >=0.2s    and < 0.5s    ", l_ind), l_node, 'D');
      g_act.m_dts[l_ind].m_diffTime_gr_or_equal_0d1s_and_lt_0d2s          = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, getHeader("diffTime >=0.1s    and < 0.2s    ", l_ind), l_node, 'D');
      g_act.m_dts[l_ind].m_diffTime_gr_or_equal_0d07s_and_lt_0d1s         = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, getHeader("diffTime >=0.07s   and < 0.1s    ", l_ind), l_node, 'D');
      g_act.m_dts[l_ind].m_diffTime_gr_or_equal_0d05s_and_lt_0d07s        = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, getHeader("diffTime >=0.05s   and < 0.07s   ", l_ind), l_node, 'D');
      g_act.m_dts[l_ind].m_diffTime_gr_or_equal_0d02s_and_lt_0d05s        = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, getHeader("diffTime >=0.02s   and < 0.05s   ", l_ind), l_node, 'D');
      g_act.m_dts[l_ind].m_diffTime_gr_or_equal_0d01s_and_lt_0d02s        = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, getHeader("diffTime >=0.01s   and < 0.02s   ", l_ind), l_node, 'D');
      g_act.m_dts[l_ind].m_diffTime_gr_or_equal_0d007s_and_lt_0d01s       = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, getHeader("diffTime >=0.007s  and < 0.01s   ", l_ind), l_node, 'D');
      g_act.m_dts[l_ind].m_diffTime_gr_or_equal_0d005s_and_lt_0d007s      = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, getHeader("diffTime >=0.005s  and < 0.007s  ", l_ind), l_node, 'D');
      g_act.m_dts[l_ind].m_diffTime_gr_or_equal_0d002s_and_lt_0d005s      = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, getHeader("diffTime >=0.002s  and < 0.005s  ", l_ind), l_node, 'D');
      g_act.m_dts[l_ind].m_diffTime_gr_or_equal_0d001s_and_lt_0d002s      = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, getHeader("diffTime >=0.001s  and < 0.002s  ", l_ind), l_node, 'D');
      g_act.m_dts[l_ind].m_diffTime_gr_or_equal_0d0007s_and_lt_0d001s     = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, getHeader("diffTime >=0.0007s  and < 0.001s ", l_ind), l_node, 'D');
      g_act.m_dts[l_ind].m_diffTime_gr_or_equal_0d0005s_and_lt_0d0007s    = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, getHeader("diffTime >=0.0005s  and < 0.0007s", l_ind), l_node, 'D');
      g_act.m_dts[l_ind].m_diffTime_gr_or_equal_0d0002s_and_lt_0d0005s    = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, getHeader("diffTime >=0.0002s  and < 0.0005s", l_ind), l_node, 'D');
      g_act.m_dts[l_ind].m_diffTime_gr_or_equal_0d0001s_and_lt_0d0002s    = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, getHeader("diffTime >=0.0001s  and < 0.0002s", l_ind), l_node, 'D');
      g_act.m_dts[l_ind].m_diffTime_lt_0d00001s                           = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, getHeader("diffTime <0.0001s                ", l_ind), l_node, 'D');
   }

   return true;
}

bool updateTPSForDB()
{
   bool l_allow = true;

   int l_currentTime = time(NULL);
   if(l_currentTime > g_act.m_queues.m_req->m_lastSecond)
   {
      DLOG(0,0,"Time changed");
      g_act.m_queues.m_req->m_lastSecond = l_currentTime;
      HLRStatisticsInitializer::instance()->logStatistics(g_maxInitialDbTpsIndex,g_act.m_queues.m_req->m_currentTrans);
      g_act.m_queues.m_req->m_currentTrans = 1;
   }
   else
   {
      pthread_mutex_lock(&(g_act.m_queues.m_req->m_q_mutex));
      if(DB_QUERY_TPS_COUNTABLE == ((DbQueryMsg*)(g_act.m_queues.m_req->m_q[0]))->m_DbQueryTpsCountable)
      {
         g_act.m_queues.m_req->m_currentTrans++;
         DLOG(0,0,"QueryQueueType is DB_QUERY_TPS_COUNTABLE, incrementing m_currentTrans[%d]",g_act.m_queues.m_req->m_currentTrans);
      }
      else
      {
         DLOG(0,0,"DB_QUERY_TPS_NON_COUNTABLE not applying tps");
      }
      pthread_mutex_unlock(&(g_act.m_queues.m_req->m_q_mutex));
   }

   TrafficParams l_traf_in,l_traf_out;
   l_traf_in.m_maxTPS = g_OtherConfigData->m_DbThresholdTps;
   string l_service;
   l_service = "DBI";
   if(false == g_daf->getTrafficParameters(l_service, l_traf_in, l_traf_out))
   {
      DLOG(0,0,"getTrafficParameters returns false, taking configured tps");
      l_traf_out.m_maxTPS = g_OtherConfigData->m_DbThresholdTps;
   }
   else
   {
      DLOG(0,0,"getTrafficParameters returns true for DB, DAF TPS is %d",l_traf_out.m_maxTPS);
   }
   g_act.m_queues.m_req->m_tps = l_traf_out.m_maxTPS;

   if(g_act.m_queues.m_req->m_currentTrans > g_act.m_queues.m_req->m_tps)
   {
      CLOG(0,0,"CurrentTPS[%d], Exceeded Configured INITIAL_QUERY_DB_TPS[%d], Sending TRAP", g_act.m_queues.m_req->m_currentTrans,g_act.m_queues.m_req->m_tps);
      g_si.sendSnmpTrap(g_InitialDBTpsReachedTrap, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL);
      l_allow=false;
   }
   return l_allow; 
}

bool updateTPSForLaterQuery()
{
   bool l_allow = true;
   DLOG(0,0,"In updateTPSForLaterQuery func");   //for Debug later needs to remove

   int l_currentTime = time(NULL);
   if(l_currentTime > g_act.m_queues.m_LaterQueryReq->m_lastSecond)
   {
      DLOG(0,0,"Time changed in updateTPSForLaterQuery");
      g_act.m_queues.m_LaterQueryReq->m_lastSecond = l_currentTime;
      HLRStatisticsInitializer::instance()->logStatistics(g_maxLaterDbTpsIndex,g_act.m_queues.m_LaterQueryReq->m_currentTrans);
      g_act.m_queues.m_LaterQueryReq->m_currentTrans = 1;
   }
   else
   {
      pthread_mutex_lock(&(g_act.m_queues.m_LaterQueryReq->m_q_mutex));
      if(DB_QUERY_QUEUE_TYPE_LATER == ((DbQueryMsg*)(g_act.m_queues.m_LaterQueryReq->m_q[0]))->m_DbQueryQueueType)
      {
         g_act.m_queues.m_LaterQueryReq->m_currentTrans++;
         DLOG(0,0,"QueryQueueType is DB_QUERY_QUEUE_TYPE_LATER, incrementing m_currentTrans [%d]",g_act.m_queues.m_LaterQueryReq->m_currentTrans);
      }
      else
      {
         DLOG(0,0,"QueryQueueType is DB_QUERY_QUEUE_TYPE_INITIAL, not incrementing m_currentTrans");  //for Debug late needs to remove
      }
      pthread_mutex_unlock(&(g_act.m_queues.m_LaterQueryReq->m_q_mutex));
   }

   TrafficParams l_traf_in,l_traf_out;
   l_traf_in.m_maxTPS = g_OtherConfigData->m_LaterQueryDbTps;
   string l_service;
   l_service = "DBL";
   if(false == g_daf->getTrafficParameters(l_service, l_traf_in, l_traf_out))
   {
      DLOG(0,0,"getTrafficParameters returns false, taking configured tps for laterQuery");
      l_traf_out.m_maxTPS = g_OtherConfigData->m_LaterQueryDbTps;
   }
   else
   {
      DLOG(0,0,"getTrafficParameters returns true for laterQuery DB, DAF TPS is %d",l_traf_out.m_maxTPS);
   }
   g_act.m_queues.m_LaterQueryReq->m_tps = l_traf_out.m_maxTPS;

   if(g_act.m_queues.m_LaterQueryReq->m_currentTrans > g_act.m_queues.m_LaterQueryReq->m_tps)
   {
      CLOG(0,0,"CurrentLaterQueryTPS[%d], Exceeded Configured LATER_QUERY_DB_TPS[%d]", g_act.m_queues.m_LaterQueryReq->m_currentTrans,g_act.m_queues.m_LaterQueryReq->m_tps);
      g_si.sendSnmpTrap(g_LaterDBTpsReachedTrap, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL);
      l_allow=false;
   }

   DLOG(0,0,"In UpdateTPSforLaterQuery returning l_allow as %d",l_allow);     // for Debug later needs to remove
   return l_allow; 
}

bool DbActiveObject::initialize(int p_numOfThreads, bool p_expMonitoringFlag)
{
   m_explicitMonitoringFlag = p_expMonitoringFlag;

   enableThreads();

   if (0 != pthread_mutex_init(&g_connLock, NULL))
   {
      ELOG(0,1,"Unable to conn lock");
      return false;
   }

   if (0 != pthread_mutex_init(&m_activeMutex, NULL))
   {
      ELOG(0,1,"Unable to active lock");
      return false;
   }

   if (0 != pthread_mutex_init(&g_dbMapMutex, NULL))
   {
      ELOG(0,1,"Unable to db map lock");
      return false;
   }

   if((0 == g_OtherConfigData->m_DbHeartBeatRequiredFlag) && (0 == g_OtherConfigData->m_THBEnabled))
   {
      m_queues.m_req = new MessageQueue(QUEUE_TYPE_BLOCKING, QUEUE_PERSISTENCE_TYPE_NON_PERSISTENT);
   }
   else
   {
      m_queues.m_req = new MessageQueue(QUEUE_TYPE_BLOCKING_TIMED_WAIT, QUEUE_PERSISTENCE_TYPE_NON_PERSISTENT);
      m_queues.m_req->m_heartBeatInterval = (1 == g_OtherConfigData->m_DbHeartBeatRequiredFlag)?(g_OtherConfigData->m_DbHeartBeatInterval):60;
      DLOG(0,1," g_OtherConfigData->m_DbHeartBeatRequiredFlag is %d g_OtherConfigData->m_DbHeartBeatInterval %d m_heartBeatInterval is %d",g_OtherConfigData->m_DbHeartBeatRequiredFlag ,g_OtherConfigData->m_DbHeartBeatInterval ,m_queues.m_req->m_heartBeatInterval);
   }
   if(g_OtherConfigData->m_DbThresholdTps > 0)
   {
      LLOG(0,0,"Max DB TPS is configured. Initializing DB Active Object with TPS %d", g_OtherConfigData->m_DbThresholdTps);
      m_queues.m_req->m_qcm = QUEUE_CONSUMING_MODEL_BASED_ON_TPS;
      m_queues.m_req->m_tps = g_OtherConfigData->m_DbThresholdTps;
      m_queues.m_req->m_callback = &updateTPSForDB; 
   }
   bool l_status = m_queues.m_req->initialize();
   if (!l_status)
   {
      ELOG(0,1,"ERROR!! Unable to initialize the Request Queue");
      return false;
   }

   m_queues.m_res = new MessageQueue(QUEUE_TYPE_NON_BLOCKING, QUEUE_PERSISTENCE_TYPE_NON_PERSISTENT);
   l_status = m_queues.m_res->initialize();
   if (!l_status)
   {
      ELOG(0,1,"ERROR!! Unable to initialize the Response Queue");
      return false;
   }

   m_numOfThreads=p_numOfThreads;

   for (int l_i=0; l_i<p_numOfThreads; l_i++)
   {
      pthread_t l_thread;

      int *p = new int;
      *p = l_i%g_ConfigData->i_DbConfigData.m_NoOfNodes;
      if (0!=pthread_create(&l_thread, NULL, dbActiveThreadFunc, p))
      {
         CLOG(0,1,"Unable to create a thread");
         return false;
      }
      LLOG(0,1,"Created DB thread [%d] ", l_thread);
   }

   memset(&m_queryCount, '\0', sizeof(m_queryCount));

   if(g_OtherConfigData->m_LaterQueryDbTps > 0)
   {
      if(g_OtherConfigData->m_LaterQueryPoolSizeRequired > 0)
      {
         LLOG(0,0,"Later Query TPS is configured, Initializing DB Active Object with TPS %d", g_OtherConfigData->m_LaterQueryDbTps);
         if((0 == g_OtherConfigData->m_THBEnabled) && (0 == g_OtherConfigData->m_DbHeartBeatRequiredFlag))
         {   
            m_queues.m_LaterQueryReq = new MessageQueue(QUEUE_TYPE_BLOCKING, QUEUE_PERSISTENCE_TYPE_NON_PERSISTENT);    //LaterQueryQueue
         }
         else
         {
            m_queues.m_LaterQueryReq = new MessageQueue(QUEUE_TYPE_BLOCKING_TIMED_WAIT, QUEUE_PERSISTENCE_TYPE_NON_PERSISTENT);    //LaterQueryQueue
            m_queues.m_LaterQueryReq->m_heartBeatInterval = (1 == g_OtherConfigData->m_DbHeartBeatRequiredFlag)?(g_OtherConfigData->m_DbHeartBeatInterval):60;
            DLOG(0,1," g_OtherConfigData->m_DbHeartBeatRequiredFlag is %d g_OtherConfigData->m_DbHeartBeatInterval %d m_heartBeatInterval is %d",g_OtherConfigData->m_DbHeartBeatRequiredFlag ,g_OtherConfigData->m_DbHeartBeatInterval ,m_queues.m_LaterQueryReq->m_heartBeatInterval);
         }
         m_queues.m_LaterQueryReq->m_qcm = QUEUE_CONSUMING_MODEL_BASED_ON_TPS;
         m_queues.m_LaterQueryReq->m_tps = g_OtherConfigData->m_LaterQueryDbTps;
         m_queues.m_LaterQueryReq->m_callback = &updateTPSForLaterQuery; 

         bool l_status1 = m_queues.m_LaterQueryReq->initialize();
         if (!l_status1)
         {
            ELOG(0,1,"ERROR!! Unable to initialize the Later Query Request Queue");
            return false;
         }

         for (int l_i=0; l_i<g_OtherConfigData->m_LaterQueryPoolSizeRequired; l_i++)
         {
            pthread_t l_thread;

            int *p = new int;
            *p = l_i%g_ConfigData->i_DbConfigData.m_NoOfNodes;
            if (0!=pthread_create(&l_thread, NULL, LaterQueryThreadFunc, p))
            {
               CLOG(0,1,"Unable to create a Later Query DB Thread");
               return false;
            }
            LLOG(0,1,"Created Later query DB thread [%d] ", l_thread);
         }
         m_laterQueryInitFlag = true;
         m_numOfThreads = m_numOfThreads + g_OtherConfigData->m_LaterQueryPoolSizeRequired;
      }
      else
      {
         LLOG(0,0,"LaterQuery DBpool size not configured");
      }
   }

   m_initializationFlag=true;
   return true;
}

bool DbActiveObject::execute(void *p_request)
{
   ContextBase *l_cb = ((DbQueryMsg*)p_request)->m_cb;
   if (NULL == l_cb)
   {
      ELOG(0,1,"Severe Error in DB Execution. m_cb is NULL");
      return false;
   }

   sprintf( ((DbQueryMsg*)p_request)->m_LoggingMsg, "%3s%3s:%08d", l_cb->m_ModName, l_cb->m_MessageName, l_cb->m_GlobalContextId);

   if (m_initializationFlag)
   {
      ((DbQueryMsg*)p_request)->m_cb->m_ReferenceCount++;
      DLOG(0,1,"DbQueryMsg reference count incremented: %d", ((DbQueryMsg*)p_request)->m_cb->m_ReferenceCount);
      if( DB_QUERY_CACHED_TYPE_NOT_CACHED != ((DbQueryMsg*)p_request)->m_DbQueryCachedType )
      {
         LLOG(0,0,"Calling MemCached execute as Query Type is MEMCACHE");
         return g_MemcActObj.execute(p_request);
      }
      else
      {
         if(DB_QUERY_QUEUE_TYPE_INITIAL == ((DbQueryMsg*)p_request)->m_DbQueryQueueType )
         {
            DLOG(0,0,"Pushing into ReqQueue");
            m_queues.m_req->push(p_request);
         }
         else
         {
            DLOG(0,0,"Pushing into LaterQueue");
            m_queues.m_LaterQueryReq->push(p_request);
         }
      }
      return true;
   }
   else
   {
      ELOG(0,1,"DbActiveObject not initialized");
      return false;
   }
   ELOG(0,1,"DbActiveObject::execute failed\n");
   return false;
}


void DbActiveObject::getStats(char *p_output)
{
   if (true == m_initializationFlag)
   {
      int l_req = m_queues.m_req->size();
      int l_req1=0;
      if(true == m_laterQueryInitFlag)
       l_req1 = m_queues.m_LaterQueryReq->size();
      int l_res = m_queues.m_res->size();

      if(g_ConfigData->i_DbConfigData.m_NoOfNodes <= 4)
      {
         sprintf(p_output, " DB Request Queue Size\t\t\t\t: %d\n DB Later Request Queue Size\t\t\t: %d\n DB Response Queue Size\t\t\t\t: %d\n DB Threads\t\t\t\t\t: Total:%d  DB01:%d(%d)  DB02:%d(%d)  DB03:%d(%d)  DB04:%d(%d)",
               l_req, l_req1, l_res, m_numOfThreads, m_activeThreads[0], m_queryCount[0], m_activeThreads[1], m_queryCount[1], 
               m_activeThreads[2], m_queryCount[2], m_activeThreads[3], m_queryCount[3]);
      }
      else
      {
         sprintf(p_output, " DB Request Queue Size\t\t\t\t: %d\n DB Later Request Queue Size\t\t\t: %d\n DB Response Queue Size\t\t\t\t: %d\n", l_req, l_req1, l_res);
         for(int l_i=0; l_i<g_ConfigData->i_DbConfigData.m_NoOfNodes; l_i++)
         {
            LLOG(0,1,"DB%02d: activeThreads:%d queryCount:%d", 1+l_i, m_activeThreads[l_i], m_queryCount[l_i]);
         }
      }
   }
   else
   {
      sprintf(p_output, " DB Interface\t\t\t\t: %s", "NOT ENABLED");
   }
}


int DbActiveObject::getRequestQueueSize()
{
   if (true == m_initializationFlag)
   {
      return m_queues.m_req->size();
   }
   else
   {
      return 99999;
   }
}

int DbActiveObject::getLaterRequestQueueSize()
{
   if (true == m_laterQueryInitFlag)
   {
      return m_queues.m_LaterQueryReq->size();
   }
   else
   {
      return 0;
   }
}
