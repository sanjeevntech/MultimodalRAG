#include <NgLogOverride.h>
#include <Logger.h>

NgLogOverride *g_nlo;

bool NgLogOverride::override(char p_logLevel, char *p_data)
{
   if('\n' == p_data[ strlen(p_data) -1])
   {
      p_data[strlen(p_data) -1] = '\0';
   }
   if(strstr(p_data, "Unable connect to SNMP Agent"))
   {
      return true;
   }
   switch(p_logLevel)
   {
      case 'D':
         DLOG(0,1,p_data);
         break;
      case 'E':
         ELOG(0,1,p_data);
         break;
      case 'L':
         LLOG(0,1,p_data);
         break;
      case 'T':
         TLOG(0,1,p_data);
         break;
      case 'W':
         WLOG(0,1,p_data);
         break;
      case 'C':
         CLOG(0,1,p_data);
         break;
      default:
         printf("\nunable to log: %s", p_data);
         break;
   }
   return true;
}
