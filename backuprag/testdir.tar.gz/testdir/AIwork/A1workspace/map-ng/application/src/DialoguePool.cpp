#include <DialoguePool.h>
#include <Logger.h>
#include <SnmpInterface.h>
#include <ConfigReader.h>

DialoguePool::DialoguePool()
{
}

DialoguePool::~DialoguePool()
{
}

bool DialoguePool::initialize(int p_startDialogue, int p_maxSessionIDs)
{
   DLOG(0,1,"Initializing DialoguePool");
   if (p_startDialogue < 0)
   {
      ELOG(0,1,"Start Dialogue is less than ZERO");
      return false;
   }

   if (p_maxSessionIDs < 0)
   {
      ELOG(0,1,"Max Dialogues is less than ZERO");
      return false;
   }
   m_maxSessionIDs=p_maxSessionIDs;

   pthread_mutex_init(&m_q_mutex,NULL);
   lock();

   while( m_q.size() != 0)
      m_q.pop();

   for (int l_i=p_startDialogue; l_i<=p_maxSessionIDs; l_i++)
   {
      m_q.push(l_i);
   }
   unlock();

   DLOG(0,1,"Size of the Dialogue Pool: %d", m_q.size());
   return true;
}

int DialoguePool::getNewDialogueId()
{
   int l_sessionID = 0;
   lock();
   if (m_q.size() != 0)
   {
      l_sessionID = m_q.front();
      m_q.pop();
   }
   else
   {
      l_sessionID = 0;
      CLOG(0,0,"Queue Size is ZERO");
   }

   TLOG(0,1,"Leaving with dialogue ID: %d. Queue Size: %d", l_sessionID, m_q.size());
   if( m_q.size()  <= (g_ConfigData->i_NgConfigData.m_MaxDialogs*2)/10 )
   {
	   CLOG(0,0,"Sending Trap to alert Dialogue pool threshold of 80% reached.. Qsize[%d]",m_q.size());
	   g_si.sendSnmpTrap(g_DialoguePoolTRAP, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL);   
   } 
  
   unlock();

   return l_sessionID;
}

bool DialoguePool::releaseDialogueId(int p_sessionID)
{
   DLOG(0,1,"Releasing DialogudID: %d", p_sessionID);

   if (p_sessionID < 0)
   {
      ELOG(0,1,"Invalid Session ID: %d", p_sessionID);
      return false;
   }
   lock();
   m_q.push(p_sessionID);
   unlock();

   return true;
}

void DialoguePool::lock()
{

}

void DialoguePool::unlock()
{

}

void DialoguePool::getStats(char *p_output)
{
   sprintf(p_output, " Dialogue Pool Size\t\t\t\t: %ld (Max %d)",m_q.size(), m_maxSessionIDs);
}

int DialoguePool::getSize()
{
   return m_q.size();
}

