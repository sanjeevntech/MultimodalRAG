/************************************************************************************
 * FILE NAME      : SmppInterface.cpp
 * REMARKS        :
 *************************************************************************************/

#include <SmppInterface.h>
#include <Logger.h>
#include <ConfigReader.h>
#include <Types.h>
#include <SnmpInterface.h>

BOOLEAN                     g_SmppConnection = false;
SmppInterface* SmppInterface::gSMPPClientObj = NULL; 

unsigned int            seqNo=0;
unsigned int            getSequenceNo();
pthread_mutex_t seqNoMutex;

INT32 ESMEClient::m_ClientSocket = 0;


char *getStatusChar(SMPP_ERROR_MESSAGES p_msg)
{
   switch (p_msg)
   {
      case SMPP_ESME_ROK:
         return "SMPP_ESME_ROK";
      case SMPP_ESME_RINVMSGLEN:
         return "SMPP_ESME_RINVMSGLEN";
      case SMPP_ESME_RINVCMDLEN:
         return "SMPP_ESME_RINVCMDLEN";
      case SMPP_ESME_RINVCMDID:
         return "SMPP_ESME_RINVCMDID";
      case SMPP_ESME_RINVBNDSTS:
         return "SMPP_ESME_RINVBNDSTS";
      case SMPP_ESME_RALYNBD:
         return "SMPP_ESME_RALYNBD";
      case SMPP_ESME_RINVPRTFLG:
         return "SMPP_ESME_RINVPRTFLG";
      case SMPP_ESME_RINVREGDLVFLG:
         return "SMPP_ESME_RINVREGDLVFLG";
      case SMPP_ESME_RSYSERR:
         return "SMPP_ESME_RSYSERR";
      case SMPP_ESME_RINVSRCADR:
         return "SMPP_ESME_RINVSRCADR";
      case SMPP_ESME_RINVDSTADR:
         return "SMPP_ESME_RINVDSTADR";
      case SMPP_ESME_RINVMSGID:
         return "SMPP_ESME_RINVMSGID";
      case SMPP_ESME_RBINDFAIL:
         return "SMPP_ESME_RBINDFAIL";
      case SMPP_ESME_RINVPASWD:
         return "SMPP_ESME_RINVPASWD";
      case SMPP_ESME_RINVSYSID:
         return "SMPP_ESME_RINVSYSID";
      case SMPP_ESME_RCANCELFAIL:
         return "SMPP_ESME_RCANCELFAIL";
      case SMPP_ESME_RREPLACEFAIL:
         return "SMPP_ESME_RREPLACEFAIL";
      case SMPP_ESME_RMSGQFUL:
         return "SMPP_ESME_RMSGQFUL";
      case SMPP_ESME_RINVSERTYP:
         return "SMPP_ESME_RINVSERTYP";
      case SMPP_ESME_RINVNUMDESTS:
         return "SMPP_ESME_RINVNUMDESTS";
      case SMPP_ESME_RINVDLNAME:
         return "SMPP_ESME_RINVDLNAME";
      case SMPP_ESME_RINVDESTFLAG:
         return "SMPP_ESME_RINVDESTFLAG";
      case SMPP_ESME_RINVSUBREP:
         return "SMPP_ESME_RINVSUBREP";
      case SMPP_ESME_RINVESMCLASS:
         return "SMPP_ESME_RINVESMCLASS";
      case SMPP_ESME_RCNTSUBDL:
         return "SMPP_ESME_RCNTSUBDL";
      case SMPP_ESME_RSUBMITFAIL:
         return "SMPP_ESME_RSUBMITFAIL";
      case SMPP_ESME_RINVSRCTON:
         return "SMPP_ESME_RINVSRCTON";
      case SMPP_ESME_RINVSRCNPI:
         return "SMPP_ESME_RINVSRCNPI";
      case SMPP_ESME_RINVDSTTON:
         return "SMPP_ESME_RINVDSTTON";
      case SMPP_ESME_RINVDSTNPI:
         return "SMPP_ESME_RINVDSTNPI";
      case SMPP_ESME_RINVSYSTYP:
         return "SMPP_ESME_RINVSYSTYP";
      case SMPP_ESME_RINVREPFLAG:
         return "SMPP_ESME_RINVREPFLAG";
      case SMPP_ESME_RINVNUMMSGS:
         return "SMPP_ESME_RINVNUMMSGS";
      case SMPP_ESME_RTHROTTLED:
         return "SMPP_ESME_RTHROTTLED";
      case SMPP_ESME_RINVSCHED:
         return "SMPP_ESME_RINVSCHED";
      case SMPP_ESME_RINVEXPIRY:
         return "SMPP_ESME_RINVEXPIRY";
      case SMPP_ESME_RINVDFTMSGID:
         return "SMPP_ESME_RINVDFTMSGID";
      case SMPP_ESME_RX_T_APPN:
         return "SMPP_ESME_RX_T_APPN";
      case SMPP_ESME_RX_P_APPN:
         return "SMPP_ESME_RX_P_APPN";
      case SMPP_ESME_RX_R_APPN:
         return "SMPP_ESME_RX_R_APPN";
      case SMPP_ESME_RQUERYFAIL:
         return "SMPP_ESME_RQUERYFAIL";
      case SMPP_ESME_RINVTLVSTREAM:
         return "SMPP_ESME_RINVTLVSTREAM";
      case SMPP_ESME_ROPTPARNOTALLWD:
         return "SMPP_ESME_ROPTPARNOTALLWD";
      case SMPP_ESME_RINVTLVLEN:
         return "SMPP_ESME_RINVTLVLEN";
      case SMPP_ESME_RMISSINGTLV:
         return "SMPP_ESME_RMISSINGTLV";
      case SMPP_ESME_RINVTLVVAL:
         return "SMPP_ESME_RINVTLVVAL";
      case SMPP_ESME_RDELIVERYFAILURE:
         return "SMPP_ESME_RDELIVERYFAILURE";
      case SMPP_ESME_RUNKNOWNERROR:
         return "SMPP_ESME_RUNKNOWNERROR";
      case SMPP_ESME_RSERTYPUNAUTH:
         return "SMPP_ESME_RSERTYPUNAUTH";
      case SMPP_ESME_RPROHIBITED:
         return "SMPP_ESME_RPROHIBITED";
      case SMPP_ESME_RSERTYPUNAVAIL:
         return "SMPP_ESME_RSERTYPUNAVAIL";
      case SMPP_ESME_RSERTYPDENIED:
         return "SMPP_ESME_RSERTYPDENIED";
      case SMPP_ESME_RINVDCS:
         return "SMPP_ESME_RINVDCS";
      case SMPP_ESME_RINVSRCADDRSUBUNIT:
         return "SMPP_ESME_RINVSRCADDRSUBUNIT";
      case SMPP_ESME_RINVDSTADDRSUBUNIT:
         return "SMPP_ESME_RINVDSTADDRSUBUNIT";
      case SMPP_ESME_RINVBCASTFREQINT:
         return "SMPP_ESME_RINVBCASTFREQINT";
      case SMPP_ESME_RINVBCASTALIAS_NAME:
         return "SMPP_ESME_RINVBCASTALIAS_NAME";
      case SMPP_ESME_RINVBCASTAREAFMT:
         return "SMPP_ESME_RINVBCASTAREAFMT";
      case SMPP_ESME_RINVNUMBCAST_AREAS:
         return "SMPP_ESME_RINVNUMBCAST_AREAS";
      case SMPP_ESME_RINVBCASTCNTTYPE:
         return "SMPP_ESME_RINVBCASTCNTTYPE";
      case SMPP_ESME_RINVBCASTMSGCLASS:
         return "SMPP_ESME_RINVBCASTMSGCLASS";
      case SMPP_ESME_RBCASTFAIL:
         return "SMPP_ESME_RBCASTFAIL";
      case SMPP_ESME_RBCASTQUERYFAIL:
         return "SMPP_ESME_RBCASTQUERYFAIL";
      case SMPP_ESME_RBCASTCANCELFAIL:
         return "SMPP_ESME_RBCASTCANCELFAIL";
      case SMPP_ESME_RINVBCAST_REP:
         return "SMPP_ESME_RINVBCAST_REP";
      case SMPP_ESME_RINVBCASTSRVGRP:
         return "SMPP_ESME_RINVBCASTSRVGRP";
      case SMPP_ESME_RINVBCASTCHANIND:
         return "SMPP_ESME_RINVBCASTCHANIND";
      default:
         return "UNKNOWN";
   }
}



/*******************************************************************************************
 * FUNCTION NAME : getSequenceNo 
 * DEFINITION    : Function to generate new Sequence number
 * ARGUMENTS     : NONE
 * RETURNS       : 
 * REMARKS       :
 * ************************************************************************************/
unsigned int getSequenceNo()
{
   unsigned int tmp=0;
   INT32 retVal;

   if(0 != (retVal = pthread_mutex_lock(&seqNoMutex)))
   {
      WLOG(0,0,"%s <Ln:%d>\npthread_mutex_lock failed\n[ErrCode:%d]",  
            __FUNCTION__, __LINE__, retVal);
      return 0;
   }

   tmp = ++seqNo;
   if(0 != (retVal = pthread_mutex_unlock(&seqNoMutex)))
   {
      WLOG(0,0,"%s <Ln:%d>\npthread_mutex_unlock failed\n[ErrCode:%d]",  
            __FUNCTION__, __LINE__, retVal);
      return 0;
   }
   return tmp;

}   

/*****************************************************************************
 * FUNCTION NAME : ESMEClient 
 * DEFINITION    : Constructor
 * ARGUMENTS     : NONE
 * RETURNS       : NONE
 * REMARKS       :
 * ****************************************************************************/
ESMEClient::ESMEClient()
{
}

SmppInterface::SmppInterface()
{
   m_IsInitialized = false;
}

/*****************************************************************************
 * FUNCTION NAME : ESMEClient
 * DEFINITION    : Destructor
 * ARGUMENTS     : NONE
 * RETURNS       : NONE
 * REMARKS       :
 * ****************************************************************************/
ESMEClient::~ESMEClient()
{
}

SmppInterface* SmppInterface::getInstance()
{
   if(gSMPPClientObj == NULL)
   {
      gSMPPClientObj = new SmppInterface();
   }

   return gSMPPClientObj;
}

/*****************************************************************************
 * FUNCTION NAME : ESMEClient
 * DEFINITION    : Function to Close Connection
 * ARGUMENTS     : NONE
 * RETURNS       : NONE
 * REMARKS       :
 * ****************************************************************************/
BOOLEAN SmppInterface::CloseConnection()
{
   DLOG(0,0,"%s <Ln:%d> Closing Client Connection", __FUNCTION__, __LINE__);
   close(ESMEClient::m_ClientSocket);
   return true;
}

/*****************************************************************************
 * FUNCTION NAME : EncodeCString
 * DEFINITION    :
 * ARGUMENTS     : TEXT *
 * RETURNS       : BOOLEAN
 * REMARKS       :
 * ****************************************************************************/
BOOLEAN ESMEClient::EncodeCString(TEXT *lString)
{
   while (m_EsmePdu.data[m_EsmePdu.pos++] = *lString++);
   m_EsmePdu.len = m_EsmePdu.pos;

   return true;
}

BOOLEAN ESMEClient::EncodeTLVString(UINT32 lTag, INT32 lLen, TEXT* lValue)
{
   this->EncodeInteger(lTag, MAX_OPTIONAL_TAG_LEN);
   this->EncodeInteger(lLen, MAX_OPTIONAL_TAG_LENGTH_LEN);
   this->EncodeString(lValue);

   return true;
}

int GSM7bitEncoding(unsigned char *lString, char* rString)
{
   char tmpString[SMPP_MSG_PAYLOAD_LEN_MAX+1];
   memset(tmpString, '\0', sizeof(tmpString));
   int i, k=0, len = strlen((char*)lString);
   DLOG(0,0,"%s <Ln:%d> Length of ascii string : %d ", __FUNCTION__, __LINE__,len);
   for(i=0; i<len; i++)
   {
      if( lString[i] < 32 || lString[i] > 35 && lString[i] < 37 || 64 == lString[i] || lString[i] > 90 && lString[i] < 97 || lString[i] > 122)
      {
         int tmp = ConvertAscii2Gsm(lString[i]);
         if(tmp > 0xFF)
         {
            tmpString[k+1]=tmp & 0xFF;
            tmp = tmp>>8;
            tmpString[k] = tmp & 0xFF;
            k+=2;
         }
         else
         {
            tmpString[k++]= (unsigned char)tmp;
         }
      }
      else
      {
         tmpString[k++]= lString[i];
      }
   }
   tmpString[k]='\0';
   DLOG(0,0,"%s <Ln:%d> Length of GSM encoding string : %d ", __FUNCTION__, __LINE__,k);

   for(int j=0; j<k; j++)
   {
      rString[j] = tmpString[j];
   }
   rString[k]='\0';
   return k;
}

int UnicodeEncoding(char *lString, char* rString)
{
   int i=0, len = strlen((char*)lString);
   for(i=0; i<len; i++)
   {
      switch(lString[i])
      {
         case 0xa4: //EURO SIGN
            rString[2*i] = 0x20;
            rString[2*i+1] = 0xac;
            break;
         case 0xa6: //LATIN CAPITAL LETTER S WITH CARON
            rString[2*i] = 0x01;
            rString[2*i+1] = 0x60;
            break;
         case 0xa8: //LATIN SMALL LETTER S WITH CARON
            rString[2*i] = 0x01;
            rString[2*i+1] = 0x61;
            break;
         case 0xb4: //LATIN CAPITAL LETTER Z WITH CARON
            rString[2*i] = 0x01;
            rString[2*i+1] = 0x7d;
            break;
         case 0xb8: //LATIN SMALL LETTER Z WITH CARON
            rString[2*i] = 0x01;
            rString[2*i+1] = 0x7e;
            break;
         case 0xbc: //LATIN CAPITAL LIGATURE OE
            rString[2*i] = 0x01;
            rString[2*i+1] = 0x52;
            break;
         case 0xbd: //LATIN SMALL LIGATURE OE
            rString[2*i] = 0x01;
            rString[2*i+1] = 0x53;
            break;
         case 0xbe: //LATIN CAPITAL LETTER Y WITH DIAERESIS
            rString[2*i] = 0x01;
            rString[2*i+1] = 0x78;
            break;
         default:
            rString[2*i] = 0x00;
            rString[2*i+1] = lString[i];
      }
   }
   rString[2*i]='\0';
   return 2*i;
}
/*****************************************************************************
 * FUNCTION NAME : EncodeString
 * DEFINITION    :
 * ARGUMENTS     : TEXT *
 * RETURNS       : BOOLEAN
 * REMARKS       :
 * ****************************************************************************/
BOOLEAN ESMEClient::EncodeString(TEXT *lString)
{
   while (m_EsmePdu.data[m_EsmePdu.pos++] = *lString++);
   m_EsmePdu.len = --m_EsmePdu.pos;

   return true;
}

/*****************************************************************************
 * FUNCTION NAME : EncodeInteger
 * DEFINITION    :
 * ARGUMENTS     : UINT32, INT32
 * RETURNS       : BOOLEAN
 * REMARKS       :
 * ****************************************************************************/
BOOLEAN ESMEClient::EncodeInteger(UINT32 lValue, INT32 lBytes)
{
   for (INT32 lshift = lBytes - 1; lshift > -1; lshift--)
      m_EsmePdu.data[m_EsmePdu.pos++] = (lValue >> lshift * 8) & 0xFF;

   m_EsmePdu.len += lBytes;
   return true;
}

/*****************************************************************************
 * FUNCTION NAME : EncodeHeader
 * DEFINITION    :
 * ARGUMENTS     :
 * RETURNS       : BOOLEAN
 * REMARKS       :
 * ****************************************************************************/
BOOLEAN ESMEClient::EncodeHeader()
{
   memset(&m_EsmePdu, 0, sizeof(m_EsmePdu));
   DLOG(0,0,"%s <Ln:%d> \n========Encoding========", __FUNCTION__, __LINE__);

   if (false == this->EncodeInteger(m_ESMEData.command_length, MAX_ESME_COMMAND_LENGTH_LEN))
   {
      WLOG(0,0,"%s <Ln:%d> Failed to encode", __FUNCTION__, __LINE__);
      return false;
   }
   DLOG(0,0,"%s <Ln:%d> command_length:%ld",
         __FUNCTION__, __LINE__, m_ESMEData.command_length);

   if (false == this->EncodeInteger(m_ESMEData.command_id, MAX_ESME_COMMAND_ID_LEN))
   {
      WLOG(0,0,"%s <Ln:%d> Failed to encode", __FUNCTION__, __LINE__);
      return false;
   }
   DLOG(0,0,"%s <Ln:%d> command_id:%s",
         __FUNCTION__, __LINE__, ConvertESMEOperationToString((enum ESME_OPERATION)m_ESMEData.command_id));

   if (false == this->EncodeInteger(m_ESMEData.command_status, MAX_ESME_COMMAND_STATUS_LEN))
   {
      WLOG(0,0,"%s <Ln:%d> Failed to encode", __FUNCTION__, __LINE__);
      return false;
   }
   DLOG(0,0,"%s <Ln:%d> command_status:%ld",
         __FUNCTION__, __LINE__, m_ESMEData.command_status);

   if (false == this->EncodeInteger(m_ESMEData.sequence_number, MAX_ESME_SEQUENCE_NUMBER_LEN))
   {
      WLOG(0,0,"%s <Ln:%d> Failed to encode", __FUNCTION__, __LINE__);
      return false;
   }
   DLOG(0,0,"%s <Ln:%d> sequence_number:%ld",
         __FUNCTION__, __LINE__, m_ESMEData.sequence_number);

   return true;
}

/******************************************************************************
 * FUNCTION NAME : DecodeInteger
 * DEFINITION    :
 * ARGUMENTS     : INT32
 * RETURNS       : UINT32 
 * REMARKS       :
 * ****************************************************************************/
UINT32 ESMEClient::DecodeInteger(INT32 len)
{
   UINT32 l_Value = 0;

   if (m_EsmePdu.len < m_EsmePdu.pos + len)
   {
      DLOG(0,0,"%s <Ln:%d> Wrong PDU length", __FUNCTION__, __LINE__);
      return -1;
   }

   for (INT32 l_Index = 0; l_Index < len; ++l_Index)
      l_Value = (l_Value << 8) | (UINT8) m_EsmePdu.data[m_EsmePdu.pos++];

   return l_Value;
}

/******************************************************************************
 * FUNCTION NAME : DecodeCString 
 * DEFINITION    :
 * ARGUMENTS     : TEXT *
 * RETURNS       : BOOLEAN
 * REMARKS       :
 * ****************************************************************************/
BOOLEAN ESMEClient::DecodeCString(TEXT *field)
{
   INT32 l_index;

   for (l_index = 0; m_EsmePdu.data[m_EsmePdu.pos] != '\0'; l_index++)
   {
      if (m_EsmePdu.pos > m_EsmePdu.len)
      {
         DLOG(0,0,"%s <Ln:%d> Wrong PDU length", __FUNCTION__, __LINE__);
         return false;
      }

      field[l_index] = m_EsmePdu.data[m_EsmePdu.pos++];
   }

   field[l_index] = m_EsmePdu.data[m_EsmePdu.pos++]; // insert the null character

   return true;
}

/******************************************************************************
 * FUNCTION NAME : DecodeString
 * DEFINITION    :
 * ARGUMENTS     : INT32, TEXT *
 * RETURNS       : BOOLEAN
 * REMARKS       :
 * ****************************************************************************/
BOOLEAN ESMEClient::DecodeString(INT32 len, TEXT *field)
{
   INT32 l_index;

   if (m_EsmePdu.len < m_EsmePdu.pos + len)
   {
      DLOG(0,0,"%s <Ln:%d> Wrong PDU length", __FUNCTION__, __LINE__);
      return false;
   }
   DLOG(0,0,"%s <Ln:%d> PDU length %d, PDU position %d, STRING length %d",
         __FUNCTION__, __LINE__,m_EsmePdu.len ,m_EsmePdu.pos,len);

   for (l_index = 0; l_index < len; l_index++)
   {
      if (m_EsmePdu.pos > m_EsmePdu.len)
      {
         DLOG(0,0,"%s <Ln:%d> Wrong PDU length", __FUNCTION__, __LINE__);
         return false;
      }

      field[l_index] = m_EsmePdu.data[m_EsmePdu.pos++];
   }

   field[l_index] = m_EsmePdu.data[m_EsmePdu.pos]; // insert the null character

   return true;
}

/******************************************************************************
 * FUNCTION NAME : DecodeHeader
 * DEFINITION    :
 * ARGUMENTS     :
 * RETURNS       : BOOLEAN
 * REMARKS       :
 * ****************************************************************************/
BOOLEAN ESMEClient::DecodeHeader()
{
   /* get the PDU Length */
   DLOG(0,0,"%s <Ln:%d> \n========Decoding========", __FUNCTION__, __LINE__);

   //if (-1 == (m_ESMEData.command_length = this->DecodeInteger(MAX_ESME_COMMAND_LENGTH_LEN)))
   m_RespMsg = new Esme_Data;
   if (-1 == (m_RespMsg->command_length = this->DecodeInteger(MAX_ESME_COMMAND_LENGTH_LEN)))
   {
      DLOG(0,0,"%s <Ln:%d> Invalid PDU length: %ld",
            __FUNCTION__, __LINE__, m_RespMsg->command_length);
      m_RespMsg->command_status = SMPP_ESME_RINVCMDLEN;
      return false;
   }

   // Check the length later
   if (m_RespMsg->command_length < MAX_ESME_HEADER_LEN || m_RespMsg->command_length > MAX_ESME_PDU_LEN)
   {
      DLOG(0,0,
            "%s <Ln:%d> SMPP PDU too short or too long... (%ld bytes).", __FUNCTION__, __LINE__,
            m_RespMsg->command_length);
      m_RespMsg->command_status = SMPP_ESME_RINVCMDLEN;
      return false;
   }
   DLOG(0,0,"%s <Ln:%d> command_length: %ld",
         __FUNCTION__, __LINE__, m_RespMsg->command_length);

   m_EsmePdu.len = m_RespMsg->command_length;

   /* get the PDU type */
   if (-1 == (m_RespMsg->command_id = this->DecodeInteger(MAX_ESME_COMMAND_ID_LEN)))
   {
      DLOG(0,0,"%s <Ln:%d> Invalid command_id: %ld",
            __FUNCTION__, __LINE__, m_RespMsg->command_id);
      m_RespMsg->command_status = SMPP_ESME_RINVCMDID;
      return false;
   }
   DLOG(0,0,"%s <Ln:%d> command_id:%s", __FUNCTION__, __LINE__,
         ConvertESMEOperationToString((enum ESME_OPERATION)m_RespMsg->command_id));
   m_RespMsg->message_type = (enum ESME_OPERATION)m_RespMsg->command_id; // Assign the message type

   /* get the PDU command status */
   if (-1 == (m_RespMsg->command_status = this->DecodeInteger(MAX_ESME_COMMAND_STATUS_LEN)))
   {
      DLOG(0,0,"%s <Ln:%d> Invalid command_status: %ld",
            __FUNCTION__, __LINE__, m_RespMsg->command_status);
      m_RespMsg->command_status = SMPP_ESME_RINVCMDLEN;
      return false;
   }
   DLOG(0,0,"%s <Ln:%d> command_status: %ld",
         __FUNCTION__, __LINE__, m_RespMsg->command_status);

   /* get the PDU sequence number */
   if (-1 == (m_RespMsg->sequence_number = this->DecodeInteger(MAX_ESME_SEQUENCE_NUMBER_LEN)))
   {
      DLOG(0,0,"%s <Ln:%d> Invalid sequence_number: %ld",
            __FUNCTION__, __LINE__, m_RespMsg->sequence_number);
      m_RespMsg->command_status = SMPP_ESME_RINVCMDLEN;
      return false;
   }

   DLOG(0,0,"%s <Ln:%d> sequence_number: %ld",
         __FUNCTION__, __LINE__, m_RespMsg->sequence_number);

   return true;
}

/******************************************************************************
 * FUNCTION NAME : ConvertESMEOperationToString
 * DEFINITION    :
 * ARGUMENTS     : enum
 * RETURNS       : TEXT *
 * REMARKS       :
 * ****************************************************************************/
TEXT * ESMEClient::ConvertESMEOperationToString(enum ESME_OPERATION l_Operation)
{
   switch (l_Operation)
   {
      case BIND_TRANSCEIVER:
         return "BIND_TRANSCEIVER";

      case BIND_TRANSCEIVER_RESP:
         return "BIND_TRANSCEIVER_RESP";

      case SUBMIT_SM:
         return "SUBMIT_SM";

      case SUBMIT_SM_RESP:
         return "SUBMIT_SM_RESP";

      case DELIVER_SM:
         return "DELIVER_SM";

      case DELIVER_SM_RESP:
         return "DELIVER_SM_RESP";

      case REPLACE_SM:
         return "REPLACE_SM";

      case REPLACE_SM_RESP:
         return "REPLACE_SM_RESP";

      case QUERY_SM:
         return "QUERY_SM";

      case QUERY_SM_RESP:
         return "QUERY_SM_RESP";

      case CANCEL_SM:
         return "CANCEL_SM";

      case CANCEL_SM_RESP:
         return "CANCEL_SM_RESP";

      case UNBIND:
         return "UNBIND";

      case ENQUIRE_LINK:
         return "ENQUIRE_LINK";

      case ENQUIRE_LINK_RESP:
         return "ENQUIRE_LINK_RESP";

      default:
         return "Invalid SMPP Operation";
   }
}

/*****************************************************************************
 * FUNCTION NAME : EncodeBindTransceiver
 * DEFINITION    : Function to process Bind Transceiver
 * ARGUMENTS     : NONE
 * RETURNS       : BOOLEAN
 * REMARKS       :
 * ****************************************************************************/
BOOLEAN ESMEClient::ProcessBindTransceiver()
{
   snprintf(m_ESMEData.msg.BindTransceiver.system_id, MAX_SYSTEM_ID_LEN+1, "%s", g_ConfigData->m_EsmeConfigData.m_System_Id); 
   snprintf(m_ESMEData.msg.BindTransceiver.password, MAX_PASSWORD_LEN+1, "%s", g_ConfigData->m_EsmeConfigData.m_Password);
   snprintf(m_ESMEData.msg.BindTransceiver.system_type, MAX_SYSTEM_TYPE_LEN+1, "%s", g_ConfigData->m_EsmeConfigData.m_System_Type);
   m_ESMEData.msg.BindTransceiver.interface_version = 0x34;
   m_ESMEData.msg.BindTransceiver.addr_ton = g_ConfigData->m_EsmeConfigData.m_BindTON;
   m_ESMEData.msg.BindTransceiver.addr_npi = g_ConfigData->m_EsmeConfigData.m_BindNPI;
   snprintf(m_ESMEData.msg.BindTransceiver.address_range, strlen("") + 1, "%s", "");

   m_ESMEData.command_id = BIND_TRANSCEIVER;
   m_ESMEData.command_status = SMPP_ESME_ROK;
   m_ESMEData.sequence_number = getSequenceNo();
   m_ESMEData.command_length = MAX_ESME_HEADER_LEN +
      strlen(m_ESMEData.msg.BindTransceiver.system_id) + 1 +
      strlen(m_ESMEData.msg.BindTransceiver.password) + 1 +
      strlen(m_ESMEData.msg.BindTransceiver.system_type) + 1 +
      strlen(m_ESMEData.msg.BindTransceiver.address_range) + 1 + 3;

   if (false == this->EncodeHeader())
   {
      DLOG(0,0,"%s <Ln:%d> Error in Encoding", __FUNCTION__, __LINE__);
      return false;
   }

   this->EncodeCString(m_ESMEData.msg.BindTransceiver.system_id);
   this->EncodeCString(m_ESMEData.msg.BindTransceiver.password);
   this->EncodeCString(m_ESMEData.msg.BindTransceiver.system_type);
   this->EncodeInteger(m_ESMEData.msg.BindTransceiver.interface_version,1);
   this->EncodeInteger(m_ESMEData.msg.BindTransceiver.addr_ton,1);
   this->EncodeInteger(m_ESMEData.msg.BindTransceiver.addr_npi,1);
   this->EncodeCString(m_ESMEData.msg.BindTransceiver.address_range);
   DLOG(0,0,"%s <Ln:%d> Sending Bind Transceiver", __FUNCTION__, __LINE__);

   this->SendMessage();

   return true;
}



/*****************************************************************************
 * FUNCTION NAME : SendEnquireLinkResp
 * DEFINITION    : Function to encode SubmitSm
 * ARGUMENTS     : NONE
 * RETURNS       : BOOLEAN
 * REMARKS       :
 * ****************************************************************************/
BOOLEAN ESMEClient::SendEnquireLinkResp()
{
   m_ESMEData.command_id = ENQUIRE_LINK_RESP;
   m_ESMEData.command_status = SMPP_ESME_ROK;
   m_ESMEData.sequence_number = m_RespMsg->sequence_number;//getSequenceNo();
   m_ESMEData.command_length  = MAX_ESME_HEADER_LEN;

   if (false == this->EncodeHeader())
   {
      DLOG(0,0,"%s <Ln:%d> Error in Encoding", __FUNCTION__, __LINE__);
      return false;
   }
   this->SendMessage();
   return true;
}


BOOLEAN ESMEClient::Encode()
{
   switch (m_ESMEData.command_id)
   {
      case SUBMIT_SM:
         this->EncodeSubmitSm();
         break;
      case QUERY_SM:
         this->EncodeQuerySm();
         break;
      case CANCEL_SM:
         this->EncodeCancelSm();
         break;
      case REPLACE_SM:
         this->EncodeReplaceSm();
         break;
      case ENQUIRE_LINK:
         this->EncodeEnquireLink();
         break;
      case UNBIND:
         break;
      case DELIVER_SM:
         break;
      case BIND_TRANSCEIVER:
         break;
      default:
         ELOG(0,0,"Unable to encode");
         break;
   }
   return true;
}


/*****************************************************************************
 * FUNCTION NAME : EncodeSubmitSm
 * DEFINITION    : Function to encode SubmitSm
 * ARGUMENTS     : NONE
 * RETURNS       : BOOLEAN
 * REMARKS       :
 * ****************************************************************************/
BOOLEAN ESMEClient::EncodeSubmitSm()
{
   //Encoding Text

   if((0x01 == m_ESMEData.msg.SubmitSm.data_coding)||(0x00 == m_ESMEData.msg.SubmitSm.data_coding)) //7 bit
   {
      DLOG(0,0,"%s <Ln:%d> Ascii string length[%d]",
            __FUNCTION__, __LINE__,strlen((char*)m_ESMEData.msg.SubmitSm.message_payload));
      char l_tmpMsg[SMPP_MSG_PAYLOAD_LEN_MAX] = "";
      int l_MsgLen = 
         GSM7bitEncoding((unsigned char *)m_ESMEData.msg.SubmitSm.message_payload,(char *)l_tmpMsg);
      DLOG(0,0,"%s <Ln:%d> GSM 7-bit Encoded string length[%d]",
            __FUNCTION__, __LINE__,l_MsgLen);

      if(l_MsgLen<=254)
      {
         m_ESMEData.msg.SubmitSm.sm_length = l_MsgLen;
         memcpy(m_ESMEData.msg.SubmitSm.message_payload, l_tmpMsg, l_MsgLen);
      }
      else
      {
         m_ESMEData.msg.SubmitSm.payload_length = l_MsgLen;
         memcpy(m_ESMEData.msg.SubmitSm.message_payload, l_tmpMsg, l_MsgLen);
      }
   }
   else if(0x08 == m_ESMEData.msg.SubmitSm.data_coding) //16 bit
   {
      DLOG(0,0,"%s <Ln:%d> Ascii string length[%d]",
            __FUNCTION__, __LINE__,strlen((char*)m_ESMEData.msg.SubmitSm.message_payload));
      char l_tmpMsg[SMPP_MSG_PAYLOAD_LEN_MAX] = "";
      int l_MsgLen = UnicodeEncoding(m_ESMEData.msg.SubmitSm.message_payload, (char *)l_tmpMsg);
      DLOG(0,0,"%s <Ln:%d> Unicode string length[%d]",
            __FUNCTION__, __LINE__, l_MsgLen);
      if(l_MsgLen<=254)
      {
         m_ESMEData.msg.SubmitSm.sm_length = l_MsgLen;
         memcpy(m_ESMEData.msg.SubmitSm.message_payload, l_tmpMsg, l_MsgLen);
      }
      else
      {
         m_ESMEData.msg.SubmitSm.payload_length = l_MsgLen;
         memcpy(m_ESMEData.msg.SubmitSm.message_payload, l_tmpMsg, l_MsgLen);
      }
   }
   else //if(0x03 == m_MsgInfo->dataCoding) //8 bit
   {

      int l_MsgLen = strlen((char*)m_ESMEData.msg.SubmitSm.message_payload);
      if(l_MsgLen<=254)
      {
         m_ESMEData.msg.SubmitSm.sm_length = l_MsgLen;
         strncpy(m_ESMEData.msg.SubmitSm.message_payload, (char*)m_ESMEData.msg.SubmitSm.message_payload, l_MsgLen + 1);
      }
      else
      {
         m_ESMEData.msg.SubmitSm.payload_length = l_MsgLen;
         strncpy(m_ESMEData.msg.SubmitSm.message_payload, (char*)m_ESMEData.msg.SubmitSm.message_payload, l_MsgLen + 1);
      }
   }


   //End of Encoding Text

   m_ESMEData.command_id = SUBMIT_SM;
   m_ESMEData.command_status = SMPP_ESME_ROK;
   m_ESMEData.sequence_number = getSequenceNo();
   m_ESMEData.command_length = MAX_ESME_HEADER_LEN +
      strlen(m_ESMEData.msg.SubmitSm.service_type) + 1 +
      strlen(m_ESMEData.msg.SubmitSm.source_addr) + 1 + 
      strlen(m_ESMEData.msg.SubmitSm.destination_addr) + 1 +
      strlen(m_ESMEData.msg.SubmitSm.schedule_delivery_time) + 1 +
      strlen(m_ESMEData.msg.SubmitSm.validity_period) + 1 + 12 +
      m_ESMEData.msg.SubmitSm.sm_length +
      ((m_ESMEData.msg.SubmitSm.payload_length > 0)?m_ESMEData.msg.SubmitSm.payload_length+4:0);

   printf("\nLength of the pdu : %d", m_ESMEData.command_length);

   if (false == this->EncodeHeader())
   {
      DLOG(0,0,"%s <Ln:%d> Error in Encoding", __FUNCTION__, __LINE__);
      return false;
   }

   this->EncodeCString(m_ESMEData.msg.SubmitSm.service_type);
   this->EncodeInteger(m_ESMEData.msg.SubmitSm.source_addr_ton,1); 
   this->EncodeInteger(m_ESMEData.msg.SubmitSm.source_addr_npi,1);
   this->EncodeCString(m_ESMEData.msg.SubmitSm.source_addr);
   this->EncodeInteger(m_ESMEData.msg.SubmitSm.dest_addr_ton,1);
   this->EncodeInteger(m_ESMEData.msg.SubmitSm.dest_addr_npi,1);
   this->EncodeCString(m_ESMEData.msg.SubmitSm.destination_addr);
   this->EncodeInteger(m_ESMEData.msg.SubmitSm.esm_class,1);   
   this->EncodeInteger(m_ESMEData.msg.SubmitSm.protocol_id,1);
   this->EncodeInteger(m_ESMEData.msg.SubmitSm.priority_flag,1);
   this->EncodeCString(m_ESMEData.msg.SubmitSm.schedule_delivery_time);
   this->EncodeCString(m_ESMEData.msg.SubmitSm.validity_period);
   this->EncodeInteger(m_ESMEData.msg.SubmitSm.registered_delivery,1);
   this->EncodeInteger(m_ESMEData.msg.SubmitSm.replace_if_present_flag,1);
   this->EncodeInteger(m_ESMEData.msg.SubmitSm.data_coding,1);
   this->EncodeInteger(m_ESMEData.msg.SubmitSm.sm_default_msg_id,1);
   this->EncodeInteger(m_ESMEData.msg.SubmitSm.sm_length,1);

   DLOG(0,0,"%s <Ln:%d> Service Type:[%s]",
         __FUNCTION__, __LINE__, m_ESMEData.msg.SubmitSm.service_type);

   DLOG(0,0,"%s <Ln:%d> Data Coding Scheme:[%d]",
         __FUNCTION__, __LINE__, m_ESMEData.msg.SubmitSm.data_coding);

   DLOG(0,0,"%s <Ln:%d> Short Message length [len:%d]",
         __FUNCTION__, __LINE__, m_ESMEData.msg.SubmitSm.sm_length);

   memcpy(&m_EsmePdu.data[m_EsmePdu.pos], m_ESMEData.msg.SubmitSm.message_payload, m_ESMEData.msg.SubmitSm.sm_length);
   m_EsmePdu.pos += m_ESMEData.msg.SubmitSm.sm_length;
   DLOG(0,0,"%s <Ln:%d> Short Message is:[%s]",
         __FUNCTION__, __LINE__, m_ESMEData.msg.SubmitSm.message_payload);

   if(m_ESMEData.msg.SubmitSm.payload_length>0)
   {
      this->EncodeTLVString(SMPP_MESSAGE_PAYLOAD, m_ESMEData.msg.SubmitSm.payload_length, 
            m_ESMEData.msg.SubmitSm.message_payload);
      DLOG(0,0,"%s <Ln:%d>  Message Payload is:[%s]",
            __FUNCTION__, __LINE__, m_ESMEData.msg.SubmitSm.message_payload);
   }

   m_EsmePdu.len = m_EsmePdu.pos;
   return true;
}



/******************************************************************************
 * FUNCTION NAME : EncodeReplaceaSm
 * DEFINITION    : Function to encode ReplaceSm
 * ARGUMENTS     : NONE
 * RETURNS       : BOOLEAN
 * REMARKS       :
 * ****************************************************************************/
BOOLEAN ESMEClient::EncodeReplaceSm()
{
   m_ESMEData.command_id = REPLACE_SM;
   m_ESMEData.command_status = SMPP_ESME_ROK;
   m_ESMEData.sequence_number = getSequenceNo();
   m_ESMEData.command_length = MAX_ESME_HEADER_LEN + 5 +
      strlen(m_ESMEData.msg.ReplaceSm.message_id) + 1 +
      strlen(m_ESMEData.msg.ReplaceSm.source_addr) + 1 +
      strlen(m_ESMEData.msg.ReplaceSm.schedule_delivery_time) + 1 +
      strlen(m_ESMEData.msg.ReplaceSm.validity_period) + 1 +
      m_ESMEData.msg.ReplaceSm.sm_length;

   if (false == this->EncodeHeader())
   {
      DLOG(0,0,"%s <Ln:%d> Error in Encoding", __FUNCTION__, __LINE__);
      return false;
   }

   this->EncodeCString(m_ESMEData.msg.ReplaceSm.message_id);
   this->EncodeInteger(m_ESMEData.msg.ReplaceSm.source_addr_ton,1); 
   this->EncodeInteger(m_ESMEData.msg.ReplaceSm.source_addr_npi,1);
   this->EncodeCString(m_ESMEData.msg.ReplaceSm.source_addr);
   this->EncodeCString(m_ESMEData.msg.ReplaceSm.schedule_delivery_time);
   this->EncodeCString(m_ESMEData.msg.ReplaceSm.validity_period);
   this->EncodeInteger(m_ESMEData.msg.ReplaceSm.registered_delivery,1);
   this->EncodeInteger(m_ESMEData.msg.ReplaceSm.sm_default_msg_id,1);
   this->EncodeInteger(m_ESMEData.msg.ReplaceSm.sm_length,1);

   memcpy(&m_EsmePdu.data[m_EsmePdu.pos], m_ESMEData.msg.ReplaceSm.message_payload, m_ESMEData.msg.ReplaceSm.sm_length);
   m_EsmePdu.pos += m_ESMEData.msg.ReplaceSm.sm_length;
   m_EsmePdu.len = m_EsmePdu.pos;

   return true;
}


/*****************************************************************************
 * FUNCTION NAME : EncodeQuerySm
 * DEFINITION    : Function to encode QuerySm
 * ARGUMENTS     : NONE
 * RETURNS       : BOOLEAN
 * REMARKS       :
 * ****************************************************************************/
BOOLEAN ESMEClient::EncodeQuerySm()
{
   m_ESMEData.command_id = QUERY_SM;
   m_ESMEData.command_status = SMPP_ESME_ROK;
   m_ESMEData.sequence_number = getSequenceNo();
   m_ESMEData.command_length = MAX_ESME_HEADER_LEN + 2 +
      strlen(m_ESMEData.msg.QuerySm.message_id) + 1 +
      strlen(m_ESMEData.msg.QuerySm.source_addr) + 1;

   if (false == this->EncodeHeader())
   {
      DLOG(0,0,"%s <Ln:%d> Error in Encoding", __FUNCTION__, __LINE__);
      return false;
   }

   this->EncodeCString(m_ESMEData.msg.QuerySm.message_id);
   this->EncodeInteger(m_ESMEData.msg.QuerySm.source_addr_ton,1);
   this->EncodeInteger(m_ESMEData.msg.QuerySm.source_addr_npi,1);
   this->EncodeCString(m_ESMEData.msg.QuerySm.source_addr);

   return true;
}


/*****************************************************************************
 * FUNCTION NAME : EncodeCancelSm
 * DEFINITION    : Function to Encode CancelSm
 * ARGUMENTS     : NONE
 * RETURNS       : BOOLEAN
 * REMARKS       :
 * ****************************************************************************/
BOOLEAN ESMEClient::EncodeCancelSm()
{
   m_ESMEData.command_id = CANCEL_SM;
   m_ESMEData.command_status = SMPP_ESME_ROK;
   m_ESMEData.sequence_number = getSequenceNo();

   m_ESMEData.command_length = MAX_ESME_HEADER_LEN + 4 +
      strlen(m_ESMEData.msg.CancelSm.service_type) + 1 +
      strlen(m_ESMEData.msg.CancelSm.message_id) + 1 +
      strlen(m_ESMEData.msg.CancelSm.source_addr) + 1 +
      strlen(m_ESMEData.msg.CancelSm.destination_addr) + 1;

   if (false == this->EncodeHeader())
   {
      DLOG(0,0,"%s <Ln:%d> Error in Encoding", __FUNCTION__, __LINE__);
      return false;
   }

   this->EncodeCString(m_ESMEData.msg.CancelSm.service_type);
   this->EncodeCString(m_ESMEData.msg.CancelSm.message_id);
   this->EncodeInteger(m_ESMEData.msg.CancelSm.source_addr_ton,1); 
   this->EncodeInteger(m_ESMEData.msg.CancelSm.source_addr_npi,1);
   this->EncodeCString(m_ESMEData.msg.CancelSm.source_addr);
   this->EncodeInteger(m_ESMEData.msg.CancelSm.dest_addr_ton,1);
   this->EncodeInteger(m_ESMEData.msg.CancelSm.dest_addr_npi,1);
   this->EncodeCString(m_ESMEData.msg.CancelSm.destination_addr);

   return true;   
}

/*****************************************************************************
 * FUNCTION NAME : EncodeEnquireLink
 * DEFINITION    : Function to encode EnquireLink
 * ARGUMENTS     : NONE
 * RETURNS       : BOOLEAN
 * REMARKS       :
 * ****************************************************************************/
BOOLEAN ESMEClient::EncodeEnquireLink()
{
   m_ESMEData.command_id = ENQUIRE_LINK;
   m_ESMEData.command_status = SMPP_ESME_ROK;
   m_ESMEData.sequence_number = getSequenceNo();
   m_ESMEData.command_length = MAX_ESME_HEADER_LEN; 

   if (false == this->EncodeHeader())
   {
      DLOG(0,0,"%s <Ln:%d> Error in Encoding", __FUNCTION__, __LINE__);
      return false;
   }

   return true;
}

/*****************************************************************************
 * FUNCTION NAME : ProcessUnBind 
 * DEFINITION    : Function to process UnBind
 * ARGUMENTS     : NONE
 * RETURNS       : BOOLEAN
 * REMARKS       :
 * ****************************************************************************/
BOOLEAN ESMEClient::ProcessUnBind()
{
   m_ESMEData.command_id = UNBIND;
   m_ESMEData.command_status = SMPP_ESME_ROK;
   m_ESMEData.sequence_number = getSequenceNo();
   m_ESMEData.command_length = MAX_ESME_HEADER_LEN; 

   if (false == this->EncodeHeader())
   {
      DLOG(0,0,"%s <Ln:%d> Error in Encoding", __FUNCTION__, __LINE__);
      return false;
   }

   this->SendMessage();

   return true;
}

/*****************************************************************************
 * FUNCTION NAME : DecodeBindTransceiverResp 
 * DEFINITION    : Function to decode BindTransceiverResponse
 * ARGUMENTS     : NONE
 * RETURNS       : BOOLEAN
 * REMARKS       :
 * ****************************************************************************/
BOOLEAN ESMEClient::DecodeBindTransceiverResp()
{
   if (false == this->DecodeCString(m_RespMsg->msg.BindTransceiver.system_id))
   {
      DLOG(0,0,"%s <Ln:%d> Failed Decoding the PDU", __FUNCTION__, __LINE__);
      return false;
   }
   DLOG(0,0,"%s <Ln:%d> System id:%s",
         __FUNCTION__, __LINE__, m_RespMsg->msg.BindTransceiver.system_id);

   if(m_RespMsg->command_status != SMPP_ESME_ROK)
   {
      g_SmppConnection = false;
      DLOG(0,0,"%s <Ln:%d> Received Negative Response", __FUNCTION__, __LINE__);
      return false;
   }
   g_si.sendSnmpTrap(g_SmscConnectionTrap, TRAP_TYPE_PASS, TRAP_SEVERITY_MINOR);
   g_SmppConnection = true;
   return true;
}

/*****************************************************************************
 * FUNCTION NAME : DecodeSubmitSmResp
 * DEFINITION    : Function to decode SubmitSmResponse
 * ARGUMENTS     : NONE
 * RETURNS       : BOOLEAN
 * REMARKS       :
 * ****************************************************************************/
BOOLEAN ESMEClient::DecodeSubmitSmResp()
{
   if(m_RespMsg->command_status == SMPP_ESME_ROK)
   {
      if (false == this->DecodeCString(m_RespMsg->msg.SubmitSmResp.message_id))
      {
         DLOG(0,0,"%s <Ln:%d> Failed Decoding the PDU", __FUNCTION__, __LINE__);
         return false;
      }
      DLOG(0,0,"%s <Ln:%d> Message id:[%s]",
            __FUNCTION__, __LINE__, m_RespMsg->msg.SubmitSmResp.message_id);
   }

   return true;
}

/*****************************************************************************
 * FUNCTION NAME : DecodeReplaceSmResp
 * DEFINITION    : Function to decode ReplaceSmResponse
 * ARGUMENTS     : NONE
 * RETURNS       : BOOLEAN
 * REMARKS       :
 * ****************************************************************************/
BOOLEAN ESMEClient::DecodeReplaceSmResp()
{
   if(SMPP_ESME_ROK != m_RespMsg->command_status)
   {
      DLOG(0,0,"%s <Ln:%d> ReplaceSm Failed. Send SubmitSm", __FUNCTION__, __LINE__);
      m_ESMEData.message_type = SUBMIT_SM;
      return true;
   }

   return true;
}

/*****************************************************************************
 * FUNCTION NAME : DecodeQuerySmResp
 * DEFINITION    : Function to decode QuerySmResponse
 * ARGUMENTS     : NONE
 * RETURNS       : BOOLEAN
 * REMARKS       :
 * ****************************************************************************/
BOOLEAN ESMEClient::DecodeQuerySmResp()
{
   if( false == this->DecodeCString(m_RespMsg->msg.QuerySmResp.message_id))
   {
      DLOG(0,0,"%s <Ln:%d> Failed Decoding the PDU", __FUNCTION__, __LINE__);
      return false;
   }

   DLOG(0,0,"%s <Ln:%d> Message ID:%s",
         __FUNCTION__, __LINE__, m_RespMsg->msg.QuerySmResp.message_id);

   if( false == this->DecodeCString(m_RespMsg->msg.QuerySmResp.final_date))
   {
      DLOG(0,0,"%s <Ln:%d> Failed Decoding the PDU", __FUNCTION__, __LINE__);
      return false;
   }

   if (-1 == (m_RespMsg->msg.QuerySmResp.message_state = this->DecodeInteger(SMPP_MESSAGE_STATE_LEN)))
   {
      DLOG(0,0,"%s <Ln:%d> Failed Decoding the PDU", __FUNCTION__, __LINE__);
      return false;
   }

   DLOG(0,0,"%s <Ln:%d> Message State is %d",
         __FUNCTION__, __LINE__, m_RespMsg->msg.QuerySmResp.message_state);

   if (NOTDELIVERED == m_RespMsg->msg.QuerySmResp.message_state)
   {
      DLOG(0,0,"%s <Ln:%d> Message is not delivered. Send ReplaceSm",
            __FUNCTION__, __LINE__);
      m_ESMEData.message_type = REPLACE_SM;
   }
   else
   {
      DLOG(0,0,"%s <Ln:%d> Message is delivered. Send SubmitSm",
            __FUNCTION__, __LINE__);
      m_ESMEData.message_type = SUBMIT_SM;
   }
   return true;
}

/*****************************************************************************
 * FUNCTION NAME : DecodeCancelSmResp
 * DEFINITION    : Function to decode CancelSmResponse
 * ARGUMENTS     : NONE
 * RETURNS       : BOOLEAN
 * REMARKS       :
 * ****************************************************************************/
BOOLEAN ESMEClient::DecodeCancelSmResp()
{
   return true;
}

/*****************************************************************************
 * FUNCTION NAME : SendDeliverSmResp
 * DEFINITION    : Function to DeliverSm Response
 * ARGUMENTS     : NONE
 * RETURNS       : BOOLEAN
 * REMARKS       :
 * ****************************************************************************/
BOOLEAN ESMEClient::SendDeliverSmResp(INT16 l_CmdStatus)
{
   m_ESMEData.command_id      = DELIVER_SM_RESP;

   if(0 != l_CmdStatus)
   {
      m_ESMEData.command_status  = l_CmdStatus;
      m_ESMEData.sequence_number = m_RespMsg->sequence_number;
      m_ESMEData.command_length  = MAX_ESME_HEADER_LEN + strlen(m_RespMsg->msg.SubmitSmResp.message_id) + 1;
   }
   else
   {
      m_ESMEData.command_status  = m_RespMsg->command_status;
      m_ESMEData.sequence_number = m_RespMsg->sequence_number;
      m_ESMEData.command_length  = MAX_ESME_HEADER_LEN + strlen(m_RespMsg->msg.SubmitSmResp.message_id) + 1;

   }

   snprintf(m_ESMEData.msg.SubmitSmResp.message_id, MAX_MESSAGE_ID_LEN + 1, "%s", m_RespMsg->msg.SubmitSmResp.message_id); 

   if (false == this->EncodeHeader())
   {
      DLOG(0,0,"%s <Ln:%d> Error in Encoding", __FUNCTION__, __LINE__);
      return false;
   }

   if(0 != l_CmdStatus)
      this->EncodeCString(m_ESMEData.msg.SubmitSmResp.message_id);
   else
      this->EncodeCString(m_RespMsg->msg.SubmitSmResp.message_id);

   DLOG(0,0,"%s <Ln:%d> Sending the PDU", __FUNCTION__, __LINE__);

   if (false == this->SendMessage())
      return false;

   return true;
}



/*****************************************************************************
 * FUNCTION NAME : DecodeDeliverSm
 * DEFINITION    : Function to decode DeliverSm
 * ARGUMENTS     : NONE
 * RETURNS       : BOOLEAN
 * REMARKS       :
 * ****************************************************************************/
BOOLEAN ESMEClient::DecodeDeliverSm()
{
   if (false == this->DecodeCString(m_RespMsg->msg.DeliverSm.service_type))
   {
      DLOG(0,0,"%s <Ln:%d> Failed Decoding the PDU", __FUNCTION__, __LINE__);
      SendDeliverSmResp(SMPP_ESME_RSYSERR);
      return false;
   }
   INT16 l_servicetypeLen = strlen(m_RespMsg->msg.DeliverSm.service_type);
   if ((0 != l_servicetypeLen) && (l_servicetypeLen < MIN_SYSTEM_TYPE_LEN || l_servicetypeLen > MAX_SYSTEM_TYPE_LEN))
   {
      WLOG(0,0,"%s <Ln:%d> Invalid Service Type",
            __FUNCTION__, __LINE__);
      SendDeliverSmResp(SMPP_ESME_RINVSERTYP);
      return false;
   }

   DLOG(0,0,"%s <Ln:%d> Service type :%s",
         __FUNCTION__, __LINE__, m_RespMsg->msg.DeliverSm.service_type);

   m_RespMsg->msg.DeliverSm.source_addr_ton = m_EsmePdu.data[m_EsmePdu.pos++];
#if 0
   if(false == IsValidTON(m_RespMsg->msg.DeliverSm.source_addr_ton))
   {
      WLOG(0,0,"%s <Ln:%d> Invalid source addr ton",__FUNCTION__,__LINE__,
            m_RespMsg->msg.DeliverSm.source_addr_ton);
      this->SendDeliverSmResp(SMPP_ESME_RINVSRCTON);
      return false;
   } 
#endif
   DLOG(0,0,"%s <Ln:%d> Source Addr TON :%d",
         __FUNCTION__, __LINE__, m_RespMsg->msg.DeliverSm.source_addr_ton);

   m_RespMsg->msg.DeliverSm.source_addr_npi = m_EsmePdu.data[m_EsmePdu.pos++];
#if 0
   if(false == IsValidNPI(m_RespMsg->msg.DeliverSm.source_addr_npi))
   {
      WLOG(0,0,"%s <Ln:%d> Invalid src_addr_npi",__FUNCTION__,__LINE__,
            m_RespMsg->msg.DeliverSm.source_addr_npi);
      this->SendDeliverSmResp(SMPP_ESME_RINVSRCNPI);
      return false;
   } 
#endif
   DLOG(0,0,"%s <Ln:%d> Source Addr npi :%d",
         __FUNCTION__, __LINE__, m_RespMsg->msg.DeliverSm.source_addr_npi);

   if (false == this->DecodeCString(m_RespMsg->msg.DeliverSm.source_addr))
   {
      DLOG(0,0,"%s <Ln:%d> Failed Decoding the PDU", __FUNCTION__, __LINE__);
      this->SendDeliverSmResp(SMPP_ESME_RSYSERR);
      return false;
   }
#if 0
   if(false == IsValidAddress(m_RespMsg->msg.DeliverSm.source_addr))
   {
      WLOG(0,0,"%s <Ln:%d> Invalid Source Address",__FUNCTION__,__LINE__,
            m_RespMsg->msg.DeliverSm.source_addr);
      this->SendDeliverSmResp(SMPP_ESME_RINVSRCADR);
      return false;
   }
#endif
   DLOG(0,0,"%s <Ln:%d> Source Addr :%s",
         __FUNCTION__, __LINE__, m_RespMsg->msg.DeliverSm.source_addr);


   m_RespMsg->msg.DeliverSm.dest_addr_ton = m_EsmePdu.data[m_EsmePdu.pos++];
#if 0
   if(false == IsValidTON(m_RespMsg->msg.DeliverSm.dest_addr_ton))
   {
      WLOG(0,0,"%s <Ln:%d> Invalid dest addr ton",__FUNCTION__,__LINE__,
            m_RespMsg->msg.DeliverSm.dest_addr_ton);
      this->SendDeliverSmResp(SMPP_ESME_RINVDSTTON);
      return false;
   }
#endif
   DLOG(0,0,"%s <Ln:%d> Destination Address Ton  :%d",
         __FUNCTION__, __LINE__, m_RespMsg->msg.DeliverSm.dest_addr_ton);

   m_RespMsg->msg.DeliverSm.dest_addr_npi = m_EsmePdu.data[m_EsmePdu.pos++];
#if 0
   if(false == IsValidNPI(m_RespMsg->msg.DeliverSm.dest_addr_npi))
   {
      WLOG(0,0,"%s <Ln:%d> Invalid dest_addr_npi",__FUNCTION__,__LINE__,
            m_RespMsg->msg.DeliverSm.dest_addr_npi);
      this->SendDeliverSmResp(SMPP_ESME_RINVDSTNPI);
      return false;
   }
#endif
   DLOG(0,0,"%s <Ln:%d> Destination Address Npi  :%d",
         __FUNCTION__, __LINE__, m_RespMsg->msg.DeliverSm.dest_addr_npi);

   if (false == this->DecodeCString(m_RespMsg->msg.DeliverSm.destination_addr))
   {
      DLOG(0,0,"%s <Ln:%d> Failed Decoding the PDU", __FUNCTION__, __LINE__);
      this->SendDeliverSmResp(SMPP_ESME_RSYSERR);
      return false;
   }
#if 0
   if(false == IsValidAddress(m_RespMsg->msg.DeliverSm.destination_addr))
   {
      WLOG(0,0,"%s <Ln:%d> Invalid dest_addr",__FUNCTION__,__LINE__,
            m_RespMsg->msg.DeliverSm.destination_addr);
      this->SendDeliverSmResp(SMPP_ESME_RINVDSTADR);
      return false;
   }
#endif
   DLOG(0,0,"%s <Ln:%d> Destination Address :%s",
         __FUNCTION__, __LINE__, m_RespMsg->msg.DeliverSm.destination_addr);


   m_RespMsg->msg.DeliverSm.esm_class = m_EsmePdu.data[m_EsmePdu.pos++];
   DLOG(0,0,"%s <Ln:%d> Esm class :%d",
         __FUNCTION__, __LINE__, m_RespMsg->msg.DeliverSm.esm_class);

   m_RespMsg->msg.DeliverSm.protocol_id = m_EsmePdu.data[m_EsmePdu.pos++];
   DLOG(0,0,"%s <Ln:%d> Protocol ID :%d",
         __FUNCTION__, __LINE__, m_RespMsg->msg.DeliverSm.protocol_id);

   m_RespMsg->msg.DeliverSm.priority_flag = m_EsmePdu.data[m_EsmePdu.pos++];
#if 0
   if(false == IsValidPriorityFlag(m_RespMsg->msg.DeliverSm.priority_flag))
   {
      WLOG(0,0,"%s <Ln:%d> Invalid Priority Flag :%d",
            __FUNCTION__, __LINE__, m_RespMsg->msg.DeliverSm.priority_flag);
      SendDeliverSmResp(SMPP_ESME_RINVPRTFLG);
      return false;
   }
#endif
   DLOG(0,0,"%s <Ln:%d> Priority Flag :%d",
         __FUNCTION__, __LINE__, m_RespMsg->msg.DeliverSm.priority_flag);

   if (false == this->DecodeCString(m_RespMsg->msg.DeliverSm.schedule_delivery_time))
   {
      DLOG(0,0,"%s <Ln:%d> Failed Decoding the PDU", __FUNCTION__, __LINE__);
      SendDeliverSmResp(SMPP_ESME_RSYSERR);
      return false;
   }
#if 0
   if(false == IsValidTime(m_RespMsg->msg.DeliverSm.schedule_delivery_time))
   {
      WLOG(0,0,"%s <Ln:%d> Invalid schedule_delivery_time",__FUNCTION__,__LINE__,
            m_RespMsg->msg.DeliverSm.schedule_delivery_time);
      SendDeliverSmResp(SMPP_ESME_RINVSCHED);
      return false;
   }
#endif
   DLOG(0,0,"%s <Ln:%d> Schedule delivery time:%s",
         __FUNCTION__, __LINE__, m_RespMsg->msg.DeliverSm.schedule_delivery_time);


   if (false == this->DecodeCString(m_RespMsg->msg.DeliverSm.validity_period))
   {
      DLOG(0,0,"%s <Ln:%d> Failed Decoding the PDU", __FUNCTION__, __LINE__);
      SendDeliverSmResp(SMPP_ESME_RSYSERR);
      return false;
   }
#if 0
   if(false == IsValidTime(m_RespMsg->msg.DeliverSm.validity_period))
   {
      WLOG(0,0,"%s <Ln:%d> Invalid validity_period",__FUNCTION__,__LINE__,
            m_RespMsg->msg.DeliverSm.validity_period);
      SendDeliverSmResp(SMPP_ESME_RINVEXPIRY);
      return false;
   }
#endif
   DLOG(0,0,"%s <Ln:%d> Validity Period:%s",
         __FUNCTION__, __LINE__, m_RespMsg->msg.DeliverSm.validity_period);


   m_RespMsg->msg.DeliverSm.registered_delivery = m_EsmePdu.data[m_EsmePdu.pos++];
#if 0
   if(false == IsValidRDelivery(m_RespMsg->msg.DeliverSm.registered_delivery))
   {
      WLOG(0,0,"%s <Ln:%d> Invalid Registered Delivery",
            __FUNCTION__, __LINE__);
      SendDeliverSmResp(SMPP_ESME_RINVREGDLVFLG);
      return false;
   }
#endif
   DLOG(0,0,"%s <Ln:%d> Registered Delivery :%d",
         __FUNCTION__, __LINE__, m_RespMsg->msg.DeliverSm.registered_delivery);

   m_RespMsg->msg.DeliverSm.replace_if_present_flag = m_EsmePdu.data[m_EsmePdu.pos++];
#if 0
   if(false == IsValidReplaceIfFlag(m_RespMsg->msg.DeliverSm.replace_if_present_flag))
   {
      WLOG(0,0,"%s <Ln:%d> Invalid Replace If Present Flag:%d",
            __FUNCTION__, __LINE__, m_RespMsg->msg.DeliverSm.replace_if_present_flag );
      SendDeliverSmResp(SMPP_ESME_RINVREPFLAG);
      return false;
   }
#endif
   DLOG(0,0,"%s <Ln:%d> Replace if persent Flag :%d",
         __FUNCTION__, __LINE__, m_RespMsg->msg.DeliverSm.replace_if_present_flag);


   m_RespMsg->msg.DeliverSm.data_coding = m_EsmePdu.data[m_EsmePdu.pos++];
   DLOG(0,0,"%s <Ln:%d> Data coding :%d",
         __FUNCTION__, __LINE__, m_RespMsg->msg.DeliverSm.data_coding);

   m_RespMsg->msg.DeliverSm.sm_default_msg_id = m_EsmePdu.data[m_EsmePdu.pos++];
   DLOG(0,0,"%s <Ln:%d> Sm default ID :%d",
         __FUNCTION__, __LINE__, m_RespMsg->msg.DeliverSm.sm_default_msg_id);


   m_RespMsg->msg.DeliverSm.sm_length = m_EsmePdu.data[m_EsmePdu.pos++];
#if 0
   if(false == IsValidSmLength(m_RespMsg->msg.DeliverSm.sm_length))
   {
      WLOG(0,0,"%s <Ln:%d> Invalid sm_len:%d",
            __FUNCTION__, __LINE__, m_RespMsg->msg.DeliverSm.sm_length);
      SendDeliverSmResp(SMPP_ESME_RINVMSGLEN);
      return false;
   }
#endif
   DLOG(0,0,"%s <Ln:%d> Sm length :%d",
         __FUNCTION__, __LINE__, m_RespMsg->msg.DeliverSm.sm_length);


   if (false == this->DecodeString(m_RespMsg->msg.DeliverSm.sm_length, m_RespMsg->msg.DeliverSm.message_payload))
   {
      DLOG(0,0,"%s <Ln:%d> Failed Decoding the PDU", __FUNCTION__, __LINE__);
      return false;
   }

   DLOG(0,0,"%s <Ln:%d> Short Message:%s",
         __FUNCTION__, __LINE__, m_RespMsg->msg.DeliverSm.message_payload);

   /*** Decode Optional Parameters ***/
   UINT32 lTag, lTagLen;

   while (m_EsmePdu.pos < m_EsmePdu.len)
   {
      switch(lTag = this->DecodeInteger(MAX_OPTIONAL_TAG_LEN))
      {
         case SMPP_SAR_MSG_REF_NUM:

            if (-1 == (lTagLen = this->DecodeInteger(MAX_OPTIONAL_TAG_LENGTH_LEN)))
            {
               WLOG(0,0,"%s <Ln:%d> Failed to Decode Optional Tag Length, Tag[%ld]",
                     __FUNCTION__, __LINE__, lTag);
               return false;
            }

            if (-1 == (m_RespMsg->msg.DeliverSm.sar_msg_ref_num = this->DecodeInteger(lTagLen)))
            {
               WLOG(0,0,"%s <Ln:%d> Failed to Decode Optional Tag Value, Tag[%ld]",
                     __FUNCTION__, __LINE__, lTag);
               return false;
            }
            break;

         case SMPP_SAR_TOTAL_SEGMENTS:

            if (-1 == (lTagLen = this->DecodeInteger(MAX_OPTIONAL_TAG_LENGTH_LEN)))
            {
               WLOG(0,0,"%s <Ln:%d> Failed to Decode Optional Tag Length, Tag[%ld]",
                     __FUNCTION__, __LINE__, lTag);
               return false;
            }

            if (-1 == (m_RespMsg->msg.DeliverSm.sar_total_segments = this->DecodeInteger(lTagLen)))
            {
               WLOG(0,0,"%s <Ln:%d> Failed to Decode Optional Tag Value, Tag[%ld]",
                     __FUNCTION__, __LINE__, lTag);
               return false;
            }
            break;

         case SMPP_SAR_SEGMENT_SEQNUM:

            if (-1 == (lTagLen = this->DecodeInteger(MAX_OPTIONAL_TAG_LENGTH_LEN)))
            {
               WLOG(0,0,"%s <Ln:%d> Failed to Decode Optional Tag Length, Tag[%ld]",
                     __FUNCTION__, __LINE__, lTag);
               return false;
            }

            if (-1 == (m_RespMsg->msg.DeliverSm.sar_segment_seqnum = this->DecodeInteger(lTagLen)))
            {
               WLOG(0,0,"%s <Ln:%d> Failed to Decode Optional Tag Value, Tag[%ld]",
                     __FUNCTION__, __LINE__, lTag);
               return false;
            }
            break;

         case SMPP_PAYLOAD_TYPE:

            if (-1 == (lTagLen = this->DecodeInteger(MAX_OPTIONAL_TAG_LENGTH_LEN)))
            {
               WLOG(0,0,"%s <Ln:%d> Failed to Decode Optional Tag Length, Tag[%ld]",
                     __FUNCTION__, __LINE__, lTag);
               return false;
            }

            if (-1 == (m_RespMsg->msg.DeliverSm.payload_type = this->DecodeInteger(lTagLen)))
            {
               WLOG(0,0,"%s <Ln:%d> Failed to Decode Optional Tag Value, Tag[%ld]",
                     __FUNCTION__, __LINE__, lTag);
               return false;
            }
            break;

         case SMPP_MESSAGE_PAYLOAD:

            if (-1 == (lTagLen = this->DecodeInteger(MAX_OPTIONAL_TAG_LENGTH_LEN)))
            {
               WLOG(0,0,"%s <Ln:%d> Failed to Decode Optional Tag Length, Tag[%ld]",
                     __FUNCTION__, __LINE__, lTag);
               return false;
            }

            if (lTagLen < MAX_SMS_LEN)
            {
               if (false == this->DecodeString(lTagLen, m_RespMsg->msg.DeliverSm.message_payload))
               {
                  WLOG(0,0,"%s <Ln:%d> Failed to Decode Optional Tag Value, Tag[%ld]",
                        __FUNCTION__, __LINE__, lTag);
                  return false;
               }
               m_RespMsg->msg.DeliverSm.sm_length = lTagLen;
            }
            else
            {
               /*
                  if (false == this->DecodeString(lTagLen, m_RespMsg->msg.DeliverSm.message_payload))
                  {
                  WLOG(0,0,"%s <Ln:%d> Failed to Decode Optional Tag Value, Tag[%ld]",
                  __FUNCTION__, __LINE__, lTag);
                  return false;
                  }
                  */
               DLOG(0,0,"%s <Ln:%d> Payload message too large.", __FUNCTION__, __LINE__);
            }
            break;

         case SMPP_PRIVACY_INDICATOR:

            if (-1 == (lTagLen = this->DecodeInteger(MAX_OPTIONAL_TAG_LENGTH_LEN)))
            {
               WLOG(0,0,"%s <Ln:%d> Failed to Decode Optional Tag Length, Tag[%ld]",
                     __FUNCTION__, __LINE__, lTag);
               return false;
            }

            if (-1 == (m_RespMsg->msg.DeliverSm.privacy_indicator = this->DecodeInteger(lTagLen)))
            {
               WLOG(0,0,"%s <Ln:%d> Failed to Decode Optional Tag Value, Tag[%ld]",
                     __FUNCTION__, __LINE__, lTag);
               return false;
            }
            break;

         case SMPP_MESSAGE_STATE:

            if (-1 == (lTagLen = this->DecodeInteger(MAX_OPTIONAL_TAG_LENGTH_LEN)))
            {
               WLOG(0,0,"%s <Ln:%d> Failed to Decode Optional Tag Length, Tag[%ld]",
                     __FUNCTION__, __LINE__, lTag);
               return false;
            }

            if (-1 == (m_RespMsg->msg.DeliverSm.message_state = this->DecodeInteger(lTagLen)))
            {
               WLOG(0,0,"%s <Ln:%d> Failed to Decode Optional Tag Value, Tag[%ld]",
                     __FUNCTION__, __LINE__, lTag);
               return false;
            }
            DLOG(0,0,"%s <Ln:%d> Message State: [%d]",
                  __FUNCTION__, __LINE__, m_RespMsg->msg.DeliverSm.message_state);
            break;

         case SMPP_LANGUAGE_INDICATOR:

            if (-1 == (lTagLen = this->DecodeInteger(MAX_OPTIONAL_TAG_LENGTH_LEN)))
            {
               WLOG(0,0,"%s <Ln:%d> Failed to Decode Optional Tag Length, Tag[%ld]",
                     __FUNCTION__, __LINE__, lTag);
               return false;
            }

            if (-1 == (m_RespMsg->msg.DeliverSm.language_indicator = this->DecodeInteger(lTagLen)))
            {
               WLOG(0,0,"%s <Ln:%d> Failed to Decode Optional Tag Value, Tag[%ld]",
                     __FUNCTION__, __LINE__, lTag);
               return false;
            }
            break;

         case SMPP_USSD_SERVICE_OP:

            if (-1 == (lTagLen = this->DecodeInteger(MAX_OPTIONAL_TAG_LENGTH_LEN)))
            {
               WLOG(0,0,"%s <Ln:%d> Failed to Decode Optional Tag Length, Tag[%ld]",
                     __FUNCTION__, __LINE__, lTag);
               return false;
            }

            if (-1 == (m_RespMsg->msg.DeliverSm.ussd_service_op = this->DecodeInteger(lTagLen)))
            {
               WLOG(0,0,"%s <Ln:%d> Failed to Decode Optional Tag Value, Tag[%ld]",
                     __FUNCTION__, __LINE__, lTag);
               return false;
            }
            break;

         case SMPP_RECEIPTED_MESSAGE_ID:

            if (-1 == (lTagLen = this->DecodeInteger(MAX_OPTIONAL_TAG_LENGTH_LEN)))
            {
               WLOG(0,0,"%s <Ln:%d> Failed to Decode Optional Tag Length, Tag[%ld]",
                     __FUNCTION__, __LINE__, lTag);
               return false;
            }

            if (-1 == (this->DecodeCString(m_RespMsg->msg.DeliverSm.receipted_message_id)))
            {
               WLOG(0,0,"%s <Ln:%d> Failed to Decode Optional Tag Value, Tag[%ld]",
                     __FUNCTION__, __LINE__, lTag);
               return false;
            }
            break;

         case -1:
            WLOG(0,0,"%s <Ln:%d> Failed to Decode Optional Tag", 
                  __FUNCTION__, __LINE__);
            return false;

         default:
            WLOG(0,0,"%s <Ln:%d> Unexpected Tag [%ld]", __FUNCTION__, __LINE__, lTag);
            return false;
      }
   }
   return this->SendDeliverSmResp();
}

/*****************************************************************************
 * FUNCTION NAME : DecodeEnquireLinkResp
 * DEFINITION    : Function to decode EnquireLinkResponse
 * ARGUMENTS     : NONE
 * RETURNS       : BOOLEAN
 * REMARKS       :
 * ****************************************************************************/
BOOLEAN ESMEClient::DecodeEnquireLinkResp()
{
   return true;
}

/******************************************************************************
 * FUNCTION NAME : PrintPdu
 * DEFINITION    :
 * ARGUMENTS     :
 * RETURNS       : BOOLEAN
 * REMARKS       :
 * ****************************************************************************/
BOOLEAN ESMEClient::PrintPdu()
{
   char tmpStr[MAX_ESME_PDU_LEN*2],lTemp[5];
   memset(tmpStr,0,MAX_ESME_PDU_LEN*2);
   if(m_EsmePdu.len > 1000)
   {
      WLOG(0,0,"%s <Ln:%d> PDU Length is more than 1000 [m_EsmePdu.len:%d]",
            __FUNCTION__, __LINE__, m_EsmePdu.len);
      return false;
   }
   for(int j=0; j<m_EsmePdu.len;j++)
   {
      snprintf(lTemp, 4, "%02x ", (UINT8)m_EsmePdu.data[j]);
      strncat(tmpStr,lTemp,4);
   }
   DLOG(0,0,"Message PDU: \
         \n---------------- ESME Hex Dump  ------------------- \
         \nEsme pos:%d, len:%d, data:%s \
         \n---------------- ESME Hex Dump  ------------------- \
         ", m_EsmePdu.pos, m_EsmePdu.len, tmpStr);
   return true;
}

/*****************************************************************************
 * FUNCTION NAME : SendAll
 * DEFINITION    : Function to handle sending messages
 * ARGUMENTS     :
 * RETURNS       :
 * REMARKS       :
 * **************************************************************************/

//int ESMEClient::SendAll(int &s, char *buf, int len)
int ESMEClient::SendAll(INT32 &s, char *buf, UINT32 &len)
{
   int total = 0;
   int bytesleft = len;
   int n = -1;

   while(total < len)
   {
      if(0 > s)
         return -1;

      n = send(s, buf+total, bytesleft, 0);
      if (n == -1)
      {
         CLOG(0,0,"%s <Ln:%d> send failed with errno: %d.",
               __FUNCTION__, __LINE__, errno);
         break;
      }
      total += n;
      bytesleft -= n;
   }
   return n==-1?-1:len; // return -1 on failure, total bytes  on success
}

/*****************************************************************************
 * FUNCTION NAME : SendMessage 
 * DEFINITION    : Function to handle sending messages
 * ARGUMENTS     : NONE
 * RETURNS       : BOOLEAN
 * REMARKS       :
 * ****************************************************************************/
BOOLEAN ESMEClient::SendMessage()
{
   INT32 number_characters_write;

   DLOG(0,0,"%s <Ln:%d> Writing into Socket[FD:%d, m_EsmePdu.len:%d]",
         __FUNCTION__, __LINE__, m_ClientSocket, m_EsmePdu.len);

   if(m_EsmePdu.len > sizeof(m_EsmePdu.data))
   {
      CLOG(0,0,"%s <Ln:%d> Length is higher than Data size [m_EsmePdu.len:%d]",
            __FUNCTION__, __LINE__, m_EsmePdu.len);
      return false;
   }
   SmppInterface::getInstance()->lockSend();

   if (-1 == (number_characters_write = this->SendAll(m_ClientSocket, (char*)m_EsmePdu.data, m_EsmePdu.len)))
   {
      CLOG(0,0,"%s <Ln:%d> Failed to send PDU", __FUNCTION__, __LINE__);
      SmppInterface::getInstance()->unlockSend();
      return false;
   }
   else if (number_characters_write < m_EsmePdu.len)
   {
      CLOG(0,0,"%s <Ln:%d> Complete message not sent [length:%ld]",
            __FUNCTION__, __LINE__, number_characters_write);
      SmppInterface::getInstance()->unlockSend();
      return false;
   }
   SmppInterface::getInstance()->unlockSend();

   if(true == g_ConfigData->m_EsmeConfigData.m_PrintPdu)
   {
      char l_data[5000+1];
      memset(l_data, '\0', 5000+1);

      char l_temp[5000+1];
      memset(l_temp, '\0', 5000+1);

      struct tm *l_timeStruct=NULL;
      char *l_dateString=NULL;
      time_t l_tim =time(NULL);
      l_timeStruct = localtime(&l_tim);
      l_dateString = asctime(l_timeStruct);
      l_dateString[24] = 0;
      
      memset(l_temp, '\0', 5000+1);
      strcpy(l_temp, " ");
      strlcat(l_data, l_temp, 5000);

      memset(l_temp, '\0', 5000+1);
      sprintf(l_temp, "\n\n<<===  SEQ NO [ %d ]  [ %s ]", m_ESMEData.sequence_number, ConvertESMEOperationToString((enum ESME_OPERATION)m_ESMEData.command_id));
      strlcat(l_data, l_temp, 5000);

      memset(l_temp, '\0', 5000+1);
      sprintf(l_temp, "\n\t---%s---",l_dateString);
      strlcat(l_data, l_temp, 5000);

      memset(l_temp, '\0', 5000+1);
      sprintf(l_temp, "\n\tLen    : %d", m_EsmePdu.len);
      strlcat(l_data, l_temp, 5000);

      memset(l_temp, '\0', 5000+1);
      sprintf(l_temp, "\n\tStatus : %s", getStatusChar((SMPP_ERROR_MESSAGES)m_ESMEData.command_status));
      strlcat(l_data, l_temp, 5000);

      memset(l_temp, '\0', 5000+1);
      sprintf(l_temp, "\n\tData   : ");
      strlcat(l_data, l_temp, 5000);

      for(int j=0; j<number_characters_write;j++)
      {
         memset(l_temp, '\0', 10);
         sprintf(l_temp, " %02x",(UINT8) m_EsmePdu.data[j]);
         strlcat(l_data, l_temp, 5000);
      }
      memset(l_temp, '\0', 5000+1);
      sprintf(l_temp, "\n\t------------------------------\n\n");
      strlcat(l_data, l_temp, 5000);

      //printf("%s", l_data);
      LLOG(0,0,"%s", l_data);
   }

   DLOG(0,0,"%s <Ln:%d> Sending Message to SMPP ",__FUNCTION__, __LINE__);

   this->PrintPdu();

   DLOG(0,0,"%s <Ln:%d> Successfully sent the message", __FUNCTION__, __LINE__);

   return true;
}

/*****************************************************************************
 * FUNCTION NAME : RecvAll
 * DEFINITION    : Function to hnadle Reading messages
 * ARGUMENTS     :
 * RETURNS       :
 * REMARKS       :
 * ****************************************************************************/

int ESMEClient::RecvAll(INT32 &s, TEXT *buf, UINT32 len)
{
   int total = 0;
   int bytesleft = len;
   int n;
   while(total < len)
   {
      if(0>s)
         return -1;

      n = recv(s, buf+total, bytesleft,0);
      if (n <= 0)
      {
         if(EINTR == errno)
         {
            WLOG(0,0,"%s <Ln:%d> recv failed with errno set to EINTR.",
                  __FUNCTION__, __LINE__);
            continue;
         }
         CLOG(0,0,"%s <Ln:%d> recv failed with errno: %d.",
               __FUNCTION__, __LINE__, errno);
         //close(s); //Closing at ReadMessage Failure
         return n;
      }
      DLOG(0,0,"revcived bytes %d and bytes left %d and len %d\n",n,bytesleft,len);
      total += n;
      bytesleft -= n;
   }
   len = total; // return number actually sent here
   return len;
}

/*****************************************************************************
 * FUNCTION NAME : ReadMessage 
 * DEFINITION    : Function to hnadle Reading messages
 * ARGUMENTS     : NONE
 * RETURNS       : BOOLEAN
 * REMARKS       :
 * ****************************************************************************/
BOOLEAN ESMEClient::ReadMessage()
{
   INT32 number_characters_read = 0;

   memset(&m_EsmePdu, 0, sizeof(m_EsmePdu));

   //number_characters_read = read (m_ClientSocket, &m_EsmePdu.data, MAX_ESME_PDU_LEN);
   number_characters_read = this->RecvAll(m_ClientSocket, (char*)m_EsmePdu.data, 4);

   if (number_characters_read <= 0)
   {
      CLOG(0,0,"%s <Ln:%d> Error reading Message from Socket[SockFD:%ld, ErrMsg:%s]",
            __FUNCTION__, __LINE__, m_ClientSocket, strerror(errno));
      return false;
   }

   UINT32 l_RcvLen = 0;
   for (INT32 l_Index = 0; l_Index < 4; ++l_Index)
      l_RcvLen = (l_RcvLen << 8) | (UINT8) m_EsmePdu.data[l_Index];

   DLOG(0,0,"%s <Ln:%d> Length of PDU [%d]", __FUNCTION__, __LINE__,l_RcvLen);

   if(l_RcvLen > sizeof(m_EsmePdu.data))
   {
      CLOG(0,0,"%s <Ln:%d> Length is higher than data size [l_RcvLen:%d]",
            __FUNCTION__, __LINE__,l_RcvLen);
      return true;
   }

   number_characters_read = this->RecvAll(m_ClientSocket, (char*)m_EsmePdu.data+4, l_RcvLen-4);

   if (number_characters_read <= 0)
   {
      CLOG(0,0,"%s <Ln:%d> Error reading Message from Socket[SockFD:%ld, ErrMsg:%s]",
            __FUNCTION__, __LINE__, m_ClientSocket, strerror(errno));
      return false;
   }

   m_EsmePdu.len = l_RcvLen;
   m_EsmePdu.pos = 0; // Re-Initialize the position

   DLOG(0,0,"%s <Ln:%d> Successfully read a request", __FUNCTION__, __LINE__);

   DLOG(0,0,"%s <Ln:%d> Message from SMPP ",
         __FUNCTION__, __LINE__);

   this->PrintPdu();
   this->DecodeHeader();

   if(m_RespMsg->command_length<MIN_ESME_PDU_LEN)
   {
      CLOG(0,0,"%s <Ln:%d> Message Received with Invalid Command Length [len:%d]. Dropping 1 message.", 
            __FUNCTION__, __LINE__, m_RespMsg->command_length);
      return true;
   }

   if(true == g_ConfigData->m_EsmeConfigData.m_PrintPdu)
   {
      char l_data[5000+1];
      memset(l_data, '\0', 5000+1);

      char l_temp[5000+1];
      memset(l_temp, '\0', 5000+1);

      struct tm *l_timeStruct=NULL;
      char *l_dateString=NULL;
      time_t l_tim =time(NULL);
      l_timeStruct = localtime(&l_tim);
      l_dateString = asctime(l_timeStruct);
      l_dateString[24] = 0;

      strcpy(l_temp, " ");
      strlcat(l_data, l_temp, 5000);

      memset(l_temp, '\0', 5000);
      sprintf(l_temp,"\n===>>  SEQ NO [ %d ]  [ %s ]", m_RespMsg->sequence_number, 
                                               ConvertESMEOperationToString((enum ESME_OPERATION)m_RespMsg->command_id));
      strlcat(l_data, l_temp, 5000);

      memset(l_temp, '\0', 5000);
      sprintf(l_temp,"\n\t---%s---",l_dateString);
      strlcat(l_data, l_temp, 5000);

      memset(l_temp, '\0', 5000);
      sprintf(l_temp,"\n\tLen    : %d", m_EsmePdu.len);
      strlcat(l_data, l_temp, 5000);

      memset(l_temp, '\0', 5000);
      sprintf(l_temp,"\n\tStatus : %s", getStatusChar((SMPP_ERROR_MESSAGES)(m_RespMsg->command_status)));
      strlcat(l_data, l_temp, 5000);

      memset(l_temp, '\0', 5000);
      sprintf(l_temp,"\n\tData   : ");
      strlcat(l_data, l_temp, 5000);

      for(int j=0; j<number_characters_read+4;j++)
      {
         memset(l_temp, '\0', 10);
         sprintf(l_temp," %02x",(UINT8) m_EsmePdu.data[j]);
         strlcat(l_data, l_temp, 5000);
      }

      memset(l_temp, '\0', 5000);
      sprintf(l_temp,"\n\t------------------------------\n\n");
      strlcat(l_data, l_temp, 5000);


      //printf("%s", l_data);
      LLOG(0,0,"%s", l_data);
   }



   switch(m_RespMsg->command_id)
   {
      case BIND_TRANSCEIVER_RESP:
         {
            bool l_status = this->DecodeBindTransceiverResp();
            if (m_RespMsg != NULL)
            {
               delete(m_RespMsg);
               m_RespMsg=NULL;
            }
            return l_status;
         }
         break;

      case ENQUIRE_LINK:
         DLOG(0,0,"%s <Ln:%d> ENQUIRE_LINK Received.",__FUNCTION__, __LINE__);
         this->DecodeHeader();
         break;

      case SUBMIT_SM_RESP:
         this->DecodeSubmitSmResp();
         break;

      case CANCEL_SM_RESP:
         this->DecodeCancelSmResp();
         break;

      case QUERY_SM_RESP:
         this->DecodeQuerySmResp();
         break;

      case REPLACE_SM_RESP:
         this->DecodeReplaceSmResp();
         break;

      case DELIVER_SM:
         this->DecodeDeliverSm();
         break;

      default:
         WLOG(0,0,"%s <Ln:%d> Invalid Message Type[%ld].", __FUNCTION__, __LINE__, m_RespMsg->command_id);
   }

   if (m_RespMsg != NULL)
   {
      SmppInterface::getInstance()->m_recvQ->push(m_RespMsg);
      m_RespMsg=NULL;
   }
   return true;
}

/*****************************************************************************
 * FUNCTION NAME : SignalsHandler
 * DEFINITION    : Function to handle signals
 * ARGUMENTS     : NONE
 * RETURNS       : BOOLEAN
 * REMARKS       :
 * ****************************************************************************/
void SignalsHandler(int lValue)
{
   DLOG(0,0,"%s <Ln:%d> Signal %d received. Closing Connection", __FUNCTION__, __LINE__, lValue);
}

ESMEClient g_ec;
ESMEClient g_ec_decoding;

int g_totalSmppFailedCount=0;

void *rcvThrFunc(void*)
{
   BOOLEAN l_connectionGood=false;
   do
   {
      if (l_connectionGood == false)
      {
         l_connectionGood = SmppInterface::getInstance()->Connect();
         if(false == l_connectionGood)
         {
            CLOG(0,0,"Unable to connect to SMPP Server\n");
            if (0 == g_totalSmppFailedCount++%10)
            {
               g_si.sendSnmpTrap(g_SmscConnectionTrap, TRAP_TYPE_FAIL, TRAP_SEVERITY_CRITICAL);
            }
            sleep(1); //sleeping for a second
         }

      }
      else
      {
         if(false == g_ec_decoding.ReadMessage())
         {
            printf("\nConnection with SMPP Server lost\n");
            CLOG(0,0,"Connection with SMPP Server lost. Closing Socket Fd: %d", ESMEClient::m_ClientSocket);
            if (0 == g_totalSmppFailedCount++%10)
            {
               g_si.sendSnmpTrap(g_SmscConnectionTrap, TRAP_TYPE_FAIL, TRAP_SEVERITY_CRITICAL);
            }
            close(ESMEClient::m_ClientSocket);
            g_SmppConnection = false;
            sleep(1); //sleeping for a second
            l_connectionGood = false;
         }
      }
   }
   while (1);
   return NULL;
}


/*****************************************************************************
 * FUNCTION NAME : Initialize 
 * DEFINITION    : Function to establish Socket connection with SmppServer
 * ARGUMENTS     : NONE
 * RETURNS       : BOOLEAN
 * REMARKS       :
 * ****************************************************************************/
BOOLEAN SmppInterface::Initialize()
{

   /* Handle the Terminate signals */
   memset (&m_sa, 0, sizeof (m_sa));
   m_sa.sa_handler = &SignalsHandler;

   pthread_mutex_init(&seqNoMutex, NULL);

   server = gethostbyname(g_ConfigData->m_EsmeConfigData.m_SMPP_IPAddress);
   m_PortNum = g_ConfigData->m_EsmeConfigData.m_SMPP_Port;

   DLOG(0,0,"%s <Ln:%d> SMPP IP_ADDRESS:%s", __FUNCTION__, __LINE__,
         g_ConfigData->m_EsmeConfigData.m_SMPP_IPAddress);

   DLOG(0,0,"%s <Ln:%d> SMPP PORT_NUMBER:%d",__FUNCTION__, __LINE__, m_PortNum);

   if (server == NULL)
   {
      CLOG(0,0,"%s <Ln:%d> Error, No such Host found Exiting...  ", __FUNCTION__, __LINE__);
      close(ESMEClient::m_ClientSocket);
      return false;
   }

   memset((char *) &serv_addr, 0, sizeof(serv_addr));
   serv_addr.sin_family = AF_INET;

   memcpy((char *)&serv_addr.sin_addr.s_addr, (char *)server->h_addr, server->h_length);
   serv_addr.sin_port = htons(m_PortNum);

   m_recvQ = new MessageQueue(QUEUE_TYPE_NON_BLOCKING, QUEUE_PERSISTENCE_TYPE_NON_PERSISTENT);
   bool l_status = m_recvQ->initialize();
   if (false == l_status)
   {
      printf("\nERROR!! Unable to initialize the RecvQ Queue");
      return false;
   }

   if(0 != pthread_mutex_init(&m_send_mutex, NULL))
   {
      printf("\nUnable to initialize the send mutex");
      return false;
   }

   pthread_t l_thread = pthread_create(&l_thread, NULL, rcvThrFunc, NULL);


   return true;
}

void SmppInterface::lockSend()
{
   pthread_mutex_lock(&m_send_mutex);
}

void SmppInterface::unlockSend()
{
   pthread_mutex_unlock(&m_send_mutex);
}

/*****************************************************************************
 * FUNCTION NAME : Connect 
 * DEFINITION    : Function to handle connection with SmppServer 
 * ARGUMENTS     : NONE
 * RETURNS       : BOOLEAN
 * REMARKS       :
 * ****************************************************************************/
BOOLEAN SmppInterface::Connect()
{
   ESMEClient::m_ClientSocket = socket(AF_INET, SOCK_STREAM, 0);

   if (ESMEClient::m_ClientSocket < 0)
   {
      DLOG(0,0,"%s <Ln:%d> Error Opening Socket Connection Exiting..", __FUNCTION__, __LINE__);
      exitFunc(EXIT_APPLICATION_TYPE_SMPP_CONNECT_FAILED);
   }
   DLOG(0,0,"%s <Ln:%d> Socket created successfully", __FUNCTION__, __LINE__);


   if (0 > connect(ESMEClient::m_ClientSocket,(struct sockaddr *)&serv_addr, sizeof(serv_addr)))
   {
      CLOG(0,0,"%s <Ln:%d> Failed to Connect to SMPP.. Closing Socket Fd:%d [errno:%d, err:%s]", 
            __FUNCTION__, __LINE__, ESMEClient::m_ClientSocket, errno, strerror(errno));
      close(ESMEClient::m_ClientSocket);
      return false;
   }
   DLOG(0,0,"%s <Ln:%d> Connected to SMPPServer succefully.. Socket Fd: %d", __FUNCTION__, __LINE__, ESMEClient::m_ClientSocket);

   ESMEClient l_EsmeClient;

   if (false == (l_EsmeClient.ProcessBindTransceiver()))
   {
      DLOG(0,0,"%s <Ln:%d> Failed to Send BindTransceiver", __FUNCTION__, __LINE__);
      close(ESMEClient::m_ClientSocket);
      return false;
   }   
   return true;
} 

