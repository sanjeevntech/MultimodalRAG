#include<StatisticsInterface.h>
#include<StatisticsGenerator.h>
#include<MplManager.h>
#include<DbActiveObject.h>
#include<MemCachedActiveObject.h>
#include<Logger.h>

extern bool initializeNgStatistics(StatisticsGenerator *p_sg);
extern bool initializeXmlRequestStatistics(StatisticsGenerator *p_sg);

extern int g_DiaDiffTime10;
extern int g_DiaDiffTime5_10;
extern int g_DiaDiffTime1_5;
extern int g_DiaDiffTime05;
extern int g_DiaDiffTime001;
extern int g_DiaDiffTime0102;
extern int g_DiaDiffTime0205;
extern int g_DiaDiffTime051;
extern int g_DiaDiffTime12;
extern int g_DiaDiffTime25;

extern int g_MapDiffTime10;
extern int g_MapDiffTime5_10;
extern int g_MapDiffTime1_5;
extern int g_MapDiffTime05;
extern int g_MapDiffTime0;

HLRStatisticsInitializer* HLRStatisticsInitializer::m_ds=NULL;

HLRStatisticsInitializer::HLRStatisticsInitializer()
{
   LLOG(0,0,"HLRStatisticsInitializer :cons:");
   m_ds=NULL;
}

HLRStatisticsInitializer::~HLRStatisticsInitializer()
{
   LLOG(0,0,"HLRStatisticsInitializer :des:");
}

bool HLRStatisticsInitializer::applicationInitializationCallback(StatisticsGenerator *p_sg)
{
   bool l_status = initializeNgStatistics(p_sg);
   if(false == l_status)
   {
      ELOG(0,0,"initializeNgStatistics failed");
   }
   l_status = initializeXmlRequestStatistics(p_sg);
   if(false == l_status)
   {
      ELOG(0,0,"initializeXmlRequestStatistics failed");
   }
   l_status = g_prov->statisticsCallback(p_sg);
   if(false == l_status)
   {
      ELOG(0,0,"Profiles statisticsCallback callback failed");
      return false;
   }
   return true;
}

bool genLogStatistics(int p_eventIndex)
{
   TLOG(0,0,"genLogStatistics index:%d", p_eventIndex);
   return HLRStatisticsInitializer::logStatistics(p_eventIndex);
}

void StatisticsInterface::logRespondingApplCtxtTotal(int p_applCtxt, int p_version)
{
   LLOG(0,0,"logRespondingApplCtxtTotal ac:%d, ver:%d", p_applCtxt, p_version);
   HLRStatisticsInitializer::logStatistics(g_MplManager.m_si.m_Respondingappls[p_applCtxt].m_TotalCount[p_version-1]);
}
void StatisticsInterface::logRespondingApplCtxtSuccess(int p_applCtxt, int p_version)
{
   LLOG(0,0,"logRespondingApplCtxtSuccess ac:%d, ver:%d", p_applCtxt, p_version);
   HLRStatisticsInitializer::logStatistics(g_MplManager.m_si.m_Respondingappls[p_applCtxt].m_SuccessCount[p_version-1]);
}
void StatisticsInterface::logRespondingOpCodeTotal(int p_opCode, int p_version)
{
   LLOG(0,0,"logRespondingOpCodeTotal op:%d, ver:%d", p_opCode, p_version);
   HLRStatisticsInitializer::logStatistics(g_MplManager.m_si.m_Respondingops[p_opCode].m_TotalCount[p_version-1]);
}
void StatisticsInterface::logRespondingOpCodeSuccess(int p_opCode, int p_version)
{
   LLOG(0,0,"logRespondingOpCodeSuccess op:%d, ver:%d", p_opCode, p_version);
   HLRStatisticsInitializer::logStatistics(g_MplManager.m_si.m_Respondingops[p_opCode].m_SuccessCount[p_version-1]);
}
void StatisticsInterface::logRespondingConversationTotal(int p_convCode, int p_version)
{
   LLOG(0,0,"logRespondingConversationTotal co:%d, ver:%d", p_convCode, p_version);
   HLRStatisticsInitializer::logStatistics(g_MplManager.m_si.m_Respondingcons[p_convCode].m_TotalCount[p_version-1]);
}
void StatisticsInterface::logRespondingConversationSuccess(int p_convCode, int p_version)
{
   LLOG(0,0,"logRespondingConversationSuccess co:%d, ver:%d", p_convCode, p_version);
   HLRStatisticsInitializer::logStatistics(g_MplManager.m_si.m_Respondingcons[p_convCode].m_SuccessCount[p_version-1]);
}


void StatisticsInterface::logInitiatingApplCtxtTotal(int p_applCtxt, int p_version)
{
   LLOG(0,0,"logInitiatingApplCtxtTotal ac:%d, ver:%d", p_applCtxt, p_version);
   HLRStatisticsInitializer::logStatistics(g_MplManager.m_si.m_Initiatingappls[p_applCtxt].m_TotalCount[p_version-1]);
}
void StatisticsInterface::logInitiatingApplCtxtSuccess(int p_applCtxt, int p_version)
{
   LLOG(0,0,"logInitiatingApplCtxtSuccess ac:%d, ver:%d", p_applCtxt, p_version);
   HLRStatisticsInitializer::logStatistics(g_MplManager.m_si.m_Initiatingappls[p_applCtxt].m_SuccessCount[p_version-1]);
}
void StatisticsInterface::logInitiatingOpCodeTotal(int p_opCode, int p_version)
{
   LLOG(0,0,"logInitiatingOpCodeTotal op:%d, ver:%d", p_opCode, p_version);
   HLRStatisticsInitializer::logStatistics(g_MplManager.m_si.m_Initiatingops[p_opCode].m_TotalCount[p_version-1]);
}
void StatisticsInterface::logInitiatingOpCodeSuccess(int p_opCode, int p_version)
{
   LLOG(0,0,"logInitiatingOpCodeSuccess op:%d, ver:%d", p_opCode, p_version);
   HLRStatisticsInitializer::logStatistics(g_MplManager.m_si.m_Initiatingops[p_opCode].m_SuccessCount[p_version-1]);
}
void StatisticsInterface::logInitiatingConversationTotal(int p_convCode, int p_version)
{
   LLOG(0,0,"logInitiatingConversationTotal co:%d, ver:%d", p_convCode, p_version);
   HLRStatisticsInitializer::logStatistics(g_MplManager.m_si.m_Initiatingcons[p_convCode].m_TotalCount[p_version-1]);
}
void StatisticsInterface::logInitiatingConversationSuccess(int p_convCode, int p_version)
{
   LLOG(0,0,"logInitiatingConversationSuccess co:%d, ver:%d", p_convCode, p_version);
   HLRStatisticsInitializer::logStatistics(g_MplManager.m_si.m_Initiatingcons[p_convCode].m_SuccessCount[p_version-1]);
}


void StatisticsInterface::logOpCodeErrorCount(int p_opCode, int p_errorCode)
{
   LLOG(0,0,"logOpCodeErrorCount op:%d, err:%d", p_opCode, p_errorCode);
   map<string,int>::iterator l_iterator;

   char l_string[20+1];
   snprintf(l_string, sizeof(l_string), "%02d:%02d", p_opCode, p_errorCode);

   l_iterator = g_MplManager.m_si.m_opCodeErrorCodeCountsMap.find(l_string);
   if(l_iterator != g_MplManager.m_si.m_opCodeErrorCodeCountsMap.end())
   {
      HLRStatisticsInitializer::logStatistics(l_iterator->second);
   }
   else
   {
      WLOG(0,0,"logOpCodeErrorCount op:%d, err:%d not found in map. So logging in default err code", p_opCode, p_errorCode);
      HLRStatisticsInitializer::logStatistics(g_MplManager.m_si.m_OpCodeErrorCodeCnt[p_opCode]);
   }
   return;
}

void StatisticsInterface::logOpCodeOtherErrorCount(int p_opCode, int p_errorCode)
{
   LLOG(0,0,"logOpCodeOtherErrorCount op:%d, err:%d", p_opCode, p_errorCode);
   HLRStatisticsInitializer::logStatistics(g_MplManager.m_si.m_OpCodeOtherErrorCodeCnts[p_opCode][p_errorCode]);
   return;
}
void StatisticsInterface::logRespondingTcapPrimCount(int p_tcapPrim)
{
   if ( (p_tcapPrim > 0) && (p_tcapPrim < STATS_MAX_TCAP_PRIMITIVES))
   {
      LLOG(0,0,"logRespondingTcapPrimCount prim:%d", p_tcapPrim);
      HLRStatisticsInitializer::logStatistics(g_MplManager.m_si.m_RespondingTcapPrimCount[p_tcapPrim]);
   }
}

void StatisticsInterface::logInitiatingTcapPrimCount(int p_tcapPrim)
{
   if ( (p_tcapPrim > 0) && (p_tcapPrim < STATS_MAX_TCAP_PRIMITIVES))
   {
      LLOG(0,0,"logInitiatingTcapPrimCount prim:%d", p_tcapPrim);
      HLRStatisticsInitializer::logStatistics(g_MplManager.m_si.m_InitiatingTcapPrimCount[p_tcapPrim]);
   }
}

void StatisticsInterface::logDiffTimeStatistics(char *p_dbQuery, struct timeval* p_diffTime, int p_dbIndex)
{
   if(0 == p_diffTime->tv_sec)
   {
      if(100 > p_diffTime->tv_usec)
         HLRStatisticsInitializer::logStatistics(g_act.m_dts[p_dbIndex].m_diffTime_lt_0d00001s);
      else if(100 > p_diffTime->tv_usec)
         HLRStatisticsInitializer::logStatistics(g_act.m_dts[p_dbIndex].m_diffTime_gr_or_equal_0d0007s_and_lt_0d001s);
      else if(200 > p_diffTime->tv_usec)
         HLRStatisticsInitializer::logStatistics(g_act.m_dts[p_dbIndex].m_diffTime_gr_or_equal_0d0001s_and_lt_0d0002s);
      else if(500 > p_diffTime->tv_usec)
         HLRStatisticsInitializer::logStatistics(g_act.m_dts[p_dbIndex].m_diffTime_gr_or_equal_0d0002s_and_lt_0d0005s);
      else if(700 > p_diffTime->tv_usec)
         HLRStatisticsInitializer::logStatistics(g_act.m_dts[p_dbIndex].m_diffTime_gr_or_equal_0d0005s_and_lt_0d0007s);
      else if(1000 > p_diffTime->tv_usec)
         HLRStatisticsInitializer::logStatistics(g_act.m_dts[p_dbIndex].m_diffTime_gr_or_equal_0d0007s_and_lt_0d001s);
      else if(2000 > p_diffTime->tv_usec)
         HLRStatisticsInitializer::logStatistics(g_act.m_dts[p_dbIndex].m_diffTime_gr_or_equal_0d001s_and_lt_0d002s);
      else if(5000 > p_diffTime->tv_usec)
         HLRStatisticsInitializer::logStatistics(g_act.m_dts[p_dbIndex].m_diffTime_gr_or_equal_0d002s_and_lt_0d005s);
      else if(7000 > p_diffTime->tv_usec)
         HLRStatisticsInitializer::logStatistics(g_act.m_dts[p_dbIndex].m_diffTime_gr_or_equal_0d005s_and_lt_0d007s);
      else if(10000 > p_diffTime->tv_usec)
         HLRStatisticsInitializer::logStatistics(g_act.m_dts[p_dbIndex].m_diffTime_gr_or_equal_0d007s_and_lt_0d01s);
      else if(20000 > p_diffTime->tv_usec)
         HLRStatisticsInitializer::logStatistics(g_act.m_dts[p_dbIndex].m_diffTime_gr_or_equal_0d01s_and_lt_0d02s);
      else if(50000 > p_diffTime->tv_usec)
         HLRStatisticsInitializer::logStatistics(g_act.m_dts[p_dbIndex].m_diffTime_gr_or_equal_0d02s_and_lt_0d05s);
      else if(70000 > p_diffTime->tv_usec)
         HLRStatisticsInitializer::logStatistics(g_act.m_dts[p_dbIndex].m_diffTime_gr_or_equal_0d05s_and_lt_0d07s);
      else if(100000 > p_diffTime->tv_usec)
         HLRStatisticsInitializer::logStatistics(g_act.m_dts[p_dbIndex].m_diffTime_gr_or_equal_0d07s_and_lt_0d1s);
      else if(200000 > p_diffTime->tv_usec)
         HLRStatisticsInitializer::logStatistics(g_act.m_dts[p_dbIndex].m_diffTime_gr_or_equal_0d1s_and_lt_0d2s);
      else if(500000 > p_diffTime->tv_usec)
         HLRStatisticsInitializer::logStatistics(g_act.m_dts[p_dbIndex].m_diffTime_gr_or_equal_0d2s_and_lt_0d5s);
      else if(700000 > p_diffTime->tv_usec)
         HLRStatisticsInitializer::logStatistics(g_act.m_dts[p_dbIndex].m_diffTime_gr_or_equal_0d5s_and_lt_0d7s);
      else 
         HLRStatisticsInitializer::logStatistics(g_act.m_dts[p_dbIndex].m_diffTime_gr_or_equal_0d7s_and_lt_1s);
   }
   else if(2 > p_diffTime->tv_sec)
      HLRStatisticsInitializer::logStatistics(g_act.m_dts[p_dbIndex].m_diffTime_gr_or_equal_1s_and_lt_2s);
   else if(5 > p_diffTime->tv_sec)
      HLRStatisticsInitializer::logStatistics(g_act.m_dts[p_dbIndex].m_diffTime_gr_or_equal_2s_and_lt_5s);
   else if(7 > p_diffTime->tv_sec)
      HLRStatisticsInitializer::logStatistics(g_act.m_dts[p_dbIndex].m_diffTime_gr_or_equal_5s_and_lt_7s);
   else if(10 > p_diffTime->tv_sec)
      HLRStatisticsInitializer::logStatistics(g_act.m_dts[p_dbIndex].m_diffTime_gr_or_equal_7s_and_lt_10s);
   else if(20 > p_diffTime->tv_sec)
      HLRStatisticsInitializer::logStatistics(g_act.m_dts[p_dbIndex].m_diffTime_gr_or_equal_10s_and_lt_20s);
   else
      HLRStatisticsInitializer::logStatistics(g_act.m_dts[p_dbIndex].m_diffTime_gr_or_equal_20s);
}

void StatisticsInterface::logMemCacheDiffTimeStatistics(struct timeval* p_diffTime, int p_memcIndex)
{
   if(0 == p_diffTime->tv_sec)
   {
      if(100 > p_diffTime->tv_usec)
         HLRStatisticsInitializer::logStatistics(g_MemcActObj.m_dts[p_memcIndex].m_diffTime_lt_0d00001s);
      else if(100 > p_diffTime->tv_usec)
         HLRStatisticsInitializer::logStatistics(g_MemcActObj.m_dts[p_memcIndex].m_diffTime_gr_or_equal_0d0007s_and_lt_0d001s);
      else if(200 > p_diffTime->tv_usec)
         HLRStatisticsInitializer::logStatistics(g_MemcActObj.m_dts[p_memcIndex].m_diffTime_gr_or_equal_0d0001s_and_lt_0d0002s);
      else if(500 > p_diffTime->tv_usec)
         HLRStatisticsInitializer::logStatistics(g_MemcActObj.m_dts[p_memcIndex].m_diffTime_gr_or_equal_0d0002s_and_lt_0d0005s);
      else if(700 > p_diffTime->tv_usec)
         HLRStatisticsInitializer::logStatistics(g_MemcActObj.m_dts[p_memcIndex].m_diffTime_gr_or_equal_0d0005s_and_lt_0d0007s);
      else if(1000 > p_diffTime->tv_usec)
         HLRStatisticsInitializer::logStatistics(g_MemcActObj.m_dts[p_memcIndex].m_diffTime_gr_or_equal_0d0007s_and_lt_0d001s);
      else if(2000 > p_diffTime->tv_usec)
         HLRStatisticsInitializer::logStatistics(g_MemcActObj.m_dts[p_memcIndex].m_diffTime_gr_or_equal_0d001s_and_lt_0d002s);
      else if(5000 > p_diffTime->tv_usec)
         HLRStatisticsInitializer::logStatistics(g_MemcActObj.m_dts[p_memcIndex].m_diffTime_gr_or_equal_0d002s_and_lt_0d005s);
      else if(7000 > p_diffTime->tv_usec)
         HLRStatisticsInitializer::logStatistics(g_MemcActObj.m_dts[p_memcIndex].m_diffTime_gr_or_equal_0d005s_and_lt_0d007s);
      else if(10000 > p_diffTime->tv_usec)
         HLRStatisticsInitializer::logStatistics(g_MemcActObj.m_dts[p_memcIndex].m_diffTime_gr_or_equal_0d007s_and_lt_0d01s);
      else if(20000 > p_diffTime->tv_usec)
         HLRStatisticsInitializer::logStatistics(g_MemcActObj.m_dts[p_memcIndex].m_diffTime_gr_or_equal_0d01s_and_lt_0d02s);
      else if(50000 > p_diffTime->tv_usec)
         HLRStatisticsInitializer::logStatistics(g_MemcActObj.m_dts[p_memcIndex].m_diffTime_gr_or_equal_0d02s_and_lt_0d05s);
      else if(70000 > p_diffTime->tv_usec)
         HLRStatisticsInitializer::logStatistics(g_MemcActObj.m_dts[p_memcIndex].m_diffTime_gr_or_equal_0d05s_and_lt_0d07s);
      else if(100000 > p_diffTime->tv_usec)
         HLRStatisticsInitializer::logStatistics(g_MemcActObj.m_dts[p_memcIndex].m_diffTime_gr_or_equal_0d07s_and_lt_0d1s);
      else if(200000 > p_diffTime->tv_usec)
         HLRStatisticsInitializer::logStatistics(g_MemcActObj.m_dts[p_memcIndex].m_diffTime_gr_or_equal_0d1s_and_lt_0d2s);
      else if(500000 > p_diffTime->tv_usec)
         HLRStatisticsInitializer::logStatistics(g_MemcActObj.m_dts[p_memcIndex].m_diffTime_gr_or_equal_0d2s_and_lt_0d5s);
      else if(700000 > p_diffTime->tv_usec)
         HLRStatisticsInitializer::logStatistics(g_MemcActObj.m_dts[p_memcIndex].m_diffTime_gr_or_equal_0d5s_and_lt_0d7s);
      else 
         HLRStatisticsInitializer::logStatistics(g_MemcActObj.m_dts[p_memcIndex].m_diffTime_gr_or_equal_0d7s_and_lt_1s);
   }
   else if(2 > p_diffTime->tv_sec)
      HLRStatisticsInitializer::logStatistics(g_MemcActObj.m_dts[p_memcIndex].m_diffTime_gr_or_equal_1s_and_lt_2s);
   else if(5 > p_diffTime->tv_sec)
      HLRStatisticsInitializer::logStatistics(g_MemcActObj.m_dts[p_memcIndex].m_diffTime_gr_or_equal_2s_and_lt_5s);
   else if(7 > p_diffTime->tv_sec)
      HLRStatisticsInitializer::logStatistics(g_MemcActObj.m_dts[p_memcIndex].m_diffTime_gr_or_equal_5s_and_lt_7s);
   else if(10 > p_diffTime->tv_sec)
      HLRStatisticsInitializer::logStatistics(g_MemcActObj.m_dts[p_memcIndex].m_diffTime_gr_or_equal_7s_and_lt_10s);
   else if(20 > p_diffTime->tv_sec)
      HLRStatisticsInitializer::logStatistics(g_MemcActObj.m_dts[p_memcIndex].m_diffTime_gr_or_equal_10s_and_lt_20s);
   else
      HLRStatisticsInitializer::logStatistics(g_MemcActObj.m_dts[p_memcIndex].m_diffTime_gr_or_equal_20s);
}

void StatisticsInterface::DiffTimeStatisticsForDiamMsg(struct timeval* p_diffTime)
{
	LLOG(0,0,"DiffTimeStatistics Called for diameter message");
	if(p_diffTime->tv_sec >= 10)
	{
		HLRStatisticsInitializer::logStatistics(g_DiaDiffTime10);
	}
	else if((p_diffTime->tv_sec >= 5) && (p_diffTime->tv_sec < 10))
	{
		HLRStatisticsInitializer::logStatistics(g_DiaDiffTime5_10);
	}
	else if((p_diffTime->tv_sec >= 1) && (p_diffTime->tv_sec < 5))
	{
		HLRStatisticsInitializer::logStatistics(g_DiaDiffTime1_5);
	}
	else if((p_diffTime->tv_usec >= 500000) && (p_diffTime->tv_sec < 1))
	{
		 HLRStatisticsInitializer::logStatistics(g_DiaDiffTime05);
	}
	else if((p_diffTime->tv_usec >= 200000) && (p_diffTime->tv_usec < 500000))
	{
		 HLRStatisticsInitializer::logStatistics(g_DiaDiffTime25);
	}
	else if((p_diffTime->tv_usec >= 100000) && (p_diffTime->tv_usec < 200000))
	{
		 HLRStatisticsInitializer::logStatistics(g_DiaDiffTime12);
	}
	else if((p_diffTime->tv_usec >= 50000) && (p_diffTime->tv_usec < 100000))
	{
		 HLRStatisticsInitializer::logStatistics(g_DiaDiffTime051);
	}
	else if((p_diffTime->tv_usec >= 20000) && (p_diffTime->tv_usec < 50000))
	{
		 HLRStatisticsInitializer::logStatistics(g_DiaDiffTime0205);
	}
	else if((p_diffTime->tv_usec >= 10000) && (p_diffTime->tv_usec < 20000))
	{
		 HLRStatisticsInitializer::logStatistics(g_DiaDiffTime0102);
	}
	else if((p_diffTime->tv_sec >= 0) && (p_diffTime->tv_usec < 10000))
	{
		 HLRStatisticsInitializer::logStatistics(g_DiaDiffTime001);
	}
}

void StatisticsInterface::DiffTimeStatisticsForMapMsg(struct timeval* p_diffTime)
{
	LLOG(0,0,"DiffTimeStatistics Called for map message");
	if(p_diffTime->tv_sec >= 10)
	{
		HLRStatisticsInitializer::logStatistics(g_MapDiffTime10);
	}
	else if((p_diffTime->tv_sec >= 5) && (p_diffTime->tv_sec < 10))
	{
		HLRStatisticsInitializer::logStatistics(g_MapDiffTime5_10);
	}
	else if((p_diffTime->tv_sec >= 1) && (p_diffTime->tv_sec < 5))
	{
		HLRStatisticsInitializer::logStatistics(g_MapDiffTime1_5);
	}
	else if((p_diffTime->tv_usec >= 500000) && (p_diffTime->tv_sec < 1))
	{
		 HLRStatisticsInitializer::logStatistics(g_MapDiffTime05);
	}
        else
	{
		HLRStatisticsInitializer::logStatistics(g_MapDiffTime0);
	}
}

HLRStatisticsInitializer *HLRStatisticsInitializer::instance()
{
   if(NULL == m_ds)
   {
      m_ds = new HLRStatisticsInitializer;
      return m_ds;
   }
   else
   {
      return m_ds;
   }
};

