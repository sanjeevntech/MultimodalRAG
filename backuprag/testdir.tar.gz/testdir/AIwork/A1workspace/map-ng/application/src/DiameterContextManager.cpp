#include <DiameterContextManager.h>
#include <Logger.h>
#include <ContextBase.h>


DiameterContextManager::DiameterContextManager()
{
   DLOG(0,1,"DiameterContextManager::DiameterContextManager() created");
}


DiameterContextManager::~DiameterContextManager()
{
   DLOG(0,1,"DiameterContextManager::~DiameterContextManager() destroyed");
}

bool DiameterContextManager::initialize()
{
   return true;
}

void DiameterContextManager::print()
{
   DLOG(0,1,"map size: %d", m_map.size());
}

int DiameterContextManager::getSize()
{
   return m_map.size();
}

bool DiameterContextManager::storeContext(string p_sessionId, void *p_msgPtr, EDialogueType p_DialogueType)
{
   // Context To Be Stored - Storing in a map or a hash-map
   map<string, void*>::iterator l_iter;
   l_iter = m_map.find(p_sessionId);
   if(l_iter != m_map.end())
   {
      ELOG(0,1,"Context with SessionId:%d already present", (char*)p_sessionId.c_str());
      return false;
   }

   m_map[p_sessionId]=(void*)p_msgPtr;
   DLOG(0,1,"Store success. Size of Map: %d", m_map.size());
   return true;
}


bool DiameterContextManager::terminate() //This has to be called at shutdown
{
   LLOG(0,1,"DiameterContextManager terminate called");
   map<string, void*>::iterator l_iter;
   for(l_iter=m_map.begin(); l_iter!=m_map.end(); l_iter++)
   {
      //TODO: to do something?
   }
   return true;
}

bool DiameterContextManager::getContext(string p_sessionId, void **p_msgPtr)
{
   // Context To Be Retrieved
   map<string, void*>::iterator l_iter;
   l_iter = m_map.find(p_sessionId);
   if (l_iter == m_map.end())
   {
      TLOG(0,1,"context for %d", (char*)p_sessionId.c_str());
      return false;
   }
   else
   {
      *p_msgPtr = (*l_iter).second;
   }

   return true;
}

bool DiameterContextManager::removeContext(string p_sessionId, EDialogueType p_DialogueType)
{
   // Context To Be Removed
   DLOG(0,1,"Removing Context UserId: %d", (char*)p_sessionId.c_str());

   map<string, void*>::iterator l_iter;
   l_iter = m_map.find(p_sessionId);
   if (l_iter == m_map.end())
   {
      ELOG(0,1,"unable to find [%d] in the map", (char*)p_sessionId.c_str());
      return false;
   }
   else
   {
      m_map.erase(l_iter);
      DLOG(0,1,"removeContext:: Size of Map: %d", m_map.size());
   }
   return true;
}

void DiameterContextManager::getStats(char *p_output)
{
   char l_dp[1000];
   memset(l_dp, '\0', sizeof(l_dp));
   sprintf(p_output, " Diameter Context Map Size\t\t\t: %ld", m_map.size());
   return;
}



