#include <MemCachedQueryMsg.h>
#include <stdio.h>
#include <string.h>
#include <Logger.h>
#include <MemCachedUtilities.h>

MemCachedQueryMsg::MemCachedQueryMsg() 
{
   DLOG(0,1,"MemCachedQueryMsg :cons:");
   m_MemcQueryRes = MEMC_QUERY_RES_UNKNOWN;
   m_MemcErrorCode = -1;
   m_MemcQueryType = MEMC_QUERY_TYPE_UNKNOWN;

   m_memcActivePtr = NULL;
   m_Mcb = NULL;
   memset(m_PriImsi4Distribution,'\0',sizeof(m_PriImsi4Distribution));
   m_MemcPort = 0;
}

MemCachedQueryMsg::~MemCachedQueryMsg()
{
   DLOG(0,1,"MemCachedQueryMsg :des:");
}

bool MemCachedQueryMsg::validateMemcachedContinuity()
{
 DLOG(0,0,"MemCachedQueryMsg:validateMemcachedContinuity called");
 return true;
}

////////////////////////////////////////////////////////////////
