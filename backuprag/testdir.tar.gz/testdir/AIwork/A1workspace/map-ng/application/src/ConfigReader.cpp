#include <ConfigReader.h>
#include <Parser.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <ModuleManager.h>
#include <apiinc.h>
#include <tcap.h>
#include <tcerror.h>
#include <sccp-addr.h>
#include <Logger.h>
#include <Utilities.h>
#include <DbQueryMsg.h>
#include <TdrFillerBase.h>
#include <GlobalData.h>
#include <NgLogOverride.h>
#include <DecDbConnStr.h>
#include <StatisticsInterface.h>
//#include <GUtilThreadHeartBeat.h>

DecDbConnStr g_DecDbConnStr;

#define MAX_MSGS_PER_MODULE  40
#define MAX_VERSIONS_ARR_SIZE 4000
#define MAX_BUFFER_STRING 90000

extern GenUtilLoggerInterface *g_gui;
string g_genLogVal;
AppLogContentModifier *g_alcm = NULL;
AppLogContextProvider *g_alcp = NULL;

char ConfigReader::m_errorDesc[1000];
unsigned char g_protocol;
unsigned char g_globalTitleIndicator;
//extern fptr_sccpcblock g_sccpcblock_fptr;
//extern fptr_sccpsblock g_sccpsblock_fptr;

char g_exitApplType[EXIT_APPLICATION_TYPE_MAXIMUM+1][100+1];

extern int  g_ConfigIndex;
extern int g_firstVal;
map<int, int> g_ApplContextPriority;
CongestionControl g_cc;
int g_DbConnectionTrap=-1;
int g_DbConnectionTrap1=-1;   
int g_DbConnectionTrap2=-1;   
int g_TcapStackConnectionTrap=-1;
int g_DiskFullTrap=-1;
int g_GracefullShutdownTrap=-1;
int g_SmscConnectionTrap=-1;
int g_RtpsConnectionTrap=-1;
int g_DbThreadHangTrap=-1;
int g_ThreadHanged=-1;
int g_DbCongestion=-1;
int g_TransPerSecTrap=-1;
int g_TranslationTrap=-1;
int g_OpCodeApplMismatchTrap=-1;
int g_outOfDialgsTrap = -1;
int g_provRegRequestNotRcvdTrap = -1;
int g_provDeviceUnauthorizedTrap = -1;
int g_DiameterStackConnectionTrap=-1;
int g_CloseNotRecvTrap = -1;
int g_DialoguePoolTRAP = -1;
char g_versionsArr[MAX_VERSIONS_ARR_SIZE+1];
GlobalData *g_spd=NULL;
CommonDataBase *g_prov=NULL;
ConfigData *g_ConfigData=NULL;
OtherConfigData *g_OtherConfigData=NULL;
extern char g_NgVersion[];
extern char g_NgStartDate[];
NgConfigReader *g_cr=NULL;
int g_CurrSubsBase=-1;
extern bool g_DbCongestionStatus;
int g_IMEI_EncrFlag=0;

int g_MaxthresholdLimitTrap=-1;
int g_AcceptNewConnErrTrap = -1;
int g_MaxThreshPercentTrap = -1;

int g_MemcInitializeFailTrap = -1;
int g_MemcServerPushFailureTrap = -1;
int g_MemcSetConnectionFailTrap = -1;
int g_MemcGetConnectionFailTrap = -1;
int g_MemcServerDiffTimeTrap = -1;
int g_MemcqueueThresholdTrap = -1;
int g_InitialDBTpsReachedTrap = -1;
int g_LaterDBTpsReachedTrap = -1;

char *getCongestionControlType(char p_char)
{
   if ('B' == p_char)
   {
      return "BOTH";
   }
   else if ('D' == p_char)
   {
      return "DB REQ QUEUE";
   }
   else if ('T' == p_char)
   {
      return "INC TRANS PER SEC";
   }
   else if ('N' == p_char)
   {
      return "NONE";
   }
   else 
   {
      return "UNKNOWN";
   }
}

void ConfigReader::setConfigName(char *p_config)
{
   m_ConfigFileName = p_config;
}

char *getExitApplTypeChar(EExitAppType p_eat)
{
   return g_exitApplType[p_eat];
}
bool ConfigReader::init()
{
   snprintf(g_exitApplType[EXIT_APPLICATION_TYPE_UNKNOWN]                                 , 100, "UNKNOWN");                                   
   snprintf(g_exitApplType[EXIT_APPLICATION_TYPE_CTRL_SIGNAL_RCVD]                        , 100, "CTRL_SIGNAL_RCVD");                          
   snprintf(g_exitApplType[EXIT_APPLICATION_TYPE_CONFIG_INIT_FAILED]                      , 100, "CONFIG_INIT_FAILED");                        
   snprintf(g_exitApplType[EXIT_APPLICATION_TYPE_MAP_CONSTANTS_INIT_FAILED]               , 100, "MAP_CONSTANTS_INIT_FAILED");                 
   snprintf(g_exitApplType[EXIT_APPLICATION_TYPE_DIAMETER_CONSTANTS_INIT_FAILED]          , 100, "DIAMETER_CONSTANTS_INIT_FAILED");            
   snprintf(g_exitApplType[EXIT_APPLICATION_TYPE_CONFIG_DATA_READING_FAILED]              , 100, "CONFIG_DATA_READING_FAILED");                 
   snprintf(g_exitApplType[EXIT_APPLICATION_TYPE_GUTIL_SNMP_SI_INIT_FAILED]               , 100, "GUTIL_SNMP_SI_INIT_FAILED");                 
   snprintf(g_exitApplType[EXIT_APPLICATION_TYPE_TRACE_LOGGER_INIT_FAILED]                , 100, "TRACE_LOGGER_INIT_FAILED");                  
   snprintf(g_exitApplType[EXIT_APPLICATION_TYPE_LICENCE_INIT_FAILED]                     , 100, "LICENCE_INIT_FAILED");                       
   snprintf(g_exitApplType[EXIT_APPLICATION_TYPE_MAP_SERV_COORD_INIT_FAILED]              , 100, "MAP_SERV_COORD_INIT_FAILED");                
   snprintf(g_exitApplType[EXIT_APPLICATION_TYPE_DB_CHANGE_NOT_INIT_FAILED]               , 100, "DB_CHANGE_NOT_INIT_FAILED");                 
   snprintf(g_exitApplType[EXIT_APPLICATION_TYPE_MML_TOOL_INIT_FAILED]                    , 100, "MML_TOOL_INIT_FAILED");                      
   snprintf(g_exitApplType[EXIT_APPLICATION_TYPE_SMPP_INIT_FAILED]                        , 100, "SMPP_INIT_FAILED");                          
   snprintf(g_exitApplType[EXIT_APPLICATION_TYPE_ASN_CODECS_INIT_FAILED]                  , 100, "ASN_CODECS_INIT_FAILED");                    
   snprintf(g_exitApplType[EXIT_APPLICATION_TYPE_INTER_MODULE_QUEUE_INIT_FAILED]          , 100, "INTER_MODULE_QUEUE_INIT_FAILED");            
   snprintf(g_exitApplType[EXIT_APPLICATION_TYPE_INTER_MODULE2_QUEUE_INIT_FAILED]         , 100, "INTER_MODULE2_QUEUE_INIT_FAILED");           
   snprintf(g_exitApplType[EXIT_APPLICATION_TYPE_OAM_TRANS_LIST_INIT_FAILED]              , 100, "OAM_TRANS_LIST_INIT_FAILED");                
   snprintf(g_exitApplType[EXIT_APPLICATION_TYPE_DIAM_STACK_INIT_FAILED]                  , 100, "DIAM_STACK_INIT_FAILED");                    
   snprintf(g_exitApplType[EXIT_APPLICATION_TYPE_DIAM_STACK_REG_RESPONSE_TIMEOUT]         , 100, "EXIT_APPLICATION_TYPE_DIAM_STACK_REG_RESPONSE_TIMEOUT");                    
   snprintf(g_exitApplType[EXIT_APPLICATION_TYPE_ULTI_STACK_INIT_FAILED]                  , 100, "ULTI_STACK_INIT_FAILED");                    
   snprintf(g_exitApplType[EXIT_APPLICATION_TYPE_LOADING_MODULES_CONFIGURATIONS_FAILED]   , 100, "LOADING_MODULES_CONFIGURATIONS_FAILED");                  
   snprintf(g_exitApplType[EXIT_APPLICATION_TYPE_TDR_INIT_FAILED]                         , 100, "TDR_INIT_FAILED");                           
   snprintf(g_exitApplType[EXIT_APPLICATION_TYPE_CRITICAL_TDR_INIT_FAILED]                , 100, "CRITICAL_TDR_INIT_FAILED");                  
   snprintf(g_exitApplType[EXIT_APPLICATION_TYPE_TIMER_MANAGER_INIT_FAILED]               , 100, "TIMER_MANAGER_INIT_FAILED");                 
   snprintf(g_exitApplType[EXIT_APPLICATION_TYPE_PROV_INTERFACE_INIT_FAILED]              , 100, "PROV_INTERFACE_INIT_FAILED");                
   snprintf(g_exitApplType[EXIT_APPLICATION_TYPE_LOGGERS_INIT_FAILED]                     , 100, "LOGGERS_INIT_FAILED");                       
   snprintf(g_exitApplType[EXIT_APPLICATION_TYPE_UNABLE_TO_GET_DB_CONNECTION]             , 100, "UNABLE_TO_GET_DB_CONNECTION");               
   snprintf(g_exitApplType[EXIT_APPLICATION_TYPE_LOGGER_ARRAY0_IS_NULL]                   , 100, "LOGGER_ARRAY0_IS_NULL");                     
   snprintf(g_exitApplType[EXIT_APPLICATION_TYPE_LOGGER_ARRAY1_IS_NULL]                   , 100, "LOGGER_ARRAY1_IS_NULL");                     
   snprintf(g_exitApplType[EXIT_APPLICATION_TYPE_APPLICATION_IS_GOING_DOWN]               , 100, "APPLICATION_IS_GOING_DOWN");                 
   snprintf(g_exitApplType[EXIT_APPLICATION_TYPE_RTPS_TSC_INIT_FAILED]                    , 100, "RTPS_TSC_INIT_FAILED");                      
   snprintf(g_exitApplType[EXIT_APPLICATION_TYPE_SMPP_CONNECT_FAILED]                     , 100, "SMPP_CONNECT_FAILED");                       
   snprintf(g_exitApplType[EXIT_APPLICATION_TYPE_TSS_INVALID_SOCKET]                      , 100, "TSS_INVALID_SOCKET");                        
   snprintf(g_exitApplType[EXIT_APPLICATION_TYPE_TOOL_INIT_SERVER_FAILED]                 , 100, "TOOL_INIT_SERVER_FAILED");                   
   snprintf(g_exitApplType[EXIT_APPLICATION_TYPE_TOOL_RECEIVED_SHUTDOWN_COMMAND]          , 100, "TOOL_RECEIVED_SHUTDOWN_COMMAND");            
   snprintf(g_exitApplType[EXIT_APPLICATION_TYPE_DIAMETRIQ_CLIENT_ALREADY_REGISTERED_ERROR], 100,"DIAMETRIQ_CLIENT_ALREADY_REGISTERED_ERROR"); 
   snprintf(g_exitApplType[EXIT_APPLICATION_TYPE_MAXIMUM]                                 , 100, "MAXIMUM");   
   snprintf(g_exitApplType[EXIT_APPLICATION_TYPE_UNABLE_TO_INITIALIZE_STATISTICS_GENERATOR],100, "UNABLE_TO_INITIALIZE_STATISTICS_GENERATOR");   
   snprintf(g_exitApplType[EXIT_APPLICATION_TYPE_THB_INITIALIZATION_FAILED]               , 100, "THB_INITIALIZATION_FAILED");   
   snprintf(g_exitApplType[EXIT_APPLICATION_TYPE_THB_I_AM_ALIVE_FAILED]                   , 100, "THB_I_AM_ALIVE_FAILED");   
   snprintf(g_exitApplType[EXIT_APPLICATION_TYPE_MODULES_PROF_LOADING_FAILED]             , 100, "MODULES_PROF_LOADING_FAILED");   
   snprintf(g_exitApplType[EXIT_APPLICATION_TYPE_SUBS_PROFILES_LOADING_TIMEOUT]           , 100, "SUBS_PROFILES_LOADING_TIMEOUT");   
   snprintf(g_exitApplType[EXIT_APPLICATION_TYPE_SMP_RECEIVED_SHUTDOWN_COMMAND]           , 100, "SMP_RECEIVED_SHUTDOWN_COMMAND");            
   snprintf(g_exitApplType[EXIT_APPLICATION_TYPE_SCCP_INIT_FAILED]                        , 100, "SCCP_INIT_FAILED");            

   string xmlFile;

   try
   {
      char l_filepath[200];
      strcpy(l_filepath, (char*)m_ConfigFileName.c_str());

      if(!strcmp(l_filepath, ""))
      {
         printf("\nCONFIGURATION FILE [%s] NOT FOUND\n", l_filepath);
         return false;
      }

      xmlFile = Parser::readXMLFile(l_filepath);

      if (0 == xmlFile.size())
      {
         printf("\nNo Configuration File [%s] found\n", l_filepath);
         return false;
      }

      m_DataString = xmlFile;
      return true;

   }
   catch(...)
   {
      cout<<"[ERROR]: Failed to read from configuration file."<<endl;
      return false;
   }
}

bool ConfigReader::IsString(char *st)
{
   int l_StrLength = strlen(st);

   for(int l_index=0; l_index < l_StrLength; l_index++)
      if (isalpha(st[l_index]))
         return false;

   return true;
}


bool configureTag(char *p_instr,char* p_outstr)
{
   char l_temp[50+1];
   char l_temp1[50+1];
   memset(l_temp,'\0',sizeof(l_temp));
   memset(l_temp1,'\0',sizeof(l_temp1));
   int l_count=0;
   char *l_ptr=NULL;
   while(l_count < strlen(p_instr))
   {
      if(p_instr[l_count] == '>')
      {
         sprintf(l_temp1,"</%s>",l_temp);
         l_ptr =strstr(p_instr,l_temp1);
         if(NULL !=l_ptr)
         {
            strcpy(p_outstr,l_temp);
            return true;
         }
         else
            return false;
      }
      else
      {
         strncpy(l_temp,p_instr+1,l_count);
         l_count =l_count+1;
      }
   }
   return true;
}


bool ConfigReader::readInteger(string parent,
      string child,
      int &ConfigValue,
      int min,
      int max)
{
   string temp = readValue (parent, child);
   //cout << child << " = " << temp << endl;

   /*if (false == IsString((char *)temp.c_str()))
     {
     printf("\nConfiguration Value %s is not found numeric", child.c_str());
     return false;
     }*/


   if (0 == temp.size())
   {
      char l_tag[50+1];
      memset(l_tag, '\0', sizeof(l_tag));

      configureTag((char*)parent.c_str(), l_tag);
      if(NULL != m_errorDesc)
      {
         snprintf(m_errorDesc, sizeof(m_errorDesc), "Configuration Value %s is not found in %s tag", child.c_str(), l_tag);
      }
      ELOG(0,0,"Configuration Value %s is not found in %s tag",child.c_str(),l_tag);
      return false;
   }


   char *l_tempChar = (char*)(temp.c_str());

   for (int l_i=0; l_i<temp.size(); l_i++)
   {
      if ( (l_tempChar[l_i] < '0')  || (l_tempChar[l_i] > '9') )
      {
         if(NULL != m_errorDesc)
         {
            snprintf(m_errorDesc, sizeof(m_errorDesc), "Configuration Value [%s]. Invalid Character [%c]", child.c_str(), l_tempChar[l_i]);
         }
         ELOG(0,0,"Configuration Value [%s]. Invalid Character [%c]",child.c_str(),l_tempChar[l_i]);
         return false;
      }
   }

   ConfigValue  = atoi(temp.c_str());
   if (min > ConfigValue  || max < ConfigValue)
   {
      if(NULL != m_errorDesc)
      {
         snprintf(m_errorDesc, sizeof(m_errorDesc),"Configuration Value of %s should be between %d and %d ", child.c_str(), min, max);
      }
      ELOG(0,0,"Configuration Value of %s should be between %d and %d ",child.c_str(),min, max);
      return false;
   }
   return true;
}


bool ConfigReader::readUnsignedInteger(string parent,
      string child,
      unsigned long int &ConfigValue,
      unsigned int min,
      unsigned int max)
{
   string temp = readValue (parent, child);

   if (0 == temp.size())
   {
      char l_tag[50+1];
      memset(l_tag, '\0', sizeof(l_tag));

      configureTag((char*)parent.c_str(), l_tag);
      if(NULL != m_errorDesc)
      {
         snprintf(m_errorDesc, sizeof(m_errorDesc), "Configuration Value %s is not found in %s tag", child.c_str(), l_tag);
      }
      ELOG(0,0,"Configuration Value %s is not found in %s tag",child.c_str(),l_tag);
      return false;
   }


   char *l_tempChar = (char*)(temp.c_str());

   for (int l_i=0; l_i<temp.size(); l_i++)
   {
      if ( (l_tempChar[l_i] < '0')  || (l_tempChar[l_i] > '9') )
      {
         if(NULL != m_errorDesc)
         {
            snprintf(m_errorDesc, sizeof(m_errorDesc), "Configuration Value [%s]. Invalid Character [%c]", child.c_str(), l_tempChar[l_i]);
         }
         ELOG(0,0,"Configuration Value [%s]. Invalid Character [%c]",child.c_str(),l_tempChar[l_i]);
         return false;
      }
   }

   ConfigValue  = atol(temp.c_str());
   if (min > ConfigValue  || max < ConfigValue)
   {
      if(NULL != m_errorDesc)
      {
         snprintf(m_errorDesc, sizeof(m_errorDesc),"Configuration Value of %s should be between %u and %u ", child.c_str(), min, max);
      }
      ELOG(0,0,"Configuration Value of %s should be between %u and %u ",child.c_str(),min, max);
      return false;
   }
   return true;
}

bool ConfigReader::readString(string  p_parent, string p_child,  char  *p_ConfigValue ,unsigned int p_min, unsigned int p_max)
{
   string temp = readValue (p_parent, p_child);

   if(p_min > temp.size()|| p_max < temp.size())
   {
      if(NULL != m_errorDesc)
      {
         snprintf(m_errorDesc, sizeof(m_errorDesc), "Invalid %s value length. Should be between %d and %d ", p_child.c_str(), p_min, p_max);
      }
      ELOG(0,0,"Invalid %s value length. Should be between %d and %d ",p_child.c_str(), p_min, p_max);
      return false;
   }
   for(int l_i=0; l_i<temp.size(); l_i++)
   {
      if(
            ('(' == temp.at(l_i)) ||
            (')' == temp.at(l_i)) ||
            (';' == temp.at(l_i))
        )
      {
         if(NULL != m_errorDesc)
         {
            snprintf(m_errorDesc, sizeof(m_errorDesc), "Invalid character [%c] found in %s", temp.at(l_i), p_child.c_str());
         }
         ELOG(0,1,"Invalid character [%c] found in %s", temp.at(l_i), p_child.c_str());
         return false;
      }
   }
   strcpy((char *)p_ConfigValue , temp.c_str());
   return true;
}

bool ConfigReader::readString(string  p_parent, string p_child,  string& p_ConfigValue ,unsigned int p_min, unsigned int p_max)
{
   p_ConfigValue = readValue (p_parent, p_child);

   if(p_min > p_ConfigValue.size()|| p_max < p_ConfigValue.size())
   {
      snprintf(m_errorDesc, sizeof(m_errorDesc), "Invalid %s value length. Should be between %d and %d ", p_child.c_str(), p_min, p_max);
      ELOG(0,0,"Invalid %s value length. Should be between %d and %d ",p_child.c_str(), p_min, p_max);
      return false;
   }
   return true;
}


NgConfigReader::NgConfigReader()
{
}

NgConfigReader::~NgConfigReader()
{
   printf("\nNgConfigReader::~NgConfigReader()\n");
}


bool NgConfigReader::readModules()
{
   string l_applTag = readValue(m_DataString, "SUPPORTED_APPL_CTXTS"); 

   if (0 == l_applTag.size())
   {
      printf("\nNo SUPPORTED_APPL_CTXTS present in the Config file");
      return false;
   }

   //printf("\n\nSupported Application Contexts:");


   for (int l_applIndex=1; l_applIndex<=50; l_applIndex++)
   {
      char l_applName[100];
      memset(l_applName, '\0', 100);
      sprintf(l_applName, "AC_%02d", l_applIndex);

      //string l_ctxt = readValue(l_applTag, l_applName);
      string l_ctxt = Parser::getChildString(l_applTag, l_applName);

      //int l_flagInt=-1;

      string l_flag = readValue(l_ctxt, "F");
      if (0 == atoi(l_flag.c_str()))
      {
         continue;
      }

      /*if( false == readInteger(l_ctxt, "F", l_flagInt, 0, 1))
        {
        ELOG(0,1,"Invalid F parameter");
        return false;
        }

        if (0 == l_flagInt)
        {
        continue;
        }*/

      int l_applValueInt=0;

      if( false == readInteger(l_ctxt, "VAL", l_applValueInt, MAP_AC_UNKNOWN, MAP_AC_CODE_MAXIMUM))
      {
         ELOG(0,1,"Invalid F parameter");
         return false;
      }

      if ( (l_applValueInt <= MAP_AC_UNKNOWN) ||
            (l_applValueInt >= MAP_AC_CODE_MAXIMUM))
      {
         printf("\nInvalid Application Context [%d]. Should be between [%d] and [%d] ", l_applValueInt, MAP_AC_UNKNOWN+1, MAP_AC_CODE_MAXIMUM-1);
         return false;
      }

      g_ConfigData->i_NgConfigData.m_ApplSupportedMap[l_applValueInt] = true;


      int l_applMinPossible = MapConstants::getMapApplCtxtMinVersion((EMapApplicationContext)l_applValueInt);
      int l_applMaxPossible = MapConstants::getMapApplCtxtMaxVersion((EMapApplicationContext)l_applValueInt);


      string l_versions_min = readValue(l_ctxt, "MIN_VER");

      if (0 == l_versions_min.size())
      {
         printf("\nMIN_VERSION tag is missing for APPL CTXT");
         return false;
      }

      if ( (atoi(l_versions_min.c_str()) < l_applMinPossible) ||
            (atoi(l_versions_min.c_str()) > l_applMaxPossible) )
      {
         printf("\nFor Appl Context [%d], Min Version [%d] should be between [%d] and [%d] ", 
               l_applValueInt,
               atoi(l_versions_min.c_str()),
               l_applMinPossible,
               l_applMaxPossible);
         return false;
      }


      //printf("\nVersions [%d]", atoi(l_versions.c_str()));

      g_ConfigData->i_NgConfigData.m_ApplSupportedMinVersion[l_applValueInt] = atoi(l_versions_min.c_str());


      string l_versions = readValue(l_ctxt, "MAX_VER");

      if (0 == l_versions.size())
      {
         printf("\nMAX_VERSION tag is missing for APPL CTXT");
         return false;
      }

      if ( (atoi(l_versions.c_str()) < l_applMinPossible) ||
            (atoi(l_versions.c_str()) > l_applMaxPossible) )
      {
         printf("\nFor Appl Context [%d], Max Version [%d] should be between [%d] and [%d]", 
               l_applValueInt,
               atoi(l_versions.c_str()),
               l_applMinPossible,
               l_applMaxPossible);
         return false;
      }


      //printf("\nVersions [%d]", atoi(l_versions.c_str()));

      g_ConfigData->i_NgConfigData.m_ApplSupportedMaxVersion[l_applValueInt] = atoi(l_versions.c_str());

      if (g_ConfigData->i_NgConfigData.m_ApplSupportedMinVersion[l_applValueInt] > 
            g_ConfigData->i_NgConfigData.m_ApplSupportedMaxVersion[l_applValueInt])
      {
         printf("\nMIN_VERSION [%d] cannot be greater than MAX_VERSION [%d] for Appl Ctxt [%d]", 
               g_ConfigData->i_NgConfigData.m_ApplSupportedMinVersion[l_applValueInt],
               g_ConfigData->i_NgConfigData.m_ApplSupportedMaxVersion[l_applValueInt],
               l_applValueInt);
         return false;
      }

      if ('N' != g_cc.m_controlType[0])
      {
         if( false == readInteger(l_ctxt, "PRIORITY", g_ApplContextPriority[l_applValueInt], 1, 5))
         {
            printf("\nPRIORITY not present for ApplCtxt: %d", l_applValueInt);
            return false;
         }
      }




      /*printf("\n  ApplCtxt [%d] MinVer [%d] MaxVer [%d]", 
        l_applValueInt, 
        g_ConfigData->i_NgConfigData.m_ApplSupportedMinVersion[atoi(l_appl.c_str())],
        g_ConfigData->i_NgConfigData.m_ApplSupportedMaxVersion[atoi(l_appl.c_str())]);*/
   }



   string temp1 = readValue(m_DataString, "MODULES");
   bool l_ErrorsPresentFlag = false; 

   //printf("\n\nInitializing Modules ...");


   memset(g_versionsArr, '\0', MAX_VERSIONS_ARR_SIZE);
   sprintf(g_versionsArr, "\n\t\t\t %-30s   %s", "mapNG", g_NgVersion);
   for (int l_i=1; l_i<=MAX_MODULES; l_i++)
   {

      char l_moduleName[100];
      memset(l_moduleName, '\0', 100);
      sprintf(l_moduleName, "MODULE_%02d", l_i);
      //string l_module = readValue(temp1, l_moduleName);
      string l_module = Parser::getChildString(temp1, l_moduleName);

      if (l_module.size() == 0)
      {
         break;
      }

      string l_moduleEnabledFlag = readValue(l_module, "F");

      string l_moduleTextName = readValue(l_module, "NAME");

      printf("\n  %s: %s  ", l_moduleName, l_moduleTextName.c_str());

      if ('1' != l_moduleEnabledFlag.c_str()[0])
      {
         printf("Ignored");
         continue;
      }
      else
      {
         printf("Loading..");
      }



      string l_libraryName = readValue(l_module, "LIB");

      if ( (l_libraryName.size() > 40) || (l_libraryName.size() < 5))
      {
         printf("\nERROR!!! Library Name Size should be between 5 and 40 [%s]", l_libraryName.c_str());
         return false;
      }


      string l_func = "getModuleObj";
      EDllResult l_result;
      char l_error[1000];
      memset(l_error, '\0', 1000);

      fptr_mod l_funcPtr = g_mm.getContextFptr_mod(l_libraryName.c_str(), l_func.c_str(), &l_result, l_error);

      if (l_funcPtr == NULL)
      {
         printf("\n  [%s] [%s]", l_libraryName.c_str(), l_func.c_str());
         l_ErrorsPresentFlag = true;
         switch (l_result)
         {
            case DLL_RESULT_DLL_NOT_FOUND:
               printf("     : LIBRARY LOADING FAILED");
               printf("\n\n Library Loading Error :: [%s]", l_error);
               break;

            case DLL_RESULT_FUNC_NOT_FOUND:
               printf("     : FUNCTION NOT LOCATED");
               printf("\n\n Function Locating Error :: [%s]", l_error);
               break;

            default:
               printf("     : NOT LOCATED");
               break;
         }

      }

      if (l_ErrorsPresentFlag)
      {
         printf("\nERROR!! There are errors in the modules configuration file.");
         return false;
      }

      //Update the module list

      snprintf(g_mm.m_modules[l_i].m_ModName, sizeof(g_mm.m_modules[l_i].m_ModName), l_moduleTextName.c_str());
      snprintf(g_mm.m_modules[l_i].m_LibName, sizeof(g_mm.m_modules[l_i].m_LibName), l_libraryName.c_str());
      g_mm.m_modules[l_i].m_loadedTime = time(NULL); //Module Loaded time

      if (strlen(g_mm.m_modules[l_i].m_LibName)>0)
      {
         g_mm.m_modules[l_i].m_func = l_funcPtr;
      }

      //End of updation of module list

      {// Code for reading the versions of the modules

         char l_tempChar[200];
         memset(l_tempChar, '\0', 200);
         sprintf(l_tempChar, "\n\t\t\t %-30s   %s", l_libraryName.c_str(), l_funcPtr()->getVersion());
         strlcat(g_versionsArr, l_tempChar, MAX_VERSIONS_ARR_SIZE);

      }// End of code for reading the versions of the modules



#if 1
      { // Code for Configuration files reading

         string l_config_reader = readValue(l_module, "CONF");
         string l_flag = readValue(l_config_reader, "F");
         if(l_moduleTextName == "SCS")
         {
            if(1 == atoi(l_moduleEnabledFlag.c_str()))
            {
               if(0 == atoi(l_flag.c_str()))
               {
                  printf("\nERROR!! CONF flag Tag is not enabled in SCS module");
                  return false;
               }
            }
         }
         if (atoi(l_flag.c_str()))
         {
            g_mm.m_modules[l_i].m_configPresent=true;

            /*
               string l_file = readValue(l_config_reader, "FILE");

            //printf("     : LOCATED");
            ConfigReader *l_cr = NULL;
            l_cr = l_funcPtr()->getConfigReaderObj();
            if (l_cr != NULL)
            {
            l_cr->setConfigName((char*)(l_file.c_str()));

            bool l_status = l_cr->init();
            if (!l_status)
            {
            printf("\nERROR!! Initialization of Configuration file [%s] failed", l_file.c_str());
            return false;
            }

            //printf("\nReading Data");
            l_status = l_cr->readData();
            if (!l_status)
            {
            printf("\nERROR!! Reading Data of Configuration file [%s] failed", l_file.c_str());
            return false;
            }

            l_cr->m_lastUpdateDate = time(NULL);

            char test[2000];
            memset(test, '\0', 2000);
            ((NgConfigReader*)l_cr)->printConfigData(test);

            g_mm.m_modules[l_i].m_configPresent=true;
            g_mm.m_modules[l_i].m_cr = l_cr;
            strcpy(g_mm.m_modules[l_i].m_file, (char*)(l_file.c_str()));
            }
            */

         }
      }// Code for Configuration files reading
#endif


      { // Code for Module Initialization Function

         bool l_status = l_funcPtr()->initModule();
         if (l_status == false)
         {
            printf("\nUnable to initialize the module: %s - %s\n", l_moduleName, l_moduleTextName.c_str());
            return false;
         }
         g_mm.m_modules[l_i].m_moduleOverridedName = l_funcPtr()->m_modName;

      }// Code for Module Initialization Function





      string l_messages_supported = readValue(l_module, "SUPPORTED_OP_CODES");



      for (int l_j=1; l_j<=MAX_MSGS_PER_MODULE; l_j++)
      {

         char l_messageName[30];
         memset(l_messageName, '\0', 30);
         sprintf(l_messageName, "MSG_%02d", l_j);

         //string l_message = readValue(l_module, l_messageName);
         string l_message = Parser::getChildString(l_module, l_messageName);

         if (l_message.size() == 0)
         {
            break;
         }

         string l_flag = readValue(l_message, "F");
         if(0 == atoi(l_flag.c_str()))
         {
            DLOG(0,1,"Ignoring %s", l_messageName);
            continue;
         }



         //printf("\nMessage [%s]", (char*)l_message.c_str());
         string l_protocol = readValue(l_message, "PR");
         if( ( 0 != strcmp((char*)l_protocol.c_str(), "MAP")) && ( 0 != strcmp((char*)l_protocol.c_str(), "DIA")) && ( 0 != strcmp((char*)l_protocol.c_str(), "SCCP")))
         {
            printf("\nPR should be either MAP or DIA or SCCP[%s]", (char*)l_protocol.c_str());
            return false;
         }

         EMsgType l_msgType;
         if( 0 == strcmp((char*)l_protocol.c_str(), "MAP"))
         {
            l_msgType=MSG_TYPE_MAP;
         }
         else if( 0 == strcmp((char*)l_protocol.c_str(), "DIA"))
         {
            l_msgType=MSG_TYPE_DIAMETER;
         }
         else if( 0 == strcmp((char*)l_protocol.c_str(), "SCCP"))
         {
            l_msgType=MSG_TYPE_SCCP;
         }

         string l_opcode = readValue(l_message, "OP");
         //printf("\nOpCode [%s]", l_opcode.c_str());

         int l_opcodeInt = atoi(l_opcode.c_str());
         LLOG(0,0,"Processing op code %d", l_opcodeInt);
         int l_opcodeIndex = l_opcodeInt;
         if(MSG_TYPE_MAP == l_msgType)
         {
            if ( (l_opcodeInt< (MAP_OP_CODE_UNKNOWN+1) ) || (l_opcodeInt>(MAP_OP_CODE_MAXIMUM)) )
            {
               printf("\nOpcode [%d] should be between %d and %d", l_opcodeInt, (MAP_OP_CODE_UNKNOWN+1), (MAP_OP_CODE_MAXIMUM));
               return false;
            }

            if ((l_opcodeInt!= 1) && (l_opcodeInt!= 90)&& (false == MapConstants::isMapOpCodeValid((EMapOpCode)l_opcodeInt)))
            {
               printf("\nOpcode [%d] is not a valid MAP OpCode", l_opcodeInt);
               return false;
            }
         }
         else if(MSG_TYPE_DIAMETER == l_msgType)
         {
            if(8388622 == l_opcodeInt)
            {
               LLOG(0,0,"Updating OpCodeIndex to 350");
               l_opcodeIndex=350; //TODO: Little silly, but lets live
            }
         }
         //Adding code to support appl ctxt and opcode based routing

         if (strlen(g_mm.m_mapping[l_msgType][l_opcodeIndex].m_ModName) > 0)
         {
            LLOG(0,1,"Op Code %d OpCodeIndex: %d already configured for module %s", l_opcodeInt, l_opcodeIndex, g_mm.m_mapping[l_msgType][l_opcodeInt].m_ModName);
            l_opcodeIndex+=100;

            if (strlen(g_mm.m_mapping[l_msgType][l_opcodeIndex].m_ModName) > 0)
            {
               LLOG(0,1,"Even Op Code %d OpCodeIndex: %d already configured for module %s", l_opcodeInt, l_opcodeIndex, g_mm.m_mapping[l_msgType][l_opcodeIndex].m_ModName);
               return false;
            }
         }


         //End of Adding code to support appl ctxt and opcode based routing

         string l_messageTextName = readValue(l_message, "NAME");


         string l_versions = readValue(l_message, "VERS");
         if ( (l_versions.size() != 3))
         {
            printf("\nERROR!!! VERSIONS tag should have info for all the 3 MAP versions");
            return false;
         }
         if(MSG_TYPE_MAP == l_msgType)
         {

            //printf("\nVersions flags [%s]", l_versions.c_str());

            char l_versionsChar[4];
            memset(l_versionsChar, '\0', 4);
            memcpy(l_versionsChar, l_versions.c_str(), 3);

            if ( (l_versionsChar[0] != '0') && (l_versionsChar[0] != '1') )
            {
               printf("\nVERSIONS_FLAGS for MAP1 cannot be [%c]", l_versionsChar[0]);
               return false;
            }
            g_mm.m_mapping[l_msgType][l_opcodeIndex].m_OpCode = l_opcodeInt;
            g_mm.m_mapping[l_msgType][l_opcodeIndex].m_Map1Flag = l_versionsChar[0]=='0'?false:true;

            if ( (l_versionsChar[1] != '0') && (l_versionsChar[1] != '1') )
            {
               printf("\nVERSIONS_FLAGS for MAP2 cannot be [%c]", l_versionsChar[1]);
               return false;
            }
            g_mm.m_mapping[l_msgType][l_opcodeIndex].m_Map2Flag = l_versionsChar[1]=='0'?false:true;

            if ( (l_versionsChar[2] != '0') && (l_versionsChar[2] != '1') )
            {
               printf("\nVERSIONS_FLAGS for MAP3 cannot be [%c]", l_versionsChar[2]);
               return false;
            }
            g_mm.m_mapping[l_msgType][l_opcodeIndex].m_Map3Flag = l_versionsChar[2]=='0'?false:true;


            // OP code and version validity check
            if (
                  (l_versionsChar[0] == '1')  && 
                  (MapConstants::getMapOpCodeArgPDU( ((EMapOpCode)l_opcodeInt), MAP_V1 ) == 0)
               )
            {
               printf("\n\n\tOp Code [%d] not valid for MAP v1\n", l_opcodeInt);
               return false;
            }

            if (
                  (l_versionsChar[1] == '1')  && 
                  (MapConstants::getMapOpCodeArgPDU( ((EMapOpCode)l_opcodeInt), MAP_V2 ) == 0)
               )
            {
               printf("\n\n\tOp Code [%d] not valid for MAP v2\n", l_opcodeInt);
               return false;
            }

            if (
                  (l_versionsChar[2] == '1')  && 
                  (MapConstants::getMapOpCodeArgPDU( ((EMapOpCode)l_opcodeInt), MAP_V3 ) == 0)
               )
            {
               printf("\n\n\tOp Code [%d] not valid for MAP v3\n", l_opcodeInt);
               return false;
            }
         }
         else if(MSG_TYPE_DIAMETER == l_msgType)
         {
            g_mm.m_mapping[l_msgType][l_opcodeIndex].m_OpCode = l_opcodeInt;
         }
         else if(MSG_TYPE_SCCP == l_msgType)
         {
            g_mm.m_mapping[l_msgType][l_opcodeIndex].m_OpCode = l_opcodeInt;
            LLOG(0,0,"updated sccp msg type in g_mm.m_mapping");
         }
         // End of OP code and version validity check

         // Reading whether TDR required for the opcode

         if( false == readInteger(l_message, "TDR", g_mm.m_mapping[l_msgType][l_opcodeIndex].m_tdrRequiredFlag, 0, 1))
         {
            printf("\nTDR tag should be set with 0 or 1");
            return false;
         }
         //g_mm.m_mapping[MSG_TYPE_DIAMETER][308].m_tdrRequiredFlag = 1;

         // End of reading whether TDR required for the opcode


         LLOG(0,0,"updating map for op code %d", l_opcodeInt);
         TLOG(0,0,"Adding Type[%d], Op[%d]", l_msgType, l_opcodeIndex);
         snprintf(g_mm.m_mapping[l_msgType][l_opcodeIndex].m_ModName, sizeof(g_mm.m_mapping[l_msgType][l_opcodeIndex].m_ModName), l_moduleTextName.c_str());
         snprintf(g_mm.m_mapping[l_msgType][l_opcodeIndex].m_MessageName,sizeof(g_mm.m_mapping[l_msgType][l_opcodeIndex].m_MessageName), l_messageTextName.c_str());
         snprintf(g_mm.m_mapping[l_msgType][l_opcodeIndex].m_LibName, sizeof(g_mm.m_mapping[l_msgType][l_opcodeIndex].m_LibName), l_libraryName.c_str());
         snprintf(g_mm.m_mapping[l_msgType][l_opcodeIndex].m_FuncName, sizeof(g_mm.m_mapping[l_msgType][l_opcodeIndex].m_FuncName), l_func.c_str());
         g_mm.m_mapping[l_msgType][l_opcodeIndex].m_loadedTime = time(NULL); //Added OP Code/Module Loaded time

         if (strlen(g_mm.m_mapping[l_msgType][l_opcodeIndex].m_LibName)>0)
         {
            g_mm.m_mapping[l_msgType][l_opcodeIndex].m_func = l_funcPtr;
         }
      }

   }


   if (1 == g_ConfigData->i_DbConfigData.m_DbRequired)
   {
      //HLR specific
      if(0 == strlen(g_mm.m_mapping[MSG_TYPE_MAP][89].m_MessageName))
      {
         printf("\nProblem in configuration. code 89 not found\n");
         return false;
      }
      //End of HLR specific
   }
   else
   {
      g_firstVal=1;
   }

   return true;
}


int g_InitialLogMedia=0;

void getIpAddress(char *p_ipAddress)
{
   int x = 16;
   char * str = NULL;
   struct hostent * hent = NULL;

   char l_name[51];
   memset(l_name, '\0', 51);
   gethostname(l_name, 50);

   hent = gethostbyname(l_name);
   str = hent -> h_addr_list[0];

   x = (*str < 0) ? (256 + *str) : *str;
   sprintf(p_ipAddress, "%d",x); str++;
   x = (*str < 0) ? (256 + *str) : *str;
   sprintf(p_ipAddress, "%s.%d",p_ipAddress, x); str++;
   x = (*str < 0) ? (256 + *str) : *str;
   sprintf(p_ipAddress, "%s.%d",p_ipAddress, x); str++;
   x = (*str < 0) ? (256 + *str) : *str;
   sprintf(p_ipAddress, "%s.%d%c",p_ipAddress, x, 0x00);

   return;
}

bool NgConfigReader::readData()
{
   //printf("\nInitialized Modules.\n");

   getIpAddress(g_selfIpAddress);
   string temp;

   /* Logging related*/

   string logger=Parser::getChildString(m_DataString,"LOGGER");
   if (0 == logger.size())
   {
      printf("\nLOGGER tag is not found\n");
      return false;
   }
   temp = readValue(logger, "LOGGING_MODEL");
   if(1 == temp.size())
   {
      switch(temp[0])
      {
         case LOG_MODEL_APPLICATION:
         case LOG_MODEL_GEN_UTIL:
            g_ConfigData->m_LogModel = temp[0];
            break;

         default:
            printf("\nUnsupported LOGGING_MODEL. Should be either of  A-Application specific logging model,  G-Generic Utilities logging model defined by GEN_UTIL_LOGGER_CONFIG parameter \n");
            break;
      }
   }
   else
   {
      printf("\nInvalid Logging Model: %s", temp.c_str());
      return false;
   }

   if(LOG_MODEL_APPLICATION == g_ConfigData->m_LogModel)    
   {                                                        
      printf("\nLogging Model: Application\n\n");              

      temp = readValue(logger, "LOG_LEVEL");
      if (1 == temp.size())
      {
         char tempChar = temp[0];
         switch (tempChar)
         {
            case 'D':
            case 'd':
               g_ConfigData->m_LogLevel = LOG_LEVEL_DEBUG;
               break;

            case 'T':
            case 't':
               g_ConfigData->m_LogLevel = LOG_LEVEL_TRACE;
               break;

            case 'L':
            case 'l':
               g_ConfigData->m_LogLevel = LOG_LEVEL_LOAD;
               break;

            case 'W':
            case 'w':
               g_ConfigData->m_LogLevel = LOG_LEVEL_WARNING;
               break;

            case 'C':
            case 'c':
               g_ConfigData->m_LogLevel = LOG_LEVEL_CRITICAL;
               break;

            case 'E':
            case 'e':
               g_ConfigData->m_LogLevel = LOG_LEVEL_ERROR;
               break;

            default:
               printf("\nInvalid Log Level Type: It should be either of D, T, W, C or E");
               return false;
               break;
         }
      }
      else
      {
         printf("\nInvalid Log Level: %s", temp.c_str());
         return false;
      }

      temp = readValue(logger, "LOG_MEDIA");
      if (1 == temp.size())
      {
         char tempChar = temp[0];
         switch (tempChar)
         {
            case 'C':
            case 'c':
               g_ConfigData->m_LogMedia = LOG_MEDIA_CONSOLE;
               break;

            case 'F':
            case 'f':
               {
                  g_ConfigData->m_LogMedia = LOG_MEDIA_FILE;

                  string l_LOG_WRITING_MECHANISM;
                  l_LOG_WRITING_MECHANISM =  readValue(logger, "LOG_FILE_WRITING_MODE");

                  if (1 == l_LOG_WRITING_MECHANISM.size())
                  {
                     char l_tempchar  = l_LOG_WRITING_MECHANISM[0];
                     switch (l_tempchar)
                     {
                        case 'N':
                           {
                              g_OtherConfigData->m_LogFileRotatingType = 0;
                              if( false == readInteger(logger, "LOG_ROTATE_MAX_FILES", 
                                       g_OtherConfigData->m_LogFileMaxFiles, 10, 999999))
                              {
                                 printf("\nLog Rotate Max files is not configured");
                              }
                           }
                           break;

                        case 'R':
                           {
                              g_OtherConfigData->m_LogFileRotatingType = 1;
                              if( false == readInteger(logger, "LOG_ROTATE_MAX_FILES", 
                                       g_OtherConfigData->m_LogFileMaxFiles, 10, 999999))
                              {
                                 printf("\nLog Rotate Max files should be between 10 and 999999");
                                 return false;
                              }
                           }
                           break;

                        default:
                           {
                              printf("\nLOG_FILE_WRITING_MODE should be either N or R");
                              return false;
                           }
                           break;
                     }
                  }
                  else
                  {
                     printf("\nLOG_FILE_WRITING_MODE is not present");
                     return false;
                  }
               }
               break;

            default:
               printf("\nInvalid Log Media Type: It should be either of F or C");
               return false;
               break;
         }

      }
      else
      {
         printf("\nInvalid Log Media: %s", temp.c_str());
         return false;
      }
      g_InitialLogMedia=g_ConfigData->m_LogMedia;

      if (false == readString(logger, "FILE_PATH", g_ConfigData->m_LogfilePath,1,100))
      {
         printf("\nInvalid FILE_PATH in LOGGER");
         return false;
      }

      if (false == readString(logger, "FILE_PREFIX", g_ConfigData->m_LogPrefix,1,20))
      {
         printf("\nInvalid FILE_PREFIX in LOGGER");
         return false;
      }

      int l_LogMaxSize=0;
      if( false == readInteger(logger, "MAX_FILE_SIZE", l_LogMaxSize, 10000, 100*1024*1024))
      {
         printf("\nLog File Size should be between 10000 bytes and 100 MB");
         return false;
      }
      g_ConfigData->m_LogMaxsize=l_LogMaxSize;

      if(LOG_MEDIA_FILE == g_ConfigData->m_LogMedia)
      {
         temp = readValue(logger, "FILE_WRITING_MECHANISM");
         if(1 != temp.size())
         {
            printf("\nFILE_WRITING_MECHANISM should be either 'I'mmediate or 'B'uffered");
            return false;
         }

         if( (temp[0] != 'B') && (temp[0] != 'I'))
         {
            printf("\nFILE_WRITING_MECHANISM [%c] should be either 'I'mmediate or 'B'uffered", temp[0]);
            return false;
         }
         g_OtherConfigData->m_logFlag = temp[0];
      }
   }
   else if(LOG_MODEL_GEN_UTIL == g_ConfigData->m_LogModel)
   {
      printf("\nLogging Model: Generic Utilities\n\n");
      if(false == ConfigReader::readString(logger, "GEN_UTIL_LOGGER_CONFIG", g_genLogVal, 1, 10000))
      {
         printf("\nFailed to read GEN_UTIL_LOGGER_CONFIG Tag in CONFIG\n");
         return false;
      }
   }

   // End of log

   // 4.0.2.0
   int l_imei_enc_flag = 0;

   if( false == readInteger(m_DataString, "IMEI_ENCRYPTION_FLAG", l_imei_enc_flag, 0, 1))
   {
      printf("\nIMEI_ENCRYPTION_FLAG value should be either 0 or 1");
      return false;
   }
   g_IMEI_EncrFlag = l_imei_enc_flag;

   memset(g_ConfigData->m_StackEntityName, '\0', 50);

   memset(g_ConfigData->m_EntityName, '\0', 20);

   if (false == readString(m_DataString, "ENTITY_NAME", g_ConfigData->m_EntityName,3,10))
   {
      ELOG(0,1,"Invalid ENTITY_NAME");
      return false;
   }

   if( false == readInteger(m_DataString, "INSTANCE_ID", g_ConfigData->m_InstanceId, 1, 999))
   {
      ELOG(0,1,"Instance ID should be between 1 and 999");
      return false;
   }

   memset(g_entityName, '\0', 10+1);
   sprintf(g_entityName, "%s%03d", g_ConfigData->m_EntityName, g_ConfigData->m_InstanceId);
   snprintf(g_selfEntityNameString, 15, "%s", g_entityName);

   if(LOG_MODEL_GEN_UTIL == g_ConfigData->m_LogModel)
   {
      string l_errMsg;
      g_gui = GenUtilLoggerInterface::getGUtilinstancePtr();
      if(g_gui == NULL)
      {
         printf("\nERROR in getting the GenUtilLoggerInterface ptr\n\n");
         exit(2);
      }

      //      g_atnp = new AppThreadNameProvider;
      //      g_gui->registerThreadNameModel(GEN_UTIL_LOG_THREAD_NAME_MODEL_OVERRIDE, g_atnp);
      g_alcm = new AppLogContentModifier;
      g_gui->registerLogContentModifierModel(GEN_UTIL_LOG_CONTENT_MODIFIER_MODEL_OVERRIDE, g_alcm);

      g_alcp = new AppLogContextProvider;
      g_gui->registerCurrentCtxtModel(GEN_UTIL_LOG_CONTEXT_ID_MODEL_OVERRIDE, g_alcp);

      string l_extensionParameter;
      if(false == g_gui->initialize(g_ConfigData->m_EntityName, g_ConfigData->m_InstanceId, g_ConfigIndex, l_extensionParameter, g_genLogVal, l_errMsg))
      {
         printf("\n ERROR in initializing the Generic Utilities Logger: [%s]\n\n   Please check the GEN_UTIL_LOGGER_CONFIG configuration parameters. Thanks! \n\n",(char*)l_errMsg.c_str());
         exit(2);
      }
   }


   printf("\n\tInitializing Loggers... ");
   bool l_status = g_LoggerObj.initialize(g_ConfigData->m_LogLevel,
         g_ConfigData->m_LogMedia, 
         g_ConfigData->m_LogfilePath, 
         g_ConfigData->m_LogPrefix, 
         "log",
         g_ConfigData->m_ArchivalPath, 
         g_ConfigData->m_LogMaxsize,
         0,
         ((ELogRotateType)g_OtherConfigData->m_LogFileRotatingType),
         g_OtherConfigData->m_LogFileMaxFiles,
         MAX_DUMP_LOGGING_SIZE);
   if (false == l_status)
   {
      printf("\nUnable to initialize Logger");
      exitFunc(EXIT_APPLICATION_TYPE_LOGGERS_INIT_FAILED);
   }
   sleep(2);

   // After this, logs can be written


   if( false == readInteger(m_DataString, "LOG_POLLING_LOOPS", g_OtherConfigData->m_PrintTimerInLog, 0, 1))
   {
      ELOG(0,1,"Invalid LOG_POLLING_LOOPS parameter");
      return false;
   }


   /*if( false == readInteger(m_DataString, "BACKLOG_QUEUE_TYPE", g_OtherConfigData->m_BackLogQueueType, 0, 1))
     {
     ELOG(0,1,"Invalid BACKLOG_QUEUE_TYPE parameter");
     return false;
     }*/
   g_OtherConfigData->m_BackLogQueueType=0;

   if( false == readInteger(m_DataString, "CONSOLE_MAP_PDU_PRINT", g_ConfigData->m_ConsoleMapPduPrintFlag, 0, 1))
   {
      ELOG(0,1,"Invalid CONSOLE_MAP_PDU_PRINT parameter");
      return false;
   }

   if( false == readInteger(m_DataString, "CONSOLE_TCAP_PDU_PRINT", g_ConfigData->m_ConsoleTcapPduPrintFlag, 0, 1))
   {
      ELOG(0,1,"Invalid CONSOLE_TCAP_PDU_PRINT parameter");
      return false;
   }

   if( false == readInteger(m_DataString, "LOG_TCAP_PDU_PRINT", g_ConfigData->m_LogTcapPduPrintFlag, 0, 2))
   {
      ELOG(0,1,"Invalid LOG_TCAP_PDU_PRINT parameter");
      return false;
   }

   if( false == readInteger(m_DataString, "LOG_MAP_PDU_PRINT", g_ConfigData->m_LogMapPduPrintFlag, 0, 1))
   {
      ELOG(0,1,"Invalid LOG_MAP_PDU_PRINT parameter");
      return false;
   }

   if( false == readInteger(m_DataString, "INITIATING_MAP_TRANSACTIONS_TRANSMISSION_RATE", g_OtherConfigData->m_MaxProvInitiatingTransactions, 10, 200))
   {
      ELOG(0,1,"Invalid INITIATING_MAP_TRANSACTIONS_TRANSMISSION_RATE parameter");
      return false;
   }

   if (g_OtherConfigData->m_MaxProvInitiatingTransactions < 10)
   {
      g_OtherConfigData->m_MaxProvInitiatingTransactions=10;
   }

   if( false == readInteger(m_DataString, "THRESHOLD_DIALOGS_FOR_INITIATING_TRANSACTIONS", g_OtherConfigData->m_ThresholdDialogsForInitiatingTransactions, 1, 200))
   {
      ELOG(0,1,"Invalid THRESHOLD_DIALOGS_FOR_INITIATING_TRANSACTIONS parameter");
      return false;
   }

   if( false == readInteger(m_DataString, "MAX_PROFILES_LOADING_DURATION", g_OtherConfigData->m_ProfilesFailureDuration, 0, 3600))
   {
      ELOG(0,1,"Invalid MAX_PROFILES_LOADING_DURATION parameter");
      return false;
   }

   if (g_OtherConfigData->m_ThresholdDialogsForInitiatingTransactions < 1)
   {
      g_OtherConfigData->m_ThresholdDialogsForInitiatingTransactions=1;
   }

   // Tool Related
   string tool = Parser::getChildString(m_DataString, "MML_TOOL");
   if (0 == tool.size())
   {
      ELOG(0,1,"MML_TOOL tag not found");
      return false;
   }

   if( false == readInteger(tool, "FLAG", g_ConfigData->m_ToolEnabledFlag, 0, 1))
      return false;

   if (1 == g_ConfigData->m_ToolEnabledFlag)
   {
      if( false == readInteger(tool, "LISTEN_PORT", g_ConfigData->m_ToolPort, 1025, 65535))
         return false;
   }


   // End of Tool Related

   // SNMP Agent Related
   string snmp = Parser::getChildString(m_DataString, "SNMP_INTERFACE");
   if (0 == snmp.size())
   {
      ELOG(0,1,"SNMP_INTERFACE tag not found");
      return false;
   }

   if( false == readInteger(snmp, "FLAG", g_ConfigData->m_SnmpInterfaceEnabledFlag, 0, 1))
      return false;

   if (1 == g_ConfigData->m_SnmpInterfaceEnabledFlag)
   {
      if( false == readInteger(snmp, "AGENT_PORT", g_ConfigData->m_SnmpAgentPort, 1025, 65535))
         return false;

      temp = readValue(snmp, "AGENT_IP");
      if ( (strlen(temp.c_str()) < 3)||
            (strlen(temp.c_str()) > 20)
         )
      {
         ELOG(0,1,"Invalid AGENT_IP %s ", temp.c_str());
         return false;
      }
      memset(g_ConfigData->m_SnmpAgentIp, '\0', 20);
      strncpy(g_ConfigData->m_SnmpAgentIp, temp.c_str(), 20);

      if( false == readInteger(snmp, "THB", g_OtherConfigData->m_THBEnabled, 0, 1))
      {
         ELOG(0,1,"THB should be between 0 and 1");
         return false;
      }
   }

   // End of SNMP Agent Related

   // Start of Provisioning Interface Related
   string prov = Parser::getChildString(m_DataString, "PROVISIONING_INTERFACE");
   if (0 == prov.size())
   {
      ELOG(0,1,"PROVISIONING_INTERFACE tag not found");
      return false;
   }
   if( false == readInteger(prov, "FLAG", g_ConfigData->m_ProvInterfaceEnabledFlag, 0, 1))
      return false;

   if (1 == g_ConfigData->m_ProvInterfaceEnabledFlag)
   {
      if( false == readInteger(prov, "LISTEN_PORT", g_ConfigData->m_ProvListenPort, 1025, 65535))
      {
         ELOG(0,1,"Invalid LISTEN_PORT parameter");
         return false;
      }
      g_selfIpPort = g_ConfigData->m_ProvListenPort;


      if( false == readInteger(m_DataString, "CLIENT_IDLE_TIMEOUT", g_OtherConfigData->m_clientIdleTimeout, 0, 86400))
      {
         ELOG(0,1,"Invalid  CLIENT_IDLE_TIMEOUT parameter");
         return false;
      }

      if( false == readString(m_DataString, "EXCEPTION_LIST_CLIENT_IDLE_TIMEOUT", g_OtherConfigData->m_clientIdleTimeoutExceptionList, 1, sizeof( g_OtherConfigData->m_clientIdleTimeoutExceptionList)-1))
      {
         ELOG(0,1,"Invalid  EXCEPTION_LIST_CLIENT_IDLE_TIMEOUT parameter");
         return false;
      }

      if( false == readInteger(m_DataString, "MAX_ACTIVE_CONNECTIONS", g_OtherConfigData->m_MaxActiveConnections, 1, 50000))
      {
         ELOG(0,1,"Invalid MAX_ACTIVE_CONNECTIONS parameter");
         return false;
      }

      if( false == readInteger(m_DataString, "ACTIVE_CONNECTIONS_THRESHOLD_PERCENT", g_OtherConfigData->m_conn_fd_thresh_percentage, 1, 99) )
      {
         ELOG(0,1,"Invalid ACTIVE_CONNECTIONS_THRESHOLD_PERCENT parameter");
         return false;
      }
      
      if( false == readInteger(prov, "SERVER_KEEPALIVE_FLAG", g_ConfigData->m_ServerKeepAliveFlag, 0, 1))
      {
         ELOG(0,1,"Invalid SERVER_KEEPALIVE_FLAG parameter");
         return false;
      }
   }



   // End of Provisionig Interface Related

   //Statistics Related
   string stat = Parser::getChildString(m_DataString, "STATISTICS");
   if (0 == stat.size())
   {
      ELOG(0,1,"STATISTICS tag not found");
      return false;
   }
   if( false == readInteger(stat, "FLAG", g_ConfigData->m_StatisticsEnabledFlag, 0, 1))
      return false;

   if (1 == g_ConfigData->m_StatisticsEnabledFlag)
   {
      memset(g_ConfigData->m_StatisticsPath, '\0', 101);

      temp = readValue(stat, "PATH");
      strcpy(g_ConfigData->m_StatisticsPath, (char*)temp.c_str());

      if (0 == strlen(g_ConfigData->m_StatisticsPath))
      {
         ELOG(0,1,"Statistics Path not set");
         return false;
      }
   }

   //End of Statistics


   // Tracing related

   string trlogger=Parser::getChildString(m_DataString,"SUBS_TRACING");
   if(trlogger.size() > 0)
   {
      if( false == readInteger(trlogger, "FLAG", g_ConfigData->m_TracingEnabledFlag, 0, 1))
         return false;

      if (g_ConfigData->m_TracingEnabledFlag)
      {
         temp = readValue(trlogger, "LEVEL");
         if (1 == temp.size())
         {
            char tempChar = temp[0];
            switch (tempChar)
            {
               case 'D':
               case 'd':
                  g_ConfigData->m_TracingLogLevel = LOG_LEVEL_DEBUG;
                  break;

               case 'T':
               case 't':
                  g_ConfigData->m_TracingLogLevel = LOG_LEVEL_TRACE;
                  break;

               case 'L':
               case 'l':
                  g_ConfigData->m_TracingLogLevel = LOG_LEVEL_LOAD;
                  break;

               case 'W':
               case 'w':
                  g_ConfigData->m_TracingLogLevel = LOG_LEVEL_WARNING;
                  break;

               case 'C':
               case 'c':
                  g_ConfigData->m_TracingLogLevel = LOG_LEVEL_CRITICAL;
                  break;

               case 'E':
               case 'e':
                  g_ConfigData->m_TracingLogLevel = LOG_LEVEL_ERROR;
                  break;

               default:
                  printf("\nInvalid Trace Level Type: It should be either of D, T, W, C or E");
                  return false;
                  break;
            }
         }
         else
         {
            ELOG(0,1,"Invalid Trace Level: %s", temp.c_str());
            return false;
         }

         temp = readValue(trlogger, "MEDIA");
         if (1 == temp.size())
         {
            char tempChar = temp[0];
            switch (tempChar)
            {
               case 'C':
               case 'c':
                  g_ConfigData->m_TracingLogMedia = LOG_MEDIA_CONSOLE;
                  break;

               case 'F':
               case 'f':
                  g_ConfigData->m_TracingLogMedia = LOG_MEDIA_FILE;
                  break;

               default:
                  ELOG(0,1,"Invalid Trace Media Type: It should be either of F or C");
                  return false;
                  break;
            }

         }
         else
         {
            ELOG(0,1,"Invalid Trace Media: %s", temp.c_str());
            return false;
         }

         if (false == readString(trlogger, "FILE_PATH", g_ConfigData->m_TracingLogfilePath,1,100))
         {
            ELOG(0,1,"Invalid FILE_PATH in SUBS_TRACING");
            return false;
         }

         if (false == readString(trlogger, "FILE_PREFIX", g_ConfigData->m_TracingLogPrefix,1,20))
         {
            printf("\nInvalid FILE_PREFIX in SUBS_TRACING");
            return false;
         }

         int l_TracingLogMaxsize=0;
         if( false == readInteger(trlogger, "MAX_FILE_SIZE", l_TracingLogMaxsize, 10000, 100*1024*1024))
         {
            ELOG(0,1,"Subs Tracing File Size should be between 10000 bytes and 100 MB");
            return false;
         }
         g_ConfigData->m_TracingLogMaxsize=l_TracingLogMaxsize;
      }
   }
   else
   {
      WLOG(0,1,"SUBS_TRACING tag is not found");
   }
   // End of Tracing related


   // TDR related

   string tdrlogger=Parser::getChildString(m_DataString,"TRANSACTION_DETAIL_RECORDS");
   if (tdrlogger.size() > 0)
   {
      if( false == readInteger(tdrlogger, "FLAG", g_ConfigData->m_TdrEnabledFlag, 0, 1))
         return false;

      if (g_ConfigData->m_TdrEnabledFlag)
      {
         g_ConfigData->m_TdrTitleFlag=1;
         //g_ConfigData->m_TdrLogMedia = LOG_MEDIA_FILE;
         temp = readValue(tdrlogger, "MEDIA");
         if (1 == temp.size())
         {
            char tempChar = temp[0];
            switch (tempChar)
            {
               case 'R':
               case 'r':
                  g_ConfigData->m_TdrLogMedia = LOG_MEDIA_RTPS;
                  break;

               case 'F':
               case 'f':
                  g_ConfigData->m_TdrLogMedia = LOG_MEDIA_FILE;
                  break;

               default:
                  ELOG(0,1,"Invalid Trace Media Type: It should be either of F-Files or R-To RTPS");
                  return false;
                  break;
            }

         }
         else
         {
            ELOG(0,1,"Invalid TDR Media: %s", temp.c_str());
            return false;
         }

         if (false == readString(tdrlogger, "FILE_PATH", g_ConfigData->m_TdrLogfilePath,1,100))
         {
            printf("\nInvalid FILE_PATH in TRANSACTION_DETAIL_RECORDS");
            return false;
         }

         if (false == readString(tdrlogger, "FILE_PREFIX", g_ConfigData->m_TdrLogPrefix,1,20))
         {
            printf("\nInvalid FILE_PATH in TRANSACTION_DETAIL_RECORDS");
            return false;
         }

         int l_TdrLogMaxsize=0;
         if( false == readInteger(tdrlogger, "MAX_FILE_SIZE", l_TdrLogMaxsize, 10000, 10*1024*1024))
         {
            ELOG(0,1,"TDR File Size should be between 10000 bytes and 10 MB");
            return false;
         }
         g_ConfigData->m_TdrLogMaxsize = l_TdrLogMaxsize;

         if(LOG_MEDIA_RTPS == g_ConfigData->m_TdrLogMedia)
         {
            if (false == readString(tdrlogger, "RTPS_IP", g_OtherConfigData->m_TdrRtpsIp,7,15))
            {
               ELOG(0,1,"Invalid RTPS_IP in TRANSACTION_DETAIL_RECORDS");
               return false;
            }

            if( false == readInteger(tdrlogger, "RTPS_PORT", g_OtherConfigData->m_TdrRtpsPort, 1025, 65535))
            {
               ELOG(0,1,"RTPS_PORT is invalid");
               return false;
            }

            if( false == readInteger(tdrlogger, "MAX_RTPS_DOWNTIME", g_OtherConfigData->m_MaxRtpsDowntime, 0, 300))
            {
               ELOG(0,1,"MAX RTPS Downtime should be between 10 and 1200 seconds");
               return false;
            }
         }
      }
   }
   else
   {
      WLOG(0,1,"TRANSACTION_DETAIL_RECORDS tag is not found");
   }
   // End of TDR related




   /*DATABASE Related */
   string database = Parser::getChildString(m_DataString,"DATABASE");
   if (0 == database.size())
   {
      ELOG(0,1,"DATABASE tag not found");
      return false;
   }

   if( false == readInteger(database, "FLAG", g_ConfigData->i_DbConfigData.m_DbRequired, 0, 1))
      return false;

   if (1 == g_ConfigData->i_DbConfigData.m_DbRequired)
   {
      g_ConfigData->i_DbConfigData.m_ReceiveNotificationsFlag = 0;

      if( false == readInteger(database, "NODE_COUNT", g_ConfigData->i_DbConfigData.m_NoOfNodes, 1, 99))
         return false;

      if( false == readInteger(database, "POOL_SIZE_REQUIRED", g_ConfigData->i_DbConfigData.m_PoolSizeRequired, 1, 200))
         return false;

      if(0 != (g_ConfigData->i_DbConfigData.m_PoolSizeRequired%g_ConfigData->i_DbConfigData.m_NoOfNodes))
      {
         ELOG(0,1,"Please configure the PoolSize:%d, a multiple of NodeCount:%d",
               g_ConfigData->i_DbConfigData.m_PoolSizeRequired,
               g_ConfigData->i_DbConfigData.m_NoOfNodes);
         return false;
      }

      memset(g_OtherConfigData->m_DbAliasStringArr, '\0', sizeof(g_OtherConfigData->m_DbAliasStringArr));
      memset(g_OtherConfigData->m_DbActualStringArr, '\0', sizeof(g_OtherConfigData->m_DbActualStringArr));

      for (int l_i=0; l_i<g_ConfigData->i_DbConfigData.m_NoOfNodes; l_i++)
      {
         char l_connectionStringChar[100];
         memset(l_connectionStringChar, '\0', sizeof(l_connectionStringChar));
         sprintf(l_connectionStringChar, "CONNECTION_STRING_%02d", 1+l_i);

         if (false == readString(database, l_connectionStringChar, g_OtherConfigData->m_DbAliasStringArr[l_i],1,39))
            return false;

         bool l_db_status = g_DecDbConnStr.getActualDbString(g_OtherConfigData->m_DbAliasStringArr[l_i],
               g_OtherConfigData->m_DbActualStringArr[l_i],
               g_nlo);
         if(false == l_db_status)
         {
            ELOG(0,1,"[%s] alias not found in password.dat\n", g_OtherConfigData->m_DbAliasStringArr[l_i]);
            return false;
         }
      }

      if (false == readString(database, "ORACLE_ERROR_CODES", g_ConfigData->i_DbConfigData.m_OraErrorCodes,0,1000))
         return false;

      /*
         if (g_ConfigData->i_DbConfigData.m_NoOfNodes > 1)
         {
         temp = readValue(database, "CONNECTION_STRING_2");
         strcpy(g_ConfigData->i_DbConfigData.m_Node2DbConnetionString, temp.c_str());

         if (0 == strlen(g_ConfigData->i_DbConfigData.m_Node2DbConnetionString))
         {
         ELOG(0,1,"CONNECTION_STRING_2 is null");
         return false;
         }

         bool l_db_status_2 = g_DecDbConnStr.getActualDbString(g_ConfigData->i_DbConfigData.m_Node2DbConnetionString,
         g_OtherConfigData->m_Node2DbActualConnetionString,
         g_nlo);
         if(false == l_db_status_2)
         {
         ELOG(0,1,"[%s] alias not found in password.dat\n", g_ConfigData->i_DbConfigData.m_Node2DbConnetionString);
         return false;
         }

      //printf("\nConn strings [%s] [%s]\n", g_OtherConfigData->m_Node2DbActualConnetionString,
      //      g_OtherConfigData->m_DbActualConnectionString);

      if(g_ConfigData->i_DbConfigData.m_PoolSizeRequired %2 != 0)
      g_ConfigData->i_DbConfigData.m_PoolSizeRequired++;
      }*/

      temp = readValue(database, "NODE_RETRY_MECHANISM");
      if (1 == temp.size())
      {
         char tempChar = temp[0];
         switch (tempChar)
         {
            case 'R':  //Re-try to connect to the node forever
            case 'r':
               g_OtherConfigData->m_DbFailedConnectionRetryType = 'R';
               break;

            case 'S':  //Switch-over to the other node if available
            case 's':
               g_OtherConfigData->m_DbFailedConnectionRetryType = 'S';
               if (2 != g_ConfigData->i_DbConfigData.m_NoOfNodes)
               {
                  ELOG(0,1,"NODE_RETRY_MECHANISM 'S'witchover cannot be configured for Node Count other than 2");
                  return false;
               }
               break;

            case 'N':
            case 'n':
               g_OtherConfigData->m_DbFailedConnectionRetryType = 'N';
               if (2 == g_ConfigData->i_DbConfigData.m_NoOfNodes)
               {
                  ELOG(0,1,"NODE_RETRY_MECHANISM 'N'one cannot be configured for Node Count 2");
                  return false;
               }
               break;

            default:
               ELOG(0,1,"Invalid DB Node Retry mechanism [%s]", temp.c_str());
               return false;
               break;
         }
      }
      else
      {
         ELOG(0,1,"Invalid DB Node Retry mechanism: [%s]", temp.c_str());
         return false;
      }

      /*if(false == readInteger(database, "DIFF_TIME", g_ConfigData->i_DbConfigData.m_diffTime,0, 60))
        return false;*/

      if( false == readInteger(database, "HEART_BEAT_FLAG", g_OtherConfigData->m_DbHeartBeatRequiredFlag, 0, 1))
      {
         CLOG(0,1,"HEART_BEAT_FLAG not configured in DATABASE.. exiting");
         return false;                                                      
      }

      if(1 == g_OtherConfigData->m_DbHeartBeatRequiredFlag)       
      {                                                                     
         if(false == readInteger(database, "HEART_BEAT_INTERVAL", g_OtherConfigData->m_DbHeartBeatInterval, 60, 86400))
         {
            CLOG(0,1,"HEART_BEAT_INTERVAL is not configured. Hard-coding to 300 seconds");
            g_OtherConfigData->m_DbHeartBeatInterval=300;
         }
      }                                                                     

      g_OtherConfigData->m_DbThresholdTps = 0;
      if( false == readInteger(database, "INITIAL_QUERY_DB_TPS", g_OtherConfigData->m_DbThresholdTps, 0, 2000))
      {
         CLOG(0,1,"INITIAL_QUERY_DB_TPS not configured in DATABASE TAG.. exiting");
         return false;                                                      
      }

      if( false == readInteger(database, "LATER_QUERY_POOL_SIZE", g_OtherConfigData->m_LaterQueryPoolSizeRequired, 0, 200))
      {
         CLOG(0,1,"LATER_QUERY_POOL_SIZE not configured in DATABASE TAG.. exiting");
         return false;                                                      
      }
      if( false == readInteger(database, "LATER_QUERY_DB_TPS", g_OtherConfigData->m_LaterQueryDbTps, 0, 2000))
      {
         CLOG(0,1,"LATER_QUERY_DB_TPS not configured in DATABASE.. exiting");
         return false;                                                      
      }
      if(g_OtherConfigData->m_LaterQueryDbTps > 0)
      {
         if(0 == g_OtherConfigData->m_LaterQueryPoolSizeRequired)
         {
            CLOG(0,1,"LATER_QUERY_POOL_SIZE not configured in DATABASE TAG.. exiting");
            return false;
         }
      }
   }

   /* MEMCACHED Related */
   string memcached = Parser::getChildString(m_DataString,"MEMCACHED");
   if (0 == memcached.size())
   {
      ELOG(0,1,"MEMCACHED tag not found");
      return false;
   }

   if( false == readInteger(memcached, "FLAG", g_ConfigData->m_MemcEnableFlag, 0, 1))
      return false;

   if(1 == g_ConfigData->m_MemcEnableFlag)
   {
      string l_memcServers = Parser::getChildString(memcached, "MEMCACHED_SERVERS");
      DLOG(0,0,"MEMCACHED_SERVERS is %s", l_memcServers.c_str());
      if (l_memcServers.size() == 0)
      {
         ELOG(0,1,"MEMCACHED_SERVERS tag is not found");
         return false;
      }
      else 
      { 
         list<string> l_MemcServerList;       
         l_MemcServerList = Parser::getAllValues(l_memcServers, "SERVER");
         list<string> :: iterator l_MemcServerListItr;
         for (l_MemcServerListItr = l_MemcServerList.begin();l_MemcServerListItr != l_MemcServerList.end();l_MemcServerListItr++)
         {
            MemCacheAddress l_memCacheAddress;
            if (false == readString((*l_MemcServerListItr),"IP",l_memCacheAddress.MCServerIp, 1,100))
            {
               ELOG(0,1,"Invalid IP");
               return false;   
            } 
            if (false == readInteger((*l_MemcServerListItr),"PORT",l_memCacheAddress.MCServerPort, 1025,65535)) 
            {
               ELOG(0,1,"Invalid PORT");
               return false; 
            }  
            LLOG(0,1,"Memcached ip %s port  %d", l_memCacheAddress.MCServerIp.c_str(), l_memCacheAddress.MCServerPort);
            g_ConfigData->m_MemCacheAddrVector.push_back(l_memCacheAddress);
         }
      }

      if( false == readInteger(memcached, "MEMC_DIFF_TIME_TRAP_INTERVAL", g_ConfigData->m_MemcDiffTimeTrapInterval, 0, 3600))
      {
         CLOG(0,1,"MEMC_DIFF_TIME_TRAP is not configured. Hard-coding to 5 seconds");
         g_ConfigData->m_MemcDiffTimeTrapInterval = 5;
      }

      if( false == readInteger(memcached, "MEMC_MAX_REQUEST_QUEUE_SIZE", g_ConfigData->m_MemcMaxReqQsize, 0, 10000))
      {
         CLOG(0,1,"MEMC_MAX_REQUEST_QUEUE_SIZE is not configured. Disabling threshold check");
         return false;
      }
   }

   /* End of MEMCACHED Releated */


   /*NG Related */
   string ng = Parser::getChildString(m_DataString,"NG");
   if (0 == ng.size())
   {
      ELOG(0,1,"NG tag not found");
      return false;
   }

   if( false == readInteger(ng, "FLAG", g_OtherConfigData->m_TCAPStackFlag, 0, 1))
   {
      ELOG(0,1,"FLAG tag not found in NG");
      return false;
   }

   if(1 == g_OtherConfigData->m_TCAPStackFlag)
   {
      string gt_translation = Parser::getChildString(ng,"GT_TRANSLATION");
      if (gt_translation.size() > 0)
      {
         if( false == readInteger(gt_translation, "FLAG", g_OtherConfigData->m_GtTranslationRequiredFlag, 0, 1))
         {
            ELOG(0,1,"FLAG in GT_TRANSLATION should be either 0 or 1");
            return false;
         }

         if (g_OtherConfigData->m_GtTranslationRequiredFlag)
         {
            string translations = Parser::getChildString(gt_translation,"TRANSLATIONS");

            //printf("\ntranslations : %s", (char*)translations.c_str());
            if (translations.size() > 0)
            {
               for (int l_trans_index=1; l_trans_index<=50; l_trans_index++)
               {
                  //printf("\ntrans loop %d", l_trans_index);
                  char l_trans_data[100];
                  memset(l_trans_data, '\0', sizeof(l_trans_data));
                  sprintf(l_trans_data, "TRANS_%02d", l_trans_index);

                  //string l_ctxt = readValue(translations, l_trans_data);
                  string l_ctxt = Parser::getChildString(translations, l_trans_data);

                  //printf("\nctxt [%s]", (char*)l_ctxt.c_str());



                  string l_flag = readValue(l_ctxt, "F");
                  if (0 == atoi(l_flag.c_str()))
                  {
                     //printf("\nnot found\n");
                     continue;
                  }

                  string l_from = readValue(l_ctxt, "FROM");

                  if (0 == l_from.size())
                  {
                     ELOG(0,1,"Error in getting FROM in index: %d", l_trans_index);
                     return false;
                  }
                  else if (l_from.size() < 5 || l_from.size() > 20)
                  {
                     ELOG(0,1,"FROM GT size in index: %d should be between 5 and 20", l_trans_index);
                     return false;
                  }

                  char *l_from_chr = new char[l_from.size()+1];
                  memset(l_from_chr, '\0', l_from.size()+1);
                  strcpy(l_from_chr, (char*)l_from.c_str());

                  string l_to = readValue(l_ctxt, "TO");

                  if (0 == l_to.size())
                  {
                     ELOG(0,1,"Error in getting TO in index: %d", l_trans_index);
                     return false;
                  }
                  else if (l_to.size() < 5 || l_to.size() > 20)
                  {
                     ELOG(0,1,"TO GT size in index: %d should be between 5 and 20", l_trans_index);
                     return false;
                  }

                  char *l_to_chr = new char[l_to.size()+1];
                  memset(l_to_chr, '\0', l_to.size()+1);
                  strcpy(l_to_chr, (char*)l_to.c_str());

                  //printf("\nFrom: %s  To: %s", l_from_chr, l_to_chr);
                  g_OtherConfigData->m_GtTranslationMap.insert(pair<char*,char*>(l_from_chr, l_to_chr));

                  //printf("\nsize of map: %d", g_OtherConfigData->m_GtTranslationMap.size());


               }
            }
            else
            {
               WLOG(0,1,"GT Translation is not configured");
            }
         }
         else
         {
            //printf("\nGT_TRANSLATION FLAG is set to zero\n");
         }
      }
      else
      {
         WLOG(0,1,"GT_TRANSLATION tag not found");
      }

      //Added for external partner gt translations for 1.0.8.0 release
      string ext_translation = Parser::getChildString(ng,"PARTNER_TRANSLATION");
      if (ext_translation.size() > 0)
      {
         if( false == readInteger(ext_translation, "FLAG", g_OtherConfigData->m_ExtTranslationRequiredFlag, 0, 1))
         {
            ELOG(0,1,"FLAG in PARTNER_TRANSLATION should be either 0 or 1");
            return false;
         }

         if (g_OtherConfigData->m_ExtTranslationRequiredFlag)
         {
            string translations = Parser::getChildString(ext_translation,"TRANSLATIONS");

            //printf("\ntranslations : %s", (char*)translations.c_str());
            if (translations.size() > 0)
            {
               for (int l_trans_index=1; l_trans_index<=50; l_trans_index++)
               {
                  //printf("\ntrans loop %d", l_trans_index);
                  char l_trans_data[100];
                  memset(l_trans_data, '\0', sizeof(l_trans_data));
                  sprintf(l_trans_data, "TRANS_%02d", l_trans_index);

                  //string l_ctxt = readValue(translations, l_trans_data);
                  string l_ctxt = Parser::getChildString(translations, l_trans_data);

                  //printf("\nctxt [%s]", (char*)l_ctxt.c_str());



                  string l_flag = readValue(l_ctxt, "F");
                  if (0 == atoi(l_flag.c_str()))
                  {
                     //printf("\nnot found\n");
                     continue;
                  }

                  string l_from = readValue(l_ctxt, "CCNDC");

                  if (0 == l_from.size())
                  {
                     ELOG(0,1,"Error in getting CCNDC in index: %d", l_trans_index);
                     return false;
                  }
                  else if (l_from.size() < 1 || l_from.size() > 20)
                  {
                     ELOG(0,1,"CCNDC size in index: %d should be between 1 and 20", l_trans_index);
                     return false;
                  }

                  char *l_from_chr = new char[l_from.size()+1];
                  memset(l_from_chr, '\0', l_from.size()+1);
                  strcpy(l_from_chr, (char*)l_from.c_str());

                  string l_to = readValue(l_ctxt, "GT");

                  if (0 == l_to.size())
                  {
                     ELOG(0,1,"Error in getting GT in index: %d", l_trans_index);
                     return false;
                  }
                  else if (l_to.size() < 5 || l_to.size() > 20)
                  {
                     ELOG(0,1,"GT size in index: %d should be between 5 and 20", l_trans_index);
                     return false;
                  }

                  char *l_to_chr = new char[l_to.size()+1];
                  memset(l_to_chr, '\0', l_to.size()+1);
                  strcpy(l_to_chr, (char*)l_to.c_str());

                  //printf("\nFrom: %s  To: %s", l_from_chr, l_to_chr);
                  g_OtherConfigData->m_ExtTranslationMap.insert(pair<char*,char*>(l_from_chr, l_to_chr));

                  //printf("\nsize of map: %d", g_OtherConfigData->m_GtTranslationMap.size());


               }
            }
            else
            {
               ELOG(0,1,"Ext GT Translation is not configured");
               return false;
            }
         }
         else
         {
            DLOG(0,1,"PARTNER_TRANSLATION FLAG is set to zero");
         }
      }
      else
      {
         ELOG(0,1,"PARTNER_TRANSLATION tag not found");
         return false;
      }

      //Added in 1.0.8.0


      temp = readValue(ng, "STACK_NAME");
      strncpy(g_ConfigData->i_NgConfigData.m_StackName, temp.c_str (), 30);
      if (strlen(g_ConfigData->i_NgConfigData.m_StackName) < 4)
      {
         ELOG(0,1,"Stack Name is less than 4 digits");
         return false;
      }

      if( false == readInteger(ng, "PRESERVE_SCCP_CLASS", g_OtherConfigData->m_PreserveSccpClass, 0, 1))
      {
         ELOG(0,1,"Invalid PRESERVE_SCCP_CLASS parameter");
         return false;
      }
      
      if( false == readInteger(ng, "OPCODE_TAG_REJECTION", g_OtherConfigData->m_OpcodeTagRej, 0, 2))
      {
         ELOG(0,1,"Invalid OPCODE_TAG_REJECTION parameter");
         return false;
      }

      string l_sccpType;
      if( false == readString(ng, "SCCP_TYPE", l_sccpType, 1, 1))
      {
         ELOG(0,1,"Invalid SCCP_TYPE parameter");
         return false;
      }
      g_OtherConfigData->m_SccpType = l_sccpType[0];

      if( false == readInteger(ng, "TT", g_OtherConfigData->m_TT, 0, 255))
      {
         ELOG(0,1,"Invalid TT parameter");
         return false;
      }

      if( false == readInteger(ng, "ALLOWED_TT_LIST_VALIDATION", g_OtherConfigData->m_AllowedTTListValidation, 0, 1))
      {
	  ELOG(0,1,"ALLOWED_TT_LIST_VALIDATION should be either 0 or 1");
	  return false;
      }
      
      if (1 == g_OtherConfigData->m_AllowedTTListValidation)
      { 
         if(true == readString(ng, "ALLOWED_TT_LIST_VALUES", g_OtherConfigData->m_AllowedTTList, 0, 300))
         {
	    if (g_OtherConfigData->m_AllowedTTList.size() > 0)
	    {
	       DLOG(0,0,"ALLOWED_TT_LIST_VALUES is configured %s",g_OtherConfigData->m_AllowedTTList.c_str());
	       int l_len=g_OtherConfigData->m_AllowedTTList.length();
	       if((g_OtherConfigData->m_AllowedTTList[0] != ',') || (g_OtherConfigData->m_AllowedTTList[l_len-1] != ','))
	       {
		  CLOG(0,1,"ALLOWED_TT_LIST_VALUES should start with a Comma(,) and end with a Comma(,)");
		  return false;
	       }

	       size_t l_start = 0;
	       size_t l_end = 0;

	       while ((l_end = g_OtherConfigData->m_AllowedTTList.find(',', l_start)) != std::string::npos)
	       {
		  string l_value = g_OtherConfigData->m_AllowedTTList.substr(l_start, l_end - l_start);
		  if (!l_value.empty()) 
		  {
	             int l_TTValue = atoi(l_value.c_str());  
		     g_OtherConfigData->m_allowedTTs.push_back(l_TTValue); 
		  }
		  l_start = l_end + 1; 
	       } 
	       vector<int> :: iterator it;
	       for(it = g_OtherConfigData->m_allowedTTs.begin(); it != g_OtherConfigData->m_allowedTTs.end(); ++it)
	       {
		  DLOG(0, 0, "Allowed TT: %d", *it);  
	       }
	    }
	    else
	    {
               ELOG(0, 0, "ALLOWED_TT_LIST_VALUES is empty or not configured");
	       return false;
	    } 
	 }
      }
      else
      {
         LLOG(0,1,"ALLOWED_TT_LIST_VALIDATION set to zero");
      }

      if('I' == g_OtherConfigData->m_SccpType)
      {
	 g_protocol = C7_PROTOCOL;
	 g_globalTitleIndicator = L_GT_0100;
      }
      else if('A' == g_OtherConfigData->m_SccpType)
      {
         g_protocol = A7_PROTOCOL;
         g_globalTitleIndicator = L_GT_0010;

         string l_sccpNi;
         if( false == readString(ng, "ANSI_SCCP_NATIONAL_IND", l_sccpNi, 1, 1))
         {
            ELOG(0,1,"Invalid ANSI_SCCP_NATIONAL_IND");
            return false;
         }
         g_OtherConfigData->m_AnsiNationalIndicator = l_sccpNi[0];
         if('I' == g_OtherConfigData->m_AnsiNationalIndicator)
         {
            LLOG(0,1,"ANSI_SCCP_NATIONAL_IND is set to I");
         }
         else if('N' == g_OtherConfigData->m_AnsiNationalIndicator)
         {
            LLOG(0,1,"ANSI_SCCP_NATIONAL_IND is set to N");
         }
         else
         {
            ELOG(0,1,"ANSI_SCCP_NATIONAL_IND should be either I-International or N-National");
            return false;
         }
      }
      else
      {
         ELOG(0,1,"SCCP_TYPE parameter should be either I-ITU or A-ANSI");
         return false;
      }

      if( false == readInteger(ng, "SCCP_MESSAGE_HANDLING_PARAM", g_OtherConfigData->m_sccpMsgHandlerParam, 0, 4))
      {
         ELOG(0,1,"Invalid SCCP_MESSAGE_HANDLING parameter");
         return false;
      }

      if( false == readInteger(ng, "MAX_DIALOGS", g_ConfigData->i_NgConfigData.m_MaxDialogs, 1, 32000))
      {
         ELOG(0,1,"Invalid MAX_DIALOGS parameter");
         return false;
      }

      bool l_result = readSccpAddress(m_DataString, "SELF_ADDRESS", &(g_ConfigData->i_NgConfigData.m_selfAddress));
      if (!l_result)
      {
         ELOG(0,1,"Invalid SELF_ADDRESS parameter");
         return false;
      }
      g_ConfigData->i_NgConfigData.m_LocalSSN = g_ConfigData->i_NgConfigData.m_selfAddress.ssn;

      l_result= readSccpAddress(m_DataString, "ADDR_1", &(g_ConfigData->i_NgConfigData.m_remoteAddress1));
      if (!l_result)
      {
         DLOG(0,1,"ADDR_1 is not present");
      }

      l_result= readSccpAddress(m_DataString, "ADDR_2", &(g_ConfigData->i_NgConfigData.m_remoteAddress2));
      if (!l_result)
      {
         DLOG(0,1,"ADDR_2 is not present");
      }

      // Reading Hex Data values... This is not ideally required for Real HLR

      temp = readValue(ng, "HEX_DATA_1");
      if ( (temp.size()>1) && ((temp.size()%2)==0))
      {
         atohx((char*)g_ConfigData->i_NgConfigData.m_HexData1.m_value, (char*)temp.c_str());
         g_ConfigData->i_NgConfigData.m_HexData1.m_length = strlen((char*)temp.c_str())/2;
      }

      temp = readValue(ng, "HEX_DATA_2");
      if ( (temp.size()>1) && ((temp.size()%2)==0))
      {
         atohx((char*)g_ConfigData->i_NgConfigData.m_HexData2.m_value, (char*)temp.c_str());
         g_ConfigData->i_NgConfigData.m_HexData2.m_length = strlen((char*)temp.c_str())/2;
      }

      temp = readValue(ng, "HEX_DATA_3");
      if ( (temp.size()>1) && ((temp.size()%2)==0))
      {
         atohx((char*)g_ConfigData->i_NgConfigData.m_HexData3.m_value, (char*)temp.c_str());
         g_ConfigData->i_NgConfigData.m_HexData3.m_length = strlen((char*)temp.c_str())/2;
      }
      // END OF Reading Hex Data values... This is not ideally required for Real HLR

      if(false == readInteger(ng, "SEPARATE_STATS_BASED_ON_GT_FLAG", g_OtherConfigData->m_SeparateStatsBasedGTFlag, 0, 1))
      {
         ELOG(0,1,"SEPARATE_STATS_BASED_ON_GT_FLAG tag not found");
         return false;
      }
      if(1 == g_OtherConfigData->m_SeparateStatsBasedGTFlag)
      {
         string l_SeparateStatsLists = Parser::getChildString(ng,"SEPARATE_STATS_LISTS");
         DLOG(0,0,"SEPARATE_STATS_LISTS is %s",l_SeparateStatsLists.c_str());
         if(l_SeparateStatsLists.size() == 0)
         {
            ELOG(0,1,"SEPARATE_STATS_LISTS tag is not found");
            return false;
         }
         else
         {
            list<string> l_SeparateStatsDataList;
            l_SeparateStatsDataList = Parser::getAllValues(l_SeparateStatsLists,"SEPARATE_STATS_DATA");
            list<string> :: iterator l_SeparateStatsDataListIt;
            for(l_SeparateStatsDataListIt = l_SeparateStatsDataList.begin(); l_SeparateStatsDataListIt != l_SeparateStatsDataList.end(); l_SeparateStatsDataListIt++)
            {   
               reportData l_reportData;
               string l_ReportName;
               if(false == readString((*l_SeparateStatsDataListIt), "REPORT_NAME", l_ReportName, 4,5))
               {
                  ELOG(0,1,"Invalid REPORT_NAME"); 
                  return false;

               }
               l_reportData.m_reportName = l_ReportName;
               DLOG(0,0,"Report name is %s",l_reportData.m_reportName.c_str());

               string l_opCodes;
               if(false == readString((*l_SeparateStatsDataListIt), "SEPARATE_STATS_BASED_ON_GT_MAP_OP_CODES_LIST", l_opCodes, 4,300))
               {
                  ELOG(0,1,"invalid SEPARATE_STATS_BASED_ON_GT_MAP_OP_CODES_LIST");
                  return false;
               }
               else
               {
                  l_reportData.m_opCodes = l_opCodes;
                  int l_len=l_reportData.m_opCodes.length();
                  if((l_reportData.m_opCodes[0] != ',') || (l_reportData.m_opCodes[l_len-1] != ','))
                  {
                     CLOG(0,1,"SEPARATE_STATS_BASED_ON_GT_MAP_OP_CODES_LIST should be start with a Comma(,) and end with a Comma(,)");
                     return false;
                  }
                  DLOG(0,0,"SEPARATE_STATS_BASED_ON_GT_MAP_OP_CODES_LIST is %s",l_reportData.m_opCodes.c_str());
               }

               string l_GTs;
               if(false == readString((*l_SeparateStatsDataListIt), "SEPARATE_STATS_BASED_ON_GT_LIST_OF_GTS", l_GTs, 1,15))
               {
                  CLOG(0,0,"Invalid SEPARATE_STATS_BASED_ON_GT_LIST_OF_GTS");
                  return false;
               }
               l_reportData.m_GTs = l_GTs;
               DLOG(0,0,"SEPARATE_STATS_BASED_ON_GT_LIST_OF_GTS is %s",l_reportData.m_GTs.c_str());

               g_OtherConfigData->m_reportDataList.push_back(l_reportData);
            }
            list<reportData> :: iterator it;
            for(it = g_OtherConfigData->m_reportDataList.begin(); it!=g_OtherConfigData->m_reportDataList.end(); it++)
               DLOG(0,0,"Report Name is %s Opcodes is %s GTs is %s",it->m_reportName.c_str(),it->m_opCodes.c_str(),it->m_GTs.c_str());
         }
      } 
      else
      {
         ELOG(0,1,"SEPARATE_STATS_BASED_ON_GT_FLAG set to zero");
      }

   }


   /*DIAMETER NG Related */
   string dng = Parser::getChildString(m_DataString,"DIAMETER_NG");
   if (0 == dng.size())
   {
      ELOG(0,1,"DIAMETER_NG tag not found");
      return false;
   }

   if(false == readInteger(dng, "FLAG", g_OtherConfigData->m_dcd.m_diameterNgRequired, 0, 1))
   {
      ELOG(0,1,"Invalid FLAG");
      return false;
   }

   string l_Sccp = Parser::getChildString(m_DataString,"SCCP_NG");
   DLOG(0,0,"SCCP [%s]",l_Sccp.c_str());
   if(0 == l_Sccp.size())
   {
      ELOG(0,1,"SCCP tag not found");
      return false;  //mandatory or optional needs to check
   }

///////////////////////////////// SCCP PARAMETERS //////////////////////////////////////////

   if(false == readInteger(l_Sccp, "FLAG", g_OtherConfigData->m_SCCPStackFlag, 0, 1))
   {
      ELOG(0,1,"Invalid FLAG");
      return false;
   }
   DLOG(0,0,"SCCP FLAG[%d]",g_OtherConfigData->m_SCCPStackFlag);

   if((0 == g_OtherConfigData->m_dcd.m_diameterNgRequired) && (0 == g_OtherConfigData->m_TCAPStackFlag) && (0 == g_OtherConfigData->m_SCCPStackFlag))
   {
      ELOG(0,1,"Atleast one of TCAP/DIAMETER/SCCP stack has to be initialized");
      return false;
   }

   /* SCCP Related */ 
   if((0 == g_OtherConfigData->m_TCAPStackFlag) && (0 == g_OtherConfigData->m_dcd.m_diameterNgRequired))
   {
      DLOG(0,0,"TCAP and DIAMETER Disabled, Reading SCCP ");

         string l_StackName = readValue(l_Sccp, "STACK_NAME");
         strncpy(g_OtherConfigData->m_StackName, l_StackName.c_str (), 30);
         if (strlen(g_OtherConfigData->m_StackName) < 4)
         {
            ELOG(0,1,"Stack Name in SCCP is less than 4 digits");
            return false;
         }
         DLOG(0,0,"STACK_NAME[%s] in SCCP tag",g_OtherConfigData->m_StackName);

         string l_SSN = readValue(l_Sccp, "SSN");
         int l_ssn = atoi(l_SSN.c_str ());
         if ( (l_ssn <0) || (l_ssn >255) )
         {
            ELOG(0,0,"SSN [%d] should be between 0 and 255", l_ssn);
            return false;
         } 
         g_OtherConfigData->m_localSSN = l_ssn;
         DLOG(0,0,"SSN[%d] in SCCP tag",g_OtherConfigData->m_localSSN);

         if( false == readString(l_Sccp, "SCCP_TYPE", g_OtherConfigData->m_Sccp_Type, 1, 1))
         {
            ELOG(0,1,"Invalid SCCP_TYPE parameter in SCCP tag");
            return false;
         }
         DLOG(0,0,"SSCP_TYPE[%s] in SCCP tag",g_OtherConfigData->m_Sccp_Type);
      
         if(false == readInteger(l_Sccp, "TT_CALLED_PARTY", g_OtherConfigData->m_TTCalledParty, 0, 255))
         {
            ELOG(0,1,"Invalied TT_CALLED_PARTY");
            return false;
         } 
         DLOG(0,0,"TT_CALLED_PARTY[%d] IN SCCP tag",g_OtherConfigData->m_TTCalledParty);
         
         if(false == readInteger(l_Sccp, "DEBUG_LOG_LEVEL", g_OtherConfigData->m_DebugLogLevel, 0, 1))
         {
            ELOG(0,1,"Invalied DEBUG_LOG_LEVEL");
            return false;
         } 
         DLOG(0,0,"DEBUG_LOG_LEVEL[%d] IN SCCP tag",g_OtherConfigData->m_DebugLogLevel);

         if(false == readString(l_Sccp, "ROUTING_HLR_ADDRESS", g_OtherConfigData->m_RoutingHlrAddress, 5, 20))
         {
            ELOG(0,1,"Invalid ROUTING_HLR_ADDRESS Tag");
            return false;
         }
         DLOG(0,0,"ROUTING_HLR_ADDRESS[%s] IN SCCP tag",g_OtherConfigData->m_RoutingHlrAddress);
   }
   else
   {
      DLOG(0,0,"DIAMETER_NG FLAG[%d] NG FLAG[%d] SCCP_NG FLAG[%d]",g_OtherConfigData->m_dcd.m_diameterNgRequired, g_OtherConfigData->m_TCAPStackFlag, g_OtherConfigData->m_SCCPStackFlag);
      if( (1 == g_OtherConfigData->m_SCCPStackFlag) && ((1 == g_OtherConfigData->m_dcd.m_diameterNgRequired) || (1 == g_OtherConfigData->m_TCAPStackFlag)) )
      {
         ELOG(0,1,"SCCP Stack is enabled, YOU cannot initialzie Tcap/Diameter stacks");
         return false;
      }
   }

   if(1 == g_OtherConfigData->m_dcd.m_diameterNgRequired)
   {
      //start 6.3.8.0C 
      string diastack_logging = Parser::getChildString(dng,"DIASTACK_LOGGING");
      if (diastack_logging.size() > 0)
      {
         if( false == readInteger(diastack_logging, "FLAG", g_OtherConfigData->m_dcd.m_DiastackLoggingFlag, 0, 1))
         {
            ELOG(0,1,"FLAG in DIASTACK_LOGGING should be either 0 or 1");
            return false;
         }

         if (1 == g_OtherConfigData->m_dcd.m_DiastackLoggingFlag)
         {

            memset(g_OtherConfigData->m_dcd.m_LogsForDebugging, '\0', sizeof(g_OtherConfigData->m_dcd.m_LogsForDebugging));
            if( false == readString(diastack_logging, "LOGGING_FLAGS", g_OtherConfigData->m_dcd.m_LogsForDebugging, 50, 50))
            {
               ELOG(0,1,"Invalid LOGGING_FLAGS");
            }
            string l_diamlogLevel;
            if( false == readString(diastack_logging, "DIAMETER_LOG_LEVEL", l_diamlogLevel,1,1))
            {
               ELOG(0,1,"Invalid DIAMETER_LOG_LEVEL");
            }
            if((l_diamlogLevel[0] == 'D') || (l_diamlogLevel[0] == 'd'))
            {
               g_OtherConfigData->m_dcd.m_logLevel = "debug";
            }
            else if((l_diamlogLevel[0] == 'W') || (l_diamlogLevel[0] == 'w'))
            {
               g_OtherConfigData->m_dcd.m_logLevel = "warning";
            }
            else if((l_diamlogLevel[0] == 'E') || (l_diamlogLevel[0] == 'e'))
            {
               g_OtherConfigData->m_dcd.m_logLevel = "error";
            }
            else if((l_diamlogLevel[0] == 'C') || (l_diamlogLevel[0] == 'c'))
            {
               g_OtherConfigData->m_dcd.m_logLevel = "critical";
            }
            else if((l_diamlogLevel[0] == 'N') || (l_diamlogLevel[0] == 'n'))
            {
               g_OtherConfigData->m_dcd.m_logLevel = "none";
            }
            else
            {
               ELOG(0,1,"Invalid DIAMETER_LOG_LEVEL");
            }
         }
         else
         {
            LLOG(0,0,"DIASTACK_LOGGING Flag is not 1");
         }
      }
      else
      {
         LLOG(0,0,"DIASTACK_LOGGING is not found");
      }
      //End 6.3.8.0C
      
      if( false == readString(dng, "STACK_IP", g_OtherConfigData->m_dcd.m_diamPrimaryIpAddress, 7, 15))
      {
         ELOG(0,1,"Invalid STACK_IP");
         return false;
      }

      if(false == readInteger(dng, "STACK_PORT", g_OtherConfigData->m_dcd.m_diamPrimaryIpPort, 1025, 65535))
      {
         ELOG(0,1,"Invalid STACK_PORT");
         return false;
      }

      if(false == readInteger(dng, "CLIENT_ID", g_OtherConfigData->m_dcd.m_clientId, 1, 100))
      {
         ELOG(0,1,"Invalid CLIENT_ID");
         return false;
      }

      if(false == readInteger(dng, "APPLICATION_ID", g_OtherConfigData->m_dcd.m_applicationId, 1, 1000000000))
      {
         ELOG(0,1,"Invalid APPLICATION_ID");
         return false;
      }

      if(false == readInteger(dng, "ADDITIONAL_APP_ID_COUNT", g_OtherConfigData->m_dcd.m_additionalAppIdcount, 0, 10))
      {
         ELOG(0,1,"Invalid ADDITIONAL_APP_ID_COUNT");
         return false;
      }
      int l_appCount = g_OtherConfigData->m_dcd.m_additionalAppIdcount;
      if( l_appCount >  0)
      {
         //ADDITIONAL_APP_ID_01
         for(int l_i=0; l_i<l_appCount; l_i++)
         {
            char l_addAppId[100];
            memset(l_addAppId, '\0', sizeof(l_addAppId));
            sprintf(l_addAppId, "ADDITIONAL_APP_ID_%02d", 1+l_i);

            if (false == readInteger(dng, l_addAppId, g_OtherConfigData->m_dcd.m_additionalAppId[l_i], 1, 1000000000))
            {
               ELOG(0,1,"Invalid [%s]",l_addAppId);
               return false;
            }
            // break; // only reading one additional app id as of now 
         }
      }

      string l_connType;
      if( false == readString(dng, "CONN_TYPE", l_connType, 1, 1))
      {
         ELOG(0,1,"Invalid CONN_TYPE");
         return false;
      }

      if((l_connType[0] == 'S') || (l_connType[0] == 'R'))
      {
         LLOG(0,1,"Conn Type: %c", l_connType[0]);
         g_OtherConfigData->m_dcd.m_connectionType = l_connType[0];
      }
      else
      {
         ELOG(0,1,"Invalid CONN_TYPE");
         return false;
      }

      if('R' == l_connType[0])
      {
         if( false == readString(dng, "BACKUP_STACK_IP", g_OtherConfigData->m_dcd.m_diamBackupIpAddress, 7, 15))
         {
            ELOG(0,1,"Invalid BACKUP_STACK_IP");
            return false;
         }

         if(false == readInteger(dng, "BACKUP_STACK_PORT", g_OtherConfigData->m_dcd.m_diamBackupIpPort, 1025, 65535))
         {
            ELOG(0,1,"Invalid BACKUP_STACK_PORT");
            return false;
         }
      }

      string l_diameterPduPrintType;
      if( false == readString(dng, "DIAMETER_PDU_PRINT", l_diameterPduPrintType, 1, 1))
      {
         ELOG(0,1,"Invalid DIAMETER_PDU_PRINT");
         return false;
      }

      if((l_diameterPduPrintType[0] == 'L') || (l_diameterPduPrintType[0] == 'C') || (l_diameterPduPrintType[0] == 'B') || (l_diameterPduPrintType[0] == 'N'))
      {
         LLOG(0,1,"Diameter PDU Print Type: %c", l_diameterPduPrintType[0]);
         g_OtherConfigData->m_dcd.m_diamterPduPrintType = l_diameterPduPrintType[0];
      }
      else
      {
         ELOG(0,1,"Invalid DIAMETER_PDU_PRINT");
         return false;
      }

      if( false == readString(dng, "ORIGIN_HOST", g_OtherConfigData->m_dcd.m_originHost, 1, 100))
      {
         ELOG(0,1,"Invalid ORIGIN_HOST");
         return false;
      }

      if( false == readString(dng, "ORIGIN_REALM", g_OtherConfigData->m_dcd.m_originRealm, 1, 100))
      {
         ELOG(0,1,"Invalid ORIGIN_REALM");
         return false;
      }

      if( false == readString(dng, "DESTINATION_HOST", g_OtherConfigData->m_dcd.m_destinationHost, 1, 100))
      {
         ELOG(0,1,"Invalid DESTINATION_HOST");
         return false;
      }

      if( false == readString(dng, "DESTINATION_REALM", g_OtherConfigData->m_dcd.m_destinationRealm, 1, 100))
      {
         ELOG(0,1,"Invalid DESTINATION_REALM");
         return false;
      }

      string l_diameterRejectionType;
      if( false == readString(dng, "DIAMETER_REJECTION_TYPE", l_diameterRejectionType, 1, 1))
      {
         ELOG(0,1,"Invalid DIAMETER_REJECTION_TYPE");
         return false;
      }

      if((l_diameterRejectionType[0] == 'E') || (l_diameterRejectionType[0] == 'N'))
      {
         LLOG(0,1,"DIAMETER Rejection Type: %c", l_diameterRejectionType[0]);
         g_OtherConfigData->m_DiameterMessageRejectionType = l_diameterRejectionType[0];
      }
      else
      {
         ELOG(0,1,"Invalid DIAMETER Rejection Type: %c", l_diameterRejectionType[0]);
         return false;
      }

      //6.4.4.0
      if( false == readInteger(dng, "DIAM_SUSPEND_RESUME_FEATURE", g_OtherConfigData->m_DiamSuspendResumeFeature, 0, 1))
      {
             ELOG(0,1,"DIAM_SUSPEND_RESUME_FEATURE should be either 0 or 1");
             return false;
      }

      g_OtherConfigData->m_DiameterInterfaceType[0]='\0';

      if( false == readString(dng, "DIAMETER_INTERFACE_TYPE", g_OtherConfigData->m_DiameterInterfaceType, 0, 20))
      {
             ELOG(0,1,"DIAMETER_INTERFACE_TYPE Tag is not present");
             return false;
      }
      if(! ((0 == strcmp(g_OtherConfigData->m_DiameterInterfaceType,"")) || ((0 == strcmp(g_OtherConfigData->m_DiameterInterfaceType,"DIAMETER-S6A")) || (0 == strcmp(g_OtherConfigData->m_DiameterInterfaceType,"DIAMETER-IMS")) || (0 == strcmp(g_OtherConfigData->m_DiameterInterfaceType,"DIAMETER-WIFI")) )))
      {
             ELOG(0,1,"DIAMETER_INTERFACE_TYPE should be either DIAMETER-S6A or DIAMETER-WIFI or DIAMETER-IMS");
             return false; 
      }
      
      
      //6.4.4.0
      /////////////////////////////////////////////////////////////////////////////////
      string hss_translation = Parser::getChildString(dng,"HSS_HOST_TRANSLATION");
      if (hss_translation.size() > 0)
      {
         if( false == readInteger(hss_translation, "FLAG", g_OtherConfigData->m_HssHostTranslationFlag, 0, 1))
         {
            ELOG(0,1,"FLAG in HSS_HOST_TRANSLATION should be either 0 or 1");
            return false;
         }

         if (g_OtherConfigData->m_HssHostTranslationFlag)
         {
            string translations = Parser::getChildString(hss_translation,"TRANSLATIONS");

            //printf("\ntranslations : %s", (char*)translations.c_str());
            if (translations.size() > 0)
            {
               for (int l_trans_index=1; l_trans_index<=50; l_trans_index++)
               {
                  //printf("\ntrans loop %d", l_trans_index);
                  char l_trans_data[100];
                  memset(l_trans_data, '\0', sizeof(l_trans_data));
                  sprintf(l_trans_data, "TRANS_%02d", l_trans_index);

                  //string l_ctxt = readValue(translations, l_trans_data);
                  string l_ctxt = Parser::getChildString(translations, l_trans_data);

                  //printf("\nctxt [%s]", (char*)l_ctxt.c_str());



                  string l_flag = readValue(l_ctxt, "F");
                  if (0 == atoi(l_flag.c_str()))
                  {
                     //printf("\nnot found\n");
                     continue;
                  }

                  string l_from = readValue(l_ctxt, "FROM");

                  if (0 == l_from.size())
                  {
                     ELOG(0,1,"Error in getting FROM in index: %d", l_trans_index);
                     return false;
                  }
                  else if (l_from.size() < 1 || l_from.size() > 100)
                  {
                     ELOG(0,1,"FROM HSS_HOST size in index: %d should be between 1 and 100", l_trans_index);
                     return false;
                  }

                  char *l_from_chr = new char[l_from.size()+1];
                  memset(l_from_chr, '\0', l_from.size()+1);
                  strcpy(l_from_chr, (char*)l_from.c_str());

                  string l_to = readValue(l_ctxt, "TO");

                  if (0 == l_to.size())
                  {
                     ELOG(0,1,"Error in getting TO in index: %d", l_trans_index);
                     return false;
                  }
                  else if (l_to.size() < 1 || l_to.size() > 100)
                  {
                     ELOG(0,1,"TO HSS_HOST size in index: %d should be between 5 and 20", l_trans_index);
                     return false;
                  }

                  char *l_to_chr = new char[l_to.size()+1];
                  memset(l_to_chr, '\0', l_to.size()+1);
                  strcpy(l_to_chr, (char*)l_to.c_str());

                  //printf("\nFrom: %s  To: %s", l_from_chr, l_to_chr);
                  g_OtherConfigData->m_HssHostTranslationMap.insert(pair<char*,char*>(l_from_chr, l_to_chr));

                  //printf("\nsize of map: %d", g_OtherConfigData->m_GtTranslationMap.size());


               }
            }
            else
            {
               WLOG(0,1,"HSS Host Translation is not configured");
            }
         }
         else
         {
            LLOG(0,0,"HSS_HOST_TRANSLATION FLAG is made to 0");
            //printf("\nGT_TRANSLATION FLAG is set to zero\n");
         }
      }
      else
      {
         WLOG(0,1,"HSS_HOST_TRANSLATION tag not found");
      }
      ///////////////////////////////////////////////////////////////////////////

   }

   memset(&g_cc, '\0', sizeof(g_cc));
   string congestion=Parser::getChildString(m_DataString,"CONGESTION_CONTROL");

   if (0 == congestion.size())
   {
      ELOG(0,1,"CONGESTION_CONTROL tag not found");
      return false;
   }

   if( false == readString(congestion, "CONTROL_TYPE", g_cc.m_controlType, 1, 1))
   {
      ELOG(0,1,"Invalid CONTROL_TYPE value. Should be either A - Monitor active dialogues, T - Monitor transactions per second, B - Monitor both active dialogues and transactions per second, N - No congestion control");
      return false;
   }

   if ( ('D' != g_cc.m_controlType[0])  && ('T' != g_cc.m_controlType[0]) && ('B' != g_cc.m_controlType[0]) && ('N' != g_cc.m_controlType[0]))
   {
      ELOG(0,1,"Invalid CONTROL_TYPE value. Should be either A - Monitor active dialogues, T - Monitor transactions per second, B - Monitor both active dialogues and transactions per second, N - No congestion control");
      return false;
   }

   if ('N' != g_cc.m_controlType[0])
   {
      if ( ('D' == g_cc.m_controlType[0])  || ('B' == g_cc.m_controlType[0]))
      {
         if( false == readInteger(congestion, "MAX_DB_REQUEST_QUEUE_SIZE", g_cc.m_maxActiveIncomingDialogues, 0, 10000))
         {
            ELOG(0,1,"Invalid MAX_DB_REQUEST_QUEUE_SIZE value");
            return false;
         }
         if( false == readInteger(congestion, "MAX_LATER_DB_REQUEST_QUEUE_SIZE", g_cc.m_maxActiveLaterQueueSize, 0, 10000))
         {
            ELOG(0,1,"Invalid MAX_LATER_DB_REQUEST_QUEUE_SIZE value");
            return false;
         }
      }

      if ( ('T' == g_cc.m_controlType[0])  || ('B' == g_cc.m_controlType[0]))
      {
         if( false == readInteger(congestion, "MAX_INCOMING_TRANSACTIONS_PER_SEC", g_cc.m_maxIncomingTransactionsPerSec, 1, 2000))
         {
            ELOG(0,1,"Invalid MAX_INCOMING_TRANSACTIONS_PER_SEC value");
            return false;
         }

         if(1 == g_OtherConfigData->m_dcd.m_diameterNgRequired)
         {
            if( false == readInteger(congestion, "MAX_DIAM_QUEUE_SIZE", g_OtherConfigData->m_DiameterMaxQueueSize, 1, 50000))
            {
               ELOG(0,1,"Invalid MAX_DIAM_QUEUE_SIZE value");
               return false;
            }

            if( false == readInteger(congestion, "MIN_DIAM_QUEUE_SIZE", g_OtherConfigData->m_DiameterMinQueueSize, 0, 50000))
            {
               ELOG(0,1,"Invalid MIN_DIAM_QUEUE_SIZE value");
               return false;
            }
         }

         /* //Commented in 1.0.8.0 - not required
            if (g_cc.m_maxIncomingTransactionsPerSec > g_ConfigData->i_NgConfigData.m_MaxDialogs)
            {
            ELOG(0,1,"MAX_INCOMING_TRANSACTIONS_PER_SEC value %d should not be greater than MAX_DIALOGS %d", 
            g_cc.m_maxIncomingTransactionsPerSec, g_ConfigData->i_NgConfigData.m_MaxDialogs);
            return false;
            }
            */
      }

      if(false == readInteger(congestion, "PRIORITY_HANDLING", g_cc.m_priorityHandling, 0, 4))
      {
         ELOG(0,1,"Invalid PRIORITY_HANDLING value");
         return false;
      }

      //printf("\ng_cc.m_priorityHandling %d\n", g_cc.m_priorityHandling);

      if(g_cc.m_priorityHandling >= 1)
      {
         g_cc.m_priorityPercentages[0]=100;
         string priorities = Parser::getChildString(m_DataString,"PRIORITY_THRESHOLDS");
         if (0 == priorities.size())
         {
            ELOG(0,1,"PRIORITY_THRESHOLDS tag not found");
            return false;
         }
         char l_priorityChar[50];

         g_cc.m_priorityMaxActiveIncomingDialogues[0] = g_cc.m_maxActiveIncomingDialogues;
         g_cc.m_priorityIncomingTransactionsPerSec[0] = g_cc.m_maxIncomingTransactionsPerSec;

         int l_i=1;
         for(l_i=1; l_i<=4; l_i++)
         {
            memset(l_priorityChar, '\0', sizeof(l_priorityChar));
            sprintf(l_priorityChar, "PRIORITY_%02d", l_i);

            //printf("\npriority loop [%s]", l_priorityChar);

            if( false == readInteger(priorities, l_priorityChar, g_cc.m_priorityPercentages[l_i], 1, 99))
            {
               WLOG(0,1,"Invalid %s value found. Breaking", l_priorityChar);
               break;
            }

            if (g_cc.m_priorityPercentages[l_i] >= g_cc.m_priorityPercentages[l_i-1])
            {
               ELOG(0,1,"Priority%d value %d should be less than Priority%d value %d", 
                     l_i, g_cc.m_priorityPercentages[l_i], l_i-1, g_cc.m_priorityPercentages[l_i-1]);
               return false;
            }

            g_cc.m_priorityMaxActiveIncomingDialogues[l_i] = (g_cc.m_maxActiveIncomingDialogues * g_cc.m_priorityPercentages[l_i])/100;
            g_cc.m_priorityIncomingTransactionsPerSec[l_i] = (g_cc.m_maxIncomingTransactionsPerSec * g_cc.m_priorityPercentages[l_i])/100;
         }

         if (l_i < g_cc.m_priorityHandling)
         {
            ELOG(0,1,"Atleast %d priority percentages have to be configured", g_cc.m_priorityHandling);
            return false;
         }
      }

      if( false == readString(congestion, "OVERLOAD_TRANSACTIONS_REJECT_TYPE", g_cc.m_overloadTransactionsRejectType, 1, 1))
      {
         ELOG(0,1,"Invalid OVERLOAD_TRANSACTIONS_REJECT_TYPE value. Should be either A-Abort or S-SystemFailure or I-Ignore");
         return false;
      }
      if ( (g_cc.m_overloadTransactionsRejectType[0] != 'A')  && 
            (g_cc.m_overloadTransactionsRejectType[0] != 'S')  && 
            (g_cc.m_overloadTransactionsRejectType[0] != 'I'))
      {
         ELOG(0,1,"Configure OVERLOAD_TRANSACTIONS_REJECT_TYPE [%c] either A-Abort or S-SystemFailure or I-Ignore", 
               g_cc.m_overloadTransactionsRejectType[0]);
         return false;
      }

      if(false == readInteger(congestion, "TRAP_INTERVAL", g_cc.m_trapInterval, 60, 3600))
      {
         ELOG(0,1,"Invalid TRAP_INTERVAL value");
         return false;
      }
   }



   /*SMPP Connection*/
   string smpp = Parser::getChildString(m_DataString,"SMPP");
   if (smpp.size() > 0)
   {
      temp = readValue(smpp, "FLAG");
      g_ConfigData->m_EsmeConfigData.m_Required = atoi(temp.c_str ());
      if(g_ConfigData->m_EsmeConfigData.m_Required != 0  && g_ConfigData->m_EsmeConfigData.m_Required != 1)
      {
         ELOG(0,1,"SMPP flag should be either 0 or 1");
         return false;
      }
      if(1 == g_ConfigData->m_EsmeConfigData.m_Required)
      {
         temp = readValue(smpp, "SMSC_IP_ADDRESS");
         strcpy(g_ConfigData->m_EsmeConfigData.m_SMPP_IPAddress, temp.c_str());

         if((strlen(g_ConfigData->m_EsmeConfigData.m_SMPP_IPAddress) < 7) || (strlen(g_ConfigData->m_EsmeConfigData.m_SMPP_IPAddress) > 20))
         {
            ELOG(0,1,"Ipaddress should be between 7 and 20 digits");
            return false;
         }

         temp = readValue(smpp, "SMSC_IP_PORT");
         g_ConfigData->m_EsmeConfigData.m_SMPP_Port = atoi(temp.c_str());

         if((g_ConfigData->m_EsmeConfigData.m_SMPP_Port < 1025) || (g_ConfigData->m_EsmeConfigData.m_SMPP_Port > 65535))
         {
            ELOG(0,1,"Smsc PORT should be between 1025 and 65535 digits");
            return false;
         }

         temp = readValue(smpp, "BIND_TON");
         g_ConfigData->m_EsmeConfigData.m_BindTON = atoi(temp.c_str());

         if((g_ConfigData->m_EsmeConfigData.m_BindTON < 0) || (g_ConfigData->m_EsmeConfigData.m_BindTON > 9999))
         {
            ELOG(0,1,"Bind Ton should be between 0 and 9999 digits");
            return false;
         }

         temp = readValue(smpp, "SUBMIT_TON");
         g_ConfigData->m_EsmeConfigData.m_SubmitTON = atoi(temp.c_str());

         if((g_ConfigData->m_EsmeConfigData.m_SubmitTON < 0) || (g_ConfigData->m_EsmeConfigData.m_SubmitTON > 9999))
         {
            ELOG(0,1,"Submit Ton should be between 0 and 9999 digits");
            return false;
         }

         temp = readValue(smpp, "BIND_NPI");
         g_ConfigData->m_EsmeConfigData.m_BindNPI = atoi(temp.c_str());

         if((g_ConfigData->m_EsmeConfigData.m_BindNPI < 0) || (g_ConfigData->m_EsmeConfigData.m_BindNPI > 9999))
         {
            ELOG(0,1,"Smsc Bind Npi should be between 0 and 9999 digits");
            return false;
         }

         temp = readValue(smpp, "SYSTEM_ID");
         strcpy(g_ConfigData->m_EsmeConfigData.m_System_Id, temp.c_str());

         if((strlen(g_ConfigData->m_EsmeConfigData.m_System_Id) < 1) || (strlen(g_ConfigData->m_EsmeConfigData.m_System_Id) > 20))
         {
            ELOG(0,1,"System Id length should be between 1 and 20 characters");
            return false;
         }

         temp = readValue(smpp, "PASSWORD");
         strcpy(g_ConfigData->m_EsmeConfigData.m_Password, temp.c_str());

         if((strlen(g_ConfigData->m_EsmeConfigData.m_Password) < 1) || (strlen(g_ConfigData->m_EsmeConfigData.m_Password) > 20))
         {
            ELOG(0,1,"Password length should be between 1 and 20 characters");
            return false;
         }


         temp = readValue(smpp, "SYSTEM_TYPE");
         strcpy(g_ConfigData->m_EsmeConfigData.m_System_Type, temp.c_str());

         if((strlen(g_ConfigData->m_EsmeConfigData.m_System_Type) < 1) || (strlen(g_ConfigData->m_EsmeConfigData.m_System_Type) > 20))
         {
            ELOG(0,1,"System type length should be between 1 and 20 characters");
            return false;
         }


         temp = readValue(smpp, "CONSOLE_PRINT");
         g_ConfigData->m_EsmeConfigData.m_PrintPdu = atoi(temp.c_str());

         if((g_ConfigData->m_EsmeConfigData.m_PrintPdu != 0)  && (g_ConfigData->i_DbConfigData.m_DbRequired != 1))
         {
            ELOG(0,1,"CONSOLE_PRINT flag should be either 0 or 1");
            return false;
         }

         temp = readValue(smpp, "SERVICE_TYPE");
         strcpy(g_ConfigData->m_EsmeConfigData.m_serviceType, temp.c_str());

         if((strlen(g_ConfigData->m_EsmeConfigData.m_serviceType) < 1) || (strlen(g_ConfigData->m_EsmeConfigData.m_serviceType) > 20))
         {
            ELOG(0,1,"Service type length should be between 1 and 20 characters");
            return false;
         }

         temp = readValue(smpp, "SOURCE_ADDR");
         strcpy(g_ConfigData->m_EsmeConfigData.m_sourceAddr, temp.c_str());

         if((strlen(g_ConfigData->m_EsmeConfigData.m_sourceAddr) < 1) || (strlen(g_ConfigData->m_EsmeConfigData.m_sourceAddr) > 20))
         {
            ELOG(0,1,"Source address length should be between 1 and 20 characters");
            return false;
         }
      }
   }

   //printf("\nConfiguration Read Successfully\n");
   return true;
}


bool modifyBoolean(char *p_log_key, int *p_val, char *p_toBeChanged, char *p_responseToBeSent)
{
   if (1 == strlen(p_toBeChanged))
   {
      if (*p_val == 0)
      {
         if (p_toBeChanged[0] == '0')
         {
            sprintf(p_responseToBeSent, "%s value is already 0", p_log_key);
            return false;
         }
         else if (p_toBeChanged[0] == '1')
         {
            *p_val = 1;
            sprintf(p_responseToBeSent, "%s value is changed to 1", p_log_key);
            return true;
         }
         else
         {
            sprintf(p_responseToBeSent, "%s value should be either 0 or 1", p_log_key);
            return false;
         }
      }
      else if (*p_val == 1)
      {
         if (p_toBeChanged[0] == '0')
         {
            *p_val = 0;
            sprintf(p_responseToBeSent, "%s value is changed to 0", p_log_key);
            return true;
         }
         else if (p_toBeChanged[0] == '1')
         {
            sprintf(p_responseToBeSent, "%s value is already 1", p_log_key); 
            return false;
         }  
         else
         {
            sprintf(p_responseToBeSent, "%s value should be either 0 or 1", p_log_key);
            return false;
         }
      }
      else
      {
         sprintf(p_responseToBeSent, "%s value should be either 0 or 1", p_log_key);     
         return false;
      }
   }
   else
   {
      sprintf(p_responseToBeSent, "%s value should be either 0 or 1", p_log_key);
      return false;
   }
   return false;
}


bool modifyInteger(char *p_log_key, int *p_val, char *p_toBeChanged, int p_min, int p_max, char *p_responseToBeSent)
{
   if (strlen(p_toBeChanged) < 1)
   {
      sprintf(p_responseToBeSent, "%s value is null", p_log_key);
      return false;
   }
   else
   {
      for (int l_i=0; l_i<strlen(p_toBeChanged); l_i++)
      {
         if ( (p_toBeChanged[l_i] < '0') || (p_toBeChanged[l_i] > '9') )
         {
            sprintf(p_responseToBeSent, "%s value should be numeric", p_log_key);
            return false;
         }
      }

      int l_value=atoi(p_toBeChanged);
      if ( (l_value < p_min) || (l_value > p_max))
      {
         sprintf(p_responseToBeSent, "%s value should be between %d and %d", p_log_key, p_min, p_max);
         return false;
      }
      else
      {
         if (*p_val == l_value)
         {
            sprintf(p_responseToBeSent, "%s value is already %d", p_log_key, l_value);
            return false;
         }
         else
         {
            *p_val = l_value;
            sprintf(p_responseToBeSent, "%s value has been changed to %d", p_log_key, l_value);
            return true;
         }
      }
   }
   return false;
}



bool modifyChar(char *p_log_key, char *p_val, char *p_toBeChanged, char *p_possibleValues, char *p_responseToBeSent)
{
   if (strlen(p_toBeChanged) != 1)
   {
      sprintf(p_responseToBeSent, "%s value should be a single character", p_log_key);
      return false;
   }
   else
   {
      char l_tempString[500];
      memset(l_tempString, '\0', sizeof(l_tempString));
      sprintf(l_tempString, "%c", p_possibleValues[0]);
      for (int l_i=1; l_i<strlen(p_possibleValues); l_i++)
      {
         char l_temp[10];
         memset(l_temp, '\0', sizeof(l_temp));
         sprintf(l_temp, " or %c", p_possibleValues[l_i]);
         strcat(l_tempString, l_temp);
      }

      bool l_possible=false;
      for (int l_i=0; l_i<strlen(p_possibleValues); l_i++)
      {
         if (p_possibleValues[l_i] == p_toBeChanged[0])
         {
            l_possible=true;
         }
      }
      if (false == l_possible)
      {
         sprintf(p_responseToBeSent, "%s value should be %s", p_log_key, l_tempString);
         return false;
      }
      else
      {
         if (p_val[0] == p_toBeChanged[0])
         {
            sprintf(p_responseToBeSent, "%s value is already %c", p_log_key, p_toBeChanged[0]);
            return false;
         }
         else
         {
            p_val[0]=p_toBeChanged[0];
            sprintf(p_responseToBeSent, "%s value is now changed to %c", p_log_key, p_toBeChanged[0]);
            return true;
         }
      }
   }
   return false;
}



void modifyNgConfigValues(char *p_log_key, char *p_log_value, char *p_responseToBeSent)
{
   if (0 == strcmp(p_log_key, "CONSOLE_MAP_PDU_PRINT"))
   {
      modifyBoolean(p_log_key, &g_ConfigData->m_ConsoleMapPduPrintFlag, p_log_value, p_responseToBeSent);
   }
   else if (0 == strcmp(p_log_key, "LOG_MAP_PDU_PRINT"))
   {
      modifyBoolean(p_log_key, &g_ConfigData->m_LogMapPduPrintFlag, p_log_value, p_responseToBeSent);
   }
   else if (0 == strcmp(p_log_key, "LOG_TCAP_PDU_PRINT"))
   {
      modifyInteger(p_log_key, &g_ConfigData->m_LogTcapPduPrintFlag, p_log_value, 0, 2, p_responseToBeSent);
   }
   else if (0 == strcmp(p_log_key, "CONSOLE_TCAP_PDU_PRINT"))
   {
      modifyInteger(p_log_key, &g_ConfigData->m_ConsoleTcapPduPrintFlag, p_log_value, 0, 2, p_responseToBeSent);
   }
   else if (0 == strcmp(p_log_key, "LOG_POLLING_LOOPS"))
   {
      modifyBoolean(p_log_key, &g_OtherConfigData->m_PrintTimerInLog, p_log_value, p_responseToBeSent);
   }
   else if (0 == strcmp(p_log_key, "PRIORITY_HANDLING"))
   {
      int l_maxPriorityPercentages=0;
      for(int l_i=1; l_i<=10; l_i++)
      {
         if (g_cc.m_priorityPercentages[l_i] > 0)
         {
            l_maxPriorityPercentages++;
         }
      }
      if (0 == l_maxPriorityPercentages)
      {
         sprintf(p_responseToBeSent, "PRIORITY_HANDLING cannot be changed since no Threshold Percentages are set");
      }
      else
      {
         modifyInteger(p_log_key, &g_cc.m_priorityHandling, p_log_value, 0, l_maxPriorityPercentages, p_responseToBeSent);
      }
   }
   else if (0 == strcmp(p_log_key, "MAX_INCOMING_TRANSACTIONS_PER_SEC"))
   {
      if (true == modifyInteger(p_log_key, &g_cc.m_maxIncomingTransactionsPerSec, p_log_value, 1, 500, p_responseToBeSent))
      {
         g_cc.m_priorityIncomingTransactionsPerSec[0]=g_cc.m_maxIncomingTransactionsPerSec;
         for(int l_i=0; l_i<=g_cc.m_priorityHandling; l_i++)
         {
            if (g_cc.m_priorityPercentages[l_i] > 0)
            {
               g_cc.m_priorityIncomingTransactionsPerSec[l_i] = (g_cc.m_maxIncomingTransactionsPerSec * g_cc.m_priorityPercentages[l_i])/100;
               LLOG(0,1,"Changed PriorityIncomingTransactions %d %d", l_i, g_cc.m_priorityIncomingTransactionsPerSec[l_i]);
            }
         }
      }
   }
   else if (0 == strcmp(p_log_key, "MAX_LATER_DB_REQUEST_QUEUE_SIZE"))
   {
      modifyInteger(p_log_key, &g_cc.m_maxActiveLaterQueueSize, p_log_value, 0, 10000, p_responseToBeSent);
   }
   else if (0 == strcmp(p_log_key, "MAX_DB_REQUEST_QUEUE_SIZE"))
   {
      if (true == modifyInteger(p_log_key, &g_cc.m_maxActiveIncomingDialogues, p_log_value, 0, 10000, p_responseToBeSent))
      {
         g_cc.m_priorityMaxActiveIncomingDialogues[0]=g_cc.m_maxActiveIncomingDialogues;
         for(int l_i=0; l_i<=g_cc.m_priorityHandling; l_i++)
         {
            if (g_cc.m_priorityPercentages[l_i] > 0)
            {
               g_cc.m_priorityMaxActiveIncomingDialogues[l_i] = (g_cc.m_maxActiveIncomingDialogues * g_cc.m_priorityPercentages[l_i])/100;
               LLOG(0,1,"Changed PriorityActiveIncomingDlgs %d %d", l_i, g_cc.m_priorityMaxActiveIncomingDialogues[l_i]);
            }
         }
      }
   }
   else if (0 == strcmp(p_log_key, "OVERLOAD_TRANSACTIONS_REJECT_TYPE"))
   {
      modifyChar(p_log_key, g_cc.m_overloadTransactionsRejectType, p_log_value, "ASI", p_responseToBeSent);
   }
   else if (0 == strcmp(p_log_key, "DIAMETER_PDU_PRINT"))
   {
      char l_char[2];
      l_char[0] = g_OtherConfigData->m_dcd.m_diamterPduPrintType;
      l_char[1] = '\0';
      if(true == modifyChar(p_log_key, l_char, p_log_value, "NLCB", p_responseToBeSent))
      {
         g_OtherConfigData->m_dcd.m_diamterPduPrintType = l_char[0];
      }
   }
   else if (0 == strcmp(p_log_key, "TRAP_INTERVAL"))
   {
      modifyInteger(p_log_key, &g_cc.m_trapInterval, p_log_value, 60, 3600, p_responseToBeSent);
   }
   else if (0 == strcmp(p_log_key, "GEN_UTIL_LOGGER_CONFIG"))
   {
      if(NULL == g_gui)
      {
         CLOG(0,0,"Application is not started with LOGGING_MODEL G-Generic Utilities logging model");
         strncpy(p_responseToBeSent, "Application is not started with LOGGING_MODEL G-Generic Utilities logging model", 4000);
      }
      else
      {
         bool l_status = g_cr->init();
         if (false == l_status)
         {
            LLOG(0,0,"Error in reloading Configuration file :%s", (char*)g_cr->m_ConfigFileName.c_str());
            strncpy(p_responseToBeSent, "Error in reloading Configuration file", 4000);
         }
         else
         {
            string logger=Parser::getChildString(g_cr->m_DataString,"LOGGER");
            if (0 == logger.size())
            {
               printf("\nLOGGER tag is not found\n");
               strncpy(p_responseToBeSent, "LOGGER tag is not found", 4000);
               //return false;
            }
            else 
            {
               LLOG(0,0,"Getting GEN_UTIL_LOGGER_CONFIG from configuration");
               string l_genUtilLoggerConfig;
               if(false == ConfigReader::readString(logger, "GEN_UTIL_LOGGER_CONFIG", l_genUtilLoggerConfig, 1, 10000))
               {
                  ELOG(0,0,"Failed to read GEN_UTIL_LOGGER_CONFIG Tag in CONFIG");
                  strncpy(p_responseToBeSent, "Failed to read GEN_UTIL_LOGGER_CONFIG Tag in CONFIG", 4000);
                  //return false;
               }
               else
               {
                  string l_errorMessage;
                  LLOG(0,0,"Calling Generic Utilities reInitialize function");
                  EGenUtilConfigReloadStatus l_status = g_gui->reInitialize(l_genUtilLoggerConfig, "", l_errorMessage);
                  if(GEN_UTIL_LOG_CFG_RELOAD_FAILURE == l_status)
                  {
                     ELOG(0,0,"Error in reInitialize of GenUtils:%s", l_errorMessage.c_str());
                     strncpy(p_responseToBeSent, (char*)l_errorMessage.c_str(), 4000);
                  }
                  else if(GEN_UTIL_LOG_CFG_RELOAD_NO_DATA_CHANGE == l_status)
                  {
                     WLOG(0,0,"Generic Utilities is saying no change! :%s", l_errorMessage.c_str());
                     strncpy(p_responseToBeSent, (char*)l_errorMessage.c_str(), 4000);
                  }
                  else if(GEN_UTIL_LOG_CFG_RELOAD_SUCCESS == l_status)
                  {
                     LLOG(0,0,"Reloading of GEN_UTIL_LOGGER_CONFIG Success");
                     strncpy(p_responseToBeSent, "Reloading of GEN_UTIL_LOGGER_CONFIG Success", 4000);
                  }
                  else
                  {
                     LLOG(0,0,"Unhandled return value");
                     strncpy(p_responseToBeSent, "Unknown reInitialization error", 4000);
                  }
               }
            }
         }
      }
   }

   /*
      else if (0 == strcmp(p_log_key, "THREAD_HEALTH_CHECK"))
      {
      modifyBoolean(p_log_key, &g_OtherConfigData->m_SendThreadHealthCheckTrap, p_log_value, p_responseToBeSent);
      }*/
   else
   {
      sprintf(p_responseToBeSent, "%s value cannot be changed. Only the following tags can be changed\n%s", p_log_key,
            "\tCONSOLE_MAP_PDU_PRINT\n\tLOG_MAP_PDU_PRINT\n\tLOG_TCAP_PDU_PRINT\n\tCONSOLE_TCAP_PDU_PRINT\n\tLOG_POLLING_LOOPS\n\tPRIORITY_HANDLING\n\tMAX_INCOMING_TRANSACTIONS_PER_SEC\n\tMAX_DB_REQUEST_QUEUE_SIZE\n\tOVERLOAD_TRANSACTIONS_REJECT_TYPE\n\tTRAP_INTERVAL\n\tDIAMETER_PDU_PRINT\n\tGEN_UTIL_LOGGER_CONFIG\n\tMAX_LATER_DB_REQUEST_QUEUE_SIZE");
   }
}


void NgConfigReader::printConfigData(char *p_output)
{
   ELOG(0,1,"NgConfigReader::printConfigData called.");
   strcpy(p_output, "yet to be implemented");
}

void ConfigReader::printConfigData(char *p_output)
{
   ELOG(0,1,"ConfigReader::printConfigData called.");
   strcpy(p_output, "Yet to be implemented");
}


bool ConfigReader::readSccpAddress(string& p_ngString, char *p_tag, L_SccpAddress *p_sccpAddr)
{
   string l_self_address = Parser::getChildString(p_ngString, p_tag);
   if (0 == l_self_address.size())
   {
      DLOG(0,1,"Address Tag [%s] not found", p_tag);
      return false;
   }

   int l_routingInd=-1;
   int l_pc=0;
   char l_gt[20+1];
   memset(l_gt, '\0', 20);

   string temp = readValue(l_self_address, "ROUTING_IND");
   if (strcmp((char*)(temp.c_str()), "GT_SSN")==0)
   {
      l_routingInd=0;
   }
   else if (strcmp((char*)(temp.c_str()), "PC_SSN")==0)
   {
      l_routingInd=1;
   }
   else
   {
      printf("\nROUTING_IND can be either GT_SSN or PC_SSN");
      return false;
   }

   if ( (l_routingInd != 0)  && (l_routingInd != 1))
   {
      printf("\nRouting Ind should be 0 or 1");
      return false;
   }

   if (0 == l_routingInd)
   {
      temp = readValue(l_self_address, "GT");
      strncpy(l_gt, temp.c_str(), 20);
      if ( (strlen(l_gt) <5) || (strlen(l_gt) >20) )
      {
         printf("\nInvalid GT [%s]", l_gt);
         return false;
      }
   }
   else
   {
      temp = readValue(l_self_address, "PC");
      l_pc = atoi(temp.c_str());
      //printf("\n Local PC      : [%d]", l_pc);
      if ( (l_pc <0) || (l_pc > 16383))
      {
         printf("\nPoint Code [%d] should be between 0 and 16383", l_pc);
         return false;
      }
   }

   temp = readValue(l_self_address, "SSN");
   int l_ssn = atoi(temp.c_str ());
   //printf("\n Local SSN      : [%d]", l_ssn);
   if ( (l_ssn <0) || (l_ssn >255) )
   {
      printf("\nSSN [%d] should be between 0 and 255", l_ssn);
      return false;
   }

   configureSccpAddress(p_sccpAddr, l_routingInd, l_pc, l_ssn, l_gt);

   /*size_t l_stringLen = 200;
     char l_string[ l_stringLen +1];
     memset(l_string, '\0', l_stringLen+1);

     sccpDumpStructureAddressToString (l_string, &l_stringLen, (SccpAddress*)p_sccpAddr);
     printf("\n%-20s\t\t: %s", p_tag, l_string);*/

   return true;
}



ConfigReader::ConfigReader()
{
   m_derivedObjectInitializedFlag=false;
   m_lastUpdateDate=0;
   memset(m_errorDesc, '\0', sizeof(m_errorDesc));
}

ConfigReader::~ConfigReader()
{
}

HexData::HexData()
{
   m_length=0;
   memset(m_value, '\0', sizeof(m_value));
}

HexData::~HexData()
{
}

NgConfigData::NgConfigData()
{
   m_RemotePC=0;
   m_RemoteSSN=0;
   m_LocalSSN=0;
   memset(m_StackName, '\0', sizeof(m_StackName));

   memset(&m_selfAddress, '\0', sizeof(m_selfAddress));
   memset(&m_remoteAddress1, '\0', sizeof(m_remoteAddress1));
   memset(&m_remoteAddress2, '\0', sizeof(m_remoteAddress2));

   m_MaxDialogs = 0;
}

NgConfigData::~NgConfigData()
{
}

DbConfigData::DbConfigData()
{
   /*DATA BASE LOG */
   m_DbRequired = 0;
   m_ReceiveNotificationsFlag = 0;
   m_DbLogLevel = 0;
   m_DbLogMedia = 0;
   m_DbMaxFileSize = 0;
   memset(m_DbLogfilePath,'\0',sizeof(m_DbLogfilePath));
   memset(m_DbLogPrefix,'\0',sizeof(m_DbLogPrefix));
   m_DbLogMaxsize = 0;
   memset(m_DbArchivalPath,'\0',sizeof(m_DbArchivalPath));

   m_PoolSizeRequired = 0;
   m_MinAcceptpoolsize = 0;
   memset(m_DbConnetionString,'\0',sizeof(m_DbConnetionString));
   m_PercentageThreshold = 0;
   m_MoniterThreadReq = 0;
   //DBTEST
   m_NoOfNodes =0;
   memset(m_Node2DbConnetionString,'\0',sizeof(m_Node2DbConnetionString));
   m_diffTime = 0;
   memset(m_OraErrorCodes,'\0',sizeof(m_OraErrorCodes));
   //DBTEST

}

DbConfigData::~DbConfigData()
{

}

ConfigData::ConfigData()
{
   memset(&m_EsmeConfigData,'\0',sizeof(m_EsmeConfigData));
   m_LogLevel = 0;
   m_LogMedia = 0;
   m_MaxFileSize = 0;
   memset(m_LogfilePath,'\0',sizeof(m_LogfilePath));
   memset(m_LogPrefix,'\0',sizeof(m_LogPrefix));
   m_LogMaxsize = 0;
   memset(m_ArchivalPath,'\0',sizeof(m_ArchivalPath));
   m_ToolEnabledFlag = 0;
   m_ToolPort = 0;
   m_StatisticsEnabledFlag = 0;
   m_SlotsInADay = 0;
   memset(m_StatisticsPath,'\0',sizeof(m_StatisticsPath));
   m_TracingEnabledFlag = 0;
   m_TracingLogLevel = 0;
   m_TracingLogMedia = 0;
   m_TracingMaxFileSize = 0;
   memset(m_TracingLogfilePath,'\0',sizeof(m_TracingLogfilePath));
   memset(m_TracingLogPrefix,'\0',sizeof(m_TracingLogPrefix));
   m_TracingLogMaxsize = 0;
   memset(m_TracingArchivalPath,'\0',sizeof(m_TracingArchivalPath));
   m_TdrEnabledFlag = 0;
   m_TdrLogLevel = 0;
   m_TdrLogMedia = 0;
   m_TdrMaxFileSize = 0;
   memset(m_TdrLogfilePath,'\0',sizeof(m_TdrLogfilePath));
   memset(m_TdrLogPrefix,'\0',sizeof(m_TdrLogPrefix));
   m_TdrLogMaxsize = 0;
   memset(m_TdrArchivalPath,'\0',sizeof(m_TdrArchivalPath));
   m_ConsoleMapPduPrintFlag = 0;
   m_ConsoleTcapPduPrintFlag = 0;
   memset(m_EntityName,'\0',sizeof(m_EntityName));
   memset(m_StackEntityName,'\0',sizeof(m_StackEntityName));
   m_InstanceId = 0;
   m_SnmpInterfaceEnabledFlag = 0;
   m_SnmpAgentPort = 0;
   memset(m_SnmpAgentIp,'\0',sizeof(m_SnmpAgentIp));
   m_ProvInterfaceEnabledFlag = 0;
   m_ProvListenPort = 0;
   m_ServerKeepAliveFlag = 0;  //6460
   m_LogTcapPduPrintFlag = 0;
   m_LogMapPduPrintFlag = 0;
   m_TdrTitleFlag = 0;

   m_MemcEnableFlag = 0;
   m_MemcPrimaryPort = 0;
   memset(m_MemcPrimaryIP,'\0',sizeof(m_MemcPrimaryIP));
   m_MemcDiffTimeTrapInterval = 0;
   m_MemcMaxReqQsize = 0;
}

ConfigData::~ConfigData()
{
}

string ConfigReader::readValue (string parent, string child)
{
   string n = Parser::getChildString (parent, child);
   string v = Parser::getValue (n, child);

   bool l_splitParameter=false;
   int l_lengthOfString = v.size();
   if (l_lengthOfString >= 2)
   {
      if ( (v.at(0) == '(') && (v.at(l_lengthOfString-1) != ')'))
      {
         ELOG(0,1,"ERROR!! No matching end brace in [%s]", child.c_str());
         printf("\nERROR!! No matching end brace in [%s]\n", child.c_str());
         v="";
         return v;
      }
      if ( (v.at(0) != '(') && (v.at(l_lengthOfString-1) == ')'))
      {
         ELOG(0,1,"ERROR!! No matching start brace in [%s]",  child.c_str());
         printf("\nERROR!! No matching start brace in [%s]",  child.c_str());
         v="";
         return v;
      }
      if ( (v.at(0) == '(') && (v.at(l_lengthOfString-1) == ')'))
      {
         DLOG(0,1,"Splitting into tokens [%s]", (char*)v.c_str());
         string l_toBeTokenized = ";" + v.substr(1, (l_lengthOfString-2)) + ";" ;
         DLOG(0,1,"Data : [%s]", (char*)l_toBeTokenized.c_str());

         char *ptr1, *ptr2;
         ptr1=ptr2=NULL;
         ptr1 = ptr2 = (char*)l_toBeTokenized.c_str();
         ptr2++;
         int l_totalRequests=0;
         while(*ptr2 != '\0')
         {
            if(';' == *ptr2)
            {
               if(ptr2-ptr1 == 1)
               {
                  DLOG(0,1,"Breaking from the loop");
                  break;
               }
               else
               {
                  DLOG(0,1,"finalizing a token");
                  l_totalRequests++;
                  char l_rowidChar[200+1];
                  memset(l_rowidChar, '\0', sizeof(l_rowidChar));
                  strncpy(l_rowidChar,ptr1+1,ptr2-ptr1-1);
                  TLOG(0,1,"Got a token [%s]", l_rowidChar);

                  if (g_ConfigIndex == l_totalRequests)
                  {
                     l_splitParameter=true;
                     v = l_rowidChar;
                     break;
                  }

                  ptr1=ptr2;
               }
            }
            ptr2++;
         }

         if (false == l_splitParameter)
         {
            ELOG(0,1, "Couldn't find the token for config index %d for parameter %s", g_ConfigIndex, (char*)child.c_str());
            printf("\nCouldn't find the token for config index %d for parameter %s\n\n", g_ConfigIndex, (char*)child.c_str());
            v="";
            //exit(600);
         }
      }
      else
      {
         DLOG(0,1,"Not matching the braces");
      }
   }

   /*if (v.size()==0)
     {
     v="-1";
     }*/
   return v;
}

/*s32 ConfigReader::convertToHex(s32 i)
  {
  switch(i)
  {
  case 0:
  return 0x0;
  case 1:
  return 0x1;
  case 2:
  return 0x2;
  case 3:
  return 0x3;
  case 4:
  return 0x4;
  case 5:
  return 0x5;
  case 6:
  return 0x6;
  case 7:
  return 0x7;
  case 8:
  return 0x8;
  case 9:
  return 0x9;
  case 10:
  return 0xa;
  case 11:
  return 0xb;
  case 12:
  return 0xc;
  case 13:
  return 0xd;
  case 14:
  return 0xe;
  case 15:
  return 0xf;
  }
  return 0x0;
  }*/
/*
   void ConfigReader::ipAddrToHex(char *dest, char *src)
   {
   char *ptr;
   s32 val = 0, i = 0;

   ptr = strtok(src, ".");
   if(NULL != ptr)
   {
   do
   {
   val = atoi(ptr);
   dest[i] = convertToHex(val%16);
   dest[i] |= (convertToHex(val/16)<<4);
   i++;
   } while(NULL != (ptr = strtok(NULL, ".")));
   }
   }*/


char *getLogLevel(int p_num)
{
   switch (p_num)
   {
      case LOG_LEVEL_DEBUG:
         return "DEBUG";
         break;
      case LOG_LEVEL_TRACE:
         return "TRACE";
         break;
      case LOG_LEVEL_LOAD:
         return "LOAD";
         break;
      case LOG_LEVEL_WARNING:
         return "WARNING";
         break;
      case LOG_LEVEL_CRITICAL:
         return "CRITICAL";
         break;
      case LOG_LEVEL_ERROR:
         return "ERROR";
         break;
      default:
         return "UNKNOWN";
         break;
   }
}

char *getLogFileWritingMode(char p_fwm)
{
   switch (p_fwm)
   {
      case 'I':
         return "Immediate";
         break;
      case 'B':
         return "Buffered";
         break;
      default:
         return "UNKNOWN";
         break;
   }
}

char *getLogMedia(int p_num)
{
   switch (p_num)
   {
      case LOG_MEDIA_FILE:
         return "FILE";
         break;
      case LOG_MEDIA_CONSOLE:
         return "CONSOLE";
         break;
      case LOG_MEDIA_RTPS:
         return "TO_RTPS";
         break;
      default:
         return "UNKNOWN";
         break;
   }
}

void ConfigReader::getModulesPrint(char **p_data)
{
   *p_data = new char[MAX_BUFFER_STRING];
   char *l_configDataChar = *p_data;
   memset(l_configDataChar, '\0', MAX_BUFFER_STRING);
   strcpy(l_configDataChar, "\n");

   char l_temp[2000];
   for (int l_i=1; l_i<MAX_MODULES; l_i++)
   {
      if (true == g_mm.m_modules[l_i].m_configPresent)
      {
         strlcat(l_configDataChar, "\n", MAX_BUFFER_STRING);

         memset(l_temp, '\0', sizeof(l_temp));
         sprintf(l_temp, "%s: \n\t", g_mm.m_modules[l_i].m_ModName);
         strlcat(l_configDataChar, l_temp, MAX_BUFFER_STRING);
         memset(l_temp, '\0', sizeof(l_temp));
         //(g_mm.m_modules[l_i].m_cr)->printConfigData(l_temp);
         (*(g_mm.m_modules[l_i].m_func()->retrieveConfigReaderPtr()))->printConfigData(l_temp);
         strlcat(l_configDataChar, l_temp, MAX_BUFFER_STRING);

         strlcat(l_configDataChar, "\n", MAX_BUFFER_STRING);
      }
   }
   return;
}

void printModuleData(char *p_data)
{
   sprintf(p_data, "\n     %-3s     %-30s   %-50s   %s", "NG", "pHSS-HLR", g_NgVersion, g_NgStartDate);

   DLOG(0,1,"start ");
   for (int l_i=1; l_i<MAX_MODULES; l_i++)
   {
      DLOG(0,1,"printModuleData:: start module loop");
      if (strlen(g_mm.m_modules[l_i].m_ModName)>0)
      {
         DLOG(0,1,"printModuleData:: start module matched");
         char l_loadTime[50];
         memset(l_loadTime, '\0', sizeof(l_loadTime));
         strcpy(l_loadTime, ctime((time_t *)&g_mm.m_modules[l_i].m_loadedTime));
         int len=strlen(l_loadTime);
         l_loadTime[len-1] = '\0';

         DLOG(0,1,"printModuleData:: start module time calculated");

         char l_tempChar[500];
         memset(l_tempChar, '\0', sizeof(l_tempChar));

         if (g_mm.m_modules[l_i].m_func != NULL)
         {
            DLOG(0,1,"printModuleData:: start module preparing data");
            DLOG(0,1,"printModuleData:: start module preparing data 1 [%s]", g_mm.m_modules[l_i].m_ModName);
            DLOG(0,1,"printModuleData:: start module preparing data 2 [%s]", g_mm.m_modules[l_i].m_LibName);
            if (NULL != g_mm.m_modules[l_i].m_func())
            {
               DLOG(0,1,"printModuleData:: start module preparing data 3 [%s]", g_mm.m_modules[l_i].m_func()->getVersion());
               sprintf(l_tempChar, "\n     %-3s     %-30s   %-50s   %s", 
                     g_mm.m_modules[l_i].m_ModName, 
                     g_mm.m_modules[l_i].m_LibName, 
                     g_mm.m_modules[l_i].m_func()->getVersion(),
                     l_loadTime);
            }
            else
            {
               DLOG(0,1,"printModuleData:: start module preparing data 3.");
               sprintf(l_tempChar, "\n     %-3s     %-30s   %-50s   %s", 
                     g_mm.m_modules[l_i].m_ModName, 
                     g_mm.m_modules[l_i].m_LibName, 
                     "VERSION",
                     l_loadTime);
            }

            DLOG(0,1,"printModuleData:: start module preparing data 4 [%s]", l_loadTime);



            DLOG(0,1,"printModuleData:: start module prepared data");
            strcat(p_data, l_tempChar);
         }
         else
         {
            printf("\nhey some error\n");
            ELOG(0,1,"some error");
         }

      }
   }
   DLOG(0,1,"printModuleData:: returning");
}

#define MAX_TMP_CHAR_SIZE 10000

char* getMemCachedServerList(vector<MemCacheAddress> *p_vec)
{
   char *g_tmpChar = new char[MAX_TMP_CHAR_SIZE + 1];
   memset(g_tmpChar, '\0', sizeof(g_tmpChar));
   char l_tmp[10000 + 1];
   snprintf(g_tmpChar, sizeof(l_tmp),"(%d) ", (int)p_vec->size());
   vector<MemCacheAddress> :: iterator l_It;
   int l_i=1;
   for(l_It = p_vec->begin(); l_It != p_vec->end(); l_It++)
   {
      memset(l_tmp,'\0',sizeof(l_tmp));
      snprintf(l_tmp,sizeof(l_tmp), "\n\t\t\t(%d) : IP:%s  PORT:%d",l_i,l_It->MCServerIp.c_str(),l_It->MCServerPort);
      strlcat(g_tmpChar, l_tmp, MAX_TMP_CHAR_SIZE);
      l_i++;
   }
   return g_tmpChar;
}

char *ConfigReader::getConfigPrint(int p_page)
{
   char *l_configDataChar = new char[MAX_BUFFER_STRING];
   memset(l_configDataChar, '\0', MAX_BUFFER_STRING);
   strcpy(l_configDataChar, "\n");


   char l_temp[10000];
   memset(l_temp, '\0', 10000);


   sprintf(l_temp, " \t\t\t\t\t\t     Entity (%s)                         [Status: %s]\n", g_ConfigData->m_StackEntityName,
         (true==g_DbCongestionStatus)?"CONGESTED":"NO CONGESTION");
   strlcat(l_configDataChar, l_temp, MAX_BUFFER_STRING);

   if((0 == p_page) || (1 == p_page))
   {
      sprintf(l_temp, "     %-6s  %-30s    %-50s  %s\n", "Module", "File", "Compiled Date          Version", "Loaded Date");
      strlcat(l_configDataChar, l_temp, MAX_BUFFER_STRING);

      sprintf(l_temp, "     %-6s  %-30s    %-50s  %s",   "------", "----", "-------------          -------", "-----------");
      strlcat(l_configDataChar, l_temp, MAX_BUFFER_STRING);

      memset(g_versionsArr, '\0', sizeof(g_versionsArr));
      printModuleData(g_versionsArr);
      sprintf(l_temp, "%s\n", g_versionsArr);
      strlcat(l_configDataChar, l_temp, MAX_BUFFER_STRING);

      sprintf(l_temp, "    ------------------------------------------------------------------------------------------------------------------------\n\n");
      strlcat(l_configDataChar, l_temp, MAX_BUFFER_STRING);
   }

   if((0 == p_page) || (2 == p_page))
   {
      if(NULL == g_gui)
      {
         sprintf(l_temp, "| Loggers\t\t: (APP)  Level:%s  Media:%s  Mode:%s  RotMaxFiles:%d  Path:%s  Prefix:%s  MaxSize:%ld  WriteMech:%s",
               getLogLevel(g_ConfigData->m_LogLevel),
               getLogMedia(g_ConfigData->m_LogMedia),
               (0==g_OtherConfigData->m_LogFileRotatingType)?"Normal":"Rotate",
               g_OtherConfigData->m_LogFileMaxFiles,
               g_ConfigData->m_LogfilePath,
               g_ConfigData->m_LogPrefix,
               g_ConfigData->m_LogMaxsize,
               getLogFileWritingMode(g_OtherConfigData->m_logFlag));
      }
      else
      {
         sprintf(l_temp, "| Loggers\t\t: GEN-UTIL  %s", g_gui->getConfigStr().c_str());
      }
      strlcat(l_configDataChar, l_temp, MAX_BUFFER_STRING);

      sprintf(l_temp, "\n| Database\t\t: %s  PoolSize:%d  NodeCount:%d  RetryMechanism:%s  HeartBeatFlag:%s  HeartBeatInterval:%ds  InitialQueryDBTPS:%d  LaterQueryPoolSize:%d  LaterQueryDbTPS:%d",
            (g_ConfigData->i_DbConfigData.m_DbRequired==1?"ENABLED ":"DISABLED"),
            g_ConfigData->i_DbConfigData.m_PoolSizeRequired,
            g_ConfigData->i_DbConfigData.m_NoOfNodes,
            ('R'==g_OtherConfigData->m_DbFailedConnectionRetryType?"Retry":('S'==g_OtherConfigData->m_DbFailedConnectionRetryType)?"Switchover":"None"),
            (1==g_OtherConfigData->m_DbHeartBeatRequiredFlag)?"ENABLED":"DISABLED", g_OtherConfigData->m_DbHeartBeatInterval,
            g_OtherConfigData->m_DbThresholdTps,
            g_OtherConfigData->m_LaterQueryPoolSizeRequired,
            g_OtherConfigData->m_LaterQueryDbTps);
      strlcat(l_configDataChar, l_temp, MAX_BUFFER_STRING);

      if(g_ConfigData->i_DbConfigData.m_NoOfNodes <= 4)
      {
         sprintf(l_temp, "\n|    \t\t\t:           Conn1:%s  Conn2:%s  Conn3:%s  Conn4:%s",
               ('\0'==g_OtherConfigData->m_DbAliasStringArr[0][0])?"NA":g_OtherConfigData->m_DbAliasStringArr[0],
               ('\0'==g_OtherConfigData->m_DbAliasStringArr[1][0])?"NA":g_OtherConfigData->m_DbAliasStringArr[1],
               ('\0'==g_OtherConfigData->m_DbAliasStringArr[2][0])?"NA":g_OtherConfigData->m_DbAliasStringArr[2],
               ('\0'==g_OtherConfigData->m_DbAliasStringArr[3][0])?"NA":g_OtherConfigData->m_DbAliasStringArr[3]);
         strlcat(l_configDataChar, l_temp, MAX_BUFFER_STRING);
      }
      else
      {
         for(int l_i=0; l_i<=g_ConfigData->i_DbConfigData.m_NoOfNodes; l_i++)
         {
            LLOG(0,1,"Conn%02d: %s", l_i, g_OtherConfigData->m_DbAliasStringArr[l_i]);
         }
      }

      sprintf(l_temp, "\n|         \t\t:           ErrorCodes:  %s", g_ConfigData->i_DbConfigData.m_OraErrorCodes);
      strlcat(l_configDataChar, l_temp, MAX_BUFFER_STRING);

      sprintf(l_temp, "\n| Memcached\t\t: %s  MemcDiffTimeTrapInterval:%ds  MemcMaxRequestQueueSize:%d ServerCount:%d\n\t\t\t ServerList:%s",
            (g_ConfigData->m_MemcEnableFlag==1?"ENABLED ":"DISABLED"),
            g_ConfigData->m_MemcDiffTimeTrapInterval,
            g_ConfigData->m_MemcMaxReqQsize,
            g_ConfigData->m_MemCacheAddrVector.size(),
            getMemCachedServerList(&g_ConfigData->m_MemCacheAddrVector));
      strlcat(l_configDataChar, l_temp, MAX_BUFFER_STRING);

      sprintf(l_temp, "\n| MMI Tool \t\t: %s  Port:%d", 
            (g_ConfigData->m_ToolEnabledFlag==1?"ENABLED ":"DISABLED"), g_ConfigData->m_ToolPort);
      strlcat(l_configDataChar, l_temp, MAX_BUFFER_STRING);

      sprintf(l_temp, "\n| Statistics\t\t: %s  Slots:%d  Path:%s", 
            (g_ConfigData->m_StatisticsEnabledFlag==1?"ENABLED ":"DISABLED"), 
            g_ConfigData->m_SlotsInADay,
            g_ConfigData->m_StatisticsPath);
      strlcat(l_configDataChar, l_temp, MAX_BUFFER_STRING);

      sprintf(l_temp, "\n| SNMP\t\t\t: %s  AgentIP:%s  AgentPort:%d  ThreadHeartBeat:%s", 
            (g_ConfigData->m_SnmpInterfaceEnabledFlag==1?"ENABLED ":"DISABLED"), 
            g_ConfigData->m_SnmpAgentIp,
            g_ConfigData->m_SnmpAgentPort,
            (g_OtherConfigData->m_THBEnabled==1?"ENABLED ":"DISABLED"));
      strlcat(l_configDataChar, l_temp, MAX_BUFFER_STRING);

      sprintf(l_temp, "\n| Provisioning\t\t: %s  ListenPort:%d  InitiatingMapTransactionsTransmissionRate:%d  \n\t\t\t\t    ThresholdForInitiatingTrans:%d  MaxProfFailureDuration:%d ImeiEncFlag:%d \n\t\t\t\t    ClientIdleTimeout[%d] ClientIdleTimeoutExclusionList[%s] \n\t\t\t\t    MaxActiveConnections[%d] MaxActiveThreshold[%d] ServerKeepAliveFlag[%d]", 
            (g_ConfigData->m_ProvInterfaceEnabledFlag==1?"ENABLED ":"DISABLED"), 
            g_ConfigData->m_ProvListenPort,
            g_OtherConfigData->m_MaxProvInitiatingTransactions,
            g_OtherConfigData->m_ThresholdDialogsForInitiatingTransactions,
            g_OtherConfigData->m_ProfilesFailureDuration,g_IMEI_EncrFlag,
            g_OtherConfigData->m_clientIdleTimeout,g_OtherConfigData->m_clientIdleTimeoutExceptionList,
            g_OtherConfigData->m_MaxActiveConnections,g_OtherConfigData->m_conn_fd_thresh_percentage,
            g_ConfigData->m_ServerKeepAliveFlag
            );
      strlcat(l_configDataChar, l_temp, MAX_BUFFER_STRING);

      sprintf(l_temp, "\n| Subscriber Tracing \t: %s  Level:%s  Media:%s  Path:%s  Prefix:%s  MaxSize:%ld",
            (g_ConfigData->m_TracingEnabledFlag==1?"ENABLED ":"DISABLED"),
            getLogLevel(g_ConfigData->m_TracingLogLevel),
            getLogMedia(g_ConfigData->m_TracingLogMedia),
            g_ConfigData->m_TracingLogfilePath,
            g_ConfigData->m_TracingLogPrefix,
            g_ConfigData->m_TracingLogMaxsize);
      strlcat(l_configDataChar, l_temp, MAX_BUFFER_STRING);

      sprintf(l_temp, "\n| TDR\t\t\t: %s  Media:%s  Path:%s  Prefix:%s  MaxSize:%ld",
            (g_ConfigData->m_TdrEnabledFlag==1?"ENABLED ":"DISABLED"),
            getLogMedia(g_ConfigData->m_TdrLogMedia),
            g_ConfigData->m_TdrLogfilePath,
            g_ConfigData->m_TdrLogPrefix,
            g_ConfigData->m_TdrLogMaxsize);
      strlcat(l_configDataChar, l_temp, MAX_BUFFER_STRING);

      sprintf(l_temp, "\n|    \t\t\t:           RTPS-IP:%s  RTPS-Port:%d   MaxRtpsDownTime:%d",
            g_OtherConfigData->m_TdrRtpsIp,
            g_OtherConfigData->m_TdrRtpsPort,
            g_OtherConfigData->m_MaxRtpsDowntime);
      strlcat(l_configDataChar, l_temp, MAX_BUFFER_STRING);

      sprintf(l_temp, "\n| SCCP Stack \t\t: %s  StackName:%s  SSN:%d  SccpType:%s  TTCalledParty:%d DEBUG_LOG_LEVEL:%d ROUTING_HLR_ADDRESS:%s", 
            (1 == g_OtherConfigData->m_SCCPStackFlag)?"ENABLED ":"DISABLED", 
            g_OtherConfigData->m_StackName,
            g_OtherConfigData->m_localSSN,
            ('I'==g_OtherConfigData->m_Sccp_Type[0])?"ITU":"ANSI",
            g_OtherConfigData->m_TTCalledParty,
            g_OtherConfigData->m_DebugLogLevel,
            g_OtherConfigData->m_RoutingHlrAddress);
      strlcat(l_configDataChar, l_temp, MAX_BUFFER_STRING);

      sprintf(l_temp, "\n| TCAP Stack \t\t: %s  Name:%s  MaxDialogs:%d  PreserveSccpClass:%d  SccpType:%s  AnsiSccpNI:%s  TT:%d SCCPMsgHandlerParam:%d", 
            (1 == g_OtherConfigData->m_TCAPStackFlag)?"ENABLED ":"DISABLED", 
            g_ConfigData->i_NgConfigData.m_StackName,
            g_ConfigData->i_NgConfigData.m_MaxDialogs,
            g_OtherConfigData->m_PreserveSccpClass,
            ('I'==g_OtherConfigData->m_SccpType)?"ITU":"ANSI",
            ('I'==g_OtherConfigData->m_SccpType)?"NA":('I'==g_OtherConfigData->m_AnsiNationalIndicator?"Intl":"Ntl"),
            g_OtherConfigData->m_TT,
            g_OtherConfigData->m_sccpMsgHandlerParam);
      strlcat(l_configDataChar, l_temp, MAX_BUFFER_STRING);

      sprintf(l_temp, "\n| GT Translation \t: %s", 
            (g_OtherConfigData->m_GtTranslationRequiredFlag==1?"ENABLED ":"DISABLED"));
      strlcat(l_configDataChar, l_temp, MAX_BUFFER_STRING);

      if(1 == g_OtherConfigData->m_GtTranslationRequiredFlag)
      {
         map<char*, char*>::iterator l_it;
         for(l_it = g_OtherConfigData->m_GtTranslationMap.begin();l_it != g_OtherConfigData->m_GtTranslationMap.end(); ++l_it)
         {
            char l_current[100];
            memset(l_current, '\0', sizeof(l_current));
            sprintf(l_current, "  From: %s To: %s", l_it->first, l_it->second);
            strlcat(l_configDataChar, l_current, MAX_BUFFER_STRING);
         }
      }

      sprintf(l_temp, "\n| Partner Translation   : %s", 
            (g_OtherConfigData->m_ExtTranslationRequiredFlag==1?"ENABLED ":"DISABLED"));
      strlcat(l_configDataChar, l_temp, MAX_BUFFER_STRING);

      if(1 == g_OtherConfigData->m_ExtTranslationRequiredFlag)
      {
         map<char*, char*>::iterator l_it;
         for(l_it = g_OtherConfigData->m_ExtTranslationMap.begin();l_it != g_OtherConfigData->m_ExtTranslationMap.end(); ++l_it)
         {
            char l_current[100];
            memset(l_current, '\0', sizeof(l_current));
            sprintf(l_current, "  CCNDC: %s GT: %s", l_it->first, l_it->second);
            strlcat(l_configDataChar, l_current, MAX_BUFFER_STRING);
         }
      }

      //sprintf(l_temp, "\n| DIAMETER Stack \t: %s  IP:%s  Port:%d  ClientId:%d  ApplId:%d  AdditionalAppId:%d \n\t\t\t\t    ConnType:%s  BackIP:%s  BackPort:%d  RejectType:%s",
      sprintf(l_temp, "\n| DIAMETER Stack \t: %s  IP:%s  Port:%d  ClientId:%d  ApplId:%d  AdditionalAppId:%d \n\t\t\t\t    ConnType:%s  BackIP:%s  BackPort:%d  RejectType:%s DiamSuspendResumeFeature:%d DiameterInterfaceType:%s \n\t\t\t\t DiastackLoggingFlag: %d DiastackLogsForDebuggingFlag: %s DiastackLogLevel:%s", 
            (1 == g_OtherConfigData->m_dcd.m_diameterNgRequired)?"ENABLED ":"DISABLED",
            g_OtherConfigData->m_dcd.m_diamPrimaryIpAddress,
            g_OtherConfigData->m_dcd.m_diamPrimaryIpPort,
            g_OtherConfigData->m_dcd.m_clientId,
            g_OtherConfigData->m_dcd.m_applicationId,
            g_OtherConfigData->m_dcd.m_additionalAppId,
            (g_OtherConfigData->m_dcd.m_connectionType=='S'?"SINGLE":"REDUNDANT"),
            g_OtherConfigData->m_dcd.m_diamBackupIpAddress,
            g_OtherConfigData->m_dcd.m_diamBackupIpPort,
            g_OtherConfigData->m_DiameterMessageRejectionType=='E'?"Error":"Normal",
            g_OtherConfigData->m_DiamSuspendResumeFeature,
            g_OtherConfigData->m_DiameterInterfaceType,
            g_OtherConfigData->m_dcd.m_DiastackLoggingFlag,
            g_OtherConfigData->m_dcd.m_LogsForDebugging,
            g_OtherConfigData->m_dcd.m_logLevel.c_str());
      strlcat(l_configDataChar, l_temp, MAX_BUFFER_STRING);

      sprintf(l_temp, "\n|    \t\t\t:           OrigHost:%s  OrigRealm:%s  DestHost:%s  DestRealm:%s",
            g_OtherConfigData->m_dcd.m_originHost,
            g_OtherConfigData->m_dcd.m_originRealm,
            g_OtherConfigData->m_dcd.m_destinationHost,
            g_OtherConfigData->m_dcd.m_destinationRealm);
      strlcat(l_configDataChar, l_temp, MAX_BUFFER_STRING);
      sprintf(l_temp, "\n\t\t\t\t    ApplId: %d ", g_OtherConfigData->m_dcd.m_applicationId);
      strlcat(l_configDataChar, l_temp, MAX_BUFFER_STRING);

      for(int AppCount =0 ; AppCount< g_OtherConfigData->m_dcd.m_additionalAppIdcount; AppCount++)
      {
         sprintf(l_temp, "\t AdditionalAppId[%d ]:%d \t ",AppCount+1, g_OtherConfigData->m_dcd.m_additionalAppId[AppCount]);
         strlcat(l_configDataChar, l_temp, MAX_BUFFER_STRING);
      }
      //printf("\n ### configdatachar[%d]\n",strlen(l_configDataChar));

#if 0
      sprintf(l_temp, "\n| SMPP\t\t\t: %s  SmscIP:%s  SmscPort:%d  BindTON:%d  BindNPI:%d  SubmitTON:%d", 
            (g_ConfigData->m_EsmeConfigData.m_Required==1?"ENABLED ":"DISABLED"), 
            g_ConfigData->m_EsmeConfigData.m_SMPP_IPAddress,
            g_ConfigData->m_EsmeConfigData.m_SMPP_Port,
            g_ConfigData->m_EsmeConfigData.m_BindTON,
            g_ConfigData->m_EsmeConfigData.m_BindNPI,
            g_ConfigData->m_EsmeConfigData.m_SubmitTON);
      strlcat(l_configDataChar, l_temp, MAX_BUFFER_STRING);
#endif

      sprintf(l_temp, "\n|     \t\t\t:           SystemId:%s  Pass:%s  SystemType:%s  ConsolePrint:%s  ServiceType:%s  SourceAddr:%s", 
            g_ConfigData->m_EsmeConfigData.m_System_Id,
            g_ConfigData->m_EsmeConfigData.m_Password,
            g_ConfigData->m_EsmeConfigData.m_System_Type,
            (g_ConfigData->m_EsmeConfigData.m_PrintPdu==1?"1":"0"),
            g_ConfigData->m_EsmeConfigData.m_serviceType,
            g_ConfigData->m_EsmeConfigData.m_sourceAddr);
      strlcat(l_configDataChar, l_temp, MAX_BUFFER_STRING);

      sprintf(l_temp, "\n| Prints\t\t:           CONSOLE-MAP-PDU:%s LOG-MAP-PDU:%s CONSOLE-TCAP-PDU:%s LOG-TCAP-PDU:%s", 
            (g_ConfigData->m_ConsoleMapPduPrintFlag==1)?"ENABLED ":"DISABLED",
            (g_ConfigData->m_LogMapPduPrintFlag==1)?"ENABLED ":"DISABLED",
            (g_ConfigData->m_ConsoleTcapPduPrintFlag==1)?"ENABLED ":"DISABLED",
            (g_ConfigData->m_LogTcapPduPrintFlag==2)?"COMPACT ":(g_ConfigData->m_LogTcapPduPrintFlag==1)?"FULL ":"DISABLED");
      strlcat(l_configDataChar, l_temp, MAX_BUFFER_STRING);

      char l_pduChar[20+1];
      if(g_OtherConfigData->m_dcd.m_diamterPduPrintType=='C')
      {
         snprintf(l_pduChar, sizeof(l_pduChar), "CONSOLE");
      }
      else if(g_OtherConfigData->m_dcd.m_diamterPduPrintType=='L')
      {
         snprintf(l_pduChar, sizeof(l_pduChar), "LOGS");
      }
      else if(g_OtherConfigData->m_dcd.m_diamterPduPrintType=='B')
      {
         snprintf(l_pduChar, sizeof(l_pduChar), "BOTH");
      }
      else 
      {
         snprintf(l_pduChar, sizeof(l_pduChar), "DISABLED");
      }
      sprintf(l_temp, "\n|       \t\t:           DIAMETER-PDU:%s  LOG-POLLING-LOOPS:%s", l_pduChar,
            (g_OtherConfigData->m_PrintTimerInLog==1)?"ENABLED ":"DISABLED");
      strlcat(l_configDataChar, l_temp, MAX_BUFFER_STRING);

      size_t l_stringLen = 1000;
      char l_string[ 1000+1];

      memset(l_string, '\0', 1000+1);
      sccpDumpStructureAddressToString (l_string, &l_stringLen, (SccpAddress*)&(g_ConfigData->i_NgConfigData.m_selfAddress));
      sprintf(l_temp, "\n| %-20s\t:           %s", "Self Address", l_string);
      strlcat(l_configDataChar, l_temp, MAX_BUFFER_STRING);


      if( (strlen(g_ConfigData->i_NgConfigData.m_remoteAddress1.globalTitle.addressInformation) > 0) ||
            (g_ConfigData->i_NgConfigData.m_remoteAddress1.ssn > 0)
        )
      {
         l_stringLen = 1000;
         memset(l_string, '\0', 1000+1);
         sccpDumpStructureAddressToString (l_string, &l_stringLen, (SccpAddress*)&(g_ConfigData->i_NgConfigData.m_remoteAddress1));
         sprintf(l_temp, "\n| %-20s\t: %s", "Addr 1", l_string);
         strlcat(l_configDataChar, l_temp, MAX_BUFFER_STRING);
      }


      if( (strlen(g_ConfigData->i_NgConfigData.m_remoteAddress2.globalTitle.addressInformation) > 0) ||
            (g_ConfigData->i_NgConfigData.m_remoteAddress2.ssn > 0)
        )
      {
         l_stringLen = 1000;
         memset(l_string, '\0', 1000+1);
         sccpDumpStructureAddressToString (l_string, &l_stringLen, (SccpAddress*)&(g_ConfigData->i_NgConfigData.m_remoteAddress2));
         sprintf(l_temp, "\n| %-20s\t: %s", "Addr 2", l_string);
         strlcat(l_configDataChar, l_temp, MAX_BUFFER_STRING);
      }

      sprintf(l_temp, "\n| Congestion Control \t: %s      MaxDbRequestQueueSize:%d  MaxLaterDbRequesQueueSize:%d  MaxIncomingTransPerSec:%d  OverloadRejectionType:%s  TrapInterval:%d DiamMaxQueueSize:%d  DiamMinQueueSize:%d",
            getCongestionControlType(g_cc.m_controlType[0]),
            g_cc.m_maxActiveIncomingDialogues,
            g_cc.m_maxActiveLaterQueueSize,
            g_cc.m_maxIncomingTransactionsPerSec,
            ((g_cc.m_overloadTransactionsRejectType[0]=='A')?"ABORT":((g_cc.m_overloadTransactionsRejectType[0]=='I')?"Ignore":"SystemFailure")),
            g_cc.m_trapInterval,
            g_OtherConfigData->m_DiameterMaxQueueSize,
            g_OtherConfigData->m_DiameterMinQueueSize);
      strlcat(l_configDataChar, l_temp, MAX_BUFFER_STRING);

      char l_priorityChar[100];
      char l_currentPriortyChar[10];
      memset(l_priorityChar, '\0', sizeof(l_priorityChar));
      for (int l_i=1; l_i<=g_cc.m_priorityHandling; l_i++)
      {
         sprintf(l_currentPriortyChar, "Priority%d(%d%%) ", l_i, g_cc.m_priorityPercentages[l_i]);
         strlcat(l_priorityChar, l_currentPriortyChar, sizeof(l_priorityChar));
      }


      sprintf(l_temp, "\n|                       :           NumOfPriorities(%d)  %s", g_cc.m_priorityHandling, l_priorityChar);
      strlcat(l_configDataChar, l_temp, MAX_BUFFER_STRING);

      sprintf(l_temp, "\n|\n| Supported Application Contexts: \n|    ");
      strlcat(l_configDataChar, l_temp, MAX_BUFFER_STRING);

      int l_totContexts=0;
      for (int i=0; i<50; i++)
      {
         if (true == g_ConfigData->i_NgConfigData.m_ApplSupportedMap[i])
         {
            l_totContexts++;
            sprintf(l_temp, "AC(%02d):%d-%d:P%d, ", 
                  i, 
                  g_ConfigData->i_NgConfigData.m_ApplSupportedMinVersion[i],
                  g_ConfigData->i_NgConfigData.m_ApplSupportedMaxVersion[i],
                  g_ApplContextPriority[i]);
            strlcat(l_configDataChar, l_temp, MAX_BUFFER_STRING);

            if (l_totContexts%8==0)
            {
               strlcat(l_configDataChar, "\n|    ", MAX_BUFFER_STRING);
            }
         }
      }
      sprintf(l_temp, "\n| Supported MAP Operations: \n|    ");
      strlcat(l_configDataChar, l_temp, MAX_BUFFER_STRING);

      int l_totOps=0;
      for (int i=0; i<MAX_OP_CODES; i++)
      {
         if (g_mm.m_mapping[MSG_TYPE_MAP][i].m_OpCode > 0)
         {
            l_totOps++;
            sprintf(l_temp, "%s: %02d-%s:v%d%d%d:t%d, ", 
                  g_mm.m_mapping[MSG_TYPE_MAP][i].m_ModName,
                  i>100?i-100:i, 
                  g_mm.m_mapping[MSG_TYPE_MAP][i].m_MessageName, 
                  g_mm.m_mapping[MSG_TYPE_MAP][i].m_Map1Flag,
                  g_mm.m_mapping[MSG_TYPE_MAP][i].m_Map2Flag,
                  g_mm.m_mapping[MSG_TYPE_MAP][i].m_Map3Flag,
                  g_mm.m_mapping[MSG_TYPE_MAP][i].m_tdrRequiredFlag);


            strlcat(l_configDataChar, l_temp, MAX_BUFFER_STRING);

            if (l_totOps%5==0)
            {
               strlcat(l_configDataChar, "\n|    ", MAX_BUFFER_STRING);
            }
         } 
      }


      sprintf(l_temp, "\n| Supported DIAMETER Commands: \n|    ");
      strlcat(l_configDataChar, l_temp, MAX_BUFFER_STRING);

      l_totOps=0;
      //for (int i=DIAM_COMM_CODE_GX_RX_RAR_RAA; i<=DIAM_COMM_CODE_S13_MICR_MICA; i++)   
      for (int i=DIAM_COMM_CODE_S6A_S6D_ULR_ULA; i<=DIAM_COMM_CODE_S6A_S6D_NOR_NOA; i++)
      {
         if (g_mm.m_mapping[MSG_TYPE_DIAMETER][i].m_OpCode > 0)
         {
            l_totOps++;
            sprintf(l_temp, "%s: %02d-%s:t%d, ", 
                  g_mm.m_mapping[MSG_TYPE_DIAMETER][i].m_ModName,
                  i, 
                  g_mm.m_mapping[MSG_TYPE_DIAMETER][i].m_MessageName, 
                  g_mm.m_mapping[MSG_TYPE_DIAMETER][i].m_tdrRequiredFlag);


            strlcat(l_configDataChar, l_temp, MAX_BUFFER_STRING);

            if (l_totOps%6==0)
            {
               strlcat(l_configDataChar, "\n|    ", MAX_BUFFER_STRING);
            }
         } 
      }
      for (int i=350; i<=350; i++)
      {
         if (g_mm.m_mapping[MSG_TYPE_DIAMETER][i].m_OpCode > 0)
         {
            l_totOps++;
            sprintf(l_temp, "%s: %02d-%s:t%d, ", 
                  g_mm.m_mapping[MSG_TYPE_DIAMETER][i].m_ModName,
                  i, 
                  g_mm.m_mapping[MSG_TYPE_DIAMETER][i].m_MessageName, 
                  g_mm.m_mapping[MSG_TYPE_DIAMETER][i].m_tdrRequiredFlag);


            strlcat(l_configDataChar, l_temp, MAX_BUFFER_STRING);

            if (l_totOps%6==0)
            {
               strlcat(l_configDataChar, "\n|    ", MAX_BUFFER_STRING);
            }
         } 
      }
      strlcat(l_configDataChar, "\n", MAX_BUFFER_STRING);
   }
   //printHexDump("HEX_DATA_1", g_ConfigData->i_NgConfigData.m_HexData1.m_value, g_ConfigData->i_NgConfigData.m_HexData1.m_length);
   //printHexDump("HEX_DATA_2", g_ConfigData->i_NgConfigData.m_HexData2.m_value, g_ConfigData->i_NgConfigData.m_HexData2.m_length);
   //printHexDump("HEX_DATA_3", g_ConfigData->i_NgConfigData.m_HexData3.m_value, g_ConfigData->i_NgConfigData.m_HexData3.m_length);
   return l_configDataChar;
}




bool reloadModule(char *p_module, char *p_file, char *p_responseToBeSent)
{
   //printModuleData(g_versionsArr);

   bool l_moduleFoundFlag=false;
   fptr_mod l_funcPtr = NULL;

   for (int l_i=1; l_i<MAX_MODULES; l_i++)
   {
      if (0 == strcmp(g_mm.m_modules[l_i].m_ModName, p_module))
      {
         l_moduleFoundFlag=true;

         string l_func = "getModuleObj";
         EDllResult l_result;
         char l_error[1000];
         memset(l_error, '\0', 1000);

         l_funcPtr = g_mm.getContextFptr_mod(p_file, l_func.c_str(), &l_result, l_error);
         if (l_funcPtr == NULL)
         {
            switch (l_result)
            {
               case DLL_RESULT_DLL_NOT_FOUND:
                  sprintf(p_responseToBeSent, "Library [%s] LOADING FAILED. Error :: [%s]", g_mm.m_modules[l_i].m_LibName, l_error);
                  return false;
                  break;

               case DLL_RESULT_FUNC_NOT_FOUND:
                  sprintf(p_responseToBeSent, "Function [%s] NOT LOCATED. Error :: [%s]", l_func.c_str(), l_error);
                  return false;
                  break;

               default:
                  sprintf(p_responseToBeSent, "NOT LOCATED");
                  return false;
                  break;
            }
         }
         else
         {
            strcpy(g_mm.m_modules[l_i].m_LibName, p_file);

            //Update the Ptr in the Modules List
            g_mm.m_modules[l_i].m_func = l_funcPtr;
            g_mm.m_modules[l_i].m_loadedTime = time(NULL);
         }

         if (true == g_mm.m_modules[l_i].m_configPresent)
         {
            ConfigReader *l_cr = NULL;
            l_cr = l_funcPtr()->getConfigReaderObj();
            if (l_cr != NULL)
            {
               l_cr->setConfigName((char*)(g_mm.m_modules[l_i].m_file));

               bool l_status = l_cr->init();
               if (!l_status)
               {
                  CLOG(0,0,"ERROR!! Initialization of Configuration file [%s] failed", g_mm.m_modules[l_i].m_file);
                  return false;
               }

               //printf("\nReading Data");
               l_status = l_cr->readData();
               if (!l_status)
               {
                  CLOG(0,0,"ERROR!! Reading Data of Configuration file [%s] failed", g_mm.m_modules[l_i].m_file);
                  return false;
               }

               l_cr->m_lastUpdateDate = time(NULL);

               char test[2000];
               memset(test, '\0', 2000);
               ((NgConfigReader*)l_cr)->printConfigData(test);

               g_mm.m_modules[l_i].m_cr = l_cr;
            }

         }

         //Module Found. Break
         break;
      }
   }



   if (true == l_moduleFoundFlag)
   {



      //Update the Ptr in the Opcode List
      for (int l_i=0; l_i<MAX_OP_CODES; l_i++)
      {
         if (0 == strcmp(g_mm.m_mapping[MSG_TYPE_MAP][l_i].m_ModName, p_module))
         {
            LLOG(0,1,"Updating for module %s at index: %d", p_module, l_i);
            g_mm.m_mapping[MSG_TYPE_MAP][l_i].m_func = l_funcPtr;
            g_mm.m_mapping[MSG_TYPE_MAP][l_i].m_loadedTime = time(NULL);
         }
      }


      //Update the Ptr in the Config List

      sprintf(p_responseToBeSent, "%s module successfully reloaded.", p_module);
      //memset(g_versionsArr, '\0', sizeof(g_versionsArr));
      //printModuleData(g_versionsArr);

      return true;
   }
   else
   {
      sprintf(p_responseToBeSent, "%s module not found", p_module);
   }
   return true;
}


bool reloadConfigurations(char *p_module, char *p_responseToBeSent)
{
   bool l_moduleFound=false;
   bool l_configPresent=false;
   for (int l_i=0; l_i<MAX_OP_CODES; l_i++)
   {
      if (0 == strcmp(g_mm.m_modules[l_i].m_ModName, p_module))
      {
         l_moduleFound=true;
         if (true == g_mm.m_modules[l_i].m_configPresent)
         {
            l_configPresent=true;
            ConfigReader *l_cr = g_mm.m_modules[l_i].m_cr;

            char l_previousConfData[2000];
            memset(l_previousConfData, '\0', sizeof(l_previousConfData));
            l_cr->printConfigData(l_previousConfData);

            LLOG(0,1,"Loading configuration file for module :%s %s", g_mm.m_modules[l_i].m_ModName, g_mm.m_modules[l_i].m_file);
            bool l_status = false;

            ConfigReader *l_currentCr=NULL;
            l_currentCr = (g_mm.m_modules[l_i].m_func)()->getConfigReaderObj();
            g_mm.m_modules[l_i].m_cr = l_currentCr;
            l_currentCr->setConfigName(g_mm.m_modules[l_i].m_file);
            l_status = l_currentCr->init();
            if (false == l_status)
            {
               ELOG(0,1,"Reloading of configuration file failed at reading (Failed in loading the file)");
               sprintf(p_responseToBeSent, "Reload of %s failed (Failed in loading the file)", g_mm.m_modules[l_i].m_ModName);
               *((g_mm.m_modules[l_i].m_func)()->retrieveConfigReaderPtr()) = l_cr;
               g_mm.m_modules[l_i].m_cr = l_cr;
               return false;
               //break;
            }
            LLOG(0,1,"init success for module :%s", g_mm.m_modules[l_i].m_ModName);

            l_status = l_currentCr->readData();
            if (false == l_status)
            {
               ELOG(0,1,"Reloading of %s configuration file failed (Failed in reading parameters)", g_mm.m_modules[l_i].m_ModName);
               sprintf(p_responseToBeSent, "Reload of %s failed (Failed in reading parameters)", g_mm.m_modules[l_i].m_ModName);
               *((g_mm.m_modules[l_i].m_func)()->retrieveConfigReaderPtr()) = l_cr;
               g_mm.m_modules[l_i].m_cr = l_cr;
               return false;
               //break;
            }
            l_currentCr->m_lastUpdateDate = time(NULL);
            LLOG(0,1,"readData success for module :%s", g_mm.m_modules[l_i].m_ModName);

            char l_currentConfData[2000];
            memset(l_currentConfData, '\0', sizeof(l_currentConfData));
            g_mm.m_modules[l_i].m_cr->printConfigData(l_currentConfData);


            //Delete the old cr

            if(l_cr)
            {
               LLOG(0,1,"Deleting the old config object");
               delete(l_cr);
            }
            sprintf(p_responseToBeSent, "Reloading of %s module's configuration done. \n\n  Previous Configuration Data:\n\t%s\n\n  Current Configuration Data:\n\t%s", 
                  p_module, l_previousConfData, l_currentConfData);
            return true;
         }
      }
   }
   if (false == l_moduleFound)
   {
      sprintf(p_responseToBeSent, "%s module not found", p_module);
   }
   else if (false == l_configPresent)
   {
      sprintf(p_responseToBeSent, "No configuration file present for the %s module", p_module);
   }
   return true;
}


bool GetNetworkHlrAddr(u8* p_NetworkHlrAddr, u8 *p_OriginalHlrAddr)
{
   if(g_OtherConfigData->m_GtTranslationRequiredFlag)
   {
      char l_OrigGT[21];
      snprintf(l_OrigGT,20,"%s",p_OriginalHlrAddr);
      map<char*, char*>::iterator l_it;

      for(l_it = g_OtherConfigData->m_GtTranslationMap.begin();l_it != g_OtherConfigData->m_GtTranslationMap.end(); ++l_it)
      {
         DLOG(0,0,"In map GT [%s] OrigGT [%s]",l_it->first,l_OrigGT);
         int l_res = strcmp(l_it->first,l_OrigGT);
         if(l_res == 0)
         {
            LLOG(0,0,"Found gt in the map. translating to [%s]",l_it->second);
            strcpy((char *)p_NetworkHlrAddr, l_it->second);
            return true;
         }
      }

      WLOG(0,0,"Not found in GT Tranlsation table. Not translating...");
      strcpy((char *)p_NetworkHlrAddr,(char *) p_OriginalHlrAddr);
      return true;
   }
   else
   {
      DLOG(0,0,"No GT Translation");
      strcpy((char *)p_NetworkHlrAddr,(char *) p_OriginalHlrAddr);
   }
   return true;
}


bool GetTranslatedHostAddr(u8* p_TranslatedHostAddr, u8 *p_OriginalHostAddr)
{
   DLOG(0,0,"passed original host address[%s]",(char*)p_OriginalHostAddr);
   char l_originHost[100+1];
   memset(l_originHost,'\0',sizeof(l_originHost));
   if(strlen((char*)p_OriginalHostAddr) <=1)
   {
      DLOG(0,0,"Origin host address not found filling configured host");
      strcpy(l_originHost, g_OtherConfigData->m_dcd.m_originHost);
   }
   else
   {
      strcpy(l_originHost,(char*)p_OriginalHostAddr);
   }
   if(g_OtherConfigData->m_HssHostTranslationFlag)
   {
      map<string, string>::iterator l_it;

      l_it = g_OtherConfigData->m_HssHostTranslationMap.find((string)l_originHost);
      if(l_it == g_OtherConfigData->m_HssHostTranslationMap.end())
      {
         WLOG(0,0,"Not found in Host Tranlsation table. Not translating...");
         strcpy((char *)p_TranslatedHostAddr,(char*)l_originHost);
      }
      else
      {
         LLOG(0,0,"Found Host in the map. translating to [%s]",(char*)((l_it->second).c_str()));
         strcpy((char *)p_TranslatedHostAddr, (char*)(l_it->second).c_str());
      }
   }
   else
   {
      DLOG(0,0,"Host Translation flag not configured");
      strcpy((char *)p_TranslatedHostAddr,(char*)l_originHost);
   }
   return true;
}






map<string,EModuleStatsType> g_appStatsList;

bool moduleLevelAddHeader(char *p_header, EModuleStatsType p_type) //p_type=0 - Normal, 1-Total/Succcess
{
   int l_sizeBefore=g_appStatsList.size();
   LLOG(0,0,"moduleLevelAddHeader called with Header [%s]", p_header);
   g_appStatsList.insert(std::pair<string,EModuleStatsType>((char*)p_header, p_type));
   int l_sizeAfter=g_appStatsList.size();
   if(l_sizeBefore == l_sizeAfter)
   {
      WLOG(0,0,"Overriden the data for Header [%s] in the map", p_header);
   }
   return true;
}

void moduleLevelLogStats(char *p_header, EModuleStatsEventStatus p_totorsuccess)
{
   char l_char[50+1];
   DLOG(0,0,"moduleLevelLogStats called with header [%s], totorsuccess [%d]", p_header, p_totorsuccess);

   map<string,EModuleStatsType>::iterator l_iter = g_appStatsList.find(p_header);
   if(l_iter == g_appStatsList.end())
   {
      ELOG(0,0,"Header [%s] not found in appStatsList", p_header);
      return;
   }

   if(MODULE_STATS_TYPE_TOTAL_SUCCESS == l_iter->second)
   {
      if(MODULE_STATS_EVENT_STATUS_UNKNOWN == p_totorsuccess)
      {
         ELOG(0,0,"Event is TOTAL_SUCCESS type. Please select Tot/Success");
         return;
      }
      if(MODULE_STATS_EVENT_STATUS_TOTAL == p_totorsuccess)
      {
         snprintf(l_char, sizeof(l_char), "%s:Total", p_header);
      }
      else
      {
         snprintf(l_char, sizeof(l_char), "%s:Success", p_header);
      }
   }
   else
   {
      if(MODULE_STATS_EVENT_STATUS_UNKNOWN != p_totorsuccess)
      {
         ELOG(0,0,"Event is NORMAL type. Please do not select Tot/Success");
         return;
      }
      snprintf(l_char, sizeof(l_char), "%s", p_header);
   }

   map<string,int>::iterator l_itr = g_globalMap.find(l_char);
   if(l_itr != g_globalMap.end())
   {
      DLOG(0,0,"Found Header [%s] in map", l_char);
      genLogStatistics(l_itr->second);
   }
   else
   {
      WLOG(0,0,"Header [%s] not found in map", l_char);
   }
   return;
}

DiameterConfigData::DiameterConfigData()
{
   m_diameterNgRequired = 0;
   memset(m_diamPrimaryIpAddress,'\0',sizeof(m_diamPrimaryIpAddress));
   m_diamPrimaryIpPort = 0;
   memset(m_diamBackupIpAddress,'\0',sizeof(m_diamBackupIpAddress));
   m_diamBackupIpPort = 0;
   m_clientId = 0;
   m_applicationId = 0;
   m_additionalAppIdcount = 0;
   memset(m_additionalAppId,0,sizeof(m_additionalAppId));
   m_connectionType = 0;
   m_diamterPduPrintType = 0;
   memset(m_originHost,'\0',sizeof(m_originHost));
   memset(m_originRealm,'\0',sizeof(m_originRealm));
   memset(m_destinationHost,'\0',sizeof(m_destinationHost));
   memset(m_destinationRealm,'\0',sizeof(m_destinationRealm));
   m_priority = 0;
   m_DiastackLoggingFlag = 0;
   memset(m_LogsForDebugging,'\0',sizeof(m_LogsForDebugging));
}

DiameterConfigData::~DiameterConfigData()
{
}


OtherConfigData::OtherConfigData()
{
   m_MaxProvInitiatingTransactions = 0;
   m_PrintTimerInLog = 0;
   m_BackLogQueueType = 0;
   m_ThresholdDialogsForInitiatingTransactions = 0;
   m_PreserveSccpClass = 0;
   m_SendThreadHealthCheckTrap = 0;
   memset(m_DbActualConnectionString,'\0',sizeof(m_DbActualConnectionString));
   memset(m_Node2DbActualConnetionString,'\0',sizeof(m_Node2DbActualConnetionString));
   m_GtTranslationRequiredFlag  = 0;
   m_LogFileRotatingType = 0;
   m_LogFileMaxFiles = 0;
   m_DbFailedConnectionRetryType = 0;
   memset(m_TdrRtpsIp,'\0',sizeof(m_TdrRtpsIp));
   m_TdrRtpsPort = 0;
   m_MaxRtpsDowntime = 0;
   m_ExtTranslationRequiredFlag = 0;
   m_SccpType = 0;
   m_AnsiNationalIndicator = 0;
   m_sccpMsgHandlerParam = 0;
   memset(&m_DbAliasStringArr,'\0',sizeof(m_DbAliasStringArr));
   memset(&m_DbActualStringArr,'\0',sizeof(m_DbActualStringArr));
   memset(&m_DiameterInterfaceType,'\0',sizeof(m_DiameterInterfaceType));
   m_TT = 0;
   m_THBEnabled = 0;
   m_TCAPStackFlag = 0;
   m_logFlag = 0;
   m_DiameterMaxQueueSize = 0;
   m_DiameterMinQueueSize = 0;
   m_DiameterMessageRejectionType = 0;
   m_DbHeartBeatRequiredFlag = 0;
   m_DbHeartBeatInterval = 0;
   m_ProfilesFailureDuration = 0;
   m_HssHostTranslationFlag = 0;
   m_LaterQueryPoolSizeRequired = 0;
   m_LaterQueryDbTps = 100;

   memset(m_StackName,'\0',sizeof(m_StackName));
   memset(m_Sccp_Type,'\0',sizeof(m_Sccp_Type));
   m_SCCPStackFlag = 0;
   m_localSSN = 0;
   m_TTCalledParty = 0;

}

OtherConfigData::~OtherConfigData()
{
}

CongestionControl::CongestionControl()
{
   memset(m_controlType,'\0',sizeof(m_controlType));
   m_maxActiveIncomingDialogues = 0;
   m_maxActiveLaterQueueSize = 0;
   m_maxIncomingTransactionsPerSec = 0;
   m_priorityHandling = 0;
   memset(m_priorityPercentages,0,sizeof(m_priorityPercentages));
   memset(m_priorityMaxActiveIncomingDialogues,0,sizeof(m_priorityMaxActiveIncomingDialogues));
   memset(m_priorityIncomingTransactionsPerSec,0,sizeof(m_priorityIncomingTransactionsPerSec));
   memset(m_overloadTransactionsRejectType,'\0',sizeof(m_overloadTransactionsRejectType));
   memset(m_priorityFlags,0,sizeof(m_priorityFlags));
   m_trapInterval = 0;
}

CongestionControl::~CongestionControl()
{
}
