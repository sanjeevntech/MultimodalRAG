#include <pthread.h>
#include <RtpsInterface.h>
#include <TcpSocketClient.h>
#include <Logger.h>
#include <ConfigReader.h>
#include <CurrentTime.h>
#include <SnmpInterface.h>
#include <BufferData.h>


#define CTDR_FILE_MIN_SIZE    1048576 //1 MB
#define CTDR_FILE_SLEEP_TIME  2


int g_rtpsFd=-1;
int g_rtpsLastFailureDate=0;
int g_rtpsLastSuccessDate=0;
int g_rtpsFullyDownFlag=false;
bool g_connectStatus=false;
int g_lastCriticalTdrProcessedDate=0;
TcpSocketClient g_tsc;

//map<string,int> g_ctdrFileNameMap;
list<string> g_ctdrFileNameList;

void ctdrFileNameMapInit(char *p_dir)
{
   DIR *pDIR=NULL;
   struct dirent *entry=NULL;
   char l_tempEntityName[100+1];
   memset(l_tempEntityName, '\0', sizeof(l_tempEntityName));
   sprintf(l_tempEntityName, "%s%03d", g_ConfigData->m_EntityName, g_ConfigData->m_InstanceId);

   pDIR=opendir(p_dir);
   if( NULL != pDIR )
   {
      while((entry = readdir(pDIR)) != NULL)
      {
         if (strlen(entry->d_name) < 7)
         {
            LLOG(0,1,"Ignoring file [%s]", entry->d_name);
            continue;
         }
         if(0 != strcmp(&entry->d_name[strlen(entry->d_name)-5], ".ctdr"))
         {
            LLOG(0,1,"Ignoring file not ctdr [%s]", entry->d_name);
            continue;
         }
         if(!strstr(entry->d_name, l_tempEntityName))
         {
            LLOG(0,1,"Ignoring file not belonging to this instance [%s]", entry->d_name);
            continue;
         }

         char l_fileName[1000+1];
         memset(l_fileName,'\0',sizeof(l_fileName));
         snprintf(l_fileName, 1000, "%s/%s", p_dir, entry->d_name);
         int fd = -1;

         LLOG(0,1,"Opening file [%s]", l_fileName);
         fd = open(l_fileName,O_RDONLY);
         if(fd > 0)
         {
            struct stat fileStat;
            fstat(fd, &fileStat);
            if(fileStat.st_size > 0)
            {
               LLOG(0,1,"File Size [%d]", fileStat.st_size);

               //g_ctdrFileNameMap[(string)l_fileName] = 1;
               g_ctdrFileNameList.push_back((string)l_fileName);
            }
            close(fd);
         }
         else
         {
            ELOG(0,1,"Error opening File .. errno:%d strerr:%s",errno, strerror(errno));
         }
      }
      closedir(pDIR);
   }
   else
   {
      ELOG(0,1,"Error opening Directory [%s] .. errno:%d strerr:%s", p_dir, errno, strerror(errno));
   }
}

int readCriticalTdrs()
{
   int l_numberOfFilesProcessed=0;
   //struct dirent *entry=NULL;
   char l_tempEntityName[100+1];
   memset(l_tempEntityName, '\0', sizeof(l_tempEntityName));
   sprintf(l_tempEntityName, "%s%03d", g_ConfigData->m_EntityName, g_ConfigData->m_InstanceId);

   //map<string,int>::iterator l_fileIter;
   list<string>::iterator l_fileIter;
   g_ctdrFileNameList.sort();
   for(l_fileIter = g_ctdrFileNameList.begin(); l_fileIter != g_ctdrFileNameList.end(); )
   {
      char l_fileName[1000+1];
      memset(l_fileName,'\0',sizeof(l_fileName));
      snprintf(l_fileName, sizeof(l_fileName), "%s", (char*)(*l_fileIter).c_str());
      int fd = -1;

      LLOG(0,1,"Opening file [%s] sizeoflist[%d]", l_fileName, g_ctdrFileNameList.size());
      fd = open(l_fileName,O_RDONLY);
      if(fd >0)
      {
         struct stat fileStat;
         fstat(fd, &fileStat);
         if(fileStat.st_size > 0)
         {
            LLOG(0,1,"Reading %d bytes from the file", fileStat.st_size);
            unsigned char *l_temp = new unsigned char[fileStat.st_size];
            ssize_t l_read = read(fd, l_temp, fileStat.st_size);
            if (l_read != fileStat.st_size)
            {
               ELOG(0,1,"Severe Error!!! filesize[%d], read[%d], data [%s]", fileStat.st_size, l_read, l_temp);
               l_fileIter++;
            }
            else
            {
               l_numberOfFilesProcessed++;
               LLOG(0,1,"Read length [%d]", fileStat.st_size);
               BufferData *l_bd = new BufferData;
               l_bd->m_data = new unsigned char[fileStat.st_size+1];
               memcpy((char*)l_bd->m_data, (char*)l_temp, fileStat.st_size);
               l_bd->m_data[fileStat.st_size] = '\0';
               l_bd->m_length = fileStat.st_size+1;
               g_TdrObj.m_lw.m_q->push(l_bd);

               LLOG(0,1,"Erasing from list [%s] size[%d]", (char*)(*l_fileIter).c_str(), g_ctdrFileNameList.size());
               l_fileIter = g_ctdrFileNameList.erase(l_fileIter);


               int l_removeResult = remove(l_fileName);
               if (0 == l_removeResult)
               {
                  LLOG(0,1,"Removing file [%s] success", l_fileName);
               }
               else
               {
                  ELOG(0,1,"Removing file [%s] failure: %d", l_fileName, errno);
               }
               TLOG(0,0,"After erasing sizeof list[%d]",g_ctdrFileNameList.size());
            }

            if (l_temp != NULL)
            {
               delete[] l_temp;
               l_temp=NULL;
            }
         }
         else
         {
            l_fileIter++;
         }
         close(fd);

         int l_currentQueueSize=g_TdrObj.m_lw.m_q->size();
         if (l_currentQueueSize < 3)
         {
            LLOG(0,1,"Queue size is just [%d]. Continuing to check if there are any critical TDR files", l_currentQueueSize);
            continue;
         }
         else
         {
            LLOG(0,1,"Queue size is [%d]. Returning", l_currentQueueSize);
            //Since we have processed atleast one file, we are returning by closing the Directory.
            return l_numberOfFilesProcessed;
         }
      }
      else
      {
         ELOG(0,1,"Error opening File .. errno:%d strerr:%s",errno, strerror(errno));
         l_fileIter++;
      }
   }
   return l_numberOfFilesProcessed;
}


bool sendDataAndRecvAck(int p_sockFd, unsigned char *p_data, int p_length)
{
   if(false == g_tsc.sendDataToNetwork(p_sockFd, p_data, p_length, 60))
   {
      WLOG(0,1,"senddatatonetwork failed");
      return false;
   }
   else
   {
      DLOG(0,1,"Sock fd %d at recvall", g_rtpsFd);
      char l_ack[10];
      memset(l_ack, '\0', sizeof(l_ack));
      if (1 == g_tsc.recvAllWithLength(g_rtpsFd, l_ack, 1, 60))
      {
         if('A' == l_ack[0])
         {
            LLOG(0,1,"Recvd Ack A");
            return true;
         }
         else
         {
            ELOG(0,1,"Recvd Invalid Ack [%c]", l_ack[0]);
            return false;
         }
      }
      else
      {
         ELOG(0,1,"Didn't receive Ack. Closing the connection.");
         return false;
      }
   }
   return false;
}


void flushTdrs()
{
   LLOG(0,1,"Called flushTdrs QueueSize:[%d]", g_TdrObj.m_lw.m_q->size());
   if(g_TdrObj.m_lw.m_q->size() > 0)
   {
      bool l_status=false;
      do
      {
         l_status = false;
         BufferData *l_data = NULL;
         l_status = g_TdrObj.m_lw.m_q->pop((void**)&l_data);
         if (true == l_status)
         {
            TLOG(0,1,"Writing into critical tdrs [%d] [%c%c%c%c%c]", l_data->m_length, 
                  l_data->m_data[0], l_data->m_data[1], l_data->m_data[2], l_data->m_data[3], l_data->m_data[4]);

            g_CriticalTdrObj.m_lw.writeLog((char*)l_data->m_data, l_data->m_length-1);
            //sleep(1);

            if (NULL != l_data)
            {
               delete(l_data);
            }
         }
      }
      while (true == l_status);
   }
   LLOG(0,1,"Returing flushTdrs QueueSize:[%d]", g_TdrObj.m_lw.m_q->size());
   return;
}




void *dispThrFunc(void *p)
{
   char l_tempDate[100];

   LLOG(0,1,"dispThrFunc started");
   LogWriter *l_lw = (LogWriter *)p;

   //This is to set the current time as last RTPS failed timestamp
   getCurrentTime(l_tempDate);
   g_rtpsLastFailureDate=g_dateEpoch;
   g_rtpsFullyDownFlag=false;
   g_lastCriticalTdrProcessedDate=0;

   char l_entityname[100];
   memset(l_entityname, '\0', sizeof(l_entityname));
   sprintf(l_entityname, "%s%03d", g_ConfigData->m_EntityName, g_ConfigData->m_InstanceId);
   bool l_status = g_tsc.initialize(l_entityname, g_OtherConfigData->m_TdrRtpsIp, g_OtherConfigData->m_TdrRtpsPort);
   if (false == l_status)
   {
      CLOG(0,1,"Unable to initialize TSC with %s %d", g_OtherConfigData->m_TdrRtpsIp, g_OtherConfigData->m_TdrRtpsPort);
      exitFunc(EXIT_APPLICATION_TYPE_RTPS_TSC_INIT_FAILED);
      return NULL;
   }

   if(0 != g_OtherConfigData->m_THBEnabled)
   {
      if(false == g_thb.registerMe(60, "dispThrFunc"))
      {
         CLOG(1,1,"RegisterMe failed on dispThrFunc");
         exit(1);
      }
   }


   while(1)
   {
      if((0 != g_OtherConfigData->m_THBEnabled) && ((g_simulateThbHungInterval == 0 ) || (time(NULL) >= g_currTimeForTHB + g_simulateThbHungInterval)))
      {
         if(false == g_thb.iAmAlive())
         {
            ELOG(0,1,"THB iAmAlive failed. Exiting...");
            exitFunc(EXIT_APPLICATION_TYPE_THB_I_AM_ALIVE_FAILED);
         }
      }

      if ( (true == g_shutdown_received) || (true == g_sig_int_signal_received) || (true == g_core_signal_received))
      {
         LLOG(0,1,"Exit Signal received. Shutdown[%d], Interrupt[%d], Core[%d]", g_shutdown_received, g_sig_int_signal_received, g_core_signal_received);
         if(0 != g_OtherConfigData->m_THBEnabled)
         {
             if(false == g_thb.unRegisterMe())
             {
                CLOG(1,1,"UnRegisterMe failed on dispThrFunc");
                exit(1);
             }
         }
        
         flushTdrs();
         return NULL;
      }

      if(g_connectStatus == false)
      {
         char l_conn_res[1000];
         memset(l_conn_res, '\0', 1000);
         char l_err_msg[1000];
         memset(l_err_msg, '\0', 1000);
         if(strlen(g_title) > 0)
         {
            g_connectStatus = g_tsc.connectToApp(&g_rtpsFd, l_conn_res, l_err_msg);
            if(false == g_connectStatus)
            {
               g_si.sendSnmpTrap(g_RtpsConnectionTrap, TRAP_TYPE_FAIL, TRAP_SEVERITY_CRITICAL);
               WLOG(0,1,"Unable to connect to RTPS");
               getCurrentTime(l_tempDate);
               if (0 == g_rtpsLastFailureDate) //This is to safeguard the last RTPS down timestamp
               {
                  WLOG(0,1,"Setting RTPS DownTime:%d", g_rtpsLastFailureDate);
                  g_rtpsLastFailureDate=g_dateEpoch;
               }

               if (g_dateEpoch > (g_rtpsLastFailureDate+g_OtherConfigData->m_MaxRtpsDowntime))
               {
                  WLOG(0,1,"RTPS is down for more than %d seconds CurrentTime:%d", g_OtherConfigData->m_MaxRtpsDowntime, g_dateEpoch);
                  g_rtpsFullyDownFlag=true;

                  TLOG(0,1,"Flushing in-memory TDRs [%d] to Critical TDRs", l_lw->m_q->size());
                  flushTdrs();

                  TLOG(0,1,"Done with flushing TDRs");
                  g_rtpsLastFailureDate=1600000000;//to not to check this again
               }
            }
            else
            {
               g_rtpsLastFailureDate=0;

               getCurrentTime(l_tempDate);
               g_rtpsLastSuccessDate=g_dateEpoch;

               TLOG(0,1,"Connected to RTPS with SockFd:[%d]. ConnRes[%s]", g_rtpsFd, l_conn_res);
               g_si.sendSnmpTrap(g_RtpsConnectionTrap, TRAP_TYPE_PASS, TRAP_SEVERITY_MINOR);
               g_rtpsFullyDownFlag=false;
               g_ctdrFileNameList.clear();
               pthread_mutex_lock(&g_WriteLogMutex);
               g_CriticalTdrObj.m_lw.m_FileSize=99999999;//just to close the current file
               pthread_mutex_unlock(&g_WriteLogMutex);

               ctdrFileNameMapInit(g_ConfigData->m_TdrLogfilePath);
            }
         }
         else
         {
            TLOG(0,1,"Still subscriber profiles is not initialized. Not connecting to RTPS");
         }
      }
      else
      {
         if(1 == g_OtherConfigData->m_PrintTimerInLog)
         {
            DLOG(0,1,"Checking RTPS connection availability");
         }
         if(true == dataAvailable(g_rtpsFd, 1))
         {
            WLOG(0,1,"RTPS connection broken");
            close(g_rtpsFd);
            g_rtpsFd=0;
            g_connectStatus=false;
            g_si.sendSnmpTrap(g_RtpsConnectionTrap, TRAP_TYPE_FAIL, TRAP_SEVERITY_CRITICAL);
            g_rtpsLastFailureDate=g_dateEpoch;
         }
         else
         {
            if(1 == g_OtherConfigData->m_PrintTimerInLog)
            {
               DLOG(0,1,"Connection with RTPS exists");
            }
         }
      }

      if(false == g_connectStatus)
      {
         if(1 == g_OtherConfigData->m_PrintTimerInLog)
         {
            DLOG(0,1,"ERROR:: No RTPS Connection available");
            sleep(1);
         }
      }
      else
      {
         do
         {
            l_status = false;
            if (true == g_connectStatus)
            {
               if (g_dateEpoch > g_rtpsLastSuccessDate + 30)
               {
                  LLOG(0,1,"Should process the Critical TDRs here");
                  //pthread_mutex_lock(&g_WriteLogMutex); //Commented in 25.1 - moved above ctdrFileNameMapInit
                  //g_CriticalTdrObj.m_lw.m_FileSize=99999999;//just to close the current file
                  //pthread_mutex_unlock(&g_WriteLogMutex);

                  if(g_dateEpoch > g_lastCriticalTdrProcessedDate+5)
                  {
                    // ctdrFileNameMapInit(g_ConfigData->m_TdrLogfilePath);

                     int l_size= l_lw->m_q->size();
                     if (l_size > 3)
                     {
                        LLOG(0,1,"Queue size is [%d]. Not reading Critical TDRs.", l_size);
                     }
                     else
                     {
                        LLOG(0,1,"Checking if there are any critical TDR files present");
                        g_lastCriticalTdrProcessedDate=g_dateEpoch;
                        if(0 == readCriticalTdrs()) //No more critical TDRs in the directory
                        {
                           LLOG(0,1,"No more Critical TDRs. g_rtpsLastSuccessDate : %d, g_dateEpoch: %d", g_rtpsLastSuccessDate, g_dateEpoch);
                           g_rtpsLastSuccessDate=1600000000;
                        }
                        else
                        {
                           LLOG(0,1,"Critical TDR Present");
                        }
                     }
                  }
               }

               BufferData *l_data = NULL;
               l_status = l_lw->m_q->pop((void**)&l_data);
               if (true == l_status)
               {
                  if(l_data->m_length > CTDR_FILE_MIN_SIZE)
                  {
                     LLOG(0,1,"Applying flow control when sending huge files to RTPS");
                     sleep(CTDR_FILE_SLEEP_TIME);
                  }
                  LLOG(0,1,"Sending data [%d] to SockFd:[%d]",  l_data->m_length, g_rtpsFd);

                  if (false == sendDataAndRecvAck(g_rtpsFd, l_data->m_data, l_data->m_length))
                  {
                     CLOG(0,1,"Send failed. Closing the connection with SockFd:[%d]", g_rtpsFd);
                     close(g_rtpsFd);
                     g_rtpsFd=0;
                     g_connectStatus=false;
                     TLOG(0,1,"Size before push: %d", l_lw->m_q->size());
                     l_lw->m_q->push(l_data);
                     TLOG(0,1,"Size after push: %d", l_lw->m_q->size());
                     g_si.sendSnmpTrap(g_RtpsConnectionTrap, TRAP_TYPE_FAIL, TRAP_SEVERITY_CRITICAL);
                     g_rtpsLastFailureDate=g_dateEpoch;
                  }
                  else //Successfully sent the data
                  {
                     LLOG(0,1,"Successfully sent the data. Deleting");
                     if (l_data != NULL)
                     {
                        delete(l_data);
                        l_data=NULL;
                     }
                  }
               }
               else
               {
                  if(1 == g_OtherConfigData->m_PrintTimerInLog)
                  {
                     TLOG(0,1,"No TDR Requests to process");
                  }
               }
            }
         }
         while (l_status);
      }
      //printf("\nsleeping %d\n", RETRY_CONNECTION_TIMER);
      sleep(1);

   }

   return NULL;
}


