#include <SmppInterface.h>


typedef enum
{
   COMMERCIAL_AT                          =  0x40  ,
   POUND_SIGN                       =  0xA3  ,
   DOLLAR_SIGN                        =  0x24  ,
   YEN_SIGN          =  0xA5  ,
   LATIN_SMALL_LETTER_E_WITH_GRAVE     =  0xE8  ,
   LATIN_SMALL_LETTER_E_WITH_ACUTE     =  0xE9  ,
   LATIN_SMALL_LETTER_U_WITH_GRAVE     =  0xF9  ,
   LATIN_SMALL_LETTER_I_WITH_GRAVE     =  0xEC  ,
   LATIN_SMALL_LETTER_O_WITH_GRAVE     =  0xF2  ,
   LATIN_CAPITAL_LETTER_C_WITH_CEDILLA =  0xC7  ,
   LINE_FEED            =  0xA   ,
   LATIN_CAPITAL_LETTER_O_WITH_STROKE  =  0xD8  ,
   LATIN_SMALL_LETTER_O_WITH_STROKE =  0xF8  ,
   CARRIAGE_RETURN            =  0xD   ,
   LATIN_CAPITAL_LETTER_A_WITH_RING_ABOVE =  0xC5  ,
   LATIN_SMALL_LETTER_A_WITH_RING_ABOVE   =  0xE5  ,
   LOW_LINE          =  0x5f  ,
   FORM_FEED            =  0xC   ,
   CIRCUMFLEX_ACCENT       =  0x5E  ,
   LEFT_CURLY_BRACKET         =  0x7B  ,
   RIGHT_CURLY_BRACKET        =  0x7D  ,
   REVERSE_SOLIDUS_BACKSLASH     =  0x5C  ,
   LEFT_SQUARE_BRACKET        =  0x5B  ,
   TILDE             =  0x7E  ,
   RIGHT_SQUARE_BRACKET       =  0x5D  ,
   VERTICAL_BAR            =  0x7C  ,
   EURO_SIGN            =  0xA4  ,
   LATIN_CAPITAL_LETTER_AE       =  0xC6  ,
   LATIN_SMALL_LETTER_AE         =  0xE6  ,
   LATIN_SMALL_LETTER_SHARP_S_German =  0xDF  ,
   LATIN_CAPITAL_LETTER_E_WITH_ACUTE   =  0xC9  ,
   CURRENCY_SIGN           =  0xA4  ,
   INVERTED_EXCLAMATION_MARK     =  0xA1  ,
   LATIN_CAPITAL_LETTER_A_WITH_DIAERESIS  =  0xC4  ,
   LATIN_CAPITAL_LETTER_O_WITH_DIAERESIS  =  0xD6  ,
   LATIN_CAPITAL_LETTER_N_WITH_TILDE   =  0xD1  ,
   LATIN_CAPITAL_LETTER_U_WITH_DIAERESIS  =  0xDC  ,
   SECTION_SIGN            =  0xA7  ,
   INVERTED_QUESTION_MARK        =  0xBF  ,
   LATIN_SMALL_LETTER_A_WITH_DIAERESIS =  0xE4  ,
   LATIN_SMALL_LETTER_O_WITH_DIAERESIS =  0xF6  ,
   LATIN_SMALL_LETTER_N_WITH_TILDE     =  0xF1  ,
   LATIN_SMALL_LETTER_U_WITH_DIAERESIS =  0xFC  ,
   LATIN_SMALL_LETTER_A_WITH_GRAVE     =  0xE0  

}AsciiCharacterSet;




typedef enum
{
GSM_COMMERCIAL_AT          =  0x00  ,
GSM_POUND_SIGN             =  0x01  ,
GSM_DOLLAR_SIGN               =  0x02  ,
GSM_YEN_SIGN               =  0x03  ,
GSM_LATIN_SMALL_LETTER_E_WITH_GRAVE    =  0x04  ,
GSM_LATIN_SMALL_LETTER_E_WITH_ACUTE    =  0x05  ,
GSM_LATIN_SMALL_LETTER_U_WITH_GRAVE    =  0x06  ,
GSM_LATIN_SMALL_LETTER_I_WITH_GRAVE    =  0x07  ,
GSM_LATIN_SMALL_LETTER_O_WITH_GRAVE    =  0x08  ,
GSM_LATIN_CAPITAL_LETTER_C_WITH_CEDILLA      =  0x09  ,
GSM_LINE_FEED              =  0x0A  ,
GSM_LATIN_CAPITAL_LETTER_O_WITH_STROKE    =  0x0B  ,
GSM_LATIN_SMALL_LETTER_O_WITH_STROKE      =  0x0C  ,
GSM_CARRIAGE_RETURN           =  0x0D  ,
GSM_LATIN_CAPITAL_LETTER_A_WITH_RING_ABOVE   =  0x0E  ,
GSM_LATIN_SMALL_LETTER_A_WITH_RING_ABOVE  =  0x0F  ,
GSM_LOW_LINE               =  0x11  ,
GSM_FORM_FEED              =  0x1B0A   ,
GSM_CIRCUMFLEX_ACCENT            =  0x1B14   ,
GSM_LEFT_CURLY_BRACKET           =  0x1B28   ,
GSM_RIGHT_CURLY_BRACKET          =  0x1B29   ,
GSM_REVERSE_SOLIDUS_BACKSLASH       =  0x1B2F   ,
GSM_LEFT_SQUARE_BRACKET          =  0x1B3C   ,
GSM_TILDE               =  0x1B3D   ,
GSM_RIGHT_SQUARE_BRACKET         =  0x1B3E   ,
GSM_VERTICAL_BAR           =  0x1B40   ,
GSM_EURO_SIGN              =  0x1B65   ,
GSM_LATIN_CAPITAL_LETTER_AE         =  0x1C  ,
GSM_LATIN_SMALL_LETTER_AE        =  0x1D  ,
GSM_LATIN_SMALL_LETTER_SHARP_S_German     =  0x1E  ,
GSM_LATIN_CAPITAL_LETTER_E_WITH_ACUTE     =  0x1F  ,
GSM_CURRENCY_SIGN          =  0x24  ,
GSM_INVERTED_EXCLAMATION_MARK       =  0x40  ,
GSM_LATIN_CAPITAL_LETTER_A_WITH_DIAERESIS =  0x5B  ,
GSM_LATIN_CAPITAL_LETTER_O_WITH_DIAERESIS =  0x5C  ,
GSM_LATIN_CAPITAL_LETTER_N_WITH_TILDE     =  0x5D  ,
GSM_LATIN_CAPITAL_LETTER_U_WITH_DIAERESIS =  0x5E  ,
GSM_SECTION_SIGN           =  0x5F  ,
GSM_INVERTED_QUESTION_MARK       =  0x60  ,
GSM_LATIN_SMALL_LETTER_A_WITH_DIAERESIS      =  0x7B  ,
GSM_LATIN_SMALL_LETTER_O_WITH_DIAERESIS      =  0x7C  ,
GSM_LATIN_SMALL_LETTER_N_WITH_TILDE    =  0x7D  ,
GSM_LATIN_SMALL_LETTER_U_WITH_DIAERESIS      =  0x7E  ,
GSM_LATIN_SMALL_LETTER_A_WITH_GRAVE    =  0x7F  ,
GSM_ESCAPE_TO_EXTENSION_TABLE          =  0x1B  

}GSM7BitCharacters;

int ConvertAscii2Gsm(int ascii)
{
   switch(ascii)
   {

      case  COMMERCIAL_AT           :  return   GSM_COMMERCIAL_AT          ;  break;
      case  POUND_SIGN           :  return   GSM_POUND_SIGN             ;  break;
      case  DOLLAR_SIGN          :  return   GSM_DOLLAR_SIGN               ;  break;
      case  YEN_SIGN          :  return   GSM_YEN_SIGN               ;  break;
      case  LATIN_SMALL_LETTER_E_WITH_GRAVE     :  return   GSM_LATIN_SMALL_LETTER_E_WITH_GRAVE    ;  break;
      case  LATIN_SMALL_LETTER_E_WITH_ACUTE     :  return   GSM_LATIN_SMALL_LETTER_E_WITH_ACUTE    ;  break;
      case  LATIN_SMALL_LETTER_U_WITH_GRAVE     :  return   GSM_LATIN_SMALL_LETTER_U_WITH_GRAVE    ;  break;
      case  LATIN_SMALL_LETTER_I_WITH_GRAVE     :  return   GSM_LATIN_SMALL_LETTER_I_WITH_GRAVE    ;  break;
      case  LATIN_SMALL_LETTER_O_WITH_GRAVE     :  return   GSM_LATIN_SMALL_LETTER_O_WITH_GRAVE    ;  break;
      case  LATIN_CAPITAL_LETTER_C_WITH_CEDILLA :  return   GSM_LATIN_CAPITAL_LETTER_C_WITH_CEDILLA      ;  break;
      case  LINE_FEED            :  return   GSM_LINE_FEED              ;  break;
      case  LATIN_CAPITAL_LETTER_O_WITH_STROKE  :  return   GSM_LATIN_CAPITAL_LETTER_O_WITH_STROKE    ;  break;
      case  LATIN_SMALL_LETTER_O_WITH_STROKE :  return   GSM_LATIN_SMALL_LETTER_O_WITH_STROKE      ;  break;
      case  CARRIAGE_RETURN            :  return   GSM_CARRIAGE_RETURN           ;  break;
      case  LATIN_CAPITAL_LETTER_A_WITH_RING_ABOVE :  return   GSM_LATIN_CAPITAL_LETTER_A_WITH_RING_ABOVE   ;  break;
      case  LATIN_SMALL_LETTER_A_WITH_RING_ABOVE   :  return   GSM_LATIN_SMALL_LETTER_A_WITH_RING_ABOVE  ;  break;
      case  LOW_LINE          :  return   GSM_LOW_LINE               ;  break;
      case  FORM_FEED            :  return   GSM_FORM_FEED              ;  break;
      case  CIRCUMFLEX_ACCENT       :  return   GSM_CIRCUMFLEX_ACCENT            ;  break;
      case  LEFT_CURLY_BRACKET         :  return   GSM_LEFT_CURLY_BRACKET           ;  break;
      case  RIGHT_CURLY_BRACKET        :  return   GSM_RIGHT_CURLY_BRACKET          ;  break;
      case  REVERSE_SOLIDUS_BACKSLASH     :  return   GSM_REVERSE_SOLIDUS_BACKSLASH       ;  break;
      case  LEFT_SQUARE_BRACKET        :  return   GSM_LEFT_SQUARE_BRACKET          ;  break;
      case  TILDE             :  return   GSM_TILDE               ;  break;
      case  RIGHT_SQUARE_BRACKET       :  return   GSM_RIGHT_SQUARE_BRACKET         ;  break;
      case  VERTICAL_BAR            :  return   GSM_VERTICAL_BAR           ;  break;
      case  EURO_SIGN            :  return   GSM_EURO_SIGN              ;  break;
      case  LATIN_CAPITAL_LETTER_AE       :  return   GSM_LATIN_CAPITAL_LETTER_AE         ;  break;
      case  LATIN_SMALL_LETTER_AE         :  return   GSM_LATIN_SMALL_LETTER_AE        ;  break;
      case  LATIN_SMALL_LETTER_SHARP_S_German   :  return   GSM_LATIN_SMALL_LETTER_SHARP_S_German     ;  break;
      case  LATIN_CAPITAL_LETTER_E_WITH_ACUTE   :  return   GSM_LATIN_CAPITAL_LETTER_E_WITH_ACUTE     ;  break;
      //case  CURRENCY_SIGN           :  return   GSM_CURRENCY_SIGN          ;  break;
      case  INVERTED_EXCLAMATION_MARK     :  return   GSM_INVERTED_EXCLAMATION_MARK       ;  break;
      case  LATIN_CAPITAL_LETTER_A_WITH_DIAERESIS  :  return   GSM_LATIN_CAPITAL_LETTER_A_WITH_DIAERESIS ;  break;
      case  LATIN_CAPITAL_LETTER_O_WITH_DIAERESIS  :  return   GSM_LATIN_CAPITAL_LETTER_O_WITH_DIAERESIS ;  break;
      case  LATIN_CAPITAL_LETTER_N_WITH_TILDE   :  return   GSM_LATIN_CAPITAL_LETTER_N_WITH_TILDE     ;  break;
      case  LATIN_CAPITAL_LETTER_U_WITH_DIAERESIS  :  return   GSM_LATIN_CAPITAL_LETTER_U_WITH_DIAERESIS ;  break;
      case  SECTION_SIGN            :  return   GSM_SECTION_SIGN           ;  break;
      case  INVERTED_QUESTION_MARK        :  return   GSM_INVERTED_QUESTION_MARK       ;  break;
      case  LATIN_SMALL_LETTER_A_WITH_DIAERESIS :  return   GSM_LATIN_SMALL_LETTER_A_WITH_DIAERESIS      ;  break;
      case  LATIN_SMALL_LETTER_O_WITH_DIAERESIS :  return   GSM_LATIN_SMALL_LETTER_O_WITH_DIAERESIS      ;  break;
      case  LATIN_SMALL_LETTER_N_WITH_TILDE     :  return   GSM_LATIN_SMALL_LETTER_N_WITH_TILDE    ;  break;
      case  LATIN_SMALL_LETTER_U_WITH_DIAERESIS :  return   GSM_LATIN_SMALL_LETTER_U_WITH_DIAERESIS      ;  break;
      case  LATIN_SMALL_LETTER_A_WITH_GRAVE     :  return   GSM_LATIN_SMALL_LETTER_A_WITH_GRAVE    ;  break;
      default:  return ascii;
   }
}
