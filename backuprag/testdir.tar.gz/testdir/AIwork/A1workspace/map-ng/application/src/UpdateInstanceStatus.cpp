
/* Result Sets Interface */
#ifndef SQL_CRSR
#  define SQL_CRSR
  struct sql_cursor
  {
    unsigned int curocn;
    void *ptr1;
    void *ptr2;
    unsigned int magic;
  };
  typedef struct sql_cursor sql_cursor;
  typedef struct sql_cursor SQL_CURSOR;
#endif /* SQL_CRSR */

/* Thread Safety */
typedef void * sql_context;
typedef void * SQL_CONTEXT;

/* Object support */
struct sqltvn
{
  unsigned char *tvnvsn; 
  unsigned short tvnvsnl; 
  unsigned char *tvnnm;
  unsigned short tvnnml; 
  unsigned char *tvnsnm;
  unsigned short tvnsnml;
};
typedef struct sqltvn sqltvn;

struct sqladts
{
  unsigned int adtvsn; 
  unsigned short adtmode; 
  unsigned short adtnum;  
  sqltvn adttvn[1];       
};
typedef struct sqladts sqladts;

static struct sqladts sqladt = {
  1,1,0,
};

/* Binding to PL/SQL Records */
struct sqltdss
{
  unsigned int tdsvsn; 
  unsigned short tdsnum; 
  unsigned char *tdsval[1]; 
};
typedef struct sqltdss sqltdss;
static struct sqltdss sqltds =
{
  1,
  0,
};

/* File name & Package Name */
struct sqlcxp
{
  unsigned short fillen;
           char  filnam[24];
};
static const struct sqlcxp sqlfpn =
{
    23,
    "UpdateInstanceStatus.pc"
};


static unsigned int sqlctx = 670693187;


static struct sqlexd {
   unsigned long  sqlvsn;
   unsigned int   arrsiz;
   unsigned int   iters;
   unsigned int   offset;
   unsigned short selerr;
   unsigned short sqlety;
   unsigned int   occurs;
      const short *cud;
   unsigned char  *sqlest;
      const char  *stmt;
   sqladts *sqladtp;
   sqltdss *sqltdsp;
   unsigned char  **sqphsv;
   unsigned long  *sqphsl;
            int   *sqphss;
            short **sqpind;
            int   *sqpins;
   unsigned long  *sqparm;
   unsigned long  **sqparc;
   unsigned short  *sqpadto;
   unsigned short  *sqptdso;
   unsigned int   sqlcmax;
   unsigned int   sqlcmin;
   unsigned int   sqlcincr;
   unsigned int   sqlctimeout;
   unsigned int   sqlcnowait;
            int   sqfoff;
   unsigned int   sqcmod;
   unsigned int   sqfmod;
   unsigned char  *sqhstv[3];
   unsigned long  sqhstl[3];
            int   sqhsts[3];
            short *sqindv[3];
            int   sqinds[3];
   unsigned long  sqharm[3];
   unsigned long  *sqharc[3];
   unsigned short  sqadto[3];
   unsigned short  sqtdso[3];
} sqlstm = {12,3};

// Prototypes
extern "C" {
  void sqlcxt (void **, unsigned int *,
               struct sqlexd *, const struct sqlcxp *);
  void sqlcx2t(void **, unsigned int *,
               struct sqlexd *, const struct sqlcxp *);
  void sqlbuft(void **, char *);
  void sqlgs2t(void **, char *);
  void sqlorat(void **, unsigned int *, void *);
}

// Forms Interface
static const int IAPSUCC = 0;
static const int IAPFAIL = 1403;
static const int IAPFTL  = 535;
extern "C" { void sqliem(unsigned char *, signed int *); }

typedef struct { unsigned short len; unsigned char arr[1]; } VARCHAR;
typedef struct { unsigned short len; unsigned char arr[1]; } varchar;

/* cud (compilation unit data) array */
static const short sqlcud0[] =
{12,4138,1,0,0,
5,0,0,1,142,0,5,54,0,0,3,3,0,1,0,1,9,0,0,1,68,0,0,1,9,0,0,
32,0,0,2,0,0,29,56,0,0,0,0,0,1,0,
47,0,0,3,0,0,31,66,0,0,0,0,0,1,0,
62,0,0,4,0,0,31,73,0,0,0,0,0,1,0,
};


#include <UpdateInstanceStatus.h>
#include <Logger.h>
#include <stdio.h>
#include <strings.h>
#include <sqlda.h>

/* EXEC SQL INCLUDE ../inc/UpdateInstanceStatus.h;
 */ 
#ifndef _UPDATE_INSTANCE_STATUS_H_
#define _UPDATE_INSTANCE_STATUS_H_

#include <DbQueryMsg.h>
#include <ConfigReader.h>


class UpdateInstanceStatus : public DbQueryMsg
{
   public:
      UpdateInstanceStatus();
      ~UpdateInstanceStatus();

      bool executeQuery(void*);
};



















#endif
/* EXEC SQL INCLUDE ../inc/ConnectionObject.h;
 */ 
#ifndef __CONNECTION_OBJECT_H
#define __CONNECTION_OBJECT_H

#include <sqlda.h>

#include <string>
#include <Logger.h>
#include <ConfigReader.h>

#define CONNECTION_ATTEMPTS 5
#define MEMBER_STATE_GOOD	0
#define MEMBER_STATE_BAD	1

extern struct oraca oraca;

#ifndef SQLCA
#define SQLCA 1
struct   sqlca
{
   /* ub1 */ char    sqlcaid[8];
   /* b4  */ int     sqlabc;
   /* b4  */ int     sqlcode;
   struct
   {
      /* ub2 */ unsigned short sqlerrml;
      /* ub1 */ char           sqlerrmc[70];
   } sqlerrm;
   /* ub1 */ char    sqlerrp[8];
   /* b4  */ int     sqlerrd[6];
   /* ub1 */ char    sqlwarn[8];
   /* ub1 */ char    sqlext[8];
};
#endif

#include <sqlca.h>

extern struct sqlca sqlca;
extern struct oraca oraca;

class ConnectionObject
{

   public:
      // This variable indicates the state of the runtime context
      int	iState ;				
      /* EXEC SQL BEGIN DECLARE SECTION; */ 
		
      /* varchar	iCntStr[200]; */ 
struct { unsigned short len; unsigned char arr[200]; } iCntStr;

      /* EXEC SQL END DECLARE SECTION; */ 

   public:

      /* EXEC SQL BEGIN DECLARE SECTION; */ 

      sql_context iCtx;
      /* EXEC SQL END DECLARE SECTION; */ 


      // Default Context Object
      ConnectionObject(string mCntStr) ;

      ~ConnectionObject();
};


#endif




extern struct sqlca sqlca;

UpdateInstanceStatus::UpdateInstanceStatus()
{
   LLOG(0,0,"UpdateInstanceStatus :cons:");
}

UpdateInstanceStatus::~UpdateInstanceStatus()
{
   LLOG(0,0,"UpdateInstanceStatus :des:");
}

bool UpdateInstanceStatus :: executeQuery(void *p_conn)
{
   struct sqlca sqlca;
   memset(&sqlca, '\0', sizeof(sqlca));
   LLOG(0,0,"LOAD UpdateInstanceStatus BEGIN");
   /* EXEC SQL BEGIN DECLARE SECTION; */ 

   /* VARCHAR l_selfIpAddress[30 + 1]; */ 
struct { unsigned short len; unsigned char arr[31]; } l_selfIpAddress;

   /* VARCHAR l_selfEntityNameString[50 + 1]; */ 
struct { unsigned short len; unsigned char arr[51]; } l_selfEntityNameString;

   unsigned int l_selfIpPort;
   /* EXEC SQL END DECLARE SECTION; */ 


   memset(&l_selfIpAddress,'\0',sizeof(l_selfIpAddress));
   memset(&l_selfEntityNameString,'\0',sizeof(l_selfEntityNameString));
   l_selfIpPort = 0;
   sprintf((char*)l_selfIpAddress.arr, g_selfIpAddress);
   l_selfIpAddress.len = strlen(g_selfIpAddress);
   strcpy((char*)l_selfEntityNameString.arr, g_ConfigData->m_EntityName);
   l_selfEntityNameString.len = strlen((char*)l_selfEntityNameString.arr);
   l_selfIpPort                 = g_ConfigData->m_ProvListenPort;

   LLOG(0,0,"Inputs: IpAddress: [%s], EntityName: [%s], Port: [%d] %d %d", (char*)l_selfIpAddress.arr, g_ConfigData->m_EntityName, g_ConfigData->m_ProvListenPort,
         l_selfIpAddress.len, l_selfEntityNameString.len);

   LLOG(0,0,"Inputs EntityName [%s]", (char*)l_selfEntityNameString.arr);


   /* EXEC SQL WHENEVER SQLERROR GOTO sql_error; */ 

   /* EXEC SQL CONTEXT USE :p_conn; */ 



   try
   {
      /* EXEC SQL UPDATE HLR_OSS_INSTANCES SET INSTANCE_STATUS = 0 where IP_ADDRESS=:l_selfIpAddress AND PROVISIONING_PORT=:l_selfIpPort and ENTITY_NAME=:l_selfEntityNameString and INSTANCE_TYPE='1'; */ 

{
      struct sqlexd sqlstm;
      sqlstm.sqlvsn = 12;
      sqlstm.arrsiz = 3;
      sqlstm.sqladtp = &sqladt;
      sqlstm.sqltdsp = &sqltds;
      sqlstm.stmt = "update HLR_OSS_INSTANCES  set INSTANCE_STATUS=0 where (\
((IP_ADDRESS=:b0 and PROVISIONING_PORT=:b1) and ENTITY_NAME=:b2) and INSTANCE_\
TYPE='1')";
      sqlstm.iters = (unsigned int  )1;
      sqlstm.offset = (unsigned int  )5;
      sqlstm.cud = sqlcud0;
      sqlstm.sqlest = (unsigned char  *)&sqlca;
      sqlstm.sqlety = (unsigned short)4352;
      sqlstm.occurs = (unsigned int  )0;
      sqlstm.sqhstv[0] = (unsigned char  *)&l_selfIpAddress;
      sqlstm.sqhstl[0] = (unsigned long )33;
      sqlstm.sqhsts[0] = (         int  )0;
      sqlstm.sqindv[0] = (         short *)0;
      sqlstm.sqinds[0] = (         int  )0;
      sqlstm.sqharm[0] = (unsigned long )0;
      sqlstm.sqadto[0] = (unsigned short )0;
      sqlstm.sqtdso[0] = (unsigned short )0;
      sqlstm.sqhstv[1] = (unsigned char  *)&l_selfIpPort;
      sqlstm.sqhstl[1] = (unsigned long )sizeof(int);
      sqlstm.sqhsts[1] = (         int  )0;
      sqlstm.sqindv[1] = (         short *)0;
      sqlstm.sqinds[1] = (         int  )0;
      sqlstm.sqharm[1] = (unsigned long )0;
      sqlstm.sqadto[1] = (unsigned short )0;
      sqlstm.sqtdso[1] = (unsigned short )0;
      sqlstm.sqhstv[2] = (unsigned char  *)&l_selfEntityNameString;
      sqlstm.sqhstl[2] = (unsigned long )53;
      sqlstm.sqhsts[2] = (         int  )0;
      sqlstm.sqindv[2] = (         short *)0;
      sqlstm.sqinds[2] = (         int  )0;
      sqlstm.sqharm[2] = (unsigned long )0;
      sqlstm.sqadto[2] = (unsigned short )0;
      sqlstm.sqtdso[2] = (unsigned short )0;
      sqlstm.sqphsv = sqlstm.sqhstv;
      sqlstm.sqphsl = sqlstm.sqhstl;
      sqlstm.sqphss = sqlstm.sqhsts;
      sqlstm.sqpind = sqlstm.sqindv;
      sqlstm.sqpins = sqlstm.sqinds;
      sqlstm.sqparm = sqlstm.sqharm;
      sqlstm.sqparc = sqlstm.sqharc;
      sqlstm.sqpadto = sqlstm.sqadto;
      sqlstm.sqptdso = sqlstm.sqtdso;
      sqlcxt(&p_conn, &sqlctx, &sqlstm, &sqlfpn);
      if (sqlca.sqlcode < 0) goto sql_error;
}



      /* EXEC SQL COMMIT; */ 

{
      struct sqlexd sqlstm;
      sqlstm.sqlvsn = 12;
      sqlstm.arrsiz = 3;
      sqlstm.sqladtp = &sqladt;
      sqlstm.sqltdsp = &sqltds;
      sqlstm.iters = (unsigned int  )1;
      sqlstm.offset = (unsigned int  )32;
      sqlstm.cud = sqlcud0;
      sqlstm.sqlest = (unsigned char  *)&sqlca;
      sqlstm.sqlety = (unsigned short)4352;
      sqlstm.occurs = (unsigned int  )0;
      sqlcxt(&p_conn, &sqlctx, &sqlstm, &sqlfpn);
      if (sqlca.sqlcode < 0) goto sql_error;
}


      LLOG(0,0,"LOAD UpdateInstanceStatus END");

      m_DbQueryRes=DB_QUERY_RES_SUCCESS;
      m_procErrorCode=0;

      return true;
   }
   catch(...)
   {
      /* EXEC SQL ROLLBACK; */ 

{
      struct sqlexd sqlstm;
      sqlstm.sqlvsn = 12;
      sqlstm.arrsiz = 3;
      sqlstm.sqladtp = &sqladt;
      sqlstm.sqltdsp = &sqltds;
      sqlstm.iters = (unsigned int  )1;
      sqlstm.offset = (unsigned int  )47;
      sqlstm.cud = sqlcud0;
      sqlstm.sqlest = (unsigned char  *)&sqlca;
      sqlstm.sqlety = (unsigned short)4352;
      sqlstm.occurs = (unsigned int  )0;
      sqlcxt(&p_conn, &sqlctx, &sqlstm, &sqlfpn);
      if (sqlca.sqlcode < 0) goto sql_error;
}


      m_sqlcode = sqlca.sqlcode;
      LLOG(0,0,"Load UPDATE UpdateInstanceStatus - Catch block");
      return false;
   }
sql_error :
   m_sqlcode = sqlca.sqlcode;
   /* EXEC SQL ROLLBACK; */ 

{
   struct sqlexd sqlstm;
   sqlstm.sqlvsn = 12;
   sqlstm.arrsiz = 3;
   sqlstm.sqladtp = &sqladt;
   sqlstm.sqltdsp = &sqltds;
   sqlstm.iters = (unsigned int  )1;
   sqlstm.offset = (unsigned int  )62;
   sqlstm.cud = sqlcud0;
   sqlstm.sqlest = (unsigned char  *)&sqlca;
   sqlstm.sqlety = (unsigned short)4352;
   sqlstm.occurs = (unsigned int  )0;
   sqlcxt(&p_conn, &sqlctx, &sqlstm, &sqlfpn);
   if (sqlca.sqlcode < 0) goto sql_error;
}


   LLOG(0,0,"Load UPDATE UpdateInstanceStatus Failed - Sql Error %d", m_sqlcode);
   return false;
}

