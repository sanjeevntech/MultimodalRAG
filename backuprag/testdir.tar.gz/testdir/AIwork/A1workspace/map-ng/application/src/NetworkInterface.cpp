/***********************************************************************
 ** FILE NAME  : NetworkInterface.cpp  
 ** AUTHOR     : 
 ** DEFINTION  : Interacts with ULTICOM stack to send/recv TCAP message.
 ** REMARKS    :
 **********************************************************************
 *********************************************************************/

#include <iostream>
#include <fstream>
#include <list>
#include <stdlib.h>
#include <string>
#include <time.h>

#include <apiinc.h>
#include <tcap.h>
#include <tcerror.h>
#include <ObjectServer.h>
#include <ccapiproto.h>

#include <NetworkInterface.h>
#include <MplManager.h>
#include <ServiceCoordinator.h>
#include <ExtendedServiceCoordinator.h>
#include <ContextBase.h>
#include <ModuleManager.h>
#include <DbActiveObject.h>
#include <TimerManager.h>
#include <ToolInterface.h>
#include <ConfigReader.h>
#include <Logger.h>
#include <MplManager.h>
#include <SmppInterface.h>
#include <CurrentTime.h>
#include <SnmpInterface.h>
#include <DiametriqInterface.h>
#include <GUtilThreadHeartBeat.h>
#include <typeinfo>
#include <MemCachedActiveObject.h>


extern time_t g_StackRegisteredTime;
extern bool g_CombinedInstance;

int AFormatSCCPcblock (sblock_t* psb         /* sblock from TCAP */
      ,cblock_t *cb     /* cblocks to be filled in */
      ,int size         /* max cblocks to fill */
      ,int *CblkRet); /* total number cblks filled*/
int AFormatSCCPsblock (sblock_t* psb         /* sblock from TCAP */
      ,cblock_t *cb     /* cblocks to be filled in */
      ,int size         /* max cblocks to fill */
      ,int *CblkRet); /* total number cblks filled*/
int AsccpEncodeAddress (U8 *pData,
      const SccpAddress *pAddress,
      U8                *pDataSize,
      SccpErrorReport   *pErrorReport);
int AsccpDecodeAddress(const U8 *pData,
      SccpAddress       *pAddress,
      U8                *pDataSize,
      SccpErrorReport   *pErrorReport);


int CFormatSCCPcblock (sblock_t* psb         /* sblock from TCAP */
      ,cblock_t *cb     /* cblocks to be filled in */
      ,int size         /* max cblocks to fill */
      ,int *CblkRet) /* total number cblks filled*/
{
   return cFormatSCCPcblock(psb, cb, size, CblkRet);
}


int CFormatSCCPsblock (sblock_t* psb         /* sblock from TCAP */
      ,cblock_t *cb     /* cblocks to be filled in */
      ,int size         /* max cblocks to fill */
      ,int *CblkRet) /* total number cblks filled*/
{
   return cFormatSCCPsblock(psb, cb, size, CblkRet);
}

int CsccpEncodeAddress (U8 *pData,
      const SccpAddress *pAddress,
      U8                *pDataSize,
      SccpErrorReport   *pErrorReport)
{
   return  sccpEncodeAddress (pData, pAddress, pDataSize, pErrorReport);
}


int CsccpDecodeAddress(const U8 *pData,
      SccpAddress       *pAddress,
      U8                *pDataSize,
      SccpErrorReport   *pErrorReport)
{
   return sccpDecodeAddress(pData, pAddress, pDataSize, pErrorReport);
}

extern void performTimerActions();
extern int g_firstVal;
extern int getContextManagerSize();
extern BOOL g_simulator;
extern BOOL g_oamFlag;
extern char g_ConfigFile[50];
extern int g_simulatorCount;
extern int g_simulatorOpCode;
extern MessageQueue *g_SimulatorCtxtQueue;
extern MessageQueue *g_InterModuleQueue;
extern MessageQueue *g_InterModuleQueue2;
extern MessageQueue *g_OamTransactionsList;
extern bool g_core_signal_received;

extern void getResourcesData(char *p_output);
extern void congestionControlActions();

int g_maxRecvMessagesAtAtime = 200;
U16 applicationID;
using namespace std;

/* global data */
BOOL tickTimerCalled;
time_t g_CurrTime=0;
time_t g_LastExecutedTimer=0;
bool g_CongestionTrapCheckingStatus=false;
bool exitStatus;
BOOL finished_initialization = FALSE;	/* Are we in the main loop yet? */

#define SERVER_IPC_RETRY 5
#define TCAP_ALRM_INT 1         /* interval for SIGALRM signals */

#ifdef __cplusplus
extern "C" {
#endif

   typedef void(*PFV)();

#ifdef __cplusplus
};
#endif


#define serverExit(x) FtTerminate(NOrestart, (x))

int terminateStack()
{
   NetworkInterface::getInstance().terminate();
   (void)signal(SIGALRM,    SIG_IGN);
   return 0;
}

int NetworkInterface::terminate()
{
   printf("\nNetworkInterface::terminate called");
#if 0
   printf("\npthread%d at terminate CscUOS %d", pthread_self(), m_nodeIndex);
   int l_result= CscUOS (m_nodeIndex, g_ConfigData->i_NgConfigData.m_LocalSSN);
   if (l_result == RETURNerror)
   {
      printf("\nCscUOS unsuccessfull errno: %d", errno);
      switch(errno)
      {
         case ENOENT:
            printf("\nCscUIS failed ENOENT\n");
            break;
         case EPATH:
            printf("\nCscUIS failed EPATH\n");
            break;
         case EDIST:
            printf("\nCscUIS failed EDIST\n");
            break;
         case EDISToptions:
            printf("\nCscUIS failed EDISToptions\n");
            break;
            //case ENotBound: -- Not found in Headers
            //   printf("\nCscUIS failed ENotBound\n");
            //   break;
         case EINVAL:
            printf("\nCscUIS failed EINVAL\n");
            break;
         case ESRCH:
            printf("\nCscUIS failed ESRCH\n");
            break;
         default:
            printf("\nCscUIS failed default\n");
            break;
      }
   }
   else
   {
      printf("\nCscUOS success\n");
   }
   printf("\nNetworkInterface::terminate CscUOS done");
#endif
   printf("\npthread%d at terminate CscUOS %d", pthread_self(), m_nodeIndex);
   int retVal;
   int distOpt = TCAP_DATA_PRIMITIVE;
#ifdef AC7_T
   distOpt |= TCAP_PROTO_A7;
#endif
#ifdef ACH7_T
   distOpt |= TCAP_PROTO_A7;
#endif
#ifdef AJ7_T
   distOpt |= TCAP_PROTO_A7;
#endif
#ifdef CA7_Q
   distOpt |= TCAP_PROTO_C7;
#endif
   printf("\nat terminate unbind %d", m_nodeIndex);
   retVal = SYSunbind( m_nodeIndex,
         /*Name Index provided during SYSbind */
         FALSE,           /* Not designatable */
         MTP_SCCP_TCAP_USER,   /*Protocol Path*/
         g_ConfigData->i_NgConfigData.m_LocalSSN,           /*TCAP User SSN */
         distOpt );
   if(RETURNok != retVal)
   {
      printf("\nSYSunbind failed, errno=%d\n",errno);
      return 1;
   }
   else
   {
      printf("\nSYSunbind success\n");
   }
   return 0;
}
extern bool releaseActivecall(bool signal);

/*****************************************************************************
 ** FUNCTION NAME  : NetworkInterface::getInstance
 ** DEFINITON      : This function returns the singleton instance of the class
 ** ARGUMENTS      : None
 ** RETURN         : It returns reference to singleton object of the class
 ** REMARKS        :
 *****************************************************************************/
NetworkInterface& NetworkInterface::getInstance()
{
   static NetworkInterface instance;
   return instance;
}

/*****************************************************************************
 ** FUNCTION NAME  : cUSERReleaseBuffer
 ** DEFINITON      : Call back function called from TCAP library.
 ** ARGUMENTS      : void *
 ** RETURN         : 
 ** REMARKS        : It releases User Data Buffer.
 *****************************************************************************/
void cUSERReleaseBuffer (void *ptr)
{
   unsigned char *relBuf = NULL;
   relBuf = (unsigned char *)ptr;
   TLOG(0,1,"cUSERReleaseBuffer called ");
   if(NULL != relBuf)
   {
      TLOG(0,1,"Releasing memory : %p", relBuf);
      delete []relBuf;
   }
   else
   {
      TLOG(0,1,"relBuf is NULL");
   }
}

/*****************************************************************************
 ** FUNCTION NAME  : SYSLogEvent 
 ** DEFINITON      : Print log information for TCAP library.
 ** ARGUMENTS      : entity, mask ptr
 ** RETURN         : 
 ** REMARKS        :
 *****************************************************************************/
void SYSLogEvent (int entity, int mask, char *ptr)
{
   DLOG(0,1, "TCAPLIB: %s, ENTITY: %d, MASK: %d",ptr, entity, mask);
}

/* FUNCTION cUSERTakeMsg() - Called by the TCAP to convert sblk->cblk */
/*************************************************************************

  FUNCTION
  cUSERTakeMsg()

  DESCRIPTION
  This function is called by the TCAP library when it is done
  building all TCAP components and wants to send the MSU to the
  driver. This function will format the sblock to cblock(s) and
  then it will send the cblock(s) to the SCCP streams module.

  INPUTS
Arg:    psb - pointer to the sblock.



OUTPUTS
Return: RETURNok - good status
RETURNerror - error condition

Args:   none

Others: Calls to cFormatSCCPcblock() and FtSendIpcEx().

FEND
 ************************************************************************/
/*****************************************************************************
 ** FUNCTION NAME  : cUSERTakeMsg 
 ** DEFINITON      : Called by TCAP to convert sblk->cblk
 ** ARGUMENTS      : psb
 ** RETURN         : 
 ** REMARKS        :
 *****************************************************************************/
int cUSERTakeMsg (sblock_t * psb)
{
   int CblkRet;
   int ret_status;
   cblock_t cb[16];
   int i;

   /* Convert TCAP filled Sblock to the Cblock     */
   TLOG(0,1,"cUSERTakeMsg is called");
   try
   {
      memset (&cb, '\0', sizeof cb);
      if('I' == g_OtherConfigData->m_SccpType)
      {
         ret_status = CFormatSCCPcblock (psb         /* sblock from TCAP */
               ,&cb[0]     /* cblocks to be filled in */
               ,16         /* max cblocks to fill */
               ,&CblkRet); /* total number cblks filled*/
      }
      else
      {
         ret_status = AFormatSCCPcblock (psb         /* sblock from TCAP */
               ,&cb[0]     /* cblocks to be filled in */
               ,16         /* max cblocks to fill */
               ,&CblkRet); /* total number cblks filled*/
      }
      if (ret_status == RETURNerror)
      {
         CLOG(0,1,"Error in converting sblock->cblock %s ",APIErr);
         g_si.sendSnmpTrap(g_TranslationTrap, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL); 
         return (RETURNerror);
      }

      /* Setup and send the Cblocks to the streams driver.     */
      for (i = 0; i < CblkRet; i++)
      {
         cb[i].hdr.messageType = N_UNITDATA_REQ;
         (void) sprintf (cb[i].hdr.destination, "%s.%s",
               g_ConfigData->i_NgConfigData.m_StackName, SCCPlogicalNAME);
         ret_status = FtSendIpcEx (&cb[i].hdr, sizeof cb[0], SERVER_IPC_RETRY,
               FALSE);
         if (ret_status != RETURNok)
         {
            DLOG(0,1, "Unable to send Ipc Msg to streams. errno=%d",errno);
            return (RETURNerror);
         }
      }
   }
   catch(...)
   {
      CLOG(0,1,"cUSERTakeMsg Exception occurred.");

   }
   return (RETURNok);
}

/* FUNCTION sigalrmHandler() - handler for ALRM signal from Unix */
/**************************************************************************

  FUNCTION
  void sigalrmHandler(void)

  DESCRIPTION
  This function is the signal handler for the Unix ALRM signal.

  INPUTS
Args:   none

Others: none


OUTPUTS
Return: none

Args:   none

Others: call to cTCAPTickTimer().
global flag tickTimerCalled set.

FEND
 **************************************************************************/
void sigalrmHandler2 (int p_signal)
{
   g_CongestionTrapCheckingStatus=true;
   tickTimerCalled = TRUE;
   if(0 == g_OtherConfigData->m_TCAPStackFlag)
   {
      (void)signal(SIGALRM,     sigalrmHandler2);     
      alarm(1);
   }
}
void sigalrmHandler (void)
{
   g_LastExecutedTimer = time(NULL);
   if((g_LastExecutedTimer - g_CurrTime) >= 1)
   {
      DLOG(0,0,"CurrentTimer[%d] LastExecutedTimer[%d] DiffTime[%d]", g_CurrTime, g_LastExecutedTimer, (g_LastExecutedTimer - g_CurrTime));
      g_CongestionTrapCheckingStatus=true;
      tickTimerCalled = TRUE;
      g_CurrTime = time(NULL);
   }
}

/* FUNCTION sigintHandler() - handler for INT signal from Unix */
/**************************************************************************
  FUNCTION
  void sigintHandler(void)

  DESCRIPTION
  This function is the signal handler for the Unix INT signal.  It
  causes the program to terminate.

  INPUTS
Args:   none

Others: none


OUTPUTS
Return: none

Args:   none

Others: Sets terminate.

FEND
 **************************************************************************/
void sigintHandler (void)
{
   CLOG(0,1,"SIGINT received, application is goig to exit... ");

   //releaseActivecall(true);
   exitStatus = true;
   //usleep(10000000);
}

/*****************************************************************************
 ** FUNCTION NAME  : NetworkInterface::openConn
 **
 ** DEFINITON      : This function is used to open connection with SS7 stack
 **
 ** ARGUMENTS      : className(in) -> The class containing information about
 **                  SS7 stack to be connected to
 **
 ** RETURN         : true if connection successfully opened
 **                  false if open connection failed
 **
 ** REMARKS        :
 *****************************************************************************/
bool NetworkInterface::openConn(int argc, char *argv[])
{
   char *l_maxMessagesAtATimeChar=NULL;
   l_maxMessagesAtATimeChar=getenv("MAX_TCAP_RECV_MESSAGES_AT_A_TIME");
   if(l_maxMessagesAtATimeChar != NULL)
   {
      LLOG(0,1,"MAX_TCAP_RECV_MESSAGES_AT_A_TIME is set as %s", l_maxMessagesAtATimeChar);
      g_maxRecvMessagesAtAtime=atoi(l_maxMessagesAtATimeChar);
   }
   else
   {
      LLOG(0,1,"MAX_TCAP_RECV_MESSAGES_AT_A_TIME is not set");
      g_maxRecvMessagesAtAtime=200;
   }

   try
   { 
      int result;
      int distOpt = TCAP_DATA_PRIMITIVE;
      char myLogicalName[MAXlogicalNAME + 1];
      char ObjectSVRBuf[MAXlogicalNAME + 1];

      char l_tempChar[30];
      snprintf(l_tempChar, sizeof(l_tempChar), "%s%03d_", g_ConfigData->m_EntityName, g_ConfigData->m_InstanceId);

      /* attach to Foundation Toolkit */
      FtUniqueName (l_tempChar, myLogicalName);
      if (FtAttachEx (myLogicalName, argv[0], " ", 0, 0, 0, 0, 5, FALSE) == RETURNerror)
      {
         cout<<"FtAttachEx failed exiting errno: "<<errno<<endl;
         CLOG(0,1,"%s: fatal error, FtAttachEx() failed, errno=%d, %s", argv[0],errno, LastErrorReport);
         return false;
      }
      strcpy(g_ConfigData->m_StackEntityName, myLogicalName);
      DLOG(0,1,"FtAttachEx is sucessfull");

      /* register with Foundation Toolkit */
      result = FtRegisterEx (argc, /* Cmd Ln Token Count        */
            argv,  /* Cmd Ln Tokens              */
            FALSE, /* Debug                      */
            FALSE, /* Monitor                    */
            TRUE,  /* Queue Required             */
            FALSE, /* Flush Queue                */
            TRUE,  /* Enqueue always             */
            TRUE,  /* Catches SIGINT             */
            NOrestart, /* Restart type           */
            0,     /* Class declaration          */
            0,     /* State declaration          */
            0,     /* Event filter               */
            10,    /* Retry count                */
            FALSE); /* Alertable                 */
      if (result == RETURNerror)
      {
         cout<<"FtRegisterEx failed exiting errno: "<<errno<<endl;
         CLOG(0,1,"%s: FtRegisterEx failed, errno=%d %s", argv[0], errno,LastErrorReport);
         return false;
      }
      DLOG(0,1, "FtRegisterEx is successful");

      /*if (FtAssignHandler (SIGINT, sigintHandler) == RETURNerror)
        {
        cout<<"FtAssignHandler() failed exiting errno: "<<errno<<endl;
        CLOG(0,1,"FtAssignHandler(SIGINT) failed, errno=%d",errno);
        return false;
        }*/
      DLOG(0,1, "FtAssignHandler is successful");

      /* attach and bind to logical node */
      int nodeIndex = SYSattach ((char *)g_ConfigData->i_NgConfigData.m_StackName, FALSE);
      if (nodeIndex == RETURNerror)
      {
         cout<<"SYSattach failed exiting errno: "<<errno<<endl;
         CLOG(0,1,"SYSattach failed, check -node value, errno=%d",errno);
         return false;
      }
      LLOG(0,1, "SYSattach is successful. NodeIndex[%d]", m_nodeIndex);

      m_nodeIndex=nodeIndex;

#ifdef AC7_T
      distOpt |= TCAP_PROTO_A7;
#endif
#ifdef ACH7_T
      distOpt |= TCAP_PROTO_A7;
#endif
#ifdef AJ7_T
      distOpt |= TCAP_PROTO_A7;
#endif
#ifdef CA7_Q
      distOpt |= TCAP_PROTO_C7;
#endif
      result = SYSbind (nodeIndex, FALSE, MTP_SCCP_TCAP_USER, g_ConfigData->i_NgConfigData.m_LocalSSN, distOpt);
      if (result == RETURNerror)
      {
         cout<<"SYSbind failed exiting errno: "<<errno<<endl;
         CLOG(0,1,"SYSbind failed, errno=%d",errno);
         return false;
      }
      DLOG(0,1, "SYSbind is successful");

      /* Send user-in-service from all processes.  Data-only processes
         send UIS because stopping the last remaining data
         process generates an automatic user-out-of-service.  */
      if (CscUIS (nodeIndex, g_ConfigData->i_NgConfigData.m_LocalSSN) == RETURNerror)
      {
         cout<<"CscUIS failed exiting errno: "<<errno<<endl;
         CLOG(0,1,"CscUIS send user-in-service failed, ssn=%d errno=%d", g_ConfigData->i_NgConfigData.m_LocalSSN, errno);
         return false;
      }
      DLOG(0,1, "CscUIS send user-in-service successful, ssn=%d.",g_ConfigData->i_NgConfigData.m_LocalSSN);

      /* Setup the SIGALRM signal handler */
      tickTimerCalled = FALSE;
      g_CurrTime=time(NULL);
      if (FtAssignHandler (SIGALRM, sigalrmHandler) == RETURNerror)
      {
         cout<<"FtAssignHandler failed exiting errno: "<<errno<<endl;
         CLOG(0,1,"FtAssignHandler(SIGALRM) failed, errno=%d",errno);
         return false;
      }
      DLOG(0,1, "FtAssignHandler is successful");

      //if (FtStartTimer (TCAP_ALRM_INT, 0, FALSE) == RETURNerror)
      if (FtStartTimer (((g_CombinedInstance==true)?0:TCAP_ALRM_INT), ((g_CombinedInstance==true)?10000:0), FALSE) == RETURNerror)
      {
         cout<<"FtStartTimer failed exiting errno: "<<errno<<endl;
         CLOG(0,1,"FtStartTimer failed, errno=%d",errno);
         return false;
      }
      DLOG(0,1, "FtStartTimer is successful");

      /* initialize TCAP and get a single dialog ID */
      applicationID = cTCAPInitialize (g_ConfigData->i_NgConfigData.m_MaxDialogs, 32000, 32000, 32000, 5, 5, 0, 0,
            CTCAP_NO_RECOVERY, FtMakeActiveName(ObjectSVRLogicalNAME, ObjectSVRBuf), g_ConfigData->i_NgConfigData.m_StackName, 
            g_ConfigData->i_NgConfigData.m_LocalSSN);
      if (applicationID == 0)
      {
         cout<<"cTCAPInitialize failed exiting errno: "<<errno<<endl;
         CLOG(0,1,"cTCAPInitialize failed, error %d, %s",ctcap_errno, cTCAPerrorReport);
         return false;
      }
      DLOG(0,1, "cTCAPInitialize is successful. ");
      /* This API call will disable decoding of dialogue portion
       * in inbound messages. Only high level parsing of dialog
       * portion is performed. There is no validation of ASN1 syntax
       * and the dialogue portion is passed to application as a byte
       * array via the pdata pointer in a tblock.
       */

      //Temporarily adding DP disable check
      //(void)cTCAPdisableDPcheck();

      finished_initialization = TRUE;     /* SIGINT will set terminate */

      if (g_simulator)
      {
         for (int i=0; i<g_simulatorCount; i++)
         {
            ContextBase *l_ct = g_mm.getRespectiveContext2(g_simulatorOpCode, NULL);
            if (l_ct != NULL)
            {
               l_ct->setClassName((char*)(typeid(*l_ct).name()));
               l_ct->startProcessing();
               if(0 == l_ct->m_ReferenceCount)
               {
                  DLOG(0,1,"Deleting the context at the call of startProcessing only");
                  delete(l_ct);
                  l_ct=NULL;
               }
            }
            else
            {

               printf("\nContext to simulate is NULL\n");
            }
         }
      }

   }       
   catch(...)
   {
      CLOG(0,1,"openConn Exception occurred.");
      return false;
   }
   return true;
}

/* FUNCTION handleTcapMsg() - handle possible primitive from TCAP */
/**************************************************************************

  FUNCTION
  void handleTcapMsg(void)

  DESCRIPTION
  This function is called by the sumServerData main loop whenever
  there may be one or more new user primitives available from the
  TCAP library, either because a received sblock has been passed
  to the TCAP library via cTCAPTakeMsg(), or because
  cTCAPTickTimer() has been called.  The function calls
  cTCAPGetTblock() and handles each primitive found.  Any error
  from cTCAPGetTblock(), other than "no tblock present", is
  treated as a fatal error.

  Normal paths through the function are: (a) Get a BEGIN from a
  client, call cTCAPGetTblock() again and get the INVOKE
  (containing a number) from the same message, send a RESULT_L
  containing the same number, send a CONTINUE, and make a new
  entry in the object server containing the number, using a name
  containing application and dialog ID.  (b) Get a CONTINUE from a
  client, call cTCAPGetTblock() again and get the INVOKE
  (containing a number) from the same message, fetch the previous
  sum from the object server (using application and dialog ID),
  add the new number to the sum, send a RESULT_L containing new
  sum, send a CONTINUE, and update the entry in the object server.
  (c) Get an END from a client, and delete the sum entry from the
  object server.

  All object server access is via the Call Context Library, see
  Call_Context_Intro(7o).  Reads will use the local cache if
  possible.  Writes are deferred until all TCAP library activity
  for the original dialog primitive is complete, so that all of
  the TCAP library's writes to the object server will be queued
  and piggybacked with the application's write.  In abnormal cases
  where the function gets a dialog primitive without writing an
  object, the function calls AccSendAllObj(3o) to complete any
  writes queued by the TCAP library.

  INPUTS
Args:   none

Others: new tblocks from TCAP library, via cTCAPGetTblock(),
getInvoke().
saved sum entries in object server, via fetchDB().


OUTPUTS
Return: none

Args:   none

Others: Tblocks sent to TCAP library via sendResult(),
sendContinue().
Writes to object server, via newDB(), storeDB(),
deleteDB().

FEND
 **************************************************************************/
void NetworkInterface::handleTcapMsg (void)
{
   ctblock_t prim;
   memset(&prim, '\0', sizeof(ctblock_t));
   int l_maxRecvMessagesAtAtime = g_maxRecvMessagesAtAtime;
   while (cTCAPGetTblock (&prim) != RETURNerror)
   {
      g_MplManager.processTcapMessage(&prim);
      l_maxRecvMessagesAtAtime--;
      if(0 == l_maxRecvMessagesAtAtime)
      {
         CLOG(0,1, "Incoming Message rate looks higher than %d. Trying to process other messages too...", g_maxRecvMessagesAtAtime);
         break;
      }
   }
}
/*
   void NetworkInterface::handleTcapMsg (void)
   {
   try
   {
   ctblock_t prim;
   ctblock_t comp;

   memset(&prim, '\0', sizeof(ctblock_t));
   while (cTCAPGetTblock (&prim) != RETURNerror)
//if(RETURNerror != cTCAPGetTblock (&prim))
{
DLOG(0,1, "%s<Ln: %d> cTCAPGetTblock(prim) [PrimType:%d DlgId:%d DPPres: %d CompPres: %d]", __FUNCTION__, __LINE__, prim.prim_code, prim.dialog_id, prim.tcu.dhp.dp_present_ind, prim.tcu.dhp.comp_present_ind);
if(0 != prim.tcu.dhp.comp_present_ind) //TODO: PKS What if more components are available ???
{
do
{
printf("\nProcessing Components here\n");
memset(&comp, '\0', sizeof(ctblock_t)); 
if (cTCAPGetTblock (&comp) == RETURNerror)
{
CLOG(0,1,"%s<Ln: %d> Failed to get component [Error %d, %s]", __FUNCTION__, __LINE__, ctcap_errno, cTCAPerrorReport);
break;
}
else
DLOG(0,1, "%s<Ln: %d> cTCAPGetTblock(comp) [PrimType:%d DlgId:%d lastCompInd: %d]", __FUNCTION__, __LINE__, comp.prim_code, comp.dialog_id, comp.tcu.chp.last_comp_ind);
//MsgHandler lMapMsgHnlr(prim.dialog_id);
//lMapMsgHnlr.processTcapMsg(prim, comp);
printTcapBlock("===>>", &prim, 1);
printTcapBlock("===>>", &comp, 1);
g_MplManager.processTcapDlgMessage(&prim, &comp, NULL);
} while(1 != comp.tcu.chp.last_comp_ind);

}
else
{
//MsgHandler lMapMsgHnlr(prim.dialog_id);
//lMapMsgHnlr.processTcapMsg(prim, comp);
printTcapBlock("===>>", &prim, 1);
g_MplManager.processTcapDlgMessage(&prim, NULL, NULL);

}
memset(&prim, '\0', sizeof(ctblock_t));
}
memset(&prim, '\0', sizeof(prim));
}
catch(...)
{
CLOG(0,1,"%s<Ln: %d> Exception occured.", __FUNCTION__, __LINE__);
}
}
*/

void morphMessage(InterModuleData *p_imd, char *p_orig)
{
   if(NULL == p_imd->m_Parameters)
   {
      CLOG(0,0,"p_imd->m_Parameters NULL returning");
      return;
   }
   TLOG(0,1,"Not processing the message. So morphing the message to store");
   int l_Length = strlen(p_imd->m_Parameters) + 200;
   char l_temp[l_Length];
   DLOG(0,0,"BEFORE filling MS_ORG p_imd->m_Parameters[%s]",(NULL == p_imd->m_Parameters)?"":p_imd->m_Parameters);
   snprintf(l_temp, sizeof(l_temp), "<MSG_ORIG>%s</MSG_ORIG><MSG_TYPE>MORPHED</MSG_TYPE><OP_CODE>%d</OP_CODE><XML>%s</XML>", 
         p_orig, p_imd->m_OpCode, p_imd->m_Parameters);

   snprintf(p_imd->m_Parameters,l_Length,"%s",l_temp);
   DLOG(0,0,"AFTER filling MS_ORG p_imd->m_Parameters[%s]",(NULL == p_imd->m_Parameters)?"":p_imd->m_Parameters);
   p_imd->m_OpCode = 1;
}

bool whatAllRegistered(char *p_registered)
{
   sprintf(p_registered, "%s", ",");

   if(1 == g_OtherConfigData->m_dcd.m_diameterNgRequired)
   {
      if(strlen(g_OtherConfigData->m_DiameterInterfaceType) > 0)
      {
         strcat(p_registered, g_OtherConfigData->m_DiameterInterfaceType);
         strcat(p_registered, ",");
      }
      else
      {
         strcat(p_registered, "DIAMETER-S6A,");
      }
   }
   if(1 == g_OtherConfigData->m_TCAPStackFlag)
   {
      strcat(p_registered, "TCAP,");
   }
   return true;
}

bool whetherToProcess(int p_opCode, EMsgType *p_msgType)
{
   //bool l_processTheMessage=true;
   *p_msgType=MSG_TYPE_UNKNOWN;
   if(p_opCode >= 316 && p_opCode <= 323)
   {
      *p_msgType=MSG_TYPE_DIAMETER;
       if(g_OtherConfigData->m_dcd.m_applicationId == 16777251 )
       {
          return true;
       }
       for(int l_i = 0; l_i < g_OtherConfigData->m_dcd.m_additionalAppIdcount; l_i++)
       {
          if(g_OtherConfigData->m_dcd.m_additionalAppId[l_i] == 16777251)
          {
             return true;
          }
       }
       return false;
   }
   else if(p_opCode >= 301 && p_opCode <= 309)
   {
      *p_msgType=MSG_TYPE_DIAMETER;
       if(g_OtherConfigData->m_dcd.m_applicationId == 16777216 || g_OtherConfigData->m_dcd.m_applicationId == 16777217 || g_OtherConfigData->m_dcd.m_applicationId == 16777265 )
       {
          return true;
       }
       for(int l_i = 0; l_i < g_OtherConfigData->m_dcd.m_additionalAppIdcount; l_i++)
       {
          if(g_OtherConfigData->m_dcd.m_additionalAppId[l_i] == 16777216 || g_OtherConfigData->m_dcd.m_additionalAppId[l_i] == 16777217 || g_OtherConfigData->m_dcd.m_additionalAppId[l_i] == 16777265)
          {
             return true;
          }
       }
       if(p_opCode == 309 && ((0 == g_OtherConfigData->m_TCAPStackFlag) || ((1 == g_OtherConfigData->m_TCAPStackFlag) && (g_ConfigData->i_NgConfigData.m_selfAddress.ssn != 6))) )
       {
          return true;
       }
       return false;
   }
   else
   {
      *p_msgType=MSG_TYPE_MAP;
      if( (p_opCode != 1) && (p_opCode != 89) && (p_opCode != 90))
      {
         if( (0 == g_OtherConfigData->m_TCAPStackFlag) || ((1 == g_OtherConfigData->m_TCAPStackFlag) && (g_ConfigData->i_NgConfigData.m_selfAddress.ssn != 6)) )
         {
            return false;
         }
      }
   }
   return true;
}

void processDbMessages()
{
   void *l_response = NULL;
   bool l_status = false;

   if (g_ConfigData->i_DbConfigData.m_DbRequired)
   {
      int l_countDbMessages=g_act.m_queues.m_res->size();
      do
      {
         l_status = g_act.m_queues.m_res->pop(&l_response);
         if (l_status)
         {
            --l_countDbMessages;
            g_sc.recvMsg((DbQueryMsg*)l_response);
         }
         else
         {
            //printf("\nNo DB Responses to process");
         }
      }
      while (l_status && (l_countDbMessages>0));
   }
}

void processOtherMessages()
{
   void *l_response = NULL;
   bool l_status = false;
   bool l_msgTypeMemc = false;

   if (g_ConfigData->i_DbConfigData.m_DbRequired)
   {
      int l_countDbMessages=g_act.m_queues.m_res->size();
      do
      {
         l_status = g_act.m_queues.m_res->pop(&l_response);
         if (l_status)
         {
            --l_countDbMessages;
            g_sc.recvMsg((DbQueryMsg*)l_response);
         }
         else
         {
            //printf("\nNo DB Responses to process");
         }
      }
      while (l_status && (l_countDbMessages>0));
   }

   if (g_ConfigData->m_MemcEnableFlag)
   {
      int l_countMemcMessages=g_MemcActObj.m_MemcQueues.memc_resQ->size();
      do
      {  
         l_status = g_MemcActObj.m_MemcQueues.memc_resQ->pop(&l_response);
         if (l_status)
         {
            l_msgTypeMemc = false;
            if(MSG_TYPE_MEMCACHED == ((MemCachedQueryMsg*)l_response)->m_MsgType)
               l_msgTypeMemc = true;

            --l_countMemcMessages;
            if(false == l_msgTypeMemc)
            {
               if( (((MemCachedQueryMsg*)l_response)->m_MemcErrorCode != 0) && ( DB_QUERY_CACHED_TYPE_ONLY_MEMCACHED_NO_DB != ((DbQueryMsg*)l_response)->m_DbQueryQueueType) ) 
               {
                  LLOG(0,0,"Pushing MemCached response back to DB Queue as it failed ErrCode[%d] ErrDesc[%s]",((MemCachedQueryMsg*)l_response)->m_MemcErrorCode,(char*)(((MemCachedQueryMsg*)l_response)->m_MemcErrorMessage).c_str());
                  if(DB_QUERY_QUEUE_TYPE_INITIAL == ((DbQueryMsg*)l_response)->m_DbQueryQueueType)
                  {
                     g_act.m_queues.m_req->push(l_response);
                  }
                  else
                  {
                     DLOG(0,0,"Memcached error pushing into LaterQueue as Query Type is Later");
                     g_act.m_queues.m_LaterQueryReq->push(l_response);
                  }
               }
               else  
               {
                  if(false == ((MemCachedQueryMsg*)l_response)->deSerializeMemc())
                  {
                     CLOG(0,0,"Pushing MemCached response back to DB Queue DeSerialize failed ErrCode[%d] ErrDesc[%s]",((MemCachedQueryMsg*)l_response)->m_MemcErrorCode,(char*)(((MemCachedQueryMsg*)l_response)->m_MemcErrorMessage).c_str());
                     g_act.m_queues.m_req->push(l_response);
                  }
                  else
                  {
                     DLOG(0,0,"going to call validateMemcachedContinuity fun");
                     if(false == ((MemCachedQueryMsg*)l_response)->validateMemcachedContinuity())
                     {
                        LLOG(0,0,"Pushing MemCached response back to DB Queue as validateMemcachedContinuity failed");
                        g_act.m_queues.m_req->push(l_response);
                     }
                     else
                     { 
                        DLOG(0,0,"Calling recvMsg with DbQueryMsg");
                        g_sc.recvMsg((DbQueryMsg*)l_response);
                     }
                  }
               }
            }
            else
            {
               if(false == ((MemCachedQueryMsg*)l_response)->deSerializeMemc())
               {
                  CLOG(0,0,"DeSerialize direct memcached query failed .. !!!!!"); //shall not push to DBQ .. resynchs shall happen unless settled TODO 
               }
               DLOG(0,0,"Calling recvMsg with MemCachedQueryMsg and MSG_TYPE_MEMCACHED");
               g_sc.recvMsg((MemCachedQueryMsg*)l_response);
            }
         }
         else
         {
            //printf("\nNo MEMC Responses to process");
         }
      }
      while (l_status && (l_countMemcMessages>0));
   }

   if (g_commandQueue != NULL)
   {
      void *l_command = NULL;
      l_status = g_commandQueue->pop(&l_command);
      if (l_status)
      {
         //printf("\nReceived a tool command [%s]\n", (char*)l_command);
         LLOG(0,1,"Received a tool command [%s]", (char*)l_command);
         processCommand((char*)l_command);
         //printf("\nDone with a tool command [%s]\n", (char*)l_command);
         delete[] (char*)l_command;
      }
   }

   if ( (g_SimulatorCtxtQueue != NULL))
   {
      bool l_continue=false;
      if(true == g_OtherConfigData->m_dcd.m_diameterNgRequired) 
      {
         if(true == g_di.m_diameterStackRegisteredFlag)
            l_continue=true;
         else
            l_continue=false;
      }
      else
      {
         l_continue=true;
      }

      if(true == l_continue)
      {
         int l_msgs = g_SimulatorCtxtQueue->size();
         for (int i=0; i<l_msgs; i++)
         {
            void *l_ctxt = NULL;
            l_status = g_SimulatorCtxtQueue->pop(&l_ctxt);
            if (l_status)
            {
               ((ContextBase*)l_ctxt)->startProcessing();
               if(0 == ((ContextBase*)l_ctxt)->m_ReferenceCount)
               {
                  DLOG(0,1,"Deleting the context at the call of startProcessing only");
                  delete((ContextBase*)l_ctxt);
                  l_ctxt=NULL;
               }
            }
         }
      }
   }

   if( g_InterModuleQueue != NULL)
   {
      void *l_temp = NULL;
      do
      {
         l_status = g_InterModuleQueue->pop(&l_temp);
         if(true == l_status)
         {
            TLOG(0,1,"popped");
            InterModuleData *l_imd = (InterModuleData*)l_temp; 

            EMsgType l_msgType;
            bool l_processTheMessage=whetherToProcess(l_imd->m_OpCode, &l_msgType);
            DLOG(0,0,"BEFORE CALLING morphMessage l_imd->m_Parameters[%s]",(NULL == l_imd->m_Parameters)?"":l_imd->m_Parameters);

            if(NULL != l_imd->m_Parameters)
            {
               if((false == l_processTheMessage) && (strlen(l_imd->m_Parameters)>0))
               {
                  morphMessage(l_imd, "IMD");
                  DLOG(0,0,"AFTER CALLING morphMessage l_imd->m_Parameters[%s]",(NULL == l_imd->m_Parameters)?"":l_imd->m_Parameters);
                  l_processTheMessage = true;
               }
            }

            if(true == l_processTheMessage)
            {
               ContextBase *l_ct = NULL;
               int l_opCodeIndex = l_imd->m_OpCode;
               if((304 == l_imd->m_OpCode) || (305 == l_imd->m_OpCode))
               {
                  LLOG(0,0,"getRespectiveContext2 called with imd");
                  l_ct = g_mm.getRespectiveContext2(l_imd->m_OpCode, l_imd);
               }
               else
               {
                  LLOG(0,0,"getRespectiveContext2 called with NULL");
                  l_ct = g_mm.getRespectiveContext2(l_imd->m_OpCode, NULL);
               }
               if (NULL == l_ct)
               {
                  LLOG(0,1,"sc pointer is null");
                  l_opCodeIndex = l_imd->m_OpCode+100;
                  if((304 == l_imd->m_OpCode) || (305 == l_imd->m_OpCode))
                  {
                     LLOG(0,0,"getRespectiveContext2 called with imd");
                     l_ct = g_mm.getRespectiveContext2(l_imd->m_OpCode, l_imd);
                  }
                  else
                  {
                     LLOG(0,0,"getRespectiveContext2 called with NULL");
                     l_ct = g_mm.getRespectiveContext2(l_imd->m_OpCode, NULL);
                  }
                  if (NULL == l_ct)
                  {
                     LLOG(0,1,"sc pointer is again null");
                  }
               }

               if(l_ct != NULL)
               {
                  l_ct->setClassName((char*)(typeid(*l_ct).name()));
                  strcpy(l_ct->m_ModName,     g_mm.m_mapping[l_msgType][l_opCodeIndex].m_ModName);
                  strcpy(l_ct->m_MessageName, g_mm.m_mapping[l_msgType][l_opCodeIndex].m_MessageName);

                  if(g_tfb != NULL)
                  {
                     l_ct->m_tdr.setOriginatingModule(l_imd->m_OriginatorModule);
                     l_ct->m_tdr.setOpCode(l_imd->m_OpCode);
                  }

                  bool l_deleteFlag=true;
                  //DLOG(0,0,"NetworkInterface: l_imd->m_Parameters[%s] [%d]",l_imd->m_Parameters, strlen(l_imd->m_Parameters));
                  l_ct->startProcessing(l_imd, l_deleteFlag);
                  if (true == l_deleteFlag)
                  {
                     delete(l_imd);
                  }
                  if(0 == l_ct->m_ReferenceCount)
                  {
                     DLOG(0,1,"Deleting the context at the call of startProcessing only");
                     delete(l_ct);
                     l_ct=NULL;
                  }
               }
               else
               {
                  CLOG(0,1,"Severe Error!! Check whether the Op Code %d is loaded or not", l_imd->m_OpCode);
                  delete(l_imd);
               }
            }
            else
            {
               WLOG(0,1,"Inter-Module Queue: Not processing the message of type %d", l_msgType);
               delete(l_imd);
            }
         }
      }while(true == l_status);
   }

   if( g_InterModuleQueue2 != NULL)
   {
      void *l_temp = NULL;
      do
      {
         l_status = g_InterModuleQueue2->pop(&l_temp);
         if(true == l_status)
         {
            TLOG(0,1,"popped");
            ExtendedInterModuleData *l_eimd = (ExtendedInterModuleData*)l_temp; 
            if(NULL == l_eimd->m_msgPtr)
            {
               LLOG(0,1,"m_msgPtr is NULL");
            }
            else
            {
               DiameterMsg *l_dm = (DiameterMsg*)(l_eimd->m_msgPtr);
               if(l_dm != NULL)
               {
                  g_esc.recvMsg((DiameterMsg*)l_eimd->m_msgPtr);
               }
               else
               {
                  LLOG(0,1,"l_dm is NULL");
               }
            }
            delete(l_eimd); //TODO:should not be deleted here since the m_msgPtr gets deleted in this destructor. find a way.
         }
      }while(true == l_status);
   }

   l_status=false;
   if (1 == g_ConfigData->m_EsmeConfigData.m_Required)
   {
      do
      {
         void *l_resp = NULL;
         l_status = SmppInterface::getInstance()->m_recvQ->pop(&l_resp);
         if (l_status)
         {
            struct Esme_Data *l_ed = (struct Esme_Data*)l_resp;
            switch (l_ed->command_id)
            {
               case SUBMIT_SM_RESP:
                  {
                     DLOG(0,0,"Received Submit Sm Resp");
                     switch (l_ed->command_status)
                     {
                        case SMPP_ESME_ROK:
                           {
                              LLOG(0,0,"Received SMPP_ESME_ROK for Seq No: %ld", l_ed->sequence_number);
                           }
                           break;

                        default:
                           {
                              CLOG(0,0,"Received Failure for Seq No: %ld", l_ed->sequence_number);
                           }
                           break;
                     }
                  }

               default:
                  {
                     DLOG(0,0,"Received Other Message: %d", l_ed->command_id);
                  }
                  break;
            }
         }
      }while(true == l_status);
   }

   if(g_OtherConfigData->m_dcd.m_diameterNgRequired)
   {
      if(true == g_di.m_initializedFlag)
      {
         int l_numberOfMessages = g_di.processDiameterMessages();
         if(0 == l_numberOfMessages)
         {
            if(0 == g_OtherConfigData->m_TCAPStackFlag)
            {
               usleep(10);
            }
         }
      }
   }

   if (true == g_NewFile)
   {
      char l_resourcesData[10000];
      memset(l_resourcesData, '\0', sizeof(l_resourcesData));
      getResourcesData(l_resourcesData);
      CLOG(1,1,"%s", l_resourcesData);
      g_NewFile=false;
   }
   if(true == g_sig_int_signal_received)
   {
      CLOG(0,1,"Shutting down the application in processMessages");
      exitFunc(EXIT_APPLICATION_TYPE_CTRL_SIGNAL_RCVD);
   }
   return;
}


///-#define MAX_OAM_TRANSACTIONS_PER_SEC  10

void processOamTransactions2()
{
   if (g_OtherConfigData->m_MaxProvInitiatingTransactions < 1)
   {
      CLOG(0,1,"MaxProvInitiatingTransactions is set to zero. Please configure an appropriate value");
      return;
   }

   if( g_OamTransactionsList != NULL)
   {
      if(1 == g_OtherConfigData->m_TCAPStackFlag)
      {
         int l_dialogs = getContextManagerSize();
         if (l_dialogs < g_OtherConfigData->m_ThresholdDialogsForInitiatingTransactions)
         {
            WLOG(0,1,"Available dialogues: %d less than threshold: %d", l_dialogs, g_OtherConfigData->m_ThresholdDialogsForInitiatingTransactions);
            return;
         }
      }

      int l_count=0;
      void *l_temp = NULL;
      bool l_status=false;
      do
      {
         l_status = g_OamTransactionsList->pop(&l_temp);
         if(true == l_status)
         {
            InterModuleData *l_imd = (InterModuleData*)l_temp; 

            EMsgType l_msgType;
            bool l_processTheMessage=whetherToProcess(l_imd->m_OpCode, &l_msgType);

            if(NULL != l_imd->m_Parameters)
            {
               if((false == l_processTheMessage) && (strlen(l_imd->m_Parameters)>0))
               {
                  morphMessage(l_imd, "OTL");
                  l_processTheMessage = true;
               }
            }

            if(true == l_processTheMessage)
            {
               ContextBase *l_ct = NULL;
               l_ct = g_mm.getRespectiveContext2(l_imd->m_OpCode, NULL);

               if(l_ct != NULL)
               {
                  l_ct->setClassName((char*)(typeid(*l_ct).name()));

                  strcpy(l_ct->m_ModName,     g_mm.m_mapping[l_msgType][l_imd->m_OpCode].m_ModName);
                  strcpy(l_ct->m_MessageName, g_mm.m_mapping[l_msgType][l_imd->m_OpCode].m_MessageName);

                  if(g_tfb != NULL)
                  {
                     l_ct->m_tdr.setOriginatingModule(l_imd->m_OriginatorModule);
                     l_ct->m_tdr.setOpCode(l_imd->m_OpCode);
                  }

                  bool l_deleteFlag=true;
                  l_ct->startProcessing(l_imd, l_deleteFlag);
                  if (true == l_deleteFlag)
                  {
                     delete(l_imd);
                  }
                  if(0 == l_ct->m_ReferenceCount)
                  {
                     DLOG(0,1,"ProvModuleQueue:: Deleting the context at the call of startProcessing only");
                     delete(l_ct);
                     l_ct=NULL;
                  }
               }
               else
               {
                  CLOG(0,1,"ProvModuleQueue:: Severe Error!! Check whether the Op Code %d is loaded or not", l_imd->m_OpCode);
                  delete(l_imd);
               }
            }
            else
            {
               WLOG(0,1,"OAM Trans List: Not processing the message of type %d", l_msgType);
               delete(l_imd);
            }
         }

         if(g_OtherConfigData->m_MaxProvInitiatingTransactions == l_count)
         {
            LLOG(0,1,"Maximum Transactions per second exceeded. Breaking");
            break;
         }
         l_count++;
      }while(true == l_status);
   }
}


void coreSignalHandler() //This function shall be called by main thread if some other thread got the core signal
{
   if (false == g_core_signal_received)
   {
      return;
   }

   printf("\n####### Core signal might have been received to some other thread\n");

   terminateStack();

   for(int i=1; i<=10000; i++) //Sleep forever
   {
      sleep(2); 
   }
}



int NetworkInterface::sendRecvMsgs()
{
   try
   {
      struct
      {
         cblock_t cblockIn;
         U8 data[2048];
      } ipcIn;

      sblock_t sblockIn;
      int nCblocksIn;
      memset(&sblockIn,'\0',sizeof(sblock_t));
      exitStatus = false;
      bool checkTCAP;
      checkTCAP = FALSE;

      FOREVER
      {
         checkTCAP = FALSE;
         if (tickTimerCalled)
         {
            //DLOG(0,0,"Tick Timer Called");
            if(1 == g_OtherConfigData->m_PrintTimerInLog)
            {
               TLOG(0,1,"Calling cTCAPTickTimer. Setting tickTimerCalled to false");
            }
            coreSignalHandler();
            if(1 == g_OtherConfigData->m_TCAPStackFlag)
            {
               cTCAPTickTimer ();
            }
            congestionControlActions();
            if((false == g_di.m_diameterStackRegisteredFlag) && (1 == g_OtherConfigData->m_dcd.m_diameterNgRequired))
            {
               time_t l_time = time(NULL);
               if(l_time > g_StackRegisteredTime + 10)
               {
                  ELOG(0,1,"Diamtriq Stack registration response timeout");
                  g_si.sendSnmpTrap(g_DiameterStackConnectionTrap, TRAP_TYPE_FAIL, TRAP_SEVERITY_CRITICAL);
                  exitFunc(EXIT_APPLICATION_TYPE_DIAM_STACK_REG_RESPONSE_TIMEOUT);
               }
               else
               {
                  LLOG(0,1,"Diamtriq Stack registration response not received since %d second(s)", l_time-g_StackRegisteredTime);
               }
            }


            tickTimerCalled = FALSE;
            checkTCAP = TRUE;
            processOamTransactions2(); // Want to perform this every second
            performTimerActions();
            setCurrentTime(); //This sets the global datestring variable with the current time
            if(true == g_sig_int_signal_received)
            {
               CLOG(0,1,"Shutting down the application in tickTimer");
               exitFunc(EXIT_APPLICATION_TYPE_CTRL_SIGNAL_RCVD);
            }

            if((0 != g_OtherConfigData->m_THBEnabled) && ((g_simulateThbHungInterval == 0 ) || (time(NULL) >= g_currTimeForTHB + g_simulateThbHungInterval)))
            {
               if(false == g_thb.iAmAlive())
               {
                  ELOG(0,1,"THB iAmAlive failed. Exiting...");
                  exitFunc(EXIT_APPLICATION_TYPE_THB_I_AM_ALIVE_FAILED);
               }
            }
         }
         else
         {
            if(1 == g_OtherConfigData->m_TCAPStackFlag)
            {
               //DLOG(0,1,"Calling FtGetIpcEx");
               if (FtGetIpcEx (&ipcIn.cblockIn.hdr, 0, sizeof ipcIn, TRUE, TRUE, TRUE) == RETURNerror)
               {
                  if (errno == EINTR)
                  {
                     //DLOG(0,1,"Calling processOtherMessages at FtGetIpcEx intr");
                     processOtherMessages();
                     continue;
                  }
                  cout<<"FtGetIpcEx() failed exiting errno: "<<errno<<endl;
                  CLOG(0,1,"FtGetIpcEx() failed, errno=%d",errno);
                  serverExit (1);
               }

               /* here we have a new IPC message */
               if (ipcIn.cblockIn.hdr.messageType == N_UNITDATA_IND || ipcIn.cblockIn.hdr.messageType == N_NOTICE_IND)
               {
                  if('I' == g_OtherConfigData->m_SccpType)
                  {
                     if (CFormatSCCPsblock (&sblockIn, &ipcIn.cblockIn, 1, &nCblocksIn) == RETURNerror)
                     {
                        extern char APIErr[256];

                        cout<<"cFormatSCCPsblock() failed exiting "<<endl;
                        CLOG(0,1,"cFormatSCCPsblock() failed, %s", APIErr);
                     }
                  }
                  else
                  {
                     if (AFormatSCCPsblock (&sblockIn, &ipcIn.cblockIn, 1, &nCblocksIn) == RETURNerror)
                     {
                        extern char APIErr[256];

                        cout<<"cFormatSCCPsblock() failed exiting "<<endl;
                        CLOG(0,1,"cFormatSCCPsblock() failed, %s", APIErr);
                     }
                  }
                  if (cTCAPTakeMsg (&sblockIn) == RETURNerror)
                  {
                     CLOG(0,1,"cTCAPTakeMsg() reported error %d, %s", ctcap_errno, cTCAPerrorReport);
                     if(TCAP_OUT_OF_TRANS_ID == ctcap_errno)
                     {
                        g_si.sendSnmpTrap(g_outOfDialgsTrap, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL);
                     }
                  }
                  checkTCAP = TRUE;
               }
            }
            else
            {
               processOtherMessages(); 
            }
         }
         if (checkTCAP && (1 == g_OtherConfigData->m_TCAPStackFlag))
         {
            //printf("Calling handleTcapMsg().\n");
            //if(g_firstVal)
               handleTcapMsg ();
            //DLOG(0,1,"Calling processOtherMessages  after handleTcapMsg ");
         }
         processOtherMessages(); 

         if(true == exitStatus)
         {
            CLOG(0,1,"Application going down.");
            exitFunc(EXIT_APPLICATION_TYPE_APPLICATION_IS_GOING_DOWN);
         }   
      }/* end FOREVER */
      return RETURNok;
   }
   catch(...)
   {
      ELOG(0,1,"sendRecvMsgs Exception occurred.");
      return RETURNerror;
   }
}
