#include <CtxtSubsProfiles.h>
#include <SubsProfilesManager.h>

CtxtSubsProfiles::CtxtSubsProfiles()
{

}

CtxtSubsProfiles::~CtxtSubsProfiles()
{
	DLOG(0,0,"CtxtSubsProfiles::~CtxtSubsProfiles()");
}

bool CtxtSubsProfiles::processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag)
{
	DLOG(0,0,"Start of CtxtSubsProfiles::processMsg function");



	return true;
}

