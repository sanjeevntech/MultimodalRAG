#include <DiameterSession.h>
#include <Logger.h>
#include <ConfigReader.h>

map<string,DiameterSession *> *g_DiameterSessionsList=NULL;

DiameterSession::DiameterSession()
{
   DLOG(0,1,"DiameterSession :cons:");
   m_diamSessType = DIAM_SESS_TYPE_UNKNOWN;
   m_diamSessState = DIAM_SESS_STATE_IDLE;
   m_tdr=new TdrData;
   m_crossedNg=false;
}

void DiameterSession::reset()
{
   m_diamSessType = DIAM_SESS_TYPE_UNKNOWN;
   m_diamSessState = DIAM_SESS_STATE_IDLE;
   if(NULL != m_tdr)
      delete(m_tdr);
   m_tdr = new TdrData;
   m_crossedNg=false;
}

DiameterSession::~DiameterSession()
{
   DLOG(0,1,"DiameterSession :des:");
}

