#include <MplManager.h>
#include <ModuleManager.h>
#include <DlgContext.h>
#include <MapMessages.h>
#include <ServiceCoordinator.h>
#include <Logger.h>
#include <sccp-addr.h>
#include <AsnCodec.h>
#include <ConfigReader.h>
#include <StatisticsInterface.h>
#include <DbActiveObject.h>
#include <SnmpInterface.h>
#include <CurrentTime.h>
#include <Utilities.h>
#include <GutilDAFInterface.h>
#include<algorithm>
#ifdef ULCM_SP5
#include <PlintronSccpAddr.h>
#elif ULCM_SP6
#include <PlintronSccpAddr_SP6.h>
#else
#error "ULCM version undefined"
#endif


extern int g_CurrentActiveTransactions;
bool g_DbCongestionStatus=false;
bool g_currentWindowDbCongestionStatus=false;
bool g_currentWindowTransPerSecStatus=false;
int g_CurrentActiveTransactions=0;
int g_lastCongestionTrapSentTime=0;
bool g_lastDbCongestionTrapType=false;
bool g_lastTransPerSecTrapType=false;

GenericUtilitiesFrameworkInterface *g_daf = NULL;             //to get DAF TPS added in HLR 5.0.4.0

char tdrNgErrorsArr[][100] = {
   /* 300 */      "Accept",
   /* 301 */      "ExceededTransPerSec",
   /* 302 */      "ExceededTransPerSec-P1",
   /* 303 */      "ExceededTransPerSec-P2",
   /* 304 */      "ExceededTransPerSec-P3",
   /* 305 */      "ExceededTransPerSec-P4",
   /* 306 */      "ExceededTransPerSec-P5",
   /* 307 */      "ExceededDbReq",
   /* 308 */      "ExceededDbReq-P1",
   /* 309 */      "ExceededDbReq-P2",
   /* 310 */      "ExceededDbReq-P3",
   /* 311 */      "ExceededDbReq-P4",
   /* 312 */      "ExceededDbReq-P5",
   /* 313 */      "UnknownPriority",
   /* 314 */      "UnknownApplVersion",                  
   /* 315 */      "ApplCtxtDowngrade",
   /* 316 */      "NotSupportedApplCtxt",
   /* 317 */      "ApplCtxtAbsentInDlgPortion",
   /* 318 */      "DlgPortionAndComponentsAbsent",
   /* 319 */      "NoCompononetsApartFromBsgInV1",
   /* 320 */      "ApplRejection",
   /* 321 */      "InvalidComponent",
   /* 322 */      "ExceededLaterDbReq",
   /* 323 */      "ExceededLaterDbReq-P1",
   /* 324 */      "ExceededLaterDbReq-P2",
   /* 325 */      "ExceededLaterDbReq-P3",
   /* 326 */      "ExceededLaterDbReq-P4",
   /* 327 */      "ExceededLaterDbReq-P5",
   /* 328 */      "DlgInvalidTT",
   /* 329 */      "DlgMaximum"
};


char otherErrorCodeChar[][100] = {
   /* 00 */      "RcvdPrimVerUAbort",
   /* 01 */      "RcvdPrimGenUAbort",
   /* 02 */      "RcvdPrimPAbort",
   /* 03 */      "RcvdPrimTcNotice",
   /* 04 */      "RcvdPrimLCancel",
   /* 05 */      "RcvdCompLCancel",
   /* 06 */      "RcvdCompUCancel",
   /* 07 */      "RcvdCompRReject",
   /* 08 */      "RcvdCompLReject",
   /* 09 */      "RcvdCompUReject",
   /* 10 */      "SentPrimVerUAbort",
   /* 11 */      "SentPrimGenUAbort",
   /* 12 */      "SentPreArrangedEnd", //added in HLR 2.0.21.0
   /* 13 */      "OtherErrorCodeMax"
};

MplManager g_MplManager;

extern void genericPrintPdu(AsnCodec *p_asnCodec, int p_msgType,void *p_dataStruct, char*);


extern U16 applicationID;
extern U32 remotePC;
extern U8 remoteSSN;
extern int localPC;
extern U8 localSSN;

void SignalMapOpenInd(int p_dialogueId, MAP_BeginSubscriberActivityArg *, EMapApplicationContext, U8 *orig, U8 *dest);
void SignalMapDelInd(int p_dialogueId);
void SignalMapCloseInd(int p_dialogueId);
void SignalMapProvError(int p_dialogueId, EMapProvError p_error, EMapProvErrorRejectType, U8, U8, U8);
void SignalMapUAbortInd(int p_dialogueId, U8 p_AbortCause, U8 p_AbortReason);
void SignalMapPAbortInd(int p_dialogueId);
void SignalMapNoticeInd(int p_dialogueId);
void SignalMapOpenCnf(int p_dialogueId, int p_version, ERefuseReason p_reason);
void sendMessage(MapMsg *p_MapMsgPtr);


int g_incomingMapReqIndex=-1;
int g_incomingMapTransRejIndex=-1;
int g_incomingMapDbRejIndex=-1;
int g_incomingDiameterReqIndex=-1;
int g_incomingDiameterTransRejIndex=-1;
int g_incomingDiameterDbRejIndex=-1;
int g_incomingSccpDbRejIndex=-1; //6471
int g_incomingSccpTransRejIndex=-1; //6471
int g_incomingSccpReqIndex=-1; //6471

int g_DiaDiffTime10=-1;
int g_DiaDiffTime5_10=-1;
int g_DiaDiffTime1_5=-1;
int g_DiaDiffTime05=-1;
int g_DiaDiffTime001=-1;
int g_DiaDiffTime0102=-1;
int g_DiaDiffTime0205=-1;
int g_DiaDiffTime051=-1;
int g_DiaDiffTime12=-1;
int g_DiaDiffTime25=-1;

int g_MapDiffTime10=-1;
int g_MapDiffTime5_10=-1;
int g_MapDiffTime1_5=-1;
int g_MapDiffTime05=-1;
int g_MapDiffTime0=-1;

extern int g_maxTpsDataIndex;
extern int g_maxInitialDbTpsIndex;
extern int g_maxLaterDbTpsIndex;

L_SccpAddress g_partnerTranslatedAddr;

L_SccpAddress getSelfAddress(U8 *p_remoteAddress)
{
   U8 l_dataSize=0;
   SccpAddress l_sccpAddress;
   SccpErrorReport l_errorReport;
   memset(&l_sccpAddress, '\0', sizeof(l_sccpAddress));
   l_dataSize=MAX_ADDR_LEN;
   l_sccpAddress.protocol = g_protocol;
   memset(&l_errorReport, '\0', sizeof(l_errorReport));

   sccpDecodeAddress(p_remoteAddress,
         &l_sccpAddress,
         &l_dataSize,
         &l_errorReport);

   TLOG(0,1,"getSelfAddress called with digits [%s]", l_sccpAddress.globalTitle.addressInformation);

   map<char*, char*>::iterator l_it;
   for(l_it = g_OtherConfigData->m_ExtTranslationMap.begin(); l_it != g_OtherConfigData->m_ExtTranslationMap.end(); l_it++)
   {
      DLOG(0,1,"Checking with CCNDC %s", l_it->first);
      int l_res = strncmp(l_it->first, l_sccpAddress.globalTitle.addressInformation, strlen(l_it->first));
      if(0 == l_res)
      {
         TLOG(0,1,"getSelfAddress matched with CCNDC %s. Sending GT %s", l_it->first, l_it->second);
         g_partnerTranslatedAddr=g_ConfigData->i_NgConfigData.m_selfAddress;
         strcpy(g_partnerTranslatedAddr.globalTitle.addressInformation, l_it->second);
         g_partnerTranslatedAddr.globalTitle.addressInformationLength = strlen(g_partnerTranslatedAddr.globalTitle.addressInformation);
         g_partnerTranslatedAddr.addressIndicator.routingIndicator = g_ConfigData->i_NgConfigData.m_selfAddress.addressIndicator.routingIndicator;
         if (g_partnerTranslatedAddr.globalTitle.addressInformationLength % 2)
            g_partnerTranslatedAddr.globalTitle.encodingScheme = L_ES_BCD_ODD;
         else
            g_partnerTranslatedAddr.globalTitle.encodingScheme = L_ES_BCD_EVEN;
         return g_partnerTranslatedAddr;

      }
   }
   TLOG(0,1,"getSelfAddress CCNDC %s not matched at all. Sending self address only");
   return (g_ConfigData->i_NgConfigData.m_selfAddress);
}


bool encodeSccpAddress(U8 *p_data, SccpAddress *p_addr)
{
   U8 l_length = 200;
   SccpErrorReport err;
   memset(&err,'\0',sizeof(SccpErrorReport));

   TLOG(0,1,"Protocol %d A7_PROTCOL:%d C7_PROTOCOL:%d", p_addr->protocol, A7_PROTOCOL, C7_PROTOCOL);
   TLOG(0,1,"AI PCI:%d  SSNI:%d  GTI:%d  RI:%d  NI:%d", 
         p_addr->addressIndicator.pointCodeIndicator, 
         p_addr->addressIndicator.ssnIndicator,
         p_addr->addressIndicator.globalTitleIndicator,
         p_addr->addressIndicator.routingIndicator,
         p_addr->addressIndicator.nationalIndicator);
   TLOG(0,1,"GTT %s", p_addr->globalTitle.addressInformation);
   TLOG(0,1,"SSN %d", p_addr->ssn);
   TLOG(0,1,"NP %d", p_addr->globalTitle.numberingPlan);
   TLOG(0,1,"ES %d", p_addr->globalTitle.encodingScheme);
   TLOG(0,1,"TT %02x", p_addr->globalTitle.translationType);
   TLOG(0,1,"NAI %02x", p_addr->globalTitle.natureOfAddressIndicator);

   if(g_protocol == A7_PROTOCOL)
   {
      if('N' == g_OtherConfigData->m_AnsiNationalIndicator)
      {
         p_addr->addressIndicator.nationalIndicator = 1;
      }
      else
      {
         p_addr->addressIndicator.nationalIndicator = 0;
      }
   }
   if (RETURNerror == sccpEncodeAddress(p_data, p_addr, &l_length, &err))
   {
      ELOG(0,1,"Severe Error: Unable to encode Sccp Address Error Length [%d] Msg [%s]", 
            err.errorLength, err.errorMsg);
      return false;
   }
   TLOG(0,1,"Length of the data %d", l_length);
   return true;
}



char *getTcapPrimChar(int p_prim)
{
   switch (p_prim)
   {
      case TC_UNI:
         return "TC_UNI";
      case TC_BEGIN:
         return "TC_BEGIN";
      case TC_CONTINUE:
         return "TC_CONTINUE";
      case TC_END:
         return "TC_END";
      case TC_U_ABORT:
         return "TC_U_ABORT";
      case TC_P_ABORT:
         return "TC_P_ABORT";
      case TC_NOTICE:
         return "TC_NOTICE";
      case TC_INVOKE:
         return "TC_INVOKE";
      case TC_RESULT_L:
         return "TC_RESULT_L";
      case TC_RESULT_NL:
         return "TC_RESULT_NL";
      case TC_U_ERROR:
         return "TC_U_ERROR";
      case TC_L_CANCEL:
         return "TC_L_CANCEL";
      case TC_U_CANCEL:
         return "TC_U_CANCEL";
      case TC_R_REJECT:
         return "TC_R_REJECT";
      case TC_L_REJECT:
         return "TC_L_REJECT";
      case TC_U_REJECT:
         return "TC_U_REJECT";
      default:
         return "UNKNOWN";

   }
}


char *getTcapAbortCauseChar(int p_cause)
{
   switch (p_cause)
   {
      case 0x00:
         return "DP_UNREC_MESSAGE";
         break;
      case 0x01:
         return "DP_UNREC_TID";
         break;
      case 0x02:
         return "DP_BAD_FORMAT_TR";
         break;
      case 0x03:
         return "DP_INCORRECT_TR";
         break;
      case 0x04:
         return "DP_RESOURCE_LIMIT";
         break;
      case 0x05:
         return "DP_ABNORMAL_DIALOGUE";
         break;
      case 0x06:
         return "DP_NO_COMMON_DIALOGUE_PORTION";
         break;
      default:
         return "UNKNOWN_ABORT";
         break;
   }
}

char *getTcapAbortReasonChar(int p_reason)
{
   switch (p_reason)
   {
      case 0x00:
         return "ABRT_NOT_PRESENT";
         break;
      case 0x01:
         return "ABRT_APPLICATION_CONTEXT_NOT_SUPPORTED";
         break;
      case 0x02:
         return "ABRT_DIALOGUE_REFUSED";
         break;
      case 0x03:
         return "ABRT_DIALOGUE_USER_DEFINED";
         break;
      default:
         return "UNKNOWN_ABORT_REASON";
         break;

   }
}

void getProbTypeChar(int p_problem, int p_problemCode, char *p_problemTypeChar, char *p_ProbCodeChar)
{
   switch (p_problem)
   {
      case CP_PT_GP:
         switch (p_problemCode)
         {
            case CP_GP_UR_COMP:
               strcpy(p_ProbCodeChar, "CP_GP_UR_COMP: unrecognized component");
               break;
            case CP_GP_MT_COMP:
               strcpy(p_ProbCodeChar, "CP_GP_MT_COMP: mistyped component");
               break;
            case CP_GP_BS_COMP:
               strcpy(p_ProbCodeChar, "CP_GP_BS_COMP: badly structured component");
               break;
            default:
               strcpy(p_ProbCodeChar, "UNKNOWN_GP_PROBLEM");
               break;
         }
         strcpy(p_problemTypeChar, "CP_PT_GP: general problem");
         break;
      case CP_PT_IP:
         switch (p_problemCode)
         {
            case CP_IP_DUP_INV_ID:
               strcpy(p_ProbCodeChar, "CP_IP_DUP_INV_ID: Duplicate Invoke ID");
               break;
            case CP_IP_UR_OP:
               strcpy(p_ProbCodeChar, "CP_IP_UR_OP: Unrecognized Operation");
               break;
            case CP_IP_MT_PARA:
               strcpy(p_ProbCodeChar, "CP_IP_MT_PARA: Mistyped Parameter");
               break;
            case CP_IP_RL:
               strcpy(p_ProbCodeChar, "CP_IP_RL: Resource Limitation");
               break;
            case CP_IP_IR:
               strcpy(p_ProbCodeChar, "CP_IP_IR: Initiating Release");
               break;
            case CP_IP_UR_LNK_ID:
               strcpy(p_ProbCodeChar, "CP_IP_UR_LNK_ID: Unrecognized Linked ID");
               break;
            case CP_IP_LR_UE:
               strcpy(p_ProbCodeChar, "CP_IP_LR_UE: Linked Response Unexpected");
               break;
            case CP_IP_UE_LO:
               strcpy(p_ProbCodeChar, "CP_IP_UE_LO: Unexpected Linked Operation");
               break;
            default:
               strcpy(p_ProbCodeChar, "UNKNOWN_IP_PROBLEM");
               break;
         }
         strcpy(p_problemTypeChar, "CP_PT_IP: invoke problem");
         break;
      case CP_PT_RRP:
         switch (p_problemCode)
         {
            case CP_RRP_UR_INV_ID:
               strcpy(p_ProbCodeChar, "CP_RRP_UR_INV_ID: Unrecognized Invoke ID");
               break;
            case CP_RRP_RR_UE:
               strcpy(p_ProbCodeChar, "CP_RRP_RR_UE: Returned Result Unexpected");
               break;
            case CP_RRP_MT_PARA:
               strcpy(p_ProbCodeChar, "CP_RRP_MT_PARA: Mistyped Parameter");
               break;
            default:
               strcpy(p_ProbCodeChar, "UNKNOWN_RRP_PROBLEM");
               break;
         }
         strcpy(p_problemTypeChar, "CP_PT_RRP: return result problem");
         break;
      case CP_PT_REP:
         switch (p_problemCode)
         {
            case CP_REP_UR_INV_ID:
               strcpy(p_ProbCodeChar, "CP_REP_UR_INV_ID: Unrecognized Invoke ID");
               break;
            case CP_REP_RE_UE:
               strcpy(p_ProbCodeChar, "CP_REP_RE_UE: Returned Error Unexpected");
               break;
            case CP_REP_UR_ERR:
               strcpy(p_ProbCodeChar, "CP_REP_UR_ERR: Unrecognized Error");
               break;
            case CP_REP_UE_ERR:
               strcpy(p_ProbCodeChar, "CP_REP_UE_ERR: Unexpected Error");
               break;
            case CP_REP_MT_PARA:
               strcpy(p_ProbCodeChar, "CP_REP_MT_PARA: Mistyped Parameter");
               break;
            default:
               strcpy(p_ProbCodeChar, "UNKNOWN_REP_PROBLEM");
               break;
         }
         strcpy(p_problemTypeChar, "CP_PT_REP: return error problem");
         break;
      default:
         strcpy(p_ProbCodeChar, "N/A");
         strcpy(p_problemTypeChar, "N/A");
         break;

   }	
}


char g_globalPara[4000+1];
char g_globalSent[1000+1];

///-memset(g_globalSent, '\0', 1000); 

#define LPRINTF(...)  { snprintf(g_globalSent, 1000, __VA_ARGS__); strcat(g_globalPara, g_globalSent); }



void printTcapBlock(char *p_string, ctblock_t *p_tcap, int p_flag)
{
   if (p_flag)
   {
      StatisticsInterface::logRespondingTcapPrimCount(p_tcap->prim_code);
   }
   else
   {
      StatisticsInterface::logInitiatingTcapPrimCount(p_tcap->prim_code);
   }

   if ( (0 == g_ConfigData->m_ConsoleTcapPduPrintFlag) &&  (0 == g_ConfigData->m_LogTcapPduPrintFlag) )
   {
      return;
   }

   if(2 == g_ConfigData->m_LogTcapPduPrintFlag)
   {
      if (0 != p_tcap->data_len)
      {
         char l_arr[2000+1];
         hexToString((unsigned char *)l_arr, 2000, p_tcap->pdata, p_tcap->data_len);
         LLOG(0,1,"%s  DLG_ID:%d: [ %s ] [ %s]    ", p_string, p_tcap->dialog_id, getTcapPrimChar(p_tcap->prim_code), l_arr);
         if (g_ConfigData->m_ConsoleTcapPduPrintFlag)
         {
            printf("\n%s  DLG_ID:%d: [ %s ] [ %s]    ", p_string, p_tcap->dialog_id, getTcapPrimChar(p_tcap->prim_code), l_arr);
         }
      }
      else
      {
         LLOG(0,1,"%s  DLG_ID:%d: [ %s ] ", p_string, p_tcap->dialog_id, getTcapPrimChar(p_tcap->prim_code));
         if (g_ConfigData->m_ConsoleTcapPduPrintFlag)
         {
            printf("\n%s  DLG_ID:%d: [ %s ] ", p_string, p_tcap->dialog_id, getTcapPrimChar(p_tcap->prim_code));
         }
      }
      return;
   }

   memset(g_globalPara, '\0', sizeof(g_globalPara));

   ///-struct tm *l_timeStruct=NULL;
   ///-char *l_dateString=NULL;
   ///-time_t l_tim =time(NULL);
   ///-l_timeStruct = localtime(&l_tim);
   ///-l_dateString = asctime(l_timeStruct);
   ///-l_dateString[24] = 0;
   ///-char l_dateString[30];
   ///-getCurrentTime(l_dateString);

   if (0 != p_tcap->data_len)
   {
      char l_arr[2000+1];
      hexToString((unsigned char *)l_arr, 2000, p_tcap->pdata, p_tcap->data_len);

      LPRINTF("\n\n%s  DLG_ID:%d: [ %s ] [ %s]\n", p_string, p_tcap->dialog_id, getTcapPrimChar(p_tcap->prim_code), l_arr);
   }
   else
   {
      LPRINTF("\n\n%s  DLG_ID:%d: [ %s ] \n", p_string, p_tcap->dialog_id, getTcapPrimChar(p_tcap->prim_code));
   }

   if (TC_END == p_tcap->prim_code)
   {
      LPRINTF("\n\t  Term Type  : [%s]", ((1==p_tcap->tcu.dhp.dialog_term_type)?"PRE_ARRANGED_TERMINATE":"BASIC_TERMINATE"));
   }

   switch (p_tcap->prim_code)
   {
      case TC_UNI:
      case TC_BEGIN:
      case TC_CONTINUE:
      case TC_END:
      case TC_U_ABORT:
      case TC_P_ABORT:
      case TC_NOTICE:
         {
            size_t l_stringLen=300;
            char l_string[300+1];
            U8 l_dataSize=0;
            SccpAddress l_sccpAddress;
            SccpErrorReport l_errorReport;

            memset(l_string, '\0', 300+1);
            memset(&l_sccpAddress, '\0', sizeof(l_sccpAddress));
            l_dataSize=MAX_ADDR_LEN;
            l_sccpAddress.protocol = g_protocol;
            memset(&l_errorReport, '\0', sizeof(l_errorReport));
            sccpDecodeAddress((U8*)&(p_tcap->tcu.dhp.remote_address),
                  &l_sccpAddress,
                  &l_dataSize,
                  &l_errorReport);
    
            sccpDumpStructureAddressToString(l_string, &l_stringLen, &l_sccpAddress);
            ///-LPRINTF("\n\t  Remote Addr: [ %s]", l_string);


            char l_string2[300+1];
            memset(l_string2, '\0', 300+1);
            l_stringLen=300;
            memset(&l_sccpAddress, '\0', sizeof(l_sccpAddress));
            l_dataSize=MAX_ADDR_LEN;
            l_sccpAddress.protocol = g_protocol;
            memset(&l_errorReport, '\0', sizeof(l_errorReport));
            sccpDecodeAddress((U8*)&(p_tcap->tcu.dhp.local_address),
                  &l_sccpAddress,
                  &l_dataSize,
                  &l_errorReport);
            sccpDumpStructureAddressToString(l_string2, &l_stringLen, &l_sccpAddress);
            ///-LPRINTF("\n\t  Local Addr : [ %s]", l_string);

            LPRINTF("\n\t  Remote Addr: [ %s]\n\t  Local Addr: [ %s]\n\t  DP Ind     : [%d]\tComp Ind : [%d]\tQuality Svc : [%d]", 
                  l_string,
                  l_string2,
                  p_tcap->tcu.dhp.dp_present_ind,
                  p_tcap->tcu.dhp.comp_present_ind,
                  p_tcap->tcu.dhp.qlty_of_svc);
            if (p_tcap->tcu.dhp.dp_present_ind)
            {
               if ( (TC_U_ABORT == p_tcap->prim_code) ||
                     (TC_P_ABORT == p_tcap->prim_code) )
               {
                  LPRINTF("\n\t  AbortReason : [%s]", getTcapAbortReasonChar(p_tcap->tcu.dhp.pdp->abort_reason));
               }
            }
         }
         break;

      case TC_INVOKE:
      case TC_RESULT_L:
      case TC_RESULT_NL:
      case TC_U_ERROR:
      case TC_L_CANCEL:
      case TC_U_CANCEL:
      case TC_R_REJECT:
      case TC_L_REJECT:
      case TC_U_REJECT:
         LPRINTF("\n\t  Invoke Id  : [%d]\tLinked Id : [%d]\tLast Comp : [%d]\tClass : [%d]\tTimer Value : [%d]", 
               p_tcap->tcu.chp.invoke_id, 
               p_tcap->tcu.chp.linked_id,
               p_tcap->tcu.chp.last_comp_ind,
               p_tcap->tcu.chp.class_of_oper, 
               p_tcap->tcu.chp.timer_value);
         break;

      default:
         LPRINTF("\n\tUNKNOWN MESSAGE");
         break;
   }

   //Write Primitive specific data
   if(  (TC_R_REJECT == p_tcap->prim_code) ||
         (TC_L_REJECT == p_tcap->prim_code) ||
         (TC_U_REJECT == p_tcap->prim_code)
     )
   {
      char l_probCodeChar[100];
      memset(l_probCodeChar, '\0', 100);
      char l_probTypeChar[100];
      memset(l_probTypeChar, '\0', 100);
      getProbTypeChar(p_tcap->tcu.chp.problem_type,
            p_tcap->tcu.chp.problem_code,
            l_probTypeChar,
            l_probCodeChar);

      LPRINTF("\n\t  Prob Type  : [0x%02x - %s ]\n\t  Prob Code  : [0x%02x - %s ]", p_tcap->tcu.chp.problem_type, l_probTypeChar,
            p_tcap->tcu.chp.problem_code, l_probCodeChar);
   }
   if ( (TC_U_ABORT == p_tcap->prim_code) ||
         (TC_P_ABORT == p_tcap->prim_code) )
   {
      LPRINTF("\n\t  AbortCause : [%s]", getTcapAbortCauseChar(p_tcap->tcu.dhp.abort_cause));
   }

   if(TC_INVOKE == p_tcap->prim_code)
   {
      if(p_tcap->data_len >= 3)
      {
         LPRINTF("\n\t  Operation  : [%s]", MapConstants::getMapOpCodeChar(p_tcap->pdata[2]));
      }
      else
      {
         LPRINTF("\n\t  Operation  : [%s]", "NOT PRESENT");
      }
   }

   if(  (TC_RESULT_L == p_tcap->prim_code) ||
         (TC_RESULT_NL == p_tcap->prim_code)
     )
   {
      if(p_tcap->data_len >= 5)
      {
         LPRINTF("\n\t  Operation  : [%s]", MapConstants::getMapOpCodeChar(p_tcap->pdata[4]));
      }
      else
      {
         LPRINTF("\n\t  Operation  : [%s]", "NOT PRESENT");
      }
   }

   if(TC_U_ERROR == p_tcap->prim_code)
   {
      if(p_tcap->data_len >= 3)
      {
         LPRINTF("\n\t  Error      : [%s]", MapConstants::getMapErrorCodeChar(p_tcap->pdata[2]));
      }
      else
      {
         LPRINTF("\n\t  Error      : [%s]", "NOT PRESENT");
      }
   }
   //End of writing Primitive specific data

   ///-LPRINTF("\n\t  Data Length: [%d]\t", p_tcap->data_len);


   ///-char l_dataString[1000];
   ///-char l_temp[5];
   ///-memset(l_dataString, '\0', sizeof(l_dataString));
   ///-for (int i=0; i<p_tcap->data_len; i++)
   ///-{
   ///-   ///-memset(l_temp, '\0', 5);
   ///-   sprintf(l_temp, " %02x",  p_tcap->pdata[i]);
   ///-   strcat(l_dataString, l_temp);
   ///-}
   ///-LPRINTF("\n\t  Data Length: [%d]\t%s\n\t------------------------------\n\n", p_tcap->data_len, l_dataString);
   ///-LPRINTF("\n\t------------------------------\n\n");

   if (g_ConfigData->m_ConsoleTcapPduPrintFlag)
   {
      printf("%s", g_globalPara);
   }

   if (g_ConfigData->m_LogTcapPduPrintFlag)
   {
      LLOG(0,1,g_globalPara);
   }
}


TcapMsg::TcapMsg()
{
}

MplManager::MplManager()
{

}

MplManager::~MplManager()
{

}

bool initializeMplManagerStatistics(StatisticsGenerator *p_sg)
{
   for(int i=2; i<STATS_MAX_OP_CODES; i++)
   {
      g_MplManager.m_si.m_Respondingops[i].m_TotalCount[0]   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, MapConstants::getMapOpCodeChar(i), "v1 R-Tot", '0');
      g_MplManager.m_si.m_Respondingops[i].m_SuccessCount[0] = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, MapConstants::getMapOpCodeChar(i), "v1 R-Suc", '0');
      g_MplManager.m_si.m_Initiatingops[i].m_TotalCount[0]   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, MapConstants::getMapOpCodeChar(i), "v1 I-Tot", '0');
      g_MplManager.m_si.m_Initiatingops[i].m_SuccessCount[0] = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, MapConstants::getMapOpCodeChar(i), "v1 I-Suc", '0');

      g_MplManager.m_si.m_Respondingops[i].m_TotalCount[1]   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, MapConstants::getMapOpCodeChar(i), "v2 R-Tot", '0');
      g_MplManager.m_si.m_Respondingops[i].m_SuccessCount[1] = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, MapConstants::getMapOpCodeChar(i), "v2 R-Suc", '0');
      g_MplManager.m_si.m_Initiatingops[i].m_TotalCount[1]   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, MapConstants::getMapOpCodeChar(i), "v2 I-Tot", '0');
      g_MplManager.m_si.m_Initiatingops[i].m_SuccessCount[1] = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, MapConstants::getMapOpCodeChar(i), "v2 I-Suc", '0');

      g_MplManager.m_si.m_Respondingops[i].m_TotalCount[2]   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, MapConstants::getMapOpCodeChar(i), "v3 R-Tot", '0');
      g_MplManager.m_si.m_Respondingops[i].m_SuccessCount[2] = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, MapConstants::getMapOpCodeChar(i), "v3 R-Suc", '0');
      g_MplManager.m_si.m_Initiatingops[i].m_TotalCount[2]   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, MapConstants::getMapOpCodeChar(i), "v3 I-Tot", '0');
      g_MplManager.m_si.m_Initiatingops[i].m_SuccessCount[2] = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, MapConstants::getMapOpCodeChar(i), "v3 I-Suc", '0');
   }
   DLOG(0,0,"checking 1");
   list<reportData> :: iterator l_it;
   for(l_it = g_OtherConfigData->m_reportDataList.begin(); l_it!=g_OtherConfigData->m_reportDataList.end(); l_it++)
   {
      DLOG(0,0,"checking 2");
      for(int i=2; i<STATS_MAX_OP_CODES; i++)
      {
         DLOG(0,0,"checking ######");
         char l_opcodeChar[4 + 1];
         memset(l_opcodeChar, '\0', sizeof(l_opcodeChar));
         snprintf(l_opcodeChar, sizeof(l_opcodeChar)+1, ",%02d,", i);
         DLOG(0,0,"l_opcodeChar is %s and opcode from file is %s",l_opcodeChar, l_it->m_opCodes.c_str());
         size_t l_found = l_it->m_opCodes.find(l_opcodeChar);
         if(l_found != string::npos)
         {
            DLOG(0,0,"opcode matched with config");
            char l_opCodeMatched[200 + 1], l_opCodeNotMached[200 + 1],l_tmpOpCodeChar[19 + 1];
            memset(l_opCodeMatched, '\0', sizeof(l_opCodeMatched));
            memset(l_opCodeNotMached, '\0', sizeof(l_opCodeNotMached));
            memset(l_tmpOpCodeChar, '\0', sizeof(l_tmpOpCodeChar));
            snprintf(l_tmpOpCodeChar, sizeof(l_tmpOpCodeChar), "%02d:%s" ,i, MapConstants::getMapOpCodeChar(i));
            snprintf(l_opCodeMatched, sizeof(l_opCodeMatched)+1, "%s:%s:gt_matched", l_it->m_reportName.c_str(), l_tmpOpCodeChar);
            snprintf(l_opCodeNotMached, sizeof(l_opCodeNotMached)+1, "%s:%s:gt_not_matched", l_it->m_reportName.c_str(), l_tmpOpCodeChar);
            DLOG(0,0,"final string for matched is %s and for not matched is %s",l_opCodeMatched, l_opCodeNotMached);

            l_it->m_RespondingOpCodesIndices[i].m_TotalCountGTMat[0] = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, l_opCodeMatched, "v1 R-Tot", '5');
            l_it->m_RespondingOpCodesIndices[i].m_SuccessCountGTMat[0] = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, l_opCodeMatched, "v1 R-Suc",  '5');
            l_it->m_InitiatingOpCodesIndices[i].m_TotalCountGTMat[0]   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, l_opCodeMatched, "v1 I-Tot", '5');
            l_it->m_InitiatingOpCodesIndices[i].m_SuccessCountGTMat[0] = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, l_opCodeMatched, "v1 I-Suc", '5');
            l_it->m_RespondingOpCodesIndices[i].m_TotalCountGTMat[1] = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, l_opCodeMatched, "v2 R-Tot", '5');
            l_it->m_RespondingOpCodesIndices[i].m_SuccessCountGTMat[1] = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, l_opCodeMatched, "v2 R-Suc",  '5');
            l_it->m_InitiatingOpCodesIndices[i].m_TotalCountGTMat[1]   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, l_opCodeMatched, "v2 I-Tot", '5');
            l_it->m_InitiatingOpCodesIndices[i].m_SuccessCountGTMat[1] = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, l_opCodeMatched, "v2 I-Suc", '5');
            l_it->m_RespondingOpCodesIndices[i].m_TotalCountGTMat[2] = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, l_opCodeMatched, "v3 R-Tot", '5');
            l_it->m_RespondingOpCodesIndices[i].m_SuccessCountGTMat[2] = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, l_opCodeMatched, "v3 R-Suc",  '5');
            l_it->m_InitiatingOpCodesIndices[i].m_TotalCountGTMat[2]   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, l_opCodeMatched, "v3 I-Tot", '5');
            l_it->m_InitiatingOpCodesIndices[i].m_SuccessCountGTMat[2] = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, l_opCodeMatched, "v3 I-Suc", '5');
            l_it->m_RespondingOpCodesIndices[i].m_TotalCountGTNotMat[0] = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, l_opCodeNotMached, "v1 R-Tot", '5');
            l_it->m_RespondingOpCodesIndices[i].m_SuccessCountGTNotMat[0] = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, l_opCodeNotMached, "v1 R-Suc", '5');
            l_it->m_InitiatingOpCodesIndices[i].m_TotalCountGTNotMat[0]   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, l_opCodeNotMached, "v1 I-Tot", '5');
            l_it->m_InitiatingOpCodesIndices[i].m_SuccessCountGTNotMat[0] = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, l_opCodeNotMached, "v1 I-Suc", '5');
            l_it->m_RespondingOpCodesIndices[i].m_TotalCountGTNotMat[1] = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, l_opCodeNotMached, "v2 R-Tot", '5');
            l_it->m_RespondingOpCodesIndices[i].m_SuccessCountGTNotMat[1] = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, l_opCodeNotMached, "v2 R-Suc", '5');
            l_it->m_InitiatingOpCodesIndices[i].m_TotalCountGTNotMat[1]   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, l_opCodeNotMached, "v2 I-Tot", '5');
            l_it->m_InitiatingOpCodesIndices[i].m_SuccessCountGTNotMat[1] = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, l_opCodeNotMached, "v2 I-Suc", '5');
            l_it->m_RespondingOpCodesIndices[i].m_TotalCountGTNotMat[2] = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, l_opCodeNotMached, "v3 R-Tot", '5');
            l_it->m_RespondingOpCodesIndices[i].m_SuccessCountGTNotMat[2] = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, l_opCodeNotMached, "v3 R-Suc", '5');
            l_it->m_InitiatingOpCodesIndices[i].m_TotalCountGTNotMat[2]   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, l_opCodeNotMached, "v3 I-Tot", '5');
            l_it->m_InitiatingOpCodesIndices[i].m_SuccessCountGTNotMat[2] = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, l_opCodeNotMached, "v3 I-Suc", '5');
         }
         else
         {
            DLOG(0,0,"opcode not matched with config");
         }
      }    
   }

   for(int i=1; i<MAP_AC_CODE_MAXIMUM; i++)
   {
      g_MplManager.m_si.m_Respondingappls[i].m_TotalCount[0]   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, MapConstants::getMapApplCodeChar(i), "v1 R-Tot", '1');
      g_MplManager.m_si.m_Respondingappls[i].m_SuccessCount[0] = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, MapConstants::getMapApplCodeChar(i), "v1 R-Suc", '1');
      g_MplManager.m_si.m_Initiatingappls[i].m_TotalCount[0]   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, MapConstants::getMapApplCodeChar(i), "v1 I-Tot", '1');
      g_MplManager.m_si.m_Initiatingappls[i].m_SuccessCount[0] = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, MapConstants::getMapApplCodeChar(i), "v1 I-Suc", '1');

      g_MplManager.m_si.m_Respondingappls[i].m_TotalCount[1]   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, MapConstants::getMapApplCodeChar(i), "v2 R-Tot", '1');
      g_MplManager.m_si.m_Respondingappls[i].m_SuccessCount[1] = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, MapConstants::getMapApplCodeChar(i), "v2 R-Suc", '1');
      g_MplManager.m_si.m_Initiatingappls[i].m_TotalCount[1]   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, MapConstants::getMapApplCodeChar(i), "v2 I-Tot", '1');
      g_MplManager.m_si.m_Initiatingappls[i].m_SuccessCount[1] = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, MapConstants::getMapApplCodeChar(i), "v2 I-Suc", '1');

      g_MplManager.m_si.m_Respondingappls[i].m_TotalCount[2]   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, MapConstants::getMapApplCodeChar(i), "v3 R-Tot", '1');
      g_MplManager.m_si.m_Respondingappls[i].m_SuccessCount[2] = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, MapConstants::getMapApplCodeChar(i), "v3 R-Suc", '1');
      g_MplManager.m_si.m_Initiatingappls[i].m_TotalCount[2]   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, MapConstants::getMapApplCodeChar(i), "v3 I-Tot", '1');
      g_MplManager.m_si.m_Initiatingappls[i].m_SuccessCount[2] = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, MapConstants::getMapApplCodeChar(i), "v3 I-Suc", '1');
   }
   for(int i=2; i<=89; i++)
   {
      if(NULL != strstr(MapConstants::getMapOpCodeChar(i), "dummy"))
      {
         DLOG(0,0,"Ignoring opcode:%d, %s", i, MapConstants::getMapOpCodeChar(i));
         continue;
      }
      for(int j=1; j<STATS_MAX_ERROR_CODES-2; j++)
      {
         if(NULL != strstr(MapConstants::getMapErrorCodeChar(j), "dummy"))
         {
            DLOG(0,0,"Ignoring errorcode:%d, %s", j, MapConstants::getMapErrorCodeChar(j));
            continue;
         }
         char l_string[20+1];
         int l_returnInt=0;
         if( (strlen(MapConstants::getMapOpCodeChar(i)) + strlen(MapConstants::getMapErrorCodeChar(j))) > 48)
         {
            char l_shortOp[50+1];
            char l_shortErr[50+1];
            snprintf(l_shortOp, sizeof(l_shortOp), "Op%02d", i);
            snprintf(l_shortErr, sizeof(l_shortErr), "Err%02d", j);

            l_returnInt  = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, l_shortOp, l_shortErr, '2');
         }
         else
         {
            l_returnInt  = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, MapConstants::getMapOpCodeChar(i), MapConstants::getMapErrorCodeChar(j), '2');
         }
         snprintf(l_string, sizeof(l_string), "%02d:%02d", i, j);
         g_MplManager.m_si.m_opCodeErrorCodeCountsMap[l_string] = l_returnInt;

      }

      g_MplManager.m_si.m_OpCodeErrorCodeCnt[i] = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, MapConstants::getMapOpCodeChar(i), "default", '2');
      if(g_MplManager.m_si.m_OpCodeErrorCodeCnt[i] < 0)
      {
         CLOG(0,0,"Adding OpCode:%s for default failed", MapConstants::getMapOpCodeChar(i));
         return false;
      }

      for(int j=0; j<OTHER_ERROR_CODE_MAXIMUM; j++)
      {
         int l_returnInt;
         if( (strlen(MapConstants::getMapOpCodeChar(i)) + strlen( otherErrorCodeChar[j])) > 48)
         {
            char l_shortOp[50+1];
            snprintf(l_shortOp, sizeof(l_shortOp), "Op%d", i);

            l_returnInt = g_MplManager.m_si.m_OpCodeOtherErrorCodeCnts[i][j] = 
               p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, l_shortOp, otherErrorCodeChar[j], '2');
            if(l_returnInt < 1)
            {
               CLOG(0,0,"addHeader failed for OpCode[%s], ErrorCode[%s]", l_shortOp, otherErrorCodeChar[j]);
               return false;
            }
         }
         else
         {
            l_returnInt = g_MplManager.m_si.m_OpCodeOtherErrorCodeCnts[i][j] = 
               p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, MapConstants::getMapOpCodeChar(i), otherErrorCodeChar[j], '2');
            if(l_returnInt < 1)
            {
               CLOG(0,0,"addHeader failed for OpCode[%s], ErrorCode[%s]", MapConstants::getMapOpCodeChar(i), otherErrorCodeChar[j]);
               return false;
            }
         }
      }

   }

   g_MplManager.m_si.m_RespondingTcapPrimCount[1]          = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"TC_UNI",       "R", '3');
   g_MplManager.m_si.m_RespondingTcapPrimCount[2]          = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"TC_BEGIN",     "R", '3');
   g_MplManager.m_si.m_RespondingTcapPrimCount[3]          = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"TC_CONTINUE",  "R", '3');
   g_MplManager.m_si.m_RespondingTcapPrimCount[4]          = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"TC_END",       "R", '3');
   g_MplManager.m_si.m_RespondingTcapPrimCount[5]          = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"TC_U_ABORT",   "R", '3');
   g_MplManager.m_si.m_RespondingTcapPrimCount[6]          = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"TC_P_ABORT",   "R", '3');
   g_MplManager.m_si.m_RespondingTcapPrimCount[7]          = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"TC_NOTICE",    "R", '3');
   g_MplManager.m_si.m_RespondingTcapPrimCount[8]          = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"TC_INVOKE",    "R", '3');
   g_MplManager.m_si.m_RespondingTcapPrimCount[9]          = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"TC_RESULT_L",  "R", '3');
   g_MplManager.m_si.m_RespondingTcapPrimCount[10]         = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"TC_RESULT_NL", "R", '3');
   g_MplManager.m_si.m_RespondingTcapPrimCount[11]         = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"TC_U_ERROR",   "R", '3');
   g_MplManager.m_si.m_RespondingTcapPrimCount[12]         = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"TC_L_CANCEL",  "R", '3');
   g_MplManager.m_si.m_RespondingTcapPrimCount[13]         = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"TC_U_CANCEL",  "R", '3');
   g_MplManager.m_si.m_RespondingTcapPrimCount[14]         = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"TC_R_REJECT",  "R", '3');
   g_MplManager.m_si.m_RespondingTcapPrimCount[15]         = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"TC_L_REJECT",  "R", '3');
   g_MplManager.m_si.m_RespondingTcapPrimCount[16]         = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"TC_U_REJECT",  "R", '3');

   g_MplManager.m_si.m_InitiatingTcapPrimCount[1]          = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"TC_UNI",       "I", '3');
   g_MplManager.m_si.m_InitiatingTcapPrimCount[2]          = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"TC_BEGIN",     "I", '3');
   g_MplManager.m_si.m_InitiatingTcapPrimCount[3]          = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"TC_CONTINUE",  "I", '3');
   g_MplManager.m_si.m_InitiatingTcapPrimCount[4]          = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"TC_END",       "I", '3');
   g_MplManager.m_si.m_InitiatingTcapPrimCount[5]          = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"TC_U_ABORT",   "I", '3');
   g_MplManager.m_si.m_InitiatingTcapPrimCount[6]          = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"TC_P_ABORT",   "I", '3');
   g_MplManager.m_si.m_InitiatingTcapPrimCount[7]          = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"TC_NOTICE",    "I", '3');
   g_MplManager.m_si.m_InitiatingTcapPrimCount[8]          = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"TC_INVOKE",    "I", '3');
   g_MplManager.m_si.m_InitiatingTcapPrimCount[9]          = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"TC_RESULT_L",  "I", '3');
   g_MplManager.m_si.m_InitiatingTcapPrimCount[10]         = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"TC_RESULT_NL", "I", '3');
   g_MplManager.m_si.m_InitiatingTcapPrimCount[11]         = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"TC_U_ERROR",   "I", '3');
   g_MplManager.m_si.m_InitiatingTcapPrimCount[12]         = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"TC_L_CANCEL",  "I", '3');
   g_MplManager.m_si.m_InitiatingTcapPrimCount[13]         = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"TC_U_CANCEL",  "I", '3');
   g_MplManager.m_si.m_InitiatingTcapPrimCount[14]         = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"TC_R_REJECT",  "I", '3');
   g_MplManager.m_si.m_InitiatingTcapPrimCount[15]         = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"TC_L_REJECT",  "I", '3');
   g_MplManager.m_si.m_InitiatingTcapPrimCount[16]         = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"TC_U_REJECT",  "I", '3');


   g_incomingMapReqIndex                      = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"MAP Req Received", "", 'C');
   g_incomingMapTransRejIndex                 = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"MAP Req Rejected (Trans Congestion)", "", 'C');
   g_incomingMapDbRejIndex                    = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"MAP Req Rejected (DB Congestion)", "", 'C');
   g_incomingDiameterReqIndex                 = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"DIAM Req Received", "", 'C');
   g_incomingDiameterTransRejIndex            = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"DIAM Req Rejected (Trans Congestion)", "", 'C');
   g_incomingDiameterDbRejIndex               = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"DIAM Req Rejected (DB Congestion)", "", 'C');
   g_incomingSccpReqIndex                     = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"SCCP Req Received", "", 'C');
   g_incomingSccpTransRejIndex                = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"SCCP Req Rejected (Trans Congestion)", "", 'C');
   g_incomingSccpDbRejIndex                   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"SCCP Req Rejected (DB Congestion)", "", 'C');
   g_maxTpsDataIndex                          = p_sg->addHeader(PEG_TYPE_MAX_COUNTER," Maximum TPS observed", "", 'C');

   g_maxInitialDbTpsIndex                     = p_sg->addHeader(PEG_TYPE_MAX_COUNTER," Maximum Initial DB TPS observed", "", 'C');
   g_maxLaterDbTpsIndex                       = p_sg->addHeader(PEG_TYPE_MAX_COUNTER," Maximum Later DB TPS observed", "", 'C');

  g_DiaDiffTime10		= p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"DIAM diffTime >= 10s","",'3');
  g_DiaDiffTime5_10	= p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"DIAM diffTime >= 5s and < 10s","",'3');
  g_DiaDiffTime1_5		= p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"DIAM diffTime >= 1s and < 5s","",'3');
  g_DiaDiffTime05		= p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"DIAM diffTime >= 0.5s and < 1s","",'3');
  g_DiaDiffTime25    = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"DIAM diffTime >= 0.2s and < 0.5s","",'3');
  g_DiaDiffTime12    = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"DIAM diffTime >= 0.1s and < 0.2s","",'3');
  g_DiaDiffTime051   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"DIAM diffTime >= 0.05s and < 0.1s","",'3');
  g_DiaDiffTime0205  = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"DIAM diffTime >= 0.02s and < 0.05s","",'3');
  g_DiaDiffTime0102  = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"DIAM diffTime >= 0.01s and < 0.02s","",'3');
  g_DiaDiffTime001   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"DIAM diffTime >= 0s and < 0.01s","",'3');

  g_MapDiffTime10		= p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"MAP diffTime >= 10s","",'3');
  g_MapDiffTime5_10	= p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"MAP diffTime >= 5s and < 10s","",'3');
  g_MapDiffTime1_5		= p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"MAP diffTime >= 1s and < 5s","",'3');
  g_MapDiffTime05		= p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"MAP diffTime >= 0.5s and < 1s","",'3');
  g_MapDiffTime0		= p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"MAP diffTime >= 0s and < 0.5s","",'3');

   return true;
}

bool MplManager::initialize(int p_dialogs)
{

   g_DlgContexts = new DlgContext[p_dialogs+1];

   for (int i=0; i<p_dialogs+1; i++)
   {
      (g_DlgContexts+i)->reset();
   }

   return true;
}


ctblock_t g_TcapCompMsg;
ctblock_t g_TcapComp2Msg;

void setError(int p_dialogid, int p_errorCode)
{
   (g_DlgContexts+p_dialogid)->m_tdr->setInteger(4, p_errorCode); 
   if( (p_errorCode >= DLG_ACCEPT) &&
         (p_errorCode <= DLG_MAXIMUM) )
   {
      (g_DlgContexts+p_dialogid)->m_tdr->setString(5, tdrNgErrorsArr[p_errorCode-300]);
   }

}

bool MplManager::processTcapMessage(ctblock_t *p_tcapMsg)
{
   DLOG(0,1,"Processing TCAP msg");

   printTcapBlock("===>>", p_tcapMsg, 1);

   switch (p_tcapMsg->prim_code)
   {
      case 0:
      case TC_UNI:
      case TC_BEGIN:
      case TC_CONTINUE:
      case TC_END:
      case TC_U_ABORT:
      case TC_P_ABORT:
      case TC_NOTICE:

	      if(TC_BEGIN == p_tcapMsg->prim_code)
	      {
		      U8 l_dataSize=0;
		      SccpAddress l_sccpAddress;
		      SccpErrorReport l_errorReport;
		      memset(&l_sccpAddress, '\0', sizeof(l_sccpAddress));
		      l_dataSize=MAX_ADDR_LEN;
		      l_sccpAddress.protocol = g_protocol;
		      memset(&l_errorReport, '\0', sizeof(l_errorReport));
		      sccpDecodeAddress((U8*)&(p_tcapMsg->tcu.dhp.remote_address),
				      &l_sccpAddress,
				      &l_dataSize,
				      &l_errorReport);

		      DLOG(0,0,"Incoming TT in Remote Addr is %d",l_sccpAddress.globalTitle.translationType);
		      if(1 == g_OtherConfigData->m_AllowedTTListValidation)
		      {	
                      vector<int> :: iterator l_TTValue;
		      l_TTValue = find(g_OtherConfigData->m_allowedTTs.begin(), g_OtherConfigData->m_allowedTTs.end(), l_sccpAddress.globalTitle.translationType);
		      if(l_TTValue == g_OtherConfigData->m_allowedTTs.end() )
		      {
			      CLOG(0,0,"TT value[%d] not found in Vector",l_sccpAddress.globalTitle.translationType);
                              setError(p_tcapMsg->dialog_id, DLG_INVALID_TT);
			      sendError(p_tcapMsg->dialog_id, MAP_ERROR_UNKNOWN);
			      return false;
		      }
		      DLOG(0,0,"TT value[%d] found in Vector", *l_TTValue);
	              }
              }
	      if(!(p_tcapMsg->tcu.dhp.comp_present_ind))
	      {
		      processTcapDlgMessage(p_tcapMsg, NULL, NULL);
	      }
	      else
	      {
		      memset(&g_TcapCompMsg, 0, sizeof(ctblock_t));
            if(cTCAPGetTblock (&g_TcapCompMsg) != RETURNerror)
            {
               printTcapBlock("===>>", &g_TcapCompMsg, 1);

               if (g_TcapCompMsg.tcu.chp.last_comp_ind)
               {
                  TLOG(0,1,"Processing with 1 component");
                  processTcapDlgMessage(p_tcapMsg, &g_TcapCompMsg, NULL);

                  memset(&g_TcapCompMsg, 0, sizeof(ctblock_t));
               }
               else
               {
                  if(cTCAPGetTblock (&g_TcapComp2Msg) != RETURNerror)
                  {
                     printTcapBlock("===>>", &g_TcapComp2Msg, 1);
                     TLOG(0,1,"Processing with 2 components");
                     processTcapDlgMessage(p_tcapMsg, &g_TcapCompMsg, &g_TcapComp2Msg);

                     memset(&g_TcapCompMsg, 0, sizeof(ctblock_t));
                     memset(&g_TcapComp2Msg, 0, sizeof(ctblock_t));
                  }
                  else
                  {
                     ELOG(0,1,"ERROR!! in cTCAPGetTblock 2\n");
                  }
               }
            }
            else
            {
               ELOG(0,1,"ERROR!! in cTCAPGetTblock");
            }
         }
         break;

      case TC_INVOKE:
      case TC_RESULT_L:
      case TC_RESULT_NL:
      case TC_U_ERROR:
      case TC_L_CANCEL:
      case TC_U_CANCEL:
      case TC_R_REJECT:
      case TC_L_REJECT:
      case TC_U_REJECT:
         DLOG(0,1,"Received component [%d] message", p_tcapMsg->prim_code);
         DLOG(0,1,"Calling processTcapDlgMessage ...");
         processTcapDlgMessage(p_tcapMsg, &g_TcapCompMsg, NULL);

         memset(&g_TcapCompMsg, 0, sizeof(ctblock_t));
         break;

      default:
         ELOG(0,1,"Received Unknown [%d] Message. Ignoring!!!", p_tcapMsg->prim_code);
         return false;
         break;
   }
   return true;
}


bool MplManager::prepareDlgPortion(int p_dialogueId, ctblock_t *p_tcapMsg, ctcap_dp_t *l_dp)
{
   DLOG(0,1,"prepareDlgPortion: DLGID: %d", p_dialogueId);
   DLOG(0,1,"prepareDlgPortion: flag: %d", (g_DlgContexts+p_dialogueId)->m_firstContinuePassed);


   if (DLG_TYPE_APPLICATION_INITIATED == (g_DlgContexts+ p_dialogueId)->m_DlgType)
   {
      TLOG(0,1,"prepareDlgPortion is not required for DLG_TYPE_APPLICATION_INITIATED");
      return false;
   }

   if( (MAP_V1 == (g_DlgContexts+p_dialogueId)->m_IncomingMapVersion) &&
         ( 0 == (g_DlgContexts+p_dialogueId)->m_dp_present_ind)
     )
   {
      TLOG(0,1,"prepareDlgPortion v1 message. Also Dlg Portion Not Present.");
      return false;
   }

   if (true == (g_DlgContexts+p_dialogueId)->m_firstContinuePassed)
   {
      DLOG(0,1,"prepareDlgPortion: Setting ind to zero");
      p_tcapMsg->tcu.dhp.dp_present_ind = 0;
   }
   else
   {
      (g_DlgContexts+p_dialogueId)->m_firstContinuePassed=true;
      memset(l_dp, '\0', sizeof(ctcap_dp_t));
      if ((g_DlgContexts+p_dialogueId)->m_dp_present_ind)
      {
         DLOG(0,1,"Preparing Dlg Portion");

         p_tcapMsg->tcu.dhp.dp_present_ind = 1;
         l_dp->application_context_name.length = (g_DlgContexts+p_dialogueId)->m_dp.application_context_name.length;
         for (int l_i=0; l_i< (int)(l_dp->application_context_name.length); l_i++)
         {
            l_dp->application_context_name.value[l_i] = (g_DlgContexts+p_dialogueId)->m_dp.application_context_name.value[l_i];
         }
      }
   }
   return true;
}


bool MplManager::sendError(int p_dialogueId, EMapErrorCode p_errorCode)
{
   ctblock_t l_error;
   memset (&l_error, 0, sizeof(l_error));

   if ((g_DlgContexts+p_dialogueId)->m_psm.m_InvokeId > -1)
   {
      if (MAP_ERROR_UNKNOWN != p_errorCode)
      {
         l_error.prim_code   = TC_U_ERROR;
         l_error.dialog_id   = p_dialogueId;
         l_error.appl_id     = (g_DlgContexts+ p_dialogueId)->m_appl_id;
         l_error.tcu.chp.class_of_oper = 0;
         l_error.tcu.chp.invoke_id = (g_DlgContexts+p_dialogueId)->m_psm.m_InvokeId;
         l_error.tcu.chp.linked_id = -1;
         l_error.tcu.chp.last_comp_ind = LAST_COMP;
         (g_DlgContexts+ p_dialogueId)->m_ErrorExchangedFlag = true;
         (g_DlgContexts+ p_dialogueId)->m_ErrorCodeExchanged = p_errorCode;

         l_error.data_len = 3;

         l_error.pdata = new unsigned char[3];
         l_error.pdata[0] = CP_EC_LOCAL; /* Error Code tag */
         l_error.pdata[1] = 1;
         l_error.pdata[2] = p_errorCode; /* Error Code */

         sendToTcapStack(&l_error);
      }
   }


   ctblock_t l_DlgBlock;
   memset (&l_DlgBlock, 0, sizeof(ctblock_t));
   ctcap_dp_t l_dp;
   memset (&l_dp, 0, sizeof(ctcap_dp_t));

   l_DlgBlock.prim_code = TC_END;
   l_DlgBlock.dialog_id = p_dialogueId;
   l_DlgBlock.appl_id = (g_DlgContexts+ p_dialogueId)->m_appl_id;

   // Added to see if the Response time, HLR GT is going or not
   L_SccpAddress l_origAddr;
   memset(&l_origAddr, '\0', sizeof(L_SccpAddress));
   l_origAddr = g_ConfigData->i_NgConfigData.m_selfAddress;
   encodeSccpAddress(l_DlgBlock.tcu.dhp.local_address, (SccpAddress*)(&l_origAddr));

   //End of Addition

   if (DLG_TYPE_NETWORK_INITIATED == (g_DlgContexts+ p_dialogueId)->m_DlgType)
   {
      memcpy(l_DlgBlock.tcu.dhp.remote_address, (g_DlgContexts+ p_dialogueId)->m_tmp_remote_address, MAX_ADDR_LEN);
   }

   prepareDlgPortion(p_dialogueId, &l_DlgBlock, &l_dp);
   l_DlgBlock.tcu.dhp.pdp = &l_dp;

   if (MAP_ERROR_UNKNOWN != p_errorCode)
   {
      l_DlgBlock.tcu.dhp.dialog_term_type = BASIC_TERMINATE;
   }
   else
   {
      l_DlgBlock.tcu.dhp.dialog_term_type = PRE_ARRANGED_TERMINATE;
      l_DlgBlock.tcu.dhp.dp_present_ind   = 0;//Stack is cribbing if this is set to 1
   }




   sendToTcapStack(&l_DlgBlock);
   if (DLG_TYPE_APPLICATION_INITIATED == (g_DlgContexts+p_dialogueId)->m_DlgType)
   {
      if (RETURNerror == cTCAPReleaseDialogId(p_dialogueId))
      {
         ELOG(0,1,"cTCAPReleaseDialogId Unable to release the dialog ID %d", p_dialogueId);
      }
      else
      {
         DLOG(0,1,"cTCAPReleaseDialogId Released the dialog ID %d", p_dialogueId);
      }
   }

   (g_DlgContexts+p_dialogueId)->m_ErrorExchangedFlag = true; 

   return true;
}


bool MplManager::sendAbort(int p_dialogueId, U8 p_AbortCause, U8 p_AbortReason, int p_supportedVersion=0)
{
   CLOG(0,1,"Sending ABORT...");

   ctblock_t l_DlgBlock;
   memset (&l_DlgBlock, 0, sizeof(ctblock_t));
   ctcap_dp_t l_dp;
   memset(&l_dp, '\0', sizeof(ctcap_dp_t));
   l_dp.abort_reason = 0;

   l_DlgBlock.prim_code = TC_U_ABORT;
   l_DlgBlock.dialog_id = p_dialogueId;
   l_DlgBlock.appl_id = applicationID;
   l_DlgBlock.tcu.dhp.abort_cause = p_AbortCause;


   prepareDlgPortion(p_dialogueId, &l_DlgBlock, &l_dp);

   if (DLG_TYPE_NETWORK_INITIATED == (g_DlgContexts+ p_dialogueId)->m_DlgType)
   {
      l_DlgBlock.tcu.dhp.dp_present_ind = (g_DlgContexts+p_dialogueId)->m_dp_present_ind;
   }
   else
   {
      if(MAP_V1 != (g_DlgContexts+p_dialogueId)->m_InitiatingMapVersion)
      {
         l_DlgBlock.tcu.dhp.dp_present_ind=1;
      }
   }
   TLOG(0,1,"sendabort after prepareDlgPortion %d", l_DlgBlock.tcu.dhp.dp_present_ind);

   l_dp.abort_reason = p_AbortReason;

   if(l_dp.application_context_name.length != 0)
   {
      if(MAP_V1 != (g_DlgContexts+p_dialogueId)->m_IncomingMapVersion)
      {
         if (p_supportedVersion>0)
         {
            DLOG(0,0,"Supported version is %d", p_supportedVersion);
            l_dp.application_context_name.value[l_dp.application_context_name.length-1] = p_supportedVersion;
         }
         else
         {
            DLOG(0,0,"Supported version is 0");
         }
      }
      else
      {
         DLOG(0,0,"Version is MAP_V1");
      }
   }
   else
   {
      DLOG(0,0,"application_context_name length is 0");
   }

   l_DlgBlock.tcu.dhp.pdp = &l_dp;

   // Added to see if the Response time, HLR GT is going or not
   L_SccpAddress l_origAddr;
   memset(&l_origAddr, '\0', sizeof(L_SccpAddress));
   if( 2 == (g_DlgContexts+p_dialogueId)->m_CustomizedSelfAddress.addressIndicator.routingIndicator)
   {
      (g_DlgContexts+p_dialogueId)->m_CustomizedSelfAddress=getSelfAddress((g_DlgContexts+ p_dialogueId)->m_tmp_local_address);
   }
   l_origAddr = (g_DlgContexts+p_dialogueId)->m_CustomizedSelfAddress;
   encodeSccpAddress(l_DlgBlock.tcu.dhp.local_address, (SccpAddress*)(&l_origAddr));

   memcpy(l_DlgBlock.tcu.dhp.remote_address, (g_DlgContexts+p_dialogueId)->m_tmp_remote_address, MAX_ADDR_LEN);
   //End of Addition

   sendToTcapStack(&l_DlgBlock);

   return true;
}

bool MplManager::simpleSendAbort(int p_dialogueId, U8 p_AbortCause, U8 p_AbortReason, int p_supportedVersion=0)
{
   CLOG(0,1,"Sending SIMPLE ABORT... with suppversion: %d", p_supportedVersion);
   ctblock_t l_DlgBlock;
   memset (&l_DlgBlock, 0, sizeof(ctblock_t));
   ctcap_dp_t l_dp;
   memset(&l_dp, '\0', sizeof(ctcap_dp_t));
   l_dp.abort_reason = 0;

   l_DlgBlock.prim_code = TC_U_ABORT;
   l_DlgBlock.appl_id = applicationID;
   l_DlgBlock.tcu.dhp.abort_cause = p_AbortCause;


   //prepareDlgPortion(p_dialogueId, &l_DlgBlock, &l_dp);

   l_DlgBlock.tcu.dhp.dp_present_ind = 1;
   l_DlgBlock.tcu.dhp.pdp = &l_dp;
   l_dp.application_context_name.length = 8;
   l_dp.application_context_name.value[0] = 0x00;
   l_dp.application_context_name.value[1] = 0x04;
   l_dp.application_context_name.value[2] = 0x00;
   l_dp.application_context_name.value[3] = 0x00;
   l_dp.application_context_name.value[4] = 0x01;
   l_dp.application_context_name.value[5] = 0x00;
   l_dp.application_context_name.value[6] = 0x00;
   l_dp.application_context_name.value[7] = 0x00;


   l_dp.abort_reason = p_AbortReason;

   // Added to see if the Response time, HLR GT is going or not
   L_SccpAddress l_origAddr;
   memset(&l_origAddr, '\0', sizeof(L_SccpAddress));
   if( 2 == (g_DlgContexts+p_dialogueId)->m_CustomizedSelfAddress.addressIndicator.routingIndicator)
   {
      (g_DlgContexts+p_dialogueId)->m_CustomizedSelfAddress=getSelfAddress((g_DlgContexts+ p_dialogueId)->m_tmp_local_address);
   }
   l_origAddr = (g_DlgContexts+p_dialogueId)->m_CustomizedSelfAddress;
   encodeSccpAddress(l_DlgBlock.tcu.dhp.local_address, (SccpAddress*)(&l_origAddr));
   //End of Addition

   sendToTcapStack(&l_DlgBlock);

   return true;
}

bool MplManager::logOtherErrorCodeStats(int p_dialog, int p_errorCode)
{
   DLOG(0,0,"MplManager::logOtherErrorCodeStats called with Dialog:%d, ErrorCode:%d", p_dialog, p_errorCode);
   if (DLG_TYPE_NETWORK_INITIATED == (g_DlgContexts+p_dialog)->m_DlgType)
   {
      StatisticsInterface::logOpCodeOtherErrorCount((g_DlgContexts+p_dialog)->m_IncomingOpCode, p_errorCode);
   }
   else
   {
      StatisticsInterface::logOpCodeOtherErrorCount((g_DlgContexts+p_dialog)->m_InitiatingOpCode, p_errorCode);
   }
   return true;
}


bool MplManager::logSuccessDialogue(int p_dialog)
{
   if (false == (g_DlgContexts+p_dialog)->m_ErrorExchangedFlag)
   {
      if (DLG_TYPE_NETWORK_INITIATED == (g_DlgContexts+p_dialog)->m_DlgType)
      {
         StatisticsInterface::logRespondingApplCtxtSuccess(
               (g_DlgContexts+p_dialog)->m_IncomingApplCntxt, 
               (g_DlgContexts+p_dialog)->m_IncomingMapVersion);

         StatisticsInterface::logRespondingOpCodeSuccess(
               (g_DlgContexts+p_dialog)->m_IncomingOpCode, 
               (g_DlgContexts+p_dialog)->m_IncomingMapVersion);
      }
      else
      {
         DLOG(0,0,"Application initiating, going to write I-Success stats");
         StatisticsInterface::logInitiatingApplCtxtSuccess(
               (g_DlgContexts+p_dialog)->m_InitiatingApplCntxt, 
               (g_DlgContexts+p_dialog)->m_InitiatingMapVersion);

         StatisticsInterface::logInitiatingOpCodeSuccess(
               (g_DlgContexts+p_dialog)->m_InitiatingOpCode, 
               (g_DlgContexts+p_dialog)->m_InitiatingMapVersion);
      }
      list<reportData> :: iterator l_it;
      for(l_it = g_OtherConfigData->m_reportDataList.begin(); l_it!=g_OtherConfigData->m_reportDataList.end(); l_it++)
      {
         char l_opcodeChar[4 + 1],l_opcodeChar1[4 + 1];;
         memset(l_opcodeChar, '\0', sizeof(l_opcodeChar));
         memset(l_opcodeChar1, '\0', sizeof(l_opcodeChar1));
         snprintf(l_opcodeChar, sizeof(l_opcodeChar)+1, ",%02d,", (g_DlgContexts+p_dialog)->m_IncomingOpCode);
         snprintf(l_opcodeChar1, sizeof(l_opcodeChar1)+1, ",%02d,", (g_DlgContexts+p_dialog)->m_InitiatingOpCode);
         size_t l_found = l_it->m_opCodes.find(l_opcodeChar);
         size_t l_found1 = l_it->m_opCodes.find(l_opcodeChar1);
         if(l_found != string::npos)
         {
            DLOG(0,0,"while Responding Success opcode matched");
            if(DLG_TYPE_NETWORK_INITIATED == (g_DlgContexts+p_dialog)->m_DlgType)
            {
               DLOG(0,0,"Called GT is %s and GT from Config file is %s",g_DlgContexts->m_remoteGT, l_it->m_GTs.c_str());
               string l_remoteGT(g_DlgContexts->m_remoteGT);
               DLOG(0,0,"l_remoteGT is %s",l_remoteGT.c_str());
               if(l_remoteGT.rfind(l_it->m_GTs.c_str(),0) ==0)
                  //size_t l_pos = l_remoteGT.find(l_it->m_GTs.c_str());
                  //if(l_pos != string::npos)
               {
                  DLOG(0,0,"In Responding Suc GT matched, index while calling logstatistics is %d",l_it->m_RespondingOpCodesIndices[(g_DlgContexts+p_dialog)->m_IncomingOpCode].m_SuccessCountGTMat[(g_DlgContexts+p_dialog)->m_IncomingMapVersion - 1]);
                  HLRStatisticsInitializer::logStatistics(l_it->m_RespondingOpCodesIndices[(g_DlgContexts+p_dialog)->m_IncomingOpCode].m_SuccessCountGTMat[(g_DlgContexts+p_dialog)->m_IncomingMapVersion - 1]);
               }
               else
               {
                  DLOG(0,0,"In Responding Suc GT Not matched, index while calling logstatistics is %d",l_it->m_RespondingOpCodesIndices[(g_DlgContexts+p_dialog)->m_IncomingOpCode].m_SuccessCountGTNotMat[(g_DlgContexts+p_dialog)->m_IncomingMapVersion - 1]);
                  HLRStatisticsInitializer::logStatistics(l_it->m_RespondingOpCodesIndices[(g_DlgContexts+p_dialog)->m_IncomingOpCode].m_SuccessCountGTNotMat[(g_DlgContexts+p_dialog)->m_IncomingMapVersion - 1]);

               }
            }
         }
         else
         {
            DLOG(0,0,"while Responding Success opcode not matched");
         }
         if(l_found1 != string::npos)
         {
            DLOG(0,0,"while Initiating Success opcode matched");
            if(DLG_TYPE_APPLICATION_INITIATED == (g_DlgContexts+p_dialog)->m_DlgType)
               //else
            {
               DLOG(0,0,"Application initiating, going to write I-Success stats for new stats");
               string l_remoteGT((g_DlgContexts+p_dialog)->m_DestAddr.globalTitle.addressInformation);
               if(l_remoteGT.rfind(l_it->m_GTs.c_str(), 0) == 0)
                  //size_t l_pos = l_remoteGT.find(l_it->m_GTs.c_str());
                  //if(l_pos != string::npos)
               {
                  DLOG(0,0,"in Initiating Suc, GT matched, index while calling logstatistics is %d",l_it->m_InitiatingOpCodesIndices[(g_DlgContexts+p_dialog)->m_InitiatingOpCode].m_SuccessCountGTMat[(g_DlgContexts+p_dialog)->m_InitiatingMapVersion - 1]);
                  HLRStatisticsInitializer::logStatistics(l_it->m_InitiatingOpCodesIndices[(g_DlgContexts+p_dialog)->m_InitiatingOpCode].m_SuccessCountGTMat[(g_DlgContexts+p_dialog)->m_InitiatingMapVersion - 1]);
               }
               else
               {
                  DLOG(0,0,"In Initiating Suc, GT Not matched, index while calling logstatistics is %d",l_it->m_InitiatingOpCodesIndices[(g_DlgContexts+p_dialog)->m_InitiatingOpCode].m_SuccessCountGTNotMat[(g_DlgContexts+p_dialog)->m_InitiatingMapVersion - 1]);
                  HLRStatisticsInitializer::logStatistics(l_it->m_InitiatingOpCodesIndices[(g_DlgContexts+p_dialog)->m_InitiatingOpCode].m_SuccessCountGTNotMat[(g_DlgContexts+p_dialog)->m_InitiatingMapVersion - 1]);
               }
            }
         }
         else
         {
            DLOG(0,0,"while Initiating Success opcode not matched");
         }
      }
   } 
   else
   {
      DLOG(0,1,"Not Logging the Statistics SuccessCount since ErrorExchangedFlag is set to true");
      if(DLG_TYPE_NETWORK_INITIATED == (g_DlgContexts+p_dialog)->m_DlgType)
      {
         StatisticsInterface::logOpCodeErrorCount(
               (g_DlgContexts+p_dialog)->m_IncomingOpCode, 
               (g_DlgContexts+p_dialog)->m_ErrorCodeExchanged);
      }
      else
      {
         StatisticsInterface::logOpCodeErrorCount(
               (g_DlgContexts+p_dialog)->m_InitiatingOpCode, 
               (g_DlgContexts+p_dialog)->m_ErrorCodeExchanged);
      }
   }
   return true;
}



void congestionControlActions() // Called every second by NetworkInterface sendRecvMessages()
{

   HLRStatisticsInitializer::instance()->logStatistics(g_maxTpsDataIndex,g_CurrentActiveTransactions);
   if(1 == g_OtherConfigData->m_PrintTimerInLog)
   {
      LLOG(0,1,"cca: CurrentActiveTransactions: %d", g_CurrentActiveTransactions);
   }

   string l_service;
   if(g_OtherConfigData->m_TCAPStackFlag == 1)
   {
      l_service = "SS7";
      g_daf->logMaxTPSValue(l_service, g_CurrentActiveTransactions);
   }
   else if(g_OtherConfigData->m_dcd.m_diameterNgRequired == 1)
   {
      l_service = "DIAMETER";
      g_daf->logMaxTPSValue(l_service, g_CurrentActiveTransactions);
   }
   else if(g_OtherConfigData->m_SCCPStackFlag == 1)
   {
      l_service = "SCCP";
      g_daf->logMaxTPSValue(l_service, g_CurrentActiveTransactions);
   }
   else
   {
      //
   }

   if ('N' != g_cc.m_controlType[0])
   {
      //if (g_cc.m_priorityHandling)
      //{
      //if(1 == g_OtherConfigData->m_PrintTimerInLog)               
      //{
      //TLOG(0,1,"%03d  Flags: ", g_CurrentActiveTransactions, g_cc.m_priorityFlags[0],g_cc.m_priorityFlags[1],g_cc.m_priorityFlags[2],g_cc.m_priorityFlags[3]);
      //}
      //}
      time_t l_currentTime = time(NULL);
      if (l_currentTime >= g_lastCongestionTrapSentTime+g_cc.m_trapInterval)
      {
         g_lastCongestionTrapSentTime=l_currentTime;
         LLOG(0,1,"LastDbCongestionTrapType:%d, CurrentWindowDbCongestionStatus:%d, LastTransPerSecTrapType:%d, CurrentWindowTransPerSecStatus:%d",
               g_lastDbCongestionTrapType, g_currentWindowDbCongestionStatus, g_lastTransPerSecTrapType, g_currentWindowTransPerSecStatus);

         //Check DB Congestion Traps
         if (g_lastDbCongestionTrapType != g_currentWindowDbCongestionStatus)
         {
            g_lastDbCongestionTrapType=g_currentWindowDbCongestionStatus;
            if (false == g_currentWindowDbCongestionStatus)
            {
               g_si.sendSnmpTrap(g_DbCongestion, TRAP_TYPE_PASS, TRAP_SEVERITY_MINOR);
            }
            else
            {
               g_si.sendSnmpTrap(g_DbCongestion, TRAP_TYPE_FAIL, TRAP_SEVERITY_CRITICAL);
            }
         }
         else if ( (true == g_lastDbCongestionTrapType) && (true == g_currentWindowDbCongestionStatus))
         {
            g_si.sendSnmpTrap(g_DbCongestion, TRAP_TYPE_FAIL, TRAP_SEVERITY_CRITICAL);
         }
         g_currentWindowDbCongestionStatus=false;

         //Check Trans Per Sec Traps
         if (g_lastTransPerSecTrapType != g_currentWindowTransPerSecStatus)
         {
            g_lastTransPerSecTrapType=g_currentWindowTransPerSecStatus;
            if (false == g_currentWindowTransPerSecStatus)
            {
               g_si.sendSnmpTrap(g_TransPerSecTrap, TRAP_TYPE_PASS, TRAP_SEVERITY_MINOR);
            }
            else
            {
               g_si.sendSnmpTrap(g_TransPerSecTrap, TRAP_TYPE_FAIL, TRAP_SEVERITY_CRITICAL);
            }
         }
         else if ( (true == g_lastTransPerSecTrapType) && (true == g_currentWindowTransPerSecStatus))
         {
            g_si.sendSnmpTrap(g_TransPerSecTrap, TRAP_TYPE_FAIL, TRAP_SEVERITY_CRITICAL);
         }
         g_currentWindowTransPerSecStatus=false;
      }
   }
   g_CurrentActiveTransactions=0;
}


bool MplManager::overload(EMsgType p_msgType, int p_dialogid, int p_applCtxt)
{
   TLOG(0,1,"overload called MsgType: %d, CurrentActive: %d, MaxActive: %d, ApplCtxt: %d", 
         p_msgType, g_CurrentActiveTransactions, g_cc.m_maxIncomingTransactionsPerSec, p_applCtxt);

   EDialogueAcceptanceType l_dat=DLG_ACCEPT;

   if ('N' == g_cc.m_controlType[0])  // No Congestion control
   {
      DLOG(0,1,"Accepting the dialogue since no congestion control is configured");
      l_dat=DLG_ACCEPT;
   }
   else  // Congestion control is set
   {
      //if ( (('T' == g_cc.m_controlType[0]) || ('B' == g_cc.m_controlType[0])) && (MSG_TYPE_MAP == p_msgType) )  //Transactions based or both
      if (('T' == g_cc.m_controlType[0]) || ('B' == g_cc.m_controlType[0]))  //Transactions based or both
      {
         TLOG(0,1,"p_msgType is %d, MSG_TYPE_DIAMETER is %d", p_msgType, MSG_TYPE_DIAMETER);
         if ((0 == g_cc.m_priorityHandling) || (MSG_TYPE_DIAMETER == p_msgType) || (MSG_TYPE_SCCP == p_msgType))
         {
            DLOG(0,1,"Priorities not present");

            //FRR-3727 start, related to DAF
            TrafficParams l_traf_in,l_traf_out;
            l_traf_in.m_maxTPS = g_cc.m_maxIncomingTransactionsPerSec;
            string l_service;
            DLOG(0,0,"Before calling getTrafficParameters in no priority case");
            if(MSG_TYPE_MAP == p_msgType)
            {
               l_service = "SS7";
               if(false == g_daf->getTrafficParameters(l_service, l_traf_in, l_traf_out))
               {
                  DLOG(0,0,"getTrafficParameters returns false, making g_tp_out as NG MAX TPS ");
                  l_traf_out.m_maxTPS = g_cc.m_maxIncomingTransactionsPerSec;
               }
               else
               {
                  DLOG(0,0,"getTrafficParameters returns true for SS7, DAF TPS is %d",l_traf_out.m_maxTPS);
               }
            }
            else if(MSG_TYPE_DIAMETER == p_msgType)
            {
               l_service = "DIAMETER";
               if(false == g_daf->getTrafficParameters(l_service, l_traf_in, l_traf_out))
               {
                  DLOG(0,0,"getTrafficParameters returns false, making g_tp_out as NG MAX TPS ");
                  l_traf_out.m_maxTPS = g_cc.m_maxIncomingTransactionsPerSec;
               }
               else
               {
                  DLOG(0,0,"getTrafficParameters returns true for DIAM, DAF TPS is %d",l_traf_out.m_maxTPS);
               }
            }
            else if(MSG_TYPE_SCCP == p_msgType)
            {
               l_service = "SCCP";
               if(false == g_daf->getTrafficParameters(l_service, l_traf_in, l_traf_out))
               {
                  DLOG(0,0,"getTrafficParameters returns false, making g_tp_out as NG MAX TPS ");
                  l_traf_out.m_maxTPS = g_cc.m_maxIncomingTransactionsPerSec;
               }
               else
               {
                  DLOG(0,0,"getTrafficParameters returns true for SCCP, DAF TPS is %d",l_traf_out.m_maxTPS);
               }
            }
            else
            {
               DLOG(0,0,"Message type is not MAP, not SCCP and not DIAM, not getting TPS from DAF");
            }
            //FRR-3727 end, related to DAF
            //            if(g_CurrentActiveTransactions > g_cc.m_maxIncomingTransactionsPerSec)
            if(g_CurrentActiveTransactions > l_traf_out.m_maxTPS)
            {
               l_dat = DLG_REJECT_PEAK_LOAD_PER_SEC;
               g_currentWindowTransPerSecStatus=true;
               LLOG(0,1,"Rejecting the transaction %d", l_dat);
            }
            else
            {
               DLOG(0,1,"Accepting the transaction");
               l_dat = DLG_ACCEPT;
            }
         }
         else
         {
            int l_currentApplPriority= g_ApplContextPriority[p_applCtxt];

            if (0 == l_currentApplPriority)
            {
               WLOG(0,1,"Unable to deduce application priority");
               l_dat = DLG_UNABLE_TO_DEDUCE_APPL_PRIORITY;
            }
            else
            {
               if (l_currentApplPriority > g_cc.m_priorityHandling+1)
               {
                  l_currentApplPriority = g_cc.m_priorityHandling+1;
                  DLOG(0,1,"Setting the application priority to the maximum one applicable %d", l_currentApplPriority);
               }
               else
               {
                  DLOG(0,1,"Appl Ctxt priority %d", l_currentApplPriority);
               }

               TLOG(0,1,"Current Active %d, Max allowed for this priority: %d", 
                     g_CurrentActiveTransactions, g_cc.m_priorityIncomingTransactionsPerSec[l_currentApplPriority-1]);

               //FRR-3727 start, related to DAF
               TrafficParams l_traf_in,l_traf_out;
               l_traf_in.m_maxTPS = g_cc.m_maxIncomingTransactionsPerSec;
               string l_service("SS7");
               DLOG(0,0,"Before calling getTrafficParameters in priotity case");
               if(false == g_daf->getTrafficParameters(l_service, l_traf_in, l_traf_out))
               {
                  DLOG(0,0,"getTrafficParameters returns false, making g_tp_out as NG MAX TPS ");
                  l_traf_out.m_maxTPS = g_cc.m_maxIncomingTransactionsPerSec;
               }
               else
               {
                  DLOG(0,0,"getTrafficParameters returns true DAF TPS is %d",l_traf_out.m_maxTPS);
               }
               //FRR-3727 end, related to DAF
               //               if (g_CurrentActiveTransactions > g_cc.m_priorityIncomingTransactionsPerSec[l_currentApplPriority-1] )
               if (g_CurrentActiveTransactions > l_traf_out.m_maxTPS )
               {
                  l_dat = (EDialogueAcceptanceType)((int)DLG_REJECT_PEAK_LOAD_PER_SEC+l_currentApplPriority);
                  g_cc.m_priorityFlags[l_currentApplPriority]=1;
                  g_currentWindowTransPerSecStatus=true;
               }
               else
               {
                  TLOG(0,1,"Accepting the transaction");
                  l_dat = DLG_ACCEPT;
               }
            }
         }
      }

      if(DLG_ACCEPT != l_dat)
      {
         if(MSG_TYPE_DIAMETER == p_msgType)
         {
            HLRStatisticsInitializer::instance()->logStatistics(g_incomingDiameterTransRejIndex);
         }
         else if(MSG_TYPE_MAP == p_msgType)
         {
            HLRStatisticsInitializer::instance()->logStatistics(g_incomingMapTransRejIndex);
         }
         else if(MSG_TYPE_SCCP == p_msgType)
         {
            HLRStatisticsInitializer::instance()->logStatistics(g_incomingSccpTransRejIndex);
         }
      }
      else if (DLG_ACCEPT == l_dat)  //Check if the other congestion control works
      {
         if ( ('D' == g_cc.m_controlType[0]) || ('B' == g_cc.m_controlType[0]) )  //Active dialogues or both
         {
            if ((0 == g_cc.m_priorityHandling)  || (MSG_TYPE_DIAMETER == p_msgType) || (MSG_TYPE_SCCP == p_msgType))
            {
               DLOG(0,1,"Priorities not present");
               if(g_act.getRequestQueueSize() > g_cc.m_maxActiveIncomingDialogues)
               {
                  LLOG(0,1,"Rejecting the Initial transaction: No Priority");
                  l_dat = DLG_REJECT_PEAK_LOAD_MAX_DLGS;
                  if(false == g_DbCongestionStatus)
                  {
                     //g_si.sendSnmpTrap(g_DbCongestion, TRAP_TYPE_FAIL, TRAP_SEVERITY_CRITICAL);
                     g_DbCongestionStatus=true;
                     g_currentWindowDbCongestionStatus=true;
                  }
               }
               else if(g_act.getLaterRequestQueueSize() > g_cc.m_maxActiveLaterQueueSize)
               {
                  LLOG(0,1,"Rejecting the Later transaction: No Priority");
                  l_dat = DLG_REJECT_LATER_PEAK_LOAD_MAX_DLGS;
                  if(false == g_DbCongestionStatus)
                  {
                     //g_si.sendSnmpTrap(g_DbCongestion, TRAP_TYPE_FAIL, TRAP_SEVERITY_CRITICAL);
                     g_DbCongestionStatus=true;
                     g_currentWindowDbCongestionStatus=true;
                  }
               }
               else
               {
                  DLOG(0,1,"Accepting the transaction");
                  l_dat = DLG_ACCEPT;
                  if(true == g_DbCongestionStatus)
                  {
                     //g_si.sendSnmpTrap(g_DbCongestion, TRAP_TYPE_PASS, TRAP_SEVERITY_CRITICAL);
                     g_DbCongestionStatus=false;
                  }
               }
            }
            else
            {
               int l_currentApplPriority= g_ApplContextPriority[p_applCtxt];

               if (0 == l_currentApplPriority)
               {
                  WLOG(0,1,"Unable to deduce application priority");
                  l_dat = DLG_UNABLE_TO_DEDUCE_APPL_PRIORITY;
               }
               else
               {
                  if (l_currentApplPriority > g_cc.m_priorityHandling+1)
                  {
                     DLOG(0,1,"Setting the application priority to the maximum one applicable");
                     l_currentApplPriority = g_cc.m_priorityHandling+1;
                  }
                  TLOG(0,1,"Current DB Queue Size: %d, Max allowed for this priority: %d. ", 
                        g_act.getRequestQueueSize(), g_cc.m_priorityMaxActiveIncomingDialogues[l_currentApplPriority-1]);

                  if (g_act.getRequestQueueSize() > g_cc.m_priorityMaxActiveIncomingDialogues[l_currentApplPriority-1] )
                  {
                     LLOG(0,1,"Rejecting the Initial transaction: Priority");
                     l_dat = (EDialogueAcceptanceType)((int)DLG_REJECT_PEAK_LOAD_MAX_DLGS+l_currentApplPriority);
                     g_cc.m_priorityFlags[l_currentApplPriority]=1;
                     if(false == g_DbCongestionStatus)
                     {
                        //g_si.sendSnmpTrap(g_DbCongestion, TRAP_TYPE_FAIL, TRAP_SEVERITY_CRITICAL);
                        g_DbCongestionStatus=true;
                        g_currentWindowDbCongestionStatus=true;
                     }
                  }
                  else if(g_act.getLaterRequestQueueSize() > g_cc.m_maxActiveLaterQueueSize)
                  {
                     LLOG(0,1,"Rejecting the Later transaction: Priority");
                     DLOG(0,0,"g_act.getLaterRequestQueueSize()[%d] .. g_cc.m_maxActiveLaterQueueSize[%d]",g_act.getLaterRequestQueueSize(),g_cc.m_maxActiveLaterQueueSize);
                     l_dat = (EDialogueAcceptanceType)((int)DLG_REJECT_LATER_PEAK_LOAD_MAX_DLGS+1);
                     if(false == g_DbCongestionStatus)
                     {
                        //g_si.sendSnmpTrap(g_DbCongestion, TRAP_TYPE_FAIL, TRAP_SEVERITY_CRITICAL);
                        g_DbCongestionStatus=true;
                        g_currentWindowDbCongestionStatus=true;
                     }
                  }
                  else
                  {
                     TLOG(0,1,"Accepting the transaction");
                     l_dat = DLG_ACCEPT;
                     if(true == g_DbCongestionStatus)
                     {
                        if(g_act.getRequestQueueSize() < g_cc.m_priorityMaxActiveIncomingDialogues[g_cc.m_priorityHandling]) //Send good trap 
                        {
                           //g_si.sendSnmpTrap(g_DbCongestion, TRAP_TYPE_PASS, TRAP_SEVERITY_CRITICAL);
                           g_DbCongestionStatus=false;
                        }
                     }
                  }
               }
            }
         }
         if(DLG_ACCEPT != l_dat)
         {
            if(MSG_TYPE_DIAMETER == p_msgType)
            {
               HLRStatisticsInitializer::instance()->logStatistics(g_incomingDiameterDbRejIndex);
            }
            else if(MSG_TYPE_MAP == p_msgType)
            {
               HLRStatisticsInitializer::instance()->logStatistics(g_incomingMapDbRejIndex);
            }
            else if(MSG_TYPE_SCCP == p_msgType)
            {
               HLRStatisticsInitializer::instance()->logStatistics(g_incomingSccpDbRejIndex);
            }
         }
      }
   }

   if (DLG_ACCEPT != l_dat)
   {
      //if ( (('T' == g_cc.m_controlType[0]) || ('B' == g_cc.m_controlType[0])) && (MSG_TYPE_MAP == p_msgType) )  //Transactions based or both
      if (('T' == g_cc.m_controlType[0]) || ('B' == g_cc.m_controlType[0]))  //HLR 2.0.24.0 commented above
      {
         g_CurrentActiveTransactions--;
      }

      if(MSG_TYPE_MAP == p_msgType)
      {
         setError(p_dialogid, l_dat);    //TDR_INDEX_ERR_CODE index
         DLOG(0,1,"MSG_TYPE_MAP rejecting...");
         if ('A' == g_cc.m_overloadTransactionsRejectType[0])
         {
            sendAbort(p_dialogid, DP_RESOURCE_LIMIT, ABRT_NOT_PRESENT);
         }
         else if ('I' == g_cc.m_overloadTransactionsRejectType[0])
         {
            sendError(p_dialogid, MAP_ERROR_UNKNOWN);
         }
         else
         {
            sendError(p_dialogid, MAP_ERROR_systemFailure);
         }
      }
      else if(MSG_TYPE_DIAMETER == p_msgType)
      {
         DLOG(0,1,"MSG_TYPE_DIAMETER rejecting...");
      }
      else if(MSG_TYPE_SCCP == p_msgType)
      {
         DLOG(0,1,"MSG_TYPE_SCCP rejecting...");
      }
      WLOG(0,0,"Rejecting the transaction reject reason %d", l_dat);
      return true;
   }
   else
   {
      TLOG(0,1,"Accepting the transaction");
      return false;
   }
}

void setApplCtxt(int p_dialog_id, int p_applCtxt)
{
   char l_applCtxtChar[10];
   memset(l_applCtxtChar, '\0', sizeof(l_applCtxtChar));
   sprintf(l_applCtxtChar, "ac%d", p_applCtxt);

   (g_DlgContexts+p_dialog_id)->m_tdr->m_HDR[TDR_HDR_OP_CODE_INDEX] = l_applCtxtChar;
}


bool MplManager::processTcapDlgMessage(ctblock_t *p_tcapMsg, ctblock_t *p_tcapCompMsg, ctblock_t *p_tcapCompMsg2=NULL)
{
   //DLOG(0,1,"MplManager::processTcapDlgMessage [%d]", p_tcapMsg->prim_code);

   if( (p_tcapMsg->dialog_id < 1) || (p_tcapMsg->dialog_id > g_ConfigData->i_NgConfigData.m_MaxDialogs) )
   {
      ELOG(0,1,"ERROR!!! Invalid PRIM Dialog Id received %d", p_tcapMsg->dialog_id);
      return false;
   }

   if ( (p_tcapMsg != NULL) && (p_tcapMsg->prim_code != 0))
   {
      switch (p_tcapMsg->prim_code)
      {
         case TC_UNI:
            DLOG(0,1,"Received a TCAP Dialogue Primitive TC_UNI message");
            break;

         case TC_BEGIN:
            g_CurrentActiveTransactions++;

            HLRStatisticsInitializer::instance()->logStatistics(g_incomingMapReqIndex);
            LLOG(0,1,"Received TC_BEGIN with dlg:%d", p_tcapMsg->dialog_id);
            if (p_tcapMsg->dialog_id > g_ConfigData->i_NgConfigData.m_MaxDialogs)
            {
               WLOG(0,1,"Received dialog id [%d] greater than MAX %d", p_tcapMsg->dialog_id, g_ConfigData->i_NgConfigData.m_MaxDialogs);
               simpleSendAbort(p_tcapMsg->dialog_id, DP_UNREC_MESSAGE, ABRT_NOT_PRESENT);
               return false;
            }

            (g_DlgContexts+p_tcapMsg->dialog_id)->reset();
            (g_DlgContexts+p_tcapMsg->dialog_id)->m_DlgType   = DLG_TYPE_NETWORK_INITIATED;
            (g_DlgContexts+p_tcapMsg->dialog_id)->m_CustomizedSelfAddress.addressIndicator.routingIndicator=2;
            (g_DlgContexts+p_tcapMsg->dialog_id)->m_IncomingSccpClass = p_tcapMsg->tcu.dhp.qlty_of_svc; //Store QOS

            memcpy((g_DlgContexts+p_tcapMsg->dialog_id)->m_tmp_remote_address, p_tcapMsg->tcu.dhp.remote_address, MAX_ADDR_LEN);
            memcpy((g_DlgContexts+p_tcapMsg->dialog_id)->m_tmp_local_address, p_tcapMsg->tcu.dhp.local_address, MAX_ADDR_LEN);

            if (NULL != p_tcapCompMsg)
            {
               (g_DlgContexts+p_tcapMsg->dialog_id)->m_psm.m_InvokeId = p_tcapCompMsg->tcu.chp.invoke_id;
            }


            (g_DlgContexts+p_tcapMsg->dialog_id)->m_dp_present_ind = p_tcapMsg->tcu.dhp.dp_present_ind;
            if (p_tcapMsg->tcu.dhp.dp_present_ind)
            {
               memcpy(&((g_DlgContexts+p_tcapMsg->dialog_id)->m_dp), p_tcapMsg->tcu.dhp.pdp, sizeof(ctcap_dp_t));

               if (2 <= p_tcapMsg->tcu.dhp.pdp->application_context_name.length)
               {
                  DLOG(0,1,"App Context Length [%d] UserInfo Length [%d]", 
                        p_tcapMsg->tcu.dhp.pdp->application_context_name.length,
                        p_tcapMsg->tcu.dhp.pdp->user_information_length);


                  int l_mapVersion = p_tcapMsg->tcu.dhp.pdp->application_context_name.value[p_tcapMsg->tcu.dhp.pdp->application_context_name.length-1];
                  if ((l_mapVersion == 1) || (l_mapVersion == 2) || (l_mapVersion == 3))
                  {
                     (g_DlgContexts+p_tcapMsg->dialog_id)->m_IncomingMapVersion = (EMapVersion)(l_mapVersion);
                  }
                  else
                  {
                     ELOG(0,0,"ERROR!! Unknown MAP Version [%d]", l_mapVersion);
                     (g_DlgContexts+p_tcapMsg->dialog_id)->m_tdr->setMapVersion(l_mapVersion);
                     setError(p_tcapMsg->dialog_id, DLG_UNKNOWN_APPL_VERSION);
                     sendAbort(p_tcapMsg->dialog_id, DP_UNREC_MESSAGE, ABRT_NOT_PRESENT);
                     return false;
                  }

                  (g_DlgContexts+p_tcapMsg->dialog_id)->m_tdr->setMapVersion(l_mapVersion);

                  int l_applCtxt = p_tcapMsg->tcu.dhp.pdp->application_context_name.value[p_tcapMsg->tcu.dhp.pdp->application_context_name.length-2];

                  StatisticsInterface::logRespondingApplCtxtTotal(l_applCtxt, l_mapVersion);
                  //StatisticsManager::instance()->print();

                  setApplCtxt(p_tcapMsg->dialog_id, l_applCtxt);

                  if(g_ConfigData->i_NgConfigData.m_ApplSupportedMap[l_applCtxt])
                  {
                     if (l_mapVersion <= g_ConfigData->i_NgConfigData.m_ApplSupportedMaxVersion[l_applCtxt])
                     {
                        (g_DlgContexts+p_tcapMsg->dialog_id)->m_IncomingApplCntxt  = (EMapApplicationContext)l_applCtxt;

                        (g_DlgContexts+p_tcapMsg->dialog_id)->m_appl_id = p_tcapMsg->appl_id;

                        if (true == overload(MSG_TYPE_MAP, p_tcapMsg->dialog_id, l_applCtxt))
                        {
                           return false;
                        }

                        SignalMapOpenInd(p_tcapMsg->dialog_id, NULL, (EMapApplicationContext)l_applCtxt, 
                              (U8*)(&(p_tcapMsg->tcu.dhp.remote_address)), (U8*)(&(p_tcapMsg->tcu.dhp.local_address)));
                        processTcapComponents(p_tcapCompMsg);
                        DLOG(0,1,"Calling SignalMapDelInd");
                        SignalMapDelInd(p_tcapMsg->dialog_id);

                        (g_DlgContexts+p_tcapMsg->dialog_id)->m_DlgState = DLG_STATE_DIALOGUE_PENDING;
                     }
                     else
                     {
                        if (l_mapVersion < g_ConfigData->i_NgConfigData.m_ApplSupportedMinVersion[l_applCtxt])
                        {
                           printf("\nCRITICAL!! Received Version [%d] is less than Min Supported Appl Context version [%d]",
                                 l_mapVersion,
                                 g_ConfigData->i_NgConfigData.m_ApplSupportedMinVersion[l_applCtxt]);
                           CLOG(0,0,"CRITICAL!! Received Version [%d] is less than Min Supported Appl Context version [%d]",
                                 l_mapVersion,
                                 g_ConfigData->i_NgConfigData.m_ApplSupportedMinVersion[l_applCtxt]);
                           setError(p_tcapMsg->dialog_id, DLG_APPL_CTXT_NOT_SUPPORTED_DOWNGRADE);
                           sendAbort(p_tcapMsg->dialog_id, DP_UNREC_MESSAGE, ABRT_APPLICATION_CONTEXT_NOT_SUPPORTED,
                                 g_ConfigData->i_NgConfigData.m_ApplSupportedMinVersion[l_applCtxt]);
                        }
                        else
                        {
                           printf("\nCRITICAL!! Max Version for Appl Context [%d] is [%d]. But received version is [%d]", 
                                 l_applCtxt, g_ConfigData->i_NgConfigData.m_ApplSupportedMaxVersion[l_applCtxt], l_mapVersion);
                           CLOG(0,0,"CRITICAL!! Max Version for Appl Context [%d] is [%d]. But received version is [%d]", 
                                 l_applCtxt, g_ConfigData->i_NgConfigData.m_ApplSupportedMaxVersion[l_applCtxt], l_mapVersion);
                           setError(p_tcapMsg->dialog_id, DLG_APPL_CTXT_NOT_SUPPORTED_DOWNGRADE);
                           sendAbort(p_tcapMsg->dialog_id, DP_UNREC_MESSAGE, ABRT_APPLICATION_CONTEXT_NOT_SUPPORTED, 
                                 g_ConfigData->i_NgConfigData.m_ApplSupportedMaxVersion[l_applCtxt]);
                        }
                     }
                  }
                  else
                  {
                     printf("\nCRITICAL!! Application Context Not Supported [%d]", l_applCtxt);
                     CLOG(0,0,"CRITICAL!! Application Context Not Supported [%d]", l_applCtxt);
                     setError(p_tcapMsg->dialog_id, DLG_APPL_CTXT_NOT_SUPPORTED_AT_ALL);
                     sendAbort(p_tcapMsg->dialog_id, DP_UNREC_MESSAGE, ABRT_NOT_PRESENT);
                  }
               }
               else
               {
                  DLOG(0,1,"Application Context Not Present. This is probably a version 1 request.");
                  setError(p_tcapMsg->dialog_id, DLG_APPL_ABSENT_IN_DLG_PORTION);
                  if (p_tcapMsg->tcu.dhp.comp_present_ind)
                  {
                     DLOG(0,1,"Components present ind is true");
                     (g_DlgContexts+p_tcapMsg->dialog_id)->m_DlgState = DLG_STATE_WAIT_FOR_INIT_DATA;

                     // Temporarily sending abort here - to change later
                     sendAbort(p_tcapMsg->dialog_id, DP_UNREC_MESSAGE, ABRT_NOT_PRESENT);
                  }
                  else
                  {
                     CLOG(0,1,"No Components present too. Sending Abort...");
                     sendAbort(p_tcapMsg->dialog_id, DP_UNREC_MESSAGE, ABRT_NOT_PRESENT);
                  }
               }
            }
            else
            {
               DLOG(0,1,"No Dialogue Portion Present. Assuming v1... ");
               if (p_tcapMsg->tcu.dhp.comp_present_ind)
               {
                  DLOG(0,1,"Components present. Probably V1 message");
                  (g_DlgContexts+p_tcapMsg->dialog_id)->m_IncomingMapVersion = MAP_V1;
                  (g_DlgContexts+p_tcapMsg->dialog_id)->m_tdr->setMapVersion(1);
                  (g_DlgContexts+p_tcapMsg->dialog_id)->m_appl_id = p_tcapMsg->appl_id;
                  (g_DlgContexts+p_tcapMsg->dialog_id)->m_DlgState = DLG_STATE_WAIT_FOR_INIT_DATA;

                  if (processTcapComponents(p_tcapCompMsg))
                  {
                     processTcapComponents(p_tcapCompMsg2);
                  }

                  DLOG(0,1,"Calling SignalMapDelInd");

                  SignalMapDelInd(p_tcapMsg->dialog_id);
               }
               else
               {
                  (g_DlgContexts+p_tcapMsg->dialog_id)->m_IncomingMapVersion = MAP_V1;
                  (g_DlgContexts+p_tcapMsg->dialog_id)->m_tdr->setMapVersion(1);
                  printf("\nNo Dialogue Portion present. No Components too. Sending Abort...");
                  CLOG(0,0,"No Dialogue Portion present. No Components too. Sending Abort...");
                  SignalMapOpenInd(p_tcapMsg->dialog_id, NULL, MAP_AC_CODE_shortMsgMTRelay, (g_DlgContexts+p_tcapMsg->dialog_id)->m_tmp_remote_address, (g_DlgContexts+p_tcapMsg->dialog_id)->m_tmp_local_address);
                  SignalMapDelInd(p_tcapMsg->dialog_id);
                  //setError(p_tcapMsg->dialog_id, DLG_DLG_PORTION_AND_COMPONENTS_ABSENT),
                  //sendAbort(p_tcapMsg->dialog_id, DP_UNREC_MESSAGE, ABRT_NOT_PRESENT);
               }
            }
            break;

         case TC_CONTINUE:
            DLOG(0,1,"Received a TCAP Dialogue Primitive TC_CONTINUE message");

            if (DLG_STATE_IDLE == (g_DlgContexts+p_tcapMsg->dialog_id)->m_DlgState)
            {
               CLOG(0,1,"Severe Error!!! Received CONTINUE in DLG_STATE_IDLE state");
            }
            else if (DLG_STATE_DLG_INITIATED == (g_DlgContexts+p_tcapMsg->dialog_id)->m_DlgState)
            {
               // Perform checks like 
               // 1. Check Application Context Negotiation

               processTcapComponents(p_tcapCompMsg);
               DLOG(0,1,"Calling SignalMapDelInd");
               SignalMapDelInd(p_tcapMsg->dialog_id);

               //memcpy((g_DlgContexts+p_tcapMsg->dialog_id)->m_tmp_remote_address, p_tcapMsg->tcu.dhp.remote_address, MAX_ADDR_LEN);
               (g_DlgContexts+p_tcapMsg->dialog_id)->m_DlgState = DLG_STATE_ESTABLISHED;
            }
            else
            {
               memcpy((g_DlgContexts+p_tcapMsg->dialog_id)->m_tmp_remote_address, p_tcapMsg->tcu.dhp.remote_address, MAX_ADDR_LEN);
               processTcapComponents(p_tcapCompMsg);
               DLOG(0,1,"Calling SignalMapDelInd 2");
               SignalMapDelInd(p_tcapMsg->dialog_id);
               (g_DlgContexts+p_tcapMsg->dialog_id)->m_DlgState = DLG_STATE_ESTABLISHED;
            }
            break;

         case TC_END:
            DLOG(0,1,"Received a TCAP Dialogue Primitive TC_END message");
            if (DLG_TYPE_APPLICATION_INITIATED == (g_DlgContexts+p_tcapMsg->dialog_id)->m_DlgType)
            {
               if (RETURNerror == cTCAPReleaseDialogId(p_tcapMsg->dialog_id))
               {
                  ELOG(0,1,"cTCAPReleaseDialogId Unable to release the dialog ID %d", p_tcapMsg->dialog_id);
               }
               else
               {
                  DLOG(0,1,"cTCAPReleaseDialogId Released the dialog ID %d", p_tcapMsg->dialog_id);
               }
            }

            processTcapComponents(p_tcapCompMsg);
            processTcapComponents(p_tcapCompMsg2); //Added for the SRG call flow where SRI-SM response comes with InformSC
            SignalMapCloseInd(p_tcapMsg->dialog_id);

            // Log Statistics
            logSuccessDialogue(p_tcapMsg->dialog_id);
            // End of Log Statistics
            break;

         case TC_U_ABORT:
            DLOG(0,1,"Received a TCAP Dialogue Primitive TC_U_ABORT message");
            if (DLG_TYPE_APPLICATION_INITIATED == (g_DlgContexts+p_tcapMsg->dialog_id)->m_DlgType)
            {
               if (RETURNerror == cTCAPReleaseDialogId(p_tcapMsg->dialog_id))
               {
                  ELOG(0,1,"cTCAPReleaseDialogId Unable to release the dialog ID %d", p_tcapMsg->dialog_id);
               }
               else
               {
                  DLOG(0,1,"cTCAPReleaseDialogId Released the dialog ID %d", p_tcapMsg->dialog_id);
               }
            }

            if (DLG_STATE_DLG_INITIATED == (g_DlgContexts+p_tcapMsg->dialog_id)->m_DlgState)
            {
               LLOG(0,1,"Received Abort in DLG INITIATED state\n");

               if (p_tcapMsg->tcu.dhp.dp_present_ind)
               {
                  if (ABRT_APPLICATION_CONTEXT_NOT_SUPPORTED == p_tcapMsg->tcu.dhp.pdp->abort_reason)
                  {
                     logOtherErrorCodeStats(p_tcapMsg->dialog_id, OTHER_ERROR_CODE_RCVD_PRIMITIVE_VERSION_U_ABORT);
                     int l_length = p_tcapMsg->tcu.dhp.pdp->application_context_name.length;
                     int l_version = p_tcapMsg->tcu.dhp.pdp->application_context_name.value[l_length-1];

                     if(l_version < (g_DlgContexts+p_tcapMsg->dialog_id)->m_InitiatingMapVersion)
                     {
                        LLOG(0,1,"Version in Abort is %d, while initiated was %d. Signaling OpenCnf to application.", l_version, 
                              (g_DlgContexts+p_tcapMsg->dialog_id)->m_InitiatingMapVersion);
                        SignalMapOpenCnf(p_tcapMsg->dialog_id, l_version, REFUSE_REASON_APPL_CNTXT_NOT_SUPPORTED);
                     }
                     else
                     {
                        LLOG(0,1,"Version in Abort is %d, while initiated was %d. Signaling Abort to application.", 
                              l_version, 
                              (g_DlgContexts+p_tcapMsg->dialog_id)->m_InitiatingMapVersion);
                        SignalMapUAbortInd(p_tcapMsg->dialog_id, p_tcapMsg->tcu.dhp.abort_cause, p_tcapMsg->tcu.dhp.pdp->abort_reason);
                     }
                  }
                  else
                  {
                     logOtherErrorCodeStats(p_tcapMsg->dialog_id, OTHER_ERROR_CODE_RCVD_PRIMITIVE_GENERAL_U_ABORT);
                     SignalMapUAbortInd(p_tcapMsg->dialog_id, p_tcapMsg->tcu.dhp.abort_cause, p_tcapMsg->tcu.dhp.pdp->abort_reason);
                  }
               }
               else
               {
                  SignalMapUAbortInd(p_tcapMsg->dialog_id, p_tcapMsg->tcu.dhp.abort_cause, 0);
               }
            }
            else
            {
               //Report MAP ABORT to the map user  -- to add code
               SignalMapUAbortInd(p_tcapMsg->dialog_id, p_tcapMsg->tcu.dhp.abort_cause, 0);
            }

            break;

         case TC_P_ABORT:
            logOtherErrorCodeStats(p_tcapMsg->dialog_id, OTHER_ERROR_CODE_RCVD_PRIMITIVE_P_ABORT);
            if (DLG_TYPE_APPLICATION_INITIATED == (g_DlgContexts+p_tcapMsg->dialog_id)->m_DlgType)
            {
               if (RETURNerror == cTCAPReleaseDialogId(p_tcapMsg->dialog_id))
               {
                  ELOG(0,1,"cTCAPReleaseDialogId Unable to release the dialog ID %d", p_tcapMsg->dialog_id);
               }
               else
               {
                  DLOG(0,1,"cTCAPReleaseDialogId Released the dialog ID %d", p_tcapMsg->dialog_id);
               }

            }

            DLOG(0,1,"Received a TCAP Dialogue Primitive TC_P_ABORT message");
            SignalMapPAbortInd(p_tcapMsg->dialog_id);
            break;

         case TC_NOTICE:
            {
               logOtherErrorCodeStats(p_tcapMsg->dialog_id, OTHER_ERROR_CODE_RCVD_PRIMITIVE_TC_NOTICE);
               (g_DlgContexts+p_tcapMsg->dialog_id)->m_ErrorExchangedFlag = true; //Added on 23-Sep to count in statistics as failures

               if (DLG_TYPE_APPLICATION_INITIATED == (g_DlgContexts+p_tcapMsg->dialog_id)->m_DlgType)
               {                  
                  if (RETURNerror == cTCAPReleaseDialogId(p_tcapMsg->dialog_id))
                  {
                     ELOG(0,1,"cTCAPReleaseDialogId Unable to release the dialog ID %d", p_tcapMsg->dialog_id);
                  }
                  else
                  {
                     DLOG(0,1,"cTCAPReleaseDialogId Released the dialog ID %d", p_tcapMsg->dialog_id);
                  }
               }

               DLOG(0,1,"Received a TCAP Dialogue Primitive TC_NOTICE message");

               if (DLG_STATE_DLG_INITIATED == (g_DlgContexts+p_tcapMsg->dialog_id)->m_DlgState) 
               {
                  SignalMapOpenCnf(p_tcapMsg->dialog_id, MAP_V_UNKNOWN, REFUSE_REASON_REMOTE_NODE_NOT_REACHABLE);
               }
               else
               {
                  SignalMapNoticeInd(p_tcapMsg->dialog_id);
               }
            }
            break;

         case TC_L_CANCEL:
            logOtherErrorCodeStats(p_tcapMsg->dialog_id, OTHER_ERROR_CODE_RCVD_PRIMITIVE_TC_L_CANCEL);
            DLOG(0,1,"Received a TCAP Dialogue Primitive TC_L_CANCEL message");
            (g_DlgContexts+p_tcapMsg->dialog_id)->m_ErrorExchangedFlag = true; //Added on 23-Sep to count in statistics as failures
            SignalMapNoticeInd(p_tcapMsg->dialog_id);
            break;


         default:
            ELOG(0,1,"Received Unknown Primitive [%d] Message. Ignoring!!!", p_tcapMsg->prim_code);
            return false;
            break;
      }
   }
   else
   {
      switch (p_tcapCompMsg->prim_code)
      {
         case TC_L_CANCEL:
            logOtherErrorCodeStats(p_tcapMsg->dialog_id, OTHER_ERROR_CODE_RCVD_COMPONENT_TC_L_CANCEL);
            DLOG(0,1,"Received a TCAP Component Primitive TC_L_CANCEL message");
            (g_DlgContexts+p_tcapMsg->dialog_id)->m_ErrorExchangedFlag = true; //Added on 23-Sep to count in statistics as failures
            (g_DlgContexts+p_tcapCompMsg->dialog_id)->m_DlgState = DLG_STATE_GOT_L_CANCEL;
            SignalMapProvError(p_tcapCompMsg->dialog_id, MAP_PROV_ERROR_NO_RESPONSE_FROM_THE_PEER, MAP_PROV_ERROR_REJECT_TYPE_UNKNOWN, 0, 0, 0);
            break;

         default:
            ELOG(0,1,"Received an unexpected TCAP Component Primitive message %d", p_tcapCompMsg->prim_code);
            break;

      }
   }
   return true;
}

void SignalMapProvError(int p_dialogueId, EMapProvError p_error, EMapProvErrorRejectType p_ert, U8 p_pt, U8 p_pc, U8 p_invokeId)
{
   MapProviderErrorMsg *l_prov = new MapProviderErrorMsg;
   ///-l_prov->m_DlgId     = p_dialogueId;
   l_prov->m_UserDlgId = p_dialogueId;
   l_prov->m_MapProvErrorCode = p_error;
   l_prov->m_rejectType  = p_ert;
   l_prov->m_problemType = p_pt;
   l_prov->m_problemCode = p_pc;
   l_prov->m_InvokeId = p_invokeId;
   sendMessage(l_prov);
}

void SignalMapOpenInd(int p_dialogueId, MAP_BeginSubscriberActivityArg *p_arg, EMapApplicationContext p_applCtxt, 
      U8 *p_remote, U8 *p_local)
{
   (g_DlgContexts+p_dialogueId)->m_crossedNg=true;
   MapOpenInd *l_mapOpenInd = new MapOpenInd;
   ///-l_mapOpenInd->m_DlgId     = p_dialogueId;
   l_mapOpenInd->m_UserDlgId = p_dialogueId;
   l_mapOpenInd->m_Version   = (g_DlgContexts+p_dialogueId)->m_IncomingMapVersion;
   l_mapOpenInd->m_ApplCntxt = p_applCtxt;

   if(p_remote != NULL)
   {
      U8 l_dataSize=0;
      SccpAddress l_sccpAddress;
      SccpErrorReport l_errorReport;
      memset(&l_sccpAddress, '\0', sizeof(l_sccpAddress));
      l_dataSize=MAX_ADDR_LEN;
      l_sccpAddress.protocol = g_protocol;
      memset(&l_errorReport, '\0', sizeof(l_errorReport));

      sccpDecodeAddress(p_remote,
            &l_sccpAddress,
            &l_dataSize,
            &l_errorReport);
      DLOG(0,1,"GT:[%s] Scheme:[%d]", l_sccpAddress.globalTitle.addressInformation, l_sccpAddress.globalTitle.encodingScheme);
      snprintf(g_DlgContexts->m_remoteGT, sizeof(g_DlgContexts->m_remoteGT), "%s", l_sccpAddress.globalTitle.addressInformation); //added to get RemoteGT
      if( (0 == (strlen((char*)l_sccpAddress.globalTitle.addressInformation)%2)) && (l_sccpAddress.globalTitle.encodingScheme == ES_BCD_ODD))
      {
         TLOG(0,1,"removing the last character");
         l_sccpAddress.globalTitle.addressInformation[strlen(l_sccpAddress.globalTitle.addressInformation)-1] = '\0';
      }
      memcpy(&(l_mapOpenInd->m_OrigAddr), &l_sccpAddress, sizeof(L_SccpAddress));
   }

   if(p_local != NULL)
   {
      U8 l_dataSize=0;
      SccpAddress l_sccpAddress;
      SccpErrorReport l_errorReport;
      memset(&l_sccpAddress, '\0', sizeof(l_sccpAddress));
      l_dataSize=MAX_ADDR_LEN;
      l_sccpAddress.protocol = g_protocol;
      memset(&l_errorReport, '\0', sizeof(l_errorReport));

      sccpDecodeAddress(p_local,
            &l_sccpAddress,
            &l_dataSize,
            &l_errorReport);
      memcpy(&(l_mapOpenInd->m_DestAddr), &l_sccpAddress, sizeof(L_SccpAddress));
      DLOG(0,0," ### 1 OPEN IND DEST ADDR [%s] ### ", l_mapOpenInd->m_DestAddr.globalTitle.addressInformation);
   }


   if (MAP_V1 == l_mapOpenInd->m_Version)
   {
      LLOG(0,1,"MAPV_1 filling MapOpenInd...");
      if (p_arg != NULL)
      {
         l_mapOpenInd->m_OpenInfo.bit_mask = MAP_DP_OpenInfo_destinationReference_present | MAP_DP_OpenInfo_originationReference_present;
         l_mapOpenInd->m_OpenInfo.destinationReference.length = p_arg->imsi.length;
         memcpy(l_mapOpenInd->m_OpenInfo.destinationReference.value, 
               p_arg->imsi.value,
               p_arg->imsi.length);

         l_mapOpenInd->m_OpenInfo.originationReference.length = p_arg->originatingEntityNumber.length;
         memcpy(l_mapOpenInd->m_OpenInfo.originationReference.value, 
               p_arg->originatingEntityNumber.value,
               p_arg->originatingEntityNumber.length);

         g_AsnCodecI1.freePdu(MapConstants::getBeginSubscriberActivityPdu(), p_arg);
      }
   }
   else
   {
      // Decode the User Information

      ctcap_dp_t *l_dp = &((g_DlgContexts+p_dialogueId)->m_dp);

      if(l_dp->user_information_length)
      {
         DLOG(0,1,"User Information present in the TC_BEGIN");

         if (ASN1_ANY_ENCODING_SCHEME | l_dp->user_information[0].encoding_scheme)
         {
            DLOG(0,1,"ASN1_ANY_ENCODING_SCHEME present Length[%d]", 
                  l_dp->user_information[0].encoding.octet_aligned.length);

            void *l_dpdu=NULL;
            unsigned char *l_tempBuffer=NULL;
            int l_tempLength = l_dp->user_information[0].encoding.octet_aligned.length;
            l_tempBuffer = new unsigned char[l_tempLength];
            memcpy(l_tempBuffer, 
                  l_dp->user_information[0].encoding.octet_aligned.value,
                  l_tempLength);

            int l_result = g_AsnCodecI2.decode(l_tempBuffer, 
                  l_tempLength,
                  MapConstants::getMapDialoguePdu(),
                  &l_dpdu);

            delete []l_tempBuffer;

            if (l_result != 0)
            {
               ELOG(0,1,"Decoding failed [%s]", g_AsnCodecI2.getErrMsg());
            }
            else
            {
               genericPrintPdu(&g_AsnCodecI2, MapConstants::getMapDialoguePdu(), l_dpdu, "===>>");
               MAP_DP_DialoguePDU *l_dp1 = (MAP_DP_DialoguePDU *)l_dpdu;
               if (MAP_DP_map_open_chosen == l_dp1->choice)
               {
                  DLOG(0,1,"MAP OPEN User Information");
                  memcpy(&(l_mapOpenInd->m_OpenInfo), 
                        &(l_dp1->u.map_open), 
                        sizeof(MAP_DP_OpenInfo));
               }
               else
               {
                  ELOG(0,1,"Some other User Info [%d]", l_dp1->choice);
               }
               g_AsnCodecI2.freePdu(MapConstants::getMapDialoguePdu(), l_dpdu);
            }
         }
         else
         {
            ELOG(0,1,"ERROR!! Unhandled User Information Encoding Scheme [%d]", 
                  l_dp->user_information[0].encoding_scheme);
         }

      }
   }

   // End of Decoding the User Information
   sendMessage(l_mapOpenInd);
}

void SignalMapOpenCnf(int p_dialogueId, int p_version, ERefuseReason p_reason)
{
   MapOpenCnf *l_mapOpenCnf = new MapOpenCnf;
   ///-l_mapOpenCnf->m_DlgId     = p_dialogueId;
   l_mapOpenCnf->m_UserDlgId = p_dialogueId;
   l_mapOpenCnf->m_ResponseChoiceFlag = false;
   l_mapOpenCnf->m_RefuseReasonParam = p_reason;
   l_mapOpenCnf->m_Version = (EMapVersion)p_version;
   sendMessage(l_mapOpenCnf);
}

void SignalMapCloseInd(int p_dialogueId)
{
   MapCloseInd *l_mapCloseInd = new MapCloseInd;
   ///-l_mapCloseInd->m_DlgId     = p_dialogueId;
   l_mapCloseInd->m_UserDlgId = p_dialogueId;
   sendMessage(l_mapCloseInd);
}

void SignalMapUAbortInd(int p_dialogueId, U8 p_AbortCause, U8 p_AbortReason)
{
   MapUAbortInd *l_mapUAbortInd = new MapUAbortInd;
   ///-l_mapUAbortInd->m_DlgId     = p_dialogueId;
   l_mapUAbortInd->m_UserDlgId = p_dialogueId;
   l_mapUAbortInd->m_AbortCause = p_AbortCause;
   l_mapUAbortInd->m_AbortReason = p_AbortReason;
   sendMessage(l_mapUAbortInd);
}

void SignalMapPAbortInd(int p_dialogueId)
{
   MapPAbortInd *l_mapPAbortInd = new MapPAbortInd;
   ///-l_mapPAbortInd->m_DlgId     = p_dialogueId;
   l_mapPAbortInd->m_UserDlgId = p_dialogueId;
   sendMessage(l_mapPAbortInd);
}

void SignalMapDelInd(int p_dialogueId)
{
   MapDelimiterInd *l_mapDelimiterInd = new MapDelimiterInd;
   ///-l_mapDelimiterInd->m_DlgId     = p_dialogueId;
   l_mapDelimiterInd->m_UserDlgId = p_dialogueId;
   sendMessage(l_mapDelimiterInd);
}

void SignalMapNoticeInd(int p_dialogueId)
{
   MapNoticeInd *l_mapNoticeInd = new MapNoticeInd;
   ///-l_mapNoticeInd->m_DlgId     = p_dialogueId;
   l_mapNoticeInd->m_UserDlgId = p_dialogueId;
   sendMessage(l_mapNoticeInd);
}

void sendMessage(MapMsg *p_MapMsgPtr)
{
   //DLOG(0,1,"Sending [%s] to the Service Layer", p_MapMsgPtr->getMsgTypeName());   
   ///-p_MapMsgPtr->m_UserDlgId = (g_DlgContexts+ p_MapMsgPtr->m_DlgId)->m_UserDlgId;
   try
   {
      int l_dlgId=p_MapMsgPtr->m_UserDlgId;
      TLOG(0,1,"Calling sendMessage with dlg id: %d", l_dlgId);
      g_sc.recvMsg(p_MapMsgPtr);      
      TLOG(0,1,"End of sendMessage with dlg id: %d", l_dlgId);
   }
   catch (...)
   {
      ELOG(0,1,"Exception occurred in processing the message with User DLG ID: %d", p_MapMsgPtr->m_UserDlgId);
   }

}


bool MplManager::prepareReject(int p_dialogId, int p_invokeId, ctblock_t *p_request, U8 p_problemType, U8 p_problemCode)
{
   p_request->prim_code   = TC_U_REJECT;
   p_request->dialog_id   = p_dialogId;
   p_request->appl_id     = applicationID;
   p_request->tcu.chp.invoke_id = p_invokeId;
   p_request->tcu.chp.last_comp_ind = LAST_COMP;
   p_request->tcu.chp.problem_type = p_problemType;
   p_request->tcu.chp.problem_code = p_problemCode;
   return true;
}


bool MplManager::processTcapComponents(ctblock_t *p_tcapMsg)
{
   if (!p_tcapMsg)
   {
      DLOG(0,1,"No Components to process");
      return true;
   }

   if( (p_tcapMsg->dialog_id < 1) || (p_tcapMsg->dialog_id > g_ConfigData->i_NgConfigData.m_MaxDialogs) )
   {
      ELOG(0,1,"ERROR!!! Invalid COMP Dialog Id received %d", p_tcapMsg->dialog_id);
      return false;
   }

   ctcap_chp_t *l_chp = &(p_tcapMsg->tcu.chp);

   DLOG(0,1,"MplManager::processTcapComponents Component Data Length [%d]", p_tcapMsg->data_len);


   switch (p_tcapMsg->prim_code)
   {
      case TC_INVOKE:
         {
            EMapApplicationContext l_applCtxtForV1 = MAP_AC_UNKNOWN;
            DLOG(0,1,"Received a TCAP Component TC_INVOKE message");
            int l_opCode;
            if (p_tcapMsg->data_len >= 3)
            {
               l_opCode = (EMapOpCode) (p_tcapMsg->pdata[2]);

               if ( (l_opCode < 1) ||
                     (l_opCode > 89)
                  )
               {
                  CLOG(0,1,"Receieved op code %d is out of range", l_opCode);
                  return false;
               }
               int l_opCodeGlobalTag = 0;
               l_opCodeGlobalTag = p_tcapMsg->pdata[0]; // opCode Tag 6-Global 2-Local
               DLOG(0,0,"opcode global local value [%d]",l_opCodeGlobalTag);
               if(0 != g_OtherConfigData->m_OpcodeTagRej)
               {
                  if(1 == g_OtherConfigData->m_OpcodeTagRej)
                  {
                     if( 6 == l_opCodeGlobalTag )
                     {
                        CLOG(0,1,"Receieved op code Tag is GLOBAL rejecting OpCode [%d]", l_opCode);
                        return false;
                     }
                  }
                  else if(2 == g_OtherConfigData->m_OpcodeTagRej)
                  {
                     if(45 == l_opCode)
                     {
                        if( 6 == l_opCodeGlobalTag )
                        {
                           CLOG(0,1,"Receieved op code Tag is GLOBAL rejecting for SRI-SM OpCode [%d]", l_opCode);
                           return false;
                        }
                     }

                  }
               }
            }
            else
            {
               ELOG(0,1,"Op Code not present in INVOKE");
               return false;
            }

            TLOG(0,1,"Received OpCode: %d", l_opCode);

            bool l_validateIncomingOperation=false;


            if ((DLG_STATE_IDLE == (g_DlgContexts+p_tcapMsg->dialog_id)->m_DlgState))
            {
               l_validateIncomingOperation=true;
               DLOG(0,1,"Validating the incoming operation");
            }
            else if((DLG_STATE_WAIT_FOR_INIT_DATA == (g_DlgContexts+p_tcapMsg->dialog_id)->m_DlgState))
            {
               if (MAP_V1 == (g_DlgContexts+p_tcapMsg->dialog_id)->m_IncomingMapVersion)
               {
                  DLOG(0,1,"Checking if it is a BEGIN SUBSCRIBER ACTIVITY %d", l_validateIncomingOperation);
                  if ((int)MAP_OP_CODE_beginSubscriberActivity != l_opCode)
                  {
                     l_applCtxtForV1 = MapConstants::getV1ApplCtxt((EMapOpCode)l_opCode);
                     setApplCtxt(p_tcapMsg->dialog_id, l_applCtxtForV1);
                     TLOG(0,1,"ApplCtxtv1: %d", l_applCtxtForV1);
                     //Code to be added here for v1 appl ctxt handling
                     if(g_ConfigData->i_NgConfigData.m_ApplSupportedMap[l_applCtxtForV1])
                     {
                        (g_DlgContexts+p_tcapMsg->dialog_id)->m_IncomingMapVersion = MAP_V1;

                        TLOG(0,1,"ApplCtxtv1: %d Min:%d, Max:%d", l_applCtxtForV1, 
                              g_ConfigData->i_NgConfigData.m_ApplSupportedMinVersion[l_applCtxtForV1],
                              g_ConfigData->i_NgConfigData.m_ApplSupportedMaxVersion[l_applCtxtForV1]);
                        if((1 <= g_ConfigData->i_NgConfigData.m_ApplSupportedMaxVersion[l_applCtxtForV1]) &&
                              (1 >= g_ConfigData->i_NgConfigData.m_ApplSupportedMinVersion[l_applCtxtForV1])
                          )
                        {
                           if (true == overload(MSG_TYPE_MAP, p_tcapMsg->dialog_id, l_applCtxtForV1))
                           {
                              return false;
                           }
                           SignalMapOpenInd(p_tcapMsg->dialog_id, NULL, l_applCtxtForV1, (g_DlgContexts+p_tcapMsg->dialog_id)->m_tmp_remote_address, (g_DlgContexts+p_tcapMsg->dialog_id)->m_tmp_local_address);
                           l_validateIncomingOperation=true;
                        }
                        else
                        {
                           if(1 < g_ConfigData->i_NgConfigData.m_ApplSupportedMinVersion[l_applCtxtForV1])
                           {
                              printf("\nCRITICAL!! Received Version [%d] is less than Min Supported Appl Context version [%d]",
                                    1,
                                    g_ConfigData->i_NgConfigData.m_ApplSupportedMinVersion[l_applCtxtForV1]);
                              CLOG(0,0,"CRITICAL!! Received Version [%d] is less than Min Supported Appl Context version [%d]",
                                    1,
                                    g_ConfigData->i_NgConfigData.m_ApplSupportedMinVersion[l_applCtxtForV1]);
                              setError(p_tcapMsg->dialog_id, DLG_APPL_CTXT_NOT_SUPPORTED_DOWNGRADE);
                              sendAbort(p_tcapMsg->dialog_id, DP_UNREC_MESSAGE, ABRT_APPLICATION_CONTEXT_NOT_SUPPORTED,
                                    g_ConfigData->i_NgConfigData.m_ApplSupportedMinVersion[l_applCtxtForV1]);
                              return false;
                           }
                           else
                           {
                              printf("\nCRITICAL!! Max Version for Appl Context [%d] is [%d]. But received version is [%d]",
                                    l_applCtxtForV1, g_ConfigData->i_NgConfigData.m_ApplSupportedMaxVersion[l_applCtxtForV1], 1);
                              CLOG(0,0,"CRITICAL!! Max Version for Appl Context [%d] is [%d]. But received version is [%d]",
                                    l_applCtxtForV1, g_ConfigData->i_NgConfigData.m_ApplSupportedMaxVersion[l_applCtxtForV1], 1);
                              setError(p_tcapMsg->dialog_id, DLG_APPL_CTXT_NOT_SUPPORTED_DOWNGRADE);
                              sendAbort(p_tcapMsg->dialog_id, DP_UNREC_MESSAGE, ABRT_APPLICATION_CONTEXT_NOT_SUPPORTED,
                                    g_ConfigData->i_NgConfigData.m_ApplSupportedMaxVersion[l_applCtxtForV1]);
                              return false;
                           }
                        }
                     }
                     else
                     {
                        printf("\nCRITICAL!! Application Context Not Supported [%d]", l_applCtxtForV1);
                        CLOG(0,0,"CRITICAL!! Application Context Not Supported [%d]", l_applCtxtForV1);
                        setError(p_tcapMsg->dialog_id, DLG_APPL_CTXT_NOT_SUPPORTED_AT_ALL);
                        sendAbort(p_tcapMsg->dialog_id, DP_UNREC_MESSAGE, ABRT_NOT_PRESENT);
                        return false;
                     }
                     //End of Code added here for v1 appl ctxt handling

                     (g_DlgContexts+p_tcapMsg->dialog_id)->m_IncomingApplCntxt  = l_applCtxtForV1;
                     (g_DlgContexts+p_tcapMsg->dialog_id)->m_DlgState = DLG_STATE_WAIT_FOR_LOAD_CHECK_RESULT_1;
                     StatisticsInterface::logRespondingApplCtxtTotal(l_applCtxtForV1, MAP_V1);

                  }
                  else
                  {
                     l_applCtxtForV1 = MAP_AC_CODE_networkFunctionalSs;
                     setApplCtxt(p_tcapMsg->dialog_id, l_applCtxtForV1);
                     if (true == overload(MSG_TYPE_MAP, p_tcapMsg->dialog_id, l_applCtxtForV1))
                     {
                        return false;
                     }
                  }
               }
            }

            DLOG(0,1,"validate incoming operation flag:%d true:%d false:%d", 
                  l_validateIncomingOperation, true, false);

            // Perform Statistics
            if (true == l_validateIncomingOperation)
            {
               (g_DlgContexts+p_tcapMsg->dialog_id)->m_IncomingOpCode = (EMapOpCode)l_opCode;
               if (DLG_TYPE_NETWORK_INITIATED == (g_DlgContexts+p_tcapMsg->dialog_id)->m_DlgType)
               {
                  StatisticsInterface::logRespondingOpCodeTotal(
                        l_opCode, 
                        (g_DlgContexts+p_tcapMsg->dialog_id)->m_IncomingMapVersion);
               }
               else
               {
                  StatisticsInterface::logInitiatingOpCodeTotal(
                        l_opCode, 
                        (g_DlgContexts+p_tcapMsg->dialog_id)->m_IncomingMapVersion);
               }
               list<reportData> :: iterator l_it;
               for(l_it = g_OtherConfigData->m_reportDataList.begin(); l_it!=g_OtherConfigData->m_reportDataList.end(); l_it++)
               {
                  char l_opcodeChar[4 + 1];
                  memset(l_opcodeChar, '\0', sizeof(l_opcodeChar));
                  snprintf(l_opcodeChar, sizeof(l_opcodeChar)+1, ",%02d,", l_opCode);
                  size_t l_found = l_it->m_opCodes.find(l_opcodeChar);
                  if(l_found != string::npos)
                  {
                     if((DLG_TYPE_NETWORK_INITIATED == (g_DlgContexts+p_tcapMsg->dialog_id)->m_DlgType))
                     {
                        DLOG(0,0,"Called GT is %s and GT from Config file is %s",g_DlgContexts->m_remoteGT, l_it->m_GTs.c_str());
                        string l_remoteGT(g_DlgContexts->m_remoteGT);
                        if(l_remoteGT.rfind(l_it->m_GTs.c_str(),0) == 0)
                           //size_t l_pos = l_remoteGT.find(l_it->m_GTs.c_str());
                           //if(l_pos != string::npos)
                        {
                           DLOG(0,0,"In RespodingTot, GT matched, index while calling logstatistics is %d",l_it->m_RespondingOpCodesIndices[l_opCode].m_TotalCountGTMat[(g_DlgContexts+p_tcapMsg->dialog_id)->m_IncomingMapVersion - 1]);
                           HLRStatisticsInitializer::logStatistics(l_it->m_RespondingOpCodesIndices[l_opCode].m_TotalCountGTMat[(g_DlgContexts+p_tcapMsg->dialog_id)->m_IncomingMapVersion - 1]);
                        }
                        else
                        {
                           DLOG(0,0,"In RespondingTot, GT Not matched, index while calling logstatistics is %d",l_it->m_RespondingOpCodesIndices[l_opCode].m_TotalCountGTMat[(g_DlgContexts+p_tcapMsg->dialog_id)->m_IncomingMapVersion - 1]);
                           HLRStatisticsInitializer::logStatistics(l_it->m_RespondingOpCodesIndices[l_opCode].m_TotalCountGTNotMat[(g_DlgContexts+p_tcapMsg->dialog_id)->m_IncomingMapVersion - 1]);

                        } 
                     }

                  }
               }
            }


            if (l_validateIncomingOperation && (false == g_mm.isPresent(MSG_TYPE_MAP, l_opCode)))
            {
               l_validateIncomingOperation=false;
               // Op Code is not serviced
               LLOG(0,1,"Op Code [%d] Not supported. Sending Reject", l_opCode);

               ctblock_t l_reject;
               memset(&l_reject, '\0', sizeof(l_reject));
               prepareReject(p_tcapMsg->dialog_id, l_chp->invoke_id, &l_reject, CP_PT_IP, CP_IP_UR_OP);
               sendToTcapStack(&l_reject);

               SignalMapNoticeInd(p_tcapMsg->dialog_id);
            }
            else
            {
               bool l_versionSupportedFlag=false;

               EMapVersion l_mv=MAP_V_UNKNOWN;
               if(true == l_validateIncomingOperation)
               {
                  if (DLG_TYPE_NETWORK_INITIATED == (g_DlgContexts+p_tcapMsg->dialog_id)->m_DlgType)
                  {
                     l_mv=(g_DlgContexts+p_tcapMsg->dialog_id)->m_IncomingMapVersion;
                  }
                  else
                  {
                     l_mv=(g_DlgContexts+p_tcapMsg->dialog_id)->m_InitiatingMapVersion;
                  }
                  switch (l_mv)
                  {
                     case MAP_V1:
                        l_versionSupportedFlag  = g_mm.m_mapping[MSG_TYPE_MAP][l_opCode].m_Map1Flag;
                        break;
                     case MAP_V2:
                        l_versionSupportedFlag  = g_mm.m_mapping[MSG_TYPE_MAP][l_opCode].m_Map2Flag;
                        break;
                     case MAP_V3:
                        l_versionSupportedFlag  = g_mm.m_mapping[MSG_TYPE_MAP][l_opCode].m_Map3Flag;
                        break;
                     default:
                        l_versionSupportedFlag = false;
                        break;
                  }
               }
               else
               {
                  LLOG(0,1,"Assuming version supported flag is true");
                  l_versionSupportedFlag=true;
               }

               if(false == l_versionSupportedFlag)
               {
                  LLOG(0,1,"Op Code [%d] Not supported for version [%d]. Sending Reject", l_opCode, l_mv);

                  /*ctblock_t l_reject;
                    memset(&l_reject, '\0', sizeof(l_reject));
                    prepareReject(p_tcapMsg->dialog_id, l_chp->invoke_id, &l_reject, CP_PT_IP, CP_IP_UR_OP);*/

                  ctblock_t l_error;
                  memset (&l_error, 0, sizeof(l_error));

                  l_error.prim_code   = TC_U_ERROR;
                  l_error.dialog_id   = p_tcapMsg->dialog_id;
                  l_error.appl_id     = (g_DlgContexts+ p_tcapMsg->dialog_id)->m_appl_id;
                  l_error.tcu.chp.class_of_oper = 0;
                  l_error.tcu.chp.invoke_id = p_tcapMsg->tcu.chp.invoke_id;
                  l_error.tcu.chp.linked_id = -1;
                  l_error.tcu.chp.last_comp_ind = LAST_COMP;
                  (g_DlgContexts+ p_tcapMsg->dialog_id)->m_ErrorExchangedFlag = true;
                  (g_DlgContexts+ p_tcapMsg->dialog_id)->m_ErrorCodeExchanged = MAP_ERROR_systemFailure;

                  l_error.data_len = 3;
                  l_error.pdata = new unsigned char[3];
                  l_error.pdata[0] = CP_EC_LOCAL; /* Error Code tag */
                  l_error.pdata[1] = 1;
                  l_error.pdata[2] = MAP_ERROR_systemFailure; /* Error Code */

                  sendToTcapStack(&l_error);

                  SignalMapNoticeInd(p_tcapMsg->dialog_id);

               }
               else if ((int)MAP_OP_CODE_beginSubscriberActivity == l_opCode)
               {
                  LLOG(0,1,"MAP_OP_CODE_beginSubscriberActivity came");
                  MAP_BeginSubscriberActivityArg *l_bsaArg = NULL;

                  int l_bufferLen = p_tcapMsg->data_len-3;
                  if (l_bufferLen)
                  {
                     unsigned char *l_buffer = new unsigned char[l_bufferLen];
                     memcpy(l_buffer, &(p_tcapMsg->pdata[3]), p_tcapMsg->data_len-3);
                     void *l_pdu = NULL;

                     int l_result = g_AsnCodecI1.decode(l_buffer, 
                           l_bufferLen,
                           MapConstants::getBeginSubscriberActivityPdu(),
                           &l_pdu);

                     if (l_result != 0)
                     {
                        ELOG(0,1,"Decoding failed [%s]", g_AsnCodecI1.getErrMsg());
                     }
                     else
                     {
                        genericPrintPdu(&g_AsnCodecI1, MapConstants::getBeginSubscriberActivityPdu(), l_pdu, "===>>");

                        l_bsaArg = (MAP_BeginSubscriberActivityArg *)(l_pdu);
                        DLOG(0,1,"bsa length : %d", l_bsaArg->imsi.length);
                     }
                     delete []l_buffer;

                     SignalMapOpenInd(p_tcapMsg->dialog_id, l_bsaArg, l_applCtxtForV1, (g_DlgContexts+p_tcapMsg->dialog_id)->m_tmp_remote_address, (g_DlgContexts+p_tcapMsg->dialog_id)->m_tmp_local_address);
                     (g_DlgContexts+p_tcapMsg->dialog_id)->m_DlgState = DLG_STATE_DIALOGUE_PENDING;
                  }
                  else
                  {
                     CLOG(0,0,"Op Code is MAP_BeginSubscriberActivityArg. But No Component Buffer Present. Sending Abort...");
                     setError(p_tcapMsg->dialog_id, DLG_NO_COMPONENTS_APART_FROM_BSG_IN_V1);
                     sendAbort(p_tcapMsg->dialog_id, DP_UNREC_MESSAGE, ABRT_NOT_PRESENT);
                     return false;
                  }
               }
               else
               {
                  MapSpecificIndication *l_mapSpecMsg = new MapSpecificIndication((EMapOpCode)l_opCode);
                  DLOG(0,1,"Got a indication with op code %d", l_opCode);

                  // Perform some checks like
                  // 1. Invoke Id already assigned 
                  // 2. Whether Operation exists or not
                  // 3. Linked ID present or not

                  ///-l_mapSpecMsg->m_DlgId     = p_tcapMsg->dialog_id;
                  l_mapSpecMsg->m_UserDlgId = p_tcapMsg->dialog_id;


                  if (DLG_TYPE_NETWORK_INITIATED == (g_DlgContexts+p_tcapMsg->dialog_id)->m_DlgType)
                  {
                     l_mapSpecMsg->m_Version   = (g_DlgContexts+p_tcapMsg->dialog_id)->m_IncomingMapVersion;
                  }
                  else
                  {
                     l_mapSpecMsg->m_Version   = (g_DlgContexts+p_tcapMsg->dialog_id)->m_InitiatingMapVersion;
                  }
                  if(NOT_LAST_COMP == l_chp->last_comp_ind)
                  {
                     l_mapSpecMsg->m_lci = MAP_SPEC_LAST_COMPONENT_IND_NOT_LAST;
                  }
                  else if(LAST_COMP == l_chp->last_comp_ind)
                  {
                     l_mapSpecMsg->m_lci = MAP_SPEC_LAST_COMPONENT_IND_LAST;
                  }



                  l_mapSpecMsg->m_InvokeId = l_chp->invoke_id;
                  (g_DlgContexts+p_tcapMsg->dialog_id)->m_psm.m_InvokeId         = l_chp->invoke_id;

                  l_mapSpecMsg->m_OpCode                                       = (EMapOpCode)l_opCode;
                  (g_DlgContexts+p_tcapMsg->dialog_id)->m_psm.m_OpCode           = (EMapOpCode)l_opCode;

                  if (p_tcapMsg->data_len > 3)
                  {
                     l_mapSpecMsg->m_bufLen = (p_tcapMsg->data_len-3>MAX_COMP_BUFFER_SIZE)?MAX_COMP_BUFFER_SIZE:p_tcapMsg->data_len-3;
                     memcpy(&(l_mapSpecMsg->m_buffer), &(p_tcapMsg->pdata[3]), l_mapSpecMsg->m_bufLen);
                     if(l_mapSpecMsg->m_bufLen < p_tcapMsg->data_len-3)
                     {
                        WLOG(0,1,"Original Recvd Length is %d. But Considering only %d", p_tcapMsg->data_len-3, MAX_COMP_BUFFER_SIZE);
                     }
                  }
                  else
                  {
                     TLOG(0,1,"No Component Buffer present");
                  }
                  sendMessage(l_mapSpecMsg);
               }
            }
         }
         break;

      default:  //All other Component Types 
         {
            if(false == (g_DlgContexts+p_tcapMsg->dialog_id)->m_crossedNg)
            {
               CLOG(0,1,"Invalid component type %d in this state", p_tcapMsg->prim_code);
               setError(p_tcapMsg->dialog_id, DLG_INVALID_COMPONENT);
               sendAbort(p_tcapMsg->dialog_id, DP_UNREC_MESSAGE, ABRT_NOT_PRESENT);
               return false;
            }

            switch(p_tcapMsg->prim_code)
            {
               case TC_RESULT_L:
               case TC_RESULT_NL:
                  {
                     DLOG(0,1,"Received a TCAP Component TC_RESULT_L message");
                     EMapOpCode l_resultOpCode = MAP_OP_CODE_UNKNOWN;

                     bool l_lengthInTwoBytesFlag=false;
                     if (p_tcapMsg->data_len >=5)
                     {
                        DLOG(0,1,"TC_RESULT_L message.dt.1:%02x dt.2:%02x", p_tcapMsg->pdata[1], p_tcapMsg->pdata[2]);
                        if(p_tcapMsg->pdata[1] == 0x81)
                        {
                           l_resultOpCode = (EMapOpCode)(p_tcapMsg->pdata[5]);
                           l_lengthInTwoBytesFlag = true;
                        }
                        else
                        {
                           l_resultOpCode = (EMapOpCode)(p_tcapMsg->pdata[4]);
                        }
                     }
                     else
                     {
                        TLOG(0,1,"Didn't receive any opcode. assuming %d", (g_DlgContexts+p_tcapMsg->dialog_id)->m_rsm.m_OpCode);
                        l_resultOpCode = (g_DlgContexts+p_tcapMsg->dialog_id)->m_rsm.m_OpCode;
                     }

                     if ((int)l_resultOpCode < 1)
                     {
                        ELOG(0,1,"Unable to deduce op code in TC_RESULT_L");
                        return false;
                     }

                     if (l_resultOpCode != (g_DlgContexts+p_tcapMsg->dialog_id)->m_rsm.m_OpCode)
                     {
                        WLOG(0,1,"Invalid opcode %d while expecting opcode %d ", 
                              l_resultOpCode, (g_DlgContexts+p_tcapMsg->dialog_id)->m_rsm.m_OpCode);
                        SignalMapProvError(p_tcapMsg->dialog_id, MAP_PROV_ERROR_INVALID_RESPONSE_RECEIVED, MAP_PROV_ERROR_REJECT_TYPE_UNKNOWN, 0, 0, 0);
                        return false;
                     }

                     MapSpecificConfirmation *l_mapSpecResult = new MapSpecificConfirmation((EMapOpCode)(l_resultOpCode));
                     if(TC_RESULT_NL == p_tcapMsg->prim_code)
                     {
                        l_mapSpecResult->m_LastFlag = 0;
                     }
                     ///-l_mapSpecResult->m_DlgId   = p_tcapMsg->dialog_id;
                     l_mapSpecResult->m_UserDlgId   = p_tcapMsg->dialog_id;

                     if (DLG_TYPE_NETWORK_INITIATED == (g_DlgContexts+p_tcapMsg->dialog_id)->m_DlgType)
                     {
                        l_mapSpecResult->m_Version   = (g_DlgContexts+p_tcapMsg->dialog_id)->m_IncomingMapVersion;


                     }
                     else
                     {
                        l_mapSpecResult->m_Version   = (g_DlgContexts+p_tcapMsg->dialog_id)->m_InitiatingMapVersion;
                     }

                     if(NOT_LAST_COMP == l_chp->last_comp_ind)
                     {
                        l_mapSpecResult->m_lci = MAP_SPEC_LAST_COMPONENT_IND_NOT_LAST;
                     }
                     else if(LAST_COMP == l_chp->last_comp_ind)
                     {
                        l_mapSpecResult->m_lci = MAP_SPEC_LAST_COMPONENT_IND_LAST;
                     }
                     l_mapSpecResult->m_InvokeId = l_chp->invoke_id;

                     if (l_chp->invoke_id != (g_DlgContexts+p_tcapMsg->dialog_id)->m_rsm.m_InvokeId)
                     {
                        WLOG(0,1,"Invalid Invoke ID [%d] received, instead of [%d]", 
                              l_chp->invoke_id, (g_DlgContexts+p_tcapMsg->dialog_id)->m_rsm.m_InvokeId);
                        SignalMapProvError(p_tcapMsg->dialog_id, MAP_PROV_ERROR_INVALID_RESPONSE_RECEIVED, MAP_PROV_ERROR_REJECT_TYPE_UNKNOWN, 0, 0, 0);
                        return false;
                     }

                     (g_DlgContexts+p_tcapMsg->dialog_id)->m_rsm.m_InvokeId         = l_chp->invoke_id;

                     //l_mapSpecResult->m_OpCode                                    = (EMapOpCode) (p_tcapMsg->pdata[4]);
                     //(g_DlgContexts+p_tcapMsg->dialog_id)->m_rsm.m_OpCode           = (EMapOpCode) (p_tcapMsg->pdata[4]);

                     if (p_tcapMsg->data_len > 5)
                     {
                        if(false == l_lengthInTwoBytesFlag)
                        {
                           l_mapSpecResult->m_bufLen = (p_tcapMsg->data_len-5>MAX_COMP_BUFFER_SIZE)?MAX_COMP_BUFFER_SIZE:p_tcapMsg->data_len-5;
                           memcpy(&(l_mapSpecResult->m_buffer), &(p_tcapMsg->pdata[5]), l_mapSpecResult->m_bufLen);
                           if(l_mapSpecResult->m_bufLen < p_tcapMsg->data_len-5)
                           {
                              WLOG(0,1,"Original Recvd Length is %d. But Considering only %d", p_tcapMsg->data_len-5, MAX_COMP_BUFFER_SIZE);
                           }
                        }
                        else
                        {
                           l_mapSpecResult->m_bufLen = (p_tcapMsg->data_len-6>MAX_COMP_BUFFER_SIZE)?MAX_COMP_BUFFER_SIZE:p_tcapMsg->data_len-6;
                           memcpy(&(l_mapSpecResult->m_buffer), &(p_tcapMsg->pdata[6]), l_mapSpecResult->m_bufLen);
                           if(l_mapSpecResult->m_bufLen < p_tcapMsg->data_len-6)
                           {
                              WLOG(0,1,"Original Recvd Length is %d. But Considering only %d", p_tcapMsg->data_len-6, MAX_COMP_BUFFER_SIZE);
                           }
                        }

                     }
                     else
                     {
                        TLOG(0,1,"No Buffer present in the component");
                     }

                     sendMessage(l_mapSpecResult);
                  }
                  break;

               case TC_U_ERROR:
                  {
                     DLOG(0,1,"Received a TCAP Component TC_U_ERROR message");

                     MapUserError *l_userError = new MapUserError(0, MAP_ERROR_UNKNOWN, MAP_V_UNKNOWN, NULL);
                     ///-l_userError->m_DlgId    = p_tcapMsg->dialog_id;
                     l_userError->m_UserDlgId    = p_tcapMsg->dialog_id;
                     l_userError->m_InvokeId = l_chp->invoke_id;
                     if (DLG_TYPE_NETWORK_INITIATED == (g_DlgContexts+p_tcapMsg->dialog_id)->m_DlgType)
                     {
                        l_userError->m_Version   = (g_DlgContexts+p_tcapMsg->dialog_id)->m_IncomingMapVersion;
                     }
                     else
                     {
                        l_userError->m_Version   = (g_DlgContexts+p_tcapMsg->dialog_id)->m_InitiatingMapVersion;
                     }
                     if(NOT_LAST_COMP == l_chp->last_comp_ind)
                     {
                        l_userError->m_lci = MAP_SPEC_LAST_COMPONENT_IND_NOT_LAST;
                     }
                     else if(LAST_COMP == l_chp->last_comp_ind)
                     {
                        l_userError->m_lci = MAP_SPEC_LAST_COMPONENT_IND_LAST;
                     }
                     (g_DlgContexts+p_tcapMsg->dialog_id)->m_ErrorExchangedFlag = true;
                     if (p_tcapMsg->data_len >= 3)
                     {
                        l_userError->m_ErrorCode = (EMapErrorCode)(p_tcapMsg->pdata[2]);
                        (g_DlgContexts+p_tcapMsg->dialog_id)->m_ErrorCodeExchanged = l_userError->m_ErrorCode;
                        l_userError->m_bufLen = (p_tcapMsg->data_len-3>MAX_COMP_BUFFER_SIZE)?MAX_COMP_BUFFER_SIZE:p_tcapMsg->data_len-3;
                        memcpy(&(l_userError->m_buffer), &(p_tcapMsg->pdata[3]), l_userError->m_bufLen);
                        if(l_userError->m_bufLen < p_tcapMsg->data_len-3)
                        {
                           WLOG(0,1,"Original Recvd Length is %d. But Considering only %d", p_tcapMsg->data_len-3, MAX_COMP_BUFFER_SIZE);
                        }
                     }
                     sendMessage(l_userError);
                  }

                  break;

               case TC_L_CANCEL:
                  {
                     logOtherErrorCodeStats(p_tcapMsg->dialog_id, OTHER_ERROR_CODE_RCVD_COMPONENT_TC_L_CANCEL);
                     DLOG(0,1,"Received a TCAP Component TC_L_CANCEL message");
                     (g_DlgContexts+p_tcapMsg->dialog_id)->m_ErrorExchangedFlag = true; //Added on 23-Sep to count in statistics as failures
                     SignalMapNoticeInd(p_tcapMsg->dialog_id);
                  }
                  break;

               case TC_U_CANCEL:
                  {
                     logOtherErrorCodeStats(p_tcapMsg->dialog_id, OTHER_ERROR_CODE_RCVD_COMPONENT_TC_U_CANCEL);
                     DLOG(0,1,"Received a TCAP Component TC_U_CANCEL message");
                     (g_DlgContexts+p_tcapMsg->dialog_id)->m_ErrorExchangedFlag = true; //Added on 23-Sep to count in statistics as failures
                     SignalMapProvError(p_tcapMsg->dialog_id, MAP_PROV_ERROR_INVALID_RESPONSE_RECEIVED, MAP_PROV_ERROR_REJECT_TYPE_U_CANCEL, 0,0, 0);
                  }
                  break;

               case TC_R_REJECT:
                  {
                     logOtherErrorCodeStats(p_tcapMsg->dialog_id, OTHER_ERROR_CODE_RCVD_COMPONENT_TC_R_REJECT);
                     DLOG(0,1,"Received a TCAP Component TC_R_REJECT message");
                     (g_DlgContexts+p_tcapMsg->dialog_id)->m_ErrorExchangedFlag = true; //Added on 23-Sep to count in statistics as failures
                     SignalMapProvError(p_tcapMsg->dialog_id, MAP_PROV_ERROR_INVALID_RESPONSE_RECEIVED, MAP_PROV_ERROR_REJECT_TYPE_R_REJECT, p_tcapMsg->tcu.chp.problem_type, p_tcapMsg->tcu.chp.problem_code, p_tcapMsg->tcu.chp.invoke_id);
                  }
                  break;

               case TC_L_REJECT:
                  {
                     logOtherErrorCodeStats(p_tcapMsg->dialog_id, OTHER_ERROR_CODE_RCVD_COMPONENT_TC_R_REJECT);
                     DLOG(0,1,"Received a TCAP Component TC_L_REJECT message");
                     (g_DlgContexts+p_tcapMsg->dialog_id)->m_ErrorExchangedFlag = true; //Added on 23-Sep to count in statistics as failures
                     SignalMapProvError(p_tcapMsg->dialog_id, MAP_PROV_ERROR_INVALID_RESPONSE_RECEIVED, MAP_PROV_ERROR_REJECT_TYPE_L_REJECT, p_tcapMsg->tcu.chp.problem_type, p_tcapMsg->tcu.chp.problem_code, p_tcapMsg->tcu.chp.invoke_id);
                  }
                  break;

               case TC_U_REJECT:
                  {
                     logOtherErrorCodeStats(p_tcapMsg->dialog_id, OTHER_ERROR_CODE_RCVD_COMPONENT_TC_U_REJECT);
                     DLOG(0,1,"Received a TCAP Component TC_U_REJECT message");
                     (g_DlgContexts+p_tcapMsg->dialog_id)->m_ErrorExchangedFlag = true; //Added on 23-Sep to count in statistics as failures
                     SignalMapProvError(p_tcapMsg->dialog_id, MAP_PROV_ERROR_INVALID_RESPONSE_RECEIVED, MAP_PROV_ERROR_REJECT_TYPE_U_REJECT, p_tcapMsg->tcu.chp.problem_type, p_tcapMsg->tcu.chp.problem_code, p_tcapMsg->tcu.chp.invoke_id);
                  }
                  break;

               default:
                  {
                     ELOG(0,1,"Received Unknown Component [%d] Message. Ignoring!!!", p_tcapMsg->prim_code);
                     return false;
                  }
                  break;
            }
         }
         break;

   }
   return true;
}


bool MplManager::sendToTcapStack(ctblock_t *p_tcapBlock)
{
   if( (g_OtherConfigData->m_sccpMsgHandlerParam == 1) && (TC_BEGIN == p_tcapBlock->prim_code) )
   {
      DLOG(0,0,"SCCP Message Handling Parameter Enabled for TC_BEGIN...Setting Message Handling bit");
      p_tcapBlock->tcu.dhp.qlty_of_svc = p_tcapBlock->tcu.dhp.qlty_of_svc|RETURN_ERROR; 
   }
   else if( (g_OtherConfigData->m_sccpMsgHandlerParam == 2) && (TC_CONTINUE == p_tcapBlock->prim_code) )
   {
      DLOG(0,0,"SCCP Message Handling Parameter Enabled for TC_CONTINUE...Setting Message Handling bit");
      p_tcapBlock->tcu.dhp.qlty_of_svc = p_tcapBlock->tcu.dhp.qlty_of_svc|RETURN_ERROR; 
   }
   else if( (g_OtherConfigData->m_sccpMsgHandlerParam == 3) && (TC_END == p_tcapBlock->prim_code) )
   {
      DLOG(0,0,"SCCP Message Handling Parameter Enabled for TC_END...Setting Message Handling bit");
      p_tcapBlock->tcu.dhp.qlty_of_svc = p_tcapBlock->tcu.dhp.qlty_of_svc|RETURN_ERROR; 
   }
   else if(g_OtherConfigData->m_sccpMsgHandlerParam == 4)
   {
      DLOG(0,0,"SCCP Message Handling Parameter Enabled for all...Setting Message Handling bit");
      p_tcapBlock->tcu.dhp.qlty_of_svc = p_tcapBlock->tcu.dhp.qlty_of_svc|RETURN_ERROR; 
   }
   printTcapBlock("<<===", p_tcapBlock, 0);
   unsigned char *l_temp = NULL;

   if (p_tcapBlock->pdata != NULL)
   {
      p_tcapBlock->pbuf = p_tcapBlock->pdata;
      l_temp            = p_tcapBlock->pdata;
   }

   if (false == (g_DlgContexts+p_tcapBlock->dialog_id)->m_crossedNg)
   {
      if ( (TC_END == p_tcapBlock->prim_code)  ||
            (TC_U_ABORT == p_tcapBlock->prim_code)
         )
      {
         char l_dateString[20+1];
         memset(l_dateString, '\0', sizeof(l_dateString));
         struct tm *l_tm_ptr=NULL;
         time_t l_tim =time(NULL);
         l_tm_ptr = localtime(&l_tim);
         sprintf(l_dateString, "%04d%02d%02d%02d%02d%02d",
               l_tm_ptr->tm_year+1900, l_tm_ptr->tm_mon+1, l_tm_ptr->tm_mday,
               l_tm_ptr->tm_hour, l_tm_ptr->tm_min, l_tm_ptr->tm_sec);

         (g_DlgContexts+p_tcapBlock->dialog_id)->m_tdr->m_HDR[TDR_HDR_RECEIVED_TIMESTAMP] = l_dateString;
         (g_DlgContexts+p_tcapBlock->dialog_id)->m_tdr->setTdrId();
         DLOG(0,0,"Source Address  : [%s]",g_DlgContexts->m_remoteGT);
         (g_DlgContexts+p_tcapBlock->dialog_id)->m_tdr->setRemoteAddr(g_DlgContexts->m_remoteGT);

         if (true == g_ConfigData->m_TdrEnabledFlag)
         {
            if(g_tfb != NULL)
            {
               DLOG(0,1,"Calling prepare TDR in NG");

               char l_buf[3000];
               memset(l_buf, '\0', sizeof(l_buf));
               g_tfb->prepareTDR(( (g_DlgContexts+p_tcapBlock->dialog_id)->m_tdr), l_buf, 0);
               LLOG(0,1,"Prepared TDR [%s]", l_buf);
               g_TdrObj.log2(LOG_LEVEL_CRITICAL, __FILE__, __FUNCTION__, __LINE__, 0, 0, l_buf);
            }
         }
      }
   }


   if (RETURNok != cTCAPPutTblock(p_tcapBlock))
   {
      ELOG(0,1,"ERROR!! Unable to send the message to the Stack [%d] [%s]", 
            ctcap_errno, cTCAPerrorReport);

      if (l_temp != NULL)
      {
         delete []p_tcapBlock->pdata;
         p_tcapBlock->pdata=NULL;
      }
      return false;
   }
   else
   {  
      //printf("\nSent the TCAP request successfully");
   }
   return true;
}




bool MplManager::recvMapMsg(MapMsg *p_MapMsgPtr)
{
   ctblock_t l_DlgBlock;
   memset (&l_DlgBlock, 0, sizeof(ctblock_t));
   ctcap_dp_t l_dp;
   memset (&l_dp, 0, sizeof(ctcap_dp_t));

   switch (((MapMsg*)p_MapMsgPtr)->m_MapMsgType)
   {
      case MAP_MSG_TYPE_COMMON:
         switch (((MapCommonMsg*)p_MapMsgPtr)->m_MapCommonMsgType)
         {
            case MAP_CMN_OPEN_REQ:
               {
                  DLOG(0,1,"MplManager::recvMapMsg MAP_CMN_OPEN_REQ received");
                  int l_newDialogID = p_MapMsgPtr->m_UserDlgId;
                  ///-g_dialogId = l_newDialogID;

                  if (!l_newDialogID)
                  {
                     CLOG(0,0,"MplManager::recvMapMsg Unable to get a new Dialogue from the Stack");
                     return false;
                  }

                  DLOG(0,1,"Allocated the dialog id %d", l_newDialogID);
                  (g_DlgContexts+l_newDialogID)->reset();
                  (g_DlgContexts+l_newDialogID)->m_DlgType   = DLG_TYPE_APPLICATION_INITIATED;
                  (g_DlgContexts+l_newDialogID)->m_UserDlgId = p_MapMsgPtr->m_UserDlgId;
                  (g_DlgContexts+l_newDialogID)->m_appl_id = applicationID;

                  // Adding for Dialogue Portion

                  MapOpenReq *l_openReq = ((MapOpenReq*)p_MapMsgPtr);

                  if ( ((MAP_AC_CODE_networkFunctionalSs == l_openReq->m_ApplCntxt) ||
                           (MAP_AC_CODE_networkUnstructuredSs == l_openReq->m_ApplCntxt)) 
                        && (MAP_V1 != l_openReq->m_Version)
                     )
                  {
                     LLOG(0,1,"Open Info is set. Setting Dialogue Portion");

                     MAP_DP_DialoguePDU l_dpdu;
                     memset(&l_dpdu, '\0', sizeof(MAP_DP_DialoguePDU));
                     l_dpdu.choice = MAP_DP_map_open_chosen;
                     l_dpdu.u.map_open = l_openReq->m_OpenInfo;

                     unsigned char *l_encodedBuffer=NULL;
                     int l_encodedBufLen=0;

                     int l_result = g_AsnCodecO2.encode(&l_dpdu, MapConstants::getMapDialoguePdu(), &l_encodedBuffer, &l_encodedBufLen);
                     if (l_result != 0)
                     {
                        ELOG(0,1,"ERROR!! Encoding failed [%s]", g_AsnCodecO2.getErrMsg());
                        return false;
                     }
                     else
                     {
                        LLOG_HEX(0,1,"Encoded User Buffer", (char*)l_encodedBuffer, l_encodedBufLen);

                        genericPrintPdu(&g_AsnCodecO2, MapConstants::getMapDialoguePdu(), &l_dpdu,"<<===");
                        memcpy((g_DlgContexts+l_newDialogID)->m_UserInfoToBeSent, l_encodedBuffer, l_encodedBufLen);
                        (g_DlgContexts+l_newDialogID)->m_UserInfoLength = l_encodedBufLen;

                        if (l_encodedBuffer)
                        {
                           free(l_encodedBuffer);
                           l_encodedBuffer=NULL;
                        }
                     }
                  }

                  // End of Addition for Dialogue Portion

                  (g_DlgContexts+l_newDialogID)->m_InitiatingApplCntxt  = l_openReq->m_ApplCntxt;
                  (g_DlgContexts+l_newDialogID)->m_InitiatingMapVersion = l_openReq->m_Version;

                  (g_DlgContexts+l_newDialogID)->m_DlgState = DLG_STATE_WAIT_FOR_USER_REQUESTS;
                  memcpy(&((g_DlgContexts+l_newDialogID)->m_DestAddr), &(l_openReq->m_DestAddr), sizeof(SccpAddress));
                  if( strlen(l_openReq->m_OrigAddr.globalTitle.addressInformation) > 0)
                  {
                     DLOG(0,1,"MAP_OPEN_REQ is defined with Originating Address");
                     memcpy(&((g_DlgContexts+l_newDialogID)->m_CustomizedSelfAddress), &(l_openReq->m_OrigAddr), sizeof(SccpAddress));
                  }
                  else
                  {
                     DLOG(0,1,"MAP_OPEN_REQ is NOT defined with Originating Address");
                     memcpy(&((g_DlgContexts+l_newDialogID)->m_CustomizedSelfAddress), &(g_ConfigData->i_NgConfigData.m_selfAddress), sizeof(SccpAddress));
                  }

                  char l_gt[50];
                  memset(l_gt, '\0', sizeof(l_gt));
                  GetNetworkHlrAddr((u8*)l_gt,(u8*)( (g_DlgContexts+l_newDialogID)->m_CustomizedSelfAddress.globalTitle.addressInformation));
                  L_SccpAddress *l_sccp=&((g_DlgContexts+l_newDialogID)->m_CustomizedSelfAddress);
                  //configureSccpAddress(l_sccp, l_sccp->addressIndicator.routingIndicator,
                  //      l_sccp->pointCode.c7pointCode.value,
                  //      l_sccp->ssn, l_gt);
                  configureSccpAddress(l_sccp, 0, 0, l_sccp->ssn, l_gt);
               }
               break;

            case MAP_CMN_DELIMITER_REQ:
               {
                  DLOG(0,1,"MplManager::recvMapMsg MAP_CMN_DELIMITER_REQ received");

                  ///-if (0 == p_MapMsgPtr->m_DlgId)
                  ///-{
                  ///-   ELOG(0,1,"Ignoring delimiter with dialogid 0");
                  ///-   return false;
                  ///-}

                  if (0 == p_MapMsgPtr->m_UserDlgId)
                  {
                     ELOG(0,1,"Ignoring delimiter with dialogid 0");
                     return false;
                  }

                  if (DLG_TYPE_NETWORK_INITIATED == (g_DlgContexts+ p_MapMsgPtr->m_UserDlgId)->m_DlgType)
                  {
                     if(g_OtherConfigData->m_PreserveSccpClass)
                     {
                        DLOG(0,1,"Preserving SCCP Class for incoming dialogue");
                        l_DlgBlock.tcu.dhp.qlty_of_svc = (g_DlgContexts+p_MapMsgPtr->m_UserDlgId)->m_IncomingSccpClass;
                     }
                  }

                  //Override SCCP Class to 1 for Messages exchanged with Not Last Components
                  if(true == (g_DlgContexts+p_MapMsgPtr->m_UserDlgId)->m_NotLastCompExchanged)
                  {
                     l_DlgBlock.tcu.dhp.qlty_of_svc = CL_SVC_CLASS_1|RETURN_ERROR;
                  }

                  // Added to see if the Response time, HLR GT is going or not
                  L_SccpAddress l_origAddr;
                  memset(&l_origAddr, '\0', sizeof(L_SccpAddress));
                  if( 2 == (g_DlgContexts+p_MapMsgPtr->m_UserDlgId)->m_CustomizedSelfAddress.addressIndicator.routingIndicator)
                  {
                     (g_DlgContexts+p_MapMsgPtr->m_UserDlgId)->m_CustomizedSelfAddress=getSelfAddress((g_DlgContexts+ p_MapMsgPtr->m_UserDlgId)->m_tmp_local_address);
                  }
                  l_origAddr = ((g_DlgContexts+p_MapMsgPtr->m_UserDlgId)->m_CustomizedSelfAddress);//g_ConfigData->i_NgConfigData.m_selfAddress;
                  encodeSccpAddress(l_DlgBlock.tcu.dhp.local_address, (SccpAddress*)(&l_origAddr));
                  //End of Addition

                  if (DLG_STATE_WAIT_FOR_USER_REQUESTS == (g_DlgContexts+ p_MapMsgPtr->m_UserDlgId)->m_DlgState)
                  {
                     DLOG(0,1,"Sending delimiter in DLG_STATE_WAIT_FOR_USER_REQUESTS state");

                     l_DlgBlock.prim_code = TC_BEGIN;
                     l_DlgBlock.dialog_id = p_MapMsgPtr->m_UserDlgId;
                     l_DlgBlock.appl_id = applicationID;
                     (g_DlgContexts+ p_MapMsgPtr->m_UserDlgId)->m_crossedNg=true;

                     StatisticsInterface::logInitiatingApplCtxtTotal((g_DlgContexts+ p_MapMsgPtr->m_UserDlgId)->m_InitiatingApplCntxt, 
                           (g_DlgContexts+ p_MapMsgPtr->m_UserDlgId)->m_InitiatingMapVersion);

                     encodeSccpAddress(l_DlgBlock.tcu.dhp.remote_address, &((g_DlgContexts+ p_MapMsgPtr->m_UserDlgId)->m_DestAddr));

                     if (MAP_V1 != (g_DlgContexts+ p_MapMsgPtr->m_UserDlgId)->m_InitiatingMapVersion)
                     {
                        memset(&l_dp, '\0', sizeof(l_dp));
                        l_DlgBlock.tcu.dhp.dp_present_ind = 1; 
                        l_DlgBlock.tcu.dhp.pdp = &l_dp;

                        l_dp.application_context_name.length = 8;
                        l_dp.application_context_name.value[0] = 0x00;
                        l_dp.application_context_name.value[1] = 0x04;
                        l_dp.application_context_name.value[2] = 0x00;
                        l_dp.application_context_name.value[3] = 0x00;
                        l_dp.application_context_name.value[4] = 0x01;
                        l_dp.application_context_name.value[5] = 0x00;
                        l_dp.application_context_name.value[6] = (g_DlgContexts+ p_MapMsgPtr->m_UserDlgId)->m_InitiatingApplCntxt;
                        l_dp.application_context_name.value[7] = (g_DlgContexts+ p_MapMsgPtr->m_UserDlgId)->m_InitiatingMapVersion;

                        //printf("\nUser Info Present in the request [%d]", (g_DlgContexts+ p_MapMsgPtr->m_DlgId)->m_UserInfoLength);

                        if((g_DlgContexts+ p_MapMsgPtr->m_UserDlgId)->m_UserInfoLength)
                        {
                           l_dp.user_information_length = 1;
                           l_dp.user_information[0].bit_mask = ASN1_DIRECT_REFERENCE_PRESENT;
                           /*
                              l_dp.user_information[0].indirect_reference = 1024;
                              */
                           l_dp.user_information[0].direct_reference.length = 8;
                           l_dp.user_information[0].direct_reference.value[0] = 0x00;
                           l_dp.user_information[0].direct_reference.value[1] = 0x04;
                           l_dp.user_information[0].direct_reference.value[2] = 0x00;
                           l_dp.user_information[0].direct_reference.value[3] = 0x00;
                           l_dp.user_information[0].direct_reference.value[4] = 0x01;
                           l_dp.user_information[0].direct_reference.value[5] = 0x01;
                           l_dp.user_information[0].direct_reference.value[6] = 0x01;
                           l_dp.user_information[0].direct_reference.value[7] = 0x01;
                           l_dp.user_information[0].encoding_scheme = ASN1_ANY_ENCODING_SCHEME;
                           l_dp.user_information[0].encoding.octet_aligned.length = (g_DlgContexts+ p_MapMsgPtr->m_UserDlgId)->m_UserInfoLength;
                           memcpy(l_dp.user_information[0].encoding.octet_aligned.value,
                                 (g_DlgContexts+ p_MapMsgPtr->m_UserDlgId)->m_UserInfoToBeSent,
                                 (g_DlgContexts+ p_MapMsgPtr->m_UserDlgId)->m_UserInfoLength);
                        }
                     }

                     (g_DlgContexts+ p_MapMsgPtr->m_UserDlgId)->m_DlgState = DLG_STATE_DLG_INITIATED;
                  }
                  else
                  {
                     l_DlgBlock.prim_code = TC_CONTINUE;
                     l_DlgBlock.dialog_id = p_MapMsgPtr->m_UserDlgId;
                     l_DlgBlock.appl_id = (g_DlgContexts+ p_MapMsgPtr->m_UserDlgId)->m_appl_id;

                     if (DLG_TYPE_NETWORK_INITIATED == (g_DlgContexts+ p_MapMsgPtr->m_UserDlgId)->m_DlgType)
                     {
                        memcpy(l_DlgBlock.tcu.dhp.remote_address, (g_DlgContexts+ p_MapMsgPtr->m_UserDlgId)->m_tmp_remote_address, MAX_ADDR_LEN);
                     }
                     else
                     {
                        memcpy(l_DlgBlock.tcu.dhp.remote_address, (g_DlgContexts+ p_MapMsgPtr->m_UserDlgId)->m_tmp_remote_address, MAX_ADDR_LEN);
                        //encodeSccpAddress(l_DlgBlock.tcu.dhp.remote_address, &((g_DlgContexts+ p_MapMsgPtr->m_UserDlgId)->m_DestAddr));
                     }

                     prepareDlgPortion(p_MapMsgPtr->m_UserDlgId, &l_DlgBlock, &l_dp);
                     l_DlgBlock.tcu.dhp.pdp = &l_dp;
                  }

                  sendToTcapStack(&l_DlgBlock);
               }
               break;

            case MAP_CMN_CLOSE_REQ:
               DLOG(0,1,"MplManager::recvMapMsg MAP_CMN_CLOSE_REQ received state[%d]",
                     (g_DlgContexts+ p_MapMsgPtr->m_UserDlgId)->m_DlgState);
               l_DlgBlock.prim_code = TC_END;
               l_DlgBlock.dialog_id = p_MapMsgPtr->m_UserDlgId;
               l_DlgBlock.appl_id = (g_DlgContexts+ p_MapMsgPtr->m_UserDlgId)->m_appl_id;
               //l_DlgBlock.tcu.dhp.qlty_of_svc = CL_SVC_CLASS_1|RETURN_ERROR; //added on 28jan

               // Added to see if the Response time, HLR GT is going or not
               L_SccpAddress l_origAddr;
               memset(&l_origAddr, '\0', sizeof(L_SccpAddress));
               if( 2 == (g_DlgContexts+p_MapMsgPtr->m_UserDlgId)->m_CustomizedSelfAddress.addressIndicator.routingIndicator)
               {
                  (g_DlgContexts+p_MapMsgPtr->m_UserDlgId)->m_CustomizedSelfAddress=getSelfAddress((g_DlgContexts+ p_MapMsgPtr->m_UserDlgId)->m_tmp_local_address);
               }
               l_origAddr = ((g_DlgContexts+p_MapMsgPtr->m_UserDlgId)->m_CustomizedSelfAddress);//g_ConfigData->i_NgConfigData.m_selfAddress;
               encodeSccpAddress(l_DlgBlock.tcu.dhp.local_address, (SccpAddress*)(&l_origAddr));

               //End of Addition

               if (DLG_TYPE_NETWORK_INITIATED == (g_DlgContexts+ p_MapMsgPtr->m_UserDlgId)->m_DlgType)
               {
                  memcpy(l_DlgBlock.tcu.dhp.remote_address, (g_DlgContexts+ p_MapMsgPtr->m_UserDlgId)->m_tmp_remote_address, MAX_ADDR_LEN);
               }

               l_DlgBlock.tcu.dhp.dialog_term_type = BASIC_TERMINATE;
               if (MAP_CLOSE_TYPE_UNKNOWN != ((MapCloseReq*)p_MapMsgPtr)->m_CloseType)
               {
                  l_DlgBlock.tcu.dhp.dialog_term_type = (int)(((MapCloseReq*)p_MapMsgPtr)->m_CloseType);
               }
               if (MAP_CLOSE_TYPE_PRE_ARRANGED_END == ((MapCloseReq*)p_MapMsgPtr)->m_CloseType)
               {
                  if(MAP_CLOSE_PRE_ARRANGED_REASON_FAILURE == (((MapCloseReq*)p_MapMsgPtr)->m_PreArrangedReason))
                  {
                     (g_DlgContexts+p_MapMsgPtr->m_UserDlgId)->m_ErrorExchangedFlag = true; //Added on 6-Jan-2020 not to count as success
                     logOtherErrorCodeStats(p_MapMsgPtr->m_UserDlgId, OTHER_ERROR_CODE_SENT_PRE_ARRANGED_END);
                  }
               }
               /*
                  if (DLG_TYPE_NETWORK_INITIATED != (g_DlgContexts+ p_MapMsgPtr->m_UserDlgId)->m_DlgType)
                  {
                  l_DlgBlock.tcu.dhp.dialog_term_type = PRE_ARRANGED_TERMINATE;
                  }
                  */


               if(true == (g_DlgContexts+p_MapMsgPtr->m_UserDlgId)->m_NotLastCompExchanged)
               {
                  l_DlgBlock.tcu.dhp.qlty_of_svc = CL_SVC_CLASS_1|RETURN_ERROR;
               }

               if (BASIC_TERMINATE == l_DlgBlock.tcu.dhp.dialog_term_type)
               {
                  prepareDlgPortion(p_MapMsgPtr->m_UserDlgId, &l_DlgBlock, &l_dp);
                  l_DlgBlock.tcu.dhp.pdp = &l_dp;
               }
               sendToTcapStack(&l_DlgBlock);
               if (DLG_TYPE_APPLICATION_INITIATED == (g_DlgContexts+l_DlgBlock.dialog_id)->m_DlgType)
               {
                  if (RETURNerror == cTCAPReleaseDialogId(l_DlgBlock.dialog_id))
                  {
                     ELOG(0,1,"cTCAPReleaseDialogId Unable to release the dialog ID %d", l_DlgBlock.dialog_id);
                  }
                  else
                  {
                     DLOG(0,1,"cTCAPReleaseDialogId Released the dialog ID %d", l_DlgBlock.dialog_id);
                  }
               }

               // Log Statistics
               logSuccessDialogue(l_DlgBlock.dialog_id);
               // End of Log Statistics

               break;

            case MAP_CMN_U_ABORT_REQ:
               logOtherErrorCodeStats(p_MapMsgPtr->m_UserDlgId, OTHER_ERROR_CODE_SENT_PRIMITIVE_GENERAL_U_ABORT);
               CLOG(0,1,"MplManager::recvMapMsg MAP_CMN_U_ABORT_REQ received");
               if (DLG_TYPE_NETWORK_INITIATED == (g_DlgContexts+ p_MapMsgPtr->m_UserDlgId)->m_DlgType)
               {
                  memcpy(l_DlgBlock.tcu.dhp.remote_address, (g_DlgContexts+ p_MapMsgPtr->m_UserDlgId)->m_tmp_remote_address, MAX_ADDR_LEN);
               }
               if(0 == ((MapUAbortReq*)p_MapMsgPtr)->m_versionRejected)
               {
                  sendAbort(p_MapMsgPtr->m_UserDlgId, ((MapUAbortReq*)p_MapMsgPtr)->m_AbortCause, ((MapUAbortReq*)p_MapMsgPtr)->m_AbortReason);
               }
               else
               {
                  sendAbort(p_MapMsgPtr->m_UserDlgId, DP_UNREC_MESSAGE, ABRT_APPLICATION_CONTEXT_NOT_SUPPORTED, ((MapUAbortReq*)p_MapMsgPtr)->m_versionRejected);
               }
               break;

            case MAP_CMN_OPEN_RSP:
               DLOG(0,1,"MplManager::recvMapMsg MAP_CMN_OPEN_RSP received");
               if(false == ((MapOpenRsp*)p_MapMsgPtr)->m_ResponseChoiceFlag)
               {
                  (g_DlgContexts+p_MapMsgPtr->m_UserDlgId)->m_crossedNg=false;  //This message has reached till ServiceCoordinator but rejected again.
                  setError(p_MapMsgPtr->m_UserDlgId, DLG_APPL_REJECTION);
                  sendAbort(p_MapMsgPtr->m_UserDlgId, DP_UNREC_MESSAGE, ABRT_NOT_PRESENT);
               }
               else
               {
                  if(strlen( ((MapOpenRsp*)p_MapMsgPtr)->m_OrigAddr.globalTitle.addressInformation) > 0)
                  {
                     DLOG(0,1,"MAP_OPEN_RSP is defined with Originating Address");
                     memcpy(&((g_DlgContexts+p_MapMsgPtr->m_UserDlgId)->m_CustomizedSelfAddress), &(((MapOpenRsp*)p_MapMsgPtr)->m_OrigAddr), sizeof(SccpAddress));
                  }
                  else
                  {
                     ELOG(0,1,"MAP_OPEN_RSP is NOT defined with Originating Address");

                     //memcpy(&((g_DlgContexts+p_MapMsgPtr->m_UserDlgId)->m_CustomizedSelfAddress), &(g_ConfigData->i_NgConfigData.m_selfAddress), sizeof(SccpAddress));
                     memcpy(&((g_DlgContexts+p_MapMsgPtr->m_UserDlgId)->m_CustomizedSelfAddress), &(getSelfAddress(l_DlgBlock.tcu.dhp.remote_address)), sizeof(SccpAddress));
                  }

               }
               break;

            default:
               ELOG(0,1,"MplManager::recvMapMsg Unknown Msg received");
               break;

         }
         break;

      case MAP_MSG_TYPE_SPECIFIC:

         if (p_MapMsgPtr->m_UserDlgId == 0)
         {
            LLOG(0,1,"Ignoring Specific Msg with dialog id 0");
            return false;
         }

         switch (((MapSpecificMsg*)p_MapMsgPtr)->m_MapSpecificEventType)
         {
            case MAP_SPEC_EVENT_REQUEST:
               {
                  DLOG(0,1,"MplManager::recvMapMsg MAP_SPEC_EVENT_REQUEST received");

                  ctblock_t l_request;
                  memset (&l_request, 0, sizeof(l_request));

                  l_request.prim_code   = TC_INVOKE;
                  l_request.dialog_id   = p_MapMsgPtr->m_UserDlgId;
                  l_request.appl_id     = applicationID;

                  EMapOpCode l_opCode = ((MapSpecificMsg*)p_MapMsgPtr)->m_OpCode;

                  if (DLG_TYPE_APPLICATION_INITIATED == (g_DlgContexts+l_request.dialog_id)->m_DlgType)
                  {
                     (g_DlgContexts+l_request.dialog_id)->m_InitiatingOpCode = l_opCode;
                     StatisticsInterface::logInitiatingOpCodeTotal(l_opCode, 
                           (g_DlgContexts+l_request.dialog_id)->m_InitiatingMapVersion);
                  }

                  list<reportData> :: iterator l_it;
                  for(l_it = g_OtherConfigData->m_reportDataList.begin(); l_it!=g_OtherConfigData->m_reportDataList.end(); l_it++)
                  {
                     char l_opcodeChar[4 + 1];
                     memset(l_opcodeChar, '\0', sizeof(l_opcodeChar));
                     snprintf(l_opcodeChar, sizeof(l_opcodeChar)+1, ",%02d,", l_opCode);
                     size_t l_found = l_it->m_opCodes.find(l_opcodeChar);
                     if(l_found != string::npos)
                     {
                        if (DLG_TYPE_APPLICATION_INITIATED == (g_DlgContexts+l_request.dialog_id)->m_DlgType)
                        {
                           string l_remoteGT((g_DlgContexts+l_request.dialog_id)->m_DestAddr.globalTitle.addressInformation);
                           DLOG(0,0,"Remote GT while initiating is %s and GT from config file is %s",l_remoteGT.c_str(),l_it->m_GTs.c_str());
                           if(l_remoteGT.rfind(l_it->m_GTs.c_str(),0) == 0)
                              //size_t l_pos = l_remoteGT.find(l_it->m_GTs.c_str());
                              //if(l_pos != string::npos)
                           {
                              DLOG(0,0,"In InitiatingTot GT matched, index while calling logstatistics is %d",l_it->m_InitiatingOpCodesIndices[l_opCode].m_TotalCountGTMat[(g_DlgContexts+l_request.dialog_id)->m_InitiatingMapVersion - 1]);
                              HLRStatisticsInitializer::logStatistics(l_it->m_InitiatingOpCodesIndices[l_opCode].m_TotalCountGTMat[(g_DlgContexts+l_request.dialog_id)->m_InitiatingMapVersion - 1]);
                           }
                           else
                           {
                              DLOG(0,0,"In InitiatingTot GT Not matched, index while calling logstatistics is %d",l_it->m_InitiatingOpCodesIndices[l_opCode].m_TotalCountGTNotMat[(g_DlgContexts+l_request.dialog_id)->m_InitiatingMapVersion - 1]);
                              HLRStatisticsInitializer::logStatistics(l_it->m_InitiatingOpCodesIndices[l_opCode].m_TotalCountGTNotMat[(g_DlgContexts+l_request.dialog_id)->m_InitiatingMapVersion - 1]);
                           }
                        } 
                     }
                  }


                  if(1 == MapConstants::getMapOpCodeConfFlag(l_opCode))
                  {
                     //printf("\nOpCode [%d] is NOT a confirmed operation", l_opCode);
                     l_request.tcu.chp.class_of_oper = CLASS_4;
                  }
                  else
                  {
                     //printf("\nOpCode [%d] is a confirmed operation", l_opCode);
                     l_request.tcu.chp.class_of_oper = CLASS_1;
                  }

                  int l_AppTimerValue = ((MapSpecificRequest*)p_MapMsgPtr)->m_TimerValue;
                  if (l_AppTimerValue)
                  {
                     // Timer value is set by the application. 
                     // Checking the limits and setting accordingly

                     if (l_AppTimerValue > MapConstants::getMapOpCodeMaxTime(l_opCode))
                     {
                        //printf("\nSetting the Max Timer value possible for this operation...");
                        l_request.tcu.chp.timer_value = MapConstants::getMapOpCodeMaxTime(l_opCode);
                     }
                     else if(l_AppTimerValue < MapConstants::getMapOpCodeMinTime(l_opCode))
                     {
                        //printf("\nSetting the Max Timer value possible for this operation...");
                        l_request.tcu.chp.timer_value = MapConstants::getMapOpCodeMinTime(l_opCode);
                     }
                     else
                     {
                        //printf("\nSetting the Application specified Timer value for this operation...");
                        l_request.tcu.chp.timer_value = l_AppTimerValue;
                     }
                  }
                  else
                  {
                     //printf("\nAppl Not set the Timer value. Setting the Max Timer value for this operation...");
                     // Timer value is not set by the application. So setting the maximum allowed value for the operation
                     l_request.tcu.chp.timer_value = MapConstants::getMapOpCodeMaxTime(l_opCode);
                  }

                  if (0 ==  ((MapSpecificMsg*)p_MapMsgPtr)->m_InvokeId)
                  {
                     //printf("\nGetting New Invoke Id...");
                     l_request.tcu.chp.invoke_id = (g_DlgContexts+ p_MapMsgPtr->m_UserDlgId)->getNextInvokeId();
                  }
                  else
                  {
                     LLOG(0,1,"Putting Invoke Id from msg...");
                     l_request.tcu.chp.invoke_id = ((MapSpecificMsg*)p_MapMsgPtr)->m_InvokeId;
                  }
                  (g_DlgContexts+l_request.dialog_id)->m_rsm.m_OpCode = l_opCode;
                  (g_DlgContexts+l_request.dialog_id)->m_rsm.m_InvokeId = l_request.tcu.chp.invoke_id;

                  if (((MapSpecificRequest*)p_MapMsgPtr)->m_LinkedId)
                  {
                     l_request.tcu.chp.linked_id = ((MapSpecificRequest*)p_MapMsgPtr)->m_LinkedId;
                  }
                  else
                  {
                     l_request.tcu.chp.linked_id = -1;
                  }


                  l_request.tcu.chp.last_comp_ind = LAST_COMP;
                  int l_compBufSize = 3 + ((MapSpecificMsg*)p_MapMsgPtr)->m_bufLen;

                  if (((MapSpecificMsg*)p_MapMsgPtr)->m_bufLen)
                  {
                     l_request.data_len = l_compBufSize;
                     l_request.pdata = new unsigned char[l_compBufSize];
                     l_request.pdata[0] = CP_OC_LOCAL; /* opcode tag 0x20 */
                     l_request.pdata[1] = 1; /* opCode Length */
                     l_request.pdata[2] = ((MapSpecificMsg*)p_MapMsgPtr)->m_OpCode;
                     memcpy(&l_request.pdata[3], 
                           &(((MapSpecificMsg*)p_MapMsgPtr)->m_buffer), 
                           ((MapSpecificMsg*)p_MapMsgPtr)->m_bufLen);
                  }
                  else
                  {
                     l_request.data_len = 3;
                     l_request.pdata = new unsigned char[5];
                     l_request.pdata[0] = CP_OC_LOCAL; /* opcode tag 0x20*/
                     l_request.pdata[1] = 1; /* opCode Length */
                     l_request.pdata[2] = ((MapSpecificMsg*)p_MapMsgPtr)->m_OpCode; /* opCode Value */
                     l_request.pdata[3] = 0x30;
                  }
                  sendToTcapStack(&l_request);
               }
               break;

            case MAP_SPEC_EVENT_RESULT:
               {
                  DLOG(0,1,"MplManager::recvMapMsg MAP_SPEC_EVENT_RESULT received");

                  ctblock_t l_result;
                  memset (&l_result, 0, sizeof(l_result));

                  if (((MapSpecificResult*)p_MapMsgPtr)->m_LastFlag)
                  {
                     l_result.prim_code   = TC_RESULT_L;
                  }
                  else
                  {
                     l_result.prim_code   = TC_RESULT_NL;
                     (g_DlgContexts+ p_MapMsgPtr->m_UserDlgId)->m_NotLastCompExchanged=true;
                  }

                  l_result.dialog_id   = p_MapMsgPtr->m_UserDlgId;
                  l_result.appl_id     = (g_DlgContexts+ p_MapMsgPtr->m_UserDlgId)->m_appl_id;
                  l_result.tcu.chp.class_of_oper = 0;
                  l_result.tcu.chp.invoke_id = (g_DlgContexts+ p_MapMsgPtr->m_UserDlgId)->m_psm.m_InvokeId;
                  l_result.tcu.chp.linked_id = -1;
                  l_result.tcu.chp.last_comp_ind = LAST_COMP;

                  int l_compBufSize=0;
                  if (((MapSpecificMsg*)p_MapMsgPtr)->m_bufLen)
                  {
                     l_compBufSize = 5 + ((MapSpecificMsg*)p_MapMsgPtr)->m_bufLen;
                  }
                  else
                  {
                     l_compBufSize = 7;
                  }

                  //printf("\nResult Data Length [%d] Comp Data Length [%d]", ((MapSpecificMsg*)p_MapMsgPtr)->m_bufLen, l_compBufSize);

                  l_result.pdata = new unsigned char[l_compBufSize + 1];
                  //l_result.pdata = new unsigned char[10];
                  l_result.pdata[0] = CP_SEQ; /* Sequence tag 0x30 */
                  int l_nextIndex=0;
                  if(l_compBufSize > 0x7F)
                  {
                     LLOG(0,0,"CompBufSize:%02x is greater than 0x7F. Hence putting length in 2 bytes", l_compBufSize);
                     l_result.data_len = l_compBufSize+1;
                     l_result.pdata[1] = 0x81;
                     l_result.pdata[2] = l_compBufSize-2;
                     l_nextIndex=3;
                  }
                  else
                  {
                     LLOG(0,0,"CompBufSize:%02x is not greater than 0x7F. Hence putting length in 1 byte",l_compBufSize);
                     l_result.data_len = l_compBufSize;
                     l_result.pdata[1] = l_compBufSize-2;
                     l_nextIndex=2;
                  }
                  l_result.pdata[l_nextIndex++] = CP_OC_LOCAL; /* opCode Tag 0x20*/
                  l_result.pdata[l_nextIndex++] = 1; /* opCode Length */
                  l_result.pdata[l_nextIndex++] = (g_DlgContexts+ p_MapMsgPtr->m_UserDlgId)->m_psm.m_OpCode; /* opCode Value */

                  if (((MapSpecificMsg*)p_MapMsgPtr)->m_bufLen)
                  {
                     memcpy(&l_result.pdata[l_nextIndex++], 
                           &(((MapSpecificMsg*)p_MapMsgPtr)->m_buffer), 
                           ((MapSpecificMsg*)p_MapMsgPtr)->m_bufLen);
                  }
                  else
                  {
                     l_result.pdata[5] = 0x30;
                     l_result.pdata[6] = 0x00;
                  }

                  sendToTcapStack(&l_result);
               }
               break;

            case MAP_SPEC_EVENT_USER_ERROR:
               LLOG(0,1,"MplManager::recvMapMsg MAP_SPEC_EVENT_USER_ERROR received");

               ctblock_t l_error;
               memset (&l_error, 0, sizeof(l_error));

               l_error.prim_code   = TC_U_ERROR;
               l_error.dialog_id   = p_MapMsgPtr->m_UserDlgId;
               l_error.appl_id     = (g_DlgContexts+ p_MapMsgPtr->m_UserDlgId)->m_appl_id;
               l_error.tcu.chp.class_of_oper = 0;
               l_error.tcu.chp.invoke_id = (g_DlgContexts+ p_MapMsgPtr->m_UserDlgId)->m_psm.m_InvokeId;
               l_error.tcu.chp.linked_id = -1;
               l_error.tcu.chp.last_comp_ind = LAST_COMP;
               (g_DlgContexts+ p_MapMsgPtr->m_UserDlgId)->m_ErrorExchangedFlag = true;
               (g_DlgContexts+ p_MapMsgPtr->m_UserDlgId)->m_ErrorCodeExchanged = ((MapUserError*)p_MapMsgPtr)->m_ErrorCode;

               if (NULL == ((MapUserError*)p_MapMsgPtr)->m_structBuffer)
               {
                  l_error.data_len = 3;

                  l_error.pdata = new unsigned char[3];
                  l_error.pdata[0] = CP_EC_LOCAL; /* Error Code tag */
                  l_error.pdata[1] = 1;
                  l_error.pdata[2] = ((MapUserError*)p_MapMsgPtr)->m_ErrorCode; /* Error Code */
               }
               else
               {
                  int l_len = ((MapSpecificMsg*)p_MapMsgPtr)->m_bufLen;

                  l_error.data_len = 3 + l_len;

                  l_error.pdata = new unsigned char[3+l_len];
                  l_error.pdata[0] = CP_EC_LOCAL; /* Error Code tag */
                  l_error.pdata[1] = 1;
                  l_error.pdata[2] = ((MapUserError*)p_MapMsgPtr)->m_ErrorCode; /* Error Code */
                  memcpy(&(l_error.pdata[3]), ((MapSpecificMsg*)p_MapMsgPtr)->m_buffer, l_len);
               }

               sendToTcapStack(&l_error);

               break;

            case MAP_SPEC_EVENT_PROV_ERROR:
               {
                  MapProviderErrorMsg *l_pem = (MapProviderErrorMsg*)p_MapMsgPtr;
                  ctblock_t l_reject;
                  memset(&l_reject, '\0', sizeof(l_reject));
                  if(MAP_PROV_ERROR_REJECT_TYPE_R_REJECT == l_pem->m_rejectType)
                  {
                     l_reject.prim_code = TC_R_REJECT;
                  }
                  else if(MAP_PROV_ERROR_REJECT_TYPE_U_REJECT == l_pem->m_rejectType)
                  {
                     l_reject.prim_code = TC_U_REJECT;
                  }
                  else
                  {
                     l_reject.prim_code = TC_U_REJECT;
                  }

                  prepareReject(l_pem->m_UserDlgId, l_pem->m_InvokeId, &l_reject, l_pem->m_problemType, l_pem->m_problemCode);
                  sendToTcapStack(&l_reject);
                  DLOG(0,1,"MplManager::recvMapMsg MAP_SPEC_EVENT_PROV_ERROR received");
               }
               break;

            default:
               DLOG(0,1,"MplManager::recvMapMsg Unknown Specific Msg received");
               break;
         }
         break;

      default:
         DLOG(0,1,"MplManager::recvMapMsg UNKNOWN received");
         break;
   }
   return true;
}

