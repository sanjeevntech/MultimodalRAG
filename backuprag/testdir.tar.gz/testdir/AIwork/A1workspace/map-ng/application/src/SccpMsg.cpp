#include <SccpMsg.h>
#include <Logger.h>

SccpMsg::SccpMsg() : Msg(MSG_TYPE_SCCP)
{
 DLOG(0,0,"CONS:");
 memset(m_callingParty,'\0',sizeof(m_callingParty));
 memset(m_calledParty,'\0',sizeof(m_calledParty));
 memset(m_Msisdn,'\0',sizeof(m_Msisdn));
 m_allocatedFlag = false;
}

SccpMsg::~SccpMsg()
{
 DLOG(0,0,"DES:");
 if(NULL != m_sblockIn)
 {
  DLOG(0,0,"Destructor sblock deleting.");
  free(m_sblockIn);
  m_sblockIn = NULL;
 }
}

