#include <MapMessages.h>
#include <Logger.h>


#include <apiinc.h>
#include <tcap.h>
#include <tcerror.h>
#include <sccp-addr.h>
#include <ServiceCoordinator.h>


char g_MapSpecificEventType[20][30] = 
{
  "MAP_SPEC_EVENT_UNKNOWN",
  "MAP_SPEC_EVENT_REQUEST",
  "MAP_SPEC_EVENT_INDICATION",
  "MAP_SPEC_EVENT_RESULT",
  "MAP_SPEC_EVENT_CONFIRMATION",
  "MAP_SPEC_EVENT_USER_ERROR",
  "MAP_SPEC_EVENT_PROV_ERROR"
};


char g_MapCommonMsgType[20][30] = 
{
  "MAP_CMN_UNKNOWN",
  "MAP_CMN_OPEN_REQ",
  "MAP_CMN_OPEN_IND",
  "MAP_CMN_OPEN_RSP",
  "MAP_CMN_OPEN_CNF",
  "MAP_CMN_CLOSE_REQ",
  "MAP_CMN_CLOSE_IND",
  "MAP_CMN_DELIMITER_REQ",
  "MAP_CMN_DELIMITER_IND",
  "MAP_CMN_U_ABORT_REQ",
  "MAP_CMN_U_ABORT_IND",
  "MAP_CMN_P_ABORT_REQ",
  "MAP_CMN_P_ABORT_IND",
  "MAP_CMN_NOTICE_IND"
};


MapMsg::MapMsg() : Msg(MSG_TYPE_MAP)
{
  m_UserDlgId     = 0;
  ///-m_DlgId         = 0;
  m_MapMsgType    = MAP_MSG_TYPE_UNKNOWN;  
  m_Version       = MAP_V_UNKNOWN;
}

MapMsg::MapMsg(EMapMsgType p_MapMsgType, EMapVersion p_Version = MAP_V3) : Msg(MSG_TYPE_MAP)
{
  MapMsg();
  m_MapMsgType = p_MapMsgType;
  m_Version    = p_Version;
}

MapMsg::~MapMsg()
{
}


char *MapMsg::getMsgTypeName()
{
	switch (m_MapMsgType)
	{
		case MAP_MSG_TYPE_UNKNOWN:
			return "Unknown";
			break;

		case MAP_MSG_TYPE_COMMON:
			return ((MapCommonMsg*)this)->getMapCommonMsgTypeName();
			break;

		case MAP_MSG_TYPE_SPECIFIC:
			return "SPECIFIC";
			break;

		default:
			return "Unknown";
			break;
	} 
}


char *MapCommonMsg::getMapCommonMsgTypeName()
{
  return g_MapCommonMsgType[(int)m_MapCommonMsgType-200];
}


MapCommonMsg::MapCommonMsg() : MapMsg(MAP_MSG_TYPE_COMMON)
{
  m_MapCommonMsgType = MAP_CMN_UNKNOWN;
}

MapCommonMsg::MapCommonMsg(EMapCommonMsgType p_MapCommonMsgType) : MapMsg(MAP_MSG_TYPE_COMMON)
{
  MapCommonMsg();
  m_MapCommonMsgType = p_MapCommonMsgType;
}

MapCommonMsg::~MapCommonMsg()
{
}


char *MapSpecificMsg::getMapSpecifigEventTypeName()
{
  return g_MapSpecificEventType[(int)m_MapSpecificEventType];
}

MapSpecificMsg::MapSpecificMsg() : MapMsg(MAP_MSG_TYPE_SPECIFIC)
{
  m_MapSpecificEventType  = MAP_SPEC_EVENT_UNKNOWN; 
  m_structBuffer = NULL;
  m_InvokeId=0;
  m_bufLen=0;
  m_allocatedFlag=false;
  memset(m_buffer, '\0', sizeof(m_buffer));
  memset(m_extensionContainerBuffer, '\0', sizeof(m_extensionContainerBuffer));
  m_ioflag='U'; //Unknown
}

MapSpecificMsg::MapSpecificMsg(EMapSpecificEventType p_MapSpecificEventType,EMapVersion p_MapVersion)
	: MapMsg(MAP_MSG_TYPE_SPECIFIC, p_MapVersion)
{
  m_MapSpecificEventType  = p_MapSpecificEventType;
  m_InvokeId=0;
  m_structBuffer = NULL;
  m_bufLen=0;
  m_allocatedFlag=false;
  memset(m_buffer, '\0', sizeof(m_buffer));
  memset(m_extensionContainerBuffer, '\0', sizeof(m_extensionContainerBuffer));
  m_ioflag='U'; //Unknown
 }

MapSpecificMsg::~MapSpecificMsg()
{
    DLOG(0,1,"MapSpecificMsg calling freeMemory");
    freeMemory(this);
}


MapSpecificRequest::MapSpecificRequest(int p_UserDlgId, EMapOpCode p_OpCode, EMapVersion p_version) :MapSpecificMsg(MAP_SPEC_EVENT_REQUEST, MAP_V_UNKNOWN)
{
	m_OpCode = p_OpCode;
	m_UserDlgId = p_UserDlgId;
	m_Version = p_version;
	m_InvokeId=0;
	m_LinkedId=-1;
	m_TimerValue=0;
   m_bufLen=0;
   m_ioflag='O'; //Defaulted to OMAP
}

MapSpecificRequest::~MapSpecificRequest()
{

}

MapSpecificIndication::MapSpecificIndication(EMapOpCode p_OpCode) :MapSpecificMsg(MAP_SPEC_EVENT_INDICATION, MAP_V_UNKNOWN)
{
   DLOG(0,1,"MapSpecificIndication :cons:");
	m_OpCode = p_OpCode;
   m_ioflag='I'; //Defaulted to IMAP
   m_lci = MAP_SPEC_LAST_COMPONENT_IND_UNKNOWN;

}

MapSpecificIndication::~MapSpecificIndication()
{
   DLOG(0,1,"MapSpecificIndication :des:");

}

MapSpecificResult::MapSpecificResult(int p_UserDlgId, EMapOpCode p_OpCode, EMapVersion p_version) :MapSpecificMsg(MAP_SPEC_EVENT_RESULT, MAP_V_UNKNOWN)
{
   DLOG(0,1,"MapSpecificResult :cons:");
	m_OpCode = p_OpCode;
	m_UserDlgId = p_UserDlgId;
	m_Version = p_version;
	m_LastFlag=true;
   m_bufLen=0;
   m_ioflag='O'; //Defaulted to OMAP
}

MapSpecificResult::~MapSpecificResult()
{
   DLOG(0,1,"MapSpecificResult :des:");

}

MapSpecificConfirmation::MapSpecificConfirmation(EMapOpCode p_OpCode) :MapSpecificMsg(MAP_SPEC_EVENT_CONFIRMATION, MAP_V_UNKNOWN)
{
   DLOG(0,1,"MapSpecificConfirmation :cons:");
	m_OpCode = p_OpCode;
   m_ioflag='I'; //Defaulted to IMAP
	m_LastFlag=true;
   m_lci = MAP_SPEC_LAST_COMPONENT_IND_UNKNOWN;
}

MapSpecificConfirmation::~MapSpecificConfirmation()
{
   DLOG(0,1,"MapSpecificConfirmation :des:");

}


MapOpenRequests::MapOpenRequests(EMapCommonMsgType p_MapCommonMsgType) : MapCommonMsg(p_MapCommonMsgType)
{
  m_ApplCntxt = MAP_AC_UNKNOWN;
  memset(&m_OpenInfo, '\0', sizeof(m_OpenInfo));
  memset(&m_OrigAddr, '\0', sizeof(m_OrigAddr));
  memset(&m_DestAddr, '\0', sizeof(m_DestAddr));
}

MapOpenRequests::~MapOpenRequests()
{
}

MapOpenReq::MapOpenReq(int p_UserDialogId, EMapVersion p_version) : MapOpenRequests(MAP_CMN_OPEN_REQ)
{
   DLOG(0,1,"MapOpenReq :cons:");
	m_UserDlgId = p_UserDialogId;
	m_Version = p_version;
}

MapOpenReq::~MapOpenReq()
{
   DLOG(0,1,"MapOpenReq :des:");
}

MapOpenInd::MapOpenInd()  : MapOpenRequests(MAP_CMN_OPEN_IND)
{
    DLOG(0,1,"MapOpenInd :cons:");
    m_componentsPresentFlag = true;
}

MapOpenInd::~MapOpenInd()
{
    DLOG(0,1,"MapOpenInd :des:");
}



MapOpenResponses::MapOpenResponses(EMapCommonMsgType p_MapCommonMsgType) : MapCommonMsg(p_MapCommonMsgType)
{
  m_ResponseChoiceFlag = false;
  m_RefuseReasonParam = REFUSE_REASON_UNKNOWN;
  m_ApplCntxt = MAP_AC_UNKNOWN;
  memset(&m_OrigAddr, '\0', sizeof(m_OrigAddr));
  memset(&m_DestAddr, '\0', sizeof(m_DestAddr));
  m_ResponseChoiceFlag=true;
}

MapOpenResponses::~MapOpenResponses()
{

}


MapOpenRsp::MapOpenRsp() : MapOpenResponses(MAP_CMN_OPEN_RSP)
{
    DLOG(0,1,"MapOpenRsp :cons:");
}

MapOpenRsp::~MapOpenRsp()
{
    DLOG(0,1,"MapOpenRsp :des:");
}

MapOpenCnf::MapOpenCnf() : MapOpenResponses(MAP_CMN_OPEN_CNF)
{
    DLOG(0,1,"MapOpenCnf :cons:");
}

MapOpenCnf::~MapOpenCnf()
{
    DLOG(0,1,"MapOpenCnf :des:");
}



MapClose::MapClose(EMapCommonMsgType p_MapCommonMsgType) : MapCommonMsg(p_MapCommonMsgType)
{
}

MapClose::~MapClose()
{

}

MapCloseReq::MapCloseReq(int p_UserDlgId) : MapClose(MAP_CMN_CLOSE_REQ)
{
   DLOG(0,1,"MapCloseReq :cons:");
	m_UserDlgId = p_UserDlgId;
	m_CloseType = MAP_CLOSE_TYPE_UNKNOWN;
	m_PreArrangedReason = MAP_CLOSE_PRE_ARRANGED_REASON_FAILURE;
}

MapCloseReq::~MapCloseReq() 
{                          
   DLOG(0,1,"MapCloseReq :des:");
}

MapCloseInd::MapCloseInd() : MapClose(MAP_CMN_CLOSE_IND)
{
   DLOG(0,1,"MapCloseInd :cons:");
}

MapCloseInd::~MapCloseInd() 
{                          
   DLOG(0,1,"MapCloseInd :des:");
}                          



MapDelimiterReq::MapDelimiterReq(int p_UserDialogId) : MapCommonMsg(MAP_CMN_DELIMITER_REQ)
{
   DLOG(0,1,"MapDelimiterReq :cons:");
	m_UserDlgId = p_UserDialogId;
}

MapDelimiterReq::~MapDelimiterReq()
{
   DLOG(0,1,"MapDelimiterReq :des:");
}

MapDelimiterInd::MapDelimiterInd() : MapCommonMsg(MAP_CMN_DELIMITER_IND)
{
   DLOG(0,1,"MapDelimiterInd :cons:");
}

MapDelimiterInd::~MapDelimiterInd()
{
   DLOG(0,1,"MapDelimiterInd :des:");
}



MapNoticeInd::MapNoticeInd() : MapCommonMsg(MAP_CMN_NOTICE_IND)
{
   DLOG(0,1,"MapNoticeInd :cons:");
   m_NoticeProblem = NOTICE_PROBLEM_UNKNOWN;
}

MapNoticeInd::~MapNoticeInd()
{
   DLOG(0,1,"MapNoticeInd :des:");
}



MapUAbort::MapUAbort(EMapCommonMsgType p_MapCommonMsgType) : MapCommonMsg(p_MapCommonMsgType)
{
   m_AbortCause = DP_UNREC_MESSAGE;
   m_AbortReason = ABRT_NOT_PRESENT;
}

MapUAbort::~MapUAbort()
{
}

MapUAbortReq::MapUAbortReq(int p_UserDlgId) : MapUAbort(MAP_CMN_U_ABORT_REQ)
{
   DLOG(0,1,"MapUAbortReq :cons:");
	m_UserDlgId = p_UserDlgId;
   m_versionRejected=0;
}

MapUAbortReq::~MapUAbortReq()
{
   DLOG(0,1,"MapUAbortReq :des:");
}

MapUAbortInd::MapUAbortInd() : MapUAbort(MAP_CMN_U_ABORT_IND)
{
   DLOG(0,1,"MapUAbortInd :cons:");
}

MapUAbortInd::~MapUAbortInd()
{
   DLOG(0,1,"MapUAbortInd :des:");
}



MapPAbort::MapPAbort(EMapCommonMsgType p_MapCommonMsgType) : MapCommonMsg(p_MapCommonMsgType)
{
}

MapPAbort::~MapPAbort()
{
}

MapPAbortReq::MapPAbortReq() : MapPAbort(MAP_CMN_P_ABORT_REQ)
{
   DLOG(0,1,"MapPAbortReq :cons:");
}

MapPAbortReq::~MapPAbortReq()
{
   DLOG(0,1,"MapPAbortReq :des:");
}

MapPAbortInd::MapPAbortInd() : MapPAbort(MAP_CMN_P_ABORT_IND)
{
   DLOG(0,1,"MapPAbortInd :cons:");
}

MapPAbortInd::~MapPAbortInd()
{
   DLOG(0,1,"MapPAbortInd :des:");
}


MapProviderErrorMsg::MapProviderErrorMsg() : MapSpecificMsg(MAP_SPEC_EVENT_PROV_ERROR, MAP_V2)
{
   DLOG(0,1,"MapProviderErrorMsg :cons:");
   m_MapProvErrorCode = MAP_PROV_ERROR_UNKNOWN;
   m_InvokeId=0;
}

MapProviderErrorMsg::~MapProviderErrorMsg()
{
   DLOG(0,1,"MapProviderErrorMsg :des:");
}

MapUserError::MapUserError(int p_dialogId, EMapErrorCode p_errorCode, EMapVersion p_MapVersion, void *p_structBuffer) : MapSpecificMsg(MAP_SPEC_EVENT_USER_ERROR, p_MapVersion)
{
  DLOG(0,1,"MapUserError :cons:");
  m_UserDlgId = p_dialogId;
  m_ErrorCode = p_errorCode;
  m_structBuffer = p_structBuffer;
  m_bufLen = 0;
  memset(m_buffer, '\0', MAX_COMP_BUFFER_SIZE);
  m_ioflag='O'; //Defaulted to OMAP, since majorly Application will initiate this one
  m_lci = MAP_SPEC_LAST_COMPONENT_IND_UNKNOWN;
}

MapUserError::~MapUserError()
{
  DLOG(0,1,"MapUserError :des:");
}



bool configureSccpAddress(L_SccpAddress *p_addr, int p_RoutingType, int p_pc, int p_ssn, char *p_gt, L_SccpNumberingPlan p_snp)
{
   memset(p_addr,'\0',sizeof(L_SccpAddress));

   if (0 != p_ssn)
   {
	   p_addr->addressIndicator.ssnIndicator = true;
	   p_addr->ssn = p_ssn;
   }
   TLOG(0,1,"configureSccpAddress protocol:%d gti:%d", g_protocol, g_globalTitleIndicator);
   p_addr->protocol = g_protocol;

   switch (p_RoutingType)
   {

	   case L_ROUTE_ON_GT:
         {
         DLOG(0,1,"L_ROUTE_ON_GT");
			p_addr->addressIndicator.pointCodeIndicator = false;
			p_addr->addressIndicator.routingIndicator = L_ROUTE_ON_GT;
			p_addr->addressIndicator.globalTitleIndicator = (L_SccpGlobalTitleIndicator)g_globalTitleIndicator;
			p_addr->pointCode.c7pointCode.value = 0;
			p_addr->globalTitle.natureOfAddressIndicator = (U8)4;
			p_addr->globalTitle.translationType = g_OtherConfigData->m_TT;
			p_addr->globalTitle.numberingPlan = p_snp;  //Added in 5.0.0.0 for SRG
			p_addr->addressIndicator.pointCodeIndicator = false;
			p_addr->globalTitle.addressInformationLength = strlen(p_gt);
			if (p_addr->globalTitle.addressInformationLength % 2)
				p_addr->globalTitle.encodingScheme = L_ES_BCD_ODD;
			else
				p_addr->globalTitle.encodingScheme = L_ES_BCD_EVEN;

			strcpy(p_addr->globalTitle.addressInformation, p_gt);
         }
			break;

	   default:
         {
         DLOG(0,1,"L_ROUTE_ON_PC_SSN");
			p_addr->addressIndicator.routingIndicator = L_ROUTE_ON_PC_SSN;
			p_addr->addressIndicator.pointCodeIndicator = true;
			p_addr->pointCode.c7pointCode.value = p_pc;
			p_addr->addressIndicator.globalTitleIndicator = L_GT_0000;
         }
			break;
   }
   return true;
}

