#include <TimeoutMsg.h>

TimeoutMsg::TimeoutMsg() : Msg(MSG_TYPE_TIMEOUT)
{
}

TimeoutMsg::~TimeoutMsg()
{
}

