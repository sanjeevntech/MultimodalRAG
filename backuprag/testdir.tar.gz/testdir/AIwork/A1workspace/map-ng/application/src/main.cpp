#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <ContextBase.h>
#include <ModuleManager.h>
#include <strings.h>
#include <stdlib.h>
#include <TcapStack.h>
#include <ServiceCoordinator.h>
#include <Logger.h>
#include <MapMessages.h>
#include <AsnCodec.h>
#include <ConfigReader.h>
#include <apiinc.h>
#include <tcap.h>
#include <tcerror.h>
#include <DbActiveObject.h>
#include <DbChangeNotification.h>
//#include <NotifyQuery.h>
#include <DlgContext.h>
#include <ToolInterface.h>
#include <MplManager.h>
#include <ExtendedServiceCoordinator.h>
#include <NetworkInterface.h>
#include <StatisticsGenerator.h>
#include <DataUnion.h>
#include <TimerManager.h>
#include <DataUnion.h>
#include <SnmpInterface.h>
#include <LogOverride.h>
#include <TcpSocketServer.h>
#include <SmppInterface.h>
#include <Utilities.h>
#include <ConstantsLogOverride.h>
#include <NgLogOverride.h>
#include <CurrentTime.h>
#include <DiameterConstants.h>
#include <SelfSimulator.h>
#include <DiametriqInterface.h>
#include <GUtilThreadHeartBeat.h>
#include <StatisticsInitializationHelper.h>
#include <CtxtUpdateExitStatus.h>
#include <SelfSlhSimulator.h>
#include <typeinfo>
#include <MemCachedActiveObject.h>
#include "SCCPInterface.h"
#include <SubsProfileData.h>

#ifdef GOOGLE_TEST
#include "gtest.h"
#endif



#ifdef WITH_QUANTIFY_APIS
#include <quantify.h>
#endif

#include <LicenVal.h>

//#ifdef Linux
//char       g_RandKey[10];
//#endif

////////

pthread_mutex_t g_mtxXsdValidationLock;
map<int, mymap> g_CCMap;
map<int,string> g_OpCodeGT; //Added in 1.0.7.1

///////


enum EHlrUniqTrapId
{
   HLR_UNIQUE_TRAP_ID_DB_CONN=100,
   HLR_UNIQUE_TRAP_ID_DB_CONN_1,
   HLR_UNIQUE_TRAP_ID_DB_CONN_2,
   HLR_UNIQUE_TRAP_ID_TCAP_STACK,
   HLR_UNIQUE_TRAP_ID_GRACEFULL,
   HLR_UNIQUE_TRAP_ID_DISK_FULL,
   HLR_UNIQUE_TRAP_ID_SMSC_CONN,
   HLR_UNIQUE_TRAP_ID_THR_HANG,
   HLR_UNIQUE_TRAP_ID_DB_CONG,
   HLR_UNIQUE_TRAP_ID_TRANS_PER_SEC,
   HLR_UNIQUE_TRAP_ID_OP_APPL_MISMATCH,
   HLR_UNIQUE_TRAP_ID_RTPS_CONN,
   HLR_UNIQUE_TRAP_ID_DB_THR_HANG,
   HLR_UNIQUE_TRAP_ID_OUT_OF_DIALOGS,
   HLR_UNIQUE_TRAP_ID_PROV_REG_NOT,
   HLR_UNIQUE_TRAP_ID_PROV_DEV_UNAUTH,
   HLR_UNIQUE_TRAP_ID_DIAM_STACK,
   CLOSE_NOT_RECV_CLIENT,
   PEER_IDLE_CONN,
   MAX_ACTIVE_CONN,
   THRESHOLD_CONN,
   ACCEPT_ERR_NEW_CONN,
   MEMC_INIT_FAIL_TRAP,
   MEMC_SERVER_PUSH_FAIL_TRAP,
   MEMC_SET_CONN_FAIL_TRAP,
   MEMC_GET_CONN_FAIL_TRAP,
   MEMC_DIFF_TIME_TRAP,
   MEMC_QUEUE_THRESHOLD_REACHED_TRAP,
   INITIAL_DB_TPS_REACHED_TRAP,
   LATER_DB_TPS_REACHED_TRAP,
   HLR_STACK_TRANS_FAIL_TRAP,
   HLR_DIALOGUE_POOL_REACHED_TRAP 
};

int  g_ConfigIndex=0;
bool g_CombinedInstance = false;

bool clearLicense(int p_index);

extern int terminateStack();
extern void sigalrmHandler2 (int);
extern void processOtherMessages();

bool g_licenseInitialised=false;
char g_NgVersion[200];
char g_NgStartDate[50];
ToolInterface g_ti;
bool g_loadFlag = FALSE;
bool g_selfLoadFlag = FALSE;
int  g_MsgsPerSec = 5;
int  g_SimulatingDuration = 30; // 30 seconds
uid_t g_uid; 
MessageQueue *g_OamTransactionsList;
int g_EmergencyFlag = 0;
//HLR 2.0.24.0
int g_maxXmlTpsDataIndex = -1; 
bool initializeXmlRequestStatistics(StatisticsGenerator *p_sg); 
int g_numOfXmlMsgsPerSecond = 0;
int g_xmlMsgTimer = 0;
int g_maxTpsDataIndex = -1; 
int g_maxInitialDbTpsIndex = -1; 
int g_maxLaterDbTpsIndex = -1; 
GenUtilLoggerInterface* g_gui = NULL;
pthread_t g_mainThreadId;

char g_LoggerBuffer[LOGGER_BUFFER_SIZE+1];
int  g_simulateThbHungInterval = 0;
time_t g_currTimeForTHB;
int g_EnableLoggerThb = 0;


#define MAX_OUTPUT_SIZE 1028

bool capturePstack(char *p_buff, int p_maxSize)
{
   FILE *ptr;
   char l_command[30];
   memset(l_command,'\0',sizeof(l_command));
   sprintf(l_command,"pstack %d ", getpid());

   char path[MAX_OUTPUT_SIZE];
   memset(path,'\0',sizeof(path));

   printf("\ncommand: [%s]\n", l_command);


   if((ptr = popen(l_command, "r"))!=NULL)
   {
      //printf("\ncapturePstack before fgets\n");
      while (fgets(path, MAX_OUTPUT_SIZE, ptr) != NULL)
      {
         //printf("\ncapturePstack before strlcat\n");
         strlcat(p_buff,path,p_maxSize);
      }
      if(-1 == pclose(ptr))
      {
         //perror("Error in pclose()");
      }
      return true;
   }
   else
   {
      printf("Failed to execute command :%s\n",l_command);
      return false;
   }
}


void exitFunc(EExitAppType p_exit)
{
   printf("\n\n     Application exited with ExitCode:%d ExitDesc:[%s]\n\n", p_exit, getExitApplTypeChar(p_exit));
   ELOG(0,1, "     exitFunc called with exit code: %d [%s]", p_exit, getExitApplTypeChar(p_exit));
   if(g_OtherConfigData->m_dcd.m_diameterNgRequired)
   {
      g_di.terminate();
   }
   terminateStack();
   //char l_buffer[10000+1];
   //memset(l_buffer, '\0', sizeof(l_buffer));
   //capturePstack(l_buffer, 10000);
   //CLOG(1,1,"\n\npstack output: [%s]", l_buffer);
   //ELOG(0,1,"exiting...\n\n");
   int l_currTime;
   l_currTime=time(NULL);
   printf("\nCurr Time:%d\n", l_currTime);
   LLOG(0,0,"Updating exit instance status in DB");
   //#ifdef SunOS
   CtxtUpdateExitStatus *l_upd = new CtxtUpdateExitStatus;
   l_upd->startProcessing();
   sleep(4);
   //#endif
   l_currTime=time(NULL);
   printf("\nCurr Time:%d\n", l_currTime);
   clearLicense(g_ConfigData->m_InstanceId-1);
   exit(p_exit);
}

int writeServerVersionNumber()
{
   FILE *fp;
   //int count;

   char *l_ngDetails = NULL;
   l_ngDetails = g_cr->getConfigPrint(0);

   char *l_moduleDetails = NULL;
   g_cr->getModulesPrint(&l_moduleDetails);

   char l_file[20+1];
   snprintf(l_file, sizeof(l_file), "Version-Index%d.txt", g_ConfigIndex);

   fp = fopen(l_file, "w");
   if(fp == NULL)
   {
      perror("Failed to open Version.txt");
      return 1;
   }
   else
   {
      fwrite(l_ngDetails, strlen(l_ngDetails), 1, fp);
      fwrite(l_moduleDetails, strlen(l_moduleDetails), 1, fp);
      fclose(fp);
      return 0;
   }
}


#if 0
class NotifyOamTable : public NotifyQuery
{
   public:
      void  callbackinitialize(char *p_table,char *p_rowid, char p_type)
      {
         if (p_type != 'I')
         {
            LLOG(0,1,"OAM Table Notification Table [%s] [%c] received. Ignored", p_table, p_type);
            return;
         }

         if (strlen(p_rowid) < 10)
         {
            printf("\nInvalid ROWID [%s]", p_rowid);
            return;
         }

         g_sc.initiateIndependentContext(NULL, MAP_OP_CODE_dummy_1, p_rowid, INITIATION_TYPE_IMMEDIATE);
      }
};
#endif


class NgConstantsLogOverride : public ConstantsLogOverride
{
   public:
      bool override(char p_logLevel, char *p_data)
      {
         if('\n' == p_data[ strlen(p_data) -1])
         {
            p_data[strlen(p_data) -1] = '\0';
         }
         switch(p_logLevel)
         {
            case 'D':
               DLOG(0,1,p_data);
               break;
            case 'E':
               ELOG(0,1,p_data);
               break;
            case 'T':
               TLOG(0,1,p_data);
               break;
            case 'W':
               WLOG(0,1,p_data);
               break;
            case 'L':
               LLOG(0,1,p_data);
               break;
            case 'C':
               CLOG(0,1,p_data);
               break;
            default:
               printf("\nunable to log: %s", p_data);
               break;
         }
         return true;
      }
};


////////////////////////////////////////////////////////////////////////////////////////////

//Temporarily adding the below piece of code to clear the licensing remnants. This function
//can be moved into gen-utils.


extern key_t g_Key;
extern int g_NumOfInst;

struct ProcDetails1
{
   pid_t m_PID;
   time_t m_TIME;
};

bool clearLicense(int p_index)
{
   if (true == g_licenseInitialised)
   {
      int l_ShmId;
      ProcDetails1 *l_ProcDetails;
      if (0 > (l_ShmId = shmget(g_Key, sizeof(ProcDetails1)*g_NumOfInst, 0)))
      {
         printf("\nError in getting mmm. [errno:%d, err:%s]", errno, strerror(errno));
         return false;
      }

      if((l_ProcDetails = (ProcDetails1*)shmat(l_ShmId, NULL, 0)) == (ProcDetails1*) -1)
      {
         printf("\nError in attaching mmm. [errno:%d, err:%s]", errno, strerror(errno));
         return false;
      }

      l_ProcDetails += p_index;

      if(l_ProcDetails->m_PID)
      {
         if (getpid() == l_ProcDetails->m_PID)
         {
            printf("\nClearing the mmm size %d clearing at index %d\n", sizeof(ProcDetails1), p_index);
            l_ProcDetails->m_PID=0;
         }
         else
         {
            printf("\nProcessids differ. Current: %d, MMM: %d So not clearing", getpid(), l_ProcDetails->m_PID);
         }
         return true;
      }
      else
      {
         printf("\nPID doesn't exist in the shared memory\n");
         return false;
      }
   }
   return false;
}

////////////////////////////////////////////////////////////////////////////////////////////


BOOL g_simulator=FALSE;
BOOL g_oamFlag=FALSE;
char g_ConfigFile[50];
int g_simulatorCount=1;
int g_simulatorOpCode=2;
U32 remotePC = 0xffffffff;
U8 remoteSSN = 0;
int localPC;
U8 localSSN = 0;
char nodeName[MAXnodeNAME + 1];

#if 0
void *ociThrFunc(void*)
{
   LLOG(0,1,"ociThrFunc: calling change notification initialize");
   g_DbChangeNotification.initialize();
   LLOG(0,1,"ociThrFunc: end of change notification initialize");
   return NULL;
}
#endif

#if 0
bool initializeDbChangeNotification()
{
   if (g_ConfigData->i_DbConfigData.m_ReceiveNotificationsFlag)
   {
      NotifyQuery *l_oam = new NotifyOamTable;
      l_oam->setDbQuery("select * from HLR_OAM_TRANSACTIONS where trans_status='P'");

      char l_schema[50];
      char l_username[50];
      char l_password[50];
      memset(l_schema, '\0', 50);
      memset(l_username, '\0', 50);
      memset(l_password, '\0', 50);

      if(strlen(g_ConfigData->i_DbConfigData.m_DbConnetionString) != 0)
      {
         char *l_slash = NULL;
         l_slash = strchr(g_ConfigData->i_DbConfigData.m_DbConnetionString, '/');
         if(l_slash != NULL)
         {
            strncpy(l_username, g_ConfigData->i_DbConfigData.m_DbConnetionString, 
                  strlen(g_ConfigData->i_DbConfigData.m_DbConnetionString) - strlen(l_slash));
            char *l_at = NULL;
            l_at = strchr(l_slash, '@');
            if(l_at != NULL)
            {
               strncpy(l_password, &l_slash[1], strlen(l_slash) - strlen(l_at)-1);
               strcpy(l_schema, &l_at[1]);
            }
         }

      }

      DLOG(0,1,"Username: [%s], Password: [%s], Schema: [%s]", l_username, l_password, l_schema);

      printf("\n\tInitializing DB Change Notification ...");

      g_DbChangeNotification.setConnectionString(l_schema,l_username,l_password);
      g_DbChangeNotification.addDbQuery(l_oam);
      pthread_t l_thread = pthread_create(&l_thread, NULL, ociThrFunc, NULL);
      //return g_DbChangeNotification.initialize();
   }
   return true;
}
#endif

void printFunc()
{
   printf("\nthis is the func");
}

MessageQueue *g_SimulatorCtxtQueue = NULL;

void *simThrFunc(void*)
{
   printf("\nsimThrFunc started");
   g_SimulatorCtxtQueue = new MessageQueue(QUEUE_TYPE_NON_BLOCKING, QUEUE_PERSISTENCE_TYPE_NON_PERSISTENT);
   bool l_status = g_SimulatorCtxtQueue->initialize();
   if (!l_status)
   {
      printf("\nERROR!! Unable to initialize the Simulator Ctxt Queue");
      return NULL;
   }

   int l_totalMsgs = g_MsgsPerSec * g_SimulatingDuration;

   int l_messagesSentInSecond=0;
   for (int i=0; i<l_totalMsgs; i++)
   {
      ContextBase *l_ct = g_mm.getRespectiveContext2(g_simulatorOpCode, NULL);
      if(l_ct == NULL)
      {
         printf("\nSevere Error!!! This one. Check whether a service is defined for the Op Code: %d", g_simulatorOpCode);
         return NULL;
      }
      l_ct->setClassName((char*)(typeid(*l_ct).name()));
      g_SimulatorCtxtQueue->push(l_ct);

      if (++l_messagesSentInSecond == g_MsgsPerSec)
      {
         l_messagesSentInSecond=0;
         sleep(1);
      }
   }

   printf("\nend of simThrFunc\n");
   return NULL;
}



void *simSelfLoadThrFunc(void*)
{
   sleep(2);
   printf("\nsimSelfLoadThrFunc started");
   if(NULL == g_selfSimObj)
   {
      printf("\nERRORg_selfSimObj is null\n");
      return NULL;
   }
   int l_totalMsgs = g_MsgsPerSec * g_SimulatingDuration;

   int l_messagesSentInSecond=0;
   for (int i=0; i<l_totalMsgs; i++)
   {
      LLOG(0,0,"simSelfLoadThrFunc initiating msg");
      Msg *l_msg = NULL;
      g_selfSimObj->getMessage(g_simulatorOpCode, &l_msg, NULL);
      if(l_msg != NULL)
      {

         LLOG(0,0,"simSelfLoadThrFunc initiating msg2");
         g_esc.initiateIndependentContextLikeNg(NULL, (EDiameterCommandCode)g_simulatorOpCode, l_msg);
         if (++l_messagesSentInSecond == g_MsgsPerSec)
         {
            l_messagesSentInSecond=0;
            sleep(1);
         }
      }
      else
      {
         printf("\nERROR!! No messages to be simulated\n");
      }
   }

   printf("\nend of simSelfLoadThrFunc\n");
   return NULL;
}

bool g_shutdown_received = false;


bool g_sig_int_signal_received = false;

extern void breakTheCall();

void catch_sig_usr1(int p_sig_num)
{
   LLOG(0,1,"Start of SIGUSR1 handler");
   //(void)signal(SIGUSR1,    catch_sig_usr1);
   LLOG(0,1,"End of SIGUSR1 handler");
   return;
}


void catch_sig_int(int p_sig_num)
{
   printf("\n\nT:%d Received a Ctrl-C signal. Closing the application...\n\n\n", pthread_self());

   //CLOG(0,1,"Received a Ctrl-C signal. [%d] Closing the application.", p_sig_num);
   (void)signal(SIGINT,     SIG_IGN);
   //terminateStack();  //anyways unbind is failing on interrupt
   g_sig_int_signal_received=true;
   exitFunc(EXIT_APPLICATION_TYPE_CTRL_SIGNAL_RCVD);
   return;
}


bool g_core_signal_received = false;



void catch_sig_core(int sig_num)
{
   if('B' == g_OtherConfigData->m_logFlag)
   {
      //ELOG(0,1,"Core signal %d received\n", sig_num);
      printf("\nCore signal %d received. Thread %d\n", sig_num, pthread_self());
      if (false == g_core_signal_received)
      {
         g_core_signal_received=true;
         pthread_mutex_unlock(&(g_LoggerObj.m_lw.m_Mutex));

         terminateStack();

         printf("\nReceived signal %d\n", sig_num);

         switch (sig_num)
         {
            case SIGSEGV:
               printf("\n\nT:%d Received a Segmentation fault. \n", pthread_self());
               break;

            case SIGBUS:
               printf("\n\nT:%d Received a Bus error. \n", pthread_self());
               break;

            default:
               printf("\n\nT:%d Received other signal causing core [%d]...\n\n\n", pthread_self(), sig_num);
               break;
         }

         //Ignore any more core signals
         (void)signal(SIGQUIT,    SIG_IGN);
         (void)signal(SIGILL,     SIG_IGN);
         (void)signal(SIGTRAP,    SIG_IGN);
         (void)signal(SIGABRT,    SIG_IGN);
#ifdef SunOS
         (void)signal(SIGEMT,     SIG_IGN);
#endif
         (void)signal(SIGFPE,     SIG_IGN);
         (void)signal(SIGBUS,     SIG_IGN);
         (void)signal(SIGSEGV,    SIG_IGN);
         (void)signal(SIGSYS,     SIG_IGN);
         (void)signal(SIGXCPU,    SIG_IGN);
         (void)signal(SIGXFSZ,    SIG_IGN);

         int l_oldTime=time(NULL);
         printf("\nT:%d Sleeping for 3 secs. Current Time %d", pthread_self(),l_oldTime);
         for(int i=1; i<=30; i++)
         {
            if (l_oldTime+4 < time(NULL))
            {
               printf("\nexceeded 3 seconds");
               break;
            }
            printf("\ntrying to sleep %d time..\n", i);
            sleep(1); 
         }
         printf("\nflushing log\n");

         //char l_buffer[10000];
         //capturePstack(l_buffer, 10000);

         char l_tempChar[1000];
         memset(l_tempChar, '\0', sizeof(l_tempChar));
         sprintf(l_tempChar, "\n\n Flushing Logs after the Core Signal [%d] Received to thread [%d]  ===============   \n\n\n", sig_num, pthread_self());


         flushLog(&g_LoggerObj, l_tempChar);

         sleep(2);
         clearLicense(g_ConfigData->m_InstanceId-1);

         printf("\nT:%d Generating core Time [%d]", pthread_self(),time(NULL));



         abort();
      }
      else
      {
         printf("\nIgnoring the signal [%d] since core_flag is already set\n", sig_num);
      }
   }
   else
   {
      //printf("\nMechanism is not buffered");
      abort();
   }
   return;
}

char *getNgVersion()
{
   RETURN_VERSION(APP_VERSION);
}

char *getNgVersionAlone()
{
   char *l_temp= new char[200]; 
   memset(l_temp, '\0', 200); 
   snprintf(l_temp, 200, "NG:%s", APP_VERSION);
   return l_temp;
}

class AppSubCount: public SubscriberBase
{
   bool GetSubsCount(long &p_sub);
};

bool AppSubCount::GetSubsCount(long& p_sub)
{
   LLOG(0,1,"g_CurrSubsBase is %d", g_CurrSubsBase);
   if(-1 != g_CurrSubsBase)
   {
      p_sub = g_CurrSubsBase;
      LLOG(0,1,"GetSubsCount %d g_CurrSubsBase %d", p_sub, g_CurrSubsBase);
      return true;
   }
   else
   {
      p_sub=-1;
      LLOG(0,1,"Db count not retrieved yet");
      return false;
   }
}

extern bool initializeMplManagerStatistics(StatisticsGenerator *p_sg);
extern bool initializeDbActiveObjectStatistics(StatisticsGenerator *p_sg);
extern bool initializeMemCachedActiveObjectStatistics(StatisticsGenerator *p_sg);
extern bool initializeDiametriqInterfaceStatistics(StatisticsGenerator *p_sg);

bool initializeNgStatistics(StatisticsGenerator *p_sg)
{
   bool l_status=false;

   l_status = initializeMplManagerStatistics(p_sg);
   if(false == l_status)
   {
      CLOG(0,0,"initializeMplManagerStatistics failed");
      return false;
   }

   if(1 == g_ConfigData->i_DbConfigData.m_DbRequired)
   {
      l_status = initializeDbActiveObjectStatistics(p_sg);
      if(false == l_status)
      {
         CLOG(0,0,"initializeDbActiveObjectStatistics failed");
         return false;
      }
   }
   if(1 == g_ConfigData->m_MemcEnableFlag)
   {
      l_status = initializeMemCachedActiveObjectStatistics(p_sg);
      if(false == l_status)
      {
         CLOG(0,0,"initializeMemCachedActiveObjectStatistics failed");
         return false;
      }
   }
   if(g_OtherConfigData->m_dcd.m_diameterNgRequired)
   {
      l_status = initializeDiametriqInterfaceStatistics(p_sg);
      if(false == l_status)
      {
         CLOG(0,0,"initializeDiametriqInterfaceStatistics failed");
         return false;
      }
   }
   return true;
}


int main(int argc, char *argv[])
{ 
   g_mainThreadId = pthread_self();
   g_selfSimObj = new SelfSlhSimulator;
   printf("\nNG APPVER-v:%s ci:%s cd:%s comp:%s %s\n",
         APP_VERSION, COMMIT_ID, COMMIT_DATE,__DATE__,__TIME__);

   g_uid = getuid();
   memset(g_NgVersion, '\0', 200);
   strcpy(g_NgVersion, getNgVersion());

   memset(g_LoggerBuffer,'\0',sizeof(g_LoggerBuffer));

   bool l_status;
   //printf("\nReading Command Line Arguments...");

   for (int i = 1; i < argc; i++)
   {
      if (strcmp (argv[i], "-config") == 0)
      {
         memset(g_ConfigFile, '\0', 50);
         strcpy (g_ConfigFile, argv[++i]);
      }
      if (strcmp (argv[i], "-index") == 0)
      {
         g_ConfigIndex = atoi(argv[++i]);
      }
      if (strcmp (argv[i], "-sim") == 0)
      {
         g_simulator = TRUE;
      }
      if (strcmp (argv[i], "-simLoad") == 0)
      {
         g_loadFlag = TRUE;
      }
      if (strcmp (argv[i], "-selfLoad") == 0)
      {
         g_selfLoadFlag = TRUE;
      }
      if (strcmp (argv[i], "-simLoadMsgsPerSec") == 0)
      {
         g_MsgsPerSec = atoi(argv[++i]);
      }
      if (strcmp (argv[i], "-simLoadDuration") == 0)// in secs
      {
         g_SimulatingDuration = atoi(argv[++i]);
      }
      if (strcmp (argv[i], "-oam") == 0)
      {
         g_oamFlag = TRUE;
      }
      if (strcmp (argv[i], "-simCount") == 0)
      {
         g_simulatorCount = (U32) atoi (argv[++i]);
      }
      if (strcmp (argv[i], "-simOpCode") == 0)
      {
         g_simulatorOpCode = (U32) atoi (argv[++i]);
      }
   }

   if ( (g_ConfigIndex<1) || (g_ConfigIndex>99) )
   {
      printf("\nPlease configure the Config Index value between 1 and 20.");
      printf("\nThis value can be configured using the -index option when starting the binary.");
      printf("\n\n");
      exit(500);
   }


   printf("\nReading Configuration File [%s]", g_ConfigFile);
   g_ConfigData = new ConfigData;
   g_OtherConfigData = new OtherConfigData;
   g_cr = new NgConfigReader();
   g_cr->setConfigName(g_ConfigFile);
   l_status = g_cr->init();
   if (false == l_status)
   {
      printf("\nError in initializing Configuration file\n");
      exitFunc(EXIT_APPLICATION_TYPE_CONFIG_INIT_FAILED);
   }
   g_nlo = new NgLogOverride;
   l_status = g_cr->readData();
   if (false == l_status)
   {
      printf("\nError in reading data\n");
      exitFunc(EXIT_APPLICATION_TYPE_CONFIG_DATA_READING_FAILED);
   }

   /* THB */
   char *l_thbHung = NULL;
   l_thbHung = getenv("ENABLE_THB_HUNG");
   if(NULL != l_thbHung)
   {
      g_simulateThbHungInterval = atoi(l_thbHung);
      g_currTimeForTHB = time(NULL);
      LLOG(0,0,"THB Hung enabled %d",g_simulateThbHungInterval);
   }
   /* THB */

   /* Enable THB for Logwriter */
   char *l_EnableLogthb = NULL;
   l_EnableLogthb = getenv("ENABLE_THB_FOR_LOG_WRITING_THREAD");
   if(NULL != l_EnableLogthb)
   {
      g_EnableLoggerThb = atoi(l_EnableLogthb);
      LLOG(0,0,"THB for Logger is enabled %d",g_EnableLoggerThb);
   }
   /* Enable THB for Logwriter */

   int l_logTest=1;
   DLOG(0,0,"Log test %d", l_logTest++);
   LLOG(0,0,"NG APPVER-v:%s ci:%s cd:%s comp:%s %s", APP_VERSION, COMMIT_ID, COMMIT_DATE,__DATE__,__TIME__);
#if 0
#ifdef GOOGLE_TEST
   printf("Running google test \n");
   testing::InitGoogleTest(&argc, argv);
   printf("DONE Running google test \n");
   RUN_ALL_TESTS();
   printf("DONE Running google test \n");
   return 0;
#endif
#endif
   printf("\n\tInitializing Signals ...");
   DLOG(0,0,"Log test %d", l_logTest++);


   // Start of blocking all the signals, so that all the child threads shall inherit this behaviour
   printSignalSet("Start of main");
   sigset_t l_current_set;
   sigemptyset(&l_current_set);
   sigset_t l_new_set;
   sigemptyset(&l_new_set);
   for(int i=SIGHUP; i<=SIGRTMAX; i++) // Beware!! - This might not be fully portable across platforms
   {
      sigaddset(&l_new_set, i);
   }
   (void)pthread_sigmask(SIG_BLOCK, NULL, &l_current_set);
   (void)pthread_sigmask(SIG_BLOCK, &l_new_set, &l_current_set);


   DLOG(0,0,"Log test %d", l_logTest++);
   if (NULL == g_gui)
   {   //This shall remove the core signals from the blocking set, so that core signals can come to any thread
      sigset_t temp;
      sigset_t set;
      sigemptyset(&set);
      sigaddset(&set, SIGQUIT);
      sigaddset(&set, SIGILL);
      sigaddset(&set, SIGTRAP);
      sigaddset(&set, SIGABRT);
#ifdef SunOS
      sigaddset(&set, SIGEMT);
#endif
      sigaddset(&set, SIGFPE);
      sigaddset(&set, SIGBUS);
      sigaddset(&set, SIGSEGV);
      sigaddset(&set, SIGSYS);
      sigaddset(&set, SIGXCPU);
      sigaddset(&set, SIGXFSZ);
      sigaddset(&set, SIGUSR1); //TO BE REMOVED

      (void)pthread_sigmask(SIG_UNBLOCK, &set, &temp);
   }
   DLOG(0,0,"Log test %d", l_logTest++);

   printSignalSet("After blocking");
   // End of blocking


   struct sigaction l_sa_old; /* Old signal actions */
   struct sigaction l_sa_new; /* New signal actions */
   l_sa_new.sa_handler = catch_sig_usr1; /* Point to our function */
   sigemptyset(&l_sa_new.sa_mask); /* Clear mask */
   l_sa_new.sa_flags = 0; /* No special flags */
   if(0 == sigaction(SIGUSR1,&l_sa_new,&l_sa_old))
   {
      LLOG(0,1,"sigaction SIGUSR1 success");
   }
   else
   {
      ELOG(0,1,"sigaction SIGUSR1 failure errno:%d", errno);
   }
   DLOG(0,0,"Log test %d", l_logTest++);

   (void)signal(SIGHUP,     SIG_IGN);            //SIGHUP           1       Exit       Hangup (see termio(7I))
   (void)signal(SIGINT,     catch_sig_int);      //SIGINT           2       Exit       Interrupt (see termio(7I))
   if(NULL == g_gui)
   {
      if(NULL == getenv("LOGS_IMMEDIATE"))
      {
         printf("\n\tLOGS_IMMEDIATE is not set. Logs are not immediate. Catching core signals");
         (void)signal(SIGQUIT,    catch_sig_core);  //SIGQUIT          3       Core       Quit (see termio(7I))
         (void)signal(SIGILL,     catch_sig_core);  //SIGILL           4       Core       Illegal Instruction
         (void)signal(SIGTRAP,    catch_sig_core);  //SIGTRAP          5       Core       Trace or Breakpoint Trap
         (void)signal(SIGABRT,    catch_sig_core);  //SIGABRT          6       Core       Abort
#ifdef SunOS
         (void)signal(SIGEMT,     catch_sig_core);  //SIGEMT           7       Core       Emulation Trap
#endif
         (void)signal(SIGFPE,     catch_sig_core);  //SIGFPE           8       Core       Arithmetic Exception
         //Should not handle the kill signal        //SIGKILL          9       Exit       Killed
         (void)signal(SIGBUS,     catch_sig_core);  //SIGBUS           10      Core       Bus Error
         (void)signal(SIGSEGV,    catch_sig_core);  //SIGSEGV          11      Core       Segmentation Fault
         (void)signal(SIGSYS,     catch_sig_core);  //SIGSYS           12      Core       Bad System Call
         (void)signal(SIGXCPU,    catch_sig_core);  //SIGXCPU          30      Core       CPU   time   limit   exceeded    (see getrlimit(2))
         (void)signal(SIGXFSZ,    catch_sig_core);  //SIGXFSZ          31      Core       File   size   limit   exceeded   (see getrlimit(2))
      }
      else
      {
         printf("\n\tLOGS_IMMEDIATE is set. Logs are immediate. Not Catching core signals");
      }
   }
   DLOG(0,0,"Log test %d", l_logTest++);
   (void)signal(SIGPIPE,    SIG_IGN);            //SIGPIPE          13      Exit       Broken Pipe
   //Should not handle alarm since Ulticom uses  //SIGALRM          14      Exit       Alarm Clock
   (void)signal(SIGTERM,    SIG_IGN);            //SIGTERM          15      Exit       Terminated
   //(void)signal(SIGUSR1,    catch_sig_usr1);   //SIGUSR1          16      Exit       User Signal 1
   (void)signal(SIGUSR2,    SIG_IGN);            //SIGUSR2          17      Exit       User Signal 2
   //(void)signal(SIGCHLD,    SIG_IGN);            //SIGCHLD          18      Ignore     Child Status Changed
   (void)signal(SIGPWR,     SIG_IGN);            //SIGPWR           19      Ignore     Power Fail or Restart
   (void)signal(SIGWINCH,   SIG_IGN);            //SIGWINCH         20      Ignore     Window Size Change
   (void)signal(SIGURG,     SIG_IGN);            //SIGURG           21      Ignore     Urgent Socket Condition
   (void)signal(SIGPOLL,    SIG_IGN);            //SIGPOLL          22      Exit       Pollable Event (see streamio(7I))
   //Should not handle this stop signal          //SIGSTOP          23      Stop       Stopped (signal)
   (void)signal(SIGTSTP,    SIG_IGN);            //SIGTSTP          24      Stop       Stopped (user) (see termio(7I))
   (void)signal(SIGCONT,    SIG_IGN);            //SIGCONT          25      Ignore     Continued
   (void)signal(SIGTTIN,    SIG_IGN);            //SIGTTIN          26      Stop       Stopped (tty input) (see termio(7I))
   (void)signal(SIGTTOU,    SIG_IGN);            //SIGTTOU          27      Stop       Stopped (tty output) (see termio(7I))
   (void)signal(SIGVTALRM,  SIG_IGN);            //SIGVTALRM        28      Exit       Virtual Timer Expired
   (void)signal(SIGPROF,    SIG_IGN);            //SIGPROF          29      Exit       Profiling Timer Expired
#ifdef SunOS
   (void)signal(SIGWAITING, SIG_IGN);            //SIGWAITING       32      Ignore     Reserved
   (void)signal(SIGLWP,     SIG_IGN);            //SIGLWP           33      Ignore     Reserved
   (void)signal(SIGFREEZE,  SIG_IGN);            //SIGFREEZE        34      Ignore     Check point Freeze
   (void)signal(SIGTHAW,    SIG_IGN);            //SIGTHAW          35      Ignore     Check point Thaw
   (void)signal(SIGCANCEL,  SIG_IGN);            //SIGCANCEL        36      Ignore     Reserved for threading support
   (void)signal(SIGLOST,    SIG_IGN);            //SIGLOST          37      Exit       Resource lost (for  example,  record-lock lost)
   (void)signal(SIGXRES,    SIG_IGN);            //SIGXRES          38      Ignore     Resource   control   exceeded    (see setrctl(2))
   (void)signal(SIGJVM1,    SIG_IGN);            //SIGJVM1          39      Ignore     Reserved for Java Virtual Machine 1
   (void)signal(SIGJVM2,    SIG_IGN);            //SIGJVM2          40      Ignore     Reserved for Java Virtual Machine 2
#endif

   DLOG(0,0,"Log test %d", l_logTest++);
   for (int l_i=SIGRTMIN; l_i<=SIGRTMAX; l_i++)  //SIGRTMIN         *       Exit       First real time signal
   {                                             //(SIGRTMIN+1)     *       Exit       Second real time signal
      (void)signal(l_i,    SIG_IGN);             //...
   }                                             //(SIGRTMAX-1)     *       Exit       Second-to-last real time signal
   //SIGRTMAX         *       Exit       Last real time signal

   printSignalSet("After signal functions");



   memset(g_NgStartDate, '\0', sizeof(g_NgStartDate));
   time_t l_startDate = time(NULL);
   strcpy(g_NgStartDate, ctime((time_t *)&l_startDate));
   int l_len= strlen(g_NgStartDate);
   g_NgStartDate[l_len-1] = '\0';
   DLOG(0,0,"Log test %d", l_logTest++);


   //printf("\nsizeo of ULCM_node_ip_addr_t: %d", sizeof(ULCM_node_ip_addr_t));
#ifdef WITH_QUANTIFY_APIS
   printf("\nQuantify: Using Quantify API stop()\n");
   if(quantify_is_running())
   {
      printf("\nQuantify: Stopping Recording Data\n");
      quantify_clear_data();
      quantify_stop_recording_data();
   }
#endif

   DLOG(0,0,"Log test %d", l_logTest++);

   NgConstantsLogOverride *l_constantsLo = new NgConstantsLogOverride;
   printf("\n\nInitializing NG... ");
   printf("\n\tInitializing MAP Constants ... ");
   l_status = MapConstants::initialize(l_constantsLo);
   if (false == l_status)
   {
      printf("\nUnable to initialize MapConstants");
      exitFunc(EXIT_APPLICATION_TYPE_MAP_CONSTANTS_INIT_FAILED);
   }

   DLOG(0,0,"Log test %d", l_logTest++);
   printf("\n\tInitializing DIAMETER Constants ... ");
   l_status = DiameterConstants::initialize();
   if (false == l_status)
   {
      printf("\nUnable to initialize DiameterConstants");
      exitFunc(EXIT_APPLICATION_TYPE_DIAMETER_CONSTANTS_INIT_FAILED);
   }

   DLOG(0,0,"Log test %d", l_logTest++);
   remotePC = g_ConfigData->i_NgConfigData.m_RemotePC;
   remoteSSN = g_ConfigData->i_NgConfigData.m_RemoteSSN;
   localSSN = g_ConfigData->i_NgConfigData.m_LocalSSN;
   strcpy(nodeName, g_ConfigData->i_NgConfigData.m_StackName);


   printSignalSet("after creating log");


   DLOG(0,0,"Log test %d", l_logTest++);


   if (true == g_ConfigData->m_SnmpInterfaceEnabledFlag)
   {
      printf("\n\tInitializing with SNMP Agent (%s:%d)...", g_ConfigData->m_SnmpAgentIp, g_ConfigData->m_SnmpAgentPort);

      l_status = g_si.initialize(g_ConfigData->m_EntityName, g_ConfigData->m_SnmpAgentIp, g_ConfigData->m_SnmpAgentPort, g_nlo, 1, g_ConfigData->m_InstanceId, "HLR");
      if (!l_status)
      {
         printf("\nERROR!! Unable to initialize the SnmpInterface");
         exitFunc(EXIT_APPLICATION_TYPE_GUTIL_SNMP_SI_INIT_FAILED);
      }

      //Register all the SNMP Traps which the application wishes to send
      g_DbConnectionTrap          = g_si.registerSnmpTrap("DB_CONN",       "DB Connection", HLR_UNIQUE_TRAP_ID_DB_CONN);
      g_DbConnectionTrap1         = g_si.registerSnmpTrap("DB_CONN_1",     "DB Connection with DB_CONN_1", HLR_UNIQUE_TRAP_ID_DB_CONN_1);
      g_DbConnectionTrap2         = g_si.registerSnmpTrap("DB_CONN_2",     "DB Connection with DB_CONN_2", HLR_UNIQUE_TRAP_ID_DB_CONN_2);
      g_TcapStackConnectionTrap   = g_si.registerSnmpTrap("TCAP_STACK",    "TCAP Stack Connection", HLR_UNIQUE_TRAP_ID_TCAP_STACK);
      g_GracefullShutdownTrap     = g_si.registerSnmpTrap("GRACEFULL",     "Gracefully shut", HLR_UNIQUE_TRAP_ID_GRACEFULL);
      g_DiskFullTrap              = g_si.registerSnmpTrap("DISK_FULL",     "Hard Disk Full", HLR_UNIQUE_TRAP_ID_DISK_FULL);
      g_SmscConnectionTrap        = g_si.registerSnmpTrap("SMSC_CONN",     "SMSC Connection", HLR_UNIQUE_TRAP_ID_SMSC_CONN);
      g_ThreadHanged              = g_si.registerSnmpTrap("THR_HANG",      "HLR Stack thread hanged", HLR_UNIQUE_TRAP_ID_THR_HANG);
      g_DbCongestion              = g_si.registerSnmpTrap("DB_CONG",       "DB Congestion", HLR_UNIQUE_TRAP_ID_DB_CONG);
      g_TransPerSecTrap           = g_si.registerSnmpTrap("TRANS_PER_SEC", "Transactions Per Sec Congestion", HLR_UNIQUE_TRAP_ID_TRANS_PER_SEC);
      g_OpCodeApplMismatchTrap    = g_si.registerSnmpTrap("OP_APPL_MISMATCH","Op Code and Application Context Mismatch", HLR_UNIQUE_TRAP_ID_OP_APPL_MISMATCH);
      g_RtpsConnectionTrap        = g_si.registerSnmpTrap("RTPS_CONN",     "Connection with the RTPS", HLR_UNIQUE_TRAP_ID_RTPS_CONN);
      g_DbThreadHangTrap          = g_si.registerSnmpTrap("DB_THR_HANG",   "DB Thread Hanged", HLR_UNIQUE_TRAP_ID_DB_THR_HANG);
      g_outOfDialgsTrap           = g_si.registerSnmpTrap("OUT_OF_DIALOGS","Out of Dialogs", HLR_UNIQUE_TRAP_ID_OUT_OF_DIALOGS);
      g_provRegRequestNotRcvdTrap = g_si.registerSnmpTrap("PROV_REG_NOT",  "Provisioning - Registration Request not received", HLR_UNIQUE_TRAP_ID_PROV_REG_NOT);
      g_provDeviceUnauthorizedTrap= g_si.registerSnmpTrap("PROV_DEV_UNAUTH","Provisioning - Device Unauthorized", HLR_UNIQUE_TRAP_ID_PROV_DEV_UNAUTH);
      g_DiameterStackConnectionTrap=g_si.registerSnmpTrap("DIAM_STACK",    "DIAMETER Stack Connection", HLR_UNIQUE_TRAP_ID_DIAM_STACK);

      g_CloseNotRecvTrap = g_si.registerSnmpTrap((char*)"CLOSE_NOT_RECV_CLIENT", (char*)"Close not received from client", CLOSE_NOT_RECV_CLIENT);
      g_MaxthresholdLimitTrap  =         g_si.registerSnmpTrap((char*)"MAX_CONN_REACHED",(char*)"Max Active Connections reached", MAX_ACTIVE_CONN);
      g_MaxThreshPercentTrap  =      g_si.registerSnmpTrap((char*)"THRESHOLD_CONN",(char*)"Current Active connections beyond the threshold percentage ", THRESHOLD_CONN);
      g_AcceptNewConnErrTrap      =        g_si.registerSnmpTrap((char*)"ACCEPT_ERR_NEW_CONN",(char*)"Error in accepting a new connection", ACCEPT_ERR_NEW_CONN);

      g_MemcInitializeFailTrap       = g_si.registerSnmpTrap("MEMC_INIT_FAIL",        "Memcached Initialization failed", MEMC_INIT_FAIL_TRAP);
      g_MemcServerPushFailureTrap    = g_si.registerSnmpTrap("MEMC_SERVER_PUSH_FAIL", "Memcached Server Push failed", MEMC_SERVER_PUSH_FAIL_TRAP);
      g_MemcSetConnectionFailTrap    = g_si.registerSnmpTrap("MEMC_SET_CONN_FAIL",    "Memcached Connection Failure for SET", MEMC_SET_CONN_FAIL_TRAP);
      g_MemcGetConnectionFailTrap    = g_si.registerSnmpTrap("MEMC_GET_CONN_FAIL",    "Memcached Connection Failure for GET", MEMC_GET_CONN_FAIL_TRAP);
      g_MemcServerDiffTimeTrap       = g_si.registerSnmpTrap("MEMC_SERVER_DIFF_TIME", "Memcached Server Delay Response", MEMC_DIFF_TIME_TRAP);
      g_MemcqueueThresholdTrap       = g_si.registerSnmpTrap("MEMC_QUEUE_THRESHOLD_REACHED", "Memcached Queue Threshold Reached", MEMC_QUEUE_THRESHOLD_REACHED_TRAP);
      g_InitialDBTpsReachedTrap             = g_si.registerSnmpTrap("INITIAL_DB_TPS_REACHED", "Current TPS exceeded than INITIAL_DB_TPS", INITIAL_DB_TPS_REACHED_TRAP);
      g_LaterDBTpsReachedTrap             = g_si.registerSnmpTrap("LATER_DB_TPS_REACHED", "Current TPS exceeded than LATER_DB_TPS", LATER_DB_TPS_REACHED_TRAP);

      g_TranslationTrap              = g_si.registerSnmpTrap("STACK_TRANS_FAIL",      "HLR Stack Translation Failed", HLR_STACK_TRANS_FAIL_TRAP);
      g_DialoguePoolTRAP          = g_si.registerSnmpTrap("DIALOGUE_POOL_SIZE","Dialogue pool queue crosses 80 percent",HLR_DIALOGUE_POOL_REACHED_TRAP);

      if(0 != g_OtherConfigData->m_THBEnabled)
      {
         if(false == g_thb.initialize(THREAD_HANGED_ACTION_DO_NOTHING))
         {
            printf("\nTHB Initialisation Failed .. exiting\n");
            exitFunc(EXIT_APPLICATION_TYPE_THB_INITIALIZATION_FAILED);
         }
      }
   }

   DLOG(0,0,"Log test %d", l_logTest++);
   if (true == g_ConfigData->m_TracingEnabledFlag)
   {
      printf("\n\tInitializing Trace files ... ");

      l_status = g_TraceObj.initialize(g_ConfigData->m_TracingLogLevel,
            g_ConfigData->m_TracingLogMedia, 
            g_ConfigData->m_TracingLogfilePath, 
            g_ConfigData->m_TracingLogPrefix, 
            "trace",
            g_ConfigData->m_TracingArchivalPath, 
            g_ConfigData->m_TracingLogMaxsize,
            1,
            LOG_ROTATE_TYPE_FALSE,
            0,
            MAX_TRACING_DUMPING_SIZE);
      if (false == l_status)
      {
         printf("\nUnable to initialize Trace Logger");
         exitFunc(EXIT_APPLICATION_TYPE_TRACE_LOGGER_INIT_FAILED);
      }
   }

   DLOG(0,0,"Log test %d", l_logTest++);
   AppSubCount l_AppSubCount;
/*
#ifndef GOOGLE_TEST
   if(1 == g_ConfigData->i_DbConfigData.m_DbRequired)
   {
      int l_LicType;
      int l_TxBase;
      LLOG(0,1,"Initializing MMM with instance id %d", g_ConfigData->m_InstanceId);
      if(false == LicenVal::GetInstance()->Init("HLR", g_ConfigData->m_InstanceId-1, 10, 60, 
               &l_AppSubCount, l_LicType, l_TxBase, g_nlo))
      {
         printf(" \n\n \t LICENSE VALIDATION FAILED \n\n");
         if(g_OtherConfigData->m_ProfilesFailureDuration % 2 == 0)
         {
            CLOG(0,0,"LICENSE VALIDATION is considered");
            exitFunc(EXIT_APPLICATION_TYPE_LICENCE_INIT_FAILED);
         }
         else
         {
            CLOG(0,0,"LICENSE VALIDATION is disabled");
         }
      }
      DLOG(0,1,"LicType:%d TxBase:%d", l_LicType, l_TxBase);
   }
#endif
*/
   g_licenseInitialised=true;


   printf("\n\tInitializing Service Coordinator ... ");
   l_status = g_sc.initialize(g_ConfigData->i_NgConfigData.m_MaxDialogs);
   if (!l_status)
   {
      DLOG(0,0,"Unable to initialize Map Service Coordinator");
      exitFunc(EXIT_APPLICATION_TYPE_MAP_SERV_COORD_INIT_FAILED);
   }

   bool l_result;
   printf("\n\tInitializing ASN.1 Codecs");
   l_result = initializeAsnCodecs(g_ConfigData->m_LogMapPduPrintFlag);
   if (false == l_result)
   {
      printf("\nError in initialization of the OSS Nokalva libraries");
      exitFunc(EXIT_APPLICATION_TYPE_ASN_CODECS_INIT_FAILED);
   }

   if (true == g_ConfigData->i_DbConfigData.m_DbRequired)
   {
      printf("\n\tInitializing DB Active Object...");
      g_act.initialize(g_ConfigData->i_DbConfigData.m_PoolSizeRequired, 0);

#if 0
      l_status = initializeDbChangeNotification();
      if (!l_status)
      {
         printf("\nERROR!! Unable to initialize DB Connections");
         exitFunc(EXIT_APPLICATION_TYPE_DB_CHANGE_NOT_INIT_FAILED);
      }
#endif
   }

   if (true == g_ConfigData->m_MemcEnableFlag)
   {
      printf("\n\tInitializing MemCached Active Object...");
      if(false == g_MemcActObj.initialize())
      {
         LLOG(0,0,"Unable to Initialize MemCached, Sending TRAP");
         g_si.sendSnmpTrap(g_MemcInitializeFailTrap, TRAP_TYPE_FAIL, TRAP_SEVERITY_CRITICAL);
      }
   }

   if (true == g_ConfigData->m_ToolEnabledFlag)
   {
      printf("\n\tInitializing Tool Interface ...");
      l_status = g_ti.initialize(g_ConfigData->m_ToolPort);
      if (!l_status)
      {
         printf("\nERROR!! Unable to initialize the ToolInterface");
         exitFunc(EXIT_APPLICATION_TYPE_MML_TOOL_INIT_FAILED);
      }
   }


   printf("\n\tInitializing MAP Provider Layer ... ");
   g_MplManager.initialize(g_ConfigData->i_NgConfigData.m_MaxDialogs);


   if (true == g_ConfigData->m_EsmeConfigData.m_Required)
   {
      printf("\n\tInitializing SMPP Interface...");
      if (false == SmppInterface::getInstance()->Initialize())
      {
         printf("\nError in Initializing the SmppClient");
         exitFunc(EXIT_APPLICATION_TYPE_SMPP_INIT_FAILED);
      }
      //int l_seqNum=0;
      //919176660833
      //g_sc.sendSmppSubmit("919789977111", (unsigned char *)"This is a test message", sizeof("This is a test message"), &l_seqNum, 0);
   }


   printf("\n\tInitializing Inter-Module Interface ...");
   g_InterModuleQueue = new MessageQueue(QUEUE_TYPE_NON_BLOCKING, QUEUE_PERSISTENCE_TYPE_NON_PERSISTENT);
   l_status = g_InterModuleQueue->initialize();
   if (false == l_status)
   {
      printf("\nERROR!! Unable to initialize the Inter-Module Interface Queue");
      exitFunc(EXIT_APPLICATION_TYPE_INTER_MODULE_QUEUE_INIT_FAILED);
   }

   printf("\n\tInitializing Inter-Module (2) Interface ...");
   g_InterModuleQueue2 = new MessageQueue(QUEUE_TYPE_NON_BLOCKING, QUEUE_PERSISTENCE_TYPE_NON_PERSISTENT);
   l_status = g_InterModuleQueue2->initialize();
   if (false == l_status)
   {
      printf("\nERROR!! Unable to initialize the Inter-Module (2) Interface Queue");
      exitFunc(EXIT_APPLICATION_TYPE_INTER_MODULE2_QUEUE_INIT_FAILED);
   }

   printf("\n\tInitializing OAM Transaction list...");
   if (1 == g_OtherConfigData->m_BackLogQueueType)
   {
      g_OamTransactionsList = new MessageQueue(QUEUE_TYPE_NON_BLOCKING, QUEUE_PERSISTENCE_TYPE_PERSISTENT);
   }
   else
   {
      g_OamTransactionsList = new MessageQueue(QUEUE_TYPE_NON_BLOCKING, QUEUE_PERSISTENCE_TYPE_NON_PERSISTENT);
   }

   l_status = g_OamTransactionsList->initialize();
   if (false == l_status)
   {
      printf("\nERROR!! Unable to initialize the OAM Transaction List");
      exitFunc(EXIT_APPLICATION_TYPE_OAM_TRANS_LIST_INIT_FAILED);
   }


   printf("\nInitialization of NG successfull.");
   initializeCurrentTime();

#if 0
   //hey to be removed
   sleep(2);
   LLOG(0,1," Checking logs");

   struct timeval l_currTv, l_prevTv;
   printTime(l_currTv, l_prevTv, NULL);

   for (int l_i=0; l_i<10000; l_i++)
   {
      //LLOG(0,1,"This is just log checking whether this is taking more time or not. Once validated, these messages shall be removed %d %s %d %c",l_i,"laksjdfl", l_i+67, l_i%5);
      LLOG(0,1,"This is just log checking whether this is taking more time or not. Once validated, these messages shall be removed");
   }
   printTime(l_currTv, l_prevTv, "LOG TIME");

   sleep(3);
   exit(999);
   //end of hey to be removed
#endif

   if(NULL != getenv("TEST_LOG_PERFORMANCE"))
   {
      char sentence[1000];
      FILE *fptr;

      fptr = fopen("output.txt", "w");
      if(fptr == NULL)
      {
         printf("Error!");
         exit(1);
      }
      for(int l_i=0; l_i<10000000; l_i++)
      {
         LLOG(0,0,"hello here: %d",l_i);
         fprintf(fptr,"done with %d\n", l_i);
         fflush(fptr);
      }
   }

   printf("\n\nLoading Modules...");
   //if(0 == g_OtherConfigData->m_SCCPStackFlag)
   if (false == g_cr->readModules())
   {
      printf("\nError in Loading Modules.\n\n");
      exitFunc(EXIT_APPLICATION_TYPE_LOADING_MODULES_CONFIGURATIONS_FAILED);
   }
   else
   {
      printf("\nLoaded Modules successfully...\n");

      if (true == g_ConfigData->m_TdrEnabledFlag)
      {
         printf("\nInitializing Transaction Detail Record files ... ");

         l_status = g_TdrObj.initialize(LOG_LEVEL_DEBUG,
               g_ConfigData->m_TdrLogMedia, 
               g_ConfigData->m_TdrLogfilePath, 
               g_ConfigData->m_TdrLogPrefix, 
               "tdr",
               g_ConfigData->m_TdrArchivalPath, 
               g_ConfigData->m_TdrLogMaxsize,
               2,
               LOG_ROTATE_TYPE_FALSE,
               0,
               MAX_TDR_DUMPING_SIZE);
         if (false == l_status)
         {
            printf("\nUnable to initialize TDR");
            exitFunc(EXIT_APPLICATION_TYPE_TDR_INIT_FAILED);
         }

         if(LOG_MEDIA_RTPS == g_ConfigData->m_TdrLogMedia)
         {
            l_status = g_CriticalTdrObj.initialize(LOG_LEVEL_DEBUG,
                  LOG_MEDIA_FILE, 
                  g_ConfigData->m_TdrLogfilePath, 
                  g_ConfigData->m_TdrLogPrefix, 
                  "ctdr",
                  g_ConfigData->m_TdrArchivalPath, 
                  g_ConfigData->m_TdrLogMaxsize,
                  2,
                  LOG_ROTATE_TYPE_FALSE,
                  0,
                  MAX_TDR_DUMPING_SIZE);
            if (false == l_status)
            {
               printf("\nUnable to initialize the Critical TDR object");
               exitFunc(EXIT_APPLICATION_TYPE_CRITICAL_TDR_INIT_FAILED);
            }
         }
      }


      printf("\n\tInitializing Timer Manager ...");
      l_status = g_tm.initialize();
      if(false == l_status)
      {
         printf("\nERROR!! Unable to initialize the Timer Manager");
         exitFunc(EXIT_APPLICATION_TYPE_TIMER_MANAGER_INIT_FAILED);
      }

      sleep(1);
      NetworkInterface& lNetworkInterface = NetworkInterface::getInstance();
      SCCPInterface& ss7Obj = SCCPInterface::getInstance();
#ifndef GOOGLE_TEST
      if(g_OtherConfigData->m_ProfilesFailureDuration > 0)
      {
         int l_sleep=0;
         do
         {
            sleep(1);
            processOtherMessages();
            if(NULL != g_spd)
            {
               LLOG(0,0,"profiles loaded successfully");
               break;
            }
            else
            {
               LLOG(0,0,"profiles still not loaded %d", l_sleep);
            }
            l_sleep++;
            processOtherMessages();

         }while(l_sleep<g_OtherConfigData->m_ProfilesFailureDuration);


         //if(0 == g_OtherConfigData->m_SCCPStackFlag) 
         {
            if(NULL == g_spd)
            {
               CLOG(0,0,"profiles still not loaded. hence exiting");
               exitFunc(EXIT_APPLICATION_TYPE_SUBS_PROFILES_LOADING_TIMEOUT);
            }
         }
      }

      ////////////////////////  INTERNAL REBOOT NOTIFICATIONS BEGIN  /////////////////////////////

      char l_dateString[20+1];
      char l_instanceType[10];
      char l_buf[1000];
      memset(l_dateString, '\0', sizeof(l_dateString));
      memset(l_instanceType,'\0',sizeof(l_instanceType));
      memset(l_buf, '\0', sizeof(l_buf));

      struct tm *l_tm_ptr=NULL;
      time_t l_tim =time(NULL);
      l_tm_ptr = localtime(&l_tim);
      sprintf(l_dateString, "%04d%02d%02d%02d%02d%02d",l_tm_ptr->tm_year+1900, l_tm_ptr->tm_mon+1, l_tm_ptr->tm_mday,l_tm_ptr->tm_hour, l_tm_ptr->tm_min, l_tm_ptr->tm_sec);

      if((1 == g_OtherConfigData->m_TCAPStackFlag) && (1 == g_OtherConfigData->m_dcd.m_diameterNgRequired))
      {
         g_CombinedInstance = true;
         DLOG(0,0,"Combined Instance Flag is set to true");
         snprintf(l_instanceType,sizeof(l_instanceType),"%s","HLRHSS");
      }
      else if(1 == g_OtherConfigData->m_TCAPStackFlag) 
      {
         snprintf(l_instanceType,sizeof(l_instanceType),"%s","HLR");
      }
      else if(1 == g_OtherConfigData->m_dcd.m_diameterNgRequired)
      {
         snprintf(l_instanceType,sizeof(l_instanceType),"%s","HSS");
      }
     
      int l_NotifyRebootInfoNetworkID;
      l_NotifyRebootInfoNetworkID = g_spdPtr->m_MsisdnPrefReplaceStruct.m_NotifyRebootInfoNetworkID;

      TdrData l_tdrDataObj;
      l_tdrDataObj.m_HDR[TDR_HDR_RECEIVED_TIMESTAMP] = l_dateString;
      l_tdrDataObj.setTdrId();   
      l_tdrDataObj.setOpCode(1);   
      l_tdrDataObj.setContextId("MAIN");   
      l_tdrDataObj.setString(15,"INTERNAL_NOTIFICATION");
      l_tdrDataObj.setString(16,"HLRHSS");
      l_tdrDataObj.setString(17,g_ConfigData->m_EntityName);
      l_tdrDataObj.setString(18,l_instanceType);
      l_tdrDataObj.setString(19,"START");
      l_tdrDataObj.setInteger(65,l_NotifyRebootInfoNetworkID);
      g_tfb->prepareTDR(&l_tdrDataObj, l_buf, 0);
      LLOG(0,1,"Prepared TDR MAIN..[%s]", l_buf);
      g_TdrObj.log2(LOG_LEVEL_CRITICAL, __FILE__, __FUNCTION__, __LINE__, 0, 0, l_buf);

      ////////////////////////////////  INTERNAL REBOOT NOTIFICATIONS END /////////////////////////////
      printf("\n\tInitializing DIAMETER Stack ...");
      DLOG(0,0,"Initializing DIAMETER Stack ...");
      if(1 == g_OtherConfigData->m_dcd.m_diameterNgRequired)
      {
         if(false == g_di.initialize(g_OtherConfigData->m_dcd.m_applicationId))
         {
            ELOG(0,1,"Diamtriq Stack initialization failure");
            g_si.sendSnmpTrap(g_DiameterStackConnectionTrap, TRAP_TYPE_FAIL, TRAP_SEVERITY_CRITICAL);
            exitFunc(EXIT_APPLICATION_TYPE_DIAM_STACK_INIT_FAILED);
         }
      }


      if(1 == g_OtherConfigData->m_TCAPStackFlag)
      {
         DLOG(0,0,"Initializing TCAP Stack ...");
         printf("\n\tInitializing TCAP Stack ...");

         l_status = lNetworkInterface.openConn(argc, argv);
         if (false == l_status)
         {
            g_si.sendSnmpTrap(g_TcapStackConnectionTrap, TRAP_TYPE_FAIL, TRAP_SEVERITY_CRITICAL);
            printf("\nUnable to initialize the stack");
            exitFunc(EXIT_APPLICATION_TYPE_ULTI_STACK_INIT_FAILED);
         }
         g_si.sendSnmpTrap(g_TcapStackConnectionTrap, TRAP_TYPE_PASS, TRAP_SEVERITY_MINOR);
      }
      else
      {
         snprintf(g_ConfigData->m_StackEntityName, sizeof(g_ConfigData->m_StackEntityName), 
               "%s%03d_%05d", g_ConfigData->m_EntityName, g_ConfigData->m_InstanceId, getpid());
         alarm(1);
         (void)signal(SIGALRM,     sigalrmHandler2);     
      }

      if(1 == g_OtherConfigData->m_SCCPStackFlag) 
      {
         DLOG(0,0," Initializing SCCP Stack");
         int tryCount=0;

         //for(tryCount=0; tryCount<3; tryCount++)
         if (!ss7Obj.openConn(argc, argv))  // open connection with SCCP failed
         {

            sleep(1);

            printf("\n Unable to initialize the SCCP stack");
            exitFunc(EXIT_APPLICATION_TYPE_SCCP_INIT_FAILED);
         }
         else
         {
            LLOG(0,0,"###### SCCP CONNECTION ESTABLISHED #####");
            printf("\n ####### SCCP CONNECTION ESTABLISHED #####");
         }
      }
#endif


      if(true == g_ConfigData->m_ProvInterfaceEnabledFlag)
      {
         printf("\n\tInitializing Provisioning Interface ...");
         l_status = g_tss.initialize(g_ConfigData->m_ProvListenPort);
         if (!l_status)
         {
            printf("\nERROR!! Unable to initialize the Provisioning Interface");
            exitFunc(EXIT_APPLICATION_TYPE_PROV_INTERFACE_INIT_FAILED);
         }
      }

      printSignalSet("just before unblocking");


      //This is after creation of all the threads. Saving the old signal rules
      sigemptyset(&l_new_set);
      (void)pthread_sigmask(SIG_SETMASK, &l_current_set, &l_new_set);
      printSignalSet("After unblocking");

      char *l_appDetails = g_cr->getConfigPrint(0);
      printf(" %s\n\n", l_appDetails);
      if(TRUE == g_loadFlag)
      {
         g_simulator = FALSE; 
         pthread_t l_thread = pthread_create(&l_thread, NULL, simThrFunc, NULL);
      }
      if(TRUE == g_selfLoadFlag)
      {
         printf("\nSelf Simulator Thread Starting\n");
         g_simulator = FALSE; 
         pthread_t l_thread = pthread_create(&l_thread, NULL, simSelfLoadThrFunc, NULL);
      }
      CLOG(1,1,"Application Details: %s", l_appDetails);
      //LLOG(0,1,"%s", l_text);

      if(0 != g_OtherConfigData->m_THBEnabled)
      {
         if(false == g_thb.registerMe(60, "Main Thread"))
         {
            CLOG(1,1,"RegisterMe failed");
            exit(1);
         }
      }
#if 1
#ifdef GOOGLE_TEST
      printf("Running google test \n");
      testing::InitGoogleTest(&argc, argv);
      printf("DONE Running google test \n");
      RUN_ALL_TESTS();
      printf("DONE Running google test \n");
      return 0;
#endif
#endif
#if 0
      DLOG(0,0,"XML: 1 testing imei masking <IMEI>1234567892345678</IMEI> to be removed later 16 digit ");
      DLOG(0,0,"XML: 2 testing imeisv masking <IMEISV>1234567892345678</IMEISV> to be removed later 16 digit ");
      DLOG(0,0,"XML: 3 testing imei masking <IMEI>23</IMEI> to be removed later 2 digit imei ");
      DLOG(0,0,"XML: 4 testing imei masking <IMEI></IMEI> to be removed later null imei ");
      DLOG(0,0,"XML: 5 testing imei and imeisv masking <IMEI>123456789345678</IMEI> and <IMEISV>3435353535353</IMEISV> to be removed later both some digits ");
      DLOG(0,0,"XML: 6 testing imei and imeisv masking <IMEI>34545666666</IMEI> <IMEISV></IMEISV> to be removed later imeisv is null ");
      DLOG(0,0,"XML: 7 testing imei and imeisv masking <IMEI></IMEI> <IMEISV></IMEISV> to be removed later both are null ");
#endif

      if(1 == g_OtherConfigData->m_SCCPStackFlag)
      {
         DLOG(0,0,"##### BEFORE SEND RECIEVE #####");
         ss7Obj.sendRecvMsgs();
         DLOG(0,0,"##### AFTER SEND RECIEVE #####");
      }
      else
      {
         lNetworkInterface.sendRecvMsgs();
      }
   }
   pthread_mutex_init(&g_mtxXsdValidationLock, NULL);
   return 0;
}

bool initializeXmlRequestStatistics(StatisticsGenerator *p_sg)
{
   g_maxXmlTpsDataIndex = p_sg->addHeader(PEG_TYPE_MAX_COUNTER," XML Maximum TPS observed", "", 'C');
   return true;
}
