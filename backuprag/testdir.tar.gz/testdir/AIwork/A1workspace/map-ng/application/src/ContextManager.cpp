#include <ContextManager.h>
#include <Logger.h>
#include <MplManager.h>
#include <CntxtMsc.h>
#include <ContextBase.h>


ContextManager::ContextManager()
{
   DLOG(0,1,"ContextManager::ContextManager() created");
}


ContextManager::~ContextManager()
{
   DLOG(0,1,"ContextManager::~ContextManager() destroyed");
}

bool ContextManager::initialize(int p_startDialogue, int p_MaxDialogues)
{
   return m_dialoguePool.initialize(p_startDialogue, p_MaxDialogues);
}

void ContextManager::print()
{
   DLOG(0,1,"map size: %d", m_map.size());
}

int ContextManager::getSize()
{
   return m_dialoguePool.getSize();
}

int getContextManagerSize()
{
   return g_ContextMangerObject.getSize();
}


bool ContextManager::storeContext(int p_UserId, void *p_CntxtMscPtr, EDialogueType p_DialogueType)
{
   // Context To Be Stored - Storing in a map or a hash-map
   pair<int, void*> l_pair(p_UserId, p_CntxtMscPtr);
   m_map[p_UserId]=(void*)p_CntxtMscPtr;
   DLOG(0,1,"Store success. Size of Map: %d", m_map.size());
   return true;
}


bool ContextManager::terminate() //This has to be called at shutdown
{
   LLOG(0,1,"ContextManager terminate called");
   map<int, void*>::iterator l_iter;
   for(l_iter=m_map.begin(); l_iter!=m_map.end(); l_iter++)
   {
      if(DIALOGUE_RESPONDER == ((CntxtMsc*)(l_iter->second))->m_DialogueType)
      {
         ContextBase *l_cb=(ContextBase*)((CntxtMsc*)(l_iter->second))->m_pRsc;
         LLOG(0,1,"Context [%s%s:%08d] is still active. Freeing the context", l_cb->m_ModName, l_cb->m_MessageName, l_cb->m_GlobalContextId);
         delete(l_cb);
      }
   }
   return true;
}

bool ContextManager::getContext(int p_UserId, void **p_CntxtMscPtr)
{
   // Context To Be Retrieved
   map<int, void*>::iterator l_iter;
   l_iter = m_map.find(p_UserId);
   if (l_iter == m_map.end())
   {
      TLOG(0,1,"context for %d", p_UserId);
      return false;
   }
   else
   {
      *p_CntxtMscPtr = (*l_iter).second;
   }

   return true;
}

bool ContextManager::removeContext(int p_UserId, EDialogueType p_DialogueType)
{
   // Context To Be Removed
   DLOG(0,1,"Removing Context UserId: %d", p_UserId);

   if (p_UserId > 0)
   {
      m_dialoguePool.releaseDialogueId(p_UserId);
   }
   else
   {
      ELOG(0,1,"User Id is less than 0.... EXITING ...");
      return false;        
   }
   DLOG(0,1,"removing from the map");

   map<int, void*>::iterator l_iter;
   l_iter = m_map.find(p_UserId);
   if (l_iter == m_map.end())
   {
      ELOG(0,1,"unable to find in the map");
      return false;
   }
   else
   {
      m_map.erase(l_iter);
      DLOG(0,1,"removeContext:: Size of Map: %d", m_map.size());
   }


   DLOG(0,1,"Sizes of the map [%d]", m_map.size());

   return true;
}

int ContextManager::getNewDialogue()
{
   m_dialoguePool.getNewDialogueId();//this is just for referrence
   return cTCAPGetDialogId();
}

int ContextManager::getNewDialogueR()
{
   return m_dialoguePool.getNewDialogueId();//this is just for referrence
}


void ContextManager::getStats(char *p_output)
{
   char l_dp[1000];
   memset(l_dp, '\0', sizeof(l_dp));
   m_dialoguePool.getStats(l_dp);

   sprintf(p_output, "%s\n Context Map Size\t\t\t\t: %ld", 
      l_dp, 
      m_map.size());
}



