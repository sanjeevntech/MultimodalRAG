#include <StatesMsc.h>
#include <ConcreteStateMsc.h>
#include <Logger.h>



StatesMsc* StatesMsc::m_pStWaitForSvcPrimitiveMsc = new WaitForSvcPrimitiveMsc();
StatesMsc* StatesMsc::m_pStRelayInfoMsc  = new RelayInfoMsc();

StatesMsc::StatesMsc()
{
    DLOG(0,0,"StatesMsc::StatesMsc() created");
}

StatesMsc::~StatesMsc()
{
    DLOG(0,0,"StatesMsc::~StatesMsc() destroyed");
}

StatesMsc* StatesMsc::handle(CntxtMsc *p_CntxtMscPtr, Msg *p_MapMsgPtr)
{
    ELOG(0,0,"StatesMsc::handle() called . ERROR!! This should never get called");
    if (p_CntxtMscPtr != NULL)
    {
       DLOG(0,1,"CntxtMscPtr is not null");
    }
    if (p_MapMsgPtr != NULL)
    {
       DLOG(0,1,"p_MapMsgPtr is not null");
    }
    return NULL;
}

