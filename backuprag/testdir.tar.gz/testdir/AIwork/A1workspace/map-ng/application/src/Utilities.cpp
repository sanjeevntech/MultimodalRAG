/*****************************************************************************
 ** FILE NAME      : Utilities.cpp
 ****************************************************************************/
#include <errno.h>
#include <Utilities.h>
#include <Logger.h>
#include <signal.h>
#include <ctype.h>
#include <MapConstants.h>
#include <DiameterConstants.h>
#include <sys/time.h>

//4.0.2.0 IMEI encryption
#include <openssl/des.h>
#define ENCRYPTION 1
#define DECRYPTION 2


int getNumberOfSignificantBitsForAByte(unsigned char p_char)
{
   unsigned char j=1;
   if(0x01 & p_char)
      return 8;
   for(int i=1; i<=7; i++)
   {
      j=j+j;
      if( p_char & j)
      {
         return 8-i;
      }
   }
   return 0;
}


int getNumberOfSignificantBitsForAnArray(unsigned char *p_char,int length)
{
   int l_temp=0;
   for(int l_i=length-1; l_i>=0; l_i--)
   {
      l_temp = getNumberOfSignificantBitsForAByte(p_char[l_i]);
      if(l_temp > 0)
      {
         return l_temp + (8*l_i);
      }
   }
   return 0;
}


unsigned int parseHex(const char * str) 
{ 
   unsigned int val = 0; 
   char c; 

   while(c = *str++) 
   { 
      val <<= 4; 

      if (c >= '0' && c <= '9') 
      { 
         val += c & 0x0F; 
         continue; 
      } 

      c &= 0xDF; 
      if (c >= 'A' && c <= 'F') 
      { 
         val += (c & 0x07) + 9; 
         continue; 
      } 

      errno = EINVAL; 
      return 0; 
   } 

   return val; 
}

/*****************************************************************************
 ** FUNCTION NAME  : checkValidBCDDigit
 **
 ** DEFINITON      : Checks whether a character is a valid BCD digit
 **
 ** ARGUMENTS      : c(in) -> The character to be checked for validity
 **
 ** RETURN         : true if valid BCD digit
 **                  false otherwise
 **
 ** REMARKS        :
 *****************************************************************************/
bool checkValidBCDDigit(u8 c)
{
   try
   {
      //if (((c >= 0) && (c <= 9)) || ((c == 0xF)))
      if (((c <= 9)) || ((c == 0xF)))
      {
         return true;
      }
   }
   catch(...)
   {
      //g_LoggerObj.log(LOG_LEVEL_CRITICAL, "%s<Ln: %d> Exception occured.", __FUNCTION__, __LINE__);
   }
   return false;
}

/*****************************************************************************
 ** FUNCTION NAME  : BCDToNum
 **
 ** DEFINITON      : Converts BCD encoded string to numeric string
 **                : It will convert 4 bits as a single numeric string
 **                : for ex. 10010011 will be 3 and 9 as 2 separte digits.   
 ** ARGUMENTS      : none
 **
 ** RETURN         : false in case of some error
 **                  true if successfully decoded
 **
 ** REMARKS        : This function also sets the length of the encoded string
 *****************************************************************************/
int BCDToNum(u8 *m_bcdStr, u8 *m_numStr, u16 m_bcdStrLength)
{
   u16 m_numStrLength = 0;
   try
   {
      u8 c;
      //if ((m_bcdStrLength > MAX_BCD_STR_LEN) || (!m_bcdStrLength))
      //if (!m_bcdStrLength)		
      if (m_bcdStrLength <= 0)		
      {
         //g_LoggerObj.log(LOG_LEVEL_WARNING, "%s<Ln: %d> Invalid BCD string length %d", __FUNCTION__, __LINE__, m_bcdStrLength);
         return -1;
      }

      for (int i = 0; i<m_bcdStrLength; i++)
      {
         c = m_bcdStr[i] & 0x0F;
         if (!checkValidBCDDigit(c))
         {
            //g_LoggerObj.log(LOG_LEVEL_WARNING, "%s<Ln: %d> Invalid input BCD string", __FUNCTION__, __LINE__);
            return -1;
         }
         m_numStr[i*2] = c + '0';

         c = (m_bcdStr[i] & 0xF0) >> 4;
         if (!checkValidBCDDigit(c))
         {
            //g_LoggerObj.log(LOG_LEVEL_WARNING, "%s<Ln: %d> Invalid input BCD string", __FUNCTION__, __LINE__);
            return -1;
         }
         m_numStr[i*2 + 1] = c + '0';
      }

      m_numStrLength = 2*m_bcdStrLength;

      // check whether last BCD octet contains filler
      if ((m_bcdStr[m_bcdStrLength-1] & 0xF0) == 0xF0)
      {
         m_numStrLength--;
      }
      // null terminate the string
      m_numStr[m_numStrLength] = 0;
   }
   catch(...)
   {
      //g_LoggerObj.log(LOG_LEVEL_CRITICAL, "%s<Ln: %d> Exception occured.", __FUNCTION__, __LINE__);
      return -1;
   }
   return m_numStrLength;
}

/*****************************************************************************
 ** FUNCTION NAME  : BCDToWholeNum
 **
 ** DEFINITON      : Converts BCD encoded string to numeric string
 **                : It will convert 4 bits as a single numeric string and and makes a decimal 
 **                : single digit by adding these 2 digits  
 **                : for ex. 10010011 will be first converts as 9 and 3 and makes a single 
 **                : whole decimal number like 93.   nd input will be 8 bits at a time
 ** ARGUMENTS      : none
 **
 ** RETURN         : false in case of some error
 **                  true if successfully decoded
 **
 ** REMARKS        : This function also sets the length of the encoded string
 *****************************************************************************/
int BCDToWholeNum(u8 m_bcdStr, u8 *m_numStr)
{
   //u16 m_numStrLength=0;
   try
   {
      u8 c;

      c = m_bcdStr & 0x0F;
      if (!checkValidBCDDigit(c))
      {
         //g_LoggerObj.log(LOG_LEVEL_WARNING, "%s<Ln: %d> Invalid input BCD string", __FUNCTION__, __LINE__);
         return -1;
      }
      *m_numStr = c;

      c = (m_bcdStr & 0xF0) >> 4;
      if (!checkValidBCDDigit(c))
      {
         //g_LoggerObj.log(LOG_LEVEL_WARNING, "%s<Ln: %d> Invalid input BCD string", __FUNCTION__, __LINE__);
         return -1;
      }
      c*=10; //Add 10th Position ex if 9 it will be 90 (decimal)
      *m_numStr+=c;	

   }
   catch(...)
   {
      //g_LoggerObj.log(LOG_LEVEL_WARNING, "%s<Ln: %d> Exception occured.", __FUNCTION__, __LINE__);
      return -1;
   }
   return 0;
}

/*****************************************************************************
 ** FUNCTION NAME  : numToBCD
 **
 ** DEFINITON      : Converts numeric string to BCD encoded string
 **                : It will take 2 digits(0 to 9) and makes 1 8 bit BCD
 **                : Ex: i/p 3,9(two digits-hex) makes 10010011
 ** ARGUMENTS      : none
 **
 ** RETURN         : false in case of some error
 **                  true if successfully decoded
 **
 ** REMARKS        : This function also sets the length of the encoded string
 *****************************************************************************/
int numToBCD(u8 *m_numStr, u8 *m_bcdStr, u8 m_numStrLength)
{
   try
   {
      u16 m_bcdStrLength=0;
      if (!m_numStrLength)
      {
         //g_LoggerObj.log(LOG_LEVEL_WARNING, "%s<Ln: %d> Invalid Numeric string length %d", __FUNCTION__, __LINE__, m_numStrLength);
         return false;
      }

      for (int i=0; i<m_numStrLength/2; i++)
      {
         if (!checkValidBCDDigit(m_numStr[i*2] - '0'))
         {
            // g_LoggerObj.log(LOG_LEVEL_WARNING, "%s<Ln: %d> Invalid input Numeric string", __FUNCTION__, __LINE__);
            return false;
         }

         m_bcdStr[i] = m_numStr[i*2] & 0x0F;

         if (!checkValidBCDDigit(m_numStr[i*2+1] - '0'))
         {
            //g_LoggerObj.log(LOG_LEVEL_WARNING, "%s<Ln: %d> Invalid input Numeric string", __FUNCTION__, __LINE__);
            return false;
         }

         m_bcdStr[i] |= (m_numStr[i*2+1] & 0x0F) << 4;
      }

      m_bcdStrLength = m_numStrLength/2;
      // Check whether filler is required
      if (m_numStrLength % 2)
      {
         m_bcdStr[m_bcdStrLength] = m_numStr[m_numStrLength - 1] & 0x0F;
         m_bcdStr[m_bcdStrLength] |= 0xF0;
         m_bcdStrLength++;
      }
      // null terminate the string
      //m_bcdStr[m_bcdStrLength] = 0;
   }
   catch(...)
   {
      //g_LoggerObj.log(LOG_LEVEL_CRITICAL, "%s<Ln: %d> Exception occured.", __FUNCTION__, __LINE__);
      return false;
   }
   return true;
}

/*****************************************************************************
 ** FUNCTION NAME  : numToBCD
 **
 ** DEFINITON      : Converts numeric string to BCD encoded string
 **                : It will take 1(00 to 99 decimal) digit and makes 1 8 bit BCD
 **                : ex: i/p 93(decimal hex 5D- 01011101) makes 10010011
 ** ARGUMENTS      : none
 **
 ** RETURN         : false in case of some error
 **                  true if successfully decoded
 **
 ** REMARKS        : This function also sets the length of the encoded string
 *****************************************************************************/
int WholeNumToBCD(u8 m_numStr, u8 *m_bcdStr)
{
   try
   {
      u8 c;
      c=m_numStr%10;
      if (!checkValidBCDDigit(c))
      {
         //g_LoggerObj.log(LOG_LEVEL_WARNING, "%s<Ln: %d> Invalid input Numeric string", __FUNCTION__, __LINE__);
         return false;
      }

      *m_bcdStr = c & 0x0F;

      m_numStr/=10;
      c=m_numStr%10;
      if (!checkValidBCDDigit(c))
      {
         //g_LoggerObj.log(LOG_LEVEL_WARNING, "%s<Ln: %d> Invalid input Numeric string", __FUNCTION__, __LINE__);
         return false;
      }

      *m_bcdStr |= (c & 0x0F) << 4;

   }
   catch(...)
   {
      //g_LoggerObj.log(LOG_LEVEL_CRITICAL, "%s<Ln: %d> Exception occured.", __FUNCTION__, __LINE__);
      return false;
   }
   return true;
}

unsigned short BCDToChar(unsigned char *aChar, unsigned char *aBcd, unsigned short aBcdLen)
{
   unsigned short l_charLen = 0;
   unsigned short j,count;
   j = count = 0;

   for(count, j; count < aBcdLen; count++, j+=2)
   {
      unsigned char l_temp;
      l_temp = ((aBcd[count])&(0x0F));
      if(l_temp >=10 && l_temp <= 15)
         aChar[j] = l_temp + 'A' - 10;
      else
         aChar[j] = l_temp + '0';

      l_temp = ((aBcd[count]&0xF0)>>4);
      if(l_temp >=10 && l_temp <= 15)
         aChar[j+1] = l_temp + 'A' - 10;
      else
         aChar[j+1] = l_temp + '0';

      if(((count == (aBcdLen-1)) && (aBcd[count]&0xF0) == 0xF0))
      {
         aChar[j+1] = '\0';
         l_charLen = j+1;
      }
      else if(count == (aBcdLen-1))
      {
         aChar[j+2] = '\0';
         l_charLen = j+2;
      }
   }
   return l_charLen;
}
/**************************************************************
 * Name             :  bcdtostring
 * Input Parameters :  char *str,char *bcd,int lengthofBCD
 * Return Type      :  none
 * Purpose          :  To change into string from BCD
 * **************************************************************/
int BCDToString(u8 *str, u8 *bcd, int bcdLen)
{
   return BCDToChar(str, bcd, bcdLen);
}
/*
   int BCDToString(u8 *str, u8 *bcd, int bcdLen)
   {
   for(int count=0, j=0; count<bcdLen; count++, j+=2)
   {
   str[j] = ((bcd[count])&(0x0F)) + '0';
   str[j+1] = ((bcd[count]&0xF0)>>4) + '0';

//if(  (count == (bcdLen-1)) && ( ((bcd[count]&0xF0) == 0xF0) || ((bcd[count]&0xC0) == 0xC0) || ((bcd[count]&0xFC) == 0xFC) ) )
if(((count == (bcdLen-1)) && (bcd[count]&0xF0) == 0xF0))
str[j+1] = '\0';
else if(count == (bcdLen-1))
str[j+2] = '\0';
}
return strlen((char*)str);
}
*/

/*
   u16 CharToBCD(u8 *aBcd,u8 *aChar, u16 aCharLen)
   {
   u16 i, j;
   for(i = 0, j = 0; j < aCharLen; i++)
   {
   aBcd[i]= aChar[j]-'0';

   if((aCharLen == (j+1)) && aCharLen%2)
   aBcd[i] |= 0xF0;
   else
   aBcd[i] |= ((aChar[j+1]-'0')<<4);
   j += 2;
   }
   return ((aCharLen/2) + (aCharLen%2));
   }*/


unsigned short CharToBCD(unsigned char *aBcd,unsigned char *aChar, unsigned short aCharLen)
{
   unsigned short i,j;
   i = j = 0;

   for(i, j; j < aCharLen; i++)
   {
      //aChar[j] = toupper(aChar[j]); //logic mandates upper case - this shall cause problem for constant strings

      aBcd[i]= isalpha(aChar[j])>0?(toupper(aChar[j])+10-'A'):aChar[j]-'0';

      if((aCharLen == (j+1)) && aCharLen%2)
         aBcd[i] |= 0xF0;
      else
         aBcd[i] |= ((isalpha(aChar[j+1])>0?(aChar[j+1]+10-'A'):aChar[j+1]-'0')<<4);
      j += 2;
   }
   return ((aCharLen/2) + (aCharLen%2));
}


int StringToBCD(u8 * dest,u8 * src, s32 length)
{
   //numToBCD(src, dest, length);
   return CharToBCD(dest, src, length);
}

/**************************************************************
Name             :  BCDToString
Input Parameters :  U8 *str, U8 *bcd, S32 i
Return Type      :  none
Purpose          :  To change into string from BCD
 **************************************************************/
void BCDToString(u8 *str, u8 *bcd, s32 i, bool oddEven)
{
   int count, j;
   for(count=0,j=0;count<i;count++,j=j+2)
   {
      str[j] = ((bcd[count])&(0x0F)) + '0';
      str[j+1] = ((bcd[count]&0xF0)>>4) + '0';

      if(((count == (i-1)) && (bcd[count]&0xF0) == 0xF0))
         str[j+1] = '\0';
      else if(count == (i-1))
         str[j+2] = '\0';
   }
   i *= 2;
   if(oddEven)
      i--;
   str[i] = '\0';

   for(count = 0; count < j; count++)
   {
      if((0x39 < str[count]) || (0x30 > str[count]))
         str[count] = '\0';
   }
   //printf("Inside bcdToString: count : %d str : %s\n", count, str);
}




bool ConvertInto8Bit(unsigned char *source, unsigned char *dest, int len)
{
   int temp = 0;
   int count = 0;
   unsigned char l_tmp_source[len+1];
   memset(l_tmp_source, '\0', sizeof(l_tmp_source));
   memcpy(l_tmp_source, source,len);
   unsigned char *l_source = l_tmp_source;

   for(int i= 0, j=0; i < len+1 ; i++, j++) // PID 46790 changed len+1 to len
   {
      if((i % 8) == 0)
      {
         count = 0;
         if(j > 1)
         {
            dest[j] = l_source[i-1] & 0x7f;
            len -=8;
            if(len)
            {
               l_source = l_source+7;
               i = 0;
            }
         }
         else
         {
            dest[j] = (l_source[i] << (count+1));
            dest[j] = dest[j] >> (count+1);
         }
      }
      else
      {
         dest[j] = l_source[i] << (count+1);
         dest[j] = ((dest[j] >> (count+1))) << (i%7);
         temp  = (l_source[i-1] >> (8-count));
         dest[j] |= temp;
      }
      count++;
   }
   return true;
}


char *atohx(char *p_dst, const char *p_src)
{	
   char *l_ret = p_dst;
   for(int lsb, msb; *p_src; p_src += 2)
   {	
      msb = tolower(*p_src);
      lsb = tolower(*(p_src + 1));
      msb -= isdigit(msb) ? 0x30 : 0x57;
      lsb -= isdigit(lsb) ? 0x30 : 0x57;
      if((msb < 0x0 || msb > 0xf) || (lsb < 0x0 || lsb > 0xf))
      {
         *l_ret = 0;
         return NULL;
      }
      *p_dst++ = (char)(lsb | (msb << 4));  
   }
   *p_dst = 0;
   return l_ret;
}

void hxtoa(unsigned char *str, unsigned char *hex, int p_hexSize)
{
   int l_count, l_j;
   for(l_count=0,l_j=0;l_count<p_hexSize;l_count++,l_j=l_j+2)
   {
      str[l_j+1] = ((hex[l_count])&(0x0F));
      str[l_j] = ((hex[l_count]&0xF0)>>4);

      ((0x0A <= str[l_j]) && (0x0F >= str[l_j]))?str[l_j] += 55:str[l_j] += 48;
      ((0x0A <= str[l_j+1]) && (0x0F >= str[l_j+1]))?str[l_j+1] += 55:str[l_j+1] += 48;
   }
   str[l_j]='\0';
}


void printHexDump(char *p_text, u8 *p_buffer, int p_length)
{
   printf("\n%-8s\t\t\t: ", p_text);
   int i;
   for (i=0; i<p_length; i++)
   {
      printf("%02x", p_buffer[i]);
      if ( 0 == ((i+1)%4))
      {
         printf(" ");
      }
   }
   //printf("\n");
}


bool ValidateIpv4(char *p_ipadd)
{
   unsigned b1, b2, b3, b4;
   unsigned char c;

   if (sscanf(p_ipadd, "%3u.%3u.%3u.%3u%c", &b1, &b2, &b3, &b4, &c) != 4)
      return false;

   if ((b1 | b2 | b3 | b4) > 255) 
      return  false;

   if (strspn(p_ipadd, "0123456789.") < strlen(p_ipadd)) 
      return false;

   return true;
}

void convertIPV4toHex(char * apIPv4Addr,unsigned char *apAddrInHex)
{
   char *pch=NULL;
   pch=strtok(apIPv4Addr,".");
   apAddrInHex[0]=atoi(pch);

   pch= strtok (NULL, ".");
   apAddrInHex[1]=atoi(pch);

   pch= strtok (NULL, ".");
   apAddrInHex[2]=atoi(pch);

   apAddrInHex[3]=atoi((pch+strlen(pch)+1));
}


void printTime(struct timeval &currTv, struct timeval &prevTv, char *str)
{
   prevTv = currTv;
#ifdef SunOS
   gettimeofday(&currTv);
#else
   gettimeofday(&currTv, NULL);
#endif

   if(NULL != str)
   {
      struct timeval diffTime;

      if(prevTv.tv_sec < currTv.tv_sec)
      {
         diffTime.tv_sec = currTv.tv_sec - prevTv.tv_sec;
         if(prevTv.tv_usec <= currTv.tv_usec)
         {
            diffTime.tv_usec = currTv.tv_usec - prevTv.tv_usec;
         }
         else
         {
            diffTime.tv_usec = 1000000 - prevTv.tv_usec;
            if(1000000 <= (diffTime.tv_usec + currTv.tv_usec))
            {
               diffTime.tv_sec += 1;
               diffTime.tv_usec = (1000000 - prevTv.tv_usec) + currTv.tv_usec - 1000000;
            }
            else
            {
               diffTime.tv_sec -= 1;
               diffTime.tv_usec += currTv.tv_usec;
            }
         }
      }
      else
      {
         diffTime.tv_sec = 0;
         diffTime.tv_usec = currTv.tv_usec - prevTv.tv_usec;
      }


      int i;
      char buf[128];
      sprintf(buf, "%ld", diffTime.tv_usec);
      int len = strlen(buf);
      sprintf(buf, "%ld.", diffTime.tv_sec);

      for(i = 0; i < (6-len); i++)
      {
         strcat(buf, "0");
      }

      sprintf(buf, "%s%ld", buf, diffTime.tv_usec);

      LLOG(0,0,"%s prev: %ld.%ld curr: %ld.%ld diffTime: %s", str, prevTv.tv_sec, prevTv.tv_usec, currTv.tv_sec, currTv.tv_usec, buf);
      //printf("\n%s prev: %ld.%ld curr: %ld.%ld diffTime: %s", str, prevTv.tv_sec, prevTv.tv_usec, currTv.tv_sec, currTv.tv_usec, buf);
   }
}

void getTime(struct timeval &currTv, struct timeval &prevTv, char *str, struct timeval *p_timeval)
{
   prevTv = currTv;
#ifdef SunOS
   gettimeofday(&currTv);
#else
   gettimeofday(&currTv, NULL);
#endif

   if(NULL != str)
   {
      struct timeval diffTime;

      if(prevTv.tv_sec < currTv.tv_sec)
      {
         diffTime.tv_sec = currTv.tv_sec - prevTv.tv_sec;
         if(prevTv.tv_usec <= currTv.tv_usec)
         {
            diffTime.tv_usec = currTv.tv_usec - prevTv.tv_usec;
         }
         else
         {
            diffTime.tv_usec = 1000000 - prevTv.tv_usec;
            if(1000000 <= (diffTime.tv_usec + currTv.tv_usec))
            {
               diffTime.tv_sec += 1;
               diffTime.tv_usec = (1000000 - prevTv.tv_usec) + currTv.tv_usec - 1000000;
            }
            else
            {
               diffTime.tv_sec -= 1;
               diffTime.tv_usec += currTv.tv_usec;
            }
         }
      }
      else
      {
         diffTime.tv_sec = 0;
         diffTime.tv_usec = currTv.tv_usec - prevTv.tv_usec;
      }

      *p_timeval=diffTime;

      int i;
      char buf[128];
      sprintf(buf, "%ld", diffTime.tv_usec);
      int len = strlen(buf);
      sprintf(buf, "%ld.", diffTime.tv_sec);

      for(i = 0; i < (6-len); i++)
      {
         strcat(buf, "0");
      }

      sprintf(buf, "%s%ld", buf, diffTime.tv_usec);

      LLOG(0,0,"%s prev: %ld.%ld curr: %ld.%ld diffTime: %s", str, prevTv.tv_sec, prevTv.tv_usec, currTv.tv_sec, currTv.tv_usec, buf);
      //printf("\n%s prev: %ld.%ld curr: %ld.%ld diffTime: %s", str, prevTv.tv_sec, prevTv.tv_usec, currTv.tv_sec, currTv.tv_usec, buf);
   }
}

void getTime2(struct timeval &currTv, struct timeval &prevTv, char *str, struct timeval *p_timeval)
{

   if(NULL != str)
   {
      struct timeval diffTime;

      if(prevTv.tv_sec < currTv.tv_sec)
      {
         diffTime.tv_sec = currTv.tv_sec - prevTv.tv_sec;
         if(prevTv.tv_usec <= currTv.tv_usec)
         {
            diffTime.tv_usec = currTv.tv_usec - prevTv.tv_usec;
         }
         else
         {
            diffTime.tv_usec = 1000000 - prevTv.tv_usec;
            if(1000000 <= (diffTime.tv_usec + currTv.tv_usec))
            {
               diffTime.tv_sec += 1;
               diffTime.tv_usec = (1000000 - prevTv.tv_usec) + currTv.tv_usec - 1000000;
            }
            else
            {
               diffTime.tv_sec -= 1;
               diffTime.tv_usec += currTv.tv_usec;
            }
         }
      }
      else
      {
         diffTime.tv_sec = 0;
         diffTime.tv_usec = currTv.tv_usec - prevTv.tv_usec;
      }

      *p_timeval=diffTime;

      int i;
      char buf[128];
      sprintf(buf, "%ld", diffTime.tv_usec);
      int len = strlen(buf);
      sprintf(buf, "%ld.", diffTime.tv_sec);

      for(i = 0; i < (6-len); i++)
      {
         strcat(buf, "0");
      }

      sprintf(buf, "%s%ld", buf, diffTime.tv_usec);

      LLOG(0,0,"%s prev: %ld.%ld curr: %ld.%ld diffTime: %s", str, prevTv.tv_sec, prevTv.tv_usec, currTv.tv_sec, currTv.tv_usec, buf);
      //printf("\n%s prev: %ld.%ld curr: %ld.%ld diffTime: %s", str, prevTv.tv_sec, prevTv.tv_usec, currTv.tv_sec, currTv.tv_usec, buf);
   }
}



void printTimeToConsole(struct timeval &currTv, struct timeval &prevTv, char *str)
{
   prevTv = currTv;
#ifdef SunOS
   gettimeofday(&currTv);
#else
   gettimeofday(&currTv, NULL);
#endif

   if(NULL != str)
   {
      struct timeval diffTime;

      if(prevTv.tv_sec < currTv.tv_sec)
      {
         diffTime.tv_sec = currTv.tv_sec - prevTv.tv_sec;
         if(prevTv.tv_usec <= currTv.tv_usec)
         {
            diffTime.tv_usec = currTv.tv_usec - prevTv.tv_usec;
         }
         else
         {
            diffTime.tv_usec = 1000000 - prevTv.tv_usec;
            if(1000000 <= (diffTime.tv_usec + currTv.tv_usec))
            {
               diffTime.tv_sec += 1;
               diffTime.tv_usec = (1000000 - prevTv.tv_usec) + currTv.tv_usec - 1000000;
            }
            else
            {
               diffTime.tv_sec -= 1;
               diffTime.tv_usec += currTv.tv_usec;
            }
         }
      }
      else
      {
         diffTime.tv_sec = 0;
         diffTime.tv_usec = currTv.tv_usec - prevTv.tv_usec;
      }

      int i;
      char buf[128];
      char buf1[128];
      sprintf(buf, "%ld", diffTime.tv_usec);
      int len = strlen(buf);
      sprintf(buf, "%ld.", diffTime.tv_sec);

      for(i = 0; i < (6-len); i++)
      {
         strcat(buf, "0");
      }

      sprintf(buf1, "%s%ld", buf, diffTime.tv_usec);

      printf("\n%s prev: %ld.%ld curr: %ld.%ld diffTime: %s", str, prevTv.tv_sec, prevTv.tv_usec, currTv.tv_sec, currTv.tv_usec, buf1);
   }
}


/**************************************************************
Name             :  tokenize
Input Parameters :  char *input, char *output, int p_size
Return Type      :  none
Purpose          :  To parse the input into an array of objects of size p_size
Usage            :
char str[20][100];
memset(str,'\0',sizeof(str));
char arr[400] = "|12423|22342|3|";
tokenize(arr, (char*)str, 100);
 **************************************************************/

void tokenize(char *p_input, char *p_str, int p_size)
{
   char *l_ptr1, *l_ptr2;
   l_ptr1=l_ptr2=p_input;
   l_ptr2++;
   int l_i=1;
   while(*l_ptr2 != '\0')
   {
      if('|' == *l_ptr2)
      {
         if(l_ptr2-l_ptr1 == 1)
         {
            strncpy(p_str+(l_i*p_size),"0",1);
         }
         else
         {
            int l_length=l_ptr2-l_ptr1-1;
            if(l_length > (p_size-1))
            {
               l_length=p_size-1;
            }
            strncpy(p_str+(l_i*p_size),l_ptr1+1,l_length);
         }
         l_ptr1=l_ptr2;
         l_i++;
      }
      l_ptr2++;
   }
}


/**************************************************************
Name             :  tokenize2
Input Parameters :  char *input, char *output, int p_size
Return Type      :  none
Purpose          :  To parse the input into an array of objects of size p_size
Usage            :
char str[20][100];
memset(str,'\0',sizeof(str));
char arr[400] = "|12423|22342|3|";
tokenize(arr, (char*)str, 100);
 **************************************************************/

int tokenize2(char *p_input, char *p_str, int p_size, char p_seperator)
{
   char *l_ptr1, *l_ptr2;
   l_ptr1=l_ptr2=p_input;
   l_ptr2++;
   int l_i=1;
   while(*l_ptr2 != '\0')
   {
      if(p_seperator == *l_ptr2)
      {
         if(l_ptr2-l_ptr1 == 1)
         {
            strncpy(p_str+(l_i*p_size),"0",1);
         }
         else
         {
            int l_length=l_ptr2-l_ptr1-1;
            if(l_length > (p_size-1))
            {
               l_length=p_size-1;
            }
            strncpy(p_str+(l_i*p_size),l_ptr1+1,l_length);
         }
         l_ptr1=l_ptr2;
         l_i++;
      }
      l_ptr2++;
   }
   return l_i;
}

/**************************************************************
Name             :  printSignalSet
Input Parameters :  Description to be printed in the log
Return Type      :  none
Purpose          :  Prints the calling thread's signal mask
 **************************************************************/
void printSignalSet(char *p_log)
{
   sigset_t l_current_set;
   sigemptyset(&l_current_set);
   (void)pthread_sigmask(SIG_BLOCK, NULL, &l_current_set);

   char l_arr[SIGRTMAX+1];
   memset(l_arr, '\0', sizeof(l_arr));

   for(int i=SIGHUP; i<=SIGRTMAX; i++)
   {
      if(0 != sigismember(&l_current_set, i) )
      {
         l_arr[i-1]='0';
      }
      else
      {
         l_arr[i-1]='1';
      }
   }
   LLOG(0,1,"%s [%d] Signal Set: [%s]", p_log, pthread_self(), l_arr);

   //printf("\n%s [T%d] Signal Set: [%s]", p_log, pthread_self(), l_arr);
   return;
}


void upper(char *p_src, char *p_dest, int p_destMaxLength)
{
   for(int l_i=0; l_i<strlen(p_src) && l_i<=p_destMaxLength; l_i++)
   {
      if( isalpha(p_src[l_i]))
      {
         p_dest[l_i] = toupper(p_src[l_i]);
      }
      else
      {
         p_dest[l_i] = p_src[l_i];
      }
   }
}


void hexToString(unsigned char *str, int p_maxStrSize, unsigned char *hex, int p_hexSize)
{
   int l_count, l_j;
   if(p_maxStrSize < (p_hexSize*3))
   {
      str[0] = '\0';
      return;
   }
   for(l_count=0,l_j=0;l_count<p_hexSize;l_count++,l_j=l_j+3)
   {
      str[l_j+1] = ((hex[l_count])&(0x0F));
      str[l_j] = ((hex[l_count]&0xF0)>>4);

      ((0x0A <= str[l_j]) && (0x0F >= str[l_j]))?str[l_j] += 55:str[l_j] += 48;
      ((0x0A <= str[l_j+1]) && (0x0F >= str[l_j+1]))?str[l_j+1] += 55:str[l_j+1] += 48;
      str[l_j+2] = ' ';
   }
   str[l_j]='\0';
}


void convertHextoIPV4(string& p_addrInHex, char *p_IPv4Addr)
{
   sprintf(p_IPv4Addr, "%u.%u.%u.%u", p_addrInHex[0]&0xFF, p_addrInHex[1]&0xFF, p_addrInHex[2]&0xFF, p_addrInHex[3]&0xFF);
}


u8 reverseByte(u8 x) 
{
   u8 y;
   u8 m = 1;
   while (m) {
      y >>= 1;
      if (m&x) {
         y |= 0x80;
      }
      m <<=1;
   }
   return y;
}

bool getOpCodeName(int p_opCode, char* p_opCodeName)
{
   if( ( (p_opCode >= MAP_OP_CODE_dummy_1 && p_opCode <= MAP_OP_CODE_MAXIMUM)) || 
         (  p_opCode >= DIAM_COMM_CODE_S6A_S6D_ULR_ULA && p_opCode <= DIAM_COMM_CODE_S6A_S6D_NOR_NOA)  ||
         (p_opCode == DIAM_COMM_CODE_SLH_RIR_RIA)  ||((p_opCode >= DIAM_COMM_CODE_CX_DX_UAR_UAA) && (p_opCode <= DIAM_COMM_CODE_SH_PNR_PNA) )
     )
   {
      if(p_opCode >= DIAM_COMM_CODE_S6A_S6D_ULR_ULA)
      {
         sprintf(p_opCodeName,"%s",DiameterConstants::getDiameterCommandCodeChar(p_opCode));
      }
      else if(((p_opCode >= DIAM_COMM_CODE_CX_DX_UAR_UAA)&& (p_opCode <= DIAM_COMM_CODE_SH_PNR_PNA)))
      {
         sprintf(p_opCodeName,"%s",DiameterConstants::getDiameterCommandCodeChar(p_opCode));
      }
      else
      {
         sprintf(p_opCodeName,"%s",MapConstants::getMapOpCodeChar(p_opCode));
      }
      DLOG(0,0,"OpcodeName[%s]",p_opCodeName);
      return true;
   }
   else
   {
      CLOG(0,0,"Invalid Opcode[%d]",p_opCode);
      p_opCodeName = NULL;
      return false;
   }
}

//4.0.2.0 for IMEI encryption
bool DES_Encryption(unsigned char *original, unsigned char *encrypted, unsigned char *key, int type)
{
   DES_key_schedule l_ks;
   DES_set_key((const_DES_cblock *)key, &l_ks);
   DES_cblock l_iv = { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };

   if(type == ENCRYPTION)
   {
      DES_ncbc_encrypt(original, encrypted, 16, &l_ks, &l_iv, DES_ENCRYPT);
   }
   else if(type == DECRYPTION)
   {
      DES_ncbc_encrypt(encrypted, original, 16 , &l_ks, &l_iv, DES_DECRYPT);
   }
   else
      return false;

   return true;
}

void hexToStringWithoutSpace(unsigned char *str, int p_maxStrSize, unsigned char *hex, int p_hexSize)
{
   int l_count, l_j;
   if(p_maxStrSize < (p_hexSize*3))
   {
      str[0] = '\0';
      return;
   }
   for(l_count=0,l_j=0;l_count<p_hexSize;l_count++,l_j=l_j+2)
   {
      str[l_j+1] = ((hex[l_count])&(0x0F));
      str[l_j] = ((hex[l_count]&0xF0)>>4);

      ((0x0A <= str[l_j]) && (0x0F >= str[l_j]))?str[l_j] += 55:str[l_j] += 48;
      ((0x0A <= str[l_j+1]) && (0x0F >= str[l_j+1]))?str[l_j+1] += 55:str[l_j+1] += 48;
      //str[l_j+2] = ' ';
   }
   str[l_j]='\0';
}



bool Copy_encryptedIMEI(char *Orig_IMEI, char* Encrypt_IMEI)
{
   unsigned char Encrypt_KEY[]="Pl!nTr0n";

   /* DES Encryption */
   bool result=DES_Encryption((unsigned char*)Orig_IMEI,(unsigned char*)Encrypt_IMEI,Encrypt_KEY,ENCRYPTION);
   //LLOG_HEX(0,0,"Encrypted IMEI: ",Encrypt_IMEI,16);

   return result;
}

bool Copy_Decrypt_IMEI(char *p_imei)
{
   unsigned char Encrypt_KEY[]="Pl!nTr0n";
   unsigned char Orig_IMEI[200];
   memset((char*)Orig_IMEI,'\0',sizeof(Orig_IMEI));

   /* ascii to hexadecimal conversion */
   char hx_imei[200];
   memset(hx_imei,'\0',sizeof(hx_imei));
   atohx(hx_imei,(char*)p_imei);

   /* DES decryption */
   bool result=DES_Encryption(Orig_IMEI,(unsigned char*)hx_imei,Encrypt_KEY,DECRYPTION);

   if(result == true)
   {
      memset(p_imei,'\0',(int)strlen(p_imei));
      int l_imeiLen = strlen((char*)Orig_IMEI); 
      if( Orig_IMEI[l_imeiLen-1] == ' ' ) // trimming last byte space if found
         l_imeiLen = l_imeiLen - 1;       //or .. Orig_IMEI[l_imeiLen-1] = '\0'
      strncpy(p_imei,(char*)Orig_IMEI,l_imeiLen);
   }
   return result;
}


#ifdef Linux

void strlcat(char *p_dest, char *p_src, int p_maxLength)
{
   int l_lengthOfDest=strlen(p_dest);
   int l_lengthOfSrc=strlen(p_src);
   if(l_lengthOfSrc+l_lengthOfDest < p_maxLength)
   {
      snprintf(p_dest+l_lengthOfDest, p_maxLength-l_lengthOfDest-1, "%s", p_src);
   }
}
#endif
