#include <ContextBase.h>
#include <Logger.h>
#include <ToolInterface.h>
#include <ServiceCoordinator.h>
#include <ModuleManager.h>
#include <typeinfo>
#include <DiametriqInterface.h>
#include <SccpMsg.h>
#include <StatisticsInterface.h>
#define MAX_SL_CONTEXTS   99999999

char g_SlCurrentCtxtTraceEnabledFlag=' ';
char g_SlCurrentIMSI[20+1];
char g_SlCurrentMSISDN[20+1];
int  g_SlCurrentContext=0;
int  g_SlContexts=0;
long g_TotalContexts=0;
int  g_SlCurrentRscType=0;
int  g_SlActiveContexts=0;
char g_SlModName[4];
char g_SlMessageName[4];
extern int g_MsgContexts;





map<string,ContextInfo*>           g_activeContextMap;
map<string,ContextInfo*>::iterator g_activeContextMapIterator;

map<int,int>::iterator g_removeItr;




ContextBase::ContextBase() : Msg(MSG_TYPE_CNTXT)
{
   ++g_SlActiveContexts;
   ++g_TotalContexts;
   if (MAX_SL_CONTEXTS == ++g_SlContexts)
   {
      g_SlContexts=1;
   }
   setGlobalContextId(g_SlContexts);

   TLOG(0,0,"ContextBase::ContextBase() [%s] created[%d]", typeid(*this).name(), getGlobalContextId());
   //printf("\nCreating [%d] [%s]", getGlobalContextId(), typeid(*this).name());
   m_flaggedToDelete=false;
   m_ReferenceCount=0;
   m_InitialRespondingDlgId=-1;
   m_InitialRespondingVersion = MAP_V_UNKNOWN;
   memset(m_ModName, '\0', 3+1);
   strcpy(m_ModName, "MOD");
   memset(m_MessageName, '\0', 3+1);
   strcpy(m_MessageName, "MSG");

   memset(m_TraceImsi, '\0', 20+1);
   memset(m_TraceMsisdn, '\0', 20+1);
   m_TraceEnabledFlag=' ';

   char l_dateString[20+1];
   memset(l_dateString, '\0', sizeof(l_dateString));
   struct tm *l_tm_ptr=NULL;
   time_t l_tim =time(NULL);
   l_tm_ptr = localtime(&l_tim);
   sprintf(l_dateString, "%04d%02d%02d%02d%02d%02d",
         l_tm_ptr->tm_year+1900, l_tm_ptr->tm_mon+1, l_tm_ptr->tm_mday,
         l_tm_ptr->tm_hour, l_tm_ptr->tm_min, l_tm_ptr->tm_sec);
  struct timeval l_dummyTv;
  memset(&l_dummyTv,'\0',sizeof(l_dummyTv));
  memset(&m_pTv,'\0',sizeof(m_pTv));
  memset(&m_rTv,'\0',sizeof(m_rTv));
  memset(&m_oldTv,'\0',sizeof(m_oldTv));
  getTime(m_oldTv, l_dummyTv, NULL, NULL);
   m_tdr.m_HDR[TDR_HDR_RECEIVED_TIMESTAMP] = l_dateString;
   LLOG(0,0,"ContextBase CONSTRUCTOR ActiveContexts[%d] ActiveMsgs[%d] typeid[%s] classname[%s] globalctxid[%d]",g_SlActiveContexts,g_MsgContexts,typeid(*this).name(), (char*)m_className.c_str(), getGlobalContextId());
}

ContextBase::~ContextBase()
{
   --g_SlActiveContexts;

   char l_ctxtId[20+1];
   memset(l_ctxtId, '\0', sizeof(l_ctxtId));
   sprintf(l_ctxtId, "%3s%3s:%08d", m_ModName, m_MessageName, m_GlobalContextId);
   m_tdr.setContextId(l_ctxtId);
   m_tdr.setTdrId();

   g_activeContextMapIterator = g_activeContextMap.find(m_className);
   if (g_activeContextMapIterator != g_activeContextMap.end())
   {
      g_activeContextMap[m_className]->m_count--;

      g_removeItr = g_activeContextMap[m_className]->m_activeContextList.find(m_GlobalContextId);
      if (g_removeItr != g_activeContextMap[m_className]->m_activeContextList.end())
      {
         TLOG(0,1,"Removing %d from the active context list map", m_GlobalContextId);
         g_activeContextMap[m_className]->m_activeContextList.erase(m_GlobalContextId);
      }
   }
   else
   {
      ELOG(0,1,"Unable to get from the map while deleting the context");
   }
   TLOG(0,0,"ContextBase::~ContextBase() [%s] destroyed[%d]", (char*)m_className.c_str(), getGlobalContextId());

   if (true == g_ConfigData->m_TdrEnabledFlag)
   {
      if(g_tfb != NULL)
      {
         DLOG(0,1,"HDR OPCODE INDEX %s", m_tdr.m_HDR[TDR_HDR_OP_CODE_INDEX].c_str());
         int l_opcodeInt = atoi(m_tdr.m_HDR[TDR_HDR_OP_CODE_INDEX].c_str());
         DLOG(0,1,"Calling prepare TDR %d", l_opcodeInt);
         EMsgType l_msgType = MSG_TYPE_MAP;;
         if( 0 == strcmp("SCCP", (char*)m_tdr.m_HDR[TDR_HDR_OP_CODE_INDEX].c_str()) )
         {
           DLOG(0,0,"SCCP: MSG_TYPE_SCCP set for TDR writing");
           l_msgType = MSG_TYPE_SCCP;
         }
         if(l_opcodeInt >= 300)
         {
            l_msgType = MSG_TYPE_DIAMETER;
         }
         if(8388622 == l_opcodeInt)
         {
               LLOG(0,0,"Updating OpCodeIndex to 350");
               l_opcodeInt=350; //TODO: Little silly, but lets live
         }

         /*bool l_skipOpCodeTdrCheck = false;
         if( (110 == l_opcodeInt) || (111 == l_opcodeInt) || (112 == l_opcodeInt) )
         {
            DLOG(0,0,"Opcode tdr enable flag to be skipped for opcode[%d]",l_opcodeInt);
            l_skipOpCodeTdrCheck = true;
         }
         if ( (1 == g_mm.m_mapping[l_msgType][l_opcodeInt].m_tdrRequiredFlag) || (true == l_skipOpCodeTdrCheck) )*/

         if ( 1 == g_mm.m_mapping[l_msgType][l_opcodeInt].m_tdrRequiredFlag )
         {
            DLOG(0,1,"TDR_HDR_REMOTE_PARTY_SSN_INDEX OpCode:%d, %s", l_opcodeInt, m_tdr.m_HDR[TDR_HDR_REMOTE_PARTY_SSN_INDEX].c_str());
            if( (1 != l_opcodeInt) ||  ((1 == l_opcodeInt) && (atoi(m_tdr.m_HDR[TDR_HDR_REMOTE_PARTY_SSN_INDEX].c_str()) <= 1)) )
            {
               char l_buf[3000];
               memset(l_buf, '\0', sizeof(l_buf));
               
               char l_ctxtId[20+1];
               memset(l_ctxtId, '\0', sizeof(l_ctxtId));
               
               if(0 == strcmp("GSMISD",m_tdr.m_HDR[TDR_HDR_ORIGINATING_MODULE].c_str()))
               {
                  DLOG(0,0,"Considering TDR as FULL ISD GSM");
                  sprintf(l_ctxtId, "%s:%08d", "MMMISD", m_GlobalContextId);
                  m_tdr.setContextId(l_ctxtId);
                  //m_tdr.setContextId("MMMISD");
                  m_tdr.setOpCode(7);
               }
               else if(0 == strcmp("GPRSISD",m_tdr.m_HDR[TDR_HDR_ORIGINATING_MODULE].c_str()))
               {
                  DLOG(0,0,"Considering TDR as FULL ISD GPRS");
                  sprintf(l_ctxtId, "%s:%08d", "MMMISD", m_GlobalContextId);
                  m_tdr.setContextId(l_ctxtId);
                  //m_tdr.setContextId("MMMISD");
                  m_tdr.setOpCode(7);
               }
               else if(0 == strcmp("MMEIDR",m_tdr.m_HDR[TDR_HDR_ORIGINATING_MODULE].c_str()))
               {
                  DLOG(0,0,"Considering TDR as FULL IDR MME");
                  sprintf(l_ctxtId, "%s:%08d", "LMMIDR", m_GlobalContextId);
                  m_tdr.setContextId(l_ctxtId);
                  //m_tdr.setContextId("LMMIDR");
                  m_tdr.setOpCode(319);
               }
               struct timeval l_prevTv, l_diffTv;
	       memset(&l_prevTv,'\0',sizeof(l_prevTv));
	       memset(&l_diffTv,'\0',sizeof(l_diffTv));

               struct timeval l_oldTv = m_oldTv;
               getTime(l_oldTv, l_prevTv, "DiffTime", &l_diffTv); // D:

               char l_diffTimeD[30+1];
               memset(l_diffTimeD,'\0',sizeof(l_diffTimeD));
               snprintf(l_diffTimeD,sizeof(l_diffTimeD),"%d:D:%d.%06d",l_opcodeInt,l_diffTv.tv_sec, l_diffTv.tv_usec);
               m_tdr.setString(167, l_diffTimeD); //Writes TDR in 176 index 
               

               bool l_diamMsg = false;
               if(l_opcodeInt >= 300)
               {
                  l_diamMsg = true;
                  StatisticsInterface::DiffTimeStatisticsForDiamMsg(&l_diffTv);	

		       struct timeval l_current,l_diffPush_Pop,l_diffPop_Sent,l_diffSent_Current;
		       memset(&l_current,'\0',sizeof(l_current));
		       memset(&l_diffPush_Pop,'\0',sizeof(l_diffPush_Pop));
		       memset(&l_diffPop_Sent,'\0',sizeof(l_diffPop_Sent));
		       memset(&l_diffSent_Current,'\0',sizeof(l_diffSent_Current));

		       char l_diffTimeP[30+1],l_diffTimeR[30+1],l_diffTimeS[30+1];
		       memset(l_diffTimeP,'\0',sizeof(l_diffTimeP));
		       memset(l_diffTimeR,'\0',sizeof(l_diffTimeR));
		       memset(l_diffTimeS,'\0',sizeof(l_diffTimeS));

		       if(0 != m_pTv.tv_sec)
		       {	 	  
			       getTime2(m_pTv,m_oldTv,"Push - Pop",&l_diffPush_Pop);
			       snprintf(l_diffTimeP,sizeof(l_diffTimeP),"P:%d.%06d",l_diffPush_Pop.tv_sec, l_diffPush_Pop.tv_usec);
			       m_tdr.setString(168, l_diffTimeP); //Writes TDR in 177 index
		       }
		       else
		       {
			       LLOG(0,0,"DiffTime Calculation not required for Outbound request[%d]",l_opcodeInt);
		       }

		       if(0 != m_rTv.tv_sec)
		       {
			       getTime2(m_rTv,m_pTv,"Pop - Sent",&l_diffPop_Sent);   
			       snprintf(l_diffTimeR,sizeof(l_diffTimeR),"R:%d.%06d",l_diffPop_Sent.tv_sec, l_diffPop_Sent.tv_usec);
			       m_tdr.setString(169, l_diffTimeR); //Writes TDR in 178 index
			       getTime(m_rTv,l_current,"Sent - Current",&l_diffSent_Current);   
			       snprintf(l_diffTimeS,sizeof(l_diffTimeS),"S:%d.%06d",l_diffSent_Current.tv_sec, l_diffSent_Current.tv_usec);
			       m_tdr.setString(170, l_diffTimeS); //Writes TDR in 179 index

		       }
		       else
		       { 
			       LLOG(0,0,"DiffTime Calculation not required for Outbound request[%d]",l_opcodeInt);
		       }


	       }
               else
               {
                  StatisticsInterface::DiffTimeStatisticsForMapMsg(&l_diffTv);	
               }
               char l_diffTimeStr[30+1];
               memset(l_diffTimeStr,'\0',sizeof(l_diffTimeStr));

               //m_tdr.setRemoteAddr(l_diffTime);	
               if(l_diffTv.tv_sec >= 10)
               {
                  snprintf(l_diffTimeStr,sizeof(l_diffTimeStr),"%s","diffTime >= 10s");
                  m_tdr.setString(171, l_diffTimeStr); //Writes TDR in 180 index
               }
               else if((l_diffTv.tv_sec >= 5) && (l_diffTv.tv_sec < 10))
               {	
                  snprintf(l_diffTimeStr,sizeof(l_diffTimeStr),"%s","diffTime >= 5s and < 10s");
                  m_tdr.setString(171, l_diffTimeStr); //Writes TDR in 180 index

               }
               else if((l_diffTv.tv_sec >= 1) && (l_diffTv.tv_sec < 5))
               {		
                  snprintf(l_diffTimeStr,sizeof(l_diffTimeStr),"%s","diffTime >= 1s and < 5s");
                  m_tdr.setString(171, l_diffTimeStr); //Writes TDR in 180 index
               }
               else if((l_diffTv.tv_usec >= 500000) && (l_diffTv.tv_sec < 1))
               {		
                  snprintf(l_diffTimeStr,sizeof(l_diffTimeStr),"%s","diffTime >= 0.5s and < 1s");
                  m_tdr.setString(171, l_diffTimeStr); //Writes TDR in 180 index
               }
               else if(((l_diffTv.tv_usec >= 200000) && (l_diffTv.tv_usec < 500000)) && (true == l_diamMsg))
               {		
                  snprintf(l_diffTimeStr,sizeof(l_diffTimeStr),"%s","diffTime >= 0.2s and < 0.5s");
                  m_tdr.setString(171, l_diffTimeStr); //Writes TDR in 180 index
               }
               else if(((l_diffTv.tv_usec >= 100000) && (l_diffTv.tv_usec < 200000)) && (true == l_diamMsg))
               {		
                  snprintf(l_diffTimeStr,sizeof(l_diffTimeStr),"%s","diffTime >= 0.1s and < 0.2s");
                  m_tdr.setString(171, l_diffTimeStr); //Writes TDR in 180 index
               }
               else if(((l_diffTv.tv_usec >= 50000) && (l_diffTv.tv_usec < 100000)) && (true == l_diamMsg))
               {		
                  snprintf(l_diffTimeStr,sizeof(l_diffTimeStr),"%s","diffTime >= 0.05s and < 0.1s");
                  m_tdr.setString(171, l_diffTimeStr); //Writes TDR in 180 index
               }
               else if(((l_diffTv.tv_usec >= 20000) && (l_diffTv.tv_usec < 50000)) && (true == l_diamMsg))
               {		
                  snprintf(l_diffTimeStr,sizeof(l_diffTimeStr),"%s","diffTime >= 0.02s and < 0.05s");
                  m_tdr.setString(171, l_diffTimeStr); //Writes TDR in 180 index
               }
               else if(((l_diffTv.tv_usec >= 10000) && (l_diffTv.tv_usec < 20000)) && (true == l_diamMsg))
               {		
                  snprintf(l_diffTimeStr,sizeof(l_diffTimeStr),"%s","diffTime >= 0.01s and < 0.02s");
                  m_tdr.setString(171, l_diffTimeStr); //Writes TDR in 180 index
               }
               else if(((l_diffTv.tv_sec >= 0) && (l_diffTv.tv_usec < 10000)) && (true == l_diamMsg))
               {		
                  snprintf(l_diffTimeStr,sizeof(l_diffTimeStr),"%s","diffTime >= 0s and < 0.01s");
                  m_tdr.setString(171, l_diffTimeStr); //Writes TDR in 180 index
               }
               else
               {		
                  snprintf(l_diffTimeStr,sizeof(l_diffTimeStr),"%s","diffTime >= 0s and < 0.5s");
                  m_tdr.setString(171, l_diffTimeStr); //Writes TDR in 180 index
               }

               g_tfb->prepareTDR(&m_tdr, l_buf, 0);
               LLOG(0,1,"Prepared TDR [%s]", l_buf);
               g_TdrObj.log2(LOG_LEVEL_CRITICAL, __FILE__, __FUNCTION__, __LINE__, 0, 0, l_buf);
            }
            else
            {
               int l_numOfTdrs = atoi(m_tdr.m_HDR[TDR_HDR_REMOTE_PARTY_SSN_INDEX].c_str());
               for(int l_i=1; l_i<=l_numOfTdrs; l_i++)
               {
                  char l_buf[3000];
                  memset(l_buf, '\0', sizeof(l_buf));
                  g_tfb->prepareTDR(&m_tdr, l_buf, l_i);
                  LLOG(0,1,"Prepared TDR [%d of %d] [%s]", l_i, l_numOfTdrs, l_buf);
                  g_TdrObj.log2(LOG_LEVEL_CRITICAL, __FILE__, __FUNCTION__, __LINE__, 0, 0, l_buf);
               }
            }
         }
         else
         {
            DLOG(0,0,"##### else block #####");
         }
      }
   }
   LLOG(0,0,"ContextBase DESTRUCTOR ActiveContexts[%d] ActiveMsgs[%d] typeid[%s] classname[%s] globalctxid[%d]",g_SlActiveContexts,g_MsgContexts,typeid(*this).name(), (char*)m_className.c_str(), getGlobalContextId());

}

void ContextBase::setClassName(char *p_name)
{
   char *l_className = p_name;
   if (l_className[0] >= '0' && l_className[0] <= '9')
   {
      l_className++;
   }
   if (l_className[0] >= '0' && l_className[0] <= '9')
   {
      l_className++;
   }
   m_className.assign(l_className, strlen(l_className));

   g_activeContextMapIterator = g_activeContextMap.find(m_className);
   if (g_activeContextMapIterator != g_activeContextMap.end())
   {
      g_activeContextMap[m_className]->m_count++;
      g_activeContextMap[m_className]->m_totalReceivedCount++;
      g_activeContextMap[m_className]->m_activeContextList[m_GlobalContextId]=1;
   }
   else
   {
      TLOG(0,1,"Inserting into map: %s", (char*)m_className.c_str());
      ContextInfo *l_ci = new ContextInfo;
      l_ci->m_count=1;
      l_ci->m_totalReceivedCount=1;
      l_ci->m_failureCount=0;
      l_ci->m_activeContextList[m_GlobalContextId]=1;
      g_activeContextMap.insert(pair<string,ContextInfo*>(m_className,l_ci));
   }
}

bool ContextBase::setTraceImsi(char *p_imsi)
{
   LLOG(0,0,"EVENT_TRACER: START IMSI:%s", p_imsi);
   map<string, int>::iterator l_it;
   l_it = g_TraceImsiMap.find(p_imsi);
   if (l_it != g_TraceImsiMap.end())// matches the list of IMSIs
   {
      printf("\nSetting trace imsi for the subscriber");
      strcpy(m_TraceImsi, p_imsi);
      m_TraceEnabledFlag= 'I';

      g_SlCurrentCtxtTraceEnabledFlag = 'I';
      strcpy(g_SlCurrentIMSI, m_TraceImsi);
   }
   return true;
}

bool ContextBase::setTraceMsisdn(char *p_msisdn)
{
   LLOG(0,0,"EVENT_TRACER: START MSISDN:%s", p_msisdn);
   map<string, int>::iterator l_it;
   l_it = g_TraceMsisdnMap.find(p_msisdn);
   if (l_it != g_TraceMsisdnMap.end())// matches the list of MSISDNs
   {
      printf("\nSetting trace msisdn for the subscriber");
      strcpy(m_TraceMsisdn, p_msisdn);
      m_TraceEnabledFlag= 'M';

      g_SlCurrentCtxtTraceEnabledFlag = 'M';
      strcpy(g_SlCurrentMSISDN, m_TraceMsisdn);
   }
   return true;
}



int ContextBase::getInitialRespondingDlgId()
{
   return m_InitialRespondingDlgId;
}

EMapVersion ContextBase::getInitialRespondingVersion()
{
   return m_InitialRespondingVersion;
}


bool ContextBase::startProcessing()
{
   CLOG(0,0,"ContextBase::startProcessing ERROR!! This should never get called");
   return false;
}

bool ContextBase::startProcessing(InterModuleData *p_data, bool& p_DeleteFlag)
{
   ELOG(0,0,"ContextBase::startProcessing ERROR!! This should never get called with flag [%d]", p_DeleteFlag);
   if (p_data != NULL)
   {
      DLOG(0,1,"Intermodule data present");
   }
   return false;
}


void ContextBase::setGlobalContextId(int p_Id)
{
   m_GlobalContextId =  p_Id;       
}

int  ContextBase::getGlobalContextId()
{
   return m_GlobalContextId;
}


bool ContextBase::sendMapOpenResponse(int p_UserDlgId, char *p_origGt, int p_origSsn)
{
   MapOpenRsp l_mor;
   l_mor.m_UserDlgId = p_UserDlgId;
   l_mor.m_ResponseChoiceFlag = true;
   if(p_origGt != NULL)
   {
      if (strlen(p_origGt) > 1)
      {
         char l_gt[50];
         memset(l_gt, '\0', sizeof(l_gt));
         GetNetworkHlrAddr((u8*)l_gt, (u8*)p_origGt);
         configureSccpAddress(&l_mor.m_OrigAddr, 0, 0, p_origSsn, l_gt);
         int l_tdrIndex = g_tfb->getTdrIndex(TDR_APP_ORIGINATING_HLR_GT); //added in 4.0.1.0
         m_tdr.setString(l_tdrIndex, l_gt);
         g_sc.sendMsg(this, &l_mor);
      }
      else
      {
         ELOG(0,1,"p_origGt is null");
      }
   }
   else
   {
      ELOG(0,1,"Invalid GT");
      return false;
   }
   return true;
}


bool ContextBase::CallProcMsg(Msg *p_MsgPtr)
{
   bool l_status = false;
   g_SlCurrentContext = getGlobalContextId();
   strcpy(g_SlCurrentIMSI, m_TraceImsi);
   strcpy(g_SlCurrentMSISDN, m_TraceMsisdn);
   g_SlCurrentCtxtTraceEnabledFlag = m_TraceEnabledFlag;

   //printf("\nCallProcMsg: -%c- -%s- -%s-", g_SlCurrentCtxtTraceEnabledFlag, g_SlCurrentIMSI, g_SlCurrentMSISDN);
   g_SlCurrentRscType=(int)m_RscType;

   DLOG(0,1,"CallProcMsg Reference Count %d %s", m_ReferenceCount, (char*)m_className.c_str());

   strcpy(g_SlModName, m_ModName);
   strcpy(g_SlMessageName, m_MessageName);
   try
   {
      bool l_deleteFlag=true;
      l_status = processMessage(p_MsgPtr, l_deleteFlag);       
      if(false == l_status)
      {
         DLOG(0,1,"processMessage returned false");
      }

      if ( (MSG_TYPE_MAP == p_MsgPtr->m_MsgType)  &&
            (MAP_MSG_TYPE_SPECIFIC == ((MapMsg*)p_MsgPtr)->m_MapMsgType)
         )
      {
         g_SlCurrentCtxtTraceEnabledFlag = m_TraceEnabledFlag;
         if ( (g_SlCurrentContext != 0) && (' ' != g_SlCurrentCtxtTraceEnabledFlag) && (1 == g_ConfigData->m_TracingEnabledFlag))
         {
            logOSSPDU((MapSpecificMsg*)p_MsgPtr);
         }
      }

      if (true == l_deleteFlag)
      {
         DLOG(0,1,"Deleting the message ...");

         switch (p_MsgPtr->m_MsgType)
         {
            case MSG_TYPE_MAP:
               delete( ((MapMsg*)p_MsgPtr));
               break;

            case MSG_TYPE_DB:  
               {
                  delete( ((DbQueryMsg*)p_MsgPtr));
               }
               break;

            case MSG_TYPE_MEMCACHED:  
               {
                  delete( ((MemCachedQueryMsg*)p_MsgPtr));
               }
               break;

            case MSG_TYPE_TIMEOUT:  
               {
                  delete( ((TimeoutMsg*)p_MsgPtr));
               }
               break;

            case MSG_TYPE_DIAMETER:  
               {
                  delete( ((DiameterMsg*)p_MsgPtr));
               }
               break;
            case MSG_TYPE_SCCP:  
               {
                  delete( ((SccpMsg*)p_MsgPtr));
               }
               break;
            default: 
               ELOG(0,1,"Not deleting the message");
               break;
         }
      }
      DLOG(0,1,"CallProcMsg end");
   }
   catch (NoSuchAttributeException e)
   {
      ELOG(0,1,"ERROR!! Exception NoSuchAttributeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
   }
   catch (WrongCommandTypeException e)
   {
      ELOG(0,1,"ERROR!! Exception WrongCommandTypeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
   }
   catch (UnknownTypeException e)
   {
      ELOG(0,1,"ERROR!! Exception UnknownTypeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
   }
   catch (CodecException e)
   {
      ELOG(0,1,"ERROR!! Exception CodecException Caught: %s ,Error Cause: %s ",e.name(), e.what());
   }
   catch (...)
   {
      printf("\nException occurred while calling ProcMsg");
      CLOG(0,0,"ContextBase::CallProcMsg Exception occurred while calling ProcMsg");
   }
   g_SlCurrentContext = 0;
   memset(g_SlCurrentIMSI, '\0', 20+1);
   memset(g_SlCurrentMSISDN, '\0', 20+1);
   g_SlCurrentCtxtTraceEnabledFlag = ' ';

   DLOG(0,1,"CallProcMsg returning");
   return true;
}



