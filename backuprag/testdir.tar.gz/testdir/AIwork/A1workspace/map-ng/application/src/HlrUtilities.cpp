#include <HlrUtilities.h>
#include <Logger.h>

bool FormClXml(char *p_XmlReq,int p_NodeType,u8 *p_imsi,u8 *p_lmsi,u8 *p_ActHLRAddr,u8 *p_vlrno,int p_updateSubsdata)
{
   strcat(p_XmlReq,"<CANCEL_LOC><IMSI>");
   strcat(p_XmlReq,(char *)p_imsi);
   if(p_NodeType == 1)
   {
      strcat(p_XmlReq,"</IMSI><TYPE>GSM</TYPE><LMSI>");
   }
   else if(p_NodeType == 2)
   {
      strcat(p_XmlReq,"</IMSI><TYPE>GPRS</TYPE><LMSI>");
   }
   else
   {
      CLOG(0,0,"Invalid Node type %d received",p_NodeType);
      return false;
   }
   strcat(p_XmlReq,(char *)p_lmsi);
   strcat(p_XmlReq,"</LMSI><DEST_ADDRESS>");
   strcat(p_XmlReq,(char *)p_vlrno);
   strcat(p_XmlReq,"</DEST_ADDRESS><ORIG_ADDRESS>");
   strcat(p_XmlReq,(char *)p_ActHLRAddr);
   strcat(p_XmlReq,"</ORIG_ADDRESS><CL_TYPE>0</CL_TYPE><CLR_SUBS_DATA>");
   char l_UpdateFlag[2];
   snprintf(l_UpdateFlag,2,"%d",p_updateSubsdata);
   strcat(p_XmlReq,(char *)l_UpdateFlag);
   strcat(p_XmlReq,"</CLR_SUBS_DATA></CANCEL_LOC>");
   return true;
}
