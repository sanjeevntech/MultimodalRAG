#include <ConcreteStateMsc.h>
#include <ContextBase.h>
#include <ServiceCoordinator.h>
#include <ModuleManager.h>
#include <Logger.h>
#include <SnmpInterface.h>
#include <typeinfo>

extern ContextBase* createObject(MapMsg *p_MapMsgPtr, ERscType *p_rscType);
MapOpenInd *g_currentOpenIndPtr=NULL;

WaitForSvcPrimitiveMsc::WaitForSvcPrimitiveMsc()
{
   DLOG(0,1,"WaitForSvcPrimitiveMsc::WaitForSvcPrimitiveMsc() created");
}

WaitForSvcPrimitiveMsc::~WaitForSvcPrimitiveMsc()
{
   DLOG(0,1,"WaitForSvcPrimitiveMsc::~WaitForSvcPrimitiveMsc() created");
}

void sendReject(ContextBase *p_cb, int p_UserDlgId, int p_ApplCtxt, int p_Version)
{
   CLOG(0,1,"sendReject called");
   MapOpenRsp l_MapOpnRsp;
   l_MapOpnRsp.m_UserDlgId = p_UserDlgId;
   l_MapOpnRsp.m_ApplCntxt = (EMapApplicationContext)p_ApplCtxt;
   l_MapOpnRsp.m_Version= (EMapVersion)p_Version;
   l_MapOpnRsp.m_ResponseChoiceFlag = false;

   if (g_sc.sendMsg(p_cb, &l_MapOpnRsp) != true)
   {
      printf("ServiceCoordinator::instance()->sendMsg failed");
      ELOG(0,1,"WaitForSvcPrimitiveMsc::handle SpecificMsg has not arrived sendMsg OpenRsp failed");
      return;
   }
}

StatesMsc* WaitForSvcPrimitiveMsc::handle(CntxtMsc *p_CntxtMscPtr, Msg *p_MsgPtr)
{
   DLOG(0,1,"WaitForSvcPrimitiveMsc::handle() called");

   if (p_CntxtMscPtr == NULL)
   {
      CLOG(0,0,"Context Error");
      return NULL;
   }
   bool l_status = false;

   if (p_MsgPtr->m_MsgType == MSG_TYPE_MAP)
   {
      MapMsg *p_MapMsgPtr = (MapMsg*)p_MsgPtr;

      switch (p_MapMsgPtr->m_MapMsgType)
      {
         case MAP_MSG_TYPE_SPECIFIC:
            {
               switch (((MapSpecificMsg*)p_MapMsgPtr)->m_MapSpecificEventType)
               {
                  case MAP_SPEC_EVENT_INDICATION:
                     {
                        TLOG(0,1,"Storing the specific message");
                        p_CntxtMscPtr->setSpecificMsgPtr(p_MapMsgPtr);
                        return StatesMsc::m_pStWaitForSvcPrimitiveMsc;
                     }
                     break;

                  default:
                     {
                        CLOG(0,1,"ERR Got an invalid message in this state");
                        sendReject(p_CntxtMscPtr->m_pRsc, p_CntxtMscPtr->m_UserDlgId, 0, 0);

                        if (p_CntxtMscPtr->m_MapOpenIndPtr != NULL) // This is added for MapProvError case
                        {
                           delete(p_CntxtMscPtr->m_MapOpenIndPtr);
                           p_CntxtMscPtr->m_MapOpenIndPtr=NULL;
                        }
                        delete(p_MsgPtr);

                     }
                     break;
               }
            }
            break;

         case MAP_MSG_TYPE_COMMON:
            {
               switch ( ((MapCommonMsg*)p_MapMsgPtr)->m_MapCommonMsgType)
               {
                  case MAP_CMN_NOTICE_IND:
                     {
                        CLOG(0,1,"WaitForSvcPrimitiveMsc::handle Received MAP_CMN_NOTICE_IND message");
                        /*MapCloseReq l_MapClose(p_CntxtMscPtr->m_UserDlgId);
                          if (g_sc.sendMsg(p_CntxtMscPtr->m_pRsc, &l_MapClose) != true)
                          {
                          DLOG(0,1,"WaitForSvcPrimitiveMsc::handle Close Send Failed");
                          }*/
                        sendReject(p_CntxtMscPtr->m_pRsc, p_CntxtMscPtr->m_UserDlgId, 0, 0);
                        if (p_CntxtMscPtr->m_MapOpenIndPtr != NULL) 
                        {
                           delete(p_CntxtMscPtr->m_MapOpenIndPtr);
                           p_CntxtMscPtr->m_MapOpenIndPtr=NULL;
                        }
                        delete(p_MsgPtr);
                        return NULL;
                        break;
                     }

                  case MAP_CMN_DELIMITER_IND:
                     {
                        DLOG(0,1,"Processing MAP_CMN_DELIMITER_IND message");
                        bool l_reject = true;
                        if(
                              (MAP_AC_CODE_shortMsgMTRelay == ((MapOpenInd*)p_CntxtMscPtr->getOpenIndPtr())->m_ApplCntxt)  ||
                              (MAP_AC_CODE_shortMsgMORelay == ((MapOpenInd*)p_CntxtMscPtr->getOpenIndPtr())->m_ApplCntxt)
                          ) 
                        {
                           LLOG(0,0,"Empty Begin is allowed for ForwardSM Relaying to application");
                           l_reject = false;
                        }
                        if ((NULL == p_CntxtMscPtr->getSpecificMsgPtr()) && (true == l_reject))
                        {
                           CLOG(0,1,"No Specific Messages. Sending Abort");
                           sendReject(p_CntxtMscPtr->m_pRsc, p_CntxtMscPtr->m_UserDlgId, 0, 0);

                           if (p_CntxtMscPtr->m_MapOpenIndPtr != NULL) 
                           {
                              delete(p_CntxtMscPtr->m_MapOpenIndPtr);
                              p_CntxtMscPtr->m_MapOpenIndPtr=NULL;
                           }
                           if(NULL != p_MsgPtr)
                           {
                              delete(p_MsgPtr);
                           }

                           // Do we need to do a RECEIVE_OPEN_IND macro execution here?
                           return StatesMsc::m_pStWaitForSvcPrimitiveMsc;;
                        }
                        else
                        {
                           p_CntxtMscPtr->m_pRsc = NULL;
                           ERscType l_rscType = RSC_TYPE_UNKNOWN;
                           int l_opCode = MAP_OP_CODE_UNKNOWN;
                           int l_version = MAP_V_UNKNOWN;

                           if(NULL == p_CntxtMscPtr->getSpecificMsgPtr())
                           {
                              l_version = ((MapOpenInd*)p_CntxtMscPtr->getOpenIndPtr())->m_Version;
                              if(MAP_V3 == l_version)
                              {
                                 l_opCode = MAP_OP_CODE_mtForwardSM;
                              }
                              else
                              {
                                 l_opCode = MAP_OP_CODE_moForwardSM;
                              }
                           }
                           else
                           {
                              l_opCode = ((MapSpecificMsg*)p_CntxtMscPtr->getSpecificMsgPtr())->m_OpCode;
                              l_version = ((MapSpecificMsg*)p_CntxtMscPtr->getSpecificMsgPtr())->m_Version;
                           }
                           int l_opCodeIndex = l_opCode;

                           DLOG(0,1,"OpCode [%d] Module Name [%s] Message Name [%s]", l_opCode, 
                                 g_mm.m_mapping[MSG_TYPE_MAP][l_opCode].m_ModName,
                                 g_mm.m_mapping[MSG_TYPE_MAP][l_opCode].m_MessageName);

                           g_currentOpenIndPtr = (MapOpenInd*)(p_CntxtMscPtr->m_MapOpenIndPtr);
                           p_CntxtMscPtr->m_pRsc = g_mm.getRespectiveContext2(l_opCodeIndex, (MapSpecificMsg*)p_CntxtMscPtr->getSpecificMsgPtr());
                           bool l_versionSupportedFlag=false;
                           if (NULL == p_CntxtMscPtr->m_pRsc)
                           {
                              LLOG(0,1,"sc pointer is null");

                              l_opCodeIndex = l_opCode+100;

                              p_CntxtMscPtr->m_pRsc = g_mm.getRespectiveContext2(l_opCodeIndex, (MapSpecificMsg*)p_CntxtMscPtr->getSpecificMsgPtr());
                              if (NULL == p_CntxtMscPtr->m_pRsc)
                              {
                                 LLOG(0,1,"sc pointer is again null");
                              }
                           }

                           if (NULL != p_CntxtMscPtr->m_pRsc)
                           {
                              switch (l_version)
                              {
                                 case 1:
                                    l_versionSupportedFlag  = g_mm.m_mapping[MSG_TYPE_MAP][l_opCodeIndex].m_Map1Flag;
                                    break;
                                 case 2:
                                    l_versionSupportedFlag  = g_mm.m_mapping[MSG_TYPE_MAP][l_opCodeIndex].m_Map2Flag;
                                    break;
                                 case 3:
                                    l_versionSupportedFlag  = g_mm.m_mapping[MSG_TYPE_MAP][l_opCodeIndex].m_Map3Flag;
                                    break;
                                 default:
                                    l_versionSupportedFlag  = false;
                                    break;
                              }
                           }

                           if (false == l_versionSupportedFlag)
                           {
                              CLOG(0,1,"No functionality defined for Op Code [%d] and Version [%d]", l_opCode, l_version);

                              sendReject(p_CntxtMscPtr->m_pRsc, p_CntxtMscPtr->m_UserDlgId, 0, 0);

                              if (p_CntxtMscPtr->m_MapOpenIndPtr != NULL) 
                              {
                                 delete(p_CntxtMscPtr->m_MapOpenIndPtr);
                                 p_CntxtMscPtr->m_MapOpenIndPtr=NULL;
                              }
                              if(NULL != p_CntxtMscPtr->getSpecificMsgPtr())
                              {
                                 delete(p_CntxtMscPtr->getSpecificMsgPtr());
                              }
                              if(NULL != p_MsgPtr)
                              {
                                 delete(p_MsgPtr);
                              }
                              return NULL;
                           }

                           if (false == MapConstants::isApplCtxtOpCodeCombValid(
                                    ((MapOpenRequests*)p_CntxtMscPtr->getOpenIndPtr())->m_ApplCntxt, 
                                    (EMapOpCode)l_opCode))
                           {
                              CLOG(0,1,"Severe Error. Op Code [%d] and Appl Ctxt [%d] Doesn't match. Sending Abort.",
                                    l_opCode, ((MapOpenRequests*)p_CntxtMscPtr->getOpenIndPtr())->m_ApplCntxt);
                              sendReject(p_CntxtMscPtr->m_pRsc, p_CntxtMscPtr->m_UserDlgId, 0, 0);

                              if (p_CntxtMscPtr->m_MapOpenIndPtr != NULL) 
                              {
                                 delete(p_CntxtMscPtr->m_MapOpenIndPtr);
                                 p_CntxtMscPtr->m_MapOpenIndPtr=NULL;
                              }
                              if(NULL != p_CntxtMscPtr->getSpecificMsgPtr())
                              {
                                 delete(p_CntxtMscPtr->getSpecificMsgPtr());
                              }
                              if(NULL != p_MsgPtr)
                              {
                                 delete(p_MsgPtr);
                              }

                              g_si.sendSnmpTrap(g_OpCodeApplMismatchTrap, TRAP_TYPE_FAIL, TRAP_SEVERITY_MAJOR);
                              return NULL;
                           }


                           p_CntxtMscPtr->m_pRsc->setClassName((char*)(typeid(*(p_CntxtMscPtr->m_pRsc)).name()));
                           p_CntxtMscPtr->m_pRsc->m_RscType = l_rscType;

                           p_CntxtMscPtr->m_pRsc->m_UserDlgId = p_CntxtMscPtr->m_UserDlgId;
                           ///-p_CntxtMscPtr->m_pRsc->m_DlgId = p_CntxtMscPtr->m_DlgId;

                           p_CntxtMscPtr->m_pRsc->m_InitialRespondingDlgId   = p_CntxtMscPtr->getOpenIndPtr()->m_UserDlgId;
                           p_CntxtMscPtr->m_pRsc->m_InitialRespondingVersion = p_CntxtMscPtr->getOpenIndPtr()->m_Version;

                           strcpy(p_CntxtMscPtr->m_pRsc->m_ModName,	 g_mm.m_mapping[MSG_TYPE_MAP][l_opCodeIndex].m_ModName);
                           strcpy(p_CntxtMscPtr->m_pRsc->m_MessageName, g_mm.m_mapping[MSG_TYPE_MAP][l_opCodeIndex].m_MessageName);


                           //Adding TDR related things
                           if(g_tfb != NULL)
                           {
                              p_CntxtMscPtr->m_pRsc->m_tdr.setOpCode(l_opCode);
                              p_CntxtMscPtr->m_pRsc->m_tdr.setMapVersion((int)p_CntxtMscPtr->getOpenIndPtr()->m_Version);
                              p_CntxtMscPtr->m_pRsc->m_tdr.setRemoteAddr(((MapOpenInd*)p_CntxtMscPtr->getOpenIndPtr())->m_OrigAddr.globalTitle.addressInformation);
                              p_CntxtMscPtr->m_pRsc->m_tdr.setRemoteAddrSsn(((MapOpenInd*)p_CntxtMscPtr->getOpenIndPtr())->m_OrigAddr.ssn);
                              p_CntxtMscPtr->m_pRsc->m_tdr.setOriginatingModule("NWK");
                           }
                           //End of TDR related things


                           p_CntxtMscPtr->m_pRsc->m_ReferenceCount++;
                           // Call the Context's ProcMsg to process the Receive_Open_Ind macro
                           l_status = p_CntxtMscPtr->m_pRsc->CallProcMsg(p_CntxtMscPtr->getOpenIndPtr());
                           p_CntxtMscPtr->m_MapOpenIndPtr=NULL; // This is added to understand that OpenInd is received by the Context and it takes care of its deletion
                           if (p_CntxtMscPtr->m_pRsc->m_ReferenceCount == 0)
                           {
                              LLOG(0,1,"Deleting Context at the end of processing OpenInd");
                              delete(p_CntxtMscPtr->m_pRsc);
                              p_CntxtMscPtr->m_pRsc = NULL;
                              delete(p_CntxtMscPtr->getSpecificMsgPtr());
                              delete(p_MsgPtr);
                              return NULL;
                           }
                           else
                           {

                            if(NULL != p_CntxtMscPtr->getSpecificMsgPtr())
                            {
DLOG(0,0," NG TEST 1");
                              l_status = p_CntxtMscPtr->m_pRsc->CallProcMsg(p_CntxtMscPtr->getSpecificMsgPtr());
                              if (p_CntxtMscPtr->m_pRsc->m_ReferenceCount == 0)
                              {
                                 LLOG(0,1,"Deleting Context at the end of processing specific msg");
                                 delete(p_CntxtMscPtr->m_pRsc);
                                 p_CntxtMscPtr->m_pRsc = NULL;
                                 delete(p_MsgPtr);
                                 return NULL;
                              }
                              else
                              {
                                 if (p_CntxtMscPtr != NULL)
                                 {
                                    bool l_status2 = p_CntxtMscPtr->m_pRsc->CallProcMsg(p_MapMsgPtr);
                                    if (p_CntxtMscPtr->m_pRsc->m_ReferenceCount == 0)
                                    {
                                       LLOG(0,1,"Deleting Context at the end of processing del msg. flag:%d", l_status2);
                                       delete(p_CntxtMscPtr->m_pRsc);
                                       p_CntxtMscPtr->m_pRsc = NULL;
                                       return NULL;
                                    }
                                 }
                              }
                             }
                             else
                             {
DLOG(0,0," NG TEST 2");
                                 if (p_CntxtMscPtr != NULL)
                                 {
                                    bool l_status2 = p_CntxtMscPtr->m_pRsc->CallProcMsg(p_MapMsgPtr);
                                    if (p_CntxtMscPtr->m_pRsc->m_ReferenceCount == 0)
                                    {
                                       LLOG(0,1,"Deleting Context at the end of processing del msg. flag:%d", l_status2);
                                       delete(p_CntxtMscPtr->m_pRsc);
                                       p_CntxtMscPtr->m_pRsc = NULL;
                                       return NULL;
                                    }
                                 }
                             }
                           }
                           return StatesMsc::m_pStRelayInfoMsc;
                        }
                     }

                     break;

                  default:
                     ELOG(0,1,"Received %d message. Don't know what to do", 
                           ((MapCommonMsg*)p_MapMsgPtr)->m_MapMsgType);
                     break;
               }
            }
            break;

         default:
            ELOG(0,0,"Received an Unknown Request: %d", p_MapMsgPtr->m_MapMsgType);
            // ERROR
            break;
      }
   }
   return NULL;
}



RelayInfoMsc::RelayInfoMsc()
{
   DLOG(0,1,"RelayInfoMsc::RelayInfoMsc() created");
}

RelayInfoMsc::~RelayInfoMsc()
{
   DLOG(0,1,"RelayInfoMsc::~RelayInfoMsc() created");
}




StatesMsc* RelayInfoMsc::handle(CntxtMsc *p_CntxtMscPtr, Msg *p_MsgPtr)
{
   DLOG(0,1,"RelayInfoMsc::handle() called");
   if (p_CntxtMscPtr->m_pRsc != NULL)
   {
      if (false == p_CntxtMscPtr->m_pRsc->m_flaggedToDelete)
      {
         //DLOG(0,1,"RelayInfoMsc::handle calling context's ProcMsg");
         bool l_ContextResult = p_CntxtMscPtr->m_pRsc->CallProcMsg(p_MsgPtr);

         if ((p_CntxtMscPtr->m_pRsc != NULL) && (p_CntxtMscPtr->m_pRsc->m_ReferenceCount == 0))
         {
            LLOG(0,1,"Deleting Context at place 2. %d", l_ContextResult);
            delete(p_CntxtMscPtr->m_pRsc);
            p_CntxtMscPtr->m_pRsc = NULL;
            return NULL; //Added after Purify
         }
         else
         {
            DLOG(0,1,"RelayInfoMsc::handle Context Returning NOT NULL");
         }
      }
      else
      {
         ELOG(0,1,"RelayInfoMsc::handle flagged to delete is true");
      }
   }
   else
   {
      CLOG(0,0,"Some ERROR");
   }

   return StatesMsc::m_pStRelayInfoMsc;
}

