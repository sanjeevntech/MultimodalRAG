#include <CtxtUpdateExitStatus.h>
#include <stdio.h>
#include <Logger.h>
#include <DbActiveObject.h>
#include <ConfigReader.h>
#include <TcpSocketServer.h>
#include <ProvisioningMessages.h>
#include <SnmpInterface.h>
#include <GlobalData.h>
#include <string>
#include <UpdateInstanceStatus.h>
using namespace std;



#define MAX_TRANSACTIONS   5000


CtxtUpdateExitStatus::CtxtUpdateExitStatus()
{
   DLOG(0,0,"CtxtUpdateExitStatus::CtxtUpdateExitStatus() :cons:");
}

CtxtUpdateExitStatus::~CtxtUpdateExitStatus()
{
   DLOG(0,0,"CtxtUpdateExitStatus::~CtxtUpdateExitStatus() :des:");
}

bool CtxtUpdateExitStatus::startProcessing()
{
   DLOG(0,0,"start processing CtxtUpdateExitStatus called");
   UpdateInstanceStatus *l_oss = new UpdateInstanceStatus;
   l_oss->m_cb = this;
   l_oss->m_DbQueryType = 1;
   g_act.execute(l_oss);


   return true;
}

bool CtxtUpdateExitStatus::processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag)
{
   DLOG(0,0,"Start of CtxtUpdateExitStatus::processMsg function with flag %d", p_DeleteFlag);

   switch (p_MsgPtr->m_MsgType)
   {
      case MSG_TYPE_DB:
         {
            DLOG(0,0,"DB message received");
            switch (((DbQueryMsg*)p_MsgPtr)->m_DbQueryType)
            {
               case 1:
                  {
                     LLOG(0,0,"UpdateInstanceStatus response received");
                     UpdateInstanceStatus *l_oss = (UpdateInstanceStatus *)p_MsgPtr;

                     if(DB_QUERY_RES_SUCCESS == l_oss->m_DbQueryRes)
                     {
                        LLOG(0,0,"Success response UpdateInstanceStatus from DB");
                     }
                     else
                     {
                        LLOG(0,0,"UpdateInstanceStatus failed");
                     }
                  }
                  break;

               default:
                  {
                     ELOG(0,0,"Invalid DB Response Message Received");
                  }
                  break;
            }
         }
         break;

      default:
         {
            DLOG(0,0,"Unknown message received");
         }
         break;
   }
   return true;
}


