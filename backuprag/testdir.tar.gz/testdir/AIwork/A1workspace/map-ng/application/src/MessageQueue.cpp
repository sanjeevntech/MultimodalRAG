#include <MessageQueue.h>
#include <Logger.h>
#include <ConfigReader.h>
#include <sys/msg.h>



MessageQueue::MessageQueue(EQueueType p_QueueType, EQueuePersistenceType p_QueuePersistenceType)
{
   m_QueueType = p_QueueType;
   m_QueuePersistenceType = p_QueuePersistenceType;
   m_persMsgId=0;
   m_persKey=1;
   m_qcm = QUEUE_CONSUMING_MODEL_AS_IT_COMES;
   m_currentTrans = 0;
   m_lastSecond = 0;
   m_tps = 0;
   m_heartBeatInterval = 60;;
   m_thbRegisterFlag = false;
}


MessageQueue::~MessageQueue()
{
}

int get_queue_ds( int qid, struct msqid_ds *qbuf )
{
   if( msgctl( qid, IPC_STAT, qbuf) == -1)
   {
      return(-1);
   }
   return(0);
}


bool change_queue_size( int qid, int size )
{
   struct msqid_ds tmpbuf;

   /* Retrieve a current copy of the internal data structure */
   if (0 != get_queue_ds( qid, &tmpbuf))
   {
      ELOG(0,1,"get_queue_ds failed\n");
      return false;
   }

   /* Change the permissions using an old trick */
   tmpbuf.msg_qbytes = size;

   /* Update the internal data structure */
   if( msgctl( qid, IPC_SET, &tmpbuf) == -1)
   {
      return(-1);
   }

   return true;
}

int get_queue_size(int qid)
{
   struct msqid_ds tmpbuf;

   /* Retrieve a current copy of the internal data structure */
   if (0 != get_queue_ds( qid, &tmpbuf))
   {
      ELOG(0,1,"get_queue_ds failed\n");
      return 0;
   }

   return tmpbuf.msg_qnum;
}


int MessageQueue::size()
{
   if(QUEUE_PERSISTENCE_TYPE_NON_PERSISTENT == m_QueuePersistenceType)
   {
      return m_q.size();
   }
   else
   {
      return get_queue_size(m_persMsgId);
   }
}




bool MessageQueue::initialize()
{

   if (0 != pthread_mutex_init(&m_q_mutex, NULL))
   {
      printf("\nUnable to initialize the mutex");
      return false;
   }

   if (-1 == sem_init(&m_semaphore, 0, 0))
   {
      printf("\nUnable to initialize the semaphore [%d]", errno);
      return false;
   }

   if (0 != pthread_mutex_init(&m_tps_mutex, NULL))
   {
      printf("\nUnable to initialize the m_tps_mutex");
      ELOG(0,0,"Unable to initialize the tps mutex");
      return false;
   }

   if(QUEUE_PERSISTENCE_TYPE_PERSISTENT == m_QueuePersistenceType)
   {
      m_persMsgId =  msgget (2460+g_ConfigData->m_InstanceId, 0640|IPC_CREAT);
      if(m_persMsgId <0)
      {
         printf("\nIPC MessageQ creation failed, Key = %d, errno = %d, ErrText = %s",m_persKey, errno, strerror(errno));
         return false;
      }
      else
      {
         LLOG(0,1,"Message Queue PERSISTENT successfull: %d", m_persMsgId);
         return change_queue_size(m_persMsgId, 1000000);
      }
   }

   return true;
}




bool MessageQueue::push(void *p_qm, int p_length)
{
   if(QUEUE_PERSISTENCE_TYPE_NON_PERSISTENT == m_QueuePersistenceType)
   {
      DLOG(0,0,"push locking");
      pthread_mutex_lock(&m_q_mutex);
      DLOG(0,0,"push locking");
      m_q.push_back(p_qm);
      DLOG(0,0,"push locking");
      pthread_mutex_unlock(&m_q_mutex);
      DLOG(0,0,"push locking");
      sem_post(&m_semaphore);
      DLOG(0,0,"push locking");
   }
   else  //PERSISTENCE CASE
   {
      if ((p_length < 1) || (p_length > MAX_QUEUE_DATA_SIZE))
      {
         ELOG(0,1,"Invalid message data length: %d", p_length);
         return false;
      }
      else
      {
         TLOG(0,1,"MsgQ Push length: %d", p_length);
         mymsg l_msg;
         memset(&l_msg, '\0', sizeof(l_msg));
         l_msg.m_type = MSG_TYPE;
         memcpy(l_msg.m_text, p_qm, p_length);
         if(msgsnd(m_persMsgId, &l_msg, p_length, 0)<0)
         {
            ELOG(0,1,"MsgQ Send failed, MsgLen = %d, MsgId = %d, errno = %d, ErrText = %s",p_length, m_persMsgId, errno, strerror(errno));
            return false;
         }

         char *l_temp = (char*)p_qm;
         delete []l_temp;
      }
   }
   return true;
}


bool MessageQueue::pop(void **p_qm, EThbFlag p_thbFlag, string p_thread_name)
{
   if(QUEUE_PERSISTENCE_TYPE_NON_PERSISTENT == m_QueuePersistenceType)
   {
      
      if((p_thbFlag == THB_ENABLED) && (!m_thbRegisterFlag))
      {
         if(0 != g_OtherConfigData->m_THBEnabled)
         {
            int l_ThbInterval = 0;
            if(g_OtherConfigData->m_DbHeartBeatInterval > 0)
            {
               l_ThbInterval = g_OtherConfigData->m_DbHeartBeatInterval;
            }
            else
            {
               l_ThbInterval = 60;
            }
            if(false == g_thb.registerMe(l_ThbInterval, const_cast<char*>(p_thread_name.c_str())))
            {
               CLOG(1,1,"RegisterMe failed on %s",p_thread_name.c_str());
               exit(1);
            }
            m_thbRegisterFlag = true;

         }

      }
do_thb:
      if(m_thbRegisterFlag)
      {
         if((0 != g_OtherConfigData->m_THBEnabled) && ((g_simulateThbHungInterval == 0 ) || (time(NULL) >= g_currTimeForTHB + g_simulateThbHungInterval)))
         {
            if(false == g_thb.iAmAlive())
            {
               ELOG(0,1,"THB iAmAlive failed. Exiting...");
               exitFunc(EXIT_APPLICATION_TYPE_THB_I_AM_ALIVE_FAILED);
            }
         }
      }
 

      if( (m_QueueType == QUEUE_TYPE_BLOCKING) || (m_QueueType == QUEUE_TYPE_BLOCKING_TIMED_WAIT) )
      {
do_wait_loop:

         int l_sem_result = 0;
         if(m_QueueType == QUEUE_TYPE_BLOCKING)
         {
            //l_sem_result = sem_wait(&m_semaphore);
            if(p_thbFlag == THB_ENABLED)
            {
               struct timespec l_tv;
               if(g_OtherConfigData->m_DbHeartBeatInterval > 0)
               {
                  l_tv.tv_sec = g_OtherConfigData->m_DbHeartBeatInterval+time(NULL);
               }
               else
               {
                  l_tv.tv_sec = 60+time(NULL);
               }
               l_tv.tv_nsec = 0;
               l_sem_result = sem_timedwait(&m_semaphore, &l_tv);
            }
            else
            {
               l_sem_result = sem_wait(&m_semaphore);
            }
         }

         else
         {
            struct timespec l_tv;
            l_tv.tv_sec = m_heartBeatInterval+time(NULL);
            l_tv.tv_nsec = 0;
            l_sem_result = sem_timedwait(&m_semaphore, &l_tv);
         }
         if (-1 == l_sem_result)
         {
            if(EINTR == errno)
            {
               CLOG(0,0,"Received a EINTR signal. Waiting on semaphore again");
               goto do_wait_loop;
            }
            else if(ETIMEDOUT == errno)
            {
               if(m_QueueType == QUEUE_TYPE_BLOCKING && (p_thbFlag == THB_ENABLED))
               {
                  DLOG(0,0,"Blocking Queue and THB enabled");
                  goto do_thb;
               }

               TLOG(0,0,"Semaphore timedout");
               return false;
            }
            else
            {
               CLOG(0,0,"Semaphore interrupted [%d]", errno);
               switch (errno)
               {
                  case EINVAL:
                     CLOG(0,0,"EINVAL received");
                     break;
                  case ENOSYS:
                     CLOG(0,0,"ENOSYS received");
                     break;
                  case EAGAIN:
                     CLOG(0,0,"EAGAIN received");
                     break;
                  case EDEADLK:
                     CLOG(0,0,"EDEADLK received");
                     break;
                  case EINTR:
                     CLOG(0,0,"EINTR received");
                     break;
                  case ETIMEDOUT:
                     DLOG(0,0,"ETIMEDOUT received");
                     break;
                  default:
                     CLOG(0,0,"Unknown errno");
                     break;
               }
               return false;
            }
         }
      }
      else
      {
         // Do nothing
      }

      if(QUEUE_CONSUMING_MODEL_BASED_ON_TPS  == m_qcm)
      {
         DLOG(0,0,"QUEUE_CONSUMING_MODEL_BASED_ON_TPS based queue CurrentTime [%d] LastSecond [%d]", time(NULL), m_lastSecond);
come_back:

         pthread_mutex_lock(&m_tps_mutex);
         bool l_allow=true;
         int l_sleepInterval=100000;
         if(true == l_allow)
         {
            if(m_callback != NULL)
            {
               if(false == m_callback())
               {
                  DLOG(0,0,"callback returned false");
                  l_allow=false;
                  l_sleepInterval=100000;
               }
               else
               {
                  DLOG(0,0,"callback returned true");   //for Debug later needs to remove
               }
            }
            else
            {
               DLOG(0,0,"m_callback is NULL");  //for Debug later needs to remove
            }
         }
         if(false == l_allow)
         {
            //LLOG(0,0,"MessageQueue: TPS Based Queue. CurrentTrans[%d], MaxTps[%d]. So not popping", m_currentTrans, m_tps);
            if((m_QueueType == QUEUE_TYPE_BLOCKING) || (m_QueueType == QUEUE_TYPE_BLOCKING_TIMED_WAIT))
            {
               usleep(l_sleepInterval);
               --m_currentTrans;
               pthread_mutex_unlock(&m_tps_mutex);
               DLOG(0,0,"sleeping for [%d]  m_currentTrans[%d]", l_sleepInterval,m_currentTrans);
               goto come_back;
            }
            else //Non Blocking
            {
               DLOG(0,0,"non-blocking");
               --m_currentTrans;
               pthread_mutex_unlock(&m_tps_mutex);
               return false;
            }
         }
         else
         {
            DLOG(0,0,"Allowing the pop");
         }
         pthread_mutex_unlock(&m_tps_mutex);
      }

      pthread_mutex_lock(&m_q_mutex);

      if (m_q.size() != 0)
      {
         //printf("\nGetting a message from the queue");
         (*p_qm) = m_q[0];
         m_q.pop_front();
         pthread_mutex_unlock(&m_q_mutex);
      }
      else
      {
         pthread_mutex_unlock(&m_q_mutex);

         if (m_QueueType == QUEUE_TYPE_BLOCKING)
         {
            ELOG(0,0,"ERROR!!!!!!! Still No data thing coming");
            ELOG(0,0,"ERROR!!!!!!! MessageQueue::popMessage ended");
         }
         return false;
      }

////////////////////


   }
   else
   {
      mymsg l_msg;
      memset(&l_msg, '\0', sizeof(l_msg));
      l_msg.m_type = MSG_TYPE;
      int l_length=0;
      l_length= msgrcv(m_persMsgId, &l_msg, MAX_QUEUE_DATA_SIZE, 0, IPC_NOWAIT);

      if(l_length < 0)
      {
         if (ENOMSG == errno)
         {
            LLOG(0,1,"No messages in the message queue with MsgId = %d", m_persMsgId);
            return false;
         }
         else
         {
            CLOG(0,1,"Some other error MsgId = %d, errno = %d, ErrText = %s", m_persMsgId, errno, strerror(errno));
            return false;
         }
      }
      else
      {
         DLOG(0,1,"Successfully received the message: %d", l_length);
         *p_qm = new unsigned char[l_length+1];
         memcpy(*p_qm, l_msg.m_text, l_length);
      }
   }
   return true;
}





bool MessageQueue::pop_without_lock(void **p_qm)
{
   if(QUEUE_PERSISTENCE_TYPE_NON_PERSISTENT == m_QueuePersistenceType)
   {
      if (m_QueueType == QUEUE_TYPE_BLOCKING)
      {
         int l_sem_result = sem_wait(&m_semaphore);
         if (-1 == l_sem_result)
         {
            CLOG(0,0,"Semaphore interrupted [%d]", errno);
            switch (errno)
            {
               case EINVAL:
                  CLOG(0,0,"EINVAL received");
                  break;
               case ENOSYS:
                  CLOG(0,0,"ENOSYS received");
                  break;
               case EAGAIN:
                  CLOG(0,0,"EAGAIN received");
                  break;
               case EDEADLK:
                  CLOG(0,0,"EDEADLK received");
                  break;
               case EINTR:
                  CLOG(0,0,"EINTR received");
                  break;
               default:
                  CLOG(0,0,"Unknown errno");
                  break;
            }
            return false;
         }
      }
      else
      {
         // Do nothing
      }

      //pthread_mutex_lock(&m_q_mutex);

      if (m_q.size() != 0)
      {
         //printf("\nGetting a message from the queue");
         (*p_qm) = m_q[0];
         m_q.pop_front();
         //pthread_mutex_unlock(&m_q_mutex);
      }
      else
      {
         //pthread_mutex_unlock(&m_q_mutex);

         if (m_QueueType == QUEUE_TYPE_BLOCKING)
         {
            ELOG(0,0,"ERROR!!!!!!! Still No data thing coming");
            ELOG(0,0,"ERROR!!!!!!! MessageQueue::popMessage ended");
         }
         return false;
      }
   }
   else
   {
   }

   return true;
}
void MessageQueue::lock()
{
   pthread_mutex_lock(&m_q_mutex);
}
void MessageQueue::unlock()
{
   pthread_mutex_unlock(&m_q_mutex);
}

int MessageQueue::getSemCount()
{
   int l_value=-1;
   if (0 != sem_getvalue(&m_semaphore, &l_value))
   {
      ELOG(0,1,"sem_getvalue failed %d", errno);
   }
   return l_value;
}
