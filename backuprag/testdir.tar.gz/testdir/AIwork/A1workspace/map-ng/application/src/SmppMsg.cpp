#include <SmppMsg.h>

SmppMsg::SmppMsg() : Msg(MSG_TYPE_SMPP)
{
}

SmppMsg::~SmppMsg()
{
}

