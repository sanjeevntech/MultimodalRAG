#include <CntxtMsc.h>
#include <stdio.h>

CntxtMsc::CntxtMsc(EDialogueType p_DialogueType, MapMsg *p_MapOpenIndPtr, ContextBase *p_ContextBaseRscPtr = NULL)
{
   MLOG(0,1,"CntxtMsc :cons:");
   DLOG(0,1,"CntxtMsc :cons:");
	m_DialogueType  = p_DialogueType;
	m_MapOpenIndPtr = p_MapOpenIndPtr;
    m_pRsc=NULL;
    m_pRsc          = p_ContextBaseRscPtr;

	///-m_DlgId        = p_MapOpenIndPtr->m_DlgId;
	m_otherPresent = false;

    if (m_DialogueType == DIALOGUE_RESPONDER)
    {
        m_pState = StatesMsc::setWaitForSvcPrimitiveState();
    }
    else if (m_DialogueType == DIALOGUE_INITIATOR)
    {
        m_pState = StatesMsc::setRelayInfoMscState();
    }
    else
    {
       m_pState = NULL;
        DLOG(0,1,"Severe Error in DIALOGUE TYPE");
    }
    m_MapSpecificMsgIndPtr = NULL;


}

void CntxtMsc::setSpecificMsgPtr(MapMsg *p_MapSpecMsgPtr)
{
	m_MapSpecificMsgIndPtr = p_MapSpecMsgPtr;
}


MapMsg *CntxtMsc::getSpecificMsgPtr()
{
    return m_MapSpecificMsgIndPtr;
}

EDialogueType CntxtMsc::getDialogueType()
{
    return m_DialogueType;
}

MapMsg* CntxtMsc::getOpenIndPtr()
{
    return m_MapOpenIndPtr;
}

void CntxtMsc::setOpenIndPtr(MapMsg *p_OpenIndPtr)
{
    m_MapOpenIndPtr=p_OpenIndPtr;
}

CntxtMsc::~CntxtMsc()
{
	MLOG(0,1,"CntxtMsc :des:");
	DLOG(0,1,"CntxtMsc :des:");
}

bool CntxtMsc::deleteRsc() //Added after purify
{
	DLOG(0,1,"CntxtMsc::deleteRsc()");

    if (m_pRsc != NULL)
    {
		CLOG(0,0,"CntxtMsc::deleteRsc() Destroying m_pRsc now.. It didn't get deleted earlier");
        delete(m_pRsc);
        m_pRsc = NULL;
    }

	return true;
}

bool CntxtMsc::ProcMsg(Msg *p_MsgPtr)
{
	 DLOG(0,1,"CntxtMsc::ProcMsg called");
    setDeleteFlag(false);

    if (m_pState != NULL)
    {
       DLOG(0,1,"CntxtMsc::ProcMsg  calling handle");
        m_pState = m_pState->handle(this, p_MsgPtr);
    }
    else
    {
        DLOG(0,1,"m_pState is NULL");
    }
    return m_CanBeDeletedFlag;
}


void CntxtMsc::setDeleteFlag(bool p_flag)
{
    m_CanBeDeletedFlag = p_flag;
}
