#include <CntxtMsc.h>
#include <ContextManager.h>
#include <ServiceCoordinator.h>
#include <MplManager.h>
#include <AsnCodec.h>
#include <MapConstants.h>
#include <Utilities.h>
#include <MessageQueue.h>
#include <SmppInterface.h>
#include <SnmpInterface.h>
#include <ExtContainerParser.h>

extern MessageQueue *g_OamTransactionsList;


void genericPrintPdu(AsnCodec *p_asnCodec, int p_msgType,void *p_dataStruct, char *p_direction)
{
   if( (1 == g_ConfigData->m_ConsoleMapPduPrintFlag) || 
         (1 == g_ConfigData->m_LogMapPduPrintFlag)
     )
   {
      p_asnCodec->printPdu(p_msgType, p_dataStruct, p_direction);

      if(1 == g_ConfigData->m_LogMapPduPrintFlag)
      {
         LLOG(1,1,"%s", g_PrintPduBuffer);
         if(1 == g_ConfigData->m_ConsoleMapPduPrintFlag)
         {
            printf("\n%s", g_PrintPduBuffer);
         }
      }
   }
}

ServiceCoordinator g_sc;
ContextManager  g_ContextMangerObject;
MessageQueue *g_InterModuleQueue = NULL;

bool encode(void *p_data, EMapVersion p_mapVersion, EMapOpCode p_OpCode, EMapSpecificEventType p_EventType, unsigned char *p_buffer, int *p_bufferLen, char p_ioflag, EMapErrorCode);

bool logOSSPDU(MapSpecificMsg *p_MapMsg)
{
   DLOG(0,1,"logOSSPDU called");
   return true;

   // This is to be changed w.r.t getAsnCodec
   if (NULL != p_MapMsg->m_structBuffer)
   {
      DLOG(0,1,"m_structBuffer is not NULL");
      AsnCodec *l_asnCodecPtr = NULL;
      int l_PDU_Number=0;

      l_asnCodecPtr = getAsnCodec((int)(p_MapMsg->m_Version), 'I');//This is temporary
      if (NULL == l_asnCodecPtr)
      {
         ELOG(0,1,"Unable to get the AsnCodec Ptr Version %d", p_MapMsg->m_Version);
         return false;
      }

      switch (p_MapMsg->m_MapSpecificEventType)
      {
         case MAP_SPEC_EVENT_REQUEST:
         case MAP_SPEC_EVENT_INDICATION:
            l_PDU_Number  = MapConstants::getMapOpCodeArgPDU(p_MapMsg->m_OpCode, 
                  p_MapMsg->m_Version);
            DLOG(0,1,"REQUEST/INDICATION PDU %d", l_PDU_Number);
            break;


         case MAP_SPEC_EVENT_CONFIRMATION:
         case MAP_SPEC_EVENT_RESULT:
            l_PDU_Number  = MapConstants::getMapOpCodeResPDU(p_MapMsg->m_OpCode, 
                  p_MapMsg->m_Version);
            DLOG(0,1,"CONFIRMATION/RESULT PDU %d", l_PDU_Number);
            break;

         case MAP_SPEC_EVENT_USER_ERROR:
            l_PDU_Number  = MapConstants::getMapErrorCodePDU(((MapUserError*)p_MapMsg)->m_ErrorCode, 
                  p_MapMsg->m_Version);
            DLOG(0,1,"USER_ERROR/ PDU %d", l_PDU_Number);
            break;

         default:
            ELOG(0,1,"Unknown Specific Event Type");
            return false;
            break;
      }

      if (0 != l_PDU_Number)
      {
         DLOG(0,1,"logOSSPDU PDU");
         l_asnCodecPtr->printPdu(l_PDU_Number, p_MapMsg->m_structBuffer, 0, 1);
         TTLOG(0,0,"Printing PDU\n====================\n%s\n====================", g_PrintPduBuffer);
         return true;
      }
      else
      {
         ELOG(0,1,"Unable to get the PDU Number EvenType %d, OpCode %d, Version %d",
               p_MapMsg->m_MapSpecificEventType, 
               p_MapMsg->m_OpCode,
               p_MapMsg->m_Version
             );
         return false;
      }
   }
   else
   {
      ELOG(0,1,"m_structBuffer is NULL");
      return false;
   }

   DLOG(0,1,"logOSSPDU end");
   return true;
}


ServiceCoordinator::ServiceCoordinator()
{
   DLOG(0,1,"ServiceCoordinator::ServiceCoordinator() created");
}


ServiceCoordinator::~ServiceCoordinator()
{
   DLOG(0,1,"ServiceCoordinator::~ServiceCoordinator() destroyed");
}


bool ServiceCoordinator::initialize(int p_MaxDialogues)
{
   DLOG(0,1,"ServiceCoordinator::initialize() called");
   bool l_status = g_ContextMangerObject.initialize(1, p_MaxDialogues);
   if (l_status == false)
   {
      CLOG(0,0,"Map Context Manager Initialization Failed");
      return false;
   }
   DLOG(0,1,"ServiceCoordinator::initialize() successfull");
   return true;
}

bool ServiceCoordinator::recvMsg(DbQueryMsg *p_DbQueryPtr)
{
   DLOG(0,1,"ServiceCoordinator::recvMsg DbQueryMsg called");

   if (((DbQueryMsg*)p_DbQueryPtr)->m_cb == NULL)
   {
      ELOG(0,0,"DbQueryMsg SEVERE ERROR!!!! m_cb is NULL");
      return false;
   }

   DLOG(0,1,"ServiceCoordinator::recvMsg DbQueryMsg 2");
   ContextBase *l_ContextBasePtr = ((DbQueryMsg*)p_DbQueryPtr)->m_cb;
   if (l_ContextBasePtr != NULL)
   {
      l_ContextBasePtr->m_ReferenceCount--;
      DLOG(0,1,"ServiceCoordinator::recvMsg DbQueryMsg 3");
      l_ContextBasePtr->CallProcMsg((DbQueryMsg*)p_DbQueryPtr);

      if (l_ContextBasePtr->m_ReferenceCount == 0)
      {
         LLOG(0,1,"Deleting Context after processing DB Resp");
         delete(l_ContextBasePtr);
         l_ContextBasePtr=NULL;
      }
   }
   else
   {
      ELOG(0,1,"ContextBasePtr is NULL at the receival of DbQueryMsg");
   }

   return true;
}

bool ServiceCoordinator::recvMsg(MemCachedQueryMsg *p_MemcQueryPtr)
{
   DLOG(0,1,"ServiceCoordinator::recvMsg MemCachedQueryMsg called");

   if (((MemCachedQueryMsg*)p_MemcQueryPtr)->m_Mcb == NULL)
   {
      ELOG(0,0,"MemCachedQueryMsg SEVERE ERROR!!!! m_cb is NULL");
      return false;
   }

   DLOG(0,1,"ServiceCoordinator::recvMsg MemCachedQueryMsg 2");
   ContextBase *l_ContextBasePtr = ((MemCachedQueryMsg*)p_MemcQueryPtr)->m_Mcb;
   if (l_ContextBasePtr != NULL)
   {
      l_ContextBasePtr->m_ReferenceCount--;
      DLOG(0,1,"ServiceCoordinator::recvMsg MemCachedQueryMsg 3");
      l_ContextBasePtr->CallProcMsg((MemCachedQueryMsg*)p_MemcQueryPtr);

      if (l_ContextBasePtr->m_ReferenceCount == 0)
      {
         LLOG(0,1,"Deleting Context after processing MemCachedQueryMsg Resp");
         delete(l_ContextBasePtr);
         l_ContextBasePtr=NULL;
      }
   }
   else
   {
      ELOG(0,1,"ContextBasePtr is NULL at the receival of MemCachedQueryMsg");
   }

   return true;
}

bool ServiceCoordinator::recvMsg(TimeoutMsg *p_tm)
{
   DLOG(0,1,"ServiceCoordinator::recvMsg timeout called");

   if (((TimeoutMsg*)p_tm)->m_cb == NULL)
   {
      ELOG(0,0,"TimeoutMsg SEVERE ERROR!!!! m_cb is NULL");
      return false;
   }

   DLOG(0,1,"ServiceCoordinator::recvMsg TimeoutMsg 2");
   ContextBase *l_ContextBasePtr = ((TimeoutMsg*)p_tm)->m_cb;
   if (l_ContextBasePtr != NULL)
   {
      l_ContextBasePtr->m_ReferenceCount--;
      DLOG(0,1,"ServiceCoordinator::recvMsg TimeoutMsg 3");
      l_ContextBasePtr->CallProcMsg((TimeoutMsg*)p_tm);

      if (l_ContextBasePtr->m_ReferenceCount == 0)
      {
         LLOG(0,1,"Deleting Context after processing TimeoutMsg");
         delete(l_ContextBasePtr);
         l_ContextBasePtr=NULL;
      }
   }
   else
   {
      CLOG(0,1,"Ignoring TimeoutMsg");
   }

   return true;
}

bool ServiceCoordinator::recvMsg(SmppMsg *p_smpp)
{
   DLOG(0,1,"ServiceCoordinator::recvMsg SmppMsg called");

   return true;
}

bool ServiceCoordinator::sendSmppSubmit(char *p_destMsisdn, unsigned char *p_sms, int p_smsLen, int *p_SeqNumber, int p_dataCoding)
{
   if (p_smsLen < 1)
   {
      CLOG(0,0,"SMS Length is less than 1 byte. Ignoring...");
      return false;
   }

   if (strlen(p_destMsisdn) < 5)
   {
      CLOG(0,0,"Invalid Destination MSISDN length %d. Ignoring...", strlen(p_destMsisdn));
      return false;
   }

   struct Esme_Data l_ed;
   memset(&l_ed, '\0', sizeof(l_ed));
   l_ed.command_id = SUBMIT_SM;
   strcpy(l_ed.msg.SubmitSm.service_type, g_ConfigData->m_EsmeConfigData.m_serviceType); 
   l_ed.msg.SubmitSm.source_addr_ton = g_ConfigData->m_EsmeConfigData.m_SubmitTON;
   l_ed.msg.SubmitSm.source_addr_npi = 1; 
   strcpy(l_ed.msg.SubmitSm.source_addr, g_ConfigData->m_EsmeConfigData.m_sourceAddr);

   l_ed.msg.SubmitSm.dest_addr_ton = 1;
   l_ed.msg.SubmitSm.dest_addr_npi = 1; 
   strcpy(l_ed.msg.SubmitSm.destination_addr, p_destMsisdn);

   memcpy(l_ed.msg.SubmitSm.message_payload, p_sms, p_smsLen);
   l_ed.msg.SubmitSm.sm_length = p_smsLen;

   /*if (1 == p_dataCoding)
     {
     l_ed.msg.SubmitSm.data_coding = 0x01;
     }
     else if (2 == p_dataCoding)
     {
     l_ed.msg.SubmitSm.data_coding = 0x03;
     }
     else if (3 == p_dataCoding)
     {
     l_ed.msg.SubmitSm.data_coding = 0x08;
     }
     else
     {
     l_ed.msg.SubmitSm.data_coding = p_dataCoding;
     }*/

   l_ed.msg.SubmitSm.data_coding = p_dataCoding;

   memcpy(&g_ec.m_ESMEData, &l_ed, sizeof(l_ed));
   g_ec.Encode();

   *p_SeqNumber = g_ec.m_ESMEData.sequence_number;

   BOOLEAN l_result = g_ec.SendMessage();
   if (false == l_result)
   {
      CLOG(0,0,"Unable to send the message");
      return false;
   }
   return true;
}



bool ServiceCoordinator::recvMsg(MapMsg *p_MapMsg)
{
   TLOG(0,1,"Received MsgType: %s UserDlg: %d started", p_MapMsg->getMsgTypeName(), p_MapMsg->m_UserDlgId);

   // Perform some validations here (actually to scrutinize MPL) - can be removed later?
   if (p_MapMsg->m_UserDlgId < 1)
   {
      CLOG(0,0,"VALIDATION FAILED :: Dialogue Id  is invalid");
      return false;
   }

   CntxtMsc *l_CntxtMscPtr = NULL;
   bool      l_status = false;
   switch (p_MapMsg->m_MapMsgType)
   {
      case MAP_MSG_TYPE_COMMON:
         {
            EMapCommonMsgType l_MapCommonMsgType = ((MapCommonMsg*)p_MapMsg)->m_MapCommonMsgType;
            if (l_MapCommonMsgType  == MAP_CMN_OPEN_IND)
            {
               g_ContextMangerObject.getNewDialogueR(); //this is just for reference
               DLOG(0,1,"Allocated Service User UserDlgId: %d ", p_MapMsg->m_UserDlgId);

               if (p_MapMsg->m_UserDlgId < 1)
               {
                  CLOG(0,0,"Invalid dialogue");
                  return false;
               }

               // Create a CntxtMsc object and store the context
               l_CntxtMscPtr = new CntxtMsc(DIALOGUE_RESPONDER, p_MapMsg, NULL);
               l_CntxtMscPtr->m_UserDlgId = p_MapMsg->m_UserDlgId;
               l_CntxtMscPtr->setOpenIndPtr(p_MapMsg);//added on feb 10
               l_CntxtMscPtr->m_applCtxt = ((MapOpenInd*)p_MapMsg)->m_ApplCntxt;

               // Now store the context
               g_ContextMangerObject.storeContext(p_MapMsg->m_UserDlgId, 
                     l_CntxtMscPtr,
                     DIALOGUE_RESPONDER);

               g_ContextMangerObject.print();
            }
            else if ( (l_MapCommonMsgType  == MAP_CMN_P_ABORT_IND) ||
                  (l_MapCommonMsgType  == MAP_CMN_U_ABORT_IND) ||
                  ((l_MapCommonMsgType == MAP_CMN_OPEN_CNF) && (((MapOpenRsp*)p_MapMsg)->m_ResponseChoiceFlag == false)  ) ||
                  (l_MapCommonMsgType  == MAP_CMN_CLOSE_IND)
                  )
            {
               //DLOG(0,1,"Received CLOSE or U_ABORT or P_ABORT with DlgId: %d ", p_MapMsg->m_UserDlgId);

               l_status = g_ContextMangerObject.getContext(p_MapMsg->m_UserDlgId, 
                     (void**)&l_CntxtMscPtr);
               int l_UserDlgId = p_MapMsg->m_UserDlgId;


               if (l_status == true)
               {
                  p_MapMsg->m_UserDlgId = l_CntxtMscPtr->m_UserDlgId;
                  DLOG(0,1,"p_MapMsg->m_MapMsgType :%d", p_MapMsg->m_MapMsgType);
                  if (l_CntxtMscPtr->m_pRsc != NULL)
                  {
                     l_CntxtMscPtr->m_pRsc->m_ReferenceCount--;
                  }

                  l_CntxtMscPtr->ProcMsg(p_MapMsg);

                  g_ContextMangerObject.removeContext(l_UserDlgId, 
                        l_CntxtMscPtr->getDialogueType());
                  //To be uncommented for sure
                  delete(l_CntxtMscPtr);
                  l_CntxtMscPtr=NULL;

                  //l_CntxtMscPtr->setDeleteFlag(true);
               }
               else
               {
                  TLOG(0,0,"Context is already removed for the message: %d with UID:%d", 
                        p_MapMsg->m_MapMsgType, p_MapMsg->m_UserDlgId);
               }
            }
            else if ( (l_MapCommonMsgType  == MAP_CMN_DELIMITER_IND) ||
                  ((l_MapCommonMsgType == MAP_CMN_OPEN_CNF) && (((MapOpenRsp*)p_MapMsg)->m_ResponseChoiceFlag == true)  ) ||
                  (l_MapCommonMsgType  == MAP_CMN_NOTICE_IND)
                  )
            {
               l_status = g_ContextMangerObject.getContext(p_MapMsg->m_UserDlgId, 
                     (void**)&l_CntxtMscPtr);
               if (l_status == true)
               {
                  p_MapMsg->m_UserDlgId = l_CntxtMscPtr->m_UserDlgId;

                  l_CntxtMscPtr->m_otherPresent = true;
                  l_status = l_CntxtMscPtr->ProcMsg(p_MapMsg);
                  l_CntxtMscPtr->m_otherPresent = false;

                  if (l_status)
                  {
                     delete(l_CntxtMscPtr);
                     l_CntxtMscPtr=NULL;
                  }
               }
               else
               {
                  TLOG(0,0,"Context is already removed for the message: %d with UID:%d", 
                        p_MapMsg->m_MapMsgType, p_MapMsg->m_UserDlgId);
                  delete(p_MapMsg);// This is required for not processed delimiter messages
               }
            }
            else
            {
               CLOG(0,0,"VALIDATION FAILED :: Invalid Message Received");
            }
         }

         break;

      case MAP_MSG_TYPE_SPECIFIC: // all specific messages
         {

            DLOG(0,1,"Received [%s]", ((MapSpecificMsg*)p_MapMsg)->getMapSpecifigEventTypeName());

            int l_asnResult=0;
            AsnCodec *l_asnCodecPtr = NULL;
            void *l_struct = NULL;
            int l_PDU_Number=0;

            switch (((MapSpecificMsg*)p_MapMsg)->m_MapSpecificEventType)
            {
               case MAP_SPEC_EVENT_INDICATION:
                  {
                     if (MAP_OP_CODE_UNKNOWN == ((MapSpecificMsg*)p_MapMsg)->m_OpCode)
                     {
                        ELOG(0,1,"Severe Error. Unknown Op Code. Do Check");
                        return false;
                     }
                     else
                     {
                        if (((MapSpecificMsg*)p_MapMsg)->m_bufLen > 2)
                        {
                           l_asnCodecPtr = getAsnCodec((int)((MapSpecificMsg*)p_MapMsg)->m_Version, 'I');
                           ((MapSpecificMsg*)p_MapMsg)->m_ioflag = 'I';
                           l_PDU_Number  = MapConstants::getMapOpCodeArgPDU(((MapSpecificMsg*)p_MapMsg)->m_OpCode, ((MapSpecificMsg*)p_MapMsg)->m_Version);

                           l_asnResult = l_asnCodecPtr->decode((&(((MapSpecificMsg*)p_MapMsg)->m_buffer[0])),
                                 ((MapSpecificMsg*)p_MapMsg)->m_bufLen,
                                 l_PDU_Number,
                                 &l_struct);

                           if (l_asnResult != 0)
                           {
                              CLOG(0,1,"Decoding not success. Checking to add some data and then decode. [%s] ", l_asnCodecPtr->getErrMsg());

                              if (((MapSpecificMsg*)p_MapMsg)->m_bufLen > 300)
                              {
                                 ELOG(0,1,"Invalid length of a component %d", ((MapSpecificMsg*)p_MapMsg)->m_bufLen);
                                 return false;
                              }

                              unsigned char l_tempBuf[300+2];
                              l_tempBuf[0] = 0x30;
                              l_tempBuf[1] = ((MapSpecificMsg*)p_MapMsg)->m_bufLen;
                              memcpy(l_tempBuf+2, 
                                    ((MapSpecificMsg*)p_MapMsg)->m_buffer, 
                                    ((MapSpecificMsg*)p_MapMsg)->m_bufLen);

                              l_asnResult = l_asnCodecPtr->decode(&l_tempBuf[0],
                                    2+((MapSpecificMsg*)p_MapMsg)->m_bufLen,
                                    l_PDU_Number,
                                    &l_struct);

                              if (l_asnResult != 0)
                              {
                                 CLOG(0,1,"Decoding again failed");
                                 //return false;
                              }
                              else
                              {
                                 genericPrintPdu(l_asnCodecPtr, l_PDU_Number, l_struct, "===>>");

                                 DLOG(0,1,"Allocating with PDU %d, Memory Address %u", l_PDU_Number, l_struct);

                                 ((MapSpecificMsg*)p_MapMsg)->m_structBuffer = l_struct;
                                 ((MapSpecificMsg*)p_MapMsg)->m_allocatedFlag=true;
                              }
                           }
                           else
                           {
                              genericPrintPdu(l_asnCodecPtr, l_PDU_Number, l_struct, "===>>");

                              DLOG(0,1,"Allocating with PDU %d, Memory Address %u", l_PDU_Number, l_struct);

                              ((MapSpecificMsg*)p_MapMsg)->m_structBuffer = l_struct;
                              ((MapSpecificMsg*)p_MapMsg)->m_allocatedFlag=true;
                              DLOG(0,1,"Allocating with PDU %d, Memory Address %u done", l_PDU_Number, l_struct);

                              g_ecp.decodeExtensionContainer(((MapSpecificMsg*)p_MapMsg)->m_OpCode, 
                                    ((MapSpecificMsg*)p_MapMsg)->m_Version, 
                                    ((MapSpecificMsg*)p_MapMsg)->m_structBuffer, 
                                    ((MapSpecificMsg*)p_MapMsg)->m_extensionContainerBuffer,
                                    MAX_EXT_CONTAINTER_BUFFER_SIZE-1);
                           }
                        }
                        else
                        {
                           DLOG(0,1,"No Buffer present. Decoding not performed");
                        }
                     }
                     DLOG(0,1,"Done with indication");
                  }
                  break;
               case MAP_SPEC_EVENT_CONFIRMATION:
                  {
                     if (MAP_OP_CODE_UNKNOWN == ((MapSpecificMsg*)p_MapMsg)->m_OpCode)
                     {
                        ELOG(0,1,"Severe Error. Unknown Op Code. Do Check");
                        return false;
                     }
                     else
                     {
                        if(((MapSpecificMsg*)p_MapMsg)->m_bufLen > 2)
                        {

                           l_asnCodecPtr = getAsnCodec((int)((MapSpecificMsg*)p_MapMsg)->m_Version, 'I');
                           ((MapSpecificMsg*)p_MapMsg)->m_ioflag = 'I';
                           l_PDU_Number  = MapConstants::getMapOpCodeResPDU(((MapSpecificMsg*)p_MapMsg)->m_OpCode, ((MapSpecificMsg*)p_MapMsg)->m_Version);

                           l_asnResult = l_asnCodecPtr->decode((&(((MapSpecificMsg*)p_MapMsg)->m_buffer[0])),
                                 ((MapSpecificMsg*)p_MapMsg)->m_bufLen,
                                 l_PDU_Number,
                                 &l_struct);

                           if (l_asnResult != 0)
                           {
                              CLOG(0,1,"Decoding not success. Checking to add some data and then decode.  [%s]", l_asnCodecPtr->getErrMsg());

                              if (((MapSpecificMsg*)p_MapMsg)->m_bufLen > 300)
                              {
                                 ELOG(0,1,"Invalid length of a component %d", ((MapSpecificMsg*)p_MapMsg)->m_bufLen);
                                 return false;
                              }

                              if(((MapSpecificMsg*)p_MapMsg)->m_buffer[0] != 0x30)
                              {

                                 unsigned char l_tempBuf[300+2];
                                 l_tempBuf[0] = 0x30;
                                 l_tempBuf[1] = ((MapSpecificMsg*)p_MapMsg)->m_bufLen;
                                 memcpy(l_tempBuf+2, 
                                       ((MapSpecificMsg*)p_MapMsg)->m_buffer, 
                                       ((MapSpecificMsg*)p_MapMsg)->m_bufLen);

                                 l_asnResult = l_asnCodecPtr->decode(&l_tempBuf[0],
                                       2+((MapSpecificMsg*)p_MapMsg)->m_bufLen,
                                       l_PDU_Number,
                                       &l_struct);

                                 if (l_asnResult != 0)
                                 {
                                    CLOG(0,1,"Decoding again failed");
                                    //return false;
                                 }
                                 else
                                 {
                                    genericPrintPdu(l_asnCodecPtr, l_PDU_Number, l_struct, "===>>");

                                    DLOG(0,1,"Allocating with PDU %d, Memory Address %u", l_PDU_Number, l_struct);

                                    ((MapSpecificMsg*)p_MapMsg)->m_structBuffer = l_struct;
                                    ((MapSpecificMsg*)p_MapMsg)->m_allocatedFlag=true;
                                 }
                              }
                              else
                              {
                                 LLOG(0,1,"0x30 tag present. Not decoding again");
                              }

                              //return false;
                           }
                           else
                           {
                              genericPrintPdu(l_asnCodecPtr, l_PDU_Number, l_struct, "===>>");

                              DLOG(0,1,"Allocating with PDU %d, Memory Address %u", l_PDU_Number, l_struct);

                              ((MapSpecificMsg*)p_MapMsg)->m_structBuffer = l_struct;
                              ((MapSpecificMsg*)p_MapMsg)->m_allocatedFlag=true;
                           }
                        }
                        else
                        {
                           TLOG(0,1,"No Buffer to decode");
                        }
                     }
                  }
                  break;
               case MAP_SPEC_EVENT_USER_ERROR:
                  {
                     l_asnCodecPtr = getAsnCodec((int)((MapSpecificMsg*)p_MapMsg)->m_Version, 'I');
                     ((MapSpecificMsg*)p_MapMsg)->m_ioflag = 'I';
                     //l_PDU_Number  = MAP2_SystemFailureParam_PDU;
                     l_PDU_Number  = MapConstants::getMapErrorCodePDU(((MapUserError*)p_MapMsg)->m_ErrorCode, ((MapSpecificMsg*)p_MapMsg)->m_Version);
                     if (((MapSpecificMsg*)p_MapMsg)->m_bufLen > 0)
                     {
                        LLOG(0,1,"Decoding Error Buffer of length [%d] with Error Code [%d], \
                              and version [%d] with PDU Number [%d]",
                              ((MapSpecificMsg*)p_MapMsg)->m_bufLen,
                              ((MapUserError*)p_MapMsg)->m_ErrorCode,
                              ((MapSpecificMsg*)p_MapMsg)->m_Version,
                              l_PDU_Number);

                        l_asnResult = l_asnCodecPtr->decode((&(((MapSpecificMsg*)p_MapMsg)->m_buffer[0])),
                              ((MapSpecificMsg*)p_MapMsg)->m_bufLen,
                              l_PDU_Number,
                              &l_struct);

                        if (l_asnResult != 0)
                        {
                           CLOG(0,1,"Decoding failed [%s]", l_asnCodecPtr->getErrMsg());
                        }
                        else
                        {
                           DLOG(0,1,"Decoding done");
                           genericPrintPdu(l_asnCodecPtr, l_PDU_Number, l_struct, "===>>");

                           DLOG(0,1,"Allocating with PDU %d, Memory Address %u", l_PDU_Number, l_struct);

                           ((MapSpecificMsg*)p_MapMsg)->m_structBuffer = l_struct;
                           ((MapSpecificMsg*)p_MapMsg)->m_allocatedFlag=true;
                        }
                     }
                     else
                     {
                        TLOG(0,1,"No User Error Buffer to decode");
                     }
                  }
                  break;
               case MAP_SPEC_EVENT_PROV_ERROR:
                  DLOG(0,1,"Validating MAP_SPEC_EVENT_PROV_ERROR");
                  break;

               default:
                  ELOG(0,1,"Unhandled message");
                  break;

            }

            DLOG(0,1,"Calling getContext");

            l_status = g_ContextMangerObject.getContext(p_MapMsg->m_UserDlgId, 
                  (void**)&l_CntxtMscPtr);
            if (l_status == true)
            {
               p_MapMsg->m_UserDlgId = l_CntxtMscPtr->m_UserDlgId;

               l_CntxtMscPtr->m_otherPresent = true;
               DLOG(0,1,"Calling l_CntxtMscPtr->ProcMsg");
               l_status = l_CntxtMscPtr->ProcMsg(p_MapMsg);
               l_CntxtMscPtr->m_otherPresent = false;
               if (l_status)
               {
                  delete(l_CntxtMscPtr);
                  l_CntxtMscPtr=NULL;
               }
            }
            else
            {
               CLOG(0,0,":T: Unable to retrieve the context for the message: %d with UID:%d", 
                     p_MapMsg->m_MapMsgType, p_MapMsg->m_UserDlgId);
            }

         }
         break;

      default:
         WLOG(0,1,"VALIDATION FAILED :: 2 Invalid Message Received");
         break;
   }
   DLOG(0,1,"end");
   return true;
}

int ServiceCoordinator::getNewDialogue()
{
   return g_ContextMangerObject.getNewDialogue();
}


bool ServiceCoordinator::sendMsg(ContextBase *p_ContextBaseRscPtr, MapMsg *p_MapMsgPtr)
{
   // Use this function initiate a Dialogue to an other entity    
   DLOG(0,1,"ServiceCoordinator::sendMessage called with DlgId: %d", p_MapMsgPtr->m_UserDlgId);
   if (p_MapMsgPtr->m_UserDlgId <= 0)
   {
      ELOG(0,1,"ERROR!!! Dialogue Id is less than zero");
      return false;
   }

   /*if (p_MapMsgPtr->m_Version == MAP_V_UNKNOWN)
     {
     CLOG(0,0,"m_Version is MAP_V_UNKNOWN");
     return false;
     }*/



   CntxtMsc *l_CntxtMscPtr = NULL;
   bool      l_status = false;

   switch (p_MapMsgPtr->m_MapMsgType)
   {
      case MAP_MSG_TYPE_COMMON:
         //DLOG(0,1,"ServiceCoordinator::sendMessage Sending [%s]", ((MapCommonMsg*)p_MapMsgPtr)->getMapCommonMsgTypeName());

         switch (((MapCommonMsg*)p_MapMsgPtr)->m_MapCommonMsgType)
         {
            case MAP_CMN_OPEN_REQ:
               {

                  /* Do some validations here*/

                  if (p_ContextBaseRscPtr == NULL)
                  {
                     ELOG(0,1,"ERROR!!! ContextRsc Ptr is NULL");
                  }


                  if (((MapOpenReq*)p_MapMsgPtr)->m_ApplCntxt == MAP_AC_UNKNOWN)
                  {
                     if (MAP_V1 != ((MapOpenReq*)p_MapMsgPtr)->m_Version)
                     {
                        ELOG(0,1,"ERROR!!! ServiceCoordinator::sendMsg Application Context Is NULL");
                        return false;
                     }
                  }

                  if (((MapOpenReq*)p_MapMsgPtr)->m_Version == MAP_V_UNKNOWN)
                  {
                     ELOG(0,1,"ERROR!!! m_Version is MAP_V_UNKNOWN");
                     return false;
                  }

                  //TODO to be fixed

                  // add gt validations

                  /* End of Validations */

                  //DLOG(0,1,"ServiceCoordinator::sendMessage Sending MAP_CMN_OPEN_REQ UserDlg:%d", p_MapMsgPtr->m_UserDlgId);
                  l_CntxtMscPtr = new CntxtMsc(DIALOGUE_INITIATOR, p_MapMsgPtr, p_ContextBaseRscPtr);
                  l_CntxtMscPtr->m_applCtxt = ((MapOpenReq*)p_MapMsgPtr)->m_ApplCntxt;
                  if (p_ContextBaseRscPtr != NULL)
                  {
                     p_ContextBaseRscPtr->m_ReferenceCount++;
                  }


                  // Now store the context
                  l_status = g_ContextMangerObject.storeContext(p_MapMsgPtr->m_UserDlgId, 
                        l_CntxtMscPtr,
                        DIALOGUE_INITIATOR);
                  l_CntxtMscPtr->m_UserDlgId = p_MapMsgPtr->m_UserDlgId;
                  if (l_status == true)
                  {
                     g_MplManager.recvMapMsg(p_MapMsgPtr);

                  }
                  else
                  {
                     CLOG(0,0,"ServiceCoordinator::sendMessage storeContext failed");
                     return false;
                  }
               }
               break;

            case MAP_CMN_U_ABORT_REQ:
            case MAP_CMN_CLOSE_REQ:
            case MAP_CMN_OPEN_RSP:
            case MAP_CMN_DELIMITER_REQ:


               if ( (MAP_CMN_U_ABORT_REQ == ((MapCommonMsg*)p_MapMsgPtr)->m_MapCommonMsgType) ||
                     (MAP_CMN_CLOSE_REQ   == ((MapCommonMsg*)p_MapMsgPtr)->m_MapCommonMsgType) ||
                     ( (MAP_CMN_OPEN_RSP    == ((MapCommonMsg*)p_MapMsgPtr)->m_MapCommonMsgType) &&
                       (false == ((MapOpenResponses*)p_MapMsgPtr)->m_ResponseChoiceFlag) )
                  )
               {
                  l_status = g_ContextMangerObject.getContext(p_MapMsgPtr->m_UserDlgId,
                        (void**)&l_CntxtMscPtr);
                  if (false == l_status)
                  {
                     CLOG(0,1,"Unable to find the context. Do Check the application");
                     return false;
                  }
                  ///-if (0 == l_CntxtMscPtr->m_DlgId)
                  ///-{
                  ///-   p_MapMsgPtr->m_DlgId = g_dialogId;
                  ///-   l_CntxtMscPtr->m_DlgId = g_dialogId;
                  ///-}
                  ///-else
                  ///-{
                  ///-   p_MapMsgPtr->m_DlgId = l_CntxtMscPtr->m_DlgId;
                  ///-}

                  if (l_status == true)
                  {
                     DLOG(0,1,"ServiceCoordinator::sendMessage Calling remove context");
                     g_ContextMangerObject.removeContext(p_MapMsgPtr->m_UserDlgId,
                           l_CntxtMscPtr->getDialogueType());

                     if (l_CntxtMscPtr->m_pRsc && l_CntxtMscPtr->m_pRsc->m_ReferenceCount)
                     {
                        l_CntxtMscPtr->m_pRsc->m_ReferenceCount--;
                     }


                     if (l_CntxtMscPtr->m_otherPresent)
                     {
                        l_CntxtMscPtr->setDeleteFlag(true);
                     }
                     else
                     {
                        delete(l_CntxtMscPtr);
                        l_CntxtMscPtr=NULL;
                     }

                     g_MplManager.recvMapMsg(p_MapMsgPtr);
                  }
                  else
                  {
                     ELOG(0,1,"ServiceCoordinator::sendMessage Unable to retrieve Context");
                     return false;
                  }
               }
               else  // Should be either Delimiter or Open Response with Flag true
               {
                  //DLOG(0,1,"ServiceCoordinator::sendMessage Sending MAP_CMN_OPEN_RSP");
                  l_status = g_ContextMangerObject.getContext(p_MapMsgPtr->m_UserDlgId, 
                        (void**)&l_CntxtMscPtr);
                  if (true == l_status)
                  {
                     ///-if (0 == l_CntxtMscPtr->m_DlgId)
                     ///-{
                     ///-   p_MapMsgPtr->m_DlgId = g_dialogId;
                     ///-   l_CntxtMscPtr->m_DlgId = g_dialogId;
                     ///-}
                     ///-else
                     ///-{
                     ///-   p_MapMsgPtr->m_DlgId = l_CntxtMscPtr->m_DlgId;
                     ///-}

                     g_MplManager.recvMapMsg(p_MapMsgPtr);
                     if(((MapCommonMsg*)p_MapMsgPtr)->m_MapCommonMsgType == MAP_CMN_OPEN_RSP)
                     {
                        DLOG(0,1,"Msc2::sendMessage  ((MapOpenResponses*)lp_MapMsg)->m_ResponseChoiceFlag: %d %d",
                              ((MapOpenResponses*)p_MapMsgPtr)->m_ResponseChoiceFlag,
                              true);
                     }
                  }
               }

               break;

            default:
               ELOG(0,0,"ServiceCoordinator::sendMessage ERROR! THIS MESSAGE <%d> CANNOT BE SENT. Returning false", 
                     ((MapCommonMsg*)p_MapMsgPtr)->m_MapCommonMsgType);
               return false;
               break;
         }
         break;


      case MAP_MSG_TYPE_SPECIFIC:
         //DLOG(0,1,"ServiceCoordinator::sendMessage Sending MAP_MSG_TYPE_SPECIFIC");

         l_status = g_ContextMangerObject.getContext(p_MapMsgPtr->m_UserDlgId, 
               (void**)&l_CntxtMscPtr);
         if (false == l_status)
         {
            CLOG(0,1,"Unable to find the context. Do Check the application");
            return false;
         }

         ///-if (0 == l_CntxtMscPtr->m_DlgId)
         ///-{
         ///-   p_MapMsgPtr->m_DlgId = g_dialogId;
         ///-   l_CntxtMscPtr->m_DlgId = g_dialogId;
         ///-}
         ///-else
         ///-{
         ///-   p_MapMsgPtr->m_DlgId = l_CntxtMscPtr->m_DlgId;
         ///-}

         switch (((MapSpecificMsg*)p_MapMsgPtr)->m_MapSpecificEventType)
         {
            case MAP_SPEC_EVENT_REQUEST:
               {
                  if (MAP_OP_CODE_UNKNOWN == ((MapSpecificMsg*)p_MapMsgPtr)->m_OpCode)
                  {
                     ELOG(0,1,"ERROR!!! Severe Error. Unknown Op Code. Do Check");
                     return false;
                  }

                  if (false == MapConstants::isApplCtxtOpCodeCombValid(l_CntxtMscPtr->m_applCtxt, ((MapSpecificMsg*)p_MapMsgPtr)->m_OpCode))
                  {
                     g_si.sendSnmpTrap(g_OpCodeApplMismatchTrap, TRAP_TYPE_FAIL, TRAP_SEVERITY_MAJOR);
                     ELOG(0,1,"Severe Error. Op Code [%d] and Appl Ctxt [%d] Doesn't match. Do Check",
                           ((MapSpecificMsg*)p_MapMsgPtr)->m_OpCode, l_CntxtMscPtr->m_applCtxt);
                     return false;
                  }

                  if (NULL != ((MapSpecificMsg*)p_MapMsgPtr)->m_buffer)
                  {
                     encode(  ((MapSpecificMsg*)p_MapMsgPtr)->m_structBuffer, 
                           ((MapSpecificMsg*)p_MapMsgPtr)->m_Version, 
                           ((MapSpecificMsg*)p_MapMsgPtr)->m_OpCode,
                           ((MapSpecificMsg*)p_MapMsgPtr)->m_MapSpecificEventType,
                           &((MapSpecificMsg*)p_MapMsgPtr)->m_buffer[0], 
                           &(((MapSpecificMsg*)p_MapMsgPtr)->m_bufLen),
                           ((MapSpecificMsg*)p_MapMsgPtr)->m_ioflag,
                           MAP_ERROR_UNKNOWN
                           );
                  }
                  else
                  {
                     TLOG(0,1,"No Buffer associated with the Request\n");
                  }
               }
               break;

            case MAP_SPEC_EVENT_RESULT:
               {
                  bool l_result;
                  if(NULL != ((MapSpecificMsg*)p_MapMsgPtr)->m_structBuffer)
                  {

                     l_result = encode(((MapSpecificMsg*)p_MapMsgPtr)->m_structBuffer, 
                           ((MapSpecificMsg*)p_MapMsgPtr)->m_Version, 
                           ((MapSpecificMsg*)p_MapMsgPtr)->m_OpCode,
                           ((MapSpecificMsg*)p_MapMsgPtr)->m_MapSpecificEventType,
                           &((MapSpecificMsg*)p_MapMsgPtr)->m_buffer[0], 
                           &(((MapSpecificMsg*)p_MapMsgPtr)->m_bufLen),
                           ((MapSpecificMsg*)p_MapMsgPtr)->m_ioflag,
                           MAP_ERROR_UNKNOWN
                           );

                     if (!l_result)
                     {
                        ELOG(0,1,"ERROR!! Encoding failed.");
                        MapProviderErrorMsg l_prov;
                        ///-l_prov.m_DlgId     = p_MapMsgPtr->m_UserDlgId;
                        l_prov.m_UserDlgId = p_MapMsgPtr->m_UserDlgId;
                        l_prov.m_MapProvErrorCode = MAP_PROV_ERROR_MISTYPED_PARAMETER;
                        return false;
                     }
                  }
                  else
                  {
                     TLOG(0,1,"No Component Buffer present to encode %d", ((MapSpecificMsg*)p_MapMsgPtr)->m_bufLen);
                  }
               }
               break;

            case MAP_SPEC_EVENT_USER_ERROR:

               if (NULL != ((MapSpecificMsg*)p_MapMsgPtr)->m_buffer)
               {
                  encode(  ((MapSpecificMsg*)p_MapMsgPtr)->m_structBuffer, 
                        ((MapSpecificMsg*)p_MapMsgPtr)->m_Version, 
                        MAP_OP_CODE_UNKNOWN,
                        ((MapSpecificMsg*)p_MapMsgPtr)->m_MapSpecificEventType,
                        &((MapSpecificMsg*)p_MapMsgPtr)->m_buffer[0], 
                        &(((MapSpecificMsg*)p_MapMsgPtr)->m_bufLen),
                        ((MapSpecificMsg*)p_MapMsgPtr)->m_ioflag,
                        ((MapUserError*)p_MapMsgPtr)->m_ErrorCode
                        );
               }
               else
               {
                  TLOG(0,1,"No Buffer associated with the User Error");
               }

               break;

            default:
               ELOG(0,1,"Unhandled message");
               break;
         }
         DLOG(0,1,"g_SlCurrentContext: %d, g_SlCurrentCtxtTraceEnabledFlag: %c, m_TracingEnabledFlag: %d", 
               g_SlCurrentContext,
               g_SlCurrentCtxtTraceEnabledFlag,
               g_ConfigData->m_TracingEnabledFlag);

         if ( (g_SlCurrentContext != 0) && (' ' != g_SlCurrentCtxtTraceEnabledFlag) && (1 == g_ConfigData->m_TracingEnabledFlag))
         {
            logOSSPDU((MapSpecificMsg*)p_MapMsgPtr);
         }
         g_MplManager.recvMapMsg(p_MapMsgPtr);
         break;

      default:
         CLOG(0,0,"ServiceCoordinator::sendMessage Not Implemented2. Returning false");
         return false;
         break;
   }
   return true;
}




bool encode(void *p_data, 
      EMapVersion p_mapVersion, 
      EMapOpCode p_OpCode, 
      EMapSpecificEventType p_EventType,
      unsigned char *p_buffer, 
      int *p_bufferLen,
      char p_ioflag,
      EMapErrorCode p_ErrorCode)
{
   AsnCodec *l_asnCodec = getAsnCodec((int)p_mapVersion, p_ioflag);
   if (NULL == l_asnCodec)
   {
      ELOG(0,1,"Unable to AsnCodec pointer");
      return false;
   }

   int l_PDU_Number=0;

   switch (p_EventType)
   {
      case MAP_SPEC_EVENT_REQUEST:
      case MAP_SPEC_EVENT_INDICATION:
         l_PDU_Number = MapConstants::getMapOpCodeArgPDU(p_OpCode, p_mapVersion);
         break;

      case MAP_SPEC_EVENT_RESULT:
      case MAP_SPEC_EVENT_CONFIRMATION:
         l_PDU_Number = MapConstants::getMapOpCodeResPDU(p_OpCode, p_mapVersion);
         break;

      case MAP_SPEC_EVENT_USER_ERROR:
         l_PDU_Number  = MapConstants::getMapErrorCodePDU(p_ErrorCode, p_mapVersion);
         CLOG(0,1,"encoding user error with error code: %d, version: %d, PDU: %d", 
               p_ErrorCode, p_mapVersion, l_PDU_Number);
         break;

      default:
         ELOG(0,1,"UNKNOWN not implemented");
         return false;
         break;
   }

   unsigned char* l_buffer=NULL;
   int l_bufferLen=0;

   // Encode the data into ASN.1 Buffer
   if (NULL != p_data)
   {
      DLOG(0,1,"Encoding with PDU Num:%d", l_PDU_Number);
      int l_result = l_asnCodec->encode(p_data,
            l_PDU_Number,
            &l_buffer,
            &l_bufferLen);
      if (l_result != 0)
      {
         ELOG(0,1,"Encoding failed [%s]", l_asnCodec->getErrMsg());
         return false;
      }
      else
      {
         genericPrintPdu(l_asnCodec, l_PDU_Number, p_data, "<<===");
         if (l_bufferLen <= MAX_COMP_BUFFER_SIZE)
         {
            memcpy(p_buffer, l_buffer, l_bufferLen);
            *p_bufferLen = l_bufferLen;

            if (l_buffer)
            {
               free(l_buffer);
               l_buffer=NULL;
            }
         }
         else
         {
            ELOG(0,1,"Encoded Buffer Length [%d] is greater than maximum allowed [%d]", 
                  l_bufferLen, MAX_COMP_BUFFER_SIZE);
            if (l_buffer)
            {
               free(l_buffer);
               l_buffer=NULL;
            }

            return false;
         }

      }
   }
   else
   {
      TLOG(0,1,"No Data To Encode");
      return false;
   }
   return true;
}



bool freeMemory(MapSpecificMsg *p_MapMsg)
{
   if (true == p_MapMsg->m_allocatedFlag)
   {
      DLOG(0,1,"allocated flag is true");
      if (NULL != p_MapMsg->m_structBuffer)
      {
         AsnCodec *l_asnCodecPtr = NULL;
         int l_PDU_Number=0;

         l_asnCodecPtr = getAsnCodec((int)(p_MapMsg->m_Version), 'I');
         if (NULL == l_asnCodecPtr)
         {
            ELOG(0,1,"Unable to get the AsnCodec Ptr Version %d", p_MapMsg->m_Version);
            return false;
         }

         switch (p_MapMsg->m_MapSpecificEventType)
         {
            case MAP_SPEC_EVENT_REQUEST:
            case MAP_SPEC_EVENT_INDICATION:
               l_PDU_Number  = MapConstants::getMapOpCodeArgPDU(p_MapMsg->m_OpCode, p_MapMsg->m_Version);
               DLOG(0,1,"Request/Indication PDU %d", l_PDU_Number);
               break;


            case MAP_SPEC_EVENT_CONFIRMATION:
            case MAP_SPEC_EVENT_RESULT:
               l_PDU_Number  = MapConstants::getMapOpCodeResPDU(p_MapMsg->m_OpCode, p_MapMsg->m_Version);
               DLOG(0,1,"Confirmation/Result PDU %d", l_PDU_Number);
               break;

            case MAP_SPEC_EVENT_USER_ERROR:
               l_PDU_Number  = MapConstants::getMapErrorCodePDU(((MapUserError*)p_MapMsg)->m_ErrorCode, p_MapMsg->m_Version);
               DLOG(0,1,"UserError PDU %d", l_PDU_Number);
               break;

            default:
               ELOG(0,1,"Unknown Specific Event Type");
               return false;
               break;
         }


         if (0 != l_PDU_Number)
         {
            DLOG(0,1,"Deallocating with PDU %d, Memory Address %u", l_PDU_Number, p_MapMsg->m_structBuffer);
            l_asnCodecPtr->freePdu(l_PDU_Number, p_MapMsg->m_structBuffer);
            return true;
         }
         else
         {
            ELOG(0,1,"Unable to get the PDU Number EvenType %d, OpCode %d, Version %d", p_MapMsg->m_MapSpecificEventType, p_MapMsg->m_OpCode,
                  p_MapMsg->m_Version);
            return false;
         }
      }
      else
      {
         DLOG(0,1,"m_structBuffer is NULL");
         return false;
      }
   }
   else
   {
      DLOG(0,1,"allocated flag is false");
      return true;
   }
   return true;
}









bool ServiceCoordinator::decodeData(MapSpecificMsg* p_MapMsg, HexData *p_hexData)
{
   printHexDump("Decoding data", p_hexData->m_value, p_hexData->m_length);
   int l_asnResult=0;
   AsnCodec *l_asnCodecPtr = NULL;
   void *l_struct = NULL;
   int l_PDU_Number=0;

   if (p_hexData->m_length <1)
   {
      CLOG(0,1,"decodeData: No Buffer to decode");
      return false;
   }

   l_asnCodecPtr = getAsnCodec((int)((MapSpecificMsg*)p_MapMsg)->m_Version, 'I');
   l_PDU_Number  = MapConstants::getMapOpCodeArgPDU(((MapSpecificMsg*)p_MapMsg)->m_OpCode, ((MapSpecificMsg*)p_MapMsg)->m_Version);

   l_asnResult = l_asnCodecPtr->decode((&(p_hexData->m_value[0])),
         p_hexData->m_length,
         l_PDU_Number,
         &l_struct);

   if (l_asnResult != 0)
   {
      CLOG(0,1,"Decoding not success. Checking to add some data and then decode. [%s]", l_asnCodecPtr->getErrMsg());

      if (p_hexData->m_length > 300)
      {
         CLOG(0,1,"Invalid length of a component %d", p_hexData->m_length);
         return false;
      }

      unsigned char l_tempBuf[300+2];
      l_tempBuf[0] = 0x30;
      l_tempBuf[1] = p_hexData->m_length;
      memcpy(l_tempBuf+2, p_hexData->m_value, p_hexData->m_length);

      l_asnResult = l_asnCodecPtr->decode(&l_tempBuf[0],
            2+p_hexData->m_length,
            l_PDU_Number,
            &l_struct);

      if (l_asnResult != 0)
      {
         ELOG(0,1,"Decoding again failed");
         return false;
      }
      else
      {
         genericPrintPdu(l_asnCodecPtr, l_PDU_Number, l_struct, "<<===");
         ((MapSpecificMsg*)p_MapMsg)->m_structBuffer = l_struct;
         return true;
      }
   }
   else
   {
      genericPrintPdu(l_asnCodecPtr, l_PDU_Number, l_struct, "<<===");
      ((MapSpecificMsg*)p_MapMsg)->m_structBuffer = l_struct;
      return true;
   }
}


bool ServiceCoordinator::initiateIndependentContext(ContextBase *p_presentContext, EMapOpCode p_opCode, char *p_parameters, EInitiationType p_it)
{
   TLOG(0,1,"ServiceCoordinator::initiateIndependentContext char initiating ...");

   if( strlen(p_parameters) > MAX_PARAM_STRING_SIZE )
   {
      ELOG(0,1,"Severe Error!! Invalid Parameters length %ld. Should be less than %d", strlen(p_parameters), MAX_PARAM_STRING_SIZE);
      return false;
   }

   InterModuleData *l_imd = new InterModuleData();
   l_imd->m_OpCode = p_opCode;
   if(p_presentContext != NULL)
   {
      if(MAX_ORIG_MODULE_NAME_SIZE > 10)
      {
         sprintf(l_imd->m_OriginatorModule, "%s%s:%08d", 
               p_presentContext->m_ModName, 
               p_presentContext->m_MessageName,
               p_presentContext->m_GlobalContextId);
      }
      else
      {
         sprintf(l_imd->m_OriginatorModule, "%s%s", 
               p_presentContext->m_ModName, 
               p_presentContext->m_MessageName);
      }
   }
   else
   {
      sprintf(l_imd->m_OriginatorModule, "unknown");
   }

   DLOG(0,1,"length of the parameters [%d]", strlen(p_parameters));
   int l_Length = strlen(p_parameters);
   if(l_Length > 0)
   {
      l_imd->m_Parameters =  new char[l_Length + 500];
      snprintf(l_imd->m_Parameters,l_Length + 500,"%s",p_parameters);
   }
   DLOG(1,1,"Initiating a Context with Op Code: [%d] and Parameters: [%s]", p_opCode, p_parameters);
   if(INITIATION_TYPE_IMMEDIATE == p_it)
   {
      return g_InterModuleQueue->push(l_imd);
   }
   else if(INITIATION_TYPE_TARDILY == p_it)
   {
      TLOG(0,1,"scheduling the context");
      if (false == g_OamTransactionsList->push(l_imd, sizeof(InterModuleData)))
      {
         WLOG(0,1,"No space in SystemV message. Pushing into normal queue");
         return g_InterModuleQueue->push(l_imd);
      }
   }
   else
   {
      ELOG(0,1,"Unknown initiation type");
   }
   return false;
}


bool ServiceCoordinator::initiateIndependentContext(ContextBase *p_presentContext, EMapOpCode p_opCode, Msg *p_msgPtr)
{
   LLOG(0,1,"ServiceCoordinator::initiateIndependentContext msg initiating ...");

   if(NULL == p_msgPtr)
   {
      ELOG(0,1,"Severe Error!! Invalid Message passed to initiate a context");
      return false;
   }
   TLOG(0,1,"ServiceCoordinator::initiateIndependentContext start");

   InterModuleData *l_imd = new InterModuleData();
   l_imd->m_OpCode = p_opCode;
   if(p_presentContext != NULL)
   {
      TLOG(0,1,"ServiceCoordinator::initiateIndependentContext not null");
      if(MAX_ORIG_MODULE_NAME_SIZE > 10)
      {
         sprintf(l_imd->m_OriginatorModule, "%s%s:%08d", p_presentContext->m_ModName, p_presentContext->m_MessageName,
               p_presentContext->m_GlobalContextId);
      }
      else
      {
         sprintf(l_imd->m_OriginatorModule, "%s%s", p_presentContext->m_ModName, p_presentContext->m_MessageName);
      }
   }
   else
   {
      TLOG(0,1,"ServiceCoordinator::initiateIndependentContext null");
      sprintf(l_imd->m_OriginatorModule, "unknown");
   }
   TLOG(0,1,"ServiceCoordinator::done");


   l_imd->m_msgPtr = p_msgPtr;
   LLOG(0,1,"Initiating a Context with Op Code: [%d]  MessageType [%d]", p_opCode, l_imd->m_msgPtr->m_MsgType);
   return g_InterModuleQueue->push(l_imd);
}








InterModuleData::InterModuleData()
{
   DLOG(0,1,"InterModuleData :cons:");
   m_OpCode=0;
   memset(m_OriginatorModule, '\0', MAX_ORIG_MODULE_NAME_SIZE+1);
   //m_Parameters = NULL;
   //memset(m_Parameters, '\0', sizeof(m_Parameters));
   m_Parameters = NULL;
   m_msgPtr = NULL;
   DLOG(0,1,"InterModuleData cons end");
}


InterModuleData::~InterModuleData()
{
   if (m_msgPtr!= NULL)
   {
      delete(m_msgPtr);//TODO
      DLOG(0,0,"InterModuleData :des: m_msgPtr");
   }

   if (m_Parameters!= NULL)
   {
      delete(m_Parameters);
      m_Parameters = NULL;
      DLOG(0,0,"InterModuleData :des: m_Parameters");
   }
}






