
/* Result Sets Interface */
#ifndef SQL_CRSR
#  define SQL_CRSR
  struct sql_cursor
  {
    unsigned int curocn;
    void *ptr1;
    void *ptr2;
    unsigned int magic;
  };
  typedef struct sql_cursor sql_cursor;
  typedef struct sql_cursor SQL_CURSOR;
#endif /* SQL_CRSR */

/* Thread Safety */
typedef void * sql_context;
typedef void * SQL_CONTEXT;

/* Object support */
struct sqltvn
{
  unsigned char *tvnvsn; 
  unsigned short tvnvsnl; 
  unsigned char *tvnnm;
  unsigned short tvnnml; 
  unsigned char *tvnsnm;
  unsigned short tvnsnml;
};
typedef struct sqltvn sqltvn;

struct sqladts
{
  unsigned int adtvsn; 
  unsigned short adtmode; 
  unsigned short adtnum;  
  sqltvn adttvn[1];       
};
typedef struct sqladts sqladts;

static struct sqladts sqladt = {
  1,1,0,
};

/* Binding to PL/SQL Records */
struct sqltdss
{
  unsigned int tdsvsn; 
  unsigned short tdsnum; 
  unsigned char *tdsval[1]; 
};
typedef struct sqltdss sqltdss;
static struct sqltdss sqltds =
{
  1,
  0,
};

/* File name & Package Name */
struct sqlcxp
{
  unsigned short fillen;
           char  filnam[19];
};
static const struct sqlcxp sqlfpn =
{
    18,
    "GetDbConnection.pc"
};


static unsigned int sqlctx = 18827675;


static struct sqlexd {
   unsigned long  sqlvsn;
   unsigned int   arrsiz;
   unsigned int   iters;
   unsigned int   offset;
   unsigned short selerr;
   unsigned short sqlety;
   unsigned int   occurs;
      const short *cud;
   unsigned char  *sqlest;
      const char  *stmt;
   sqladts *sqladtp;
   sqltdss *sqltdsp;
   unsigned char  **sqphsv;
   unsigned long  *sqphsl;
            int   *sqphss;
            short **sqpind;
            int   *sqpins;
   unsigned long  *sqparm;
   unsigned long  **sqparc;
   unsigned short  *sqpadto;
   unsigned short  *sqptdso;
   unsigned int   sqlcmax;
   unsigned int   sqlcmin;
   unsigned int   sqlcincr;
   unsigned int   sqlctimeout;
   unsigned int   sqlcnowait;
            int   sqfoff;
   unsigned int   sqcmod;
   unsigned int   sqfmod;
   unsigned char  *sqhstv[1];
   unsigned long  sqhstl[1];
            int   sqhsts[1];
            short *sqindv[1];
            int   sqinds[1];
   unsigned long  sqharm[1];
   unsigned long  *sqharc[1];
   unsigned short  sqadto[1];
   unsigned short  sqtdso[1];
} sqlstm = {12,1};

// Prototypes
extern "C" {
  void sqlcxt (void **, unsigned int *,
               struct sqlexd *, const struct sqlcxp *);
  void sqlcx2t(void **, unsigned int *,
               struct sqlexd *, const struct sqlcxp *);
  void sqlbuft(void **, char *);
  void sqlgs2t(void **, char *);
  void sqlorat(void **, unsigned int *, void *);
}

// Forms Interface
static const int IAPSUCC = 0;
static const int IAPFAIL = 1403;
static const int IAPFTL  = 535;
extern "C" { void sqliem(unsigned char *, signed int *); }

typedef struct { unsigned short len; unsigned char arr[1]; } VARCHAR;
typedef struct { unsigned short len; unsigned char arr[1]; } varchar;

/* cud (compilation unit data) array */
static const short sqlcud0[] =
{12,4138,1,0,0,
5,0,0,1,0,0,31,60,0,0,0,0,0,1,0,
};


#include <GetDbConnection.h>
#include <Logger.h>
#define SQLCA_STORAGE_CLASS extern
#ifndef SQLCA_INIT
#define SQLCA_INIT 1
#endif
extern struct sqlca sqlca;

//extern bool removeContext();

/* EXEC SQL INCLUDE ../inc/ConnectionObject.h;
 */ 
#ifndef __CONNECTION_OBJECT_H
#define __CONNECTION_OBJECT_H

#include <sqlda.h>

#include <string>
#include <Logger.h>
#include <ConfigReader.h>

#define CONNECTION_ATTEMPTS 5
#define MEMBER_STATE_GOOD	0
#define MEMBER_STATE_BAD	1

extern struct oraca oraca;

#ifndef SQLCA
#define SQLCA 1
struct   sqlca
{
   /* ub1 */ char    sqlcaid[8];
   /* b4  */ int     sqlabc;
   /* b4  */ int     sqlcode;
   struct
   {
      /* ub2 */ unsigned short sqlerrml;
      /* ub1 */ char           sqlerrmc[70];
   } sqlerrm;
   /* ub1 */ char    sqlerrp[8];
   /* b4  */ int     sqlerrd[6];
   /* ub1 */ char    sqlwarn[8];
   /* ub1 */ char    sqlext[8];
};
#endif

#include <sqlca.h>

extern struct sqlca sqlca;
extern struct oraca oraca;

class ConnectionObject
{

   public:
      // This variable indicates the state of the runtime context
      int	iState ;				
      /* EXEC SQL BEGIN DECLARE SECTION; */ 
		
      /* varchar	iCntStr[200]; */ 
struct { unsigned short len; unsigned char arr[200]; } iCntStr;

      /* EXEC SQL END DECLARE SECTION; */ 

   public:

      /* EXEC SQL BEGIN DECLARE SECTION; */ 

      sql_context iCtx;
      /* EXEC SQL END DECLARE SECTION; */ 


      // Default Context Object
      ConnectionObject(string mCntStr) ;

      ~ConnectionObject();
};


#endif




void *getConnObject(char *p_connStr, char *p_alias)
{
   ConnectionObject *l_co = NULL;
   l_co = new ConnectionObject(p_connStr);
   if(MEMBER_STATE_GOOD == l_co->iState)
   {
      TLOG(0,1,"Connected to %s", p_alias);
      return l_co;
   }
   else
   {
      CLOG(0,1,"Unable to connect to %s", p_alias);
      if(l_co != NULL)
      {
         delete(l_co);
      }
      return NULL;
   }
}


void *getConnCtx(void *p_connObject)
{
    if(p_connObject != NULL)
    {
	return ((ConnectionObject*)p_connObject)->iCtx;
    }
    else
    {
	return NULL;
    }
    return NULL;
}


void destructConnObject(void *p_connObject)
{
    //removeContext();
    delete((ConnectionObject*)p_connObject);
}

void rollback(void *p_conn)
{
   struct sqlca sqlca;
   memset(&sqlca, '\0', sizeof(sqlca));

   /* EXEC SQL CONTEXT USE :p_conn; */ 

   /* EXEC SQL ROLLBACK; */ 

{
   struct sqlexd sqlstm;
   sqlstm.sqlvsn = 12;
   sqlstm.arrsiz = 0;
   sqlstm.sqladtp = &sqladt;
   sqlstm.sqltdsp = &sqltds;
   sqlstm.iters = (unsigned int  )1;
   sqlstm.offset = (unsigned int  )5;
   sqlstm.cud = sqlcud0;
   sqlstm.sqlest = (unsigned char  *)&sqlca;
   sqlstm.sqlety = (unsigned short)4352;
   sqlstm.occurs = (unsigned int  )0;
   sqlcxt(&p_conn, &sqlctx, &sqlstm, &sqlfpn);
}


}



