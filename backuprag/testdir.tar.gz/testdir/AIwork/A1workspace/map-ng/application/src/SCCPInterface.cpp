/*********************************************************************
 **********************************************************************
 ** FILE NAME  : SCCPInterface.cpp  
 ** DEFINTION  : Implements the SCCP Message handler class
 ** REMARKS    :
 **********************************************************************
 *********************************************************************/

#include <iostream>
#include <fstream>
#include <list>
#include <stdlib.h>
#include <string>
#include <time.h>

#include <apiinc.h>
#include <tcap.h>
#include <tcerror.h>
#include <ObjectServer.h>
#include <ccapiproto.h>

#include "SCCPInterface.h"
#include "ConfigReader.h"
#include "SCCPMsgHandler.h"
#include "Logger.h"
#include <GUtilThreadHeartBeat.h>
#include <SnmpInterface.h>
//#include <StatisticsHandler.h>
#include <ServiceCoordinator.h>
#include <DbActiveObject.h>

#include <UpdateInstanceStatus.h>
#include <CurrentTime.h>

using namespace std;
extern bool g_sigUsr2;
extern bool g_loopMsgIgnoredFlag;
extern int g_MaxTPSTrap;
extern map<string,time_t> g_msisdnTransactionMap;
extern map<string,HeavyTransaction> g_HeavyTransactionMap;
extern int g_RejectMaxTPSIndex;
extern int g_maxTpsDataIndex;
extern bool g_dynamicConfigurationFlag;

extern void congestionControlActions();

/* global data */
BOOL tickTimerCalled2;
#define SERVER_INVOKE_TIMER  3
#define SERVER_IPC_RETRY_2 5
#define TCAP_ALRM_INT 1         /* interval for SIGALRM signals */
#define INVOKE_COUNT 32000
#define TBLOCK_COUNT 32000


#ifdef __cplusplus
extern "C" {
#endif

   typedef void(*PFV)();

#ifdef __cplusplus
};
#endif

#define MY_NAME (pSHM->cpt[OwnClientTableEntry].ClientLogicalName)
#define serverExit(x) FtTerminate(NOrestart, (x))

#define SERVER_OOS_NAME (FT_ACTIVE_PREFIX ObjectSVRLogicalNAME)

extern void readPortedNumberInfo();
extern void  readUserSignalFunc();
int AFormatSCCPcblock (sblock_t* psb         /* sblock from TCAP */
      ,cblock_t *cb     /* cblocks to be filled in */
      ,int size         /* max cblocks to fill */
      ,int *CblkRet); /* total number cblks filled*/
int AFormatSCCPsblock (sblock_t* psb         /* sblock from TCAP */
      ,cblock_t *cb     /* cblocks to be filled in */
      ,int size         /* max cblocks to fill */
      ,int *CblkRet); /* total number cblks filled*/

int CFormatSCCPcblock2 (sblock_t* psb         /* sblock from TCAP */
      ,cblock_t *cb     /* cblocks to be filled in */
      ,int size         /* max cblocks to fill */
      ,int *CblkRet) /* total number cblks filled*/
{
   return cFormatSCCPcblock(psb, cb, size, CblkRet);
}

int CFormatSCCPsblock2 (sblock_t* psb         /* sblock from TCAP */
      ,cblock_t *cb     /* cblocks to be filled in */
      ,int size         /* max cblocks to fill */
      ,int *CblkRet) /* total number cblks filled*/
{
   return cFormatSCCPsblock(psb, cb, size, CblkRet);
}

extern void processOtherMessages();

void printTime(struct timeval &currTv, struct timeval &prevTv, char *str = NULL, int dlgId = 0)
{
   prevTv = currTv;

#ifdef SunOS
      gettimeofday(&currTv);
#else
      gettimeofday(&currTv, NULL);
#endif

   if(NULL != str)
   {
      struct timeval diffTime;

      if(prevTv.tv_sec < currTv.tv_sec)
      {
         diffTime.tv_sec = currTv.tv_sec - prevTv.tv_sec;
         if(prevTv.tv_usec <= currTv.tv_usec)
         {
            diffTime.tv_usec = currTv.tv_usec - prevTv.tv_usec;
         }
         else
         {
            diffTime.tv_usec = 1000000 - prevTv.tv_usec;
            if(1000000 <= (diffTime.tv_usec + currTv.tv_usec))
            {
               diffTime.tv_sec += 1;
               diffTime.tv_usec = (1000000 - prevTv.tv_usec) + currTv.tv_usec - 1000000;
            }
            else
            {
               diffTime.tv_sec -= 1;
               diffTime.tv_usec += currTv.tv_usec;
            }
         }
      }
      else
      {
         diffTime.tv_sec = 0;
         diffTime.tv_usec = currTv.tv_usec - prevTv.tv_usec;
      }

      int i;
      char buf[128];
      char l_buf[128];
      snprintf(buf, sizeof(buf), "%ld", diffTime.tv_usec);
      int len = strlen(buf);
      snprintf(buf, sizeof(buf), "%ld.", diffTime.tv_sec);

      for(i = 0; i < (6-len); i++)
      {
         strcat(buf, "0");
      }

      snprintf(l_buf, sizeof(l_buf), "%s%ld", buf, diffTime.tv_usec);

      //g_LoggerObj.log(LOG_LEVEL_PERFORMANCE, "[%d]: %s<Line: %d> %s prevSec: %ld prevMsec: %ld currSec: %ld currMsec: %ld diffTime: %s", dlgId, __FUNCTION__, __LINE__, str, prevTv.tv_sec, prevTv.tv_usec, currTv.tv_sec, currTv.tv_usec, l_buf);
   }
}

/*****************************************************************************
 ** FUNCTION NAME  : SCCPInterface::getInstance
 **
 ** DEFINITON      : This function returns the singleton instance of the class
 **
 ** ARGUMENTS      : None
 **
 ** RETURN         : It returns reference to singleton object of the class
 **
 ** REMARKS        :
 *****************************************************************************/
SCCPInterface& SCCPInterface::getInstance()
{
   static SCCPInterface instance;
   return instance;
}

/* FUNCTION SYSLogEvent() - print log information for TCAP library */
/**************************************************************************

  FUNCTION
  void SYSLogEvent(int entity, int mask, char *ptr)

  DESCRIPTION
  This function is called by the TCAP library to send debug
  information to the outside world.  It will only be called as
  enabled by bits in the global variable tcap_dbg_mask.  The
  function sends the data to stdout.

  INPUTS
Args:   entity - ignored
mask - ignored
ptr - character string data

Others: process logical name in CPT.


OUTPUTS
Return: none

Args:   none

Others: Characters to stdout via printf().

FEND
 **************************************************************************/
/*void SYSLogEvent (int entity, int mask, char *ptr)
{
   //g_LoggerObj.log(LOG_LEVEL_DEBUG, "%s<Ln: %d> TCAPLIB: %s",__FUNCTION__,__FILE__,ptr);
}*/

/* FUNCTION sigalrmHandler() - handler for ALRM signal from Unix */
/**************************************************************************

  FUNCTION
  void sigalrmHandler(void)

  DESCRIPTION
  This function is the signal handler for the Unix ALRM signal.

  INPUTS
Args:   none

Others: none


OUTPUTS
Return: none

Args:   none

Others: call to cTCAPTickTimer().
global flag tickTimerCalled set.

FEND
 **************************************************************************/
void sigalrmHandler3 (void)
{
   tickTimerCalled2 = TRUE;
}

/* FUNCTION sigintHandler() - handler for INT signal from Unix */
/**************************************************************************
  FUNCTION
  void sigintHandler(void)

  DESCRIPTION
  This function is the signal handler for the Unix INT signal.  It
  causes the program to terminate.

  INPUTS
Args:   none

Others: none


OUTPUTS
Return: none

Args:   none

Others: Sets terminate.

FEND
 **************************************************************************/
void sigintHandler2 (void)
{
   //g_LoggerObj.log(LOG_LEVEL_CRITICAL, "%s<Ln: %d> SIGINT received, application is going to exiting... ", __FUNCTION__, __LINE__);
   exit(0);	/* not in main loop yet */
}

/*****************************************************************************
 ** FUNCTION NAME  : SCCPInterface::openConn
 **
 ** DEFINITON      : This function is used to open connection with SS7 stack
 **
 ** ARGUMENTS      : className(in) -> The class containing information about
 **                  SS7 stack to be connected to
 **
 ** RETURN         : true if connection successfully opened
 **                  false if open connection failed
 **
 ** REMARKS        :
 *****************************************************************************/
bool SCCPInterface::openConn(int argc, char *argv[])
{
#if 1    // TODO REMOVE REMOVE 
//snprintf(g_ConfigData->m_StackName,sizeof(g_ConfigData->m_StackName),"%s","stack2");
//g_ConfigData->m_localSSN = 86;
#endif
   try
   { 
      int result;
      int distOpt = TCAP_DATA_PRIMITIVE; // PKS TCAP_CONTROL_DATA_PRIMITIVE;
      char myLogicalName[MAXlogicalNAME + 1];
      BOOL savDebugIndicator;	/* save value from -debug */

      char l_tempChar[30];
      snprintf(l_tempChar, sizeof(l_tempChar), "%s%03d_", g_ConfigData->m_EntityName, g_ConfigData->m_InstanceId);

      /* attach to Foundation Toolkit */
      FtUniqueName (l_tempChar, myLogicalName);
      if (FtAttachEx (myLogicalName, argv[0], " ", 0, 0, 0, 0, 5, FALSE) == RETURNerror)
      {
         CLOG(0,0,"FtAttachEx() failed exiting errno: %d",errno);

         return false;

      }
      TLOG(0,0,"FtAttachEx() is sucessful");

      /* register with Foundation Toolkit */
      result = FtRegisterEx (argc, /* Cmd Ln Token Count        */
            argv,  /* Cmd Ln Tokens              */
            (g_OtherConfigData->m_DebugLogLevel == 1)?TRUE:FALSE, /* Debug                      */
            FALSE, /* Monitor                    */
            TRUE,  /* Queue Required             */
            FALSE, /* Flush Queue                */
            TRUE,  /* Enqueue always             */
            TRUE,  /* Catches SIGINT             */
            NOrestart, /* Restart type           */
            0,     /* Class declaration          */
            0,     /* State declaration          */
            0,     /* Event filter               */
            10,    /* Retry count                */
            FALSE); /* Alertable                 */
      if (result == RETURNerror)
      {
         CLOG(0,0,"FtRegisterEx() failed exiting errno: %d",errno);

         return false;
      }
      TLOG(0,0,"FtRegisterEx() is sucessful");

      if (FtAssignHandler (SIGINT, sigintHandler2) == RETURNerror)
      {
         CLOG(0,0,"FtAssignHandler() failed exiting errno: %d",errno);
         return false;
      }
      TLOG(0,0,"FtAssignHandler() is sucessful");

      /* attach and bind to logical node */
      savDebugIndicator = DebugIndicator;
      DebugIndicator = FALSE;	/* off during SYSattach() */
      DebugIndicator = savDebugIndicator;

      int nodeIndex = SYSattach ((char *)g_OtherConfigData->m_StackName, FALSE);
      if (nodeIndex == RETURNerror)
      {
         CLOG(0,0,"SYSattach() failed exiting errno: %d",errno);
         return false;

      }
      TLOG(0,0,"SYSattach() is sucessful");
      distOpt = SCCP_CLASS0;
      result = SYSbind (nodeIndex, FALSE, MTP_SCCP_USER, g_OtherConfigData->m_localSSN, distOpt);
      if (result == RETURNerror)
      {
         CLOG(0,0,"SYSbind() failed exiting errno: %d",errno);
         return false;
      }
      TLOG(0,0,"SYSbind() is sucessful");

      /* Send user-in-service from all processes.  Data-only processes
         send UIS because stopping the last remaining data
         process generates an automatic user-out-of-service.  */
      if (CscUIS (nodeIndex, g_OtherConfigData->m_localSSN) == RETURNerror)
      {
         CLOG(0,0,"CscUIS() failed exiting errno: %d",errno);
         return false;
      }
      TLOG(0,0,"CscUIS() is sucessful");

      /* Setup the SIGALRM signal handler */
      tickTimerCalled2 = FALSE;
      if (FtAssignHandler (SIGALRM, sigalrmHandler3) == RETURNerror)
      {
         CLOG(0,0,"FtAssignHandler() failed exiting errno: %d",errno);
         return false;
      }
      TLOG(0,0,"FtAssignHandler() is sucessful");

      if (FtStartTimer (1, 0, FALSE) == RETURNerror)
      {
         CLOG(0,0,"FtStartTimer() failed exiting errno: %d",errno);
         return false;
      }
      TLOG(0,0,"FtStartTimer() is sucessful");
      /* SIGINT will set terminate */
   }       
   catch(...)
   {
      CLOG(0,0,"SCCP openConn Exception occurred.");
      return false;
   }
   return true;
}

int SCCPInterface::sendRecvMsgs()
{
   int g_currentTrans=0;
   time_t g_lastTimeSecond=time(NULL);
   struct
   {
      cblock_t cblockIn;
      U8 data[2048];
   } ipcIn;

   sblock_t *sblockIn = NULL;
   int nCblocksIn;
   int ret_status = RETURNerror;
   struct timeval currTime, prevTime;


   FOREVER
   {
      if (tickTimerCalled2)
      {
         g_currentTrans =0;
         congestionControlActions();  
         SCCPTickTimer();
         tickTimerCalled2 = FALSE;
         g_thb.iAmAlive();

         //time_t l_currenttime = time(NULL);
         setCurrentTime();  //This sets the global datestring variable with the current time
      }
      else
      {
         int hopCntr = 0;
         printTime(currTime, prevTime);
         if (FtGetIpcEx (&ipcIn.cblockIn.hdr, 0, sizeof ipcIn, TRUE, TRUE, TRUE) == RETURNerror)
         {
            printTime(currTime, prevTime, "FtGetIpcEx");
            if (errno == EINTR)
             {
               continue;
             }
            CLOG(0,0,"FtGetIpcEx() failed exiting errno: %d",errno);
            serverExit (1);
         }
         printTime(currTime, prevTime, "FtGetIpcEx");
          sblockIn = (sblock_t*)malloc(sizeof(sblock_t));
          memset(sblockIn, 0, sizeof(sblock_t));
         /* here we have a new IPC message */
         if (ipcIn.cblockIn.hdr.messageType == N_UNITDATA_IND)// || ipcIn.cblockIn.hdr.messageType == N_NOTICE_IND)
         {
            hopCntr = ipcIn.cblockIn.ULCM_CBLOCK_KERNEL_UNION.msu.mtp_ud.sccp.ud.xudts.hop_cntr;

            if('I' == g_OtherConfigData->m_Sccp_Type[0])
            {
               ret_status = CFormatSCCPsblock2 (sblockIn    /* sblock from TCAP */
                     ,&ipcIn.cblockIn                       /* cblocks to be filled in */
                     ,1                                     /* max cblocks to fill */
                     ,&nCblocksIn);                         /* total number cblks filled*/
            }
            else
            {
               ret_status = AFormatSCCPsblock (sblockIn    /* sblock from TCAP */
                     ,&ipcIn.cblockIn                       /* cblocks to be filled in */
                     ,1                                     /* max cblocks to fill */
                     ,&nCblocksIn);                         /* total number cblks filled*/
            }

            //if (cFormatSCCPsblock (&sblockIn, &ipcIn.cblockIn, 1, &nCblocksIn) == RETURNerror)
            if(RETURNerror == ret_status)
            {
               extern char APIErr[256];

               CLOG(0,0,"cFormatSCCPsblock() failed exiting");
            }
#if 0 //SCCP DUMP
            printf("SCCP DUMP\n==========================================\n");
            for(int i = 0; i < sblockIn->prim.nunitd.data_size; i++)
            {
               printf("%02x ", sblockIn->prim.nunitd.pdata[i]);
            }
            printf("\n==========================================\n");

#endif

         
            SCCPMsgHandler sccpObj;
            int paddedBytes = 0;
            int dataSize = sblockIn->prim.nunitd.data_size+1;
            unsigned char paddedData[16];
            memcpy(paddedData, &sblockIn->prim.nunitd.pdata[sblockIn->prim.nunitd.data_size+1], 16);
            g_loopMsgIgnoredFlag=false;

            char pMsisdn[20+1];
            memset(pMsisdn,'\0',sizeof(pMsisdn)); 
            if(false == sccpObj.processSCCPMsg(sblockIn, paddedBytes, pMsisdn))
            {
             LLOG(0,0,"Other than SRI message flow, deleting sblock ptr");
             if(NULL != sblockIn)
             {
              DLOG(0,0,"Destructor sblock deleting in NG");
              free(sblockIn);
              sblockIn = NULL;
             }
            }
         }
      }
   processOtherMessages();
   } /* end FOREVER */
   return RETURNok;
}

