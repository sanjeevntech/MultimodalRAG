#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <pthread.h>
#include <strings.h>
#include <errno.h>
#include <ctype.h>
#include <Logger.h>
#include <ConfigReader.h>
#include <TcpSocketClient.h>



TcpSocketClient::TcpSocketClient()
{
   CLOG(0,1,"TcpSocketClient cons");
}

TcpSocketClient::~TcpSocketClient()
{
   CLOG(0,1,"TcpSocketClient des");
}

bool dataAvailable(int p_sockFd, int p_timeout)
{
   struct timeval l_tv;
   l_tv.tv_sec = p_timeout;
   l_tv.tv_usec = 0;

   fd_set read_mask;
   FD_ZERO(&read_mask);
   FD_SET(p_sockFd, &read_mask);
   DLOG(0,0, "Checking if there is space to send");
   int nfd = select(p_sockFd+1, (fd_set *)&read_mask, (fd_set*)NULL, (fd_set *)NULL, (struct timeval *)&l_tv);/* will block */
   if (nfd > 0)
   {
      DLOG(0,1,"There is data to read");
      return true;
   }
   else if (-1 == nfd)
   {
      CLOG(0,0,"select returned -1");
      return false;
   }
   else
   {
      DLOG(0,1,"Timer (%d secs) expired.", l_tv.tv_sec);
      return false;
   }
}

bool available(int p_sockFd, int p_timeout)
{
   struct timeval l_tv;
   l_tv.tv_sec = p_timeout;
   l_tv.tv_usec = 0;

   fd_set write_mask;
   FD_ZERO(&write_mask);
   FD_SET(p_sockFd, &write_mask);
   DLOG(0,0, "Checking if there is space to send");
   int nfd = select(p_sockFd+1, (fd_set *)NULL, &write_mask, (fd_set *)NULL, (struct timeval *)&l_tv);/* will block */
   if (nfd > 0)
   {
      DLOG(0,1,"Data can be sent");
      return true;
   }
   else if (-1 == nfd)
   {
      CLOG(0,0,"select returned -1");
      return false;
   }
   else
   {
      WLOG(0,1,"Timer (%d secs) expired.", l_tv.tv_sec);
      return false;
   }
}

bool TcpSocketClient::sendDataToNetwork(int p_sockFd, unsigned char *p_data, int p_length, int p_timeout)
{
   unsigned char *l_data = (unsigned char *)"Some Error";
   int l_length=strlen((char*)l_data);

   if (NULL != p_data)
   {
      l_data = p_data;
      l_length = p_length;
   }

   if (0 == l_length)
   {
      CLOG(0,1,"SockFd:[%d] sendDataToNetwork failed. Invalid Length", p_sockFd);
      return false;
   }
   if (p_sockFd != 0)
   {
      char l_lengthChar[10];
      memset(l_lengthChar, '\0', 10);
      sprintf(l_lengthChar, "%09d", l_length);

      DLOG(0,1,"Sending Length [%s]", l_lengthChar);

      if (false == available(p_sockFd, p_timeout))
      {
         CLOG(0,1,"sendDataToNetwork failed. Not available to send length SockFd:[%d]", p_sockFd);
         return false;
      }

      if (send(p_sockFd, l_lengthChar, 9, 0) == -1) 
      {
         CLOG(0,1,"sendDataToNetwork failed. Unable to send length SockFd:[%d]", p_sockFd);
         perror("send");
         return false;
      }

      if (false == available(p_sockFd, p_timeout))
      {
         CLOG(0,1,"sendDataToNetwork failed. Not available to send data SockFd:[%d]", p_sockFd);
         return false;
      }

      if (send(p_sockFd, l_data, l_length, 0) == -1) 
      {
         CLOG(0,1,"sendDataToNetwork failed. Unable to send data SockFd:[%d]", p_sockFd);
         perror("send");
         return false;
      }
      DLOG(0,1,"Sending data successfull\n");
   }
   return true;
}


int TcpSocketClient::recvAllWithLength(int p_sockFd, char *p_buf, int p_len, int p_timeoutInSecs)
{
   char l_length[10];
   memset(l_length, '\0', sizeof(l_length));

   if(9 != recvAll(p_sockFd, l_length, 9, p_timeoutInSecs))
   {
      CLOG(0,1,"Unable to receive length SockFd:[%d]", p_sockFd);
      return -1;
   }

   int l_dataLength=atoi(l_length);
   if(l_dataLength != recvAll(p_sockFd, p_buf, l_dataLength, p_timeoutInSecs))
   {
      CLOG(0,1,"Unable to receive data SockFd:[%d]", p_sockFd);
      return -1;
   }
   return l_dataLength;
}

int TcpSocketClient::recvAll(int p_sockFd, char *p_buf, int p_len, int p_timeoutInSecs)
{
   TLOG(0,1,"Waiting for length [%d] for SockFd:[%d]  timeout[%d]", p_len, p_sockFd, p_timeoutInSecs);
   if(0 > p_sockFd)
   {
      ELOG(0,1,"Invalid SockFd:[%d]", p_sockFd);
      return -1;
   }

   if (1 > p_len)
   {
      ELOG(0,1,"Invalid Length in input : %d", p_len);
      return -1;
   }

   if ( (1 > p_timeoutInSecs) || (100 < p_timeoutInSecs) )
   {
      ELOG(0,1,"Invalid timeout in input %d", p_timeoutInSecs);
   }

   int l_total = 0;
   int l_receivedBytes = 0;
   struct timeval l_tv;
   l_tv.tv_sec = p_timeoutInSecs;          
   l_tv.tv_usec = 0;

   while(l_total < p_len)
   {
      fd_set read_mask;
      FD_ZERO(&read_mask);
      FD_SET(p_sockFd, &read_mask);
      DLOG(0,0, "Checking if there is data to read");
      int nfd = select(p_sockFd+1, &read_mask, (fd_set *)NULL, (fd_set *)NULL, (struct timeval *)&l_tv);/* will block */
      if (nfd > 0)
      {
         TLOG(0,1,"Data present checking for %d bytes", p_len-l_total);
         l_receivedBytes = recv(p_sockFd, p_buf+l_total, p_len-l_total, MSG_DONTWAIT);
         if (0 >= l_receivedBytes)
         {
            if(0 > l_receivedBytes)
            {
               WLOG(0,1,"recv failed with errno:[%d] error desc: [%s]",errno, strerror(errno));
               if (EINTR == errno)
                  continue;
            }
            else
            {
               LLOG(0,1,"Socket closed by Peer");
            }
            return l_receivedBytes;
         }
         else
         {
            l_total += l_receivedBytes;
            DLOG(0,1,"Received bytes %d, bytesleft %d, len %d, SockFd:[%d]",l_receivedBytes,p_len-l_total, p_len, p_sockFd);
         }
      }
      else if (-1 == nfd)
      {
         CLOG(0,1,"Error in select %d", errno);
         if (EINTR == errno)
            continue;
      }
      else
      {
         WLOG(0,1,"Timer (%d secs) expired. Received only %d byte(s) while expected is %d byte(s) ", p_timeoutInSecs, l_total, p_len);
         return -1;
      }
   }
   TLOG(0,1,"Returning %d", l_total);
   return l_total;
}


bool TcpSocketClient::connectToApp(int *p_sock, char *p_AppRegResp, char *p_ErrMsg)
{
   //struct addrinfo hints;
   int l_sock;

   if ( (m_AgentPort < 1024) ||
         (m_AgentPort > 99999) )
   {
      sprintf(p_ErrMsg, "port should be between 1024 and 99999");
      return false;
   }

   if ((l_sock = socket(PF_INET, SOCK_STREAM, 0)) == -1) 
   {
      perror("socket");
      return false;
   }

   struct sockaddr_in dest_addr; // will hold the destination addr
   dest_addr.sin_family = AF_INET; // host byte order
   dest_addr.sin_port = htons(m_AgentPort); // short, network byte order
   dest_addr.sin_addr.s_addr = inet_addr(m_AgentIp);
   memset(&(dest_addr.sin_zero), '\0', 8); // zero the rest of the struct

   if (connect(l_sock, (struct sockaddr *)&dest_addr, sizeof(struct sockaddr)) == -1) 
   {
      close(l_sock);
      sprintf(p_ErrMsg, "connect: %s", strerror(errno));
      return false;
   }


   char l_entity[10000+1];
   memset(l_entity, '\0', sizeof(l_entity));
   snprintf(l_entity, sizeof(l_entity), "<REGISTRATION_REQUEST><HEADER><ENTITY_NAME>%s</ENTITY_NAME><TITLE>%s</TITLE><CONNECTION_TYPE>0</CONNECTION_TYPE></HEADER></REGISTRATION_REQUEST>", 
         m_selfEntityName, g_title); 

   if (false == sendDataToNetwork(l_sock, (unsigned char*)l_entity, strlen(l_entity), 60))
   {
      CLOG(0,1,"Unable to send the registration message");
      return false;
   }

   TLOG(0,1,"TcpSocketClient: Waiting for registration response");

   char l_reg_res_length[10];
   memset(l_reg_res_length, '\0', sizeof(l_reg_res_length));
   if (9 != recvAll(l_sock, l_reg_res_length, 9, 60))
   {
      close(l_sock);
      CLOG(0,1,"Unable to receive the registration response length");
      return false;
   }
   int l_reg_res_length_int = atoi(l_reg_res_length);

   TLOG(0,1,"TcpSocketClient: Received Registration Response Length [%s] [%d]",l_reg_res_length, l_reg_res_length_int); 

   char l_reg_res[1024];
   memset(l_reg_res, '\0', l_reg_res_length_int);
   if (l_reg_res_length_int != recvAll(l_sock, l_reg_res, l_reg_res_length_int, 2))
   {
      close(l_sock);
      CLOG(0,1,"Unable to receive the registration of length %d", l_reg_res_length_int);
      return false;
   }

   TLOG(0,1,"TcpSocketClient: Received Registration Response [%s]",l_reg_res); 

   if (strstr(l_reg_res, "<ERROR_CODE>0</ERROR_CODE>"))
   {
      LLOG(0,1,"Connected to RTPS with SockFd:[%d]", l_sock);
   }
   else
   {
      close(l_sock);
      CLOG(0,1, "TcpSocketClient: CRITICAL!!! Could not register with the RTPS. Check RTPS Configuration file");
      CLOG(0,1, "Received response [%s]", l_reg_res);
      sleep(2);
      return false;
   }

   *p_sock = l_sock;
   return true;
}

int g_agentFd=-1;



bool TcpSocketClient::initialize(char *p_selfEntityName, char *p_AgentIp, int p_AgentPort)
{
   if( (strlen(p_selfEntityName) < 3) || (strlen(p_selfEntityName) > 9))
   {
      printf("\nERROR TcpSocketClient::initialize Combination of Entity Name and InstanceID should be between 3-9 digits");
      CLOG(0,1,"ERROR TcpSocketClient::initialize Combination of Entity Name and InstanceID should be between 3-9 digits");
      return false;
   }
   strncpy(m_selfEntityName, p_selfEntityName, 10);

   if( (p_AgentPort < 1025) || (p_AgentPort > 65535))
   {
      printf("\nERROR TcpSocketClient::initialize Agent Port should be between 1025 and 65535");
      CLOG(0,1,"ERROR TcpSocketClient::initialize Agent Port should be between 1025 and 65535");
      return false;
   }
   m_AgentPort=p_AgentPort;

   if( (strlen(p_AgentIp) < 3) ||
         (strlen(p_AgentIp) > 20)
     )
   {
      printf("\nERROR: TcpSocketClient::initialize Invalid Agent IP: [%s]", p_AgentIp);
      CLOG(0,1,"ERROR: TcpSocketClient::initialize Invalid Agent IP: [%s]", p_AgentIp);
      return false;
   }
   strncpy(m_AgentIp, p_AgentIp, 20);

   DLOG(0,1,"TcpSocketClient initialized successfully");
   return true;
}





