/*****************************************************************************
 ** FILE NAME      : MemcUtilities.cpp
 ****************************************************************************/
#include <MemCachedUtilities.h>
#include <Logger.h>
#include <libmemcached/memcached.h>
#include <SnmpInterface.h>
#include <ConfigReader.h>
#include<StatisticsInterface.h>

int g_HomeImsiGetMemcQueryTotal;
int g_HomeImsiSetMemcQueryTotal;
int g_OtherImsiGetMemcQueryTotal;
int g_OtherImsiSetMemcQueryTotal;

int g_HomeImsiGetMemcQuerySuccess;
int g_HomeImsiSetMemcQuerySuccess;
int g_OtherImsiGetMemcQuerySuccess;
int g_OtherImsiSetMemcQuerySuccess;

int g_HomeImsiGetMemcQueryMissesNoData;
int g_OtherImsiGetMemcQueryMissesNoData;

int g_HomeImsiGetMemcQueryMissesCommuniError;
int g_HomeImsiSetMemcQueryMissesCommuniError;
int g_OtherImsiGetMemcQueryMissesCommuniError;
int g_OtherImsiSetMemcQueryMissesCommuniError;

int g_deleteMemcQueryTotal;
int g_deleteMemcQuerySuccess;
int g_deleteMemcQueryFailure;

int g_ULRHomeImsiGetMemcQueryTotal;
int g_ULRHomeImsiSetMemcQueryTotal;

int g_ULRHomeImsiGetMemcQuerySuccess;
int g_ULRHomeImsiSetMemcQuerySuccess;

int g_ULRHomeImsiGetMemcQueryMissesNoData;


int g_ULRHomeImsiGetMemcQueryMissesCommuniError;
int g_ULRHomeImsiSetMemcQueryMissesCommuniError;

int g_ULRdeleteMemcQueryTotal;
int g_ULRdeleteMemcQuerySuccess;
int g_ULRdeleteMemcQueryFailure;

bool RetrieveMemCached(void *p, string pKey, string &pValue, int &pErrCode, string &pErrDesc, bool pHomeImsi, string pMemcIp, int pMemcPort)
{
   memcached_st *memc = (memcached_st*)p;   
   memcached_return rc;

   uint32_t l_flags;
   size_t l_valueLen;
   bool l_stats=true;

   if(0 == strcmp(pKey.c_str(),"MemcHearBeatDummyKey"))
      l_stats = false;

   LLOG(0,0,"GET_MEMCACHED_DATA: for Key[%s]", pKey.c_str());

   char *l_val = memcached_get(memc, pKey.c_str(), pKey.length(), &l_valueLen, &l_flags, &rc);

   if(false == l_stats)
      return true;
   if('R' == pKey.at(pKey.length() - 1))
   {
   HLRStatisticsInitializer::logStatistics(g_ULRHomeImsiGetMemcQueryTotal);
   }
   else
   {
   HLRStatisticsInitializer::logStatistics((true == pHomeImsi)?g_HomeImsiGetMemcQueryTotal:g_OtherImsiGetMemcQueryTotal);
   }

   if (rc == MEMCACHED_SUCCESS) 
   {
      LLOG(0,0, "GET_MEMCACHED_DATA: Key retrieved successfully");
      if(l_val != NULL)
      {
         pValue = l_val;
         LLOG(0,0,"GET_MEMCACHED_DATA: Key[%s] returned value[%s] SUCCESS", (char*)pKey.c_str(), (char*)pValue.c_str());
         pErrDesc.assign("Success");
         
     if('R' == pKey.at(pKey.length() - 1))
     {
     HLRStatisticsInitializer::logStatistics(g_ULRHomeImsiGetMemcQuerySuccess);
     }
     else
     {
      HLRStatisticsInitializer::logStatistics((true == pHomeImsi)?g_HomeImsiGetMemcQuerySuccess:g_OtherImsiGetMemcQuerySuccess);
     }     
    
     free(l_val);
      }
   }
   else
   {
      ELOG(0,0, "GET_MEMCACHED_DATA: Couldn't retrieve Key:[%s] Reason: [%s]", pKey.c_str(), memcached_strerror(memc, rc));

      pErrDesc.assign(memcached_strerror(memc, rc));
      pErrCode = rc;
      
      char l_trapDesc[200+1];
      snprintf(l_trapDesc,sizeof(l_trapDesc), "[IP:%s Port:%d]", pMemcIp.c_str(), pMemcPort);
      if((MEMCACHED_CONNECTION_FAILURE == pErrCode) || (MEMCACHED_SERVER_TEMPORARILY_DISABLED == pErrCode))   // errorCode: 3 and 47
      {
         LLOG(0,0,"GET_MEMCACHED_DATA: CONNECTION FAILURE [IP:%s Port:%d], Sending TRAP",pMemcIp.c_str(), pMemcPort);
         g_si.sendSnmpTrap(g_MemcGetConnectionFailTrap, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL, l_trapDesc);

       if('R' == pKey.at(pKey.length() - 1))
       {
        HLRStatisticsInitializer::logStatistics(g_ULRHomeImsiGetMemcQueryMissesCommuniError);
       }
       else
       {
        HLRStatisticsInitializer::logStatistics((true == pHomeImsi)?g_HomeImsiGetMemcQueryMissesCommuniError:g_OtherImsiGetMemcQueryMissesCommuniError);
       }
      
      }
      if(MEMCACHED_NOTFOUND == pErrCode)
      {
         TLOG(0,0,"GET_MEMCACHED_DATA: NOTFOUND, Logging Statistics");
       if('R' == pKey.at(pKey.length() - 1))
       {
        HLRStatisticsInitializer::logStatistics(g_ULRHomeImsiGetMemcQueryMissesNoData);
       }
       else
       {
        HLRStatisticsInitializer::logStatistics((true == pHomeImsi)?g_HomeImsiGetMemcQueryMissesNoData:g_OtherImsiGetMemcQueryMissesNoData);
       }
      }
      return false;
   }

   pErrCode = rc;
   return true;
}

bool UpdateMemCached(void *p, string pKey, string &pValue, int &pErrCode, string &pErrDesc, bool pHomeImsi, string pMemcIp, int pMemcPort)
{
   memcached_st *memc = (memcached_st*)p;
   memcached_return rc;

   rc = memcached_set(memc, pKey.c_str(), pKey.length(), pValue.c_str(), pValue.length(), (time_t)0, (uint32_t)0);
   
   if('R' == pKey.at(pKey.length() - 1))
   {
    HLRStatisticsInitializer::logStatistics(g_ULRHomeImsiSetMemcQueryTotal);
   }
   else
   {
    HLRStatisticsInitializer::logStatistics((true == pHomeImsi)?g_HomeImsiSetMemcQueryTotal:g_OtherImsiSetMemcQueryTotal);
   }

   if(rc == MEMCACHED_SUCCESS)
   {
      LLOG(0,0, "SET_MEMCACHED_DATA: Key[%s] stored successfully", pKey.c_str());
      if('R' == pKey.at(pKey.length() - 1))
      {
       HLRStatisticsInitializer::logStatistics(g_ULRHomeImsiSetMemcQuerySuccess);
      }
      else
      {
       HLRStatisticsInitializer::logStatistics((true == pHomeImsi)?g_HomeImsiSetMemcQuerySuccess:g_OtherImsiSetMemcQuerySuccess);
      }
   }
   else
   {
      ELOG(0,0, "SET_MEMCACHED_DATA: Couldn't store Key[%s]", memcached_strerror(memc, rc));
      pErrDesc.assign(memcached_strerror(memc, rc));
      pErrCode =rc;

      char l_trapDesc[200+1];
      snprintf(l_trapDesc,sizeof(l_trapDesc), "[IP:%s Port:%d]", pMemcIp.c_str(), pMemcPort);
      if((MEMCACHED_SERVER_TEMPORARILY_DISABLED == pErrCode) || (MEMCACHED_CONNECTION_FAILURE == pErrCode)) // errorCode: 47 and 3
      {
         LLOG(0,0,"SET_MEMCACHED_DATA: CONNECTION FAILURE [IP:%s Port:%d], Sending TRAP",pMemcIp.c_str(), pMemcPort);
         g_si.sendSnmpTrap(g_MemcSetConnectionFailTrap, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL, l_trapDesc);
         if('R' == pKey.at(pKey.length() - 1))
         {
          HLRStatisticsInitializer::logStatistics(g_ULRHomeImsiSetMemcQueryMissesCommuniError);
         }
         else
         {
          HLRStatisticsInitializer::logStatistics((true == pHomeImsi)?g_HomeImsiSetMemcQueryMissesCommuniError:g_OtherImsiSetMemcQueryMissesCommuniError);
         }
      }
      return false;
   }

   pErrCode = rc;
   return true;
}

bool SoftDeleteMemCached(void *p, string pKey, string &pValue, int &pErrCode, string &pErrDesc)
{
   memcached_st *memc = (memcached_st*)p;
   memcached_return rc;

   string l_key;
   l_key = pKey;

   if('R' == pKey.at(pKey.length() - 1))
   {
    rc = memcached_set(memc, pKey.c_str(), pKey.length(), pValue.c_str(), pValue.length(), (time_t)0, (uint32_t)0);
   }
   else
   {
   pKey = l_key+"_V";
   rc = memcached_set(memc, pKey.c_str(), pKey.length(), pValue.c_str(), pValue.length(), (time_t)0, (uint32_t)0);

   pKey = l_key+"_S";
   rc = memcached_set(memc, pKey.c_str(), pKey.length(), pValue.c_str(), pValue.length(), (time_t)0, (uint32_t)0);

   pKey = l_key+"_M";
   rc = memcached_set(memc, pKey.c_str(), pKey.length(), pValue.c_str(), pValue.length(), (time_t)0, (uint32_t)0);

   pKey = l_key+"_I";
   rc = memcached_set(memc, pKey.c_str(), pKey.length(), pValue.c_str(), pValue.length(), (time_t)0, (uint32_t)0);
   }

   LLOG(0,0,"SOFT DELETE_MEMCACHED_DATA: for Key[%s]", pKey.c_str());
   if('R' == pKey.at(pKey.length() - 1))
   {
    HLRStatisticsInitializer::logStatistics(g_ULRdeleteMemcQueryTotal); 
   }
   else
   {
    HLRStatisticsInitializer::logStatistics(g_deleteMemcQueryTotal);
   }
   
   if( rc == MEMCACHED_SUCCESS )
   {
      LLOG(0,0, "SOFT DELETE_MEMCACHED_DATA: SET_MEMCACHED_DATA: Key[%s] stored successfully", pKey.c_str());
      if('R' == pKey.at(pKey.length() - 1))
      {
       HLRStatisticsInitializer::logStatistics(g_ULRdeleteMemcQuerySuccess);
      }
      else
      {
       HLRStatisticsInitializer::logStatistics(g_deleteMemcQuerySuccess);
      }
   }
   else
   {
      LLOG(0,0, "SOFT DELETE_MEMCACHED_DATA: SET_MEMCACHED_DATA: Couldn't store Key[%s]", memcached_strerror(memc, rc));
      pErrCode = rc;
      pErrDesc.assign(memcached_strerror(memc, rc));
      if('R' == pKey.at(pKey.length() - 1))
      {
       HLRStatisticsInitializer::logStatistics(g_ULRdeleteMemcQueryFailure);
      }
      else
      {
       HLRStatisticsInitializer::logStatistics(g_deleteMemcQueryFailure);
      }
      return false;
   }
   pErrCode = rc;
   return true;
}

bool DeleteMemCached(void *p, string pKey, int &pErrCode, string &pErrDesc)
{
   memcached_st *memc = (memcached_st*)p;   
   memcached_return rc;
   bool l_retValue = true;
   string l_key;
   l_key = pKey;
   bool l_found = false;

   for(int i=1; i<=4; i++)
   {
      if(1==i)
      {
         pKey = l_key+"_V";
         DLOG(0,0,"Appending Key with _V, Key is %s and i is %d",pKey.c_str(),i);
      }
      else if(2==i)
      {
         pKey = l_key+"_S";
         DLOG(0,0,"Appending Key with _S, Key is %s and i is %d",pKey.c_str(),i);
      }
      else if(3==i) 
      {
         pKey = l_key+"_M";
         DLOG(0,0,"Appending Key with _M, Key is %s and i is %d",pKey.c_str(),i);
      }
      else
      {
         pKey = l_key+"_I";
         DLOG(0,0,"Appending Key with _I, Key is %s and i is %d",pKey.c_str(),i);
      }

      LLOG(0,0,"DELETE_MEMCACHED_DATA: for Key[%s]", pKey.c_str());
      if('R' == pKey.at(pKey.length() - 1))
      {
       HLRStatisticsInitializer::logStatistics(g_ULRdeleteMemcQueryTotal);
      }
      else
      {
       HLRStatisticsInitializer::logStatistics(g_deleteMemcQueryTotal);
      }

      rc = memcached_delete(memc, pKey.c_str(), pKey.length(),(time_t)0);

      if (rc == MEMCACHED_SUCCESS) 
      {
         LLOG(0,0, "DELETE_MEMCACHED_DATA: Key deleted successfully");
         l_found = true;
         if('R' == pKey.at(pKey.length() - 1))
         {
          HLRStatisticsInitializer::logStatistics(g_ULRdeleteMemcQuerySuccess);
         }
         else
         {
          HLRStatisticsInitializer::logStatistics(g_deleteMemcQuerySuccess);
         }
         pErrCode = rc;
      }
      else
      {
         LLOG(0,0, "DELETE_MEMCACHED_DATA: Couldn't delete Key:[%s] Reason: [%s]", pKey.c_str(), memcached_strerror(memc, rc));
         if('R' == pKey.at(pKey.length() - 1))
         {
          HLRStatisticsInitializer::logStatistics(g_ULRdeleteMemcQueryFailure);
         }
         else
         { 
          HLRStatisticsInitializer::logStatistics(g_deleteMemcQueryFailure);
         }
      }
   }
   if(l_found == false)
   {
      pErrDesc.assign(memcached_strerror(memc, rc));
      pErrCode = rc;
      l_retValue = false;
   }

   return l_retValue;
}
