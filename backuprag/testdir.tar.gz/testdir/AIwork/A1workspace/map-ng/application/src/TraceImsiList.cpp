#include <stdio.h>

#include <map>

using namespace std;

map g_TraceList<int, int>

int main()
{
}
