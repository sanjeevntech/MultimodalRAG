#include <MemCachedActiveObject.h>
#include <pthread.h>
#include <stdio.h>
#include <MessageQueue.h>
#include <MemCachedQueryMsg.h>
#include <ConfigReader.h>
#include <SnmpInterface.h>
#include <Logger.h>
#include <Utilities.h>
#include <DataUnion.h>
#include <StatisticsInterface.h>
#include <StatisticsGenerator.h>
#include <map>
#include <typeinfo>
#include <libmemcached/memcached.h>
#include <DbActiveObject.h>
#include <MemCachedUtilities.h>
#include <GUtilThreadHeartBeat.h>

using namespace std;

extern void *getCtx(void *co);
MemCachedActiveObject g_MemcActObj;
MemCachedQueryMsg *g_MemcHeartBeatMsgPtr;

extern char *getHeader(char *p_text, int p_racIndex);

MemCachedActiveObject::MemCachedActiveObject()
{
   m_initializationFlag = false;
   memset(&m_dts,'\0',sizeof(m_dts));
}

MemCachedActiveObject::~MemCachedActiveObject()
{

}

bool pushToMemCached(void *p_memc, char *p_Ip, int p_Port)
{
   memcached_server_st *server = NULL;
   memcached_return rc;    
   server = memcached_server_list_append(server, p_Ip, p_Port, &rc);
   if(server != NULL)
   {
      rc = memcached_server_push((memcached_st*)p_memc, server);
      if(rc == MEMCACHED_SUCCESS)
      {
         LLOG(0,1, "Added server successfully [IP:%s] [Port:%d]",p_Ip,p_Port);
      }
      else
      {
         LLOG(0,1, "Couldn't add the server [IP:%s] [Port:%d] Reason:[%s]",p_Ip,p_Port,memcached_strerror((memcached_st*)p_memc, rc));
         return false;
      }

      LLOG(0,1,"Server list count [%d]",memcached_server_list_count(server));
   }
   else
   {
      LLOG(0,1, "Couldn't append the server list [IP:%s] [Port:%d] Reason:[%s]", p_Ip, p_Port,memcached_strerror((memcached_st*)p_memc, rc));
      return false;
   }
   return true;
}

void *MemCachedActiveThreadFunc(void *p)
{
   if (NULL == p)
   {
      WLOG(0,1,"Memcached: Invalid parameters to the thread");
      return NULL;
   }

   int l_IpIndex = *((int*)p);
   LLOG(0,1,"MemCachedActiveThreadFunc called with connection index:%d", l_IpIndex);

   printSignalSet("db thread signals");

   LLOG(0,0,"Memcached Server IP[%s] and Port[%d]",g_ConfigData->m_MemCacheAddrVector[l_IpIndex].MCServerIp.c_str(), g_ConfigData->m_MemCacheAddrVector[l_IpIndex].MCServerPort);

   void *l_memcPrimary = memcached_create(NULL);
   if(l_memcPrimary == NULL)
   {
      ELOG(0,0,"Memcached Primary initialization failed");
      return false;
   }

   char l_trapDesc[200+1];
   snprintf(l_trapDesc, sizeof(l_trapDesc), "[IP:%s Port:%d]", (char*)g_ConfigData->m_MemCacheAddrVector[l_IpIndex].MCServerIp.c_str(),g_ConfigData->m_MemCacheAddrVector[l_IpIndex].MCServerPort);
   if(false == pushToMemCached(l_memcPrimary, (char*)g_ConfigData->m_MemCacheAddrVector[l_IpIndex].MCServerIp.c_str(), g_ConfigData->m_MemCacheAddrVector[l_IpIndex].MCServerPort))
   {
      CLOG(0,1, "Cannot push the Server[IP:%s Port:%d] into Memcache, Sending TRAP",(char*)g_ConfigData->m_MemCacheAddrVector[l_IpIndex].MCServerIp.c_str(),g_ConfigData->m_MemCacheAddrVector[l_IpIndex].MCServerPort);
      g_si.sendSnmpTrap(g_MemcServerPushFailureTrap, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL, l_trapDesc);
   }

   MessageQueue *l_mq = g_MemcActObj.m_MemcQueues.memc_reqQ[l_IpIndex];
   DLOG(0,0,"Queue Index[%d] to be popped [IP:%s Port:%d]",l_IpIndex,(char*)g_ConfigData->m_MemCacheAddrVector[l_IpIndex].MCServerIp.c_str(),g_ConfigData->m_MemCacheAddrVector[l_IpIndex].MCServerPort);

   while (1)
   {
      void *l_request = NULL;
      DLOG(0,1,"Waiting for Memcached Request");

      bool l_status = l_mq->pop(&l_request,THB_ENABLED,"MemCachedActiveThreadFunc");
      MemCachedQueryMsg *l_mcm = NULL;
      if (true == l_status)
      {
         l_mcm = (MemCachedQueryMsg *)l_request;
      }
      else
      {
            DLOG(0,1,"MEMC:ERROR!! In getting a message from the queue. This is probably due to a signal");
      }

      if(NULL != l_mcm)
      {
         struct timeval l_currTv, l_prevTv;
         getTime(l_currTv, l_prevTv, NULL, NULL);

         DLOG(0,1,"Calling executeMemc query of %s", typeid(*l_mcm).name());

         l_mcm->m_MemcIP = g_ConfigData->m_MemCacheAddrVector[l_IpIndex].MCServerIp;
         l_mcm->m_MemcPort = g_ConfigData->m_MemCacheAddrVector[l_IpIndex].MCServerPort;
         l_mcm->m_memcActivePtr = (memcached_st*)l_memcPrimary;
         l_mcm->executeMemcQuery();  

            if( l_mcm->m_MemcErrorCode != 0) 
            {
               CLOG(0,1,"MemCached ERRROR Execute query of %s code:%d ..[IP:%s Port:%d]", typeid(*l_mcm).name(), l_mcm->m_MemcErrorCode,(char*)l_mcm->m_MemcIP.c_str(),l_mcm->m_MemcPort);
            }

            struct timeval l_diffTv;
            getTime(l_currTv, l_prevTv, "MemcQuery", &l_diffTv);
            TLOG(0,1,"MemCached Time diff: %d %06d  [IP:%s Port:%d]", l_diffTv.tv_sec, l_diffTv.tv_usec, (char*)l_mcm->m_MemcIP.c_str(),l_mcm->m_MemcPort);
            StatisticsInterface::logMemCacheDiffTimeStatistics(&l_diffTv,l_IpIndex);
         
            char l_trapDesc[200+1];
            snprintf(l_trapDesc, sizeof(l_trapDesc), "[IP:%s Port:%d]", (char*)l_mcm->m_MemcIP.c_str(),l_mcm->m_MemcPort);
            if(0 != g_ConfigData->m_MemcDiffTimeTrapInterval)
            {
               if(l_diffTv.tv_sec >= g_ConfigData->m_MemcDiffTimeTrapInterval) 
               {
                  CLOG(0,0,"Sending Trap as Memcached response is taking more than [%d] seconds..[IP:%s Port:%d]",l_diffTv.tv_sec,(char*)l_mcm->m_MemcIP.c_str(),l_mcm->m_MemcPort);
                  g_si.sendSnmpTrap(g_MemcServerDiffTimeTrap, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL, l_trapDesc);
               }
            }
            DLOG(0,1,"Pushing the Response into MemCached response queue ..[IP:%s Port:%d]",(char*)l_mcm->m_MemcIP.c_str(),l_mcm->m_MemcPort);
            g_MemcActObj.m_MemcQueues.memc_resQ->push(l_mcm);
            DLOG(0,1,"Pushed the Response into MemCached response queue..[IP:%s Port:%d]",(char*)l_mcm->m_MemcIP.c_str(),l_mcm->m_MemcPort);
      }
      else
      {
         ELOG(0,1,"l_mcm is NULL");
      }
   }

   ELOG(0,1,"ERROR!!! Thread func exit");
}

bool initializeMemCachedActiveObjectStatistics(StatisticsGenerator *p_sg)
{
   //Initialize Statistics
   for(int l_ind = 0; l_ind < g_ConfigData->m_MemCacheAddrVector.size(); l_ind++)
   {
      char l_MemcIndex[20+1];
      snprintf(l_MemcIndex, sizeof(l_MemcIndex), "MEMC-SERVER-[%02d]", 1+l_ind);
      
      g_MemcActObj.m_dts[l_ind].m_diffTime_gr_or_equal_20s                       = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, getHeader("diffTime >=20s                   ", l_ind), l_MemcIndex, 'Z');
      g_MemcActObj.m_dts[l_ind].m_diffTime_gr_or_equal_10s_and_lt_20s            = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, getHeader("diffTime >=10s     and < 20s     ", l_ind), l_MemcIndex, 'Z');
      g_MemcActObj.m_dts[l_ind].m_diffTime_gr_or_equal_7s_and_lt_10s             = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, getHeader("diffTime >=7s      and < 10s     ", l_ind), l_MemcIndex, 'Z');
      g_MemcActObj.m_dts[l_ind].m_diffTime_gr_or_equal_5s_and_lt_7s              = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, getHeader("diffTime >=5s      and < 7s      ", l_ind), l_MemcIndex, 'Z');
      g_MemcActObj.m_dts[l_ind].m_diffTime_gr_or_equal_2s_and_lt_5s              = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, getHeader("diffTime >=2s      and < 5s      ", l_ind), l_MemcIndex, 'Z');
      g_MemcActObj.m_dts[l_ind].m_diffTime_gr_or_equal_1s_and_lt_2s              = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, getHeader("diffTime >=1s      and < 2s      ", l_ind), l_MemcIndex, 'Z');
      g_MemcActObj.m_dts[l_ind].m_diffTime_gr_or_equal_0d7s_and_lt_1s            = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, getHeader("diffTime >=0.7s    and < 1s      ", l_ind), l_MemcIndex, 'Z');
      g_MemcActObj.m_dts[l_ind].m_diffTime_gr_or_equal_0d5s_and_lt_0d7s          = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, getHeader("diffTime >=0.5s    and < 0.7s    ", l_ind), l_MemcIndex, 'Z');
      g_MemcActObj.m_dts[l_ind].m_diffTime_gr_or_equal_0d2s_and_lt_0d5s          = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, getHeader("diffTime >=0.2s    and < 0.5s    ", l_ind), l_MemcIndex, 'Z');
      g_MemcActObj.m_dts[l_ind].m_diffTime_gr_or_equal_0d1s_and_lt_0d2s          = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, getHeader("diffTime >=0.1s    and < 0.2s    ", l_ind), l_MemcIndex, 'Z');
      g_MemcActObj.m_dts[l_ind].m_diffTime_gr_or_equal_0d07s_and_lt_0d1s         = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, getHeader("diffTime >=0.07s   and < 0.1s    ", l_ind), l_MemcIndex, 'Z');
      g_MemcActObj.m_dts[l_ind].m_diffTime_gr_or_equal_0d05s_and_lt_0d07s        = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, getHeader("diffTime >=0.05s   and < 0.07s   ", l_ind), l_MemcIndex, 'Z');
      g_MemcActObj.m_dts[l_ind].m_diffTime_gr_or_equal_0d02s_and_lt_0d05s        = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, getHeader("diffTime >=0.02s   and < 0.05s   ", l_ind), l_MemcIndex, 'Z');
      g_MemcActObj.m_dts[l_ind].m_diffTime_gr_or_equal_0d01s_and_lt_0d02s        = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, getHeader("diffTime >=0.01s   and < 0.02s   ", l_ind), l_MemcIndex, 'Z');
      g_MemcActObj.m_dts[l_ind].m_diffTime_gr_or_equal_0d007s_and_lt_0d01s       = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, getHeader("diffTime >=0.007s  and < 0.01s   ", l_ind), l_MemcIndex, 'Z');
      g_MemcActObj.m_dts[l_ind].m_diffTime_gr_or_equal_0d005s_and_lt_0d007s      = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, getHeader("diffTime >=0.005s  and < 0.007s  ", l_ind), l_MemcIndex, 'Z');
      g_MemcActObj.m_dts[l_ind].m_diffTime_gr_or_equal_0d002s_and_lt_0d005s      = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, getHeader("diffTime >=0.002s  and < 0.005s  ", l_ind), l_MemcIndex, 'Z');
      g_MemcActObj.m_dts[l_ind].m_diffTime_gr_or_equal_0d001s_and_lt_0d002s      = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, getHeader("diffTime >=0.001s  and < 0.002s  ", l_ind), l_MemcIndex, 'Z');
      g_MemcActObj.m_dts[l_ind].m_diffTime_gr_or_equal_0d0007s_and_lt_0d001s     = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, getHeader("diffTime >=0.0007s  and < 0.001s ", l_ind), l_MemcIndex, 'Z');
      g_MemcActObj.m_dts[l_ind].m_diffTime_gr_or_equal_0d0005s_and_lt_0d0007s    = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, getHeader("diffTime >=0.0005s  and < 0.0007s", l_ind), l_MemcIndex, 'Z');
      g_MemcActObj.m_dts[l_ind].m_diffTime_gr_or_equal_0d0002s_and_lt_0d0005s    = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, getHeader("diffTime >=0.0002s  and < 0.0005s", l_ind), l_MemcIndex, 'Z');
      g_MemcActObj.m_dts[l_ind].m_diffTime_gr_or_equal_0d0001s_and_lt_0d0002s    = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, getHeader("diffTime >=0.0001s  and < 0.0002s", l_ind), l_MemcIndex, 'Z');
      g_MemcActObj.m_dts[l_ind].m_diffTime_lt_0d00001s                           = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, getHeader("diffTime <0.0001s                ", l_ind), l_MemcIndex, 'Z');
   } 
      g_HomeImsiGetMemcQueryTotal   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"AucHomeImsi_GET_Total" , "MEMC", 'Y');
      g_HomeImsiGetMemcQuerySuccess = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"AucHomeImsi_GET_Success" , "MEMC", 'Y');
      g_HomeImsiGetMemcQueryMissesNoData        = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"AucHomeImsi_GET_MissessNOdata" , "MEMC", 'Y');
      g_HomeImsiGetMemcQueryMissesCommuniError  = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"AucHomeImsi_GET_MissessCOMMUNICATIONerror" , "MEMC", 'Y');
      g_HomeImsiSetMemcQueryTotal   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"AucHomeImsi_SET_Total" , "MEMC", 'Y');
      g_HomeImsiSetMemcQuerySuccess = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"AucHomeImsi_SET_Success" , "MEMC", 'Y');
      g_HomeImsiSetMemcQueryMissesCommuniError  = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"AucHomeImsi_SET_MissessCOMMUNICATIONerror" , "MEMC", 'Y');
   
      g_OtherImsiGetMemcQueryTotal  = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"AucOtherImsi_GET_Total" , "MEMC", 'Y');
      g_OtherImsiGetMemcQuerySuccess = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"AucOtherImsi_GET_Success" , "MEMC", 'Y');
      g_OtherImsiGetMemcQueryMissesNoData       = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"AucOtherImsi_GET_MissessNOdata" , "MEMC", 'Y');
      g_OtherImsiGetMemcQueryMissesCommuniError = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"AucOtherImsi_GET_MissessCOMMUNICATIONerror" , "MEMC", 'Y');
      g_OtherImsiSetMemcQueryTotal   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"AucOtherImsi_SET_Total" , "MEMC", 'Y');
      g_OtherImsiSetMemcQuerySuccess = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"AucOtherImsi_SET_Success" , "MEMC", 'Y');
      g_OtherImsiSetMemcQueryMissesCommuniError = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"AucOtherImsi_SET_MissessCOMMUNICATIONerror" , "MEMC", 'Y');

      g_deleteMemcQueryTotal   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"AucPriImsi_DELETE_Total" , "MEMC", 'Y');
      g_deleteMemcQuerySuccess = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"AucPriImsi_DELETE_Success" , "MEMC", 'Y');
      g_deleteMemcQueryFailure = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"AucPriImsi_DELETE_Failure" , "MEMC", 'Y');

      g_ULRHomeImsiGetMemcQueryTotal   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"ULRHomeImsi_GET_Total" , "MEMC", 'U');
      g_ULRHomeImsiGetMemcQuerySuccess = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"ULRHomeImsi_GET_Success" , "MEMC", 'U');
      g_ULRHomeImsiGetMemcQueryMissesNoData        = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"ULRHomeImsi_GET_MissessNOdata" , "MEMC", 'U');
      g_ULRHomeImsiGetMemcQueryMissesCommuniError  = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"ULRHomeImsi_GET_MissessCOMMUNICATIONerror" , "MEMC", 'U');
      g_ULRHomeImsiSetMemcQueryTotal   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"ULRHomeImsi_SET_Total" , "MEMC", 'U');
      g_ULRHomeImsiSetMemcQuerySuccess = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"ULRHomeImsi_SET_Success" , "MEMC", 'U');
      g_ULRHomeImsiSetMemcQueryMissesCommuniError  = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"ULRHomeImsi_SET_MissessCOMMUNICATIONerror" , "MEMC", 'U');
  
      g_ULRdeleteMemcQueryTotal   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"ULRPriImsi_DELETE_Total" , "MEMC", 'U');
      g_ULRdeleteMemcQuerySuccess = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"ULRPriImsi_DELETE_Success" , "MEMC", 'U');
      g_ULRdeleteMemcQueryFailure = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"ULRPriImsi_DELETE_Failure" , "MEMC", 'U');

    return true;
}

bool MemCachedActiveObject::initialize()
{
   bool l_status = false;

   for(int i=0; i<g_ConfigData->m_MemCacheAddrVector.size(); i++)
   {
      m_MemcQueues.memc_reqQ[i] = new MessageQueue(QUEUE_TYPE_BLOCKING, QUEUE_PERSISTENCE_TYPE_NON_PERSISTENT);

      l_status = m_MemcQueues.memc_reqQ[i]->initialize();
      if (!l_status)
      {
         ELOG(0,1,"ERROR!! Unable to initialize the Memcache Request Queue[%d]",i);
         return false;
      }
   }

   m_MemcQueues.memc_resQ = new MessageQueue(QUEUE_TYPE_NON_BLOCKING, QUEUE_PERSISTENCE_TYPE_NON_PERSISTENT);
   l_status = m_MemcQueues.memc_resQ->initialize();
   if (!l_status)
   {
      ELOG(0,1,"ERROR!! Unable to initialize the Memcache Response Queue");
      return false;
   }

   for (int l_i=0; l_i<g_ConfigData->m_MemCacheAddrVector.size(); l_i++)
   {
      pthread_t l_thread;

      int *l_IpIndex = new int;
      *l_IpIndex = l_i;

      if(0!=pthread_create(&l_thread, NULL, MemCachedActiveThreadFunc, l_IpIndex))
      {
         CLOG(0,1,"Unable to create a thread");
         return false;
      }
      LLOG(0,1,"Created Memcached thread [%d] ", l_thread);
   }

   m_initializationFlag=true;
   return true;
}


bool MemCachedActiveObject::execute(void *p_request)
{
   if (m_initializationFlag)
   {
      if(MSG_TYPE_MEMCACHED == ((MemCachedQueryMsg*)p_request)->m_MsgType)
      {
         ((MemCachedQueryMsg*)p_request)->m_Mcb->m_ReferenceCount++;
         DLOG(0,0,"MemCachedQueryMsg reference count incremented: %d",((MemCachedQueryMsg*)p_request)->m_Mcb->m_ReferenceCount);
      }
      ((MemCachedQueryMsg *)p_request)->serializeMemc();

      int l_QIndex = atol(((MemCachedQueryMsg*)p_request)->m_PriImsi4Distribution)%(g_ConfigData->m_MemCacheAddrVector.size());
      DLOG(0,0,"Queue Index[%d] pushed for Imsi[%s]",l_QIndex,((MemCachedQueryMsg*)p_request)->m_PriImsi4Distribution);

      if( (0 != g_ConfigData->m_MemcMaxReqQsize) && (m_MemcQueues.memc_reqQ[l_QIndex]->size() > g_ConfigData->m_MemcMaxReqQsize) )
      {
         CLOG(0,0,"Threshold reached for MemcachedQ[%d] pushing into MemcRespQ with Error which shall push to DBQ",l_QIndex);
         g_si.sendSnmpTrap(g_MemcqueueThresholdTrap, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL);
         ((MemCachedQueryMsg*)p_request)->m_MemcErrorCode = 498;
         m_MemcQueues.memc_resQ->push(p_request);
      } 
      else
      { 
         m_MemcQueues.memc_reqQ[l_QIndex]->push(p_request);
      }
      return true;
   }
   else
   {
      ELOG(0,1,"MemCachedActiveObject not initialized");
      return false;
   }
   ELOG(0,1,"MemCachedActiveObject::execute failed\n");
   return false;
}

void MemCachedActiveObject::getMemcQueueStats(char *p_output)
{
   if (true == m_initializationFlag)
   {
      int l_req = 0;
      char l_reqBuff[200];
      memset(l_reqBuff,'\0',sizeof(l_reqBuff));
      char l_temp[20];
      for (int l_i=0; l_i<g_ConfigData->m_MemCacheAddrVector.size(); l_i++)
      {
         l_req = l_req + m_MemcQueues.memc_reqQ[l_i]->size();
         snprintf(l_temp,sizeof(l_temp),"Q(%d):%d ",l_i,m_MemcQueues.memc_reqQ[l_i]->size());
         strlcat(l_reqBuff,l_temp,200);
      }
      int l_res = m_MemcQueues.memc_resQ->size();

      sprintf(p_output, " MEMCACHED Request Queue Size\t\t\t: Total:%d [ %s] \n MEMCACHED Response Queue Size\t\t\t: %d\n", l_req, l_reqBuff, l_res);
   }
   else
   {
      sprintf(p_output, " MEMCACHED Interface\t\t\t\t: %s", "NOT ENABLED");
   }
}

