#include <TimerManager.h>
#include <Logger.h>
#include <ServiceCoordinator.h>
#include <SnmpInterface.h>

#define TIMER_MANAGER_WAKEUP_INTERVAL    5
#define MAX_TIMER_ID                     10000000


TimerManager g_tm;
int g_lastTimerExecutedDate;

TimerManager::TimerManager()
{
   m_currentTimerId=0;
   m_initializedFlag=false;
}

TimerManager::~TimerManager()
{
}


unsigned int TimerManager::startTimer(ContextBase *p_cb, int p_interval)
{
   if ( (p_interval < 1) || (p_interval > 86400) )
   {
      ELOG(0,1,"Invalid Timer %d. Not setting ...", p_interval);
      return 0;
   }

   if (NULL == p_cb)
   {
      ELOG(0,1,"Context Base is NULL");
      return 0;
   }

   int l_currentTimerId = 0;
   if (m_currentTimerId < MAX_TIMER_ID)
   {
      l_currentTimerId = ++m_currentTimerId;
   }
   else
   {
      m_currentTimerId = l_currentTimerId = 1;
   }

   TimeoutMsg *l_td = new TimeoutMsg;
   l_td->m_dialogId  = l_currentTimerId;
   l_td->m_epoch     = time(NULL);
   l_td->m_cb        = p_cb;
   l_td->m_interval  = p_interval;

   p_cb->m_ReferenceCount++;
   if (p_cb->m_ReferenceCount < 0)
   {
      ELOG(0,1,"startTimer m_ReferenceCount is going negative");
   }

   LLOG(0,1,"Setting timeout with id %d with interval %d", l_currentTimerId, p_interval);
   //m_setTimerQueue->push( (void*)l_td );

   //g_tm.m_data[l_td->m_dialogId] = l_td;
   g_tm.m_data->insert(pair<unsigned int, TimeoutMsg*>(l_td->m_dialogId,l_td));

   return l_currentTimerId;
}


bool TimerManager::initialize()
{
   g_lastTimerExecutedDate=0;
   m_initializedFlag=true;
   m_data = new map<unsigned int, TimeoutMsg*>;
   return true;
}

MessageQueue *TimerManager::getTimerQueue()
{
   return m_setTimerQueue;
}

MessageQueue *TimerManager::getResetQueue()
{
   return m_resetQueue;
}

MessageQueue *TimerManager::getTimeoutQueue()
{
   return m_timeoutQueue;
}

void TimerManager::getStats(char *p_output)
{
   if (true == m_initializedFlag)
   {
      sprintf(p_output, " Active Timers Map Size\t\t\t\t: %ld", m_data->size());
   }
}


void performTimerActions()
{
   int l_currentTime = time(NULL);

   if (l_currentTime < g_lastTimerExecutedDate+TIMER_MANAGER_WAKEUP_INTERVAL)
   {
      if(1 == g_OtherConfigData->m_PrintTimerInLog)
      {
         DLOG(0,1,"skipping timer actions");
      }
      return;
   }
   g_lastTimerExecutedDate=l_currentTime;
   // Check for Timeouts in the map
   if(1 == g_OtherConfigData->m_PrintTimerInLog)
   {
      TLOG(0,1,"before Timer size: %d", g_tm.m_data->size());
   }
   map<unsigned int, TimeoutMsg*>::iterator l_timeout_it;
   for (l_timeout_it = g_tm.m_data->begin(); l_timeout_it != g_tm.m_data->end(); )
   {
      TimeoutMsg *l_td = l_timeout_it->second;
      if(1 == g_OtherConfigData->m_PrintTimerInLog)
      {
         DLOG(0,1,"Timeout case for id [%d]", l_td->m_dialogId);
      }
      if (l_currentTime > l_td->m_epoch+l_td->m_interval)
      {
         LLOG(0,1,"Timeout expired for id [%d]", l_td->m_dialogId);
         //l_tm->m_timeoutQueue->push(l_td);

         map<unsigned int, TimeoutMsg*>::iterator temp=l_timeout_it;
         ++l_timeout_it;
         g_tm.m_data->erase(temp);

         g_sc.recvMsg(l_td);  //Processing immediately
      }
      else
      {
         ++l_timeout_it;
      }
   }
   if(1 == g_OtherConfigData->m_PrintTimerInLog)
   {
      TLOG(0,1,"after Timer size: %d", g_tm.m_data->size());
   }
}


bool TimerManager::resetTimer(ContextBase *p_cb, unsigned int p_uniqueReferenceId)
{
   if (p_uniqueReferenceId < 1)
   {
      ELOG(0,1,"Invalid reference id %d", p_uniqueReferenceId);
      return false;
   }
   else
   {
      map<unsigned int, TimeoutMsg*>::iterator l_it;
      l_it = g_tm.m_data->find(p_uniqueReferenceId);
      if (l_it != g_tm.m_data->end())// matches the list of Timeouts
      {
         p_cb->m_ReferenceCount--;
         if (p_cb->m_ReferenceCount < 0)
         {
            ELOG(0,1,"resetTimer m_ReferenceCount is going negative");
         }

         LLOG(0,1,"Removing the id [%d] from the map", p_uniqueReferenceId);

         //Added for 1.0.5.2
         if (NULL != l_it->second)
         {
            delete((TimeoutMsg*)(l_it->second));
         }

         g_tm.m_data->erase(l_it);
      }
      else
      {
         CLOG(0,1,"id [%d] not found in the map", p_uniqueReferenceId);
      }
   }
   return false;
}
