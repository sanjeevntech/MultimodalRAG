#include <TdrData.h>
#include <TdrFillerBase.h>
#include <Logger.h>
#include <ConfigReader.h>

TdrFillerBase *g_tfb=new TdrFillerBase;

TdrFillerBase::TdrFillerBase()
{
   memset(m_LastDateString, '\0', sizeof(m_LastDateString));
   m_LastSeqNo=1;
}

TdrFillerBase::~TdrFillerBase()
{
}

bool TdrFillerBase::prepareTitle(char *a_tdrBuff)
{
   ELOG(0,1,"TdrFillerBase::prepareTitle This should never be called");
   return NULL;
}


bool TdrFillerBase::prepareTDR(TdrData *p_scd, char *a_tdrBuff, int p_currentTdr)
{
   ELOG(0,1,"TdrFillerBase::prepareTDR This should never be called");
   return true;
}

char *TdrFillerBase::getHeaderString() 
{ 
   return "TdrId,OpCode,ContextId,RcvdTime,MapVersion,CallingParty,CallingPartySsn,OriginatingModule,"; 
}
int TdrFillerBase::getHeaderCount()  
{ 
   return 8; 
}

int TdrFillerBase::getTdrIndex(EOtherTdrParams p_data)
{
   ELOG(0,1,"getTdrIndex base is called");
   return -1;
}



