#include <SelfSimulator.h>
#include <Logger.h>

SelfSimulator *g_selfSimObj = NULL;

SelfSimulator::SelfSimulator()
{
}

SelfSimulator::~SelfSimulator()
{
}

bool SelfSimulator::getMessage(int p_opCode, Msg **p_msgPtr, Msg *p_ReqMsgPtr)
{
   WLOG(0,1,"SelfSimulator::getMessage called");
   return false;
}


