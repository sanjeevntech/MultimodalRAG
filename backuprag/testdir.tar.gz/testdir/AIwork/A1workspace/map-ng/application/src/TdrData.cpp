#include <TdrData.h>
#include <Logger.h>
#include <ConfigReader.h>

TdrData::TdrData()
{
}

TdrData::~TdrData()
{
}

void TdrData::setChar(int a_index, s8 a_char)
{
   if ( (a_index < 0) || (a_index >TDR_APPLICATION_MAX_PARAMS-1) )
   {
      return;
   }
   s8 l_temp[5];
   memset(l_temp,'\0',sizeof(l_temp));
   sprintf(l_temp,"%c",a_char);
   m_CDR[a_index] = l_temp;
}

void TdrData::setInteger(int a_index, s32 a_Int)
{
   if ( (a_index < 0) || (a_index >TDR_APPLICATION_MAX_PARAMS-1) )
   {
      return;
   }
   s8 l_temp[5];
   memset(l_temp,'\0',sizeof(l_temp));
   sprintf(l_temp,"%d",a_Int);
   m_CDR[a_index] = l_temp;
}

void TdrData::setUnsignedInteger(int a_index, u32 a_Int)
{
   if ( (a_index < 0) || (a_index >TDR_APPLICATION_MAX_PARAMS-1) )
   {
      return;
   }
   s8 l_temp[5];
   memset(l_temp,'\0',sizeof(l_temp));
   sprintf(l_temp,"%u",a_Int);
   m_CDR[a_index] = l_temp;
}

void TdrData::setString(int a_index, s8* a_string)
{
   if ( (a_index < 0) || (a_index >TDR_APPLICATION_MAX_PARAMS-1) )
   {
      return;
   }

   char l_string[500];
   memset(l_string, '\0', 500);

   int l_len=strlen(a_string);
   if(0 == l_len)
   {
      m_CDR[a_index]="";
   }
   for (int l_i=0; (l_i<l_len) && (l_i<500); l_i++)
   {
      //TDR attributes should not contain "\n" , "," etc
      if ( (',' == a_string[l_i]) ||
            ('\n' == a_string[l_i])
         )
      {
         l_string[l_i] = ' ';
      }
      else
      {
         l_string[l_i] = a_string[l_i];
      }
      m_CDR[a_index] = l_string;
   }
}

void TdrData::setHex(int a_index, s8* a_string, u16 a_Len)
{
   if ( (a_index < 0) || (a_index >TDR_APPLICATION_MAX_PARAMS-1) )
   {
      return;
   }
   s8 l_hexBuff[200+1];
   s8 l_temp[3];
   memset(l_temp, '\0', sizeof(l_temp));
   memset(l_hexBuff,'\0',sizeof(l_hexBuff));
   if(a_Len > 100)
   {
      strcpy(l_hexBuff, "DUMMY");
   }
   else
   {
      for(u16 i=0; i < a_Len; i++)
      {
         snprintf(l_temp,3,"%02x",a_string[i]&0x00ff);
         strncat(l_hexBuff,l_temp,2);
      }
      m_CDR[a_index] = l_hexBuff;
   }
}


//The functions below shall set the Header Data

void TdrData::setOpCode(u16 a_opCode)
{ 
   char l_tempBuff[10+1];
   memset(l_tempBuff, '\0', sizeof(l_tempBuff));
   sprintf(l_tempBuff,"%d",a_opCode); 
   m_HDR[TDR_HDR_OP_CODE_INDEX] = l_tempBuff;
}

void TdrData::setMapVersion(u16 a_mapVer)
{ 
   char l_tempBuff[10+1];
   memset(l_tempBuff, '\0', sizeof(l_tempBuff));
   sprintf(l_tempBuff,"v%d",a_mapVer);
   m_HDR[TDR_HDR_MAP_VERSION_INDEX] = l_tempBuff;
}

void TdrData::setRemoteAddr(s8* a_callingAddr)
{ 
   m_HDR[TDR_HDR_REMOTE_PARTY_ADDR_INDEX] = a_callingAddr;
}

void TdrData::setTdrId()
{ 
   char l_timeStamp[20+1];
   memset(l_timeStamp, '\0', sizeof(l_timeStamp));

   char l_dateString[20+1];
   memset(l_dateString, '\0', sizeof(l_dateString));
   struct tm *l_tm_ptr=NULL;
   time_t l_tim =time(NULL);
   l_tm_ptr = localtime(&l_tim);
   sprintf(l_dateString, "%04d%02d%02d%02d%02d%02d",
         l_tm_ptr->tm_year+1900, l_tm_ptr->tm_mon+1, l_tm_ptr->tm_mday,
         l_tm_ptr->tm_hour, l_tm_ptr->tm_min, l_tm_ptr->tm_sec);

   if(0 == strcmp(l_dateString, g_tfb->m_LastDateString))
   {
      ++(g_tfb->m_LastSeqNo);
   }
   else
   {
      strcpy(g_tfb->m_LastDateString, l_dateString);
      g_tfb->m_LastSeqNo=1;
   }
   sprintf(l_timeStamp, "%s%03d%03d", l_dateString, g_ConfigData->m_InstanceId, g_tfb->m_LastSeqNo);


   m_HDR[TDR_HDR_TDR_ID_INDEX] = l_timeStamp;
}

void TdrData::setRemoteAddrSsn(int p_ssn)
{
   char l_tempBuff[10+1];
   memset(l_tempBuff, '\0', sizeof(l_tempBuff));
   sprintf(l_tempBuff,"%d",p_ssn); 
   m_HDR[TDR_HDR_REMOTE_PARTY_SSN_INDEX] = l_tempBuff;
}

void TdrData::setOriginatingModule(char *p_mod)
{
   m_HDR[TDR_HDR_ORIGINATING_MODULE] = p_mod;
}

void TdrData::setContextId(char *p_ctxt)
{
   m_HDR[TDR_HDR_CONTEXT_ID_INDEX] = p_ctxt;
}
