#include <stdio.h>
#include <dlfcn.h>
#include <ModuleManager.h>
#include <strings.h>
#include <Logger.h>
#include <ConfigReader.h>

ModuleManager g_mm;



ContextBase *ModuleManager::getRespectiveContext2(int p_OpCode, Msg* p_msg)
{
   DLOG(0,0,"Locating opcode:%d", p_OpCode);
   if(p_OpCode < 300) //TODO: This is very dirty. It should be cleaned before release
   {
      DLOG(0,0,"Locating MAP:%d opcode:%d", MSG_TYPE_MAP, p_OpCode);
      if( (45 == p_OpCode) && (MSG_TYPE_SCCP == p_msg->m_MsgType) )
      {
       if (m_mapping[MSG_TYPE_SCCP][p_OpCode].m_func != NULL)
         {
          return m_mapping[MSG_TYPE_SCCP][p_OpCode].m_func()->getCtxtObj((EMapOpCode)p_OpCode, (SccpMsg*)p_msg);
         }
      }
      else if (m_mapping[MSG_TYPE_MAP][p_OpCode].m_func != NULL)
      {
         return m_mapping[MSG_TYPE_MAP][p_OpCode].m_func()->getCtxtObj((EMapOpCode)p_OpCode, (MapSpecificMsg*)p_msg);
      }
      else
      {
         return NULL;
      }
   }
   else
   {
      DLOG(0,0,"Locating DIAMETER:%d opcode:%d", MSG_TYPE_DIAMETER, p_OpCode);
      int l_opCode=p_OpCode;
      if(8388622 == l_opCode)
      {
         l_opCode=350;
      }
      /*if(303 == l_opCode)
      {
         l_opCode=393;
         p_OpCode=393;
      }*/
      if((304 == p_OpCode) || (305 == p_OpCode))
      {
         return m_mapping[MSG_TYPE_DIAMETER][l_opCode].m_func()->getCtxtObj((EDiameterCommandCode)p_OpCode, (InterModuleData*)p_msg);
      }
      else if (m_mapping[MSG_TYPE_DIAMETER][l_opCode].m_func != NULL)
      {
         return m_mapping[MSG_TYPE_DIAMETER][l_opCode].m_func()->getCtxtObj((EDiameterCommandCode)p_OpCode, (DiameterMsg*)p_msg);
      }
      else
      {
         return NULL;
      }
   }
   return NULL;
}

bool ModuleManager::isPresent(EMsgType p_mt, int p_OpCode)
{
   int l_opCode=p_OpCode;
   if(MSG_TYPE_DIAMETER == p_mt)
   {
      if(8388622 == l_opCode)
      {
            l_opCode=350;
      }
   }

   if (m_mapping[p_mt][l_opCode].m_func != NULL)
   {
      return true;
   }
   else
   {
      return false;
   }
}

static char m_libName[30+1];
static void *l_libHandle;


fptr_mod ModuleManager::getContextFptr_mod(const char* p_libName, const char* p_funcName, EDllResult *p_result, char *p_error)
{
   LLOG(0,1,"calling dlopen");
   l_libHandle=NULL;
   l_libHandle = dlopen(p_libName, RTLD_NOW);
   if(l_libHandle == NULL)
   {
      strcpy(p_error, dlerror());
      CLOG(0,0,"Failed to dlopen the [%s] [%s]",  p_libName, p_error);
      *p_result = DLL_RESULT_DLL_NOT_FOUND;
      return NULL;
   }
   else
   {
      LLOG(0,0,"dlopen success for [%s]", p_libName);
      strcpy(m_libName, p_libName);
   }

   dlerror();// This just flushes the error variable

   LLOG(0,0,"calling dlsym for resolving [%s]", p_funcName);

   ModuleBase * (*fptr1)() = NULL;
   fptr1 = (ModuleBase* (*)())dlsym(l_libHandle, p_funcName);

   if (fptr1 != NULL)
   {
      LLOG(0,0,"success");
      *p_result = DLL_RESULT_SUCCESS;
   }
   else
   {
      LLOG(0,0,"failure");
      strcpy(p_error, dlerror());
      dlerror(); //flush
      *p_result = DLL_RESULT_FUNC_NOT_FOUND;
   }



   return fptr1;
}

bool ModuleManager::readModulesConfig()
{
   // This is a dummy filling of OpCode mapping. Load from Configuration files in sorting order of library names
   m_mappingCount = 200;
   //OpCodeMapping *l_mapping = &m_mapping[0];
   return true;
}

OpCodeMapping::OpCodeMapping()
{
   m_OpCode=0;
   memset(m_LibName, '\0', 30+1);
   memset(m_FuncName, '\0', 30+1);
   m_ContextPtr= NULL;
   m_func=NULL;
   m_Map1Flag=false;
   m_Map2Flag=false;
   m_Map3Flag=false;

   memset(m_ModName, '\0', 3+1);
   memset(m_MessageName, '\0', 3+1);
   m_loadedTime=0;
}

OpCodeMapping::~OpCodeMapping()
{
}




ModuleMapping::ModuleMapping()
{
   memset(m_LibName, '\0', 30+1);
   m_func=NULL;
   memset(m_ModName, '\0', 3+1);
   m_loadedTime=0;
   m_configPresent=false;
   m_cr=NULL;
   memset(m_file, '\0', sizeof(m_file));
}

ModuleMapping::~ModuleMapping()
{
}
