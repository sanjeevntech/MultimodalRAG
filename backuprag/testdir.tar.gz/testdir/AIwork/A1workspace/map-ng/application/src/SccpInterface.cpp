
/*
#include <iostream>
#include <fstream>
#include <list>
#include <stdlib.h>
#include <string>
#include <time.h>
*/

#include <apiinc.h>
#include <tcap.h>
#include <tcerror.h>
#include <ObjectServer.h>
#include <ccapiproto.h>

/*
#include <NetworkInterface.h>
#include <MplManager.h>
#include <ServiceCoordinator.h>
#include <ContextBase.h>
#include <ModuleManager.h>
#include <DbActiveObject.h>
#include <TimerManager.h>
#include <ToolInterface.h>
#include <ConfigReader.h>
#include <Logger.h>
#include <MplManager.h>
#include <SmppInterface.h>
#include <CurrentTime.h>
*/



int AFormatSCCPcblock (sblock_t* psb         /* sblock from TCAP */
      ,cblock_t *cb     /* cblocks to be filled in */
      ,int size         /* max cblocks to fill */
      ,int *CblkRet) /* total number cblks filled*/
{
   return aFormatSCCPcblock(psb, cb, size, CblkRet);
}


int AFormatSCCPsblock (sblock_t* psb         /* sblock from TCAP */
      ,cblock_t *cb     /* cblocks to be filled in */
      ,int size         /* max cblocks to fill */
      ,int *CblkRet) /* total number cblks filled*/
{
   return aFormatSCCPsblock(psb, cb, size, CblkRet);
}


int AsccpEncodeAddress (U8 *pData,
      const SccpAddress *pAddress,
      U8                *pDataSize,
      SccpErrorReport   *pErrorReport)
{
   return  sccpEncodeAddress (pData, pAddress, pDataSize, pErrorReport);
}


int AsccpDecodeAddress(const U8 *pData,
      SccpAddress       *pAddress,
      U8                *pDataSize,
      SccpErrorReport   *pErrorReport)
{
   return sccpDecodeAddress(pData, pAddress, pDataSize, pErrorReport);
}

