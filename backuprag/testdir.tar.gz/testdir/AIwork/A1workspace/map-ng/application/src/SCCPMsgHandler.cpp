#include "SCCPMsgHandler.h"
#include "ConfigReader.h"
#include "Logger.h"
#include "ASNTags.h"
#include "Utilities.h"
#include <StatisticsInterface.h>
#include <ctcapdp.h>
#include <SccpMsg.h>
#include <ModuleManager.h>
#include <MplManager.h>
#include <typeinfo>
#include <HlrTdrFiller.h>

bool g_Reject=false;
extern unsigned char g_protocol;
extern int g_RejectLoopTransactionIndex;
extern int g_maxTpsDataIndex;
extern int g_CurrentActiveTransactions;

bool g_currentMultiImsiFlag=false;
bool g_currentImsiRangeFlag=false;
bool g_loopMsgIgnoredFlag=false;
bool g_currentPortedFlag=false;
extern map<int, mymap> g_CCMap;
extern  map<int,string> g_OpCodeGT;
extern char tdrNgErrorsArr[][100];

extern int g_incomingSccpReqIndex; //6471

map<string,HeavyTransaction> g_HeavyTransactionMap;

char *atohx2(char *p_dst, const char *p_src)
{
   char *l_ret = p_dst;
   for(int lsb, msb; *p_src; p_src += 2)
   {
      msb = tolower(*p_src);
      lsb = tolower(*(p_src + 1));
      msb -= isdigit(msb) ? 0x30 : 0x57;
      lsb -= isdigit(lsb) ? 0x30 : 0x57;
      if((msb < 0x0 || msb > 0xf) || (lsb < 0x0 || lsb > 0xf))
      {
         *l_ret = 0;
         return NULL;
      }
      //*p_dst++ = (char)(lsb | (msb << 4));
      *p_dst++ = (char)(msb | (lsb << 4));
   }
   *p_dst = 0;
   return l_ret;
}


void SCCPMsgHandler::processMAPMsg(sblock_t *sblockIn, int opCode, SccpAddress *calledParty, u8 *tc_msg, u8 *pTcLen, u8 *pCompLen, u8 *pMsgLen, int &paddedBytes, u8 *oTxId,char  *callingParty, char* pMSISDN)
{
g_OtherConfigData->m_ccmsisdnlen = 12; //TODO REMOVE REMOVE
g_OtherConfigData->m_LoopCounterFlag = 0;

   unsigned char *pInvokeLen = NULL;
   unsigned char *pMsidnLen = NULL;
   char msisdn[64];
   char country_code[4];
   memset(country_code,'\0',sizeof(country_code));
   char prefix[30];

   bool l_outof_msisdn_range = false;

   memset(msisdn,'\0',sizeof(msisdn));
   memset(prefix,'\0',sizeof(prefix));
   int cc=0;
   bool portedOut = false;

   paddedBytes = sblockIn->prim.nunitd.data_size;
   if(*tc_msg == 0x30)
   {
      int l_to_skip_bytes = 1;
      pInvokeLen = (++tc_msg); //Skip Parameter Sequence
      if((*tc_msg == 0x80))
      {
         //g_LoggerObj.log(LOG_LEVEL_CRITICAL, "%s<Ln: %d> Long definite legth ignoring", __FUNCTION__, __LINE__);
      }
      else if((*tc_msg & 0x80) == 0x80)
      {
         l_to_skip_bytes += (*tc_msg - 0x80) ;
      }

      tc_msg += l_to_skip_bytes; // Skip Parameter Sequence Len
   }

   if((MSISDN_TAG != *tc_msg) && (MSISDN_TAG1 != *tc_msg))
   {
      CLOG(0,0,"### MSISDN TAG not present");
      //g_LoggerObj.log(LOG_LEVEL_CRITICAL, "%s<Ln: %d> MSISDN Tag not present", __FUNCTION__, __LINE__);
      return;
   }
   else
   {
      tc_msg++;
      char buff[1024];
      if ((*tc_msg & 0x80) == 0x80)   // Long definite length or indefinite length
      {
         LLOG(0,0,"### Msisdn Received EOC encoded length ###");
         tc_msg++;
      }
      pMsidnLen = tc_msg; // Skip MSISDN Tag
      LLOG(0,0,"### Configured g_OtherConfigData->m_ccmsisdnlen %d pMsidnLen %d (g_OtherConfigData->m_ccmsisdnlen+1)/2 %d ###",g_OtherConfigData->m_ccmsisdnlen,*pMsidnLen,(g_OtherConfigData->m_ccmsisdnlen+1)/2);
      if((*pMsidnLen - 1) > (g_OtherConfigData->m_ccmsisdnlen+1)/2)
      {
         //g_LoggerObj.log(LOG_LEVEL_CRITICAL, "%s<Ln: %d> msisdnlen %d", __FUNCTION__, __LINE__,*pMsidnLen);
         LLOG(0,0,"###  msisdnlen %d ###",*pMsidnLen);
         char l_output[5000];
         memset(l_output, '\0', sizeof(l_output));
         for(int i = 0; i < sblockIn->prim.nunitd.data_size && i < 1024; i++)
         { 
            sprintf(&l_output[i*3], "%02x ", sblockIn->prim.nunitd.pdata[i]&0x00ff);
         }
         CLOG(0,0,"### Received MSISDN is more than specified printing Hex Dump[%s] ###",l_output);
         l_outof_msisdn_range = true;
      }
      tc_msg++; // Skip MSISDN Len
      if(!l_outof_msisdn_range)
      {
         LLOG(0,0,"### MSISDN NAI/NPI %02x data_size: %d ###",tc_msg[0],sblockIn->prim.nunitd.data_size);
         if((tc_msg[0]&0xf0) != 0x90) // Not In International format
         {
            CLOG(0,0,"### MSISDN Not International Format ###");
            u8 *pStart = sblockIn->prim.nunitd.pdata;
            int locallen = (tc_msg - pStart);
            locallen--; //Skip NAI, NPI

            if(locallen > sblockIn->prim.nunitd.data_size)
            {
               CLOG(0,0,"### Invalid data_size: %d .. returning###",sblockIn->prim.nunitd.data_size);
               return;
            }

            memcpy(buff, (char *)tc_msg+1, sblockIn->prim.nunitd.data_size-locallen);
            tc_msg[0] = 0x91;

            char l_temp_msisdn[30];
            BCDToString((u8*)l_temp_msisdn, tc_msg+1, *pMsidnLen-1);

            snprintf(msisdn, sizeof(l_temp_msisdn), "%s%s", g_OtherConfigData->m_CountryCode, l_temp_msisdn);
            unsigned char l_msisdn_bcd[15];
            StringToBCD(l_msisdn_bcd, (u8*)msisdn, strlen(msisdn));
            LLOG(0,0,"### OldMSISDN[%s] NewMSISDN[%s]",l_temp_msisdn,msisdn);

            int l_oldBcdLength = (1+strlen(l_temp_msisdn))/2;
            int l_newBcdLength = (1+(strlen(l_temp_msisdn) + strlen(g_OtherConfigData->m_CountryCode)))/2;
            int l_addedLength=l_newBcdLength-l_oldBcdLength;

            LLOG(0,0,"### OldBCDLen[%d], NewBCDLen[%d], AddedLen[%d]",l_oldBcdLength,l_newBcdLength);

            if((locallen+l_oldBcdLength) > sblockIn->prim.nunitd.data_size)
            {
               CLOG(0,0,"### Invalid data_size: %d .. returning",sblockIn->prim.nunitd.data_size);
               return;
            }
            memcpy(&tc_msg[1], l_msisdn_bcd, l_newBcdLength);
            memcpy(&tc_msg[1+l_newBcdLength], buff+l_oldBcdLength, sblockIn->prim.nunitd.data_size-locallen-l_oldBcdLength);

            if(NULL != pTcLen)
               (*pTcLen)+=l_addedLength;
            if(NULL != pMsidnLen)
               (*pMsidnLen)+=l_addedLength;
            if(NULL != pInvokeLen)
               (*pInvokeLen)+=l_addedLength;
            if(NULL != pCompLen)
               (*pCompLen)+=l_addedLength;
            if(NULL != pMsgLen)
               (*pMsgLen)+=l_addedLength;

            paddedBytes = sblockIn->prim.nunitd.data_size - paddedBytes;
            sblockIn->prim.nunitd.data_size += l_addedLength;
         }
         else
         {
            LLOG(0,0,"### Received MSISDN International Format");
            BCDToString((u8*)msisdn, tc_msg+1, *pMsidnLen-1);
         }
         //Check in Multi IMSI MAP and modify the called party GT
         if(NULL != pMsidnLen )
         {
            LLOG(0,0,"### MSISDN: %s",msisdn);


            /*if(g_OtherConfigData->m_NumberPlan != 0x00)
               calledParty->globalTitle.numberingPlan =(SccpNumberingPlan)g_OtherConfigData->m_NumberPlan;
            if(g_OtherConfigData->m_NatureADDInd != 0x00)
               calledParty->globalTitle.natureOfAddressIndicator = g_OtherConfigData->m_NatureADDInd;*/

            if(0 == (calledParty->globalTitle.addressInformationLength%2))
            {
               LLOG(0,0,"### Encoding Scheme set to EVEN");
               calledParty->globalTitle.encodingScheme = ES_BCD_EVEN;
            }
            else
            {
               LLOG(0,0,"###  Encoding Scheme set to ODD");
               calledParty->globalTitle.encodingScheme = ES_BCD_ODD;
            }
         }
      }
   }
   LLOG(0,0,"#### MSISDN VALUE [%s]######",msisdn);
   LLOG(0,0,"#### CALLED PARTY VALUE [%s]######",calledParty->globalTitle.addressInformation);
   LLOG(0,0,"#### CALLING PARTY VALUE [%s]######",callingParty);
   snprintf(pMSISDN,21,"%s",msisdn);
}


bool SCCPMsgHandler::processSCCPMsg(sblock_t *sblockIn, int& paddedBytes, char *pSriMSISDN)
{
   DLOG(0,0,"In processSCCPMSG");
   g_Reject=false;
   u8 *tc_msg = sblockIn->prim.nunitd.pdata;

   if (!tc_msg)
   {
      CLOG(0,0,"TC Message NULL while decoding");
      return false;
   }

   SccpAddress callingParty, calledParty;
   SccpErrorReport sccpError;
   U8 dataSize=0;

   memset(&callingParty, '\0', sizeof(callingParty));
   callingParty.protocol = C7_PROTOCOL;
   sccpDecodeAddress(sblockIn->prim.nunitd.calling, &callingParty, &dataSize, &sccpError);

   memset(&calledParty, '\0', sizeof(calledParty));
   calledParty.protocol = C7_PROTOCOL;
   sccpDecodeAddress(sblockIn->prim.nunitd.called, &calledParty, &dataSize, &sccpError);
   //calledParty.globalTitle.translationType = g_OtherConfigData->m_TT; //changing TT here
   calledParty.addressIndicator.pointCodeIndicator = false;
   LLOG(0,0,"#### callingParty: %s Calling Party SSN: %d,calledParty: %s Called Party SSN: %d pointcode Present %d",callingParty.globalTitle.addressInformation, callingParty.ssn, calledParty.globalTitle.addressInformation, calledParty.ssn,calledParty.addressIndicator.pointCodeIndicator);


   if(('F' == calledParty.globalTitle.addressInformation[calledParty.globalTitle.addressInformationLength - 1])
         ||('f' == calledParty.globalTitle.addressInformation[calledParty.globalTitle.addressInformationLength - 1]))
   {
      calledParty.globalTitle.addressInformation[calledParty.globalTitle.addressInformationLength - 1] = '\0';
      calledParty.globalTitle.addressInformationLength--;
   }

   switch(*tc_msg)
   {
      case TC_BEGIN_TAG:
         {
            DLOG(0,0,"Received TC_BEGIN_TAG");
            int length;
            u8 *pTcLen = NULL;
            u8 oTxId[5];
            u8 *pCompLen = NULL;
            u8 *pMsgLen = NULL;
            int mapVer = 1;
            u8* pDlgportion=NULL;
            int invokeId;

            tc_msg++;   // Skip BEGIN Tag
            if ((*tc_msg & 0x80) == 0x80) // long definite length or indefinite length
            {
               tc_msg += (decodeLongDefLen(tc_msg));
            }
            pTcLen = tc_msg;
            tc_msg++;   // Skip Transaction Len

            if (OTID_TAG != *tc_msg)
            {
               CLOG(0,0,"OTID Tag not found while decoding");
               break;
            }
            //pOTID = tc_msg;
            length = *(++tc_msg);
            memcpy(oTxId, tc_msg, 5);
            tc_msg++; // Skip OTID Length
            tc_msg += length; // Skip OTID

            if (DLG_PRTN_TAG == *tc_msg)
            {
#if 0
               printf("\n   Hex data start ");
               for(int l_i=0; l_i<100; l_i++)
               {
                  printf(" %02x", tc_msg[l_i]);
               }
               printf("\n   Hex data end ");
#endif

               pDlgportion = tc_msg;
               tc_msg++;
               if ((*tc_msg & 0x80) == 0x80)   // Long definite length or indefinite length
               {
                  CLOG(0,0,"Unable to decode EOC encoded Dialog Portion");
                  break;
               }
               ctcap_dialogue_portion_t l_cdpt;
               memset(&l_cdpt, '\0', sizeof(l_cdpt));
               ctcap_error_report_t l_cert;
               memset(&l_cert, '\0', sizeof(l_cert));
               U32 l_length_of_data = *tc_msg;
               int l_ret_code = cTCAPDecodeDialoguePortion(
                     &l_cdpt, 
                     tc_msg+1,
                     &l_length_of_data,
                     &l_cert);
               if(l_ret_code != RETURNok)
               {
                  CLOG(0,0,"Unable to decode Dialog Portion using cTCAPDecodeDialoguePortion [%d:%s]",l_cert.error_code, l_cert.error_msg);
                  break;
               }
               else
               {
                  DLOG(0,0,"Decoded Dialog Portion using cTCAPDecodeDialoguePortion type[%d]",l_cdpt.dialogue_type);
                  if(CTCAP_DP_AARQ == l_cdpt.dialogue_type)
                  {
                     int l_length = l_cdpt.ctcap_dialogue_apdu.aarq.application_context_name.length;
                     if(l_length > 1)
                     {
                        mapVer = l_cdpt.ctcap_dialogue_apdu.aarq.application_context_name.value[l_length-1];
                        DLOG(0,0,"AARQ Version is [%d]",mapVer);
                     }
                  }
                  else if(CTCAP_DP_AUDT == l_cdpt.dialogue_type)
                  {
                     int l_length = l_cdpt.ctcap_dialogue_apdu.audt.application_context_name.length;
                     if(l_length > 1)
                     {
                        mapVer = l_cdpt.ctcap_dialogue_apdu.audt.application_context_name.value[l_length-1];
                        DLOG(0,0,"AUDT Version is [%d]",mapVer);
                     }
                  }
                  else
                  {
                     CLOG(0,0,"Invalid dialogue_type [%d]",l_cdpt.dialogue_type);
                     break;
                  }
               }

               length = *tc_msg;
               tc_msg += length + 1;   // Move to end of dialog portion
            }

            if (COMP_PRTN_TAG != *tc_msg)
            {
               CLOG(0,0,"Component Portion Tag not found while decoding");
               break;
            }
            else
            {
               tc_msg++; // Skip Component Tag
               if(0x80 == (*tc_msg & 0x80)) // Long definite length or indefinite length
               {
                  //printf("Message is EOC encoded.\n");
                  tc_msg += (decodeLongDefLen(tc_msg)) + 1;

                  if(0xA1 == tc_msg[0])
                  {
                     //printf("Found 0xA1 after skipping indefinite length.\n");
                     tc_msg += 1;
                  }
               }
               if((0x81 == tc_msg[0]) && (0x02 != tc_msg[1]))
                  tc_msg++;
               pCompLen = tc_msg;
               //printf("Component Len: %02x %d\n", tc_msg[0], tc_msg[0]);
               tc_msg++; //Skip Component Len

               if(0xA1 == tc_msg[0])
               {
                  //printf("====================== 0xA1 found\n");
                  pMsgLen = (++tc_msg); //Skip Tag
                  tc_msg++; //Skip Len
               }
               invokeId = tc_msg[2];
               tc_msg += 6; // Skip complete Invoke ID & Op Code

               LLOG(0,0,"OpCode: %d InvokeId: %d",tc_msg[-1], invokeId);

#if 1
               char l_storedCalledPartyAddr[100+1];
               int  l_storedCalledPartyLength=calledParty.globalTitle.addressInformationLength;
               snprintf(l_storedCalledPartyAddr, sizeof(l_storedCalledPartyAddr), calledParty.globalTitle.addressInformation);
#endif
               int l_currentOpCode = tc_msg[-1];
               DLOG(0,0,"Logging Details OpCode:%d, Version:%d", tc_msg[-1], mapVer);
               int l_currentMapVersion = mapVer;
               //StatisticsInterface::logOpCodeDetail(l_currentOpCode, l_currentMapVersion-1, 0);
               g_currentMultiImsiFlag=false;
               g_currentImsiRangeFlag=false;
               g_loopMsgIgnoredFlag=false;
               g_currentPortedFlag=false;
               g_Reject=false;

               switch(tc_msg[-1])
               {
                  case SRI_SM_MSG:
                     {
                      g_CurrentActiveTransactions++;
		      HLRStatisticsInitializer::instance()->logStatistics(g_incomingSccpReqIndex);
                      char pMsisdn[20+1];
                      memset(pMsisdn,'\0',sizeof(pMsisdn));
                      processMAPMsg(sblockIn,tc_msg[-1], &calledParty,tc_msg, pTcLen, pCompLen, pMsgLen, paddedBytes, oTxId, callingParty.globalTitle.addressInformation, pMsisdn);
                      snprintf(pSriMSISDN,21,"%s",pMsisdn);
                      if((true == g_MplManager.overload(MSG_TYPE_SCCP, 0, 0)))
		      {
		         LLOG(0,1,"Rejecting the SCCP message");
                         TdrData l_tdr;
                         l_tdr.setOpCode(SRI_SM_MSG);
                         l_tdr.setOriginatingModule("SCCP");
                         l_tdr.setTdrId();
                         l_tdr.setString(TDR_INDEX_ERR_DESC,"ExceededTransPerSec");
                         l_tdr.setInteger(TDR_INDEX_ERR_CODE,300);

                         char l_buf[3000];
			 memset(l_buf, '\0', sizeof(l_buf));
                         g_tfb->prepareTDR(&l_tdr, l_buf, 0);
			 LLOG(0,1,"Prepared TDR [%s]", l_buf);
			 g_TdrObj.log2(LOG_LEVEL_CRITICAL, __FILE__, __FUNCTION__, __LINE__, 0, 0, l_buf);
                         return false;
		      } 
                      
                      SccpMsg *l_newSccpMsg = new SccpMsg;  //MSG_TYPE_SCCP in constructor 
                      l_newSccpMsg->m_sblockIn = sblockIn;
                      snprintf(l_newSccpMsg->m_calledParty,21,"%s",calledParty.globalTitle.addressInformation);
                      snprintf(l_newSccpMsg->m_callingParty,21,"%s",callingParty.globalTitle.addressInformation);
                      snprintf(l_newSccpMsg->m_Msisdn,21,"%s",pMsisdn);

                      ContextBase *l_ct = g_mm.getRespectiveContext2(SRI_SM_MSG, l_newSccpMsg);
                      if (l_ct != NULL)
                      {
                           //Adding TDR related things
                           if(g_tfb != NULL)
                           {
                              DLOG(0,0,"SCCP: setting map opcode and origmodule");
                              l_ct->m_tdr.setOpCode(SRI_SM_MSG);
                              l_ct->m_tdr.setOriginatingModule("SCCP");
                              l_ct->m_tdr.setRemoteAddr(l_newSccpMsg->m_callingParty);
                              l_ct->m_tdr.setRemoteAddrSsn(callingParty.ssn);
                              char l_ctxtId[20+1];
                              memset(l_ctxtId, '\0', sizeof(l_ctxtId));
                              sprintf(l_ctxtId, "%3s%3s:%08d", l_ct->m_ModName, l_ct->m_MessageName, l_ct->m_GlobalContextId);
                              DLOG(0,0,"TDR ModuleName %s",l_ctxtId);
                              l_ct->m_tdr.setContextId(l_ctxtId);
                           }
                           //End of TDR related things
                       l_ct->setClassName((char*)(typeid(*l_ct).name()));
                       l_ct->CallProcMsg(l_newSccpMsg);
                       if(0 == l_ct->m_ReferenceCount)
                       {
                         DLOG(0,1,"Deleting the context at the call of startProcessing only");
                         delete(l_ct);
                         l_ct=NULL;
                       }
                      }
                      else
                      {
                        CLOG(0,0,"NULL CONTEXT");
                      }
                     }
                     break;

                  default:
                     LLOG(0,0,"Received unknown message, so just ignoring");
                     return false;
                     break;
               } // End of switch(tc_msg[-1]) OpCode


               DLOG(0,0,"Logging Details OpCode:%d, Version:%d, Flags: PortedFlag:%d, MultiImsiFlag:%d, RejectFlag:%d, ImsiRangeFlag:%d, LoopMsgIgnoredFlag:%d", l_currentOpCode, l_currentMapVersion, g_currentPortedFlag, g_currentMultiImsiFlag, g_Reject, g_currentImsiRangeFlag, g_loopMsgIgnoredFlag);

            }
         } // end case TC_BEGIN_TAG
         break;

      case TC_CONT_TAG:
           CLOG(0,0,"TC_CONT_TAG %d received in XUDT",tc_msg);
         return false;
         break;

      case TC_END_TAG:
           CLOG(0,0,"TC_END_TAG %d received in XUDT",tc_msg);
         return false;
         break;
      case TC_ABRT_TAG :
           CLOG(0,0,"TC_ABRT_TAG %d received in XUDT",tc_msg);
         return false;
         break;
      default:
           CLOG(0,0,"Invalid msg type %d received in XUDT",tc_msg);
         return false;
         break;
   }
   U8 len = SCCP_ADDR_MAX_SIZE;
   if(false == g_Reject)
   {
      sccpEncodeAddress(sblockIn->prim.nunitd.called, &calledParty, &len, &sccpError);
      sblockIn->prim.nunitd.l3dpc = 0;
      sblockIn->prim.nunitd.l3opc = 0;
   }
   return true;
}

s16 SCCPMsgHandler :: decodeLongDefLen(u8 *msg)
{
   return (*msg & 0x7f);
}
