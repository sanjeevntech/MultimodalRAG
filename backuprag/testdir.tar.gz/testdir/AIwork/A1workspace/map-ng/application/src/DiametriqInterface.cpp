#include <its++.h>
#include <its_timers.h>
#include <diameter/Command.h>
#include <diameter/base/BaseAVP.h>
#include <UpdateLocation.h>
#include <AuthenticationInformation.h>
#include <Reset.h>
#include <PurgeUE.h>
#include <Notify.h>
#include <InsertSubscriberData.h>
#include <DeleteSubscriberData.h>
#include <CancelLocation.h>
#include <AuthenticationInformation.h>













#include <dia_defines.h>
#include <diameter/base/ReAuth.h>
#include <diameter/base/AbortSession.h>
#include <diameter/base/SessionTermination.h>
#include <diameter/base/Accounting.h>
#include <diameter/base/CapabilitiesExchange.h>
#include <diameter/base/DeviceWatchdog.h>
#include <diameter/base/DisconnectPeer.h>
#include <diameter/base/BaseGenericCommand.h>
#include <diameter/base/NONPROXYABLEERROR.h>
#include <diameter/base/PROXYABLEERROR.h>
#include <diameter/Exceptions.h>
#include <DiametriqInterface.h>
#include <idc_api.h>
#include <ExtendedServiceCoordinator.h>
#include <ConfigReader.h>
#include <ModuleManager.h>
#include <SnmpInterface.h>
#include <StatisticsInterface.h>
#include <MplManager.h>
#include <TdrData.h>
#include <LcsRoutingInfo.h>
#include <Slh_rel_10AVP.h>
#include <NgLogOverride.h>

using namespace std;
using namespace its;
using namespace diameter;
using namespace diameter::base;

using namespace diameter::slh_rel_10;


typedef struct _DiamErrCodeStats
{
   int m_total;
}DiamErrorCodeStats;

map<string, DiamErrorCodeStats> g_diamErrorMapping;

time_t g_StackRegisteredTime;
extern int g_incomingDiameterReqIndex;
extern int g_maxTpsDataIndex;

int g_diamSuspendIndex=-1;
int g_diamResumeIndex=-1;
int g_diamMessageIndex=-1;
int g_diamRequestIndex=-1;
int g_diamAnswerIndex=-1;
int g_diamErrorIndex=-1;
int g_diamProxyableIndex=-1;
int g_diamRetransmitIndex=-1;
pthread_mutex_t g_diamSusp_mutex;

extern int g_CurrentActiveTransactions;
extern void printPdu(diameter::Command *p_ci, char *p_direction);
DiametriqInterface g_di;
extern IDSCLApi *g_smplApi;
extern unsigned int sendAppId;
extern unsigned int sendAppId2;
extern unsigned int receivedAppId;
extern NgLogOverride *g_nlo;
unsigned int sendAppId     = 10000;
unsigned int sendAppId2    = 10000;
unsigned int receivedAppId = 10000;
bool g_isSuspended=false;
ITS_BOOLEAN isConnected = ITS_FALSE ,isTrying = ITS_FALSE;
ITS_BOOLEAN isConnectedBk = ITS_FALSE ,isTryingBk = ITS_FALSE;
ITS_BOOLEAN ifRedundancy = ITS_FALSE;
IDSCLApi *g_smplApi;
vector<IDS_MESSAGE> regVect;
int  StoreRegInfo(IDS_MESSAGE* msg);
void ReleaseRegInfo();
#define DISC_CAUSE_TYPE_TO_TEXT(x) \
   ((x== DisconnectCause::REBOOTING)  ? "REBOOTING"   :\
    ((x== DisconnectCause::BUSY)       ? "BUSY"        :\
     ((x== DisconnectCause::DO_NOT_WANT_TO_TALK_TO_YOU)  ? \
      "DO_NOT_WANT_TO_TALK_TO_YOU" :\
      "INVALID")))

char *getShortCommandCode(int p_commandCode)
{
   switch(p_commandCode)
   {
      case DIAM_COMM_CODE_S6A_S6D_ULR_ULA:
         return "ULR";
         break;
      case DIAM_COMM_CODE_S6A_S6D_CLR_CLA:
         return "CLR";
         break;
      case DIAM_COMM_CODE_S6A_S6D_AIR_AIA:
         return "AIR";
         break;
      case DIAM_COMM_CODE_S6A_S6D_S7A_S7D_IDR_IDA:
         return "ISR";
         break;
      case DIAM_COMM_CODE_S6A_S6D_S7A_S7D_DSR_DSA:
         return "DSR";
         break;
      case DIAM_COMM_CODE_S6A_S6D_PUR_PUA:
         return "PUR";
         break;
      case DIAM_COMM_CODE_S6A_S6D_S7A_S7D_RSR_RSA:
         return "RSR";
         break;
      case DIAM_COMM_CODE_S6A_S6D_NOR_NOA:
         return "NOR";
         break;
      case DIAM_COMM_CODE_SLH_RIR_RIA:
         return "RIR";
         break;
      case DIAM_COMM_CODE_SH_UDR_UDA:
         return "UDR";
         break;
      case DIAM_COMM_CODE_SH_SNR_SNA:
         return "SNR";
         break;
      case DIAM_COMM_CODE_SH_PNR_PNA:
         return "PNR";
         break;
      case DIAM_COMM_CODE_CX_DX_UAR_UAA:
         return "UAR";
         break;
      case DIAM_COMM_CODE_CX_DX_SAR_SAA:
         return "SAR";
         break;
      case DIAM_COMM_CODE_CX_DX_LIR_LIA:
         return "LIR";
         break;
      case DIAM_COMM_CODE_CX_DX_MAR_MAA:
         return "MAR";
         break;
      case DIAM_COMM_CODE_CX_DX_RTR_RTA:
         return "RTR";
         break;
      case DIAM_COMM_CODE_CX_DX_PPR_PPA:
         return "PPR";
         break;
//      case DIAM_COMM_CODE_SWX_MAR_MAA:
//         return "SMAR";
//         break;
      default:
         return "UNK";
         break;
   }
}

bool logErrorStatsFinal(char p_direction, int p_code, int p_resultCode, int p_expResultCode)
{
   DLOG(0,0,"logErrorStatsFinal %c - Code:%d, ResultCode:%d, ExpResultCode:%d", p_direction, p_code, p_resultCode, p_expResultCode);

   char l_errorChar[50+1];
   memset(l_errorChar, '\0', sizeof(l_errorChar));
   if(p_resultCode > 0)
   {
      if(0 == strcmp(DiameterConstants::getDiameterResultCodeChar(p_resultCode), "DiamResultCodeUnknown"))
      {
         snprintf(l_errorChar, sizeof(l_errorChar), "%s", DiameterConstants::getDiameterResultCodeChar(p_resultCode));
      }
      else
      {
         snprintf(l_errorChar, sizeof(l_errorChar), "%04d-%s", p_resultCode, DiameterConstants::getDiameterResultCodeChar(p_resultCode));
      }
   }
   else if(p_expResultCode > 0)
   {
      if(0 == strcmp(DiameterConstants::getDiameterExperimentalResultCodeChar(p_expResultCode,p_code), "DiamExpResultCodeUnknown"))
      {
         snprintf(l_errorChar, sizeof(l_errorChar), "%s", DiameterConstants::getDiameterExperimentalResultCodeChar(p_expResultCode,p_code));
      }
      else
      {
         snprintf(l_errorChar, sizeof(l_errorChar), "%04d-%s", p_expResultCode, DiameterConstants::getDiameterExperimentalResultCodeChar(p_expResultCode,p_code));
      }
   }
   else
   {
      WLOG(0,0,"ResultCode and Experimental ResultCode are not greater than 0");
      return false;
   }
   char l_fullCommand[50+1];
   snprintf(l_fullCommand, sizeof(l_fullCommand), "%s:%s", getShortCommandCode(p_code), l_errorChar);

   DLOG(0,0,"Searching for [%s] in the map", l_fullCommand);
   map<string,DiamErrorCodeStats>::iterator l_itr = g_diamErrorMapping.find(l_fullCommand);
   if(l_itr != g_diamErrorMapping.end())
   {
      HLRStatisticsInitializer::instance()->logStatistics(l_itr->second.m_total);
   }
   else
   {
      WLOG(0,0,"The char [%s] not found in map", l_fullCommand);
   }
   return true;
}


bool logErrorStatistics(diameter::Command& impl)
{
   DLOG(0,0,"logErrorStatistics called Code:%d", impl.getCommandCode());
   if(false == impl.isRequest())
   {
      int l_rc_int=0;
      int l_rc_result = impl.getAvpValue(268, &l_rc_int, Unsigned32Type); //TODO: remove hard-code
      if(0 == l_rc_result)
      {
         LLOG(0,0,"Result code value is %d", l_rc_int);
         logErrorStatsFinal('I', impl.getCommandCode(), l_rc_int, 0);
      }
      else
      {
         TLOG(0,1,"getAvpValue failed for AVP Code 268 (Result-Code). Result:%d", l_rc_result);
         ExperimentalResult l_er;
         int l_erc_result = impl.getAvpValue(297, &l_er, GroupedType);
         if(0 == l_erc_result)
         {
            LLOG(0,0,"Experimental Result Code value is %d", l_er.getExperimentalResultCode().value());
            logErrorStatsFinal('I', impl.getCommandCode(), 0, l_er.getExperimentalResultCode().value());

            //6.3.8.0 Start
            if((l_er.getExperimentalResultCode().value() == DIAM_RESULT_CODE_SUCCESS)  || (l_er.getExperimentalResultCode().value() == DIAM_RESULT_CODE_LIMITED_SUCCESS))
            {
               DLOG(0,1,"Experimental Result Code :stats: Success");
               if((impl.getCommandCode()) == DIAM_COMM_CODE_CX_DX_UAR_UAA)      
               {
                  DLOG(0,0,"Experimental Result Code DIAM_COMM_CODE_CX_DX_UAR_UAA");
                  HLRStatisticsInitializer::instance()->logStatistics(g_di.m_dsi.m_RespondingCommands[(impl.getCommandCode())-290].m_SuccessCount);
               }
            }
            else
            {
               DLOG(0,1,"stats not updating success %d", l_erc_result);
            }
            //6.3.8.0 End
         }
         else
         {
            TLOG(0,1,"getAvpValue failed for AVP Code 297 (Experimental-Result-Code). Result:%d", l_erc_result);
         }
      }
   }
   return true;
}


bool logErrorStatisticsImpl(diameter::CommandImpl *impl)
{
   DLOG(0,0,"logErrorStatisticsImpl called Code:%d", impl->getCommandCode());
   if(false == impl->isRequest())
   {
      int l_rc_int=0;
      int l_rc_result = impl->getAvpValue(268, 0, &l_rc_int, Unsigned32Type); //TODO: remove hard-code
      if(0 == l_rc_result)
      {
         LLOG(0,0,"Result code value is %d", l_rc_int);
         logErrorStatsFinal('R',impl->getCommandCode(), l_rc_int, 0);
      }
      else
      {
         TLOG(0,1,"getAvpValue failed for AVP Code 268 (Result-Code). Result:%d", l_rc_result);
         ExperimentalResult l_er;
         int l_erc_result = impl->getAvpValue(297, 0, &l_er, GroupedType);
         if(0 == l_erc_result)
         {
            LLOG(0,0,"Experimental Result Code value is %d", l_er.getExperimentalResultCode().value());
            logErrorStatsFinal('R',impl->getCommandCode(), 0, l_er.getExperimentalResultCode().value());
         }
         else
         {
            TLOG(0,1,"getAvpValue failed for AVP Code 297 (Experimental-Result-Code). Result:%d", l_erc_result);
         }
      }
   }
   return true;
}


void DiametriqInterface::getStats(char *p_text)
{
   if(false == m_initializedFlag)
   {
      snprintf(p_text, 1000, " DISABLED");
   }
   else
   {
      snprintf(p_text, 1000, " %d", m_diameterMessagesQueue->size());
   }
   return;
}

bool DiametriqInterface::sendErrorResponse(const diameter::CommandImpl *recv_impl, unsigned int sIdx, EDiameterResultCode p_drc)
{
   /*
      DiaHeader *hdr = (DiaHeader*)recv_impl->getHeader();

      DIA_GEN_CMD *cmd;

   // You may have to fill other AVPs if required, like ProxyInfo AVP
   l_pe.getHeader().appId = hdr.appId;

   ((DIA_HDR&)cmd->getHeader()).appId   = hdr.appId;
   ((DIA_HDR&)cmd->getHeader()).flags.p = hdr.flags.p;
   ((DIA_HDR&)cmd->getHeader()).hh = hdr.hh;
   ((DIA_HDR&)cmd->getHeader()).ee = hdr.ee;

   cmd->setSessionIndex(inMsg->getSessionIndex());
   cmd->setClientId(inMsg->getClientId());
   */

   if(  ('E' == g_OtherConfigData->m_DiameterMessageRejectionType) ||
         (recv_impl->getCommandCode() < 316) ||
         (recv_impl->getCommandCode() > 323)
     )
   {
      ITS_INT l_ret = (!ITS_SUCCESS);
      PROXYABLEERROR l_pe(true, false, recv_impl->getCommandCode());
      string l_sess = getSessionId(recv_impl);
      SessionId l_sid(l_sess);
      AuthSessionState l_authSs(AuthSessionState::NO_STATE_MAINTAINED);
      l_pe.setSessionId(l_sid);
      l_pe.setSessionIndex(sIdx);
      //l_pe.setAuthSessionState(l_authSs);

      u8 l_TransHost[100 + 1];
      memset(l_TransHost,'\0',sizeof(l_TransHost));
      GetTranslatedHostAddr(l_TransHost,(u8*)g_OtherConfigData->m_dcd.m_originHost);
      OriginHost l_oh((char*)l_TransHost);

      //OriginHost l_oh(g_OtherConfigData->m_dcd.m_originHost);
      l_pe.setOriginHost(l_oh);
      OriginRealm l_or(g_OtherConfigData->m_dcd.m_originRealm);
      l_pe.setOriginRealm(l_or);
      ResultCode l_rc(p_drc);
      l_pe.setResultCode(l_rc);

      printPdu(&l_pe, "Sent");

      l_ret = sendDiaAppMsg(l_pe, sIdx);
      //cout<<"Sending Error Response ..."<<l_pe<<endl;
      if(ITS_SUCCESS != l_ret)
      {
         ELOG(0,1,"Error in sendErrorResponse");
         return false;
      }
   }
   else
   {
      ITS_INT ret;
      string l_sess = getSessionId(recv_impl);
      SessionId l_sid(l_sess);

      u8 l_TransHost[100 + 1];
      memset(l_TransHost,'\0',sizeof(l_TransHost));
      GetTranslatedHostAddr(l_TransHost,(u8*)g_OtherConfigData->m_dcd.m_originHost);
      OriginHost l_oh((char*)l_TransHost);

      //OriginHost l_oh(g_OtherConfigData->m_dcd.m_originHost);
      OriginRealm l_or(g_OtherConfigData->m_dcd.m_originRealm);
      ResultCode l_rc(p_drc);
      AuthSessionState l_authSs(AuthSessionState::NO_STATE_MAINTAINED);
      if(316 == recv_impl->getCommandCode())
      {
         LLOG(0,1,"Sending ULA with error code %d", p_drc);
         s6a_r10::UpdateLocationAnswer l_aia;
         l_aia.setSessionId(l_sid);
         l_aia.setSessionIndex(sIdx);
         l_aia.setAuthSessionState(l_authSs);
         l_aia.setOriginHost(l_oh);
         l_aia.setOriginRealm(l_or);
         l_aia.setResultCode(l_rc);
         printPdu(&l_aia, "Sent");
         if ((ret = sendDiaAppMsg(*((diameter::Command*)&l_aia), sIdx)) != ITS_SUCCESS)
         {
            ELOG(0,1,"sendDiaAppMsg UpdateLocationAnswer Failure");
         }
      }
      else if(317 == recv_impl->getCommandCode())
      {
         LLOG(0,1,"Sending CLA with error code %d", p_drc);
         s6a_r10::CancelLocationAnswer l_aia;
         l_aia.setSessionId(l_sid);
         l_aia.setSessionIndex(sIdx);
         l_aia.setAuthSessionState(l_authSs);
         l_aia.setOriginHost(l_oh);
         l_aia.setOriginRealm(l_or);
         l_aia.setResultCode(l_rc);
         printPdu(&l_aia, "Sent");
         if ((ret = sendDiaAppMsg(*((diameter::Command*)&l_aia), sIdx)) != ITS_SUCCESS)
         {
            ELOG(0,1,"sendDiaAppMsg CancelLocationAnswer Failure");
         }
      }
      else if(318 == recv_impl->getCommandCode())
      {
         LLOG(0,1,"Sending AIA with error code %d", p_drc);
         s6a_r10::AuthenticationInformationAnswer l_aia;
         l_aia.setSessionId(l_sid);
         l_aia.setSessionIndex(sIdx);
         l_aia.setAuthSessionState(l_authSs);
         l_aia.setOriginHost(l_oh);
         l_aia.setOriginRealm(l_or);
         l_aia.setResultCode(l_rc);
         printPdu(&l_aia, "Sent");
         if ((ret = sendDiaAppMsg(*((diameter::Command*)&l_aia), sIdx)) != ITS_SUCCESS)
         {
            ELOG(0,1,"sendDiaAppMsg AuthenticationInformationAnswer Failure");
         }
      }
      else if(319 == recv_impl->getCommandCode())
      {
         LLOG(0,1,"Sending IDA with error code %d", p_drc);
         s6a_r10::InsertSubscriberDataAnswer l_aia;
         l_aia.setSessionId(l_sid);
         l_aia.setSessionIndex(sIdx);
         l_aia.setAuthSessionState(l_authSs);
         l_aia.setOriginHost(l_oh);
         l_aia.setOriginRealm(l_or);
         l_aia.setResultCode(l_rc);
         printPdu(&l_aia, "Sent");
         if ((ret = sendDiaAppMsg(*((diameter::Command*)&l_aia), sIdx)) != ITS_SUCCESS)
         {
            ELOG(0,1,"sendDiaAppMsg InsertSubscriberDataAnswer Failure");
         }
      }
      else if(320 == recv_impl->getCommandCode())
      {
         LLOG(0,1,"Sending DSA with error code %d", p_drc);
         s6a_r10::DeleteSubscriberDataAnswer l_aia;
         l_aia.setSessionId(l_sid);
         l_aia.setSessionIndex(sIdx);
         l_aia.setAuthSessionState(l_authSs);
         l_aia.setOriginHost(l_oh);
         l_aia.setOriginRealm(l_or);
         l_aia.setResultCode(l_rc);
         printPdu(&l_aia, "Sent");
         if ((ret = sendDiaAppMsg(*((diameter::Command*)&l_aia), sIdx)) != ITS_SUCCESS)
         {
            ELOG(0,1,"sendDiaAppMsg DeleteSubscriberDataAnswer Failure");
         }
      }
      else if(321 == recv_impl->getCommandCode())
      {
         LLOG(0,1,"Sending PUA with error code %d", p_drc);
         s6a_r10::PurgeUEAnswer l_aia;
         l_aia.setSessionId(l_sid);
         l_aia.setSessionIndex(sIdx);
         l_aia.setAuthSessionState(l_authSs);
         l_aia.setOriginHost(l_oh);
         l_aia.setOriginRealm(l_or);
         l_aia.setResultCode(l_rc);
         printPdu(&l_aia, "Sent");
         if ((ret = sendDiaAppMsg(*((diameter::Command*)&l_aia), sIdx)) != ITS_SUCCESS)
         {
            ELOG(0,1,"sendDiaAppMsg PurgeUEAnswer Failure");
         }
      }
      else if(322 == recv_impl->getCommandCode())
      {
         LLOG(0,1,"Sending RSA with error code %d", p_drc);
         s6a_r10::ResetAnswer l_aia;
         l_aia.setSessionId(l_sid);
         l_aia.setSessionIndex(sIdx);
         l_aia.setAuthSessionState(l_authSs);
         l_aia.setOriginHost(l_oh);
         l_aia.setOriginRealm(l_or);
         l_aia.setResultCode(l_rc);
         printPdu(&l_aia, "Sent");
         if ((ret = sendDiaAppMsg(*((diameter::Command*)&l_aia), sIdx)) != ITS_SUCCESS)
         {
            ELOG(0,1,"sendDiaAppMsg ResetAnswer Failure");
         }
      }
      else if(323 == recv_impl->getCommandCode())
      {
         LLOG(0,1,"Sending NOA with error code %d", p_drc);
         s6a_r10::NotifyAnswer l_aia;
         l_aia.setSessionId(l_sid);
         l_aia.setSessionIndex(sIdx);
         l_aia.setAuthSessionState(l_authSs);
         l_aia.setOriginHost(l_oh);
         l_aia.setOriginRealm(l_or);
         l_aia.setResultCode(l_rc);
         printPdu(&l_aia, "Sent");
         if ((ret = sendDiaAppMsg(*((diameter::Command*)&l_aia), sIdx)) != ITS_SUCCESS)
         {
            ELOG(0,1,"sendDiaAppMsg NotifyAnswer Failure");
         }
      }
      else if(8388622 == recv_impl->getCommandCode())
      {
         LLOG(0,1,"Sending RIA with error code %d", p_drc);
         slh_rel_10::LCSRoutingInfoAnswer l_aia;
         l_aia.setSessionId(l_sid);
         l_aia.setSessionIndex(sIdx);
         l_aia.setAuthSessionState(l_authSs);
         l_aia.setOriginHost(l_oh);
         l_aia.setOriginRealm(l_or);
         l_aia.setResultCode(l_rc);
         printPdu(&l_aia, "Sent");
         if ((ret = sendDiaAppMsg(*((diameter::Command*)&l_aia), sIdx)) != ITS_SUCCESS)
         {
            ELOG(0,1,"sendDiaAppMsg RoutingInfoAnswer Failure");
         }
      }
      else
      {
         ELOG(0,1,"Unhandled command code: %d", recv_impl->getCommandCode());
         return false;
      }
   }
   return true;
}

int DiametriqInterface::handleErrorResponse(const diameter::CommandImpl *impl, unsigned int sIdx)
{
   ITS_INT pinfo_avp_count=0, avpCount;
   ProxyInfo *pinf=NULL;
   ITS_INT ret = (!ITS_SUCCESS);

   ELOG(0,1,"Error Answers Received");

   if(impl->isProxyable())
   {
      LLOG(0,1,"Proxyable error");
      PROXYABLEERROR err(*impl);
      /*
         if('C' == g_OtherConfigData->m_dcd.m_diamterPduPrintType)
         {
         cout<<endl<<err<<endl;
         }
         */
      printPdu(&err, "Received");
      Command *cmd = (Command *) &err;
      diameter::base::BaseGenericCommand *gCmd =
         (diameter::base::BaseGenericCommand *) cmd;
      pinfo_avp_count = gCmd->countProxyInfo();

      for(avpCount=0; avpCount < pinfo_avp_count; avpCount++)
      {
         LLOG(0,1,"OriHost: %s,   ReqOrigHost: %s", 
               g_OtherConfigData->m_dcd.m_originHost, gCmd->getProxyInfo(avpCount)->getProxyHost().value().c_str());
         if(!strcmp(g_OtherConfigData->m_dcd.m_originHost, gCmd->getProxyInfo(avpCount)->getProxyHost().value().c_str()))
         {
            const ProxyInfo *pinfo1 = gCmd->getProxyInfo(avpCount);
            pinf = (ProxyInfo*) pinfo1;

            if ((pinf->removeAVP(pinf->getProxyHost())) == ITS_SUCCESS)
            {
               DLOG(0,1,"Proxy-Host AVP removed successfully");
            }
            else
            {
               ELOG(0,1,"Unable to remove Proxy-Host AVP");
            }
            if ((pinf->removeAVP(pinf->getProxyState())) == ITS_SUCCESS)
            {
               DLOG(0,1,"Proxy-State AVP removed successfully");
            }
            else
            {
               ELOG(0,1,"Unable to remove Proxy-State AVP");
            }
            if (((Command*)gCmd)->removeAVP(*pinf) == ITS_SUCCESS)
            {
               DLOG(0,1,"Proxy-Info AVP removed successfully");
            }
            else
            {
               ELOG(0,1,"Unable to remove Proxy-Info AVP");
            }

            if ((ret = sendDiaAppMsg(*gCmd, gCmd->getSessionIndex())) != ITS_SUCCESS)
            {
               ELOG(0,1,"sendDiaAppMsg Failure");
            }
            return ret;
         }
      }
   }
   else
   {
      LLOG(0,1,"Non-Proxyable error");
      NONPROXYABLEERROR err(*impl);
#if DEBUG
      cout<<endl<<err<<endl;
#endif
   }

   DLOG(0,1,"Indicating ERROR to application");
   DiameterMsg *l_msg = new DiameterMsg((char*)getSessionId((diameter::CommandImpl *)impl).c_str(), DIAM_EVENT_ERROR, (EDiameterCommandCode)impl->getCommandCode());
   l_msg->m_sessionIndex = sIdx;
   delete(impl);
   g_esc.recvMsg(l_msg);

   return (ITS_SUCCESS);
}

struct WrapTheIDSMessage
{
    IDS_MESSAGE *m_im;
    struct timeval m_oldTv1,m_pTv1,m_rTv1;
};
void* Recieve(void* args)
{
   DiametriqInterface *l_di = (DiametriqInterface*)args;
   LLOG(0,1,"Diametriq STACK Receive Thread started");
   IDSCLApi l_smplApi;

   while(1)
   {
      // fills the memory area and point that memory with variable ev
      struct WrapTheIDSMessage *l_wtim = (struct WrapTheIDSMessage *)malloc(sizeof(struct WrapTheIDSMessage));
      l_wtim->m_im =  (IDS_MESSAGE*)malloc(sizeof(IDS_MESSAGE));
      DLOG(0,0,"IDS_MESSAGE malloc :cons:");
      memset(l_wtim->m_im, 0, sizeof(IDS_MESSAGE));
      //DLOG(0,1,"Calling ReceiveEvent");
      l_smplApi.ReceiveEvent(l_wtim->m_im);
      struct timeval l_dummyTv;
      memset(&l_dummyTv,'\0',sizeof(l_dummyTv)); 
      memset(&l_wtim->m_oldTv1,'\0',sizeof(l_wtim->m_oldTv1)); 
      memset(&l_wtim->m_pTv1,'\0',sizeof(l_wtim->m_pTv1)); 
      memset(&l_wtim->m_rTv1,'\0',sizeof(l_wtim->m_rTv1)); 
      getTime(l_wtim->m_oldTv1, l_dummyTv, NULL, NULL);
      l_di->m_diameterMessagesQueue->push(l_wtim);

      /*int l_currentQueueSize = l_di->m_diameterMessagesQueue->size();

      pthread_mutex_lock(&g_diamSusp_mutex);
      if (false == g_isSuspended) //Not Suspended
      {
         if (l_currentQueueSize > g_OtherConfigData->m_DiameterMaxQueueSize)
         {
            IDS_MESSAGE l_reg;
            g_isSuspended = true;
            l_reg.msg_type = CONTROL_REQUEST_MSG;
            l_reg.u.controlRequestInfo.controlRequestType = IDS_SUSPEND;
            LLOG(0,1,"DIAMETER CC Sending control request to SUSPEND");
            l_smplApi.ControlRequest(&l_reg);
            HLRStatisticsInitializer::instance()->logStatistics(g_diamSuspendIndex);
         }
         else
         {
            DLOG(0,1,"DIAMETER CC Not Suspended. Queue size is normal");
         }
      }
      pthread_mutex_unlock(&g_diamSusp_mutex);*/
   }
   return NULL;
}


char *getDiametriqErrorChar(int p_code)
{
   switch(p_code)
   {
      case -122:
         return "Client Id Already Registered";
         break;
      case -121:
         return "Application Id not Supported";
         break;
      case -120:
         return "Application already Registered";
         break;
      case -124:
         return "Routing Criteria Invalid";
         break;
      case -125:
         return "DSS is not Registered";
         break;
      case -126:
         return "DSS Registration Decode Fail";
         break;
      default:
         return "Unknown Error Code";
         break;
   }
   return "Unknown Error Code1";
}

int DiametriqInterface::processDiameterMessages()
{
   bool message;
   IDSCLApi smplApi;

   int l_currentQueueSize = m_diameterMessagesQueue->size();

   for(int l_currentMessage=1; l_currentMessage <= l_currentQueueSize; l_currentMessage++)
   { 
      DLOG(0,1,"In processDiameterMessages func %d of %d", l_currentMessage, l_currentQueueSize);
      struct WrapTheIDSMessage *l_wtim = NULL;
      DLOG(0,1,"In processDiameterMessages 1");
      m_diameterMessagesQueue->pop((void**)&l_wtim);
      if(NULL != l_wtim)
      {
         if(NULL != l_wtim->m_im)
         {
            struct timeval l_dummy;
	    memset(&l_dummy,'\0',sizeof(l_dummy)); 
            getTime(l_wtim->m_pTv1,l_dummy ,NULL,NULL);

            DLOG(0,1,"In processDiameterMessages 2");
            IDS_MESSAGE *l_ev = (IDS_MESSAGE *)l_wtim->m_im;
            DLOG(0,1,"In processDiameterMessages 3");

            message = false;

            DLOG(0,1,"<---------- MessageType %d ------------------->", l_ev->msg_type);

            // If received Message type is DIAMETER_MSG then go further
            if (l_ev->msg_type == DIAMETER_MSG)
            {
               switch(l_ev->u.diaInfo.msgType)
               {
                  case ITS_DIA_MSG_TYPE_DATA:
                     message = true;
                     DLOG(0,1,"Received message from Stack");
                     break;
                  case ITS_DIA_MSG_TYPE_IND:
                     DLOG(0,1,"Received Indication from Stack");
                     break;
                  case ITS_DIA_MSG_TYPE_IND_WITH_DATA:
                     message = true;
                     DLOG(0,1,"Received Indication with message from Stack");
                     break;
                  default:
                     DLOG(0,1,"Received unknown indication from Stack");
                     break;
               }

               unsigned int receiveSesIdx = l_ev->u.diaInfo.sessionIndex;
               // If not an indication, then it is a Command Message
               if (message)
               {        
                  DLOG(0,1,"<---------- Diameter message ------------------->");

                  DLOG(0,1,"Diameter session index <%d>", l_ev->u.diaInfo.sessionIndex);

                  // Get the command instance from the message.
                  const diameter::CommandImpl* impl = l_ev->u.diaInfo.cImpl;

                  // If message is not NULL process the messages based on
                  // Application ID.
                  if(impl)
                  {
                     receivedAppId=l_ev->u.diaInfo.appIdentifier;
                     m_recvAppId = l_ev->u.diaInfo.appIdentifier;
                     DLOG(0,1,"Application Id <%u>", receivedAppId);

                     if(receivedAppId == 0)
                     {
                        handleBaseMessages(impl,receiveSesIdx); 
                        delete(impl);
                     }  
                     else if ((receivedAppId == m_regAppId) || (receivedAppId == 16777251) || (receivedAppId == 16777291)||(receivedAppId == 16777217 ) || (receivedAppId == 16777216) || (receivedAppId == 16777265))
                     {
                        DLOG(0,1,"Before Application Id we recieved is <%u>",receivedAppId);
                        logErrorStatisticsImpl((diameter::CommandImpl*)impl);
                        handleDiaAppMsg(impl, receiveSesIdx, l_wtim->m_oldTv1, l_wtim->m_pTv1,l_wtim->m_rTv1);
                        DLOG(0,1,"After Application Id we recieved is <%u>",receivedAppId);
                     }
                     else
                     {
                        ELOG(0,1,"ERROR!!  Received message with applid: %d instead of %d. Ignoring", receivedAppId, m_regAppId);
                     }
                     //delete l_ev->u.diaInfo.cImpl; TOCHECK:
                     //l_ev->u.diaInfo.cImpl = NULL; TOCHECK:
                  }
               }
               else
               {
                  LLOG(0,1,"Indication type: <%d> for session index <%u>", l_ev->u.diaInfo.indication, l_ev->u.diaInfo.sessionIndex);

                  switch(l_ev->u.diaInfo.indication)
                  {
                     case DISCONECT_IND_FROM_STACK:
                        {
                           ITS_OCTET *diaInfoData = (ITS_OCTET*)l_ev->u.diaInfo.data;

                           ITS_OCTET peerHost[64];
                           memset(peerHost, 0, sizeof(peerHost)/sizeof
                                 (ITS_OCTET));
                           ITS_OCTET ab=0; 
                           while(*diaInfoData != '.')
                           {
                              peerHost[ab++]= *(diaInfoData++);
                           } 
                           peerHost[ab]='\0';
                           LLOG(0,1,"Peer Host            : %s", peerHost);
                           diaInfoData++;

                           ITS_OCTET peerRelam[64];
                           memset(peerRelam, 0, sizeof(peerRelam)/sizeof
                                 (ITS_OCTET));
                           ITS_OCTET bc=0; 
                           while(*diaInfoData != ';')
                           {
                              peerRelam[bc++]= *(diaInfoData++);
                           } 
                           peerRelam[bc]='\0';
                           LLOG(0,1,"Peer Relam           : %s", peerRelam);
                           diaInfoData++;

                           ITS_USHORT disCause = 0;
                           disCause = atoi((const char*)(diaInfoData));
                           LLOG(0,1,"Disconnect Cause     : %s", DISC_CAUSE_TYPE_TO_TEXT(disCause));
                           LLOG(0,1,"Disconnect Indication from stack");
                           HLRStatisticsInitializer::instance()->logStatistics(m_dsi.m_DISC);
                        }
                        break;
                     case TIME_OUT_IND_FROM_STACK:
                        {
                           LLOG(0,1,"Session Id : %s. TIME_OUT_IND_FROM_STACK", l_ev->u.diaInfo.data);
                           DiameterMsg *l_msg = new DiameterMsg((char*)l_ev->u.diaInfo.data, DIAM_EVENT_TIME_OUT);
                           l_msg->m_sessionIndex = receiveSesIdx;
                           g_esc.recvMsg(l_msg);
                           HLRStatisticsInitializer::instance()->logStatistics(m_dsi.m_TIME_OUT);
                        }
                        break;
                     case AUTH_LIFE_TIME_OUT_IND_FROM_STACK:
                        {
                           LLOG(0,1,"Session Id : %s. AUTH_LIFE_TIME_OUT_IND_FROM_STACK", l_ev->u.diaInfo.data);
                           DiameterMsg *l_msg = new DiameterMsg((char*)l_ev->u.diaInfo.data, DIAM_EVENT_AUTH_LIFE_TIME_OUT);
                           l_msg->m_sessionIndex = receiveSesIdx;
                           g_esc.recvMsg(l_msg);
                           HLRStatisticsInitializer::instance()->logStatistics(m_dsi.m_AUTH_LIFE_TIME_OUT);
                        }
                        break;
                     case AUTH_GRACE_TIME_OUT_IND_FROM_STACK:
                        {
                           LLOG(0,1,"Session Id : %s. AUTH_GRACE_TIME_OUT_IND_FROM_STACK", l_ev->u.diaInfo.data);
                           DiameterMsg *l_msg = new DiameterMsg((char*)l_ev->u.diaInfo.data, DIAM_EVENT_AUTH_GRACE_TIME_OUT);
                           l_msg->m_sessionIndex = receiveSesIdx;
                           g_esc.recvMsg(l_msg);
                           HLRStatisticsInitializer::instance()->logStatistics(m_dsi.m_AUTH_GRACE_TIME_OUT);
                        }
                        break;
                     case CORRUPTED_MSG_IND_FROM_STACK:
                        {
                           LLOG(0,1,"Session Id : %s. CORRUPTED_MSG_IND_FROM_STACK", l_ev->u.diaInfo.data);
                           DiameterMsg *l_msg = new DiameterMsg((char*)l_ev->u.diaInfo.data, DIAM_EVENT_CORRUPTED_MSG);
                           l_msg->m_sessionIndex = receiveSesIdx;
                           g_esc.recvMsg(l_msg);
                           HLRStatisticsInitializer::instance()->logStatistics(m_dsi.m_CORRUPTED_MSG);
                        }
                        break;
                     case ACCT_INTERIM_TIME_OUT_IND_FROM_STACK:
                        {
                           LLOG(0,1,"Session Id : %s. ACCT_INTERIM_TIME_OUT_IND_FROM_STACK", l_ev->u.diaInfo.data);
                           DiameterMsg *l_msg = new DiameterMsg((char*)l_ev->u.diaInfo.data, DIAM_EVENT_ACCT_INTERIM_TIME_OUT);
                           l_msg->m_sessionIndex = receiveSesIdx;
                           g_esc.recvMsg(l_msg);
                           HLRStatisticsInitializer::instance()->logStatistics(m_dsi.m_ACCT_INTERIM_TIME_OUT);
                        }
                        break;
                     case FAILOVER_IND_FROM_STACK:
                        {
                           ITS_OCTET *diaInfoData = (ITS_OCTET*)l_ev->u.diaInfo.data;

                           ITS_OCTET peerHost[64];
                           memset(peerHost, 0, sizeof(peerHost)/sizeof
                                 (ITS_OCTET));
                           ITS_OCTET ab=0;
                           while(*diaInfoData != '.')
                           {
                              peerHost[ab++]= *(diaInfoData++);
                           }
                           peerHost[ab]='\0';
                           LLOG(0,1,"Peer Host            : %s", peerHost);
                           diaInfoData++;

                           ITS_OCTET peerRelam[64];
                           memset(peerRelam, 0, sizeof(peerRelam)/sizeof
                                 (ITS_OCTET));
                           ITS_OCTET bc=0;
                           while(*diaInfoData != ';')
                           {
                              peerRelam[bc++]= *(diaInfoData++);
                           }
                           peerRelam[bc]='\0';
                           LLOG(0,1,"Peer Relam           : %s", peerRelam);
                           diaInfoData++;

                           ITS_OCTET altPeerHost[64];
                           memset(altPeerHost, 0, sizeof(altPeerHost)/sizeof
                                 (ITS_OCTET));
                           ITS_OCTET cd=0;
                           while(*diaInfoData != '.')
                           {
                              altPeerHost[cd++]= *(diaInfoData++);
                           }
                           altPeerHost[cd]='\0';
                           LLOG(0,1,"Altenate Peer Host   : %s", altPeerHost);
                           diaInfoData++;

                           ITS_OCTET altPeerRelam[64];
                           memset(altPeerRelam, 0, sizeof(altPeerRelam)/sizeof
                                 (ITS_OCTET));
                           ITS_OCTET de=0;
                           while(*diaInfoData != '\0')
                           {
                              altPeerRelam[de++]= *(diaInfoData++);
                           }
                           altPeerRelam[de]='\0';
                           LLOG(0,1,"Alternate Peer Relam : %s", altPeerRelam);
                           LLOG(0,1,"FAILOVER Indication from stack");
                           HLRStatisticsInitializer::instance()->logStatistics(m_dsi.m_FAILOVER);
                        }

                        break;
                     case FAILBACK_IND_FROM_STACK:
                        {
                           ITS_OCTET *diaInfoData = (ITS_OCTET*)l_ev->u.diaInfo.data;

                           ITS_OCTET peerHost[64];
                           memset(peerHost, 0, sizeof(peerHost)/sizeof
                                 (ITS_OCTET));
                           ITS_OCTET ab=0;
                           while(*diaInfoData != '.')
                           {
                              peerHost[ab++]= *(diaInfoData++);
                           }
                           peerHost[ab]='\0';
                           LLOG(0,1,"Peer Host            : %s", peerHost);
                           diaInfoData++;

                           ITS_OCTET peerRelam[64];
                           memset(peerRelam, 0, sizeof(peerRelam)/sizeof
                                 (ITS_OCTET));
                           ITS_OCTET bc=0;
                           while(*diaInfoData != ';')
                           {
                              peerRelam[bc++]= *(diaInfoData++);
                           }
                           peerRelam[bc]='\0';
                           LLOG(0,1,"Peer Relam           : %s", peerRelam);
                           diaInfoData++;

                           ITS_OCTET altPeerHost[64];
                           memset(altPeerHost, 0, sizeof(altPeerHost)/sizeof
                                 (ITS_OCTET));
                           ITS_OCTET cd=0;
                           while(*diaInfoData != '.')
                           {
                              altPeerHost[cd++]= *(diaInfoData++);
                           }
                           altPeerHost[cd]='\0';
                           LLOG(0,1,"Altenate Peer Host   : %s", altPeerHost);
                           diaInfoData++;

                           ITS_OCTET altPeerRelam[64];
                           memset(altPeerRelam, 0, sizeof(altPeerRelam)/sizeof
                                 (ITS_OCTET));
                           ITS_OCTET de=0;
                           while(*diaInfoData != '\0')
                           {
                              altPeerRelam[de++]= *(diaInfoData++);
                           }
                           altPeerRelam[de]='\0';
                           LLOG(0,1,"Alternate Peer Relam : %s", altPeerRelam);
                           LLOG(0,1,"FAILBACK Indication from stack");
                           HLRStatisticsInitializer::instance()->logStatistics(m_dsi.m_FAILBACK);
                        }
                        break;
                     default:
                        {
                           ELOG(0,1,"Unhandled message");
                        }
                        break;
                  }

               }
            }

            // If the message is acknowledge for Register
            // Display the result of the requested message
            // Display the Registered server IP and Port
            if (l_ev->msg_type == REGISTER_ACK_MSG)
            {
               if (l_ev->u.regAck.errorCode < 0)
               {
                  HLRStatisticsInitializer::instance()->logStatistics(m_dsi.m_DIAM_REGISTRATION_FAILED);
                  ELOG(0,1,"DIAMETER Stack registration failed ErrCode:%d [%s]",l_ev->u.regAck.errorCode, getDiametriqErrorChar(l_ev->u.regAck.errorCode));
                  g_si.sendSnmpTrap(g_DiameterStackConnectionTrap, TRAP_TYPE_FAIL, TRAP_SEVERITY_CRITICAL);
                  exitFunc(EXIT_APPLICATION_TYPE_DIAMETRIQ_CLIENT_ALREADY_REGISTERED_ERROR);
               }
               else
               {
                  HLRStatisticsInitializer::instance()->logStatistics(m_dsi.m_DIAM_REGISTRATION_SUCCESS);
                  m_diameterStackRegisteredFlag=true;
                  g_si.sendSnmpTrap(g_DiameterStackConnectionTrap, TRAP_TYPE_PASS, TRAP_SEVERITY_MAJOR);
                  LLOG(0,1,"Registered result : %d, error: %d, serverip: %s, server port: %d",l_ev->u.regAck.result, l_ev->u.regAck.errorCode, l_ev->u.regAck.ipAddr, l_ev->u.regAck.port);
                  printf("\n DIAMETER Stack registration successful \n");
                  sleep(1);
               }
            } 
            // If the message is acknowledge for DeRegister
            // Display the result of the requested message
            if (l_ev->msg_type == DEREGISTER_ACK_MSG)
            {
               LLOG(0,1,"Deregistered result: %d", l_ev->u.deregAck.result);
               LLOG(0,1,"Deregistered error:  %d", l_ev->u.deregAck.errorCode);
               if (l_ev->u.deregAck.errorCode < 0)
               {
                  ELOG(0,1,"Client deregistration failed for AppId[%d]",l_ev->u.diaInfo.appIdentifier);
               }
               HLRStatisticsInitializer::instance()->logStatistics(m_dsi.m_DEREGISTER_ACK_MSG);
            }
            // If the message a notification from Distributed Server
            if (l_ev->msg_type == DIASERVER_NOTIFY_MSG)
            {
               DLOG(0,1,"Notification from Server for");
               DLOG(0,1,"Diameter Application Id <%u> session index <%u>",
                     l_ev->u.notifyInfo.appId, l_ev->u.notifyInfo.sessionIndex);
               if (l_ev->u.notifyInfo.data)
               {
                  DLOG(0,1,"Session Id : %s", l_ev->u.notifyInfo.data);
                  free(l_ev->u.notifyInfo.data);
                  DLOG(0,0,"notifyInfo.data free :des:");
                  l_ev->u.notifyInfo.data = NULL;
               }
               switch(l_ev->u.notifyInfo.indType)
               {
                  case IDS_MSG_ENCODE_FAIL_IND:
                     ELOG(0,1,"Failed to encode message");
                     break;
                  case IDS_SENDTO_STACK_FAIL_IND:
                     ELOG(0,1,"Failed to send message to Stack");
                     break;
                  case IDS_RELEASE_SESS_FAIL_IND:
                     ELOG(0,1,"Failed to release the diameter session");
                     break;
                  case IDS_RELEASE_SESS_SUCCESS_IND:
                     DLOG(0,1,"Diameter session released ");
                     break;
               }
               HLRStatisticsInitializer::instance()->logStatistics(m_dsi.m_DIASERVER_NOTIFY_MSG);
            }
            if (l_ev->msg_type == GLOBAL_UNIQ_ADDR_ACK_MSG)
            {
               DLOG(0,1,"Global Unique Addr Ack");
               if (l_ev->u.guaAck.action == IDS_GUA_ADD)
               {
                  DLOG(0,1,"Global Unique Addr Msg Action: Add");
               }
               else
               {
                  DLOG(0,1,"Global Unique Addr Msg Action: Del");
               }
               if (l_ev->u.guaAck.result == SUCCESS)
               {
                  DLOG(0,1,"Global Unique Addr Success");
               }
               else
               {
                  DLOG(0,1,"Global Unique Addr Failure");
               }
               HLRStatisticsInitializer::instance()->logStatistics(m_dsi.m_GLOBAL_UNIQ_ADDR_ACK_MSG);
            }

            free(l_ev);
            DLOG(0,0,"IDS_MESSAGE free :des:");
	 }
	 else
	 {
		 ELOG(0,0,"ERRO! ev is NULL");
	 }
      }
      if(NULL != l_wtim)
         free(l_wtim);

      int l_currentQueueSize = m_diameterMessagesQueue->size();


      if (1 == g_OtherConfigData->m_DiamSuspendResumeFeature) //Suspend/Resume Feature enabled or not
      {
        pthread_mutex_lock(&g_diamSusp_mutex);
        if (false == g_isSuspended) //Not Suspended
        {
          if (l_currentQueueSize > g_OtherConfigData->m_DiameterMaxQueueSize)
          {
            IDS_MESSAGE l_reg;
            g_isSuspended = true;
            l_reg.msg_type = CONTROL_REQUEST_MSG;
            l_reg.u.controlRequestInfo.controlRequestType = IDS_SUSPEND;
            LLOG(0,1,"DIAMETER CC Sending control request to SUSPEND");
            smplApi.ControlRequest(&l_reg);
            HLRStatisticsInitializer::instance()->logStatistics(g_diamSuspendIndex);
         }
         else
         {
            DLOG(0,1,"DIAMETER CC Not Suspended. Queue size is normal");
         }
       }

       if (true == g_isSuspended) //Suspended
       {
         if (l_currentQueueSize <= g_OtherConfigData->m_DiameterMinQueueSize)
         {
            IDS_MESSAGE l_reg;
            g_isSuspended = false;
            l_reg.msg_type = CONTROL_REQUEST_MSG;
            l_reg.u.controlRequestInfo.controlRequestType = IDS_RESUME;
            HLRStatisticsInitializer::instance()->logStatistics(g_diamResumeIndex);
            LLOG(0,1,"DIAMETER CC Sending control request to RESUME");
            smplApi.ControlRequest(&l_reg);
         }
         else
         {
            DLOG(0,1,"DIAMETER CC Doing nothing since suspended");
         }
       }
       pthread_mutex_unlock(&g_diamSusp_mutex);
      }  
   }
   return l_currentQueueSize;
}

/*.implementation:static
 ****************************************************************************
 *  Purpose: Thread Method used to Connect to the Distributed Server 
 *
 *  Input Parameters:
 *      void* args: Arguments (if any).
 *
 *  Input/Output Parameters:
 *      None.
 *
 *  Output Parameters:
 *      None.
 *
 *  Return Value:
 *
 *  Notes:
 *
 *  See Also:
 ****************************************************************************/
   extern "C"
void* ConnectToServer(void *args)
{
   ITS_INT retVal = ITS_SUCCESS;

   isTrying = ITS_TRUE;

   // Initializes the connectivity with the IDS Server
   retVal = g_smplApi->Initialize(g_OtherConfigData->m_dcd.m_diamPrimaryIpAddress,g_OtherConfigData->m_dcd.m_diamPrimaryIpPort);
   if (retVal == ITS_SUCCESS)
   {
      LLOG(0,1,"ConnectToServer smplApi.Initialize is ITS_SUCCESS");
      isConnected = ITS_TRUE;
   }
   else
   {
      ELOG(0,1,"ConnectToServer failure");
   }
   isTrying = ITS_FALSE;
   pthread_exit(NULL);
   return NULL;
}

   extern "C"
void* ConnectToBkServer(void *args)
{
   LLOG(0,1,"ConnectToBkServer called");
   ITS_INT retVal = ITS_SUCCESS;

   isTryingBk = ITS_TRUE;

   // Initializes the connectivity with the IDS Server
   // Connect to backup
   retVal = g_smplApi->Initialize(g_OtherConfigData->m_dcd.m_diamBackupIpAddress,g_OtherConfigData->m_dcd.m_diamBackupIpPort);
   if (retVal == ITS_SUCCESS)
   {
      isConnectedBk = ITS_TRUE;
      LLOG(0,1,"ConnectToServer smplApi.Initialize is ITS_SUCCESS for the BkpServer");
   }
   else
   {
      ELOG(0,1,"ConnectToBkServer failure");
      return NULL;
   }

   isTryingBk = ITS_FALSE;

   pthread_exit(NULL);

   LLOG(0,1,"ConnectToBkServer end");
   return NULL;
}

/*  implementation: public
 ****************************************************************************
 *  Purpose: 
 *      Utility function to store the Registration Information.
 * 
 *  Input Parameters:
 *      takes IDS_MESSAGE* pointer as input.
 *  Input/Output Parameters:
 *      None.
 *
 *  Output Parameters:
 *      None.
 * 
 *  Return Value:
 *      returns IDS_SUCCESS on successful storage and !IDS_SUCCESS on failure.
 *  Notes: 
 * 
 *  See Also:
 ****************************************************************************/
   int 
StoreRegInfo(IDS_MESSAGE* msg)
{ 
   if (msg)
   {
      vector<IDS_MESSAGE>::iterator ii;
      for (ii =regVect.begin(); ii!=regVect.end() ; ii++)
      {
         if ((*ii).u.regInfo.appIdentifier == msg->u.regInfo.appIdentifier)
         {
            DLOG(0,1,"AppId Already Exists");
            return(!IDS_SUCCESS);
         }
      }
      regVect.push_back(*msg);

      return IDS_SUCCESS;
   }
   return(!IDS_SUCCESS);
}



void *PrintMenu(void* args)
{
   //int input = 0;
   int choice = 0;
   IDS_MESSAGE reg;
   bool l_secondAppId = false;
   IDS_MESSAGE reg2[10];// added for SLH 4.0.2.0
   if( g_OtherConfigData->m_dcd.m_additionalAppIdcount > 0 )
      l_secondAppId = true;
   //pthread_t threadConnect;
   pthread_t threadConnectBk;
   string  inStr;
   //int len = 0;
   //int idx = 0;

   if(0 != g_OtherConfigData->m_THBEnabled)
   {
      if(false == g_thb.registerMe(60, "PrintMenu"))
      {
         CLOG(1,1,"RegisterMe failed on Printmenu");
         exit(1);
      }
   }

   LLOG(0,1,"PrintMenu OrigHost:%s OrigRealm:%s", g_OtherConfigData->m_dcd.m_originHost, g_OtherConfigData->m_dcd.m_originRealm);

   g_smplApi->SetHostInfo(g_OtherConfigData->m_dcd.m_originHost,
         g_OtherConfigData->m_dcd.m_originRealm);
   bool l_reg=false;
   while (1)
   {
      if(true == l_reg || choice == 3)
         break;
      choice++;
      switch(choice)
      {
         case 1:
            LLOG(0,1,"Connecting to the Stack");
            // Connect to the server , if client is not already connected
            // or if client is not already trying to connect.
            if (!isConnected)
            {
               ITS_INT retVal = ITS_SUCCESS;
               retVal = g_smplApi->Initialize(g_OtherConfigData->m_dcd.m_diamPrimaryIpAddress,g_OtherConfigData->m_dcd.m_diamPrimaryIpPort);
               if (retVal == ITS_SUCCESS)
               {
                  LLOG(0,1,"ConnectToServer smplApi.Initialize is ITS_SUCCESS");
                  isConnected = ITS_TRUE;
               }
               else
               {
                  ELOG(0,1,"ConnectToServer failure");
                  return false;
               }
               //pthread_create(&threadConnect, NULL, ConnectToServer, NULL);
            }
            if (ifRedundancy)
            {
               if (!isConnectedBk && !isTryingBk)
               {
                  // Create a thread to Connect to the backup server
                  pthread_create(&threadConnectBk,NULL,ConnectToBkServer,NULL);
               }
            }
            /*
               else if ( (!ifRedundancy && isConnected) ||
               (ifRedundancy && (isConnected || isConnectedBk)))

               {
               ELOG(0,1,"Already Connected to the Server ");
               }
               */
            sleep(1);
            break;

         case 2:

            LLOG(0,1,"Registering with the Stack red:%d, conn:%d, connbkp:%d",
                  ifRedundancy, isConnected, isConnectedBk);
            //if (!isConnected)
            if ((!ifRedundancy && !isConnected) ||
                  ((ifRedundancy && !isConnected && !isConnectedBk)))
            {
               ELOG(0,1,"ERROR!!!  Not Connected to Server ");
               break;
            }
            else if ( (ifRedundancy &&
                     (
                      (g_smplApi->IsConnectionUp(IDS_PRIMARY_CONNECTION) &&
                       g_smplApi->IsConnectionUp(IDS_BACKUP_CONNECTION) &&
                       !g_smplApi->IsRegisteredWith(IDS_PRIMARY_CONNECTION)&&
                       !g_smplApi->IsRegisteredWith(IDS_BACKUP_CONNECTION)
                      ) ||
                      (g_smplApi->IsConnectionUp(IDS_PRIMARY_CONNECTION) &&
                       !g_smplApi->IsConnectionUp(IDS_BACKUP_CONNECTION) &&
                       !g_smplApi->IsRegisteredWith(IDS_PRIMARY_CONNECTION)
                      )||
                      (g_smplApi->IsConnectionUp(IDS_BACKUP_CONNECTION) &&
                       !g_smplApi->IsConnectionUp(IDS_PRIMARY_CONNECTION) &&
                       !g_smplApi->IsRegisteredWith(IDS_BACKUP_CONNECTION)
                      )
                     )
                     ) ||
                  (!ifRedundancy && !g_smplApi->IsRegistered()) )
            {
               reg.clientID = g_OtherConfigData->m_dcd.m_clientId;
               reg.msg_type = REGISTER_MSG;

               reg.u.regInfo.routing_criteria = IDS_APP_IDENTIFIER;

               unsigned int sendAppIdType = 0;
               sendAppId = strtoul(inStr.c_str(), NULL, 0); //Return Unsigned long.
               sendAppId = g_OtherConfigData->m_dcd.m_applicationId;
               reg.u.regInfo.appIdentifier = sendAppId;
               if(g_OtherConfigData->m_dcd.m_connectionType == 'P')
               {
                  reg.u.regInfo.connectionType = IDS_PRIMARY_CONNECTION;
               }
               else
               {
                  reg.u.regInfo.connectionType = IDS_BACKUP_CONNECTION;

               }
               reg.u.regInfo.appIdType      = sendAppIdType;
               LLOG(0,1,"AppIdentifier: %d, ConnType: %d, AppIdType: %d", reg.u.regInfo.appIdentifier, reg.u.regInfo.connectionType, reg.u.regInfo.appIdType);
               if (StoreRegInfo(&reg) == IDS_SUCCESS)
               {
                  LLOG(0,1,"StoreRegInfo is IDS_SUCCESS for AppId[%d]",reg.u.regInfo.appIdentifier);
                  g_smplApi->Register(&reg);
               }
               else
               {
                  ELOG(0,1,"ERROR!!! REGISTERING TO STACK FAILED for AppId[%d]",reg.u.regInfo.appIdentifier);
               }

               /** register for Additional application ID */
               for(int AppCount =0 ;AppCount< g_OtherConfigData->m_dcd.m_additionalAppIdcount ;AppCount++)
               {
                  if( true == l_secondAppId)
                  {
                     reg2[AppCount].clientID = g_OtherConfigData->m_dcd.m_clientId;
                     reg2[AppCount].msg_type = REGISTER_MSG;
                     reg2[AppCount].u.regInfo.routing_criteria = IDS_APP_IDENTIFIER;
                     reg2[AppCount].u.regInfo.appIdType      = sendAppIdType;
                     sendAppId2 = strtoul(inStr.c_str(), NULL, 0); //Return Unsigned long.
                     sendAppId2 = g_OtherConfigData->m_dcd.m_additionalAppId[AppCount];
                     reg2[AppCount].u.regInfo.appIdentifier = g_OtherConfigData->m_dcd.m_additionalAppId[AppCount]; // slh- 16777291;
                     if(g_OtherConfigData->m_dcd.m_connectionType == 'P')
                     {

                        reg2[AppCount].u.regInfo.connectionType = IDS_PRIMARY_CONNECTION;
                     }
                     else
                     {

                        reg2[AppCount].u.regInfo.connectionType = IDS_BACKUP_CONNECTION;
                     }
                  }

                  // Registers the Client w.r.t Client ID and  Application ID.
                  if( true == l_secondAppId)
                  {
                     LLOG(0,1,"AppIdentifier2: %d, ConnType: %d, AppIdType: %d", reg2[AppCount].u.regInfo.appIdentifier, reg2[AppCount].u.regInfo.connectionType, reg2[AppCount].u.regInfo.appIdType);
                     if (StoreRegInfo(&reg2[AppCount]) == IDS_SUCCESS)
                     {
                        LLOG(0,1,"StoreRegInfo is IDS_SUCCESS for second AppId[%d]",reg2[AppCount].u.regInfo.appIdentifier);
                        g_smplApi->Register(&reg2[AppCount]);
                     }
                     else
                     {
                        ELOG(0,1,"ERROR!!! REGISTERING TO STACK FAILED for second AppId[%d]",reg2[AppCount].u.regInfo.appIdentifier);
                     }
                  }
               }
               l_reg = true;
               break;
            }
            else if (ifRedundancy)
            {
               if (g_smplApi->IsConnectionUp(IDS_PRIMARY_CONNECTION))
               {
                  if (!g_smplApi->IsRegisteredWith(IDS_PRIMARY_CONNECTION))
                  {
                     // Registers the Client with Primary
                     g_smplApi->Register(&reg);

                  }
                  else
                  {
                     ELOG(0,1,"Registered already: ClientId [%d], AppId [%d],"
                           ,reg.clientID, reg.u.regInfo.appIdentifier);
                  }
               }
               if (g_smplApi->IsConnectionUp(IDS_BACKUP_CONNECTION))
               {
                  if (!g_smplApi->IsRegisteredWith(IDS_BACKUP_CONNECTION))
                  {
                     // Registers the Client with Backup
                     g_smplApi->Register(&reg);

                  }
                  else
                  {
                     ELOG(0,1,"Registered already: ClientId [%d], AppId [%d], "
                           ,reg.clientID, reg.u.regInfo.appIdentifier);
                  }
               }
               for(int AppCount =0 ;AppCount< g_OtherConfigData->m_dcd.m_additionalAppIdcount ;AppCount++)
               {
                  if (g_smplApi->IsConnectionUp(IDS_PRIMARY_CONNECTION))
                  {
                     if (!g_smplApi->IsRegisteredWith(IDS_PRIMARY_CONNECTION))
                     {
                        if( true == l_secondAppId)
                           g_smplApi->Register(&reg2[AppCount]);
                     }
                     else
                     {
                        ELOG(0,1,"Registered already: ClientId [%d], AppId [%d], ClientId2 [%d], AppId2 [%d]"
                              ,reg.clientID, reg.u.regInfo.appIdentifier, reg2[AppCount].clientID, reg2[AppCount].u.regInfo.appIdentifier);
                     }
                  }
                  if (g_smplApi->IsConnectionUp(IDS_BACKUP_CONNECTION))
                  {
                     if (!g_smplApi->IsRegisteredWith(IDS_BACKUP_CONNECTION))
                     {
                        // Registers the Client with Backup
                        if( true == l_secondAppId)
                           g_smplApi->Register(&reg2[AppCount]);
                     }
                     else
                     {
                        ELOG(0,1,"Registered already: ClientId [%d], AppId [%d], ClientId2 [%d], AppId2 [%d]"
                              ,reg.clientID, reg.u.regInfo.appIdentifier, reg2[AppCount].clientID, reg2[AppCount].u.regInfo.appIdentifier);
                     }
                  }
               }
            }
            else
            {
               for(int AppCount =0 ;AppCount< g_OtherConfigData->m_dcd.m_additionalAppIdcount ;AppCount++)
               {
                  ELOG(0,1,"Registered already : ClientId [%d], AppId [%d] , ClientId2 [%d], AppId2 [%d]",
                        reg.clientID, reg.u.regInfo.appIdentifier, reg2[AppCount].clientID, reg2[AppCount].u.regInfo.appIdentifier);

               }
            }
            break;

         default:
            ELOG(0,1,"May be an error");
            break;
      }
   }
   if(0 != g_OtherConfigData->m_THBEnabled)
   {
      if(false == g_thb.unRegisterMe())
      {
         CLOG(1,1,"UnRegisterMe failed on PrintMenu");
         exit(1);
      }
   }
   return NULL;

}

/*.implementation:static
 ****************************************************************************
 *  Purpose: ReRegister function registers the application Id
 *      and fills into a character array.
 *
 *  Input Parameters:
 *      None.
 *
 *  Output Parameters:
 *      None.
 *
 *  Return Value: None
 *
 *  Notes:
 *
 *  See Also:
 ****************************************************************************/
void ReRegister(IDS_CALLBACK_INFO idsCbInfo)
{
   IDSCLApi api;
   //IDS_MESSAGE reg;   // The  registration info saved sent first time
   LLOG(0,1,"Re-Register ");

   /**
    * Checking if primary connection is up
    */
   if ( idsCbInfo.ids_stat.conType == IDS_PRIMARY_CONNECTION &&
         idsCbInfo.isConUp == IDS_TRUE )
   {
      cout<<"Primary Connection is up"<<endl;
      LLOG(0,1,"Primary Connection is up");
   }
   /**
    * Checking if backup connection is up
    */
   else if (idsCbInfo.ids_stat.conType == IDS_BACKUP_CONNECTION &&
         idsCbInfo.isConUp == IDS_TRUE)
   {
      cout<<"Backup Connection is up"<<endl;
      LLOG(0,1,"Backup Connection is up");

   }

   /**
    * Please do the Re-Registration processing here.
    */

   vector<IDS_MESSAGE>::iterator it;
   for (it = regVect.begin(); it!= regVect.end() ; it++)
   {
      cout<<endl<<"Sending Re-Registration Message for Client-Id:"<< (*it).clientID<<" and AppId:"<<(*it).u.regInfo.appIdentifier<< endl;
      LLOG(0,1,"Sending Re-Registration Message");
      LLOG(0,1,"ReRegister AppIdentifier: %d, ConnType: %d, AppIdType: %d", 
            (*it).u.regInfo.appIdentifier, (*it).u.regInfo.connectionType, (*it).u.regInfo.appIdType);
      api.Register(&(*it), idsCbInfo.ids_stat.conType);
   }

}

/* CallBackFunc function */
   void
CallBackFunc(IDS_CALLBACK_INFO idsCbInfo)
{
   cout <<"CallBackFunc invoked"<<endl;
   LLOG(0,1,"CallBackFunc invoked");

   if (idsCbInfo.type == IDS_CONNECT)
   {
      ReRegister(idsCbInfo);
   }
   else if(idsCbInfo.type == IDS_DISCONNECT)
   {
      /**
       * Checking if primary connection is up
       */
      if ( idsCbInfo.ids_stat.conType == IDS_PRIMARY_CONNECTION &&
            idsCbInfo.isConUp == IDS_FALSE )
      {
         cout<<"Primary Connection is down"<<endl;
         LLOG(0,1,"Primary Connection is down");
      }
      /**
       * Checking if backup connection is up
       */
      else if (idsCbInfo.ids_stat.conType == IDS_BACKUP_CONNECTION &&
            idsCbInfo.isConUp == IDS_FALSE)
      {
         cout<<"Backup Connection is down"<<endl;
         LLOG(0,1,"Backup Connection is down");

      }

   }
   else
   {
      cout<<"Unknown Callback Type ";
      ELOG(0,1,"Unknown Callback Type");
   }
}


int DiametriqInterface::sendDiaAppMsg(diameter::Command& impl, ITS_UINT sesIdx)
{
   logErrorStatistics(impl);
   return g_smplApi->Send(impl, sesIdx, sendAppId); 
}

int DiametriqInterface::allocateSession(ITS_UINT appId, ITS_UINT &sessIdx, std::string &sessString)
{
   return g_smplApi->AllocateSessionIndex(appId,sessIdx,sessString);
}

void DiametriqInterface::releaseSession(std::string &sessString, ITS_UINT sessIdx)
{
   g_smplApi->ReleaseSession(sessString, sessIdx);
}

bool DiametriqInterface::isDccaEnabled()
{
   return g_smplApi->IsDccaEnabled();
}


string DiametriqInterface::getSessionId(const diameter::CommandImpl *p_commandImpl)
{
   string l_sessionId;
   int l_sessionIdReturn = p_commandImpl->getAvpValue(263, 0, &l_sessionId, UTF8StringType);
   if(0 == l_sessionIdReturn)
   {
      DLOG(0,1,"retrieved session id");
   }
   else
   {
      ELOG(0,1,"Unable to retrieve session id");
   }
   return l_sessionId;
}

int DiametriqInterface::handleDiaAppMsg(const diameter::CommandImpl *impl, unsigned int &sIdx, struct timeval p_oldTv, struct timeval p_pTv, struct timeval p_rTv)
{
   DLOG(0,1,"handleDiaAppMsg called");
   try
   {
      HLRStatisticsInitializer::instance()->logStatistics(g_diamMessageIndex);

      if(impl->isProxyable())
      {
         HLRStatisticsInitializer::instance()->logStatistics(g_diamProxyableIndex);
      }
      if(impl->isRetransmit())
      {
         HLRStatisticsInitializer::instance()->logStatistics(g_diamRetransmitIndex);
      }
      // Process the commands based on the command code.
      if(impl->isError())
      {
         LLOG(0,1,"Calling handleErrorResponse");
         HLRStatisticsInitializer::instance()->logStatistics(g_diamErrorIndex);
         handleErrorResponse(impl, sIdx);
      }
      else
      {
         if(impl->isRequest())
         {
            HLRStatisticsInitializer::instance()->logStatistics(g_diamRequestIndex);
            HLRStatisticsInitializer::instance()->logStatistics(g_incomingDiameterReqIndex);
         }
         else
         {
            HLRStatisticsInitializer::instance()->logStatistics(g_diamAnswerIndex);
         }

         TLOG(0,1,"Checking Command Code %d, Index %d", impl->getCommandCode(), sIdx);

         if(impl->getCommandCode()>0)
         {
            if(impl->isRequest())
            {
               //g_CurrentActiveTransactions++; //Commented in 2.0.0.0 Rev2
               g_CurrentActiveTransactions++; //UnCommented in 2.0.24.0
               if( ( (impl->getCommandCode() >= DIAM_COMM_CODE_S6A_S6D_ULR_ULA) && 
                        (impl->getCommandCode() <= DIAM_COMM_CODE_S6A_S6D_NOR_NOA)
                   ) ||
                     (impl->getCommandCode() == DIAM_COMM_CODE_SLH_RIR_RIA)||
                     ((impl->getCommandCode() >= DIAM_COMM_CODE_CX_DX_UAR_UAA) && (impl->getCommandCode() <=DIAM_COMM_CODE_SH_PNR_PNA))
                     //|| 
                     //((impl->getCommandCode() >= DIAM_COMM_CODE_SWX_MAR_MAA) && (impl->getCommandCode() <= DIAM_COMM_CODE_SWX_PPR_PPA))
                 )
               {
                  if((DIAM_COMM_CODE_SLH_RIR_RIA == impl->getCommandCode()) )
                  {
                     HLRStatisticsInitializer::instance()->logStatistics(m_dsi.m_RespondingCommands[8].m_TotalCount);
                  }
                  /** added for Cx interface */
                  else if(((impl->getCommandCode() >= DIAM_COMM_CODE_CX_DX_UAR_UAA) && (impl->getCommandCode() <= DIAM_COMM_CODE_SH_PNR_PNA)))
                  {
		     if (m_recvAppId != DIAM_APP_ID_SWX)
		     {
                     HLRStatisticsInitializer::instance()->logStatistics(m_dsi.m_RespondingCommands[impl->getCommandCode()-290].m_TotalCount);
		     }
		     else
		     {	
                     HLRStatisticsInitializer::instance()->logStatistics(m_dsi.m_RespondingCommands[impl->getCommandCode()-280].m_TotalCount);
		     }		
                  }
                  else
                  {

                     HLRStatisticsInitializer::instance()->logStatistics(m_dsi.m_RespondingCommands[impl->getCommandCode()-DIAM_COMM_CODE_S6A_S6D_ULR_ULA].m_TotalCount);
                  }
               }
               if(false == g_mm.isPresent(MSG_TYPE_DIAMETER, impl->getCommandCode()))
               {
                  CLOG(0,1,"Command Code %d not served", impl->getCommandCode());
                  sendErrorResponse(impl, sIdx, DIAM_RESULT_CODE_UNABLE_TO_COMPLY);
                  delete(impl);
                  return 0;
               }
#if 0
               if(false == DiameterConstants::isApplIdCommandCodeCombValid(m_regAppId, impl->getCommandCode()))
               {
                  CLOG(0,1,"Command Code %d and ApplId %d combination is not valid", impl->getCommandCode(), m_regAppId);
                  sendErrorResponse(impl, sIdx, DIAM_RESULT_CODE_UNABLE_TO_COMPLY);
                  delete(impl);
                  return 0;
               }
#endif
            }
         }

         EDiameterEventType l_det = DIAM_EVENT_UNKNOWN;
         switch (impl->getCommandCode())
         {
            /*TODO: Do we need to handle any base messages here?
            // Handle Base Messages
            case BASE_RA_MSG_CMD_CODE:
            case BASE_ST_MSG_CMD_CODE:
            case BASE_AS_MSG_CMD_CODE:
            handleBaseMessages(impl,sIdx);
            break;
            */

            default:
               char l_type;
               std::string l_sessionId = (char*)getSessionId((diameter::CommandImpl*)impl).c_str();
               if(0 == impl->getCommandCode())
               {
                  WLOG(0,1,"CommandCode is ZERO");
                  l_type='E';
                  l_det=DIAM_EVENT_ERROR_SOMETHING_WEIRD;
                  //if(0 == impl->getCommandCode())
                  //{
                  //   CLOG(0,1,"Calling releaseSession");
                  //   releaseSession(l_sessionId, sIdx);
                  //}
               }
               else if(impl->isRequest())
               {
                  l_type='R';
                  l_det=DIAM_EVENT_REQUEST;
               }
               else
               {
                  l_type='A';
                  l_det=DIAM_EVENT_ANSWER;
               }
               bool l_flag=false;
               bool l_outputFlag=false;
               if(('C' == g_OtherConfigData->m_dcd.m_diamterPduPrintType) || 
                     ('L' == g_OtherConfigData->m_dcd.m_diamterPduPrintType) ||
                     ('B' == g_OtherConfigData->m_dcd.m_diamterPduPrintType)
                 )
               {
                  l_outputFlag=true;
               }
               char l_diameterPduBuffer[32000+1];
               l_flag = DiameterConstants::printCommands(l_type, (EDiameterCommandCode)impl->getCommandCode(), (const void *)impl,
                     l_diameterPduBuffer, sizeof(l_diameterPduBuffer), l_outputFlag, m_recvAppId);
	       if(false == l_flag)
               {
                  WLOG(0,1,"printCommands returned false. Typecasting failed.");
               }
               if(('C' == g_OtherConfigData->m_dcd.m_diamterPduPrintType) || ('B' == g_OtherConfigData->m_dcd.m_diamterPduPrintType))
               {
                  printf("\nReceived [%s] [%s]\n", (char*)l_sessionId.c_str(), l_diameterPduBuffer);
               }
               if(('L' == g_OtherConfigData->m_dcd.m_diamterPduPrintType) || ('B' == g_OtherConfigData->m_dcd.m_diamterPduPrintType))
               {
                  LLOG(1,1,"Received DIAM_PDU [%s] [%s]", (char*)l_sessionId.c_str(), l_diameterPduBuffer);
               }

               if((impl->isRequest()) && (true == g_MplManager.overload(MSG_TYPE_DIAMETER, 0, impl->getCommandCode())))
               {
                  LLOG(0,1,"Rejecting the diameter message");
                  sendErrorResponse(impl, sIdx, DIAM_RESULT_CODE_RESOURCES_EXCEEDED);
                  delete(impl);
               }
               else
               {
                  DLOG(0,1,"Newing DiameterMsg");

                  DiameterMsg *l_msg = new DiameterMsg((char*)l_sessionId.c_str(), l_det, (EDiameterCommandCode)impl->getCommandCode());
		  LLOG(0,0,"Inside handleDiaAppMsg m_oldTv1: %ld.%ld m_pTv1: %ld.%ld m_rTv1: %ld.%ld",p_oldTv.tv_sec, p_oldTv.tv_usec, p_pTv.tv_sec, p_pTv.tv_usec,p_rTv.tv_sec, p_rTv.tv_usec);
		  l_msg->m_oldTv2 = p_oldTv;
		  l_msg->m_pTv2 = p_pTv;
		  l_msg->m_rTv2 = p_rTv;
                  l_msg->m_sessionIndex = sIdx;
                  l_msg->m_cmd = (void*)impl;
                  l_msg->m_applicationId = m_recvAppId;
                  if(l_msg->m_cmd == NULL)
		  {
			WLOG(0,0,"l_msg->m_cmd is nulllll");
		  }	       
                  if( (NULL != l_msg->m_cmd) && (true == l_flag))
                  {
                     l_msg->m_allocatedFlag = true;
                  }
                  else
                  {
                     WLOG(0,1,"l_msg->m_cmd is null");
                  }
                  /*if(m_recvAppId == 16777265)
                  {
                     LLOG(0,0,"Adding opcode value with 90 for SWX messages");
                     l_msg->m_commandCode = 90 + l_msg->m_commandCode;
                  }*/
                  g_esc.recvMsg(l_msg);
               }
               break;

         }
      }
   }
   catch (NoSuchAttributeException e)
   {
      ELOG(0,1,"Exception Caught: %s , Error Cause: %s ", e.name(), e.what());
   }
   catch (WrongCommandTypeException e)
   {
      ELOG(0,1,"Exception Caught: %s , Error Cause: %s ", e.name(), e.what());
   }
   catch (UnknownTypeException e)
   {
      ELOG(0,1,"Exception Caught: %s , Error Cause: %s ", e.name(), e.what());
   }
   catch (CodecException e)
   {
      ELOG(0,1,"Exception Caught: %s , Error Cause: %s ", e.name(), e.what());
   }
   catch (...)
   {
      ELOG(0,1,"Unknown Exception Caught");
   }

   return ITS_SUCCESS;
}

DiametriqInterface::DiametriqInterface()
{
   m_regAppId=0;
   m_diameterStackRegisteredFlag=false;
   m_diameterMessagesQueue=NULL;
   m_initializedFlag=false;
   m_recvAppId=0;
}

DiametriqInterface::~DiametriqInterface()
{
}

bool initializeDiametriqInterfaceStatistics(StatisticsGenerator *p_sg)
{
   for(int l_i=DIAM_COMM_CODE_S6A_S6D_ULR_ULA-DIAM_COMM_CODE_S6A_S6D_ULR_ULA; 
         l_i<=DIAM_COMM_CODE_S6A_S6D_NOR_NOA-DIAM_COMM_CODE_S6A_S6D_ULR_ULA; 
         l_i++)
   {
      g_di.m_dsi.m_RespondingCommands[l_i].m_TotalCount   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, DiameterConstants::getDiameterCommandCodeChar(l_i+DIAM_COMM_CODE_S6A_S6D_ULR_ULA), "R-Tot", 'L');
      g_di.m_dsi.m_RespondingCommands[l_i].m_SuccessCount = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, DiameterConstants::getDiameterCommandCodeChar(l_i+DIAM_COMM_CODE_S6A_S6D_ULR_ULA), "R-Suc", 'L');
      g_di.m_dsi.m_InitiatingCommands[l_i].m_TotalCount   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, DiameterConstants::getDiameterCommandCodeChar(l_i+DIAM_COMM_CODE_S6A_S6D_ULR_ULA), "I-Tot", 'L');
      g_di.m_dsi.m_InitiatingCommands[l_i].m_SuccessCount = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, DiameterConstants::getDiameterCommandCodeChar(l_i+DIAM_COMM_CODE_S6A_S6D_ULR_ULA), "I-Suc", 'L');
   }
   g_di.m_dsi.m_RespondingCommands[8].m_TotalCount   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, DiameterConstants::getDiameterCommandCodeChar(DIAM_COMM_CODE_SLH_RIR_RIA), "R-Tot", 'L');
   g_di.m_dsi.m_RespondingCommands[8].m_SuccessCount = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, DiameterConstants::getDiameterCommandCodeChar(DIAM_COMM_CODE_SLH_RIR_RIA), "R-Suc", 'L');
   g_di.m_dsi.m_InitiatingCommands[8].m_TotalCount   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, DiameterConstants::getDiameterCommandCodeChar(DIAM_COMM_CODE_SLH_RIR_RIA), "I-Tot", 'L');
   g_di.m_dsi.m_InitiatingCommands[8].m_SuccessCount = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, DiameterConstants::getDiameterCommandCodeChar(DIAM_COMM_CODE_SLH_RIR_RIA), "I-Suc", 'L');
   /** commencing from 10th index for UAR to PNR*/
   /** for CX interface and SH */
   for(int l_i= 10; l_i<= 19; l_i++)
   {
      g_di.m_dsi.m_RespondingCommands[l_i].m_TotalCount   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, DiameterConstants::getDiameterCommandCodeChar(l_i+290), "R-Tot", 'L');
      g_di.m_dsi.m_RespondingCommands[l_i].m_SuccessCount = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, DiameterConstants::getDiameterCommandCodeChar(l_i+290), "R-Suc", 'L');
      g_di.m_dsi.m_InitiatingCommands[l_i].m_TotalCount   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, DiameterConstants::getDiameterCommandCodeChar(l_i+290), "I-Tot", 'L');
      g_di.m_dsi.m_InitiatingCommands[l_i].m_SuccessCount = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, DiameterConstants::getDiameterCommandCodeChar(l_i+290), "I-Suc", 'L');
   }
   /* For SWX Inerface */ 	
   for(int l_i= 20; l_i<= 25; l_i++)
   {
	   if((l_i != 20) && (l_i != 22))
	   {

		   char l_shortCommand[50+1];
		   memset(l_shortCommand,'\0',sizeof(l_shortCommand));
		   snprintf(l_shortCommand, sizeof(l_shortCommand), "%s_SWx", DiameterConstants::getDiameterCommandCodeChar(l_i+280));
		   g_di.m_dsi.m_RespondingCommands[l_i].m_TotalCount   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, l_shortCommand, "R-Tot", 'L');
		   g_di.m_dsi.m_RespondingCommands[l_i].m_SuccessCount = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, l_shortCommand, "R-Suc", 'L');
		   g_di.m_dsi.m_InitiatingCommands[l_i].m_TotalCount   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, l_shortCommand, "I-Tot", 'L');
		   g_di.m_dsi.m_InitiatingCommands[l_i].m_SuccessCount = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, l_shortCommand, "I-Suc", 'L');
	   }
   }
   g_di.m_dsi.m_CER                          = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, "CER",                           "", 'M');
   g_di.m_dsi.m_CEA                          = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, "CEA",                           "", 'M');
   g_di.m_dsi.m_DWR                          = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, "DWR",                           "", 'M');
   g_di.m_dsi.m_DWA                          = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, "DWA",                           "", 'M');
   g_di.m_dsi.m_DPR                          = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, "DPR",                           "", 'M');
   g_di.m_dsi.m_DPA                          = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, "DPA",                           "", 'M');
   g_di.m_dsi.m_DISC                         = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, "DISC",                          "", 'M');
   g_di.m_dsi.m_TIME_OUT                     = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, "TIME_OUT",                      "", 'M');
   g_di.m_dsi.m_AUTH_LIFE_TIME_OUT           = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, "AUTH_LIFE_TIME_OUT",            "", 'M');
   g_di.m_dsi.m_AUTH_GRACE_TIME_OUT          = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, "AUTH_GRACE_TIME_OUT",           "", 'M');
   g_di.m_dsi.m_CORRUPTED_MSG                = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, "CORRUPTED_MSG",                 "", 'M');
   g_di.m_dsi.m_ACCT_INTERIM_TIME_OUT        = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, "ACCT_INTERIM_TIME_OUT",         "", 'M');
   g_di.m_dsi.m_FAILOVER                     = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, "FAILOVER",                      "", 'M');
   g_di.m_dsi.m_FAILBACK                     = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, "FAILBACK",                      "", 'M');
   g_di.m_dsi.m_DIAM_REGISTRATION_FAILED     = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, "DIAM_REGISTRATION_FAILED",      "", 'M');
   g_di.m_dsi.m_DIAM_REGISTRATION_SUCCESS    = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, "DIAM_REGISTRATION_SUCCESS",     "", 'M');
   g_di.m_dsi.m_DEREGISTER_ACK_MSG           = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, "DEREGISTER_ACK_MSG",            "", 'M');
   g_di.m_dsi.m_DIASERVER_NOTIFY_MSG         = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, "DIASERVER_NOTIFY_MSG",          "", 'M');
   g_di.m_dsi.m_GLOBAL_UNIQ_ADDR_ACK_MSG     = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, "GLOBAL_UNIQ_ADDR_ACK_MSG",      "", 'M');

   g_diamSuspendIndex                   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, "DIAM_MSGS_SUSPENDED",           "", 'M');
   g_diamResumeIndex                    = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, "DIAM_MSGS_RESUMED",             "", 'M');

   g_diamMessageIndex                   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, "DIAM_MSG_RCVD_TOTAL(R+A+E)",    "", 'M');
   g_diamRequestIndex                   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, "DIAM_MSG_RCVD_REQUEST",         "", 'M');
   g_diamAnswerIndex                    = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, "DIAM_MSG_RCVD_ANSWER",          "", 'M');
   g_diamErrorIndex                     = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, "DIAM_MSG_RCVD_ERROR",           "", 'M');
   g_diamProxyableIndex                 = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, "DIAM_MSG_RCVD_BIT_PROXYABLE",   "", 'M');
   g_diamRetransmitIndex                = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, "DIAM_MSG_RCVD_BIT_RE_TRANSMIT", "", 'M');


   for(int l_i=DIAM_COMM_CODE_S6A_S6D_ULR_ULA-DIAM_COMM_CODE_S6A_S6D_ULR_ULA; l_i<=DIAM_COMM_CODE_S6A_S6D_NOR_NOA-DIAM_COMM_CODE_S6A_S6D_ULR_ULA; l_i++)
   {
      char l_shortCommand[3+1];
      snprintf(l_shortCommand, sizeof(l_shortCommand), "%s", getShortCommandCode(l_i+DIAM_COMM_CODE_S6A_S6D_ULR_ULA));
      for(map<int,string>::iterator l_itr=DiameterConstants::m_resultCodeCharMap.begin(); 
            l_itr!=DiameterConstants::m_resultCodeCharMap.end();
            l_itr++)
      {
         if((l_itr->first/1000) != 2)
            //if( (l_itr->first < DIAM_RESULT_CODE_SUCCESS) || (l_itr->first > DIAM_RESULT_CODE_SUCCESS_MAX_RANGE))
         {
            char l_char[50+1];
            snprintf(l_char, sizeof(l_char), "%04d-%s", l_itr->first, (char*)l_itr->second.c_str());
            DiamErrorCodeStats l_decs;
            memset(&l_decs, '\0', sizeof(l_decs));
            l_decs.m_total   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, l_shortCommand, l_char, 'N');
            char l_fullChar[50+1];
            snprintf(l_fullChar, sizeof(l_fullChar), "%s:%s", l_shortCommand, l_char);
            g_diamErrorMapping.insert(std::pair<string,DiamErrorCodeStats>(l_fullChar, l_decs));
         }
      }
      DiamErrorCodeStats l_decs;
      memset(&l_decs, '\0', sizeof(l_decs));
      char l_fullChar[50+1];
      snprintf(l_fullChar, sizeof(l_fullChar), "%s:%s", l_shortCommand, "DiamResultCodeUnknown");
      l_decs.m_total   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, l_shortCommand, "DiamResultCodeUnknown", 'N');
      g_diamErrorMapping.insert(std::pair<string,DiamErrorCodeStats>(l_fullChar, l_decs));
      for(map<int,string>::iterator l_itr=DiameterConstants::m_experimentalResultCodeCharMap.begin(); 
            l_itr!=DiameterConstants::m_experimentalResultCodeCharMap.end();
            l_itr++)
      {
         if((l_itr->first/1000) != 2)
         {
            char l_char[50+1];
            snprintf(l_char, sizeof(l_char), "%04d-%s", l_itr->first, (char*)l_itr->second.c_str());
            DiamErrorCodeStats l_decs;
            memset(&l_decs, '\0', sizeof(l_decs));
            l_decs.m_total   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, l_shortCommand, l_char, 'N');
            char l_fullChar[50+1];
            snprintf(l_fullChar, sizeof(l_fullChar), "%s:%s", l_shortCommand, l_char);
            g_diamErrorMapping.insert(std::pair<string,DiamErrorCodeStats>(l_fullChar, l_decs));
         }
      }
      memset(&l_decs, '\0', sizeof(l_decs));
      l_decs.m_total   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, l_shortCommand, "DiamExpResultCodeUnknown", 'N');
      snprintf(l_fullChar, sizeof(l_fullChar), "%s:%s", l_shortCommand, "DiamExpResultCodeUnknown");
      g_diamErrorMapping.insert(std::pair<string,DiamErrorCodeStats>(l_fullChar, l_decs));
   }
   for(int l_i=DIAM_COMM_CODE_SLH_RIR_RIA; l_i<=DIAM_COMM_CODE_SLH_RIR_RIA; l_i++)
   {
      char l_shortCommand[3+1];
      snprintf(l_shortCommand, sizeof(l_shortCommand), "%s", getShortCommandCode(DIAM_COMM_CODE_SLH_RIR_RIA));
      for(map<int,string>::iterator l_itr=DiameterConstants::m_resultCodeCharMap.begin(); 
            l_itr!=DiameterConstants::m_resultCodeCharMap.end();
            l_itr++)
      {
         if((l_itr->first/1000) != 2)
            //if( (l_itr->first < DIAM_RESULT_CODE_SUCCESS) || (l_itr->first > DIAM_RESULT_CODE_SUCCESS_MAX_RANGE))
         {
            char l_char[50+1];
            snprintf(l_char, sizeof(l_char), "%04d-%s", l_itr->first, (char*)l_itr->second.c_str());
            DiamErrorCodeStats l_decs;
            memset(&l_decs, '\0', sizeof(l_decs));
            l_decs.m_total   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, l_shortCommand, l_char, 'N');
            char l_fullChar[50+1];
            snprintf(l_fullChar, sizeof(l_fullChar), "%s:%s", l_shortCommand, l_char);
            g_diamErrorMapping.insert(std::pair<string,DiamErrorCodeStats>(l_fullChar, l_decs));
         }
      }
      DiamErrorCodeStats l_decs;
      memset(&l_decs, '\0', sizeof(l_decs));
      char l_fullChar[50+1];
      snprintf(l_fullChar, sizeof(l_fullChar), "%s:%s", l_shortCommand, "DiamResultCodeUnknown");
      l_decs.m_total   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, l_shortCommand, "DiamResultCodeUnknown", 'N');
      g_diamErrorMapping.insert(std::pair<string,DiamErrorCodeStats>(l_fullChar, l_decs));
      for(map<int,string>::iterator l_itr=DiameterConstants::m_experimentalResultCodeCharMap.begin(); 
            l_itr!=DiameterConstants::m_experimentalResultCodeCharMap.end();
            l_itr++)
      {
         if((l_itr->first/1000) != 2)
         {
            char l_char[50+1];
            snprintf(l_char, sizeof(l_char), "%04d-%s", l_itr->first, (char*)l_itr->second.c_str());
            DiamErrorCodeStats l_decs;
            memset(&l_decs, '\0', sizeof(l_decs));
            l_decs.m_total   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, l_shortCommand, l_char, 'N');
            char l_fullChar[50+1];
            snprintf(l_fullChar, sizeof(l_fullChar), "%s:%s", l_shortCommand, l_char);
            g_diamErrorMapping.insert(std::pair<string,DiamErrorCodeStats>(l_fullChar, l_decs));
         }
      }
      memset(&l_decs, '\0', sizeof(l_decs));
      l_decs.m_total   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, l_shortCommand, "DiamExpResultCodeUnknown", 'N');
      snprintf(l_fullChar, sizeof(l_fullChar), "%s:%s", l_shortCommand, "DiamExpResultCodeUnknown");
      g_diamErrorMapping.insert(std::pair<string,DiamErrorCodeStats>(l_fullChar, l_decs));
   }

   for(int l_i=DIAM_COMM_CODE_SH_UDR_UDA-DIAM_COMM_CODE_SH_UDR_UDA; l_i<=DIAM_COMM_CODE_SH_PNR_PNA-DIAM_COMM_CODE_SH_UDR_UDA; l_i++)
   {
      DLOG(0,0,"Logging SH Message ErrorStatistics");
      char l_shortCommand[3+1];
      if(l_i != 1)
      {
         DLOG(0,0,"Calling getShortCommandCode as DiamCode other than 307");
         snprintf(l_shortCommand, sizeof(l_shortCommand), "%s", getShortCommandCode(l_i+DIAM_COMM_CODE_SH_UDR_UDA));
      }
      else
      {
         DLOG(0,0,"Not Calling getShortCommandCode as DiamCode 307");
      }
      for(map<int,string>::iterator l_itr=DiameterConstants::m_resultCodeCharMap.begin(); 
            l_itr!=DiameterConstants::m_resultCodeCharMap.end();
            l_itr++)
      {
         if((l_itr->first/1000) != 2)
            //if( (l_itr->first < DIAM_RESULT_CODE_SUCCESS) || (l_itr->first > DIAM_RESULT_CODE_SUCCESS_MAX_RANGE))
         {
            char l_char[50+1];
            snprintf(l_char, sizeof(l_char), "%04d-%s", l_itr->first, (char*)l_itr->second.c_str());
            DiamErrorCodeStats l_decs;
            memset(&l_decs, '\0', sizeof(l_decs));
            if(l_i != 1)
               l_decs.m_total   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, l_shortCommand, l_char, 'N');
            char l_fullChar[50+1];
            snprintf(l_fullChar, sizeof(l_fullChar), "%s:%s", l_shortCommand, l_char);
            g_diamErrorMapping.insert(std::pair<string,DiamErrorCodeStats>(l_fullChar, l_decs));
         }
      }
      DiamErrorCodeStats l_decs;
      memset(&l_decs, '\0', sizeof(l_decs));
      char l_fullChar[50+1];
      snprintf(l_fullChar, sizeof(l_fullChar), "%s:%s", l_shortCommand, "DiamResultCodeUnknown");
      if(l_i != 1)
         l_decs.m_total   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, l_shortCommand, "DiamResultCodeUnknown", 'N');
      g_diamErrorMapping.insert(std::pair<string,DiamErrorCodeStats>(l_fullChar, l_decs));
      for(map<int,string>::iterator l_itr=DiameterConstants::m_experimentalResultCodeCharMap.begin(); 
            l_itr!=DiameterConstants::m_experimentalResultCodeCharMap.end();
            l_itr++)
      {
         if((l_itr->first/1000) != 2)
         {
            char l_char[50+1];
            snprintf(l_char, sizeof(l_char), "%04d-%s", l_itr->first, (char*)l_itr->second.c_str());
            DiamErrorCodeStats l_decs;
            memset(&l_decs, '\0', sizeof(l_decs));
            if(l_i != 1)
               l_decs.m_total   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, l_shortCommand, l_char, 'N');
            char l_fullChar[50+1];
            snprintf(l_fullChar, sizeof(l_fullChar), "%s:%s", l_shortCommand, l_char);
            g_diamErrorMapping.insert(std::pair<string,DiamErrorCodeStats>(l_fullChar, l_decs));
         }
      }
      memset(&l_decs, '\0', sizeof(l_decs));
      if(l_i != 1)
         l_decs.m_total   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, l_shortCommand, "DiamExpResultCodeUnknown", 'N');
      snprintf(l_fullChar, sizeof(l_fullChar), "%s:%s", l_shortCommand, "DiamExpResultCodeUnknown");
      g_diamErrorMapping.insert(std::pair<string,DiamErrorCodeStats>(l_fullChar, l_decs));
      for(map<int,string>::iterator l_itr=DiameterConstants::m_appExperimentalResultCodeCharMapSh.begin(); 
            l_itr!=DiameterConstants::m_appExperimentalResultCodeCharMapSh.end();
            l_itr++)
      {
         if((l_itr->first/1000) != 2)
         {
            char l_char[50+1];
            snprintf(l_char, sizeof(l_char), "%04d-%s", l_itr->first, (char*)l_itr->second.c_str());
            DiamErrorCodeStats l_decs;
            memset(&l_decs, '\0', sizeof(l_decs));
            if(l_i != 1)
               l_decs.m_total   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, l_shortCommand, l_char, 'N');
            char l_fullChar[50+1];
            snprintf(l_fullChar, sizeof(l_fullChar), "%s:%s", l_shortCommand, l_char);
            g_diamErrorMapping.insert(std::pair<string,DiamErrorCodeStats>(l_fullChar, l_decs));
         }
      }
   }

   for(int l_i=DIAM_COMM_CODE_CX_DX_UAR_UAA-DIAM_COMM_CODE_CX_DX_UAR_UAA; l_i<=DIAM_COMM_CODE_CX_DX_PPR_PPA-DIAM_COMM_CODE_CX_DX_UAR_UAA; l_i++)
   {
      char l_shortCommand[3+1];
      snprintf(l_shortCommand, sizeof(l_shortCommand), "%s", getShortCommandCode(l_i+DIAM_COMM_CODE_CX_DX_UAR_UAA));
      for(map<int,string>::iterator l_itr=DiameterConstants::m_resultCodeCharMap.begin(); 
            l_itr!=DiameterConstants::m_resultCodeCharMap.end();
            l_itr++)
      {
         if( ((l_itr->first/1000) != 2) || (l_itr->first == 2002) )
            //if( (l_itr->first < DIAM_RESULT_CODE_SUCCESS) || (l_itr->first > DIAM_RESULT_CODE_SUCCESS_MAX_RANGE))
         {
            char l_char[50+1];
            snprintf(l_char, sizeof(l_char), "%04d-%s", l_itr->first, (char*)l_itr->second.c_str());
            DiamErrorCodeStats l_decs;
            memset(&l_decs, '\0', sizeof(l_decs));
            l_decs.m_total   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, l_shortCommand, l_char, 'N');
            char l_fullChar[50+1];
            snprintf(l_fullChar, sizeof(l_fullChar), "%s:%s", l_shortCommand, l_char);
            g_diamErrorMapping.insert(std::pair<string,DiamErrorCodeStats>(l_fullChar, l_decs));
         }
      }
      DiamErrorCodeStats l_decs;
      memset(&l_decs, '\0', sizeof(l_decs));
      char l_fullChar[50+1];
      snprintf(l_fullChar, sizeof(l_fullChar), "%s:%s", l_shortCommand, "DiamResultCodeUnknown");
      l_decs.m_total   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, l_shortCommand, "DiamResultCodeUnknown", 'N');
      g_diamErrorMapping.insert(std::pair<string,DiamErrorCodeStats>(l_fullChar, l_decs));
      for(map<int,string>::iterator l_itr=DiameterConstants::m_experimentalResultCodeCharMap.begin(); 
            l_itr!=DiameterConstants::m_experimentalResultCodeCharMap.end();
            l_itr++)
      {
         if((l_itr->first/1000) != 2)
         {
            char l_char[50+1];
            snprintf(l_char, sizeof(l_char), "%04d-%s", l_itr->first, (char*)l_itr->second.c_str());
            DiamErrorCodeStats l_decs;
            memset(&l_decs, '\0', sizeof(l_decs));
            l_decs.m_total   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, l_shortCommand, l_char, 'N');
            char l_fullChar[50+1];
            snprintf(l_fullChar, sizeof(l_fullChar), "%s:%s", l_shortCommand, l_char);
            g_diamErrorMapping.insert(std::pair<string,DiamErrorCodeStats>(l_fullChar, l_decs));
         }
      }
      memset(&l_decs, '\0', sizeof(l_decs));
      l_decs.m_total   = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER, l_shortCommand, "DiamExpResultCodeUnknown", 'N');
      snprintf(l_fullChar, sizeof(l_fullChar), "%s:%s", l_shortCommand, "DiamExpResultCodeUnknown");
      g_diamErrorMapping.insert(std::pair<string,DiamErrorCodeStats>(l_fullChar, l_decs));
   }

   LLOG(0,0,"g_diamErrorMapping size:%d", g_diamErrorMapping.size());
   return true;
}

bool DiametriqInterface::initialize(int p_applicationId)
{
   try
   {
      m_diameterMessagesQueue = new MessageQueue(QUEUE_TYPE_NON_BLOCKING, QUEUE_PERSISTENCE_TYPE_NON_PERSISTENT);
      if(NULL == m_diameterMessagesQueue)
      {
         ELOG(0,1,"Unable to create diameterMessagesQueue");
         return false;
      }
      if(false == m_diameterMessagesQueue->initialize())
      {
         ELOG(0,1,"Unable to initialize the Diameter Message Queue");
         return false;
      }

      if('R' == g_OtherConfigData->m_dcd.m_connectionType)
      {
         TLOG(0,1,"Setting the ifRedundancy to ITS_TRUE");
         ifRedundancy = ITS_TRUE;
      }

      m_regAppId = p_applicationId;

      pthread_t thread, threadPrint;
      
      //6.3.8.0C start
      if(1 == g_OtherConfigData->m_dcd.m_DiastackLoggingFlag)
      {
         LLOG(0,0,"Diastack Logging Flag is enabled");
         g_smplApi = new IDSCLApi(g_nlo);
         if("none" != g_OtherConfigData->m_dcd.m_logLevel)
         {
            LLOG(0,0,"Diastack LogLevel is [%s]",g_OtherConfigData->m_dcd.m_logLevel.c_str());
            //g_smplApi = new IDSCLApi(g_nlo);
            g_smplApi->SetLogLevel(g_OtherConfigData->m_dcd.m_logLevel);
            g_smplApi->SetAppLoggingFlags(g_OtherConfigData->m_dcd.m_LogsForDebugging);
         }
         else
         {
            ELOG(0,1,"DIASTACK_LOG_LEVEL should be D/W/E/C");
         }
         // Re-Register call back
         g_smplApi->RegisterCallback(CallBackFunc);
         g_smplApi->InitDiaDictParser();
      }
      else
      {
         LLOG(0,0,"Diastack Logging Flag is not enabled");
         g_smplApi = new IDSCLApi;
         std::string logLevel;
         IDSCLApi smplApi;
         // Setting the log level, from the command line argument
         logLevel = "critical";
         smplApi.SetLogLevel(logLevel);
         // Re-Register call back
         smplApi.RegisterCallback(CallBackFunc);
         smplApi.InitDiaDictParser();
      }
      //6.3.8.0C end


      if (0 != pthread_mutex_init(&g_diamSusp_mutex, NULL))
      {
         ELOG(0,1,"Unable to initialize the mutex");
         return false;
      }

      /* Send thread */
      if(0 != pthread_create(&threadPrint, NULL, PrintMenu, NULL))
      {
         ELOG(0,1,"Unable to create Connector thread");
         return false;
      }

      /* Receive thread */
      if(0 != pthread_create(&thread, NULL, Recieve, this))
      {
         ELOG(0,1,"Unable to create Recieve thread");
         return false;
      }

      //return PrintMenu(NULL);
      m_initializedFlag=true;
      g_StackRegisteredTime = time(NULL);
      LLOG(0,0,"Initilaization with Diametriq Stack done");
      return true;
   }
   catch (...)
   {
      ELOG(0,1,"Exception occurred in initialization");
      return false;
   }
   return true;
}


int DiametriqInterface::handleBaseMessages(const diameter::CommandImpl *impl, unsigned int &sIdxBase)
{
   //ITS_BOOLEAN isProxy;
   ITS_INT ret = !(ITS_SUCCESS);
   //ITS_INT count=0;
   //Command *cmd = NULL;

   DLOG(0,1,"Base Diameter Messages Received");


   // Process the commands based on the command code.
   switch (impl->getCommandCode())
   {
      case BASE_CE_MSG_CMD_CODE:
         if(impl->isRequest())
         {
            CapabilitiesExchangeRequest cereq(*impl);
            /*
               if('C' == g_OtherConfigData->m_dcd.m_diamterPduPrintType)
               cout << endl << "Capabilties Exchange Request Received "
               << cereq << endl;
               */
            printPdu(&cereq, "Received");
            HLRStatisticsInitializer::instance()->logStatistics(m_dsi.m_CER);

         }
         else
         {
            CapabilitiesExchangeAnswer ceans(*impl);
            /*
               if('C' == g_OtherConfigData->m_dcd.m_diamterPduPrintType)
               cout << endl << "Capabilties Exchange Answer Received"
               << ceans << endl;
               */
            printPdu(&ceans, "Received");
            HLRStatisticsInitializer::instance()->logStatistics(m_dsi.m_CEA);
         }
         break;
      case BASE_DW_MSG_CMD_CODE:
         if(impl->isRequest())
         {
            DeviceWatchdogRequest dwreq(*impl);
            /*
               if('C' == g_OtherConfigData->m_dcd.m_diamterPduPrintType)
               cout << endl << "Device Watch Dog Request Received"
               << dwreq << endl;
               */
            printPdu(&dwreq, "Received");
            HLRStatisticsInitializer::instance()->logStatistics(m_dsi.m_DWR);
         }
         else
         {
            DeviceWatchdogAnswer dwans(*impl);
            /*
               if('C' == g_OtherConfigData->m_dcd.m_diamterPduPrintType)
               cout << endl <<"Device Watch Dog Answer Received"
               << dwans << endl;
               */
            printPdu(&dwans, "Received");
            HLRStatisticsInitializer::instance()->logStatistics(m_dsi.m_DWA);
         }
         break;
      case BASE_DP_MSG_CMD_CODE:
         if(impl->isRequest())
         {
            DisconnectPeerRequest dpreq(*impl);
            /*
               if('C' == g_OtherConfigData->m_dcd.m_diamterPduPrintType)
               cout << endl << "Disconnect Peer Request Received"
               << dpreq << endl;
               */
            printPdu(&dpreq, "Received");
            HLRStatisticsInitializer::instance()->logStatistics(m_dsi.m_DPR);
         }
         else
         {
            DisconnectPeerAnswer dpans(*impl);
            /*
               if('C' == g_OtherConfigData->m_dcd.m_diamterPduPrintType)
               cout << endl <<"Disconnect Peer Answer Received"
               << dpans << endl;
               */
            printPdu(&dpans, "Received");
            HLRStatisticsInitializer::instance()->logStatistics(m_dsi.m_DPA);
         }
         break;
      default:
         WLOG(0,1,"Unknown Base Protocol Message Received [%d]", impl->getCommandCode());
         break;
   }

   return ret;
}

//End of functions from sample_base


bool DiametriqInterface::terminate()
{
   LLOG(0,1,"DiametriqInterface::terminate start");
   if(false == m_initializedFlag)
   {
      LLOG(0,1,"DiametriqInterface::terminate not initialized itself. returning");
      return false;
   }
   IDS_MESSAGE reg;
   reg.clientID= g_OtherConfigData->m_dcd.m_clientId;
   reg.msg_type = DEREGISTER_MSG;

   // De-Register the Registered Client
   g_smplApi->DeRegister(&reg);

   IDSCL_Terminate();
   LLOG(0,1,"DiametriqInterface::terminate end");
   return true;
}

