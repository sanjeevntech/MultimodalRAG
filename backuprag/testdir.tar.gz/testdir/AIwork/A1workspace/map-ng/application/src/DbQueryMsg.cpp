#include <DbQueryMsg.h>
#include <stdio.h>
#include <string.h>
#include <Logger.h>

char g_entityName[10+1];

DbQueryMsg::DbQueryMsg() 
{
   DLOG(0,1,"DbQueryMsg :cons:");
   m_DbQueryRes = DB_QUERY_RES_UNKNOWN;
   m_cb = NULL;
   memset(m_LoggingMsg, '\0', 20+1);
   m_sqlcode=-1;
   m_procErrorCode=-1;
   memset(m_procErrorMessage, '\0', sizeof(m_procErrorMessage));
   m_DbQueryCachedType = DB_QUERY_CACHED_TYPE_NOT_CACHED;
   m_MsgType = MSG_TYPE_DB;       
   m_DbQueryTpsCountable = DB_QUERY_TPS_COUNTABLE;
   m_DbQueryQueueType =  DB_QUERY_QUEUE_TYPE_INITIAL;
}

DbQueryMsg::~DbQueryMsg()
{
   DLOG(0,1,"DbQueryMsg :des:");
}

void DbQueryMsg::executeMemcQuery()
{
   ELOG(0,1,"DbQueryMsg :executeMemcQuery: should not be called");
}
void DbQueryMsg::serializeMemc()
{
   ELOG(0,1,"DbQueryMsg :serializeMemc: should not be called");
}
bool DbQueryMsg::deSerializeMemc()
{
   ELOG(0,1,"DbQueryMsg :deSerializeMemc: should not be called");
   return false;
}
/*bool DbQueryMsg::validateMemcachedContinuity()
{
   ELOG(0,1,"DbQueryMsg :validateMemcachedContinuity: should not be called");
   return false;
}*/
