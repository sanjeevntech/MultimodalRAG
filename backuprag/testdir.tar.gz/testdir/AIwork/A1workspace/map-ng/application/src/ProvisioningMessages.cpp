#include <ProvisioningMessages.h>
#include <Logger.h>


ProvisioningMsg::ProvisioningMsg() : Msg(MSG_TYPE_PROV)
{
   m_UserDlgId     = 0;
   ///-m_DlgId         = 0;
   m_provMsgType   = PROV_MSG_TYPE_UNKNOWN;
   m_sockFd        =-1;
   m_DeviceConnectionType=0;
}

ProvisioningMsg::ProvisioningMsg(EProvMsgType p_provMsgType) : Msg(MSG_TYPE_PROV)
{
   m_provMsgType=p_provMsgType;

   m_sockFd=-1;
}

ProvisioningMsg::~ProvisioningMsg()
{
}

ProvisioningReqMsg::ProvisioningReqMsg() : ProvisioningMsg(PROV_MSG_TYPE_REQUEST)
{
   TLOG(0,1,"ProvisioningReqMsg :cons:");
}

ProvisioningReqMsg::~ProvisioningReqMsg()
{
   TLOG(0,1,"ProvisioningReqMsg :des:");
}

ProvisioningResMsg::ProvisioningResMsg() : ProvisioningMsg(PROV_MSG_TYPE_RESPONSE)
{
   TLOG(0,1,"ProvisioningResMsg :cons:");
}

ProvisioningResMsg::~ProvisioningResMsg()
{
   TLOG(0,1,"ProvisioningResMsg :des:");
}

