#include <stdio.h>
#include <deque>
#include <stdlib.h>
#include <string>
#include <list>
#include <strings.h>
#include <time.h>
#include <signal.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <signal.h>

#include <Logger.h>
#include <TcpSocketServer.h>
#include <ServiceCoordinator.h>
#include <ProvisioningMessages.h>
#include <GlobalData.h>
#include <Utilities.h>
#include <StatisticsInterface.h>
#include <GUtilThreadHeartBeat.h>
#include <SnmpInterface.h>

#define CLIENT_BUF 5*1024*1024
#define SIZE_OF_LENGTH_FIELD 9   // This should always be 9 bytes

#define PROV_REG_ERROR_NOT_CONFIGURED           1001
#define PROV_REG_ERROR_ALREADY_EXISTS           1002
#define PROV_REG_ERROR_INVALID_LENGTH           1003
#define PROV_REG_ERROR_UNAUTHORIZED             1004
#define PROV_REG_ERROR_THRESHOLD_REACHED        1005

extern MessageQueue *g_OamTransactionsList;
map<int,FdInfo> g_FdInfoMap;

extern bool whatAllRegistered(char *p_registered);
TcpSocketServer g_tss;
MessageQueue *g_tcpSocketQueue = NULL;
MessageQueue *g_tcpSocketRetryQueue = NULL;
int g_tcpSockFd=0;
pthread_mutex_t g_FdMapMutex;
char g_registeredInterfaces[100+1];

extern int g_maxXmlTpsDataIndex; //HLR 2.0.24.0
extern int g_xmlMsgTimer;
extern int g_numOfXmlMsgsPerSecond;

FdInfo::FdInfo()
{
   state=DEVICE_STATE_NOT_REGISTERED;
   m_DeviceConnectionType=DEVICE_CONN_TYPE_NON_DEDICATED;
   m_lastActiveTime=time(NULL);
}

bool isValidInteger(char *p_buf)
{
   for (int l_i=0; l_i<SIZE_OF_LENGTH_FIELD; l_i++)
   {
      if ( (p_buf[l_i] < '0') || (p_buf[l_i] > '9'))
      {
         return false;
      }
   }
   return true;
}

int TcpSocketRecvAll(int p_sockFd, char *p_buf, int p_len, int p_timeoutInSecs)
{
   if(0 > p_sockFd)
   {
      ELOG(0,1,"Invalid Sockfd : %d", p_sockFd);
      return -1;
   }

   if (1 > p_len)
   {
      ELOG(0,1,"Invalid Length in input : %d", p_len);
      return -1;
   }

   if ( (1 > p_timeoutInSecs) || (100 < p_timeoutInSecs) )
   {
      ELOG(0,1,"Invalid timeout in input %d", p_timeoutInSecs);
   }

   int l_total = 0;
   int l_receivedBytes = 0;
   struct timeval l_tv;
   l_tv.tv_sec = p_timeoutInSecs;          
   l_tv.tv_usec = 0;

   while(l_total < p_len)
   {
      fd_set read_mask;
      FD_ZERO(&read_mask);
      FD_SET(p_sockFd, &read_mask);
      DLOG(0,0, "Checking if there is data to read");
      int nfd = select(p_sockFd+1, &read_mask, (fd_set *)NULL, (fd_set *)NULL, (struct timeval *)&l_tv);/* will block */
      if (nfd > 0)
      {
         DLOG(0,1,"Data present");
         l_receivedBytes = recv(p_sockFd, p_buf+l_total, p_len-l_total, MSG_DONTWAIT);
         if (0 >= l_receivedBytes)
         {
            if(0 > l_receivedBytes)
            {
               WLOG(0,1,"recv failed with errno: %d.",errno);
               if (EINTR == errno)
                  continue;
            }
            else
            {
               LLOG(0,1,"Socket closed by Peer");
            }
            return l_receivedBytes;
         }
         else
         {
            l_total += l_receivedBytes;
            DLOG(0,1,"Received bytes %d, bytesleft %d, len %d, sockFd: %d",l_receivedBytes,p_len-l_total, p_len, p_sockFd);
         }
      }
      else if (-1 == nfd)
      {
         CLOG(0,1,"Error in select %d", errno);
         if (EINTR == errno)
            continue;
      }
      else
      {
         WLOG(0,1,"Timer (%d secs) expired. Received only %d byte(s) while expected is %d byte(s) ", p_timeoutInSecs, l_total, p_len);
         return -1;
      }
   }
   LLOG(0,1,"Returning %d", l_total);
   return l_total;
}

/*
   int TcpSocketRecvAll(int &s, char *l_buf, int len)
   {
   int total = 0;
   int bytesleft = len;
   int n;

   if(0>s)
   return -1;

   while(total < len)
   {
   n = recv(s, l_buf+total, bytesleft,0);
   if (0 >= n)
   {
   if(0 > n)
   {
   WLOG(0,1,"%s <Ln:%d> recv failed with errno: %d.",__FUNCTION__, __LINE__, errno);
   if (EINTR == errno || EWOULDBLOCK == errno )
   continue;
   }
   else
   DLOG(0,1,"%s <Ln:%d> Socket closed by Peer.", __FUNCTION__, __LINE__);
   return n;
   }
   total += n;
   bytesleft -= n;
   TLOG(0,1,"received bytes %d, bytesleft %d, len %d, sockFd: %d",n,bytesleft,len, s);
   }

   len = total; // return number actually sent here

   TLOG(0,0,"TcpSocketRecvAll buf: [%s] len [%d]", l_buf, len);
   return len;
   }*/


bool available(int p_sockFd)
{
   struct timeval l_tv;
   l_tv.tv_sec = 3;          
   l_tv.tv_usec = 0;

   fd_set write_mask;
   FD_ZERO(&write_mask);
   FD_SET(p_sockFd, &write_mask);
   DLOG(0,0, "Checking if there is space to send");
   int nfd = select(p_sockFd+1, (fd_set *)NULL, &write_mask, (fd_set *)NULL, (struct timeval *)&l_tv);/* will block */
   if (nfd > 0)
   {
      DLOG(0,1,"Data can be sent");
      return true;
   }
   else if (-1 == nfd)
   {
      CLOG(0,0,"select returned -1");
      return false;
   }
   else
   {
      WLOG(0,1,"Timer (%d secs) expired.", l_tv.tv_sec);
      return false;
   }
}


bool sendDataToNetwork2(int p_sockFd, unsigned char *p_data, int p_length)
{
   DLOG(0,1,"sendDataToNetwork2 called");
   unsigned char *l_data = (unsigned char *)"Some Error";
   int l_length=strlen((char*)l_data);

   if (NULL != p_data)
   {
      l_data = p_data;
      l_length = p_length;
   }

   if (0 == l_length)
   {
      ELOG(0,1,"sendDataToNetwork2 failed. Invalid length");
      return false;
   }
   if (p_sockFd != 0)
   {
      char l_lengthChar[10];
      memset(l_lengthChar, '\0', 10);
      sprintf(l_lengthChar, "%09d", l_length);

      LLOG(0,1,"TcpSocketServer Sending Length [%s]", l_lengthChar);

      if (false == available(p_sockFd))
      {
         return false;
      }

      if (send(p_sockFd, l_lengthChar, 9, 0) == -1) 
      {
         CLOG(0,1,"Sending length failed");
         return false;
      }

      if (false == available(p_sockFd))
      {
         return false;
      }


      if (send(p_sockFd, l_data, l_length, 0) == -1) 
      {
         CLOG(0,1,"Sending data failed");
         return false;
      }
      DLOG(0,1,"TcpSocketServer Sending data successfull\n");
   }
   else
   {
      CLOG(0,1,"No Client Desc present");
   }
   return true;
}

bool sendImmediateRegistrationResponse(int p_sockFd, int p_errorCode, char *p_errorDesc)
{
   TLOG(0,1,"sendImmediateRegistrationResponse called");

   string l_temp;
   l_temp.assign("<REGISTRATION_RESPONSE>");
   l_temp.append("<HEADER>");
   l_temp.append("<ERROR_CODE>");
   char l_errorCode[10];
   memset(l_errorCode, '\0', sizeof(l_errorCode));
   sprintf(l_errorCode, "%d", p_errorCode);
   l_temp.append(l_errorCode);
   l_temp.append("</ERROR_CODE>");
   l_temp.append("<ERROR_DESC>");
   l_temp.append(p_errorDesc);
   l_temp.append("</ERROR_DESC>");
   l_temp.append("</HEADER>");
   l_temp.append("<BODY>");
   l_temp.append(g_registeredInterfaces);
   l_temp.append("</BODY>");
   l_temp.append("</REGISTRATION_RESPONSE>");

   LLOG(0,1,"Sending [%s] to the sockfd:%d", (unsigned char*)l_temp.c_str(), p_sockFd);

   return sendDataToNetwork2(p_sockFd, (unsigned char*)l_temp.c_str(), l_temp.size());
}


void *tcpSocketReceiverThrFunc(void *p)
{
   int l_lastRetryQueueProcessedTime = 0;
   if(0 != g_OtherConfigData->m_THBEnabled)
   {
    if(false == g_thb.registerMe((g_OtherConfigData->m_DbHeartBeatInterval>0)?g_OtherConfigData->m_DbHeartBeatInterval+60:STANDARD_SERVER_REGISTER_ME_TIMEOUT, "tcpSocketReceiverThr Thread"))
    {
       ELOG(0,1,"ERROR!! RegisterMe Failed");
       exitFunc(EXIT_APPLICATION_TYPE_THB_I_AM_ALIVE_FAILED);
    }
   }
   if (g_tcpSocketQueue != NULL)
   {
      bool l_status=false;
      while(1)
      {
       if((0 != g_OtherConfigData->m_THBEnabled) && ((g_simulateThbHungInterval == 0 ) || (time(NULL) >= g_currTimeForTHB + g_simulateThbHungInterval)))
       {
        if(false == g_thb.iAmAlive())
        {
        ELOG(0,1,"THB iAmAlive failed. Exiting...");
        return NULL;
        }
       }
         DLOG(0,0,"TCP RetryQueue size: %d, ProcessingQueue size: %d", g_tcpSocketRetryQueue->size(), g_tcpSocketQueue->size());
         void *l_pop = NULL;
         l_status = g_tcpSocketQueue->pop(&l_pop);
         if(true == l_status)
         {
            ProvisioningResMsg *l_provResMsg = (ProvisioningResMsg *)l_pop;
            LLOG(0,1,"XML: TcpSocketServer: Got a response to be sent fd:%d [%s]", l_provResMsg->m_sockFd, (char*)l_provResMsg->m_data.c_str());

            //Adding code here to retrieve the current interface's socket descriptor
            int l_currClientSockFd=-1;
            pthread_mutex_lock(&g_FdMapMutex);
            map<int,FdInfo>::iterator l_fdinfo_check_list_itr;
            for(l_fdinfo_check_list_itr=g_FdInfoMap.begin();
                  l_fdinfo_check_list_itr!=g_FdInfoMap.end();
                  ++l_fdinfo_check_list_itr)
            {
               TLOG(0,1,"checking with name [%s]", l_fdinfo_check_list_itr->second.device_name.c_str());

               TLOG(0,1,"pop provres [%s], [%s]", l_provResMsg->m_OrigEntityName.c_str(), l_provResMsg->m_IpAddress.c_str());
               if(
                     (((l_fdinfo_check_list_itr->second.device_name).compare(l_provResMsg->m_OrigEntityName))==0) &&
                     (((l_fdinfo_check_list_itr->second.ip_address).compare(l_provResMsg->m_IpAddress))==0)
                 ) 
               {
                  TLOG(0,1,"Matched");
                  l_currClientSockFd=l_fdinfo_check_list_itr->first;
                  break;
               }
            }
            pthread_mutex_unlock(&g_FdMapMutex);
            if(l_currClientSockFd > 0)
            {
               if(false == sendDataToNetwork2(l_currClientSockFd, (unsigned char*)l_provResMsg->m_data.c_str(), l_provResMsg->m_data.size()))
               {
                  CLOG(0,1,"sendDataToNetwork2 failed.");
                  if(1 == l_provResMsg->m_DeviceConnectionType)
                  {
                     LLOG(0,1,"Device Type is Dedicated. Pushing the message to the RetryQueue");
                     g_tcpSocketRetryQueue->push(l_provResMsg);
                  }
                  else
                  {
                     WLOG(0,1,"Device Type is Non Dedicated. Ignoring the message");
                     delete(l_provResMsg);
                  }
               }
               else
               {
                  TLOG(0,1,"sendDataToNetwork2 success. Deleting the message");
                  delete(l_provResMsg);
               }
            }
            else
            {
               WLOG(0,1,"Could not get a socket descriptor in the map for the entity [%s]", l_provResMsg->m_OrigEntityName.c_str());
               if(1 == l_provResMsg->m_DeviceConnectionType)
               {
                  LLOG(0,1,"Device Type is Dedicated. Pushing the message to the RetryQueue");
                  g_tcpSocketRetryQueue->push(l_provResMsg);
               }
               else
               {
                  TLOG(0,1,"Device Type is Non Dedicated. Ignoring the message");
                  delete(l_provResMsg);
               }
            }
         }

         if(g_tcpSocketRetryQueue->size() > 0)
         {
            int l_retryQueueSize = g_tcpSocketRetryQueue->size();
            int l_currentTime = time(NULL);
            if(l_currentTime > l_lastRetryQueueProcessedTime+60)
            {
               LLOG(0,0,"TCP RetryQueue size: %d", l_retryQueueSize);
               l_lastRetryQueueProcessedTime = l_currentTime;
               LLOG(0,0,"Moving the RetryQueue into the ProcessingQueue. ProcessingQueueSize [%d]", g_tcpSocketQueue->size());
               for(int l_i=1; l_i<=l_retryQueueSize; l_i++)
               {
                  void *l_pop = NULL;
                  l_status = g_tcpSocketRetryQueue->pop(&l_pop);
                  if(true == l_status)
                  {
                     g_tcpSocketQueue->push(l_pop);
                  }
                  else
                  {
                     ELOG(0,0,"Pop Failed. This should never come");
                  }
               }
               LLOG(0,0,"End of moving the RetryQueue into the ProcessingQueue. ProcessingQueueSize [%d]", g_tcpSocketQueue->size());
            }
         }
         else
         {
            //DLOG(0,0,"No messages present in the RetryQueue");
         }
      }
   }
   return NULL;
}

void *tcpSocketServerThrFunc(void *p)
{
   LLOG(0,1,"tcpSocketServerThrFunc started");

   if (p != NULL)
   {
      DLOG(0,1,"p is not null");
   }
   if(0 != g_OtherConfigData->m_THBEnabled)
   {
    if(false == g_thb.registerMe((g_OtherConfigData->m_DbHeartBeatInterval>0)?g_OtherConfigData->m_DbHeartBeatInterval+60:STANDARD_SERVER_REGISTER_ME_TIMEOUT , "tcpSocketServerThr Thread"))
    {
      ELOG(0,1,"ERROR!! RegisterMe Failed");
      exitFunc(EXIT_APPLICATION_TYPE_THB_I_AM_ALIVE_FAILED);
    }
   }

   int l_ServerSocket = g_tcpSockFd;
   if (l_ServerSocket < 1)
   {
      ELOG(0,1,"Invalid Server Socket Fd");
      exitFunc(EXIT_APPLICATION_TYPE_TSS_INVALID_SOCKET);
   }

   DLOG(0,1,"tcpSocketServerThrFunc started with socket %d", l_ServerSocket);

   fd_set l_cli_fdset;
   int l_max_fd = l_ServerSocket;
   struct timeval tv;
   list<int> l_sockFdList;
   list<int>::iterator l_sockfd_it;
   struct sockaddr_in client_addr;
   int l_ClientSocket;

   time_t l_lastTimerExecuted=0;
   time_t l_currTime=time(NULL);
   while (1)
   {
      // Start of Responses Processing


      // End of Responses Processing
      if((0 != g_OtherConfigData->m_THBEnabled) && ((g_simulateThbHungInterval == 0 ) || (time(NULL) >= g_currTimeForTHB + g_simulateThbHungInterval)))
      {
         if(false == g_thb.iAmAlive())
         {
            ELOG(0,1,"THB iAmAlive failed. Exiting...");
            return NULL;
         }
      }
      if(g_OtherConfigData->m_clientIdleTimeout > 0)
      {
         l_currTime=time(NULL);
         if(l_currTime > l_lastTimerExecuted+60) //Do only in a minute
         {
            LLOG(0,0,"Start Time Manger.. SizeOfMap:%d, TempSizeMap:%d", g_FdInfoMap.size(), l_sockFdList.size());
            l_lastTimerExecuted=l_currTime;

            pthread_mutex_lock(&g_FdMapMutex);
            //map<int,FdInfo>::iterator l_fdinfo_itr;
            //for(l_fdinfo_itr = l_TcpSocketServer->m_FdInfoMap.begin(); l_fdinfo_itr != l_TcpSocketServer->m_FdInfoMap.end(); l_fdinfo_itr++)
            for(l_sockfd_it = l_sockFdList.begin(); l_sockfd_it != l_sockFdList.end(); )
            {
               map<int,FdInfo>::iterator l_fdinfo_itr;
               l_fdinfo_itr = g_FdInfoMap.find(*l_sockfd_it);

               if(l_fdinfo_itr == g_FdInfoMap.end())
               {
                  ELOG(0,0,"sockfd:%d not found in main map", *l_sockfd_it);
                  l_sockfd_it++;
                  continue;
               }


               if(DEVICE_CONN_TYPE_DEDICATED == l_fdinfo_itr->second.m_DeviceConnectionType)
               {
                  DLOG(0,0,"Ignoring timeout for client since dedicated [%s]", l_fdinfo_itr->second.device_name.c_str());
                  l_sockfd_it++;
                  continue;
               }

               char l_deviceName[100+1];
               snprintf(l_deviceName, sizeof(l_deviceName), ",%s,", l_fdinfo_itr->second.device_name.c_str());
               if(NULL != strstr(g_OtherConfigData->m_clientIdleTimeoutExceptionList, l_deviceName))
               {
                  DLOG(0,0,"Ignoring timeout for client since configured in the list [%s]", l_fdinfo_itr->second.device_name.c_str());
                  l_sockfd_it++;
                  continue;
               }

               if(l_currTime > l_fdinfo_itr->second.m_lastActiveTime+g_OtherConfigData->m_clientIdleTimeout)
               {
                  CLOG(0,0,"Found an idle connection with sockfd:%d. Closing the connection. EntityName[%s] IP[%s]", l_fdinfo_itr->first,l_fdinfo_itr->second.device_name.c_str(),l_fdinfo_itr->second.ip_address.c_str());
                  close(*l_sockfd_it);
                  g_si.sendSnmpTrap(g_CloseNotRecvTrap, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL);
                  g_FdInfoMap.erase(*l_sockfd_it);
                  l_sockfd_it=l_sockFdList.erase(l_sockfd_it);
               }
               else
               {
                  l_sockfd_it++;
               }
            }
            pthread_mutex_unlock(&g_FdMapMutex);
            LLOG(0,0,"End of Time Manager SizeOfMap:%d, TempSizeMap:%d", g_FdInfoMap.size(), l_sockFdList.size());
         }

      }

      FD_ZERO(&l_cli_fdset);
      FD_SET(l_ServerSocket, &l_cli_fdset);
      l_max_fd = l_ServerSocket;

      for(l_sockfd_it = l_sockFdList.begin(); l_sockfd_it != l_sockFdList.end(); ++l_sockfd_it)
      {
         FD_SET(*l_sockfd_it, &l_cli_fdset);
         if(l_max_fd<*l_sockfd_it)
            l_max_fd = *l_sockfd_it;
      }

      tv.tv_sec = 0;
      tv.tv_usec = 100000;

      if(1 == g_OtherConfigData->m_PrintTimerInLog)
      {
         DLOG(0,1,"TcpSocketServer calling select with server sockfd: %d", l_ServerSocket);
      }

      if(0 < select(l_max_fd+1, &l_cli_fdset, NULL, NULL, &tv))
      {
         if(FD_ISSET(l_ServerSocket, &l_cli_fdset))
         {
            int client_len = sizeof(client_addr);

            if(0 <= (l_ClientSocket = accept(l_ServerSocket, (struct sockaddr *)&client_addr, (socklen_t *)&client_len)))
            {
               if(l_ClientSocket > 1023)
               {
                  WLOG(0,1,"socket fd [%d]  more than 1023 , closing the connection ", l_ClientSocket);
                  g_si.sendSnmpTrap(g_AcceptNewConnErrTrap, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL);
                  close(l_ClientSocket);
                  continue;
               }
               int l_percentage = 0;
               l_percentage = (g_FdInfoMap.size()*100)/ g_OtherConfigData->m_MaxActiveConnections;
               LLOG(0,1,"PerCentageThreshold[%d] of m_MaxActiveConnections:[%d]", l_percentage, g_OtherConfigData->m_MaxActiveConnections);

               if(g_FdInfoMap.size() >= g_OtherConfigData->m_MaxActiveConnections)
               {
                  WLOG(0,1,"SizeOfMap:%d is high. Closing the connection", g_FdInfoMap.size());
                  g_si.sendSnmpTrap(g_MaxthresholdLimitTrap, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL);
                  sendImmediateRegistrationResponse(l_ClientSocket, PROV_REG_ERROR_THRESHOLD_REACHED, "Maximum Connection Reached");
                  close(l_ClientSocket);
                  continue;

               }
               if(l_percentage >= g_OtherConfigData->m_conn_fd_thresh_percentage)
               { 
                  char l_temp[500];
                  snprintf(l_temp, sizeof(l_temp), "Active Connection %d Percentage Reached", l_percentage); 
                  CLOG(0,0,"Connection Reached percentage [%d] MAX Active percentage :%d ", l_percentage, g_OtherConfigData->m_conn_fd_thresh_percentage);
                  g_si.sendSnmpTrap(g_MaxThreshPercentTrap, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL, l_temp);
               } 
               l_sockFdList.push_back(l_ClientSocket);
               FdInfo l_FdInfo;
               l_FdInfo.ip_address = inet_ntoa(client_addr.sin_addr);
               l_FdInfo.port = client_addr.sin_port;
               pthread_mutex_lock(&g_FdMapMutex);
               g_FdInfoMap.insert(pair<int,FdInfo>(l_ClientSocket,l_FdInfo));
               pthread_mutex_unlock(&g_FdMapMutex);
               LLOG(0,1,"Accepted a new connection with sock fd:%d from ip: %s",l_ClientSocket, inet_ntoa(client_addr.sin_addr));
            }
            else if(l_ClientSocket < 0)
            {
               WLOG(0,1,"Error in accept: %d", errno);
            }
         }//if FD_ISSET
         else
         {
            for(l_sockfd_it = l_sockFdList.begin(); l_sockfd_it != l_sockFdList.end(); )
            {
               if(FD_ISSET(*l_sockfd_it, &l_cli_fdset))
               {
                  DLOG(0,1,"Received message from Client");


                  char l_bufLength[9+1];
                  memset(l_bufLength, 0, 9+1);

                  pthread_mutex_lock(&g_FdMapMutex);
                  map<int,FdInfo>::iterator l_fdinfo_itr;
                  l_fdinfo_itr = g_FdInfoMap.find(*l_sockfd_it);
                  if(l_fdinfo_itr == g_FdInfoMap.end())
                  {
                     DLOG(0,1,"Severe Error");
                     pthread_mutex_unlock(&g_FdMapMutex);
                     continue;
                  }
                  l_fdinfo_itr->second.m_lastActiveTime = time(NULL);
                  pthread_mutex_unlock(&g_FdMapMutex);

                  int recdLen = TcpSocketRecvAll(*l_sockfd_it, l_bufLength, SIZE_OF_LENGTH_FIELD, 5);
                  if(recdLen <= 0)
                  {
                     WLOG(0,1,"Entity [%s] got disconnected. recv length failed. fd=%d. SizeOfMap:%d",
                           (char*)l_fdinfo_itr->second.device_name.c_str(), *l_sockfd_it, g_FdInfoMap.size());

                     // Close the connection
                     close(*l_sockfd_it);
                     pthread_mutex_lock(&g_FdMapMutex);
                     g_FdInfoMap.erase(*l_sockfd_it);
                     pthread_mutex_unlock(&g_FdMapMutex);
                     l_sockfd_it=l_sockFdList.erase(l_sockfd_it);
                     WLOG(0,1,"SizeOfMap:%d", g_FdInfoMap.size());
                     continue;
                  }

                  LLOG(0,1,"Received Length [%s]\n", l_bufLength);

                  if (false == isValidInteger(l_bufLength))
                  {
                     WLOG(0,1,"Not a valid length. Closing the connection. received corrupted length. fd=%d", *l_sockfd_it);

                     // Close the connection
                     close(*l_sockfd_it);
                     pthread_mutex_lock(&g_FdMapMutex);
                     g_FdInfoMap.erase(*l_sockfd_it);
                     pthread_mutex_unlock(&g_FdMapMutex);
                     l_sockfd_it=l_sockFdList.erase(l_sockfd_it);
                     continue;
                  }

                  int l_length = atoi(l_bufLength);
                  if ( (CLIENT_BUF < l_length) || (l_length < 10))
                  {
                     WLOG(0,1,"Closing the connection. received length %d invalid.: fd=%d", l_length, *l_sockfd_it);

                     // Close the connection
                     close(*l_sockfd_it);
                     pthread_mutex_lock(&g_FdMapMutex);
                     g_FdInfoMap.erase(*l_sockfd_it);
                     pthread_mutex_unlock(&g_FdMapMutex);
                     l_sockfd_it=l_sockFdList.erase(l_sockfd_it);
                     continue;
                  }

                  char *l_buf = new char[l_length+1];
                  memset(l_buf, '\0', l_length+1);

                  recdLen = TcpSocketRecvAll(*l_sockfd_it, l_buf, l_length, 5);
                  if(recdLen <= 0)
                  {
                     WLOG(0,1,"Entity [%s] got disconnected. recv data failed. fd=%d.",
                           (char*)l_fdinfo_itr->second.device_name.c_str(), *l_sockfd_it);

                     // Close the connection
                     close(*l_sockfd_it);
                     pthread_mutex_lock(&g_FdMapMutex);
                     g_FdInfoMap.erase(*l_sockfd_it);
                     pthread_mutex_unlock(&g_FdMapMutex);
                     l_sockfd_it=l_sockFdList.erase(l_sockfd_it);

                     if(l_buf != NULL)
                     {
                        delete []l_buf;
                        l_buf=NULL;
                     }
                     continue;
                  }

                  LLOG(0,1,"rcvd data [%s] [%d] [%d] state:[%d]", l_buf, strlen(l_buf), l_length, l_fdinfo_itr->second.state);
                  string l_entityName;


                  bool l_deviceValid=false;

                  if(l_fdinfo_itr->second.state == DEVICE_STATE_NOT_REGISTERED)
                  {
                     int l_DeviceConnectionType=0;
                     bool l_devicePresentInxml=false; //Making the flag by default to true
                     string l_registrationRequest = ConfigReader::readValue(l_buf, "REGISTRATION_REQUEST");
                     if(l_registrationRequest.size() > 0)
                     {
                        string l_header = ConfigReader::readValue(l_registrationRequest, "HEADER");
                        if(l_header.size() > 0)
                        {
                           l_entityName = ConfigReader::readValue(l_header, "ENTITY_NAME");
                           if(l_entityName.size() > 0)
                           {
                              l_devicePresentInxml = true;
                           }
                           ConfigReader::readInteger(l_header, "CONNECTION_TYPE", l_DeviceConnectionType, 0, 1);
                           TLOG(0,1,"Device Connection Type: %d", l_DeviceConnectionType);

                        }
                     }

                     //code for checking the incoming client with already present map
                     bool l_clientNotAlreadyPresent = true;
                     if(1 == l_DeviceConnectionType)  // changed to check only for Dedicated Connections
                     {
                        pthread_mutex_lock(&g_FdMapMutex);
                        map<int,FdInfo>::iterator l_fdinfo_check_list_itr;
                        for(l_fdinfo_check_list_itr=g_FdInfoMap.begin();
                              l_fdinfo_check_list_itr!=g_FdInfoMap.end();
                              ++l_fdinfo_check_list_itr)
                        {
                           TLOG(0,1,"dev [%s], ip [%s]", l_fdinfo_check_list_itr->second.device_name.c_str(),
                                 l_fdinfo_check_list_itr->second.ip_address.c_str());
                           TLOG(0,1,"request dev[%s], ip[%s]", l_entityName.c_str(), l_fdinfo_itr->second.ip_address.c_str());
                           if( (((l_fdinfo_check_list_itr->second.device_name).compare(l_entityName))==0) &&
                                 (((l_fdinfo_check_list_itr->second.ip_address).compare(l_fdinfo_itr->second.ip_address))==0)
                             )
                           {
                              l_clientNotAlreadyPresent=false;
                              break;
                           }
                        }
                        pthread_mutex_unlock(&g_FdMapMutex);
                     }

                     int l_provInitializedFlag=false;


                     if (g_prov != NULL)
                     {
                        if (0 == g_prov->m_lastUpdatedDate)
                        {
                           l_provInitializedFlag=false;
                        }
                        else
                        {
                           l_provInitializedFlag=true;
                        }
                        TLOG(0,1,"Calling isValidEntity");
                        char l_entityNameUpper[200+1];
                        memset(l_entityNameUpper, '\0', sizeof(l_entityNameUpper));
                        upper((char*)l_entityName.c_str(), l_entityNameUpper, 200);
                        l_deviceValid = g_prov->isValidEntity((char*)l_fdinfo_itr->second.ip_address.c_str(), 
                              l_entityNameUpper);
                     }
                     else
                     {
                        ELOG(0,1,"g_prov is null");
                        l_deviceValid=false;
                        l_provInitializedFlag=false;
                     }

                     if((true == l_clientNotAlreadyPresent) && (true == l_devicePresentInxml) && (true == l_deviceValid))
                     {
                        if(0 == l_DeviceConnectionType) //NON Dedicated
                        {
                           char l_uniqueIP[200+1]; //IP_ADD:10DIGIT_EPOCH:SOCKFD
                           snprintf(l_uniqueIP, sizeof(l_uniqueIP), "%s:%d",
                                 (char*)l_fdinfo_itr->second.ip_address.c_str(), l_fdinfo_itr->second.port);
                           l_fdinfo_itr->second.ip_address = l_uniqueIP;
                           LLOG(0,1, "Unique Connection IP : [%s]", l_uniqueIP);
                        }

                        l_fdinfo_itr->second.device_name = l_entityName;
                        l_fdinfo_itr->second.m_DeviceConnectionType = (EDeviceConnectionType)l_DeviceConnectionType;
                        l_fdinfo_itr->second.state=DEVICE_STATE_REGISTERED;
                        LLOG(0,1,"Registration Request Received [%s]", l_buf);
                        sendImmediateRegistrationResponse(*l_sockfd_it, 0, "Success");
                     }
                     else
                     {
                        if(false == l_devicePresentInxml)
                        {
                           WLOG(0,1,"Closing the connection. Registration request should be sent at startup instead of [%s]  fd=%d",l_buf, *l_sockfd_it);
                           //sendImmediateRegistrationResponse(int p_sockFd, string& p_transId, string& p_reqType, int p_errorCode, char *p_errorDesc)
                        }
                        else if (false == l_clientNotAlreadyPresent)
                        {
                           WLOG(0,1,"Closing the connection. entity [%s] already exists.: fd=%d", (char*)l_entityName.c_str(), *l_sockfd_it);
                           sendImmediateRegistrationResponse(*l_sockfd_it, PROV_REG_ERROR_ALREADY_EXISTS, "Device already connected");
                        }
                        else if(false == l_deviceValid)
                        {
                           WLOG(0,1,"Device invalid");
                           if(true == l_provInitializedFlag)
                           {
                              sendImmediateRegistrationResponse(*l_sockfd_it, PROV_REG_ERROR_UNAUTHORIZED, "Device Unauthorized");
                           }
                           else
                           {
                              CLOG(0,1,"Provisioning not yet initialized");
                              sleep(1);
                           }
			   WLOG(0,1,"Closing the connection. Device invalid  fd=%d", *l_sockfd_it);
                        }
                        // Close the connection
                        close(*l_sockfd_it);
                        pthread_mutex_lock(&g_FdMapMutex);
                        g_FdInfoMap.erase(*l_sockfd_it);
                        pthread_mutex_unlock(&g_FdMapMutex);
                        l_sockfd_it=l_sockFdList.erase(l_sockfd_it);
                     }
                  }
                  else if(l_fdinfo_itr->second.state == DEVICE_STATE_REGISTERED)
                  {
                     LLOG(1,1,"Message Received [%s]",l_buf);
                     // HLR 2.0.24.0
                     time_t l_tempTime = time(NULL);
                     g_numOfXmlMsgsPerSecond++;
                     if(l_tempTime > g_xmlMsgTimer)
                     {
                        LLOG(0,0,"Before Resetting New Second NumOfMsgInThatSec[%d]",g_numOfXmlMsgsPerSecond);
                        HLRStatisticsInitializer::instance()->logStatistics(g_maxXmlTpsDataIndex,g_numOfXmlMsgsPerSecond);
                        g_numOfXmlMsgsPerSecond = 1;
                        g_xmlMsgTimer = l_tempTime;
                     }
                     //Process the data

                     /*if( (strlen(l_buf) > 5000) && (g_OamTransactionsList->size() > 10000))
                       {
                       LLOG(0,1,"OAM Transactions size is greater than 5000");
                       sendImmediateRegistrationResponse(*l_sockfd_it, PROV_REG_ERROR_THRESHOLD_REACHED, "Threshold Reached");

                     // Close the connection
                     close(*l_sockfd_it);
                     pthread_mutex_lock(&g_FdMapMutex);
                     g_FdInfoMap.erase(*l_sockfd_it);
                     pthread_mutex_unlock(&g_FdMapMutex);
                     l_sockfd_it=l_sockFdList.erase(l_sockfd_it);
                     }
                     else
                     {*/
                     ProvisioningReqMsg *l_provReqMsg = new ProvisioningReqMsg;
                     l_provReqMsg->m_sockFd = *l_sockfd_it;
                     l_provReqMsg->m_data.assign(l_buf, strlen(l_buf));
                     l_provReqMsg->m_OrigEntityName = l_fdinfo_itr->second.device_name;
                     l_provReqMsg->m_IpAddress = l_fdinfo_itr->second.ip_address;
                     l_provReqMsg->m_DeviceConnectionType = l_fdinfo_itr->second.m_DeviceConnectionType;
                     TLOG(0,1,"Preparing message with entityname [%s] entitytype [%d]", l_provReqMsg->m_OrigEntityName.c_str(), 
                           l_provReqMsg->m_DeviceConnectionType);

                     g_sc.initiateIndependentContext(NULL, MAP_OP_CODE_dummy_1, l_provReqMsg);
                     //}
                  }

                  if(l_buf != NULL)
                  {
                     TLOG(0,1,"Deleting the buffer");
                     delete []l_buf;
                     l_buf=NULL;
                  }
               } 
               ++l_sockfd_it;
            }//for
         }//else
      }//if)select
   }//while
   return NULL;
}

void TcpSocketServer::getStats(char *p_output)
{
   if (g_tcpSocketQueue != NULL)
   {  
      pthread_mutex_lock(&g_FdMapMutex);
      char l_entities[1000];
      memset(l_entities, '\0', sizeof(l_entities));
      strcpy(l_entities, "Entities: ");
      map<int,FdInfo>::iterator l_fdinfo_itr;
      for (l_fdinfo_itr=g_FdInfoMap.begin(); l_fdinfo_itr!=g_FdInfoMap.end(); ++l_fdinfo_itr)
      {
         char l_temp[100];
         memset(l_temp, '\0', sizeof(l_temp));
         snprintf(l_temp, sizeof(l_temp), "(%d)[%s] ", l_fdinfo_itr->first, l_fdinfo_itr->second.device_name.c_str());
         strlcat(l_entities, l_temp, 1000);
      }
      sprintf(p_output, "\n Provisioning Interface \t\t\t: QueueSize: %d %s", g_tcpSocketQueue->size(), l_entities);
      pthread_mutex_unlock(&g_FdMapMutex);
   }
   else
   {
      sprintf(p_output, "\n Provisioning Response Queue Size\t\t: %s", "NOT ENABLED");
   }
   return;
}

bool TcpSocketServer::initialize(int p_port)
{
   int l_ServerSocket;
   struct sockaddr_in addr;
   unsigned int val = 1;

   whatAllRegistered(g_registeredInterfaces);
   LLOG(0,1,"Initializing with the interfaces [%s]", g_registeredInterfaces);

   g_tcpSocketQueue = new MessageQueue(QUEUE_TYPE_BLOCKING_TIMED_WAIT, QUEUE_PERSISTENCE_TYPE_NON_PERSISTENT); // This queue is required to process the responses
   bool l_status = g_tcpSocketQueue->initialize();
   if (!l_status)
   {
      ELOG(0,1,"ERROR!! Unable to initialize the TCP Socket Response Queue");
      return false;
   }

   g_tcpSocketRetryQueue = new MessageQueue(QUEUE_TYPE_NON_BLOCKING, QUEUE_PERSISTENCE_TYPE_NON_PERSISTENT); // This queue is required to process the retry messages
   l_status = g_tcpSocketRetryQueue->initialize();
   if (!l_status)
   {
      ELOG(0,1,"ERROR!! Unable to initialize the TCP Socket Retry Response Queue");
      return false;
   }

   if (-1 == (l_ServerSocket = socket(AF_INET, SOCK_STREAM, 0)))
   {
      ELOG(0,1,"Error in socket Call");
      return false;
   }
   memset(&addr, 0, sizeof(addr));
   addr.sin_family = AF_INET;
   addr.sin_addr.s_addr = INADDR_ANY;
   addr.sin_port = htons(p_port);

   LLOG(0,1,"TcpSocketServer sockfd: %d Binding on port:%d", l_ServerSocket, p_port);

   setsockopt(l_ServerSocket, SOL_SOCKET, SO_REUSEADDR , &val, sizeof(val));

   if( 1 == g_ConfigData->m_ServerKeepAliveFlag )
   {
      LLOG(0,0,"Server KeepAlive Flag is enabled");
      if(-1 == setsockopt(l_ServerSocket, SOL_SOCKET, SO_KEEPALIVE, &val, sizeof(val)))
      {
         ELOG(0,1,"Error in Setsockopt Call");
         return false;
      }

   }

   if(bind(l_ServerSocket, (struct sockaddr *)&addr,  sizeof(addr)) < 0)
   {
      close(l_ServerSocket);
      ELOG(0,1,"Error in Bind");
      return false;
   }

   if (listen(l_ServerSocket, 40) < 0)
   {
      close(l_ServerSocket);
      ELOG(0,1,"Error in Listen");
      return false;
   }

   LLOG(0,1,"TcpSocketServer Creating thread sockfd: %d", l_ServerSocket);
   g_tcpSockFd=l_ServerSocket;

   pthread_mutex_init(&g_FdMapMutex, NULL); //Added for synchronisation of the g_FdInfoMap

   pthread_t l_thread;
   if(0 !=  pthread_create(&l_thread, NULL, tcpSocketServerThrFunc, this))
   {
      ELOG(0,1,"Unable to create thread tcpSocketServerThrFunc");
      return false;
   }

   pthread_t l_thread_sender;
   if(0 !=  pthread_create(&l_thread_sender, NULL, tcpSocketReceiverThrFunc, this))
   {
      ELOG(0,1,"Unable to create thread tcpSocketReceiverThrFunc");
      return false;
   }
   LLOG(0,1,"Initialization of TcpSocketServer successfull..\n\n");
   return true;
}


TcpSocketServer::TcpSocketServer()
{
}

TcpSocketServer::~TcpSocketServer()
{
}


