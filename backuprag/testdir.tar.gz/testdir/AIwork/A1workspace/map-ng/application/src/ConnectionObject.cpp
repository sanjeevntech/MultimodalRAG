
/* Result Sets Interface */
#ifndef SQL_CRSR
#  define SQL_CRSR
  struct sql_cursor
  {
    unsigned int curocn;
    void *ptr1;
    void *ptr2;
    unsigned int magic;
  };
  typedef struct sql_cursor sql_cursor;
  typedef struct sql_cursor SQL_CURSOR;
#endif /* SQL_CRSR */

/* Thread Safety */
typedef void * sql_context;
typedef void * SQL_CONTEXT;

/* Object support */
struct sqltvn
{
  unsigned char *tvnvsn; 
  unsigned short tvnvsnl; 
  unsigned char *tvnnm;
  unsigned short tvnnml; 
  unsigned char *tvnsnm;
  unsigned short tvnsnml;
};
typedef struct sqltvn sqltvn;

struct sqladts
{
  unsigned int adtvsn; 
  unsigned short adtmode; 
  unsigned short adtnum;  
  sqltvn adttvn[1];       
};
typedef struct sqladts sqladts;

static struct sqladts sqladt = {
  1,1,0,
};

/* Binding to PL/SQL Records */
struct sqltdss
{
  unsigned int tdsvsn; 
  unsigned short tdsnum; 
  unsigned char *tdsval[1]; 
};
typedef struct sqltdss sqltdss;
static struct sqltdss sqltds =
{
  1,
  0,
};

/* File name & Package Name */
struct sqlcxp
{
  unsigned short fillen;
           char  filnam[20];
};
static const struct sqlcxp sqlfpn =
{
    19,
    "ConnectionObject.pc"
};


static unsigned int sqlctx = 37917579;


static struct sqlexd {
   unsigned long  sqlvsn;
   unsigned int   arrsiz;
   unsigned int   iters;
   unsigned int   offset;
   unsigned short selerr;
   unsigned short sqlety;
   unsigned int   occurs;
      const short *cud;
   unsigned char  *sqlest;
      const char  *stmt;
   sqladts *sqladtp;
   sqltdss *sqltdsp;
   unsigned char  **sqphsv;
   unsigned long  *sqphsl;
            int   *sqphss;
            short **sqpind;
            int   *sqpins;
   unsigned long  *sqparm;
   unsigned long  **sqparc;
   unsigned short  *sqpadto;
   unsigned short  *sqptdso;
   unsigned int   sqlcmax;
   unsigned int   sqlcmin;
   unsigned int   sqlcincr;
   unsigned int   sqlctimeout;
   unsigned int   sqlcnowait;
            int   sqfoff;
   unsigned int   sqcmod;
   unsigned int   sqfmod;
   unsigned char  *sqhstv[4];
   unsigned long  sqhstl[4];
            int   sqhsts[4];
            short *sqindv[4];
            int   sqinds[4];
   unsigned long  sqharm[4];
   unsigned long  *sqharc[4];
   unsigned short  sqadto[4];
   unsigned short  sqtdso[4];
} sqlstm = {12,4};

// Prototypes
extern "C" {
  void sqlcxt (void **, unsigned int *,
               struct sqlexd *, const struct sqlcxp *);
  void sqlcx2t(void **, unsigned int *,
               struct sqlexd *, const struct sqlcxp *);
  void sqlbuft(void **, char *);
  void sqlgs2t(void **, char *);
  void sqlorat(void **, unsigned int *, void *);
}

// Forms Interface
static const int IAPSUCC = 0;
static const int IAPFAIL = 1403;
static const int IAPFTL  = 535;
extern "C" { void sqliem(unsigned char *, signed int *); }

typedef struct { unsigned short len; unsigned char arr[1]; } VARCHAR;
typedef struct { unsigned short len; unsigned char arr[1]; } varchar;

/* cud (compilation unit data) array */
static const short sqlcud0[] =
{12,4138,1,0,0,
5,0,0,0,0,0,60,27,0,0,0,0,0,1,0,
20,0,0,0,0,0,58,49,0,0,1,1,0,1,0,3,109,0,0,
39,0,0,0,0,0,27,51,0,0,4,4,0,1,0,1,9,0,0,1,10,0,0,1,10,0,0,1,10,0,0,
70,0,0,0,0,0,59,66,0,0,1,1,0,1,0,3,109,0,0,
89,0,0,2,0,0,30,87,0,0,0,0,0,1,0,
104,0,0,0,0,0,59,88,0,0,1,1,0,1,0,3,109,0,0,
};


#include <string>
#include <map>
#include <sqlca.h>
#include <sql2oci.h>
//using namespace std;

#ifndef SQLCA_INIT
#define SQLCA_INIT 1
#endif

/* EXEC SQL INCLUDE ../inc/ConnectionObject.h;
 */ 
#ifndef __CONNECTION_OBJECT_H
#define __CONNECTION_OBJECT_H

#include <sqlda.h>

#include <string>
#include <Logger.h>
#include <ConfigReader.h>

#define CONNECTION_ATTEMPTS 5
#define MEMBER_STATE_GOOD	0
#define MEMBER_STATE_BAD	1

extern struct oraca oraca;

#ifndef SQLCA
#define SQLCA 1
struct   sqlca
{
   /* ub1 */ char    sqlcaid[8];
   /* b4  */ int     sqlabc;
   /* b4  */ int     sqlcode;
   struct
   {
      /* ub2 */ unsigned short sqlerrml;
      /* ub1 */ char           sqlerrmc[70];
   } sqlerrm;
   /* ub1 */ char    sqlerrp[8];
   /* b4  */ int     sqlerrd[6];
   /* ub1 */ char    sqlwarn[8];
   /* ub1 */ char    sqlext[8];
};
#endif

#include <sqlca.h>

extern struct sqlca sqlca;
extern struct oraca oraca;

class ConnectionObject
{

   public:
      // This variable indicates the state of the runtime context
      int	iState ;				
      /* EXEC SQL BEGIN DECLARE SECTION; */ 
		
      /* varchar	iCntStr[200]; */ 
struct { unsigned short len; unsigned char arr[200]; } iCntStr;

      /* EXEC SQL END DECLARE SECTION; */ 

   public:

      /* EXEC SQL BEGIN DECLARE SECTION; */ 

      sql_context iCtx;
      /* EXEC SQL END DECLARE SECTION; */ 


      // Default Context Object
      ConnectionObject(string mCntStr) ;

      ~ConnectionObject();
};


#endif




bool storeOciContext(sql_context *p_sc);

struct dbdata
{
   void *m_oci_svc;
   void *m_oci_err;
};

map <int, dbdata*> g_dbCtxtMap;
pthread_mutex_t    g_dbMapMutex;


void enableThreads()
{
   /* EXEC SQL ENABLE THREADS; */ 

{
   struct sqlexd sqlstm;
   sqlstm.sqlvsn = 12;
   sqlstm.arrsiz = 0;
   sqlstm.sqladtp = &sqladt;
   sqlstm.sqltdsp = &sqltds;
   sqlstm.stmt = "";
   sqlstm.iters = (unsigned int  )1;
   sqlstm.offset = (unsigned int  )5;
   sqlstm.cud = sqlcud0;
   sqlstm.sqlest = (unsigned char  *)&sqlca;
   sqlstm.sqlety = (unsigned short)4352;
   sqlstm.occurs = (unsigned int  )0;
   sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
}


}



ConnectionObject::ConnectionObject(string mCntStr)
{
   g_LoggerObj.log2(LOG_LEVEL_DEBUG, __FILE__, __FUNCTION__, __LINE__, 0, 1, "ConnectionObject cons");
   //extern struct sqlca sqlca;   5100 .. Removing extern for core dump issue when one DB conn is successful and other failure
   struct sqlca sqlca;
   int m_tryToConnectAttempt = CONNECTION_ATTEMPTS;

   this->iCtx = NULL ;

   do 
   {	
      strcpy((char*)this->iCntStr.arr,mCntStr.c_str());
      iCntStr.len = strlen((char*)mCntStr.c_str());
      g_LoggerObj.log2(LOG_LEVEL_DEBUG,    __FILE__, __FUNCTION__, __LINE__, 0, 1, "Trying to connect to Oracle Database (Attempt %d)", (CONNECTION_ATTEMPTS-m_tryToConnectAttempt)+1);
      m_tryToConnectAttempt--;

      /* EXEC SQL WHENEVER SQLERROR GOTO Error; */ 
 
      /* EXEC SQL CONTEXT ALLOCATE :iCtx; */ 

{
      struct sqlexd sqlstm;
      sqlstm.sqlvsn = 12;
      sqlstm.arrsiz = 1;
      sqlstm.sqladtp = &sqladt;
      sqlstm.sqltdsp = &sqltds;
      sqlstm.stmt = "";
      sqlstm.iters = (unsigned int  )1;
      sqlstm.offset = (unsigned int  )20;
      sqlstm.cud = sqlcud0;
      sqlstm.sqlest = (unsigned char  *)&sqlca;
      sqlstm.sqlety = (unsigned short)4352;
      sqlstm.occurs = (unsigned int  )0;
      sqlstm.sqhstv[0] = (unsigned char  *)&iCtx;
      sqlstm.sqhstl[0] = (unsigned long )sizeof(void *);
      sqlstm.sqhsts[0] = (         int  )0;
      sqlstm.sqindv[0] = (         short *)0;
      sqlstm.sqinds[0] = (         int  )0;
      sqlstm.sqharm[0] = (unsigned long )0;
      sqlstm.sqadto[0] = (unsigned short )0;
      sqlstm.sqtdso[0] = (unsigned short )0;
      sqlstm.sqphsv = sqlstm.sqhstv;
      sqlstm.sqphsl = sqlstm.sqhstl;
      sqlstm.sqphss = sqlstm.sqhsts;
      sqlstm.sqpind = sqlstm.sqindv;
      sqlstm.sqpins = sqlstm.sqinds;
      sqlstm.sqparm = sqlstm.sqharm;
      sqlstm.sqparc = sqlstm.sqharc;
      sqlstm.sqpadto = sqlstm.sqadto;
      sqlstm.sqptdso = sqlstm.sqtdso;
      sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
      if (sqlca.sqlcode < 0) goto Error;
}

  
      /* EXEC SQL CONTEXT USE :iCtx; */ 
 
      /* EXEC SQL CONNECT :iCntStr; */ 

{
      struct sqlexd sqlstm;
      sqlstm.sqlvsn = 12;
      sqlstm.arrsiz = 4;
      sqlstm.sqladtp = &sqladt;
      sqlstm.sqltdsp = &sqltds;
      sqlstm.iters = (unsigned int  )10;
      sqlstm.offset = (unsigned int  )39;
      sqlstm.cud = sqlcud0;
      sqlstm.sqlest = (unsigned char  *)&sqlca;
      sqlstm.sqlety = (unsigned short)4352;
      sqlstm.occurs = (unsigned int  )0;
      sqlstm.sqhstv[0] = (unsigned char  *)&iCntStr;
      sqlstm.sqhstl[0] = (unsigned long )202;
      sqlstm.sqhsts[0] = (         int  )202;
      sqlstm.sqindv[0] = (         short *)0;
      sqlstm.sqinds[0] = (         int  )0;
      sqlstm.sqharm[0] = (unsigned long )0;
      sqlstm.sqadto[0] = (unsigned short )0;
      sqlstm.sqtdso[0] = (unsigned short )0;
      sqlstm.sqphsv = sqlstm.sqhstv;
      sqlstm.sqphsl = sqlstm.sqhstl;
      sqlstm.sqphss = sqlstm.sqhsts;
      sqlstm.sqpind = sqlstm.sqindv;
      sqlstm.sqpins = sqlstm.sqinds;
      sqlstm.sqparm = sqlstm.sqharm;
      sqlstm.sqparc = sqlstm.sqharc;
      sqlstm.sqpadto = sqlstm.sqadto;
      sqlstm.sqptdso = sqlstm.sqtdso;
      sqlstm.sqlcmax = (unsigned int )100;
      sqlstm.sqlcmin = (unsigned int )2;
      sqlstm.sqlcincr = (unsigned int )1;
      sqlstm.sqlctimeout = (unsigned int )0;
      sqlstm.sqlcnowait = (unsigned int )0;
      sqlcxt(&iCtx, &sqlctx, &sqlstm, &sqlfpn);
      if (sqlca.sqlcode < 0) goto Error;
}

 
      g_LoggerObj.log2(LOG_LEVEL_LOAD,    __FILE__, __FUNCTION__, __LINE__, 0, 1, "iCtx value %u", iCtx);
      this->iState = MEMBER_STATE_GOOD;

#if 0
      if(false == storeOciContext(&iCtx))
      {
         g_LoggerObj.log2(LOG_LEVEL_WARNING,    __FILE__, __FUNCTION__, __LINE__, 0, 1, "Unable to store the OCI Context for the connection");
      }
#endif
      return;

Error:
      g_LoggerObj.log2(LOG_LEVEL_DEBUG,    __FILE__, __FUNCTION__, __LINE__, 0, 1, "Could not connect to Oracle");
      this->iState = MEMBER_STATE_BAD;
      /* EXEC SQL CONTEXT FREE :iCtx; */ 

{
      struct sqlexd sqlstm;
      sqlstm.sqlvsn = 12;
      sqlstm.arrsiz = 4;
      sqlstm.sqladtp = &sqladt;
      sqlstm.sqltdsp = &sqltds;
      sqlstm.stmt = "";
      sqlstm.iters = (unsigned int  )1;
      sqlstm.offset = (unsigned int  )70;
      sqlstm.cud = sqlcud0;
      sqlstm.sqlest = (unsigned char  *)&sqlca;
      sqlstm.sqlety = (unsigned short)4352;
      sqlstm.occurs = (unsigned int  )0;
      sqlstm.sqhstv[0] = (unsigned char  *)&iCtx;
      sqlstm.sqhstl[0] = (unsigned long )sizeof(void *);
      sqlstm.sqhsts[0] = (         int  )0;
      sqlstm.sqindv[0] = (         short *)0;
      sqlstm.sqinds[0] = (         int  )0;
      sqlstm.sqharm[0] = (unsigned long )0;
      sqlstm.sqadto[0] = (unsigned short )0;
      sqlstm.sqtdso[0] = (unsigned short )0;
      sqlstm.sqphsv = sqlstm.sqhstv;
      sqlstm.sqphsl = sqlstm.sqhstl;
      sqlstm.sqphss = sqlstm.sqhsts;
      sqlstm.sqpind = sqlstm.sqindv;
      sqlstm.sqpins = sqlstm.sqinds;
      sqlstm.sqparm = sqlstm.sqharm;
      sqlstm.sqparc = sqlstm.sqharc;
      sqlstm.sqpadto = sqlstm.sqadto;
      sqlstm.sqptdso = sqlstm.sqtdso;
      sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
      if (sqlca.sqlcode < 0) goto Error;
}

 
      this->iCtx = NULL ;

      /* EXEC SQL WHENEVER SQLERROR CONTINUE; */ 
 

      char l_text[200];
      memset(l_text, '\0', 200);
      strncpy(l_text, sqlca.sqlerrm.sqlerrmc, strlen(sqlca.sqlerrm.sqlerrmc));
      l_text[strlen(l_text)-1] = '\0';
      g_LoggerObj.log2(LOG_LEVEL_DEBUG,    __FILE__, __FUNCTION__, __LINE__, 0, 1, "Errno: %d %s", sqlca.sqlcode, l_text);
   } while(m_tryToConnectAttempt > 0);


   return;
}

ConnectionObject::~ConnectionObject()
{
   g_LoggerObj.log2(LOG_LEVEL_DEBUG, __FILE__, __FUNCTION__, __LINE__, 0, 1, "ConnectionObject des");
   if (this->iCtx!=NULL)	
   {
      /* EXEC SQL COMMIT WORK RELEASE; */ 

{
      struct sqlexd sqlstm;
      sqlstm.sqlvsn = 12;
      sqlstm.arrsiz = 4;
      sqlstm.sqladtp = &sqladt;
      sqlstm.sqltdsp = &sqltds;
      sqlstm.iters = (unsigned int  )1;
      sqlstm.offset = (unsigned int  )89;
      sqlstm.cud = sqlcud0;
      sqlstm.sqlest = (unsigned char  *)&sqlca;
      sqlstm.sqlety = (unsigned short)4352;
      sqlstm.occurs = (unsigned int  )0;
      sqlcxt(&iCtx, &sqlctx, &sqlstm, &sqlfpn);
}


      /* EXEC SQL CONTEXT FREE :iCtx; */ 

{
      struct sqlexd sqlstm;
      sqlstm.sqlvsn = 12;
      sqlstm.arrsiz = 4;
      sqlstm.sqladtp = &sqladt;
      sqlstm.sqltdsp = &sqltds;
      sqlstm.stmt = "";
      sqlstm.iters = (unsigned int  )1;
      sqlstm.offset = (unsigned int  )104;
      sqlstm.cud = sqlcud0;
      sqlstm.sqlest = (unsigned char  *)&sqlca;
      sqlstm.sqlety = (unsigned short)4352;
      sqlstm.occurs = (unsigned int  )0;
      sqlstm.sqhstv[0] = (unsigned char  *)&iCtx;
      sqlstm.sqhstl[0] = (unsigned long )sizeof(void *);
      sqlstm.sqhsts[0] = (         int  )0;
      sqlstm.sqindv[0] = (         short *)0;
      sqlstm.sqinds[0] = (         int  )0;
      sqlstm.sqharm[0] = (unsigned long )0;
      sqlstm.sqadto[0] = (unsigned short )0;
      sqlstm.sqtdso[0] = (unsigned short )0;
      sqlstm.sqphsv = sqlstm.sqhstv;
      sqlstm.sqphsl = sqlstm.sqhstl;
      sqlstm.sqphss = sqlstm.sqhsts;
      sqlstm.sqpind = sqlstm.sqindv;
      sqlstm.sqpins = sqlstm.sqinds;
      sqlstm.sqparm = sqlstm.sqharm;
      sqlstm.sqparc = sqlstm.sqharc;
      sqlstm.sqpadto = sqlstm.sqadto;
      sqlstm.sqptdso = sqlstm.sqtdso;
      sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
}

 
   }
}



void breakTheCall()
{
   g_LoggerObj.log2(LOG_LEVEL_LOAD, __FILE__, __FUNCTION__, __LINE__, 0, 1, "breakTheCall called with threadid:%d", pthread_self());

   map<int, dbdata*>::iterator l_it;
   l_it = g_dbCtxtMap.find(pthread_self());
   if (l_it != g_dbCtxtMap.end())
   {
      g_LoggerObj.log2(LOG_LEVEL_LOAD, __FILE__, __FUNCTION__, __LINE__, 0, 1, "Calling OCIBreak");

      int retcode = OCIBreak( (dvoid *)l_it->second->m_oci_svc, (OCIError *)l_it->second->m_oci_err);
      if (SQL_SUCCESS == retcode)
      {
         g_LoggerObj.log2(LOG_LEVEL_LOAD,    __FILE__, __FUNCTION__, __LINE__, 0, 1, "OCIBreak success");
      }
      else
      {
         g_LoggerObj.log2(LOG_LEVEL_LOAD,    __FILE__, __FUNCTION__, __LINE__, 0, 1, "OCIBreak failure retcode:%d", retcode);
      }
   }
   else
   {
      g_LoggerObj.log2(LOG_LEVEL_ERROR, __FILE__, __FUNCTION__, __LINE__, 0, 1, "Thread not found int the DBContextMAP");
   }
}

bool storeOciContext(sql_context *p_sc)
{
   OCIEnv *oeh;
   OCISvcCtx *l_svc=NULL;
   OCIError *l_err=NULL;
   int retcode = SQLEnvGet(*p_sc, &oeh);
   if (SQL_SUCCESS == retcode)
   {
      g_LoggerObj.log2(LOG_LEVEL_LOAD,    __FILE__, __FUNCTION__, __LINE__, 0, 1, "Getting OCIEnv success");
      retcode = OCIHandleAlloc((dvoid *)oeh, (dvoid **)&l_err, (ub4)OCI_HTYPE_ERROR, (ub4)0, (dvoid **)0);
      if(SQL_SUCCESS == retcode)
      {
         g_LoggerObj.log2(LOG_LEVEL_LOAD,    __FILE__, __FUNCTION__, __LINE__, 0, 1, "Getting OCIHandleAlloc success");

         retcode = SQLSvcCtxGet(*p_sc, (text*)"", -1, &l_svc);
         if(SQL_SUCCESS == retcode)
         {
            g_LoggerObj.log2(LOG_LEVEL_LOAD,    __FILE__, __FUNCTION__, __LINE__, 0, 1, "Getting SQLSvcCtxGet success");

            dbdata *l_db = new dbdata;
            l_db->m_oci_svc = l_svc;
            l_db->m_oci_err = l_err;

            pthread_mutex_lock(&g_dbMapMutex);
            g_dbCtxtMap[pthread_self()]=l_db;
            pthread_mutex_unlock(&g_dbMapMutex);

            LLOG(0,1,"placed at threadid:%d", pthread_self());
            return true;
         }
         else
         {
            g_LoggerObj.log2(LOG_LEVEL_LOAD,    __FILE__, __FUNCTION__, __LINE__, 0, 1, "Getting SQLSvcCtxGet failure retcode:%d", retcode);
            return false;
         }
      }
      else
      {
         g_LoggerObj.log2(LOG_LEVEL_LOAD,    __FILE__, __FUNCTION__, __LINE__, 0, 1, "Getting OCIHandleAlloc failure retcode:%d", retcode);
         return false;
      }
   }
   else
   {
      g_LoggerObj.log2(LOG_LEVEL_LOAD,    __FILE__, __FUNCTION__, __LINE__, 0, 1, "Getting OCIEnv failure retcode:%d", retcode);
      return false;
   }
   return false;
}

bool removeContext()
{
   pthread_mutex_lock(&g_dbMapMutex);
   map<int, dbdata*>::iterator l_it;
   l_it = g_dbCtxtMap.find(pthread_self());
   if (l_it != g_dbCtxtMap.end())
   {
      g_dbCtxtMap.erase(l_it);
      LLOG(0,1,"Removed the context from the DB map. Size:%d", g_dbCtxtMap.size());
   }
   else
   {
      WLOG(0,1,"Could not find the context in the DB map");
   }
   pthread_mutex_unlock(&g_dbMapMutex);
   return true;
}


bool checkConnection()
{
   TLOG(0,1,"checkConnection called");

   map<int, dbdata*>::iterator l_it;
   l_it = g_dbCtxtMap.find(pthread_self());
   if (l_it != g_dbCtxtMap.end())
   {
      g_LoggerObj.log2(LOG_LEVEL_LOAD, __FILE__, __FUNCTION__, __LINE__, 0, 1, "Calling OCIPing");

      int retcode = OCIPing( (OCISvcCtx *)l_it->second->m_oci_svc, (OCIError *)l_it->second->m_oci_err, (ub4)OCI_DEFAULT);
      if (SQL_SUCCESS == retcode)
      {
         g_LoggerObj.log2(LOG_LEVEL_LOAD,    __FILE__, __FUNCTION__, __LINE__, 0, 1, "checkConnection OCIPing success");
         return true;
      }
      else
      {
         g_LoggerObj.log2(LOG_LEVEL_LOAD,    __FILE__, __FUNCTION__, __LINE__, 0, 1, "checkConnection OCIPing failure retcode:%d", retcode);
         return false;
      }
   }
   else
   {
      g_LoggerObj.log2(LOG_LEVEL_ERROR, __FILE__, __FUNCTION__, __LINE__, 0, 1, "checkConnection Thread not found int the DBContextMAP");
      return false;
   }
   return false;
}

