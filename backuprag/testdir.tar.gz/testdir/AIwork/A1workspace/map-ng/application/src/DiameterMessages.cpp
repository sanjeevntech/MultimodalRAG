#include <Logger.h>
#include <DiameterMessages.h>
#include <ServiceCoordinator.h>

//ITS specific
#include <diameter/Command.h>
#include <dia_defines.h>
#include <diameter/Exceptions.h>
//End of ITS specific




char g_DiameterEventType[DIAM_EVENT_MAXIMUM+1][50] = 
{
   "DIAM_EVENT_UNKNOWN",
   "DIAM_EVENT_REQUEST",
   "DIAM_EVENT_ANSWER",
   "DIAM_EVENT_ERROR",
   "DIAM_EVENT_TIME_OUT",
   "DIAM_EVENT_AUTH_LIFE_TIME_OUT",
   "DIAM_EVENT_AUTH_GRACE_TIME_OUT",
   "DIAM_EVENT_CORRUPTED_MSG",
   "DIAM_EVENT_ACCT_INTERIM_TIME_OUT",
   "DIAM_EVENT_MAXIMUM"
};


DiameterMsg::DiameterMsg(char *p_sessionId, EDiameterEventType p_DiamMsgType, EDiameterCommandCode p_commCode) : Msg(MSG_TYPE_DIAMETER)
{
   m_cmd=NULL;
   m_det=p_DiamMsgType;
   m_commandCode=p_commCode;
   m_allocatedFlag=false;
   snprintf(m_sessionId, sizeof(m_sessionId), "%s", p_sessionId);
   m_sessionIndex=-1;
   DLOG(0,1,"DiameterMsg :cons: [%s]", m_sessionId);
   //m_applicationId = 0;
   memset(&m_oldTv2,'\0',sizeof(m_oldTv2));
   memset(&m_pTv2,'\0',sizeof(m_pTv2));
   memset(&m_rTv2,'\0',sizeof(m_rTv2));
}

DiameterMsg::DiameterMsg(char *p_sessionId, EDiameterEventType p_DiamMsgType) : Msg(MSG_TYPE_DIAMETER)
{
   m_cmd=NULL;
   m_det=p_DiamMsgType;
   m_allocatedFlag=false;
   m_commandCode=DIAM_COMM_CODE_UNKNOWN;
   snprintf(m_sessionId, sizeof(m_sessionId), "%s", p_sessionId);
   m_sessionIndex=-1;
   DLOG(0,1,"DiameterMsg :cons:2 [%s]", m_sessionId);
   //m_applicationId = 0;
   memset(&m_oldTv2,'\0',sizeof(m_oldTv2));
   memset(&m_pTv2,'\0',sizeof(m_pTv2));
   memset(&m_rTv2,'\0',sizeof(m_rTv2));
}


DiameterMsg::~DiameterMsg()
{
   DLOG(0,1,"~DiameterMsg :des: [%s]", m_sessionId);
   if(true == m_allocatedFlag)
   {
      if(NULL != m_cmd)
      {
         DLOG(0,1,"~DiameterMsg deleting command too");
         diameter::CommandImpl *l_ci = NULL;
         l_ci =(diameter::CommandImpl *)m_cmd;
         if(NULL != l_ci)
         {
            DLOG(0,1,"~DiameterMsg verymuch deleting");
            delete(l_ci);
            m_cmd=NULL;
         }
      }
   }
   else
   {
      DLOG(0,1,"DiameterMsg. not allocated. hence not deleting");
   }
}


char *DiameterMsg::getMsgTypeName()
{
   //diameter::Command *l_cmd = (diameter::Command*)m_cmd;
   return g_DiameterEventType[m_det];
}


