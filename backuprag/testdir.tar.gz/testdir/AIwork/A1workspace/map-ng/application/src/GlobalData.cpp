#include <GlobalData.h>
#include <StatisticsInterface.h>
#include <Logger.h>
#include <map>
#include <ModuleManager.h>

char g_selfIpAddress[15+1];
char g_selfEntityNameString[20+1];
int  g_selfIpPort;
char g_DeploymentType;

TagValuePair *g_tvp=NULL;

map<string,int> g_globalMap;

GlobalData::GlobalData()
{
   m_lastUpdatedDate=0;
}

GlobalData::~GlobalData()
{
}

void GlobalData::getStats(char *p_output)
{
}


CommonDataBase::CommonDataBase()
{
   m_lastUpdatedDate=0;
}

CommonDataBase::~CommonDataBase()
{
}

bool CommonDataBase::isValidEntity(char *p_ip, char *p_name)
{
   ELOG(0,1,"Invalid caller");
   return false;
}


void CommonDataBase::getStats(char *p_output)
{
}

bool CommonDataBase::statisticsCallback(StatisticsGenerator *p_sg)
{
   ELOG(0,0,"CommonDataBase::statisticsCallback is being called. Please check");
   return false;
}

bool validateConfigurationData(TagValuePair *p_tvp, int p_flag, char *p_errorDesc, int p_maxErrorDescLength, char *p_module)
{
   // p_flag - 0 - reloading time, 1 - only validation
   LLOG(0,0,"validateConfigurationData called");
   for (int l_i=1; l_i<MAX_MODULES; l_i++)
   {
      if(true == g_mm.m_modules[l_i].m_configPresent)
      {
         if(NULL != p_module)
         {
            if(0 != strcmp(p_module, (char*)g_mm.m_modules[l_i].m_moduleOverridedName.c_str()))
            {
               TLOG(0,0,"Incoming Module [%s]. So ignoring the module [%s]", p_module, (char*)g_mm.m_modules[l_i].m_moduleOverridedName.c_str());
               continue;
            }

         }
         g_mm.m_modules[l_i].m_cr = NULL;
         LLOG(0,0,"Validating Configuration data of module %d %s %s", l_i, g_mm.m_modules[l_i].m_ModName, g_mm.m_modules[l_i].m_moduleOverridedName.c_str());
         ConfigReader *l_cr = NULL;
         l_cr = g_mm.m_modules[l_i].m_func()->getConfigReaderObj();
         LLOG(0,0,"here");
         char *l_tempModuleData = NULL;
         LLOG(0,0,"here");
         if(
             (0 == strcmp("LTS", g_mm.m_modules[l_i].m_moduleOverridedName.c_str())) ||   
             (0 == strcmp("UPS", g_mm.m_modules[l_i].m_moduleOverridedName.c_str())) ||
             (0 == strcmp("UGS", g_mm.m_modules[l_i].m_moduleOverridedName.c_str())) ||
             (0 == strcmp("CMS", g_mm.m_modules[l_i].m_moduleOverridedName.c_str())) ||
             (0 == strcmp("AUS", g_mm.m_modules[l_i].m_moduleOverridedName.c_str())) ||
             (0 == strcmp("OMS", g_mm.m_modules[l_i].m_moduleOverridedName.c_str())) ||
             (0 == strcmp("SMS", g_mm.m_modules[l_i].m_moduleOverridedName.c_str())) ||
             (0 == strcmp("SIS", g_mm.m_modules[l_i].m_moduleOverridedName.c_str())) ||
             (0 == strcmp("ICS", g_mm.m_modules[l_i].m_moduleOverridedName.c_str())) ||
             (0 == strcmp("SSS", g_mm.m_modules[l_i].m_moduleOverridedName.c_str())) ||
             (0 == strcmp("SCS", g_mm.m_modules[l_i].m_moduleOverridedName.c_str())) 
           )
         {
            LLOG(0,0,"SIMULATOR[%s]",g_mm.m_modules[l_i].m_moduleOverridedName.c_str());
            l_tempModuleData = getenv("SIM_MODULE_DATA");
            LLOG(0,0,"SIM module data");
         }
         if (l_cr != NULL)
         {
           if(NULL == l_tempModuleData)
           {
            LLOG(0,0,"ConfigReader object present for module %s", g_mm.m_modules[l_i].m_moduleOverridedName.c_str());
            map<string,TagValue*>::iterator l_iter = p_tvp->m_moduleData.find(g_mm.m_modules[l_i].m_moduleOverridedName);
            LLOG(0,0,"ConfigReader 1");
            if(l_iter == p_tvp->m_moduleData.end())
            {
               CLOG(0,0,"Module Configurations of the Module [%s] not found in the Configuration MAP", g_mm.m_modules[l_i].m_moduleOverridedName.c_str());
               snprintf(p_errorDesc, p_maxErrorDescLength, "Module Configurations of the Module [%s] not found in the Configuration MAP", g_mm.m_modules[l_i].m_moduleOverridedName.c_str());
               delete(l_cr);
               return false;
            }
            LLOG(0,0,"Filling 1");

            l_cr->m_DataString = "<";
            l_cr->m_DataString += g_mm.m_modules[l_i].m_ModName;
            l_cr->m_DataString += ">";
            LLOG(0,0,"Filling 2");

            TagValue *l_tv = l_iter->second;
            LLOG(0,0,"Filling 3");
            map<string,string>::iterator l_tv_iter;
            for(l_tv_iter=l_tv->m_data.begin(); l_tv_iter!=l_tv->m_data.end(); l_tv_iter++)
            {
               l_cr->m_DataString += "<";
               l_cr->m_DataString += l_tv_iter->first;
               l_cr->m_DataString += ">";
               l_cr->m_DataString += l_tv_iter->second;
               l_cr->m_DataString += "</";
               l_cr->m_DataString += l_tv_iter->first;
               l_cr->m_DataString += ">";
            }
            LLOG(0,0,"Filling 4");


            l_cr->m_DataString += "</";
            l_cr->m_DataString += g_mm.m_modules[l_i].m_ModName;
            l_cr->m_DataString += ">";

            LLOG(1,1,"Module[%s] ModuleConfigXML[%s]", g_mm.m_modules[l_i].m_ModName, (char*)l_cr->m_DataString.c_str());
          }
          else
          {
             LLOG(0,0,"MS module data");
             l_cr->m_DataString += l_tempModuleData;
          }


            //printf("\nReading Data");
            bool l_status = l_cr->readData();
            if (!l_status)
            {
               CLOG(0,0,"ERROR!! Reading Data of Configuration module [%s] failed", g_mm.m_modules[l_i].m_ModName);
               if(strlen(l_cr->m_errorDesc) > 0)
               {
                  snprintf(p_errorDesc, p_maxErrorDescLength, "Error in Loading Module [%s]: Error Message: %s", g_mm.m_modules[l_i].m_moduleOverridedName.c_str(), l_cr->m_errorDesc);
               }
               delete(l_cr);
               return false;
            }

            l_cr->m_lastUpdateDate = time(NULL);

            if(0 == p_flag)
            {
               g_mm.m_modules[l_i].m_cr = l_cr;
            }
            else
            {
               LLOG(0,0,"Deleting the config ptr");
               delete(l_cr);
            }
         }
         else
         {
            CLOG(0,0,"No Config Reader object returned");
            snprintf(p_errorDesc, p_maxErrorDescLength, "%s", "No Config Reader object returned");
            return false;
         }

      }
      else
      {
         LLOG(0,0,"Configuration not present for module %d %s", l_i, g_mm.m_modules[l_i].m_ModName);
      }
   }
   return true;
}

bool assignNewConfigurations()
{
   LLOG(0,0,"assignNewConfigurations called");
   for (int l_i=1; l_i<MAX_MODULES; l_i++)
   {
      if(true == g_mm.m_modules[l_i].m_configPresent)
      {
         if(NULL != g_mm.m_modules[l_i].m_cr)
         {
            LLOG(0,0,"Assigning the new pointers for Module [%s]", g_mm.m_modules[l_i].m_ModName);
            *((g_mm.m_modules[l_i].m_func)()->retrieveConfigReaderPtr()) = g_mm.m_modules[l_i].m_cr;
         }
         else
         {
            ELOG(0,0,"SEVERE ERROR!!! Configuration pointer is null for Module [%s]", g_mm.m_modules[l_i].m_ModName);
            return false;
         }
      }
   }
   return true;
}
