#include <DlgContext.h>
#include <Logger.h>
#include <ConfigReader.h>

DlgContext *g_DlgContexts;

DlgContext::DlgContext()
{
   m_DlgType = DLG_TYPE_UNKNOWN;
   m_DlgState = DLG_STATE_IDLE;
   m_UserDlgId =0;
   m_lastRequestedInvokeId=0;
   memset(m_UserInfoToBeSent, '\0', 50);
   m_UserInfoLength=0;
   m_firstContinuePassed=false;
   m_InitiatingApplCntxt = MAP_AC_UNKNOWN;
   m_InitiatingOpCode = MAP_OP_CODE_UNKNOWN;
   m_InitiatingMapVersion = MAP_V_UNKNOWN;
   m_IncomingApplCntxt = MAP_AC_UNKNOWN;
   m_IncomingOpCode = MAP_OP_CODE_UNKNOWN;
   m_IncomingMapVersion = MAP_V_UNKNOWN;
   m_ErrorExchangedFlag=false;
   m_ErrorCodeExchanged=MAP_ERROR_UNKNOWN;
   memset(&m_CustomizedSelfAddress, '\0', sizeof(m_CustomizedSelfAddress));
   m_CustomizedSelfAddress=g_ConfigData->i_NgConfigData.m_selfAddress;

   memset(m_tmp_remote_address, '\0', sizeof(m_tmp_remote_address));
   memset(m_tmp_local_address, '\0', sizeof(m_tmp_local_address));
   memset(&m_DestAddr, '\0', sizeof(m_DestAddr));
   m_dp_present_ind=0;
   memset(&m_dp, '\0', sizeof(m_dp));
   m_appl_id=0;
   m_IncomingSccpClass=0;
   m_NotLastCompExchanged=false;
   m_tdr=new TdrData;
   m_crossedNg=false;
   memset(m_remoteGT, '\0', sizeof(m_remoteGT));
}

void DlgContext::reset()
{
   //DLOG(0,1,"DlgContext::reset function called");
   m_DlgType = DLG_TYPE_UNKNOWN;
   m_DlgState = DLG_STATE_IDLE;
   m_UserDlgId =0;
   m_lastRequestedInvokeId=0;
   memset(m_UserInfoToBeSent, '\0', 50);
   m_UserInfoLength=0;
   m_firstContinuePassed=false;
   m_InitiatingApplCntxt = MAP_AC_UNKNOWN;
   m_InitiatingOpCode = MAP_OP_CODE_UNKNOWN;
   m_InitiatingMapVersion = MAP_V_UNKNOWN;
   m_IncomingApplCntxt = MAP_AC_UNKNOWN;
   m_IncomingOpCode = MAP_OP_CODE_UNKNOWN;
   m_IncomingMapVersion = MAP_V_UNKNOWN;
   m_ErrorExchangedFlag=false;
   m_ErrorCodeExchanged=MAP_ERROR_UNKNOWN;
   memset(&m_CustomizedSelfAddress, '\0', sizeof(m_CustomizedSelfAddress));
   m_CustomizedSelfAddress=g_ConfigData->i_NgConfigData.m_selfAddress;

   memset(m_tmp_remote_address, '\0', sizeof(m_tmp_remote_address));
   memset(m_tmp_local_address, '\0', sizeof(m_tmp_local_address));
   memset(&m_DestAddr, '\0', sizeof(m_DestAddr));
   m_dp_present_ind=0;
   memset(&m_dp, '\0', sizeof(m_dp));
   m_appl_id=0;
   m_IncomingSccpClass=0;
   m_NotLastCompExchanged=false;
   m_psm.m_InvokeId =-1;
   m_psm.m_OpCode=MAP_OP_CODE_UNKNOWN;

   if(NULL != m_tdr)
      delete(m_tdr);
   m_tdr = new TdrData;
   m_crossedNg=false;
}

int DlgContext::getNextInvokeId()
{
   if ( (++m_lastRequestedInvokeId) == m_psm.m_InvokeId)
   {
      return ++m_lastRequestedInvokeId;
   }
   else if ( m_lastRequestedInvokeId == m_rsm.m_InvokeId)
   {
      return ++m_lastRequestedInvokeId;
   }
   else
   {
      return m_lastRequestedInvokeId;
   }
}


DlgContext::~DlgContext()
{

}

Csm::Csm()
{
   m_InvokeId =-1;
   m_OpCode=MAP_OP_CODE_UNKNOWN;
}

Csm::~Csm()
{

}

