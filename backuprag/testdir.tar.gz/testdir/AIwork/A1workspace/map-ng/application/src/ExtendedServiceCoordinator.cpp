#include <CntxtMsc.h>
#include <ContextManager.h>
#include <MplManager.h>
#include <AsnCodec.h>
#include <MapConstants.h>
#include <Utilities.h>
#include <MessageQueue.h>
#include <SmppInterface.h>
#include <SnmpInterface.h>
#include <ExtContainerParser.h>
#include <DiameterMessages.h>
#include <DiametriqInterface.h>
#include <ExtendedServiceCoordinator.h>
#include <DiameterContextManager.h>
#include <ModuleManager.h>
#include <DiametriqInterface.h>
#include <SelfSimulator.h> //TODO:to be removed
#include <StatisticsInterface.h> 
#include <fstream>
#include <iostream>
#include <typeinfo>
using namespace std;

MessageQueue *g_InterModuleQueue2 = NULL;
extern MessageQueue *g_OamTransactionsList;


ExtendedServiceCoordinator g_esc;
DiameterContextManager     g_DiameterContextMangerObject;


std::string gulp(std::istream &in)
{
   std::string ret;
   char buffer[4096];
   while (in.read(buffer, sizeof(buffer)))
      ret.append(buffer, sizeof(buffer));
   ret.append(buffer, in.gcount());
   return ret;
}

ExtendedServiceCoordinator::ExtendedServiceCoordinator()
{
   DLOG(0,1,"ExtendedServiceCoordinator::ExtendedServiceCoordinator() created");
}


ExtendedServiceCoordinator::~ExtendedServiceCoordinator()
{
   DLOG(0,1,"ExtendedServiceCoordinator::~ExtendedServiceCoordinator() destroyed");
}


bool ExtendedServiceCoordinator::initialize(int p_MaxSessions)
{
   DLOG(0,1,"ExtendedServiceCoordinator::initialize() called with MaxSessions:%d", p_MaxSessions);
   if(false == g_DiameterContextMangerObject.initialize())
   {
      ELOG(0,1,"Unable to initialize DIAMETER Context Manager");
      return false;
   }
   return true;
}

int g_sessionId=0;

#if 0
bool ExtendedServiceCoordinator::allocateSession(EDiameterApplicationIdentifier p_dai, int& p_sessIndex, string& p_sessionId)
{
   //AllocateSession(16777251, sIdx, sessIdString);
   p_sessIndex = ++g_sessionId;
   char l_sessChar[20];
   snprintf(l_sessChar, sizeof(l_sessChar), "%d", g_sessionId);
   p_sessionId = (char*)"sess;" ;
   p_sessionId += l_sessChar;
   return true;
}
#else

bool ExtendedServiceCoordinator::allocateSession(EDiameterApplicationIdentifier p_dai, unsigned int& p_sessIndex, string& p_sessionId)
{
   //g_di.allocateSession(g_OtherConfigData->m_dcd.m_applicationId, p_sessIndex, p_sessionId);
   DLOG(0,0,"allocateSession called [%d].. incoming[%d]",g_OtherConfigData->m_dcd.m_applicationId,(int)p_dai); 
   g_di.allocateSession((ITS_UINT)p_dai, p_sessIndex, p_sessionId);
   if(0 == p_sessionId.size())
   {
      WLOG(0,1,"allocateSession failed");
      return false;
   }
   else
   {
      return true;
   }
   /*
      p_sessIndex = ++g_sessionId;
      char l_sessChar[20];
      snprintf(l_sessChar, sizeof(l_sessChar), "%d", g_sessionId);
      p_sessionId = (char*)"sess;" ;
      p_sessionId += l_sessChar;
      */
}
#endif


/*

   bool ExtendedServiceCoordinator::sendFailureMsg(DiameterMsg *p_IncomingMsg)
   {

   }
   */


void printPdu(diameter::Command *p_ci, char *p_direction)
{
   if(('C' == g_OtherConfigData->m_dcd.m_diamterPduPrintType) || ('B' == g_OtherConfigData->m_dcd.m_diamterPduPrintType))
   {
      cout<<p_direction<<"...."<<*p_ci;
   }
   if(('L' == g_OtherConfigData->m_dcd.m_diamterPduPrintType) || ('B' == g_OtherConfigData->m_dcd.m_diamterPduPrintType))
   {
      std::ostringstream out;
      out<<*p_ci;
      LLOG(1,1,"DIAMETER PDU %s: [%s]", p_direction, (char*)out.str().c_str());
   }
   return;
}
bool ExtendedServiceCoordinator::recvMsg(DiameterMsg *p_DiameterMsg)
{
   TLOG(0,1,"ExtendedServiceCoordinator::recvMsg DiameterMsg");

   try
   {
      //cout<<*((diameter::CommandImpl*)(p_DiameterMsg->m_cmd));
      ContextBase *l_cb = NULL;
      string l_sessionId = p_DiameterMsg->m_sessionId;//getSessionId(l_ci);

      //ostream in;
      //std::ostream os;
      //l_ci->print(std::cout);
      if(DIAM_EVENT_REQUEST == p_DiameterMsg->m_det)
      {
         diameter::CommandImpl *l_ci = (diameter::CommandImpl*)(p_DiameterMsg->m_cmd);
         //cout<<"Received ... "<<*(diameter::Command*)l_ci;
         TLOG(0,1,"SessionId %s", (char*)l_sessionId.c_str());
         l_cb = g_mm.getRespectiveContext2(p_DiameterMsg->m_commandCode, p_DiameterMsg);
         if(NULL != l_cb)
         {
            if(false == g_DiameterContextMangerObject.storeContext(l_sessionId, l_cb, DIALOGUE_RESPONDER))
            {
               ELOG(0,1,"SessionId%s DCM store context failed", (char*)l_sessionId.c_str());
               return false;
            }
            TLOG(0,1,"DCM Size:%d", g_DiameterContextMangerObject.getSize());

            //Set the parameters for the Context
            l_cb->setClassName((char*)(typeid(*(l_cb)).name()));
            l_cb->m_oldTv = p_DiameterMsg->m_oldTv2;
            l_cb->m_pTv   = p_DiameterMsg->m_pTv2;
            l_cb->m_rTv   = p_DiameterMsg->m_rTv2;
            int l_opCode=p_DiameterMsg->m_commandCode;
            if(8388622 == l_opCode)
            {
               l_opCode=350;
            }
            /*if(p_DiameterMsg->m_applicationId == 16777265)
            {
               l_opCode=9000+p_DiameterMsg->m_commandCode;
            }*/
            strcpy(l_cb->m_ModName,	    g_mm.m_mapping[MSG_TYPE_DIAMETER][l_opCode].m_ModName);
            strcpy(l_cb->m_MessageName, g_mm.m_mapping[MSG_TYPE_DIAMETER][l_opCode].m_MessageName);
            l_cb->m_ReferenceCount++;
            DLOG(0,1,"Ref Count incremented: %d",l_cb->m_ReferenceCount);


#if 1 //TODO to be removed
            //Adding TDR related things
            if(g_tfb != NULL)
            {
               //l_cb->m_tdr.setOpCode(p_DiameterMsg->m_commandCode);
               l_cb->m_tdr.setOpCode(l_opCode);
               //TDR_INDEX_NEW_RESERVED_EIGHT 164
               l_cb->m_tdr.setInteger(155,l_ci->getApplicationId());

               int l_tdrIndex = g_tfb->getTdrIndex(TDR_APP_REMOTE_HOST);
               if(l_tdrIndex >= 0)
               {
                  Identity l_originHost;
                  int l_origHostResult = l_ci->getAvpValue(264, 0, &l_originHost, IdentityType);
                  if(0 == l_origHostResult)
                  {
                     l_cb->m_tdr.setString(l_tdrIndex, (char*)l_originHost.c_str());
                  }
                  else
                  {
                     TLOG(0,1,"getAvpValue failed for AVP Code 264 (Origin-Host). Result code:%d", l_origHostResult);
                  }
               }

               l_tdrIndex = g_tfb->getTdrIndex(TDR_APP_REMOTE_REALM);
               if(l_tdrIndex >= 0)
               {
                  Identity l_originRealm;
                  int l_origRealmResult = l_ci->getAvpValue(296, 0, &l_originRealm, IdentityType);
                  if(0 == l_origRealmResult)
                  {
                     l_cb->m_tdr.setString(l_tdrIndex, (char*)l_originRealm.c_str());
                  }
                  else
                  {
                     TLOG(0,1,"getAvpValue failed for AVP Code 296 (Origin-Realm). Result code:%d", l_origRealmResult);
                  }
               }
            printPdu((diameter::Command*)l_ci, "Rcvd");

               //p_CntxtMscPtr->m_pRsc->m_tdr.setMapVersion((int)p_CntxtMscPtr->getOpenIndPtr()->m_Version);
               //p_CntxtMscPtr->m_pRsc->m_tdr.setRemoteAddrSsn(((MapOpenInd*)p_CntxtMscPtr->getOpenIndPtr())->m_OrigAddr.ssn);
               l_cb->m_tdr.setOriginatingModule("NWK");
            }
#endif
            //End of TDR related things
         }
         else
         {
            ELOG(0,1,"SessionId%s No Context to be created for Command Code: %d", (char*)l_sessionId.c_str(), p_DiameterMsg->m_commandCode);
            g_di.sendErrorResponse((const diameter::CommandImpl*)p_DiameterMsg->m_cmd, 0, DIAM_RESULT_CODE_UNABLE_TO_COMPLY);
            return false;
         }
      }
      else
      {
         diameter::CommandImpl *l_ci = (diameter::CommandImpl*)(p_DiameterMsg->m_cmd);
         //TODO: retrieve the context

         if(false == g_DiameterContextMangerObject.getContext(l_sessionId, (void**)&l_cb))
         {
            ELOG(0,1,"SessionId%s Unable to retrieve the context", (char*)l_sessionId.c_str());
            delete(p_DiameterMsg);
            return false;
         }
         if(false == g_DiameterContextMangerObject.removeContext(l_sessionId, DIALOGUE_RESPONDER))//TODO: not responder
         {
            ELOG(0,1,"SessionId%s already removed", (char*)l_sessionId.c_str());
            delete(p_DiameterMsg);
            return false;
         }
         if(l_cb != NULL)
         {
            l_cb->m_ReferenceCount--; //Response received; hence decremented
            DLOG(0,1,"Ref Count decremented: %d",l_cb->m_ReferenceCount);
            TLOG(0,1,"SessionId%s Command is response", (char*)l_sessionId.c_str());
         }
         else
         {
            ELOG(0,1,"Unable to find SessionId%s", (char*)l_sessionId.c_str());
         }


         if(DIAM_EVENT_ANSWER == p_DiameterMsg->m_det)
         { //To update the Success statistics
            int l_rc_int=0;
            int l_resultCodeResult = l_ci->getAvpValue(268, 0, &l_rc_int, Unsigned32Type);
            if(0 == l_resultCodeResult)
            {
               if((l_rc_int >= DIAM_RESULT_CODE_SUCCESS) && (l_rc_int <= DIAM_RESULT_CODE_SUCCESS_MAX_RANGE))
               {
                  DLOG(0,1,":stats: Success");
                  if(DIAM_COMM_CODE_SLH_RIR_RIA == p_DiameterMsg->m_commandCode)
                  {
                     HLRStatisticsInitializer::instance()->logStatistics(g_di.m_dsi.m_InitiatingCommands[8].m_SuccessCount);
                  }
                  else if(((p_DiameterMsg->m_commandCode >= DIAM_COMM_CODE_CX_DX_UAR_UAA) && (p_DiameterMsg->m_commandCode <= DIAM_COMM_CODE_SH_PNR_PNA)))
		  {
			  int l_appId = l_ci->getApplicationId();	
		          LLOG(0,1,"Stats Application Id %d",l_appId);
			  if ( l_appId == DIAM_APP_ID_SWX)
			  {
				  HLRStatisticsInitializer::instance()->logStatistics(g_di.m_dsi.m_InitiatingCommands[p_DiameterMsg->m_commandCode-280].m_SuccessCount);
			  }
			  else
			  {
				  HLRStatisticsInitializer::instance()->logStatistics(g_di.m_dsi.m_InitiatingCommands[p_DiameterMsg->m_commandCode-290].m_SuccessCount);
			  }

		  }
                  else
                  {
                     HLRStatisticsInitializer::instance()->logStatistics(g_di.m_dsi.m_InitiatingCommands[p_DiameterMsg->m_commandCode-DIAM_COMM_CODE_S6A_S6D_ULR_ULA].m_SuccessCount);
                  }
               }
               else
               {
                  DLOG(0,1,"stats not updating success %d", l_rc_int);
               }
            }
            else
            {
               TLOG(0,1,"getAvpValue failed for AVP Code 268 (Result-Code). Result code:%d", l_resultCodeResult);
            }
         }
      }
      DLOG(0,1,"LINE");
      if(NULL != l_cb)
      {
         l_cb->CallProcMsg((Msg*)p_DiameterMsg); //Relay the message 

         if(0 == l_cb->m_ReferenceCount)
         {
            LLOG(0,1,"Deleting Context in recvMsg Diameter");
            delete(l_cb);
            l_cb=NULL;
         }
      }
      else
      {
         ELOG(0,1,"SessionId%s Still l_cb is NULL. This should not occur", (char*)l_sessionId.c_str());
      }
   }
   catch (NoSuchAttributeException e)
   {
      ELOG(0,1,"ERROR!! Exception NoSuchAttributeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
   }
   catch (WrongCommandTypeException e)
   {
      ELOG(0,1,"ERROR!! Exception WrongCommandTypeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
   }
   catch (UnknownTypeException e)
   {
      ELOG(0,1,"ERROR!! Exception UnknownTypeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
   }
   catch (CodecException e)
   {
      ELOG(0,1,"ERROR!! Exception CodecException Caught: %s ,Error Cause: %s ",e.name(), e.what());
   }
   catch(...)
   {
      ELOG(0,1,"ERROR!! Very Unknown Exception");
      return false;
   }
   return true;
}


bool ExtendedServiceCoordinator::sendMsg(ContextBase *p_ContextBasePtr, DiameterMsg *p_DiameterMsg)
{
   LLOG(0,1,"ExtendedServiceCoordinator::sendMsg DiameterMsg");
   try
   {
      if(NULL != p_DiameterMsg->m_cmd)
      {
         diameter::Command *l_ci = (diameter::Command*)(p_DiameterMsg->m_cmd);
         string l_sessionId = p_DiameterMsg->m_sessionId;//getSessionId(*l_ci);
         p_ContextBasePtr->m_tdr.setInteger(155,l_ci->getApplicationId());
         if(DIAM_EVENT_REQUEST == p_DiameterMsg->m_det)
         {
            DLOG(0,1,"sendMsg DIAM_EVENT_REQUEST");
            if(false == g_DiameterContextMangerObject.storeContext(l_sessionId, p_ContextBasePtr, DIALOGUE_INITIATOR))
            {
               ELOG(0,1,"SessionId%s Unable to store the context", (char*)l_sessionId.c_str());
               return false;
            }
            p_ContextBasePtr->m_ReferenceCount++;
            int l_tdrIndex = g_tfb->getTdrIndex(TDR_APP_LOCAL_HOST);
            if(l_tdrIndex > 0)
            {
               Identity l_originHost("");
               int l_originHostResult = l_ci->getAvpValue(264, &l_originHost, IdentityType); 
               DLOG(0,0,"Orighost[%s]",(char*)l_originHost.c_str());
               u8 l_translatedHost[100+1];
               memset(l_translatedHost, '\0', sizeof(l_translatedHost));
               GetTranslatedHostAddr(l_translatedHost,(u8*)l_originHost.c_str());
               Identity l_TransHost((const char*)l_translatedHost);
               DLOG(0,0,"TranslatedHost[%s]",(char*)l_TransHost.c_str());
               l_ci->removeAVP(264,0);
               l_ci->addAVP(264,0, &l_TransHost, true, IdentityType);
               //p_ContextBasePtr->m_tdr.setString(l_tdrIndex, (char*)l_TransHost.c_str());
               p_ContextBasePtr->m_tdr.setString(l_tdrIndex, (char*)l_translatedHost);
            }

            l_tdrIndex = g_tfb->getTdrIndex(TDR_APP_REMOTE_HOST);
            if(l_tdrIndex > 0)
            {
               Identity l_destHost;
               int l_destHostResult = l_ci->getAvpValue(293, &l_destHost, IdentityType); //TODO: remove hard-code
               if(0 == l_destHostResult)
               {
                  p_ContextBasePtr->m_tdr.setString(l_tdrIndex, (char*)l_destHost.c_str());
               }
               else
               {
                  TLOG(0,1,"getAvpValue failed for AVP Code 293 (Dest-Host). Result code:%d", l_destHostResult);
               }
            }

            l_tdrIndex = g_tfb->getTdrIndex(TDR_APP_REMOTE_REALM);
            if(l_tdrIndex > 0)
            {
               Identity l_destRealm;
               int l_destRealmResult = l_ci->getAvpValue(283, &l_destRealm, IdentityType); //TODO: remove hard-code
               if(0 == l_destRealmResult)
               {
                  p_ContextBasePtr->m_tdr.setString(l_tdrIndex, (char*)l_destRealm.c_str());
               }
               else
               {
                  TLOG(0,1,"getAvpValue failed for AVP Code 283 (Dest-Realm). Result code:%d", l_destRealmResult);
               }
            }
            printPdu(l_ci, "Sent");
            if(1)
            {
               if(DIAM_COMM_CODE_SLH_RIR_RIA == p_DiameterMsg->m_commandCode)
               {
                  HLRStatisticsInitializer::instance()->logStatistics(g_di.m_dsi.m_InitiatingCommands[8].m_TotalCount);
               }
               else if(((p_DiameterMsg->m_commandCode >= DIAM_COMM_CODE_CX_DX_UAR_UAA) && (p_DiameterMsg->m_commandCode <= DIAM_COMM_CODE_SH_PNR_PNA)))
	       {
		       int l_appId = l_ci->getApplicationId();						
		       LLOG(0,1,"Stats Application Id %d",l_appId);
		       if ( l_appId == DIAM_APP_ID_SWX)
		       {
			       HLRStatisticsInitializer::instance()->logStatistics(g_di.m_dsi.m_InitiatingCommands[p_DiameterMsg->m_commandCode-280].m_TotalCount);
		       }
		       else
		       {
			       HLRStatisticsInitializer::instance()->logStatistics(g_di.m_dsi.m_InitiatingCommands[p_DiameterMsg->m_commandCode-290].m_TotalCount);
		       }

	       }
               else
               {
                  HLRStatisticsInitializer::instance()->logStatistics(g_di.m_dsi.m_InitiatingCommands[p_DiameterMsg->m_commandCode-DIAM_COMM_CODE_S6A_S6D_ULR_ULA].m_TotalCount);
               }
               int l_ret = g_di.sendDiaAppMsg(*((diameter::Command*)p_DiameterMsg->m_cmd), 0);
               LLOG(0,1,"Sending DIAMETER message to stack return code: %d", l_ret);
            }
            else
            {

               //TODO: to be removed once interfacing with NG
               Msg *l_msg=NULL;
               try
               {
                  g_selfSimObj->getMessage(p_DiameterMsg->m_commandCode, &l_msg, (Msg*)p_DiameterMsg);
               }
               catch (NoSuchAttributeException e)
               {
                  ELOG(0,1,"ERROR!! Exception NoSuchAttributeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
               }
               catch (WrongCommandTypeException e)
               {
                  ELOG(0,1,"ERROR!! Exception WrongCommandTypeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
               }
               catch (UnknownTypeException e)
               {
                  ELOG(0,1,"ERROR!! Exception UnknownTypeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
               }
               catch (CodecException e)
               {
                  ELOG(0,1,"ERROR!! Exception CodecException Caught: %s ,Error Cause: %s ",e.name(), e.what());
               }
               catch(...)
               {
                  ELOG(0,1,"ERROR!! Exception occurred in getMessage");
               }

               if(NULL != l_msg)
               {
                  g_esc.recvMsg((DiameterMsg*)l_msg);
               }
               else
               {
                  ELOG(0,1,"SessionId%s response message is null", (char*)l_sessionId.c_str());
               }
            }
         }
         else
         {
            int l_tdrIndex = g_tfb->getTdrIndex(TDR_APP_LOCAL_HOST);
            if(l_tdrIndex > 0)
            {
               Identity l_originHost("");
               int l_originHostResult = l_ci->getAvpValue(264, &l_originHost, IdentityType); 
               DLOG(0,0,"Orighost[%s]",(char*)l_originHost.c_str());
               u8 l_translatedHost[100+1];
               memset(l_translatedHost, '\0', sizeof(l_translatedHost));
               GetTranslatedHostAddr(l_translatedHost,(u8*)l_originHost.c_str());
               Identity l_TransHost((const char*)l_translatedHost);
               DLOG(0,0,"TranslatedHost[%s]",(char*)l_TransHost.c_str());
               l_ci->removeAVP(264,0);
               l_ci->addAVP(264,0, &l_TransHost, true, IdentityType);
               //p_ContextBasePtr->m_tdr.setString(l_tdrIndex, (char*)l_TransHost.c_str());
               p_ContextBasePtr->m_tdr.setString(l_tdrIndex, (char*)l_translatedHost);
            }

            l_tdrIndex = g_tfb->getTdrIndex(TDR_APP_LOCAL_REALM);
            if(l_tdrIndex > 0)
            {
               Identity l_originRealm;
               int l_originRealmResult = l_ci->getAvpValue(296, &l_originRealm, IdentityType); //TODO: remove hard-code
               if(0 == l_originRealmResult)
               {
                  if(0 == l_originRealm.size())
                  {
                     ELOG(0,1,"Origin-realm not set by the application");
                     l_originRealm = g_OtherConfigData->m_dcd.m_originRealm;
                     l_ci->addAVP(296,0, &l_originRealm, true, IdentityType);
                  }
                  p_ContextBasePtr->m_tdr.setString(l_tdrIndex, (char*)l_originRealm.c_str());
               }
               else
               {
                  TLOG(0,1,"getAvpValue failed for AVP Code 296 (Origin-Realm). Result code:%d", l_originRealmResult);
               }
            }

            if(DIAM_EVENT_ANSWER == p_DiameterMsg->m_det)
            { //To update the Responding success statistics
               unsigned int l_rc_int=0;
               int l_resultCodeResult = l_ci->getAvpValue(268, &l_rc_int, Unsigned32Type);
               if(0 == l_resultCodeResult)
               {
                  if((l_rc_int >= DIAM_RESULT_CODE_SUCCESS) && (l_rc_int <= DIAM_RESULT_CODE_SUCCESS_MAX_RANGE))
                  {
                     DLOG(0,1,":stats: Success");
                     if(DIAM_COMM_CODE_SLH_RIR_RIA == p_DiameterMsg->m_commandCode)
                     {
                        HLRStatisticsInitializer::instance()->logStatistics(g_di.m_dsi.m_RespondingCommands[8].m_SuccessCount);
                     }
		     else if(((p_DiameterMsg->m_commandCode >= DIAM_COMM_CODE_CX_DX_UAR_UAA) && (p_DiameterMsg->m_commandCode <= DIAM_COMM_CODE_SH_PNR_PNA)))
		     { 
		       int l_appId = l_ci->getApplicationId(); 
		       LLOG(0,1,"Stats Application Id %d",l_appId);
			     if (l_appId == DIAM_APP_ID_SWX)
			     {
				     HLRStatisticsInitializer::instance()->logStatistics(g_di.m_dsi.m_RespondingCommands[p_DiameterMsg->m_commandCode-280].m_SuccessCount);
			     }
			     else
			     {
				     HLRStatisticsInitializer::instance()->logStatistics(g_di.m_dsi.m_RespondingCommands[p_DiameterMsg->m_commandCode-290].m_SuccessCount);
			     }
		     }
                     else
                     {
                        HLRStatisticsInitializer::instance()->logStatistics(g_di.m_dsi.m_RespondingCommands[p_DiameterMsg->m_commandCode-DIAM_COMM_CODE_S6A_S6D_ULR_ULA].m_SuccessCount);
                     }
                  }
                  else
                  {
                     DLOG(0,1,"stats not updating success %d", l_rc_int);
                  }
               }
               else
               {
                  TLOG(0,1,"getAvpValue failed for AVP Code 268 (Result-Code). Result code:%d", l_resultCodeResult);
               }
            }
            printPdu(l_ci, "Sent");
            struct timeval l_dummyTv;
            
	    LLOG(0,0,"SendMsg m_rTv: %ld.%ld", p_ContextBasePtr->m_rTv.tv_sec, p_ContextBasePtr->m_rTv.tv_usec);
            getTime(p_ContextBasePtr->m_rTv, l_dummyTv, NULL, NULL);

            int l_ret = g_di.sendDiaAppMsg(*((diameter::Command*)p_DiameterMsg->m_cmd), 0);
            string l_sessionId = p_DiameterMsg->m_sessionId;//getSessionId(*((diameter::Command*)p_DiameterMsg->m_cmd));
            LLOG(0,1,"Sending DIAMETER message to stack with sessionid:%s", (char*)l_sessionId.c_str());
            if(1 == g_OtherConfigData->m_dcd.m_DiastackLoggingFlag)
            {
               CLOG(0,1,"Sending DIAMETER message to stack with sessionid:%s", (char*)l_sessionId.c_str());
            }

            size_t l_Pos = l_sessionId.find(";");
            if (l_Pos != string::npos)
            {
               if(l_Pos+1 < l_sessionId.size())
               {
                  string l_tempSessionId = l_sessionId.substr(l_Pos+1);
                  DLOG(0,0,"Partitioned Session-Id [%s]",l_tempSessionId.c_str());
                  l_tdrIndex = g_tfb->getTdrIndex(TDR_APP_ORIGINATING_HLR_GT);
                  if(l_tdrIndex > 0)
                  {
                     p_ContextBasePtr->m_tdr.setString(l_tdrIndex+77, (char*)l_tempSessionId.c_str()); //Writes TDR in 181 index
                  }
               }
            }

            if(false == g_DiameterContextMangerObject.removeContext(l_sessionId, DIALOGUE_RESPONDER))//TODO: not responder
            {
               ELOG(0,1,"SessionId%s already removed", (char*)l_sessionId.c_str());
               return false;
            }
            TLOG(0,1,"DCM Size:%d", g_DiameterContextMangerObject.getSize());
            p_ContextBasePtr->m_ReferenceCount--;

         }
      }
   }
   catch (NoSuchAttributeException e)
   {
      ELOG(0,1,"ERROR!! Exception NoSuchAttributeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
   }
   catch (WrongCommandTypeException e)
   {
      ELOG(0,1,"ERROR!! Exception WrongCommandTypeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
   }
   catch (UnknownTypeException e)
   {
      ELOG(0,1,"ERROR!! Exception UnknownTypeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
   }
   catch (CodecException e)
   {
      ELOG(0,1,"ERROR!! Exception CodecException Caught: %s ,Error Cause: %s ",e.name(), e.what());
   }
   catch(...)
   {
      ELOG(0,1,"Exception occurred in sendMsg");
      return false;
   }
   return true;
}


bool ExtendedServiceCoordinator::initiateIndependentContext(ContextBase *p_presentContext, EDiameterCommandCode p_ccCode, char *p_parameters, EInitiationType p_it)
{
   TLOG(0,1,"ExtendedServiceCoordinator::initiateIndependentContext char initiating ...");

   if( strlen(p_parameters) > MAX_PARAM_STRING_SIZE )
   {
      ELOG(0,1,"Severe Error!! Invalid Parameters length %ld. Should be less than %d", strlen(p_parameters), MAX_PARAM_STRING_SIZE);
      return false;
   }

   InterModuleData *l_imd = new InterModuleData();
   l_imd->m_OpCode = p_ccCode;
   if(p_presentContext != NULL)
   {
      if(MAX_ORIG_MODULE_NAME_SIZE > 10)
      {
         sprintf(l_imd->m_OriginatorModule, "%s%s:%08d", 
               p_presentContext->m_ModName, 
               p_presentContext->m_MessageName,
               p_presentContext->m_GlobalContextId);
      }
      else
      {
         sprintf(l_imd->m_OriginatorModule, "%s%s", 
               p_presentContext->m_ModName, 
               p_presentContext->m_MessageName);
      }
   }
   else
   {
      sprintf(l_imd->m_OriginatorModule, "unknown");
   }

   DLOG(0,1,"length of the parameters [%d]", strlen(p_parameters));
   int l_Length = strlen(p_parameters);
   if(l_Length > 0)
   {
      l_imd->m_Parameters =  new char[l_Length + 500];
      snprintf(l_imd->m_Parameters,l_Length + 500,"%s",p_parameters);
   }
   DLOG(1,1,"Initiating a Context with Op Code: [%d] and Parameters: [%s]", p_ccCode, p_parameters);
   if(INITIATION_TYPE_IMMEDIATE == p_it)
   {
      return g_InterModuleQueue->push(l_imd);
   }
   else if(INITIATION_TYPE_TARDILY == p_it)
   {
      TLOG(0,1,"scheduling the context");
      if (false == g_OamTransactionsList->push(l_imd, sizeof(InterModuleData)))
      {
         WLOG(0,1,"No space in SystemV message. Pushing into normal queue");
         return g_InterModuleQueue->push(l_imd);
      }
   }
   else
   {
      ELOG(0,1,"Unknown initiation type");
   }
   return false;
}


bool ExtendedServiceCoordinator::initiateIndependentContext(ContextBase *p_presentContext, EDiameterCommandCode p_ccCode, Msg *p_msgPtr)
{
   LLOG(0,1,"ExtendedServiceCoordinator::initiateIndependentContext msg initiating ...");

   if(NULL == p_msgPtr)
   {
      ELOG(0,1,"Severe Error!! Invalid Message passed to initiate a context");
      return false;
   }
   TLOG(0,1,"ExtendedServiceCoordinator::initiateIndependentContext start");

   InterModuleData *l_imd = new InterModuleData();
   l_imd->m_OpCode = p_ccCode;
   if(p_presentContext != NULL)
   {
      TLOG(0,1,"ExtendedServiceCoordinator::initiateIndependentContext not null");
      if(MAX_ORIG_MODULE_NAME_SIZE > 10)
      {
         sprintf(l_imd->m_OriginatorModule, "%s%s:%08d", p_presentContext->m_ModName, p_presentContext->m_MessageName,
               p_presentContext->m_GlobalContextId);
      }
      else
      {
         sprintf(l_imd->m_OriginatorModule, "%s%s", p_presentContext->m_ModName, p_presentContext->m_MessageName);
      }
   }
   else
   {
      TLOG(0,1,"ExtendedServiceCoordinator::initiateIndependentContext null");
      sprintf(l_imd->m_OriginatorModule, "unknown");
   }
   TLOG(0,1,"ExtendedServiceCoordinator::done");


   l_imd->m_msgPtr = p_msgPtr;
   LLOG(0,1,"Initiating a Context with Op Code: [%d]  MessageType [%d]", p_ccCode, l_imd->m_msgPtr->m_MsgType);
   return g_InterModuleQueue->push(l_imd);
}


bool ExtendedServiceCoordinator::initiateIndependentContextLikeNg(ContextBase *p_presentContext, EDiameterCommandCode p_ccCode, Msg *p_msgPtr)
{
   LLOG(0,1,"ExtendedServiceCoordinator::initiateIndependentContextLikeNg msg initiating ...");

   if(NULL == p_msgPtr)
   {
      ELOG(0,1,"Severe Error!! Invalid Message passed to initiate a context");
      return false;
   }
   TLOG(0,1,"ExtendedServiceCoordinator::initiateIndependentContextLikeNg start");

   ExtendedInterModuleData *l_imd = new ExtendedInterModuleData();
   l_imd->m_eimt = EXT_INTER_MOD_TYPE_LIKE_NG;
   l_imd->m_OpCode = p_ccCode;
   if(p_presentContext != NULL)
   {
      TLOG(0,1,"ExtendedServiceCoordinator::initiateIndependentContextLikeNg not null");
      if(MAX_ORIG_MODULE_NAME_SIZE > 10)
      {
         sprintf(l_imd->m_OriginatorModule, "%s%s:%08d", p_presentContext->m_ModName, p_presentContext->m_MessageName,
               p_presentContext->m_GlobalContextId);
      }
      else
      {
         sprintf(l_imd->m_OriginatorModule, "%s%s", p_presentContext->m_ModName, p_presentContext->m_MessageName);
      }
   }
   else
   {
      TLOG(0,1,"ExtendedServiceCoordinator::initiateIndependentContextLikeNg null");
      sprintf(l_imd->m_OriginatorModule, "unknown");
   }
   TLOG(0,1,"ExtendedServiceCoordinator::done");


   l_imd->m_msgPtr = p_msgPtr;
   LLOG(0,1,"Initiating a Context with Op Code: [%d]  MessageType [%d]", p_ccCode, l_imd->m_msgPtr->m_MsgType);
   if(NULL != g_InterModuleQueue2)
   {
      return g_InterModuleQueue2->push(l_imd);
   }
   else
   {
      ELOG(0,1,"Invalid g_InterModuleQueue2");
   }
   return true;
}


ExtendedInterModuleData::ExtendedInterModuleData()
{
   DLOG(0,1,"ExtendedInterModuleData :cons:");
}

ExtendedInterModuleData::~ExtendedInterModuleData()
{
   DLOG(0,1,"~ExtendedInterModuleData :des:");
}



