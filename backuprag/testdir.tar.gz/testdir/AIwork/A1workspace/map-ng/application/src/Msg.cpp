#include <Msg.h>
#include <Logger.h>
#include <typeinfo>

int g_MsgContexts = 0;
Msg::Msg()
{
   ++g_MsgContexts;
   //DLOG(0,1,"Msg :cons:");
   m_MsgType = MSG_TYPE_UNKNOWN;
   ///-m_DlgId=0;
   m_UserDlgId=0;
   DLOG(0,0,"Msg :cons: [%d] typeid[%s]",g_MsgContexts,typeid(*this).name());
}

Msg::Msg(EMsgType p_MsgType)
{
   ++g_MsgContexts;
   //DLOG(0,1,"Msg (EMsgType p_MsgType) :cons:");
   m_MsgType = p_MsgType;
   ///-m_DlgId=0;
   m_UserDlgId=0;
   DLOG(0,0,"Msg :cons: 2 [%d] typeid[%s]",g_MsgContexts,typeid(*this).name());
}

Msg::~Msg()
{
   --g_MsgContexts;
   DLOG(0,0,"Msg :des: [%d] typeid[%s]",g_MsgContexts,typeid(*this).name());
   //DLOG(0,1,"Msg  :des:");
}


