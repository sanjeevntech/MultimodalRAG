#include "gtest.h"
#include <Utilities.h>

bool verifyMax(int a, int b)
{
   return a>b?true:false;
}

bool verifyMin(int a, int b)
{
   return a<b?true:false;
}

bool verifyEqual(int a, int b)
{
   return (a==b)?true:false;
}

bool verifyNotEqual(int a, int b)
{
   return (a==b)?false:true;
}

bool verifyAscending(int a, int b)
{
  return a<b?true:false;
}
bool verifyNonAscending(int a, int b)
{
  return a>b?true:false;
}

bool verifyDescending(int a, int b)
{
  return a>b?true:false;
}
bool verifyNonDescending(int a, int b)
{
  return a<b?true:false;
}

bool IsUpper(char a)
{
return (a>='A') && (a<='Z')?true:false;
}

bool IsLower(char a)
{
return (a>='a') && (a<='z')?true:false;
}

bool IsPositive(int n)
{
return n>0?true:false;
}

bool IsNegative(int n)
{
return n<0?true:false;
}

bool IsEven(int n)
{
return (n%2==0)?true:false;
}

bool IsOdd(int n)
{
return (n%2!=0)?true:false;
}

bool IsDigit(char a)
{
return (a>=48) && (a<=57)? true: false;
}


TEST(BIN_TEST1, Negative) {
   EXPECT_FALSE(verifyMax(2,5));
}

TEST(BIN_TEST1, Positive) {
   EXPECT_TRUE(verifyMax(9,5));
}

TEST(BIN_TEST2, Negative) {
   EXPECT_FALSE(verifyMin(5,2));
}

TEST(BIN_TEST2, Positive) {
   EXPECT_TRUE(verifyMin(5,9));
}

TEST(BIN_TEST3, Negative) {
   EXPECT_FALSE(verifyEqual(5,2));
}

TEST(BIN_TEST3, Positive) {
   EXPECT_TRUE(verifyEqual(5,5));
}

TEST(BIN_TEST4, Negative) {
   EXPECT_FALSE(verifyNotEqual(5,5));
}

TEST(BIN_TEST4, Positive) {
   EXPECT_TRUE(verifyNotEqual(5,2));
}

TEST(BIN_TEST5, Positive) {
   EXPECT_TRUE(verifyAscending(2,5));
}

TEST(BIN_TEST5, Negative) {
   EXPECT_FALSE(verifyAscending(5,2));
}

TEST(BIN_TEST6, Positive) {
   EXPECT_TRUE(verifyNonAscending(5,2));
}

TEST(BIN_TEST6, Negative) {
   EXPECT_FALSE(verifyNonAscending(2,5));
}

TEST(BIN_TEST7, Positive) {
   EXPECT_TRUE(verifyDescending(5,2));
}

TEST(BIN_TEST7, Negative) {
   EXPECT_FALSE(verifyDescending(2,5));
}

TEST(BIN_TEST8, Positive) {
   EXPECT_TRUE(verifyNonDescending(2,5));
}

TEST(BIN_TEST8, Negative) {
   EXPECT_FALSE(verifyNonDescending(5,2));
}

TEST(IsUpperFunc, ReturnTrueCase) {
   EXPECT_TRUE(IsUpper('A'));
}

TEST(IsUpperFunc, ReturnFalseCase) {
   EXPECT_FALSE(IsUpper('a'));
}

TEST(IsLowerFunc, ReturnTrueCase) {
   EXPECT_TRUE(IsLower('a'));
}

TEST(IsLowerFunc, ReturnFalseCase) {
   EXPECT_FALSE(IsLower('A'));
}

TEST(IsPositiveFunc, ReturnTrueCase) {
   EXPECT_TRUE(IsPositive(7));
}

TEST(IsPositiveFunc, ReturnFalseCase) {
   EXPECT_FALSE(IsPositive(-8));
}

TEST(IsNegativeFunc, ReturnTrueCase) {
   EXPECT_TRUE(IsNegative(-7));
}

TEST(IsNegativeFunc, ReturnFalseCase) {
   EXPECT_FALSE(IsNegative(8));
}

TEST(IsEvenFunc, ReturnTrueCase) {
   EXPECT_TRUE(IsEven(8));
}

TEST(IsEvenFunc, ReturnFalseCase) {
   EXPECT_FALSE(IsEven(7));
}

TEST(IsOddFunc, ReturnTrueCase) {
   EXPECT_TRUE(IsOdd(7));
}

TEST(IsOddFunc, ReturnFalseCase) {
   EXPECT_FALSE(IsOdd(8));
}

TEST(IsDigitFunc, ReturnTrueCase) {
   EXPECT_TRUE(IsDigit('7'));
}

TEST(IsDigitFunc, ReturnFalseCase) {
   EXPECT_FALSE(IsDigit('a'));
}
/*********************************************************************************************************************************************************/
/*-----------------------------------------------------------  Utilities.cpp   -------------------------------------------------------------------       */
TEST(Utilities_cpp_getNumberOfSignificantBitsForAByteFunc, Return_eight) {
EXPECT_EQ(getNumberOfSignificantBitsForAByte('A'),8);
}
TEST(Utilities_cpp_getNumberOfSignificantBitsForAByteFunc, Return_eightminusi) {
EXPECT_NE(getNumberOfSignificantBitsForAByte('0'),8);
}
TEST(Utilities_cpp_getNumberOfSignificantBitsForAByteFunc, Return_Zero) {
EXPECT_EQ(getNumberOfSignificantBitsForAByte('\0'),0);
}
/*-----------------------------------------------------------*/
TEST(Utilities_cpp_BCDToStringFunc, Return_lcharlen)  {
char a[20];
char b[]="00010101";
int c=strlen(b);
EXPECT_NE(BCDToString(a,b,c),NULL);
}
/*---------------------------------------------------------*/
TEST(Utilities_cpp_StringToBCDFunc, Return_NON_NULL)  {
char a[20];
char b[]="abcde";
int c=strlen(b);
EXPECT_NE(StringToBCD(a,b,c),NULL);
}
/*---------------------------------------------------------*/
TEST(Utilities_cpp_ConvertInto8BitFunc, Return_True) {
char a[]="abcde";
char b[20];
int c=strlen(a);
EXPECT_TRUE(ConvertInto8Bit(a,b,c));
}

TEST(Utilities_cpp_ConvertInto8BitFunc, ReturnTrue) {
char a[]="abcdefghijku123567";
char b[20];
int c=strlen(a);
EXPECT_TRUE(ConvertInto8Bit(a,b,c));
}

/*---------------------------------------------------------*/
TEST(Utilities_cpp_atohxFunc, Return_l_ret)  {
char a[6]="123464CDD1D1";
char b[12];
EXPECT_NE(atohx(b,a),NULL);
}

TEST(Utilities_cpp_atohxFunc, ReturnNULL)  {
char a[6]=" a2b 3c4  d5e6f";
char b[12];
EXPECT_EQ(atohx(b,a),NULL);
}

/*-----------------------------------------------------------*/
TEST(Utilities_cpp_printHexDumpFunc, ReturnVoid)  {
char a[]="abcdef";
char b[]="abcddef";
int c=1;
EXPECT_NO_THROW(printHexDump(a,b,c));
}
/*------------------------------------------------------------*/
TEST(Utilities_cpp_ValidateIpv4Func, ReturnFalse_Notequaltofour) {
char a[]="172.16.25";
EXPECT_FALSE(ValidateIpv4(a));
}

TEST(Utilities_cpp_ValidateIpv4Func, ReturnFalse_greaterthan_255) {
char a[]="266.1266.266.289";
EXPECT_FALSE(ValidateIpv4(a));
}

TEST(Utilities_cpp_ValidateIpv4Func, ReturnFalse_strspn) {
char a[]="a.12.cd.23";
EXPECT_FALSE(ValidateIpv4(a));
}

TEST(Utilities_cpp_ValidateIpv4Func, ReturnTrue) {
char a[]="125.12.0.1";
EXPECT_TRUE(ValidateIpv4(a));
}
/*-----------------------------------------------------------*/
TEST(Utilities_cpp_convertIPV4toHexFunc, ReturnVoid) {
char a[]="172.16.254.1";
char b[20];
EXPECT_NO_THROW(convertIPV4toHex(a,b));
}
/*------------------------------------------------------------*/
TEST(Utilities_cpp_getTimeFunc, ReturnVoid) {
struct timeval l_currTv, l_prevTv;
EXPECT_NO_THROW(getTime(l_currTv, l_prevTv, NULL, NULL));
}
/*------------------------------------------------------------*/
TEST(Utilities_cpp_tokenizeFunc, ReturnVoid) {
char a[]="|abcd|cdef|efgh|";
char b[20];
int c=1;
EXPECT_NO_THROW(tokenize(a,b,c));
}

TEST(Utilities_cpp_tokenizeFunc, Return_Void) {
char a[]="||abcd|cdef|efgh|";
char b[20];
int c=1;
EXPECT_NO_THROW(tokenize(a,b,c));
}

/*-----------------------------------------------------------*/
TEST(Utilities_cpp_tokenize2Func, Reurnint) {
char a[100+1]="|abcd|cdef|efgh|";
char b[3][100];
EXPECT_NE(tokenize2(a,(char*)b,100,'|'),NULL);
}

TEST(Utilities_cpp_tokenize2Func, Reurn_int) {
char a[100+1]="||abcd|cdef|efgh|";
char b[3][100];
EXPECT_NE(tokenize2(a,(char*)b,100,'|'),NULL);
}

TEST(Utilities_cpp_tokenize2Func, Return_int) {
char a[100+1]="abcd|cdef|efgh|";
char b[3][100];
EXPECT_NE(tokenize2(a,(char*)b,1,'|'),NULL);
}


/*-----------------------------------------------------------*/

TEST(Utilities_cpp_convertHextoIPV4Func, ReturnVoid) {
string a="0x7f000001";
char b[20];
EXPECT_NO_THROW(convertHextoIPV4(a,b));
}

/*------------------------------------------------------------*/
TEST(Utilities_cpp_strlcatFunc, Returnvoid) {
char a[]="abcdef";
char b[]="ABCDEF";
int c=strlen(b);
EXPECT_NO_THROW(strlcat(a,b,c));
}
/*------------------------------------------------------------*/
/**********************************************************************************************************************************************************/


#include<SmppInterface.h>

TEST(Ascii2Gsm_cpp,ConvertAscii2Gsm_Func) {
EXPECT_NE(ConvertAscii2Gsm(1),1111110111111111);
}

TEST(Ascii2Gsm_cpp,ConvertAscii2Gsm_COMMERCIAL_AT_Func) {
EXPECT_NE(ConvertAscii2Gsm(0x40),1111110111111111);
}

TEST(Ascii2Gsm_cpp,ConvertAscii2Gsm_POUND_SIGN_Func) {
EXPECT_NE(ConvertAscii2Gsm(0xA3),1111110111111111);
}

TEST(Ascii2Gsm_cpp,ConvertAscii2Gsm_DOLLAR_SIGN_Func) {
EXPECT_NE(ConvertAscii2Gsm(0x24),1111110111111111);
}

TEST(Ascii2Gsm_cpp,ConvertAscii2Gsm_YEN_SIGN_Func) {
EXPECT_NE(ConvertAscii2Gsm(0xA5),1111110111111111);
}

TEST(Ascii2Gsm_cpp,ConvertAscii2Gsm_LATIN_SMALL_LETTER_E_WITH_GRAVE_Func) {
EXPECT_NE(ConvertAscii2Gsm(0xE8),1111110111111111);
}

TEST(Ascii2Gsm_cpp,ConvertAscii2Gsm_LATIN_SMALL_LETTER_E_WITH_ACUTE_Func) {
EXPECT_NE(ConvertAscii2Gsm(0xE9),1111110111111111);
}

TEST(Ascii2Gsm_cpp,ConvertAscii2Gsm_LATIN_SMALL_LETTER_U_WITH_GRAVE_Func) {
EXPECT_NE(ConvertAscii2Gsm(0xF9),1111110111111111);
}

TEST(Ascii2Gsm_cpp,ConvertAscii2Gsm_LATIN_SMALL_LETTER_I_WITH_GRAVE_Func) {
EXPECT_NE(ConvertAscii2Gsm(0xEC),1111110111111111);
}

TEST(Ascii2Gsm_cpp,ConvertAscii2Gsm_LATIN_SMALL_LETTER_O_WITH_GRAVE_Func) {
EXPECT_NE(ConvertAscii2Gsm(0xF2),1111110111111111);
}

TEST(Ascii2Gsm_cpp,ConvertAscii2Gsm_LATIN_CAPITAL_LETTER_C_WITH_CEDILLA_Func) {
EXPECT_NE(ConvertAscii2Gsm(0xC7),1111110111111111);
}


TEST(Ascii2Gsm_cpp,ConvertAscii2Gsm_LINE_FEED_Func) {
EXPECT_NE(ConvertAscii2Gsm(0xA),1111110111111111);
}

TEST(Ascii2Gsm_cpp,ConvertAscii2Gsm_LATIN_CAPITAL_LETTER_O_WITH_STROKE_Func) {
EXPECT_NE(ConvertAscii2Gsm(0xD8),1111110111111111);
}

TEST(Ascii2Gsm_cpp,ConvertAscii2Gsm_LATIN_SMALL_LETTER_O_WITH_STROKE_Func) {
EXPECT_NE(ConvertAscii2Gsm(0xF8),1111110111111111);
}

TEST(Ascii2Gsm_cpp,ConvertAscii2Gsm_CARRIAGE_RETURN_Func) {
EXPECT_NE(ConvertAscii2Gsm(0xD),1111110111111111);
}

TEST(Ascii2Gsm_cpp,ConvertAscii2Gsm_LATIN_CAPITAL_LETTER_A_WITH_RING_ABOVE_Func) {
EXPECT_NE(ConvertAscii2Gsm(0xC5),1111110111111111);
}


TEST(Ascii2Gsm_cpp,ConvertAscii2Gsm_LATIN_SMALL_LETTER_A_WITH_RING_ABOVE_Func) {
EXPECT_NE(ConvertAscii2Gsm(0xE5),1111110111111111);
}

TEST(Ascii2Gsm_cpp,ConvertAscii2Gsm_LOW_LINE_Func) {
EXPECT_NE(ConvertAscii2Gsm(0x5f),1111110111111111);
}

TEST(Ascii2Gsm_cpp,ConvertAscii2Gsm_FORM_FEED_Func) {
EXPECT_NE(ConvertAscii2Gsm(0xC),1111110111111111);
}

TEST(Ascii2Gsm_cpp,ConvertAscii2Gsm_CIRCUMFLEX_ACCENT_Func) {
EXPECT_NE(ConvertAscii2Gsm(0x5E),1111110111111111);
}

TEST(Ascii2Gsm_cpp,ConvertAscii2Gsm_LEFT_CURLY_BRACKET_Func) {
EXPECT_NE(ConvertAscii2Gsm(0x7B),1111110111111111);
}

TEST(Ascii2Gsm_cpp,ConvertAscii2Gsm_RIGHT_CURLY_BRACKET_Func) {
EXPECT_NE(ConvertAscii2Gsm(0x7D),1111110111111111);
}

TEST(Ascii2Gsm_cpp,ConvertAscii2Gsm_REVERSE_SOLIDUS_BACKSLASH_Func) {
EXPECT_NE(ConvertAscii2Gsm(0x5C),1111110111111111);
}

TEST(Ascii2Gsm_cpp,ConvertAscii2Gsm_LEFT_SQUARE_BRACKET_Func) {
EXPECT_NE(ConvertAscii2Gsm(0x5B),1111110111111111);
}

TEST(Ascii2Gsm_cpp,ConvertAscii2Gsm_TILDE_Func) {
EXPECT_NE(ConvertAscii2Gsm(0x7E),1111110111111111);
}

TEST(Ascii2Gsm_cpp,ConvertAscii2Gsm_RIGHT_SQUARE_BRACKET_Func) {
EXPECT_NE(ConvertAscii2Gsm(0x5D),1111110111111111);
}

TEST(Ascii2Gsm_cpp,ConvertAscii2Gsm_VERTICAL_BAR_Func) {
EXPECT_NE(ConvertAscii2Gsm(0x7C),1111110111111111);
}

TEST(Ascii2Gsm_cpp,ConvertAscii2Gsm_EURO_SIGN_Func) {
EXPECT_NE(ConvertAscii2Gsm(0xA4),1111110111111111);
}

TEST(Ascii2Gsm_cpp,ConvertAscii2Gsm_LATIN_CAPITAL_LETTER_AE_Func) {
EXPECT_NE(ConvertAscii2Gsm(0xC6),1111110111111111);
}

TEST(Ascii2Gsm_cpp,ConvertAscii2Gsm_LATIN_SMALL_LETTER_AE_Func) {
EXPECT_NE(ConvertAscii2Gsm(0xE6),1111110111111111);
}

TEST(Ascii2Gsm_cpp,ConvertAscii2Gsm_LATIN_SMALL_LETTER_SHARP_S_German_Func) {
EXPECT_NE(ConvertAscii2Gsm(0xDF),1111110111111111);
}

TEST(Ascii2Gsm_cpp,ConvertAscii2Gsm_LATIN_CAPITAL_LETTER_E_WITH_ACUTE_Func) {
EXPECT_NE(ConvertAscii2Gsm(0xC9),1111110111111111);
}

TEST(Ascii2Gsm_cpp,ConvertAscii2Gsm_INVERTED_EXCLAMATION_MARK_Func) {
EXPECT_NE(ConvertAscii2Gsm(0xA1),1111110111111111);
}

TEST(Ascii2Gsm_cpp,ConvertAscii2Gsm_LATIN_CAPITAL_LETTER_A_WITH_DIAERESIS_Func) {
EXPECT_NE(ConvertAscii2Gsm(0xC4),1111110111111111);
}

TEST(Ascii2Gsm_cpp,ConvertAscii2Gsm_LATIN_CAPITAL_LETTER_O_WITH_DIAERESIS_Func) {
EXPECT_NE(ConvertAscii2Gsm(0xD6),1111110111111111);
}

TEST(Ascii2Gsm_cpp,ConvertAscii2Gsm_LATIN_CAPITAL_LETTER_N_WITH_TILDE_Func) {
EXPECT_NE(ConvertAscii2Gsm(0xD1),1111110111111111);
}

TEST(Ascii2Gsm_cpp,ConvertAscii2Gsm_LATIN_CAPITAL_LETTER_U_WITH_DIAERESIS_Func) {
EXPECT_NE(ConvertAscii2Gsm(0xDC),1111110111111111);
}

TEST(Ascii2Gsm_cpp,ConvertAscii2Gsm_SECTION_SIGN_Func) {
EXPECT_NE(ConvertAscii2Gsm(0xA7),1111110111111111);
}

TEST(Ascii2Gsm_cpp,ConvertAscii2Gsm_INVERTED_QUESTION_MARK_Func) {
EXPECT_NE(ConvertAscii2Gsm(0xBF),1111110111111111);
}

TEST(Ascii2Gsm_cpp,ConvertAscii2Gsm_LATIN_SMALL_LETTER_A_WITH_DIAERESIS_Func) {
EXPECT_NE(ConvertAscii2Gsm(0xE4),1111110111111111);
}

TEST(Ascii2Gsm_cpp,ConvertAscii2Gsm_LATIN_SMALL_LETTER_O_WITH_DIAERESIS_Func) {
EXPECT_NE(ConvertAscii2Gsm(0xF6),1111110111111111);
}

TEST(Ascii2Gsm_cpp,ConvertAscii2Gsm_LATIN_SMALL_LETTER_N_WITH_TILDE_Func) {
EXPECT_NE(ConvertAscii2Gsm(0xF1),1111110111111111);
}

TEST(Ascii2Gsm_cpp,ConvertAscii2Gsm_LATIN_SMALL_LETTER_U_WITH_DIAERESIS_Func) {
EXPECT_NE(ConvertAscii2Gsm(0xFC),1111110111111111);
}

TEST(Ascii2Gsm_cpp,ConvertAscii2Gsm_LATIN_SMALL_LETTER_A_WITH_GRAVE_Func) {
EXPECT_NE(ConvertAscii2Gsm(0xE0),1111110111111111);
}



