ifeq ($(SYSTEM_OS),SunOS)
   ORACLE_HOME                = $(ORACLE_10G_HOME)

   FOR_ULTICOM_SYSTEM_OS      = SUNOS
   OSS_NOKALVA_LIB_FILE       = -lasn1code
#DIAMETER_LIB_POS           = -ldiaval -lbaseapi -lIDSClient -ls6a_3gpp_r10_6 -lslh_rel_10
DIAMETER_LIB_POS           = -ldiaval -lbaseapi -lIDSClient -L $ITS_DIAMETER_HOME/lib  -ls6a_3gpp_r10_6 -lslh_rel_10 -lsh_3gpp_r16_6 -lrx_3gpp_r16_6 -lcx_rel_16 -lgx_3gpp_r10_6 -lnasreqapi -lswx_rel_18 
else
   ORACLE_HOME                = $(ORACLE_11G_HOME)

   FOR_ULTICOM_SYSTEM_OS      = LINUX
   EXTRA_ULTICOM_LIB_FILE     = -lstream -ldf
   EXTRA_OS_SPECIFIC_FLAGS    = -rdynamic -fpermissive
   OSS_NOKALVA_LIB_FILE       = -losstoed
#   DIAMETER_LIB_POS           = -lbaseapi -lIDSClient -ls6a_3gpp_r10_6 -lslh_rel_10 -ldiaval -lcx_rel_16
#DIAMETER_LIB_POS           = -lbaseapi -lIDSClient -ldiastack -lENGINE -lDRIVER++ -ldccacore -lITSDFrame -L/opt/product/sach1164/DIASTACK_2.0.5.0/diastack/Dependency/lksctp-tools-1.0.10/lib/ -lsctp -L../../diametriq-lib/lib/ -ldccaapi -ls6a_3gpp_r10_6 -lslh_rel_10 -lsh_3gpp_r16_6 -lrx_3gpp_r16_6 -lcx_rel_16 -lgx_3gpp_r10_6 -lnasreqapi -ldiaval
   DIAMETER_LIB_POS           = -lbaseapi -lIDSClient  -L $ITS_DIAMETER_HOME/lib  -ls6a_3gpp_r10_6 -lswx_rel_18 -lslh_rel_10 -lsh_3gpp_r16_6 -lrx_3gpp_r16_6 -lcx_rel_16 -lgx_3gpp_r10_6 -lnasreqapi -ldiaval 
   NG_CONFIG_FILE_SUFFIX      = Linux
endif 

CXX                           = $(COMPILER_GCC_DEFAULT_PATH)/gcc -m64 $(EXTRA_OS_SPECIFIC_FLAGS)
SOFLAGS                       = -shared
#SOFLAGS                       = -G -z allextract
PICFLAGS                      = -fPIC
#PICFLAGS                      = -KPIC
WARNINGS_C                    =  #-Wchar-subscripts -Wcomment -Wcomments -Wendif-labels -Wfloat-equal -Wformat -Wformat-extra-args -Wformat-nonliteral -Wformat-security -Wformat-y2k -Wimplicit -Winit-self -Wmissing-braces  -Wmissing-format-attribute -Wmultichar -Wparentheses -Wpointer-arith -Wredundant-decls -Wreturn-type -Wsign-compare -Wtrigraphs -Wundef -Wunknown-pragmas -Wunused-macros
WARNINGS_OTHERS               = #-Wcast-align -Winline -Wmissing-noreturn -Wshadow -Wstrict-aliasing -Wswitch-default -O -Wuninitialized -Wunused -Wunused-function -Wunused-label -Wunused-parameter -Wunused-value -Wunused-variable
WARNINGS_STRINGS              = #-Wall -Wextra $(WARNINGS_OTHERS) -Wno-deprecated $(WARNINGS_C)
SCCP_TYPE_ITU                 = -DC7_Q
SCCP_TYPE_ANSI                = -DA7_T
CXX_FLAGS                     = -D$(ULCM_VERSION) $(GCOV_FLAGS) $(WARNINGS_STRINGS) -g -m64 -D$(SYSTEM_OS) -D$(FOR_ULTICOM_SYSTEM_OS) -DUNIX_PORT -DMULTITHREAD -D_REENTRANT -DSS_64BIT_SERVER -DBIT64 -DMACHINE64 -DSLMXMX_ENABLE -DSLTS_ENABLE -D_SVID_GETTOD  -DAPP_VERSION="\"$(APP_VERSION)\"" -DCOMMIT_ID="\"$(COMMIT_ID)\"" -DCOMMIT_DATE="\"$(COMMIT_DATE)\"" -Wno-write-strings #-DULTICOM_STACK_SP6_INCLUDE #-DWITH_QUANTIFY_APIS #-DAAA
MAP1_HOME                     = $(HLR_FRAMEWORK_ROOT)/IOLIB_$(SYSTEM_OS)/MAP1/
MAP2_HOME                     = $(HLR_FRAMEWORK_ROOT)/IOLIB_$(SYSTEM_OS)/MAP2/
MAP3_HOME                     = $(HLR_FRAMEWORK_ROOT)/IOLIB_$(SYSTEM_OS)/MAP3/
MAP_CONSTANTS_HOME            = $(HLR_FRAMEWORK_ROOT)/IOLIB_$(SYSTEM_OS)/map-constants/
DIAMETER_CONSTANTS_HOME       = $(HLR_FRAMEWORK_ROOT)/IOLIB_$(SYSTEM_OS)/diameter-constants/
ITS_DIAMETER_SERVER_HOME      = $(ITS_DIAMETER_HOME)/
ITS_S6A_HOME                  = $(ITS_DIAMETER_HOME)/
ITS_SWX_HOME                  = $(ITS_DIAMETER_HOME)/
ITS_S6A_MSG_HOME              = $(ITS_DIAMETER_HOME)/inc/diameter/s6a_r10/
ITS_SWX_MSG_HOME              = $(ITS_DIAMETER_HOME)/inc/diameter/swx_rel_18/
ITS_SLH_MSG_HOME              = $(ITS_DIAMETER_HOME)/inc/diameter/slh_rel_10/
ITS_SLH_LIB                   = $(ITS_DIAMETER_HOME)/lib
ITS_FLAGS                     = -D$(SYSTEM_OS) -D_REENTRANT -DPLATFORM=solaris64 -Dsolaris64 -DUSE_HEAP -DHAVE_NAMESPACES -DHAVE_STD_NAMESPACE -DHAVE_THROW_SPECS -D_MIT_POSIX_THREADS -DHAVE_STL  -DDEBUG
PURIFY_HOME                   = /opt/product/mohan/Rational/releases/PurifyPlus.7.0/sun4_solaris2/
QUANTIFY_HOME                 = /opt/product/mohan/Rational/releases/quantify.sol.7.0/
ARGTABLE_INSTALL_HOME         = $(ARGTABLE_PATH)
GCC_LIB_FLAGS                 = -lstdc++
#Added from Diametriq
PLATFORM                      = solaris64
DEBUG_BUILD                   = no
STACKLOC                      = /opt/IntelliNet
IMS_ROOT                      = /opt/product/rgopal/learn/new/IMSDIA-GA-5.1.0/
IMS_TOOLS                     = $(IMS_ROOT)/imstools
ITS_ROOT                      = $(IMS_ROOT)/AcceleroCore
ISS7_CONFIG_DIR               = $(IMS_ROOT)/config/
