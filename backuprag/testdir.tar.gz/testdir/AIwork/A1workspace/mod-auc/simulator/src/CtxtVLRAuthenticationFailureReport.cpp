#include <CtxtVLRAuthenticateFailureReport.h>
#include <stdio.h>
#include <MapMessages.h>
#include <ServiceCoordinator.h>
#include <Logger.h>
#include <IMAP3.h>
#include <OMAP3.h>
#include <DbActiveObject.h>
#include <AucConfigReader.h>
//#include <ByteMilenage.h>


CtxtVLRAuthenticateFailureReport::CtxtVLRAuthenticateFailureReport()
{
}

CtxtVLRAuthenticateFailureReport::~CtxtVLRAuthenticateFailureReport()
{

}


bool CtxtVLRAuthenticateFailureReport::sendv3AFR(int p_dialogue)
{
	DLOG(0,0,"Sending MapSpecificRequest ...");
	MapSpecificRequest l_request(p_dialogue, MAP_OP_CODE_authenticationFailureReport, MAP_V3);

	OMAP3_AuthenticationFailureReportArg *l_temp = (OMAP3_AuthenticationFailureReportArg*)malloc(sizeof(OMAP3_AuthenticationFailureReportArg));
	memset(l_temp, '\0', sizeof(OMAP3_AuthenticationFailureReportArg));
   //204043733999907
   //02043437939909F7
	l_temp->imsi.length = 7;
	l_temp->imsi.value[0] = 0x02;
	l_temp->imsi.value[1] = 0x04;
	l_temp->imsi.value[2] = 0x34;
	l_temp->imsi.value[3] = 0x37;
	l_temp->imsi.value[4] = 0x93;
	l_temp->imsi.value[5] = 0x99;
	l_temp->imsi.value[6] = 0x09;
	l_temp->imsi.value[7] = 0xF7;
	l_temp->failureCause = OMAP3_wrongUserResponse;
    l_temp->bit_mask = OMAP3_re_attempt_present |
                       OMAP3_accessType_present |
                       OMAP3_AuthenticationFailureReportArg_vlr_Number_present |
                       OMAP3_rand_present;
    l_temp->re_attempt = true;
    l_temp->accessType=OMAP3_call;
    l_temp->rand.length=16;
    l_temp->rand.value[1]=0x01;
    l_temp->rand.value[2]=0x02;
    l_temp->rand.value[3]=0x03;
    l_temp->vlr_Number.length=2;
    l_temp->vlr_Number.value[0]=0x12;
    l_temp->vlr_Number.value[1]=0x34;
	l_request.m_structBuffer = (void*)l_temp;

	g_sc.sendMsg(this, &l_request);


	DLOG(0,0,"Sending MapDelimiterReq Req ...");
	MapDelimiterReq l_del(p_dialogue);
	g_sc.sendMsg(this, &l_del);

	return true;
}



bool CtxtVLRAuthenticateFailureReport::initiateAFR()
{
	int l_UserDlgId = g_sc.getNewDialogue();


    DLOG(0,0,"Sending MapOpenReq ...");
    MapOpenReq l_mapOpenReq(l_UserDlgId, MAP_V3);
    l_mapOpenReq.m_ApplCntxt = MAP_AC_CODE_authenticationFailureReport;
    l_mapOpenReq.m_DestAddr  = g_ConfigData->i_NgConfigData.m_remoteAddress1;
    g_sc.sendMsg(this, &l_mapOpenReq);

    return sendv3AFR(l_UserDlgId);

}




bool CtxtVLRAuthenticateFailureReport::startProcessing()
{
	DLOG(0,0,"Start of CtxtVLRAuthenticateFailureReport::startProcessing function");

	initiateAFR();
	return true;
}


bool CtxtVLRAuthenticateFailureReport::processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag)
{
	DLOG(0,0,"Start of CtxtVLRAuthenticateFailureReport::processMessage function");
	int l_UserDlgId;

	switch (p_MsgPtr->m_MsgType)
	{
		case MSG_TYPE_MAP:
			switch (((MapMsg*)p_MsgPtr)->m_MapMsgType)
			{
				case MAP_MSG_TYPE_COMMON:
					switch (((MapCommonMsg*)p_MsgPtr)->m_MapCommonMsgType)
					{
						case MAP_CMN_OPEN_IND:
							DLOG(0,0,"MAP_CMN_OPEN_IND received");
							break;

						case MAP_CMN_OPEN_CNF:
							DLOG(0,0,"MAP_CMN_OPEN_CNF received");
							break;

						case MAP_CMN_DELIMITER_IND:
						{
							DLOG(0,0,"MAP_CMN_DELIMITER_IND received");
						}
						break;

						case MAP_CMN_CLOSE_IND:
							DLOG(0,0,"MAP_CMN_CLOSE_IND received");
							return true;
							break;

						case MAP_CMN_U_ABORT_IND:
							DLOG(0,0,"MAP_CMN_U_ABORT_IND received");
							break;

						case MAP_CMN_P_ABORT_IND:
							DLOG(0,0,"MAP_CMN_P_ABORT_IND received");
							break;

						case MAP_CMN_NOTICE_IND:
							DLOG(0,0,"MAP_CMN_NOTICE_IND received");
							break;

						default:
							DLOG(0,0,"Unknown Msg received");
							break;
					}
					break;

				case MAP_MSG_TYPE_SPECIFIC:
					DLOG(0,0,"MAP_MSG_TYPE_SPECIFIC received");
					switch (((MapSpecificMsg*)p_MsgPtr)->m_MapSpecificEventType)
					{
						case MAP_SPEC_EVENT_REQUEST:
							DLOG(0,0,"MAP_SPEC_EVENT_REQUEST received");
							break;

						case MAP_SPEC_EVENT_INDICATION:
						{
							DLOG(0,0,"MAP_SPEC_EVENT_INDICATION received");
						}
						break;

						case MAP_SPEC_EVENT_RESULT:
							DLOG(0,0,"MAP_SPEC_EVENT_RESULT received");
							break;
						case MAP_SPEC_EVENT_CONFIRMATION:
							DLOG(0,0,"MAP_SPEC_EVENT_CONFIRMATION received");

							break;
						case MAP_SPEC_EVENT_USER_ERROR:
							DLOG(0,0,"MAP_SPEC_EVENT_USER_ERROR received");
							switch (((MapUserError*)p_MsgPtr)->m_ErrorCode)
							{
								case MAP_ERROR_systemFailure:
									printf("\nGot a User Error : System Failure Param ");
									break;
								case MAP_ERROR_UNKNOWN:
									printf("\nGot a User Error : Unknown ");
									break;
								default:
									printf("\nGot a Different error");
									break;
							}
							break;

						case MAP_SPEC_EVENT_PROV_ERROR:
						{
							DLOG(0,0,"MAP_SPEC_EVENT_PROV_ERROR received");
							DLOG(0,0,"Closing the Dialogue");
							MapCloseReq l_closeReq(((MapSpecificMsg*)p_MsgPtr)->m_UserDlgId);
							g_sc.sendMsg(this, &l_closeReq);
						}
						break;

						default:
							ELOG(0,0,"ERROR!!! Default received");
							break;
					
					}
					break;
			
				default:
					break;
			}
			break;

		case MSG_TYPE_DB:
			DLOG(0,0,"DB message received");
			break;

		default:
			DLOG(0,0,"Unknown message received");
			break;
	
	}
	return true;
}
