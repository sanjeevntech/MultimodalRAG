#include <CtxtCancelLocation.h>
#include <stdio.h>
#include <MapMessages.h>
#include <ServiceCoordinator.h>
#include <Logger.h>
#include <OMAP1.h>
#include <OMAP2.h>
#include <OMAP3.h>


CtxtCancelLocation::CtxtCancelLocation()
{

}

CtxtCancelLocation::~CtxtCancelLocation()
{

}


bool CtxtCancelLocation::processMessage(Msg *p_MsgPtr,bool &p_DeleteFlag)
{
	DLOG(0,0,"Start of CtxtCancelLocation::processMessage function del flag %d",p_DeleteFlag);

	int l_UserDlgId = 0;

	switch (p_MsgPtr->m_MsgType)
	{
		case MSG_TYPE_MAP:
			switch (((MapMsg*)p_MsgPtr)->m_MapMsgType)
			{
				case MAP_MSG_TYPE_COMMON:
					switch (((MapCommonMsg*)p_MsgPtr)->m_MapCommonMsgType)
					{
						case MAP_CMN_OPEN_IND:
							DLOG(0,0,"MAP_CMN_OPEN_IND received");
							break;

						case MAP_CMN_DELIMITER_IND:
						{
							DLOG(0,0,"MAP_CMN_DELIMITER_IND received");
							l_UserDlgId = p_MsgPtr->m_UserDlgId;
						}
						break;

						case MAP_CMN_CLOSE_IND:
							DLOG(0,0,"MAP_CMN_CLOSE_IND received");
							return true;
							break;

						case MAP_CMN_U_ABORT_IND:
							DLOG(0,0,"MAP_CMN_U_ABORT_IND received");
							break;

						case MAP_CMN_P_ABORT_IND:
							DLOG(0,0,"MAP_CMN_P_ABORT_IND received");
							break;

						case MAP_CMN_NOTICE_IND:
							DLOG(0,0,"MAP_CMN_NOTICE_IND received");
							break;

						default:
							DLOG(0,0,"Unknown Msg received");
							break;
					}
					break;

				case MAP_MSG_TYPE_SPECIFIC:
					DLOG(0,0,"MAP_MSG_TYPE_SPECIFIC received");
					switch (((MapSpecificMsg*)p_MsgPtr)->m_MapSpecificEventType)
					{
						case MAP_SPEC_EVENT_REQUEST:
							DLOG(0,0,"MAP_SPEC_EVENT_REQUEST received");
							break;

						case MAP_SPEC_EVENT_INDICATION:
						{
							DLOG(0,0,"MAP_SPEC_EVENT_INDICATION received");
							switch (((MapSpecificMsg*)p_MsgPtr)->m_OpCode)
							{
								case MAP_OP_CODE_cancelLocation:
								{
									DLOG(0,0,"MAP_OP_CODE_CancelLoc REQUEST received");
									printf("MAP_OP_CODE_CancelLoc REQUEST received\n");
									l_UserDlgId = ((MapSpecificMsg*)p_MsgPtr)->m_UserDlgId;

                           char *l_Type = getenv("DONT_SENT_CL_RESP");
                           if(strcmp(l_Type,"YES") != 0)
                           {
                              DLOG(0,0,"Sending CancelLoc Specific Result ...");
                              MapSpecificResult l_result(l_UserDlgId, MAP_OP_CODE_cancelLocation, MAP_V2);

                              OMAP2_CancelLocationRes *l_temp = (OMAP2_CancelLocationRes*)malloc(sizeof(OMAP2_CancelLocationRes));
                              memset(l_temp, '\0', sizeof(OMAP2_CancelLocationRes));

                              l_result.m_structBuffer = (void*)l_temp;
                              g_sc.sendMsg(this, &l_result);

                              DLOG(0,0,"Closing the Dialogue CancelLoc");
                              MapCloseReq l_closeReq(l_UserDlgId);
                              g_sc.sendMsg(this, &l_closeReq);
                           }
                           else
                           {
                              ELOG(0,0,"\n\n DONT_SENT_CL_RESP set not sending resp \n\n");
                           }

								}
								break;
                        case MAP_OP_CODE_insertSubscriberData:
                        {
                           printf("MAP_OP_CODE_insertSubscriberData REQUEST received");
                           MapSpecificResult l_result(((MapSpecificMsg*) p_MsgPtr)->m_UserDlgId, MAP_OP_CODE_insertSubscriberData, MAP_V2);
                           g_sc.sendMsg(this, &l_result);
                           printf("Received ISD Arg, Sending MapSpecificResult followed by MAP_Delimiter\n");
                           MapDelimiterReq l_del(((MapSpecificMsg*) p_MsgPtr)->m_UserDlgId);
                           g_sc.sendMsg(this, &l_del);
                        }
                        break;
                        default:
									ELOG(0,0,"Unknown REQUEST received");
									break;
							}
						}
						break;

						case MAP_SPEC_EVENT_RESULT:
							DLOG(0,0,"MAP_SPEC_EVENT_RESULT received");
							break;
						case MAP_SPEC_EVENT_CONFIRMATION:
							DLOG(0,0,"MAP_SPEC_EVENT_CONFIRMATION received");
							break;
						case MAP_SPEC_EVENT_USER_ERROR:
							DLOG(0,0,"MAP_SPEC_EVENT_USER_ERROR received");
							break;

						case MAP_SPEC_EVENT_PROV_ERROR:
						{
							DLOG(0,0,"MAP_SPEC_EVENT_PROV_ERROR received");
							DLOG(0,0,"Closing the Dialogue");
							MapCloseReq l_closeReq(((MapSpecificMsg*)p_MsgPtr)->m_UserDlgId);
							g_sc.sendMsg(this, &l_closeReq);
						}
						break;

						default:
							ELOG(0,0,"ERROR!!! Default received");
							break;
					
					}
					break;
			
				default:
					break;
			}
			break;

		case MSG_TYPE_DB:
			DLOG(0,0,"DB message received");
			break;
      
    case MSG_TYPE_TIMEOUT:
       break;
          

		default:
			DLOG(0,0,"Unknown message received");
			break;
	
	}
	return true;
}
