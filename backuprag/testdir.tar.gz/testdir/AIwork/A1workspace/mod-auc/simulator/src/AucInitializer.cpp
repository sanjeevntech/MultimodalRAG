#include <MapMessages.h>
#include <ContextBase.h>
#include <Logger.h>
#include <AucConfigReader.h>
#include <ModuleBase.h>

#include <CtxtVLRSendAuthenticationInfo.h>
#include <CtxtCancelLocation.h>
#include <CtxtVLRAuthenticateFailureReport.h>


extern "C" {
   ModuleBase *getModuleObj();
}

class SimAucModule : public ModuleBase
{
    public:
      bool initModule();
      ContextBase *getCtxtObj(EMapOpCode, MapSpecificMsg*);
      char *getVersion();
      ConfigReader *getConfigReaderObj();
      ConfigReader **retrieveConfigReaderPtr();
};

SimAucModule g_SimAucModule;

ModuleBase *getModuleObj()
{
    return &g_SimAucModule;
}

bool SimAucModule::initModule()
{
    return true;
}

char *SimAucModule::getVersion()
{
    RETURN_VERSION("0.0.0.2");
}

ContextBase *SimAucModule::getCtxtObj(EMapOpCode p_OpCode, MapSpecificMsg *p_msg)
{
    switch (p_OpCode)
    {
        case MAP_OP_CODE_sendAuthenticationInfo:
        case MAP_OP_CODE_provideRoamingNumber:
            DLOG(0,0,"Newing CtxtVLRSendAuthenticationInfo");
            return new CtxtVLRSendAuthenticationInfo;
            break;

        case MAP_OP_CODE_cancelLocation:
            return new CtxtCancelLocation;
            break;

        case MAP_OP_CODE_sendParameters:
            DLOG(0,0,"Newing CtxtVLRSendAuthenticationInfo");
            return new CtxtVLRSendAuthenticationInfo;
            break;

        case MAP_OP_CODE_authenticationFailureReport:
            DLOG(0,0,"Newing CtxtVLRAuthenticateFailureReport");
            return new CtxtVLRAuthenticateFailureReport;
            break;

        case MAP_OP_CODE_sendIMSI:
            DLOG(0,0,"Newing CtxtVLRSendIMSI");
            return new CtxtVLRSendImsi;
            break;

        default:
            DLOG(0,0,"getVLRAucSimulatorCtxtObj Unknown OpCode [%d]",p_OpCode);
            return NULL;
            break;
    }
}

ConfigReader *SimAucModule::getConfigReaderObj()
{
	DLOG(0,0,"Returning g_AucConfigReaderObj");
   return (g_AucConfigReaderObj = new AucConfigReader);
}

ConfigReader **SimAucModule::retrieveConfigReaderPtr()
{
   TLOG(0,0,"ConfigReader **AucModule::retrieveConfigReaderPtr() called");
   return (ConfigReader **)&g_AucConfigReaderObj;
}

bool resetStruct(int p_version, int p_pdu, void *p_struct)
{
   switch (p_version)
   {
      case 1:
      {
         switch(p_pdu)
         {
            default:
            {
               DLOG(0,0,"v1 In the default case");
               return false;
            }
            break;
         }
      }
      break;

      case 2:
      {
         switch(p_pdu)
         {
            default:
            {
               DLOG(0,0,"v2 In the default case");
               return false;
            }
            break;
         }
      }
      break;

      case 3:
      {
         switch(p_pdu)
         {
            default:
            {
               DLOG(0,0,"v3 In the default case");
               return false;
            }
            break;
         }
      }
      break;

      default:
      {
          DLOG(0,0,"v-default In the default case");
      }
      break;
   }
   return false;
}
