#include <AucConfigReader.h>
#include <Logger.h>

AucConfigReader *g_AucConfigReaderObj=NULL;




AucConfigReader::AucConfigReader()
{
    memset(m_simImsi, '\0', 17);
}

AucConfigReader::~AucConfigReader()
{
}


bool AucConfigReader::readData()
{
	//printf("\nCalling AucConfigReader::readData()");
    string l_auc = readValue(m_DataString, "AUC");

    string l_SIM_VERSION = readValue(l_auc, "SIM_VERSION");
    m_simVersion=atoi(l_SIM_VERSION.c_str());
    printf("\nm_simVersion %d\n", m_simVersion);

    string l_SIM_IMSI = readValue(l_auc, "SIM_IMSI");
    strcpy(m_simImsi, l_SIM_IMSI.c_str());
    
    return true;
}

void AucConfigReader::printConfigData(char *p_output)
{
}

