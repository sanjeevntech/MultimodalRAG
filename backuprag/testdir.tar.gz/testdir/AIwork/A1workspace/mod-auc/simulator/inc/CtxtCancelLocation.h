#ifndef __CONTEXT_CANCEL_LOCATION_H
#define __CONTEXT_CANCEL_LOCATION_H

#include <ContextBase.h>
#include <Msg.h>


class CtxtCancelLocation : public ContextBase
{
	public:
		CtxtCancelLocation();
		~CtxtCancelLocation();

		bool processMessage(Msg *p_MsgPtr,bool &p_DeleteFlag);
};



#endif
