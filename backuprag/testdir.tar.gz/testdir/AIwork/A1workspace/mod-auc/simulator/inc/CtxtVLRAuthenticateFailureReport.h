#ifndef __CONTEXT_VLR_AUTH_FAIL_REPORT_H
#define __CONTEXT_VLR_AUTH_FAIL_REPORT_H

#include <ContextBase.h>
#include <Msg.h>
#include <MapMessages.h>


class CtxtVLRAuthenticateFailureReport : public ContextBase
{
	private:
        bool initiateAFR();
		bool sendv3AFR(int);

	public:
		CtxtVLRAuthenticateFailureReport();
		~CtxtVLRAuthenticateFailureReport();

		bool processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag);
		bool startProcessing();
};




#endif
