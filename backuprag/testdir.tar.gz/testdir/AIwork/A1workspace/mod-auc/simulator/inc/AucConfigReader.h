#ifndef __AUC_CONFIG_READER_H
#define __AUC_CONFIG_READER_H

#include <ConfigReader.h>

class AucConfigReader: public ConfigReader
{
    private:

    public:
        AucConfigReader();
        ~AucConfigReader();

		bool readData();
         void printConfigData(char *p_output);

        // AUC Simulator Configuration Parameters
        int m_simVersion;
        char m_simImsi[16+1];
};

extern AucConfigReader *g_AucConfigReaderObj;


#endif
