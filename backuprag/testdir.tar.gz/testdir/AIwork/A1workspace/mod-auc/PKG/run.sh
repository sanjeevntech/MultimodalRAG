HLR_FRAMEWORK_ROOT=/opt/product/rgopal/work/HLR_1.0.7.0_Rev1/

OMNI_ROOT=/opt/ulcm/
MAP_HOME=/opt/product/rgopal/work/HLR_1.0.7.0_Rev1/IOLIB/
ORACLE_HOME=/ora10gclnt/product/10.2.0/client/
LD_LIBRARY_PATH=/usr/sfw/lib/sparcv9/:$MAP_HOME/map-constants/lib/:$MAP_HOME/MAP1/lib:$MAP_HOME/MAP2/lib:$MAP_HOME/MAP3/lib:/usr/local/ossasn1/solaris7-64bit/8.3.1/lib:/opt/ulcm/library:$ORACLE_HOME/lib:$HLR_FRAMEWORK_ROOT/framework/objs/:.:$HLR_FRAMEWORK_ROOT/map-ng/oci-change-notification/:/export/home/anjanr/HLR/hlr_subs_profiles_0.2/PKG/:/export/home/sachi/CodeBase/GENERIC_UTIL_1.1.1.0/gen-util/lib/:/export/home/sachi/CodeBase/LICENSING_1.0.0.0_Rev1/lic_validator/objs:/opt/product/mohan/HLR/license/generator/pkg

PATH=$PATH:$ORACLE_HOME/bin/
