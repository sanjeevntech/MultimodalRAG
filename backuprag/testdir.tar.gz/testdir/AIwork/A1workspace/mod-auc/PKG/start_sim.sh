clear
. run.sh
rm -f core
SHM=100
ldd $HLR_FRAMEWORK_ROOT/map-ng/application/objs/mapNG
# 39-sendimsi, 56-sai, 58-auth
export DONT_SENT_CL_RESP=NO
$HLR_FRAMEWORK_ROOT/map-ng/application/objs/mapNG -config SimulatorNgConfig.xml -simLoad -simOpCode 56 -simLoadMsgsPerSec 1 -simLoadDuration 1 -index $1
