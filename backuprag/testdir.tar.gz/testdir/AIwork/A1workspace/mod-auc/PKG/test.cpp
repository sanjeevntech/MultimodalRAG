#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <typeinfo>

class B
{
   public:
   int a;
   void getType(){printf("\n getType() type %s", typeid(this).name());}
   virtual ~B(){}
};

class D : public B
{
   int c;
};

int main()
{
   D d;
   B *temp = new D();
   printf("\ntype %s", typeid(*temp).name());
   temp->getType();

   char *test;
   printf("\ncalling first malloc\n");
   test = (char*)malloc(10);
   printf("\ncalling second malloc\n");
   test = (char*)malloc(20);

   printf("\nsleeping\n");


   sleep(100);
   return 0;
}

