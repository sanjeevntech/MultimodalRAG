clear
. run.sh
rm -f ./log/*.log
rm -f ./log/db/*.log
rm -f ./trace/*.log
rm -f core
SHM=100
$HLR_FRAMEWORK_ROOT/map-ng/PKG/mapNG -config NgConfig.xml -res
