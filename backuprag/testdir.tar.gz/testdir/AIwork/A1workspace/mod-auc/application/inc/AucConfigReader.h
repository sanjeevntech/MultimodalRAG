#ifndef __AUC_CONFIG_READER_H
#define __AUC_CONFIG_READER_H

#include <ConfigReader.h>

class AucConfigReader: public ConfigReader
{
   private:

   public:
      AucConfigReader();
      ~AucConfigReader();

      bool readData();
      void printConfigData(char *p_output);

      // AUC Module Configuration Parameters
      int m_MAX_NUM_OF_VECTORS_IN_A_CHUNK;
      int m_MAX_NUM_OF_TOTAL_VECTORS;
      int m_TestFlag;
      int m_TestRandFlag;
      int m_ConstantRandomFlag;
      bool m_DEBUG_MODE;
      int m_MAP3_SUCCESSIVE_INVOKE_TIMEOUT;
      int m_MAP3_LOCKED_SUBSCRIBER_RETRY_COUNT;
      int m_MAP3_LOCKED_SUBSCRIBER_RETRY_TIMER;
      int m_MULTI_IMSI_VALIDATION_FLAG;
      int m_SUBS_BARRED_VALIDATION_FLAG;
      int m_REQUESTING_NODE_VALIDATION_FLAG;
      int m_LTE_REQUESTING_NODE_VALIDATION_FLAG;
      char m_MAP3_QUIN_OR_TRIPLETS;
      int m_Custom_RI_CI_Values ;
      int m_MAP3_DOWNGRADE_VECTORS;
      int m_CONGESTION_MAP3_DOWNGRADE_VECTORS;
      int m_RandFlag;
      int m_IMS_REQUESTING_NODE_VALIDATION_FLAG;
      int m_SAI_AIR_MemcachedFlag;
      int m_MAR_MemcachedFlag;
      int m_ADD_NETWORK_ID_IN_MAA_CUSTOM_AVP_FLAG;
      int m_SQN_DISTRIBUTION_FLAG;
      int m_SWX_REQUESTING_NODE_VALIDATION_FLAG;

};

extern AucConfigReader *g_AucConfigReaderObj;
extern bool resetStruct(int p_version, int p_pdu, void *p_struct);
extern char *g_fixed_rand;


#endif
