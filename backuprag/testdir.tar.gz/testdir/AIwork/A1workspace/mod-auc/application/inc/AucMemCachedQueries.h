#ifndef __AUC_MEMC_QUERIES_H
#define __AUC_MEMC_QUERIES_H

class AucMemCachedQueries 
{
   public:
      AucMemCachedQueries();
      ~AucMemCachedQueries();
};

extern bool IsSubscriberOtherImsi(char* pImsi);


#endif
