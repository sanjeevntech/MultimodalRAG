#ifndef __AUC_DB_QUERIES_H
#define __AUC_DB_QUERIES_H
#include <DbQueryMsg.h>

#include <ByteMilenage.h>


//values taken from 29.002 RequestingNodeType
enum ERequestingNodeType
{
   REQUEST_NODE_UNKNOWN=0,
   REQUEST_NODE_VLR,
   REQUEST_NODE_SGSN,
   REQUEST_NODE_BSF,
   REQUEST_NODE_S_CSCF,
   REQUEST_NODE_GAN_AAA_SERVER,
   REQUEST_NODE_WLAN_AAA_SERVER,
   REQUEST_NODE_MME,
   REQUEST_NODE_BOTH_MME_SGSN
};


#define NODE_HOST_MAX_SIZE   100
#define NODE_REALM_MAX_SIZE  100
class OssTrigData2
{
   public:
      OssTrigData2();
      ~OssTrigData2();
      char  m_rowId[30+1];
      char  m_transId[20+1];
      int   m_opCode;
      char  m_transXml[1000+1];
};


class RetrieveSubsAuthData : public DbQueryMsg
{
   public:
      RetrieveSubsAuthData();
      ~RetrieveSubsAuthData();

      bool executeQuery(void*);
      void executeMemcQuery();
      void serializeMemc();
      bool deSerializeMemc();

      //Inputs
      char m_imsi[16+1];

      bool m_resynchFlag;
      u8 m_resynchRand[16];
      u8 m_resynchAuts[14];
      ERequestingNodeType m_requestNode;
      char m_OrigAddr[20+1];

      //Outputs
      u8  m_k[16];
      u8  m_first_k[16];
      u8  m_k_key[32];
      int m_k_len_key;
      u8  m_iv_char[32];
      int m_iv_len_char;
      u8  m_op[16];  
      u8  m_sqn[6];
      u8  m_amf[2];
      u8  m_rand[16];
      char m_msisdn[16+1];

      int m_ki_enc_algo;
      int m_ki_enc_mode;
      int m_auth_algo;

      int m_subsType; //3-3G, 2-2G
      char m_accountId[20+1];
      char m_hlrAddress[20];
      int m_imsiType;
      int m_Customized_RC_Flag;
      short unsigned int m_R1;
      short unsigned int m_R2;
      short unsigned int m_R3;
      short unsigned int m_R4;
      short unsigned int m_R5;
      u8 m_C1[16];
      u8 m_C2[16];
      u8 m_C3[16];
      u8 m_C4[16];
      u8 m_C5[16];

      int m_errCode;
      int m_msgVersion;

      int m_retryCount;
      int m_retryTimer;

      int m_multi_imsi_validation_flag;
      int m_subs_barred_validation_flag;
      int m_requesting_node_validation_flag;
      int m_maxVectors;
      char m_Map3QuinOrTriplets;
      int m_TestFlag;

      char m_mmeHost     [NODE_HOST_MAX_SIZE+1];
      char m_mmeRealm    [NODE_REALM_MAX_SIZE+1];
      char m_hssHost     [NODE_HOST_MAX_SIZE+1];
      char m_hssRealm    [NODE_REALM_MAX_SIZE+1];
      int  m_s6aRelease;
      char m_primaryImsi[15+1];
      int  m_nam;
      int  m_networkId;
      int  m_AucTemplateId;
      int  m_RoamPartnerId;
      char m_scscfHost[NODE_HOST_MAX_SIZE+1];
      char m_scscfRealm[NODE_REALM_MAX_SIZE+1];
      char m_scscfName[100+1];
      char m_requestNodeStr[30+1];
      int m_curCount;
      int m_ossTriggerDataCount;
      char m_visitedNwkID_DB[100+1];
      char m_errMsg_DB[200+1];
      int m_AAA_Failure_Indication_DB;
      OssTrigData2    m_ossTriggerDataArray[5];
      int m_mappedErrCode;
      int m_imsProfId;
      	
};

class UpdateSubsAuthData : public DbQueryMsg 
{
   public:
      UpdateSubsAuthData();
      ~UpdateSubsAuthData();

      bool executeQuery(void*);
      void executeMemcQuery();
      void serializeMemc();
      bool deSerializeMemc();

      //Inputs
      char m_imsi[16+1];
      char m_accountId[20+1];
      ERequestingNodeType m_requestNode;
      u8  m_sqn[6];

      int  m_networkId;
      int  m_AucTemplateId;
      int  m_RoamPartnerId;
      char m_primaryImsi[15+1];
      char m_msisdn[16+1];
      int  m_PartnerTpe;

      u8  m_k[16];
      u8  m_first_k[16];
};

class RetrieveDirectMemcQuery : public MemCachedQueryMsg 
{
   public: 
      RetrieveDirectMemcQuery();
      ~RetrieveDirectMemcQuery();

      virtual void executeMemcQuery();
      virtual void serializeMemc();
      virtual bool deSerializeMemc();

      ERequestingNodeType m_requestNode;
      char m_primaryImsi[15+1];
      bool m_OtherImsiSubscriberFlag;

      u8  m_sqn[6];
};

#endif
