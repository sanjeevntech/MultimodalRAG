#ifndef __HSS_SIM_AUC_SWX_MAR_MAA_H
#define __HSS_SIM_AUC_SWX_MAR_MAA_H

#include <ContextBase.h>
#include <MapMessages.h>
#include <MapConstants.h>
#include <Msg.h>
#include <diameter/swx_rel_18/SWxMessages.h>
#include <diameter/swx_rel_18/SWx_rel_18AVP.h>
#include <DiameterMessages.h>

#include <SubsProfileData.h>
#include <DiametriqInterface.h>


using namespace diameter::SWx_rel_18;
using namespace diameter::base;

class CtxtSimulatorImsSwxMultimediaAuthRequest : public ContextBase
{
   private:

   public:
      CtxtSimulatorImsSwxMultimediaAuthRequest();
      virtual ~CtxtSimulatorImsSwxMultimediaAuthRequest();

      bool startProcessing();
      bool processMessage(Msg *p_MsgPtr,bool &p_DeleteFlag);
};


#endif
