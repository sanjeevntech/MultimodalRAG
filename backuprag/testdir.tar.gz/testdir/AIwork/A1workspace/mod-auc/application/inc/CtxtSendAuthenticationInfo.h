#ifndef __CONTEXT_SEND_AUTH_INFO_H
#define __CONTEXT_SEND_AUTH_INFO_H

#include <ContextBase.h>
#include <Msg.h>
#include <ByteMilenage.h>
#include <AucDbQueries.h>

extern int g_EmergencyFlag;

enum ERequestOrigin
{
   REQUEST_ORIGIN_UNKNOWN=0,
   REQUEST_ORIGIN_SS7,
   REQUEST_ORIGIN_DIAMETER_S6A,
   REQUEST_ORIGIN_DIAMETER_CX,
   REQUEST_ORIGIN_DIAMETER_SWX
};

enum EErrorDiagnostic
{
   ERROR_DIAGNOSTIC_NOT_REQUIRED=-1,
   ERROR_DIAGNOSTIC_GPRS_DATA_SUBSCRIBED=0,
   ERROR_DIAGNOSTIC_NO_GPRS_DATA_SUBSCRIBED,
   ERROR_DIAGNOSTIC_ODB_ALL_APN,
   ERROR_DIAGNOSTIC_ODB_HPLMN_APN,
   ERROR_DIAGNOSTIC_ODB_VPLMN_APN
};

struct AucVectors
{
   public:
      AucVectors();
      ~AucVectors();

      u8 m_rand[16];
      u8 m_op_c[16];
      u8 m_res[8];
      u8 m_ck[16];
      u8 m_ik[16];
      u8 m_ak[6];
      u8 m_kc[8];
      u8 m_sres[4];
      u8 m_mac_a[8];
      u8 m_autn[16];
      u8 m_auts[14];
      u8 m_kasme[32];


      u8 m_digest_realm[100+1];
      u8 m_HA1[32];
      u8 m_qop[20];
      u8 m_digest_rand[16];
};



class CtxtSendAuthenticationInfo : public ContextBase
{
   private:
      bool initiateDbRequest(Msg *p_MsgPtr); // Input Parameter is Map Specific Msg
      bool handleDbResponse(Msg *p_MsgPtr);  // Input Parameter is Db Response Msg
      bool sendFurtherResponses(); // This would be called for sending further chunked responses
      bool handleError(unsigned int aVendorId, unsigned int aErrCode, EErrorDiagnostic p_ed);

      int m_firstSaiFlag;// This flag is used to understand whether the first SAI request or successive ones
      int m_maxVectors;
      int m_additionalMaxVectors; //Added for LTE-AuC
      unsigned int m_irp_mme; //Added for LTE-AuC
      unsigned int m_irp_sgsn; //Added for LTE-AuC
      ERequestingNodeType m_rnt;
      ERequestOrigin  m_ro;
      int m_totalSentCount;

      RetrieveSubsAuthData *m_rsad;
      //UpdateSubsAuthData *m_usad;

      int m_v1AuthIndex;
      char m_OrigAddr[20+1];

      unsigned int m_timerId;

      bool m_dlgStatusFlag; 
      int  m_subsType;
      int m_networkId;
      int m_invalidAuthScheme;
      int m_CxFeatureListIdFlag; //6.4.12.0

      Msg *m_msgPtr;

      char m_originHost[100+1];
      char m_originRealm[100+1];
      char m_proxyHost[100+1];
      char m_proxyState[100+1];
      unsigned char m_vplmnId[3];

      bool m_OtherImsiSubscriberFlag;
      int m_Customized_RC_Flag;
      short unsigned int m_R1;
      short unsigned int m_R2;
      short unsigned int m_R3;
      short unsigned int m_R4;
      short unsigned int m_R5;
      u8 m_C1[16];
      u8 m_C2[16]; 
      u8 m_C3[16];
      u8 m_C4[16]; 
      u8 m_C5[16];

   public:
      CtxtSendAuthenticationInfo();
      ~CtxtSendAuthenticationInfo();

      bool processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag);

      char m_user_name[100+1];
      char m_publicIden[200+1];
      char m_domainName[200+1];
      char m_AAAServerName[100+1];
      string m_password;
      int m_AAAFailureIndication;
      int m_memcUpdateInd; //6.4.12.4
      AucVectors m_vectors[5];
};



#endif
