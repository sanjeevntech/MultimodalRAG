#ifndef __COMP_ALGORITHMS_H
#define __COMP_ALGORITHMS_H

#include <string.h>

typedef unsigned char u8;

enum ECompAlgo
{
   COMP_ALGO_UNKNOWN=0,
   COMP_ALGO_1=1,
   COMP_ALGO_2=2,
   COMP_ALGO_3=3
};

extern bool calculateCompVectors(u8 k[16], u8 rand[16], u8 kc[8], u8 sres[4], ECompAlgo p_compAlgo);



#endif
