#ifndef __CONTEXT_SIMULATOR_SEND_AUTH_INFO_H
#define __CONTEXT_SIMULATOR_SEND_AUTH_INFO_H

#include <ContextBase.h>
#include <Msg.h>



class CtxtSimulatorSendAuthenticationInfo : public ContextBase
{
   private:

   public:
      CtxtSimulatorSendAuthenticationInfo();
      ~CtxtSimulatorSendAuthenticationInfo();

      bool startProcessing();
      bool processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag);
};



#endif
