#ifndef __CONTEXT_AUTH_FAIL_REPORT_H
#define __CONTEXT_AUTH_FAIL_REPORT_H

#include <ContextBase.h>
#include <Msg.h>
#include <AucDbQueries.h>


class CtxtAuthenticateFailureReport : public ContextBase
{
	private:

	public:
		CtxtAuthenticateFailureReport();
		~CtxtAuthenticateFailureReport();

      char m_OrigAddr[20+1];

		bool processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag);
};



#endif
