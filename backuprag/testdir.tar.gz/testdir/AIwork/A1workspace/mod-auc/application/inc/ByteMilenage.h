#ifndef __BYTE_MILENAGE_H
#define __BYTE_MILENAGE_H

#include <string.h>
#include <stdlib.h>

typedef unsigned char u8;

#pragma pack(1)
struct SqnStruct {
#ifdef Linux
    unsigned int m_ind : 5;
    unsigned int m_seq2 : 24;
    unsigned int m_seq1 : 19;
#else
    unsigned int m_seq1 : 19;
    unsigned int m_seq2 : 24;
    unsigned int m_ind : 5;
#endif
};
#pragma pack()


extern bool calculateKASME(u8 p_k1[16], u8 p_k2[16], u8 p_fc, u8 p_snId[3], u8 p_autn[16], u8 p_kasme[32]);

class ByteMilenage
{
    public:
        ByteMilenage();
        ~ByteMilenage();

        u8 m_OP[16];
        u8 m_sqn[6];
};

extern ByteMilenage g_ByteMilenageObj;

extern bool calculateMilenageVectors (u8 k[16], u8 rand[16], int sresDerivFuncNo, u8 sqn[6], u8 amf[2], short unsigned int R1_VALUE, u8 C1_VALUE[16], short unsigned int R2_VALUE, short unsigned int R3_VALUE, short unsigned int R4_VALUE, u8 C2_VALUE[16], u8 C3_VALUE[16], u8 C4_VALUE[16], u8 op_c[16], u8 res[8], u8 ck[16], u8 ik[16], u8 ak[6], u8 kc[8], u8 sres[4], u8 mac_a[8], u8 autn[16]);

extern void printHexOnDebug(char *p_text, char *p_buffer, int p_length);

bool calculateAuts(u8 amf[2], u8 k[16], u8 rand[16], u8 sqn[6], short unsigned int R1_VALUE, u8 C1_VALUE[16], short unsigned int R5_VALUE, u8 C5_VALUE[16] , u8 auts[6]);
bool resynchronizeFunc(u8 amf[2], u8 k[16], u8 rand[16], u8 auts[6], u8 sqn[6], short unsigned int R1_VALUE, u8 C1_VALUE[16], short unsigned int R5_VALUE, u8 C5_VALUE[16]);

extern void calculateSqn(unsigned char p_sqn[6], unsigned int p_seq1, unsigned int p_seq2, unsigned int p_ind);
extern void decodeSqn   (unsigned char p_sqn[6], unsigned int *p_seq1, unsigned int *p_seq2, unsigned int *p_ind);
char* Hex2Str(u8* buffIn, int lenIn, char* strSeparator, int lenOut, char* buffOut);

#endif
