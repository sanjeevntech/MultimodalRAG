#ifndef __DES_CODEC_H
#define __DES_CODEC_H

/* DES Encryption & Decryption Code */ 

class DesCodec
{
    public:
        bool decrypt(unsigned char *p_nonEncrypted, unsigned char *p_Encrypted, unsigned char *p_key);
        bool decryptTripleDes(unsigned char *p_nonEncrypted, unsigned char *p_Encrypted, unsigned char *p_key, int );
        bool decryptData(unsigned char *p_nonEncrypted, 
      unsigned char *p_Encrypted, 
      int            p_enc_algo,
      unsigned char *p_key, 
      int            p_len_key,
      unsigned char *p_ivchar,
      int            p_len_ivchar,
      int            p_mode,
      int p_type);

}; 

#endif

