#ifndef __CONTEXT_VLR_SEND_AUTH_INFO_H
#define __CONTEXT_VLR_SEND_AUTH_INFO_H

#include <ContextBase.h>
#include <Msg.h>
#include <MapMessages.h>


class CtxtVLRSendAuthenticationInfo : public ContextBase
{
   private:
      bool initiateSAI();
      bool sendv3SAI(int);
      bool sendv2SAI(int);
      bool sendv1SAI(int);
      bool sendv2SAIFromHex(int p_dialogue);


      EMapVersion m_version;

   public:
      CtxtVLRSendAuthenticationInfo();
      ~CtxtVLRSendAuthenticationInfo();

      bool processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag);
      bool startProcessing();
};

#endif
