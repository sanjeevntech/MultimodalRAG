#ifndef __HSS_SIM_AUC_MAR_MAA_H
#define __HSS_SIM_AUC_MAR_MAA_H

#include <ContextBase.h>
#include <MapMessages.h>
#include <MapConstants.h>
#include <Msg.h>
#include <diameter/cx_rel_16/CxMessages.h>
#include <diameter/cx_rel_16/Cx_rel_16AVP.h>
#include <DiameterMessages.h>

#include <SubsProfileData.h>
#include <DiametriqInterface.h>


using namespace diameter::Cx_rel_16;
using namespace diameter::base;

class CtxtSimulatorImsMultimediaAuthRequest : public ContextBase
{
   private:

   public:
      CtxtSimulatorImsMultimediaAuthRequest();
      virtual ~CtxtSimulatorImsMultimediaAuthRequest();

      bool startProcessing();
      bool processMessage(Msg *p_MsgPtr,bool &p_DeleteFlag);
};


#endif
