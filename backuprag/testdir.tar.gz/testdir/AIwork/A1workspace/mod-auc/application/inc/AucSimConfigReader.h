#ifndef __AUC_SIM_CONFIG_READER_H
#define __AUC_SIM_CONFIG_READER_H

#include <ConfigReader.h>

class AucSimConfigReader: public ConfigReader
{
    private:

    public:
        AucSimConfigReader();
        ~AucSimConfigReader();

		   bool readData();
         void printConfigData(char *p_output);

// AUC Simulator Configuration Parameters
int m_simVersion;
int m_CxSwxFlag;
char m_simImsi[16+1];

};

extern AucSimConfigReader *g_AucSimConfigReaderObj;
extern bool resetStruct(int p_version, int p_pdu, void *p_struct);


#endif
