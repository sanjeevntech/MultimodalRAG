#include"gtest.h"
extern int hextoint (char x);
extern void CompF(int A[16], int B[16], int C[16]);

TEST(Comp2Algo_cpp_hextoint_Func, Return_int) {
char x='A';
EXPECT_NE(hextoint(x),NULL);
}

TEST(Comp2Algo_cpp_hextoint_Func, Return_T_Int) {
char x='A';
EXPECT_NE(hextoint(x),NULL);
}

/*TEST(Comp2Algo_cpp_CompF_Func, Return_Void)  {
int A[]={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16};
int B[]={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16};
int C[]={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16};
EXPECT_NO_THROW(CompF(A,B,C));
}*/
