#define private public

#include"gtest.h"
#include <CtxtAuthenticateFailureReport.h>
#include <MapMessages.h>
#include <IMAP3.h>
#include <AucDbQueries.h>
#include <AucConfigReader.h>
#include <AucDbQueries.h>
#include <Msg.h>
#include<MapConstants.h>
#include<IMAP3.h>

class UT_CtxtAuthenticateFailureReport: public testing::Test , public CtxtAuthenticateFailureReport,public Msg, public MapMsg, public MapCommonMsg, public MapSpecificMsg
{public:
UT_CtxtAuthenticateFailureReport()
{
}
~UT_CtxtAuthenticateFailureReport()
{
}
};

TEST_F(UT_CtxtAuthenticateFailureReport,MAP_CMN_OPEN_IND_Func){
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=202;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtAuthenticateFailureReport,MAP_CMN_DELIMITER_IND_Func){
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=208;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtAuthenticateFailureReport,MAP_CMN_CLOSE_IND_Func){
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=206;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtAuthenticateFailureReport,MAP_CMN_U_ABORT_IND_Func){
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=210;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtAuthenticateFailureReport,MAP_CMN_P_ABORT_IND_Func){
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=212;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtAuthenticateFailureReport,MAP_CMN_NOTICE_IND_Func){
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=213;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtAuthenticateFailureReport,default_Func){
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MapCommonMsgType=200;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtAuthenticateFailureReport,MAP_OP_CODE_authenticationFailureReport_Func){
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=2;
p_MsgPtr.m_OpCode=15;
p_MsgPtr.m_allocatedFlag=false;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

/*TEST_F(UT_CtxtAuthenticateFailureReport,MAP_OP_CODE_authenticationFailureReport_else_Func){
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=2;
p_MsgPtr.m_OpCode=15;
p_MsgPtr.m_allocatedFlag=true;
bool p_DeleteFlag=true;
IMAP3_AuthenticationFailureReportArg ab;
ab.imsi.value[8]="abcdefgh";
ab.imsi.length=8;
ab.bit_mask='@';
p_MsgPtr.m_structBuffer=&ab;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}*/

TEST_F(UT_CtxtAuthenticateFailureReport,MAP_SPEC_EVENT_RESULT_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=3;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtAuthenticateFailureReport,MAP_SPEC_EVENT_CONFIRMATION_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=4;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtAuthenticateFailureReport,MAP_SPEC_EVENT_USER_ERROR_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=5;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtAuthenticateFailureReport,default_MapSpecificMsg_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MapSpecificEventType=0;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtAuthenticateFailureReport,MSG_TYPE_DB_Func) {
RetrieveSubsAuthData p_MsgPtr;
p_MsgPtr.m_MsgType=2;
strcpy(p_MsgPtr.m_hlrAddress,"abcd");
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtAuthenticateFailureReport,else_MSG_TYPE_DB_Func) {
RetrieveSubsAuthData p_MsgPtr;
p_MsgPtr.m_MsgType=2;
strcpy(p_MsgPtr.m_hlrAddress,"abcd");
p_MsgPtr.m_DbQueryRes=1;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtAuthenticateFailureReport,Last_default_Func) {
RetrieveSubsAuthData p_MsgPtr;
p_MsgPtr.m_MsgType=0;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}






#undef private

