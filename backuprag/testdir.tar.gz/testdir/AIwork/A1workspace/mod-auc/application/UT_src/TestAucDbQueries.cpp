#include"gtest.h"
#include<AucDbQueries.h>

class UT_RetrieveSubsAuthData: public testing::Test , public RetrieveSubsAuthData
{public:
UT_RetrieveSubsAuthData()
{
}
~UT_RetrieveSubsAuthData()
{
}
};

class UT_UpdateSubsAuthData: public testing::Test , public UpdateSubsAuthData
{public:
UT_UpdateSubsAuthData()
{
}
~UT_UpdateSubsAuthData()
{
}
};

class UT_RetrieveDirectMemcQuery: public testing::Test , public RetrieveDirectMemcQuery
{public:
UT_RetrieveDirectMemcQuery()
{
}
~UT_RetrieveDirectMemcQuery()
{
}
};

/*
TEST_F(UT_RetrieveSubsAuthData,executeQuery_Func) {
int p_conn[]={1,2,3,4,5,6,7,8,9,10};
EXPECT_TRUE(executeQuery(p_conn));
}


TEST_F(UT_RetrieveSubsAuthData,executeQuery_Two_Func) {
int p_conn[]={1,2,3,4,5,6,7,8,9,10};
RetrieveSubsAuthData::m_errCode=1;
EXPECT_TRUE(executeQuery(p_conn));
}*/

TEST_F(UT_UpdateSubsAuthData,executeQuery_Func) {
int p_conn[]={1,2,3,4,5,6,7,8,9,10};
EXPECT_TRUE(executeQuery(p_conn));
}

