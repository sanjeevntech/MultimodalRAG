#define private public

#include"gtest.h"
//#include"AucInitializer.cpp"
//#include"../src/AucInitializer.cpp"
#include <ModuleBase.h>
#include <AucConfigReader.h>
#include<MapMessages.h>
#include<MapConstants.h>
#include<CtxtSendAuthenticationInfo.h>
#include<DiameterConstants.h>
#include <DiameterMessages.h>
#include <ExtendedServiceCoordinator.h>


extern bool resetStruct(int p_version, int p_pdu, void *p_struct);
class AucModule : public ModuleBase
{
   public:
      AucModule(){}
      bool initModule();
      ContextBase *getCtxtObj(EMapOpCode, MapSpecificMsg*);
      ContextBase *getCtxtObj(EDiameterCommandCode, DiameterMsg*);
      char *getVersion();
      ConfigReader *getConfigReaderObj();
      ConfigReader **retrieveConfigReaderPtr();
};
extern bool g_loadFlag;

//extern AucModule g_AucModule;
class UT_AucModule: public testing::Test , public AucModule, public CtxtSendAuthenticationInfo
{public:
UT_AucModule()
{
}};
/*~UT_AucModule()
{
}
};*/

class UT_MapSpecificMsg: public testing::Test , public MapSpecificMsg
{public:
UT_MapSpecificMsg()
{
}
~UT_MapSpecificMsg()
{
}
 };

class UT_DiameterMsg : public testing::Test , public DiameterMsg 
{public:
UT_DiameterMsg() //("host26.realm26;1628358902;498433;1:2",DIAM_EVENT_REQUEST,318)
{
}
~UT_DiameterMsg ()
{
}
 };


class UT_CtxtSendAuthenticationInfo: public testing::Test , public CtxtSendAuthenticationInfo
{public:
UT_CtxtSendAuthenticationInfo()
{
}
~UT_CtxtSendAuthenticationInfo()
{
}
 };
/*
TEST_F(UT_AucModule,initModule_Func){
EXPECT_TRUE(initModule());
g_loadFlag=true;
EXPECT_TRUE(initModule());
}
*/
/*TEST_F(UT_AucModule,getVersion_Func){
EXPECT_NE(getVersion(),NULL);
}

TEST_F(UT_AucModule,getCtxtObj_Func){
EXPECT_NE(getCtxtObj(MAP_OP_CODE_sendAuthenticationInfo,NULL),NULL);
g_loadFlag=false;
EXPECT_NE(getCtxtObj(MAP_OP_CODE_sendAuthenticationInfo,NULL),NULL);
}

TEST_F(UT_AucModule,getCtxtObj_TWO_Func){
EXPECT_NE(getCtxtObj(MAP_OP_CODE_sendParameters,false),NULL);
//EXPECT_NE(getCtxtObj(MAP_OP_CODE_sendParameters,true),NULL);
}


TEST_F(UT_AucModule,getCtxtObj_THREE_Func){
EXPECT_NE(getCtxtObj(MAP_OP_CODE_authenticationFailureReport,NULL),NULL);
}

TEST_F(UT_AucModule,getCtxtObj_FOUR_Func){
EXPECT_NE(getCtxtObj(MAP_OP_CODE_updateLocation,NULL),NULL);
}*/

/*TEST(AucInitializer_cpp_resetStruct_Func, Return_Bool) {
int p_version=1;
int p_pdu=1;
//int p_struct=NULL;
EXPECT_NE(resetStruct(p_version,p_pdu,NULL),NULL);
}*/
/*
//Balaji used
TEST_F(UT_AucModule,getCtxtObj_Func) {
MapSpecificMsg p_msg;
g_loadFlag=false;
EXPECT_NE(getCtxtObj(56,&p_msg),NULL);
}
*/
/*TEST_F(UT_AucModule,getCtxtObj_Two_Func) {
MapSpecificMsg p_msg;
g_loadFlag=true;
m_user_name[100+1]="abcdef";
m_password="adfsghjyt";
//m_vectors[5]="gfdtl";
sprintf(m_vectors,"adgyth");
EXPECT_NE(getCtxtObj(56,&p_msg),NULL);
}*/
/* 
TEST_F(UT_AucModule,getCtxtObj_Two_Func) {
MapSpecificMsg p_msg;
p_msg.m_allocatedFlag=false;
EXPECT_EQ(getCtxtObj(9,&p_msg),NULL);
}

TEST_F(UT_AucModule,getCtxtObj_default_Func) {
MapSpecificMsg p_msg;
EXPECT_EQ(getCtxtObj(0,&p_msg),NULL);
}

TEST_F(UT_AucModule,getCtxtObj_Three_Func) 
{
MapSpecificMsg p_msg;
EXPECT_NE(getCtxtObj(15,&p_msg),NULL);
}

TEST_F(UT_AucModule,getCtxtObj_Dia_Func)
{
DiameterMsg p_msg("host26.realm26;1628358902;498433;1:2",DIAM_EVENT_REQUEST,318);
g_loadFlag=false;
EXPECT_NE(getCtxtObj(318,&p_msg),NULL);
}

TEST_F(UT_AucModule,getCtxtObj_Dia_one_Func)
{
DiameterMsg p_msg("host26.realm26;1628358902;498433;1:2",DIAM_EVENT_REQUEST,318);
g_loadFlag=true;
EXPECT_NE(getCtxtObj(318,&p_msg),NULL);
}

TEST_F(UT_AucModule,getCtxtObj_DIAM_COMM_CODE_CX_DX_MAR_MAA_Func)
{
DiameterMsg p_msg("host26.realm26;1628358902;498433;1:2",DIAM_EVENT_REQUEST,303);
g_loadFlag=false;
EXPECT_NE(getCtxtObj(303,&p_msg),NULL);
}

TEST_F(UT_AucModule,getCtxtObj_else_DIAM_COMM_CODE_CX_DX_MAR_MAA_Func)
{
DiameterMsg p_msg("host26.realm26;1628358902;498433;1:2",DIAM_EVENT_REQUEST,303);
g_loadFlag=true;
EXPECT_NE(getCtxtObj(303,&p_msg),NULL);
}

TEST_F(UT_AucModule,getCtxtObj_DIAM_default_Func)
{
DiameterMsg p_msg("host26.realm26;1628358902;498433;1:2",DIAM_EVENT_REQUEST,0);
EXPECT_EQ(getCtxtObj(0,&p_msg),NULL);
}*/


/*
TEST_F(UT_AucModule,getConfigReaderObj_Func) {
g_loadFlag=false;
EXPECT_NE(getConfigReaderObj(),NULL);
g_loadFlag=true;
EXPECT_NE(getConfigReaderObj(),NULL);
}
*/
/*
TEST_F(UT_AucModule,retrieveConfigReaderPtr_Func) {
g_loadFlag=false;
EXPECT_NE(retrieveConfigReaderPtr(),NULL);
g_loadFlag=true;
EXPECT_NE(retrieveConfigReaderPtr(),NULL);
}
*/ 
TEST(AucInitializer_cpp_resetStruct_Func, Return_False) {
int p_version=1;
int p_pdu=1;
char p_struct[]="ABCDF";
EXPECT_FALSE(resetStruct(p_version,p_pdu,p_struct));
}


TEST(AucInitializer_cpp_resetStruct_Func, Return_Two_False) {
int p_version=2;
int p_pdu=1;
char p_struct[]="ABCDF";
EXPECT_FALSE(resetStruct(p_version,p_pdu,p_struct));
}

TEST(AucInitializer_cpp_resetStruct_Func, Return_Third_False) {
int p_version=3;
int p_pdu=1;
char p_struct[]="ABCDF";
EXPECT_FALSE(resetStruct(p_version,p_pdu,p_struct));
}

TEST(AucInitializer_cpp_resetStruct_Func, Return_Four_False) {
int p_version=4;
int p_pdu=1;
char p_struct[]="ABCDF";
EXPECT_FALSE(resetStruct(p_version,p_pdu,p_struct));
}





#undef private

