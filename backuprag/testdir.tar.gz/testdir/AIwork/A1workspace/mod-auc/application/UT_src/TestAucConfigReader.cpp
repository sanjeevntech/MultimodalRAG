#include"gtest.h"
#include<AucConfigReader.h>
#include<ConfigReader.h>

extern u8 g_test_rand[];

class UT_AucConfigReader: public testing::Test , public AucConfigReader
{public:
UT_AucConfigReader()
{
}
~UT_AucConfigReader()
{
}
};

/*class UT_ConfigReader: public testing::Test , public ConfigReader
{public:
UT_ConfigReader()
{
}
~UT_ConfigReader()
{
}
};*/


TEST_F(UT_AucConfigReader,readData_Func) {
EXPECT_FALSE(readData());
}

/*TEST_F(UT_AucConfigReader,printConfigData_Func) {
char p_output[350];
EXPECT_NO_THROW(printConfigData(p_output));
}*/

/*TEST_F(UT_AucConfigReader,readData_Two_Func) {
g_fixed_rand="abdcf";
ConfigReader::m_DataString="absertghjkloiuytrertyjkliuytrert";
sprintf(g_test_rand,"abcdefg");
//g_test_rand[]="abgfdt";
EXPECT_TRUE(readData());
}*/

