#include"gtest.h"
#include<CompAlgorithms.h>
extern int hextoint (char x);
extern void CompF(u8 *A, u8 *B, u8 *C);
extern bool calculateCompVectors(u8 p_k[16], u8 p_rand[16], u8 kc[8], u8 sres[4], ECompAlgo p_compAlgo);


TEST(CompAlgorithms_cpp_hextoint_Func, Return_int) {
char x='A';
EXPECT_NE(hextoint(x),NULL);
}

TEST(CompAlgorithms_cpp_hextoint_Func, Return_T_Int) {
char x='A';
EXPECT_NE(hextoint(x),NULL);
}

TEST(CompAlgorithms_cpp_CompF_Func, Return_Void)  {
unsigned char A[]={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16};
unsigned char B[]={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16};
unsigned char C[]={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16};
EXPECT_NO_THROW(CompF(A,B,C));
}

TEST(CompAlgorithms_cpp_calculateCompVectors_Func, Return_True)  {
unsigned char p_k[]={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16};
unsigned char p_rand[]={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16};
unsigned char kc[]={1,2,3,4,5,6,7,8};
unsigned char sres[]={1,2,3,4};
EXPECT_TRUE(calculateCompVectors(p_k,p_rand,kc,sres,2));
}

TEST(CompAlgorithms_cpp_calculateCompVectors_Func, Return_T_True)  {
unsigned char p_k[]={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16};
unsigned char p_rand[]={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16};
unsigned char kc[]={1,2,3,4,5,6,7,8};
unsigned char sres[]={1,2,3,4};
EXPECT_TRUE(calculateCompVectors(p_k,p_rand,kc,sres,3));
}

TEST(CompAlgorithms_cpp_calculateCompVectors_Func, Return_False)  {
unsigned char p_k[]={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16};
unsigned char p_rand[]={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16};
unsigned char kc[]={1,2,3,4,5,6,7,8};
unsigned char sres[]={1,2,3,4};
EXPECT_FALSE(calculateCompVectors(p_k,p_rand,kc,sres,0));
}


