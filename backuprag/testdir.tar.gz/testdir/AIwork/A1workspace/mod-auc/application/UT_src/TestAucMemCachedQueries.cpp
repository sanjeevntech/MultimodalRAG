#include"gtest.h"
#include<AucMemCachedQueries.h>
#include<AucDbQueries.h>
#include<string.h>

extern void KiSwapSomeBytes(unsigned char* pKI, unsigned char* pSwappedKI);
extern void KiRevertSwapppedBytes(unsigned char* pKI, unsigned char* pSwappedKI);
class UT_AucMemCachedQueries: public testing::Test , public AucMemCachedQueries
{public:
UT_AucMemCachedQueries()
{
}
~UT_AucMemCachedQueries()
{
}
};

class UT_RetrieveSubsAuthData: public testing::Test , public RetrieveSubsAuthData
{public:
UT_RetrieveSubsAuthData()
{
}
~UT_RetrieveSubsAuthData()
{
}
};

class UT_UpdateSubsAuthData: public testing::Test , public UpdateSubsAuthData
{public:
UT_UpdateSubsAuthData()
{
}
~UT_UpdateSubsAuthData()
{
}
};

class UT_RetrieveDirectMemcQuery: public testing::Test , public RetrieveDirectMemcQuery
{public:
UT_RetrieveDirectMemcQuery()
{
}
~UT_RetrieveDirectMemcQuery()
{
}
};


TEST(AucMemCachedQueries_cpp_KiSwapSomeBytes_Func, Return_void) {
unsigned char pKI[]={0xb7,0x3a,0x90,0xcb,0xcf,0x3a,0xfb,0x62,0x2d,0xba,0x83,0xc5,0x8a,0x84,0x15,0xdf};
unsigned char pSwappedKI[]={0xb1,0x20,0xf1,0xc1,0xa0,0x10,0x2a,0x2f,0x50,0x7d,0xd5,0x43,0xde,0x68,0x28,0x1f};
EXPECT_NO_THROW(KiSwapSomeBytes(pKI,pSwappedKI));
}

TEST(AucMemCachedQueries_cpp_KiRevertSwapppedBytes_Func, Return_void) {
unsigned char pKI[]={0xb7,0x3a,0x90,0xcb,0xcf,0x3a,0xfb,0x62,0x2d,0xba,0x83,0xc5,0x8a,0x84,0x15,0xdf};
unsigned char pSwappedKI[]={0xb1,0x20,0xf1,0xc1,0xa0,0x10,0x2a,0x2f,0x50,0x7d,0xd5,0x43,0xde,0x68,0x28,0x1f};
EXPECT_NO_THROW(KiRevertSwapppedBytes(pKI,pSwappedKI));
}
/*
TEST_F(UT_RetrieveSubsAuthData,executeMemcQuery_Func) {
EXPECT_NO_THROW(executeMemcQuery());
}
*/

TEST_F(UT_RetrieveSubsAuthData,serializeMemc_Func) {
EXPECT_NO_THROW(serializeMemc());
}

TEST_F(UT_RetrieveSubsAuthData,deSerializeMemc_Func) {
EXPECT_FALSE(deSerializeMemc());
}

/*
TEST_F(UT_UpdateSubsAuthData,executeMemcQuery_Func) {
EXPECT_NO_THROW(executeMemcQuery());
}
*/

TEST_F(UT_UpdateSubsAuthData,serializeMemc_Func) {
EXPECT_NO_THROW(serializeMemc());
}

TEST_F(UT_UpdateSubsAuthData,deSerializeMemc_Func) {
EXPECT_TRUE(deSerializeMemc());
}

/*TEST(AucMemCachedQueries_cpp_IsSubscriberOtherImsi_Func,Return_True) {
//char pImsi[]="222540000003508";
char l_imsi[20];
memset(l_imsi,'\0',sizeof(l_imsi));
//snprintf(l_imsi,sizeof(l_imsi),"%s","222540000003508");
strncpy(l_imsi,"222540000003508",20);
EXPECT_TRUE(IsSubscriberOtherImsi(l_imsi));
//EXPECT_TRUE(IsSubscriberOtherImsi("222540000003508"));
}*/

/*TEST(AucMemCachedQueries_cpp_IsSubscriberOtherImsi_Func,Return_False) {
char pImsi[]="10000002  0    03754";
EXPECT_FALSE(IsSubscriberOtherImsi(pImsi));
}*/

/*
TEST_F(UT_RetrieveDirectMemcQuery,executeMemcQuery_Func) {
EXPECT_NO_THROW(executeMemcQuery());
}
*/

TEST_F(UT_RetrieveDirectMemcQuery,serializeMemc_Func) {
EXPECT_NO_THROW(serializeMemc());
}


TEST_F(UT_RetrieveDirectMemcQuery,deSerializeMemc_Func) {
EXPECT_FALSE(deSerializeMemc());
}































