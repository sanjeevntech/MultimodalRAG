#include"gtest.h"
#include<DigestMD5.h>
extern void CvtHex(IN HASH Bin,OUT HASHHEX Hex);
extern void DigestCalcHA1(IN char * pszAlg,IN char * pszUserName,IN char * pszRealm,IN char * pszPassword,IN char * pszNonce,IN char * pszCNonce,OUT HASHHEX SessionKey);
extern void DigestCalcResponse(IN HASHHEX HA1,IN char * pszNonce,IN char * pszNonceCount,IN char * pszCNonce,IN char * pszQop,IN char * pszMethod,IN char * pszDigestUri,IN HASHHEX HEntity,OUT HASHHEX Response );  

TEST(DigestMD5_cpp_CvtHex_Func, Return_void) {
unsigned char Bin[16]="0000000010011111";
unsigned char Hex[32+1];
EXPECT_NO_THROW(CvtHex(Bin,Hex));
}

TEST(DigestMD5_cpp_CvtHex_Func, Returnvoid) {
unsigned char Bin[16]="1111111111111111";
unsigned char Hex[32+1];
EXPECT_NO_THROW(CvtHex(Bin,Hex));
}

TEST(DigestMD5_cpp_DigestCalcHA1_Func, Returnvoid) {
char pszAlg[]="md5-sess";
char pszUserName[]="abcdef";
char pszRealm[]="ndhgd";
char pszPassword[]="1234";
char pszNonce[]="dfhj";
char pszCNonce[]="bchdl";
unsigned char SessionKey[32+1];
EXPECT_NO_THROW(DigestCalcHA1(pszAlg,pszUserName,pszRealm,pszPassword,pszNonce,pszCNonce,SessionKey));
}

TEST(DigestMD5_cpp_DigestCalcResponse_Func, Returnvoid) {
unsigned char HA1[32+1]="12345567";
char pszNonce[]="abgsfdrt";
char pszNonceCount[]="one";
char pszCNonce[]="bala";
char pszQop[]="auth-int";
char pszMethod[]="easy";
char pszDigestUri[]="https://www.google.com/search?q=strcasecmp+return";
unsigned char HEntity[32+1]="1234566";
unsigned char Response[32+1];
EXPECT_NO_THROW(DigestCalcResponse(HA1,pszNonce,pszNonceCount,pszCNonce,pszQop,pszMethod,pszDigestUri,HEntity,Response ));
}
