#include"gtest.h"
#include<Codec.h>

extern void Cipher(unsigned char* in, int len, unsigned char* outData, int encdec, unsigned char *key, unsigned char *ivchar);
extern void handleErrors();
extern int encrypt(unsigned char *plaintext, int plaintext_len, unsigned char *key, unsigned char *iv, unsigned char *ciphertext);
extern main();

TEST(Codec_cpp_CipherFunc,Return_Void)  {
unsigned char in[]={0x31,0x32,0x33,0x31,0x31,0x31,0x31,0x31,0x31,0x31,0x31,0x31,0x31,0x31,0x31,0x31};
int len=16;
unsigned char outData[20];
int encdec;
unsigned char key[]={0x31,0x35,0x31,0x31,0x31,0x31,0x31,0x31,0x32,0x32,0x32,0x32,0x32,0x32,0x32,0x32,0x31,0x31,0x31,0x31,0x31,0x31,0x31,0x31};
unsigned char ivchar[]={0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
EXPECT_NO_THROW(Cipher(in,len,outData,encdec,key,ivchar));
}

TEST(Codec_cpp_handleErrorsFunc, Return_void)  {
EXPECT_NO_THROW(handleErrors());
}

TEST(Codec_cpp_encryptFunc, Return_int) {
unsigned char key[] = "01234567890123456789012345678901";
unsigned char iv[] = "01234567890123456";
//unsigned char plaintext[] ="The quick brown fox jumps over the lazy dog";
unsigned char plaintext[] ="0123456789123456";
unsigned char ciphertext[128];
EXPECT_NE(encrypt(plaintext, strlen((char*)plaintext), key, iv,ciphertext),NULL);
}

/*TEST(Codec_cpp_intFunc, Return_int) {
unsigned char ivchar[] = {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
   unsigned char key1[] = {0x31,0x35,0x31,0x31,0x31,0x31,0x31,0x31,0x32,0x32,0x32,0x32,0x32,0x32,0x32,0x32,0x31,0x31,0x31,0x31,0x31,0x31,0x31,0x31};
   unsigned char in[] = {0x31,0x32,0x33,0x31,0x31,0x31,0x31,0x31,0x31,0x31,0x31,0x31,0x31,0x31,0x31,0x31};
   unsigned char dec[20]="";
   unsigned char dec1[20]="";

unsigned char key[] = "01234567890123456789012345678901";
unsigned char iv[] = "01234567890123456";
   //unsigned char plaintext[] ="The quick brown fox jumps over the lazy dog";
unsigned char plaintext[] ="0123456789123456";
unsigned char ciphertext[128];
int ciphertext_len;
    
EXPECT_NE(main(),NULL);
}
*/
