#define private public

#include"gtest.h"
#include<CtxtSendAuthenticationInfo.h>
#include<ByteMilenage.h>
#include <Msg.h>
#include <AucDbQueries.h>
#include<ContextBase.h>
#include<MapConstants.h>
#include<MapMessages.h>
#include<DiameterMessages.h>
#include<DiameterConstants.h>
#include<MemCachedQueryMsg.h>
#include<DbQueryMsg.h>
#include<UpdateInstanceStatus.h>
#include<ConfigReader.h>
#include<AucConfigReader.h>
#include<SubsProfileData.h>
#include <its++.h>
#include <its_timers.h>
#include <diameter/Command.h>
#include <diameter/base/BaseAVP.h>
#include <DiametriqInterface.h>
#include <ServiceCoordinator.h>
#include <ExtendedServiceCoordinator.h>
#include<IMAP3.h>
#include<IMAP2.h>
#include<IMAP1.h>
#include<HlrTdrFiller.h>
#include<TdrData.h>
//#include<OamDbQueries.h>
//#include<CtxtLteUpdateLocationRequest.h>
extern char *getAuthType(int p_type);
extern char *getEncAlgo(int p_enc_algo);
extern char *getEncMode(int p_enc_mode);
extern bool handleError(unsigned int aVendorId, unsigned int aErrCode, EErrorDiagnostic p_ed);
extern bool sendFurtherResponses();

class UT_Msg: public testing::Test , public Msg,public MapCommonMsg
{public:
UT_Msg()
{
}
~UT_Msg()
{
}
};


class UT_CtxtSendAuthenticationInfo: public testing::Test , public CtxtSendAuthenticationInfo, public Msg, public RetrieveSubsAuthData, public AucConfigReader//,public DiameterMsg//, public MapSpecificIndication//, public RetrieveDirectMemcQuery//, public RetrieveSendImsiData//, public MapSpecificIndication/*,public MapMsg,public MapCommonMsg,public ContextBase*/
{public:
UT_CtxtSendAuthenticationInfo()
{
}
~UT_CtxtSendAuthenticationInfo()
{
}
};


class UT_DiameterMsg: public testing::Test , public DiameterMsg
{public:
UT_DiameterMsg()
{
}
~UT_DiameterMsg()
{
}
};

class UT_RetrieveSubsAuthData: public testing::Test , public RetrieveSubsAuthData, public CtxtSendAuthenticationInfo
{public:
UT_RetrieveSubsAuthData()
{
}
~UT_RetrieveSubsAuthData()
{
}
};


class UT_MapMsg: public testing::Test , public MapMsg
{public:
UT_MapMsg()
{
}
~UT_MapMsg()
{
}
};

class UT_MapCommonMsg: public testing::Test , public MapCommonMsg
{public:
UT_MapCommonMsg()
{
}
~UT_MapCommonMsg()
{
}
};

class UT_MapSpecificMsg: public testing::Test , public MapSpecificMsg
{public:
UT_MapSpecificMsg()
{
}
~UT_MapSpecificMsg()
{
}
};


/*class UT_MapSpecificIndication: public testing::Test , public MapSpecificIndication
{public:
UT_MapSpecificIndication(EMapOpCode)
{
}
~UT_MapSpecificIndication()
{
}
};*/



class UT_ContextBase: public testing::Test , public ContextBase
{public:
UT_ContextBase()
{
}
~UT_ContextBase()
{
}
};


class UT_MemCachedQueryMsg: public testing::Test , public MemCachedQueryMsg
{public:
UT_MemCachedQueryMsg()
{
}
~UT_MemCachedQueryMsg()
{
}
};

class UT_RetrieveDirectMemcQuery: public testing::Test , public RetrieveDirectMemcQuery
{public:
UT_RetrieveDirectMemcQuery()
{
}
~UT_RetrieveDirectMemcQuery()
{
}
};


class UT_DbQueryMsg: public testing::Test , public DbQueryMsg
{public:
UT_DbQueryMsg()
{
}
~UT_DbQueryMsg()
{
}
};

class UT_UpdateInstanceStatus: public testing::Test , public UpdateInstanceStatus
{public:
UT_UpdateInstanceStatus()
{
}
~UT_UpdateInstanceStatus()
{
}
};

/*class UT_SubsProfileData: public testing::Test , public SubsProfileData
{public:
UT_SubsProfileData()
{
}
~UT_SubsProfileData()
{
}
};*/

/***********************************************************************/

/*TEST_F(UT_CtxtSendAuthenticationInfo,handleError_Func) {
//DiameterMsg p_msg("host26.realm26;1628358902;498433;1:2",DIAM_EVENT_ANSWER,318);
Msg *p_MsgPtr=new Msg;
p_MsgPtr->m_DlgId=1;
//p_MsgPtr.m_DlgId=1;
//DiameterMsg *l_dm = (DiameterMsg*)p_MsgPtr;
//l_dm->m_cmd=NULL;
//l_dm->m_det=p_DiamMsgType;
//l_dm->m_commandCode=p_commCode;
//l_dm->m_sessionIndex=-1;
//strcpy(l_dm->m_sessionId,"host26.realm26;1628358902;498433;1:2");
char p_sessionId[4096+1];
//char *s="host26.realm26;1628358902;498433;1:2";
//snprintf(P_sessionId,4097, "%s\n", s);
snprintf(p_sessionId, sizeof(p_sessionId), "%s", "host26.realm26;1628358902;498433;1:2");
LLOG(0,0,"### after snprintf ###");
DiameterMsg p_msg(p_sessionId,DIAM_EVENT_ANSWER,318);
 LLOG(0,0,"### after daimeter msg obj ###");
//EXPECT_TRUE(handleError(12,5012,-1));
m_msgPtr=p_MsgPtr;
EXPECT_TRUE( handleError(12,DIAM_RESULT_CODE_UNABLE_TO_COMPLY, ERROR_DIAGNOSTIC_NOT_REQUIRED));
delete p_MsgPtr;
}*/


/************************************************************************/
TEST_F(UT_CtxtSendAuthenticationInfo,processMessage_MSG_TYPE_MAP_Func) {
Msg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtSendAuthenticationInfo,processMessage_MSG_TYPE_DIAMETER_Func) {
Msg p_MsgPtr;
p_MsgPtr.m_MsgType=7;
bool p_DeleteFlag=true;
EXPECT_FALSE(processMessage(&p_MsgPtr,p_DeleteFlag));
}


TEST_F(UT_CtxtSendAuthenticationInfo,processMessage_MSG_TYPE_DB_Func) {
Msg p_MsgPtr;
p_MsgPtr.m_MsgType=2;
bool p_DeleteFlag=true;
EXPECT_FALSE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtSendAuthenticationInfo,processMessage_MSG_TYPE_TIMEOUT_Func) {
Msg p_MsgPtr;
p_MsgPtr.m_MsgType=4;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtSendAuthenticationInfo,processMessage_MSG_TYPE_MEMCACHED_Func) {
Msg p_MsgPtr;
p_MsgPtr.m_MsgType=8;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtSendAuthenticationInfo,processMessage_default_Func) {
Msg p_MsgPtr;
p_MsgPtr.m_MsgType=3;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}


TEST_F(UT_CtxtSendAuthenticationInfo,processMessage_MAP_CMN_OPEN_IND_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MapCommonMsgType=202;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MsgType=1;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtSendAuthenticationInfo,processMessage_MAP_CMN_DELIMITER_IND_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MapCommonMsgType=208;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MsgType=1;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtSendAuthenticationInfo,processMessage_MAP_CMN_CLOSE_IND_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MapCommonMsgType=206;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MsgType=1;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtSendAuthenticationInfo,processMessage_MAP_CMN_U_ABORT_IND_Func) {
MapCommonMsg p_MsgPtr;
m_timerId=1;
p_MsgPtr.m_MapCommonMsgType=210;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MsgType=1;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtSendAuthenticationInfo,processMessage_MAP_CMN_P_ABORT_IND_Func) {
MapCommonMsg p_MsgPtr;
m_timerId=1;
p_MsgPtr.m_MapCommonMsgType=212;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MsgType=1;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtSendAuthenticationInfo,processMessage_MAP_CMN_NOTICE_IND_Func) {
MapCommonMsg p_MsgPtr;
m_timerId=1;
p_MsgPtr.m_MapCommonMsgType=213;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MsgType=1;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtSendAuthenticationInfo,processMessage_Two_default_Func) {
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MapCommonMsgType=301;
p_MsgPtr.m_MapMsgType=1;
p_MsgPtr.m_MsgType=1;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtSendAuthenticationInfo,processMessage_MSG_TYPE_TIMEOUT_if_Func) {
m_dlgStatusFlag=true;
Msg p_MsgPtr;
p_MsgPtr.m_MsgType=4;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtSendAuthenticationInfo,processMessage_False_MAP_SPEC_EVENT_INDICATION_Func) {
MapSpecificMsg obj1;
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MapCommonMsgType=2;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MsgType=1;
bool p_DeleteFlag=true;
m_firstSaiFlag=1;
obj1.m_allocatedFlag=false;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtSendAuthenticationInfo,processMessage_True_MAP_SPEC_EVENT_INDICATION_Func) {
MapSpecificMsg obj1;
MapCommonMsg p_MsgPtr;
p_MsgPtr.m_MapCommonMsgType=2;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MsgType=1;
bool p_DeleteFlag=true;
m_firstSaiFlag=1;
obj1.m_allocatedFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}
extern CtxtSendAuthenticationInfo;
TEST_F(UT_CtxtSendAuthenticationInfo,processMessage_Two_MAP_SPEC_EVENT_INDICATION_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapSpecificEventType=2;
p_MsgPtr.m_OpCode=9;
m_firstSaiFlag=true;
p_MsgPtr.m_allocatedFlag=false;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtSendAuthenticationInfo,processMessage_Three_MAP_SPEC_EVENT_INDICATION_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapSpecificEventType=2;
p_MsgPtr.m_OpCode=9;
m_firstSaiFlag=true;
p_MsgPtr.m_allocatedFlag=true;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtSendAuthenticationInfo,processMessage_MEMC_QUERY_TYPE_UPDATE_Func) {
UpdateInstanceStatus p_MsgPtr;
p_MsgPtr.m_MsgType=8;
p_MsgPtr.m_MemcQueryType=1;
p_MsgPtr.m_MemcQueryRes=1;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtSendAuthenticationInfo,processMessage_two_MEMC_QUERY_TYPE_UPDATE_Func) {
UpdateInstanceStatus p_MsgPtr;
p_MsgPtr.m_MsgType=8;
p_MsgPtr.m_MemcQueryType=1;
p_MsgPtr.m_MemcQueryRes=2;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtSendAuthenticationInfo,processMessage_MSG_TYPE_DB_case_two_Func){
UpdateInstanceStatus p_MsgPtr;
p_MsgPtr.m_DbQueryType=2;
p_MsgPtr.m_MsgType=2;
p_MsgPtr.m_DbQueryCachedType=1;
p_MsgPtr.m_MemcQueryRes=1;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtSendAuthenticationInfo,processMessage_MSG_TYPE_DB_case_two_else_Func){
UpdateInstanceStatus p_MsgPtr;
p_MsgPtr.m_DbQueryType=2;
p_MsgPtr.m_MsgType=2;
p_MsgPtr.m_DbQueryCachedType=1;
p_MsgPtr.m_MemcQueryRes=2;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtSendAuthenticationInfo,processMessage_DIAM_EVENT_ANSWER_Func){
DiameterMsg p_MsgPtr("host26.realm26;1628358902;498433;1:2",DIAM_EVENT_REQUEST,303);
p_MsgPtr.m_MsgType=7;
p_MsgPtr.m_det=2;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtSendAuthenticationInfo,processMessage_DIAM_EVENT_TIME_OUT_Func){
DiameterMsg p_MsgPtr("host26.realm26;1628358902;498433;1:2",DIAM_EVENT_REQUEST,303);
p_MsgPtr.m_MsgType=7;
p_MsgPtr.m_det=5;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtSendAuthenticationInfo,processMessage_DIAM_EVENT_ERROR_Func){
DiameterMsg p_MsgPtr("host26.realm26;1628358902;498433;1:2",DIAM_EVENT_REQUEST,303);
p_MsgPtr.m_MsgType=7;
p_MsgPtr.m_det=3;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtSendAuthenticationInfo,processMessage_DIAM_EVENT_AUTH_LIFE_TIME_OUT_Func){
DiameterMsg p_MsgPtr("host26.realm26;1628358902;498433;1:2",DIAM_EVENT_REQUEST,303);
p_MsgPtr.m_MsgType=7;
p_MsgPtr.m_det=6;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtSendAuthenticationInfo,processMessage_DIAM_EVENT_AUTH_GRACE_TIME_OUT_Func){
DiameterMsg p_MsgPtr("host26.realm26;1628358902;498433;1:2",DIAM_EVENT_REQUEST,303);
p_MsgPtr.m_MsgType=7;
p_MsgPtr.m_det=7;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtSendAuthenticationInfo,processMessage_DIAM_EVENT_CORRUPTED_MSG_Func){
DiameterMsg p_MsgPtr("host26.realm26;1628358902;498433;1:2",DIAM_EVENT_REQUEST,303);
p_MsgPtr.m_MsgType=7;
p_MsgPtr.m_det=8;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtSendAuthenticationInfo,processMessage_DIAM_EVENT_ACCT_INTERIM_TIME_OUT_Func){
DiameterMsg p_MsgPtr("host26.realm26;1628358902;498433;1:2",DIAM_EVENT_REQUEST,303);
p_MsgPtr.m_MsgType=7;
p_MsgPtr.m_det=9;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}


/*TEST_F(UT_CtxtSendAuthenticationInfo,processMessage_MSG_TYPE_DB_case_one_Func){
RetrieveSubsAuthData p_MsgPtr;
p_MsgPtr.m_MsgType=2;
p_MsgPtr.m_DbQueryType=1;
p_MsgPtr.m_DbQueryCachedType=1;
p_MsgPtr.m_MemcQueryRes=1;
p_MsgPtr.m_DbQueryRes=4;
p_MsgPtr.m_nam=3;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}*/





/*TEST_F(UT_CtxtSendAuthenticationInfo,processMessage_four_MAP_SPEC_EVENT_INDICATION_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapSpecificEventType=2;
p_MsgPtr.m_OpCode=9;
m_firstSaiFlag=false;
p_MsgPtr.m_allocatedFlag=true;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}*/

TEST_F(UT_CtxtSendAuthenticationInfo,processMessage_five_MAP_SPEC_EVENT_INDICATION_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapSpecificEventType=2;
p_MsgPtr.m_OpCode=0;
m_firstSaiFlag=false;
p_MsgPtr.m_allocatedFlag=true;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtSendAuthenticationInfo,processMessage_MAP_SPEC_EVENT_RESULT_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapSpecificEventType=3;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}


TEST_F(UT_CtxtSendAuthenticationInfo,processMessage_MAP_SPEC_EVENT_CONFIRMATION_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapSpecificEventType=4;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}


TEST_F(UT_CtxtSendAuthenticationInfo,processMessage_MAP_SPEC_EVENT_USER_ERROR_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapSpecificEventType=5;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}


TEST_F(UT_CtxtSendAuthenticationInfo,processMessage_MAP_SPEC_EVENT_PROV_ERROR_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapSpecificEventType=6;
bool p_DeleteFlag=true;
m_timerId=1;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtSendAuthenticationInfo,processMessage_default_m_MapSpecificEventType_Func) {
MapSpecificMsg p_MsgPtr;
p_MsgPtr.m_MapMsgType=2;
p_MsgPtr.m_MsgType=1;
p_MsgPtr.m_MapSpecificEventType=0;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

/*TEST_F(UT_CtxtSendAuthenticationInfo,processMessage_MSG_TYPE_DB_case_one_func) {
RetrieveSubsAuthData p_MsgPtr;
p_MsgPtr.m_MsgType=2;
p_MsgPtr.m_DbQueryType=1;
p_MsgPtr.m_DbQueryCachedType=1;
p_MsgPtr.m_MemcQueryRes=1;
p_MsgPtr.m_DbQueryRes=1;
//CtxtSendAuthenticationInfo::m_OtherImsiSubscriberFlag=true;
m_OtherImsiSubscriberFlag=false;
m_ro=1;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}*/

/*
//Congestion release comment
TEST_F(UT_CtxtSendAuthenticationInfo,processMessage_MSG_TYPE_DB_case_one_elseif_func) {
RetrieveSubsAuthData p_MsgPtr;
p_MsgPtr.m_MsgType=2;
p_MsgPtr.m_DbQueryType=1;
p_MsgPtr.m_DbQueryCachedType=1;
p_MsgPtr.m_MemcQueryRes=2;
p_MsgPtr.m_MemcErrorCode=1;
p_MsgPtr.m_DbQueryRes=2;
m_ro=1;
strcpy(p_MsgPtr.m_hlrAddress,"abcdfghjkliuytrtyjk");
p_MsgPtr.m_errCode=4;
p_MsgPtr.m_requestNode=2;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtSendAuthenticationInfo,processMessage_MSG_TYPE_DB_case_one_innerelse_func) {
RetrieveSubsAuthData p_MsgPtr;
p_MsgPtr.m_MsgType=2;
p_MsgPtr.m_DbQueryType=1;
p_MsgPtr.m_DbQueryCachedType=1;
p_MsgPtr.m_MemcQueryRes=2;
p_MsgPtr.m_MemcErrorCode=1;
p_MsgPtr.m_DbQueryRes=2;
m_ro=1;
strcpy(p_MsgPtr.m_hlrAddress,"abcdfghjkliuytrtyjk");
p_MsgPtr.m_errCode=5;
p_MsgPtr.m_requestNode=3;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtSendAuthenticationInfo,processMessage_MSG_TYPE_DB_case_one_outerelse_func) {
RetrieveSubsAuthData p_MsgPtr;
p_MsgPtr.m_MsgType=2;
p_MsgPtr.m_DbQueryType=1;
p_MsgPtr.m_DbQueryCachedType=1;
p_MsgPtr.m_MemcQueryRes=2;
p_MsgPtr.m_MemcErrorCode=1;
p_MsgPtr.m_DbQueryRes=0;
m_ro=1;
strcpy(p_MsgPtr.m_hlrAddress,"abcdfghjkliuytrtyjk");
p_MsgPtr.m_errCode=5;
p_MsgPtr.m_requestNode=3;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}
*/




/*TEST_F(UT_CtxtSendAuthenticationInfo,processMessage_MSG_TYPE_MEMCACHED_MEMC_QUERY_TYPE_GET_func)
{
RetrieveDirectMemcQuery p_MsgPtr;
p_MsgPtr.m_MsgType=8;
p_MsgPtr.m_MemcQueryType=0;
p_MsgPtr.m_MemcQueryRes=1;
m_OtherImsiSubscriberFlag=false;
m_ro=1;
//p_MsgPtr.m_sqn[6]={0x34,0x45,0x56,0x67,0x78,0x12};
//p_MsgPtr.m_sqn[]="abcdef";
strcpy(p_MsgPtr.m_sqn,"abcdef");
//RetrieveSubsAuthData::m_sqn[6]="abcdef";
//RetrieveSubsAuthData *m_rsad;
m_rsad=new RetrieveSubsAuthData;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
//delete m_rsad;
}
*/
/*
TEST_F(UT_CtxtSendAuthenticationInfo,processMessage_MSG_TYPE_MEMCACHED_MEMC_QUERY_TYPE_GET_else_func)
{
RetrieveDirectMemcQuery p_MsgPtr;
p_MsgPtr.m_MsgType=8;
p_MsgPtr.m_MemcQueryType=0;
p_MsgPtr.m_MemcQueryRes=2;
m_OtherImsiSubscriberFlag=false;
m_ro=1;
strcpy(p_MsgPtr.m_sqn,"abcdef");
m_rsad=new RetrieveSubsAuthData;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
//delete m_rsad;
}
*/
/*TEST_F(UT_CtxtSendAuthenticationInfo,processMessage_Two_MSG_TYPE_DIAMETER_Func) {
DiameterMsg p_MsgPtr;
p_MsgPtr.m_MsgType=7;
p_MsgPtr.m_det=1;
p_MsgPtr.m_commandCode=318;
p_MsgPtr.m_cmd=NULL;
bool p_DeleteFlag=true;
EXPECT_TRUE(processMessage(&p_MsgPtr,p_DeleteFlag));
}*/


/*TEST_F(UT_CtxtSendAuthenticationInfo,processMessage_Two_MSG_TYPE_DIAMETER_Func) {
UT_DiameterMsg p_MsgPtr;
p_MsgPtr.m_det=1;
p_MsgPtr.m_commandCode=318;
p_MsgPtr.m_cmd="abdcf";
p_MsgPtr.m_allocatedFlag=false;
bool p_DeleteFlag=true;
p_MsgPtr.m_MsgType=7;
EXPECT_FALSE(processMessage(&p_MsgPtr,p_DeleteFlag));
}*/


/*TEST_F(UT_CtxtSendAuthenticationInfo,processMessage_DIAM_COMM_CODE_S6A_S6D_AIR_AIA_Func) {
DiameterMsg p_MsgPtr;
p_MsgPtr.m_det=1;
p_MsgPtr.m_commandCode=318;
p_MsgPtr.m_cmd=1;
p_MsgPtr.m_allocatedFlag=true;
bool p_DeleteFlag=true;
p_MsgPtr.m_MsgType=7;
EXPECT_FALSE(processMessage(&p_MsgPtr,p_DeleteFlag));
}*/

/*TEST_F(UT_CtxtSendAuthenticationInfo,processMessage_NULL_DIAM_COMM_CODE_S6A_S6D_AIR_AIA_Func) {
DiameterMsg p_MsgPtr;
p_MsgPtr.m_det=1;
p_MsgPtr.m_commandCode=318;
p_MsgPtr.m_cmd=NULL;
p_MsgPtr.m_allocatedFlag=true;
bool p_DeleteFlag=true;
p_MsgPtr.m_MsgType=7;
EXPECT_FALSE(processMessage(&p_MsgPtr,p_DeleteFlag));
}*/

/*TEST_F(UT_CtxtSendAuthenticationInfo,processMessage_Two_MSG_TYPE_DB_Func) {
UpdateInstanceStatus p_MsgPtr;
p_MsgPtr.m_DbQueryType=1;
p_MsgPtr.m_MsgType=2;
p_MsgPtr.m_DbQueryCachedType=1;
p_MsgPtr.m_MemcQueryRes=1;
p_MsgPtr.m_DbQueryRes=1;
RetrieveDirectMemcQuery obj2;
obj2.m_OtherImsiSubscriberFlag=true;
bool p_DeleteFlag=true;
EXPECT_FALSE(processMessage(&p_MsgPtr,p_DeleteFlag));
}

TEST_F(UT_CtxtSendAuthenticationInfo,processMessage_Three_MSG_TYPE_DB_Func) {
UpdateInstanceStatus p_MsgPtr;
p_MsgPtr.m_DbQueryType=1;
p_MsgPtr.m_MsgType=2;
p_MsgPtr.m_DbQueryCachedType=1;
p_MsgPtr.m_MemcQueryRes=2;
RetrieveDirectMemcQuery obj2;
obj2.m_OtherImsiSubscriberFlag=false;
bool p_DeleteFlag=true;
EXPECT_FALSE(processMessage(&p_MsgPtr,p_DeleteFlag));
}*/
/*********************************************************************/
TEST_F(UT_CtxtSendAuthenticationInfo,initiateDbRequest_Func) {
Msg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
EXPECT_FALSE(initiateDbRequest(&p_MsgPtr));
}

TEST_F(UT_CtxtSendAuthenticationInfo,initiateDbRequest_Two_Func) {
Msg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
EXPECT_FALSE(initiateDbRequest(&p_MsgPtr));
p_MsgPtr.m_MsgType=3;
getInitialRespondingVersion();
EXPECT_FALSE(initiateDbRequest(&p_MsgPtr));
}

TEST_F(UT_CtxtSendAuthenticationInfo,initiateDbRequest_Three_Func) {
Msg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
EXPECT_FALSE(initiateDbRequest(&p_MsgPtr));
p_MsgPtr.m_MsgType=2;
getInitialRespondingVersion();
EXPECT_FALSE(initiateDbRequest(&p_MsgPtr));
}

TEST_F(UT_CtxtSendAuthenticationInfo,initiateDbRequest_Four_Func) {
Msg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
EXPECT_FALSE(initiateDbRequest(&p_MsgPtr));
p_MsgPtr.m_MsgType=1;
//ContextBase obj;
m_InitialRespondingVersion=1;
getInitialRespondingVersion();
EXPECT_FALSE(initiateDbRequest(&p_MsgPtr));
}

TEST_F(UT_CtxtSendAuthenticationInfo,initiateDbRequest_FIVE_Func) {
Msg p_MsgPtr;
p_MsgPtr.m_MsgType=7;
CtxtSendAuthenticationInfo obj;
obj.m_ro=2;
EXPECT_FALSE(initiateDbRequest(&p_MsgPtr));
}

/*TEST_F(UT_CtxtSendAuthenticationInfo,initiateDbRequest_MAP_V2_Func)  {
//MapSpecificIndication p_MsgPtr(0);
//MapSpecificIndication p_MsgPtr(MAP_OP_CODE_UNKNOWN);
MapSpecificIndication *p_MsgPtr= new MapSpecificIndication(56);
p_MsgPtr->m_MsgType=1;
CtxtSendAuthenticationInfo::m_InitialRespondingVersion=2;
IMAP2_IMSI ab;
p_MsgPtr->m_structBuffer=&ab;
ab.value[8]="abfdghyu";
ab.length=4;
EXPECT_FALSE(initiateDbRequest(p_MsgPtr));
delete p_MsgPtr;
}
*/
/*TEST_F(UT_CtxtSendAuthenticationInfo,initiateDbRequest_MAP_V3_Func)  {
MapSpecificIndication *p_MsgPtr= new MapSpecificIndication(56);
p_MsgPtr->m_MsgType=1;
CtxtSendAuthenticationInfo::m_InitialRespondingVersion=3;
IMAP3_SendAuthenticationInfoArg ab;
//strcpy(ab.imsi.value,"11110000");
ab.imsi.value[8]="abcdefgh";
ab.imsi.length=strlen(ab.imsi.value);
ab.numberOfRequestedVectors=7;
EXPECT_FALSE(initiateDbRequest(p_MsgPtr));
delete p_MsgPtr;
}*/



/*TEST_F(UT_CtxtSendAuthenticationInfo,initiateDbRequest_MAP_V1_Func)  {
MapSpecificIndication *p_MsgPtr= new MapSpecificIndication(56);
p_MsgPtr->m_MsgType=1;
CtxtSendAuthenticationInfo::m_InitialRespondingVersion=2;
IMAP1_SendParametersArg ab;
IMAP1_SubscriberId a;
a.choice=1;
a.u.imsi.length=-1;
strcpy(a.u.imsi.value,"abcdefgh");
char l_imsi[20];
memset(l_imsi, '\0', 20);
//a.u.imsi.value[8]="abfdghyu";
IMAP1_RequestParameters_ b;
b.value=strlen(a.u.imsi.value);
p_MsgPtr->m_structBuffer=&ab;
EXPECT_TRUE(initiateDbRequest(p_MsgPtr));
delete p_MsgPtr;
}*/




/*TEST_F(UT_CtxtSendAuthenticationInfo,initiateDbRequest_REQUEST_ORIGIN_DIAMETER_S6A_Func) {
DiameterMsg p_MsgPtr("host26.realm26;1628358902;498433;1:2",DIAM_EVENT_REQUEST,303);
p_MsgPtr.m_MsgType=7;
m_ro=2;
p_MsgPtr.m_cmd="adsfghjkdluegd";
EXPECT_FALSE(initiateDbRequest(&p_MsgPtr));
}*/



/*TEST_F(UT_CtxtSendAuthenticationInfo,initiateDbRequest_MAP_V2_Func) {
Msg p_MsgPtr;
CtxtSendAuthenticationInfo::m_InitialRespondingVersion=2;
//EMapOpCode e;
MapSpecificIndication m;
//p_MsgPtr=new MapSpecificIndication(e);
p_MsgPtr.m_MsgType=1;
IMAP2_IMSI ab;
m.m_structBuffer=&ab;
//p_MsgPtr->m_structBuffer=&ab;
ab.value[8]="abfdghyu";
ab.length=4;
EXPECT_TRUE(initiateDbRequest(p_MsgPtr));
}*/


/*TEST_F(UT_CtxtSendAuthenticationInfo,initiateDbRequest_MAP_V2_Func) {
Msg p_MsgPtr;
p_MsgPtr.m_MsgType=1;
ContextBase::m_InitialRespondingVersion=2;
EXPECT_TRUE(initiateDbRequest(&p_MsgPtr));
}*/





/***************************************************************************/
/*TEST_F(UT_CtxtSendAuthenticationInfo,handleErrorFunc) {
enum EErrorDiagnostic
{
   ERROR_DIAGNOSTIC_NOT_REQUIRED=-1,
   ERROR_DIAGNOSTIC_GPRS_DATA_SUBSCRIBED=0,
   ERROR_DIAGNOSTIC_NO_GPRS_DATA_SUBSCRIBED,
   ERROR_DIAGNOSTIC_ODB_ALL_APN,
   ERROR_DIAGNOSTIC_ODB_HPLMN_APN,
   ERROR_DIAGNOSTIC_ODB_VPLMN_APN
};

//unsigned int aVendorId=12,
//unsigned int aErrCode=0;
DiameterMsg ptr;
ptr.m_sessionId[4096+1]="abdgdterdjd";
EXPECT_TRUE(handleError(12,5001,-1));
//EXPECT_TRUE(handleError(aVendorId,DIAM_RESULT_CODE,ERROR_DIAGNOSTIC_NOT_REQUIRED));

}*/

/*TEST_F(UT_CtxtSendAuthenticationInfo,sendFurtherResponsesFunc) {
EXPECT_TRUE(sendFurtherResponses());
}

TEST_F(UT_CtxtSendAuthenticationInfo,sendFurtherResponses_Func) {
EXPECT_FALSE(sendFurtherResponses());
}*/
/*
TEST_F(UT_CtxtSendAuthenticationInfo,sendFurtherResponses_Func) {
CtxtSendAuthenticationInfo::m_ro=1;
ContextBase::m_InitialRespondingVersion=3;
CtxtSendAuthenticationInfo::m_subsType=3;
g_AucConfigReaderObj->m_MAP3_QUIN_OR_TRIPLETS='Q';
CtxtSendAuthenticationInfo::m_totalSentCount=1;
CtxtSendAuthenticationInfo::m_maxVectors=8;
CtxtSendAuthenticationInfo::m_timerId=1;
EXPECT_TRUE(sendFurtherResponses());
}
*/

/*
TEST_F(UT_CtxtSendAuthenticationInfo,sendFurtherResponses_MAP_V2_Func) {
CtxtSendAuthenticationInfo::m_ro=1;
ContextBase::m_InitialRespondingVersion=2;
m_totalSentCount =0;
CtxtSendAuthenticationInfo::m_maxVectors=8;
RetrieveSubsAuthData::m_maxVectors=8;
g_AucConfigReaderObj->m_MAX_NUM_OF_VECTORS_IN_A_CHUNK=10;
g_AucConfigReaderObj->m_TestFlag=1;
CtxtSendAuthenticationInfo::m_timerId=1;
EXPECT_TRUE(sendFurtherResponses());
}
*/
/*
TEST_F(UT_CtxtSendAuthenticationInfo,sendFurtherResponses_MAP_V3_Func) {
CtxtSendAuthenticationInfo::m_ro=1;
ContextBase::m_InitialRespondingVersion=3;
CtxtSendAuthenticationInfo::m_subsType=2;
g_AucConfigReaderObj->m_MAP3_QUIN_OR_TRIPLETS='T';
CtxtSendAuthenticationInfo::m_totalSentCount=1;
CtxtSendAuthenticationInfo::m_maxVectors=8;
g_AucConfigReaderObj->m_MAX_NUM_OF_VECTORS_IN_A_CHUNK=10;
g_AucConfigReaderObj->m_TestFlag=1;
CtxtSendAuthenticationInfo::m_timerId=1;
EXPECT_TRUE(sendFurtherResponses());
}

TEST_F(UT_CtxtSendAuthenticationInfo,sendFurtherResponses_MAP_V3_elseif_Func) {
CtxtSendAuthenticationInfo::m_ro=1;
ContextBase::m_InitialRespondingVersion=3;
CtxtSendAuthenticationInfo::m_subsType=2;
g_AucConfigReaderObj->m_MAP3_QUIN_OR_TRIPLETS='T';
CtxtSendAuthenticationInfo::m_totalSentCount=1;
CtxtSendAuthenticationInfo::m_maxVectors=8;
g_AucConfigReaderObj->m_MAX_NUM_OF_VECTORS_IN_A_CHUNK=10;
g_AucConfigReaderObj->m_TestFlag=0;
CtxtSendAuthenticationInfo::m_timerId=1;
EXPECT_TRUE(sendFurtherResponses());
}

TEST_F(UT_CtxtSendAuthenticationInfo,sendFurtherResponses_MAP_V3_m_timerId_Func) {
CtxtSendAuthenticationInfo::m_ro=1;
ContextBase::m_InitialRespondingVersion=3;
CtxtSendAuthenticationInfo::m_subsType=2;
g_AucConfigReaderObj->m_MAP3_QUIN_OR_TRIPLETS='T';
CtxtSendAuthenticationInfo::m_totalSentCount=1;
CtxtSendAuthenticationInfo::m_maxVectors=8;
g_AucConfigReaderObj->m_MAX_NUM_OF_VECTORS_IN_A_CHUNK=10;
g_AucConfigReaderObj->m_TestFlag=0;
CtxtSendAuthenticationInfo::m_timerId=0;
EXPECT_TRUE(sendFurtherResponses());
}


TEST_F(UT_CtxtSendAuthenticationInfo,sendFurtherResponses_MAP_V3_else_Func) {
CtxtSendAuthenticationInfo::m_ro=1;
ContextBase::m_InitialRespondingVersion=3;
CtxtSendAuthenticationInfo::m_totalSentCount=1;
g_AucConfigReaderObj->m_MAP3_QUIN_OR_TRIPLETS='F';
CtxtSendAuthenticationInfo::m_subsType=7;
CtxtSendAuthenticationInfo::m_maxVectors=8;
g_AucConfigReaderObj->m_MAX_NUM_OF_VECTORS_IN_A_CHUNK=10;
g_AucConfigReaderObj->m_TestFlag=0;
CtxtSendAuthenticationInfo::m_timerId=1;
EXPECT_FALSE(sendFurtherResponses());
}

TEST_F(UT_CtxtSendAuthenticationInfo,sendFurtherResponses_MAP_V2_else_Func) {
CtxtSendAuthenticationInfo::m_ro=1;
ContextBase::m_InitialRespondingVersion=2;
CtxtSendAuthenticationInfo::m_totalSentCount=1;
CtxtSendAuthenticationInfo::m_maxVectors=8;
g_AucConfigReaderObj->m_TestFlag=0;
CtxtSendAuthenticationInfo::m_timerId=0;
EXPECT_TRUE(sendFurtherResponses());
}
*/
/*
TEST_F(UT_CtxtSendAuthenticationInfo,sendFurtherResponses_MAP_V1_Func) {
CtxtSendAuthenticationInfo::m_ro=1;
ContextBase::m_InitialRespondingVersion=1;
CtxtSendAuthenticationInfo::m_v1AuthIndex=0;
CtxtSendAuthenticationInfo::m_maxVectors=8;
CtxtSendAuthenticationInfo::m_totalSentCount=1;
g_AucConfigReaderObj->m_MAX_NUM_OF_VECTORS_IN_A_CHUNK=10;
g_AucConfigReaderObj->m_TestFlag=1;
CtxtSendAuthenticationInfo::m_timerId=0;
EXPECT_TRUE(sendFurtherResponses());
}

TEST_F(UT_CtxtSendAuthenticationInfo,sendFurtherResponses_MAP_V1_innerelse_Func) {
CtxtSendAuthenticationInfo::m_ro=1;
ContextBase::m_InitialRespondingVersion=1;
CtxtSendAuthenticationInfo::m_v1AuthIndex=0;
CtxtSendAuthenticationInfo::m_maxVectors=8;
CtxtSendAuthenticationInfo::m_totalSentCount=1;
g_AucConfigReaderObj->m_MAX_NUM_OF_VECTORS_IN_A_CHUNK=10;
g_AucConfigReaderObj->m_TestFlag=0;
CtxtSendAuthenticationInfo::m_timerId=0;
EXPECT_TRUE(sendFurtherResponses());
}

TEST_F(UT_CtxtSendAuthenticationInfo,sendFurtherResponses_MAP_V1_innerelseif_Func) {
CtxtSendAuthenticationInfo::m_ro=1;
ContextBase::m_InitialRespondingVersion=1;
CtxtSendAuthenticationInfo::m_v1AuthIndex=0;
CtxtSendAuthenticationInfo::m_maxVectors=8;
CtxtSendAuthenticationInfo::m_totalSentCount=1;
g_AucConfigReaderObj->m_MAX_NUM_OF_VECTORS_IN_A_CHUNK=10;
g_AucConfigReaderObj->m_TestFlag=0;
CtxtSendAuthenticationInfo::m_timerId=0;
CtxtSendAuthenticationInfo::m_subsType=3;
EXPECT_TRUE(sendFurtherResponses());
}

TEST_F(UT_CtxtSendAuthenticationInfo,sendFurtherResponses_MAP_V1_outerelse_Func) {
CtxtSendAuthenticationInfo::m_ro=1;
ContextBase::m_InitialRespondingVersion=1;
CtxtSendAuthenticationInfo::m_v1AuthIndex=5;
CtxtSendAuthenticationInfo::m_maxVectors=8;
CtxtSendAuthenticationInfo::m_totalSentCount=1;
g_AucConfigReaderObj->m_MAX_NUM_OF_VECTORS_IN_A_CHUNK=10;
g_AucConfigReaderObj->m_TestFlag=0;
CtxtSendAuthenticationInfo::m_timerId=0;
CtxtSendAuthenticationInfo::m_subsType=3;
//RetrieveSubsAuthData::m_subsType=3;
EXPECT_TRUE(sendFurtherResponses());
}

*/


/*TEST_F(UT_CtxtSendAuthenticationInfo,sendFurtherResponses_TWO_Func) {
CtxtSendAuthenticationInfo::m_ro=1;
CtxtSendAuthenticationInfo::m_subsType=2;
//AucConfigReader::m_MAX_NUM_OF_VECTORS_IN_A_CHUNK=2;
m_MAX_NUM_OF_VECTORS_IN_A_CHUNK=2;
AucConfigReader::m_TestFlag=1;
ContextBase::m_InitialRespondingVersion=3;
CtxtSendAuthenticationInfo::m_subsType=3;
AucConfigReader::m_MAP3_QUIN_OR_TRIPLETS='Q';
//CtxtSendAuthenticationInfo::m_totalSentCount=1;
CtxtSendAuthenticationInfo::m_maxVectors=8;
m_totalSentCount=1;
//m_maxVectors=8;

CtxtSendAuthenticationInfo::m_timerId=1;
EXPECT_FALSE(sendFurtherResponses());
}*/






TEST(CtxtSendAuthenticationInfo_cpp_getAuthTypeFunc, Return_case1) {
int p_type=1;
EXPECT_NE(getAuthType(p_type),NULL);
}

TEST(CtxtSendAuthenticationInfo_cpp_getAuthTypeFunc, Return_case2) {
int p_type=2;
EXPECT_NE(getAuthType(p_type),NULL);
}

TEST(CtxtSendAuthenticationInfo_cpp_getAuthTypeFunc, Return_case3) {
int p_type=3;
EXPECT_NE(getAuthType(p_type),NULL);
}

TEST(CtxtSendAuthenticationInfo_cpp_getAuthTypeFunc, Return_case4) {
int p_type=4;
EXPECT_NE(getAuthType(p_type),NULL);
}

TEST(CtxtSendAuthenticationInfo_cpp_getAuthTypeFunc, Return_case5) {
int p_type=5;
EXPECT_NE(getAuthType(p_type),NULL);
}

TEST(CtxtSendAuthenticationInfo_cpp_getAuthTypeFunc, Return_case6) {
int p_type=6;
EXPECT_NE(getAuthType(p_type),NULL);
}

TEST(CtxtSendAuthenticationInfo_cpp_getAuthTypeFunc, Return_case7) {
int p_type=7;
EXPECT_NE(getAuthType(p_type),NULL);
}

TEST(CtxtSendAuthenticationInfo_cpp_getAuthTypeFunc, Return_case8) {
int p_type=8;
EXPECT_NE(getAuthType(p_type),NULL);
}

TEST(CtxtSendAuthenticationInfo_cpp_getAuthTypeFunc, Return_casedefault) {
int p_type=0;
EXPECT_NE(getAuthType(p_type),NULL);
}
/****************************************************************************/
TEST(CtxtSendAuthenticationInfo_cpp_getEncAlgoFunc, Return_case1) {
int p_enc_algo=0;
EXPECT_NE(getEncAlgo(p_enc_algo),NULL);
}

TEST(CtxtSendAuthenticationInfo_cpp_getEncAlgoFunc, Return_case2) {
int p_enc_algo=1;
EXPECT_NE(getEncAlgo(p_enc_algo),NULL);
}

TEST(CtxtSendAuthenticationInfo_cpp_getEncAlgoFunc, Return_case3) {
int p_enc_algo=2;
EXPECT_NE(getEncAlgo(p_enc_algo),NULL);
}

TEST(CtxtSendAuthenticationInfo_cpp_getEncAlgoFunc, Return_case4) {
int p_enc_algo=3;
EXPECT_NE(getEncAlgo(p_enc_algo),NULL);
}

TEST(CtxtSendAuthenticationInfo_cpp_getEncAlgoFunc, Return_casedefault) {
int p_enc_algo=8;
EXPECT_NE(getEncAlgo(p_enc_algo),NULL);
}
/**************************************************************************/

TEST(CtxtSendAuthenticationInfo_cpp_getEncModeFunc, Return_case1) {
int p_enc_mode=0;
EXPECT_NE(getEncMode(p_enc_mode),NULL);
}

TEST(CtxtSendAuthenticationInfo_cpp_getEncModeFunc, Return_case2) {
int p_enc_mode=1;
EXPECT_NE(getEncMode(p_enc_mode),NULL);
}

TEST(CtxtSendAuthenticationInfo_cpp_getEncModeFunc, Return_case3) {
int p_enc_mode=2;
EXPECT_NE(getEncMode(p_enc_mode),NULL);
}

TEST(CtxtSendAuthenticationInfo_cpp_getEncModeFunc, Return_case4) {
int p_enc_mode=3;
EXPECT_NE(getEncMode(p_enc_mode),NULL);
}

TEST(CtxtSendAuthenticationInfo_cpp_getEncModeFunc, Return_casedefault) {
int p_enc_mode=8;
EXPECT_NE(getEncMode(p_enc_mode),NULL);
}

TEST(CtxtSendAuthenticationInfo_cpp_getEncModeFunc, Return_case5) {
int p_enc_mode=3;
EXPECT_NE(getEncMode(p_enc_mode),NULL);
}

TEST(CtxtSendAuthenticationInfo_cpp_getEncModeFunc, Return_case6) {
int p_enc_mode=3;
EXPECT_NE(getEncMode(p_enc_mode),NULL);
}

/**************************************************************************/
/*TEST_F(UT_CtxtSendAuthenticationInfo,handleDbResponse_Func) {
Msg p_MsgPtr;
p_MsgPtr.m_DlgId=1;
p_MsgPtr.m_UserDlgId=1;
p_MsgPtr.m_MsgType=0;
m_OtherImsiSubscriberFlag=true;
EXPECT_TRUE(handleDbResponse(&p_MsgPtr));
}*/
/*
TEST_F(UT_CtxtSendAuthenticationInfo,handleDbResponse_Two_Func) {
Msg p_MsgPtr;
m_OtherImsiSubscriberFlag=false;
EXPECT_FALSE(handleDbResponse(&p_MsgPtr));
}

TEST_F(UT_CtxtSendAuthenticationInfo,handleDbResponse_True_Func) {
CtxtSendAuthenticationInfo p_MsgPtr;
p_MsgPtr.m_OtherImsiSubscriberFlag=true;
p_MsgPtr.m_ro=2;
p_MsgPtr.m_MsgType=2;
m_ki_enc_algo=1;
EXPECT_FALSE(handleDbResponse(&p_MsgPtr));
}

TEST_F(UT_CtxtSendAuthenticationInfo,handleDbResponse_True_Two_Func) {
RetrieveSubsAuthData p_MsgPtr;
//m_OtherImsiSubscriberFlag=false;
g_ConfigData->m_MemcEnableFlag=1;
g_AucConfigReaderObj->m_SAI_AIR_MemcachedFlag=1;
p_MsgPtr.m_RoamPartnerId=0;
//p_MsgPtr.m_ro=3;
p_MsgPtr.m_ki_enc_algo=1;
p_MsgPtr.m_auth_algo=6;
p_MsgPtr.m_subsType=4;
p_MsgPtr.m_networkId=1;
p_MsgPtr.m_AucTemplateId=1;
p_MsgPtr.m_hlrAddress[20]="229940459190";
//p_MsgPtr.m_msisdn[16+1]="andhdyekjhj";
//p_MsgPtr.m_hlrAddress[20]="22994";
p_MsgPtr.m_k_key[32]="abdfhygwhdjhdhhddkjgyuklmbgfrtym";
p_MsgPtr.m_k[16]="sgagvadjtgdvmjku";
EXPECT_FALSE(handleDbResponse(&p_MsgPtr));
}

TEST_F(UT_CtxtSendAuthenticationInfo,handleDbResponse_m_auth_algo_Five_Func) {
RetrieveSubsAuthData p_MsgPtr;
g_ConfigData->m_MemcEnableFlag=1;
g_AucConfigReaderObj->m_SAI_AIR_MemcachedFlag=1;
p_MsgPtr.m_RoamPartnerId=0;
p_MsgPtr.m_ki_enc_algo=1;
p_MsgPtr.m_auth_algo=5;
p_MsgPtr.m_subsType=4;
p_MsgPtr.m_networkId=1;
p_MsgPtr.m_AucTemplateId=1;
p_MsgPtr.m_hlrAddress[20]="229940459190";
p_MsgPtr.m_k_key[32]="abdfhygwhdjhdhhddkjgyuklmbgfrtym";
p_MsgPtr.m_k[16]="sgagvadjtgdvmjku";
EXPECT_FALSE(handleDbResponse(&p_MsgPtr));
}

TEST_F(UT_CtxtSendAuthenticationInfo,handleDbResponse_m_auth_algo_Four_Func) {
RetrieveSubsAuthData p_MsgPtr;
g_ConfigData->m_MemcEnableFlag=1;
g_AucConfigReaderObj->m_SAI_AIR_MemcachedFlag=1;
p_MsgPtr.m_RoamPartnerId=0;
p_MsgPtr.m_ki_enc_algo=1;
p_MsgPtr.m_auth_algo=4;
p_MsgPtr.m_subsType=4;
p_MsgPtr.m_networkId=1;
p_MsgPtr.m_AucTemplateId=1;
p_MsgPtr.m_hlrAddress[20]="229940459190";
p_MsgPtr.m_k_key[32]="abdfhygwhdjhdhhddkjgyuklmbgfrtym";
p_MsgPtr.m_k[16]="sgagvadjtgdvmjku";
EXPECT_FALSE(handleDbResponse(&p_MsgPtr));
}

TEST_F(UT_CtxtSendAuthenticationInfo,handleDbResponse_m_auth_algo_TWO_Func) {
RetrieveSubsAuthData p_MsgPtr;
g_ConfigData->m_MemcEnableFlag=1;
g_AucConfigReaderObj->m_SAI_AIR_MemcachedFlag=1;
p_MsgPtr.m_RoamPartnerId=0;
p_MsgPtr.m_ki_enc_algo=1;
p_MsgPtr.m_auth_algo=2;
p_MsgPtr.m_subsType=2;
p_MsgPtr.m_networkId=1;
p_MsgPtr.m_AucTemplateId=1;
p_MsgPtr.m_hlrAddress[20]="229940459190";
p_MsgPtr.m_k_key[32]="abdfhygwhdjhdhhddkjgyuklmbgfrtym";
p_MsgPtr.m_k[16]="sgagvadjtgdvmjku";
m_rnt=7;
EXPECT_FALSE(handleDbResponse(&p_MsgPtr));
}

TEST_F(UT_CtxtSendAuthenticationInfo,handleDbResponse_m_rnt_Func) {
RetrieveSubsAuthData p_MsgPtr;
g_ConfigData->m_MemcEnableFlag=1;
g_AucConfigReaderObj->m_SAI_AIR_MemcachedFlag=1;
p_MsgPtr.m_RoamPartnerId=0;
p_MsgPtr.m_ki_enc_algo=1;
p_MsgPtr.m_auth_algo=2;
p_MsgPtr.m_subsType=3;
p_MsgPtr.m_networkId=1;
p_MsgPtr.m_AucTemplateId=1;
p_MsgPtr.m_hlrAddress[20]="229940459190";
p_MsgPtr.m_k_key[32]="abdfhygwhdjhdhhddkjgyuklmbgfrtym";
p_MsgPtr.m_k[16]="sgagvadjtgdvmjku";
m_rnt=8;
//CtxtSendAuthenticationInfo *ptr=new CtxtSendAuthenticationInfo;
//ptr->m_ro=1;
m_ro=1;
//m_subsType=4;
p_MsgPtr.m_msisdn[16+1]="abcdefghijklmnop";
p_MsgPtr.m_requestNode=4;
p_MsgPtr.m_resynchFlag=true;
g_AucConfigReaderObj->m_TestFlag=1;
g_AucConfigReaderObj->m_TestFlag=1;
EXPECT_TRUE(handleDbResponse(&p_MsgPtr));
//delete ptr;
}

TEST_F(UT_CtxtSendAuthenticationInfo,handleDbResponse_Two_m_rnt_Func) {
RetrieveSubsAuthData p_MsgPtr;
g_ConfigData->m_MemcEnableFlag=1;
g_AucConfigReaderObj->m_SAI_AIR_MemcachedFlag=1;
p_MsgPtr.m_RoamPartnerId=0;
p_MsgPtr.m_ki_enc_algo=1;
p_MsgPtr.m_auth_algo=2;
p_MsgPtr.m_subsType=3;
p_MsgPtr.m_networkId=1;
p_MsgPtr.m_maxVectors=2;
p_MsgPtr.m_AucTemplateId=1;
p_MsgPtr.m_hlrAddress[20]="229940459190";
p_MsgPtr.m_k_key[32]="abdfhygwhdjhdhhddkjgyuklmbgfrtym";
p_MsgPtr.m_k[16]="sgagvadjtgdvmjku";
m_rnt=8;
m_ro=1;
p_MsgPtr.m_msisdn[16+1]="abcdefghijklmnop";
p_MsgPtr.m_requestNode=1;
p_MsgPtr.m_resynchFlag=false;
g_AucConfigReaderObj->m_TestFlag=1;
EXPECT_TRUE(handleDbResponse(&p_MsgPtr));
}

TEST_F(UT_CtxtSendAuthenticationInfo,handleDbResponse_Three_m_rnt_Func) {
RetrieveSubsAuthData p_MsgPtr;
g_ConfigData->m_MemcEnableFlag=1;
g_AucConfigReaderObj->m_SAI_AIR_MemcachedFlag=1;
p_MsgPtr.m_RoamPartnerId=0;
p_MsgPtr.m_ki_enc_algo=1;
p_MsgPtr.m_auth_algo=2;
p_MsgPtr.m_subsType=3;
p_MsgPtr.m_networkId=1;
p_MsgPtr.m_maxVectors=2;
p_MsgPtr.m_AucTemplateId=1;
p_MsgPtr.m_hlrAddress[20]="229940459190";
p_MsgPtr.m_k_key[32]="abdfhygwhdjhdhhddkjgyuklmbgfrtym";
p_MsgPtr.m_k[16]="sgagvadjtgdvmjku";
m_rnt=8;
m_ro=1;
p_MsgPtr.m_msisdn[16+1]="abcdefghijklmnop";
p_MsgPtr.m_requestNode=2;
p_MsgPtr.m_resynchFlag=false;
g_AucConfigReaderObj->m_TestFlag=1;
EXPECT_TRUE(handleDbResponse(&p_MsgPtr));
}

TEST_F(UT_CtxtSendAuthenticationInfo,handleDbResponse_Four_m_rnt_Func) {
RetrieveSubsAuthData p_MsgPtr;
g_ConfigData->m_MemcEnableFlag=1;
g_AucConfigReaderObj->m_SAI_AIR_MemcachedFlag=1;
p_MsgPtr.m_RoamPartnerId=0;
p_MsgPtr.m_ki_enc_algo=1;
p_MsgPtr.m_auth_algo=2;
p_MsgPtr.m_subsType=3;
p_MsgPtr.m_networkId=1;
p_MsgPtr.m_maxVectors=2;
p_MsgPtr.m_AucTemplateId=1;
p_MsgPtr.m_hlrAddress[20]="229940459190";
p_MsgPtr.m_k_key[32]="abdfhygwhdjhdhhddkjgyuklmbgfrtym";
p_MsgPtr.m_k[16]="sgagvadjtgdvmjku";
m_rnt=8;
m_ro=1;
p_MsgPtr.m_msisdn[16+1]="abcdefghijklmnop";
p_MsgPtr.m_requestNode=7;
p_MsgPtr.m_resynchFlag=false;
g_AucConfigReaderObj->m_TestFlag=1;
CtxtSendAuthenticationInfo::m_maxVectors=2;
g_OtherConfigData->m_LaterQueryDbTps=4;
EXPECT_TRUE(handleDbResponse(&p_MsgPtr));
}

TEST_F(UT_CtxtSendAuthenticationInfo,handleDbResponse_Five_m_rnt_Func) {
RetrieveSubsAuthData p_MsgPtr;
g_ConfigData->m_MemcEnableFlag=1;
g_AucConfigReaderObj->m_SAI_AIR_MemcachedFlag=1;
p_MsgPtr.m_RoamPartnerId=0;
p_MsgPtr.m_ki_enc_algo=1;
p_MsgPtr.m_auth_algo=2;
p_MsgPtr.m_subsType=3;
p_MsgPtr.m_networkId=1;
CtxtSendAuthenticationInfo::m_maxVectors=2;
p_MsgPtr.m_AucTemplateId=1;
p_MsgPtr.m_hlrAddress[20]="229940459190";
p_MsgPtr.m_k_key[32]="abdfhygwhdjhdhhddkjgyuklmbgfrtym";
p_MsgPtr.m_k[16]="sgagvadjtgdvmjku";
m_rnt=8;
m_ro=1;
p_MsgPtr.m_msisdn[16+1]="abcdefghijklmnop";
p_MsgPtr.m_requestNode=7;
p_MsgPtr.m_resynchFlag=false;
g_AucConfigReaderObj->m_TestFlag=0;
g_OtherConfigData->m_LaterQueryDbTps=4;
EXPECT_TRUE(handleDbResponse(&p_MsgPtr));
}

TEST_F(UT_CtxtSendAuthenticationInfo,handleDbResponse_six_m_rnt_Func) {
RetrieveSubsAuthData p_MsgPtr;
g_ConfigData->m_MemcEnableFlag=1;
g_AucConfigReaderObj->m_SAI_AIR_MemcachedFlag=1;
p_MsgPtr.m_RoamPartnerId=0;
p_MsgPtr.m_ki_enc_algo=1;
p_MsgPtr.m_auth_algo=4;
p_MsgPtr.m_subsType=3;
CtxtSendAuthenticationInfo::m_subsType=4;
p_MsgPtr.m_networkId=1;
CtxtSendAuthenticationInfo::m_maxVectors=2;
p_MsgPtr.m_AucTemplateId=1;
p_MsgPtr.m_hlrAddress[20]="229940459190";
p_MsgPtr.m_k_key[32]="abdfhygwhdjhdhhddkjgyuklmbgfrtym";
p_MsgPtr.m_k[16]="sgagvadjtgdvmjku";
m_rnt=7;
m_ro=1;
g_AucConfigReaderObj->m_RandFlag=1;
p_MsgPtr.m_msisdn[16+1]="abcdefghijklmnop";
p_MsgPtr.m_requestNode=4;
p_MsgPtr.m_resynchFlag=false;
g_AucConfigReaderObj->m_TestFlag=0;
g_OtherConfigData->m_LaterQueryDbTps=4;
EXPECT_FALSE(handleDbResponse(&p_MsgPtr));
}

TEST_F(UT_CtxtSendAuthenticationInfo,handleDbResponse_seven_m_rnt_Func) {
RetrieveSubsAuthData p_MsgPtr;
g_ConfigData->m_MemcEnableFlag=1;
g_AucConfigReaderObj->m_SAI_AIR_MemcachedFlag=1;
p_MsgPtr.m_RoamPartnerId=0;
p_MsgPtr.m_ki_enc_algo=1;
p_MsgPtr.m_auth_algo=1;
p_MsgPtr.m_subsType=3;
p_MsgPtr.m_networkId=1;
CtxtSendAuthenticationInfo::m_maxVectors=2;
p_MsgPtr.m_AucTemplateId=1;
p_MsgPtr.m_hlrAddress[20]="229940459190";
p_MsgPtr.m_k_key[32]="abdfhygwhdjhdhhddkjgyuklmbgfrtym";
p_MsgPtr.m_k[16]="sgagvadjtgdvmjku";
m_rnt=8;
m_ro=1;
p_MsgPtr.m_msisdn[16+1]="abcdefghijklmnop";
p_MsgPtr.m_requestNode=7;
p_MsgPtr.m_resynchFlag=false;
g_AucConfigReaderObj->m_TestFlag=0;
g_OtherConfigData->m_LaterQueryDbTps=4;
EXPECT_FALSE(handleDbResponse(&p_MsgPtr));
}

TEST_F(UT_CtxtSendAuthenticationInfo,handleDbResponse_eight_m_rnt_Func) {
RetrieveSubsAuthData p_MsgPtr;
g_ConfigData->m_MemcEnableFlag=1;
g_AucConfigReaderObj->m_SAI_AIR_MemcachedFlag=1;
p_MsgPtr.m_RoamPartnerId=0;
p_MsgPtr.m_ki_enc_algo=1;
p_MsgPtr.m_auth_algo=2;
p_MsgPtr.m_subsType=3;
p_MsgPtr.m_networkId=1;
CtxtSendAuthenticationInfo::m_maxVectors=2;
p_MsgPtr.m_AucTemplateId=1;
p_MsgPtr.m_hlrAddress[20]="229940459190";
p_MsgPtr.m_k_key[32]="abdfhygwhdjhdhhddkjgyuklmbgfrtym";
p_MsgPtr.m_k[16]="sgagvadjtgdvmjku";
m_rnt=8;
m_ro=1;
p_MsgPtr.m_msisdn[16+1]="abcdefghijklmnop";
p_MsgPtr.m_requestNode=7;
p_MsgPtr.m_resynchFlag=false;
g_AucConfigReaderObj->m_TestFlag=0;
g_OtherConfigData->m_LaterQueryDbTps=4;
EXPECT_TRUE(handleDbResponse(&p_MsgPtr));
}

TEST_F(UT_CtxtSendAuthenticationInfo,handleDbResponse_nine_m_rnt_Func) {
RetrieveSubsAuthData p_MsgPtr;
g_ConfigData->m_MemcEnableFlag=1;
g_AucConfigReaderObj->m_SAI_AIR_MemcachedFlag=1;
p_MsgPtr.m_RoamPartnerId=0;
p_MsgPtr.m_ki_enc_algo=1;
p_MsgPtr.m_auth_algo=3;
p_MsgPtr.m_subsType=3;
p_MsgPtr.m_networkId=1;
CtxtSendAuthenticationInfo::m_maxVectors=2;
p_MsgPtr.m_AucTemplateId=1;
p_MsgPtr.m_hlrAddress[20]="229940459190";
p_MsgPtr.m_k_key[32]="abdfhygwhdjhdhhddkjgyuklmbgfrtym";
p_MsgPtr.m_k[16]="sgagvadjtgdvmjku";
m_rnt=8;
m_ro=1;
p_MsgPtr.m_msisdn[16+1]="abcdefghijklmnop";
p_MsgPtr.m_requestNode=7;
p_MsgPtr.m_resynchFlag=false;
g_AucConfigReaderObj->m_TestFlag=0;
g_OtherConfigData->m_LaterQueryDbTps=4;
EXPECT_TRUE(handleDbResponse(&p_MsgPtr));
}

TEST_F(UT_CtxtSendAuthenticationInfo,handleDbResponse_ten_m_rnt_Func) {
RetrieveSubsAuthData p_MsgPtr;
g_ConfigData->m_MemcEnableFlag=1;
g_AucConfigReaderObj->m_SAI_AIR_MemcachedFlag=1;
p_MsgPtr.m_RoamPartnerId=0;
p_MsgPtr.m_ki_enc_algo=1;
p_MsgPtr.m_auth_algo=5;
p_MsgPtr.m_subsType=3;
p_MsgPtr.m_networkId=1;
CtxtSendAuthenticationInfo::m_maxVectors=2;
CtxtSendAuthenticationInfo::m_subsType=3;
p_MsgPtr.m_AucTemplateId=1;
p_MsgPtr.m_hlrAddress[20]="229940459190";
p_MsgPtr.m_k_key[32]="abdfhygwhdjhdhhddkjgyuklmbgfrtym";
p_MsgPtr.m_k[16]="sgagvadjtgdvmjku";
m_rnt=7;
m_ro=1;
g_AucConfigReaderObj->m_RandFlag=1;
p_MsgPtr.m_msisdn[16+1]="abcdefghijklmnop";
p_MsgPtr.m_requestNode=7;
p_MsgPtr.m_resynchFlag=false;
g_AucConfigReaderObj->m_TestFlag=0;
g_OtherConfigData->m_LaterQueryDbTps=4;
EXPECT_FALSE(handleDbResponse(&p_MsgPtr));
}
*/
/*TEST_F(UT_CtxtSendAuthenticationInfo,handleDbResponse_eleven_m_rnt_Func) {
RetrieveSubsAuthData p_MsgPtr;
CtxtSendAuthenticationInfo::m_OtherImsiSubscriberFlag=true;
p_MsgPtr.m_RoamPartnerId=0;
//RetrieveDirectMemcQuery::m_OtherImsiSubscriberFlag=true;
m_ro=1;
p_MsgPtr.m_hlrAddress[20]="agdfstyjhyukliopmhjk";
//RetrieveSendImsiData::m_hlrAddress[20]="agdfstyjhyukliopmhjk";
p_MsgPtr.m_auth_algo=6;
p_MsgPtr.m_ki_enc_algo=1;
p_MsgPtr.m_subsType=3;
CtxtSendAuthenticationInfo::m_rnt=7;
p_MsgPtr.m_msisdn[16+1]="adfghjklioiuplkj";
CtxtSendAuthenticationInfo::m_maxVectors=2;
g_AucConfigReaderObj->m_RandFlag=1;
EXPECT_TRUE(handleDbResponse(&p_MsgPtr));


RetrieveSubsAuthData p_MsgPtr;
g_ConfigData->m_MemcEnableFlag=1;
g_AucConfigReaderObj->m_SAI_AIR_MemcachedFlag=1;
p_MsgPtr.m_RoamPartnerId=0;
p_MsgPtr.m_ki_enc_algo=1;
p_MsgPtr.m_auth_algo=4;
p_MsgPtr.m_subsType=3;
p_MsgPtr.m_networkId=1;
CtxtSendAuthenticationInfo::m_maxVectors=2;
CtxtSendAuthenticationInfo::m_subsType=3;
p_MsgPtr.m_AucTemplateId=1;
p_MsgPtr.m_hlrAddress[20]="229940459190";
p_MsgPtr.m_k_key[32]="abdfhygwhdjhdhhddkjgyuklmbgfrtym";
p_MsgPtr.m_k[16]="sgagvadjtgdvmjku";
m_rnt=7;
m_ro=1;
g_AucConfigReaderObj->m_RandFlag=1;
p_MsgPtr.m_msisdn[16+1]="abcdefghijklmnop";
p_MsgPtr.m_requestNode=7;
p_MsgPtr.m_resynchFlag=false;
g_AucConfigReaderObj->m_TestFlag=0;
g_OtherConfigData->m_LaterQueryDbTps=4;
EXPECT_FALSE(handleDbResponse(&p_MsgPtr));
}*/


//#define  g_spdPtr ((SubsProfileData*)g_spd)
//extern g_spdPtr;

/*TEST_F(UT_CtxtSendAuthenticationInfo,handleDbResponse_Func) {
RetrieveSubsAuthData p_MsgPtr;
SubsProfileData a;
m_OtherImsiSubscriberFlag=false;
g_ConfigData->m_MemcEnableFlag=1;
g_AucConfigReaderObj->m_SAI_AIR_MemcachedFlag=1;
p_MsgPtr.m_RoamPartnerId=1;
p_MsgPtr.m_networkId=1;
a.g_spdPtr->m_HlrNetworks=17.6;
EXPECT_FALSE(handleDbResponse(&p_MsgPtr));
}*/

/*TEST_F(UT_CtxtSendAuthenticationInfo,handleDbResponse_Func) {
RetrieveSubsAuthData p_MsgPtr;
m_OtherImsiSubscriberFlag=false;
g_ConfigData->m_MemcEnableFlag=1;
g_AucConfigReaderObj->m_SAI_AIR_MemcachedFlag=1;
p_MsgPtr.m_RoamPartnerId=1;
//map<int, HlrNetworks* > g;
//HlrNetworks *hlr1;
//hlr1=new HlrNetworks;
//hlr1->m_networkId=10;
//g.insert(make_pair(10, hlr1));
//hlr1.m_networkId=10;
p_MsgPtr.m_networkId=1;
p_MsgPtr.m_requestNode=7;
CtxtSendAuthenticationInfo obj;
obj.m_ro=1;
p_MsgPtr.m_hlrAddress[16+1]="abcdef";
p_MsgPtr.m_ki_enc_algo=1;
p_MsgPtr.m_auth_algo=6;
obj.m_rnt=7;
p_MsgPtr.m_msisdn[16+1]="abcdef";
p_MsgPtr.m_resynchFlag=true;
p_MsgPtr.m_requestNode=1;
EXPECT_TRUE(handleDbResponse(&p_MsgPtr));
//delete hlr1;
}*/




/******************************************************************/
/*TEST_F(UT_CtxtSendAuthenticationInfo,generateAkaNonce_Func) {
char a[]="abcdefghi";
EXPECT_NO_THROW(generateAkaNonce(a));
}

TEST_F(UT_CtxtSendAuthenticationInfo,retrieveAuts_Func) {
char a[]="abcdehfg";
EXPECT_NO_THROW(retrieveAuts(a));
}
*/
/*************************************************************************/
/*TEST_F(UT_CtxtSendAuthenticationInfo,handleError_Func) {
DiameterMsg p_msg("host26.realm26;1628358902;498433;1:2",DIAM_EVENT_REQUEST,303);
EXPECT_TRUE(handleError(12,5012,-1));
}*/






#undef private

















