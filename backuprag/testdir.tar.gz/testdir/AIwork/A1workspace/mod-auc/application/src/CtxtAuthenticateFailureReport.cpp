#include <CtxtAuthenticateFailureReport.h>
#include <stdio.h>
#include <MapMessages.h>
#include <ServiceCoordinator.h>
#include <Logger.h>
#include <IMAP3.h>
#include <AucDbQueries.h>
#include <DbActiveObject.h>
#include <Utilities.h>
#include <AucConfigReader.h>
#include <AucDbQueries.h>
#include <SnmpInterface.h>
#include <HlrTdrFiller.h>


/*
    TDR_REQUESTTYPE_INDEX=0,
    TDR_REQUESTMSISDN_INDEX,
    TDR_REQUESTIMSI_INDEX,
    TDR_MSGSTATUS_INDEX,
    TDR_ERRCODE_INDEX,
    TDR_LMSI_INDEX,
    TDR_REQUEST_DOMAIN_INDEX,
    TDR_PARTNER_TYPE_INDEX,

    TDR_CM_SRI_GMSCADDR_INDEX,
    TDR_CM_SRI_CALLREFNUM_INDEX,
    TDR_CM_SRI_SUPPRESSTCSI_INDEX,

    TDR_SSM_SSCODE_INDEX,
    TDR_SSM_BSCODE_INDEX,
    TDR_SSM_BSTYPE_INDEX,
    TDR_SSM_FTN_INDEX,
    TDR_SSM_FTSUBADDR_INDEX,
    TDR_SSM_NOREPTIMER_INDEX,
    TDR_SSM_NBRUSR_INDEX,
    TDR_SSM_DEFPRIO_INDEX,
    TDR_SSM_USSDSERVCODE_INDEX,
    TDR_SSM_USSDGWADDR_INDEX,

    TDR_SI_GSMSCFADDRESS_INDEX,
    TDR_SI_SGSNADDRESS_INDEX,
    TDR_SI_REQINFO_INDEX,

    TDR_AUC_NUM_VECTORS_REQUESTED_INDEX,
    TDR_AUC_NUM_VECTORS_SENT_INDEX,
    TDR_AUC_RESYNC_INFO_INDEX,
    TDR_AUC_AFR_RAND_INDEX,
    TDR_AUC_AFR_RE_ATTEMPT_INDEX,
    TDR_AUC_AFR_ACCESS_TYPE_INDEX,
    TDR_AUC_AFR_FAILURE_CAUSE_INDEX,

    TDR_OAM_NUM_OF_IMSI_PREFIXES_INDEX,
    TDR_OAM_IMSI_PREFIXES_INDEX,

*/

extern int g_AfrTrap;

CtxtAuthenticateFailureReport::CtxtAuthenticateFailureReport()
{
   memset(m_OrigAddr, '\0', 20+1);
}

CtxtAuthenticateFailureReport::~CtxtAuthenticateFailureReport()
{
   DLOG(0,0,"CtxtAuthenticateFailureReport::~CtxtAuthenticateFailureReport()");
}

bool CtxtAuthenticateFailureReport::processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag)
{
   DLOG(0,0,"Start of CtxtAuthenticateFailureReport::processMsg function");

   p_DeleteFlag=p_DeleteFlag; // This is just to keep the compiler happy

   MapSpecificMsg *l_specMsg = NULL;

   switch (p_MsgPtr->m_MsgType)
   {
      case MSG_TYPE_MAP:
         switch (((MapMsg*)p_MsgPtr)->m_MapMsgType)
         {
            case MAP_MSG_TYPE_COMMON:
               switch (((MapCommonMsg*)p_MsgPtr)->m_MapCommonMsgType)
               {
                  case MAP_CMN_OPEN_IND:
                     DLOG(0,0,"MAP_CMN_OPEN_IND received remote ssn: %d gt: %s", 
                           ((MapOpenInd*)p_MsgPtr)->m_OrigAddr.ssn,
                           ((MapOpenInd*)p_MsgPtr)->m_OrigAddr.globalTitle.addressInformation);
                     strncpy(m_OrigAddr, ((MapOpenInd*)p_MsgPtr)->m_OrigAddr.globalTitle.addressInformation, 20);
                     break;

                  case MAP_CMN_DELIMITER_IND:
                     DLOG(0,0,"MAP_CMN_DELIMITER_IND received");
                     break;

                  case MAP_CMN_CLOSE_IND:
                     DLOG(0,0,"MAP_CMN_CLOSE_IND received");
                     //printf("\nGot a Close. Call flow success.\n");
                     return true;
                     break;

                  case MAP_CMN_U_ABORT_IND:
                     m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_U_ABORT_RCVD); 
                     CLOG(0,0,"MAP_CMN_U_ABORT_IND received");
                     break;

                  case MAP_CMN_P_ABORT_IND:
                     m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_P_ABORT_RCVD); 
                     DLOG(0,0,"MAP_CMN_P_ABORT_IND received");
                     break;

                  case MAP_CMN_NOTICE_IND:
                     {
                        CLOG(0,0,"MAP_CMN_NOTICE_IND received");
                        m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_NOTICE_RCVD); 
                        MapCloseReq l_closeReq(((MapMsg*)p_MsgPtr)->m_UserDlgId);
                        g_sc.sendMsg(this, &l_closeReq);
                     }
                     break;

                  default:
                     DLOG(0,0,"Unknown Msg received [%d]", ((MapCommonMsg*)p_MsgPtr)->m_MapCommonMsgType);
                     break;
               }
               break;

            case MAP_MSG_TYPE_SPECIFIC:
               DLOG(0,0,"MAP_MSG_TYPE_SPECIFIC received");
               l_specMsg = (MapSpecificMsg*)p_MsgPtr;

               switch (((MapSpecificMsg*)p_MsgPtr)->m_MapSpecificEventType)
               {
                  case MAP_SPEC_EVENT_INDICATION:
                     {
                        DLOG(0,0,"MAP_SPEC_EVENT_INDICATION received");
                        g_si.sendSnmpTrap(g_AfrTrap, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL);

                        switch (((MapSpecificMsg*)p_MsgPtr)->m_OpCode)
                        {
                           case MAP_OP_CODE_authenticationFailureReport:
                              {
                                 if (false == ((MapSpecificMsg*)p_MsgPtr)->m_allocatedFlag)
                                 {
                                    CLOG(0,0,"Received AFR is NULL. Sending User Error (Unexpected Data)...");
                                    m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_unexpectedData);
                                    MapUserError l_userError(getInitialRespondingDlgId(), MAP_ERROR_unexpectedData, getInitialRespondingVersion(), NULL);
                                    g_sc.sendMsg(this, &l_userError);
                                    MapCloseReq l_closeReq(getInitialRespondingDlgId());
                                    g_sc.sendMsg(this, &l_closeReq);
                                 }
                                 else
                                 {
                                    DLOG(0,0,"Received AFR... ");

                                    IMAP3_AuthenticationFailureReportArg *l_temp = (IMAP3_AuthenticationFailureReportArg*)(((MapSpecificMsg*)p_MsgPtr)->m_structBuffer);

                                    char l_imsi[20];
                                    memset(l_imsi, '\0', 20);
                                    BCDToString((u8*)l_imsi, l_temp->imsi.value, l_temp->imsi.length);
                                    TLOG(0,1,"Authentication Failure Report received for IMSI %s", l_imsi);
                                    m_tdr.setChar(TDR_INDEX_REQUEST_TYPE, 'I');
                                    m_tdr.setString(TDR_INDEX_REQUEST_IMSI,(char*)l_imsi);

                                    LLOG(0,0,"Failure Cause: %d", l_temp->failureCause);
                                    m_tdr.setInteger(TDR_INDEX_AUC_AFR_FAILURE_CAUSE,l_temp->failureCause);

                                    if (l_temp->bit_mask & IMAP3_re_attempt_present)
                                    {
                                       LLOG(0,0,"Re-attempt : %d", l_temp->re_attempt);
                                       m_tdr.setInteger(TDR_INDEX_AUC_AFR_RE_ATTEMPT,l_temp->re_attempt);
                                    }

                                    if (l_temp->bit_mask & IMAP3_accessType_present)
                                    {
                                       TLOG(0,0,"Access Type : %d", l_temp->accessType);
                                       m_tdr.setInteger(TDR_INDEX_AUC_AFR_ACCESS_TYPE,l_temp->accessType);
                                    }

                                    if (l_temp->bit_mask & IMAP3_rand_present)
                                    {
                                       TLOG_HEX(0,0,"RAND", (char*)l_temp->rand.value, l_temp->rand.length);
                                       m_tdr.setHex(TDR_INDEX_AUC_AFR_RAND,(char*)l_temp->rand.value, l_temp->rand.length);
                                    }

                                    ERequestingNodeType l_rnt=REQUEST_NODE_VLR;

                                    if (l_temp->bit_mask & IMAP3_AuthenticationFailureReportArg_vlr_Number_present)
                                    {
                                       l_rnt=REQUEST_NODE_VLR;
                                       char l_vlrNumber[20+1];
                                       memset(l_vlrNumber, '\0', sizeof(l_vlrNumber));
                                       BCDToString((u8*)l_vlrNumber, l_temp->vlr_Number.value, l_temp->vlr_Number.length);
                                       LLOG(0,0,"VLR Number [%s]", l_vlrNumber);
                                    }

                                    if (l_temp->bit_mask & IMAP3_AuthenticationFailureReportArg_sgsn_Number_present)
                                    {
                                       l_rnt=REQUEST_NODE_SGSN;
                                       char l_sgsnNumber[20+1];
                                       memset(l_sgsnNumber, '\0', sizeof(l_sgsnNumber));
                                       BCDToString((u8*)l_sgsnNumber, l_temp->sgsn_Number.value, l_temp->sgsn_Number.length);
                                       LLOG(0,0,"SGSN Number [%s]", l_sgsnNumber);
                                    }

                                    if (strlen(l_imsi) < 15)
                                    {
                                       m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_unexpectedData); 
                                       MapUserError l_userError(getInitialRespondingDlgId(), MAP_ERROR_unexpectedData, getInitialRespondingVersion(), NULL);
                                       g_sc.sendMsg(this, &l_userError);
                                       MapCloseReq l_closeReq(getInitialRespondingDlgId());
                                       g_sc.sendMsg(this, &l_closeReq);
                                    }
                                    else
                                    {
                                       RetrieveSubsAuthData *l_rsad = new RetrieveSubsAuthData();
                                       strcpy(l_rsad->m_imsi, l_imsi);
                                       setTraceImsi(l_imsi);

                                       TLOG(0,0,"IMSI [%s]", l_imsi);

                                       l_rsad->m_cb = this;
                                       l_rsad->m_DbQueryType = 1;
                                       l_rsad->m_requestNode = l_rnt;
                                       l_rsad->m_msgVersion = 1;
                                       if(REQUEST_NODE_UNKNOWN != l_rnt)
                                       {
                                          strcpy(l_rsad->m_OrigAddr, m_OrigAddr);
                                       }
                                       l_rsad->m_retryCount                 =0;
                                       l_rsad->m_retryTimer                 =0;
                                       l_rsad->m_multi_imsi_validation_flag =g_AucConfigReaderObj->m_MULTI_IMSI_VALIDATION_FLAG;
                                       l_rsad->m_subs_barred_validation_flag=g_AucConfigReaderObj->m_SUBS_BARRED_VALIDATION_FLAG;
                                       l_rsad->m_requesting_node_validation_flag=g_AucConfigReaderObj->m_REQUESTING_NODE_VALIDATION_FLAG;
                                       g_act.execute(l_rsad);
                                    }


                                 }
                              }
                              break;

                           default:
                              DLOG(0,0,"Received Unknown Specific Message");
                              break;
                        }
                     }
                     break;

                  case MAP_SPEC_EVENT_RESULT:
                     {
                        DLOG(0,0,"MAP_SPEC_EVENT_RESULT received");
                     }
                     break;

                  case MAP_SPEC_EVENT_CONFIRMATION:
                     {
                        DLOG(0,0,"MAP_SPEC_EVENT_CONFIRMATION received");
                     }
                     break;

                  case MAP_SPEC_EVENT_USER_ERROR:
                     {
                        CLOG(0,0,"MAP_SPEC_EVENT_USER_ERROR received");
                     }
                     break;

                  case MAP_SPEC_EVENT_PROV_ERROR:
                     {
                        LLOG(0,0,"MAP_SPEC_EVENT_PROV_ERROR received");
                        MapCloseReq l_closeReq(((MapSpecificMsg*)p_MsgPtr)->m_UserDlgId);
                        g_sc.sendMsg(this, &l_closeReq);
                     }
                     break;

                  default:
                     ELOG(0,0,"ERROR!! Default received");
                     break;
               }
               break;

            default:
               break;
         }
         break;

      case MSG_TYPE_DB:
      {
         DLOG(0,0,"DB message received");
         
         RetrieveSubsAuthData* l_rsad = ((RetrieveSubsAuthData*)p_MsgPtr);

         if (strlen(l_rsad->m_hlrAddress) > 0)
         {
            sendMapOpenResponse(getInitialRespondingDlgId(), l_rsad->m_hlrAddress, 6);
            m_tdr.setString(TDR_INDEX_LOCAL_ADDRESS, l_rsad->m_hlrAddress);
         }

         if(DB_QUERY_RES_SUCCESS == l_rsad->m_DbQueryRes)
         {
            LLOG(0,0,"Sending AFR response");
            MapSpecificResult l_result(getInitialRespondingDlgId(), MAP_OP_CODE_authenticationFailureReport, MAP_V3);
            l_result.m_structBuffer = NULL;
            g_sc.sendMsg(this, &l_result);
         }
         else
         {
            WLOG(0,1,"AFR received for unknown subscriber");
            m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_unknownSubscriber);
            MapUserError l_userError(getInitialRespondingDlgId(), MAP_ERROR_unknownSubscriber, getInitialRespondingVersion(), NULL);
            g_sc.sendMsg(this, &l_userError);
         }

         DLOG(0,0,"Closing the Dialogue");
         MapCloseReq l_closeReq(getInitialRespondingDlgId());
         g_sc.sendMsg(this, &l_closeReq);
      }
      break;

      default:
         DLOG(0,0,"Unknown message received");
         break;

   }
   return true;
}
