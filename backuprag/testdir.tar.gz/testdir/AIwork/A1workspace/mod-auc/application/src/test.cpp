#include <openssl/hmac.h>
#include <openssl/evp.h>
#include <stdio.h>
#include <string.h>

#define u8 unsigned char

void printHex(char *data, unsigned char *p_print, int p_length)
{
   printf("\n. %s len:%d :", data, p_length);
   for (int i = 0; i < p_length; i++)
   {
     printf("%02x ", (unsigned int)p_print[i]);
   }
   printf("\n");
}

bool openssl_hmac(u8 p_key[32], u8 p_data[14], u8 p_kasme[32]) 
{
   // Be careful of the length of string with the choosen hash engine. SHA1 needed 20 characters.
   // Change the length accordingly with your choosen hash engine.     
   unsigned char* result;
   unsigned int len = 32; 

   result = (unsigned char*)malloc(sizeof(char) * len);

   HMAC_CTX ctx;
   HMAC_CTX_init(&ctx);

   printHex("KEY", p_key, 32);
   printHex("DATA",p_data, 14);

   // Using sha1 hash engine here.
   // You may use other hash engines. e.g EVP_md5(), EVP_sha224, EVP_sha512, etc
   HMAC_Init_ex(&ctx, p_key, 32, EVP_sha256(), NULL);
   HMAC_Update(&ctx, p_data, 14);
   HMAC_Final(&ctx, result, &len);
   HMAC_CTX_cleanup(&ctx);

   printHex("KASME", result, len);

   free(result);

   return true;
}

bool calculateKASME(u8 p_k[16], u8 p_fc, u8 p_snId[3], u8 p_sqn[6], u8 p_ak[6], u8 p_kasme[32])
{
   //Preparation of S
   //FC = 0x10,
   //P0 = SN id,
   //L0 = length of SN id (i.e. 0x00 0x03),
   //P1 = SQN . AK
   //L1 = length of SQN . AK (i.e. 0x00 0x06) 

   u8 l_s[14];
   l_s[0] = p_fc;
   memcpy(l_s+1, p_snId, 3); //1,2,3
   l_s[4]=0x00;
   l_s[5]=0x03;
   for (int i = 0; i < 6; i++)   //6-11
      l_s[6+i] = p_sqn[i];// ^ p_ak[i];
   l_s[12]=0x00;
   l_s[13]=0x06;
   return openssl_hmac(p_k, l_s, p_kasme);
}

int main()
{
   //u8 l_k[] = {0x5A,0xFF,0x52,0xE6,0xAA,0xC6,0x52,0x02,0x41,0x11,0xC3,0x3D,0x3F,0x88,0x67,0x86,0x26,0xD7,0x7E,0x75,0x25,0x1C,0x7D,0xA4,0xBB,0x56,0x45,0x36,0x71,0x15,0xE4,0xA8};

   u8 l_k[] = {0x5A,0xFF,0x52,0xE6,0xAA,0xC6,0x52,0x02,0x41,0x11,0xC3,0x3D,0x3F,0x88,0x67,0x86,0x26,0xD7,0x7E,0x75,0x25,0x1C,0x7D,0xA4,0xBB,0x56,0x45,0x36,0x71,0x15,0xE4,0xA8};
   u8 l_fc  = 0x10;
   //u8 l_snId[] = {0x26, 0x80, 0x60};
   //u8 l_snId[] = {0x62, 0x08, 0x06};
   //u8 l_snId[] = {0x26, 0x80, 0x60};
   //u8 l_snId[] = {0x62, 0x68, 0x00};
   //u8 l_snId[] = {0x00, 0x68, 0x62};
   //u8 l_snId[] = {0x68, 0x02, 0x06};
   //u8 l_snId[] = {0x06, 0x02, 0x68};
   u8 l_snId[] = {0x62, 0xf8, 0x60};
   u8 l_ak[] = {0xB4,0x6F,0x17,0xE0,0xF8,0x4F};
   u8 l_kasme[32];
   calculateKASME(l_k, l_fc, l_snId, l_ak, l_ak, l_kasme);
   
   return 0;
}

