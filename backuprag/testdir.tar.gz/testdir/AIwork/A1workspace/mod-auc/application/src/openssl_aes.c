#include "des.h"
#include "string.h"
#include <ctype.h>
#include <aes.h>

/*
void DES_ede3_cbc_encrypt(const unsigned char *input,unsigned char *output,
      long length,
      DES_key_schedule *ks1,DES_key_schedule *ks2,
      DES_key_schedule *ks3,DES_cblock *ivec,int enc);

int DES_set_key_checked(const_DES_cblock *key,DES_key_schedule *schedule);

void AES_cbc_encrypt(const unsigned char *in, unsigned char *out,
	const unsigned long length, const AES_KEY *key,
	unsigned char *ivec, const int enc);

int AES_set_encrypt_key(const unsigned char *userKey, const int bits,
	AES_KEY *key);
int AES_set_decrypt_key(const unsigned char *userKey, const int bits,
	AES_KEY *key);

*/

char *atohx(char *p_dst, const char *p_src)
{  
   char *l_ret = p_dst;
   int lsb=0,msb=0;
   for(lsb=0, msb=0; *p_src; p_src += 2)
   {  
      msb = tolower(*p_src);
      lsb = tolower(*(p_src + 1));
      msb -= isdigit(msb) ? 0x30 : 0x57;
      lsb -= isdigit(lsb) ? 0x30 : 0x57;
      if((msb < 0x0 || msb > 0xf) || (lsb < 0x0 || lsb > 0xf))
      {
         *l_ret = 0;
         return NULL;
      }
      *p_dst++ = (char)(lsb | (msb << 4));  
   }
   *p_dst = 0;
   return l_ret;
}

int main()
{
   char *cp;

   //char key1[10]=""; atohx(key1, "42FB75BB21B2E866");
   char key1[33]=""; atohx(key1, "42FB75BB21B2E866582ABFA6C1EBA89A42FB75BB21B2E866582ABFA6C1EBA89A");
   char key2[10]=""; atohx(key2, "582ABFA6C1EBA89A");
   //char key1[] = {0x3D, 0x7B, 0x06, 0xA0, 0x56, 0x1E, 0x50, 0xFC};
   //char key2[] = {0x86, 0xA4, 0x63, 0x5B, 0x05, 0x68, 0xE4, 0x28};
   //char key1[] = {0x11, 0x11, 0x11, 0x11, 0x11, 0x11, 0x11, 0x11};
   //char key2[] = {0x11, 0x11, 0x11, 0x11, 0x11, 0x11, 0x11, 0x11};
   //char key1[] = {0x12, 0x34, 0x56, 0x78, 0x91, 0x23, 0x45, 0x67};
   //char key2[] = {0x89, 0x12, 0x34, 0x56, 0x78, 0x91, 0x23, 0x45};
   //char key3[] = {0x11, 0x11, 0x11, 0x11, 0x11, 0x11, 0x11, 0x11};
   
   //char in[] = {0x00,0x54, 0x15, 0x02, 0x00, 0x15, 0x15, 0x4C, 0x41, 0x41, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xA0, 0x3C, 0x10, 0x04, 0x04, 0x81, 0x55, 0x55, 0x20, 0x0A, 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x31, 0x09, 0x08, 0x29, 0x22, 0x99, 0x11, 0x11, 0x11, 0x11, 0x11, 0x32, 0x09, 0x08, 0x29, 0x22, 0x99, 0x22, 0x22, 0x22, 0x22, 0x22, 0x41, 0x08, 0x07, 0x91, 0x93, 0x11, 0x11, 0x11, 0x11, 0xF1, 0x42, 0x08, 0x07, 0x91, 0x93, 0x22, 0x22, 0x22, 0x22, 0xF2, 0x00, 0x00};
   //char in[] = {0x00, 0x54, 0x15, 0x02, 0x00, 0x15, 0x15, 0x4C, 0x41, 0x41, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xA0, 0x3C, 0x10, 0x04, 0x04, 0x81, 0x55, 0x55, 0x20, 0x0A, 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x31, 0x09, 0x08, 0x29, 0x22, 0x99, 0x11, 0x11, 0x11, 0x11, 0x11, 0x32, 0x09, 0x08, 0x29, 0x22, 0x99, 0x22, 0x22, 0x22, 0x22, 0x22, 0x41, 0x08, 0x07, 0x91, 0x93, 0x11, 0x11, 0x11, 0x11, 0xF1, 0x42, 0x08, 0x07, 0x91, 0x93, 0x22, 0x22, 0x22, 0x22, 0xF2, 0x00, 0x00};
   //char in[] = {0x00, 0x18, 0x15, 0x02, 0x00, 0x15, 0x15, 0x4C, 0x41, 0x41, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xA0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};

   char in[1000]="";
   atohx(in, "d22cadd25b1ecda866876592fc0ae766ddb19988765ded8cb35f7f4de4969e444470333f9812c8a9d1d0569551737349");
   //atohx(in, "005415020015154C4141000000000000A03C100404815555200A4444444444444444444431090829229911111111113209082922992222222222410807919311111111F1420807919322222222F20000");
   //atohx(in, "001815020015154C4141000000000000A000");
   //atohx(in, "00581516212525B00010000000000614A0A40000023F00A0A40000024444A0A40000025405A0DC01041408526F616D696E682AFFFFFFFFFFFFFFFFFFFFFF0000000000000000000000000000000000000000000000000000");

   char ivchar[] = {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
   char out[1255]="";
   char dec[255]="";
   int i;

   DES_key_schedule ks1,ks2,ks3;
   DES_cblock iv, iv2;
   memcpy(iv, ivchar, sizeof(ivchar));
   memcpy(iv2, ivchar, sizeof(ivchar));

   AES_KEY ectx;

   AES_set_encrypt_key((const unsigned char*)key1, 256, &ectx);

   /*
   DES_set_key_unchecked((const_DES_cblock *)key1, &ks1);
   DES_set_key_unchecked((const_DES_cblock *)key2, &ks2);
   DES_set_key_unchecked((const_DES_cblock *)key1, &ks3);
   */
   //DES_set_key((const_DES_cblock *)key1, &ks1);
   //DES_set_key((const_DES_cblock *)key2, &ks2);
   //DES_set_key((const_DES_cblock *)key1, &ks3);

   printf("\n Before encoding = ");
   for(i=0; i<88; i++)
   {
      printf(" %02x", in[i]&0x00ff);
   }
   printf("\n");

   AES_encrypt((const unsigned char*)in, (unsigned char*)out, &ectx);
   //AES_cbc_encrypt((const unsigned char*)in, (unsigned char*)out, 48, &ectx,  (unsigned char*)ivchar, AES_ENCRYPT);
   //DES_ede3_cbc_encrypt((const unsigned char*)in, (unsigned char*)out, 96, &ks1, &ks2, &ks3, &iv, DES_DECRYPT);
   //DES_ede3_cbc_encrypt((const unsigned char*)in, (unsigned char*)out, sizeof(in), &ks1, &ks2, &ks3, &iv, DES_ENCRYPT);
   //DES_ede3_cbcm_encrypt((const unsigned char*)in, (unsigned char*)out, 82, &ks1, &ks2, &ks3, &iv, &iv2, DES_ENCRYPT);
   //DES_ede2_cbc_encrypt((const unsigned char*)in, (unsigned char*)out, 18, &ks1, &ks2, &iv, DES_ENCRYPT);

   printf("\n After decrypting = ");
   for(i=0; i<150; i++)
   {
      printf(" %02x", out[i]&0x00ff);
   }
   printf("\n");
   exit(0);

   memcpy(iv, ivchar, sizeof(ivchar));
   /*
   DES_set_key((const_DES_cblock *)key1, &ks1);
   DES_set_key((const_DES_cblock *)key2, &ks2);
   DES_set_key((const_DES_cblock *)key1, &ks3);
   */

   AES_KEY dectx;
   AES_set_decrypt_key((const unsigned char*)key1, 256, &dectx);

   AES_cbc_encrypt((const unsigned char*)in, (unsigned char*)out, 96, &dectx,  (unsigned char*)ivchar, DES_DECRYPT);
   //DES_ede3_cbc_encrypt((const unsigned char*)out, (unsigned char*)dec, 80, &ks1, &ks2, &ks3, &iv, DES_DECRYPT);

   printf("\n size of in = %d \n After decoding = ", sizeof(in));
   for(i=0; i<82; i++)
   {
      printf(" %02x", dec[i]&0x00ff);
   }

   printf("\n");
}
