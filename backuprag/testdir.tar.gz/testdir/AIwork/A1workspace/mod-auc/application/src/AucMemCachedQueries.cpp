#include <AucMemCachedQueries.h>
#include <AucDbQueries.h>
#include <MemCachedUtilities.h>
#include <Logger.h>
#include <ConfigReader.h>
#include <AucConfigReader.h>
#include <SubsProfileData.h>

AucMemCachedQueries::AucMemCachedQueries()
{
   DLOG(0,1,"AucMemCachedQueries :cons:");
}

AucMemCachedQueries::~AucMemCachedQueries()
{
   DLOG(0,1,"AucMemCachedQueries :des:");
}

void KiSwapSomeBytes(unsigned char* pKI, unsigned char* pSwappedKI)
{
   //DLOG_HEX(0,0,"ORIGINAL KI",pKI,16);
   unsigned char l_temp[2];
   memset(l_temp,'\0',sizeof(l_temp));
   l_temp[0]=pSwappedKI[0];pSwappedKI[0]=pKI[15];pSwappedKI[15]=l_temp[0];
   l_temp[0]=pSwappedKI[2];pSwappedKI[2]=pKI[11];pSwappedKI[11]=l_temp[0];
   l_temp[0]=pSwappedKI[5];pSwappedKI[5]=pKI[8];pSwappedKI[8]=l_temp[0];
   l_temp[0]=pSwappedKI[9];pSwappedKI[9]=pKI[3];pSwappedKI[3]=l_temp[0];
   l_temp[0]=pSwappedKI[13];pSwappedKI[13]=pKI[10];pSwappedKI[10]=l_temp[0];
   //DLOG_HEX(0,0,"SWAPPED KI",pSwappedKI,16);
}

void KiRevertSwapppedBytes(unsigned char* pKI, unsigned char* pSwappedKI)
{
   //DLOG_HEX(0,0,"AFTER: SWAPPED KI",pSwappedKI,16);
   unsigned char l_temp[2];
   memset(l_temp,'\0',sizeof(l_temp));
   l_temp[0]=pSwappedKI[15];pKI[15]=pSwappedKI[0];pKI[0]=l_temp[0];
   l_temp[0]=pSwappedKI[11];pKI[11]=pSwappedKI[2];pKI[2]=l_temp[0];
   l_temp[0]=pSwappedKI[8];pKI[8]=pSwappedKI[5];pKI[5]=l_temp[0];
   l_temp[0]=pSwappedKI[3];pKI[3]=pSwappedKI[9];pKI[9]=l_temp[0];
   l_temp[0]=pSwappedKI[10];pKI[10]=pSwappedKI[13];pKI[13]=l_temp[0];
   //DLOG_HEX(0,0,"AFTER: ORIGINAL KI",pKI,16);
}

void RetrieveSubsAuthData::executeMemcQuery()
{
   RetrieveMemCached(m_memcActivePtr, m_MemcKey, m_MemcValue, m_MemcErrorCode, m_MemcErrorMessage, (0 == m_RoamPartnerId)?true:false, m_MemcIP, m_MemcPort);

   if(m_MemcErrorCode != 0)
   {
      m_MemcQueryRes = MEMC_QUERY_RES_FAILURE;
   }
   else
   {
      m_MemcQueryRes = MEMC_QUERY_RES_SUCCESS;
   }
}

void RetrieveSubsAuthData::serializeMemc()
{
   char l_memcKey[25];
   snprintf(l_memcKey,sizeof(l_memcKey),"%s_%s",m_imsi,(m_requestNode==REQUEST_NODE_VLR)?"V":((m_requestNode==REQUEST_NODE_SGSN)?"S":(m_requestNode==REQUEST_NODE_MME)?"M":"I"));
   snprintf(m_PriImsi4Distribution,sizeof(m_PriImsi4Distribution),"%s",m_imsi);
   m_MemcKey = l_memcKey;
   DLOG(0,0,"RetrieveSubsAuthData: serialize: MEMC_KEY[%s]",m_MemcKey.c_str());
}

bool RetrieveSubsAuthData::deSerializeMemc()
{
   DLOG(0,0,"RetrieveSubsAuthData: deSerialize: MEMC_KEY[%s] MEMC_VALUE[%s]",m_MemcKey.c_str(),m_MemcValue.c_str());
   if('D' == m_MemcValue.c_str()[0])
   {
      LLOG(0,0,"SUBSCRIBER[%s] marked as soft delete... pushing into DBQ",m_MemcKey.c_str());
      return false;
   }
   int l_RoamPartId = 0;
   int l_AucTempId = 0;
   int l_NetworkId = 0;
   int l_PartnerType = 0;
   char l_msisdn[16 + 1];
   memset(l_msisdn, '\0', sizeof(l_msisdn));
   unsigned char l_StringSqn[12+1];
   unsigned char l_StringKi[32+1];
   unsigned char l_RevertSwappedKi[16];
   if(false == ConfigReader::readString(m_MemcValue, "S", (char*)l_StringSqn, 1, 12))
   {
      ELOG(0,0,"SQN not present in Memcached Value");
      return false;
   }
   else
   {
      DLOG(0,0,"SQN present in Memcached Value:%s",l_StringSqn);
      atohx((char*)m_sqn,(const char*)l_StringSqn);
      DLOG_HEX(0,0,"MEMCACHED: SQN ",m_sqn,6);
   }

   if(false == ConfigReader::readString(m_MemcValue, "K", (char*)l_StringKi, 1, 32))
   {
      ELOG(0,0,"KI not present in Memcached Value");
      return false;
   }
   else
   {
      DLOG(0,0,"KI present in Memcached Value:%s",l_StringKi);
      atohx((char*)m_k,(const char*)l_StringKi);
      memset(l_RevertSwappedKi,'\0',sizeof(l_RevertSwappedKi));
      memcpy(l_RevertSwappedKi,m_k,16);
      KiRevertSwapppedBytes(l_RevertSwappedKi,m_k);
      memcpy(m_first_k,l_RevertSwappedKi,16);
      memcpy(m_k,m_first_k,16);
      //DLOG_HEX(0,0,"MEMCACHED: KI ",m_k,16);
   }

   if(false == ConfigReader::readInteger(m_MemcValue.c_str(), "P", l_PartnerType, 0, 999))
   {
      ELOG(0,0,"PartnerType not present in Memcached value");
      return false;
   }
   else
   {
      m_imsiType = l_PartnerType;
      DLOG(0,0,"PartnerType %d present in Memcached Value",l_PartnerType);
   }

   if(false == ConfigReader::readString(m_MemcValue, "M", l_msisdn, 1, 16))
   {
      ELOG(0,0,"MSISDN not present in Memcached Value");
      return false;
   }
   else
   {
      strncpy(m_msisdn,l_msisdn,16);
      DLOG(0,0,"MSISDN %s present in Memcached Value",l_msisdn); 
   }

   if(false == ConfigReader::readInteger(m_MemcValue.c_str(), "N", l_NetworkId, 1, 999))
   {
      ELOG(0,0,"NETWORK Id not present in Memcached value");
      return false;
   }
   m_networkId = l_NetworkId;

   if(false == ConfigReader::readInteger(m_MemcValue.c_str(), "R", l_RoamPartId, 0, 10000))
   {
      ELOG(0,0,"RoamPartnerId[%d] not present in Memcached Value",l_RoamPartId);
      return false;
   }
   else
   {
      m_RoamPartnerId = l_RoamPartId;
      if(0 != l_RoamPartId)
      {
         map<int, HlrRoamPartners* > :: iterator l_HlrRoamPartnersDetailsIter;
         l_HlrRoamPartnersDetailsIter = g_spdPtr->m_HlrRoamPartners.find(l_RoamPartId);
         if(l_HlrRoamPartnersDetailsIter != g_spdPtr->m_HlrRoamPartners.end())
         {
            if('M' == m_MemcKey.c_str()[m_MemcKey.length()-1])
            {
               snprintf(m_hssHost,sizeof(m_hssHost),"%s",(l_HlrRoamPartnersDetailsIter->second)->m_hssOrigHost);
               snprintf(m_hssRealm,sizeof(m_hssRealm),"%s",(l_HlrRoamPartnersDetailsIter->second)->m_hssOrigRealm);
               DLOG(0,0,"RoamPartnerId present in HlrRoamPartners map, filling HSS HOST[%s] and REALM[%s]",m_hssHost,m_hssRealm);
            }
            else
            {
               snprintf(m_hlrAddress,sizeof(m_hlrAddress),"%s",(l_HlrRoamPartnersDetailsIter->second)->m_hlrAddr);
               DLOG(0,0,"RoamPartnerId present in HlrRoamPartners map, filling HLR Address[%s]",m_hlrAddress);
            }
            m_errCode = 0;
            m_DbQueryRes = DB_QUERY_RES_SUCCESS;
         }
         else
         {
            TLOG(0,0,"HLR Address is NULL for RoamPartner[%d]",m_RoamPartnerId);
            m_errCode = 5;
         }
      }
      else
      {
         map<int, HlrNetworks* > :: iterator l_HlrNetworksDetailsIter;
         l_HlrNetworksDetailsIter = g_spdPtr->m_HlrNetworks.find(l_NetworkId);
         if(l_HlrNetworksDetailsIter != g_spdPtr->m_HlrNetworks.end())
         {
            if('M' == m_MemcKey.c_str()[m_MemcKey.length()-1])
            {
               snprintf(m_hssHost,sizeof(m_hssHost),"%s",(l_HlrNetworksDetailsIter->second)->m_hssOrigHost);
               snprintf(m_hssRealm,sizeof(m_hssRealm),"%s",(l_HlrNetworksDetailsIter->second)->m_hssOrigRealm);
               DLOG(0,0,"NetworkId Present in HlrNetworks map, filling HSS HOST[%s] and REALM[%s]",m_hssHost,m_hssRealm);
            }
            else if('I' == m_MemcKey.c_str()[m_MemcKey.length()-1])
            {
               snprintf(m_hssHost,sizeof(m_hssHost),"%s",(l_HlrNetworksDetailsIter->second)->m_hssCxOrigHost);
               snprintf(m_hssRealm,sizeof(m_hssRealm),"%s",(l_HlrNetworksDetailsIter->second)->m_hssCxOrigRealm);
               DLOG(0,0,"NetworkId Present in HlrNetworks map, filling HSS HOST[%s] and REALM[%s] for IMS MAR/MAA Message",m_hssHost,m_hssRealm);
            }   
            else
            {
               snprintf(m_hlrAddress,sizeof(m_hlrAddress),"%s",(l_HlrNetworksDetailsIter->second)->m_hlrAddr);
               DLOG(0,0,"NetworkId Present in HlrNetworks map, filling HLR Address[%s]",m_hlrAddress);
            }
            m_errCode = 0;
            m_DbQueryRes = DB_QUERY_RES_SUCCESS;
         }
         else
         {
            CLOG(0,0,"NetworkId[%d] Not Present in HlrNetworks map",l_NetworkId);
         }
      }
   }
   if(false == ConfigReader::readInteger(m_MemcValue.c_str(), "A", l_AucTempId, 1, 10000))
   {
      ELOG(0,0,"AucTemplateId[%d] not present in Memcached Value",l_AucTempId);
      return false;
   }
   else
   {
      m_AucTemplateId = l_AucTempId;
      map<int, HlrAucTemp *> :: iterator l_HlrAucTempDetailsIter;
      l_HlrAucTempDetailsIter = g_spdPtr->m_HlrAucTemp.find(l_AucTempId);
      if(l_HlrAucTempDetailsIter != g_spdPtr->m_HlrAucTemp.end())
      {
         DLOG(0,0,"AucTemplateId[%d] present in HlrAucTemp map, filling the details",l_AucTempId);
         DLOG(0,0,"LENGTH OF m_decrOp[%d] m_decrKiKey[%d] m_iv_char[%d]",(l_HlrAucTempDetailsIter->second)->m_decrOp_len,(l_HlrAucTempDetailsIter->second)->m_decrKiKey_len, (l_HlrAucTempDetailsIter->second)->m_dec_ki_init_vec_len);
         memcpy(m_op,(l_HlrAucTempDetailsIter->second)->m_decrOp,(l_HlrAucTempDetailsIter->second)->m_decrOp_len);
         m_k_len_key = (l_HlrAucTempDetailsIter->second)->m_decrKiKey_len;
         memcpy(m_k_key,(l_HlrAucTempDetailsIter->second)->m_decrKiKey,m_k_len_key);
         m_iv_len_char = (l_HlrAucTempDetailsIter->second)->m_dec_ki_init_vec_len;
         memcpy(m_iv_char,(l_HlrAucTempDetailsIter->second)->m_dec_ki_enc_init_vector,m_k_len_key);
         m_ki_enc_algo = (l_HlrAucTempDetailsIter->second)->m_kiEncalgo;
         m_auth_algo = (l_HlrAucTempDetailsIter->second)->m_authAlgo;
         m_subsType = 3;
         m_Customized_RC_Flag = (l_HlrAucTempDetailsIter->second)->m_Customized_RC_Flag;
         m_R1 = (l_HlrAucTempDetailsIter->second)->m_R1;
         m_R2 = (l_HlrAucTempDetailsIter->second)->m_R2;
         m_R3 = (l_HlrAucTempDetailsIter->second)->m_R3;
         m_R4 = (l_HlrAucTempDetailsIter->second)->m_R4;
         m_R5 = (l_HlrAucTempDetailsIter->second)->m_R5;
         memcpy(m_C1,(l_HlrAucTempDetailsIter->second)->m_C1,16);
         memcpy(m_C2,(l_HlrAucTempDetailsIter->second)->m_C2,16);
         memcpy(m_C3,(l_HlrAucTempDetailsIter->second)->m_C3,16);
         memcpy(m_C4,(l_HlrAucTempDetailsIter->second)->m_C4,16);
         memcpy(m_C5,(l_HlrAucTempDetailsIter->second)->m_C5,16);

         if(1 == g_AucConfigReaderObj->m_Custom_RI_CI_Values)
	 {
         memcpy(m_amf,(l_HlrAucTempDetailsIter->second)->m_amf,2);
         DLOG_HEX(0,0,"### deserialize ### m_amf is",m_amf,2);
         } 
         
         DLOG(0,0,"m_ki_enc_algo[%d] m_auth_algo[%d] m_subsType[%d] m_Customized_RC_Flag[%d] ",m_ki_enc_algo,m_auth_algo,m_subsType,m_Customized_RC_Flag); 
         m_errCode = 0;
         m_DbQueryRes = DB_QUERY_RES_SUCCESS;
         DLOG_HEX(0,0,"### deserialize ### m_op is",m_op,(l_HlrAucTempDetailsIter->second)->m_decrOp_len);
         DLOG_HEX(0,0,"### deserialize ### m_k_key is",m_k_key,m_k_len_key);
         DLOG_HEX(0,0,"### deserialize ### m_iv_char is",m_iv_char,m_iv_len_char);
      }
      else
      {
         ELOG(0,0,"AucTemplateId not present in HlrAucTemp map");
         return false;
      }
   }
   return true;
}



void UpdateSubsAuthData::executeMemcQuery()
{
   UpdateMemCached(m_memcActivePtr, m_MemcKey, m_MemcValue, m_MemcErrorCode, m_MemcErrorMessage,(0 == m_RoamPartnerId)?true:false, m_MemcIP, m_MemcPort);

   if(m_MemcErrorCode != 0)
   {
      m_MemcQueryRes = MEMC_QUERY_RES_FAILURE;
   }
   else
   {
      m_MemcQueryRes = MEMC_QUERY_RES_SUCCESS;
   }
}

void UpdateSubsAuthData::serializeMemc()
{
   if(m_RoamPartnerId > 0)
   {
      TLOG(0,0,"Other IMSI subscriber: Imsi[%s] PartnerId[%d] .. updating primaryIMSI[%s] in memcached",m_imsi,m_RoamPartnerId,m_primaryImsi);
   }
   char l_memcKey[25];
   snprintf(l_memcKey,sizeof(l_memcKey),"%s_%s",((m_RoamPartnerId>0)?m_primaryImsi:m_imsi),((m_requestNode==REQUEST_NODE_VLR)?"V":((m_requestNode==REQUEST_NODE_SGSN)?"S":(m_requestNode==REQUEST_NODE_MME)?"M":"I")));
   snprintf(m_PriImsi4Distribution,sizeof(m_PriImsi4Distribution),"%s",((m_RoamPartnerId>0)?m_primaryImsi:m_imsi));
   m_MemcKey = l_memcKey;


   char l_memcValue[200];
   unsigned char l_stringSqn[12+1];
   memset(l_stringSqn,'\0',sizeof(l_stringSqn));
   hxtoa(l_stringSqn,m_sqn,6);
   unsigned char l_stringKI[32+1];
   memset(l_stringKI,'\0',sizeof(l_stringKI));
   unsigned char l_swappedKI[16];
   memset(l_swappedKI,'\0',sizeof(l_swappedKI));
   memcpy(l_swappedKI,m_first_k,16);
   KiSwapSomeBytes(m_first_k,l_swappedKI);
   hxtoa(l_stringKI,l_swappedKI,16);

   snprintf(l_memcValue,sizeof(l_memcValue),"<N>%d</N><R>%d</R><A>%d</A><S>%s</S><K>%s</K><P>%d</P><M>%s</M>",m_networkId,m_RoamPartnerId,m_AucTemplateId,l_stringSqn,l_stringKI,m_PartnerTpe,m_msisdn);
   m_MemcValue = l_memcValue;

   DLOG(0,0,"UpdateSubsAuthData: serialize: MEMC_KEY[%s] MEMC_VALUE[%s]",m_MemcKey.c_str(),m_MemcValue.c_str());
}

bool UpdateSubsAuthData::deSerializeMemc()
{
   DLOG(0,0, "UpdateSubsAuthData : deSerializeMemc");
   return true;
}

bool IsSubscriberOtherImsi(char* pImsi)
{
   // If IMSI is not in HLR_NETWORKS_IMSI with partner id 0, flag this as roaming
   map <int, list<HlrRoamPartnersImsiRange> > :: iterator HlrRoamPartnerImsiIter;
   for(HlrRoamPartnerImsiIter = g_spdPtr->m_HlrRaomPartnersImsi.begin(); HlrRoamPartnerImsiIter != g_spdPtr->m_HlrRaomPartnersImsi.end(); HlrRoamPartnerImsiIter++)
   {
      list<HlrRoamPartnersImsiRange> List = HlrRoamPartnerImsiIter->second;
      for(list<HlrRoamPartnersImsiRange> :: iterator ListIter = List.begin(); ListIter != List.end(); ListIter++)
      {
         if((atol(pImsi) >= atol(ListIter->m_FromImsi)) && (atol(pImsi) <= atol(ListIter->m_ToImsi)))
         {
            DLOG(0,0,"IMSI present in HlrRoamPartnersImsiRange map for NetworkId[%d], Subscriber is in HOME returning false",HlrRoamPartnerImsiIter->first);
            return false;
         }
         else
         {
            //DLOG(0,0,"IMSI not present in HlrRoamPartnersImsiRange map for NetworkId[%d], Subscriber is in Other Imsi",HlrRoamPartnerImsiIter->first);
         }
      }
   }
   LLOG(0,0,"Subscriber latched with Other IMSI[%s]",pImsi);

   return true;
}

//////////////////////////////////////////////////////////////////

RetrieveDirectMemcQuery::RetrieveDirectMemcQuery()
{
   m_MsgType = MSG_TYPE_MEMCACHED;       
   memset(m_primaryImsi,'\0',sizeof(m_primaryImsi));
   m_requestNode=REQUEST_NODE_VLR;
   m_OtherImsiSubscriberFlag = false;
   memset(m_sqn, '\0', 6);  
   DLOG(0,1,"RetrieveDirectMemcQuery :cons:");
}

RetrieveDirectMemcQuery::~RetrieveDirectMemcQuery()
{
   DLOG(0,1,"RetrieveDirectMemcQuery :des:");
}

void RetrieveDirectMemcQuery::executeMemcQuery()
{
   RetrieveMemCached(m_memcActivePtr, m_MemcKey, m_MemcValue, m_MemcErrorCode, m_MemcErrorMessage,(false == m_OtherImsiSubscriberFlag)?true:false, m_MemcIP, m_MemcPort);

   if(m_MemcErrorCode != 0)
   {
      m_MemcQueryRes = MEMC_QUERY_RES_FAILURE;
   }
   else
   {
      m_MemcQueryRes = MEMC_QUERY_RES_SUCCESS;
   }
}

void RetrieveDirectMemcQuery::serializeMemc()
{
   char l_memcKey[25];
   snprintf(l_memcKey,sizeof(l_memcKey),"%s_%s",m_primaryImsi,(m_requestNode==REQUEST_NODE_VLR)?"V":((m_requestNode==REQUEST_NODE_SGSN)?"S":(m_requestNode==REQUEST_NODE_MME)?"M":"I"));
   m_MemcKey = l_memcKey;
   snprintf(m_PriImsi4Distribution,sizeof(m_PriImsi4Distribution),"%s",m_primaryImsi);
   DLOG(0,0,"RetrieveDirectMemcQuery: serialize: MEMC_KEY[%s]",m_MemcKey.c_str());
}
bool RetrieveDirectMemcQuery::deSerializeMemc()
{
   DLOG(0,0,"RetrieveDirectMemcQuery: deSerialize: MEMC_KEY[%s] MEMC_VALUE[%s]",m_MemcKey.c_str(),m_MemcValue.c_str());

   unsigned char l_StringSqn[12+1];
   if(false == ConfigReader::readString(m_MemcValue, "S", (char*)l_StringSqn, 1, 12))
   {
      ELOG(0,0,"Direct Memcached Query Response: SQN not present in Memcached Value");
      return false;
   }
   else
   {
      DLOG(0,0,"Direct Memcached Query Response: SQN present in Memcached Value:%s",l_StringSqn);
      memset(m_sqn, '\0', 6);  
      atohx((char*)m_sqn,(const char*)l_StringSqn);
   }
   return true;
}

//////////////////////////////////////////////////////
