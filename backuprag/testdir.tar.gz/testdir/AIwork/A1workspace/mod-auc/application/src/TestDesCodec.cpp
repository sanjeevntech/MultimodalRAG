#include <DesCodec.h>
#include <openssl/des.h>
#include <string.h>

bool DesCodec::decrypt(unsigned char *p_nonEncrypted, unsigned char *p_Encrypted, unsigned char *p_key)
{
   DES_key_schedule l_ks;

   //Decrypt the first 8 bytes
   DES_set_key((const_DES_cblock *)p_key, &l_ks);
   DES_ecb_encrypt((const_DES_cblock*)p_Encrypted, (DES_cblock*)p_nonEncrypted, &l_ks, DES_DECRYPT);

   //Decrypt the next 8 bytes
   DES_set_key((const_DES_cblock *)p_key, &l_ks);
   DES_ecb_encrypt((const_DES_cblock*)(p_Encrypted+8), (DES_cblock*)(p_nonEncrypted+8), &l_ks, DES_DECRYPT);

   return true;
}

bool DesCodec::decryptTripleDes(unsigned char *p_nonEncrypted, unsigned char *p_Encrypted, unsigned char *p_key, int encdec)
{
   char ivchar[] = {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
   DES_cblock iv;
   memcpy(iv, ivchar, sizeof(ivchar));

   DES_key_schedule l_ks1;
   DES_key_schedule l_ks2;
   DES_key_schedule l_ks3;

   DES_set_key((const_DES_cblock *)p_key, &l_ks1);
   DES_set_key((const_DES_cblock *)p_key+8, &l_ks1);
   DES_set_key((const_DES_cblock *)p_key+16, &l_ks1);
   DES_ede3_cbc_encrypt((const unsigned char *)p_Encrypted, (unsigned char *)p_nonEncrypted, 16, &l_ks1, &l_ks2, &l_ks3, &iv, encdec);

   return true;
}

int main()
{
   DesCodec l_des;
   char key1[] = {0x31,0x31,0x31,0x31,0x31,0x31,0x31,0x31,0x32,0x32,0x32,0x32,0x32,0x32,0x32,0x32,0x31,0x31,0x31,0x31,0x31,0x31,0x31,0x31};
   char in[] = {0x31,0x31,0x31,0x31,0x31,0x31,0x31,0x31,0x31,0x31,0x31,0x31,0x31,0x31,0x31,0x31};
   char dec[20]="";
   char dec1[20]="";

   //l_des.decrypt((unsigned char *)dec, (unsigned char *)in, (unsigned char *)key1);
   l_des.decryptTripleDes((unsigned char *)dec, (unsigned char *)in, (unsigned char *)key1, DES_ENCRYPT);

   printf("\nEncrypted\n");
   for(int i=0; i<16; i++)
   {
      printf(" %02x", dec[i]);
   }
   printf("\n\n");

   char key2[] = {0x31,0x31,0x31,0x31,0x31,0x31,0x31,0x31,0x32,0x32,0x32,0x32,0x32,0x32,0x32,0x32,0x31,0x31,0x31,0x31,0x31,0x31,0x31,0x31};
   l_des.decryptTripleDes((unsigned char *)dec1, (unsigned char *)dec, (unsigned char *)key2, DES_DECRYPT);
   printf("\nDecrypted\n");
   for(int i=0; i<16; i++)
   {
      printf(" %02x", dec1[i]);
   }
   printf("\n\n");
}
///usr/sfw/bin/gcc DesCodec.cpp -o des  -I/usr/sfw/include/openssl -lcrypto -L/usr/local/ssl/lib/ -I../inc -lstdc++
//OPEN_SSL_INC
//OPEN_SSL_LIB

