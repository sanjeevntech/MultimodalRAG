#include <DesCodec.h>
#include <openssl/des.h>
#include <openssl/aes.h>
#include <openssl/err.h>
#include <openssl/conf.h>
#include <string.h>
#include <Logger.h>

extern void printHexOnDebug(char *p_text, char *p_buffer, int p_length);

bool DesCodec::decrypt(unsigned char *p_nonEncrypted, unsigned char *p_Encrypted, unsigned char *p_key)
{
   DES_key_schedule l_ks;

   //Decrypt the first 8 bytes
   DES_set_key((const_DES_cblock *)p_key, &l_ks);
   DES_ecb_encrypt((const_DES_cblock*)p_Encrypted, (DES_cblock*)p_nonEncrypted, &l_ks, DES_DECRYPT);

   //Decrypt the next 8 bytes
   DES_set_key((const_DES_cblock *)p_key, &l_ks);
   DES_ecb_encrypt((const_DES_cblock*)(p_Encrypted+8), (DES_cblock*)(p_nonEncrypted+8), &l_ks, DES_DECRYPT);

   return true;
}

bool DesCodec::decryptData(unsigned char *p_nonEncrypted, 
      unsigned char *p_Encrypted, 
      int            p_enc_algo,
      unsigned char *p_key, 
      int            p_len_key,
      unsigned char *p_ivchar,
      int            p_len_ivchar,
      int            p_mode,
      int p_type)
{
   DES_key_schedule l_ks1;
   DES_key_schedule l_ks2;
   DES_key_schedule l_ks3;
   DES_cblock iv;
   AES_KEY wctx; 

   if((1 == p_mode) || (2 == p_mode) || (3 == p_mode))
   {
      memcpy(iv, p_ivchar, p_len_ivchar);
      printHexOnDebug("IV copied", (char *)iv, p_len_ivchar);
   }
   if(1 == p_enc_algo) /* DES */
   {
      if(0 == p_mode) /* ECB */
      {
         DES_set_key((const_DES_cblock *)p_key, &l_ks1);
         DES_ecb_encrypt((const_DES_cblock*)p_Encrypted, (DES_cblock*)p_nonEncrypted, &l_ks1, DES_DECRYPT);
         DES_set_key((const_DES_cblock *)p_key, &l_ks1);
         DES_ecb_encrypt((const_DES_cblock*)(p_Encrypted+8), (DES_cblock*)(p_nonEncrypted+8), &l_ks1, DES_DECRYPT);
      }
      else if(1 == p_mode) /* CBC */
      {
         DES_set_key((const_DES_cblock *)p_key, &l_ks1);
         DES_cbc_encrypt(p_Encrypted, p_nonEncrypted, 16, &l_ks1, &iv, DES_DECRYPT);
      }
      else if(2 == p_mode) /* CFB */
      {
         DES_set_key((const_DES_cblock *)p_key, &l_ks1);
         DES_cfb_encrypt(p_Encrypted, p_nonEncrypted, 8, 16, &l_ks1, &iv, DES_DECRYPT);
      }
      else if(3 == p_mode) /* OFB */
      {
         int num=0;
         DES_set_key((const_DES_cblock *)p_key, &l_ks1);
         //DES_ofb_encrypt(p_Encrypted, p_nonEncrypted, 8, 16, &l_ks1, &iv);
         DES_ofb64_encrypt(p_Encrypted, p_nonEncrypted, 16, &l_ks1, &iv, &num);
      }
   }
   else if(2 == p_enc_algo) /* Triple DES */
   {
      DES_set_key_unchecked((const_DES_cblock *)p_key, &l_ks1);
      DES_set_key_unchecked((const_DES_cblock *)(p_key+8), &l_ks2);
      DES_set_key_unchecked((const_DES_cblock *)(p_key+16), &l_ks3);
      printHexOnDebug("Encrypted", (char *)p_Encrypted, 16);
      printHexOnDebug("IV", (char *)iv, 8);
      printHexOnDebug("KI KEY here", (char*)p_key, 24);
      DLOG(0,0,"p_type is %d, mode is %d", p_type, p_mode);
      if(0 == p_mode) /* ECB */
      {
         DES_ecb3_encrypt((const_DES_cblock*)p_Encrypted, (const_DES_cblock*)p_nonEncrypted, &l_ks1, &l_ks2, &l_ks3, p_type);
         DES_ecb3_encrypt((const_DES_cblock*)(p_Encrypted+8), (const_DES_cblock*)(p_nonEncrypted+8), &l_ks1, &l_ks2, &l_ks3, p_type);
      }
      else if(1 == p_mode) /* CBC */
      {
         DES_ede3_cbc_encrypt((const unsigned char *)p_Encrypted, (unsigned char *)p_nonEncrypted, 16, &l_ks1, &l_ks2, &l_ks3, &iv, p_type);
         printHexOnDebug("nonEncrypted", (char *)p_nonEncrypted, 16);
      }
      else if(2 == p_mode) /* CFB */
      {
         DES_ede3_cfb_encrypt((const unsigned char *)p_Encrypted, (unsigned char *)p_nonEncrypted, 8, 16, &l_ks1, &l_ks2, &l_ks3, &iv, p_type);
      }
      else if(3 == p_mode) /* OFB */
      {
         int num=0;
         DES_ede3_ofb64_encrypt((const unsigned char *)p_Encrypted, (unsigned char *)p_nonEncrypted, 16, &l_ks1, &l_ks2, &l_ks3, &iv, &num);
      }
   }
   else if(3 == p_enc_algo) /* AES */
   {
      AES_set_decrypt_key(p_key, 8*p_len_key, &wctx); 

      if(0 == p_mode) /* ECB */
      {
         AES_ecb_encrypt(p_Encrypted, p_nonEncrypted, &wctx, AES_DECRYPT);
      }
      else if(1 == p_mode) /* CBC */
      {
         AES_cbc_encrypt(p_Encrypted, p_nonEncrypted, 16, &wctx, p_ivchar, AES_DECRYPT);
      }
      else if(2 == p_mode) /* CFB */
      {
         int num=0;
         AES_cfb1_encrypt(p_Encrypted, p_nonEncrypted, 16, &wctx, p_ivchar, &num, AES_DECRYPT);
      }
      else if(3 == p_mode) /* OFB */
      {
         int num=0;
         AES_ofb128_encrypt(p_Encrypted, p_nonEncrypted, 16, &wctx, p_ivchar, &num);
      }
   }

   return true;
}

/*
   int main()
   {
   DesCodec l_des;
   char key1[] = {0x72,0xA1,0x25,0xB0,0x92,0x7C,0xEF,0x18};
   char in[] = {0x00, 0x4C, 0x16, 0x0E, 0xA0, 0x7E, 0xDE, 0x5B, 0x6B, 0xA9, 0x2E, 0xCD, 0x21, 0x23, 0x98, 0x1C};
   char dec[20]="";

   l_des.decrypt((unsigned char *)dec, (unsigned char *)in, (unsigned char *)key1);
   }
   */
///usr/sfw/bin/gcc DesCodec.cpp -o des  -I/usr/sfw/include/openssl -lcrypto -L/usr/local/ssl/lib/ -I../inc -lstdc++
//OPEN_SSL_INC
//OPEN_SSL_LIB

