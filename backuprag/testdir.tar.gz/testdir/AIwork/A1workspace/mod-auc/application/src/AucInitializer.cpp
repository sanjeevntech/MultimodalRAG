#include <Logger.h>
#include <MapMessages.h>
#include <ContextBase.h>
#include <ModuleBase.h>
#include <AucConfigReader.h>
#include <AucSimConfigReader.h>
#include <SnmpInterface.h>
#include <MapMessages.h>
#include <CtxtSimulatorImsSwxMultimediaAuthRequest.h>
#include <IMAP1.h>
#include <CtxtSendAuthenticationInfo.h>
#include <CtxtAuthenticateFailureReport.h>
#include <CtxtSimulatorImsMultimediaAuthRequest.h>
#include <CtxtSimulatorSendAuthenticationInfo.h>
#include <DiameterMessages.h>
#include <DiameterConstants.h>
#include <ExtendedServiceCoordinator.h>
#include <MySimulator.h>
#include <CtxtVLRSendAuthenticationInfo.h>

extern bool g_loadFlag;

enum EHlrAucModuleTrapId
{
   HLR_UNIQUE_TRAP_ID_AFR=901,
   HLR_UNIQUE_TRAP_ID_AUTH_REJECTED,
   HLR_UNIQUE_TRAP_ID_PROV_TO_ACT_FAIL,
};

int g_AfrTrap=-1;
int g_AuthRejected=-1;
int g_Prov2ActiveFailTrap;

extern "C" {
   ModuleBase *getModuleObj();
}


class AucModule : public ModuleBase
{
   public:
      AucModule(){}
      bool initModule();
      ContextBase *getCtxtObj(EMapOpCode, MapSpecificMsg*);
      ContextBase *getCtxtObj(EDiameterCommandCode, DiameterMsg*);
      ContextBase *getCtxtObj(EMapOpCode, SccpMsg*);
      char *getVersion();
      ConfigReader *getConfigReaderObj();
      ConfigReader **retrieveConfigReaderPtr();
};

AucModule g_AucModule;

ModuleBase *getModuleObj()
{
   return &g_AucModule;
}


char *g_op_env = NULL;
char *g_fixed_rand_str  = NULL;
char *g_sqn_env = NULL;
char *g_amf_env = NULL;

bool AucModule::initModule()
{
      g_fixed_rand_str  = getenv("FIXED_RAND_VALUE");
      g_sqn_env = getenv("FIXED_SQN");
      g_op_env = getenv("FIXED_OP");
      g_amf_env = getenv("FIXED_AMF");


   if(true == g_loadFlag)
   {
      m_modName="AUS";
   }
   else
   {
      m_modName="AUC";
      LLOG(0,0,"AUC APPVER-v:%s ci:%s cd:%s comp:%s %s", APP_VERSION, COMMIT_ID, COMMIT_DATE,__DATE__,__TIME__);
      // This function is called by the framework after reading the respective Module's Configuration file (if any)
#if 0
      if (NULL == g_AucConfigReaderObj) // This is required since this module needs a configuration file to be initialized
      {
         printf("\ng_AucConfigReaderObj is NULL\n");
         return false;
      }

      if (false == g_AucConfigReaderObj->m_derivedObjectInitializedFlag)
      {
         printf("\nERROR: AUC specific configuration file reading is mandatory");
         return false;
      }
#endif      
      g_AfrTrap      = g_si.registerSnmpTrap("AFR", "Authentication Failure Report received", HLR_UNIQUE_TRAP_ID_AFR);
      g_AuthRejected = g_si.registerSnmpTrap("AUTH_REJECTED", "Authentication Rejected by HSS/HLR", HLR_UNIQUE_TRAP_ID_AUTH_REJECTED);
      g_Prov2ActiveFailTrap = g_si.registerSnmpTrap("PROV_TO_ACTIVE_FAIL", "Provision To Active Fail", HLR_UNIQUE_TRAP_ID_PROV_TO_ACT_FAIL);
   }
   return true;
}



char *AucModule::getVersion()
{
   RETURN_VERSION(APP_VERSION); //2.0.25.1  2.0.24.1 2.0.15.0_Rev2 2.0.15.0 
}

ContextBase *AucModule::getCtxtObj(EMapOpCode p_OpCode, MapSpecificMsg *p_msg)
{
   DLOG(0,0,"Rcvd g_loadFlag %d", g_loadFlag);
   switch (p_OpCode)
   {
      case MAP_OP_CODE_sendAuthenticationInfo:
         {
            if(false == g_loadFlag)
            {
               DLOG(0,0,"Rcvd MAP_OP_CODE_sendAuthenticationInfo Newing CtxtSendAuthenticationInfo");
               return new CtxtSendAuthenticationInfo;
            }
            else
            {
               DLOG(0,0,"Rcvd MAP_OP_CODE_sendAuthenticationInfo Newing CtxtSimulatorSendAuthenticationInfo");
               return new CtxtVLRSendAuthenticationInfo;
            }
         }
         break;

      case MAP_OP_CODE_sendParameters:
         {
            DLOG(0,0,"Rcvd MAP_OP_CODE_sendParameters Newing CtxtSendAuthenticationInfo");
            if (false == p_msg->m_allocatedFlag)
            {
               CLOG(0,0,"m_allocatedFlag is false for SPR");
               return NULL;
            }
            else
            {
               bool l_intendedForAucFlag=false;
               IMAP1_SendParametersArg *l_temp = (IMAP1_SendParametersArg*)(p_msg->m_structBuffer);

               struct IMAP1_RequestParameters_ *l_rp = NULL;
               l_rp = l_temp->requestParameters;
               while (l_rp != NULL)
               {
                  if (IMAP1_request_AuthenticationSet == l_rp->value)
                  {
                     TLOG(0,0,"IMAP1_request_AuthenticationSet found in the list");
                     l_intendedForAucFlag=true;
                     break;
                  }
                  l_rp = l_rp->next;
               }

               if (true == l_intendedForAucFlag)
               {
                  TLOG(0,0,"Returning CtxtSendAuthenticationInfo");
                  return new CtxtSendAuthenticationInfo;
               }
               else
               {
                  CLOG(0,0,"Not Intended for AUC");
                  return NULL;
               }
            }
         }
         break;

      case MAP_OP_CODE_authenticationFailureReport:
         {
            DLOG(0,0,"Newing CtxtAuthenticateFailureReport");
            return new CtxtAuthenticateFailureReport;
         }
         break;

      default:
         {
            DLOG(0,0,"getAucCtxtObj Unknown OpCode [%d]",p_OpCode);
            printf("\ngetAucCtxtObj Unknown OpCode [%d]",p_OpCode);
            return NULL;
         }
         break;
   }
}

ContextBase *AucModule::getCtxtObj(EDiameterCommandCode p_ccCode, DiameterMsg *p_msg)
{
   DLOG(0,0,"getCtxtObj");
   switch (p_ccCode)
   {
      case DIAM_COMM_CODE_S6A_S6D_AIR_AIA:
         {
            if(false == g_loadFlag)
            {
               DLOG(0,0,"Rcvd DIAM_COMM_CODE_S6A_S6D_AIR_AIA Newing CtxtSendAuthenticationInfo");
               return new CtxtSendAuthenticationInfo;
            }
            else
            {
               DLOG(0,0,"Rcvd DIAM_COMM_CODE_S6A_S6D_AIR_AIA Newing CtxtSimulatorSendAuthenticationInfo");
               return new CtxtSimulatorSendAuthenticationInfo;
            }
         }
         break;

      case DIAM_COMM_CODE_CX_DX_MAR_MAA:
         {
            if(false == g_loadFlag)
            {
               DLOG(0,0,"Rcvd DIAM_COMM_CODE_CX_DX_MAR_MAA Newing CtxtSendAuthenticationInfo");
               return new CtxtSendAuthenticationInfo;
            } 
            else
            {
               if(1 == g_AucSimConfigReaderObj->m_CxSwxFlag)
               {    
                  DLOG(0,0,"Rcvd DIAM_COMM_CODE_SWX_MAR_MAA Newing CtxtSimulatorImsMultimediaAuthRequest");
                  return new CtxtSimulatorImsSwxMultimediaAuthRequest;
                  // return new CtxtSimulatorImsMultimediaAuthRequest;
               }
               else
               {
                  DLOG(0,0,"getCtxtObj 6");
                  DLOG(0,0,"Rcvd DIAM_COMM_CODE_CX_DX_MAR_MAA Newing CtxtSimulatorImsMultimediaAuthRequest");
                  return new CtxtSimulatorImsMultimediaAuthRequest;
               }
            }
         }
         break;

         default:
         {
            DLOG(0,0,"getAucCtxtObj Unknown ccCode [%d]",p_ccCode);
            printf("\ngetAucCtxtObj Unknown ccCode [%d]",p_ccCode);
            return NULL;
         }
         break;
   }
}

ContextBase *AucModule::getCtxtObj(EMapOpCode p_OpCode, SccpMsg* p_msg)
{
   ELOG(0,0,"SCCP message not supported");
   return NULL;
}

ConfigReader *AucModule::getConfigReaderObj()
{
   if(true == g_loadFlag)
   {
      LLOG(0,0,"Returning g_AucSimConfigReaderObj");
      return (g_AucSimConfigReaderObj = new AucSimConfigReader);
   }
   LLOG(0,0,"ConfigReader *AucModule::getConfigReaderObj()");
   return new AucConfigReader;
}

ConfigReader **AucModule::retrieveConfigReaderPtr()
{
   if(true == g_loadFlag)
   {
      LLOG(0,0,"ConfigReader Sim **AucModule::retrieveConfigReaderPtr() called");
      return (ConfigReader **)&g_AucSimConfigReaderObj;
   }
   LLOG(0,0,"ConfigReader **AucModule::retrieveConfigReaderPtr() called");
   return (ConfigReader **)&g_AucConfigReaderObj;
}

bool resetStruct(int p_version, int p_pdu, void *p_struct)
{
   if (NULL == p_struct)
   {
      ELOG(0,1,"p_struct is NULL");
      sleep(2);
      exit(1);
   }

   switch (p_version)
   {
      case 1:
         {
            switch(p_pdu)
            {
               default:
                  {
                     DLOG(0,0,"v1 In the default case");
                     return false;
                  }
                  break;
            }
         }
         break;

      case 2:
         {
            switch(p_pdu)
            {
               default:
                  {
                     DLOG(0,0,"v2 In the default case");
                     return false;
                  }
                  break;
            }
         }
         break;

      case 3:
         {
            switch(p_pdu)
            {
               default:
                  {
                     DLOG(0,0,"v3 In the default case");
                     return false;
                  }
                  break;
            }
         }
         break;

      default:
         {
            DLOG(0,0,"v-default In the default case");
         }
         break;
   }
   return false;
}

