#include <CtxtVLRSendAuthenticationInfo.h>
#include <stdio.h>
#include <MapMessages.h>
#include <ServiceCoordinator.h>
#include <Logger.h>
#include <IMAP1.h>
#include <IMAP2.h>
#include <IMAP3.h>
#include <OMAP1.h>
#include <OMAP2.h>
#include <OMAP3.h>
#include <DbActiveObject.h>
#include <ByteMilenage.h>
#include <AucSimConfigReader.h>
#include <AucConfigReader.h>
#include <DataUnion.h>
#include <Utilities.h>

extern bool resetStruct(int p_version, int p_pdu, void *p_struct);


CtxtVLRSendAuthenticationInfo::CtxtVLRSendAuthenticationInfo()
{
   //printf("\nVersion %d", (EMapVersion)(g_AucSimConfigReaderObj->m_simVersion));
   m_version=(EMapVersion)(g_AucSimConfigReaderObj->m_simVersion);
}

CtxtVLRSendAuthenticationInfo::~CtxtVLRSendAuthenticationInfo()
{

}

u8 g_sim_RAND[16] = { 0x23, 0x55, 0x3c, 0xbe, 0x96, 0x37, 0xa8, 0x9d, 0x21, 0x8a, 0xe6, 0x4d, 0xae, 0x47, 0xbf, 0x35 };
u8 g_sim_k[16]    = { 0x46, 0x5b, 0x5c, 0xe8, 0xb1, 0x99, 0xb4, 0x9f, 0xaa, 0x5f, 0x0a, 0x2e, 0xe2, 0x38, 0xa6, 0xbc };
u8 g_sim_OP[16]   = { 0xcd, 0xc2, 0x02, 0xd5, 0x12, 0x3e, 0x20, 0xf6, 0x2b, 0x6d, 0x67, 0x6a, 0xc7, 0x2c, 0xb3, 0x18 };
u8 g_sim_sqn[6]   = { 0xff, 0x9b, 0xb4, 0xd0, 0xb6, 0x07 };
u8 g_sim_amf[2]   = { 0x00, 0x00 };
short unsigned int g_sim_R1=64;
short unsigned int g_sim_R2=0;
short unsigned int g_sim_R3=32;
short unsigned int g_sim_R4=64;
short unsigned int g_sim_R5=96;
u8 g_sim_C1[16]={0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
u8 g_sim_C2[16]={0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x01};
u8 g_sim_C3[16]={0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x02};
u8 g_sim_C4[16]={0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x04};
u8 g_sim_C5[16]={0,0,0,0,0,0,0,0,0,0,0x00,0x00,0x00,0x00,0x00,0x08};

/*
u8 g_sim_RAND[16] = {0x55, 0xe9, 0x77, 0x4e, 0x46, 0xc1, 0xdc, 0x1a, 0x2c, 0xeb, 0x7d, 0x06, 0x40, 0xee, 0x58, 0xcf };
u8 g_sim_k[16]    = {0x4d, 0x34, 0x71, 0x7a, 0xa7, 0x17, 0x03, 0xa0, 0x28, 0xe1, 0x22, 0x62, 0x94, 0x1a, 0x2d, 0x98 };
u8 g_sim_OP[16]   = {0x87, 0x98, 0x23, 0x4b, 0x36, 0x57, 0xa2, 0x03, 0x6e, 0x0a, 0x47, 0xad, 0x80, 0x32, 0xe9, 0x30 };  
u8 g_sim_sqn[6]   = {0x29, 0xd3, 0xd3, 0x6d, 0x6a, 0x16 };
u8 g_sim_amf[2]   = { 0x00, 0x01 };
short unsigned int g_sim_R1=24;
short unsigned int g_sim_R2=80;
short unsigned int g_sim_R3=72;
short unsigned int g_sim_R4=64;
short unsigned int g_sim_R5=8;
u8 g_sim_C1[16]={0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x05};
u8 g_sim_C2[16]={0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x12,0x13};
u8 g_sim_C3[16]={0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x01,0x4d};
u8 g_sim_C4[16]={0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x05,0x15};
u8 g_sim_C5[16]={0,0,0,0,0,0,0,0,0,0,0x00,0x00,0x00,0x32,0xf1,0xa1};
*/
bool CtxtVLRSendAuthenticationInfo::sendv3SAI(int p_dialogue)
{
   DLOG(0,0,"Sending MapSpecificRequest ...");
   MapSpecificRequest l_request(p_dialogue, MAP_OP_CODE_sendAuthenticationInfo, MAP_V3);

   DECLARE(OMAP3_SendAuthenticationInfoArg, l_temp, 3, "OMAP3_SendAuthenticationInfoArg", resetStruct);
   numToBCD((u8*)g_AucSimConfigReaderObj->m_simImsi, l_temp->imsi.value, strlen(g_AucSimConfigReaderObj->m_simImsi));
   l_temp->imsi.length = (1+strlen(g_AucSimConfigReaderObj->m_simImsi))/2;
   l_temp->numberOfRequestedVectors=5;

  // if (0) // Re-synchronization info
  // {
      u8 l_auts[14];
      
      DLOG(0,0,"Calculating AUTS");
      if (g_AucConfigReaderObj == NULL) 
      {
         g_AucConfigReaderObj = new AucConfigReader();
         if (g_AucConfigReaderObj == NULL) 
         {
	    DLOG(0, 0, "Failed to initialize g_AucConfigReaderObj");
	 } 
         else 
         {
            g_AucConfigReaderObj->m_Custom_RI_CI_Values = 1; //Custom -1 , Default -0
         }
      }

      memcpy(g_ByteMilenageObj.m_OP, g_sim_OP, 16);
      DLOG_HEX(0,0," Testing OP ",g_ByteMilenageObj.m_OP,16);

 
      DLOG(0,0,"Resynchronisation info is set ..");
      l_temp->bit_mask |= OMAP3_re_synchronisationInfo_present;
      l_temp->re_synchronisationInfo.rand.length = 16;
      memcpy(l_temp->re_synchronisationInfo.rand.value, g_sim_RAND, 16);


      DLOG(0,0,"Resynch AUTS Value ...");
      l_temp->re_synchronisationInfo.auts.length = 14;
      calculateAuts(g_sim_amf, g_sim_k, g_sim_RAND, g_sim_sqn, g_sim_R1, g_sim_C1, g_sim_R5, g_sim_C5, l_auts);
      DLOG(0,0,"Success CALC AUTS. Setting the CalculatedAUTS value as Resynch AUTS");
      memcpy(l_temp->re_synchronisationInfo.auts.value, l_auts, 14);

  // }


   l_temp->requestingNodeType=OMAP3_RequestingNodeType_vlr;
   l_temp->bit_mask |= OMAP3_requestingNodeType_present;

   l_request.m_structBuffer = (void*)l_temp;
   g_sc.sendMsg(this, &l_request);


   DLOG(0,0,"Sending MapDelimiterReq Req ...");
   MapDelimiterReq l_del(p_dialogue);
   g_sc.sendMsg(this, &l_del);

   delete g_AucConfigReaderObj;
   g_AucConfigReaderObj = NULL;

   return true;
}

bool CtxtVLRSendAuthenticationInfo::sendv2SAIFromHex(int p_dialogue)
{
   DLOG(0,0,"Sending MapSpecificRequest ...");
   /*
      MapSpecificRequest l_request(p_dialogue, MAP_OP_CODE_sendAuthenticationInfo, MAP_V2);
      g_sc.decodeData(&l_request, &(g_ConfigData->i_NgConfigData.m_HexData1));
      g_sc.sendMsg(this, &l_request);*/

   MapSpecificRequest l_request(p_dialogue, MAP_OP_CODE_processUnstructuredSsData, MAP_V1);
   g_sc.decodeData(&l_request, &(g_ConfigData->i_NgConfigData.m_HexData1));
   g_sc.sendMsg(this, &l_request);


   DLOG(0,0,"Sending MapDelimiterReq Req ...");
   MapDelimiterReq l_del(p_dialogue);
   g_sc.sendMsg(this, &l_del);

   return true;
}

bool CtxtVLRSendAuthenticationInfo::sendv2SAI(int p_dialogue)
{
   DLOG(0,0,"Sending MapSpecificRequest ...");
   MapSpecificRequest l_request(p_dialogue, MAP_OP_CODE_sendAuthenticationInfo, MAP_V2);
   DECLARE(OMAP2_SendAuthenticationInfoArg, l_temp, 2, "OMAP2_SendAuthenticationInfoArg", resetStruct);
   l_temp->length = (1+strlen(g_AucSimConfigReaderObj->m_simImsi))/2;
   numToBCD((u8*)g_AucSimConfigReaderObj->m_simImsi, l_temp->value, strlen(g_AucSimConfigReaderObj->m_simImsi));
   l_request.m_structBuffer = (void*)(l_temp);
   g_sc.sendMsg(this, &l_request);


   DLOG(0,0,"Sending MapDelimiterReq Req ...");
   MapDelimiterReq l_del(p_dialogue);
   g_sc.sendMsg(this, &l_del);

   return true;
}

bool CtxtVLRSendAuthenticationInfo::sendv1SAI(int p_dialogue)
{
   DLOG(0,0,"Sending MapSpecificRequest ...");
   MapSpecificRequest l_request(p_dialogue, MAP_OP_CODE_sendParameters, MAP_V1);
   DECLARE(OMAP1_SendParametersArg, l_temp, 1, "OMAP1_SendParametersArg", resetStruct);

   l_temp->subscriberId.choice = OMAP1_SubscriberId_imsi_chosen;
   l_temp->subscriberId.u.imsi.length = (1+strlen(g_AucSimConfigReaderObj->m_simImsi))/2;
   numToBCD((u8*)g_AucSimConfigReaderObj->m_simImsi, l_temp->subscriberId.u.imsi.value, strlen(g_AucSimConfigReaderObj->m_simImsi));
   l_temp->requestParameters.count = 2;
   l_temp->requestParameters.value[0] = OMAP1_request_AuthenticationSet;//MAP1_request_AuthenticationSet;
   l_temp->requestParameters.value[1] = OMAP1_request_SubscriberData;

   l_request.m_structBuffer = (void*)(l_temp);
   g_sc.sendMsg(this, &l_request);


   DLOG(0,0,"Sending MapDelimiterReq Req ...");
   MapDelimiterReq l_del(p_dialogue);
   g_sc.sendMsg(this, &l_del);

   return true;
}

bool CtxtVLRSendAuthenticationInfo::initiateSAI()
{
   int l_UserDlgId = g_sc.getNewDialogue();

   if (m_version == MAP_V2)
   {
      DLOG(0,0,"Sending MapOpenReq ...");
      MapOpenReq l_mapOpenReq(l_UserDlgId, MAP_V2);
      l_mapOpenReq.m_ApplCntxt = MAP_AC_CODE_infoRetrieval;
      l_mapOpenReq.m_DestAddr  = g_ConfigData->i_NgConfigData.m_remoteAddress1;
      g_sc.sendMsg(this, &l_mapOpenReq);

      if (1)
      {
         return sendv2SAI(l_UserDlgId);
      }
      else
      {
         return sendv2SAIFromHex(l_UserDlgId);
      }


   }
   else if (m_version == MAP_V3)
   {
      DLOG(0,0,"Sending MapOpenReq ...");
      MapOpenReq l_mapOpenReq(l_UserDlgId, MAP_V3);
      l_mapOpenReq.m_ApplCntxt = MAP_AC_CODE_infoRetrieval;
      l_mapOpenReq.m_DestAddr  = g_ConfigData->i_NgConfigData.m_remoteAddress1;
      g_sc.sendMsg(this, &l_mapOpenReq);

      return sendv3SAI(l_UserDlgId);
   }
   else if (m_version == MAP_V1)
   {
      DLOG(0,0,"Sending MapOpenReq ...");
      MapOpenReq l_mapOpenReq(l_UserDlgId, MAP_V1);
      l_mapOpenReq.m_ApplCntxt = MAP_AC_CODE_infoRetrieval;
      l_mapOpenReq.m_DestAddr  = g_ConfigData->i_NgConfigData.m_remoteAddress1;
      g_sc.sendMsg(this, &l_mapOpenReq);

      return sendv1SAI(l_UserDlgId);
   }
   else
   {
      printf("\nNot initiating SAI %d", m_version);
      return false;
   }
}


bool CtxtVLRSendAuthenticationInfo::startProcessing()
{
   DLOG(0,0,"Start of CtxtVLRSendAuthenticationInfo::startProcessing function");
   return initiateSAI();;
}


bool CtxtVLRSendAuthenticationInfo::processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag)
{
   DLOG(0,0,"Start of CtxtVLRSendAuthenticationInfo::processMessage function");
   int l_UserDlgId;

   switch (p_MsgPtr->m_MsgType)
   {
      case MSG_TYPE_MAP:
         switch (((MapMsg*)p_MsgPtr)->m_MapMsgType)
         {
            case MAP_MSG_TYPE_COMMON:
               switch (((MapCommonMsg*)p_MsgPtr)->m_MapCommonMsgType)
               {
                  case MAP_CMN_OPEN_IND:
                     DLOG(0,0,"MAP_CMN_OPEN_IND received");
                     break;

                  case MAP_CMN_OPEN_CNF:
                     DLOG(0,0,"MAP_CMN_OPEN_CNF received");
                     break;

                  case MAP_CMN_DELIMITER_IND:
                     {
                        DLOG(0,0,"MAP_CMN_DELIMITER_IND received");
                        l_UserDlgId = p_MsgPtr->m_UserDlgId;
                        if (m_version == MAP_V2)
                        {
                           sendv2SAI(l_UserDlgId);
                        }
                        else if (m_version == MAP_V3)
                        {
                           sendv3SAI(l_UserDlgId);
                        }
                        else
                        {
                           printf("\nNot sending the sai");
                        }
                     }
                     break;

                  case MAP_CMN_CLOSE_IND:
                     DLOG(0,0,"MAP_CMN_CLOSE_IND received");
                     return true;
                     break;

                  case MAP_CMN_U_ABORT_IND:
                     DLOG(0,0,"MAP_CMN_U_ABORT_IND received");
                     break;

                  case MAP_CMN_P_ABORT_IND:
                     DLOG(0,0,"MAP_CMN_P_ABORT_IND received");
                     break;

                  case MAP_CMN_NOTICE_IND:
                     DLOG(0,0,"MAP_CMN_NOTICE_IND received");
                     break;

                  default:
                     DLOG(0,0,"Unknown Msg received");
                     break;
               }
               break;

            case MAP_MSG_TYPE_SPECIFIC:
               DLOG(0,0,"MAP_MSG_TYPE_SPECIFIC received");
               switch (((MapSpecificMsg*)p_MsgPtr)->m_MapSpecificEventType)
               {
                  case MAP_SPEC_EVENT_REQUEST:
                     DLOG(0,0,"MAP_SPEC_EVENT_REQUEST received");
                     break;

                  case MAP_SPEC_EVENT_INDICATION:
                     {
                        DLOG(0,0,"MAP_SPEC_EVENT_INDICATION received");
                        //MapCloseReq l_closeReq(((MapSpecificMsg*)p_MsgPtr)->m_UserDlgId);
                        //g_sc.sendMsg(this, &l_closeReq);
                     }
                     break;

                  case MAP_SPEC_EVENT_RESULT:
                     DLOG(0,0,"MAP_SPEC_EVENT_RESULT received");
                     break;
                  case MAP_SPEC_EVENT_CONFIRMATION:
                     DLOG(0,0,"MAP_SPEC_EVENT_CONFIRMATION received");

                     break;
                  case MAP_SPEC_EVENT_USER_ERROR:
                     DLOG(0,0,"MAP_SPEC_EVENT_USER_ERROR received");
                     switch (((MapUserError*)p_MsgPtr)->m_ErrorCode)
                     {
                        case MAP_ERROR_systemFailure:
                           printf("\nGot a User Error : System Failure Param ");
                           break;
                        case MAP_ERROR_UNKNOWN:
                           printf("\nGot a User Error : Unknown ");
                           break;
                        default:
                           printf("\nGot a Different error");
                           break;
                     }
                     break;

                  case MAP_SPEC_EVENT_PROV_ERROR:
                     {
                        DLOG(0,0,"MAP_SPEC_EVENT_PROV_ERROR received");
                        DLOG(0,0,"Closing the Dialogue");
                        MapCloseReq l_closeReq(((MapSpecificMsg*)p_MsgPtr)->m_UserDlgId);
                        g_sc.sendMsg(this, &l_closeReq);
                     }
                     break;

                  default:
                     ELOG(0,0,"ERROR!!! Default received");
                     break;

               }
               break;

            default:
               break;
         }
         break;

      case MSG_TYPE_DB:
         DLOG(0,0,"DB message received");
         break;

      default:
         DLOG(0,0,"Unknown message received");
         break;

   }
   return true;
}
