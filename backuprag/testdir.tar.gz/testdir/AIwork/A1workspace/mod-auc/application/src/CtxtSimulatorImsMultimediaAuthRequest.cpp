#include <CtxtSimulatorImsMultimediaAuthRequest.h>
#include <stdio.h>
#include <MapMessages.h>
#include <ServiceCoordinator.h>
#include <ExtendedServiceCoordinator.h>
#include <Logger.h>
#include <DataUnion.h>
#include <DbActiveObject.h>
#include <Utilities.h>
#include <AucSimConfigReader.h>

#include <DiameterConstants.h>
#include <DiametriqInterface.h>


CtxtSimulatorImsMultimediaAuthRequest :: CtxtSimulatorImsMultimediaAuthRequest()
{
   DLOG(0, 0, "CtxtSimulatorImsMultimediaAuthRequest::CtxtSimulatorImsMultimediaAuthRequest()");
}

CtxtSimulatorImsMultimediaAuthRequest :: ~CtxtSimulatorImsMultimediaAuthRequest()
{
   DLOG(0, 0, "CtxtSimulatorImsMultimediaAuthRequest::~CtxtSimulatorImsMultimediaAuthRequest()");
}

bool CtxtSimulatorImsMultimediaAuthRequest :: startProcessing()
{
   DLOG(0,0, "CtxtSimulatorImsMultimediaAuthRequest startprocessing");
   LLOG(0,0,"selfSimulate: MAR");
   unsigned int sIdx;
   string sessIdString;
   if(false == g_esc.allocateSession(DIAM_APP_ID_CX_DX, 
            sIdx, 
            sessIdString))
   {
      ELOG(0,1,"Unable to allocate a session");
      return false;
   }

   //cout<<"--- sessionIDint---"<<sIdx<<endl<<"--- sessionIDstring ---"<<sessIdString<<endl;

   DLOG(0,0,"selfSimulate: MAR");
   DiameterMsg l_test((char*)sessIdString.c_str(), DIAM_EVENT_REQUEST, DIAM_COMM_CODE_CX_DX_MAR_MAA);

   DLOG(0,0,"selfSimulate: MAR");
   //Prepare ULR Message
   Cx_rel_16::MultiMediaAuthRequest *l_mar = new Cx_rel_16::MultiMediaAuthRequest;
   l_mar->setSessionId(base::SessionId(sessIdString));
   l_mar->setSessionIndex(sIdx);
   DLOG(0,0,"selfSimulate: MAR");

   VendorSpecificApplicationId l_vendorSpecificApplicationId1;
   diameter::base::VendorId l_vendorId(10415);
   l_vendorSpecificApplicationId1.addVendorId(l_vendorId);
     
   AuthApplicationId l_authApplicationId(DIAM_APP_ID_CX_DX);
   l_vendorSpecificApplicationId1.setAuthApplicationId(l_authApplicationId);
   l_mar->setVendorSpecificApplicationId(l_vendorSpecificApplicationId1);
   DLOG(0,0,"selfSimulate: MAR");

   PublicIdentity l_pu("tel:447404006268@xyz.com");;
   l_mar->setPublicIdentity(l_pu);
   DLOG(0,0,"selfSimulate: MAR");

   AuthSessionState l_authSessionState(AuthSessionState::NO_STATE_MAINTAINED);
   l_mar->setAuthSessionState(l_authSessionState);

   DLOG(0,0,"selfSimulate: MAR");
   OriginHost l_originHost = base::OriginHost(g_OtherConfigData->m_dcd.m_originHost);
   l_mar->setOriginHost(l_originHost);

   DLOG(0,0,"selfSimulate: MAR");
   OriginRealm l_originRealm(g_OtherConfigData->m_dcd.m_originRealm);
   l_mar->setOriginRealm(l_originRealm);

   DLOG(0,0,"selfSimulate: MAR");
   DestinationRealm l_destinationRealm(g_OtherConfigData->m_dcd.m_destinationRealm);
   l_mar->setDestinationRealm(l_destinationRealm);

   DLOG(0,0,"selfSimulate: MAR");
   DestinationHost l_destinationHost(g_OtherConfigData->m_dcd.m_destinationHost);
   l_mar->setDestinationHost(l_destinationHost);

   DLOG(0,0,"selfSimulate: MAR");
   //diameter::base::UserName l_userName(g_LteMmSimConfigReaderObj->m_UlrImsi);
   //diameter::base::UserName l_userName("100447404006268@xy.com");
   //UserName l_userName(g_LteMmSimConfigReaderObj->m_UlrImsi);
   char imsi[30+1];
   memset(imsi,'\0',sizeof(imsi));
   snprintf(imsi,sizeof(imsi),"%s@xy.com",g_AucSimConfigReaderObj->m_simImsi);
   diameter::base::UserName l_userName(imsi);
   l_mar->setUserName(l_userName);
   DLOG(0,0,"selfSimulate: MAR");

   SIPNumberAuthItems l_snai(5);
   l_mar->setSIPNumberAuthItems(l_snai);
   ServerName l_sn("sip:192.168.151.95:42004");
   l_mar->setServerName(l_sn);
   DLOG(0,0,"selfSimulate: MAR");

   SIPAuthDataItem l_sadi;
   SIPItemNumber l_sin(1);
   l_sadi.setSIPItemNumber(l_sin);
   SIPAuthenticationScheme l_sas("Digest-AKAv1-MD5");
   //SIPAuthenticationScheme l_sas("Digest-MD5");
   l_sadi.setSIPAuthenticationScheme(l_sas);


#if 0
   SIPAuthenticate l_sa("XY");
	l_sadi.setSIPAuthenticate(l_sa);
   SIPAuthorization l_sauth("YZ");;
	l_sadi.setSIPAuthorization(l_sauth);
   SIPAuthenticationContext l_sac("SAC");
	l_sadi.setSIPAuthenticationContext(l_sac);

   ConfidentialityKey l_ck("CK");
	l_sadi.setConfidentialityKey(l_ck);
   IntegrityKey l_ik("IK");
	l_sadi.setIntegrityKey(l_ik);
   SIPDigestAuthenticate l_sda;
   DigestRealm l_dr("DR");
   DigestAlgorithm l_da("DA");
   DigestQoP l_dq("QOP");
   DigestHA1 l_dh("HA1");
   l_sda.setDigestRealm(l_dr);
   l_sda.setDigestAlgorithm(l_da);
   l_sda.setDigestQoP(l_dq);
   l_sda.setDigestHA1(l_dh);

	l_sadi.setSIPDigestAuthenticate(l_sda);
   FramedIPAddress l_fia("FIA");
	l_sadi.setFramedIPAddress(l_fia);
   FramedIPv6Prefix l_fip("FIP");
	//l_sadi.setFramedIPv6Prefix(l_fip);
   FramedInterfaceId l_fid(5);
	//l_sadi.setFramedInterfaceId(l_fid);

   LineIdentifier l_li("LI");
   l_sadi.addLineIdentifier(l_li);

#endif
   l_mar->setSIPAuthDataItem(l_sadi);
   l_test.m_cmd = l_mar;
   l_test.m_allocatedFlag = true;
   DLOG(0,0,"selfSimulate: MAR");

   g_esc.sendMsg(this, &l_test);

   return true;
}

bool CtxtSimulatorImsMultimediaAuthRequest :: processMessage(Msg *p_MsgPtr,bool &p_DeleteFlag)
{
   DLOG(0, 0, "Start of CtxtSimulatorImsMultimediaAuthRequest::processMsg function Delete flag is %d",p_DeleteFlag);
   MapSpecificMsg *l_specMsg = NULL;

   switch (p_MsgPtr->m_MsgType)
   {
      case MSG_TYPE_MAP:
         {
            DLOG(0,0,"MAP message received");
         }
         break;

      case MSG_TYPE_DIAMETER:
         {
            DiameterMsg *l_dm = (DiameterMsg*)p_MsgPtr;
            if(NULL == l_dm->m_cmd)
            {
               CLOG(0,0,"Received Diameter Message is NULL");
               break;
            }
            switch(l_dm->m_commandCode)
            {
               case DIAM_COMM_CODE_CX_DX_MAR_MAA:
                  {
                     LLOG(0,0,"Diameter Message MAR received");
                  }
                  break;
               default:
                  {
                     CLOG(0,0,"Unknown Message[%d] Received",l_dm->m_commandCode);
                  }
                  break;
            }
         }
         break;

      case MSG_TYPE_DB:
         {
            DLOG(0, 0, "DB message received");
            if(1 == ((DbQueryMsg*)p_MsgPtr)->m_DbQueryType)
            {
               LLOG(0,0,"DBRES: Type:1");
            }
            else
            {
               ELOG(0,0,"Unknown DB message");
            }
         }
         break;

      default:
         ELOG(0, 0, "Unknown message received");
         break;

   }
   return true;
}
