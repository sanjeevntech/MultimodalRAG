/*-------------------------------------------------------------------
 *          Example algorithms f1, f1*, f2, f3, f4, f5, f5*
 *-------------------------------------------------------------------
 *
 *  A sample implementation of the example 3GPP authentication and
 *  key agreement functions f1, f1*, f2, f3, f4, f5 and f5*.  This is
 *  a byte-oriented implementation of the functions, and of the block
 *  cipher kernel function Rijndael.
 *
 *  This has been coded for clarity, not necessarily for efficiency.
 *
 *  The functions f2, f3, f4 and f5 share the same inputs and have 
 *  been coded together as a single function.  f1, f1* and f5* are
 *  all coded separately.
 *
 *-----------------------------------------------------------------*/

#include <stdio.h>
#include <ByteMilenage.h>
#include <AucConfigReader.h>
#include <Logger.h>
#include <openssl/hmac.h>

ByteMilenage g_ByteMilenageObj;

//int rpl_snprintf(char *str, size_t size, const char *format,...);

void rotate_left(unsigned char *d, unsigned char *s, unsigned char bits) 
{    
   const unsigned char octetshifts = bits / 8;    
   const unsigned char bitshift = bits % 8;    
   const unsigned char bitsleft = (8 - bitshift);    
   const unsigned char lm = (1 << bitshift) - 1;    
   const unsigned char um = ~lm;    
   int i;     
   for (i = 0; i < 4; i++)    
   {        
      d[(i + 4 - octetshifts) % 4] =            ((s[i] << bitshift) & um) |             ((s[(i + 1) % 4] >> bitsleft) & lm);    
   } 
}

void rotate_right(unsigned char *d, unsigned char *s, unsigned char bits)
{
   const unsigned char octetshifts = bits / 8;
   const unsigned char bitshift = bits % 8;
   const unsigned char bitsleft = (8 - bitshift);
   const unsigned char lm = ((1 << bitshift) - 1)<<bitsleft;
   const unsigned char um = ~lm;
   int i;
   for (i = 0; i < 16; i++)
   {
      d[(i + 16 - octetshifts) % 16] =            ((s[i] >> bitshift) & um) |             ((s[(i - 1+16) % 16] << bitsleft) & lm);
   }
}

void printHexOnDebug(char *p_text, char *p_buffer, int p_length)
{
   //if(true == g_AucConfigReaderObj->m_DEBUG_MODE)
   if(NULL != g_fixed_rand)
   {
      LLOG_HEX(0,0,p_text, p_buffer, p_length);
   }
}


//void LLOG_HEX(0,0,char *p_text, u8 *p_buffer, int p_length);


/*--------- Operator Variant Algorithm Configuration Field --------*/

/*------- Insert your value of OP here -------*/
// commented to take own value
//u8 OP[16] = {0x63, 0xbf, 0xa5, 0x0e, 0xe6, 0x52, 0x33, 0x65,
//             0xff, 0x14, 0xc1, 0xf4, 0x5f, 0x88, 0x73, 0x7d};
/*------- Insert your value of OP here -------*/

//K:    465b5ce8 b199b49f aa5f0a2e e238a6bc 
//RAND: 23553cbe 9637a89d 218ae64d ae47bf35 
//OP:   cdc202d5 123e20f6 2b6d676a c72cb318 





/*--------------------------- prototypes --------------------------*/

void f1    ( u8 k[16], u8 rand[16], u8 sqn[6], u8 amf[2], short unsigned int R1_VALUE, u8 C1_VALUE[16],  
      u8 mac_a[8], u8 op_c[16] );
void f2345 ( u8 k[16], u8 rand[16], short unsigned int R2_VALUE, short unsigned int R3_VALUE, short unsigned int R4_VALUE, u8 C2_VALUE[16], u8 C3_VALUE[16], u8 C4_VALUE[16], 
      u8 res[8], u8 ck[16], u8 ik[16], u8 ak[6] );
void f1star( u8 k[16], u8 rand[16], u8 sqn[6], u8 amf[2], short unsigned int R1_VALUE, u8 C1_VALUE[16], 
      u8 mac_s[8] );
void f5star( u8 k[16], u8 rand[16], short unsigned int R5_VALUE, u8 C5_VALUE[16], 
      u8 ak[6] );
void ComputeOPc( u8 op_c[16] );
void RijndaelKeySchedule( u8 key[16] );
void RijndaelEncrypt( u8 input[16], u8 output[16] );

u8 g_rijndaelInput_tmp[16];

/*
   unsigned char  R1_VALUE = 64;
   unsigned char  R2_VALUE = 0 ;
   unsigned char  R3_VALUE = 32;
   unsigned char  R4_VALUE = 64;
   unsigned char  R5_VALUE = 96;

   unsigned char C1_VALUE[16]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
   unsigned char C2_VALUE[16]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1}; 
   unsigned char C3_VALUE[16]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2}; 
   unsigned char C4_VALUE[16]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,4}; 
   unsigned char C5_VALUE[16]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,8}; 
*/ 
/*
unsigned char  R1_VALUE = 0x2e;
unsigned char  R2_VALUE = 0x1b;
unsigned char  R3_VALUE = 0x25;
unsigned char  R4_VALUE = 0x45;
unsigned char  R5_VALUE = 0x69;

unsigned char C1_VALUE[16]={0xB6,0x19,0x02,0x0B,0xFB,0x3E,0xA7,0xA0,0xD6,0x89,0x5C,0x3B,0xCC,0x14,0x48,0x61};
unsigned char C2_VALUE[16]={0x38,0x25,0x43,0x6B,0xA8,0x14,0x18,0x36,0xAC,0x9C,0x53,0x08,0x55,0x54,0x34,0x1B};
unsigned char C3_VALUE[16]={0xC8,0x91,0x92,0x18,0xB8,0x89,0x2C,0xA9,0xEC,0xA4,0xA6,0x41,0x88,0x35,0x93,0xB3};
unsigned char C4_VALUE[16]={0xE6,0x41,0x6F,0x4C,0x06,0x73,0x62,0xA9,0xC6,0x25,0x8C,0x09,0x72,0xA8,0xAD,0x02};
unsigned char C5_VALUE[16]={0xEE,0x25,0x84,0x85,0xC7,0xEB,0xA3,0x45,0x0F,0xC7,0xF6,0xA4,0x50,0xA1,0x8E,0x92};
*/

/*-------------------------------------------------------------------
 *                            Algorithm f1
 *-------------------------------------------------------------------
 *
 *  Computes network authentication code MAC-A from key K, random
 *  challenge RAND, sequence number SQN and authentication management
 *  field AMF.
 *
 *-----------------------------------------------------------------*/

void f1    ( u8 k[16], u8 rand[16], u8 sqn[6], u8 amf[2], short unsigned int R1_VALUE, u8 C1_VALUE[16],  
      u8 mac_a[8], u8 op_c[16] )
{
   //u8 op_c[16];
   u8 temp[16];
   u8 in1[16];
   u8 out1[16];
   u8 rijndaelInput[16];
   u8 i;


   RijndaelKeySchedule( k );

   ComputeOPc( op_c );

   for (i=0; i<16; i++)
      rijndaelInput[i] = rand[i] ^ op_c[i];
   printHexOnDebug("Rijndael Input", (char *)rijndaelInput, 16);  
   RijndaelEncrypt( rijndaelInput, temp );
   printHexOnDebug("Rijndael Output", (char *)temp, 16); 

   for (i=0; i<6; i++)
   {
      in1[i]    = sqn[i];
      in1[i+8]  = sqn[i];
   }
   for (i=0; i<2; i++)
   {
      in1[i+6]  = amf[i];
      in1[i+14] = amf[i];
   }

   /* XOR op_c and in1, rotate by r1=64, and XOR *
    * on the constant c1 (which is all zeroes)   */

   if(1 == g_AucConfigReaderObj->m_Custom_RI_CI_Values)
   {
      //printHexOnDebug("R1 Value", (char *)&R1_VALUE, 1);
      //printHexOnDebug("C1 Value", (char *)C1_VALUE, 16);
      //DLOG_HEX(0,0,"Inside f1 C1 VAL ",C1_VALUE,16);

      //TLOG(0,0,"R1 value : %d", R1_VALUE);
      for (i=0; i<16; i++)
         rijndaelInput[(i + (16 - (R1_VALUE / 8)))% 16] = in1[i] ^ op_c[i];

      for (i=0; i<16; i++)
         rijndaelInput[i] ^= C1_VALUE[i];

   }
   else
   {
      TLOG(0,0,"Default R1 value : %d", 64);
      for (i=0; i<16; i++)
         rijndaelInput[(i+8) % 16] = in1[i] ^ op_c[i];
   }

   /* XOR on the value temp computed before */

   for (i=0; i<16; i++)
      rijndaelInput[i] ^= temp[i];

   printHexOnDebug("Rijndael Input", (char *)rijndaelInput, 16);  
   RijndaelEncrypt( rijndaelInput, out1 );
   printHexOnDebug("Rijndael Output", (char *)out1, 16);  
   for (i=0; i<16; i++)
      out1[i] ^= op_c[i];

   for (i=0; i<8; i++)
      mac_a[i] = out1[i];
   
   return;
} /* end of function f1 */



/*-------------------------------------------------------------------
 *                            Algorithms f2-f5
 *-------------------------------------------------------------------
 *
 *  Takes key K and random challenge RAND, and returns response RES,
 *  confidentiality key CK, integrity key IK and anonymity key AK.
 *
 *-----------------------------------------------------------------*/

void f2345 ( u8 k[16], u8 rand[16], short unsigned int R2_VALUE, short unsigned int R3_VALUE, short unsigned int R4_VALUE, u8 C2_VALUE[16], u8 C3_VALUE[16], u8 C4_VALUE[16], 
      u8 res[8], u8 ck[16], u8 ik[16], u8 ak[6] )
{
   u8 op_c[16];
   u8 temp[16];
   u8 out[16];
   u8 rijndaelInput[16];
   u8 i;


   RijndaelKeySchedule( k );

   ComputeOPc( op_c );

   for (i=0; i<16; i++)
      rijndaelInput[i] = rand[i] ^ op_c[i];
   printHexOnDebug("Rijndael Input", (char *)rijndaelInput, 16);  
   RijndaelEncrypt( rijndaelInput, temp );
   printHexOnDebug("Rijndael Output", (char *)temp, 16);  

   /* To obtain output block OUT2: XOR OPc and TEMP,    *
    * rotate by r2=0, and XOR on the constant c2 (which *
    * is all zeroes except that the last bit is 1).     */

   if(1 == g_AucConfigReaderObj->m_Custom_RI_CI_Values)
   {
      //printHexOnDebug("R2 Value", (char *)&R2_VALUE, 1);
      //printHexOnDebug("C2 Value", (char *)C2_VALUE, 16);
      //DLOG_HEX(0,0,"Inside f2345 C2 VAL ",C2_VALUE,16);
      
    
      //TLOG(0,0,"R2 value : %d", R2_VALUE);
      for (i=0; i<16; i++)
         rijndaelInput[(i + (16 - (R2_VALUE / 8))) % 16] = temp[i] ^ op_c[i];    
      
      for (i=0; i<16; i++)
         rijndaelInput[i] ^= C2_VALUE[i];

   }
   else
   {
      TLOG(0,0,"Default R2 value : %d", 0);
      for (i=0; i<16; i++)
         rijndaelInput[i] = temp[i] ^ op_c[i];

      rijndaelInput[15] ^= 1;
   }

   printHexOnDebug("Rijndael Input", (char *)rijndaelInput, 16);  
   RijndaelEncrypt( rijndaelInput, out );
   printHexOnDebug("Rijndael Output", (char *)out, 16);  
   for (i=0; i<16; i++)
      out[i] ^= op_c[i];

   for (i=0; i<8; i++)
      res[i] = out[i+8];
   for (i=0; i<6; i++)
      ak[i]  = out[i];

   /* To obtain output block OUT3: XOR OPc and TEMP,        *
    * rotate by r3=32, and XOR on the constant c3 (which    *
    * is all zeroes except that the next to last bit is 1). */


   if(1 == g_AucConfigReaderObj->m_Custom_RI_CI_Values)
   {
      //printHexOnDebug("R3 Value", (char *)&R3_VALUE, 1);
      //printHexOnDebug("C3 Value", (char *)C3_VALUE, 16);
      //DLOG_HEX(0,0,"Inside f2345 C3 VAL ",C3_VALUE,16);
      //TLOG(0,0,"R3 value : %d", R3_VALUE);
      for (i=0; i<16; i++)
         rijndaelInput[(i + (16 - (R3_VALUE / 8))) % 16] = temp[i] ^ op_c[i];    
      for (i=0; i<16; i++)
         rijndaelInput[i] ^= C3_VALUE[i];
   }
   else
   {
      TLOG(0,0,"Default R3 value : %d", 32);
      for (i=0; i<16; i++)
         rijndaelInput[(i+12) % 16] = temp[i] ^ op_c[i];
      rijndaelInput[15] ^= 2;
   }

   printHexOnDebug("Rijndael Input", (char *)rijndaelInput, 16);  
   RijndaelEncrypt( rijndaelInput, out );
   printHexOnDebug("Rijndael Output", (char *)out, 16);  
   for (i=0; i<16; i++)
      out[i] ^= op_c[i];

   for (i=0; i<16; i++)
      ck[i] = out[i];

   /* To obtain output block OUT4: XOR OPc and TEMP,         *
    * rotate by r4=64, and XOR on the constant c4 (which     *
    * is all zeroes except that the 2nd from last bit is 1). */

   if(1 == g_AucConfigReaderObj->m_Custom_RI_CI_Values)
   {
      //printHexOnDebug("R4 Value", (char *)&R4_VALUE, 1);
      //printHexOnDebug("C4 Value", (char *)C4_VALUE, 16);
      //DLOG_HEX(0,0,"Inside f2345 C4 VAL ",C4_VALUE,16);
      //TLOG(0,0,"R4 value : %d", R4_VALUE);
      for (i=0; i<16; i++)
         rijndaelInput[(i + (16 - (R4_VALUE / 8))) % 16] = temp[i] ^ op_c[i];    
      for (i=0; i<16; i++)
         rijndaelInput[i] ^= C4_VALUE[i];
   }
   else
   {
      TLOG(0,0,"Default R4 value : %d", 64);
      for (i=0; i<16; i++)
         rijndaelInput[(i+8) % 16] = temp[i] ^ op_c[i];
      rijndaelInput[15] ^= 4;
   }

   printHexOnDebug("Rijndael Input", (char *)rijndaelInput, 16);  
   RijndaelEncrypt( rijndaelInput, out );
   printHexOnDebug("Rijndael Output", (char *)out, 16);  
   for (i=0; i<16; i++)
      out[i] ^= op_c[i];

   for (i=0; i<16; i++)
      ik[i] = out[i];

   //char buff[512];
   //DLOG(0,0,"f2345:IN:k:   %s\n", Hex2Str(k, 16, NULL, sizeof(buff), buff));
   //DLOG(0,0,"f2345:IN:rand:%s\n", Hex2Str(rand, 16, NULL, sizeof(buff), buff));
   //DLOG(0,0,"f2345:OUT:res:%s\n", Hex2Str(res, 8, NULL, sizeof(buff), buff));
   //DLOG(0,0,"f2345:OUT:ck: %s\n", Hex2Str(ck, 16, NULL, sizeof(buff), buff));
   //DLOG(0,0,"f2345:OUT:ik: %s\n", Hex2Str(ik, 16, NULL, sizeof(buff), buff));


   return;
} /* end of function f2345 */


/*-------------------------------------------------------------------
 *                            Algorithm f1*
 *-------------------------------------------------------------------
 *
 *  Computes resynch authentication code MAC-S from key K, random
 *  challenge RAND, sequence number SQN and authentication management
 *  field AMF.
 *
 *-----------------------------------------------------------------*/

void f1star( u8 k[16], u8 rand[16], u8 sqn[6], u8 amf[2], short unsigned int R1_VALUE, u8 C1_VALUE[16], 
      u8 mac_s[8] )
{
   u8 op_c[16];
   u8 temp[16];
   u8 in1[16];
   u8 out1[16];
   u8 rijndaelInput[16];
   u8 i;

   RijndaelKeySchedule( k );

   ComputeOPc( op_c );

   for (i=0; i<16; i++)
      rijndaelInput[i] = rand[i] ^ op_c[i];
   printHexOnDebug("Rijndael Input", (char *)rijndaelInput, 16);  
   RijndaelEncrypt( rijndaelInput, temp );
   printHexOnDebug("Rijndael Output", (char *)temp, 16);  

   for (i=0; i<6; i++)
   {
      in1[i]    = sqn[i];
      in1[i+8]  = sqn[i];
   }
   for (i=0; i<2; i++)
   {
      in1[i+6]  = amf[i];
      in1[i+14] = amf[i];
   }

   /* XOR op_c and in1, rotate by r1=64, and XOR *
    * on the constant c1 (which is all zeroes)   */

   if(1 == g_AucConfigReaderObj->m_Custom_RI_CI_Values)
   {
      //printHexOnDebug("R1 Value", (char *)&R1_VALUE, 1);
      //printHexOnDebug("C1 Value", (char *)C1_VALUE, 16);
      //DLOG_HEX(0,0,"Inside f1star C1 VAL ",C1_VALUE,16);
      //TLOG(0,0,"R1 value : %d", R1_VALUE);
      for (i=0; i<16; i++)
         rijndaelInput[(i + (16 - (R1_VALUE / 8)))% 16] = in1[i] ^ op_c[i];
      for (i=0; i<16; i++)
         rijndaelInput[i] ^= C1_VALUE[i];
   }
   else
   {
      TLOG(0,0,"Default R1 value : %d", 64);
      for (i=0; i<16; i++)
       rijndaelInput[(i+8) % 16] = in1[i] ^ op_c[i];
   }

   /* XOR on the value temp computed before */

   for (i=0; i<16; i++)
      rijndaelInput[i] ^= temp[i];

   printHexOnDebug("Rijndael Input", (char *)rijndaelInput, 16);  
   RijndaelEncrypt( rijndaelInput, out1 );
   printHexOnDebug("Rijndael Output", (char *)out1, 16);  
   for (i=0; i<16; i++)
      out1[i] ^= op_c[i];

   for (i=0; i<8; i++)
      mac_s[i] = out1[i+8];


   //char buff[512];
   //DLOG(0,0,"f1star:OUT:mac_s: %s\n", Hex2Str(mac_s, 8, NULL, sizeof(buff), buff));
   return;
} /* end of function f1star */


/*-------------------------------------------------------------------
 *                            Algorithm f5*
 *-------------------------------------------------------------------
 *
 *  Takes key K and random challenge RAND, and returns resynch
 *  anonymity key AK.
 *
 *-----------------------------------------------------------------*/

void f5star( u8 k[16], u8 rand[16], short unsigned int R5_VALUE, u8 C5_VALUE[16], 
      u8 ak[6] )
{
   u8 op_c[16];
   u8 temp[16];
   u8 out[16];
   u8 rijndaelInput[16];
   u8 i;

   RijndaelKeySchedule( k );

   ComputeOPc( op_c );

   for (i=0; i<16; i++)
      rijndaelInput[i] = rand[i] ^ op_c[i];
   RijndaelEncrypt( rijndaelInput, temp );

   /* To obtain output block OUT5: XOR OPc and TEMP,         *
    * rotate by r5=96, and XOR on the constant c5 (which     *
    * is all zeroes except that the 3rd from last bit is 1). */

   if(1 == g_AucConfigReaderObj->m_Custom_RI_CI_Values)
   {
      //printHexOnDebug("R5 Value", (char *)&R5_VALUE, 1);
      //printHexOnDebug("C5 Value", (char *)C5_VALUE, 16);
      //DLOG_HEX(0,0,"Inside f5star C5 VAL ",C5_VALUE,16);
      //TLOG(0,0,"R5 value : %d", R5_VALUE);
      for (i=0; i<16; i++)
         rijndaelInput[(i + (16 - (R5_VALUE / 8))) % 16] = temp[i] ^ op_c[i];    
      for (i=0; i<16; i++)
         rijndaelInput[i] ^= C5_VALUE[i];
   }
   else
   {
      TLOG(0,0,"Default R5 value : %d", 96);
      for (i=0; i<16; i++)
         rijndaelInput[(i+4) % 16] = temp[i] ^ op_c[i];
      rijndaelInput[15] ^= 8;
   }

   RijndaelEncrypt( rijndaelInput, out );
   for (i=0; i<16; i++)
      out[i] ^= op_c[i];

   for (i=0; i<6; i++)
      ak[i] = out[i];


   //char buff[512];
   //DLOG(0,0,"f5star:OUT:ak: %s\n", Hex2Str(ak, 6, NULL, sizeof(buff), buff));

   return;
} /* end of function f5star */


/*-------------------------------------------------------------------
 *  Function to compute OPc from OP and K.  Assumes key schedule has
 already been performed.
 *-----------------------------------------------------------------*/

void ComputeOPc( u8 op_c[16] )
{
   u8 i;
  
   RijndaelEncrypt( g_ByteMilenageObj.m_OP, op_c );
   for (i=0; i<16; i++)
      op_c[i] ^= g_ByteMilenageObj.m_OP[i];
  
   //DLOG_HEX(0,0," Inside ComputeOPc OP_c value ",op_c,16);  
 
   return;
} /* end of function ComputeOPc */



/*-------------------- Rijndael round subkeys ---------------------*/
u8 roundKeys[11][4][4];

/*--------------------- Rijndael S box table ----------------------*/
u8 S[256] = {
   99,124,119,123,242,107,111,197, 48,  1,103, 43,254,215,171,118,
   202,130,201,125,250, 89, 71,240,173,212,162,175,156,164,114,192,
   183,253,147, 38, 54, 63,247,204, 52,165,229,241,113,216, 49, 21,
   4,199, 35,195, 24,150,  5,154,  7, 18,128,226,235, 39,178,117,
   9,131, 44, 26, 27,110, 90,160, 82, 59,214,179, 41,227, 47,132,
   83,209,  0,237, 32,252,177, 91,106,203,190, 57, 74, 76, 88,207,
   208,239,170,251, 67, 77, 51,133, 69,249,  2,127, 80, 60,159,168,
   81,163, 64,143,146,157, 56,245,188,182,218, 33, 16,255,243,210,
   205, 12, 19,236, 95,151, 68, 23,196,167,126, 61,100, 93, 25,115,
   96,129, 79,220, 34, 42,144,136, 70,238,184, 20,222, 94, 11,219,
   224, 50, 58, 10, 73,  6, 36, 92,194,211,172, 98,145,149,228,121,
   231,200, 55,109,141,213, 78,169,108, 86,244,234,101,122,174,  8,
   186,120, 37, 46, 28,166,180,198,232,221,116, 31, 75,189,139,138,
   112, 62,181,102, 72,  3,246, 14, 97, 53, 87,185,134,193, 29,158,
   225,248,152, 17,105,217,142,148,155, 30,135,233,206, 85, 40,223,
   140,161,137, 13,191,230, 66,104, 65,153, 45, 15,176, 84,187, 22,
};

/*------- This array does the multiplication by x in GF(2^8) ------*/
u8 Xtime[256] = {
   0,  2,  4,  6,  8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30,
   32, 34, 36, 38, 40, 42, 44, 46, 48, 50, 52, 54, 56, 58, 60, 62,
   64, 66, 68, 70, 72, 74, 76, 78, 80, 82, 84, 86, 88, 90, 92, 94,
   96, 98,100,102,104,106,108,110,112,114,116,118,120,122,124,126,
   128,130,132,134,136,138,140,142,144,146,148,150,152,154,156,158,
   160,162,164,166,168,170,172,174,176,178,180,182,184,186,188,190,
   192,194,196,198,200,202,204,206,208,210,212,214,216,218,220,222,
   224,226,228,230,232,234,236,238,240,242,244,246,248,250,252,254,
   27, 25, 31, 29, 19, 17, 23, 21, 11,  9, 15, 13,  3,  1,  7,  5,
   59, 57, 63, 61, 51, 49, 55, 53, 43, 41, 47, 45, 35, 33, 39, 37,
   91, 89, 95, 93, 83, 81, 87, 85, 75, 73, 79, 77, 67, 65, 71, 69,
   123,121,127,125,115,113,119,117,107,105,111,109, 99, 97,103,101,
   155,153,159,157,147,145,151,149,139,137,143,141,131,129,135,133,
   187,185,191,189,179,177,183,181,171,169,175,173,163,161,167,165,
   219,217,223,221,211,209,215,213,203,201,207,205,195,193,199,197,
   251,249,255,253,243,241,247,245,235,233,239,237,227,225,231,229
};


/*-------------------------------------------------------------------
 *  Rijndael key schedule function.  Takes 16-byte key and creates 
 *  all Rijndael's internal subkeys ready for encryption.
 *-----------------------------------------------------------------*/

void RijndaelKeySchedule( u8 key[16] )
{
   u8 roundConst;
   int i, j;

   /* first round key equals key */
   for (i=0; i<16; i++)
      roundKeys[0][i & 0x03][i>>2] = key[i];

   roundConst = 1;

   /* now calculate round keys */
   for (i=1; i<11; i++)
   {
      roundKeys[i][0][0] = S[roundKeys[i-1][1][3]]
         ^ roundKeys[i-1][0][0] ^ roundConst;
      roundKeys[i][1][0] = S[roundKeys[i-1][2][3]]
         ^ roundKeys[i-1][1][0];
      roundKeys[i][2][0] = S[roundKeys[i-1][3][3]]
         ^ roundKeys[i-1][2][0];
      roundKeys[i][3][0] = S[roundKeys[i-1][0][3]]
         ^ roundKeys[i-1][3][0];

      for (j=0; j<4; j++)
      {
         roundKeys[i][j][1] = roundKeys[i-1][j][1] ^ roundKeys[i][j][0];
         roundKeys[i][j][2] = roundKeys[i-1][j][2] ^ roundKeys[i][j][1];
         roundKeys[i][j][3] = roundKeys[i-1][j][3] ^ roundKeys[i][j][2];
      }

      /* update round constant */
      roundConst = Xtime[roundConst];
   }

   return;
} /* end of function RijndaelKeySchedule */


/* Round key addition function */
void KeyAdd(u8 state[4][4], u8 p_roundKeys[11][4][4], int round)
{
   int i, j;

   for (i=0; i<4; i++)
      for (j=0; j<4; j++)
         state[i][j] ^= p_roundKeys[round][i][j];

   return;
}


/* Byte substitution transformation */
int ByteSub(u8 state[4][4])
{
   int i, j;

   for (i=0; i<4; i++)
      for (j=0; j<4; j++)
         state[i][j] = S[state[i][j]];

   return 0;
}


/* Row shift transformation */
void ShiftRow(u8 state[4][4])
{
   u8 temp;

   /* left rotate row 1 by 1 */
   temp = state[1][0];
   state[1][0] = state[1][1];
   state[1][1] = state[1][2];
   state[1][2] = state[1][3];
   state[1][3] = temp;

   /* left rotate row 2 by 2 */
   temp = state[2][0];
   state[2][0] = state[2][2];
   state[2][2] = temp;
   temp = state[2][1];
   state[2][1] = state[2][3];
   state[2][3] = temp;

   /* left rotate row 3 by 3 */
   temp = state[3][0];
   state[3][0] = state[3][3];
   state[3][3] = state[3][2];
   state[3][2] = state[3][1];
   state[3][1] = temp;

   return;
}


/* MixColumn transformation*/
void MixColumn(u8 state[4][4])
{
   u8 temp, tmp, tmp0;
   int i;

   /* do one column at a time */
   for (i=0; i<4;i++)
   {
      temp = state[0][i] ^ state[1][i] ^ state[2][i] ^ state[3][i];
      tmp0 = state[0][i];

      /* Xtime array does multiply by x in GF2^8 */
      tmp = Xtime[state[0][i] ^ state[1][i]];
      state[0][i] ^= temp ^ tmp;

      tmp = Xtime[state[1][i] ^ state[2][i]];
      state[1][i] ^= temp ^ tmp;

      tmp = Xtime[state[2][i] ^ state[3][i]];
      state[2][i] ^= temp ^ tmp;

      tmp = Xtime[state[3][i] ^ tmp0];
      state[3][i] ^= temp ^ tmp;
   }

   return;
}


/*-------------------------------------------------------------------
 *  Rijndael encryption function.  Takes 16-byte input and creates 
 *  16-byte output (using round keys already derived from 16-byte 
 *  key).
 *-----------------------------------------------------------------*/

void RijndaelEncrypt( u8 input[16], u8 output[16] )
{
   u8 state[4][4];
   int i, r;

   /* initialise state array from input byte string */
   for (i=0; i<16; i++)
      state[i & 0x3][i>>2] = input[i];

   /* add first round_key */
   KeyAdd(state, roundKeys, 0);

   /* do lots of full rounds */
   for (r=1; r<=9; r++)
   {
      ByteSub(state);
      ShiftRow(state);
      MixColumn(state);
      KeyAdd(state, roundKeys, r);
   }

   /* final round */
   ByteSub(state);
   ShiftRow(state);
   KeyAdd(state, roundKeys, r);

   /* produce output byte string from state array */
   for (i=0; i<16; i++)
   {
      output[i] = state[i & 0x3][i>>2];
   }

   return;
} /* end of function RijndaelEncrypt */


bool calculateAuts(u8 amf[2], u8 k[16], u8 rand[16], u8 sqn[6], short unsigned int R1_VALUE, u8 C1_VALUE[16], short unsigned int R5_VALUE, u8 C5_VALUE[16] , u8 auts[14])
{
   u8 ak[6];//, conc[6];

   printHexOnDebug("calculateAuts: AMF  ", (char*)amf, 2);
   printHexOnDebug("calculateAuts: K    ", (char*)k, 16);
   printHexOnDebug("calculateAuts: RAND ", (char*)rand, 16);
   printHexOnDebug("calculateAuts: SQN  ", (char*)sqn, 6);

   f5star(k, rand, R5_VALUE, C5_VALUE, ak);
   printHexOnDebug("calculateAuts: AK   ", (char*)ak, 6);

   for (int i=0; i<6; i++)
      auts[i] = sqn[i] ^ ak[i];
   printHexOnDebug("calculateAuts: conc ", (char*)auts, 6);

   u8 mac_s[8];
   f1star(k, rand, sqn, amf, R1_VALUE, C1_VALUE,  mac_s);
   printHexOnDebug("calculateAuts: MAC_S", (char*)mac_s, 8);

   memcpy(auts+6, mac_s, 8);

   printHexOnDebug("calculateAuts: AUTS ", (char*)auts, 14);
   return true;
}

bool resynchronizeFunc(u8 amf[2], u8 k[16], u8 rand[16], u8 auts[14], u8 sqn[6], short unsigned int R1_VALUE, u8 C1_VALUE[16], short unsigned int R5_VALUE, u8 C5_VALUE[16] )
{
   u8 ak[6];

   printHexOnDebug("resynchronizeFunc: amf", (char*)amf, 2);
   printHexOnDebug("resynchronizeFunc: K", (char*)k, 16);
   printHexOnDebug("resynchronizeFunc: rand", (char*)rand, 16);
   printHexOnDebug("resynchronizeFunc: auts", (char*)auts, 14);


   //f2345(k, rand, res, ck, ik, ak);
   f5star(k, rand, R5_VALUE, C5_VALUE, ak);
   printHexOnDebug("Resynchronized AK", (char*)ak, 6);
   for (int i=0; i<6; i++)
      sqn[i] = auts[i] ^ ak[i];
   printHexOnDebug("Resynchronized SQN", (char*)sqn, 6);

   u8 l_calculated_auts[14];
   calculateAuts(amf, k, rand, sqn, R1_VALUE, C1_VALUE, R5_VALUE, C5_VALUE, l_calculated_auts);

   for (int i=0; i<14; i++)
   {
      if (auts[i] != l_calculated_auts[i])
      {
         return true; // Changed temporarily on 17-Feb-2011 to check
      }
   }
   return true;
}

bool calculateMilenageVectors (u8 k[16], u8 rand[16], int sresDerivFuncNo, u8 sqn[6], u8 amf[2], short unsigned int R1_VALUE, u8 C1_VALUE[16], short unsigned int R2_VALUE, short unsigned int R3_VALUE, short unsigned int R4_VALUE, u8 C2_VALUE[16], u8 C3_VALUE[16], u8 C4_VALUE[16], u8 op_c[16], u8 res[8], u8 ck[16], u8 ik[16], u8 ak[6], u8 kc[8], u8 sres[4], u8 mac_a[8], u8 autn[16])
{
   f2345(k, rand, R2_VALUE, R3_VALUE, R4_VALUE, C2_VALUE, C3_VALUE, C4_VALUE, res, ck, ik, ak);

   f1(k, rand, sqn, amf, R1_VALUE, C1_VALUE, mac_a, op_c);

   for (int i = 0; i < 8; i++)
      kc[i] = ck[i] ^ ck[i + 8] ^ ik[i] ^ ik[i + 8];

   if (2 == sresDerivFuncNo)
   {
      memcpy(sres, res, 4);
   }
   else
   {
      for (int i = 0; i < 4; i++)
         sres[i] = res[i] ^ res[i + 4];
   }
   for (int i = 0; i < 6; i++)
      autn[i] = sqn[i] ^ ak[i];
   memcpy(autn + 6, amf, 2);
   memcpy(autn + 8, mac_a, 8);

   char buff[512];
   DLOG(0,0,"f2345:IN:autn:%s\n", Hex2Str(autn, 16, NULL, sizeof(buff), buff));

   return true;
}

ByteMilenage::ByteMilenage()
{
}

ByteMilenage::~ByteMilenage()
{
}

bool openssl_hmac(u8 p_key[32], u8 p_data[14], u8 p_kasme[32]) 
{
   // Be careful of the length of string with the choosen hash engine. SHA1 needed 20 characters.
   // Change the length accordingly with your choosen hash engine.     
   unsigned char* result;
   unsigned int len = 32; //TODO: but KASME is only 16 bytes?

   result = (unsigned char*)malloc(sizeof(char) * len);

   HMAC_CTX ctx;
   HMAC_CTX_init(&ctx);

   LLOG_HEX(0,0,"KEY", p_key, 32);
   LLOG_HEX(0,0,"DATA", p_data, 14);

   // Using sha1 hash engine here.
   // You may use other hash engines. e.g EVP_md5(), EVP_sha224, EVP_sha512, etc
   HMAC_Init_ex(&ctx, p_key, 32, EVP_sha256(), NULL);
   HMAC_Update(&ctx, p_data, 14);
   HMAC_Final(&ctx, result, &len);
   HMAC_CTX_cleanup(&ctx);

   TLOG(0,0,"final len is %d", len);
   //printf("\nHMAC digest: ");

   for (int i = 0; i < 32; i++)
   {
      //printf("%02x", (unsigned int)result[i]);
      p_kasme[i]=result[i];
   }

   LLOG_HEX(0,0,"KASME", result, len);

   free(result);

   return true;
}

bool calculateKASME(u8 p_k1[16], u8 p_k2[16], u8 p_fc, u8 p_snId[3], u8 p_autn[16], u8 p_kasme[32])
{
   //Preparation of S
   //FC = 0x10,
   //P0 = SN id,
   //L0 = length of SN id (i.e. 0x00 0x03),
   //P1 = SQN . AK
   //L1 = length of SQN . AK (i.e. 0x00 0x06) 

   u8 l_k[32];
   memcpy(l_k, p_k1, 16);
   memcpy(l_k+16, p_k2, 16);
   u8 l_s[14];
   l_s[0] = p_fc;
   memcpy(l_s+1, p_snId, 3); //1,2,3
   l_s[4]=0x00;
   l_s[5]=0x03;
   for (int i = 0; i < 6; i++)   //6-11
      l_s[6+i] = p_autn[i];
   l_s[12]=0x00;
   l_s[13]=0x06;
   return openssl_hmac(l_k, l_s, p_kasme);
}

void calculateSqn(unsigned char p_sqn[6], unsigned int p_seq1, unsigned int p_seq2, unsigned int p_ind)
{
   struct SqnStruct l_struct;
   l_struct.m_seq1 = p_seq1;
   l_struct.m_seq2 = p_seq2;
   l_struct.m_ind = p_ind;
#ifdef Linux
   unsigned char l_temp[6];
   memcpy(l_temp, &l_struct, 6);
   p_sqn[0] = l_temp[5];
   p_sqn[1] = l_temp[4];
   p_sqn[2] = l_temp[3];
   p_sqn[3] = l_temp[2];
   p_sqn[4] = l_temp[1];
   p_sqn[5] = l_temp[0];
#else
   memcpy(p_sqn, &l_struct, 6);
#endif
   return;
}


void decodeSqn(unsigned char p_sqn[6], unsigned int *p_seq1, unsigned int *p_seq2, unsigned int *p_ind)
{
   struct SqnStruct l_struct;
#ifdef Linux
   unsigned char l_temp[6];
   l_temp[0] = p_sqn[5];
   l_temp[1] = p_sqn[4];
   l_temp[2] = p_sqn[3];
   l_temp[3] = p_sqn[2];
   l_temp[4] = p_sqn[1];
   l_temp[5] = p_sqn[0];
   memcpy(&l_struct, l_temp, 6);
#else
   memcpy(&l_struct, p_sqn, 6);
#endif
   *p_seq1 = l_struct.m_seq1;
   *p_seq2 = l_struct.m_seq2;
   *p_ind = l_struct.m_ind;
   return;
}

char* Hex2Str(u8* buffIn, int lenIn, char* strSeparator, int lenOut, char* buffOut)
{
   int  i;
   signed int   available = (signed int)lenOut;
   signed int   printed;
   u8* pIn  = buffIn;
   char* pOut = buffOut;

   buffOut[0] = '\0';

   if (strSeparator == NULL)
   {
      strSeparator = "";
   }

   for (i=0; i<lenIn; i++)
   {
      printed = snprintf(pOut, available, "%02x%s", *pIn++, strSeparator);
      if (printed < 0 || printed >= available)  /*if truncated*/
      {
         if (lenOut > 0)
         {
            buffOut[lenOut - 1] = '\0';
         }
         return buffOut;
      }
      available -= printed;
      pOut      += printed;
   }

   /* Remove separator after last converted byte.
    */
   pOut -= strlen(strSeparator);
   if (pOut >= buffOut)
   {
      *pOut = '\0';
   }
   return buffOut;
}
