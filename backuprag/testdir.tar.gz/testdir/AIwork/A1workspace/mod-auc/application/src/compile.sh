/usr/sfw/bin/gcc -m64 test.cpp  -I/opt/sfp/64bit/openssl-0.9.8m/include/ -L/opt/sfp/64bit/openssl-0.9.8m/lib/ -lcrypto -lstdc++
export LD_LIBRARY_PATH=/opt/sfp/64bit/openssl-0.9.8m/lib/:/opt/ulcm/library
