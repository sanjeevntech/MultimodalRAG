#include <openssl/des.h>
#include <openssl/aes.h>
#include <openssl/evp.h>
#include <openssl/err.h>
#include <openssl/conf.h>
#include <iostream>
#include <stdio.h>
#include <string>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>


void Cipher(unsigned char* in, int len, unsigned char* outData, int encdec, unsigned char *key, unsigned char *ivchar)
{
   char out[255]="";
   char dec[255]="";
   int i;

   DES_key_schedule ks1,ks2,ks3;
   DES_cblock iv;
   memcpy(iv, ivchar, 8);
   printf("\niv \n");
   for(int i=0; i<8; i++)
   {
      printf(" %02x", iv[i]);
   }
   printf("\n\n");

   printf("\nki key\n");
   for(int i=0; i<24; i++)
   {
      printf(" %02x", key[i]);
   }
   printf("\n\n");
   DES_set_key((const_DES_cblock *)key, &ks1);
   DES_set_key((const_DES_cblock *)(key+8), &ks2);
   DES_set_key((const_DES_cblock *)(key+16), &ks3);

   printf("\nin\n");
   for(int i=0; i<16; i++)
   {
      printf(" %02x", in[i]);
   }
   printf("\n\n");

   DES_ede3_cbc_encrypt((const unsigned char*)in, (unsigned char*)out, len, &ks1, &ks2, &ks3, &iv, encdec);

#if 1
   for(i=0; i<len; i++)
   {
      outData[i] = out[i]&0x00ff;
   }
#endif


}

void handleErrors()
{
   printf("\nhandleErrors called.\n");
   return;
}

int encrypt(unsigned char *plaintext, int plaintext_len, unsigned char *key, unsigned char *iv, unsigned char *ciphertext)
{
  EVP_CIPHER_CTX *ctx;

  int len;

  int ciphertext_len;

  /* Create and initialise the context */
  if(!(ctx = EVP_CIPHER_CTX_new())) handleErrors();

  /* Initialise the encryption operation. IMPORTANT - ensure you use a key
   * and IV size appropriate for your cipher
   * In this example we are using 256 bit AES (i.e. a 256 bit key). The
   * IV size for *most* modes is the same as the block size. For AES this
   * is 128 bits */
  if(1 != EVP_EncryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, key, iv))
    handleErrors();

  /* Provide the message to be encrypted, and obtain the encrypted output.
   * EVP_EncryptUpdate can be called multiple times if necessary
   */
  if(1 != EVP_EncryptUpdate(ctx, ciphertext, &len, plaintext, plaintext_len))
    handleErrors();
  ciphertext_len = len;

  /* Finalise the encryption. Further ciphertext bytes may be written at
   * this stage.
   */
  if(1 != EVP_EncryptFinal_ex(ctx, ciphertext + len, &len)) handleErrors();
  ciphertext_len += len;

  /* Clean up */
  EVP_CIPHER_CTX_free(ctx);

  return ciphertext_len;
}


int main()
{
   unsigned char ivchar[] = {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
   unsigned char key1[] = {0x31,0x35,0x31,0x31,0x31,0x31,0x31,0x31,0x32,0x32,0x32,0x32,0x32,0x32,0x32,0x32,0x31,0x31,0x31,0x31,0x31,0x31,0x31,0x31};
   unsigned char in[] = {0x31,0x32,0x33,0x31,0x31,0x31,0x31,0x31,0x31,0x31,0x31,0x31,0x31,0x31,0x31,0x31};
   unsigned char dec[20]="";
   unsigned char dec1[20]="";
   memset(dec, '\0', sizeof(dec));
   memset(dec1, '\0', sizeof(dec1));
   //Codec l_c;
#if 1
   Cipher(in, 16, dec, DES_ENCRYPT, key1, ivchar);

   printf("\nEncrypted\n");
   for(int i=0; i<20; i++)
   {
      printf(" %02x", dec[i]);
   }
   printf("\n\n");
#endif

   //unsigned char newin[]={0x86, 0x01, 0xa9, 0x1e, 0x08, 0x6f, 0x91, 0xf6, 0x5e, 0x71, 0x30, 0x8d, 0xdf, 0x28, 0x58, 0x78};

   //unsigned char ivchar1[] = {0x01,0x02,0x00,0x00,0x00,0x00,0x00,0x00};
   //unsigned char key2[] = {0x31,0x35,0x31,0x31,0x31,0x31,0x31,0x31,0x32,0x32,0x32,0x32,0x32,0x32,0x32,0x32,0x31,0x31,0x31,0x31,0x31,0x31,0x31,0x31};

   Cipher(dec, 16, dec1, DES_DECRYPT, key1, ivchar);
   printf("\nDecrypted\n");
   for(int i=0; i<16; i++)
   {
      printf(" %02x", dec1[i]);
   }
   printf("\n\n");

   unsigned char key[] = "01234567890123456789012345678901";
   unsigned char iv[] = "01234567890123456";
   //unsigned char plaintext[] ="The quick brown fox jumps over the lazy dog";
   unsigned char plaintext[] ="0123456789123456";
   unsigned char ciphertext[128];
   int ciphertext_len;
   //ERR_load_crypto_strings();
   //OpenSSL_add_all_algorithms();
   //OPENSSL_config(NULL);
   ciphertext_len = encrypt(plaintext, strlen((char*)plaintext), key, iv,ciphertext);
   printf("Length is %d Ciphertext is:\n", ciphertext_len);
   BIO_dump_fp(stdout, (const char*)ciphertext, ciphertext_len);

   unsigned char ciphertext2[128];
   //int decryptedtext_len2, ciphertext_len2;
   AES_KEY wctx; 
   AES_set_encrypt_key(key, 256, &wctx); 
   AES_encrypt(plaintext, ciphertext2, &wctx);   
   //AES_cbc_encrypt(plaintext, ciphertext2, 16, &wctx, iv, AES_ENCRYPT);   

   printf("\n");
   for(int l_i=0; l_i<32; l_i++)
      printf(" %02x", ciphertext2[l_i]);
}


///usr/sfw/bin/gcc -o des Codec.cpp -I/opt/sfp/64bit/openssl-0.9.8m/include/ -L/opt/sfp/64bit/openssl-0.9.8m/lib/ -lcrypto -lstdc++  -I. -m64
