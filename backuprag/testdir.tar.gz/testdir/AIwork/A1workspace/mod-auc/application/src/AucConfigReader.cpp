#include <Logger.h>
#include <AucConfigReader.h>
#include <stdlib.h>
#include <SubsProfileData.h>

extern int g_EmergencyFlag; 
extern u8 g_test_rand[]; 

AucConfigReader *g_AucConfigReaderObj=NULL;
char *g_fixed_rand = NULL;


AucConfigReader::AucConfigReader()
{
   m_MAX_NUM_OF_TOTAL_VECTORS=0;
   m_MAX_NUM_OF_VECTORS_IN_A_CHUNK=0;
   m_TestFlag=0;
   m_TestRandFlag=0;
   m_SQN_DISTRIBUTION_FLAG=0;
   m_SWX_REQUESTING_NODE_VALIDATION_FLAG=0;
}

AucConfigReader::~AucConfigReader()
{
}


bool AucConfigReader::readData()
{
   time_t l_time = time(NULL);
   g_fixed_rand = getenv("FIXED_RAND_VALUE");
   if(NULL != g_fixed_rand)
   {
      CLOG(0,0,"Random Value is hardcoded for testing");
   }
   else
   {
      srand((unsigned int)l_time);
      DLOG(0,0, "SRAND function is used");
   }

   //string l_auc = readValue(m_DataString, "AUC");
   string l_auc = m_DataString;

   string temp = readValue (l_auc, "TEST_RAND");
   if(0 == temp.size())
   {
      m_RandFlag=0;
      LLOG(0,1,"Test rand is not present");
   }
   else if(32 == temp.size())
   {
      WLOG(0,1,"Test rand present. Please use this only for testing.");
      m_RandFlag=1;
      atohx((char*)g_test_rand, (char*)temp.c_str());
   }
   else
   {
      ELOG(0,1,"Test RAND should be 32 digits (16 bytes)");
   }

   if( false == readInteger(l_auc, "MAX_NUM_OF_VECTORS_IN_A_CHUNK", m_MAX_NUM_OF_VECTORS_IN_A_CHUNK, 1, 3))
      return false;

   if( false == readInteger(l_auc, "MAX_NUM_OF_TOTAL_VECTORS", m_MAX_NUM_OF_TOTAL_VECTORS, 1, 5))
      return false;


   temp = readValue (l_auc, "DEBUG_MODE");
   if(0 == temp.size())
   {
      m_DEBUG_MODE = false;
      LLOG(0,1,"Debug Mode is false");
   }
   else
   {
      int l_debug_mode;
      if( false == readInteger(l_auc, "DEBUG_MODE", l_debug_mode, 0, 1))
         return false;
      m_DEBUG_MODE = l_debug_mode;
   }

   temp = readValue (l_auc, "TEST_FLAG");
   if(0 == temp.size())
   {
      m_TestFlag = 0;
      LLOG(0,1,"Test flag is 0");
   }
   else
   {
      if( false == readInteger(l_auc, "TEST_FLAG", m_TestFlag, 0, 1))
         return false;
   }

   char *l_testFlag = getenv("TEST_RAND_FLAG");
   if(NULL != l_testFlag)
   {   
      m_TestRandFlag = atoi(l_testFlag);
      CLOG(0,0,"\n RAND TEST FLAG [%d] \n", m_TestRandFlag);
   }
   else
   {
      DLOG(0,0,"\n RAND TEST FLAG is not enabled");
   }   

   if( false == readInteger(l_auc, "MAP3_SUCCESSIVE_INVOKE_TIMEOUT", m_MAP3_SUCCESSIVE_INVOKE_TIMEOUT, 1, 600))
      return false;

   m_MAP3_LOCKED_SUBSCRIBER_RETRY_COUNT=0;
   m_MAP3_LOCKED_SUBSCRIBER_RETRY_TIMER=0;

   if (m_MAP3_LOCKED_SUBSCRIBER_RETRY_COUNT > 1)
   {
      if( false == readInteger(l_auc, "MAP3_LOCKED_SUBSCRIBER_RETRY_TIMER", m_MAP3_LOCKED_SUBSCRIBER_RETRY_TIMER, 1, 1000000))
         return false;
   }

   if( false == readInteger(l_auc, "MULTI_IMSI_VALIDATION_FLAG", m_MULTI_IMSI_VALIDATION_FLAG, 0, 1))
      return false;

   if( false == readInteger(l_auc, "SUBS_BARRED_VALIDATION_FLAG", m_SUBS_BARRED_VALIDATION_FLAG, 0, 1))
      return false;

   if( false == readInteger(l_auc, "REQUESTING_NODE_VALIDATION_FLAG", m_REQUESTING_NODE_VALIDATION_FLAG, 0, 1))
      return false;

   if( false == readInteger(l_auc, "LTE_REQUESTING_NODE_VALIDATION_FLAG", m_LTE_REQUESTING_NODE_VALIDATION_FLAG, 0, 1))
      return false;

   string l_MAP3_QUIN_OR_TRIPLETS = readValue(l_auc, "MAP3_QUIN_OR_TRIPLETS");
   if (0 == l_MAP3_QUIN_OR_TRIPLETS.size())
   {
      CLOG(0,1,"MAP3_QUIN_OR_TRIPLETS not present");
      snprintf(m_errorDesc, sizeof(m_errorDesc), "%s", "MAP3_QUIN_OR_TRIPLETS not present");
      return false;
   }
   m_MAP3_QUIN_OR_TRIPLETS=l_MAP3_QUIN_OR_TRIPLETS[0];

   if ( ('Q' == m_MAP3_QUIN_OR_TRIPLETS)  || ('T' == m_MAP3_QUIN_OR_TRIPLETS) )
   {
      LLOG(0,0,"m_MAP3_QUIN_OR_TRIPLETS %c", m_MAP3_QUIN_OR_TRIPLETS);
   }
   else
   {
      CLOG(0,0,"Invalid m_MAP3_QUIN_OR_TRIPLETS [%c]", m_MAP3_QUIN_OR_TRIPLETS);
      snprintf(m_errorDesc, sizeof(m_errorDesc), "Invalid m_MAP3_QUIN_OR_TRIPLETS [%c]", m_MAP3_QUIN_OR_TRIPLETS);
      return false;
   }

   if( false == readInteger(l_auc, "CUSTOM_RI_CI_VALUES", m_Custom_RI_CI_Values, 0, 1))
      return false;

   DLOG(0,0,"CUSTOM_RI_CI_VALUES[%d]",m_Custom_RI_CI_Values);

   if( false == readInteger(l_auc, "MAP3_DOWNGRADE_VECTORS", m_MAP3_DOWNGRADE_VECTORS, 0, 4))
      return false;

   if( false == readInteger(l_auc, "CONGESTION_MAP3_DOWNGRADE_VECTORS", m_CONGESTION_MAP3_DOWNGRADE_VECTORS, 0, 4))
      return false;

   if( false == readInteger(l_auc, "SAI_AIR_MEMCACHED_FLAG", m_SAI_AIR_MemcachedFlag, 0, 1))
      return false;

   DLOG(0,0,"SAI_AIR_MemcachedFlag[%d]",m_SAI_AIR_MemcachedFlag);

   if( false == readInteger(l_auc, "MAR_MEMCACHED_FLAG", m_MAR_MemcachedFlag, 0, 1))
      return false;

   DLOG(0,0,"MAR_MEMCACHED_FLAG[%d]",m_MAR_MemcachedFlag);


   if( false == readInteger(l_auc, "ADD_NETWORK_ID_IN_MAA_CUSTOM_AVP_FLAG", m_ADD_NETWORK_ID_IN_MAA_CUSTOM_AVP_FLAG, 0, 1))
      return false;

   DLOG(0,0,"ADD_NETWORK_ID_IN_MAA_CUSTOM_AVP_FLAG[%d]", m_ADD_NETWORK_ID_IN_MAA_CUSTOM_AVP_FLAG);
   
   if( false == readInteger(l_auc, "SQN_DISTRIBUTION_FLAG", m_SQN_DISTRIBUTION_FLAG, 0, 1))
      return false;
   
   DLOG(0,0,"SQN_DISTRIBUTION_FLAG[%d]", m_SQN_DISTRIBUTION_FLAG);

   if( false == readInteger(l_auc, "SWX_REQUESTING_NODE_VALIDATION_FLAG", m_SWX_REQUESTING_NODE_VALIDATION_FLAG, 0, 1))
      return false;

   DLOG(0,0,"SWX_REQUESTING_NODE_VALIDATION_FLAG[%d]", m_SWX_REQUESTING_NODE_VALIDATION_FLAG);

   m_ConstantRandomFlag=1;

   m_derivedObjectInitializedFlag=true;
   return true;
}

void AucConfigReader::printConfigData(char *p_output)
{
   LLOG(0,1,"AucConfigReader::printConfigData called.");
   if(NULL != g_spdPtr)
   {
      g_EmergencyFlag = g_spdPtr->m_MsisdnPrefReplaceStruct.m_CongestionEmergencyFlag;
   }

   sprintf(p_output, "%s:%d\t%s:%d\t%s:%d\t%s:%d\t%s:%d\n\t%s:%d\t%s:%c\t%s:%d\t%s:%d\t\n\t%s:%d\t%s:%d\t%s:%d\t\n\t%s:%d\t%s:%d\t%s:%d\t%s:%d\t%s:%d",
         "MaxNumOfVectorsInAChunk", m_MAX_NUM_OF_VECTORS_IN_A_CHUNK,
         "MaxNumOfTotalVectors",    m_MAX_NUM_OF_TOTAL_VECTORS,
         "SuccessiveInvokeTimeout", m_MAP3_SUCCESSIVE_INVOKE_TIMEOUT,
         "MultiImsiValidationFlag", m_MULTI_IMSI_VALIDATION_FLAG,
         "SubsBarredValidationFlag", m_SUBS_BARRED_VALIDATION_FLAG,
         "RequestingNodeValidationFlag", m_REQUESTING_NODE_VALIDATION_FLAG,
         "Map3QuintupletsOrTripletsFlag", m_MAP3_QUIN_OR_TRIPLETS,
         "Map3DowngradeVectors",m_MAP3_DOWNGRADE_VECTORS,
         "CONGESTION_MAP3_DOWNGRADE_VECTORS",m_CONGESTION_MAP3_DOWNGRADE_VECTORS,
         "Congestion_Emergency_Flag",g_EmergencyFlag,
         "LteRequestingNodeValidationFlag", m_LTE_REQUESTING_NODE_VALIDATION_FLAG,
         "SAI_AIR_MemcachedFlag", m_SAI_AIR_MemcachedFlag,
         "ADD_NETWORK_ID_IN_MAA_CUSTOM_AVP_FLAG", m_ADD_NETWORK_ID_IN_MAA_CUSTOM_AVP_FLAG,
         "MAR_MEMCACHED_FLAG",m_MAR_MemcachedFlag,
         "SQN_DISTRIBUTION_FLAG", m_SQN_DISTRIBUTION_FLAG,
         "SWX_REQUESTING_NODE_VALIDATION_FLAG", m_SWX_REQUESTING_NODE_VALIDATION_FLAG,
         "CUSTOM_RI_CI_VALUES",m_Custom_RI_CI_Values
         );

   LLOG(0,1,"AucConfigReader::printConfigData done.");
}

