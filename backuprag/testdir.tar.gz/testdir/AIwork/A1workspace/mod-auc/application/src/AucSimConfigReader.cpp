#include <Logger.h>
#include <AucSimConfigReader.h>
#include <stdlib.h>


AucSimConfigReader *g_AucSimConfigReaderObj=NULL;


AucSimConfigReader::AucSimConfigReader()
{
 memset(m_simImsi, '\0', 17);
 m_CxSwxFlag = 0;
}

AucSimConfigReader::~AucSimConfigReader()
{
}


bool AucSimConfigReader::readData()
{
       //printf("\nCalling AucConfigReader::readData()");
   string l_auc = readValue(m_DataString, "AUCSIM");

   string l_SIM_VERSION = readValue(l_auc, "SIM_VERSION");
   m_simVersion=atoi(l_SIM_VERSION.c_str());
   printf("\nm_simVersion %d\n", m_simVersion);

   string l_SIM_IMSI = readValue(l_auc, "SIM_IMSI");
   strcpy(m_simImsi, l_SIM_IMSI.c_str());

   string l_CxSwxFlag = readValue(l_auc, "CX_OR_SWX_FLAG");
   m_CxSwxFlag = atoi(l_CxSwxFlag.c_str());

   return true;
}

void AucSimConfigReader::printConfigData(char *p_output)
{
}

