#include <CtxtSimulatorImsSwxMultimediaAuthRequest.h>
#include <stdio.h>
#include <MapMessages.h>
#include <ServiceCoordinator.h>
#include <ExtendedServiceCoordinator.h>
#include <Logger.h>
#include <DataUnion.h>
#include <DbActiveObject.h>
#include <Utilities.h>
#include <AucSimConfigReader.h>

#include <DiameterConstants.h>
#include <DiametriqInterface.h>


CtxtSimulatorImsSwxMultimediaAuthRequest :: CtxtSimulatorImsSwxMultimediaAuthRequest()
{
   DLOG(0, 0, "CtxtSimulatorImsSwxMultimediaAuthRequest::CtxtSimulatorImsSwxMultimediaAuthRequest()");
}

CtxtSimulatorImsSwxMultimediaAuthRequest :: ~CtxtSimulatorImsSwxMultimediaAuthRequest()
{
   DLOG(0, 0, "CtxtSimulatorImsSwxMultimediaAuthRequest::~CtxtSimulatorImsSwxMultimediaAuthRequest()");
}

bool CtxtSimulatorImsSwxMultimediaAuthRequest :: startProcessing()
{
   DLOG(0,0, "CtxtSimulatorImsSwxMultimediaAuthRequest startprocessing");
   LLOG(0,0,"selfSimulate: Swx MAR");
   unsigned int sIdx;
   string sessIdString;
   if(false == g_esc.allocateSession(DIAM_APP_ID_SWX, 
            sIdx, 
            sessIdString))
   {
      ELOG(0,1,"Unable to allocate a session");
      return false;
   }

   //cout<<"--- sessionIDint---"<<sIdx<<endl<<"--- sessionIDstring ---"<<sessIdString<<endl;

   DLOG(0,0,"selfSimulate: MAR");
   DiameterMsg l_test((char*)sessIdString.c_str(), DIAM_EVENT_REQUEST,DIAM_COMM_CODE_CX_DX_MAR_MAA);

   DLOG(0,0,"selfSimulate: MAR");
   //Prepare ULR Message
   SWx_rel_18::MultiMediaAuthRequest *l_mar = new SWx_rel_18::MultiMediaAuthRequest;
   l_mar->setSessionId(base::SessionId(sessIdString));
   l_mar->setSessionIndex(sIdx);
   DLOG(0,0,"selfSimulate: MAR");

   VendorSpecificApplicationId l_vendorSpecificApplicationId1;
   diameter::base::VendorId l_vendorId(10415);
   l_vendorSpecificApplicationId1.addVendorId(l_vendorId);
     
   AuthApplicationId l_authApplicationId(DIAM_APP_ID_SWX);
   l_vendorSpecificApplicationId1.setAuthApplicationId(l_authApplicationId);
   l_mar->setVendorSpecificApplicationId(l_vendorSpecificApplicationId1);
   DLOG(0,0,"selfSimulate: MAR");

   //PublicIdentity l_pu("tel:447404006268@xyz.com");
   /*PublicIdentity l_pu("tel:912222222225@xyz.com");
   l_mar->setPublicIdentity(l_pu);
   DLOG(0,0,"selfSimulate: MAR");*/

   AuthSessionState l_authSessionState(AuthSessionState::NO_STATE_MAINTAINED);
   l_mar->setAuthSessionState(l_authSessionState);

   DLOG(0,0,"selfSimulate: MAR");
   OriginHost l_originHost = base::OriginHost(g_OtherConfigData->m_dcd.m_originHost);
   l_mar->setOriginHost(l_originHost);

   DLOG(0,0,"selfSimulate: MAR");
   OriginRealm l_originRealm(g_OtherConfigData->m_dcd.m_originRealm);
   l_mar->setOriginRealm(l_originRealm);

   DLOG(0,0,"selfSimulate: MAR");
   DestinationRealm l_destinationRealm(g_OtherConfigData->m_dcd.m_destinationRealm);
   l_mar->setDestinationRealm(l_destinationRealm);

   DLOG(0,0,"selfSimulate: MAR");
   DestinationHost l_destinationHost(g_OtherConfigData->m_dcd.m_destinationHost);
   l_mar->setDestinationHost(l_destinationHost);

   DLOG(0,0,"selfSimulate: MAR");
   //diameter::base::UserName l_userName(g_LteMmSimConfigReaderObj->m_UlrImsi);
   //diameter::base::UserName l_userName("100447404006268@xy.com");
   //UserName l_userName(g_LteMmSimConfigReaderObj->m_UlrImsi);
   diameter::base::UserName l_userName(g_AucSimConfigReaderObj->m_simImsi);
   l_mar->setUserName(l_userName);
   DLOG(0,0,"selfSimulate: MAR");


   VisitedNetworkIdentifier l_vni("TestNetworkID");
   l_mar->setVisitedNetworkIdentifier(l_vni);
      

   SIPNumberAuthItems l_snai(1);
   l_mar->setSIPNumberAuthItems(l_snai);
   /*ServerName l_sn("sip:192.168.151.95:42004");
   l_mar->setServerName(l_sn);
   DLOG(0,0,"selfSimulate: MAR");*/

   SIPAuthDataItem l_sadi;
   SIPItemNumber l_sin(1);
   l_sadi.setSIPItemNumber(l_sin);
   SIPAuthenticationScheme l_sas("EAP-AKA");
   //SIPAuthenticationScheme l_sas("Digest-MD5");
   l_sadi.setSIPAuthenticationScheme(l_sas);


#if 0
   SIPAuthenticate l_sa("XY");
	l_sadi.setSIPAuthenticate(l_sa);
   SIPAuthorization l_sauth("YZ");;
	l_sadi.setSIPAuthorization(l_sauth);
   SIPAuthenticationContext l_sac("SAC");
	l_sadi.setSIPAuthenticationContext(l_sac);

   ConfidentialityKey l_ck("CK");
	l_sadi.setConfidentialityKey(l_ck);
   IntegrityKey l_ik("IK");
	l_sadi.setIntegrityKey(l_ik);
   SIPDigestAuthenticate l_sda;
   DigestRealm l_dr("DR");
   DigestAlgorithm l_da("DA");
   DigestQoP l_dq("QOP");
   DigestHA1 l_dh("HA1");
   l_sda.setDigestRealm(l_dr);
   l_sda.setDigestAlgorithm(l_da);
   l_sda.setDigestQoP(l_dq);
   l_sda.setDigestHA1(l_dh);

	l_sadi.setSIPDigestAuthenticate(l_sda);
   FramedIPAddress l_fia("FIA");
	l_sadi.setFramedIPAddress(l_fia);
   FramedIPv6Prefix l_fip("FIP");
	//l_sadi.setFramedIPv6Prefix(l_fip);
   FramedInterfaceId l_fid(5);
	//l_sadi.setFramedInterfaceId(l_fid);

   LineIdentifier l_li("LI");
   l_sadi.addLineIdentifier(l_li);

#endif
   l_mar->setSIPAuthDataItem(l_sadi);

   /*ProxyInfo l_proxyInfo;
   base::ProxyHost l_proxyHost("worker2.swx01.epdgswx.mnc026.mcc234.3gppnetwork.org");
   l_proxyInfo.setProxyHost(l_proxyHost);
   base::ProxyState l_proxyState("03bbc8355555555555555558");
   l_proxyInfo.setProxyState(l_proxyState);
   l_mar->addProxyInfo(l_proxyInfo);*/

   //AAAFailureIndication l_aaa(0);
   //l_mar->setAAAFailureIndication(l_aaa);


   l_test.m_cmd = l_mar;
   l_test.m_allocatedFlag = true;
   DLOG(0,0,"selfSimulate: MAR");

   g_esc.sendMsg(this, &l_test);

   return true;
}

bool CtxtSimulatorImsSwxMultimediaAuthRequest :: processMessage(Msg *p_MsgPtr,bool &p_DeleteFlag)
{
   DLOG(0, 0, "Start of CtxtSimulatorImsSwxMultimediaAuthRequest::processMsg function Delete flag is %d",p_DeleteFlag);
   MapSpecificMsg *l_specMsg = NULL;

   switch (p_MsgPtr->m_MsgType)
   {
      case MSG_TYPE_MAP:
         {
            DLOG(0,0,"MAP message received");
         }
         break;

      case MSG_TYPE_DIAMETER:
         {
            DiameterMsg *l_dm = (DiameterMsg*)p_MsgPtr;
            if(NULL == l_dm->m_cmd)
            {
               CLOG(0,0,"Received Diameter Message is NULL");
               break;
            }
            switch(l_dm->m_commandCode)
            {
               case DIAM_COMM_CODE_CX_DX_MAR_MAA:
                  {
                     LLOG(0,0,"Diameter Message MAR received");
                  }
                  break;
               default:
                  {
                     CLOG(0,0,"Unknown Message[%d] Received",l_dm->m_commandCode);
                  }
                  break;
            }
         }
         break;

      case MSG_TYPE_DB:
         {
            DLOG(0, 0, "DB message received");
            if(1 == ((DbQueryMsg*)p_MsgPtr)->m_DbQueryType)
            {
               LLOG(0,0,"DBRES: Type:1");
            }
            else
            {
               ELOG(0,0,"Unknown DB message");
            }
         }
         break;

      default:
         ELOG(0, 0, "Unknown message received");
         break;

   }
   return true;
}
