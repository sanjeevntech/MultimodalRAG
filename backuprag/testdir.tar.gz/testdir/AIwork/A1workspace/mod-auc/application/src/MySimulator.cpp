#include <MySimulator.h>
#include <diameter/s6a_r10/AuthenticationInformation.h>
#include <diameter/s6a_r10/S6a_r10AVP.h>
#include <Logger.h>

#include <DiameterMessages.h>
#include <ExtendedServiceCoordinator.h>
#include <DiameterConstants.h>

#include <ExtendedServiceCoordinator.h>

using namespace diameter::base;
using namespace diameter::s6a_r10;




MySimulator::MySimulator()
{
}

MySimulator::~MySimulator()
{
}

bool MySimulator::getMessage(int p_opCode, Msg **p_msgPtr, Msg *p_ReqMsgPtr)
{
   switch(p_opCode)
   {
      case DIAM_COMM_CODE_S6A_S6D_AIR_AIA:
         {
            LLOG(0,0,"selfSimulate: AIR");
            unsigned int sIdx;
            string sessIdString;
            if(false == g_esc.allocateSession(DIAM_APP_ID_S6A_S6D, 
                     sIdx, 
                     sessIdString))
            {
               ELOG(0,1,"Unable to allocate a session");
               return false;
            }
            *p_msgPtr = new DiameterMsg((char*)sessIdString.c_str(), DIAM_EVENT_REQUEST, DIAM_COMM_CODE_S6A_S6D_AIR_AIA);
            DiameterMsg *l_test = (DiameterMsg*)(*p_msgPtr);

            //Prepare a AIR Message
            diameter::s6a_r10::AuthenticationInformationRequest *l_air = new diameter::s6a_r10::AuthenticationInformationRequest;
            //l_air->setSessionId(diameter::base::SessionId(sessIdString));
            l_air->setSessionIndex(sIdx);


            AuthSessionState authSessionState(AuthSessionState::NO_STATE_MAINTAINED);
            l_air->setAuthSessionState(authSessionState);

            OriginHost originHost = diameter::base::OriginHost("origin.mme");
            l_air->setOriginHost(originHost);

            OriginRealm originRealm("OriginRealm");
            l_air->setOriginRealm(originRealm);

            DestinationRealm destinationRealm("DestinationRealm");
            l_air->setDestinationRealm(destinationRealm);

            UserName userName("110000000000009");
            l_air->setUserName(userName);

            RequestedEUTRANAuthenticationInfo REAInfo; 
            NumberOfRequestedVectors nofreqvect1(10);
            REAInfo.setNumberOfRequestedVectors(nofreqvect1);
            ImmediateResponsePreferred	imrespref1(2);
            REAInfo.setImmediateResponsePreferred(imrespref1);

            ReSynchronizationInfo rsinfo1("987654321098765432109876543210");
            REAInfo.setReSynchronizationInfo(rsinfo1);

            l_air->setRequestedEUTRANAuthenticationInfo(REAInfo);

            RequestedUTRANGERANAuthenticationInfo RUGAInfo;
            NumberOfRequestedVectors nofreqvect2(11);
            RUGAInfo.setNumberOfRequestedVectors(nofreqvect2);
            ImmediateResponsePreferred  imrespref2(3);
            //RUGAInfo.setImmediateResponsePreferred(imrespref2);

            ReSynchronizationInfo rsinfo2("123456789012345678901234567890");
            //RUGAInfo.setReSynchronizationInfo(rsinfo2);

            //l_air->setRequestedUTRANGERANAuthenticationInfo(RUGAInfo);
            VisitedPLMNId  visPLMNid("visitedPLMNID123");
            l_air->setVisitedPLMNId(visPLMNid);

            l_test->m_cmd = l_air;
            l_test->m_allocatedFlag = true;
         }
         break;
      default:
         {
            LLOG(0,0,"selfSimulate: Default");
         }
         break;
   }
   return true;
}
