
/* Result Sets Interface */
#ifndef SQL_CRSR
#  define SQL_CRSR
  struct sql_cursor
  {
    unsigned int curocn;
    void *ptr1;
    void *ptr2;
    unsigned int magic;
  };
  typedef struct sql_cursor sql_cursor;
  typedef struct sql_cursor SQL_CURSOR;
#endif /* SQL_CRSR */

/* Thread Safety */
typedef void * sql_context;
typedef void * SQL_CONTEXT;

/* Object support */
struct sqltvn
{
  unsigned char *tvnvsn; 
  unsigned short tvnvsnl; 
  unsigned char *tvnnm;
  unsigned short tvnnml; 
  unsigned char *tvnsnm;
  unsigned short tvnsnml;
};
typedef struct sqltvn sqltvn;

struct sqladts
{
  unsigned int adtvsn; 
  unsigned short adtmode; 
  unsigned short adtnum;  
  sqltvn adttvn[1];       
};
typedef struct sqladts sqladts;

static struct sqladts sqladt = {
  1,1,0,
};

/* Binding to PL/SQL Records */
struct sqltdss
{
  unsigned int tdsvsn; 
  unsigned short tdsnum; 
  unsigned char *tdsval[1]; 
};
typedef struct sqltdss sqltdss;
static struct sqltdss sqltds =
{
  1,
  0,
};

/* File name & Package Name */
struct sqlcxp
{
  unsigned short fillen;
           char  filnam[16];
};
static const struct sqlcxp sqlfpn =
{
    15,
    "AucDbQueries.pc"
};


static unsigned int sqlctx = 2324387;


static struct sqlexd {
   unsigned long  sqlvsn;
   unsigned int   arrsiz;
   unsigned int   iters;
   unsigned int   offset;
   unsigned short selerr;
   unsigned short sqlety;
   unsigned int   occurs;
      const short *cud;
   unsigned char  *sqlest;
      const char  *stmt;
   sqladts *sqladtp;
   sqltdss *sqltdsp;
   unsigned char  **sqphsv;
   unsigned long  *sqphsl;
            int   *sqphss;
            short **sqpind;
            int   *sqpins;
   unsigned long  *sqparm;
   unsigned long  **sqparc;
   unsigned short  *sqpadto;
   unsigned short  *sqptdso;
   unsigned int   sqlcmax;
   unsigned int   sqlcmin;
   unsigned int   sqlcincr;
   unsigned int   sqlctimeout;
   unsigned int   sqlcnowait;
            int   sqfoff;
   unsigned int   sqcmod;
   unsigned int   sqfmod;
   unsigned char  *sqhstv[56];
   unsigned long  sqhstl[56];
            int   sqhsts[56];
            short *sqindv[56];
            int   sqinds[56];
   unsigned long  sqharm[56];
   unsigned long  *sqharc[56];
   unsigned short  sqadto[56];
   unsigned short  sqtdso[56];
} sqlstm = {12,56};

// Prototypes
extern "C" {
  void sqlcxt (void **, unsigned int *,
               struct sqlexd *, const struct sqlcxp *);
  void sqlcx2t(void **, unsigned int *,
               struct sqlexd *, const struct sqlcxp *);
  void sqlbuft(void **, char *);
  void sqlgs2t(void **, char *);
  void sqlorat(void **, unsigned int *, void *);
}

// Forms Interface
static const int IAPSUCC = 0;
static const int IAPFAIL = 1403;
static const int IAPFTL  = 535;
extern "C" { void sqliem(unsigned char *, signed int *); }

typedef struct { unsigned short len; unsigned char arr[1]; } VARCHAR;
typedef struct { unsigned short len; unsigned char arr[1]; } varchar;

/* cud (compilation unit data) array */
static const short sqlcud0[] =
{12,4138,1,0,0,
5,0,0,0,0,0,56,345,0,0,1,1,0,1,0,3,102,0,0,
24,0,0,1,1302,0,6,347,0,0,56,56,0,1,0,1,9,0,0,1,9,0,0,1,3,0,0,1,3,0,0,1,3,0,0,
1,4,0,0,1,3,0,0,1,3,0,0,1,3,0,0,1,9,0,0,1,9,0,0,1,9,0,0,1,9,0,0,1,9,0,0,1,9,0,
0,1,9,0,0,1,3,0,0,2,9,0,0,2,9,0,0,2,95,0,0,2,95,0,0,2,3,0,0,2,3,0,0,2,95,0,0,2,
95,0,0,2,95,0,0,2,3,0,0,2,9,0,0,2,3,0,0,2,9,0,0,2,9,0,0,2,3,0,0,2,9,0,0,2,3,0,
0,2,3,0,0,2,95,0,0,2,3,0,0,2,3,0,0,2,3,0,0,2,3,0,0,2,102,0,0,2,3,0,0,2,68,0,0,
2,68,0,0,2,68,0,0,2,68,0,0,2,68,0,0,2,95,0,0,2,95,0,0,2,95,0,0,2,95,0,0,2,95,0,
0,2,3,0,0,2,3,0,0,2,3,0,0,2,9,0,0,
263,0,0,0,0,0,13,464,0,0,5,1,0,1,0,1,102,0,0,2,9,0,0,2,9,0,0,2,3,0,0,2,9,0,0,
298,0,0,0,0,0,78,490,0,0,1,1,0,1,0,3,102,0,0,
317,0,0,2,119,0,6,657,0,0,5,5,0,1,0,1,9,0,0,1,95,0,0,1,3,0,0,2,3,0,0,2,9,0,0,
};


#include <AucDbQueries.h>
#include <stdio.h>
#include <strings.h>
#include <sqlca.h>
#include <sqlda.h>
#include <Logger.h>


OssTrigData2::OssTrigData2()
{
   memset(m_rowId, '\0', sizeof(m_rowId));
   memset(m_transId, '\0', sizeof(m_transId));
   memset(m_transXml, '\0', sizeof(m_transXml));
   m_opCode = 0;
}

OssTrigData2::~OssTrigData2()
{
}

RetrieveSubsAuthData::RetrieveSubsAuthData()
{
   DLOG(0,1,"RetrieveSubsAuthData :cons:");
   DLOG(0,1,"Data RetrieveSubsAuth:%d DbQueryMsg: %d Msg: %d", 
         sizeof(RetrieveSubsAuthData),
         sizeof(DbQueryMsg),
         sizeof(Msg));
   //Inputs
   memset(m_imsi, '\0', 16+1);

   m_resynchFlag=false; // default to false
   memset(m_resynchRand, '\0', 16);
   memset(m_resynchAuts, '\0', 14);
   m_requestNode=REQUEST_NODE_VLR;
   memset(m_OrigAddr, '\0', 20+1);

   //Outputs
   memset(m_k, '\0', 16);
   memset(m_first_k, '\0', 16);
   memset(m_k_key, '\0', 8);
   memset(m_op, '\0', 16);  
   memset(m_sqn, '\0', 6);  
   memset(m_amf, '\0', 2);
   memset(m_rand, '\0', 16);
   memset(m_msisdn, '\0', 16+1);

   m_imsiType=-1;

   m_subsType=0;
   memset(m_accountId, '\0', sizeof(m_accountId));

   m_auth_algo=-1;
   m_ki_enc_algo=-1;
   m_ki_enc_mode=0;
   memset(m_hlrAddress, '\0', 20);
   m_errCode=-99;
   m_msgVersion=0;

   m_retryTimer=0;
   m_retryCount=0;
   m_multi_imsi_validation_flag=0; 
   m_subs_barred_validation_flag=0;
   m_requesting_node_validation_flag=0;
   memset(m_mmeHost,  '\0', sizeof(m_mmeHost));
   memset(m_mmeRealm, '\0', sizeof(m_mmeRealm));
   memset(m_hssHost,  '\0', sizeof(m_hssHost));
   memset(m_hssRealm, '\0', sizeof(m_hssRealm));
   m_s6aRelease=0;
   memset(m_primaryImsi, '\0', sizeof(m_primaryImsi));
   m_nam=7;
   m_networkId = 0;
   m_AucTemplateId = 0;
   m_RoamPartnerId = 0;
   m_curCount = 0;
   m_Customized_RC_Flag=0;
   m_R1=0;
   m_R2=0;
   m_R3=0;
   m_R4=0;
   m_R5=0;
   memset(&m_C1, '\0', sizeof(m_C1));
   memset(&m_C2, '\0', sizeof(m_C2));
   memset(&m_C3, '\0', sizeof(m_C3));
   memset(&m_C4, '\0', sizeof(m_C4));
   memset(&m_C5, '\0', sizeof(m_C5));
   m_ossTriggerDataCount = 0;
   memset(m_scscfHost, '\0', sizeof(m_scscfHost));
   memset(m_scscfRealm, '\0', sizeof(m_scscfRealm));
   memset(m_scscfName, '\0', sizeof(m_scscfName));
   memset(m_requestNodeStr, '\0', sizeof(m_requestNodeStr));
   memset(&m_ossTriggerDataArray, '\0', sizeof(m_ossTriggerDataArray));
   memset(m_visitedNwkID_DB,'\0',sizeof(m_visitedNwkID_DB));
   m_AAA_Failure_Indication_DB = -1;
   m_mappedErrCode = 0;
   m_imsProfId = 0;
   DLOG(0,1,"RetrieveSubsAuthData end of constrcutor");
}

RetrieveSubsAuthData::~RetrieveSubsAuthData()
{
   DLOG(0,1,"RetrieveSubsAuthData :des:");
}


typedef struct my_raw1
{
   int len;
   unsigned char buf[32];
} my_raw;
/* EXEC SQL TYPE my_raw IS LONG VARRAW(32); */ 


bool RetrieveSubsAuthData::executeQuery(void *p_conn)
{
   struct sqlca sqlca;
   TLOG(0,0,"RetrieveSubsAuthData::executeQuery start for imsi[%s]...", m_imsi);

   /* EXEC SQL BEGIN DECLARE SECTION; */ 

   //Inputs
   /* VARCHAR l_imsi[20]; */ 
struct { unsigned short len; unsigned char arr[20]; } l_imsi;

   //Outputs
   my_raw l_sqn;
   my_raw l_op;
   my_raw l_ki;
   my_raw l_ki_key;
   my_raw l_ki_init_vector;
   int    l_ki_enc_mode;
   my_raw l_amf;
   my_raw l_rand;
   /* VARCHAR l_accountId[20+1]; */ 
struct { unsigned short len; unsigned char arr[21]; } l_accountId;

   /* VARCHAR l_msisdn[16]; */ 
struct { unsigned short len; unsigned char arr[16]; } l_msisdn;

   int l_accFlag;
   int l_errCode;
   /* VARCHAR l_errMsg[200]; */ 
struct { unsigned short len; unsigned char arr[200]; } l_errMsg;

   int l_ki_enc_algo;
   int l_auth_algo;
   /* VARCHAR l_hlrAdd[20]; */ 
struct { unsigned short len; unsigned char arr[20]; } l_hlrAdd;

   int l_reqNode;
   int l_msgVersion;
   /* VARCHAR l_origNode[20]; */ 
struct { unsigned short len; unsigned char arr[20]; } l_origNode;

   int l_retryCount;
   float l_sleepInterval;
   int l_multi_imsi_validation_flag;
   int l_subs_barred_validation_flag;
   int l_req_node_validation_flag;
   int l_imsiType;
   /* VARCHAR l_mmeHost[100+1]; */ 
struct { unsigned short len; unsigned char arr[101]; } l_mmeHost;

   /* VARCHAR l_mmeRealm[100+1]; */ 
struct { unsigned short len; unsigned char arr[101]; } l_mmeRealm;

   /* VARCHAR l_hssHost[100+1]; */ 
struct { unsigned short len; unsigned char arr[101]; } l_hssHost;

   /* VARCHAR l_hssRealm[100+1]; */ 
struct { unsigned short len; unsigned char arr[101]; } l_hssRealm;

   /* VARCHAR l_scscfRealm[100+1]; */ 
struct { unsigned short len; unsigned char arr[101]; } l_scscfRealm;

   /* VARCHAR l_scscfHost[100+1]; */ 
struct { unsigned short len; unsigned char arr[101]; } l_scscfHost;

   /* VARCHAR l_scscfName[100+1]; */ 
struct { unsigned short len; unsigned char arr[101]; } l_scscfName;

   /* VARCHAR l_requestNode[30+1]; */ 
struct { unsigned short len; unsigned char arr[31]; } l_requestNode;

   /* VARCHAR l_visitedNwkID_DB[100+1]; */ 
struct { unsigned short len; unsigned char arr[101]; } l_visitedNwkID_DB;
   
   int l_AAA_Failure_Indication_DB;
   int l_s6aRelease;
   /* VARCHAR l_primaryImsi[15+1]; */ 
struct { unsigned short len; unsigned char arr[16]; } l_primaryImsi;

   int    l_nam;
   int l_networkId_DB;
   int l_AucTemplateId_DB;
   int l_RoamPartnerId_DB;
   int l_curCount_DB;
   int l_ossTriggerDataCount_DB;
   sql_cursor l_cur_DB;
   int l_Customized_RC_Flag;
   short unsigned int l_R1;
   short unsigned int l_R2;
   short unsigned int l_R3;
   short unsigned int l_R4;
   short unsigned int l_R5;
   my_raw l_C1;
   my_raw l_C2;
   my_raw l_C3;
   my_raw l_C4;
   my_raw l_C5;
   /* VARCHAR           l_rowid[30+1]; */ 
struct { unsigned short len; unsigned char arr[31]; } l_rowid;
     
   /* VARCHAR           l_transId[20+1]; */ 
struct { unsigned short len; unsigned char arr[21]; } l_transId;
   
   int               l_opCode;          
   /* VARCHAR           l_transXml[8000+1]; */ 
struct { unsigned short len; unsigned char arr[8001]; } l_transXml;

   int l_mappedErrCode;
   int l_imsProfId;
   short  l_indArr0;
   short  l_indArr1;
   short  l_indArr2;
   short  l_indArr3;
   short  l_indArr4;
   short  l_indArr5;
   short  l_indArr6;
   short  l_indArr7;
   short  l_indArr8;
   short  l_indArr9;
   short  l_indArr10;
   short  l_indArr11;
   short  l_indArr12;
   short  l_indArr13;
   short  l_indArr14;
   short  l_indArr15;
   short  l_indArr16;
   short  l_indArr17;
   short  l_indArr18;
   short  l_indArr19;
   short  l_indArr20;
   short  l_indArr21;
   short  l_indArr22;
   short  l_indArr23;
   short  l_indArr24;
   short  l_indArr25;
   short  l_indArr26;
   short  l_indArr27;
   short  l_indArr28;
   short  l_indArr29;
   short  l_indArr30;
   short  l_indArr31;
   short  l_indArr32;
   short  l_indArr33;
   short  l_indArr34;
   short  l_indArr35;
   short  l_indArr36;
   short  l_indArr37;
   short  l_indArr38;

   /* EXEC SQL END DECLARE SECTION; */ 


   l_indArr0=0; 
   l_indArr1=0; 
   l_indArr2=0; 
   l_indArr3=0; 
   l_indArr4=0; 
   l_indArr5=0; 
   l_indArr6=0; 
   l_indArr7=0; 
   l_indArr8=0; 
   l_indArr9=0; 
   l_indArr10=0;
   l_indArr11=0;
   l_indArr12=0;
   l_indArr13=0;
   l_indArr14=0;
   l_indArr15=0;
   l_indArr16=0;
   l_indArr17=0;
   l_indArr18=0;
   l_indArr19=0;
   l_indArr20=0;
   l_indArr21=0;
   l_indArr22=0;
   l_indArr23=0;
   l_indArr24=0;
   l_indArr25=0; 
   l_indArr26=0; 
   l_indArr27=0; 
   l_indArr28=0; 
   l_indArr29=0; 
   l_indArr30=0; 
   l_indArr31=0; 
   l_indArr32=0; 
   l_indArr33=0; 
   l_indArr34=0; 
   l_indArr35=0; 
   l_indArr36=0; 
   l_indArr37=0; 
   l_indArr38=0; 

   //Inputs
   memset(&l_imsi, '\0', sizeof(l_imsi));
   l_imsi.len = strlen(m_imsi);
   strncpy((char*)l_imsi.arr, m_imsi, strlen(m_imsi));
   memset(&l_mmeHost, '\0', sizeof(l_mmeHost));
   l_mmeHost.len = strlen(m_mmeHost);
   strncpy((char*)l_mmeHost.arr, m_mmeHost, strlen(m_mmeHost));
   memset(&l_mmeRealm, '\0', sizeof(l_mmeRealm));
   l_mmeRealm.len = snprintf((char*)l_mmeRealm.arr, sizeof(l_mmeRealm.arr), "%s",m_mmeRealm);
   memset(&l_scscfRealm, '\0', sizeof(l_scscfRealm));
   l_scscfRealm.len = snprintf((char*)l_scscfRealm.arr, sizeof(l_scscfRealm.arr), "%s",m_scscfRealm);
   memset(&l_scscfHost, '\0', sizeof(l_scscfHost));
   l_scscfHost.len = snprintf((char*)l_scscfHost.arr, sizeof(l_scscfHost.arr), "%s",m_scscfHost);
   memset(&l_scscfName, '\0', sizeof(l_scscfName));
   l_scscfName.len = snprintf((char*)l_scscfName.arr, sizeof(l_scscfName.arr), "%s",m_scscfName);
   memset(&l_requestNode, '\0', sizeof(l_requestNode));
   l_requestNode.len = snprintf((char*)l_requestNode.arr, sizeof(l_requestNode.arr), "%s",m_requestNodeStr);
   memset(&l_visitedNwkID_DB,'\0',sizeof(l_visitedNwkID_DB));
   l_visitedNwkID_DB.len = snprintf((char*)l_visitedNwkID_DB.arr,sizeof(l_visitedNwkID_DB.arr),"%s",m_visitedNwkID_DB);
    l_AAA_Failure_Indication_DB = m_AAA_Failure_Indication_DB;


   //Outputs
   memset(&l_sqn, '\0', sizeof(l_sqn));
   memset(&l_ki, '\0', sizeof(l_ki));
   memset(&l_ki_key, '\0', sizeof(l_ki_key));
   memset(&l_ki_init_vector, '\0', sizeof(l_ki_init_vector));
   memset(&l_op, '\0', sizeof(l_op));
   memset(&l_amf, '\0', sizeof(l_amf));
   memset(&l_rand, '\0', sizeof(l_rand));
   memset(&l_msisdn, '\0', sizeof(l_msisdn));
   memset(&l_accountId, '\0', sizeof(l_accountId));
   l_accFlag=-1;
   memset(&l_errMsg, '\0', sizeof(l_errMsg));
   l_errCode=-1;
   l_ki_enc_algo=-1;
   l_ki_enc_mode=0;
   l_auth_algo=-1;
   memset(&l_hlrAdd, '\0', sizeof(l_hlrAdd));
   l_msgVersion=m_msgVersion;
   l_reqNode=m_requestNode;
   //l_reqNode=1;
   memset(&l_hssHost, '\0', sizeof(l_hssHost));
   memset(&l_hssRealm, '\0', sizeof(l_hssRealm));
   l_s6aRelease=0;
   memset(&l_primaryImsi, '\0', sizeof(l_primaryImsi));
   l_nam=-1;
   l_networkId_DB = 0;
   l_AucTemplateId_DB = 0;
   l_RoamPartnerId_DB = 0;
   l_curCount_DB = 0;
   memset(&l_cur_DB,'\0',sizeof(l_cur_DB));
   l_Customized_RC_Flag=0;
   l_R1=0;
   l_R2=0;
   l_R3=0;
   l_R4=0;
   l_R5=0;
   memset(&l_C1, '\0', sizeof(l_C1));
   memset(&l_C2, '\0', sizeof(l_C2));
   memset(&l_C3, '\0', sizeof(l_C3));
   memset(&l_C4, '\0', sizeof(l_C4));
   memset(&l_C5, '\0', sizeof(l_C5));
   l_ossTriggerDataCount_DB = 0;
   l_mappedErrCode = 0;
   l_imsProfId = 0;
   memset(&l_origNode, '\0', sizeof(l_origNode));
   strcpy((char*)l_origNode.arr, m_OrigAddr);
   l_origNode.len = strlen(m_OrigAddr);

   l_retryCount=m_retryCount;
   l_sleepInterval=((float)m_retryTimer)/1000000;
   l_imsiType=-1;
   l_multi_imsi_validation_flag =m_multi_imsi_validation_flag; 
   l_subs_barred_validation_flag=m_subs_barred_validation_flag;
   l_req_node_validation_flag=m_requesting_node_validation_flag;

   LLOG(0,1,"AUC proc called with imsi [%s], ReqNode[%d], OrigNode[%s], MsgVersion[%d], RetryCount[%d], SleepIntervalmicro[%d], SleepInterval[%f], imsi_validation_flag[%d], subs_barred_validation_flag[%d], requesting_node_validation_flag[%d], MmeHost:[%s], MmeRealm:[%s], ScscfHost[%s], ScscfRealm[%s], ScscfName[%s], RequestNode[%s] ,VisitedNetWorkID [%s] AAA_Failure_Indication[%d]", 
         (char*)l_imsi.arr, l_reqNode, (char*)l_origNode.arr, l_msgVersion, l_retryCount, m_retryTimer, l_sleepInterval, l_multi_imsi_validation_flag, l_subs_barred_validation_flag, l_req_node_validation_flag, (char*)l_mmeHost.arr, (char*)l_mmeRealm.arr, (char*)l_scscfHost.arr, (char*)l_scscfRealm.arr, (char*)l_scscfName.arr, (char*)l_requestNode.arr,l_visitedNwkID_DB.arr,l_AAA_Failure_Indication_DB);

   /* EXEC SQL CONTEXT USE :p_conn; */ 

   /* EXEC SQL ALLOCATE :l_cur_DB; */ 

{
   struct sqlexd sqlstm;
   sqlstm.sqlvsn = 12;
   sqlstm.arrsiz = 1;
   sqlstm.sqladtp = &sqladt;
   sqlstm.sqltdsp = &sqltds;
   sqlstm.stmt = "";
   sqlstm.iters = (unsigned int  )1;
   sqlstm.offset = (unsigned int  )5;
   sqlstm.cud = sqlcud0;
   sqlstm.sqlest = (unsigned char  *)&sqlca;
   sqlstm.sqlety = (unsigned short)4352;
   sqlstm.occurs = (unsigned int  )0;
   sqlstm.sqhstv[0] = (unsigned char  *)&l_cur_DB;
   sqlstm.sqhstl[0] = (unsigned long )sizeof(int);
   sqlstm.sqhsts[0] = (         int  )0;
   sqlstm.sqindv[0] = (         short *)0;
   sqlstm.sqinds[0] = (         int  )0;
   sqlstm.sqharm[0] = (unsigned long )0;
   sqlstm.sqadto[0] = (unsigned short )0;
   sqlstm.sqtdso[0] = (unsigned short )0;
   sqlstm.sqphsv = sqlstm.sqhstv;
   sqlstm.sqphsl = sqlstm.sqhstl;
   sqlstm.sqphss = sqlstm.sqhsts;
   sqlstm.sqpind = sqlstm.sqindv;
   sqlstm.sqpins = sqlstm.sqinds;
   sqlstm.sqparm = sqlstm.sqharm;
   sqlstm.sqparc = sqlstm.sqharc;
   sqlstm.sqpadto = sqlstm.sqadto;
   sqlstm.sqptdso = sqlstm.sqtdso;
   sqlcxt(&p_conn, &sqlctx, &sqlstm, &sqlfpn);
}


   
   /* EXEC SQL EXECUTE
      BEGIN
      HSS_PKG_AUTHENT_MODULE.GETAUCDETAILS(:l_imsi,
            :l_origNode,
            :l_reqNode,
            :l_msgVersion,
            :l_retryCount,
            :l_sleepInterval,
            :l_multi_imsi_validation_flag,
            :l_subs_barred_validation_flag,
            :l_req_node_validation_flag,
            :l_mmeHost,
            :l_mmeRealm,
            :l_scscfHost,
            :l_scscfRealm,
            :l_scscfName,
            :l_requestNode,
            :l_visitedNwkID_DB,
            :l_AAA_Failure_Indication_DB,
            :l_accountId:l_indArr0,
            :l_msisdn:l_indArr1,
            :l_ki:l_indArr2, 
            :l_ki_key:l_indArr3, 
            :l_ki_enc_algo:l_indArr4,
            :l_auth_algo:l_indArr5,
            :l_sqn:l_indArr6, 
            :l_op:l_indArr7, 
            :l_amf:l_indArr8,
            :l_accFlag:l_indArr9,
            :l_hlrAdd:l_indArr10,
            :l_imsiType:l_indArr11,
            :l_hssHost:l_indArr14,
            :l_hssRealm:l_indArr15,
            :l_s6aRelease:l_indArr16,
            :l_primaryImsi:l_indArr17,
            :l_nam:l_indArr18,
            :l_ki_enc_mode:l_indArr20,
            :l_ki_init_vector:l_indArr19,
            :l_networkId_DB:l_indArr21,
            :l_AucTemplateId_DB:l_indArr22,
            :l_RoamPartnerId_DB:l_indArr23,
            :l_curCount_DB:l_indArr24,
            :l_cur_DB:l_indArr25,
            :l_Customized_RC_Flag:l_indArr26,
            :l_R1:l_indArr27,
            :l_R2:l_indArr28,
            :l_R3:l_indArr29,
            :l_R4:l_indArr30,
            :l_R5:l_indArr31,
            :l_C1:l_indArr32,
            :l_C2:l_indArr33,
            :l_C3:l_indArr34,
            :l_C4:l_indArr35,
            :l_C5:l_indArr36,
            :l_mappedErrCode:l_indArr37,
            :l_imsProfId:l_indArr38,
            :l_errCode:l_indArr12,
            :l_errMsg:l_indArr13);
   END;
   END-EXEC; */ 

{
   struct sqlexd sqlstm;
   sqlstm.sqlvsn = 12;
   sqlstm.arrsiz = 56;
   sqlstm.sqladtp = &sqladt;
   sqlstm.sqltdsp = &sqltds;
   sqlbuft(&p_conn,
     "begin HSS_PKG_AUTHENT_MODULE . GETAUCDETAILS ( :l_imsi , :l_origNode ,\
 :l_reqNode , :l_msgVersion , :l_retryCount , :l_sleepInterval , :l_multi_im\
si_validation_flag , :l_subs_barred_validation_flag , :l_req_node_validation\
_flag , :l_mmeHost , :l_mmeRealm , :l_scscfHost , :l_scscfRealm , :l_scscfNa\
me , :l_requestNode , :l_visitedNwkID_DB , :l_AAA_Failure_Indication_DB , :l\
_accountId:l_indArr0 , :l_msisdn:l_indArr1 , :l_ki:l_indArr2 , :l_ki_key:l_i\
ndArr3 , :l_ki_enc_algo:l_indArr4 , :l_auth_algo:l_indArr5 , :l_sqn:l_indArr\
6 , :l_op:l_indArr7 , :l_amf:l_indArr8 , :l_accFlag:l_indArr9 , :l_hlrAdd:l_\
indArr10 , :l_imsiType:l_indArr11 , :l_hssHost:l_indArr14 , :l_hssRealm:l_in\
dArr15 , :l_s6aRelease:l_indArr16 , :l_primaryImsi:l_indArr17 , :l_nam:l_ind\
Arr18 , :l_ki_enc_mode:l_indArr20 , :l_ki_init_vector:l_indArr19 , :l_networ\
kId_DB:l_indArr21 , :l_AucTemplateId_DB:l_indArr22 , :l_RoamPartnerId_DB:l_i\
ndArr23 , :l_curCount_DB:l_indArr24 , :l_cur_DB:l_indArr25 , :l_Customized_R\
C_Flag:l_indArr26 , :l_R1:l_indArr27 , :l_");
   sqlstm.stmt = "R2:l_indArr28 , :l_R3:l_indArr29 , :l_R4:l_indArr30 , :l_R\
5:l_indArr31 , :l_C1:l_indArr32 , :l_C2:l_indArr33 , :l_C3:l_indArr34 , :l_C4:\
l_indArr35 , :l_C5:l_indArr36 , :l_mappedErrCode:l_indArr37 , :l_imsProfId:l_i\
ndArr38 , :l_errCode:l_indArr12 , :l_errMsg:l_indArr13 ) ; END ;";
   sqlstm.iters = (unsigned int  )1;
   sqlstm.offset = (unsigned int  )24;
   sqlstm.cud = sqlcud0;
   sqlstm.sqlest = (unsigned char  *)&sqlca;
   sqlstm.sqlety = (unsigned short)4352;
   sqlstm.occurs = (unsigned int  )0;
   sqlstm.sqhstv[0] = (unsigned char  *)&l_imsi;
   sqlstm.sqhstl[0] = (unsigned long )22;
   sqlstm.sqhsts[0] = (         int  )0;
   sqlstm.sqindv[0] = (         short *)0;
   sqlstm.sqinds[0] = (         int  )0;
   sqlstm.sqharm[0] = (unsigned long )0;
   sqlstm.sqadto[0] = (unsigned short )0;
   sqlstm.sqtdso[0] = (unsigned short )0;
   sqlstm.sqhstv[1] = (unsigned char  *)&l_origNode;
   sqlstm.sqhstl[1] = (unsigned long )22;
   sqlstm.sqhsts[1] = (         int  )0;
   sqlstm.sqindv[1] = (         short *)0;
   sqlstm.sqinds[1] = (         int  )0;
   sqlstm.sqharm[1] = (unsigned long )0;
   sqlstm.sqadto[1] = (unsigned short )0;
   sqlstm.sqtdso[1] = (unsigned short )0;
   sqlstm.sqhstv[2] = (unsigned char  *)&l_reqNode;
   sqlstm.sqhstl[2] = (unsigned long )sizeof(int);
   sqlstm.sqhsts[2] = (         int  )0;
   sqlstm.sqindv[2] = (         short *)0;
   sqlstm.sqinds[2] = (         int  )0;
   sqlstm.sqharm[2] = (unsigned long )0;
   sqlstm.sqadto[2] = (unsigned short )0;
   sqlstm.sqtdso[2] = (unsigned short )0;
   sqlstm.sqhstv[3] = (unsigned char  *)&l_msgVersion;
   sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
   sqlstm.sqhsts[3] = (         int  )0;
   sqlstm.sqindv[3] = (         short *)0;
   sqlstm.sqinds[3] = (         int  )0;
   sqlstm.sqharm[3] = (unsigned long )0;
   sqlstm.sqadto[3] = (unsigned short )0;
   sqlstm.sqtdso[3] = (unsigned short )0;
   sqlstm.sqhstv[4] = (unsigned char  *)&l_retryCount;
   sqlstm.sqhstl[4] = (unsigned long )sizeof(int);
   sqlstm.sqhsts[4] = (         int  )0;
   sqlstm.sqindv[4] = (         short *)0;
   sqlstm.sqinds[4] = (         int  )0;
   sqlstm.sqharm[4] = (unsigned long )0;
   sqlstm.sqadto[4] = (unsigned short )0;
   sqlstm.sqtdso[4] = (unsigned short )0;
   sqlstm.sqhstv[5] = (unsigned char  *)&l_sleepInterval;
   sqlstm.sqhstl[5] = (unsigned long )sizeof(float);
   sqlstm.sqhsts[5] = (         int  )0;
   sqlstm.sqindv[5] = (         short *)0;
   sqlstm.sqinds[5] = (         int  )0;
   sqlstm.sqharm[5] = (unsigned long )0;
   sqlstm.sqadto[5] = (unsigned short )0;
   sqlstm.sqtdso[5] = (unsigned short )0;
   sqlstm.sqhstv[6] = (unsigned char  *)&l_multi_imsi_validation_flag;
   sqlstm.sqhstl[6] = (unsigned long )sizeof(int);
   sqlstm.sqhsts[6] = (         int  )0;
   sqlstm.sqindv[6] = (         short *)0;
   sqlstm.sqinds[6] = (         int  )0;
   sqlstm.sqharm[6] = (unsigned long )0;
   sqlstm.sqadto[6] = (unsigned short )0;
   sqlstm.sqtdso[6] = (unsigned short )0;
   sqlstm.sqhstv[7] = (unsigned char  *)&l_subs_barred_validation_flag;
   sqlstm.sqhstl[7] = (unsigned long )sizeof(int);
   sqlstm.sqhsts[7] = (         int  )0;
   sqlstm.sqindv[7] = (         short *)0;
   sqlstm.sqinds[7] = (         int  )0;
   sqlstm.sqharm[7] = (unsigned long )0;
   sqlstm.sqadto[7] = (unsigned short )0;
   sqlstm.sqtdso[7] = (unsigned short )0;
   sqlstm.sqhstv[8] = (unsigned char  *)&l_req_node_validation_flag;
   sqlstm.sqhstl[8] = (unsigned long )sizeof(int);
   sqlstm.sqhsts[8] = (         int  )0;
   sqlstm.sqindv[8] = (         short *)0;
   sqlstm.sqinds[8] = (         int  )0;
   sqlstm.sqharm[8] = (unsigned long )0;
   sqlstm.sqadto[8] = (unsigned short )0;
   sqlstm.sqtdso[8] = (unsigned short )0;
   sqlstm.sqhstv[9] = (unsigned char  *)&l_mmeHost;
   sqlstm.sqhstl[9] = (unsigned long )103;
   sqlstm.sqhsts[9] = (         int  )0;
   sqlstm.sqindv[9] = (         short *)0;
   sqlstm.sqinds[9] = (         int  )0;
   sqlstm.sqharm[9] = (unsigned long )0;
   sqlstm.sqadto[9] = (unsigned short )0;
   sqlstm.sqtdso[9] = (unsigned short )0;
   sqlstm.sqhstv[10] = (unsigned char  *)&l_mmeRealm;
   sqlstm.sqhstl[10] = (unsigned long )103;
   sqlstm.sqhsts[10] = (         int  )0;
   sqlstm.sqindv[10] = (         short *)0;
   sqlstm.sqinds[10] = (         int  )0;
   sqlstm.sqharm[10] = (unsigned long )0;
   sqlstm.sqadto[10] = (unsigned short )0;
   sqlstm.sqtdso[10] = (unsigned short )0;
   sqlstm.sqhstv[11] = (unsigned char  *)&l_scscfHost;
   sqlstm.sqhstl[11] = (unsigned long )103;
   sqlstm.sqhsts[11] = (         int  )0;
   sqlstm.sqindv[11] = (         short *)0;
   sqlstm.sqinds[11] = (         int  )0;
   sqlstm.sqharm[11] = (unsigned long )0;
   sqlstm.sqadto[11] = (unsigned short )0;
   sqlstm.sqtdso[11] = (unsigned short )0;
   sqlstm.sqhstv[12] = (unsigned char  *)&l_scscfRealm;
   sqlstm.sqhstl[12] = (unsigned long )103;
   sqlstm.sqhsts[12] = (         int  )0;
   sqlstm.sqindv[12] = (         short *)0;
   sqlstm.sqinds[12] = (         int  )0;
   sqlstm.sqharm[12] = (unsigned long )0;
   sqlstm.sqadto[12] = (unsigned short )0;
   sqlstm.sqtdso[12] = (unsigned short )0;
   sqlstm.sqhstv[13] = (unsigned char  *)&l_scscfName;
   sqlstm.sqhstl[13] = (unsigned long )103;
   sqlstm.sqhsts[13] = (         int  )0;
   sqlstm.sqindv[13] = (         short *)0;
   sqlstm.sqinds[13] = (         int  )0;
   sqlstm.sqharm[13] = (unsigned long )0;
   sqlstm.sqadto[13] = (unsigned short )0;
   sqlstm.sqtdso[13] = (unsigned short )0;
   sqlstm.sqhstv[14] = (unsigned char  *)&l_requestNode;
   sqlstm.sqhstl[14] = (unsigned long )33;
   sqlstm.sqhsts[14] = (         int  )0;
   sqlstm.sqindv[14] = (         short *)0;
   sqlstm.sqinds[14] = (         int  )0;
   sqlstm.sqharm[14] = (unsigned long )0;
   sqlstm.sqadto[14] = (unsigned short )0;
   sqlstm.sqtdso[14] = (unsigned short )0;
   sqlstm.sqhstv[15] = (unsigned char  *)&l_visitedNwkID_DB;
   sqlstm.sqhstl[15] = (unsigned long )103;
   sqlstm.sqhsts[15] = (         int  )0;
   sqlstm.sqindv[15] = (         short *)0;
   sqlstm.sqinds[15] = (         int  )0;
   sqlstm.sqharm[15] = (unsigned long )0;
   sqlstm.sqadto[15] = (unsigned short )0;
   sqlstm.sqtdso[15] = (unsigned short )0;
   sqlstm.sqhstv[16] = (unsigned char  *)&l_AAA_Failure_Indication_DB;
   sqlstm.sqhstl[16] = (unsigned long )sizeof(int);
   sqlstm.sqhsts[16] = (         int  )0;
   sqlstm.sqindv[16] = (         short *)0;
   sqlstm.sqinds[16] = (         int  )0;
   sqlstm.sqharm[16] = (unsigned long )0;
   sqlstm.sqadto[16] = (unsigned short )0;
   sqlstm.sqtdso[16] = (unsigned short )0;
   sqlstm.sqhstv[17] = (unsigned char  *)&l_accountId;
   sqlstm.sqhstl[17] = (unsigned long )23;
   sqlstm.sqhsts[17] = (         int  )0;
   sqlstm.sqindv[17] = (         short *)&l_indArr0;
   sqlstm.sqinds[17] = (         int  )0;
   sqlstm.sqharm[17] = (unsigned long )0;
   sqlstm.sqadto[17] = (unsigned short )0;
   sqlstm.sqtdso[17] = (unsigned short )0;
   sqlstm.sqhstv[18] = (unsigned char  *)&l_msisdn;
   sqlstm.sqhstl[18] = (unsigned long )18;
   sqlstm.sqhsts[18] = (         int  )0;
   sqlstm.sqindv[18] = (         short *)&l_indArr1;
   sqlstm.sqinds[18] = (         int  )0;
   sqlstm.sqharm[18] = (unsigned long )0;
   sqlstm.sqadto[18] = (unsigned short )0;
   sqlstm.sqtdso[18] = (unsigned short )0;
   sqlstm.sqhstv[19] = (unsigned char  *)&l_ki;
   sqlstm.sqhstl[19] = (unsigned long )36;
   sqlstm.sqhsts[19] = (         int  )0;
   sqlstm.sqindv[19] = (         short *)&l_indArr2;
   sqlstm.sqinds[19] = (         int  )0;
   sqlstm.sqharm[19] = (unsigned long )0;
   sqlstm.sqadto[19] = (unsigned short )0;
   sqlstm.sqtdso[19] = (unsigned short )0;
   sqlstm.sqhstv[20] = (unsigned char  *)&l_ki_key;
   sqlstm.sqhstl[20] = (unsigned long )36;
   sqlstm.sqhsts[20] = (         int  )0;
   sqlstm.sqindv[20] = (         short *)&l_indArr3;
   sqlstm.sqinds[20] = (         int  )0;
   sqlstm.sqharm[20] = (unsigned long )0;
   sqlstm.sqadto[20] = (unsigned short )0;
   sqlstm.sqtdso[20] = (unsigned short )0;
   sqlstm.sqhstv[21] = (unsigned char  *)&l_ki_enc_algo;
   sqlstm.sqhstl[21] = (unsigned long )sizeof(int);
   sqlstm.sqhsts[21] = (         int  )0;
   sqlstm.sqindv[21] = (         short *)&l_indArr4;
   sqlstm.sqinds[21] = (         int  )0;
   sqlstm.sqharm[21] = (unsigned long )0;
   sqlstm.sqadto[21] = (unsigned short )0;
   sqlstm.sqtdso[21] = (unsigned short )0;
   sqlstm.sqhstv[22] = (unsigned char  *)&l_auth_algo;
   sqlstm.sqhstl[22] = (unsigned long )sizeof(int);
   sqlstm.sqhsts[22] = (         int  )0;
   sqlstm.sqindv[22] = (         short *)&l_indArr5;
   sqlstm.sqinds[22] = (         int  )0;
   sqlstm.sqharm[22] = (unsigned long )0;
   sqlstm.sqadto[22] = (unsigned short )0;
   sqlstm.sqtdso[22] = (unsigned short )0;
   sqlstm.sqhstv[23] = (unsigned char  *)&l_sqn;
   sqlstm.sqhstl[23] = (unsigned long )36;
   sqlstm.sqhsts[23] = (         int  )0;
   sqlstm.sqindv[23] = (         short *)&l_indArr6;
   sqlstm.sqinds[23] = (         int  )0;
   sqlstm.sqharm[23] = (unsigned long )0;
   sqlstm.sqadto[23] = (unsigned short )0;
   sqlstm.sqtdso[23] = (unsigned short )0;
   sqlstm.sqhstv[24] = (unsigned char  *)&l_op;
   sqlstm.sqhstl[24] = (unsigned long )36;
   sqlstm.sqhsts[24] = (         int  )0;
   sqlstm.sqindv[24] = (         short *)&l_indArr7;
   sqlstm.sqinds[24] = (         int  )0;
   sqlstm.sqharm[24] = (unsigned long )0;
   sqlstm.sqadto[24] = (unsigned short )0;
   sqlstm.sqtdso[24] = (unsigned short )0;
   sqlstm.sqhstv[25] = (unsigned char  *)&l_amf;
   sqlstm.sqhstl[25] = (unsigned long )36;
   sqlstm.sqhsts[25] = (         int  )0;
   sqlstm.sqindv[25] = (         short *)&l_indArr8;
   sqlstm.sqinds[25] = (         int  )0;
   sqlstm.sqharm[25] = (unsigned long )0;
   sqlstm.sqadto[25] = (unsigned short )0;
   sqlstm.sqtdso[25] = (unsigned short )0;
   sqlstm.sqhstv[26] = (unsigned char  *)&l_accFlag;
   sqlstm.sqhstl[26] = (unsigned long )sizeof(int);
   sqlstm.sqhsts[26] = (         int  )0;
   sqlstm.sqindv[26] = (         short *)&l_indArr9;
   sqlstm.sqinds[26] = (         int  )0;
   sqlstm.sqharm[26] = (unsigned long )0;
   sqlstm.sqadto[26] = (unsigned short )0;
   sqlstm.sqtdso[26] = (unsigned short )0;
   sqlstm.sqhstv[27] = (unsigned char  *)&l_hlrAdd;
   sqlstm.sqhstl[27] = (unsigned long )22;
   sqlstm.sqhsts[27] = (         int  )0;
   sqlstm.sqindv[27] = (         short *)&l_indArr10;
   sqlstm.sqinds[27] = (         int  )0;
   sqlstm.sqharm[27] = (unsigned long )0;
   sqlstm.sqadto[27] = (unsigned short )0;
   sqlstm.sqtdso[27] = (unsigned short )0;
   sqlstm.sqhstv[28] = (unsigned char  *)&l_imsiType;
   sqlstm.sqhstl[28] = (unsigned long )sizeof(int);
   sqlstm.sqhsts[28] = (         int  )0;
   sqlstm.sqindv[28] = (         short *)&l_indArr11;
   sqlstm.sqinds[28] = (         int  )0;
   sqlstm.sqharm[28] = (unsigned long )0;
   sqlstm.sqadto[28] = (unsigned short )0;
   sqlstm.sqtdso[28] = (unsigned short )0;
   sqlstm.sqhstv[29] = (unsigned char  *)&l_hssHost;
   sqlstm.sqhstl[29] = (unsigned long )103;
   sqlstm.sqhsts[29] = (         int  )0;
   sqlstm.sqindv[29] = (         short *)&l_indArr14;
   sqlstm.sqinds[29] = (         int  )0;
   sqlstm.sqharm[29] = (unsigned long )0;
   sqlstm.sqadto[29] = (unsigned short )0;
   sqlstm.sqtdso[29] = (unsigned short )0;
   sqlstm.sqhstv[30] = (unsigned char  *)&l_hssRealm;
   sqlstm.sqhstl[30] = (unsigned long )103;
   sqlstm.sqhsts[30] = (         int  )0;
   sqlstm.sqindv[30] = (         short *)&l_indArr15;
   sqlstm.sqinds[30] = (         int  )0;
   sqlstm.sqharm[30] = (unsigned long )0;
   sqlstm.sqadto[30] = (unsigned short )0;
   sqlstm.sqtdso[30] = (unsigned short )0;
   sqlstm.sqhstv[31] = (unsigned char  *)&l_s6aRelease;
   sqlstm.sqhstl[31] = (unsigned long )sizeof(int);
   sqlstm.sqhsts[31] = (         int  )0;
   sqlstm.sqindv[31] = (         short *)&l_indArr16;
   sqlstm.sqinds[31] = (         int  )0;
   sqlstm.sqharm[31] = (unsigned long )0;
   sqlstm.sqadto[31] = (unsigned short )0;
   sqlstm.sqtdso[31] = (unsigned short )0;
   sqlstm.sqhstv[32] = (unsigned char  *)&l_primaryImsi;
   sqlstm.sqhstl[32] = (unsigned long )18;
   sqlstm.sqhsts[32] = (         int  )0;
   sqlstm.sqindv[32] = (         short *)&l_indArr17;
   sqlstm.sqinds[32] = (         int  )0;
   sqlstm.sqharm[32] = (unsigned long )0;
   sqlstm.sqadto[32] = (unsigned short )0;
   sqlstm.sqtdso[32] = (unsigned short )0;
   sqlstm.sqhstv[33] = (unsigned char  *)&l_nam;
   sqlstm.sqhstl[33] = (unsigned long )sizeof(int);
   sqlstm.sqhsts[33] = (         int  )0;
   sqlstm.sqindv[33] = (         short *)&l_indArr18;
   sqlstm.sqinds[33] = (         int  )0;
   sqlstm.sqharm[33] = (unsigned long )0;
   sqlstm.sqadto[33] = (unsigned short )0;
   sqlstm.sqtdso[33] = (unsigned short )0;
   sqlstm.sqhstv[34] = (unsigned char  *)&l_ki_enc_mode;
   sqlstm.sqhstl[34] = (unsigned long )sizeof(int);
   sqlstm.sqhsts[34] = (         int  )0;
   sqlstm.sqindv[34] = (         short *)&l_indArr20;
   sqlstm.sqinds[34] = (         int  )0;
   sqlstm.sqharm[34] = (unsigned long )0;
   sqlstm.sqadto[34] = (unsigned short )0;
   sqlstm.sqtdso[34] = (unsigned short )0;
   sqlstm.sqhstv[35] = (unsigned char  *)&l_ki_init_vector;
   sqlstm.sqhstl[35] = (unsigned long )36;
   sqlstm.sqhsts[35] = (         int  )0;
   sqlstm.sqindv[35] = (         short *)&l_indArr19;
   sqlstm.sqinds[35] = (         int  )0;
   sqlstm.sqharm[35] = (unsigned long )0;
   sqlstm.sqadto[35] = (unsigned short )0;
   sqlstm.sqtdso[35] = (unsigned short )0;
   sqlstm.sqhstv[36] = (unsigned char  *)&l_networkId_DB;
   sqlstm.sqhstl[36] = (unsigned long )sizeof(int);
   sqlstm.sqhsts[36] = (         int  )0;
   sqlstm.sqindv[36] = (         short *)&l_indArr21;
   sqlstm.sqinds[36] = (         int  )0;
   sqlstm.sqharm[36] = (unsigned long )0;
   sqlstm.sqadto[36] = (unsigned short )0;
   sqlstm.sqtdso[36] = (unsigned short )0;
   sqlstm.sqhstv[37] = (unsigned char  *)&l_AucTemplateId_DB;
   sqlstm.sqhstl[37] = (unsigned long )sizeof(int);
   sqlstm.sqhsts[37] = (         int  )0;
   sqlstm.sqindv[37] = (         short *)&l_indArr22;
   sqlstm.sqinds[37] = (         int  )0;
   sqlstm.sqharm[37] = (unsigned long )0;
   sqlstm.sqadto[37] = (unsigned short )0;
   sqlstm.sqtdso[37] = (unsigned short )0;
   sqlstm.sqhstv[38] = (unsigned char  *)&l_RoamPartnerId_DB;
   sqlstm.sqhstl[38] = (unsigned long )sizeof(int);
   sqlstm.sqhsts[38] = (         int  )0;
   sqlstm.sqindv[38] = (         short *)&l_indArr23;
   sqlstm.sqinds[38] = (         int  )0;
   sqlstm.sqharm[38] = (unsigned long )0;
   sqlstm.sqadto[38] = (unsigned short )0;
   sqlstm.sqtdso[38] = (unsigned short )0;
   sqlstm.sqhstv[39] = (unsigned char  *)&l_curCount_DB;
   sqlstm.sqhstl[39] = (unsigned long )sizeof(int);
   sqlstm.sqhsts[39] = (         int  )0;
   sqlstm.sqindv[39] = (         short *)&l_indArr24;
   sqlstm.sqinds[39] = (         int  )0;
   sqlstm.sqharm[39] = (unsigned long )0;
   sqlstm.sqadto[39] = (unsigned short )0;
   sqlstm.sqtdso[39] = (unsigned short )0;
   sqlstm.sqhstv[40] = (unsigned char  *)&l_cur_DB;
   sqlstm.sqhstl[40] = (unsigned long )sizeof(int);
   sqlstm.sqhsts[40] = (         int  )0;
   sqlstm.sqindv[40] = (         short *)&l_indArr25;
   sqlstm.sqinds[40] = (         int  )0;
   sqlstm.sqharm[40] = (unsigned long )0;
   sqlstm.sqadto[40] = (unsigned short )0;
   sqlstm.sqtdso[40] = (unsigned short )0;
   sqlstm.sqhstv[41] = (unsigned char  *)&l_Customized_RC_Flag;
   sqlstm.sqhstl[41] = (unsigned long )sizeof(int);
   sqlstm.sqhsts[41] = (         int  )0;
   sqlstm.sqindv[41] = (         short *)&l_indArr26;
   sqlstm.sqinds[41] = (         int  )0;
   sqlstm.sqharm[41] = (unsigned long )0;
   sqlstm.sqadto[41] = (unsigned short )0;
   sqlstm.sqtdso[41] = (unsigned short )0;
   sqlstm.sqhstv[42] = (unsigned char  *)&l_R1;
   sqlstm.sqhstl[42] = (unsigned long )sizeof(short);
   sqlstm.sqhsts[42] = (         int  )0;
   sqlstm.sqindv[42] = (         short *)&l_indArr27;
   sqlstm.sqinds[42] = (         int  )0;
   sqlstm.sqharm[42] = (unsigned long )0;
   sqlstm.sqadto[42] = (unsigned short )0;
   sqlstm.sqtdso[42] = (unsigned short )0;
   sqlstm.sqhstv[43] = (unsigned char  *)&l_R2;
   sqlstm.sqhstl[43] = (unsigned long )sizeof(short);
   sqlstm.sqhsts[43] = (         int  )0;
   sqlstm.sqindv[43] = (         short *)&l_indArr28;
   sqlstm.sqinds[43] = (         int  )0;
   sqlstm.sqharm[43] = (unsigned long )0;
   sqlstm.sqadto[43] = (unsigned short )0;
   sqlstm.sqtdso[43] = (unsigned short )0;
   sqlstm.sqhstv[44] = (unsigned char  *)&l_R3;
   sqlstm.sqhstl[44] = (unsigned long )sizeof(short);
   sqlstm.sqhsts[44] = (         int  )0;
   sqlstm.sqindv[44] = (         short *)&l_indArr29;
   sqlstm.sqinds[44] = (         int  )0;
   sqlstm.sqharm[44] = (unsigned long )0;
   sqlstm.sqadto[44] = (unsigned short )0;
   sqlstm.sqtdso[44] = (unsigned short )0;
   sqlstm.sqhstv[45] = (unsigned char  *)&l_R4;
   sqlstm.sqhstl[45] = (unsigned long )sizeof(short);
   sqlstm.sqhsts[45] = (         int  )0;
   sqlstm.sqindv[45] = (         short *)&l_indArr30;
   sqlstm.sqinds[45] = (         int  )0;
   sqlstm.sqharm[45] = (unsigned long )0;
   sqlstm.sqadto[45] = (unsigned short )0;
   sqlstm.sqtdso[45] = (unsigned short )0;
   sqlstm.sqhstv[46] = (unsigned char  *)&l_R5;
   sqlstm.sqhstl[46] = (unsigned long )sizeof(short);
   sqlstm.sqhsts[46] = (         int  )0;
   sqlstm.sqindv[46] = (         short *)&l_indArr31;
   sqlstm.sqinds[46] = (         int  )0;
   sqlstm.sqharm[46] = (unsigned long )0;
   sqlstm.sqadto[46] = (unsigned short )0;
   sqlstm.sqtdso[46] = (unsigned short )0;
   sqlstm.sqhstv[47] = (unsigned char  *)&l_C1;
   sqlstm.sqhstl[47] = (unsigned long )36;
   sqlstm.sqhsts[47] = (         int  )0;
   sqlstm.sqindv[47] = (         short *)&l_indArr32;
   sqlstm.sqinds[47] = (         int  )0;
   sqlstm.sqharm[47] = (unsigned long )0;
   sqlstm.sqadto[47] = (unsigned short )0;
   sqlstm.sqtdso[47] = (unsigned short )0;
   sqlstm.sqhstv[48] = (unsigned char  *)&l_C2;
   sqlstm.sqhstl[48] = (unsigned long )36;
   sqlstm.sqhsts[48] = (         int  )0;
   sqlstm.sqindv[48] = (         short *)&l_indArr33;
   sqlstm.sqinds[48] = (         int  )0;
   sqlstm.sqharm[48] = (unsigned long )0;
   sqlstm.sqadto[48] = (unsigned short )0;
   sqlstm.sqtdso[48] = (unsigned short )0;
   sqlstm.sqhstv[49] = (unsigned char  *)&l_C3;
   sqlstm.sqhstl[49] = (unsigned long )36;
   sqlstm.sqhsts[49] = (         int  )0;
   sqlstm.sqindv[49] = (         short *)&l_indArr34;
   sqlstm.sqinds[49] = (         int  )0;
   sqlstm.sqharm[49] = (unsigned long )0;
   sqlstm.sqadto[49] = (unsigned short )0;
   sqlstm.sqtdso[49] = (unsigned short )0;
   sqlstm.sqhstv[50] = (unsigned char  *)&l_C4;
   sqlstm.sqhstl[50] = (unsigned long )36;
   sqlstm.sqhsts[50] = (         int  )0;
   sqlstm.sqindv[50] = (         short *)&l_indArr35;
   sqlstm.sqinds[50] = (         int  )0;
   sqlstm.sqharm[50] = (unsigned long )0;
   sqlstm.sqadto[50] = (unsigned short )0;
   sqlstm.sqtdso[50] = (unsigned short )0;
   sqlstm.sqhstv[51] = (unsigned char  *)&l_C5;
   sqlstm.sqhstl[51] = (unsigned long )36;
   sqlstm.sqhsts[51] = (         int  )0;
   sqlstm.sqindv[51] = (         short *)&l_indArr36;
   sqlstm.sqinds[51] = (         int  )0;
   sqlstm.sqharm[51] = (unsigned long )0;
   sqlstm.sqadto[51] = (unsigned short )0;
   sqlstm.sqtdso[51] = (unsigned short )0;
   sqlstm.sqhstv[52] = (unsigned char  *)&l_mappedErrCode;
   sqlstm.sqhstl[52] = (unsigned long )sizeof(int);
   sqlstm.sqhsts[52] = (         int  )0;
   sqlstm.sqindv[52] = (         short *)&l_indArr37;
   sqlstm.sqinds[52] = (         int  )0;
   sqlstm.sqharm[52] = (unsigned long )0;
   sqlstm.sqadto[52] = (unsigned short )0;
   sqlstm.sqtdso[52] = (unsigned short )0;
   sqlstm.sqhstv[53] = (unsigned char  *)&l_imsProfId;
   sqlstm.sqhstl[53] = (unsigned long )sizeof(int);
   sqlstm.sqhsts[53] = (         int  )0;
   sqlstm.sqindv[53] = (         short *)&l_indArr38;
   sqlstm.sqinds[53] = (         int  )0;
   sqlstm.sqharm[53] = (unsigned long )0;
   sqlstm.sqadto[53] = (unsigned short )0;
   sqlstm.sqtdso[53] = (unsigned short )0;
   sqlstm.sqhstv[54] = (unsigned char  *)&l_errCode;
   sqlstm.sqhstl[54] = (unsigned long )sizeof(int);
   sqlstm.sqhsts[54] = (         int  )0;
   sqlstm.sqindv[54] = (         short *)&l_indArr12;
   sqlstm.sqinds[54] = (         int  )0;
   sqlstm.sqharm[54] = (unsigned long )0;
   sqlstm.sqadto[54] = (unsigned short )0;
   sqlstm.sqtdso[54] = (unsigned short )0;
   sqlstm.sqhstv[55] = (unsigned char  *)&l_errMsg;
   sqlstm.sqhstl[55] = (unsigned long )202;
   sqlstm.sqhsts[55] = (         int  )0;
   sqlstm.sqindv[55] = (         short *)&l_indArr13;
   sqlstm.sqinds[55] = (         int  )0;
   sqlstm.sqharm[55] = (unsigned long )0;
   sqlstm.sqadto[55] = (unsigned short )0;
   sqlstm.sqtdso[55] = (unsigned short )0;
   sqlstm.sqphsv = sqlstm.sqhstv;
   sqlstm.sqphsl = sqlstm.sqhstl;
   sqlstm.sqphss = sqlstm.sqhsts;
   sqlstm.sqpind = sqlstm.sqindv;
   sqlstm.sqpins = sqlstm.sqinds;
   sqlstm.sqparm = sqlstm.sqharm;
   sqlstm.sqparc = sqlstm.sqharc;
   sqlstm.sqpadto = sqlstm.sqadto;
   sqlstm.sqptdso = sqlstm.sqtdso;
   sqlcxt(&p_conn, &sqlctx, &sqlstm, &sqlfpn);
}



   m_errCode = l_errCode;
   strncpy(m_errMsg_DB,(char*)l_errMsg.arr,l_errMsg.len);
   m_errMsg_DB[l_errMsg.len]='\0';
   LLOG(0,0,"m_errMsg_DB[%s]",m_errMsg_DB);
   LLOG(0,0,"l_reqNode[%d] l_curCount_DB[%d] l_req_node_validation_flag[%d]",l_reqNode,l_curCount_DB,l_req_node_validation_flag);
/*   if((6 == l_reqNode) && (1 == l_curCount_DB) && (1 == l_req_node_validation_flag))
   {
    l_errCode = m_errCode = 18;
    LLOG(0,0,"Cursor count is 1 for SWX setting as error code 18");
   } */

   LLOG(0,1,"DB Return Code [%d] [%s] [%d]", l_errCode, (char*)l_errMsg.arr, sqlca.sqlcode);

   m_procErrorCode=l_errCode;
   strncpy(m_procErrorMessage, (char*)l_errMsg.arr, l_errMsg.len);

   /*
      if(2 == l_reqNode)
      {
         LLOG(0,1,"GPRS request. retreiving SQN from SQN_GPRS");
         memset(&l_sqn, '\0', sizeof(l_sqn));
         l_imsi.len = strlen(m_imsi);
         strncpy((char*)l_imsi.arr, m_imsi, strlen(m_imsi));

         EXEC SQL SELECT SQN_GPRS
         INTO :l_sqn
         FROM HLR_ACCOUNT
         WHERE  ACCOUNT_ID=:l_accountId;
         
         if(0 != sqlca.sqlcode)
         {
         ELOG(0,1,"error in retrieving the sqn_gprs length:%d", l_sqn.len);
         }
         else
         {
         LLOG(0,1,"Retreived SQN GPRS length: %d", l_sqn.len);
         }
      }
    */

   m_networkId = l_networkId_DB;
   m_AucTemplateId = l_AucTemplateId_DB;
   m_RoamPartnerId = l_RoamPartnerId_DB;
   m_curCount = l_curCount_DB;
   m_mappedErrCode = l_mappedErrCode;
   m_imsProfId = l_imsProfId;
   DLOG(0,0,"m_AucTemplateId[%d] m_RoamPartnerId[%d] m_curCount[%d] m_mappedErrCode[%d] ImsProfileId [%d]",m_AucTemplateId,m_RoamPartnerId,m_curCount,m_mappedErrCode,m_imsProfId);


   LLOG(0,1,"GenericXmlApiData successfull sqlcode:%d", sqlca.sqlcode);
   memset(&l_rowid, '\0', sizeof(l_rowid));
   memset(&l_transId, '\0', sizeof(l_transId));
   memset(&l_transXml, '\0', sizeof(l_transXml));
   l_opCode=0;
        
   DLOG(0,1,"GenericXmlApiData before fetch :%d", sqlca.sqlcode);
   /* EXEC SQL FETCH :l_cur_DB INTO :l_rowid, :l_transId, :l_opCode, :l_transXml; */ 

{
   struct sqlexd sqlstm;
   sqlstm.sqlvsn = 12;
   sqlstm.arrsiz = 56;
   sqlstm.sqladtp = &sqladt;
   sqlstm.sqltdsp = &sqltds;
   sqlstm.iters = (unsigned int  )1;
   sqlstm.offset = (unsigned int  )263;
   sqlstm.selerr = (unsigned short)1;
   sqlstm.cud = sqlcud0;
   sqlstm.sqlest = (unsigned char  *)&sqlca;
   sqlstm.sqlety = (unsigned short)4352;
   sqlstm.occurs = (unsigned int  )0;
   sqlstm.sqfoff = (         int )0;
   sqlstm.sqfmod = (unsigned int )2;
   sqlstm.sqhstv[0] = (unsigned char  *)&l_cur_DB;
   sqlstm.sqhstl[0] = (unsigned long )sizeof(int);
   sqlstm.sqhsts[0] = (         int  )0;
   sqlstm.sqindv[0] = (         short *)0;
   sqlstm.sqinds[0] = (         int  )0;
   sqlstm.sqharm[0] = (unsigned long )0;
   sqlstm.sqadto[0] = (unsigned short )0;
   sqlstm.sqtdso[0] = (unsigned short )0;
   sqlstm.sqhstv[1] = (unsigned char  *)&l_rowid;
   sqlstm.sqhstl[1] = (unsigned long )33;
   sqlstm.sqhsts[1] = (         int  )0;
   sqlstm.sqindv[1] = (         short *)0;
   sqlstm.sqinds[1] = (         int  )0;
   sqlstm.sqharm[1] = (unsigned long )0;
   sqlstm.sqadto[1] = (unsigned short )0;
   sqlstm.sqtdso[1] = (unsigned short )0;
   sqlstm.sqhstv[2] = (unsigned char  *)&l_transId;
   sqlstm.sqhstl[2] = (unsigned long )23;
   sqlstm.sqhsts[2] = (         int  )0;
   sqlstm.sqindv[2] = (         short *)0;
   sqlstm.sqinds[2] = (         int  )0;
   sqlstm.sqharm[2] = (unsigned long )0;
   sqlstm.sqadto[2] = (unsigned short )0;
   sqlstm.sqtdso[2] = (unsigned short )0;
   sqlstm.sqhstv[3] = (unsigned char  *)&l_opCode;
   sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
   sqlstm.sqhsts[3] = (         int  )0;
   sqlstm.sqindv[3] = (         short *)0;
   sqlstm.sqinds[3] = (         int  )0;
   sqlstm.sqharm[3] = (unsigned long )0;
   sqlstm.sqadto[3] = (unsigned short )0;
   sqlstm.sqtdso[3] = (unsigned short )0;
   sqlstm.sqhstv[4] = (unsigned char  *)&l_transXml;
   sqlstm.sqhstl[4] = (unsigned long )8003;
   sqlstm.sqhsts[4] = (         int  )0;
   sqlstm.sqindv[4] = (         short *)0;
   sqlstm.sqinds[4] = (         int  )0;
   sqlstm.sqharm[4] = (unsigned long )0;
   sqlstm.sqadto[4] = (unsigned short )0;
   sqlstm.sqtdso[4] = (unsigned short )0;
   sqlstm.sqphsv = sqlstm.sqhstv;
   sqlstm.sqphsl = sqlstm.sqhstl;
   sqlstm.sqphss = sqlstm.sqhsts;
   sqlstm.sqpind = sqlstm.sqindv;
   sqlstm.sqpins = sqlstm.sqinds;
   sqlstm.sqparm = sqlstm.sqharm;
   sqlstm.sqparc = sqlstm.sqharc;
   sqlstm.sqpadto = sqlstm.sqadto;
   sqlstm.sqptdso = sqlstm.sqtdso;
   sqlcxt(&p_conn, &sqlctx, &sqlstm, &sqlfpn);
}


   DLOG(0,1,"GenericXmlApiData after fetch :%d",sqlca.sqlcode);

   m_nam = l_nam;
if(1 == l_curCount_DB)
{
   if(0 == sqlca.sqlcode)
   {
	   strcpy(m_ossTriggerDataArray[m_ossTriggerDataCount].m_rowId, (char*)l_rowid.arr);
	   strcpy(m_ossTriggerDataArray[m_ossTriggerDataCount].m_transId, (char*)l_transId.arr);
	   m_ossTriggerDataArray[m_ossTriggerDataCount].m_opCode = l_opCode;
	   strcpy(m_ossTriggerDataArray[m_ossTriggerDataCount].m_transXml, (char*)l_transXml.arr);
	   LLOG(0,0,"GenericXmlApiData rowid [%s], transId [%s], opCode [%d], transXml[%s], ossTriggerDataCount [%d], curCount_oDB [%d]",
			   m_ossTriggerDataArray[m_ossTriggerDataCount].m_rowId,
			   m_ossTriggerDataArray[m_ossTriggerDataCount].m_transId,
			   m_ossTriggerDataArray[m_ossTriggerDataCount].m_opCode,
			   m_ossTriggerDataArray[m_ossTriggerDataCount].m_transXml,m_ossTriggerDataCount, l_curCount_DB);
	   m_ossTriggerDataCount++;

   }
   else
   {
	   LLOG(0,1,"GenericXmlApiData cursor fetch failed for RTR ...sqlca code is %d", sqlca.sqlcode);
   }
}

/* EXEC SQL FREE :l_cur_DB; */ 

{
struct sqlexd sqlstm;
sqlstm.sqlvsn = 12;
sqlstm.arrsiz = 56;
sqlstm.sqladtp = &sqladt;
sqlstm.sqltdsp = &sqltds;
sqlstm.stmt = "";
sqlstm.iters = (unsigned int  )1;
sqlstm.offset = (unsigned int  )298;
sqlstm.cud = sqlcud0;
sqlstm.sqlest = (unsigned char  *)&sqlca;
sqlstm.sqlety = (unsigned short)4352;
sqlstm.occurs = (unsigned int  )0;
sqlstm.sqhstv[0] = (unsigned char  *)&l_cur_DB;
sqlstm.sqhstl[0] = (unsigned long )sizeof(int);
sqlstm.sqhsts[0] = (         int  )0;
sqlstm.sqindv[0] = (         short *)0;
sqlstm.sqinds[0] = (         int  )0;
sqlstm.sqharm[0] = (unsigned long )0;
sqlstm.sqadto[0] = (unsigned short )0;
sqlstm.sqtdso[0] = (unsigned short )0;
sqlstm.sqphsv = sqlstm.sqhstv;
sqlstm.sqphsl = sqlstm.sqhstl;
sqlstm.sqphss = sqlstm.sqhsts;
sqlstm.sqpind = sqlstm.sqindv;
sqlstm.sqpins = sqlstm.sqinds;
sqlstm.sqparm = sqlstm.sqharm;
sqlstm.sqparc = sqlstm.sqharc;
sqlstm.sqpadto = sqlstm.sqadto;
sqlstm.sqptdso = sqlstm.sqtdso;
sqlcxt(&p_conn, &sqlctx, &sqlstm, &sqlfpn);
}

 
if (0 == l_errCode)
{
   memcpy(m_k, l_ki.buf, 16);
   memcpy(m_first_k, l_ki.buf, 16);
   memcpy(m_k_key, l_ki_key.buf, l_ki_key.len);
   m_k_len_key=l_ki_key.len;
   memcpy(m_iv_char, l_ki_init_vector.buf, l_ki_init_vector.len);
   m_iv_len_char=l_ki_init_vector.len;
   m_ki_enc_mode=l_ki_enc_mode;
   memcpy(m_op, l_op.buf, 16);
   memcpy(m_amf, l_amf.buf, 2);
   memcpy(m_sqn, l_sqn.buf, 6);
   memcpy(m_rand, l_rand.buf, 16);
   m_subsType=3;
   strcpy(m_msisdn, (char*)l_msisdn.arr);
   strcpy(m_accountId,(char*)l_accountId.arr);

   m_ki_enc_algo = l_ki_enc_algo;
   m_auth_algo = l_auth_algo;
   memcpy(m_hlrAddress, l_hlrAdd.arr, l_hlrAdd.len);
   memcpy(m_hssHost,    l_hssHost.arr,  l_hssHost.len);
   memcpy(m_hssRealm,   l_hssRealm.arr, l_hssRealm.len);
   memcpy(m_primaryImsi,l_primaryImsi.arr, l_primaryImsi.len);
   m_s6aRelease = l_s6aRelease;

   m_imsiType=l_imsiType;
   m_Customized_RC_Flag=l_Customized_RC_Flag;
   m_R1=l_R1;
   m_R2=l_R2;
   m_R3=l_R3;
   m_R4=l_R4;
   m_R5=l_R5;
   memcpy(m_C1, l_C1.buf, 16);
   memcpy(m_C2, l_C2.buf, 16);
   memcpy(m_C3, l_C3.buf, 16);
   memcpy(m_C4, l_C4.buf, 16);
   memcpy(m_C5, l_C5.buf, 16);
   m_DbQueryRes = DB_QUERY_RES_SUCCESS;

}
else if ( (1 == l_errCode)  || 
      (3 == l_errCode)  || 
      (4 == l_errCode)  || 
      (5 == l_errCode)  || 
      (6 == l_errCode)  || 
      (7 == l_errCode)  ||
      (8 == l_errCode)  ||
      (9 == l_errCode)  ||
      (10 == l_errCode)  ||
      (11 == l_errCode)  || 
      (14 == l_errCode)  ||
      (15 == l_errCode)  ||
      (16 == l_errCode)  ||
      (17 == l_errCode) ||
      (18 == l_errCode) ||
      (19 == l_errCode) ||
      (20 == l_errCode) ||
      (701 == l_errCode)
      )
{
   LLOG(0,0,"Error Code is ROWS_NOT_FOUND: %d", l_errCode);
   m_DbQueryRes = DB_QUERY_RES_ROWS_NOT_FOUND;	
   memcpy(m_hlrAddress, l_hlrAdd.arr, l_hlrAdd.len);
   memcpy(m_hssHost,    l_hssHost.arr,  l_hssHost.len);
   memcpy(m_hssRealm,   l_hssRealm.arr, l_hssRealm.len);
   memcpy(m_primaryImsi,l_primaryImsi.arr, l_primaryImsi.len);
   m_s6aRelease = l_s6aRelease;
}
else
{
   LLOG(0,0,"Error Code is other: %d", l_errCode);
   m_DbQueryRes = DB_QUERY_RES_CODE_EXCEPTION;	
   memcpy(m_hlrAddress, l_hlrAdd.arr, l_hlrAdd.len);
   memcpy(m_hssHost,    l_hssHost.arr,  l_hssHost.len);
   memcpy(m_hssRealm,   l_hssRealm.arr, l_hssRealm.len);
   memcpy(m_primaryImsi,l_primaryImsi.arr, l_primaryImsi.len);
   m_s6aRelease = l_s6aRelease;
}
m_sqlcode = sqlca.sqlcode;

return true;
}

UpdateSubsAuthData::UpdateSubsAuthData()
{
   DLOG(0,0,"UpdateSubsAuthData :cons:");
   memset(m_imsi, '\0', 16+1);
   memset(m_sqn, '\0', 6);  
   m_requestNode=REQUEST_NODE_VLR;
   memset(m_accountId, '\0', sizeof(m_accountId));

   m_networkId = 0;
   m_AucTemplateId = 0;
   m_RoamPartnerId = 0;
   memset(m_primaryImsi, '\0', sizeof(m_primaryImsi));
   memset(m_first_k, '\0', 16);
}

UpdateSubsAuthData::~UpdateSubsAuthData()
{
   DLOG(0,0,"UpdateSubsAuthData :des:");
}


bool UpdateSubsAuthData::executeQuery(void *p_conn)
{
   struct sqlca sqlca;
   LLOG(0,0,"UpdateSubsAuthData::executeQuery start for imsi[%s]...", m_imsi);

   /* EXEC SQL BEGIN DECLARE SECTION; */ 

   /* VARCHAR l_imsi[20]; */ 
struct { unsigned short len; unsigned char arr[20]; } l_imsi;

   my_raw l_sqn;
   /* VARCHAR l_accountId[20+1]; */ 
struct { unsigned short len; unsigned char arr[21]; } l_accountId;

   int l_reqNode;
   int l_errCode;
   /* VARCHAR l_errMsg[200]; */ 
struct { unsigned short len; unsigned char arr[200]; } l_errMsg;

   /* EXEC SQL END DECLARE SECTION; */ 


   memset(&l_imsi, '\0', sizeof(l_imsi));
   l_imsi.len = strlen(m_imsi);
   strncpy((char*)l_imsi.arr, m_imsi, strlen(m_imsi));

   memset(&l_sqn, '\0', sizeof(l_sqn));
   l_sqn.len = 6;
   memcpy((char*)l_sqn.buf, m_sqn, 6);

   memset(&l_accountId, '\0', sizeof(l_accountId));
   l_accountId.len = strlen(m_accountId);
   strcpy((char*)l_accountId.arr, m_accountId);
   l_reqNode=m_requestNode;

   memset(&l_errMsg, '\0', sizeof(l_errMsg));
   l_errCode=-1;

   LLOG_HEX(0,0,"Updating SQN into db", (char*)l_sqn.buf, l_sqn.len);
   LLOG(0,0,"Updating Request Node into db [%d]", l_reqNode);
   LLOG(0,0,"Updating Account Id into db [%s]", l_accountId.arr);

   //ConnectionObject* l_RunTimeContext = (ConnectionObject*)p_conn;
   //EXEC SQL CONTEXT USE :(l_RunTimeContext->iCtx);
   /* EXEC SQL CONTEXT USE :p_conn; */ 


   /*
      if(2 == m_requestNode)
      {
      LLOG(0,1,"GPRS request. updating SQN into SQN_GPRS");

      EXEC SQL UPDATE HLR_ACCOUNT
      SET SQN_GPRS = :l_sqn
      WHERE  ACCOUNT_ID=:l_accountId;
      EXEC SQL COMMIT;

      if(0 != sqlca.sqlcode)
      {
      ELOG(0,1,"error in updating the sqn_gprs length:%d", l_sqn.len);
      }
      else
      {
      LLOG(0,1,"Updated SQN GPRS length: %d", l_sqn.len);
      }
      l_errCode=0;
      l_errMsg.len = snprintf((char*)l_errMsg.arr, sizeof(l_errMsg.arr), "Success");
      }
      else
      {
    */
   /* EXEC SQL EXECUTE
      BEGIN
      HSS_PKG_AUTHENT_MODULE.UPDATEAUCDETAILS(:l_accountId,
            :l_sqn, 
            :l_reqNode,
            :l_errCode,
            :l_errMsg);
   END;
   END-EXEC; */ 

{
   struct sqlexd sqlstm;
   sqlstm.sqlvsn = 12;
   sqlstm.arrsiz = 56;
   sqlstm.sqladtp = &sqladt;
   sqlstm.sqltdsp = &sqltds;
   sqlstm.stmt = "begin HSS_PKG_AUTHENT_MODULE . UPDATEAUCDETAILS ( :l_accou\
ntId , :l_sqn , :l_reqNode , :l_errCode , :l_errMsg ) ; END ;";
   sqlstm.iters = (unsigned int  )1;
   sqlstm.offset = (unsigned int  )317;
   sqlstm.cud = sqlcud0;
   sqlstm.sqlest = (unsigned char  *)&sqlca;
   sqlstm.sqlety = (unsigned short)4352;
   sqlstm.occurs = (unsigned int  )0;
   sqlstm.sqhstv[0] = (unsigned char  *)&l_accountId;
   sqlstm.sqhstl[0] = (unsigned long )23;
   sqlstm.sqhsts[0] = (         int  )0;
   sqlstm.sqindv[0] = (         short *)0;
   sqlstm.sqinds[0] = (         int  )0;
   sqlstm.sqharm[0] = (unsigned long )0;
   sqlstm.sqadto[0] = (unsigned short )0;
   sqlstm.sqtdso[0] = (unsigned short )0;
   sqlstm.sqhstv[1] = (unsigned char  *)&l_sqn;
   sqlstm.sqhstl[1] = (unsigned long )36;
   sqlstm.sqhsts[1] = (         int  )0;
   sqlstm.sqindv[1] = (         short *)0;
   sqlstm.sqinds[1] = (         int  )0;
   sqlstm.sqharm[1] = (unsigned long )0;
   sqlstm.sqadto[1] = (unsigned short )0;
   sqlstm.sqtdso[1] = (unsigned short )0;
   sqlstm.sqhstv[2] = (unsigned char  *)&l_reqNode;
   sqlstm.sqhstl[2] = (unsigned long )sizeof(int);
   sqlstm.sqhsts[2] = (         int  )0;
   sqlstm.sqindv[2] = (         short *)0;
   sqlstm.sqinds[2] = (         int  )0;
   sqlstm.sqharm[2] = (unsigned long )0;
   sqlstm.sqadto[2] = (unsigned short )0;
   sqlstm.sqtdso[2] = (unsigned short )0;
   sqlstm.sqhstv[3] = (unsigned char  *)&l_errCode;
   sqlstm.sqhstl[3] = (unsigned long )sizeof(int);
   sqlstm.sqhsts[3] = (         int  )0;
   sqlstm.sqindv[3] = (         short *)0;
   sqlstm.sqinds[3] = (         int  )0;
   sqlstm.sqharm[3] = (unsigned long )0;
   sqlstm.sqadto[3] = (unsigned short )0;
   sqlstm.sqtdso[3] = (unsigned short )0;
   sqlstm.sqhstv[4] = (unsigned char  *)&l_errMsg;
   sqlstm.sqhstl[4] = (unsigned long )202;
   sqlstm.sqhsts[4] = (         int  )0;
   sqlstm.sqindv[4] = (         short *)0;
   sqlstm.sqinds[4] = (         int  )0;
   sqlstm.sqharm[4] = (unsigned long )0;
   sqlstm.sqadto[4] = (unsigned short )0;
   sqlstm.sqtdso[4] = (unsigned short )0;
   sqlstm.sqphsv = sqlstm.sqhstv;
   sqlstm.sqphsl = sqlstm.sqhstl;
   sqlstm.sqphss = sqlstm.sqhsts;
   sqlstm.sqpind = sqlstm.sqindv;
   sqlstm.sqpins = sqlstm.sqinds;
   sqlstm.sqparm = sqlstm.sqharm;
   sqlstm.sqparc = sqlstm.sqharc;
   sqlstm.sqpadto = sqlstm.sqadto;
   sqlstm.sqptdso = sqlstm.sqtdso;
   sqlcxt(&p_conn, &sqlctx, &sqlstm, &sqlfpn);
}


   /*
      }
    */

   /*EXEC SQL UPDATE HLR_ACCOUNT
     SET SQN = :l_sqn
     WHERE ACCOUNT_ID = :l_accountId;*/

   if (0 == l_errCode)
   {
      LLOG(0,0,"UpdateSubsAuthData: Updated the DB Successfully");
      m_DbQueryRes = DB_QUERY_RES_SUCCESS;	
   }
   else
   {
      LLOG(0,0,"Unable to update the DB");
      m_DbQueryRes = DB_QUERY_RES_CODE_EXCEPTION;	
   }
   m_sqlcode = sqlca.sqlcode;
   return true;
}

