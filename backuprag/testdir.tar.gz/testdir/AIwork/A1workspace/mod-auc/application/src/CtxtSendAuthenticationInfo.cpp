#include <its++.h>
#include <its_timers.h>
#include <diameter/Command.h>
#include <diameter/base/BaseAVP.h>
#include <AuthenticationInformation.h>
#include <DiametriqInterface.h>
#include <CtxtSendAuthenticationInfo.h>
#include <stdio.h>
#include <MapMessages.h>
#include <ServiceCoordinator.h>
#include <ExtendedServiceCoordinator.h>
#include <Logger.h>
#include <diameter/swx_rel_18/SWx_rel_18AVP.h>
#include <diameter/swx_rel_18/SWxMessages.h>
#include <IMAP1.h>
#include <IMAP2.h>
#include <IMAP3.h>
#include <OMAP1.h>
#include <OMAP2.h>
#include <OMAP3.h>
#include <AucDbQueries.h>
#include <DbActiveObject.h>
#include <ByteMilenage.h>
#include <CompAlgorithms.h>
#include <Utilities.h>
#include <AucConfigReader.h>
#include <DesCodec.h>
#include <DataUnion.h>
#include <TimerManager.h>
#include <typeinfo>
#include <HlrTdrFiller.h>
#include <DiameterMessages.h>
#include <DiameterConstants.h>
#include <S6a_r10AVP.h>
#include <SnmpInterface.h>
#include <AucMemCachedQueries.h>
#include <MemCachedUtilities.h>
#include <MemCachedActiveObject.h>
#include <SubsProfileData.h>
#include <diameter/cx_rel_16/CxMessages.h>
#include <diameter/cx_rel_16/Cx_rel_16AVP.h>
#include <DigestMD5.h>
#include <stdlib.h>

using namespace diameter::Cx_rel_16;
using namespace diameter::SWx_rel_18;
using namespace diameter::base;

extern int g_AuthRejected;
extern char *g_op_env;
extern char *g_fixed_rand_str;
extern char *g_sqn_env;
extern char *g_amf_env;

//#include <diameter/s6a_r10/S6aAVP.h>
using namespace diameter::s6a_r10;
/*
   u8 g_test_rand[16]= {0x2D,0x65,0xC2,0x1A,0x0E,0x2F,0x5D,0xB8,0x91,0x1C,0x3B,0x69,0x4A,0x34,0xC6,0xA1};
   u8 g_test_kc[8]= {0x7a,0x85,0xdf,0x99,0x57,0xa1,0x1d,0xb5};
   u8 g_sqn[6]= {0x95,0x69,0x79,0xB9,0xAF,0x7E};
   u8 g_test_res[4]= {0xb3,0xfc,0x20,0xa8};
   */

u8 g_test_rand[16] = {0x60, 0x78, 0x31, 0x32, 0x30, 0x78, 0x31, 0x32,
   0x30, 0x78, 0x31, 0x32, 0x30, 0x78, 0x31, 0x31};
//u8 g_test_rand[16] = {0x00,0x00,0x0e,0xfa,0x00,0x00,0x6a,0xee,0x00,0x00,0x72,0x9a,0x00,0x00,0x42,0xa2};
u8 g_test_kc[8]= {0x7a,0x85,0xdf,0x99,0x57,0xa1,0x1d,0xb5};
u8 g_sqn[6]= {0x00,0x00,0x12,0x69,0xe4,0xb9};
u8 g_test_res[4]= {0xb3,0xfc,0x20,0xa8};

#define SIP_DIGEST 2
#define AKA 1

CtxtSendAuthenticationInfo::CtxtSendAuthenticationInfo()
{
   m_subsType=0;
   m_firstSaiFlag=true;
   m_maxVectors=0;
   m_additionalMaxVectors=0;
   m_totalSentCount=0;
   m_rsad=NULL;
   //m_usad=NULL;
   m_v1AuthIndex=-1;
   memset(m_OrigAddr, '\0', 20+1);
   m_timerId=0;
   m_dlgStatusFlag=false;
   m_msgPtr=NULL;
   m_irp_mme=0;
   m_irp_sgsn=0;
   m_ro=REQUEST_ORIGIN_UNKNOWN;
   m_rnt=REQUEST_NODE_UNKNOWN;
   memset(m_originHost, '\0', sizeof(m_originHost));
   memset(m_originRealm, '\0', sizeof(m_originRealm));
   memset(m_publicIden, '\0', sizeof(m_publicIden));
   memset(m_domainName, '\0', sizeof(m_domainName));
   m_OtherImsiSubscriberFlag = false;
   m_networkId = 0;
   m_invalidAuthScheme = false;
   m_AAAFailureIndication = 0;
   memset(m_AAAServerName, '\0', sizeof(m_AAAServerName));
   m_CxFeatureListIdFlag = 0;
   m_memcUpdateInd = 0;
   memset(m_proxyHost, '\0', sizeof(m_proxyHost));
   memset(m_proxyState, '\0', sizeof(m_proxyState));
   DLOG(0,0,"CtxtSendAuthenticationInfo :cons:");
}

CtxtSendAuthenticationInfo::~CtxtSendAuthenticationInfo()
{
   DLOG(0,0,"CtxtSendAuthenticationInfo :des:");
   if (0 != m_timerId)                   
   {                                     
      g_tm.resetTimer(this, m_timerId);  
      m_timerId=0;                       
   }                                     
   if(NULL != m_msgPtr)
   {
      delete(m_msgPtr);
      m_msgPtr=NULL;
   }
   if(NULL != m_rsad)
   {
      delete(m_rsad);
      m_rsad=NULL;
   }
}

bool CtxtSendAuthenticationInfo::handleError(unsigned int aVendorId, unsigned int aErrCode, EErrorDiagnostic p_ed)
{
   if(REQUEST_ORIGIN_DIAMETER_S6A == m_ro)
   {  
      DLOG(0,0, "S6A Message Error received");

      DiameterMsg l_answer(((DiameterMsg*)m_msgPtr)->m_sessionId, DIAM_EVENT_ANSWER, DIAM_COMM_CODE_S6A_S6D_AIR_AIA);
      AuthenticationInformationAnswer l_aia;
      l_answer.m_cmd = &l_aia;

      SessionId l_sid(((DiameterMsg*)m_msgPtr)->m_sessionId);
      l_aia.setSessionId(l_sid);
      l_aia.setSessionIndex(((DiameterMsg*)m_msgPtr)->m_sessionIndex);
      AuthSessionState l_authSs(AuthSessionState::NO_STATE_MAINTAINED);
      l_aia.setAuthSessionState(l_authSs);
      OriginHost originHost(m_originHost);
      l_aia.setOriginHost(originHost);
      OriginRealm originRealm(m_originRealm);
      l_aia.setOriginRealm(originRealm);


      if(aErrCode == DIAM_RESULT_CODE_UNABLE_TO_COMPLY)
      {
         LLOG(0,1,"Setting Result Code %d", aErrCode);
         ResultCode l_rc(aErrCode);
         l_aia.setResultCode(l_rc);
      }
      else
      {
         LLOG(0,1,"Setting Experimental Result Code %d", aErrCode);
         ExperimentalResult l_experimentalResult;
         base::VendorId l_vendorId(10415);
         l_experimentalResult.setVendorId(l_vendorId);
         ExperimentalResultCode l_experimentalResultCode(aErrCode);
         l_experimentalResult.setExperimentalResultCode(l_experimentalResultCode);
         l_aia.setExperimentalResult(l_experimentalResult);

         if(ERROR_DIAGNOSTIC_NOT_REQUIRED != p_ed) //TODO: this is not present in Rel-8
         {
            LLOG(0,1,"Setting Error Diagnostic Code %d", p_ed);
            if(ERROR_DIAGNOSTIC_GPRS_DATA_SUBSCRIBED == p_ed)
            {
               ErrorDiagnostic l_ed(ErrorDiagnostic::GPRS_DATA_SUBSCRIBED);
               l_aia.setErrorDiagnostic(l_ed);
            }
            else if(ERROR_DIAGNOSTIC_NO_GPRS_DATA_SUBSCRIBED == p_ed)
            {
               ErrorDiagnostic l_ed(ErrorDiagnostic::NO_GPRS_DATA_SUBSCRIBED);
               l_aia.setErrorDiagnostic(l_ed);
            }
            else
            {
               ErrorDiagnostic l_ed(ErrorDiagnostic::GPRS_DATA_SUBSCRIBED);
               l_aia.setErrorDiagnostic(l_ed);
            }
         }
      }
      g_esc.sendMsg(this, &l_answer);
      m_dlgStatusFlag=false;
   }
   else if(REQUEST_ORIGIN_DIAMETER_CX == m_ro)
   {
      DLOG(0,0, "CX Message Error received");

      DiameterMsg l_answer(((DiameterMsg*)m_msgPtr)->m_sessionId, DIAM_EVENT_ANSWER, DIAM_COMM_CODE_CX_DX_MAR_MAA);
      diameter::Cx_rel_16::MutiMediaAuthAnswer l_maa;
      l_answer.m_cmd = &l_maa;

      SessionId l_sid(((DiameterMsg*)m_msgPtr)->m_sessionId);
      l_maa.setSessionId(l_sid);
      l_maa.setSessionIndex(((DiameterMsg*)m_msgPtr)->m_sessionIndex);
      AuthSessionState l_authSs(AuthSessionState::NO_STATE_MAINTAINED);
      l_maa.setAuthSessionState(l_authSs);
      OriginHost originHost(m_originHost);
      l_maa.setOriginHost(originHost);
      OriginRealm originRealm(m_originRealm);
      l_maa.setOriginRealm(originRealm);

      //{ Vendor-Specific-Application-Id }
      diameter::base::VendorId l_vendorId(10415);
      VendorSpecificApplicationId l_vendorSpecificApplicationId1;
      l_vendorSpecificApplicationId1.addVendorId(l_vendorId);
      AuthApplicationId l_authApplicationId(16777216);
      l_vendorSpecificApplicationId1.setAuthApplicationId(l_authApplicationId);
      l_maa.setVendorSpecificApplicationId(l_vendorSpecificApplicationId1);
      LLOG(0,0,"ErrorResp: SLAFlags Seperation Indication[1] VendorId[10415] AuthApplicationId[16777216] always");

      if(aErrCode == DIAM_RESULT_CODE_UNABLE_TO_COMPLY)
      {
         LLOG(0,1,"Setting Result Code %d", aErrCode);
         ResultCode l_rc(aErrCode);
         l_maa.setResultCode(l_rc);
      }
      else
      {
         LLOG(0,1,"Setting Experimental Result Code %d", aErrCode);
         ExperimentalResult l_experimentalResult;
         base::VendorId l_vendorId(10415);
         l_experimentalResult.setVendorId(l_vendorId);
         ExperimentalResultCode l_experimentalResultCode(aErrCode);
         l_experimentalResult.setExperimentalResultCode(l_experimentalResultCode);
         l_maa.setExperimentalResult(l_experimentalResult);
      }
      g_esc.sendMsg(this, &l_answer);
      m_dlgStatusFlag=false;
   }
   else if(REQUEST_ORIGIN_DIAMETER_SWX == m_ro)
   {
      DLOG(0,0, "SWX Message Error received");

      DiameterMsg l_answer(((DiameterMsg*)m_msgPtr)->m_sessionId, DIAM_EVENT_ANSWER, DIAM_COMM_CODE_CX_DX_MAR_MAA);
      diameter::SWx_rel_18::MutiMediaAuthAnswer l_maa;
      l_answer.m_cmd = &l_maa;

      SessionId l_sid(((DiameterMsg*)m_msgPtr)->m_sessionId);
      l_maa.setSessionId(l_sid);
      l_maa.setSessionIndex(((DiameterMsg*)m_msgPtr)->m_sessionIndex);
      AuthSessionState l_authSs(AuthSessionState::NO_STATE_MAINTAINED);
      l_maa.setAuthSessionState(l_authSs);
      OriginHost originHost(m_originHost);
      l_maa.setOriginHost(originHost);
      OriginRealm originRealm(m_originRealm);
      l_maa.setOriginRealm(originRealm);
      diameter::base::UserName l_userName(m_user_name);	
      l_maa.setUserName(l_userName);
      //{ Vendor-Specific-Application-Id }
      diameter::base::VendorId l_vendorId(10415);
      VendorSpecificApplicationId l_vendorSpecificApplicationId1;
      l_vendorSpecificApplicationId1.addVendorId(l_vendorId);
      AuthApplicationId l_authApplicationId(16777265);
      l_vendorSpecificApplicationId1.setAuthApplicationId(l_authApplicationId);
      l_maa.setVendorSpecificApplicationId(l_vendorSpecificApplicationId1);
      LLOG(0,0,"ErrorResp: SLAFlags Seperation Indication[1] VendorId[10415] AuthApplicationId[16777265] always");

      if(aErrCode == DIAM_RESULT_CODE_UNABLE_TO_COMPLY)
      {
         LLOG(0,1,"Setting Result Code %d", aErrCode);
         ResultCode l_rc(aErrCode);
         l_maa.setResultCode(l_rc);
      }
      else
      {
         LLOG(0,1,"Setting Experimental Result Code %d", aErrCode);
         ExperimentalResult l_experimentalResult;
         base::VendorId l_vendorId(10415);
         l_experimentalResult.setVendorId(l_vendorId);
         ExperimentalResultCode l_experimentalResultCode(aErrCode);
         l_experimentalResult.setExperimentalResultCode(l_experimentalResultCode);
         l_maa.setExperimentalResult(l_experimentalResult);
         if(aErrCode == DIAM_APP_CX_DX_EXP_RESULT_CODE_ERROR_IDENTITY_ALREADY_REGISTERED)
	 {
		dia3GPPAAAServerName serverName(m_AAAServerName);
	 	l_maa.setdia3GPPAAAServerName(serverName);
	 }
   
      }
      g_esc.sendMsg(this, &l_answer);
      m_dlgStatusFlag=false;
   }
   else
   {
      ELOG(0,0,"Unexpected Interface message received");
   }   
   return true;
}

bool CtxtSendAuthenticationInfo::processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag)
{
   DLOG(0,0,"Start of CtxtSendAuthenticationInfo::processMsg function");

   p_DeleteFlag=p_DeleteFlag; // This is just to keep the compiler happy

   MapSpecificMsg *l_specMsg = NULL;

   switch (p_MsgPtr->m_MsgType)
   {
      case MSG_TYPE_MAP:
         {
            switch (((MapMsg*)p_MsgPtr)->m_MapMsgType)
            {
               case MAP_MSG_TYPE_COMMON:
                  switch (((MapCommonMsg*)p_MsgPtr)->m_MapCommonMsgType)
                  {
                     case MAP_CMN_OPEN_IND:
                        {
                           m_ro=REQUEST_ORIGIN_SS7;
                           DLOG(0,0,"MAP_CMN_OPEN_IND received remote ssn: %d gt: %s", 
                                 ((MapOpenInd*)p_MsgPtr)->m_OrigAddr.ssn,
                                 ((MapOpenInd*)p_MsgPtr)->m_OrigAddr.globalTitle.addressInformation);
                           strncpy(m_OrigAddr, ((MapOpenInd*)p_MsgPtr)->m_OrigAddr.globalTitle.addressInformation, 20);
                           m_dlgStatusFlag=true;
                        }
                        break;

                     case MAP_CMN_DELIMITER_IND:
                        {
                           DLOG(0,0,"MAP_CMN_DELIMITER_IND received");
                        }
                        break;

                     case MAP_CMN_CLOSE_IND:
                        {
                           LLOG(0,0,"MAP_CMN_CLOSE_IND received");
                           m_dlgStatusFlag=false;
                        }
                        break;

                     case MAP_CMN_U_ABORT_IND:
                        {
                           m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_U_ABORT_RCVD); 
                           LLOG(0,0,"MAP_CMN_U_ABORT_IND received");
                           m_dlgStatusFlag=false;
                           if (0 != m_timerId)                  
                           {                                    
                              g_tm.resetTimer(this, m_timerId); 
                              m_timerId=0;                      
                           }                                    
                        }
                        break;

                     case MAP_CMN_P_ABORT_IND:
                        {
                           m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_P_ABORT_RCVD); 
                           LLOG(0,0,"MAP_CMN_P_ABORT_IND received");
                           m_dlgStatusFlag=false;
                           if (0 != m_timerId)                  
                           {                                    
                              g_tm.resetTimer(this, m_timerId); 
                              m_timerId=0;                      
                           } 
                        }
                        break;

                     case MAP_CMN_NOTICE_IND:
                        {
                           LLOG(0,0,"MAP_CMN_NOTICE_IND received");
                           DLOG(0,0,"Closing the Dialogue");
                           m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_NOTICE_RCVD); 
                           MapCloseReq l_closeReq(((MapMsg*)p_MsgPtr)->m_UserDlgId);
                           g_sc.sendMsg(this, &l_closeReq);
                           m_dlgStatusFlag=false;
                           if (0 != m_timerId)                  
                           {                                    
                              g_tm.resetTimer(this, m_timerId); 
                              m_timerId=0;                      
                           } 
                        }
                        break;

                     default:
                        DLOG(0,0,"Unknown Msg received [%d]", ((MapCommonMsg*)p_MsgPtr)->m_MapCommonMsgType);
                        break;
                  }
                  break;

               case MAP_MSG_TYPE_SPECIFIC:
                  DLOG(0,0,"MAP_MSG_TYPE_SPECIFIC received");
                  l_specMsg = (MapSpecificMsg*)p_MsgPtr;

                  switch (((MapSpecificMsg*)p_MsgPtr)->m_MapSpecificEventType)
                  {
                     case MAP_SPEC_EVENT_INDICATION:
                        {
                           DLOG(0,0,"MAP_SPEC_EVENT_INDICATION received");

                           switch (((MapSpecificMsg*)p_MsgPtr)->m_OpCode)
                           {
                              case MAP_OP_CODE_sendAuthenticationInfo:
                              case MAP_OP_CODE_sendParameters:
                                 {
                                    if (true == m_firstSaiFlag)
                                    {
                                       LLOG(0,0,"Received Invoke for the first time. Initiating DB Request... ");
                                       if (false == ((MapSpecificMsg*)p_MsgPtr)->m_allocatedFlag)
                                       {
                                          CLOG(0,0,"First Invoke received is NULL. Sending User Error (Unexpected Data)...");
                                          m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_unexpectedData); 
                                          MapUserError l_userError(getInitialRespondingDlgId(), MAP_ERROR_unexpectedData, getInitialRespondingVersion(), NULL);
                                          g_sc.sendMsg(this, &l_userError);
                                          MapCloseReq l_closeReq(getInitialRespondingDlgId());
                                          g_sc.sendMsg(this, &l_closeReq);
                                          m_dlgStatusFlag=false;
                                       }
                                       else
                                       {
                                          m_firstSaiFlag=false;

                                          if (false == initiateDbRequest(p_MsgPtr))
                                          {
                                             LLOG(0,0,"Failed initiating DB Request. Sending User Error (Unexpected Data)...");
                                             m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_unexpectedData); 
                                             MapUserError l_userError(getInitialRespondingDlgId(), MAP_ERROR_unexpectedData, getInitialRespondingVersion(), NULL);
                                             g_sc.sendMsg(this, &l_userError);
                                             MapCloseReq l_closeReq(getInitialRespondingDlgId());
                                             g_sc.sendMsg(this, &l_closeReq);
                                             m_dlgStatusFlag=false;
                                          }
                                       }
                                    }
                                    else
                                    {
                                       LLOG(0,0,"Received Invoke for the successive time. Resetting the timer. Sending further responses...");
                                       sendFurtherResponses();
                                    }
                                 }
                                 break;

                              default:
                                 {
                                    WLOG(0,0,"Received Unknown Specific Message");
                                    MapUAbortReq l_req(((MapMsg*)p_MsgPtr)->m_UserDlgId);
                                    g_sc.sendMsg(this, &l_req);
                                 }
                                 break;
                           }
                        }
                        break;

                     case MAP_SPEC_EVENT_RESULT:
                        {
                           WLOG(0,0,"MAP_SPEC_EVENT_RESULT received");
                        }
                        break;

                     case MAP_SPEC_EVENT_CONFIRMATION:
                        {
                           WLOG(0,0,"MAP_SPEC_EVENT_CONFIRMATION received");
                        }
                        break;

                     case MAP_SPEC_EVENT_USER_ERROR:
                        {
                           WLOG(0,0,"MAP_SPEC_EVENT_USER_ERROR received");
                        }
                        break;

                     case MAP_SPEC_EVENT_PROV_ERROR:
                        {
                           WLOG(0,0,"MAP_SPEC_EVENT_PROV_ERROR received");
                           WLOG(0,0,"Closing the Dialogue");
                           MapCloseReq l_closeReq(((MapSpecificMsg*)p_MsgPtr)->m_UserDlgId);
                           g_sc.sendMsg(this, &l_closeReq);
                           m_dlgStatusFlag=false;
                           if (0 != m_timerId)                   
                           {                                     
                              g_tm.resetTimer(this, m_timerId);  
                              m_timerId=0;                       
                           }                                     
                        }
                        break;

                     default:
                        ELOG(0,0,"ERROR!! Default received");
                        break;
                  }
                  break;

               default:
                  break;
            }
         }
         break;

      case MSG_TYPE_DIAMETER:
         {
            DiameterMsg *l_dm = (DiameterMsg*)p_MsgPtr;
            switch(l_dm->m_det)
            {
               case DIAM_EVENT_REQUEST:
                  LLOG(0,1,"DIAM_EVENT_REQUEST received");
                  p_DeleteFlag=false;
                  m_msgPtr=p_MsgPtr;
                  m_ro=REQUEST_ORIGIN_DIAMETER_S6A;

                  switch(l_dm->m_commandCode)
                  {
                     case DIAM_COMM_CODE_S6A_S6D_AIR_AIA:
                        {
                           p_DeleteFlag=false;
                           m_msgPtr=p_MsgPtr;
                           m_ro=REQUEST_ORIGIN_DIAMETER_S6A;
                           LLOG(0,0,"DIAMETER message received");
                           if(NULL != l_dm->m_cmd)
                           {
                              if (false == l_dm->m_allocatedFlag)
                              {
                                 CLOG(0,0,"S6A AIR received is NULL. Sending Unexpected Data...");
                                 //TODO: how to send unexpected data?
                                 handleError(12,DIAM_RESULT_CODE_UNABLE_TO_COMPLY, ERROR_DIAGNOSTIC_NOT_REQUIRED);
                                 m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_RESULT_CODE_UNABLE_TO_COMPLY); 
                                 m_dlgStatusFlag=false;
                                 return false;
                              }
                              else
                              {
                                 if (false == initiateDbRequest(p_MsgPtr))
                                 {
                                    LLOG(0,0,"Failed initiating DB Request S6A AIR. Sending Unexpected Data...");
                                    //TODO: how?
                                    handleError(12,DIAM_RESULT_CODE_UNABLE_TO_COMPLY, ERROR_DIAGNOSTIC_NOT_REQUIRED);
                                    m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_RESULT_CODE_UNABLE_TO_COMPLY); 
                                    m_dlgStatusFlag=false;
                                    return false;
                                 }
                              }
                           }
                           else
                           {
                              WLOG(0,0,"No AIR message found");
                           }
                        }   
                        break;

                     case DIAM_COMM_CODE_CX_DX_MAR_MAA:
                        {
                           if(l_dm->m_applicationId == 16777216)
                           {   
                           p_DeleteFlag=false;
                           m_msgPtr=p_MsgPtr;
                           m_ro=REQUEST_ORIGIN_DIAMETER_CX;
                           m_tdr.setInteger(TDR_INDEX_REQUEST_DOMAIN, m_ro);
                           LLOG(0,0,"DIAMETER Cx message received");
                           if(NULL != l_dm->m_cmd)
                           {
                              if (false == l_dm->m_allocatedFlag)
                              {
                                 CLOG(0,0,"Cx MAR received is NULL. Sending Unexpected Data...");
                                 //TODO: how to send unexpected data?
                                 handleError(12,DIAM_RESULT_CODE_UNABLE_TO_COMPLY, ERROR_DIAGNOSTIC_NOT_REQUIRED);
                                 m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_RESULT_CODE_UNABLE_TO_COMPLY); 
                                 m_dlgStatusFlag=false;
                                 return false;
                              }
                              else
                              {
                                 if (false == initiateDbRequest(p_MsgPtr))
                                 {
                                    //TODO: how?
                                    if(true == m_invalidAuthScheme)
                                    {   
                                       handleError(12, DIAM_APP_CX_DX_EXP_RESULT_CODE_ERROR_AUTH_SCHEME_NOT_SUPPORTED, ERROR_DIAGNOSTIC_NOT_REQUIRED);
                                       m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_APP_CX_DX_EXP_RESULT_CODE_ERROR_AUTH_SCHEME_NOT_SUPPORTED); 
                                    }
                                    else
                                    {
                                       LLOG(0,0,"Failed initiating DB Request CX MAR. Sending Unexpected Data...");
                                       handleError(12, DIAM_RESULT_CODE_UNABLE_TO_COMPLY, ERROR_DIAGNOSTIC_NOT_REQUIRED);
                                       m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_RESULT_CODE_UNABLE_TO_COMPLY); 
                                    }   
                                    m_dlgStatusFlag=false;
                                    return false;
                                 }
                              }
                           }
                           else
                           {
                              WLOG(0,0,"No MAR message found");
                           }
                           }   
                           else
                           { 
                           p_DeleteFlag=false;
                           m_msgPtr=p_MsgPtr;
                           m_ro=REQUEST_ORIGIN_DIAMETER_SWX;
                           LLOG(0,0,"DIAMETER SWX message received");
                           if(NULL != l_dm->m_cmd)
                           {
                              DLOG(0,0,"m_allocatedFlag in Swx Mar [%d]",l_dm->m_allocatedFlag);
                              /*if (false == l_dm->m_allocatedFlag)
                              {
                                 CLOG(0,0,"SWX MAR received is NULL. Sending Unexpected Data...");
                                 //TODO: how to send unexpected data?
                                 handleError(12,DIAM_RESULT_CODE_UNABLE_TO_COMPLY, ERROR_DIAGNOSTIC_NOT_REQUIRED);
                                 m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_RESULT_CODE_UNABLE_TO_COMPLY); 
                                 m_dlgStatusFlag=false;
                                 return false;
                              }
                              else*/
                              {
                                 if (false == initiateDbRequest(p_MsgPtr))
                                 {
                                    //TODO: how?
                                    if(true == m_invalidAuthScheme)
                                    {   
                                       handleError(12, DIAM_APP_CX_DX_EXP_RESULT_CODE_ERROR_AUTH_SCHEME_NOT_SUPPORTED, ERROR_DIAGNOSTIC_NOT_REQUIRED);
                                       m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_APP_CX_DX_EXP_RESULT_CODE_ERROR_AUTH_SCHEME_NOT_SUPPORTED); 
                                    }
                                    else
                                    {
                                       LLOG(0,0,"Failed initiating DB Request SWX MAR. Sending Unexpected Data...");
                                       handleError(12, DIAM_RESULT_CODE_UNABLE_TO_COMPLY, ERROR_DIAGNOSTIC_NOT_REQUIRED);
                                       m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_RESULT_CODE_UNABLE_TO_COMPLY); 
                                    }   
                                    m_dlgStatusFlag=false;
                                    return false;
                                 }
				 
                              }
			      
                           }
                           else
                           {
                              WLOG(0,0,"No MAR message found");
                           }
                        
                        
                           }
                        }
                        break; 
                  }
                  break;

               case DIAM_EVENT_ANSWER:
                  ELOG(0,1,"Unexpected DIAM_EVENT_ANSWER received");
                  break;
               case DIAM_EVENT_TIME_OUT:
                  ELOG(0,1,"Unexpected DIAM_EVENT_TIME_OUT received");
                  m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EVENT_TIME_OUT);
                  break;
               case DIAM_EVENT_ERROR:
                  ELOG(0,1,"Unexpected DIAM_EVENT_ERROR received");
                  m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EVENT_ERROR);
                  break;
               case DIAM_EVENT_AUTH_LIFE_TIME_OUT:
                  ELOG(0,1,"Unexpected DIAM_EVENT_AUTH_LIFE_TIME_OUT received");
                  m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EVENT_AUTH_LIFE_TIME_OUT);
                  break;
               case DIAM_EVENT_AUTH_GRACE_TIME_OUT:
                  ELOG(0,1,"Unexpected DIAM_EVENT_AUTH_GRACE_TIME_OUT received");
                  m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EVENT_AUTH_GRACE_TIME_OUT);
                  break;
               case DIAM_EVENT_CORRUPTED_MSG:
                  ELOG(0,1,"Unexpected DIAM_EVENT_CORRUPTED_MSG received");
                  m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EVENT_CORRUPTED_MSG);
                  break;
               case DIAM_EVENT_ACCT_INTERIM_TIME_OUT:
                  ELOG(0,1,"Unexpected DIAM_EVENT_ACCT_INTERIM_TIME_OUT received");
                  m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_DIAM_EVENT_ACCT_INTERIM_TIME_OUT);
                  break;
               default:
                  ELOG(0,1,"UNKNOWN DIAMETER received");
                  m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_GENERAL_ERROR);
                  return false;
                  break;
            }
         }
         break;

      case MSG_TYPE_DB:
         {
            DLOG(0,0,"DB message received");

            DbQueryMsg* l_dbQueryMsgPtr = ((DbQueryMsg*)p_MsgPtr);
            switch (l_dbQueryMsgPtr->m_DbQueryType)
            {
               case 1:
                  {
                     TLOG(0,0,"Got a RetrieveSubsAuthData response");
                     if(DB_QUERY_CACHED_TYPE_CACHED == l_dbQueryMsgPtr->m_DbQueryCachedType)
                     {
                        if(MEMC_QUERY_RES_SUCCESS == l_dbQueryMsgPtr->m_MemcQueryRes)
                        {
                           m_tdr.setString(TDR_INDEX_MEMC_GET,"MCG|S");
                        }
                        else if(MEMC_QUERY_RES_FAILURE == l_dbQueryMsgPtr->m_MemcQueryRes)
                        {
                           char l_errBuff[50];
                           snprintf(l_errBuff,sizeof(l_errBuff),"MCG|F|%d|%s",l_dbQueryMsgPtr->m_MemcErrorCode,(char*)(l_dbQueryMsgPtr->m_MemcErrorMessage).c_str());
                           m_tdr.setString(TDR_INDEX_MEMC_GET,l_errBuff);
                           m_memcUpdateInd = 1;
                        }
                     }

                     if(DB_QUERY_RES_SUCCESS == l_dbQueryMsgPtr->m_DbQueryRes)
                     {
                        if(true == m_OtherImsiSubscriberFlag)
                        {
                           p_DeleteFlag=false;
                           RetrieveDirectMemcQuery *l_directMemcQuery =  new RetrieveDirectMemcQuery();
                           RetrieveSubsAuthData *l_rsad = (RetrieveSubsAuthData *)p_MsgPtr;
                           m_rsad = l_rsad;
                           snprintf(l_directMemcQuery->m_primaryImsi,sizeof(l_directMemcQuery->m_primaryImsi),"%s",l_rsad->m_primaryImsi);
                           l_directMemcQuery->m_requestNode = l_rsad->m_requestNode;
                           l_directMemcQuery->m_OtherImsiSubscriberFlag = m_OtherImsiSubscriberFlag;
                           l_directMemcQuery->m_Mcb = this;
                           l_directMemcQuery->m_MemcQueryType = MEMC_QUERY_TYPE_GET;
                           g_MemcActObj.execute(l_directMemcQuery);
                           DLOG(0,0,"Other than Home Imsi Subscriber .. pushing to MemcachedQ");
                        }
                        else if (false == handleDbResponse(p_MsgPtr))
                        {
                           if(REQUEST_ORIGIN_SS7 == m_ro)
                           {
                              CLOG(0,0,"Some Error. Closing the dlg");
                              m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_systemFailure); 
                              MapUserError l_userError(getInitialRespondingDlgId(), MAP_ERROR_systemFailure, getInitialRespondingVersion(), NULL);
                              g_sc.sendMsg(this, &l_userError);
                              MapCloseReq l_closeReq(getInitialRespondingDlgId());
                              g_sc.sendMsg(this, &l_closeReq);
                              m_dlgStatusFlag=false;
                           }
                           else
                           {
                              CLOG(0,0,"Some Error. Closing DIAMETER session");
                              //TODO:
                              handleError(12,DIAM_RESULT_CODE_UNABLE_TO_COMPLY, ERROR_DIAGNOSTIC_NOT_REQUIRED);
                              m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_RESULT_CODE_UNABLE_TO_COMPLY); 
                           }
                        }
                     }
                     else
                     {
                        m_tdr.setInteger(TDR_INDEX_DB_ERR_CODE, l_dbQueryMsgPtr->m_procErrorCode);
                        m_tdr.setString(TDR_INDEX_DB_ERR_DESC, l_dbQueryMsgPtr->m_procErrorMessage);


                        RetrieveSubsAuthData *l_rsad = (RetrieveSubsAuthData *)p_MsgPtr; // 5052A
                        if(REQUEST_ORIGIN_SS7 == m_ro)
                        {
                           if(strlen(l_rsad->m_hlrAddress) > 0)
                           {
                              sendMapOpenResponse(getInitialRespondingDlgId(), l_rsad->m_hlrAddress, g_ConfigData->i_NgConfigData.m_selfAddress.ssn);
                              m_tdr.setString(TDR_INDEX_LOCAL_ADDRESS, l_rsad->m_hlrAddress);
                              DLOG(0,0,"Sending HLRAddress[%s] for negative response",l_rsad->m_hlrAddress);
                           }
                           else
                           {
                              DLOG(0,0,"HLRAddress in NULL from DB for negative response .. taking from NgConfig");
                           }
                           if (DB_QUERY_RES_ROWS_NOT_FOUND == l_dbQueryMsgPtr->m_DbQueryRes)
                           {
                              WLOG(0,0,"Db Response %d. Subscriber not found", l_dbQueryMsgPtr->m_DbQueryRes);
                              if ( (4 ==  ((RetrieveSubsAuthData*)l_dbQueryMsgPtr)->m_errCode) &&
                                    (REQUEST_NODE_SGSN ==  ((RetrieveSubsAuthData*)l_dbQueryMsgPtr)->m_requestNode) 
                                 )
                              {
                                 OMAP3_UnknownSubscriberParam l_usp;
                                 memset(&l_usp, '\0', sizeof(l_usp));
                                 l_usp.bit_mask |= OMAP3_unknownSubscriberDiagnostic_present;
                                 l_usp.unknownSubscriberDiagnostic = OMAP3_gprsSubscriptionUnknown;
                                 m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_unknownSubscriber); 
                                 MapUserError l_userError(getInitialRespondingDlgId(), MAP_ERROR_unknownSubscriber, getInitialRespondingVersion(), &l_usp);
                                 g_sc.sendMsg(this, &l_userError);
                              }
                              else
                              {
                                 m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_unknownSubscriber); 
                                 MapUserError l_userError(getInitialRespondingDlgId(), MAP_ERROR_unknownSubscriber, getInitialRespondingVersion(), NULL);
                                 g_sc.sendMsg(this, &l_userError);
                              }
                           }
                           else
                           {
                              ELOG(0,0,"Db Response %d. Some other error", l_dbQueryMsgPtr->m_DbQueryRes);
                              m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_systemFailure); 
                              MapUserError l_userError(getInitialRespondingDlgId(), MAP_ERROR_systemFailure, getInitialRespondingVersion(), NULL);
                              g_sc.sendMsg(this, &l_userError);
                           }

                           MapCloseReq l_closeReq(getInitialRespondingDlgId());
                           g_sc.sendMsg(this, &l_closeReq);
                           m_dlgStatusFlag=false;
                        }
                        else
                        {
                           DLOG(0,0,"Need to Handle DIAMETER error here");
                           //TODO:
                           if (DB_QUERY_RES_ROWS_NOT_FOUND == l_dbQueryMsgPtr->m_DbQueryRes)
                           {
                              int l_errCode = ((RetrieveSubsAuthData*)l_dbQueryMsgPtr)->m_errCode;
                              string l_errMsg = ((RetrieveSubsAuthData*)l_dbQueryMsgPtr)->m_errMsg_DB;
                              int l_mappedErrorCode = ((RetrieveSubsAuthData*)l_dbQueryMsgPtr)->m_mappedErrCode;
                              if( !( (REQUEST_NODE_WLAN_AAA_SERVER == ((RetrieveSubsAuthData*)l_dbQueryMsgPtr)->m_requestNode) && ((5001 == l_mappedErrorCode) || (5003 == l_mappedErrorCode) || (5004 == l_mappedErrorCode) || (5005 == l_mappedErrorCode) || (5450 == l_mappedErrorCode) || (5451 == l_mappedErrorCode) || (5452 == l_mappedErrorCode) || (5453 == l_mappedErrorCode) || (5454 == l_mappedErrorCode) || (5554 == l_mappedErrorCode))) )
                              {
                                 l_mappedErrorCode = 0;
                              }
                              if(3 == ((RetrieveSubsAuthData*)l_dbQueryMsgPtr)->m_nam) //No Network is supported. Same as Unknown User
                              {
                                 handleError(12,DIAM_EXP_RESULT_CODE_ERROR_USER_UNKNOWN, ERROR_DIAGNOSTIC_NOT_REQUIRED);
                                 m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_EXP_RESULT_CODE_ERROR_USER_UNKNOWN); 
                              }
                              else if( (1 == l_errCode) || (3 == l_errCode) || (4 == l_errCode)|| (6 == l_errCode)|| (7 == l_errCode) ||
                                    (8 == l_errCode)|| (9 == l_errCode))
                              {
                                 TLOG(0,0,"AIR test m_originHost[%s] m_originRealm[%s]",m_originHost,m_originRealm);
                                 snprintf(m_originHost, sizeof(m_originHost), l_rsad->m_hssHost);
                                 snprintf(m_originRealm, sizeof(m_originRealm), l_rsad->m_hssRealm);
                                 if(((1 == l_errCode) || (8 == l_errCode) || (9 == l_errCode)) && (l_mappedErrorCode > 0) )
                                 {
                                    m_tdr.setInteger(TDR_INDEX_RESRV1, DIAM_EXP_RESULT_CODE_ERROR_USER_UNKNOWN); 
                                    handleError(12,l_mappedErrorCode, ERROR_DIAGNOSTIC_NOT_REQUIRED);
                                    m_tdr.setInteger(TDR_INDEX_ERR_CODE, l_mappedErrorCode); 
                                 }
                                 else
                                 {
                                    handleError(12,DIAM_EXP_RESULT_CODE_ERROR_USER_UNKNOWN, ERROR_DIAGNOSTIC_NOT_REQUIRED);
                                    m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_EXP_RESULT_CODE_ERROR_USER_UNKNOWN); 
                                 }
                              }
                              else if(5 == l_errCode) //LTE not present. GPRS present
                              {
                                 handleError(12,DIAM_EXP_RESULT_CODE_ERROR_UNKNOWN_EPS_SUBSCRIPTION, ERROR_DIAGNOSTIC_GPRS_DATA_SUBSCRIBED);
                                 m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_EXP_RESULT_CODE_ERROR_UNKNOWN_EPS_SUBSCRIPTION); 
                              }
                              else if(10 == l_errCode) //LTE not present. GPRS not present
                              {
                                 handleError(12,DIAM_EXP_RESULT_CODE_ERROR_UNKNOWN_EPS_SUBSCRIPTION, ERROR_DIAGNOSTIC_NO_GPRS_DATA_SUBSCRIBED);
                                 m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_EXP_RESULT_CODE_ERROR_UNKNOWN_EPS_SUBSCRIPTION); 
                              }
                              else if(11 == l_errCode) //Access Restriction
                              {
                                 handleError(12,DIAM_EXP_RESULT_CODE_AUTHORIZATION_REJECTED, ERROR_DIAGNOSTIC_NOT_REQUIRED);
                                 m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_EXP_RESULT_CODE_AUTHORIZATION_REJECTED); 
			      }
			      else if(14 == l_errCode)
			      {
				      WLOG(0,0,"SWX AAA Realm Not Configured");
                  if(l_mappedErrorCode > 0)
                  {
                     m_tdr.setInteger(TDR_INDEX_RESRV1, DIAM_EXP_RESULT_CODE_ERROR_ROAMING_NOT_ALLOWED); 
                     handleError(14,l_mappedErrorCode, ERROR_DIAGNOSTIC_NOT_REQUIRED);
                     m_tdr.setInteger(TDR_INDEX_ERR_CODE, l_mappedErrorCode); 
                  }
                  else
                  {
                     handleError(14,DIAM_EXP_RESULT_CODE_ERROR_ROAMING_NOT_ALLOWED, ERROR_DIAGNOSTIC_NOT_REQUIRED);
                     m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_EXP_RESULT_CODE_ERROR_ROAMING_NOT_ALLOWED); 
                  }
			      }
			      else if(15 == l_errCode)
			      {
				      WLOG(0,0,"SWX AAA Realm Blacklisted");
                  if(l_mappedErrorCode > 0)
                  {
                     m_tdr.setInteger(TDR_INDEX_RESRV1, DIAM_EXP_RESULT_CODE_ERROR_ROAMING_NOT_ALLOWED); 
                     handleError(15,l_mappedErrorCode, ERROR_DIAGNOSTIC_NOT_REQUIRED);
                     m_tdr.setInteger(TDR_INDEX_ERR_CODE, l_mappedErrorCode); 
                  }
                  else
                  {
                     handleError(15,DIAM_EXP_RESULT_CODE_ERROR_ROAMING_NOT_ALLOWED, ERROR_DIAGNOSTIC_NOT_REQUIRED);
                     m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_EXP_RESULT_CODE_ERROR_ROAMING_NOT_ALLOWED); 
                  }
			      }
			      else if(16 == l_errCode)
			      {
				      WLOG(0,0,"SWX Visited Network Identifier is Blacklisted");
                  if(l_mappedErrorCode > 0)
                  {
                     m_tdr.setInteger(TDR_INDEX_RESRV1, DIAM_EXP_RESULT_CODE_ERROR_ROAMING_NOT_ALLOWED); 
                     handleError(16,l_mappedErrorCode, ERROR_DIAGNOSTIC_NOT_REQUIRED);
                     m_tdr.setInteger(TDR_INDEX_ERR_CODE, l_mappedErrorCode); 
                  }
                  else
                  {
                     handleError(16,DIAM_EXP_RESULT_CODE_ERROR_ROAMING_NOT_ALLOWED, ERROR_DIAGNOSTIC_NOT_REQUIRED);
                     m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_EXP_RESULT_CODE_ERROR_ROAMING_NOT_ALLOWED); 
                  }
			      }
			      else if(17 == l_errCode)
			      {
				      WLOG(0,0,"SWX Realm/Host not Configured");
                  if(l_mappedErrorCode > 0)
                  {
                     m_tdr.setInteger(TDR_INDEX_RESRV1, DIAM_EXP_RESULT_CODE_ERROR_ROAMING_NOT_ALLOWED); 
                     handleError(17,l_mappedErrorCode, ERROR_DIAGNOSTIC_NOT_REQUIRED);
                     m_tdr.setInteger(TDR_INDEX_ERR_CODE, l_mappedErrorCode); 
                  }
                  else
                  {
                     handleError(17,DIAM_EXP_RESULT_CODE_ERROR_ROAMING_NOT_ALLOWED, ERROR_DIAGNOSTIC_NOT_REQUIRED);
                     m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_EXP_RESULT_CODE_ERROR_ROAMING_NOT_ALLOWED); 
                  }
			      }
                              else if(19 == l_errCode)
			      {
				      WLOG(0,0,"SWX IMSI Prefix Blacklisted");
                  if(l_mappedErrorCode > 0)
                  {
                     m_tdr.setInteger(TDR_INDEX_RESRV1, DIAM_EXP_RESULT_CODE_AUTHENTICATION_DATA_UNAVAILABLE); 
                     handleError(19,l_mappedErrorCode, ERROR_DIAGNOSTIC_NOT_REQUIRED);
                     m_tdr.setInteger(TDR_INDEX_ERR_CODE, l_mappedErrorCode); 
                  }
                  else
                  {
                     handleError(19,DIAM_EXP_RESULT_CODE_AUTHENTICATION_DATA_UNAVAILABLE, ERROR_DIAGNOSTIC_NOT_REQUIRED);
                     m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_EXP_RESULT_CODE_AUTHENTICATION_DATA_UNAVAILABLE); 
                  }
			      }
                              else if(20 == l_errCode)
                              {
                                 snprintf(m_originHost, sizeof(m_originHost), l_rsad->m_hssHost);
                                 snprintf(m_originRealm, sizeof(m_originRealm), l_rsad->m_hssRealm);
				      WLOG(0,0,"SWX Subscriber wifi disabled Rejecting MAR request");
                  if(l_mappedErrorCode > 0)
                  {
                     m_tdr.setInteger(TDR_INDEX_RESRV1, 5450); 
                     handleError(20,l_mappedErrorCode, ERROR_DIAGNOSTIC_NOT_REQUIRED);
                     m_tdr.setInteger(TDR_INDEX_ERR_CODE, l_mappedErrorCode); 
                  }
                  else
                  {
                     handleError(20,5450, ERROR_DIAGNOSTIC_NOT_REQUIRED);
                     m_tdr.setInteger(TDR_INDEX_ERR_CODE, 5450); 
                  }
               }            
			      else if(18 == l_errCode)
			      {
				      WLOG(0,0,"SWX Host/AAA Server Name not identical");
				      size_t l_Pos = l_errMsg.find("$");
				      if (l_Pos != string::npos)
				      {
					      if(l_Pos+1 < l_errMsg.size())
					      {
						      string l_newSer = l_errMsg.substr(l_Pos+1);
						      memset(m_AAAServerName,'\0',sizeof(m_AAAServerName));
						      snprintf(m_AAAServerName,sizeof(m_AAAServerName),"%s",l_newSer.c_str());
					      }
				      }
                  if(l_mappedErrorCode > 0)
                  {
                     m_tdr.setInteger(TDR_INDEX_RESRV1, DIAM_APP_CX_DX_EXP_RESULT_CODE_ERROR_IDENTITY_ALREADY_REGISTERED); 
                     handleError(18,l_mappedErrorCode, ERROR_DIAGNOSTIC_NOT_REQUIRED);
                     m_tdr.setInteger(TDR_INDEX_ERR_CODE, l_mappedErrorCode); 
                  }
                  else
                  {
                     handleError(18,DIAM_APP_CX_DX_EXP_RESULT_CODE_ERROR_IDENTITY_ALREADY_REGISTERED, ERROR_DIAGNOSTIC_NOT_REQUIRED);
                     m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_APP_CX_DX_EXP_RESULT_CODE_ERROR_IDENTITY_ALREADY_REGISTERED);
                  }
			      }
			      else if(701 == l_errCode)
			      {
				      WLOG(0,0,"SWX Realm/Host not Configured");
                  if(l_mappedErrorCode > 0)
                  {
                     m_tdr.setInteger(TDR_INDEX_RESRV1, DIAM_EXP_RESULT_CODE_ERROR_ROAMING_NOT_ALLOWED); 
                     handleError(701,l_mappedErrorCode, ERROR_DIAGNOSTIC_NOT_REQUIRED);
                     m_tdr.setInteger(TDR_INDEX_ERR_CODE, l_mappedErrorCode); 
                  }
                  else
                  {
                     handleError(701,DIAM_EXP_RESULT_CODE_ERROR_ROAMING_NOT_ALLOWED, ERROR_DIAGNOSTIC_NOT_REQUIRED);
                     m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_EXP_RESULT_CODE_ERROR_ROAMING_NOT_ALLOWED); 
                  }
			      }
			      else
                              {
                                 handleError(12,DIAM_EXP_RESULT_CODE_ERROR_UNKNOWN_EPS_SUBSCRIPTION, ERROR_DIAGNOSTIC_NOT_REQUIRED);
                                 m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_EXP_RESULT_CODE_ERROR_UNKNOWN_EPS_SUBSCRIPTION); 
                              }
                           }
                           else 
                           {
                              handleError(12,DIAM_EXP_RESULT_CODE_AUTHENTICATION_DATA_UNAVAILABLE, ERROR_DIAGNOSTIC_NOT_REQUIRED);
                              m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_EXP_RESULT_CODE_AUTHENTICATION_DATA_UNAVAILABLE); 
                           }
                        }
                     }
                  }
                  break;
               case 2:
                  {
                     if(DB_QUERY_CACHED_TYPE_CACHED == l_dbQueryMsgPtr->m_DbQueryCachedType)
                     {
                        if(MEMC_QUERY_RES_SUCCESS == l_dbQueryMsgPtr->m_MemcQueryRes)
                        {
                           m_tdr.setString(TDR_INDEX_MEMC_SET,((false == m_OtherImsiSubscriberFlag)?(s8*)("MCU|S"):(s8*)("MCUO|S")));
                        }
                        else if(MEMC_QUERY_RES_FAILURE == l_dbQueryMsgPtr->m_MemcQueryRes)
                        {
                           char l_errBuff[50];
                           snprintf(l_errBuff,sizeof(l_errBuff),((false == m_OtherImsiSubscriberFlag)?(s8*)("MCU|F|%d|%s"):(s8*)("MCUO|F|%d|%s")),l_dbQueryMsgPtr->m_MemcErrorCode,(char*)(l_dbQueryMsgPtr->m_MemcErrorMessage).c_str());
                           m_tdr.setString(TDR_INDEX_MEMC_SET,l_errBuff);
                        }
                     }
                     LLOG(0,0,"Got a UpdateSubsAuthData response.");
                  }
                  break;
               default:
                  {
                     ELOG(0,0,"Got an Unknown DB Response. Returning...");
                     return false;
                  }
                  break;

            }
         }
         break;

      case MSG_TYPE_TIMEOUT:
         {
            LLOG(0,0,"Timeout received %d", m_timerId);      
            m_timerId=0;                                     
            if(true == m_dlgStatusFlag)
            {
               m_tdr.setInteger(TDR_INDEX_ERR_CODE,TDR_ERROR_NOTICE_RCVD);
               m_dlgStatusFlag=false;
               LLOG(0,0,"Timeout message rcvd. Sending close.");
               MapCloseReq l_closeReq(getInitialRespondingDlgId());
               l_closeReq.m_CloseType = MAP_CLOSE_TYPE_PRE_ARRANGED_END;
               g_sc.sendMsg(this, &l_closeReq);
            }
            else
            {
               LLOG(0,0,"Timeout message rcvd. Not sending close since dialogue is already closed.");
            }
         }
      case MSG_TYPE_MEMCACHED:
         {
            DLOG(0,0,"Direct Memcached Query Response for Other than Home Imsi Subscriber");      
            MemCachedQueryMsg* l_MemcQueryMsgPtr = ((MemCachedQueryMsg*)p_MsgPtr);
            switch (l_MemcQueryMsgPtr->m_MemcQueryType)
            {
               case MEMC_QUERY_TYPE_GET:
                  {
                     RetrieveDirectMemcQuery *l_directMemcQuery = (RetrieveDirectMemcQuery *)p_MsgPtr;
                     if(MEMC_QUERY_RES_SUCCESS == l_MemcQueryMsgPtr->m_MemcQueryRes)
                     {
                        m_tdr.setString(TDR_INDEX_MEMC_GET,"MCGO|S");
                     }
                     else if(MEMC_QUERY_RES_FAILURE == l_MemcQueryMsgPtr->m_MemcQueryRes)
                     {
                        char l_errBuff[50];
                        snprintf(l_errBuff,sizeof(l_errBuff),"MCGO|F|%d|%s",l_MemcQueryMsgPtr->m_MemcErrorCode,(char*)(l_MemcQueryMsgPtr->m_MemcErrorMessage).c_str());
                        m_tdr.setString(TDR_INDEX_MEMC_GET,l_errBuff);
                        m_memcUpdateInd = 1;
                        LLOG(0,0,"Other than Home Imsi subscriber MEMCACHED_GET failed .. pushing into DBQueue")
                     }

                     memcpy(m_rsad->m_sqn, l_directMemcQuery->m_sqn, 6);

                     if (false == handleDbResponse(m_rsad))
                     {
                        if(REQUEST_ORIGIN_SS7 == m_ro)
                        {
                           CLOG(0,0,"Some Error. Closing the dlg");
                           m_tdr.setInteger(TDR_INDEX_ERR_CODE, TDR_ERROR_systemFailure); 
                           MapUserError l_userError(getInitialRespondingDlgId(), MAP_ERROR_systemFailure, getInitialRespondingVersion(), NULL);
                           g_sc.sendMsg(this, &l_userError);
                           MapCloseReq l_closeReq(getInitialRespondingDlgId());
                           g_sc.sendMsg(this, &l_closeReq);
                           m_dlgStatusFlag=false;
                        }
                        else
                        {
                           CLOG(0,0,"Some Error. Closing DIAMETER session");
                           handleError(12,DIAM_RESULT_CODE_UNABLE_TO_COMPLY, ERROR_DIAGNOSTIC_NOT_REQUIRED);
                           m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_RESULT_CODE_UNABLE_TO_COMPLY); 
                        } 
                     }
                  }
                  break;
               case MEMC_QUERY_TYPE_UPDATE:
                  {
                     // will never come here
                     if(MEMC_QUERY_RES_SUCCESS == l_MemcQueryMsgPtr->m_MemcQueryRes)
                     {
                        m_tdr.setString(TDR_INDEX_MEMC_SET,"MCUO|S");
                     }
                     else if(MEMC_QUERY_RES_FAILURE == l_MemcQueryMsgPtr->m_MemcQueryRes)
                     {
                        char l_errBuff[50];
                        snprintf(l_errBuff,sizeof(l_errBuff),"MCUO|F|%d|%s",l_MemcQueryMsgPtr->m_MemcErrorCode,(char*)(l_MemcQueryMsgPtr->m_MemcErrorMessage).c_str());
                        m_tdr.setString(TDR_INDEX_MEMC_SET,l_errBuff);
                     }
                  }
                  break;
               default:
                  DLOG(0,0,"Unknown MEMCACHED Query type received %d", l_MemcQueryMsgPtr->m_MemcQueryType);
                  break;
            }
         }

         break;

      default:
         DLOG(0,0,"Unknown message received %d", p_MsgPtr->m_MsgType);
         break;

   }
   return true;
}

bool CtxtSendAuthenticationInfo::initiateDbRequest(Msg *p_MsgPtr)
{
   // Input Parameter is the Map Specific Msg

   char l_imsi[20];
   memset(l_imsi, '\0', 20);

   bool l_resynchFlag=false;
   u8 l_resynchRand[16];
   memset(l_resynchRand, '\0', sizeof(l_resynchRand));
   u8 l_resynchAuts[14];
   memset(l_resynchAuts, '\0', sizeof(l_resynchAuts));
   ERequestingNodeType l_rnt=REQUEST_NODE_VLR;
   m_tdr.setInteger(TDR_INDEX_REQUEST_DOMAIN, 0); 

   char l_mmeOriginHost[NODE_HOST_MAX_SIZE+1];
   memset(l_mmeOriginHost, '\0', sizeof(l_mmeOriginHost));
   char l_mmeOriginRealm[NODE_REALM_MAX_SIZE+1];
   memset(l_mmeOriginRealm, '\0', sizeof(l_mmeOriginRealm));

   char l_scscfHost[NODE_HOST_MAX_SIZE+1];
   memset(l_scscfHost, '\0', sizeof(l_scscfHost));
   char l_scscfRealm[NODE_REALM_MAX_SIZE+1];
   memset(l_scscfRealm, '\0', sizeof(l_scscfRealm));

   char l_ims_pui[100+1];
   memset(l_ims_pui, '\0', sizeof(l_ims_pui));
   char l_scscf_name[100+1];
   memset(l_scscf_name, '\0', sizeof(l_scscf_name));
   char l_auth_scheme[100+1];
   memset(l_auth_scheme, '\0', sizeof(l_auth_scheme));

   char l_authorization[100+1];
   memset(l_authorization, '\0', sizeof(l_authorization));

   char l_visitedNwkID[100+1];
   memset(l_visitedNwkID, '\0', sizeof(l_visitedNwkID));


   switch(p_MsgPtr->m_MsgType)
   {
      case MSG_TYPE_MAP:
         {
            DLOG(0,0,"MAP message rcvd");

            MapSpecificIndication *l_msi = (MapSpecificIndication *)p_MsgPtr;

            switch (getInitialRespondingVersion())
            {
               case MAP_V3:
                  {
                     IMAP3_SendAuthenticationInfoArg *l_temp = (IMAP3_SendAuthenticationInfoArg*)(l_msi->m_structBuffer);
                     BCDToString((u8*)l_imsi, l_temp->imsi.value, l_temp->imsi.length);

                     if ( (l_temp->numberOfRequestedVectors < 1) || (l_temp->numberOfRequestedVectors > 5))
                     {
                        WLOG(0,0,"Wrong number of NumberOfRequestedVectors (%d). We support only 1 through 5", l_temp->numberOfRequestedVectors);
                        return false;
                     }

                     g_EmergencyFlag = g_spdPtr->m_MsisdnPrefReplaceStruct.m_CongestionEmergencyFlag;

                     m_tdr.setInteger(TDR_INDEX_NOR_VISITED_NET_ID,g_EmergencyFlag);
                     m_maxVectors = l_temp->numberOfRequestedVectors;
                     if( 1 == g_EmergencyFlag )
                     {
                        if(g_AucConfigReaderObj->m_CONGESTION_MAP3_DOWNGRADE_VECTORS > 0)
                        {
                           if(g_AucConfigReaderObj->m_CONGESTION_MAP3_DOWNGRADE_VECTORS < l_temp->numberOfRequestedVectors)
                           {
                              LLOG(0,0,"Downgrading the vectors to %d", g_AucConfigReaderObj->m_CONGESTION_MAP3_DOWNGRADE_VECTORS);
                              m_maxVectors = g_AucConfigReaderObj->m_CONGESTION_MAP3_DOWNGRADE_VECTORS;
                           }
                        }
                     }
                     else
                     {
                        if(g_AucConfigReaderObj->m_MAP3_DOWNGRADE_VECTORS > 0)
                        {
                           if(g_AucConfigReaderObj->m_MAP3_DOWNGRADE_VECTORS < l_temp->numberOfRequestedVectors)
                           {
                              LLOG(0,0,"Downgrading the vectors to %d", g_AucConfigReaderObj->m_MAP3_DOWNGRADE_VECTORS);
                              m_maxVectors = g_AucConfigReaderObj->m_MAP3_DOWNGRADE_VECTORS;
                           }
                        }
                     }
                     LLOG(0,0,"DBRES: EmergencyFlag[%d] Downgraded Vectors[%d]",g_EmergencyFlag,m_maxVectors);
                     DLOG(0,0,"#### max vectors [%d] ####",m_maxVectors);
                     m_tdr.setInteger(TDR_INDEX_AUC_NUM_VECTORS_REQUESTED, l_temp->numberOfRequestedVectors);

                     if (l_temp->bit_mask & IMAP3_re_synchronisationInfo_present)
                     {
                        m_tdr.setInteger(TDR_INDEX_AUC_RESYNC_INFO, 1);

                        TLOG(0,0,"In MAP_V3, ReSynchronization,logging statistics");
                        map<string,int>::iterator l_itr = g_globalMap.find("TotalReSynch");
                        if(l_itr != g_globalMap.end())
                        {
                           HLRStatisticsInitializer::logStatistics(l_itr->second);
                        }

                        LLOG(0,0,"Re-synchronization info present");
                        l_resynchFlag=true;
                        memcpy(l_resynchRand, l_temp->re_synchronisationInfo.rand.value, 16);
                        memcpy(l_resynchAuts, l_temp->re_synchronisationInfo.auts.value, 14);
                     }

                     if (l_temp->bit_mask & IMAP3_SendAuthenticationInfoArg_segmentationProhibited_present)
                     {
                        CLOG(0,0,"segmentationProhibited present. Sending 1 vector though request is for %d vectors", m_maxVectors);
                        m_maxVectors = 1;
                     }

                     if (l_temp->bit_mask & IMAP3_requestingNodeType_present)
                     {
                        if(IMAP3_RequestingNodeType_vlr == l_temp->requestingNodeType)
                        {
                           l_rnt = REQUEST_NODE_VLR;
                           m_tdr.setInteger(TDR_INDEX_REQUEST_DOMAIN, 0);  //0-CS
                        }
                        else
                        {
                           l_rnt = REQUEST_NODE_SGSN;
                           m_tdr.setInteger(TDR_INDEX_REQUEST_DOMAIN, 1);  //0-PS
                        }
                     }
                  }
                  break;

               case MAP_V2:
                  {
                     IMAP2_SendAuthenticationInfoArg *l_temp = (IMAP2_SendAuthenticationInfoArg*)(l_msi->m_structBuffer);
                     BCDToString((u8*)l_imsi, l_temp->value, l_temp->length);

                     m_maxVectors = g_AucConfigReaderObj->m_MAX_NUM_OF_TOTAL_VECTORS;

                  }
                  break;

               case MAP_V1:
                  {

                     IMAP1_SendParametersArg *l_temp = (IMAP1_SendParametersArg*)(l_msi->m_structBuffer);
                     if (IMAP1_SubscriberId_imsi_chosen == l_temp->subscriberId.choice)
                     {
                        DLOG(0,0,"IMSI present in send parameters");
                        BCDToString((u8*)l_imsi, l_temp->subscriberId.u.imsi.value, l_temp->subscriberId.u.imsi.length);
                     }
                     else
                     {
                        CLOG(0,0,"TMSI present in send parameters");
                        return false;
                     }

                     //for (int i=0; i<l_temp->requestParameters.count; i++)
                     {
                        switch(l_temp->requestParameters->value)
                        {
                           case IMAP1_request_IMSI:
                              DLOG(0,0,"MAP1_request_IMSI");
                              //return false;
                              break;
                           case IMAP1_request_AuthenticationSet:
                              m_v1AuthIndex=0;
                              DLOG(0,0,"MAP1_request_AuthenticationSet setting m_v1AuthIndex to %d", m_v1AuthIndex);
                              break;
                           case IMAP1_request_SubscriberData:
                              DLOG(0,0,"MAP1_request_SubscriberData");
                              //return false;
                              break;
                           case IMAP1_request_CUG_Information:
                              DLOG(0,0,"MAP1_request_CUG_Information");
                              //return false;
                              break;
                           case IMAP1_request_Ki:
                              DLOG(0,0,"MAP1_request_Ki");
                              //return false;
                              break;
                           default:
                              CLOG(0,0,"unknown request parameter");
                              return false;
                              break;
                        }
                     }

                     m_maxVectors = g_AucConfigReaderObj->m_MAX_NUM_OF_VECTORS_IN_A_CHUNK;
                  }
                  break;

               default:
                  {
                     ELOG(0,0,"Unknown Version: [%d]", getInitialRespondingVersion());
                     return false;
                  }
                  break;
            }
         }
         break;
      case MSG_TYPE_DIAMETER:
         {
            if(REQUEST_ORIGIN_DIAMETER_S6A == m_ro)
            {
               DLOG(0,0,"DIAMETER message rcvd");
               DiameterMsg *l_dm = ((DiameterMsg*)p_MsgPtr);
               diameter::s6a_r10::AuthenticationInformationRequest air(*(diameter::CommandImpl*)l_dm->m_cmd);
               diameter::s6a_r10::AuthenticationInformationRequest *l_air = &air;
               diameter::base::SessionId sess= l_air->getSessionId();

               //Decode IMSI
               diameter::base::UserName l_un = l_air->getUserName();
               if(15 != l_un.value().size())
               {
                  WLOG(0,0,"IMSI length not 15");
                  return false;
               }
               strcpy(l_imsi, l_un.value().c_str());


               const OriginHost &l_OriginHost = l_air->getOriginHost();
               if(l_OriginHost.value().size() > NODE_HOST_MAX_SIZE)
               {
                  WLOG(0,0,"Origin Host size %d is greater than the acceptable size %d", l_OriginHost.value().size(), NODE_HOST_MAX_SIZE);
                  return false;
               }
               snprintf(l_mmeOriginHost, NODE_HOST_MAX_SIZE, "%s", (l_OriginHost.value().c_str()));

               const OriginRealm &l_OriginRealm = l_air->getOriginRealm();
               if(l_OriginRealm.value().size() > NODE_REALM_MAX_SIZE)
               {
                  WLOG(0,0,"Origin Realm size %d is greater than the acceptable size %d", l_OriginRealm.value().size(), NODE_REALM_MAX_SIZE);
                  return false;
               }
               snprintf(l_mmeOriginRealm, NODE_REALM_MAX_SIZE, "%s", (l_OriginRealm.value().c_str()));

               VisitedPLMNId l_vpi = l_air->getVisitedPLMNId();
               if(l_vpi.value().size() != 3)
               {
                  WLOG(0,0,"Visited PLMN Id should be only 3 bytes, but instead it is %d bytes", l_vpi.value().size());
                  return false;
               }
               memcpy(m_vplmnId, &l_vpi.value()[0], 3);

               //Decode MME or SGSN or MME-SGSN
               if(l_air->containsRequestedEUTRANAuthenticationInfo() && l_air->containsRequestedUTRANGERANAuthenticationInfo())
               {
                  LLOG(0,0,"Requesting Node DIAM_BOTH_MME_AND_SGSN");
                  l_rnt = REQUEST_NODE_BOTH_MME_SGSN;
                  m_tdr.setInteger(TDR_INDEX_REQUEST_DOMAIN, 2);  //2-MME-SGSN
                  return false; //S6d not supported now
               }
               else if(l_air->containsRequestedEUTRANAuthenticationInfo())
               {
                  LLOG(0,0,"Requesting Node DIAM_MME");
                  l_rnt = REQUEST_NODE_MME;
                  m_tdr.setInteger(TDR_INDEX_REQUEST_DOMAIN, 3);  //3-MME
               }
               else if(l_air->containsRequestedUTRANGERANAuthenticationInfo())
               {
                  LLOG(0,0,"Requesting Node DIAM_SGSN");
                  l_rnt = REQUEST_NODE_SGSN;
                  m_tdr.setInteger(TDR_INDEX_REQUEST_DOMAIN, 4);  //4-SGSN
                  return false; //S6d not supported now
               }
               else
               {
                  WLOG(0,0,"Both are not requested.");
                  return false;
               }

               char l_requestedVectorsMmeChar[10+1];
               char l_requestedVectorsSgsnChar[10+1];

               if((REQUEST_NODE_MME == l_rnt) || (REQUEST_NODE_BOTH_MME_SGSN == l_rnt))
               {
                  RequestedEUTRANAuthenticationInfo l_reai = l_air->getRequestedEUTRANAuthenticationInfo();
                  if(l_reai.containsNumberOfRequestedVectors())
                  {
                     NumberOfRequestedVectors l_norv = l_reai.getNumberOfRequestedVectors();
                     if((l_norv.value() < 1) || (l_norv.value() > 5))
                     {
                        WLOG(0,0,"Requested Number of vectors are %d. We support only 1 through 5.", l_norv.value());
                        return false;
                     }
                     //TODO: do we need to validate?
                     m_maxVectors = l_norv.value();
                     snprintf(l_requestedVectorsMmeChar, sizeof(l_requestedVectorsMmeChar), "%d", l_norv.value());
                  }
                  else
                  {
                     WLOG(0,0,"Requested Number of vectors AVP not present.");
                     return false;

                     //m_maxVectors = 5; //TODO: is this hard-coding ok?
                     //snprintf(l_requestedVectorsMmeChar, sizeof(l_requestedVectorsMmeChar), "%c", 'N');
                  }

                  if(l_reai.containsImmediateResponsePreferred())
                  {
                     ImmediateResponsePreferred l_irp = l_reai.getImmediateResponsePreferred();
                     m_irp_mme = 1;//TODO:l_irp.value();
                  }

                  if(l_reai.containsReSynchronizationInfo())
                  {
                     m_tdr.setInteger(TDR_INDEX_AUC_RESYNC_INFO, 1);

                     TLOG(0,0,"ReSynchronization,logging statistics");
                     map<string,int>::iterator l_itr = g_globalMap.find("TotalReSynch");
                     if(l_itr != g_globalMap.end())
                     {
                        HLRStatisticsInitializer::logStatistics(l_itr->second);
                     }

                     ReSynchronizationInfo l_rsi = l_reai.getReSynchronizationInfo();
                     if(30 != l_rsi.value().size())
                     {
                        WLOG(0,0,"ReSynchronization is not 30 bytes %d", l_rsi.value().size());
                        return false;
                     }
                     l_resynchFlag=true;
                     memcpy(l_resynchRand, &l_rsi.value()[0], 16);
                     memcpy(l_resynchAuts, &l_rsi.value()[16], 14);
                     LLOG_HEX(0,0,"Re-synch RAND", l_resynchRand, 16);
                     LLOG_HEX(0,0,"Re-synch AUTS", l_resynchAuts, 14);
                  }

               }

               if((REQUEST_NODE_SGSN == l_rnt) || (REQUEST_NODE_BOTH_MME_SGSN == l_rnt))
               {
                  RequestedUTRANGERANAuthenticationInfo l_rugai = l_air->getRequestedUTRANGERANAuthenticationInfo();
                  if(l_rugai.containsNumberOfRequestedVectors())
                  {
                     NumberOfRequestedVectors l_norv = l_rugai.getNumberOfRequestedVectors();
                     snprintf(l_requestedVectorsSgsnChar, sizeof(l_requestedVectorsSgsnChar), "%d", l_norv.value());
                     //TODO: do we need to validate?
                     if(0 == m_maxVectors)
                     {
                        m_maxVectors = l_norv.value();
                     }
                     else
                     {
                        m_additionalMaxVectors = l_norv.value();
                     }
                  }
                  else
                  {
                     snprintf(l_requestedVectorsSgsnChar, sizeof(l_requestedVectorsSgsnChar), "%c", 'N');
                     if(0 == m_maxVectors)
                     {
                        m_maxVectors = 5; //TODO: is this hard-coding ok?
                     }
                     else
                     {
                        m_additionalMaxVectors = 5;
                     }
                  }

                  if((0 != m_irp_mme) && (l_rugai.containsImmediateResponsePreferred()))
                  {
                     WLOG(0,0,"Immediate-Response-Preferred should not be present in both the EUTRAN and UTRAN/GERAN");
                     return false;
                  }

                  if(l_rugai.containsImmediateResponsePreferred())
                  {
                     ImmediateResponsePreferred l_irp = l_rugai.getImmediateResponsePreferred();
                     m_irp_sgsn = 1;//TODO:l_irp.value();
                  }

                  if((true == l_resynchFlag) && l_rugai.containsReSynchronizationInfo())
                  {
                     WLOG(0,0,"Re-synchronization cannot be present in both the EUTRAN and UTRAN/GERAN");
                     return false;
                  }

                  if(l_rugai.containsReSynchronizationInfo())
                  {
                     ReSynchronizationInfo l_rsi = l_rugai.getReSynchronizationInfo();
                     if(30 != l_rsi.value().size())
                     {
                        WLOG(0,0,"ReSynchronization is not 30 bytes %d", l_rsi.value().size());
                        return false;
                     }
                     l_resynchFlag=true;
                     memcpy(l_resynchRand, &l_rsi.value()[0], 16);
                     memcpy(l_resynchAuts, &l_rsi.value()[16], 14);
                  }
               }
               char l_reqVectorsChar[20+1];
               if(REQUEST_NODE_BOTH_MME_SGSN == l_rnt)
               {
                  snprintf(l_reqVectorsChar, sizeof(l_reqVectorsChar), "%s-%s", l_requestedVectorsMmeChar, l_requestedVectorsSgsnChar);
               }
               else if(REQUEST_NODE_MME == l_rnt)
               {
                  snprintf(l_reqVectorsChar, sizeof(l_reqVectorsChar), "%s", l_requestedVectorsMmeChar);
               }
               else
               {
                  snprintf(l_reqVectorsChar, sizeof(l_reqVectorsChar), "%s", l_requestedVectorsSgsnChar);
               }
               m_tdr.setString(TDR_INDEX_AUC_NUM_VECTORS_REQUESTED, l_reqVectorsChar);
            }
            else if (REQUEST_ORIGIN_DIAMETER_CX == m_ro)  
            {
               l_rnt = REQUEST_NODE_S_CSCF;
               DLOG(0,0,"DIAMETER message Cx rcvd");
	       m_tdr.setString(TDR_INDEX_REQUEST_DOMAIN,"S-CSCF");
               DiameterMsg *l_dm = ((DiameterMsg*)p_MsgPtr);
               Cx_rel_16::MultiMediaAuthRequest mar(*(diameter::CommandImpl*)l_dm->m_cmd);
               if(((diameter::CommandImpl*)l_dm->m_cmd)->isRetransmit())
               {
                  LLOG(0,0,"Diameter Msg contains ReTransmit bit CX-MAR");
                  m_tdr.setString(TDR_INDEX_AUC_AFR_RAND,"RET");
               }
               Cx_rel_16::MultiMediaAuthRequest *l_mar = &mar;
               diameter::base::SessionId sess= l_mar->getSessionId();

               //Decode IMSI
               diameter::base::UserName l_un = l_mar->getUserName();
               strncpy(l_imsi, l_un.value().c_str(), 15);
               snprintf(m_user_name, sizeof(m_user_name), "%s", l_un.value().c_str());
               DLOG(0,0," User Name from MAR: [%s]", m_user_name);
               m_tdr.setString(TDR_INDEX_REQUEST_IMSI, l_imsi);

               Cx_rel_16::PublicIdentity l_pi = l_mar->getPublicIdentity();
               if(100 < l_pi.value().size())
               {
                  WLOG(0,0,"PUI length should not be greater than 100");
                  return false;
               }
#if 0
               if( (0 != strncmp(l_pi.value().c_str(), "tel:", 4)) && (0 != strncmp(l_pi.value().c_str(), "sip:", 4)) )
               {
                  WLOG(0,0,"Only tel: or sip: is supported");
                  return false;
               }
#endif
               snprintf(m_publicIden, sizeof(m_publicIden), "%s", (l_pi.value().c_str()));
               DLOG(0,0," Public Identity from MAR: [%s]", m_publicIden);

               strcpy(l_ims_pui, 4+l_pi.value().c_str());
               char *l_atPresent=NULL;
               l_atPresent = strstr(l_ims_pui, "@");
               int l_length=0;
               if(NULL != l_atPresent)
               {
                  l_length = strlen(l_atPresent);
                  l_ims_pui[l_pi.value().size()-l_length-4]='\0';
               }

               DLOG(0,0,"PUI: [%s]", l_ims_pui);

               const OriginHost &l_OriginHost = l_mar->getOriginHost();
               if(l_OriginHost.value().size() > NODE_HOST_MAX_SIZE)
               {
                  WLOG(0,0,"Origin Host size %d is greater than the acceptable size %d", l_OriginHost.value().size(), NODE_HOST_MAX_SIZE);
                  return false;
               }
               snprintf(l_mmeOriginHost, NODE_HOST_MAX_SIZE, "%s", (l_OriginHost.value().c_str()));

               snprintf(l_scscfHost, NODE_HOST_MAX_SIZE, "%s", (l_OriginHost.value().c_str()));
               DLOG(0,0, "Server Host AVP from MAR: [%s]", l_OriginHost.value().c_str());

               const OriginRealm &l_OriginRealm = l_mar->getOriginRealm();
               if(l_OriginRealm.value().size() > NODE_REALM_MAX_SIZE)
               {
                  WLOG(0,0,"Origin Realm size %d is greater than the acceptable size %d", l_OriginRealm.value().size(), NODE_REALM_MAX_SIZE);
                  return false;
               }
               snprintf(l_mmeOriginRealm, NODE_REALM_MAX_SIZE, "%s", (l_OriginRealm.value().c_str()));

               snprintf(l_scscfRealm, NODE_REALM_MAX_SIZE, "%s", (l_OriginRealm.value().c_str()));
               snprintf(m_domainName, NODE_REALM_MAX_SIZE, "%s", (l_OriginRealm.value().c_str()));
               DLOG(0,0, "Scscf Realm AVP from MAR: [%s]", l_OriginRealm.value().c_str());

               m_maxVectors = l_mar->getSIPNumberAuthItems().value();

               LLOG(0,0,"CX INTF MAR Max vectors [%d] ", m_maxVectors);

               m_tdr.setInteger(TDR_INDEX_AUC_NUM_VECTORS_REQUESTED, m_maxVectors);

               if((m_maxVectors < 1) || (m_maxVectors > 5))
               {
                  WLOG(0,0,"Requested Number of vectors are %d. We support only 1 through 5.", m_maxVectors);
                  return false;
               }

               Cx_rel_16::SIPAuthDataItem l_sadi = l_mar->getSIPAuthDataItem();
               if(false == l_sadi.containsSIPAuthenticationScheme())
               {
                  LLOG(0,0,"Authentication Scheme is not present");
                  return false;
               }
               snprintf(l_auth_scheme, sizeof(l_auth_scheme), "%s", l_sadi.getSIPAuthenticationScheme().value().c_str());

               LLOG(0,0,"Cx MAR Authentication Scheme %s ", l_sadi.getSIPAuthenticationScheme().value().c_str());

               if(0 == (!strcmp("Digest-AKAv1-MD5", l_sadi.getSIPAuthenticationScheme().value().c_str())))
               {  
                  LLOG(0,0,"Cx MAR received Invalid Authentication Scheme");
                  m_invalidAuthScheme = true;
                  return false;
               }  

               if(true == l_sadi.containsSIPAuthorization())
               {   
                  if(l_sadi.getSIPAuthorization().value().c_str())
                  {   
                     snprintf(l_authorization, sizeof(l_authorization), "%s", l_sadi.getSIPAuthorization().value().c_str());

                     u8 l_rand[16];
                     u8 l_auts[14];

                     memcpy(l_rand, (l_sadi.getSIPAuthorization()).value().c_str(), 16);
                     memcpy(l_auts, (l_sadi.getSIPAuthorization()).value().c_str()+16, 14);

                     l_resynchFlag=true;
                     m_tdr.setInteger(TDR_INDEX_AUC_RESYNC_INFO, 1);

                     memcpy(l_resynchRand, &l_rand[0], 16);
                     memcpy(l_resynchAuts, &l_auts[0], 14);

                     LLOG_HEX(0,0,"IMS Re-synch RAND", l_resynchRand, 16);
                     LLOG_HEX(0,0,"IMS Re-synch AUTS", l_resynchAuts, 14);
                  }
               }   

               Cx_rel_16::ServerName l_sn = l_mar->getServerName();
               snprintf(l_scscf_name, sizeof(l_scscf_name), "%s", l_sn.value().c_str());
               DLOG(0,0, "Server Name AVP from MAR: [%s]", l_sn.value().c_str());
               m_tdr.setString(TDR_INDEX_SERVER_SCSCF_NAME, (s8*)l_sn.value().c_str());
            }
            else if(REQUEST_ORIGIN_DIAMETER_SWX == m_ro)
            {
               l_rnt = REQUEST_NODE_WLAN_AAA_SERVER;
               DLOG(0,0,"DIAMETER message SWX rcvd");
	       m_tdr.setString(TDR_INDEX_REQUEST_DOMAIN,"AAA");
               DiameterMsg *l_dm = ((DiameterMsg*)p_MsgPtr);
               SWx_rel_18::MultiMediaAuthRequest mar(*(diameter::CommandImpl*)l_dm->m_cmd);
               SWx_rel_18::MultiMediaAuthRequest *l_mar = &mar;
               diameter::base::SessionId sess= l_mar->getSessionId();
               if(((diameter::CommandImpl*)l_dm->m_cmd)->isRetransmit())
               {
                  LLOG(0,0,"Diameter Msg contains ReTransmit bit SWX-MAR");
                  m_tdr.setString(TDR_INDEX_AUC_AFR_RAND,"RET");
               }
               //Decode IMSI
               diameter::base::UserName l_un = l_mar->getUserName();             
               strncpy(l_imsi, l_un.value().c_str(), 15);
               snprintf(m_user_name, sizeof(m_user_name), "%s", l_un.value().c_str());
               DLOG(0,0," User Name from MAR: [%s]", m_user_name);
               m_tdr.setString(TDR_INDEX_REQUEST_IMSI, l_imsi);

               /*SWx_rel_18::PublicIdentity l_pi = l_mar->getPublicIdentity();
               if(100 < l_pi.value().size())
               {
                  WLOG(0,0,"PUI length should not be greater than 100");
                  return false;
               }*/
#if 0
               if( (0 != strncmp(l_pi.value().c_str(), "tel:", 4)) && (0 != strncmp(l_pi.value().c_str(), "sip:", 4)) )
               {
                  WLOG(0,0,"Only tel: or sip: is supported");
                  return false;
               }
#endif
              // snprintf(m_publicIden, sizeof(m_publicIden), "%s", (l_pi.value().c_str()));
              // DLOG(0,0," Public Identity from MAR: [%s]", m_publicIden);

               /*strcpy(l_ims_pui, 4+l_pi.value().c_str());
               char *l_atPresent=NULL;
               l_atPresent = strstr(l_ims_pui, "@");AAFailureIndication
               int l_length=0;
               if(NULL != l_atPresent)
               {
                  l_length = strlen(l_atPresent);
                  l_ims_pui[l_pi.value().size()-l_length-4]='\0';
               }

               DLOG(0,0,"PUI: [%s]", l_ims_pui);*/
	       //VisitedNetworkIdentifier &l_vnid = l_mar->getVisitedNetworkIdentifier();	
	       if(true == l_mar->containsAAAFailureIndication())
	       {
		       m_AAAFailureIndication = l_mar->getAAAFailureIndication().value();
		       LLOG(0,0,"AAA_Failure_Indication AVP Found Values is [%d]",m_AAAFailureIndication);
	       } 

	       if(true == l_mar->containsVisitedNetworkIdentifier())
	       {
		       snprintf(l_visitedNwkID,sizeof(l_visitedNwkID),"%s",(l_mar->getVisitedNetworkIdentifier()).value().c_str());	
	       }

               const OriginHost &l_OriginHost = l_mar->getOriginHost();
               if(l_OriginHost.value().size() > NODE_HOST_MAX_SIZE)
               {
                  WLOG(0,0,"Origin Host size %d is greater than the acceptable size %d", l_OriginHost.value().size(), NODE_HOST_MAX_SIZE);
                  return false;
               }
               snprintf(l_mmeOriginHost, NODE_HOST_MAX_SIZE, "%s", (l_OriginHost.value().c_str()));

               snprintf(l_scscfHost, NODE_HOST_MAX_SIZE, "%s", (l_OriginHost.value().c_str()));
               snprintf(m_AAAServerName, sizeof(m_AAAServerName), "%s", (l_OriginHost.value().c_str()));
               DLOG(0,0, "Server Host AVP from MAR: [%s]", l_OriginHost.value().c_str());

               const OriginRealm &l_OriginRealm = l_mar->getOriginRealm();
               if(l_OriginRealm.value().size() > NODE_REALM_MAX_SIZE)
               {
                  WLOG(0,0,"Origin Realm size %d is greater than the acceptable size %d", l_OriginRealm.value().size(), NODE_REALM_MAX_SIZE);
                  return false;
               }
               snprintf(l_mmeOriginRealm, NODE_REALM_MAX_SIZE, "%s", (l_OriginRealm.value().c_str()));

               snprintf(l_scscfRealm, NODE_REALM_MAX_SIZE, "%s", (l_OriginRealm.value().c_str()));
               snprintf(m_domainName, NODE_REALM_MAX_SIZE, "%s", (l_OriginRealm.value().c_str()));
               DLOG(0,0, "Scscf Realm AVP from MAR: [%s]", l_OriginRealm.value().c_str());

               m_maxVectors = l_mar->getSIPNumberAuthItems().value();

               LLOG(0,0,"SWX INTF MAR Max vectors [%d] ", m_maxVectors);

               m_tdr.setInteger(TDR_INDEX_AUC_NUM_VECTORS_REQUESTED, m_maxVectors);

               if((m_maxVectors < 1) || (m_maxVectors > 5))
               {
                  WLOG(0,0,"Requested Number of vectors are %d. We support only 1 through 5.", m_maxVectors);
                  return false;
               }

               SWx_rel_18::SIPAuthDataItem l_sadi = l_mar->getSIPAuthDataItem();
               if(false == l_sadi.containsSIPAuthenticationScheme())
               {
                  LLOG(0,0,"Authentication Scheme is not present");
                  return false;
               }
               snprintf(l_auth_scheme, sizeof(l_auth_scheme), "%s", l_sadi.getSIPAuthenticationScheme().value().c_str());

               LLOG(0,0,"SWX MAR Authentication Scheme %s ", l_sadi.getSIPAuthenticationScheme().value().c_str());

               if(0 == (!strcmp("EAP-AKA", l_sadi.getSIPAuthenticationScheme().value().c_str())))
               {  
                  LLOG(0,0,"SWX MAR received Invalid Authentication Scheme");
                  m_invalidAuthScheme = true;
                  return false;
               }  

               if(true == l_sadi.containsSIPAuthorization())
               {   
                  if(l_sadi.getSIPAuthorization().value().c_str())
                  {   
                     snprintf(l_authorization, sizeof(l_authorization), "%s", l_sadi.getSIPAuthorization().value().c_str());

                     u8 l_rand[16];
                     u8 l_auts[14];

                     memcpy(l_rand, (l_sadi.getSIPAuthorization()).value().c_str(), 16);
                     memcpy(l_auts, (l_sadi.getSIPAuthorization()).value().c_str()+16, 14);

                     l_resynchFlag=true;
                     m_tdr.setInteger(TDR_INDEX_AUC_RESYNC_INFO, 1);

                     memcpy(l_resynchRand, &l_rand[0], 16);
                     memcpy(l_resynchAuts, &l_auts[0], 14);

                     LLOG_HEX(0,0,"IMS Re-synch RAND", l_resynchRand, 16);
                     LLOG_HEX(0,0,"IMS Re-synch AUTS", l_resynchAuts, 14);
                  }
               }   

            /*   SWx_rel_18::ServerName l_sn = l_mar->getServerName();
               snprintf(l_scscf_name, sizeof(l_scscf_name), "%s", l_sn.value().c_str());
               DLOG(0,0, "Server Name AVP from MAR: [%s]", l_sn.value().c_str());
               m_tdr.setString(TDR_INDEX_SERVER_SCSCF_NAME, (s8*)l_sn.value().c_str());*/

               if(l_mar->countProxyInfo() > 0)
               {
                  const ProxyInfo &l_proxyInfo = l_mar->getProxyInfo();
                  snprintf(m_proxyHost,sizeof(m_proxyHost),"%s",l_proxyInfo.getProxyHost().value().c_str());
                  snprintf(m_proxyState,sizeof(m_proxyState),"%s",l_proxyInfo.getProxyState().value().c_str());

                  LLOG(0,0,"Proxy Host [%s] Proxy State [%s]",m_proxyHost,m_proxyState);

               }
            }


         }   
         break;

      default:
         {
         }
         break;
   }


   m_rnt = l_rnt;
   m_tdr.setChar(TDR_INDEX_REQUEST_TYPE, 'I');
   m_tdr.setString(TDR_INDEX_REQUEST_IMSI, (char*)l_imsi);

   if (strlen(l_imsi) < 10)
   {
      CLOG(0,0,"IMSI <%s> Length is less than 10 digits", l_imsi);
      return false;
   }

   RetrieveSubsAuthData *l_rsad = new RetrieveSubsAuthData();

   strncpy(l_rsad->m_imsi, l_imsi,15);
   setTraceImsi(l_rsad->m_imsi);

   TLOG(0,0,"IMSI [%s]", l_rsad->m_imsi);

   l_rsad->m_cb = this;
   l_rsad->m_DbQueryType = 1;
   l_rsad->m_requestNode = l_rnt;
   l_rsad->m_msgVersion = ((int)getInitialRespondingVersion());
   l_rsad->m_maxVectors = m_maxVectors;
   l_rsad->m_Map3QuinOrTriplets = g_AucConfigReaderObj->m_MAP3_QUIN_OR_TRIPLETS;
   l_rsad->m_TestFlag           = g_AucConfigReaderObj->m_TestFlag;
   if(REQUEST_NODE_UNKNOWN != l_rnt)
   {
      strncpy(l_rsad->m_OrigAddr, m_OrigAddr, 20);
   }
   memcpy(l_rsad->m_resynchRand, l_resynchRand, 16);
   memcpy(l_rsad->m_resynchAuts, l_resynchAuts, 14);
   l_rsad->m_resynchFlag = l_resynchFlag;

   strcpy(l_rsad->m_mmeHost, l_mmeOriginHost);
   strcpy(l_rsad->m_mmeRealm, l_mmeOriginRealm);

   DLOG(0,0,"Filling db request with RequestNode [%d] ", l_rnt);
   if (g_AucConfigReaderObj == NULL)
   {
      DLOG(0,0,"Hey null");
   }
   else
   {
      DLOG(0,0,"Hey not null");
   }

   l_rsad->m_retryCount                 =g_AucConfigReaderObj->m_MAP3_LOCKED_SUBSCRIBER_RETRY_COUNT;
   l_rsad->m_retryTimer                 =g_AucConfigReaderObj->m_MAP3_LOCKED_SUBSCRIBER_RETRY_TIMER;
   l_rsad->m_multi_imsi_validation_flag =g_AucConfigReaderObj->m_MULTI_IMSI_VALIDATION_FLAG;
   l_rsad->m_subs_barred_validation_flag=g_AucConfigReaderObj->m_SUBS_BARRED_VALIDATION_FLAG;
   if(REQUEST_NODE_MME == l_rnt)
   {
      DLOG(0,0,"Filling db request for MME [%d]",l_rnt );
      l_rsad->m_requesting_node_validation_flag=g_AucConfigReaderObj->m_LTE_REQUESTING_NODE_VALIDATION_FLAG;
   }
   else if(REQUEST_NODE_S_CSCF == l_rnt)
   {
      DLOG(0,0,"Filling db request for SCSCF [%d]",l_rnt );
      l_rsad->m_requesting_node_validation_flag=g_AucConfigReaderObj->m_IMS_REQUESTING_NODE_VALIDATION_FLAG;
      snprintf(l_rsad->m_scscfHost, sizeof(l_rsad->m_scscfHost), "%s", l_scscfHost);
      snprintf(l_rsad->m_scscfRealm, sizeof(l_rsad->m_scscfRealm), "%s", l_scscfRealm);
      snprintf(l_rsad->m_scscfName, sizeof(l_rsad->m_scscfName), "%s", l_scscf_name);
      snprintf(l_rsad->m_requestNodeStr, sizeof(l_rsad->m_requestNodeStr), "%s", "S-CSCF");

      DLOG(0,0,"Filling db request for SCSCF Host [%s], SCSCF Realm [%s], SCSCF Name[%s], SCSCF Node[%s] memcachedDISABLED", l_rsad->m_scscfHost, l_rsad->m_scscfRealm, l_rsad->m_scscfName, l_rsad->m_requestNodeStr);
   }
   else if(REQUEST_NODE_WLAN_AAA_SERVER == l_rnt)
   {
      DLOG(0,0,"Filling db request for AAA_SERVER [%d]",l_rnt );
      snprintf(l_rsad->m_scscfHost, sizeof(l_rsad->m_scscfHost), "%s", l_scscfHost);
      snprintf(l_rsad->m_scscfRealm, sizeof(l_rsad->m_scscfRealm), "%s", l_scscfRealm);
      snprintf(l_rsad->m_scscfName, sizeof(l_rsad->m_scscfName), "%s", l_scscf_name);
      snprintf(l_rsad->m_requestNodeStr, sizeof(l_rsad->m_requestNodeStr), "%s", "AAA");
      snprintf(l_rsad->m_visitedNwkID_DB,sizeof(l_rsad->m_visitedNwkID_DB),"%s",l_visitedNwkID);
      l_rsad->m_AAA_Failure_Indication_DB = m_AAAFailureIndication; 
      l_rsad->m_requesting_node_validation_flag=g_AucConfigReaderObj->m_SWX_REQUESTING_NODE_VALIDATION_FLAG;
   }
   else
   {
      l_rsad->m_requesting_node_validation_flag=g_AucConfigReaderObj->m_REQUESTING_NODE_VALIDATION_FLAG;
   }

   DLOG(0,0,"Initiating AUC db request");

   int l_marMemcahceFlag = 0;
   int l_saiAirMemcachedFlag = 0;
   if(
         //((MAP_V3 == getInitialRespondingVersion()) || (REQUEST_NODE_MME == l_rsad->m_requestNode)) && 
         (1 == g_ConfigData->m_MemcEnableFlag) && 

         ( 
          (1 == g_AucConfigReaderObj->m_SAI_AIR_MemcachedFlag) || //(REQUEST_NODE_S_CSCF != l_rnt) ||
          (1 == g_AucConfigReaderObj->m_MAR_MemcachedFlag)
         )
     )
   {
      DLOG(0,0,"Inside Memcached logic");
      if( (1 == g_AucConfigReaderObj->m_MAR_MemcachedFlag) && ((REQUEST_NODE_S_CSCF == l_rnt)) )
      {
         l_marMemcahceFlag = 1;
         l_rsad->m_subs_barred_validation_flag = 1;
      }
      else if( (1 == g_AucConfigReaderObj->m_SAI_AIR_MemcachedFlag) && ( (REQUEST_NODE_S_CSCF != l_rnt) && (REQUEST_NODE_WLAN_AAA_SERVER != l_rnt) ) )
      {
         l_saiAirMemcachedFlag = 1;
      }
      DLOG(0,0,"MAR memcached flag |%d| , SAIAIR Memcached flag [%d]",l_marMemcahceFlag,l_saiAirMemcachedFlag);

      if( (1 == l_marMemcahceFlag) || (1 == l_saiAirMemcachedFlag) )
      {
         if(false == IsSubscriberOtherImsi(l_imsi))
         {
            l_rsad->m_DbQueryCachedType = DB_QUERY_CACHED_TYPE_CACHED; 
         }
         else
         {
            m_OtherImsiSubscriberFlag = true;
         }
         l_rsad->m_MemcQueryType = MEMC_QUERY_TYPE_GET;
      }
   }

   g_act.execute(l_rsad);

   DLOG(0,0,"m_MemcEnableFlag |%d|, m_SAI_AIR_MemcachedFlag |%d|, m_MAR_MemcachedFlag |%d|",g_ConfigData->m_MemcEnableFlag,g_AucConfigReaderObj->m_SAI_AIR_MemcachedFlag,g_AucConfigReaderObj->m_MAR_MemcachedFlag);

   DLOG(0,0,"returning");
   return true;
}

bool CtxtSendAuthenticationInfo::sendFurtherResponses()
{
   if(REQUEST_ORIGIN_SS7 == m_ro)
   {
      DLOG(0,0,"SS7 Sending responses...");
      switch (getInitialRespondingVersion())
      {
         case MAP_V3:
            {
               MapSpecificResult l_result(getInitialRespondingDlgId(), MAP_OP_CODE_sendAuthenticationInfo, MAP_V3);
               DECLARE(OMAP3_SendAuthenticationInfoRes, l_temp, 3, "OMAP3_SendAuthenticationInfoRes", resetStruct);
               l_temp->bit_mask = OMAP3_SendAuthenticationInfoRes_authenticationSetList_present;


               if( (3 == m_subsType) && ('Q' == g_AucConfigReaderObj->m_MAP3_QUIN_OR_TRIPLETS) )
               {
                  l_temp->authenticationSetList.choice = OMAP3_quintupletList_chosen;

                  if (m_totalSentCount < m_maxVectors)
                  {
                     int l_i, l_j;

                     for (l_i=m_totalSentCount, l_j=0;
                           (l_i<m_maxVectors) && (l_j<1); 
                           l_i++, l_j++)
                     {
                        l_temp->authenticationSetList.u.quintupletList.count++;
                        m_totalSentCount++;

                        l_temp->authenticationSetList.u.quintupletList.value[l_j].rand.length = 16; 
                        memcpy(l_temp->authenticationSetList.u.quintupletList.value[l_j].rand.value, m_vectors[l_i].m_rand, 16);
                        l_temp->authenticationSetList.u.quintupletList.value[l_j].xres.length = 8; 
                        memcpy(l_temp->authenticationSetList.u.quintupletList.value[l_j].xres.value, m_vectors[l_i].m_res, 8);
                        l_temp->authenticationSetList.u.quintupletList.value[l_j].ck.length = 16; 
                        memcpy(l_temp->authenticationSetList.u.quintupletList.value[l_j].ck.value, m_vectors[l_i].m_ck, 16);
                        l_temp->authenticationSetList.u.quintupletList.value[l_j].ik.length = 16; 
                        memcpy(l_temp->authenticationSetList.u.quintupletList.value[l_j].ik.value, m_vectors[l_i].m_ik, 16);
                        l_temp->authenticationSetList.u.quintupletList.value[l_j].autn.length = 16; 
                        memcpy(l_temp->authenticationSetList.u.quintupletList.value[l_j].autn.value, m_vectors[l_i].m_autn, 16);
                     }
                  }
               }
               else if( ('T' == g_AucConfigReaderObj->m_MAP3_QUIN_OR_TRIPLETS) || (2 == m_subsType) )
               {
                  l_temp->authenticationSetList.choice = OMAP3_tripletList_chosen;

                  if (m_totalSentCount < m_maxVectors)
                  {
                     int l_i, l_j;

                     for (l_i=m_totalSentCount, l_j=0;
                           (l_i<m_maxVectors) && (l_j<g_AucConfigReaderObj->m_MAX_NUM_OF_VECTORS_IN_A_CHUNK); 
                           l_i++, l_j++)
                     {
                        if (1 == g_AucConfigReaderObj->m_TestFlag)
                        {
                           CLOG(0,0,"Test Flag Enabled. Hard-coding Triplets...");
                           l_temp->authenticationSetList.u.tripletList.count++;
                           m_totalSentCount++;

                           l_temp->authenticationSetList.u.tripletList.value[l_j].rand.length = 16; 
                           memcpy(l_temp->authenticationSetList.u.tripletList.value[l_j].rand.value, g_test_rand, 16);
                           l_temp->authenticationSetList.u.tripletList.value[l_j].sres.length = 4; 
                           memcpy(l_temp->authenticationSetList.u.tripletList.value[l_j].sres.value, g_test_res, 4);
                           l_temp->authenticationSetList.u.tripletList.value[l_j].kc.length = 8; 
                           memcpy(l_temp->authenticationSetList.u.tripletList.value[l_j].kc.value, g_test_kc, 8);

                        }
                        else
                        {
                           l_temp->authenticationSetList.u.tripletList.count++;
                           m_totalSentCount++;

                           u8 l_res[4];
                           if(3 == m_subsType)
                           {
                              u8 l_tempChar[4];
                              memset(l_tempChar, '\0', 4);
                              for (int i=0; i<4; i++)
                              {
                                 l_res[i] = m_vectors[l_i].m_res[i] ^ m_vectors[l_i].m_res[i+4] ^ l_tempChar[i] ^ l_tempChar[i];
                              }
                           }
                           else
                           {
                              memcpy(l_res, m_vectors[l_i].m_sres, 4);
                           }

                           l_temp->authenticationSetList.u.tripletList.value[l_j].rand.length = 16; 
                           memcpy(l_temp->authenticationSetList.u.tripletList.value[l_j].rand.value, m_vectors[l_i].m_rand, 16);
                           l_temp->authenticationSetList.u.tripletList.value[l_j].sres.length = 4; 
                           memcpy(l_temp->authenticationSetList.u.tripletList.value[l_j].sres.value, l_res, 4);
                           l_temp->authenticationSetList.u.tripletList.value[l_j].kc.length = 8; 
                           memcpy(l_temp->authenticationSetList.u.tripletList.value[l_j].kc.value, m_vectors[l_i].m_kc, 8);
                        }
                     }
                  }
               }
               else
               {
                  ELOG(0,0,"Unknown m_MAP3_QUIN_OR_TRIPLETS: %c or Subs Type: %d", 
                        g_AucConfigReaderObj->m_MAP3_QUIN_OR_TRIPLETS,
                        m_subsType);
                  return false;
               }

               l_result.m_structBuffer = (void*)l_temp;
               g_sc.sendMsg(this, &l_result);

               if (m_totalSentCount < m_maxVectors)
               {
                  LLOG(0,0,"More Vectors to send. Sending MapDelimiterReq ...");
                  MapDelimiterReq l_del(getInitialRespondingDlgId());
                  g_sc.sendMsg(this, &l_del);

                  if(0 == m_timerId)
                  {
                     m_timerId = g_tm.startTimer(this, g_AucConfigReaderObj->m_MAP3_SUCCESSIVE_INVOKE_TIMEOUT);
                     if (m_timerId < 1)
                     {
                        ELOG(0,0,"Unable to set the timer value");
                     }
                     else
                     {
                        TLOG(0,0,"Set timer to %d seconds", g_AucConfigReaderObj->m_MAP3_SUCCESSIVE_INVOKE_TIMEOUT);
                     }
                  }
               }
               else
               {
                  LLOG(0,0,"Done with all the vectors. Sending MapCloseReq ...");
                  MapCloseReq l_closeReq(getInitialRespondingDlgId());
                  g_sc.sendMsg(this, &l_closeReq);
                  if (0 != m_timerId)                  
                  {                                    
                     g_tm.resetTimer(this, m_timerId); 
                     m_timerId=0;                      
                  }                                    
               }

               LLOG(0,0,"Sent %d vectors out of a total of %d new", m_totalSentCount, m_maxVectors);
               m_tdr.setInteger(TDR_INDEX_AUC_NUM_VECTORS_SENT, m_totalSentCount); 
            }
            break;

         case MAP_V2:
            {
               MapSpecificResult l_result(getInitialRespondingDlgId(), MAP_OP_CODE_sendAuthenticationInfo, MAP_V2);
               DECLARE(OMAP2_SendAuthenticationInfoRes, l_temp, 2, "OMAP2_SendAuthenticationInfoRes", resetStruct);

               if (m_totalSentCount < m_maxVectors)
               {
                  int l_i, l_j;

                  for (l_i=m_totalSentCount, l_j=0;
                        (l_i<m_maxVectors) && (l_j<g_AucConfigReaderObj->m_MAX_NUM_OF_VECTORS_IN_A_CHUNK); 
                        l_i++, l_j++)
                  {
                     if (1 == g_AucConfigReaderObj->m_TestFlag)
                     {
                        CLOG(0,0,"Test Flag Enabled. Hard-coding Triplets...");
                        l_temp->count++;
                        m_totalSentCount++;

                        l_temp->value[l_j].rand.length = 16; 
                        memcpy(l_temp->value[l_j].rand.value, g_test_rand, 16);
                        l_temp->value[l_j].sres.length = 4; 
                        memcpy(l_temp->value[l_j].sres.value, g_test_res, 4);
                        l_temp->value[l_j].kc.length = 8; 
                        memcpy(l_temp->value[l_j].kc.value, g_test_kc, 8);

                     }
                     else
                     {
                        l_temp->count++;
                        m_totalSentCount++;

                        u8 l_res[4];
                        if(3 == m_subsType)
                        {
                           u8 l_tempChar[4];
                           memset(l_tempChar, '\0', 4);
                           for (int i=0; i<4; i++)
                           {
                              l_res[i] = m_vectors[l_i].m_res[i] ^ m_vectors[l_i].m_res[i+4] ^ l_tempChar[i] ^ l_tempChar[i];
                           }
                        }
                        else
                        {
                           memcpy(l_res, m_vectors[l_i].m_sres, 4);
                        }

                        l_temp->value[l_j].rand.length = 16; 
                        memcpy(l_temp->value[l_j].rand.value, m_vectors[l_i].m_rand, 16);
                        l_temp->value[l_j].sres.length = 4; 
                        memcpy(l_temp->value[l_j].sres.value, l_res, 4);
                        l_temp->value[l_j].kc.length = 8; 
                        memcpy(l_temp->value[l_j].kc.value, m_vectors[l_i].m_kc, 8);
                     }
                  }
               }

               l_result.m_structBuffer = (void*)(l_temp);
               g_sc.sendMsg(this, &l_result);

               if (m_totalSentCount < m_maxVectors)
               {
                  LLOG(0,0,"More Vectors to send. Sending MapDelimiterReq ...");
                  MapDelimiterReq l_del(getInitialRespondingDlgId());
                  g_sc.sendMsg(this, &l_del);

                  if(0 == m_timerId)
                  {
                     m_timerId = g_tm.startTimer(this, g_AucConfigReaderObj->m_MAP3_SUCCESSIVE_INVOKE_TIMEOUT);
                     if (m_timerId < 1)
                     {
                        ELOG(0,0,"Unable to set the timer value");
                     }
                     else
                     {
                        LLOG(0,0,"Set timer to %d seconds", g_AucConfigReaderObj->m_MAP3_SUCCESSIVE_INVOKE_TIMEOUT);
                     }
                  }
               }
               else
               {
                  LLOG(0,0,"Done with all the vectors. Sending MapCloseReq ...");
                  MapCloseReq l_closeReq(getInitialRespondingDlgId());
                  g_sc.sendMsg(this, &l_closeReq);
                  if (0 != m_timerId)                  
                  {                                    
                     g_tm.resetTimer(this, m_timerId); 
                     m_timerId=0;                      
                  }                                    
               }

               LLOG(0,0,"Sent %d vectors out of a total of %d", m_totalSentCount, m_maxVectors);
               m_tdr.setInteger(TDR_INDEX_AUC_NUM_VECTORS_SENT, m_totalSentCount); 
            }
            break;

         case MAP_V1:
            {
               if ( (0 == m_v1AuthIndex) || (1 == m_v1AuthIndex) )
               {
                  MapSpecificResult l_result(getInitialRespondingDlgId(), MAP_OP_CODE_sendParameters, MAP_V1);
                  DECLARE(OMAP1_SendParametersRes, l_temp, 1, "OMAP1_SendParametersRes", resetStruct);

                  int l_i, l_j;


                  for (l_i=m_totalSentCount, l_j=0;
                        (l_i<m_maxVectors) && (l_j<g_AucConfigReaderObj->m_MAX_NUM_OF_VECTORS_IN_A_CHUNK); 
                        l_i++, l_j++)
                  {
                     DLOG(0,0,"for loop %d", l_j);
                     l_temp->sentParameters.count++;
                     l_temp->sentParameters.value[l_j].choice = OMAP1_authenticationSet_chosen;


                     if (1 == g_AucConfigReaderObj->m_TestFlag)
                     {
                        CLOG(0,0,"Test Flag Enabled. Hard-coding Triplets...");
                        m_totalSentCount++;

                        l_temp->sentParameters.value[l_j].u.authenticationSet.rand.length = 16; 
                        memcpy(l_temp->sentParameters.value[l_j].u.authenticationSet.rand.value, g_test_rand, 16);
                        l_temp->sentParameters.value[l_j].u.authenticationSet.sres.length = 4; 
                        memcpy(l_temp->sentParameters.value[l_j].u.authenticationSet.sres.value, g_test_res, 4);
                        l_temp->sentParameters.value[l_j].u.authenticationSet.kc.length = 8; 
                        memcpy(l_temp->sentParameters.value[l_j].u.authenticationSet.kc.value, g_test_kc, 8);

                     }
                     else
                     {
                        m_totalSentCount++;

                        u8 l_res[4];
                        if(3 == m_subsType)
                        {
                           u8 l_tempChar[4];
                           memset(l_tempChar, '\0', 4);
                           for (int i=0; i<4; i++)
                           {
                              l_res[i] = m_vectors[l_i].m_res[i] ^ m_vectors[l_i].m_res[i+4] ^ l_tempChar[i] ^ l_tempChar[i];
                           }
                        }
                        else
                        {
                           memcpy(l_res, m_vectors[l_i].m_sres, 4);
                        }

                        l_temp->sentParameters.value[l_j].u.authenticationSet.rand.length = 16; 
                        memcpy(l_temp->sentParameters.value[l_j].u.authenticationSet.rand.value, m_vectors[l_i].m_rand, 16);
                        l_temp->sentParameters.value[l_j].u.authenticationSet.sres.length = 4; 
                        memcpy(l_temp->sentParameters.value[l_j].u.authenticationSet.sres.value, l_res, 4);
                        l_temp->sentParameters.value[l_j].u.authenticationSet.kc.length = 8; 
                        memcpy(l_temp->sentParameters.value[l_j].u.authenticationSet.kc.value, m_vectors[l_i].m_kc, 8);
                     }
                  }

                  l_result.m_structBuffer = (void*)(l_temp);
                  g_sc.sendMsg(this, &l_result);

                  LLOG(0,0,"Done with all the vectors. Sending MapCloseReq ...");
                  MapCloseReq l_closeReq(getInitialRespondingDlgId());
                  g_sc.sendMsg(this, &l_closeReq);
                  if (0 != m_timerId)                  
                  {                                    
                     g_tm.resetTimer(this, m_timerId); 
                     m_timerId=0;                      
                  }                                    

                  LLOG(0,0,"MAPV_1 Sent %d out of %d vectors", m_totalSentCount, m_maxVectors);
                  m_tdr.setInteger(TDR_INDEX_AUC_NUM_VECTORS_SENT, m_totalSentCount); 
               }
               else
               {
                  CLOG(0,0,"No auth parameters requested. Sending abort...");
                  MapUAbortReq l_req(getInitialRespondingDlgId());
                  g_sc.sendMsg(this, &l_req);
               }
            }
            break;

         default:
            ELOG(0,0,"Default Case");
            return false;
            break;
      }
   }
   else if(REQUEST_ORIGIN_DIAMETER_S6A == m_ro)
   {
      DLOG(0,0,"DIAMETER Sending responses...");

      diameter::s6a_r10::AuthenticationInformationRequest air(*(diameter::CommandImpl*)((DiameterMsg*)m_msgPtr)->m_cmd);
      diameter::s6a_r10::AuthenticationInformationRequest *l_air = &air;
      //   AuthenticationInformationRequest *l_air = ((AuthenticationInformationRequest*)((DiameterMsg*)m_msgPtr)->m_cmd);
      const SessionId &sid1 = l_air->getSessionId();

      DiameterMsg l_answer((char*)sid1.value().c_str(), DIAM_EVENT_ANSWER, DIAM_COMM_CODE_S6A_S6D_AIR_AIA);
      diameter::s6a_r10::AuthenticationInformationAnswer l_aia;
      l_answer.m_cmd = &l_aia;

      try
      {
         const AuthSessionState &authSessState = l_air->getAuthSessionState();
         l_aia.setSessionId(sid1);
         l_aia.setSessionIndex(l_air->getSessionIndex());    
         l_aia.setAuthSessionState(authSessState); 
         diameter::base::ResultCode resultCode(2001);
         l_aia.setResultCode(resultCode);

         OriginHost originHost(m_originHost);
         l_aia.setOriginHost(originHost);

         OriginRealm originRealm(m_originRealm);
         l_aia.setOriginRealm(originRealm);


         VendorSpecificApplicationId l_vendorSpecificApplicationId1;
         VendorId l_vendorId(10415); 
         l_vendorSpecificApplicationId1.addVendorId(l_vendorId);
         AuthApplicationId l_authApplicationId(DIAM_APP_ID_S6A_S6D);
         l_vendorSpecificApplicationId1.setAuthApplicationId(l_authApplicationId);
         l_aia.setVendorSpecificApplicationId(l_vendorSpecificApplicationId1);

         diameter::s6a_r10::AuthenticationInfo l_ai;
         LLOG(0,0,"vectors %d, additional vectors %d", m_maxVectors, m_additionalMaxVectors);

         char l_resVectorsMmeChar[10+1];
         char l_resVectorsSgsnChar[10+1];
         if( (3 == m_subsType) && ('Q' == g_AucConfigReaderObj->m_MAP3_QUIN_OR_TRIPLETS) )
         {
            if (m_totalSentCount < m_maxVectors)
            {
               if((REQUEST_NODE_MME == m_rnt) || (REQUEST_NODE_BOTH_MME_SGSN == m_rnt))
               {
                  snprintf(l_resVectorsMmeChar, sizeof(l_resVectorsMmeChar), "%d", m_maxVectors);
                  for (int l_i=0; l_i<m_maxVectors; l_i++)
                  {
                     TLOG(0,0,"Adding vector %d", l_i);
                     EUTRANVector l_ev;
                     string l_rand;
                     l_rand.assign((char *)m_vectors[l_i].m_rand, 16);
                     RAND rand(l_rand);
                     l_ev.setRAND(rand);

                     string l_xres((char*)m_vectors[l_i].m_res, 8);
                     XRES xres(l_xres);
                     l_ev.setXRES(xres);

                     string l_autn((char*)m_vectors[l_i].m_autn, 16);
                     AUTN autn(l_autn);
                     l_ev.setAUTN(autn);

                     string l_kasme((char*)m_vectors[l_i].m_kasme, 32);
                     KASME kasme(l_kasme);
                     l_ev.setKASME(kasme);

                     ItemNumber l_itemNumber(1+l_i);
                     l_ev.setItemNumber(l_itemNumber);

                     l_ai.addEUTRANVector(l_ev);
                     m_totalSentCount++;
                  }
               }
               if((REQUEST_NODE_SGSN == m_rnt) || (REQUEST_NODE_BOTH_MME_SGSN == m_rnt))
               {
                  snprintf(l_resVectorsSgsnChar, sizeof(l_resVectorsSgsnChar), "%d", m_additionalMaxVectors);
                  for (int l_i=0; l_i<m_additionalMaxVectors; l_i++)
                  {
                     TLOG(0,0,"Adding vector %d", l_i);
                     UTRANVector l_uv;
                     string l_rand;
                     l_rand.assign((char *)m_vectors[l_i].m_rand, 16);
                     RAND rand(l_rand);
                     l_uv.setRAND(rand);

                     string l_xres((char*)m_vectors[l_i].m_res, 8);
                     XRES xres(l_xres);
                     l_uv.setXRES(xres);

                     string l_autn((char*)m_vectors[l_i].m_autn, 16);
                     AUTN autn(l_autn);
                     l_uv.setAUTN(autn);

                     string l_ik((char*)m_vectors[l_i].m_ik, 16);
                     IK ik(l_ik);
                     l_uv.setIK(ik);

                     string l_ck((char*)m_vectors[l_i].m_ck, 16);
                     CK ck(l_ck);
                     l_uv.setCK(ck);

                     l_ai.addUTRANVector(l_uv);
                     m_totalSentCount++;
                  }
               }
            }
         }
         else if( ('T' == g_AucConfigReaderObj->m_MAP3_QUIN_OR_TRIPLETS) || (2 == m_subsType) )
         {
            for (int l_i=0; l_i<m_maxVectors; l_i++)
            {
               TLOG(0,0,"Adding vector %d", l_i);
               GERANVector l_gv;
               string l_rand((char *)m_vectors[l_i].m_rand, 16);
               RAND rand(l_rand);
               l_gv.setRAND(rand);

               string l_sres((char*)m_vectors[l_i].m_sres, 4);
               SRES sres(l_sres);
               l_gv.setSRES(sres);

               string l_kc((char*)m_vectors[l_i].m_kc, 8);
               Kc kc(l_kc);
               l_gv.setKc(kc);

               l_ai.addGERANVector(l_gv);
               m_totalSentCount++;
            }
         }

         char l_resVectorsChar[20+1];
         if(REQUEST_NODE_BOTH_MME_SGSN == m_rnt)
         {
            snprintf(l_resVectorsChar, sizeof(l_resVectorsChar), "%s-%s", l_resVectorsMmeChar, l_resVectorsSgsnChar);
         }
         else if(REQUEST_NODE_MME == m_rnt)
         {
            snprintf(l_resVectorsChar, sizeof(l_resVectorsChar), "%s", l_resVectorsMmeChar);
         }
         else
         {
            snprintf(l_resVectorsChar, sizeof(l_resVectorsChar), "%s", l_resVectorsSgsnChar);
         }
         m_tdr.setString(TDR_INDEX_AUC_NUM_VECTORS_SENT, l_resVectorsChar);
         l_aia.setAuthenticationInfo(l_ai);

         //m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_RESULT_CODE_SUCCESS);
      }
      catch (NoSuchAttributeException e)
      {
         ELOG(0,1,"ERROR!! Exception NoSuchAttributeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
         m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_RESULT_CODE_UNABLE_TO_COMPLY); 
         return handleError(12,DIAM_RESULT_CODE_UNABLE_TO_COMPLY, ERROR_DIAGNOSTIC_NOT_REQUIRED);
      }
      catch (WrongCommandTypeException e)
      {
         ELOG(0,1,"ERROR!! Exception WrongCommandTypeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
         m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_RESULT_CODE_UNABLE_TO_COMPLY); 
         return handleError(12,DIAM_RESULT_CODE_UNABLE_TO_COMPLY, ERROR_DIAGNOSTIC_NOT_REQUIRED);
      }
      catch (UnknownTypeException e)
      {
         ELOG(0,1,"ERROR!! Exception UnknownTypeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
         m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_RESULT_CODE_UNABLE_TO_COMPLY); 
         return handleError(12,DIAM_RESULT_CODE_UNABLE_TO_COMPLY, ERROR_DIAGNOSTIC_NOT_REQUIRED);
      }
      catch (CodecException e)
      {
         ELOG(0,1,"ERROR!! Exception CodecException Caught: %s ,Error Cause: %s ",e.name(), e.what());
         m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_RESULT_CODE_UNABLE_TO_COMPLY); 
         return handleError(12,DIAM_RESULT_CODE_UNABLE_TO_COMPLY, ERROR_DIAGNOSTIC_NOT_REQUIRED);
      }
      catch (...)
      {
         ELOG(0,0,"Exception occurred while calling SendULA");
         m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_RESULT_CODE_UNABLE_TO_COMPLY); 
         return handleError(12,DIAM_RESULT_CODE_UNABLE_TO_COMPLY, ERROR_DIAGNOSTIC_NOT_REQUIRED);
      }

      g_esc.sendMsg(this, &l_answer);
   }
   else if(REQUEST_ORIGIN_DIAMETER_CX == m_ro)
   {   
      DLOG(0,0,"DIAMETER Sending responses for Cx...");

      diameter::Cx_rel_16::MultiMediaAuthRequest mar(*(diameter::CommandImpl*)((DiameterMsg*)m_msgPtr)->m_cmd);
      diameter::Cx_rel_16::MultiMediaAuthRequest *l_mar = &mar;
      //   AuthenticationInformationRequest *l_mar = ((AuthenticationInformationRequest*)((DiameterMsg*)m_msgPtr)->m_cmd);
      const SessionId &sid1 = l_mar->getSessionId();

      DiameterMsg l_answer((char*)sid1.value().c_str(), DIAM_EVENT_ANSWER, DIAM_COMM_CODE_CX_DX_MAR_MAA);
      diameter::Cx_rel_16::MutiMediaAuthAnswer l_maa;
      l_answer.m_cmd = &l_maa;

      try
      {
         const AuthSessionState &authSessState = l_mar->getAuthSessionState();
         l_maa.setSessionId(sid1);
         l_maa.setSessionIndex(l_mar->getSessionIndex());    
         l_maa.setAuthSessionState(authSessState); 
         diameter::base::ResultCode resultCode(2001);
         l_maa.setResultCode(resultCode);

         OriginHost originHost(m_originHost);
         l_maa.setOriginHost(originHost);

         OriginRealm originRealm(m_originRealm);
         l_maa.setOriginRealm(originRealm);

         VendorSpecificApplicationId l_vendorSpecificApplicationId1;
         VendorId l_vendorId(10415); 
         l_vendorSpecificApplicationId1.addVendorId(l_vendorId);
         AuthApplicationId l_authApplicationId(DIAM_APP_ID_CX_DX);
         l_vendorSpecificApplicationId1.setAuthApplicationId(l_authApplicationId);
         l_maa.setVendorSpecificApplicationId(l_vendorSpecificApplicationId1);
#if 0
         diameter::base::RouteRecord l_RouteRec(m_originHost);
         l_maa.addRouteRecord(l_RouteRec);
#endif
         Cx_rel_16::PublicIdentity l_pubId(m_publicIden);
         l_maa.setPublicIdentity(l_pubId);

#if 1
         Cx_rel_16::SupportedFeatures suppFeatures;
         diameter::base::VendorId vendorIdSup(10415);
         suppFeatures.setVendorId(vendorIdSup);

         int l_featureListId = 4;
         if(1 == m_CxFeatureListIdFlag)
         {
            l_featureListId = 1;
         }

         LLOG(0,0,"FeatureList ID [%d]",l_featureListId);
         Cx_rel_16::FeatureListID featureListId(l_featureListId);
         suppFeatures.setFeatureListID(featureListId);

         Cx_rel_16::FeatureList featureList(5);

         suppFeatures.setFeatureList(featureList);
         l_maa.addSupportedFeatures(suppFeatures);
#endif
         diameter::base::UserName l_userName(m_user_name);
         l_maa.setUserName(l_userName);

         if(1 == g_AucConfigReaderObj->m_ADD_NETWORK_ID_IN_MAA_CUSTOM_AVP_FLAG)
         {
            diameter::Cx_rel_16::PlintronNetworkId l_plinNwId(m_networkId);
            l_maa.setPlintronNetworkId(l_plinNwId);
         }   

         LLOG(0,0,"vectors %d, additional vectors %d", m_maxVectors, m_additionalMaxVectors);

         char l_resVectorsMmeChar[10+1];
         char l_resVectorsSgsnChar[10+1];
         snprintf(l_resVectorsMmeChar, sizeof(l_resVectorsMmeChar), "%d", m_maxVectors);

         diameter::Cx_rel_16::SIPNumberAuthItems l_authItems(m_maxVectors);
         l_maa.setSIPNumberAuthItems(l_authItems);

         int l_authScheme=AKA;
         for (int l_i=0; l_i<m_maxVectors; l_i++)
         {
            TLOG(0,0,"Adding vector %d", l_i);
            diameter::Cx_rel_16::SIPAuthDataItem l_sipAuthData;

            if(1 != m_maxVectors)
            {   
               diameter::Cx_rel_16::SIPItemNumber l_sipItemNo(l_i+1);
               l_sipAuthData.setSIPItemNumber(l_sipItemNo);
            }   

            diameter::Cx_rel_16::SIPAuthenticationScheme l_sipAuthScheme("Digest-AKAv1-MD5");
            l_sipAuthData.setSIPAuthenticationScheme(l_sipAuthScheme);

            //l_authScheme = SIP_DIGEST;
            l_authScheme = AKA;
            if(AKA == l_authScheme)
            {
               u8 l_randAutn[16+16];

               memset(l_randAutn, '\0', 16+16);

               /* concatenate RAND and AUTN values */
               memcpy(l_randAutn, &m_vectors[l_i].m_rand[0], 16);
               memcpy(l_randAutn+16, &m_vectors[l_i].m_autn[0], 16);

               string l_ck((char*)m_vectors[l_i].m_ck, 16);
               diameter::Cx_rel_16::ConfidentialityKey ck(l_ck);
               l_sipAuthData.setConfidentialityKey(ck);

               string l_ik((char*)m_vectors[l_i].m_ik, 16);
               diameter::Cx_rel_16::IntegrityKey ik(l_ik);
               l_sipAuthData.setIntegrityKey(ik);

               string l_randAutnStr((char*)l_randAutn, 32);
               diameter::Cx_rel_16::SIPAuthenticate authenticate(l_randAutnStr);
               l_sipAuthData.setSIPAuthenticate(authenticate);

               string l_xres((char*)m_vectors[l_i].m_res, 8);
               diameter::Cx_rel_16::SIPAuthorization authorization(l_xres);
               l_sipAuthData.setSIPAuthorization(authorization);
            }
            else if(SIP_DIGEST == l_authScheme)
            {
               if(0) //for spec
               {
                  diameter::Cx_rel_16::SIPDigestAuthenticate l_sda;
                  string l_realm;
                  l_realm.assign((char*)m_vectors[l_i].m_digest_realm);
                  diameter::Cx_rel_16::DigestRealm l_dr(l_realm);
                  l_sda.setDigestRealm(l_dr);

                  string l_algo;
                  l_algo.assign("MD5");
                  diameter::Cx_rel_16::DigestAlgorithm l_da(l_algo);
                  l_sda.setDigestAlgorithm(l_da);

#if 0
                  string l_qop_string;
                  l_qop_string.assign((char*)m_vectors[l_i].m_qop);
                  diameter::Cx_rel_16::DigestQoP l_qop(l_qop_string);
                  l_sda.setDigestQoP(l_qop);

                  string l_ha1_string;
                  l_ha1_string.assign((char*)m_vectors[l_i].m_HA1, 32);
                  diameter::Cx_rel_16::DigestHA1 l_ha(l_ha1_string);
                  l_sda.setDigestHA1(l_ha);
#endif

                  l_sipAuthData.setSIPDigestAuthenticate(l_sda);
               }
               else //TODO: for surendra
               {
                  string l_ha1_string;
                  l_ha1_string.assign((char*)m_vectors[l_i].m_HA1, 32);
                  diameter::Cx_rel_16::SIPAuthenticate authenticate(l_ha1_string);
                  l_sipAuthData.setSIPAuthenticate(authenticate);

                  diameter::Cx_rel_16::SIPAuthorization authorization(m_password);
                  l_sipAuthData.setSIPAuthorization(authorization);
               }

            }

            l_maa.addSIPAuthDataItem(l_sipAuthData);
         }

         char l_resVectorsChar[20+1];
         m_tdr.setInteger(TDR_INDEX_AUC_NUM_VECTORS_SENT, m_maxVectors);
         //m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_RESULT_CODE_SUCCESS);
      }
      catch (NoSuchAttributeException e)
      {
         ELOG(0,1,"ERROR!! Exception NoSuchAttributeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
         m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_RESULT_CODE_UNABLE_TO_COMPLY); 
         return handleError(12,DIAM_RESULT_CODE_UNABLE_TO_COMPLY, ERROR_DIAGNOSTIC_NOT_REQUIRED);
      }
      catch (WrongCommandTypeException e)
      {
         ELOG(0,1,"ERROR!! Exception WrongCommandTypeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
         m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_RESULT_CODE_UNABLE_TO_COMPLY); 
         return handleError(12,DIAM_RESULT_CODE_UNABLE_TO_COMPLY, ERROR_DIAGNOSTIC_NOT_REQUIRED);
      }
      catch (UnknownTypeException e)
      {
         ELOG(0,1,"ERROR!! Exception UnknownTypeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
         m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_RESULT_CODE_UNABLE_TO_COMPLY); 
         return handleError(12,DIAM_RESULT_CODE_UNABLE_TO_COMPLY, ERROR_DIAGNOSTIC_NOT_REQUIRED);
      }
      catch (CodecException e)
      {
         ELOG(0,1,"ERROR!! Exception CodecException Caught: %s ,Error Cause: %s ",e.name(), e.what());
         m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_RESULT_CODE_UNABLE_TO_COMPLY); 
         return handleError(12,DIAM_RESULT_CODE_UNABLE_TO_COMPLY, ERROR_DIAGNOSTIC_NOT_REQUIRED);
      }
      catch (...)
      {
         ELOG(0,0,"Exception occurred while calling SendULA");
         m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_RESULT_CODE_UNABLE_TO_COMPLY); 
         return handleError(12,DIAM_RESULT_CODE_UNABLE_TO_COMPLY, ERROR_DIAGNOSTIC_NOT_REQUIRED);
      }

      g_esc.sendMsg(this, &l_answer);
   }
   else if(REQUEST_ORIGIN_DIAMETER_SWX == m_ro)
   {
	   DLOG(0,0,"DIAMETER Sending responses for SWX...");

	   diameter::SWx_rel_18::MultiMediaAuthRequest mar(*(diameter::CommandImpl*)((DiameterMsg*)m_msgPtr)->m_cmd);
	   diameter::SWx_rel_18::MultiMediaAuthRequest *l_mar = &mar;
	   //   AuthenticationInformationRequest *l_mar = ((AuthenticationInformationRequest*)((DiameterMsg*)m_msgPtr)->m_cmd);
	   const SessionId &sid1 = l_mar->getSessionId();

	   //DiameterMsg l_answer((char*)sid1.value().c_str(), DIAM_EVENT_ANSWER, DIAM_COMM_CODE_SWX_MAR_MAA);
	   DiameterMsg l_answer((char*)sid1.value().c_str(), DIAM_EVENT_ANSWER, DIAM_COMM_CODE_CX_DX_MAR_MAA);
	   diameter::SWx_rel_18::MutiMediaAuthAnswer l_maa;
	   l_answer.m_cmd = &l_maa;

	   try
      {
         const AuthSessionState &authSessState = l_mar->getAuthSessionState();
         l_maa.setSessionId(sid1);
         l_maa.setSessionIndex(l_mar->getSessionIndex());    
         l_maa.setAuthSessionState(authSessState); 
         diameter::base::ResultCode resultCode(2001);
         l_maa.setResultCode(resultCode);

         //OriginHost originHost("cxims.mnc005.mcc206.3gppnetwork.org"); //changed since it was picking from Roam Partners S6a data
        OriginHost originHost(m_originHost); 
	l_maa.setOriginHost(originHost);

         //OriginRealm originRealm("ims.mnc005.mcc206.3gppnetwork.org"); //changed since it was picking from Roam Partners S6a data
        OriginRealm originRealm(m_originRealm); 
	l_maa.setOriginRealm(originRealm);

         VendorSpecificApplicationId l_vendorSpecificApplicationId1;
         VendorId l_vendorId(10415); 
         l_vendorSpecificApplicationId1.addVendorId(l_vendorId);
         AuthApplicationId l_authApplicationId(DIAM_APP_ID_SWX);
         l_vendorSpecificApplicationId1.setAuthApplicationId(l_authApplicationId);
         l_maa.setVendorSpecificApplicationId(l_vendorSpecificApplicationId1);
#if 0
         diameter::base::RouteRecord l_RouteRec(m_originHost);
         l_maa.addRouteRecord(l_RouteRec);
#endif
         /*Cx_rel_16::PublicIdentity l_pubId(m_publicIden);
         l_maa.setPublicIdentity(l_pubId);*/

#if 1
         SWx_rel_18::SupportedFeatures suppFeatures;
         diameter::base::VendorId vendorIdSup(10415);
         suppFeatures.setVendorId(vendorIdSup);

         SWx_rel_18::FeatureListID featureListId(4);
         suppFeatures.setFeatureListID(featureListId);

         SWx_rel_18::FeatureList featureList(5);
         suppFeatures.setFeatureList(featureList);

         l_maa.addSupportedFeatures(suppFeatures);
#endif
         diameter::base::UserName l_userName(m_user_name);
         l_maa.setUserName(l_userName);

         /*if(1 == g_AucConfigReaderObj->m_ADD_NETWORK_ID_IN_MAA_CUSTOM_AVP_FLAG)
         {
            diameter::Cx_rel_16::PlintronNetworkId l_plinNwId(m_networkId);
            l_maa.setPlintronNetworkId(l_plinNwId);
         } */  

         LLOG(0,0,"vectors %d, additional vectors %d", m_maxVectors, m_additionalMaxVectors);

         char l_resVectorsMmeChar[10+1];
         char l_resVectorsSgsnChar[10+1];
         snprintf(l_resVectorsMmeChar, sizeof(l_resVectorsMmeChar), "%d", m_maxVectors);

         diameter::SWx_rel_18::SIPNumberAuthItems l_authItems(m_maxVectors);
         l_maa.setSIPNumberAuthItems(l_authItems);

         int l_authScheme=AKA;
         for (int l_i=0; l_i<m_maxVectors; l_i++)
         {
            TLOG(0,0,"Adding vector %d", l_i);
            diameter::SWx_rel_18::SIPAuthDataItem l_sipAuthData;

            if(1 != m_maxVectors)
            {   
               diameter::SWx_rel_18::SIPItemNumber l_sipItemNo(l_i+1);
               l_sipAuthData.setSIPItemNumber(l_sipItemNo);
            }   

            diameter::SWx_rel_18::SIPAuthenticationScheme l_sipAuthScheme("EAP-AKA");
            l_sipAuthData.setSIPAuthenticationScheme(l_sipAuthScheme);

            //l_authScheme = SIP_DIGEST;
            l_authScheme = AKA;
            if(AKA == l_authScheme)
            {
               u8 l_randAutn[16+16];

               memset(l_randAutn, '\0', 16+16);

               /* concatenate RAND and AUTN values */
               memcpy(l_randAutn, &m_vectors[l_i].m_rand[0], 16);
               memcpy(l_randAutn+16, &m_vectors[l_i].m_autn[0], 16);

               string l_ck((char*)m_vectors[l_i].m_ck, 16);
               diameter::SWx_rel_18::ConfidentialityKey ck(l_ck);
               l_sipAuthData.setConfidentialityKey(ck);

               string l_ik((char*)m_vectors[l_i].m_ik, 16);
               diameter::SWx_rel_18::IntegrityKey ik(l_ik);
               l_sipAuthData.setIntegrityKey(ik);

               string l_randAutnStr((char*)l_randAutn, 32);
               diameter::SWx_rel_18::SIPAuthenticate authenticate(l_randAutnStr);
               l_sipAuthData.setSIPAuthenticate(authenticate);

               string l_xres((char*)m_vectors[l_i].m_res, 8);
               diameter::SWx_rel_18::SIPAuthorization authorization(l_xres);
               l_sipAuthData.setSIPAuthorization(authorization);
            }
            else if(SIP_DIGEST == l_authScheme)
            {
               if(0) //for spec
               {
                  diameter::SWx_rel_18::SIPDigestAuthenticate l_sda;
                  string l_realm;
                  l_realm.assign((char*)m_vectors[l_i].m_digest_realm);
                  diameter::SWx_rel_18::DigestRealm l_dr(l_realm);
                  l_sda.setDigestRealm(l_dr);

                  string l_algo;
                  l_algo.assign("MD5");
                  diameter::SWx_rel_18::DigestAlgorithm l_da(l_algo);
                  l_sda.setDigestAlgorithm(l_da);

#if 0
                  string l_qop_string;
                  l_qop_string.assign((char*)m_vectors[l_i].m_qop);
                  diameter::Cx_rel_16::DigestQoP l_qop(l_qop_string);
                  l_sda.setDigestQoP(l_qop);

                  string l_ha1_string;
                  l_ha1_string.assign((char*)m_vectors[l_i].m_HA1, 32);
                  diameter::Cx_rel_16::DigestHA1 l_ha(l_ha1_string);
                  l_sda.setDigestHA1(l_ha);
#endif

                  l_sipAuthData.setSIPDigestAuthenticate(l_sda);
               }
               else //TODO: for surendra
               {
                  string l_ha1_string;
                  l_ha1_string.assign((char*)m_vectors[l_i].m_HA1, 32);
                  diameter::SWx_rel_18::SIPAuthenticate authenticate(l_ha1_string);
                  l_sipAuthData.setSIPAuthenticate(authenticate);

                  diameter::SWx_rel_18::SIPAuthorization authorization(m_password);
                  l_sipAuthData.setSIPAuthorization(authorization);
               }

            }

            l_maa.addSIPAuthDataItem(l_sipAuthData);
         }

         if(l_mar->countProxyInfo() > 0)
         {
            ProxyInfo l_proxyInfo;
            base::ProxyHost l_proxyHost(m_proxyHost);
            l_proxyInfo.setProxyHost(l_proxyHost);
            base::ProxyState l_proxyState(m_proxyState);
            l_proxyInfo.setProxyState(l_proxyState);
            l_maa.addProxyInfo(l_proxyInfo);
         }

         char l_resVectorsChar[20+1];
         m_tdr.setInteger(TDR_INDEX_AUC_NUM_VECTORS_SENT, m_maxVectors);
         //m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_RESULT_CODE_SUCCESS);
      }
      catch (NoSuchAttributeException e)
      {
         ELOG(0,1,"ERROR!! Exception NoSuchAttributeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
         m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_RESULT_CODE_UNABLE_TO_COMPLY); 
         return handleError(12,DIAM_RESULT_CODE_UNABLE_TO_COMPLY, ERROR_DIAGNOSTIC_NOT_REQUIRED);
      }
      catch (WrongCommandTypeException e)
      {
         ELOG(0,1,"ERROR!! Exception WrongCommandTypeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
         m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_RESULT_CODE_UNABLE_TO_COMPLY); 
         return handleError(12,DIAM_RESULT_CODE_UNABLE_TO_COMPLY, ERROR_DIAGNOSTIC_NOT_REQUIRED);
      }
      catch (UnknownTypeException e)
      {
         ELOG(0,1,"ERROR!! Exception UnknownTypeException Caught: %s ,Error Cause: %s ",e.name(), e.what());
         m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_RESULT_CODE_UNABLE_TO_COMPLY); 
         return handleError(12,DIAM_RESULT_CODE_UNABLE_TO_COMPLY, ERROR_DIAGNOSTIC_NOT_REQUIRED);
      }
      catch (CodecException e)
      {
         ELOG(0,1,"ERROR!! Exception CodecException Caught: %s ,Error Cause: %s ",e.name(), e.what());
         m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_RESULT_CODE_UNABLE_TO_COMPLY); 
         return handleError(12,DIAM_RESULT_CODE_UNABLE_TO_COMPLY, ERROR_DIAGNOSTIC_NOT_REQUIRED);
      }
      catch (...)
      {
         ELOG(0,0,"Exception occurred while calling SendULA");
         m_tdr.setInteger(TDR_INDEX_ERR_CODE, DIAM_RESULT_CODE_UNABLE_TO_COMPLY); 
         return handleError(12,DIAM_RESULT_CODE_UNABLE_TO_COMPLY, ERROR_DIAGNOSTIC_NOT_REQUIRED);
      }

      g_esc.sendMsg(this, &l_answer);

   }

   return true;
}


char *getAuthType(int p_type)
{
   switch(p_type)
   {
      case 1:
         return "COMP 128-1";
         break;
      case 2:
         return "COMP 128-2";
         break;
      case 3:
         return "COMP 128-3";
         break;
      case 4:
         return "2G GSM Milenage SRES #1";
         break;
      case 5:
         return "2G GSM Milenage SRES #2";
         break;
      case 6:
         return "3G Partly time-based General SQN)";
         break;
      case 7:
         return "3G Incremental SQN";
         break;
      case 8:
         return "3G Time-based SQN";
         break;
      default:
         return "UNKNOWN";
         break;
   }
}

char *getEncAlgo(int p_enc_algo)
{
   switch(p_enc_algo)
   {
      case 0:
         return "Not-Encrypted";
      case 1:
         return "DES";
      case 2:
         return "Triple-DES";
      case 3:
         return "AES";
      default:
         return "Unknown";
   }
}

char *getEncMode(int p_enc_mode)
{
   switch(p_enc_mode)
   {
      case 0:
         return "ECB";
      case 1:
         return "CBC";
      case 2:
         return "CFB";
      case 3:
         return "NOFB";
      default:
         return "Unknown";
   }
}


bool CtxtSendAuthenticationInfo::handleDbResponse(Msg *p_MsgPtr)
{
   //RetrieveSubsAuthData *l_rsad = (RetrieveSubsAuthData *)p_MsgPtr;
   RetrieveSubsAuthData *l_rsad = NULL;

   if(true == m_OtherImsiSubscriberFlag)
   {
      l_rsad = m_rsad;
      DLOG(0,0,"direct memcached get and regular db update case .. copying m_rsad");
   }
   else
   {
      l_rsad  = (RetrieveSubsAuthData *)p_MsgPtr;

      m_networkId = l_rsad->m_networkId;

      map<int,ImsProf> :: iterator imsProfileItr;
      imsProfileItr = g_spdPtr->m_imsProfMap.find(l_rsad->m_imsProfId);
      m_CxFeatureListIdFlag = imsProfileItr->second.m_CxFeatureListIdFlag;

      TLOG(0,0," CxFeatureListId Flag [%d]",m_CxFeatureListIdFlag);

#if 0
      snprintf(m_user_name, sizeof(m_user_name), "%s@%s", l_rsad->m_primaryImsi, m_domainName);
      snprintf(m_publicIden, sizeof(m_publicIden), "sip:%s@%s", l_rsad->m_primaryImsi, m_domainName);
      DLOG(0,0," IMSI from DB: [%s]", m_user_name);
      m_tdr.setString(TDR_INDEX_REQUEST_IMSI, (char*)l_rsad->m_primaryImsi);
#endif

      int l_marMemcahceFlag = 0;
      int l_saiAirMemcachedFlag = 0;
      if(
            (1 == g_ConfigData->m_MemcEnableFlag) && 
            (
             (1 == g_AucConfigReaderObj->m_SAI_AIR_MemcachedFlag) || // && (REQUEST_NODE_S_CSCF != l_rsad->m_requestNode)
             (1 == g_AucConfigReaderObj->m_MAR_MemcachedFlag)
            ) 
        )
      {
         DLOG(0,0,"Inside Memcached logic");
         if( (1 == g_AucConfigReaderObj->m_MAR_MemcachedFlag) && ((REQUEST_NODE_S_CSCF == l_rsad->m_requestNode) ))
         {
            l_marMemcahceFlag = 1;
         }
         else if( (1 == g_AucConfigReaderObj->m_SAI_AIR_MemcachedFlag) && ( (REQUEST_NODE_S_CSCF != l_rsad->m_requestNode) && (REQUEST_NODE_WLAN_AAA_SERVER != l_rsad->m_requestNode)))
         {
            l_saiAirMemcachedFlag = 1;
         }
         DLOG(0,0,"MAR memcached flag |%d| , SAIAIR Memcached flag [%d]",l_marMemcahceFlag,l_saiAirMemcachedFlag);
         if( (1 == l_marMemcahceFlag) || (1 == l_saiAirMemcachedFlag) )
         {
            if(0 != l_rsad->m_RoamPartnerId)
            {
               l_rsad->m_RoamPartnerId = 0; // hardcoding for home
               l_rsad->m_imsiType = 0; // hardcoding for home

               map<int, HlrNetworks* > :: iterator l_HlrNetworksDetailsIter;
               l_HlrNetworksDetailsIter = g_spdPtr->m_HlrNetworks.find(l_rsad->m_networkId);
               if(l_HlrNetworksDetailsIter != g_spdPtr->m_HlrNetworks.end())
               {
                  if(REQUEST_NODE_MME == l_rsad->m_requestNode)
                  {
                     snprintf(l_rsad->m_hssHost,sizeof(l_rsad->m_hssHost),"%s",(l_HlrNetworksDetailsIter->second)->m_hssOrigHost);
                     snprintf(l_rsad->m_hssRealm,sizeof(l_rsad->m_hssRealm),"%s",(l_HlrNetworksDetailsIter->second)->m_hssOrigRealm);
                     DLOG(0,0,"FIRST_ROAM_TO_HOME: NetworkId Present in HlrNetworks map, filling HSS HOST[%s] and REALM[%s]",l_rsad->m_hssHost,l_rsad->m_hssRealm);
                  }
                  else
                  {
                     snprintf(l_rsad->m_hlrAddress,sizeof(l_rsad->m_hlrAddress),"%s",(l_HlrNetworksDetailsIter->second)->m_hlrAddr);
                     DLOG(0,0,"FIRST_ROAM_TO_HOME: NetworkId Present in HlrNetworks map, filling HLR Address[%s]",l_rsad->m_hlrAddress);
                  }
               }
               else
               {
                  CLOG(0,0,"FIRST_ROAM_TO_HOME:NetworkId[%d] Not Present in HlrNetworks map",l_rsad->m_networkId);
               }
            }
         }
      }
   }

   TLOG(0,0,"NetworkId is |%d| AucTemplateId is |%d| RoamPartnerId is |%d|", l_rsad->m_networkId, l_rsad->m_AucTemplateId, l_rsad->m_RoamPartnerId);
   m_tdr.setInteger(TDR_INDEX_MM_NETWORK_ID, l_rsad->m_networkId);
   m_tdr.setInteger(TDR_INDEX_SI_REQ_INFO,l_rsad->m_Customized_RC_Flag); 
   DLOG(0,0,"Customized RC flag in AUC Template |%d| ",l_rsad->m_Customized_RC_Flag);
   if(l_rsad->m_Customized_RC_Flag == 0)
   {

	   l_rsad->m_R1 = 64;
	   l_rsad->m_R2 = 0;
	   l_rsad->m_R3 = 32; 
	   l_rsad->m_R4 = 64;
	   l_rsad->m_R5 = 96;
	   u8 l_def_C1[16] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}; 
	   u8 l_def_C2[16] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1};
	   u8 l_def_C3[16] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2};
	   u8 l_def_C4[16] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,4};
	   u8 l_def_C5[16] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,8};
	   memcpy(l_rsad->m_C1, l_def_C1, 16);
	   memcpy(l_rsad->m_C2, l_def_C2, 16);
	   memcpy(l_rsad->m_C3, l_def_C3, 16);
	   memcpy(l_rsad->m_C4, l_def_C4, 16);
	   memcpy(l_rsad->m_C5, l_def_C5, 16);
  
    DLOG(0,0,"Customized RC flag in AUC Template is disabled so taking default values ");
    //TLOG(0,0,"Default R1 value : %d", l_rsad->m_R1);
    //TLOG(0,0,"Default R2 value : %d", l_rsad->m_R2);
    //TLOG(0,0,"Default R3 value : %d", l_rsad->m_R3);
    //TLOG(0,0,"Default R4 value : %d", l_rsad->m_R4);
    //TLOG(0,0,"Default R5 value : %d", l_rsad->m_R5);
          
   }

   if(REQUEST_ORIGIN_SS7 == m_ro)
   {
      if (strlen(l_rsad->m_hlrAddress) > 0)
      {
         sendMapOpenResponse(getInitialRespondingDlgId(), l_rsad->m_hlrAddress, g_ConfigData->i_NgConfigData.m_selfAddress.ssn);
         m_tdr.setString(TDR_INDEX_LOCAL_ADDRESS, l_rsad->m_hlrAddress);
      }
   }
   else if((REQUEST_ORIGIN_DIAMETER_S6A == m_ro) || (REQUEST_ORIGIN_DIAMETER_CX == m_ro) || (REQUEST_ORIGIN_DIAMETER_SWX == m_ro))

   {
      snprintf(m_originHost, sizeof(m_originHost), l_rsad->m_hssHost);
      snprintf(m_originRealm, sizeof(m_originHost), l_rsad->m_hssRealm);
   }

   m_tdr.setInteger(TDR_INDEX_PARTNER_TYPE, l_rsad->m_imsiType);

   if( (NULL == l_rsad) && (p_MsgPtr->m_MsgType != MSG_TYPE_DB))
   {
      ELOG(0,0,"Severe Error!!! Db Response ptr is NULL");
      g_si.sendSnmpTrap(g_AuthRejected, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL);
      return false;
   }

   DLOG_HEX(0,0,"DB: SQN ",l_rsad->m_sqn,6);
   //DLOG_HEX(0,0,"DB: KI ",l_rsad->m_k,16);
   printHexOnDebug("K Key", (char*)l_rsad->m_k_key, l_rsad->m_k_len_key);
   printHexOnDebug("K before", (char*)l_rsad->m_k, 16);
   //printHexOnDebug("IV", (char*)l_rsad->m_iv_char, l_rsad->m_iv_len_char);

   if (0 == l_rsad->m_ki_enc_algo)
   {
      LLOG(0,0,"Non Encrypted KI");
   }
   else if ((1 == l_rsad->m_ki_enc_algo) || (2 == l_rsad->m_ki_enc_algo) || (3 == l_rsad->m_ki_enc_algo))
   {
      //if((1 == l_rsad->m_ki_enc_algo)  && (0 == l_rsad->m_ki_enc_mode))
      //{
      // printf("\n before decrypt_key \n");

      //{
      // printf("\t %x ", l_rsad->m_k[i]);
      //}   
      //TLOG(0,0,"DES Encrypted KI");
      //DesCodec l_des;
      //unsigned char l_Encrypted[16];
      //memcpy(l_Encrypted, l_rsad->m_k, 16);
      //l_des.decrypt((unsigned char *)l_rsad->m_k, (unsigned char *)l_Encrypted, (unsigned char *)(l_rsad->m_k_key));

      //printf("\n after decrypted_key \n");
      //for(int i =0;i<16;i++)
      //{
      //printf("\t %x ", l_rsad->m_k[i]);
      //}   
      //}
      //else
      TLOG(0,0,"Encrypted KI. EncAlgo:%s, EncMode:%s", getEncAlgo(l_rsad->m_ki_enc_algo), getEncMode(l_rsad->m_ki_enc_mode));
      DesCodec l_des;
      unsigned char l_Encrypted[16];
      memcpy(l_Encrypted, l_rsad->m_k, 16);
      printHexOnDebug("##### BEFORE: K ", (char*)l_rsad->m_k, 16);
      printHexOnDebug("##### BEFORE: KEY ", (char*)l_rsad->m_k_key, l_rsad->m_k_len_key);
      DLOG(0,0,"##### BEFORE: m_ki_enc_algo[%d] m_ki_enc_mode[%d]", l_rsad->m_ki_enc_algo, l_rsad->m_ki_enc_mode);
      l_des.decryptData((unsigned char *)l_rsad->m_k, 
            (unsigned char *)l_Encrypted, 
            l_rsad->m_ki_enc_algo,
            (unsigned char *)(l_rsad->m_k_key),
            l_rsad->m_k_len_key,
            l_rsad->m_iv_char,
            l_rsad->m_iv_len_char,
            l_rsad->m_ki_enc_mode,
            0);
      printHexOnDebug("##### AFTER: K ", (char*)l_rsad->m_k, 16);
      printHexOnDebug("##### AFTER: KEY ", (char*)l_rsad->m_k_key, l_rsad->m_k_len_key);
      //DLOG_HEX(0,0,"DB: Testing KI ",l_rsad->m_k,16);
      //DLOG_HEX(0,0,"DB: Testing Key ",l_rsad->m_k_key,l_rsad->m_k_len_key);
      DLOG(0,0,"##### AFTER: m_ki_enc_algo[%d] m_ki_enc_mode[%d]", l_rsad->m_ki_enc_algo, l_rsad->m_ki_enc_mode);
   }
   else
   {
      ELOG(0,0,"Error!! KI Encryption Algorithm %d not implemented", l_rsad->m_ki_enc_algo);
      g_si.sendSnmpTrap(g_AuthRejected, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL);
      return false;
   }

   if (6 == l_rsad->m_auth_algo)
   {
      DLOG(0,0,"AuthAlgo is 6. Setting subs type to 3");
      m_subsType=3;
   }
   else if (5 == l_rsad->m_auth_algo)
   {
      DLOG(0,0,"AuthAlgo is 5. Setting subs type to 2");
      m_subsType=2;
   }
   else if (4 == l_rsad->m_auth_algo)
   {
      DLOG(0,0,"AuthAlgo is 4. Setting subs type to 2");
      m_subsType=2;
   }
   else  if( (2 == l_rsad->m_auth_algo) || (3 == l_rsad->m_auth_algo) )
   {
      m_subsType=2;
   }
   else
   {
      ELOG(0,0,"Error!! Authentication Algorithm %d not implemented", l_rsad->m_auth_algo);
      return false;
   }

   if ((l_rsad->m_subsType != 2) && (l_rsad->m_subsType != 3) )
   {
      ELOG(0,0,"Error!! Subscriber type %d not implemented", l_rsad->m_subsType);
      g_si.sendSnmpTrap(g_AuthRejected, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL);
      return false;
   }


   if((REQUEST_NODE_MME == m_rnt) && (2 == m_subsType))
   {
      ELOG(0,0,"ERROR! Subscriber configured as 2G algorithm. But received a request from an MME");
      g_si.sendSnmpTrap(g_AuthRejected, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL);
      return false;
   }


   if(REQUEST_NODE_MME == m_rnt)
   {
      if (g_amf_env != NULL) 
      {
         if(1 == atoi(g_amf_env))
         {
         printHexOnDebug("DB: AMF for testing ", (char*)l_rsad->m_amf, 2);
	 //DLOG_HEX(0, 0, "DB: AMF ", l_rsad->m_amf, 2);
         }
      } 
      else
      {
         printHexOnDebug("AMF before ", (char*)l_rsad->m_amf, 2);
	 TLOG(0,0,"Enabling the seperation bit in the AMF");
	 l_rsad->m_amf[0] = l_rsad->m_amf[0] |= 0x80;
	 printHexOnDebug("AMF after ", (char*)l_rsad->m_amf, 2);
      }
   }


   printHexOnDebug("K after", (char*)l_rsad->m_k, 16);


   if (strlen(l_rsad->m_msisdn) > 1)
   {
      setTraceMsisdn(l_rsad->m_msisdn);
      m_tdr.setString(TDR_INDEX_MM_PRIMARY_MSISDN, (char*)l_rsad->m_msisdn);
   }
#if 0
   if(REQUEST_NODE_S_CSCF == m_rnt)
   {
      LLOG(0,0,"Processing the MD5 algo");
      //m_maxVectors=1;
      for (int l_i=0; l_i<m_maxVectors; l_i++)
      {
         if (1 == g_AucConfigReaderObj->m_RandFlag)
         {
            memcpy(m_vectors[l_i].m_rand, g_test_rand, 16);
            LLOG(0,0,"Test Flag is enabled. Taking RAND hardcoded");
            strcpy(l_rsad->m_imsi, "Mufasa");
         }
         else // To change the rand
         {
            int l_rand1 = rand();
            memcpy((m_vectors[l_i].m_digest_rand), &l_rand1, 4);
            int l_rand2 = rand();
            memcpy((m_vectors[l_i].m_digest_rand)+4, &l_rand2, 4);
            int l_rand3 = rand();
            memcpy((m_vectors[l_i].m_digest_rand)+8, &l_rand3, 4);
            int l_rand4 = rand();
            memcpy((m_vectors[l_i].m_digest_rand)+12, &l_rand4, 4);
         }
         LLOG(0,0,"Generating %d vector", 1+l_i);
         unsigned char HA1[32+1];
         memset(HA1, '\0', sizeof(HA1));
         LLOG_HEX(0,0,"Digest RAND", m_vectors[l_i].m_digest_rand, 16);
         LLOG_HEX(0,0,"Digest Key", l_rsad->m_digest_key, l_rsad->m_digest_key_len);
         m_password.assign((char*)l_rsad->m_digest_key, l_rsad->m_digest_key_len);
         LLOG(0,0,"QoP:[%s] IMS-Digest-Realm:[%s] User[%s]", l_rsad->m_digest_qop, l_rsad->m_ims_digest_realm, m_user_name);
         DigestCalcHA1("md5", m_user_name, l_rsad->m_ims_digest_realm, (char*)l_rsad->m_digest_key, 
               (char*)m_vectors[l_i].m_digest_rand,"0a4f113b", HA1);
         LLOG(0,0,"HA1: %s", HA1);
         memcpy(m_vectors[l_i].m_HA1, HA1, 32);
         snprintf((char*)m_vectors[l_i].m_digest_realm, sizeof(m_vectors[l_i].m_digest_realm), "%s", l_rsad->m_ims_digest_realm);
         snprintf((char*)m_vectors[l_i].m_qop, sizeof(m_vectors[l_i].m_qop), "%s", l_rsad->m_digest_qop);
      }

   }
#endif
   //m_rsad = l_rsad;


   if (g_op_env != NULL) 
   {
      u8 l_fixed_op[16];                                //OP for Testing 
      for (int i = 0; i < 16; i++) 
      {
         sscanf(&g_op_env[i * 2], "%2hhx", &l_fixed_op[i]);
      }
      DLOG_HEX(0, 0, "Overriding with fixed OP from environment variable", l_fixed_op, 16);
      memcpy(g_ByteMilenageObj.m_OP, l_fixed_op, 16); 
   } 
   else
   {
      memcpy(g_ByteMilenageObj.m_OP, l_rsad->m_op, 16);
      //DLOG_HEX(0,0,"DB: OP ",l_rsad->m_op,16);
   }


   //unsigned int l_presentSeq1 =0;
   //unsigned int l_presentSeq2 =0;

   u8 l_previousSqn[6];

   if( ( (MAP_V3 == getInitialRespondingVersion()) &&\
            ('Q' == g_AucConfigReaderObj->m_MAP3_QUIN_OR_TRIPLETS) &&\
            (3 == m_subsType) ) ||\
         (REQUEST_NODE_MME == l_rsad->m_requestNode) ||\
         (REQUEST_NODE_S_CSCF == l_rsad->m_requestNode)||\
         (REQUEST_NODE_WLAN_AAA_SERVER == l_rsad->m_requestNode))
      // Perform SQN Calculation only for V3
   {
      //Retrieving Previous SQN


      if (l_rsad->m_resynchFlag)
      {
         printHexOnDebug("Resynch RAND ", (char*)l_rsad->m_resynchRand, 16);
         printHexOnDebug("Resynch AUTS ", (char*)l_rsad->m_resynchAuts, 14);

         u8 l_temp_sqn[6];
         bool l_resynch_status = resynchronizeFunc(l_rsad->m_amf, l_rsad->m_k, l_rsad->m_resynchRand, l_rsad->m_resynchAuts, l_temp_sqn, l_rsad->m_R1, l_rsad->m_C1,l_rsad->m_R5, l_rsad->m_C5);
         if (false == l_resynch_status)
         {
            WLOG(0,0,"AUTS verification failed. Not resetting the SQN");
            memcpy(l_previousSqn, l_rsad->m_sqn, 6);
         }
         else
         {
            LLOG(0,0,"AUTS verification passed. Resetting the SQN");
            memcpy(l_previousSqn, l_temp_sqn, 6);
         }
         printHexOnDebug("Retrieved SQN from AUTS", (char*)l_previousSqn, 6);
      }
      else
      {
         DLOG(0,0,"RetrieveSubsAuthData:: No Re-synchronisation");
         memcpy(l_previousSqn, l_rsad->m_sqn, 6);
      }

      printHexOnDebug("Retrieved SQN : ", (char*)l_previousSqn, 6);

      //End of Retrieving Previous SQN

      // Starting below is the algorithm for SQN Generation


      /*
         if ( (l_seq2 < l_glc) &&
         (l_glc < (l_seq2 + l_p - l_D + 1)) 
         )
         {
         l_presentSeq2 = l_glc;
         l_presentSeq1 = l_seq1;
         TLOG(0,0,"SQN Generation Case 1: Present SEQ1: %d Present SEQ2: %d", l_presentSeq1, l_presentSeq2);
         }
         else if ( ((l_glc <= l_seq2) &&
         (l_seq2 <= (l_glc + l_D -1) ))  ||
         (l_seq2 + l_p - l_D + 1 <= l_glc )
         )
         {
         l_presentSeq2 = l_seq2+1;
         if (l_presentSeq2 < l_seq2) // wrap around on seq2 case
         {
         l_presentSeq1 = l_seq1+1;
         }
         else
         {
         l_presentSeq1 = l_seq1;
         }
         TLOG(0,0,"SQN Generation Case 2: Present SEQ1: %d Present SEQ2: %d", l_presentSeq1, l_presentSeq2);
         }
         else if (l_glc + l_D -1 < l_seq2)
         {
         l_presentSeq1 = l_seq1+1;
         l_presentSeq2 = l_glc;
         TLOG(0,0,"SQN Generation Case 3: Present SEQ1: %d Present SEQ2: %d", l_presentSeq1, l_presentSeq2);
         }
         else
         {
         l_presentSeq1 = l_seq1;
         l_presentSeq2 = l_seq2;
         TLOG(0,0,"SQN Generation Case 4: Present SEQ1: %d Present SEQ2: %d", l_presentSeq1, l_presentSeq2);
         }
         */

      // End of SQN Generation Algorithm Implementation

   }
   unsigned int l_seq1;
   unsigned int l_seq2;
   unsigned int l_ind;
   int l_D = 65536; 
   int l_p = 16777216;

   time_t l_epochTime = time(NULL);
   unsigned int l_glc = l_epochTime  % l_p; 
   TLOG(0,0,"Epoch Time %d   GLC %d", l_epochTime, l_glc);
   decodeSqn(l_previousSqn, &l_seq1, &l_seq2, &l_ind);
   LLOG(0,0,"type: %s, SQN Retrieved: SEQ1 : %d, SEQ2 : %d, IND : %d", (true==l_rsad->m_resynchFlag)?"RESYNCH":"NORMAL", l_seq1, l_seq2, l_ind);

   u8 l_sqn[6];
   memset(l_sqn, '\0', 6);

   
   LLOG(0,0,"Generating %s algorithm %d vector(s) ", getAuthType(l_rsad->m_auth_algo), m_maxVectors);

   int l_presentInd = 0;
   if( 0 == g_AucConfigReaderObj->m_SQN_DISTRIBUTION_FLAG)
   {
      DLOG(0,0,"SQN_DISTRIBUTION_FLAG is 0");
      if(REQUEST_NODE_VLR == l_rsad->m_requestNode) //GSM
      {
         l_presentInd = (++l_ind)%10; // This IND should be different for each vector
         LLOG(0,0,"VLR  Current Ind: %d", l_presentInd);
      }
      else if(REQUEST_NODE_SGSN == l_rsad->m_requestNode) //GPRS
      {
         l_presentInd = 10+((++l_ind)%10);
         LLOG(0,0,"SGSN Current Ind: %d", l_presentInd);
      }
      else if(REQUEST_NODE_MME == l_rsad->m_requestNode) //LTE
      {
         l_presentInd = 20+((++l_ind)%10);
         LLOG(0,0,"MME Current Ind: %d", l_presentInd);
      }
      else if(REQUEST_NODE_S_CSCF == l_rsad->m_requestNode) //IMS
      {
         //l_presentInd = 30+((++l_ind)%10);
         LLOG(0,0,"SCSCF Current Ind: %d", l_presentInd);
      }
      else if(REQUEST_NODE_WLAN_AAA_SERVER == l_rsad->m_requestNode) //SWx
      {
         //l_presentInd = 30+((++l_ind)%10);
         LLOG(0,0,"AAA-Server Current Ind: %d", l_presentInd);
      }
   }
   else if(1 == g_AucConfigReaderObj->m_SQN_DISTRIBUTION_FLAG)
   {
      DLOG(0,0,"SQN_DISTRIBUTION_FLAG is 1");
      if(REQUEST_NODE_VLR == l_rsad->m_requestNode) //GSM
      {
         l_presentInd = (++l_ind)%6; // This IND should be different for each vector
         LLOG(0,0,"VLR  Current Ind: %d", l_presentInd);
      }
      else if(REQUEST_NODE_SGSN == l_rsad->m_requestNode) //GPRS
      {
         l_presentInd = 6+((++l_ind)%6);
         LLOG(0,0,"SGSN Current Ind: %d", l_presentInd);
      }
      else if(REQUEST_NODE_MME == l_rsad->m_requestNode) //LTE
      {
         l_presentInd = 12+((++l_ind)%6);
         LLOG(0,0,"MME Current Ind: %d", l_presentInd);
      }
      else if(REQUEST_NODE_S_CSCF == l_rsad->m_requestNode) //IMS
      {
         l_presentInd = 18+((++l_ind)%6);
         LLOG(0,0,"SCSCF Current Ind: %d", l_presentInd);
      }
      else if(REQUEST_NODE_WLAN_AAA_SERVER == l_rsad->m_requestNode) //SWx
      {
         l_presentInd = 24+((++l_ind)%6);
         LLOG(0,0,"AAA-Server Current Ind: %d", l_presentInd);
      }
   }
   for (int l_i=0; l_i<m_maxVectors; l_i++)
   {
      LLOG(0,0,"Generating %d vector GLC: %d, SEQ1: %d, SEQ2: %d", 1+l_i, l_glc, l_seq1, l_seq2);
      if( ((MAP_V3 == getInitialRespondingVersion()) &&
               ('Q' == g_AucConfigReaderObj->m_MAP3_QUIN_OR_TRIPLETS) &&
               (3 == m_subsType)) ||
            (REQUEST_NODE_MME == l_rsad->m_requestNode)||\
            (REQUEST_NODE_S_CSCF == l_rsad->m_requestNode)||\
            (REQUEST_NODE_WLAN_AAA_SERVER == l_rsad->m_requestNode))
         // Perform SQN Calculation only for V3
      {
         if ( (l_seq2 < l_glc) &&
               (l_glc < (l_seq2 + l_p - l_D + 1)) 
            )
         {
            //l_presentSeq2 = l_glc;
            //l_presentSeq1 = l_seq1;
            l_seq2 = l_glc;
            l_seq1 = l_seq1;
            LLOG(0,0,"SQN Generation Case 1: Present SEQ1: %d Present SEQ2: %d", l_seq1, l_seq2);
         }
         else if ( ((l_glc <= l_seq2) &&
                  (l_seq2 <= (l_glc + l_D -1) ))  ||
               (l_seq2 + l_p - l_D + 1 <= l_glc )
               )
         {
            l_seq2 = l_seq2+1;
            if (l_seq2 < l_seq2) // wrap around on seq2 case
            {
               l_seq1 = l_seq1+1;
            }
            else
            {
               l_seq1 = l_seq1;
            }
            LLOG(0,0,"SQN Generation Case 2: Present SEQ1: %d Present SEQ2: %d", l_seq1, l_seq2);
         }
         else if (l_glc + l_D -1 < l_seq2)
         {
            l_seq1 = l_seq1+1;
            l_seq2 = l_glc;
            LLOG(0,0,"SQN Generation Case 3: Present SEQ1: %d Present SEQ2: %d", l_seq1, l_seq2);
         }
         else
         {
            l_seq1 = l_seq1;
            l_seq2 = l_seq2;
            LLOG(0,0,"SQN Generation Case 4: Present SEQ1: %d Present SEQ2: %d", l_seq1, l_seq2);
         }
         if(1 == g_AucConfigReaderObj->m_TestFlag)
         {
            l_seq1=1000;
            l_seq2=7000;
            l_presentInd=9;
            LLOG(0,0,"Hardcoding SEQ1:%d, SEQ2:%d, Ind:%d", l_seq1, l_seq2, l_presentInd);
         }
         calculateSqn(l_sqn, l_seq1, l_seq2, l_presentInd);
         LLOG_HEX(0,0,"SQN HERE", l_sqn, 6);

         if (1 == g_AucConfigReaderObj->m_TestFlag) // testing sqn
         {
            LLOG(0,0,"Test Flag is enabled. Taking SQN hardcoded");
            //memcpy(l_sqn, g_sqn, 6);
         }
      }
      else
      {
      }   

      if (g_sqn_env != NULL) 
      {
         u8 l_fixed_sqn[6];                                //SQN for Testing 
         for (int i = 0; i < 6; i++) 
	 {
            sscanf(&g_sqn_env[i * 2], "%2hhx", &l_fixed_sqn[i]);
         }
         memcpy(l_sqn, l_fixed_sqn, 6); 
         DLOG_HEX(0, 0, "Overriding with fixed SQN from environment variable", l_fixed_sqn, 6);
      } 

      if (g_fixed_rand_str != NULL) 
      {
         unsigned char l_fixed_rand[16];                  //RAND for Testing
	 for (int i = 0; i < 16; ++i) 
         {
            sscanf(&g_fixed_rand_str[i * 2], "%2hhx", &l_fixed_rand[i]);
	 }

         memcpy(m_vectors[l_i].m_rand, l_fixed_rand, 16);
         DLOG_HEX(0,0,"FIXED RAND VALUE is set ",l_fixed_rand,16);
      }
      else
      {
         memcpy(m_vectors[l_i].m_rand, l_rsad->m_rand, 16);
	 //DLOG_HEX(0,0,"DB: RAND ",l_rsad->m_rand,16);
	 if (1 == g_AucConfigReaderObj->m_TestRandFlag)
	 {
	    memcpy(m_vectors[l_i].m_rand, g_test_rand, 16);
            LLOG(0,0,"Test Flag is enabled. Taking RAND hardcoded");
         }
	 else // To change the rand
	 {
	    int l_rand1 = rand();
	    memcpy((m_vectors[l_i].m_rand), &l_rand1, 4);
	    int l_rand2 = rand();
	    memcpy((m_vectors[l_i].m_rand)+4, &l_rand2, 4);
	    int l_rand3 = rand();
	    memcpy((m_vectors[l_i].m_rand)+8, &l_rand3, 4);
	    int l_rand4 = rand();
	    memcpy((m_vectors[l_i].m_rand)+12, &l_rand4, 4);
	 }
      }

      if( (6 == l_rsad->m_auth_algo) || (5 == l_rsad->m_auth_algo) || (4 == l_rsad->m_auth_algo) )
      {
         int l_derivFunc=1;
         if(4 == l_rsad->m_auth_algo)
         {
            TLOG(0,0,"Setting Derivation Function to 1");
            l_derivFunc=1;
         }
         else if(5 == l_rsad->m_auth_algo)
         {
            TLOG(0,0,"Setting Derivation Function to 2");
            l_derivFunc=2;
         }
         TLOG(0,0,"Calling calculateMilenageVectors");
         bool l_algResult = calculateMilenageVectors(
               l_rsad->m_k, 
               m_vectors[l_i].m_rand, 
               l_derivFunc, 
               l_sqn,
               l_rsad->m_amf,
               l_rsad->m_R1 ,
               l_rsad->m_C1, 
               l_rsad->m_R2,
               l_rsad->m_R3, 
               l_rsad->m_R4,
               l_rsad->m_C2,
               l_rsad->m_C3, 
               l_rsad->m_C4,
               m_vectors[l_i].m_op_c, 
               m_vectors[l_i].m_res, 
               m_vectors[l_i].m_ck, 
               m_vectors[l_i].m_ik, 
               m_vectors[l_i].m_ak, 
               m_vectors[l_i].m_kc, 
               m_vectors[l_i].m_sres,
               m_vectors[l_i].m_mac_a,
               m_vectors[l_i].m_autn
               );
         if (false == l_algResult)
         {
            return false;
         }

         if(m_rnt == REQUEST_NODE_MME)
         {
            if (1 == g_AucConfigReaderObj->m_RandFlag)
            {
               LLOG(0,0,"hard-coding key, snid and data");
               u8 l_key[] = {0x5A,0xFF,0x52,0xE6,0xAA,0xC6,0x52,0x02,0x41,0x11,0xC3,0x3D,0x3F,0x88,0x67,0x86,0x26,0xD7,0x7E,0x75,0x25,0x1C,0x7D,0xA4,0xBB,0x56,0x45,0x36,0x71,0x15,0xE4,0xA8};
               u8 l_snId[] = {0x62, 0xf8, 0x60};
               u8 l_data1[] = {0xB4,0x6F,0x17,0xE0,0xF8,0x4F};
               memcpy(m_vectors[l_i].m_ck, l_key, 16);
               memcpy(m_vectors[l_i].m_ik, l_key+16, 16);
               memcpy(m_vplmnId, l_snId, sizeof(l_snId));
               memcpy(m_vectors[l_i].m_autn, l_data1, sizeof(l_data1));

            }
            TLOG_HEX(0,0,"CK", m_vectors[l_i].m_ck, 16);
            TLOG_HEX(0,0,"IK", m_vectors[l_i].m_ik, 16);
            TLOG_HEX(0,0,"VPLMNID", m_vplmnId, 3);
            TLOG_HEX(0,0,"AUTN", m_vectors[l_i].m_autn, 16);
            if(false == calculateKASME(m_vectors[l_i].m_ck, m_vectors[l_i].m_ik, 0x10, m_vplmnId, m_vectors[l_i].m_autn, m_vectors[l_i].m_kasme))
            {
               return false;
            }
         }
      }
      else if( (2 == l_rsad->m_auth_algo) || (3 == l_rsad->m_auth_algo))
      {
         ECompAlgo l_compAlgo=COMP_ALGO_UNKNOWN;
         if (2 == l_rsad->m_auth_algo)
         {
            l_compAlgo=COMP_ALGO_2;
         }
         else if (3 == l_rsad->m_auth_algo)
         {
            l_compAlgo=COMP_ALGO_3;
         }
         else if (1 == l_rsad->m_auth_algo)
         {
            l_compAlgo=COMP_ALGO_1;
         }
         else
         {
            l_compAlgo=COMP_ALGO_UNKNOWN;
         }

         TLOG(0,0,"Calling calculateCompVectors");

         bool l_algResult = calculateCompVectors(
               l_rsad->m_k, 
               m_vectors[l_i].m_rand, 
               m_vectors[l_i].m_kc, 
               m_vectors[l_i].m_sres,
               l_compAlgo
               );
         if (false == l_algResult)
         {
            return false;
         }
      }
      else
      {
         return false;
      }

      printHexOnDebug("AMF",    (char*)l_rsad->m_amf,          2);
      printHexOnDebug("OP",    (char*)l_rsad->m_op,           16);
      printHexOnDebug("RAND",  (char*)m_vectors[l_i].m_rand,  16);
      printHexOnDebug("Ki",    (char*)l_rsad->m_k,            16);
      printHexOnDebug("SQN",   (char*)l_sqn,                  6);
      if(m_rnt == REQUEST_NODE_MME)
      {
         printHexOnDebug("VPLMN", (char*)m_vplmnId,           3);
      }

      printHexOnDebug("OPc",   (char*)m_vectors[l_i].m_op_c,  16);
      printHexOnDebug("RES",   (char*)m_vectors[l_i].m_res,   8);
      printHexOnDebug("SRES",  (char*)m_vectors[l_i].m_sres,  4);
      printHexOnDebug("Kc",    (char*)m_vectors[l_i].m_kc,    8);
      printHexOnDebug("CK",    (char*)m_vectors[l_i].m_ck,    16);
      printHexOnDebug("IK",    (char*)m_vectors[l_i].m_ik,    16);
      printHexOnDebug("AK",    (char*)m_vectors[l_i].m_ak,    6);
      printHexOnDebug("MAC_A", (char*)m_vectors[l_i].m_mac_a, 8);
      printHexOnDebug("AUTN",  (char*)m_vectors[l_i].m_autn,  16);
      if(m_rnt == REQUEST_NODE_MME)
      {
         printHexOnDebug("KASME", (char*)m_vectors[l_i].m_kasme, 32);
      }

   }

   if( ((((MAP_V3 == getInitialRespondingVersion()) || 
            ((2 == g_spdPtr->m_MsisdnPrefReplaceStruct.m_AuthMemcFlags || 3 == g_spdPtr->m_MsisdnPrefReplaceStruct.m_AuthMemcFlags) && (1 == m_memcUpdateInd) && (MAP_V2 == getInitialRespondingVersion()))) &&
               ('Q' == g_AucConfigReaderObj->m_MAP3_QUIN_OR_TRIPLETS) &&
               (3 == m_subsType)) ||
            (REQUEST_NODE_MME == l_rsad->m_requestNode) ||   
            (REQUEST_NODE_S_CSCF == l_rsad->m_requestNode) || 
            (REQUEST_NODE_WLAN_AAA_SERVER == l_rsad->m_requestNode) )
     )
   {
      DLOG(0,0,"*** INSIDE handleDBResponse for MEMC_QUERY_TYPE_UPDATE ***");
      if (1 != g_AucConfigReaderObj->m_TestFlag) 
      {
         UpdateSubsAuthData *l_usad = new UpdateSubsAuthData();
         strncpy(l_usad->m_imsi, l_rsad->m_imsi, 15);
         if(MAP_V2 == getInitialRespondingVersion())
         {
            memcpy(l_usad->m_sqn, l_rsad->m_sqn, 6);
         }
         else
         {
            memcpy(l_usad->m_sqn, l_sqn, 6);
         }
         strncpy(l_usad->m_accountId, l_rsad->m_accountId, 20);
         l_usad->m_DbQueryType = 2;
         l_usad->m_requestNode = l_rsad->m_requestNode;
         l_usad->m_networkId = l_rsad->m_networkId;
         l_usad->m_AucTemplateId = l_rsad->m_AucTemplateId;
         l_usad->m_RoamPartnerId = l_rsad->m_RoamPartnerId;
         snprintf(l_usad->m_primaryImsi,sizeof(l_usad->m_primaryImsi),"%s",l_rsad->m_primaryImsi);
         memcpy(l_usad->m_k,l_rsad->m_k,16);
         memcpy(l_usad->m_first_k, l_rsad->m_first_k, 16);
         l_usad->m_PartnerTpe = l_rsad->m_imsiType;
         strncpy(l_usad->m_msisdn, l_rsad->m_msisdn, 15);
         l_usad->m_cb = this;

         int l_marMemcahceFlag = 0;
         int l_saiAirMemcachedFlag = 0;
         if(
               (1 == g_ConfigData->m_MemcEnableFlag) && 
               (
                (1 == g_AucConfigReaderObj->m_SAI_AIR_MemcachedFlag) || // && (REQUEST_NODE_S_CSCF == l_rsad->m_requestNode)
                (1 == g_AucConfigReaderObj->m_MAR_MemcachedFlag)
               )
           )
         {
            DLOG(0,0,"Inside Memcached logic");
            if( (1 == g_AucConfigReaderObj->m_MAR_MemcachedFlag) && (REQUEST_NODE_S_CSCF == l_rsad->m_requestNode) )
            {
               l_marMemcahceFlag = 1;
            }
            else if( (1 == g_AucConfigReaderObj->m_SAI_AIR_MemcachedFlag) && ( (REQUEST_NODE_S_CSCF != l_rsad->m_requestNode) && (REQUEST_NODE_WLAN_AAA_SERVER != l_rsad->m_requestNode)) )
            {
               l_saiAirMemcachedFlag = 1;
            }
            DLOG(0,0,"MAR memcached flag |%d| , SAIAIR Memcached flag [%d]",l_marMemcahceFlag,l_saiAirMemcachedFlag);
            if( (1 == l_marMemcahceFlag) || (1 == l_saiAirMemcachedFlag) )
            {
               l_usad->m_DbQueryCachedType = DB_QUERY_CACHED_TYPE_CACHED; 
               l_usad->m_MemcQueryType = MEMC_QUERY_TYPE_UPDATE;
               if(g_OtherConfigData->m_DbThresholdTps > 0)
                  l_usad->m_DbQueryTpsCountable = DB_QUERY_TPS_NON_COUNTABLE;
            }
         }
         if(g_OtherConfigData->m_LaterQueryDbTps > 0)
         {
            DLOG(0,0,"Setting laterQueryDBType");
            l_usad->m_DbQueryQueueType = DB_QUERY_QUEUE_TYPE_LATER; 
         }
         DLOG(0,0,"Going to update in memcached");
         //if((MAP_V3 == getInitialRespondingVersion()) || ((1 == m_memcUpdateInd) && (MAP_V2 == getInitialRespondingVersion())))
         //{
         g_act.execute(l_usad);
         //}
      }
      else // For testing things, don't update SQN
      {
         LLOG(0,0,"Test flag Enabled. Not Updating DB");
      }
   }
   if(REQUEST_ORIGIN_DIAMETER_SWX == m_ro)
   {
	   if(1 == l_rsad->m_curCount)
	   {
		   LLOG(0,0, "REG_TERMINATION_REQ Initiation for AAA host change");
		   char l_rtrXml[500];
		   memset(l_rtrXml,'\0',sizeof(l_rtrXml));
		   snprintf(l_rtrXml, sizeof(l_rtrXml), "%s",l_rsad->m_ossTriggerDataArray[0].m_transXml);
		   DLOG(0,0, "REG_TERMINATION_REQ XML [%s] ", l_rtrXml);
		   g_esc.initiateIndependentContext(this, DIAM_COMM_CODE_CX_DX_RTR_RTA, l_rtrXml, INITIATION_TYPE_IMMEDIATE);
	   }
	   else
	   {
		   DLOG(0,0, "REG_TERMINATION_REQ Not Initiated becase cursor count is %d ",l_rsad->m_curCount);
	   }
   }
   sendFurtherResponses();
   return true;
}

AucVectors::AucVectors()
{
	memset(m_rand, '\0', 16);
	memset(m_op_c, '\0', 16);
	memset(m_res, '\0', 8);
	memset(m_ck, '\0', 16);
	memset(m_ik, '\0', 16);
	memset(m_ak, '\0', 6);
	memset(m_kc, '\0', 8);
	memset(m_sres, '\0', 4);
	memset(m_mac_a, '\0', 8);
	memset(m_autn, '\0', 16);
	memset(m_auts, '\0', 14);
}

AucVectors::~AucVectors()
{
}

