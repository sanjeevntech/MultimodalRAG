#ifndef INCL_CODEC_H
#define INCL_CODEC_H

#include <iostream>
#include <stdio.h>
#include <string>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>


class Codec
{
   public:
      Codec();
      void      Cipher(unsigned char* in, int len, unsigned char* outData, int encdec, unsigned char *key, unsigned char *ivchar);
};
#endif
