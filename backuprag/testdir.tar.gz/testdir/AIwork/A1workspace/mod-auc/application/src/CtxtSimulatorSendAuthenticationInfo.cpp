#include <its++.h>
#include <its_timers.h>
#include <diameter/Command.h>
#include <diameter/base/BaseAVP.h>
#include <AuthenticationInformation.h>
#include <S6a_r10AVP.h>
#include <DiametriqInterface.h>
#include <CtxtSimulatorSendAuthenticationInfo.h>
#include <stdio.h>
#include <ServiceCoordinator.h>
#include <ExtendedServiceCoordinator.h>
#include <Logger.h>
#include <AucDbQueries.h>
#include <DbActiveObject.h>
#include <ByteMilenage.h>
#include <CompAlgorithms.h>
#include <Utilities.h>
#include <AucConfigReader.h>
#include <AucSimConfigReader.h>
#include <DesCodec.h>
#include <DataUnion.h>
#include <TimerManager.h>
#include <typeinfo>
#include <HlrTdrFiller.h>
#include <DiameterMessages.h>
#include <DiameterConstants.h>

using namespace diameter::s6a_r10;

CtxtSimulatorSendAuthenticationInfo::CtxtSimulatorSendAuthenticationInfo()
{
}

CtxtSimulatorSendAuthenticationInfo::~CtxtSimulatorSendAuthenticationInfo()
{
}

bool CtxtSimulatorSendAuthenticationInfo::startProcessing()
{
   unsigned int sIdx;
   string sessIdString;
   if(false == g_esc.allocateSession(DIAM_APP_ID_S6A_S6D, sIdx, sessIdString))
   {
      ELOG(0,1,"Unable to allocate a session");
      return false;
   }

   LLOG(0,0,"AIR Session Id : %s", (char*)sessIdString.c_str());

   DiameterMsg l_test((char*)sessIdString.c_str(), DIAM_EVENT_REQUEST, DIAM_COMM_CODE_S6A_S6D_CLR_CLA);;

   //Prepare a AIR Message
   diameter::s6a_r10::AuthenticationInformationRequest *l_air = new diameter::s6a_r10::AuthenticationInformationRequest;
   l_air->setSessionId(base::SessionId(sessIdString));
   l_air->setSessionIndex(sIdx);


#if 0
   AuthSessionState authSessionState(AuthSessionState::NO_STATE_MAINTAINED);
   l_air->setAuthSessionState(authSessionState);

   OriginHost originHost = diameter::base::OriginHost("3333332.epc.mnc0333mcc333.3gppnetwork.org");
   l_air->setOriginHost(originHost);

   OriginRealm originRealm("epc.mnc0333mcc333.3gppnetwork.org");
   l_air->setOriginRealm(originRealm);

   DestinationRealm destinationRealm("HSS");
   l_air->setDestinationRealm(destinationRealm);

   UserName userName("110000000000009");
   l_air->setUserName(userName);

   SupportedFeatures sf;
   VendorId vi(10415);
   sf.setVendorId(vi);
   FeatureListID flid(1);
   sf.setFeatureListID(flid);
   FeatureList fl(67110415);
   sf.setFeatureList(fl);
   l_air->addSupportedFeatures(sf);

   RequestedEUTRANAuthenticationInfo REAInfo; 
   NumberOfRequestedVectors nofreqvect1(1);
   REAInfo.setNumberOfRequestedVectors(nofreqvect1);
   ImmediateResponsePreferred	imrespref1(1);
   REAInfo.setImmediateResponsePreferred(imrespref1);

   //ReSynchronizationInfo rsinfo1("987654321098765432109876543210");
   REAInfo.setReSynchronizationInfo(rsinfo1);

   l_air->setRequestedEUTRANAuthenticationInfo(REAInfo);

   RequestedUTRANGERANAuthenticationInfo RUGAInfo;
   NumberOfRequestedVectors nofreqvect2(11);
   RUGAInfo.setNumberOfRequestedVectors(nofreqvect2);
   ImmediateResponsePreferred  imrespref2(3);
   //RUGAInfo.setImmediateResponsePreferred(imrespref2);

   ReSynchronizationInfo rsinfo2("123456789012345678901234567890");
   //RUGAInfo.setReSynchronizationInfo(rsinfo2);

   l_air->setRequestedUTRANGERANAuthenticationInfo(RUGAInfo);
   VisitedPLMNId  visPLMNid("33:33:33");
   l_air->setVisitedPLMNId(visPLMNid);
#endif

   AuthSessionState authSessionState(AuthSessionState::NO_STATE_MAINTAINED);
   l_air->setAuthSessionState(authSessionState);

   //OriginHost originHost = diameter::base::OriginHost("3333332.epc.mnc0333mcc333.3gppnetwork.org");
   OriginHost originHost = diameter::base::OriginHost("Mme140Host");
   l_air->setOriginHost(originHost);

   //OriginRealm originRealm = diameter::base::OriginRealm("epc.mnc0333mcc333.3gppnetwork.org");
   OriginRealm originRealm = diameter::base::OriginRealm("Mme140Realm");
   l_air->setOriginRealm(originRealm);

   DestinationHost destinationHost("Hss140Host");
   l_air->setDestinationHost(destinationHost);
   
   DestinationRealm destinationRealm("Hss140Realm");
   l_air->setDestinationRealm(destinationRealm);

   //UserName userName("222540000003588");
   UserName userName(g_AucSimConfigReaderObj->m_simImsi);
   l_air->setUserName(userName);

   SupportedFeatures sf;
   VendorId vi(10415);
   sf.setVendorId(vi);
   FeatureListID flid(1);
   sf.setFeatureListID(flid);
   FeatureList fl(67110415);
   sf.setFeatureList(fl);
   l_air->addSupportedFeatures(sf);

   RequestedEUTRANAuthenticationInfo REAInfo; 
   NumberOfRequestedVectors nofreqvect1(1);
   REAInfo.setNumberOfRequestedVectors(nofreqvect1);
   ImmediateResponsePreferred imrespref1(1);
   REAInfo.setImmediateResponsePreferred(imrespref1);

   ReSynchronizationInfo rsinfo1("987654321098765432109876543210");
   REAInfo.setReSynchronizationInfo(rsinfo1);

   l_air->setRequestedEUTRANAuthenticationInfo(REAInfo);

   RequestedUTRANGERANAuthenticationInfo RUGAInfo;       //(not supported)
   NumberOfRequestedVectors nofreqvect2(11);
   RUGAInfo.setNumberOfRequestedVectors(nofreqvect2);
   ImmediateResponsePreferred  imrespref2(3);
   //RUGAInfo.setImmediateResponsePreferred(imrespref2); 

   ReSynchronizationInfo rsinfo2("123456789012345678901234567890");
   //RUGAInfo.setReSynchronizationInfo(rsinfo2);

   //l_air->setRequestedUTRANGERANAuthenticationInfo(RUGAInfo);
   string l_vplmn;
   l_vplmn.assign("123", 3);
   VisitedPLMNId  visPLMNid(l_vplmn);
   l_air->setVisitedPLMNId(visPLMNid);

   l_test.m_cmd = l_air;
   l_test.m_allocatedFlag = true;
   g_esc.sendMsg(this, &l_test);

   return true;
}

bool CtxtSimulatorSendAuthenticationInfo::processMessage(Msg *p_MsgPtr, bool& p_DeleteFlag)
{
   DLOG(0,0,"Start of CtxtSimulatorSendAuthenticationInfo::processMsg function");

   p_DeleteFlag=p_DeleteFlag; // This is just to keep the compiler happy


   switch (p_MsgPtr->m_MsgType)
   {
      case MSG_TYPE_MAP:
         {
         }
         break;

      case MSG_TYPE_DIAMETER:
         {
            DiameterMsg *l_dm = (DiameterMsg*)p_MsgPtr;
            switch(l_dm->m_det)
            {
               case DIAM_EVENT_REQUEST:
                  LLOG(0,1,"DIAM_EVENT_REQUEST received");
                  break;
               case DIAM_EVENT_ANSWER:
                  LLOG(0,1,"DIAM_EVENT_ANSWER received");
                  break;
               case DIAM_EVENT_TIME_OUT:
                  LLOG(0,1,"DIAM_EVENT_TIME_OUT received");
                  break;
               case DIAM_EVENT_ERROR:
                  LLOG(0,1,"DIAM_EVENT_ERROR received");
                  break;
               case DIAM_EVENT_ERROR_SOMETHING_WEIRD:
                  LLOG(0,1,"DIAM_EVENT_ERROR_SOMETHING_WEIRD received");
                  break;
               case DIAM_EVENT_AUTH_LIFE_TIME_OUT:
                  LLOG(0,1,"DIAM_EVENT_AUTH_LIFE_TIME_OUT received");
                  break;
               case DIAM_EVENT_AUTH_GRACE_TIME_OUT:
                  LLOG(0,1,"DIAM_EVENT_AUTH_GRACE_TIME_OUT received");
                  break;
               case DIAM_EVENT_CORRUPTED_MSG:
                  LLOG(0,1,"DIAM_EVENT_CORRUPTED_MSG received");
                  break;
               case DIAM_EVENT_ACCT_INTERIM_TIME_OUT:
                  LLOG(0,1,"DIAM_EVENT_ACCT_INTERIM_TIME_OUT received");
                  break;
               default:
                  LLOG(0,1,"UNKNOWN DIAMETER received");
                  return false;
                  break;
            }
         }
         break;

      case MSG_TYPE_DB:
         {
         }
         break;

      case MSG_TYPE_TIMEOUT:
         {
            LLOG(0,0,"Timeout received");      
         }
         break;

      default:
         DLOG(0,0,"Unknown message received %d", p_MsgPtr->m_MsgType);
         break;

   }
   return true;
}

