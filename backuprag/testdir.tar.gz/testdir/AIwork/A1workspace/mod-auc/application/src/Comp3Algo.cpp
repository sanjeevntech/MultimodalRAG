/* GSM EXAMPLE ALGORITHM COMP128-3
   This code provides an implementation of the accompanying functional description of COMP128-3, providing a 32-bit response SRES and 64-bit cryptovariable Kc.
   */
#include <stdio.h>
#include <ctype.h> //Added for toupper
#include <stdlib.h> //Added for exit
#include <string.h> //Added for strlen
static unsigned int L[256]={
   197,235,60,151,98,96,3,100,248,118,42,117,172,211,181,203,61,126,156,87,149
      ,
   224,55,132,186,63,238,255,85,83,152,33,160,184,210,219,159,11,180,194,130,
   212,147,5,215,92,27,46,113,187,52,25,185,79,221,48,70,31,101,15,195,201,50,
   222,137,233,229,106,122,183,178,177,144,207,234,182,37,254,227,231,54,209,
   133,65,202,69,237,220,189,146,120,68,21,125,38,30,2,155,53,196,174,176,51,
   246,167,76,110,20,82,121,103,112,56,173,49,217,252,0,114,228,123,12,93,161,
   253,232,240,175,67,128,22,158,89,18,77,109,190,17,62,4,153,163,59,145,138,7
      ,
   74,205,10,162,80,45,104,111,150,214,154,28,191,169,213,88,193,198,200,245,
   39,164,124,84,78,1,188,170,23,86,226,141,32,6,131,127,199,40,135,16,57,71, 91,225,168,242,206,97,166,44,14,90,236,239,230,244,223,108,102,119,148,251,
   29,216,8,9,249,208,24,105,94,34,64,95,115,72,134,204,43,247,243,218,47,58,
   73,107,241,179,116,66,36,143,81,250,139,19,13,142,140,129,192,99,171,157,
   136,41,75,35,165,26} ;
static unsigned int M[256]={
   170,42,95,141,109,30,71,89,26,147,231,205,239,212,124,129,216,79,15,185,153
      ,
   14,251,162,0,241,172,197,43,10,194,235,6,20,72,45,143,104,161,119,41,136,38
      ,
   189,135,25,93,18,224,171,252,195,63,19,58,165,23,55,133,254,214,144,220,178
      ,
   156,52,110,225,97,183,140,39,53,88,219,167,16,198,62,222,76,139,175,94,51,
   134,115,22,67,1,249,217,3,5,232,138,31,56,116,163,70,128,234,132,229,184,
   244,13,34,73,233,154,179,131,215,236,142,223,27,57,246,108,211,8,253,85,66,
   245,193,78,190,4,17,7,150,127,152,213,37,186,2,243,46,169,68,101,60,174,208
      ,
   158,176,69,238,191,90,83,166,125,77,59,21,92,49,151,168,99,9,50,146,113,117
      ,
   228,65,230,40,82,54,237,227,102,28,36,107,24,44,126,206,201,61,114,164,207,
   181,29,91,64,221,255,48,155,192,111,180,210,182,247,203,148,209,98,173,11, 75,123,250,118,32,47,240,202,74,177,100,80,196,33,248,86,157,137,120,130,84
      ,
   204,122,81,242,188,200,149,226,218,160,187,106,35,87,105,96,145,199,159,12,
   121,103,112} ;

int hextoint (char x)
{
   x = toupper (x) ;
   if (x>= 'A' && x <= 'F') return x-'A'+10;
   else if (x>= '0' && x <= '9') return x-'0';
   fprintf(stderr,"Input should be in hex with 16 byte values 0x<Ki> 0x<RAND>\n");
   exit (1) ;
}
void CompF(int A[16], int B[16], int C[16])
{
   int Y[32], Z[16];
   int i,j,k;
   for (j=0;j<16;j++) {
      Y[j]=B[j];
      Y[j+16]=A[j];
   }
   for (k=0;k<5;k++) {
      for (j=0;j<16;j++){Z[j]=L[Y[j]^(M[(Y[j+16])])];}
      for (i=0;i<(1<<k);i++){
         for (j=0; j<(1<<(4-k));j++) {
            Y[((2*j+1)<<k)+i]=L[((Y[(j<<k)+i+16])^(M[Z[(j<<k)+i]]))];
            Y[(j<<(k+1))+i]=Z[(j<<k)+i];
         }
      }
   }
   for (i=0;i<16;i++) C[i]=0;
   /* now compute the 16-byte output, C */
   for (i=0;i<16;i++) {
      for (j=0;j<8;j++) {
         C[i]=C[i]^(((Y[((19*(8*i+j+1))%256)/8]>>((3*j+3)%8))&1)<<j);
      }
   }
} /* end CompF Compression Function */

main(int argc, char **argv){
   int i, j;
   int Ki[16],K[16],R[16],Kc[8], SRES[4];
   /* input 128-bit data values Ki and RAND in hex */
   if (argc !=3 || strlen(argv[1]) != 34 || strlen(argv[2]) != 34 ||
         strncmp(argv[1], "0x",2) != 0 || strncmp(argv[2], "0x", 2) != 0){
      fprintf(stderr,
            "Input in hex the 16-byte values %s 0x<Ki> 0x<RAND>\n",argv[0]);
      exit (1);
   }
   for (i=0; i<16; i++)
      Ki[15-i]=(hextoint(argv[1][2*i+2])<<4)| hextoint(argv[1][2*i+3]);
   /* the initial value of R is the input challenge RAND */
   for(i=0;i<16;i++)
      R[15-i]=(hextoint(argv[2][2*i+2])<<4)| hextoint(argv[2][2*i+3]);
   printf("The input Ki is: 0x");
   for (j=0;j<16;j++) printf("%02x",Ki[15-j]);
   printf("\n\n");
   printf("The input challenge RAND is: 0x");
   for (j=0;j<16;j++) printf("%02x",R[15-j]);
   printf("\n\n");
   /* XOR Ki and RAND to give K in input */
   for (i=0;i<16;i++) K[i]=Ki[i]^R[i];
   /* compute eight rounds of the compression function */
   for (i=0;i<8;i++) CompF(K,R,R);
   /* the 16-byte output S is equal to the value of R after these eight rounds */
   printf("The 16-byte vector S is: 0x");
   for (j=0;j<16;j++) printf("%02x",R[15-j]);
   printf("\n\n");
   /* SRES is the high 32 bits of R; Kc is the last 64 bits of R */
   for (j=0;j<4;j++) SRES[j]=R[12+j];
   for (j=0;j<8;j++) Kc[j]=R[j];
   /* print out SRES and Kc */
   printf("SRES = 0x");
   for (j=0;j<4;j++) printf("%02x",SRES[3-j]);
   printf("\n\n");
   printf("Kc = 0x");
   for (j=0;j<8;j++) printf("%02x",Kc[7-j]);
   printf("\n\n");
}

