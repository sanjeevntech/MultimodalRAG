ott userid=hlr/hlr@lyca code=C intype=demoin.typ outtype=demoout.typ hfile=demo.h
cp demo.h ../inc/
