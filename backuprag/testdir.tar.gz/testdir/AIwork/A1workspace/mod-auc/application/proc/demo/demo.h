#ifndef DEMO_ORACLE
# define DEMO_ORACLE

#ifndef OCI_ORACLE
# include <oci.h>
#endif

typedef OCIRef TEST_STUDENT_ref;
typedef OCIArray TEST_STUDENT_ARRAY;
typedef OCIArray TEST_STUDENT_VARR;

struct TEST_STUDENT
{
   OCINumber ID_NUM;
   OCIString * NAME;
   OCIString * ADDRESS;
   OCIString * STATUS;
};
typedef struct TEST_STUDENT TEST_STUDENT;

struct TEST_STUDENT_ind
{
   OCIInd _atomic;
   OCIInd ID_NUM;
   OCIInd NAME;
   OCIInd ADDRESS;
   OCIInd STATUS;
};
typedef struct TEST_STUDENT_ind TEST_STUDENT_ind;

#endif
